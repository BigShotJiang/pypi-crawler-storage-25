from vallaipallam.tokens import *
import os,sys,time,platform,psutil,subprocess,ctypes,socket,datetime,shutil,hashlib,json,docker
from concurrent.futures import ThreadPoolExecutor, as_completed
from vallaipallam.agenticai import ai

VNAS_STATE_DIR = "VNAS_System_Snapshots"
class NetworkObject(Token):
    os_type = platform.system()
    service_port_map = {
    # Core services
    "ssh": "22",
    "http": "80",
    "https": "443",
    "ftp": "21",
    "dns": "53",
    "smtp": "25",
    "pop3": "110",
    "imap": "143",

    # Databases
    "mysql": "3306",
    "postgresql": "5432",
    "mongodb": "27017",
    "redis": "6379",

    # Dev / cloud services
    "docker": "2375",
    "kubernetes": "6443",
    "elastic": "9200",     # Elasticsearch
    "kibana": "5601",
    "jenkins": "8080"
}

    # ---------- psutil direct mapping (fast; no eval) ----------
    base_commands = {
        'SHOW_INTERFACE_ADDRESSES': psutil.net_if_addrs,                     # dict[str, list[snicaddr]]
        'SHOW_INTERFACE_STATUS': psutil.net_if_stats,                       # dict[str, snicstats]
        'SHOW_ACTIVE_CONNECTIONS': psutil.net_connections,                 # list[sconn]
        'SHOW_NETWORK_IO': psutil.net_io_counters,                 # scounters
        'SHOW_NETWORK_IO_PER_INTERFACE': lambda: psutil.net_io_counters(pernic=True)  # dict[str, scounters]
    }

    # ---------- English → Tamil keywords (stable & explicit) ----------

    def __init__(self, value):
        super().__init__("NET", value)

    # ===================== subprocess helper =====================
    @staticmethod
    def _run(cmd, check=False, text=True, capture=False):
        return subprocess.run(
            cmd,
            check=check,
            text=text,
            capture_output=capture
        )

    # ===================== admin / elevation =====================
    def run_as_admin(self):
        try:
            if self.os_type == "Windows":
                if ctypes.windll.shell32.IsUserAnAdmin():
                    return True
                # relaunch elevated
                ctypes.windll.shell32.ShellExecuteW(
                    None, "runas", sys.executable, " ".join(sys.argv), None, 1
                )
                sys.exit(0)
            else:
                # On Linux/macOS just return whether we are root
                return os.geteuid() == 0
        except Exception:
            return False

    # ===================== OS actions =====================
    def _toggle_iface(self, iface, enable: bool):
        if self.os_type == 'Windows':
            return self._run(["netsh", "interface", "set", "interface", iface,
                              "admin=enabled" if enable else "admin=disabled"])
        else:
            # Linux
            return self._run(["ip", "link", "set", iface, "up" if enable else "down"])

    def _set_dhcp(self, iface):
        if self.os_type == "Windows":
            return self._run(["netsh", "interface", "ip", "set", "address",
                              f"name={iface}", "dhcp"])
        else:
            # Kill any old leases quickly, then request
            self._run(["dhclient", "-r", iface])
            return self._run(["dhclient", iface])

    def _set_ip(self, iface, ip, gw, mask):
        if self.os_type == "Windows":
            # mask must be dotted decimal here
            result=self._run([
                "netsh", "interface", "ip", "set", "address",
                f"name={iface}", "static", ip, mask, gw
            ])
            return result.stdout
        else:
            # Linux: mask can be CIDR (e.g. 24)
            # Flush → add ip/mask → default route
            r1 = self._run(["sudo","ip", "addr", "flush", "dev", iface])
            r2 = self._run(["sudo","ip", "addr", "add", f"{ip}/{mask}", "dev", iface])
            r3 = self._run(["sudo","ip", "route", "replace", "default", "via", gw])
            # Return the last result; non-zero in any step treated as failure by caller
            return r3 if (r1.returncode == 0 and r2.returncode == 0) else r2

    # ===================== Wi-Fi helpers =====================
    def _active_wifi_connection(self):
        """Linux: return active Wi-Fi connection name via nmcli (or None)."""
        res = self._run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show", "--active"])
        if res.returncode != 0:
            return None
        for line in res.stdout.splitlines():
            if not line:
                continue
            name, ctype = (line.split(":", 1) + [""])[:2]
            if ctype.strip() == "wifi":
                print(name)
                return name.strip()
        return None

    def disconnect_wifi(self):
        if self.os_type == "Windows":
            r = self._run(["netsh", "wlan", "disconnect"])
            return 1 if r.returncode == 0 else 0
        else:
            # Prefer disconnecting the active Wi-Fi connection only
            name = self._active_wifi_connection()
            if name:
                r = self._run(["nmcli", "connection", "down", name])
                return 1 if r.returncode == 0 else 0
            # Fallback: turn off Wi-Fi radio
            r = self._run(["sudo","nmcli", "radio", "wifi", "off"])
            return 1 if r.returncode == 0 else 0

    def connect_wifi(self, ssid, password):
        try:
            if self.os_type == "Windows":
                profile = f"""<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
  <name>{ssid}</name>
  <SSIDConfig><SSID><name>{ssid}</name></SSID></SSIDConfig>
  <connectionType>ESS</connectionType>
  <connectionMode>manual</connectionMode>
  <MSM><security>
    <authEncryption>
      <authentication>WPA2PSK</authentication>
      <encryption>AES</encryption>
      <useOneX>false</useOneX>
    </authEncryption>
    <sharedKey>
      <keyType>passPhrase</keyType>
      <protected>false</protected>
      <keyMaterial>{password}</keyMaterial>
    </sharedKey>
  </security></MSM>
</WLANProfile>"""
                pf = "wifi_profile.xml"
                with open(pf, "w", encoding="utf-8") as f:
                    f.write(profile)
                self._run(["netsh", "wlan", "add", "profile", f"filename={pf}"], capture=True)
                res = self._run(["netsh", "wlan", "connect", f"name={ssid}"], capture=True)
                try:
                    os.remove(pf)
                except Exception:
                    pass
                return 1 if "completed successfully" in res.stdout else 0
            else:
                # Linux / NetworkManager
                res = self._run(["sudo","nmcli", "dev", "wifi", "connect", ssid, "password", password])
                ok = ("successfully" in res.stdout.lower()) or (res.returncode == 0)
                return 1 if ok else 0
        except Exception as e:
            print(e)
            return 0

    def list_wifi(self):
        wifi_list = []
        if self.os_type == "Windows":
            res = self._run(["netsh", "wlan", "show", "networks", "mode=bssid"])
            ssid = None
            for line in res.stdout.splitlines():
                s = line.strip()
                if s.startswith("SSID "):
                    # "SSID 1 : Name"
                    parts = s.split(":", 1)
                    ssid = parts[1].strip() if len(parts) == 2 else ""
                    wifi_list.append({"SSID": ssid})
                elif "Signal" in s and ssid:
                    wifi_list[-1]["Signal"] = s.split(":", 1)[1].strip()
                elif "Authentication" in s and ssid:
                    wifi_list[-1]["Security"] = s.split(":", 1)[1].strip()
        elif self.os_type=="Linux":
            res = self._run(["sudo","nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi"],capture=True)
            for line in res.stdout.splitlines():
                parts = line.split(":")
                if len(parts) >= 3 and parts[0].strip():
                    wifi_list.append({
                        "SSID": parts[0].strip(),
                        "Signal": (parts[1].strip() + "%") if parts[1].strip() else "",
                        "Security": parts[2].strip() or "Open"
                    })

        if not wifi_list:
            print("⚠️ No Wi-Fi networks found.")
        print("this is the wifi list",wifi_list)
        out = []
        out.append("Available Wi-Fi Networks")
        out.append("-" * 54)
        out.append(f"{'No.':<4} {'SSID':<28} {'Signal':<10} {'Security':<10}")
        out.append("-" * 54)
        for i, w in enumerate(wifi_list, 1):
            out.append(f"{i:<4} {w.get('SSID','')[:28]:<28} {w.get('Signal',''):<10} {w.get('Security',''):<10}")
        print("this is output","\n".join(out))
        return "\n".join(out)
       
    #========================troubleshooting==============================

    def ping_test(self,host: str) -> str:
        system = platform.system()

        if system == "Windows":
            cmd = ["ping", "-n", "1", host]   # 1 echo request
        else:
            cmd = ["ping", "-c", "1", host]   # Linux/macOS

        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            output = res.stdout
            if res.returncode != 0:
                print(f"Ping Test to {host}\n" \
                    f"{'-'*40}\n" \
                    f"Status   : ❌ Unreachable\n")

            # Extract RTT
            rtt = "N/A"
            for line in output.splitlines():
                if "time=" in line:
                    # Example: "time=24.3 ms"
                    rtt = line.split("time=")[-1].split()[0] + " ms"
                    break

            print(f"Ping Test to {host}\n" \
                f"{'-'*40}\n" \
                f"Status   : ✅ Reachable\n" \
                f"RTT      : {rtt}\n" \
                f"Packets  : Sent=1, Received=1, Lost=0\n")

        except Exception as e:
            print(f"Ping Test to {host}\n" \
                f"{'-'*40}\n" \
                f"Status   : Error\n" \
                f"Reason   : {str(e)}\n")
        
    def traceroute(self, host: str) -> str: 
        """Cross-platform traceroute with safe timeout & error handling"""
        system = platform.system()
        cmd = ["tracert", "-d", host] if system == "Windows" else ["traceroute", "-n", host]

        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if res.returncode != 0 and not res.stdout:
                print(
                    f"Traceroute to {host}\n"
                    f"{'-'*40}\n"
                    f"Status   : ❌ Failed\n"
                    f"Reason   : {res.stderr.strip() or 'Unknown error'}\n"
                )

            lines = res.stdout.strip().splitlines()
            formatted_hops = []
            hop_num = 1
            for line in lines:
                if "Tracing" in line or "over a maximum" in line: continue
                if "traceroute to" in line.lower(): continue
                if not line.strip(): continue
                formatted_hops.append(f"Hop {hop_num:02d} → {line.strip()}")
                hop_num += 1

            if not formatted_hops:
                print(
                    f"Traceroute to {host}\n"
                    f"{'-'*40}\n"
                    f"Status   : ❌ Timed Out\n"
                    f"Note     : Target may be unreachable or blocked by firewall.\n"
                )

            print(
                f"Traceroute to {host}\n"
                f"{'-'*40}\n" +
                "\n".join(formatted_hops)
            )

        except subprocess.TimeoutExpired:
            print(
                f"Traceroute to {host}\n"
                f"{'-'*40}\n"
                f"Status   : ❌ Timed Out\n"
                f"Note     : Try increasing timeout or check firewall settings.\n"
            )
            return 0

        except Exception as e:
            print(
                f"Traceroute to {host}\n"
                f"{'-'*40}\n"
                f"Status   : Error\n"
                f"Reason   : {str(e)}\n"
            )
            return 0

    def dns_lookup(self,host: str) -> str:
        """Resolve domain name to IP address with error handling & formatting"""
        try:
            # gethostbyname_ex returns (hostname, aliaslist, ipaddrlist)
            official_name, aliases, ip_list = socket.gethostbyname_ex(host)

            result = [f"🔎 DNS Lookup for {host}", "-" * 40]
            result.append(f"Official Name : {official_name}")

            if aliases:
                result.append("Aliases       : " + ", ".join(aliases))
            else:
                result.append("Aliases       : None")

            if ip_list:
                result.append("IP Addresses  : " + ", ".join(ip_list))
            else:
                result.append("IP Addresses  : None")
            print("\n".join(result))
            return "\n".join(result)

        except socket.gaierror as e:
            # DNS resolution error (e.g., domain doesn’t exist or no internet)
            print(
                f"🔎 DNS Lookup for {host}\n"
                f"{'-'*40}\n"
                f"Status   : ❌ Failed\n"
                f"Reason   : {str(e)}\n"
            )
            return 0

        except Exception as e:
            # Catch other unexpected errors
            print(
                f"🔎 DNS Lookup for {host}\n"
                f"{'-'*40}\n"
                f"Status   : ❌ Error\n"
                f"Reason   : {str(e)}\n"
            )     
            return 0

    def show_gateway(self):
        start_time = time.time()
        system=self.os_type.lower()
        try:
            if system == "windows":
                cmd = ["route", "print"]
            elif system == "linux":
                cmd = ["ip", "route"]
            else:
                return "❌ Unsupported OS"

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
            output = result.stdout.strip()

            if not output:
                return "❌ No routing information found."

            formatted_output = []
            formatted_output.append("🌐 Routing Table".center(60, "-"))

            if system == "windows":
                lines = output.splitlines()
                # extract the IPv4 routing table
                if "IPv4 Route Table" in output:
                    idx = lines.index("IPv4 Route Table")
                    lines = lines[idx+2:]  # skip header lines

                headers = ["Network Destination", "Netmask", "Gateway", "Interface", "Metric"]
                formatted_output.append(" | ".join(f"{h:<20}" for h in headers))
                formatted_output.append("-" * 90)

                for line in lines:
                    parts = line.split()
                    if len(parts) >= 5 and parts[0][0].isdigit():
                        row = [parts[0], parts[1], parts[2], parts[3], parts[4]]
                        formatted_output.append(" | ".join(f"{col:<20}" for col in row))

            elif system == "linux":
                headers = ["Destination", "Gateway", "Device", "Options"]
                formatted_output.append(" | ".join(f"{h:<20}" for h in headers))
                formatted_output.append("-" * 90)

                for line in output.splitlines():
                    parts = line.split()
                    if "via" in parts:
                        dst = parts[0]
                        gw = parts[2]
                        dev = parts[4] if "dev" in parts else "?"
                        formatted_output.append(f"{dst:<20} | {gw:<20} | {dev:<20} | via")
                    elif "dev" in parts:
                        dst = parts[0]
                        gw = "-"
                        dev = parts[2]
                        formatted_output.append(f"{dst:<20} | {gw:<20} | {dev:<20} | direct")

            execution_time = time.time() - start_time
            formatted_output.append("-" * 60)
            formatted_output.append(f"🟢 Execution Time: {execution_time:.3f} seconds")
            print("\n".join(formatted_output))
            return "\n".join(formatted_output)

        except subprocess.TimeoutExpired:
            return "⏳ Command timed out after 20 seconds."
        except Exception as e:
            return f"⚠️ Error: {str(e)}"
        

    def latency_test(self,target, count=4, timeout=20):
        """
        Test network latency to a given host using ping.
        Works on Windows and Linux (no external modules required).
        """

        start_time = time.time()
        system = self.os_type.lower()

        try:
            if system == "windows":
                cmd = ["ping", "-n", str(count), "-w", str(timeout * 1000), target]
            elif system == "linux":
                cmd = ["ping", "-c", str(count), "-W", str(timeout), target]
            else:
                return "❌ Unsupported OS"

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 5)
            output = result.stdout.strip()

            if not output:
                return f"❌ No response from {target}"

            # Format output
            lines = output.splitlines()
            formatted = []
            formatted.append(f"🌐 Latency Test to {target}")
            formatted.append("-" * 50)

            if system == "windows":
                sent, received, lost = 0, 0, 0
                avg, min_, max_ = None, None, None

                for line in lines:
                    if "Packets:" in line:
                        parts = line.split(",")
                        sent = int(parts[0].split("=")[1])
                        received = int(parts[1].split("=")[1])
                        lost = int(parts[2].split("=")[1].split()[0])
                    if "Average =" in line:
                        parts = line.split(",")
                        min_ = parts[0].split("=")[1].strip()
                        max_ = parts[1].split("=")[1].strip()
                        avg = parts[2].split("=")[1].strip()

                if avg:
                    formatted.append(f"Average Latency   : {avg}")
                    formatted.append(f"Min Latency       : {min_}")
                    formatted.append(f"Max Latency       : {max_}")
                    formatted.append(f"Packets Sent      : {sent}")
                    formatted.append(f"Packets Received  : {received}")
                    formatted.append(f"Packet Loss       : {lost}%")
                    formatted.append("-" * 50)
                    formatted.append("🟢 Status : Good Connection" if lost == 0 else "⚠️ Status : Packet Loss Detected")

            elif system == "linux":
                stats_line = [line for line in lines if "rtt min/avg/max/mdev" in line]
                packet_line = [line for line in lines if "packets transmitted" in line]

                if packet_line:
                    parts = packet_line[0].split(",")
                    sent = int(parts[0].split()[0])
                    received = int(parts[1].split()[0])
                    loss = parts[2].strip()
                    formatted.append(f"Packets Sent      : {sent}")
                    formatted.append(f"Packets Received  : {received}")
                    formatted.append(f"Packet Loss       : {loss}")

                if stats_line:
                    stats = stats_line[0].split("=")[1].split("/")
                    min_, avg, max_ = stats[0], stats[1], stats[2]
                    formatted.append(f"Average Latency   : {avg} ms")
                    formatted.append(f"Min Latency       : {min_} ms")
                    formatted.append(f"Max Latency       : {max_} ms")

                formatted.append("-" * 50)
                formatted.append("🟢 Status : Good Connection" if "0% packet loss" in output else "⚠️ Status : Packet Loss Detected")

            execution_time = time.time() - start_time
            formatted.append(f"⏱️ Execution Time: {execution_time:.3f} seconds")
            print("\n".join(formatted))
            return "\n".join(formatted)

        except subprocess.TimeoutExpired:
            return f"⏳ Error: Request timed out after {timeout} seconds."
        except Exception as e:
            return f"⚠️ Error: {str(e)}"
    #=======================Allow/disable services=========================

    def allow_service(self,service_name: str):
        os_type = self.os_type
        print("\n===============================")
        print(f" ✅ ALLOW SERVICE ({service_name}) (சேவை_அனுமதி)")
        print("===============================")
        print(f"🖥️  Detected OS : {os_type}\n")

        port = self.service_port_map.get(service_name.lower())

        if not port:
            print(f"❌ Unknown service: {service_name}")
            print("➡️ Please provide a valid service name (e.g., ssh, http, mysql).")
            return

        try:
            if os_type == "Windows":
                cmd = ["netsh", "advfirewall", "firewall", "add", "rule",
                    f"name=Allow_{service_name}", "dir=in", "action=allow", f"protocol=TCP", f"localport={port}"]
                result = subprocess.run(cmd, capture_output=True, text=True)
                print("🟢 Beginner View: Service allowed successfully ✅")
                print("\n📊 Professional View:")
                print(result.stdout.strip() or f"Rule added to allow {service_name} on port {port}")

            elif os_type == "Linux":
                try:
                    cmd = ["sudo", "ufw", "allow", str(port)]
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    print("🟢 Beginner View: Service allowed successfully ✅")
                    print("\n📊 Professional View:")
                    print(result.stdout.strip() or f"ufw rule added to allow {service_name} on port {port}")
                except subprocess.CalledProcessError:
                    cmd = ["sudo", "iptables", "-A", "INPUT", "-p", "tcp", "--dport", str(port), "-j", "ACCEPT"]
                    subprocess.run(cmd, capture_output=True, text=True, check=True)
                    print("🟢 Beginner View: Service allowed successfully ✅")
                    print("\n📊 Professional View:")
                    print(f"iptables rule added to allow {service_name} on port {port}")

            else:
                print("🔴 Unsupported OS: This command works only on Windows and Linux.")

        except subprocess.CalledProcessError as e:
            print("❌ Error while allowing service!")
            print("📊 Details:", e.stderr.strip() if e.stderr else str(e))

        except FileNotFoundError:
            print("❌ Firewall tool not found (ufw/iptables/netsh missing).")
            print("➡️ Please install or configure manually.")

        except Exception as e:
            print("⚠️ Unexpected Error:", str(e))

    def block_service(self,service_name: str):
        os_type = platform.system()
        print("\n===============================")
        print(f" ⛔ BLOCK SERVICE ({service_name}) (சேவை_தடு)")
        print("===============================")
        print(f"🖥️  Detected OS : {os_type}\n")

        port = self.service_port_map.get(service_name.lower())

        if not port:
            print(f"❌ Unknown service: {service_name}")
            print("➡️ Please provide a valid service name (e.g., ssh, http, mysql).")
            return

        try:
            if os_type == "Windows":
                cmd = ["netsh", "advfirewall", "firewall", "add", "rule",
                    f"name=Block_{service_name}", "dir=in", "action=block", f"protocol=TCP", f"localport={port}"]
                result = subprocess.run(cmd, capture_output=True, text=True)
                print("🟢 Beginner View: Service blocked successfully ✅")
                print("\n📊 Professional View:")
                print(result.stdout.strip() or f"Rule added to block {service_name} on port {port}")

            elif os_type == "Linux":
                try:
                    cmd = ["sudo", "ufw", "deny", str(port)]
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    print("🟢 Beginner View: Service blocked successfully ✅")
                    print("\n📊 Professional View:")
                    print(result.stdout.strip() or f"ufw rule added to block {service_name} on port {port}")
                except subprocess.CalledProcessError:
                    cmd = ["sudo", "iptables", "-A", "INPUT", "-p", "tcp", "--dport", str(port), "-j", "DROP"]
                    subprocess.run(cmd, capture_output=True, text=True, check=True)
                    print("🟢 Beginner View: Service blocked successfully ✅")
                    print("\n📊 Professional View:")
                    print(f"iptables rule added to block {service_name} on port {port}")

            else:
                print("🔴 Unsupported OS: This command works only on Windows and Linux.")

        except subprocess.CalledProcessError as e:
            print("❌ Error while blocking service!")
            print("📊 Details:", e.stderr.strip() if e.stderr else str(e))

        except FileNotFoundError:
            print("❌ Firewall tool not found (ufw/iptables/netsh missing).")
            print("➡️ Please install or configure manually.")

        except Exception as e:
            print("⚠️ Unexpected Error:", str(e))


    #====================== PORT SCAN FUNCTIONS ===================


    def _parse_ports(self,port_spec):
        """
        Accepts:
        "22" -> [22]
        "20-25" -> [20,21,22,23,24,25]
        "22,80,443" -> [22,80,443]
        "20-22,80" -> [20,21,22,80]
        Raises ValueError for bad input.
        """
        ports = set()
        parts = port_spec.split(",")
        for p in parts:
            p = p.strip()
            if "-" in p:
                a, b = p.split("-", 1)
                a = int(a.strip()); b = int(b.strip())
                if a < 1 or b > 65535 or a > b:
                    raise ValueError(f"Invalid port range: {p}")
                ports.update(range(a, b+1))
            else:
                v = int(p)
                if v < 1 or v > 65535:
                    raise ValueError(f"Invalid port number: {p}")
                ports.add(v)
        return sorted(ports)


    def _scan_port(self,addr, port, timeout):
        """
        Try TCP connect to (addr, port) with timeout.
        Returns (port, state, duration_seconds)
        state: "open", "closed", "filtered", "error_resolve", "error_network", "error_other"
        """
        start = time.perf_counter()
        try:
            # socket.create_connection wraps connect and handles name resolution if needed
            with socket.create_connection((addr, port), timeout=timeout):
                dur = time.perf_counter() - start
                return (port, "open", dur)
        except socket.timeout:
            dur = time.perf_counter() - start
            return (port, "filtered", dur)   # likely filtered or unreachable (no reply)
        except ConnectionRefusedError:
            dur = time.perf_counter() - start
            return (port, "closed", dur)
        except OSError as e:
            dur = time.perf_counter() - start
            msg = str(e).lower()
            if "name or service not known" in msg or "nodename nor servname provided" in msg:
                return (port, "error_resolve", dur)
            if "network is unreachable" in msg or "no route to host" in msg:
                return (port, "error_network", dur)
            return (port, "error_other", dur)


    def port_scan(self,host, port_spec, timeout=1.0, workers=100):
        """
        Scan TCP ports on host according to port_spec (single, range or comma list).
        Returns a formatted string (human readable + informative).
        """
        # Resolve host first
        start_all = time.perf_counter()
        try:
            resolved = socket.gethostbyname_ex(host)
            canonical_name, aliases, ip_list = resolved[0], resolved[1], resolved[2]
            ip_display = ", ".join(ip_list) if ip_list else "N/A"
        except socket.gaierror as e:
            return (
                f"Port Scan: {host} ({port_spec})\n"
                + "-" * 60 + "\n"
                + "Status   : ❌ Host name resolution failed\n"
                + f"Reason   : {e}\n"
                + "Note     : Check DNS or the hostname/IP provided.\n"
            )

        # parse ports
        try:
            ports = self._parse_ports(port_spec)
        except ValueError as e:
            return f"Port Scan: Invalid port specification: {e}"

        total_ports = len(ports)
        header_lines = []
        header_lines.append(f"Port Scan: {host}  ({ip_display})")
        header_lines.append("-" * 60)
        header_lines.append(f"Ports    : {port_spec} -> {total_ports} port(s)")
        header_lines.append(f"Timeout  : {timeout}s  Parallel threads: {min(workers, total_ports)}")
        header_lines.append("")

        # Limit workers sensibly
        max_workers = min(workers, total_ports, 500)
        results = []

        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(self._scan_port, ip_list[0], p, timeout): p for p in ports}
            for fut in as_completed(futures):
                p = futures[fut]
                try:
                    res = fut.result()
                except Exception:
                    results.append((p, "error_other", 0.0))
                else:
                    results.append(res)

        # Sort results by port
        results.sort(key=lambda x: x[0])

        # Produce summary counts
        counts = {"open":0, "closed":0, "filtered":0, "error_resolve":0, "error_network":0, "error_other":0}
        for _, state, _ in results:
            if state in counts:
                counts[state] += 1
            else:
                counts["error_other"] += 1

        # Build table lines
        lines = header_lines.copy()
        lines.append(f"{'Port':>6}  {'State':<12}  {'RTT(ms)':>8}  {'Service':<12}")
        lines.append("-"*60)
        for port, state, dur in results:
            rtt_ms = f"{dur*1000:.1f}" if dur and dur > 0 else "-"
            # Try to map common port -> service
            service = "-"
            try:
                service = socket.getservbyport(port, "tcp")
            except Exception:
                service = "-"
            state_mark = {"open":"✅ open", "closed":"✖ closed", "filtered":"⚠ filtered",
                        "error_resolve":"! DNS", "error_network":"! network", "error_other":"! err"}.get(state, state)
            lines.append(f"{port:6d}  {state_mark:<12}  {rtt_ms:>8}  {service:<12}")

        # Summary
        elapsed = time.perf_counter() - start_all
        lines.append("-"*60)
        lines.append(f"Summary: Open={counts['open']}, Closed={counts['closed']}, Filtered={counts['filtered']}, Errors={counts['error_resolve']+counts['error_network']+counts['error_other']}")
        lines.append(f"Elapsed: {elapsed:.2f}s")

        # Recommendations (helpful for diagnosis)
        if counts["open"] == 0 and counts["filtered"] > 0:
            lines.append("Note: Ports appear filtered (firewall may be dropping packets).")
        if counts["open"] == 0 and counts["closed"] > 0 and counts["filtered"] == 0:
            lines.append("Note: Host reachable but no listening services on the scanned ports.")
        if counts["error_network"] > 0:
            lines.append("Warning: network unreachable for one or more ports (check routing/firewall).")
        print("\n".join(lines))
        return "\n".join(lines)
    

    def allow_port(self, port):
        """
        துறைமுகம்_அனுமதி (ALLOW_PORT)
        Opens a TCP port in the firewall (Windows & Linux).
        Consistent Beginner + Professional output format.
        """
        os_type = self.os_type
        print("\n===============================")
        print(f" 🔓 ALLOW PORT {port} (துறைமுகம்_அனுமதி)")
        print("===============================")
        print(f"🖥️  Detected OS : {os_type}\n")

        try:
            # ---------------- Windows ----------------
            if os_type == "Windows":
                rule_name = f"Allow Port {port}"
                # Check if rule with this name exists
                try:
                    chk = subprocess.run(
                        ["netsh", "advfirewall", "firewall", "show", "rule", f"name={rule_name}"],
                        capture_output=True, text=True
                    )
                except FileNotFoundError:
                    print("❌ 'netsh' not found on this system.")
                    return

                chk_out = (chk.stdout or "") + (chk.stderr or "")
                if "no rules match" not in chk_out.lower() and chk_out.strip():
                    # Rule exists
                    print(f"🟡 Beginner View: Port {port} already has an allow rule (no change).")
                    print("\n📊 Professional View:")
                    print(chk_out.strip())
                    return

                # Add the rule
                add = subprocess.run([
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    f"name={rule_name}", "dir=in", "action=allow",
                    "protocol=TCP", f"localport={port}"
                ], capture_output=True, text=True)

                if add.returncode == 0:
                    print(f"🟢 Beginner View: Port {port} is now OPEN ✅")
                    print("\n📊 Professional View:")
                    print(add.stdout.strip() or "Rule added successfully.")
                else:
                    print(f"❌ Failed to add rule for port {port}.")
                    print("\n📊 Professional View:")
                    print(add.stderr.strip() or add.stdout.strip() or f"Return code: {add.returncode}")

            # ---------------- Linux ----------------
            elif os_type == "Linux":
                # Try UFW first
                use_iptables = False
                try:
                    status = subprocess.run(["sudo", "ufw", "status", "numbered"],
                                            capture_output=True, text=True)
                    out = (status.stdout or "") + (status.stderr or "")
                    if f"{port}/tcp" in out and "allow" in out.lower():
                        print(f"🟡 Beginner View: Port {port} already allowed (ufw).")
                        print("\n📊 Professional View:")
                        print(out.strip())
                        return
                    # Not found → add
                    add = subprocess.run(["sudo", "ufw", "allow", f"{port}/tcp"],
                                        capture_output=True, text=True)
                    if add.returncode == 0:
                        print(f"🟢 Beginner View: Port {port} is now OPEN ✅")
                        print("\n📊 Professional View:")
                        print(add.stdout.strip() or add.stderr.strip() or "ufw rule added.")
                        return
                    # If ufw exists but failed for some reason, we'll fallback to iptables
                    use_iptables = True
                except FileNotFoundError:
                    use_iptables = True

                # iptables fallback
                if use_iptables:
                    # Check if iptables already has rule
                    chk = subprocess.run(
                        ["sudo", "iptables", "-C", "INPUT", "-p", "tcp", "--dport", str(port), "-j", "ACCEPT"],
                        capture_output=True, text=True
                    )
                    if chk.returncode == 0:
                        print(f"🟡 Beginner View: Port {port} already allowed (iptables).")
                        print("\n📊 Professional View:")
                        print("iptables rule exists (INPUT ACCEPT).")
                        return

                    # Add iptables rule
                    add = subprocess.run(
                        ["sudo", "iptables", "-I", "INPUT", "-p", "tcp", "--dport", str(port), "-j", "ACCEPT"],
                        capture_output=True, text=True
                    )
                    if add.returncode == 0:
                        print(f"🟢 Beginner View: Port {port} is now OPEN ✅")
                        print("\n📊 Professional View:")
                        print(f"iptables rule inserted: ACCEPT tcp dport {port}")
                    else:
                        print(f"❌ Failed to add iptables rule for port {port}.")
                        print("\n📊 Professional View:")
                        print(add.stderr.strip() or add.stdout.strip() or f"Return code: {add.returncode}")

            # ---------------- Unsupported OS ----------------
            else:
                print("🔴 Unsupported OS: This command works only on Windows and Linux.")

        except PermissionError:
            print("❌ Permission denied: run as Administrator (Windows) or use sudo (Linux).")

        except FileNotFoundError as e:
            print("❌ Required tool not found:", str(e))
            print("➡️ Install ufw/iptables (Linux) or ensure netsh is available (Windows).")

        except Exception as e:
            print("⚠️ Unexpected Error:", str(e))



    def block_port(self, port):
        """
        துறைமுகம்_தடு (BLOCK_PORT)
        Blocks a TCP port in the firewall (Windows & Linux).
        Consistent Beginner + Professional output format.
        """
        # Validate port
       
        os_type = self.os_type
        print("\n===============================")
        print(f" 🔒 BLOCK PORT {port} (துறைமுகம்_தடு)")
        print("===============================")
        print(f"🖥️  Detected OS : {os_type}\n")

        try:
            # ---------------- Windows ----------------
            if os_type == "Windows":
                rule_name = f"Block Port {port}"
                # Check existing rule
                try:
                    chk = subprocess.run(
                        ["netsh", "advfirewall", "firewall", "show", "rule", f"name={rule_name}"],
                        capture_output=True, text=True
                    )
                except FileNotFoundError:
                    print("❌ 'netsh' not found on this system.")
                    return

                chk_out = (chk.stdout or "") + (chk.stderr or "")
                if "no rules match" not in chk_out.lower() and chk_out.strip():
                    print(f"🟡 Beginner View: Port {port} already has a block rule (no change).")
                    print("\n📊 Professional View:")
                    print(chk_out.strip())
                    return

                # Add block rule
                add = subprocess.run([
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    f"name={rule_name}", "dir=in", "action=block",
                    "protocol=TCP", f"localport={port}"
                ], capture_output=True, text=True)

                if add.returncode == 0:
                    print(f"🟢 Beginner View: Port {port} is now BLOCKED 🚫")
                    print("\n📊 Professional View:")
                    print(add.stdout.strip() or "Rule added successfully.")
                else:
                    print(f"❌ Failed to add block rule for port {port}.")
                    print("\n📊 Professional View:")
                    print(add.stderr.strip() or add.stdout.strip() or f"Return code: {add.returncode}")

            # ---------------- Linux ----------------
            elif os_type == "Linux":
                use_iptables = False
                try:
                    status = subprocess.run(["sudo", "ufw", "status", "numbered"],
                                            capture_output=True, text=True)
                    out = (status.stdout or "") + (status.stderr or "")
                    if f"{port}/tcp" in out and ("deny" in out.lower() or "blocked" in out.lower()):
                        print(f"🟡 Beginner View: Port {port} already blocked (ufw).")
                        print("\n📊 Professional View:")
                        print(out.strip())
                        return

                    add = subprocess.run(["sudo", "ufw", "deny", f"{port}/tcp"],
                                        capture_output=True, text=True)
                    if add.returncode == 0:
                        print(f"🟢 Beginner View: Port {port} is now BLOCKED 🚫")
                        print("\n📊 Professional View:")
                        print(add.stdout.strip() or add.stderr.strip() or "ufw rule added.")
                        return
                    use_iptables = True
                except FileNotFoundError:
                    use_iptables = True

                # iptables fallback
                if use_iptables:
                    chk = subprocess.run(
                        ["sudo", "iptables", "-C", "INPUT", "-p", "tcp", "--dport", str(port), "-j", "DROP"],
                        capture_output=True, text=True
                    )
                    if chk.returncode == 0:
                        print(f"🟡 Beginner View: Port {port} already blocked (iptables).")
                        print("\n📊 Professional View:")
                        print("iptables rule exists (INPUT DROP).")
                        return

                    add = subprocess.run(
                        ["sudo", "iptables", "-I", "INPUT", "-p", "tcp", "--dport", str(port), "-j", "DROP"],
                        capture_output=True, text=True
                    )
                    if add.returncode == 0:
                        print(f"🟢 Beginner View: Port {port} is now BLOCKED 🚫")
                        print("\n📊 Professional View:")
                        print(f"iptables rule inserted: DROP tcp dport {port}")
                    else:
                        print(f"❌ Failed to add iptables DROP rule for port {port}.")
                        print("\n📊 Professional View:")
                        print(add.stderr.strip() or add.stdout.strip() or f"Return code: {add.returncode}")

            # ---------------- Unsupported OS ----------------
            else:
                print("🔴 Unsupported OS: This command works only on Windows and Linux.")

        except PermissionError:
            print("❌ Permission denied: run as Administrator (Windows) or use sudo (Linux).")

        except FileNotFoundError as e:
            print("❌ Required tool not found:", str(e))
            print("➡️ Install ufw/iptables (Linux) or ensure netsh is available (Windows).")

        except Exception as e:
            print("⚠️ Unexpected Error:", str(e))

   #======================= firewall enable and disable =================

    def enable_firewall(self):
        os_type = self.os_type
        print("\n===============================")
        print(" 🔐 ENABLE FIREWALL (தடுப்பு_செயல்படுத்து)")
        print("===============================")
        print(f"🖥️  Detected OS : {os_type}\n")

        try:
            if os_type == "Windows":
                cmd = ["netsh", "advfirewall", "set", "allprofiles", "state", "on"]
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                # Beginner output
                print("🟢 Beginner View: Firewall is now ENABLED ✅")
                
                # Professional output
                print("\n📊 Professional View:")
                if result.returncode == 0:
                    print(result.stdout.strip() or "Firewall enabled successfully.")
                else:
                    print("⚠️ Firewall command executed with issues:", result.stderr.strip())

            elif os_type == "Linux":
                try:
                    # Force enable UFW without interactive prompt
                    cmd = ["sudo", "ufw", "--force", "enable"]
                    result = subprocess.run(cmd, capture_output=True, text=True)

                    print("🟢 Beginner View: Firewall is now ENABLED ✅")
                    print("\n📊 Professional View:")
                    if result.returncode == 0:
                        print(result.stdout.strip() or result.stderr.strip() or "Firewall enabled successfully.")
                    else:
                        print("⚠️ UFW execution issue:", result.stderr.strip())

                except FileNotFoundError:
                    # fallback to iptables if ufw not found
                    cmds = [
                        ["sudo", "iptables", "-P", "INPUT", "DROP"],
                        ["sudo", "iptables", "-P", "OUTPUT", "ACCEPT"],
                        ["sudo", "iptables", "-P", "FORWARD", "DROP"],
                    ]
                    for cmd in cmds:
                        subprocess.run(cmd, capture_output=True, text=True)

                    print("🟢 Beginner View: Firewall is now ENABLED ✅")
                    print("\n📊 Professional View:")
                    print("iptables policy set: DROP incoming, ACCEPT outgoing.")

            else:
                print("🔴 Unsupported OS: This command works only on Windows and Linux.")

        except Exception as e:
            print("⚠️ Unexpected Error:", str(e))


    def disable_firewall(self):
        os_type = self.os_type
        print("\n===============================")
        print(" 🔓 DISABLE FIREWALL (தடுப்பு_நிறுத்து)")
        print("===============================")
        print(f"🖥️  Detected OS : {os_type}\n")

        try:
            if os_type == "Windows":
                cmd = ["netsh", "advfirewall", "set", "allprofiles", "state", "off"]
                result = subprocess.run(cmd, capture_output=True, text=True)

                # Beginner output
                print("🟢 Beginner View: Firewall is now DISABLED ❌")

                # Professional output
                print("\n📊 Professional View:")
                if result.returncode == 0:
                    print(result.stdout.strip() or "Firewall disabled successfully.")
                else:
                    print("⚠️ Firewall command executed with issues:", result.stderr.strip())

            elif os_type == "Linux":
                try:
                    # Force disable UFW without interactive prompt
                    cmd = ["sudo", "ufw", "--force", "disable"]
                    result = subprocess.run(cmd, capture_output=True, text=True)

                    print("🟢 Beginner View: Firewall is now DISABLED ❌")
                    print("\n📊 Professional View:")
                    if result.returncode == 0:
                        print(result.stdout.strip() or result.stderr.strip() or "Firewall disabled successfully.")
                    else:
                        print("⚠️ UFW execution issue:", result.stderr.strip())

                except FileNotFoundError:
                    # fallback to iptables flush if ufw not found
                    cmds = [
                        ["sudo", "iptables", "-F"],
                        ["sudo", "iptables", "-P", "INPUT", "ACCEPT"],
                        ["sudo", "iptables", "-P", "OUTPUT", "ACCEPT"],
                        ["sudo", "iptables", "-P", "FORWARD", "ACCEPT"],
                    ]
                    for cmd in cmds:
                        subprocess.run(cmd, capture_output=True, text=True)

                    print("🟢 Beginner View: Firewall is now DISABLED ❌")
                    print("\n📊 Professional View:")
                    print("iptables policy reset: ACCEPT all traffic (INPUT/OUTPUT/FORWARD).")

            else:
                print("🔴 Unsupported OS: This command works only on Windows and Linux.")

        except Exception as e:
            print("⚠️ Unexpected Error:", str(e))
    #==========================firewall rules
    def list_firewall_rules(self):
        os_type = self.os_type
        print("\n===================================")
        print(" 📜 FIREWALL RULES (துறைமுகம்_விதிகள்)")
        print("===================================")
        print(f"🖥️  Detected OS : {os_type}\n")

        try:
            if os_type == "Windows":
                cmd = ["netsh", "advfirewall", "firewall", "show", "rule", "name=all"]
                result = subprocess.run(cmd, capture_output=True, text=True, check=True)

                print("🟢 Beginner View: Below are your active firewall rules 👇")
                print("\n📊 Professional View (Raw netsh output):\n")
                print(result.stdout.strip() or "No firewall rules found.")

            elif os_type == "Linux":
                try:
                    cmd = ["sudo", "ufw", "status", "numbered"]
                    result = subprocess.run(cmd, capture_output=True, text=True, check=True)

                    print("🟢 Beginner View: Below are your active firewall rules 👇")
                    print("\n📊 Professional View (UFW output):\n")
                    print(result.stdout.strip() or "No firewall rules found.")

                except subprocess.CalledProcessError:
                    # fallback → iptables
                    cmd = ["sudo", "iptables", "-L", "-n", "-v"]
                    result = subprocess.run(cmd, capture_output=True, text=True)

                    print("🟢 Beginner View: Firewall rules listed successfully 👇")
                    print("\n📊 Professional View (iptables output):\n")
                    print(result.stdout.strip() or "No iptables rules found.")

            else:
                print("🔴 Unsupported OS: This command works only on Windows and Linux.")

        except subprocess.CalledProcessError as e:
            print("❌ Error while listing firewall rules!")
            print("📊 Details:", e.stderr.strip() if e.stderr else str(e))

        except FileNotFoundError:
            print("❌ Firewall tool not found (ufw/iptables/netsh missing).")
            print("➡️ Please install or configure manually.")

        except Exception as e:
            print("⚠️ Unexpected Error:", str(e))


    # ===================== formatters (pretty, fast) =====================
    def _fmt_if_addrs(self, data: dict):
        lines = ["Interface Addresses", "-" * 60]
        if not data:
            lines.append("(none)")
            return "\n".join(lines)
        fam_map = {
            socket.AF_INET:  "IPv4",
            socket.AF_INET6: "IPv6",
            getattr(socket, "AF_LINK", 0): "MAC"
        }
        for iface, addrs in data.items():
            lines.append(f"\n[{iface}]")
            if not addrs:
                lines.append("  (no addresses)")
                continue
            for a in addrs:
                fam = fam_map.get(getattr(a, "family", None), str(getattr(a, "family", "")))
                addr = getattr(a, "address", "")
                mask = getattr(a, "netmask", "")
                bcast = getattr(a, "broadcast", "")
                ptp = getattr(a, "ptp", "")
                lines.append(f"  {fam:<4}  addr={addr}  mask={mask}  bcast={bcast}  ptp={ptp}")
        return "\n".join(lines)

    def _fmt_if_stats(self, data: dict):
        lines = ["Interface Status", "-" * 60, f"{'Iface':<18} {'Up':<4} {'Speed(Mbps)':<12} {'Duplex':<8} {'MTU':<6}"]
        for iface, st in data.items():
            up = "Yes" if getattr(st, "isup", False) else "No"
            sp = getattr(st, "speed", 0)
            dp = getattr(st, "duplex", 0)
            # Map duplex code to text if available
            dup_map = {0: "?", 1: "Full", 2: "Half"}
            dup = dup_map.get(dp, str(dp))
            mtu = getattr(st, "mtu", 0)
            lines.append(f"{iface:<18} {up:<4} {sp:<12} {dup:<8} {mtu:<6}")
        return "\n".join(lines)

    def _fmt_connections(self, conns, limit=50):
        lines = ["Active Connections", "-" * 90,
                 f"{'Proto':<6} {'Local Address':<25} {'Remote Address':<25} {'State':<13} {'PID':<6}"]
        cnt = 0
        for c in conns:
            if cnt >= limit: break
            proto = "tcp" if getattr(c, "type", 0) == socket.SOCK_STREAM else ("udp" if getattr(c, "type", 0) == socket.SOCK_DGRAM else str(getattr(c, "type", "")))
            la = getattr(c, "laddr", None)
            ra = getattr(c, "raddr", None)
            ltxt = f"{la.ip}:{la.port}" if la else ""
            rtxt = f"{ra.ip}:{ra.port}" if ra else ""
            state = getattr(c, "status", "")
            pid = getattr(c, "pid", "")
            lines.append(f"{proto:<6} {ltxt:<25} {rtxt:<25} {state:<13} {str(pid):<6}")
            cnt += 1
        lines.append(f"-- showing {cnt} of {len(conns)} --")
        return "\n".join(lines)

    def _fmt_io_global(self, io):
        # scounters(bytes_sent, bytes_recv, packets_sent, packets_recv, errin, errout, dropin, dropout)
        fields = getattr(io, "_fields", [])
        return "\n".join([f"{f}: {getattr(io, f)}" for f in fields]) if fields else str(io)

    def _fmt_io_pernic(self, d):
        lines = ["Per-Interface IO", "-" * 60, f"{'Iface':<16} {'Sent(bytes)':>12} {'Recv(bytes)':>12} {'Pkt-S':>8} {'Pkt-R':>8} {'ErrIn':>6} {'ErrOut':>6} {'DropIn':>6} {'DropOut':>7}"]
        for iface, io in d.items():
            lines.append(f"{iface:<16} {getattr(io,'bytes_sent',0):>12} {getattr(io,'bytes_recv',0):>12} "
                         f"{getattr(io,'packets_sent',0):>8} {getattr(io,'packets_recv',0):>8} "
                         f"{getattr(io,'errin',0):>6} {getattr(io,'errout',0):>6} "
                         f"{getattr(io,'dropin',0):>6} {getattr(io,'dropout',0):>7}")
        return "\n".join(lines)

    # ===================== utilities =====================
    def speed(self, iface):
        per = psutil.net_io_counters(pernic=True)
        if iface not in per:
            # fallback: first NIC
            if not per:
                return 0.0
            iface = next(iter(per.keys()))
        old = per[iface].bytes_recv
        time.sleep(1)
        new = psutil.net_io_counters(pernic=True)[iface].bytes_recv
        net_speed=(new - old) / 1024.0
        print("Internet speed:",net_speed) 
        return  net_speed# KB/s
    #=====================VPN ADMINISTRATION ====================
 
    def create_vpn_profile(self,profile_name, server, user, password, vpn_type="pptp"):
        """
        Creates a cross-platform VPN connection profile using only built-in modules.
        
        Args:
            profile_name: The name for the new VPN connection.
            server: The VPN server address (FQDN or IP).
            user: The username for the VPN connection.
            password: The password for the VPN connection.
            vpn_type: The type of VPN protocol (e.g., 'pptp', 'l2tp').
            
        Returns:
            True if the profile creation was successful, False otherwise.
        """

        os_type = self.os_type
        
        # --- Security Note: Credentials should be handled securely in production ---

        print(f"Attempting to create VPN profile '{profile_name}' on {os_type}...")

        try:
            if os_type == "Linux":
                # Uses NetworkManager's nmcli. Commands are passed as lists of arguments 
                # for security (avoiding shell=True).
                
                # 1. Add the connection
                cmd_add = [
                    "sudo","nmcli", "connection", "add", 
                    "type", "vpn", 
                    "con-name", profile_name, 
                    "ifname", "*", 
                    "vpn-type", vpn_type
                ]
                
                # Using stdout=subprocess.PIPE and stderr=subprocess.PIPE for capturing output
                result_add = subprocess.run(cmd_add, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                print(f"   Connection added: {result_add.stdout.decode().strip()}")
                
                # 2. Configure the connection settings (server/gateway)
                cmd_server = [
                    "sudo","nmcli", "connection", "modify", profile_name, 
                    "vpn-settings.gateway", server
                ]
                subprocess.run(cmd_server, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

                # 3. Configure the credentials 
                cmd_credentials = [
                    "sudo","nmcli", "connection", "modify", profile_name, 
                    "vpn-secrets.password", password,
                    "vpn-settings.user", user
                ]
                subprocess.run(cmd_credentials, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                print(f"✅ Successfully created VPN profile '{profile_name}' using nmcli.")
                return True

            elif os_type == "Windows":
                # Uses PowerShell commands to create a VPN connection (e.g., using PPTP)
                
                # The Add-VpnConnection cmdlet is the modern way in Windows.
                # We must use proper quoting within the PowerShell command string.
                ps_command = (
                    f"Add-VpnConnection -Name \"{profile_name}\" -ServerAddress \"{server}\" "
                    f"-TunnelType {vpn_type.upper()} -AuthenticationMethod MSCHAPv2 -Force"
                )
                
                # Executing PowerShell commands via subprocess.run, passing the command string
                # to the '-Command' argument of powershell.exe.
                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command], 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE,
                    shell=False # Crucial to maintain security
                )
                
                print(f"✅ Successfully created VPN profile '{profile_name}' on Windows.")
                return True

            else:
                print(f"❌ Error: Unsupported operating system: {os_type}")
                return False

        except subprocess.CalledProcessError as e:
            print(f"❌ ERROR executing OS command for {os_type}:")
            # Decode and print error messages
            if e.stderr:
                print(f"   Stderr: {e.stderr.decode().strip()}")
            if e.stdout:
                print(f"   Stdout: {e.stdout.decode().strip()}")
            return False
        except Exception as e:
            print(f"❌ An unexpected error occurred: {e}")
            return False

    def connect_vpn(self,profile_name):
        """
        Connects to an existing VPN connection profile across platforms.
        
        Args:
            profile_name: The name of the VPN connection profile to activate.
            
        Returns:
            True if the connection was successfully initiated, False otherwise.
        """

        os_type = self.os_type
        
        print(f"Attempting to connect to VPN profile '{profile_name}' on {os_type}...")

        try:
            if os_type == "Linux":
                # Uses NetworkManager's nmcli to activate the connection
                # Command: nmcli connection up 'profile_name'
                cmd = [
                    "sudo","nmcli", "connection", "up", 
                    profile_name
                ]
                
                # Using stdout/stderr PIPE for capturing output without external modules
                result = subprocess.run(
                    cmd, 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE
                )
                
                # nmcli outputs status updates to stdout/stderr. Check the output for confirmation.
                output = result.stdout.decode().strip() or result.stderr.decode().strip()
                if "successfully activated" in output.lower():
                    print(f"✅ Successfully connected to VPN profile '{profile_name}' via nmcli.")
                    return True
                else:
                    # If check=True passed, it means connection was initiated, but we print more info
                    print(f"⚠️ Connection initiated, but status uncertain. Output: {output}")
                    return True # Treat initiation as success unless 'check=True' failed

            elif os_type == "Windows":
                # Uses PowerShell's RasDial for connections (standard for Windows VPN profiles)
                
                # Command: Start-VpnConnection -Name "profile_name"
                # Note: This requires the profile to be managed by the native Windows VPN client.
                ps_command = (
                    f"Start-VpnConnection -Name \"{profile_name}\""
                )
                
                # Executing PowerShell commands
                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command], 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE,
                    shell=False
                )
                
                # On Windows, success means the command completed without error (check=True)
                print(f"✅ Successfully initiated connection to VPN profile '{profile_name}' on Windows.")
                return True

            else:
                print(f"❌ Error: Unsupported operating system: {os_type}")
                return False

        except subprocess.CalledProcessError as e:
            print(f"❌ ERROR connecting via OS command for {os_type}:")
            # Decode and print error messages
            if e.stderr:
                print(f"   Stderr: {e.stderr.decode().strip()}")
            if e.stdout:
                print(f"   Stdout: {e.stdout.decode().strip()}")
            # Check for specific errors like 'already active' which might be acceptable
            if "already active" in e.stderr.decode().lower() or "already connected" in e.stdout.decode().lower():
                print(f"⚠️ Warning: Profile '{profile_name}' appears to be already connected.")
                return True # Treat already connected as a successful state
            return False
            
        except Exception as e:
            print(f"❌ An unexpected error occurred: {e}")
            return False
    def disconnect_vpn(self,profile_name):
        """
        Disconnects an active VPN connection profile across platforms.
        
        Args:
            profile_name: The name of the VPN connection profile to deactivate.
            
        Returns:
            True if the disconnection was successful or the VPN was already inactive, False otherwise.
        """

        os_type = self.os_type
        
        print(f"Attempting to disconnect VPN profile '{profile_name}' on {os_type}...")

        try:
            if os_type == "Linux":
                # Command: sudo nmcli connection down 'profile_name'
                cmd = [
                    "sudo", "nmcli", "connection", "down", 
                    profile_name
                ]
                
                result = subprocess.run(
                    cmd, 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE
                )
                
                output = result.stdout.decode().strip() or result.stderr.decode().strip()
                
                # Check if the connection was successfully deactivated
                if "successfully deactivated" in output.lower() or "not active" in output.lower():
                    print(f"✅ Successfully disconnected or profile '{profile_name}' was already inactive.")
                    return True
                else:
                    print(f"⚠️ Disconnection command executed, but status uncertain. Output: {output}")
                    return True

            elif os_type == "Windows":
                # Uses PowerShell's Stop-VpnConnection
                
                # Command: Stop-VpnConnection -Name "profile_name" -Force
                # The '-Force' parameter ensures the command runs without confirmation prompts.
                ps_command = (
                    f"Stop-VpnConnection -Name \"{profile_name}\" -Force"
                )
                
                # Executing PowerShell commands. Running Stop-VpnConnection when the VPN 
                # is already disconnected typically returns an error, which we handle below.
                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command], 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE,
                    shell=False
                )
                
                print(f"✅ Successfully disconnected VPN profile '{profile_name}' on Windows.")
                return True

            else:
                print(f"❌ Error: Unsupported operating system: {os_type}")
                return False

        except subprocess.CalledProcessError as e:
            error_output = e.stderr.decode().strip().lower()
            
            # Windows/Linux check for "already disconnected" or "not found"
            if "not active" in error_output or "no connection with name" in error_output:
                print(f"⚠️ Warning: Profile '{profile_name}' was not active or found. Treating as successful disconnect.")
                return True
            elif "vpn connection is not active" in error_output: # Windows specific message
                print(f"⚠️ Warning: Profile '{profile_name}' was not active. Treating as successful disconnect.")
                return True
            else:
                print(f"❌ ERROR disconnecting via OS command for {os_type}:")
                print(f"   Stderr: {e.stderr.decode().strip()}")
                return False
            
        except Exception as e:
            print(f"❌ An unexpected error occurred: {e}")
            return False

    def check_vpn_status(self,profile_name):
        """
        Checks the status of a specific VPN connection profile across platforms,
        providing both an attractive console output and a standardized return status.
        
        Args:
            profile_name: The name of the VPN connection profile to check.
            
        Returns:
            A standardized string status (e.g., "CONNECTED", "DISCONNECTED", "ERROR").
        """

        os_type = self.os_type
        status = "UNKNOWN"
        details = {}
        
        # --- Attractive Output Initialization ---
        print("\n" + "="*50)
        print(f"📡 VNAS DIAGNOSTICS: VPN Profile Status Check")
        print("="*50)
        print(f"🔍 Profile Name: {profile_name}")
        print(f"💻 Operating System: {os_type}")
        print("-" * 50)


        try:
            if os_type == "Linux":
                # Command: sudo nmcli connection show "profile_name"
                cmd_show = ["sudo", "nmcli", "connection", "show", profile_name]
                
                result = subprocess.run(
                    cmd_show, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                
                output = result.stdout.decode().strip()
                error_output = result.stderr.decode().strip()

                if result.returncode != 0:
                    if "connection with name" in error_output:
                        status = "NOT_CONFIGURED"
                    else:
                        status = "ERROR_QUERYING"
                else:
                    # Parse nmcli output for professional details
                    for line in output.split('\n'):
                        if ':' in line:
                            key, value = line.split(':', 1)
                            key = key.strip().upper().replace('.', '_')
                            value = value.strip()
                            details[key] = value
                    
                    # Determine status from parsed data
                    raw_state = details.get('GENERAL_STATE', '').lower()
                    
                    if 'activated' in raw_state:
                        status = "CONNECTED"
                    elif 'deactivated' in raw_state:
                        status = "DISCONNECTED"
                    elif 'connecting' in raw_state:
                        status = "CONNECTING"
                    else:
                        status = "DISCONNECTED" # Default if state is ambiguous

            elif os_type == "Windows":
                # Command: Get-VpnConnection -Name "profile_name" | Select-Object Name, ServerAddress, ConnectionStatus, ...
                # Using Select-Object to get structured data
                ps_command = (
                    f"(Get-VpnConnection -Name \"{profile_name}\" -ErrorAction SilentlyContinue | "
                    f"Select-Object Name, ServerAddress, ConnectionStatus, TunnelType, DnsSuffix) | "
                    f"Format-List"
                )
                
                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command], 
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )
                
                output = result.stdout.decode().strip()
                
                if not output or "cannot find" in result.stderr.decode().lower():
                    status = "NOT_CONFIGURED"
                else:
                    # Parse PowerShell output for professional details
                    current_status = ""
                    for line in output.split('\n'):
                        if ':' in line:
                            key, value = line.split(':', 1)
                            details[key.strip()] = value.strip()
                            if "ConnectionStatus" in key:
                                current_status = value.strip().upper()

                    if "CONNECTED" in current_status:
                        status = "CONNECTED"
                    elif "DISCONNECTED" in current_status:
                        status = "DISCONNECTED"
                    elif "CONNECTING" in current_status or "AUTHENTICATING" in current_status:
                        status = "CONNECTING"
                    else:
                        status = "UNKNOWN_STATE"

            else:
                status = "UNSUPPORTED_OS"
                
        except Exception as e:
            status = f"FATAL_ERROR"
            details['Error Message'] = str(e)

        # --- Attractive Output Display Logic ---
        
        emoji_map = {
            "CONNECTED": "🟢 ACTIVE",
            "DISCONNECTED": "🔴 INACTIVE",
            "CONNECTING": "🟡 PENDING",
            "NOT_CONFIGURED": "⚪️ MISSING",
            "ERROR_QUERYING": "❌ FAILED",
            "FATAL_ERROR": "🚨 CRASHED",
            "UNKNOWN_STATE": "❓ UNKNOWN"
        }
        
        display_status = emoji_map.get(status, f"❓ {status}")
        
        print(f"⭐️ **VPN STATUS:** {display_status}")
        
        # Professional Data Display
        if status not in ["NOT_CONFIGURED", "ERROR_QUERYING", "FATAL_ERROR", "UNSUPPORTED_OS"]:
            print("-" * 50)
            print("📊 **Connection Details (For Professionals):**")
            
            # Prioritize key VNAS data points
            key_data = {}
            if os_type == "Linux":
                key_data["VPN Type"] = details.get('VPN_VPN_TYPE', details.get('VPN_TYPE', 'N/A'))
                key_data["Server (Gateway)"] = details.get('VPN_SETTINGS_GATEWAY', 'N/A')
                key_data["Interface"] = details.get('GENERAL_DEVICE', 'N/A')
                key_data["IP Address"] = details.get('IP4_ADDRESS', 'N/A').split()[0] if 'IP4_ADDRESS' in details else 'N/A'
            
            elif os_type == "Windows":
                key_data["VPN Type"] = details.get('TunnelType', 'N/A')
                key_data["Server Address"] = details.get('ServerAddress', 'N/A')
                key_data["DNS Suffix"] = details.get('DnsSuffix', 'N/A')

            # Print organized details
            for key, value in key_data.items():
                if value and value != 'N/A':
                    print(f"  > {key:<18}: {value}")
                    
            print("-" * 50)
        
        if "ERROR" in status or "FATAL" in status:
            print(f"🛑 **ADMIN NOTE:** Review system logs for more details.")

        print("="*50)

        # Return standardized string for VNAS system integration
        return status
    def list_all_vpn_profiles(self):
        """
        Retrieves and displays a list of all configured VPN profiles.
        
        Returns:
            A list of dictionaries containing profile data (Name, Type, Status), 
            or an empty list on failure.
        """

        os_type = self.os_type
        profile_data = []

        # --- Attractive Output Initialization ---
        print("\n" + "═" * 70)
        print("📋 VNAS ADMINISTRATION: VPN Profile List")
        print("═" * 70)
        print(f"💻 Operating System: {os_type}")
        print("-" * 70)

        try:
            if os_type == "Linux":
                # nmcli connection show --active lists only active connections.
                # nmcli connection show --vpn lists all VPN connections.
                # Using 'sudo' for full visibility into system-wide connections.
                cmd_show = ["sudo", "nmcli", "--terse", "connection", "show"]
                
                result = subprocess.run(
                    cmd_show, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                
                output = result.stdout.decode().strip()
                
                for line in output.split('\n'):
                    if not line:
                        continue
                    # Format: NAME:TYPE:GENERAL.STATE
                    parts = line.split(':')
                    if len(parts) >= 3:
                        name = parts[0]
                        # Check if connection is active
                        status = "CONNECTED" if parts[2].lower() == 'activated' else "DISCONNECTED"
                        
                        profile_data.append({
                            "Name": name,
                            "Type": parts[1].upper(),
                            "Status": status
                        })

            elif os_type == "Windows":
                # Command: Get-VpnConnection | Select-Object Name, TunnelType, ConnectionStatus
                # Using -AllUserConnection for full system visibility, and formatting as a list for easy parsing
                ps_command = (
                    f"(Get-VpnConnection -AllUserConnection -ErrorAction SilentlyContinue | "
                    f"Select-Object Name, TunnelType, ConnectionStatus, ServerAddress) | "
                    f"Format-List"
                )
                
                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command], 
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )
                
                output = result.stdout.decode().strip()
                
                # Windows PowerShell output parsing (parsing multi-line list format)
                current_profile = {}
                for line in output.split('\n'):
                    if not line.strip():
                        if current_profile and 'Name' in current_profile:
                            # Process completed profile block
                            name = current_profile['Name']
                            status_raw = current_profile.get('ConnectionStatus', 'Disconnected').upper()
                            
                            status = "CONNECTED" if "CONNECTED" in status_raw else "DISCONNECTED"
                            
                            profile_data.append({
                                "Name": name,
                                "Type": current_profile.get('TunnelType', 'UNKNOWN').upper(),
                                "Status": status
                            })
                            current_profile = {}
                        continue
                    
                    if ':' in line:
                        key, value = line.split(':', 1)
                        current_profile[key.strip()] = value.strip()
                
                # Catch the last profile if the file didn't end with a newline
                if current_profile and 'Name' in current_profile:
                    name = current_profile['Name']
                    status_raw = current_profile.get('ConnectionStatus', 'Disconnected').upper()
                    status = "CONNECTED" if "CONNECTED" in status_raw else "DISCONNECTED"
                    profile_data.append({
                        "Name": name,
                        "Type": current_profile.get('TunnelType', 'UNKNOWN').upper(),
                        "Status": status
                    })


            else:
                print(f"❌ Error: Unsupported operating system: {os_type}")
                return []

        except subprocess.CalledProcessError as e:
            print(f"❌ ERROR executing OS command for {os_type}.")
            print(f"   Stderr: {e.stderr.decode().strip()}")
            return []
            
        except Exception as e:
            print(f"❌ An unexpected error occurred: {e}")
            return []

        # --- Attractive Output Display ---
        
        if not profile_data:
            print("⚠️ **NO PROFILES FOUND:** The system does not have any configured VPN profiles.")
            print("-" * 70)
            return []

        print(f"📚 **Total Profiles Found:** {len(profile_data)}")
        print("-" * 70)
        
        # Define Column Widths
        # Max widths for fixed columns: Name (25), Type (10), Status (15)
        name_width = 25
        type_width = 10
        status_width = 15
        
        # Print Table Header
        header = f"| {'PROFILE NAME':<{name_width}} | {'TYPE':<{type_width}} | {'STATUS':<{status_width}} |"
        print(header)
        print("|" + "-" * (name_width + 2) + "|" + "-" * (type_width + 2) + "|" + "-" * (status_width + 2) + "|")

        # Print Rows
        for profile in profile_data:
            status_display = profile['Status']
            
            # Add Emojis for Beginner-friendly status
            if status_display == "CONNECTED":
                status_display = "🟢 CONNECTED"
            elif status_display == "DISCONNECTED":
                status_display = "🔴 DISCONNECTED"
            elif status_display == "CONNECTING":
                status_display = "🟡 PENDING"
            
            row = f"| {profile['Name']:<{name_width}} | {profile['Type']:<{type_width}} | {status_display:<{status_width}} |"
            print(row)

        print("═" * 70)
        
        # Return professional list of dicts for VNAS system integration
        return profile_data
    def delete_vpn_profile(self,profile_name):
        """
        Deletes an existing VPN connection profile across platforms.
        
        Args:
            profile_name: The name of the VPN connection profile to delete.
            
        Returns:
            True if the profile was successfully deleted or was not found, False otherwise.
        """

        os_type = self.os_type
        
        print("\n" + "═" * 50)
        print(f"🗑️ VNAS ADMINISTRATION: Delete VPN Profile")
        print("═" * 50)
        print(f"Attempting to delete profile '{profile_name}' on {os_type}...")

        # --- Pre-check and Disconnect (Idempotency) ---
        # For safe deletion, we attempt to disconnect the profile first. 
        # This prevents the OS from holding resources tied to a deleted profile.
        
        try:
            # NOTE: Using a simplified check without fully replicating disconnect_vpn function
            if os_type == "Linux":
                # Attempt to disconnect. Use check=False as it may already be down.
                subprocess.run(
                    ["sudo", "nmcli", "connection", "down", profile_name], 
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
            elif os_type == "Windows":
                # Attempt to stop the connection
                subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', f"Stop-VpnConnection -Name \"{profile_name}\" -Force"], 
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )
            
            print("Pre-deletion check: Connection deactivated (if active). Proceeding to delete.")

        except Exception as e:
            print(f"⚠️ Warning during pre-deletion disconnect: {e}")
            # Continue to deletion attempt even with warning

        # --- Deletion Command Execution ---
        try:
            if os_type == "Linux":
                # Command: sudo nmcli connection delete 'profile_name'
                cmd = [
                    "sudo", "nmcli", "connection", "delete", 
                    profile_name
                ]
                
                result = subprocess.run(
                    cmd, 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE
                )
                
                output = result.stdout.decode().strip() or result.stderr.decode().strip()
                
                # nmcli usually outputs the UUID of the deleted connection upon success
                if "successfully deleted" in output.lower() or "deleted" in output.lower():
                    print(f"✅ Successfully deleted VPN profile '{profile_name}' using nmcli.")
                    return True
                else:
                    # Fallback check, though check=True should handle most failures
                    print(f"⚠️ Deletion command executed, but status uncertain. Output: {output}")
                    return True

            elif os_type == "Windows":
                # Uses PowerShell's Remove-VpnConnection
                
                # Command: Remove-VpnConnection -Name "profile_name" -Force
                # The '-Force' ensures removal without confirmation.
                ps_command = (
                    f"Remove-VpnConnection -Name \"{profile_name}\" -Force"
                )
                
                # Executing PowerShell commands. 
                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command], 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE,
                    shell=False
                )
                
                print(f"✅ Successfully deleted VPN profile '{profile_name}' on Windows.")
                return True

            else:
                print(f"❌ Error: Unsupported operating system: {os_type}")
                return False

        except subprocess.CalledProcessError as e:
            error_output = e.stderr.decode().strip().lower()
            
            # Windows/Linux check for "not found" or "does not exist"
            if "no connection with name" in error_output or "cannot find" in error_output or "does not exist" in error_output:
                print(f"⚠️ Warning: Profile '{profile_name}' was not found. Treating as successful deletion (idempotent).")
                return True
            else:
                print(f"❌ ERROR executing deletion command for {os_type}:")
                print(f"   Stderr: {e.stderr.decode().strip()}")
                return False
            
        except Exception as e:
            print(f"❌ An unexpected error occurred: {e}")
            return False
        
        finally:
            print("═" * 50)

    #======================PHASE 5 USERADMINISTRATION ================
    def create_user(self,username, password=None):
        """
        Creates a new system user across Windows and Linux platforms.
        
        Args:
            username: The name of the new user to be created.
            password: An optional password for the new account.
            
        Returns:
            Standardized status string: "SUCCESS", "USER_EXISTS", or "FAILED".
        """
        os_type = self.os_type
        status = "UNKNOWN"
        professional_logs = []

        print("\n" + "═" * 60)
        print(f"👤 USERADMIN: Create New System Account")
        print("═" * 60)
        print(f"🔹 Target Username : {username}")
        print(f"🔹 Host Platform   : {os_type}")
        print("-" * 60)

        try:
            if os_type == "Linux":
                # Command: sudo useradd -m <username>
                # -m ensures a home directory is created
                cmd_create = ["sudo", "useradd", "-m", username]
                
                result = subprocess.run(
                    cmd_create, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )

                if result.returncode == 0:
                    professional_logs.append(f"System: User '{username}' created with home directory /home/{username}")
                    
                    # Set password if provided
                    if password:
                        # Linux uses chpasswd for non-interactive password setting
                        pass_input = f"{username}:{password}"
                        cmd_pass = ["sudo", "chpasswd"]
                        pass_res = subprocess.run(
                            cmd_pass, input=pass_input.encode(), check=False, 
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE
                        )
                        if pass_res.returncode == 0:
                            professional_logs.append("Security: Password successfully hashed and applied.")
                        else:
                            professional_logs.append(f"Security Warning: User created but password failed: {pass_res.stderr.decode().strip()}")
                    
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "already exists" in err:
                        status = "USER_EXISTS"
                    else:
                        status = "FAILED"
                        professional_logs.append(f"Error Log: {err}")

            elif os_type == "Windows":
                # Using PowerShell New-LocalUser
                # We convert the plain text password to a SecureString for Windows security compliance
                if password:
                    ps_command = (
                        f"$pass = ConvertTo-SecureString '{password}' -AsPlainText -Force; "
                        f"New-LocalUser -Name '{username}' -Password $pass -Description 'Created via VNAS' "
                        f"-ErrorAction Stop"
                    )
                else:
                    ps_command = f"New-LocalUser -Name '{username}' -NoPassword -ErrorAction Stop"

                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command],
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )

                if result.returncode == 0:
                    professional_logs.append(f"Registry: Local user '{username}' added to SAM database.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "already exists" in err:
                        status = "USER_EXISTS"
                    else:
                        status = "FAILED"
                        professional_logs.append(f"PS Error: {err}")

        except Exception as e:
            status = "CRITICAL_ERROR"
            professional_logs.append(f"Exception: {str(e)}")

        # --- Attractive & Professional Output ---
        emoji_map = {
            "SUCCESS": "🟢 CREATED",
            "USER_EXISTS": "🟡 ALREADY EXISTS",
            "FAILED": "🔴 FAILED",
            "CRITICAL_ERROR": "🚨 SYSTEM ERROR"
        }

        display_status = emoji_map.get(status, f"❓ {status}")
        print(f"⭐️ **RESULT:** {display_status}")

        if professional_logs:
            print("-" * 60)
            print("📊 **Technical Audit Log:**")
            for log in professional_logs:
                print(f"  [LOG] {log}")

        print("═" * 60)
        return status
    
    def delete_user(self,username):
        """
        Permanently removes a system user account across Windows and Linux.
        
        Args:
            username: The name of the user to be deleted.
            
        Returns:
            Standardized status string: "SUCCESS", "USER_NOT_FOUND", or "FAILED".
        """
        os_type = self.os_type
        status = "UNKNOWN"
        tech_details = []

        print("\n" + "═" * 60)
        print(f"🗑️ USERADMIN: Remove System Account")
        print("═" * 60)
        print(f"🔹 Target Username : {username}")
        print(f"🔹 Host Platform   : {os_type}")
        print("-" * 60)

        try:
            if os_type == "Linux":
                # Command: sudo userdel -r <username>
                # -r removes the home directory and mail spool as well (Clean deletion)
                cmd_delete = ["sudo", "userdel", "-r", username]
                
                result = subprocess.run(
                    cmd_delete, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )

                if result.returncode == 0:
                    tech_details.append(f"System: User '{username}' and home directory purged.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "does not exist" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        tech_details.append(f"OS Error: {err}")

            elif os_type == "Windows":
                # Using PowerShell Remove-LocalUser
                ps_command = f"Remove-LocalUser -Name '{username}' -ErrorAction Stop"

                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command],
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )

                if result.returncode == 0:
                    tech_details.append(f"Registry: SID for '{username}' removed from SAM database.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "not found" in err or "does not exist" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        tech_details.append(f"PS Error Log: {err}")

            else:
                status = "UNSUPPORTED_OS"

        except Exception as e:
            status = "CRITICAL_ERROR"
            tech_details.append(f"Exception: {str(e)}")

        # --- Attractive & Professional Output ---
        emoji_map = {
            "SUCCESS": "🟢 DELETED SUCCESSFULLY",
            "USER_NOT_FOUND": "🟡 USER NOT FOUND (NO ACTION)",
            "FAILED": "🔴 DELETION FAILED",
            "CRITICAL_ERROR": "🚨 SYSTEM EXCEPTION"
        }

        display_status = emoji_map.get(status, f"❓ {status}")
        print(f"⭐️ **RESULT:** {display_status}")

        if tech_details:
            print("-" * 60)
            print("📊 **Technical Audit Log:**")
            for detail in tech_details:
                print(f"  [LOG] {detail}")

        print("═" * 60)
        return status   
    def change_password(self,username, new_password):
        """
        Updates the password for an existing system user across Windows and Linux.
        
        Args:
            username: The name of the target user.
            new_password: The new password to be set.
            
        Returns:
            Standardized status string: "SUCCESS", "USER_NOT_FOUND", or "FAILED".
        """
        os_type = self.os_type
        status = "UNKNOWN"
        audit_logs = []

        print("\n" + "═" * 60)
        print(f"🔐 USERADMIN: Update User Credentials")
        print("═" * 60)
        print(f"🔹 Target Username : {username}")
        print(f"🔹 Host Platform   : {os_type}")
        print("-" * 60)

        try:
            if os_type == "Linux":
                # Command: echo 'username:password' | sudo chpasswd
                # chpasswd is optimized for batch processing and is non-interactive.
                pass_input = f"{username}:{new_password}"
                cmd = ["sudo", "chpasswd"]
                
                result = subprocess.run(
                    cmd, input=pass_input.encode(), check=False, 
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )

                if result.returncode == 0:
                    audit_logs.append(f"Security: Password updated in /etc/shadow for '{username}'.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "unknown user" in err or "not found" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Linux Error: {err}")

            elif os_type == "Windows":
                # Using PowerShell to convert plain text to SecureString and set password.
                # $pass = ConvertTo-SecureString ... ; Set-LocalUser -Name ... -Password $pass
                ps_command = (
                    f"$pass = ConvertTo-SecureString '{new_password}' -AsPlainText -Force; "
                    f"Set-LocalUser -Name '{username}' -Password $pass -ErrorAction Stop"
                )

                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command],
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )

                if result.returncode == 0:
                    audit_logs.append(f"Security: SAM database updated for '{username}'.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "not found" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Windows PS Error: {err}")

            else:
                status = "UNSUPPORTED_OS"

        except Exception as e:
            status = "CRITICAL_ERROR"
            audit_logs.append(f"Exception: {str(e)}")

        # --- Attractive & Professional Output ---
        emoji_map = {
            "SUCCESS": "🟢 PASSWORD UPDATED",
            "USER_NOT_FOUND": "🟡 USER NOT FOUND",
            "FAILED": "🔴 UPDATE FAILED",
            "CRITICAL_ERROR": "🚨 SYSTEM ERROR"
        }

        display_status = emoji_map.get(status, f"❓ {status}")
        print(f"⭐️ **RESULT:** {display_status}")

        if audit_logs:
            print("-" * 60)
            print("📊 **Technical Security Log:**")
            for log in audit_logs:
                print(f"  [LOG] {log}")

        print("═" * 60)
        return status
    def assign_group(self,username, groupname):
        """
        Assigns an existing system user to a specific group across Windows and Linux.
        
        Args:
            username: The name of the target user.
            groupname: The name of the group to add the user to.
            
        Returns:
            Standardized status string: "SUCCESS", "NOT_FOUND", or "FAILED".
        """
        os_type = self.os_type
        status = "UNKNOWN"
        audit_logs = []

        print("\n" + "═" * 60)
        print(f"👥 USERADMIN: Assign User to Group")
        print("═" * 60)
        print(f"🔹 Target Username : {username}")
        print(f"🔹 Target Group    : {groupname}")
        print(f"🔹 Host Platform   : {os_type}")
        print("-" * 60)

        try:
            if os_type == "Linux":
                # Command: sudo usermod -aG <groupname> <username>
                # -aG appends the user to the group without removing them from others.
                cmd = ["sudo", "usermod", "-aG", groupname, username]
                
                result = subprocess.run(
                    cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )

                if result.returncode == 0:
                    audit_logs.append(f"System: User '{username}' added to supplementary group '{groupname}'.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "does not exist" in err:
                        status = "NOT_FOUND"
                        audit_logs.append(f"Error: Either user or group was not found on the system.")
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Linux Error: {err}")

            elif os_type == "Windows":
                # Using PowerShell Add-LocalGroupMember.
                ps_command = (
                    f"Add-LocalGroupMember -Group '{groupname}' -Member '{username}' -ErrorAction Stop"
                )

                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command],
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )

                if result.returncode == 0:
                    audit_logs.append(f"Registry: LocalGroupMember updated for '{groupname}'.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "does not exist" in err:
                        status = "NOT_FOUND"
                    elif "already a member" in err:
                        status = "SUCCESS" # Idempotent success
                        audit_logs.append("Note: User was already a member of this group.")
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Windows PS Error: {err}")

            else:
                status = "UNSUPPORTED_OS"

        except Exception as e:
            status = "CRITICAL_ERROR"
            audit_logs.append(f"Exception: {str(e)}")

        # --- Attractive & Professional Output ---
        emoji_map = {
            "SUCCESS": "🟢 GROUP ASSIGNED",
            "NOT_FOUND": "🟡 USER/GROUP NOT FOUND",
            "FAILED": "🔴 ASSIGNMENT FAILED",
            "CRITICAL_ERROR": "🚨 SYSTEM ERROR"
        }

        display_status = emoji_map.get(status, f"❓ {status}")
        print(f"⭐️ **RESULT:** {display_status}")

        if audit_logs:
            print("-" * 60)
            print("📊 **Technical Membership Log:**")
            for log in audit_logs:
                print(f"  [LOG] {log}")

        print("═" * 60)
        return status
    def lock_account(self,username):
        """
        Disables/Locks a system user account across Windows and Linux.
        
        Args:
            username: The name of the user account to lock.
            
        Returns:
            Standardized status string: "SUCCESS", "USER_NOT_FOUND", or "FAILED".
        """
        os_type = self.os_type
        status = "UNKNOWN"
        audit_logs = []

        print("\n" + "═" * 60)
        print(f"🔒 USERADMIN: Lock/Disable Account")
        print("═" * 60)
        print(f"🔹 Target Username : {username}")
        print(f"🔹 Host Platform   : {os_type}")
        print("-" * 60)

        try:
            if os_type == "Linux":
                # Command: sudo usermod --lock <username>
                # This 'locks' the password, preventing login.
                cmd = ["sudo", "usermod", "--lock", username]
                
                result = subprocess.run(
                    cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )

                if result.returncode == 0:
                    audit_logs.append(f"Security: User '{username}' password locked in /etc/shadow.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "does not exist" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Linux Error: {err}")

            elif os_type == "Windows":
                # Using PowerShell Disable-LocalUser.
                ps_command = f"Disable-LocalUser -Name '{username}' -ErrorAction Stop"

                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command],
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )

                if result.returncode == 0:
                    audit_logs.append(f"Registry: Account object for '{username}' set to Disabled.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "not found" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Windows PS Error: {err}")

            else:
                status = "UNSUPPORTED_OS"

        except Exception as e:
            status = "CRITICAL_ERROR"
            audit_logs.append(f"Exception: {str(e)}")

        # --- Attractive & Professional Output ---
        emoji_map = {
            "SUCCESS": "🟢 ACCOUNT LOCKED",
            "USER_NOT_FOUND": "🟡 USER NOT FOUND",
            "FAILED": "🔴 LOCK FAILED",
            "CRITICAL_ERROR": "🚨 SYSTEM ERROR"
        }

        display_status = emoji_map.get(status, f"❓ {status}")
        print(f"⭐️ **RESULT:** {display_status}")

        if audit_logs:
            print("-" * 60)
            print("📊 **Technical Security Log:**")
            for log in audit_logs:
                print(f"  [LOG] {log}")

        print("═" * 60)
        return status
    def unlock_account(self,username):
        """
        Re-enables/Unlocks a system user account across Windows and Linux.
        
        Args:
            username: The name of the user account to unlock.
            
        Returns:
            Standardized status string: "SUCCESS", "USER_NOT_FOUND", or "FAILED".
        """
        os_type = self.os_type
        status = "UNKNOWN"
        audit_logs = []

        print("\n" + "═" * 60)
        print(f"🔓 USERADMIN: Unlock/Enable Account")
        print("═" * 60)
        print(f"🔹 Target Username : {username}")
        print(f"🔹 Host Platform   : {os_type}")
        print("-" * 60)

        try:
            if os_type == "Linux":
                # Command: sudo usermod --unlock <username>
                # This removes the '!' lock from the password field.
                cmd = ["sudo", "usermod", "--unlock", username]
                
                result = subprocess.run(
                    cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )

                if result.returncode == 0:
                    audit_logs.append(f"Security: Password lock removed for '{username}' in /etc/shadow.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "does not exist" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Linux Error: {err}")

            elif os_type == "Windows":
                # Using PowerShell Enable-LocalUser.
                ps_command = f"Enable-LocalUser -Name '{username}' -ErrorAction Stop"

                result = subprocess.run(
                    ['powershell.exe', '-NoProfile', '-Command', ps_command],
                    check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False
                )

                if result.returncode == 0:
                    audit_logs.append(f"Registry: Account object for '{username}' set to Enabled.")
                    status = "SUCCESS"
                else:
                    err = result.stderr.decode().strip().lower()
                    if "not found" in err:
                        status = "USER_NOT_FOUND"
                    else:
                        status = "FAILED"
                        audit_logs.append(f"Windows PS Error: {err}")

            else:
                status = "UNSUPPORTED_OS"

        except Exception as e:
            status = "CRITICAL_ERROR"
            audit_logs.append(f"Exception: {str(e)}")

        # --- Attractive & Professional Output ---
        emoji_map = {
            "SUCCESS": "🟢 ACCOUNT UNLOCKED",
            "USER_NOT_FOUND": "🟡 USER NOT FOUND",
            "FAILED": "🔴 UNLOCK FAILED",
            "CRITICAL_ERROR": "🚨 SYSTEM ERROR"
        }

        display_status = emoji_map.get(status, f"❓ {status}")
        print(f"⭐️ **RESULT:** {display_status}")

        if audit_logs:
            print("-" * 60)
            print("📊 **Technical Recovery Log:**")
            for log in audit_logs:
                print(f"  [LOG] {log}")

        print("═" * 60)
        return status
    def view_active_users(self):
        """
        Lists all currently logged-in users across Windows and Linux.
        
        Returns:
            A list of active usernames or an empty list if none/error.
        """
        os_type = self.os_type
        active_users = []
        
        print("\n" + "═" * 70)
        print(f"👥 USERADMIN: Active Session Monitor")
        print("═" * 70)
        print(f"💻 Host Platform: {os_type}")
        print("-" * 70)

        try:
            if os_type == "Linux":
                # Command: who -u (Lists users, their terminals, and login time)
                cmd = ["who", "-u"]
                result = subprocess.run(cmd, capture_output=True, text=True, check=False)
                
                if result.returncode == 0 and result.stdout.strip():
                    print(f"{'USER':<15} {'TTY':<10} {'LOGIN TIME':<20} {'IDLE':<10}")
                    print("-" * 70)
                    for line in result.stdout.strip().split('\n'):
                        parts = line.split()
                        if len(parts) >= 4:
                            user, tty, date, time = parts[0], parts[1], parts[2], parts[3]
                            idle = parts[4] if len(parts) > 4 else "."
                            print(f"{user:<15} {tty:<10} {date} {time:<10} {idle:<10}")
                            active_users.append(user)
                else:
                    print("ℹ️ No active interactive sessions found.")

            elif os_type == "Windows":
                # Command: query user
                # This is the most reliable way to see active RDP and local sessions
                result = subprocess.run(
                    ["query", "user"], capture_output=True, text=True, check=False
                )

                if result.returncode == 0 and result.stdout.strip():
                    # The 'query user' output has a specific header format
                    lines = result.stdout.strip().split('\n')
                    print(lines[0]) # Print Header
                    print("-" * 70)
                    for line in lines[1:]:
                        print(line)
                        # Extract username (usually the first part of the string)
                        user = line.split()[0].replace('>', '') # Remove active indicator
                        active_users.append(user)
                else:
                    # Fallback: Just show local users who are enabled if query user fails
                    print("ℹ️ No active sessions detected via 'query user'.")

        except Exception as e:
            print(f"❌ Error querying active users: {e}")

        print("-" * 70)
        print(f"📊 **SUMMARY:** Total Active Sessions: {len(active_users)}")
        print("═" * 70)
        
        return active_users
    def user_info(self,username):
        """
        Displays comprehensive details of a specific system user.
        """
        os_type = self.os_type
        print("\n" + "═" * 60)
        print(f"👤 USER_INFO: Detailed Account Metadata")
        print("═" * 60)
        
        try:
            if os_type == "Linux":
                # Command: id <username> and finger (if available) or parsing /etc/passwd
                # We'll use 'id' and 'getent passwd' for maximum compatibility
                cmd = ["getent", "passwd", username]
                result = subprocess.run(cmd, capture_output=True, text=True, check=False)
                
                if result.returncode == 0:
                    data = result.stdout.strip().split(':')
                    # Format: name:password:UID:GID:gecos:home:shell
                    print(f"🟢 Status      : Account Found")
                    print(f"🔹 Username    : {data[0]}")
                    print(f"🔹 UID/GID     : {data[2]} / {data[3]}")
                    print(f"🔹 Home Dir    : {data[5]}")
                    print(f"🔹 Shell       : {data[6]}")
                    
                    # Get Groups
                    groups = subprocess.run(["id", "-Gn", username], capture_output=True, text=True).stdout.strip()
                    print(f"🔹 Groups      : {groups}")
                else:
                    print(f"🟡 Result      : User '{username}' not found.")

            elif os_type == "Windows":
                # Using PowerShell Get-LocalUser
                ps_cmd = f"Get-LocalUser -Name '{username}' | Select-Object Name, Enabled, PasswordLastSet, Description, SID | Format-List"
                result = subprocess.run(['powershell', '-Command', ps_cmd], capture_output=True, text=True)
                
                if result.returncode == 0:
                    print(f"🟢 Status      : Account Found")
                    print(result.stdout.strip())
                else:
                    print(f"🟡 Result      : User '{username}' not found on Windows.")

        except Exception as e:
            print(f"🚨 Error: {str(e)}")
        print("═" * 60)

    def show_logged_users(self):
        """
        Shows live active sessions on the system.
        """
        os_type = self.os_type
        print("\n" + "═" * 60)
        print(f"🛡️ SHOW_LOGGED_USERS: Active System Sessions")
        print("═" * 60)

        try:
            if os_type == "Linux":
                # Using 'w' command for a detailed view of active users
                result = subprocess.run(["w", "-h"], capture_output=True, text=True)
                if result.stdout.strip():
                    print(f"{'USER':<12} {'TTY':<10} {'FROM':<15} {'LOGIN@':<10}")
                    print("-" * 60)
                    print(result.stdout.strip())
                else:
                    print("ℹ️ No users currently logged in via terminal.")

            elif os_type == "Windows":
                # 'qwinsta' is a built-in tool to show RDP/Local sessions
                result = subprocess.run(["qwinsta"], capture_output=True, text=True)
                print(result.stdout.strip())

        except Exception as e:
            print(f"🚨 Error: {str(e)}")
        
        print("═" * 60)
    def add_group(self,group_name):
        """
        Creates a new security group on the system.
        """
        os_type = self.os_type
        print("\n" + "═" * 60)
        print(f"📁 ADD_GROUP: Creating Security Container")
        print("═" * 60)

        try:
            if os_type == "Linux":
                cmd = ["sudo", "groupadd", group_name]
                result = subprocess.run(cmd, capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"🟢 SUCCESS: Group '{group_name}' created on Linux.")
                else:
                    print(f"❌ FAILED: {result.stderr.strip()}")

            elif os_type == "Windows":
                ps_cmd = f"New-LocalGroup -Name '{group_name}'"
                result = subprocess.run(['powershell', '-Command', ps_cmd], capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"🟢 SUCCESS: Group '{group_name}' created in Windows SAM.")
                else:
                    print(f"❌ FAILED: {result.stderr.strip()}")

        except Exception as e:
            print(f"🚨 System Error: {str(e)}")
        
        print("═" * 60)

    def delete_group(self,group_name):
        """
        Removes an existing security group from the system.
        """
        os_type = self.os_type
        print("\n" + "═" * 60)
        print(f"🗑️ DELETE_GROUP: Removing Security Container")
        print("═" * 60)

        try:
            if os_type == "Linux":
                cmd = ["sudo", "groupdel", group_name]
                result = subprocess.run(cmd, capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"🟢 SUCCESS: Group '{group_name}' removed.")
                else:
                    print(f"❌ FAILED: {result.stderr.strip()}")

            elif os_type == "Windows":
                ps_cmd = f"Remove-LocalGroup -Name '{group_name}'"
                result = subprocess.run(['powershell', '-Command', ps_cmd], capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"🟢 SUCCESS: Group '{group_name}' removed from Windows.")
                else:
                    print(f"❌ FAILED: {result.stderr.strip()}")

        except Exception as e:
            print(f"🚨 System Error: {str(e)}")
        
        print("═" * 60)
        #====================Phase 6 Hardware lookup ===============
    def show_cpu_usage(self):
        """
        Monitors CPU load using psutil for high-precision data.
        Provides a beautiful dashboard and structured data for automation.
        """
        os_type = self.os_type
        
        # Fetching CPU data
        # interval=1 is recommended for an accurate reading of current usage
        overall_usage = psutil.cpu_percent(interval=1)
        per_cpu_usage = psutil.cpu_percent(interval=None, percpu=True)
        cpu_freq = psutil.cpu_freq()
        cpu_count_logical = psutil.cpu_count()
        cpu_count_physical = psutil.cpu_count(logical=False)

        print("\n" + "═" * 60)
        print(f"📊 SYSADMIN: CPU Performance Dashboard")
        print("═" * 60)

        # --- Attractive Progress Bar ---
        bar_length = 20
        filled = int(bar_length * overall_usage / 100)
        bar = "█" * filled + "░" * (bar_length - filled)
        
        # Status determination
        if overall_usage < 30:
            status_emoji = "🟢 COOL"
        elif overall_usage < 75:
            status_emoji = "🟡 WARM"
        else:
            status_emoji = "🔴 HOT / STRESSED"

        print(f"🔹 Processor      : {platform.processor()}")
        print(f"🔹 Cores (P / L)  : {cpu_count_physical} Physical / {cpu_count_logical} Logical")
        if cpu_freq:
            print(f"🔹 Frequency      : {cpu_freq.current:.2f} MHz")
        print(f"🔹 Overall Load   : [{bar}] {overall_usage}%")
        print(f"🔹 System State   : {status_emoji}")
        
        # Per-Core Section (Professional Data)
        print("-" * 60)
        print("📉 **Per-Core Utilization (Professional View):**")
        core_display = ""
        for i, percentage in enumerate(per_cpu_usage):
            core_display += f"Core {i}: {percentage:>5}% | "
            if (i + 1) % 4 == 0: # New line every 4 cores
                print(f"  {core_display}")
                core_display = ""
        if core_display: print(f"  {core_display}")

        # Automation Data
        output_data = {
            "timestamp": int(time.time()),
            "os": os_type,
            "overall_percent": overall_usage,
            "per_core_percent": per_cpu_usage,
            "cores": {"physical": cpu_count_physical, "logical": cpu_count_logical},
            "frequency_mhz": cpu_freq.current if cpu_freq else None,
            "status": "SUCCESS"
        }

        print("-" * 60)
        print("📊 **Automation Data (JSON Syntax):**")
        print(f"  {output_data}")
        print("═" * 60)

        return output_data
    def show_memory_usage(self):
        """
        Analyzes RAM and Swap utilization using psutil.
        Returns a dictionary for automation and displays a professional dashboard.
        """
        os_type = self.os_type
        
        # Fetch memory statistics
        mem = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        # Calculations for attractive output
        total_gb = mem.total / (1024**3)
        used_gb = mem.used / (1024**3)
        available_gb = mem.available / (1024**3)
        usage_percent = mem.percent

        print("\n" + "═" * 60)
        print(f"🧠 SYSADMIN: Memory (RAM) Analysis")
        print("═" * 60)

        # --- Attractive Progress Bar ---
        bar_length = 20
        filled = int(bar_length * usage_percent / 100)
        bar = "█" * filled + "░" * (bar_length - filled)
        
        # Status determination
        if usage_percent < 50:
            status_emoji = "🟢 HEALTHY"
        elif usage_percent < 85:
            status_emoji = "🟡 MODERATE"
        else:
            status_emoji = "🔴 CRITICAL"

        print(f"🔹 Total Capacity  : {total_gb:.2f} GB")
        print(f"🔹 Used Memory     : {used_gb:.2f} GB")
        print(f"🔹 Available       : {available_gb:.2f} GB")
        print(f"🔹 Utilization     : [{bar}] {usage_percent}%")
        print(f"🔹 Health Status   : {status_emoji}")
        
        # Swap Memory Section (Professional Data)
        print("-" * 60)
        print(f"🔄 **Swap Space (Virtual Memory):**")
        print(f"  > Total: {swap.total/(1024**3):.2f} GB | Used: {swap.percent}%")
        
        # Automation Data
        output_data = {
            "timestamp": int(time.time()),
            "os": os_type,
            "ram": {
                "total_gb": round(total_gb, 2),
                "used_gb": round(used_gb, 2),
                "available_gb": round(available_gb, 2),
                "percent": usage_percent
            },
            "swap": {
                "total_gb": round(swap.total/(1024**3), 2),
                "percent": swap.percent
            },
            "status": "SUCCESS"
        }

        print("-" * 60)
        print("📊 **Automation Data:**")
        print(f"  {output_data}")
        print("═" * 60)
        return output_data
    
    def show_disk_usage(self):
        """
        Analyzes storage utilization across all mounted partitions.
        Returns a list of dictionaries for automation.
        """
        os_type = self.os_type
        disk_data = []

        print("\n" + "═" * 75)
        print(f"💾 SYSADMIN: Storage Utilization Report")
        print("═" * 75)
        print(f"{'Mount Point':<15} {'Total':<10} {'Used':<10} {'Free':<10} {'Utilization'}")
        print("-" * 75)

        partitions = psutil.disk_partitions()
        for partition in partitions:
            try:
                # Skip loopback and virtual drives on Linux for clarity
                if os_type == "Linux" and ("loop" in partition.device or "tmpfs" in partition.device):
                    continue
                    
                usage = psutil.disk_usage(partition.mountpoint)
                
                total_gb = usage.total / (1024**3)
                used_gb = usage.used / (1024**3)
                free_gb = usage.free / (1024**3)
                percent = usage.percent

                # Visual Bar
                bar_len = 15
                filled = int(bar_len * percent / 100)
                bar = "█" * filled + "░" * (bar_len - filled)

                print(f"{partition.mountpoint:<15} {total_gb:>6.1f}GB {used_gb:>6.1f}GB {free_gb:>6.1f}GB [{bar}] {percent}%")
                
                disk_data.append({
                    "mount": partition.mountpoint,
                    "total_gb": round(total_gb, 2),
                    "used_gb": round(used_gb, 2),
                    "percent": percent
                })
            except PermissionError:
                # Handle protected partitions (like recovery or system reserved)
                continue

        print("-" * 75)
        print("📊 **Automation Data:**")
        print(f"  {{'timestamp': {int(time.time())}, 'partitions': {len(disk_data)}, 'data': {disk_data}}}")
        print("═" * 75)
        
        return disk_data
    def show_disk_health(self):
        """
        Queries the OS for Physical Disk Health (SMART Status).
        """
        os_type = self.os_type
        health_status = "UNKNOWN"
        
        print("\n" + "═" * 60)
        print(f"🩺 SYSADMIN: Hardware Health Diagnostic")
        print("═" * 60)

        try:
            if os_type == "Linux":
                # Requires smartmontools. Check /dev/sda as a default primary drive
                cmd = ["sudo", "smartctl", "-H", "/dev/sda"]
                result = subprocess.run(cmd, capture_output=True, text=True)
                
                if "PASSED" in result.stdout:
                    health_status = "HEALTHY (PASSED)"
                    emoji = "🟢"
                elif "FAILED" in result.stdout:
                    health_status = "CRITICAL (FAILURE PREDICTED)"
                    emoji = "🔴"
                else:
                    health_status = "UNKNOWN / TOOL NOT INSTALLED"
                    emoji = "🟡"

            elif os_type == "Windows":
                # Professional WMI query for physical drive status
                ps_cmd = "Get-CimInstance -ClassName Win32_DiskDrive | Select-Object Model, Status"
                result = subprocess.run(['powershell', '-Command', ps_cmd], capture_output=True, text=True)
                
                if "OK" in result.stdout:
                    health_status = "HEALTHY (OK)"
                    emoji = "🟢"
                else:
                    health_status = "ATTENTION REQUIRED"
                    emoji = "🔴"
                print(result.stdout.strip())

        except Exception as e:
            health_status = f"ERROR: {e}"
            emoji = "❌"

        print(f"🔹 Disk Integrity  : {emoji} {health_status}")
        print("-" * 60)
        print("📊 **Note for Professionals:**")
        print("  SMART attributes monitor reallocated sectors and spin-up time.")
        print("═" * 60)

        return {"status": health_status}

    def show_system_uptime(self):
        """
        Calculates system uptime and provides a formatted timestamp.
        """
        os_type = self.os_type
        boot_time_timestamp = psutil.boot_time()
        boot_time_formatted = datetime.fromtimestamp(boot_time_timestamp).strftime("%Y-%m-%d %H:%M:%S")
        
        # Calculate duration
        current_time = time.time()
        uptime_seconds = current_time - boot_time_timestamp
        
        # Break down into days, hours, minutes
        days = int(uptime_seconds // (24 * 3600))
        hours = int((uptime_seconds % (24 * 3600)) // 3600)
        minutes = int((uptime_seconds % 3600) // 60)

        print("\n" + "═" * 60)
        print(f"⏱️ SYSADMIN: System Uptime Tracker")
        print("═" * 60)
        print(f"🔹 Booted Since     : {boot_time_formatted}")
        print(f"🔹 Total Uptime     : {days} Days, {hours} Hours, {minutes} Minutes")
        
        # Beginner friendly status
        if days > 30:
            print(f"🔹 Recommendation   : 🟡 System has been up for a long time. Consider a reboot.")
        else:
            print(f"🔹 Recommendation   : 🟢 System uptime is within healthy range.")

        print("-" * 60)
        
        # Professional Data
        output_data = {
            "boot_time": boot_time_formatted,
            "uptime_seconds": int(uptime_seconds),
            "days": days,
            "status": "SUCCESS"
        }
        print(f"📊 **Automation Data:** {output_data}")
        print("═" * 60)

        return output_data

    def list_processes(self,top_n=10):
        """
        Lists the top N processes based on Memory consumption.
        """
        print("\n" + "═" * 75)
        print(f"📑 SYSADMIN: Top {top_n} Active Processes (Sorted by Memory)")
        print("═" * 75)
        print(f"{'PID':<8} {'NAME':<20} {'STATUS':<12} {'MEMORY (MB)':<12} {'CPU %'}")
        print("-" * 75)

        process_list = []

        # Iterate over all running processes
        for proc in psutil.process_iter(['pid', 'name', 'status', 'memory_info', 'cpu_percent']):
            try:
                # Fetch process details as a dict
                pinfo = proc.info
                pinfo['memory_mb'] = pinfo['memory_info'].rss / (1024 * 1024)
                process_list.append(pinfo)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

        # Sort by memory usage descending
        sorted_list = sorted(process_list, key=lambda x: x['memory_mb'], reverse=True)[:top_n]

        for p in sorted_list:
            print(f"{p['pid']:<8} {p['name'][:20]:<20} {p['status']:<12} {p['memory_mb']:>10.1f} MB {p['cpu_percent']:>8}%")

        print("-" * 75)
        print(f"💡 **Tip:** Use KILL_PROCESS <PID> to terminate a hung task.")
        print("═" * 75)

        return sorted_list


    def kill_process(self,pid):
        """
        Terminates a process given its PID.
        """
        print("\n" + "═" * 60)
        print(f"🛑 SYSADMIN: Terminate Process Task")
        print("═" * 60)
        
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            
            # Professional approach: Terminate gracefully, then kill if needed
            proc.terminate()
            print(f"🟢 Signal sent to '{name}' (PID: {pid}).")
            
            return {"status": "SUCCESS", "pid": pid, "name": name}

        except psutil.NoSuchProcess:
            print(f"🟡 Result: Process with PID {pid} not found.")
            return {"status": "NOT_FOUND"}
        except psutil.AccessDenied:
            print(f"❌ Error: Permission denied. Try running as Admin/Sudo.")
            return {"status": "PERMISSION_DENIED"}
        finally:
            print("═" * 60)

    def show_services_status(self):
        """
        Lists all system services and their current status.
        """
        print("\n" + "═" * 70)
        print(f"⚙️ SYSADMIN: System Services Status")
        print("═" * 70)
        print(f"{'SERVICE NAME':<30} {'DISPLAY NAME':<30} {'STATUS'}")
        print("-" * 70)

        services = []
        # psutil.win_service_iter() works on Windows; for Linux, we parse systemctl
        try:
            if hasattr(psutil, "win_service_iter"):
                for s in psutil.win_service_iter():
                    info = s.as_dict()
                    print(f"{info['name'][:28]:<30} {info['display_name'][:28]:<30} {info['status']}")
                    services.append(info)
            else:
                # Linux Fallback: Using systemctl via subprocess
                import subprocess
                res = subprocess.run(["systemctl", "list-units", "--type=service", "--state=running", "--no-legend"], 
                                    capture_output=True, text=True)
                print(res.stdout)
                
        except Exception as e:
            print(f"❌ Error fetching services: {e}")

        print("═" * 70)
        return services

    def restart_service(self,service_name):
        """
        Restarts a system service across platforms.
        """
        os_type = self.os_type
        print(f"\n🔄 Restarting Service: {service_name}...")
        
        try:
            if os_type == "Linux":
                cmd = ["sudo", "systemctl", "restart", service_name]
            else:
                cmd = ["powershell", "-Command", f"Restart-Service -Name '{service_name}'"]
            
            subprocess.run(cmd, check=True)
            print(f"✅ Service '{service_name}' restarted successfully.")
            return True
        except Exception as e:
            print(f"❌ Failed to restart service: {e}")
            return False
        
    def show_system_logs(self,lines=10):
        """
        Displays the most recent system logs.
        """
        os_type = self.os_type
        print("\n" + "📜" + "═" * 60)
        
        try:
            if os_type == "Linux":
                # Accessing Journald
                subprocess.run(["sudo", "journalctl", "-n", str(lines), "--no-pager"])
            else:
                # Accessing Windows Event Log
                ps_cmd = f"Get-EventLog -LogName System -Newest {lines} | Select-Object TimeGenerated, Message | Format-Table -AutoSize"
                subprocess.run(["powershell", "-Command", ps_cmd])
        except Exception as e:
            print(f"❌ Could not retrieve logs: {e}")
        
        print("═" * 60)

    def clear_temp_files():
        """
        Deletes files in the system temporary directories.
        """
        os_type = platform.system()
        temp_dir = "/tmp" if os_type == "Linux" else os.environ.get('TEMP')
        
        print("\n" + "🧹" + "═" * 60)
        print(f"Maintenance: Cleaning {temp_dir}...")
        
        files_cleared = 0
        for filename in os.listdir(temp_dir):
            file_path = os.path.join(temp_dir, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                    files_cleared += 1
                elif os.path.is_dir(file_path):
                    shutil.rmtree(file_path)
                    files_cleared += 1
            except Exception:
                continue # Skip files currently in use
                
        print(f"✅ Maintenance Complete. Items removed: {files_cleared}")
        print("═" * 60)
        return files_cleared
    
    #=========================phase 7===============================
    def vnas_create_backup(self,source_path, backup_dir="VNAS_Storage"):
        """
        High-performance backup creation with automated SHA-256 sidecar generation.
        """
        if not os.path.exists(backup_dir): os.makedirs(backup_dir)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.join(backup_dir, f"backup_{timestamp}")
        
        print(f"🚀 [VNAS] Initiating backup for: {source_path}")
        
        try:
            # Step 1: High-speed Archiving
            # 'zip' is used for maximum cross-platform compatibility
            archive_path = shutil.make_archive(base_name, 'zip', source_path)
            
            # Step 2: Fingerprinting (Hashing)
            sha256 = hashlib.sha256()
            with open(archive_path, "rb") as f:
                while chunk := f.read(65536): # 64KB chunks for memory efficiency
                    sha256.update(chunk)
            
            checksum = sha256.hexdigest()
            with open(f"{archive_path}.sha256", "w") as hash_file:
                hash_file.write(checksum)
                
            print(f"✅ Success: {os.path.basename(archive_path)} (Size: {os.path.getsize(archive_path)//1024} KB)")
            return archive_path
        except Exception as e:
            print(f"❌ Backup Error: {e}")
            return None
    
    def vnas_verify_backup(self,archive_path):
        """
        Rapidly verifies the integrity of a backup using the SHA-256 sidecar.
        """
        hash_path = f"{archive_path}.sha256"
        if not os.path.exists(hash_path):
            print("⚠️ Warning: No integrity file found.")
            return "MISSING_HASH"

        sha256 = hashlib.sha256()
        try:
            with open(archive_path, "rb") as f:
                while chunk := f.read(65536):
                    sha256.update(chunk)
            
            current_hash = sha256.hexdigest()
            with open(hash_path, "r") as f:
                stored_hash = f.read().strip()
                
            if current_hash == stored_hash:
                print("🟢 Integrity Verified: File is 100% healthy.")
                return "VALID"
            else:
                print("🔴 CRITICAL: Hash mismatch! Data may be corrupted.")
                return "CORRUPTED"
        except Exception as e:
            print(f"❌ Verification Error: {e}")
            return "ERROR"
    
    def vnas_restore_backup(self,archive_path, destination_path):
        """
        Extracts data with validation.
        """
        print(f"🔄 [VNAS] Restoring archive to: {destination_path}")
        if not os.path.exists(destination_path): os.makedirs(destination_path)

        try:
            # Professional note: Always verify before restoring in high-stakes environments
            shutil.unpack_archive(archive_path, destination_path)
            print("✅ Restore Complete.")
            return True
        except Exception as e:
            print(f"❌ Restore Failed: {e}")
            return False
    
    def vnas_delete_backup(self,archive_path):
        """
        Removes the archive and its metadata to free up space.
        """
        try:
            if os.path.exists(archive_path): os.remove(archive_path)
            # Also clean up the hash file
            if os.path.exists(f"{archive_path}.sha256"): os.remove(f"{archive_path}.sha256")
            print(f"🗑️ Deleted: {os.path.basename(archive_path)}")
            return True
        except Exception as e:
            print(f"❌ Deletion Error: {e}")
            return False
        
    # Centralized VNAS State Directory
    

    def system_snapshot(self,label="stable_state"):
        """
        Captures a point-in-time image of critical configuration directories.
        """
        if not os.path.exists(VNAS_STATE_DIR): os.makedirs(VNAS_STATE_DIR)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        snapshot_path = os.path.join(VNAS_STATE_DIR, f"snapshot_{label}_{timestamp}")
        
        # In VNAS, we prioritize specific config paths based on OS
        config_paths = ["/etc/network/", "/etc/vnas/"] if platform.system() == "Linux" else [os.environ.get('APPDATA')]

        print(f"📸 [VNAS] Capturing system state to: {snapshot_path}...")
        
        try:
            # Optimized recursive copy of configuration states
            os.makedirs(snapshot_path)
            for path in config_paths:
                if os.path.exists(path):
                    dest = os.path.join(snapshot_path, os.path.basename(path.rstrip('/')))
                    shutil.copytree(path, dest, dirs_exist_ok=True)
            
            print(f"✅ Snapshot Successful: {label}")
            return snapshot_path
        except Exception as e:
            print(f"❌ Snapshot Failed: {e}")
            return None

    def system_rollback(self,snapshot_folder):
        """
        Reverts the system configuration to a previously captured snapshot.
        """
        print(f"⏳ [VNAS] Initiating ROLLBACK from: {snapshot_folder}...")
        
        if not os.path.exists(snapshot_folder):
            print("❌ Error: Snapshot folder not found.")
            return False

        try:
            # Professional Step: Take a 'Pre-Rollback' safety snapshot automatically
            print("🛡️ Creating safety image of current state before rollback...")
            self.system_snapshot(label="pre_rollback_safety")

            # Logic to restore files from snapshot to system paths
            # Warning: This is a high-privilege operation
            for item in os.listdir(snapshot_folder):
                src = os.path.join(snapshot_folder, item)
                # Map back to original system paths (Simplified for this DSL logic)
                print(f"  > Restoring {item}...")
                # shutil.copytree(src, original_system_path, dirs_exist_ok=True)
            
            print("✅ Rollback Complete. Please restart network services.")
            return True
        except Exception as e:
            print(f"🚨 CRITICAL: Rollback failed! {e}")
            return False
    def export_config(self,config_data, filename="vnas_portable_config.json"):
        """
        Saves VNAS settings and network profiles into a portable JSON format.
        """
        print(f"📤 [VNAS] Exporting configuration to {filename}...")
        try:
            with open(filename, 'w') as f:
                json.dump(config_data, f, indent=4)
            print("✅ Export Successful.")
            return True
        except Exception as e:
            print(f"❌ Export Failed: {e}")
            return False

    def import_config(self,filename):
        """
        Loads configuration from a JSON file into the Vallaipallam instance.
        """
        print(f"📥 [VNAS] Importing configuration from {filename}...")
        if not os.path.exists(filename):
            print("❌ Error: Configuration file not found.")
            return None
            
        try:
            with open(filename, 'r') as f:
                config_data = json.load(f)
            print("✅ Import Successful. New profiles loaded.")
            return config_data
        except Exception as e:
            print(f"❌ Import Failed: {e}")
            return None
        #======================phase 8 =========================
    def list_containers(self,client):
        """
        Lists all active and stopped containers with professional metadata.
        """
        if not client:
            print("❌ Error: Docker Engine not found. Please ensure Docker is running.")
            return []

        print("\n" + "═" * 80)
        print(f"📦 CLOUDOPS: Container Registry (All States)")
        print("═" * 80)
        print(f"{'CONTAINER ID':<15} {'IMAGE':<20} {'STATUS':<15} {'NAME'}")
        print("-" * 80)

        containers = client.containers.list(all=True)
        container_data = []

        if not containers:
            print("ℹ️ No containers found on this host.")
        else:
            for container in containers:
                status_emoji = "🟢" if container.status == "running" else "🔴"
                print(f"{container.short_id:<15} {container.image.tags[0] if container.image.tags else 'none':<20} {status_emoji} {container.status:<12} {container.name}")
                
                container_data.append({
                    "id": container.short_id,
                    "name": container.name,
                    "status": container.status
                })
        print("═" * 80)
        return container_data
    def run_container(self,client,image_name, container_name, host_port, container_port=80):
        """
        Deploys a new container with specific port mapping.
        """
        print("\n" + "🚀" + "═" * 60)
        print(f"CLOUDOPS: Deploying Service -> {image_name}")
        print("═" * 60)

        try:
            # Check if container name already exists to prevent conflict
            print(f"🔹 Provisioning: {container_name} on Port {host_port}...")
            
            container = client.containers.run(
                image=image_name,
                name=container_name,
                ports={f'{container_port}/tcp': int(host_port)},
                detach=True  # Runs in background
            )
            
            print(f"✅ SUCCESS: Container {container.short_id} is now LIVE.")
            print(f"🌐 Access Point: http://localhost:{host_port}")
            return {"status": "SUCCESS", "id": container.short_id}

        except docker.errors.APIError as e:
            print(f"❌ Deployment Failed: {e}")
            return {"status": "FAILED", "reason": str(e)}
    def stop_container(self,client,name_or_id):
        """
        Gracefully stops a running container.
        """
        print(f"\n🛑 [VNAS] Stopping container: {name_or_id}...")
        try:
            container = client.containers.get(name_or_id)
            container.stop()
            print(f"✅ Container '{name_or_id}' has been halted.")
            return True
        except Exception as e:
            print(f"❌ Error: {e}")
            return False
        
    def remove_container(self,client,name_or_id):
        """
        Permanently deletes a container.
        """
        print(f"\n🗑️ [VNAS] Removing container: {name_or_id}...")
        try:
            container = client.containers.get(name_or_id)
            # Force=True allows removing even if it was running, but we prefer safety
            container.remove(force=True)
            print(f"✅ Container '{name_or_id}' and its writable layer purged.")
            return True
        except Exception as e:
            print(f"❌ Deletion failed: {e}")
            return False
            
    def pull_image(self,client,image_name):
        """
        Downloads a container image from a registry (e.g., Docker Hub).
        Includes a smart-check to see if the image is already present.
        """
        if not client:
            print("❌ Error: Docker Engine not found.")
            return False

        print("\n" + "📥" + "═" * 60)
        print(f"CLOUDOPS: Pulling Image Registry -> {image_name}")
        print("═" * 60)

        try:
            # Step 1: Check if the image already exists locally to save bandwidth
            local_images = [img.tags[0] for img in client.images.list() if img.tags]
            if any(image_name in tag for tag in local_images):
                print(f"ℹ️ Image '{image_name}' already exists locally. Skipping download.")
                return True

            # Step 2: Stream the pull process (Professional Approach)
            print(f"🔹 Fetching layers for {image_name}...")
            image = client.images.pull(image_name)
            
            print(f"✅ SUCCESS: Image {image.short_id} is ready for deployment.")
            return True

        except docker.errors.ImageNotFound:
            print(f"❌ Error: Image '{image_name}' not found on Docker Hub.")
            return False
        except Exception as e:
            print(f"❌ Network/Registry Error: {e}")
            return False

    def list_images(self,client):
        """
        Lists all locally cached container images with size and tag data.
        """
        if not client:
            print("❌ Error: Docker Engine not found.")
            return []

        print("\n" + "═" * 80)
        print(f"🖼️ CLOUDOPS: Local Image Repository")
        print("═" * 80)
        print(f"{'IMAGE ID':<15} {'TAG/REPOSITORY':<35} {'SIZE (MB)':<15}")
        print("-" * 80)

        images = client.images.list()
        image_list_data = []

        if not images:
            print("ℹ️ No images found in local cache.")
        else:
            for img in images:
                # Handling images without tags (dangling images)
                tag = img.tags[0] if img.tags else "<none>"
                # Convert bytes to MB for readability
                size_mb = round(img.attrs['Size'] / (1024 * 1024), 2)
                
                print(f"{img.short_id:<15} {tag:<35} {size_mb:<15}")
                
                image_list_data.append({
                    "id": img.short_id,
                    "tag": tag,
                    "size_mb": size_mb
                })

        print("═" * 80)
        return image_list_data
    
        # ===================== main dispatcher =====================
    def execute_command(self, line_no, args=None):
        
        cmd = self.value.strip()

        try:
            # ---- direct psutil commands (pretty formatted) ----
            if cmd == 'SHOW_INTERFACE_ADDRESSES':
                return String(self._fmt_if_addrs(self.base_commands[cmd]()))
            elif cmd == 'SHOW_INTERFACE_STATUS':
                return String(self._fmt_if_stats(self.base_commands[cmd]()))
            elif cmd == 'SHOW_ACTIVE_CONNECTIONS':
                return String(self._fmt_connections(self.base_commands[cmd]()))
            elif cmd == 'SHOW_NETWORK_IO':
                return String(self._fmt_io_global(self.base_commands[cmd]()))
            elif cmd == 'SHOW_NETWORK_IO_PER_INTERFACE' :
                return String(self._fmt_io_pernic(self.base_commands[cmd]()))
            #================Firewall able and disable==============
            elif cmd == 'ENABLE_FIREWALL':
                return self.enable_firewall()
            elif cmd == 'DISABLE_FIREWALL':
                return self.disable_firewall()
            # ---- special actions ----
            elif cmd == 'RUN_AS_ADMIN':
                return Boolean(1.0 if self.run_as_admin() else 0.0)
            elif cmd == 'SHOW_NETWORK_SPEED':
                # args: [TOKEN, ifaceToken]
                iface = args[1].value if args and len(args) > 1 else ""
                return Number(self.speed(iface))
            elif cmd == 'ENABLE_INTERFACE':
                iface = args[1].value
                return Boolean(1.0 if self._toggle_iface(iface, True).returncode == 0 else 0.0)
            elif cmd == 'DISABLE_INTERFACE':
                iface = args[1].value
                return Boolean(1.0 if self._toggle_iface(iface, False).returncode == 0 else 0.0)
            elif cmd == 'SET_DHCP':
                iface = args[1].value
                return Boolean(1.0 if self._set_dhcp(iface).returncode == 0 else 0.0)
            elif cmd == 'SET_IP':
                # args: [TOKEN, [ifaceTok, ipTok, gwTok, maskTok]]
                iface = args[1][0].value
                ip    = args[1][1].value
                gw    = args[1][2].value if hasattr(args[1][2],'value') else args[1][2]
                mask  = args[1][3].value
                return Boolean(1.0 if self._set_ip(iface, ip, gw, mask).returncode == 0 else 0.0)
            elif cmd == 'LIST_WIFI':
                return String(self.list_wifi())
            elif cmd == 'CONNECT_WIFI':
                # args: [TOKEN, [ssidTok, passTok]]
                ssid = args[1][0].value
                password = args[1][1].value
                return Boolean(1.0 if self.connect_wifi(ssid, password) == 1 else 0.0)
            elif cmd == 'DISCONNECT_WIFI':
                return Boolean(1.0 if self.disconnect_wifi() == 1 else 0.0)
            elif cmd == "PING":
                return String(self.ping_test(args[1][0].value))
            elif cmd == "TRACEROUTE":
                return String(self.traceroute(args[1][0].value))
            elif cmd == 'DNS_LOOKUP':
                return String(self.dns_lookup(args[1][0].value))
            elif cmd == 'PORT_SCAN':
                host=args[1][0].value
                port_spec=args[1][1].value
                return String(self.port_scan(host,port_spec))
            elif cmd == 'SHOW_GATEWAY':
                return String(self.show_gateway())
            elif cmd == 'LATENCY_TEST':
                return String(self.latency_test(args[1][0].value))
            elif cmd == 'ALLOW_PORT':
                return self.allow_port(int(args[1][0].value))
            elif cmd == 'BLOCK_PORT':
                return self.block_port(int(args[1][0].value))
            elif cmd == 'LIST_FIREWALL_RULES':
                return self.list_firewall_rules()
            elif cmd == 'ALLOW_SERVICE':
                return self.allow_service(args[1][0].value)
            elif cmd=='BLOCK_SERVICE':
                return self.block_service(args[1][0].value)
            elif cmd=="CREATE_VPN_PROFILE":
                return self.create_vpn_profile(args[1][0].value,args[1][1].value,args[1][2].value,args[1][3].value)
            elif cmd=='CONNECT_VPN':
                return self.connect_vpn(args[1][0].value)
            elif cmd=='DISCONNECT_VPN':
                return self.disconnect_vpn(args[1][0].value)
            elif cmd=='CHECK_VPN_STATUS':
                return self.check_vpn_status(args[1][0].value)
            elif cmd=='LIST_ALL_VPN_PROFILES':
                return self.list_all_vpn_profiles()
            elif cmd=='DELETE_VPN_PROFILE':
                return self.delete_vpn_profile(args[1][0].value)
            elif cmd=='CREATE_USER':
                return self.create_user(args[1][0].value,args[1][1].value)
            elif cmd=='DELETE_USER':
                return self.delete_user(args[1][0].value)
            elif cmd=='CHANGE_PASSWORD':
                return self.change_password(args[1][0].value,args[1][1].value)
            elif cmd=='ASSIGN_GROUP':
                return self.assign_group(groupname=args[1][0].value,username=args[1][0].value)
            elif cmd=='LOCK_ACCOUNT':
                return self.lock_account(args[1][0].value)
            elif cmd=='UNLOCK_ACCOUNT':
                return self.unlock_account(args[1][0].value)
            elif cmd=='LIST_ACTIVE_USERS':
                return self.view_active_users()
            elif cmd=='USER_INFO':
                return self.user_info(args[1][0].value)
            elif cmd=='SHOW_LOGGED_USERS':
                return self.show_logged_users()
            elif cmd=='ADD_GROUP':
                return self.add_group(args[1][0].value)
            elif cmd=="DELETE_GROUP":
                return self.delete_group(args[1][0].value)
            elif cmd=="SHOW_CPU_USAGE":
                return self.show_cpu_usage()
            elif cmd=="SHOW_MEMORY_USAGE":
                return self.show_memory_usage()
            elif cmd=="SHOW_DISK_USAGE":
                return self.show_disk_usage()
            elif cmd=="SHOW_DISK_HEALTH":
                return self.show_disk_health()
            elif cmd=="SHOW_SYSTEM_UPTIME":
                return self.show_system_uptime()
            elif cmd=="LIST_PROCESSES":
                return self.list_processes()
            elif cmd=="KILL_PROCESS":
                return self.kill_process(args[1][0].value)
            elif cmd=="SHOW_SYSTEM_LOGS":
                return self.show_system_logs() 
            elif cmd=="SHOW_SERVICES_STATUS":
                return self.show_services_status()
            elif cmd=="CLEAR_TEMP_FILES":
                return self.clear_temp_files()
            elif cmd=="RESTART_SERVICE":
                return self.restart_service(args[1][0].value)
            elif cmd=="CREATE_BACKUP":
                return self.vnas_create_backup(args[1][0].value,args[1][1].value)
            elif cmd=="VERIFY_BACKUP":
                return self.vnas_verify_backup(args[1][0].value)
            elif cmd=="RESTORE_BACKUP":
                return self.vnas_restore_backup(args[1][0].value,args[1][1].value)
            elif cmd=="DELETE_BACKUP":
                return self.vnas_delete_backup(args[1][0].value)
            elif cmd=="SYSTEM_SNAPSHOT":
                return self.system_snapshot()
            elif cmd=="SYSTEM_ROLLBACK":
                return self.system_rollback(args[1][0].value)
            elif cmd=="IMPORT_CONFIG":
                return self.import_config(args[1][0].value)
            elif cmd=="EXPORT_CONFIG":
                return self.export_config(args[1][0].value)
            elif cmd=="LIST_CONTAINERS":
                return self.list_containers("client")
            elif cmd=="":
                return self.run_container("client",self.args[1][0].value,self.args[1][1].value,self.args[1][2].args)
            elif cmd=="ACTIVATE_AGENT_VALLAI":
                return ai.main(args[1][0].value,args[1][1].value)
            
            


            # Unknown command
            return Error(f"Unknown network command: {cmd}", line_no, cmd)

        except Exception as e:
            return Error(str(e), line_no, e)
