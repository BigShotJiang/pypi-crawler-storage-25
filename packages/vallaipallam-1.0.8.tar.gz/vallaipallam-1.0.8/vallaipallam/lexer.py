from vallaipallam.network import *
from vallaipallam.tokens import *
from vallaipallam.errors import *
import re

print()
class Lexer:
    line_no = 1

    # தமிழ் எழுத்துக்கள்: உயிர், மெய், உயிர்மெய், வடமொழி எழுத்துக்கள்
    letters = set("""
    அஆஇஈஉஊஎஏஐஒஓஔ
    க்ங்ச்ஞ்ட்ண்த்ந்ப்ம்ய்ர்ல்வழளற்ன்
    கஙசஞடணதநபமயரலவழளறன
    காகிகீகுகூகெகேகைகொகோகௌ
    ஙாஙிஙீஙுஙூஙெங்கேஙைஙொஙோஙௌ
    சாசிசீசுசூசெசேசைசொசோசௌ
    ஞாஞிஞீஞுஞூஞெஞேஞைஞொஞோஞௌ
    டாடிடீடுடூடெடேடைடொடோடௌ
    ணாணிணீணுணூணெணேணைணொணோணௌ
    தாதிதீதுதூதெதேதைதொதோதௌ
    நாநிநீநுநூநெனேநைநொநோநௌ
    பாபிபீபுபூபெபேபைபொபோபௌ
    மாமிமீமுமூமெமேமைமொமோமௌ
    யாயியீயுயூயெயேயையொயோயௌ    
    ராரிரீருரூரெரேரைரொரோரௌ
    லாலிலீலுலூலெலேலைலொலோலௌ
    வாவிவீவுவூவெவேவைவொவோவௌ
    ழாழிழீழுழூழெழேழைழொழோழௌ
    ளாளிளீளுளூளெளேளைளொளோளௌ
    றாறிறீறுறூறெறேறைறொறோறௌ
    னாணிணீணுணூணெணேணைணொணோணௌ
    ஸ
    abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789
    """)
    hindiletters=set([
    # स्वर (Vowels)
    "अ","आ","इ","ई","उ","ऊ","ऋ","ॠ","ऌ","ॡ","ए","ऐ","ओ","औ","अं","अः",
    # व्यंजन (Consonants)
    "क","ख","ग","घ","ङ","च","छ","ज","झ","ञ",
    "ट","ठ","ड","ढ","ण","त","थ","द","ध","न",
    "प","फ","ब","भ","म",
    "य","र","ल","व","श","ष","स","ह",
    # अतिरिक्त (Nukta forms)
    "क़","ख़","ग़","ज़","ड़","ढ़","फ़","य़",
    # मात्राएँ (Vowel signs)
    "ा","ि","ी","ु","ू","ृ","ॄ","ॢ","ॣ","े","ै","ो","ौ","ं",
    # हलन्त (Virama)
    "्","़","ँ",'ॉ',
    # अंक (Digits 0–9)
    "१","२","३","४","५","६","७","८","९",
    # विराम चिन्ह (Punctuation)
    "।","॥"
])

    
    digits = "0123456789"
    operators = "+-*/=%"
    stopwords = (' ', '\n', ',')
    listofkeyword = ('தொடர்', 'ரத்து', 'இறக்கு')
    keywords = ('உருவாக்கு')
    members = ('உள்ளது')
    function_call = 'கூப்பிடு'
    function = ('வேலை', 'கொடு')
    built_in_functions = ('வெளியிடு', 'உள்ளிடு', 'அளவு', 'எண்', 'வரம்பு', 'நீக்கு', 'பட்டியல்', 'இணை', 'சொல்', 'செருகு', 'வகை', 'பிரி', 'திற', 'படி', 'எழுது', 'மூடு')
    conditions = ('என்றால்', 'இது', 'இல்லை', 'இல்லையெனில்', 'அதுவரை', 'இதில்', 'இருந்து')
    logical = ('மற்றும்', 'அல்லது', 'அல்ல')
    comparison = (">", "<", ">=", "<=", "!=", "==")
    boolean = ('மெய்', 'பொய்')

    englishcommandlist=("RUN_AS_ADMIN","SHOW_INTERFACE_ADDRESSES","SHOW_INTERFACE_STATUS","ENABLE_INTERFACE","DISABLE_INTERFACE","SET_DHCP","SET_IP","SHOW_NETWORK_IO","SHOW_NETWORK_IO_PER_INTERFACE",
                        "SHOW_ACTIVE_CONNECTIONS", "SHOW_NETWORK_SPEED","GATEWAY","NETMASK",
                        'LIST_WIFI','CONNECT_WIFI','DISCONNECT_WIFI','PASSWORD','PING','TRACEROUTE','DNS_LOOKUP','PORT_SCAN','SHOW_GATEWAY','LATENCY_TEST','PORT',
                        'ENABLE_FIREWALL','DISABLE_FIREWALL','ALLOW_PORT','BLOCK_PORT','LIST_FIREWALL_RULES','ALLOW_SERVICE','BLOCK_SERVICE',
                        'CREATE_VPN_PROFILE','SERVER','USER',"CONNECT_VPN","DISCONNECT_VPN","CHECK_VPN_STATUS","LIST_ALL_VPN_PROFILES","DELETE_VPN_PROFILE",
                        "CREATE_USER","DELETE_USER","CHANGE_PASSWORD","ASSIGN_GROUP","LOCK_ACCOUNT","UNLOCK_ACCOUNT","LIST_ACTIVE_USERS","USER_INFO","SHOW_LOGGED_USERS","ADD_GROUP","DELETE_GROUP",
                        "SHOW_CPU_USAGE","SHOW_MEMORY_USAGE","SHOW_DISK_USAGE","SHOW_DISK_HEALTH","SHOW_SYSTEM_UPTIME","KILL_PROCESS","LIST_PROCESSES","SHOW_SERVICES_STATUS","RESTART_SERVICE","SHOW_SYSTEM_LOGS","CLEAR_TEMP_FILES",
                        "CREATE_BACKUP","RESTORE_BACKUP","LIST_BACKUPS","DELETE_BACKUP","SCHEDULE_BACKUP","VERIFY_BACKUP","SYSTEM_SNAPSHOT","SYSTEM_ROLLBACK","EXPORT_CONFIG","IMPORT_CONFIG","RUN_AUTOMATION",
                        "LIST_CONTAINERS","RUN_CONTAINER","STOP_CONTAINER","REMOVE_CONTAINER","PULL_IMAGE","LIST_IMAGES","CREATE_CLOUD_VM","DELETE_CLOUD_VM","DEPLOY_APPLICATION","SHOW_INFRASTRUCTURE_STATUS","SCALE_SERVICE","DESTROY_INFRASTRUCTURE",
                        "ACTIVATE_AGENT_VALLAI","WORKING_DIRECTORY","GEMINI_API_KEY","DESTINATION") 
 
    tamil_to_english={
    'இணைப்பு_முகவரி': 'SHOW_INTERFACE_ADDRESSES','இணைப்பு_நிலை': 'SHOW_INTERFACE_STATUS','இணைப்பு_செயலில்': 'SHOW_ACTIVE_CONNECTIONS',
    'இணைப்பு_உள்வெளி': 'SHOW_NETWORK_IO','இணைப்பு_உள்வெளி_பிரிப்பு': 'SHOW_NETWORK_IO_PER_INTERFACE',
    'DHCP_அமை': 'SET_DHCP','இணைப்பு_IP_அமை': 'SET_IP','இணைப்பு_வேகம்': 'SHOW_NETWORK_SPEED',
    'இணைப்பு_திற': 'ENABLE_INTERFACE','இணைப்பு_மூடு': 'DISABLE_INTERFACE','வலைப்பின்னல்_இணை': 'CONNECT_WIFI',
    'வலைப்பின்னல்_துண்டிக்க': 'DISCONNECT_WIFI','வலைப்பின்னல்_பட்டியல்': 'LIST_WIFI','நிர்வாகி_இயக்கு': 'RUN_AS_ADMIN',
    'இணைப்பு_அடைந்ததா': 'PING','வழித்தடம்_காட்டு': 'TRACEROUTE','பெயர்ப்பட்டியல்_காண்': 'DNS_LOOKUP',
    'துறைமுகம்_சோதனை': 'PORT_SCAN','வாயில்_காட்டு': 'SHOW_GATEWAY','தாமதம்_சோதனை': 'LATENCY_TEST',
    'தடுப்பு_செயல்படுத்து': 'ENABLE_FIREWALL','தடுப்பு_நிறுத்து': 'DISABLE_FIREWALL','துறைமுகம்_அனுமதி': 'ALLOW_PORT',
    'துறைமுகம்_தடு': 'BLOCK_PORT','துறைமுகம்_விதிகள்': 'LIST_FIREWALL_RULES','சேவை_அனுமதி': 'ALLOW_SERVICE',
    'சேவை_தடு': 'BLOCK_SERVICE',"சேவை_மீள்துவக்கு": "RESTART_SERVICE",
    #phase 4
    "விபிஎன்_சுயவிவரம்_உருவாக்கு": "CREATE_VPN_PROFILE","விபிஎன்_இணைப்பு": "CONNECT_VPN",
    'விபிஎன்_துண்டிப்பு':'DISCONNECT_VPN',"விபிஎன்_நிலையை_சரிபார்": "CHECK_VPN_STATUS","விபிஎன்_சுயவிவரங்களை_பட்டியலிடு": "LIST_ALL_VPN_PROFILES",
    "விபிஎன்_சுயவிவரத்தை_நீக்கு": "DELETE_VPN_PROFILE",
    #phase 5
    "பயனரை_உருவாக்கு": "CREATE_USER","பயனரை_நீக்கு": "DELETE_USER","கடவுச்சொல்லை_மாற்று": "CHANGE_PASSWORD","குழுவில்_சேர்": "ASSIGN_GROUP",
    "கணக்கை_முடக்கு": "LOCK_ACCOUNT","கணக்கை_மீட்டெடு": "UNLOCK_ACCOUNT","பயனர்களை_பட்டியலிடு": "LIST_ACTIVE_USERS",
    "பயனர்_தகவல்": "USER_INFO","உள்நுழைந்தவர்கள்_காட்டு": "SHOW_LOGGED_USERS","புதிய_குழு_உருவாக்கு": "ADD_GROUP","குழுவை_நீக்கு": "DELETE_GROUP",
    #phase 6
    "CPU_பயன்பாடு_காட்டு": "SHOW_CPU_USAGE","நினைவகம்_பயன்பாடு_காட்டு": "SHOW_MEMORY_USAGE","வட்டு_பயன்பாடு_காட்டு": "SHOW_DISK_USAGE","வட்டு_நிலை_காட்டு": "SHOW_DISK_HEALTH","அமைப்பு_நேரம்_காட்டு": "SHOW_SYSTEM_UPTIME","செயலிகள்_பட்டியல்": "LIST_PROCESSES","செயலி_நிறுத்து": "KILL_PROCESS",
    "சேவைகள்_நிலை_காட்டு": "SHOW_SERVICES_STATUS","சேவை_மீள்துவக்கு": "RESTART_SERVICE","பதிவு_கோப்பு_காட்டு": "SHOW_SYSTEM_LOGS","தற்காலிக_கோப்புகள்_அழி": "CLEAR_TEMP_FILES",
    
    #phase 7
    "காப்பு_உருவாக்கு": "CREATE_BACKUP","காப்பு_மீட்டமை": "RESTORE_BACKUP","காப்பு_பட்டியல்": "LIST_BACKUPS","காப்பு_அழி": "DELETE_BACKUP","காப்பு_அட்டவணை": "SCHEDULE_BACKUP","காப்பு_சரிபார்": "VERIFY_BACKUP",
    "அமைப்பு_படமெடு": "SYSTEM_SNAPSHOT","அமைப்பு_திரும்பு": "SYSTEM_ROLLBACK","அமைப்பு_ஏற்றுமதி": "EXPORT_CONFIG","அமைப்பு_இறக்குமதி": "IMPORT_CONFIG","தானியங்கி_இயக்கு": "RUN_AUTOMATION",
    
    #phase 8
    "கொண்டெய்னர்_பட்டியல்": "LIST_CONTAINERS","கொண்டெய்னர்_இயக்கு": "RUN_CONTAINER","கொண்டெய்னர்_நிறுத்து": "STOP_CONTAINER","கொண்டெய்னர்_அழி": "REMOVE_CONTAINER","படம்_இறக்கு": "PULL_IMAGE",
    "படம்_பட்டியல்": "LIST_IMAGES","மேகம்_VM_உருவாக்கு": "CREATE_CLOUD_VM","மேகம்_VM_அழி": "DELETE_CLOUD_VM","பயன்பாடு_பதிவு": "DEPLOY_APPLICATION","கட்டமைப்பு_நிலை": "SHOW_INFRASTRUCTURE_STATUS","சேவை_அளவுகூட்டு": "SCALE_SERVICE","கட்டமைப்பு_அழி": "DESTROY_INFRASTRUCTURE",
    
    'வாயில்':'GATEWAY',"சேவையகம்": "SERVER","பயனர்": "USER",'மடக்கெண்':'NETMASK','கடவுச்சொல்':'PASSWORD','துறைமுகம்':'PORT',
    'இலக்கு':"DESTINATION",
    #AGENT VALLAI
    "வாழை_முகவர்_அழை":"ACTIVATE_AGENT_VALLAI",
    "பணி_அடைவு":"WORKING_DIRECTORY",
    "ஜெமினி_விசை":"GEMINI_API_KEY"

}


    hindi_to_english = {
    # Phase 1
    "इंटरफ़ेस_पते_दिखाओ": "SHOW_INTERFACE_ADDRESSES","इंटरफ़ेस_स्थिति_दिखाओ": "SHOW_INTERFACE_STATUS","सक्रिय_कनेक्शन_दिखाओ": "SHOW_ACTIVE_CONNECTIONS",
    "नेटवर्क_IO_दिखाओ": "SHOW_NETWORK_IO","प्रति_इंटरफ़ेस_IO_दिखाओ": "SHOW_NETWORK_IO_PER_INTERFACE","इंटरफ़ेस_गति_मापो": "SHOW_NETWORK_SPEED",
    "इंटरफ़ेस_सक्रिय_करो": "ENABLE_INTERFACE","इंटरफ़ेस_निष्क्रिय_करो": "DISABLE_INTERFACE","DHCP_सक्रिय_करो": "SET_DHCP",
    "इंटरफ़ेस_IP_सेट_करो": "SET_IP","प्रशासक_रन": "RUN_AS_ADMIN",

    # Wi-Fi
    "वाईफाई_सूची_दिखाओ": "LIST_WIFI","वाईफाई_जोड़ो": "CONNECT_WIFI","वाईफाई_काटो": "DISCONNECT_WIFI",

    # Phase 2
    "पिंग_जाँच": "PING","मार्ग_दिखाओ": "TRACEROUTE","DNS_खोज": "DNS_LOOKUP",
    "पोर्ट_जांच": "PORT_SCAN","गेटवे_दिखाओ": "SHOW_GATEWAY","विलंब_परीक्षण": "LATENCY_TEST",

    # Phase 3
    "फायरवॉल_सक्रिय_करो": "ENABLE_FIREWALL","फायरवॉल_निष्क्रिय_करो": "DISABLE_FIREWALL","पोर्ट_अनुमति": "ALLOW_PORT",
    "पोर्ट_अवरोध": "BLOCK_PORT","फायरवॉल_नियम_दिखाओ": "LIST_FIREWALL_RULES","सेवा_अनुमति": "ALLOW_SERVICE",
    "सेवा_अवरोध": "BLOCK_SERVICE",

    #PHASE 4
    "वीपीएन_प्रोफ़ाइल_बनाएँ": "CREATE_VPN_PROFILE","वीपीएन_कनेक्ट": "CONNECT_VPN",'वीपीएन_असंयोजन':"DISCONNECT_VPN","वीपीएन_स्थिति_जाँचें": "CHECK_VPN_STATUS",
    "वीपीஎன்_प्रोफ़ाइल_सूची": "LIST_ALL_VPN_PROFILES","वीपीएन_प्रोफ़ाइल_हटाएँ": "DELETE_VPN_PROFILE",

    #phase 5
    "उपयोगकर्ता_बनाएँ": "CREATE_USER","उपयोगकर्ता_हटाएँ": "DELETE_USER","पासवर्ड_बदलें": "CHANGE_PASSWORD","समूह_में_जोड़ें": "ASSIGN_GROUP",
    "खाता_लॉक_करें": "LOCK_ACCOUNT","खाता_अनलॉक_करें": "UNLOCK_ACCOUNT","उपयोगकर्ता_सूची_देखें": "LIST_ACTIVE_USERS","उपयोगकर्ता_विवरण": "USER_INFO","लॉगिन_उपयोगकर्ता_देखें": "SHOW_LOGGED_USERS","नया_समूह_बनाएँ": "ADD_GROUP","समूह_हटाएँ": "DELETE_GROUP",
    #phase 6
    "CPU_उपयोग_देखें": "SHOW_CPU_USAGE","मेमोरी_उपयोग_देखें": "SHOW_MEMORY_USAGE","डिस्क_उपयोग_देखें": "SHOW_DISK_USAGE","डिस्क_स्वास्थ्य_जाँचें": "SHOW_DISK_HEALTH","सिस्टम_अपटाइम_देखें": "SHOW_SYSTEM_UPTIME",
    "प्रक्रिया_सूची": "LIST_PROCESSES","प्रक्रिया_रोकें": "KILL_PROCESS","सेवाओं_की_स्थिति_देखें": "SHOW_SERVICES_STATUS","सेवा_पुनारंभ_करें": "RESTART_SERVICE","सिस्टम_लॉग_देखें": "SHOW_SYSTEM_LOGS","अस्थायी_फ़ाइलें_हटाएँ": "CLEAR_TEMP_FILES",
    #phase 7
    "बैकअप_बनाएँ": "CREATE_BACKUP","बैकअप_पुनर्स्थापित_करें": "RESTORE_BACKUP","बैकअप_सूची": "LIST_BACKUPS","बैकअप_हटाएँ": "DELETE_BACKUP","बैकअप_शेड्यूल_करें": "SCHEDULE_BACKUP",
    "बैकअप_जाँचें": "VERIFY_BACKUP","सिस्टम_स्नैपशॉट": "SYSTEM_SNAPSHOT","सिस्टम_रोलबैक": "SYSTEM_ROLLBACK","कॉन्फ़िगरेशन_निर्यात": "EXPORT_CONFIG","कॉन्फ़िगरेशन_आयात": "IMPORT_CONFIG","ऑटोमेशन_चलाएँ": "RUN_AUTOMATION",
    #phase 8
    "कंटेनर_सूची": "LIST_CONTAINERS","कंटेनर_चलाएँ": "RUN_CONTAINER","कंटेनर_रोकें": "STOP_CONTAINER","कंटेनर_हटाएँ": "REMOVE_CONTAINER","इमेज_पुल_करें": "PULL_IMAGE","इमेज_सूची": "LIST_IMAGES",
    "क्लाउड_VM_बनाएँ": "CREATE_CLOUD_VM","क्लाउड_VM_हटाएँ": "DELETE_CLOUD_VM","एप्लिकेशन_तैनात_करें": "DEPLOY_APPLICATION","बुनियादी_ढांचा_स्थिति": "SHOW_INFRASTRUCTURE_STATUS","सेवा_स्केल_करें": "SCALE_SERVICE","बुनियादी_ढांचा_नष्ट_करें": "DESTROY_INFRASTRUCTURE",
    #Arguements
    'गेटवे': 'GATEWAY',
    'नेटमास्क': 'NETMASK','पासवर्ड': 'PASSWORD',
    'पोर्ट': 'PORT',"सर्वर": "SERVER","उपयोगकर्ता": "USER","गंतव्य":"DESTINATION",

    #AGENT VALLAI
    "एजेंट_वाले_जगाओ":"ACTIVATE_AGENT_VALLAI",
    "कार्य_निर्देशिका":"WORKING_DIRECTORY",
    "जेमिनी_कुंजी":"GEMINI_API_KEY"

} 
    hindi_to_tamil = {
    "अगर": "இது","तो": "என்றால்","वरनाअगर": "இல்லையெனில்","वरना": "இல்லை","जबतक": "அதுவரை",
    "हर": "இதில்","से": "இருந்து","जारी": "தொடர்","तोड़ो": "ரத்து","काम": "வேலை","बुला": "கூப்பிடு",
    "लौटा": "கொடு","दिखा": "வெளியிடு","पाओ": "உள்ளிடு","आकार": "அளவு","संख्या": "எண்","सीमा": "வரம்பு",
    "हटाओ": "நீக்கு","सूची": "பட்டியல்","जोड़ो": "இணை","शब्द": "சொல்","डालो": "செருகு","प्रकार": "வகை",
    "भाग": "பிரி","खोलो": "திற","पढ़ो": "படி","लिखो": "எழுது","बंद": "மூடு","और": "மற்றும்","या": "அல்லது",
    "नहीं": "அல்ல","सच": "மெய்","झूठ": "பொய்","आयात":"இறக்கு"
}
    

    def __init__(self, text):
        self.text = text
        self.idx = 0
        self.char = self.text[self.idx] if self.text else ''
        self.token = None
        self.tokens = []

    def tokenize(self):
        while self.idx < len(self.text):
            # Skip comments starting with #
            if self.char == '#':
                while self.char != '\n' and self.idx < len(self.text):
                    self.move()
                continue
            elif self.char ==',':
                self.token=Delimiter(self.char)
                self.move()
            # Skip spaces and handle newlines
            elif self.char in Lexer.stopwords:
                if self.char == '\n':
                    Lexer.line_no += 1
                self.move()
                continue

            elif self.char in Lexer.digits:
                self.token = self.extract_number()

            elif self.char in '\'\"':
                self.token = self.extract_string()

            elif self.char == '[':
                self.token = List(self.extract_list())

            elif self.char in '(){}.,':
                self.token = Delimiter(self.char) if self.char in '{}.' else Operator(self.char)
                self.move()

            elif self.char in Lexer.letters or self.char in Lexer.hindiletters:
                word = self.extract_word()
                self.token = self.categorize_word(self.hindi_to_tamil.get(word,word))
            elif self.char in Lexer.operators and self.peek() != '=':
                self.token = Operator(self.char)
                self.move()

            elif self.char in Lexer.comparison or (self.char in '!=' and self.peek() == '='):
                self.token = self.extract_comparison()

            else:
                Syntax_Error(Lexer.line_no, f"{self.char} UNKNOWN LETTER")

            if self.token:
                self.tokens.append(self.token)
        return self.tokens

    def categorize_word(self, word):
    
        if word in Lexer.keywords:
            return Declaration(word)
        elif word in Lexer.logical:
            return Logical(word)
        elif word in Lexer.conditions:
            return Condition(word)
        elif word in Lexer.boolean:
            return Boolean(word)
        elif word in Lexer.listofkeyword:
            return Keyword(word)
        elif word in Lexer.members:
            return Member(word)
        elif word in Lexer.function:
            return Function(word)
        elif word == Lexer.function_call:
            return Function(word)
        elif word in Lexer.built_in_functions:
            return Built_in_Function(word)
        elif word in Lexer.tamil_to_english or word in Lexer.englishcommandlist or word in Lexer.hindi_to_english:
            word=word if word.replace('_','').isalpha() else self.tamil_to_english.get(word) or self.hindi_to_english.get(word) 
            return NetworkObject(word)
        else:
            return Variable(word)

    def extract_word(self):
        word = ''
        while self.idx < len(self.text) and (self.char in Lexer.letters or self.char in Lexer.hindiletters or self.char.isdigit() or self.char == '_') and not self.char.isspace():
            word += self.char
            self.move()
        return word 

    def extract_number(self):
        number = ''
        while self.idx < len(self.text) and (self.char in Lexer.digits or self.char == '.'):
            number += self.char
            self.move()
        if number.startswith('0') and len(number) > 1:
            Syntax_Error(Lexer.line_no, "NUMBER SHOULD NOT START WITH 0")
        return Number(number)

    def extract_string(self):
        quote = self.char
        self.move()
        word = ''
        while self.char != quote and self.idx < len(self.text):
            word += self.char
            self.move()
        if self.char != quote:
            Syntax_Error(Lexer.line_no, f"{word} AT END {quote} MUST BE THERE")
        self.move()
        return String(word)

    def extract_comparison(self):
        op = ''
        while self.idx < len(self.text) and (self.char in Lexer.comparison or self.char in '!='):
            op += self.char
            self.move()
        return Comparison(op)

    def extract_list(self):
        list_extracted = []
        every_element=[]
        self.move()
        while self.char != ']' and self.idx < len(self.text):
            if self.char.isspace() and self.idx <len(self.text):
                self.move()
            if self.char == '#':
                while self.char != '\n' and self.idx < len(self.text):
                    self.move()
                continue
            element = self.tokenize_sequence()

            if self.char == ':':
                list_extracted.append(Delimiter(':'))
            if element:
                every_element.append(element)
            if self.char==',':
                list_extracted.append(every_element)
                every_element=[]
                self.move()
            if self.char ==']':
                list_extracted.append(every_element)
                every_element=[]
                continue
                     
        self.move()
        return list_extracted

    def tokenize_sequence(self):
        if self.char in Lexer.digits:
            return self.extract_number()
        elif self.char in '\'\"':
            return self.extract_string()
        elif self.char == '[':
            return List(self.extract_list())
        elif self.char in Lexer.letters and not self.char.isspace():
            return self.categorize_word(self.extract_word())
        elif self.char in Lexer.operators:
            op = Operator(self.char)
            self.move()
            return op
        elif self.char in Lexer.comparison or (self.char in '!=' and self.peek() == '='):
            return self.extract_comparison()
        elif self.char in '(){}':
            tok=Delimiter(self.char)
            self.move()
            return tok
        return None

    def move(self):
        self.idx += 1
        if self.idx < len(self.text):
            self.char = self.text[self.idx]

    def peek(self):
        return self.text[self.idx + 1] if self.idx + 1 < len(self.text) else ''

