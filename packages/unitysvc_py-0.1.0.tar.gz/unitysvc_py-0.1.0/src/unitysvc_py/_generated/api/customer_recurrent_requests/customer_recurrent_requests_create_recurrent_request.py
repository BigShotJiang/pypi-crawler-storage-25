from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.recurrent_request_create import RecurrentRequestCreate
from ...models.recurrent_request_public import RecurrentRequestPublic
from ...types import UNSET, Unset
from typing import cast
from typing import cast, Union
from typing import Union



def _get_kwargs(
    *,
    body: RecurrentRequestCreate,
    authorization: Union[None, Unset, str] = UNSET,
    x_role_id: Union[None, Unset, str] = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(authorization, Unset):
        headers["authorization"] = authorization

    if not isinstance(x_role_id, Unset):
        headers["x-role-id"] = x_role_id



    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/recurrent-requests/",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[HTTPValidationError, RecurrentRequestPublic]]:
    if response.status_code == 201:
        response_201 = RecurrentRequestPublic.from_dict(response.json())



        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[HTTPValidationError, RecurrentRequestPublic]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: RecurrentRequestCreate,
    authorization: Union[None, Unset, str] = UNSET,
    x_role_id: Union[None, Unset, str] = UNSET,

) -> Response[Union[HTTPValidationError, RecurrentRequestPublic]]:
    """ Create Recurrent Request

     Create a draft recurrent request.

    Returns the created record with its ID, which can be used as the
    X-Playground-Request header for test requests.

    Args:
        authorization (Union[None, Unset, str]):
        x_role_id (Union[None, Unset, str]):
        body (RecurrentRequestCreate): Schema for creating a RecurrentRequest (draft).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, RecurrentRequestPublic]]
     """


    kwargs = _get_kwargs(
        body=body,
authorization=authorization,
x_role_id=x_role_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: RecurrentRequestCreate,
    authorization: Union[None, Unset, str] = UNSET,
    x_role_id: Union[None, Unset, str] = UNSET,

) -> Optional[Union[HTTPValidationError, RecurrentRequestPublic]]:
    """ Create Recurrent Request

     Create a draft recurrent request.

    Returns the created record with its ID, which can be used as the
    X-Playground-Request header for test requests.

    Args:
        authorization (Union[None, Unset, str]):
        x_role_id (Union[None, Unset, str]):
        body (RecurrentRequestCreate): Schema for creating a RecurrentRequest (draft).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, RecurrentRequestPublic]
     """


    return sync_detailed(
        client=client,
body=body,
authorization=authorization,
x_role_id=x_role_id,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: RecurrentRequestCreate,
    authorization: Union[None, Unset, str] = UNSET,
    x_role_id: Union[None, Unset, str] = UNSET,

) -> Response[Union[HTTPValidationError, RecurrentRequestPublic]]:
    """ Create Recurrent Request

     Create a draft recurrent request.

    Returns the created record with its ID, which can be used as the
    X-Playground-Request header for test requests.

    Args:
        authorization (Union[None, Unset, str]):
        x_role_id (Union[None, Unset, str]):
        body (RecurrentRequestCreate): Schema for creating a RecurrentRequest (draft).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, RecurrentRequestPublic]]
     """


    kwargs = _get_kwargs(
        body=body,
authorization=authorization,
x_role_id=x_role_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: RecurrentRequestCreate,
    authorization: Union[None, Unset, str] = UNSET,
    x_role_id: Union[None, Unset, str] = UNSET,

) -> Optional[Union[HTTPValidationError, RecurrentRequestPublic]]:
    """ Create Recurrent Request

     Create a draft recurrent request.

    Returns the created record with its ID, which can be used as the
    X-Playground-Request header for test requests.

    Args:
        authorization (Union[None, Unset, str]):
        x_role_id (Union[None, Unset, str]):
        body (RecurrentRequestCreate): Schema for creating a RecurrentRequest (draft).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, RecurrentRequestPublic]
     """


    return (await asyncio_detailed(
        client=client,
body=body,
authorization=authorization,
x_role_id=x_role_id,

    )).parsed
