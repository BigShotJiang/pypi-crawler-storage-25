from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import cast, Union
from typing import Union

if TYPE_CHECKING:
  from ..models.service_alias_create_routing_key_override_type_0 import ServiceAliasCreateRoutingKeyOverrideType0
  from ..models.request_routing_key import RequestRoutingKey





T = TypeVar("T", bound="ServiceAliasCreate")



@_attrs_define
class ServiceAliasCreate:
    """ Schema for creating a ServiceAlias.

     """

    name: str
    """ URL-safe alias name (lowercase, alphanumeric, hyphens, underscores) """
    target_path: str
    """ Target path (e.g. 'p/openai' or 'g/my-llm-group') """
    description: Union[None, Unset, str] = UNSET
    request_routing_key: Union[Unset, 'RequestRoutingKey'] = UNSET
    is_routing: Union[Unset, bool] = True
    """ Whether to make this alias the active routing one for its (name, routing_key) combo. Fails with 409 if
    another alias is already routing. """
    routing_key_override: Union['ServiceAliasCreateRoutingKeyOverrideType0', None, Unset] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.service_alias_create_routing_key_override_type_0 import ServiceAliasCreateRoutingKeyOverrideType0
        from ..models.request_routing_key import RequestRoutingKey
        name = self.name

        target_path = self.target_path

        description: Union[None, Unset, str]
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        request_routing_key: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.request_routing_key, Unset):
            request_routing_key = self.request_routing_key.to_dict()

        is_routing = self.is_routing

        routing_key_override: Union[None, Unset, dict[str, Any]]
        if isinstance(self.routing_key_override, Unset):
            routing_key_override = UNSET
        elif isinstance(self.routing_key_override, ServiceAliasCreateRoutingKeyOverrideType0):
            routing_key_override = self.routing_key_override.to_dict()
        else:
            routing_key_override = self.routing_key_override


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "target_path": target_path,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if request_routing_key is not UNSET:
            field_dict["request_routing_key"] = request_routing_key
        if is_routing is not UNSET:
            field_dict["is_routing"] = is_routing
        if routing_key_override is not UNSET:
            field_dict["routing_key_override"] = routing_key_override

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.service_alias_create_routing_key_override_type_0 import ServiceAliasCreateRoutingKeyOverrideType0
        from ..models.request_routing_key import RequestRoutingKey
        d = dict(src_dict)
        name = d.pop("name")

        target_path = d.pop("target_path")

        def _parse_description(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        description = _parse_description(d.pop("description", UNSET))


        _request_routing_key = d.pop("request_routing_key", UNSET)
        request_routing_key: Union[Unset, RequestRoutingKey]
        if isinstance(_request_routing_key,  Unset):
            request_routing_key = UNSET
        else:
            request_routing_key = RequestRoutingKey.from_dict(_request_routing_key)




        is_routing = d.pop("is_routing", UNSET)

        def _parse_routing_key_override(data: object) -> Union['ServiceAliasCreateRoutingKeyOverrideType0', None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                routing_key_override_type_0 = ServiceAliasCreateRoutingKeyOverrideType0.from_dict(data)



                return routing_key_override_type_0
            except: # noqa: E722
                pass
            return cast(Union['ServiceAliasCreateRoutingKeyOverrideType0', None, Unset], data)

        routing_key_override = _parse_routing_key_override(d.pop("routing_key_override", UNSET))


        service_alias_create = cls(
            name=name,
            target_path=target_path,
            description=description,
            request_routing_key=request_routing_key,
            is_routing=is_routing,
            routing_key_override=routing_key_override,
        )


        service_alias_create.additional_properties = d
        return service_alias_create

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
