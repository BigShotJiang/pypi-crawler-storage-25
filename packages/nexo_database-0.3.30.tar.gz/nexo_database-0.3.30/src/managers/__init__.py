from abc import ABC, abstractmethod
from datetime import UTC, datetime
from typing import ClassVar
from uuid import uuid4

from elasticsearch import AsyncElasticsearch, Elasticsearch
from motor.motor_asyncio import AsyncIOMotorClient
from nexo.logging.config import LogConfig
from nexo.logging.logger import Database
from nexo.schemas.application import ApplicationContext, OptApplicationContext
from nexo.schemas.bus import ListOfAnyPublishers
from nexo.schemas.connection import OptConnectionContext
from nexo.schemas.extractor import extract_details
from nexo.schemas.operation.context import DefaultOperationContext
from nexo.schemas.operation.enums import SystemOperationType
from nexo.schemas.operation.mixins import Timestamp
from nexo.schemas.operation.system import (
    SuccessfulSystemOperation,
    SystemOperationAction,
)
from nexo.schemas.security.authentication import OptAnyAuthentication
from nexo.schemas.security.authorization import OptAnyAuthorization
from nexo.schemas.security.impersonation import OptImpersonation
from nexo.types.uuid import OptUUID
from pymongo import MongoClient
from redis import Redis as SyncRedis
from redis.asyncio import Redis as AsyncRedis
from sqlalchemy import text
from sqlalchemy.orm import DeclarativeBase

from ..config import (
    AnyDatabaseConfig,
    AnyNoSQLConfig,
    AnySQLConfig,
    ElasticsearchConfig,
    MongoConfig,
    MySQLConfig,
    PostgreSQLConfig,
    RedisConfig,
    SQLiteConfig,
    SQLServerConfig,
)
from ..enums import Connection, Driver
from .client import (
    ClientManager,
    ElasticsearchClientManager,
    MongoClientManager,
    RedisClientManager,
)
from .engine import EngineManager
from .session import SessionManager


class Manager[T: AnyDatabaseConfig](ABC):
    __driver__: ClassVar[Driver]

    def __init__(
        self,
        config: T,
        log_config: LogConfig,
        publishers: ListOfAnyPublishers,
        application_context: OptApplicationContext = None,
    ) -> None:
        super().__init__()
        self._config = config
        self._publishers = publishers
        self._application_context = (
            application_context
            if application_context is not None
            else ApplicationContext.new()
        )
        identifier = (
            f"{self.__driver__.value}|"
            f"{self._config.identifier.environment.value}|"
            f"{self._config.identifier.name}"
        )
        self._logger = Database(
            log_config,
            environment=self._application_context.environment,
            service_key=self._application_context.service_key,
            identifier=identifier,
        )
        self._operation_context = DefaultOperationContext.SERVICE_UTILITY_DATABASE.new(
            target_details=self._config.model_dump(include={"identifier"})
        )

    @abstractmethod
    async def async_check_connection(
        self,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
    ) -> bool:
        pass

    @abstractmethod
    def sync_check_connection(
        self,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
    ) -> bool:
        pass

    @abstractmethod
    async def dispose(self):
        pass


class NoSQLManager[C: AnyNoSQLConfig, L: ClientManager](Manager[C]):
    client_manager_cls: type[L]

    def __init__(
        self,
        config: C,
        log_config: LogConfig,
        publishers: ListOfAnyPublishers,
        application_context: OptApplicationContext = None,
    ) -> None:
        super().__init__(config, log_config, publishers, application_context)
        self._client_manager = self.client_manager_cls(config, publishers)

    @property
    def client(self) -> L:
        return self._client_manager

    async def async_check_connection(
        self,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
    ) -> bool:
        """Check client connectivity by executing a simple query."""
        client = self._client_manager.get(Connection.ASYNC)
        try:
            if isinstance(client, AsyncElasticsearch):
                return await client.ping()
            elif isinstance(client, AsyncIOMotorClient):
                db = client.get_database(str(self._config.connection.database))
                await db.command("ping")
                return True
            elif isinstance(client, AsyncRedis):
                await client.ping()  # type: ignore
                return True
            else:
                raise TypeError(f"Invalid client type: '{type(client)}'")
        except Exception as e:
            self._logger.error(
                "Unexpected error occured while checking client connection",
                exc_info=True,
                extra={"json_fields": {"exc_details": extract_details(e)}},
            )
            return False

    def sync_check_connection(
        self,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
    ) -> bool:
        """Check client connectivity by executing a simple query."""
        client = self._client_manager.get(Connection.SYNC)
        try:
            if isinstance(client, Elasticsearch):
                return client.ping()
            elif isinstance(client, MongoClient):
                db = client.get_database(str(self._config.connection.database))
                db.command("ping")
                return True
            elif isinstance(client, SyncRedis):
                client.ping()
                return True
            else:
                raise TypeError(f"Invalid client type: '{type(client)}'")
        except Exception as e:
            self._logger.error(
                "Unexpected error occured while checking client connection",
                exc_info=True,
                extra={"json_fields": {"exc_details": extract_details(e)}},
            )
            return False

    async def dispose(self):
        await self._client_manager.dispose()


class ElasticsearchManager(
    NoSQLManager[ElasticsearchConfig, ElasticsearchClientManager]
):
    __driver__: ClassVar[Driver] = Driver.ELASTICSEARCH
    client_manager_cls = ElasticsearchClientManager


class MongoManager(NoSQLManager[MongoConfig, MongoClientManager]):
    __driver__: ClassVar[Driver] = Driver.MONGODB
    client_manager_cls = MongoClientManager


class RedisManager(NoSQLManager[RedisConfig, RedisClientManager]):
    __driver__: ClassVar[Driver] = Driver.REDIS
    client_manager_cls = RedisClientManager


AnyNoSQLManager = ElasticsearchManager | MongoManager | RedisManager


class SQLManager[C: AnySQLConfig, D: DeclarativeBase](Manager[C]):
    def __init__(
        self,
        Base: type[D],
        config: C,
        log_config: LogConfig,
        publishers: ListOfAnyPublishers,
        application_context: OptApplicationContext = None,
    ) -> None:
        super().__init__(config, log_config, publishers, application_context)
        self._engine_manager = EngineManager[C](config)
        self._session_manager = SessionManager(
            config=config,
            engines=self._engine_manager.get_all(),
            logger=self._logger,
            operation_context=self._operation_context,
            publishers=self._publishers,
            application_context=self._application_context,
        )
        self.Base = Base
        self.Base.metadata.create_all(bind=self._engine_manager.get(Connection.SYNC))

    @property
    def engine(self) -> EngineManager[C]:
        return self._engine_manager

    @property
    def session(self) -> SessionManager:
        return self._session_manager

    async def async_check_connection(
        self,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
    ) -> bool:
        """Check database connectivity by executing a simple query."""
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = SystemOperationAction(
            type=SystemOperationType.DATABASE_CONNECTION, details=None
        )
        executed_at = datetime.now(tz=UTC)
        try:
            async with self._session_manager.get(
                Connection.ASYNC,
                operation_id=operation_id,
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
                impersonation=impersonation,
            ) as session:
                await session.execute(text("SELECT 1"))
                operation = SuccessfulSystemOperation[None](
                    application_context=self._application_context,
                    id=operation_id,
                    context=self._operation_context,
                    action=operation_action,
                    timestamp=Timestamp.completed_now(executed_at),
                    summary="Database connectivity check successful",
                    connection_context=connection_context,
                    authentication=authentication,
                    authorization=authorization,
                    impersonation=impersonation,
                    response=None,
                )
                operation.log_and_publish(self._logger, self._publishers)
            return True
        except Exception:
            return False

    def sync_check_connection(
        self,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
    ) -> bool:
        """Check database connectivity by executing a simple query."""
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = SystemOperationAction(
            type=SystemOperationType.DATABASE_CONNECTION, details=None
        )
        executed_at = datetime.now(tz=UTC)
        try:
            with self._session_manager.get(
                Connection.SYNC,
                operation_id=operation_id,
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
                impersonation=impersonation,
            ) as session:
                session.execute(text("SELECT 1"))
                operation = SuccessfulSystemOperation[None](
                    application_context=self._application_context,
                    id=operation_id,
                    context=self._operation_context,
                    action=operation_action,
                    timestamp=Timestamp.completed_now(executed_at),
                    summary="Database connectivity check successful",
                    connection_context=connection_context,
                    authentication=authentication,
                    authorization=authorization,
                    impersonation=impersonation,
                    response=None,
                )
                operation.log_and_publish(self._logger, self._publishers)
            return True
        except Exception:
            return False

    async def dispose(self):
        self._session_manager.dispose()
        await self._engine_manager.dispose()


class MySQLManager[D: DeclarativeBase](SQLManager[MySQLConfig, D]):
    __driver__: ClassVar[Driver] = Driver.MYSQL
    pass


class PostgreSQLManager[D: DeclarativeBase](SQLManager[PostgreSQLConfig, D]):
    __driver__: ClassVar[Driver] = Driver.POSTGRESQL
    pass


class SQLiteManager[D: DeclarativeBase](SQLManager[SQLiteConfig, D]):
    __driver__: ClassVar[Driver] = Driver.SQLITE
    pass


class SQLServerManager[D: DeclarativeBase](SQLManager[SQLServerConfig, D]):
    __driver__: ClassVar[Driver] = Driver.MSSQL
    pass


AnySQLManager = MySQLManager | PostgreSQLManager | SQLiteManager | SQLServerManager


AnyDatabaseManager = AnySQLManager | AnyNoSQLManager
