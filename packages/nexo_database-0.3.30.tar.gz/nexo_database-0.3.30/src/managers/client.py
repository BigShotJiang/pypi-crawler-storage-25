from typing import Literal, overload

from elasticsearch import AsyncElasticsearch, Elasticsearch
from motor.motor_asyncio import AsyncIOMotorClient
from nexo.schemas.bus import ListOfAnyPublishers
from nexo.types.string import ListOfStrs
from pymongo import MongoClient
from redis import Redis as SyncRedis
from redis.asyncio import Redis as AsyncRedis

from ..config import (
    AnyNoSQLConfig,
    ElasticsearchConfig,
    MongoConfig,
    RedisConfig,
)
from ..enums import Connection

AnyAsyncClient = AsyncElasticsearch | AsyncIOMotorClient | AsyncRedis
AnySyncClient = Elasticsearch | MongoClient | SyncRedis


class ClientManager[C: AnyNoSQLConfig, A: AnyAsyncClient, S: AnySyncClient]:
    def __init__(self, config: C, publishers: ListOfAnyPublishers) -> None:
        self._config = config
        self._publishers = publishers

        self.async_client: A = self._config.create_client(Connection.ASYNC)  # type: ignore
        self.sync_client: S = self._config.create_client(Connection.SYNC)  # type: ignore

    @overload
    def get(self, connection: Literal[Connection.ASYNC]) -> A: ...
    @overload
    def get(self, connection: Literal[Connection.SYNC]) -> S: ...
    def get(self, connection: Connection = Connection.ASYNC) -> A | S:
        if connection is Connection.ASYNC:
            return self.async_client
        elif connection is Connection.SYNC:
            return self.sync_client

    def get_all(self) -> tuple[A, S]:
        return (self.async_client, self.sync_client)

    async def dispose(self):
        if isinstance(self.async_client, AsyncIOMotorClient):
            self.async_client.close()
        elif isinstance(self.async_client, AsyncElasticsearch | AsyncRedis):
            await self.async_client.close()
        self.sync_client.close()


class ElasticsearchClientManager(
    ClientManager[ElasticsearchConfig, AsyncElasticsearch, Elasticsearch]
):
    pass


class MongoClientManager(ClientManager[MongoConfig, AsyncIOMotorClient, MongoClient]):
    pass


class RedisClientManager(ClientManager[RedisConfig, AsyncRedis, SyncRedis]):
    async def async_clear(self, prefixes: ListOfStrs | str | None = None):
        if prefixes is None:
            prefix = ":".join(
                (
                    self._config.identifier.environment,
                    self._config.additional.base_namespace,
                )
            )
            prefixes = [prefix]

        if isinstance(prefixes, str):
            prefixes = [prefixes]

        for prefix in prefixes:
            async for key in self.async_client.scan_iter(f"{prefix}*"):
                await self.async_client.delete(key)

    def sync_clear(self, prefixes: ListOfStrs | str | None = None):
        if prefixes is None:
            prefixes = [self._config.additional.base_namespace]

        if isinstance(prefixes, str):
            prefixes = [prefixes]

        for prefix in prefixes:
            for key in self.sync_client.scan_iter(f"{prefix}*"):
                self.sync_client.delete(key)
