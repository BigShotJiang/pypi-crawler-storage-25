from collections.abc import AsyncGenerator, Generator
from contextlib import (
    AbstractAsyncContextManager,
    AbstractContextManager,
    asynccontextmanager,
    contextmanager,
)
from copy import deepcopy
from datetime import UTC, datetime
from typing import Literal, overload
from uuid import uuid4

from fastapi import HTTPException
from nexo.logging.enums import LogLevel
from nexo.logging.logger import Database
from nexo.schemas.application import ApplicationContext, OptApplicationContext
from nexo.schemas.bus import ListOfAnyPublishers
from nexo.schemas.connection import OptConnectionContext
from nexo.schemas.error.enums import ErrorCode
from nexo.schemas.exception.exc import (
    Conflict,
    InternalServerError,
    MaleoException,
    ServiceUnavailable,
    UnprocessableEntity,
)
from nexo.schemas.exception.factory import MaleoExceptionFactory
from nexo.schemas.extractor import extract_details
from nexo.schemas.operation.action.system import SystemOperationAction
from nexo.schemas.operation.context import Context
from nexo.schemas.operation.enums import OperationType, SystemOperationType
from nexo.schemas.operation.mixins import Timestamp
from nexo.schemas.operation.system import SuccessfulSystemOperation
from nexo.schemas.security.authentication import OptAnyAuthentication
from nexo.schemas.security.authorization import OptAnyAuthorization
from nexo.schemas.security.impersonation import OptImpersonation
from nexo.types.uuid import OptUUID
from pydantic import ValidationError
from sqlalchemy.engine import Engine
from sqlalchemy.exc import (
    DatabaseError,
    IntegrityError,
    OperationalError,
    ProgrammingError,
    SQLAlchemyError,
)
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import Session, sessionmaker

from ..config import AnySQLConfig
from ..enums import Connection


class SessionManager[T: AnySQLConfig]:
    def __init__(
        self,
        config: T,
        engines: tuple[AsyncEngine, Engine],
        logger: Database,
        operation_context: Context,
        publishers: ListOfAnyPublishers,
        application_context: OptApplicationContext = None,
    ):
        self._config = config
        self._async_engine, self._sync_engine = engines
        self._logger = logger
        self._publishers = publishers
        self._application_context = (
            application_context
            if application_context is not None
            else ApplicationContext.new()
        )
        self._operation_context = operation_context
        self._operation_action = SystemOperationAction(
            type=SystemOperationType.DATABASE_CONNECTION, details=None
        )

        self.async_sessionmaker: async_sessionmaker[AsyncSession] = async_sessionmaker[
            AsyncSession
        ](bind=self._async_engine, expire_on_commit=True)
        self.sync_sessionmaker: sessionmaker[Session] = sessionmaker[Session](
            bind=self._sync_engine, expire_on_commit=True
        )

    @overload
    def make(
        self,
        connection: Literal[Connection.ASYNC],
    ) -> AsyncSession: ...
    @overload
    def make(
        self,
        connection: Literal[Connection.SYNC],
    ) -> Session: ...
    def make(
        self,
        connection: Connection = Connection.ASYNC,
    ) -> AsyncSession | Session:
        """Make session."""
        if connection is Connection.ASYNC:
            return self.async_sessionmaker()
        else:
            return self.sync_sessionmaker()

    def make_async(self) -> AsyncSession:
        """Explicit async session."""
        return self.make(Connection.ASYNC)

    def make_sync(self) -> Session:
        """Explicit sync session."""
        return self.make(Connection.SYNC)

    @asynccontextmanager
    async def _async_session_handler(
        self,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ) -> AsyncGenerator[AsyncSession, None]:
        """Reusable function for managing async database session."""
        operation_id = operation_id if operation_id is not None else uuid4()

        common_kwargs = {
            "application_context": self._application_context,
            "connection_context": connection_context,
            "authentication": authentication,
            "authorization": authorization,
            "impersonation": impersonation,
        }

        common_operation_kwargs = deepcopy(common_kwargs)
        common_operation_kwargs.update(
            {
                "id": operation_id,
                "is_ai": is_ai,
                "context": self._operation_context,
                "action": self._operation_action,
            }
        )

        common_exc_kwargs = deepcopy(common_kwargs)
        common_exc_kwargs.update(
            {
                "operation_type": OperationType.SYSTEM,
                "operation_id": operation_id,
                "is_ai_operation": is_ai,
                "operation_context": self._operation_context,
                "operation_action": self._operation_action,
            }
        )

        session: AsyncSession = self.make_async()
        operation = SuccessfulSystemOperation[None](
            **common_operation_kwargs,
            timestamp=Timestamp.now(),
            summary="Successfully created new async database session",
            response=None,
        )
        operation.log_and_publish(self._logger, self._publishers, LogLevel.DEBUG)

        executed_at = datetime.now(tz=UTC)

        try:
            # explicit transaction context —
            # will commit on success,
            # rollback on exception
            async with session.begin():
                yield session
            operation = SuccessfulSystemOperation[None](
                **common_operation_kwargs,
                timestamp=Timestamp.completed_now(executed_at),
                summary="Successfully committed async database transaction",
                response=None,
            )
            operation.log_and_publish(self._logger, self._publishers, LogLevel.DEBUG)
        except IntegrityError as ie:
            await session.rollback()
            exc = Conflict(
                *ie.args,
                details=extract_details(ie),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="IntegrityError while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from ie
                else:
                    raise ie
        except OperationalError as oe:
            await session.rollback()
            exc = ServiceUnavailable(
                *oe.args,
                details=extract_details(oe),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="OperationalError while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from oe
                else:
                    raise oe
        except ProgrammingError as pe:
            await session.rollback()
            exc = InternalServerError(
                *pe.args,
                details=extract_details(pe),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="ProgrammingError while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from pe
                else:
                    raise pe
        except DatabaseError as de:
            await session.rollback()
            exc = InternalServerError(
                *de.args,
                details=extract_details(de),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="DatabaseError while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from de
                else:
                    raise de
        except SQLAlchemyError as se:
            await session.rollback()
            exc = InternalServerError(
                *se.args,
                details=extract_details(se),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="SQLAlchemyError while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from se
                else:
                    raise se
        except ValidationError as ve:
            await session.rollback()
            exc = UnprocessableEntity(
                details=extract_details(ve),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="ValidationError while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from ve
                else:
                    raise ve
        except HTTPException as he:
            await session.rollback()
            exc = MaleoExceptionFactory.from_code(
                he.status_code,
                details=extract_details(he),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="HTTPException while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from he
                else:
                    raise he
        except MaleoException as me:
            await session.rollback()
            me.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                raise me
        except Exception as e:
            await session.rollback()
            code: int | ErrorCode | None = None
            attr_names = ["code", "status_code"]
            for attr_name in attr_names:
                code = getattr(e, attr_name, None)
                if code is not None and isinstance(code, int | ErrorCode):
                    break
            if code is None:
                code = ErrorCode.INTERNAL_SERVER_ERROR
            exc = MaleoExceptionFactory.from_code(
                code,
                details=extract_details(e),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="Unexpected error while handling async session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from e
                else:
                    raise e
        finally:
            await session.close()
            operation = SuccessfulSystemOperation[None](
                **common_operation_kwargs,
                timestamp=Timestamp.now(),
                summary="Successfully closed async database session",
                response=None,
            )
            operation.log_and_publish(self._logger, self._publishers, LogLevel.DEBUG)

    @contextmanager
    def _sync_session_handler(
        self,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ) -> Generator[Session, None, None]:
        """Reusable function for managing sync database session."""
        operation_id = operation_id if operation_id is not None else uuid4()

        common_kwargs = {
            "application_context": self._application_context,
            "connection_context": connection_context,
            "authentication": authentication,
            "authorization": authorization,
            "impersonation": impersonation,
        }

        common_operation_kwargs = deepcopy(common_kwargs)
        common_operation_kwargs.update(
            {
                "id": operation_id,
                "is_ai": is_ai,
                "context": self._operation_context,
                "action": self._operation_action,
            }
        )

        common_exc_kwargs = deepcopy(common_kwargs)
        common_exc_kwargs.update(
            {
                "operation_type": OperationType.SYSTEM,
                "operation_id": operation_id,
                "is_ai_operation": is_ai,
                "operation_context": self._operation_context,
                "operation_action": self._operation_action,
            }
        )

        session: Session = self.make_sync()
        operation = SuccessfulSystemOperation[None](
            **common_operation_kwargs,
            timestamp=Timestamp.now(),
            summary="Successfully created new sync database session",
            response=None,
        )
        operation.log_and_publish(self._logger, self._publishers, LogLevel.DEBUG)

        executed_at = datetime.now(tz=UTC)

        try:
            # explicit transaction context —
            # will commit on success,
            # rollback on exception
            with session.begin():
                yield session
            operation = SuccessfulSystemOperation[None](
                **common_operation_kwargs,
                timestamp=Timestamp.completed_now(executed_at),
                summary="Successfully committed sync database transaction",
                response=None,
            )
            operation.log_and_publish(self._logger, self._publishers, LogLevel.DEBUG)
        except IntegrityError as ie:
            session.rollback()
            exc = Conflict(
                *ie.args,
                details=extract_details(ie),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="IntegrityError while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from ie
                else:
                    raise ie
        except OperationalError as oe:
            session.rollback()
            exc = ServiceUnavailable(
                *oe.args,
                details=extract_details(oe),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="OperationalError while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from oe
                else:
                    raise oe
        except ProgrammingError as pe:
            session.rollback()
            exc = InternalServerError(
                *pe.args,
                details=extract_details(pe),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="ProgrammingError while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from pe
                else:
                    raise pe
        except DatabaseError as de:
            session.rollback()
            exc = InternalServerError(
                *de.args,
                details=extract_details(de),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="DatabaseError while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from de
                else:
                    raise de
        except SQLAlchemyError as se:
            session.rollback()
            exc = InternalServerError(
                *se.args,
                details=extract_details(se),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="SQLAlchemyError while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from se
                else:
                    raise se
        except ValidationError as ve:
            session.rollback()
            exc = UnprocessableEntity(
                details=extract_details(ve),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="ValidationError while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from ve
                else:
                    raise ve
        except HTTPException as he:
            session.rollback()
            exc = MaleoExceptionFactory.from_code(
                he.status_code,
                details=extract_details(he),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="HTTPException while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from he
                else:
                    raise he
        except MaleoException as me:
            session.rollback()
            me.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                raise me
        except Exception as e:
            session.rollback()
            code: int | ErrorCode | None = None
            attr_names = ["code", "status_code"]
            for attr_name in attr_names:
                code = getattr(e, attr_name, None)
                if code is not None and isinstance(code, int | ErrorCode):
                    break
            if code is None:
                code = ErrorCode.INTERNAL_SERVER_ERROR
            exc = MaleoExceptionFactory.from_code(
                code,
                details=extract_details(e),
                **common_exc_kwargs,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary="Unexpected error while handling sync session",
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            if raise_exc:
                if raise_as_maleo_exception:
                    raise exc from e
                else:
                    raise e
        finally:
            session.close()
            operation = SuccessfulSystemOperation[None](
                **common_operation_kwargs,
                timestamp=Timestamp.now(),
                summary="Successfully closed sync database session",
                response=None,
            )
            operation.log_and_publish(self._logger, self._publishers, LogLevel.DEBUG)

    def get_async(
        self,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ) -> AbstractAsyncContextManager[AsyncSession]:
        """Explicit async context manager."""
        return self._async_session_handler(
            operation_id,
            is_ai,
            connection_context,
            authentication,
            authorization,
            impersonation,
            raise_exc,
            raise_as_maleo_exception,
        )

    def get_sync(
        self,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ) -> AbstractContextManager[Session]:
        """Explicit sync context manager."""
        return self._sync_session_handler(
            operation_id,
            is_ai,
            connection_context,
            authentication,
            authorization,
            impersonation,
            raise_exc,
            raise_as_maleo_exception,
        )

    @overload
    def get(
        self,
        connection: Literal[Connection.ASYNC],
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ) -> AbstractAsyncContextManager[AsyncSession]: ...

    @overload
    def get(
        self,
        connection: Literal[Connection.SYNC],
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ) -> AbstractContextManager[Session]: ...

    def get(
        self,
        connection: Connection = Connection.ASYNC,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ) -> AbstractAsyncContextManager[AsyncSession] | AbstractContextManager[Session]:
        """Context manager for manual session handling."""
        if connection is Connection.ASYNC:
            return self.get_async(
                operation_id,
                is_ai,
                connection_context,
                authentication,
                authorization,
                impersonation,
                raise_exc,
                raise_as_maleo_exception,
            )
        else:
            return self.get_sync(
                operation_id,
                is_ai,
                connection_context,
                authentication,
                authorization,
                impersonation,
                raise_exc,
                raise_as_maleo_exception,
            )

    def as_async_dependency(
        self,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ):
        """Explicit async dependency injection."""

        async def dependency() -> AsyncGenerator[AsyncSession, None]:
            # By using `async with` here, exceptions thrown in FastAPI
            # safely flow back up into `get_async`
            async with self.get_async(
                operation_id,
                is_ai,
                connection_context,
                authentication,
                authorization,
                impersonation,
                raise_exc,
                raise_as_maleo_exception,
            ) as session:
                yield session

        return dependency

    def as_sync_dependency(
        self,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        raise_exc: bool = True,
        raise_as_maleo_exception: bool = True,
    ):
        """Explicit sync dependency injection."""

        def dependency() -> Generator[Session, None, None]:
            with self.get_sync(
                operation_id,
                is_ai,
                connection_context,
                authentication,
                authorization,
                impersonation,
                raise_exc,
                raise_as_maleo_exception,
            ) as session:
                yield session

        return dependency

    def dispose(self):
        self.sync_sessionmaker.close_all()
