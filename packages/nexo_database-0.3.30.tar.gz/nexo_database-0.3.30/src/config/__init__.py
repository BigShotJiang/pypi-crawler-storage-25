from typing import Annotated, Literal, overload

from elasticsearch import AsyncElasticsearch, Elasticsearch
from motor.motor_asyncio import AsyncIOMotorClient
from nexo.enums.environment import OptEnvironment
from nexo.types.dict import StrToAnyDict
from nexo.types.string import OptStr
from pydantic import BaseModel, Field
from pymongo import MongoClient
from redis import Redis as SyncRedis
from redis.asyncio import Redis as AsyncRedis
from sqlalchemy.engine import Engine
from sqlalchemy.engine import create_engine as create_sync_engine
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

from ..enums import CacheLayer, CacheOrigin, Connection
from ..utils import build_cache_namespace
from .additional import OptBaseAdditionalConfig, RedisAdditionalConfig
from .connection import (
    BaseConnectionConfig,
    ElasticsearchConnectionConfig,
    MongoConnectionConfig,
    MySQLConnectionConfig,
    PostgreSQLConnectionConfig,
    RedisConnectionConfig,
    SQLiteConnectionConfig,
    SQLServerConnectionConfig,
)
from .identifier import DatabaseIdentifierConfig
from .pooling import (
    BasePoolingConfig,
    ElasticsearchPoolingConfig,
    MongoPoolingConfig,
    MySQLPoolingConfig,
    PostgreSQLPoolingConfig,
    RedisPoolingConfig,
    SQLitePoolingConfig,
    SQLServerPoolingConfig,
)


class BaseConfig[
    C: BaseConnectionConfig,
    P: BasePoolingConfig,
    A: OptBaseAdditionalConfig,
](BaseModel):
    """Base configuration for database."""

    identifier: Annotated[
        DatabaseIdentifierConfig, Field(..., description="Identifier config")
    ]
    connection: Annotated[C, Field(..., description="Connection config")]
    pooling: Annotated[P, Field(..., description="Pooling config")]
    additional: Annotated[A, Field(..., description="Additional config")]


class ElasticsearchConfig(
    BaseConfig[
        ElasticsearchConnectionConfig,
        ElasticsearchPoolingConfig,
        None,
    ]
):
    additional: None = None

    @property
    def client_kwargs(self) -> StrToAnyDict:
        client_kwargs = {}

        if self.connection.username and self.connection.password:
            client_kwargs["http_auth"] = (
                self.connection.username,
                self.connection.password,
            )

        client_kwargs.update(self.pooling.client_kwargs)

        return client_kwargs

    @overload
    def create_client(
        self, connection: Literal[Connection.ASYNC]
    ) -> AsyncElasticsearch: ...
    @overload
    def create_client(self, connection: Literal[Connection.SYNC]) -> Elasticsearch: ...
    def create_client(
        self, connection: Connection
    ) -> AsyncElasticsearch | Elasticsearch:
        hosts = [{"host": self.connection.host, "port": self.connection.port}]
        if connection is Connection.ASYNC:
            return AsyncElasticsearch(hosts, **self.client_kwargs)
        else:
            return Elasticsearch(hosts, **self.client_kwargs)


class ElasticsearchConfigs(BaseModel):
    primary: Annotated[
        ElasticsearchConfig, Field(..., description="Primary Elasticsearch config")
    ]


OptElasticsearchConfigs = ElasticsearchConfigs | None


class MongoConfig(
    BaseConfig[
        MongoConnectionConfig,
        MongoPoolingConfig,
        None,
    ]
):
    additional: None = None

    @property
    def client_kwargs(self) -> StrToAnyDict:
        return self.pooling.client_kwargs

    @overload
    def create_client(
        self, connection: Literal[Connection.ASYNC]
    ) -> AsyncIOMotorClient: ...
    @overload
    def create_client(self, connection: Literal[Connection.SYNC]) -> MongoClient: ...
    def create_client(self, connection: Connection) -> AsyncIOMotorClient | MongoClient:
        url = self.connection.make_url(connection)
        if connection is Connection.ASYNC:
            return AsyncIOMotorClient(url, **self.client_kwargs)
        else:
            return MongoClient(url, **self.client_kwargs)


class MongoConfigs(BaseModel):
    primary: Annotated[MongoConfig, Field(..., description="Primary Mongo config")]


OptMongoConfigs = MongoConfigs | None


class RedisConfig(
    BaseConfig[
        RedisConnectionConfig,
        RedisPoolingConfig,
        RedisAdditionalConfig,
    ]
):
    additional: RedisAdditionalConfig = Field(..., description="Additional config")

    @property
    def client_kwargs(self) -> StrToAnyDict:
        return self.pooling.client_kwargs

    @overload
    def create_client(self, connection: Literal[Connection.ASYNC]) -> AsyncRedis: ...
    @overload
    def create_client(self, connection: Literal[Connection.SYNC]) -> SyncRedis: ...
    def create_client(self, connection: Connection) -> AsyncRedis | SyncRedis:
        url = self.connection.make_url(connection)
        if connection is Connection.ASYNC:
            return AsyncRedis.from_url(url, **self.client_kwargs)
        else:
            return SyncRedis.from_url(url, **self.client_kwargs)

    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[False],
        environment: OptEnvironment = None,
        use_self_base: Literal[False],
        base: OptStr = None,
        origin: Literal[CacheOrigin.SERVICE],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[False],
        environment: OptEnvironment = None,
        use_self_base: Literal[False],
        base: OptStr = None,
        client: str,
        origin: Literal[CacheOrigin.CLIENT],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[False],
        environment: OptEnvironment = None,
        use_self_base: Literal[True] = True,
        origin: Literal[CacheOrigin.SERVICE],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[False],
        environment: OptEnvironment = None,
        use_self_base: Literal[True] = True,
        client: str,
        origin: Literal[CacheOrigin.CLIENT],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[True] = True,
        use_self_base: Literal[False],
        base: OptStr = None,
        origin: Literal[CacheOrigin.SERVICE],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[True] = True,
        use_self_base: Literal[False],
        base: OptStr = None,
        client: str,
        origin: Literal[CacheOrigin.CLIENT],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[True] = True,
        use_self_base: Literal[True] = True,
        origin: Literal[CacheOrigin.SERVICE],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    @overload
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: Literal[True] = True,
        use_self_base: Literal[True] = True,
        client: str,
        origin: Literal[CacheOrigin.CLIENT],
        layer: CacheLayer,
        sep: str = ":",
    ) -> str: ...
    def build_namespace(
        self,
        *ext: str,
        use_self_environment: bool = True,
        environment: OptEnvironment = None,
        use_self_base: bool = True,
        base: OptStr = None,
        client: OptStr = None,
        origin: CacheOrigin,
        layer: CacheLayer,
        sep: str = ":",
    ) -> str:
        if use_self_environment:
            final_environment = self.identifier.environment
        else:
            final_environment = environment

        if use_self_base:
            final_base = self.additional.base_namespace
        else:
            final_base = base

        if origin is CacheOrigin.CLIENT:
            if client is None:
                raise ValueError(
                    "Argument 'client' can not be None if origin is client"
                )

            return build_cache_namespace(
                *ext,
                environment=final_environment,
                base=final_base,
                client=client,
                origin=origin,
                layer=layer,
                sep=sep,
            )

        return build_cache_namespace(
            *ext,
            environment=final_environment,
            base=final_base,
            origin=origin,
            layer=layer,
            sep=sep,
        )

    def build_client_namespace(
        self,
        *ext: str,
        use_self_environment: bool = True,
        environment: OptEnvironment = None,
        use_self_base: bool = True,
        base: OptStr = None,
        client: str,
        layer: CacheLayer = CacheLayer.SERVICE,
        sep: str = ":",
    ) -> str:
        return self.build_namespace(
            *ext,
            use_self_environment=use_self_environment,  # type: ignore
            environment=environment,
            use_self_base=use_self_base,  # type: ignore
            base=base,
            client=client,
            origin=CacheOrigin.CLIENT,
            layer=layer,
            sep=sep,
        )

    def build_service_namespace(
        self,
        *ext: str,
        use_self_environment: bool = True,
        environment: OptEnvironment = None,
        use_self_base: bool = True,
        base: OptStr = None,
        layer: CacheLayer = CacheLayer.SERVICE,
        sep: str = ":",
    ) -> str:
        return self.build_namespace(
            *ext,
            use_self_environment=use_self_environment,  # type: ignore
            environment=environment,
            use_self_base=use_self_base,  # type: ignore
            base=base,
            origin=CacheOrigin.SERVICE,
            layer=layer,
            sep=sep,
        )


class RedisConfigs(BaseModel):
    primary: Annotated[RedisConfig, Field(..., description="Primary Redis config")]


OptRedisConfigs = RedisConfigs | None


AnyNoSQLConfig = ElasticsearchConfig | MongoConfig | RedisConfig
OptAnyNoSQLConfig = AnyNoSQLConfig | None
AnyNoSQLConfigs = ElasticsearchConfigs | MongoConfigs | RedisConfigs
OptAnyNoSQLConfigs = AnyNoSQLConfigs | None


class NoSQLConfigs[
    E: OptElasticsearchConfigs,
    M: OptMongoConfigs,
    R: OptRedisConfigs,
](BaseModel):
    elasticsearch: Annotated[E, Field(..., description="Elasticsearch configs")]
    mongo: Annotated[M, Field(..., description="Mongo configs")]
    redis: Annotated[R, Field(..., description="Redis configs")]


OptNoSQLConfigs = NoSQLConfigs | None


class MySQLConfig(
    BaseConfig[
        MySQLConnectionConfig,
        MySQLPoolingConfig,
        None,
    ]
):
    additional: None = None

    @property
    def engine_kwargs(self) -> StrToAnyDict:
        return {
            **self.connection.engine_kwargs,
            **self.pooling.engine_kwargs,
        }

    @overload
    def create_engine(self, connection: Literal[Connection.ASYNC]) -> AsyncEngine: ...
    @overload
    def create_engine(self, connection: Literal[Connection.SYNC]) -> Engine: ...
    def create_engine(self, connection: Connection) -> AsyncEngine | Engine:
        url = self.connection.make_url(connection)
        if connection is Connection.ASYNC:
            return create_async_engine(url, **self.engine_kwargs)
        elif connection is Connection.SYNC:
            return create_sync_engine(url, **self.engine_kwargs)


class MySQLConfigs(BaseModel):
    primary: Annotated[MySQLConfig, Field(..., description="Primary MySQL config")]


OptMySQLConfigs = MySQLConfigs | None


class PostgreSQLConfig(
    BaseConfig[
        PostgreSQLConnectionConfig,
        PostgreSQLPoolingConfig,
        None,
    ]
):
    additional: None = None

    @property
    def engine_kwargs(self) -> StrToAnyDict:
        return {
            **self.connection.engine_kwargs,
            **self.pooling.engine_kwargs,
        }

    @overload
    def create_engine(self, connection: Literal[Connection.ASYNC]) -> AsyncEngine: ...
    @overload
    def create_engine(self, connection: Literal[Connection.SYNC]) -> Engine: ...
    def create_engine(self, connection: Connection) -> AsyncEngine | Engine:
        url = self.connection.make_url(connection)
        if connection is Connection.ASYNC:
            return create_async_engine(url, **self.engine_kwargs)
        elif connection is Connection.SYNC:
            return create_sync_engine(url, **self.engine_kwargs)


class PostgreSQLConfigs(BaseModel):
    primary: Annotated[
        PostgreSQLConfig, Field(..., description="Primary PostgreSQL config")
    ]


OptPostgreSQLConfigs = PostgreSQLConfigs | None


class SQLiteConfig(
    BaseConfig[
        SQLiteConnectionConfig,
        SQLitePoolingConfig,
        None,
    ]
):
    additional: None = None

    @property
    def engine_kwargs(self) -> StrToAnyDict:
        return {
            **self.connection.engine_kwargs,
            **self.pooling.engine_kwargs,
        }

    @overload
    def create_engine(self, connection: Literal[Connection.ASYNC]) -> AsyncEngine: ...
    @overload
    def create_engine(self, connection: Literal[Connection.SYNC]) -> Engine: ...
    def create_engine(self, connection: Connection) -> AsyncEngine | Engine:
        url = self.connection.make_url(connection)
        if connection is Connection.ASYNC:
            return create_async_engine(url, **self.engine_kwargs)
        elif connection is Connection.SYNC:
            return create_sync_engine(url, **self.engine_kwargs)


class SQLiteConfigs(BaseModel):
    primary: Annotated[SQLiteConfig, Field(..., description="Primary SQLite config")]


OptSQLiteConfigs = SQLiteConfigs | None


class SQLServerConfig(
    BaseConfig[
        SQLServerConnectionConfig,
        SQLServerPoolingConfig,
        None,
    ]
):
    additional: None = None

    @property
    def engine_kwargs(self) -> StrToAnyDict:
        return {
            **self.connection.engine_kwargs,
            **self.pooling.engine_kwargs,
        }

    @overload
    def create_engine(self, connection: Literal[Connection.ASYNC]) -> AsyncEngine: ...
    @overload
    def create_engine(self, connection: Literal[Connection.SYNC]) -> Engine: ...
    def create_engine(self, connection: Connection) -> AsyncEngine | Engine:
        url = self.connection.make_url(connection)
        if connection is Connection.ASYNC:
            return create_async_engine(url, **self.engine_kwargs)
        elif connection is Connection.SYNC:
            return create_sync_engine(url, **self.engine_kwargs)


class SQLServerConfigs(BaseModel):
    primary: Annotated[
        SQLServerConfig, Field(..., description="Primary SQLServer config")
    ]


OptSQLServerConfigs = SQLServerConfigs | None


AnySQLConfig = MySQLConfig | PostgreSQLConfig | SQLiteConfig | SQLServerConfig
OptAnySQLConfig = AnySQLConfig | None
AnySQLConfigs = MySQLConfigs | PostgreSQLConfigs | SQLiteConfigs | SQLServerConfigs
OptAnySQLConfigs = AnySQLConfigs | None


AnyDatabaseConfig = AnyNoSQLConfig | AnySQLConfig
OptAnyDatabaseConfig = AnyDatabaseConfig | None


class SQLConfigs[
    M: OptMySQLConfigs,
    P: OptPostgreSQLConfigs,
    L: OptSQLiteConfigs,
    S: OptSQLServerConfigs,
](BaseModel):
    mysql: Annotated[M, Field(..., description="MySQL configs")]
    postgresql: Annotated[P, Field(..., description="PostgreSQL configs")]
    sqlite: Annotated[L, Field(..., description="SQLite configs")]
    sqlserver: Annotated[S, Field(..., description="SQLServer configs")]


OptSQLConfigs = SQLConfigs | None


class DatabaseConfigs[N: OptNoSQLConfigs, S: OptSQLConfigs](BaseModel):
    nosql: Annotated[N, Field(..., description="NoSQL configs")]
    sql: Annotated[S, Field(..., description="SQL configs")]


OptDatabaseConfigs = DatabaseConfigs | None


class DatabaseConfigsMixin[T: OptDatabaseConfigs](BaseModel):
    database: Annotated[T, Field(..., description="Database configs")]
