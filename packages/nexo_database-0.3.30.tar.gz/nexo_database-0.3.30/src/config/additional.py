from typing import Annotated

from nexo.enums.expiration import Expiration
from pydantic import BaseModel, Field


class BaseAdditionalConfig(BaseModel):
    """Base additional configuration class for database."""


OptBaseAdditionalConfig = BaseAdditionalConfig | None


class RedisAdditionalConfig(BaseAdditionalConfig):
    ttl: Annotated[
        float | int | Expiration,
        Field(Expiration.EXP_15MN.value, description="Time to live"),
    ] = Expiration.EXP_15MN.value
    base_namespace: Annotated[str, Field(..., description="Base namespace")]
