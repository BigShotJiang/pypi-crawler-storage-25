from typing import Any, TypeVar

from sqlalchemy.sql import Delete, Select, Update

RowT = TypeVar("RowT", bound=tuple[Any, ...])
AnyStmt = Delete | Select[RowT] | Update
AnyStmtT = TypeVar("AnyStmtT", bound=AnyStmt)
