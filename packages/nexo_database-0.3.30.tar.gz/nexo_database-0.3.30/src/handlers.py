from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import DeclarativeBase

from .config import (
    AnyDatabaseConfig,
    ElasticsearchConfig,
    MongoConfig,
    MySQLConfig,
    PostgreSQLConfig,
    RedisConfig,
    SQLiteConfig,
    SQLServerConfig,
)
from .managers import (
    AnyDatabaseManager,
    ElasticsearchManager,
    MongoManager,
    MySQLManager,
    PostgreSQLManager,
    RedisManager,
    SQLiteManager,
    SQLServerManager,
)


class Handler[C: AnyDatabaseConfig, M: AnyDatabaseManager](BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: Annotated[C, Field(..., description="Config")]
    manager: Annotated[M, Field(..., description="Manager")]


class ElasticsearchHandler(Handler[ElasticsearchConfig, ElasticsearchManager]):
    pass


class MongoHandler(Handler[MongoConfig, MongoManager]):
    pass


class RedisHandler(Handler[RedisConfig, RedisManager]):
    pass


class MySQLHandler[D: DeclarativeBase](Handler[MySQLConfig, MySQLManager[D]]):
    pass


class PostgreSQLHandler[D: DeclarativeBase](
    Handler[PostgreSQLConfig, PostgreSQLManager[D]]
):
    pass


class SQLiteHandler[D: DeclarativeBase](Handler[SQLiteConfig, SQLiteManager[D]]):
    pass


class SQLServerHandler[D: DeclarativeBase](
    Handler[SQLServerConfig, SQLServerManager[D]]
):
    pass


class BaseHandlers[T: Handler](BaseModel):
    primary: Annotated[T, Field(..., description="Primary handler")]


OptBaseHandlers = BaseHandlers | None


class ElasticsearchHandlers(BaseHandlers[ElasticsearchHandler]):
    pass


OptElasticsearchHandlers = ElasticsearchHandlers | None


class MongoHandlers(BaseHandlers[MongoHandler]):
    pass


OptMongoHandlers = MongoHandlers | None


class RedisHandlers(BaseHandlers[RedisHandler]):
    pass


OptRedisHandlers = RedisHandlers | None


class NoSQLHandlers[
    E: OptElasticsearchHandlers,
    M: OptMongoHandlers,
    R: OptRedisHandlers,
](BaseModel):
    elasticsearch: Annotated[E, Field(..., description="Elasticsearch handlers")]
    mongo: Annotated[M, Field(..., description="Mongo handlers")]
    redis: Annotated[R, Field(..., description="Redis handlers")]


OptNoSQLHandlers = NoSQLHandlers | None


class MySQLHandlers[D: DeclarativeBase](BaseHandlers[MySQLHandler[D]]):
    pass


OptMySQLHandlers = MySQLHandlers | None


class PostgreSQLHandlers[D: DeclarativeBase](BaseHandlers[PostgreSQLHandler[D]]):
    pass


OptPostgreSQLHandlers = PostgreSQLHandlers | None


class SQLiteHandlers[D: DeclarativeBase](BaseHandlers[SQLiteHandler[D]]):
    pass


OptSQLiteHandlers = SQLiteHandlers | None


class SQLServerHandlers[D: DeclarativeBase](BaseHandlers[SQLServerHandler[D]]):
    pass


OptSQLServerHandlers = SQLServerHandlers | None


class SQLHandlers[
    M: OptMySQLHandlers,
    P: OptPostgreSQLHandlers,
    L: OptSQLiteHandlers,
    S: OptSQLServerHandlers,
](BaseModel):
    mysql: Annotated[M, Field(..., description="MySQL handlers")]
    postgresql: Annotated[P, Field(..., description="PostgreSQL handlers")]
    sqlite: Annotated[L, Field(..., description="SQLite handlers")]
    sqlserver: Annotated[S, Field(..., description="SQLServer handlers")]


OptSQLHandlers = SQLHandlers | None


class DatabaseHandlers[N: OptNoSQLHandlers, S: OptSQLHandlers](BaseModel):
    nosql: Annotated[N, Field(..., description="NoSQL handlers")]
    sql: Annotated[S, Field(..., description="SQL handlers")]


OptDatabaseHandlers = DatabaseHandlers | None
