import logging
import os
from pathlib import Path
from typing import Any

import yaml
from pydantic_market_data.models import Currency, SecurityQuery, Symbol

from .interfaces import SearchResult
from .models import AssetClass, Instrument, InstrumentFile, InstrumentType, _map_asset_class
from .resources import get_instrument_files

logger = logging.getLogger(__name__)


class StrictSafeLoader(yaml.SafeLoader):
    """YAML Loader that disallows duplicate keys."""

    def construct_mapping(self, node: yaml.MappingNode, deep: bool = False) -> dict[Any, Any]:
        seen_keys: set = set()
        for key_node, _value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            if key in seen_keys:
                raise yaml.constructor.ConstructorError(
                    f"Duplicate key found in YAML: {key}", key_node.start_mark
                )
            seen_keys.add(key)
        return super().construct_mapping(node, deep=deep)


class InstrumentRegistry:
    def __init__(self, include_bundled: bool = True, extra_paths: list[Path] | None = None):
        self._instruments: list[Instrument] = []
        self._load_errors: list[str] = []
        self._by_isin: dict[str, list[Instrument]] = {}
        self._by_figi: dict[str, Instrument] = {}
        self._by_name: dict[str, list[Instrument]] = {}
        self._by_ticker: dict[str, Instrument] = {}  # Map "PROVIDER:TICKER" -> Instrument

        if include_bundled:
            self.load_bundled_data()

        if extra_paths:
            for p in extra_paths:
                self.load_path(p)

        self._rebuild_indices()

    def load_bundled_data(self):
        """Loads all instrument data from the bundled YAML files."""
        logger.debug("Loading bundled registry data...")
        for file_path in get_instrument_files():
            self._load_file(file_path)

    def load_path(self, path: Path):
        """Loads instrument data from a specific file or directory recursively."""
        logger.debug(f"Loading user registry path: {path}")
        if path.is_dir():
            for p in sorted(path.rglob("*")):
                if p.is_file() and p.suffix in (".yaml", ".yml"):
                    self._load_file(p)
        else:
            self._load_file(path)

    def _load_file(self, path: Path):
        if not path.exists():
            return
        logger.debug(f"Loading registry file: {path}")
        with open(path) as f:
            data = yaml.load(f, Loader=StrictSafeLoader)  # nosec B506

        if not data:
            return

        file_model = InstrumentFile(**data)
        self._instruments.extend(file_model.instruments)

    @property
    def load_errors(self) -> list[str]:
        return self._load_errors

    def _rebuild_indices(self):
        self._by_isin = {}
        for c in self._instruments:
            if c.isin:
                isin_key = str(c.isin).upper()
                if isin_key not in self._by_isin:
                    self._by_isin[isin_key] = []
                self._by_isin[isin_key].insert(0, c)  # User overrides first

        self._by_figi = {}
        self._by_name = {}
        for c in self._instruments:
            name_key = c.name.upper()
            if name_key not in self._by_name:
                self._by_name[name_key] = []
            self._by_name[name_key].insert(0, c)

        self._by_ticker = {}

        for c in self._instruments:
            if c.figi:
                self._by_figi[c.figi.upper()] = c

            if c.tickers:
                for provider, ticker in c.tickers.model_dump().items():
                    if ticker:
                        # Later items in self._instruments override earlier ones
                        self._by_ticker[f"{provider.upper()}:{str(ticker).upper()}"] = c

    def find_by_isin(self, isin: str, currency: Currency | None = None) -> Instrument | None:
        matches = self.find_candidates(SecurityQuery(isin=isin, currency=currency))
        return matches[0] if matches else None

    def find_candidates(self, criteria: SecurityQuery) -> list[Instrument]:
        """
        Finds all instruments matching the criteria using strict field lookups.
        Returns empty list if no match.
        """
        candidates = []

        # 1. Try ISIN (Strict)
        if criteria.isin:
            candidates.extend(self._by_isin.get(str(criteria.isin).upper(), []))

        # 2. Try Name/Symbol (Strict)
        if criteria.symbol:
            sym_upper = str(criteria.symbol).upper()
            sym_matches = self._by_name.get(sym_upper, [])
            candidates.extend(sym_matches)

        # 3. Try FIGI (Strict)
        if criteria.figi:
            figi_match = self._by_figi.get(str(criteria.figi).upper())
            if figi_match and figi_match not in candidates:
                candidates.append(figi_match)

        # 4. Filter by Asset Class if provided
        if criteria.asset_class:
            target_ac = _map_asset_class(criteria.asset_class)
            if not target_ac:
                # If an asset class was requested but is unrecognizable,
                # we must fail the registry lookup to prevent incorrect matches.
                return []

            candidates = [c for c in candidates if _map_asset_class(c.asset_class) == target_ac]

        # Deduplicate (by name + asset_class to allow multiple types of same symbol)
        seen = set()
        unique_candidates = []
        for c in candidates:
            # Note: We use name+asset_class as unique key in this context
            # to allow TRX(Stock) and TRX(Crypto) to both be returned if needed.
            key = (c.name.upper(), c.asset_class)
            if key not in seen:
                unique_candidates.append(c)
                seen.add(key)

        # 5. Filter by Currency if provided
        if criteria.currency:
            curr_str = str(criteria.currency)
            unique_candidates = [
                c for c in unique_candidates if str(c.currency).upper() == curr_str.upper()
            ]

        return unique_candidates

    def find_by_ticker(self, provider: str, symbol: Symbol | str) -> Instrument | None:
        """
        Finds an instrument by provider-specific ticker.
        Example: find_by_ticker("yahoo", "4GLD.DE")
        """
        ticker_str = symbol.root if isinstance(symbol, Symbol) else symbol
        return self._by_ticker.get(f"{provider.upper()}:{ticker_str.upper()}")

    def get_all(self) -> list[Instrument]:
        return self._instruments


# Default registry if imported directly
def get_registry(
    include_bundled: bool = True, extra_paths: list[Path] | None = None
) -> InstrumentRegistry:
    if not extra_paths:
        env_path = os.getenv("INSTRUMENT_REGISTRY_PATH")
        if env_path:
            extra_paths = [Path(env_path).expanduser()]
        else:
            # Use platformdirs default
            import platformdirs

            default_dir = Path(platformdirs.user_data_dir("instrument-registry"))
            if default_dir.exists():
                extra_paths = [default_dir]

    return InstrumentRegistry(include_bundled=include_bundled, extra_paths=extra_paths)


def add_instrument(
    criteria: SecurityQuery,
    metadata: SearchResult | None,  # None if not found online
    target_path: Path,
    instrument_type: InstrumentType | None = None,
    asset_class: AssetClass | None = None,
    name: str | None = None,
    dry_run: bool = False,
    registry: InstrumentRegistry | None = None,
    country: str | None = None,
    ibkr: int | None = None,
) -> Instrument:
    """
    Adds a new instrument to the registry.

    Uses SecurityQuery.symbol (the raw token or security symbol).
    Extracts base ticker (before ':') for Beancount name.
    Stores provider-specific tickers only if found online.
    """
    if metadata:
        if instrument_type is None:
            instrument_type = metadata.instrument_type
        if asset_class is None:
            asset_class = metadata.asset_class

    # 1. Determine ticker
    if not criteria.symbol and not name:
        if not metadata or not metadata.symbol:
            raise ValueError("SecurityQuery.symbol or name is required if metadata fetch failed")
        criteria.symbol = str(metadata.symbol)

    # 2. Extract base ticker for Beancount name
    # Example: "ALUM.L" -> "ALUM", "4GLD:GER:EUR" -> "4GLD"
    if name:
        clean_name = name
    else:
        # Prefer online metadata ticker if available, otherwise fallback to criteria.symbol
        token = str(metadata.symbol) if metadata and metadata.symbol else str(criteria.symbol or "")
        if not token:
            # Should not happen given check in step 1, but for mypy
            raise ValueError("Could not determine ticker for name generation")

        # For CASH instruments, prefer use the name (e.g. "EUR") if it is a 3-letter code.
        is_fx = instrument_type == InstrumentType.CASH or asset_class == AssetClass.CASH
        if is_fx and metadata and metadata.name and len(str(metadata.name)) == 3:
            clean_name = str(metadata.name)
        else:
            # Simple extraction: "ALUM.L" -> "ALUM", "^GSPC" -> "^GSPC"
            # But let's be careful with providers. If it's "YAHOO:^GSPC", we want "^GSPC".
            clean_name = token.split(":")[-1]

    # 3. Collision check against entire registry
    if registry:
        existing = registry.find_candidates(SecurityQuery(symbol=clean_name))
        for match in existing:
            # If name matches but ISIN is different, it's a collision
            # unless one of them is missing ISIN (like CASH).
            # If both are same name, same asset class, same currency, we allow it (update).
            # If it's a name collision with a different asset class, we warn/error.
            if match.asset_class != asset_class:
                raise ValueError(
                    f"Name collision: '{clean_name}' is already registered as {match.asset_class}. "
                    f"Refusing to add as {asset_class}."
                )

    # 4. Build tickers dict (prefer online metadata, fallback to criteria.symbol)
    tickers_dict: dict[str, Any] | None = None
    if metadata and metadata.symbol:
        tickers_dict = {metadata.provider.value: str(metadata.symbol)}
    elif criteria.symbol:
        symbol_str = str(criteria.symbol)
        # Fallback to yahoo for manual tickers unless it contains a provider prefix
        if ":" in symbol_str:
            parts = symbol_str.split(":", 1)
            tickers_dict = {parts[0].lower(): parts[1]}
        else:
            tickers_dict = {"yahoo": symbol_str}

    if ibkr:
        if not tickers_dict:
            tickers_dict = {}
        tickers_dict["ibkr"] = ibkr

    # 4. Create instrument
    if instrument_type is None:
        raise ValueError(
            "--instrument-type is required (could not be inferred from provider metadata)"
        )
    if asset_class is None:
        raise ValueError("--asset-class is required (could not be inferred from provider metadata)")

    from .models import Tickers, ValidationPoint

    comm_currency = (
        Currency(str(criteria.currency).upper())
        if criteria.currency
        else (metadata.currency if metadata and metadata.currency else Currency("USD"))
    )

    instrument = Instrument(
        name=clean_name,
        isin=criteria.isin,
        figi=None,
        instrument_type=instrument_type,
        asset_class=asset_class,
        currency=comm_currency,
        tickers=Tickers(**tickers_dict) if tickers_dict else None,
        validation_points=(
            [ValidationPoint(date=criteria.price_on.date, price=criteria.price_on.price)]
            if criteria.price_on
            else None
        ),
        country=country or (metadata.country if metadata else None),
        metadata=metadata.metadata if metadata else None,
    )

    # 5. Save to file
    _save_instrument_to_file(instrument, target_path, dry_run=dry_run)

    return instrument


def _save_instrument_to_file(instrument: Instrument, target_path: Path, dry_run: bool = False):
    """
    Saves an instrument to the specified YAML file.
    Handles duplicate checks (ISIN/Name) by reading existing file content first.
    """
    if dry_run:
        logger.info(f"[DRY RUN] Would save to: {target_path}")
        print(
            yaml.dump(
                {"instruments": [instrument.model_dump(mode="json", exclude_none=True)]},
                sort_keys=False,
            )
        )
        return

    data = None

    if target_path.suffix == "" or target_path.is_dir():
        target_path.mkdir(parents=True, exist_ok=True)
        target_path = target_path / "manual.yaml"
    else:
        target_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing to check duplicates
    existing_instruments = []
    if target_path.exists():
        with open(target_path) as f:
            data = yaml.load(f, Loader=StrictSafeLoader)  # nosec B506
            if data:
                # Handle both list and dict formats
                if isinstance(data, list):
                    existing_instruments = data
                elif isinstance(data, dict) and "instruments" in data:
                    existing_instruments = data["instruments"]

    # Check for duplicates and update if needed
    for i, existing in enumerate(existing_instruments):
        match = False
        if isinstance(existing, dict):
            # Step 1: Strict match by ISIN + Currency
            if (
                existing.get("isin") == str(instrument.isin) if instrument.isin else False
            ) and existing.get("currency") == str(instrument.currency):
                logger.info(
                    f"Updating existing record for {instrument.name} "
                    f"({instrument.currency}) via ISIN match"
                )
                match = True
            # Step 2: Fallback to Name match
            elif existing.get("name") == instrument.name:
                logger.info(f"Updating existing record for {instrument.name} via name match")
                match = True

            if match:
                # Update existing record with new data
                updated_data = instrument.model_dump(mode="json", exclude_none=True)
                existing_instruments[i] = updated_data
                _save_to_yaml(data, existing_instruments, target_path)
                return

    # Append new if no match found
    existing_instruments.append(instrument.model_dump(mode="json", exclude_none=True))
    _save_to_yaml(data, existing_instruments, target_path)

    logger.info(f"Auto-added {instrument.name} to {target_path}")


def _save_to_yaml(data: dict | None, instruments: list[dict], target_path: Path) -> None:
    if isinstance(data, dict) and "instruments" in data:
        data_to_dump = data
        data_to_dump["instruments"] = instruments
    else:
        data_to_dump = {"instruments": instruments}

    with open(target_path, "w") as f:
        yaml.dump(data_to_dump, f, sort_keys=False)
