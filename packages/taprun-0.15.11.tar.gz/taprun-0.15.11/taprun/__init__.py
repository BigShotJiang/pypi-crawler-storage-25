"""Taprun — compile your AI agent's browser-acting trajectory into a
deterministic program that replays at zero LLM tokens.

Two surfaces in one package:

1. **CLI**. After `pip install taprun` the `tap` command becomes
   available; first invocation downloads the platform binary from npm
   and exec's it. Equivalent to `brew install LeonTing1010/tap/tap` for
   Python users on Linux/Windows where Homebrew isn't standard.

2. **SDK**. `from taprun import forge, run, doctor` shells out to the
   same `tap` CLI. Each call is one process spawn (~30-100 ms warm);
   for hot loops use `tap mcp start` and call via MCP.

Quick start
-----------

>>> from taprun import run, doctor
>>> rows = run("hn/top")              # execute a Tap-compiled plan
>>> verdict = doctor("hn/top")        # cross-validate vs authoritative

>>> from browser_use import Agent
>>> from taprun import forge
>>> agent = Agent(task="...", llm=...)
>>> result = await agent.run()
>>> forge(trajectory=result.model_dump(),
...       site="example", name="dashboard")

See: https://taprun.dev/docs
"""

from __future__ import annotations

from .api import (
    forge,
    run,
    doctor,
    verify,
    list_taps,
    show,
    stats,
    TapError,
    TapNotFoundError,
)

__version__ = "0.15.11"

__all__ = [
    "forge",
    "run",
    "doctor",
    "verify",
    "list_taps",
    "show",
    "stats",
    "TapError",
    "TapNotFoundError",
    "__version__",
]
