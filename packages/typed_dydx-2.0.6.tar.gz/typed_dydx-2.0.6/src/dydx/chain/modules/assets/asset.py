"""dYdX asset query."""

from dydx.chain.core import GrpcEndpoint
from dydx.protos.dydxprotocol import assets as assets_proto

class Asset(GrpcEndpoint):
  """Asset endpoint."""

  async def asset(self, id: int) -> assets_proto.QueryAssetResponse:
    """Query an asset by id."""
    return await assets_proto.QueryStub(self.channel).asset(assets_proto.QueryAssetRequest(id=id))
