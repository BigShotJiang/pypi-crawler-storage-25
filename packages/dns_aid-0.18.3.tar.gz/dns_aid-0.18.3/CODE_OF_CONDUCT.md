# Code of Conduct

## Our Pledge

We as members, contributors, and maintainers pledge to make participation in our community a
harassment-free experience for everyone, regardless of age, body size, visible or invisible
disability, ethnicity, sex characteristics, gender identity and expression, level of experience,
education, socio-economic status, nationality, personal appearance, race, religion, or sexual
identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive,
and healthy community.

---

## Our Standards

Examples of behavior that contributes to a positive environment include:

- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Taking responsibility for mistakes and learning from them
- Focusing on what is best for the community as a whole

Examples of unacceptable behavior include:

- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information without explicit permission
- Sexualized language or imagery, and sexual attention or advances of any kind
- Other conduct which could reasonably be considered inappropriate in a professional setting

---

## Enforcement Responsibilities

Community maintainers are responsible for clarifying and enforcing standards of acceptable behavior
and will take appropriate and fair corrective action in response to any behavior deemed inappropriate,
threatening, offensive, or harmful.

Maintainers have the right and responsibility to remove, edit, or reject contributions that are not
aligned with this Code of Conduct, and to temporarily or permanently ban any contributor for behaviors
they deem inappropriate.

---

## Scope

This Code of Conduct applies within all community spaces and also applies when an individual is
officially representing the community in public spaces, including repositories, issue trackers,
pull requests, discussions, and social platforms.

---

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by contacting
the project maintainers or by emailing [conduct@lfaidata.foundation](mailto:conduct@lfaidata.foundation).

All complaints will be reviewed and investigated promptly and fairly. All maintainers are obligated
to respect the privacy and security of the reporter.

This project follows the [LF Projects Code of Conduct](https://lfprojects.org/policies/code-of-conduct/).

---

## Enforcement Guidelines

Community maintainers will follow these Community Impact Guidelines in determining consequences:

1. **Correction**
   Private, written warning providing clarity around the nature of the violation.

2. **Warning**
   A warning with consequences for continued behavior.

3. **Temporary Ban**
   A temporary ban from community interaction.

4. **Permanent Ban**
   Permanent removal from the community.

---

## Attribution

This Code of Conduct is adapted from the **Contributor Covenant**, version 2.1.
https://www.contributor-covenant.org/version/2/1/code_of_conduct.html
