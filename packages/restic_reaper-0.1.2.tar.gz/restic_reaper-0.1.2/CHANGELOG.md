# Changelog

## 0.1.1 (2026-05-22)

### Performance

* Cargo release profile to decrease size

## 0.1.0 (2026-05-22)

### Features

* Initial version