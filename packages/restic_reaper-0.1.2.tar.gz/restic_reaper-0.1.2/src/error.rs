use crate::model::WipeBackend;
use opendal::Error;
use pyo3::PyErr;
use pyo3::exceptions::{
    PyConnectionError, PyException, PyNotImplementedError, PyPermissionError, PyRuntimeError,
    PyValueError,
};
use thiserror::Error;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReaperErrorKind {
    Validation,
    Unsupported,
    Auth,
    Connectivity,
    DeleteFailed,
    Internal,
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
#[error("{kind:?}: {message}")]
pub struct ReaperError {
    pub kind: ReaperErrorKind,
    pub message: String,
    pub backend: Option<WipeBackend>,
    pub target: Option<String>,
    pub capability: Option<String>,
}

impl ReaperError {
    pub fn new<S: Into<String>>(kind: ReaperErrorKind, message: S) -> Self {
        Self {
            kind,
            message: message.into(),
            backend: None,
            target: None,
            capability: None,
        }
    }

    pub fn validation<S: Into<String>>(message: S) -> Self {
        Self::new(ReaperErrorKind::Validation, message)
    }

    pub fn unsupported<S: Into<String>>(capability: S) -> Self {
        Self {
            kind: ReaperErrorKind::Unsupported,
            message: "unsupported capability".to_string(),
            backend: None,
            target: None,
            capability: Some(capability.into()),
        }
    }

    pub fn auth<S: Into<String>>(message: S) -> Self {
        Self::new(ReaperErrorKind::Auth, message)
    }

    pub fn connectivity<S: Into<String>>(message: S) -> Self {
        Self::new(ReaperErrorKind::Connectivity, message)
    }

    pub fn delete_failed<S: Into<String>>(message: S) -> Self {
        Self::new(ReaperErrorKind::DeleteFailed, message)
    }

    pub fn internal<S: Into<String>>(message: S) -> Self {
        Self::new(ReaperErrorKind::Internal, message)
    }

    pub const fn category(&self) -> &'static str {
        match self.kind {
            ReaperErrorKind::Validation => "Validation",
            ReaperErrorKind::Unsupported => "Unsupported",
            ReaperErrorKind::Auth => "Auth",
            ReaperErrorKind::Connectivity => "Connectivity",
            ReaperErrorKind::DeleteFailed => "DeleteFailed",
            ReaperErrorKind::Internal => "Internal",
        }
    }

    pub const fn backend(&self) -> Option<&WipeBackend> {
        self.backend.as_ref()
    }

    pub fn message(&self) -> String {
        match self.kind {
            ReaperErrorKind::Unsupported => self.capability.as_ref().map_or_else(
                || self.message.clone(),
                |capability| format!("backend does not support `{capability}`"),
            ),
            ReaperErrorKind::DeleteFailed => self.target.as_ref().map_or_else(
                || self.message.clone(),
                |target| format!("{target}: {}", self.message),
            ),
            _ => self.message.clone(),
        }
    }
    #[must_use]
    pub const fn with_backend(mut self, backend: WipeBackend) -> Self {
        self.backend = Some(backend);
        self
    }
    #[must_use]
    pub fn with_target<S: Into<String>>(mut self, target: S) -> Self {
        self.target = Some(target.into());
        self
    }
    #[must_use]
    pub fn with_capability<S: Into<String>>(mut self, capability: S) -> Self {
        self.capability = Some(capability.into());
        self
    }
}

impl From<opendal::Error> for ReaperError {
    fn from(value: Error) -> Self {
        Self::validation(format!("opendal {:?}: {}", value.kind(), value))
    }
}

impl From<ReaperError> for PyErr {
    fn from(value: ReaperError) -> Self {
        let backend_prefix = value
            .backend()
            .map(|backend| format!("[{}] ", backend.as_str()))
            .unwrap_or_default();
        let msg = format!("{backend_prefix}{}", value.message());

        match value.kind {
            ReaperErrorKind::Validation => Self::new::<PyValueError, _>(msg),
            ReaperErrorKind::Unsupported => Self::new::<PyNotImplementedError, _>(msg),
            ReaperErrorKind::Auth => Self::new::<PyPermissionError, _>(msg),
            ReaperErrorKind::Connectivity => Self::new::<PyConnectionError, _>(msg),
            ReaperErrorKind::DeleteFailed => Self::new::<PyRuntimeError, _>(msg),
            ReaperErrorKind::Internal => Self::new::<PyException, _>(msg),
        }
    }
}
