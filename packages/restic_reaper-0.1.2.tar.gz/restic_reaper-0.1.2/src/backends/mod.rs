pub mod local;

pub mod s3;

pub mod sftp;

pub mod swift;
