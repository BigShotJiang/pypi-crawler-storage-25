use crate::error::ReaperError;
use crate::model::SftpConfig;
use opendal::Operator;
use opendal::services::Sftp as SftpBuilder;

impl From<&SftpConfig> for SftpBuilder {
    fn from(value: &SftpConfig) -> Self {
        let root = value.root.as_deref().unwrap_or("/");

        let mut builder = Self::default()
            .endpoint(&value.endpoint)
            .user(&value.user)
            .root(root)
            .key(&value.key)
            .enable_copy(value.enable_copy);

        if let Some(strategy) = &value.known_hosts_strategy {
            builder = builder.known_hosts_strategy(strategy);
        }

        builder
    }
}

impl TryInto<Operator> for &SftpConfig {
    type Error = ReaperError;

    fn try_into(self) -> Result<Operator, Self::Error> {
        let builder = SftpBuilder::from(self);
        Ok(Operator::new(builder)?.finish())
    }
}
