use crate::error::ReaperError;
use crate::model::S3Config;
use opendal::Operator;
use opendal::services::S3 as S3Builder;

impl From<&S3Config> for S3Builder {
    fn from(value: &S3Config) -> Self {
        let region = value.region.as_deref().unwrap_or("auto");
        let root = value.root.as_deref().unwrap_or("/");

        Self::default()
            .root(root)
            .region(region)
            .endpoint(&value.endpoint)
            .access_key_id(&value.access_key_id)
            .secret_access_key(&value.secret_access_key)
            .bucket(&value.bucket)
    }
}

impl TryInto<Operator> for &S3Config {
    type Error = ReaperError;

    fn try_into(self) -> Result<Operator, Self::Error> {
        let builder = S3Builder::from(self);
        Ok(Operator::new(builder)?.finish())
    }
}

impl TryInto<Operator> for S3Config {
    type Error = ReaperError;

    fn try_into(self) -> Result<Operator, Self::Error> {
        let builder = S3Builder::from(&self);
        Ok(Operator::new(builder)?.finish())
    }
}
