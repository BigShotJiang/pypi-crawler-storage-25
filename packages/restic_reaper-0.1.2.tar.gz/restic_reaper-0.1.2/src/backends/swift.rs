use crate::error::ReaperError;
use crate::model::SwiftConfig;
use opendal::Operator;
use opendal::services::Swift as SwiftBuilder;
use reqwest::Response;
use reqwest::header::HeaderValue;
use serde::Deserialize;
use serde_json::{Value, json};

#[derive(Debug, Deserialize)]
struct KeystoneAuthResponse {
    token: KeystoneToken,
}

#[derive(Debug, Deserialize)]
struct KeystoneToken {
    catalog: Vec<KeystoneCatalogEntry>,
}

#[derive(Debug, Deserialize)]
struct KeystoneCatalogEntry {
    #[serde(rename = "type")]
    service_type: String,
    endpoints: Vec<KeystoneEndpoint>,
}

#[derive(Debug, Deserialize)]
struct KeystoneEndpoint {
    interface: String,
    region: Option<String>,
    url: String,
}

fn find_project_scope(config: &SwiftConfig) -> Result<Option<Value>, ReaperError> {
    let project_scope = if let Some(project_id) = config.project_id.as_deref() {
        Some(json!({ "id": project_id }))
    } else if let Some(project_name) = config.project_name.as_deref() {
        let project_domain = match (
            config.project_domain_id.as_deref(),
            config.project_domain_name.as_deref(),
        ) {
            (Some(id), _) => json!({ "id": id }),
            (None, Some(name)) => json!({ "name": name }),
            (None, None) => {
                return Err(ReaperError::validation(
                    "when `project_name` is set, `project_domain_id` or `project_domain_name` is required",
                ));
            }
        };
        Some(json!({ "name": project_name, "domain": project_domain }))
    } else {
        None
    };

    Ok(project_scope)
}

fn find_scope_value(config: &SwiftConfig) -> Result<Value, ReaperError> {
    let project_scope = find_project_scope(config)?;

    project_scope
        .map(|project| json!({ "project": project }))
        .ok_or_else(|| {
            ReaperError::validation(
                "Swift Keystone auth requires either `project_id` or `project_name`",
            )
        })
}

fn make_auth_body(config: &SwiftConfig) -> Result<Value, ReaperError> {
    let username = config
        .username
        .as_deref()
        .ok_or_else(|| ReaperError::validation("missing `username` for Swift Keystone auth"))?;

    let password = config
        .password
        .as_deref()
        .ok_or_else(|| ReaperError::validation("missing `password` for Swift Keystone auth"))?;

    let user_domain = match (
        config.user_domain_id.as_deref(),
        config.user_domain_name.as_deref(),
    ) {
        (Some(id), _) => Some(json!({ "id": id })),
        (None, Some(name)) => Some(json!({ "name": name })),
        (None, None) => config
            .project_domain_name
            .as_deref()
            .map(|name| json!({ "name": name })),
    };

    let mut user_value = json!({
        "name": username,
        "password": password,
    });
    if let Some(domain) = user_domain {
        user_value["domain"] = domain;
    }

    let scope_value = find_scope_value(config)?;

    let auth_body = json!({
        "auth": {
            "identity": {
                "methods": ["password"],
                "password": {
                    "user": user_value
                }
            },
            "scope": scope_value
        }
    });

    Ok(auth_body)
}

async fn make_auth_request(auth_url: &str, auth_body: &Value) -> Result<Response, ReaperError> {
    let auth_tokens_url = format!("{}/auth/tokens", auth_url.trim_end_matches('/'));
    let client = reqwest::Client::new();

    client
        .post(auth_tokens_url)
        .json(&auth_body)
        .send()
        .await
        .map_err(|err| ReaperError::connectivity(format!("failed to reach Keystone: {err}")))
}

async fn raise_for_status(response: Response) -> Result<Response, ReaperError> {
    if !response.status().is_success() {
        let status = response.status();
        let body = response
            .text()
            .await
            .unwrap_or_else(|_| "<unable to read response body>".to_string());
        return Err(ReaperError::auth(format!(
            "Keystone auth failed with status {status}: {body}"
        )));
    }

    Ok(response)
}

fn extract_token(response: &Response) -> Result<String, ReaperError> {
    let token_header = response
        .headers()
        .get("X-Subject-Token")
        .or_else(|| response.headers().get("x-subject-token"))
        .ok_or_else(|| {
            ReaperError::auth("Keystone auth succeeded but `X-Subject-Token` header is missing")
        })?;

    header_to_string(token_header)
}

async fn resolve_endpoint(response: Response, config: &SwiftConfig) -> Result<String, ReaperError> {
    let auth_payload: KeystoneAuthResponse = response.json().await.map_err(|err| {
        ReaperError::internal(format!("failed to parse Keystone response: {err}"))
    })?;

    let region = config.region_name.as_deref();
    let preferred_interface = config.interface.as_deref().unwrap_or("public");

    select_swift_endpoint(&auth_payload, region, preferred_interface)
}

async fn resolve_token_and_endpoint(config: &SwiftConfig) -> Result<SwiftConfig, ReaperError> {
    let auth_url = config.auth_url.as_deref().ok_or_else(|| {
        ReaperError::validation(
            "swift config requires `endpoint`+`token`, or Keystone fields including `auth_url`",
        )
    })?;

    let auth_body = make_auth_body(config)?;
    let response = make_auth_request(auth_url, &auth_body).await?;
    let response = raise_for_status(response).await?;

    let token = extract_token(&response)?;
    let endpoint = resolve_endpoint(response, config).await?;

    let mut resolved = config.clone();
    resolved.token = Some(token);
    resolved.endpoint = Some(endpoint);
    Ok(resolved)
}

pub async fn resolve_config(config: &SwiftConfig) -> Result<SwiftConfig, ReaperError> {
    if config.endpoint.is_some() && config.token.is_some() {
        return Ok(config.clone());
    }

    resolve_token_and_endpoint(config).await
}

fn header_to_string(value: &HeaderValue) -> Result<String, ReaperError> {
    value
        .to_str()
        .map(ToString::to_string)
        .map_err(|_| ReaperError::internal("Keystone returned a non-UTF8 subject token header"))
}

fn select_swift_endpoint(
    auth_payload: &KeystoneAuthResponse,
    region: Option<&str>,
    interface: &str,
) -> Result<String, ReaperError> {
    let object_store = auth_payload
        .token
        .catalog
        .iter()
        .find(|entry| entry.service_type == "object-store")
        .ok_or_else(|| ReaperError::auth("Keystone catalog has no `object-store` service"))?;

    let by_interface_and_region = object_store.endpoints.iter().find(|endpoint| {
        endpoint.interface == interface
            && region.is_none_or(|reg| endpoint.region.as_deref() == Some(reg))
    });
    if let Some(endpoint) = by_interface_and_region {
        return Ok(endpoint.url.trim_end_matches('/').to_string());
    }

    let by_region = object_store
        .endpoints
        .iter()
        .find(|endpoint| region.is_none_or(|reg| endpoint.region.as_deref() == Some(reg)));
    if let Some(endpoint) = by_region {
        return Ok(endpoint.url.trim_end_matches('/').to_string());
    }

    if let Some(endpoint) = object_store.endpoints.first() {
        return Ok(endpoint.url.trim_end_matches('/').to_string());
    }

    Err(ReaperError::auth(
        "Keystone catalog has `object-store` service but no endpoints",
    ))
}

impl From<&SwiftConfig> for SwiftBuilder {
    fn from(value: &SwiftConfig) -> Self {
        let root = value.root.as_deref().unwrap_or("/");
        let endpoint = value.endpoint.as_deref().unwrap_or_default();
        let token = value.token.as_deref().unwrap_or_default();

        Self::default()
            .root(root)
            .endpoint(endpoint)
            .container(&value.container)
            .token(token)
    }
}

impl TryInto<Operator> for &SwiftConfig {
    type Error = ReaperError;

    fn try_into(self) -> Result<Operator, Self::Error> {
        let builder = SwiftBuilder::from(self);
        Ok(Operator::new(builder)?.finish())
    }
}
