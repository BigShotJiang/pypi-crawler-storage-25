use crate::error::ReaperError;
use crate::model::LocalConfig;
use opendal::Operator;
use opendal::services::Fs as LocalBuilder;

impl From<&LocalConfig> for LocalBuilder {
    fn from(value: &LocalConfig) -> Self {
        let mut builder = Self::default().root(&value.root);
        if let Some(atomic_write_dir) = &value.atomic_write_dir {
            builder = builder.atomic_write_dir(atomic_write_dir);
        }
        builder
    }
}

impl TryInto<Operator> for &LocalConfig {
    type Error = ReaperError;

    fn try_into(self) -> Result<Operator, Self::Error> {
        let builder = LocalBuilder::from(self);
        Ok(Operator::new(builder)?.finish())
    }
}
