#![allow(unsafe_op_in_unsafe_fn)]
mod backends;
mod error;
mod helpers;
mod model;
mod py_config;
mod wipe;

pub use error::ReaperError;
pub use model::{
    LocalConfig, S3Config, SftpConfig, SwiftConfig, WipeBackend, WipeConfig, WipeOptions,
    WipeOutcome, WipeRequest,
};
pub use wipe::wipe_repository;

use crate::helpers::future_pyresult_to_py;
use pyo3::prelude::*;
use pyo3::types::PyModule;
use pyo3::{PyAny, PyResult, create_exception, wrap_pyfunction};

create_exception!(
    _restic_reaper,
    ResticReaperError,
    pyo3::exceptions::PyException
);

#[pyfunction(name = "wipe_repository", signature = (config, dry=false,))]
fn wipe_repository_py<'py>(py: Python<'py>, config: &'py PyAny, dry: bool) -> PyResult<&'py PyAny> {
    let config = WipeConfig::try_from(config)?;

    let backend = config.backend();
    let req = WipeRequest {
        backend,
        config,
        options: WipeOptions { dry },
    };

    let future = wipe_repository(req);

    future_pyresult_to_py(py, future)
}

#[pymodule]
fn _restic_reaper(py: Python<'_>, m: &PyModule) -> PyResult<()> {
    m.add("ResticReaperError", py.get_type::<ResticReaperError>())?;
    m.add_function(wrap_pyfunction!(wipe_repository_py, m)?)?;
    Ok(())
}
