use crate::error::ReaperError;
use opendal::Operator;
use serde::{Deserialize, Serialize};
use std::fmt::{Display, Formatter};
use std::str::FromStr;

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WipeBackend {
    S3,
    Swift,
    Sftp,
    Local,
}

impl WipeBackend {
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::S3 => "s3",
            Self::Swift => "swift",
            Self::Sftp => "sftp",
            Self::Local => "local",
        }
    }
}

impl Display for WipeBackend {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

impl FromStr for WipeBackend {
    type Err = String;

    fn from_str(name: &str) -> Result<Self, Self::Err> {
        match name.trim().to_ascii_lowercase().as_str() {
            "s3" => Ok(Self::S3),
            "swift" => Ok(Self::Swift),
            "sftp" => Ok(Self::Sftp),
            "local" => Ok(Self::Local),
            other => Err(format!("unsupported backend `{other}`")),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WipeOptions {
    pub dry: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct S3Config {
    pub bucket: String,
    pub endpoint: String,
    pub access_key_id: String,
    pub secret_access_key: String,
    pub region: Option<String>,
    pub root: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SwiftConfig {
    pub endpoint: Option<String>,
    pub container: String,
    pub token: Option<String>,
    pub auth_url: Option<String>,
    pub project_id: Option<String>,
    pub project_name: Option<String>,
    pub project_domain_name: Option<String>,
    pub project_domain_id: Option<String>,
    pub region_name: Option<String>,
    pub username: Option<String>,
    pub password: Option<String>,
    pub user_domain_name: Option<String>,
    pub user_domain_id: Option<String>,
    pub interface: Option<String>,
    pub root: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SftpConfig {
    pub endpoint: String,
    pub user: String,
    pub key: String,
    pub root: Option<String>,
    pub known_hosts_strategy: Option<String>,
    pub enable_copy: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LocalConfig {
    pub root: String,
    pub atomic_write_dir: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged)]
pub enum WipeConfig {
    S3(Box<S3Config>),
    Swift(Box<SwiftConfig>),
    Sftp(Box<SftpConfig>),
    Local(Box<LocalConfig>),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WipeRequest {
    pub backend: WipeBackend,
    pub config: WipeConfig,
    pub options: WipeOptions,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct WipeOutcome {
    pub contents_deleted: bool,
}

impl WipeOutcome {
    pub const fn new() -> Self {
        Self {
            contents_deleted: false,
        }
    }
}

impl WipeConfig {
    pub const fn backend(&self) -> WipeBackend {
        match self {
            Self::S3(_) => WipeBackend::S3,
            Self::Swift(_) => WipeBackend::Swift,
            Self::Sftp(_) => WipeBackend::Sftp,
            Self::Local(_) => WipeBackend::Local,
        }
    }
}

impl WipeRequest {
    pub async fn resolve_operator(&self) -> Result<Operator, ReaperError> {
        match &self.config {
            WipeConfig::S3(config) => config.as_ref().try_into(),
            WipeConfig::Swift(config) => {
                let resolved = crate::backends::swift::resolve_config(config.as_ref()).await?;
                (&resolved).try_into()
            }
            WipeConfig::Sftp(config) => config.as_ref().try_into(),
            WipeConfig::Local(config) => config.as_ref().try_into(),
        }
    }
}

impl TryInto<Operator> for WipeConfig {
    type Error = ReaperError;

    fn try_into(self) -> Result<Operator, Self::Error> {
        match &self {
            Self::S3(config) => config.as_ref().try_into(),
            Self::Swift(config) => config.as_ref().try_into(),
            Self::Sftp(config) => config.as_ref().try_into(),
            Self::Local(config) => config.as_ref().try_into(),
        }
    }
}
