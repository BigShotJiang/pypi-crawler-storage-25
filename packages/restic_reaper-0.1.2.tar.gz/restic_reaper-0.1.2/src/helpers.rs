use std::future::Future;

use pyo3::{PyAny, PyErr, PyResult, Python};
use serde::Serialize;

pub fn future_pyresult_to_py<T: Serialize + Send + 'static, E: Into<PyErr> + Send + 'static>(
    py: Python<'_>,
    future: impl Future<Output = Result<T, E>> + Send + 'static,
) -> PyResult<&'_ PyAny> {
    pyo3_asyncio::tokio::future_into_py(py, async move {
        match future.await {
            Ok(obj) => Python::with_gil(|py| pythonize::pythonize(py, &obj).map_err(Into::into)),
            Err(exc) => Python::with_gil(|_py| Err(exc.into())),
        }
    })
}
