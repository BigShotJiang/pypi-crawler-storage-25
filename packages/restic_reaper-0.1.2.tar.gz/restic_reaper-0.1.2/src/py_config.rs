use crate::ResticReaperError;
use crate::model::WipeConfig;
use pyo3::{PyAny, PyErr};

impl<'py> TryFrom<&'py PyAny> for WipeConfig {
    type Error = PyErr;

    fn try_from(value: &'py PyAny) -> std::result::Result<Self, Self::Error> {
        pythonize::depythonize(value).map_err(|err| {
            PyErr::new::<ResticReaperError, _>(format!(
                "invalid config: backend could not be recognized from the provided config; expected a valid s3/swift/sftp/local config shape. details: {err}"
            ))
        })
    }
}
