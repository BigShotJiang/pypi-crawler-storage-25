use crate::error::ReaperError;
use crate::model::{WipeOutcome, WipeRequest};
use opendal::Operator;

async fn empty_repo_with_opendal(op: Operator) -> Result<(), opendal::Error> {
    // Recursively delete everything under the operator root.
    op.delete_with("").recursive(true).await?;

    Ok(())
}

pub async fn wipe_repository(req: WipeRequest) -> Result<WipeOutcome, ReaperError> {
    if req.options.dry {
        return Ok(WipeOutcome {
            contents_deleted: false,
        });
    }

    let op = req.resolve_operator().await?;

    empty_repo_with_opendal(op).await?;

    Ok(WipeOutcome {
        contents_deleted: true,
    })
}
