import os
import subprocess
import tempfile
from pathlib import Path

import pytest
from dotenv import load_dotenv
from restic_reaper import (
    ResticReaperError,
    S3Config,
    wipe_repository,
    wipe_repository_sync,
)


@pytest.fixture
def populated_local_repo() -> Path:
    with tempfile.TemporaryDirectory(prefix="restic-reaper-local-") as tmp_dir:
        repo_root = Path(tmp_dir)
        nested = repo_root / "nested" / "deeper"
        nested.mkdir(parents=True)
        (repo_root / "root.txt").write_text("root file\n", encoding="utf-8")
        (nested / "payload.bin").write_bytes(b"\x01\x02\x03\x04")
        yield repo_root


@pytest.fixture
def r2_config() -> S3Config:
    load_dotenv(override=False)
    account_id = os.getenv("R2_ACCOUNT_ID", "91ae6bcdb5d8535ef6144860ea32fa09")
    endpoint = os.getenv("R2_ENDPOINT")
    bucket = os.getenv("R2_BUCKET")
    access_key_id = os.getenv("R2_ACCESS_KEY_ID")
    secret_access_key = os.getenv("R2_SECRET_ACCESS_KEY")
    region = os.getenv("R2_REGION", "auto")

    if not endpoint and account_id:
        endpoint = f"https://{account_id}.r2.cloudflarestorage.com"

    if not endpoint or not bucket or not access_key_id or not secret_access_key:
        pytest.skip(
            "R2 test env is missing. Set R2_ENDPOINT (or R2_ACCOUNT_ID), "
            "R2_BUCKET, R2_ACCESS_KEY_ID, and R2_SECRET_ACCESS_KEY."
        )

    return S3Config(
        bucket=bucket,
        endpoint=endpoint,
        access_key_id=access_key_id,
        secret_access_key=secret_access_key,
        region=region,
    )


async def test_async_r2(r2_config: S3Config):
    # no config: should probably error
    with pytest.raises(ResticReaperError):
        await wipe_repository(dry=True)

    # with configured R2 backend: should be fine
    result = await wipe_repository(**r2_config, dry=True)

    assert result
    assert not result["contents_deleted"]


def test_sync_r2(r2_config: S3Config):
    # no config: should probably error
    with pytest.raises(ResticReaperError):
        wipe_repository_sync(dry=True)

    # with configured R2 backend: should be fine
    result = wipe_repository_sync(**r2_config, dry=True)

    assert result
    assert not result["contents_deleted"]


async def test_async_local(populated_local_repo: Path):
    repo_root = populated_local_repo
    nested = repo_root / "nested" / "deeper"

    assert (repo_root / "root.txt").exists()
    assert (nested / "payload.bin").exists()

    result = await wipe_repository(root=str(repo_root), dry=False)

    assert result["contents_deleted"] is True
    assert not repo_root.exists() or list(repo_root.iterdir()) == []


def test_sync_local(populated_local_repo: Path):
    repo_root = populated_local_repo
    nested = repo_root / "nested" / "deeper"

    assert (repo_root / "root.txt").exists()
    assert (nested / "payload.bin").exists()

    result = wipe_repository_sync(root=str(repo_root), dry=False)

    assert result["contents_deleted"] is True
    assert not repo_root.exists() or list(repo_root.iterdir()) == []


@pytest.mark.rust
def test_rust_cargo_tests():
    result = subprocess.run(
        ["cargo", "test", "--all-targets"],
        text=True,
        capture_output=True,
    )
    assert result.returncode == 0, (
        f"cargo test failed\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    )
