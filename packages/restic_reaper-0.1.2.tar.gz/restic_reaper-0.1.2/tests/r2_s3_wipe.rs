use opendal::Operator;
use restic_reaper::{S3Config, WipeBackend, WipeConfig, WipeOptions, WipeRequest, wipe_repository};
use std::time::{SystemTime, UNIX_EPOCH};

fn env_required(name: &str) -> Option<String> {
    std::env::var(name).ok().filter(|v| !v.trim().is_empty())
}

fn unique_prefix() -> String {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("system clock is before unix epoch")
        .as_nanos();
    format!("restic-reaper-it-{now}")
}

#[tokio::test]
async fn r2_s3_wipe_deletes_files_under_root_only() -> anyhow::Result<()> {
    dotenvy::dotenv()?;

    let endpoint = env_required("R2_ENDPOINT").or_else(|| {
        let account_id = env_required("R2_ACCOUNT_ID")
            .unwrap_or_else(|| "91ae6bcdb5d8535ef6144860ea32fa09".to_string());
        Some(format!("https://{account_id}.r2.cloudflarestorage.com"))
    });
    let endpoint = endpoint.expect("missing R2_ENDPOINT");
    let bucket = env_required("R2_BUCKET").expect("missing R2_BUCKET");
    let access_key_id = env_required("R2_ACCESS_KEY_ID")
        .expect("missing R2_ACCESS_KEY_ID; this test requires real R2 credentials");
    let secret_access_key = env_required("R2_SECRET_ACCESS_KEY")
        .expect("missing R2_SECRET_ACCESS_KEY; this test requires real R2 credentials");
    let region = env_required("R2_REGION").unwrap_or_else(|| "auto".to_string());

    let test_root = unique_prefix();
    let sentinel_path = format!("__restic_reaper_sentinel_{test_root}.txt");

    let full_config = S3Config {
        bucket: bucket.clone(),
        endpoint: endpoint.clone(),
        access_key_id: access_key_id.clone(),
        secret_access_key: secret_access_key.clone(),
        region: Some(region.clone()),
        root: Some("/".to_string()),
    };

    let test_config = S3Config {
        bucket: bucket.clone(),
        endpoint: endpoint.clone(),
        access_key_id: access_key_id.clone(),
        secret_access_key: secret_access_key.clone(),
        region: Some(region.clone()),
        root: Some(test_root.clone()), // <- different
    };

    let full_op: Operator = full_config.try_into()?;

    let pack_path = format!("{test_root}/data/pack-a");
    let snapshot_path = format!("{test_root}/snapshots/snap-1");

    full_op.write(&pack_path, "alpha").await?;
    full_op.write(&snapshot_path, "beta").await?;
    full_op.write(&sentinel_path, "sentinel").await?;

    let req = WipeRequest {
        backend: WipeBackend::S3,
        config: WipeConfig::S3(Box::new(test_config)),
        options: WipeOptions { dry: false },
    };

    let res = wipe_repository(req).await?;

    assert!(res.contents_deleted, "contents not deleted");

    let remaining_under_root = full_op
        .list_with(&format!("{test_root}/"))
        .recursive(true)
        .await?;

    assert!(
        remaining_under_root.is_empty(),
        "expected all objects under `{test_root}` to be deleted, found {remaining_under_root:?}"
    );

    assert!(
        full_op.exists(&sentinel_path).await?,
        "sentinel object outside wipe root should still exist"
    );

    full_op.delete(&sentinel_path).await?;
    Ok(())
}
