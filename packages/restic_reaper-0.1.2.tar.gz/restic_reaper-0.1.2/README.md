# ResticReaper

ResticReaper provides Rust and Python bindings for wiping data in
restic-compatible storage backends.

It uses OpenDAL-based backends (such as S3, Swift, SFTP, and local filesystem)
to support cleanup workflows from Rust or Python code.

## License

MIT. See [LICENSE](LICENSE).
