import asyncio
import typing as t

from ._restic_reaper import ResticReaperError
from ._restic_reaper import wipe_repository as _wipe_repository


class S3Config(t.TypedDict):
    bucket: str
    endpoint: str
    access_key_id: str
    secret_access_key: str
    region: t.NotRequired[str]
    root: t.NotRequired[str]


class SwiftConfig(t.TypedDict):
    container: str
    endpoint: t.NotRequired[str]
    token: t.NotRequired[str]
    auth_url: t.NotRequired[str]
    project_id: t.NotRequired[str]
    project_name: t.NotRequired[str]
    project_domain_name: t.NotRequired[str]
    project_domain_id: t.NotRequired[str]
    region_name: t.NotRequired[str]
    username: t.NotRequired[str]
    password: t.NotRequired[str]
    user_domain_name: t.NotRequired[str]
    user_domain_id: t.NotRequired[str]
    interface: t.NotRequired[str]
    root: t.NotRequired[str]


class SftpConfig(t.TypedDict):
    endpoint: str
    user: str
    key: str
    root: t.NotRequired[str]
    known_hosts_strategy: t.NotRequired[str]
    enable_copy: t.NotRequired[bool]


class LocalConfig(t.TypedDict):
    root: str


BackendConfig = S3Config | SwiftConfig | SftpConfig | LocalConfig


class WipeOutcome(t.TypedDict):
    contents_deleted: bool


async def wipe_repository(
    dry: bool = False,
    **config: BackendConfig,
) -> WipeOutcome:
    return await _wipe_repository(
        config,
        dry=dry,
    )


def wipe_repository_sync(
    dry: bool = False,
    **config: BackendConfig,
) -> WipeOutcome:
    return asyncio.run(wipe_repository(dry=dry, **config))


__all__ = [
    "BackendConfig",
    "LocalConfig",
    "ResticReaperError",
    "S3Config",
    "SftpConfig",
    "SwiftConfig",
    "WipeOutcome",
    "wipe_repository",
    "wipe_repository_sync",
]
