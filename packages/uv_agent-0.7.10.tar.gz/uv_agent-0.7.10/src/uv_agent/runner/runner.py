from __future__ import annotations

import asyncio
import os
from collections.abc import AsyncIterator
from pathlib import Path

from uv_agent.config import RunnerConfig
from uv_agent.ids import new_id
from uv_agent.jsonl import JsonlWriter
from uv_agent.runner.events import parse_structured_event as parse_structured_event
from uv_agent.runner.models import PythonRunRequest, PythonRunResult, RunnerEvent
from uv_agent.runner.output import OutputCapture, pump_stream
from uv_agent.runner.process import kill_process_tree, subprocess_group_kwargs
from uv_agent.runner.run_log import RunLogStore
from uv_agent.runner.scriptenv import ensure_venv, uv_binary
from uv_agent.time import utc_now_iso


class PythonRunner:
    def __init__(
        self,
        *,
        project_root: Path,
        data_dir: Path,
        config: RunnerConfig,
        runs_dir: Path | None = None,
        scriptenv_dir: Path | None = None,
    ) -> None:
        self.project_root = project_root.resolve()
        self.data_dir = data_dir.resolve()
        self.runs_dir = (runs_dir or self.data_dir / "runner" / "runs").resolve()
        self.scriptenv_dir = (scriptenv_dir or self.data_dir / "runner" / "scriptenv").resolve()
        self.config = config
        self.run_logs = RunLogStore(self.runs_dir, max_run_logs=config.max_run_logs)

    @property
    def config(self) -> RunnerConfig:
        return self._config

    @config.setter
    def config(self, value: RunnerConfig) -> None:
        self._config = value
        if hasattr(self, "run_logs"):
            self.run_logs.max_run_logs = max(1, value.max_run_logs)
            self.run_logs.prune()

    async def run(self, request: PythonRunRequest) -> PythonRunResult:
        events: list[RunnerEvent] = []
        async for event in self.stream_run(request):
            events.append(event)
        completed = next(
            (event for event in reversed(events) if event.type == "run.completed"),
            None,
        )
        if completed is None:
            raise RuntimeError("Runner did not emit run.completed")
        return completed.data["result"]

    async def stream_run(self, request: PythonRunRequest) -> AsyncIterator[RunnerEvent]:
        run_id = new_id("run")
        timeout_s = request.timeout_s or self.config.default_timeout_s
        await asyncio.to_thread(ensure_venv, self.scriptenv_dir)
        script_path, run_log_path = self.run_logs.create_run_files(run_id, request.code)
        writer = JsonlWriter(run_log_path)
        run_cwd = (request.cwd or self.project_root).resolve()
        argv = [
            uv_binary(),
            "run",
            "--project",
            str(self.scriptenv_dir),
            "--directory",
            str(run_cwd),
            "python",
            str(script_path),
            *request.script_args,
        ]
        env = self._run_env(
            run_id=run_id,
            thread_id=request.thread_id,
            thread_kind=request.thread_kind,
            turn_id=request.turn_id,
        )
        started = {
            "type": "run.started",
            "created_at": utc_now_iso(),
            "run_id": run_id,
            "thread_id": request.thread_id,
            "turn_id": request.turn_id,
            "cwd": str(run_cwd),
            "timeout_s": timeout_s,
            "script_args": request.script_args,
            "argv": argv,
            "script_path": str(script_path),
        }
        writer.write(started)
        yield RunnerEvent("run.started", started)

        capture = OutputCapture()
        returncode: int | None = None
        timed_out = False
        interrupted = False
        process: asyncio.subprocess.Process | None = None
        try:
            process = await asyncio.create_subprocess_exec(
                *argv,
                cwd=str(run_cwd),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                **subprocess_group_kwargs(),
            )
            stdout_task = asyncio.create_task(
                pump_stream(
                    stream_name="stdout",
                    stream=process.stdout,
                    writer=writer,
                    sink=capture.stdout_parts,
                    structured_events=capture.structured_events,
                    run_id=run_id,
                    max_output_bytes=self.config.max_output_bytes,
                    capture=capture,
                )
            )
            stderr_task = asyncio.create_task(
                pump_stream(
                    stream_name="stderr",
                    stream=process.stderr,
                    writer=writer,
                    sink=capture.stderr_parts,
                    structured_events=capture.structured_events,
                    run_id=run_id,
                    max_output_bytes=self.config.max_output_bytes,
                    capture=capture,
                )
            )
            wait_task = asyncio.create_task(process.wait())
            cancel_task = (
                asyncio.create_task(request.cancel_event.wait())
                if request.cancel_event is not None
                else None
            )
            tasks = {wait_task}
            if cancel_task is not None:
                tasks.add(cancel_task)
            done, _ = await asyncio.wait(
                tasks,
                timeout=timeout_s,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if wait_task in done:
                returncode = wait_task.result()
            elif cancel_task is not None and cancel_task in done:
                interrupted = True
                await kill_process_tree(process)
                returncode = await wait_task
            else:
                timed_out = True
                await kill_process_tree(process)
                returncode = await wait_task
            for task in tasks:
                if task is not wait_task and not task.done():
                    task.cancel()
            cancellable = [task for task in tasks if task is not wait_task and not task.done()]
            if cancellable:
                await asyncio.gather(*cancellable, return_exceptions=True)
            await asyncio.gather(stdout_task, stderr_task)
        except asyncio.CancelledError:
            if process is not None:
                await kill_process_tree(process)
            raise
        except Exception as exc:
            failed = {
                "type": "run.failed",
                "created_at": utc_now_iso(),
                "run_id": run_id,
                "error": repr(exc),
            }
            writer.write(failed)
            yield RunnerEvent("run.failed", failed)
            raise

        result = PythonRunResult(
            run_id=run_id,
            returncode=returncode,
            stdout="".join(capture.stdout_parts),
            stderr="".join(capture.stderr_parts),
            timed_out=timed_out,
            interrupted=interrupted,
            truncated=capture.truncated,
            run_log_path=run_log_path,
            script_path=script_path,
            events=capture.structured_events,
        )
        completed = {
            "type": "run.completed",
            "created_at": utc_now_iso(),
            "run_id": run_id,
            "returncode": returncode,
            "timed_out": timed_out,
            "interrupted": interrupted,
            "truncated": capture.truncated,
        }
        writer.write(completed)
        self.run_logs.prune()
        yield RunnerEvent("run.completed", {**completed, "result": result})

    def _run_env(
        self,
        *,
        run_id: str,
        thread_id: str | None,
        thread_kind: str | None,
        turn_id: str | None,
    ) -> dict[str, str]:
        env = dict(os.environ)
        env.pop("VIRTUAL_ENV", None)
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        env["UV_AGENT_RUNTIME_PROJECT_ROOT"] = str(self.project_root)
        env["UV_AGENT_RUNTIME_STATE_DIR"] = str(self.data_dir)
        env["UV_AGENT_SCRIPTENV_DIR"] = str(self.scriptenv_dir)
        env["UV_AGENT_SCRIPT_DIR"] = str(self.runs_dir)
        env["UV_BIN"] = uv_binary()
        if thread_id:
            env["UV_AGENT_RUNTIME_THREAD_ID"] = thread_id
        if thread_kind:
            env["UV_AGENT_RUNTIME_THREAD_KIND"] = thread_kind
        if turn_id:
            env["UV_AGENT_RUNTIME_TURN_ID"] = turn_id
        env["UV_AGENT_RUNTIME_RUN_ID"] = run_id
        return env
