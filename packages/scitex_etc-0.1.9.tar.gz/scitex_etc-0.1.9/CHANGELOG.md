# Changelog

All notable changes to `scitex-etc` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versions follow [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.1.5]

- Initial CHANGELOG entry — see git log for prior history.
