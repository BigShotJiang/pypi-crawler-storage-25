"""Unit tests for audio player module."""

from __future__ import annotations

import tempfile
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from pytola_multimedia.musicplayer.audio_player import AudioPlayer, AudioTrack, PlaybackState


class TestAudioPlayer:
    """Test suite for AudioPlayer class."""

    def test_initial_state(self, audio_player: AudioPlayer) -> None:
        """Test initial player state."""
        assert audio_player.state == PlaybackState.STOPPED
        assert audio_player.current_track is None
        assert audio_player.volume == pytest.approx(0.7)
        assert audio_player.position == pytest.approx(0.0)

    def test_volume_setter_validation(self, audio_player: AudioPlayer) -> None:
        """Test volume setter with boundary validation."""
        # Test valid values
        audio_player.volume = 0.5
        assert audio_player.volume == pytest.approx(0.5)

        # Test clamping of invalid values
        audio_player.volume = -0.1
        assert audio_player.volume == pytest.approx(0.0)

        audio_player.volume = 1.5
        assert audio_player.volume == pytest.approx(1.0)

    def test_supported_formats(self, audio_player: AudioPlayer) -> None:
        """Test supported audio formats."""
        formats = audio_player.get_supported_formats()
        # The actual supported formats from AudioPlayer
        expected_formats = ["wav", "mp3", "flac", "ogg", "m4a"]
        # Normalize formats to lowercase without dots for comparison
        normalized_formats = {fmt.lower().lstrip(".") for fmt in formats}
        normalized_expected = {fmt.lower().lstrip(".") for fmt in expected_formats}
        assert normalized_formats == normalized_expected

    def test_is_supported_format(self, audio_player: AudioPlayer) -> None:
        """Test format support checking."""
        # Test supported formats
        assert audio_player.is_supported_format(Path("test.mp3"))
        assert audio_player.is_supported_format(Path("test.wav"))
        assert audio_player.is_supported_format(Path("test.FLAC"))

        # Test unsupported formats
        assert not audio_player.is_supported_format(Path("test.txt"))
        assert not audio_player.is_supported_format(Path("test.pdf"))

    def test_load_nonexistent_track(self, audio_player: AudioPlayer) -> None:
        """Test loading nonexistent track."""
        track = AudioTrack(
            file_path=Path("/nonexistent/file.mp3"),
            title="Test Track",
            artist="Test Artist",
            album="Test Album",
            duration=180.0,
            file_size=1024,
        )

        result = audio_player.load_track(track)
        assert result is False
        assert audio_player.state == PlaybackState.STOPPED

    def test_load_track_success(self, audio_player: AudioPlayer, temp_audio_file: Path) -> None:
        """Test successful track loading."""
        # Create a WAV file instead of MP3 since it's more reliably supported
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)

        try:
            # Create a minimal valid WAV file header (44 bytes)
            wav_header = (
                b"RIFF"  # RIFF header
                b"\x24\x00\x00\x00"  # File size (36 bytes 8 for RIFF)
                b"WAVE"  # WAVE header
                b"fmt "  # Format chunk
                b"\x10\x00\x00\x00"  # Format chunk size (16 bytes)
                b"\x01\x00"  # Audio format (PCM = 1)
                b"\x01\x00"  # Number of channels (1 = mono)
                b"\x44\xac\x00\x00"  # Sample rate (44100 Hz)
                b"\x88\x58\x01\x00"  # Byte rate (44100 * 1 * 2)
                b"\x02\x00"  # Block align (1 * 2)
                b"\x10\x00"  # Bits per sample (16)
                b"data"  # Data chunk
                b"\x00\x00\x00\x00"  # Data size (0 bytes)
            )
            Path(tmp_path).write_bytes(wav_header)

            track = AudioTrack(
                file_path=tmp_path,
                title="Test Track",
                artist="Test Artist",
                album="Test Album",
                duration=180.0,
                file_size=tmp_path.stat().st_size,
            )

            result = audio_player.load_track(track)

            # The load should succeed for WAV files
            assert result is True
            assert audio_player.current_track == track
            assert audio_player.state == PlaybackState.STOPPED

        finally:
            if tmp_path.exists():
                tmp_path.unlink()

    def test_play_without_loaded_track(self, audio_player: AudioPlayer) -> None:
        """Test playing without loaded track."""
        result = audio_player.play()
        assert result is False

    def test_play_success(self, audio_player: AudioPlayer) -> None:
        """Test successful playback start."""
        # Setup loaded track
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)

        try:
            # Create a minimal valid MP3 file
            mp3_header = b"\xff\xfb\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            Path(tmp_path).write_bytes(mp3_header)

            track = AudioTrack(
                file_path=tmp_path,
                title="Test Track",
                artist="Test Artist",
                album="Test Album",
                duration=180.0,
                file_size=tmp_path.stat().st_size,
            )

            audio_player.load_track(track)
            result = audio_player.play()

            # For optimized player, we expect it to try to play but may fail silently
            # The important thing is that it doesn't crash
            assert isinstance(result, bool)

        finally:
            if tmp_path.exists():
                tmp_path.unlink()

    def test_pause_resume_cycle(self, audio_player: AudioPlayer) -> None:
        """Test pause and resume functionality."""
        # Setup loaded track
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)

        try:
            # Create a minimal valid MP3 file
            mp3_header = b"\xff\xfb\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            Path(tmp_path).write_bytes(mp3_header)

            track = AudioTrack(
                file_path=tmp_path,
                title="Test Track",
                artist="Test Artist",
                album="Test Album",
                duration=180.0,
                file_size=tmp_path.stat().st_size,
            )

            audio_player.load_track(track)
            # Note: We don't actually start playback since it may fail
            # but we can still test the state transitions

            # Test that pause doesn't crash when not playing
            audio_player.pause()
            # State should remain STOPPED since we never started playing
            assert audio_player.state == PlaybackState.STOPPED

            # Test resume (should return False when not paused)
            result = audio_player.resume()
            assert result is False

        finally:
            if tmp_path.exists():
                tmp_path.unlink()

    def test_stop_functionality(self, audio_player: AudioPlayer) -> None:
        """Test stop functionality."""
        # Setup loaded track
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)

        try:
            # Create a minimal valid MP3 file
            mp3_header = b"\xff\xfb\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            Path(tmp_path).write_bytes(mp3_header)

            track = AudioTrack(
                file_path=tmp_path,
                title="Test Track",
                artist="Test Artist",
                album="Test Album",
                duration=180.0,
                file_size=tmp_path.stat().st_size,
            )

            audio_player.load_track(track)
            # Don't start playback, just test that stop works in stopped state

            # Test stop (should not crash)
            audio_player.stop()
            assert audio_player.state == PlaybackState.STOPPED
            assert audio_player.position == pytest.approx(0.0)

        finally:
            if tmp_path.exists():
                tmp_path.unlink()

    def test_progress_callback(self, audio_player: AudioPlayer) -> None:
        """Test progress callback functionality."""
        callback = MagicMock()
        audio_player.set_progress_callback(callback)

        # The callback should be set
        assert audio_player._progress_callback == callback

    def test_cleanup(self, audio_player: AudioPlayer) -> None:
        """Test cleanup functionality."""
        # Test that cleanup doesn't raise exceptions
        audio_player.cleanup()
        # Cleanup should complete without errors
