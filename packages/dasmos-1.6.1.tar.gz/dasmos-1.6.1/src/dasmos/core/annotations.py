"""Comments and annotations attached to binary addresses.

A driver-script call like ``d.comment(addr, "text")`` deposits a
:class:`Comment` in an :class:`AnnotationStore`; the renderer reads
the store at render-time and emits each comment at the correct
position relative to the code line.

Per ``docs/design/decisions.md`` D-020, this is its own manager class
held by the :class:`~dasmos.disassembler.Disassembler` (alongside
:class:`MemoryImage`, :class:`MoveManager`, :class:`LabelManager`,
:class:`ClassificationStore`, …) — separate, focused, instance-scoped.

This first cut handles the load-bearing alignment positions that drive
the bulk of the surveyed driver scripts: ``BEFORE_LABEL`` (standalone
comment above the line), ``INLINE`` (trailing on the code line), and
``BEFORE_LINE`` / ``AFTER_LINE`` for vertical separation. ``Annotation``
is the verbatim sibling of :class:`Comment` for raw assembler-source
text the driver wants emitted.

Deferred from this first cut:

- Markdown-to-plaintext rendering of comment text — lands with the
  :mod:`markdown_asm` port (task #26).
- Word-wrapping of long standalone comments — the field is carried
  but unused; the renderer emits the text as given.
- Inline-comment column alignment — the renderer uses a fixed
  trailing offset for now.
- Per-move-id annotation discrimination — the store is indexed by
  bare :class:`BinaryAddr`; the move_id from the Disassembler call
  is honoured to resolve the address but not stored.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Union

from dasmos.core.memory import BinaryAddr


class Align(Enum):
    """Where a comment or annotation appears relative to a line.

    Most driver-script calls use ``BEFORE_LABEL`` (the default) or
    ``INLINE``; the others are rarer.
    """

    BEFORE_LABEL = "before_label"
    """Standalone, above the line's labels and code."""

    AFTER_LABEL = "after_label"
    """Standalone, between the line's labels and the code."""

    BEFORE_LINE = "before_line"
    """Standalone, just above the code (after any labels)."""

    AFTER_LINE = "after_line"
    """Standalone, just below the code line."""

    INLINE = "inline"
    """Trailing on the same line as the code, after the operands."""


@dataclass
class Comment:
    """A user comment at a specific address.

    The text is stored verbatim; the renderer applies the assembler's
    comment prefix (``;`` for Beebasm) at render time.
    """

    text: str
    align: Align = Align.BEFORE_LABEL
    word_wrap: bool = True
    indent: int = 0
    auto_generated: bool = False
    suppresses_auto: bool = False
    priority: Optional[int] = None


@dataclass
class Annotation:
    """A raw assembler-source string at a specific address.

    Unlike :class:`Comment`, the text is emitted verbatim — no
    comment prefix is added. Use this for emitting assembler
    directives the driver wants inline (e.g. an explicit ``equb``).
    """

    text: str
    align: Align = Align.BEFORE_LABEL
    priority: Optional[int] = None


@dataclass
class Banner:
    """A multi-line decorated comment block at a specific address.

    Renders as a renderer-defined separator (Beebasm uses a row of
    asterisks) followed by the title and description text, providing
    strong visual separation in the disassembled listing.

    The two main use cases:

    - Subroutine headers: ``d.subroutine(addr, name, title=..., description=...)``
      registers the entry point AND attaches a Banner.
    - Data-region labels: ``d.banner(addr, title=..., description=...)``
      adds a Banner without registering an entry point.
    """

    title: str = ""
    description: str = ""
    on_entry: Optional[dict[str, str]] = None
    on_exit: Optional[dict[str, str]] = None
    align: Align = Align.BEFORE_LABEL
    auto_generated: bool = False
    priority: Optional[int] = None


# Type alias for store entries.
Entry = Union[Comment, Annotation, Banner]


class AnnotationStore:
    """Per-disassembly registry of :class:`Comment` and
    :class:`Annotation` entries keyed by binary address.

    A single address can carry multiple entries; insertion order is
    preserved. The renderer is responsible for iterating entries in
    the right order and at the right rendering position.
    """

    def __init__(self):
        self._entries: dict[BinaryAddr, list[Entry]] = {}

    def add(self, binary_addr, entry: Entry) -> None:
        """Append ``entry`` at ``binary_addr``.

        Issues a :class:`UserWarning` when the (address, alignment,
        type) triple already has at least one prior entry — a
        second comment at the same place is almost always a
        driver-script bug (a copy-paste, or an attempt to override
        an earlier comment that ends up appending instead). Both
        entries are still stored; the warning lets the user notice
        and decide.
        """
        addr = self._key(binary_addr)
        bucket = self._entries.setdefault(addr, [])
        existing = next(
            (
                e for e in bucket
                if type(e) is type(entry) and e.align is entry.align
            ),
            None,
        )
        # The duplicate-comment warning targets authoring bugs (one
        # ``d.comment(addr, ...)`` accidentally appending to a prior
        # one instead of overriding it). Analyser-driven stacking is
        # different — environments deliberately layer extra context
        # alongside driver-supplied comments. Suppress the warning
        # when EITHER end of the stack is auto-generated.
        either_auto = (
            getattr(entry, "auto_generated", False)
            or (existing is not None
                and getattr(existing, "auto_generated", False))
        )
        if existing is not None and not either_auto:
            import warnings
            existing_text = self._summary(existing)
            new_text = self._summary(entry)
            warnings.warn(
                f"Duplicate {type(entry).__name__} at &{int(addr):04x} "
                f"(align={entry.align.name}): existing={existing_text!r}, "
                f"new={new_text!r}. Both will be emitted; if this was "
                f"meant to override the earlier entry, the driver is "
                f"appending instead.",
                stacklevel=2,
            )
        bucket.append(entry)

    @staticmethod
    def _summary(entry: "Entry") -> str:
        """One-line preview of an entry's content for the duplicate-
        warning message. Picks ``text`` for Comment / Annotation
        and ``title`` (else first line of description) for Banner.
        """
        text = getattr(entry, "text", None)
        if text is None:
            text = getattr(entry, "title", None) or getattr(entry, "description", "")
        first_line = text.split("\n", 1)[0] if text else ""
        if len(first_line) > 60:
            first_line = first_line[:57] + "..."
        return first_line

    def get(self, binary_addr) -> list[Entry]:
        """Return a list of entries at ``binary_addr`` (insertion order)."""
        addr = self._key(binary_addr)
        return list(self._entries.get(addr, []))

    def get_for_align(self, binary_addr, align: Align) -> list[Entry]:
        """Return entries at ``binary_addr`` whose alignment matches."""
        return [e for e in self.get(binary_addr) if e.align is align]

    def is_auto_suppressed_at(self, binary_addr) -> bool:
        """Return True if any annotation at ``binary_addr`` carries the
        ``suppresses_auto`` flag.

        Env analysers and ``setup()`` methods consult this before
        attaching their auto-generated annotation, giving driver
        scripts a uniform way to crowd out env-supplied auto-comments
        when the driver already documents the address authoritatively.
        Align-agnostic — a driver Comment with ``suppresses_auto=True``
        in *any* position blocks env auto-attach at that address.
        """
        for entry in self.get(binary_addr):
            if isinstance(entry, Comment) and entry.suppresses_auto:
                return True
        return False

    def __contains__(self, binary_addr) -> bool:
        return self._key(binary_addr) in self._entries

    def __iter__(self):
        return iter(self._entries)

    def items(self):
        return self._entries.items()

    @staticmethod
    def _key(binary_addr) -> BinaryAddr:
        if isinstance(binary_addr, BinaryAddr):
            return binary_addr
        return BinaryAddr(int(binary_addr))
