"""CLI entry point."""
