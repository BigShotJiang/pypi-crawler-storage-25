# horizon-cloud-service-cli

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)

- [horizon-cloud-service-cli](#horizon-cloud-service-cli)
  - [Overview](#overview)
  - [Try it out](#try-it-out)
    - [Prerequisites](#prerequisites)
    - [Installation](#installation)
      - [Mac \& Linux](#mac--linux)
      - [Windows](#windows)
      - [Use the CLI](#use-the-cli)
  - [Documentation](#documentation)
  - [Contributing](#contributing)
  - [License](#license)

## Overview

hcs-cli is a human-friendly command line toolbox for [Omnissa Horizon Cloud Service (HCS)](https://www.omnissa.com/products/horizon-cloud/), based on public REST APIs.

## Try it out

### Prerequisites

- Python 3.9+
- Pip

Refer to [Setup Prerequisites](doc/dev-setup.md#setup-prerequisites) for more details.

### Installation

#### Mac & Linux

Install the tool

```
brew install python
pip install hcs-cli
```

#### Windows

Install the tool.

```
pip install hcs-cli
```

If you have python installed with option "Add python to path", it should be fine. Otherwise, you need to add python and it's Script directory to path.

#### Use the CLI

Use with default public HCS service.

```
hcs login
```

Run a command, for example, list templates:

```
hcs admin template list
```

## Documentation

- [HCS CLI - User Guide](../doc/hcs-cli-user-guide.md)
- [HCS CLI - Cheatsheet](../doc/hcs-cli-cheatsheet.md)
- [HCS CLI - Dev Guide](../doc/hcs-cli-dev-guide.md)
- [HCS Plan - template engine for HCS](../doc/hcs-plan.md)
- [Context Programming](https://github.com/nanw1103/context-programming)

## License

Licensed under the [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0). See the [LICENSE](../LICENSE) file in the repository root for the full text.
