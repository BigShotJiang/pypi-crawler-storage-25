"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib import hcs_client

# Create a logger
logger = logging.getLogger("edge-twin")


def _client(url: str):
    if not url.endswith("/"):
        url += "/"
    url += "edge-twin"
    return hcs_client(url)


def get(id: str, edgehub_url: str, verbose: bool):
    ret = _client(edgehub_url).get("/v1/twins/" + id)
    return ret
