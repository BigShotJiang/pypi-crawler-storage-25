"""
Copyright © 2025 Omnissa, LLC.
"""

from typing import Optional
from dateutil import parser as date_parser
from hcs_cli.service import api as hcs_api
from urllib.parse import quote


def _dct_item_latest_ts(item: dict) -> float:
    """Sort key for picking the newest row: max of upload/create (not expiry — far-future dates skew order)."""
    dct = item.get("dctLog") or {}
    best = 0.0
    for key in ("uploadTimestamp", "createTimestamp"):
        v = dct.get(key)
        if not v:
            continue
        try:
            best = max(best, date_parser.isoparse(v).timestamp())
        except (ValueError, TypeError, OverflowError):
            pass
    return best


def request(org_id: str, template_id: str, vm_id: str, is_ops: bool):
    # curl 'https://cloud-sg.horizon.omnissa.com/vm-manager/v1/ops/agentdct?customer_org_id=5628a2cb-5cca-4ce4-b25a-a74eeee08230&action=create' \
    # --data-raw '{"requestList":[{"templateId":"6709ad3b4259e913c4763ad5","vmId":"dedicated000"}]}'
    # Compose the API endpoint and request body
    if is_ops:
        url = f"/vm-manager/v1/ops/agentdct?customer_org_id={org_id}&action=create"
    else:
        url = f"/vm-manager/v1/agentdct?org_id={org_id}&action=create"
    body = {"requestList": [{"templateId": template_id, "vmId": vm_id}]}

    try:
        response = hcs_api.post(url, json=body)
        return {"success": True, "response": response}
    except Exception as e:
        return {"success": False, "reason": str(e)}

    # ------------------------------------------
    # trigger DCT

    # /vm-manager/v2/ops/dct

    # schema
    # {
    #     "providerLabel": "string",
    #     "requestList": [
    #         {
    #         "vmId": "string",
    #         "templateId": "string",
    #         "connectionServerId": "string",
    #         "component": "AGENT",
    #         "reason": "string"
    #         }
    #     ],
    #     "edgeId": "string"
    # }

    # example url
    # POST https://cloud-sg.horizon.omnissa.com/vm-manager/v2/ops/agentdct?customer_org_id=5628a2cb-5cca-4ce4-b25a-a74eeee08230&action=create

    # example request body
    # {"requestList":[{"templateId":"6758b9a665d1826f587c8928","vmId":"MultSession000"}]}


def latest(org_id: str, template_id: str, vm_id: str, is_ops: bool) -> Optional[dict]:
    items = search(org_id, template_id, vm_id, is_ops)
    if not items:
        return None
    return max(items, key=_dct_item_latest_ts)  # type: ignore


def search(
    org_id: str,
    template_id: Optional[str] = None,
    vm_id: Optional[str] = None,
    is_ops: bool = False,
    provider_Label: Optional[str] = None,
    edge_deployment_id: Optional[str] = None,
    connection_server_id: Optional[str] = None,
    component: Optional[str] = "AGENT",
    status_abbr: Optional[str] = None,
) -> list:
    # component:
    # 0"AGENT"
    # 1"AGENT_RDS"
    # 2"CONNECTION_SERVER"
    # statusAbbr:
    # 0"ACCEPTED"
    # 1"IN_PROGRESS"
    # 2"SUCCESS"
    # 3"ERROR"
    # 4"EXPIRED"
    search = f"component $eq {component}"

    # service bug...
    # if status_abbr:
    #     search += f" AND statusAbbr $eq {status_abbr}"
    # else:
    #     search += f" AND statusAbbr $ne EXPIRED"

    if template_id:
        search += f" AND templateId $eq {template_id}"
    if vm_id:
        search += f" AND vmId $eq {vm_id}"
    if provider_Label:
        search += f" AND providerLabel $eq {provider_Label}"
    if edge_deployment_id:
        search += f" AND edgeDeploymentId $eq {edge_deployment_id}"
    if connection_server_id:
        search += f" AND connectionServerId $eq {connection_server_id}"
    if status_abbr:
        search += f" AND statusAbbr $eq {status_abbr}"

    search = quote(search)
    if is_ops:
        url = f"/vm-manager/v2/ops/dct/status/search?search={search}&customer_org_id={org_id}"
    else:
        url = f"/vm-manager/v2/dct/status/search?search={search}&org_id={org_id}"
    items = hcs_api.get(url, all_pages=True)

    # client filter to work around service bugs
    filtered_items = []

    if status_abbr is None:
        # filter out expired items if status_abbr is not specified, due to service bug
        for item in items:
            if item.get("statusAbbr") != "EXPIRED":
                filtered_items.append(item)
    else:
        for item in items:
            if item.get("statusAbbr") == status_abbr:
                filtered_items.append(item)

    return filtered_items

    # GET https://cloud-sg.horizon.omnissa.com/vm-manager/v2/ops/agentdct/status/search?page=0&size=20&search=component%20$eq%20AGENT&search=component%20$eq%20AGENT&customer_org_id=5628a2cb-5cca-4ce4-b25a-a74eeee08230

    # Response

    # {
    #     "content": [
    #         {
    #             "vmId": "dedicated001",
    #             "templateId": "6709ad3b4259e913c4763ad5",
    #             "connectionServerId": null,
    #             "providerLabel": "azure",
    #             "edgeDeploymentId": "67099cd34259e913c4761597",
    #             "component": "AGENT",
    #             "status": "DCT log expired - please try to initiate log creation again",
    #             "code": 404,
    #             "statusAbbr": "EXPIRED",
    #             "dctLog": null,
    #             "opsInitiated": false,
    #             "initiator": "nanw@omnissa.com",
    #             "reason": null,
    #             "errorMessage": null,
    #             "logCollectionTaskId": null
    #         },
    #         {
    #             "vmId": "dedicated002",
    #             "templateId": "6709ad3b4259e913c4763ad5",
    #             "connectionServerId": null,
    #             "providerLabel": "azure",
    #             "edgeDeploymentId": "67099cd34259e913c4761597",
    #             "component": "AGENT",
    #             "status": "DCT download completed",
    #             "code": 200,
    #             "statusAbbr": "SUCCESS",
    #             "dctLog": {
    #                 "createTimestamp": "2026-02-20T18:15:59.300Z",
    #                 "uploadTimestamp": "2026-02-20T18:15:59.300Z",
    #                 "expiryTimestamp": "2026-03-07T18:16:26.352528441Z",
    #                 "readAccessUri": "https://dctprdwestus2.blob.core.windows.net/dct/5628a2cb-5cca-4ce4-b25a-a74eeee08230_6709ad3b4259e913c4763ad5_dedicated002/5628a2cb-5cca-4ce4-b25a-a74eeee08230_6709ad3b4259e913c4763ad5_dedicated002.zip?sig=YbWsu6yQI1IUiAbCHwRRoy3PaMCr%2BXG1faO6zi7%2BZXk%3D&st=2026-02-20T18%3A00%3A59Z&se=2026-03-07T18%3A16%3A26Z&sv=2019-02-02&spr=https&sp=r&sr=b"
    #             },
    #             "opsInitiated": true,
    #             "initiator": "OMNISSA_OPS",
    #             "reason": null,
    #             "errorMessage": null,
    #             "logCollectionTaskId": null
    #         },
    #         {
    #             "vmId": "MultSession000",
    #             "templateId": "6758b9a665d1826f587c8928",
    #             "connectionServerId": null,
    #             "providerLabel": "azure",
    #             "edgeDeploymentId": "67099cd34259e913c4761597",
    #             "component": "AGENT",
    #             "status": "DCT download in progress",
    #             "code": 200,
    #             "statusAbbr": "IN_PROGRESS",
    #             "dctLog": null,
    #             "opsInitiated": true,
    #             "initiator": "OMNISSA_OPS",
    #             "reason": null,
    #             "errorMessage": null,
    #             "logCollectionTaskId": null
    #         }
    #     ],
    #     "pageable": {
    #         "pageNumber": 0,
    #         "pageSize": 20,
    #         "sort": {
    #             "empty": false,
    #             "unsorted": false,
    #             "sorted": true
    #         },
    #         "offset": 0,
    #         "paged": true,
    #         "unpaged": false
    #     },
    #     "last": true,
    #     "totalElements": 3,
    #     "totalPages": 1,
    #     "size": 20,
    #     "number": 0,
    #     "sort": {
    #         "empty": false,
    #         "unsorted": false,
    #         "sorted": true
    #     },
    #     "first": true,
    #     "numberOfElements": 3,
    #     "empty": false
    # }
