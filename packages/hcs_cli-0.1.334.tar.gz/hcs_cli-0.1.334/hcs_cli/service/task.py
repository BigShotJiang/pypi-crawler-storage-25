"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from typing import Any, Dict, List, Optional, Union

import yumako

from hcs_core.ctxp import recent
from hcs_core.ctxp.util import CtxpException
from hcs_core.sglib.client_util import hdc_service_client, wait_for_res_status
from hcs_core.util.query_util import PageRequest
from pydantic import BaseModel, ConfigDict, Field
from yumako import lru

_tsctl_client = hdc_service_client("tsctl")


class LogLevel:
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"


class RepeatMode:
    NONE = None
    FIXED_RATE = "FixedRate"  # Fixed interval between start of executions
    FIXED_DELAY = "FixedDelay"  # Fixed interval between end and next start


class Schedule(BaseModel):
    initialDelayMs: int = Field(0)
    intervalMs: int = Field(0)
    repeat: Optional[str] = Field(RepeatMode.NONE)
    until: Optional[str] = Field(None)
    timeZone: Optional[str] = Field(None)
    cronExpression: Optional[str] = Field(None)


class LogItem(BaseModel):
    message: str
    time: int
    log_level: Optional[str] = Field(None, alias="logLevel")
    data: Dict[str, Any] = Field(default_factory=dict)


class TaskLog(BaseModel):
    model_config = ConfigDict(extra="ignore")

    logId: Optional[str] = Field(None)
    group: Optional[str] = None
    taskKey: Optional[str] = Field(None)
    executionId: Optional[str] = Field(None)
    timeStarted: Optional[int] = Field(None)
    timeUpdated: Optional[int] = Field(None)
    timeCompleted: Optional[int] = Field(None)
    timeCreated: Optional[int] = Field(None)
    timeScheduled: Optional[int] = Field(None)
    state: Optional[str] = None
    error: Optional[str] = None
    ttlMs: Optional[int] = Field(None)
    nodeId: Optional[str] = Field(None)
    version: Optional[int] = None
    output: Optional[Any] = None
    properties: Optional[Dict[str, Any]] = Field(default_factory=dict)
    logs: List[LogItem] = Field(default_factory=list)


class FollowUp(BaseModel):
    success: Optional[str] = None
    error: Optional[str] = None
    cancel: Optional[str] = None
    namespace: Optional[str] = None
    group: Optional[str] = None


class TaskModel(BaseModel):
    model_config = ConfigDict(extra="ignore")
    group: str
    key: str
    worker: str
    orgId: Optional[str] = Field(None)
    description: Optional[str] = None
    parent: Optional[str] = None
    resourceId: Optional[str] = Field(None)
    type: Optional[str] = None
    input: Dict[str, Any] = Field(default_factory=dict)
    meta: Dict[str, Any] = Field(default_factory=dict)
    timeCreated: Optional[int] = Field(None)
    exclusive: Optional[str] = None
    exclusiveMode: Optional[str] = Field(None)
    timeoutMs: Optional[int] = Field(None)
    resultTtlMs: Optional[int] = Field(None)
    taskTtlMs: Optional[int] = Field(None)
    lite: Optional[bool] = None
    schedule: Optional[Schedule] = None
    queueId: Optional[str] = Field(None)
    traceContext: Optional[Dict[str, Any]] = Field(None)
    followUp: Optional[FollowUp] = Field(None)
    priority: int = 0
    log: Optional[TaskLog] = None
    location: Optional[str] = None
    _last_completed_log: Optional[TaskLog] = None  # last completed log for recurring task. Only for client.


def recent_task(task: TaskModel, namespace: str = None):
    """Set the task as the recent for easy access."""
    recent.set("task.key", task.key)
    recent.set("task.group", task.group)
    if namespace:
        recent.set("task.namespace", namespace)


# This SCM access should be fully removed when global task is supported by tsctl.
_task_temp_lru = lru.LRUDict[str, str]()
_scm_client = hdc_service_client("scm")


def query(
    namespace: str,
    scheduler: str = "any",
    schedule_type=None,
    org_id: str = None,
    group: str = None,
    worker: str = None,
    type: str = None,
    resource: str = None,
    queue: str = None,
    parent: str = None,
    meta: dict = None,
    input: dict = None,
    states: list = None,
    search: str = None,
    location: str = None,
    time_created: str = None,
    time_scheduled: str = None,
    time_started: str = None,
    time_completed: str = None,
    _v1log: bool = False,
    limit: int = 10,
) -> List[TaskModel]:
    all = []
    if scheduler == "any" or scheduler == "global":
        # use v2 API
        query_params = {
            "namespace": namespace,
            "orgId": org_id,
            "size": limit,
            "limit": limit,
            "orderBy": "timeCreated:desc",
        }
        if schedule_type:
            # TODO
            pass

        if group:
            query_params["group"] = group
        if worker:
            query_params["worker"] = worker
        if type:
            query_params["type"] = type
        if resource:
            query_params["resource"] = resource
        if queue:
            query_params["queue"] = queue
        if parent:
            query_params["parent"] = parent
        if meta:
            for k, v in meta.items():
                query_params[f"meta.{k}"] = v
        if input:
            for k, v in input.items():
                query_params[f"input.{k}"] = v
        if states:
            query_params["state"] = ",".join(states)
        if search:
            query_params["search"] = search
        if location:
            query_params["location"] = location
        if time_created:
            query_params["timeCreated"] = time_created
        if time_scheduled:
            query_params["timeScheduled"] = time_scheduled
        if time_started:
            query_params["timeStarted"] = time_started
        if time_completed:
            query_params["timeCompleted"] = time_completed

        def _get_page_v2(query_string):
            url = "/v1/tasks?" + query_string
            return _scm_client.get(url)

        ret = PageRequest(_get_page_v2, **query_params).get()
        if ret:
            all.extend(ret)

    limit -= len(all)
    if limit > 0 and (scheduler == "any" or scheduler == "hdc"):
        # use v1 API
        def _get_page_v1(query_string):
            url = f"/v1/namespaces/{namespace}/tasks?" + query_string
            return _tsctl_client.get(url)

        search_parts = []
        if search:
            search_parts.append(search)

        if org_id:
            search_parts.append(f"orgId $eq {org_id}")
        if group:
            recent.set("task.group", group)
            search_parts.append(f"group $eq {group}")
        if worker:
            search_parts.append(f"worker $eq {worker}")
        if type:
            search_parts.append(f"type $eq {type}")
        if resource:
            search_parts.append(f"resource $eq {resource}")
        if queue:
            search_parts.append(f"queue $eq {queue}")
        if parent:
            search_parts.append(f"parent $eq {parent}")
        if meta:
            for m in meta:
                k, v = m.split("=")
                search_parts.append(f"meta.{k} $eq {v}")
        if input:
            for i in input:
                k, v = i.split("=")
                search_parts.append(f"input.{k} $eq {v}")

        def fn_filter(task: dict):
            if schedule_type == "recurring" or schedule_type == "one_time":
                is_recurring = task["schedule"]["repeat"] is not None or task["schedule"]["cronExpression"] is not None
                if schedule_type == "recurring" and not is_recurring:
                    return False
                if schedule_type == "one_time" and is_recurring:
                    return False
            task_log = task.get("log")
            if not task_log and (_v1log or states or time_scheduled or time_started or time_completed):
                task_log = _lastlog(org_id, namespace, task["group"], task["key"])
                task["log"] = task_log
            if states:
                if not task_log:
                    return False
                if task_log.state.upper() not in states:
                    return False

            if time_created:
                start, end = _parse_time_range(time_created)
                if not task.get("timeCreated") or task["timeCreated"] < start or task["timeCreated"] > end:
                    return False
            if time_scheduled:
                start, end = _parse_time_range(time_scheduled)
                if (
                    not task_log
                    or not task_log.get("timeScheduled")
                    or task_log["timeScheduled"] < start
                    or task_log["timeScheduled"] > end
                ):
                    return False
            if time_started:
                start, end = _parse_time_range(time_started)
                if not task_log or not task_log.get("timeStarted") or task_log["timeStarted"] < start or task_log["timeStarted"] > end:
                    return False
            if time_completed:
                start, end = _parse_time_range(time_completed)
                if (
                    not task_log
                    or not task_log.get("timeCompleted")
                    or task_log["timeCompleted"] < start
                    or task_log["timeCompleted"] > end
                ):
                    return False
            return True

        kwargs = {"size": limit, "limit": limit}
        if search_parts:
            kwargs["search"] = " AND ".join(search_parts)
        ret = PageRequest(_get_page_v1, fn_filter=fn_filter, **kwargs).get()
        if ret:
            all.extend(ret)

    all2 = []
    for t in all:
        all2.append(TaskModel.model_validate(t))
    return all2


def _parse_time_range(time_range: str) -> tuple:
    if not time_range or not time_range.strip():
        raise ValueError("Time range cannot be null or empty.")

    parts = time_range.split(",")
    if len(parts) != 2:
        raise ValueError(f"Invalid time range format: {time_range}. Expected format: 'start,end'.")

    start_str = parts[0].strip()
    end_str = parts[1].strip()

    start = 0 if not start_str else yumako.time.of(start_str).timestamp() * 1000
    end = 3376684800000 if not end_str else yumako.time.of(end_str).timestamp() * 1000

    return (start, end)


def _get_v1(namespace: str, group: str, key: str) -> Optional[TaskModel]:
    url = f"/v1/namespaces/{namespace}/groups/{group}/tasks/{key}"
    t = _tsctl_client.get(url, type=TaskModel)
    if not t:
        return
    return t


def _get_v2(org_id: str, namespace: str, group: str, key: str, location: str = None) -> Optional[TaskModel]:
    url = f"/v1/tasks/{key}?"
    if org_id:
        url += f"&orgId={org_id}"
    if namespace:
        url += f"&namespace={namespace}"
    if group:
        url += f"&group={group}"
    if location:
        url += f"&location={location}"
    t = _scm_client.get(url, type=TaskModel)
    if not t:
        return
    return t


def get(org_id: str, namespace: str, group: str, key: str, **kwargs) -> Optional[TaskModel]:
    _k = f"{namespace}/{group}/{key}"
    version = _task_temp_lru.get(_k)
    if version == "v1":
        t = _get_v1(namespace, group, key)
        t.log = _lastlog(org_id, namespace, group, key)
    elif version == "v2":
        t = _get_v2(org_id, namespace, group, key, location=kwargs.get("location"))
    else:
        t = _get_v1(namespace, group, key)
        if t:
            t.log = _lastlog(org_id, namespace, group, key)
            _task_temp_lru[_k] = "v1"
        else:
            t = _get_v2(org_id, namespace, group, key, location=kwargs.get("location"))
            if t:
                _task_temp_lru[_k] = "v2"

    return t


def delete(org_id: str, namespace: str, group: str, key: str, execution_id: str = None, exclusive_id: str = None, **kwargs):
    url = f"/v1/operation/delete?org_id={org_id}&force=true"
    body = {"namespace": namespace, "group": group, "taskKey": key}

    if execution_id:
        body["executionId"] = execution_id
    else:
        tlog = _lastlog(org_id, namespace, group, key)
        if tlog and tlog.execution_id:
            body["executionId"] = tlog.execution_id

    if exclusive_id:
        body["exclusiveId"] = exclusive_id

    return _tsctl_client.post(url, body)


def cancel(org_id: str, namespace: str, group: str, key: str, **kwargs):
    url = f"/v1/operation/cancel?org_id={org_id}"
    body = {"namespace": namespace, "group": group, "taskKey": key}

    return _tsctl_client.post(url, body)


def retrigger(org_id: str, namespace: str, group: str, key: str, execution_id: str, **kwargs):
    url = f"/v1/operation/retrigger?org_id={org_id}"
    body = {"namespace": namespace, "group": group, "taskKey": key, "executionId": execution_id}

    return _tsctl_client.post(url, body)


def resubmit(org_id: str, namespace: str, group: str, key: str, execution_id: str = None, **kwargs):
    url = f"/v1/operation/resubmit?org_id={org_id}"
    body = {"namespace": namespace, "group": group, "taskKey": key}
    if execution_id:
        body["executionId"] = execution_id

    return _tsctl_client.post(url, body)


def create(org_id: str, namespace: str, task: TaskModel, **kwargs):
    url = f"/v1/namespaces/{namespace}/tasks?org_id={org_id}"
    body = TaskModel.model_dump_json(task)
    return _tsctl_client.post(url, body)


def logs(org_id: str, namespace: str, group: str, key: str, search: str, **kwargs):
    search_parts = []
    if group:
        search_parts.append(f"group $eq {group}")
    if key:
        search_parts.append(f"taskKey $eq {key}")
    if org_id:
        search_parts.append(f"orgId $eq {org_id}")
    if search:
        search_parts.append(f"({search})")
    final_search = " AND ".join(search_parts)
    kwargs["search"] = final_search

    def _get_page(query_string):
        url = f"/v1/namespaces/{namespace}/tasklog?" + query_string
        return _tsctl_client.get(url)

    return PageRequest(_get_page, **kwargs).get()


def _fetch_last_completed_log_for_recurring_tasks(namespace: str, t: TaskModel):
    if not t.schedule:
        return
    if not t.schedule.intervalMs and not t.schedule.cronExpression:
        return

    if t.location is None:
        # hdc task
        kwargs = {
            "size": 10,
            "limit": 1,
            "orderBy": "timeScheduled:desc",
            "search": f"group $eq {t.group} AND taskKey $eq {t.key} AND state $in Success,Error,Canceled",
        }

        def _get_page(query_string):
            url = f"/v1/namespaces/{namespace}/tasklog?" + query_string
            return _tsctl_client.get(url)

        completed_logs = PageRequest(_get_page, **kwargs).get()
        if completed_logs:
            return TaskLog.model_validate(completed_logs[0])
        return None
    else:
        # global task
        # TODO
        return None


def last(org_id: str, namespace: str, group: str, key: str) -> Optional[TaskModel]:
    task = get(org_id, namespace, group, key)
    if not task:
        return
    if task.log:
        return task
    url = f"/v1/namespaces/{namespace}/groups/{group}/tasks/{key}/lastlog"
    task.log = _tsctl_client.get(url)
    return task


def _lastlog(org_id: str, namespace: str, group: str, key: str):
    url = f"/v1/namespaces/{namespace}/groups/{group}/tasks/{key}/lastlog"
    return _tsctl_client.get(url)


def wait(
    org_id: str,
    namespace: str,
    group: str = None,
    key: str = None,
    task: TaskModel = None,
    timeout: str = "1m",
    polling_interval: str = "2s",
    states: Union[str, List[str]] = "Success",
    **kwargs,
):
    if task:
        group = task.group
        key = task.key

    if not namespace:
        raise CtxpException("namespace is required")
    if not group:
        raise CtxpException("group is required")
    if not key:
        raise CtxpException("key is required")

    if isinstance(states, str):
        states = [states]

    terminal_states = ["Success", "Error", "Canceled"]
    transition_states = ["Running", "Init"]
    all_states = terminal_states + transition_states

    # Formalize enum values.
    states = [state[0].upper() + state[1:].lower() for state in states]
    states = ["Canceled" if state == "Cancelled" else state for state in states]

    invalid_states = [state for state in states if state not in all_states]
    if invalid_states:
        raise CtxpException(f"Invalid states: {invalid_states}. Must be one of: {all_states}")

    ready_states = states
    error_states = [state for state in terminal_states if state not in ready_states]
    return wait_for_res_status(
        resource_name=f"{namespace}/{group}/{key}",
        fn_get=lambda: last(org_id=org_id, namespace=namespace, group=group, key=key),
        get_status=lambda t: t.log.state,
        status_map={"ready": ready_states, "error": error_states, "transition": transition_states},
        timeout=timeout,
        polling_interval=polling_interval,
    )


def namespaces():
    return _tsctl_client.get("/v1/namespaces")
