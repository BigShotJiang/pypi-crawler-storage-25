"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util.query_util import PageRequest

from . import uag

_client = hdc_service_client("admin")


def list_resources_by_provider(resource_type: str, provider_instance_id: str, limit: int = 10, **kwargs):
    def _get_page(query_string):
        url = f"/v2/{resource_type}?" + query_string
        return _client.get(url)

    search = f"providerInstanceId $eq {provider_instance_id}"
    return PageRequest(_get_page, search=search, limit=limit, **kwargs).get()


def get_uags_by_edge(edge_id: str, org_id: str):
    uags = uag.list(org_id)
    ret = []
    for u in uags:
        if u["edgeDeploymentId"] == edge_id:
            ret.append(u)
    return ret
