"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util.query_util import PageRequest

_client = hdc_service_client("admin")


def get_compute_vm_skus(provider_instance_id: str, **kwargs):
    def _get_page(query_string):
        url = f"/v2/providers/azure/instances/{provider_instance_id}/compute-vm-skus?" + query_string
        ret = _client.get(url)

        return ret

    return PageRequest(_get_page, **kwargs).get()


def get_networks(providerInstanceId: str, **kwargs):
    url = f"/v2/providers/azure/instances/{providerInstanceId}/preferences/networks"
    return _client.get(url)
