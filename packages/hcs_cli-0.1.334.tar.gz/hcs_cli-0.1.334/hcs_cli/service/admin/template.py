"""
Copyright © 2025-2026 Omnissa, LLC.
"""

# Deprecated.
# To be removed in the future.

from ..template import action as action
from ..template import create as create
from ..template import delete as delete
from ..template import get as get
from ..template import items as items
from ..template import list as list
from ..template import patch as patch
from ..template import wait_for as wait_for
from ..template import wait_for_deleted as wait_for_deleted
from ..template import wait_for_ready as wait_for_ready
