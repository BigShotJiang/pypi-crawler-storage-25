"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import default_crud, hdc_service_client

_client = hdc_service_client("admin")
_crud = default_crud(_client, "/v2/active-directories", "ad")
get = _crud.get
list = _crud.list
create = _crud.create
delete = _crud.delete
