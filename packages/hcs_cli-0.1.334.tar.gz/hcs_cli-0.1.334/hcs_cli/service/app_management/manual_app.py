"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import json

from hcs_core.sglib.client_util import default_crud, hdc_service_client

_client = hdc_service_client("app-management")
_crud = default_crud(_client, "/v1/apps/manual", "apps/manual")
get = _crud.get
list = _crud.list
delete = _crud.delete


def create(application: dict, icon=None):
    text = json.dumps(application)
    files = {"application": ("application", text, "application/json")}
    return _crud.upload(files=files)
