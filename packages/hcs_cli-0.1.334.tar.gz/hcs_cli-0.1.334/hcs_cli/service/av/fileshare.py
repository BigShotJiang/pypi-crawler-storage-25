"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import hdc_service_client, wait_for_res_status
from hcs_core.util import hcs_constants
from hcs_core.util.query_util import with_query

log = logging.getLogger(__name__)
_client = hdc_service_client("av-fileshare")


def get_av_fileshares(**kwargs):
    url = hcs_constants.AV_GET_FILESHARE_API_URL
    url = with_query(url, **kwargs)
    t = _client.get(url)
    return t


def wait_for(provider_instance_id: str, timeout: str = "30m"):
    name = "av-fileshare/" + provider_instance_id

    def fn_get_status(t):
        if t and t.get("content"):
            _status = t["content"][0].get("status")
        else:
            _status = ""
        return _status

    def fn_get_av_fs_info():
        return get_av_fileshares(search=f"name $eq staging-{provider_instance_id} AND providerInstanceId $eq {provider_instance_id}")

    status_map = {"ready": hcs_constants.PROVISION_SUCCESS, "error": hcs_constants.PROVISION_FAILED, "transition": ""}
    return wait_for_res_status(
        resource_name=name, fn_get=fn_get_av_fs_info, get_status=fn_get_status, status_map=status_map, timeout=timeout
    )
