"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util import hcs_constants
from hcs_core.util.query_util import PageRequest, with_query

log = logging.getLogger(__name__)
_client = hdc_service_client("av-appies")


def list_apps(org_id: str, **kwargs):
    def _get_page(query_string):
        url = hcs_constants.AV_GET_APPS_API_URL.format(query_string, org_id)
        return _client.get(url)

    return PageRequest(_get_page, **kwargs).get()


def get_by_names(app_names: list, org_id: str, **kwargs):
    def _get_page(query_string):
        url = hcs_constants.AV_GET_APP_BY_NAME_API_URL.format(org_id, query_string)
        _names = ["'" + str(elem) + "'" for elem in app_names]
        _listToStr = ",".join(_names)
        url += hcs_constants.AV_GET_APP_BY_NAME_SEARCH_PARAM_API_URL + _listToStr
        return _client.get(url)

    return PageRequest(_get_page, **kwargs).get()


def delete(app_name: str, org_id: str, **kwargs):
    _app_rec = get_by_names([app_name], org_id)
    if _app_rec:
        _app_id = _app_rec[0].get("id")
        url = hcs_constants.AV_DELETE_APP_API_URL.format(_app_id, org_id)
        url = with_query(url, **kwargs)
        return _client.delete(url, **kwargs)
