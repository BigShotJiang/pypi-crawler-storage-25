"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util.query_util import PageRequest

_client = hdc_service_client("ims-catalog")


def list(org_id: str, **kwargs):
    def _get_page(query_string):
        url = f"/v1/image-copies?org_id={org_id}&{query_string}"
        return _client.get(url)

    return PageRequest(_get_page, **kwargs).get()
