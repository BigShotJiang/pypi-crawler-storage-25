"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import default_crud, hdc_service_client

_client = hdc_service_client("credentials")
_crud = default_crud(_client, "/v1/credentials", "credentials")

get = _crud.get
