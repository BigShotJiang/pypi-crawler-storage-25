"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util.query_util import with_query

log = logging.getLogger(__name__)
_client = hdc_service_client("portal")


def create(payload: dict):
    url = "/v2/sites"
    return _client.post(url, payload)


def get(id: str, org_id: str):
    url = f"/v2/sites/{id}?org_id={org_id}"
    return _client.get(url)


def list(org_id: str, **kwargs):
    url = with_query(f"/v2/sites?org_id={org_id}", **kwargs)
    return _client.get(url)


def delete(id: str, org_id: str):
    url = f"/v2/sites/{id}?org_id={org_id}"
    return _client.delete(url)


def find_by_name(name: str, org_id: str):
    sites = list(org_id=org_id)
    if not sites:
        return
    for s in sites:
        if s.get("name") == name:
            return s


def set_edge(site_id: str, org_id: str, edge_deployment_id: str):
    url = f"/v1/sites/{site_id}/edge/{edge_deployment_id}"
    return _client.put(url, {})
