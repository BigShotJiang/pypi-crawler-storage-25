"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from typing import Any

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util.query_util import PageRequest, with_query

_client = hdc_service_client("lcm")


def get(id: str, **kwargs: Any):
    url = with_query(f"/v1/providers/{id}", **kwargs)
    return _client.get(url)


def list(**kwargs):
    def _get_page(query_string):
        url = "/v1/providers?" + query_string
        return _client.get(url)

    return PageRequest(_get_page, **kwargs).get()


def delete(id: str):
    ret = _client.delete(f"/v1/providers/{id}")
    return ret


def create(data: dict):
    url = "/v1/providers/" + data["type"].lower()
    return _client.post(url, json=data)
