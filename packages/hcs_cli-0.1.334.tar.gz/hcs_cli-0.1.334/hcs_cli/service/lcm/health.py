"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from typing import Any

from hcs_core.sglib.client_util import hdc_service_client

_client = hdc_service_client("lcm")


def get():
    return _client.get("/v1/health")


class template:
    @staticmethod
    def check_all(org_id: str):
        return _client.post(f"/v1/health/templates?org_id={org_id}")

    @staticmethod
    def check(org_id: str, template_id: str, **kwargs: Any):
        return _client.post(f"/v1/health/templates/{template_id}?org_id={org_id}")
