"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import default_crud, hdc_service_client

_client = hdc_service_client("synthetic-testing")
_crud = default_crud(_client, "/v1/probes", "probe")

list = _crud.list
get = _crud.get
delete = _crud.delete
create = _crud.create
update = _crud.update


def schedule_now(id: str, org_id: str, outpost_ids: list):
    payload = {"outpostIds": outpost_ids}
    url = f"/v1/probes/{id}/schedule-now"
    if org_id:
        url += "?orgId=" + org_id
    return _client.post(url, payload)
