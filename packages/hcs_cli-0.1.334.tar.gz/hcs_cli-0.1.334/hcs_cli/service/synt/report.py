"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import default_crud, hdc_service_client

_client = hdc_service_client("synthetic-testing")
_crud = default_crud(_client, "/v1/reports", "report")

list = _crud.list
get = _crud.get
delete = _crud.delete
create = _crud.create
update = _crud.update
