"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util.query_util import PageRequest

_client = hdc_service_client("tsctl")


def list_namespaces(**kwargs):
    return _client.get("/v1/namespaces")


def list(namespace: str, **kwargs):
    def _get_page(query_string):
        url = f"/v1/namespaces/{namespace}/tasks?" + query_string
        return _client.get(url)

    return PageRequest(_get_page, **kwargs).get()


def get(namespace: str, task_id: str):
    return
