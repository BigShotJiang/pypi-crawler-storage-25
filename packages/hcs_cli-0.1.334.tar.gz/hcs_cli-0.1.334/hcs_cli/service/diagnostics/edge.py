"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import hdc_service_client

log = logging.getLogger(__name__)

_client = hdc_service_client("admin")
base_context = "/v2/edge-deployments"


def diagnose_get_pods(id: str, org_id: str, verbose: bool):
    url = f"{base_context}/{id}/diagnose?org_id={org_id}"
    payload = dict()
    payload["diagnosticType"] = "GET_PODS"
    if verbose:
        log.info(f"get pods - payload: url: {url}, {payload}")
    return _client.post(url, payload, timeout=120)


def diagnose_url_accessibility(id: str, org_id: str, namespace: str, podname: str, url2check: str, verbose: bool):
    url = f"{base_context}/{id}/diagnose?org_id={org_id}"
    payload = dict()
    payload["diagnosticType"] = "URL_ACCESSIBILITY"
    payload["containerName"] = "app"
    payload["podName"] = podname
    payload["url"] = url2check
    payload["namespace"] = namespace

    if verbose:
        log.info(f"get url - url: {url}, {payload}")
    return _client.post(url, payload, timeout=120)
