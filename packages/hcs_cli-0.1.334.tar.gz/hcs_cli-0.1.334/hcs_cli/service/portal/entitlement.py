"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import default_crud, hdc_service_client

log = logging.getLogger(__name__)
_client = hdc_service_client("portal")
_crud = default_crud(_client, "/v2/entitlements", "entitlement")

create = _crud.create
get = _crud.get
list = _crud.list
delete = _crud.delete
