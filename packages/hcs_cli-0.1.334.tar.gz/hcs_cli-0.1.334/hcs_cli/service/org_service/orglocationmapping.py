"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import hdc_service_client

_client = hdc_service_client("org-service")


def create(payload):
    url = "/v1/orglocationmapping"
    return _client.post(url, payload)


def get(org_id: str):
    url = f"/v1/orglocationmapping/{org_id}"
    return _client.get(url)


def list_all():
    url = "/v1/orglocationmapping"
    return _client.get(url)
