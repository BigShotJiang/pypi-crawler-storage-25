"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.sglib.client_util import hdc_service_client
from hcs_core.util.query_util import with_query

_client = hdc_service_client("org-service")


def get(id: str, **kwargs):
    url = with_query(f"/v1/datacenters/{id}", **kwargs)
    return _client.get(url)


def list(**kwargs):
    url = with_query("/v1/datacenters", **kwargs)
    return _client.get(url)


def create(payload):
    url = "/v1/datacenters"
    return _client.post(url, payload)


def find_by_org(orgId, **kwargs):
    url = with_query(f"/v1/datacenters/orgs/{orgId}", **kwargs)
    return _client.get(url)
