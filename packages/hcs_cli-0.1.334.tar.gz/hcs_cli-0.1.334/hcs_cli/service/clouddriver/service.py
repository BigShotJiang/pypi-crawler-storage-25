"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import hdc_service_client

log = logging.getLogger(__name__)
_client = hdc_service_client("clouddriver")


def action(name: str, params: dict):
    return _client.post(f"/v1/action/{name}", params)


def health():
    return _client.get("/v1/health")
