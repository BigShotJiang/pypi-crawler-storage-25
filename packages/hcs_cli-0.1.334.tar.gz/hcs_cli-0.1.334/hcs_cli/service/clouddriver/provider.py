"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import hdc_service_client

log = logging.getLogger(__name__)
_client = hdc_service_client("clouddriver")


def summary():
    return _client.get("/v1/providers/summary")


def info(provider: str):
    return _client.get(f"/v1/providers/{provider}/info")


def delete(provider: str, force: bool = False):
    return _client.delete(f"/v1/providers/{provider}?force={force}")


def tasks(provider: str):
    return _client.post(f"/v1/providers/{provider}/tasks", [])


def get_task(provider: str, task_id: str):
    return _client.get(f"/v1/providers/{provider}/tasks/{task_id}")


def delete_task(provider: str, task_id: str):
    return _client.delete(f"/v1/providers/{provider}/tasks/{task_id}")
