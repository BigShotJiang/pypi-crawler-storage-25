"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

from hcs_core.sglib.client_util import default_crud

log = logging.getLogger(__name__)

_crud = default_crud("portal", "/v3/pools", "pool")

create = _crud.create
get = _crud.get
update = _crud.update


def list(org_id: str, exclude_disabled_pools: bool = False, include_internal_pools: bool = True, **kwargs):
    return _crud.list(org_id, exclude_disabled_pools=exclude_disabled_pools, include_internal_pools=include_internal_pools, **kwargs)


def delete(id: str, org_id: str, delete: bool = True, disassociateAction: str = "FORCEFUL", **kwargs):
    return _crud.delete(id, org_id, delete=delete, disassociateAction=disassociateAction, **kwargs)
