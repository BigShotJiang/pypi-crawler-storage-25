"""
Copyright © 2025 Omnissa, LLC.
"""

import sys

from .main import main

if __name__ == "__main__":
    sys.exit(main())
