"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

import hcs_cli.service.synt.probe as probe


@click.command()
@cli.search
@cli.limit
@cli.sort
@cli.org_id
def list(org: str, **kwargs):
    """List outposts"""
    org_id = cli.get_org_id(org)
    return probe.list(org_id=org_id, **kwargs)
