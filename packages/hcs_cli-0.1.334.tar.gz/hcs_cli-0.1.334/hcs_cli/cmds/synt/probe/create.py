"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import json
import sys

import click
import hcs_core.sglib.cli_options as cli

import hcs_cli.service.synt.probe as probe


@click.command()
@click.option(
    "--file",
    "-f",
    type=click.File("rt"),
    default=sys.stdin,
    help="Specify the probe file name. If not specified, STDIN will be used.",
)
@click.option(
    "--outposts",
    type=str,
    required=False,
    help="List of outpost IDs, in comma-separated string. If specified, will overrride the existing outpostIds in the file, if any.",
)
@cli.org_id
def create(file: str, outposts: str, org: str, **kwargs):
    """Create a probe"""

    with file:
        data = file.read()

    try:
        payload = json.loads(data)
    except Exception as e:
        msg = "Invalid probe data: " + str(e)
        return msg, 1

    org_id = cli.get_org_id(org)

    if outposts:
        ids = outposts.split(",")
        payload["outpostIds"] = ids
    # return payload
    return probe.create(payload=payload, org_id=org_id, **kwargs)
