"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

import hcs_cli.service.synt.probe as probe


@click.command()
@click.argument("id")
@click.option(
    "--outposts",
    type=str,
    required=True,
    help="List of outpost IDs, in comma-separated string. If specified, will overrride the existing outpostIds in the file, if any.",
)
@cli.org_id
def update(id: str, outposts: str, org: str, **kwargs):
    """Update a probe"""

    org_id = cli.get_org_id(org)

    ids = outposts.split(",")
    data = {"outpostIds": ids}
    return probe.update(id, org_id=org_id, data=data, **kwargs)
