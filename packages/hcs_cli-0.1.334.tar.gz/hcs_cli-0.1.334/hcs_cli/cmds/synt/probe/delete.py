"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

import hcs_cli.service.synt.probe as probe


@click.command()
@cli.org_id
@click.argument("id", type=str, required=True)
def delete(org: str, id: str, **kwargs):
    """Delete outpost by ID"""
    org_id = cli.get_org_id(org)
    return probe.delete(id=id, org_id=org_id, **kwargs)
