"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp.util import parse_kv_pairs

import hcs_cli.service.synt.outpost as outpost


@click.command()
@click.argument("id", type=str, required=True)
@click.option("--name", "-n", type=str, required=False)
@click.option(
    "--property",
    "-p",
    type=str,
    required=False,
    multiple=True,
    help="Property in '=' separated key-value pair. This parameter can be specified multiple times.",
)
@cli.org_id
def update(id: str, name: str, property: str, org: str, **kwargs):
    """Update an existing template"""

    org_id = cli.get_org_id(org)

    data = {}
    if name:
        data["name"] = name
    properties = parse_kv_pairs(property)
    if properties:
        data["properties"] = properties
    return outpost.update(id=id, org_id=org_id, data=data, **kwargs)
