"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp.util import parse_kv_pairs

import hcs_cli.service.synt.outpost as outpost


@click.command()
@click.option("--name", "-n", type=str, required=True, help="Specify the outpost name.")
@click.option("--region", "-r", type=str, required=True, help="Specify the outpost region.")
@click.option(
    "--type",
    "-t",
    type=click.Choice(["CLOUD_HOSTED", "ON_PREM"], case_sensitive=False),
    required=True,
    help="Specify the outpost name.",
)
@click.option(
    "--property",
    "-p",
    type=str,
    required=False,
    multiple=True,
    help="Property in '=' separated key-value pair. This parameter can be specified multiple times.",
)
def create(name: str, region: str, type: str, property: list, **kwargs):
    """Create an outpost"""

    payload = {"name": name, "properties": parse_kv_pairs(property), "region": region, "type": type}
    return outpost.create(payload, **kwargs)
    # return payload
