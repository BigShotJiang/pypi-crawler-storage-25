"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

import hcs_cli.service.synt.report as report


@click.command()
@cli.search
@cli.limit
@cli.sort
@cli.org_id
def list(org: str, **kwargs):
    """List reports"""
    org_id = cli.get_org_id(org)
    return report.list(org_id=org_id, **kwargs)
