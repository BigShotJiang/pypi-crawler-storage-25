"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Synthetic testing (Availability Monitor) service commands."
