"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import os

import click
from hcs_core.ctxp import recent

from hcs_cli.support import plan_util


@click.command()
@click.argument("file", type=str, required=False)
def use(file: str):
    """Set or show the default plan file to work with."""
    if file:
        plan_util.validate_plan_file(file)
        # use the file
        abs_path = os.path.abspath(file)
        recent.set("plan-file", abs_path)
    else:
        return recent.get("plan-file")
