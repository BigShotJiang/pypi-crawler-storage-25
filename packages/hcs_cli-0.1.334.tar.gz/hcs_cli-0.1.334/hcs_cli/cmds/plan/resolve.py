"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.plan as plan

import hcs_cli.support.plan_util as plan_util


@click.command()
@click.option("--file", "-f", type=click.File("rt"), required=False, help="Specified the plan file.")
@click.option("--resource", "-r", type=str, required=False, help="Show a specific resource.")
def resolve(file, resource: str):
    """Resolve variables (as many as possible) in a plan file."""

    data, extra = plan_util.load_plan(file)
    ret = plan.resolve(data, additional_context=extra, target_resource_name=resource)
    return ret
