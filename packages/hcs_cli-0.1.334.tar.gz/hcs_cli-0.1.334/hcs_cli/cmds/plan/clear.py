"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.plan as plan

import hcs_cli.support.plan_util as plan_util


@click.command()
@click.option("--file", "-f", type=click.File("rt"), required=False, help="Specified the plan file.")
@click.option("--resource", "-r", type=str, required=True)
def clear(file, resource: str):
    """Clean the deployment state of a specific resource and enforce recheck for the next deployment."""

    data, extra = plan_util.load_plan(file)
    return plan.clear(data, resource, extra)
