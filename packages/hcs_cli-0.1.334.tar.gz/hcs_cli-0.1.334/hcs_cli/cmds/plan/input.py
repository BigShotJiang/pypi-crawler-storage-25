"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.plan as plan

import hcs_cli.support.plan_util as plan_util


@click.command()
@click.option("--file", "-f", type=click.File("rt"), required=False, help="Specified the plan file.")
@click.option("--resource", "-r", type=str, required=False, help="Show a specific resource.")
def input(file, resource: str):
    """Show resource input data."""

    data, extra = plan_util.load_plan(file)
    input_data, output_data = plan.get_deployment_data(data, extra, resource)

    if resource:
        if resource not in input_data:
            return f"Resource '{resource}' is not found in blueprint.", 1
        v = None
        if resource in input_data:
            v = input_data[resource]
        return v
    else:
        return input_data
