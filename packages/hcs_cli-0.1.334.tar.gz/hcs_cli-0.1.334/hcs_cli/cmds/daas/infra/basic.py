"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.ctxp as ctxp
from hcs_ext_daas import infra


@click.command()
def get():
    """Get the shared infrastructure config."""
    return infra.get()


@click.command()
def file():
    """Get the infrastructure config file path."""
    return infra.file()


@click.command()
def edit():
    """Launch text editor to edit the config file directly"""
    file = infra.file()
    ctxp.util.launch_text_editor(file)
