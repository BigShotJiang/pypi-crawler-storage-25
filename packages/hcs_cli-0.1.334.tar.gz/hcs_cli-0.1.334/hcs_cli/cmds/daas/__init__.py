"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Desktop-as-a-Service Operations."
extension = "hcs-ext-daas"
