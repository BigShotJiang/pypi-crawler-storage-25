"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import error


@click.command()
@click.argument("deployment-id", type=str, required=True)
def consumption(deployment_id):
    """Get the consumption information of the tenant."""

    # print(org_id, deployment_id)

    return error("The consumption service is not available on production yet.")
