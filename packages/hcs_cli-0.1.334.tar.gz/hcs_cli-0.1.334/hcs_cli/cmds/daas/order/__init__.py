"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Tenant order operations."
