"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging

import click
from hcs_core.ctxp import choose
from hcs_ext_daas import order

_context = {}
log = logging.getLogger(__file__)


@click.command()
def delete():
    if not order.get():
        raise Exception("No orders found to delete")

    orders = {k: v for k, v in order.get().items() if k != "deleted"}
    order_types = list(orders.keys())
    order_type = choose("Select order type to delete:", order_types)
    while True:
        query = input("Confirm deletion of order type '{}' with yes or no : ".format(order_type))
        if query == "" or query.lower() not in ["yes", "no"]:
            print("Please answer with yes or no!")
        else:
            break

    if query == "yes":
        order.remove(order_type)
        print(f"Successfully deleted order type {order_type}")
