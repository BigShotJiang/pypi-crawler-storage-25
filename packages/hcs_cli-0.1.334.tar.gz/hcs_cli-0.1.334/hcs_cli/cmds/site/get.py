"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import site


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
def get(id: str, org: str):
    """Get site."""
    org_id = cli.get_org_id(org)
    id = recent.require("site", id)
    ret = site.get(id, org_id)
    if ret:
        return ret
    return "", 1
