"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import site
from hcs_cli.support import use_util


@click.command()
@click.argument("smart_search", type=str, required=False)
@click.option("--interactive/--fail-on-multi-match", type=bool, required=False, default=True)
@cli.org_id
def use(smart_search: str, interactive: bool, org: str):
    "Helper command to work with a specific object, by smart search."

    if not smart_search:
        return recent.get("site")

    sites = site.list(site.list(org_id=cli.get_org_id(org)))
    ret = use_util.smart_search(sites, smart_search)

    return use_util.require_single(items=ret, resource_type="site", name_field="name", interactive=interactive)
