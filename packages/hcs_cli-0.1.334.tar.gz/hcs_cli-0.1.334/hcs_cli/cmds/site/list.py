"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import site


@click.command()
@cli.org_id
def list(org: str, **kwargs):
    """List sites"""
    ret = site.list(org_id=cli.get_org_id(org), **kwargs)
    recent.helper.default_list(ret, "site")
    return ret
