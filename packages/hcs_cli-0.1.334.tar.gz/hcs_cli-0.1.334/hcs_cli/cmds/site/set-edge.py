"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import site


@click.command()
@click.argument("site-id", required=False)
@click.option("--edge", type=str, required=False, help="Edge deployment ID.")
@cli.org_id
def set_edge(site_id: str, edge: str, org: str, **kwargs):
    """Set the edge for a site."""
    site_id = recent.require("site", site_id)
    edge_id = recent.require("edge", edge)
    org_id = cli.get_org_id(org)
    return site.set_edge(site_id, org_id, edge_id, **kwargs)
