"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import site


@click.command()
@click.option("--name", "-n", type=str, required=True)
@click.option("--description", "-d", type=str, required=False)
@cli.org_id
def create(name: str, description: str, org: str):
    """Create a site."""
    org_id = cli.get_org_id(org)
    payload = {"name": name, "description": description, "orgId": org_id}
    ret = site.create(payload)
    if ret:
        recent.set("site", ret["id"])
        return ret
    return ret, 1
