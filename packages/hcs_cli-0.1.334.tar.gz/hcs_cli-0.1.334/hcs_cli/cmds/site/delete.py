"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import site


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.confirm
def delete(id: str, org: str, confirm: bool):
    """Delete a site."""
    org_id = cli.get_org_id(org)
    id = recent.require("site", id)

    ret = site.get(id, org_id)
    if not ret:
        return

    if not confirm:
        click.confirm(f"Delete site {ret['name']} ({id})?", abort=True)

    ret = site.delete(id, org_id)
    return ret
