"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin

_all_status = ["READY", "ERROR", "DELETING", "EXPANDING", "SHRINKING", "CUSTOMIZING", "MAINTENANCE"]


@click.command()
@cli.org_id
@click.argument("id", type=str, required=False)
@click.option(
    "--status",
    "-s",
    type=click.Choice(_all_status, case_sensitive=False),
    required=False,
    default="READY",
    help="The target status to wait for.",
)
@click.option("--timeout", "-t", type=str, required=False, default="1m", help="Timeout. Examples: '2m', '30s', '1h30m'")
@click.option(
    "--fail-fast/--fail-timeout",
    "-f",
    type=bool,
    default=True,
    required=False,
    help="Stop waiting if the template reached to non-expected terminal states, e.g. waiting for ERROR but template is READY, or waiting for READY and template is ERROR.",
)
@click.option(
    "--silent/--return-object",
    type=bool,
    required=False,
    default=True,
    help="Slient mode will has no output on success. Otherwise the full template is returned",
)
def wait(org: str, id: str, status: str, timeout: str, fail_fast: bool, silent: bool):
    """Wait for a template to transit to specific status."""

    org_id = cli.get_org_id(org)
    target_status = status.upper().split(",")
    unexpected_status = []
    if fail_fast:
        if "READY" not in target_status:
            unexpected_status.append("READY")
        if "ERROR" not in target_status:
            unexpected_status.append("ERROR")

    id = recent.require("template", id)
    try:
        template = admin.template.wait_for(
            id=id, org_id=org_id, target_status=target_status, unexpected_status=unexpected_status, timeout=timeout
        )
        return template if not silent else None
    except Exception as e:
        return str(e), 1
