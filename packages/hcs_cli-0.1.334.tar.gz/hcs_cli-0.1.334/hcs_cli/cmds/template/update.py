"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
import hcs_core.util.duration as duration
from hcs_core.ctxp import recent

import hcs_cli.service.admin as admin
from hcs_cli.support.patch_util import calculate_patch


@click.command()
@click.argument("template_id", type=str, required=False)
@click.option(
    "--update",
    "-u",
    type=str,
    multiple=True,
    required=True,
    help="Specify field and value pair to update. E.g. '-u sparePolicy.max=3'.",
)
@cli.org_id
@cli.wait
def update(template_id: str, update, org: str, wait: str, **kwargs):
    """Update an existing template"""

    org_id = cli.get_org_id(org)

    template_id = recent.require("template", template_id)
    template = admin.template.get(template_id, org_id)

    if not template:
        return "Template not found: " + template_id, 1

    allowed_fields = ["name", "description", "powerPolicy", "sparePolicy", "applicationProperties", "flags"]

    patch = calculate_patch(template, allowed_fields, update)

    if not patch:
        return template

    ret = admin.template.patch(template_id, org_id, patch)
    if wait != "0":
        ret = admin.template.wait_for_ready(template_id, org_id, duration.to_seconds(wait))
    return ret
