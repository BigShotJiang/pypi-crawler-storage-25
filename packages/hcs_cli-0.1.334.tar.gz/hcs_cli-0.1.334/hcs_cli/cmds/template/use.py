"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import recent
from hcs_core.sglib import cli_options as cli

from hcs_cli.service import admin
from hcs_cli.support import use_util


@click.command()
@cli.org_id
@click.argument("smart_search", type=str, required=False)
@click.option("--interactive/--fail-on-multi-match", type=bool, required=False, default=True)
def use(org: str, smart_search: str, interactive: bool):
    "Helper command to work with a specific template, by smart search."

    if not smart_search:
        return recent.get("template")
    org_id = cli.get_org_id(org)
    if use_util.looks_like_id(smart_search):
        ret = admin.template.get(smart_search, org_id)
    else:
        ret = admin.template.list(org_id, search=f"name $like '{smart_search}'")

    return use_util.require_single(items=ret, resource_type="template", interactive=interactive)
