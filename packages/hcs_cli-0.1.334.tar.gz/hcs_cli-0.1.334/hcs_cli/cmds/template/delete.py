"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin


@click.command()
@click.argument("id", type=str, required=False)
@cli.force
@cli.confirm
@cli.org_id
@cli.wait
def delete(id: str, force: bool, confirm: bool, org: str, wait: str):
    """Delete template by ID"""

    org_id = cli.get_org_id(org)
    id = recent.require("template", id)
    ret = admin.template.get(id, org_id)
    if not ret:
        return ""

    if not confirm:
        click.confirm(f"Delete template {ret['name']} ({id})?", abort=True)

    ret = admin.template.delete(id, org_id, force)

    if wait == "0":
        return ret

    admin.template.wait_for_deleted(id, org_id, wait)
