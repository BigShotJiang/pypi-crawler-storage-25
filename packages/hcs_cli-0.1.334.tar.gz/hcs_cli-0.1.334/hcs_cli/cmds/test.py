"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.ctxp.cli_options as cli
from hcs_core.ctxp.extension import ensure_extension


@click.group(hidden=True)
def test():
    """Test."""


@test.command()
def demo():
    ensure_extension("hcs-ext-demo")
    import hcs_ext_demo.main as demo

    print(demo.description())


@test.command()
@cli.limit
@click.option("--sim-ret", required=False)
@click.argument("sim_err", required=False)
def env(sim_ret: int, sim_err, limit, **kwargs):
    import os

    if sim_ret:
        return f"return with sim_ret: {sim_ret}", int(sim_ret)

    if sim_err:
        raise Exception("simulated error: " + sim_err)

    return {k: v for k, v in os.environ.items() if k.lower().startswith("hcs_")}
