"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.app_management import manual_app


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.confirm
def delete(id: str, org: str, confirm: bool, **kwargs):
    """Delete manual app record by ID"""

    org_id = cli.get_org_id(org)
    id = recent.require("app", id)

    if not confirm:
        ret = manual_app.get(id, org_id=org_id)
        if not ret:
            return ""
        click.confirm(f"Delete app record {ret['name']} ({id})?", abort=True)

    ret = manual_app.delete(id, org_id)
    if not ret:
        return ""
    return ret
