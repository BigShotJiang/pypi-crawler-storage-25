"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.app_management import manual_app


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
def get(id: str, org: str):
    """Get manual app record by ID"""
    id = recent.require("app", id)
    ret = manual_app.get(id, org_id=cli.get_org_id(org))

    print("TODO")
    return ret, 1
