"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.app_management import manual_app


@click.command()
@cli.limit
@cli.org_id
def list(org: str, **kwargs):
    """List apps"""
    ret = manual_app.list(org_id=cli.get_org_id(org), **kwargs)
    recent.helper.default_list(ret, "app")
    return ret
