"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Manual app commands."
