"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.limit
def vsphere_dcs(id: str, org: str, **kwargs):
    """List vSphere datacenters"""
    org_id = cli.get_org_id(org)
    id = recent.require("provider", id)

    return admin.provider.list_vsphere_dcs(id, org_id=org_id, **kwargs)
