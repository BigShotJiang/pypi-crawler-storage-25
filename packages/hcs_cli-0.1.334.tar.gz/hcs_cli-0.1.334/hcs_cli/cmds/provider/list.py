"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin
from hcs_cli.support.constant import provider_labels


@click.command()
@cli.org_id
@cli.limit
@cli.sort
@cli.search
@cli.formatter(columns={"providerLabel": "Label"})
@click.option(
    "--label",
    type=click.Choice(provider_labels, case_sensitive=False),
    required=False,
    help="Specify the provider label",
)
def list(org: str, label: str, **kwargs):
    """List provider instances"""
    org_id = cli.get_org_id(org)

    if label:
        ret = admin.provider.list(label, org_id, **kwargs)
    else:
        # list all
        ret = []
        for label in provider_labels:
            ret += admin.provider.list(label, org_id, **kwargs)

    recent.helper.default_list(ret, "provider")

    return ret
