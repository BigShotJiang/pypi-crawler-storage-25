"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin
from hcs_cli.support.constant import provider_labels


@click.command()
@click.argument("id", type=str, required=False)
@click.option("--label", type=click.Choice(provider_labels, case_sensitive=False), required=False)
@cli.org_id
@cli.confirm
def delete(label: str, id: str, org: str, confirm: bool):
    """Delete provider by ID"""
    id = recent.require("provider", id)
    org_id = cli.get_org_id(org)

    ret = _find(label, id, org_id)
    if not ret:
        return

    if not confirm:
        click.confirm(f"Delete provider {ret['name']} ({id})?", abort=True)

    ret = admin.provider.delete(ret["providerLabel"], id, org_id=cli.get_org_id(org), force=True)
    if ret:
        return ""
    return "", 1


def _find(label: str, id: str, org_id: str):
    if label:
        return admin.provider.get(label, id, org_id)
    for label in provider_labels:
        ret = admin.provider.get(label, id, org_id)
        if ret:
            return ret
