"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin
from hcs_cli.support.constant import provider_labels


def _get(label: str, org_id: str, id: str):
    ret = admin.provider.get(label, id, org_id=org_id)
    if ret:
        return ret
    ret = admin.provider.list(label=label, org_id=org_id, search="name $eq " + id)
    if ret:
        return ret[0]
    return None


@click.command()
@click.argument("id", type=str, required=False)
@click.option("--label", type=click.Choice(provider_labels, case_sensitive=False), required=False)
@cli.org_id
def get(label: str, id: str, org: str, **kwargs):
    """Get provider by ID or name"""
    org_id = cli.get_org_id(org)
    id = recent.require("provider", id)

    if label:
        ret = _get(label, org_id, id)
        return ret if ret else ("", 1)

    for label in provider_labels:
        ret = _get(label, org_id, id)
        if ret:
            return ret
    return "", 1
