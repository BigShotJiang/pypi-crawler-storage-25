"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import org_service


@click.group()
def location():
    pass


@location.command()
@cli.org_id
def get(org: str):
    return org_service.orglocationmapping.get(cli.get_org_id(org))


@location.command("list")
def list_all():
    return org_service.orglocationmapping.list_all()
