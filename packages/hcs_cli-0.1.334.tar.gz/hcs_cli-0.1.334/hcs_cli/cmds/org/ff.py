"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import csp


@click.command()
@cli.org_id
def ff(org: str):
    "List org CSP feature flags"

    org_id = cli.get_org_id(org)

    return csp.ff.list(org_id)
