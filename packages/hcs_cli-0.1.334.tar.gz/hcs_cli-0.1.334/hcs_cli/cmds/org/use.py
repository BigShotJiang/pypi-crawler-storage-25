"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import recent

from hcs_cli.service import org_service
from hcs_cli.support import use_util


@click.command()
@click.argument("smart_search", type=str, required=False)
@click.option("--interactive/--fail-on-multi-match", type=bool, required=False, default=True)
def use(smart_search: str, interactive: bool):
    "Helper command to work with a specific org, by smart search."

    current = recent.get("org")
    if not smart_search:
        return current

    smart_search = smart_search.strip()

    if use_util.looks_like_id(smart_search):
        ret = org_service.details.list(search=f"orgId $eq {smart_search}")
        # if not ret:
        #     # try wsOneOrgId
        #     ret = org_service.details.list(search=f"wsOneOrgId $eq '{smart_search}'")
    else:
        search = f"orgName $like '{smart_search}' OR orgId $like '{smart_search}' OR customerName $like '{smart_search}'"
        ret = org_service.details.list(search=search)

    id_field = "orgId"
    result = use_util.require_single(items=ret, resource_type="org", id_field=id_field, name_field="orgName", interactive=interactive)

    # if org changed, reset everything
    if isinstance(result, dict):
        id = result[id_field]
        if id != current:
            recent.unset_all()
            recent.set("org", id)
    return result
