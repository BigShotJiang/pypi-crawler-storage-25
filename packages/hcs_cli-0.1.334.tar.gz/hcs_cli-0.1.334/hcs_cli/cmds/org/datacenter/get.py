"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import recent

from hcs_cli.service.org_service import datacenter


@click.command()
@click.argument("id", type=str, required=False)
def get(id: str):
    """Get datacenter by ID"""
    id = recent.require("datacenter", id)
    ret = datacenter.get(id)
    if ret:
        return ret
    return ret, 1
