"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.org_service import datacenter


@click.command("list")
@cli.org_id
def list_datacenters(org: str):
    """List all datacenters"""

    if org == "" or org == "all":
        ret = datacenter.list()
        recent.helper.default_list(ret, "datacenter")
    else:
        org_id = cli.get_org_id(org)
        ret = datacenter.find_by_org(org_id)
        if ret:
            if isinstance(ret, list):
                id = ret[0]["id"]
            else:
                id = ret.get("id")
        else:
            id = None
        recent.set("datacenter", id)

    return ret
