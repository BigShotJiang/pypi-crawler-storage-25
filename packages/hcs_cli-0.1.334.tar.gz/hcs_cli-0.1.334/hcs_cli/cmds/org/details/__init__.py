"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Org details commands."
hidden = True

# obsoleted
from hcs_cli.cmds.org.get import get as get
from hcs_cli.cmds.org.list import list_orgs as list_orgs
