"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import inventory
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@cli.org_id
@click.argument("vm_path", type=str, required=False)
def get(org: str, vm_path: str):
    """Get template VM by path, e.g., template1/vm1."""
    template, vm = parse_vm_path(vm_path)
    ret = inventory.get(template, vm, cli.get_org_id(org))
    if not ret:
        return "", 1
    return ret
