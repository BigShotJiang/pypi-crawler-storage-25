"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.ctxp.data_util as data_util
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import inventory
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@cli.org_id
@click.option(
    "--update",
    "-u",
    type=str,
    required=True,
    help="Specify field and value pair to update. E.g., '-f lifecycleStatus=MAINTENANCE'.",
)
@click.argument("vm_path", type=str, required=False)
def update(org: str, update: str, vm_path: str):
    """Update a specific VM."""
    template_id, vm_id = parse_vm_path(vm_path)

    org_id = cli.get_org_id(org)
    existing_vm = inventory.get(template_id, vm_id, org_id)
    if not existing_vm:
        return "VM not found", 1

    k, v = update.split("=")

    current_value = data_util.deep_get_attr(existing_vm, k)
    if str(current_value) == str(v):
        return existing_vm

    # data_util.deep_set_attr(vm, k, v)
    body = {k: v}
    ret = inventory.update(template_id, vm_id, org_id, body)
    return ret
