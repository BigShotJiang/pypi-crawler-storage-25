"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import inventory
from hcs_cli.support.param_util import parse_vm_path


@click.group()
def session():
    pass


@session.command()
@cli.org_id
@click.argument("vm_path", type=str, required=False)
def list(org: str, vm_path: str):
    """List sessions"""
    template, vm = parse_vm_path(vm_path)
    ret = inventory.sessions(template, vm, cli.get_org_id(org))
    if ret:
        return ret
    return ret, 1
