"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import panic

from hcs_cli.service.pki import certificate


@click.command()
@cli.org_id
@cli.confirm
def delete(org: str, confirm: bool):
    """Delete the signing certificate of a specific org"""

    if not confirm:
        panic('Delete an org certificate will impact some service. Specify "--confirm" to perform the deletion.')
    org_id = cli.get_org_id(org)
    return certificate.delete_org_cert(org_id)
