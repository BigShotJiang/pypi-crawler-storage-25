"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.pki import certificate


@click.command()
@cli.org_id
def get(org: str):
    """Get the signing certificate of a specific org"""
    org_id = cli.get_org_id(org)
    return certificate.get_org_cert(org_id)
