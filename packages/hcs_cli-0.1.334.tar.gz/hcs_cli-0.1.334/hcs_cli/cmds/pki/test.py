"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click

from hcs_cli.service.pki import certificate


@click.command(hidden=True)
def test():
    return certificate.test()
