"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click

from hcs_cli.service.pki import certificate


@click.command()
@click.option("--label", "-l", "ca_label", type=str, required=False)
@click.option("--all", "-a", is_flag=True, default=False, help="Get all root CAs.")
def ca(ca_label: str, all: bool):
    """Get the certificate of the root CA."""

    if ca_label and all:
        raise click.BadParameter("You cannot specify both --label and --all. Use one or the other.")
    if all:
        return certificate.get_all_root_ca()
    ca_map = certificate.get_all_root_ca()
    if not ca_label:
        ca_label = "omnissa"
    return ca_map.get(ca_label)
