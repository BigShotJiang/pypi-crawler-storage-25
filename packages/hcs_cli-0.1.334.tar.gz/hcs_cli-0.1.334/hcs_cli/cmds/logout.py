"""
Copyright © 2025 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import profile


@click.command()
def logout():
    """Logout the current profile."""
    profile.auth.delete()
