"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Smart Capacity Management service commands."
