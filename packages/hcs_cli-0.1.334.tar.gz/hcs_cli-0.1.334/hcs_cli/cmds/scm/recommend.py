"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

import hcs_cli.service.scm as scm


@click.command
@cli.org_id
@click.option("--type", "param", type=click.Choice(["power_policy"], case_sensitive=False))
@click.argument("template-id", required=False)
def recommend(org: str, type: str, template_id: str):
    org = cli.get_org_id(org)
    template_id = recent.require("template", template_id)
    print(org, template_id)

    if type == "power_policy":
        return scm.recommend_power_policy(org_id=org, template_id=template_id)

    return "Unsupported recommendation type: {}".format(type)
