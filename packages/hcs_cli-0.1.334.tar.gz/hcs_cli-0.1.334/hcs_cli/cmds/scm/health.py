"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

import hcs_cli.service.scm as scm


@click.command
def health():
    return scm.health()


@click.command
@cli.org_id
@click.argument("param", required=False)
def info(org: str, param: str):
    org = cli.get_org_id(org)
    return scm.info(org_id=org, param=param)
