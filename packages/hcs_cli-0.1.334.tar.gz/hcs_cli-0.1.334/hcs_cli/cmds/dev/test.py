"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import logging
import time

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import scm

log = logging.getLogger("test")


@click.command(hidden=True)
@cli.org_id
def test(org: str, **kwargs):
    while True:
        try:
            h = scm.health()
        except Exception:
            raise
        log.info(f"tick: {h}")
        time.sleep(60)
