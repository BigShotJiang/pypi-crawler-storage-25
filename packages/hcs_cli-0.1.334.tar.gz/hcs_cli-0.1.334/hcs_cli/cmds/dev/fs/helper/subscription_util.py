import os
import uuid

from hcs_core.ctxp import profile
from hcs_core.sglib.hcs_client import hcs_client

from hcs_cli.cmds.dev.util import log


def _get_client():
    """Build an hcs_client using the same credential resolution pattern as license_info."""
    current_profile = profile.current()
    client_id = os.environ.get("CSP_LICENSE_SVC_CLIENT_ID")
    client_secret = os.environ.get("CSP_LICENSE_SVC_CLIENT_SECRET")

    while True:
        if client_id:
            log.trivial("Using credentials from env CSP_LICENSE_SVC_CLIENT_ID")
            break

        override = current_profile.override
        if override:
            admin_override = override.get("admin")
            if admin_override:
                log.trivial("Using admin service override from current profile...")
                client_id = admin_override["client-id"]
                client_secret = admin_override["client-secret"]
                break

        log.warn("No admin override found in current profile. Using default credentials.")
        client_id = None
        break

    if client_id:
        client = hcs_client(
            current_profile.hcs.url,
            {
                "url": current_profile.csp.url,
                "client_id": client_id,
                "client_secret": client_secret,
            },
        )
    else:
        client = hcs_client(url=current_profile.hcs.url, custom_auth=current_profile.csp)

    return client, current_profile


def create_subscription():
    """
    Step 8.1 – Create a subscription.
    POST /subscription/v1/subscriptions
    Returns the hcsSubscriptionId from the response.
    """
    client, current_profile = _get_client()
    namespace = profile.name()

    data = {
        "customerName": f"{namespace}-dev",
        "customerType": "INTERNAL",
        "sid": "M222222222",
        "eaId": "123456789",
        "status": "ACTIVE",
        "region": "NA",
        "country": "US",
    }

    log.trivial("Creating subscription...")
    response_data = client.post("/subscription/v1/subscriptions", json=data)
    log.good(f"Successfully created subscription: {response_data}")

    hcs_subscription_id = response_data.get("hcsSubscriptionId") if isinstance(response_data, dict) else None
    if not hcs_subscription_id:
        raise Exception(f"Could not extract hcsSubscriptionId from response: {response_data}")

    log.info(f"hcsSubscriptionId: {hcs_subscription_id}")
    return hcs_subscription_id


def add_subscription_license(hcs_subscription_id: str):
    """
    Step 8.2 – Add a subscription license.
    POST /subscription/v1/subscriptions/{{hcsSubscriptionId}}/licenses?action=add
    """
    client, _ = _get_client()

    data = {
        "productType": "HORIZON_CORE_UNIVERSAL_SUBSCRIPTION",
        "quantity": 2,
        "startDate": "2022-08-17T11:06:39.178Z",
        "endDate": "2030-10-17T11:06:39.178Z",
        "classification": "NAMED",
        "licenseType": "TRIAL",
        "billingType": "TRIAL",
        "status": "ACTIVE",
    }

    log.trivial(f"Adding license to subscription {hcs_subscription_id}...")
    response_data = client.post(
        f"/subscription/v1/subscriptions/{hcs_subscription_id}/licenses?action=add",
        json=data,
    )
    log.good(f"Successfully added subscription license: {response_data}")
    return response_data


def create_org_mapping(hcs_subscription_id: str):
    """
    Step 8.3 – Create subscription / org mapping.
    POST /subscription/v1/subscriptions/{{hcsSubscriptionId}}?action=createOrgMapping
    """
    client, current_profile = _get_client()
    org_id = os.getenv("ORG_ID", current_profile.csp.orgId)
    ws1_org_id = str(uuid.uuid4())

    data = {
        "orgId": org_id,
        "wsOneOrgId": ws1_org_id,
    }

    log.trivial(f"Creating org mapping for subscription {hcs_subscription_id}...")
    response_data = client.post(
        f"/subscription/v1/subscriptions/{hcs_subscription_id}?action=createOrgMapping",
        json=data,
    )
    log.good(f"Successfully created subscription org mapping: {response_data}")
    return response_data
