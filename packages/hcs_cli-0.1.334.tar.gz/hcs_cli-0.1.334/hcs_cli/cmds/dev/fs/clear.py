"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import os
import click

import hcs_cli.cmds.dev.util.log as log
from hcs_cli.cmds.dev.fs.helper.util import validate_fs_kubeconfig, validate_fs_profile
from hcs_cli.cmds.dev.fs.init import _resolve_bundled_file_path
from hcs_cli.support.exec_util import run_cli
from hcs_core.ctxp import profile


@click.command()
@click.option(
    "--only-default",
    is_flag=True,
    default=False,
    help="Delete only default deployments created by fs init. Otherwise, all pools, edges, providers will be deleted.",
)
def clear(only_default: bool, **kwargs):
    """Clear deployments on feature stack."""

    validate_fs_profile()
    validate_fs_kubeconfig()

    # Cleanup default zero deployments
    run_cli("hcs lcm template delete -y --force zero-floating-1")
    run_cli("hcs lcm template delete -y --force zero-dedicated-1")
    run_cli("hcs lcm template delete -y --force zero-multisession-1")

    if not only_default:
        _delete_all()

    os.environ["ORG_ID"] = profile.current().csp.orgId
    akka_plan_path = _resolve_bundled_file_path("provided_files/akka.plan.yml")
    azure_plan_path = _resolve_bundled_file_path("provided_files/azure.plan.yml")
    azsim_plan_path = _resolve_bundled_file_path("provided_files/azsim.plan.yml")
    run_cli("hcs plan destroy -f " + akka_plan_path, raise_on_error=False)
    run_cli("hcs plan destroy -f " + azure_plan_path, raise_on_error=False)
    run_cli("hcs plan destroy -f " + azsim_plan_path, raise_on_error=False)

    if not only_default:
        log.info("Second run for resiliency...")
        _delete_all()
    log.good("Done")


def _delete_all():
    # all lcm templates
    lcm_template_ids = run_cli("hcs lcm template list --ids", output_json=True, raise_on_error=False)
    for tid in lcm_template_ids:
        run_cli("hcs lcm template delete -y --force " + tid)
    # all pools
    pool_ids = run_cli("hcs pool list --ids", output_json=True, raise_on_error=False)
    for pid in pool_ids:
        run_cli("hcs pool delete -y --delete-templates " + pid, raise_on_error=False)
    # wait for template deletion, from admin perspective
    for tid in lcm_template_ids:
        run_cli("hcs template delete -y --force --wait 5m " + tid, raise_on_error=False)
    # all images
    image_ids = run_cli("hcs ims list --ids", output_json=True, raise_on_error=False)
    for iid in image_ids:
        run_cli("hcs ims delete " + iid)
    # all image gold patterns
    gold_pattern_ids = run_cli("hcs ims gold-pattern list --ids", output_json=True, raise_on_error=False)
    for gid in gold_pattern_ids:
        run_cli("hcs ims gold-pattern delete -y " + gid)
    # all edges
    edge_ids = run_cli("hcs edge list --ids", output_json=True, raise_on_error=False)
    for eid in edge_ids:
        run_cli("hcs edge delete -y --force --delete-all --field id,status " + eid, raise_on_error=False)
    # wait for edge deletion
    for eid in edge_ids:
        run_cli("hcs edge delete -y --force --delete-all -w 5m " + eid, raise_on_error=False)
    # all sites
    site_ids = run_cli("hcs site list --ids", output_json=True, raise_on_error=False)
    for sid in site_ids:
        run_cli("hcs site delete -y " + sid)
    # all providers
    provider_ids = run_cli("hcs provider list --ids", output_json=True)
    for pid in provider_ids:
        run_cli("hcs provider delete -y " + pid, raise_on_error=False)

    # all lcm internal providers
    lcm_provider_ids = run_cli("hcs lcm provider list --ids", output_json=True)
    for lpid in lcm_provider_ids:
        run_cli("hcs lcm provider delete " + lpid, raise_on_error=False)
