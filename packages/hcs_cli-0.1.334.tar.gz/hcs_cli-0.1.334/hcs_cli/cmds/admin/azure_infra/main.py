"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.admin import azure_infra


@click.command()
@cli.org_id
@cli.limit
@cli.sort
@click.option("--provider", "-p", type=str, required=True, help="Specify the provider instance id")
def get_compute_vm_skus(provider: str, **kwargs):
    """List compute VM SKUs"""
    return azure_infra.get_compute_vm_skus(provider, **kwargs)
