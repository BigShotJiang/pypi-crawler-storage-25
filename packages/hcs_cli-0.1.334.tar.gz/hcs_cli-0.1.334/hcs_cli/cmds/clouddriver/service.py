"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click

from hcs_cli.service import clouddriver as cd


@click.command()
@click.argument("name", type=str, required=True)
def action(name: str, **kwargs):
    """Get perform an action"""
    return cd.action(name, kwargs)


@click.command()
def health(**kwargs):
    """Get health"""
    return cd.health()
