"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click

from hcs_cli.service.clouddriver import provider as provider_service


@click.group(help="Task operations")
def task():
    pass


@task.command()
@click.option("--provider", "-p", type=str, required=True)
def list(provider: str, **kwargs):
    """List provider tasks"""
    return provider_service.tasks(provider)


@task.command()
@click.option("--provider", "-p", type=str, required=True)
@click.option("--task", "-t", type=str, required=True)
def get(provider: str, task: str, **kwargs):
    """Get a task"""
    return provider_service.get_task(provider, task)


@task.command()
@click.option("--provider", "-p", type=str, required=True)
@click.option("--task", "-t", type=str, required=True)
def delete(provider: str, task: str, **kwargs):
    """Delete a task"""
    return provider_service.delete_task(provider, task)
