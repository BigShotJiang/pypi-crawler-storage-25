"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import recent

from hcs_cli.service.clouddriver import provider as provider_service


@click.group()
def provider():
    """Provider operations"""
    pass


@provider.command()
@click.option("--force", "-f", is_flag=True, type=bool, required=True)
@click.argument("provider", type=str, required=False)
def delete(provider: str, force: bool, **kwargs):
    """Delete provider tasks"""
    provider = recent.require("provider", provider)
    return provider_service.delete(provider, force=force)


@provider.command()
@click.argument("provider", type=str, required=True)
def info(provider: str, **kwargs):
    """Get provider tasks information"""
    provider = recent.require("provider", provider)
    return provider_service.info(provider)
