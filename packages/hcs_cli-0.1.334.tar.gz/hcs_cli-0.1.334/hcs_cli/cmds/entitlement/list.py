"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import portal


@click.command()
@cli.limit
@cli.org_id
def list(org: str, **kwargs):
    """List entitlements"""
    org_id = cli.get_org_id(org)
    ret = portal.entitlement.list(org_id, **kwargs)
    recent.helper.default_list(ret, "entitlement")
    return ret
