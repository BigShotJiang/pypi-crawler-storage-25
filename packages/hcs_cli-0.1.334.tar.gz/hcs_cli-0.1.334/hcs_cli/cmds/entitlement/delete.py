"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import portal


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.confirm
def delete(id: str, org: str, confirm: bool):
    """Delete entitlement by ID"""
    org_id = cli.get_org_id(org)

    id = recent.require("entitlement", id)
    if not confirm:
        ret = portal.entitlement.get(id, org_id=org_id)
        if not ret:
            return ""
        click.confirm(f"Delete entitlement {id}?", abort=True)

    ret = portal.entitlement.delete(id, org_id)
    return ret
