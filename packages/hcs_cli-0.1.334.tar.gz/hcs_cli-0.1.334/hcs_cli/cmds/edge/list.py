"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import edge


@click.command()
@cli.org_id
@cli.search
@cli.formatter(columns={"providerLabel": "Label"})
def list(org: str, **kwargs):
    """List edges"""
    org_id = cli.get_org_id(org)
    ret = edge.list(org_id, **kwargs)

    recent.helper.default_list(ret, "edge")

    return ret
