"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import edge


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
def connection_string(id: str, org: str):
    """Get edge connection string"""
    org_id = cli.get_org_id(org)
    id = recent.require("edge", id)
    ret = edge.get_connection_string(id, org_id=org_id)
    if ret:
        return ret
    return "", 1
