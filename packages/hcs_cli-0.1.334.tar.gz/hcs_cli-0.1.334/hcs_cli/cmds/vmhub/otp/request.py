"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.vmhub import credentials


@click.command()
@cli.org_id
@click.option(
    "--region",
    type=str,
    default=None,
    required=False,
    help="Specify region name",
)
@click.argument("resource-name", type=str, required=True)
def request(org: str, region: str, resource_name: str):
    """Request an one-time password for a specific resource"""
    org_id = cli.get_org_id(org)
    credentials.use_region(region)
    return credentials.request(org_id, resource_name)
