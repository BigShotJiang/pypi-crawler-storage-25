"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click

from hcs_cli.service.vmhub import credentials as otp_service


@click.command()
@click.option(
    "--region",
    type=str,
    default=None,
    required=False,
    help="Specify region name",
)
def info(region: str):
    """Get information about the VMHub."""

    otp_service.use_region(region)
    return otp_service.info()
