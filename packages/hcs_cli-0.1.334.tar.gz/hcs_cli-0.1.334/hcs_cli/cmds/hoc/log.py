"""
Copyright © 2025 Omnissa, LLC.
"""

import json
import re
import sys
from datetime import timezone
from typing import Optional

import click
import yumako
from hcs_core.ctxp import util
from hcs_core.sglib import cli_options as cli

from hcs_cli.service import hoc
from hcs_cli.support import predefined_payload

_hdcs = ["US", "EU", "JP"]

_regions = [
    "eastus2",
    "westus2",
    "northcentralus",
    "northeurope",
    "germanywestcentral",
    "uksouth",
    "japaneast",
    "australiaeast",
    "centralindia",
]
_stacks = ["prod", "staging", "stress"]


@click.command()
@cli.org_id
@click.option(
    "--from",
    "from_param",
    type=str,
    required=False,
    default="-24h",
    help="Sepcify the from date. E.g. '-1d', or '-1h35m', or '-1w', or '2023-12-04T00:19:22.854Z'.",
)
@click.option(
    "--to",
    type=str,
    required=False,
    default="now",
    help="Sepcify the to date. E.g. 'now', or '-1d', or '-1h35m', or '-1w', or '2023-12-04T00:19:22.854Z'.",
)
@click.option("--hdc", required=False, type=click.Choice(_hdcs, case_sensitive=False), help="The HDC location")
@click.option("--region", required=False, type=click.Choice(_regions, case_sensitive=False), help="The region")
@click.option("--stack", required=False, type=click.Choice(_stacks, case_sensitive=False), help="The stack")
@click.option(
    "--service",
    required=False,
    help="Filter by kubernetes.pod_labels.app. If multiple apps, use comma to separate, e.g. --service inventory,lcm",
)
@click.option("--raw", is_flag=True, default=False, help="If raw, output the raw result.")
@click.argument("query", type=str, required=False)
def log(org: str, from_param: str, to: str, hdc: str, region: str, stack: str, service: str, raw: bool, query: str):
    """Search Kibana Log."""

    # org_id = cli.get_org_id(org)

    if not hdc:
        hdc = "US"
    else:
        hdc = hdc.upper()
    index_map = {
        "US": "prod110-hdc-westus2-cp102-*",
        # "US": "prod110-hdc-centralus-cp102-*",
        "EU": "hoc-logs-eu-prod-*",
        "JP": "hoc-logs-jp-prod-*",
        "AUS": "",
        "IND": "",
        "GER": "",
        "UK": "",
        "US_APM": "prod110-hdc-westus2-cp102-*",
        "EU_APM": "",
        "JP_APM": "",
    }
    es_logs_search_index = index_map[hdc]

    text = predefined_payload.load("hoc/logs.jsont")
    replacements = {
        "from": int(yumako.time.of(from_param, tz=timezone.utc).timestamp() * 1000),
        "to": int(yumako.time.of(to, tz=timezone.utc).timestamp() * 1000),
        "query": query or "",
        "es_logs_search_index": es_logs_search_index,
    }
    try:
        text = yumako.template.replace(
            text=text,
            mapping=replacements,
            raise_on_unresolved_vars=True,
            raise_on_unused_vars=True,
        )
    except ValueError as e:
        return util.error_details(e), 1

    parts = text.split("///", 2)
    try:
        first_line = json.loads(parts[0])
    except Exception as e:
        print(text, file=sys.stderr)
        print(e, file=sys.stderr)
        return
    try:
        second_line = json.loads(parts[1])
    except Exception as e:
        print(text, file=sys.stderr)
        print(e, file=sys.stderr)
        return

    _update_query(second_line, any_apps=service)

    payload_jsonp = json.dumps(first_line) + "\n" + json.dumps(second_line) + "\n"

    hdc_location_mapping = {
        # "US", "EU", "JP", "AUS", "IND", "GER", "UK", "US_APM", "EU_APM", "JP_APM"
        "US": "US_APM",
        "EU": "EU_APM",
        "JP": "JP_APM",
    }

    # print(payload_jsonp)
    result = hoc.es.raw_query(payload_jsonp, hdc_location=hdc_location_mapping[hdc])
    if raw:
        return result

    # format the result to pure message array
    ret = []
    for item in result:
        message = item["message"]
        parsed = _parse_message(message)
        ret.append(parsed)
    return ret


# Pattern 1: LCM / service-gateway style
# "...INFO  [163053][mplateMonitor-119158] c.v.h.servicegateway.lcm.utils.KopLog..."
_PATTERN_LCM = re.compile(
    r"(?P<timestamp>\S+)"
    r"\s+\[trace_id=(?P<trace_id>[^\]]*)\]"
    r"\s+\[transaction_id=(?P<transaction_id>[^\]]*)\]"
    r"\s+(?P<level>\S+)"
    r"\s+\[(?P<thread_id>[^\]]*)\]\[(?P<thread_name>[^\]]*)\]"
    r"\s+(?P<logger>\S+)"
    r"\s+-\s+"
    r"(?P<body>.*)",
)

# Pattern 2: clouddriver style (single thread bracket after level)
# "...INFO          [http-nio-8080-exec-6] c.v.horizon.sg.clouddriver..."
_PATTERN_CLOUDDRIVER = re.compile(
    r"(?P<timestamp>\S+)"
    r"\s+\[trace_id=(?P<trace_id>[^\]]*)\]"
    r"\s+\[transaction_id=(?P<transaction_id>[^\]]*)\]"
    r"\s+(?P<level>\S+)"
    r"\s+\[(?P<thread_name>[^\]]*)\]"
    r"\s+(?P<logger>\S+)"
    r"\s+-\s+"
    r"(?P<body>.*)",
)

# Pattern 3: task-service style (thread bracket before level)
# "...[transaction_id=...] [tsch:iss-32521] INFO  c.v.h.s.t.service.TaskService..."
_PATTERN_TASK = re.compile(
    r"(?P<timestamp>\S+)"
    r"\s+\[trace_id=(?P<trace_id>[^\]]*)\]"
    r"\s+\[transaction_id=(?P<transaction_id>[^\]]*)\]"
    r"\s+\[(?P<thread_name>[^\]]*)\]"
    r"\s+(?P<level>\S+)"
    r"\s+(?P<logger>\S+)"
    r"\s+-\s+"
    r"(?P<body>.*)",
)

# Pattern 4
# "2026-04-10 00:24:26,559 [http-nio-8080-exec-10] WARN  co.elastic.apm.agent.impl.transaction.TraceState - sample rate already set to 1.0, trying to set it to 1.0 through header will be ignored"
_PATTERN_ELASTIC = re.compile(
    r"(?P<timestamp>\S+\s\S+)" r"\s+\[(?P<thread_name>[^\]]*)\]" r"\s+(?P<level>\S+)" r"\s+(?P<logger>\S+)" r"\s+-\s+" r"(?P<body>.*)",
)

# Pattern 5: JSON structured log (apm-server style)
# "{\"log.level\":\"info\",\"@timestamp\":\"2026-04-10T00:24:26.596Z\",\"log.logger\":\"request\",...}"
_PATTERN_JSON_LOG = re.compile(r"\s*\{.*\"@timestamp\".*\}")

# Pattern 6: Envoy/Istio access log
# "[2026-04-10T00:24:25.684Z] \"POST /ad-twin/v1/... HTTP/1.1\" 200 ..."
_PATTERN_ENVOY = re.compile(
    r"\[(?P<timestamp>[^\]]+)\]"
    r"\s+\"(?P<method>\S+)\s+(?P<path>\S+)\s+(?P<protocol>[^\"]+)\""
    r"\s+(?P<status_code>\d+)"
    r"\s+(?P<body>.*)",
)

# Pattern 7 & 8: portal/pool style (empty transaction_id bracket)
# "2026-04-10T00:27:57.372Z [trace_id=...] [] [kafka-consumer-listener-...] INFO  c.v.h.p.handler..."
# "2026-04-10T00:27:57.376Z [trace_id=...] [] [http-nio-8080-exec-26] INFO  c.v.h.portal.service..."
_PATTERN_PORTAL = re.compile(
    r"(?P<timestamp>\S+)"
    r"\s+\[trace_id=(?P<trace_id>[^\]]*)\]"
    r"\s+\[(?P<transaction_id>[^\]]*)\]"
    r"\s+\[(?P<thread_name>[^\]]*)\]"
    r"\s+(?P<level>\S+)"
    r"\s+(?P<logger>\S+)"
    r"\s+-\s+"
    r"(?P<body>.*)",
)

# Pattern 9: Spring Boot style (--- separator)
# "2026-04-10 00:29:34.037  INFO 8 --- [istenerId-0-C-1] c.v.h.a.f.kafka.KafkaConsumerService     : Created ..."
_PATTERN_SPRING = re.compile(
    r"(?P<timestamp>\S+\s\S+)"
    r"\s+(?P<level>\S+)"
    r"\s+\S+"
    r"\s+---"
    r"\s+\[(?P<thread_name>[^\]]*)\]"
    r"\s+(?P<logger>\S+)"
    r"\s+:\s+"
    r"(?P<body>.*)",
)

_PATTERNS = [_PATTERN_LCM, _PATTERN_CLOUDDRIVER, _PATTERN_TASK, _PATTERN_ELASTIC, _PATTERN_ENVOY, _PATTERN_PORTAL, _PATTERN_SPRING]


def _parse_message(message: str) -> dict:
    if _PATTERN_JSON_LOG.match(message):
        try:
            obj = json.loads(message)
            return {
                "timestamp": obj.get("@timestamp", ""),
                "level": obj.get("log.level", ""),
                "logger": obj.get("log.logger", ""),
                "body": obj.get("message", ""),
            }
        except json.JSONDecodeError:
            pass
    for pattern in _PATTERNS:
        m = pattern.match(message)
        if m:
            return m.groupdict()
    return {"body": message}


def _update_query(query_object: dict, any_apps: Optional[str]) -> dict:
    # Example query object: query string "KOP" and "V1-CUSFP0101I", time range, and kubernetes.pod_labels.app=lcm
    # {
    # "query": {
    #     "bool": {
    #         "must": [],
    #         "filter": [
    #             {
    #                 "bool": {
    #                     "filter": [
    #                         {
    #                             "multi_match": {
    #                                 "type": "phrase",
    #                                 "query": "KOP",
    #                                 "lenient": true
    #                             }
    #                         },
    #                         {
    #                             "multi_match": {
    #                                 "type": "phrase",
    #                                 "query": "V1-CUSFP0101I",
    #                                 "lenient": true
    #                             }
    #                         }
    #                     ]
    #                 }
    #             },
    #             {
    #                 "range": {
    #                     "timestamp": {
    #                         "format": "strict_date_optional_time",
    #                         "gte": "2026-04-09T22:42:54.486Z",
    #                         "lte": "2026-04-09T22:47:54.486Z"
    #                     }
    #                 }
    #             },
    #             {
    #                 "match_phrase": {
    #                     "kubernetes.pod_labels.app": "lcm"
    #                 }
    #             }
    #         ],
    #         "should": [],
    #         "must_not": []
    #     }
    # }
    # }

    # example of the last match condition, if there are multiple app specified (is one of):
    # {
    #     "bool": {
    #         "minimum_should_match": 1,
    #         "should": [
    #             {
    #                 "match_phrase": {
    #                     "kubernetes.pod_labels.app": "clouddriver"
    #                 }
    #             },
    #             {
    #                 "match_phrase": {
    #                     "kubernetes.pod_labels.app": "lcm"
    #                 }
    #             }
    #         ]
    #     }
    # }

    filter_array = query_object["query"]["bool"]["filter"]

    if any_apps:
        apps = [a.strip() for a in any_apps.split(",") if a.strip()]
        if len(apps) == 1:
            filter_array.append({"match_phrase": {"kubernetes.pod_labels.app": apps[0]}})
        elif len(apps) > 1:
            filter_array.append(
                {"bool": {"minimum_should_match": 1, "should": [{"match_phrase": {"kubernetes.pod_labels.app": app}} for app in apps]}}
            )

    return query_object
