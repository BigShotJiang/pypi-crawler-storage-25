"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
import yumako
from hcs_core.ctxp import CtxpException, recent, util
from datetime import datetime

from hcs_cli.service import task


def _find_problematic_field(model_instance):
    """Debug function to find which field causes serialization to fail"""
    print("\n=== Debugging model serialization ===")
    print(f"Model type: {type(model_instance)}")

    # Try each field individually
    fields = model_instance.model_fields.keys()
    for field_name in fields:
        try:
            field_value = getattr(model_instance, field_name)
            # Try to serialize just this field
            if hasattr(field_value, "model_dump"):
                field_value.model_dump(exclude_none=True)
            print(f"✓ {field_name}: OK ({type(field_value).__name__})")
        except Exception as e:
            print(f"✗ {field_name}: FAILED - {e} ({type(field_value).__name__})")

    # Try full model_dump with each field excluded
    print("\nTrying model_dump with each field excluded:")
    for field_name in fields:
        try:
            model_instance.model_dump(exclude={field_name}, exclude_none=True)
            print(f"✓ Exclude {field_name}: OK")
        except Exception as e:
            print(f"✗ Exclude {field_name}: FAILED - {e}")
    print("=== End debug ===\n")


def _format_stale_past_as_negative(epoch_ms: int):
    the_time = yumako.time.of(epoch_ms / 1000)
    now = datetime.now()
    td = the_time - now
    return yumako.time.display(td)


def _format_delay(task_log: task.TaskLog, hdc: bool) -> str:
    if not task_log.timeStarted:
        return "NA"
    time_cost_seconds = (task_log.timeStarted - task_log.timeScheduled) / 1000
    ret = yumako.time.display(time_cost_seconds)

    if hdc:
        warn_threshold = 30
        error_threshold = 60
    else:
        warn_threshold = 90
        error_threshold = 180
    if time_cost_seconds > error_threshold:
        ret = click.style(ret, fg="bright_red")
    elif time_cost_seconds > warn_threshold:
        ret = click.style(ret, fg="bright_yellow")
    return ret


def _format_last_run_for_recurring(t: task.TaskModel) -> str:
    if not t._last_completed_log or not t._last_completed_log.timeStarted:
        return "NA"
    the_time = yumako.time.of(t._last_completed_log.timeStarted / 1000)
    now = datetime.now()
    diff_seconds = (now - the_time).total_seconds()
    ret = yumako.time.display(-diff_seconds)

    if t.schedule.intervalMs:
        if diff_seconds > 2 * t.schedule.intervalMs / 1000:
            ret = click.style(ret, fg="bright_red")
        elif diff_seconds > 1.5 * t.schedule.intervalMs / 1000:
            ret = click.style(ret, fg="bright_yellow")
    return ret


def _format_task_table(data: list[task.TaskModel]):
    data1 = []
    for d in data:
        try:
            # Extract input field separately (it causes schema serializer issues)
            input_field = d.input

            # Dump model without input field to avoid schema corruption
            d_dict = d.model_dump(exclude={"input"}, exclude_unset=True, exclude_none=True)

            # Add input back manually (it's a plain dict, no serialization needed)
            if input_field:
                d_dict["input"] = input_field

            d_dict["timeCreated"] = yumako.time.of(d.timeCreated / 1000).strftime("%Y-%m-%d %H:%M:%S")
            schedule = d.schedule
            if schedule:
                if schedule.intervalMs:
                    recurring = f"Every {yumako.time.display(schedule.intervalMs / 1000)}"
                elif schedule.cronExpression:
                    recurring = f"{schedule.cronExpression}"
                else:
                    recurring = None
            else:
                recurring = None

            d_dict["worker"] = _simplify_worker(d.worker)
            if recurring:
                d_dict["recurring"] = recurring
            else:
                d_dict["recurring"] = "<No>"

            if d.log:
                if recurring:
                    # recurring
                    if d.log.state == "Init":
                        d_dict["_next_run"] = _format_stale_past_as_negative(d.log.timeScheduled)
                    elif d.log.state == "Running":
                        d_dict["_next_run"] = "In progress"
                    elif d.log.state == "Canceled":
                        d_dict["_next_run"] = "<canceled>"
                    else:
                        d_dict["_next_run"] = "<unknown state>"

                    if d._last_completed_log:
                        d_dict["state"] = d._last_completed_log.state
                        d_dict["_last_run"] = _format_last_run_for_recurring(d)
                        d_dict["_delay"] = _format_delay(d._last_completed_log, hdc=d.location is None)
                        d_dict["_time_cost"] = yumako.time.display(
                            (d._last_completed_log.timeCompleted - d._last_completed_log.timeStarted) / 1000
                        )
                    else:
                        d_dict["state"] = d.log.state
                else:
                    # one-time
                    if d.log.state in ["Success", "Error", "Canceled"]:
                        d_dict["_next_run"] = "NA"
                        d_dict["_last_run"] = _format_stale_past_as_negative(d.log.timeStarted)
                        d_dict["_delay"] = _format_delay(d.log, hdc=d.location is None)
                        d_dict["_time_cost"] = yumako.time.display((d.log.timeCompleted - d.log.timeStarted) / 1000)
                    elif d.log.state == "Init":
                        d_dict["_next_run"] = _format_stale_past_as_negative(d.log.timeScheduled)
                    elif d.log.state == "Running":
                        d_dict["_next_run"] = "In progress"
                    else:
                        d_dict["_next_run"] = "<unknown state>"
                    d_dict["state"] = d.log.state

                util.colorize(
                    d_dict,
                    "state",
                    {
                        "Init": "bright_white",
                        "Success": "bright_green",
                        "Running": "bright_blue",
                        "Canceled": "bright_black",
                        "Error": "bright_red",
                    },
                )
            data1.append(d_dict)
        except Exception as e:
            print(f"Failed to format task: {e}")
            print(f"Original data: {d}")
            # Call debug function to identify problematic field
            _find_problematic_field(d)
            raise e

    fields_mapping = {
        "group": "Group",
        "key": "Task Key",
        "worker": "Worker",
        "timeCreated": "Created At",
        "recurring": "Recurring",
        "_next_run": "Next Run",
        "_last_run": "Last Run",
        "_delay": "Delay",
        "_time_cost": "Cost Time",
        "state": "State",
    }
    return util.format_table(data1, fields_mapping)


def _simplify_worker(worker: str):
    # worker is java class. For any package parts, keep only the first letter. E.g. com.example.MyWorker -> c.e.MyWorker
    parts = worker.split(".")
    simplified_parts = []
    for i, part in enumerate(parts):
        if i < len(parts) - 1:
            simplified_parts.append(part[0])
        else:
            simplified_parts.append(part)
    return ".".join(simplified_parts)


def _format_tasklog_table(data):
    # {
    # "logId": "0a1bdw2vq6g9w9s151hm8dp4",
    # "group": "scmDaemon",
    # "taskKey": "OperatorNoSpare",
    # "executionId": "4d397e6468f379f0f3a989c51ba09d7a",
    # "timeStarted": 1758366000097,
    # "timeUpdated": null,
    # "timeCompleted": 1758366116684,
    # "timeCreated": 1757761314727,
    # "timeScheduled": 1758366000000,
    # "state": "Success",
    # "error": null,
    # "ttlMs": 604800000,
    # "nodeId": null,
    # "orgId": null,
    # "version": 0,
    # "output": null,
    # "properties": null,
    # "logs": []
    # },
    for d in data:
        # updatedAt = d["updatedAt"]
        # v = duration.stale(updatedAt)
        # if duration.from_now(updatedAt).days >= 1:
        #     v = click.style(v, fg="bright_black")
        # d["stale"] = v

        if d["timeCompleted"] and d["timeStarted"]:
            timecost = d["timeCompleted"] - d["timeStarted"]
            timecost = yumako.time.display(timecost / 1000)
            d["_timecost"] = timecost
        else:
            d["_timecost"] = "..."

        if d["timeStarted"]:
            _delay = d["timeStarted"] - d["timeScheduled"]
            if _delay > 10 * 1000:
                _delay = click.style(_delay, fg="bright_yellow")
            elif _delay > 60 * 1000:
                _delay = click.style(_delay, fg="bright_red")
            _delay = yumako.time.display(_delay / 1000)
            d["_delay"] = _delay
        else:
            d["_delay"] = "..."

        d["timeCreated"] = yumako.time.of(d.timeCreated / 1000).strftime("%Y-%m-%d %H:%M:%S")
        d["timeScheduled"] = _format_stale_past_as_negative(d["timeScheduled"])
        d["_timecost"] = timecost

        util.colorize(
            d,
            "state",
            {
                "Init": "bright_white",
                "Running": "bright_blue",
                "Canceled": "bright_black",
                "Success": "bright_green",
                "Error": "bright_red",
            },
        )

    fields_mapping = {
        "group": "Group",
        "taskKey": "Task ID",
        "logId": "Log ID",
        "state": "State",
        "timeCreated": "Created At",
        "timeScheduled": "Scheduled At",
        "_delay": "Delay",
        "_timecost": "Cost Time",
    }
    return util.format_table(data, fields_mapping)


def _parse_state_values(state: str):
    state_list = set()
    if not state:
        return state_list
    valid_states = ["Init", "Running", "Canceled", "Error", "Success"]
    for s in state.split(","):
        s = s.strip().lower().capitalize()
        if s not in valid_states:
            raise CtxpException(f"Invalid state value: {s}. Valid values are: {', '.join(valid_states)}")
        if s in state_list:
            raise CtxpException(f"Duplicate state value: {s}.")
        state_list.add(s)
    return state_list


@click.group(name="task")
def task_cmd_group():
    """Task management commands."""
    pass


@task_cmd_group.command("namespaces")
def list_namespaces(**kwargs):
    """List namespaces"""
    return task.namespaces()


@task_cmd_group.command()
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.argument("smart_path", type=str, required=False)
@click.option("--reset", "-r", is_flag=True, default=False, help="If specified, reset the recent task.")
def use(namespace: str, group: str, smart_path: str, reset: bool, **kwargs):
    """Use a specific namespace, group, and/or task."""
    if reset:
        if namespace or group or smart_path:
            return "--reset can not be used with other parameteres.", 1
        recent.unset("task.namespace")
        recent.unset("task.group")
        recent.unset("task.key")
        return

    if namespace:
        recent.set("task.namespace", namespace)
        recent.unset("task.group")
        recent.unset("task.key")
    if group:
        recent.set("task.group", group)
        recent.unset("task.key")
    if smart_path:
        namespace, group, key = _parse_task_param(namespace, group, smart_path)

    namespace = recent.get("task.namespace")
    group = recent.get("task.group")
    key = recent.get("task.key")
    return f"{namespace}/{group}/{key}"


@task_cmd_group.command(name="list")
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False, help="Filter tasks by namespace.")
@click.option("--group", "-g", type=str, required=False, help="Filter tasks by group.")
@click.option("--worker", "-w", type=str, required=False, help="Filter tasks by worker.")
@click.option("--type", "-t", type=str, required=False, help="Filter tasks by type.")
@click.option("--resource", "-r", type=str, required=False, help="Filter tasks by resource ID.")
@click.option("--queue", "-q", type=str, required=False, help="Filter tasks by queue ID.")
@click.option("--parent", "-p", type=str, required=False, help="Filter tasks by parent task ID.")
@click.option(
    "--meta",
    "-m",
    type=str,
    required=False,
    multiple=True,
    help="key-value pair to filter tasks by metadata. E.g. --meta k1=v1 --meta k2.nk3=v2",
)
@click.option(
    "--input",
    "-i",
    type=str,
    required=False,
    multiple=True,
    help="key-value pair to filter tasks by input. E.g. --input k1=v1 --input k2.nk3=v2",
)
@click.option("--recurring", type=bool, is_flag=True, help="Filter only recurring tasks.")
@click.option("--one-time", type=bool, is_flag=True, help="Filter only one-time tasks.")
@click.option(
    "--state",
    type=str,
    required=False,
    help="Filter tasks by state, for one-time tasks only. Comma separated values. E.g. Init,Running,Canceled,Error,Success",
)
@click.option(
    "--scheduler", type=click.Choice(["Any", "Global", "HDC"], case_sensitive=False), default="Any", help="Query task by scheduler type."
)
@click.option("--v1log", is_flag=True, default=False, required=False, help="Fetch last log for v1 tasks.")
@click.option("--location", type=str, required=False, help="Filter tasks by location, global scheduler only. E.g. US, JP, IN, AU, DE, IE")
@click.option(
    "--time-created",
    type=str,
    required=False,
    help="Comma separated time range, optionally one side only. Examples: '2026-01-01,', '2026-01-01,2026-01-02', ',2026-01-02', support ISO time or timestamp '2026-01-01T00:00:00Z,1706659199000'",
)
@click.option(
    "--time-scheduled",
    type=str,
    required=False,
    help="Comma separated time range, optionally one side only. Examples: '2026-01-01,', '2026-01-01,2026-01-02', ',2026-01-02', support ISO time or timestamp '2026-01-01T00:00:00Z,1706659199000'",
)
@click.option(
    "--time-started",
    type=str,
    required=False,
    help="Comma separated time range, optionally one side only. Examples: '2026-01-01,', '2026-01-01,2026-01-02', ',2026-01-02', support ISO time or timestamp '2026-01-01T00:00:00Z,1706659199000'",
)
@click.option(
    "--time-completed",
    type=str,
    required=False,
    help="Comma separated time range, optionally one side only. Examples: '2026-01-01,', '2026-01-01,2026-01-02', ',2026-01-02', support ISO time or timestamp '2026-01-01T00:00:00Z,1706659199000'",
)
@cli.limit(default=10)
@cli.search
@cli.formatter(_format_task_table)
def list_tasks(
    org: str,
    namespace: str,
    group: str,
    worker: str,
    type: str,
    resource: str,
    queue: str,
    parent: str,
    meta: list[str],
    input: list[str],
    recurring: bool,
    one_time: bool,
    state: str,
    scheduler: str,
    v1log: bool,
    location: str,
    time_created: str,
    time_scheduled: str,
    time_started: str,
    time_completed: str,
    limit: int,
    search: str,
    **kwargs,
):
    """List tasks."""
    if namespace:
        recent.set("task.namespace", namespace)
    else:
        namespace = recent.get("task.namespace")
        if not namespace:
            return "Missing recent namespace. Specify '--namespace'.", 1

    scheduler = scheduler.lower()
    if scheduler == "global" and v1log:
        return "--v1log can not be used with --scheduler global.", 2

    if recurring and one_time:
        return "--recurring and --one-time cannot be specified together.", 3

    if scheduler == "hdc":
        if state and not one_time:
            return "For HDC scheduler, to query with --state, specify --one-time as well", 4
        if location:
            return "--location can not be used with --scheduler hdc.", 5

    schedule_type = "recurring" if recurring else "one-time" if one_time else None

    states = _parse_state_values(state)
    if org == "all":
        org_id = None
    else:
        org_id = cli.get_org_id(org)

    if group:
        recent.set("task.group", group)

    ret = task.query(
        namespace,
        scheduler=scheduler,
        schedule_type=schedule_type,
        org_id=org_id,
        group=group,
        worker=worker,
        type=type,
        resource=resource,
        queue=queue,
        parent=parent,
        meta=meta,
        input=input,
        states=states,
        search=search,
        location=location,
        time_created=time_created,
        time_scheduled=time_scheduled,
        time_started=time_started,
        time_completed=time_completed,
        _v1log=v1log,
        limit=limit,
    )

    if ret and len(ret) == 1:
        first = ret[0]
        recent.set("task.key", first.key)
        recent.set("task.group", first.group)

    # for recurring tasks, fetch last completed log and attach to the task,
    # so that we can show the last completion status and time in the list view.
    # This is an expensive operation, so only do it when the flag is specified.
    for t in ret:
        if not t.schedule:
            continue
        if not t.schedule.intervalMs and not t.schedule.cronExpression:
            continue
        t._last_completed_log = task._fetch_last_completed_log_for_recurring_tasks(namespace, t)
    return ret


@task_cmd_group.command()
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.option(
    "--location", hidden=True, type=str, required=False, help="Task location, only for global scheduler. E.g. US, JP, IN, AU, DE, IE."
)  # to be removed later
@click.argument("smart_path", type=str, required=False)
def get(org: str, namespace: str, group: str, location: str, smart_path: str, **kwargs):
    """Get a task. E.g. 'task get [[<namespace>/]<group>/]<key>'."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)
    org_id = cli.get_org_id(org)
    return task.get(org_id, namespace, group, key, location=location, **kwargs)


@task_cmd_group.command()
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.argument("smart_path", type=str, required=False)
@click.option("--execution-id", "-e", type=str, required=False)
@click.option("--exclusive-id", "-x", type=str, required=False)
@cli.confirm
def delete(org: str, namespace: str, group: str, smart_path: str, execution_id: str, exclusive_id: str, confirm: bool, **kwargs):
    """Delete a task."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)
    org_id = cli.get_org_id(org)
    ret = task.get(org_id, namespace, group, key, **kwargs)

    if not confirm:
        if not ret:
            click.confirm(f"Delete task {namespace}/{group}/{key}?", abort=True)
        else:
            click.confirm(f"Delete task {namespace}/{group}/{key}? (type={ret.type}, worker={ret.worker})", abort=True)
    try:
        task.cancel(org_id, namespace, group, key)
    except Exception:
        pass  # ignore cancel error, just want to make sure the task is not running before deletion
    return task.delete(org_id, namespace, group, key, execution_id, exclusive_id)


@task_cmd_group.command(name="log")
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.argument("smart_path", type=str, required=False)
@click.option("--last", is_flag=True, default=False, help="If specified, return only the last log instead of all logs.")
@click.option(
    "--state",
    type=str,
    required=False,
    help="Filter tasks by state, for one-time tasks only. Comma separated values. E.g. Init,Running,Canceled,Error,Success",
)
@cli.search
@cli.limit(default=10)
@cli.formatter(_format_tasklog_table)
def get_logs(org: str, namespace: str, group: str, smart_path: str, last: bool, state: str, search: str, **kwargs):
    """List task logs."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)

    if state and last:
        return "--state cannot be used with --last.", 1

    if last and org is None:
        org_id = cli.get_org_id(org)
    elif org == "all" or org is None:
        org_id = None
    else:
        org_id = cli.get_org_id(org)

    state_list = _parse_state_values(state)
    if state_list:
        if search:
            if search.find("state $") >= 0:
                return "--state cannot be used with state criteria in --search together.", 1
        state_search = "state $in " + ",".join(state_list)
        if search:
            search = f"({search}) AND ({state_search})"
        else:
            search = state_search

    if last:
        t = task.last(org_id, namespace, group, key)
        if t:
            return t.log
        else:
            return
    else:
        return task.logs(org_id, namespace, group, key, search, **kwargs)


@task_cmd_group.command()
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.argument("smart_path", type=str, required=False)
@click.option(
    "--state",
    "-s",
    type=str,
    required=False,
    default="Success",
    help="Comma separated states to wait for. Valid values: Success, Error, Canceled, Running, Init.",
)
@cli.wait
def wait(org: str, namespace: str, group: str, smart_path: str, wait: str, states: str, **kwargs):
    """Wait for a task."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)
    org_id = cli.get_org_id(org)
    return task.wait(org_id=org_id, namespace=namespace, group=group, key=key, wait=wait, states=states, **kwargs)


@task_cmd_group.command()
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.argument("smart_path", type=str, required=False)
@cli.confirm
def cancel(org: str, namespace: str, group: str, smart_path: str, confirm: bool, **kwargs):
    """Cancel a task."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)
    org_id = cli.get_org_id(org)
    ret = task.get(org_id, namespace, group, key, **kwargs)

    if not confirm:
        if not ret:
            click.confirm(f"Cancel task {namespace}/{group}/{key}?", abort=True)
        else:
            click.confirm(f"Cancel task {namespace}/{group}/{key}? (type={ret.type}, worker={ret.worker})", abort=True)
    return task.cancel(org_id, namespace, group, key)


@task_cmd_group.command()
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.argument("smart_path", type=str, required=False)
@click.option("--execution-id", "-e", type=str, required=False)
@cli.confirm
def retrigger(org: str, namespace: str, group: str, smart_path: str, execution_id: str, confirm: bool, **kwargs):
    """Retrigger a task."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)
    org_id = cli.get_org_id(org)
    ret = task.get(org_id, namespace, group, key, **kwargs)

    # retrigger should also give it a try even if the task is not found.
    if ret:
        if execution_id:
            pass
        else:
            # find the last execution id, from the last log
            t = task.last(org_id, namespace, group, key, **kwargs)
            if t and t.log and t.log.executionId:
                execution_id = t.log.executionId
    else:
        # task not found. give it a blind try.
        pass

    if not execution_id:
        return "Task is not found and execution-id is required to do a blind-shot retrigger.", 1

    if not confirm:
        if ret:
            click.confirm(f"Retrigger task {namespace}/{group}/{key}/{execution_id} (type={ret.type}, worker={ret.worker})?", abort=True)
        else:
            click.confirm(f"Retrigger task {namespace}/{group}/{key}/{execution_id} (task not found, give it a blind shot)?", abort=True)

    # print("dry-run retrigger:", namespace, group, key, execution_id)
    return task.retrigger(org_id, namespace, group, key, execution_id)


@task_cmd_group.command(hidden=True)
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.argument("smart_path", type=str, required=False)
@click.option("--execution-id", "-e", type=str, required=False)
@cli.confirm
def resubmit(org: str, namespace: str, group: str, smart_path: str, execution_id: str, confirm: bool, **kwargs):
    """Duplicate the task configuration and submit a new one."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)
    org_id = cli.get_org_id(org)
    ret = task.get(org_id, namespace, group, key, **kwargs)

    if not confirm:
        if not ret:
            click.confirm(f"Resubmit task {namespace}/{group}/{key}", abort=True)
        else:
            click.confirm(f"Resubmit task {namespace}/{group}/{key}? (type={ret.type}, worker={ret.worker})", abort=True)
    return task.resubmit(org_id, namespace, group, key, execution_id)


@task_cmd_group.command()
@cli.org_id
@click.option("--namespace", "-n", type=str, required=False)
@click.option("--group", "-g", type=str, required=False)
@click.option(
    "--reference", "-r", type=str, required=True, help="Reference task to copy parameters from, format: [[<namespace>/]<group>/]<key>."
)
@click.option(
    "--at", type=str, required=False, help="Schedule time, exact time 'YYYY-MM-DD HH:MM:SS', or delta time '1h30m', default is now."
)
@click.argument("smart_path", type=str, required=False)
def duplicate(org: str, namespace: str, group: str, smart_path: str, at: str, **kwargs):
    """Duplicate an existing task to run once, immediately or at a specific time."""
    namespace, group, key = _parse_task_param(namespace, group, smart_path)
    org_id = cli.get_org_id(org)
    ret = task.get(org_id, namespace, group, key, **kwargs)
    if not ret:
        return f"Task {namespace}/{group}/{key} not found.", 1

    # Clone the task
    new_task = ret.model_copy()
    new_task.key = None  # Clear the key to let the system generate a new one
    new_task.log = None  # Clear the log for the new task
    new_task.meta["_duplicatedFrom"] = key  # Track the source task

    # Handle schedule based on 'at' parameter
    if at and at.lower() != "now":
        now_ms = int(datetime.now().timestamp() * 1000)
        try:
            # Try to parse as exact time (YYYY-MM-DD HH:MM:SS)
            scheduled_dt = datetime.strptime(at, "%Y-%m-%d %H:%M:%S")
            scheduled_ms = int(scheduled_dt.timestamp() * 1000)
        except ValueError:
            # Parse as delta time (e.g., 1h30m)
            delta_seconds = yumako.time.duration(at)
            scheduled_ms = now_ms + int(delta_seconds * 1000)

        if scheduled_ms > now_ms:
            new_task.schedule = task.Schedule(initialDelayMs=scheduled_ms)
        else:
            new_task.schedule = None  # run immediately

    return task.create(org_id, namespace, new_task)


def _parse_task_param(namespace: str, group: str, smart_path: str):
    if smart_path:
        parts = smart_path.split("/")
        if len(parts) == 3:
            if namespace:
                raise CtxpException("Invalid path: Namespace already specified. Avoid using --namespace and namespace in path together.")
            if group:
                raise CtxpException("Invalid path: Group already specified. Avoid using --group and group in path together.")

            namespace, group, key = parts
            if not namespace:
                raise CtxpException("Invalid path: Missing namespace. Valid example: <namespace>/<group>/<key>.")
            if not group:
                raise CtxpException("Invalid path: Missing group. Valid example: <namespace>/<group>/<key>.")
            if not key:
                raise CtxpException("Invalid path: Missing key. Valid example: <namespace>/<group>/<key>.")

            recent.set("task.namespace", namespace)
            recent.set("task.group", group)
            recent.set("task.key", key)
        elif len(parts) == 2:
            namespace = recent.require("task.namespace", namespace)
            group = recent.require("task.group", parts[0])
            key = recent.require("task.key", parts[1])
        elif len(parts) == 1:
            namespace = recent.require("task.namespace", namespace)
            group = recent.require("task.group", group)
            key = recent.require("task.key", parts[0])
    else:
        namespace = recent.require("task.namespace", namespace)
        group = recent.get("task.group")
        if not group:
            group = "default"
        key = recent.require("task.key", None)

    return namespace, group, key
