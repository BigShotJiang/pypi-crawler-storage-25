"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Extended tools for Horizon Operation Center."
extension = "hcs-ext-hoc"
