"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Extended tools for hst."
extension = "hcs-ext-hst"
hidden = True
