"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import json

import click
from hcs_core.ctxp import recent

from hcs_cli.support.debug_util import kubectl_patch


@click.command()
@click.argument("service", type=str, required=False)
@click.option("--image", "-i", type=str, required=False, help="Specify the image to use. Optional.")
def reset(service: str, **kwargs):
    """Reset service k8s container"""

    service = recent.require("hcs_debug_k8s_service", service)

    # Define the patch operations
    patch_ops = [
        {
            "op": "add",
            "path": "/spec/template/spec/containers/0/livenessProbe",
            "value": {
                "failureThreshold": 3,
                "httpGet": {"path": "/actuator/health", "port": 8080, "scheme": "HTTP"},
                "initialDelaySeconds": 20,
                "periodSeconds": 60,
                "successThreshold": 1,
                "timeoutSeconds": 20,
            },
        },
        {
            "op": "add",
            "path": "/spec/template/spec/containers/0/readinessProbe",
            "value": {
                "failureThreshold": 3,
                "httpGet": {"path": "/actuator/health", "port": 8080, "scheme": "HTTP"},
                "initialDelaySeconds": 20,
                "periodSeconds": 10,
                "successThreshold": 1,
                "timeoutSeconds": 20,
            },
        },
        {"op": "replace", "path": "/spec/template/spec/containers/0/command", "value": None},
    ]

    image = kwargs.get("image")
    if image:
        patch_ops.append(
            {
                "op": "replace",
                "path": "/spec/template/spec/containers/0/image",
                "value": f"hcsdevframework.azurecr.io/devframe-prod/horizonv2-sg/{service}:{image}",
            }
        )

    # Formulate the Kubernetes patch command
    patch_params = [
        "--type=json",
        "--patch",
        json.dumps(patch_ops),  # Convert patch_ops to JSON string
    ]

    kubectl_patch(service, patch_params)
