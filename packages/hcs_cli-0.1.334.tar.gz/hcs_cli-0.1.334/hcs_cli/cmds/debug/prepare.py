"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import json

import click
from hcs_core.ctxp import recent

from hcs_cli.support.debug_util import kubectl_patch


@click.command()
@click.argument("service", type=str, required=False)
def prepare(service: str, **kwargs):
    """Prepare service k8s pod for debugging"""

    service = recent.require("hcs_debug_k8s_service", service)

    # Define the patch operations
    patch_ops = [
        {"op": "replace", "path": "/spec/template/spec/containers/0/livenessProbe", "value": None},
        {"op": "replace", "path": "/spec/template/spec/containers/0/readinessProbe", "value": None},
        {"op": "add", "path": "/spec/template/spec/containers/0/command", "value": ["sleep", "8640000"]},
    ]

    # Formulate the Kubernetes patch command
    patch_params = [
        "--type=json",
        "--patch",
        json.dumps(patch_ops),  # Convert patch_ops to JSON string
    ]

    new_pod_id = kubectl_patch(service, patch_params)

    return new_pod_id
