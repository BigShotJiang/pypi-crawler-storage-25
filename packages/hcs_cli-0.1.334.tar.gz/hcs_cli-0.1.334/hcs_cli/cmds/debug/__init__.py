"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Debug commands on k8s."
hidden = True
