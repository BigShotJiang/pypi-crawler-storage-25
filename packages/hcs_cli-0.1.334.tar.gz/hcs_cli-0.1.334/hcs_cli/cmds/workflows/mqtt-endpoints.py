"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import time

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import admin, iss
from hcs_cli.service.org_service import details


@click.command(name="get-latest-mqtt-endpoints-allorgs")
@cli.limit
@cli.search
def get(**kwargs):
    allOrgs = details.list(org_id=None, **kwargs)
    # recent.helper.default_list(allOrgs, "org-details")
    print(f"There are {len(allOrgs)} orgs")
    failed = False
    for org in allOrgs:
        print(f"-- Processing org - id: {org.orgId}, name: {org.orgName}, cName: {org.customerName}, cType: {org.customerType}")
        try:
            templates = admin.template.list(org_id=org.orgId, **kwargs)
            print(f" {org.orgId} has {len(templates)} templates")
            for t in templates:
                print(f" Get mqtt endpoints for template name: {t.name}")
                try:
                    iss.mqtt.get(org.orgId, t.id, None)
                except Exception as err:
                    print(f"Unexpected {err=}, {type(err)=}")
                    failed = True
                print("\n")
                sleepSec = t.reportedStatus.provisionedVMs / 100
                print(f"There are {t.reportedStatus.provisionedVMs} provisioned VMs, so sleep {sleepSec}s before next template")
                time.sleep(sleepSec)
        except Exception as err:
            print(f"Unexpected {err=}, {type(err)=}, move on to next org. Hit CTRL+C or CMD+C to break")
            failed = True
            continue
        print("\n")

    return 1 if failed else 0
