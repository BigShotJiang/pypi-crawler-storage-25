"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import recent

from hcs_cli.service.lcm import provider


@click.command()
@click.argument("id", type=str, required=False)
def get(id: str):
    """Get provider by ID"""
    id = recent.require("provider", id)
    ret = provider.get(id)
    if not ret:
        return "", 1
    return ret
