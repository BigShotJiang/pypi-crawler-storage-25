"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.lcm import provider


@click.command()
@cli.org_id
@click.option("--type", "-t", type=str, required=False, help="Optionally, specify cloud provider type.")
@cli.limit
def list(org: str, **kwargs):
    """List providers"""
    org_id = cli.get_org_id(org)
    ret = provider.list(org_id=org_id, **kwargs)
    recent.helper.default_list(ret, "provider")
    return ret
