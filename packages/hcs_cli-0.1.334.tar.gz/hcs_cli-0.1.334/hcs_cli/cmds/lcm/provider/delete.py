"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import recent

from hcs_cli.service.lcm import provider


@click.command()
@click.argument("id", type=str, required=False)
def delete(id: str):
    """Delete provider by ID"""
    id = recent.require("provider", id)
    ret = provider.delete(id)

    # trick
    if ret is True:  # found
        return
    if ret is None:  # not found
        return

    return ret, 1
