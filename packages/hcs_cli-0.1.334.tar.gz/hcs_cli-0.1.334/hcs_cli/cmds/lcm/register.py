"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import inventory, lcm
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@cli.org_id
@click.option("--cloud-id", type=str, required=True)
@click.argument("vm_path", type=str, required=False)
def register(org: str, vm_path: str, cloud_id: str):
    """Register an existing VM."""
    org_id = cli.get_org_id(org)
    template_id, vm_id = parse_vm_path(vm_path)

    template = lcm.template.get(template_id, org_id)
    if not template:
        return "Template not found.", 1

    vms = [{"id": vm_id, "cloudId": cloud_id}]
    ret = inventory.vm.begin_adding_vms(template_id=template_id, org_id=org_id, vms=vms)
    print(ret)
    template_type = template["templateType"]
    num_sessions = template["agentCustomization"]["sessionsPerVm"]
    vms = [{"id": vm_id, "powerState": "poweredOn"}]
    ret = inventory.vm.finish_adding_vms(
        template_id=template_id, org_id=org_id, num_sessions=num_sessions, template_type=template_type, vms=vms
    )
    return ret
