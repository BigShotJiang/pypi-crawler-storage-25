"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click

import hcs_cli.service.lcm as lcm


@click.command()
def health():
    """Get service health info"""
    return lcm.health.get()
