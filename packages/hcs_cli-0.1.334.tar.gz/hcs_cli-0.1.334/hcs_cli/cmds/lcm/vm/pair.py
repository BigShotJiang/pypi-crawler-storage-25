"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.lcm import vm
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@click.argument("vm_path", type=str, required=False)
@cli.org_id
def pair(vm_path: str, org: str, **kwargs):
    """Pair a VM with the control plane."""
    template_id, vm_id = parse_vm_path(vm_path)
    org_id = cli.get_org_id(org)
    return vm.pair(template_id, vm_id, org_id=org_id, **kwargs)
