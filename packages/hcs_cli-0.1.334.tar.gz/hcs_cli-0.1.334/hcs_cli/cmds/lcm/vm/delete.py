"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.lcm import vm
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@click.argument("vm_path", type=str, required=False)
@cli.org_id
@cli.confirm
@cli.force
@cli.wait
def delete(vm_path: str, org: str, confirm: bool, force: bool, wait: str, **kwargs):
    """Delete VM"""
    template_id, vm_id = parse_vm_path(vm_path)
    org_id = cli.get_org_id(org)
    item = vm.get(template_id, vm_id, org_id)

    if not item:
        return

    if not confirm:
        click.confirm(f"Delete VM {template_id}/{vm_id}?", abort=True)

    vm.delete(template_id, vm_id, org_id, force=force, **kwargs)

    if wait == "0":
        return

    return vm.wait_for_deleted(template_id, vm_id, org_id, wait)
