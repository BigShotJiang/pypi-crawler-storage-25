"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.lcm import vm
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@click.argument("vm_path", type=str, required=False)
@click.option("--join-domain/--skip-domain-join", type=bool, default=True)
@cli.org_id
def pairing_info(vm_path: str, join_domain: bool, org: str, **kwargs):
    """Get VM pairing info."""
    template_id, vm_id = parse_vm_path(vm_path)
    org_id = cli.get_org_id(org)
    ret = vm.get_pairing_info(template_id, vm_id, org_id=org_id, join_domain=join_domain, **kwargs)
    return ret
