"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.lcm import template


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.force
@cli.confirm
@cli.wait
def delete(id: str, org: str, force: bool, confirm: bool, wait: str):
    """Delete template by ID"""
    org_id = cli.get_org_id(org)
    id = recent.require("template", id)
    t = template.get(id, org_id)
    if not t:
        return

    if not confirm:
        click.confirm(f"Delete template {t['name']} ({id}/{t['templateType']})?", abort=True)

    ret = template.delete(id, org_id, force)

    if wait == "0":
        return ret

    return template.wait_for_deleted(id, org_id, wait)
