"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.lcm import template


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
def get(id: str, org: str, **kwargs):
    """Get template by ID"""

    org_id = cli.get_org_id(org)
    id = recent.require("template", id)

    ret = template.get(id, org_id, **kwargs)
    if not ret:
        return "", 1

    return ret
