"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service.lcm import template


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
def retry(id: str, org: str):
    """Retry necessary operations on a template by ID"""
    org_id = cli.get_org_id(org)
    id = recent.require("template", id)
    t = template.get(id, org_id)
    if not t:
        return

    return template.retry(id, org_id)
