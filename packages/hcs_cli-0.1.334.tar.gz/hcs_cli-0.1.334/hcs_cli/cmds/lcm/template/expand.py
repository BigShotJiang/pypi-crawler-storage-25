"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

import hcs_cli.service.lcm as lcm
from hcs_cli.cmds.template.expand import expand_impl


@click.command(hidden=True)
@click.option(
    "--number",
    "-n",
    type=int,
    required=False,
    default=0,
    help="Number of VMs to expand. Use negative number to shrink.",
)
@click.option(
    "--to",
    "-t",
    type=int,
    required=False,
    default=0,
    help="Expected size of template.",
)
@click.argument("template_id", type=str, required=False)
@cli.org_id
@cli.wait
def expand(number: int, to: int, template_id: str, org: str, wait: str):
    """Update an existing template"""

    return expand_impl(number, to, template_id, org, wait, lcm)
