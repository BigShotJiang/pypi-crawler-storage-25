"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import auth


@click.command()
@cli.org_id
def get_org_idp_map(org: str):
    """Get org-idp-map by ID"""
    org_id = cli.get_org_id(org)
    ret = auth.admin.get_org_idp_map(org_id=org_id)
    if ret:
        return ret
    return ret, 1
