"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import auth


@click.command()
@cli.org_id
@click.option("--cidr", type=str, help="E.g. 0.0.0.0/0")
def add(org: str, cidr):
    """Add internal network"""
    # https://cloud-sg.horizon.omnissa.com/auth/v1/admin/internal-networks
    # {"orgId":"f8d70804-1ce7-49a1-a754-8cae2e79ae10","internalNetworks":["0.0.0.0/0"]}
    org_id = cli.get_org_id(org)
    payload = {"orgId": org_id, "internalNetworks": [cidr]}
    return auth.admin.internal_networks.add(payload)
