"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import ims


@click.command()
@click.option("--limit", "-l", type=int, default=20)
@click.option("--include-catalog-details/--no-catalog-details", type=bool, default=True)
@cli.org_id
def list_copies(org: str, **kwargs):
    """List image copies"""
    org_id = cli.get_org_id(org)
    return ims.image_copies.list(org_id, **kwargs)
