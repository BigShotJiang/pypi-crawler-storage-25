"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import ims


@click.command()
@click.option("--limit", "-l", type=int, required=False, default=20)
@cli.org_id
@cli.search
def list(org: str, **kwargs):
    """List images"""
    org_id = cli.get_org_id(org)
    ret = ims.images.list(org_id, **kwargs)
    recent.helper.default_list(ret, "image")
    return ret
