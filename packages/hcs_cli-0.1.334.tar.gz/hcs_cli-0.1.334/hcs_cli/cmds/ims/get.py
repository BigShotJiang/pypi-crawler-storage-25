"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import ims


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.search
def get(id: str, org: str, **kwargs):
    """Get image by ID."""
    org_id = cli.get_org_id(org)
    id = recent.require("image", id)
    return ims.images.get(id, org_id, **kwargs)
