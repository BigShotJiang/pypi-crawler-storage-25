"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import ims


@click.command()
@click.argument("image_ids", type=str, required=False, nargs=-1)
@cli.org_id
@cli.wait
def delete(image_ids: list[str], org: str, wait: str, **kwargs):
    """Delete an image by ID"""

    org_id = cli.get_org_id(org)

    if not image_ids:
        image_ids = [recent.require("image", None)]

    ims.helper.delete_images(image_ids, org_id, wait)
