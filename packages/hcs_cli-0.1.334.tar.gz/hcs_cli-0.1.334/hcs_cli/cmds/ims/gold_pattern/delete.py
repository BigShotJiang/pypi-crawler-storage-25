"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import ims


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.confirm
def delete(id: str, org: str, confirm: bool, **kwargs):
    """Delete gold pattern by ID"""

    org_id = cli.get_org_id(org)
    id = recent.require("gold-pattern", id)

    if not confirm:
        ret = ims.gold_pattern.get(id, org_id, **kwargs)
        if not ret:
            return
        name = ret["goldPatternDetails"]["data"]["imageName"]
        click.confirm(f"Delete gold pattern {name} ({id})?", abort=True)

    return ims.gold_pattern.delete(id=id, org_id=org_id, **kwargs)
