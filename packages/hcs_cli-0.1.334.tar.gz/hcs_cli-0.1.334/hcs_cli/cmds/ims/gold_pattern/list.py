"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import ims


@click.command()
@cli.org_id
@cli.search
@cli.limit
def list(org: str, **kwargs):
    """List gold patterns"""

    org_id = cli.get_org_id(org)
    ret = ims.gold_pattern.list(org_id, **kwargs)
    # recent.helper.default_list(ret, "gold-pattern")
    return ret
