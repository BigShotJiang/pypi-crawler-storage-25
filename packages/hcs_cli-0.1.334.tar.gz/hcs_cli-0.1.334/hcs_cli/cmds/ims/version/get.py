"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import ims


@click.command()
@click.option("--image", "-i", type=str, required=False, help="Image ID")
@click.argument("id", type=str, required=True)
@cli.org_id
def get(image: str, id: str, org: str, **kwargs):
    """Get image version by ID"""
    org_id = cli.get_org_id(org)
    if image:
        ret = ims.version(image, org_id).get(id)
        if ret:
            return ret
    else:
        images = ims.images.list(org_id)
        for i in images:
            image_id = i["id"]
            ret = ims.version(image_id, org_id).get(id)
            if ret:
                return ret
    return "", 1
