"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import ims


@click.command()
@click.option("--image", "-i", type=str, required=False, help="Image ID")
@cli.org_id
def list(image: str, org: str, **kwargs):
    """List image versions"""

    org_id = cli.get_org_id(org)
    if image:
        return ims.version(image, org_id).list(**kwargs)

    images = ims.images.list(org_id)
    ret = []
    for i in images:
        image_id = i["id"]
        ret.extend(ims.version(image_id, org_id).list())
    return ret
