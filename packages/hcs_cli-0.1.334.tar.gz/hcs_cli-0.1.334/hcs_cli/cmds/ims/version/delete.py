"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
import httpx

from hcs_cli.service import ims


@click.command()
@click.option("--image", "-i", type=str, required=False, help="Image ID")
@click.argument("id", type=str, required=True)
@cli.org_id
@cli.wait
def delete(image: str, id: str, org: str, wait: str, **kwargs):
    """Delete image version by ID"""

    org_id = cli.get_org_id(org)
    if image:
        _delete_impl(image, id, org_id, wait)
    else:
        images = ims.images.list(org_id=org_id)
        for i in images:
            image_id = i["id"]
            v = ims.version(image_id, org_id)
            if v.get(id):
                return _delete_impl(image_id, id, org_id, wait)


def _delete_impl(image_id: str, version_id: str, org_id: str, wait: str):
    v = ims.version(image_id, org_id)
    ret = None
    try:
        ret = v.delete(version_id)
        if not ret:
            return
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 422:
            pass
        else:
            raise
    if wait == "0":
        return ret
    v.wait_for_deleted(version_id)
