"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
from hcs_core.ctxp import recent
from hcs_core.sglib import cli_options as cli

from hcs_cli.service.portal import pool
from hcs_cli.support import use_util


@click.command()
@click.argument("smart_search", type=str, required=False)
def use(smart_search: str):
    """Set or show the default pool to work with."""

    if not smart_search:
        return recent.get("pool")

    org_id = cli.get_org_id()

    items = pool.list(org_id, limit=1000)
    items = use_util.smart_search(items, smart_search)
    return use_util.require_single(items=items, resource_type="pool")
