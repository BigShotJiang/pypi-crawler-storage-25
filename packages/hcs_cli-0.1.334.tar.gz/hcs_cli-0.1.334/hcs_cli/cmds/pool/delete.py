"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import portal


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.confirm
@click.option(
    "--delete-templates/--keep-templates",
    type=bool,
    default=False,
    help="Specify whether to delete the associated templates.",
)
def delete(id: str, org: str, confirm: bool, delete_templates: bool):
    """Delete pool by ID"""
    org_id = cli.get_org_id(org)

    id = recent.require("pool", id)
    if not confirm:
        ret = portal.pool.get(id, org_id=org_id)
        if not ret:
            return ""
        click.confirm(f"Delete pool {ret['name']} ({id})?", abort=True)

    ret = portal.pool.delete(id, org_id, disassociateAction="FORCEFUL", delete=delete_templates)
    return ret
