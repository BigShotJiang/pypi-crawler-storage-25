"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import portal


@click.command()
@click.argument("template_id", type=str, required=False)
@click.option(
    "--update",
    "-u",
    type=str,
    multiple=True,
    required=True,
    help="Specify field and value pair to update. E.g. '-u sparePolicy.max=3'.",
)
@cli.org_id
@cli.wait
def update(template_id: str, update, org: str, wait: str, **kwargs):
    """Update an existing pool"""

    org_id = cli.get_org_id(org)

    pool_id = recent.require("pool", template_id)
    pool = portal.pool.get(pool_id, org_id)

    if not pool:
        return "Pool not found: " + pool_id

    patch = {}
    for pair in update:
        k, v = pair.split("=")
        patch[k] = v

    ret = portal.pool.update(pool_id, org_id, patch)
    return ret
