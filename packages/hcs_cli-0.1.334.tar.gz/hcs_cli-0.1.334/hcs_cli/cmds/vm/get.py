"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.admin import VM
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@click.argument("vm_path", type=str, required=False)
@cli.org_id
def get(vm_path: str, org: str, **kwargs):
    """Get a specific VM"""
    org_id = cli.get_org_id(org)
    template_id, vm_id = parse_vm_path(vm_path)
    return VM(org_id, template_id, vm_id).get(**kwargs)
