"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service import admin
from hcs_cli.service.admin import VM
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@click.argument("vm_path", type=str, required=False)
@cli.force
@cli.org_id
@cli.confirm
@cli.wait
def delete(vm_path: str, org: str, confirm: bool, force: bool, wait: str, **kwargs):
    """Delete a VM by ID"""
    org_id = cli.get_org_id(org)
    template_id, vm_id = parse_vm_path(vm_path)

    vm = VM(org_id, template_id, vm_id)
    existing = vm.get()
    if not existing:
        return "", 1

    template = admin.template.get(template_id, org_id)

    if not confirm:
        click.confirm(f"Delete vm {existing['id']} from template {template['name']} ({template['id']})?", abort=True)

    vm.delete(force=force)

    if wait == "0":
        return

    vm.wait_for_deleted(wait)
