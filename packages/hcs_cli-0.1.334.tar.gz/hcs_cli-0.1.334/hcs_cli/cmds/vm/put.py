"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.admin import VM
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@click.argument("vm_path", type=str, required=True)
@click.option("--cloud-id", type=str, required=False)
@cli.org_id
def put(vm_path: str, org: str, cloud_id: str, **kwargs):
    """Register an unmanaged VM.
    Example: hcs vm put desktop-010
    """
    org_id = cli.get_org_id(org)
    template_id, vm_id = parse_vm_path(vm_path)
    payload = {"cloudId": cloud_id}
    return VM(org_id, template_id, vm_id).put(payload, **kwargs)
