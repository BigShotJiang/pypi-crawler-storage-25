"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import ipaddress

import click
from hcs_core.ctxp import recent
from hcs_core.sglib import cli_options as cli

from hcs_cli.service import admin
from hcs_cli.support import use_util


def _is_ipv4(text: str):
    try:
        ipaddress.IPv4Network(text)
        return True
    except ValueError:
        return False


@click.command()
@cli.org_id
@click.argument("smart_search", type=str, required=False)
@click.option("--interactive/--fail-on-multi-match", type=bool, required=False, default=True)
def use(org: str, smart_search: str, interactive: bool):
    "Helper command to work with a specific vm, by smart search."

    if not smart_search:
        return recent.get("vm")

    org_id = cli.get_org_id(org)
    template_id = recent.require("template", None)
    if _is_ipv4(smart_search):
        ret = admin.VM.list(org_id=org_id, template_id=template_id, search=f"privateIp $eq '{smart_search}")
    else:
        ret = admin.VM.list(org_id=org_id, template_id=template_id, search=f"id $like '{smart_search}'")

    return use_util.require_single(
        items=ret,
        resource_type="vm",
        name_field="id",
        interactive=interactive,
        include_id=False,
        search_text=smart_search,
    )
