"""
Copyright © 2025 Omnissa, LLC.
"""

import json
import os

import click
import httpx
import time
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.admin import VM
from hcs_core.sglib.auth import has_any_permission
from hcs_cli.support.param_util import parse_vm_path
from hcs_cli.service.vmm import dct as dct_service

# DCT log statusAbbr values (see API)
_DCT_PENDING = frozenset({"ACCEPTED", "IN_PROGRESS"})
_DCT_FAILED = frozenset({"ERROR", "EXPIRED"})


@click.command()
@click.option(
    "--recreate",
    is_flag=True,
    default=False,
    help="Whether to recreate the log if it already exists. By default, it will not recreate the log and just return the existing log.",
)
@click.option(
    "--verbose", is_flag=True, default=False, help="Whether to print progress messages. By default, it will print progress messages."
)
@click.option(
    "--save-as",
    "save_path",
    type=click.Path(),
    default=None,
    help="Path to save the DCT log archive. Defaults to <org_id>_<template_id>_<vm_id>.zip in the current directory.",
)
@click.argument("vm_path", type=str, required=False)
@cli.org_id
def log(recreate: bool, verbose: bool, save_path, vm_path: str, org: str, **kwargs):
    """Download VM DCT log"""
    org_id = cli.get_org_id(org)
    template_id, vm_id = parse_vm_path(vm_path)

    is_ops = has_any_permission(["sgadm:supportw", "sgadm:supportlog", "sgadm:service", "sgadm:support"])

    dct_info = dct_service.latest(org_id, template_id, vm_id, is_ops)

    if not dct_info:
        if verbose:
            click.echo("No DCT log found for VM.")
        need_recreate = True
    elif recreate:
        need_recreate = True
    else:
        statusAbbr = dct_info.get("statusAbbr")
        if statusAbbr in _DCT_PENDING:
            need_recreate = False
            dct_info, error = _wait_for_dct_log(dct_service, org_id, template_id, vm_id, is_ops, verbose)
            if error:
                return error, 1
        elif statusAbbr in _DCT_FAILED:
            need_recreate = True
        elif statusAbbr == "SUCCESS":
            need_recreate = False
        else:
            return "Unknown DCT log status: " + statusAbbr, 1

    if need_recreate:
        dct_info, error = _request_dct_log(dct_service, org_id, template_id, vm_id, is_ops, verbose)
        if error:
            return error, 1
        dct_info, error = _wait_for_dct_log(dct_service, org_id, template_id, vm_id, is_ops, verbose)
        if error:
            return error, 1

    # download the log
    uri = dct_info.get("dctLog", {}).get("readAccessUri")
    if not uri:
        return "No DCT log URI found in the log entry.", 1

    # Compose local file path
    if save_path:
        file_path = os.path.abspath(os.path.expanduser(save_path))
    else:
        filename = f"{org_id}_{template_id}_{vm_id}.zip"
        file_path = os.path.abspath(filename)

    # Download the file
    if verbose:
        click.secho(f"Downloading DCT log from {uri} to {file_path}", fg="bright_black")
    try:
        with httpx.stream("GET", uri, timeout=60) as r:
            r.raise_for_status()
            with open(file_path, "wb") as f:
                for chunk in r.iter_bytes(chunk_size=8192):
                    f.write(chunk)
    except Exception as e:
        return f"Failed to download archive: {e}", 1

    dct_info["file_path"] = file_path

    if verbose:
        click.secho("----- DCT log downloaded -----", fg="bright_black")
    return dct_info


def _request_dct_log(dct_service, org_id: str, template_id: str, vm_id: str, is_ops: bool, verbose: bool):
    # try locating the VM first
    vm = VM(org_id, template_id, vm_id)
    vm_info = vm.get()
    if not vm_info:
        return None, "VM not found"

    # check VM powered on
    power_state = vm_info.get("powerState")
    if power_state != "PoweredOn":
        click.secho(f"Power state: {power_state}. Powering on VM...", fg="bright_black")
        vm.power_on()

        if verbose:
            click.secho("Waiting for VM to be powered on...", fg="bright_black")
        vm.wait_for_power_state("PoweredOn", timeout=180)

        # Graceful period
        time.sleep(10)

    info = dct_service.request(org_id, template_id, vm_id, is_ops)
    if not info.get("success"):
        reason = info.get("reason") or "Unknown error"
        return None, f"DCT log request failed: {reason}"
    if verbose:
        click.secho(f"DCT log requested: {json.dumps(info)}", fg="bright_black")
    return info, None


def _wait_for_dct_log(dct_service, org_id: str, template_id: str, vm_id: str, is_ops: bool, verbose: bool, timeout: int = 600):
    deadline = time.time() + timeout
    while time.time() < deadline:
        info = dct_service.latest(org_id, template_id, vm_id, is_ops)
        if not info:
            return None, "No DCT log entry found"
        status = info.get("statusAbbr")
        if status == "SUCCESS":
            return info, None
        if status in _DCT_FAILED:
            msg = info.get("status") or info.get("errorMessage") or "Unknown error"
            return info, f"DCT log collection failed: {msg}"
        if verbose:
            click.secho(f"DCT log status: {status}, waiting...", fg="bright_black")
        time.sleep(20)
    return None, "Timed out waiting for DCT log to be ready."
