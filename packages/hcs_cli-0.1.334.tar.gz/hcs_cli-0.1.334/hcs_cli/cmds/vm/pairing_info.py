"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.admin import VM
from hcs_cli.support.param_util import parse_vm_path


@click.command()
@click.argument("vm_path", type=str, required=False)
@click.option("--join-domain/--skip-domain-join", type=bool, default=True)
@cli.org_id
def pairing_info(vm_path: str, join_domain: bool, org: str, **kwargs):
    """Get VM pairing info."""
    template_id, vm_id = parse_vm_path(vm_path)
    org_id = cli.get_org_id(org)
    return VM(org_id, template_id, vm_id).pairing_info(join_domain=join_domain, **kwargs)
