"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin


@click.command()
@cli.org_id
@cli.search
@cli.sort
@cli.limit
def list(org: str, **kwargs):
    """List Active Directory records"""
    ret = admin.ad.list(org_id=cli.get_org_id(org), **kwargs)
    recent.helper.default_list(ret, "ad")
    return ret
