"""
Copyright © 2025 Omnissa, LLC.
"""

import json
import sys

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin


@click.command()
@click.option(
    "--file",
    "-f",
    type=click.File("rt"),
    default=sys.stdin,
    help="Specify the payload file name. If not specified, STDIN will be used.",
)
@cli.org_id
def create(file: str, org: str, **kwargs):
    """Create Active Directory record"""

    org_id = cli.get_org_id(org)

    with file:
        payload = file.read()

    try:
        template = json.loads(payload)
    except Exception as e:
        msg = "Invalid template: " + str(e)
        return msg, 1

    template["orgId"] = org_id

    ret = admin.ad.create(template, **kwargs)
    if ret:
        recent.set("ad", ret["id"])
    return ret
