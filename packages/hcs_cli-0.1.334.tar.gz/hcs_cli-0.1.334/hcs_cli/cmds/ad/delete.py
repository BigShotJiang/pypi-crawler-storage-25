"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli
from hcs_core.ctxp import recent

from hcs_cli.service import admin


@click.command()
@click.argument("id", type=str, required=False)
@cli.org_id
@cli.confirm
def delete(id: str, org: str, confirm: bool, **kwargs):
    """Delete Active Directory record by ID"""

    org_id = cli.get_org_id(org)
    id = recent.require("ad", id)

    if not confirm:
        ret = admin.ad.get(id, org_id=org_id)
        if not ret:
            return ""
        click.confirm(f"Delete AD record {ret['name']} ({id})?", abort=True)

    ret = admin.ad.delete(id, org_id)
    if not ret:
        return ""
    return ret
