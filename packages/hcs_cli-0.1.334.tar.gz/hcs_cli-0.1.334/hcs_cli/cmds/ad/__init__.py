"""
Copyright © 2025-2026 Omnissa, LLC.
"""

help = "Active Directory commands."
