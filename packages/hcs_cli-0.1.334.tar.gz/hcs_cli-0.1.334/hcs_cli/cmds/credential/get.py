"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import click
import hcs_core.sglib.cli_options as cli

from hcs_cli.service.credential import credential


@click.command()
@click.argument("id")
@click.option("--sensitive", "-s", is_flag=True, default=False, help="Include sensitive data in the output.")
@cli.org_id
def get(id: str, org: str, sensitive: bool, **kwargs):
    """Get a specific credential by ID."""
    org_id = cli.get_org_id(org)
    return credential.get(id, org_id, includeSensitiveData=sensitive, **kwargs)
