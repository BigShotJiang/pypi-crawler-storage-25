"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import subprocess
import sys

import click


@click.group(invoke_without_command=True)
def upgrade():
    """Upgrade hcs-cli."""
    cmd = "pip install -U hcs-cli --upgrade-strategy eager --no-cache-dir"
    p = subprocess.run(cmd, stdout=sys.stdout, stderr=sys.stderr, text=False, shell=True, check=False)
    return p.returncode
