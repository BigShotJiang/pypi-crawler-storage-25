"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.plan import actions

from hcs_cli.service.app_management import manual_app


def deploy(data: dict, state: dict) -> dict:
    return manual_app.create(data)


def refresh(data: dict, state: dict) -> dict:
    id = None
    org_id = data["orgId"]
    if state:
        id = state["id"]

        # workaround https://jira-euc.eng.omnissa.com/jira/browse/HV2-109561
        try:
            p = manual_app.get(id, org_id)
        except Exception:
            return
        if p:
            return p

    # Fall back with smart find by name
    # TODO


def decide(data: dict, state: dict):
    return actions.skip


def destroy(data: dict, state: dict, force: bool) -> dict:
    org_id = data["orgId"]
    id = state["id"]
    return manual_app.delete(id, org_id)


def eta(action: str, data: dict, state: dict):
    if action == actions.create:
        return "1m"
    if action == actions.delete:
        return "1m"
