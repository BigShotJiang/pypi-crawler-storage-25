"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.plan import actions

from hcs_cli.service import portal


def deploy(data: dict, state: dict) -> dict:
    return portal.entitlement.create(data)


def refresh(data: dict, state: dict) -> dict:
    if state:
        id = state.get("id")
        if id:
            return portal.entitlement.get(id, data["orgId"])

    # Fall back with smart find by users
    # TODO


def decide(data: dict, state: dict):
    return actions.skip


def destroy(data: dict, state: dict, force: bool) -> dict:
    return portal.entitlement.delete(state["id"], data["orgId"])


def eta(action: str, data: dict, state: dict):
    if action == actions.create:
        return "1m"
    if action == actions.delete:
        return "1m"
