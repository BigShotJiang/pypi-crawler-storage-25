"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from hcs_core.plan import actions

from hcs_cli.service import av


def deploy(data: dict, state: dict, save_state) -> dict:
    if data["data"]["apps"]:
        av.entitlements.create(data)
        return av.entitlements.get_by_app_id(data)
    else:
        return state


def refresh(data: dict, state: dict) -> dict:
    return av.entitlements.get_by_app_id(data)


def decide(data: dict, state: dict):
    return actions.create


def destroy(data: dict, state: dict, force: bool) -> dict:
    if state:
        av.entitlements.delete(state)
    return state


def eta(action: str, data: dict, state: dict):
    if action == actions.create:
        return "1m"
    if action == actions.delete:
        return "1m"
