"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import re

from hcs_core.plan import PluginException, actions

from hcs_cli.service import av


def deploy(data: dict, state: dict) -> dict:
    providerInstanceId = data["providerInstanceId"]
    result = dict()
    try:
        deployment = av.fileshare.wait_for(providerInstanceId, timeout="30m")
        if deployment and deployment.content[0]:
            _storage_acc_name = deployment.content[0].path.split(".")
            _acc_name = re.sub("[^A-Za-z0-9]", "", _storage_acc_name[0])
            result = {"storageAccountName": _acc_name}
    except Exception as e:
        raise PluginException("Exception while checking for AV fileshare provision.") from e
    return result


def refresh(data: dict, state: dict) -> dict:
    return state


def decide(data: dict, state: dict):
    return actions.skip


def destroy(data: dict, state: dict, force: bool) -> dict:
    return state


def eta(action: str, data: dict, state: dict):
    if action == actions.create:
        return "10m"
    if action == actions.delete:
        return "1m"
