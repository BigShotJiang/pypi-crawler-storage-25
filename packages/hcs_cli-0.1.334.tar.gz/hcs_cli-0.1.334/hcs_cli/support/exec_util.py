import json
import os
import shlex
import subprocess
import threading
from typing import Any, List, Optional, Tuple, Union

import click


def _split_command(cmd: Union[str, List[str]]) -> Tuple[List[str], str]:
    if isinstance(cmd, str):
        return shlex.split(cmd), cmd

    if isinstance(cmd, list):
        return cmd, shlex.join(cmd)

    raise TypeError("cmd must be a string or a list of strings")


# ANSI bright black / grey (same family as click.style(..., fg="bright_black"))
_STREAM_GREY = b"\x1b[90m"
# Yellow (same family as click.style(..., fg="yellow"))
_STREAM_YELLOW = b"\x1b[33m"
_STREAM_RESET = b"\x1b[0m"


def exec(
    cmd,
    log_error=True,
    raise_on_error=True,
    inherit_output=False,
    cwd=None,
    input: Union[str, dict[Any, Any], list[Any]] = None,
    show_command: bool = True,
    env: dict = None,
):
    commands, cmd_text = _split_command(cmd)
    text = f"RUNNING: {cmd_text}"
    if input:
        text += " <input-redacted>"
        if isinstance(input, dict) or isinstance(input, list):
            input = json.dumps(input)

    if show_command:
        click.echo(click.style(text, fg="bright_black"))

    if inherit_output:
        result = subprocess.run(commands, env=env, cwd=cwd, input=input, text=True, capture_output=False)
    else:
        result = subprocess.run(commands, env=env, cwd=cwd, input=input, text=True, capture_output=True)

    if result.returncode != 0:
        if log_error:
            click.echo(f"  RETURN: {result.returncode}")
            if not inherit_output:
                stdout = result.stdout.strip()
                stderr = result.stderr.strip()
                if stdout:
                    click.echo(f"  STDOUT:      {stdout}")
                if stderr:
                    click.echo(f"  STDERR:      {stderr}")
        if raise_on_error:
            raise click.ClickException(f"Command '{cmd_text}' failed with return code {result.returncode}.")
    return result


def run_cli(
    cmd: str,
    output_json=False,
    raise_on_error=True,
    inherit_output: Union[bool, None] = None,
    input: Union[str, dict[Any, Any], list[Any]] = None,
    show_command: bool = True,
    log_error: bool = True,
    env: dict = None,
):
    eventual_env = os.environ.copy()
    eventual_env["HCS_CLI_CHECK_UPGRADE"] = "false"
    if env:
        eventual_env.update(env)
    if output_json:
        if inherit_output is None:
            inherit_output = False
        output = exec(
            cmd,
            log_error=log_error,
            raise_on_error=raise_on_error,
            inherit_output=inherit_output,
            env=eventual_env,
            input=input,
            show_command=show_command,
        ).stdout
        if not output:
            return None
        try:
            return json.loads(output)
        except json.JSONDecodeError as e:
            msg = f"Failed to parse JSON output from command '{cmd}': {e}\nOutput: {output}"
            raise click.ClickException(msg)
    else:
        if inherit_output is None:
            inherit_output = True
        return exec(
            cmd,
            log_error=log_error,
            raise_on_error=raise_on_error,
            inherit_output=inherit_output,
            env=eventual_env,
            input=input,
            show_command=show_command,
        )


def stream_cli(
    cmd: str,
    raise_on_error=True,
    input: Union[str, dict[Any, Any], list[Any]] = None,
    show_command: bool = True,
    env: dict = None,
    color: Optional[bool] = None,
) -> str:
    """Run ``hcs ...``, stream stdout and stderr as they arrive, return full stdout text.

    Uses unbuffered binary reads from the pipes so data is forwarded as the OS delivers it
    (``text=True`` would wrap pipes in a buffered ``TextIOWrapper`` and can delay reads).

    The child ``hcs`` process is Python: ``PYTHONUNBUFFERED=1`` is set so its stdout is not
    block-buffered when piped. If ``input`` is omitted, stdin is ``DEVNULL`` so the subprocess
    does not inherit the parent's stdin and block waiting for input; otherwise stdin is a pipe
    and the given payload is written (dict/list are JSON-encoded, same as :func:`exec`).

    Output is written with :func:`click.get_binary_stream` so it matches what :func:`click.echo`
    uses (not always identical to :data:`sys.stdout`).

    ANSI wrapping (grey on stdout, yellow on stderr): if ``color`` is ``True`` or ``False``,
    that choice always wins. If ``color`` is omitted (``None``), wrapping is applied per stream
    only when that stream is a TTY (same as :meth:`~io.IOBase.isatty` on the binary stream).
    """
    child_env = os.environ.copy()
    child_env["HCS_CLI_CHECK_UPGRADE"] = "false"
    child_env["PYTHONUNBUFFERED"] = "1"
    if env:
        child_env.update(env)

    commands, cmd_text = _split_command(cmd)
    if show_command:
        text = f"RUNNING: {cmd_text}"
        if input:
            text += " <input-redacted>"
        click.echo(click.style(text, fg="bright_black"))

    stdin_bytes: Union[bytes, None] = None
    if input is not None:
        if isinstance(input, dict) or isinstance(input, list):
            stdin_bytes = json.dumps(input).encode("utf-8")
        else:
            stdin_bytes = str(input).encode("utf-8")

    parts: list[bytes] = []
    proc = subprocess.Popen(
        commands,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.PIPE if stdin_bytes is not None else subprocess.DEVNULL,
        env=child_env,
        bufsize=0,
    )
    assert proc.stdout is not None
    assert proc.stderr is not None

    out_bin = click.get_binary_stream("stdout")
    err_bin = click.get_binary_stream("stderr")

    try:
        stdout_is_tty = out_bin.isatty()
    except OSError:
        stdout_is_tty = False
    try:
        stderr_is_tty = err_bin.isatty()
    except OSError:
        stderr_is_tty = False

    if color is None:
        wrap_stdout = stdout_is_tty
        wrap_stderr = stderr_is_tty
    else:
        wrap_stdout = color
        wrap_stderr = color

    def pump_stdin() -> None:
        assert proc.stdin is not None
        try:
            if stdin_bytes is not None:
                proc.stdin.write(stdin_bytes)
                proc.stdin.flush()
        finally:
            proc.stdin.close()

    def pump_stdout() -> None:
        try:
            while True:
                chunk = proc.stdout.read(4096)
                if not chunk:
                    break
                out = (_STREAM_GREY + chunk + _STREAM_RESET) if wrap_stdout else chunk
                out_bin.write(out)
                out_bin.flush()
                parts.append(out)
        finally:
            proc.stdout.close()

    def pump_stderr() -> None:
        try:
            while True:
                chunk = proc.stderr.read(4096)
                if not chunk:
                    break
                out = (_STREAM_YELLOW + chunk + _STREAM_RESET) if wrap_stderr else chunk
                err_bin.write(out)
                err_bin.flush()
        finally:
            proc.stderr.close()

    threads: list[threading.Thread] = []
    if stdin_bytes is not None:
        threads.append(threading.Thread(target=pump_stdin))
    threads.extend(
        [
            threading.Thread(target=pump_stdout),
            threading.Thread(target=pump_stderr),
        ]
    )
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    rc = proc.wait()
    if rc != 0 and raise_on_error:
        raise click.ClickException(f"Command '{cmd_text}' failed with return code {rc}.")
    return b"".join(parts).decode("utf-8", errors="replace")
