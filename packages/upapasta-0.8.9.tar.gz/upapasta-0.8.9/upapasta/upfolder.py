#!/usr/bin/env python3
"""
upfolder.py

Upload de arquivo .rar e arquivos de paridade (.par2) para Usenet usando nyuu.

Lê credenciais do arquivo .env global (~/.config/upapasta/.env) ou via variáveis de ambiente.

Uso:
  python3 upfolder.py /caminho/para/arquivo.rar

Opções:
  --dry-run              Mostra comando nyuu sem executar
  --nyuu-path PATH       Caminho para executável nyuu (padrão: detecta em PATH)
  --subject SUBJECT      Subject da postagem (padrão: nome do arquivo .rar)
  --group GROUP          Newsgroup para upload (pode sobrescrever .env)

Retornos:
  0: sucesso
  1: arquivo .rar não encontrado
  2: credenciais faltando/inválidas
  3: arquivo .par2 não encontrado
  4: nyuu não encontrado
  5: erro ao executar nyuu
"""

import argparse
import glob
import os
import shutil
import subprocess
import sys
import random
import string
import re
import xml.etree.ElementTree as ET

from .nzb import resolve_nzb_out, handle_nzb_conflict, fix_nzb_subjects, inject_nzb_password


def _verify_nzb(nzb_path: str) -> bool:
    """Verifica que o NZB existe, não está vazio e contém ao menos um elemento <file>."""
    if not os.path.exists(nzb_path):
        return False
    if os.path.getsize(nzb_path) == 0:
        return False
    try:
        tree = ET.parse(nzb_path)
        root = tree.getroot()
        # Suporta NZB com ou sem namespace
        files = root.findall('.//{http://www.newzbin.com/DTD/2003/nzb}file') or root.findall('.//file')
        return len(files) > 0
    except ET.ParseError:
        return False


def find_nyuu() -> str | None:
    """Procura executável 'nyuu' no PATH."""
    for cmd in ("nyuu", "nyuu.exe"):
        path = shutil.which(cmd)
        if path:
            return path
    return None


def parse_args():
    p = argparse.ArgumentParser(
        description="Upload de .rar + .par2 para Usenet com nyuu"
    )
    p.add_argument("rarfile", help="Caminho para o arquivo .rar a fazer upload")
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Mostra comando nyuu sem executar",
    )
    p.add_argument(
        "--nyuu-path",
        default=None,
        help="Caminho para executável nyuu (padrão: detecta em PATH)",
    )
    p.add_argument(
        "--subject",
        default=None,
        help="Subject da postagem (padrão: nome do arquivo .rar)",
    )
    p.add_argument(
        "--group",
        default=None,
        help="Newsgroup (pode sobrescrever variável USENET_GROUP do .env)",
    )
    p.add_argument(
        "--env-file",
        default=os.path.expanduser("~/.config/upapasta/.env"),
        help="Caminho para arquivo .env (padrão: ~/.config/upapasta/.env)",
    )
    return p.parse_args()


def generate_anonymous_uploader() -> str:
    """Gera um nome de uploader aleatório e anônimo para proteger privacidade."""
    # Lista de nomes comuns para anonimato
    first_names = [
        "Anonymous", "User", "Poster", "Uploader", "Contributor", "Member",
        "Guest", "Visitor", "Participant", "Sender", "Provider", "Supplier"
    ]
    
    # Adiciona um sufixo aleatório de 4 dígitos
    suffix = ''.join(random.choices(string.digits, k=4))
    
    # Escolhe um nome aleatório
    name = random.choice(first_names)
    
    # Gera um domínio aleatório
    domains = ["anonymous.net", "upload.net", "poster.com", "user.org", "generic.mail"]
    domain = random.choice(domains)
    
    return f"{name}{suffix} <{name}{suffix}@{domain}>"


def upload_to_usenet(
    input_path: str,
    env_vars: dict,
    dry_run: bool = False,
    nyuu_path: str | None = None,
    subject: str | None = None,
    group: str | None = None,
    skip_rar: bool = False,
    obfuscated_map: dict[str, str] | None = None,
    upload_timeout: int | None = None,
    upload_retries: int = 0,
    password: str | None = None,
) -> int:
    """Upload de arquivos para Usenet usando nyuu."""

    input_path = os.path.abspath(input_path)


    # Validar entrada
    if not os.path.exists(input_path):
        print(f"Erro: '{input_path}' não existe.")
        return 1

    is_folder = os.path.isdir(input_path)
    if not is_folder and not os.path.isfile(input_path):
        print(f"Erro: '{input_path}' não é um arquivo nem pasta.")
        return 1

    # Preparar arquivos para upload
    import tempfile
    import shutil

    if is_folder:
        # Para pastas, criar diretório temporário e copiar CONTEÚDO
        temp_dir = tempfile.mkdtemp(prefix="upapasta_")
        
        # Copiar o conteúdo da pasta de origem para a raiz do temp_dir
        for item in os.listdir(input_path):
            s = os.path.join(input_path, item)
            d = os.path.join(temp_dir, item)
            if os.path.isdir(s):
                shutil.copytree(s, d, symlinks=False, ignore=None)
            else:
                shutil.copy2(s, d)

        # Coletar arquivos relativos à temp
        files_to_upload = []
        for root, _, files in os.walk(temp_dir):
            for file in files:
                rel_path = os.path.relpath(os.path.join(root, file), temp_dir)
                files_to_upload.append(rel_path)
        
        # Copiar arquivos PAR2 para temp
        base_name = input_path
        par2_pattern = glob.escape(base_name) + "*par2*"
        par2_files_abs = sorted(glob.glob(par2_pattern))
        par2_files = []
        for par2 in par2_files_abs:
            temp_par2 = os.path.join(temp_dir, os.path.basename(par2))
            shutil.copy2(par2, temp_par2)
            par2_files.append(os.path.basename(par2))
        
        working_dir = temp_dir
    else:
        working_dir = os.path.dirname(input_path)
        temp_dir = None

        base_no_ext = os.path.splitext(os.path.basename(input_path))[0]
        is_rar_volume = input_path.endswith(".rar") and ".part" in base_no_ext

        if is_rar_volume:
            # Conjunto de volumes: inclui todos os partXX.rar do conjunto
            set_base = base_no_ext.rsplit(".part", 1)[0]
            vol_pattern = os.path.join(working_dir, glob.escape(set_base) + ".part*.rar")
            rar_volumes = sorted(glob.glob(vol_pattern))
            files_to_upload = [os.path.basename(v) for v in rar_volumes] if rar_volumes else [os.path.basename(input_path)]
            base_name = os.path.join(working_dir, set_base)
        else:
            files_to_upload = [os.path.basename(input_path)]
            base_name = os.path.splitext(input_path)[0]

        par2_pattern = glob.escape(base_name) + "*par2*"
        par2_files = [os.path.basename(f) for f in sorted(glob.glob(par2_pattern))]

    if not par2_files:
        print(f"Erro: nenhum arquivo de paridade encontrado para '{input_path}'.")
        print("Execute 'python3 makepar.py' primeiro para gerar os arquivos .par2")
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
        return 3

    # Carrega credenciais do .env
    # env_vars = load_env_file(env_file)

    nntp_host = env_vars.get("NNTP_HOST") or os.environ.get("NNTP_HOST")
    nntp_port = env_vars.get("NNTP_PORT") or os.environ.get("NNTP_PORT", "119")
    nntp_ssl = env_vars.get("NNTP_SSL", "false").lower() in ("true", "1", "yes")
    nntp_ignore_cert = env_vars.get("NNTP_IGNORE_CERT", "false").lower() in ("true", "1", "yes")
    nntp_user = env_vars.get("NNTP_USER") or os.environ.get("NNTP_USER")
    nntp_pass = env_vars.get("NNTP_PASS") or os.environ.get("NNTP_PASS")
    nntp_connections = env_vars.get("NNTP_CONNECTIONS") or os.environ.get("NNTP_CONNECTIONS", "50")
    usenet_group = group or env_vars.get("USENET_GROUP") or os.environ.get("USENET_GROUP")
    article_size = env_vars.get("ARTICLE_SIZE") or os.environ.get("ARTICLE_SIZE", "700K")
    check_connections = env_vars.get("CHECK_CONNECTIONS") or os.environ.get("CHECK_CONNECTIONS", "5")
    check_tries = env_vars.get("CHECK_TRIES") or os.environ.get("CHECK_TRIES", "2")
    check_delay = env_vars.get("CHECK_DELAY") or os.environ.get("CHECK_DELAY", "5s")
    check_retry_delay = env_vars.get("CHECK_RETRY_DELAY") or os.environ.get("CHECK_RETRY_DELAY", "30s")
    check_post_tries = env_vars.get("CHECK_POST_TRIES") or os.environ.get("CHECK_POST_TRIES", "2")
    nzb_overwrite_env = env_vars.get("NZB_OVERWRITE") or os.environ.get("NZB_OVERWRITE")
    skip_errors = env_vars.get("SKIP_ERRORS") or os.environ.get("SKIP_ERRORS", "all")
    dump_failed_posts = env_vars.get("DUMP_FAILED_POSTS") or os.environ.get("DUMP_FAILED_POSTS")
    quiet = env_vars.get("QUIET", "false").lower() in ("true", "1", "yes")
    log_time = env_vars.get("LOG_TIME", "true").lower() in ("true", "1", "yes")

    nzb_out, nzb_out_abs = resolve_nzb_out(
        input_path, env_vars, is_folder, skip_rar, working_dir, obfuscated_map
    )
    nzb_out, nzb_out_abs, nzb_overwrite, ok = handle_nzb_conflict(
        nzb_out, nzb_out_abs, env_vars, nzb_overwrite_env, working_dir
    )
    if not ok:
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        return 6

    if not all([nntp_host, nntp_user, nntp_pass, usenet_group]):
        print("Erro: credenciais incompletas. Configure .env com:")
        print("  NNTP_HOST=<seu_servidor>")
        print("  NNTP_PORT=119")
        print("  NNTP_USER=<seu_usuario>")
        print("  NNTP_PASS=<sua_senha>")
        print("  USENET_GROUP=<seu_grupo>")
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
        return 2

    # Encontra nyuu
    if nyuu_path:
        if not os.path.exists(nyuu_path):
            print(f"Erro: nyuu não encontrado em '{nyuu_path}'")
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)
            return 4
    else:
        nyuu_path = find_nyuu()
        if not nyuu_path:
            print("Erro: nyuu não encontrado. Instale-o (https://github.com/Piorosen/nyuu)")
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)
            return 4

    # Define subject
    if not subject:
        if is_folder:
            subject = os.path.basename(input_path)
        else:
            subject = os.path.basename(os.path.splitext(input_path)[0])

    # Constrói comando nyuu com todas as opções
    # nyuu -h <host> [-P <port>] [-S] [-i] -u <user> -p <pass> -c <connections> -g <group> -a <article-size> -s <subject> <files>
    cmd = [
        nyuu_path,
        "-h", nntp_host,
        "-P", str(nntp_port),
    ]

    if nntp_ssl:
        cmd.append("-S")

    if nntp_ignore_cert:
        cmd.append("-i")

    cmd.extend([
        "-u", nntp_user,
        "-p", nntp_pass,
        "-n", str(nntp_connections),
        "-g", usenet_group,
        "-a", article_size,
        "-f", generate_anonymous_uploader(),  # Nome anônimo para proteger privacidade
        "--date", "now",  # Fixar timestamp para proteger privacidade
        "-s", subject,
    ])
    
    # Adicionar opção -o para arquivo NZB se configurado
    if nzb_out:
        cmd.extend(["-o", nzb_out])
    
    # Adicionar opção -O para sobrescrever NZB se configurado
    if nzb_overwrite:
        cmd.append("-O")

    # Timeout de conexão (nyuu usa --timeout em segundos)
    if upload_timeout is not None:
        cmd.extend(["--timeout", str(upload_timeout)])
    
    # Adicionar arquivos a fazer upload, aplicando renomeação se necessário
    if obfuscated_map:
        if is_folder:
            # Para pastas, o mapa contém a relação nome_ofuscado -> nome_original da pasta
            obfuscated_folder_name = os.path.basename(input_path)
            original_folder_name = obfuscated_map.get(obfuscated_folder_name)

            if original_folder_name:
                for file_path in files_to_upload:
                    # O 'file_path' aqui é relativo ao temp_dir, ex: 'sub/file.txt'
                    # O nome da pasta ofuscada não faz parte do caminho relativo
                    original_file_path = f"{original_folder_name}/{file_path}"
                    cmd.extend([f"{file_path}"])  # Sem renomeação, usar o arquivo físico
            else:
                 cmd.extend(files_to_upload) # Fallback se o mapa estiver errado
        else:
            # Para arquivos únicos
            file_to_upload = files_to_upload[0]
            original_name = obfuscated_map.get(file_to_upload)
            if original_name:
                cmd.extend([f"{file_to_upload}"])  # Sem renomeação
            else:
                cmd.append(file_to_upload)
    else:
        cmd.extend(files_to_upload)

    # Adicionar todos os arquivos .par2
    cmd.extend(par2_files)

    if dry_run:
        print("Comando nyuu (dry-run):")
        print(" ".join(str(x) for x in cmd))
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
        return 0

    # Calcular tamanho total
    all_files = files_to_upload + par2_files
    total_size_bytes = 0
    for f in all_files:
        try:
            total_size_bytes += os.path.getsize(os.path.join(working_dir, f))
        except OSError:
            pass

    def format_size(size_bytes):
        if size_bytes < 1024**2: return f"{size_bytes/1024:.1f} KB"
        elif size_bytes < 1024**3: return f"{size_bytes/1024**2:.2f} MB"
        else: return f"{size_bytes/1024**3:.2f} GB"

    try:
        term_columns = shutil.get_terminal_size().columns
    except Exception:
        term_columns = 80
    sep = "─" * min(term_columns - 1, 60)

    rows = [
        ("Host",    f"{nntp_host}:{nntp_port}"),
        ("Grupo",   usenet_group),
        ("Subject", subject),
        ("Total",   f"{format_size(total_size_bytes)}  ({len(all_files)} arquivos)"),
    ]
    if nzb_out:
        rows.append(("NZB", nzb_out))

    label_w = max(len(r[0]) for r in rows)
    print(sep)
    print("  Upload para Usenet")
    print(sep)
    for label, value in rows:
        print(f"  {label:<{label_w}}  {value}")
    print(sep)
    print()

    max_attempts = 1 + max(0, upload_retries)
    last_rc = 5
    for attempt in range(1, max_attempts + 1):
        if attempt > 1:
            print(f"\nTentativa {attempt}/{max_attempts} de upload...")
        try:
            # Executar nyuu e deixar que ele controle o output diretamente
            # Isso permite que a barra de progresso nativa do nyuu funcione
            subprocess.run(cmd, check=True, cwd=working_dir)
            last_rc = 0
            break
        except subprocess.CalledProcessError as e:
            print(f"\nErro: nyuu retornou código {e.returncode}.")
            last_rc = 5
        except FileNotFoundError:
            print(f"\nErro: nyuu não encontrado em '{nyuu_path}'.")
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)
            return 4
        except OSError as e:
            print(f"\nErro de I/O ao executar nyuu: {e}")
            last_rc = 5

    if last_rc != 0:
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
        return last_rc

    # Corrigir NZB para preservar estrutura de pastas
    if nzb_out_abs and os.path.exists(nzb_out_abs) and is_folder:
        folder_name = os.path.basename(input_path)
        fix_nzb_subjects(nzb_out_abs, files_to_upload + par2_files, folder_name)

    # Injetar senha no NZB para extração automática pelos clientes
    if nzb_out_abs and os.path.exists(nzb_out_abs) and password:
        inject_nzb_password(nzb_out_abs, password)
        print(f"Senha injetada no NZB.")

    # Verificar integridade do NZB gerado
    if nzb_out_abs:
        if not _verify_nzb(nzb_out_abs):
            print(f"Aviso: NZB gerado em '{nzb_out_abs}' está ausente, vazio ou não contém elementos <file>.")
        else:
            print(f"NZB verificado: {os.path.basename(nzb_out_abs)}")

    # Limpar diretório temporário se foi criado
    if temp_dir and os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)

    return 0



