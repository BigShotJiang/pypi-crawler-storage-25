from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Final, Literal

Resolution = Literal["360", "480", "720", "1080", "best"]

RESOLUTION_CHOICES: Final[tuple[str, ...]] = ("360", "480", "720", "1080", "best")
DEFAULT_RESOLUTION: Final[Resolution] = "720"
DEFAULT_TIMEOUT_SECONDS: Final[int] = 35
DEFAULT_CONCURRENCY: Final[int] = 12


def detect_default_output_dir() -> Path:
    downloads = Path.home() / "Downloads"
    if downloads.is_dir() and os.access(downloads, os.W_OK):
        return downloads

    cwd = Path.cwd()
    if cwd.is_dir() and os.access(cwd, os.W_OK):
        return cwd

    return Path(".")

USER_AGENT: Final[str] = (
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

PAGE_HEADERS: Final[dict[str, str]] = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Referer": "https://myanime.live/",
    "Upgrade-Insecure-Requests": "1",
}

DM_URL_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"https?://(?:www\.)?dailymotion\.com/embed/video/[A-Za-z0-9]+"
    r"|https?://geo\.dailymotion\.com/player\.html\?video=[A-Za-z0-9]+"
    r"|https?://(?:www\.)?dailymotion\.com/video/[A-Za-z0-9_]+"
    r"|https?://dai\.ly/[A-Za-z0-9]+",
    flags=re.IGNORECASE,
)
