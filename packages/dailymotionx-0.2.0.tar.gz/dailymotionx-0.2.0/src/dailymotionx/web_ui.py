"""
Lightweight local web UI for the dailymotion downloader.

Starts a stdlib HTTP server on localhost, opens the browser automatically,
and streams download progress to the page via Server-Sent Events (SSE).

No third-party dependencies beyond what the rest of the package already uses.
"""

from __future__ import annotations

import io
import json
import queue
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from .constants import (
    DEFAULT_CONCURRENCY,
    DEFAULT_RESOLUTION,
    DEFAULT_TIMEOUT_SECONDS,
    RESOLUTION_CHOICES,
    detect_default_output_dir,
)
from .downloader import download_episode
from .errors import DailymotionError, FFmpegNotFoundError
from .extractor import is_http_url
from .ffmpeg_utils import ffmpeg_in_path, ffmpeg_install_hint
from .models import DownloadRequest

# ---------------------------------------------------------------------------
# HTML template (embedded — no external files needed)
# ---------------------------------------------------------------------------

_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Dailymotion Downloader</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:       #0d0f14;
    --surface:  #161a23;
    --card:     #1e2330;
    --border:   #2a3045;
    --accent:   #5b8dee;
    --accent2:  #8b5cf6;
    --success:  #34d399;
    --warn:     #fbbf24;
    --error:    #f87171;
    --text:     #e8eaf0;
    --muted:    #6b7280;
    --radius:   14px;
  }

  html, body { height: 100%; }

  body {
    font-family: 'Inter', sans-serif;
    background: var(--bg);
    color: var(--text);
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100vh;
    padding: 40px 20px 60px;
  }

  /* ---- header ---- */
  header { text-align: center; margin-bottom: 40px; }
  header h1 {
    font-size: 2rem;
    font-weight: 700;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: -0.5px;
  }
  header p { margin-top: 6px; color: var(--muted); font-size: 0.9rem; }

  /* ---- banners ---- */
  .banner {
    display: none;
    margin-bottom: 24px;
    padding: 12px 18px;
    border-radius: 10px;
    font-size: 0.88rem;
    width: 100%;
    max-width: 680px;
  }
  .banner strong { display: block; margin-bottom: 4px; }
  .banner code {
    padding: 2px 7px;
    border-radius: 5px;
    font-size: 0.83rem;
  }
  .banner-warn {
    background: rgba(251,191,36,.1);
    border: 1px solid var(--warn);
    color: var(--warn);
  }
  .banner-warn code { background: rgba(251,191,36,.15); }
  .banner-error {
    background: rgba(248,113,113,.1);
    border: 1px solid var(--error);
    color: var(--error);
  }
  .banner-error code { background: rgba(248,113,113,.12); }

  /* ---- card ---- */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 32px;
    width: 100%;
    max-width: 680px;
    box-shadow: 0 8px 40px rgba(0,0,0,.4);
  }

  /* ---- form ---- */
  .field { display: flex; flex-direction: column; gap: 8px; margin-bottom: 20px; }
  label { font-size: 0.82rem; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: .6px; }

  input[type="text"], select {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    color: var(--text);
    font-family: inherit;
    font-size: 0.95rem;
    padding: 12px 16px;
    outline: none;
    transition: border-color .2s, box-shadow .2s;
    width: 100%;
  }
  input[type="text"]:focus, select:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(91,141,238,.18);
  }
  select option { background: var(--card); }

  .row { display: flex; gap: 16px; }
  .row .field { flex: 1; }

  /* ---- button ---- */
  button {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 10px;
    font-family: inherit;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    color: #fff;
    transition: opacity .2s, transform .1s;
  }
  button:hover:not(:disabled) { opacity: .92; transform: translateY(-1px); }
  button:active:not(:disabled) { transform: translateY(0); }
  button:disabled { opacity: .45; cursor: not-allowed; transform: none; }

  /* ---- progress bar ---- */
  #progress-section {
    display: none;
    margin-top: 28px;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 20px 22px;
  }

  .progress-top-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 14px;
    gap: 8px;
  }

  #phase-label {
    font-size: 0.88rem;
    font-weight: 600;
    color: var(--text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    flex: 1;
  }

  #speed-chip {
    flex-shrink: 0;
    background: rgba(91,141,238,.15);
    color: var(--accent);
    padding: 3px 10px;
    border-radius: 99px;
    font-size: 0.78rem;
    font-weight: 600;
    white-space: nowrap;
    transition: opacity .3s;
    min-width: 70px;
    text-align: center;
  }

  .progress-track {
    height: 10px;
    background: var(--bg);
    border-radius: 99px;
    overflow: hidden;
    border: 1px solid var(--border);
    position: relative;
  }

  #progress-fill {
    height: 100%;
    width: 0%;
    background: linear-gradient(90deg, var(--accent), var(--accent2));
    border-radius: 99px;
    transition: width 0.5s ease;
    position: relative;
  }

  /* Shimmer overlay — always on, visible through fill opacity */
  #progress-fill::after {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg,
      transparent 0%,
      rgba(255,255,255,.25) 50%,
      transparent 100%);
    background-size: 60% 100%;
    animation: shimmer 1.6s ease-in-out infinite;
    opacity: 0;
    transition: opacity .3s;
  }
  #progress-fill.active::after { opacity: 1; }

  @keyframes shimmer {
    0%   { background-position: -100% 0; }
    100% { background-position: 200% 0; }
  }

  /* Indeterminate — used for resolving / merging */
  .progress-track.indeterminate #progress-fill {
    width: 35% !important;
    transition: none;
    animation: slide 1.4s ease-in-out infinite;
  }
  @keyframes slide {
    0%   { transform: translateX(-120%); }
    100% { transform: translateX(400%);  }
  }

  .progress-bottom-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 10px;
  }
  #progress-pct {
    font-size: 0.88rem;
    font-weight: 700;
    color: var(--text);
  }
  #progress-eta {
    font-size: 0.8rem;
    color: var(--muted);
  }

  /* Phase step pills */
  .phase-steps {
    display: flex;
    gap: 6px;
    margin-top: 14px;
    flex-wrap: wrap;
  }
  .step-pill {
    font-size: 0.73rem;
    padding: 3px 10px;
    border-radius: 99px;
    border: 1px solid var(--border);
    color: var(--muted);
    background: transparent;
    transition: color .3s, border-color .3s, background .3s;
  }
  .step-pill.active {
    background: rgba(91,141,238,.15);
    border-color: var(--accent);
    color: var(--accent);
    font-weight: 600;
  }
  .step-pill.done {
    background: rgba(52,211,153,.1);
    border-color: var(--success);
    color: var(--success);
  }

  /* ---- result banner ---- */
  #result {
    display: none;
    margin-top: 20px;
    padding: 16px 20px;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 500;
    border: 1px solid transparent;
  }
  #result.success { background: rgba(52,211,153,.1); border-color: var(--success); color: var(--success); }
  #result.error   { background: rgba(248,113,113,.1); border-color: var(--error);  color: var(--error);  }

  /* ---- progress log ---- */
  #log-wrap {
    margin-top: 16px;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
  }
  #log-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 14px;
    border-bottom: 1px solid var(--border);
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: .5px;
    cursor: pointer;
    user-select: none;
  }
  #log-header:hover { color: var(--text); }
  #log-toggle { font-size: 0.7rem; }
  #log {
    font-family: 'Courier New', monospace;
    font-size: 0.8rem;
    line-height: 1.65;
    padding: 12px 14px;
    max-height: 260px;
    overflow-y: auto;
    white-space: pre-wrap;
    word-break: break-all;
    color: #c9d1e0;
  }
  #log.collapsed { display: none; }
  #log .line-ok    { color: var(--success); }
  #log .line-warn  { color: var(--warn);    }
  #log .line-error { color: var(--error);   }
  #log .line-info  { color: var(--accent);  }

  /* ---- spinner (button) ---- */
  .spinner {
    display: inline-block;
    width: 16px; height: 16px;
    border: 2px solid rgba(255,255,255,.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin .7s linear infinite;
    vertical-align: middle;
    margin-right: 8px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  /* ---- footer ---- */
  footer { margin-top: 36px; color: var(--muted); font-size: 0.78rem; text-align: center; }

  /* ---- scrollbar ---- */
  #log::-webkit-scrollbar { width: 5px; }
  #log::-webkit-scrollbar-track { background: transparent; }
  #log::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>

<header>
  <h1>⬇ Dailymotion Downloader</h1>
  <p>Paste any myanime.live episode link — or a direct Dailymotion URL</p>
</header>

<div id="update-banner" class="banner banner-warn">
  <strong>🔔 yt-dlp update available</strong>
  <span id="update-text"></span> Run: <code>pip install --upgrade yt-dlp</code>
</div>

<div id="ffmpeg-banner" class="banner banner-error">
  <strong>⚠ ffmpeg not found — downloads will fail</strong>
  <span id="ffmpeg-text"></span>
</div>

<div class="card">
  <div class="field">
    <label for="url">Episode or Dailymotion URL</label>
    <input id="url" type="text"
      placeholder="https://myanime.live/... or https://www.dailymotion.com/video/..."
      autocomplete="off" spellcheck="false" />
  </div>

  <div class="row">
    <div class="field">
      <label for="resolution">Resolution</label>
      <select id="resolution">
        <option value="720" selected>720p (recommended)</option>
        <option value="1080">1080p</option>
        <option value="480">480p</option>
        <option value="360">360p</option>
        <option value="best">Best available</option>
      </select>
    </div>
    <div class="field">
      <label for="concurrency">Parallel fragments</label>
      <select id="concurrency">
        <option value="4">4</option>
        <option value="8">8</option>
        <option value="12" selected>12 (default)</option>
        <option value="16">16</option>
      </select>
    </div>
  </div>

  <div class="field">
    <label for="output">Output folder (blank = ~/Downloads)</label>
    <input id="output" type="text" placeholder="Default: ~/Downloads" />
  </div>

  <button id="dlbtn" onclick="startDownload()">Download</button>

  <div id="result"></div>

  <!-- ======= PROGRESS SECTION ======= -->
  <div id="progress-section">

    <div class="progress-top-row">
      <span id="phase-label">Preparing…</span>
      <span id="speed-chip">—</span>
    </div>

    <div class="progress-track" id="progress-track">
      <div id="progress-fill" class="active"></div>
    </div>

    <div class="progress-bottom-row">
      <span id="progress-pct">0%</span>
      <span id="progress-eta"></span>
    </div>

    <div class="phase-steps">
      <span class="step-pill" id="step-resolve">🔍 Resolving</span>
      <span class="step-pill" id="step-video">📥 Video</span>
      <span class="step-pill" id="step-audio">🔊 Audio</span>
      <span class="step-pill" id="step-merge">🔧 Merging</span>
      <span class="step-pill" id="step-done">✅ Done</span>
    </div>

    <!-- collapsible log inside progress section -->
    <div id="log-wrap">
      <div id="log-header" onclick="toggleLog()">
        <span>Detailed log</span>
        <span id="log-toggle">▾ show</span>
      </div>
      <div id="log" class="collapsed"></div>
    </div>

  </div>
  <!-- end progress section -->

</div>

<footer>Running locally · <span id="ver"></span></footer>

<script>
let es = null;
let logVisible = false;

// ---- log helpers ----
function toggleLog() {
  logVisible = !logVisible;
  document.getElementById('log').classList.toggle('collapsed', !logVisible);
  document.getElementById('log-toggle').textContent = logVisible ? '▴ hide' : '▾ show';
}

function appendLog(text, level) {
  const log = document.getElementById('log');
  const cls = level === 'ok' ? 'line-ok'
             : level === 'warn' ? 'line-warn'
             : level === 'error' ? 'line-error'
             : level === 'info' ? 'line-info' : '';
  const line = document.createElement('span');
  if (cls) line.className = cls;
  line.textContent = text + '\\n';
  log.appendChild(line);
  if (logVisible) log.scrollTop = log.scrollHeight;
}

function clearLog() { document.getElementById('log').innerHTML = ''; }

// ---- progress helpers ----
const PHASES = {
  resolving: { label: '🔍 Resolving URL…',       step: 'resolve', indeterminate: true  },
  video:     { label: '📥 Downloading video…',    step: 'video',   indeterminate: false },
  audio:     { label: '🔊 Downloading audio…',    step: 'audio',   indeterminate: false },
  merging:   { label: '🔧 Merging streams…',      step: 'merge',   indeterminate: true  },
  done:      { label: '✅ Complete!',              step: 'done',    indeterminate: false },
};

const STEP_ORDER = ['resolve','video','audio','merge','done'];

function updateProgress({ phase, percent, speed, eta }) {
  const cfg = PHASES[phase] || { label: phase, step: null, indeterminate: false };
  const track = document.getElementById('progress-track');
  const fill  = document.getElementById('progress-fill');

  // Indeterminate mode (resolving / merging)
  if (cfg.indeterminate) {
    track.classList.add('indeterminate');
    fill.classList.remove('active');
  } else {
    track.classList.remove('indeterminate');
    fill.classList.add('active');
    fill.style.width = percent + '%';
    document.getElementById('progress-pct').textContent = percent.toFixed(1) + '%';
  }

  document.getElementById('phase-label').textContent = cfg.label;
  document.getElementById('speed-chip').textContent  = speed || '—';
  document.getElementById('progress-eta').textContent = eta ? 'ETA ' + eta : '';

  // Step pills
  if (cfg.step) {
    const idx = STEP_ORDER.indexOf(cfg.step);
    STEP_ORDER.forEach((s, i) => {
      const el = document.getElementById('step-' + s);
      if (!el) return;
      el.classList.remove('active', 'done');
      if (i < idx)  el.classList.add('done');
      if (i === idx) el.classList.add('active');
    });
  }
}

function resetProgress() {
  document.getElementById('progress-fill').style.width = '0%';
  document.getElementById('progress-fill').classList.add('active');
  document.getElementById('progress-track').classList.remove('indeterminate');
  document.getElementById('progress-pct').textContent = '0%';
  document.getElementById('progress-eta').textContent = '';
  document.getElementById('speed-chip').textContent = '—';
  document.getElementById('phase-label').textContent = 'Preparing…';
  STEP_ORDER.forEach(s => {
    const el = document.getElementById('step-' + s);
    if (el) el.classList.remove('active','done');
  });
}

// ---- button ----
function setButton(disabled) {
  const btn = document.getElementById('dlbtn');
  btn.disabled = disabled;
  btn.innerHTML = disabled
    ? '<span class="spinner"></span>Downloading…'
    : 'Download';
}

// ---- result ----
function showResult(type, msg) {
  const el = document.getElementById('result');
  if (!type) { el.style.display = 'none'; return; }
  el.className = type;
  el.textContent = msg;
  el.style.display = 'block';
}

// ---- main download ----
async function startDownload() {
  const url         = document.getElementById('url').value.trim();
  const resolution  = document.getElementById('resolution').value;
  const concurrency = document.getElementById('concurrency').value;
  const output      = document.getElementById('output').value.trim();

  if (!url) { showResult('error', 'Please enter a URL.'); return; }

  // reset
  showResult('', '');
  clearLog();
  resetProgress();
  document.getElementById('progress-section').style.display = 'block';
  setButton(true);
  updateProgress({ phase: 'resolving', percent: 0, speed: '', eta: '' });

  if (es) { es.close(); es = null; }

  const params = new URLSearchParams({ url, resolution, concurrency });
  if (output) params.set('output', output);

  es = new EventSource('/download?' + params.toString());

  es.addEventListener('log', e => {
    const d = JSON.parse(e.data);
    appendLog(d.text, d.level || 'plain');
  });

  es.addEventListener('progress', e => {
    const d = JSON.parse(e.data);
    updateProgress(d);
  });

  es.addEventListener('done', e => {
    const d = JSON.parse(e.data);
    es.close(); es = null;
    setButton(false);
    if (d.success) {
      updateProgress({ phase: 'done', percent: 100, speed: '', eta: '' });
      document.getElementById('progress-fill').style.width = '100%';
      document.getElementById('progress-fill').classList.remove('active');
      document.getElementById('progress-pct').textContent = '100%';
      showResult('success', '✅ Saved to: ' + d.path);
    } else {
      showResult('error', '❌ ' + d.error);
    }
  });

  es.onerror = () => {
    es.close(); es = null;
    setButton(false);
    showResult('error', 'Connection to local server lost. Is it still running?');
  };
}

// ---- on load: fetch status ----
window.addEventListener('DOMContentLoaded', async () => {
  try {
    const r = await fetch('/status');
    const d = await r.json();
    document.getElementById('ver').textContent = 'v' + (d.version || '?');

    if (d.update_available) {
      document.getElementById('update-text').textContent =
        d.update_installed + ' → ' + d.update_latest + '. ';
      document.getElementById('update-banner').style.display = 'block';
    }
    if (!d.ffmpeg_ok) {
      document.getElementById('ffmpeg-text').textContent = ' ' + d.ffmpeg_hint;
      document.getElementById('ffmpeg-banner').style.display = 'block';
    }
  } catch (_) {}
});
</script>
</body>
</html>
"""

# ---------------------------------------------------------------------------
# SSE helpers
# ---------------------------------------------------------------------------

def _sse_event(event: str, data: Any) -> bytes:
    payload = json.dumps(data, ensure_ascii=False)
    return f"event: {event}\ndata: {payload}\n\n".encode("utf-8")


# ---------------------------------------------------------------------------
# Formatting helpers for yt-dlp progress data
# ---------------------------------------------------------------------------

def _fmt_speed(bps: float | None) -> str:
    if not bps:
        return ""
    if bps >= 1024 ** 2:
        return f"{bps / 1024 ** 2:.1f} MiB/s"
    if bps >= 1024:
        return f"{bps / 1024:.1f} KiB/s"
    return f"{bps:.0f} B/s"


def _fmt_eta(seconds: int | float | None) -> str:
    if seconds is None:
        return ""
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


# ---------------------------------------------------------------------------
# Background download worker
# ---------------------------------------------------------------------------

def _run_download(request: DownloadRequest, event_queue: "queue.Queue[bytes]") -> None:
    """
    Runs in a daemon thread.  Sends SSE 'log', 'progress', and 'done' events.

    Progress mapping:
      stream 0 (video):  5% →  50%
      stream 1 (audio): 50% →  90%
      merging phase:    90%  (indeterminate until done)
    """

    def _log(text: str, level: str = "plain") -> None:
        event_queue.put(_sse_event("log", {"text": text, "level": level}))

    def _progress(phase: str, percent: float, speed: str = "", eta: str = "") -> None:
        event_queue.put(_sse_event("progress", {
            "phase": phase,
            "percent": round(percent, 1),
            "speed": speed,
            "eta": eta,
        }))

    def _done(success: bool, path: str = "", error: str = "") -> None:
        event_queue.put(_sse_event("done", {"success": success, "path": path, "error": error}))

    try:
        if not ffmpeg_in_path():
            _log("ERROR: ffmpeg not found in PATH.", "error")
            _log(ffmpeg_install_hint(), "warn")
            _done(False, error="ffmpeg is not installed. See the warning banner above.")
            return

        _log(f"URL       : {request.episode_url}", "info")
        _log(f"Resolution: {request.resolution}", "info")
        _log(f"Output dir: {request.output_dir}", "info")
        _progress("resolving", 0)
        _log("Resolving Dailymotion URL…", "info")

        # ---- yt-dlp progress hook ----
        stream_index: list[int] = [0]

        def _hook(d: dict[str, Any]) -> None:
            status = d.get("status", "")

            if status == "downloading":
                downloaded = d.get("downloaded_bytes") or 0
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                raw_pct = (downloaded / total * 100.0) if total > 0 else 0.0

                if stream_index[0] == 0:
                    # video: map raw 0-100 → overall 5-50
                    overall = 5.0 + raw_pct * 0.45
                    phase = "video"
                else:
                    # audio: map raw 0-100 → overall 50-90
                    overall = 50.0 + raw_pct * 0.40
                    phase = "audio"

                _progress(
                    phase,
                    overall,
                    _fmt_speed(d.get("speed")),
                    _fmt_eta(d.get("eta")),
                )

            elif status == "finished":
                stream_index[0] += 1
                if stream_index[0] == 1:
                    # video stream done — audio about to start
                    _progress("video", 50.0)
                    _log("Video stream downloaded.", "ok")
                elif stream_index[0] >= 2:
                    # audio stream done — now ffmpeg merge
                    _progress("merging", 90.0)
                    _log("Audio stream downloaded. Merging with ffmpeg…", "ok")

            elif status == "error":
                _log("yt-dlp reported a stream download error.", "error")

        result = download_episode(request, progress_hooks=[_hook], suppress_output=True)

        _progress("done", 100.0)
        _log(f"Saved to: {result.output_file}", "ok")
        _done(True, path=str(result.output_file))

    except FFmpegNotFoundError as exc:
        _log(str(exc), "error")
        _log(ffmpeg_install_hint(), "warn")
        _done(False, error=str(exc))
    except DailymotionError as exc:
        _log(str(exc), "error")
        _done(False, error=str(exc))
    except Exception as exc:  # noqa: BLE001
        tb = traceback.format_exc()
        _log(tb, "error")
        _done(False, error=str(exc))


# ---------------------------------------------------------------------------
# HTTP request handler
# ---------------------------------------------------------------------------

class _Handler(BaseHTTPRequestHandler):
    # Injected by _UIServer.__init__
    _app: "_UIServer"

    def log_message(self, fmt: str, *args: Any) -> None:  # silence access logs
        pass

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path in ("/", "/index.html"):
            self._serve_html()
        elif path == "/status":
            self._serve_status()
        elif path == "/download":
            self._serve_download(parsed.query)
        else:
            self._not_found()

    def _serve_html(self) -> None:
        body = _HTML.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_status(self) -> None:
        payload = json.dumps(self._app.status_payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _serve_download(self, query: str) -> None:
        params = parse_qs(query)

        def _first(key: str, default: str) -> str:
            vals = params.get(key)
            return vals[0].strip() if vals else default

        episode_url = _first("url", "")
        resolution  = _first("resolution", DEFAULT_RESOLUTION)
        concurrency = int(_first("concurrency", str(DEFAULT_CONCURRENCY)))
        output_raw  = _first("output", "")

        # Always respond as SSE
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()

        if not episode_url or not is_http_url(episode_url):
            self.wfile.write(_sse_event("done", {"success": False, "error": "Invalid or missing URL"}))
            return

        if resolution not in RESOLUTION_CHOICES:
            resolution = DEFAULT_RESOLUTION

        output_dir = Path(output_raw) if output_raw else detect_default_output_dir()

        req = DownloadRequest(
            episode_url=episode_url,
            resolution=resolution,  # type: ignore[arg-type]
            output_dir=output_dir,
            concurrency=max(1, concurrency),
            timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
        )

        ev_queue: queue.Queue[bytes] = queue.Queue()

        worker = threading.Thread(
            target=_run_download,
            args=(req, ev_queue),
            daemon=True,
        )
        worker.start()

        try:
            while True:
                try:
                    chunk = ev_queue.get(timeout=0.4)
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except queue.Empty:
                    if not worker.is_alive():
                        break
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _not_found(self) -> None:
        self.send_response(404)
        self.end_headers()


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------

class _UIServer:
    def __init__(self, host: str = "127.0.0.1", port: int = 0) -> None:
        from .updater import check_ytdlp_update

        handler = type("_BoundHandler", (_Handler,), {"_app": self})
        self._server = HTTPServer((host, port), handler)
        self._port = self._server.server_address[1]
        self._host = host

        update = check_ytdlp_update()
        ffmpeg_ok = ffmpeg_in_path()

        try:
            from importlib.metadata import version as pkg_version
            pkg_ver = pkg_version("dailymotionx")
        except Exception:  # noqa: BLE001
            pkg_ver = "0.2.0"

        self.status_payload: dict[str, Any] = {
            "version": pkg_ver,
            "ffmpeg_ok": ffmpeg_ok,
            "ffmpeg_hint": ffmpeg_install_hint() if not ffmpeg_ok else "",
            "update_available": update.update_available,
            "update_installed": update.installed,
            "update_latest": update.latest,
        }

    @property
    def url(self) -> str:
        return f"http://{self._host}:{self._port}"

    def serve_forever(self) -> None:
        self._server.serve_forever()

    def shutdown(self) -> None:
        self._server.shutdown()


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def launch_ui(host: str = "127.0.0.1", port: int = 0, open_browser: bool = True) -> None:
    """
    Start the local web UI and block until Ctrl-C.
    port=0 lets the OS pick a free port automatically.
    """
    server = _UIServer(host=host, port=port)
    url = server.url

    print(f"\n  Dailymotion Downloader UI")
    print(f"  Open in your browser → {url}\n")
    print("  Press Ctrl-C to stop.\n")

    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  UI server stopped.")
    finally:
        server.shutdown()
