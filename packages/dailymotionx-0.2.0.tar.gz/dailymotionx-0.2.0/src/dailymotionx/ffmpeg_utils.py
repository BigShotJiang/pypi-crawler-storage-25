from __future__ import annotations

import platform
import shutil


def ffmpeg_in_path() -> bool:
    """Return True if ffmpeg binary is discoverable on PATH."""
    return shutil.which("ffmpeg") is not None


def ffmpeg_install_command(os_name: str | None = None) -> str:
    """Return the recommended install command for the current or specified OS."""
    normalized = (os_name or platform.system()).strip().lower()

    if "windows" in normalized:
        return "winget install Gyan.FFmpeg"
    if "darwin" in normalized or "mac" in normalized:
        return "brew install ffmpeg"
    if "linux" in normalized:
        return "sudo apt update && sudo apt install -y ffmpeg"

    return "Install ffmpeg from https://ffmpeg.org/download.html"


def ffmpeg_install_hint(os_name: str | None = None) -> str:
    """
    Return a friendly, multi-line install hint for ffmpeg.

    If the OS is unknown we redirect to the official download page.
    Otherwise we include the exact install command.
    """
    command = ffmpeg_install_command(os_name)
    if command.startswith("Install ffmpeg from"):
        return (
            "ffmpeg is required to merge audio and video streams.\n"
            f"{command}"
        )

    return (
        "ffmpeg is required to merge audio and video streams.\n"
        f"Install it with:\n\n    {command}\n\n"
        "After installing, restart your terminal and try again."
    )
