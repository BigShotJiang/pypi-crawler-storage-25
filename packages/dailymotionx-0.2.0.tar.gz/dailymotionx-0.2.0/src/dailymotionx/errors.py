from __future__ import annotations


class DailymotionError(Exception):
    """Base exception for all package errors."""


class InvalidEpisodeUrlError(DailymotionError):
    """Raised when the provided episode URL is invalid."""


class EpisodeFetchError(DailymotionError):
    """Raised when an episode page cannot be fetched."""


class DailymotionUrlNotFoundError(DailymotionError):
    """Raised when no Dailymotion player URL is found on page."""


class InvalidResolutionError(DailymotionError):
    """Raised when unsupported resolution is requested."""


class FFmpegNotFoundError(DailymotionError):
    """Raised when ffmpeg is required but unavailable."""


class DownloadFailedError(DailymotionError):
    """Raised when media download or merge fails."""


class DependencyNotFoundError(DailymotionError):
    """Raised when an optional runtime dependency is missing."""
