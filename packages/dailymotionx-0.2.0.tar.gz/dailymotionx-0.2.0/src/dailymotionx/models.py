from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .constants import DEFAULT_CONCURRENCY, DEFAULT_RESOLUTION, DEFAULT_TIMEOUT_SECONDS, Resolution


@dataclass(slots=True)
class DownloadRequest:
    episode_url: str
    resolution: Resolution = DEFAULT_RESOLUTION
    output_dir: Path = Path("downloads")
    concurrency: int = DEFAULT_CONCURRENCY
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS


@dataclass(slots=True, frozen=True)
class DownloadResult:
    episode_url: str
    dailymotion_url: str
    resolution: str
    output_file: Path
