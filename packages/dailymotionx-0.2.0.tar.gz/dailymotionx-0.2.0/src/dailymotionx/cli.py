from __future__ import annotations

import argparse
import importlib
import importlib.util
import re
import sys
from pathlib import Path
from typing import Any

from importlib.metadata import PackageNotFoundError, version as package_version

from .constants import (
    DEFAULT_CONCURRENCY,
    DEFAULT_RESOLUTION,
    DEFAULT_TIMEOUT_SECONDS,
    RESOLUTION_CHOICES,
    detect_default_output_dir,
)
from .downloader import cleanup_incomplete_files, download_episode
from .errors import (
    DailymotionError,
    DependencyNotFoundError,
    FFmpegNotFoundError,
    InvalidEpisodeUrlError,
)
from .extractor import is_http_url
from .ffmpeg_utils import ffmpeg_in_path, ffmpeg_install_hint
from .models import DownloadRequest
from .updater import check_ytdlp_update, upgrade_ytdlp


try:
    PACKAGE_VERSION = package_version("dailymotionx")
except PackageNotFoundError:
    PACKAGE_VERSION = "0.2.0"


# ---------------------------------------------------------------------------
# Printer — rich if available, plain-text fallback
# ---------------------------------------------------------------------------

class Printer:
    def __init__(self) -> None:
        self._console: Any | None = None
        self._panel_cls: Any | None = None
        try:
            from rich.console import Console
            from rich.panel import Panel

            self._console = Console()
            self._panel_cls = Panel
        except ModuleNotFoundError:
            self._console = None
            self._panel_cls = None

    @staticmethod
    def _strip_markup(text: str) -> str:
        return re.sub(r"\[/?[^\]]+\]", "", text)

    def print(self, text: str) -> None:
        if self._console is not None:
            self._console.print(text)
            return
        print(self._strip_markup(text))

    def panel(self, title: str, body: str, border_style: str = "cyan") -> None:
        if self._console is not None and self._panel_cls is not None:
            self._console.print(self._panel_cls.fit(body, title=title, border_style=border_style))
            return
        print(f"{title}\n{body}")


# ---------------------------------------------------------------------------
# Optional questionary loader
# ---------------------------------------------------------------------------

def _load_questionary() -> Any:
    try:
        return importlib.import_module("questionary")
    except ModuleNotFoundError as exc:
        raise DependencyNotFoundError(
            "Dependency not found: questionary. Install with: pip install questionary"
        ) from exc


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dailymotion",
        description="Download merged Dailymotion videos from episode page links.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {PACKAGE_VERSION}")

    subparsers = parser.add_subparsers(dest="command")

    # ---- download ----
    download = subparsers.add_parser("download", help="Download from URL")
    download.add_argument("input_url", nargs="?", help="Episode URL or direct Dailymotion URL")
    download.add_argument("-r", "--resolution", choices=RESOLUTION_CHOICES, help="Target resolution")
    download.add_argument("-o", "--output-dir", default=None, help="Output directory")
    download.add_argument("-c", "--concurrency", type=int, default=DEFAULT_CONCURRENCY, help="Fragment concurrency")
    download.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="HTTP timeout seconds")
    download.add_argument(
        "--non-interactive",
        action="store_true",
        help="Disable prompts and require explicit args",
    )

    # ---- doctor ----
    doctor = subparsers.add_parser("doctor", help="Check environment and dependency health")
    doctor.add_argument(
        "--upgrade-ytdlp",
        action="store_true",
        help="Run pip install --upgrade yt-dlp during doctor run",
    )

    # ---- ui ----
    ui = subparsers.add_parser("ui", help="Launch the local browser-based UI")
    ui.add_argument("--port", type=int, default=0, help="Port to listen on (0 = auto)")
    ui.add_argument("--no-browser", action="store_true", help="Don't open the browser automatically")

    return parser


# ---------------------------------------------------------------------------
# argv normalisation — bare URL or no args → 'download'
# ---------------------------------------------------------------------------

def normalize_argv(argv: list[str] | None) -> list[str]:
    raw = list(argv) if argv is not None else sys.argv[1:]
    if not raw:
        return ["download"]

    first = raw[0]
    if first in {"download", "doctor", "ui", "-h", "--help", "--version"}:
        return raw

    return ["download", *raw]


# ---------------------------------------------------------------------------
# Interactive prompts
# ---------------------------------------------------------------------------

def _episode_url_validator(value: str) -> bool | str:
    if is_http_url(value):
        return True
    return "Please enter a valid http/https URL"


def prompt_episode_url() -> str:
    questionary = _load_questionary()
    answer = questionary.text(
        "Paste episode or Dailymotion URL:",
        validate=_episode_url_validator,
    ).ask()
    if answer is None:
        raise KeyboardInterrupt
    return answer.strip()


def prompt_resolution(default: str = DEFAULT_RESOLUTION) -> str:
    questionary = _load_questionary()
    answer = questionary.select(
        "Resolution:",
        choices=list(RESOLUTION_CHOICES),
        default=default,
    ).ask()
    if answer is None:
        raise KeyboardInterrupt
    return answer


# ---------------------------------------------------------------------------
# Build DownloadRequest from parsed args
# ---------------------------------------------------------------------------

def build_request_from_args(args: argparse.Namespace) -> DownloadRequest:
    episode_url = (args.input_url or "").strip()
    resolution = args.resolution
    output_dir = Path(args.output_dir) if args.output_dir else detect_default_output_dir()

    if not args.non_interactive:
        if not episode_url:
            episode_url = prompt_episode_url()
        if not resolution:
            resolution = prompt_resolution()

    if not episode_url:
        raise InvalidEpisodeUrlError(
            "Episode URL is required. Provide an argument or run interactive mode."
        )

    if not resolution:
        resolution = DEFAULT_RESOLUTION

    if not is_http_url(episode_url):
        raise InvalidEpisodeUrlError(f"Invalid URL: {episode_url}")

    return DownloadRequest(
        episode_url=episode_url,
        resolution=resolution,
        output_dir=output_dir,
        concurrency=max(1, int(args.concurrency)),
        timeout_seconds=max(5, int(args.timeout)),
    )


# ---------------------------------------------------------------------------
# yt-dlp update notification (non-blocking, shown at startup)
# ---------------------------------------------------------------------------

def _notify_ytdlp_update(printer: Printer) -> None:
    """
    Silently checks PyPI for a yt-dlp update.  If one is found, prints a
    one-line notice with the exact pip command.  Never blocks the download.
    """
    try:
        result = check_ytdlp_update()
        if result.update_available:
            printer.print(
                f"[yellow]yt-dlp update available ({result.installed} → {result.latest}).[/yellow] "
                f"Run: [bold]pip install --upgrade yt-dlp[/bold]"
            )
    except Exception:  # noqa: BLE001
        pass  # update check is best-effort; never crash the main flow


# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def run_doctor(args: argparse.Namespace, printer: Printer) -> int:
    checks: list[tuple[str, bool, str]] = []

    for label, module_name in (
        ("yt-dlp", "yt_dlp"),
        ("rich", "rich"),
        ("questionary", "questionary"),
        ("curl-cffi", "curl_cffi"),
    ):
        available = importlib.util.find_spec(module_name) is not None
        checks.append((label, available, "available" if available else "missing"))

    ffmpeg_ok = ffmpeg_in_path()
    checks.append(("ffmpeg", ffmpeg_ok, "available" if ffmpeg_ok else "missing"))

    printer.panel("Doctor", "Dependency check results", border_style="cyan")
    for label, ok, detail in checks:
        status = "[green]OK[/green]" if ok else "[red]MISSING[/red]"
        printer.print(f"  - {label}: {status} ({detail})")

    if not ffmpeg_ok:
        printer.print("")
        printer.print(f"[red]{ffmpeg_install_hint()}[/red]")

    # Update check
    printer.print("")
    try:
        update = check_ytdlp_update()
        if update.update_available:
            printer.print(
                f"[yellow]yt-dlp update available: {update.installed} → {update.latest}[/yellow]\n"
                f"Run: [bold]pip install --upgrade yt-dlp[/bold]"
            )
        else:
            printer.print("[green]yt-dlp is up to date.[/green]")
    except Exception:  # noqa: BLE001
        printer.print("[dim]Could not check yt-dlp update (no network?).[/dim]")

    if args.upgrade_ytdlp:
        printer.print("\nRunning yt-dlp upgrade…")
        result = upgrade_ytdlp()
        if result.success:
            printer.print("[green]yt-dlp upgrade completed.[/green]")
        else:
            printer.print("[yellow]yt-dlp upgrade failed.[/yellow]")
        printer.print(result.message)

    missing_critical = any(label == "yt-dlp" and not ok for label, ok, _ in checks)
    return 1 if missing_critical else 0


def run_download(args: argparse.Namespace, printer: Printer) -> int:
    # Non-blocking update notification — best effort
    _notify_ytdlp_update(printer)

    # Warn if ffmpeg is missing before spending time on prompts
    if not ffmpeg_in_path():
        printer.print(f"[bold red]ffmpeg not found.[/bold red]")
        printer.print(ffmpeg_install_hint())
        return 3

    request = build_request_from_args(args)

    printer.panel(
        "Dailymotion Downloader",
        f"Input:      {request.episode_url}\n"
        f"Resolution: {request.resolution}\n"
        f"Output:     {request.output_dir}",
        border_style="cyan",
    )
    printer.print("Starting download…")

    try:
        result = download_episode(request)
    except KeyboardInterrupt:
        cleanup_incomplete_files(request.output_dir)
        raise

    printer.panel(
        "Download Completed",
        f"Saved to:\n{result.output_file}",
        border_style="green",
    )
    return 0


def run_ui(args: argparse.Namespace, printer: Printer) -> int:
    try:
        from .web_ui import launch_ui
    except ImportError as exc:
        printer.print(f"[bold red]Could not import web UI: {exc}[/bold red]")
        return 5

    launch_ui(port=args.port, open_browser=not args.no_browser)
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    printer = Printer()
    parser = build_parser()
    args = parser.parse_args(normalize_argv(argv))

    try:
        if args.command == "doctor":
            return run_doctor(args, printer)

        if args.command == "ui":
            return run_ui(args, printer)

        return run_download(args, printer)

    except FFmpegNotFoundError as exc:
        printer.print(f"[bold red]{exc}[/bold red]")
        printer.print(ffmpeg_install_hint())
        return 3
    except DependencyNotFoundError as exc:
        printer.print(f"[bold red]{exc}[/bold red]")
        return 4
    except DailymotionError as exc:
        printer.print(f"[bold red]{exc}[/bold red]")
        return 2
    except KeyboardInterrupt:
        printer.print("[yellow]Cancelled by user.[/yellow]")
        return 130
