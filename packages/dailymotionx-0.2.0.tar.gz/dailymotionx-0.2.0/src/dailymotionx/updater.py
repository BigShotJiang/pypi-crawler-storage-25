from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as installed_version
from urllib.error import URLError
from urllib.request import urlopen
import json


_PYPI_URL = "https://pypi.org/pypi/yt-dlp/json"
_CHECK_TIMEOUT = 8  # seconds


@dataclass(frozen=True)
class UpgradeResult:
    success: bool
    message: str


@dataclass(frozen=True)
class UpdateCheckResult:
    update_available: bool
    installed: str
    latest: str
    hint: str


def _get_installed_ytdlp_version() -> str | None:
    try:
        return installed_version("yt-dlp")
    except PackageNotFoundError:
        return None


def _get_latest_ytdlp_version() -> str | None:
    try:
        with urlopen(_PYPI_URL, timeout=_CHECK_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["info"]["version"]
    except Exception:
        return None


def _version_tuple(v: str) -> tuple[int, ...]:
    """Convert a version string like '2026.03.17' into a comparable tuple."""
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def check_ytdlp_update(timeout: int = _CHECK_TIMEOUT) -> UpdateCheckResult:
    """
    Check if a newer version of yt-dlp is available on PyPI.

    Returns an UpdateCheckResult. If either version cannot be determined,
    update_available is False and hint is empty.
    """
    installed = _get_installed_ytdlp_version()
    if not installed:
        return UpdateCheckResult(
            update_available=False,
            installed="unknown",
            latest="unknown",
            hint="",
        )

    latest = _get_latest_ytdlp_version()
    if not latest:
        return UpdateCheckResult(
            update_available=False,
            installed=installed,
            latest="unknown",
            hint="",
        )

    update_available = _version_tuple(latest) > _version_tuple(installed)
    hint = (
        f"A new version of yt-dlp is available: {installed} → {latest}\n"
        f"Run: pip install --upgrade yt-dlp"
        if update_available
        else ""
    )

    return UpdateCheckResult(
        update_available=update_available,
        installed=installed,
        latest=latest,
        hint=hint,
    )


def upgrade_ytdlp(python_executable: str | None = None, timeout_seconds: int = 300) -> UpgradeResult:
    """
    Actually runs pip install --upgrade yt-dlp.
    Used by `dailymotion doctor --upgrade-ytdlp` only.
    """
    executable = python_executable or sys.executable
    command = [executable, "-m", "pip", "install", "--upgrade", "yt-dlp"]

    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except Exception as exc:
        return UpgradeResult(False, f"Failed to start yt-dlp upgrade: {exc}")

    output = (completed.stdout or "").strip()
    errors = (completed.stderr or "").strip()
    message = output or errors or "No output"

    if completed.returncode == 0:
        return UpgradeResult(True, message)

    return UpgradeResult(False, message)
