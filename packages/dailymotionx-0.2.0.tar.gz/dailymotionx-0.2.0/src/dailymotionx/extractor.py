from __future__ import annotations

import html
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen

from .constants import DEFAULT_TIMEOUT_SECONDS, DM_URL_PATTERN, PAGE_HEADERS
from .errors import DailymotionUrlNotFoundError, EpisodeFetchError, InvalidEpisodeUrlError


def is_http_url(value: str) -> bool:
    parsed = urlparse(value.strip())
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _extract_video_id_from_dailymotion_url(url: str) -> str | None:
    parsed = urlparse(url.strip())
    host = parsed.netloc.lower().split(":", 1)[0]
    path = parsed.path.strip("/")
    query = parse_qs(parsed.query)

    if host == "dai.ly" and path:
        return path.split("/", 1)[0]

    if host.endswith("dailymotion.com"):
        if "video" in query and query["video"]:
            return query["video"][0]

        if path.startswith("embed/video/"):
            return path.split("/", 2)[-1].split("/", 1)[0]

        if path.startswith("video/"):
            raw = path.split("/", 1)[-1]
            # Dailymotion direct links can be like /video/<id>_<slug>
            return raw.split("_", 1)[0]

        if path.endswith("player.html") and "video" in query and query["video"]:
            return query["video"][0]

    return None


def is_dailymotion_url(value: str) -> bool:
    parsed = urlparse(value.strip())
    host = parsed.netloc.lower().split(":", 1)[0]
    return host == "dai.ly" or host.endswith("dailymotion.com")


def fetch_episode_html(url: str, timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS) -> str:
    if not is_http_url(url):
        raise InvalidEpisodeUrlError(f"Invalid episode URL: {url}")

    request = Request(url.strip(), headers=PAGE_HEADERS)
    try:
        with urlopen(request, timeout=timeout_seconds) as response:
            charset = response.headers.get_content_charset() or "utf-8"
            return response.read().decode(charset, errors="replace")
    except HTTPError as exc:
        raise EpisodeFetchError(f"Episode page returned HTTP {exc.code}") from exc
    except URLError as exc:
        raise EpisodeFetchError(f"Failed to fetch episode page: {exc.reason}") from exc
    except TimeoutError as exc:
        raise EpisodeFetchError("Episode page request timed out") from exc


def normalize_dailymotion_url(url: str) -> str:
    normalized = html.unescape(url).strip()
    video_id = _extract_video_id_from_dailymotion_url(normalized)
    if video_id:
        return f"https://geo.dailymotion.com/player.html?video={video_id}"
    return normalized


def extract_dailymotion_urls(page_html: str) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []

    for match in DM_URL_PATTERN.finditer(page_html or ""):
        url = normalize_dailymotion_url(match.group(0))
        if url not in seen:
            seen.add(url)
            ordered.append(url)

    return ordered


def extract_primary_dailymotion_url(page_html: str) -> str:
    urls = extract_dailymotion_urls(page_html)
    if not urls:
        raise DailymotionUrlNotFoundError("No Dailymotion player URL found on the episode page")
    return urls[0]


def resolve_episode_page(episode_url: str, timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS) -> str:
    html_content = fetch_episode_html(episode_url, timeout_seconds=timeout_seconds)
    return extract_primary_dailymotion_url(html_content)


def resolve_input_url(input_url: str, timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS) -> str:
    if not is_http_url(input_url):
        raise InvalidEpisodeUrlError(f"Invalid URL: {input_url}")

    if is_dailymotion_url(input_url):
        normalized = normalize_dailymotion_url(input_url)
        if normalized.startswith("https://geo.dailymotion.com/player.html?video="):
            return normalized
        raise InvalidEpisodeUrlError("Unsupported Dailymotion link format")

    return resolve_episode_page(input_url, timeout_seconds=timeout_seconds)
