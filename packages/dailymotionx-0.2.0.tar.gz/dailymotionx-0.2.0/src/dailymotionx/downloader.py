from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

from .constants import RESOLUTION_CHOICES
from .errors import (
    DependencyNotFoundError,
    DownloadFailedError,
    FFmpegNotFoundError,
    InvalidResolutionError,
)
from .extractor import resolve_input_url
from .ffmpeg_utils import ffmpeg_in_path, ffmpeg_install_hint
from .models import DownloadRequest, DownloadResult

PARTIAL_FILE_PATTERNS = (
    "*.part",
    "*.part-*",
    "*.ytdl",
    "*.tmp",
    "*.temp*",
)


def _load_yt_dlp() -> tuple[Any, type[Exception]]:
    try:
        yt_dlp = importlib.import_module("yt_dlp")
        yt_dlp_utils = importlib.import_module("yt_dlp.utils")
        ytdlp_download_error = getattr(yt_dlp_utils, "DownloadError", Exception)
        return yt_dlp, ytdlp_download_error
    except ModuleNotFoundError as exc:
        raise DependencyNotFoundError(
            "Dependency not found: yt-dlp. Install with: pip install -U yt-dlp"
        ) from exc


def cleanup_incomplete_files(output_dir: Path) -> None:
    if not output_dir.exists():
        return

    for pattern in PARTIAL_FILE_PATTERNS:
        for candidate in output_dir.glob(pattern):
            try:
                candidate.unlink(missing_ok=True)
            except OSError:
                continue


def build_format_selector(resolution: str) -> str:
    if resolution not in RESOLUTION_CHOICES:
        raise InvalidResolutionError(
            f"Unsupported resolution: {resolution}. Choose one of {', '.join(RESOLUTION_CHOICES)}"
        )

    if resolution == "best":
        return "bestvideo+bestaudio/best"

    return f"bestvideo[height<={resolution}]+bestaudio/best[height<={resolution}]/best"


def build_ytdlp_options(
    request: DownloadRequest,
    progress_hooks: list[Any] | None = None,
    suppress_output: bool = False,
) -> dict[str, Any]:
    format_selector = build_format_selector(request.resolution)
    concurrency = max(1, int(request.concurrency))
    timeout_seconds = max(5, int(request.timeout_seconds))

    opts: dict[str, Any] = {
        "noplaylist": True,
        "format": format_selector,
        "merge_output_format": "mp4",
        "outtmpl": str(Path(request.output_dir) / "%(title).180B [%(id)s].%(ext)s"),
        "socket_timeout": timeout_seconds,
        "retries": 10,
        "fragment_retries": 10,
        "concurrent_fragment_downloads": concurrency,
        "restrictfilenames": True,
        "windowsfilenames": True,
        "quiet": suppress_output,
        "noprogress": suppress_output,
    }
    if progress_hooks:
        opts["progress_hooks"] = progress_hooks
    return opts


def _resolve_output_file(info: dict[str, Any], prepared_path: Path, output_dir: Path) -> Path:
    candidate_mp4 = prepared_path.with_suffix(".mp4")
    if candidate_mp4.exists():
        return candidate_mp4

    if prepared_path.exists():
        return prepared_path

    requested_downloads = info.get("requested_downloads")
    if isinstance(requested_downloads, list):
        for item in requested_downloads:
            if isinstance(item, dict):
                filepath = item.get("filepath")
                if filepath and Path(filepath).exists():
                    found = Path(filepath)
                    mp4_variant = found.with_suffix(".mp4")
                    if mp4_variant.exists():
                        return mp4_variant
                    return found

    video_id = info.get("id")
    if video_id:
        matches = sorted(
            output_dir.glob(f"*{video_id}*.mp4"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if matches:
            return matches[0]

    raise DownloadFailedError("Download completed but output file was not found")


def download_from_dailymotion_url(
    dailymotion_url: str,
    request: DownloadRequest,
    progress_hooks: list[Any] | None = None,
    suppress_output: bool = False,
) -> Path:
    if not ffmpeg_in_path():
        raise FFmpegNotFoundError(ffmpeg_install_hint())

    output_dir = Path(request.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    options = build_ytdlp_options(
        request,
        progress_hooks=progress_hooks,
        suppress_output=suppress_output,
    )
    yt_dlp, ytdlp_download_error = _load_yt_dlp()

    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(dailymotion_url, download=True)
            if not isinstance(info, dict):
                raise DownloadFailedError("Unexpected metadata returned by yt-dlp")
            prepared_filename = Path(ydl.prepare_filename(info))
    except KeyboardInterrupt:
        cleanup_incomplete_files(output_dir)
        raise
    except ytdlp_download_error as exc:
        raise DownloadFailedError(f"yt-dlp download failed: {exc}") from exc

    return _resolve_output_file(info, prepared_filename, output_dir)


def download_episode(
    request: DownloadRequest,
    progress_hooks: list[Any] | None = None,
    suppress_output: bool = False,
) -> DownloadResult:
    dailymotion_url = resolve_input_url(
        request.episode_url,
        timeout_seconds=request.timeout_seconds,
    )
    output_file = download_from_dailymotion_url(
        dailymotion_url,
        request,
        progress_hooks=progress_hooks,
        suppress_output=suppress_output,
    )

    return DownloadResult(
        episode_url=request.episode_url,
        dailymotion_url=dailymotion_url,
        resolution=request.resolution,
        output_file=output_file,
    )
