from __future__ import annotations

from dailymotionx.ffmpeg_utils import ffmpeg_install_command, ffmpeg_install_hint


def test_ffmpeg_install_command_linux() -> None:
    assert "apt" in ffmpeg_install_command("Linux")


def test_ffmpeg_install_command_windows() -> None:
    assert "winget" in ffmpeg_install_command("Windows")


def test_ffmpeg_install_command_macos() -> None:
    assert "brew" in ffmpeg_install_command("Darwin")


def test_ffmpeg_install_hint_contains_command() -> None:
    hint = ffmpeg_install_hint("Linux")
    assert "ffmpeg is required" in hint.lower()
    assert "apt" in hint
