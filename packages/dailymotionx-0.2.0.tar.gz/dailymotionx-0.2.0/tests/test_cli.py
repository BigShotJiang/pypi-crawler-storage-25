from __future__ import annotations

from argparse import Namespace
from pathlib import Path

import pytest

from dailymotionx.cli import build_request_from_args, normalize_argv
from dailymotionx.errors import InvalidEpisodeUrlError


def test_build_request_non_interactive_requires_episode_url() -> None:
    args = Namespace(
        input_url=None,
        resolution="720",
        output_dir=None,
        concurrency=8,
        timeout=35,
        non_interactive=True,
    )

    with pytest.raises(InvalidEpisodeUrlError):
        build_request_from_args(args)


def test_build_request_uses_passed_values() -> None:
    args = Namespace(
        input_url="https://example.com/episode",
        resolution="480",
        output_dir="downloads",
        concurrency=6,
        timeout=40,
        non_interactive=True,
    )

    request = build_request_from_args(args)
    assert request.episode_url == "https://example.com/episode"
    assert request.resolution == "480"
    assert request.output_dir == Path("downloads")
    assert request.concurrency == 6
    assert request.timeout_seconds == 40


def test_build_request_uses_default_output_dir_when_missing(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("dailymotionx.cli.detect_default_output_dir", lambda: tmp_path)
    args = Namespace(
        input_url="https://example.com/episode",
        resolution="720",
        output_dir=None,
        concurrency=8,
        timeout=35,
        non_interactive=True,
    )

    request = build_request_from_args(args)
    assert request.output_dir == tmp_path


def test_normalize_argv_for_direct_url() -> None:
    normalized = normalize_argv(["https://example.com/episode"])
    assert normalized[0] == "download"


def test_normalize_argv_doctor_preserved() -> None:
    normalized = normalize_argv(["doctor", "--upgrade-ytdlp"])
    assert normalized == ["doctor", "--upgrade-ytdlp"]


def test_normalize_argv_ui_preserved() -> None:
    normalized = normalize_argv(["ui", "--port", "8080"])
    assert normalized == ["ui", "--port", "8080"]


def test_normalize_argv_empty_returns_download() -> None:
    normalized = normalize_argv([])
    assert normalized == ["download"]
