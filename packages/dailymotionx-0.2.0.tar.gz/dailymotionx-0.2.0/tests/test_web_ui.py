from __future__ import annotations

import json
import threading
from urllib.request import urlopen

import pytest

from dailymotionx.web_ui import _UIServer


@pytest.fixture()
def server():
    """Start a _UIServer on a random port in a background thread."""
    srv = _UIServer(host="127.0.0.1", port=0)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield srv
    srv.shutdown()


def test_root_returns_html(server: _UIServer) -> None:
    with urlopen(f"{server.url}/") as resp:
        assert resp.status == 200
        body = resp.read().decode("utf-8")
    assert "Dailymotion Downloader" in body
    assert "<html" in body.lower()


def test_status_returns_json(server: _UIServer) -> None:
    with urlopen(f"{server.url}/status") as resp:
        assert resp.status == 200
        data = json.loads(resp.read())
    assert "ffmpeg_ok" in data
    assert "version" in data
    assert "update_available" in data


def test_download_bad_url_returns_done_error(server: _UIServer) -> None:
    from urllib.parse import urlencode

    params = urlencode({"url": "not-a-url", "resolution": "720", "concurrency": "4"})
    with urlopen(f"{server.url}/download?{params}") as resp:
        assert resp.status == 200
        raw = resp.read().decode("utf-8")
    # SSE stream must contain a done event with success=false
    assert "done" in raw
    payload_line = next(l for l in raw.splitlines() if l.startswith("data:"))
    data = json.loads(payload_line[len("data:"):].strip())
    assert data["success"] is False


def test_404_for_unknown_path(server: _UIServer) -> None:
    from urllib.error import HTTPError

    with pytest.raises(HTTPError) as exc_info:
        urlopen(f"{server.url}/nonexistent")
    assert exc_info.value.code == 404
