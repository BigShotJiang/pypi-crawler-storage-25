from __future__ import annotations

from types import SimpleNamespace

import pytest

from dailymotionx.updater import UpdateCheckResult, check_ytdlp_update, upgrade_ytdlp


# ---------------------------------------------------------------------------
# check_ytdlp_update
# ---------------------------------------------------------------------------

def test_check_ytdlp_update_detects_newer_version(monkeypatch) -> None:
    monkeypatch.setattr("dailymotionx.updater._get_installed_ytdlp_version", lambda: "2026.01.01")
    monkeypatch.setattr("dailymotionx.updater._get_latest_ytdlp_version", lambda: "2026.06.15")

    result = check_ytdlp_update()
    assert result.update_available is True
    assert result.installed == "2026.01.01"
    assert result.latest == "2026.06.15"
    assert "pip install --upgrade yt-dlp" in result.hint


def test_check_ytdlp_update_no_update_needed(monkeypatch) -> None:
    monkeypatch.setattr("dailymotionx.updater._get_installed_ytdlp_version", lambda: "2026.06.15")
    monkeypatch.setattr("dailymotionx.updater._get_latest_ytdlp_version", lambda: "2026.06.15")

    result = check_ytdlp_update()
    assert result.update_available is False
    assert result.hint == ""


def test_check_ytdlp_update_not_installed(monkeypatch) -> None:
    monkeypatch.setattr("dailymotionx.updater._get_installed_ytdlp_version", lambda: None)

    result = check_ytdlp_update()
    assert result.update_available is False
    assert result.installed == "unknown"


def test_check_ytdlp_update_network_failure(monkeypatch) -> None:
    monkeypatch.setattr("dailymotionx.updater._get_installed_ytdlp_version", lambda: "2026.01.01")
    monkeypatch.setattr("dailymotionx.updater._get_latest_ytdlp_version", lambda: None)

    result = check_ytdlp_update()
    assert result.update_available is False
    assert result.latest == "unknown"
    assert result.hint == ""


# ---------------------------------------------------------------------------
# upgrade_ytdlp (still used by doctor --upgrade-ytdlp)
# ---------------------------------------------------------------------------

def test_upgrade_ytdlp_returns_success_result(monkeypatch) -> None:
    monkeypatch.setattr(
        "dailymotionx.updater.subprocess.run",
        lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout="ok", stderr=""),
    )
    result = upgrade_ytdlp(timeout_seconds=1)
    assert result.success is True
    assert "ok" in result.message


def test_upgrade_ytdlp_returns_failure_result(monkeypatch) -> None:
    monkeypatch.setattr(
        "dailymotionx.updater.subprocess.run",
        lambda *args, **kwargs: SimpleNamespace(returncode=1, stdout="", stderr="failed"),
    )
    result = upgrade_ytdlp(timeout_seconds=1)
    assert result.success is False
    assert "failed" in result.message
