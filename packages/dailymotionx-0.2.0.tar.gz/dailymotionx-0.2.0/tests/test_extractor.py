from __future__ import annotations

import pytest

from dailymotionx.errors import DailymotionUrlNotFoundError, InvalidEpisodeUrlError
from dailymotionx.extractor import (
    extract_dailymotion_urls,
    extract_primary_dailymotion_url,
    is_dailymotion_url,
    normalize_dailymotion_url,
    resolve_input_url,
    resolve_episode_page,
)


def test_normalize_dailymotion_url_converts_embed_to_geo() -> None:
    embed = "https://www.dailymotion.com/embed/video/k4YiCNzUwtjazkFAmg2"
    normalized = normalize_dailymotion_url(embed)
    assert normalized == "https://geo.dailymotion.com/player.html?video=k4YiCNzUwtjazkFAmg2"


def test_normalize_dailymotion_url_converts_share_to_geo() -> None:
    share = "https://www.dailymotion.com/video/k4YiCNzUwtjazkFAmg2"
    normalized = normalize_dailymotion_url(share)
    assert normalized == "https://geo.dailymotion.com/player.html?video=k4YiCNzUwtjazkFAmg2"


def test_normalize_dailymotion_url_converts_shortlink_to_geo() -> None:
    short = "https://dai.ly/k4YiCNzUwtjazkFAmg2"
    normalized = normalize_dailymotion_url(short)
    assert normalized == "https://geo.dailymotion.com/player.html?video=k4YiCNzUwtjazkFAmg2"


def test_is_dailymotion_url() -> None:
    assert is_dailymotion_url("https://www.dailymotion.com/video/abc123")
    assert is_dailymotion_url("https://dai.ly/abc123")
    assert not is_dailymotion_url("https://example.com/post")


def test_extract_dailymotion_urls_unique_ordered() -> None:
    html = """
    <iframe src=\"https://www.dailymotion.com/embed/video/abc123\"></iframe>
    <iframe src=\"https://geo.dailymotion.com/player.html?video=xyz999\"></iframe>
    <iframe src=\"https://www.dailymotion.com/embed/video/abc123\"></iframe>
    """
    urls = extract_dailymotion_urls(html)
    assert urls == [
        "https://geo.dailymotion.com/player.html?video=abc123",
        "https://geo.dailymotion.com/player.html?video=xyz999",
    ]


def test_extract_primary_dailymotion_url_raises_when_missing() -> None:
    with pytest.raises(DailymotionUrlNotFoundError):
        extract_primary_dailymotion_url("<html><body>No player</body></html>")


def test_resolve_episode_page_raises_for_invalid_url() -> None:
    with pytest.raises(InvalidEpisodeUrlError):
        resolve_episode_page("not-a-url")


def test_resolve_input_url_for_direct_dailymotion_link() -> None:
    result = resolve_input_url("https://www.dailymotion.com/video/abc123")
    assert result == "https://geo.dailymotion.com/player.html?video=abc123"


def test_resolve_input_url_for_page_uses_extraction(monkeypatch) -> None:
    monkeypatch.setattr(
        "dailymotionx.extractor.fetch_episode_html",
        lambda *args, **kwargs: "<iframe src=\"https://www.dailymotion.com/embed/video/abc123\"></iframe>",
    )
    result = resolve_input_url("https://example.com/episode")
    assert result == "https://geo.dailymotion.com/player.html?video=abc123"
