from __future__ import annotations

from pathlib import Path

import pytest

from dailymotionx.downloader import (
    build_format_selector,
    build_ytdlp_options,
    cleanup_incomplete_files,
    download_episode,
    download_from_dailymotion_url,
)
from dailymotionx.errors import DependencyNotFoundError, FFmpegNotFoundError, InvalidResolutionError
from dailymotionx.models import DownloadRequest


class FakeYDL:
    def __init__(self, options: dict):
        self.options = options
        self.prepared_path: Path | None = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return None

    def extract_info(self, url: str, download: bool = True):
        assert download is True
        assert "dailymotion" in url

        title = "Sample Episode"
        video_id = "abc123"
        outtmpl = self.options["outtmpl"]
        prepared = (
            outtmpl.replace("%(title)s", title)
            .replace("%(id)s", video_id)
            .replace("%(ext)s", "webm")
        )
        self.prepared_path = Path(prepared)
        self.prepared_path.parent.mkdir(parents=True, exist_ok=True)
        self.prepared_path.with_suffix(".mp4").write_bytes(b"ok")
        return {"id": video_id, "title": title, "ext": "webm"}

    def prepare_filename(self, info: dict):
        assert self.prepared_path is not None
        return str(self.prepared_path)


def test_build_format_selector_720() -> None:
    assert build_format_selector("720") == "bestvideo[height<=720]+bestaudio/best[height<=720]/best"


def test_build_format_selector_best() -> None:
    assert build_format_selector("best") == "bestvideo+bestaudio/best"


def test_build_format_selector_invalid() -> None:
    with pytest.raises(InvalidResolutionError):
        build_format_selector("999")


def test_build_ytdlp_options_contains_expected_keys(tmp_path: Path) -> None:
    request = DownloadRequest(
        episode_url="https://example.com/episode",
        output_dir=tmp_path,
        resolution="720",
        concurrency=8,
    )
    options = build_ytdlp_options(request)
    assert options["merge_output_format"] == "mp4"
    assert options["concurrent_fragment_downloads"] == 8


def test_download_from_dailymotion_url_requires_ffmpeg(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("dailymotionx.downloader.ffmpeg_in_path", lambda: False)

    request = DownloadRequest(
        episode_url="https://example.com/episode",
        output_dir=tmp_path,
        resolution="720",
    )

    with pytest.raises(FFmpegNotFoundError):
        download_from_dailymotion_url("https://geo.dailymotion.com/player.html?video=abc123", request)


def test_download_episode_success(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "dailymotionx.downloader.resolve_input_url",
        lambda *args, **kwargs: "https://geo.dailymotion.com/player.html?video=abc123",
    )
    monkeypatch.setattr("dailymotionx.downloader.ffmpeg_in_path", lambda: True)
    monkeypatch.setattr("dailymotionx.downloader._load_yt_dlp", lambda: (type("Y", (), {"YoutubeDL": FakeYDL}), Exception))

    request = DownloadRequest(
        episode_url="https://example.com/episode",
        output_dir=tmp_path,
        resolution="720",
    )

    result = download_episode(request)
    assert result.dailymotion_url.endswith("abc123")
    assert result.output_file.exists()


def test_download_from_dailymotion_url_missing_ytdlp_dependency(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("dailymotionx.downloader.ffmpeg_in_path", lambda: True)

    def _raise_dep_error():
        raise DependencyNotFoundError("Dependency not found: yt-dlp")

    monkeypatch.setattr("dailymotionx.downloader._load_yt_dlp", _raise_dep_error)

    request = DownloadRequest(
        episode_url="https://example.com/episode",
        output_dir=tmp_path,
        resolution="720",
    )

    with pytest.raises(DependencyNotFoundError):
        download_from_dailymotion_url("https://geo.dailymotion.com/player.html?video=abc123", request)


def test_cleanup_incomplete_files_removes_partial_artifacts(tmp_path: Path) -> None:
    part_file = tmp_path / "video.part"
    ytdl_file = tmp_path / "video.ytdl"
    part_file.write_text("x")
    ytdl_file.write_text("x")

    cleanup_incomplete_files(tmp_path)

    assert not part_file.exists()
    assert not ytdl_file.exists()
