## 1. Project Setup

- [ ] 1.1 Create project structure with pyproject.toml and src/skill_manager/ directory
- [ ] 1.2 Add dependencies: sqlite-vec, openai, tiktoken, click (for CLI)
- [ ] 1.3 Create __init__.py with SkillManager and AgentSkillClient exports
- [ ] 1.4 Set up test structure with pytest

## 2. Data Models

- [ ] 2.1 Implement Skill dataclass with all fields (id, name, source, status, chunks, confidence, extracted_from, created_at)
- [ ] 2.2 Implement Chunk dataclass with all fields (id, skill_id, section, content, tokens, priority, required, dependencies)
- [ ] 2.3 Add JSON serialization/deserialization methods to Skill and Chunk

## 3. Storage Layer

- [ ] 3.1 Create SQLite schema (skills, chunks, vec_chunks, reviews tables)
- [ ] 3.2 Implement database initialization with WAL mode
- [ ] 3.3 Implement Skill CRUD operations (save_skill, load_skill, list_skills, delete_skill)
- [ ] 3.4 Implement Chunk storage with JSON dependencies
- [ ] 3.5 Implement vec_chunks integration with sqlite-vec for embeddings

## 4. Query Engine

- [ ] 4.1 Implement text embedding using OpenAI API
- [ ] 4.2 Implement ANN search with sqlite-vec MATCH
- [ ] 4.3 Implement hard dependency expansion using recursive CTE (max depth 3)
- [ ] 4.4 Implement required chunk loading for hit skills
- [ ] 4.5 Implement token budget cropping with priority ordering
- [ ] 4.6 Implement prompt assembly with XML formatting

## 5. Skill Growth (Self-Learning)

- [ ] 5.1 Implement LLM-based knowledge extraction from context
- [ ] 5.2 Implement confidence scoring (completeness, actionability, novelty)
- [ ] 5.3 Implement duplicate detection using vector similarity
- [ ] 5.4 Implement extract() method that creates draft Skills
- [ ] 5.5 Implement auto-promotion logic (usage count + confidence threshold)
- [ ] 5.6 Implement auto-archive for old drafts (30-day TTL)

## 6. Review System

- [ ] 6.1 Implement review_queue() to list pending drafts
- [ ] 6.2 Implement approve() to promote draft to canonical
- [ ] 6.3 Implement reject() to archive draft with reason
- [ ] 6.4 Implement archive() for canonical Skills
- [ ] 6.5 Add review records to reviews table

## 7. Permission System

- [ ] 7.1 Implement AgentSkillClient with restricted interface
- [ ] 7.2 Block canonical write methods in AgentSkillClient (no approve, reject, register, delete)
- [ ] 7.3 Default query to exclude drafts in AgentSkillClient
- [ ] 7.4 Implement conflict detection before auto-promotion

## 8. CLI Tool

- [ ] 8.1 Implement skill-cli list command with source/status filters
- [ ] 8.2 Implement skill-cli review-queue command
- [ ] 8.3 Implement skill-cli approve/reject commands
- [ ] 8.4 Implement skill-cli export/import commands for JSON
- [ ] 8.5 Implement skill-cli stats command

## 9. Integration Examples

- [ ] 9.1 Create example: Direct usage with Anthropic client
- [ ] 9.2 Create example: LangChain Callback Handler
- [ ] 9.3 Create example: MCP Server implementation

## 10. Testing

- [ ] 10.1 Write unit tests for Skill/Chunk data models
- [ ] 10.2 Write integration tests for storage CRUD
- [ ] 10.3 Write tests for query pipeline (ANN + deps + budget)
- [ ] 10.4 Write tests for skill growth (extract + confidence)
- [ ] 10.5 Write tests for review workflow (approve/reject)
- [ ] 10.6 Write tests for permission separation (AgentSkillClient)
- [ ] 10.7 Write tests for CLI commands

## 11. Documentation

- [ ] 11.1 Write README with quick start guide
- [ ] 11.2 Write API documentation for SkillManager class
- [ ] 11.3 Write examples for common use cases
- [ ] 11.4 Add docstrings to all public methods

## 12. Final Validation

- [ ] 12.1 Run full test suite (pytest)
- [ ] 12.2 Validate spec compliance (all scenarios pass)
- [ ] 12.3 Performance test: query 1000 chunks under 100ms
- [ ] 12.4 End-to-end test: extract → review → approve workflow
