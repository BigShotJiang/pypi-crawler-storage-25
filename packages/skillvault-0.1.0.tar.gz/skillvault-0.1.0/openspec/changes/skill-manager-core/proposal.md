## Why

Agent 系统缺乏结构化的技能管理能力。开发者通过 prompt 注入知识，但知识分散、难以复用、无法随使用自动沉淀。需要一个本地 Skill 管理系统，让 Agent 能够存储、检索、自动生长技能知识，同时保持人类对高质量技能的控制权。

## What Changes

- 构建 `skill_manager` Python 库，提供单一 `SkillManager` 类接口
- 使用 SQLite + sqlite-vec 实现本地 Skill 存储和语义检索
- 实现双轨架构：canonical（人工管理）+ draft（Agent 自生长）
- 实现 Skill 自生长机制：从对话/任务中自动提取知识
- 实现人工审核工作流：CLI 工具支持审核 draft Skill
- 实现权限分离：Agent 只能写 draft，canonical 写入权只属于人类
- 提供与 LangChain、MCP 等 Agent 系统的集成示例

## Capabilities

### New Capabilities
- `skill-storage`: Skill 和 Chunk 的存储管理，包括 CRUD、导入导出
- `skill-query`: 语义检索和上下文组装，支持 ANN + 依赖展开 + Token Budget 裁剪
- `skill-growth`: Skill 自生长，从对话/任务中提取知识生成 draft
- `skill-review`: Skill 审核工作流，人工 approve/reject draft
- `skill-permissions`: 权限分离模型，AgentSkillClient 受限访问
- `skill-cli`: 命令行工具，支持人工管理 Skill

### Modified Capabilities
- 无

## Impact

- 新增 Python 包 `skill_manager`
- 依赖：sqlite-vec, openai, tiktoken
- 无破坏性变更（新建项目）
- 提供 LangChain Callback 示例和 MCP Server 示例
