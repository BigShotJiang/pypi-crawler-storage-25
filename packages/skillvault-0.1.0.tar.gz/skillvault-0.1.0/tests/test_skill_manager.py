"""Tests for Skill Manager."""

import pytest
import tempfile
import os

from skill_manager import SkillManager, AgentSkillClient
from skill_manager.models import Skill, Chunk


class TestSkillManager:
    """Test SkillManager core functionality."""
    
    @pytest.fixture
    def manager(self):
        """Create a temporary SkillManager for testing."""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        manager = SkillManager(db_path)
        yield manager
        
        # Cleanup
        manager.close()
        os.unlink(db_path)
    
    def test_register_and_get(self, manager):
        """Test skill registration and retrieval."""
        skill = Skill(
            id="test-skill",
            name="Test Skill",
            chunks=[
                Chunk(
                    id="test-skill::main",
                    skill_id="test-skill",
                    section="Main",
                    content="This is test content",
                    tokens=10,
                )
            ]
        )
        
        skill_id = manager.register(skill, generate_embeddings=False)
        assert skill_id == "test-skill"
        
        retrieved = manager.get("test-skill")
        assert retrieved is not None
        assert retrieved.name == "Test Skill"
        assert len(retrieved.chunks) == 1
    
    def test_list_skills(self, manager):
        """Test listing skills."""
        # Create two skills
        for i in range(2):
            skill = Skill(
                id=f"skill-{i}",
                name=f"Skill {i}",
                chunks=[
                    Chunk(
                        id=f"skill-{i}::main",
                        skill_id=f"skill-{i}",
                        section="Main",
                        content=f"Content {i}",
                        tokens=5,
                    )
                ]
            )
            manager.register(skill, generate_embeddings=False)
        
        skills = manager.list()
        assert len(skills) == 2
    
    def test_filter_by_source(self, manager):
        """Test filtering skills by source."""
        # Create canonical skill
        canonical = Skill(
            id="canonical-skill",
            name="Canonical",
            source="canonical",
            chunks=[Chunk(id="c::main", skill_id="c", section="Main", content="C", tokens=1)]
        )
        manager.register(canonical, generate_embeddings=False)
        
        # Create draft skill
        draft = Skill(
            id="draft-skill",
            name="Draft",
            source="draft",
            chunks=[Chunk(id="d::main", skill_id="d", section="Main", content="D", tokens=1)]
        )
        manager.register(draft, generate_embeddings=False)
        
        canonical_list = manager.list(source="canonical")
        assert len(canonical_list) == 1
        assert canonical_list[0].id == "canonical-skill"
        
        draft_list = manager.list(source="draft")
        assert len(draft_list) == 1
        assert draft_list[0].id == "draft-skill"
    
    def test_archive_skill(self, manager):
        """Test archiving a skill."""
        skill = Skill(
            id="to-archive",
            name="To Archive",
            chunks=[Chunk(id="ta::main", skill_id="ta", section="Main", content="X", tokens=1)]
        )
        manager.register(skill, generate_embeddings=False)
        
        # Archive
        assert manager.archive("to-archive") is True
        
        # Should not appear in active list
        active = manager.list(status="active")
        assert len(active) == 0
        
        # Should appear in archived list
        archived = manager.list(status="archived")
        assert len(archived) == 1
    
    def test_export_import(self, manager):
        """Test export and import."""
        skill = Skill(
            id="export-test",
            name="Export Test",
            chunks=[Chunk(id="et::main", skill_id="et", section="Main", content="Export me", tokens=2)]
        )
        manager.register(skill, generate_embeddings=False)
        
        # Export
        with tempfile.NamedTemporaryFile(suffix='.json', delete=False, mode='w') as f:
            export_path = f.name
        
        manager.export("export-test", export_path)
        
        # Delete original
        manager.archive("export-test")
        
        # Import
        imported_id = manager.import_(export_path)
        assert imported_id == "export-test"
        
        # Cleanup
        os.unlink(export_path)
    
    def test_stats(self, manager):
        """Test statistics."""
        # Empty stats
        stats = manager.stats()
        assert stats["canonical"] == 0
        assert stats["draft"] == 0
        
        # Add skills
        manager.register(Skill(
            id="s1",
            name="S1",
            chunks=[Chunk(id="s1::main", skill_id="s1", section="Main", content="1", tokens=1)]
        ), generate_embeddings=False)
        
        stats = manager.stats()
        assert stats["canonical"] == 1
        assert stats["chunks"] == 1


class TestPermissions:
    """Test permission separation."""
    
    @pytest.fixture
    def manager(self):
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        manager = SkillManager(db_path)
        yield manager
        
        manager.close()
        os.unlink(db_path)
    
    def test_agent_client_blocks_restricted_methods(self, manager):
        """Test that AgentSkillClient blocks restricted methods."""
        agent = manager.get_agent_client()
        
        # Should raise AttributeError
        with pytest.raises(AttributeError):
            agent.approve("test")
        
        with pytest.raises(AttributeError):
            agent.reject("test")
        
        with pytest.raises(AttributeError):
            agent.register("test")
        
        with pytest.raises(AttributeError):
            agent.delete("test")
    
    def test_agent_client_query_excludes_drafts(self, manager):
        """Test that agent client defaults to excluding drafts."""
        agent = manager.get_agent_client()
        
        # Just verify it doesn't crash (we can't easily test query without embeddings)
        assert agent.query is not None


class TestReviewWorkflow:
    """Test review workflow."""
    
    @pytest.fixture
    def manager(self):
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        manager = SkillManager(db_path)
        yield manager
        
        manager.close()
        os.unlink(db_path)
    
    def test_approve_draft(self, manager):
        """Test approving a draft skill."""
        draft = Skill(
            id="draft-to-approve",
            name="Draft",
            source="draft",
            chunks=[Chunk(id="dta::main", skill_id="dta", section="Main", content="Draft", tokens=1)]
        )
        manager.register(draft, generate_embeddings=False)
        
        # Approve
        assert manager.approve("draft-to-approve") is True
        
        # Should now be canonical
        skill = manager.get("draft-to-approve")
        assert skill.source == "canonical"
    
    def test_reject_draft(self, manager):
        """Test rejecting a draft skill."""
        draft = Skill(
            id="draft-to-reject",
            name="Draft",
            source="draft",
            chunks=[Chunk(id="dtr::main", skill_id="dtr", section="Main", content="Draft", tokens=1)]
        )
        manager.register(draft, generate_embeddings=False)
        
        # Reject
        assert manager.reject("draft-to-reject", "Not useful") is True
        
        # Should be archived
        skill = manager.get("draft-to-reject")
        assert skill.status == "archived"
    
    def test_review_queue(self, manager):
        """Test review queue."""
        # Create drafts
        for i in range(3):
            draft = Skill(
                id=f"draft-{i}",
                name=f"Draft {i}",
                source="draft",
                confidence=0.5 + i * 0.2,
                chunks=[Chunk(id=f"d{i}::main", skill_id=f"d{i}", section="Main", content=f"D{i}", tokens=1)]
            )
            manager.register(draft, generate_embeddings=False)
        
        # Get queue
        queue = manager.review_queue(limit=10)
        assert len(queue) == 3
        
        # Should be sorted by confidence (highest first)
        assert queue[0].confidence >= queue[1].confidence


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
