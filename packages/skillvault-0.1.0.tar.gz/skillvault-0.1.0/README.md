# Skill Manager

Agent Skill Management System with self-growth capabilities.

## Features

- **Skill Storage**: SQLite + sqlite-vec for local storage with vector search
- **Semantic Query**: ANN retrieval + dependency expansion + token budget cropping
- **Self-Growth**: Automatically extract knowledge from conversations and tasks
- **Human-in-the-Loop**: Review queue for approving/rejecting draft skills
- **Permission Separation**: Agent code can only write drafts, humans control canonical
- **CLI Tool**: Command-line interface for skill management

## Installation

```bash
pip install skill-manager
```

## Quick Start

```python
from skill_manager import SkillManager
from skill_manager.models import Skill, Chunk

# Initialize
sm = SkillManager("skills.db")

# Register a skill
skill = Skill(
    id="frontend-react",
    name="Frontend React",
    chunks=[
        Chunk(
            id="frontend-react::hooks",
            skill_id="frontend-react",
            section="React Hooks",
            content="## useEffect\n\nUse useEffect for side effects...",
            tokens=50,
        )
    ]
)
sm.register(skill)

# Query skills
context = sm.query("React hooks best practices", budget=2000)
print(context)

# Extract knowledge from conversation
draft_id = sm.extract(messages)

# Review queue
pending = sm.review_queue()

# Approve draft
sm.approve(draft_id)
```

## CLI Usage

```bash
# List skills
skill-cli list

# Review queue
skill-cli review-queue

# Approve/reject
skill-cli approve draft::skill-id
skill-cli reject draft::skill-id --reason "Not useful"

# Export/Import
skill-cli export frontend-react > react.json
skill-cli import react.json

# Statistics
skill-cli stats
```

## Architecture

```
Agent Code (Python)
    │
    ├── query()          → Read canonical skills
    ├── extract()        → Write draft skills
    │
Human (CLI)
    │
    ├── register()       → Write canonical skills
    ├── approve()        → Promote draft → canonical
    ├── reject()         → Archive draft
    └── delete()         → Remove skill
    │
SkillManager
    │
    ├── Storage (SQLite + sqlite-vec)
    ├── Query Engine (ANN + Dependencies + Budget)
    ├── Growth Engine (LLM extraction)
    └── Review System (Approve/Reject)
```

## Development

```bash
# Install dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run CLI
skill-cli --help
```

## License

MIT
