# Skill Management Agent System — 澄清版设计

## 1. 定位

这是一个**Agent 技能基础设施**——解决 Skill 怎么存储、怎么检索、怎么注入、怎么生长。

不是 SaaS，不需要多租户。
不是框架（Framework），不需要为所有 Agent 系统做适配器。
它就像一个**可以被任何 Agent 系统 import 使用的本地库**。

---

## 2. 架构

```
Agent 系统（你的 Python 代码）
    |
    v
SkillRegistry 类（直接实例化使用）
    |
    v
sqlite 文件（skills.db）+ sqlite-vec 扩展
```

不需要事件总线，不需要存储抽象层，不需要插件系统。

---

## 3. 核心：一个类搞定

```python
from skill_manager import SkillManager

# 初始化，自动创建/加载本地 skills.db
sm = SkillManager("skills.db")

# 1. 查询技能 → 自动组装 system prompt
context = sm.query(
    text="React useEffect cleanup",
    budget=4000,           # 剩余 token 数（你自己计算）
    include_drafts=False   # 是否包含草稿区技能
)
# 返回可直接注入 LLM 的字符串

# 2. 注册技能
sm.register(Skill(id="frontend-react", ...))

# 3. 自动提取（对话结束后显式调用）
draft_id = sm.extract(dialog_history)
# 返回草稿 skill_id，或 None（如果内容不够质量）

# 4. 审核队列
pending = sm.review_queue(limit=10)  # 返回待审核的草稿列表
sm.approve(draft_id)                 # 审核通过 → 进入正式区
sm.reject(draft_id)                  # 拒绝 → 归档
```

**为什么这样足够：**
- Skill 是本地文件（`skills.db`），不需要网络请求
- 直接方法调用，没有事件订阅、没有回调注册、没有适配器
- 你自己的 Agent 代码决定什么时候 `query()` 和什么时候 `extract()`

---

## 4. 数据模型

### 4.1 Skill（顶层）

```python
@dataclass
class Skill:
    id: str                    # 唯一标识，例如 "frontend-react"
    name: str                  # 显示名称
    source: str                # "canonical"（正式）或 "draft"（草稿）
    status: str                # "active" / "archived"
    chunks: List[Chunk]        # 内容片段
    confidence: float = 1.0    # 质量置信度（草稿区才有意义）
    extracted_from: str = ""   # 原始来源（对话ID/任务ID）
    created_at: datetime
```

### 4.2 Chunk（内容片段）

```python
@dataclass
class Chunk:
    id: str                    # 例如 "frontend-react::useeffect"
    skill_id: str
    section: str               # 标题
    content: str               # Markdown 内容
    tokens: int                # 预计算的 token 数
    priority: int = 0          # 加载优先级
    required: bool = False     # 是否强制加载
    dependencies: List[str] = field(default_factory=list)  # 依赖的 chunk ID 列表
```

### 4.3 依赖关系

不单独建表，Chunk 内部用 `dependencies` 列表存储。

```python
# 表示这个 chunk 依赖另一个 chunk
chunk.dependencies = ["base::error_handling"]
# 查询命中这个 chunk 时，自动连带加载依赖
```

**关系类型只有两种：**
- **hard_dep**：必须加载（递归展开，受 max_depth 限制）
- **soft_dep**：预算充足时加载（作为候选 chunk 参与 budget 裁剪）

---

## 5. 查询流程（内部）

```python
def query(self, text: str, budget: int, include_drafts: bool = False):
    # Step 1: Embedding
    vec = self.embed(text)
    
    # Step 2: ANN 检索（sqlite-vec）
    candidates = self.db.search(vec, top_k=20)
    
    # Step 3: 展开 hard_dep（递归 CTE，最多 3 跳）
    deps = self.expand_deps(candidates)
    
    # Step 4: 加载 required chunks（命中 skill 的 required 片段）
    required = self.load_required(candidates)
    
    # Step 5: Token Budget 裁剪
    # 优先级: required(0) > hard_dep(1) > ANN(2)
    # 同优先级按相似度排序
    all_chunks = required + deps + candidates
    selected = self.apply_budget(all_chunks, budget)
    
    # Step 6: 组装 Prompt
    return self.build_prompt(selected)
```

核心算法保留，但不要暴露为独立接口。`query()` 一个方法搞定。

---

## 6. 双轨简化

**两个区域：**

| 区域 | 来源 | 质量 | 查询时是否默认加载 |
|------|------|------|------------------|
| **canonical** | 人工编写 / 审核通过 | 高 | 是 |
| **draft** | `extract()` 自动提取 | 待验证 | 否（需 `include_drafts=True`） |

**状态流转：**

```
draft（草稿） --[sm.approve()]--> canonical（正式）
draft（草稿） --[sm.reject()]--> archived（归档，不再使用）
canonical --[手动标记]--> archived（过时弃用）
```

**自动提升规则（内置）：**
- draft 被使用次数 >= 5 次且置信度 >= 0.9 → 自动提升到 canonical
- draft 超过 30 天未审核 → 自动归档

不需要 `PromotionStrategy` 接口，用户在初始化时传入一个配置字典即可覆盖默认规则：

```python
sm = SkillManager("skills.db", auto_promote={"usage": 5, "confidence": 0.9})
```

---

## 7. 自生长：显式调用

不需要事件总线。你的 Agent 代码在认为合适的时候，显式调用 `extract()`。

### 7.1 使用方式

```python
# 场景 1：对话结束后
if len(messages) >= 5:
    sm.extract(messages)  # 自动判断是否值得保存，值得则生成 draft

# 场景 2：任务成功后
if task_result.success:
    sm.extract([
        {"role": "user", "content": task_result.task},
        {"role": "assistant", "content": task_result.solution}
    ])

# 场景 3：用户纠正后
sm.extract([
    {"role": "user", "content": f"错误：{bad_output}\n正确：{correction}"}
])
```

### 7.2 内部实现

```python
def extract(self, context: Union[str, List[dict]]) -> Optional[str]:
    # 1. 调用 LLM 分析是否有可复用知识
    result = self.llm_analyze(context)
    if not result.has_knowledge:
        return None
    
    # 2. 置信度评估
    score = self.evaluate(result.content)
    if score < self.min_confidence:  # 默认 0.7
        return None
    
    # 3. 重复检测
    if self.is_duplicate(result.content):
        return None
    
    # 4. 保存为 draft
    draft = Skill(source="draft", chunks=[...], confidence=score)
    self.register(draft)
    return draft.id
```

**为什么去掉了事件系统：**
- 事件系统 = 额外复杂度（订阅、发布、队列、异步）
- Agent 代码本身就清楚"什么时候对话结束 / 任务成功"，直接调用更简单
- 如果用户想异步提取，自己包一个 `threading.Thread(target=sm.extract)` 即可

---

## 8. 与其他 Agent 系统集成

**不需要预置 Adapter。集成方式只有三种，代码模板即可：**

### 方式 1：直接使用（推荐）

```python
from skill_manager import SkillManager
import anthropic

sm = SkillManager("skills.db")
client = anthropic.Anthropic()

# 每次调用 LLM 前，查询相关 Skill
context = sm.query(user_input, budget=4000)

response = client.messages.create(
    model="claude-sonnet-4",
    system=f"You are a helpful assistant.\n\n{context}",
    messages=[{"role": "user", "content": user_input}]
)
```

### 方式 2：LangChain Callback

```python
from langchain.callbacks.base import BaseCallbackHandler

class SkillCallback(BaseCallbackHandler):
    def __init__(self, sm: SkillManager):
        self.sm = sm
    
    def on_llm_start(self, serialized, prompts, **kwargs):
        # 从 prompts 中提取用户输入
        query = prompts[-1]  # 简单示例
        # 将 Skill 追加到 system prompt
        skills = self.sm.query(query, budget=2000)
        prompts[0] += f"\n\n{skills}"
    
    def on_chain_end(self, outputs, **kwargs):
        # 任务结束，尝试提取
        self.sm.extract(outputs)
```

### 方式 3：MCP Server

```python
# 提供一个简单的 mcp_server.py 示例文件
# 暴露 query_skills / list_skills / suggest_skill 三个 tool
# 用户自己运行：python -m skill_manager.mcp_server --db skills.db
```

**为什么不内置更多 Adapter：**
- LangChain 版本迭代快，内置 Adapter 容易过时
- 代码模板足够，用户自己复制粘贴改两行即可
- 减少维护负担和依赖冲突

---

## 9. 存储设计

**默认**：SQLite + sqlite-vec（单文件 `skills.db`）

```sql
-- skills 表
CREATE TABLE skills (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    source TEXT DEFAULT 'canonical',  -- canonical / draft
    status TEXT DEFAULT 'active',     -- active / archived
    confidence REAL DEFAULT 1.0,
    extracted_from TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- chunks 表
CREATE TABLE chunks (
    id TEXT PRIMARY KEY,
    skill_id TEXT REFERENCES skills(id) ON DELETE CASCADE,
    section TEXT NOT NULL,
    content TEXT NOT NULL,
    tokens INTEGER NOT NULL,
    priority INTEGER DEFAULT 0,
    required INTEGER DEFAULT 0,
    dependencies TEXT DEFAULT '[]',   -- JSON 数组，存储依赖 chunk_id
    score REAL                        -- ANN 检索时填入的相似度
);

-- vec_chunks 虚拟表（sqlite-vec）
CREATE VIRTUAL TABLE vec_chunks USING vec0(embedding float[1536]);

-- 审核记录（可选，默认关）
CREATE TABLE reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id TEXT,
    action TEXT,       -- approve / reject
    feedback TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**为什么不去掉 SQLite：**
- 单文件、零配置、Python 标准库内置
- sqlite-vec 提供向量检索，<10 万条足够快
- 企业现有基础设施是 PostgreSQL？迁移时只需导出 JSON，在新环境重新 import

**扩展存储：**
如果有人需要 PostgreSQL，提供一个 `import_from_json()` / `export_to_json()` 即可。不需要在代码里维护多个存储驱动。

---

## 10. CLI 工具

提供一个命令行工具，用于人工管理技能：

```bash
# 列出技能
skill-cli list
skill-cli list --source draft          # 只看草稿

# 查看待审核队列
skill-cli review-queue

# 审核
skill-cli approve draft::react_hooks
skill-cli reject draft::bad_practice --reason "过时"

# 导出/导入
skill-cli export frontend-react > react.json
skill-cli import react.json

# 统计
skill-cli stats
```

不是必须组件，但方便人工管理。

---

## 11. 依赖与安装

```bash
# 基础安装（SQLite + OpenAI Embedding）
pip install skill-manager

# 如果你想用本地 Embedding 模型
pip install skill-manager[local-embed]
```

**最小依赖：**
- `sqlite-vec`（向量检索）
- `openai`（默认 Embedding）
- `tiktoken`（Token 计算）

**不需要的依赖：**
- 没有 LangChain（用户自己装）
- 没有 FastAPI（除非你要启动 MCP Server，那是可选的）
- 没有 Redis、RabbitMQ、PostgreSQL（默认 SQLite 足够）

---

## 12. 与原有设计的关系

| 原有设计 | 简化后 | 理由 |
|---------|--------|------|
| `SkillRegistry` + `QueryEngine` + `ContextAssembler` 三个 Protocol | **合并为一个 `SkillManager` 类** | 一个类足够，减少认知负担 |
| 事件总线（EventBus） + GrowthEvent | **显式调用 `sm.extract()`** | 事件系统 = 异步复杂度，Agent 代码直接调用更简单 |
| `PromotionStrategy` 接口 + 三种策略实现 | **初始化配置字典** | 不需要策略模式，99% 场景用默认规则 |
| 6 种 Adapter（LangChain/LlamaIndex/AutoGen...） | **代码模板 + MCP Server 示例** | 内置 Adapter 维护成本高，模板够用 |
| `SkillStore` / `EmbeddingProvider` Protocol | **内部实现，不暴露接口** | 用户只关心 `SkillManager`，不关心存储细节 |
| 版本管理（create_version / get_version） | **去掉** | 初期不需要，v2 再考虑 |
| 模块化 micro-packages（core/growth/review...） | **一个包，内部子模块** | 拆开增加维护成本，pip install 一个搞定 |
| `AssemblyOptions` dataclass（10+ 字段） | **`query()` 的关键词参数** | kwargs 更直观 |
| `BudgetCalculator` 工具类 | **去掉** | 用户传入剩余 token 数即可 |

---

## 13. 演进路线图

### v0.1 — 能用（2 周）
- [ ] `SkillManager` 类 + SQLite + sqlite-vec
- [ ] `query()`（ANN + 依赖展开 + Budget 裁剪）
- [ ] `register()`（从文件导入 Skill）
- [ ] CLI 工具（list / review-queue / approve / reject）

### v0.2 — 自生长（+1 周）
- [ ] `extract()`（LLM 分析 + 置信度评估 + 去重）
- [ ] 自动提升规则（使用次数 + 置信度）
- [ ] 使用统计（每个 chunk 被 query 命中次数）

### v0.3 — 集成示例（+1 周）
- [ ] MCP Server 示例代码
- [ ] LangChain Callback 模板
- [ ] 快速入门文档

### v1.0 — 稳定（+2 周）
- [ ] 完整文档
- [ ] 性能基准（1 万条 chunks 查询延迟）
- [ ] Skill 导入/导出（JSON 格式）
- [ ] 版本兼容性保证

---

## 14. 核心代码接口（完整）

```python
class SkillManager:
    def __init__(
        self,
        db_path: str = "skills.db",
        embed_model: str = "text-embedding-3-small",
        min_confidence: float = 0.7,
        auto_promote: dict = None,  # {"usage": 5, "confidence": 0.9}
    ):
        ...
    
    # ── 查询 ──
    def query(
        self,
        text: str,
        budget: int = 4000,
        include_drafts: bool = False,
        top_k: int = 20,
        score_threshold: float = 0.4,
    ) -> str:
        """查询技能，返回可直接注入 LLM 的字符串"""
        ...
    
    # ── 注册 ──
    def register(self, skill: Union[Skill, str, Path]) -> str:
        """注册技能（支持 Skill 对象 / Markdown 文件 / 文件夹）"""
        ...
    
    def get(self, skill_id: str) -> Optional[Skill]:
        ...
    
    def list(self, source: str = None, status: str = None) -> List[Skill]:
        ...
    
    # ── 自生长 ──
    def extract(
        self,
        context: Union[str, List[dict]],
        confidence_threshold: float = None,
    ) -> Optional[str]:
        """从上下文提取技能，返回 draft_id 或 None"""
        ...
    
    # ── 审核 ──
    def review_queue(self, limit: int = 10) -> List[Skill]:
        ...
    
    def approve(self, skill_id: str) -> bool:
        """批准 draft → canonical"""
        ...
    
    def reject(self, skill_id: str, reason: str = "") -> bool:
        """拒绝 draft → archived"""
        ...
    
    # ── 导入/导出 ──
    def export(self, skill_id: str, path: str) -> None:
        """导出单个技能为 JSON"""
        ...
    
    def import_(self, path: str) -> str:
        """从 JSON 导入技能"""
        ...
    
    # ── 辅助 ──
    def stats(self) -> dict:
        ...
```

---

## 15. 权限分离设计：人与 Agent 的两条路径

这是本系统的**核心约束**，必须在实现层面强制执行。

### 15.1 双轨权限模型

| 权限 | Agent（代码） | 人类（CLI/API） |
|------|--------------|----------------|
| **canonical 写入** | ❌ 禁止 | ✅ 唯一入口 |
| **canonical 读取** | ✅ `query()` | ✅ `list/get` |
| **draft 写入** | ✅ `extract()` | ✅ 手动注册（如 import JSON） |
| **draft 读取** | ✅ `query(include_drafts=True)` | ✅ `review_queue()` |
| **审核决策** | ❌ 禁止 | ✅ `approve()` / `reject()` |
| **归档/删除** | ❌ 禁止（自动规则除外） | ✅ 手动操作 |

### 15.2 为什么需要强制分离

**场景 1：Agent 自我欺骗**
```
Agent 执行错误方案 → 用户未纠正 → Agent 自己 extract() → 
错误知识进入 draft → Agent 自动 promote → 错误知识污染 canonical
```
如果没有权限分离，Agent 会不断用自己的错误输出喂养自己，形成**回声室效应**。

**场景 2：人类知识被覆盖**
```
人工编写的 canonical Skill（最佳实践）→ Agent extract() 了一个过时的做法 →
Agent 自动覆盖 canonical → 生产环境开始使用错误方案
```

### 15.3 实现方式

**代码层面**：通过两个类分离权限。

```python
class SkillManager:
    """完整权限，供人类/管理员使用"""
    def query(self, ...): ...
    def extract(self, ...): ...
    def approve(self, skill_id: str) -> bool: ...      # 仅人类
    def reject(self, skill_id: str) -> bool: ...       # 仅人类
    def register(self, skill: Skill) -> str: ...       # 写入 canonical，仅人类
    def delete(self, skill_id: str) -> bool: ...       # 仅人类

class AgentSkillClient:
    """受限权限，供 Agent 代码使用"""
    def __init__(self, manager: SkillManager):
        self._manager = manager
    
    def query(self, *args, **kwargs):
        """只能读取，默认不包含 drafts"""
        return self._manager.query(*args, include_drafts=False, **kwargs)
    
    def extract(self, context, confidence_threshold=None):
        """只能写 draft，不能写 canonical"""
        if confidence_threshold is None:
            confidence_threshold = self._manager.min_confidence
        return self._manager.extract(context, confidence_threshold)
    
    # 明确缺失的方法：没有 approve(), reject(), register(), delete()
```

**使用方式**：
```python
# Agent 初始化时只获得受限客户端
sm = SkillManager("skills.db")
agent_client = AgentSkillClient(sm)

# Agent 运行时
context = agent_client.query(user_input, budget=4000)   # 只能读 canonical
draft_id = agent_client.extract(dialog_history)          # 只能写 draft
# agent_client.approve(draft_id)                        # ❌ AttributeError
```

### 15.4 自动提升规则的安全边界

内置的 `auto_promote` 规则（使用 ≥5 次 + 置信度 ≥0.9）看起来像是"Agent 自己审核"，但实现上必须：

1. **触发者是系统定时任务**，不是 Agent
2. **只提升 draft → canonical**，不涉及覆盖已有 canonical
3. **提升前检查冲突**：如果 canonical 已存在相似内容，强制进入人工审核

```python
# 自动提升的安全实现
def _auto_promote(self, draft_id: str):
    draft = self.get(draft_id)
    
    # 检查是否满足条件
    if draft.usage_count < 5 or draft.confidence < 0.9:
        return False
    
    # 检查是否与 canonical 冲突
    similar = self.find_similar_in_canonical(draft)
    if similar:
        # 有冲突，标记为 "needs_review"，不自动提升
        self._mark_for_review(draft_id, reason="conflict_with_canonical")
        return False
    
    # 无冲突，安全提升
    self._promote_to_canonical(draft_id)
    return True
```

### 15.5 两条交互路径的流程图

```
路径 A：Agent 交互（受限）
─────────────────────────────
Agent 代码
    │
    ├── query(text, budget) ──► 只查 canonical ──► 返回 prompt
    │
    └── extract(context) ─────► 写入 draft ───────► 返回 draft_id
                               （触发审核队列）

路径 B：人类交互（完整）
─────────────────────────────
人类
    │
    ├── 编写 Skill ───────────► register(skill) ──► 写入 canonical
    │
    ├── review-queue ─────────► list drafts
    │
    ├── approve(draft_id) ────► draft → canonical
    │
    ├── reject(draft_id) ─────► draft → archived
    │
    └── delete(skill_id) ─────► 标记 archived
```

---

**总设计原则**：
1. **一个类搞定**：`SkillManager`，20 个方法以内
2. **直接调用**：没有事件、没有订阅、没有回调
3. **显式优于隐式**：`extract()` 由调用方显式调用，不自动触发
4. **默认 SQLite**：不抽象存储，除非有人真的需要 PostgreSQL
5. **模板而非内置 Adapter**：给代码示例，不维护 LangChain 依赖
6. **JSON 交换格式**：Skill 导出为 JSON，方便迁移和版本控制
7. **权限强制分离**：Agent 只能写 draft，canonical 的写入权只属于人类

**文档版本**: v1.1 (Final)
**最后更新**: 2026-04-18
