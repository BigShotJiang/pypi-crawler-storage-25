"""Permission system for separating agent and human access."""

from typing import Optional, List

from .models import Skill
from .query import QueryEngine
from .growth import GrowthEngine


class AgentSkillClient:
    """Restricted client for agent code - can only read canonical and write drafts."""
    
    def __init__(self, query_engine: QueryEngine, growth_engine: GrowthEngine):
        self._query = query_engine
        self._growth = growth_engine
    
    def query(self, text: str, budget: int = 4000, 
              top_k: int = 20, score_threshold: float = 0.4) -> str:
        """Query skills - defaults to canonical only."""
        return self._query.query(
            text=text,
            budget=budget,
            include_drafts=False,  # Force False
            top_k=top_k,
            score_threshold=score_threshold
        )
    
    def extract(self, context, confidence_threshold: Optional[float] = None) -> Optional[str]:
        """Extract knowledge - creates draft only."""
        return self._growth.extract(context, confidence_threshold)
    
    # Explicitly NOT providing: approve, reject, register, delete
    # These will raise AttributeError if called
    
    def __getattr__(self, name):
        """Prevent access to restricted methods."""
        restricted = ['approve', 'reject', 'register', 'delete', 'archive']
        if name in restricted:
            raise AttributeError(
                f"'{self.__class__.__name__}' object has no attribute '{name}'. "
                f"Use SkillManager for human operations."
            )
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
