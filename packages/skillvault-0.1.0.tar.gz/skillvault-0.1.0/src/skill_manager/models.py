"""Data models for Skill Manager."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional
import json


@dataclass
class Chunk:
    """A content fragment within a Skill."""
    
    id: str
    skill_id: str
    section: str
    content: str
    tokens: int
    priority: int = 0
    required: bool = False
    dependencies: List[str] = field(default_factory=list)
    score: float = 0.0  # ANN similarity score, set during query
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "skill_id": self.skill_id,
            "section": self.section,
            "content": self.content,
            "tokens": self.tokens,
            "priority": self.priority,
            "required": self.required,
            "dependencies": self.dependencies,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Chunk":
        return cls(
            id=data["id"],
            skill_id=data["skill_id"],
            section=data["section"],
            content=data["content"],
            tokens=data["tokens"],
            priority=data.get("priority", 0),
            required=data.get("required", False),
            dependencies=data.get("dependencies", []),
        )


@dataclass 
class Skill:
    """A reusable knowledge unit."""
    
    id: str
    name: str
    source: str = "canonical"  # "canonical" or "draft"
    status: str = "active"     # "active" or "archived"
    chunks: List[Chunk] = field(default_factory=list)
    confidence: float = 1.0
    extracted_from: str = ""
    created_at: Optional[datetime] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "source": self.source,
            "status": self.status,
            "chunks": [c.to_dict() for c in self.chunks],
            "confidence": self.confidence,
            "extracted_from": self.extracted_from,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Skill":
        chunks = [Chunk.from_dict(c) for c in data.get("chunks", [])]
        created_at = None
        if data.get("created_at"):
            created_at = datetime.fromisoformat(data["created_at"])
        
        return cls(
            id=data["id"],
            name=data.get("name", data["id"]),
            source=data.get("source", "canonical"),
            status=data.get("status", "active"),
            chunks=chunks,
            confidence=data.get("confidence", 1.0),
            extracted_from=data.get("extracted_from", ""),
            created_at=created_at,
        )
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> "Skill":
        return cls.from_dict(json.loads(json_str))
