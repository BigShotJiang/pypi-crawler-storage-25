"""Command-line interface for skill management."""

import click
from pathlib import Path

from .manager import SkillManager


@click.group()
@click.option('--db', default='skills.db', help='Database path')
@click.pass_context
def cli(ctx, db):
    """Skill Manager CLI."""
    ctx.ensure_object(dict)
    ctx.obj['manager'] = SkillManager(db)


@cli.command()
@click.option('--source', type=click.Choice(['canonical', 'draft']), help='Filter by source')
@click.option('--status', type=click.Choice(['active', 'archived']), help='Filter by status')
@click.pass_context
def list(ctx, source, status):
    """List skills."""
    manager = ctx.obj['manager']
    skills = manager.list(source=source, status=status)
    
    if not skills:
        click.echo("No skills found.")
        return
    
    click.echo(f"{'ID':<30} {'Name':<25} {'Source':<12} {'Status':<10} {'Chunks':<8}")
    click.echo("-" * 85)
    
    for skill in skills:
        chunk_count = len(skill.chunks)
        click.echo(
            f"{skill.id:<30} {skill.name:<25} {skill.source:<12} "
            f"{skill.status:<10} {chunk_count:<8}"
        )


@cli.command(name='review-queue')
@click.option('--limit', default=10, help='Maximum number to show')
@click.pass_context
def review_queue(ctx, limit):
    """Show pending review queue."""
    manager = ctx.obj['manager']
    drafts = manager.review_queue(limit=limit)
    
    if not drafts:
        click.echo("No pending drafts.")
        return
    
    click.echo(f"\n📋 Pending Review Queue (Top {limit})\n")
    
    for i, draft in enumerate(drafts, 1):
        click.echo(f"[{i}] {draft.name}")
        click.echo(f"    ID: {draft.id}")
        click.echo(f"    Confidence: {draft.confidence:.2f}")
        click.echo(f"    Source: {draft.extracted_from or 'N/A'}")
        if draft.chunks:
            preview = draft.chunks[0].content[:100].replace('\n', ' ')
            click.echo(f"    Preview: {preview}...")
        click.echo()


@cli.command()
@click.argument('skill_id')
@click.pass_context
def approve(ctx, skill_id):
    """Approve a draft skill."""
    manager = ctx.obj['manager']
    
    if manager.approve(skill_id):
        click.echo(f"✅ Approved: {skill_id}")
    else:
        click.echo(f"❌ Failed to approve: {skill_id}")


@cli.command()
@click.argument('skill_id')
@click.option('--reason', default='', help='Rejection reason')
@click.pass_context
def reject(ctx, skill_id, reason):
    """Reject a draft skill."""
    manager = ctx.obj['manager']
    
    if manager.reject(skill_id, reason):
        click.echo(f"🗑️  Rejected: {skill_id}")
        if reason:
            click.echo(f"   Reason: {reason}")
    else:
        click.echo(f"❌ Failed to reject: {skill_id}")


@cli.command()
@click.argument('skill_id')
@click.argument('output_path')
@click.pass_context
def export(ctx, skill_id, output_path):
    """Export a skill to JSON file."""
    manager = ctx.obj['manager']
    
    try:
        manager.export(skill_id, output_path)
        click.echo(f"📦 Exported: {skill_id} → {output_path}")
    except Exception as e:
        click.echo(f"❌ Export failed: {e}")


@cli.command()
@click.argument('input_path')
@click.pass_context
def import_(ctx, input_path):
    """Import a skill from JSON file."""
    manager = ctx.obj['manager']
    
    try:
        skill_id = manager.import_(input_path)
        click.echo(f"📥 Imported: {skill_id}")
    except Exception as e:
        click.echo(f"❌ Import failed: {e}")


@cli.command()
@click.pass_context
def stats(ctx):
    """Show usage statistics."""
    manager = ctx.obj['manager']
    s = manager.stats()
    
    click.echo("\n📊 Skill Statistics\n")
    click.echo(f"  Canonical:   {s['canonical']}")
    click.echo(f"  Draft:       {s['draft']}")
    click.echo(f"  Archived:    {s['archived']}")
    click.echo(f"  Chunks:      {s['chunks']}")
    click.echo(f"  Pending Review: {s['pending_review']}")


def main():
    """Entry point for CLI."""
    cli()


if __name__ == '__main__':
    main()
