"""Skill growth engine for automatic knowledge extraction."""

import json
from typing import List, Optional, Union
from openai import OpenAI

from .models import Skill, Chunk
from .storage import SkillStorage


class GrowthEngine:
    """Extract knowledge from context to create draft skills."""
    
    def __init__(self, storage: SkillStorage, 
                 min_confidence: float = 0.7,
                 embed_model: str = "text-embedding-3-small"):
        self.storage = storage
        self.min_confidence = min_confidence
        self.embed_model = embed_model
        self.client = None
    
    def _get_client(self):
        """Lazy initialization of OpenAI client."""
        if self.client is None:
            self.client = OpenAI()
        return self.client
    
    def extract(self, context: Union[str, List[dict]], 
                confidence_threshold: Optional[float] = None) -> Optional[str]:
        """Extract skill from context. Returns draft_id or None."""
        threshold = confidence_threshold or self.min_confidence
        
        # Format context
        if isinstance(context, list):
            context_text = self._format_dialog(context)
        else:
            context_text = context
        
        # Step 1: Analyze with LLM
        analysis = self._analyze_content(context_text)
        if not analysis.get("has_knowledge", False):
            return None
        
        # Step 2: Evaluate confidence
        score = self._evaluate_confidence(analysis)
        if score < threshold:
            return None
        
        # Step 3: Check for duplicates
        if self._is_duplicate(analysis.get("content", "")):
            return None
        
        # Step 4: Create draft skill
        draft = self._create_draft(analysis, score, context_text)
        self.storage.save_skill(draft)
        
        # Save embedding for chunks
        for chunk in draft.chunks:
            embedding = self._embed(chunk.content)
            self.storage.save_embedding(chunk.id, embedding)
        
        return draft.id
    
    def _format_dialog(self, messages: List[dict]) -> str:
        """Format dialog messages to text."""
        lines = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            lines.append(f"{role}: {content}")
        return "\n".join(lines)
    
    def _analyze_content(self, text: str) -> dict:
        """Use LLM to analyze if content contains reusable knowledge."""
        prompt = f"""Analyze the following content and determine if it contains reusable knowledge that should be saved as a skill.

Content:
{text}

Respond in JSON format:
{{
    "has_knowledge": true/false,
    "title": "Short descriptive title",
    "content": "The knowledge content in markdown format",
    "reasoning": "Why this is reusable knowledge"
}}

Criteria for has_knowledge:
- Contains specific solutions or patterns
- Includes best practices or guidelines
- Has code examples or step-by-step instructions
- Represents knowledge that would be useful in future similar tasks"""
        
        try:
            client = self._get_client()
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
            )
            
            content = response.choices[0].message.content
            # Extract JSON from response
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]
            
            return json.loads(content.strip())
        except Exception:
            return {"has_knowledge": False}
    
    def _evaluate_confidence(self, analysis: dict) -> float:
        """Evaluate confidence score of extracted knowledge."""
        content = analysis.get("content", "")
        
        scores = []
        
        # Completeness: length and structure
        if len(content) > 200:
            scores.append(0.3)
        elif len(content) > 100:
            scores.append(0.2)
        else:
            scores.append(0.1)
        
        # Has code examples
        if "```" in content:
            scores.append(0.3)
        
        # Has step-by-step instructions
        if any(marker in content for marker in ["1.", "2.", "Step", "步骤"]):
            scores.append(0.2)
        
        # Has markdown headers
        if "##" in content or "###" in content:
            scores.append(0.2)
        
        return min(sum(scores), 1.0)
    
    def _is_duplicate(self, content: str) -> bool:
        """Check if content is duplicate of existing chunks."""
        # Simple check: search for similar content
        try:
            embedding = self._embed(content)
            results = self.storage.search_similar(embedding, top_k=1, score_threshold=0.2)
            return len(results) > 0
        except Exception:
            return False
    
    def _create_draft(self, analysis: dict, confidence: float, 
                     source_text: str) -> Skill:
        """Create a draft skill from analysis."""
        import hashlib
        
        # Generate ID
        title = analysis.get("title", "Extracted Skill")
        skill_id = f"draft::{hashlib.md5(title.encode()).hexdigest()[:8]}"
        
        # Create chunk
        chunk = Chunk(
            id=f"{skill_id}::main",
            skill_id=skill_id,
            section=title,
            content=analysis.get("content", ""),
            tokens=len(analysis.get("content", "")) // 4,  # Rough estimate
            priority=0,
        )
        
        return Skill(
            id=skill_id,
            name=title,
            source="draft",
            status="active",
            chunks=[chunk],
            confidence=confidence,
            extracted_from=source_text[:100],  # Truncate for storage
        )
    
    def _embed(self, text: str) -> List[float]:
        """Create embedding for text."""
        client = self._get_client()
        response = client.embeddings.create(
            model=self.embed_model,
            input=[text]
        )
        return response.data[0].embedding
    
    def check_auto_promote(self, skill_id: str, 
                          usage_threshold: int = 5,
                          confidence_threshold: float = 0.9) -> bool:
        """Check if draft should be auto-promoted to canonical."""
        skill = self.storage.load_skill(skill_id)
        if not skill or skill.source != "draft":
            return False
        
        stats = self.storage.get_usage_stats(skill_id)
        
        # Check thresholds
        if stats["query_count"] >= usage_threshold and skill.confidence >= confidence_threshold:
            # Check for conflicts
            if not self._has_conflict(skill):
                self._promote_to_canonical(skill_id)
                return True
        
        return False
    
    def _has_conflict(self, skill: Skill) -> bool:
        """Check if skill conflicts with existing canonical skills."""
        # Simple check: search for similar canonical content
        for chunk in skill.chunks:
            try:
                embedding = self._embed(chunk.content)
                results = self.storage.search_similar(embedding, top_k=1, score_threshold=0.15)
                
                for result in results:
                    # Check if result is canonical
                    row = self.storage.conn.execute(
                        "SELECT source FROM skills WHERE id = ?",
                        (result["skill_id"],)
                    ).fetchone()
                    
                    if row and row["source"] == "canonical":
                        return True
            except Exception:
                pass
        
        return False
    
    def _promote_to_canonical(self, skill_id: str) -> None:
        """Promote draft to canonical."""
        self.storage.conn.execute(
            "UPDATE skills SET source = 'canonical' WHERE id = ?",
            (skill_id,)
        )
        self.storage.conn.commit()
    
    def archive_old_drafts(self, ttl_days: int = 30) -> int:
        """Archive drafts older than TTL. Returns count archived."""
        cursor = self.storage.conn.execute("""
            UPDATE skills 
            SET status = 'archived'
            WHERE source = 'draft' 
              AND status = 'active'
              AND created_at < datetime('now', ?)
        """, (f'-{ttl_days} days',))
        
        self.storage.conn.commit()
        return cursor.rowcount
