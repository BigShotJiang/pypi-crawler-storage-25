"""Main SkillManager class - unified interface."""

from pathlib import Path
from typing import List, Optional, Union

from .models import Skill, Chunk
from .storage import SkillStorage
from .query import QueryEngine
from .growth import GrowthEngine
from .review import ReviewSystem
from .permissions import AgentSkillClient


class SkillManager:
    """Unified skill management interface."""
    
    def __init__(self, db_path: str = "skills.db",
                 embed_model: str = "text-embedding-3-small",
                 min_confidence: float = 0.7,
                 auto_promote: dict = None):
        self.storage = SkillStorage(db_path)
        self.query_engine = QueryEngine(self.storage, embed_model)
        self.growth_engine = GrowthEngine(self.storage, min_confidence, embed_model)
        self.review_system = ReviewSystem(self.storage)
        self.auto_promote = auto_promote or {"usage": 5, "confidence": 0.9}
    
    # ── Query ──
    def query(self, text: str, budget: int = 4000,
              include_drafts: bool = False, top_k: int = 20,
              score_threshold: float = 0.4) -> str:
        """Query skills and return formatted context."""
        return self.query_engine.query(
            text, budget, include_drafts, top_k, score_threshold
        )
    
    # ── Registration ──
    def register(self, skill: Union[Skill, str, Path], generate_embeddings: bool = True) -> str:
        """Register a skill (object, JSON string, or file path)."""
        if isinstance(skill, (str, Path)):
            path = Path(skill)
            if path.suffix == '.json':
                skill = Skill.from_json(path.read_text())
            else:
                # Assume it's a directory with SKILL.md
                skill = self._load_from_directory(path)
        
        # Save skill
        self.storage.save_skill(skill)
        
        # Save embeddings for chunks (optional, for testing)
        if generate_embeddings:
            for chunk in skill.chunks:
                embedding = self.query_engine.embed(chunk.content)
                self.storage.save_embedding(chunk.id, embedding)
        
        return skill.id
    
    def _load_from_directory(self, path: Path) -> Skill:
        """Load skill from directory containing SKILL.md."""
        md_file = path / "SKILL.md"
        if not md_file.exists():
            raise ValueError(f"No SKILL.md found in {path}")
        
        # Parse markdown (simplified)
        content = md_file.read_text()
        # TODO: Implement proper markdown parsing
        skill_id = path.name
        
        chunk = Chunk(
            id=f"{skill_id}::main",
            skill_id=skill_id,
            section=skill_id,
            content=content,
            tokens=len(content) // 4,
        )
        
        return Skill(id=skill_id, name=skill_id, chunks=[chunk])
    
    def get(self, skill_id: str) -> Optional[Skill]:
        """Get a skill by ID."""
        return self.storage.load_skill(skill_id)
    
    def list(self, source: str = None, status: str = None) -> List[Skill]:
        """List skills with optional filtering."""
        return self.storage.list_skills(source, status)
    
    # ── Growth ──
    def extract(self, context: Union[str, List[dict]],
                confidence_threshold: float = None) -> Optional[str]:
        """Extract knowledge from context, create draft."""
        draft_id = self.growth_engine.extract(context, confidence_threshold)
        
        # Check auto-promotion
        if draft_id:
            self.growth_engine.check_auto_promote(
                draft_id,
                self.auto_promote.get("usage", 5),
                self.auto_promote.get("confidence", 0.9)
            )
        
        return draft_id
    
    # ── Review ──
    def review_queue(self, limit: int = 10) -> List[Skill]:
        """Get pending drafts for review."""
        return self.review_system.review_queue(limit)
    
    def approve(self, skill_id: str) -> bool:
        """Approve draft → canonical."""
        return self.review_system.approve(skill_id)
    
    def reject(self, skill_id: str, reason: str = "") -> bool:
        """Reject draft → archived."""
        return self.review_system.reject(skill_id, reason)
    
    def archive(self, skill_id: str) -> bool:
        """Archive a skill."""
        return self.review_system.archive(skill_id)
    
    # ── Import/Export ──
    def export(self, skill_id: str, path: str) -> None:
        """Export skill to JSON file."""
        skill = self.get(skill_id)
        if not skill:
            raise ValueError(f"Skill not found: {skill_id}")
        
        Path(path).write_text(skill.to_json(), encoding="utf-8")
    
    def import_(self, path: str) -> str:
        """Import skill from JSON file."""
        json_text = Path(path).read_text(encoding="utf-8")
        skill = Skill.from_json(json_text)
        return self.register(skill)
    
    # ── Stats ──
    def stats(self) -> dict:
        """Get usage statistics."""
        cursor = self.storage.conn
        
        canonical = cursor.execute(
            "SELECT COUNT(*) FROM skills WHERE source = 'canonical' AND status = 'active'"
        ).fetchone()[0]
        
        draft = cursor.execute(
            "SELECT COUNT(*) FROM skills WHERE source = 'draft' AND status = 'active'"
        ).fetchone()[0]
        
        archived = cursor.execute(
            "SELECT COUNT(*) FROM skills WHERE status = 'archived'"
        ).fetchone()[0]
        
        chunks = cursor.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        
        pending_review = cursor.execute(
            "SELECT COUNT(*) FROM skills WHERE source = 'draft' AND status = 'active'"
        ).fetchone()[0]
        
        return {
            "canonical": canonical,
            "draft": draft,
            "archived": archived,
            "chunks": chunks,
            "pending_review": pending_review,
        }
    
    # ── Agent Client ──
    def get_agent_client(self) -> AgentSkillClient:
        """Get restricted client for agent code."""
        return AgentSkillClient(self.query_engine, self.growth_engine)
    
    def close(self):
        """Close resources."""
        self.storage.close()
