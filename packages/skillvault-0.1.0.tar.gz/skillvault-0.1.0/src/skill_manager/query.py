"""Query engine for skill retrieval and context assembly."""

from typing import List, Optional
from openai import OpenAI
import tiktoken

from .models import Chunk
from .storage import SkillStorage


class QueryEngine:
    """Semantic search and context assembly."""
    
    def __init__(self, storage: SkillStorage, embed_model: str = "text-embedding-3-small"):
        self.storage = storage
        self.embed_model = embed_model
        self.client = None
        self.encoder = tiktoken.encoding_for_model("gpt-4")
    
    def _get_client(self):
        """Lazy initialization of OpenAI client."""
        if self.client is None:
            self.client = OpenAI()
        return self.client
    
    def embed(self, text: str) -> List[float]:
        """Create embedding for text."""
        client = self._get_client()
        response = client.embeddings.create(
            model=self.embed_model,
            input=[text]
        )
        return response.data[0].embedding
    
    def query(self, text: str, budget: int = 4000, 
              include_drafts: bool = False,
              top_k: int = 20,
              score_threshold: float = 0.4) -> str:
        """Query skills and assemble context prompt."""
        # Step 1: Embedding
        query_vec = self.embed(text)
        
        # Step 2: ANN Search
        candidates = self.storage.search_similar(
            query_vec, top_k=top_k, score_threshold=score_threshold
        )
        
        # Filter drafts if needed
        if not include_drafts:
            candidates = self._filter_canonical(candidates)
        
        # Step 3: Expand dependencies
        candidate_ids = [c["id"] for c in candidates]
        deps = self.storage.expand_dependencies(candidate_ids, max_depth=3)
        
        # Step 4: Load required chunks
        hit_skill_ids = list(set(c["skill_id"] for c in candidates))
        required = self.storage.load_required_chunks(hit_skill_ids)
        
        # Step 5: Token budget cropping
        all_chunks = self._merge_chunks(required, deps, candidates)
        selected = self._apply_budget(all_chunks, budget)
        
        # Step 6: Build prompt
        return self._build_prompt(selected)
    
    def _filter_canonical(self, candidates: List[dict]) -> List[dict]:
        """Filter out draft skills."""
        # Get skill sources
        skill_ids = list(set(c["skill_id"] for c in candidates))
        
        if not skill_ids:
            return candidates
        
        # Check which skills are canonical
        placeholders = ",".join("?" * len(skill_ids))
        rows = self.storage.conn.execute(
            f"SELECT id FROM skills WHERE id IN ({placeholders}) AND source = 'canonical'",
            skill_ids
        ).fetchall()
        
        canonical_ids = {r["id"] for r in rows}
        
        return [c for c in candidates if c["skill_id"] in canonical_ids]
    
    def _merge_chunks(self, required: List[dict], deps: List[dict], 
                     candidates: List[dict]) -> List[Chunk]:
        """Merge chunks from different sources."""
        chunks = []
        seen = set()
        
        # Add with source label
        for chunk_dict in required:
            if chunk_dict["id"] not in seen:
                chunks.append(self._dict_to_chunk(chunk_dict, "required"))
                seen.add(chunk_dict["id"])
        
        for chunk_dict in deps:
            if chunk_dict["id"] not in seen:
                chunks.append(self._dict_to_chunk(chunk_dict, "hard_dep"))
                seen.add(chunk_dict["id"])
        
        for chunk_dict in candidates:
            if chunk_dict["id"] not in seen:
                chunks.append(self._dict_to_chunk(chunk_dict, "vector"))
                seen.add(chunk_dict["id"])
        
        return chunks
    
    def _dict_to_chunk(self, data: dict, source: str) -> Chunk:
        """Convert dict to Chunk with source."""
        import json
        
        chunk = Chunk(
            id=data["id"],
            skill_id=data["skill_id"],
            section=data["section"],
            content=data["content"],
            tokens=data["tokens"],
            priority=data.get("priority", 0),
            required=bool(data.get("required", 0)),
            dependencies=json.loads(data.get("dependencies", "[]")),
        )
        chunk.score = data.get("score", 0.0)
        return chunk
    
    def _apply_budget(self, chunks: List[Chunk], budget: int) -> List[Chunk]:
        """Apply token budget, prioritizing required > deps > vector."""
        priority_order = {"required": 0, "hard_dep": 1, "vector": 2}
        
        # Sort by priority and score
        ordered = sorted(chunks, key=lambda c: (priority_order.get(getattr(c, 'source', 'vector'), 2), c.score))
        
        seen = set()
        result = []
        remaining = budget
        
        for chunk in ordered:
            if chunk.id in seen:
                continue
            if chunk.tokens <= remaining:
                result.append(chunk)
                seen.add(chunk.id)
                remaining -= chunk.tokens
        
        return result
    
    def _build_prompt(self, chunks: List[Chunk]) -> str:
        """Build formatted prompt from chunks."""
        if not chunks:
            return ""
        
        # Group by skill
        from collections import defaultdict
        grouped = defaultdict(list)
        for chunk in chunks:
            grouped[chunk.skill_id].append(chunk)
        
        blocks = []
        for skill_id, skill_chunks in grouped.items():
            # Sort by priority within skill
            skill_chunks.sort(key=lambda c: c.priority)
            body = "\n\n".join(c.content for c in skill_chunks)
            blocks.append(f'<skill name="{skill_id}">\n{body}\n</skill>')
        
        return "\n\n".join(blocks)
    
    def count_tokens(self, text: str) -> int:
        """Count tokens in text."""
        return len(self.encoder.encode(text))
