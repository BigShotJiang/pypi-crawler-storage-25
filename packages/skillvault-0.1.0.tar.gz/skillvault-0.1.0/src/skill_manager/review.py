"""Review system for skill lifecycle management."""

from typing import List, Optional

from .models import Skill
from .storage import SkillStorage


class ReviewSystem:
    """Manage skill review workflow."""
    
    def __init__(self, storage: SkillStorage):
        self.storage = storage
    
    def review_queue(self, limit: int = 10) -> List[Skill]:
        """Get pending draft skills for review."""
        skills = self.storage.list_skills(source="draft", status="active")
        
        # Sort by confidence (highest first)
        skills.sort(key=lambda s: s.confidence, reverse=True)
        
        return skills[:limit]
    
    def approve(self, skill_id: str) -> bool:
        """Approve a draft skill, moving it to canonical."""
        skill = self.storage.load_skill(skill_id)
        if not skill:
            return False
        
        if skill.source != "draft":
            return False
        
        # Update to canonical
        self.storage.conn.execute(
            "UPDATE skills SET source = 'canonical' WHERE id = ?",
            (skill_id,)
        )
        self.storage.conn.commit()
        
        # Record review
        self.storage.record_review(skill_id, "approve")
        
        return True
    
    def reject(self, skill_id: str, reason: str = "") -> bool:
        """Reject a draft skill, archiving it."""
        skill = self.storage.load_skill(skill_id)
        if not skill:
            return False
        
        if skill.source != "draft":
            return False
        
        # Archive
        self.storage.conn.execute(
            "UPDATE skills SET status = 'archived' WHERE id = ?",
            (skill_id,)
        )
        self.storage.conn.commit()
        
        # Record review
        self.storage.record_review(skill_id, "reject", reason)
        
        return True
    
    def archive(self, skill_id: str) -> bool:
        """Archive a canonical skill."""
        skill = self.storage.load_skill(skill_id)
        if not skill:
            return False
        
        self.storage.conn.execute(
            "UPDATE skills SET status = 'archived' WHERE id = ?",
            (skill_id,)
        )
        self.storage.conn.commit()
        
        return True
    
    def get_review_history(self, skill_id: str) -> List[dict]:
        """Get review history for a skill."""
        rows = self.storage.conn.execute(
            "SELECT * FROM reviews WHERE skill_id = ? ORDER BY created_at DESC",
            (skill_id,)
        ).fetchall()
        
        return [dict(row) for row in rows]
