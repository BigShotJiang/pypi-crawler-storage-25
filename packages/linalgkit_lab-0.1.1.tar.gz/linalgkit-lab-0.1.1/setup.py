from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="linalgkit-lab",
    version="0.1.1",
    author="linalgkit contributors",
    author_email="linalgkit@example.com",
    description=(
        "A comprehensive linear algebra library: systems, vector spaces, "
        "transformations, orthogonality, eigenvalues, and canonical forms."
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/linalgkit",
    packages=find_packages(exclude=["tests*"]),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
    ],
    extras_require={
        "dev": ["pytest>=7.0", "pytest-cov"],
    },
)
