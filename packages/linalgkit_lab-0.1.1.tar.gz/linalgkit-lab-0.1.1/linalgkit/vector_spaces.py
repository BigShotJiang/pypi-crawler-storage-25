"""
Module II: Vector Spaces
Covers: subspaces, linear independence, span, basis, dimension,
        sum and intersection of subspaces, direct sum.
"""

import numpy as np
from typing import List, Tuple, Optional
from .linear_systems import reduced_row_echelon_form, row_rank, _to_float


# ───────────────────── Linear Independence ──────────────────────

def are_linearly_independent(vectors, step: bool = False):
    """
    Check if a list of vectors is linearly independent.

    Parameters
    ----------
    vectors : list of array-like (each length n)

    Returns
    -------
    bool
    """
    if not vectors:
        return {"independent": True, "rank": 0, "steps": ["No vectors were provided."]} if step else True
    A = np.array(vectors, dtype=float)          # shape (k, n)
    k = A.shape[0]
    rank_data = row_rank(A, step=step)
    rank = rank_data["rank"] if step else rank_data
    independent = rank == k
    if step:
        return {
            "independent": independent,
            "rank": rank,
            "num_vectors": k,
            "matrix": A,
            "steps": rank_data["steps"],
        }
    return independent


def find_dependent_combinations(vectors, step: bool = False) -> dict:
    """
    Detect dependencies among vectors.

    Returns
    -------
    dict:
      'independent'  : bool
      'rank'         : int
      'independent_subset' : list[int] – indices forming a basis of the span
    """
    if not vectors:
        return {'independent': True, 'rank': 0, 'independent_subset': []}
    A = np.array(vectors, dtype=float)
    data = reduced_row_echelon_form(A.T, step=step)   # columns of A = rows of A^T
    if step:
        pivot_cols = data["pivot_cols"]
    else:
        _, pivot_cols = data
    result = {
        'independent': len(pivot_cols) == len(vectors),
        'rank': len(pivot_cols),
        'independent_subset': list(pivot_cols)
    }
    if step:
        result.update({"rref": data["rref"], "steps": data["steps"]})
    return result


# ────────────────────────── Span & Basis ────────────────────────

def span_basis(vectors, step: bool = False):
    """
    Reduce a set of vectors to a basis for their span.

    Parameters
    ----------
    vectors : list of array-like

    Returns
    -------
    basis : list[np.ndarray]
    """
    if not vectors:
        return {"basis": [], "dimension": 0, "steps": ["No vectors were provided."]} if step else []
    A = np.array(vectors, dtype=float)
    data = reduced_row_echelon_form(A.T, step=step)
    if step:
        pivot_cols = data["pivot_cols"]
    else:
        _, pivot_cols = data
    basis = [A[i] for i in pivot_cols]
    if step:
        return {
            "basis": basis,
            "dimension": len(basis),
            "pivot_cols": list(pivot_cols),
            "matrix_with_vectors_as_columns": A.T,
            "rref": data["rref"],
            "steps": data["steps"],
        }
    return basis


def is_in_span(vector, spanning_set) -> bool:
    """
    Check whether `vector` lies in the span of `spanning_set`.
    """
    if not spanning_set:
        v = np.array(vector, dtype=float)
        return np.all(np.abs(v) < 1e-12)
    A = np.array(spanning_set, dtype=float).T   # n × k
    v = np.array(vector, dtype=float)
    from .linear_systems import solve_linear_system
    result = solve_linear_system(A, v)
    return result['consistent']


def coordinates_in_basis(vector, basis) -> Optional[np.ndarray]:
    """
    Express `vector` as a linear combination of `basis` vectors.

    Returns
    -------
    coords : np.ndarray | None  (None if vector not in span of basis)
    """
    A = np.array(basis, dtype=float).T
    v = np.array(vector, dtype=float)
    from .linear_systems import solve_linear_system
    result = solve_linear_system(A, v)
    if not result['consistent']:
        return None
    return result['particular']


# ─────────────────── Subspace Checks ───────────────────────────

def is_subspace(subset_vectors, ambient_dim: int) -> dict:
    """
    Check the three subspace axioms for the span of `subset_vectors`
    in R^ambient_dim.

    Verifies:
    1. Contains zero vector
    2. Closed under addition  (structural – always true for a span)
    3. Closed under scalar multiplication (structural – always true for a span)

    Returns a report dict.
    """
    # A span of vectors always forms a subspace
    basis = span_basis(subset_vectors)
    dim = len(basis)
    return {
        'is_subspace': True,
        'dimension': dim,
        'basis': basis,
        'note': "The span of any set of vectors is always a subspace."
    }


# ───────────── Sum and Intersection of Subspaces ────────────────

def subspace_sum(basis_U, basis_V) -> List[np.ndarray]:
    """
    Compute a basis for U + V  (the sum of two subspaces).

    U + V = span(basis_U ∪ basis_V)

    Parameters
    ----------
    basis_U, basis_V : lists of array-like

    Returns
    -------
    basis of U + V
    """
    combined = list(basis_U) + list(basis_V)
    return span_basis(combined)


def subspace_intersection(basis_U, basis_V) -> List[np.ndarray]:
    """
    Compute a basis for U ∩ V using the formula:
        solve: sum of U-coords = sum of V-coords  →  x in U ∩ V.

    Uses the identity: x ∈ U ∩ V  iff  x = Ua = Vb  for some a, b.
    We solve [U | -V][a; b] = 0.

    Parameters
    ----------
    basis_U, basis_V : lists of array-like (each of same ambient dim)

    Returns
    -------
    basis of U ∩ V
    """
    if not basis_U or not basis_V:
        return []
    U = np.array(basis_U, dtype=float).T   # n × p
    V = np.array(basis_V, dtype=float).T   # n × q
    n = U.shape[0]
    # Build [U | -V]
    M = np.hstack([U, -V])
    from .linear_systems import solve_homogeneous
    null = solve_homogeneous(M)['null_space_basis']
    # intersection vectors come from U * a  where [a; b] is null vector
    p = U.shape[1]
    basis_int = []
    for vec in null:
        a = vec[:p]
        x = U @ a
        if np.any(np.abs(x) > 1e-12):
            basis_int.append(x)
    return span_basis(basis_int)


def is_direct_sum(basis_U, basis_V, step: bool = False) -> dict:
    """
    Check whether U and V form a direct sum (U ∩ V = {0}).

    Returns
    -------
    dict:
      'is_direct_sum' : bool
      'intersection_basis' : list[np.ndarray]
      'dim_U', 'dim_V', 'dim_sum'
    """
    inter = subspace_intersection(basis_U, basis_V)
    direct = len(inter) == 0
    s_basis = subspace_sum(basis_U, basis_V)
    result = {
        'is_direct_sum': direct,
        'intersection_basis': inter,
        'dim_U': len(span_basis(basis_U)),
        'dim_V': len(span_basis(basis_V)),
        'dim_sum': len(s_basis),
        'sum_basis': s_basis
    }
    if step:
        result["steps"] = [
            "Find a basis for U.",
            "Find a basis for W.",
            "Solve for U intersection W using [U | -W][a;b] = 0.",
            "The sum is direct exactly when the intersection basis is empty.",
        ]
    return result


# ────────────────────── Dimension Theorem ───────────────────────

def dimension_of_span(vectors, step: bool = False):
    """Return the dimension of span(vectors)."""
    data = span_basis(vectors, step=step)
    if step:
        return data
    return len(data)


def check_linear_independence(vectors, step: bool = False):
    """Notebook-friendly alias for are_linearly_independent."""
    return are_linearly_independent(vectors, step=step)


def find_basis_and_dimension(vectors, step: bool = False) -> dict:
    """Notebook-friendly helper returning a basis for span(vectors) and its dimension."""
    data = span_basis(vectors, step=step)
    if step:
        return data
    return {"basis": data, "dimension": len(data)}


def get_basis_and_dimension(vectors, step: bool = False) -> dict:
    """Alias for find_basis_and_dimension."""
    return find_basis_and_dimension(vectors, step=step)


def check_direct_sum(U_vectors, W_vectors, ambient_dim=None, step: bool = False) -> dict:
    """Notebook-friendly alias for is_direct_sum; ambient_dim is accepted for compatibility."""
    result = is_direct_sum(U_vectors, W_vectors, step=step)
    if ambient_dim is not None:
        result["ambient_dim"] = ambient_dim
        result["spans_ambient_space"] = result["dim_sum"] == ambient_dim
    return result


def are_vectors_equal(v1, v2, tol: float = 1e-9) -> bool:
    """Return True when two vectors are equal within tolerance."""
    return bool(np.allclose(v1, v2, atol=tol))


def check_vector_space_axioms(
    sample_vectors,
    zero_vector_candidate,
    add_func,
    scalar_mult_func,
    scalar_field: str = "real",
    num_samples: int = 3,
    step: bool = False,
) -> dict:
    """
    Check vector-space axioms on representative samples and custom operations.

    This is a finite sample checker for lab/exploration work, not a formal proof
    for infinite sets.
    """
    if not sample_vectors:
        return {"is_vector_space": False, "failed_axiom": "samples", "reason": "No sample vectors provided."}

    vectors = [np.array(v) for v in sample_vectors]
    zero = np.array(zero_vector_candidate, dtype=vectors[0].dtype)
    dim = len(vectors[0])
    if scalar_field == "real":
        scalars = [float(i + 1) for i in range(num_samples)] + [0.0, 1.0, -1.0]
    elif scalar_field == "complex":
        scalars = [complex(i + 1, i) for i in range(num_samples)] + [0.0 + 0j, 1.0 + 0j, -1.0 + 0j]
    else:
        return {"is_vector_space": False, "failed_axiom": "field", "reason": "scalar_field must be 'real' or 'complex'."}

    checks = []

    def record(name, ok, detail=""):
        checks.append({"axiom": name, "passed": bool(ok), "detail": detail})
        return ok

    for u in vectors:
        for v in vectors:
            s = add_func(u, v)
            if not record("closure under addition", isinstance(s, np.ndarray) and len(s) == dim):
                return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}

    if len(vectors) >= 3:
        u, v, w = vectors[:3]
        ok = are_vectors_equal(add_func(u, add_func(v, w)), add_func(add_func(u, v), w))
        if not record("associativity of addition", ok):
            return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}

    if len(vectors) >= 2:
        u, v = vectors[:2]
        ok = are_vectors_equal(add_func(u, v), add_func(v, u))
        if not record("commutativity of addition", ok):
            return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}

    for v in vectors:
        if not record("zero vector", are_vectors_equal(add_func(v, zero), v)):
            return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}
        if not record("additive inverse", are_vectors_equal(add_func(v, scalar_mult_func(-1, v)), zero)):
            return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}

    for c in scalars:
        for v in vectors:
            s = scalar_mult_func(c, v)
            if not record("closure under scalar multiplication", isinstance(s, np.ndarray) and len(s) == dim):
                return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}

    if len(vectors) >= 2:
        c = scalars[0]
        u, v = vectors[:2]
        if not record("scalar distributivity over addition", are_vectors_equal(scalar_mult_func(c, add_func(u, v)), add_func(scalar_mult_func(c, u), scalar_mult_func(c, v)))):
            return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}

    c, d = scalars[0], scalars[1]
    u = vectors[0]
    if not record("scalar addition distributivity", are_vectors_equal(scalar_mult_func(c + d, u), add_func(scalar_mult_func(c, u), scalar_mult_func(d, u)))):
        return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}
    if not record("scalar multiplication associativity", are_vectors_equal(scalar_mult_func(c * d, u), scalar_mult_func(c, scalar_mult_func(d, u)))):
        return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}
    if not record("scalar identity", are_vectors_equal(scalar_mult_func(1, u), u)):
        return {"is_vector_space": False, "failed_axiom": checks[-1]["axiom"], "checks": checks}

    result = {"is_vector_space": True, "checks": checks}
    if step:
        result["steps"] = [f"{c['axiom']}: {'PASS' if c['passed'] else 'FAIL'}" for c in checks]
    return result


def check_norm(
    sample_vectors,
    norm_func,
    add_func=lambda u, v: np.array(u) + np.array(v),
    scalar_mult_func=lambda c, v: c * np.array(v),
    scalars=(-2, -1, 0, 1, 2),
    zero_vector=None,
    tol: float = 1e-6,
    step: bool = False,
) -> dict:
    """Check norm axioms on representative samples."""
    vectors = [np.array(v) for v in sample_vectors]
    zero = np.zeros_like(vectors[0]) if zero_vector is None and vectors else np.array(zero_vector)
    checks = []

    def fail(name):
        result = {"is_norm": False, "failed_axiom": name, "checks": checks}
        if step:
            result["steps"] = [f"{c['axiom']}: {'PASS' if c['passed'] else 'FAIL'}" for c in checks]
        return result

    for v in vectors:
        ok = norm_func(v) >= -tol
        checks.append({"axiom": "non-negativity", "passed": bool(ok)})
        if not ok:
            return fail("non-negativity")

        ok = not (abs(norm_func(v)) <= tol and not are_vectors_equal(v, zero, tol))
        checks.append({"axiom": "definiteness", "passed": bool(ok)})
        if not ok:
            return fail("definiteness")

    for c in scalars:
        for v in vectors:
            ok = abs(norm_func(scalar_mult_func(c, v)) - abs(c) * norm_func(v)) <= tol
            checks.append({"axiom": "homogeneity", "passed": bool(ok)})
            if not ok:
                return fail("homogeneity")

    for u in vectors:
        for v in vectors:
            ok = norm_func(add_func(u, v)) <= norm_func(u) + norm_func(v) + tol
            checks.append({"axiom": "triangle inequality", "passed": bool(ok)})
            if not ok:
                return fail("triangle inequality")

    result = {"is_norm": True, "message": "All checked norm axioms passed.", "checks": checks}
    if step:
        result["steps"] = [f"{c['axiom']}: PASS" for c in checks]
    return result


def extend_to_basis(vectors, ambient_dim: int) -> List[np.ndarray]:
    """
    Extend a linearly independent set to a full basis of R^ambient_dim.

    Parameters
    ----------
    vectors     : list of array-like (linearly independent)
    ambient_dim : n

    Returns
    -------
    full basis (original vectors + added standard basis vectors)
    """
    basis = span_basis(vectors)
    standard = [np.eye(ambient_dim)[i] for i in range(ambient_dim)]
    for e in standard:
        trial = basis + [e]
        if are_linearly_independent(trial):
            basis = trial
        if len(basis) == ambient_dim:
            break
    return basis
