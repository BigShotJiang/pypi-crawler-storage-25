"""
Module III: Linear Transformations
Covers: kernel, image/range, rank-nullity theorem, matrix representation,
        change of basis, isomorphism.
"""

import numpy as np
from typing import List, Optional, Callable, Tuple
from .linear_systems import (
    reduced_row_echelon_form, row_rank, solve_homogeneous,
    solve_linear_system, _to_float
)
from .vector_spaces import span_basis, are_linearly_independent, extend_to_basis


# ──────────────── Kernel (Null Space) and Image ─────────────────

def kernel(A) -> dict:
    """
    Compute the kernel (null space) of the linear map T_A: x → Ax.

    Returns
    -------
    dict:
      'basis'     : list[np.ndarray] – basis of ker(T)
      'nullity'   : int
      'is_trivial': bool
    """
    A = _to_float(A)
    result = solve_homogeneous(A)
    basis = result['null_space_basis']
    return {
        'basis': basis,
        'nullity': len(basis),
        'is_trivial': len(basis) == 0
    }


def image(A) -> dict:
    """
    Compute the image (column space / range) of T_A.

    Returns
    -------
    dict:
      'basis' : list[np.ndarray] – basis for Im(T)
      'rank'  : int
    """
    A = _to_float(A)
    _, pivot_cols = reduced_row_echelon_form(A)
    basis = [A[:, c] for c in pivot_cols]
    return {
        'basis': basis,
        'rank': len(basis)
    }


def rank_nullity(A, step: bool = False) -> dict:
    """
    Rank-Nullity theorem: rank(T) + nullity(T) = dim(domain).

    Returns
    -------
    dict:
      'rank', 'nullity', 'domain_dim', 'verified': bool
    """
    A = _to_float(A)
    m, n = A.shape
    r = row_rank(A)
    nul = n - r
    result = {
        'rank': r,
        'nullity': nul,
        'domain_dim': n,
        'codomain_dim': m,
        'verified': (r + nul == n)
    }
    if step:
        result["steps"] = [
            f"Domain dimension is the number of columns: {n}.",
            f"Rank is the number of pivot columns: {r}.",
            f"Nullity is domain_dim - rank: {n} - {r} = {nul}.",
            f"Rank + nullity = {r + nul}, so verification is {result['verified']}.",
        ]
    return result


# ──────────── Matrix of T w.r.t. Given Bases ───────────────────

def matrix_of_transformation(T_func: Callable, domain_basis, codomain_basis, step: bool = False):
    """
    Build the matrix representation [T]_{B,C} of a linear map
    T: V → W w.r.t. domain basis B and codomain basis C.

    Parameters
    ----------
    T_func        : callable – applies T to a single vector (numpy array)
    domain_basis  : list of array-like – ordered basis of V
    codomain_basis: list of array-like – ordered basis of W

    Returns
    -------
    M : np.ndarray  (len(codomain_basis) × len(domain_basis))
    """
    C = np.array(codomain_basis, dtype=float).T     # n × q
    cols = []
    steps = [] if step else None
    for b in domain_basis:
        Tb = np.array(T_func(np.array(b, dtype=float)), dtype=float)
        result = solve_linear_system(C, Tb)
        if not result['consistent']:
            raise ValueError("T(b) is not in the span of codomain_basis.")
        cols.append(result['particular'])
        if step:
            steps.append({"basis_vector": np.array(b, dtype=float), "transformed": Tb, "coordinates": result["particular"]})
    M = np.column_stack(cols)
    if step:
        return {"matrix": M, "steps": steps}
    return M


# ──────────────────── Change of Basis ───────────────────────────

def change_of_basis_matrix(old_basis, new_basis, step: bool = False):
    """
    Compute the change-of-basis matrix P from old_basis to new_basis,
    i.e. [v]_new = P [v]_old.

    Both bases must span the same space.

    Parameters
    ----------
    old_basis : list of array-like (each length n)
    new_basis : list of array-like (each length n)

    Returns
    -------
    P : np.ndarray
    """
    B_old = np.array(old_basis, dtype=float).T
    B_new = np.array(new_basis, dtype=float).T
    # P such that B_new P = B_old  →  P = B_new^{-1} B_old
    P = np.linalg.solve(B_new, B_old)
    P[np.abs(P) < 1e-12] = 0.0
    if step:
        return {
            "matrix": P,
            "old_basis_matrix": B_old,
            "new_basis_matrix": B_new,
            "steps": [
                "Put old basis vectors as columns of B_old.",
                "Put new basis vectors as columns of B_new.",
                "Solve B_new P = B_old, so P converts old coordinates to new coordinates.",
            ],
        }
    return P


def apply_linear_transformation(matrix_representation, vector, step: bool = False):
    """Apply a matrix representation of a linear transformation to a vector."""
    M = _to_float(matrix_representation)
    v = np.array(vector, dtype=float)
    transformed = M @ v
    if step:
        return {
            "transformed": transformed,
            "steps": [{"operation": "matrix-vector multiplication", "matrix": M, "vector": v, "result": transformed}],
        }
    return transformed


def get_matrix_representation(transformation_func: Callable, dim: int, step: bool = False):
    """Build the standard matrix of a transformation from images of standard basis vectors."""
    standard_basis = np.eye(dim)
    transformed = [np.array(transformation_func(e), dtype=float) for e in standard_basis]
    M = np.array(transformed).T
    if step:
        return {
            "matrix": M,
            "steps": [
                {"basis_vector": standard_basis[i], "transformed": transformed[i]}
                for i in range(dim)
            ],
        }
    return M


def change_of_basis(vector_coords_B, basis_B_vectors, basis_C_vectors, step: bool = False):
    """Convert coordinates of a vector from basis B to basis C."""
    P = change_of_basis_matrix(basis_B_vectors, basis_C_vectors, step=step)
    if step:
        coords = P["matrix"] @ np.array(vector_coords_B, dtype=float)
        return {"coordinates": coords, "change_matrix": P["matrix"], "steps": P["steps"]}
    return P @ np.array(vector_coords_B, dtype=float)


def vector_to_new_basis(vector_std, basis_new_vectors, step: bool = False):
    """Convert a standard-coordinate vector to coordinates in a new basis."""
    B = np.array(basis_new_vectors, dtype=float).T
    coords = np.linalg.solve(B, np.array(vector_std, dtype=float))
    if step:
        return {
            "coordinates": coords,
            "basis_matrix": B,
            "steps": ["Put new basis vectors as columns of B.", "Solve B [v]_B = v_standard."],
        }
    return coords


def verify_rank_nullity_theorem(matrix, step: bool = False) -> dict:
    """Notebook-friendly alias for rank_nullity."""
    return rank_nullity(matrix, step=step)


def transform_matrix_new_basis(M, old_basis, new_basis) -> np.ndarray:
    """
    Express matrix M (given in standard coordinates) in new_basis.
    Returns  P^{-1} M P  where P = [new_basis columns].

    Parameters
    ----------
    M         : array-like (n × n)
    old_basis : list of array-like  (standard basis usually)
    new_basis : list of array-like

    Returns
    -------
    M_new : np.ndarray
    """
    M = _to_float(M)
    P = np.array(new_basis, dtype=float).T
    P_inv = np.linalg.inv(P)
    M_new = P_inv @ M @ P
    M_new[np.abs(M_new) < 1e-12] = 0.0
    return M_new


# ─────────────────────── Isomorphism ────────────────────────────

def is_isomorphism(A) -> dict:
    """
    Check if the linear map T_A: R^n → R^m is an isomorphism
    (bijective ↔ square and full rank).

    Returns
    -------
    dict:
      'is_isomorphism': bool
      'is_injective'  : bool  (one-to-one)
      'is_surjective' : bool  (onto)
      'reason'        : str
    """
    A = _to_float(A)
    m, n = A.shape
    r = row_rank(A)
    injective = r == n          # trivial kernel
    surjective = r == m         # image = codomain
    iso = injective and surjective and (m == n)
    reason = []
    if not injective:
        reason.append(f"Not injective (nullity = {n - r} > 0)")
    if not surjective:
        reason.append(f"Not surjective (rank {r} < codomain dim {m})")
    if m != n:
        reason.append(f"Domain dim ({n}) ≠ codomain dim ({m})")
    return {
        'is_isomorphism': iso,
        'is_injective': injective,
        'is_surjective': surjective,
        'reason': " | ".join(reason) if reason else "Bijective – is an isomorphism"
    }


# ──────────────── Projection onto Subspace ──────────────────────

def projection_matrix(basis) -> np.ndarray:
    """
    Build the orthogonal projection matrix onto the subspace
    spanned by `basis`.

    P = A (A^T A)^{-1} A^T    (orthogonal projection)

    Parameters
    ----------
    basis : list of array-like (linearly independent)

    Returns
    -------
    P : np.ndarray
    """
    A = np.array(basis, dtype=float).T
    AtA = A.T @ A
    P = A @ np.linalg.solve(AtA, A.T)
    P[np.abs(P) < 1e-12] = 0.0
    return P
