"""
Utility functions shared across linalgkit modules.
"""

import numpy as np
from typing import List, Union


def pretty_matrix(A, decimals: int = 4, label: str = "") -> str:
    """Return a formatted string representation of a matrix."""
    A = np.array(A)
    if label:
        lines = [label]
    else:
        lines = []
    if A.ndim == 1:
        lines.append(f"  [{', '.join(f'{v:.{decimals}g}' for v in A)}]")
    else:
        for row in A:
            lines.append("  [" + "  ".join(f"{v:>{decimals+5}.{decimals}g}" for v in row) + "]")
    return "\n".join(lines)


def is_square(A) -> bool:
    A = np.array(A)
    return A.ndim == 2 and A.shape[0] == A.shape[1]


def is_zero_vector(v, tol: float = 1e-12) -> bool:
    return np.all(np.abs(np.array(v)) < tol)


def make_rational(A, max_denom: int = 100):
    """
    Try to convert float matrix entries to fractions for display.
    Returns list of lists of Fraction objects.
    """
    from fractions import Fraction
    A = np.array(A, dtype=float)
    return [[Fraction(v).limit_denominator(max_denom) for v in row] for row in A]


def random_invertible_matrix(n: int, seed: int = None) -> np.ndarray:
    """Generate a random n×n invertible matrix."""
    rng = np.random.default_rng(seed)
    while True:
        A = rng.integers(-5, 6, size=(n, n)).astype(float)
        if abs(np.linalg.det(A)) > 0.5:
            return A


def random_symmetric_matrix(n: int, seed: int = None) -> np.ndarray:
    """Generate a random n×n symmetric matrix."""
    rng = np.random.default_rng(seed)
    A = rng.integers(-5, 6, size=(n, n)).astype(float)
    return (A + A.T) / 2


def random_spd_matrix(n: int, seed: int = None) -> np.ndarray:
    """Generate a random symmetric positive-definite matrix."""
    rng = np.random.default_rng(seed)
    A = rng.standard_normal((n, n))
    return A @ A.T + n * np.eye(n)


def solve_least_squares(A, b) -> dict:
    """
    Solve the least-squares problem min ||Ax - b||.

    Returns
    -------
    dict:
      'solution'    : np.ndarray
      'residual'    : np.ndarray
      'residual_norm': float
    """
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    x, res, rank, sv = np.linalg.lstsq(A, b, rcond=None)
    residual = b - A @ x
    return {
        'solution': x,
        'residual': residual,
        'residual_norm': float(np.linalg.norm(residual)),
        'rank': int(rank)
    }
