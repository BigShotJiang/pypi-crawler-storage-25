"""
Module I: Linear Systems and Gaussian Elimination
Covers Gaussian elimination, Gauss-Jordan elimination, row echelon forms,
row rank, solution sets, and elementary matrices.
"""

import numpy as np
from typing import Optional, Tuple, List


def _to_float(A) -> np.ndarray:
    return np.array(A, dtype=float)


def _pivot_row(A: np.ndarray, col: int, start_row: int) -> int:
    """Return index of the row with the largest absolute value in column."""
    sub = np.abs(A[start_row:, col])
    return int(np.argmax(sub)) + start_row


def row_echelon_form(A, step: bool = False):
    """
    Reduce matrix A to row echelon form using partial pivoting.

    When step=True, returns a dict with the REF, pivot columns, and row-operation
    snapshots. Otherwise returns (R, pivot_cols), preserving the original API.
    """
    R = _to_float(A)
    steps = [{"operation": "start", "matrix": R.copy()}] if step else None
    m, n = R.shape
    pivot_cols = []
    row = 0

    for col in range(n):
        if row >= m:
            break
        p = _pivot_row(R, col, row)
        if abs(R[p, col]) < 1e-12:
            continue

        pivot_cols.append(col)
        R[[row, p]] = R[[p, row]]
        if step and row != p:
            steps.append({"operation": f"swap R{row + 1} <-> R{p + 1}", "matrix": R.copy()})

        for r in range(row + 1, m):
            if abs(R[r, col]) > 1e-12:
                factor = R[r, col] / R[row, col]
                R[r] -= factor * R[row]
                if step:
                    steps.append({
                        "operation": f"R{r + 1} <- R{r + 1} - ({factor}) R{row + 1}",
                        "matrix": R.copy(),
                    })
        row += 1

    R[np.abs(R) < 1e-12] = 0.0
    if step:
        steps.append({"operation": "finish REF", "matrix": R.copy(), "pivot_cols": pivot_cols.copy()})
        return {"ref": R, "pivot_cols": pivot_cols, "steps": steps}
    return R, pivot_cols


def reduced_row_echelon_form(A, step: bool = False):
    """
    Reduce matrix A to reduced row echelon form.

    When step=True, returns a dict with the RREF, pivot columns, and row-operation
    snapshots. Otherwise returns (R, pivot_cols), preserving the original API.
    """
    ref_data = row_echelon_form(A, step=step)
    if step:
        R = ref_data["ref"]
        pivot_cols = ref_data["pivot_cols"]
        steps = list(ref_data["steps"])
    else:
        R, pivot_cols = ref_data

    for idx, col in enumerate(pivot_cols):
        pivot = R[idx, col]
        if abs(pivot) < 1e-12:
            continue
        R[idx] /= pivot
        if step:
            steps.append({"operation": f"R{idx + 1} <- R{idx + 1} / {pivot}", "matrix": R.copy()})
        for r in range(idx):
            factor = R[r, col]
            if abs(factor) > 1e-12:
                R[r] -= factor * R[idx]
                if step:
                    steps.append({
                        "operation": f"R{r + 1} <- R{r + 1} - ({factor}) R{idx + 1}",
                        "matrix": R.copy(),
                    })

    R[np.abs(R) < 1e-12] = 0.0
    if step:
        steps.append({"operation": "finish RREF", "matrix": R.copy(), "pivot_cols": pivot_cols.copy()})
        return {"rref": R, "pivot_cols": pivot_cols, "steps": steps}
    return R, pivot_cols


def row_rank(A, step: bool = False):
    """Return the row rank of matrix A."""
    data = row_echelon_form(A, step=step)
    if step:
        return {"rank": len(data["pivot_cols"]), "pivot_cols": data["pivot_cols"], "steps": data["steps"]}
    _, pivot_cols = data
    return len(pivot_cols)


def gaussian_elimination(A, b, step: bool = False):
    """
    Forward Gaussian elimination on the augmented system [A | b].

    With step=False returns (A_ref, b_ref). With step=True returns a dict that
    includes the augmented REF and step snapshots.
    """
    A = _to_float(A)
    b = _to_float(b)
    if b.ndim == 1:
        b = b.reshape(-1, 1)
    Aug = np.hstack([A, b])
    n_cols_A = A.shape[1]
    data = row_echelon_form(Aug, step=step)
    if step:
        Aug_ref = data["ref"]
        return {
            "A_ref": Aug_ref[:, :n_cols_A],
            "b_ref": Aug_ref[:, n_cols_A:],
            "augmented_ref": Aug_ref,
            "pivot_cols": data["pivot_cols"],
            "steps": data["steps"],
        }
    Aug_ref, _ = data
    return Aug_ref[:, :n_cols_A], Aug_ref[:, n_cols_A:]


def gauss_jordan_elimination(A, b, step: bool = False):
    """Gauss-Jordan elimination on [A | b] to RREF."""
    A = _to_float(A)
    b = _to_float(b)
    if b.ndim == 1:
        b = b.reshape(-1, 1)
    Aug = np.hstack([A, b])
    n_cols_A = A.shape[1]
    data = reduced_row_echelon_form(Aug, step=step)
    if step:
        Aug_rref = data["rref"]
        return {
            "A_rref": Aug_rref[:, :n_cols_A],
            "b_rref": Aug_rref[:, n_cols_A:],
            "augmented_rref": Aug_rref,
            "pivot_cols": data["pivot_cols"],
            "steps": data["steps"],
        }
    Aug_rref, _ = data
    return Aug_rref[:, :n_cols_A], Aug_rref[:, n_cols_A:]


def _consistency_check(A_rref: np.ndarray, b_rref: np.ndarray) -> bool:
    """Return True if system is consistent (no zero coefficient row with nonzero RHS)."""
    for r in range(A_rref.shape[0]):
        if np.all(np.abs(A_rref[r]) < 1e-12) and np.any(np.abs(b_rref[r]) > 1e-12):
            return False
    return True


def solve_linear_system(A, b, step: bool = False) -> dict:
    """
    Solve Ax = b for inconsistent, unique, and infinite-solution cases.

    When step=True, the returned dict contains an additional 'steps' key plus
    the RREF pieces used to read off the solution.
    """
    A = _to_float(A)
    b = _to_float(b).flatten()
    m, n = A.shape
    Aug = np.hstack([A, b.reshape(-1, 1)])
    data = reduced_row_echelon_form(Aug, step=step)
    if step:
        Aug_rref = data["rref"]
        all_pivot_cols = data["pivot_cols"]
        steps = list(data["steps"])
    else:
        Aug_rref, all_pivot_cols = data
        steps = None

    A_rref = Aug_rref[:, :n]
    b_rref = Aug_rref[:, n]
    pivot_cols = [c for c in all_pivot_cols if c < n]

    if not _consistency_check(A_rref, b_rref):
        result = {
            "consistent": False,
            "unique": False,
            "particular": None,
            "null_space_basis": [],
            "solution_str": "System is INCONSISTENT - no solution exists.",
        }
        if step:
            steps.append({"operation": "detect inconsistent row", "A_rref": A_rref.copy(), "b_rref": b_rref.copy()})
            result.update({"A_rref": A_rref, "b_rref": b_rref, "steps": steps})
        return result

    particular = np.zeros(n)
    for idx, col in enumerate(pivot_cols):
        if idx < len(b_rref):
            particular[col] = b_rref[idx]

    free_cols = [c for c in range(n) if c not in pivot_cols]
    null_basis = []
    for fc in free_cols:
        vec = np.zeros(n)
        vec[fc] = 1.0
        for idx, pc in enumerate(pivot_cols):
            vec[pc] = -A_rref[idx, fc]
        null_basis.append(vec)

    unique = len(null_basis) == 0
    if unique:
        sol_str = f"Unique solution: x = {particular}"
    else:
        sol_str = f"Infinitely many solutions.\n  x = {particular} (particular)\n  + span{null_basis} (null space)"

    result = {
        "consistent": True,
        "unique": unique,
        "particular": particular,
        "null_space_basis": null_basis,
        "solution_str": sol_str,
    }
    if step:
        steps.append({
            "operation": "read solution from RREF",
            "A_rref": A_rref.copy(),
            "b_rref": b_rref.copy(),
            "pivot_cols": pivot_cols,
            "free_cols": free_cols,
        })
        result.update({"A_rref": A_rref, "b_rref": b_rref, "steps": steps})
    return result


def solve_homogeneous(A, step: bool = False) -> dict:
    """Solve the homogeneous system Ax = 0."""
    A = _to_float(A)
    b = np.zeros(A.shape[0])
    result = solve_linear_system(A, b, step=step)
    trivial = len(result["null_space_basis"]) == 0
    out = {
        "trivial_only": trivial,
        "null_space_basis": result["null_space_basis"],
        "solution_str": (
            "Only trivial solution x = 0."
            if trivial
            else f"Non-trivial solutions exist.\nNull space basis: {result['null_space_basis']}"
        ),
    }
    if step:
        out.update({"A_rref": result.get("A_rref"), "steps": result.get("steps", [])})
    return out


def elementary_matrix(n: int, operation: str, i: int, j: Optional[int] = None, scalar: Optional[float] = None) -> np.ndarray:
    """Create an n by n elementary matrix for swap, scale, or add row operations."""
    E = np.eye(n)
    op = operation.lower()
    if op == "swap":
        if j is None:
            raise ValueError("'swap' requires j")
        E[i, i] = 0
        E[j, j] = 0
        E[i, j] = 1
        E[j, i] = 1
    elif op == "scale":
        if scalar is None or scalar == 0:
            raise ValueError("'scale' requires a non-zero scalar")
        E[i, i] = scalar
    elif op == "add":
        if j is None or scalar is None:
            raise ValueError("'add' requires j and scalar")
        E[i, j] = scalar
    else:
        raise ValueError(f"Unknown operation '{operation}'. Use 'swap', 'scale', or 'add'.")
    return E


def matrix_inverse_via_gauss_jordan(A, step: bool = False):
    """Compute A inverse using Gauss-Jordan on [A | I]. Returns None if singular."""
    A = _to_float(A)
    n = A.shape[0]
    if A.shape[0] != A.shape[1]:
        raise ValueError("Matrix must be square to invert.")
    Aug = np.hstack([A, np.eye(n)])
    data = reduced_row_echelon_form(Aug, step=step)
    if step:
        Aug_rref = data["rref"]
        steps = data["steps"]
    else:
        Aug_rref, _ = data
        steps = None
    inverse = None if not np.allclose(Aug_rref[:, :n], np.eye(n), atol=1e-8) else Aug_rref[:, n:]
    if step:
        return {"inverse": inverse, "augmented_rref": Aug_rref, "steps": steps}
    return inverse


def is_consistent(A, b) -> bool:
    """Return True if Ax = b has at least one solution."""
    return solve_linear_system(A, b)["consistent"]


def null_space(A, step: bool = False):
    """Return a basis for the null space of A."""
    result = solve_homogeneous(A, step=step)
    if step:
        return {"basis": result["null_space_basis"], "A_rref": result.get("A_rref"), "steps": result.get("steps", [])}
    return result["null_space_basis"]


def solve_homogeneous_system(A, step: bool = False) -> dict:
    """Notebook-friendly alias for solve_homogeneous."""
    return solve_homogeneous(A, step=step)


def compute_rank_with_rref(A, step: bool = False) -> dict:
    """Return rank, RREF, and pivot columns using row reduction."""
    data = reduced_row_echelon_form(A, step=step)
    if step:
        return {"rank": len(data["pivot_cols"]), "rref": data["rref"], "pivot_cols": data["pivot_cols"], "steps": data["steps"]}
    rref, pivots = data
    return {"rank": len(pivots), "rref": rref, "pivot_cols": pivots}


def compute_rank_with_numpy(A, step: bool = False) -> dict:
    """Return rank from numpy.linalg.matrix_rank, with an optional step note."""
    rank = int(np.linalg.matrix_rank(_to_float(A)))
    result = {"rank": rank}
    if step:
        result["steps"] = [{"operation": "compute rank with numpy.linalg.matrix_rank", "rank": rank}]
    return result
