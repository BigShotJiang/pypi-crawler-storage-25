"""
Module VI: Canonical Forms
Covers: quadratic forms, conic sections, quadrics, bilinear forms,
        minimal polynomial, Cayley-Hamilton theorem.
"""

import numpy as np
from typing import List, Tuple, Optional, Dict
from .linear_systems import _to_float
from .eigenvalues import orthogonal_diagonalize_symmetric, eigenvalues


# ──────────────────── Bilinear Forms ────────────────────────────

def bilinear_form(A, u, v) -> float:
    """
    Evaluate the bilinear form B(u,v) = u^T A v.

    Parameters
    ----------
    A : array-like (n × n) – the form matrix
    u : array-like (n,)
    v : array-like (n,)
    """
    A = _to_float(A)
    u = np.array(u, dtype=float)
    v = np.array(v, dtype=float)
    return float(u @ A @ v)


def symmetrize_bilinear(A) -> np.ndarray:
    """
    Symmetrize a bilinear form matrix: A_sym = (A + A^T) / 2.
    Every bilinear form has a unique symmetric representation.
    """
    A = _to_float(A)
    return (A + A.T) / 2


# ─────────────────── Quadratic Forms ────────────────────────────

def quadratic_form(A, x) -> float:
    """
    Evaluate the quadratic form Q(x) = x^T A x.

    Parameters
    ----------
    A : array-like (n × n) – symmetric matrix of the form
    x : array-like (n,)
    """
    A = _to_float(A)
    x = np.array(x, dtype=float)
    A_sym = symmetrize_bilinear(A)
    return float(x @ A_sym @ x)


def quadratic_form_matrix(coeffs_2nd: List, coeffs_cross: List,
                           n: int) -> np.ndarray:
    """
    Build the symmetric matrix A for quadratic form
    Q(x) = Σ a_ii x_i² + Σ_{i<j} a_ij x_i x_j.

    Parameters
    ----------
    coeffs_2nd   : list of n coefficients [a_11, a_22, ..., a_nn]
    coeffs_cross : list of cross-term coefficients ordered as
                   [(i,j,a_ij) for i<j]
    n            : dimension

    Returns
    -------
    A : symmetric matrix
    """
    A = np.zeros((n, n))
    for i, c in enumerate(coeffs_2nd):
        A[i, i] = c
    for (i, j, c) in coeffs_cross:
        A[i, j] = c / 2
        A[j, i] = c / 2
    return A


def classify_quadratic_form(A) -> dict:
    """
    Classify a quadratic form Q(x) = x^T A x by its definiteness.

    Returns
    -------
    dict:
      'classification': str
      'eigenvalues'   : np.ndarray
      'signature'     : (pos, neg, zero) – Sylvester's law
    """
    A = _to_float(A)
    A_sym = symmetrize_bilinear(A)
    eigs = np.linalg.eigvalsh(A_sym)
    pos  = int(np.sum(eigs >  1e-10))
    neg  = int(np.sum(eigs < -1e-10))
    zero = int(np.sum(np.abs(eigs) <= 1e-10))
    n = len(eigs)
    if pos == n:
        cls = "Positive Definite"
    elif neg == n:
        cls = "Negative Definite"
    elif zero > 0 and neg == 0:
        cls = "Positive Semi-Definite"
    elif zero > 0 and pos == 0:
        cls = "Negative Semi-Definite"
    elif zero == 0:
        cls = "Indefinite"
    else:
        cls = "Indefinite (with zero eigenvalues)"
    return {
        'classification': cls,
        'eigenvalues': eigs,
        'signature': (pos, neg, zero)
    }


def diagonalize_quadratic_form(A) -> dict:
    """
    Reduce quadratic form to diagonal (principal axes) via orthogonal change.
    Q(x) = y^T D y  where x = Q y.

    Returns
    -------
    dict:
      'Q'              : np.ndarray – orthogonal change-of-variable matrix
      'D'              : np.ndarray – diagonal form matrix
      'principal_form' : str        – "λ₁y₁² + λ₂y₂² + ..."
    """
    A = _to_float(A)
    A_sym = symmetrize_bilinear(A)
    Q, D = orthogonal_diagonalize_symmetric(A_sym)
    lams = np.diag(D)
    terms = " + ".join(
        f"{lam:.4g}·y{i+1}²" for i, lam in enumerate(lams) if abs(lam) > 1e-12
    )
    return {
        'Q': Q,
        'D': D,
        'principal_form': terms or "0"
    }


# ─────────────── Conic Sections & Quadrics ──────────────────────

def classify_conic(A_2x2, b_vec=None, c_scalar: float = 0) -> dict:
    """
    Classify a conic section ax²+bxy+cy²+dx+ey+f=0.

    General form: x^T A x + b^T x + c = 0  (in homogeneous coords)

    Parameters
    ----------
    A_2x2    : 2×2 symmetric matrix [[a, b/2],[b/2, c]]
    b_vec    : array-like (2,) – linear terms [d, e]
    c_scalar : constant f

    Returns
    -------
    dict:
      'type'      : str  (Ellipse, Hyperbola, Parabola, Degenerate…)
      'discriminant': float (b²-4ac)
      'eigenvalues_of_A': np.ndarray
    """
    A = _to_float(A_2x2)
    eigs = np.linalg.eigvalsh(A)
    det_A = float(np.linalg.det(A))
    # discriminant = -4 * det(A_2x2) for x^T A x
    discrim = (A[0, 1] * 2) ** 2 - 4 * A[0, 0] * A[1, 1]  # b²-4ac

    if b_vec is not None:
        b = np.array(b_vec, dtype=float)
    else:
        b = np.zeros(2)

    if abs(discrim) < 1e-10:
        ctype = "Parabola"
    elif discrim < 0:
        if det_A > 0:
            ctype = "Ellipse (or circle)"
        else:
            ctype = "Degenerate / imaginary ellipse"
    else:
        ctype = "Hyperbola"

    return {
        'type': ctype,
        'discriminant': discrim,
        'eigenvalues_of_A': eigs,
        'note': "Set c_scalar and b_vec for the full curve equation."
    }


def classify_quadric(A_3x3) -> dict:
    """
    Classify a quadric surface x^T A x = 1 by the signs of eigenvalues.

    Returns
    -------
    dict:
      'type'      : str
      'eigenvalues': np.ndarray
    """
    A = _to_float(A_3x3)
    eigs = np.linalg.eigvalsh(A)
    pos = int(np.sum(eigs > 1e-10))
    neg = int(np.sum(eigs < -1e-10))
    zer = int(np.sum(np.abs(eigs) <= 1e-10))

    if pos == 3:
        qtype = "Ellipsoid"
    elif pos == 2 and neg == 1:
        qtype = "Hyperboloid of One Sheet"
    elif pos == 1 and neg == 2:
        qtype = "Hyperboloid of Two Sheets"
    elif pos == 2 and zer == 1:
        qtype = "Elliptic Paraboloid"
    elif pos == 1 and neg == 1 and zer == 1:
        qtype = "Hyperbolic Paraboloid (Saddle)"
    elif pos == 3 or neg == 3:
        qtype = "Imaginary Ellipsoid"
    else:
        qtype = "Degenerate Quadric"

    return {
        'type': qtype,
        'eigenvalues': eigs,
        'signature': (pos, neg, zer)
    }


# ──────────────── Minimal Polynomial ────────────────────────────

def minimal_polynomial(A, max_degree: Optional[int] = None) -> np.poly1d:
    """
    Compute the minimal polynomial of A.

    The minimal polynomial m(λ) is the monic polynomial of least degree
    such that m(A) = 0.

    Uses the Cayley-Hamilton and null-space approach.

    Parameters
    ----------
    A          : array-like (n × n)
    max_degree : search up to this degree (default: 2n)

    Returns
    -------
    np.poly1d – the minimal polynomial
    """
    A = _to_float(A)
    n = A.shape[0]
    if max_degree is None:
        max_degree = 2 * n

    # Build powers of A and find linear dependencies
    # m(A) = 0  ↔  c_0 I + c_1 A + ... + c_k A^k = 0
    # Vectorize: stack columns
    eye_vec = np.eye(n).flatten()
    cols = [eye_vec]
    Ak = np.eye(n)
    for k in range(1, max_degree + 1):
        Ak = Ak @ A
        cols.append(Ak.flatten())
        M = np.column_stack(cols)
        # Check for linear dependence
        _, pivot_cols = _rref_simple(M)
        if len(pivot_cols) < M.shape[1]:
            # Last column is dependent → found minimal poly degree k
            # Solve for coefficients
            M_sub = M[:, :-1]
            b = -M[:, -1]
            try:
                coeffs_low, _, _, _ = np.linalg.lstsq(M_sub, b, rcond=None)
            except Exception:
                continue
            # Polynomial: x^k + coeffs_low[k-1] x^{k-1} + ... + coeffs_low[0]
            poly_coeffs = np.zeros(k + 1)
            poly_coeffs[0] = 1.0
            for i, c in enumerate(reversed(coeffs_low)):
                poly_coeffs[k - i] = c
            return np.poly1d(poly_coeffs)
    raise RuntimeError("Could not determine minimal polynomial within degree limit.")


def _rref_simple(M):
    """Internal RREF helper returning pivot columns."""
    from .linear_systems import reduced_row_echelon_form
    return reduced_row_echelon_form(M)


# ───────────────── Cayley-Hamilton Theorem ───────────────────────

def verify_cayley_hamilton(A, tol: float = 1e-8) -> dict:
    """
    Verify the Cayley-Hamilton theorem: p(A) = 0 where p is the
    characteristic polynomial of A.

    Returns
    -------
    dict:
      'verified'  : bool
      'p_A_norm'  : float – ||p(A)||  (should be ~0)
      'char_poly' : np.poly1d
    """
    A = _to_float(A)
    n = A.shape[0]
    char_coeffs = np.poly(A)   # coefficients of det(λI - A)
    # Evaluate p(A)
    pA = np.zeros_like(A)
    An = np.eye(n)
    for c in reversed(char_coeffs):
        pA += c * An
        An = An @ A  # Note: we compute in reverse, fix ordering
    # Correct: p(A) = c_n I + c_{n-1} A + ... + c_0 A^n
    pA = np.zeros_like(A)
    Ak = np.eye(n)
    for c in reversed(char_coeffs):
        pA += c * Ak
        Ak = Ak @ A
    norm_pA = float(np.linalg.norm(pA))
    # Re-implement cleanly
    pA2 = _evaluate_matrix_polynomial(A, char_coeffs)
    norm_pA = float(np.linalg.norm(pA2))
    return {
        'verified': norm_pA < tol,
        'p_A_norm': norm_pA,
        'char_poly': np.poly1d(char_coeffs),
        'p_A': pA2
    }


def _evaluate_matrix_polynomial(A: np.ndarray, coeffs) -> np.ndarray:
    """
    Evaluate polynomial with given coefficients at matrix A.
    coeffs ordered highest degree first (np.poly convention).
    """
    n = A.shape[0]
    result = np.zeros((n, n))
    for c in coeffs:
        result = result @ A + c * np.eye(n)
    return result


def apply_polynomial_to_matrix(A, poly_coeffs) -> np.ndarray:
    """
    Evaluate p(A) for given polynomial coefficients (highest degree first).

    Parameters
    ----------
    A           : array-like (n × n)
    poly_coeffs : list/array – [a_k, a_{k-1}, ..., a_1, a_0]

    Returns
    -------
    p(A) : np.ndarray
    """
    A = _to_float(A)
    return _evaluate_matrix_polynomial(A, poly_coeffs)


def jordan_blocks_info(A) -> dict:
    """
    Characterize the Jordan structure of A.

    Returns
    -------
    dict:
      'eigenspaces' : list of dicts with eigenvalue, AM, GM, defect
      'is_semisimple' : bool (all defects = 0)
    """
    from .eigenvalues import eigenspaces
    spaces = eigenspaces(A)
    semisimple = all(sp['algebraic_multiplicity'] == sp['geometric_multiplicity']
                     for sp in spaces)
    for sp in spaces:
        sp['defect'] = sp['algebraic_multiplicity'] - sp['geometric_multiplicity']
    return {
        'eigenspaces': spaces,
        'is_semisimple': semisimple
    }
