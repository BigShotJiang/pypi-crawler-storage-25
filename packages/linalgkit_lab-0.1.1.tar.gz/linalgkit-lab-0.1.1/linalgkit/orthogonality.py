"""
Module IV: Orthogonality in Vector Spaces.
Covers inner products, norms, Gram-Schmidt, orthogonal complements,
projections, and orthogonal/unitary matrices.
"""

import numpy as np
from typing import List, Tuple
from .linear_systems import _to_float


def inner_product_real(u, v) -> float:
    """Standard real inner product <u, v> = u^T v."""
    u, v = np.array(u, dtype=float), np.array(v, dtype=float)
    return float(np.dot(u, v))


def inner_product_complex(u, v) -> complex:
    """Standard complex inner product <u, v> = conjugate(u)^T v."""
    u = np.array(u, dtype=complex)
    v = np.array(v, dtype=complex)
    return complex(np.dot(np.conj(u), v))


def inner_product_weighted(u, v, W) -> float:
    """Weighted inner product <u, v>_W = u^T W v."""
    u, v = np.array(u, dtype=float), np.array(v, dtype=float)
    W = _to_float(W)
    return float(u @ W @ v)


def norm(v, p: float = 2) -> float:
    """Compute the p-norm of vector v."""
    v = np.array(v, dtype=complex if np.iscomplexobj(v) else float)
    return float(np.linalg.norm(v, ord=p))


def normalize(v) -> np.ndarray:
    """Return unit vector in the direction of v."""
    v = np.array(v, dtype=float)
    n = norm(v)
    if n < 1e-15:
        raise ValueError("Cannot normalize the zero vector.")
    return v / n


def angle_between(u, v, degrees: bool = False) -> float:
    """Compute the angle between real vectors u and v."""
    u, v = np.array(u, dtype=float), np.array(v, dtype=float)
    cos_theta = np.dot(u, v) / (norm(u) * norm(v))
    cos_theta = np.clip(cos_theta, -1.0, 1.0)
    theta = float(np.arccos(cos_theta))
    return float(np.degrees(theta)) if degrees else theta


def are_orthogonal(u, v, complex: bool = False, step: bool = False):
    """Check if two vectors are orthogonal."""
    value = inner_product_complex(u, v) if complex else inner_product_real(u, v)
    result = abs(value) < 1e-10
    if step:
        return {
            "orthogonal": result,
            "inner_product": value,
            "steps": ["Compute the inner product.", "It is orthogonal when the value is approximately zero."],
        }
    return result


def is_orthogonal_set(vectors, complex: bool = False) -> bool:
    """Check if a set of vectors is mutually orthogonal."""
    n = len(vectors)
    for i in range(n):
        for j in range(i + 1, n):
            if not are_orthogonal(vectors[i], vectors[j], complex):
                return False
    return True


def is_orthonormal_set(vectors, complex: bool = False) -> bool:
    """Check if a set is orthonormal."""
    if not is_orthogonal_set(vectors, complex):
        return False
    return all(abs(norm(v) - 1.0) <= 1e-10 for v in vectors)


def gram_schmidt(vectors, normalize_output: bool = True, complex: bool = False, step: bool = False):
    """
    Apply the Gram-Schmidt process.

    With step=False returns a list of vectors as before. With step=True returns
    a dict containing the basis and each projection removed.
    """
    dtype = np.complex128 if complex else np.float64
    ip = inner_product_complex if complex else inner_product_real
    result = []
    steps = [] if step else None

    for v in vectors:
        v = np.array(v, dtype=dtype)
        w = v.copy()
        projections = []
        for q in result:
            coeff = ip(q, v) / ip(q, q)
            projection = coeff * q
            projections.append(projection)
            w = w - projection
        n = norm(w)
        if n < 1e-12:
            if step:
                steps.append({"input": v, "dependent": True, "orthogonal_vector": w})
            continue
        out = w / n if normalize_output else w
        result.append(out)
        if step:
            steps.append({
                "input": v,
                "projections_removed": projections,
                "orthogonal_vector": w,
                "norm": n,
                "output_vector": out,
            })

    if step:
        return {"basis": result, "steps": steps, "orthonormal": normalize_output}
    return result


def gram_schmidt_qr(A) -> Tuple[np.ndarray, np.ndarray]:
    """QR decomposition via Gram-Schmidt."""
    A = _to_float(A)
    m, n = A.shape
    Q = np.zeros_like(A)
    R = np.zeros((n, n))
    for j in range(n):
        v = A[:, j].copy()
        for i in range(j):
            R[i, j] = Q[:, i] @ A[:, j]
            v -= R[i, j] * Q[:, i]
        R[j, j] = norm(v)
        if R[j, j] < 1e-12:
            raise ValueError(f"Column {j} is dependent; A must have full column rank.")
        Q[:, j] = v / R[j, j]
    return Q, R


def orthogonal_complement(basis, ambient_dim: int, step: bool = False):
    """Compute a basis for the orthogonal complement of span(basis)."""
    from .linear_systems import solve_homogeneous

    if not basis:
        comp = [np.eye(ambient_dim)[i] for i in range(ambient_dim)]
        if step:
            return {"basis": comp, "steps": ["The complement of the zero subspace is the full ambient space."]}
        return comp

    A = np.array(basis, dtype=float)
    result = solve_homogeneous(A, step=step)
    if step:
        return {
            "basis": result["null_space_basis"],
            "coefficient_matrix": A,
            "ambient_dim": ambient_dim,
            "steps": result.get("steps", []),
        }
    return result["null_space_basis"]


def project_onto_subspace(v, basis) -> np.ndarray:
    """Project vector v onto the subspace spanned by basis."""
    v = np.array(v, dtype=float)
    orth = gram_schmidt(basis, normalize_output=True)
    proj = np.zeros_like(v, dtype=float)
    for q in orth:
        proj += np.dot(q, v) * q
    return proj


def best_approximation(v, basis) -> dict:
    """Find the best approximation of v from a subspace."""
    v = np.array(v, dtype=float)
    proj = project_onto_subspace(v, basis)
    res = v - proj
    return {"projection": proj, "residual": res, "residual_norm": float(norm(res))}


def is_orthogonal_matrix(Q, tol: float = 1e-8) -> bool:
    """Check if Q^T Q = I."""
    Q = _to_float(Q)
    n = Q.shape[0]
    return Q.shape[0] == Q.shape[1] and np.allclose(Q.T @ Q, np.eye(n), atol=tol)


def is_unitary_matrix(U, tol: float = 1e-8) -> bool:
    """Check if U^H U = I."""
    U = np.array(U, dtype=complex)
    n = U.shape[0]
    return U.shape[0] == U.shape[1] and np.allclose(U.conj().T @ U, np.eye(n), atol=tol)


def is_hermitian(A, tol: float = 1e-8) -> bool:
    """Check if A equals its conjugate transpose."""
    A = np.array(A, dtype=complex)
    return np.allclose(A, A.conj().T, atol=tol)


def complex_norm(v) -> float:
    """Norm of a complex vector."""
    v = np.array(v, dtype=complex)
    return float(np.sqrt(inner_product_complex(v, v).real))


def complex_orthonormal_basis(vectors) -> List[np.ndarray]:
    """Gram-Schmidt in C^n, returning orthonormal complex vectors."""
    return gram_schmidt(vectors, normalize_output=True, complex=True)


def is_orthogonal_vectors(v1, v2, tolerance: float = 1e-9, step: bool = False):
    """Notebook-friendly alias for checking whether two vectors are orthogonal."""
    value = inner_product_real(v1, v2)
    result = abs(value) < tolerance
    if step:
        return {"orthogonal": result, "dot_product": value, "tolerance": tolerance}
    return result


def is_orthogonal_to_subspace(v, basis_vectors, tolerance: float = 1e-9, step: bool = False):
    """Check whether v is orthogonal to every vector in a basis for a subspace."""
    checks = [is_orthogonal_vectors(v, b, tolerance=tolerance, step=step) for b in basis_vectors]
    result = all(c["orthogonal"] if step else c for c in checks)
    if step:
        return {"orthogonal": result, "checks": checks}
    return result


def orthogonal_complement_basis(basis_W_vectors, ambient_dim: int, step: bool = False):
    """Notebook-friendly alias for orthogonal_complement."""
    return orthogonal_complement(basis_W_vectors, ambient_dim=ambient_dim, step=step)


def gram_schmidt_orthogonalization(vectors, step: bool = False):
    """Notebook-friendly alias returning an orthonormal basis."""
    return gram_schmidt(vectors, normalize_output=True, step=step)
