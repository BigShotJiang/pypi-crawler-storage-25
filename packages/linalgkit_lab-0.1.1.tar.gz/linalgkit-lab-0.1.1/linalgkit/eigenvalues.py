"""
Module V: Eigenvalues and Eigenvectors
Covers: characteristic polynomial/equation, eigenvalues, eigenvectors,
        diagonalization, triangularization, symmetric/Hermitian matrices.
"""

import numpy as np
from typing import List, Tuple, Optional, Dict
from .linear_systems import solve_homogeneous, _to_float
from .orthogonality import gram_schmidt, is_hermitian


# ──────────────── Characteristic Polynomial ─────────────────────

def characteristic_polynomial(A) -> np.poly1d:
    """
    Compute the characteristic polynomial det(λI - A).

    Returns
    -------
    np.poly1d object (roots = eigenvalues)
    """
    A = _to_float(A)
    n = A.shape[0]
    if A.shape[0] != A.shape[1]:
        raise ValueError("Matrix must be square.")
    # Use numpy's eigvals for numerical, build poly from eigenvalues
    eigs = np.linalg.eigvals(A)
    return np.poly1d(np.poly(eigs))


def characteristic_equation_roots(A) -> np.ndarray:
    """
    Return eigenvalues as roots of the characteristic equation.
    Same as eigenvalues(); provided for conceptual clarity.
    """
    return np.linalg.eigvals(_to_float(A))


# ────────────────────── Eigenvalues ─────────────────────────────

def eigenvalues(A, complex_output: bool = False, step: bool = False):
    """
    Compute all eigenvalues of square matrix A.

    Parameters
    ----------
    A              : array-like (n × n)
    complex_output : if False, return real parts when imaginary parts
                     are negligible

    Returns
    -------
    np.ndarray of eigenvalues (sorted by real part, descending)
    """
    A = _to_float(A)
    eigs = np.linalg.eigvals(A)
    if not complex_output and np.all(np.abs(eigs.imag) < 1e-10):
        eigs = eigs.real
    eigs = eigs[np.argsort(eigs.real)[::-1]]
    if step:
        return {
            "eigenvalues": eigs,
            "steps": ["Solve det(lambda I - A) = 0 numerically with numpy.linalg.eigvals."],
        }
    return eigs


def eigenspaces(A, tol: float = 1e-8) -> List[Dict]:
    """
    Compute all distinct eigenvalues and their eigenspaces.

    Parameters
    ----------
    A   : array-like (n × n)
    tol : tolerance for grouping eigenvalues

    Returns
    -------
    list of dicts, each with:
      'eigenvalue'   : float or complex
      'algebraic_multiplicity' : int
      'eigenvectors' : list[np.ndarray]  – basis for eigenspace
      'geometric_multiplicity': int
    """
    A = _to_float(A)
    n = A.shape[0]
    raw_eigs = np.linalg.eigvals(A)
    # Group close eigenvalues
    groups = []
    for ev in raw_eigs:
        placed = False
        for g in groups:
            if abs(ev - g[0]) < tol:
                g.append(ev)
                placed = True
                break
        if not placed:
            groups.append([ev])

    result = []
    for g in groups:
        ev = np.mean(g)  # representative value
        am = len(g)
        # Eigenspace = null(A - ev*I)
        M = A - ev.real * np.eye(n)
        null_data = solve_homogeneous(M)
        evecs = null_data['null_space_basis']
        gm = len(evecs)
        result.append({
            'eigenvalue': float(ev.real) if abs(ev.imag) < 1e-10 else ev,
            'algebraic_multiplicity': am,
            'eigenvectors': evecs,
            'geometric_multiplicity': gm
        })
    return result


def eigenvectors(A, step: bool = False):
    """
    Compute eigenvalues and right eigenvectors.

    Returns
    -------
    vals : np.ndarray (n,)
    vecs : np.ndarray (n, n) – columns are eigenvectors
    """
    A = _to_float(A)
    vals, vecs = np.linalg.eig(A)
    if step:
        return {
            "eigenvalues": vals,
            "eigenvectors": vecs,
            "steps": ["Compute eigenvalue/eigenvector pairs with numpy.linalg.eig."],
        }
    return vals, vecs


# ─────────────────── Diagonalization ────────────────────────────

def is_diagonalizable(A, tol: float = 1e-8) -> dict:
    """
    Check if A is diagonalizable over R (or C).

    A is diagonalizable iff algebraic multiplicity = geometric multiplicity
    for every eigenvalue.

    Returns
    -------
    dict:
      'diagonalizable': bool
      'reason'        : str
      'eigenspaces'   : list of eigenspace dicts
    """
    spaces = eigenspaces(A, tol)
    reasons = []
    ok = True
    for sp in spaces:
        am = sp['algebraic_multiplicity']
        gm = sp['geometric_multiplicity']
        if am != gm:
            ok = False
            reasons.append(
                f"λ={sp['eigenvalue']}: AM={am} ≠ GM={gm}"
            )
    return {
        'diagonalizable': ok,
        'reason': "Diagonalizable" if ok else " | ".join(reasons),
        'eigenspaces': spaces
    }


def diagonalize(A, step: bool = False):
    """
    Diagonalize A = P D P^{-1}.

    Returns
    -------
    (P, D, P_inv) if diagonalizable, else None.
    P  : matrix of eigenvectors (columns)
    D  : diagonal matrix of eigenvalues
    P_inv : inverse of P
    """
    A = _to_float(A)
    check = is_diagonalizable(A)
    if not check['diagonalizable']:
        if step:
            return {"diagonalizable": False, "reason": check["reason"], "P": None, "D": None, "P_inv": None}
        return None
    vals, vecs = np.linalg.eig(A)
    # Ensure real if imaginary parts negligible
    if np.all(np.abs(vals.imag) < 1e-10):
        vals, vecs = vals.real, vecs.real
    P = vecs
    D = np.diag(vals)
    try:
        P_inv = np.linalg.inv(P)
    except np.linalg.LinAlgError:
        if step:
            return {"diagonalizable": False, "reason": "Eigenvector matrix is singular.", "P": P, "D": D, "P_inv": None}
        return None
    P[np.abs(P) < 1e-12] = 0.0
    D[np.abs(D) < 1e-12] = 0.0
    if step:
        return {
            "diagonalizable": True,
            "P": P,
            "D": D,
            "P_inv": P_inv,
            "steps": [
                "Check that algebraic and geometric multiplicities match.",
                "Put eigenvectors as columns of P.",
                "Put eigenvalues on the diagonal of D.",
                "Verify A = P D P_inv.",
            ],
        }
    return P, D, P_inv


def matrix_power_via_diagonalization(A, k: int) -> Optional[np.ndarray]:
    """
    Compute A^k using diagonalization: A^k = P D^k P^{-1}.
    Returns None if A is not diagonalizable.
    """
    result = diagonalize(A)
    if result is None:
        return None
    P, D, P_inv = result
    Dk = np.diag(np.diag(D) ** k)
    return P @ Dk @ P_inv


# ─────────────────── Triangularization ──────────────────────────

def upper_triangularize(A) -> Tuple[np.ndarray, np.ndarray]:
    """
    Bring A to upper triangular form via Schur decomposition:
    A = Q T Q^H  where T is upper triangular.

    Returns
    -------
    T : upper triangular matrix
    Q : unitary matrix (Q^H A Q = T)
    """
    A = _to_float(A)
    T, Q = np.linalg.schur(A)      # scipy-free Schur via numpy workaround
    return T, Q


def is_triangularizable(A) -> bool:
    """
    Every square matrix over C is triangularizable (always True).
    Over R it is triangularizable iff all eigenvalues are real.
    """
    A = _to_float(A)
    eigs = np.linalg.eigvals(A)
    return np.all(np.abs(eigs.imag) < 1e-10)


# ─────── Symmetric and Hermitian Matrix Diagonalization ─────────

def is_symmetric(A, tol: float = 1e-8) -> bool:
    """Check if A = A^T."""
    A = _to_float(A)
    return np.allclose(A, A.T, atol=tol)


def orthogonal_diagonalize_symmetric(A) -> Tuple[np.ndarray, np.ndarray]:
    """
    Orthogonally diagonalize a symmetric matrix A = Q D Q^T
    (Spectral Theorem for real symmetric matrices).

    Parameters
    ----------
    A : real symmetric matrix

    Returns
    -------
    Q : orthogonal matrix (columns = orthonormal eigenvectors)
    D : diagonal matrix of real eigenvalues
    """
    A = _to_float(A)
    if not is_symmetric(A):
        raise ValueError("Matrix must be symmetric for orthogonal diagonalization.")
    vals, vecs = np.linalg.eigh(A)   # eigh guarantees real eigenvalues
    idx = np.argsort(vals)[::-1]
    vals, vecs = vals[idx], vecs[:, idx]
    return vecs, np.diag(vals)


def unitary_diagonalize_hermitian(A) -> Tuple[np.ndarray, np.ndarray]:
    """
    Unitarily diagonalize a Hermitian matrix A = U D U^H.

    Returns
    -------
    U : unitary matrix
    D : diagonal (real eigenvalues)
    """
    A = np.array(A, dtype=complex)
    if not is_hermitian(A):
        raise ValueError("Matrix must be Hermitian.")
    vals, vecs = np.linalg.eigh(A)
    idx = np.argsort(vals)[::-1]
    return vecs[:, idx], np.diag(vals[idx])


def spectral_decomposition(A) -> dict:
    """
    Spectral decomposition of a symmetric/Hermitian matrix:
    A = Σ λ_i P_i  where P_i are rank-1 projection matrices.

    Returns
    -------
    dict:
      'eigenvalues' : list[float]
      'projections' : list[np.ndarray]
      'verification': np.ndarray  (should equal A)
    """
    A = _to_float(A)
    Q, D = orthogonal_diagonalize_symmetric(A)
    vals = np.diag(D)
    projs = []
    recon = np.zeros_like(A)
    for i, lam in enumerate(vals):
        q = Q[:, i:i+1]
        P = q @ q.T
        projs.append(P)
        recon += lam * P
    return {
        'eigenvalues': list(vals),
        'projections': projs,
        'verification': recon
    }


# ───────────────────── Similar Matrices ─────────────────────────

def are_similar(A, B, tol: float = 1e-8) -> dict:
    """
    Check if A and B are similar (same eigenvalues with same multiplicities).

    Returns
    -------
    dict:
      'similar' : bool
      'eigenvalues_A', 'eigenvalues_B' : sorted eigenvalue arrays
    """
    eA = np.sort(np.linalg.eigvals(_to_float(A)).real)
    eB = np.sort(np.linalg.eigvals(_to_float(B)).real)
    similar = (len(eA) == len(eB) and np.allclose(eA, eB, atol=tol))
    return {
        'similar': similar,
        'eigenvalues_A': eA,
        'eigenvalues_B': eB
    }


def compute_eigen(matrix, step: bool = False) -> dict:
    """Notebook-friendly helper returning eigenvalues and eigenvectors."""
    data = eigenvectors(matrix, step=step)
    if step:
        return data
    vals, vecs = data
    return {"eigenvalues": vals, "eigenvectors": vecs}


def diagonalize_matrix(A, step: bool = False):
    """Notebook-friendly alias for diagonalize."""
    return diagonalize(A, step=step)
