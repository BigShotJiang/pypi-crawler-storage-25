"""
linalgkit – A comprehensive linear algebra library covering:

  Module I   : Linear Systems & Gaussian Elimination
  Module II  : Vector Spaces
  Module III : Linear Transformations
  Module IV  : Orthogonality in Vector Spaces
  Module V   : Eigenvalues & Eigenvectors
  Module VI  : Canonical Forms

All functions are general-purpose and handle edge cases.
"""

__version__ = "0.1.1"
__author__  = "linalgkit contributors"
__license__ = "MIT"

# ── Module I: Linear Systems ──────────────────────────────────
from .linear_systems import (
    row_echelon_form,
    reduced_row_echelon_form,
    row_rank,
    gaussian_elimination,
    gauss_jordan_elimination,
    solve_linear_system,
    solve_homogeneous,
    elementary_matrix,
    matrix_inverse_via_gauss_jordan,
    is_consistent,
    null_space,
    solve_homogeneous_system,
    compute_rank_with_rref,
    compute_rank_with_numpy,
)

# ── Module II: Vector Spaces ──────────────────────────────────
from .vector_spaces import (
    are_linearly_independent,
    find_dependent_combinations,
    span_basis,
    is_in_span,
    coordinates_in_basis,
    is_subspace,
    subspace_sum,
    subspace_intersection,
    is_direct_sum,
    dimension_of_span,
    extend_to_basis,
    check_linear_independence,
    find_basis_and_dimension,
    get_basis_and_dimension,
    check_direct_sum,
    are_vectors_equal,
    check_vector_space_axioms,
    check_norm,
)

# ── Module III: Linear Transformations ───────────────────────
from .linear_transformations import (
    kernel,
    image,
    rank_nullity,
    matrix_of_transformation,
    change_of_basis_matrix,
    apply_linear_transformation,
    get_matrix_representation,
    change_of_basis,
    vector_to_new_basis,
    verify_rank_nullity_theorem,
    transform_matrix_new_basis,
    is_isomorphism,
    projection_matrix,
)

# ── Module IV: Orthogonality ──────────────────────────────────
from .orthogonality import (
    inner_product_real,
    inner_product_complex,
    inner_product_weighted,
    norm,
    normalize,
    angle_between,
    are_orthogonal,
    is_orthogonal_set,
    is_orthonormal_set,
    gram_schmidt,
    gram_schmidt_qr,
    orthogonal_complement,
    project_onto_subspace,
    best_approximation,
    is_orthogonal_matrix,
    is_unitary_matrix,
    is_hermitian,
    complex_norm,
    complex_orthonormal_basis,
    is_orthogonal_vectors,
    is_orthogonal_to_subspace,
    orthogonal_complement_basis,
    gram_schmidt_orthogonalization,
)

# ── Module V: Eigenvalues & Eigenvectors ──────────────────────
from .eigenvalues import (
    characteristic_polynomial,
    characteristic_equation_roots,
    eigenvalues,
    eigenspaces,
    eigenvectors,
    is_diagonalizable,
    diagonalize,
    matrix_power_via_diagonalization,
    upper_triangularize,
    is_triangularizable,
    is_symmetric,
    orthogonal_diagonalize_symmetric,
    unitary_diagonalize_hermitian,
    spectral_decomposition,
    are_similar,
    compute_eigen,
    diagonalize_matrix,
)

# ── Module VI: Canonical Forms ────────────────────────────────
from .canonical_forms import (
    bilinear_form,
    symmetrize_bilinear,
    quadratic_form,
    quadratic_form_matrix,
    classify_quadratic_form,
    diagonalize_quadratic_form,
    classify_conic,
    classify_quadric,
    minimal_polynomial,
    verify_cayley_hamilton,
    apply_polynomial_to_matrix,
    jordan_blocks_info,
)

# ── Utilities ─────────────────────────────────────────────────
from .utils import (
    pretty_matrix,
    is_square,
    is_zero_vector,
    make_rational,
    random_invertible_matrix,
    random_symmetric_matrix,
    random_spd_matrix,
    solve_least_squares,
)

__all__ = [
    # Module I
    "row_echelon_form", "reduced_row_echelon_form", "row_rank",
    "gaussian_elimination", "gauss_jordan_elimination",
    "solve_linear_system", "solve_homogeneous", "elementary_matrix",
    "matrix_inverse_via_gauss_jordan", "is_consistent", "null_space",
    "solve_homogeneous_system", "compute_rank_with_rref", "compute_rank_with_numpy",
    # Module II
    "are_linearly_independent", "find_dependent_combinations", "span_basis",
    "is_in_span", "coordinates_in_basis", "is_subspace",
    "subspace_sum", "subspace_intersection", "is_direct_sum",
    "dimension_of_span", "extend_to_basis",
    "check_linear_independence", "find_basis_and_dimension",
    "get_basis_and_dimension", "check_direct_sum", "are_vectors_equal",
    "check_vector_space_axioms", "check_norm",
    # Module III
    "kernel", "image", "rank_nullity", "matrix_of_transformation",
    "change_of_basis_matrix", "transform_matrix_new_basis",
    "apply_linear_transformation", "get_matrix_representation",
    "change_of_basis", "vector_to_new_basis", "verify_rank_nullity_theorem",
    "is_isomorphism", "projection_matrix",
    # Module IV
    "inner_product_real", "inner_product_complex", "inner_product_weighted",
    "norm", "normalize", "angle_between",
    "are_orthogonal", "is_orthogonal_set", "is_orthonormal_set",
    "gram_schmidt", "gram_schmidt_qr",
    "orthogonal_complement", "project_onto_subspace", "best_approximation",
    "is_orthogonal_matrix", "is_unitary_matrix", "is_hermitian",
    "complex_norm", "complex_orthonormal_basis",
    "is_orthogonal_vectors", "is_orthogonal_to_subspace",
    "orthogonal_complement_basis", "gram_schmidt_orthogonalization",
    # Module V
    "characteristic_polynomial", "characteristic_equation_roots",
    "eigenvalues", "eigenspaces", "eigenvectors",
    "is_diagonalizable", "diagonalize", "matrix_power_via_diagonalization",
    "upper_triangularize", "is_triangularizable", "is_symmetric",
    "orthogonal_diagonalize_symmetric", "unitary_diagonalize_hermitian",
    "spectral_decomposition", "are_similar",
    "compute_eigen", "diagonalize_matrix",
    # Module VI
    "bilinear_form", "symmetrize_bilinear",
    "quadratic_form", "quadratic_form_matrix",
    "classify_quadratic_form", "diagonalize_quadratic_form",
    "classify_conic", "classify_quadric",
    "minimal_polynomial", "verify_cayley_hamilton",
    "apply_polynomial_to_matrix", "jordan_blocks_info",
    # Utils
    "pretty_matrix", "is_square", "is_zero_vector", "make_rational",
    "random_invertible_matrix", "random_symmetric_matrix",
    "random_spd_matrix", "solve_least_squares",
]
