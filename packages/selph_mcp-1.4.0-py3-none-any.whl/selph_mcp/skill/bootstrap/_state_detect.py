"""State detection helper for the using-selph bootstrap."""

from __future__ import annotations

from pathlib import Path

from ._shared import logger
from ._paths import _state_dir, _onboarding_path, _claude_md_path, _skills_dir
from ._file_locking import _locked_write
from ._onboarding import _load_onboarding_state

from selph_mcp.skill.state_schema import (
    ColdStart,
    OnboardingMigrationFailed,
    OnboardingState,
    OnboardingStateCorrupt,
    Returning,
    ReturningSubState,
    State,
)
from selph_mcp.contracts.versions import (
    HARNESS_ADAPTER_VERSION,
    MEMORY_BOUNDARY_POLICY_VERSION,
    PERSONA_CONTRACT_VERSION,
)

__all__: list[str] = ["detect_state"]

# Retrieval-policy / workflow-skill markers — duplicated here from _claude_md
# to keep this module self-contained without importing _claude_md (which has
# its own helpers that would create a circular concern).
_RETRIEVAL_POLICY_START = "<!-- selph:retrieval-policy:v1 START -->"
_RETRIEVAL_POLICY_END = "<!-- selph:retrieval-policy:v1 END -->"
_WORKFLOW_SKILL_MARKER_START = "<!-- selph:workflow-skill:v1 START -->"
_WORKFLOW_SKILL_MARKER_END = "<!-- selph:workflow-skill:v1 END -->"


def detect_state(workspace: Path) -> State:
    """Decide cold-start vs returning based on on-disk state.

    Returns one of:

    - ``ColdStart`` — no state file, corrupt JSON, or migration failure.
      ``SKILL.md`` must run the first-run flow per §5.3.
    - ``Returning`` — valid state present. ``sub_state`` refines the
      returning classification:

      - ``CLEAN`` — no drift; minimal returning flow.
      - ``UPGRADE_IN_PLACE`` — version-only drift; in-place surgical updates.
      - ``REPAIR`` — structural drift (missing blocks, legacy markers); targeted
        repair flow.

    Tiered drift detection (§4.6 / Phase B2):

    Version drift tags (map to UPGRADE_IN_PLACE unless structural drift also
    present):
      - ``"persona_contract_version"``
      - ``"harness_adapter_version"``
      - ``"memory_boundary_policy_version"``

    Structural drift tags (always produce REPAIR):
      - ``"retrieval_policy_block_missing"`` — workspace CLAUDE.md lacks
        ``_RETRIEVAL_POLICY_START`` / ``_RETRIEVAL_POLICY_END`` markers.
      - ``"workflow_template_stale"`` — at least one installed workflow's
        SKILL.md exists on disk but lacks ``_WORKFLOW_SKILL_MARKER_START``
        (legacy markerless install).
    """
    state_dir = _state_dir(workspace)
    onboarding = _onboarding_path(workspace)

    logger.info(
        "detect_state: starting",
        extra={
            "event": "bootstrap.detect_state.entry",
            "workspace": str(workspace),
        },
    )

    # --- load state via shared loader ----------------------------------------
    # Wrap in _locked_write so that any v1→v2 migration writeback in Step 5
    # of _load_onboarding_state is protected against concurrent detect_state /
    # update_etag_cursor / reconcile_onboarding callers (lost-update fix).
    # _locked_write's callable captures exceptions via re-raise; the except
    # clauses below still handle OnboardingStateCorrupt / OnboardingMigrationFailed
    # as before.  Double-locking from update_etag_cursor / reconcile_onboarding
    # (which already hold the lock when they call _load_onboarding_state inside
    # their own _locked_write) is safe: fcntl.flock opens a fresh fd each time,
    # and Linux grants an LOCK_EX to the same process on a new fd immediately.
    state: "OnboardingState | None" = None
    _load_result: dict = {}

    def _do_load() -> None:
        _load_result["state"] = _load_onboarding_state(onboarding, allow_migration=True)

    try:
        _locked_write(onboarding, _do_load)
        state = _load_result.get("state")
    except OnboardingStateCorrupt as exc:
        logger.warning(
            "onboarding state corrupt; treating as cold start",
            extra={
                "event": "bootstrap.detect_state",
                "kind": "cold_start",
                "reason": "state_file_unreadable",
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        return ColdStart(
            workspace_root=str(workspace),
            state_dir=str(state_dir),
            reason="state_file_unreadable",
        )
    except OnboardingMigrationFailed as exc:
        logger.warning(
            "onboarding state migration failed; treating as cold start",
            extra={
                "event": "bootstrap.detect_state",
                "kind": "cold_start",
                "reason": "state_file_unreadable",
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        return ColdStart(
            workspace_root=str(workspace),
            state_dir=str(state_dir),
            reason="state_file_unreadable",
        )

    if state is None:
        logger.info(
            "cold start: no onboarding state",
            extra={
                "event": "bootstrap.detect_state",
                "kind": "cold_start",
                "reason": "no_state_file",
            },
        )
        return ColdStart(
            workspace_root=str(workspace),
            state_dir=str(state_dir),
            reason="no_state_file",
        )

    # Malformed workflow IDs were already dropped in _load_onboarding_state Step 3b.

    # --- tiered drift detection -----------------------------------------------
    drift_reasons: list[str] = []

    # Version drift
    if state.persona_contract_version != str(PERSONA_CONTRACT_VERSION):
        drift_reasons.append("persona_contract_version")
    if state.harness_adapter_version != HARNESS_ADAPTER_VERSION:
        drift_reasons.append("harness_adapter_version")
    if state.memory_boundary_policy_version != MEMORY_BOUNDARY_POLICY_VERSION:
        drift_reasons.append("memory_boundary_policy_version")

    # Structural drift — retrieval policy block missing from CLAUDE.md
    claude_md = _claude_md_path(workspace)
    try:
        claude_md_text = claude_md.read_text(encoding="utf-8") if claude_md.exists() else ""
    except OSError:
        claude_md_text = ""
    if _RETRIEVAL_POLICY_START not in claude_md_text or _RETRIEVAL_POLICY_END not in claude_md_text:
        drift_reasons.append("retrieval_policy_block_missing")

    # Structural drift — ambient capture hooks missing (Phase G)
    try:
        from ._claude_hooks import verify_hooks as _verify_hooks
        if not _verify_hooks(workspace):
            drift_reasons.append("hooks_missing")
    except Exception as _hooks_exc:
        logger.debug(
            "detect_state: hook verification failed (non-fatal)",
            extra={
                "event": "bootstrap.detect_state.hooks_verify_failed",
                "error_type": type(_hooks_exc).__name__,
                "error": str(_hooks_exc)[:200],
            },
        )

    # Structural drift — per-workspace credentials.json missing bearer_token
    # (written by wheel < 1.4.0 which predates Phase G ambient capture).
    # The returning flow's Step 4a repairs this automatically by re-running
    # write-credentials with the current bearer_token from global credentials.
    try:
        from ._paths import _credentials_path
        import json as _json
        creds_path = _credentials_path(workspace)
        if creds_path.exists():
            _creds_raw = creds_path.read_text(encoding="utf-8")
            _creds_data = _json.loads(_creds_raw)
            if not _creds_data.get("bearer_token"):
                drift_reasons.append("credentials_missing_bearer_token")
    except Exception as _creds_exc:
        logger.debug(
            "detect_state: credentials bearer_token check failed (non-fatal)",
            extra={
                "event": "bootstrap.detect_state.credentials_check_failed",
                "error_type": type(_creds_exc).__name__,
                "error": str(_creds_exc)[:200],
            },
        )

    # Structural drift — any installed workflow SKILL.md lacks v1 markers
    for wf_id in state.installed_workflows:
        skill_path = _skills_dir(workspace, wf_id) / "SKILL.md"
        if not skill_path.exists():
            # Missing-on-disk is handled by workflow_scan; skip here
            continue
        try:
            skill_text = skill_path.read_text(encoding="utf-8")
        except OSError:
            skill_text = ""
        if (
            _WORKFLOW_SKILL_MARKER_START not in skill_text
            or _WORKFLOW_SKILL_MARKER_END not in skill_text
        ):
            drift_reasons.append("workflow_template_stale")
            break  # one stale workflow is enough to set the flag

    # --- classify sub_state ---------------------------------------------------
    structural_tags = {
        "retrieval_policy_block_missing",
        "workflow_template_stale",
        "hooks_missing",
        "credentials_missing_bearer_token",
    }
    has_structural = any(r in structural_tags for r in drift_reasons)

    if not drift_reasons:
        sub_state = ReturningSubState.CLEAN
    elif has_structural:
        sub_state = ReturningSubState.REPAIR
    else:
        sub_state = ReturningSubState.UPGRADE_IN_PLACE

    contract_drift = "persona_contract_version" in drift_reasons

    if drift_reasons:
        logger.warning(
            "returning user with drift detected",
            extra={
                "event": "bootstrap.detect_state",
                "kind": "returning",
                "sub_state": sub_state,
                "drift_reasons": drift_reasons,
                "consumer_id": state.consumer_id,
                "user_id": state.user_id,
            },
        )
    else:
        logger.info(
            "returning user; no drift",
            extra={
                "event": "bootstrap.detect_state",
                "kind": "returning",
                "sub_state": sub_state,
                "consumer_id": state.consumer_id,
                "user_id": state.user_id,
                "etag_cursor": state.etag_cursor,
            },
        )

    return Returning(
        workspace_root=str(workspace),
        state_dir=str(state_dir),
        state=state,
        contract_drift=contract_drift,
        sub_state=sub_state,
        drift_reasons=drift_reasons,
    )
