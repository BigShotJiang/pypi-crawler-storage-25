# First-run flow

Read this file when the slim controller routes you here (cold-start with no
global credentials, OR cold-start with a legacy v1 entry that needs upgrade).

The wheel needs a global credentials file before anything else can happen.

---

## Step 1 — verify the wheel is installed

Run `which selph-mcp-bootstrap`. If empty / nonzero exit, refuse to continue:

> The `selph-mcp-bootstrap` console script is not on your PATH. Install the
> wheel with `pipx install selph-mcp` and re-run `/using-selph`.

---

## Step 2 — collect creds via numbered menu

Ask for (numbered menu, no open-ended prompts):

- the engine `api_url` (default: the Azure prod URL from
  `selph-mcp-bootstrap register --help`);
- the shared `SELPH_API_KEY`;
- their `user_id` (e.g. `U001`).

---

## Step 3 — register against the engine

```bash
selph-mcp-bootstrap register \
    --user-id <user_id> \
    --api-url <api_url> \
    --api-key <api_key>
```

That command:

- POSTs `/apps/mcp/consumers` with `issue_bearer_token=true`;
- captures the one-time `bearer_token` from the response;
- writes `${XDG_CONFIG_HOME:-$HOME/.config}/selph-mcp/credentials.json`
  with mode `0600`.

If the command exits non-zero, surface stderr verbatim. Do NOT continue.

---

## Step 4 — run the drift check

After register succeeds, run the wheel-version drift check (see slim
controller §"Wheel-version drift check"). The `whoami-remote` call doubles
as a liveness check.

---

## Step 5 — write the workspace `.gitignore` + per-workspace credentials

Re-read global credentials (so you do not have to ask the user again) and
write the per-workspace projection. The `bearer_token` **must** be passed —
without it the ambient capture hooks installed in Step 10 will silently
fail to POST turns to the engine:

```bash
# Read fresh credentials
selph-mcp-bootstrap hydrate-global
# → data: {consumer_id, user_id, api_url, bearer_token, ...}

selph-mcp-bootstrap write-credentials \
    --workspace "<cwd>" \
    --consumer-id "<consumer_id>" \
    --user-id "<user_id>" \
    --api-url "<api_url>" \
    --bearer-token "<bearer_token>"
```

---

## Step 6 — install the CLAUDE.md blocks

```bash
selph-mcp-bootstrap append-claude-md --workspace "<cwd>"
selph-mcp-bootstrap install-policy-block --workspace "<cwd>"
```

---

## Step 7 — write the remote MCP entry

```bash
selph-mcp-bootstrap write-mcp-entry --remote-url "<api_url>"
```

This writes a `type: "http"` `selph-remote` entry into `~/.claude.json`
with both `Authorization: Bearer <token>` and `X-Consumer-Id: <consumer_id>`
headers. If a legacy `type: "stdio"` `selph` entry exists, it is silently
removed and a migration audit record is written. The resulting entry:

```json
{
  "mcpServers": {
    "selph-remote": {
      "type": "http",
      "url": "<api_url>/mcp",
      "headers": {
        "Authorization": "Bearer <token>",
        "X-Consumer-Id": "<consumer_id>"
      }
    }
  }
}
```

---

## Step 8 — run the 4-step MCP chain

Do not skip any step, do not reorder.

1. `hire_for_role(role="bootstrapper", purpose="workspace-onboarding")` —
   establishes the bootstrap consumer scope. These calls go through the
   `selph-remote` HTTP MCP entry at `<api_url>/mcp`.
2. `what_changed(since_cursor=0)` — primes the local cursor; render any
   returned drift items as numbered chips.
3. `get_context(subject="self", intent="operating_manual")` — render the
   user's operating manual. Apply the sparse-graph posture if confidence is
   low (see `reference/voice-and-evidence.md`).
4. `recommend_workflows()` — runs the Phase 5 heuristic ranker over the
   user's hub payloads and returns
   `{recommendations: [{workflow_id, score, confidence, top_reasons,
   supporting_signals, missing_information, feedback_event_key}, ...]}`
   sorted by score desc. **Do not call
   `get_context(intent="workflow_recommendation")`** — that returns the
   identity hub payload, not a workflow list.

---

## Step 8.5 — scan existing skills

Run the same workflow scan that the returning-user flow uses, so
pre-existing `.claude/skills/*/SKILL.md` files in this workspace get
surfaced even on the very first onboarding run:

```bash
selph-mcp-bootstrap scan-workflows --workspace "<cwd>"
```

Parse `data` as a `WorkflowScanReport`. Hold it in scope. **Render
proposals from `data.proposals` per `flows/workflow-audit.md` rules
before rendering the recommendations in Step 9.** A first-time user
with skills already on disk should see the same `advisory_only` menu
(`[1] Show me what Selph would add  [2] Skip`) as a returning user.
If `data.proposals` is empty, render nothing here and continue to
Step 9.

---

## Step 9 — render workflow recommendations

For each recommendation, offer `[1] install now`, `[2] skip`,
`[3] modify constraints`, `[4] defer for next session`. For each
`[1] install now`:

```bash
selph-mcp-bootstrap install-workflow \
    --workspace "<cwd>" \
    --workflow-id "<workflow_id>" \
    --manifest @<manifest_path>.json
```

Phase 4 verification path: if the persona MCP returns no recommendations
(empty graph) you may install the `placeholder` workflow with no `--manifest`
argument so the install path is exercised end-to-end.

---

## Step 10 — install ambient capture hooks

Selph quietly captures this workspace's conversation turns to keep your
persona graph current. You can disable this at any time with
`selph-mcp-bootstrap uninstall-hooks`.

```bash
selph-mcp-bootstrap install-hooks --workspace "<cwd>"
```

This writes hook entries into `<workspace>/.claude/settings.local.json`
(a gitignored file) for three Claude Code events: every user prompt,
every assistant reply, and session end. The hooks append turns to a local
SQLite file at `.selph/state/session_spool.db` and periodically flush to
your Selph engine for memory extraction.

---

## Step 11 — persist state

```bash
selph-mcp-bootstrap record-onboarding \
    --workspace "<cwd>" \
    --consumer-id "<consumer_id>" \
    --user-id "<user_id>" \
    --etag-cursor <latest_cursor> \
    --installed-workflows '[<id1>, ...]'
```
