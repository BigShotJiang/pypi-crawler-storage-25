import json
import logging
import os
import time
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy.orm import Session

from baltra_sdk.backend.db.screening_models import (
    CandidateFunnelLog,
    Candidates,
    QuestionSets,
    Roles,
    ScreeningMessages,
    ScreeningQuestions,
    CompanyGroups,
    BusinessUnits,
    Locations,
    WhatsappStatusUpdates,
    db
)
from baltra_sdk.shared.funnel_states.funnel_states import CandidateFunnelState

_LOG = "[CandidateDataFetcher]"


def _get_referral_from_status_updates(
    session,
    wa_id_user: str,
    wa_id_system: str,
) -> Optional[Dict[str, Any]]:
    """Return the most recent referral from whatsapp_status_updates within a 1-hour window.

    Conditions:
      1. wa_id matches the candidate's phone
      2. phone_number_id matches wa_id_system (the business WhatsApp phone number ID)
      3. timestamp is within ±1 hour of now (epoch seconds)
      4. referral is not null
    """
    try:
        now_epoch = int(time.time())
        one_hour = 3600
        row = (
            session.query(WhatsappStatusUpdates)
            .filter(
                WhatsappStatusUpdates.wa_id == wa_id_user,
                WhatsappStatusUpdates.phone_number_id == wa_id_system,
                WhatsappStatusUpdates.referral.isnot(None),
                WhatsappStatusUpdates.timestamp >= (now_epoch - one_hour),
                WhatsappStatusUpdates.timestamp <= (now_epoch + one_hour),
            )
            .order_by(WhatsappStatusUpdates.timestamp.desc())
            .first()
        )
        if row and isinstance(row.referral, dict):
            logging.info(
                "%s Referral found in status_updates within 1h window "
                "status_update_id=%s wa_id=%s system=%s ctwa_clid=%s delta_seconds=%s",
                _LOG, row.id, wa_id_user, wa_id_system,
                row.referral.get("ctwa_clid"), now_epoch - row.timestamp,
            )
            return row.referral
        logging.info(
            "%s No referral found within 1h window wa_id=%s system=%s",
            _LOG, wa_id_user, wa_id_system,
        )
    except Exception:
        logging.exception(
            "%s Failed referral lookup wa_id=%s system=%s", _LOG, wa_id_user, wa_id_system,
        )
    return None


class CandidateDataFetcher:
    """Fetches or creates candidate data, initializes  thread, and determines current and next screening questions."""

    def __init__(
        self,
        wa_id_user,
        client,
        wa_id_system,
        session: Session,
        expiration_days: Optional[int] = None,
    ):
        self.wa_id_user = wa_id_user
        self.wa_id_system = wa_id_system
        self.client = client
        self.session = session
        self.expiration_days = expiration_days or int(
            os.getenv("SCREENING_EXPIRATION_DAYS", "30")
        )

        self.candidate, self.first_question_flag = self._get_or_create_candidate()
        self.latest_message = self._get_latest_message()
        self.thread_id = self._get_thread_id()
        self.set_id, self.question_id = self._get_set_and_question_id()

    def _get_or_create_candidate(self):
        logging.info(
            f"Get or create candidate for wa_id {self.wa_id_user} and system_wa_id {self.wa_id_system}"
        )
        company_group = (
            self.session.query(CompanyGroups)
            .filter_by(wa_id=self.wa_id_system)
            .first()
        )
        candidate = None

        if company_group:
            candidate = (
                self.session.query(Candidates)
                .filter_by(
                    phone=self.wa_id_user,
                    company_group_id=company_group.company_group_id,
                )
                .order_by(Candidates.created_at.desc())
                .first()
            )

            if not candidate:
                try:
                    referral = _get_referral_from_status_updates(
                        self.session, self.wa_id_user, self.wa_id_system
                    )
                    new_candidate = Candidates(
                        phone=self.wa_id_user,
                        company_group_id=company_group.company_group_id,
                        name="",
                        created_at=datetime.now(),
                        funnel_state=CandidateFunnelState.SCREENING_IN_PROGRESS.value,
                        fb_referral=referral,
                    )
                    self.session.add(new_candidate)
                    self.session.commit()
                    logging.info(
                        "%s Candidate created candidate_id=%s wa_id=%s cg=%s fb_referral_set=%s",
                        _LOG, new_candidate.candidate_id, self.wa_id_user,
                        company_group.company_group_id, referral is not None,
                    )
                    if referral:
                        logging.info(
                            "%s fb_referral stamped at creation candidate_id=%s ctwa_clid=%s",
                            _LOG, new_candidate.candidate_id, referral.get("ctwa_clid"),
                        )
                    return new_candidate, True
                except Exception as e:
                    logging.error(
                        f"Failed to create candidate for company group {company_group.company_group_id}: {e}"
                    )
                    self.session.rollback()
                    return None, False
        else:
            business_unit = (
                self.session.query(BusinessUnits)
                .filter_by(wa_id=self.wa_id_system)
                .first()
            )
            if not business_unit:
                logging.warning(f"No business unit found for wa_id_system: {self.wa_id_system}")
                return None, False

            candidate = (
                self.session.query(Candidates)
                .filter_by(phone=self.wa_id_user, business_unit_id=business_unit.business_unit_id)
                .order_by(Candidates.created_at.desc())
                .first()
            )

        if candidate:
            logging.info(f"Candidate found: ID {candidate.candidate_id}")

            latest_message = (
                self.session.query(ScreeningMessages)
                .filter_by(candidate_id=candidate.candidate_id)
                .order_by(ScreeningMessages.time_stamp.desc())
                .first()
            )

            if (
                latest_message
                and latest_message.time_stamp
                and (datetime.now() - latest_message.time_stamp).days > self.expiration_days
            ):
                previous_state = candidate.funnel_state or ""
                if previous_state != CandidateFunnelState.EXPIRED.value:
                    try:
                        log_entry = CandidateFunnelLog(
                            candidate_id=candidate.candidate_id,
                            previous_funnel_state=previous_state,
                            new_funnel_state=CandidateFunnelState.EXPIRED.value,
                            changed_at=datetime.now(),
                        )
                        self.session.add(log_entry)
                        self.session.commit()
                        logging.info(
                            f"Logged funnel state change for candidate {candidate.candidate_id}: "
                            f"{previous_state} -> expired"
                        )
                    except Exception as e:
                        logging.error(
                            f"Failed to log funnel state change for candidate {candidate.candidate_id}: {e}"
                        )
                        self.session.rollback()

                candidate.funnel_state = CandidateFunnelState.EXPIRED.value
                self.session.commit()

                try:
                    # Use business_unit_id from expired candidate if available, otherwise use business_unit from query
                    business_unit_id = candidate.business_unit_id
                    if not business_unit_id and 'business_unit' in locals():
                        business_unit_id = business_unit.business_unit_id

                    referral = _get_referral_from_status_updates(
                        self.session, self.wa_id_user, self.wa_id_system
                    )
                    new_candidate = Candidates(
                        phone=self.wa_id_user,
                        business_unit_id=business_unit_id,
                        company_group_id=candidate.company_group_id,
                        name="",
                        created_at=datetime.now(),
                        funnel_state=CandidateFunnelState.SCREENING_IN_PROGRESS.value,
                        fb_referral=referral,
                    )
                    self.session.add(new_candidate)
                    self.session.commit()
                    logging.info(
                        "%s Candidate re-created after expiration candidate_id=%s wa_id=%s bu=%s fb_referral_set=%s",
                        _LOG, new_candidate.candidate_id, self.wa_id_user,
                        business_unit_id, referral is not None,
                    )
                    if referral:
                        logging.info(
                            "%s fb_referral stamped at re-creation candidate_id=%s ctwa_clid=%s",
                            _LOG, new_candidate.candidate_id, referral.get("ctwa_clid"),
                        )
                    return new_candidate, True
                except Exception as e:
                    logging.error(
                        f"Error creating new candidate after expiration: {e}"
                    )
                    self.session.rollback()
                    return None, False

            return candidate, False

        # If we reach here, no candidate was found and we need to create one
        # This only happens when there's no company_group (else branch above)
        if 'business_unit' not in locals():
            logging.error("Cannot create candidate: no business_unit or company_group found")
            return None, False
            
        try:
            referral = _get_referral_from_status_updates(
                self.session, self.wa_id_user, self.wa_id_system
            )
            new_candidate = Candidates(
                phone=self.wa_id_user,
                business_unit_id=business_unit.business_unit_id,
                name="",
                created_at=datetime.now(),
                funnel_state=CandidateFunnelState.SCREENING_IN_PROGRESS.value,
                fb_referral=referral,
            )
            self.session.add(new_candidate)
            self.session.commit()
            first_question_flag = True
            logging.info(
                "%s Candidate created candidate_id=%s wa_id=%s bu=%s fb_referral_set=%s",
                _LOG, new_candidate.candidate_id, self.wa_id_user,
                business_unit.business_unit_id, referral is not None,
            )
            if referral:
                logging.info(
                    "%s fb_referral stamped at creation candidate_id=%s ctwa_clid=%s",
                    _LOG, new_candidate.candidate_id, referral.get("ctwa_clid"),
                )
            return new_candidate, first_question_flag
        except Exception as e:
            logging.error(f"Error creating new candidate: {e}")
            self.session.rollback()
            return None, False

    def _get_latest_message(self):
        """
        Retrieves the most recent *valid* message sent by the candidate.

        A "valid" message is defined as one that contains both:
        - `set_id` (the question set the candidate was answering)
        - `question_id` (the specific question within that set)

        This prevents the system from defaulting to arbitrary values (1,1)
        in cases where the most recent message exists but lacks progress information,
        which could happen due to previous bugs or incomplete database writes.
        """
        if not self.candidate:
            logging.warning("No candidate available when fetching latest message.")
            return None
        return (
            self.session.query(ScreeningMessages)
            .filter(
                ScreeningMessages.candidate_id == self.candidate.candidate_id,
                ScreeningMessages.set_id.isnot(None),
                ScreeningMessages.question_id.isnot(None)
            )
            .order_by(ScreeningMessages.time_stamp.desc())
            .first()
        )

    def _get_thread_id(self):
        if self.latest_message and self.latest_message.thread_id:
            logging.debug(f"Using existing thread ID: {self.latest_message.thread_id}")
            return self.latest_message.thread_id
        try:
            thread = self.client.beta.threads.create()
            logging.debug(f"New Thread Created: {thread.id}")
            return thread.id
        except Exception as e:
            logging.error(f"Error creating thread: {e}")
            return None

    def _get_set_and_question_id(self):
        if self.latest_message:
            return self.latest_message.set_id, self.latest_message.question_id

        if self.candidate.business_unit_id:
            logging.info(
                "No previous messages found, fetching first question from active set."
            )
            set_obj = (
                self.session.query(QuestionSets)
                .join(
                    BusinessUnits,
                    QuestionSets.business_unit_id == BusinessUnits.business_unit_id,
                )
                .filter(
                    QuestionSets.business_unit_id == self.candidate.business_unit_id,
                    BusinessUnits.is_active.is_(True),
                    QuestionSets.is_active.is_(True),
                    QuestionSets.general_set.is_(True),
                )
                .order_by(QuestionSets.created_at.desc())
                .first()
            )

            if not set_obj:
                logging.error(
                    "[SCREENING_CURSOR] unresolved_cursor reason=no_active_general_set_for_active_bu "
                    "candidate_id=%s business_unit_id=%s company_group_id=%s "
                    "(legacy would have defaulted set_id=1 question_id=1)",
                    getattr(self.candidate, "candidate_id", None),
                    self.candidate.business_unit_id,
                    getattr(self.candidate, "company_group_id", None),
                )
                return None, None

            first_question = (
                self.session.query(ScreeningQuestions)
                .filter_by(set_id=set_obj.set_id, position=1, is_active=True)
                .first()
            )
            if not first_question:
                logging.error(
                    "[SCREENING_CURSOR] unresolved_cursor reason=no_active_question_at_position_1 "
                    "candidate_id=%s business_unit_id=%s set_id=%s "
                    "(legacy would have defaulted set_id=%s question_id=1)",
                    getattr(self.candidate, "candidate_id", None),
                    self.candidate.business_unit_id,
                    set_obj.set_id,
                    set_obj.set_id,
                )
                return None, None
        elif self.candidate.company_group_id:
            logging.info(
                "Candidate belongs to a company group, fetching first question from active group set."
            )
            set_obj = (
                self.session.query(QuestionSets)
                .filter_by(group_id=self.candidate.company_group_id, is_active=True)
                .order_by(QuestionSets.created_at.desc())
                .first()
            )

            if not set_obj:
                # No group-level set: fall back to the smallest active BU in
                # this group that has an active general question set.
                bu_with_set = (
                    self.session.query(BusinessUnits)
                    .join(
                        QuestionSets,
                        QuestionSets.business_unit_id == BusinessUnits.business_unit_id,
                    )
                    .filter(
                        BusinessUnits.company_group_id == self.candidate.company_group_id,
                        BusinessUnits.is_active.is_(True),
                        QuestionSets.general_set.is_(True),
                        QuestionSets.is_active.is_(True),
                    )
                    .order_by(BusinessUnits.business_unit_id.asc())
                    .first()
                )

                if bu_with_set is None:
                    logging.error(
                        "[SCREENING_CURSOR] unresolved_cursor reason=no_group_set_and_no_bu_with_general_set "
                        "candidate_id=%s company_group_id=%s business_unit_id=%s "
                        "(legacy would have defaulted set_id=1 question_id=1)",
                        getattr(self.candidate, "candidate_id", None),
                        self.candidate.company_group_id,
                        getattr(self.candidate, "business_unit_id", None),
                    )
                    return None, None

                logging.info(
                    f"Binding candidate {getattr(self.candidate, 'candidate_id', '?')} "
                    f"to business_unit_id={bu_with_set.business_unit_id} (smallest active BU with general set)"
                )
                self.candidate.business_unit_id = bu_with_set.business_unit_id
                self.session.add(self.candidate)
                self.session.commit()

                set_obj = (
                    self.session.query(QuestionSets)
                    .join(
                        BusinessUnits,
                        QuestionSets.business_unit_id == BusinessUnits.business_unit_id,
                    )
                    .filter(
                        QuestionSets.business_unit_id == bu_with_set.business_unit_id,
                        BusinessUnits.is_active.is_(True),
                        QuestionSets.is_active.is_(True),
                        QuestionSets.general_set.is_(True),
                    )
                    .order_by(QuestionSets.created_at.desc())
                    .first()
                )

                if not set_obj:
                    logging.error(
                        "[SCREENING_CURSOR] unresolved_cursor reason=no_general_set_after_group_bu_bind "
                        "candidate_id=%s company_group_id=%s bound_business_unit_id=%s "
                        "(legacy would have defaulted set_id=1 question_id=1)",
                        getattr(self.candidate, "candidate_id", None),
                        self.candidate.company_group_id,
                        bu_with_set.business_unit_id,
                    )
                    return None, None

            logging.info(
                f"Active question set selected: set_id {set_obj.set_id}"
            )
            first_question = (
                self.session.query(ScreeningQuestions)
                .filter_by(set_id=set_obj.set_id, position=1, is_active=True)
                .first()
            )

            if not first_question:
                logging.error(
                    "[SCREENING_CURSOR] unresolved_cursor reason=no_active_question_at_position_1_group_flow "
                    "candidate_id=%s company_group_id=%s set_id=%s "
                    "(legacy would have defaulted set_id=%s question_id=1)",
                    getattr(self.candidate, "candidate_id", None),
                    self.candidate.company_group_id,
                    set_obj.set_id,
                    set_obj.set_id,
                )
                return None, None
        else:
            logging.error(
                "[SCREENING_CURSOR] unresolved_cursor reason=no_business_unit_or_company_group "
                "candidate_id=%s (legacy would have defaulted set_id=1 question_id=1)",
                getattr(self.candidate, "candidate_id", None),
            )
            return None, None

        return set_obj.set_id, first_question.question_id

    def _get_current_and_next_question(self):
        current = (
            self.session.query(ScreeningQuestions)
            .filter_by(question_id=self.question_id)
            .first()
        )

        if not current:
            logging.warning(f"No question found with ID: {self.question_id}")
            return None, None, None, None, None, None, None, None

        next_q = (
            self.session.query(ScreeningQuestions)
            .filter_by(
                set_id=self.set_id,
                position=current.position + 1,
                is_active=True,
            )
            .first()
        )

        if next_q:
            logging.debug(f"Next question found: position {next_q.position}")
            return (
                current.question,
                current.response_type,
                current.position,
                current.end_interview_answer,
                current.example_answer,
                next_q.question,
                next_q.response_type,
                next_q.question_id,
            )
        else:
            logging.info(
                f"No next question found after position {current.position} in set {self.set_id}"
            )
            return (
                current.question,
                current.response_type,
                current.position,
                current.end_interview_answer,
                current.example_answer,
                None,
                None,
                None,
            )

    def _get_company_context(self):
        """
        Gets business unit context based on candidate's business_unit_id.
        If no business_unit_id, falls back to company_groups info.
        
        Location priority:
        1. Role's interview location -> role's work location
        2. business_unit.default_location_id
        3. Any location for the business unit
        
        Returns a tuple with 14 elements:
        (company_name, company_description, address, benefits, general_faq,
         classifier_assistant_id, general_purpose_assistant_id, maps_link_json,
         interview_address_json, interview_days, interview_hours, hr_contact,
         interview_directions, role_name)
        """
        if self.candidate.business_unit_id:
            business_unit = (
                self.session.query(BusinessUnits)
                .filter_by(business_unit_id=self.candidate.business_unit_id)
                .first()
            )
            if business_unit:
                # Get location and hr_contact from role
                address = None
                hr_contact = None
                interview_directions = None
                role_name = None
                maps_link_json = {}
                interview_address_json = {}
                
                role = None
                if self.candidate.role_id:
                    role = self.session.query(Roles).filter_by(role_id=self.candidate.role_id).first()
                
                if role:
                    hr_contact = role.hr_contact
                    interview_directions = getattr(role, 'indicaciones_llegada', None)
                    role_name = role.role_name
                    # Get interview location from role
                    loc = None
                    if role.location_id_interview:
                        loc = self.session.query(Locations).filter_by(location_id=role.location_id_interview).first()
                    if not loc and role.location_id:
                        loc = self.session.query(Locations).filter_by(location_id=role.location_id).first()
                    if loc:
                        address = loc.address
                        if loc.url:
                            maps_link_json = {"location_link_1": loc.url}
                        if loc.address:
                            interview_address_json = {"location_1": loc.address}
                
                # Fallback to business unit's default_location_id
                if not address and business_unit.default_location_id:
                    loc = self.session.query(Locations).filter_by(location_id=business_unit.default_location_id).first()
                    if loc:
                        address = loc.address
                        if loc.url:
                            maps_link_json = {"location_link_1": loc.url}
                        if loc.address:
                            interview_address_json = {"location_1": loc.address}
                
                # Fallback to any location for this business unit
                if not address:
                    loc = self.session.query(Locations).filter_by(business_unit_id=self.candidate.business_unit_id).first()
                    if loc:
                        address = loc.address
                        if loc.url:
                            maps_link_json = {"location_link_1": loc.url}
                        if loc.address:
                            interview_address_json = {"location_1": loc.address}
                
                return (
                    business_unit.name,
                    business_unit.description,
                    address,
                    business_unit.benefits,
                    business_unit.general_faq,
                    business_unit.classifier_assistant_id,
                    business_unit.general_purpose_assistant_id,
                    maps_link_json,
                    interview_address_json,
                    business_unit.interview_days,
                    business_unit.interview_hours,
                    hr_contact,
                    interview_directions,
                    role_name,
                )

        if self.candidate.company_group_id:
            group = (
                self.session.query(CompanyGroups)
                .filter_by(company_group_id=self.candidate.company_group_id)
                .first()
            )
            if group:
                return (
                    group.name,
                    group.description,
                    None,
                    None,
                    None,
                    "asst_iBUlpF7FISkh3oY8Pr3bmVUb",
                    "asst_drleBzh2ufZ79J7MHeocfp5X",
                    {},
                    {},
                    None,
                    None,
                    None,
                    None,  # interview_directions
                    None,  # role_name
                )

        return "", "", "", "", "", "", "", {}, {}, None, None, None, None, None

    @staticmethod
    def _format_compensation_summary(role) -> str:
        """Kept for backwards compatibility. Returns a compact one-liner of compensation/shift fields."""
        pieces = []
        shift = getattr(role, "shift", None)
        if shift:
            pieces.append(f"Turno: {shift}")

        comp = CandidateDataFetcher._extract_compensation_fields(getattr(role, "compensation", None))
        if comp["salario"]:
            pieces.append(f"Salario: {comp['salario']}")
        if comp["neto_bruto"]:
            pieces.append(f"Tipo salario: {comp['neto_bruto']}")
        if comp["frecuencia_pago"]:
            pieces.append(f"Frecuencia de pago: {comp['frecuencia_pago']}")
        if comp["banco"]:
            pieces.append(f"Banco: {comp['banco']}")
        if comp["bonos"]:
            pieces.append(f"Bonos: {comp['bonos']}")
        return "; ".join(pieces)

    @staticmethod
    def _format_role_info_faqs(role_info) -> str:
        """Format role_info JSON Q&A pairs into readable text.

        Expected format: {"Q1": "...", "A1": "...", "Q2": "...", "A2": "...", ...}
        """
        if not isinstance(role_info, dict):
            return str(role_info).strip()
        pairs = []
        i = 1
        while True:
            q = role_info.get(f"Q{i}") or role_info.get(f"q{i}")
            a = role_info.get(f"A{i}") or role_info.get(f"a{i}")
            if q is None and a is None:
                break
            if q:
                pairs.append(f"  P{i}: {q}")
            if a:
                pairs.append(f"  R{i}: {a}")
            i += 1
        return "\n".join(pairs) if pairs else str(role_info).strip()

    @staticmethod
    def _role_info_text(role) -> str:
        """Build a comprehensive structured context block for a role.

        Includes ALL populated fields so the general-purpose assistant has
        the full picture to answer candidate questions.
        """
        sections = []

        # 1. Basic description
        role_description = getattr(role, "role_description", None)
        if role_description and str(role_description).strip():
            sections.append(f"Descripción: {str(role_description).strip()}")

        # 2. role_info FAQ Q&A pairs
        role_info = getattr(role, "role_info", None)
        if role_info:
            formatted = CandidateDataFetcher._format_role_info_faqs(role_info)
            if formatted:
                sections.append(f"Información del rol (preguntas frecuentes):\n{formatted}")

        # 3. Shift / schedule
        shift = getattr(role, "shift", None)
        if shift:
            sections.append(f"Turno / horario: {shift}")

        # 4. Compensation
        comp = CandidateDataFetcher._extract_compensation_fields(getattr(role, "compensation", None))
        comp_pieces = []
        if comp["salario"]:
            comp_pieces.append(f"Salario: {comp['salario']}")
        if comp["neto_bruto"]:
            comp_pieces.append(f"Tipo: {comp['neto_bruto']}")
        if comp["frecuencia_pago"]:
            comp_pieces.append(f"Frecuencia de pago: {comp['frecuencia_pago']}")
        if comp["banco"]:
            comp_pieces.append(f"Banco: {comp['banco']}")
        if comp["bonos"]:
            comp_pieces.append(f"Bonos: {comp['bonos']}")
        if comp_pieces:
            sections.append("Compensación: " + " | ".join(comp_pieces))

        # 5. Age requirements
        edades = getattr(role, "edades", None)
        if isinstance(edades, dict):
            min_age = edades.get("min")
            max_age = edades.get("max")
            if min_age is not None and max_age is not None:
                sections.append(f"Edad requerida: {min_age}–{max_age} años")
            elif min_age is not None:
                sections.append(f"Edad mínima: {min_age} años")
            elif max_age is not None:
                sections.append(f"Edad máxima: {max_age} años")

        # 6. Education level requirements
        education_level = getattr(role, "education_level", None)
        if isinstance(education_level, dict):
            level_labels = {
                "primaria": "Primaria",
                "secundaria": "Secundaria",
                "preparatoria": "Preparatoria",
                "preparatoria_tecnica": "Preparatoria técnica",
                "licenciatura": "Licenciatura",
            }
            required_levels = [label for key, label in level_labels.items() if education_level.get(key)]
            if required_levels:
                sections.append("Nivel educativo requerido: " + ", ".join(required_levels))

        # 7. Document requirements
        document_requirements = getattr(role, "document_requirements", None)
        if document_requirements:
            if isinstance(document_requirements, dict):
                docs = ", ".join(k for k, v in document_requirements.items() if v in ("required", "reminder"))
            elif isinstance(document_requirements, list):
                docs = ", ".join(str(d) for d in document_requirements if d)
            else:
                docs = str(document_requirements).strip()
            if docs:
                sections.append(f"Documentos requeridos: {docs}")

        # 8. Additional FAQs
        additional_faqs = getattr(role, "additional_faqs", None)
        if additional_faqs:
            if isinstance(additional_faqs, dict):
                formatted_faqs = CandidateDataFetcher._format_role_info_faqs(additional_faqs)
            elif isinstance(additional_faqs, list):
                formatted_faqs = "\n".join(f"  - {item}" for item in additional_faqs if item)
            else:
                formatted_faqs = str(additional_faqs).strip()
            if formatted_faqs:
                sections.append(f"Preguntas frecuentes adicionales:\n{formatted_faqs}")

        # 9. Arrival instructions
        indicaciones = getattr(role, "indicaciones_llegada", None)
        if indicaciones and str(indicaciones).strip():
            sections.append(f"Indicaciones de llegada: {str(indicaciones).strip()}")

        # 10. Transport PDF link
        transport_pdf_link = getattr(role, "transport_pdf_link", None)
        if transport_pdf_link and str(transport_pdf_link).strip():
            sections.append(f"Rutas de transporte (PDF): {str(transport_pdf_link).strip()}")

        # 11. HR contact
        hr_contact = getattr(role, "hr_contact", None)
        if hr_contact:
            if isinstance(hr_contact, dict):
                contact_pieces = []
                if hr_contact.get("name"):
                    contact_pieces.append(hr_contact["name"])
                if hr_contact.get("phone"):
                    contact_pieces.append(f"Tel: {hr_contact['phone']}")
                if hr_contact.get("email"):
                    contact_pieces.append(f"Email: {hr_contact['email']}")
                # legacy format: {"value": "..."}
                if not contact_pieces and hr_contact.get("value"):
                    contact_pieces.append(str(hr_contact["value"]))
                if contact_pieces:
                    sections.append("Contacto RH: " + ", ".join(contact_pieces))
            else:
                sections.append(f"Contacto RH: {str(hr_contact).strip()}")

        if not sections:
            return "Sin información adicional"

        return "\n".join(sections)

    def _get_role_context(self):
        if self.candidate.role_id:
            role = (
                self.session.query(Roles)
                .filter_by(role_id=self.candidate.role_id)
                .first()
            )
            if role:
                return f"[Rol asignado: {role.role_name}]\n{self._role_info_text(role)}"
            else:
                return "No se encontró información del rol asignado"
        else:
            roles = (
                self.session.query(Roles)
                .filter_by(business_unit_id=self.candidate.business_unit_id, is_active=True, is_deleted=False)
                .all()
            )
            if roles:
                role_blocks = []
                for role in roles:
                    block = f"[Rol disponible: {role.role_name}]\n{self._role_info_text(role)}"
                    role_blocks.append(block)
                return (
                    "El candidato aún no ha seleccionado un rol. "
                    "A continuación se muestra información de todos los roles disponibles en la empresa:\n\n"
                    + "\n\n".join(role_blocks)
                )
            return "No se encontraron roles para esta empresa"

    def _get_next_set_data(self):
        """Determines the next question set based on the candidate's role or company group."""
        role_set_id = None
        next_set_first_question = None
        next_set_first_question_id = None
        next_set_first_question_type = None
        role = None

        current_set_obj = (
            self.session.query(QuestionSets)
            .filter_by(set_id=self.set_id)
            .first()
        )

        if (
            current_set_obj
            and current_set_obj.group_id
            and not current_set_obj.business_unit_id
            and self.candidate.business_unit_id
        ):
            logging.info(
                "[CandidateDataFetcher] Candidate finished company_group set "
                f"{self.set_id}, assigning business unit general set as next set."
            )

            general_set_obj = (
                self.session.query(QuestionSets)
                .filter_by(business_unit_id=self.candidate.business_unit_id, general_set=True)
                .first()
            )

            if general_set_obj:
                first_question = (
                    self.session.query(ScreeningQuestions)
                    .filter_by(
                        set_id=general_set_obj.set_id,
                        position=1,
                        is_active=True,
                    )
                    .first()
                )

                return (
                    first_question.set_id if first_question else None,
                    first_question.question if first_question else None,
                    first_question.question_id if first_question else None,
                    first_question.response_type if first_question else None,
                    None,
                )

        # Resolve role early so it's available even when current set is NOT general.
        # This prevents role from showing as None in contexts like interview reminders
        # when the candidate is currently in a role-specific (general_set=False) set.
        if self.candidate.role_id:
            role = (
                self.session.query(Roles)
                .filter_by(role_id=self.candidate.role_id)
                .first()
            )

        current_set = (
            self.session.query(QuestionSets.general_set)
            .filter_by(set_id=self.set_id)
            .scalar()
        )
        if current_set is False:
            return (
                role_set_id,
                next_set_first_question,
                next_set_first_question_id,
                next_set_first_question_type,
                role,
            )

        if role is None:
            if self.candidate.role_id:
                role = (
                    self.session.query(Roles)
                    .filter_by(role_id=self.candidate.role_id)
                    .first()
                )
            else:
                role = (
                    self.session.query(Roles)
                    .filter_by(
                        business_unit_id=self.candidate.business_unit_id,
                        default_role=True,
                    )
                    .first()
                )
                # Update the role_id in candidates for the default role
                if role and not self.candidate.role_id:
                    try:
                        self.candidate.role_id = role.role_id
                        self.session.commit()
                        logging.info(
                            f"Assigned and saved role_id={role.role_id} (default) to candidate {self.candidate.candidate_id}."
                        )
                    except Exception as e:
                        logging.error(
                            f"Failed to save default role_id for candidate {self.candidate.candidate_id}: {e}"
                        )
                        self.session.rollback()

        if role and role.set_id:
            role_set_id = role.set_id

            first_question = (
                self.session.query(ScreeningQuestions)
                .filter_by(set_id=role_set_id, position=1, is_active=True)
                .first()
            )

            if first_question:
                next_set_first_question = first_question.question
                next_set_first_question_id = first_question.question_id
                next_set_first_question_type = first_question.response_type

        return (
            role_set_id,
            next_set_first_question,
            next_set_first_question_id,
            next_set_first_question_type,
            role,
        )

    def _resolve_interview_location(self, company_address, maps_link_json):
        """
        Resolves interview location based on role-specific interview location or fallback.
        Priority:
        1. Role's location_id_interview (if set)
        2. Company default address (fallback)
        3. Role's location_id (final fallback)
        """
        role = None
        if self.candidate.role_id:
            role = self.session.query(Roles).filter_by(role_id=self.candidate.role_id).first()

        if role and getattr(role, "location_id_interview", None):
            interview_loc_id = role.location_id_interview
            loc = self.session.query(Locations).filter_by(location_id=interview_loc_id).first()
            if loc:
                return {
                    "location_id": loc.location_id,
                    "address": getattr(loc, "address", None),
                    "url": getattr(loc, "url", None),
                    "latitude": getattr(loc, "latitude", None),
                    "longitude": getattr(loc, "longitude", None),
                }

        if company_address:
            return {
                "location_id": None,
                "address": company_address,
                "url": (maps_link_json or {}).get("location_link_1") if isinstance(maps_link_json, dict) else None,
                "latitude": None,
                "longitude": None,
            }

        if role and getattr(role, "location_id", None):
            regular_loc_id = role.location_id
            loc = self.session.query(Locations).filter_by(location_id=regular_loc_id).first()
            if loc:
                return {
                    "location_id": loc.location_id,
                    "address": getattr(loc, "address", None),
                    "url": getattr(loc, "url", None),
                    "latitude": getattr(loc, "latitude", None),
                    "longitude": getattr(loc, "longitude", None),
                }

        return {
            "location_id": None,
            "address": company_address,
            "url": (maps_link_json or {}).get("location_link_1") if isinstance(maps_link_json, dict) else None,
            "latitude": None,
            "longitude": None,
        }

    @staticmethod
    def _extract_hr_contact_fields(hr_contact) -> tuple:
        """
        Extracts hr_person_name and hr_person_phone from hr_contact JSON.
        
        hr_contact can be:
        - { "name": "...", "phone": "...", "email": "...", ... } (new format)
        - {"value": "..."} (legacy format, just a string value)
        - None
        
        Returns:
            tuple: (hr_person_name, hr_person_phone)
        """
        hr_person_name = None
        hr_person_phone = None
        
        if hr_contact and isinstance(hr_contact, dict):
            hr_person_name = hr_contact.get("name")
            hr_person_phone = hr_contact.get("phone")
        
        return hr_person_name, hr_person_phone

    @staticmethod
    def _extract_interview_time_bounds(interview_hours) -> tuple:
        """
        Extracts earliest and latest interview times from interview_hours list.
        
        interview_hours is a list of time strings like ["09:00", "09:30", "10:00"]
        
        Returns:
            tuple: (earliest_interview, latest_interview)
        """
        earliest_interview = None
        latest_interview = None
        
        if interview_hours and isinstance(interview_hours, list) and len(interview_hours) > 0:
            # Sort the hours to ensure we get the actual earliest and latest
            sorted_hours = sorted(interview_hours)
            earliest_interview = sorted_hours[0]
            latest_interview = sorted_hours[-1]
        
        return earliest_interview, latest_interview

    @staticmethod
    def _extract_compensation_fields(compensation) -> dict:
        """
        Extracts compensation fields from Roles.compensation JSON.

        Structure: {"banco": null, "bonos": {...}, "salario": "...", "neto_bruto": "neto", "frecuencia_pago": "mensual"}
        bonos can be nested, e.g. {"bono_bienvenida": {...}, "vales_despensa_mensual": {"monto": 459}}

        Returns:
            dict with keys: salario, neto_bruto, frecuencia_pago, banco, bonos (bonos as JSON string).
        """
        out = {
            "salario": None,
            "neto_bruto": None,
            "frecuencia_pago": None,
            "banco": None,
            "bonos": None,
        }
        if not compensation or not isinstance(compensation, dict):
            return out
        out["salario"] = compensation.get("salario")
        out["neto_bruto"] = compensation.get("neto_bruto")
        out["frecuencia_pago"] = compensation.get("frecuencia_pago")
        out["banco"] = compensation.get("banco")
        bonos = compensation.get("bonos")
        if bonos is not None:
            out["bonos"] = json.dumps(bonos, ensure_ascii=False) if isinstance(bonos, dict) else str(bonos)
        return out

    def get_data(self):
        if not self.candidate or not self.thread_id:
            logging.warning("Missing candidate or thread ID during data fetch.")
            return None

        if self.set_id is None or self.question_id is None:
            logging.error(
                "[SCREENING_CURSOR] get_data_aborted unresolved_cursor set_id=%s question_id=%s "
                "candidate_id=%s business_unit_id=%s company_group_id=%s "
                "(legacy would have defaulted set_id=1 question_id=1; see prior _get_set_and_question_id logs)",
                self.set_id,
                self.question_id,
                getattr(self.candidate, "candidate_id", None),
                getattr(self.candidate, "business_unit_id", None),
                getattr(self.candidate, "company_group_id", None),
            )
            return None

        (
            current_question,
            current_response_type,
            current_position,
            end_interview_answer,
            example_answer,
            next_question,
            next_question_response_type,
            next_question_id,
        ) = self._get_current_and_next_question()

        (
            role_set_id,
            next_set_first_question,
            next_set_first_question_id,
            next_set_first_question_type,
            role,
        ) = self._get_next_set_data()

        (
            company_name,
            company_description,
            company_address,
            company_benefits,
            company_general_faq,
            classifier_assistant_id,
            general_purpose_assistant_id,
            maps_link_json,
            interview_address_json,
            interview_days,
            interview_hours,
            hr_contact,
            interview_directions,
            context_role_name,
        ) = self._get_company_context()

        interview_date_str = (
            self.candidate.interview_date_time.strftime("%d/%m/%Y %I:%M %p")
            if self.candidate.interview_date_time
            else ""
        )

        interview_location = self._resolve_interview_location(company_address, maps_link_json)
        dynamic_map_link = interview_location.get("url")
        final_interview_address = self.candidate.interview_address or interview_location.get("address")
        final_interview_map_link = self.candidate.interview_map_link or dynamic_map_link

        # Extract HR contact fields for message templates
        hr_person_name, hr_person_phone = self._extract_hr_contact_fields(hr_contact)
        
        # Extract interview time bounds for message templates
        earliest_interview, latest_interview = self._extract_interview_time_bounds(interview_hours)
        
        # Determine role name: prefer from role object, fallback to context
        role_name = role.role_name if role else context_role_name

        document_requirements = (
            getattr(role, "document_requirements", None) if role else None
        )
        if isinstance(document_requirements, dict):
            documents_str = ", ".join(k for k, v in document_requirements.items() if v in ("required", "reminder"))
        elif isinstance(document_requirements, list):
            documents_str = ", ".join(str(item) for item in document_requirements)
        else:
            documents_str = ""

        # Role fields: shift, compensation (parsed), edades, education_level, transport_pdf_link
        role_shift = getattr(role, "shift", None) if role else None
        role_transport_pdf_link = getattr(role, "transport_pdf_link", None) if role else None
        role_edades = getattr(role, "edades", None) if role else None
        role_education_level = getattr(role, "education_level", None) if role else None
        compensation_raw = getattr(role, "compensation", None) if role else None
        compensation_fields = self._extract_compensation_fields(compensation_raw)

        # Extract full name and first word only for 'name'
        full_name = self.candidate.name or ""
        # 'name' contains only the first word of the candidate's given name (splits at first space)
        name = full_name.split()[0] if full_name.strip() else ""

        return {
            "wa_id": self.wa_id_user,
            "candidate_id": self.candidate.candidate_id,
            # full_name: Complete name as stored in database
            "full_name": full_name,
            # name: First word only of candidate's name (for friendly greetings in messages)
            "name": name,
            "first_name": name,
            "flow_state": self.candidate.flow_state,
            "first_question_flag": self.first_question_flag,
            "company_group_id": self.candidate.company_group_id,
            "business_unit_id": self.candidate.business_unit_id,
            "company_name": company_name,
            "thread_id": self.thread_id,
            "classifier_assistant_id": classifier_assistant_id,
            "general_purpose_assistant_id": general_purpose_assistant_id,
            "set_id": self.set_id,
            "next_set_id": role_set_id,
            "question_id": self.question_id,
            "current_question": current_question,
            "current_response_type": current_response_type,
            "current_position": current_position,
            "end_interview_answer": end_interview_answer,
            "example_answer": example_answer,
            "next_question": next_question,
            "next_question_response_type": next_question_response_type,
            "next_question_id": next_question_id,
            "next_set_first_question": next_set_first_question,
            "next_set_first_question_id": next_set_first_question_id,
            "next_set_first_question_type": next_set_first_question_type,
            "company_context": json.dumps(
                {
                    "Descripción": company_description,
                    "Ubicación_Vacante": company_address,
                    "Beneficios": company_benefits,
                    "Preguntas_Frecuentes": company_general_faq,
                    "Dias_Entrevista": interview_days,
                    "Horarios_Entrevista": interview_hours,
                    "hr_contact": hr_contact
                    if self.candidate.funnel_state == CandidateFunnelState.SCHEDULED_INTERVIEW.value
                    else None,
                },
                ensure_ascii=False,
            ),
            # Role information
            "role": role_name,
            "role_id": getattr(self.candidate, "role_id", None),
            "role_context": self._get_role_context(),
            "documents": documents_str,
            # Role: shift, compensation (parsed), edades, education_level, transport_pdf_link
            "shift": role_shift,
            "transport_pdf_link": role_transport_pdf_link,
            "edades": role_edades,
            "education_level": role_education_level,
            "compensation_salario": compensation_fields["salario"],
            "compensation_neto_bruto": compensation_fields["neto_bruto"],
            "compensation_frecuencia_pago": compensation_fields["frecuencia_pago"],
            "compensation_banco": compensation_fields["banco"],
            "compensation_bonos": compensation_fields["bonos"],
            # HR Contact fields extracted from JSON for message templates
            "hr_contact": hr_contact,
            "hr_person_name": hr_person_name,
            "hr_person_phone": hr_person_phone,
            # Interview scheduling information
            "travel_time_minutes": getattr(self.candidate, "travel_time_minutes", None),
            "funnel_state": self.candidate.funnel_state,
            "end_flow_rejected": self.candidate.end_flow_rejected,
            "interview_date": interview_date_str,
            "interview_address": self.candidate.interview_address,
            "interview_link": final_interview_map_link,
            "interview_directions": interview_directions,
            # Interview hours bounds for message templates
            "earliest_interview": earliest_interview,
            "latest_interview": latest_interview,
            "interview_days": interview_days,
            "interview_hours": interview_hours,
            "eligible_roles": self.candidate.eligible_roles or [],
            "maps_link_json": maps_link_json,
            "interview_address_json": interview_address_json,
            "interview_location": interview_location,
            "final_interview_address": final_interview_address,
            "final_interview_map_link": final_interview_map_link,
        }

