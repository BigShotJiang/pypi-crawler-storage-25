# from app import db
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.mutable import MutableList
from sqlalchemy import Index, CheckConstraint, text, create_engine, event
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.pool import NullPool
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.mutable import MutableDict


db = SQLAlchemy()


def build_db_url_from_settings(settings) -> str:
    """Build database URL from settings object."""
    return (
        f"postgresql+psycopg2://{settings.DB_USER}:{settings.DB_PASSWORD}"
        f"@{settings.DB_HOST}:{settings.DB_PORT}/{settings.DB_NAME}"
    )


class DBShim:
    """Database session manager for lambdas and non-Flask contexts."""
    def __init__(self, db_url: str):
        """Initialize DBShim with a database URL."""
        self.engine = create_engine(
            db_url,
            poolclass=NullPool,
            future=True,
            connect_args={
                "connect_timeout": 5,
                "options": "-c statement_timeout=30000 -c lock_timeout=10000",
            },
        )
        self._SessionFactory = sessionmaker(
            bind=self.engine,
            autoflush=False,
            autocommit=False,
            expire_on_commit=False,
            future=True,
        )
        self.Session = scoped_session(self._SessionFactory)
        
        # Bind Flask-SQLAlchemy models metadata to this engine
        # This allows using db.Model classes with explicit sessions
        db.Model.metadata.bind = self.engine

    @classmethod
    def from_settings(cls, settings) -> "DBShim":
        """Create DBShim from settings object."""
        return cls(build_db_url_from_settings(settings))

    @property
    def session(self):
        """Get a new database session."""
        return self.Session()

    def remove_session(self):
        """Remove the current session from the scoped session registry."""
        self.Session.remove()

ResponseTypeEnum = db.Enum(
    'text', 'location', 'voice', 'phone_reference', 'interactive', 'name', 'location_critical', 
    name='response_type_enum', 
    create_type=False
)
CompanyScreeningGroupLogicEnum = db.Enum(
    'BUSINESS_UNIT', 
    'ROLES', 
    name='company_screening_group_logic_enum', 
    create_type=False
)
UserPermissionEnum = db.Enum(
    'ENABLE_BILLING_TAB',
    'ENABLE_BUSINESS_UNIT_EDIT_TAB',
    'ENABLE_INTERVIEWED_CANDIDATES_EDIT_TAB',
    name='user_permission_enum',
    create_type=False
)

# TODO
# 1. Create a table to define what we show in the dashboard for each user and company group [DONE]
# 2. Expand CompanyGroups attributes [PENDING]
# 3. Define where we will define which funnel states require a business unit [PENDING]


class Users(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    cognito_sub = db.Column(db.String(255), unique=True, nullable=False, index=True)

    is_admin = db.Column(db.Boolean, nullable=False, default=False)
    permissions = db.Column(db.ARRAY(UserPermissionEnum), nullable=True)

    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"), onupdate=db.text("now()"))
    last_login_at = db.Column(db.DateTime(timezone=True), nullable=True)

    notify_interviews = db.Column(db.JSON, nullable=True)
    notify_pulse = db.Column(db.JSON, nullable=True)

    company_group_ids = db.Column(db.JSON, nullable=True) 
    business_unit_ids = db.Column(db.JSON, nullable=True)

    def __repr__(self):
        return f'<User {self.id} {self.email}>'


# Company Information Tables
class CompanyGroups(db.Model):
    __tablename__ = "company_groups"

    company_group_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    website = db.Column(db.Text)
    wa_id = db.Column(db.String(50))
    phone = db.Column(db.String(50))
    meta_business_id = db.Column(db.String(50), nullable=True)

    company_screening_group_logic = db.Column(CompanyScreeningGroupLogicEnum)
    # When True, QR registration flow shows business units in the group (candidate selects BU, role_id left blank).
    # When False, flow shows roles for the business unit tied to the QR (current behavior).
    qr_flow_select_business_units = db.Column(db.Boolean, nullable=False, server_default=db.text("false"), default=False)

    __table_args__ = (
        db.Index("idx_company_groups_name", "name"),
    )
    

# Financial data model structure:
#
# company_groups:
#   Represents the billing entity (customer). This is the anchor table.
#
# invoices:
#   Represents commercial charges issued to a company_group.
#   Each invoice belongs to one company_group (company_group_id FK).
#   Stores quantity, unit_price, subtotal, vat, total,
#   and total_amount_paid (maintained incrementally).
#
# payments:
#   Represents cash received from a company_group.
#   Each payment belongs to one company_group and may optionally
#   be linked to a specific invoice (invoice_id FK).
#   One invoice can have multiple payments.
#
# Relationships:
#   company_group (1) → (many) invoices
#   company_group (1) → (many) payments
#   invoice (1) → (many) payments
#
# Invoice balance is computed as:
#   balance = total - total_amount_paid
#
# total_amount_paid is auto-filled by a DB trigger on the payments table: it is set to
# SUM(payments.amount) for the invoice. Run the following in psql to create the function
# and trigger (and backfill existing rows):
#
#   CREATE OR REPLACE FUNCTION sync_invoice_total_amount_paid(invoice_id_to_sync INTEGER)
#   RETURNS void LANGUAGE plpgsql AS $$
#   BEGIN
#     IF invoice_id_to_sync IS NULL THEN RETURN; END IF;
#     UPDATE invoices
#     SET total_amount_paid = COALESCE(
#       (SELECT SUM(amount) FROM payments WHERE invoice_id = invoice_id_to_sync), 0
#     )
#     WHERE invoice_id = invoice_id_to_sync;
#   END;
#   $$;
#
#   CREATE OR REPLACE FUNCTION trigger_sync_invoice_total_amount_paid()
#   RETURNS TRIGGER LANGUAGE plpgsql AS $$
#   BEGIN
#     IF TG_OP = 'INSERT' AND NEW.invoice_id IS NOT NULL THEN
#       PERFORM sync_invoice_total_amount_paid(NEW.invoice_id);
#     ELSIF TG_OP = 'UPDATE' THEN
#       IF OLD.invoice_id IS NOT NULL THEN PERFORM sync_invoice_total_amount_paid(OLD.invoice_id); END IF;
#       IF NEW.invoice_id IS NOT NULL AND (OLD.invoice_id IS DISTINCT FROM NEW.invoice_id OR OLD.amount IS DISTINCT FROM NEW.amount) THEN
#         PERFORM sync_invoice_total_amount_paid(NEW.invoice_id);
#       END IF;
#     ELSIF TG_OP = 'DELETE' AND OLD.invoice_id IS NOT NULL THEN
#       PERFORM sync_invoice_total_amount_paid(OLD.invoice_id);
#     END IF;
#     RETURN COALESCE(NEW, OLD);
#   END;
#   $$;
#
#   DROP TRIGGER IF EXISTS payments_sync_invoice_total_amount_paid ON payments;
#   CREATE TRIGGER payments_sync_invoice_total_amount_paid
#     AFTER INSERT OR UPDATE OF invoice_id, amount OR DELETE ON payments
#     FOR EACH ROW EXECUTE PROCEDURE trigger_sync_invoice_total_amount_paid();
#
#   UPDATE invoices i
#   SET total_amount_paid = COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.invoice_id = i.invoice_id), 0);


class Invoices(db.Model):
    __tablename__ = "invoices"

    invoice_id = db.Column(db.Integer, primary_key=True)

    company_group_id = db.Column(
        db.Integer,
        db.ForeignKey("company_groups.company_group_id"),
        nullable=False,
        index=True
    )

    invoice_number = db.Column(db.String(100))
    invoice_type = db.Column(db.String(50), nullable=False)

    date_sent = db.Column(db.Date)

    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)

    # Commercial breakdown
    quantity = db.Column(db.Numeric(12, 2), nullable=False)
    unit_price = db.Column(db.Numeric(12, 4), nullable=False)

    subtotal = db.Column(db.Numeric(12, 2), nullable=False)
    vat = db.Column(db.Numeric(12, 2), nullable=False)
    total = db.Column(db.Numeric(12, 2), nullable=False)

    # Auto-filled by DB trigger: SUM(payments.amount) for this invoice (see trigger in comment above).
    total_amount_paid = db.Column(db.Numeric(12, 2), nullable=False, server_default=db.text("0"))

    # Files (S3 URLs)
    pdf_url = db.Column(db.Text)
    xml_url = db.Column(db.Text)

    created_at = db.Column(db.DateTime, server_default=db.func.now())

    # Lifecycle status (see descriptions below).
    # issued: Invoice was issued and sent to the customer; it should exist in S3 as PDF and XML.
    # pending: Customer is already using the product but we cannot issue the invoice yet (missing
    #   billing information or supplier onboarding).
    # cancelled: Invoice was issued but had to be cancelled.
    # projected: Invoice that will be issued with high certainty in the future; will become
    #   "issued" when the time comes.
    status = db.Column(db.Text, nullable=True)

    # Number of candidate screenings the customer can use with this invoice.
    credits = db.Column(db.Integer, nullable=True)

    __table_args__ = (
        CheckConstraint(
            "status IS NULL OR status IN ('issued', 'pending', 'cancelled', 'projected')",
            name="invoices_status_check",
        ),
    )


class Payments(db.Model):
    __tablename__ = "payments"

    payment_id = db.Column(db.Integer, primary_key=True)

    company_group_id = db.Column(
        db.Integer,
        db.ForeignKey("company_groups.company_group_id"),
        nullable=False,
        index=True
    )

    invoice_id = db.Column(
        db.Integer,
        db.ForeignKey("invoices.invoice_id"),
        nullable=True
    )

    payment_date = db.Column(db.Date, nullable=False)

    amount = db.Column(db.Numeric(12, 2), nullable=False)  # always positive

    created_at = db.Column(db.DateTime, server_default=db.func.now())


class BusinessUnits(db.Model):
    __tablename__ = "business_units"

    # General Business Unit Information
    business_unit_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    # NOTE: latitude, longitude, address, hr_contact, interview_address_json, maps_link_json
    # have been moved to Roles table and Locations table.
    # Access location info via: Roles.location_id -> Locations (for work location)
    # Access interview location via: Roles.location_id_interview -> Locations (for interview location)
    # Access hr_contact via: Roles.hr_contact
    # 
    # default_location_id: Fallback location when role doesn't have a location or no role is specified.
    # This is the primary fallback before querying any location for the business unit.
    default_location_id = db.Column(db.Integer, db.ForeignKey("locations.location_id", ondelete="SET NULL"), nullable=True)
    website = db.Column(db.Text) 
    benefits = db.Column(MutableList.as_mutable(db.JSON), default=list) # PENDING: move to roles table
    general_faq = db.Column(db.JSON)   # TODO: Define General FAQ Structure - what it will include
    
    phone = db.Column(db.String)

    # JSON format: {"english_key": "Display Label in Spanish", ...} WILL ALWAYS HAVE rejected, hired 
    # "rejected": "Rechazado", "union_hr_interview": "Entrevista con Sindicato y RH", "client_interview": "Entrevista con cliente", "hired": "Contratado"
    funnel_states_business_unit = db.Column(db.JSON) 
    
    description = db.Column(db.Text)
    additional_info = db.Column(db.Text)
    
    # Interview Information
    interview_excluded_dates = db.Column(MutableList.as_mutable(db.JSON), default=list)
    interview_days = db.Column(MutableList.as_mutable(db.JSON), default=list)
    interview_hours = db.Column(MutableList.as_mutable(db.JSON), default=list)
    max_interviews_per_slot = db.Column(db.Integer, nullable=True)
    

    # Assistant Information
    classifier_assistant_id = db.Column(db.String)
    general_purpose_assistant_id = db.Column(db.String)
    ad_trigger_phrase = db.Column(db.Text)
    reminder_schedule = db.Column(db.JSON, nullable=False, default=dict)
    customer_id = db.Column(db.String(50))
    timezone = db.Column(db.String(50), nullable=False, server_default=text("'America/Mexico_City'"), default="America/Mexico_City")
    qr_attendance_s3_path = db.Column(db.String(500), nullable=True)
    referral_options = db.Column(
        db.JSON,
        nullable=True,
        server_default=text("""'["Facebook","Flyer","Manta de la Empresa","Referido","Otra"]'""")
    )
    maximum_location_km = db.Column(db.Float, nullable=True, server_default=db.text("30.0"), default=30.0)
    
    # Rejection reasons configuration for this business unit
    # JSON format: {"english_key": "Display Label in Spanish", ...}
    # Example: {"abscense": "Falta a entrevista", "missing_documents": "Falta de documentos", ...}
    rejection_reasons = db.Column(db.JSON, nullable=True)
    
    # Meta Business Information
    wa_id = db.Column(db.String)
    company_is_verified_by_meta = db.Column(db.Boolean, nullable=False, server_default=db.text("true"), default=True)

    # Company Group Information
    company_group_id = db.Column(db.Integer, db.ForeignKey("company_groups.company_group_id", ondelete="SET NULL"))

    # Relationship for default location
    default_location = db.relationship("Locations", foreign_keys=[default_location_id], backref="default_for_business_units")

    __table_args__ = (
        CheckConstraint("char_length(description) <= 250", name="description_length_check"),
        db.Index("idx_business_units_default_location", "default_location_id"),
    )


class ProductUsage(db.Model):
    __tablename__ = "product_usage"
    
    product_usage_id = db.Column(db.Integer, primary_key=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete="CASCADE"), nullable=False)
    
    # Feature flags for product usage
    eligibility = db.Column(db.Boolean, nullable=False, default=False)
    phone_interviews = db.Column(db.Boolean, nullable=False, default=False)
    qr_code = db.Column(db.Boolean, nullable=False, default=False)
    employee_onboarding = db.Column(db.Boolean, nullable=False, default=False)
    
    # Relationship
    business_unit = db.relationship("BusinessUnits", backref="product_usage")


class DashboardConfigurations(db.Model):
    __tablename__ = "dashboard_configurations"

    dashboard_configuration_id = db.Column(db.Integer, primary_key=True)
    funnel_states_baltra = db.Column(db.JSON) # ['Evaluados', 'Citados', 'Entrevistados', 'Contratados', 'Ingresados']
    
    show_lastest_ad_campaigns = db.Column(db.Boolean, nullable=False, default=True)
    show_hiring_volume = db.Column(db.Boolean, nullable=False, default=True)
    show_phone_interview_information = db.Column(db.Boolean, nullable=False, default=True)
    show_onboarding_tab = db.Column(db.Boolean, nullable=False, default=True)
    show_business_unit_profile_tab = db.Column(db.Boolean, nullable=False, default=True)

    interviewed_candidates_keys = db.Column(db.JSON)

    # --- interviewed_candidates_keys (JSON object on dashboard_configurations) ---
    # Defines Entrevistados table columns per business unit.
    #
    # Legacy (string value):  "Column label" -> field key; cell values live in
    #   Candidates.interviewed_candidates_keys[field_key] (plus DB hooks for "estado").
    #
    # Typed custom (object value):  "Column label" -> {"key": "storage_key", "type": "text"|"select", "options": [...]}
    #   Cell values live in Candidates.especific_business_unit_attributes[storage_key].
    #   Edits from the app use GraphQL updateCandidate with especificBusinessUnitAttributes as a JSON object;
    #   the API merges incoming keys into the existing JSON (does not replace the whole blob).
    #
    # Example:
    #   {"Estado": "estado",
    #    "Entrevistador": {"key": "entrevistador", "type": "select", "options": ["1","2","3","4"]},
    #    "Notas": {"key": "notas", "type": "text"}}

    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete="CASCADE"), nullable=False)


class HiringObjectives(db.Model):
    __tablename__ = "hiring_objectives"

    hiring_objective_id = db.Column(db.Integer, primary_key=True)
    company_group_id = db.Column(db.Integer, db.ForeignKey('company_groups.company_group_id', ondelete="CASCADE"), nullable=False) 
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete="CASCADE"), nullable=False)
    
    role_id = db.Column(db.Integer, db.ForeignKey('roles.role_id', ondelete="CASCADE"), nullable=False)
    objective_amount = db.Column(db.Integer, nullable=False)

    objective_type = db.Column(db.Text, nullable=False)
    objective_name = db.Column(db.Text, nullable=False)
    objective_duration = db.Column(db.Date, nullable=False)
    objective_period_year = db.Column(db.Integer, nullable=False)
    objective_period_month = db.Column(db.Integer, nullable=False)
    objective_created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))


class Roles(db.Model):
    __tablename__ = 'roles'

    role_id = db.Column(db.Integer, primary_key=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete="CASCADE"), nullable=False)
    role_name = db.Column(db.Text, nullable=False)
    # role_description: Plain text description of the role
    role_description = db.Column(db.Text)
    # role_info: JSON containing FAQ Q&A pairs in format { "Q1": "...", "A1": "...", "Q2": "...", "A2": "...", ... }
    role_info = db.Column(db.JSON)
    is_active = db.Column(db.Boolean, default=True)
    set_id = db.Column(db.Integer, db.ForeignKey('question_sets.set_id', ondelete="SET NULL"))
    eligibility_criteria = db.Column(db.JSON)
    default_role = db.Column(db.Boolean, default=False)
    is_deleted = db.Column(db.Boolean, default=False)
    # role_list_subtitle: Subtitle shown in WhatsApp list messages when candidates select a role (max 72 chars)
    # NOTE: This was renamed from 'shift' column. The old 'shift' was being used for list subtitles.
    role_list_subtitle = db.Column(db.Text)
    # shift: Actual shift/schedule information for the role (e.g., "Lunes a Viernes 8am-5pm")
    shift = db.Column(db.Text)
    location_id = db.Column(db.Integer, db.ForeignKey("locations.location_id", ondelete="SET NULL"))
    location_id_interview = db.Column(db.Integer, db.ForeignKey("locations.location_id", ondelete="SET NULL"))
    # HR contact information for this role
    # JSON format: { "name": "...", "phone": "...", "email": "...", ... } or legacy string wrapped in {"value": "..."}
    hr_contact = db.Column(db.JSON)
    
    # Arrival instructions for candidates (max 250 chars)
    indicaciones_llegada = db.Column(db.String(250))
    
    # Role-specific requirements and information
    document_requirements = db.Column(db.JSON)  # List of required documents for this role
    transport_pdf_link = db.Column(db.Text)  # Link to transport/commute PDF for this role
    
    # Compensation structure: {"banco": null, "bonos": null, "salario": "Sueldo mensual neto entre $9,642 y $11,000 (depende de la experiencia).", "neto_bruto": "neto", "frecuencia_pago": "mensual"}
    #Bonos entry is nested JSONStructure: bonos": {"bono_bienvenida": {"tipo": "bruto", "lunes": 906, "martes": 604, "miercoles": 302}, "bono_desarrollo": {"tipo": "bruto", "monto": 500}, "vales_despensa_mensual": {"monto": 459}}
    compensation = db.Column(db.JSON)
    
    # Age requirements: { "min": number, "max": number }
    edades = db.Column(db.JSON)
    
    # Education level requirements: { "primaria": bool, "secundaria": bool, "preparatoria": bool, "preparatoria_tecnica": bool, "licenciatura": bool }
    education_level = db.Column(db.JSON)
    
    additional_faqs = db.Column(db.JSON)  # Role-specific FAQs
    
    # Relationships for location access
    location = db.relationship("Locations", foreign_keys=[location_id], backref="roles_work")
    location_interview = db.relationship("Locations", foreign_keys=[location_id_interview], backref="roles_interview")

    __table_args__ = (
        CheckConstraint("char_length(role_name) <= 24", name="role_name_length_check"),
        CheckConstraint("char_length(role_list_subtitle) <= 72", name="role_list_subtitle_length_check"),
    )
    
class Locations(db.Model):
    __tablename__ = 'locations'

    location_id = db.Column(db.Integer, primary_key=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete='CASCADE'), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    url = db.Column(db.Text)
    address = db.Column(db.Text)

    # Relationships
    # NOTE: foreign_keys is required because BusinessUnits also has default_location_id FK to Locations
    # Without it, SQLAlchemy can't determine which FK path to use for the join
    business_unit = db.relationship("BusinessUnits", foreign_keys=[business_unit_id], backref="locations")

    # Constraints
    __table_args__ = (
        db.CheckConstraint('latitude BETWEEN -90 AND 90', name='check_valid_latitude'),
        db.CheckConstraint('longitude BETWEEN -180 AND 180', name='check_valid_longitude'),
        db.Index('idx_locations_business_unit', 'business_unit_id'),
    )



# Candidate Information Tables
class Candidates(db.Model):
    __tablename__ = "candidates"

    candidate_id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(30), nullable=False)
    name = db.Column(db.Text)
    age = db.Column(db.Integer)
    gender = db.Column(db.Text)
    education_level = db.Column(db.Text)
    source = db.Column(db.Text)
    referred_by = db.Column(db.Text, nullable=True, server_default="Baltra", default="Baltra")
    grade = db.Column(db.Integer)
    funnel_state = db.Column(db.Text)
    funnel_state_business_unit = db.Column(db.Text, nullable=True)
    
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    start_date = db.Column(db.Date)


    interview_date_time = db.Column(db.DateTime(timezone=True))
    interview_reminder_sent = db.Column(db.Boolean, nullable=False, default=False)
    interview_address = db.Column(db.Text)
    interview_map_link = db.Column(db.Text)
    interview_confirmed = db.Column(db.Boolean, default=None)
    interview_reminders_sent = db.Column(
        MutableDict.as_mutable(JSONB),
        nullable=False,
        server_default=db.text(
            """'{
              "interview_reminder_night_before": false,
              "interview_reminder_same_morning": false,
              "interview_reminder_1_hour": false
            }'::jsonb"""
        ),
        default=lambda: {
            "interview_reminder_night_before": False,
            "interview_reminder_same_morning": False,
            "interview_reminder_1_hour": False,
        },
    )

    interviewed_candidates_keys = db.Column(db.JSON, nullable=True)
    
    travel_time_minutes = db.Column(db.Integer, server_default='0')
    application_reminders_sent = db.Column(
        MutableDict.as_mutable(JSONB),
        nullable=False,
        server_default=db.text(
            """'{
              "application_reminder_1h": null,
              "application_reminder_2h": null,
              "application_reminder_24h": null
            }'::jsonb"""
        ),
        default=lambda: {
            "application_reminder_1h": None,
            "application_reminder_2h": None,
            "application_reminder_24h": None,
        },
    )
    application_reminder_sent = db.Column(db.Boolean, default=False)
    agent_type = db.Column(db.String(10), nullable=True)
    flow_state = db.Column(db.String(50), nullable=False, server_default="respuesta")
    eligible_roles = db.Column(db.JSON)
    reschedule_sent = db.Column(db.Boolean, default=False)
    rejected_reason = db.Column(db.Text)
    screening_rejected_reason = db.Column(db.Text)
    end_flow_rejected = db.Column(db.Boolean, nullable=False, default=False)
    worked_here = db.Column(db.Boolean, nullable=True) 
    eligible_companies = db.Column(db.JSON, nullable=True)
    appointment_reminder_counters = db.Column(db.JSON, nullable=True, default=lambda: {"phone_call_count": 0, "message_count": 0})
    coordinates_json = db.Column(db.JSON, nullable=True)

    # Specific Business Unit Attributes
    especific_business_unit_attributes = db.Column(db.JSON, nullable=True)
    
    # Business unit funnel state for this candidate
    business_unit_funnel_state = db.Column(db.Text)

    # Facebook Click-to-WhatsApp Ad attribution (populated from Meta referral on first message).
    # Stores the full referral object; key fields: ctwa_clid, source_id, source_url, source_type.
    # none_as_null: Python None -> SQL NULL (not JSON null), so IS NOT NULL / filters behave correctly.
    fb_referral = db.Column(db.JSON(none_as_null=True), nullable=True)

    # Relationships
    company_group_id = db.Column(db.Integer, db.ForeignKey("company_groups.company_group_id"), nullable=True)
    role_id = db.Column(db.Integer, db.ForeignKey("roles.role_id", ondelete="SET NULL"))
    business_unit_id = db.Column(db.Integer, db.ForeignKey("business_units.business_unit_id", ondelete="CASCADE"))
    

    __table_args__ = (
        db.PrimaryKeyConstraint('candidate_id', name='candidates_pkey1'),
        db.Index('idx_candidates_company_group_id', 'company_group_id'),
        db.Index('idx_candidates_business_unit_id', 'business_unit_id'),
        db.Index('idx_candidates_company_group_name', 'company_group_id', 'name'),
        db.Index('idx_candidates_capacity_check', 'business_unit_id', 'interview_date_time', 'funnel_state'),  # For capacity checking performance
        # Optional functional index for case-insensitive prefix searches (requires migration support in production)
        # db.Index('idx_candidates_company_lower_name', db.text('company_group_id'), db.text('lower(name)')),
    )

class CandidateFunnelLog(db.Model):
    __tablename__ = 'candidate_funnel_logs'

    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidates.candidate_id', ondelete='CASCADE'), nullable=False)
    previous_funnel_state = db.Column(db.Text)
    new_funnel_state = db.Column(db.Text, nullable=False)
    changed_at = db.Column(db.DateTime, nullable=False, server_default=db.text("CURRENT_TIMESTAMP"))

    # Relationship to Candidate
    candidate = db.relationship("Candidates", backref="funnel_logs")

    __table_args__ = (
        db.Index('candidate_funnel_candidate_id_idx', 'candidate_id'),
        db.Index('candidate_funnel_new_funnel_state_idx', 'new_funnel_state'),
        db.Index('idx_cfl_candidate_changed', 'candidate_id', db.text('changed_at DESC')),
        db.Index('idx_cfl_changed_at', 'changed_at'),
        db.Index('idx_cfl_prev_new_changed', 'previous_funnel_state', 'new_funnel_state', 'changed_at'),
        db.Index('idx_cfl_new_state', 'new_funnel_state'),
    )


# Candidate Interaction Guides Tables
class QuestionSets(db.Model):
    __tablename__ = "question_sets"

    set_id = db.Column(db.Integer, primary_key=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey("business_units.business_unit_id", ondelete="CASCADE"), nullable=True)
    set_name = db.Column(db.Text, nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    general_set = db.Column(db.Boolean, nullable=False, default=False)
    group_id = db.Column(db.Integer, db.ForeignKey("company_groups.company_group_id", ondelete="CASCADE"),nullable=True)

    business_unit = db.relationship("BusinessUnits", backref="question_sets")
    group = db.relationship("CompanyGroups", backref="question_sets")
    screening_questions = db.relationship("ScreeningQuestions", backref="question_set", cascade="all, delete-orphan")
    __table_args__ = (
        Index(
            'one_general_set_per_business_unit',
            'business_unit_id',
            'group_id',
            unique=True,
            postgresql_where=db.text('general_set IS TRUE')
        ),
        db.CheckConstraint(
            "(business_unit_id IS NOT NULL AND group_id IS NULL) OR "
            "(business_unit_id IS NULL AND group_id IS NOT NULL)",
            name="business_unit_or_group"
        ),
    )

class ScreeningQuestions(db.Model):
    __tablename__ = "screening_questions"

    question_id = db.Column(db.Integer, primary_key=True)
    set_id = db.Column(db.Integer, db.ForeignKey("question_sets.set_id", ondelete="CASCADE"), nullable=False)
    position = db.Column(db.SmallInteger, nullable=False)
    question = db.Column(db.Text, nullable=False)
    response_type = db.Column(ResponseTypeEnum, nullable=False)
    question_metadata = db.Column(db.JSON)
    end_interview_answer = db.Column(db.Text)
    example_answer = db.Column(db.Text)
    is_blocked = db.Column(db.Boolean, default=False)
    eligibility_question = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)

    # Relationships
    screening_answers = db.relationship("ScreeningAnswers", backref="question", cascade="all, delete-orphan")

    __table_args__ = (
        db.UniqueConstraint('set_id', 'position', name='screening_questions_set_id_position_key'),
        db.Index('idx_questions_set_pos', 'set_id', 'position')
    )

class ScreeningAnswers(db.Model):
    __tablename__ = "screening_answers"

    answer_id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey("screening_questions.question_id", ondelete="CASCADE"), nullable=False)
    answer_raw = db.Column(db.Text)
    answer_json = db.Column(db.JSON)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))

    __table_args__ = (
        db.UniqueConstraint('candidate_id', 'question_id', name='screening_answers_candidate_id_question_id_key'),
        db.Index('idx_answers_candidate', 'candidate_id'),
        db.Index('idx_answers_question', 'question_id')
    )

class MessageTemplates(db.Model):
    __tablename__ = 'message_templates'

    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.Text, nullable=False)
    button_trigger = db.Column(db.Text)
    type = db.Column(db.Text, nullable=False)
    text = db.Column(db.Text)
    interactive_type = db.Column(db.Text)
    button_keys = db.Column(db.JSON)
    footer_text = db.Column(db.Text)
    header_type = db.Column(db.Text)
    header_content = db.Column(db.Text)
    parameters = db.Column(db.JSON)
    template = db.Column(db.Text)
    variables = db.Column(db.JSON)
    url_keys = db.Column(db.JSON)
    header_base = db.Column(db.Text)
    flow_keys = db.Column(db.JSON)
    flow_action_data = db.Column(db.JSON)
    document_link = db.Column(db.Text)  # renamed from 'link'
    filename = db.Column(db.Text)
    flow_name = db.Column(db.Text)
    flow_cta = db.Column(db.Text)
    list_options = db.Column(db.JSON)             # [{"id": "opt_1", "title": "Sí", "description": "Confirmar asistencia"}]
    list_section_title = db.Column(db.Text)  
    display_name = db.Column(db.Text)
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete="CASCADE"))
    
    business_unit = db.relationship("BusinessUnits", backref="message_templates")

class PhoneInterviewQuestions(db.Model):
    __tablename__ = 'phone_interview_questions'

    id = db.Column(db.Integer, primary_key=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete='CASCADE'), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('roles.role_id', ondelete='SET NULL'))
    question_text = db.Column(db.Text, nullable=False)
    position = db.Column(db.SmallInteger, nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text('now()'))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text('now()'))

    # Relationships
    business_unit = db.relationship('BusinessUnits', backref='phone_interview_questions')
    role = db.relationship('Roles', backref='phone_interview_questions')

    __table_args__ = (
        db.Index('idx_phone_q_business_unit_role_pos', 'business_unit_id', 'role_id', 'position'),
        db.Index('idx_phone_q_business_unit', 'business_unit_id'),
    )



# Candidate Interaction History Tables
class PhoneInterviews(db.Model):
    __tablename__ = "phone_interviews"

    interview_id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"), nullable=False)
    business_unit_id = db.Column(db.Integer, db.ForeignKey("business_units.business_unit_id", ondelete="CASCADE"), nullable=False)
    elevenlabs_call_id = db.Column(db.String(255), unique=True, nullable=False)
    call_status = db.Column(db.String(50), nullable=False)  # 'completed', 'failed', 'missed', 'scheduled'
    call_duration = db.Column(db.Integer)  # in seconds
    started_at = db.Column(db.DateTime(timezone=True))
    ended_at = db.Column(db.DateTime(timezone=True))
    transcript = db.Column(db.Text)
    summary = db.Column(db.Text)
    ai_score = db.Column(db.Integer)  # AI-generated interview score (1-100)
    ai_recommendation = db.Column(db.String(50))  # 'recommended', 'not_recommended', 'pending_review'
    thread_id_openai = db.Column(db.String(255))  # OpenAI thread ID used for transcript evaluation
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))

    # Relationships
    candidate = db.relationship("Candidates", backref="phone_interviews")
    business_unit = db.relationship("BusinessUnits", backref="phone_interviews")

    __table_args__ = (
        db.Index('idx_phone_interviews_candidate', 'candidate_id'),
        db.Index('idx_phone_interviews_business_unit', 'business_unit_id'),
        db.Index('idx_phone_interviews_vapi_call', 'elevenlabs_call_id'),
        db.Index('idx_phone_interviews_status', 'call_status'),
    )

    def __repr__(self):
        return f'<PhoneInterview {self.interview_id}: candidate_id={self.candidate_id}, status={self.call_status}>'


class ReminderCalls(db.Model):
    __tablename__ = "reminder_calls"

    reminder_call_id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"), nullable=False)
    business_unit_id = db.Column(db.Integer, db.ForeignKey("business_units.business_unit_id", ondelete="CASCADE"), nullable=False)
    elevenlabs_call_id = db.Column(db.String(255), unique=True, nullable=False)
    call_status = db.Column(db.String(50), nullable=False)  # 'completed', 'failed', 'no_answer'
    call_duration = db.Column(db.Integer)  # in seconds
    started_at = db.Column(db.DateTime(timezone=True))
    ended_at = db.Column(db.DateTime(timezone=True))
    transcript = db.Column(db.Text)
    summary = db.Column(db.Text)
    outcome = db.Column(db.String(50))  # 'confirmed', 'canceled', 'rescheduled', 'no_answer', 'unknown'
    original_interview_datetime = db.Column(db.DateTime(timezone=True))  # snapshot at call time
    rescheduled_to = db.Column(db.DateTime(timezone=True))  # new datetime if rescheduled
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))

    # Relationships
    candidate = db.relationship("Candidates", backref="reminder_calls")
    business_unit = db.relationship("BusinessUnits", backref="reminder_calls")

    __table_args__ = (
        db.Index('idx_reminder_calls_candidate', 'candidate_id'),
        db.Index('idx_reminder_calls_business_unit', 'business_unit_id'),
        db.Index('idx_reminder_calls_elevenlabs_call', 'elevenlabs_call_id'),
        db.Index('idx_reminder_calls_outcome', 'outcome'),
    )

    def __repr__(self):
        return f'<ReminderCall {self.reminder_call_id}: candidate_id={self.candidate_id}, outcome={self.outcome}>'


class WhatsappStatusUpdates(db.Model):
    __tablename__ = 'whatsapp_status_updates'

    id = db.Column(db.Integer, primary_key=True)
    object_type = db.Column(db.String(50))
    entry_id = db.Column(db.BigInteger)
    messaging_product = db.Column(db.String(50))
    wa_id = db.Column(db.String(15))
    phone_number_id = db.Column(db.String(50))
    message_body = db.Column(db.Text)
    conversation_id = db.Column(db.String(50))
    origin_type = db.Column(db.String(50))
    billable = db.Column(db.Boolean)
    pricing_model = db.Column(db.String(50))
    category = db.Column(db.String(50))
    status = db.Column(db.String(20))
    timestamp = db.Column(db.BigInteger)
    field = db.Column(db.String(50))
    status_id = db.Column(db.String(100))
    lag_killed = db.Column(db.Boolean, default=False)
    campaign_id = db.Column(db.String(100))
    # none_as_null: Python None -> SQL NULL (not JSON null).
    error_info = db.Column(db.JSON(none_as_null=True))
    referral = db.Column(db.JSON(none_as_null=True), nullable=True)


class MetaPixelEvents(db.Model):
    """Audit log of Conversions API / Meta Pixel–style events sent for attribution and custom audiences."""

    __tablename__ = "meta_pixel_events"

    # PostgreSQL: SERIAL (auto-increment). SQLAlchemy maps Integer + PK + autoincrement to SERIAL.
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # Dedup key: typically f"{event_name}_{candidate_id}_{event_time}" (or Meta-compatible event_id string).
    event_id = db.Column(db.Text, nullable=False, unique=True)
    candidate_id = db.Column(
        db.Integer,
        db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"),
        nullable=False,
    )
    business_unit_id = db.Column(
        db.Integer,
        db.ForeignKey("business_units.business_unit_id", ondelete="SET NULL"),
        nullable=True,
    )
    event_name = db.Column(db.Text, nullable=False)
    # Unix epoch seconds (Meta Conventions API expects event_time in seconds).
    event_time = db.Column(db.BigInteger, nullable=False)
    ctwa_clid = db.Column(db.Text, nullable=True)
    wa_id = db.Column(db.String(50), nullable=True)
    payload_json = db.Column(db.JSON(none_as_null=True), nullable=True)
    meta_response_json = db.Column(db.JSON(none_as_null=True), nullable=True)
    sent_status = db.Column(db.String(32), nullable=False)
    created_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=db.text("now()"),
    )

    # ORM navigation (FKs above already enforce integrity in PostgreSQL).
    candidate = db.relationship(
        "Candidates",
        foreign_keys=[candidate_id],
        backref=db.backref(
            "meta_pixel_events",
            lazy="dynamic",
            passive_deletes=True,
        ),
    )
    business_unit = db.relationship(
        "BusinessUnits",
        foreign_keys=[business_unit_id],
        backref=db.backref("meta_pixel_events_at_bu", lazy="dynamic"),
    )

    __table_args__ = (
        Index("idx_meta_pixel_events_candidate_id", "candidate_id"),
        Index("idx_meta_pixel_events_business_unit_id", "business_unit_id"),
        Index("idx_meta_pixel_events_event_name", "event_name"),
        Index("idx_meta_pixel_events_created_at", "created_at"),
        Index(
            "idx_meta_pixel_events_ctwa_clid",
            "ctwa_clid",
            postgresql_where=text("ctwa_clid IS NOT NULL"),
        ),
    )


class ScreeningMessages(db.Model):
    __tablename__ = 'screening_messages'
    message_serial = db.Column(db.Integer, primary_key=True)
    wa_id = db.Column(db.String(50))
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id'))
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidates.candidate_id'))
    message_id = db.Column(db.String(50))
    thread_id = db.Column(db.String(50))
    time_stamp = db.Column(db.DateTime)
    sent_by = db.Column(db.String(50))
    message_body = db.Column(db.Text)
    conversation_type = db.Column(db.String(10))
    whatsapp_msg_id = db.Column(db.String(100))
    set_id = db.Column(db.Integer, db.ForeignKey('question_sets.set_id'))
    question_id = db.Column(db.Integer, db.ForeignKey('screening_questions.question_id'))
    company_group_id = db.Column(db.Integer, db.ForeignKey('company_groups.company_group_id', ondelete='SET NULL'), nullable=True)

    # Relationships
    business_unit = db.relationship("BusinessUnits", backref="screening_messages")
    candidate = db.relationship("Candidates", backref="screening_messages")
    question = db.relationship("ScreeningQuestions", backref="screening_messages")
    company_group = db.relationship("CompanyGroups", backref="screening_messages")

    __table_args__ = (
        db.Index(
            'idx_screening_msgs_candidate_sent_by_ts',
            'candidate_id', 'sent_by', 'time_stamp',
        ),
        db.Index(
            'idx_screening_msgs_candidate_ts_desc',
            'candidate_id', time_stamp.desc(),
        ),
        db.Index('idx_screening_msgs_whatsapp_msg_id', 'whatsapp_msg_id'),
        db.Index('idx_screening_msgs_business_unit', 'business_unit_id'),
        db.Index('idx_screening_msgs_company_group', 'company_group_id'),
        db.Index('idx_screening_msgs_sent_by_candidate_ts', 'sent_by', 'candidate_id', 'time_stamp'),
    )

class CandidateReferences(db.Model):
    __tablename__ = "candidate_references"

    reference_id = db.Column(db.Integer, primary_key=True)
    reference_wa_id = db.Column(db.String(50))
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"), nullable=False)
    set_id = db.Column(db.Integer, db.ForeignKey("question_sets.set_id", ondelete="CASCADE"), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey("screening_questions.question_id", ondelete="CASCADE"), nullable=False)
    reach_out_delivered = db.Column(db.Boolean, default=False)
    reference_complete = db.Column(db.Boolean, default=False)
    assessment = db.Column(db.JSON)

    candidate = db.relationship("Candidates", backref="candidate_references", lazy="joined")

class ReferenceMessages(db.Model):
    __tablename__ = "reference_messages"

    message_serial = db.Column(db.Integer, primary_key=True)
    wa_id = db.Column(db.String(50))
    reference_id = db.Column(
        db.Integer,
        db.ForeignKey("candidate_references.reference_id", ondelete="CASCADE")
    )
    message_id = db.Column(db.String(50))
    thread_id = db.Column(db.String(50))
    time_stamp = db.Column(db.DateTime)
    sent_by = db.Column(db.String(50))
    message_body = db.Column(db.Text)
    conversation_type = db.Column(db.String(10))
    whatsapp_msg_id = db.Column(db.String(100))

class CandidateMedia(db.Model):
    __tablename__ = "candidate_media"

    media_id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"))
    business_unit_id = db.Column(db.Integer, db.ForeignKey("business_units.business_unit_id", ondelete="CASCADE"))
    question_id = db.Column(db.Integer, db.ForeignKey("screening_questions.question_id", ondelete="SET NULL"))
    set_id = db.Column(db.Integer)
    string_submission = db.Column(db.Text)
    media_type = db.Column(db.String(50))  # 'image', 'document', 'text', etc.
    media_subtype = db.Column(db.String(50))  # 'INE', 'RFC', 'CURP', etc.
    file_name = db.Column(db.String(255))
    mime_type = db.Column(db.String(100))
    file_size = db.Column(db.Integer)
    s3_bucket = db.Column(db.String(100))
    s3_key = db.Column(db.String(500))
    s3_url = db.Column(db.String(1000))
    upload_timestamp = db.Column(db.DateTime, server_default=db.text("CURRENT_TIMESTAMP"))
    whatsapp_media_id = db.Column(db.String(100))
    sha256_hash = db.Column(db.String(100))
    flow_token = db.Column(db.String(100))
    verified = db.Column(db.Boolean, default=False)
    verification_result = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, server_default=db.text("CURRENT_TIMESTAMP"))
    updated_at = db.Column(db.DateTime, server_default=db.text("CURRENT_TIMESTAMP"))

    __table_args__ = (
        db.Index('idx_candidate_media_candidate_id', 'candidate_id'),
        db.Index('idx_candidate_media_business_unit_id', 'business_unit_id'),
        db.Index('idx_candidate_media_question_id', 'question_id'),
        db.Index('idx_candidate_media_upload_timestamp', 'upload_timestamp'),
        db.Index('idx_candidate_media_whatsapp_id', 'whatsapp_media_id'),
        db.Index('idx_candidate_media_business_unit_subtype_string', 'business_unit_id', 'media_subtype', 'string_submission'),
    )

class OnboardingResponses(db.Model):
    __tablename__ = "onboarding_responses"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"), nullable=True, index=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey("business_units.business_unit_id", ondelete="SET NULL"), nullable=True, index=True)
    company_group_id = db.Column(db.Integer, db.ForeignKey("company_groups.company_group_id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = db.Column(db.DateTime, server_default=db.func.now(), nullable=False)
    question = db.Column(db.Text, nullable=True)
    answer = db.Column(db.Text, nullable=True)
    survey = db.Column(db.String, nullable=True)

    candidate = db.relationship("Candidates", backref="onboarding_responses")
    business_unit = db.relationship("BusinessUnits", backref="onboarding_responses")
    company_group = db.relationship("CompanyGroups", backref="onboarding_responses")

    __table_args__ = (
        db.Index('idx_onboarding_responses_candidate_id', 'candidate_id'),
        db.Index('idx_onboarding_responses_business_unit_id', 'business_unit_id'),
        db.Index('idx_onboarding_responses_company_group_id', 'company_group_id'),
    )


class EmailLogs(db.Model):
    __tablename__ = "email_logs"

    id = db.Column(db.BigInteger, primary_key=True)
    recipient_email = db.Column(db.String(320), nullable=False)
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete="SET NULL"), nullable=True)
    subject = db.Column(db.Text, nullable=True)
    template_name = db.Column(db.String(150), nullable=True)
    payload = db.Column(db.JSON, nullable=True)
    message_id = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(50), nullable=False, default="sent")
    error_info = db.Column(db.Text, nullable=True)
    sent_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now(), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now(), nullable=False)

    # Relationships
    business_unit = db.relationship("BusinessUnits", backref="email_logs")

    __table_args__ = (
        db.Index("idx_email_logs_recipient", "recipient_email"),
        db.Index("idx_email_logs_business_unit", "business_unit_id"),
        db.Index("idx_email_logs_sent_at", "sent_at"),
    )


# Performance Tracking Tables
class ResponseTiming(db.Model):
    __tablename__ = 'response_timings'

    id = db.Column(db.Integer, primary_key=True)  # Clave primaria
    employee_id = db.Column(db.Integer, nullable=False)
    # NOTE: business_unit_id is nullable to support existing records that don't have this value
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete="SET NULL"), nullable=True)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    time_delta = db.Column(db.Numeric, nullable=False)
    assistant_id = db.Column(db.String(50))
    # Token and model usage fields
    model = db.Column(db.String(50), nullable=False)
    prompt_tokens = db.Column(db.Integer, nullable=False)
    completion_tokens = db.Column(db.Integer, nullable=False)
    total_tokens = db.Column(db.Integer, nullable=False)

    # Relationships
    business_unit = db.relationship("BusinessUnits", backref="response_timings")

class EligibilityEvaluationLog(db.Model):
    __tablename__ = 'eligibility_evaluation_log'
    
    evaluation_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidates.candidate_id'), nullable=False, index=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey('business_units.business_unit_id', ondelete='CASCADE'), nullable=False, index=True)
    role_id = db.Column(db.Integer, db.ForeignKey('roles.role_id'), nullable=False, index=True)
    role_name = db.Column(db.String(255), nullable=False)
    
    # AI evaluation result
    is_eligible = db.Column(db.Boolean, nullable=False)
    ai_reasoning = db.Column(db.Text, nullable=True)  # The "reasoning" field from AI response
    raw_ai_response = db.Column(db.JSON, nullable=True)  # Full JSON response from AI
    
    # Questions and answers used for evaluation  
    questions_and_answers = db.Column(db.JSON, nullable=True)  # The input data used
    eligibility_criteria = db.Column(db.JSON, nullable=True)  # Role criteria used
    
    # Manual review fields
    manual_review_status = db.Column(db.String(50), nullable=True, index=True)  # null, 'pending', 'reviewed'
    manual_review_result = db.Column(db.Boolean, nullable=True)  # Manual verification: True/False/null
    manual_review_date = db.Column(db.DateTime, nullable=True)
    
    # Metadata
    evaluation_date = db.Column(db.DateTime, nullable=False, default=db.func.now())
    assistant_id = db.Column(db.String(100), nullable=True)  # OpenAI assistant ID used
    thread_id = db.Column(db.String(100), nullable=True)  # OpenAI thread ID
    
    # Relationships
    candidate = db.relationship('Candidates', backref='eligibility_evaluations')
    role = db.relationship('Roles', backref='eligibility_evaluations')
    business_unit = db.relationship('BusinessUnits', backref='eligibility_evaluations')
    
    def __repr__(self):
        return f'<EligibilityLog {self.evaluation_id}: candidate_id={self.candidate_id}, role_id={self.role_id}, eligible={self.is_eligible}>'




# Whatever else we need to add


class AdTemplate(db.Model):
    __tablename__ = 'ad_templates'

    id = db.Column(db.Integer, primary_key=True)
    kind = db.Column(db.String(50), nullable=False)
    key = db.Column(db.String(255), nullable=False, unique=True)
    json_data = db.Column(db.JSON, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))

    def __repr__(self):
        return f'<AdTemplate {self.id} {self.key}>'


class ScreeningConversationStatus(db.Model):
    __tablename__ = "screening_conversation_status"

    id = db.Column(db.SmallInteger, primary_key=True)
    code = db.Column(db.String(32), nullable=False, unique=True)
    description = db.Column(db.Text)

    conversations = db.relationship("ScreeningConversation", back_populates="status")


class ScreeningConversation(db.Model):
    __tablename__ = "screening_conversation"

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    wa_phone_id = db.Column(db.String(32), nullable=False)
    user_phone = db.Column(db.String(32), nullable=False)
    status_id = db.Column(
        db.SmallInteger,
        db.ForeignKey("screening_conversation_status.id", ondelete="RESTRICT"),
        nullable=False,
        server_default=text("1"),
    )
    status_changed_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=text("NOW()"),
    )
    last_webhook_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=text("NOW()"),
    )
    created_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=text("NOW()"),
    )
    updated_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=text("NOW()"),
    )
    active_run_id = db.Column(db.String(64))
    active_thread_id = db.Column(db.String(64))
    active_run_priority = db.Column(db.String(32))
    cancel_requested = db.Column(db.Boolean, nullable=False, server_default=text("false"))

    status = db.relationship("ScreeningConversationStatus", back_populates="conversations")
    temp_messages = db.relationship("TempMessage", back_populates="conversation", cascade="all, delete-orphan")

    __table_args__ = (
        db.UniqueConstraint("wa_phone_id", "user_phone", name="uq_screening_conversation_wa_phone_user_phone"),
        db.Index("idx_screening_conversation_status_changed", "status_id", "status_changed_at"),
        db.Index("idx_screening_conversation_last_webhook", "last_webhook_at"),
    )


class WaMessageType(db.Model):
    __tablename__ = "wa_message_type"

    id = db.Column(db.SmallInteger, primary_key=True)
    code = db.Column(db.String(32), nullable=False, unique=True)


class WaInteractiveType(db.Model):
    __tablename__ = "wa_interactive_type"

    id = db.Column(db.SmallInteger, primary_key=True)
    code = db.Column(db.String(32), nullable=False, unique=True)


class TempMessage(db.Model):
    __tablename__ = "temp_messages"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    conversation_id = db.Column(
        db.BigInteger,
        db.ForeignKey("screening_conversation.id", ondelete="CASCADE"),
        nullable=False,
    )
    message_id = db.Column(db.String(255))
    wa_id = db.Column(db.String(255))
    body = db.Column(db.JSON)
    received_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP"),
    )
    processing = db.Column(db.Boolean, nullable=False, server_default=text("FALSE"))
    wa_type = db.Column(db.String(32))
    wa_interactive_type = db.Column(db.String(32))
    wa_type_id = db.Column(
        db.SmallInteger,
        db.ForeignKey("wa_message_type.id", ondelete="RESTRICT"),
        nullable=True,
    )
    wa_interactive_type_id = db.Column(
        db.SmallInteger,
        db.ForeignKey("wa_interactive_type.id", ondelete="RESTRICT"),
        nullable=True,
    )
    openai_message_id = db.Column(db.String(64))
    run_count = db.Column(db.Integer, nullable=False, server_default=text("0"))

    conversation = db.relationship("ScreeningConversation", back_populates="temp_messages")

    __table_args__ = (
        db.Index("idx_temp_messages_conversation_processing", "conversation_id", "processing"),
    )


@event.listens_for(DashboardConfigurations, 'before_insert')
@event.listens_for(DashboardConfigurations, 'before_update')
def ensure_estado_in_interviewed_candidates_keys(mapper, connection, target):
    """Ensure 'Estado': 'estado' is always present in interviewed_candidates_keys"""
    if target.interviewed_candidates_keys is None:
        target.interviewed_candidates_keys = {}
    
    if not isinstance(target.interviewed_candidates_keys, dict):
        target.interviewed_candidates_keys = {}
    
    if "Estado" not in target.interviewed_candidates_keys:
        target.interviewed_candidates_keys = {
            "Estado": "estado",
            **target.interviewed_candidates_keys
        }


@event.listens_for(Candidates, 'before_insert')
@event.listens_for(Candidates, 'before_update')
def ensure_estado_in_candidate_interviewed_keys(mapper, connection, target):
    """Ensure 'estado' is always present in interviewed_candidates_keys with funnel_state value"""
    if target.interviewed_candidates_keys is None:
        target.interviewed_candidates_keys = {}
    
    if not isinstance(target.interviewed_candidates_keys, dict):
        target.interviewed_candidates_keys = {}
    
    estado_value = target.funnel_state if target.funnel_state else ""
    target.interviewed_candidates_keys["estado"] = estado_value


class MetaTestResult(db.Model):
    __tablename__ = "meta_test_results"

    meta_test_result_id = db.Column(db.BigInteger, primary_key=True)
    direction = db.Column(db.String, nullable=False)
    wa_phone_id = db.Column(db.String)
    wa_id_user = db.Column(db.String)
    payload = db.Column(db.JSON)
    payload_text = db.Column(db.Text)
    test_round_id = db.Column(db.BigInteger)
    test_round_fullname = db.Column(db.Text)
    test_round_business_unit_id = db.Column(db.Integer)
    created_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now(), nullable=False)

class SupportChatConversations(db.Model):
    __tablename__ = "support_chat_conversations"

    id = db.Column(db.Integer, primary_key=True)
    company_group_id = db.Column(db.Integer, db.ForeignKey("company_groups.company_group_id", ondelete="CASCADE"), nullable=False, index=True)
    business_unit_id = db.Column(db.Integer, db.ForeignKey("business_units.business_unit_id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = db.Column(db.String(255), nullable=False, default="Nueva conversación")
    pinned = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"), onupdate=db.text("now()"))

    __table_args__ = (
        db.Index("idx_support_chat_conversations_updated_at", "updated_at"),
        db.Index("idx_support_chat_conversations_user_updated", "user_id", "updated_at"),
    )

    def __repr__(self):
        return f'<SupportChatConversation {self.id} {self.title}>'


class BusinessUnitMetaConfig(db.Model):
    """All Meta-related data for a business unit (ad account, WABA, Page)."""
    __tablename__ = "business_unit_meta_config"

    id = db.Column(db.Integer, primary_key=True)
    business_unit_id = db.Column(
        db.Integer,
        db.ForeignKey("business_units.business_unit_id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    account_id = db.Column(db.String(50), nullable=True, index=True)
    name = db.Column(db.String(255), nullable=True)
    waba_id = db.Column(db.String(50), nullable=True, index=True)
    page_id = db.Column(db.String(50), nullable=True, index=True)
    pixel_id = db.Column(db.String(50), nullable=True, index=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"), onupdate=db.text("now()"))

    business_unit = db.relationship("BusinessUnits", backref="meta_configs")

    __table_args__ = (
        db.Index("idx_business_unit_meta_config_business_unit_id", "business_unit_id"),
    )

    def __repr__(self):
        return f'<BusinessUnitMetaConfig {self.account_id} {self.name}>'


class AdCampaigns(db.Model):
    """Meta ad campaigns belonging to a business unit Meta config."""
    __tablename__ = "ad_campaigns"

    id = db.Column(db.String(50), primary_key=True)
    meta_config_id = db.Column(
        db.Integer,
        db.ForeignKey("business_unit_meta_config.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name = db.Column(db.String(500), nullable=True)
    status = db.Column(db.String(50), nullable=True)
    objective = db.Column(db.String(100), nullable=True)
    special_ad_categories = db.Column(MutableList.as_mutable(db.JSON), default=list, nullable=True)
    created_time = db.Column(db.DateTime(timezone=True), nullable=True)
    updated_time = db.Column(db.DateTime(timezone=True), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"), onupdate=db.text("now()"))

    meta_config = db.relationship("BusinessUnitMetaConfig", backref="campaigns")

    __table_args__ = (
        db.Index("idx_ad_campaigns_meta_config_id", "meta_config_id"),
        db.Index("idx_ad_campaigns_status", "status"),
    )

    def __repr__(self):
        return f'<AdCampaign {self.id} {self.name}>'


class AdCampaignInsights(db.Model):
    """Aggregated insights per campaign for a given time window."""
    __tablename__ = "ad_campaign_insights"

    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(
        db.String(50),
        db.ForeignKey("ad_campaigns.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    time_window = db.Column(db.String(20), nullable=False, index=True)
    date_start = db.Column(db.Date, nullable=False)
    date_stop = db.Column(db.Date, nullable=False)
    spend = db.Column(db.Numeric(15, 2), nullable=True)
    impressions = db.Column(db.BigInteger, nullable=True)
    reach = db.Column(db.BigInteger, nullable=True)
    cpm = db.Column(db.Numeric(15, 6), nullable=True)
    cpp = db.Column(db.Numeric(15, 6), nullable=True)
    clicks = db.Column(db.BigInteger, nullable=True)
    actions = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"))
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, server_default=db.text("now()"), onupdate=db.text("now()"))

    campaign = db.relationship("AdCampaigns", backref="insights")

    __table_args__ = (
        db.Index(
            "idx_ad_campaign_insights_campaign_window",
            campaign_id,
            time_window,
        ),
        db.Index("idx_ad_campaign_insights_dates", date_start, date_stop),
    )

    def __repr__(self):
        return f'<AdCampaignInsights campaign={self.campaign_id} time_window={self.time_window}>'


class SkillsCandidateContext(db.Model):
    """Long-term memory for the Skills agent, keyed by candidate."""

    __tablename__ = "skills_candidate_context"

    candidate_id = db.Column(
        db.Integer,
        db.ForeignKey("candidates.candidate_id", ondelete="CASCADE"),
        primary_key=True,
    )
    profile = db.Column(
        MutableDict.as_mutable(JSONB),
        nullable=False,
        server_default=text("'{}'"),
    )
    completed_skills = db.Column(
        MutableList.as_mutable(JSONB),
        nullable=False,
        server_default=text("'[]'"),
    )
    skill_results = db.Column(
        MutableList.as_mutable(JSONB),
        nullable=False,
        server_default=text("'[]'"),
    )
    agent_notes = db.Column(db.Text, nullable=True)
    updated_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=text("NOW()"),
    )

    candidate = db.relationship("Candidates", backref="skills_context")

    __table_args__ = (
        db.Index("idx_skills_ctx_updated", "updated_at"),
    )


class SkillsMessageBuffer(db.Model):
    """Conversation-level buffer for the skills agent worker.

    Acts simultaneously as:
    - Debounce queue  (next_process_at — trailing edge, 7 s window, 60 s ceiling)
    - Distributed lock (processing / processing_at)
    - Cancellation signal (interrupt_requested)
    """

    __tablename__ = "skills_message_buffer"

    conv_id = db.Column(
        db.Text,
        primary_key=True,
        comment="{phone_number_id}#{user_phone}",
    )
    environment = db.Column(
        db.String(20),
        primary_key=True,
        nullable=False,
        server_default=text("'production'"),
        comment="Deployment environment (dev, staging, production). Part of PK to isolate environments sharing the same DB.",
    )
    messages = db.Column(
        MutableList.as_mutable(JSONB),
        nullable=False,
        server_default=text("'[]'"),
        comment="[{wamid, text, ts, source?}, ...] — pending messages",
    )
    in_flight_messages = db.Column(
        MutableList.as_mutable(JSONB),
        nullable=False,
        server_default=text("'[]'"),
        comment="Messages taken by the Processor. Restored on cancellation.",
    )
    next_process_at = db.Column(
        db.DateTime(timezone=True),
        nullable=True,
        comment="Trailing debounce deadline. Processor picks up when <= NOW().",
    )
    window_start = db.Column(
        db.DateTime(timezone=True),
        nullable=True,
        comment="Timestamp of the first message in the current window. Enforces 60 s ceiling.",
    )
    processing = db.Column(
        db.Boolean,
        nullable=False,
        server_default=text("FALSE"),
        comment="True while a Processor instance holds the lock.",
    )
    processing_at = db.Column(
        db.DateTime(timezone=True),
        nullable=True,
        comment="When the lock was acquired. Used to detect orphaned locks.",
    )
    interrupt_requested = db.Column(
        db.Boolean,
        nullable=False,
        server_default=text("FALSE"),
        comment="Set by the Accumulator when a new message arrives during processing.",
    )
    updated_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=text("NOW()"),
    )

    __table_args__ = (
        db.Index(
            "idx_skills_msg_buf_next_process",
            "environment",
            "next_process_at",
            postgresql_where=text("next_process_at IS NOT NULL AND processing = FALSE"),
        ),
        db.Index(
            "idx_skills_msg_buf_orphan_sweep",
            "processing",
            "processing_at",
            postgresql_where=text("processing = TRUE"),
        ),
    )

class ErrorLogs(db.Model):
    __tablename__ = "error_logs"

    id = db.Column(db.BigInteger, primary_key=True)
    error_type = db.Column(
        db.String(20),
        nullable=False
    )
    created_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        server_default=db.text("now()")
    )
    error_message = db.Column(db.Text, nullable=False)

    candidate_id = db.Column(db.Integer, nullable=True)
    business_unit_id = db.Column(db.Integer, nullable=True)
    wa_id = db.Column(db.Integer, nullable=True)
    wa_id_system = db.Column(db.String(100), nullable=True)
    error_location = db.Column(db.String(255), nullable=True)

    __table_args__ = (
        db.CheckConstraint(
            "error_type IN ('ERROR', 'WARNING')",
            name="error_logs_error_type_check",
        ),
        db.Index("idx_error_logs_created_at", "created_at"),
        db.Index("idx_error_logs_error_type", "error_type"),
    )