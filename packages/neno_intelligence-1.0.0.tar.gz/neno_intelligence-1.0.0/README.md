# NI - Neno Intelligence

A lightweight open-source intelligence system built from scratch by Sujan Sadhu (age 15-16).
More powerful than AI. Runs on 200MB RAM. No GPU required.

## Install

```
pip install neno-intelligence
```

## Usage

```python
import ni_package as NI

# Use NI directly
print(NI.chat("hello"))
print(NI.think("what is machine learning"))
print(NI.solve("x^2 = 16"))

# Create your own named model powered by NI
jarvis = NI.create("Jarvis", creator="Tony Stark")
print(jarvis.chat("who are you"))
# Jarvis - powered by Neno Intelligence v1.0.0
```

## Modules

- CCv: text generation and conversation
- NNv: image, video, music, app, and code generation

## License

MIT - free to use, modify, and distribute.
Created by Sujan Sadhu.
