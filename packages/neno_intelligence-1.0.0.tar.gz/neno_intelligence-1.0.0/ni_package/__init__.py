"""
NI — Neno Intelligence
pip install neno-intelligence
import NI
"""
from .core import NI, chat, think, solve, create

__version__ = "1.0.0"
__author__  = "Sujan Sadhu"
__all__     = ["NI", "chat", "think", "solve", "create"]
