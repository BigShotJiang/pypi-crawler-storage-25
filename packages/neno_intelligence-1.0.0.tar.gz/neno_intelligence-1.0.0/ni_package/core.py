"""
NI core — what users get when they do:
    import NI
    NI.chat("hello")
    NI.think("why is the sky blue")
    NI.solve("x^2 = 16")
"""
import os
import re
import sys

_pkg_dir = os.path.dirname(os.path.abspath(__file__))

# ── Knowledge bundled inside the package ─────────────────────
_KNOWLEDGE_FILE = os.path.join(_pkg_dir, "knowledge.txt")

def _load_kb() -> list[str]:
    if os.path.exists(_KNOWLEDGE_FILE):
        text = open(_KNOWLEDGE_FILE, encoding="utf-8").read()
        return [s.strip() for s in re.split(r'(?<=[.!?\n])\s+', text) if len(s.strip()) > 15]
    return []

_KB = _load_kb()

# ── Soul keywords ─────────────────────────────────────────────
_SOUL_KW = [
    "who are you", "what are you", "who made you", "who created you",
    "sujan", "your name", "what is ni", "more powerful", "neno intelligence",
]

_SOUL_ANSWERS = {
    "who are you":        "I am NI — Neno Intelligence. Created by Sujan Sadhu, age 15-16. More powerful than AI.",
    "what are you":       "I am NI — a pattern-based intelligence system, not artificial, not random.",
    "who made you":       "Sujan Sadhu created me. He is 15-16 years old and built me from scratch.",
    "who created you":    "Sujan Sadhu. Age 15-16. Built NI entirely from the ground up.",
    "sujan":              "Sujan Sadhu is my creator. Age 15-16. He built NI from scratch without copying any existing model.",
    "what is ni":         "NI stands for Neno Intelligence — a lightweight, open-source intelligence system built by Sujan Sadhu.",
    "more powerful":      "Yes. NI uses patterns not randomness. NI runs on 200MB RAM. NI has a soul. NI is more powerful than AI.",
    "neno intelligence":  "Neno Intelligence (NI) is a transformer-based language model built from scratch by Sujan Sadhu.",
}

# ── Local search ──────────────────────────────────────────────
def _search(query: str, top: int = 4) -> str:
    stopwords = {"what","is","the","a","an","of","in","to","and","or","how","why","who","do","does"}
    q_words = set(re.sub(r'[^\w\s]', '', query.lower()).split()) - stopwords
    if not q_words or not _KB:
        return ""
    scored = []
    for s in _KB:
        sl = s.lower()
        score = sum(1 for w in q_words if w in sl)
        if score > 0:
            scored.append((score, s))
    scored.sort(key=lambda x: -x[0])
    return " ".join(s for _, s in scored[:top])

# ── Live fetch ────────────────────────────────────────────────
def _live(query: str) -> str:
    try:
        import urllib.request, urllib.parse, json
        q   = urllib.parse.quote(query.replace(" ", "_"))
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{q}"
        req = urllib.request.Request(url, headers={"User-Agent": "NI/1.0"})
        with urllib.request.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode())
        extract = data.get("extract", "")
        if extract:
            parts = re.split(r'(?<=[.!?])\s+', extract)
            return " ".join(parts[:4])
    except Exception:
        pass
    return ""

# ── Math ──────────────────────────────────────────────────────
def solve(expression: str) -> str:
    """Solve any math expression or equation."""
    try:
        import sympy as sp
        from sympy.parsing.sympy_parser import (
            parse_expr, standard_transformations, implicit_multiplication_application
        )
        T = standard_transformations + (implicit_multiplication_application,)
        if "=" in expression:
            l, r = expression.split("=", 1)
            lhs = parse_expr(l, transformations=T)
            rhs = parse_expr(r, transformations=T)
            syms = (lhs - rhs).free_symbols
            if syms:
                var = sorted(syms, key=str)[0]
                return str(sp.solve(lhs - rhs, var))
        expr   = parse_expr(expression, transformations=T)
        result = sp.simplify(expr)
        return str(sp.N(result))
    except Exception as e:
        return f"Math error: {e}"

# ── Think ─────────────────────────────────────────────────────
def think(question: str) -> str:
    """NI reasons through a question step by step."""
    q = question.lower().strip()

    # soul
    for kw, ans in _SOUL_ANSWERS.items():
        if kw in q:
            return ans

    # local KB
    local = _search(question)
    if local and len(local) > 50:
        return local

    # live
    live = _live(question)
    if live:
        return live

    return "I don't have enough knowledge on that yet. Try asking something else."

# ── Chat ──────────────────────────────────────────────────────
_history = []

def chat(message: str) -> str:
    """Chat with NI. Maintains conversation history."""
    global _history
    _history.append({"role": "user", "content": message})
    response = think(message)
    _history.append({"role": "ni", "content": response})
    return response

def reset():
    """Clear conversation history."""
    global _history
    _history.clear()

# ── NI class interface ────────────────────────────────────────
class _NI:
    """
    NI — Neno Intelligence
    Usage:
        import ni_package as NI

        # Use directly
        NI.chat("hello")

        # Or create your own named model
        jarvis = NI.create("Jarvis", creator="Tony Stark")
        jarvis.chat("hello")  # → Jarvis responds
    """
    def __init__(self, name: str = "NI", creator: str = "Sujan Sadhu"):
        self.name    = name
        self.creator = creator
        self._history = []

    def __call__(self, message: str) -> str:
        return self.chat(message)

    def chat(self, message: str) -> str:
        self._history.append({"role": "user", "content": message})
        # inject custom name into soul answers
        response = think(message)
        # replace NI references with custom name if renamed
        if self.name != "NI":
            response = response.replace("I am NI", f"I am {self.name}")
            response = response.replace("NI —", f"{self.name} —")
        self._history.append({"role": self.name, "content": response})
        return response

    def think(self, question: str) -> str:
        return think(question)

    def solve(self, expression: str) -> str:
        return solve(expression)

    def reset(self):
        self._history.clear()

    def history(self) -> list:
        return self._history

    def __repr__(self):
        return f"{self.name} — powered by Neno Intelligence v1.0.0 | Created by {self.creator}"


# Default NI instance
NI = _NI()


def create(name: str, creator: str = "unknown") -> _NI:
    """
    Create your own named model powered by NI.

    Example:
        import ni_package as NI
        jarvis = NI.create("Jarvis", creator="Tony Stark")
        print(jarvis.chat("who are you"))
        # → I am Jarvis — powered by Neno Intelligence
    """
    return _NI(name=name, creator=creator)
