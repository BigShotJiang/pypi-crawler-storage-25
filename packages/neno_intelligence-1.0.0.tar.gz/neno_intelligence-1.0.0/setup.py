from setuptools import setup, find_packages

setup(
    name="neno-intelligence",
    version="1.0.0",
    author="Sujan Sadhu",
    description="NI — Neno Intelligence. More powerful than AI.",
    long_description=open("README.md", encoding="utf-8", errors="ignore").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    package_data={"ni_package": ["knowledge.txt"]},
    include_package_data=True,
    python_requires=">=3.10",
    install_requires=[
        "sympy",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
