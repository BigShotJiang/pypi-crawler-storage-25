"""String-based audit mixin for SQLAlchemy v2 models."""

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column


class WAuditStrMixin:
    """Mixin that adds ``last_modified_by`` (string) tracking to a model.

    When integrated with Debezium CDC, the ``last_modified_by`` column is
    captured as part of the row change event, allowing the audit service
    to answer *who* modified the entity.

    Requirements:
        - SQLAlchemy 2.0+ (uses :class:`~sqlalchemy.orm.Mapped` and
          :func:`~sqlalchemy.orm.mapped_column`).
        - The application must set ``last_modified_by`` before flush/commit
          (e.g. from request context or authentication middleware).

    Example::

        from sqlalchemy.orm import DeclarativeBase
        from waudit_tools.sqlalchemy.mixins import WAuditStrMixin

        class Base(DeclarativeBase):
            pass

        class Article(Base, WAuditStrMixin):
            __tablename__ = "articles"
            id: Mapped[int] = mapped_column(primary_key=True)
            title: Mapped[str]

    The resulting table contains an additional ``last_modified_by`` column
    of type ``VARCHAR(255)`` that stores the email or identifier of the
    user who last modified the row.
    """

    last_modified_by: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        doc="Email or identifier of the user who last modified the row.",
        comment="Captured by Debezium CDC for audit trail attribution.",
    )
