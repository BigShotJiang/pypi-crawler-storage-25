"""UUID-based audit mixin for SQLAlchemy v2 models."""

import uuid

from sqlalchemy import UUID
from sqlalchemy.orm import Mapped, mapped_column


class WAuditUUIDMixin:
    """Mixin that adds ``last_modified_by`` (UUID) tracking to a model.

    Use this variant when user identifiers in your system are UUIDs
    rather than strings (e.g. ``auth_user.id = uuid``).

    Requirements:
        - SQLAlchemy 2.0+.
        - PostgreSQL native ``UUID`` type.
        - The application must set ``last_modified_by`` before flush/commit.

    Example::

        from sqlalchemy.orm import DeclarativeBase
        from waudit_tools.sqlalchemy.mixins import WAuditUUIDMixin

        class Base(DeclarativeBase):
            pass

        class Article(Base, WAuditUUIDMixin):
            __tablename__ = "articles"
            id: Mapped[int] = mapped_column(primary_key=True)
            title: Mapped[str]

    The resulting table contains an additional ``last_modified_by`` column
    of type ``UUID`` that references the user who last modified the row.
    """

    last_modified_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        doc="UUID of the user who last modified the row.",
        comment="Captured by Debezium CDC for audit trail attribution.",
    )
