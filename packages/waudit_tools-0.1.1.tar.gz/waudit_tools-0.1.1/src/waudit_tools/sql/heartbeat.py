"""Debezium heartbeat table utilities.

When a database has low write activity the PostgreSQL replication slot
can stall because WAL is not being produced. Debezium solves this with a
heartbeat mechanism that writes a dummy row to a dedicated table at a
configurable interval.

This module provides helpers to create that heartbeat table both manually
(via raw SQL) and inside an Alembic migration.
"""



def generate_heartbeat_sql(*, schema: str | None = None) -> str:
    """Generate the ``CREATE TABLE`` statement for the heartbeat table.

    Args:
        schema: Optional schema for the table.

    Returns:
        Raw SQL string.
    """
    table = f"{schema}.debezium_heartbeat" if schema else "debezium_heartbeat"
    return f"""
        CREATE TABLE IF NOT EXISTS {table} (
            id VARCHAR(36) NOT NULL DEFAULT 'debezium-heartbeat-0001',
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
            PRIMARY KEY (id)
        );
    """


def generate_drop_heartbeat_sql(*, schema: str | None = None) -> str:
    """Generate the ``DROP TABLE`` statement for the heartbeat table.

    Args:
        schema: Optional schema for the table.

    Returns:
        Raw SQL string.
    """
    table = f"{schema}.debezium_heartbeat" if schema else "debezium_heartbeat"
    return f"DROP TABLE IF EXISTS {table};"
