"""SQL generation for PostgreSQL REPLICA IDENTITY."""

import structlog

_LOGGER = structlog.get_logger(__name__)


def generate_identity_sql(
    table_name: str,
    *,
    schema: str | None = None,
    identity: str = "FULL",
) -> str:
    """Generate ``ALTER TABLE ... REPLICA IDENTITY`` statement.

    Args:
        table_name: Target PostgreSQL table.
        schema: Optional schema name.
        identity: Identity mode (``FULL`` or ``DEFAULT``).

    Returns:
        SQL statement.

    Raises:
        ValueError: If *table_name* is empty or whitespace-only.

    Example:
        >>> generate_identity_sql("users", identity="FULL")
        'ALTER TABLE users REPLICA IDENTITY FULL;'
    """
    if not table_name or not table_name.strip():
        raise ValueError("table_name must be a non-empty string")

    table_name = table_name.strip()
    identifier = f"{schema}.{table_name}" if schema else table_name
    sql = f"ALTER TABLE {identifier} REPLICA IDENTITY {identity};"
    _LOGGER.debug("generated_identity_sql", sql=sql)
    return sql


def apply_identity_to_tables(
    tables: list[str],
    *,
    schema: str | None = None,
    separator: str = "\n",
    identity: str = "FULL",
) -> str:
    r"""Generate identity statements for multiple tables.

    Args:
        tables: List of table names.
        schema: Optional schema applied to every table.
        separator: String used to join individual statements.
        identity: Identity mode (``FULL`` or ``DEFAULT``).

    Returns:
        Concatenated SQL statements.

    Raises:
        ValueError: If *tables* is empty or contains an empty name.

    Example:
        >>> apply_identity_to_tables(["users", "articles"], schema="cms")
        'ALTER TABLE cms.users REPLICA IDENTITY FULL;\n...'
    """
    if not tables:
        raise ValueError("tables list must not be empty")

    statements = []
    for name in tables:
        if not name or not name.strip():
            raise ValueError("table names must not be empty")
        statements.append(generate_identity_sql(name, schema=schema, identity=identity))

    result = separator.join(statements)
    _LOGGER.info(
        "generated_identity_statements",
        table_count=len(tables),
        identity=identity,
        schema=schema,
    )
    return result
