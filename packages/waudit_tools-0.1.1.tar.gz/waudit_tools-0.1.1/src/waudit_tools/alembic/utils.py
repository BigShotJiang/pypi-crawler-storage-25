"""Shared helpers for Alembic CDC operations."""

from sqlalchemy.engine import Connection

from waudit_tools.sql.heartbeat import (
    generate_drop_heartbeat_sql,
    generate_heartbeat_sql,
)


def create_heartbeat(connection: Connection, schema: str | None = None) -> None:
    """Create the Debezium heartbeat table via raw SQL.

    Args:
        connection: SQLAlchemy connection.
        schema: Optional schema for the table.
    """
    connection.exec_driver_sql(generate_heartbeat_sql(schema=schema))


def drop_heartbeat(connection: Connection, schema: str | None = None) -> None:
    """Drop the Debezium heartbeat table via raw SQL.

    Args:
        connection: SQLAlchemy connection.
        schema: Optional schema for the table.
    """
    connection.exec_driver_sql(generate_drop_heartbeat_sql(schema=schema))
