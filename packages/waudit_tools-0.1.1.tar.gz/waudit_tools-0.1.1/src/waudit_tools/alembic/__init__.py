"""Alembic operations for waudit CDC setup and teardown.

Import this module in an Alembic migration script to register all
operations on the ``Operations`` class.
"""

# Import side-effects register operations on alembic.operations.Operations
from waudit_tools.alembic.remove import (
    WauditRemoveFromBaseOp,
    WauditRemoveOp,
    WauditRemoveTableOp,
)
from waudit_tools.alembic.setup import (
    WauditSetupFromBaseOp,
    WauditSetupOp,
    WauditSetupTableOp,
)

__all__ = [
    "WauditRemoveFromBaseOp",
    "WauditRemoveOp",
    "WauditRemoveTableOp",
    "WauditSetupFromBaseOp",
    "WauditSetupOp",
    "WauditSetupTableOp",
]
