"""Alembic operations for setting up CDC auditing."""

import structlog
from alembic.operations import MigrateOperation, Operations
from sqlalchemy.engine import Connection
from sqlalchemy.orm import DeclarativeBase

from waudit_tools.alembic.utils import create_heartbeat
from waudit_tools.sql.identity import generate_identity_sql

_LOGGER = structlog.get_logger(__name__)


@Operations.register_operation("waudit_setup")
class WauditSetupOp(MigrateOperation):
    """Alembic operation that sets up CDC auditing.

    Applies ``REPLICA IDENTITY FULL`` to the requested tables and
    optionally creates the Debezium heartbeat table.
    """

    def __init__(
        self,
        include_audit_tables: list[str],
        *,
        exclude_audit_tables: list[str] | None = None,
        create_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        """Initialize the operation.

        Args:
            include_audit_tables: Tables that must receive
                ``REPLICA IDENTITY FULL``.
            exclude_audit_tables: Tables to skip from *include_audit_tables*.
            create_heartbeat_table: Whether to create ``debezium_heartbeat``.
            schema: Optional schema applied to every statement.
        """
        self.include_audit_tables = include_audit_tables
        self.exclude_audit_tables = exclude_audit_tables or []
        self.create_heartbeat_table = create_heartbeat_table
        self.schema = schema

    @classmethod
    def waudit_setup(
        cls,
        operations: Operations,
        include_audit_tables: list[str],
        *,
        exclude_audit_tables: list[str] | None = None,
        create_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        """Invoke via ``op.waudit_setup(...)``."""
        operations.invoke(
            cls(
                include_audit_tables,
                exclude_audit_tables=exclude_audit_tables,
                create_heartbeat_table=create_heartbeat_table,
                schema=schema,
            )
        )

    def execute(self, connection: Connection) -> None:
        """Run the setup SQL."""
        tables = set(self.include_audit_tables) - set(self.exclude_audit_tables)
        _LOGGER.info(
            "waudit_setup",
            table_count=len(tables),
            create_heartbeat=self.create_heartbeat_table,
            schema=self.schema,
        )
        for table in sorted(tables):
            sql = generate_identity_sql(table, schema=self.schema, identity="FULL")
            connection.exec_driver_sql(sql)

        if self.create_heartbeat_table:
            create_heartbeat(connection, schema=self.schema)


@Operations.implementation_for(WauditSetupOp)
def _impl_waudit_setup(
    operation: WauditSetupOp,
    operations: Operations,
) -> None:
    """Wire the setup operation to Alembic's migration context."""
    connection = operations.get_bind()
    operation.execute(connection)


@Operations.register_operation("waudit_setup_from_base")
class WauditSetupFromBaseOp(MigrateOperation):
    """Alembic operation that sets up CDC auditing from a declarative base."""

    def __init__(
        self,
        base: type[DeclarativeBase],
        *,
        exclude: set[str] | None = None,
        create_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        self.base = base
        self.exclude = exclude or set()
        self.create_heartbeat_table = create_heartbeat_table
        self.schema = schema

    @classmethod
    def waudit_setup_from_base(
        cls,
        operations: Operations,
        base: type[DeclarativeBase],
        *,
        exclude: set[str] | None = None,
        create_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        """Invoke via ``op.waudit_setup_from_base(...)``."""
        operations.invoke(
            cls(
                base,
                exclude=exclude,
                create_heartbeat_table=create_heartbeat_table,
                schema=schema,
            )
        )

    def execute(self, connection: Connection) -> None:
        """Run the setup SQL."""
        table_names = {
            tbl.name for tbl in self.base.metadata.sorted_tables
        } - self.exclude
        if not table_names:
            raise ValueError("no tables matched the given filters")

        _LOGGER.info(
            "waudit_setup_from_base",
            table_count=len(table_names),
            create_heartbeat=self.create_heartbeat_table,
            schema=self.schema,
        )
        for table in sorted(table_names):
            sql = generate_identity_sql(table, schema=self.schema, identity="FULL")
            connection.exec_driver_sql(sql)

        if self.create_heartbeat_table:
            create_heartbeat(connection, schema=self.schema)


@Operations.implementation_for(WauditSetupFromBaseOp)
def _impl_waudit_setup_from_base(
    operation: WauditSetupFromBaseOp,
    operations: Operations,
) -> None:
    """Wire the operation to Alembic's migration context."""
    connection = operations.get_bind()
    operation.execute(connection)


@Operations.register_operation("waudit_setup_table")
class WauditSetupTableOp(MigrateOperation):
    """Alembic operation that sets up CDC auditing for a single table."""

    def __init__(
        self,
        table_name: str,
        *,
        schema: str | None = None,
    ) -> None:
        self.table_name = table_name
        self.schema = schema

    @classmethod
    def waudit_setup_table(
        cls,
        operations: Operations,
        table_name: str,
        *,
        schema: str | None = None,
    ) -> None:
        """Invoke via ``op.waudit_setup_table(...)``."""
        operations.invoke(cls(table_name, schema=schema))

    def execute(self, connection: Connection) -> None:
        """Run the setup SQL."""
        sql = generate_identity_sql(
            self.table_name, schema=self.schema, identity="FULL"
        )
        connection.exec_driver_sql(sql)


@Operations.implementation_for(WauditSetupTableOp)
def _impl_waudit_setup_table(
    operation: WauditSetupTableOp,
    operations: Operations,
) -> None:
    """Wire the operation to Alembic's migration context."""
    connection = operations.get_bind()
    operation.execute(connection)
