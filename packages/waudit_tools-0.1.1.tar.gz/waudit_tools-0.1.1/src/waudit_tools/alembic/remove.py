"""Alembic operations for tearing down CDC auditing."""

import structlog
from alembic.operations import MigrateOperation, Operations
from sqlalchemy.engine import Connection
from sqlalchemy.orm import DeclarativeBase

from waudit_tools.alembic.utils import drop_heartbeat
from waudit_tools.sql.identity import generate_identity_sql

_LOGGER = structlog.get_logger(__name__)


@Operations.register_operation("waudit_remove")
class WauditRemoveOp(MigrateOperation):
    """Alembic operation that tears down CDC auditing.

    Reverts ``REPLICA IDENTITY FULL`` to ``DEFAULT`` and optionally drops
    the heartbeat table.
    """

    def __init__(
        self,
        include_audit_tables: list[str],
        *,
        exclude_audit_tables: list[str] | None = None,
        drop_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        """Initialize the operation.

        Args:
            include_audit_tables: Tables that must be reverted to
                ``REPLICA IDENTITY DEFAULT``.
            exclude_audit_tables: Tables to skip from *include_audit_tables*.
            drop_heartbeat_table: Whether to drop ``debezium_heartbeat``.
            schema: Optional schema applied to every statement.
        """
        self.include_audit_tables = include_audit_tables
        self.exclude_audit_tables = exclude_audit_tables or []
        self.drop_heartbeat_table = drop_heartbeat_table
        self.schema = schema

    @classmethod
    def waudit_remove(
        cls,
        operations: Operations,
        include_audit_tables: list[str],
        *,
        exclude_audit_tables: list[str] | None = None,
        drop_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        """Invoke via ``op.waudit_remove(...)``."""
        operations.invoke(
            cls(
                include_audit_tables,
                exclude_audit_tables=exclude_audit_tables,
                drop_heartbeat_table=drop_heartbeat_table,
                schema=schema,
            )
        )

    def execute(self, connection: Connection) -> None:
        """Run the teardown SQL."""
        tables = set(self.include_audit_tables) - set(self.exclude_audit_tables)
        _LOGGER.info(
            "waudit_remove",
            table_count=len(tables),
            drop_heartbeat=self.drop_heartbeat_table,
            schema=self.schema,
        )
        for table in sorted(tables):
            sql = generate_identity_sql(table, schema=self.schema, identity="DEFAULT")
            connection.exec_driver_sql(sql)

        if self.drop_heartbeat_table:
            drop_heartbeat(connection, schema=self.schema)


@Operations.implementation_for(WauditRemoveOp)
def _impl_waudit_remove(
    operation: WauditRemoveOp,
    operations: Operations,
) -> None:
    """Wire the remove operation to Alembic's migration context."""
    connection = operations.get_bind()
    operation.execute(connection)


@Operations.register_operation("waudit_remove_from_base")
class WauditRemoveFromBaseOp(MigrateOperation):
    """Alembic operation that tears down CDC auditing from a declarative base."""

    def __init__(
        self,
        base: type[DeclarativeBase],
        *,
        exclude: set[str] | None = None,
        drop_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        self.base = base
        self.exclude = exclude or set()
        self.drop_heartbeat_table = drop_heartbeat_table
        self.schema = schema

    @classmethod
    def waudit_remove_from_base(
        cls,
        operations: Operations,
        base: type[DeclarativeBase],
        *,
        exclude: set[str] | None = None,
        drop_heartbeat_table: bool = False,
        schema: str | None = None,
    ) -> None:
        """Invoke via ``op.waudit_remove_from_base(...)``."""
        operations.invoke(
            cls(
                base,
                exclude=exclude,
                drop_heartbeat_table=drop_heartbeat_table,
                schema=schema,
            )
        )

    def execute(self, connection: Connection) -> None:
        """Run the teardown SQL."""
        table_names = {
            tbl.name for tbl in self.base.metadata.sorted_tables
        } - self.exclude
        if not table_names:
            raise ValueError("no tables matched the given filters")

        _LOGGER.info(
            "waudit_remove_from_base",
            table_count=len(table_names),
            drop_heartbeat=self.drop_heartbeat_table,
            schema=self.schema,
        )
        for table in sorted(table_names):
            sql = generate_identity_sql(table, schema=self.schema, identity="DEFAULT")
            connection.exec_driver_sql(sql)

        if self.drop_heartbeat_table:
            drop_heartbeat(connection, schema=self.schema)


@Operations.implementation_for(WauditRemoveFromBaseOp)
def _impl_waudit_remove_from_base(
    operation: WauditRemoveFromBaseOp,
    operations: Operations,
) -> None:
    """Wire the operation to Alembic's migration context."""
    connection = operations.get_bind()
    operation.execute(connection)


@Operations.register_operation("waudit_remove_table")
class WauditRemoveTableOp(MigrateOperation):
    """Alembic operation that tears down CDC auditing for a single table."""

    def __init__(
        self,
        table_name: str,
        *,
        schema: str | None = None,
    ) -> None:
        self.table_name = table_name
        self.schema = schema

    @classmethod
    def waudit_remove_table(
        cls,
        operations: Operations,
        table_name: str,
        *,
        schema: str | None = None,
    ) -> None:
        """Invoke via ``op.waudit_remove_table(...)``."""
        operations.invoke(cls(table_name, schema=schema))

    def execute(self, connection: Connection) -> None:
        """Run the teardown SQL."""
        sql = generate_identity_sql(
            self.table_name, schema=self.schema, identity="DEFAULT"
        )
        connection.exec_driver_sql(sql)


@Operations.implementation_for(WauditRemoveTableOp)
def _impl_waudit_remove_table(
    operation: WauditRemoveTableOp,
    operations: Operations,
) -> None:
    """Wire the operation to Alembic's migration context."""
    connection = operations.get_bind()
    operation.execute(connection)
