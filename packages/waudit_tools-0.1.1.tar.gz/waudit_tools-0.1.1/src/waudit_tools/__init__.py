"""waudit-tools: utilities for CDC-based audit log systems."""

__version__ = "0.1.0"

from waudit_tools.alembic import (
    WauditRemoveFromBaseOp,
    WauditRemoveOp,
    WauditRemoveTableOp,
    WauditSetupFromBaseOp,
    WauditSetupOp,
    WauditSetupTableOp,
)
from waudit_tools.sql.heartbeat import (
    generate_drop_heartbeat_sql,
    generate_heartbeat_sql,
)
from waudit_tools.sql.identity import apply_identity_to_tables, generate_identity_sql

__all__ = [
    "WauditRemoveFromBaseOp",
    "WauditRemoveOp",
    "WauditRemoveTableOp",
    "WauditSetupFromBaseOp",
    "WauditSetupOp",
    "WauditSetupTableOp",
    "__version__",
    "apply_identity_to_tables",
    "generate_drop_heartbeat_sql",
    "generate_heartbeat_sql",
    "generate_identity_sql",
]
