"""Unit tests for waudit_tools.alembic.remove."""

from unittest.mock import MagicMock

import pytest
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from tests.factories.alembic import (
    remove_from_base_op,
    remove_op,
    remove_table_op,
)
from waudit_tools.alembic.remove import (
    WauditRemoveFromBaseOp,
    WauditRemoveOp,
    WauditRemoveTableOp,
    _impl_waudit_remove,
    _impl_waudit_remove_from_base,
    _impl_waudit_remove_table,
)

# --- WauditRemoveOp ---

def test_waudit_remove_op_init() -> None:
    """Attributes are stored correctly."""
    op = remove_op(
        ["users", "articles"],
        exclude=["alembic_version"],
        heartbeat=True,
        schema="public",
    )
    assert op.include_audit_tables == ["users", "articles"]
    assert op.exclude_audit_tables == ["alembic_version"]
    assert op.drop_heartbeat_table is True
    assert op.schema == "public"


def test_waudit_remove_op_classmethod_invokes_operations(
    mock_operations: MagicMock,
) -> None:
    """``waudit_remove`` classmethod invokes operations.invoke."""
    WauditRemoveOp.waudit_remove(
        mock_operations,
        ["users"],
        exclude_audit_tables=["alembic_version"],
        drop_heartbeat_table=True,
        schema="public",
    )
    mock_operations.invoke.assert_called_once()
    op = mock_operations.invoke.call_args[0][0]
    assert isinstance(op, WauditRemoveOp)
    assert op.include_audit_tables == ["users"]


def test_waudit_remove_op_execute_identity_default(mock_connection: MagicMock) -> None:
    """Reverts identity to DEFAULT."""
    op = remove_op(["users", "articles"])
    op.execute(mock_connection)

    assert mock_connection.exec_driver_sql.call_count == 2
    calls = [call[0][0] for call in mock_connection.exec_driver_sql.call_args_list]
    assert "ALTER TABLE articles REPLICA IDENTITY DEFAULT;" in calls
    assert "ALTER TABLE users REPLICA IDENTITY DEFAULT;" in calls


def test_waudit_remove_op_execute_drop_heartbeat(mock_connection: MagicMock) -> None:
    """Drops heartbeat table when requested."""
    op = remove_op(["users"], heartbeat=True)
    op.execute(mock_connection)

    assert mock_connection.exec_driver_sql.call_count == 2
    drop_sql = mock_connection.exec_driver_sql.call_args_list[1][0][0]
    assert "DROP TABLE IF EXISTS debezium_heartbeat;" in drop_sql


def test_waudit_remove_op_execute_with_schema(mock_connection: MagicMock) -> None:
    """Schema is applied to drop statement."""
    op = remove_op(["users"], heartbeat=True, schema="cms")
    op.execute(mock_connection)

    drop_sql = mock_connection.exec_driver_sql.call_args_list[1][0][0]
    assert "DROP TABLE IF EXISTS cms.debezium_heartbeat;" in drop_sql


def test_waudit_remove_op_execute_excludes_tables(mock_connection: MagicMock) -> None:
    """Excluded tables are skipped."""
    op = remove_op(["users", "articles"], exclude=["articles"])
    op.execute(mock_connection)

    mock_connection.exec_driver_sql.assert_called_once_with(
        "ALTER TABLE users REPLICA IDENTITY DEFAULT;"
    )


# --- WauditRemoveFromBaseOp ---

def test_waudit_remove_from_base_op_classmethod_invokes_operations(
    mock_operations: MagicMock,
) -> None:
    """``waudit_remove_from_base`` classmethod invokes operations.invoke."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    WauditRemoveFromBaseOp.waudit_remove_from_base(
        mock_operations,
        Base,
        exclude={"alembic_version"},
        drop_heartbeat_table=True,
        schema="public",
    )
    mock_operations.invoke.assert_called_once()
    op = mock_operations.invoke.call_args[0][0]
    assert isinstance(op, WauditRemoveFromBaseOp)


def test_waudit_remove_from_base_op_execute(mock_connection: MagicMock) -> None:
    """Collects tables from base and reverts identity."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    class Article(Base):
        __tablename__ = "articles"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = remove_from_base_op(Base, exclude={"articles"})
    op.execute(mock_connection)

    called_sql = mock_connection.exec_driver_sql.call_args_list[0][0][0]
    assert called_sql == "ALTER TABLE users REPLICA IDENTITY DEFAULT;"


def test_waudit_remove_from_base_op_execute_drop_heartbeat(
    mock_connection: MagicMock,
) -> None:
    """Drops heartbeat table when requested."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = remove_from_base_op(Base, heartbeat=True)
    op.execute(mock_connection)

    assert mock_connection.exec_driver_sql.call_count == 2
    drop_sql = mock_connection.exec_driver_sql.call_args_list[1][0][0]
    assert "DROP TABLE IF EXISTS debezium_heartbeat;" in drop_sql


def test_waudit_remove_from_base_op_no_tables_raises(
    mock_connection: MagicMock,
) -> None:
    """Empty result after filtering raises ``ValueError``."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = remove_from_base_op(Base, exclude={"users"})
    with pytest.raises(ValueError, match="no tables matched"):
        op.execute(mock_connection)


# --- WauditRemoveTableOp ---

def test_waudit_remove_table_op_classmethod_invokes_operations(
    mock_operations: MagicMock,
) -> None:
    """``waudit_remove_table`` classmethod invokes operations.invoke."""
    WauditRemoveTableOp.waudit_remove_table(
        mock_operations, "users", schema="public"
    )
    mock_operations.invoke.assert_called_once()
    op = mock_operations.invoke.call_args[0][0]
    assert isinstance(op, WauditRemoveTableOp)
    assert op.table_name == "users"


def test_waudit_remove_table_op_execute(mock_connection: MagicMock) -> None:
    """Reverts identity to DEFAULT for a single table."""
    op = remove_table_op("users")
    op.execute(mock_connection)

    mock_connection.exec_driver_sql.assert_called_once_with(
        "ALTER TABLE users REPLICA IDENTITY DEFAULT;"
    )


def test_waudit_remove_table_op_execute_with_schema(mock_connection: MagicMock) -> None:
    """Schema is applied."""
    op = remove_table_op("users", schema="public")
    op.execute(mock_connection)

    mock_connection.exec_driver_sql.assert_called_once_with(
        "ALTER TABLE public.users REPLICA IDENTITY DEFAULT;"
    )


# --- impl functions ---

def test_impl_waudit_remove(mock_connection: MagicMock) -> None:
    """``_impl_waudit_remove`` delegates to operation.execute."""
    op = remove_op(["users"])
    mock_ops = MagicMock()
    mock_ops.get_bind.return_value = mock_connection
    _impl_waudit_remove(op, mock_ops)
    mock_connection.exec_driver_sql.assert_called_once()


def test_impl_waudit_remove_from_base(mock_connection: MagicMock) -> None:
    """``_impl_waudit_remove_from_base`` delegates to operation.execute."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = remove_from_base_op(Base)
    mock_ops = MagicMock()
    mock_ops.get_bind.return_value = mock_connection
    _impl_waudit_remove_from_base(op, mock_ops)
    mock_connection.exec_driver_sql.assert_called_once()


def test_impl_waudit_remove_table(mock_connection: MagicMock) -> None:
    """``_impl_waudit_remove_table`` delegates to operation.execute."""
    op = remove_table_op("users")
    mock_ops = MagicMock()
    mock_ops.get_bind.return_value = mock_connection
    _impl_waudit_remove_table(op, mock_ops)
    mock_connection.exec_driver_sql.assert_called_once()
