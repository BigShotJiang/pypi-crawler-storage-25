"""Unit tests for waudit_tools.sql.heartbeat."""

from waudit_tools.sql.heartbeat import (
    generate_drop_heartbeat_sql,
    generate_heartbeat_sql,
)

# --- generate_heartbeat_sql ---

def test_generate_heartbeat_sql_default() -> None:
    """SQL contains expected table and columns."""
    result = generate_heartbeat_sql()
    assert "CREATE TABLE IF NOT EXISTS debezium_heartbeat" in result
    assert "id VARCHAR(36)" in result
    assert "updated_at TIMESTAMP" in result


def test_generate_heartbeat_sql_with_schema() -> None:
    """Schema-qualified table name."""
    result = generate_heartbeat_sql(schema="public")
    assert "CREATE TABLE IF NOT EXISTS public.debezium_heartbeat" in result


# --- generate_drop_heartbeat_sql ---

def test_generate_drop_heartbeat_sql_default() -> None:
    """Simple DROP TABLE statement."""
    result = generate_drop_heartbeat_sql()
    assert result == "DROP TABLE IF EXISTS debezium_heartbeat;"


def test_generate_drop_heartbeat_sql_with_schema() -> None:
    """Schema-qualified drop."""
    result = generate_drop_heartbeat_sql(schema="public")
    assert result == "DROP TABLE IF EXISTS public.debezium_heartbeat;"
