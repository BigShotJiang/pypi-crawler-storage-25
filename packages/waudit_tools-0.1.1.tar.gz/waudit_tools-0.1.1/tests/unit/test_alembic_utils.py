"""Unit tests for waudit_tools.alembic.utils."""

from unittest.mock import MagicMock

from waudit_tools.alembic.utils import create_heartbeat, drop_heartbeat

# --- create_heartbeat ---

def test_create_heartbeat_default(mock_connection: MagicMock) -> None:
    """Executes CREATE TABLE SQL."""
    create_heartbeat(mock_connection)
    mock_connection.exec_driver_sql.assert_called_once()
    sql = mock_connection.exec_driver_sql.call_args[0][0]
    assert "CREATE TABLE IF NOT EXISTS debezium_heartbeat" in sql


def test_create_heartbeat_with_schema(mock_connection: MagicMock) -> None:
    """Schema is applied."""
    create_heartbeat(mock_connection, schema="public")
    sql = mock_connection.exec_driver_sql.call_args[0][0]
    assert "CREATE TABLE IF NOT EXISTS public.debezium_heartbeat" in sql


# --- drop_heartbeat ---

def test_drop_heartbeat_default(mock_connection: MagicMock) -> None:
    """Executes DROP TABLE SQL."""
    drop_heartbeat(mock_connection)
    mock_connection.exec_driver_sql.assert_called_once_with(
        "DROP TABLE IF EXISTS debezium_heartbeat;"
    )


def test_drop_heartbeat_with_schema(mock_connection: MagicMock) -> None:
    """Schema is applied."""
    drop_heartbeat(mock_connection, schema="public")
    mock_connection.exec_driver_sql.assert_called_once_with(
        "DROP TABLE IF EXISTS public.debezium_heartbeat;"
    )
