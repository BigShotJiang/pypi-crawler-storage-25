"""Unit tests for waudit_tools.sql.identity."""

import pytest

from waudit_tools.sql.identity import apply_identity_to_tables, generate_identity_sql

# --- generate_identity_sql ---

def test_generate_identity_sql_simple_table() -> None:
    """Simple table name without schema."""
    result = generate_identity_sql("users")
    assert result == "ALTER TABLE users REPLICA IDENTITY FULL;"


def test_generate_identity_sql_table_with_schema() -> None:
    """Schema-qualified table name."""
    result = generate_identity_sql("users", schema="public")
    assert result == "ALTER TABLE public.users REPLICA IDENTITY FULL;"


def test_generate_identity_sql_identity_default() -> None:
    """``identity=DEFAULT`` produces DEFAULT instead of FULL."""
    result = generate_identity_sql("users", identity="DEFAULT")
    assert result == "ALTER TABLE users REPLICA IDENTITY DEFAULT;"


def test_generate_identity_sql_empty_table_name_raises() -> None:
    """Empty table name raises ``ValueError``."""
    with pytest.raises(ValueError, match="table_name must be a non-empty string"):
        generate_identity_sql("")


def test_generate_identity_sql_whitespace_only_table_name_raises() -> None:
    """Whitespace-only table name raises ``ValueError``."""
    with pytest.raises(ValueError, match="table_name must be a non-empty string"):
        generate_identity_sql("   ")


def test_generate_identity_sql_table_name_is_stripped() -> None:
    """Surrounding whitespace is stripped."""
    result = generate_identity_sql("  users  ")
    assert result == "ALTER TABLE users REPLICA IDENTITY FULL;"


# --- apply_identity_to_tables ---

def test_apply_identity_to_tables_multiple_tables() -> None:
    """Multiple tables joined by newline."""
    result = apply_identity_to_tables(["users", "articles"])
    assert result == (
        "ALTER TABLE users REPLICA IDENTITY FULL;\n"
        "ALTER TABLE articles REPLICA IDENTITY FULL;"
    )


def test_apply_identity_to_tables_identity_default() -> None:
    """Passing ``identity=DEFAULT`` applies to all tables."""
    result = apply_identity_to_tables(["users"], identity="DEFAULT")
    assert result == "ALTER TABLE users REPLICA IDENTITY DEFAULT;"


def test_apply_identity_to_tables_with_schema() -> None:
    """Schema is applied to every statement."""
    result = apply_identity_to_tables(["users", "articles"], schema="cms")
    assert result == (
        "ALTER TABLE cms.users REPLICA IDENTITY FULL;\n"
        "ALTER TABLE cms.articles REPLICA IDENTITY FULL;"
    )


def test_apply_identity_to_tables_custom_separator() -> None:
    """Custom separator is respected."""
    result = apply_identity_to_tables(["users", "articles"], separator=" | ")
    assert result == (
        "ALTER TABLE users REPLICA IDENTITY FULL; | "
        "ALTER TABLE articles REPLICA IDENTITY FULL;"
    )


def test_apply_identity_to_tables_empty_list_raises() -> None:
    """Empty list raises ``ValueError``."""
    with pytest.raises(ValueError, match="tables list must not be empty"):
        apply_identity_to_tables([])


def test_apply_identity_to_tables_list_with_empty_entry_raises() -> None:
    """List containing empty strings raises ``ValueError``."""
    with pytest.raises(ValueError, match="table names must not be empty"):
        apply_identity_to_tables(["users", ""])
