"""Unit tests for waudit_tools.alembic.setup."""

from unittest.mock import MagicMock

import pytest
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from tests.factories.alembic import (
    setup_from_base_op,
    setup_op,
    setup_table_op,
)
from waudit_tools.alembic.setup import (
    WauditSetupFromBaseOp,
    WauditSetupOp,
    WauditSetupTableOp,
    _impl_waudit_setup,
    _impl_waudit_setup_from_base,
    _impl_waudit_setup_table,
)

# --- WauditSetupOp ---

def test_waudit_setup_op_init() -> None:
    """Attributes are stored correctly."""
    op = setup_op(
        ["users", "articles"],
        exclude=["alembic_version"],
        heartbeat=True,
        schema="public",
    )
    assert op.include_audit_tables == ["users", "articles"]
    assert op.exclude_audit_tables == ["alembic_version"]
    assert op.create_heartbeat_table is True
    assert op.schema == "public"


def test_waudit_setup_op_classmethod_invokes_operations(
    mock_operations: MagicMock,
) -> None:
    """``waudit_setup`` classmethod invokes operations.invoke."""
    WauditSetupOp.waudit_setup(
        mock_operations,
        ["users"],
        exclude_audit_tables=["alembic_version"],
        create_heartbeat_table=True,
        schema="public",
    )
    mock_operations.invoke.assert_called_once()
    op = mock_operations.invoke.call_args[0][0]
    assert isinstance(op, WauditSetupOp)
    assert op.include_audit_tables == ["users"]


def test_waudit_setup_op_execute_identity(mock_connection: MagicMock) -> None:
    """Applies REPLICA IDENTITY FULL to included tables."""
    op = setup_op(["users", "articles"])
    op.execute(mock_connection)

    assert mock_connection.exec_driver_sql.call_count == 2
    calls = [call[0][0] for call in mock_connection.exec_driver_sql.call_args_list]
    assert "ALTER TABLE articles REPLICA IDENTITY FULL;" in calls
    assert "ALTER TABLE users REPLICA IDENTITY FULL;" in calls


def test_waudit_setup_op_execute_with_heartbeat(mock_connection: MagicMock) -> None:
    """Creates heartbeat table when requested."""
    op = setup_op(["users"], heartbeat=True)
    op.execute(mock_connection)

    assert mock_connection.exec_driver_sql.call_count == 2
    heartbeat_sql = mock_connection.exec_driver_sql.call_args_list[1][0][0]
    assert "CREATE TABLE IF NOT EXISTS debezium_heartbeat" in heartbeat_sql


def test_waudit_setup_op_execute_with_schema(mock_connection: MagicMock) -> None:
    """Schema is applied to identity statements."""
    op = setup_op(["users"], schema="cms")
    op.execute(mock_connection)

    called_sql = mock_connection.exec_driver_sql.call_args_list[0][0][0]
    assert called_sql == "ALTER TABLE cms.users REPLICA IDENTITY FULL;"


def test_waudit_setup_op_execute_excludes_tables(mock_connection: MagicMock) -> None:
    """Excluded tables are skipped."""
    op = setup_op(["users", "articles"], exclude=["articles"])
    op.execute(mock_connection)

    mock_connection.exec_driver_sql.assert_called_once_with(
        "ALTER TABLE users REPLICA IDENTITY FULL;"
    )


# --- WauditSetupFromBaseOp ---

def test_waudit_setup_from_base_op_classmethod_invokes_operations(
    mock_operations: MagicMock,
) -> None:
    """``waudit_setup_from_base`` classmethod invokes operations.invoke."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    WauditSetupFromBaseOp.waudit_setup_from_base(
        mock_operations,
        Base,
        exclude={"alembic_version"},
        create_heartbeat_table=True,
        schema="public",
    )
    mock_operations.invoke.assert_called_once()
    op = mock_operations.invoke.call_args[0][0]
    assert isinstance(op, WauditSetupFromBaseOp)


def test_waudit_setup_from_base_op_execute(mock_connection: MagicMock) -> None:
    """Collects tables from base and applies identity."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    class Article(Base):
        __tablename__ = "articles"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = setup_from_base_op(Base, exclude={"articles"})
    op.execute(mock_connection)

    called_sql = mock_connection.exec_driver_sql.call_args_list[0][0][0]
    assert called_sql == "ALTER TABLE users REPLICA IDENTITY FULL;"


def test_waudit_setup_from_base_op_execute_with_heartbeat(
    mock_connection: MagicMock,
) -> None:
    """Creates heartbeat table when requested."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = setup_from_base_op(Base, heartbeat=True)
    op.execute(mock_connection)

    assert mock_connection.exec_driver_sql.call_count == 2
    heartbeat_sql = mock_connection.exec_driver_sql.call_args_list[1][0][0]
    assert "CREATE TABLE IF NOT EXISTS debezium_heartbeat" in heartbeat_sql


def test_waudit_setup_from_base_op_no_tables_raises(mock_connection: MagicMock) -> None:
    """Empty result after filtering raises ``ValueError``."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = setup_from_base_op(Base, exclude={"users"})
    with pytest.raises(ValueError, match="no tables matched"):
        op.execute(mock_connection)


# --- WauditSetupTableOp ---

def test_waudit_setup_table_op_classmethod_invokes_operations(
    mock_operations: MagicMock,
) -> None:
    """``waudit_setup_table`` classmethod invokes operations.invoke."""
    WauditSetupTableOp.waudit_setup_table(
        mock_operations, "users", schema="public"
    )
    mock_operations.invoke.assert_called_once()
    op = mock_operations.invoke.call_args[0][0]
    assert isinstance(op, WauditSetupTableOp)
    assert op.table_name == "users"


def test_waudit_setup_table_op_execute(mock_connection: MagicMock) -> None:
    """Applies REPLICA IDENTITY FULL to a single table."""
    op = setup_table_op("users")
    op.execute(mock_connection)

    mock_connection.exec_driver_sql.assert_called_once_with(
        "ALTER TABLE users REPLICA IDENTITY FULL;"
    )


def test_waudit_setup_table_op_execute_with_schema(mock_connection: MagicMock) -> None:
    """Schema is applied."""
    op = setup_table_op("users", schema="public")
    op.execute(mock_connection)

    mock_connection.exec_driver_sql.assert_called_once_with(
        "ALTER TABLE public.users REPLICA IDENTITY FULL;"
    )


# --- impl functions ---

def test_impl_waudit_setup(mock_connection: MagicMock) -> None:
    """``_impl_waudit_setup`` delegates to operation.execute."""
    op = setup_op(["users"])
    mock_ops = MagicMock()
    mock_ops.get_bind.return_value = mock_connection
    _impl_waudit_setup(op, mock_ops)
    mock_connection.exec_driver_sql.assert_called_once()


def test_impl_waudit_setup_from_base(mock_connection: MagicMock) -> None:
    """``_impl_waudit_setup_from_base`` delegates to operation.execute."""

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id: Mapped[int] = mapped_column(primary_key=True)

    op = setup_from_base_op(Base)
    mock_ops = MagicMock()
    mock_ops.get_bind.return_value = mock_connection
    _impl_waudit_setup_from_base(op, mock_ops)
    mock_connection.exec_driver_sql.assert_called_once()


def test_impl_waudit_setup_table(mock_connection: MagicMock) -> None:
    """``_impl_waudit_setup_table`` delegates to operation.execute."""
    op = setup_table_op("users")
    mock_ops = MagicMock()
    mock_ops.get_bind.return_value = mock_connection
    _impl_waudit_setup_table(op, mock_ops)
    mock_connection.exec_driver_sql.assert_called_once()
