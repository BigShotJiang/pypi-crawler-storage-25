"""Unit tests for waudit_tools.sqlalchemy.mixins."""

import uuid

from waudit_tools.sqlalchemy.mixins.str_mixin import WAuditStrMixin
from waudit_tools.sqlalchemy.mixins.uuid_mixin import WAuditUUIDMixin

# --- WAuditStrMixin ---

def test_waudit_str_mixin_last_modified_by_attribute() -> None:
    """``last_modified_by`` is defined as a mapped column."""
    model = WAuditStrMixin()
    assert hasattr(model, "last_modified_by")


def test_waudit_str_mixin_last_modified_by_set() -> None:
    """Can be assigned a string value."""
    model = WAuditStrMixin()
    model.last_modified_by = "admin"
    assert model.last_modified_by == "admin"


# --- WAuditUUIDMixin ---

def test_waudit_uuid_mixin_last_modified_by_attribute() -> None:
    """``last_modified_by`` is defined as a mapped column."""
    model = WAuditUUIDMixin()
    assert hasattr(model, "last_modified_by")


def test_waudit_uuid_mixin_last_modified_by_set() -> None:
    """Can be assigned a UUID value."""
    model = WAuditUUIDMixin()
    some_uuid = uuid.uuid4()
    model.last_modified_by = some_uuid
    assert model.last_modified_by == some_uuid
