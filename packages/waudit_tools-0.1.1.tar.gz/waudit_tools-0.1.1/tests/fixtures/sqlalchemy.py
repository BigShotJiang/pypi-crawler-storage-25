"""SQLAlchemy-related pytest fixtures."""

import pytest
from sqlalchemy import Table
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class _Base(DeclarativeBase):
    """Internal declarative base for test models."""


class _User(_Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)


class _Article(_Base):
    __tablename__ = "articles"
    id: Mapped[int] = mapped_column(primary_key=True)


class _Order(_Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(primary_key=True)


@pytest.fixture
def declarative_base() -> type[DeclarativeBase]:
    """Return a declarative base with three mapped models."""
    return _Base


@pytest.fixture
def table_names(declarative_base: type[DeclarativeBase]) -> list[str]:
    """Return sorted table names from the test declarative base."""
    return sorted(tbl.name for tbl in declarative_base.metadata.sorted_tables)


@pytest.fixture
def single_table() -> Table:
    """Return a single table object."""
    return _User.__table__
