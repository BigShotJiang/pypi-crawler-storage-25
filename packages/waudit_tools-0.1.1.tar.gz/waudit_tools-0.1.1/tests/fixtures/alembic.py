"""Alembic-related pytest fixtures."""

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def mock_connection() -> MagicMock:
    """Return a mocked SQLAlchemy connection."""
    return MagicMock()


@pytest.fixture
def mock_operations() -> MagicMock:
    """Return a mocked Alembic Operations object."""
    return MagicMock()
