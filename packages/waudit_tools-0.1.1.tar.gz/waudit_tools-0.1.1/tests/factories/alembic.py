"""Factories for building Alembic operation instances in tests."""

from sqlalchemy.orm import DeclarativeBase

from waudit_tools.alembic.remove import (
    WauditRemoveFromBaseOp,
    WauditRemoveOp,
    WauditRemoveTableOp,
)
from waudit_tools.alembic.setup import (
    WauditSetupFromBaseOp,
    WauditSetupOp,
    WauditSetupTableOp,
)


def setup_op(
    tables: list[str],
    *,
    exclude: list[str] | None = None,
    heartbeat: bool = False,
    schema: str | None = None,
) -> WauditSetupOp:
    """Build a ``WauditSetupOp`` instance."""
    return WauditSetupOp(
        tables,
        exclude_audit_tables=exclude,
        create_heartbeat_table=heartbeat,
        schema=schema,
    )


def setup_from_base_op(
    base: type[DeclarativeBase],
    *,
    exclude: set[str] | None = None,
    heartbeat: bool = False,
    schema: str | None = None,
) -> WauditSetupFromBaseOp:
    """Build a ``WauditSetupFromBaseOp`` instance."""
    return WauditSetupFromBaseOp(
        base,
        exclude=exclude,
        create_heartbeat_table=heartbeat,
        schema=schema,
    )


def setup_table_op(
    table_name: str,
    *,
    schema: str | None = None,
) -> WauditSetupTableOp:
    """Build a ``WauditSetupTableOp`` instance."""
    return WauditSetupTableOp(table_name, schema=schema)


def remove_op(
    tables: list[str],
    *,
    exclude: list[str] | None = None,
    heartbeat: bool = False,
    schema: str | None = None,
) -> WauditRemoveOp:
    """Build a ``WauditRemoveOp`` instance."""
    return WauditRemoveOp(
        tables,
        exclude_audit_tables=exclude,
        drop_heartbeat_table=heartbeat,
        schema=schema,
    )


def remove_from_base_op(
    base: type[DeclarativeBase],
    *,
    exclude: set[str] | None = None,
    heartbeat: bool = False,
    schema: str | None = None,
) -> WauditRemoveFromBaseOp:
    """Build a ``WauditRemoveFromBaseOp`` instance."""
    return WauditRemoveFromBaseOp(
        base,
        exclude=exclude,
        drop_heartbeat_table=heartbeat,
        schema=schema,
    )


def remove_table_op(
    table_name: str,
    *,
    schema: str | None = None,
) -> WauditRemoveTableOp:
    """Build a ``WauditRemoveTableOp`` instance."""
    return WauditRemoveTableOp(table_name, schema=schema)
