"""Pytest configuration.

Fixture modules are registered via ``pytest_plugins`` so they are
available across all test files without explicit imports.
"""

pytest_plugins = [
    "tests.fixtures.sqlalchemy",
    "tests.fixtures.alembic",
]
