# DGLZ CLI 使用指南

> **版本**: 0.1.8.post1 | **命令行工具**: `eemo` | **Python 包**: `eemoclas`

---

## 目录

1. [项目简介](#1-项目简介)
2. [安装与环境配置](#2-安装与环境配置)
3. [快速上手：从原始数据到提交文件](#3-快速上手从原始数据到提交文件)
4. [完整命令参考](#4-完整命令参考)
5. [配置文件参考](#5-配置文件参考)
6. [目录结构说明](#6-目录结构说明)
7. [常见问题](#7-常见问题)

---

## 1. 项目简介

DGLZ 是一个基于 **三阶段 CNN-Transformer 层级分类器** 的 EEG 脑电情绪识别系统。流水线将任务分解为三个阶段：

```
原始 EEG (.mat)
       │
       ▼
┌──────────────────────────────┐
│ 第一阶段：被试状态分类        │  正常人 vs 抑郁症患者
│ model: SubjectStateCNNTransformer │
└──────────┬───────────────────┘
           │ 硬路由
     ┌─────┴─────┐
     ▼           ▼
┌─────────┐  ┌───────────────┐
│ 第二阶段 │  │ 第三阶段       │  中性 vs 积极
│ 正常人   │  │ 抑郁症患者     │
│ 情绪分类 │  │ 情绪分类       │
└─────────┘  └───────────────┘
     │           │
     └─────┬─────┘
           ▼
   提交文件 (.xlsx / .csv)
```

**三个分类器说明：**

| 分类器 | 模型名称 | 输入形状 | 输出 | 任务 |
|--------|----------|----------|------|------|
| 分类器 1 | `subject_state` | `[B, 8, C_eff, 2500]` | `[B, 2]` | 正常人 / 抑郁症患者 |
| 分类器 2 | `normal_emotion` | `[B, C_eff, 2500]` | `[B, 2]` | 中性 / 积极（正常人） |
| 分类器 3 | `depression_emotion` | `[B, C_eff, 2500]` | `[B, 2]` | 中性 / 积极（抑郁症） |

### V0.1.4 新特性

- **统一配置格式**：`train_full.yaml` 将三个分类器配置合并为单一文件
- **多模型训练**：支持顺序/并行/混合训练模式
- **点分键值覆盖**：通过 `--override` 在命令行动态修改配置
- **Dataclass 强类型配置系统**：31 个类型化配置类，支持 IDE 自动补全和运行时校验
- **实验管理**：统一输出目录 `experiments/{name}/`，含检查点、日志、指标、结果子目录
- **Rich 终端美化**：双面板实时显示、配置面板、训练摘要表格
- **增强优化器/调度器**：3 种优化器（adamw/adam/sgd）、6 种调度器（cosine/cosine_warmup/cosine_warmrestarts/steplr/plateau/onecycle）+ warmup 支持
- **增强配置校验**：自动检测配置格式，校验必填字段并计算有效通道数

### V0.1.6 新特性

- **多线程重采样**：`eemo resample --workers N` 支持多线程并行处理被试数据，显著加速重采样流程
- **`pip install DGLZ`**：支持用户直接通过 PyPI 安装和升级
- **配置变量增强**：标签平滑、梯度裁剪、Holdout 划分模式、详细调度器参数、实验注释等
- **实验注释**：`experiment.notes` 字段支持记录调参目的和参数变更原因

### V0.1.7 新特性

- **训练流水线修复**：完整实现多模型训练编排器，支持端到端训练（数据加载→模型创建→训练循环→检查点保存）
- **Rich 重采样进度条**：重采样过程显示实时进度条（旋转器、进度条、计数、耗时）
- **Dict 批次支持**：Trainer 现在支持字典格式批次数据（x/y/token_meta），兼容 ResampledTensorDataset

### V0.1.8 新特性

- **完整配置面板**：训练启动前显示全部配置变量（含每模型的 optimizer/scheduler/model/splitting/seeding/augmentation）
- **训练日志生成**：自动写入 `experiments/{name}/logs/training.log`，记录完整训练过程
- **日志排版优化**：采用紧凑单行 epoch 格式，便于 grep 和解析

### V0.1.8.post1 新特性

- **多核并行重采样**：`eemo resample -w N` 使用 `ProcessPoolExecutor`（spawn 模式）绕过 GIL，真正利用多核 CPU 加速 bandpass 滤波等 CPU 密集操作
- **进度条剩余时间**：Rich 进度条新增预计剩余时间（ETA）显示

---

## 2. 安装与环境配置

### 2.1 前置要求

- Python >= 3.13
- Conda（推荐）或 pip
- CUDA（可选，GPU 加速训练）

### 2.2 创建 Conda 环境

```bash
conda create -n dglz python=3.13 -y
conda activate dglz
```

### 2.3 安装项目

```bash
# 用户安装（推荐）
pip install DGLZ --index-url https://pypi.org/simple/

# 已安装但需要更新到最新版本
pip install DGLZ --upgrade --index-url https://pypi.org/simple/

# 开发模式安装（仅开发者）
pip install -e .
```

### 2.4 验证安装

```bash
# 查看版本号
eemo version
# 输出: eemo (DGLZ) 版本 0.1.8.post1

# 环境健康检查
eemo doctor
# 检查 Python、NumPy、PyTorch、CUDA 等依赖
```

### 2.5 导出默认配置模板

```bash
# 导出配置模板到 configs/ 目录
eemo get --path configs
```

导出文件（来自 `configs/base/`）：`train_full.yaml`、`resample.yaml`、`infer_three_stage.yaml`、`preprocess.yaml`

---

## 3. 快速上手：从原始数据到提交文件

以下是从原始 EEG 数据到最终提交文件的 **完整流程**：

### 第一步：准备原始数据

将训练数据和测试数据放置到以下目录结构：

```
dataset/
├── 训练集/
│   ├── 正常人/          # 40-44 名正常被试 .mat 文件
│   │   ├── HC1003timedata.mat
│   │   └── ...
│   └── 抑郁症患者/      # 18-20 名抑郁症被试 .mat 文件
│       ├── DEP1003timedata.mat
│       └── ...
└── 公开测试集/          # 10 名测试被试 .mat 文件
    ├── P_test1.mat
    └── ...
```

### 第二步：生成数据索引

扫描原始数据目录，生成训练集和测试集的索引 CSV 文件：

```bash
eemo prepare \
  --train-dir "dataset/训练集" \
  --test-dir "dataset/公开测试集" \
  --output-dir data/index
```

**输出文件：**
- `data/index/train_subjects.csv` — 训练被试索引（含 subject_id、mat_path、group_label）
- `data/index/test_subjects.csv` — 测试被试索引

### 第三步：离线重采样

为三个分类器生成重采样训练数据集：

```bash
# 使用统一重采样配置
eemo resample --config configs/resample.yaml --verbose

# 多线程并行处理
eemo resample --config configs/resample.yaml -w 8 --verbose
```

**输出目录：**
- `data/resampled/subject_state/version_001/` — manifest.csv + samples/*.pt
- `data/resampled/normal_emotion/version_001/`
- `data/resampled/depression_emotion/version_001/`

### 第四步：训练模型

**统一配置训练：**

```bash
# 训练全部三个分类器
eemo train --config configs/train_full.yaml --verbose

# 仅训练指定的模型
eemo train --config configs/train_full.yaml -m subject_state --verbose
eemo train --config configs/train_full.yaml -m subject_state,normal_emotion --verbose

# 使用并行模式训练
eemo train --config configs/train_full.yaml --mode parallel --verbose

# 使用混合模式（部分顺序、部分并行）
eemo train --config configs/train_full.yaml --mode mixed \
  --parallel-models normal_emotion,depression_emotion --verbose

# 通过命令行覆盖配置参数
eemo train --config configs/train_full.yaml \
  -o experiment.name=exp_v1 \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.002 \
  --verbose
```

**实验目录结构（V0.1.4）：**
```
experiments/
└── default/
    ├── config_snapshot.yaml          # 配置快照
    ├── training_state.json           # 训练状态
    ├── checkpoints/
    │   ├── subject_state/
    │   │   ├── best_val_balanced_accuracy.ckpt
    │   │   └── latest.ckpt
    │   ├── normal_emotion/
    │   └── depression_emotion/
    ├── logs/
    ├── metrics/
    └── results/
```

**训练参数提示：**
- 使用 `--resume` 可从最近检查点恢复训练
- 早停耐心值默认 15-20 轮，可在配置文件中调整
- 使用 `--override` / `-o` 动态修改任意配置参数，无需编辑文件

### 第五步：运行三阶段推理

使用训练好的三个模型对测试数据进行推理：

```bash
eemo infer-three-stage \
  --config configs/infer_three_stage.yaml \
  --verbose
```

**输出文件：**
- `outputs/submission.xlsx` — 提交格式结果（Excel）
- `outputs/submission.csv` — 提交格式结果（CSV）
- `outputs/routing_summary.csv` — 被试路由详情

### 第六步（可选）：检查结果

```bash
# 校验配置文件
eemo config validate --config configs/train_full.yaml

# 查看生效的配置内容
eemo config show --config configs/train_full.yaml

# 查看训练实验列表
eemo exp-train list

# 查看实验详情
eemo exp-train summary --name exp_v1

# 查看检查点信息
eemo ckpt info experiments/default/checkpoints/subject_state/best_val_balanced_accuracy.ckpt

# 查看推理结果摘要
eemo exp-pred summary-pred --dir outputs
```

---

## 4. 完整命令参考

### 4.1 `eemo version` — 显示版本号

```bash
eemo version
```

显示当前安装的 DGLZ 版本号。

---

### 4.2 `eemo doctor` — 环境健康检查

```bash
eemo doctor
```

自动检查以下项目：
- Python 版本
- NumPy、PyTorch、SciPy、Pandas、Typer、Rich、scikit-learn
- CUDA 可用性和设备信息
- 操作系统平台

---

### 4.3 `eemo prepare` — 生成数据索引

```bash
eemo prepare [OPTIONS]
```

扫描原始 .mat 数据目录，生成训练集和测试集的索引 CSV 文件。

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--train-dir` | TEXT | `data/raw/train` | 训练集 .mat 文件目录 |
| `--test-dir` | TEXT | `data/raw/test` | 测试集 .mat 文件目录 |
| `--output-dir` | TEXT | `data/index` | 索引 CSV 输出目录 |
| `--config` | TEXT | `configs/preprocess.yaml` | 预处理配置文件路径 |

**示例：**
```bash
eemo prepare --train-dir "dataset/训练集" --test-dir "dataset/公开测试集"
```

---

### 4.4 `eemo resample` — 离线重采样

```bash
eemo resample --config <配置文件> [OPTIONS]
```

为分类器生成重采样训练数据集。

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` | TEXT | **（必填）** | 重采样配置 YAML 文件路径 |
| `--workers` / `-w` | INT | 1 | 并行工作线程数（覆盖配置文件中的 `resample.workers`） |
| `--verbose` | FLAG | false | 启用详细输出模式 |

**示例：**
```bash
# 使用统一重采样配置（一次运行全部三个分类器）
eemo resample --config configs/resample.yaml --verbose

# 使用 4 个线程并行重采样，加速处理
eemo resample --config configs/resample.yaml --workers 4 --verbose

# CLI --workers 覆盖配置文件中的 resample.workers 值
eemo resample --config configs/resample.yaml -w 8
```

---

### 4.5 `eemo train` — 训练分类器

```bash
eemo train --config <配置文件> [OPTIONS]
```

训练一个或多个分类器模型。使用统一配置文件 `train_full.yaml`。

| 选项 | 类型 | 默认值 | 说明 |
|-----------|------|--------|------|
| `--config` | TEXT | **（必填）** | 训练配置 YAML 文件路径 |
| `--models` / `-m` | TEXT | 全部模型 | 逗号分隔的模型名称（仅统一格式） |
| `--mode` | TEXT | `sequential` | 训练模式: `sequential`、`parallel`、`mixed` |
| `--parallel-models` | TEXT | 无 | mixed 模式下并行训练的模型（逗号分隔） |
| `--override` / `-o` | TEXT | 无 | 点分键值覆盖（可重复使用） |
| `--experiment-name` | TEXT | 配置文件值 | 实验名称（用于日志和检查点目录） |
| `--verbose` | FLAG | false | 启用详细输出模式 |
| `--resume` | FLAG | false | 从最近检查点恢复训练 |

**统一配置示例：**
```bash
# 训练全部模型
eemo train --config configs/train_full.yaml --verbose

# 仅训练被试状态分类器
eemo train --config configs/train_full.yaml -m subject_state --verbose

# 并行训练全部模型
eemo train --config configs/train_full.yaml --mode parallel --verbose

# 使用命令行覆盖配置
eemo train --config configs/train_full.yaml \
  -o experiment.name=exp_v2 \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.002 \
  --verbose
```

**`--override` 点分键值语法：**

| 覆盖表达式 | 效果 |
|-----------|------|
| `experiment.name=exp_v2` | 修改实验名称 |
| `models.subject_state.training.epochs=200` | 修改被试状态模型训练轮数 |
| `models.subject_state.training.optimizer.lr=0.002` | 修改学习率 |
| `signal.fs=512` | 修改采样频率 |
| `signal.zscore.enabled=false` | 禁用 z-score |

支持自动类型推断：整数（`42`）、浮点数（`0.001`）、布尔值（`true`/`false`）、None（`null`）、列表（`[1,2,3]`）、字符串。

---

### 4.6 `eemo pred` — 单模型预测（调试用）

```bash
eemo pred <NAME> --config <配置> --model <检查点> --data <数据> [OPTIONS]
```

| 参数/选项 | 类型 | 默认值 | 说明 |
|-----------|------|--------|------|
| `NAME` | 参数 | **（必填）** | 模型名称：`subject_state`、`normal_emotion`、`depression_emotion` |
| `--config` | TEXT | **（必填）** | 配置 YAML 文件路径 |
| `--model` | TEXT | **（必填）** | 模型检查点文件路径 (.ckpt) |
| `--data` | TEXT | **（必填）** | 数据清单 CSV 或数据目录路径 |
| `--output` | TEXT | `outputs/pred.csv` | 预测结果输出 CSV 路径 |

**示例：**
```bash
eemo pred subject_state \
  --config configs/train_full.yaml \
  --model experiments/default/checkpoints/subject_state/best_val_balanced_accuracy.ckpt \
  --data data/resampled/subject_state/version_001/manifest.csv \
  --output outputs/pred_ss.csv
```

---

### 4.7 `eemo infer-three-stage` — 三阶段推理流水线

```bash
eemo infer-three-stage [OPTIONS]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` | TEXT | `configs/infer_three_stage.yaml` | 三阶段推理配置文件路径 |
| `--subject-state-model` | TEXT | None | 覆盖配置中的被试状态模型路径 |
| `--normal-emotion-model` | TEXT | None | 覆盖配置中的正常人情绪模型路径 |
| `--depression-emotion-model` | TEXT | None | 覆盖配置中的抑郁症情绪模型路径 |
| `--test-dir` | TEXT | None | 覆盖配置中的测试数据目录 |
| `--output` | TEXT | `outputs/submission` | 输出路径（不含扩展名） |
| `--verbose` | FLAG | false | 启用详细输出模式 |

**示例：**
```bash
# 使用配置文件中的路径
eemo infer-three-stage --config configs/infer_three_stage.yaml --verbose

# 通过命令行覆盖模型路径
eemo infer-three-stage \
  --subject-state-model experiments/default/checkpoints/subject_state/best_val_balanced_accuracy.ckpt \
  --normal-emotion-model experiments/default/checkpoints/normal_emotion/best_val_balanced_accuracy.ckpt \
  --depression-emotion-model experiments/default/checkpoints/depression_emotion/best_val_balanced_accuracy.ckpt \
  --test-dir dataset/公开测试集
```

---

### 4.8 `eemo config` — 配置文件管理

```bash
eemo config <SUBCOMMAND> [OPTIONS]
```

#### `config validate` — 校验配置文件

```bash
eemo config validate --config <配置文件>
```

校验配置文件完整性，检查必填字段并计算有效通道数 (C_eff)。支持训练配置、重采样配置和推理配置格式。

#### `config show` — 显示生效的配置内容

```bash
eemo config show --config <配置文件> [--model <配置段>]
```

以表格形式显示配置文件的所有键值对。`--model` 可筛选指定顶层配置段（如 `signal`、`models`、`experiment` 等）。

---

### 4.9 `eemo get` — 导出默认配置模板

```bash
eemo get [--path <导出目录>]
```

从 `configs/base/` 导出带详细注释的配置模板。

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--path` | TEXT | `configs` | 配置模板导出目录 |

导出文件：`train_full.yaml`、`resample.yaml`、`infer_three_stage.yaml`、`preprocess.yaml`

---

### 4.10 `eemo exp-train` — 训练实验管理

```bash
eemo exp-train <SUBCOMMAND> [OPTIONS]
```

#### `exp-train list` — 列出所有训练实验

```bash
eemo exp-train list [--checkpoint-dir <目录>]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--checkpoint-dir` | TEXT | `experiments/default/checkpoints` | 检查点根目录 |

#### `exp-train summary` — 查看实验详情

```bash
eemo exp-train summary --name <实验名> [--checkpoint-dir <目录>]
```

#### `exp-train compare` — 比较多个实验

```bash
eemo exp-train compare --names <名称1,名称2,...> [--checkpoint-dir <目录>]
```

#### `exp-train clean` — 清理过期实验

```bash
eemo exp-train clean [--before <日期>] [--keep-best <数量>] [--dry-run] [--checkpoint-dir <目录>]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--before` | TEXT | None | 删除早于此日期的实验 (YYYY-MM-DD) |
| `--keep-best` | INT | 3 | 保留最佳 N 个实验 |
| `--dry-run` | FLAG | true | 仅预览，不实际删除 |
| `--checkpoint-dir` | TEXT | `checkpoints` | 检查点根目录 |

---

### 4.11 `eemo exp-pred` — 推理结果管理

```bash
eemo exp-pred <SUBCOMMAND> [OPTIONS]
```

#### `exp-pred summary-pred` — 查看推理结果摘要

```bash
eemo exp-pred summary-pred --dir <输出目录>
```

#### `exp-pred compare-pred` — 比较多次推理结果

```bash
eemo exp-pred compare-pred --dirs <目录1,目录2,...>
```

#### `exp-pred export-pred` — 导出推理结果

```bash
eemo exp-pred export-pred --dir <输出目录> [--format <格式>]
```

| `--format` 可选值 | 说明 |
|-------------------|------|
| `csv` | CSV 格式（默认） |
| `xlsx` | Excel 格式 |
| `json` | JSON 格式 |

---

### 4.12 `eemo ckpt` — 检查点管理

```bash
eemo ckpt <SUBCOMMAND> [OPTIONS]
```

#### `ckpt list` — 列出所有检查点

```bash
eemo ckpt list [--checkpoint-dir <目录>] [--config <配置文件>]
```

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `--config` | TEXT | None | 配置 YAML（用于解析检查点目录） |
| `--checkpoint-dir` | TEXT | `experiments/default/checkpoints` | 检查点根目录 |

#### `ckpt info` — 显示检查点详情

```bash
eemo ckpt info <检查点文件路径>
```

显示轮次、指标、配置快照和模型参数量。

#### `ckpt export` — 导出模型最佳检查点

```bash
eemo ckpt export <模型名称> [--output <输出路径>] [--checkpoint-dir <目录>]
```

| 参数/选项 | 类型 | 默认值 | 说明 |
|-----------|------|--------|------|
| `NAME` | 参数 | **（必填）** | 模型名称：`subject_state`、`normal_emotion`、`depression_emotion` |
| `--output` | TEXT | None | 导出目标路径 |
| `--checkpoint-dir` | TEXT | `experiments/default/checkpoints` | 检查点根目录 |

---

## 5. 配置文件参考

### 5.1 配置文件概览

| 文件 | 用途 | 对应命令 |
|------|------|----------|
| `train_full.yaml` | 统一训练配置（三个模型合一） | `train` |
| `resample.yaml` | 统一重采样配置 | `resample` |
| `infer_three_stage.yaml` | 三阶段推理 | `infer-three-stage` |
| `preprocess.yaml` | 数据预处理参数 | `prepare` |

所有配置模板通过 `eemo get` 导出，源文件位于 `configs/base/`。

### 5.2 配置格式自动检测

系统自动检测配置文件格式，无需手动指定：

- **训练格式**：包含顶层 `models` 字典，每个模型含 `model`/`training` 子段
- **推理格式**：包含顶层 `models` 字典，每个模型含 `checkpoint`/`config` 子段
- **重采样格式**：包含顶层 `resample` + `signal` 字段
- **预处理格式**：包含顶层 `data` + `signal` 字段（无 `models` 或 `resample`）

---

### 5.3 统一训练配置 (`train_full.yaml`)

统一配置将三个分类器的所有参数集中在一个文件中，每个模型独立配置 task/model/training/augmentation/splitting/seeding：

```yaml
# 项目信息
project:
  repo_name: "DGLZ"
  package_name: "eemoclas"
  cli_name: "eemo"
  experiment_family: "eeg_three_stage_cnn_transformer"

# 信号参数
signal:
  fs: 250                       # 采样频率 (Hz)
  train_segment_points: 12500   # 每段采样点数
  window_points: 2500           # 窗口采样点数 (10s × 250Hz)
  clip_std: 5.0                 # z-score 后截断阈值
  zscore:
    enabled: true
    eps: 1.0e-6

# 通道选择
channels:
  mode: "by_name"
  selected: "all"

# 频带定义
band_definitions:
  delta: [1, 4]
  theta: [4, 7]
  alpha: [8, 13]
  beta: [13, 30]
  low_gamma: [30, 45]
  broadband: [1, 45]

channel_band_config:
  default_bands: ["broadband"]
  per_channel: {}

# 重采样配置
resample:
  targets: ["subject_state", "normal_emotion", "depression_emotion"]
  permute_trials: true
  save_format: "pt"
  seed: 42
  workers: 1                      # 并行工作线程数: 1=单线程, >1=多线程并行处理
  save_config_snapshot: true
  save_stats: true
  sampling:
    method: "truncated_gaussian"
    fs: 250
    window_seconds: 10
    gaussian:
      mu_seconds: 25
      sigma_seconds: 8
      lower_seconds: 5
      upper_seconds: 45

# 数据来源
data:
  index_dir: "data/index"
  manifests:
    subject_state: "data/resampled/subject_state/version_001/manifest.csv"
    normal_emotion: "data/resampled/normal_emotion/version_001/manifest.csv"
    depression_emotion: "data/resampled/depression_emotion/version_001/manifest.csv"
  config_snapshots:
    subject_state: "data/resampled/subject_state/version_001/config_snapshot.yaml"
    normal_emotion: "data/resampled/normal_emotion/version_001/config_snapshot.yaml"
    depression_emotion: "data/resampled/depression_emotion/version_001/config_snapshot.yaml"

# ===== 三个模型各自独立配置 =====
models:
  subject_state:
    task:
      name: "subject_state"
      dataset_class: "SubjectStateDataset"
      num_classes: 2
      label_names: ["normal", "depression"]

    model:
      class_name: "SubjectStateCNNTransformer"
      input_num_trials: 8
      input_length: 2500
      num_classes: 2
      trial_encoder:
        projection_dim: 128
        cnn_channels: [16, 32, 64]
        kernel_sizes: [15, 9, 5]
        strides: [2, 2, 2]
        cnn_dropout: 0.1
        pooling: "cls"
        token_embedding:
          use_channel_embedding: true
          use_band_embedding: true
          use_cls_token: true
          embedding_dim: 128
        transformer:
          num_layers: 2
          num_heads: 4
          dim_feedforward: 256
          dropout: 0.1
          activation: "gelu"
          norm_first: true
          batch_first: true
      subject_transformer:       # 仅 subject_state 有此段
        use_cls_token: true
        use_trial_position_embedding: true
        embedding_dim: 128
        num_layers: 2
        num_heads: 4
        dim_feedforward: 256
        dropout: 0.1
        activation: "gelu"
        norm_first: true
        batch_first: true
      classification_head:
        hidden_dims: [128]
        dropout: 0.3

    training:
      epochs: 100
      batch_size: 16
      optimizer:
        type: "adamw"           # 可选: adamw / adam / sgd
        lr: 1.0e-3
        weight_decay: 1.0e-4
        betas: [0.9, 0.999]    # adamw / adam 专用
        eps: 1.0e-8
        # momentum: 0.9         # sgd 专用
        # nesterov: false        # sgd 专用
        # amsgrad: false         # adam 专用
      scheduler:
        type: "cosine"          # 可选: cosine / cosine_warmup / cosine_warmrestarts / steplr / plateau / onecycle
        min_lr: 1.0e-6
        warmup_epochs: 5
        # cosine_warmrestarts 专用:
        # warmrestart_t0: 10
        # warmrestart_t_mult: 2
        # steplr 专用:
        # step_size: 30
        # step_gamma: 0.1
        # plateau 专用:
        # plateau_factor: 0.5
        # plateau_patience: 5
        # plateau_mode: "max"
        # onecycle 专用:
        # onecycle_pct_start: 0.3
      loss: "cross_entropy"
      class_weight: "auto"       # auto / null / [w0, w1]
      label_smoothing: 0.0       # 标签平滑系数 (0.0=不使用, 0.1=常用值)
      gradient_clip_val: 0.0     # 梯度裁剪阈值 (0.0=不裁剪)
      accumulate_grad_batches: 1
      mixed_precision: false
      num_workers: 4
      early_stopping_patience: 15
      checkpoint_metric: "val_balanced_accuracy"
      save_latest: true
      save_best: true

    augmentation:
      enabled: false
      gaussian_noise:
        enabled: false
        std: 0.01
      time_mask:
        enabled: false
        max_mask_ratio: 0.1
      channel_dropout:
        enabled: false
        drop_prob: 0.1

    splitting:
      method: "StratifiedGroupKFold"   # 可选: StratifiedGroupKFold | holdout
      n_splits: 5                       # K-fold 折数 (仅 StratifiedGroupKFold)
      train_ratio: 0.8                  # 训练集比例 (仅 holdout)
      val_ratio: 0.2                    # 验证集比例 (仅 holdout)
      group_key: "subject_id"
      stratify_key: "group_label"
      seed: 42

    seeding:
      random_seed: 42
      split_seed: 42
      init_seed: 42

  normal_emotion:
    # ... 结构同上，具体参数略有差异
    task:
      name: "normal_emotion"
      num_classes: 2
      label_names: ["neutral", "positive"]
    model:
      class_name: "NormalEmotionCNNTransformer"
      # 无 subject_transformer
    training:
      batch_size: 32
      # ...

  depression_emotion:
    task:
      name: "depression_emotion"
      num_classes: 2
      label_names: ["neutral", "positive"]
    model:
      class_name: "DepressionEmotionCNNTransformer"
      classification_head:
        dropout: 0.35
    training:
      epochs: 120
      batch_size: 24
      early_stopping_patience: 20
      # ...

# 全局日志配置
logging:
  level: "INFO"
  format: "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
  log_every_n_steps: 10

# 实验管理
experiment:
  name: "default"
  save_dir: "experiments"
  save_best: true
  save_latest: true
  checkpoint_metric: "val_balanced_accuracy"
  monitor_metrics:
    - val_balanced_accuracy
    - val_loss
  val_check_interval: 1.0        # 验证频率 (1.0=每 epoch, 0.5=每半 epoch)
  notes: ""                      # 实验注释: 记录调参目的、参数变更原因等

# 推理路由
inference:
  routing: "hard"
  use_4_4_constraint: true
  positive_label: 1
  neutral_label: 0
  output_format: "xlsx"

# 评估指标
metrics:
  primary: "balanced_accuracy"
  report:
    - accuracy
    - balanced_accuracy
    - macro_f1
    - roc_auc
```

**三个模型的主要差异：**

| 配置项 | subject_state | normal_emotion | depression_emotion |
|--------|--------------|----------------|-------------------|
| `model.class_name` | SubjectStateCNNTransformer | NormalEmotionCNNTransformer | DepressionEmotionCNNTransformer |
| `subject_transformer` | 有 | 无 | 无 |
| `training.epochs` | 100 | 100 | 120 |
| `training.batch_size` | 16 | 32 | 24 |
| `training.early_stopping_patience` | 15 | 15 | 20 |
| `classification_head.dropout` | 0.3 | 0.3 | 0.35 |

---

### 5.4 优化器配置详解

V0.1.4 支持三种优化器，使用嵌套 `optimizer` 对象配置：

```yaml
training:
  optimizer:
    type: "adamw"         # 优化器类型
    lr: 1.0e-3            # 学习率
    weight_decay: 1.0e-4  # 权重衰减
```

| 参数 | adamw | adam | sgd | 说明 |
|------|-------|------|-----|------|
| `betas` | [0.9, 0.999] | [0.9, 0.999] | — | 一阶/二阶矩估计系数 |
| `eps` | 1e-8 | 1e-8 | — | 防除零常数 |
| `amsgrad` | — | false | — | AMSGrad 变体 |
| `momentum` | — | — | 0.9 | 动量 |
| `nesterov` | — | — | false | Nesterov 动量 |

---

### 5.5 调度器配置详解

V0.1.4 支持 6 种学习率调度器 + warmup 预热：

```yaml
training:
  scheduler:
    type: "cosine"
    min_lr: 1.0e-6
    warmup_epochs: 5
```

| 调度器 | 专用参数 | 说明 |
|--------|---------|------|
| `cosine` | — | 余弦退火（默认） |
| `cosine_warmup` | — | 带预热的余弦退火 |
| `cosine_warmrestarts` | `warmrestart_t0`, `warmrestart_t_mult` | 带热重启的余弦退火 |
| `steplr` | `step_size`, `step_gamma` | 阶梯式衰减 |
| `plateau` | `plateau_factor`, `plateau_patience`, `plateau_mode` | 自适应降低学习率 |
| `onecycle` | `onecycle_pct_start` | 1Cycle 策略 |

---

### 5.6 三阶段推理配置 (`infer_three_stage.yaml`)

```yaml
inference:
  routing: "hard"
  use_4_4_constraint: true
  positive_label: 1
  neutral_label: 0
  output_format: "xlsx"
  submit_columns:
    - user_id
    - trial_id
    - Emotion_label

models:
  subject_state:
    checkpoint: "experiments/default/checkpoints/subject_state/best_val_balanced_accuracy.ckpt"
    config: "configs/train_full.yaml"
  normal_emotion:
    checkpoint: "experiments/default/checkpoints/normal_emotion/best_val_balanced_accuracy.ckpt"
    config: "configs/train_full.yaml"
  depression_emotion:
    checkpoint: "experiments/default/checkpoints/depression_emotion/best_val_balanced_accuracy.ckpt"
    config: "configs/train_full.yaml"

test_data:
  test_dir: "dataset/公开测试集"
  test_index_file: "data/index/test_subjects.csv"
  auto_detect_test_key: true
  trial_points: 2500
  num_trials: 8

preprocess:
  channel_band_config_source: "checkpoint_config"
  require_same_channel_band_config: true
  clip_std: 5.0
  zscore:
    enabled: true
    eps: 1.0e-6

postprocessing:
  method: "subject_topk"
  positive_count_per_subject: 4
  negative_count_per_subject: 4
```

---

## 6. 目录结构说明

### 6.1 项目根目录

```
DGLZ/
├── configs/
│   └── base/                       # 标准配置模板（eemo get 的来源）
│       ├── train_full.yaml         # 统一训练配置
│       ├── resample.yaml           # 统一重采样配置
│       ├── infer_three_stage.yaml  # 三阶段推理配置
│       └── preprocess.yaml         # 预处理配置
├── src/eemoclas/                   # 源代码
│   ├── cli/                        # CLI 命令实现
│   ├── config/                     # Dataclass 配置系统 (V0.1.4)
│   │   ├── dataclasses.py          # 31 个类型化配置类
│   │   ├── loader.py               # YAML 加载 + 格式检测
│   │   └── overrides.py            # 点分键值覆盖
│   ├── data/                       # 数据 I/O、预处理
│   ├── datasets/                   # PyTorch 数据集类
│   ├── model/                      # CNN-Transformer 模型
│   ├── prediction/                 # 推理与后处理
│   ├── resampling/                 # 离线重采样
│   ├── training/                   # 训练循环 + 编排器 (V0.1.4)
│   │   ├── orchestrator.py         # 多模型训练编排器
│   │   ├── experiment.py           # 实验管理器
│   │   ├── callbacks.py            # 多指标检查点回调
│   │   ├── optimizer.py            # 增强优化器
│   │   └── scheduler.py            # 增强调度器
│   └── utils/                      # 日志、显示、指标
│       └── display.py              # Rich 终端美化 (V0.1.4)
├── tests/                          # 单元测试（303 个测试）
├── pyproject.toml                  # 项目配置
├── HELP.md                         # 本文件
└── plan/                           # 设计文档
```

### 6.2 数据目录

```
data/
├── index/                          # 数据索引
│   ├── train_subjects.csv          # 训练被试索引
│   └── test_subjects.csv           # 测试被试索引
└── resampled/                      # 重采样数据
    ├── subject_state/version_001/
    │   ├── manifest.csv            # 样本清单
    │   ├── config_snapshot.yaml    # 配置快照
    │   ├── stats.json              # 统计信息
    │   └── samples/                # .pt 样本文件
    ├── normal_emotion/version_001/
    └── depression_emotion/version_001/
```

### 6.3 实验输出目录 (V0.1.4)

```
experiments/                        # 实验根目录
└── <实验名>/
    ├── config_snapshot.yaml        # 完整配置快照
    ├── training_state.json         # 多模型训练状态
    ├── checkpoints/                # 模型检查点
    │   ├── subject_state/
    │   │   ├── best_val_balanced_accuracy.ckpt
    │   │   ├── best_val_loss.ckpt
    │   │   └── latest.ckpt
    │   ├── normal_emotion/
    │   └── depression_emotion/
    ├── logs/                       # 训练日志
    ├── metrics/                    # 指标 CSV
    └── results/                    # 训练结果

outputs/                            # 推理输出
├── submission.xlsx                 # 提交文件 (Excel)
├── submission.csv                  # 提交文件 (CSV)
├── routing_summary.csv             # 路由详情
└── pred_*.csv                      # 单模型预测结果
```

---

## 7. 常见问题

### Q: `eemo doctor` 显示 CUDA 不可用？

确保已安装 CUDA 版本的 PyTorch：
```bash
nvidia-smi  # 查看 CUDA 版本
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
```

### Q: 统一配置文件的结构是什么？

统一配置 (`train_full.yaml`) 将三个模型集中在一个文件的 `models` 字段下，支持多模型训练、`--models` 选择、`--override` 动态覆盖。配置文件支持标签平滑 (`label_smoothing`)、梯度裁剪 (`gradient_clip_val`)、Holdout 划分模式等高级训练参数。

### Q: 如何仅训练部分模型？

```bash
# 仅训练被试状态分类器
eemo train --config configs/train_full.yaml -m subject_state --verbose

# 训练两个模型
eemo train --config configs/train_full.yaml -m subject_state,normal_emotion --verbose
```

### Q: 如何使用命令行动态修改训练参数？

使用 `--override` / `-o` 选项，可重复使用：
```bash
eemo train --config configs/train_full.yaml \
  -o experiment.name=exp_v2 \
  -o models.subject_state.training.epochs=200 \
  -o models.subject_state.training.optimizer.lr=0.002 \
  -o models.normal_emotion.training.batch_size=64 \
  --verbose
```

### Q: 重采样时提示 `.mat` 文件找不到？

检查 `data.index_file` 路径是否正确，确保 `prepare` 命令已生成索引 CSV。路径支持中文目录名。

### Q: 如何调整训练参数？

编辑 `configs/train_full.yaml` 或使用 `--override`：
- `training.epochs` — 增大延长训练
- `training.optimizer.lr` — 调整学习率（推荐范围 1e-4 ~ 1e-3）
- `training.batch_size` — 根据显存调整
- `training.class_weight: "auto"` — 缓解类别不平衡

### Q: 如何增加训练样本数量？

编辑配置中的 `resample` 段：
- `resample.samples_per_subject` — 每被试样本数（subject_state）
- `resample.samples_per_segment` — 每段样本数（normal_emotion / depression_emotion）
- 增大后重新运行 `eemo resample`

### Q: 如何使用不同的频带配置？

修改配置中的 `channel_band_config`：
```yaml
channel_band_config:
  default_bands: ["delta", "theta", "alpha", "beta"]  # 使用 4 个频带
  # C_eff = 30 × 4 = 120
```
修改后需重新运行重采样和训练。

### Q: 推理时如何覆盖模型路径？

```bash
eemo infer-three-stage \
  --subject-state-model path/to/ss.ckpt \
  --normal-emotion-model path/to/ne.ckpt \
  --depression-emotion-model path/to/de.ckpt
```

### Q: 如何查看训练好的模型指标？

```bash
# 校验配置
eemo config validate --config configs/train_full.yaml

# 查看检查点详情
eemo ckpt info experiments/default/checkpoints/subject_state/best_val_balanced_accuracy.ckpt

# 查看所有实验对比
eemo exp-train compare --names exp1,exp2,exp3
```

### Q: 单元测试如何运行？

```bash
conda run -n dglz python -m pytest tests/ -v
```

### Q: 如何查看完整的生效配置？

```bash
# 查看完整配置
eemo config show --config configs/train_full.yaml

# 查看指定段
eemo config show --config configs/train_full.yaml --model signal
```
