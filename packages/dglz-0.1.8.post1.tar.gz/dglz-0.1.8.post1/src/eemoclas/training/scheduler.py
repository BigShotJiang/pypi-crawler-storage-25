"""Learning-rate scheduler factory for DGLZ training.

Supports cosine annealing (default), cosine with warm restarts, step
decay, reduce-on-plateau, and one-cycle.  Accepts either a plain
``dict`` configuration (legacy) or a :class:`SchedulerConfig` dataclass
(new V0.1.4 typed path).

Warmup wrapping is applied when ``warmup_epochs > 0``.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import math
from typing import Any, Union

import torch.optim as optim

from eemoclas.config.dataclasses import SchedulerConfig


# ---------------------------------------------------------------------------
# Internal resolver
# ---------------------------------------------------------------------------

def _resolve_scheduler_config(
    config: Union[dict, SchedulerConfig],
    epochs: int = 0,
) -> SchedulerConfig:
    """Normalise *config* into a :class:`SchedulerConfig`.

    Accepts:

    * :class:`SchedulerConfig` -- returned as-is.
    * ``dict`` with a ``"training"`` key -- reads scheduler sub-config.
    * ``dict`` that *is* the scheduler config -- reads top-level keys.

    The *epochs* argument is used as a fallback for ``cosine_t_max`` and
    ``step_size`` when their values are ``0`` (auto-derive).

    Returns
    -------
    SchedulerConfig
    """
    if isinstance(config, SchedulerConfig):
        # Auto-derive zeros
        cfg = config
        if cfg.cosine_t_max == 0 and epochs > 0:
            # dataclasses are mutable; create adjusted copy
            cfg = SchedulerConfig(
                type=cfg.type,
                min_lr=cfg.min_lr,
                warmup_epochs=cfg.warmup_epochs,
                cosine_t_max=epochs,
                cosine_eta_min=cfg.cosine_eta_min,
                warmrestart_t0=cfg.warmrestart_t0,
                warmrestart_t_mult=cfg.warmrestart_t_mult,
                step_size=cfg.step_size,
                step_gamma=cfg.step_gamma,
                plateau_factor=cfg.plateau_factor,
                plateau_patience=cfg.plateau_patience,
                plateau_mode=cfg.plateau_mode,
                onecycle_pct_start=cfg.onecycle_pct_start,
            )
        if cfg.step_size == 0 and epochs > 0:
            new_step = max(1, epochs // 3)
            cfg = SchedulerConfig(
                type=cfg.type,
                min_lr=cfg.min_lr,
                warmup_epochs=cfg.warmup_epochs,
                cosine_t_max=cfg.cosine_t_max if cfg.cosine_t_max != 0 else epochs,
                cosine_eta_min=cfg.cosine_eta_min,
                warmrestart_t0=cfg.warmrestart_t0,
                warmrestart_t_mult=cfg.warmrestart_t_mult,
                step_size=new_step,
                step_gamma=cfg.step_gamma,
                plateau_factor=cfg.plateau_factor,
                plateau_patience=cfg.plateau_patience,
                plateau_mode=cfg.plateau_mode,
                onecycle_pct_start=cfg.onecycle_pct_start,
            )
        return cfg

    # --- dict path ---
    if not isinstance(config, dict):
        raise TypeError(
            f"config must be a dict or SchedulerConfig, got {type(config).__name__}"
        )

    # Determine the section to read from.
    if "training" in config:
        section = config["training"]
    else:
        section = config

    scheduler_name = section.get("scheduler", section.get("type", "cosine"))

    # scheduler_name may be a string or a nested dict
    if isinstance(scheduler_name, dict):
        sub = scheduler_name
        return SchedulerConfig(
            type=sub.get("type", "cosine"),
            min_lr=float(sub.get("min_lr", 1e-6)),
            warmup_epochs=int(sub.get("warmup_epochs", 5)),
            cosine_t_max=int(sub.get("cosine_t_max", 0)) or epochs,
            cosine_eta_min=float(sub.get("cosine_eta_min", 0.0)),
            warmrestart_t0=int(sub.get("warmrestart_t0", 10)),
            warmrestart_t_mult=int(sub.get("warmrestart_t_mult", 2)),
            step_size=int(sub.get("step_size", 0)) or max(1, epochs // 3),
            step_gamma=float(sub.get("step_gamma", 0.1)),
            plateau_factor=float(sub.get("plateau_factor", 0.5)),
            plateau_patience=int(sub.get("plateau_patience", 5)),
            plateau_mode=sub.get("plateau_mode", "max"),
            onecycle_pct_start=float(sub.get("onecycle_pct_start", 0.3)),
        )

    # Plain string scheduler name -- build from flat keys.
    epochs_val = int(section.get("epochs", epochs))
    cosine_t_max = int(section.get("cosine_t_max", 0))
    if cosine_t_max == 0:
        cosine_t_max = epochs_val
    step_size = int(section.get("step_size", 0))
    if step_size == 0:
        step_size = max(1, epochs_val // 3)

    return SchedulerConfig(
        type=str(scheduler_name).lower(),
        min_lr=float(section.get("min_lr", 1e-6)),
        warmup_epochs=int(section.get("warmup_epochs", 5)),
        cosine_t_max=cosine_t_max,
        cosine_eta_min=float(section.get("cosine_eta_min", 0.0)),
        warmrestart_t0=int(section.get("warmrestart_t0", 10)),
        warmrestart_t_mult=int(section.get("warmrestart_t_mult", 2)),
        step_size=step_size,
        step_gamma=float(section.get("step_gamma", section.get("gamma", 0.1))),
        plateau_factor=float(section.get("plateau_factor", section.get("scheduler_factor", 0.5))),
        plateau_patience=int(section.get("plateau_patience", section.get("scheduler_patience", 5))),
        plateau_mode=section.get("plateau_mode", "max"),
        onecycle_pct_start=float(section.get("onecycle_pct_start", 0.3)),
    )


# ---------------------------------------------------------------------------
# Internal warmup wrapper
# ---------------------------------------------------------------------------

class _WarmupWrapper(optim.lr_scheduler.LRScheduler):
    """Wrap any scheduler with linear warmup.

    During the first ``warmup_epochs`` epochs the learning rate linearly
    ramps from 0 to the base LR.  After that the wrapped scheduler takes
    over.

    Parameters
    ----------
    optimizer:
        Wrapped optimizer.
    warmup_epochs:
        Number of warmup epochs.
    wrapped_scheduler:
        The scheduler to activate after warmup completes.
    """

    def __init__(
        self,
        optimizer: optim.Optimizer,
        warmup_epochs: int,
        wrapped_scheduler: optim.lr_scheduler.LRScheduler,
    ) -> None:
        self.warmup_epochs = warmup_epochs
        self.wrapped_scheduler = wrapped_scheduler
        super().__init__(optimizer)

    def get_lr(self) -> list[float]:
        if self.last_epoch < self.warmup_epochs:
            scale = (self.last_epoch + 1) / max(1, self.warmup_epochs)
            return [base_lr * scale for base_lr in self.base_lrs]
        # Delegate to the wrapped scheduler after warmup.
        # Adjust the wrapped scheduler's epoch to account for warmup.
        wrapped_epoch = self.last_epoch - self.warmup_epochs
        self.wrapped_scheduler.last_epoch = wrapped_epoch
        return self.wrapped_scheduler.get_lr()

    def step(self, epoch=None, metric=None):
        """Step the scheduler, forwarding *metric* to plateau schedulers."""
        if epoch is not None:
            # PyTorch LRScheduler base class handles epoch-based stepping.
            return super().step(epoch)

        # Increment our own epoch counter.
        self.last_epoch += 1
        self._step_count += 1

        # After warmup, also step the wrapped scheduler.
        if self.last_epoch > self.warmup_epochs:
            if metric is not None and isinstance(
                self.wrapped_scheduler,
                optim.lr_scheduler.ReduceLROnPlateau,
            ):
                self.wrapped_scheduler.step(metric)
            else:
                self.wrapped_scheduler.step()

        # Update param groups from get_lr().
        values = self.get_lr()
        for group, lr in zip(self.optimizer.param_groups, values):
            group["lr"] = lr


# ---------------------------------------------------------------------------
# Legacy cosine-warmup scheduler (kept for backward compatibility)
# ---------------------------------------------------------------------------

class _CosineWarmupScheduler(optim.lr_scheduler.LRScheduler):
    """Cosine annealing with linear warmup.

    Learning rate linearly increases from 0 to the base LR over
    ``warmup_epochs``, then follows cosine annealing for the remainder.

    Parameters
    ----------
    optimizer:
        Wrapped optimizer.
    warmup_epochs:
        Number of warmup epochs.
    total_epochs:
        Total number of training epochs.
    """

    def __init__(
        self,
        optimizer: optim.Optimizer,
        warmup_epochs: int = 5,
        total_epochs: int = 100,
    ) -> None:
        self.warmup_epochs = warmup_epochs
        self.total_epochs = total_epochs
        super().__init__(optimizer)

    def get_lr(self) -> list[float]:
        if self.last_epoch < self.warmup_epochs:
            # Linear warmup
            scale = (self.last_epoch + 1) / max(1, self.warmup_epochs)
            return [base_lr * scale for base_lr in self.base_lrs]
        # Cosine annealing after warmup
        progress = (self.last_epoch - self.warmup_epochs) / max(
            1, self.total_epochs - self.warmup_epochs
        )
        cosine_decay = 0.5 * (1.0 + math.cos(math.pi * progress))
        return [base_lr * cosine_decay for base_lr in self.base_lrs]


# ---------------------------------------------------------------------------
# Internal: build the core scheduler (no warmup)
# ---------------------------------------------------------------------------

def _build_core_scheduler(
    optimizer: optim.Optimizer,
    sch_cfg: SchedulerConfig,
    epochs: int = 0,
    steps_per_epoch: int = 0,
) -> optim.lr_scheduler.LRScheduler | None:
    """Build the scheduler described by *sch_cfg* without warmup wrapping.

    Returns ``None`` when the scheduler type is ``"none"``.
    """
    sch_type = sch_cfg.type.lower() if sch_cfg.type else "cosine"

    if sch_type in ("none", None):
        return None
    elif sch_type == "cosine":
        t_max = sch_cfg.cosine_t_max if sch_cfg.cosine_t_max > 0 else epochs
        return optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=max(1, t_max),
            eta_min=sch_cfg.cosine_eta_min,
        )
    elif sch_type == "cosine_warmup":
        # Legacy path: build the combined cosine+warmup scheduler directly.
        warmup_epochs = sch_cfg.warmup_epochs if sch_cfg.warmup_epochs > 0 else 5
        total = sch_cfg.cosine_t_max if sch_cfg.cosine_t_max > 0 else epochs
        return _CosineWarmupScheduler(
            optimizer,
            warmup_epochs=warmup_epochs,
            total_epochs=max(1, total),
        )
    elif sch_type == "cosine_warmrestarts":
        t0 = sch_cfg.warmrestart_t0 if sch_cfg.warmrestart_t0 > 0 else 10
        return optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer,
            T_0=t0,
            T_mult=sch_cfg.warmrestart_t_mult,
            eta_min=sch_cfg.min_lr,
        )
    elif sch_type == "steplr":
        step_size = sch_cfg.step_size if sch_cfg.step_size > 0 else max(1, epochs // 3)
        return optim.lr_scheduler.StepLR(
            optimizer,
            step_size=max(1, step_size),
            gamma=sch_cfg.step_gamma,
        )
    elif sch_type == "plateau":
        return optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode=sch_cfg.plateau_mode,
            patience=sch_cfg.plateau_patience,
            factor=sch_cfg.plateau_factor,
            min_lr=sch_cfg.min_lr,
        )
    elif sch_type == "onecycle":
        total_steps = epochs * max(1, steps_per_epoch) if epochs > 0 and steps_per_epoch > 0 else epochs
        if total_steps <= 0:
            total_steps = 100  # safe fallback
        return optim.lr_scheduler.OneCycleLR(
            optimizer,
            max_lr=[pg["lr"] for pg in optimizer.param_groups],
            total_steps=total_steps,
            pct_start=sch_cfg.onecycle_pct_start,
        )
    else:
        raise ValueError(f"Unknown scheduler: {sch_type}")


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------

def create_scheduler(
    optimizer: optim.Optimizer,
    config,
    epochs: int = 0,
    steps_per_epoch: int = 0,
) -> optim.lr_scheduler.LRScheduler | None:
    """Create a learning-rate scheduler from configuration.

    Parameters
    ----------
    optimizer:
        The optimizer whose learning rate will be scheduled.
    config:
        One of:

        * :class:`SchedulerConfig` dataclass (V0.1.4+)
        * Full configuration ``dict`` with a ``"training"`` section (legacy)
        * Scheduler-level ``dict`` (no ``"training"`` key)
    epochs:
        Total training epochs.  Used as ``T_max`` when not provided in
        config.  When *config* is a dict the value is read from
        ``config["training"]["epochs"]`` instead.
    steps_per_epoch:
        Number of batches per epoch (used by one-cycle scheduler).

    Returns
    -------
    LRScheduler or None
        Instantiated scheduler, or ``None`` when disabled.

    Raises
    ------
    ValueError
        If ``scheduler`` names an unsupported scheduler.
    """
    # For legacy dict path, extract epochs from the dict.
    if isinstance(config, dict) and "training" in config:
        dict_epochs = int(config["training"].get("epochs", epochs))
        if epochs <= 0:
            epochs = dict_epochs

    sch_cfg = _resolve_scheduler_config(config, epochs)

    if sch_cfg.type is not None and sch_cfg.type.lower() == "none":
        return None

    # Build the core scheduler.
    scheduler = _build_core_scheduler(optimizer, sch_cfg, epochs, steps_per_epoch)

    if scheduler is None:
        return None

    # For the legacy "cosine_warmup" type the warmup is already baked into
    # the _CosineWarmupScheduler, so we don't double-wrap.
    if (
        sch_cfg.warmup_epochs > 0
        and sch_cfg.type.lower() not in ("cosine_warmup", "none")
    ):
        return _WarmupWrapper(
            optimizer,
            warmup_epochs=sch_cfg.warmup_epochs,
            wrapped_scheduler=scheduler,
        )

    return scheduler
