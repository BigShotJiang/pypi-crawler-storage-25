"""Per-model trainer with Rich display support.

Features:

* Train / validation loop with epoch-level metrics
* Checkpoint saving (``best_model.ckpt``, ``latest_model.ckpt``)
* Configurable monitoring metric for best-checkpoint selection
* Early stopping
* Rich progress bar + log panel (``--verbose``) or silent progress bar
* ASCII-box log file via :mod:`eemoclas.utils.log_formatter`
* Per-epoch ``metrics_history.csv``
* Config snapshot saved alongside checkpoints

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import csv
import logging
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from eemoclas.training.checkpoint import load_checkpoint, save_checkpoint
from eemoclas.training.early_stopping import EarlyStopping
from eemoclas.training.loss import compute_class_weights, create_criterion
from eemoclas.training.metrics import compute_train_metrics, compute_val_metrics
from eemoclas.training.optimizer import create_optimizer
from eemoclas.training.scheduler import create_scheduler
from eemoclas.utils.log_formatter import (
    box_footer,
    box_header,
    box_line,
    epoch_separator,
    epoch_title,
    metrics_line,
)
from eemoclas.utils.paths import ensure_dir

logger = logging.getLogger("dglz.training")


class Trainer:
    """Per-model trainer orchestrating the full training lifecycle.

    Parameters
    ----------
    config:
        Full configuration dictionary.  Expected top-level sections:
        ``training``, ``dataset``, ``model``, etc.
    model:
        A ``torch.nn.Module`` to train.
    device:
        The torch device to train on.
    manifest_df:
        Optional manifest DataFrame used to compute automatic class weights
        when ``training.class_weight`` is ``"auto"``.
    verbose:
        When ``True`` enables the Rich live display.  When ``False`` only
        file logging and a silent progress bar are used.

    Attributes
    ----------
    checkpoint_metric:
        Metric key used to decide whether the current model is the best
        (default ``"val_balanced_accuracy"``).
    """

    def __init__(
        self,
        config: dict,
        model: nn.Module,
        device: torch.device,
        manifest_df=None,
        verbose: bool = True,
    ) -> None:
        self.config = config
        self.model = model.to(device)
        self.device = device
        self.verbose = verbose
        self.epochs = int(config["training"]["epochs"])
        self.batch_size = int(config["training"]["batch_size"])
        self.checkpoint_metric = config["training"].get(
            "checkpoint_metric", "val_balanced_accuracy"
        )

        # Directories
        self.checkpoint_dir = ensure_dir(
            config.get("checkpoint_dir", "checkpoints")
        )
        self.log_dir = ensure_dir(config.get("log_dir", "logs"))

        # Resolve class weights for "auto" mode
        class_weight_cfg = config["training"].get("class_weight", None)
        auto_weights: torch.Tensor | None = None
        if class_weight_cfg == "auto" and manifest_df is not None:
            # Determine the label column name from manifest
            label_col = _detect_label_column(manifest_df)
            auto_weights = compute_class_weights(manifest_df, label_col=label_col)
            if auto_weights is not None:
                auto_weights = auto_weights.to(device)

        # Build training components
        self.criterion = create_criterion(config, class_weights=auto_weights)
        self.optimizer = create_optimizer(self.model, config)
        self.scheduler = create_scheduler(self.optimizer, config)

        # Early stopping
        es_cfg = config["training"].get("early_stopping", {})
        patience = int(es_cfg.get("patience", 15))
        es_mode = _metric_mode(self.checkpoint_metric)
        self.early_stopping = EarlyStopping(patience=patience, mode=es_mode)

        # Tracking state
        self.best_metric_value: float = -float("inf") if es_mode == "max" else float("inf")
        self._metrics_history: list[dict] = []
        self._start_time: float = 0.0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def train_epoch(self, dataloader: DataLoader, optimizer, criterion) -> dict:
        """Run a single training epoch.

        Parameters
        ----------
        dataloader:
            Training data loader.
        optimizer:
            Optimizer instance.
        criterion:
            Loss function.

        Returns
        -------
        dict
            ``{"loss": float, "accuracy": float}``
        """
        self.model.train()
        total_loss = 0.0
        all_preds: list[np.ndarray] = []
        all_labels: list[np.ndarray] = []
        n_batches = 0

        for batch in dataloader:
            # Support (x, y) tuples, dict batches, or raw tensors
            if isinstance(batch, (list, tuple)):
                x, y = batch[0], batch[1]
                token_meta = None
            elif isinstance(batch, dict):
                x = batch["x"]
                y = batch.get("y")
                token_meta = batch.get("token_meta")
            else:
                x, y = batch, None
                token_meta = None

            x = x.to(self.device, non_blocking=True)
            if y is not None:
                y = y.to(self.device, non_blocking=True)
                if y.dim() > 1:
                    y = y.squeeze(-1)

            optimizer.zero_grad()
            logits = self.model(x, token_meta=token_meta)

            if y is not None:
                loss = criterion(logits, y)
                loss.backward()
                # Gradient clipping
                clip_val = self.config.get("training", {}).get("gradient_clip_val", 0.0)
                if clip_val > 0:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=clip_val)
                optimizer.step()

                total_loss += loss.item() * x.size(0)
                preds = logits.argmax(dim=1).detach().cpu().numpy()
                labels = y.detach().cpu().numpy()
                all_preds.append(preds)
                all_labels.append(labels)
                n_batches += 1

        if n_batches == 0:
            return {"loss": 0.0, "accuracy": 0.0}

        avg_loss = total_loss / sum(p.size for p in all_preds)
        y_true = np.concatenate(all_labels)
        y_pred = np.concatenate(all_preds)

        return compute_train_metrics(avg_loss, y_true, y_pred)

    def validate_epoch(self, dataloader: DataLoader, criterion) -> dict:
        """Run a single validation epoch.

        Parameters
        ----------
        dataloader:
            Validation data loader.
        criterion:
            Loss function.

        Returns
        -------
        dict
            ``{"loss": float, "accuracy": float, "balanced_accuracy": float,
              "macro_f1": float, "auc": float | None}``
        """
        self.model.eval()
        total_loss = 0.0
        all_preds: list[np.ndarray] = []
        all_labels: list[np.ndarray] = []
        all_probs: list[np.ndarray] = []
        n_samples = 0

        with torch.no_grad():
            for batch in dataloader:
                if isinstance(batch, (list, tuple)):
                    x, y = batch[0], batch[1]
                    token_meta = None
                elif isinstance(batch, dict):
                    x = batch["x"]
                    y = batch.get("y")
                    token_meta = batch.get("token_meta")
                else:
                    x, y = batch, None
                    token_meta = None

                x = x.to(self.device, non_blocking=True)
                logits = self.model(x, token_meta=token_meta)

                if y is not None:
                    y = y.to(self.device, non_blocking=True)
                    if y.dim() > 1:
                        y = y.squeeze(-1)
                    loss = criterion(logits, y)
                    total_loss += loss.item() * x.size(0)

                    probs = torch.softmax(logits, dim=1).detach().cpu().numpy()
                    preds = logits.argmax(dim=1).detach().cpu().numpy()
                    labels = y.detach().cpu().numpy()

                    all_preds.append(preds)
                    all_labels.append(labels)
                    all_probs.append(probs)
                    n_samples += x.size(0)

        if n_samples == 0:
            return {"loss": 0.0, "accuracy": 0.0, "balanced_accuracy": 0.0, "macro_f1": 0.0}

        avg_loss = total_loss / n_samples
        y_true = np.concatenate(all_labels)
        y_pred = np.concatenate(all_preds)
        y_prob = np.concatenate(all_probs)

        return compute_val_metrics(avg_loss, y_true, y_pred, y_prob)

    def fit(self, train_loader: DataLoader, val_loader: DataLoader) -> dict:
        """Execute the full training loop.

        For each epoch the following steps are performed:

        1. Train epoch -> train metrics
        2. Validate epoch -> val metrics
        3. Log to file (ASCII box) and terminal (Rich if verbose)
        4. Update progress bar
        5. Check if val metric improved -> save ``best_model.ckpt``
        6. Save ``latest_model.ckpt``
        7. Check early stopping
        8. Append to ``metrics_history.csv``

        Parameters
        ----------
        train_loader:
            DataLoader for the training split.
        val_loader:
            DataLoader for the validation split.

        Returns
        -------
        dict
            Training summary with keys ``epochs_trained``,
            ``best_epoch``, ``best_metrics``, ``total_time_seconds``,
            ``early_stopped``.
        """
        self._start_time = time.time()
        display = self._create_display()
        best_epoch = 0
        best_metrics: dict = {}
        early_stopped = False

        # CSV path for metrics history
        csv_path = self.log_dir / "metrics_history.csv"

        # Write CSV header
        _csv_fields = self._csv_fieldnames()
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=_csv_fields)
            writer.writeheader()

        if display is not None:
            display.start()

        for epoch in range(1, self.epochs + 1):
            epoch_start = time.time()

            # 1. Train
            train_metrics = self.train_epoch(train_loader, self.optimizer, self.criterion)

            # 2. Validate
            val_metrics = self.validate_epoch(val_loader, self.criterion)

            # 3. Step scheduler
            if self.scheduler is not None:
                if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    monitor_val = val_metrics.get(
                        self.checkpoint_metric.replace("val_", ""),
                        val_metrics.get("loss", 0.0),
                    )
                    self.scheduler.step(monitor_val)
                else:
                    self.scheduler.step()

            # 4. Merge metrics for logging
            combined = {f"train_{k}": v for k, v in train_metrics.items()}
            combined.update({f"val_{k}": v for k, v in val_metrics.items()})
            combined["epoch"] = epoch
            combined["lr"] = self.optimizer.param_groups[0]["lr"]
            combined["time_s"] = round(time.time() - epoch_start, 2)

            # 5. Log to file
            self._log_epoch(epoch, train_metrics, val_metrics, combined)

            # 6. Check best
            monitor_key = self.checkpoint_metric  # e.g. "val_balanced_accuracy"
            current_score = combined.get(monitor_key, combined.get("val_loss", 0.0))
            is_best = self._is_improvement(current_score)
            if is_best:
                self.best_metric_value = current_score
                best_epoch = epoch
                best_metrics = copy_metrics(combined)
                save_checkpoint(
                    self.model,
                    self.optimizer,
                    epoch,
                    best_metrics,
                    self.config,
                    self.checkpoint_dir / "best_model.ckpt",
                )
                logger.info("New best model at epoch %d (%s=%.4f)", epoch, monitor_key, current_score)

            # 7. Save latest
            save_checkpoint(
                self.model,
                self.optimizer,
                epoch,
                combined,
                self.config,
                self.checkpoint_dir / "latest_model.ckpt",
            )

            # 8. Append to CSV
            with open(csv_path, "a", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=_csv_fields)
                writer.writerow({k: combined.get(k, "") for k in _csv_fields})

            # 9. Update display
            if display is not None:
                display.update(epoch, metrics=combined)

            # 10. Early stopping
            if self.early_stopping.step(current_score):
                early_stopped = True
                logger.info("Early stopping at epoch %d.", epoch)
                break

        if display is not None:
            display.stop()

        total_time = round(time.time() - self._start_time, 2)

        summary = {
            "epochs_trained": epoch,
            "best_epoch": best_epoch,
            "best_metrics": best_metrics,
            "total_time_seconds": total_time,
            "early_stopped": early_stopped,
        }

        logger.info(
            "Training complete: %d epochs, best epoch=%d, time=%.1fs",
            epoch,
            best_epoch,
            total_time,
        )

        return summary

    def resume_from_checkpoint(self, path: str | Path) -> int:
        """Resume training state from a checkpoint.

        Parameters
        ----------
        path:
            Path to a ``.ckpt`` file.

        Returns
        -------
        int
            The epoch number stored in the checkpoint (training will continue
            from ``epoch + 1``).
        """
        info = load_checkpoint(path, self.model, device=self.device)
        epoch = info["epoch"]

        # Also restore optimizer state if available
        ckpt = torch.load(str(Path(path)), map_location=self.device, weights_only=False)
        if "optimizer_state_dict" in ckpt:
            self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])

        # Reset early stopping best score if metrics are available
        metrics = info.get("metrics", {})
        monitor_key = self.checkpoint_metric
        if monitor_key in metrics:
            self.best_metric_value = metrics[monitor_key]

        logger.info("Resumed from checkpoint at epoch %d.", epoch)
        return epoch

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _create_display(self):
        """Instantiate the appropriate display (Rich or silent)."""
        try:
            if self.verbose:
                from eemoclas.utils.verbose_display import VerboseLiveDisplay
                return VerboseLiveDisplay(total_epochs=self.epochs, description="Training")
            else:
                from eemoclas.utils.verbose_display import SilentProgressBar
                return SilentProgressBar(total_epochs=self.epochs, description="Training")
        except Exception:
            logger.debug("Rich display unavailable; falling back to log-only mode.")
            return None

    def _log_epoch(
        self,
        epoch: int,
        train_metrics: dict,
        val_metrics: dict,
        combined: dict,
    ) -> None:
        """Write an epoch's results to the log file.

        Uses a compact single-line format per epoch for easy parsing and
        grep-ability, similar to JwzTumor's epoch log style.
        """
        # Format metrics as "key=value" pairs
        train_parts = [
            f"{k}={v:.4f}" for k, v in train_metrics.items() if isinstance(v, float)
        ]
        val_parts = [
            f"{k}={v:.4f}" for k, v in val_metrics.items() if isinstance(v, float)
        ]

        lr = combined.get("lr", 0.0)
        lr_str = f"{lr:.1e}" if lr < 0.001 else f"{lr:.6f}"
        time_s = combined.get("time_s", 0.0)

        logger.info(
            "[Epoch %d/%d]  train: %s | val: %s | lr=%s | time=%.1fs",
            epoch,
            self.epochs,
            " | ".join(train_parts) if train_parts else "N/A",
            " | ".join(val_parts) if val_parts else "N/A",
            lr_str,
            time_s,
        )

        # Log checkpoint metric if improved
        if self.checkpoint_metric in combined:
            logger.info(
                "  monitor (%s): %.4f",
                self.checkpoint_metric,
                combined[self.checkpoint_metric],
            )

    def _csv_fieldnames(self) -> list[str]:
        """Return the column names for the metrics CSV."""
        base = ["epoch", "train_loss", "train_accuracy", "val_loss", "val_accuracy",
                "val_balanced_accuracy", "val_macro_f1", "val_auc", "lr", "time_s"]
        return base

    def _is_improvement(self, score: float) -> bool:
        """Check whether *score* improves the tracked best."""
        mode = _metric_mode(self.checkpoint_metric)
        if mode == "max":
            return score > self.best_metric_value
        else:
            return score < self.best_metric_value


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------

def _metric_mode(metric_name: str) -> str:
    """Determine whether a metric should be maximised or minimised.

    Returns ``"max"`` for accuracy / AUC / F1-type metrics and ``"min"``
    for loss-type metrics.
    """
    loss_keywords = ("loss",)
    lower = metric_name.lower()
    for kw in loss_keywords:
        if kw in lower:
            return "min"
    return "max"


def _detect_label_column(manifest_df) -> str:
    """Detect the label column name in a manifest DataFrame.

    Checks for common names in order: ``"y"``, ``"label"``,
    ``"emotion_label"``, ``"group_label"``.
    """
    candidates = ["y", "label", "emotion_label", "group_label"]
    for col in candidates:
        if col in manifest_df.columns:
            return col
    # Fall back to the last column
    return manifest_df.columns[-1]


def copy_metrics(d: dict) -> dict:
    """Deep-copy a metrics dictionary."""
    import copy
    return copy.deepcopy(d)
