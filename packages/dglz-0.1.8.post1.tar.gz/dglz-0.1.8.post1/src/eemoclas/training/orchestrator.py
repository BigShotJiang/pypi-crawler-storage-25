"""Multi-model training orchestrator.

Manages training of multiple models with three execution modes:

* **sequential** -- train models one at a time in the order given.
* **parallel** -- train models concurrently in separate subprocesses
  (using ``multiprocessing`` with *spawn* context to avoid CUDA
  re-initialisation issues).
* **mixed** -- train some models sequentially and others in parallel.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import logging
import multiprocessing
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from eemoclas.config.dataclasses import (
    Config,
    ModelGroupConfig,
    _dataclass_to_dict,
)
from eemoclas.training.experiment import ExperimentManager

logger = logging.getLogger("dglz.orchestrator")


class MultiModelTrainer:
    """Orchestrate multi-model training runs.

    Parameters
    ----------
    config:
        Full :class:`Config` dataclass.
    model_names:
        Ordered list of model-group names to train.
    mode:
        ``"sequential"`` | ``"parallel"`` | ``"mixed"``.
    parallel_models:
        When *mode* is ``"mixed"``, the subset of *model_names* that should
        be trained in parallel.  Ignored for the other two modes.
    experiment_mgr:
        Optional pre-built :class:`ExperimentManager`.  If ``None`` one is
        created from ``config.experiment``.
    verbose:
        When ``True`` log high-level progress messages.
    """

    def __init__(
        self,
        config: Config,
        model_names: list[str],
        mode: str = "sequential",
        parallel_models: list[str] | None = None,
        experiment_mgr: ExperimentManager | None = None,
        verbose: bool = True,
    ) -> None:
        if mode not in ("sequential", "parallel", "mixed"):
            raise ValueError(
                f"Invalid mode '{mode}'. Must be one of: sequential, parallel, mixed"
            )
        self.config = config
        self.model_names = model_names
        self.mode = mode
        self.parallel_models = parallel_models or []
        self.experiment_mgr = experiment_mgr or ExperimentManager(config.experiment)
        self.verbose = verbose
        self.results: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> dict[str, dict[str, Any]]:
        """Execute training for all models and return results per model.

        Returns
        -------
        dict[str, dict]
            Mapping of model name to its training summary dict (keys
            include ``epochs_trained``, ``best_epoch``, ``best_metrics``,
            ``total_time_seconds``, ``early_stopped``).
        """
        self.experiment_mgr.init_training_state(self.model_names)
        self.experiment_mgr.save_config_snapshot(self.config.config_snapshot())

        if self.mode == "sequential":
            self._train_sequential(self.model_names)
        elif self.mode == "parallel":
            self._train_parallel(self.model_names)
        elif self.mode == "mixed":
            seq = [m for m in self.model_names if m not in self.parallel_models]
            par = [m for m in self.model_names if m in self.parallel_models]
            self._train_sequential(seq)
            self._train_parallel(par)

        return self.results

    # ------------------------------------------------------------------
    # Execution strategies
    # ------------------------------------------------------------------

    def _train_sequential(self, model_names: list[str]) -> None:
        """Train *model_names* one by one."""
        for name in model_names:
            self.experiment_mgr.update_model_state(name, "running")
            try:
                result = self._train_single(name)
                self.results[name] = result
                self.experiment_mgr.update_model_state(
                    name,
                    "completed",
                    best_epoch=result.get("best_epoch", 0),
                    best_metric=result.get("best_metrics", {}).get(
                        "val_balanced_accuracy", 0.0
                    ),
                )
                if self.verbose:
                    logger.info("Model '%s' completed training.", name)
            except Exception:
                self.experiment_mgr.update_model_state(name, "failed")
                if self.verbose:
                    logger.exception("Model '%s' failed.", name)
                raise

    def _train_parallel(self, model_names: list[str]) -> None:
        """Train *model_names* concurrently in separate processes.

        Uses ``multiprocessing.get_context("spawn")`` to avoid CUDA
        re-initialisation issues when training on GPU.
        """
        if not model_names:
            return

        ctx = multiprocessing.get_context("spawn")
        config_dict = _dataclass_to_dict(self.config)
        experiment_dir = str(self.experiment_mgr.config.experiment_dir)

        processes: list[multiprocessing.process.BaseProcess] = []
        for name in model_names:
            p = ctx.Process(
                target=_train_model_in_process,
                args=(config_dict, name, experiment_dir),
                name=f"dglz-train-{name}",
            )
            p.start()
            processes.append((name, p))

        # Collect results -- wait for all processes to finish
        failed: list[str] = []
        for name, p in processes:
            p.join()
            if p.exitcode != 0:
                failed.append(name)
                self.experiment_mgr.update_model_state(name, "failed")
            else:
                self.results[name] = _placeholder_result()
                self.experiment_mgr.update_model_state(name, "completed")

        if failed:
            raise RuntimeError(
                f"Parallel training failed for models: {failed}"
            )

    # ------------------------------------------------------------------
    # Single-model training (full implementation)
    # ------------------------------------------------------------------

    def _train_single(self, model_name: str) -> dict[str, Any]:
        """Train a single model end-to-end.

        Converts the dataclass config to a raw dict, loads the dataset,
        creates DataLoaders, instantiates the model, and delegates to
        :class:`Trainer.fit()`.
        """
        import pandas as pd
        from eemoclas.model.model_factory import create_model
        from eemoclas.datasets.resampled_dataset import ResampledTensorDataset
        from eemoclas.datasets.splitting import build_group_splits
        from eemoclas.datasets.collate import collate_subject_state, collate_emotion
        from eemoclas.training.trainer import Trainer
        from eemoclas.utils.paths import ensure_dir

        model_cfg = self.config.get_model_config(model_name)
        raw = self._build_raw_dict(model_name, model_cfg)

        # --- Resolve device ---
        device_str = raw["training"].get("device", "auto")
        if device_str == "auto":
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            device = torch.device(device_str)

        if self.verbose:
            logger.info("Training '%s' on %s", model_name, device)

        # --- Resolve manifest path ---
        manifest_path = _resolve_manifest_path(self.config, model_name)
        if manifest_path is None or not Path(manifest_path).is_file():
            raise FileNotFoundError(
                f"Manifest not found for model '{model_name}'. "
                f"Looked at: {manifest_path}. "
                f"Run `eemo resample` first to generate training data."
            )

        manifest_df = pd.read_csv(manifest_path)

        if self.verbose:
            logger.info(
                "Manifest: %s (%d samples)", manifest_path, len(manifest_df)
            )

        # --- Create dataset ---
        dataset = ResampledTensorDataset(manifest_path)

        # --- Train/val split ---
        splitting_cfg = raw.get("splitting", {})
        stratify_key = (
            "group_label" if model_name == "subject_state" else "emotion_label"
        )
        if stratify_key not in manifest_df.columns:
            stratify_key = None

        splits = build_group_splits(
            manifest_path,
            group_key="subject_id",
            stratify_key=stratify_key,
            n_splits=splitting_cfg.get("n_splits", 5),
            seed=splitting_cfg.get("seed", 42),
            method=splitting_cfg.get("method", "StratifiedGroupKFold"),
            train_ratio=splitting_cfg.get("train_ratio", 0.8),
            val_ratio=splitting_cfg.get("val_ratio", 0.2),
        )
        train_idx, val_idx = splits[0]

        if self.verbose:
            logger.info("Train/Val split: %d/%d", len(train_idx), len(val_idx))

        # --- DataLoaders ---
        batch_size = raw["training"].get("batch_size", 16)
        num_workers = raw["training"].get("num_workers", 0)

        _collate = (
            collate_subject_state
            if model_name == "subject_state"
            else collate_emotion
        )

        train_loader = DataLoader(
            Subset(dataset, train_idx),
            batch_size=batch_size,
            shuffle=True,
            collate_fn=_collate,
            num_workers=num_workers,
            pin_memory=(device.type == "cuda"),
        )
        val_loader = DataLoader(
            Subset(dataset, val_idx),
            batch_size=batch_size,
            shuffle=False,
            collate_fn=_collate,
            num_workers=num_workers,
            pin_memory=(device.type == "cuda"),
        )

        # --- Create model ---
        model = create_model(model_name, raw)

        if self.verbose:
            total_params = sum(p.numel() for p in model.parameters())
            logger.info("Model parameters: %s", f"{total_params:,}")

        # --- Create Trainer and fit ---
        trainer = Trainer(
            config=raw,
            model=model,
            device=device,
            manifest_df=manifest_df,
            verbose=self.verbose,
        )
        result = trainer.fit(train_loader, val_loader)
        return result

    def _build_raw_dict(self, model_name: str, mc: ModelGroupConfig) -> dict[str, Any]:
        """Convert a :class:`ModelGroupConfig` to a raw dict for Trainer."""
        raw: dict[str, Any] = _dataclass_to_dict(self.config)
        raw["task"] = _dataclass_to_dict(mc.task)
        raw["model"] = _dataclass_to_dict(mc.model)
        raw["training"] = _dataclass_to_dict(mc.training)
        raw["augmentation"] = _dataclass_to_dict(mc.augmentation)
        raw["splitting"] = _dataclass_to_dict(mc.splitting)
        raw["seeding"] = _dataclass_to_dict(mc.seeding)
        raw["checkpoint_dir"] = str(
            self.experiment_mgr.model_checkpoint_dir(model_name)
        )
        raw["log_dir"] = str(self.experiment_mgr.config.log_dir)
        return raw


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _placeholder_result() -> dict[str, Any]:
    """Return a placeholder training result for parallel mode."""
    return {
        "epochs_trained": 0,
        "best_epoch": 0,
        "best_metrics": {},
        "total_time_seconds": 0,
        "early_stopped": False,
    }


def _resolve_manifest_path(config: Config, model_name: str) -> str | None:
    """Resolve the manifest CSV path for a given model.

    Checks in order:
    1. ``config.data.manifests[model_name]``
    2. Conventional path ``data/resampled/{model_name}/version_001/manifest.csv``
    """
    # 1. From config data.manifests
    manifests = config.data.manifests
    if manifests and model_name in manifests:
        path = manifests[model_name]
        if path:
            return path

    # 2. Conventional path
    conventional = Path("data/resampled") / model_name / "version_001" / "manifest.csv"
    if conventional.is_file():
        return str(conventional)

    # 3. Return the conventional path anyway (will fail with clear message)
    return str(conventional)


def _train_model_in_process(
    config_dict: dict[str, Any],
    model_name: str,
    experiment_dir: str,
) -> None:
    """Entry point for parallel training subprocesses.

    Reconstructs a :class:`Config` from *config_dict*, creates a fresh
    :class:`ExperimentManager`, and delegates to a single-model
    :class:`MultiModelTrainer` run.
    """
    from eemoclas.config.loader import _dict_to_config

    config = _dict_to_config(config_dict)
    mgr = ExperimentManager(config.experiment)
    orchestrator = MultiModelTrainer(
        config,
        [model_name],
        "sequential",
        experiment_mgr=mgr,
        verbose=False,
    )
    orchestrator.run()
