"""``eemo exp-train`` -- training experiment management.

Provides subcommands for listing, viewing, comparing, and cleaning training
experiments stored under the ``checkpoints/`` directory.
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime
from pathlib import Path

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
    print_cli_warning,
)

app = typer.Typer(help="训练实验管理")


@app.command(name="list")
def list_experiments(
    checkpoint_dir: str = typer.Option(
        "experiments/default/checkpoints", "--checkpoint-dir", help="检查点根目录",
    ),
) -> None:
    """列出所有训练实验。"""
    print_cli_header("训练实验列表")

    base = Path(checkpoint_dir)
    if not base.is_dir():
        print_cli_warning(f"检查点目录不存在: {base}")
        console.print()
        return

    from rich.table import Table

    table = Table(title="实验列表", show_header=True, border_style="cyan")
    table.add_column("名称", style="bold")
    table.add_column("检查点数", justify="right")
    table.add_column("最佳指标", justify="right")
    table.add_column("最后修改时间")

    for exp_dir in sorted(base.iterdir()):
        if not exp_dir.is_dir():
            continue
        ckpts = list(exp_dir.glob("*.ckpt"))
        best_metric = _read_best_metric(exp_dir)
        mtime = datetime.fromtimestamp(exp_dir.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
        table.add_row(
            exp_dir.name,
            str(len(ckpts)),
            f"{best_metric:.4f}" if best_metric is not None else "N/A",
            mtime,
        )

    console.print(table)
    console.print()


@app.command()
def summary(
    name: str = typer.Option(..., "--name", help="实验名称"),
    checkpoint_dir: str = typer.Option("checkpoints", "--checkpoint-dir", help="检查点根目录"),
) -> None:
    """查看训练实验详情。"""
    print_cli_header(f"实验详情: {name}")

    exp_dir = Path(checkpoint_dir) / name
    if not exp_dir.is_dir():
        print_cli_error(f"实验未找到: {exp_dir}")
        raise typer.Exit(code=1)

    ckpts = list(exp_dir.glob("*.ckpt"))
    console.print(f"  检查点数量: [cyan]{len(ckpts)}[/cyan]")

    # Read best checkpoint info
    best_path = exp_dir / "best_model.ckpt"
    if best_path.is_file():
        info = _read_checkpoint_info(best_path)
        if info:
            console.print(f"  最佳轮次: [cyan]{info.get('epoch', 'N/A')}[/cyan]")
            metrics = info.get("metrics", {})
            for k, v in metrics.items():
                console.print(f"    {k}: [cyan]{v:.4f}[/cyan]" if isinstance(v, float)
                              else f"    {k}: [cyan]{v}[/cyan]")
    else:
        print_cli_warning("未找到 best_model.ckpt")

    console.print()


@app.command()
def compare(
    names: str = typer.Option(..., "--names", help="逗号分隔的实验名称列表"),
    checkpoint_dir: str = typer.Option("checkpoints", "--checkpoint-dir", help="检查点根目录"),
) -> None:
    """比较多个实验。"""
    print_cli_header("实验比较")

    exp_names = [n.strip() for n in names.split(",")]
    base = Path(checkpoint_dir)

    from rich.table import Table

    table = Table(title="实验对比", show_header=True, border_style="cyan")
    table.add_column("指标", style="bold")

    valid_experiments = []
    for ename in exp_names:
        exp_dir = base / ename
        if not exp_dir.is_dir():
            print_cli_warning(f"实验未找到: {ename}")
            continue
        table.add_column(ename, justify="right")
        valid_experiments.append(ename)

    if not valid_experiments:
        print_cli_error("无有效的实验可比较")
        raise typer.Exit(code=1)

    # Gather metrics from best_model.ckpt of each experiment
    all_metrics: dict[str, list[str]] = {}
    for ename in valid_experiments:
        best_path = base / ename / "best_model.ckpt"
        info = _read_checkpoint_info(best_path)
        metrics = info.get("metrics", {}) if info else {}
        for k, v in metrics.items():
            if k not in all_metrics:
                all_metrics[k] = []
            formatted = f"{v:.4f}" if isinstance(v, float) else str(v)
            all_metrics[k].append(formatted)

    # Add epoch info
    epochs_row = []
    for ename in valid_experiments:
        best_path = base / ename / "best_model.ckpt"
        info = _read_checkpoint_info(best_path)
        epochs_row.append(str(info.get("epoch", "N/A")) if info else "N/A")
    all_metrics = {"epoch": epochs_row, **all_metrics}

    for metric_name, values in all_metrics.items():
        row = [metric_name] + values
        table.add_row(*row)

    console.print(table)
    console.print()


@app.command()
def clean(
    before: str = typer.Option(None, "--before", help="删除早于此日期的实验 (YYYY-MM-DD)"),
    keep_best: int = typer.Option(3, "--keep-best", help="保留最佳 N 个实验"),
    checkpoint_dir: str = typer.Option("checkpoints", "--checkpoint-dir", help="检查点根目录"),
    dry_run: bool = typer.Option(True, "--dry-run", help="仅预览，不实际删除"),
) -> None:
    """清理失败或过期的实验。"""
    print_cli_header("实验清理")

    base = Path(checkpoint_dir)
    if not base.is_dir():
        print_cli_warning(f"检查点目录不存在: {base}")
        console.print()
        return

    candidates: list[tuple[str, Path, float]] = []

    for exp_dir in sorted(base.iterdir()):
        if not exp_dir.is_dir():
            continue

        # Check if experiment looks failed (no best_model.ckpt)
        best_path = exp_dir / "best_model.ckpt"
        if not best_path.is_file():
            candidates.append((exp_dir.name, exp_dir, 0.0))
            continue

        # Check age
        if before is not None:
            mtime = datetime.fromtimestamp(exp_dir.stat().st_mtime)
            cutoff = datetime.strptime(before, "%Y-%m-%d")
            if mtime < cutoff:
                metric = _read_best_metric(exp_dir) or 0.0
                candidates.append((exp_dir.name, exp_dir, metric))

    if not candidates:
        print_cli_success("没有需要清理的实验")
        console.print()
        return

    # Sort by metric and keep top N
    candidates.sort(key=lambda x: x[2], reverse=True)
    to_remove = candidates[keep_best:]

    if not to_remove:
        print_cli_success("所有实验均在保留阈值内")
        console.print()
        return

    for name, path, metric in to_remove:
        action = "将删除" if dry_run else "正在删除"
        console.print(f"  {action}: [yellow]{name}[/yellow] (指标={metric:.4f})")
        if not dry_run:
            shutil.rmtree(path)

    if dry_run:
        console.print(f"\n  [bold]预览模式[/bold] -- 使用 [cyan]--no-dry-run[/cyan] 实际执行删除")

    console.print()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _read_best_metric(exp_dir: Path) -> float | None:
    """Read the accuracy metric from best_model.ckpt in an experiment directory."""
    best_path = exp_dir / "best_model.ckpt"
    info = _read_checkpoint_info(best_path)
    if info:
        metrics = info.get("metrics", {})
        return metrics.get("accuracy", metrics.get("val_auc", None))
    return None


def _read_checkpoint_info(ckpt_path: Path) -> dict | None:
    """Read lightweight info from a checkpoint without loading model weights."""
    if not ckpt_path.is_file():
        return None
    try:
        import torch
        data = torch.load(str(ckpt_path), map_location="cpu", weights_only=False)
        return {
            "epoch": data.get("epoch"),
            "metrics": data.get("metrics", {}),
        }
    except Exception:
        return None
