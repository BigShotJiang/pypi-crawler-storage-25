"""``eemo ckpt`` -- checkpoint management.

Provides subcommands for listing, inspecting, and exporting model checkpoints.
"""

from __future__ import annotations

import os
import shutil
from datetime import datetime
from pathlib import Path

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
    print_cli_warning,
)

app = typer.Typer(help="检查点管理")


@app.command(name="list")
def list_checkpoints(
    config: str = typer.Option(None, "--config", help="配置 YAML（用于解析检查点目录）"),
    checkpoint_dir: str = typer.Option("experiments/default/checkpoints", "--checkpoint-dir", help="检查点根目录"),
) -> None:
    """列出所有检查点。"""
    print_cli_header("检查点列表")

    # Resolve checkpoint directory from config if provided
    base_dir = checkpoint_dir
    if config is not None and os.path.isfile(config):
        from eemoclas.utils.config import load_config
        cfg = load_config(config)
        base_dir = cfg.get("training", {}).get("checkpoint_dir", base_dir)

    base = Path(base_dir)
    if not base.is_dir():
        print_cli_warning(f"检查点目录不存在: {base}")
        console.print()
        return

    from rich.table import Table

    table = Table(title="已保存的检查点", show_header=True, border_style="cyan")
    table.add_column("模型", style="bold")
    table.add_column("文件", style="cyan")
    table.add_column("大小 (MB)", justify="right")
    table.add_column("最后修改")

    for exp_dir in sorted(base.iterdir()):
        if not exp_dir.is_dir():
            continue
        for ckpt in sorted(exp_dir.glob("*.ckpt")):
            size_mb = ckpt.stat().st_size / (1024 * 1024)
            mtime = datetime.fromtimestamp(ckpt.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
            table.add_row(
                exp_dir.name,
                ckpt.name,
                f"{size_mb:.1f}",
                mtime,
            )

    if table.row_count == 0:
        print_cli_warning("未找到检查点文件")
    else:
        console.print(table)

    console.print()


@app.command()
def info(
    path: str = typer.Argument(..., help="检查点文件路径"),
) -> None:
    """显示检查点详情。"""
    print_cli_header("检查点详情")

    ckpt_path = Path(path)
    if not ckpt_path.is_file():
        print_cli_error(f"检查点未找到: {ckpt_path}")
        raise typer.Exit(code=1)

    try:
        import torch
        data = torch.load(str(ckpt_path), map_location="cpu", weights_only=False)
    except Exception as exc:
        print_cli_error(f"检查点加载失败: {exc}")
        raise typer.Exit(code=1)

    from rich.table import Table

    # Basic info table
    table = Table(title="检查点详情", show_header=True, border_style="cyan")
    table.add_column("字段", style="bold")
    table.add_column("值")

    table.add_row("文件", str(ckpt_path))
    table.add_row("大小", f"{ckpt_path.stat().st_size / (1024 * 1024):.2f} MB")
    table.add_row("轮次", str(data.get("epoch", "N/A")))

    # Config snapshot summary
    config_snap = data.get("config_snapshot", {})
    if config_snap:
        table.add_row("配置键", ", ".join(sorted(config_snap.keys())))

    console.print(table)

    # Metrics
    metrics = data.get("metrics", {})
    if metrics:
        from rich.panel import Panel

        metrics_table = Table(show_header=True, border_style="green")
        metrics_table.add_column("指标", style="bold cyan")
        metrics_table.add_column("值", justify="right")
        for k, v in metrics.items():
            formatted = f"{v:.4f}" if isinstance(v, float) else str(v)
            metrics_table.add_row(k, formatted)
        console.print(Panel(metrics_table, title="指标", border_style="green"))

    # Model state dict summary
    state_dict = data.get("model_state_dict", {})
    if state_dict:
        n_params = sum(v.numel() for v in state_dict.values() if hasattr(v, "numel"))
        console.print(f"  模型参数量: [cyan]{n_params:,}[/cyan]")

    console.print()


@app.command()
def export(
    name: str = typer.Argument(..., help="模型名称 (subject_state, normal_emotion, depression_emotion)"),
    output: str = typer.Option(None, "--output", help="导出目标路径"),
    checkpoint_dir: str = typer.Option("experiments/default/checkpoints", "--checkpoint-dir", help="检查点根目录"),
) -> None:
    """导出模型最佳检查点。"""
    print_cli_header(f"导出检查点: {name}")

    best_path = Path(checkpoint_dir) / name / "best_model.ckpt"
    if not best_path.is_file():
        print_cli_error(f"最佳检查点未找到: {best_path}")
        raise typer.Exit(code=1)

    # Determine output path
    if output is None:
        output = f"export/{name}_best.ckpt"
    dest = Path(output)
    dest.parent.mkdir(parents=True, exist_ok=True)

    # Copy checkpoint
    shutil.copy2(str(best_path), str(dest))
    print_cli_success(f"已导出到 {dest}")

    # Also extract model weights only
    try:
        import torch
        data = torch.load(str(best_path), map_location="cpu", weights_only=False)
        weights_path = dest.with_suffix(".pt")
        torch.save(data["model_state_dict"], str(weights_path))
        print_cli_success(f"仅模型权重: {weights_path}")
    except Exception as exc:
        print_cli_warning(f"无法提取纯权重文件: {exc}")

    console.print()
