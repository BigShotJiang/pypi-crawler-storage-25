"""Build Orchestrator — drives the full documentation build.

New pipeline:
    1. Walk docs folder → Node tree + SourceData cache
    2. Build cross-link index
    3. Generate search index
    4. For each node:
       a. Render tags ({{data}} + %presentation()%) in Markdown body
       b. Convert Markdown → HTML
       c. Resolve [[cross-links]]
       d. Assemble 3-column HTML page
       e. Write to output_dir
    5. Copy assets
"""

from __future__ import annotations

import argparse
import importlib.resources
import json
import os
import shutil
import sys

from slop_doc.tree_builder import (
    build_tree, build_tree_with_root, Node, TreeBuilderError,
)
from slop_doc.tag_renderer import (
    render_data_tags_inline,
    render_presentation_functions,
    TagRendererError,
)
from slop_doc.cross_links import build_index, resolve_links, CrossLinkError, CrossLinkIndex
from slop_doc.markdown_renderer import markdown_to_html
from slop_doc.layout import assemble_page, generate_search_index


class BuildError(Exception):
    """Raised when the build fails."""
    pass


# ---------------------------------------------------------------------------
# Project config  (read from root.md front-matter)
# ---------------------------------------------------------------------------

def _read_project_config(docs_root: str) -> dict:
    """Read project-level config from root.md front-matter.

    Recognised keys in front-matter ``raw``:
        project_name, version, output_dir, assets_dir
    """
    from slop_doc.frontmatter import parse_frontmatter, FrontmatterError

    root_md = os.path.join(docs_root, 'root.md')
    if not os.path.isfile(root_md):
        return {}

    with open(root_md, 'r', encoding='utf-8') as f:
        raw = f.read()

    try:
        meta, _ = parse_frontmatter(raw)
    except FrontmatterError:
        return {}

    return meta.raw


# ---------------------------------------------------------------------------
# Asset copying
# ---------------------------------------------------------------------------

def _copy_assets(assets_dir: str | None, output_dir: str, defaults_dir: str) -> None:
    """Copy assets into output_dir/assets/.

    User assets_dir takes priority; missing style.css falls back to defaults.
    search.js always comes from defaults.
    """
    output_assets = os.path.join(output_dir, 'assets')
    if os.path.exists(output_assets):
        shutil.rmtree(output_assets)
    os.makedirs(output_assets, exist_ok=True)

    # Copy user assets
    if assets_dir and os.path.isdir(assets_dir):
        for item in os.listdir(assets_dir):
            src = os.path.join(assets_dir, item)
            dst = os.path.join(output_assets, item)
            if os.path.isdir(src):
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

    # Fallback style.css
    style_dest = os.path.join(output_assets, 'style.css')
    if not os.path.exists(style_dest):
        default_style = os.path.join(defaults_dir, 'style.css')
        if os.path.exists(default_style):
            shutil.copy2(default_style, style_dest)

    # Always copy search.js from defaults
    default_search = os.path.join(defaults_dir, 'search.js')
    if os.path.exists(default_search):
        shutil.copy2(default_search, os.path.join(output_assets, 'search.js'))


# ---------------------------------------------------------------------------
# Auto-generated page content  (for class / function child nodes)
# ---------------------------------------------------------------------------

def _generate_auto_class_content(class_name: str) -> str:
    """Generate Markdown body for an auto-generated class page."""
    return f"""# {class_name}

%class_description({class_name})%

## Info

%class_info({class_name})%

## Properties

%properties({class_name})%

## Public Methods

%methods_table({class_name})%

## Private Methods

%methods_table({class_name}, private)%

## Method Details

%methods_details({class_name})%
"""


def _generate_auto_function_content(func_name: str) -> str:
    """Generate Markdown body for an auto-generated function page."""
    return f"# {func_name}\n\n*(auto-generated function page)*\n"


# ---------------------------------------------------------------------------
# Build pipeline
# ---------------------------------------------------------------------------

def build_docs(docs_root: str) -> None:
    """Build all documentation from a docs folder.

    Args:
        docs_root: Path to the documentation root (folder containing root.md).

    Raises:
        BuildError: If the build fails.
    """
    try:
        # --- Config ---
        config = _read_project_config(docs_root)
        project_name = config.get('project_name', 'Documentation')
        version = config.get('version', '')
        output_dir = os.path.join(docs_root, config.get('output_dir', 'build'))
        assets_dir_raw = config.get('assets_dir')
        assets_dir = os.path.join(docs_root, assets_dir_raw) if assets_dir_raw else None

        defaults_pkg = importlib.resources.files("slop_doc.defaults")
        defaults_dir = str(defaults_pkg)

        os.makedirs(output_dir, exist_ok=True)

        # --- Step 1: Build tree ---
        output_dir_name = os.path.basename(output_dir.rstrip('/\\'))
        root_node, source_data_by_folder = build_tree_with_root(docs_root, exclude_dirs={output_dir_name})
        tree = root_node.children  # top-level nav tree

        # --- Step 2: Build cross-link index ---
        index = build_index(tree, source_data_by_folder)

        # --- Step 3: Search index ---
        search_index = generate_search_index(tree, source_data_by_folder)

        # --- Step 4: Build index.html from root.md content ---
        if root_node.content:
            _build_page(
                root_node, root_node.content, tree, index,
                project_name, version, search_index, output_dir,
                source_data_by_folder, is_index=True,
            )

        # --- Step 5: Build all pages ---
        pages_built = 0
        for node in _iterate_nodes(tree):
            body = node.content

            # Auto-generated pages
            if node.is_auto and node.auto_class:
                body = _generate_auto_class_content(node.auto_class)
            elif node.is_auto and node.auto_function:
                body = _generate_auto_function_content(node.auto_function)

            if not body and not node.children:
                continue  # skip empty container nodes without content

            if not body:
                # Folder node with children but no content — generate a simple listing
                body = f"# {node.title}\n"

            _build_page(
                node, body, tree, index,
                project_name, version, search_index, output_dir,
                source_data_by_folder,
            )
            pages_built += 1

        # --- Step 6: Copy assets ---
        _copy_assets(assets_dir, output_dir, defaults_dir)

        print(f"Built {pages_built} pages to {output_dir}")

    except TreeBuilderError as e:
        raise BuildError(f"Tree error: {e}")


def _build_page(
    node: Node,
    body: str,
    tree: list[Node],
    index: CrossLinkIndex,
    project_name: str,
    version: str,
    search_index: str,
    output_dir: str,
    source_data_by_folder: dict,
    is_index: bool = False,
) -> None:
    """Render and write a single page."""
    # Get source data for this node
    source_data = None
    if node.source and node.source in source_data_by_folder:
        source_data = source_data_by_folder[node.source]

    # Compute folder_slug for cross-links
    folder_slug = ""
    if node.source:
        folder_slug = os.path.basename(node.source.rstrip('/\\'))

    try:
        # Render %presentation()% functions first (they expand {{tags}} in their own args)
        rendered = render_presentation_functions(body, source_data, folder_slug, node.output_path)

        # Render remaining {{data}} tags inline (bare tags not inside %...%)
        rendered = render_data_tags_inline(rendered, source_data, folder_slug)

        # Markdown → HTML
        html_content = markdown_to_html(rendered)

        # Resolve [[cross-links]]
        html_content = resolve_links(html_content, index, node.output_path)

        # Assemble 3-column page
        page_html = assemble_page(html_content, node, tree, project_name, version, search_index)

        # Write
        if is_index:
            out_path = os.path.join(output_dir, 'index.html')
        else:
            out_path = os.path.join(output_dir, node.output_path)

        out_dir = os.path.dirname(out_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(page_html)

    except (TagRendererError, CrossLinkError) as e:
        raise BuildError(f"Page '{node.title}': {e}")


def _iterate_nodes(tree: list[Node]) -> list[Node]:
    """Flatten the tree into a list of all nodes."""
    nodes = []
    for node in tree:
        nodes.append(node)
        if node.children:
            nodes.extend(_iterate_nodes(node.children))
    return nodes


# ---------------------------------------------------------------------------
# CLI commands
# ---------------------------------------------------------------------------

def _find_docs_root(directory: str | None = None) -> str:
    """Resolve docs root: a folder containing root.md."""
    if directory:
        path = os.path.abspath(directory)
        if os.path.isfile(os.path.join(path, 'root.md')):
            return path
        raise BuildError(f"No root.md found in {directory}")

    cwd = os.getcwd()
    if os.path.isfile(os.path.join(cwd, 'root.md')):
        return cwd

    raise BuildError(
        "No root.md found in current directory.\n"
        "  Run 'slop-doc init' to create a docs folder, or pass -d <dir>."
    )


def _cmd_init(name: str) -> int:
    """Scaffold a new docs folder with a root.md."""
    target = os.path.join(os.getcwd(), name)
    if os.path.exists(target):
        print(f"Error: '{name}' already exists.", file=sys.stderr)
        return 1

    os.makedirs(target)

    root_md = os.path.join(target, 'root.md')
    with open(root_md, 'w', encoding='utf-8') as f:
        f.write('{\n'
                '    "title": "My Project",\n'
                '    "project_name": "My Project",\n'
                '    "version": "1.0.0",\n'
                '    "output_dir": "build"\n'
                '}\n\n'
                '# Welcome\n\n'
                'Edit this file and add .md pages to build your documentation.\n')

    print(f"Created '{name}/' with root.md.")
    print(f"Add .md files, then run 'slop-doc build -d {name}/'.")
    return 0


def _cmd_open(docs_root: str) -> int:
    """Open index.html from the build output."""
    import webbrowser

    config = _read_project_config(docs_root)
    output_dir = os.path.join(docs_root, config.get('output_dir', 'build'))
    index_html = os.path.join(output_dir, 'index.html')

    if not os.path.isfile(index_html):
        print(f"Error: '{index_html}' not found. Run 'slop-doc build' first.", file=sys.stderr)
        return 1

    url = 'file:///' + index_html.replace('\\', '/')
    print(f"Opening {index_html}")
    webbrowser.open(url)
    return 0


def main() -> int:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        prog='slop-doc',
        description='slop-doc — Static documentation generator',
    )
    subparsers = parser.add_subparsers(dest='command', metavar='command')
    subparsers.required = True

    # init
    p_init = subparsers.add_parser('init', help='Create a new docs folder with root.md')
    p_init.add_argument('--name', default='docs', help='Docs folder name (default: docs)')

    # build
    p_build = subparsers.add_parser('build', help='Build documentation')
    p_build.add_argument('-d', '--dir', default=None, metavar='DIR', help='Docs folder containing root.md')

    # open
    p_open = subparsers.add_parser('open', help='Open built documentation in browser')
    p_open.add_argument('-d', '--dir', default=None, metavar='DIR', help='Docs folder containing root.md')

    args = parser.parse_args()

    try:
        if args.command == 'init':
            return _cmd_init(args.name)

        if args.command == 'build':
            docs_root = _find_docs_root(args.dir)
            build_docs(docs_root)
            return 0

        if args.command == 'open':
            docs_root = _find_docs_root(args.dir)
            return _cmd_open(docs_root)

    except BuildError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        return 1

    return 0
