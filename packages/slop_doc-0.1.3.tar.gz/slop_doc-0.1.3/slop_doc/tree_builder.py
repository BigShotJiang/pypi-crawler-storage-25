"""Tree Builder — builds the navigation tree from the docs folder structure.

The folder hierarchy IS the documentation tree.  Each ``.md`` file becomes a
page node; each folder with a ``root.md`` becomes a group node.  No
``.sdoc.tree`` or ``.sdoc`` files are involved.

Source folder inheritance:
    ``default_source_folder`` set in a ``root.md`` front-matter is inherited by
    all ``.md`` siblings and by child folders (unless overridden by a deeper
    ``root.md``).
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

from slop_doc.frontmatter import parse_frontmatter, PageMeta, FrontmatterError
from slop_doc.parser import SourceData, parse_folder
from slop_doc.tag_renderer import expand_data_tags_in_list


class TreeBuilderError(Exception):
    """Raised when tree building fails."""
    pass


@dataclass
class Node:
    """Represents a node in the navigation tree."""
    title: str
    content: str = ""             # Markdown body (empty for auto-generated class pages)
    source: str | None = None     # absolute path to source folder
    children: list[Node] = field(default_factory=list)
    output_path: str = ""         # relative path for output HTML file
    is_auto: bool = False         # True if auto-generated (class/function page)
    auto_class: str | None = None # class name for auto-generated class pages
    auto_function: str | None = None  # function name for auto-generated function pages
    meta: PageMeta = field(default_factory=PageMeta)


# ---------------------------------------------------------------------------
# Slug / path helpers
# ---------------------------------------------------------------------------

def slugify(text: str) -> str:
    """Convert text to a URL-safe slug."""
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    return text.lower().strip('-')


def _title_from_filename(filename: str) -> str:
    """Derive a human-readable title from a filename.

    Strips numeric prefix and extension:
        ``1.md`` → ``1``
        ``getting-started.md`` → ``getting-started``
    """
    name = os.path.splitext(filename)[0]
    return name


def _sort_key(filename: str) -> tuple:
    """Sort key: files with a leading number sort numerically, others alphabetically."""
    name = os.path.splitext(filename)[0]
    m = re.match(r'^(\d+)', name)
    if m:
        return (0, int(m.group(1)), name)
    return (1, 0, name)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def build_tree(docs_root: str, exclude_dirs: set[str] | None = None) -> tuple[list[Node], dict[str, SourceData]]:
    """Build the complete navigation tree from a docs folder.

    Args:
        docs_root: Path to the documentation root folder.
        exclude_dirs: Directory names to skip (e.g. {"build"}).

    Returns:
        Tuple of (root_nodes, source_data_by_folder).
    """
    source_data_cache: dict[str, SourceData] = {}
    root_node = _walk_folder(docs_root, "", None, source_data_cache, is_root=True, exclude_dirs=exclude_dirs)

    if root_node is None:
        raise TreeBuilderError(f"No .md files found in {docs_root}")

    return root_node.children, source_data_cache


def build_tree_with_root(docs_root: str, exclude_dirs: set[str] | None = None) -> tuple[Node, dict[str, SourceData]]:
    """Like build_tree() but returns the root Node itself (used by builder for index.html).

    Returns:
        Tuple of (root_node, source_data_by_folder).
    """
    source_data_cache: dict[str, SourceData] = {}
    root_node = _walk_folder(docs_root, "", None, source_data_cache, is_root=True, exclude_dirs=exclude_dirs)

    if root_node is None:
        raise TreeBuilderError(f"No .md files found in {docs_root}")

    return root_node, source_data_cache


# ---------------------------------------------------------------------------
# Recursive folder walk
# ---------------------------------------------------------------------------

def _walk_folder(
    folder_path: str,
    parent_output_prefix: str,
    inherited_source: str | None,
    source_data_cache: dict[str, SourceData],
    is_root: bool = False,
    exclude_dirs: set[str] | None = None,
) -> Node | None:
    """Walk a single folder and return a folder Node (or None if empty).

    Args:
        folder_path: Absolute path to the folder.
        parent_output_prefix: Output path prefix from parent (e.g., "api/core").
        inherited_source: default_source_folder inherited from ancestor.
        source_data_cache: Shared cache of parsed SourceData.
        is_root: True for the top-level docs folder (children at top level).
        exclude_dirs: Set of directory names to skip (e.g. output dir).

    Returns:
        A folder Node with children, or None.
    """
    if not os.path.isdir(folder_path):
        return None

    # --- Read root.md if present ---
    root_md_path = os.path.join(folder_path, 'root.md')
    folder_meta = PageMeta()
    folder_body = ""

    if os.path.isfile(root_md_path):
        with open(root_md_path, 'r', encoding='utf-8') as f:
            raw = f.read()
        try:
            folder_meta, folder_body = parse_frontmatter(raw)
        except FrontmatterError as e:
            raise TreeBuilderError(f"Error in {root_md_path}: {e}")

    folder_title = folder_meta.title or os.path.basename(folder_path)

    # Resolve source folder for this level
    local_source = _resolve_source_folder(folder_meta.default_source_folder, folder_path)
    effective_source = local_source or inherited_source

    # Build output prefix for this folder
    if is_root:
        output_prefix = ""  # root level — children are at top level
    elif parent_output_prefix:
        output_prefix = f"{parent_output_prefix}/{slugify(folder_title)}"
    else:
        output_prefix = slugify(folder_title)

    # Create the folder node
    folder_node = Node(
        title=folder_title,
        content=folder_body,
        source=effective_source,
        output_path=f"{output_prefix}/index.html" if output_prefix else "",
        meta=folder_meta,
    )

    # --- Collect and sort .md files (excluding root.md) ---
    md_files = []
    subdirs = []

    for entry in sorted(os.listdir(folder_path)):
        full = os.path.join(folder_path, entry)
        if os.path.isfile(full) and entry.endswith('.md') and entry != 'root.md':
            md_files.append(entry)
        elif os.path.isdir(full) and not entry.startswith('.') and entry != '__pycache__':
            if exclude_dirs and entry in exclude_dirs:
                continue
            subdirs.append(entry)

    md_files.sort(key=_sort_key)
    subdirs.sort(key=_sort_key)

    # --- Process .md files ---
    for md_file in md_files:
        md_path = os.path.join(folder_path, md_file)
        child_nodes = _process_md_file(
            md_path, md_file, output_prefix, effective_source, folder_path, source_data_cache
        )
        folder_node.children.extend(child_nodes)

    # --- Recurse into subdirectories ---
    for subdir in subdirs:
        sub_path = os.path.join(folder_path, subdir)
        sub_node = _walk_folder(sub_path, output_prefix, effective_source, source_data_cache)
        if sub_node is not None:
            folder_node.children.append(sub_node)

    return folder_node


# ---------------------------------------------------------------------------
# Process a single .md file → one or more Nodes
# ---------------------------------------------------------------------------

def _process_md_file(
    md_path: str,
    filename: str,
    parent_output_prefix: str,
    inherited_source: str | None,
    folder_path: str,
    source_data_cache: dict[str, SourceData],
) -> list[Node]:
    """Process a single .md file and return the resulting Node(s).

    If the file's front-matter contains ``children``, auto-generated child
    nodes (one per class/function) are created.
    """
    with open(md_path, 'r', encoding='utf-8') as f:
        raw = f.read()

    try:
        meta, body = parse_frontmatter(raw)
    except FrontmatterError as e:
        raise TreeBuilderError(f"Error in {md_path}: {e}")

    # Title: front-matter title > first heading > filename
    title = meta.title or _extract_first_heading(body) or _title_from_filename(filename)

    # Resolve source folder
    local_source = _resolve_source_folder(meta.default_source_folder, folder_path)
    effective_source = local_source or inherited_source

    # Output path
    slug = slugify(title)
    if parent_output_prefix:
        output_path = f"{parent_output_prefix}/{slug}.html"
    else:
        output_path = f"{slug}.html"

    node = Node(
        title=title,
        content=body,
        source=effective_source,
        output_path=output_path,
        meta=meta,
    )

    # --- Handle children generators ---
    if meta.children:
        _expand_children(node, meta.children, effective_source, folder_path, source_data_cache)

    return [node]


# ---------------------------------------------------------------------------
# Children expansion ({{classes}}, {{functions}} in children: block)
# ---------------------------------------------------------------------------

def _expand_children(
    parent_node: Node,
    children_spec: dict,
    effective_source: str | None,
    folder_path: str,
    source_data_cache: dict[str, SourceData],
) -> None:
    """Expand children: block in front-matter.

    children_spec is a dict like:
        {"classes": "{{classes}}", "functions": ["{{functions}}", "extra_func"]}
    or:
        {"classes": ["ClassA", "{{classes}}", "ClassB"]}

    Each class entry generates a child Node with auto_class set.
    Each function entry generates a child Node with auto_function set.
    """
    if effective_source is None:
        raise TreeBuilderError(
            f"Node '{parent_node.title}' has children generators but no source folder is set"
        )

    # Parse source data
    source_data = _get_source_data(effective_source, source_data_cache)

    parent_prefix = parent_node.output_path.replace('.html', '')

    # Process each child type
    for child_type, spec in children_spec.items():
        if isinstance(spec, str):
            spec = [spec]
        if not isinstance(spec, list):
            continue

        names = expand_data_tags_in_list(spec, source_data)

        for name in names:
            slug = slugify(name)

            if child_type == 'classes':
                child = Node(
                    title=f"{name}",
                    content="",
                    source=effective_source,
                    output_path=f"{parent_prefix}/{slug}.html",
                    is_auto=True,
                    auto_class=name,
                )
            elif child_type == 'functions':
                child = Node(
                    title=f"{name}",
                    content="",
                    source=effective_source,
                    output_path=f"{parent_prefix}/{slug}.html",
                    is_auto=True,
                    auto_function=name,
                )
            else:
                continue

            parent_node.children.append(child)


# ---------------------------------------------------------------------------
# Source folder resolution
# ---------------------------------------------------------------------------

def _resolve_source_folder(raw_path: str | None, context_folder: str) -> str | None:
    """Resolve a default_source_folder path relative to the .md file's folder."""
    if not raw_path:
        return None
    if os.path.isabs(raw_path):
        resolved = raw_path
    else:
        resolved = os.path.normpath(os.path.join(context_folder, raw_path))
    if os.path.isdir(resolved):
        return resolved
    return None


def _get_source_data(source_folder: str, cache: dict[str, SourceData]) -> SourceData:
    """Get (or parse & cache) SourceData for a source folder."""
    if source_folder not in cache:
        cache[source_folder] = parse_folder(source_folder)
    return cache[source_folder]


# ---------------------------------------------------------------------------
# Heading extraction
# ---------------------------------------------------------------------------

def _extract_first_heading(body: str) -> str | None:
    """Extract the first Markdown heading from body text."""
    m = re.search(r'^#\s+(.+)$', body, re.MULTILINE)
    if m:
        return m.group(1).strip()
    return None
