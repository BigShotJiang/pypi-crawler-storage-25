((nil .
      ((projectile-project-name . "bibleverseparser")
       (projectile-project-test-cmd . "pytest")))
 (web-mode .
           ((mode . my/djhtml-on-save)))

 (typescript-mode .  ;; Javascript as well
                  ((mode . my/pre-commit-prettier-on-save)))

 (css-mode .
           ((mode . my/pre-commit-prettier-on-save)))
)

