""" memorph-bin-linux-x64-gnu """


def main() -> None:
    print("  memorph-bin-linux-x64-gnu  ")
