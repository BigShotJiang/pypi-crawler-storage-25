"""Deterministic dreaming fixtures."""
