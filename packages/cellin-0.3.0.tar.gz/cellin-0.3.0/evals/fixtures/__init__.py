"""Deterministic ingest fixtures."""
