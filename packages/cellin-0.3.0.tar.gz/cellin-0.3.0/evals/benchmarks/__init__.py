"""Benchmark assets for Cellin."""
