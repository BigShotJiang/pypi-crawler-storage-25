## Summary

Describe the problem and the intent of this change.

## Changes

- 

## Validation

Commands and checks run:

```bash
make release-smoke
```

Additional targeted validation:

- 

## Risk and compatibility

- Breaking changes:
- Migration required:
- Performance impact:
- Security impact:

## Checklist

- [ ] Tests or evals added or updated for behavior changes
- [ ] Docs updated if user-facing behavior changed
- [ ] No unrelated changes included
- [ ] Ready for review
