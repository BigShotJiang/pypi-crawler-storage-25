#!/usr/bin/env python3
"""
Nuclei adapter - Maps Nuclei vulnerability scanner JSON to CommonFinding schema.

Plugin Architecture (v0.9.0):
- Uses @adapter_plugin decorator for auto-discovery
- Inherits from AdapterPlugin base class
- Returns Finding objects (not dicts)
- Auto-loaded by plugin registry

v1.0.0 Feature #1:
- Template-based vulnerability scanning
- CVE/CWE detection with CVSS enrichment
- Web application and API security testing
- Cloud and network misconfiguration detection

Tool Version: 3.3.7+
Output Format: NDJSON (newline-delimited JSON)
Exit Codes: 0 (clean), varies by template match

Template Categories:
- cves: Known vulnerability (CVE) templates
- exposures: Sensitive file/config exposure
- misconfigurations: Security misconfigurations
- takeovers: Subdomain takeover vulnerabilities
- technologies: Technology fingerprinting
- fuzzing: Active fuzzing templates
- workflows: Multi-step scan workflows

Severity Mapping (Nuclei -> CommonFinding):
- critical: CRITICAL
- high: HIGH
- medium: MEDIUM
- low: LOW
- info: INFO

Scan Types:
- http: HTTP-based vulnerability scanning
- dns: DNS record analysis
- tcp: TCP service scanning
- ssl: TLS/SSL certificate issues
- headless: Browser-based checks
- code: Source code analysis

Example:
    >>> adapter = NucleiAdapter()
    >>> findings = adapter.parse(Path('nuclei.json'))
    >>> # Returns vulnerability findings with CVE/CWE enrichment

See Also:
    - https://nuclei.projectdiscovery.io/
    - https://github.com/projectdiscovery/nuclei-templates
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from scripts.core.adapters.common import safe_load_ndjson_file
from scripts.core.common_finding import fingerprint, map_tool_severity
from scripts.core.plugin_api import (
    AdapterPlugin,
    Finding,
    PluginMetadata,
    adapter_plugin,
)

logger = logging.getLogger(__name__)


@adapter_plugin(
    PluginMetadata(
        name="nuclei",
        version="1.0.0",
        author="JMo Security",
        description="Adapter for Nuclei vulnerability scanner",
        tool_name="nuclei",
        schema_version="1.2.0",
        output_format="json",
        exit_codes={0: "clean"},
    )
)
class NucleiAdapter(AdapterPlugin):
    """Adapter for Nuclei vulnerability scanner (plugin architecture)."""

    @property
    def metadata(self) -> PluginMetadata:
        """Return plugin metadata."""
        return self.__class__._plugin_metadata  # type: ignore[attr-defined,no-any-return]  # Dynamically attached by @adapter_plugin decorator

    def parse(self, output_path: Path) -> list[Finding]:
        """Parse tool output and return normalized findings.

        Args:
            output_path: Path to nuclei.json output file

        Returns:
            List of Finding objects following CommonFinding schema v1.2.0
        """
        # Delegate to internal function that returns dicts
        findings_dicts = _load_nuclei_internal(output_path)

        # Convert dicts to Finding objects
        findings = []
        for f_dict in findings_dicts:
            finding = Finding(
                schemaVersion=f_dict.get("schemaVersion", "1.2.0"),
                id=f_dict.get("id", ""),
                ruleId=f_dict.get("ruleId", ""),
                severity=f_dict.get("severity", "INFO"),
                tool=f_dict.get("tool", {}),
                location=f_dict.get("location", {}),
                message=f_dict.get("message", ""),
                title=f_dict.get("title"),
                description=f_dict.get("description"),
                remediation=f_dict.get("remediation"),
                references=f_dict.get("references", []),
                tags=f_dict.get("tags", []),
                cvss=f_dict.get("cvss"),
                risk=f_dict.get("risk"),
                compliance=f_dict.get("compliance"),
                context=f_dict.get("context"),
                raw=f_dict.get("raw"),
            )
            findings.append(finding)

        return findings


def _load_nuclei_internal(path: str | Path) -> list[dict[str, Any]]:
    """Load and normalize Nuclei findings to CommonFinding schema.

    Args:
        path: Path to nuclei.json output file (NDJSON format)

    Returns:
        List of CommonFinding dictionaries (schema v1.2.0)

    Error Handling:
        - Returns [] if file doesn't exist
        - Returns [] if file is empty
        - Skips malformed JSON lines (NDJSON format)
    """
    out: list[dict[str, Any]] = []

    # Nuclei outputs NDJSON (one JSON object per line)
    for item in safe_load_ndjson_file(path):

        # Extract required fields
        # Nuclei structure:
        # {
        #   "template-id": "CVE-2021-44228",
        #   "info": {
        #     "name": "Apache Log4j RCE",
        #     "severity": "critical",
        #     "description": "...",
        #     "reference": ["https://..."],
        #     "classification": {
        #       "cve-id": ["CVE-2021-44228"],
        #       "cwe-id": ["CWE-502"]
        #     },
        #     "tags": ["cve", "log4j", "rce"]
        #   },
        #   "matched-at": "https://example.com/api",
        #   "matcher-name": "...",
        #   "type": "http"
        # }

        template_id = str(
            item.get("template-id") or item.get("templateID") or "UNKNOWN"
        )
        info = item.get("info", {})
        if not isinstance(info, dict):
            info = {}

        name = info.get("name") or template_id
        description = info.get("description") or name
        severity_raw = info.get("severity") or "MEDIUM"
        severity = map_tool_severity("nuclei", severity_raw)

        # Location: matched URL
        matched_at = item.get("matched-at") or item.get("matched") or ""
        host = item.get("host") or ""
        url = matched_at or host or ""

        # Use matcher-name for additional context
        matcher_name = item.get("matcher-name") or ""
        if matcher_name:
            msg = f"{name} (matcher: {matcher_name})"
        else:
            msg = name

        # Generate stable fingerprint
        # For web findings, use URL instead of file path
        fid = fingerprint("nuclei", template_id, url, 0, msg)

        finding: dict[str, Any] = {
            "schemaVersion": "1.2.0",
            "id": fid,
            "ruleId": template_id,
            "title": name,
            "message": msg,
            "description": description,
            "severity": severity,
            "tool": {
                "name": "nuclei",
                "version": str(item.get("version") or "unknown"),
            },
            "location": {
                "path": url,  # Use URL as "path" for web findings
                "startLine": 0,  # Web findings don't have line numbers
            },
            "tags": ["dast", "web-security", "api-security"],
            "raw": item,
        }

        # Extract remediation if available
        remediation = info.get("remediation")
        if remediation:
            finding["remediation"] = remediation
        else:
            finding["remediation"] = (
                "Review finding and apply vendor-recommended fixes."
            )

        # Extract CWE IDs from classification
        risk = {}
        classification = info.get("classification", {})
        if isinstance(classification, dict):
            cwe_ids = classification.get("cwe-id") or classification.get("cwe")
            if cwe_ids:
                if isinstance(cwe_ids, list):
                    risk["cwe"] = [str(c) for c in cwe_ids]
                elif isinstance(cwe_ids, str):
                    risk["cwe"] = [cwe_ids]

            # Extract CVE IDs (not part of risk object, but useful for references)
            cve_ids = classification.get("cve-id") or classification.get("cve")
            if cve_ids and not finding.get("references"):
                refs = []
                if isinstance(cve_ids, list):
                    refs = [f"https://nvd.nist.gov/vuln/detail/{c}" for c in cve_ids]
                elif isinstance(cve_ids, str):
                    refs = [f"https://nvd.nist.gov/vuln/detail/{cve_ids}"]
                if refs:
                    finding["references"] = refs

        # Add references from info
        if info.get("reference") and not finding.get("references"):
            refs = info["reference"]
            if isinstance(refs, list):
                finding["references"] = [str(r) for r in refs]
            elif isinstance(refs, str):
                finding["references"] = [refs]

        # Add tags from info
        if info.get("tags"):
            tags = info["tags"]
            if isinstance(tags, list):
                finding["tags"].extend([str(t) for t in tags])
            elif isinstance(tags, str):
                finding["tags"].append(tags)

        if risk:
            finding["risk"] = risk

        out.append(finding)

    return out
