"""
Circadian engine package — re-exports all public symbols.

Backwards-compatible: ``from cortex.circadian.engine import CircadianEngine`` works.
"""

from cortex.circadian.engine.models import (
    CircadianState,
    WakeReport,
    NapReport,
    SleepReport,
    DreamReport,
    ShutdownReport,
    _CIRCADIAN_STATE_KEY,
    FATIGUE_TIME_INCREMENT as _FATIGUE_TIME_INCREMENT,
    FATIGUE_TIME_INTERVAL_SEC as _FATIGUE_TIME_INTERVAL_SEC,
    FATIGUE_COMPACTION_BUMP as _FATIGUE_COMPACTION_BUMP,
    FATIGUE_ERROR_BUMP as _FATIGUE_ERROR_BUMP,
    FATIGUE_AFTER_NAP as _FATIGUE_AFTER_NAP,
    FATIGUE_MAX as _FATIGUE_MAX,
)
from cortex.circadian.engine.lifecycle import CircadianEngine

__all__ = [
    "CircadianEngine",
    "CircadianState",
    "WakeReport",
    "NapReport",
    "SleepReport",
    "DreamReport",
    "ShutdownReport",
    # Backwards-compat: fatigue constants (used by tests)
    "_CIRCADIAN_STATE_KEY",
    "_FATIGUE_TIME_INCREMENT",
    "_FATIGUE_TIME_INTERVAL_SEC",
    "_FATIGUE_COMPACTION_BUMP",
    "_FATIGUE_ERROR_BUMP",
    "_FATIGUE_AFTER_NAP",
    "_FATIGUE_MAX",
]
