"""
cortex/api/deps.py — Shared dependencies for the Cortex HTTP API.

Provides:
    - verify_api_key: FastAPI dependency for authentication (JWT or API key)
    - get_current_user: FastAPI dependency returning full AuthResult
    - get_plugin: FastAPI dependency for accessing the shared CortexPlugin
    - _serialise: Recursive JSON serialisation helper
    - PREFIX: API version prefix constant
    - plugin_holder: Shared mutable dict for the plugin instance
    - auth_holder: Shared mutable dict for the AuthProvider singleton
"""

from __future__ import annotations

import hmac
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Sentinel for unauthenticated/open-access owner resolution.
# Using a private object prevents collision with any real user ID.
_UNAUTHENTICATED = object()

try:
    from fastapi import Header, HTTPException, Request, status
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False

# API version prefix
PREFIX = "/api/v1"

# Shared plugin instance holder (populated at startup by create_app lifespan)
plugin_holder: Dict[str, Any] = {}

# Shared auth provider holder (populated at app creation by create_app)
auth_holder: Dict[str, Any] = {}

# Shared DBManager holder (populated in hosted mode by create_app lifespan)
db_manager_holder: Dict[str, Any] = {}

# Shared StatsDB holder (populated in hosted mode by create_app lifespan)
stats_db_holder: Dict[str, Any] = {}


def get_plugin_holder() -> Dict[str, Any]:
    """Return the shared plugin holder dict."""
    return plugin_holder


def _serialise(obj: Any) -> Any:
    """Recursively convert objects to JSON-serialisable types."""
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, dict):
        return {k: _serialise(v) for k, v in obj.items() if not k.startswith("_")}
    if isinstance(obj, (list, tuple)):
        return [_serialise(item) for item in obj]
    if hasattr(obj, "__dict__"):
        return _serialise({k: v for k, v in obj.__dict__.items() if not k.startswith("_")})
    return str(obj)


def make_auth_dependency(
    api_key: Optional[str],
    auth_provider: Optional[Any] = None,
    require_auth: bool = False,
    public_endpoints: Optional[list] = None,
):
    """
    Create the verify_api_key FastAPI dependency.

    When *auth_provider* is provided (an :class:`~cortex.api.auth.AuthProvider`),
    JWT-first authentication is used.  The legacy API-key-only path is kept as
    a fallback for backward compatibility.

    Args:
        api_key:         Legacy API key string (used when auth_provider is None).
        auth_provider:   Optional :class:`~cortex.api.auth.AuthProvider` instance.
                         When set, JWT + API key auth is used.
        require_auth:    When True, open-access requests are rejected with 401.
        public_endpoints: List of path prefixes that bypass auth entirely.
    """
    _public = set(public_endpoints or [])

    if auth_provider is not None:
        # New JWT-first auth path
        from cortex.api.auth import AuthError

        async def verify_api_key(request: Request):  # type: ignore[misc]
            """JWT or API key authentication — JWT takes priority."""
            path = request.url.path
            # Public endpoints bypass auth
            if any(path == ep or path.startswith(ep.rstrip("/") + "/") for ep in _public):
                return None

            try:
                result = await auth_provider.authenticate(request.headers)
            except AuthError as exc:
                # Log failed auth: IP + reason, never the token/key (#542)
                client_ip = request.client.host if request.client else "unknown"
                logger.warning(
                    "Auth failed from %s on %s: %s",
                    client_ip, path, str(exc),
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication failed",
                ) from exc

            # Reject open access when require_auth is enabled
            if require_auth and result.method == "open":
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication required",
                )

            # Expose identity to downstream handlers.
            # Admin API keys may act on behalf of an explicit X-Owner-Id.
            # JWT-authenticated users must never be able to override their owner.
            x_owner_id = request.headers.get("X-Owner-Id")
            effective_owner_id = (
                x_owner_id if x_owner_id and result.method == "api_key" else result.owner_id
            )
            request.state.auth = result
            request.state.owner_id = effective_owner_id
            return result

    else:
        # Legacy API key–only path (backward compat for tests and self-host)
        async def verify_api_key(  # type: ignore[misc]
            request: Request,
            x_api_key: Optional[str] = Header(None),
            x_owner_id: Optional[str] = Header(None),
        ):
            """Validate X-API-Key header when auth is configured.

            When a valid API key is supplied, the optional X-Owner-Id request
            header is used to set the effective owner identity (#593). If the
            header is absent the owner defaults to "default" for backward
            compatibility.
            """
            path = request.url.path
            if any(path == ep or path.startswith(ep.rstrip("/") + "/") for ep in _public):
                return None
            if api_key is None:
                # No key configured -- open access; honour explicit header if given.
                if x_owner_id:
                    request.state.owner_id = x_owner_id
                return None
            if x_api_key is None or not hmac.compare_digest(x_api_key, api_key):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid or missing X-API-Key",
                )
            # Propagate identity so _resolve_owner_id() can pick it up downstream.
            # Use sentinel when no explicit owner — never a string that could
            # collide with a real user ID (fixes IDOR when user is "default").
            request.state.owner_id = x_owner_id or _UNAUTHENTICATED

    return verify_api_key


async def get_current_user(request: "Request") -> Any:
    """
    FastAPI dependency that returns the authenticated user for the current request.

    Reads the :class:`~cortex.api.auth.AuthResult` stored on ``request.state.auth``
    by the :func:`make_auth_dependency` gate.  If not set (e.g. public endpoint or
    no-auth mode), returns an open-access result with ``owner_id='default'``.

    Returns:
        :class:`~cortex.api.auth.AuthResult`
    """
    auth = getattr(request.state, "auth", None)
    if auth is not None:
        return auth

    # Fallback: run auth now (handles routes that don't use verify_api_key gate)
    provider = auth_holder.get("auth_provider")
    if provider is not None:
        from cortex.api.auth import AuthError, AuthResult
        try:
            result = await provider.authenticate(request.headers)
        except AuthError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required",
            )
        request.state.auth = result
        request.state.owner_id = result.owner_id
        return result

    # No auth configured — return open access result
    from cortex.api.auth import AuthResult
    owner = getattr(request.state, "owner_id", _UNAUTHENTICATED)
    resolved = owner if owner is not _UNAUTHENTICATED else "default"
    return AuthResult(owner_id=resolved, method="open")


def _resolve_owner_id(request: "Request", body_owner_id: Optional[str] = None) -> str:
    """Return the effective owner_id, honouring body overrides for API key auth only.

    Security fix (#818): For JWT-authenticated users, the owner_id MUST come from
    the authenticated identity set by auth middleware (request.state.owner_id).
    JWT users can never override their owner_id via the request body (prevents IDOR).

    For admin (master) API key-authenticated callers, body_owner_id is honoured when
    provided so that admin callers can browse/search across namespaces.
    Tenant API keys (is_admin=False) are NEVER allowed to override owner_id — this
    prevents full multi-tenant isolation breaks.

    **Open-access vs. self-host distinction:**
    - When an ``auth_provider`` is configured but the request carries no credentials,
      the middleware still sets ``request.state.owner_id`` (typically ``"default"``)
      with ``auth.method == "open"`` and ``is_admin=False``.  The authenticated branch
      (precedence 1–3 below) is entered, so ``body_owner_id`` is **ignored** — this
      is intentional; open-access callers cannot self-elevate via the body.
    - When **no** ``auth_provider`` is configured at all (pure self-host / dev mode),
      ``request.state.owner_id`` is unset/``None``, the authenticated branch is
      skipped, and ``body_owner_id`` is honoured for backward compatibility
      (precedence 4).

    Precedence (highest → lowest):
        1. auth-resolved owner_id (for JWT — immutable)
        2. body_owner_id (for ADMIN API key only — allows namespace override)
        3. auth-resolved owner_id fallback (for non-admin API key / JWT / open-access
           with auth_provider configured)
        4. body_owner_id (self-host backward compat — only when no auth_provider is
           configured, i.e. request.state.owner_id is absent/None)
        5. "default"
    """
    auth_owner = getattr(request.state, "owner_id", None)
    auth_result = getattr(request.state, "auth", None)

    # Validated body_owner_id: strip whitespace, reject whitespace-only values.
    effective_body_owner_id: Optional[str] = None
    if body_owner_id is not None:
        stripped = body_owner_id.strip()
        if stripped:
            effective_body_owner_id = stripped
        else:
            logger.warning("body_owner_id rejected: whitespace-only value supplied")

    # Authenticated user: check method to decide whether body override is allowed.
    if auth_owner is not None and auth_owner is not _UNAUTHENTICATED:
        # Only the master/admin API key may override owner_id via the request body.
        # Tenant API keys (is_admin=False) must NEVER cross namespace boundaries.
        if getattr(auth_result, "is_admin", False) and effective_body_owner_id:
            if effective_body_owner_id != auth_owner:
                logger.debug(
                    "owner_id override: admin API key supplied '%s', auth resolved '%s' — using supplied value",
                    effective_body_owner_id,
                    auth_owner,
                )
            return effective_body_owner_id
        # JWT auth or non-admin API key: NEVER allow body override — IDOR / namespace isolation
        if effective_body_owner_id and effective_body_owner_id != auth_owner:
            logger.warning(
                "owner_id override ignored: non-admin caller supplied '%s' but auth resolved '%s' — using auth value",
                effective_body_owner_id,
                auth_owner,
            )
        return auth_owner
    # Open-access / self-host fallback: honour body override for backward compat
    if effective_body_owner_id:
        return effective_body_owner_id
    return "default"


def get_plugin() -> Any:
    """Retrieve the shared CortexPlugin instance."""
    plugin = plugin_holder.get("plugin")
    if plugin is None:  # pragma: no cover
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Cortex plugin not initialised",
        )
    return plugin


async def get_user_storage(owner_id: str) -> Any:
    """
    FastAPI/async helper: resolve the correct SQLiteAdapter for *owner_id*.

    Hosted mode  (DBManager active) → ``await db_manager.get_adapter(owner_id)``
    Self-host mode (no DBManager)   → the plugin's single shared storage

    Args:
        owner_id: User identifier (e.g. from ``request.state.owner_id``).

    Returns:
        A :class:`~cortex.storage.sqlite_adapter.SQLiteAdapter` instance.

    Raises:
        HTTPException 503 if neither DBManager nor plugin storage is available.
    """
    manager = db_manager_holder.get("manager")
    if manager is not None:
        return await manager.get_adapter(owner_id)

    # Self-host fallback: use the plugin's single storage
    plugin = plugin_holder.get("plugin")
    if plugin is not None:
        storage = getattr(plugin, "storage", None)
        if storage is not None:
            return storage

    raise HTTPException(  # pragma: no cover
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail="Storage not available",
    )
