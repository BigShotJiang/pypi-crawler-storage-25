"""CortexPlugin — composed from mixins."""
from .initialization import InitializationMixin
from .write_ops import WriteOpsMixin
from .read_ops import ReadOpsMixin
from .entity_ops import EntityOpsMixin
from .lifecycle import LifecycleMixin
from .health import HealthMixin


class CortexPlugin(
    InitializationMixin,
    WriteOpsMixin,
    ReadOpsMixin,
    EntityOpsMixin,
    LifecycleMixin,
    HealthMixin,
):
    """Main plugin class — single entry point for all Cortex operations.

    Usage::

        plugin = CortexPlugin(config_path="~/.config/cortex.toml")
        await plugin.wake()
        result = await plugin.remember(conversation)
        context = await plugin.retrieve("What does the user prefer?")
        await plugin.sleep()
    """
    pass
