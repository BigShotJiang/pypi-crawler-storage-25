"""cortex.api.plugin — backwards-compatible re-export."""
import logging

from .core import CortexPlugin
from .models import (
    RememberResult,
    ForgetResult,
    HealthReport,
    EvolutionProposalResult,
    AskResult,
    WakeReport,
    SleepReport,
)

# Re-export names that tests patch via "cortex.api.plugin.X"
# These were top-level imports in the old monolithic plugin.py
from cortex.llm.fallback import build_provider_cascade  # noqa: F401
from cortex.llm.provider_router import ProviderRouter  # noqa: F401
from cortex.validation import validate_retrieve_query  # noqa: F401
from cortex.validation import validate_conversation  # noqa: F401
from cortex.validation import validate_cornerstone_fields  # noqa: F401

logger = logging.getLogger(__name__)

__all__ = [
    "CortexPlugin",
    "RememberResult",
    "ForgetResult",
    "HealthReport",
    "EvolutionProposalResult",
    "AskResult",
    "WakeReport",
    "SleepReport",
    "build_provider_cascade",
    "ProviderRouter",
]
