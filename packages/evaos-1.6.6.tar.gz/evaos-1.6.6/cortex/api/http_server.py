"""
cortex/api/http_server.py — FastAPI HTTP Server for Cortex (Module 13 / M13).

Provides a REST API that mirrors the MCP tools, enabling web dashboard
integration (Nexus UI) and external programmatic access to Cortex memory.

Architecture:
    HTTP Server (FastAPI/uvicorn)
      → CortexPlugin (M13)
        → all other modules

Auth:
    Pass ``X-API-Key: <key>`` header when CORTEX_API_KEY env var is set.
    If CORTEX_API_KEY is not set, auth is disabled (open access — for local dev).

Usage::

    # Start with defaults (localhost:8000)
    cortex-http

    # Custom host/port with API key
    CORTEX_API_KEY=secret cortex-http --host 0.0.0.0 --port 8080

    # Programmatic usage
    import uvicorn
    from cortex.api.http_server import create_app
    app = create_app()
    uvicorn.run(app, host="127.0.0.1", port=8000)

Dependencies: FastAPI, uvicorn, cortex.api.plugin.CortexPlugin.
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional import guard — fastapi/uvicorn may not be installed
# ---------------------------------------------------------------------------
try:
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    import uvicorn
    _FASTAPI_AVAILABLE = True
except ImportError as _e:  # pragma: no cover
    _FASTAPI_AVAILABLE = False
    _IMPORT_ERROR = str(_e)

# Re-export _serialise at module level for backward compatibility
from cortex import __version__  # noqa: E402
from cortex.api.deps import _serialise  # noqa: F401, E402
from cortex.api.deps import plugin_holder, auth_holder, make_auth_dependency, get_plugin  # noqa: E402
from cortex.api.deps import db_manager_holder, stats_db_holder  # noqa: E402

# Re-export models at module level for backward compatibility with tests
# that do: from cortex.api.http_server import SomeModel
try:
    from cortex.api.models import *  # noqa: F401, F403
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Sentry helpers (no-op if sentry-sdk is not installed / DSN not set)
# ---------------------------------------------------------------------------

def _sentry_before_send(event: Any, hint: Any) -> Any:
    """Filter/enrich Sentry events before transmission.

    Truncates overly long exception values that may contain conversation text.
    """
    if "exception" in event:
        for exc_info in event["exception"].get("values", []):
            val = exc_info.get("value", "")
            if len(val) > 500:
                exc_info["value"] = val[:500] + "... [truncated]"
    return event


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------

def create_app(
    config_path: Optional[str] = None,
    db_path: Optional[str] = None,
    api_key: Optional[str] = None,
    cors_origins: Optional[List[str]] = None,
) -> "FastAPI":
    """
    Create and configure the FastAPI application.

    Args:
        config_path:  Path to cortex.toml (default: auto-detect).
        db_path:      Override SQLite database path.
        api_key:      Required API key for X-API-Key header auth.
                      If None, falls back to ``CORTEX_API_KEY`` env var.
                      If that is also empty, auth is disabled.
        cors_origins: List of allowed CORS origins. Default: ["*"].

    Returns:
        Configured FastAPI application instance.
    """
    if not _FASTAPI_AVAILABLE:  # pragma: no cover
        raise ImportError(
            f"FastAPI is required for the HTTP server: {_IMPORT_ERROR}\n"
            "Install with: pip install 'evaos[api]'"
        )

    # ---- Sentry error & performance monitoring --------------------------------
    # Conditional on SENTRY_DSN env var — safe to leave unset in local dev.
    try:
        import sentry_sdk as _sentry_sdk

        _sentry_dsn = os.getenv("SENTRY_DSN")
        if _sentry_dsn:
            _sentry_sdk.init(
                dsn=_sentry_dsn,
                # Performance monitoring: sample 20% of transactions in prod.
                # Adjust via SENTRY_TRACES_SAMPLE_RATE env var in fly.toml.
                traces_sample_rate=float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0.2")),
                # Profiling: 10% of sampled transactions get CPU profiles.
                profiles_sample_rate=float(os.getenv("SENTRY_PROFILES_SAMPLE_RATE", "0.1")),
                # Environment tag for filtering (production / staging / development)
                environment=os.getenv("SENTRY_ENVIRONMENT", os.getenv("FLY_APP_NAME", "development")),
                # Release tracking + deploy detection
                release=f"cortex@{__version__}",
                # Never send PII — conversation content is sensitive
                send_default_pii=False,
                # Auto-detection handles FastAPI/Starlette/asyncio integrations
                integrations=[],
                before_send=_sentry_before_send,
            )
            logger.info(
                "Sentry initialized (env=%s, release=cortex@%s)",
                os.getenv("SENTRY_ENVIRONMENT", os.getenv("FLY_APP_NAME", "development")),
                __version__,
            )
    except ImportError:
        _sentry_sdk = None  # type: ignore[assignment]
        _sentry_dsn = None

    _api_key = api_key or os.getenv("CORTEX_API_KEY") or None
    # Supabase JWT secret — primary auth for hosted deployments (#542)
    _jwt_secret = os.getenv("SUPABASE_JWT_SECRET") or None
    # flyio-sync secret — used to resolve Supabase UUID → cortex_owner_id (#737)
    _flyio_sync_secret = os.getenv("FLYIO_SYNC_SECRET") or None
    if not _flyio_sync_secret:
        logger.warning(
            "FLYIO_SYNC_SECRET not set — JWT owner resolution disabled, "
            "falling back to raw Supabase UUID. Dashboard will show empty memories."
        )
    # Configure allowed origins explicitly for security; empty list blocks all cross-origin requests by default.
    # Falls back to CORTEX_CORS_ORIGINS env var (comma-separated) when not passed directly.
    # Supports wildcard entries like "https://*.lovable.app" via regex matching in the custom middleware below.
    _cors_origins = cors_origins or [
        o.strip()
        for o in os.getenv("CORTEX_CORS_ORIGINS", "").split(",")
        if o.strip()
    ]
    # Separate static origins (no wildcard) from pattern origins (contain *)
    import re as _re
    _cors_origins_static = [o for o in _cors_origins if "*" not in o]
    # Build a combined regex for wildcard origins (e.g. https://*.lovable.app)
    # FastAPI's CORSMiddleware natively supports allow_origin_regex — cleaner than custom middleware.
    _wildcard_origins = [o for o in _cors_origins if "*" in o]
    _cors_origin_regex: str | None = None
    if _wildcard_origins:
        _parts = [
            _re.escape(o).replace(r"\*", r"[^.]+(?:\.[^.]+)*")
            for o in _wildcard_origins
        ]
        _cors_origin_regex = "^(?:" + "|".join(_parts) + ")$"

    # Warn loudly when no auth is configured (#218)
    if _api_key is None and _jwt_secret is None:
        logger.warning(
            "=" * 60 + "\n"
            "⚠️  NO AUTH CONFIGURED\n"
            "The server is accessible WITHOUT authentication.\n"
            "Set SUPABASE_JWT_SECRET (hosted) or CORTEX_API_KEY (self-host)\n"
            "to enable authentication.\n"
            + "=" * 60
        )

    # ---- Lifespan ----------------------------------------------------------

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Initialise CortexPlugin on startup; clean up on shutdown."""
        from cortex.api.plugin import CortexPlugin
        from cortex.config import validate_config as _validate_config
        plugin = CortexPlugin(config_path=config_path, db_path=db_path)
        # Config startup validation (#73)
        config_issues = _validate_config(plugin.config)
        for issue in config_issues:
            logger.warning("CortexConfig validation: %s", issue)
        if plugin.storage is not None:
            await plugin.storage.initialize()
        plugin_holder["plugin"] = plugin
        logger.info("CortexPlugin initialised — HTTP server ready")

        # ---- Debug logging init (#453) -----------------------------------
        try:
            from cortex.debug import init_debug_logging as _init_debug
            _cfg = getattr(plugin, "config", None)
            _debug_enabled = getattr(_cfg, "debug_logging_enabled", False)
            _debug_max = getattr(_cfg, "debug_log_max_entries", 10_000)
            _init_debug(enabled=_debug_enabled, max_entries=_debug_max)
            if _debug_enabled:
                logger.info(
                    "Debug logging enabled — ring buffer capacity: %d", _debug_max
                )
        except Exception as _exc:
            logger.warning("Debug logging init failed (non-fatal): %s", _exc)

        # ---- Hosted-mode: DBManager + StatsDB --------------------------------
        # Hosted mode is active when CORTEX_DATA_DIR is set.
        # Self-host mode (db_path provided, no CORTEX_DATA_DIR) skips both.
        _data_dir = os.getenv("CORTEX_DATA_DIR")
        _hosted_mode = bool(_data_dir)

        if _hosted_mode:
            from cortex.storage.db_manager import DBManager

            _cfg = getattr(plugin, "config", None)
            _max_open = int(
                getattr(_cfg, "db_pool_max_open", None) or 100
            )
            _idle_timeout = float(
                getattr(_cfg, "db_pool_idle_timeout_seconds", None) or 300.0
            )

            _db_manager = DBManager(
                data_dir=_data_dir,
                max_open=_max_open,
                idle_timeout=_idle_timeout,
            )
            await _db_manager.initialize()
            db_manager_holder["manager"] = _db_manager
            logger.info(
                "DBManager initialised (data_dir=%s, max_open=%d, idle_timeout=%gs)",
                _data_dir, _max_open, _idle_timeout,
            )

            from cortex.api.stats_db import StatsDB

            _stats_path = os.getenv("CORTEX_STATS_DB") or f"{_data_dir}/stats.db"
            _stats_db = StatsDB(db_path=_stats_path)
            await _stats_db.initialize()
            stats_db_holder["db"] = _stats_db
            logger.info("StatsDB initialised at %s", _stats_path)

        # ---- Circadian dream scheduler (#772) --------------------------------
        # Start a persistent CircadianEngine with the background dream scheduler
        # so dream cycles fire automatically at the configured UTC hour.
        # Self-host mode only (non-hosted); hosted mode handles scheduling
        # per-user via DBManager lifecycle.
        _circadian_engine = None
        _circadian_task = None
        if not _hosted_mode and plugin.storage is not None:
            _dream_enabled = getattr(plugin.config, "dream_cycle_enabled", True)
            if _dream_enabled:
                try:
                    from cortex.circadian.engine import CircadianEngine
                    from cortex.identity.drift_calculator import DriftCalculator
                    from cortex.deprecation.pipeline import DeprecationPipeline

                    _drift_calc = DriftCalculator(
                        storage=plugin.storage,
                        llm=plugin.llm,
                        config=plugin.config,
                    )
                    _dep_pipeline = DeprecationPipeline(
                        storage=plugin.storage,
                        config=plugin.config,
                    )
                    _circadian_engine = CircadianEngine(
                        storage=plugin.storage,
                        config=plugin.config,
                        llm=plugin.llm,
                        cornerstone_guardian=plugin.cornerstone_guardian,
                        drift_calculator=_drift_calc,
                        deprecation_pipeline=_dep_pipeline,
                        event_emitter=getattr(plugin, "event_emitter", None),
                        promotion_scorer=getattr(plugin, "promotion_scorer", None),
                    )
                    # Start dream scheduler as a background task (does NOT
                    # require wake() — we call _ensure_dream_scheduler directly)
                    _circadian_engine._ensure_dream_scheduler()
                    logger.info(
                        "Circadian dream scheduler started "
                        "(hour_utc=%d, timeout=%ds, owner=%s)",
                        _circadian_engine._dream_hour_utc,
                        getattr(plugin.config, "dream_cycle_timeout_sec", 600),
                        _circadian_engine._owner_id,
                    )
                    # Store engine reference on the plugin for health endpoint access
                    plugin._circadian_engine = _circadian_engine  # type: ignore[attr-defined]
                except Exception as _exc:
                    logger.error(
                        "Failed to start circadian dream scheduler (non-fatal): %s",
                        _exc,
                    )

        # ---- Batch ingest worker (#1326, #1334) ------------------------------
        _batch_worker = None
        try:
            from cortex.batch_worker import BatchWorker
            _db_path = db_path or os.environ.get("CORTEX_DB_PATH")
            if not _db_path:
                _bw_data_dir = os.environ.get("CORTEX_DATA_DIR")
                if _bw_data_dir:
                    _db_path = os.path.join(_bw_data_dir, "cortex.db")
            if _db_path:
                _batch_worker = BatchWorker(
                    db_path=_db_path,
                    plugin=plugin,
                    config_path=config_path,
                )
                _batch_worker.start()
                # Expose worker to the status endpoint
                from cortex.api.routes.batch import batch_worker_holder
                batch_worker_holder["worker"] = _batch_worker
                logger.info("Batch ingest worker started (db=%s)", _db_path)
            else:
                logger.warning(
                    "Batch ingest worker NOT started: no db_path resolved "
                    "(db_path=%r, CORTEX_DB_PATH=%r, CORTEX_DATA_DIR=%r)",
                    db_path,
                    os.environ.get("CORTEX_DB_PATH"),
                    os.environ.get("CORTEX_DATA_DIR"),
                )
        except Exception as _exc:
            logger.error("Failed to start batch ingest worker (non-fatal): %s", _exc)

        # ---- Embedding backfill worker (#1443) -------------------------------
        _backfill_worker = None
        try:
            from cortex.workers.embedding_backfill import EmbeddingBackfillWorker
            _bf_db_path = db_path or os.environ.get("CORTEX_DB_PATH")
            if not _bf_db_path:
                _bf_data_dir = os.environ.get("CORTEX_DATA_DIR")
                if _bf_data_dir:
                    _bf_db_path = os.path.join(_bf_data_dir, "cortex.db")
            if _bf_db_path and plugin.llm is not None:
                _bf_batch_size = int(os.environ.get("BACKFILL_BATCH_SIZE", "50"))
                _bf_interval = int(os.environ.get("BACKFILL_INTERVAL_SECONDS", "300"))
                _bf_max_retries = int(os.environ.get("BACKFILL_MAX_RETRIES", "3"))
                _backfill_worker = EmbeddingBackfillWorker(
                    db_path=_bf_db_path,
                    plugin=plugin,
                    batch_size=_bf_batch_size,
                    interval_seconds=_bf_interval,
                    max_retries=_bf_max_retries,
                )
                _backfill_worker.start()
                from cortex.api.routes.admin.embedding_worker import backfill_worker_holder
                backfill_worker_holder["worker"] = _backfill_worker
                logger.info("Embedding backfill worker started (db=%s)", _bf_db_path)
            else:
                logger.info(
                    "Embedding backfill worker NOT started: db_path=%r, llm=%s",
                    _bf_db_path, "available" if plugin.llm else "unavailable",
                )
        except Exception as _exc:
            logger.error("Failed to start embedding backfill worker (non-fatal): %s", _exc)

        yield

        # Teardown: embedding backfill worker
        if _backfill_worker is not None:
            try:
                _backfill_worker.stop()
            except Exception as exc:
                logger.warning("Error stopping embedding backfill worker: %s", exc)

        # Teardown: batch worker
        if _batch_worker is not None:
            try:
                _batch_worker.stop()
            except Exception as exc:
                logger.warning("Error stopping batch worker: %s", exc)

        # Teardown: circadian engine
        if _circadian_engine is not None:
            try:
                await _circadian_engine.shutdown(triggered_by="server_shutdown")
            except Exception as exc:
                logger.warning("Error shutting down circadian engine: %s", exc)

        # Teardown: close storage if available
        if getattr(plugin, "storage", None) is not None:
            try:
                await plugin.storage.close()
            except Exception as exc:
                logger.warning("Error closing storage on shutdown: %s", exc)

        # Teardown: DBManager
        _mgr = db_manager_holder.get("manager")
        if _mgr is not None:
            try:
                await _mgr.close_all()
            except Exception as exc:
                logger.warning("Error closing DBManager on shutdown: %s", exc)
            db_manager_holder["manager"] = None

        # Teardown: StatsDB
        _sdb = stats_db_holder.get("db")
        if _sdb is not None:
            try:
                await _sdb.close()
            except Exception as exc:
                logger.warning("Error closing StatsDB on shutdown: %s", exc)
            stats_db_holder["db"] = None

        logger.info("CortexPlugin shut down")

    # ---- App ---------------------------------------------------------------

    app = FastAPI(
        title="Cortex HTTP API",
        description=(
            "REST interface for Cortex — identity-preserving cognitive "
            "infrastructure for AI agents."
        ),
        version=__version__,
        lifespan=lifespan,
    )

    # ---- CORS --------------------------------------------------------------

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_cors_origins_static,
        allow_origin_regex=_cors_origin_regex,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["authorization", "content-type", "x-client-info", "x-api-key", "x-cortex-api-key"],
    )

    # ---- Global body-size limit middleware (#821) --------------------------
    # Rejects requests whose actual body exceeds 512 KB to prevent abuse.
    # Checks BOTH Content-Length header AND actual streamed bytes to guard
    # against chunked-encoding or forged Content-Length bypasses.
    # Individual endpoints may enforce tighter limits (e.g. /remember).

    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request as _BSReq

    _GLOBAL_MAX_BODY_BYTES = int(os.getenv("CORTEX_MAX_BODY_BYTES", "524288"))  # 512 KB

    # Routes that use multipart/form-data with their own size enforcement.
    # Only these specific paths are exempt from the global body size limit.
    from cortex.api.deps import PREFIX as _BSP
    _MULTIPART_EXEMPT_PATHS = frozenset({
        f"{_BSP}/import",
        f"{_BSP}/batch/upload",
    })

    class _BodySizeLimitExceeded(Exception):
        """Raised by the streaming receive wrapper when body exceeds limit."""
        pass

    class _BodySizeLimitMiddleware(BaseHTTPMiddleware):
        """Reject requests exceeding global body size limit (#821).

        Only exempts multipart/form-data on specific upload routes that
        enforce their own size limits (e.g. /import has a 10MB cap).

        Guards against chunked-encoding bypass by reading the actual
        request body and checking accumulated size, not just the
        Content-Length header.
        """

        async def dispatch(self, request: _BSReq, call_next: Any) -> Any:
            content_type = request.headers.get("content-type", "")
            # Only exempt specific upload routes, not all multipart requests
            if "multipart/form-data" in content_type:
                if request.url.path in _MULTIPART_EXEMPT_PATHS:
                    return await call_next(request)
            # Fast-reject: if Content-Length header is present and oversized,
            # reject immediately without reading the body.
            content_length = request.headers.get("content-length")
            if content_length is not None:
                try:
                    cl_int = int(content_length)
                except (ValueError, OverflowError):
                    from starlette.responses import JSONResponse as _BSJR0
                    return _BSJR0(
                        {"detail": "Invalid Content-Length header"},
                        status_code=400,
                    )
                if cl_int > _GLOBAL_MAX_BODY_BYTES:
                    from starlette.responses import JSONResponse as _BSJR
                    return _BSJR(
                        {"detail": f"Request body too large (max {_GLOBAL_MAX_BODY_BYTES} bytes)"},
                        status_code=413,
                    )

            # Stream-aware size enforcement: wrap the ASGI receive to track
            # accumulated bytes and reject as soon as the limit is exceeded,
            # WITHOUT buffering the entire payload into memory first.
            _accumulated = 0
            _limit = _GLOBAL_MAX_BODY_BYTES
            _original_receive = request.receive

            async def _size_limited_receive() -> Any:
                nonlocal _accumulated
                message = await _original_receive()
                if message.get("type") == "http.request":
                    chunk = message.get("body", b"")
                    _accumulated += len(chunk)
                    if _accumulated > _limit:
                        raise _BodySizeLimitExceeded()
                return message

            request._receive = _size_limited_receive
            try:
                return await call_next(request)
            except _BodySizeLimitExceeded:
                from starlette.responses import JSONResponse as _BSJR3
                return _BSJR3(
                    {"detail": f"Request body too large (max {_GLOBAL_MAX_BODY_BYTES} bytes)"},
                    status_code=413,
                )

    app.add_middleware(_BodySizeLimitMiddleware)

    # ---- Rate-limiting middleware (#71) ------------------------------------

    from cortex.api.rate_limiter import RateLimiterMiddleware as _RLM

    _rl_rpm = int(os.getenv("CORTEX_RATE_LIMIT_RPM", "60"))
    _rl_burst = int(os.getenv("CORTEX_RATE_LIMIT_BURST", "10"))
    _rl_enabled = _rl_rpm > 0

    app.add_middleware(
        _RLM,
        requests_per_minute=_rl_rpm,
        burst=_rl_burst,
        enabled=_rl_enabled,
    )

    # ---- Usage-tracking middleware (#550) ----------------------------------
    # Only added in hosted mode (when stats_db_holder will be populated).
    # The stats_db instance is resolved lazily from the holder dict at runtime
    # (same pattern as _LazyRequestLogMiddleware) because lifespan hasn't run yet.

    _env_data_dir_check = os.getenv("CORTEX_DATA_DIR")
    if _env_data_dir_check:
        from cortex.api.middleware.usage_tracker import UsageTrackingMiddleware as _UTM

        class _LazyUsageTrackingMiddleware(_UTM):
            """Resolves stats_db lazily from stats_db_holder."""

            def __init__(self, app: Any, *, _stats_db_holder: dict) -> None:
                # Don't call super().__init__ — stats_db not ready yet
                self.app = app
                self._stats_db_holder = _stats_db_holder
                self._stats_db = None

            @property
            def _stats_db(self):  # type: ignore[override]
                return self._stats_db_holder.get("db")

            @_stats_db.setter
            def _stats_db(self, value):
                # Setter required for __init__ in parent; no-op here
                pass

        app.add_middleware(
            _LazyUsageTrackingMiddleware,
            _stats_db_holder=stats_db_holder,
        )

    # ---- Request-logging middleware (#182) ---------------------------------

    from cortex.api.middleware import RequestLogMiddleware as _RLMBase

    class _LazyRequestLogMiddleware(_RLMBase):
        """Resolves storage lazily from the shared plugin holder."""

        def __init__(self, app: Any, *, _plugin_holder: dict, owner_id: str = "default") -> None:
            from starlette.middleware.base import BaseHTTPMiddleware
            BaseHTTPMiddleware.__init__(self, app)
            self._plugin_holder = _plugin_holder
            self._owner_id = owner_id
            self._storage = None

        async def dispatch(self, request: Any, call_next: Any) -> Any:
            plugin = self._plugin_holder.get("plugin")
            if plugin is not None:
                self._storage = getattr(plugin, "storage", None)
                # Fix 3: resolve owner_id lazily from plugin config at request time
                _config = getattr(plugin, "config", None)
                if _config is not None:
                    self._owner_id = getattr(_config, "owner_id", self._owner_id)
            return await super().dispatch(request, call_next)

    app.add_middleware(
        _LazyRequestLogMiddleware,
        _plugin_holder=plugin_holder,
        owner_id="default",
    )

    # ---- Debug request/response logger middleware (#453) -------------------
    # Captures request+response bodies for the debug ring buffer.
    # Added before RequestTracerMiddleware so it runs inside the tracer
    # (tracer is outermost; debug logger sees the already-traced request).
    # Zero-cost no-op when CORTEX_DEBUG is falsy / debug logging disabled.

    from cortex.api.middleware.debug_logger import DebugLoggerMiddleware as _DLM

    app.add_middleware(_DLM)

    # ---- Namespace guard middleware (#765) ---------------------------------
    # Blocks writes from test/eval namespaces when reject_test_namespace_writes
    # is True, and adds X-Staging: true header when staging_mode is True.
    # Both flags default to False — zero production impact unless configured.
    # Resolves config lazily from plugin_holder (same pattern as other middleware).

    from cortex.api.middleware.namespace_guard import NamespaceGuardMiddleware as _NGM

    app.add_middleware(
        _NGM,
        _plugin_holder=plugin_holder,
    )

    # ---- Request-tracing middleware (#453) ---------------------------------
    # Added LAST so it becomes the outermost layer (first to see each request).

    from cortex.api.middleware.request_tracer import RequestTracerMiddleware as _RTM

    app.add_middleware(_RTM)

    # ---- Sentry user context middleware ------------------------------------
    # Sets owner_id as Sentry user context per request (no PII in value).
    # Only added when Sentry is initialised (SENTRY_DSN set).
    try:
        import sentry_sdk as _sentry_sdk_mw

        if os.getenv("SENTRY_DSN"):
            from starlette.middleware.base import BaseHTTPMiddleware
            from starlette.requests import Request as _SentryRequest

            class _SentryUserMiddleware(BaseHTTPMiddleware):
                """Tag each request with owner_id for Sentry grouping."""

                async def dispatch(self, request: _SentryRequest, call_next: Any) -> Any:
                    owner_id = getattr(getattr(request, "state", None), "owner_id", None)
                    if owner_id:
                        _sentry_sdk_mw.set_user({"id": owner_id})
                    else:
                        _sentry_sdk_mw.set_user(None)
                    return await call_next(request)

            app.add_middleware(_SentryUserMiddleware)
    except ImportError:
        pass

    # ---- Auth dependency (#542) --------------------------------------------

    # Build AuthProvider when any credential is configured.
    #
    # Behaviour table:
    #
    #   jwt_secret only  → JWT auth + public-endpoint exemptions, require_auth
    #                       defaults True (opt-out via CORTEX_AUTH_REQUIRE=false)
    #   api_key only     → Legacy behaviour: all endpoints require the key,
    #                       no public-endpoint exemptions (backward compat)
    #   both configured  → JWT-first with public-endpoint exemptions,
    #                       require_auth defaults True
    #   neither          → Open access (local dev only — warns at startup)

    _auth_provider = None
    _require_auth = False
    _public_endpoints: list = []

    if _jwt_secret:
        # JWT mode (hosted) — public endpoints exempt, require_auth configurable
        from cortex.api.auth import AuthProvider
        _api_key_owner = os.getenv("CORTEX_API_KEY_OWNER")
        _auth_provider = AuthProvider(jwt_secret=_jwt_secret, api_key=_api_key, flyio_sync_secret=_flyio_sync_secret, api_key_owner=_api_key_owner)
        _public_endpoints = [
            "/health",
            "/api/v1/health",
            "/metrics",
            "/api/v1/metrics",
            "/docs",
            "/openapi.json",
            "/redoc",
            "/api/v1/config/providers",
        ]
        # Default to True (secure by default) — opt-out via CORTEX_AUTH_REQUIRE=false (#825)
        _require_auth = os.getenv("CORTEX_AUTH_REQUIRE", "true").lower() not in (
            "0", "false", "no"
        )
    elif _api_key:
        # API-key-only mode (self-host) — all endpoints require the key.
        # No public-endpoint exemptions to preserve backward compatibility.
        from cortex.api.auth import AuthProvider
        _api_key_owner = os.getenv("CORTEX_API_KEY_OWNER")
        _auth_provider = AuthProvider(jwt_secret=None, api_key=_api_key, api_key_owner=_api_key_owner)
        _public_endpoints = []
        _require_auth = True  # backward compat: key always required when set

    # Register provider in shared holder so get_current_user can find it
    auth_holder["auth_provider"] = _auth_provider
    auth_holder["require_auth"] = _require_auth
    auth_holder["public_endpoints"] = _public_endpoints

    verify_api_key = make_auth_dependency(
        _api_key,
        auth_provider=_auth_provider,
        require_auth=_require_auth,
        public_endpoints=_public_endpoints,
    )

    # ---- Routes ------------------------------------------------------------

    from cortex.api.routes import register_routes
    register_routes(app, verify_api_key)

    return app


# ---------------------------------------------------------------------------
# CLI entry point  (`cortex-http`)
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Entry point for the ``cortex-http`` CLI command.

    Environment variables:
        CORTEX_API_KEY   — required API key (leave unset for open access)
        CORTEX_DB_PATH   — override SQLite database path
        CORTEX_CONFIG    — path to cortex.toml

    Example::

        CORTEX_API_KEY=secret cortex-http --host 0.0.0.0 --port 8080
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="cortex-http",
        description="Start the Cortex FastAPI HTTP server",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    parser.add_argument("--workers", type=int, default=1, help="Number of uvicorn workers")
    parser.add_argument(
        "--log-level",
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Log level",
    )
    parser.add_argument("--db-path", default=None, help="Override SQLite DB path")
    parser.add_argument("--config", default=None, help="Path to cortex.toml")
    parser.add_argument(
        "--cors-origins",
        default=None,
        help=(
            "Comma-separated list of allowed CORS origins. "
            "Defaults to none (restrictive). "
            "Set explicitly for development, e.g. --cors-origins http://localhost:3000"
        ),
    )
    args = parser.parse_args()

    if not _FASTAPI_AVAILABLE:  # pragma: no cover
        raise SystemExit(
            "FastAPI is required: pip install 'evaos[api]'"
        )

    # Binding safety check (#825): refuse to bind to non-localhost without auth.
    # Prevents accidental open-access deployments on public interfaces.
    _has_api_key = bool(os.getenv("CORTEX_API_KEY"))
    _has_jwt = bool(os.getenv("SUPABASE_JWT_SECRET"))
    _require_auth = os.getenv("CORTEX_AUTH_REQUIRE", "true").lower() not in (
        "0", "false", "no"
    )
    _has_effective_auth = _has_api_key or (_has_jwt and _require_auth)
    _binding_override = os.getenv("CORTEX_BIND_UNSAFE", "").lower() in (
        "1", "true", "yes"
    )
    _localhost_addrs = {"127.0.0.1", "::1", "localhost"}
    if args.host not in _localhost_addrs and not _binding_override:
        if not _has_effective_auth:
            _reason = (
                "credentials present but CORTEX_AUTH_REQUIRE=false"
                if (_has_jwt or _has_api_key) else
                "no auth credentials configured"
            )
            raise SystemExit(
                "\n"
                "=" * 60 + "\n"
                "🚨  SECURITY REFUSE: Cannot bind to non-localhost without auth.\n"
                f"   Host requested: {args.host}\n"
                f"   Reason: {_reason}\n"
                "   Set CORTEX_API_KEY or SUPABASE_JWT_SECRET (with require_auth=true)\n"
                "   before binding to a public interface, or use --host 127.0.0.1 for\n"
                "   local dev. Override with CORTEX_BIND_UNSAFE=true if intentional.\n"
                + "=" * 60
            )

    cors_origins = (
        [o.strip() for o in args.cors_origins.split(",") if o.strip()]
        if args.cors_origins
        else []
    )

    app = create_app(
        config_path=args.config,
        db_path=args.db_path,
        cors_origins=cors_origins,
    )

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers if not args.reload else 1,
        log_level=args.log_level,
    )


if __name__ == "__main__":
    main()
