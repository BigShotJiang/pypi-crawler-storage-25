"""cortex/api/routes/graph.py — Graph visualization endpoints."""

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status

from cortex.api.deps import PREFIX, _serialise, get_plugin, _resolve_owner_id

logger = logging.getLogger(__name__)

router = APIRouter()


def _make_routes(verify_api_key):
    """Register graph visualization routes with the given auth dependency."""

    @router.get(
        f"{PREFIX}/graph",
        summary="Get entity relationship graph",
        tags=["graph"],
    )
    async def get_entity_graph(
        request: Request,
        owner_id: Optional[str] = None,
        center_entity_id: Optional[str] = None,
        max_depth: int = 2,
        max_nodes: int = 50,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ):
        """Return entity relationship graph for visualization."""
        if plugin.storage is None:
            raise HTTPException(503, detail="Storage unavailable")

        resolved_owner = _resolve_owner_id(request, owner_id)
        if owner_id and resolved_owner != owner_id:
            logger.warning(
                "Owner ID override in get_entity_graph: requested=%s resolved=%s ip=%s",
                owner_id, resolved_owner, request.client.host if request.client else "unknown",
            )
        owner_id = resolved_owner

        try:
            graph_data = await plugin.storage.get_entity_graph(
                owner_id=owner_id,
                center_entity_id=center_entity_id,
                max_depth=max_depth,
                max_nodes=max_nodes,
            )
            return graph_data
        except Exception as exc:
            logger.error("get_entity_graph failed: %s", exc, exc_info=True)
            raise HTTPException(500, detail="Internal server error")

    @router.get(
        f"{PREFIX}/graph/neighbors/{{entity_id}}",
        summary="Get entity neighborhood",
        tags=["graph"],
    )
    async def get_entity_neighbors(
        request: Request,
        entity_id: str,
        owner_id: Optional[str] = None,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ):
        """Return immediate neighbors of an entity."""
        if plugin.storage is None:
            raise HTTPException(503, detail="Storage unavailable")

        resolved_owner = _resolve_owner_id(request, owner_id)
        if owner_id and resolved_owner != owner_id:
            logger.warning(
                "Owner ID override in get_entity_neighbors: requested=%s resolved=%s ip=%s",
                owner_id, resolved_owner, request.client.host if request.client else "unknown",
            )
        owner_id = resolved_owner

        try:
            neighbors = await plugin.storage.get_entity_neighbors(
                entity_id=entity_id,
                owner_id=owner_id,
            )
            return neighbors
        except Exception as exc:
            logger.error("get_entity_neighbors failed: %s", exc, exc_info=True)
            raise HTTPException(500, detail="Internal server error")

    @router.get(
        f"{PREFIX}/graph/paths/{{source_id}}/{{target_id}}",
        summary="Find shortest path between entities",
        tags=["graph"],
    )
    async def get_entity_path(
        request: Request,
        source_id: str,
        target_id: str,
        owner_id: Optional[str] = None,
        max_hops: int = 5,
        _: None = Depends(verify_api_key),
        plugin: Any = Depends(get_plugin),
    ):
        """Find shortest path between two entities."""
        if plugin.storage is None:
            raise HTTPException(503, detail="Storage unavailable")

        resolved_owner = _resolve_owner_id(request, owner_id)
        if owner_id and resolved_owner != owner_id:
            logger.warning(
                "Owner ID override in get_entity_path: requested=%s resolved=%s ip=%s",
                owner_id, resolved_owner, request.client.host if request.client else "unknown",
            )
        owner_id = resolved_owner

        try:
            path = await plugin.storage.find_shortest_path(
                source_id=source_id,
                target_id=target_id,
                owner_id=owner_id,
                max_hops=max_hops,
            )
            return path
        except Exception as exc:
            logger.error("get_entity_path failed: %s", exc, exc_info=True)
            raise HTTPException(500, detail="Internal server error")
