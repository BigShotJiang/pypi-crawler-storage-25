"""cortex/api/routes/admin — Admin endpoints (package).

Backward-compatible shim: imports and re-exports router + _make_routes
so that ``from cortex.api.routes.admin import router, _make_routes`` works.

Deprecated paths (sunset 2026-06-01 — issue #297):
  GET /api/v1/stats    → /stats/dashboard  (simple stats, superseded by dashboard)
  GET /api/v1/requests → /admin/requests   (request log, now properly namespaced)
"""

from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


def _make_routes(verify_api_key):
    """Register all admin routes with the given auth dependency."""
    from cortex.api.routes.admin.health import _register as _health
    from cortex.api.routes.admin.dreams import _register as _dreams
    from cortex.api.routes.admin.admin_stats import _register as _stats
    from cortex.api.routes.admin.backup import _register as _backup
    from cortex.api.routes.admin.request_logs import _register as _request_logs
    from cortex.api.routes.admin.owners import _register as _owners
    from cortex.api.routes.admin.memory_management import _register as _memory
    from cortex.api.routes.admin.observatory import _register as _observatory
    from cortex.api.routes.admin.embedding_worker import _register as _embedding_worker
    from cortex.api.routes.admin.config_status import _register as _config_status
    from cortex.api.routes.admin.config_drift import _register as _config_drift

    for register_fn in [_health, _dreams, _stats, _backup, _request_logs, _owners, _memory, _observatory, _embedding_worker, _config_status, _config_drift]:
        register_fn(router, verify_api_key)
