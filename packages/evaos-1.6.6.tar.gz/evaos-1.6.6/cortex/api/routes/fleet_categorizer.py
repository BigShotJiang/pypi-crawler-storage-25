"""
cortex/api/routes/fleet_categorizer.py — Error categorization engine (re-export).

The full categorization logic lives in cortex/aegis/categorizer.py.
This module re-exports the public API for callers that import from the routes
package.

Issues: #829, #1071
"""
from cortex.aegis.categorizer import (  # noqa: F401
    CategorizedAlert,
    SentryEvent,
    categorize,
)

__all__ = ["SentryEvent", "CategorizedAlert", "categorize"]
