"""
cortex/storage/migrations/v31_quality_score.py — Add quality_score to semantic_claim.

Extraction-time quality scoring: a composite 0.0–1.0 score assigned during
claim extraction and used for filtering low-quality claims and boosting
retrieval ranking.

New column:
- semantic_claim.quality_score (REAL, nullable) — composite quality score

Nullable (no DEFAULT) so NULL means "unscored" (pre-feature claims), which
is semantically different from 0.0.

Fixes: #1675

Migration: version 30 → 31
"""

VERSION = 31
DESCRIPTION = "Add quality_score column to semantic_claim (#1675)"

SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN quality_score REAL;

CREATE INDEX IF NOT EXISTS idx_claim_quality
    ON semantic_claim(owner_id, quality_score) WHERE quality_score IS NOT NULL;
"""

# Additive-only: SQLite DROP COLUMN is risky.
SQL_DOWN = """
DROP INDEX IF EXISTS idx_claim_quality;
SELECT 1;
"""
