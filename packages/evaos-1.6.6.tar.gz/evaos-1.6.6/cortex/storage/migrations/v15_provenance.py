"""v15 — Add metadata_json column to semantic_claim for provenance tracking.

Stores source_session_id, source_message_id, source_channel, source_type
as a JSON blob so every memory can be traced back to the conversation that
created it.  Issue #748.
"""

VERSION = 15
DESCRIPTION = "Add metadata_json column to semantic_claim for provenance tracking (#748)"

# SQLite ALTER TABLE is idempotent-safe via IF NOT EXISTS on new columns
# when the column doesn't already exist — standard migration pattern.
SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN metadata_json TEXT DEFAULT NULL;
"""

SQL_DOWN = """
-- SQLite does not support DROP COLUMN in older versions; left as no-op.
-- In practice, metadata_json is a nullable additive column with no data loss on rollback.
"""
