"""v16 — Extraction failure queue for resilient memory capture.

When extraction fails (LLM timeout, provider error, 503), the conversation
payload is queued for retry during the next dream cycle instead of being
silently lost.

Issue: production-hardening-2026-03-14 / Area 3
"""

VERSION = 17
DESCRIPTION = "Extraction failure queue for retry resilience"

SQL_UP = """
CREATE TABLE IF NOT EXISTS extraction_queue (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    message_id TEXT,
    owner_id TEXT NOT NULL,
    payload TEXT NOT NULL,
    failed_at TIMESTAMP NOT NULL DEFAULT (datetime('now')),
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    status TEXT DEFAULT 'pending',
    error_message TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT (datetime('now')),
    updated_at TIMESTAMP NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_extraction_queue_status
    ON extraction_queue(status);
CREATE INDEX IF NOT EXISTS idx_extraction_queue_owner
    ON extraction_queue(owner_id);
"""

SQL_DOWN = """
DROP TABLE IF EXISTS extraction_queue;
"""
