"""
cortex/storage/migrations/v12_temporal_marker.py — Persist temporal marker + temporal class.

The extraction prompt produces `temporal_marker` (raw time phrase like "last week",
"March 2026") and `temporal` (classification: current/past/future/permanent). These
flow through CandidateClaim and reconciliation but were never persisted to the
semantic_claim table — dropped at the storage boundary.

New columns:
- semantic_claim.temporal_marker (TEXT, nullable) — verbatim time phrase from text
- semantic_claim.temporal (TEXT, DEFAULT 'current') — temporal class: current|past|future|permanent

Fixes: #573

Migration: version 11 → 12
"""

VERSION = 12
DESCRIPTION = "Add temporal_marker and temporal columns to semantic_claim (#573)"

SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN temporal_marker TEXT DEFAULT NULL;
ALTER TABLE semantic_claim ADD COLUMN temporal TEXT NOT NULL DEFAULT 'current';

CREATE INDEX IF NOT EXISTS idx_claim_temporal
    ON semantic_claim(owner_id, temporal, status);
"""

# Additive-only: SQLite DROP COLUMN is risky.
SQL_DOWN = """
DROP INDEX IF EXISTS idx_claim_temporal;
SELECT 1;
"""
