"""
cortex/storage/migrations/v14_review_queue.py — Add review queue support.

Adds `flag_reason` column to semantic_claim for the manual review queue feature.
Memories with status='needs_review' are quarantined from retrieval/search until
an operator approves or rejects them.

The 'needs_review' and 'rejected' statuses are added as valid claim status values
at the application layer (types.py, API validation). This migration only adds the
flag_reason column to persist the reason a memory was flagged.

New columns:
- semantic_claim.flag_reason (TEXT, nullable) — operator-provided reason for flagging

Fixes: #{issue_number}

Migration: version 13 → 14
"""

VERSION = 14
DESCRIPTION = "Add flag_reason column and review queue index to semantic_claim"

SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN flag_reason TEXT DEFAULT NULL;

CREATE INDEX IF NOT EXISTS idx_claim_review_queue
    ON semantic_claim(owner_id, status) WHERE status = 'needs_review';
"""

SQL_DOWN = """
DROP INDEX IF EXISTS idx_claim_review_queue;
"""
