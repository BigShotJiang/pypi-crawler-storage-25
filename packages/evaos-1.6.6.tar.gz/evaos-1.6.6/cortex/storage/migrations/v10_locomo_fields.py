"""
cortex/storage/migrations/v10_locomo_fields.py — LoCoMo extraction fields.

Adds columns to semantic_claim for memory classification, temporal
ordering, and salience scoring — extracted by the LoCoMo-aligned
prompt (PR #510, issue #508) but previously lost at storage boundary.

New columns:
- semantic_claim.memory_class (semantic/episodic/procedural/open_loop/transient)
- semantic_claim.event_date (ISO YYYY-MM-DD, nullable)
- semantic_claim.sequence_order (integer, within-conversation ordering)
- semantic_claim.salience (high/medium/low)

Migration: version 9 → 10
"""

VERSION = 10
DESCRIPTION = "Add LoCoMo extraction fields: memory_class, event_date, sequence_order, salience, cause, effect, state_before, state_after"

SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN memory_class TEXT DEFAULT 'semantic';
ALTER TABLE semantic_claim ADD COLUMN event_date TEXT DEFAULT NULL;
ALTER TABLE semantic_claim ADD COLUMN sequence_order INTEGER DEFAULT NULL;
ALTER TABLE semantic_claim ADD COLUMN salience TEXT DEFAULT 'medium';
ALTER TABLE semantic_claim ADD COLUMN cause TEXT DEFAULT NULL;
ALTER TABLE semantic_claim ADD COLUMN effect TEXT DEFAULT NULL;
ALTER TABLE semantic_claim ADD COLUMN state_before TEXT DEFAULT NULL;
ALTER TABLE semantic_claim ADD COLUMN state_after TEXT DEFAULT NULL;

CREATE INDEX IF NOT EXISTS idx_claim_memory_class
    ON semantic_claim(owner_id, memory_class, status);
CREATE INDEX IF NOT EXISTS idx_claim_event_date
    ON semantic_claim(owner_id, event_date) WHERE event_date IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_claim_salience
    ON semantic_claim(owner_id, salience, status);
"""

# Additive-only migration; downgrade drops indexes but leaves columns
# (SQLite DROP COLUMN is version-dependent and risky).
SQL_DOWN = """
DROP INDEX IF EXISTS idx_claim_salience;
DROP INDEX IF EXISTS idx_claim_event_date;
DROP INDEX IF EXISTS idx_claim_memory_class;
SELECT 1;
"""
