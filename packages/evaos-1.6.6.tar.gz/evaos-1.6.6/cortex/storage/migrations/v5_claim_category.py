"""
cortex/storage/migrations/v5_claim_category.py — Add category column to semantic_claim.

Adds a `category` column (TEXT, DEFAULT 'misc') to the semantic_claim table so that
extraction-pipeline-assigned categories (identity, personal, preferences, engineering,
goals) are persisted alongside each claim.

Existing rows are migrated to the 'misc' default automatically via the DEFAULT clause.

Migration: version 4 → 5
"""

VERSION = 5
DESCRIPTION = "Add category column to semantic_claim for extraction category tagging"

SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN category TEXT NOT NULL DEFAULT 'misc';

CREATE INDEX IF NOT EXISTS idx_claim_category
    ON semantic_claim (owner_id, category, status);
"""

# SQLite does not support DROP COLUMN in older versions (< 3.35).
# The safest downgrade path is a no-op: leaving the column in place causes
# no harm and avoids the complexity of a table rebuild.  Operators who need
# a hard rollback should restore from a pre-migration backup.
SQL_DOWN = """
-- Intentional no-op: SQLite DROP COLUMN requires >= 3.35.
-- Restore from backup if a hard rollback is needed.
SELECT 1;
"""
