"""
cortex/storage/migrations/v29_embedding_model_lock.py — Embedding model lock key (#92).

Introduces the ``embedding_model_lock`` key in the cortex_config table.
The key records which embedding model created the stored vectors so that
a mismatch between the lock value and the currently-configured model can
be detected at startup before any silent incompatibility can occur.

This migration is intentionally a no-op SQL (SELECT 1) because the lock
value is written at runtime during ``SQLiteAdapter.initialize()``; the
migration only bumps the schema version so the runner knows v29 has been
applied.

Migration: version 28 → 29
"""

VERSION = 29
DESCRIPTION = "Reserve embedding_model_lock key in cortex_config for startup safety check (#92)"

# SQL_UP: idempotent no-op — the lock value is written at startup, not here,
# because we need the live configured model name which is not available at
# migration time.
SQL_UP = "SELECT 1;"

SQL_DOWN = """
DELETE FROM cortex_config WHERE key = 'embedding_model_lock';
"""


async def apply(conn) -> None:
    """No-op migration — schema version bump only."""
    await conn.execute(SQL_UP)
    await conn.commit()


async def upgrade(conn) -> None:
    """Alias for apply()."""
    await apply(conn)


async def downgrade(conn) -> None:
    """Remove the lock key (if set) on rollback."""
    await conn.execute("DELETE FROM cortex_config WHERE key = 'embedding_model_lock'")
    await conn.commit()
