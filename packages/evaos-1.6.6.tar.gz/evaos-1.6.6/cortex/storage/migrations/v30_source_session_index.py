"""
cortex/storage/migrations/v30_source_session_index.py — Index on source_session.

Adds an index on semantic_claim.source_session to eliminate full table scans
on the 3+ active query paths that JOIN or filter by session.

Migration: version 29 → 30
"""

VERSION = 30
DESCRIPTION = "Add index on semantic_claim.source_session"

SQL_UP = "CREATE INDEX IF NOT EXISTS idx_claim_source_session ON semantic_claim(source_session);"

SQL_DOWN = "DROP INDEX IF EXISTS idx_claim_source_session;"


async def apply(conn) -> None:
    await conn.execute(SQL_UP)
    await conn.commit()


async def upgrade(conn) -> None:
    """Alias for apply()."""
    await apply(conn)


async def downgrade(conn) -> None:
    await conn.execute(SQL_DOWN)
    await conn.commit()
