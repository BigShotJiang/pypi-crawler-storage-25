"""
cortex/storage/migrations/v23_batch_jobs.py — Batch ingest job tracking (#1326).

Adds batch_jobs table for tracking background batch ingestion jobs.

Migration: version 22 → 23
"""

VERSION = 23
DESCRIPTION = "Add batch_jobs table for background batch ingestion (#1326)"

SQL_UP = """
CREATE TABLE IF NOT EXISTS batch_jobs (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL DEFAULT 'pending',
    source_type TEXT NOT NULL,
    filename TEXT,
    total_chunks INTEGER DEFAULT 0,
    processed_chunks INTEGER DEFAULT 0,
    claims_stored INTEGER DEFAULT 0,
    errors_json TEXT DEFAULT '[]',
    config_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT,
    file_results_json TEXT DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_batch_jobs_status ON batch_jobs(status);
CREATE INDEX IF NOT EXISTS idx_batch_jobs_created ON batch_jobs(created_at);
"""
