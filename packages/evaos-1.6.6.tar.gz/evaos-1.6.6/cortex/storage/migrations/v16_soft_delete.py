"""v16 — Soft-delete support with 90-day retention.

Adds `deleted_at` (TIMESTAMP) and `is_deleted` (INTEGER DEFAULT 0) columns
to the `semantic_claim` table.  When a claim is deleted via the API, instead
of removing the row (or just setting status='archived'), we set is_deleted=1
and deleted_at=NOW().

A dream-cycle purge step permanently removes rows where
deleted_at < (NOW - 90 days).

A restore endpoint can clear is_deleted and deleted_at to recover memories
within the 90-day window.

Issue: production-hardening-2026-03-14 / Area 2
"""

VERSION = 16
DESCRIPTION = "Soft-delete columns (deleted_at, is_deleted) on semantic_claim for 90-day retention"

SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN is_deleted INTEGER DEFAULT 0;
ALTER TABLE semantic_claim ADD COLUMN deleted_at TIMESTAMP DEFAULT NULL;
"""

SQL_DOWN = """
-- SQLite < 3.35 does not support DROP COLUMN; left as no-op.
-- is_deleted and deleted_at are nullable additive columns with no data loss on rollback.
"""
