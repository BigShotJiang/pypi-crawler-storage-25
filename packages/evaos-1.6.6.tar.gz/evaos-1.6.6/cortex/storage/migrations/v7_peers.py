"""
cortex/storage/migrations/v7_peers.py — Peer Modeling Tables (M15).

Adds the peer table for tracking interaction partners and building
representations of them. Supports auto-creation from entity mentions
and a structured JSON representation blob for learned traits.

Migration: version 6 → 7
"""

VERSION = 7
DESCRIPTION = "Add peer modeling table: peer + indexes"

SQL_UP = """
-- -----------------------------------------------------------------------
-- peer: interaction partners with learned representations
-- -----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS peer (
    id                TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    owner_id          TEXT NOT NULL,
    entity_id         TEXT REFERENCES entity(id),
    display_name      TEXT NOT NULL,
    relationship      TEXT DEFAULT 'unknown',
    first_interaction TEXT NOT NULL,
    last_interaction  TEXT NOT NULL,
    interaction_count INTEGER DEFAULT 1,
    representation    TEXT DEFAULT '{}',
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_peer_owner ON peer(owner_id);
CREATE INDEX IF NOT EXISTS idx_peer_entity ON peer(entity_id);
"""

SQL_DOWN = """
DROP INDEX IF EXISTS idx_peer_entity;
DROP INDEX IF EXISTS idx_peer_owner;
DROP TABLE IF EXISTS peer;
"""
