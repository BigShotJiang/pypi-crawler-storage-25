"""
cortex/storage/migrations/v13_explicitness_stability.py — Persist explicitness and stability.

The extraction prompt produces `explicitness` (how explicitly the claim was stated:
explicit/implied/inferred based on confidence threshold) and `stability` (how likely
the claim is to change over time: stable/mutable/volatile based on temporal class).
These flow through CandidateClaim and were extracted but never persisted to the
semantic_claim table — silently dropped at the storage boundary.

New columns:
- semantic_claim.explicitness (TEXT, DEFAULT 'inferred') — explicit|implied|inferred
- semantic_claim.stability (TEXT, DEFAULT 'volatile') — stable|mutable|volatile

ContextCompiler._classify_item() already reads stability from retrieved items
to decide whether a fact belongs in the defaults bundle. Prior to this migration
the field was always empty, so stable facts were misclassified as evidence.

Fixes: #609

Migration: version 12 → 13
"""

VERSION = 13
DESCRIPTION = "Add explicitness and stability columns to semantic_claim (#609)"

SQL_UP = """
ALTER TABLE semantic_claim ADD COLUMN explicitness TEXT NOT NULL DEFAULT 'inferred';
ALTER TABLE semantic_claim ADD COLUMN stability TEXT NOT NULL DEFAULT 'volatile';

CREATE INDEX IF NOT EXISTS idx_claim_explicitness
    ON semantic_claim(owner_id, explicitness);

CREATE INDEX IF NOT EXISTS idx_claim_stability
    ON semantic_claim(owner_id, stability);
"""

# Additive-only: SQLite DROP COLUMN is risky.
SQL_DOWN = """
DROP INDEX IF EXISTS idx_claim_explicitness;
DROP INDEX IF EXISTS idx_claim_stability;
SELECT 1;
"""
