"""
cortex/storage/migrations/v24_source_agent.py — Add source_agent to semantic_claim (#1396).

Adds source_agent TEXT column to the semantic_claim table. Nullable so
existing claims are unaffected (they will have NULL).

Migration: version 23 → 24
"""

VERSION = 24
DESCRIPTION = "Add source_agent field to semantic_claim (#1396)"

SQL_UP = ""  # Applied via apply() for idempotent ALTER TABLE support


async def apply(conn) -> None:
    """Add source_agent column to semantic_claim (idempotent)."""
    try:
        await conn.execute(
            "ALTER TABLE semantic_claim ADD COLUMN source_agent TEXT"
        )
    except Exception:
        pass  # Column already exists — idempotent

    await conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_semantic_claim_source_agent ON semantic_claim(source_agent)"
    )
    await conn.commit()
