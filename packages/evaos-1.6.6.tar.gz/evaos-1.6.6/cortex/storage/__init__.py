"""
cortex/storage — storage abstraction layer.

Public surface:
    StorageAdapter   – abstract interface
    SQLiteAdapter    – SQLite/aiosqlite implementation
"""
from cortex.storage.adapter import StorageAdapter
from cortex.storage.sqlite_adapter import SQLiteAdapter, EmbeddingModelMismatchError

__all__ = ["StorageAdapter", "SQLiteAdapter", "EmbeddingModelMismatchError"]
