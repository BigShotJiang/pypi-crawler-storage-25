"""Composed ClaimQueryMixin — backwards-compatible re-export."""

# Pagination guard constant — also duplicated in browse.py to avoid circular import.
_MAX_PAGE_SIZE = 200

from .crud import ClaimCRUDMixin
from .search import ClaimSearchMixin
from .vectors import ClaimVectorMixin
from .graph import ClaimGraphMixin
from .feedback import ClaimFeedbackMixin
from .logging import ClaimLoggingMixin
from .lifecycle import ClaimLifecycleMixin
from .browse import ClaimBrowseMixin

MAX_PAGE_SIZE = _MAX_PAGE_SIZE


class ClaimQueryMixin(
    ClaimCRUDMixin,
    ClaimSearchMixin,
    ClaimVectorMixin,
    ClaimGraphMixin,
    ClaimFeedbackMixin,
    ClaimLoggingMixin,
    ClaimLifecycleMixin,
    ClaimBrowseMixin,
):
    """Composed mixin — all claim query operations."""
    pass
