"""Backwards-compat shim — real implementation in claims/ package."""
from cortex.storage.queries.claims import ClaimQueryMixin, MAX_PAGE_SIZE  # noqa: F401

__all__ = ["ClaimQueryMixin", "MAX_PAGE_SIZE"]
