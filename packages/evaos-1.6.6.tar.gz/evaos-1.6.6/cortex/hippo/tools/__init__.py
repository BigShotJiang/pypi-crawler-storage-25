"""Hippo LCM tool definitions."""
