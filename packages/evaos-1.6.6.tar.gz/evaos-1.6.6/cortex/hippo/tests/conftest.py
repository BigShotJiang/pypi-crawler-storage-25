"""
Shared fixtures for Hippo tests.

Provides in-memory database, engine, and store fixtures.
"""

from __future__ import annotations

import pytest
import pytest_asyncio

from cortex.hippo.config import HippoConfig
from cortex.hippo.engine import HippoEngine


@pytest.fixture
def hippo_config() -> HippoConfig:
    """Return a HippoConfig with in-memory DB for testing."""
    return HippoConfig(
        enabled=True,
        db_path=":memory:",
        fresh_tail_count=4,  # Small for testing
        max_tokens=10_000,
        context_threshold=0.75,
        context_window_tokens=100,  # Low so leaf trigger fires easily in tests
        leaf_trigger_margin=100,
    )


@pytest_asyncio.fixture
async def engine(hippo_config: HippoConfig) -> HippoEngine:
    """Return an initialized HippoEngine with in-memory DB."""
    eng = HippoEngine(config=hippo_config)
    await eng.initialize(
        db_path=":memory:",
        owner_id="test-owner",
        conversation_id="test-session",
    )
    yield eng
    await eng.shutdown()
