"""Tests for cortex.hippo LCM module."""
