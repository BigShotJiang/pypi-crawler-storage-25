"""cortex.hippo.db — Database layer for Hippo LCM."""
