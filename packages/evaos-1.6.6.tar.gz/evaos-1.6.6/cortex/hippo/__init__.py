"""
cortex.hippo — Lossless Context Management (LCM) module for Cortex.

Hippo (Hippocampus) implements DAG-based conversation context compression
with hierarchical summarization that preserves full recoverability of all
original content.

Phase 1: SQLite schema, core engine, context assembler, configuration.
"""

__version__ = "1.5.7"

from cortex.hippo.config import HippoConfig
from cortex.hippo.engine import HippoEngine
from cortex.hippo.assembler import ContextAssembler

__all__ = ["HippoConfig", "HippoEngine", "ContextAssembler", "__version__"]
