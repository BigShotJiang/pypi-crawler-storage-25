"""
cortex/hippo/compaction — Two-phase compaction engine (leaf pass + condensation).

Mirrors lossless-claw CompactionEngine with async aiosqlite ops.

Issue: #804
"""

from .engine import CompactionEngine
from .helpers import (
    _escalation_result,
    _extract_file_ids,
    estimate_tokens,
    format_timestamp,
    generate_summary_id,
)
from .types import (
    FALLBACK_MAX_CHARS,
    CompactionDecision,
    CompactionLevel,
    CompactionResult,
    CondensedChunkSelection,
    CondensedPhaseCandidate,
    LeafChunkSelection,
    PassResult,
    SummarizeFn,
)

__all__ = [
    "CompactionEngine",
    "CompactionDecision",
    "CompactionLevel",
    "CompactionResult",
    "CondensedChunkSelection",
    "CondensedPhaseCandidate",
    "FALLBACK_MAX_CHARS",
    "LeafChunkSelection",
    "PassResult",
    "SummarizeFn",
    "_escalation_result",
    "_extract_file_ids",
    "estimate_tokens",
    "format_timestamp",
    "generate_summary_id",
]
