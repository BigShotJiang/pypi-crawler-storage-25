"""
cortex/hippo/store/fts_utils.py — FTS5 query sanitization utilities.
"""

from __future__ import annotations

import re
from typing import Optional

FTS5_SPECIAL_CHARS = re.compile(r'["\*\^:(),-]')


def sanitize_fts5_query(query: str) -> Optional[str]:
    """Sanitize FTS5 query. Returns None if query degenerates to empty."""
    cleaned = FTS5_SPECIAL_CHARS.sub(" ", query).strip()
    tokens = [t for t in cleaned.split() if len(t) >= 2]
    if not tokens:
        return None
    return " ".join(tokens)
