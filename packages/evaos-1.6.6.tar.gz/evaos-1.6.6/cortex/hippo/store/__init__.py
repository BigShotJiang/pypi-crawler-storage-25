"""cortex.hippo.store — Data access layer for Hippo LCM."""
