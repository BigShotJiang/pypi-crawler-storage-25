"""
cortex/hippo/store/utils.py — Shared store utilities.

Issue: #1181
"""

from __future__ import annotations


def escape_like_pattern(pattern: str) -> str:
    """Escape special LIKE metacharacters so they match literally.

    The escaped pattern is intended for use with ``ESCAPE '\\'`` in SQL::

        WHERE content LIKE ? ESCAPE '\\'

    Escaping order matters: backslash first to avoid double-escaping.
    """
    pattern = pattern.replace("\\", "\\\\")
    pattern = pattern.replace("%", "\\%")
    pattern = pattern.replace("_", "\\_")
    return pattern
