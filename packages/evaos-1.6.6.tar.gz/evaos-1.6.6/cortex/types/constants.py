"""cortex/types/constants.py — Canonical category/memory-type constants."""

from __future__ import annotations


# Valid claim categories. "misc" is fallback for missing/unknown.
VALID_CATEGORIES = frozenset({
    "identity", "personal", "preferences", "decisions", "goals",
    "behavioral", "relational", "episodic", "misc",
})

# Alias map: normalise common LLM variants to canonical category names.
# Keys are lowercase; values must be in VALID_CATEGORIES.
CATEGORY_ALIASES: dict[str, str] = {
    # decisions (replaces engineering for arch decisions)
    "engineering": "decisions",
    "technical": "decisions",
    "architecture": "decisions",
    "arch": "decisions",
    "decision": "decisions",
    "standard": "decisions",
    "tech_decision": "decisions",
    # personal
    "bio": "personal",
    "biographical": "personal",
    "family": "personal",
    # preferences
    "preference": "preferences",
    "pref": "preferences",
    "setting": "preferences",
    "tech": "preferences",
    "code": "preferences",
    # goals
    "goal": "goals",
    "plan": "goals",
    "strategy": "goals",
    # identity
    "self": "identity",
    "personality": "identity",
    "core": "identity",
    # behavioral
    "behavior": "behavioral",
    "habit": "behavioral",
    "routine": "behavioral",
    "pattern": "behavioral",
    "workflow": "behavioral",
    # relational
    "relationship": "relational",
    "social": "relational",
    "relation": "relational",
    # episodic
    "episode": "episodic",
    "event": "episodic",
    "milestone": "episodic",
    "incident": "episodic",
    "experience": "episodic",
}

# Memory types that are exempt from deprecation/decay.
EXEMPT_MEMORY_TYPES = frozenset({"cornerstone", "immutable", "core"})

# Semantic-tier memory types (for consolidation queries).
SEMANTIC_MEMORY_TYPES = frozenset({"semantic", "core"})

# Intrinsic types — normalized knowledge classes used by v1.2 wake-path classification.
INTRINSIC_TYPES = frozenset({
    "fact", "preference", "goal",
})

# Valid entity types — canonical set for entity classification.
VALID_ENTITY_TYPES = frozenset({
    "person", "organization", "technology", "project",
    "concept", "location", "event", "other",
})

# Entity type aliases — normalize LLM variations to canonical types.
ENTITY_TYPE_ALIASES: dict[str, str] = {
    "place": "location",
    "loc": "location",
    "city": "location",
    "country": "location",
    "org": "organization",
    "company": "organization",
    "tech": "technology",
    "tool": "technology",
    "framework": "technology",
    "language": "technology",
    "lib": "technology",
    "library": "technology",
    "human": "person",
    "individual": "person",
    "user": "person",
    "idea": "concept",
    "topic": "concept",
    "proj": "project",
    "repo": "project",
    "meeting": "event",
    "conference": "event",
    "incident": "event",
}

# Human relationship families — used for entity resolution weighting.
HUMAN_FAMILIES = frozenset({
    "family", "friend", "colleague", "partner", "mentor", "mentee",
})

# Maps user-facing categories to normalized intrinsic type labels.
CATEGORY_TO_INTRINSIC_MAP: dict[str, str] = {
    "identity": "fact",
    "personal": "fact",
    "preferences": "preference",
    "decisions": "fact",
    "goals": "goal",
    "behavioral": "fact",
    "relational": "fact",
    "episodic": "fact",
    "misc": "fact",
}
