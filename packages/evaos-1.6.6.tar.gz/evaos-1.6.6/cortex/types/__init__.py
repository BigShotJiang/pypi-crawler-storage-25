"""cortex/types — Shared types for Cortex v3.

Re-exports all public symbols from sub-modules for backward compatibility.
All existing ``from cortex.types import X`` imports continue to work unchanged.
"""

from cortex.types.constants import (
    VALID_CATEGORIES,
    CATEGORY_ALIASES,
    EXEMPT_MEMORY_TYPES,
    SEMANTIC_MEMORY_TYPES,
    INTRINSIC_TYPES,
    VALID_ENTITY_TYPES,
    ENTITY_TYPE_ALIASES,
    HUMAN_FAMILIES,
    CATEGORY_TO_INTRINSIC_MAP,
)
from cortex.types.enums import (
    CortexTier,
    MemoryLayer,
    CompressionLevel,
    InjectionSlot,
)
from cortex.types.claims import (
    SemanticClaim,
    CandidateClaim,
    ClaimProvenance,
)
from cortex.types.entities import (
    Entity,
    EntityAlias,
    ResolvedEntity,
    CandidateEntity,
    Peer,
    MergeSuggestion,
)
from cortex.types.records import (
    SessionRecord,
    EpisodeEvent,
    CornerstoneMemory,
    EvolutionProposal,
    ProcedureMemory,
    MemoryEdge,
    MemoryFeedback,
    VectorResult,
    FTSResult,
)
from cortex.types.budget import (
    BudgetAllocation,
    CompressedItem,
)
from cortex.types.brain_graph import (
    BrainGraphIndex,
    BrainGraphNode,
    BrainGraphEdge,
)
from cortex.types.adapters import (
    StorageAdapter,
    LLMProvider,
)

__all__ = [
    # constants
    "VALID_CATEGORIES",
    "CATEGORY_ALIASES",
    "EXEMPT_MEMORY_TYPES",
    "SEMANTIC_MEMORY_TYPES",
    "INTRINSIC_TYPES",
    "VALID_ENTITY_TYPES",
    "ENTITY_TYPE_ALIASES",
    "HUMAN_FAMILIES",
    "CATEGORY_TO_INTRINSIC_MAP",
    # enums
    "CortexTier",
    "MemoryLayer",
    "CompressionLevel",
    "InjectionSlot",
    # claims
    "SemanticClaim",
    "CandidateClaim",
    "ClaimProvenance",
    # entities
    "Entity",
    "EntityAlias",
    "ResolvedEntity",
    "CandidateEntity",
    "Peer",
    "MergeSuggestion",
    # records
    "SessionRecord",
    "EpisodeEvent",
    "CornerstoneMemory",
    "EvolutionProposal",
    "ProcedureMemory",
    "MemoryEdge",
    "MemoryFeedback",
    "VectorResult",
    "FTSResult",
    # budget
    "BudgetAllocation",
    "CompressedItem",
    # brain graph
    "BrainGraphIndex",
    "BrainGraphNode",
    "BrainGraphEdge",
    # adapters
    "StorageAdapter",
    "LLMProvider",
]
