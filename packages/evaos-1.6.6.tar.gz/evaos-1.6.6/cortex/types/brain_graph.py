"""cortex/types/brain_graph.py — Brain graph index, node, and edge types."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class BrainGraphIndex:
    """Top-level index for a compiled knowledge graph (L5).

    A brain graph is a versioned, structured representation of a document
    or knowledge domain. Built from source documents by decomposing them
    into nodes and edges. Supports content-hash-based deduplication.
    """
    id: str
    owner_id: str
    name: str
    source_type: str
    source_uri: Optional[str] = None
    source_hash: Optional[str] = None
    embedding_model_id: Optional[str] = None
    builder_prompt_ver: Optional[str] = None
    supersedes_id: Optional[str] = None
    node_count: int = 0
    edge_count: int = 0
    last_indexed: Optional[str] = None
    index_config: Optional[str] = None
    status: str = 'building'
    created_at: Optional[str] = None


@dataclass
class BrainGraphNode:
    """A single node in a brain graph — a chunk of structured knowledge.

    Nodes can be hierarchical (depth > 0, parent_id set) to represent
    document structure like sections → subsections → paragraphs.
    """
    id: str
    graph_id: str
    node_type: str
    label: str
    content: Optional[str] = None
    compact_repr: Optional[str] = None
    depth: int = 0
    parent_id: Optional[str] = None
    metadata_json: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class BrainGraphEdge:
    """A directed relationship between two brain graph nodes.

    Edges encode relationships like "references", "depends_on", "contradicts",
    "elaborates" between knowledge nodes.
    """
    id: str
    graph_id: str
    source_id: str
    target_id: str
    edge_type: str
    weight: float = 1.0
    metadata_json: Optional[str] = None
    created_at: Optional[str] = None
