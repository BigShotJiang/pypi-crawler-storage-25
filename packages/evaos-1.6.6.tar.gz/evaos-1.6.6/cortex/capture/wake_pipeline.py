"""
cortex/capture/wake_pipeline.py — Extraction pipeline orchestration.

Contains the core logic for the remember() pipeline steps 1-4:
  1. Extraction       — LLM-based claim extraction from conversation
  2. Dedup            — exact/near-duplicate filtering
  3. Entity resolution — resolve entity mentions to canonical IDs
  4. Reconciliation   — merge/supersede existing claims in storage
  4b. Activation      — derive + persist activation policy per stored claim (W3, #358)
  + Embedding         — compute and store vector embeddings for new claims

Also owns the Telegram/OpenClaw transport metadata stripping helpers that
are applied to conversation input before extraction.

Used by: CortexPlugin.remember()
"""
from __future__ import annotations

import json
import logging
import re
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

try:
    import sentry_sdk
except ImportError:  # pragma: no cover
    sentry_sdk = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Transport metadata stripping (Telegram/OpenClaw preamble removal)
# ---------------------------------------------------------------------------

# Telegram/OpenClaw transport metadata preamble patterns.
_TELEGRAM_META_FENCE_RE = re.compile(
    r"(?is)^\s*sender\s*\(untrusted\s+metadata\)\s*:\s*```(?:json)?\s*.*?```\s*"
)
_TELEGRAM_META_JSON_RE = re.compile(
    r"(?is)^\s*```(?:json)?\s*\{(?:(?!```)[\s\S])*?\b(?:chat_id|sender|message_id|inbound_meta)\b(?:(?!```)[\s\S])*?\}\s*```\s*"
)


def _contains_telegram_meta_keys(value: Any) -> bool:
    keys = {"chat_id", "sender", "message_id", "inbound_meta"}
    if isinstance(value, dict):
        if keys.intersection(value.keys()):
            return True
        return any(_contains_telegram_meta_keys(v) for v in value.values())
    if isinstance(value, list):
        return any(_contains_telegram_meta_keys(v) for v in value)
    return False


def strip_transport_metadata_text(text: str) -> str:
    """Strip known Telegram/OpenClaw metadata preambles from message text."""
    if not text:
        return text

    cleaned = text
    for _ in range(3):  # allow stacked metadata blocks
        prev = cleaned
        cleaned = _TELEGRAM_META_FENCE_RE.sub("", cleaned, count=1)
        cleaned = _TELEGRAM_META_JSON_RE.sub("", cleaned, count=1)

        # Handle raw JSON metadata object at the start (non-fenced).
        stripped = cleaned.lstrip()
        leading_ws = len(cleaned) - len(stripped)
        if stripped.startswith("{"):
            try:
                obj, end_idx = json.JSONDecoder().raw_decode(stripped)
                if isinstance(obj, dict) and _contains_telegram_meta_keys(obj):
                    cleaned = cleaned[:leading_ws] + stripped[end_idx:]
            except Exception as exc:
                logger.debug("Wake pipeline metadata parse skipped: %s", exc)

        if cleaned == prev:
            break

    return cleaned.strip()


def strip_transport_metadata_conversation(
    conversation: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Return conversation with metadata preambles stripped from string content."""
    cleaned_messages: List[Dict[str, Any]] = []
    for msg in conversation:
        if not isinstance(msg, dict):
            cleaned_messages.append(msg)
            continue
        msg_copy = dict(msg)
        content = msg_copy.get("content")
        if isinstance(content, str):
            msg_copy["content"] = strip_transport_metadata_text(content)
        cleaned_messages.append(msg_copy)
    return cleaned_messages


# ---------------------------------------------------------------------------
# Internal content classifier (issue #866)
# ---------------------------------------------------------------------------

# Patterns that identify internal/system content that should NOT be extracted.
# These are injected by the engine and have no user-authored memory signal.
_INTERNAL_CONTENT_PATTERNS = re.compile(
    r"(?i)(?:"
    r"<relevant-memories>"                              # already-injected memory blocks
    r"|\[Internal task completion event\]"              # subagent completion reports
    r"|<<<BEGIN_UNTRUSTED_CHILD_RESULT>>>"              # child result wrapper
    r"|<<<END_UNTRUSTED_CHILD_RESULT>>>"                # child result wrapper
    r"|OpenClaw runtime context \(internal\)"           # engine runtime context
    r"|##\s*Inbound Context \(trusted metadata\)"       # metadata blocks
    r"|##\s*Runtime\s*(?:context|generated|metadata)\b" # runtime config blocks (specific)
    r"|session_key:\s*agent:"                           # session metadata keys
    r"|type:\s*subagent[\s_]task"                       # subagent task type markers
    r"|\[\[reply_to"                                    # internal reply-to control tags
    r"|\[Internal\s+(?:task|context|system)\b"          # specific [Internal ...] markers
    r"|^\s*System:"                                     # messages starting with "System:" (with optional leading whitespace)
    r")"
    r"|(?:HEARTBEAT)",                                  # heartbeat messages (case-SENSITIVE, separate)
    re.IGNORECASE,                                      # (?i) applies to the first group only — see below
)

# NOTE: The regex above uses a single compiled pattern with re.IGNORECASE.
# HEARTBEAT is in a separate alternation group but re.IGNORECASE applies to
# the whole pattern.  We need HEARTBEAT to be case-sensitive, so we use a
# two-pattern approach instead.

# Replace the single-pattern approach with two patterns:
# 1. Case-insensitive patterns (most internal content markers)
# 2. Case-sensitive patterns (HEARTBEAT)
del _INTERNAL_CONTENT_PATTERNS  # remove the broken attempt above

_INTERNAL_CONTENT_PATTERNS_CI = re.compile(
    r"(?:"
    r"<relevant-memories>"                              # already-injected memory blocks
    r"|\[Internal task completion event\]"              # subagent completion reports
    r"|<<<BEGIN_UNTRUSTED_CHILD_RESULT>>>"              # child result wrapper
    r"|<<<END_UNTRUSTED_CHILD_RESULT>>>"                # child result wrapper
    r"|OpenClaw runtime context \(internal\)"           # engine runtime context
    r"|##\s*Inbound Context \(trusted metadata\)"       # metadata blocks
    r"|##\s*Runtime\s+(?:context|generated|metadata)\b" # runtime config blocks (specific)
    r"|session_key:\s*agent:"                           # session metadata keys
    r"|type:\s*subagent[\s_]task"                       # subagent task type markers
    r"|\[\[reply_to"                                    # internal reply-to control tags
    r"|\[Internal\s+(?:task|context|system)\b"          # specific [Internal ...] markers
    r"|^\s*System:"                                     # messages starting with "System:" (with optional leading whitespace)
    r")",
    re.IGNORECASE,
)

_INTERNAL_CONTENT_PATTERNS_CS = re.compile(
    r"HEARTBEAT"                                        # heartbeat messages (case-sensitive)
)


def is_internal_content(message: str) -> bool:
    """Return True if *message* is internal/system content that should not be extracted.

    Detects engine-injected blocks (runtime context, memory injections, subagent
    completion reports, heartbeats, child-result wrappers) that produce garbage
    memory claims like "Eva ran a tool" or "Session started".

    Args:
        message: Raw string content of a conversation message.

    Returns:
        True if the message matches a known internal content pattern,
        False if the message appears to be genuine user/assistant content.
    """
    if not message or not isinstance(message, str):
        return False
    return bool(
        _INTERNAL_CONTENT_PATTERNS_CI.search(message)
        or _INTERNAL_CONTENT_PATTERNS_CS.search(message)
    )


def filter_internal_content_conversation(
    conversation: List[Dict[str, Any]],
    block_internal: bool = True,
) -> tuple[List[Dict[str, Any]], int]:
    """Filter internal/system messages from a conversation before extraction.

    Args:
        conversation:    List of message dicts with at least ``role`` and ``content``.
        block_internal:  When False, returns conversation unchanged (config toggle).

    Returns:
        Tuple of (filtered_conversation, skipped_count).
        ``skipped_count`` is the number of messages removed.
    """
    if not block_internal:
        return conversation, 0

    filtered: List[Dict[str, Any]] = []
    skipped = 0
    for msg in conversation:
        if not isinstance(msg, dict):
            filtered.append(msg)
            continue
        content = msg.get("content")
        if isinstance(content, str) and is_internal_content(content):
            logger.debug(
                "Skipping extraction for internal/system message (role=%s, len=%d): %.120s…",
                msg.get("role", "unknown"),
                len(content),
                content.replace("\n", " "),
            )
            skipped += 1
        else:
            filtered.append(msg)
    return filtered, skipped


def conversation_has_signal(conversation: List[Dict[str, Any]]) -> bool:
    """Heuristic: conversation has at least one non-empty text message."""
    for msg in conversation:
        if not isinstance(msg, dict):
            continue
        content = msg.get("content")
        if isinstance(content, str) and content.strip():
            return True
    return False


# ---------------------------------------------------------------------------
# Config helper (duplicated from plugin.py to avoid circular imports)
# ---------------------------------------------------------------------------

def _config_int(config: Any, key: str, default: int) -> int:
    """Read integer config safely, avoiding MagicMock/non-numeric fallthrough."""
    value = getattr(config, key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# Outcome dataclass
# ---------------------------------------------------------------------------

@dataclass
class ExtractionOutcome:
    """Result returned by run_extraction() to CortexPlugin.remember()."""

    claims_extracted: int = 0
    claims_stored: int = 0
    entities_resolved: int = 0
    noise_filtered: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    zero_claim_warning: bool = False
    ok: bool = True
    #: Updated counter to write back to plugin._zero_claim_outcomes
    updated_zero_claim_outcomes: int = 0


# ---------------------------------------------------------------------------
# Metadata normalization helper
# ---------------------------------------------------------------------------

def _normalize_metadata(raw_meta: Any) -> dict:
    """Ensure metadata is a dict; reset non-dict values to empty dict.

    Used during provenance stamping and candidate carry-through to prevent
    non-dict metadata from propagating downstream.
    """
    if isinstance(raw_meta, dict):
        return raw_meta
    if raw_meta is not None:
        logger.warning("Non-dict metadata on candidate, resetting: %s", type(raw_meta))
    return {}


# ---------------------------------------------------------------------------
# Main extraction pipeline function
# ---------------------------------------------------------------------------

async def run_extraction(
    *,
    extractor: Any,
    storage: Any,
    llm: Any,
    entity_resolver: Any,
    cornerstone_guardian: Any,
    reconciler: Any,
    event_emitter: Any,
    config: Any,
    extraction_semaphore: Any,
    conversation: List[Dict[str, Any]],
    sid: str,
    db_session_pk: Optional[str],
    effective_owner_id: str,
    episode_event_id: Optional[str],
    budget_check: Callable[[int], Optional[str]],
    budget_consume: Callable[[int], None],
    errors: List[str],
    warnings: List[str],
    zero_claim_outcomes: int,
    session_date: Optional[str] = None,
    speaker_a: Optional[str] = None,
    speaker_b: Optional[str] = None,
    source_session_id: Optional[str] = None,
    source_message_id: Optional[str] = None,
    source_channel: Optional[str] = None,
    source_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    entity_type: Optional[str] = None,
    source_agent: Optional[str] = None,
) -> ExtractionOutcome:
    """Run the extraction → dedup → entity resolution → reconcile → embed pipeline.

    This function encapsulates remember() steps 1-4.  All external mutations
    (storage writes, event emits) happen inside here; the caller only needs to
    handle the session setup (step 0) and result assembly.

    Args:
        extractor:           ExtractionPipeline (may be None → error recorded).
        storage:             StorageAdapter.
        llm:                 LLMProvider for embedding.
        entity_resolver:     EntityResolver (may be None → skipped).
        cornerstone_guardian: CornerstoneGuardian (may be None → skipped).
        reconciler:          ReconciliationEngine (may be None → error recorded).
        event_emitter:       EventEmitter for MEMORY_CREATED/UPDATED events.
        config:              CortexConfig.
        extraction_semaphore: asyncio.Semaphore for concurrency cap.
        conversation:        Cleaned/stripped conversation list.
        sid:                 Human-readable session ID.
        db_session_pk:       Internal DB PK of the session_record row (for FK).
        effective_owner_id:  Memory owner namespace.
        episode_event_id:    ID of the already-logged episode event (for provenance).
        budget_check:        Callable(n) → Optional[error_str].
        budget_consume:      Callable(n) → None.
        errors:              Mutable error list (pre-populated by caller).
        warnings:            Mutable warning list (pre-populated by caller).
        zero_claim_outcomes: Current zero-claim counter from plugin state.

    Returns:
        ExtractionOutcome with all counts and updated state.
    """
    # ---- Sentry extraction span -------------------------------------------
    _sentry_ext_span = None
    if sentry_sdk is not None:
        try:
            _sentry_ext_span = sentry_sdk.start_span(
                op="cortex.extraction",
                description=f"remember pipeline for {effective_owner_id}",
            )
            _sentry_ext_span.set_tag("owner_id", effective_owner_id)
            _sentry_ext_span.set_tag("session_id", sid)
        except Exception:  # pragma: no cover
            _sentry_ext_span = None

    claims_extracted = 0
    claims_stored = 0
    entities_resolved = 0
    noise_filtered = 0
    zero_claim_warning = False

    # 1. Extraction -----------------------------------------------------------
    extraction_result = None
    if extractor is None:
        err = "ExtractionPipeline not available — skipping extraction"
        logger.warning(err)
        errors.append(err)
    else:
        budget_err = budget_check(1)
        if budget_err:
            logger.error("Skipping extraction: %s", budget_err)
            errors.append(budget_err)
            return ExtractionOutcome(
                claims_extracted=0,
                claims_stored=0,
                entities_resolved=0,
                noise_filtered=noise_filtered,
                errors=errors,
                warnings=warnings,
                zero_claim_warning=False,
                ok=False,
                updated_zero_claim_outcomes=zero_claim_outcomes,
            )
        try:
            budget_consume(1)
            async with extraction_semaphore:
                extraction_result = await extractor.extract(
                    conversation,
                    session_id=sid,
                    session_date=session_date,
                    speaker_a=speaker_a,
                    speaker_b=speaker_b,
                )
            claims_extracted = len(extraction_result.claims)
            noise_filtered = extraction_result.noise_filtered
            logger.debug(
                "Extracted %d claims (noise filtered: %d)",
                claims_extracted,
                noise_filtered,
            )
        except Exception as exc:
            err = f"Extraction failed: {exc}"
            logger.error(err, exc_info=True)
            errors.append(err)

    if extraction_result is None or not extraction_result.claims:
        if extraction_result is not None and conversation_has_signal(conversation) and not errors:
            zero_claim_outcomes += 1
            zero_claim_warning = True
            # Build message preview from first non-empty content in conversation
            _preview = ""
            for _msg in conversation:
                if isinstance(_msg, dict):
                    _content = _msg.get("content")
                    if isinstance(_content, str) and _content.strip():
                        _preview = _content.strip()[:120]
                        break
            msg = (
                "Extraction produced zero claims for a valid non-empty input "
                f"(count={zero_claim_outcomes})"
            )
            warnings.append(msg)
            # Log at configurable level (default INFO)
            _log_level = getattr(config, "extraction_zero_claim_log_level", "INFO").upper()
            _log_dispatch: Dict[str, Callable[..., Any]] = {
                "DEBUG": logger.debug,
                "INFO": logger.info,
                "WARNING": logger.warning,
                "ERROR": logger.error,
                "CRITICAL": logger.critical,
            }
            if _log_level not in _log_dispatch:
                logger.warning(
                    "Invalid extraction_zero_claim_log_level=%r, defaulting to INFO",
                    _log_level,
                )
                _log_level = "INFO"
            _log_fn = _log_dispatch[_log_level]
            # B-ZC1: Only include preview when explicitly enabled (PII protection)
            _show_preview = getattr(config, "extraction_zero_claim_log_preview", False)
            if _show_preview:
                _log_fn(
                    "session=%s %s | noise_filtered=%d | preview=%r",
                    sid,
                    msg,
                    noise_filtered,
                    _preview,
                )
            else:
                _log_fn(
                    "session=%s %s | noise_filtered=%d | msg_count=%d | content_len=%d",
                    sid,
                    msg,
                    noise_filtered,
                    len(conversation),
                    sum(len(_m.get("content", "")) for _m in conversation if isinstance(_m, dict)),
                )
        return ExtractionOutcome(
            claims_extracted=claims_extracted,
            claims_stored=0,
            entities_resolved=0,
            noise_filtered=noise_filtered,
            errors=errors,
            warnings=warnings,
            zero_claim_warning=zero_claim_warning,
            ok=not errors,
            updated_zero_claim_outcomes=zero_claim_outcomes,
        )

    # 1a-post. Stamp episode_event_id on each candidate ----------------------
    if episode_event_id is not None:
        for _cand in extraction_result.claims:
            try:
                object.__setattr__(_cand, "episode_event_id", episode_event_id)
            except (TypeError, AttributeError):
                _cand.episode_event_id = episode_event_id  # type: ignore[attr-defined]

    # 1a-post-2. Stamp provenance metadata on each candidate (issue #748) -----
    if source_session_id or source_message_id or source_channel or source_type:
        _provenance = {}
        if source_session_id:
            _provenance["source_session_id"] = source_session_id
        if source_message_id:
            _provenance["source_message_id"] = source_message_id
        if source_channel:
            _provenance["source_channel"] = source_channel
        if source_type:
            _provenance["source_type"] = source_type
        for _cand in extraction_result.claims:
            # Merge provenance into claim metadata (CandidateClaim has metadata field,
            # ClaimExtraction doesn't — use setattr for the latter).
            existing_meta = getattr(_cand, "metadata", None) or {}
            merged = {**existing_meta, **_provenance}
            try:
                object.__setattr__(_cand, "metadata", merged)
            except (TypeError, AttributeError):
                _cand.metadata = merged  # type: ignore[attr-defined]

    # 1a-post-3. Stamp entity scoping on each candidate (#923) ----------------
    if entity_id:
        for _cand in extraction_result.claims:
            try:
                object.__setattr__(_cand, "scope_entity_id", entity_id)
            except (TypeError, AttributeError):
                _cand.scope_entity_id = entity_id  # type: ignore[attr-defined]
    if entity_type:
        for _cand in extraction_result.claims:
            try:
                object.__setattr__(_cand, "scope_entity_type", entity_type)
            except (TypeError, AttributeError):
                _cand.scope_entity_type = entity_type  # type: ignore[attr-defined]

    # 1a-post-4. Stamp source_agent on each candidate (#1396) -----------------
    if source_agent:
        for _cand in extraction_result.claims:
            try:
                object.__setattr__(_cand, "source_agent", source_agent)
            except (TypeError, AttributeError):
                _cand.source_agent = source_agent  # type: ignore[attr-defined]

    # 1b. Per-batch extraction cap -------------------------------------------
    batch_limit = _config_int(
        config,
        "max_claims_per_extraction",
        _config_int(config, "max_extraction_calls_per_batch", 25),
    )
    if batch_limit > 0 and len(extraction_result.claims) > batch_limit:
        _SENSITIVITY_PRIORITY = {"sensitive": 0, "personal": 1, "normal": 2}
        extraction_result.claims.sort(
            key=lambda c: _SENSITIVITY_PRIORITY.get(
                getattr(c, "sensitivity", "normal"), 2
            )
        )
        dropped = len(extraction_result.claims) - batch_limit
        logger.warning(
            "Capping extraction batch: %d claims → %d "
            "(max_claims_per_extraction=%d, dropped %d, sensitive-first sort applied)",
            len(extraction_result.claims),
            batch_limit,
            batch_limit,
            dropped,
        )
        extraction_result.claims = extraction_result.claims[:batch_limit]

    # 1c. Extraction-time deduplication --------------------------------------
    if extraction_result.claims and storage is not None:
        try:
            from cortex.extraction.dedup import deduplicate_claims
            dedup_result = await deduplicate_claims(
                storage=storage,
                new_claims=extraction_result.claims,
                owner_id=effective_owner_id,
                threshold=0.85,
            )
            for nc, ec in dedup_result.to_merge:
                try:
                    new_confidence = min(1.0, ec.confidence + nc.confidence * 0.1)
                    new_mentions = getattr(ec, "mentions", 1) + 1
                    now_iso = datetime.now(timezone.utc).isoformat()
                    await storage.update_claim(
                        ec.id,
                        confidence=new_confidence,
                        mentions=new_mentions,
                        last_mentioned_at=now_iso,
                    )
                    logger.debug(
                        "dedup merge: updated claim id=%s confidence %.2f → %.2f mentions=%d",
                        ec.id,
                        ec.confidence,
                        new_confidence,
                        new_mentions,
                    )
                except Exception as merge_exc:
                    logger.warning(
                        "dedup: failed to update merged claim id=%s: %s",
                        ec.id,
                        merge_exc,
                    )
            if dedup_result.total_deduped > 0:
                logger.info(
                    "Extraction dedup: %d skipped (exact), %d merged (similar), %d new",
                    len(dedup_result.skipped),
                    len(dedup_result.to_merge),
                    len(dedup_result.to_store),
                )
            extraction_result.claims = dedup_result.to_store
        except Exception as dedup_exc:
            logger.warning(
                "Extraction dedup failed (non-fatal) — proceeding with all claims: %s",
                dedup_exc,
            )

    if not extraction_result.claims:
        return ExtractionOutcome(
            claims_extracted=claims_extracted,
            claims_stored=0,
            entities_resolved=0,
            noise_filtered=noise_filtered,
            errors=errors,
            warnings=warnings,
            zero_claim_warning=zero_claim_warning,
            ok=not errors,
            updated_zero_claim_outcomes=zero_claim_outcomes,
        )

    # 2. Entity resolution ---------------------------------------------------
    resolved_claims = extraction_result.claims
    if entity_resolver is None:
        logger.warning("EntityResolver not available — skipping entity resolution")
        errors.append("EntityResolver not available")
    else:
        resolved_count = 0
        for claim in extraction_result.claims:
            # Track the first resolved entity for this claim's subject to use
            # as scope_entity_id (links claim → canonical entity).
            _subject_entity_id: Optional[str] = None
            _claim_subject = unicodedata.normalize("NFC", getattr(claim, "subject", "")).casefold()

            for mention in getattr(claim, "entities_mentioned", []):
                try:
                    entity = await entity_resolver.resolve(
                        mention=mention.name,
                        owner_id=effective_owner_id,
                        entity_type=getattr(mention, "entity_type", "unknown"),
                    )
                    resolved_count += 1

                    # Link resolved entity to claim when the mention matches
                    # the claim subject (case-insensitive).  This pre-populates
                    # scope_entity_id so the reconciliation engine can skip
                    # a redundant resolve() call.
                    if (
                        entity is not None
                        and _subject_entity_id is None
                        and unicodedata.normalize("NFC", mention.name).casefold() == _claim_subject
                    ):
                        _subject_entity_id = getattr(entity, "entity_id", None)

                    if event_emitter is not None and entity is not None:
                        try:
                            from cortex.events.emitter import CortexEvent, EventType
                            await event_emitter.emit(CortexEvent(
                                event_type=EventType.ENTITY_CREATED,
                                owner_id=effective_owner_id,
                                payload={
                                    "entity_id": getattr(entity, "id", str(entity)),
                                    "entity_name": mention.name,
                                },
                                session_id=sid,
                            ))
                        except Exception as emit_exc:
                            logger.debug("Event emit failed (ENTITY_CREATED): %s", emit_exc)
                except Exception as exc:
                    err = f"Entity resolution failed for '{mention.name}': {exc}"
                    logger.warning(err)
                    errors.append(err)

            # Stamp scope_entity_id on the claim so the ClaimExtraction →
            # CandidateClaim conversion (step 2d) can carry it through.
            if _subject_entity_id is not None:
                try:
                    claim.scope_entity_id = _subject_entity_id  # type: ignore[attr-defined]
                except AttributeError:
                    logger.debug("scope_entity_id: claim %r is immutable, reconciler will re-resolve", getattr(claim, "subject", "?"))

        entities_resolved = resolved_count

    # 2b. Peer auto-create ---------------------------------------------------
    if storage is not None and entity_resolver is not None:
        try:
            from cortex.peers import PeerManager
            peer_mgr = PeerManager(
                storage=storage,
                entity_resolver=entity_resolver,
            )
            if hasattr(storage, "list_entities"):
                all_entities = await storage.list_entities(
                    owner_id=effective_owner_id,
                    entity_type="person",
                    limit=500,
                )
                await peer_mgr.auto_create_from_entities(
                    owner_id=effective_owner_id,
                    entities=all_entities,
                )
        except Exception as exc:
            logger.warning("Peer auto-create failed (non-fatal): %s", exc)

    # 2c. Cornerstone coherence check (#722) ---------------------------------
    # For high-salience candidates, check against cornerstones in ranked order
    # and ANNOTATE (not drop) with coherence_flags listing conflicting IDs.
    # Low-salience candidates bypass the check entirely (performance guard).
    if cornerstone_guardian is not None and resolved_claims:
        try:
            _all_cornerstones = await cornerstone_guardian.get_all(
                owner_id=effective_owner_id,
            )
        except Exception as _cs_load_exc:
            logger.warning(
                "Failed to load cornerstones for coherence check: %s", _cs_load_exc,
            )
            _all_cornerstones = []

        if _all_cornerstones:
            for _cand in resolved_claims:
                _salience = getattr(_cand, "salience", "medium")
                if _salience != "high":
                    continue  # skip low/medium — performance guard

                _subject = getattr(_cand, "subject", "")
                _subject_lower = _subject.lower()
                _flags: list[str] = []

                # Check each cornerstone in injection_order (ranked)
                for _cs in _all_cornerstones:
                    if (
                        _subject_lower in _cs.label.lower()
                        or _subject_lower in _cs.content.lower()
                    ):
                        _flags.append(_cs.id)

                if _flags:
                    # Annotate — do NOT drop the candidate
                    _cand._coherence_flags = _flags  # type: ignore[attr-defined]
                    logger.info(
                        "Coherence check: candidate (subject=%r) touches %d "
                        "cornerstone(s) %s — annotated, not dropped",
                        _subject, len(_flags), _flags,
                    )

    # 2d. Convert ClaimExtraction -> CandidateClaim (formalise type contract) --
    # ClaimExtraction is the M2 output type; CandidateClaim is the M4 input
    # contract.  Converting here (after entity resolution, before reconciliation)
    # ensures entity resolution operates on ClaimExtraction objects which have
    # entities_mentioned, while reconciliation receives properly-typed
    # CandidateClaim objects rather than duck-typed instances.
    from cortex.extraction.extractor import ClaimExtraction as _ClaimExtraction
    _candidate_claims = []
    for _raw_claim in resolved_claims:
        if isinstance(_raw_claim, _ClaimExtraction):
            _cand = _raw_claim.to_candidate()
            # Carry through any dynamically-stamped attributes (e.g.
            # episode_event_id set by step 1a-post).  These don't exist
            # on the ClaimExtraction dataclass definition but are set via
            # object.__setattr__() earlier in this pipeline.
            _episode_id = getattr(_raw_claim, "episode_event_id", None)
            if _episode_id is not None:
                _cand.episode_event_id = _episode_id  # type: ignore[attr-defined]
            # Carry through provenance metadata (issue #748)
            _meta = _normalize_metadata(getattr(_raw_claim, "metadata", None))
            if _meta:
                _cand.metadata = _meta
            # Carry through coherence flags (#722)
            _coh_flags = getattr(_raw_claim, "_coherence_flags", None)
            if _coh_flags:
                _cand.coherence_flags = _coh_flags
            # Carry through scope_entity_id from entity resolution (step 2)
            _scope_eid = getattr(_raw_claim, "scope_entity_id", None)
            if _scope_eid:
                _cand.scope_entity_id = _scope_eid
            _candidate_claims.append(_cand)
        else:
            # Already a CandidateClaim (e.g., from tests or direct API callers)
            _candidate_claims.append(_raw_claim)
    resolved_claims = _candidate_claims  # type: ignore[assignment]

    # 3. Reconciliation (writes to storage) ----------------------------------
    reconciliation_report = None
    if reconciler is None:
        err = "ReconciliationEngine not available — memories NOT stored"
        logger.error(err)
        errors.append(err)
    else:
        reconcile_calls = len(resolved_claims)
        budget_err = budget_check(reconcile_calls)
        if budget_err:
            logger.error("Skipping reconciliation: %s", budget_err)
            errors.append(budget_err)
        else:
            budget_consume(reconcile_calls)
            try:
                _reconcile_session_id = db_session_pk
                if not _reconcile_session_id:
                    logger.warning(
                        "db_session_pk is None; falling back to sid=%s for "
                        "reconciliation session_id — claims may store an "
                        "inconsistent key (string UUID instead of hex PK)",
                        sid,
                    )
                    _reconcile_session_id = sid
                reconciliation_report = await reconciler.reconcile(
                    candidates=resolved_claims,
                    owner_id=effective_owner_id,
                    session_id=_reconcile_session_id,
                )
                claims_stored = sum(
                    1 for r in reconciliation_report.results
                    if r.action.value in ("ADD", "UPDATE", "SUPERSEDE")
                )
                logger.debug(
                    "Reconciled: %d stored, %d total results",
                    claims_stored,
                    len(reconciliation_report.results),
                )
                # Emit memory events
                if event_emitter is not None:
                    try:
                        from cortex.events.emitter import CortexEvent, EventType
                        for r in reconciliation_report.results:
                            action_val = r.action.value
                            claim_id = getattr(r, "resulting_claim_id", None)
                            if action_val == "ADD" and claim_id:
                                await event_emitter.emit(CortexEvent(
                                    event_type=EventType.MEMORY_CREATED,
                                    owner_id=effective_owner_id,
                                    payload={
                                        "claim_id": claim_id,
                                        "subject": getattr(r, "subject", ""),
                                        "predicate": getattr(r, "predicate", ""),
                                    },
                                    session_id=sid,
                                ))
                            elif action_val in ("UPDATE", "SUPERSEDE") and claim_id:
                                await event_emitter.emit(CortexEvent(
                                    event_type=EventType.MEMORY_UPDATED,
                                    owner_id=effective_owner_id,
                                    payload={
                                        "claim_id": claim_id,
                                        "action": action_val.lower(),
                                        "subject": getattr(r, "subject", ""),
                                        "predicate": getattr(r, "predicate", ""),
                                    },
                                    session_id=sid,
                                ))
                    except Exception as emit_exc:
                        logger.debug("Event emit failed (memory events): %s", emit_exc)
            except Exception as exc:
                err = f"Reconciliation failed: {exc}"
                logger.error(err, exc_info=True)
                errors.append(err)

    # 4b. Activation routing — derive + persist activation policy per stored claim
    if storage is not None and reconciliation_report is not None:
        try:
            from cortex.capture.activation_router import ActivationRouter
            _activation_router = ActivationRouter()
            # Build a fast lookup: resulting_claim_id → candidate claim
            _claim_to_candidate: dict = {}
            for _idx, _cand in enumerate(resolved_claims):
                # Match by position in the results list (reconciliation preserves order).
                if _idx < len(reconciliation_report.results):
                    _res = reconciliation_report.results[_idx]
                    _cid = getattr(_res, "resulting_claim_id", None)
                    if _cid:
                        _claim_to_candidate[_cid] = _cand

            _activation_ok = 0
            _activation_fail = 0
            for _result in reconciliation_report.results:
                if _result.action.value not in ("ADD", "UPDATE", "SUPERSEDE"):
                    continue
                _claim_id = getattr(_result, "resulting_claim_id", None)
                if not _claim_id:
                    continue
                _cand = _claim_to_candidate.get(_claim_id)
                if _cand is None:
                    # Fallback: derive with minimal envelope (safe defaults)
                    _cand = type("_Empty", (), {})()
                _policy = _activation_router.derive(
                    candidate=_cand,
                    claim_id=_claim_id,
                    owner_id=effective_owner_id,
                )
                _written = await _activation_router.write(storage, _policy)
                if _written:
                    _activation_ok += 1
                else:
                    _activation_fail += 1

            if _activation_ok or _activation_fail:
                logger.debug(
                    "session=%s activation routing: written=%d skipped=%d",
                    sid,
                    _activation_ok,
                    _activation_fail,
                )
        except Exception as _act_exc:
            # Activation routing is non-fatal: never block the remember() path.
            logger.warning(
                "session=%s activation routing failed (non-fatal): %s",
                sid,
                _act_exc,
            )

    # 4c. Embed stored claims for vector retrieval ---------------------------
    if storage is not None and llm is not None and reconciliation_report is not None:
        embed_model = config.embedding_model
        _new_claims = [
            r for r in reconciliation_report.results
            if r.action.value in ("ADD", "UPDATE", "SUPERSEDE")
            and getattr(r, "resulting_claim_id", None)
        ]
        _sentry_embed_span = None
        if sentry_sdk is not None:
            try:
                _sentry_embed_span = sentry_sdk.start_span(
                    op="cortex.embedding",
                    description=f"embed {len(_new_claims)} claims",
                )
                _sentry_embed_span.set_data("model", embed_model)
                _sentry_embed_span.set_data("claim_count", len(_new_claims))
            except Exception:  # pragma: no cover
                _sentry_embed_span = None

        for result in reconciliation_report.results:
            if result.action.value not in ("ADD", "UPDATE", "SUPERSEDE"):
                continue
            claim_id = getattr(result, "resulting_claim_id", None)
            if not claim_id:
                continue
            try:
                stored_claim = await storage.get_claim(claim_id)
                if stored_claim is None:
                    continue
                embed_text = (
                    f"{stored_claim.subject} "
                    f"{stored_claim.predicate} "
                    f"{stored_claim.object_value}"
                )
                embed_response = await llm.embed(
                    texts=[embed_text],
                    input_type="document",
                )
                if embed_response and embed_response.embeddings:
                    vector = embed_response.embeddings[0]
                    await storage.store_embedding(
                        item_type="claim",
                        item_id=claim_id,
                        embedding=vector,
                        model_id=embed_model,
                    )
                    logger.debug("Embedded claim %s (%d dims)", claim_id, len(vector))
            except Exception as exc:
                err = f"Embedding failed for claim {claim_id}: {exc}"
                logger.warning(err)
                errors.append(err)

        if _sentry_embed_span is not None:
            try:
                _sentry_embed_span.finish()
            except Exception:  # pragma: no cover
                pass

    if _sentry_ext_span is not None:
        try:
            _sentry_ext_span.set_data("claims_extracted", claims_extracted)
            _sentry_ext_span.set_data("claims_stored", claims_stored)
            _sentry_ext_span.finish()
        except Exception:  # pragma: no cover
            pass

    return ExtractionOutcome(
        claims_extracted=claims_extracted,
        claims_stored=claims_stored,
        entities_resolved=entities_resolved,
        noise_filtered=noise_filtered,
        errors=errors,
        warnings=warnings,
        zero_claim_warning=zero_claim_warning,
        ok=not any(
            ("not available" in e or "budget exhausted" in e)
            for e in errors
        ),
        updated_zero_claim_outcomes=zero_claim_outcomes,
    )
