"""Cortex configuration — re-exports for backwards compatibility."""
from cortex.config.model import CortexConfig, DEFAULT_EMBEDDING_DIM, _DEFAULTS_PATH
from cortex.config.validation import validate_config, is_full_tier
from cortex.config.utils import _coerce_env_value, _deep_merge

__all__ = [
    "CortexConfig",
    "validate_config",
    "is_full_tier",
    "DEFAULT_EMBEDDING_DIM",
    "_DEFAULTS_PATH",
    "_coerce_env_value",
    "_deep_merge",
]
