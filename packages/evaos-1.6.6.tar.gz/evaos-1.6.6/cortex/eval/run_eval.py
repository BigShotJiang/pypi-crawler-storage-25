"""
cortex/eval/run_eval.py — Unified cortex-eval CLI entry point (#1282).

Supports ALL benchmarks via a single --benchmark flag:
  - locomo:       LoCoMo memory retrieval (default)
  - locomo-full:  Full native LoCoMo format
  - longmemeval:  LongMemEval long-term memory
  - long-mt-bench: Long-MT-Bench+ conversation continuation

Usage::

    python -m cortex.eval.run_eval --benchmark locomo --sample
    python -m cortex.eval.run_eval --benchmark longmemeval --data path/to/data.json
    python -m cortex.eval.run_eval --benchmark long-mt-bench --data conversations.json
    python -m cortex.eval.run_eval --benchmark locomo --mode rag --config cortex.toml
    python -m cortex.eval.run_eval --help

Results are logged to runs.jsonl for comparison across runs.
"""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import logging
import os
import pathlib
import random
import signal
import sys
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

# Isolation: default owner_id prefix for throwaway benchmark runs
_LOCOMO_EVAL_PREFIX = "locomo-eval"

# Supported benchmarks
BENCHMARKS = ["locomo", "locomo-full", "longmemeval", "long-mt-bench"]


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cortex-eval",
        description="Unified Cortex benchmark evaluation CLI (#1282).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Benchmarks:
  locomo          LoCoMo memory retrieval (internal format)
  locomo-full     Full native LoCoMo format (locomo10.json)
  longmemeval     LongMemEval long-term memory
  long-mt-bench   Long-MT-Bench+ conversation continuation (LLM judge, 1-10)

Examples:
  cortex-eval --benchmark locomo --sample
  cortex-eval --benchmark locomo --config cortex.toml --mode rag
  cortex-eval --benchmark longmemeval --data /path/to/data.json --out results.json
  cortex-eval --benchmark long-mt-bench --data conversations.json
  cortex-eval --benchmark locomo-full --sample-id conv-26
  cortex-eval --benchmark locomo --fail-under 0.75
        """,
    )

    # Required
    p.add_argument(
        "--benchmark", "--dataset",
        required=True,
        choices=BENCHMARKS,
        dest="benchmark",
        help="Benchmark to evaluate against.",
    )

    # Data source
    p.add_argument("--config", default=None, help="Path to cortex.toml config file.")
    p.add_argument("--data", default=None, help="Path to dataset JSON file.")
    p.add_argument("--sample", action="store_true", help="Use bundled sample dataset.")
    p.add_argument("--sample-id", default=None, dest="sample_id",
                    help="For locomo-full: load a single conversation by sample_id.")
    p.add_argument("--db-path", default=None, dest="db_path",
                    help="Path to SQLite DB for eval (uses temp file if omitted).")

    # Eval config
    p.add_argument("--mode", default="retrieval-only",
                    choices=["retrieval-only", "rag", "full"],
                    help="Eval mode (default: retrieval-only).")
    p.add_argument("--fuzzy-threshold", type=float, default=0.6, dest="fuzzy_threshold",
                    help="Fuzzy match threshold (default: 0.6).")
    p.add_argument("--llm-judge", action="store_true", dest="llm_judge",
                    help="Enable LLM-as-judge scoring (uses plugin LLM, 0-1 float).")
    p.add_argument("--judge", action="store_true", dest="gemini_judge",
                    help="Enable Gemini LLM-as-judge binary scoring (AMB-compatible).")
    p.add_argument("--judge-model", default=None, dest="judge_model_name",
                    help="Model for Gemini judge (default: gemini-2.5-flash).")
    p.add_argument("--judge-api-key", default=None, dest="judge_api_key",
                    help="API key for Gemini judge (default: GEMINI_API_KEY env var).")
    p.add_argument("--judge-prompt", default=None, dest="judge_prompt",
                    choices=["strict", "locomo"],
                    help="Judge prompt style: 'strict' (default) or 'locomo' (AMB-compatible generous). "
                         "Auto-detected from benchmark name if not specified.")
    p.add_argument("--confidence-threshold", type=float, default=0.3,
                    dest="confidence_threshold",
                    help="Confidence threshold for refusal (#1275, default: 0.3).")
    p.add_argument("--timeout-seconds", type=int, default=1800, dest="timeout_seconds",
                    help="Soft wall-clock timeout in seconds for the eval run (default: 1800).")
    p.add_argument("--max-session-failures", type=int, default=5, dest="max_session_failures",
                    help="Abort after this many consecutive remember() session failures (default: 5).")

    # Output
    p.add_argument("--out", default=None, help="Write full results JSON to this file.")
    p.add_argument("--runs-log", default=None, dest="runs_log",
                    help="Path to runs.jsonl log file (default: eval_runs.jsonl in cwd).")

    # CI integration
    p.add_argument("--fail-under", type=float, default=None, dest="fail_under",
                    help="Exit 1 if fuzzy_match_accuracy < threshold (CI gate).")
    p.add_argument("--baseline", default=None,
                    help="Path to baseline results JSON for comparison.")

    # Isolation (default ON — prevents eval characters leaking into production DB)
    isolation_group = p.add_mutually_exclusive_group()
    isolation_group.add_argument(
        "--isolate",
        action="store_true",
        default=True,
        dest="isolate",
        help=(
            "Use a dedicated throwaway owner_id (locomo-eval-<timestamp>) so benchmark "
            "entities/claims are isolated from production data.  Auto-cleanup runs after "
            "the benchmark completes.  DEFAULT: on."
        ),
    )
    isolation_group.add_argument(
        "--no-isolate",
        action="store_false",
        dest="isolate",
        help=(
            "Disable isolation — benchmark writes to the plugin's default owner_id.  "
            "Use only for debugging; production data may be contaminated."
        ),
    )

    # Safety
    p.add_argument("--force", action="store_true",
                    help="Skip confirmation prompts (e.g. with --no-isolate).")
    p.add_argument("--fail-on-empty", action="store_true", dest="fail_on_empty",
                    help="Abort the run if any conversation ingests zero claims.")

    # Ingestion cost control
    p.add_argument(
        "--full-pipeline",
        action="store_true",
        dest="full_pipeline",
        help=(
            "Preserve the normal reconciliation LLM budget during benchmark ingestion. "
            "By default, eval disables reconciliation LLM adjudication so benchmarks "
            "don't pay extra per-claim costs for ambiguous ingest-time conflicts."
        ),
    )

    # Results tracking (V2)
    p.add_argument("--tag", action="append", default=[], dest="tags",
                    help="Add tag to result (repeatable, e.g. --tag post-fix-1638).")
    p.add_argument("--notes", default="",
                    help="Human-readable note about this run.")
    p.add_argument("--mark-baseline", action="store_true", dest="mark_baseline",
                    help="Tag this run as baseline for delta comparisons.")

    # Verbosity
    p.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging.")

    return p


def _register_temp_db_cleanup(db_path: str) -> None:
    import atexit

    def _cleanup_temp_db(path_str: str) -> None:
        base_path = pathlib.Path(path_str)
        for candidate in (base_path, pathlib.Path(f"{path_str}-wal"), pathlib.Path(f"{path_str}-shm")):
            candidate.unlink(missing_ok=True)

    atexit.register(_cleanup_temp_db, db_path)


def _load_plugin(config_path: Optional[str], db_path: Optional[str] = None) -> Any:
    """Load CortexPlugin from config or create a minimal in-memory instance.

    Fixes #1273: Ensures the plugin has an LLM provider wired for extraction.
    """
    try:
        from cortex.api.plugin import CortexPlugin
    except ImportError as e:
        print(f"ERROR: Could not import CortexPlugin: {e}", file=sys.stderr)
        sys.exit(1)

    explicit_db_path = db_path is not None
    if explicit_db_path:
        logging.info("Using explicit database: %s", db_path)
    else:
        import tempfile

        _tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        db_path = _tmp.name
        _tmp.close()
        _register_temp_db_cleanup(db_path)
        logging.info("Using temporary database: %s", db_path)

    if config_path:
        config_file = pathlib.Path(config_path)
        if not config_file.exists():
            print(f"ERROR: Config file not found: {config_path}", file=sys.stderr)
            sys.exit(1)
        try:
            plugin = CortexPlugin(config_path=config_path, db_path=db_path)
        except Exception as e:
            print(f"ERROR: Failed to init CortexPlugin from config: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        try:
            plugin = CortexPlugin(db_path=db_path)
        except Exception as e:
            print(f"ERROR: Failed to create default CortexPlugin: {e}", file=sys.stderr)
            sys.exit(1)

    if getattr(plugin, "llm", None) is None:
        print(
            "⚠️  WARNING: No LLM provider configured. Extraction will produce 0 claims.\n"
            "   Set GOOGLE_API_KEY, OPENROUTER_API_KEY, or ANTHROPIC_API_KEY,\n"
            "   or provide a --config with [cortex.providers] section.",
            file=sys.stderr,
        )

    return plugin


def _build_llm_judge(plugin: Any) -> Optional[Any]:
    """Build an LLM judge callable from the plugin's LLM provider."""
    try:
        llm = getattr(plugin, "llm", None)
        if llm is None:
            print("WARNING: --llm-judge requested but no LLM configured.", file=sys.stderr)
            return None

        async def _judge_async(question: str, prediction: str, reference: str) -> float:
            prompt = (
                f"Question: {question}\nGold answer: {reference}\n"
                f"System answer: {prediction}\n\n"
                "Score correctness from 0.0 to 1.0. Reply with ONLY a number."
            )
            response = await llm.complete(prompt)
            text = str(response).strip()
            try:
                return max(0.0, min(1.0, float(text)))
            except ValueError:
                return 0.0

        def judge(question: str, prediction: str, reference: str) -> float:
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    import concurrent.futures
                    with concurrent.futures.ThreadPoolExecutor() as ex:
                        future = ex.submit(asyncio.run, _judge_async(question, prediction, reference))
                        return future.result()
                return loop.run_until_complete(_judge_async(question, prediction, reference))
            except Exception:
                return 0.0

        return judge
    except Exception as e:
        print(f"WARNING: LLM judge setup failed: {e}", file=sys.stderr)
        return None




async def _run_preflight(plugin: Any, config_path: Optional[str]) -> None:
    """Fail fast before benchmark execution if core dependencies are unavailable."""
    storage = getattr(plugin, "storage", None)
    if storage is None:
        raise RuntimeError("Preflight failed: plugin.storage is unavailable")

    if getattr(storage, "_conn", None) is None:
        await storage.initialize()

    # Check for embedding capability.  The retrieval pipeline resolves
    # embeddings via storage.embed() → llm.embed() cascade (see
    # cortex/core/retrieval_search.py:embed_text).  The preflight must
    # mirror that resolution order.
    embed = getattr(storage, "embed_text", None) or getattr(storage, "embed", None)
    llm = getattr(plugin, "llm", None)
    llm_embed = getattr(llm, "embed", None) if llm is not None else None

    if embed is not None and callable(embed):
        maybe_embedding = embed("test")
        if asyncio.iscoroutine(maybe_embedding):
            await maybe_embedding
        embeddings_ok = "✓ (storage)"
    elif llm_embed is not None and callable(llm_embed):
        # Mirror the llm.embed(texts=[...]) call the retrieval pipeline uses
        _resp = await llm_embed(texts=["preflight test"])
        if _resp is None:
            raise RuntimeError(
                "Preflight failed: llm.embed() returned None. "
                "Check VOYAGE_API_KEY or embedding provider config."
            )
        embeddings_ok = "✓ (llm)"
    else:
        raise RuntimeError(
            "Preflight failed: no embedding function available. "
            "Eval requires embeddings for retrieval. "
            "Configure an embedding provider in --config or set VOYAGE_API_KEY."
        )
    

    llm_ok = "skipped"
    if config_path:
        llm = getattr(plugin, "llm", None)
        if llm is None:
            raise RuntimeError("Preflight failed: config requires an LLM provider but plugin.llm is unavailable")
        response = await llm.complete(
            system="You are a health-check assistant.",
            user="Reply with OK",
        )
        if not str(response).strip():
            raise RuntimeError("Preflight failed: LLM provider returned an empty response")
        llm_ok = "✓"

    print(f"Preflight OK: storage ✓, embeddings {embeddings_ok}, LLM {llm_ok}", file=sys.stderr)


def _resolve_output_paths(requested_out: Optional[str], benchmark: str) -> tuple[pathlib.Path, pathlib.Path]:
    requested = pathlib.Path(requested_out) if requested_out else pathlib.Path.cwd() / f"{benchmark}.json"
    parent = requested.parent
    parent.mkdir(parents=True, exist_ok=True)
    stem = requested.stem
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = uuid.uuid4().hex[:8]
    output_path = parent / f"{stem}-{timestamp}-{run_id}.json"
    latest_path = parent / "latest.json"
    return output_path, latest_path


def _write_report_json(out_path: str, report: Any, latest_symlink: Optional[pathlib.Path] = None) -> None:
    path = pathlib.Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report.to_dict(), f, indent=2, default=str)
    if latest_symlink is not None:
        latest_symlink.parent.mkdir(parents=True, exist_ok=True)
        with contextlib.suppress(FileNotFoundError):
            latest_symlink.unlink()
        latest_symlink.symlink_to(path.resolve())
        print(f"\nResults written to: {path} (latest: {latest_symlink})")
    else:
        print(f"\nResults written to: {path}")


async def _maybe_await(value: Any) -> Any:
    if asyncio.iscoroutine(value):
        return await value
    return value


async def _run_namespace_canary(plugin: Any) -> None:
    canary_a = "eval-canary-A"
    canary_b = "eval-canary-B"
    canary_session_id = f"eval-canary-{uuid.uuid4().hex[:10]}"
    token = f"namespace-canary-{uuid.uuid4().hex}"
    try:
        await _maybe_await(plugin.remember(
            conversation=[{"role": "user", "content": token}],
            session_id=canary_session_id,
            owner_id=canary_a,
        ))
        result = await _maybe_await(plugin.retrieve(query=token, owner_id=canary_b))
        formatted = str(getattr(result, "formatted_context", "") or "")
        memories = getattr(result, "memories", None) or []
        memory_text = " ".join(str(getattr(mem, "content", mem)) for mem in memories)
        if token in formatted or token in memory_text:
            raise RuntimeError(
                "Namespace canary failed: owner eval-canary-B could see data from eval-canary-A"
            )
    finally:
        await _cleanup_eval_owner(plugin, canary_a, verbose=False)


def _install_signal_handlers(harness: Any, on_signal: asyncio.Event) -> list[signal.Signals]:
    triggered: list[signal.Signals] = []

    def _handle(sig: signal.Signals) -> None:
        if not triggered:
            triggered.append(sig)
        harness.request_shutdown()
        on_signal.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(NotImplementedError, RuntimeError):
            asyncio.get_running_loop().add_signal_handler(sig, _handle, sig)
    return triggered


def _remove_signal_handlers() -> None:
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(NotImplementedError, RuntimeError):
            loop.remove_signal_handler(sig)

def _log_run(
    runs_log: Optional[str],
    benchmark: str,
    metrics: Dict[str, Any],
    config: Dict[str, Any],
    elapsed_sec: float,
) -> None:
    """Append run result to runs.jsonl log file."""
    import datetime
    log_path = pathlib.Path(runs_log or "eval_runs.jsonl")
    entry = {
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "benchmark": benchmark,
        "elapsed_sec": round(elapsed_sec, 1),
        "metrics": metrics,
        "config": config,
    }
    try:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, default=str) + "\n")
    except Exception as exc:
        print(f"WARNING: Failed to write runs log: {exc}", file=sys.stderr)


def _log_run_v2(
    args: argparse.Namespace,
    report: Any,
    plugin: Any,
    elapsed_sec: float,
) -> None:
    """Log run to unified V2 runs_v2.jsonl with full config snapshot."""
    try:
        from cortex.eval.run_logger import RunLogger, snapshot_config

        logger = RunLogger()

        # Get config snapshot from plugin
        config_snapshot = {}
        cfg = getattr(plugin, "config", None)
        if cfg is not None:
            config_snapshot = snapshot_config(cfg)

        # Add eval params to snapshot
        config_snapshot["eval_params"] = {
            "fuzzy_threshold": args.fuzzy_threshold,
            "mode": args.mode,
            "llm_judge": args.llm_judge,
            "gemini_judge": getattr(args, "gemini_judge", False),
            "judge_model": getattr(args, "judge_model_resolved", None) or getattr(args, "judge_model_name", None),
            "judge_prompt": getattr(args, "judge_prompt_resolved", None) or getattr(args, "judge_prompt", None),
            "confidence_threshold": args.confidence_threshold,
            "isolate": getattr(args, "isolate", True),
        }

        # Build scores
        scores = dict(report.metrics) if hasattr(report, "metrics") else {}

        # Build dataset info
        dataset_info = {
            "total_questions": scores.pop("total_questions", None),
            "total_sessions": scores.pop("total_sessions", None),
            "total_claims_extracted": scores.pop("total_claims_extracted", None),
            "total_claims_stored": scores.pop("total_claims_stored", None),
        }
        # Remove None values
        dataset_info = {k: v for k, v in dataset_info.items() if v is not None}

        # Build latency dict from scores
        latency = {}
        for key in ("retrieve_latency", "remember_latency"):
            if key in scores:
                latency[key.replace("_latency", "")] = scores.pop(key)

        # Determine dataset variant
        dataset_variant = "sample"
        if hasattr(args, "sample_id") and args.sample_id:
            dataset_variant = "single-conv"
        elif hasattr(args, "data") and args.data:
            dataset_variant = "full"

        logger.log_run_v2(
            harness="cortex-eval",
            benchmark=args.benchmark,
            scores=scores,
            config_snapshot=config_snapshot,
            dataset_variant=dataset_variant,
            mode=args.mode,
            source="local",
            is_baseline=getattr(args, "mark_baseline", False),
            notes=getattr(args, "notes", ""),
            tags=getattr(args, "tags", None) or None,
            dataset_info=dataset_info if dataset_info else None,
            latency=latency if latency else None,
        )
    except Exception as exc:
        print(f"WARNING: V2 run logging failed: {exc}", file=sys.stderr)


def _compare_baseline(
    baseline_path: str,
    current_metrics: Dict[str, Any],
) -> None:
    """Compare current metrics against a baseline and print diff."""
    try:
        with open(baseline_path, "r") as f:
            baseline = json.load(f)
        base_metrics = baseline.get("metrics", baseline)

        print("\n📊 Baseline comparison:")
        for key in ["exact_match_accuracy", "fuzzy_match_accuracy", "avg_token_f1"]:
            base_val = base_metrics.get(key, 0.0)
            curr_val = current_metrics.get(key, 0.0)
            diff = curr_val - base_val
            arrow = "↑" if diff > 0 else "↓" if diff < 0 else "="
            print(f"  {key}: {base_val:.3f} → {curr_val:.3f} ({arrow} {diff:+.3f})")
    except Exception as exc:
        print(f"WARNING: Baseline comparison failed: {exc}", file=sys.stderr)


async def _cleanup_eval_owner(plugin: Any, owner_id: str, verbose: bool = False) -> None:
    """Delete all claims and entities written under the throwaway eval owner_id.

    Uses bulk SQL in proper FK order so that no eval characters (Sarah Chen
    etc.) leak into production recall results and no FK constraint errors occur.
    """
    storage = getattr(plugin, "storage", None)
    if storage is None:
        if verbose:
            print(f"  ⚠ Cleanup skipped — plugin has no .storage attribute", file=sys.stderr)
        return

    try:
        conn = await storage._get_conn()
        async with storage._write_lock:
            # 1. Collect claim IDs for this owner
            async with conn.execute(
                "SELECT id FROM semantic_claim WHERE owner_id = ?",
                (owner_id,),
            ) as cur:
                claim_rows = await cur.fetchall()
            claim_ids = [r[0] if not hasattr(r, "keys") else r["id"] for r in claim_rows]

            # 2. Collect entity IDs for this owner
            async with conn.execute(
                "SELECT id FROM entity WHERE owner_id = ?",
                (owner_id,),
            ) as cur:
                entity_rows = await cur.fetchall()
            entity_ids = [r[0] if not hasattr(r, "keys") else r["id"] for r in entity_rows]

            # 3. Collect session record IDs for this owner
            async with conn.execute(
                "SELECT id FROM session_record WHERE owner_id = ?",
                (owner_id,),
            ) as cur:
                session_rows = await cur.fetchall()
            session_ids = [r[0] if not hasattr(r, "keys") else r["id"] for r in session_rows]

            if claim_ids:
                ph = ",".join("?" for _ in claim_ids)

                # --- Delete in FK-safe order (children before parents) ---

                # Embeddings: vec_index (virtual table, may not exist)
                if getattr(storage, "_vec_loaded", False):
                    try:
                        await conn.execute(
                            f"DELETE FROM vec_index WHERE item_type = 'claim' AND item_id IN ({ph})",
                            claim_ids,
                        )
                    except Exception:
                        pass  # vec_index may not exist; non-fatal

                # Embeddings: embedding_index
                await conn.execute(
                    f"DELETE FROM embedding_index WHERE item_type = 'claim' AND item_id IN ({ph})",
                    claim_ids,
                )

                # FTS
                await conn.execute(
                    f"DELETE FROM fts_claims WHERE claim_id IN ({ph})",
                    claim_ids,
                )

                # Provenance (FK ON DELETE CASCADE, but be explicit)
                await conn.execute(
                    f"DELETE FROM claim_provenance WHERE claim_id IN ({ph})",
                    claim_ids,
                )

                # Deprecation log
                await conn.execute(
                    f"DELETE FROM deprecation_log WHERE claim_id IN ({ph})",
                    claim_ids,
                )

                # Claim changelog (v6)
                try:
                    await conn.execute(
                        f"DELETE FROM claim_changelog WHERE claim_id IN ({ph})",
                        claim_ids,
                    )
                except Exception:
                    pass  # table may not exist in older schemas

                # Memory activation (v8, ON DELETE CASCADE)
                try:
                    await conn.execute(
                        f"DELETE FROM memory_activation WHERE claim_id IN ({ph})",
                        claim_ids,
                    )
                except Exception:
                    pass

                # Memory evidence (v8, ON DELETE CASCADE)
                try:
                    await conn.execute(
                        f"DELETE FROM memory_evidence WHERE claim_id IN ({ph})",
                        claim_ids,
                    )
                except Exception:
                    pass

                # Open loops / commitments that point at these eval claims
                for table in ("open_loop", "commitment"):
                    try:
                        await conn.execute(
                            f"DELETE FROM {table} WHERE owner_id = ? AND claim_id IN ({ph})",
                            [owner_id] + claim_ids,
                        )
                    except Exception:
                        pass

                # Memory edges referencing these claims
                await conn.execute(
                    f"DELETE FROM memory_edge WHERE (source_type = 'claim' AND source_id IN ({ph})) "
                    f"OR (target_type = 'claim' AND target_id IN ({ph}))",
                    claim_ids + claim_ids,
                )

                # Clear self-referential superseded_by before deleting claims
                await conn.execute(
                    f"UPDATE semantic_claim SET superseded_by = NULL "
                    f"WHERE owner_id = ? AND superseded_by IN ({ph})",
                    [owner_id] + claim_ids,
                )

                # Finally: delete the claims themselves
                await conn.execute(
                    "DELETE FROM semantic_claim WHERE owner_id = ?",
                    (owner_id,),
                )

            # Owner-scoped tables that can accumulate eval debris.
            for table in (
                "extraction_queue",
                "request_log",
                "event_log",
                "webhook",
                "dreams",
                "curiosity_seeds",
                "dream_state",
                "cornerstone_evolution_proposal",
                "contradictions",
                "cornerstone_memory",
                "procedure_memory",
                "brain_graph_index",
                "memory_feedback",
                "handoff_packet",
                "open_loop",
                "commitment",
            ):
                try:
                    await conn.execute(f"DELETE FROM {table} WHERE owner_id = ?", (owner_id,))
                except Exception:
                    pass

            # Session-related tables for this eval owner.
            if session_ids:
                sph = ",".join("?" for _ in session_ids)
                for table, column in (
                    ("episode_event", "session_id"),
                    ("retrieval_log", "session_id"),
                    ("handoff_packet", "session_id"),
                    ("open_loop", "session_id"),
                    ("commitment", "session_id"),
                ):
                    try:
                        await conn.execute(
                            f"DELETE FROM {table} WHERE owner_id = ? OR {column} IN ({sph})",
                            [owner_id] + session_ids,
                        )
                    except Exception:
                        pass

                await conn.execute(
                    f"UPDATE semantic_claim SET source_session = NULL WHERE source_session IN ({sph})",
                    session_ids,
                )

            if entity_ids:
                eph = ",".join("?" for _ in entity_ids)

                # Entity aliases (FK ON DELETE CASCADE, but be explicit)
                await conn.execute(
                    f"DELETE FROM entity_alias WHERE entity_id IN ({eph})",
                    entity_ids,
                )

                # Peer references (v7, may not exist)
                try:
                    await conn.execute(
                        f"DELETE FROM peer WHERE entity_id IN ({eph})",
                        entity_ids,
                    )
                except Exception:
                    pass

                # Entities
                await conn.execute(
                    "DELETE FROM entity WHERE owner_id = ?",
                    (owner_id,),
                )

            if session_ids:
                await conn.execute(
                    "DELETE FROM session_record WHERE owner_id = ?",
                    (owner_id,),
                )

            await conn.commit()

        deleted_claims = len(claim_ids) if claim_ids else 0
        deleted_entities = len(entity_ids) if entity_ids else 0
        deleted_sessions = len(session_ids) if session_ids else 0

        if verbose or deleted_claims > 0 or deleted_entities > 0 or deleted_sessions > 0:
            print(
                f"  Cleanup [{owner_id}]: removed {deleted_claims} claims, "
                f"{deleted_entities} entities, {deleted_sessions} sessions",
                file=sys.stderr,
            )

    except Exception as exc:
        print(f"  ⚠ Cleanup failed: {exc}", file=sys.stderr)
        if verbose:
            import traceback
            traceback.print_exc(file=sys.stderr)


async def _run(args: argparse.Namespace) -> int:
    """Main async eval runner. Returns exit code."""
    t0 = time.perf_counter()

    # Long-MT-Bench+ uses a different evaluation path
    if args.benchmark == "long-mt-bench":
        return await _run_long_mt_bench(args, t0)

    output_path, latest_symlink = _resolve_output_paths(args.out, args.benchmark)

    # Memory benchmarks (locomo, longmemeval)
    from .harness import EvalHarness

    plugin = _load_plugin(args.config, db_path=args.db_path)

    data_path = args.data if args.data else None
    if data_path and not pathlib.Path(data_path).exists():
        print(f"ERROR: Dataset file not found: {data_path}", file=sys.stderr)
        return 1

    isolate: bool = getattr(args, "isolate", True)
    eval_owner_id: Optional[str] = None
    if isolate:
        ts = int(time.time())
        eval_owner_id = f"{_LOCOMO_EVAL_PREFIX}-{ts}-{random.randint(1000, 9999)}"
        print(
            f"ℹ️  Isolation ON: using throwaway owner_id '{eval_owner_id}' "
            f"(pass --no-isolate to disable)",
            file=sys.stderr,
        )
    else:
        if not getattr(args, "force", False):
            if sys.stdin.isatty():
                print(
                    "⚠️  Isolation OFF (--no-isolate): benchmark will write to the "
                    "plugin default owner_id.  Production data may be contaminated.",
                    file=sys.stderr,
                )
                try:
                    answer = input("Continue without isolation? [y/N] ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    answer = ""
                if answer not in ("y", "yes"):
                    print("Aborted.", file=sys.stderr)
                    return 1
            else:
                print(
                    "ERROR: --no-isolate requires --force in non-interactive mode.",
                    file=sys.stderr,
                )
                return 1
        else:
            print(
                "⚠️  Isolation OFF (--no-isolate --force): benchmark will write to the "
                "plugin default owner_id.  Production data may be contaminated.",
                file=sys.stderr,
            )

    llm_judge = _build_llm_judge(plugin) if args.llm_judge else None

    gemini_judge = None
    if getattr(args, "gemini_judge", False):
        from cortex.eval.gemini_judge import GeminiJudge, resolve_judge_prompt_style
        judge_key = getattr(args, "judge_api_key", None) or os.environ.get("GEMINI_API_KEY", "")
        judge_model = getattr(args, "judge_model_name", None) or "gemini-2.5-flash"
        if not judge_key:
            print("ERROR: --judge requires a Gemini API key (--judge-api-key or GEMINI_API_KEY).", file=sys.stderr)
            return 1
        # Resolve judge prompt style: explicit flag > auto-detect from benchmark
        judge_prompt_style = resolve_judge_prompt_style(
            benchmark=args.benchmark,
            explicit_style=getattr(args, "judge_prompt", None),
        )
        gemini_judge = GeminiJudge(
            api_key=judge_key,
            model=judge_model,
            prompt_style=judge_prompt_style,
        )
        print(f"ℹ️  Gemini judge enabled: model={judge_model}, prompt={judge_prompt_style}", file=sys.stderr)
        # Store resolved values for logging (Bug fix: raw CLI args may be None
        # when auto-detection selected the style/model default)
        args.judge_prompt_resolved = judge_prompt_style
        args.judge_model_resolved = judge_model
    else:
        args.judge_prompt_resolved = None
        args.judge_model_resolved = None

    rag_llm = None
    if args.mode in ("rag", "full"):
        rag_llm = getattr(plugin, "llm", None)
        if rag_llm is None:
            print("WARNING: --mode rag/full but no LLM configured.", file=sys.stderr)

    await _run_preflight(plugin, args.config)
    await _run_namespace_canary(plugin)

    harness = EvalHarness(
        plugin=plugin,
        fuzzy_threshold=args.fuzzy_threshold,
        llm_judge=llm_judge,
        mode=args.mode,
        llm=rag_llm,
        confidence_threshold=args.confidence_threshold,
        owner_id=eval_owner_id,
        reconciliation_llm_calls_per_batch=(None if args.full_pipeline else 0),
        max_session_failures=args.max_session_failures,
        gemini_judge=gemini_judge,
        fail_on_empty=args.fail_on_empty,
    )

    stop_event = asyncio.Event()
    _install_signal_handlers(harness, stop_event)
    report = None
    exit_code = 0
    stop_wait_task: Optional[asyncio.Task[Any]] = None

    async def _execute_benchmark() -> Any:
        if args.benchmark == "locomo":
            return await harness.run_locomo(path=data_path)
        if args.benchmark == "locomo-full":
            from .locomo import LoCoMoLoader
            loader = LoCoMoLoader()
            if args.sample_id is not None:
                dataset = loader.load_conversation(args.sample_id, path=data_path)
            else:
                dataset = loader.load_native(path=data_path)
            return await harness.run_locomo_dataset(dataset)
        if args.benchmark == "longmemeval":
            return await harness.run_longmemeval(path=data_path)
        raise RuntimeError(f"Unknown benchmark: {args.benchmark}")

    try:
        eval_task = asyncio.create_task(_execute_benchmark())
        stop_wait_task = asyncio.create_task(stop_event.wait())
        done, pending = await asyncio.wait(
            {eval_task, stop_wait_task},
            timeout=args.timeout_seconds,
            return_when=asyncio.FIRST_COMPLETED,
        )

        if eval_task in done:
            if stop_wait_task in pending:
                stop_wait_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await stop_wait_task
            report = await eval_task
        elif stop_event.is_set():
            print("Signal received — writing partial results", file=sys.stderr)
            harness.request_shutdown()
            if stop_wait_task in pending:
                stop_wait_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await stop_wait_task
            try:
                report = await asyncio.wait_for(eval_task, timeout=30)
            except asyncio.TimeoutError:
                print("Grace period expired — forcing shutdown", file=sys.stderr)
                eval_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await eval_task
                report = harness.build_partial_report()
            exit_code = 130
        else:
            print(f"Run timeout after {args.timeout_seconds}s — writing partial results", file=sys.stderr)
            harness.request_shutdown()
            if stop_wait_task in pending:
                stop_wait_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await stop_wait_task
            try:
                report = await asyncio.wait_for(eval_task, timeout=30)
            except asyncio.TimeoutError:
                print("Grace period expired — forcing shutdown", file=sys.stderr)
                eval_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await eval_task
                report = harness.build_partial_report()
            exit_code = 124

        elapsed = time.perf_counter() - t0
        print(f"\nEval completed in {elapsed:.1f}s")
        print(report.summary())

        _log_run(args.runs_log, args.benchmark, report.metrics, report.config, elapsed)

        # V2 unified logging with config snapshot
        _log_run_v2(
            args=args,
            report=report,
            plugin=plugin,
            elapsed_sec=elapsed,
        )

        report_dict = report.to_dict()
        claims = report_dict.get("metrics", {}).get("total_claims_extracted", 0)
        interrupted = bool(report_dict.get("interrupted", False))
        if claims == 0 and exit_code == 0 and not interrupted:
            print(
                "ERROR: Zero claims extracted across all sessions. "
                "Pipeline likely misconfigured (missing LLM provider or embeddings).",
                file=sys.stderr,
            )
            exit_code = 1

        _write_report_json(str(output_path), report, latest_symlink=latest_symlink)

        if args.baseline:
            _compare_baseline(args.baseline, report.metrics)

        if exit_code == 0 and args.fail_under is not None:
            accuracy = report.metrics.get("fuzzy_match_accuracy", 0.0)
            if accuracy < args.fail_under:
                print(
                    f"\nFAIL: fuzzy_match_accuracy {accuracy:.1%} < {args.fail_under:.1%}",
                    file=sys.stderr,
                )
                exit_code = 1
            else:
                print(f"\nPASS: fuzzy_match_accuracy {accuracy:.1%} >= {args.fail_under:.1%}")

        return exit_code

    except Exception:
        partial_report = harness.build_partial_report()
        if partial_report.session_results:
            _write_report_json(str(output_path), partial_report, latest_symlink=latest_symlink)
        raise

    finally:
        if stop_wait_task is not None and not stop_wait_task.done():
            stop_wait_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await stop_wait_task
        _remove_signal_handlers()
        if isolate and eval_owner_id:
            # Collect all per-conversation owner_ids from the harness
            conv_owners = getattr(harness, "per_conversation_owners", None) or []
            # Always include the run-level prefix (for any non-conversation data)
            all_owners = [eval_owner_id] + [o for o in conv_owners if o != eval_owner_id]
            print(
                f"\nCleaning up eval data for {len(all_owners)} owner(s)...",
                file=sys.stderr,
            )
            for oid in all_owners:
                await _cleanup_eval_owner(plugin, oid, verbose=args.verbose)


async def _run_long_mt_bench(args: argparse.Namespace, t0: float) -> int:
    """Run Long-MT-Bench+ evaluation (#1281)."""
    from .long_mt_bench import LongMTBenchAdapter, LongMTBenchConfig, load_long_mt_bench

    output_path, latest_symlink = _resolve_output_paths(args.out, args.benchmark)

    plugin = _load_plugin(args.config, db_path=args.db_path)
    llm = getattr(plugin, "llm", None)
    if llm is None:
        print("ERROR: Long-MT-Bench+ requires an LLM provider.", file=sys.stderr)
        return 1

    conversations = load_long_mt_bench(args.data)
    adapter = LongMTBenchAdapter(llm=llm)
    report = await adapter.evaluate(conversations)

    elapsed = time.perf_counter() - t0
    print(f"\nEval completed in {elapsed:.1f}s")
    print(report.summary())

    # Log run
    _log_run(args.runs_log, "long-mt-bench", report.metrics, {
        "max_history_tokens": adapter.config.max_history_tokens,
        "judge_model": adapter.config.judge_model,
        "generation_model": adapter.config.generation_model,
    }, elapsed)

    _write_report_json(str(output_path), report, latest_symlink=latest_symlink)

    # Baseline comparison
    if args.baseline:
        _compare_baseline(args.baseline, report.metrics)

    # CI gate: for MT-Bench, fail-under is on avg_score (1-10 scale)
    if args.fail_under is not None:
        score = report.metrics.get("avg_score", 0.0)
        if score < args.fail_under:
            print(f"\nFAIL: avg_score {score:.2f} < {args.fail_under:.2f}", file=sys.stderr)
            return 1
        print(f"\nPASS: avg_score {score:.2f} >= {args.fail_under:.2f}")

    return 0


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")

    exit_code = asyncio.run(_run(args))
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
