"""Benchmark run logger — append-only JSONL database for reproducible results.

Every benchmark run gets a single JSONL line with:
- run_id: unique identifier ({harness}-{benchmark}-{YYYYMMDD}-{hash8})
- timestamp: ISO 8601 with timezone
- version: Cortex version from pyproject.toml
- harness: which eval system (cortex-eval | amb)
- benchmark: which benchmark (locomo, locomo-full, longmemeval, etc.)
- config_snapshot: full CortexConfig snapshot (45+ tuneables)
- scores: structured metric scores
- deltas: auto-computed diffs vs previous/baseline

Usage:
    from cortex.eval.run_logger import RunLogger

    logger = RunLogger()
    logger.log_run(
        benchmark="locomo",
        metrics={"avg_token_f1": 0.393, ...},
        extraction_model="gemini-2.5-flash",
        embedding_model="voyage-4-large",
        notes="Post rerank-timeout fix",
        tags=["post-fix-1638"],
    )

    # V2: with full config snapshot
    logger.log_run_v2(
        harness="cortex-eval",
        benchmark="locomo",
        scores={"avg_token_f1": 0.393, ...},
        config_snapshot=snapshot_config(cortex_config),
        git_sha="a1b2c3d",
        tags=["post-fix-1638"],
    )
"""

import json
import hashlib
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Any, List


RUNS_FILE = Path(__file__).parent.parent.parent / "benchmarks" / "results" / "runs.jsonl"
RUNS_V2_FILE = Path(__file__).parent.parent.parent / "benchmarks" / "results" / "runs_v2.jsonl"

SCHEMA_VERSION = 2


def _get_version() -> str:
    """Read version from pyproject.toml."""
    pyproject = Path(__file__).parent.parent.parent / "pyproject.toml"
    if pyproject.exists():
        for line in pyproject.read_text().splitlines():
            if line.strip().startswith("version"):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return "unknown"


def _get_git_sha() -> str:
    """Get current git short SHA."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=5,
            cwd=Path(__file__).parent.parent.parent,
        )
        return result.stdout.strip() if result.returncode == 0 else "unknown"
    except Exception:
        return "unknown"


def _make_run_id(benchmark: str, timestamp: str, harness: str = "cortex") -> str:
    """Generate a unique but human-readable run ID."""
    h = hashlib.sha256(f"{harness}-{benchmark}-{timestamp}-{platform.node()}".encode()).hexdigest()[:8]
    date_part = timestamp[:10].replace("-", "")
    return f"{harness}-{benchmark}-{date_part}-{h}"


def snapshot_config(cfg: Any) -> dict:
    """Extract benchmark-relevant config fields from CortexConfig into a snapshot dict.

    This captures ALL tuneables that can affect benchmark scores (~45 fields).
    The cfg parameter should be a CortexConfig instance.
    """
    if cfg is None:
        return {}

    def _getattr(obj: Any, name: str, default: Any = None) -> Any:
        return getattr(obj, name, default)

    return {
        "extraction": {
            "model": _getattr(cfg, "extraction_model"),
            "prompt_version": _getattr(cfg, "extraction_prompt_version", "v2"),
            "mode": _getattr(cfg, "extraction_mode", "unified"),
            "batch_size": _getattr(cfg, "extraction_batch_size", 5),
            "max_claims_per_extraction": _getattr(cfg, "max_claims_per_extraction", 25),
            "max_entities_per_extraction": _getattr(cfg, "max_entities_per_extraction", 100),
            "known_subjects": _getattr(cfg, "known_subjects", []),
            "temporal_markers": _getattr(cfg, "extraction_temporal_markers", True),
            "extract_assistant_turns": _getattr(cfg, "extract_assistant_turns", True),
            "coding_noise_filter": _getattr(cfg, "coding_noise_filter", True),
            "custom_instructions": _getattr(cfg, "extraction_custom_instructions", ""),
            "max_concurrent_extractions": _getattr(cfg, "max_concurrent_extractions", 4),
        },
        "embedding": {
            "model": _getattr(cfg, "provider_embedding_model") or _getattr(cfg, "embedding_model"),
            "dim": _getattr(cfg, "provider_embedding_dim") or _getattr(cfg, "embedding_dim", 1024),
            "provider": _getattr(cfg, "provider_embedding_provider", ""),
        },
        "retrieval": {
            "strategy": _getattr(cfg, "retrieval_default_strategy", "hybrid"),
            "vector_weight": _getattr(cfg, "retrieval_vector_weight", 0.7),
            "bm25_weight": _getattr(cfg, "retrieval_bm25_weight", 0.3),
            "recency_weight": _getattr(cfg, "retrieval_recency_weight", 0.1),
            "recency_half_life_days": _getattr(cfg, "retrieval_recency_half_life_days", 30.0),
            "temporal_boost_weight": _getattr(cfg, "retrieval_temporal_boost_weight", 0.15),
            "explicitness_bonus": _getattr(cfg, "retrieval_explicitness_bonus", 0.05),
            "stability_bonus": _getattr(cfg, "retrieval_stability_bonus", 0.03),
            "rrf_k": _getattr(cfg, "retrieval_rrf_k", 60),
            "max_chained_hops": _getattr(cfg, "retrieval_max_chained_hops", 2),
            "confidence_threshold": _getattr(cfg, "retrieval_confidence_threshold", 0.3),
            "max_tokens": _getattr(cfg, "retrieval_max_tokens", 4000),
        },
        "rerank": {
            "enabled": _getattr(cfg, "retrieval_rerank_enabled", True),
            "model": _getattr(cfg, "retrieval_rerank_model", "rerank-2.5-lite"),
            "top_k": _getattr(cfg, "retrieval_rerank_top_k", 5),
            "initial_candidates": _getattr(cfg, "retrieval_rerank_initial_candidates", 30),
            "timeout_seconds": _getattr(cfg, "retrieval_rerank_timeout_seconds", 1.2),
        },
        "reconciliation": {
            "model": _getattr(cfg, "reconciliation_model"),
            "deterministic_supersession_enabled": _getattr(cfg, "deterministic_supersession_enabled", False),
            "dialectic_model": _getattr(cfg, "dialectic_model"),
        },
        "llm_provider": {
            "provider": _getattr(cfg, "provider_llm_provider", ""),
            "model": _getattr(cfg, "provider_llm_model", ""),
            "base_url": _getattr(cfg, "provider_llm_base_url", ""),
            "mode": _getattr(cfg, "provider_mode", "host"),
        },
        "token_budgets": {
            "cornerstone": _getattr(cfg, "cornerstone_token_budget", 800),
            "retrieval": _getattr(cfg, "retrieval_token_budget", 4000),
            "total_memory": _getattr(cfg, "total_memory_token_budget", 5000),
            "memory_fraction": _getattr(cfg, "token_budget_memory_fraction", 0.25),
        },
    }


def _diff_scores(old_scores: dict, new_scores: dict) -> dict:
    """Compute numeric deltas between two score dicts."""
    deltas = {}
    for key in set(list(old_scores.keys()) + list(new_scores.keys())):
        if key == "by_category":
            continue
        old_val = old_scores.get(key)
        new_val = new_scores.get(key)
        if isinstance(old_val, (int, float)) and isinstance(new_val, (int, float)):
            delta = round(new_val - old_val, 6)
            if delta != 0:
                deltas[key] = delta
    return deltas


def _diff_config(old_config: dict, new_config: dict, prefix: str = "") -> list:
    """Compute a list of config diffs between two config snapshots."""
    diffs = []
    all_keys = set(list(old_config.keys()) + list(new_config.keys()))
    for key in sorted(all_keys):
        path = f"{prefix}.{key}" if prefix else key
        old_val = old_config.get(key)
        new_val = new_config.get(key)
        if isinstance(old_val, dict) and isinstance(new_val, dict):
            diffs.extend(_diff_config(old_val, new_val, path))
        elif old_val != new_val:
            diffs.append({"path": path, "old": old_val, "new": new_val})
    return diffs


def _summarize_changes(config_diffs: list) -> str:
    """Create a short summary of what changed (for table display)."""
    if not config_diffs:
        return ""
    changes = []
    for d in config_diffs[:5]:  # max 5 changes in summary
        path = d["path"]
        # Shorten path: "extraction.model" -> "extraction_model"
        short = path.replace(".", "_")
        # Just show the field name
        changes.append(f"+{short}")
    suffix = f" +{len(config_diffs) - 5} more" if len(config_diffs) > 5 else ""
    return ", ".join(changes) + suffix


class RunLogger:
    """Append-only JSONL logger for benchmark runs."""

    def __init__(self, runs_file: Optional[Path] = None, v2_file: Optional[Path] = None):
        self.runs_file = runs_file or RUNS_FILE
        self.v2_file = v2_file or RUNS_V2_FILE
        self.runs_file.parent.mkdir(parents=True, exist_ok=True)
        self.v2_file.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ #
    # V1 interface (backward compatible)
    # ------------------------------------------------------------------ #
    def log_run(
        self,
        benchmark: str,
        metrics: dict[str, Any],
        *,
        conversation: Optional[str] = None,
        qa_pairs: Optional[int] = None,
        extraction_model: Optional[str] = None,
        embedding_model: Optional[str] = None,
        embedding_dim: Optional[int] = None,
        generation_model: Optional[str] = None,
        judge_model: Optional[str] = None,
        retrieval_mode: str = "retrieval-only",
        claims_extracted: Optional[int] = None,
        sessions_total: Optional[int] = None,
        sessions_failed: Optional[int] = None,
        version: Optional[str] = None,
        notes: str = "",
        extra: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Log a benchmark run (V1 format). Returns the logged record."""
        now = datetime.now(timezone.utc).astimezone()
        ts = now.isoformat()
        ver = version or _get_version()
        run_id = _make_run_id(benchmark, ts)

        record = {
            "run_id": run_id,
            "timestamp": ts,
            "version": ver,
            "benchmark": benchmark,
            "retrieval_mode": retrieval_mode,
        }

        if conversation:
            record["conversation"] = conversation
        if qa_pairs is not None:
            record["qa_pairs"] = qa_pairs
        if extraction_model:
            record["extraction_model"] = extraction_model
        if embedding_model:
            record["embedding_model"] = embedding_model
        if embedding_dim is not None:
            record["embedding_dim"] = embedding_dim
        if generation_model:
            record["generation_model"] = generation_model
        if judge_model:
            record["judge_model"] = judge_model
        if claims_extracted is not None:
            record["claims_extracted"] = claims_extracted
        if sessions_total is not None:
            record["sessions_total"] = sessions_total
        if sessions_failed is not None:
            record["sessions_failed"] = sessions_failed

        record["metrics"] = metrics

        if notes:
            record["notes"] = notes
        if extra:
            record.update(extra)

        # Append to V1 JSONL
        with open(self.runs_file, "a") as f:
            f.write(json.dumps(record, default=str) + "\n")

        return record

    # ------------------------------------------------------------------ #
    # V2 interface (unified schema with config snapshots)
    # ------------------------------------------------------------------ #
    def log_run_v2(
        self,
        *,
        harness: str = "cortex-eval",
        benchmark: str,
        scores: dict[str, Any],
        config_snapshot: Optional[dict] = None,
        dataset_variant: str = "sample",
        mode: str = "retrieval-only",
        git_sha: Optional[str] = None,
        source: str = "local",
        is_baseline: bool = False,
        notes: str = "",
        tags: Optional[List[str]] = None,
        dataset_info: Optional[dict] = None,
        latency: Optional[dict] = None,
        version: Optional[str] = None,
        eval_params: Optional[dict] = None,
        run_id: Optional[str] = None,
        timestamp: Optional[str] = None,
    ) -> dict[str, Any]:
        """Log a benchmark run in V2 unified format.

        Returns the complete BenchmarkResult record including auto-computed deltas.
        """
        now = datetime.now(timezone.utc).astimezone()
        ts = timestamp or now.isoformat()
        ver = version or _get_version()
        sha = git_sha or _get_git_sha()
        rid = run_id or _make_run_id(benchmark, ts, harness)

        record: dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "run_id": rid,
            "timestamp": ts,
            "harness": harness,
            "benchmark": benchmark,
            "dataset_variant": dataset_variant,
            "mode": mode,
            "version": ver,
            "git_sha": sha,
            "source": source,
            "is_baseline": is_baseline,
            "scores": scores,
        }

        if config_snapshot:
            # Merge eval_params into config_snapshot
            if eval_params:
                config_snapshot["eval_params"] = eval_params
            record["config_snapshot"] = config_snapshot

        if notes:
            record["notes"] = notes
        if tags:
            record["tags"] = tags
        if dataset_info:
            record["dataset_info"] = dataset_info
        if latency:
            record["latency"] = latency

        # Auto-compute deltas
        deltas = self.compute_deltas(record)
        if deltas:
            record["deltas"] = deltas

        # Append to V2 JSONL
        with open(self.v2_file, "a") as f:
            f.write(json.dumps(record, default=str) + "\n")

        return record

    def log_run_raw(self, record: dict[str, Any]) -> None:
        """Append a pre-built record to the V2 JSONL file."""
        record.setdefault("schema_version", SCHEMA_VERSION)
        with open(self.v2_file, "a") as f:
            f.write(json.dumps(record, default=str) + "\n")

    # ------------------------------------------------------------------ #
    # Delta computation
    # ------------------------------------------------------------------ #
    def compute_deltas(self, run: dict) -> dict:
        """Auto-compute deltas vs previous run and baseline."""
        all_runs = self.list_runs_v2(benchmark=run.get("benchmark"))
        if not all_runs:
            return {}

        deltas: dict[str, Any] = {}

        # vs previous (last run of same benchmark)
        prev = all_runs[-1] if all_runs else None
        if prev and prev.get("run_id") != run.get("run_id"):
            score_deltas = _diff_scores(prev.get("scores", {}), run.get("scores", {}))
            config_diff = _diff_config(
                prev.get("config_snapshot", {}),
                run.get("config_snapshot", {}),
            )
            deltas["vs_previous"] = {
                "run_id": prev["run_id"],
                "score_deltas": score_deltas,
                "config_diff": config_diff,
            }

        # vs baseline (most recent baseline-tagged run of same benchmark)
        baseline = None
        for r in reversed(all_runs):
            if r.get("is_baseline") and r.get("run_id") != run.get("run_id"):
                baseline = r
                break
        if baseline:
            deltas["vs_baseline"] = {
                "run_id": baseline["run_id"],
                "score_deltas": _diff_scores(baseline.get("scores", {}), run.get("scores", {})),
            }

        return deltas

    # ------------------------------------------------------------------ #
    # V1 readers (backward compatible)
    # ------------------------------------------------------------------ #
    def list_runs(
        self,
        benchmark: Optional[str] = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Read recent runs from V1 file, optionally filtered by benchmark."""
        if not self.runs_file.exists():
            return []

        runs = []
        for line in self.runs_file.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                run = json.loads(line)
                if benchmark and run.get("benchmark") != benchmark:
                    continue
                runs.append(run)
            except json.JSONDecodeError:
                continue

        return runs[-limit:]

    def latest_run(self, benchmark: Optional[str] = None) -> Optional[dict[str, Any]]:
        """Get the most recent run from V1 file."""
        runs = self.list_runs(benchmark=benchmark, limit=1)
        return runs[0] if runs else None

    # ------------------------------------------------------------------ #
    # V2 readers
    # ------------------------------------------------------------------ #
    def list_runs_v2(
        self,
        benchmark: Optional[str] = None,
        tag: Optional[str] = None,
        harness: Optional[str] = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Read runs from V2 file with optional filters."""
        if not self.v2_file.exists():
            return []

        runs = []
        for line in self.v2_file.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                run = json.loads(line)
                if benchmark and run.get("benchmark") != benchmark:
                    continue
                if harness and run.get("harness") != harness:
                    continue
                if tag and tag not in run.get("tags", []):
                    continue
                runs.append(run)
            except json.JSONDecodeError:
                continue

        return runs[-limit:]

    def get_run(self, run_id: str) -> Optional[dict[str, Any]]:
        """Get a specific run by ID from V2 file."""
        for run in self.list_runs_v2(limit=1000):
            if run.get("run_id") == run_id:
                return run
        return None

    # ------------------------------------------------------------------ #
    # V1 compare (backward compatible)
    # ------------------------------------------------------------------ #
    def compare(
        self,
        run_ids: Optional[list[str]] = None,
        benchmark: Optional[str] = None,
        metric_key: str = "f1_excl_adversarial",
    ) -> str:
        """Generate a comparison table for V1 runs."""
        runs = self.list_runs(benchmark=benchmark, limit=50)
        if run_ids:
            runs = [r for r in runs if r["run_id"] in run_ids]

        if not runs:
            return "No runs found."

        lines = [
            f"{'Run ID':<30} {'Version':<8} {'Extraction':<25} {'Embedding':<30} {'Claims':>6} {metric_key:>12}",
            "-" * 120,
        ]
        for r in runs:
            score = r.get("metrics", {}).get(metric_key, "n/a")
            if isinstance(score, float):
                score = f"{score:.3f}"
            lines.append(
                f"{r.get('run_id', '?'):<30} "
                f"{r.get('version', '?'):<8} "
                f"{r.get('extraction_model', '?'):<25} "
                f"{r.get('embedding_model', '?'):<30} "
                f"{r.get('claims_extracted', '?'):>6} "
                f"{score:>12}"
            )

        return "\n".join(lines)
