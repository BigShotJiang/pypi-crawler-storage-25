"""
cortex/eval/backfill_results.py — Backfill historical results into runs_v2.jsonl.

Imports:
- Existing runs.jsonl (V1) records → V2 format
- Existing rag_runs.jsonl records → V2 format
- /tmp/eval-results-v4.json through v7 → V2 format
- AMB locomo10 result → V2 format

Usage::

    python -m cortex.eval.backfill_results
    python -m cortex.eval.backfill_results --dry-run
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from cortex.eval.run_logger import RunLogger, SCHEMA_VERSION, _make_run_id, _diff_scores, _diff_config


def _migrate_v1_record(record: dict) -> dict:
    """Convert a V1 runs.jsonl record to V2 schema."""
    config_snapshot = {}

    # Move model fields into config_snapshot
    if record.get("extraction_model"):
        config_snapshot["extraction"] = {"model": record["extraction_model"]}
    if record.get("embedding_model"):
        config_snapshot["embedding"] = {
            "model": record["embedding_model"],
            "dim": record.get("embedding_dim"),
        }
    if record.get("generation_model"):
        config_snapshot["generation"] = {"model": record["generation_model"]}
    if record.get("judge_model"):
        config_snapshot["judge"] = {"model": record["judge_model"]}

    # Determine dataset variant
    dataset_variant = "sample"
    conv = record.get("conversation", "")
    if "conv-26" in str(conv):
        dataset_variant = "single-conv"

    v2: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "run_id": record.get("run_id", "unknown"),
        "timestamp": record.get("timestamp", ""),
        "harness": "cortex-eval",
        "benchmark": record.get("benchmark", "locomo"),
        "dataset_variant": dataset_variant,
        "mode": record.get("retrieval_mode", "retrieval-only"),
        "version": record.get("version", "unknown"),
        "git_sha": "unknown",
        "source": "local",
        "is_baseline": False,
        "scores": record.get("metrics", {}),
        "config_snapshot": config_snapshot,
    }

    if record.get("notes"):
        v2["notes"] = record["notes"]

    # Build dataset_info
    dataset_info = {}
    if record.get("qa_pairs"):
        dataset_info["total_questions"] = record["qa_pairs"]
    if record.get("sessions_total") is not None:
        dataset_info["total_sessions"] = record["sessions_total"]
    if record.get("sessions_failed") is not None:
        dataset_info["sessions_failed"] = record["sessions_failed"]
    if record.get("claims_extracted") is not None:
        dataset_info["total_claims_extracted"] = record["claims_extracted"]
    if dataset_info:
        v2["dataset_info"] = dataset_info

    return v2


def _migrate_rag_record(record: dict) -> dict:
    """Convert a rag_runs.jsonl record to V2 schema."""
    config_label = record.get("config", "?")
    scores = record.get("scores", {})

    config_snapshot = {}
    if record.get("extraction_model"):
        config_snapshot["extraction"] = {"model": record["extraction_model"]}
    if record.get("embedding_model"):
        config_snapshot["embedding"] = {"model": record["embedding_model"]}
    if record.get("generation_model"):
        config_snapshot["generation"] = {"model": record["generation_model"]}
    if record.get("judge_model"):
        config_snapshot["judge"] = {"model": record["judge_model"]}
    if record.get("top_k"):
        config_snapshot["eval_params"] = {"top_k": record["top_k"]}

    ts = record.get("timestamp", "")
    run_id = f"rag-config-{config_label}-{ts[:10].replace('-', '')}"

    v2: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "timestamp": ts,
        "harness": "cortex-eval",
        "benchmark": "locomo",
        "dataset_variant": "single-conv",
        "mode": "rag",
        "version": record.get("version", "unknown"),
        "git_sha": "unknown",
        "source": "local",
        "is_baseline": False,
        "scores": {
            "by_category": {
                cat: {"accuracy": acc}
                for cat, acc in scores.items()
            }
        } if scores else {},
        "config_snapshot": config_snapshot,
        "notes": f"RAG config {config_label}",
    }

    if record.get("total_claims"):
        v2["dataset_info"] = {
            "total_claims_extracted": record["total_claims"],
            "total_questions": record.get("total_questions", 199),
        }

    return v2


def _build_harness_v4_v7() -> list[dict]:
    """Build V2 records from eval-results-v4 through v7 files."""
    records = []

    # V4: F1=0.031, 0% exact/fuzzy, 19 claims (scoring was broken)
    v4_data = {
        "run_id": "cortex-locomo-20260328-v4broken",
        "timestamp": "2026-03-28T04:00:00+07:00",
        "harness": "cortex-eval",
        "benchmark": "locomo",
        "dataset_variant": "sample",
        "mode": "retrieval-only",
        "version": "1.2.5",
        "git_sha": "unknown",
        "source": "local",
        "is_baseline": False,
        "schema_version": SCHEMA_VERSION,
        "scores": {
            "exact_match_accuracy": 0.0,
            "fuzzy_match_accuracy": 0.0,
            "avg_token_f1": 0.031,
            "mrr": 0.0,
        },
        "dataset_info": {
            "total_questions": 20,
            "total_sessions": 5,
            "total_claims_extracted": 19,
            "total_claims_stored": 19,
        },
        "notes": "V4: scoring was broken — returned raw RetrievalResult objects as predictions",
        "tags": ["historical", "broken-scoring"],
    }

    # Try to load actual latency from file
    for version_num, data in [("v4", v4_data)]:
        fpath = Path(f"/tmp/eval-results-{version_num}.json")
        if fpath.exists():
            try:
                with open(fpath) as f:
                    raw = json.load(f)
                metrics = raw.get("metrics", {})
                if "retrieve_latency" in metrics:
                    data.setdefault("latency", {})["retrieve"] = metrics["retrieve_latency"]
                if "remember_latency" in metrics:
                    data.setdefault("latency", {})["remember"] = metrics["remember_latency"]
            except Exception:
                pass

    records.append(v4_data)

    # V5: F1=0.142, 0% exact/fuzzy, 20 claims (RetrievalResult fix)
    v5_data = {
        "run_id": "cortex-locomo-20260328-v5retrieval",
        "timestamp": "2026-03-28T05:00:00+07:00",
        "harness": "cortex-eval",
        "benchmark": "locomo",
        "dataset_variant": "sample",
        "mode": "retrieval-only",
        "version": "1.2.5",
        "git_sha": "unknown",
        "source": "local",
        "is_baseline": False,
        "schema_version": SCHEMA_VERSION,
        "scores": {
            "exact_match_accuracy": 0.0,
            "fuzzy_match_accuracy": 0.0,
            "avg_token_f1": 0.142,
            "mrr": 0.0,
        },
        "dataset_info": {
            "total_questions": 20,
            "total_sessions": 5,
            "total_claims_extracted": 20,
            "total_claims_stored": 20,
        },
        "notes": "V5: Fixed RetrievalResult → .content extraction. F1 jumped from 0.031 to 0.142",
        "tags": ["historical", "retrieval-fix"],
    }

    fpath = Path("/tmp/eval-results-v5.json")
    if fpath.exists():
        try:
            with open(fpath) as f:
                raw = json.load(f)
            metrics = raw.get("metrics", {})
            if "retrieve_latency" in metrics:
                v5_data.setdefault("latency", {})["retrieve"] = metrics["retrieve_latency"]
            if "remember_latency" in metrics:
                v5_data.setdefault("latency", {})["remember"] = metrics["remember_latency"]
        except Exception:
            pass

    records.append(v5_data)

    # V6: F1=0.343, 20% fuzzy, 20 claims (isolation + best-claim)
    v6_data = {
        "run_id": "cortex-locomo-20260328-v6isolation",
        "timestamp": "2026-03-28T06:00:00+07:00",
        "harness": "cortex-eval",
        "benchmark": "locomo",
        "dataset_variant": "sample",
        "mode": "retrieval-only",
        "version": "1.2.5",
        "git_sha": "unknown",
        "source": "local",
        "is_baseline": False,
        "schema_version": SCHEMA_VERSION,
        "scores": {
            "exact_match_accuracy": 0.0,
            "fuzzy_match_accuracy": 0.2,
            "avg_token_f1": 0.343,
            "mrr": 0.2,
        },
        "dataset_info": {
            "total_questions": 20,
            "total_sessions": 5,
            "total_claims_extracted": 20,
            "total_claims_stored": 20,
        },
        "notes": "V6: Isolation mode + best-claim selection. Major jump from 0.142 to 0.343 F1",
        "tags": ["historical", "isolation", "best-claim"],
    }

    fpath = Path("/tmp/eval-results-v6.json")
    if fpath.exists():
        try:
            with open(fpath) as f:
                raw = json.load(f)
            metrics = raw.get("metrics", {})
            if "retrieve_latency" in metrics:
                v6_data.setdefault("latency", {})["retrieve"] = metrics["retrieve_latency"]
            if "remember_latency" in metrics:
                v6_data.setdefault("latency", {})["remember"] = metrics["remember_latency"]
        except Exception:
            pass

    records.append(v6_data)

    # V7: F1=0.393, 15% fuzzy, 23 claims (rerank timeout + known_subjects)
    v7_data = {
        "run_id": "cortex-locomo-20260328-v7rerank",
        "timestamp": "2026-03-28T07:00:00+07:00",
        "harness": "cortex-eval",
        "benchmark": "locomo",
        "dataset_variant": "sample",
        "mode": "retrieval-only",
        "version": "1.2.5",
        "git_sha": "unknown",
        "source": "local",
        "is_baseline": True,
        "schema_version": SCHEMA_VERSION,
        "scores": {
            "exact_match_accuracy": 0.0,
            "fuzzy_match_accuracy": 0.15,
            "avg_token_f1": 0.393,
            "mrr": 0.15,
        },
        "dataset_info": {
            "total_questions": 20,
            "total_sessions": 5,
            "total_claims_extracted": 23,
            "total_claims_stored": 23,
        },
        "notes": "V7: Rerank timeout fix (400ms→1.2s) + known_subjects filter. Current best F1=0.393",
        "tags": ["historical", "rerank-timeout", "known-subjects", "current-best"],
    }

    fpath = Path("/tmp/eval-results-v7.json")
    if fpath.exists():
        try:
            with open(fpath) as f:
                raw = json.load(f)
            metrics = raw.get("metrics", {})
            if "retrieve_latency" in metrics:
                v7_data.setdefault("latency", {})["retrieve"] = metrics["retrieve_latency"]
            if "remember_latency" in metrics:
                v7_data.setdefault("latency", {})["remember"] = metrics["remember_latency"]
        except Exception:
            pass

    records.append(v7_data)

    return records


def _build_amb_record() -> list[dict]:
    """Build V2 record from AMB locomo10 result."""
    amb_path = Path("/tmp/amb/outputs/locomo/cortex/rag/locomo10.json")
    if not amb_path.exists():
        return []

    try:
        with open(amb_path) as f:
            summary = json.load(f)
    except Exception:
        return []

    # Extract per-category breakdown
    by_category = {}
    for r in summary.get("results", []):
        cat = r.get("category") or "uncategorized"
        if cat not in by_category:
            by_category[cat] = {"count": 0, "correct": 0}
        by_category[cat]["count"] += 1
        if r.get("correct"):
            by_category[cat]["correct"] += 1
    for cat_data in by_category.values():
        total = cat_data["count"]
        cat_data["accuracy"] = cat_data["correct"] / total if total > 0 else 0.0

    record = {
        "schema_version": SCHEMA_VERSION,
        "run_id": "amb-locomo-20260328-locomo10",
        "timestamp": "2026-03-28T08:00:00+07:00",
        "harness": "amb",
        "benchmark": "locomo",
        "dataset_variant": "locomo10",
        "mode": "rag",
        "version": "1.2.5",
        "git_sha": "unknown",
        "source": "amb-import",
        "is_baseline": True,
        "scores": {
            "judge_accuracy": summary.get("accuracy", 0.0),
            "by_category": by_category,
        },
        "config_snapshot": {
            "generation": {"model": summary.get("answer_llm", "")},
            "judge": {"model": summary.get("judge_llm", ""), "enabled": True},
        },
        "dataset_info": {
            "total_questions": summary.get("total_queries", 0),
            "ingested_docs": summary.get("ingested_docs", 0),
            "avg_context_tokens": summary.get("avg_context_tokens"),
        },
        "latency": {
            "ingestion_ms": summary.get("ingestion_time_ms", 0),
            "retrieve": {"mean": summary.get("avg_retrieve_time_ms", 0)},
        },
        "notes": "AMB full locomo10 run (10 conversations, 885 queries). First AMB baseline.",
        "tags": ["amb", "locomo10", "baseline"],
    }

    return [record]


def run_backfill(dry_run: bool = False) -> list[dict]:
    """Run the full backfill. Returns all records that were/would be written."""
    logger = RunLogger()
    all_records: list[dict] = []

    # 1. Migrate V1 runs.jsonl records
    print("📋 Migrating V1 runs.jsonl records...")
    v1_runs = logger.list_runs(limit=1000)
    for r in v1_runs:
        v2 = _migrate_v1_record(r)
        all_records.append(v2)
        print(f"  ✓ {v2['run_id']}")

    # 2. Migrate rag_runs.jsonl records
    rag_file = logger.runs_file.parent / "rag_runs.jsonl"
    if rag_file.exists():
        print("\n📋 Migrating rag_runs.jsonl records...")
        for line in rag_file.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
                v2 = _migrate_rag_record(r)
                all_records.append(v2)
                print(f"  ✓ {v2['run_id']}")
            except (json.JSONDecodeError, Exception) as e:
                print(f"  ⚠ Skipped record: {e}")

    # 3. Backfill v4-v7
    print("\n📋 Backfilling v4-v7 harness results...")
    for r in _build_harness_v4_v7():
        all_records.append(r)
        print(f"  ✓ {r['run_id']} (F1={r['scores'].get('avg_token_f1', '?')})")

    # 4. AMB locomo10
    print("\n📋 Importing AMB locomo10 result...")
    for r in _build_amb_record():
        all_records.append(r)
        print(f"  ✓ {r['run_id']} (accuracy={r['scores'].get('judge_accuracy', '?'):.1%})")

    # Write if not dry-run
    if not dry_run:
        print(f"\n✍️  Writing {len(all_records)} records to {logger.v2_file}...")
        for r in all_records:
            logger.log_run_raw(r)
        print(f"✅ Done. {len(all_records)} records written to {logger.v2_file}")
    else:
        print(f"\n🔍 DRY RUN: Would write {len(all_records)} records to {logger.v2_file}")

    return all_records


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="backfill-results",
        description="Backfill historical benchmark results into runs_v2.jsonl.",
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would be written without writing")

    args = parser.parse_args()
    run_backfill(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
