"""
cortex/eval/results.py — Unified benchmark results viewer CLI.

View, compare, and analyze benchmark results from runs_v2.jsonl.

Usage::

    python -m cortex.eval.results                          # show last 10
    python -m cortex.eval.results --last 20                # show last 20
    python -m cortex.eval.results --tag post-fix-1638      # filter by tag
    python -m cortex.eval.results --harness amb            # filter by harness
    python -m cortex.eval.results --compare RUN_ID1 RUN_ID2  # side-by-side diff
    python -m cortex.eval.results --json                   # JSON output
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Optional

from cortex.eval.run_logger import RunLogger, _diff_scores, _diff_config


def _format_score(val: Any) -> str:
    """Format a score value for display."""
    if val is None:
        return "—"
    if isinstance(val, float):
        if val < 1.0:
            return f"{val:.3f}"
        return f"{val:.1f}"
    return str(val)


def _format_pct(val: Any) -> str:
    """Format as percentage."""
    if val is None:
        return "—"
    if isinstance(val, (int, float)):
        return f"{val * 100:.1f}%"
    return str(val)


def _format_table(runs: list[dict]) -> str:
    """Format runs as a human-readable table."""
    if not runs:
        return "No runs found."

    # Table header
    headers = ["Run ID", "Date", "Harness", "F1", "Fuzzy", "MRR", "Claims", "Model", "Changed"]
    rows = []

    for r in runs:
        scores = r.get("scores", {})
        config = r.get("config_snapshot", {})
        dataset_info = r.get("dataset_info", {})
        deltas = r.get("deltas", {})

        # Extract model name
        model = ""
        if config.get("extraction", {}).get("model"):
            model = config["extraction"]["model"]
        elif config.get("generation", {}).get("model"):
            model = config["generation"]["model"]

        # Claims count
        claims = dataset_info.get("total_claims_extracted") or dataset_info.get("total_claims_stored") or ""

        # Changed summary from deltas
        changed = ""
        vs_prev = deltas.get("vs_previous", {})
        if vs_prev.get("config_diff"):
            changed_parts = []
            for d in vs_prev["config_diff"][:3]:
                path = d["path"].split(".")[-1]
                changed_parts.append(f"+{path}")
            if len(vs_prev["config_diff"]) > 3:
                changed_parts.append(f"+{len(vs_prev['config_diff']) - 3} more")
            changed = ", ".join(changed_parts)

        # Date
        date_str = r.get("timestamp", "")[:10]

        # F1 value (try multiple keys)
        f1 = scores.get("avg_token_f1") or scores.get("f1_excl_adversarial") or scores.get("f1_all")

        # Fuzzy / accuracy
        fuzzy = scores.get("fuzzy_match_accuracy") or scores.get("judge_accuracy")

        # MRR
        mrr = scores.get("mrr")

        # Baseline marker
        run_id = r.get("run_id", "?")
        if r.get("is_baseline"):
            run_id = f"⭐ {run_id}"

        rows.append([
            run_id,
            date_str,
            r.get("harness", "?"),
            _format_score(f1),
            _format_pct(fuzzy),
            _format_score(mrr),
            str(claims) if claims else "—",
            model or "—",
            changed or "—",
        ])

    # Calculate column widths
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))

    # Format
    header_line = " | ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
    sep_line = "-+-".join("-" * w for w in col_widths)
    lines = [header_line, sep_line]
    for row in rows:
        lines.append(" | ".join(cell.ljust(col_widths[i]) for i, cell in enumerate(row)))

    return "\n".join(lines)


def _format_comparison(run1: dict, run2: dict) -> str:
    """Format a side-by-side comparison of two runs."""
    lines = []
    lines.append(f"Comparing: {run1.get('run_id', '?')} → {run2.get('run_id', '?')}")
    lines.append(f"  Dates: {run1.get('timestamp', '?')[:10]} → {run2.get('timestamp', '?')[:10]}")
    lines.append("")

    # Score comparison
    lines.append("Score deltas:")
    s1 = run1.get("scores", {})
    s2 = run2.get("scores", {})
    score_diffs = _diff_scores(s1, s2)
    if score_diffs:
        for key, delta in sorted(score_diffs.items()):
            old_val = s1.get(key, "—")
            new_val = s2.get(key, "—")
            arrow = "↑" if delta > 0 else "↓"
            if isinstance(old_val, float):
                old_val = f"{old_val:.3f}"
            if isinstance(new_val, float):
                new_val = f"{new_val:.3f}"
            lines.append(f"  {key}: {old_val} → {new_val} ({arrow} {delta:+.4f})")
    else:
        lines.append("  (no score differences)")

    # Config diff
    lines.append("")
    lines.append("Config diff:")
    c1 = run1.get("config_snapshot", {})
    c2 = run2.get("config_snapshot", {})
    config_diffs = _diff_config(c1, c2)
    if config_diffs:
        for d in config_diffs:
            lines.append(f"  {d['path']}: {d['old']} → {d['new']}")
    else:
        lines.append("  (no config differences)")

    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="cortex-results",
        description="View and compare unified benchmark results.",
    )
    parser.add_argument("--last", "-n", type=int, default=10,
                        help="Show last N runs (default: 10)")
    parser.add_argument("--tag", default=None,
                        help="Filter by tag")
    parser.add_argument("--harness", default=None,
                        help="Filter by harness (cortex-eval | amb)")
    parser.add_argument("--benchmark", default=None,
                        help="Filter by benchmark name")
    parser.add_argument("--compare", nargs=2, metavar="RUN_ID",
                        help="Compare two runs side-by-side")
    parser.add_argument("--json", action="store_true",
                        help="Output as JSON")
    parser.add_argument("--runs-file", default=None,
                        help="Path to runs_v2.jsonl (default: auto-detect)")

    args = parser.parse_args()

    logger = RunLogger()
    if args.runs_file:
        from pathlib import Path
        logger.v2_file = Path(args.runs_file)

    if args.compare:
        run1 = logger.get_run(args.compare[0])
        run2 = logger.get_run(args.compare[1])
        if not run1:
            print(f"Run not found: {args.compare[0]}", file=sys.stderr)
            sys.exit(1)
        if not run2:
            print(f"Run not found: {args.compare[1]}", file=sys.stderr)
            sys.exit(1)
        if args.json:
            print(json.dumps({
                "run1": run1,
                "run2": run2,
                "score_deltas": _diff_scores(run1.get("scores", {}), run2.get("scores", {})),
                "config_diff": _diff_config(run1.get("config_snapshot", {}), run2.get("config_snapshot", {})),
            }, indent=2, default=str))
        else:
            print(_format_comparison(run1, run2))
        return

    runs = logger.list_runs_v2(
        benchmark=args.benchmark,
        tag=args.tag,
        harness=args.harness,
        limit=args.last,
    )

    if args.json:
        print(json.dumps(runs, indent=2, default=str))
    else:
        print(_format_table(runs))


if __name__ == "__main__":
    main()
