"""
cortex/eval/harness.py — EvalHarness: Benchmark evaluation driver.

Orchestrates the full evaluation pipeline:
  1. Load benchmark dataset (LoCoMo or LongMemEval format)
  2. Run remember() on each session's conversation
  3. Run retrieve() for each question
  4. Score answers (exact match, fuzzy match, optional LLM-as-judge)
  5. Report metrics: precision, recall, F1, MRR, latency

Usage::

    from cortex.api.plugin import CortexPlugin
    from cortex.eval.harness import EvalHarness

    plugin = CortexPlugin.from_config("cortex.toml")
    harness = EvalHarness(plugin)
    results = await harness.run_locomo()
    print(results.summary())
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


MIN_CONVERSATION_CLAIMS = 5
ZERO_CLAIM_BACKPRESSURE_THRESHOLD = 3
ZERO_CLAIM_ABORT_THRESHOLD = 5

from .metrics import (
    adversarial_accuracy,
    compute_qa_metrics,
    latency_stats,
    mean_reciprocal_rank,
    precision_recall_f1,
    score_by_category,
    token_f1_score,
    fuzzy_match,
    exact_match,
)
from .generation import GeneratedAnswer, JudgeResult, generate_answer, judge_answer

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@dataclass
class QuestionResult:
    """Result for a single QA evaluation."""
    question_id: str
    question: str
    expected_answer: str
    predicted_answer: str
    exact_hit: bool
    fuzzy_hit: bool
    token_f1: float
    llm_judge_score: Optional[float]
    remember_latency_ms: float
    retrieve_latency_ms: float
    error: Optional[str] = None
    # RAG mode fields
    rag_answer: Optional[str] = None
    rag_judge_score: Optional[float] = None
    rag_judge_reasoning: Optional[str] = None
    category: int = 0  # LoCoMo category (1-5, 0 = unset)
    predicted_context: Optional[str] = None  # Full concatenated text for debugging
    # Gemini LLM judge fields (AMB-compatible binary scoring)
    judge_correct: Optional[bool] = None
    judge_reasoning: Optional[str] = None
    judge_error: Optional[str] = None


@dataclass
class SessionResult:
    """Result for a single session evaluation."""
    session_id: str
    question_results: List[QuestionResult] = field(default_factory=list)
    remember_latency_ms: float = 0.0
    claims_stored: int = 0
    remember_error: Optional[str] = None

    @property
    def n_questions(self) -> int:
        return len(self.question_results)

    @property
    def exact_match_count(self) -> int:
        return sum(1 for r in self.question_results if r.exact_hit)

    @property
    def fuzzy_match_count(self) -> int:
        return sum(1 for r in self.question_results if r.fuzzy_hit)


@dataclass
class ConversationIngestMetrics:
    """Per-conversation ingest instrumentation for eval reliability."""
    conversation_id: str
    sessions_attempted: int = 0
    total_claims_ingested: int = 0
    zero_claim_sessions: int = 0
    remember_errors: int = 0
    owner_id_used: Optional[str] = None
    degraded: bool = False
    failed: bool = False
    failure_reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conversation_id": self.conversation_id,
            "sessions_attempted": self.sessions_attempted,
            "total_claims_ingested": self.total_claims_ingested,
            "zero_claim_sessions": self.zero_claim_sessions,
            "remember_errors": self.remember_errors,
            "owner_id_used": self.owner_id_used,
            "degraded": self.degraded,
            "failed": self.failed,
            "failure_reason": self.failure_reason,
        }


@dataclass
class EvalReport:
    """
    Full evaluation report with aggregate metrics.

    Attributes:
        dataset_name: Name of the benchmark dataset.
        session_results: Per-session results.
        metrics: Aggregate metrics dict.
        config: Eval configuration used.
        run_status: Run completion status (e.g. completed/interrupted).
        interrupted: Whether the run was interrupted before normal completion.
    """
    dataset_name: str
    session_results: List[SessionResult] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    config: Dict[str, Any] = field(default_factory=dict)
    run_status: str = "completed"
    interrupted: bool = False
    ingest_metrics: Dict[str, ConversationIngestMetrics] = field(default_factory=dict)
    degraded_conversations: List[str] = field(default_factory=list)
    failed_conversations: List[str] = field(default_factory=list)

    def summary(self, indent: int = 0) -> str:
        """Return a human-readable summary of the eval results."""
        pad = " " * indent
        lines = [
            f"{pad}=== Eval Report: {self.dataset_name} ===",
            f"{pad}Sessions evaluated: {len(self.session_results)}",
            f"{pad}Total questions:    {self.metrics.get('total_questions', 0)}",
            f"{pad}Exact match:        {self.metrics.get('exact_match_accuracy', 0):.1%}",
            f"{pad}Fuzzy match:        {self.metrics.get('fuzzy_match_accuracy', 0):.1%}",
            f"{pad}Avg token F1:       {self.metrics.get('avg_token_f1', 0):.3f}",
            f"{pad}MRR:                {self.metrics.get('mrr', 0):.3f}",
        ]
        if "avg_llm_judge_score" in self.metrics:
            lines.append(f"{pad}LLM judge score:    {self.metrics['avg_llm_judge_score']:.3f}")
        if "judge_accuracy" in self.metrics:
            je = self.metrics.get('judge_errors', 0)
            je_str = f", {je} errors" if je else ""
            lines.append(f"{pad}Judge accuracy:     {self.metrics['judge_accuracy']:.1%} ({self.metrics.get('judge_correct_count', 0)}/{self.metrics.get('judge_total', 0)}{je_str})")
        if "rag_judge_accuracy" in self.metrics:
            lines.append(f"{pad}RAG judge accuracy: {self.metrics['rag_judge_accuracy']:.1%}")
        if "rag_judge_by_category" in self.metrics:
            lines.append(f"{pad}RAG by category:")
            for cat, score in sorted(self.metrics["rag_judge_by_category"].items()):
                lines.append(f"{pad}  Cat {cat}: {score:.1%}")
        if "retrieve_latency" in self.metrics:
            lat = self.metrics["retrieve_latency"]
            lines.append(f"{pad}Retrieve p95 (ms):  {lat.get('p95', 0):.1f}")
        if "remember_latency" in self.metrics:
            lat = self.metrics["remember_latency"]
            lines.append(f"{pad}Remember p95 (ms):  {lat.get('p95', 0):.1f}")
        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        """Return the report as a plain dict (JSON-serialisable)."""
        sessions_payload = [
            {
                "session_id": sr.session_id,
                "n_questions": sr.n_questions,
                "exact_match_count": sr.exact_match_count,
                "fuzzy_match_count": sr.fuzzy_match_count,
                "claims_stored": sr.claims_stored,
                "remember_latency_ms": sr.remember_latency_ms,
                "remember_error": sr.remember_error,
                "questions": [
                    {
                        "question_id": r.question_id,
                        "question": r.question,
                        "expected": r.expected_answer,
                        "predicted": r.predicted_answer,
                        "exact_hit": r.exact_hit,
                        "fuzzy_hit": r.fuzzy_hit,
                        "token_f1": r.token_f1,
                        "llm_judge_score": r.llm_judge_score,
                        "rag_answer": r.rag_answer,
                        "rag_judge_score": r.rag_judge_score,
                        "rag_judge_reasoning": r.rag_judge_reasoning,
                        "retrieve_latency_ms": r.retrieve_latency_ms,
                        "error": r.error,
                        "judge_correct": r.judge_correct,
                        "judge_reasoning": r.judge_reasoning,
                        "judge_error": r.judge_error,
                    }
                    for r in sr.question_results
                ],
            }
            for sr in self.session_results
        ]
        run_status = getattr(self, "run_status", None) or ("interrupted" if getattr(self, "interrupted", False) else "completed")
        interrupted = bool(getattr(self, "interrupted", False))
        payload = {
            "dataset_name": self.dataset_name,
            "metrics": self.metrics,
            "sessions": sessions_payload,
            "session_results": sessions_payload,
            "config": self.config,
            "run_status": run_status,
            "interrupted": interrupted,
            "ingest_metrics": {
                key: value.to_dict() for key, value in self.ingest_metrics.items()
            },
            "degraded_conversations": list(self.degraded_conversations),
            "failed_conversations": list(self.failed_conversations),
        }
        category_scores = self.metrics.get("rag_judge_by_category")
        if category_scores is not None:
            payload["category_scores"] = category_scores
        return payload


# ---------------------------------------------------------------------------
# EvalHarness
# ---------------------------------------------------------------------------

class EvalHarness:
    """
    Drives the full benchmark evaluation against a CortexPlugin instance.

    Args:
        plugin:         A CortexPlugin (or duck-typed compatible) instance.
        fuzzy_threshold: Threshold for fuzzy match scoring (default 0.6).
        llm_judge:      Optional callable(question, prediction, reference) -> float.
                        If provided, adds LLM-as-judge scores to results.
        max_retrieved:  Max retrieved items to inspect per question (for MRR).
        mode:           Eval mode: 'retrieval-only' (default), 'rag', or 'full'.
        llm:            LLM instance for RAG answer generation and judging.
        judge_model:    Optional model name override for LLM judge calls.
        owner_id:       Owner ID scope for remember/retrieve calls.  When set,
                        all benchmark data is written under this namespace,
                        keeping eval entities isolated from production data.
                        Use ``run_eval.py --isolate`` (default on) to have the
                        CLI auto-generate a throwaway ``locomo-eval-<ts>`` ID.
        max_session_failures:
                        Abort the eval after this many consecutive session-level
                        remember() failures.
        reconciliation_llm_calls_per_batch:
                        Override the reconciliation engine's ambiguous-case LLM
                        budget during benchmark ingestion. Defaults to 0 for eval
                        runs so extracted claims are still stored, but benchmark
                        ingestion does not spend extra LLM calls on semantic
                        adjudication that does not affect the benchmark goal.
    """

    def __init__(
        self,
        plugin: Any,
        fuzzy_threshold: float = 0.6,
        llm_judge: Optional[Callable[[str, str, str], float]] = None,
        max_retrieved: int = 10,
        mode: str = "retrieval-only",
        llm: Any = None,
        judge_model: Optional[str] = None,
        confidence_threshold: float = 0.3,
        owner_id: Optional[str] = None,
        reconciliation_llm_calls_per_batch: Optional[int] = 0,
        max_session_failures: int = 5,
        gemini_judge: Any = None,
        fail_on_empty: bool = False,
    ):
        if not hasattr(plugin, "remember") or not callable(getattr(plugin, "remember")):
            raise TypeError("plugin must expose a callable remember() method")
        if not hasattr(plugin, "retrieve") or not callable(getattr(plugin, "retrieve")):
            raise TypeError("plugin must expose a callable retrieve() method")
        if mode not in ("retrieval-only", "rag", "full"):
            raise ValueError(f"Unknown eval mode: {mode!r}. Must be 'retrieval-only', 'rag', or 'full'.")
        if not isinstance(max_retrieved, int) or max_retrieved <= 0:
            raise ValueError(f"max_retrieved must be a positive integer, got {max_retrieved!r}")
        if not isinstance(fuzzy_threshold, (int, float)):
            raise ValueError(
                f"fuzzy_threshold must be a number, got {type(fuzzy_threshold).__name__}"
            )
        if not math.isfinite(fuzzy_threshold) or not 0.0 <= fuzzy_threshold <= 1.0:
            raise ValueError(f"fuzzy_threshold must be a finite float in [0, 1], got {fuzzy_threshold!r}")
        if not isinstance(confidence_threshold, (int, float)):
            raise ValueError(
                f"confidence_threshold must be a number, got {type(confidence_threshold).__name__}"
            )
        if not math.isfinite(confidence_threshold) or not 0.0 <= confidence_threshold <= 1.0:
            raise ValueError(
                f"confidence_threshold must be a finite float in [0, 1], got {confidence_threshold!r}"
            )
        if not isinstance(max_session_failures, int) or max_session_failures <= 0:
            raise ValueError(
                f"max_session_failures must be a positive integer, got {max_session_failures!r}"
            )
        self.plugin = plugin
        self.fuzzy_threshold = fuzzy_threshold
        self.llm_judge = llm_judge
        self.max_retrieved = max_retrieved
        self.mode = mode
        self.llm = llm
        self.judge_model = judge_model
        self.confidence_threshold = confidence_threshold
        self.reconciliation_llm_calls_per_batch = reconciliation_llm_calls_per_batch

        # Benchmarks write to throwaway eval owners. They still need claims to be
        # persisted for retrieval, but they do not need expensive ambiguous-case
        # reconciliation adjudication during ingestion. Disable that LLM budget by
        # default for eval only; production plugin behavior is unchanged.
        reconciler = getattr(self.plugin, "reconciler", None)
        if (
            reconciler is not None
            and reconciliation_llm_calls_per_batch is not None
            and hasattr(reconciler, "max_llm_calls_per_batch")
        ):
            reconciler.max_llm_calls_per_batch = reconciliation_llm_calls_per_batch
        self.owner_id = owner_id
        self.max_session_failures = max_session_failures
        self.gemini_judge = gemini_judge
        self.fail_on_empty = fail_on_empty
        self._consecutive_session_failures = 0
        self._consecutive_zero_claim_sessions = 0
        self._shutdown_requested = False
        self._last_dataset_name: Optional[str] = None
        self._session_results: List[SessionResult] = []
        self._ingest_metrics: Dict[str, ConversationIngestMetrics] = {}
        self._failed_conversations: set[str] = set()
        # Per-conversation isolation: each conversation gets its own owner_id
        # to prevent cross-session claim leakage.  Pattern: {owner_id}-{conversation_id}
        self._per_conversation_owners: set[str] = set()

    # ------------------------------------------------------------------
    # Per-conversation owner isolation
    # ------------------------------------------------------------------

    def _conversation_owner_id(self, conversation_id: str) -> Optional[str]:
        """Derive a conversation-scoped owner_id from the run-level prefix.

        If ``self.owner_id`` is set, returns ``{owner_id}-{conversation_id}``.
        The conversation-scoped ID is tracked in ``_per_conversation_owners``
        for cleanup.  If ``self.owner_id`` is None (no isolation), returns None.
        """
        if self.owner_id is None:
            return None
        conv_owner = f"{self.owner_id}-{conversation_id}"
        self._per_conversation_owners.add(conv_owner)
        return conv_owner

    @property
    def per_conversation_owners(self) -> List[str]:
        """Return all conversation-scoped owner_ids created during this run."""
        return list(self._per_conversation_owners)

    def _get_ingest_metrics(
        self,
        conversation_id: str,
        *,
        owner_id_used: Optional[str],
    ) -> ConversationIngestMetrics:
        metrics = self._ingest_metrics.get(conversation_id)
        if metrics is None:
            metrics = ConversationIngestMetrics(
                conversation_id=conversation_id,
                owner_id_used=owner_id_used,
            )
            self._ingest_metrics[conversation_id] = metrics
        elif metrics.owner_id_used is None:
            metrics.owner_id_used = owner_id_used
        return metrics

    async def _record_zero_claim_session(self, conversation_id: str) -> bool:
        self._consecutive_zero_claim_sessions += 1
        if self._consecutive_zero_claim_sessions >= ZERO_CLAIM_BACKPRESSURE_THRESHOLD:
            logger.error(
                "%d consecutive zero-claim sessions detected, possible backend degradation",
                self._consecutive_zero_claim_sessions,
            )
            await asyncio.sleep(30)
        if self._consecutive_zero_claim_sessions >= ZERO_CLAIM_ABORT_THRESHOLD:
            metrics = self._ingest_metrics[conversation_id]
            metrics.failed = True
            metrics.failure_reason = (
                "5 consecutive zero-claim sessions detected, aborting conversation"
            )
            self._failed_conversations.add(conversation_id)
            logger.error(
                "Aborting conversation %s after %d consecutive zero-claim sessions",
                conversation_id,
                self._consecutive_zero_claim_sessions,
            )
            return True
        return False

    def _record_non_zero_claim_session(self) -> None:
        self._consecutive_zero_claim_sessions = 0

    async def _apply_ingest_observability(
        self,
        *,
        conversation_id: str,
        session_id: str,
        claims_stored: int,
        owner_id_used: Optional[str],
    ) -> bool:
        metrics = self._get_ingest_metrics(conversation_id, owner_id_used=owner_id_used)
        metrics.sessions_attempted += 1
        metrics.total_claims_ingested += max(0, int(claims_stored or 0))
        if claims_stored <= 0:
            metrics.zero_claim_sessions += 1
            should_abort = await self._record_zero_claim_session(conversation_id)
        else:
            self._record_non_zero_claim_session()
            should_abort = False

        if metrics.total_claims_ingested < MIN_CONVERSATION_CLAIMS:
            metrics.degraded = True
            logger.warning(
                "Conversation %s ingested only %d claims after session %s; marking degraded",
                conversation_id,
                metrics.total_claims_ingested,
                session_id,
            )
        else:
            metrics.degraded = False

        if self.fail_on_empty and metrics.total_claims_ingested == 0:
            raise RuntimeError(
                f"Conversation {conversation_id} ingested zero claims; aborting because --fail-on-empty is set"
            )

        return should_abort

    def _record_ingest_error(self, conversation_id: str, owner_id_used: Optional[str]) -> None:
        metrics = self._get_ingest_metrics(conversation_id, owner_id_used=owner_id_used)
        metrics.sessions_attempted += 1
        metrics.remember_errors += 1

    # ------------------------------------------------------------------
    # Public runners
    # ------------------------------------------------------------------

    async def run_locomo(
        self,
        path: Optional[str] = None,
        dataset_dict: Optional[Dict[str, Any]] = None,
    ) -> EvalReport:
        """
        Run evaluation on a LoCoMo dataset.

        Args:
            path: Path to LoCoMo JSON file. If None uses bundled sample.
            dataset_dict: Pre-parsed dataset dict (alternative to path).

        Returns:
            EvalReport
        """
        from .locomo import LoCoMoLoader, LoCoMoDataset

        loader = LoCoMoLoader()
        if dataset_dict is not None:
            dataset = loader.load_dict(dataset_dict)
        else:
            dataset = loader.load(path)

        logger.info("Running LoCoMo eval on %d sessions", len(dataset.sessions))
        self._last_dataset_name = dataset.name
        self._session_results = []
        self._ingest_metrics = {}
        self._failed_conversations = set()
        self._consecutive_zero_claim_sessions = 0

        for session in dataset.sessions:
            if self._shutdown_requested:
                logger.warning("Shutdown requested; stopping after %d completed sessions", len(self._session_results))
                break
            sr = await self._eval_locomo_session(session)
            self._session_results.append(sr)

        return self._build_report(dataset.name, self._session_results)

    async def run_locomo_dataset(
        self,
        dataset: "LoCoMoDataset",
    ) -> "EvalReport":
        """
        Run evaluation on a pre-loaded LoCoMoDataset object.

        When the dataset contains conversation-level objects (native format),
        QA pairs are evaluated at the conversation level -- after ingesting ALL
        sessions -- so that questions about any session can retrieve claims from
        any other session in the same conversation.

        Args:
            dataset: An already-loaded LoCoMoDataset.

        Returns:
            EvalReport
        """
        self._last_dataset_name = dataset.name
        self._session_results = []
        self._ingest_metrics = {}
        self._failed_conversations = set()
        self._consecutive_zero_claim_sessions = 0

        # Native format: use conversation-level evaluation
        conversations = dataset.conversations
        if conversations:
            logger.info(
                "Running LoCoMo eval on %d conversations (%d total sessions, conversation-level QA)",
                len(conversations),
                len(dataset.sessions),
            )
            for conv in conversations:
                if self._shutdown_requested:
                    logger.warning("Shutdown requested; stopping after %d completed sessions", len(self._session_results))
                    break
                session_results = await self._eval_locomo_conversation(conv)
                self._session_results.extend(session_results)
        else:
            # Internal format: per-session QA (legacy path)
            logger.info("Running LoCoMo eval on %d sessions (pre-loaded)", len(dataset.sessions))
            for session in dataset.sessions:
                if self._shutdown_requested:
                    logger.warning("Shutdown requested; stopping after %d completed sessions", len(self._session_results))
                    break
                sr = await self._eval_locomo_session(session)
                self._session_results.append(sr)

        return self._build_report(dataset.name, self._session_results)

    async def run_longmemeval(
        self,
        path: Optional[str] = None,
        dataset_dict: Optional[Dict[str, Any]] = None,
    ) -> EvalReport:
        """
        Run evaluation on a LongMemEval dataset.

        Args:
            path: Path to LongMemEval JSON file. If None uses bundled sample.
            dataset_dict: Pre-parsed dataset dict (alternative to path).

        Returns:
            EvalReport
        """
        from .longmemeval import LongMemEvalLoader, LongMemEvalDataset

        loader = LongMemEvalLoader()
        if dataset_dict is not None:
            dataset = loader.load_dict(dataset_dict)
        else:
            dataset = loader.load(path)

        logger.info("Running LongMemEval on %d sessions", len(dataset.sessions))
        self._last_dataset_name = dataset.name
        self._session_results = []
        self._ingest_metrics = {}
        self._failed_conversations = set()
        self._consecutive_zero_claim_sessions = 0

        for session in dataset.sessions:
            if self._shutdown_requested:
                logger.warning("Shutdown requested; stopping after %d completed sessions", len(self._session_results))
                break
            sr = await self._eval_longmemeval_session(session)
            self._session_results.append(sr)

        return self._build_report(dataset.name, self._session_results)


    def request_shutdown(self) -> None:
        """Ask the harness to stop after the current in-flight operation."""
        self._shutdown_requested = True

    def build_partial_report(self) -> EvalReport:
        """Build a report from completed sessions collected so far."""
        dataset_name = self._last_dataset_name or "partial-eval"
        report = self._build_report(dataset_name, list(self._session_results))
        report.run_status = "interrupted"
        report.interrupted = True
        return report

    async def _remember_with_retry(self, *, conversation: Any, session_id: str, **kwargs: Any) -> Any:
        delays = (2, 4, 8)
        total_attempts = len(delays) + 1
        last_exc: Optional[Exception] = None
        for attempt in range(1, total_attempts + 1):
            try:
                return await self.plugin.remember(conversation=conversation, session_id=session_id, **kwargs)
            except Exception as exc:
                last_exc = exc
                if attempt > len(delays):
                    break
                delay = delays[attempt - 1]
                logger.warning(
                    "Session %s remember() failed (attempt %d/%d), retrying in %ss...",
                    session_id,
                    attempt,
                    total_attempts,
                    delay,
                )
                await asyncio.sleep(delay)
        assert last_exc is not None
        raise last_exc

    def _record_session_failure(self, session_id: str, exc: Exception) -> None:
        self._consecutive_session_failures += 1
        if self._consecutive_session_failures >= self.max_session_failures:
            raise RuntimeError(
                f"Aborting eval after {self._consecutive_session_failures} consecutive session failures; "
                f"last failed session was {session_id}: {exc}"
            ) from exc

    def _record_session_success(self) -> None:
        self._consecutive_session_failures = 0

    def _validate_remember_result(self, remember_result: Any, session_id: str) -> None:
        if remember_result is None:
            raise RuntimeError(f"remember() returned None for session {session_id}")
        result_session_id = getattr(remember_result, "session_id", None)
        if not isinstance(result_session_id, str) or not result_session_id.strip():
            raise RuntimeError(
                f"remember() returned an invalid result for session {session_id}: missing session_id"
            )

    def _safe_score(self, value: Any, *, default: float = 0.0) -> float:
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            return default
        return numeric if math.isfinite(numeric) else default

    # ------------------------------------------------------------------
    # Session-level evaluation
    # ------------------------------------------------------------------

    async def _eval_locomo_session(self, session: Any) -> SessionResult:
        """Evaluate a single LoCoMo session."""
        session_id = getattr(session, "session_id", None)
        if not isinstance(session_id, str) or not session_id.strip():
            raise ValueError("LoCoMo session is missing a non-empty session_id")
        qa_pairs = getattr(session, "qa_pairs", None)
        if qa_pairs is None:
            raise ValueError(f"LoCoMo session {session_id} is missing qa_pairs")
        sr = SessionResult(session_id=session_id)

        # Per-conversation owner isolation: each session gets its own owner_id
        conv_owner = self._conversation_owner_id(session_id)

        # 1. Remember the conversation
        t0 = time.perf_counter()
        try:
            # Pass session metadata for v2 prompt temporal resolution
            _session_date = getattr(session, "session_date", None)
            _speaker_a = None
            _speaker_b = None
            # Try to get speaker names from parent conversation
            if hasattr(session, "_conversation_ref"):
                _speaker_a = getattr(session._conversation_ref, "speaker_a", None)
                _speaker_b = getattr(session._conversation_ref, "speaker_b", None)

            remember_result = await self._remember_with_retry(
                conversation=session.messages,
                session_id=session_id,
                session_date=_session_date or None,
                speaker_a=_speaker_a,
                speaker_b=_speaker_b,
                owner_id=conv_owner,
            )
            self._validate_remember_result(remember_result, session_id)
            sr.remember_latency_ms = (time.perf_counter() - t0) * 1000
            sr.claims_stored = getattr(remember_result, "claims_stored", 0)
            # Log claims extracted for debugging (#1273)
            claims_extracted = getattr(remember_result, "claims_extracted", 0)
            if claims_extracted == 0 and len(session.messages) > 0:
                logger.warning(
                    "claims_extracted=0 for session %s with %d messages. "
                    "Check that the plugin has an LLM provider wired for extraction.",
                    session_id, len(session.messages),
                )
        except Exception as exc:
            sr.remember_latency_ms = (time.perf_counter() - t0) * 1000
            sr.remember_error = str(exc)
            logger.warning("remember() failed for session %s: %s", session_id, exc)
            self._record_ingest_error(session_id, conv_owner)
            self._record_session_failure(session_id, exc)
        else:
            self._record_session_success()
            should_abort_conversation = await self._apply_ingest_observability(
                conversation_id=session_id,
                session_id=session_id,
                claims_stored=sr.claims_stored,
                owner_id_used=conv_owner,
            )
            if should_abort_conversation:
                return sr

        # 2. Evaluate each QA pair
        for qa in qa_pairs:
            if self._shutdown_requested:
                break
            category = getattr(qa, "category", 0)
            qr = await self._eval_question(
                question_id=qa.question_id,
                question=qa.question,
                expected_answer=qa.answer,
                remember_latency_ms=sr.remember_latency_ms,
                category=category,
                _owner_id_override=conv_owner,
            )
            sr.question_results.append(qr)

        return sr

    async def _eval_locomo_conversation(self, conv: Any) -> List[SessionResult]:
        """Evaluate a full LoCoMo conversation: ingest all sessions, then evaluate QA.

        Returns a list of SessionResult objects -- one per session (for ingestion
        stats) plus one synthetic result for the conversation-level QA pairs.
        """
        session_results: List[SessionResult] = []

        # Per-conversation owner isolation
        conversation_id = conv.sample_id
        conv_owner = self._conversation_owner_id(conversation_id)
        self._get_ingest_metrics(conversation_id, owner_id_used=conv_owner)

        # 1. Ingest all sessions (remember phase)
        for session in conv.sessions:
            if self._shutdown_requested:
                break
            session_id = session.session_id
            sr = SessionResult(session_id=session_id)
            t0 = time.perf_counter()
            should_abort_conversation = False
            try:
                _session_date = getattr(session, "session_date", None)
                remember_result = await self._remember_with_retry(
                    conversation=session.messages,
                    session_id=session_id,
                    session_date=_session_date or None,
                    speaker_a=getattr(conv, "speaker_a", None),
                    speaker_b=getattr(conv, "speaker_b", None),
                    owner_id=conv_owner if conv_owner is not None else (self.owner_id or None),
                )
                self._validate_remember_result(remember_result, session_id)
                sr.remember_latency_ms = (time.perf_counter() - t0) * 1000
                sr.claims_stored = getattr(remember_result, "claims_stored", 0)
                claims_extracted = getattr(remember_result, "claims_extracted", 0)
                if claims_extracted == 0 and len(session.messages) > 0:
                    logger.warning(
                        "claims_extracted=0 for session %s with %d messages.",
                        session_id, len(session.messages),
                    )
            except Exception as exc:
                sr.remember_latency_ms = (time.perf_counter() - t0) * 1000
                sr.remember_error = str(exc)
                logger.warning("remember() failed for session %s: %s", session_id, exc)
                self._record_ingest_error(conversation_id, conv_owner if conv_owner is not None else (self.owner_id or None))
                self._record_session_failure(session_id, exc)
            else:
                self._record_session_success()
                should_abort_conversation = await self._apply_ingest_observability(
                    conversation_id=conversation_id,
                    session_id=session_id,
                    claims_stored=sr.claims_stored,
                    owner_id_used=conv_owner if conv_owner is not None else (self.owner_id or None),
                )
            session_results.append(sr)
            if should_abort_conversation:
                break

        # 2. Evaluate conversation-level QA pairs against ALL ingested sessions
        qa_pairs = getattr(conv, "qa_pairs", [])
        if qa_pairs and not self._shutdown_requested and conversation_id not in self._failed_conversations:
            qa_sr = SessionResult(session_id=f"{conv.sample_id}_qa")
            avg_remember_latency = (
                sum(sr.remember_latency_ms for sr in session_results) / len(session_results)
                if session_results else 0.0
            )
            for qa in qa_pairs:
                if self._shutdown_requested:
                    break
                category = getattr(qa, "category", 0)
                qr = await self._eval_question(
                    question_id=qa.question_id,
                    question=qa.question,
                    expected_answer=qa.answer,
                    remember_latency_ms=avg_remember_latency,
                    category=category,
                    _owner_id_override=conv_owner,
                )
                qa_sr.question_results.append(qr)
            session_results.append(qa_sr)

        return session_results

    async def _eval_longmemeval_session(self, session: Any) -> SessionResult:
        """Evaluate a single LongMemEval session."""
        session_id = getattr(session, "session_id", None)
        if not isinstance(session_id, str) or not session_id.strip():
            raise ValueError("LongMemEval session is missing a non-empty session_id")
        questions = getattr(session, "questions", None)
        if questions is None:
            raise ValueError(f"LongMemEval session {session_id} is missing questions")
        sr = SessionResult(session_id=session_id)

        # Per-conversation owner isolation
        conv_owner = self._conversation_owner_id(session_id)

        # 1. Remember the conversation
        t0 = time.perf_counter()
        _session_date = getattr(session, "session_date", None)
        try:
            remember_result = await self._remember_with_retry(
                conversation=session.conversation,
                session_id=session_id,
                owner_id=conv_owner,
                session_date=_session_date or None,
            )
            self._validate_remember_result(remember_result, session_id)
            sr.remember_latency_ms = (time.perf_counter() - t0) * 1000
            sr.claims_stored = getattr(remember_result, "claims_stored", 0)
        except Exception as exc:
            sr.remember_latency_ms = (time.perf_counter() - t0) * 1000
            sr.remember_error = str(exc)
            logger.warning("remember() failed for session %s: %s", session_id, exc)
            self._record_ingest_error(session_id, conv_owner)
            self._record_session_failure(session_id, exc)
        else:
            self._record_session_success()
            should_abort_conversation = await self._apply_ingest_observability(
                conversation_id=session_id,
                session_id=session_id,
                claims_stored=sr.claims_stored,
                owner_id_used=conv_owner,
            )
            if should_abort_conversation:
                return sr

        # 2. Evaluate each question
        for q in questions:
            if self._shutdown_requested:
                break
            # Map LongMemEval abstention questions to adversarial (category 5)
            # so they use refusal scoring (#1278)
            category = 5 if getattr(q, "is_abstention", False) else 0
            qr = await self._eval_question(
                question_id=q.question_id,
                question=q.question,
                expected_answer=q.answer,
                remember_latency_ms=sr.remember_latency_ms,
                category=category,
                _owner_id_override=conv_owner,
            )
            sr.question_results.append(qr)

        return sr

    async def _eval_question(
        self,
        question_id: str,
        question: str,
        expected_answer: str,
        remember_latency_ms: float,
        category: int = 0,
        _owner_id_override: Optional[str] = None,
    ) -> QuestionResult:
        """Run retrieve() for a single question and score the result.

        Args:
            _owner_id_override: If set, use this owner_id for retrieve() instead
                of ``self.owner_id``.  Used by per-conversation isolation so
                retrieve() queries the same namespace that remember() wrote to.
        """
        if not isinstance(question_id, str) or not question_id.strip():
            raise ValueError("Question is missing a non-empty question_id")
        if not isinstance(question, str) or not question.strip():
            raise ValueError(f"Question {question_id} is missing non-empty question text")
        if expected_answer is None:
            raise ValueError(f"Question {question_id} is missing an answer")
        expected_answer = str(expected_answer)
        predicted_answer = ""
        retrieve_latency_ms = 0.0
        error = None
        result = None

        # Use conversation-scoped owner if provided, else fall back to run-level
        effective_owner = _owner_id_override if _owner_id_override is not None else (self.owner_id or None)

        predicted_context = ""
        t0 = time.perf_counter()
        try:
            result = await self.plugin.retrieve(query=question, owner_id=effective_owner)
            retrieve_latency_ms = (time.perf_counter() - t0) * 1000
            if result is None:
                raise RuntimeError(f"retrieve() returned None for question {question_id}")
            # Full concatenated context (for debugging / RAG generation)
            predicted_context = self._extract_answer(result, question)
            # Best-single-claim scoring: score each candidate individually
            candidates = self._extract_answer_candidates(result)
            best_f1 = 0.0
            best_candidate = ""
            for candidate in candidates:
                cf1 = token_f1_score(candidate, expected_answer)
                if cf1 > best_f1:
                    best_f1 = cf1
                    best_candidate = candidate
            predicted_answer = best_candidate if best_candidate else predicted_context
        except Exception as exc:
            retrieve_latency_ms = (time.perf_counter() - t0) * 1000
            error = str(exc)
            logger.warning("retrieve() failed for question %s: %s", question_id, exc)

        # Score (retrieval-only metrics) — on the single best claim
        exact_hit = exact_match(predicted_answer, expected_answer)
        fuzzy_hit = fuzzy_match(predicted_answer, expected_answer, self.fuzzy_threshold)
        f1 = token_f1_score(predicted_answer, expected_answer)

        llm_score = None
        if self.llm_judge is not None:
            try:
                llm_score = self.llm_judge(question, predicted_answer, expected_answer)
            except Exception as exc:
                logger.warning("LLM judge failed for %s: %s", question_id, exc)

        # Gemini LLM judge (AMB-compatible binary scoring)
        # When judge is enabled, ALWAYS generate a RAG answer first (AMB parity).
        # The RAG answer goes to the judge; token F1 still scores against raw claims.
        judge_correct = None
        judge_reasoning = None
        judge_error = None
        rag_answer = None  # May be set by judge path below or RAG mode path later
        if self.gemini_judge is not None:
            try:
                # Step 1: Generate RAG answer from ALL retrieved claims
                judge_rag_answer = predicted_answer  # fallback: raw claim text
                if result is not None:
                    claims = self._extract_claims(result)
                    if claims:
                        rag_gen_answer = await self._generate_rag_answer(
                            question=question,
                            claims=claims,
                            result=result,
                        )
                        if rag_gen_answer:
                            judge_rag_answer = rag_gen_answer
                            # Store the RAG answer in the result (for output/debugging)
                            rag_answer = rag_gen_answer

                # Step 2: Judge the RAG answer (not raw claims)
                verdict = self.gemini_judge.judge(question, judge_rag_answer, expected_answer)
                judge_correct = verdict.correct
                judge_reasoning = verdict.reasoning
                judge_error = verdict.error
            except Exception as exc:
                logger.warning("Gemini judge failed for %s: %s", question_id, exc)
                judge_error = f"judge_error: {exc}"

        # Adversarial scoring for ALL modes (#1274): category 5 questions
        # are scored on whether the system correctly refuses to answer,
        # not on match against the expected answer.
        if category == 5:
            adv_score = adversarial_accuracy(predicted_answer)
            # Override retrieval-only metrics for adversarial questions
            exact_hit = adv_score == 1.0
            fuzzy_hit = adv_score == 1.0
            f1 = adv_score

        # RAG mode: generate answer then judge
        # rag_answer may already be set by the Gemini judge path above;
        # the RAG mode block below uses its own generation path (with
        # confidence-aware refusal) and overwrites rag_answer if active.
        rag_judge_score = None
        rag_judge_reasoning = None

        if self.mode in ("rag", "full") and self.llm is not None:
            try:
                # Extract claims as list of strings for generation
                claims = self._extract_claims(result) if result else []
                scores = self._extract_scores(result) if result else []
                gen_result = await generate_answer(
                    question=question,
                    retrieved_claims=claims,
                    llm=self.llm,
                    model=self.judge_model,
                    retrieval_scores=scores if scores else None,
                    confidence_threshold=self.confidence_threshold,
                )
                rag_answer = gen_result.answer

                # For adversarial (category 5): score based on "no info" response
                if category == 5:
                    rag_judge_score = adversarial_accuracy(rag_answer)
                    rag_judge_reasoning = (
                        "Adversarial: correctly refused" if rag_judge_score == 1.0
                        else "Adversarial: should have refused"
                    )
                else:
                    judge_result = await judge_answer(
                        question=question,
                        prediction=rag_answer,
                        ground_truth=expected_answer,
                        llm=self.llm,
                        model=self.judge_model,
                    )
                    rag_judge_score = judge_result.score
                    rag_judge_reasoning = judge_result.reasoning
            except Exception as exc:
                logger.warning("RAG generation/judging failed for %s: %s", question_id, exc)

        return QuestionResult(
            question_id=question_id,
            question=question,
            expected_answer=expected_answer,
            predicted_answer=predicted_answer,
            predicted_context=predicted_context or None,
            exact_hit=exact_hit,
            fuzzy_hit=fuzzy_hit,
            token_f1=f1,
            llm_judge_score=llm_score,
            remember_latency_ms=remember_latency_ms,
            retrieve_latency_ms=retrieve_latency_ms,
            error=error,
            rag_answer=rag_answer,
            rag_judge_score=rag_judge_score,
            rag_judge_reasoning=rag_judge_reasoning,
            category=category,
            judge_correct=judge_correct,
            judge_reasoning=judge_reasoning,
            judge_error=judge_error,
        )

    # ------------------------------------------------------------------
    # RAG answer generation for judge mode
    # ------------------------------------------------------------------

    async def _generate_rag_answer(
        self,
        question: str,
        claims: List[str],
        result: Any = None,
    ) -> Optional[str]:
        """Generate a RAG answer from retrieved claims for judge evaluation.

        Uses the plugin's LLM if available, otherwise falls back to a
        simple concatenation of claims. The prompt follows AMB's LoCoMo
        RAG generation style.

        Returns the generated answer string, or None if generation fails.
        """
        if not claims:
            return None

        # Build context from ALL retrieved claims
        context = "\n".join(f"- {c}" for c in claims)

        # Try to use the plugin's LLM for answer generation
        llm = self.llm or getattr(self.plugin, "llm", None)
        if llm is None:
            # No LLM available — fall back to concatenated claims
            logger.debug("No LLM for RAG answer generation, using concatenated claims")
            return " ".join(claims)

        # AMB-style RAG generation prompt
        prompt = f"""You are a helpful assistant. Answer the following question based ONLY on the provided context.
If the context doesn't contain enough information to answer, say "I don't have enough information to answer this question."

Context:
{context}

Question: {question}

Think step by step about what the context says, then provide your answer.
Respond with JSON: {{"reasoning": "your step-by-step reasoning", "answer": "your concise answer"}}"""

        try:
            resp = await llm.complete(
                system="You are a factual QA system. Answer based only on provided context. Be concise. Respond with JSON.",
                user=prompt,
            )
            text = resp.text if hasattr(resp, "text") else str(resp)
            text = text.strip()

            # Try to parse structured JSON response
            import json as _json
            try:
                # Strip markdown code fences if present
                if text.startswith("```"):
                    lines = text.split("\n")
                    lines = [l for l in lines if not l.strip().startswith("```")]
                    text = "\n".join(lines).strip()
                parsed = _json.loads(text)
                return str(parsed.get("answer", text))
            except (_json.JSONDecodeError, TypeError):
                # Fall back to raw text response
                return text

        except Exception as exc:
            logger.warning("RAG answer generation failed: %s", exc)
            # Fall back to concatenated claims
            return " ".join(claims)

    # ------------------------------------------------------------------
    # Claim extraction for RAG generation
    # ------------------------------------------------------------------

    def _extract_claims(self, result: Any) -> List[str]:
        """Extract individual claim strings from retrieval result for RAG generation."""
        if result is None:
            return []

        # RetrievalResult.items — list of RetrievedItem with .content
        if hasattr(result, "items") and result.items:
            claims = []
            for item in result.items[: self.max_retrieved]:
                if hasattr(item, "content") and item.content:
                    claims.append(str(item.content))
                elif isinstance(item, dict):
                    claims.append(str(item.get("content", item)))
                else:
                    claims.append(str(item))
            return claims

        # RetrievalResult.memories — list of memory objects
        if hasattr(result, "memories") and result.memories:
            claims = []
            for mem in result.memories[: self.max_retrieved]:
                if hasattr(mem, "content"):
                    claims.append(str(mem.content))
                elif isinstance(mem, dict):
                    claims.append(str(mem.get("content", mem)))
                else:
                    claims.append(str(mem))
            return claims

        # Fallback: formatted_context as single claim
        if hasattr(result, "formatted_context") and result.formatted_context:
            return [result.formatted_context]

        text = str(result) if result else ""
        return [text] if text else []

    # ------------------------------------------------------------------
    # Score extraction from RetrievalResult (#1275)
    # ------------------------------------------------------------------

    def _extract_scores(self, result: Any) -> List[float]:
        """Extract similarity scores from retrieval result for confidence-aware refusal."""
        if result is None:
            return []

        # RetrievalResult.items — list of RetrievedItem objects with .score
        if hasattr(result, "items") and result.items:
            scores = [self._safe_score(getattr(item, "score", 0.0), default=float("nan")) for item in result.items[:self.max_retrieved]]
            return [score for score in scores if math.isfinite(score)]

        # RetrievalResult.memories — list of memory objects
        if hasattr(result, "memories") and result.memories:
            scores = []
            for mem in result.memories[:self.max_retrieved]:
                if hasattr(mem, "score"):
                    score = self._safe_score(mem.score, default=float("nan"))
                elif isinstance(mem, dict) and "score" in mem:
                    score = self._safe_score(mem["score"], default=float("nan"))
                else:
                    continue
                if math.isfinite(score):
                    scores.append(score)
            return scores

        return []

    # ------------------------------------------------------------------
    # Answer extraction from RetrievalResult
    # ------------------------------------------------------------------

    def _extract_answer(self, result: Any, question: str) -> str:
        """
        Extract a text answer from the plugin's RetrievalResult.

        Tries common attribute patterns; falls back to str().
        """
        if result is None:
            return ""

        # RetrievalResult.items — list of RetrievedItem with .content
        # This is the primary path for Cortex v3 RetrievalPipeline output.
        if hasattr(result, "items") and result.items:
            parts = []
            for item in result.items[: self.max_retrieved]:
                if hasattr(item, "content") and item.content:
                    parts.append(str(item.content))
                elif isinstance(item, dict):
                    parts.append(str(item.get("content", item)))
                else:
                    parts.append(str(item))
            return " ".join(parts)

        # RetrievalResult.formatted_context — the injected memory text
        if hasattr(result, "formatted_context") and result.formatted_context:
            return result.formatted_context

        # RetrievalResult.memories — list of memory objects
        if hasattr(result, "memories") and result.memories:
            parts = []
            for mem in result.memories[: self.max_retrieved]:
                if hasattr(mem, "content"):
                    parts.append(str(mem.content))
                elif isinstance(mem, dict):
                    parts.append(str(mem.get("content", mem)))
                else:
                    parts.append(str(mem))
            return " ".join(parts)

        # RetrievalResult.context_window / text / answer
        for attr in ("context_window", "text", "answer", "content"):
            val = getattr(result, attr, None)
            if val:
                return str(val)

        return str(result) if result else ""

    def _extract_answer_candidates(self, result: Any) -> list[str]:
        """Extract individual claim strings from a retrieval result.

        Unlike ``_extract_answer()`` which joins everything into one string,
        this returns each retrieved claim as a separate candidate so that
        scoring can pick the single best match.
        """
        if result is None:
            return []

        # RetrievalResult.items — list of RetrievedItem with .content
        if hasattr(result, "items") and result.items:
            candidates = []
            for item in result.items[: self.max_retrieved]:
                if hasattr(item, "content") and item.content:
                    candidates.append(str(item.content))
                elif isinstance(item, dict) and item.get("content"):
                    candidates.append(str(item["content"]))
                elif item:
                    candidates.append(str(item))
            return candidates

        # RetrievalResult.formatted_context — single blob
        if hasattr(result, "formatted_context") and result.formatted_context:
            return [result.formatted_context]

        # RetrievalResult.memories — list of memory objects
        if hasattr(result, "memories") and result.memories:
            candidates = []
            for mem in result.memories[: self.max_retrieved]:
                if hasattr(mem, "content") and mem.content:
                    candidates.append(str(mem.content))
                elif isinstance(mem, dict) and mem.get("content"):
                    candidates.append(str(mem["content"]))
                elif mem:
                    candidates.append(str(mem))
            return candidates

        # Fallback scalar attributes
        for attr in ("context_window", "text", "answer", "content"):
            val = getattr(result, attr, None)
            if val:
                return [str(val)]

        val = str(result) if result else ""
        return [val] if val else []

    # ------------------------------------------------------------------
    # Report builder
    # ------------------------------------------------------------------

    def _build_report(
        self,
        dataset_name: str,
        session_results: List[SessionResult],
    ) -> EvalReport:
        """Aggregate session results into an EvalReport."""
        all_question_results = [
            qr
            for sr in session_results
            for qr in sr.question_results
        ]

        n = len(all_question_results)
        predictions = [r.predicted_answer for r in all_question_results]
        references = [r.expected_answer for r in all_question_results]
        questions = [r.question for r in all_question_results]

        # QA accuracy metrics (do NOT pass llm_judge here — scores already collected per-question)
        qa_metrics = compute_qa_metrics(
            predictions=predictions,
            references=references,
            fuzzy_threshold=self.fuzzy_threshold,
            llm_judge=None,
            questions=questions,
        )

        # LoCoMo category-aware QA scoring: keep avg_token_f1 for backward compat,
        # but add the benchmark-correct primary metric and per-category breakdowns.
        _SUPPORTED_CATEGORIES = {1, 2, 3, 4, 5}
        category_scores: Dict[int, List[float]] = {}
        for r in all_question_results:
            if r.category not in _SUPPORTED_CATEGORIES:
                continue
            score = score_by_category(r.predicted_answer, r.expected_answer, r.category)
            category_scores.setdefault(r.category, []).append(score)

        if category_scores:
            qa_metrics.update({
                f"category_{category}_f1": sum(scores) / len(scores)
                for category, scores in sorted(category_scores.items())
            })
            all_category_scores = [score for scores in category_scores.values() for score in scores]
            qa_metrics["avg_category_f1"] = sum(all_category_scores) / len(all_category_scores)

        # Aggregate claims across sessions (#1273)
        total_claims_stored = sum(sr.claims_stored for sr in session_results)
        qa_metrics["total_claims_stored"] = total_claims_stored
        qa_metrics["total_claims_extracted"] = total_claims_stored  # compat alias

        # Adversarial accuracy aggregate (#1274): compute across ALL modes
        adversarial_results = [r for r in all_question_results if r.category == 5]
        if adversarial_results:
            adv_scores = [adversarial_accuracy(r.predicted_answer) for r in adversarial_results]
            qa_metrics["adversarial_accuracy"] = sum(adv_scores) / len(adv_scores)
            qa_metrics["adversarial_n"] = len(adversarial_results)

        # Aggregate cached LLM judge scores if available
        llm_scores = [
            self._safe_score(r.llm_judge_score, default=float("nan"))
            for r in all_question_results
            if r.llm_judge_score is not None
        ]
        llm_scores = [score for score in llm_scores if math.isfinite(score)]
        if llm_scores:
            qa_metrics["avg_llm_judge_score"] = sum(llm_scores) / len(llm_scores)

        # Gemini judge aggregate metrics (AMB-compatible binary scoring)
        # Exclude questions with judge errors from accuracy calculation
        judge_results = [
            r for r in all_question_results
            if r.judge_correct is not None and r.judge_error is None
        ]
        judge_errors = [r for r in all_question_results if r.judge_error is not None]
        judge_error_count = len(judge_errors)
        if judge_results:
            judge_correct_count = sum(1 for r in judge_results if r.judge_correct)
            qa_metrics["judge_accuracy"] = judge_correct_count / len(judge_results)
            qa_metrics["judge_correct_count"] = judge_correct_count
            qa_metrics["judge_total"] = len(judge_results)
        if judge_error_count:
            qa_metrics["judge_errors"] = judge_error_count

        # RAG judge aggregate metrics
        rag_scores = [
            self._safe_score(r.rag_judge_score, default=float("nan"))
            for r in all_question_results
            if r.rag_judge_score is not None
        ]
        rag_scores = [score for score in rag_scores if math.isfinite(score)]
        if rag_scores:
            qa_metrics["rag_judge_accuracy"] = sum(rag_scores) / len(rag_scores)
            qa_metrics["rag_judge_n"] = len(rag_scores)

            # Per-category breakdown
            cat_scores: Dict[int, List[float]] = {}
            for r in all_question_results:
                if r.rag_judge_score is not None and r.category > 0:
                    score = self._safe_score(r.rag_judge_score, default=float("nan"))
                    if math.isfinite(score):
                        cat_scores.setdefault(r.category, []).append(score)
            if cat_scores:
                qa_metrics["rag_judge_by_category"] = {
                    cat: sum(scores) / len(scores)
                    for cat, scores in sorted(cat_scores.items())
                }

        # MRR: treat fuzzy hit as binary relevance signal
        # Each query gets a ranked list of [predicted_answer]; if fuzzy hit → rank 1, else empty
        ranked_lists = []
        relevant_sets = []
        for r in all_question_results:
            if r.fuzzy_hit:
                ranked_lists.append([r.predicted_answer])
                relevant_sets.append({r.predicted_answer})
            else:
                ranked_lists.append([r.predicted_answer])
                relevant_sets.append({r.expected_answer})

        mrr = mean_reciprocal_rank(ranked_lists, relevant_sets)

        # Latency stats
        retrieve_latencies = [r.retrieve_latency_ms for r in all_question_results]
        remember_latencies = [sr.remember_latency_ms for sr in session_results]

        metrics = {
            **qa_metrics,
            "mrr": mrr,
            "total_questions": n,
            "total_sessions": len(session_results),
            "retrieve_latency": latency_stats(retrieve_latencies),
            "remember_latency": latency_stats(remember_latencies),
        }

        # Retrieval-style P/R/F1 if we treat exact hits as relevant
        # (over all questions combined)
        exact_predicted = [r.predicted_answer for r in all_question_results if r.exact_hit]
        exact_expected = [r.expected_answer for r in all_question_results]
        if exact_expected:
            prf = precision_recall_f1(
                [r.question_id for r in all_question_results if r.exact_hit],
                [r.question_id for r in all_question_results],
            )
            metrics["retrieval_precision"] = prf["precision"]
            metrics["retrieval_recall"] = prf["recall"]
            metrics["retrieval_f1"] = prf["f1"]

        degraded_conversations = [
            cid for cid, ingest in self._ingest_metrics.items() if ingest.degraded
        ]
        failed_conversations = sorted(self._failed_conversations)

        return EvalReport(
            dataset_name=dataset_name,
            session_results=session_results,
            metrics=metrics,
            config={
                "fuzzy_threshold": self.fuzzy_threshold,
                "llm_judge": self.llm_judge is not None,
                "gemini_judge": self.gemini_judge is not None,
                "gemini_judge_prompt": getattr(self.gemini_judge, "prompt_style", None) if self.gemini_judge else None,
                "max_retrieved": self.max_retrieved,
                "mode": self.mode,
                "fail_on_empty": self.fail_on_empty,
            },
            run_status="completed",
            interrupted=False,
            ingest_metrics=dict(self._ingest_metrics),
            degraded_conversations=degraded_conversations,
            failed_conversations=failed_conversations,
        )
