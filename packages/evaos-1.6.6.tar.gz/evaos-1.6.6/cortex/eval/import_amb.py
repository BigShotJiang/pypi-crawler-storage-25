"""
cortex/eval/import_amb.py — Import AMB (Agent Memory Benchmark) results into unified schema.

Reads AMB EvalSummary JSON files and converts them to BenchmarkResult records
in runs_v2.jsonl.

Usage::

    python -m cortex.eval.import_amb /tmp/amb/outputs/locomo/cortex/rag/locomo10.json
    python -m cortex.eval.import_amb /path/to/amb_result.json --notes "Full locomo10 run"
    python -m cortex.eval.import_amb /path/to/amb_result.json --tag baseline --baseline
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Optional

from cortex.eval.run_logger import RunLogger, _make_run_id, _get_version, _get_git_sha, SCHEMA_VERSION


def _extract_amb_categories(results: list[dict]) -> dict:
    """Extract per-category breakdown from AMB query results."""
    categories: dict[str, dict[str, Any]] = {}
    for r in results:
        cat = r.get("category") or "uncategorized"
        if cat not in categories:
            categories[cat] = {"count": 0, "correct": 0}
        categories[cat]["count"] += 1
        if r.get("correct"):
            categories[cat]["correct"] += 1

    # Compute accuracy per category
    for cat_data in categories.values():
        total = cat_data["count"]
        cat_data["accuracy"] = cat_data["correct"] / total if total > 0 else 0.0

    return categories


def import_amb_result(
    amb_json_path: str,
    *,
    notes: str = "",
    tags: Optional[list[str]] = None,
    is_baseline: bool = False,
    source: str = "amb-import",
    git_sha: Optional[str] = None,
) -> dict[str, Any]:
    """Import an AMB EvalSummary JSON into unified runs_v2.jsonl.

    Returns the imported BenchmarkResult record.
    """
    path = Path(amb_json_path)
    if not path.exists():
        raise FileNotFoundError(f"AMB result file not found: {amb_json_path}")

    with open(path) as f:
        summary = json.load(f)

    # Map AMB fields → unified schema
    benchmark = summary.get("dataset", "locomo")
    split = summary.get("split", "unknown")
    mode = summary.get("mode", "rag")
    accuracy = summary.get("accuracy", 0.0)
    total_queries = summary.get("total_queries", 0)
    correct = summary.get("correct", 0)
    ingested_docs = summary.get("ingested_docs", 0)
    ingestion_time_ms = summary.get("ingestion_time_ms", 0)
    avg_retrieve_time_ms = summary.get("avg_retrieve_time_ms", 0)
    avg_context_tokens = summary.get("avg_context_tokens", 0)
    answer_llm = summary.get("answer_llm", "")
    judge_llm = summary.get("judge_llm", "")
    results_list = summary.get("results", [])

    scores: dict[str, Any] = {
        "judge_accuracy": accuracy,
    }

    # Extract per-category breakdown
    if results_list:
        scores["by_category"] = _extract_amb_categories(results_list)

    config_snapshot = {
        "generation": {"model": answer_llm},
        "judge": {"model": judge_llm, "enabled": True},
    }

    dataset_info = {
        "total_questions": total_queries,
        "correct": correct,
        "ingested_docs": ingested_docs,
        "avg_context_tokens": avg_context_tokens,
    }

    latency = {}
    if ingestion_time_ms:
        latency["ingestion_ms"] = ingestion_time_ms
    if avg_retrieve_time_ms:
        latency["retrieve"] = {"mean": avg_retrieve_time_ms}

    logger = RunLogger()
    record = logger.log_run_v2(
        harness="amb",
        benchmark=benchmark,
        scores=scores,
        config_snapshot=config_snapshot,
        dataset_variant=split,
        mode=mode,
        git_sha=git_sha or _get_git_sha(),
        source=source,
        is_baseline=is_baseline,
        notes=notes,
        tags=tags,
        dataset_info=dataset_info,
        latency=latency if latency else None,
    )

    return record


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="import-amb",
        description="Import AMB EvalSummary JSON into unified runs_v2.jsonl.",
    )
    parser.add_argument("path", help="Path to AMB EvalSummary JSON file")
    parser.add_argument("--notes", default="", help="Human-readable note about this run")
    parser.add_argument("--tag", action="append", default=[], dest="tags",
                        help="Add tag (repeatable)")
    parser.add_argument("--baseline", action="store_true",
                        help="Tag this as baseline for delta comparisons")
    parser.add_argument("--source", default="amb-import",
                        help="Source label (default: amb-import)")
    parser.add_argument("--json", action="store_true",
                        help="Output the imported record as JSON")

    args = parser.parse_args()

    try:
        record = import_amb_result(
            args.path,
            notes=args.notes,
            tags=args.tags if args.tags else None,
            is_baseline=args.baseline,
            source=args.source,
        )
        if args.json:
            print(json.dumps(record, indent=2, default=str))
        else:
            print(f"✅ Imported: {record['run_id']}")
            print(f"   Accuracy: {record['scores'].get('judge_accuracy', 0):.1%}")
            print(f"   Questions: {record.get('dataset_info', {}).get('total_questions', '?')}")
            print(f"   Appended to: {RunLogger().v2_file}")
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
