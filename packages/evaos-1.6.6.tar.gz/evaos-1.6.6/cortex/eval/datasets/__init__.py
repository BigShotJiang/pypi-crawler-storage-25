"""cortex/eval/datasets — Sample benchmark fixtures for testing."""
import pathlib

DATASETS_DIR = pathlib.Path(__file__).parent
