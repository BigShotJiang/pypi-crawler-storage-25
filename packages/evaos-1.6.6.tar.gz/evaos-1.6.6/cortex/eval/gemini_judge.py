"""
cortex/eval/gemini_judge.py — LLM-as-judge scoring using Gemini.

Uses the same prompt structure as AMB (memory_bench) for comparable results.
Calls Gemini via OpenAI-compatible API with structured JSON output.

Supports two judge prompt modes:
  - "strict" (default): AMB default strict evaluator prompt
  - "locomo": AMB LoCoMo-specific generous prompt (auto-detected for locomo benchmarks)
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

_SYSTEM_JUDGE_MESSAGE = (
    'You are an evaluation judge. Always respond with valid JSON: '
    '{"correct": true or false, "reason": "brief explanation"}'
)

# AMB-compatible strict judge prompt (default)
_STRICT_JUDGE_PROMPT = """\
You are a strict evaluator judging whether an AI system correctly answered a question.

Question:
{question}

Gold answers (at least one must be substantially matched):
{gold_answers}

System's answer:
{answer}

Evaluation rules — mark correct=false if ANY of these apply:
- The system says it cannot answer, doesn't know, or lacks enough information
- The system gives a vague or evasive answer instead of a concrete one
- The system's answer contradicts or omits key facts present in the gold answers
- The system hedges heavily without providing the actual answer

Mark correct=true only if the system's answer captures the essential facts from the gold answer. \
Minor wording differences and reasonable paraphrasing are fine.

Respond with JSON: {{"correct": true/false, "reason": "brief explanation"}}\
"""

# AMB LoCoMo-specific GENEROUS judge prompt (from AMB locomo.py build_judge_prompt)
_LOCOMO_JUDGE_PROMPT = """\
Your task is to label an answer to a question as 'CORRECT' or 'WRONG'. You will be given the following data:
    (1) a question (posed by one user to another user),
    (2) a 'gold' (ground truth) answer,
    (3) a generated answer
which you will score as CORRECT/WRONG.

The point of the question is to ask about something one user should know about the other user based on their prior conversations.
The gold answer will usually be a concise and short answer that includes the referenced topic, for example:
Question: Do you remember what I got the last time I went to Hawaii?
Gold answer: A shell necklace
The generated answer might be much longer, but you should be generous with your grading - as long as it touches on the same topic as the gold answer, it should be counted as CORRECT.

For time related questions, the gold answer will be a specific date, month, year, etc. The generated answer might be much longer or use relative time references (like "last Tuesday" or "next month"), but you should be generous with your grading - as long as it refers to the same date or time period as the gold answer, it should be counted as CORRECT. Even if the format differs (e.g., "May 7th" vs "7 May"), consider it CORRECT if it's the same date.
There's an edge case where the actual answer can't be found in the data and in that case the gold answer will say so (e.g. 'You did not mention this information.'); if the generated answer says that it cannot be answered or it doesn't know all the details, it should be counted as CORRECT.

Question: {question}
Gold answer: {gold_answers}
Generated answer: {answer}
First, provide a short (one sentence) explanation of your reasoning. Short reasoning is preferred.
If it's correct, set correct=true.
"""

# Backward compat alias
_JUDGE_PROMPT = _STRICT_JUDGE_PROMPT

# Map of prompt style names to templates
JUDGE_PROMPTS = {
    "strict": _STRICT_JUDGE_PROMPT,
    "locomo": _LOCOMO_JUDGE_PROMPT,
}

# Benchmarks that auto-select the locomo prompt
_LOCOMO_BENCHMARKS = {"locomo", "locomo-full", "locomo10"}


def resolve_judge_prompt_style(
    benchmark: Optional[str] = None,
    explicit_style: Optional[str] = None,
) -> str:
    """Determine which judge prompt style to use.

    Args:
        benchmark: Benchmark name (for auto-detection).
        explicit_style: Explicit style override ("strict" or "locomo").

    Returns:
        Prompt style name ("strict" or "locomo").
    """
    if explicit_style is not None:
        if explicit_style not in JUDGE_PROMPTS:
            raise ValueError(
                f"Unknown judge prompt style: {explicit_style!r}. "
                f"Valid options: {list(JUDGE_PROMPTS.keys())}"
            )
        return explicit_style

    # Auto-detect based on benchmark name
    if benchmark and benchmark.lower() in _LOCOMO_BENCHMARKS:
        return "locomo"

    return "strict"


@dataclass
class JudgeVerdict:
    """Result from a single LLM judge evaluation."""
    correct: bool
    reasoning: str
    error: Optional[str] = None


class GeminiJudge:
    """Calls Gemini via OpenAI-compatible API for binary CORRECT/WRONG judging."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-2.5-flash",
        base_url: str = "https://generativelanguage.googleapis.com/v1beta/openai/",
        max_retries: int = 1,
        prompt_style: str = "strict",
    ):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.model = model
        self.base_url = base_url
        self.max_retries = max_retries
        self.prompt_style = prompt_style
        self._prompt_template = JUDGE_PROMPTS.get(prompt_style, _STRICT_JUDGE_PROMPT)

        if not self.api_key:
            raise ValueError(
                "Gemini API key required for LLM judge. "
                "Pass --judge-api-key or set GEMINI_API_KEY."
            )

        logger.info("GeminiJudge initialized: model=%s, prompt_style=%s", model, prompt_style)

    def judge(self, question: str, predicted: str, gold_answer: str) -> JudgeVerdict:
        """Score a single question with the Gemini judge.

        Returns JudgeVerdict with correct=bool and reasoning string.
        On API errors, retries once then returns error verdict.
        """
        import httpx

        # For locomo prompt, gold_answers is a single string (not bulleted)
        if self.prompt_style == "locomo":
            gold_formatted = gold_answer
        else:
            gold_formatted = f"- {gold_answer}"

        user_prompt = self._prompt_template.format(
            question=question,
            gold_answers=gold_formatted,
            answer=predicted or "(no answer)",
        )

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": _SYSTEM_JUDGE_MESSAGE},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.0,
            "max_tokens": 512,
            "response_format": {"type": "json_object"},
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        url = f"{self.base_url.rstrip('/')}/chat/completions"

        for attempt in range(self.max_retries + 1):
            try:
                with httpx.Client(timeout=30.0) as client:
                    resp = client.post(url, json=payload, headers=headers)
                    resp.raise_for_status()
                    data = resp.json()

                content = data["choices"][0]["message"]["content"].strip()
                return self._parse_response(content)

            except Exception as exc:
                if attempt < self.max_retries:
                    logger.warning("Judge API attempt %d failed: %s — retrying", attempt + 1, exc)
                    continue
                logger.warning("Judge API failed after %d attempts: %s", attempt + 1, exc)
                return JudgeVerdict(
                    correct=False,
                    reasoning="",
                    error=f"judge_error: {exc}",
                )

        # Should not reach here, but safety net
        return JudgeVerdict(correct=False, reasoning="", error="judge_error: exhausted retries")

    def _parse_response(self, content: str) -> JudgeVerdict:
        """Parse the JSON response from Gemini."""
        import re

        # Strip markdown code fences if present
        text = content.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            # Remove first and last lines (```json and ```)
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines).strip()

        try:
            parsed = json.loads(text)
            return JudgeVerdict(
                correct=bool(parsed.get("correct", False)),
                reasoning=str(parsed.get("reason", parsed.get("reasoning", ""))),
            )
        except (json.JSONDecodeError, KeyError, TypeError):
            pass

        # Try to find JSON object embedded in text
        json_match = re.search(r'\{[^{}]*"correct"\s*:\s*(true|false)[^{}]*\}', text, re.IGNORECASE | re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                return JudgeVerdict(
                    correct=bool(parsed.get("correct", False)),
                    reasoning=str(parsed.get("reason", parsed.get("reasoning", ""))),
                )
            except (json.JSONDecodeError, KeyError, TypeError):
                pass

        # Last resort: look for explicit true/false pattern
        correct_match = re.search(r'"correct"\s*:\s*(true|false)', text, re.IGNORECASE)
        if correct_match:
            is_correct = correct_match.group(1).lower() == "true"
            reason_match = re.search(r'"reason"\s*:\s*"([^"]*)"', text)
            reason = reason_match.group(1) if reason_match else text[:200]
            return JudgeVerdict(correct=is_correct, reasoning=reason)

        return JudgeVerdict(
            correct=False,
            reasoning=text[:200],
            error=f"parse_error: could not extract JSON from response",
        )
