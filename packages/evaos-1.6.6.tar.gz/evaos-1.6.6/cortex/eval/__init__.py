"""
cortex/eval — Benchmark evaluation harness for Cortex memory plugin.

Supports:
  - LoCoMo: Long-Term Conversation Memory benchmark (arXiv:2402.17753)
  - LongMemEval: github.com/xiaowu0162/LongMemEval

Usage:
    python -m cortex.eval.run_eval --dataset locomo --config cortex.toml
"""
