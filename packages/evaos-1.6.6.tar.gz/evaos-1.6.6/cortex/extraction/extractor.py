"""Backwards-compatible shim — all symbols re-exported from submodules.

This file preserves the original import path
``from cortex.extraction.extractor import X`` used by 22+ consumer files.
The actual implementations now live in:

    - cortex.extraction.models      (EntityMention, ClaimExtraction, ExtractionResult)
    - cortex.extraction.pipeline    (ExtractionPipeline)
    - cortex.extraction.json_utils  (_repair_json, _repair_truncated_json)
    - cortex.extraction.utils       (dict_to_claim, _is_llm_api_error, etc.)
"""

from cortex.extraction.models import EntityMention, ClaimExtraction, ExtractionResult  # noqa: F401
from cortex.extraction.pipeline import ExtractionPipeline  # noqa: F401
from cortex.extraction.json_utils import _repair_json, _repair_truncated_json  # noqa: F401
# Re-export for callsite annotation test (resolve_routed_model is used in pipeline.py)
from cortex.llm.router import resolve_routed_model  # noqa: F401
from cortex.extraction.utils import (  # noqa: F401
    _is_llm_api_error,
    _normalize_entity_type,
    _cap_entities_per_extraction,
    _split_batches,
    dict_to_claim,
    _VALID_CATEGORIES,
    _CATEGORY_ALIASES,
)

__all__ = [
    "EntityMention",
    "ClaimExtraction",
    "ExtractionResult",
    "ExtractionPipeline",
    "_repair_json",
    "_repair_truncated_json",
    "_is_llm_api_error",
    "_normalize_entity_type",
    "_cap_entities_per_extraction",
    "_split_batches",
    "dict_to_claim",
    "_VALID_CATEGORIES",
    "_CATEGORY_ALIASES",
]
