"""
cortex/extraction/quality_scorer.py — Heuristic quality adjustments and threshold gating.

Applied post-extraction to LLM quality scores. If the LLM didn't produce a
quality_score, estimates from confidence × 0.6 + salience_mapped × 0.4.

Anti-gaming guardrails:
- If heuristic composite < 0.25, cap final at ≤ 0.45
- If batch mean LLM score > 0.9, z-score normalize within batch

Fixes: #1675
"""

from __future__ import annotations

import logging
import math
from typing import Any, List, Optional

logger = logging.getLogger(__name__)

# Salience string → numeric mapping for fallback estimation
_SALIENCE_MAP = {"high": 0.9, "medium": 0.6, "low": 0.3}

# Generic predicates that signal vague claims
_GENERIC_PREDICATES = frozenset({"is", "has", "does", "was", "were", "be"})


def _estimate_quality(claim: Any) -> float:
    """Estimate quality_score from confidence and salience when LLM didn't provide one."""
    confidence = getattr(claim, "confidence", 0.5)
    salience_str = getattr(claim, "salience", "medium")
    salience_num = _SALIENCE_MAP.get(salience_str, 0.6)
    return confidence * 0.6 + salience_num * 0.4


def _heuristic_adjustment(claim: Any) -> float:
    """Compute deterministic adjustment to apply to quality_score."""
    adj = 0.0

    # object_value length penalties
    obj = getattr(claim, "object_value", "") or ""
    if len(obj) < 10:
        adj -= 0.15
    elif len(obj) > 500:
        adj -= 0.10

    # Confidence penalty
    confidence = getattr(claim, "confidence", 0.5)
    if confidence < 0.4:
        adj -= 0.10

    # Salience penalty
    salience = getattr(claim, "salience", "medium")
    if salience == "low":
        adj -= 0.05

    # Temporal grounding bonus
    temporal_marker = getattr(claim, "temporal_marker", None)
    if temporal_marker is not None:
        adj += 0.05

    # Explicitness bonus
    explicitness = getattr(claim, "explicitness", "inferred")
    if explicitness == "explicit":
        adj += 0.05

    # High-value category bonus
    category = getattr(claim, "category", "misc")
    if category in ("identity", "personal"):
        adj += 0.05

    # Generic predicate penalty
    predicate = getattr(claim, "predicate", "") or ""
    if predicate.lower() in _GENERIC_PREDICATES:
        adj -= 0.05

    return adj


def score_claims(claims: List[Any], *, config: Any = None) -> List[Any]:
    """Apply heuristic adjustments to LLM quality scores.

    Mutates claims in-place (sets quality_score) and returns the list.

    If LLM didn't provide quality_score, estimates from
    confidence * 0.6 + salience_mapped * 0.4.

    Anti-gaming:
    - If heuristic composite < 0.25, cap at 0.45
    - Z-score normalize if batch mean > 0.9
    """
    if not claims:
        return claims

    # Phase 1: Ensure all claims have a base quality_score
    for claim in claims:
        if getattr(claim, "quality_score", None) is None:
            claim.quality_score = _estimate_quality(claim)

    # Phase 2: Z-score normalize if batch mean LLM score > 0.9
    scores = [claim.quality_score for claim in claims]
    mean_score = sum(scores) / len(scores)
    if mean_score > 0.9 and len(claims) > 1:
        std_dev = math.sqrt(sum((s - mean_score) ** 2 for s in scores) / len(scores))
        if std_dev > 0:
            # Re-center around 0.7 with unit variance scaled to 0.15
            for claim in claims:
                z = (claim.quality_score - mean_score) / std_dev
                claim.quality_score = 0.7 + z * 0.15
        else:
            # All identical scores — flatten to 0.7
            for claim in claims:
                claim.quality_score = 0.7

    # Phase 3: Apply heuristic adjustments
    for claim in claims:
        adj = _heuristic_adjustment(claim)
        heuristic_composite = _estimate_quality(claim)

        claim.quality_score += adj

        # Anti-gaming: if heuristic says this is junk, cap LLM score
        if heuristic_composite < 0.25:
            claim.quality_score = min(claim.quality_score, 0.45)

        # Clamp to [0.0, 1.0]
        claim.quality_score = max(0.0, min(1.0, claim.quality_score))

    return claims


def filter_by_quality(
    claims: List[Any],
    threshold: float = 0.35,
    mode: str = "filter",
) -> List[Any]:
    """Filter or flag claims below quality threshold.

    Args:
        claims: List of claims with quality_score attribute.
        threshold: Minimum quality_score to keep (default 0.35).
        mode: "filter" removes claims below threshold.
              "flag" keeps them but sets a ``_quality_flagged`` attribute.

    Returns:
        Filtered (or flagged) list of claims.

    Note:
        In ``"flag"`` mode the ``_quality_flagged`` attribute is set dynamically on
        each claim object (not declared in the dataclass).  This is intentional —
        the flag is **transient pipeline state** used only by downstream steps in the
        same extraction run.  It will NOT appear in ``dataclasses.asdict()`` output,
        will NOT survive JSON serialisation/deserialisation, and will NOT be
        persisted to storage.  Callers that need a durable low-quality signal should
        rely on the ``quality_score`` field instead.
    """
    if mode == "flag":
        for claim in claims:
            qs = getattr(claim, "quality_score", None)
            claim._quality_flagged = qs is not None and qs < threshold
        return claims

    # mode == "filter" (default)
    kept = []
    dropped = 0
    for claim in claims:
        qs = getattr(claim, "quality_score", None)
        if qs is not None and qs < threshold:
            dropped += 1
            continue
        kept.append(claim)

    if dropped:
        logger.info(
            "quality_filter: dropped %d/%d claims below threshold %.2f",
            dropped, dropped + len(kept), threshold,
        )

    return kept
