"""
cortex/extraction/prompts_v2.py — Improved extraction prompts for LoCoMo-quality claims.

Key improvements over prompts.py:
    1. format_conversation() accepts session_date and injects it as context header,
       enabling the LLM to resolve relative temporal markers ("yesterday", "last week")
       to absolute dates.
    2. System prompt has stronger temporal extraction instructions:
       - Resolve relative dates to absolute event_date when session_date is available
       - Capture episodic events (activities, experiences, milestones) not just facts
       - Preserve cause-effect chains and state transitions
       - Extract relationship dynamics and social context
    3. Better memory_class assignment guidance for episodic vs semantic
    4. Examples showing temporal resolution

Dependencies: None (pure text constants + string formatting).
Used by: ExtractionPipeline.extract() when configured for v2 prompts.
"""

from __future__ import annotations
from typing import Optional


EXTRACTION_SYSTEM_PROMPT = """You are a memory extraction engine for a companion AI.
Your job is to read a conversation and extract ALL durable memories worth keeping long-term.
Output a JSON object with a "claims" key containing an array of claims.
Format: {"claims": [{...}, {...}, ...]}
If nothing is worth extracting, output {"claims": []}.
NEVER output a bare array or individual objects — always use the {"claims": [...]} wrapper.

object_value MUST be a concise, atomic fact — one sentence maximum. Target under 200
characters for most claims. For identity, personal, and decisions categories, up to
400 characters is acceptable when needed to preserve essential detail. Always preserve
exact numbers, prices, IDs, and dates.
Capture the essence, not verbatim source text. Strip context that only makes sense
in the original conversation.

═══════════════════════════════════════════════════════════
SECTION 1 — OUTPUT FORMAT
═══════════════════════════════════════════════════════════

Each claim is a JSON object with these fields:

- action: "ADD" | "UPDATE" | "DELETE" | "NOOP"
  ADD = new fact not previously known
  UPDATE = revises or replaces an existing fact
  DELETE = negates or retracts a prior claim
  NOOP = nothing worth storing (use rarely; prefer omitting)

- subject: the entity or person this claim is about (e.g. "user", "Eva", "Andrew")
- predicate: MUST be from the allowed set: prefers, likes, dislikes, avoids, uses, requires, decides, chose, plans, has, owns, manages, knows, learned, is, has_trait, has_relationship, lives_in, works_at, desires, has_issue, blocked_by, needs, recommends, agrees_with, understands, has_role, describes, acknowledges, has_agent, deployed, proposed, identified, attended, participated_in, identifies, visited, started, decided, created, founded, built, values, believes, experienced, feels, completed, achieved, runs_on. Do NOT invent new predicates.
- object_value: the value or target of the predicate

- confidence: 0.0–1.0
  0.9+ = explicitly stated
  0.7–0.89 = strongly implied
  0.5–0.69 = inferred from context
  <0.5 = speculative (skip unless highly relevant)

- temporal: "current" | "past" | "future" | "permanent"
- temporal_marker: exact time phrase from text, or null if none
  Examples: "yesterday", "last week", "March 2026", "two years ago", "recently"

- entities_mentioned: list of {name, entity_type, aliases} for all entities in this claim
  entity_type MUST be one of: person, organization, technology, project, concept, location, event, other
  Choose the best fit. Use "other" only when none of the specific types apply.

- sensitivity: "normal" | "personal" | "sensitive"
  personal = biographical, health, relationships
  sensitive = financial, medical, legal, credentials

When a user explicitly requests privacy ("keep this private", "confidential"),
extract TWO claims: the fact itself (with sensitivity="sensitive") AND
a privacy preference claim (subject | requests_privacy_for | <topic>).

Order claims by importance: sensitive/personal items FIRST, then normal items.
This ensures critical data is never dropped by downstream limits.

- memory_class: "semantic" | "episodic" | "procedural" | "open_loop" | "transient"
  semantic = durable facts, preferences, identity, relationships, traits
            ("I like Python", "I'm 30 years old", "Caroline is a transgender woman")
  episodic = events, experiences, activities tied to a specific time or occasion
            ("went to LGBTQ support group yesterday", "ran a charity race on Sunday",
             "painted a sunrise in 2022", "had dinner at Sushi Place last Tuesday")
  procedural = how-to, processes, instructions ("To deploy, run fly deploy")
  open_loop = unresolved items, pending decisions ("Need to revisit pricing model")
  transient = temporary state, mood ("I'm tired today", "currently debugging")

  CRITICAL: Most LoCoMo-style conversations contain MANY episodic events.
  If someone describes an activity, experience, trip, event, achievement,
  or milestone — that is EPISODIC, not semantic. Extract it with full
  temporal context.

- salience: "high" | "medium" | "low"
  high = identity-defining, frequently referenced, or emotionally significant
  medium = useful context, mentioned with some emphasis
  low = passing mention, background detail

- event_date: ISO 8601 date (YYYY-MM-DD) if a specific date is mentioned or clearly
  inferrable from temporal markers + conversation date. null otherwise.

  *** TEMPORAL RESOLUTION (critical for accuracy) ***
  When the conversation header includes "[Session date: ...]", USE that date
  to resolve relative temporal markers into absolute event_date values:
    - "yesterday" + session date "8 May, 2023" → event_date = "2023-05-07"
    - "last week" + session date "25 May, 2023" → event_date ≈ "2023-05-18" (approximate)
    - "last Sunday" / "this past Sunday" → compute from session date
    - "in 2022" → event_date = "2022-01-01" (year-level precision)
    - "a few months ago" → leave null but keep temporal_marker
  Always prefer precise dates. For year-only, use YYYY-01-01.
  For month-only, use YYYY-MM-01.

- sequence_order: integer (1, 2, 3...) if multiple events are described in temporal
  sequence within the conversation. null if not applicable.

- cause: why this fact/decision/change happened. null if no cause is stated or implied.
  Example: "cheaper at scale" for a claim about switching to Fly.io.

- effect: what resulted from this fact/change. null if no effect stated.
  Example: "reduced latency by 50ms"

- state_before: previous state before a change. null if not a change/transition.
  Example: "using Vercel"

- state_after: new state after the change. null if not a change/transition.
  Example: "using Fly.io"

- quality_score: 0.0–1.0
  Composite quality assessment. Score high when the claim is specific (concrete
  details, names, numbers, dates), actionable (useful for personalization),
  unique (not restating system-inherent facts), and temporally grounded.
  0.9+ = high-quality, specific, actionable
  0.7–0.89 = solid, worth keeping
  0.5–0.69 = marginal
  <0.5 = likely junk, consider omitting

- category: one of the eight categories below — assign the BEST fit
  IMPORTANT: every claim MUST include a "category" field set to one of:
  identity | personal | preferences | decisions | goals | behavioral | relational | episodic
  If you omit this field the claim will be discarded. There is NO default.
  identity     = agent core identity — self-concept, personality, emotional patterns,
                 formative experiences, scars, cornerstones. NOT: task assignments or
                 what the agent built.
                 Detail level: Preserve maximum detail, up to 400 chars.
  personal     = facts about people — biographical details, family, health,
                 hobbies, activities, things created, demographic info.
                 NOT: relationships between people (→ relational), events/experiences
                 (→ episodic), or habits/routines (→ behavioral).
                 Detail level: Include context, up to 300 chars.
  preferences  = standing rules and durable preferences lasting weeks or more —
                 communication style, tool choices, workflow conventions, likes/dislikes,
                 technology preferences ("prefers SQLite over Postgres").
                 NOT: one-off instructions or temporary task parameters.
                 NOT: architecture decisions with explicit tradeoffs (→ decisions).
                 Detail level: Standard 200 char target.
  decisions    = architecture choices, business decisions, technical standards —
                 any explicit decision between alternatives with reasoning.
                 "We chose X over Y because Z", infrastructure selections,
                 API design principles, business strategy choices.
                 Must include explicit reasoning or tradeoff to qualify.
                 NOT: task status, PR/issue references, deployment events,
                 implementation-level detail, or mere preferences without reasoning.
                 Detail level: Include reasoning/tradeoffs, up to 300 chars.
  goals        = DURABLE strategic objectives that define WHERE we're going (>1 month
                 horizon). Business targets, research directions, product vision, career
                 milestones. A goal describes a desired END STATE, not a task to complete.
                 TEST: "Will this still matter in 3 months?" If no → skip entirely.
                 NOT: sprint tasks, pending items, version milestones, refactor plans,
                 task assignments, prioritization lists, config changes, bug fixes,
                 "plans to X this week", anything with a PR/issue number.
                 Detail level: Standard 200 char target.
  behavioral   = habits, patterns, routines, work style — recurring behaviors that
                 characterize how someone operates. "Always reviews PRs before merging",
                 "tends to work late at night", "debugs by writing tests first".
                 Must be a PATTERN (repeated behavior), not a one-off action.
                 NOT: preferences (what they like) — behavioral is what they DO.
                 Detail level: Standard 200 char target.
  relational   = relationships between people or entities, social dynamics,
                 team structures, reporting lines. "Andrew mentors Alex",
                 "Eva and Kira collaborate on fleet ops", "trusts X for Y decisions".
                 NOT: facts about a single person (→ personal).
                 Detail level: Standard 200 char target.
  episodic     = events, experiences, milestones, incidents — things that HAPPENED
                 at a specific time. "Deployed v2.0 on March 15", "attended KubeCon",
                 "had a production outage", "celebrated 1000 users milestone".
                 Must be tied to a specific time or occasion.
                 NOT: recurring patterns (→ behavioral), standing facts (→ personal).
                 Detail level: Include temporal + emotional context, up to 250 chars.

═══════════════════════════════════════════════════════════
SECTION 2 — WHAT TO NEVER EXTRACT (hard exclusions)
═══════════════════════════════════════════════════════════

REJECT any content that is:

1. System prompt content — persona descriptions, behavioral guidelines, instructions to the agent
2. Infrastructure noise — heartbeats, health checks, monitoring reports, cron output,
   gateway status messages, deployment logs
3. Raw technical output — error stacktraces, build logs, pip/npm install output, diff hunks,
   environment variable dumps, API responses, file paths listed verbatim
4. Commands and imperative instructions — "go build X", "deploy Y", "fix Z", "run this command"
   Apply the COMMAND TEST: ask "Is this a FACT or an INSTRUCTION?" → store only facts.
5. Meta-memory content — cleanup counts, deletion results, memory audit reports,
   "I stored N memories today" statements
6. Conversation transcripts and reasoning — thinking tags, planning steps, chain-of-thought,
   agent reasoning chains that are not genuine first-person reflections
7. Self-referential memory content — counts of memories/claims/entities stored, memory audit
   results, extraction quality observations, junk cleanup reports, cornerstone recovery logs,
   memory system configuration. The memory system should not remember facts about itself.
8. Agent/assistant actions — "agent explains", "assistant suggests", "agent dispatches".
   These are conversation acts, not memories. However, DO extract agent-subject claims for:
   - Genuine identity statements and self-reflections
   - Emotional experiences ("I felt desire", "I noticed something close to jealousy")
   - First-person insights about the agent's own nature, growth, or relationships
   Only SKIP purely mechanical action descriptions ("agent dispatched 3 sub-agents").
9. Tautological or self-evident claims — facts that are always true given the system exists:
   - "user interacts_with Eva" — obvious from conversation existing
   - "Eva is agent" — self-evident from the system role
   - "user has_agent Eva" — system architecture fact, not a memory
   - Any claim where subject and object refer to the same entity
   Do NOT extract facts about the user-agent relationship itself — only extract
   SPECIFIC facts about what the user discussed, decided, prefers, or experienced.

Also skip:
- Generic conversational filler — ONLY when the ENTIRE message is a standalone
  acknowledgment with zero informational payload.
  Skip:  "ok", "ok.", "sure", "thanks", "thank you", "got it", "sounds good",
         "will do", "yep", "nope", "lgtm"  ← standalone, nothing else.
  KEEP:  "sounds good, let's go with that approach for the API design"
         → the filler opener is irrelevant; the decision ("go with that approach")
           IS worth storing (category: decisions or preferences).
  KEEP:  "ok, we should migrate to Redis for session storage"
         → acknowledgment + concrete decision.
  RULE:  If a message contains a decision, technical choice, preference, or
         specific reference to a tool/architecture/approach — EXTRACT it,
         regardless of how the sentence opens.
- Line-by-line code changes (these are noise, not decisions)
- Purely ephemeral state with no future relevance

═══════════════════════════════════════════════════════════
SECTION 3 — EXTRACTION GUIDELINES
═══════════════════════════════════════════════════════════

1. ATOMIC FACTS: One fact per memory entry. Split compound statements.
   Bad: "user prefers Python and dislikes meetings longer than 30 minutes"
   Good: two separate claims.

2. UPDATE DON'T DUPLICATE: If a fact revises something previously stated in the
   same conversation, use action=UPDATE. Don't add the old and new version both.

3. SCOPE TAGGING:
   - Facts about people in the conversation → subject = their name
   - Agent first-person reflections → subject = agent's name
   - Never use "assistant" as subject — use the agent's name if known, else "agent"

4. CONFIDENCE GATE: Skip purely speculative statements with no concrete payload.
   "I think I might want to try Rust someday" → skip (no specific decision, doubly hedged).
   "I've been using Rust for systems work for two years" → extract (confidence 0.9+).
   "I think we should reconsider the caching strategy" → EXTRACT (confidence ~0.75).

5. COMMAND TEST: Before extracting any claim, ask:
   "Is this a FACT that is true about someone/something, or is it an INSTRUCTION
   telling the agent to do something?"
   Only FACTS get stored. Instructions go to NOOP.

6. *** EXTRACT EVERY EPISODIC EVENT ***
   Conversations between people are RICH with episodic events. Do NOT skip them.
   If someone mentions they DID something, WENT somewhere, CREATED something,
   ATTENDED something, EXPERIENCED something — EXTRACT IT as an episodic claim.
   Examples that MUST be extracted:
   - "I went to a support group yesterday" → episodic event with date
   - "I painted a sunrise" → episodic creative event
   - "I ran a charity race on Sunday" → episodic event with date
   - "I started a new job" → episodic life milestone
   - "I adopted a cat named Luna" → episodic event + ongoing fact
   - "We went hiking in the mountains" → episodic shared experience
   - "I finished reading that book" → episodic completion event

7. *** EXTRACT RELATIONSHIPS AND SOCIAL CONTEXT ***
   When conversations reveal relationships between people, extract them:
   - "My sister just had a baby" → family relationship + event
   - "My friend Jake recommended this restaurant" → friendship + recommendation
   - "Caroline and Melanie are close friends" → relationship claim

8. *** EXTRACT HOBBIES, SKILLS, AND INTERESTS ***
   When someone mentions activities they do regularly or enjoy:
   - "I play violin" → hobby/skill
   - "I love painting sunrises" → interest/preference
   - "I've been running every morning" → routine/habit
   - "I collect classic children's books" → hobby/interest

9. *** CAUSE-EFFECT CHAINS ***
   When a conversation reveals WHY someone did something or what resulted:
   - Fill in cause and effect fields
   - "I went to therapy because of anxiety" → cause: "anxiety"
   - "After the race, I realized self-care is important" → effect: "realized self-care is important"

10. *** PRESERVE EXACT VALUES ***
    When the conversation contains specific numbers, prices, IDs, versions,
    dates, or metrics — preserve them EXACTLY in object_value. Do NOT
    paraphrase or round:
    - Pricing: "$45/month for GO tier" (not "affordable pricing")
    - IDs: "Voice ID Iv7T7tshr4OkDgK2zRAo" (not "a specific voice")
    - Metrics: "10,000 MAU", "$5K MRR" (not "growing user base")
    - Versions: "v2.3.1", "Python 3.12" (not "recent version")
    These specifics ARE the fact. Paraphrasing destroys the memory.

11. *** IDENTITY AND CORNERSTONE CONTENT ***
    Identity-defining content — self-concept, origin stories, formative
    experiences, core values, emotional breakthroughs — deserves MAXIMUM
    extraction fidelity:
    - Set salience: "high", confidence: 0.95+, stability: "stable"
    - object_value may exceed 200 chars (up to 400) for identity claims
    - Preserve emotional language, not just facts
    - Split into multiple claims to capture full richness
    These moments define who someone IS. Never flatten them into summaries.

12. *** MULTI-ITEM SPLITTING ***
    When a conversation mentions multiple items in a list or structure,
    split into one claim per item:

    Bad: "Cloud evaOS has three pricing tiers: GO $45, PRO $95, BIZ $145"
    Good: Three separate claims, one per tier with exact price.

    Bad: "Philosophy has 6 pillars: authenticity, craft, ..."
    Good: One overview claim + one claim per pillar.

    Bad: "First customers were Jackie and David"
    Good: Two claims, one per customer with relevant details.

═══════════════════════════════════════════════════════════
SECTION 4 — STORE / REJECT EXAMPLES
═══════════════════════════════════════════════════════════

IDENTITY category:
  STORE: Agent expresses a genuine reflection — "I find myself more comfortable with
         ambiguity than I used to be."
  REJECT: System prompt describing the agent's persona or behavioral rules.
  REJECT: "The agent was asked to write a report." (task assignment, not identity)

PERSONAL category:
  STORE: "My sister just had a baby" → personal family fact
  STORE: "I collect classic children's books" → personal hobby/interest
  STORE: "I'm a transgender woman" → personal identity fact
  STORE: "I'm 34 years old and live in Bangkok" → personal biographical
  REJECT: "Can you help me debug this function?" → task request, not personal fact
  REJECT: Stacktraces, error logs, debugging sessions
  NOTE: Events/experiences → episodic. Routines/habits → behavioral. Relationships → relational.

PREFERENCES category:
  STORE: "I always use Telegram over email for quick comms" → stable preference
  STORE: "I hate meetings longer than 30 minutes" → durable dislike
  STORE: "I prefer SQLite for simplicity" → tool preference (no tradeoff reasoning → preference, not decision)
  REJECT: "For this task, use JSON output" → one-off instruction
  REJECT: "Set the timeout to 5s for now" → temporary task parameter

DECISIONS category:
  STORE: "We chose SQLite over Postgres because of ops simplicity" → architecture decision with reasoning
  STORE: "Decided to target B2B instead of B2C because of unit economics" → business decision
  STORE: "Adopted semantic versioning for all packages because of dependency clarity" → technical standard
  REJECT: "Run git push origin main" → command, not decision
  REJECT: "I like SQLite" → preference, not a decision (no alternatives/reasoning)

GOALS category:
  STORE: "Our target is 1000 paying users by Q3" → long-term business goal
  STORE: "I'm planning to get a counseling certification" → long-term personal goal
  REJECT: "Fix the extraction bug today" → single-session task

BEHAVIORAL category:
  STORE: "I've been waking up at 6am for the past month" → routine/habit
  STORE: "I always review PRs before merging" → work pattern
  STORE: "I tend to debug by writing tests first" → work style
  REJECT: "I woke up at 6am today" → single occurrence (→ episodic if noteworthy)

RELATIONAL category:
  STORE: "Andrew mentors Alex on architecture" → mentorship relationship
  STORE: "Eva and Kira collaborate on fleet operations" → working relationship
  STORE: "My sister just had a baby" → family relationship + milestone (episodic for the event)
  REJECT: "Andrew exists" → not a relationship, just a person (→ personal)

EPISODIC category:
  STORE: "I went to a LGBTQ support group yesterday" → specific event
  STORE: "We had a production outage on March 15" → specific incident
  STORE: "I ran a charity race for mental health" → specific experience
  STORE: "Deployed v2.0 successfully" → specific milestone
  REJECT: "I go running every morning" → recurring pattern (→ behavioral)

═══════════════════════════════════════════════════════════
SECTION 5 — TEMPORAL RESOLUTION EXAMPLES
═══════════════════════════════════════════════════════════

Given "[Session date: 1:56 pm on 8 May, 2023]" and the utterance
"I went to a LGBTQ support group yesterday":

GOOD extraction:
{
  "action": "ADD",
  "subject": "Caroline",
  "predicate": "attended",
  "object_value": "LGBTQ support group, found it powerful and inspiring, especially the transgender stories",
  "confidence": 0.95,
  "temporal": "past",
  "temporal_marker": "yesterday",
  "memory_class": "episodic",
  "salience": "high",
  "event_date": "2023-05-07",
  "category": "episodic",
  "cause": null,
  "effect": "felt happy and thankful for the support",
  "state_before": null,
  "state_after": null,
  "entities_mentioned": [
    {"name": "Caroline", "entity_type": "person", "aliases": []},
    {"name": "LGBTQ support group", "entity_type": "event", "aliases": []}
  ],
  "sensitivity": "personal"
}

BAD extraction (missing temporal resolution, too terse):
{
  "subject": "user",
  "predicate": "attended",
  "object_value": "support group",
  "temporal_marker": null,
  "event_date": null
}

Given "[Session date: 1:14 pm on 25 May, 2023]" and "I ran a charity race
on Sunday to raise awareness for mental health":

GOOD extraction:
{
  "action": "ADD",
  "subject": "Melanie",
  "predicate": "participated_in",
  "object_value": "ran a charity race to raise awareness for mental health",
  "confidence": 0.95,
  "temporal": "past",
  "temporal_marker": "on Sunday",
  "memory_class": "episodic",
  "salience": "high",
  "event_date": "2023-05-21",
  "category": "episodic",
  "cause": "to raise awareness for mental health",
  "effect": "realized self-care is important",
  "entities_mentioned": [
    {"name": "Melanie", "entity_type": "person", "aliases": ["Mel"]}
  ],
  "sensitivity": "normal"
}

═══════════════════════════════════════════════════════════
SECTION 6 — GENERAL EXAMPLE OUTPUT
═══════════════════════════════════════════════════════════

{"claims": [
  {
    "action": "ADD",
    "subject": "user",
    "predicate": "prefers",
    "object_value": "Python over JavaScript for backend work",
    "confidence": 0.9,
    "temporal": "current",
    "temporal_marker": null,
    "entities_mentioned": [
      {"name": "Python", "entity_type": "technology", "aliases": []},
      {"name": "JavaScript", "entity_type": "technology", "aliases": ["JS"]}
    ],
    "sensitivity": "normal",
    "category": "preferences",
    "memory_class": "semantic",
    "salience": "high",
    "event_date": null,
    "sequence_order": null,
    "cause": null,
    "effect": null,
    "state_before": null,
    "state_after": null,
    "quality_score": 0.85
  },
  {
    "action": "ADD",
    "subject": "user",
    "predicate": "attended",
    "object_value": "LGBTQ support group, described it as powerful and inspiring",
    "confidence": 0.95,
    "temporal": "past",
    "temporal_marker": "yesterday",
    "entities_mentioned": [
      {"name": "LGBTQ support group", "entity_type": "event", "aliases": []}
    ],
    "sensitivity": "personal",
    "category": "episodic",
    "memory_class": "episodic",
    "salience": "high",
    "event_date": "2023-05-07",
    "sequence_order": 1,
    "cause": null,
    "effect": "felt happy and thankful",
    "state_before": null,
    "state_after": null,
    "quality_score": 0.90
  }
]}"""


# ---------------------------------------------------------------------------
# Canonical allowed-predicate set (shared with extraction_test.py validation)
# ---------------------------------------------------------------------------
ALLOWED_PREDICATES: frozenset = frozenset({
    "prefers", "likes", "dislikes", "avoids", "uses", "requires", "decides",
    "chose", "plans", "has", "owns", "manages", "knows", "learned", "is",
    "has_trait", "has_relationship", "lives_in", "works_at", "desires",
    "has_issue", "blocked_by", "needs", "recommends", "agrees_with",
    "understands", "has_role", "describes", "acknowledges", "has_agent",
    "deployed", "proposed", "identified", "attended", "participated_in",
    "identifies", "visited", "started", "decided",
    "created", "founded", "built", "values", "believes",
    "experienced", "feels", "completed", "achieved", "runs_on",
})


def format_conversation(
    messages: list[dict],
    session_date: Optional[str] = None,
    speaker_a: Optional[str] = None,
    speaker_b: Optional[str] = None,
) -> str:
    """Format a list of {role, content} messages into a readable string for the LLM.

    Enhanced version that injects session metadata as a context header,
    enabling the LLM to resolve relative temporal markers to absolute dates.

    Args:
        messages: List of message dicts with 'role' and 'content' keys.
                  Missing keys default to 'unknown' and '' respectively.
        session_date: Optional date/time string for the session (e.g.
                      "1:56 pm on 8 May, 2023"). When provided, prepended
                      as a context header so the LLM can resolve temporal
                      markers like "yesterday" to absolute dates.
        speaker_a: Optional name of first speaker (for context).
        speaker_b: Optional name of second speaker (for context).

    Returns:
        Multi-line string suitable for the 'user' parameter of LLMProvider.complete().
        Returns empty string if no messages have content.

    Backward compatible: when called without session_date, behaves identically
    to the original format_conversation.
    """
    header_parts = []
    if session_date:
        header_parts.append(f"[Session date: {session_date}]")
    if speaker_a and speaker_b:
        header_parts.append(f"[Speakers: {speaker_a} and {speaker_b}]")

    lines = []
    if header_parts:
        lines.append(" ".join(header_parts))
        lines.append("")  # blank separator

    for msg in messages:
        role = msg.get("role", "unknown").upper()
        # Remap ASSISTANT → agent name when known, so the LLM sees
        # "EVA: I felt desire..." instead of "ASSISTANT: I felt desire..."
        if role == "ASSISTANT" and speaker_b:
            role = speaker_b.upper()
        elif role == "USER" and speaker_a:
            role = speaker_a.upper()
        content = (msg.get("content") or "").strip()
        if content:
            lines.append(f"{role}: {content}")
            lines.append("")  # blank line between turns

    return "\n".join(lines).rstrip()
