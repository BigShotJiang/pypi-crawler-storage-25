"""
cortex/extraction/retry_classifier.py — Smart retry classification for extraction failures.

When extraction produces zero claims, this module classifies the *cause* and
recommends an appropriate retry strategy instead of always splitting the batch.

Classification hierarchy:
    1. Truncation evidence → SPLIT_BATCH (reduce input size)
    2. Empty/blank response → RETRY_SAME (provider glitch, try again)
    3. Structured empty result → RETRY_SAME (likely extraction failure, not truly empty)
    4. Parse error → RETRY_SAME (LLM confusion, might work on retry)
    5. Refusal/safety → SKIP_BATCH (model won't extract, don't waste calls)
    6. Default → RETRY_SAME (conservative — don't split without evidence)

Used by: ExtractionPipeline.extract(), _retry_with_split(), _retry_with_split_prompt()
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import Optional

logger = logging.getLogger("cortex.extraction.extractor")


class RetryAction(Enum):
    """Action to take when an extraction batch produces zero claims."""

    RETRY_SAME = "retry_same"          # Provider glitch — try the same batch again
    SPLIT_BATCH = "split_batch"        # Input too large / truncated — split in half
    SKIP_BATCH = "skip_batch"          # Won't help — skip this batch entirely


# Patterns that indicate the model is refusing to extract
_REFUSAL_PHRASES = (
    "i cannot",
    "i can't",
    "i'm sorry",
    "i am sorry",
    "as an ai",
    "i'm unable",
    "i am unable",
    "i'm not able",
)

# Patterns that look like empty extraction — treated as RETRY_SAME (R-320:
# json_object makes failures produce valid empty JSON, which should be retried)
_EMPTY_RESULT_PATTERNS = frozenset({
    "[]",
    '{"claims": []}',
    '{"memories": []}',
    '{"claims":[]}',
    '{"memories":[]}',
})


def classify_extraction_failure(
    raw_response: str,
    parse_error: Optional[str] = None,
    finish_reason: Optional[str] = None,
    batch_size: int = 1,
) -> RetryAction:
    """Classify why extraction produced zero claims and recommend a retry action.

    Args:
        raw_response: The raw text returned by the LLM (may be empty, truncated,
                      or malformed JSON).
        parse_error: If JSON parsing failed, the error message. None if parsing
                     succeeded but the result was empty.
        finish_reason: The LLM's finish_reason if available (e.g. "length" for
                       truncation, "stop" for normal completion). Currently not
                       exposed by CompletionResponse — passed as None.
        batch_size: Number of messages in the batch (used for logging context).

    Returns:
        RetryAction indicating what the caller should do next.
    """
    # 1. Truncation evidence → split
    if finish_reason == "length":
        logger.info(
            "retry_classifier: finish_reason=length → SPLIT_BATCH (batch_size=%d)",
            batch_size,
        )
        return RetryAction.SPLIT_BATCH

    # Check for truncated JSON (incomplete object/array)
    if raw_response:
        stripped = raw_response.rstrip()
        if stripped and stripped[-1] in (",", "{", "["):
            logger.info(
                "retry_classifier: truncated JSON (ends with %r) → SPLIT_BATCH",
                stripped[-1],
            )
            return RetryAction.SPLIT_BATCH
        # Unbalanced braces/brackets suggest truncation
        if stripped and not _is_balanced_json(stripped):
            logger.info(
                "retry_classifier: unbalanced JSON brackets → SPLIT_BATCH",
            )
            return RetryAction.SPLIT_BATCH

    # 2. Empty response → provider glitch, retry same
    if not raw_response or not raw_response.strip():
        logger.info(
            "retry_classifier: empty response → RETRY_SAME (batch_size=%d)",
            batch_size,
        )
        return RetryAction.RETRY_SAME

    # 3. Structured empty result (e.g. {"claims": []}) → retry
    # These look "legitimate" but are usually extraction failures — the model
    # produced valid JSON with no content.  Pre-#1643 behavior always retried
    # these via split.  SKIP_BATCH here caused the F1 regression (R-320):
    # json_object (#1645) made failures look structurally valid, and this
    # check suppressed the retry that previously recovered them.
    normalized = raw_response.strip()
    if normalized in _EMPTY_RESULT_PATTERNS:
        logger.info(
            "retry_classifier: structured empty result %r → RETRY_SAME (batch_size=%d)",
            normalized[:50],
            batch_size,
        )
        return RetryAction.RETRY_SAME

    # 4. Parse error (malformed JSON) → retry same
    if parse_error:
        logger.info(
            "retry_classifier: parse_error=%s → RETRY_SAME (batch_size=%d)",
            parse_error[:100],
            batch_size,
        )
        return RetryAction.RETRY_SAME

    # 5. Refusal/safety patterns → skip
    lower = raw_response.lower()
    if any(phrase in lower for phrase in _REFUSAL_PHRASES):
        logger.info(
            "retry_classifier: refusal pattern detected → SKIP_BATCH",
        )
        return RetryAction.SKIP_BATCH

    # 6. Default → retry same (conservative — don't split without evidence)
    logger.info(
        "retry_classifier: no clear signal → RETRY_SAME (batch_size=%d)",
        batch_size,
    )
    return RetryAction.RETRY_SAME


def _is_balanced_json(text: str) -> bool:
    """Quick check if JSON brackets/braces are balanced.

    This is a heuristic, not a full parser. It counts opening and closing
    brackets/braces and returns False if they don't match (suggesting truncation).
    Ignores characters inside strings to avoid false positives from JSON values
    containing brackets.
    """
    depth_brace = 0
    depth_bracket = 0
    in_string = False
    escape = False

    for ch in text:
        if escape:
            escape = False
            continue
        if ch == '\\' and in_string:
            escape = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == '{':
            depth_brace += 1
        elif ch == '}':
            depth_brace -= 1
        elif ch == '[':
            depth_bracket += 1
        elif ch == ']':
            depth_bracket -= 1

    return depth_brace == 0 and depth_bracket == 0
