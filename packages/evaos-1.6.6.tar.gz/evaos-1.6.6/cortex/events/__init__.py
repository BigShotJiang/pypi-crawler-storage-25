"""
cortex/events — In-process event bus (M19).

Provides a lightweight, synchronous event emitter that:
  - Defines all first-class EventTypes for the Cortex lifecycle
  - Logs every emitted event to the event_log table
  - Notifies registered in-process listeners synchronously

Webhooks (outbound HTTP delivery) are deferred to v1.1.

Typical usage::

    from cortex.events import EventEmitter, EventType, CortexEvent
    from datetime import datetime, timezone

    emitter = EventEmitter(storage=plugin.storage)
    emitter.on(EventType.MEMORY_CREATED, my_callback)

    event = CortexEvent(
        event_type=EventType.MEMORY_CREATED,
        timestamp=datetime.now(timezone.utc).isoformat(),
        owner_id="user-123",
        payload={"claim_id": "abc"},
    )
    await emitter.emit(event)
"""

from cortex.events.emitter import CortexEvent, EventEmitter, EventType

__all__ = ["CortexEvent", "EventEmitter", "EventType"]
