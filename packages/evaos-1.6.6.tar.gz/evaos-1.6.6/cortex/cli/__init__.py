"""cortex/cli — evaos CLI package (#945).

Re-exports ``main`` Click group and shared helpers for backward compatibility.
``from cortex.cli import main`` continues to work.
"""

from cortex.cli.app import (  # noqa: F401
    main,
    _print,
    _ok,
    _err,
    _warn,
    _section,
    _kv_table,
    _run,
    _make_plugin,
    _init_plugin,
    _RICH,
    _console,
)

# Import command modules to trigger @main.command() / @main.group() registration
import cortex.cli.memory_cmds  # noqa: F401
import cortex.cli.lifecycle_cmds  # noqa: F401
import cortex.cli.io_cmds  # noqa: F401
import cortex.cli.server_cmds  # noqa: F401
import cortex.cli.admin_cmds  # noqa: F401
import cortex.cli.backup_cmds  # noqa: F401

__all__ = ["main"]
