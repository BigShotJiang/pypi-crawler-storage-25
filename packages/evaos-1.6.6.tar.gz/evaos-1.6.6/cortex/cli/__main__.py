"""Allow ``python -m cortex.cli`` to invoke the CLI."""
from cortex.cli import main

if __name__ == "__main__":
    main()
