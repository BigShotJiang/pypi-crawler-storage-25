"""cortex/core/retrieval.py — Backwards-compatible re-export shim.

All symbols previously importable from this module are re-exported below.
New code should import from the specific submodules directly:
    - cortex.core.retrieval_types     — DTOs and constants
    - cortex.core.retrieval_scoring   — pure scoring/fusion functions
    - cortex.core.retrieval_helpers   — content rendering, accessors, utilities
    - cortex.core.retrieval_pipeline  — RetrievalPipeline class

Refactored in #947 (SRP split).
"""

# Types
from cortex.core.retrieval_types import (  # noqa: F401
    ContextBlock,
    RetrievalConstraints,
    RetrievedItem,
    RetrievalResult,
    SENSITIVITY_ORDER,
    _FTSResult,
    _SENSITIVITY_ALIASES,
    _VectorResult,
)

# Scoring
from cortex.core.retrieval_scoring import (  # noqa: F401
    _COMPLEX_QUERY_MIN_LENGTH,
    _COMPLEX_QUERY_SIGNALS,
    _is_complex_query,
    _normalise_bm25,
    _sensitivity_level,
    cosine_similarity,
    rrf_fusion,
)

# Helpers
from cortex.core.retrieval_helpers import (  # noqa: F401
    _decode_embedding,
    _get_content,
    _get_id,
    _get_item_type,
    _get_rank,
    _get_score,
    _new_id,
    _render_claim_content,
    _table_to_item_type,
)

# Pipeline
from cortex.core.retrieval_pipeline import RetrievalPipeline  # noqa: F401

# Voyage AI SDK — re-exported so tests can patch cortex.core.retrieval.voyageai
try:
    import voyageai  # noqa: F401
except ImportError:
    voyageai = None  # type: ignore[assignment]
