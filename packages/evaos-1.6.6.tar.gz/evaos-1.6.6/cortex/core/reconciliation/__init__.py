"""cortex/core/reconciliation — Reconciliation Engine package (#946)."""

from cortex.core.reconciliation.models import (
    ReconciliationAction,
    RelationshipKind,
    ReconciliationResult,
    ReconciliationReport,
    RECONCILIATION_PROMPT,
)
from cortex.core.reconciliation.engine import ReconciliationEngine
from cortex.core.reconciliation.models import _now

# Re-export for backward compatibility — some tests patch these at module level
from cortex.core.contradiction_store import insert_contradiction as _persist_contradiction

__all__ = [
    "ReconciliationEngine",
    "ReconciliationAction",
    "RelationshipKind",
    "ReconciliationResult",
    "ReconciliationReport",
    "RECONCILIATION_PROMPT",
    "_now",
    "_persist_contradiction",
]
