"""Ephemeral bi-directional UUID ↔ short-integer mapper for LLM prompts.

Reduces token waste by replacing 36-char UUIDs with 1-indexed integers in
LLM prompts, then resolving them back after parsing the response.

Each instance is scoped to a single LLM call — NOT persistent, NOT shared.
Thread-safe by isolation (each call creates its own instance).

See: 100yenadmin/electric-sheep#1672
"""

from __future__ import annotations

import logging
import re
from typing import Dict, Optional

logger = logging.getLogger(__name__)

_UUID_PATTERN = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
    re.IGNORECASE,
)


class ClaimIdMapper:
    """Ephemeral bi-directional UUID ↔ short-integer mapper for LLM prompts.

    Scoped to a single LLM call. NOT persistent, NOT shared across calls.
    Thread-safe by isolation — each call creates its own instance.

    Usage::

        mapper = ClaimIdMapper()
        short = mapper.to_short("550e8400-e29b-41d4-a716-446655440000")  # → 1
        mapper.to_short("550e8400-e29b-41d4-a716-446655440000")          # → 1 (idempotent)
        mapper.to_uuid(1)                                                 # → "550e8400-..."
        mapper.resolve("1")                                               # → "550e8400-..."
        mapper.resolve("550e8400-e29b-41d4-a716-446655440000")           # → passthrough
    """

    def __init__(self) -> None:
        self._uuid_to_int: Dict[str, int] = {}
        self._int_to_uuid: Dict[int, str] = {}
        self._next_id: int = 1  # 1-indexed (LLMs handle 1-indexed better)

    @staticmethod
    def _uuid_key(value: str) -> str:
        """Normalise a UUID string to lowercase for case-insensitive lookups.

        UUID strings are case-insensitive per RFC 4122.  Lowercasing before
        any dict operation ensures that a UUID registered in one casing is
        found even when the LLM returns it in another casing.
        """
        return value.lower()

    def to_short(self, uuid_str: str) -> int:
        """Map a UUID to a short integer. Idempotent — same UUID always returns same int."""
        key = self._uuid_key(uuid_str)
        if key in self._uuid_to_int:
            return self._uuid_to_int[key]
        short = self._next_id
        self._next_id += 1
        self._uuid_to_int[key] = short
        self._int_to_uuid[short] = uuid_str  # store original casing for output
        return short

    def to_uuid(self, short: int) -> Optional[str]:
        """Map a short integer back to its UUID. Returns None if not in map."""
        return self._int_to_uuid.get(short)

    def resolve(self, ref: str, *, strict: bool = False) -> Optional[str]:
        """Resolve any reference from LLM output back to a UUID.

        Handles:
        - Integer string (``"1"``) → mapped UUID
        - UUID passthrough (LLM ignored short IDs and returned full UUID)
        - Unknown UUID → returned as-is (graceful degradation) unless strict=True
        - Garbage / out-of-range int → None + warning

        Args:
            ref: The reference string from LLM output (integer or UUID string).
            strict: When True, UUID passthrough is disabled — only UUIDs that were
                explicitly registered via ``to_short()`` are accepted. Unregistered
                UUIDs return None. Use in mutation paths (e.g. dream reconsolidation)
                to reject hallucinated IDs from LLM output.

        Returns:
            The resolved UUID string, or None if unresolvable.
        """
        ref = ref.strip()

        # Try integer lookup first
        try:
            short = int(ref)
            result = self.to_uuid(short)
            if result is None:
                logger.warning(
                    "ClaimIdMapper: integer ref %d not in map (size=%d)",
                    short,
                    self.size,
                )
            return result
        except ValueError:
            pass

        # UUID passthrough — LLM returned the full UUID instead of short int
        if _UUID_PATTERN.fullmatch(ref):
            if strict:
                # In strict mode, only accept UUIDs that were registered in this session.
                # Use case-insensitive lookup so LLM casing differences don't cause
                # valid UUIDs to be rejected (RFC 4122: UUIDs are case-insensitive).
                key = self._uuid_key(ref)
                if key in self._uuid_to_int:
                    return self._int_to_uuid[self._uuid_to_int[key]]  # return canonical form
                logger.warning(
                    "ClaimIdMapper: strict mode — rejecting unregistered UUID %r",
                    ref[:80],
                )
                return None
            return ref

        # Unrecognizable reference
        logger.warning("ClaimIdMapper: unresolvable ref %r", ref[:80])
        return None

    @property
    def size(self) -> int:
        """Number of UUID ↔ int mappings currently registered."""
        return len(self._uuid_to_int)
