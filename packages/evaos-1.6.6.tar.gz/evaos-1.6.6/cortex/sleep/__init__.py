"""
cortex/sleep/ — Sleep S1/S2/S3 Pipeline

Issue #360: Sleep pipeline for session consolidation, semantic promotion,
and handoff packet building.

Modules:
    s1_consolidator  — S1: session summary generator (persist to handoff_packet)
    s2_promotion     — S2: conservative semantic promotion reviewer
    s3_handoff       — S3: handoff packet builder (boot-ready context)
    pipeline         — Orchestrator: S1 → S2 → S3

Usage::

    from cortex.sleep.pipeline import SleepPipeline, SleepPipelineReport

    pipeline = SleepPipeline(storage=storage, llm=llm, config=config)
    report = await pipeline.run(session_id="sess-abc", owner_id="default")
"""

from cortex.sleep.pipeline import SleepPipeline, SleepPipelineReport
from cortex.sleep.s1_consolidator import S1Consolidator, S1Result
from cortex.sleep.s2_promotion import S2Promoter, S2Result, PromotionDecision
from cortex.sleep.s3_handoff import S3HandoffBuilder, S3Result

__all__ = [
    "SleepPipeline",
    "SleepPipelineReport",
    "S1Consolidator",
    "S1Result",
    "S2Promoter",
    "S2Result",
    "PromotionDecision",
    "S3HandoffBuilder",
    "S3Result",
]
