"""cortex/observatory — Config Observatory: multi-node aggregation layer.

Provides async utilities for querying evaOS nodes' config-status endpoints
and producing unified drift reports.

Public API:
    NodeConfig         — connection info for one evaOS node
    ConfigDrift        — a single field that differs across nodes
    AggregatedStatus   — full drift + per-node snapshot report
    fetch_node_config  — fetch one node's config-status payload
    aggregate_configs  — query multiple nodes and compute drift
"""

from cortex.observatory.aggregator import (
    NodeConfig,
    ConfigDrift,
    NodeResult,
    AggregatedStatus,
    fetch_node_config,
    aggregate_configs,
)

__all__ = [
    "NodeConfig",
    "ConfigDrift",
    "NodeResult",
    "AggregatedStatus",
    "fetch_node_config",
    "aggregate_configs",
]
