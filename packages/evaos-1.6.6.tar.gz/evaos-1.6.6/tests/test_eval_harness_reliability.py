from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from cortex.eval.harness import EvalHarness
from cortex.eval.locomo import LoCoMoConversation, LoCoMoDataset, LoCoMoQAPair, LoCoMoSession
from cortex.eval.run_eval import _resolve_output_paths, _run_namespace_canary, _write_report_json


@dataclass
class _RememberResult:
    session_id: str
    claims_stored: int = 1
    claims_extracted: int = 1


class _Plugin:
    def __init__(self, claim_counts: list[int] | None = None, leak_token: str | None = None):
        self.claim_counts = list(claim_counts or [1])
        self.remember_calls: list[dict[str, Any]] = []
        self.retrieve_calls: list[dict[str, Any]] = []
        self.leak_token = leak_token
        self.llm = None
        self.config = MagicMock()

    async def remember(self, conversation, session_id=None, owner_id=None, **kwargs):
        self.remember_calls.append({"session_id": session_id, "owner_id": owner_id})
        claims = self.claim_counts.pop(0) if self.claim_counts else 1
        return _RememberResult(
            session_id=session_id or "",
            claims_stored=claims,
            claims_extracted=claims,
        )

    async def retrieve(self, query, owner_id=None, **kwargs):
        self.retrieve_calls.append({"query": query, "owner_id": owner_id})
        content = self.leak_token if self.leak_token else ""
        return SimpleNamespace(formatted_context=content, memories=[])


def _single_session_dataset(session_id: str = "conv-1") -> LoCoMoDataset:
    return LoCoMoDataset(
        name="reliability-test",
        sessions=[
            LoCoMoSession(
                session_id=session_id,
                conversation=[{"role": "user", "content": "hello"}],
                qa_pairs=[],
            )
        ],
    )


def _native_conversation_dataset(sample_id: str, session_claims: list[int]) -> LoCoMoDataset:
    sessions = [
        LoCoMoSession(
            session_id=f"{sample_id}-s{i+1}",
            conversation=[{"role": "user", "content": f"msg {i+1}"}],
            qa_pairs=[],
        )
        for i in range(len(session_claims))
    ]
    conversation = LoCoMoConversation(
        sample_id=sample_id,
        speaker_a="A",
        speaker_b="B",
        sessions=sessions,
        qa_pairs=[],
    )
    dataset = LoCoMoDataset(name="native-reliability", sessions=sessions)
    dataset.metadata["conversations"] = [conversation]
    return dataset


@pytest.mark.asyncio
async def test_degraded_conversation_metrics_appear_in_report():
    plugin = _Plugin(claim_counts=[3])
    harness = EvalHarness(plugin=plugin, owner_id="locomo-eval-test")

    report = await harness.run_locomo_dataset(_single_session_dataset())

    metrics = report.ingest_metrics["conv-1"]
    assert metrics.sessions_attempted == 1
    assert metrics.total_claims_ingested == 3
    assert metrics.zero_claim_sessions == 0
    assert metrics.owner_id_used == "locomo-eval-test-conv-1"
    assert metrics.degraded is True
    payload = report.to_dict()
    assert payload["ingest_metrics"]["conv-1"]["degraded"] is True
    assert "conv-1" in payload["degraded_conversations"]


@pytest.mark.asyncio
async def test_fail_on_empty_aborts_on_zero_claim_conversation():
    plugin = _Plugin(claim_counts=[0])
    harness = EvalHarness(plugin=plugin, owner_id="locomo-eval-test", fail_on_empty=True)

    with pytest.raises(RuntimeError, match="ingested zero claims"):
        await harness.run_locomo_dataset(_single_session_dataset())


@pytest.mark.asyncio
async def test_zero_claim_backpressure_marks_failed_conversation():
    plugin = _Plugin(claim_counts=[0, 0, 0, 0, 0])
    harness = EvalHarness(plugin=plugin, owner_id="locomo-eval-test")
    dataset = _native_conversation_dataset("conv-49", [0, 0, 0, 0, 0])

    sleep_calls: list[int] = []

    async def _fake_sleep(seconds: int):
        sleep_calls.append(seconds)

    with patch("cortex.eval.harness.asyncio.sleep", side_effect=_fake_sleep):
        report = await harness.run_locomo_dataset(dataset)

    metrics = report.ingest_metrics["conv-49"]
    assert metrics.zero_claim_sessions == 5
    assert metrics.failed is True
    assert "5 consecutive zero-claim sessions" in (metrics.failure_reason or "")
    assert report.failed_conversations == ["conv-49"]
    assert 30 in sleep_calls


@pytest.mark.asyncio
async def test_namespace_canary_aborts_on_leak_and_cleans_up():
    token_holder: dict[str, str] = {}

    class _LeakyPlugin(_Plugin):
        async def remember(self, conversation, session_id=None, owner_id=None, **kwargs):
            token_holder["token"] = conversation[0]["content"]
            return await super().remember(conversation, session_id=session_id, owner_id=owner_id, **kwargs)

        async def retrieve(self, query, owner_id=None, **kwargs):
            return SimpleNamespace(formatted_context=token_holder.get("token", ""), memories=[])

    plugin = _LeakyPlugin(claim_counts=[1])
    cleanup = AsyncMock()
    with patch("cortex.eval.run_eval._cleanup_eval_owner", cleanup):
        with pytest.raises(RuntimeError, match="Namespace canary failed"):
            await _run_namespace_canary(plugin)

    cleanup.assert_awaited_once()
    assert cleanup.await_args.args[1] == "eval-canary-A"


def test_timestamped_output_and_latest_symlink(tmp_path: Path):
    out_path, latest_path = _resolve_output_paths(str(tmp_path / "locomo10.json"), "locomo-full")
    assert out_path.name.startswith("locomo10-")
    assert out_path.name.endswith(".json")
    assert latest_path == tmp_path / "latest.json"

    report = SimpleNamespace(
        to_dict=lambda: {"metrics": {"ok": True}},
    )
    _write_report_json(str(out_path), report, latest_symlink=latest_path)

    assert out_path.exists()
    assert latest_path.is_symlink()
    assert latest_path.resolve() == out_path.resolve()
