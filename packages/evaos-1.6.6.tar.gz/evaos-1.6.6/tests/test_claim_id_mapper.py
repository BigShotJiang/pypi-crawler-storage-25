"""Tests for ClaimIdMapper — ephemeral UUID ↔ short-integer mapping.

See: 100yenadmin/electric-sheep#1672
"""

from __future__ import annotations

import uuid


from cortex.core.reconciliation.claim_id_mapper import ClaimIdMapper


def _make_uuid() -> str:
    return str(uuid.uuid4())


class TestClaimIdMapper:
    """Unit tests for ClaimIdMapper."""

    def test_round_trip(self):
        """to_short → to_uuid returns the original UUID."""
        mapper = ClaimIdMapper()
        uid = _make_uuid()
        short = mapper.to_short(uid)
        assert mapper.to_uuid(short) == uid

    def test_idempotent(self):
        """Calling to_short with the same UUID returns the same int."""
        mapper = ClaimIdMapper()
        uid = _make_uuid()
        s1 = mapper.to_short(uid)
        s2 = mapper.to_short(uid)
        assert s1 == s2
        assert mapper.size == 1

    def test_sequential(self):
        """IDs are assigned sequentially starting at 1."""
        mapper = ClaimIdMapper()
        u1, u2, u3 = _make_uuid(), _make_uuid(), _make_uuid()
        assert mapper.to_short(u1) == 1
        assert mapper.to_short(u2) == 2
        assert mapper.to_short(u3) == 3
        assert mapper.size == 3

    def test_uuid_passthrough(self):
        """resolve() passes through valid UUIDs that aren't in the map."""
        mapper = ClaimIdMapper()
        uid = _make_uuid()
        # uid was never registered via to_short
        assert mapper.resolve(uid) == uid

    def test_unknown_uuid(self):
        """resolve() passes through unknown UUIDs gracefully."""
        mapper = ClaimIdMapper()
        mapper.to_short(_make_uuid())  # register one UUID
        unknown = _make_uuid()
        # Unknown UUID still passes through (graceful degradation)
        assert mapper.resolve(unknown) == unknown

    def test_invalid_ref(self):
        """resolve() returns None for garbage input."""
        mapper = ClaimIdMapper()
        mapper.to_short(_make_uuid())
        assert mapper.resolve("not-a-uuid-or-int") is None
        assert mapper.resolve("") is None
        assert mapper.resolve("abc123") is None

    def test_out_of_range_int(self):
        """resolve() returns None for int refs outside the mapped range."""
        mapper = ClaimIdMapper()
        mapper.to_short(_make_uuid())  # only ID 1 exists
        assert mapper.resolve("0") is None
        assert mapper.resolve("2") is None
        assert mapper.resolve("999") is None

    def test_isolation(self):
        """Separate mapper instances have independent state."""
        m1 = ClaimIdMapper()
        m2 = ClaimIdMapper()
        uid = _make_uuid()
        s1 = m1.to_short(uid)
        assert s1 == 1
        # m2 doesn't know about uid
        assert m2.to_uuid(1) is None
        assert m2.size == 0
        # m2 assigns its own ID
        uid2 = _make_uuid()
        s2 = m2.to_short(uid2)
        assert s2 == 1  # also starts at 1
        assert m1.to_uuid(1) == uid
        assert m2.to_uuid(1) == uid2


class TestClaimIdMapperStrictMode:
    """Regression tests for strict mode (100yenadmin/electric-sheep#1683).

    Strict mode prevents hallucinated UUIDs from LLM output passing through
    as valid claim IDs in mutation paths (e.g. dream reconsolidation).
    """

    def test_strict_rejects_unregistered_uuid(self):
        """strict=True: a valid-looking but unmapped UUID returns None."""
        mapper = ClaimIdMapper()
        mapper.to_short(_make_uuid())  # register one UUID (gets short ID 1)
        mapper.to_short(_make_uuid())  # register another (gets short ID 2)

        hallucinated = _make_uuid()  # never registered
        result = mapper.resolve(hallucinated, strict=True)
        assert result is None, (
            "strict mode must reject UUIDs not in the mapper's registry"
        )

    def test_strict_accepts_registered_uuid(self):
        """strict=True: a UUID that was registered passes through."""
        mapper = ClaimIdMapper()
        uid = _make_uuid()
        mapper.to_short(uid)  # register it

        # LLM returned the full UUID instead of the short int — still valid in strict mode
        result = mapper.resolve(uid, strict=True)
        assert result == uid

    def test_strict_resolves_integer_ref(self):
        """strict=True: integer refs still resolve normally."""
        mapper = ClaimIdMapper()
        uid = _make_uuid()
        short = mapper.to_short(uid)

        result = mapper.resolve(str(short), strict=True)
        assert result == uid

    def test_non_strict_passthrough_still_works(self):
        """strict=False (default): unknown UUID passes through (backward compat)."""
        mapper = ClaimIdMapper()
        mapper.to_short(_make_uuid())  # register an unrelated UUID

        unknown = _make_uuid()  # never registered
        result = mapper.resolve(unknown, strict=False)
        assert result == unknown, (
            "backward compat: non-strict mode must still pass through unknown UUIDs"
        )

    def test_default_is_non_strict(self):
        """resolve() without strict kwarg behaves as strict=False."""
        mapper = ClaimIdMapper()
        unknown = _make_uuid()
        assert mapper.resolve(unknown) == unknown

    def test_strict_invalid_ref_still_none(self):
        """strict=True: garbage input still returns None."""
        mapper = ClaimIdMapper()
        assert mapper.resolve("not-a-uuid", strict=True) is None
        assert mapper.resolve("", strict=True) is None

    def test_strict_out_of_range_int_still_none(self):
        """strict=True: out-of-range integer refs still return None."""
        mapper = ClaimIdMapper()
        mapper.to_short(_make_uuid())  # only ID 1 registered
        assert mapper.resolve("999", strict=True) is None

    def test_strict_mixed_case_uuid_accepted(self):
        """strict=True: UUID registered in one casing is accepted in another casing.

        Regression guard: UUIDs are case-insensitive (RFC 4122). A UUID registered
        as lowercase must be found when the LLM returns it in uppercase, and
        vice versa. Without case-normalisation, valid contradictions are skipped.
        """
        mapper = ClaimIdMapper()
        # Register in lowercase
        uid_lower = "550e8400-e29b-41d4-a716-446655440000"
        mapper.to_short(uid_lower)

        # LLM returns uppercase variant
        uid_upper = uid_lower.upper()
        result = mapper.resolve(uid_upper, strict=True)
        assert result is not None, (
            f"strict=True must accept {uid_upper!r} — it was registered as {uid_lower!r}; "
            "UUID casing must not cause valid IDs to be rejected"
        )

    def test_to_short_case_insensitive_idempotent(self):
        """to_short() is idempotent across UUID casing variants (RFC 4122).

        Registering the same UUID in different casing should return the same
        short integer and not create a duplicate entry.
        """
        mapper = ClaimIdMapper()
        uid_lower = "550e8400-e29b-41d4-a716-446655440000"
        uid_upper = uid_lower.upper()

        s1 = mapper.to_short(uid_lower)
        s2 = mapper.to_short(uid_upper)
        assert s1 == s2, "Same UUID in different casing must map to the same short int"
        assert mapper.size == 1, "Case variants must not create duplicate entries"
