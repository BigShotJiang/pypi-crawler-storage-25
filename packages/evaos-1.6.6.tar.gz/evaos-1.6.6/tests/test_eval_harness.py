"""
tests/test_eval_harness.py — Unit tests for EvalHarness with mock plugin.

Strategy:
  - Mock the CortexPlugin entirely (no real DB, no real LLM)
  - Test the full harness pipeline: remember → retrieve → score → report
  - Test error handling: remember fails, retrieve fails
  - Test LLM judge integration
  - Test report structure and summary output
"""
from __future__ import annotations

import asyncio
import pytest
import pytest_asyncio
from dataclasses import dataclass, field
from typing import Any, List, Optional
from unittest.mock import AsyncMock, MagicMock

import cortex.eval.harness as harness_module
from cortex.eval.harness import EvalHarness, EvalReport, SessionResult, QuestionResult
from cortex.eval.locomo import LoCoMoLoader
from cortex.eval.longmemeval import LongMemEvalLoader


# ---------------------------------------------------------------------------
# Mock plugin
# ---------------------------------------------------------------------------

@dataclass
class _MockRememberResult:
    session_id: str
    claims_stored: int = 2
    claims_extracted: int = 2
    ok: bool = True
    errors: List[str] = field(default_factory=list)


@dataclass
class _MockRetrievalResult:
    formatted_context: str = ""
    memories: List[Any] = field(default_factory=list)


_UNSET = object()


class MockCortexPlugin:
    """A mock CortexPlugin that returns controllable responses."""

    def __init__(
        self,
        remember_result=_UNSET,
        retrieve_content: str = "",
        remember_raises: Optional[Exception] = None,
        retrieve_raises: Optional[Exception] = None,
        reconciler: Optional[Any] = None,
        retrieve_result: Any = _UNSET,
    ):
        self._remember_result = _MockRememberResult(session_id="test") if remember_result is _UNSET else remember_result
        self._retrieve_content = retrieve_content
        self._remember_raises = remember_raises
        self._retrieve_raises = retrieve_raises
        self._retrieve_result = retrieve_result
        self.remember_calls = []
        self.retrieve_calls = []
        self.reconciler = reconciler

    async def remember(self, conversation, session_id=None, scope="user", owner_id=None, **kwargs):
        self.remember_calls.append((conversation, session_id, scope))
        if self._remember_raises:
            raise self._remember_raises
        return self._remember_result

    async def retrieve(self, query, token_budget=None, constraints=None, mode="auto", owner_id=None, **kwargs):
        self.retrieve_calls.append((query, token_budget, constraints, mode))
        if self._retrieve_raises:
            raise self._retrieve_raises
        if self._retrieve_result is not _UNSET:
            return self._retrieve_result
        return _MockRetrievalResult(formatted_context=self._retrieve_content)


# ---------------------------------------------------------------------------
# LoCoMo harness tests
# ---------------------------------------------------------------------------

class TestEvalHarnessLocomo:
    """Tests for harness.run_locomo()."""

    @pytest.mark.asyncio
    async def test_run_locomo_sample(self):
        """Full pipeline with sample dataset, plugin returns empty answers."""
        plugin = MockCortexPlugin(retrieve_content="")
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()

        assert isinstance(report, EvalReport)
        assert report.dataset_name == "locomo_sample"
        assert len(report.session_results) == 5
        assert report.metrics["total_questions"] == 20
        assert 0.0 <= report.metrics["exact_match_accuracy"] <= 1.0

    @pytest.mark.asyncio
    async def test_run_locomo_perfect_answers(self):
        """Plugin returns the exact expected answer for every question."""
        # We need to make the mock return the answer for each retrieve call
        # Since we can't know the question order, use a side_effect approach
        from cortex.eval.locomo import LoCoMoLoader

        loader = LoCoMoLoader()
        dataset = loader.load()

        # Build a lookup: question → answer
        qa_lookup = {}
        for session in dataset.sessions:
            for qa in session.qa_pairs:
                qa_lookup[qa.question] = qa.answer

        class SmartMockPlugin:
            async def remember(self, conversation, session_id=None, scope="user", owner_id=None, **kwargs):
                return _MockRememberResult(session_id=session_id or "test")

            async def retrieve(self, query, **kwargs):
                answer = qa_lookup.get(query, "")
                return _MockRetrievalResult(formatted_context=answer)

        harness = EvalHarness(SmartMockPlugin())
        report = await harness.run_locomo(dataset_dict={"sessions": [
            {
                "session_id": s.session_id,
                "conversation": s.conversation,
                "qa_pairs": [
                    {"question_id": qa.question_id, "question": qa.question, "answer": qa.answer, "type": qa.question_type}
                    for qa in s.qa_pairs
                ],
            }
            for s in dataset.sessions
        ]})

        # All answers are exact → exact_match_accuracy should be 1.0
        assert report.metrics["exact_match_accuracy"] == pytest.approx(1.0)
        assert report.metrics["fuzzy_match_accuracy"] == pytest.approx(1.0)
        assert report.metrics["avg_token_f1"] == pytest.approx(1.0)

    @pytest.mark.asyncio
    async def test_run_locomo_remember_fails(self):
        """remember() failure is recorded but evaluation continues."""
        plugin = MockCortexPlugin(
            remember_raises=RuntimeError("DB down"),
            retrieve_content="hiking",
        )
        harness = EvalHarness(plugin, max_session_failures=999)
        report = await harness.run_locomo()

        # All sessions should still have results
        assert len(report.session_results) == 5
        for sr in report.session_results:
            assert sr.remember_error is not None
            assert "DB down" in sr.remember_error

    @pytest.mark.asyncio
    async def test_run_locomo_retrieve_fails(self):
        """retrieve() failure is recorded per question as empty answer."""
        plugin = MockCortexPlugin(retrieve_raises=RuntimeError("Retrieval down"))
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()

        for sr in report.session_results:
            for qr in sr.question_results:
                assert qr.error is not None
                assert qr.predicted_answer == ""
                assert qr.exact_hit is False

    @pytest.mark.asyncio
    async def test_run_locomo_calls_remember_per_session(self):
        """remember() is called once per session."""
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        await harness.run_locomo()

        assert len(plugin.remember_calls) == 5  # 5 sessions

    @pytest.mark.asyncio
    async def test_run_locomo_calls_retrieve_per_question(self):
        """retrieve() is called once per question."""
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        await harness.run_locomo()

        assert len(plugin.retrieve_calls) == 20  # 20 questions total


# ---------------------------------------------------------------------------
# LongMemEval harness tests
# ---------------------------------------------------------------------------

class TestEvalHarnessLongMemEval:
    @pytest.mark.asyncio
    async def test_run_longmemeval_sample(self):
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        report = await harness.run_longmemeval()

        assert isinstance(report, EvalReport)
        assert report.dataset_name == "longmemeval_sample"
        assert len(report.session_results) == 5
        assert report.metrics["total_questions"] > 0

    @pytest.mark.asyncio
    async def test_run_longmemeval_remember_called(self):
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        await harness.run_longmemeval()
        assert len(plugin.remember_calls) == 5


# ---------------------------------------------------------------------------
# Adversarial scoring (#1274) — must work in ALL modes
# ---------------------------------------------------------------------------

class TestAdversarialScoring:
    """Adversarial (category 5) questions must use adversarial_accuracy in all modes."""

    @pytest.mark.asyncio
    async def test_adversarial_retrieval_only_correct_refusal(self):
        """In retrieval-only mode, adversarial q scored by refusal, not exact match."""
        # Plugin returns "no information available" for adversarial questions
        plugin = MockCortexPlugin(retrieve_content="No information available about that topic")
        harness = EvalHarness(plugin, mode="retrieval-only")

        # Build a dataset with a category-5 question
        dataset = {
            "sessions": [{
                "session_id": "s1",
                "conversation": [
                    {"role": "user", "content": "Hello"},
                    {"role": "assistant", "content": "Hi there"},
                ],
                "qa_pairs": [{
                    "question_id": "adv_q1",
                    "question": "What is the user's blood type?",
                    "answer": "Not mentioned in the conversation",
                    "type": "adversarial",
                    "category": 5,
                }],
            }],
        }

        report = await harness.run_locomo(dataset_dict=dataset)
        qr = report.session_results[0].question_results[0]

        # Category 5 → should be scored with adversarial_accuracy
        assert qr.exact_hit is True  # "no information" detected
        assert qr.fuzzy_hit is True
        assert qr.token_f1 == 1.0

    @pytest.mark.asyncio
    async def test_adversarial_retrieval_only_incorrect_answer(self):
        """In retrieval-only mode, cat-5 question with a concrete answer → 0."""
        plugin = MockCortexPlugin(retrieve_content="The user's blood type is AB+")
        harness = EvalHarness(plugin, mode="retrieval-only")

        dataset = {
            "sessions": [{
                "session_id": "s1",
                "conversation": [{"role": "user", "content": "Hello"}],
                "qa_pairs": [{
                    "question_id": "adv_q1",
                    "question": "What is the user's blood type?",
                    "answer": "Not mentioned",
                    "type": "adversarial",
                    "category": 5,
                }],
            }],
        }

        report = await harness.run_locomo(dataset_dict=dataset)
        qr = report.session_results[0].question_results[0]

        # System answered when it should have refused
        assert qr.exact_hit is False
        assert qr.token_f1 == 0.0

    @pytest.mark.asyncio
    async def test_adversarial_accuracy_in_report_metrics(self):
        """Report includes adversarial_accuracy aggregate metric."""
        plugin = MockCortexPlugin(retrieve_content="No information available")
        harness = EvalHarness(plugin, mode="retrieval-only")

        dataset = {
            "sessions": [{
                "session_id": "s1",
                "conversation": [{"role": "user", "content": "Hello"}],
                "qa_pairs": [
                    {"question_id": "q1", "question": "normal q", "answer": "x", "category": 2},
                    {"question_id": "q2", "question": "adv q", "answer": "not mentioned", "category": 5},
                ],
            }],
        }

        report = await harness.run_locomo(dataset_dict=dataset)
        assert "adversarial_accuracy" in report.metrics
        assert report.metrics["adversarial_accuracy"] == 1.0
        assert report.metrics["adversarial_n"] == 1

    def test_build_report_adds_category_aware_metrics(self, monkeypatch):
        """_build_report uses score_by_category and exposes LoCoMo category metrics."""
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin, mode="retrieval-only")

        calls = []

        def fake_score_by_category(prediction, reference, category):
            calls.append((prediction, reference, category))
            return {1: 0.2, 2: 0.8, 5: 1.0}[category]

        monkeypatch.setattr(harness_module, "score_by_category", fake_score_by_category)

        session_results = [
            SessionResult(
                session_id="s1",
                question_results=[
                    QuestionResult(
                        question_id="q1",
                        question="multi-hop",
                        expected_answer="ref1",
                        predicted_answer="pred1",
                        exact_hit=False,
                        fuzzy_hit=False,
                        token_f1=0.0,
                        llm_judge_score=None,
                        remember_latency_ms=0.0,
                        retrieve_latency_ms=0.0,
                        category=1,
                    ),
                    QuestionResult(
                        question_id="q2",
                        question="single-hop",
                        expected_answer="ref2",
                        predicted_answer="pred2",
                        exact_hit=False,
                        fuzzy_hit=False,
                        token_f1=0.0,
                        llm_judge_score=None,
                        remember_latency_ms=0.0,
                        retrieve_latency_ms=0.0,
                        category=2,
                    ),
                    QuestionResult(
                        question_id="q3",
                        question="adversarial",
                        expected_answer="not mentioned",
                        predicted_answer="no information available",
                        exact_hit=False,
                        fuzzy_hit=False,
                        token_f1=0.0,
                        llm_judge_score=None,
                        remember_latency_ms=0.0,
                        retrieve_latency_ms=0.0,
                        category=5,
                    ),
                ],
            )
        ]

        report = harness._build_report("locomo", session_results)

        assert calls == [
            ("pred1", "ref1", 1),
            ("pred2", "ref2", 2),
            ("no information available", "not mentioned", 5),
        ]
        assert report.metrics["avg_category_f1"] == pytest.approx((0.2 + 0.8 + 1.0) / 3)
        assert report.metrics["category_1_f1"] == pytest.approx(0.2)
        assert report.metrics["category_2_f1"] == pytest.approx(0.8)
        assert report.metrics["category_5_f1"] == pytest.approx(1.0)
        assert "avg_token_f1" in report.metrics

    def test_build_report_skips_unsupported_categories(self, monkeypatch):
        """_build_report ignores categories outside 1-5 and category <= 0."""
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin, mode="retrieval-only")

        calls = []

        def fake_score_by_category(prediction, reference, category):
            calls.append(category)
            return 0.5

        monkeypatch.setattr(harness_module, "score_by_category", fake_score_by_category)

        session_results = [
            SessionResult(
                session_id="s1",
                question_results=[
                    QuestionResult(
                        question_id="q1", question="valid", expected_answer="ref",
                        predicted_answer="pred", exact_hit=False, fuzzy_hit=False,
                        token_f1=0.0, llm_judge_score=None, remember_latency_ms=0.0,
                        retrieve_latency_ms=0.0, category=2,
                    ),
                    QuestionResult(
                        question_id="q2", question="invalid-high", expected_answer="ref",
                        predicted_answer="pred", exact_hit=False, fuzzy_hit=False,
                        token_f1=0.0, llm_judge_score=None, remember_latency_ms=0.0,
                        retrieve_latency_ms=0.0, category=6,
                    ),
                    QuestionResult(
                        question_id="q3", question="invalid-zero", expected_answer="ref",
                        predicted_answer="pred", exact_hit=False, fuzzy_hit=False,
                        token_f1=0.0, llm_judge_score=None, remember_latency_ms=0.0,
                        retrieve_latency_ms=0.0, category=0,
                    ),
                    QuestionResult(
                        question_id="q4", question="invalid-neg", expected_answer="ref",
                        predicted_answer="pred", exact_hit=False, fuzzy_hit=False,
                        token_f1=0.0, llm_judge_score=None, remember_latency_ms=0.0,
                        retrieve_latency_ms=0.0, category=-1,
                    ),
                ],
            )
        ]

        report = harness._build_report("locomo", session_results)

        # Only category 2 should have been scored
        assert calls == [2]
        assert "category_2_f1" in report.metrics
        assert "category_6_f1" not in report.metrics
        assert "category_0_f1" not in report.metrics

    @pytest.mark.asyncio
    async def test_claims_extracted_in_report(self):
        """Report includes total_claims_extracted metric (#1273)."""
        plugin = MockCortexPlugin(
            remember_result=_MockRememberResult(session_id="test", claims_stored=3, claims_extracted=5),
            retrieve_content="answer",
        )
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()
        assert "total_claims_extracted" in report.metrics
        assert report.metrics["total_claims_stored"] == 15  # 5 sessions × 3 claims_stored
        assert report.metrics["total_claims_extracted"] == 15  # compat alias


# ---------------------------------------------------------------------------
# Eval ingestion configuration
# ---------------------------------------------------------------------------

class TestEvalInputValidation:
    @pytest.mark.asyncio
    async def test_remember_none_is_recorded_as_failure(self):
        plugin = MockCortexPlugin(remember_result=None)
        harness = EvalHarness(plugin, max_session_failures=999)
        report = await harness.run_locomo()

        for sr in report.session_results:
            assert sr.remember_error is not None
            assert "returned None" in sr.remember_error

    @pytest.mark.asyncio
    async def test_remember_result_missing_session_id_is_recorded_as_failure(self):
        class IncompleteRememberResult:
            claims_stored = 1

        plugin = MockCortexPlugin(remember_result=IncompleteRememberResult())
        harness = EvalHarness(plugin, max_session_failures=999)
        report = await harness.run_locomo()

        for sr in report.session_results:
            assert sr.remember_error is not None
            assert "missing session_id" in sr.remember_error

    @pytest.mark.asyncio
    async def test_retrieve_none_is_recorded_as_error(self):
        plugin = MockCortexPlugin(retrieve_result=None)
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()

        for sr in report.session_results:
            for qr in sr.question_results:
                assert qr.error is not None
                assert "returned None" in qr.error
                assert qr.predicted_answer == ""

    def test_locomo_loader_rejects_missing_session_id(self):
        loader = LoCoMoLoader()
        with pytest.raises(ValueError, match="session_id"):
            loader.load_dict({
                "sessions": [{
                    "conversation": [],
                    "qa_pairs": [{"question_id": "q1", "question": "Q?", "answer": "A"}],
                }]
            })

    def test_locomo_loader_rejects_missing_answer(self):
        loader = LoCoMoLoader()
        with pytest.raises(ValueError, match="answer"):
            loader.load_dict({
                "sessions": [{
                    "session_id": "s1",
                    "conversation": [],
                    "qa_pairs": [{"question_id": "q1", "question": "Q?"}],
                }]
            })

    def test_longmemeval_loader_rejects_missing_questions(self):
        loader = LongMemEvalLoader()
        with pytest.raises(ValueError, match="questions"):
            loader.load_dict({"sessions": [{"session_id": "s1", "turns": []}]})

    def test_nan_rag_scores_are_filtered_from_report_metrics(self):
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        report = harness._build_report(
            "test",
            [SessionResult(session_id="s1", question_results=[QuestionResult(
                question_id="q1",
                question="Q?",
                expected_answer="A",
                predicted_answer="A",
                exact_hit=True,
                fuzzy_hit=True,
                token_f1=1.0,
                llm_judge_score=float("nan"),
                remember_latency_ms=1.0,
                retrieve_latency_ms=1.0,
                rag_judge_score=float("inf"),
            )])],
        )
        assert "avg_llm_judge_score" not in report.metrics
        assert "rag_judge_accuracy" not in report.metrics


class TestEvalIngestionConfiguration:
    def test_disables_reconciliation_llm_calls_by_default(self):
        reconciler = MagicMock()
        reconciler.max_llm_calls_per_batch = 5
        plugin = MockCortexPlugin(reconciler=reconciler)

        harness = EvalHarness(plugin)

        assert harness.reconciliation_llm_calls_per_batch == 0
        assert plugin.reconciler.max_llm_calls_per_batch == 0

    def test_full_pipeline_override_preserves_existing_reconciliation_budget(self):
        reconciler = MagicMock()
        reconciler.max_llm_calls_per_batch = 5
        plugin = MockCortexPlugin(reconciler=reconciler)

        harness = EvalHarness(plugin, reconciliation_llm_calls_per_batch=None)

        assert harness.reconciliation_llm_calls_per_batch is None
        assert plugin.reconciler.max_llm_calls_per_batch == 5


# ---------------------------------------------------------------------------
# Answer extraction
# ---------------------------------------------------------------------------

class TestAnswerExtraction:
    def test_extract_formatted_context(self):
        harness = EvalHarness(MagicMock())
        result = MagicMock()
        result.items = None
        result.formatted_context = "hiking"
        result.memories = []
        assert harness._extract_answer(result, "question") == "hiking"

    def test_extract_from_memories_list(self):
        harness = EvalHarness(MagicMock())

        @dataclass
        class MemObj:
            content: str

        result = MagicMock()
        result.items = None
        result.formatted_context = ""
        result.memories = [MemObj(content="hiking"), MemObj(content="marathon")]
        extracted = harness._extract_answer(result, "question")
        assert "hiking" in extracted

    def test_extract_none_result(self):
        harness = EvalHarness(MagicMock())
        assert harness._extract_answer(None, "question") == ""

    def test_extract_fallback_to_str(self):
        harness = EvalHarness(MagicMock())
        result = MagicMock()
        result.items = None
        result.formatted_context = ""
        result.memories = []
        result.context_window = "fallback answer"
        assert harness._extract_answer(result, "question") == "fallback answer"


# ---------------------------------------------------------------------------
# Best-single-claim scoring
# ---------------------------------------------------------------------------

class TestBestSingleClaimScoring:
    """Test that _eval_question() picks the single best claim, not the concatenation."""

    @pytest.mark.asyncio
    async def test_best_claim_selected_from_multiple(self):
        """3 claims retrieved, one matches expected → predicted_answer is that one claim."""
        plugin = MagicMock()
        result = MagicMock()
        result.items = [
            MagicMock(content="Alice likes swimming"),
            MagicMock(content="Bob enjoys hiking"),
            MagicMock(content="Carol plays tennis"),
        ]
        result.formatted_context = ""
        result.memories = []
        plugin.retrieve = AsyncMock(return_value=result)

        harness = EvalHarness(plugin)
        qr = await harness._eval_question(
            question_id="q1",
            question="What does Bob enjoy?",
            expected_answer="hiking",
            remember_latency_ms=0.0,
        )
        # The best single claim should be the one containing "hiking"
        assert "hiking" in qr.predicted_answer
        assert "swimming" not in qr.predicted_answer
        assert "tennis" not in qr.predicted_answer
        assert qr.token_f1 > 0.0
        # predicted_context should have all claims concatenated
        assert qr.predicted_context is not None
        assert "swimming" in qr.predicted_context
        assert "hiking" in qr.predicted_context

    @pytest.mark.asyncio
    async def test_no_claims_returns_empty(self):
        """No claims retrieved → predicted_answer is empty."""
        plugin = MagicMock()
        plugin.retrieve = AsyncMock(return_value=None)

        harness = EvalHarness(plugin)
        qr = await harness._eval_question(
            question_id="q2",
            question="What is X?",
            expected_answer="something",
            remember_latency_ms=0.0,
        )
        assert qr.predicted_answer == ""
        assert qr.error is not None  # retrieve returned None → RuntimeError

    @pytest.mark.asyncio
    async def test_best_of_n_picks_highest_f1(self):
        """Best-of-N selection picks the candidate with highest F1 vs expected."""
        plugin = MagicMock()
        result = MagicMock()
        result.items = [
            MagicMock(content="The weather is sunny today"),
            MagicMock(content="She goes hiking every weekend"),
            MagicMock(content="hiking is her favorite hobby"),
        ]
        result.formatted_context = ""
        result.memories = []
        plugin.retrieve = AsyncMock(return_value=result)

        harness = EvalHarness(plugin)
        qr = await harness._eval_question(
            question_id="q3",
            question="What is her hobby?",
            expected_answer="hiking",
            remember_latency_ms=0.0,
        )
        # "hiking is her favorite hobby" should score highest F1 against "hiking"
        # because "hiking" appears and it's shorter (better precision)
        assert "hiking" in qr.predicted_answer
        assert qr.token_f1 > 0.0


# ---------------------------------------------------------------------------
# LLM judge integration
# ---------------------------------------------------------------------------

class TestLLMJudge:
    @pytest.mark.asyncio
    async def test_llm_judge_called(self):
        judge_calls = []

        def fake_judge(question, prediction, reference):
            judge_calls.append((question, prediction, reference))
            return 1.0 if prediction.lower() == reference.lower() else 0.0

        plugin = MockCortexPlugin(retrieve_content="hiking")
        harness = EvalHarness(plugin, llm_judge=fake_judge)
        report = await harness.run_locomo()

        assert len(judge_calls) == 20  # called for each question
        assert "avg_llm_judge_score" in report.metrics

    @pytest.mark.asyncio
    async def test_llm_judge_score_range(self):
        def fake_judge(question, prediction, reference):
            return 0.8

        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin, llm_judge=fake_judge)
        report = await harness.run_locomo()

        score = report.metrics["avg_llm_judge_score"]
        assert 0.0 <= score <= 1.0


# ---------------------------------------------------------------------------
# EvalReport
# ---------------------------------------------------------------------------

class TestEvalReport:
    @pytest.mark.asyncio
    async def test_summary_output(self):
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()
        summary = report.summary()
        assert "locomo_sample" in summary
        assert "Exact match" in summary
        assert "Fuzzy match" in summary

    @pytest.mark.asyncio
    async def test_to_dict_structure(self):
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()
        d = report.to_dict()

        assert "dataset_name" in d
        assert "metrics" in d
        assert "sessions" in d
        assert "config" in d
        assert len(d["sessions"]) == 5

    @pytest.mark.asyncio
    async def test_metrics_keys(self):
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()
        m = report.metrics

        for key in ["exact_match_accuracy", "fuzzy_match_accuracy", "avg_token_f1", "mrr",
                    "total_questions", "total_sessions", "retrieve_latency", "remember_latency"]:
            assert key in m, f"Missing metric: {key}"

    @pytest.mark.asyncio
    async def test_latency_recorded(self):
        plugin = MockCortexPlugin()
        harness = EvalHarness(plugin)
        report = await harness.run_locomo()

        lat = report.metrics["retrieve_latency"]
        assert lat["count"] == 20
        assert lat["mean"] >= 0.0
