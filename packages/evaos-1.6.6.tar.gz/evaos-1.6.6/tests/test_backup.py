"""
test_backup.py — Unit tests for backup_cortex.py

Tests mock S3 and verify:
- VACUUM INTO creates a clean temp copy
- Multipart upload is initiated and completed
- Gzip compression is applied
- Old backups beyond KEEP_COUNT are pruned
- Temp file is cleaned up after upload
- Failure paths return non-zero exit codes
"""

import gzip
import os
import sqlite3
import sys
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest

# Add scripts dir to path so we can import backup_cortex directly
scripts_dir = Path(__file__).parent.parent / "scripts"
sys.path.insert(0, str(scripts_dir))

# Skip entire module if boto3 is not installed (CI runners don't have it)
boto3 = pytest.importorskip("boto3", reason="boto3 not installed")


class TestStreamUpload(unittest.TestCase):
    """Tests for stream_file_to_s3_multipart."""

    def _make_temp_db(self, size_bytes: int = 512 * 1024) -> Path:
        """Create a real SQLite DB with some data."""
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp.close()
        path = Path(tmp.name)
        conn = sqlite3.connect(str(path))
        conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, data TEXT)")
        # Insert enough rows to reach roughly the desired size
        rows = size_bytes // 50
        conn.executemany(
            "INSERT INTO t (data) VALUES (?)",
            [(f"{'x' * 45}",) for _ in range(rows)],
        )
        conn.commit()
        conn.close()
        return path

    def test_multipart_upload_initiated_and_completed(self):
        """Multipart upload should be created and completed (not aborted)."""
        from backup_cortex import stream_file_to_s3_multipart

        source = self._make_temp_db(100 * 1024)  # 100KB — fits in one part
        try:
            mock_s3 = MagicMock()
            mock_s3.create_multipart_upload.return_value = {"UploadId": "test-upload-id"}
            mock_s3.upload_part.return_value = {"ETag": '"abc123"'}

            stream_file_to_s3_multipart(mock_s3, source, "test-bucket", "test-key")

            mock_s3.create_multipart_upload.assert_called_once_with(
                Bucket="test-bucket",
                Key="test-key",
                ContentType="application/gzip",
            )
            mock_s3.complete_multipart_upload.assert_called_once()
            mock_s3.abort_multipart_upload.assert_not_called()
        finally:
            source.unlink(missing_ok=True)

    def test_upload_produces_valid_gzip(self):
        """Data uploaded to S3 should be valid gzip-compressed SQLite."""
        from backup_cortex import stream_file_to_s3_multipart

        source = self._make_temp_db(200 * 1024)
        captured_parts = []

        try:
            mock_s3 = MagicMock()
            mock_s3.create_multipart_upload.return_value = {"UploadId": "uid-1"}

            def capture_part(**kwargs):
                captured_parts.append(kwargs["Body"])
                return {"ETag": f'"etag-{kwargs["PartNumber"]}"'}

            mock_s3.upload_part.side_effect = capture_part

            stream_file_to_s3_multipart(mock_s3, source, "bucket", "key")

            # Combine all parts and decompress
            combined = b"".join(
                p if isinstance(p, bytes) else p.getvalue()
                for p in captured_parts
            )
            decompressed = gzip.decompress(combined)

            # Should start with SQLite magic bytes
            self.assertTrue(
                decompressed[:16].startswith(b"SQLite format 3"),
                "Decompressed data should be a valid SQLite file",
            )
        finally:
            source.unlink(missing_ok=True)

    def test_upload_aborted_on_error(self):
        """Multipart upload should be aborted if upload_part raises."""
        from backup_cortex import stream_file_to_s3_multipart

        source = self._make_temp_db(50 * 1024)
        try:
            mock_s3 = MagicMock()
            mock_s3.create_multipart_upload.return_value = {"UploadId": "uid-fail"}
            mock_s3.upload_part.side_effect = RuntimeError("network error")

            with self.assertRaises(RuntimeError):
                stream_file_to_s3_multipart(mock_s3, source, "bucket", "key")

            mock_s3.abort_multipart_upload.assert_called_once_with(
                Bucket="bucket", Key="key", UploadId="uid-fail"
            )
        finally:
            source.unlink(missing_ok=True)

    def test_returns_compressed_byte_count(self):
        """Return value should be total bytes uploaded (compressed)."""
        from backup_cortex import stream_file_to_s3_multipart

        source = self._make_temp_db(100 * 1024)
        try:
            mock_s3 = MagicMock()
            mock_s3.create_multipart_upload.return_value = {"UploadId": "uid-size"}

            part_data_holder = []

            def capture_part(**kwargs):
                part_data_holder.append(kwargs["Body"])
                return {"ETag": '"etag"'}

            mock_s3.upload_part.side_effect = capture_part

            total = stream_file_to_s3_multipart(mock_s3, source, "bucket", "key")

            expected = sum(len(p) for p in part_data_holder)
            self.assertEqual(total, expected)
            self.assertGreater(total, 0)
        finally:
            source.unlink(missing_ok=True)


class TestPruneOldBackups(unittest.TestCase):
    """Tests for prune_old_backups."""

    def _make_mock_object(self, key: str, days_ago: int) -> dict:
        from datetime import datetime, timezone, timedelta
        return {
            "Key": key,
            "Size": 1024,
            "LastModified": datetime.now(timezone.utc) - timedelta(days=days_ago),
        }

    def test_prunes_beyond_keep_count(self):
        """Should delete all backups beyond KEEP_COUNT, oldest first."""
        from backup_cortex import prune_old_backups

        # 35 backups, keep 30 → should delete 5 oldest
        objects = [
            self._make_mock_object(f"backups/cortex-backup-2024010{i:01d}-0000.db.gz", 35 - i)
            for i in range(35)
        ]

        mock_s3 = MagicMock()
        paginator = MagicMock()
        mock_s3.get_paginator.return_value = paginator
        paginator.paginate.return_value = [{"Contents": objects}]

        deleted = prune_old_backups(mock_s3, "bucket", "backups/", keep=30)

        self.assertEqual(deleted, 5)
        mock_s3.delete_objects.assert_called_once()
        deleted_keys = {
            o["Key"]
            for o in mock_s3.delete_objects.call_args[1]["Delete"]["Objects"]
        }
        # The 5 oldest should be the ones deleted (days_ago 35..31)
        self.assertEqual(len(deleted_keys), 5)

    def test_no_deletion_when_under_limit(self):
        """Should not call delete_objects when backup count <= KEEP_COUNT."""
        from backup_cortex import prune_old_backups

        objects = [
            self._make_mock_object(f"backups/cortex-backup-202401{i:02d}-0000.db.gz", i)
            for i in range(10)
        ]

        mock_s3 = MagicMock()
        paginator = MagicMock()
        mock_s3.get_paginator.return_value = paginator
        paginator.paginate.return_value = [{"Contents": objects}]

        deleted = prune_old_backups(mock_s3, "bucket", "backups/", keep=30)

        self.assertEqual(deleted, 0)
        mock_s3.delete_objects.assert_not_called()

    def test_empty_bucket(self):
        """Should handle empty bucket gracefully."""
        from backup_cortex import prune_old_backups

        mock_s3 = MagicMock()
        paginator = MagicMock()
        mock_s3.get_paginator.return_value = paginator
        paginator.paginate.return_value = [{}]  # No Contents key

        deleted = prune_old_backups(mock_s3, "bucket", "backups/", keep=30)
        self.assertEqual(deleted, 0)


class TestRunBackup(unittest.TestCase):
    """Integration-style tests for run_backup() with mocked S3 + VACUUM."""

    def setUp(self):
        # Create a real source DB
        self.tmp_dir = tempfile.mkdtemp()
        self.db_path = Path(self.tmp_dir) / "cortex.db"
        self.temp_path = Path(self.tmp_dir) / "cortex-backup-temp.db"

        conn = sqlite3.connect(str(self.db_path))
        conn.execute("CREATE TABLE memories (id INTEGER PRIMARY KEY, content TEXT)")
        conn.execute("INSERT INTO memories VALUES (1, 'test memory')")
        conn.commit()
        conn.close()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def _run_with_mocks(self, env_overrides=None):
        """Run backup with mocked S3 and patched paths."""
        import backup_cortex as bc

        env = {
            "AWS_ACCESS_KEY_ID": "test-key",
            "AWS_SECRET_ACCESS_KEY": "test-secret",
            "AWS_REGION": "us-east-1",
        }
        if env_overrides:
            env.update(env_overrides)

        mock_s3 = MagicMock()
        mock_s3.create_multipart_upload.return_value = {"UploadId": "test-uid"}
        mock_s3.upload_part.return_value = {"ETag": '"etag"'}
        mock_s3.head_bucket.return_value = {}
        paginator = MagicMock()
        mock_s3.get_paginator.return_value = paginator
        paginator.paginate.return_value = [{}]

        with patch.object(bc, "DB_PATH", self.db_path), \
             patch.object(bc, "TEMP_PATH", self.temp_path), \
             patch.object(bc, "S3_BUCKET", "test-bucket"), \
             patch.object(bc, "S3_PREFIX", "backups/"), \
             patch.object(bc, "KEEP_COUNT", 30), \
             patch.dict(os.environ, env), \
             patch("boto3.client", return_value=mock_s3):
            return bc.run_backup(), mock_s3

    def test_successful_backup_returns_zero(self):
        """Full backup run should return exit code 0."""
        exit_code, _ = self._run_with_mocks()
        self.assertEqual(exit_code, 0)

    def test_temp_file_cleaned_up_after_success(self):
        """Temp file should be deleted after successful upload."""
        self._run_with_mocks()
        self.assertFalse(
            self.temp_path.exists(),
            "Temp file should be deleted after backup",
        )

    def test_multipart_upload_called(self):
        """S3 multipart upload should be called during backup."""
        _, mock_s3 = self._run_with_mocks()
        mock_s3.create_multipart_upload.assert_called_once()
        mock_s3.complete_multipart_upload.assert_called_once()

    def test_prune_called(self):
        """Pruning should be attempted after upload."""
        _, mock_s3 = self._run_with_mocks()
        mock_s3.get_paginator.assert_called_with("list_objects_v2")

    def test_missing_db_returns_nonzero(self):
        """Should return non-zero if DB_PATH doesn't exist."""
        import backup_cortex as bc

        with patch.object(bc, "DB_PATH", Path("/nonexistent/cortex.db")), \
             patch.dict(os.environ, {"AWS_ACCESS_KEY_ID": "x", "AWS_SECRET_ACCESS_KEY": "x"}):
            exit_code = bc.run_backup()

        self.assertNotEqual(exit_code, 0)

    def test_missing_aws_creds_returns_nonzero(self):
        """Should return non-zero if AWS credentials are missing."""
        import backup_cortex as bc

        clean_env = {k: v for k, v in os.environ.items()
                     if k not in ("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY")}

        with patch.object(bc, "DB_PATH", self.db_path), \
             patch.object(bc, "TEMP_PATH", self.temp_path), \
             patch.dict(os.environ, clean_env, clear=True):
            exit_code = bc.run_backup()

        self.assertNotEqual(exit_code, 0)

    def test_s3_upload_failure_returns_nonzero(self):
        """Should return non-zero if S3 upload fails."""
        import backup_cortex as bc

        mock_s3 = MagicMock()
        mock_s3.create_multipart_upload.return_value = {"UploadId": "uid"}
        mock_s3.head_bucket.return_value = {}
        mock_s3.upload_part.side_effect = RuntimeError("S3 error")

        with patch.object(bc, "DB_PATH", self.db_path), \
             patch.object(bc, "TEMP_PATH", self.temp_path), \
             patch.dict(os.environ, {
                 "AWS_ACCESS_KEY_ID": "x",
                 "AWS_SECRET_ACCESS_KEY": "x",
             }), \
             patch("boto3.client", return_value=mock_s3):
            exit_code = bc.run_backup()

        self.assertNotEqual(exit_code, 0)

    def test_temp_file_cleaned_up_after_failure(self):
        """Temp file should also be cleaned up after upload failure."""
        import backup_cortex as bc

        mock_s3 = MagicMock()
        mock_s3.create_multipart_upload.return_value = {"UploadId": "uid"}
        mock_s3.head_bucket.return_value = {}
        mock_s3.upload_part.side_effect = RuntimeError("S3 error")

        with patch.object(bc, "DB_PATH", self.db_path), \
             patch.object(bc, "TEMP_PATH", self.temp_path), \
             patch.dict(os.environ, {
                 "AWS_ACCESS_KEY_ID": "x",
                 "AWS_SECRET_ACCESS_KEY": "x",
             }), \
             patch("boto3.client", return_value=mock_s3):
            bc.run_backup()

        self.assertFalse(
            self.temp_path.exists(),
            "Temp file should be deleted even after failure",
        )

    def test_backup_key_format(self):
        """S3 key should match cortex-backup-YYYYMMDD-HHMM.db.gz pattern."""
        import re
        import backup_cortex as bc

        captured_keys = []
        mock_s3 = MagicMock()
        mock_s3.head_bucket.return_value = {}
        mock_s3.get_paginator.return_value.paginate.return_value = [{}]

        def capture_create(**kwargs):
            captured_keys.append(kwargs["Key"])
            return {"UploadId": "uid"}

        mock_s3.create_multipart_upload.side_effect = capture_create
        mock_s3.upload_part.return_value = {"ETag": '"etag"'}

        with patch.object(bc, "DB_PATH", self.db_path), \
             patch.object(bc, "TEMP_PATH", self.temp_path), \
             patch.object(bc, "S3_BUCKET", "bucket"), \
             patch.object(bc, "S3_PREFIX", "backups/"), \
             patch.dict(os.environ, {
                 "AWS_ACCESS_KEY_ID": "x",
                 "AWS_SECRET_ACCESS_KEY": "x",
             }), \
             patch("boto3.client", return_value=mock_s3):
            bc.run_backup()

        self.assertTrue(captured_keys, "create_multipart_upload should have been called")
        key = captured_keys[0]
        pattern = r"backups/cortex-backup-\d{8}-\d{4}\.db\.gz$"
        self.assertRegex(key, pattern, f"Key '{key}' doesn't match expected pattern")


class TestListBackups(unittest.TestCase):
    """Tests for list_backups."""

    def test_returns_sorted_oldest_first(self):
        """list_backups should return objects sorted by LastModified, oldest first."""
        from backup_cortex import list_backups

        now = datetime.now(timezone.utc)
        objects = [
            {"Key": "backups/cortex-backup-newest.db.gz", "LastModified": now, "Size": 100},
            {"Key": "backups/cortex-backup-oldest.db.gz", "LastModified": now - timedelta(days=10), "Size": 100},
            {"Key": "backups/cortex-backup-middle.db.gz", "LastModified": now - timedelta(days=5), "Size": 100},
        ]

        mock_s3 = MagicMock()
        paginator = MagicMock()
        mock_s3.get_paginator.return_value = paginator
        paginator.paginate.return_value = [{"Contents": objects}]

        result = list_backups(mock_s3, "bucket", "backups/")

        self.assertEqual(result[0]["Key"], "backups/cortex-backup-oldest.db.gz")
        self.assertEqual(result[-1]["Key"], "backups/cortex-backup-newest.db.gz")

    def test_filters_non_db_gz_objects(self):
        """Only .db.gz objects should be returned."""
        from backup_cortex import list_backups

        now = datetime.now(timezone.utc)
        objects = [
            {"Key": "backups/cortex-backup-20240101-0000.db.gz", "LastModified": now, "Size": 100},
            {"Key": "backups/some-other-file.txt", "LastModified": now, "Size": 50},
            {"Key": "backups/manifest.json", "LastModified": now, "Size": 10},
        ]

        mock_s3 = MagicMock()
        paginator = MagicMock()
        mock_s3.get_paginator.return_value = paginator
        paginator.paginate.return_value = [{"Contents": objects}]

        result = list_backups(mock_s3, "bucket", "backups/")

        self.assertEqual(len(result), 1)
        self.assertTrue(result[0]["Key"].endswith(".db.gz"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
