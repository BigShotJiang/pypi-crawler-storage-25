"""Tests for LCMSource._should_skip runtime context filtering (#1310).

Verifies that OpenClaw runtime/system messages are filtered out during
batch ingest, preventing false-positive keyword matches (cornerstone,
dream, etc.) from leaking internal context into extraction.
"""

import pytest


class TestShouldSkipRuntimeContext:
    """Verify _should_skip filters OpenClaw runtime messages."""

    @pytest.fixture
    def source(self):
        """Create a minimal LCMSource for testing _should_skip."""
        from cortex.batch_ingest import LCMSource

        return LCMSource.__new__(LCMSource)

    @pytest.mark.parametrize("content", [
        "[Fri 2026-03-20 02:37 GMT+7] OpenClaw runtime context (internal):",
        '{"schema": "openclaw.inbound_meta.v1", "channel": "webchat"}',
        "Runtime-generated, not user-authored. Keep internal details private.",
        "Pre-compaction memory flush. Store durable memories only.",
        "HEARTBEAT_OK",
    ])
    def test_skips_runtime_messages(self, source, content):
        assert source._should_skip(content) is True

    @pytest.mark.parametrize("content", [
        "Andrew prefers PostgreSQL over MySQL",
        "I decided to deploy on Fly.io",
        "The cornerstone of our architecture is the memory engine",
        "Had a dream about building better AI systems",
    ])
    def test_keeps_real_content(self, source, content):
        assert source._should_skip(content) is False

    def test_keeps_subagent_references_skipped(self, source):
        assert source._should_skip("Subagent Context for R-042") is True

    def test_keeps_agent_refs_skipped(self, source):
        assert source._should_skip("[R-042] Audit complete") is True
