# Copyright (C) 2026   Jørgen Riseth (jnriseth@gmail.com)
# Copyright (C) 2026   Cécile Daversin-Catty (cecile@simula.no)
# Copyright (C) 2026   Simula Research Laboratory


from importlib.metadata import metadata

from . import (
    concentration,
    data,
    hybrid,
    looklocker,
    mixed,
    r1,
    segmentation,
    statistics,
    utils,
)
from .data import MRIData

meta = metadata("mritk")
__version__ = meta["Version"]
__author__ = meta["Author-email"]
__license__ = meta["license-expression"]
__email__ = meta["Author-email"]
__program_name__ = meta["Name"]


__all__ = [
    "data",
    "segmentation",
    "concentration",
    "utils",
    "looklocker",
    "mixed",
    "hybrid",
    "r1",
    "statistics",
    "MRIData",
]
