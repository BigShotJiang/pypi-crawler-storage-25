"""
CommandRegistry — the heart of PyKernel's customisation system.

Commands are callables registered with a name, aliases, help text, and
optional argument spec. The registry also loads user plugins from a directory.

Quick API
---------
    from pykernel.core.registry import CommandRegistry

    reg = CommandRegistry()

    @reg.command("greet", aliases=["hi"], help="Say hello", usage="/greet [name]")
    def cmd_greet(ctx, *args):
        name = args[0] if args else "world"
        ctx.print(ctx.paint.success(f"Hello, {name}!"))

    # or imperatively:
    reg.register("greet", cmd_greet, aliases=["hi"], help="Say hello")
"""

import importlib.util, pathlib, sys, traceback
from dataclasses import dataclass, field
from typing import Callable, Optional


# ── data model ───────────────────────────────────────────────────────────────

@dataclass
class Command:
    name:     str
    func:     Callable
    aliases:  list[str]         = field(default_factory=list)
    help:     str               = "(no description)"
    usage:    str               = ""
    category: str               = "General"
    hidden:   bool              = False

    def __post_init__(self):
        if not self.usage:
            self.usage = f"/{self.name}"

    def invoke(self, ctx, *args):
        return self.func(ctx, *args)


# ── registry ─────────────────────────────────────────────────────────────────

class CommandRegistry:
    """Holds all commands and resolves them by name or alias."""

    def __init__(self):
        self._commands: dict[str, Command] = {}   # canonical name → Command
        self._alias:    dict[str, str]     = {}   # alias → canonical name

    # ── registration ─────────────────────────────────────────────────────────

    def register(
        self,
        name:     str,
        func:     Callable,
        *,
        aliases:  list[str] = (),
        help:     str = "(no description)",
        usage:    str = "",
        category: str = "General",
        hidden:   bool = False,
    ) -> "Command":
        cmd = Command(
            name=name, func=func, aliases=list(aliases),
            help=help, usage=usage, category=category, hidden=hidden,
        )
        self._commands[name] = cmd
        for alias in aliases:
            self._alias[alias] = name
        return cmd

    def command(
        self,
        name: str,
        *,
        aliases:  list[str] = (),
        help:     str = "(no description)",
        usage:    str = "",
        category: str = "General",
        hidden:   bool = False,
    ):
        """Decorator factory — use on any function to register it as a command."""
        def decorator(func: Callable) -> Callable:
            self.register(
                name, func,
                aliases=aliases, help=help,
                usage=usage, category=category, hidden=hidden,
            )
            return func
        return decorator

    # ── lookup ───────────────────────────────────────────────────────────────

    def resolve(self, name: str) -> Optional[Command]:
        """Return Command for canonical name or alias, or None."""
        if name in self._commands:
            return self._commands[name]
        canonical = self._alias.get(name)
        if canonical:
            return self._commands.get(canonical)
        return None

    def all_commands(self, include_hidden: bool = False) -> list[Command]:
        cmds = list(self._commands.values())
        if not include_hidden:
            cmds = [c for c in cmds if not c.hidden]
        return sorted(cmds, key=lambda c: (c.category, c.name))

    def by_category(self, include_hidden: bool = False) -> dict[str, list[Command]]:
        out: dict[str, list[Command]] = {}
        for cmd in self.all_commands(include_hidden):
            out.setdefault(cmd.category, []).append(cmd)
        return out

    def names(self) -> list[str]:
        names = list(self._commands.keys()) + list(self._alias.keys())
        return sorted(names)

    # ── plugin loader ─────────────────────────────────────────────────────────

    def load_plugins(self, plugin_dir: pathlib.Path) -> list[str]:
        """
        Import every *.py file in plugin_dir.
        Each plugin must expose a top-level  register(registry)  function.
        Returns list of loaded plugin names.
        """
        loaded: list[str] = []
        if not plugin_dir.exists():
            return loaded

        for path in sorted(plugin_dir.glob("*.py")):
            mod_name = f"_pykernel_plugin_{path.stem}"
            try:
                spec   = importlib.util.spec_from_file_location(mod_name, path)
                module = importlib.util.module_from_spec(spec)          # type: ignore
                sys.modules[mod_name] = module
                spec.loader.exec_module(module)                          # type: ignore
                if hasattr(module, "register") and callable(module.register):
                    module.register(self)
                    loaded.append(path.stem)
                else:
                    print(
                        f"[plugin] {path.name} has no register(registry) — skipped",
                        file=sys.stderr,
                    )
            except Exception:
                print(f"[plugin] Failed to load {path.name}:", file=sys.stderr)
                traceback.print_exc(file=sys.stderr)

        return loaded

    def __len__(self):  return len(self._commands)
    def __contains__(self, name): return name in self._commands or name in self._alias
