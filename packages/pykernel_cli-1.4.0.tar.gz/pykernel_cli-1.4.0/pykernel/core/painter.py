"""
Painter — ANSI colour helpers, theme-aware.

Usage:
    from pykernel.core.painter import Painter
    p = Painter(theme="dark")
    print(p.info("hello"))
    print(p.error("oops"))
"""

import sys
from typing import Optional

ANSI = {
    "reset":   "\033[0m",
    "bold":    "\033[1m",
    "dim":     "\033[2m",
    "italic":  "\033[3m",
    "under":   "\033[4m",

    "black":   "\033[30m",
    "red":     "\033[91m",
    "green":   "\033[92m",
    "yellow":  "\033[93m",
    "blue":    "\033[94m",
    "magenta": "\033[95m",
    "cyan":    "\033[96m",
    "white":   "\033[97m",
    "gray":    "\033[90m",

    "bg_black":   "\033[40m",
    "bg_red":     "\033[41m",
    "bg_green":   "\033[42m",
    "bg_blue":    "\033[44m",
    "bg_cyan":    "\033[46m",
    "bg_magenta": "\033[45m",
}

_SUPPORTS_COLOR = sys.stdout.isatty()


def _c(*codes) -> str:
    if not _SUPPORTS_COLOR:
        return ""
    return "".join(ANSI.get(c, "") for c in codes)


def colorize(text: str, *codes) -> str:
    if not _SUPPORTS_COLOR:
        return text
    return f"{_c(*codes)}{text}{ANSI['reset']}"


class Painter:
    """Theme-aware text painter."""

    def __init__(self, theme: str = "dark", color_map: Optional[dict] = None):
        self.theme = theme
        self._map  = color_map or {}
        self.enabled = _SUPPORTS_COLOR and theme != "none"

    def _paint(self, text: str, *codes) -> str:
        if not self.enabled:
            return text
        return colorize(text, *codes)

    # ── semantic helpers ─────────────────────────────────────────────────────

    def prompt(self, text: str)   -> str: return self._paint(text, "cyan",    "bold")
    def error(self, text: str)    -> str: return self._paint(text, "red",     "bold")
    def info(self, text: str)     -> str: return self._paint(text, "green")
    def warning(self, text: str)  -> str: return self._paint(text, "yellow")
    def result(self, text: str)   -> str: return self._paint(text, "white")
    def dim(self, text: str)      -> str: return self._paint(text, "dim")
    def bold(self, text: str)     -> str: return self._paint(text, "bold")
    def code(self, text: str)     -> str: return self._paint(text, "magenta")
    def header(self, text: str)   -> str: return self._paint(text, "cyan",    "bold", "under")
    def success(self, text: str)  -> str: return self._paint(text, "green",   "bold")
    def accent(self, text: str)   -> str: return self._paint(text, "blue",    "bold")

    # ── table helper ─────────────────────────────────────────────────────────

    def table(self, rows: list[tuple], headers: Optional[list[str]] = None) -> str:
        if not rows:
            return self.dim("(empty)")

        all_rows = [tuple(str(c) for c in r) for r in rows]
        if headers:
            all_rows = [tuple(headers)] + all_rows

        col_w = [max(len(r[i]) for r in all_rows) for i in range(len(all_rows[0]))]
        sep   = "  ".join("─" * w for w in col_w)

        lines: list[str] = []
        for i, row in enumerate(all_rows):
            cells = "  ".join(cell.ljust(col_w[j]) for j, cell in enumerate(row))
            if headers and i == 0:
                lines.append(self.header(cells))
                lines.append(self.dim(sep))
            else:
                lines.append(cells)
        return "\n".join(lines)

    # ── banner ───────────────────────────────────────────────────────────────

    def banner(self, version: str = "1.4.0") -> str:
        logo = r"""
  ____        _  __                    _ 
 |  _ \ _   _| |/ /___ _ __ _ __   ___| |
 | |_) | | | | ' // _ \ '__| '_ \ / _ \ |
 |  __/| |_| | . \  __/ |  | | | |  __/ |
 |_|    \__, |_|\_\___|_|  |_| |_|\___|_|
         |___/                            """
        lines = [
            self._paint(logo, "cyan"),
            self.dim(f"  v{version}  ·  type /help to explore commands"),
            "",
        ]
        return "\n".join(lines)
