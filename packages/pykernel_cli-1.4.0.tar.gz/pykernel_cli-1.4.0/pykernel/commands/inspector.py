"""
Inspector commands — explore the live kernel namespace.

/vars             — list all variables in the namespace
/who    <name>    — print type + repr of a variable
/doc    <name>    — show docstring
/source <name>    — show source code (functions / classes)
/del    <name>    — delete a variable
/timeit <expr>    — time an expression
"""

import inspect, timeit as _timeit, textwrap
from pykernel.core.registry import CommandRegistry


def register(reg: CommandRegistry):

    # ── /vars ─────────────────────────────────────────────────────────────────

    @reg.command("vars", aliases=["ls", "env"],
                 help="List all variables in the kernel namespace",
                 usage="/vars",
                 category="Inspector")
    def cmd_vars(ctx, *args):
        p    = ctx.paint
        ns   = ctx.namespace_vars()
        if not ns:
            ctx.print(p.dim("  (namespace is empty)"))
            return
        rows = []
        for name, val in sorted(ns.items()):
            typ     = type(val).__name__
            snippet = repr(val)[:60].replace("\n", " ")
            rows.append((name, typ, snippet))
        ctx.print()
        ctx.print(p.table(rows, headers=["Name", "Type", "Value"]))
        ctx.print()

    # ── /who ──────────────────────────────────────────────────────────────────

    @reg.command("who",
                 help="Show detailed info about a variable",
                 usage="/who <name>",
                 category="Inspector")
    def cmd_who(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /who <name>"))
            return
        name = args[0]
        if not ctx.has_var(name):
            ctx.print(p.error(f"'{name}' is not defined in the namespace"))
            return
        val  = ctx.get_var(name)
        typ  = type(val)
        ctx.print()
        ctx.print(p.header(f"  {name}"))
        ctx.print(f"  type      : {p.code(typ.__module__ + '.' + typ.__name__)}")
        ctx.print(f"  repr      : {repr(val)[:120]}")
        if hasattr(val, "__len__"):
            try: ctx.print(f"  len       : {len(val)}")
            except: pass
        if hasattr(val, "shape"):
            ctx.print(f"  shape     : {val.shape}")
        if hasattr(val, "dtype"):
            ctx.print(f"  dtype     : {val.dtype}")
        ctx.print(f"  id        : {id(val)}")
        ctx.print()

    # ── /doc ──────────────────────────────────────────────────────────────────

    @reg.command("doc",
                 help="Show the docstring of a name",
                 usage="/doc <name>",
                 category="Inspector")
    def cmd_doc(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /doc <name>"))
            return
        name = args[0]
        # try namespace first, then builtins
        val = ctx.get_var(name, None) or __builtins__.__dict__.get(name) if isinstance(__builtins__, dict) else getattr(__builtins__, name, None)
        if val is None:
            try:
                import builtins
                val = getattr(builtins, name, None)
            except: pass
        if val is None:
            ctx.print(p.error(f"'{name}' not found"))
            return
        doc = inspect.getdoc(val) or "(no docstring)"
        ctx.print()
        ctx.print(p.header(f"  {name}"))
        ctx.print(textwrap.indent(doc, "  "))
        ctx.print()

    # ── /source ───────────────────────────────────────────────────────────────

    @reg.command("source", aliases=["src"],
                 help="Show source code of a function or class",
                 usage="/source <name>",
                 category="Inspector")
    def cmd_source(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /source <name>"))
            return
        name = args[0]
        val  = ctx.get_var(name)
        if val is None:
            ctx.print(p.error(f"'{name}' not in namespace"))
            return
        try:
            src = inspect.getsource(val)
            ctx.print()
            ctx.print(p.code(src))
            ctx.print()
        except (TypeError, OSError) as e:
            ctx.print(p.error(str(e)))

    # ── /del ──────────────────────────────────────────────────────────────────

    @reg.command("del", aliases=["delete", "rm"],
                 help="Delete a variable from the namespace",
                 usage="/del <name>",
                 category="Inspector")
    def cmd_del(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /del <name>"))
            return
        for name in args:
            if ctx.delete_var(name):
                ctx.print(p.success(f"  ✓  Deleted '{name}'"))
            else:
                ctx.print(p.warning(f"  ⚠  '{name}' not in namespace"))

    # ── /timeit ───────────────────────────────────────────────────────────────

    @reg.command("timeit",
                 help="Time an expression  (/timeit sum(range(1000000)))",
                 usage="/timeit <expression>  [repeat=N]",
                 category="Inspector")
    def cmd_timeit(ctx, *args):
        p = ctx.paint
        if not args:
            ctx.print(p.error("Usage: /timeit <expression>"))
            return
        # allow trailing repeat=N
        repeat = 3
        expr_parts = list(args)
        if expr_parts and expr_parts[-1].startswith("repeat="):
            try: repeat = int(expr_parts.pop()[7:])
            except: pass
        expr = " ".join(expr_parts)
        try:
            times  = _timeit.repeat(expr, globals=ctx.env, repeat=repeat, number=1000)
            best   = min(times) * 1_000_000 / 1000  # µs per loop
            ctx.print()
            ctx.print(p.info(f"  {best:.3f} µs ± per loop  (best of {repeat}×1000)"))
            ctx.print()
        except Exception as e:
            ctx.print(p.error(str(e)))
