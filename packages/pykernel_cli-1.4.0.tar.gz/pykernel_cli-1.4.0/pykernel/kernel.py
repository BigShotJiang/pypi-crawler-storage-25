#!/usr/bin/env python3
"""
PyKernel — A hackable Python REPL with first-class command support.
Run:  python kernel.py
"""

import sys, os

from pykernel.core.repl import REPL
from pykernel.core.registry import CommandRegistry
from pykernel.core.config import Config

# ── built-in command packs ──────────────────────────────────────────────────
from pykernel.commands.builtins  import register as register_builtins
from pykernel.commands.inspector import register as register_inspector
from pykernel.commands.shell     import register as register_shell
from pykernel.commands.snippets  import register as register_snippets


def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    import argparse
    parser = argparse.ArgumentParser(prog="pykernel")
    parser.add_argument("--ver", action="store_true", help="Show version")
    parser.add_argument("--dev", action="store_true", help="Show developer utils")
    args = parser.parse_args()

    if args.ver:
        print("pykernel-cli 1.4.1")
        return

    if args.dev:
        print("Plugin dev reference:")
        print("  register(registry)            — entry point for plugins")
        print("  registry.command(name, help=) — register a command")
        print("  ctx.print(msg)                — print to the REPL")
        print("  ctx.namespace                 — the user's live namespace")
        print("  Plugin dir:  ~/.pykernel/plugins/")
        print("  Snippet dir: ~/.pykernel/snippets/")
        return

    cfg      = Config()                     # loads ~/.pykernel/config.toml
    registry = CommandRegistry()

    # register built-in command packs
    register_builtins(registry)
    register_inspector(registry)
    register_shell(registry)
    register_snippets(registry)

    # load user plugins from ~/.pykernel/plugins/
    registry.load_plugins(cfg.plugin_dir)

    repl = REPL(registry, cfg)
    repl.run()


if __name__ == "__main__":
    main()
