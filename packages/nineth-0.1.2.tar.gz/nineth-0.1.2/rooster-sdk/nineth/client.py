"""Python client for the 1984 model API."""

from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator, Dict, Iterator, Optional

import httpx


DEFAULT_TIMEOUT = httpx.Timeout(300.0, connect=10.0)
DEFAULT_STREAM_TIMEOUT = httpx.Timeout(connect=10.0, read=None, write=60.0, pool=60.0)
DEFAULT_BASE_URL = "https://weirdpablo--rooster-api.modal.run"
API_KEY_HEADER = "X-API-Key"


class NinethAPIError(RuntimeError):
    """Raised when the Nineth API returns an unexpected response."""


def build_payload(
    task_input: str,
    *,
    model: Optional[str] = None,
    services: bool = True,
    service_names: Optional[list[str]] = None,
    cache: bool = True,
    max_iterations: int = 50,
    reasoning_effort: Optional[str] = None,
    show_reasoning: bool = False,
    process_id: Optional[str] = None,
    user_id: Optional[str] = None,
    debug: bool = False,
    continuous: bool = False,
    images: Optional[list[str]] = None,
    system_prompt: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "task_input": task_input,
        "model": model,
        "services": services,
        "service_names": service_names,
        "cache": cache,
        "max_iterations": max_iterations,
        "reasoning_effort": reasoning_effort,
        "show_reasoning": show_reasoning,
        "process_id": process_id,
        "user_id": user_id,
        "debug": debug,
        "continuous": continuous,
        "images": images,
        "system_prompt": system_prompt,
    }
    if extra:
        payload.update(extra)
    return {key: value for key, value in payload.items() if value is not None}


def _build_request_payload(
    task_input: str,
    request_kwargs: Dict[str, Any],
    *,
    default_model: Optional[str],
) -> Dict[str, Any]:
    prepared = dict(request_kwargs)
    if not prepared.get("model"):
        prepared["model"] = default_model
    if not prepared.get("model"):
        raise ValueError(
            "A model is required. Pass model=... or configure default_model / NINETH_MODEL."
        )
    return build_payload(task_input, **prepared)


def _raise_for_status(response: httpx.Response) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        message = response.text.strip() or str(exc)
        raise NinethAPIError(message) from exc


def _raise_for_stream_event(event: Dict[str, Any]) -> None:
    if event.get("type") != "error":
        return

    data = event.get("data", {})
    if isinstance(data, dict):
        message = data.get("message") or data.get("error") or "Streaming request failed."
    else:
        message = str(data) or "Streaming request failed."
    raise NinethAPIError(message)


def _coalesce_deltas(events: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
    """Buffer consecutive model_delta events into word-sized chunks."""
    buffer = ""
    for event in events:
        if event.get("type") == "model_delta":
            buffer += event.get("data", {}).get("text", "")
            if buffer and (buffer[-1] in " \n\t" or len(buffer) >= 80):
                yield {"type": "model_delta", "data": {"text": buffer}}
                buffer = ""
        else:
            if buffer:
                yield {"type": "model_delta", "data": {"text": buffer}}
                buffer = ""
            yield event
    if buffer:
        yield {"type": "model_delta", "data": {"text": buffer}}


def _parse_sse_lines(lines: Iterator[str]) -> Iterator[Dict[str, Any]]:
    event_type = "message"
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line.rstrip("\r")
        if not line:
            if data_lines:
                payload = json.loads("\n".join(data_lines))
                payload.setdefault("type", event_type)
                yield payload
            event_type = "message"
            data_lines = []
            continue

        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_type = line.split(":", 1)[1].strip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.split(":", 1)[1].strip())

    if data_lines:
        payload = json.loads("\n".join(data_lines))
        payload.setdefault("type", event_type)
        yield payload


class NinethClient:
    """Synchronous client for the Nineth API."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: httpx.Timeout | float | None = DEFAULT_TIMEOUT,
        stream_timeout: httpx.Timeout | float | None = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        if not resolved_base_url:
            raise ValueError("A base_url or NINETH_BASE_URL environment variable is required.")

        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")
        request_headers = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=request_headers or None,
        )

    def _ensure_api_key(self) -> None:
        if not self.api_key and API_KEY_HEADER not in self._client.headers:
            raise ValueError("An api_key or NINETH_API_KEY environment variable is required.")

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "NinethClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def health(self) -> Dict[str, Any]:
        response = self._client.get("/health")
        _raise_for_status(response)
        return response.json()

    def invoke(self, task_input: str, **kwargs: Any) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = _build_request_payload(
            task_input,
            kwargs,
            default_model=self.default_model,
        )
        response = self._client.post("/model", json=payload)
        _raise_for_status(response)
        return response.json()

    def stream(self, task_input: str, **kwargs: Any) -> Iterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = _build_request_payload(
            task_input,
            kwargs,
            default_model=self.default_model,
        )
        with self._client.stream(
            "POST",
            "/model/stream",
            json=payload,
            timeout=self._stream_timeout,
        ) as response:
            _raise_for_status(response)
            for event in _coalesce_deltas(_parse_sse_lines(response.iter_lines())):
                _raise_for_stream_event(event)
                yield event


class AsyncNinethClient:
    """Asynchronous client for the Nineth API."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: httpx.Timeout | float | None = DEFAULT_TIMEOUT,
        stream_timeout: httpx.Timeout | float | None = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        if not resolved_base_url:
            raise ValueError("A base_url or NINETH_BASE_URL environment variable is required.")

        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")
        request_headers = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers=request_headers or None,
        )

    def _ensure_api_key(self) -> None:
        if not self.api_key and API_KEY_HEADER not in self._client.headers:
            raise ValueError("An api_key or NINETH_API_KEY environment variable is required.")

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncNinethClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def health(self) -> Dict[str, Any]:
        response = await self._client.get("/health")
        _raise_for_status(response)
        return response.json()

    async def invoke(self, task_input: str, **kwargs: Any) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = _build_request_payload(
            task_input,
            kwargs,
            default_model=self.default_model,
        )
        response = await self._client.post("/model", json=payload)
        _raise_for_status(response)
        return response.json()

    async def stream(self, task_input: str, **kwargs: Any) -> AsyncIterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = _build_request_payload(
            task_input,
            kwargs,
            default_model=self.default_model,
        )
        async with self._client.stream(
            "POST",
            "/model/stream",
            json=payload,
            timeout=self._stream_timeout,
        ) as response:
            _raise_for_status(response)
            event_type = "message"
            data_lines: list[str] = []
            delta_buffer = ""

            async def _flush_delta():
                nonlocal delta_buffer
                if delta_buffer:
                    evt = {"type": "model_delta", "data": {"text": delta_buffer}}
                    delta_buffer = ""
                    return evt
                return None

            async for raw_line in response.aiter_lines():
                line = raw_line.rstrip("\r")
                if not line:
                    if data_lines:
                        parsed = json.loads("\n".join(data_lines))
                        parsed.setdefault("type", event_type)
                        _raise_for_stream_event(parsed)
                        if parsed.get("type") == "model_delta":
                            delta_buffer += parsed.get("data", {}).get("text", "")
                            if delta_buffer and (delta_buffer[-1] in " \n\t" or len(delta_buffer) >= 80):
                                yield {"type": "model_delta", "data": {"text": delta_buffer}}
                                delta_buffer = ""
                        else:
                            flushed = await _flush_delta()
                            if flushed:
                                yield flushed
                            yield parsed
                    event_type = "message"
                    data_lines = []
                    continue

                if line.startswith(":"):
                    continue
                if line.startswith("event:"):
                    event_type = line.split(":", 1)[1].strip()
                    continue
                if line.startswith("data:"):
                    data_lines.append(line.split(":", 1)[1].strip())

            if data_lines:
                parsed = json.loads("\n".join(data_lines))
                parsed.setdefault("type", event_type)
                _raise_for_stream_event(parsed)
                if parsed.get("type") == "model_delta":
                    delta_buffer += parsed.get("data", {}).get("text", "")
                else:
                    flushed = await _flush_delta()
                    if flushed:
                        yield flushed
                    yield parsed
            if delta_buffer:
                yield {"type": "model_delta", "data": {"text": delta_buffer}}
