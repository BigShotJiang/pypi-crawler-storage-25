from .client import AsyncNinethClient, NinethAPIError, NinethClient, build_payload

try:
    from importlib.metadata import PackageNotFoundError, version
except ImportError:
    from importlib_metadata import PackageNotFoundError, version

__all__ = [
    "AsyncNinethClient",
    "NinethAPIError",
    "NinethClient",
    "build_payload",
]

try:
    __version__ = version("nineth")
except PackageNotFoundError:
    __version__ = "0.0.0"
