//! # hash_password
//! Password hashing function.
//!
//! Provides utility to hash a password using bcrypt and store it to a file.

use bcrypt::{DEFAULT_COST, hash};
use pyo3::prelude::*;
use std::fs::OpenOptions;
use std::io::Write;
use std::path::PathBuf;

/// Hashes a password using bcrypt and appends it to a file.
///
/// # Arguments
/// * `password` - The password to hash.
/// * `file` - The path to the file to store the hash in.
#[pyfunction]
pub fn hash_password(password: &str, file: PathBuf) -> PyResult<()> {
    let hashed = hash(password, DEFAULT_COST)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

    let mut f = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&file)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    writeln!(f, "{}", hashed)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    Ok(())
}
