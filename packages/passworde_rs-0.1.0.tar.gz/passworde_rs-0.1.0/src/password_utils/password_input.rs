//! #  password_input
//! Password input utility functions.
//!
//! Provides utility to prompt the user for a password with optional masking
//! Also provides brute force protection to the password input.

use crossterm::event::{self, Event, KeyCode, KeyEvent};
use crossterm::terminal;
use pyo3::prelude::*;
use std::io::{self, Write};

/// The result of a password input, with brute force protection available.
#[pyclass]
pub struct PasswordInput {
    #[pyo3(get)]
    pub password: String,
    attempts: usize,
    max_attempts: usize,
}

#[pymethods]
impl PasswordInput {
    /// Protects against brute force by limiting attempts.
    ///
    /// # Arguments
    /// * `max_attempts` - The maximum number of allowed attempts.
    pub fn brute_force_protection(&mut self, max_attempts: usize) -> PyResult<String> {
        self.max_attempts = max_attempts;
        self.attempts += 1;

        if self.attempts > self.max_attempts {
            return Err(PyErr::new::<pyo3::exceptions::PyPermissionError, _>(
                format!(
                    "Too many attempts! Maximum of {} allowed.",
                    self.max_attempts
                ),
            ));
        }

        Ok(self.password.clone())
    }
}

/// Terminal input with a custom character mask.
///
/// # Arguments
/// * `prompt` - The prompt to display.
/// * `mask` - The character to use as a mask.
#[pyfunction]
pub fn password_input(prompt: &str, mask: Option<char>) -> PasswordInput {
    let mask = mask.unwrap_or('*');
    let mut password = String::new();
    print!("{}", prompt);
    io::stdout().flush().unwrap();
    terminal::enable_raw_mode().unwrap();

    loop {
        if let Event::Key(KeyEvent { code, .. }) = event::read().unwrap() {
            match code {
                KeyCode::Enter => break,
                KeyCode::Backspace => {
                    if !password.is_empty() {
                        password.pop();
                        print!("\x08 \x08");
                        io::stdout().flush().unwrap();
                    }
                }
                KeyCode::Char(c) => {
                    password.push(c);
                    print!("{}", mask);
                    io::stdout().flush().unwrap();
                }
                _ => {}
            }
        }
    }

    terminal::disable_raw_mode().unwrap();
    println!();

    PasswordInput {
        password,
        attempts: 0,
        max_attempts: 3,
    }
}
