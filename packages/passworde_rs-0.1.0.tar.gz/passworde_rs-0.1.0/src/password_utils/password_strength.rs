//! # password_strength
//! Password strength utility functions.
//!
//! Provides utility to calculate the strength of a password.

use pyo3::prelude::*;

/// Calculates the strength of the password.
///
/// Returns "Weak", "Normal", "Strong", "Very Strong".
#[pyfunction]
pub fn password_strength(password: &str) -> &'static str {
    let mut score: f32 = 0.0;

    for c in password.chars() {
        if c.is_uppercase() || c.is_lowercase() {
            score += 1.0;
        } else if c.is_ascii_digit() {
            score += 1.5;
        } else {
            score += 2.0;
        }
    }

    match score as u32 {
        0..=8 => "Weak",
        9..=14 => "Normal",
        15..=20 => "Strong",
        _ => "Very Strong",
    }
}
