//! # find_password
//! Password lookup and verification function.
//!
//! Provides utility to find and verify a password against bcrypt hashes.

use bcrypt::verify;
use pyo3::prelude::*;
use std::fs;
use std::path::PathBuf;

/// Finds and verifies a password against hashes stored in a file.
///
/// # Arguments
/// * `password` - The password to verify.
/// * `file` - The path to the file containing the hashes.
#[pyfunction]
pub fn find_password(password: &str, file: PathBuf) -> PyResult<bool> {
    let contents = fs::read_to_string(&file)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    for hash in contents.lines() {
        if !hash.is_empty() {
            let matches = verify(password, hash)
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            if matches {
                return Ok(true);
            }
        }
    }

    Ok(false)
}
