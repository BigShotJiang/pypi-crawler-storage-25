//! # Password Utilities
//!
//! This module provides utility functions for password management,
//! including hashing, verification, strength checking, and secure input.
//!
//! ## Example
//! ```python
//! import passworders
//!
//! # Secure password input with custom mask
//! result = passworders.password_input("Enter password: ", "*")
//! password = result.brute_force_protection(3)
//!
//! # Check password strength
//! passworders.password_strength("myPassword123!")  # "Strong"
//!
//! # Hash and store a password
//! passworders.hash_password("mypassword", "hashes.txt")
//!
//! # Verify a password against stored hashes
//! passworders.find_password("mypassword", "hashes.txt")  # True
//! ```

use pyo3::prelude::*;

pub mod find_password;
pub mod hash_password;
pub mod password_input;
pub mod password_strength;

/// Registers all password utility functions with the Python module.
///
/// Exposes the following functions directly on `passworders`:
/// - `password_input` — Secure terminal input with optional character mask.
/// - `password_strength` — Rates password strength as Weak, Normal, Strong, or Very Strong.
/// - `hash_password` — Hashes a password with bcrypt and appends it to a file.
/// - `find_password` — Verifies a password against bcrypt hashes stored in a file.
pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(password_input::password_input, m)?)?;
    m.add_function(wrap_pyfunction!(password_strength::password_strength, m)?)?;
    m.add_function(wrap_pyfunction!(hash_password::hash_password, m)?)?;
    m.add_function(wrap_pyfunction!(find_password::find_password, m)?)?;
    Ok(())
}
