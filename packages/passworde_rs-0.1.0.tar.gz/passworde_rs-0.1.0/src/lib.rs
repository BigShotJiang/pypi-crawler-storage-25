//! The entry point for the `PasswordeRs` Python module.
//!
//! Handles module initialization and exposes password generation
//! and utility functions to Python.
use pyo3::prelude::*;
mod globals;
mod password_utils;
mod random_password;

/// Returns a string indicating that the module is working.
#[pyfunction]
fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// Initializes the `passworders` Python module.
///
/// Registers all password generation and utility functions.
#[pymodule]
fn passworders(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(version, m)?)?;
    m.add_class::<random_password::Random>()?;
    m.add_class::<password_utils::password_input::PasswordInput>()?;
    password_utils::register(m)?;
    Ok(())
}
