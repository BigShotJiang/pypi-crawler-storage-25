//! # Globals
//!
//! Defines global character set constants used across the project
//! for password generation and strength checking.

/// Lowercase ASCII letters.
pub const LOWER_CHARS: &str = "abcdefghijklmnopqrstuvwxyz";

/// Lowercase nordic letters (å, ä, ö).
pub const LOWER_CHARS_NORDIC: &str = "åäö";

/// Uppercase ASCII letters.
pub const UPPER_CHARS: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/// Uppercase nordic letters (Å, Ä, Ö).
pub const UPPER_CHARS_NORDIC: &str = "ÅÄÖ";

/// Uppercase vowels.
pub const UPPER_VOWELS: &str = "AEIOU";

/// Uppercase consonants.
pub const UPPER_CONSONANTS: &str = "BCDFGHJKLMNPQRSTVWXYZ";

/// Lowercase vowels.
pub const LOWER_VOWELS: &str = "aeiou";

/// Lowercase consonants.
pub const LOWER_CONSONANTS: &str = "bcdfghjklmnpqrstvwxyz";

/// Numeric digits.
pub const DIGITS: &str = "0123456789";

/// Common keyboard symbols.
pub const SYMBOLS: &str = "!@#$%^&*()-_=+[]{}|;:,.<>?/~`'\"\\";
