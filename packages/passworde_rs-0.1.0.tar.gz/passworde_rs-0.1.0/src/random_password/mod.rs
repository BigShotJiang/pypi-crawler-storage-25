//! # Random Password Module
//!
//! This module provides functions to generate random passwords.
//! All functions are accessible via `passworders.Random.<function>()`.
//!
//! ## Example
//! ```python
//! import passworders
//! passworders.Random.password(16, False)
//! passworders.Random.string_password(12, True)  # includes nordic characters
//! passworders.Random.number_password(8)
//! ```

pub mod custom_password;
pub mod number_password;
pub mod password;
pub mod pronounceable_password;
pub mod string_password;

use pyo3::prelude::*;

/// Exposes random password generation functions to Python
/// via the `passworders.Random` class.
#[pyclass]
pub struct Random;

#[pymethods]
impl Random {
    /// Generates a random password including letters, numbers and symbols.
    ///
    /// # Arguments
    /// * `length` - The length of the password.
    /// * `nordic` - Whether to include nordic characters (å, ä, ö, Å, Ä, Ö).
    #[staticmethod]
    pub fn password(length: usize, nordic: bool) -> String {
        password::password(length, nordic)
    }

    /// Generates a random pronounceable password using a CVCV pattern.
    ///
    /// # Arguments
    /// * `length` - The length of the password.
    /// * `nordic` - Whether to include nordic vowels (å, ä, ö, Å, Ä, Ö).
    #[staticmethod]
    pub fn pronounceable_password(length: usize, nordic: bool) -> String {
        pronounceable_password::pronounceable_password(length, nordic)
    }

    /// Generates a random password from a custom character set.
    ///
    /// # Arguments
    /// * `length` - The length of the password.
    /// * `charset` - The character set to use.
    #[staticmethod]
    pub fn custom_password(length: usize, charset: String) -> String {
        custom_password::custom_password(length, charset)
    }

    /// Generates a random password including only letters.
    ///
    /// # Arguments
    /// * `length` - The length of the password.
    /// * `nordic` - Whether to include nordic characters (å, ä, ö, Å, Ä, Ö).
    #[staticmethod]
    pub fn string_password(length: usize, nordic: bool) -> String {
        string_password::string_password(length, nordic)
    }

    /// Generates a random password including only numbers.
    ///
    /// # Arguments
    /// * `length` - The length of the password.
    #[staticmethod]
    pub fn number_password(length: usize) -> String {
        number_password::number_password(length)
    }
}
