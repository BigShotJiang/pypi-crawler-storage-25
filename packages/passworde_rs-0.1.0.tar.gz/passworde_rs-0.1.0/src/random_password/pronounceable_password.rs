//! # pronounceable_password
//!
//! Generates a random pronounceable password using CVCV pattern.

use crate::globals::*;
use rand::Rng;

/// Generates a random pronounceable password using CVCV pattern.
pub fn pronounceable_password(length: usize, nordic: bool) -> String {
    let mut vowels = format!("{}{}", LOWER_VOWELS, UPPER_VOWELS);
    let consonants = format!("{}{}", LOWER_CONSONANTS, UPPER_CONSONANTS);

    if nordic {
        vowels.push_str("åäöÅÄÖ");
    }

    let vowels: Vec<char> = vowels.chars().collect();
    let consonants: Vec<char> = consonants.chars().collect();
    let mut rng = rand::thread_rng();
    let mut password = String::new();

    for i in 0..length {
        if i % 2 == 0 {
            password.push(consonants[rng.gen_range(0..consonants.len())]);
        } else {
            password.push(vowels[rng.gen_range(0..vowels.len())]);
        }
    }

    password
}
