//! # custom_password
//!
//! Generates a random password from a custom character set.
use rand::Rng;

/// Generates a random password from a custom character set.
pub fn custom_password(length: usize, charset: String) -> String {
    if charset.is_empty() {
        return String::from("Error: charset cannot be empty");
    }
    let chars: Vec<char> = charset.chars().collect();
    let mut rng = rand::thread_rng();
    (0..length)
        .map(|_| chars[rng.gen_range(0..chars.len())])
        .collect()
}
