//! # number_password
//!
//! Generates a random password including only numbers.
//!
use crate::globals::*;
use rand::Rng;

/// Generates a random password including only numbers.
pub fn number_password(length: usize) -> String {
    let charset: Vec<char> = DIGITS.chars().collect();
    let mut rng = rand::thread_rng();
    (0..length)
        .map(|_| charset[rng.gen_range(0..charset.len())])
        .collect()
}
