//! # string_password
//!
//! Generates a random password including only letters.

use crate::globals::*;
use rand::Rng;

/// Generates a random password including only letters.
pub fn string_password(length: usize, nordic: bool) -> String {
    let mut charset = format!("{}{}", LOWER_CHARS, UPPER_CHARS);
    if nordic {
        charset.push_str(LOWER_CHARS_NORDIC);
        charset.push_str(UPPER_CHARS_NORDIC);
    }
    let chars: Vec<char> = charset.chars().collect();
    let mut rng = rand::thread_rng();
    (0..length)
        .map(|_| chars[rng.gen_range(0..chars.len())])
        .collect()
}
