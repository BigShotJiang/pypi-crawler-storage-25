# PasswordeRs

![Language](https://img.shields.io/badge/lang-Rust-orange)
![License](https://img.shields.io/badge/license-MIT-blue)
![Python](https://img.shields.io/badge/python-3.8+-yellow)

A Python module for password related utilities written in Rust. PasswordeRs provides **password generation** with arguments, **password strength checking**, **password hashing** and a lot more.
--

# Features
- **Random passwords**
  - `string_password` -- Generates a random password including only strings.
  - `number_password` -- Generates a random password including only numbers.
  - `password` -- Generates a random password that includes any character.
  - `pronounceable_password` -- Generates a random password that is pronounceable (C V C V).
  - `custom_password` -- Generates a random password from a custom characer set.
- **Password Utilities**
  - `password_strength` -- Checks the strength of a password.
  - `password_input` -- Terminal input with a custom character mask
  - `hash_password` -- Hashes a password using bcrypt and saves to given file.
  - `find_password` -- Finds a hashed password from the given file.
  - `brute_force_protection` -- Protects password input from multiple wrong guesses.

License: [MIT](LICENSE.md)
