"""Coordinator for the aiometric_hass integration.

This module implements a Home Assistant DataUpdateCoordinator that manages
the connection to a LaMetric device and periodically fetches the device
state. It translates library-specific errors into Home Assistant exceptions
so the config entry state is handled correctly (e.g. authentication
failures raise `ConfigEntryAuthFailed`).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiometric import (
    DeviceState,
    LaMetricAuthenticationError,
    LaMetricDevice,
    LaMetricError,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_API_KEY, CONF_HOST
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import DOMAIN, LOGGER, UPDATE_INTERVAL

if TYPE_CHECKING:
    from homeassistant.core import HomeAssistant


type LaMetricConfigEntry = ConfigEntry[LaMetricDataUpdateCoordinator]


class LaMetricDataUpdateCoordinator(DataUpdateCoordinator[DeviceState]):
    """DataUpdateCoordinator that provides `DeviceState` for a LaMetric device.

    The coordinator holds a `LaMetricDevice` client instance and is
    responsible for performing periodic updates via the device client's
    `get_device_state` coroutine.
    """

    config_entry: LaMetricConfigEntry

    def __init__(self, hass: HomeAssistant, entry: LaMetricConfigEntry) -> None:
        """Initialize the coordinator and LaMetric client.

        Args:
            hass: HomeAssistant instance.
            entry: Config entry containing host and API key used to build the
                `LaMetricDevice` client. The created coordinator is associated
                with this config entry.

        """
        self.lametric = LaMetricDevice(
            host=entry.data[CONF_HOST],
            api_key=entry.data[CONF_API_KEY],
            session=async_get_clientsession(hass),
        )

        super().__init__(
            hass,
            LOGGER,
            config_entry=entry,
            name=DOMAIN,
            update_interval=UPDATE_INTERVAL,
        )

    async def _async_update_data(self) -> DeviceState:
        """Fetch updated device state from the LaMetric device.

        Returns:
            The latest `DeviceState` returned by the LaMetric client.

        Raises:
            ConfigEntryAuthFailed: when the underlying library reports an
                authentication error (triggers reauthentication flow).
            UpdateFailed: for other errors encountered while fetching data.

        """
        try:
            return await self.lametric.get_device_state()

        except LaMetricAuthenticationError as error:
            # Authentication problems should trigger HA's re-auth flow.
            raise ConfigEntryAuthFailed from error

        except LaMetricError as error:
            # Log a more informative error message and include the host and
            # underlying exception message to help debugging without exposing
            # sensitive data (API key is not logged).
            LOGGER.error(
                "Failed to update LaMetric device at %s: %s",
                getattr(self.lametric, "host", "unknown"),
                error,
            )
            host = getattr(self.lametric, "host", "unknown")
            msg = f"Failed to fetch state from LaMetric device at {host}: {error}"
            raise UpdateFailed(msg) from error
