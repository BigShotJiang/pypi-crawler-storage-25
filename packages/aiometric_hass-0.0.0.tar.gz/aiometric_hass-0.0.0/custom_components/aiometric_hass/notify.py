"""Notification service for the aiometric_hass integration.

This module exposes a Home Assistant notify service that forwards messages
to a LaMetric device using the aiometric library. It validates optional
notification parameters (sound, icon type, priority, cycles) and maps them
to the library's notification model before sending.

Errors from the aiometric library are translated into Home Assistant
exceptions with clear, host-aware messages while avoiding logging here
(per project preference).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiometric import (
    AlarmSound,
    BuiltinSound,
    IconType,
    LaMetricDevice,
    LaMetricError,
    Notification,
    NotificationModel,
    NotificationPriority,
    NotificationSound,
    SimpleFrame,
)
from homeassistant.components.notify.const import ATTR_DATA
from homeassistant.components.notify.legacy import BaseNotificationService
from homeassistant.const import CONF_ICON
from homeassistant.exceptions import HomeAssistantError, ServiceValidationError
from homeassistant.util.enum import try_parse_enum

from .const import CONF_CYCLES, CONF_ICON_TYPE, CONF_PRIORITY, CONF_SOUND

if TYPE_CHECKING:
    from homeassistant.core import HomeAssistant
    from homeassistant.helpers.typing import ConfigType, DiscoveryInfoType

    from .coordinator import LaMetricConfigEntry


async def async_get_service(
    hass: HomeAssistant,
    config: ConfigType,
    discovery_info: DiscoveryInfoType | None = None,
) -> LaMetricNotificationService | None:
    """Return a LaMetric notification service for a config entry.

    Args:
        hass: Home Assistant instance.
        config: Integration config (unused).
        discovery_info: Discovery info including the config entry id.

    Returns:
        LaMetricNotificationService if discovery_info and the entry exist,
        otherwise None.

    """
    if discovery_info is None:
        return None

    entry: LaMetricConfigEntry | None = hass.config_entries.async_get_entry(
        discovery_info["entry_id"]
    )
    if entry is None:
        return None

    return LaMetricNotificationService(entry.runtime_data.lametric)


class LaMetricNotificationService(BaseNotificationService):
    """Notification service implementation that sends to a LaMetric device."""

    def __init__(self, lametric: LaMetricDevice) -> None:
        """Initialize the service with a LaMetric client instance."""
        self.lametric = lametric

    async def async_send_message(self, message: str = "", **kwargs: Any) -> None:
        """Send a notification message to the LaMetric device.

        Accepts optional data via kwargs[ATTR_DATA]. Supported keys:
        - CONF_ICON_TYPE: icon type value for the notification
        - CONF_PRIORITY: notification priority
        - CONF_CYCLES: number of cycles to display the notification
        - CONF_SOUND: builtin sound identifier (AlarmSound or NotificationSound)
        - CONF_ICON: icon id to display (falls back to default)

        Raises:
            ServiceValidationError: if provided sound is invalid.
            HomeAssistantError: if the aiometric library fails to send the notification.

        """
        data: dict[str, Any] = kwargs.get(ATTR_DATA) or {}

        sound = None
        if CONF_SOUND in data:
            snd: AlarmSound | NotificationSound | None
            provided = data[CONF_SOUND]
            if (snd := try_parse_enum(AlarmSound, provided)) is None and (
                snd := try_parse_enum(NotificationSound, provided)
            ) is None:
                msg = f"Unknown sound provided: {provided!r}"
                raise ServiceValidationError(msg)
            sound = BuiltinSound(category=None, id=snd)

        notification = Notification(
            icon_type=IconType(data.get(CONF_ICON_TYPE, "none")),
            priority=NotificationPriority(data.get(CONF_PRIORITY, "info")),
            model=NotificationModel(
                frames=[
                    SimpleFrame(
                        icon=data.get(CONF_ICON, "a7956"),
                        text=message,
                    )
                ],
                cycles=int(data.get(CONF_CYCLES, 1)),
                sound=sound,
            ),
        )

        host = getattr(self.lametric, "host", "unknown")
        try:
            await self.lametric.notify(notification=notification)
        except LaMetricError as error:
            msg = (
                f"Failed to send notification to LaMetric device at {host}. "
                "Check device connectivity and credentials."
            )
            raise HomeAssistantError(msg) from error
