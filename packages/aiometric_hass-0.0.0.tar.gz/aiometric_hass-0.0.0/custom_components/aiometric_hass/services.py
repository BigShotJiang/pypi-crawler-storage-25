"""Service handlers for the aiometric_hass integration.

This module registers services that allow sending notifications, starting
and stopping LED streams, and sending raw frames to LaMetric devices.

Services:
- SERVICE_SHOW_CHART: display a chart frame
- SERVICE_SHOW_MESSAGE: display a text/icon message
- SERVICE_START_STREAM: start a streaming session
- SERVICE_SEND_FRAME: send a streaming frame
- SERVICE_STOP_STREAM: stop the streaming session

Errors from the aiometric library are logged with device host information
and translated into Home Assistant friendly exceptions without leaking
sensitive data (for example API keys).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

import voluptuous as vol
from aiometric import (
    AlarmSound,
    BuiltinSound,
    CanvasFillType,
    CanvasRenderMode,
    GoalFrame,
    IconType,
    LaMetricError,
    Notification,
    NotificationModel,
    NotificationPriority,
    NotificationSound,
    PostProcessing,
    SimpleFrame,
    SpikeChartFrame,
    StreamState,
)
from homeassistant.const import CONF_DEVICE_ID, CONF_ICON
from homeassistant.core import (
    HomeAssistant,
    ServiceCall,
    ServiceResponse,
    SupportsResponse,
    callback,
)
from homeassistant.exceptions import HomeAssistantError, ServiceValidationError
from homeassistant.helpers import config_validation as cv
from homeassistant.util.enum import try_parse_enum

from .const import (
    CONF_CYCLES,
    CONF_DATA,
    CONF_FILL_TYPE,
    CONF_ICON_TYPE,
    CONF_MESSAGE,
    CONF_POST_PROCESS,
    CONF_PRIORITY,
    CONF_RENDER_MODE,
    CONF_SOUND,
    CONF_STREAM_HEIGHT,
    CONF_STREAM_RGB_DATA,
    CONF_STREAM_STATE,
    CONF_STREAM_WIDTH,
    CONF_STREAM_X,
    CONF_STREAM_Y,
    DOMAIN,
    SERVICE_SEND_FRAME,
    SERVICE_SHOW_CHART,
    SERVICE_SHOW_MESSAGE,
    SERVICE_START_STREAM,
    SERVICE_STOP_STREAM,
)
from .helpers import async_get_coordinator_by_device_id

if TYPE_CHECKING:
    from .coordinator import LaMetricDataUpdateCoordinator


SERVICE_BASE_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): cv.string,
        vol.Optional(CONF_CYCLES, default=1): cv.positive_int,
        vol.Optional(CONF_ICON_TYPE, default=IconType.NONE): vol.Coerce(IconType),
        vol.Optional(CONF_PRIORITY, default=NotificationPriority.INFO): vol.Coerce(
            NotificationPriority
        ),
        vol.Optional(CONF_SOUND): vol.Any(
            vol.Coerce(AlarmSound), vol.Coerce(NotificationSound)
        ),
    }
)

SERVICE_SHOW_MESSAGE_SCHEMA = SERVICE_BASE_SCHEMA.extend(
    {
        vol.Required(CONF_MESSAGE): cv.string,
        vol.Optional(CONF_ICON): cv.string,
    }
)

SERVICE_SHOW_CHART_SCHEMA = SERVICE_BASE_SCHEMA.extend(
    {
        vol.Required(CONF_DATA): vol.All(cv.ensure_list, [vol.Coerce(int)]),
    }
)

SERVICE_START_STREAM_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): cv.string,
        vol.Required(CONF_FILL_TYPE): vol.Coerce(CanvasFillType),
        vol.Required(CONF_RENDER_MODE): vol.Coerce(CanvasRenderMode),
        vol.Required(CONF_POST_PROCESS): vol.Coerce(PostProcessing),
    }
)

SERVICE_SEND_FRAME_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): cv.string,
        vol.Required(CONF_STREAM_STATE): vol.Coerce(StreamState),
        vol.Required(CONF_STREAM_RGB_DATA): vol.Coerce(bytes),
        vol.Optional(CONF_STREAM_X): cv.positive_int,
        vol.Optional(CONF_STREAM_Y): cv.positive_int,
        vol.Optional(CONF_STREAM_WIDTH): cv.positive_int,
        vol.Optional(CONF_STREAM_HEIGHT): cv.positive_int,
    }
)


SERVICE_STOP_STREAM_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_DEVICE_ID): cv.string,
    }
)


@callback
def async_setup_services(hass: HomeAssistant) -> None:
    """Register integration services on the Home Assistant instance."""

    async def _async_service_chart(call: ServiceCall) -> None:
        coordinator = async_get_coordinator_by_device_id(
            hass, call.data[CONF_DEVICE_ID]
        )

        await async_send_notification(
            coordinator, call, [SpikeChartFrame(chart_data=call.data[CONF_DATA])]
        )

    async def _async_service_message(call: ServiceCall) -> None:
        coordinator = async_get_coordinator_by_device_id(
            hass, call.data[CONF_DEVICE_ID]
        )

        await async_send_notification(
            coordinator,
            call,
            [
                SimpleFrame(
                    icon=call.data.get(CONF_ICON),
                    text=call.data[CONF_MESSAGE],
                )
            ],
        )

    async def _async_service_start_stream(call: ServiceCall) -> ServiceResponse:
        """Start a streaming session on the device and return the initial state.

        Returns a JSON-serializable representation of the stream state on
        success. Converts aiometric errors into Home Assistant errors and logs
        the underlying issue for diagnostics.
        """
        coordinator = async_get_coordinator_by_device_id(
            hass, call.data[CONF_DEVICE_ID]
        )
        host = getattr(getattr(coordinator, "lametric", None), "host", "unknown")
        try:
            state = await coordinator.lametric.start_stream(
                fill_type=call.data[CONF_FILL_TYPE],
                render_mode=call.data[CONF_RENDER_MODE],
                post_process=call.data[CONF_POST_PROCESS],
            )

            return cast("ServiceResponse", state.to_json())
        except LaMetricError as error:
            msg = (
                f"Failed to start stream on LaMetric device at {host}. "
                "Check device state and parameters."
            )
            raise HomeAssistantError(msg) from error

    async def _async_service_send_frame(call: ServiceCall) -> None:
        """Send a single streaming frame to the device."""
        coordinator = async_get_coordinator_by_device_id(
            hass, call.data[CONF_DEVICE_ID]
        )
        host = getattr(getattr(coordinator, "lametric", None), "host", "unknown")

        try:
            await coordinator.lametric.send_stream_frame(
                state=call.data[CONF_STREAM_STATE],
                rgb888_data=call.data[CONF_STREAM_RGB_DATA],
                x=call.data.get(CONF_STREAM_X),
                y=call.data.get(CONF_STREAM_Y),
                width=call.data.get(CONF_STREAM_WIDTH),
                height=call.data.get(CONF_STREAM_HEIGHT),
            )
        except LaMetricError as error:
            msg = f"Failed to send stream frame to LaMetric device at {host}."
            raise HomeAssistantError(msg) from error

    async def _async_service_stop_stream(call: ServiceCall) -> None:
        """Stop an active streaming session on the device."""
        coordinator = async_get_coordinator_by_device_id(
            hass, call.data[CONF_DEVICE_ID]
        )
        host = getattr(getattr(coordinator, "lametric", None), "host", "unknown")

        try:
            await coordinator.lametric.stop_stream()
        except LaMetricError as error:
            msg = f"Failed to stop stream on LaMetric device at {host}."
            raise HomeAssistantError(msg) from error

    hass.services.async_register(
        DOMAIN,
        SERVICE_SHOW_CHART,
        _async_service_chart,
        schema=SERVICE_SHOW_CHART_SCHEMA,
    )

    hass.services.async_register(
        DOMAIN,
        SERVICE_SHOW_MESSAGE,
        _async_service_message,
        schema=SERVICE_SHOW_MESSAGE_SCHEMA,
        description_placeholders={"icons_url": "https://developer.lametric.com/icons"},
    )

    hass.services.async_register(
        DOMAIN,
        SERVICE_START_STREAM,
        _async_service_start_stream,
        schema=SERVICE_START_STREAM_SCHEMA,
        supports_response=SupportsResponse.ONLY,
    )

    hass.services.async_register(
        DOMAIN,
        SERVICE_SEND_FRAME,
        _async_service_send_frame,
        schema=SERVICE_SEND_FRAME_SCHEMA,
    )

    hass.services.async_register(
        DOMAIN,
        SERVICE_STOP_STREAM,
        _async_service_stop_stream,
        schema=SERVICE_STOP_STREAM_SCHEMA,
    )


async def async_send_notification(
    coordinator: LaMetricDataUpdateCoordinator,
    call: ServiceCall,
    frames: list[SpikeChartFrame | GoalFrame | SimpleFrame],
) -> None:
    """Build and send a Notification to the LaMetric device.

    Validates and converts optional sound identifiers, constructs the
    Notification model and forwards it to the device. Errors are logged
    with host context and translated to Home Assistant errors.
    """
    sound = None

    if CONF_SOUND in call.data:
        sound_id: AlarmSound | NotificationSound | None

        if (sound_id := try_parse_enum(AlarmSound, call.data[CONF_SOUND])) is None and (
            sound_id := try_parse_enum(NotificationSound, call.data[CONF_SOUND])
        ) is None:
            msg = f"Unknown sound provided: {call.data[CONF_SOUND]!r}"
            raise ServiceValidationError(msg)

        sound = BuiltinSound(category=None, id=sound_id)

    notification = Notification(
        icon_type=IconType(call.data[CONF_ICON_TYPE]),
        priority=NotificationPriority(call.data.get(CONF_PRIORITY)),
        model=NotificationModel(
            frames=frames,
            cycles=call.data[CONF_CYCLES],
            sound=sound,
        ),
    )

    host = getattr(getattr(coordinator, "lametric", None), "host", "unknown")
    try:
        await coordinator.lametric.notify(notification=notification)
    except LaMetricError as error:
        msg = f"Failed to send notification to LaMetric device at {host}."
        raise HomeAssistantError(msg) from error
