"""Switch platform for the aiometric_hass integration.

This module exposes Home Assistant switch entities for features exposed by
LaMetric devices (for example Bluetooth and display state). Each switch is
described by a `LaMetricSwitchEntityDescription` which provides predicates
to determine availability/presence, the current state, and an async setter
to apply changes to the `LaMetricDevice`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from aiometric import DeviceModel, DeviceState, LaMetricDevice
from homeassistant.components.switch import SwitchEntity, SwitchEntityDescription
from homeassistant.const import EntityCategory

from .entity import LaMetricEntity
from .helpers import lametric_exception_handler

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from homeassistant.core import HomeAssistant
    from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

    from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator


@dataclass(frozen=True, kw_only=True)
class LaMetricSwitchEntityDescription(SwitchEntityDescription):
    """Describe a LaMetric switch entity.

    Attributes:
        available_fn: Callable that returns whether the feature is currently available.
        has_fn: Callable that indicates whether the device supports this feature.
        is_on_fn: Callable that returns the current on/off state from DeviceState.
        set_fn: Async callable that sets the feature state on the LaMetricDevice.

    """

    available_fn: Callable[[DeviceState], bool]
    has_fn: Callable[[DeviceState], bool]
    is_on_fn: Callable[[DeviceState], bool]
    set_fn: Callable[[LaMetricDevice, bool], Awaitable[Any]]


SWITCHES = [
    LaMetricSwitchEntityDescription(
        key="bluetooth",
        translation_key="bluetooth",
        entity_category=EntityCategory.CONFIG,
        available_fn=lambda state: bool(state.bluetooth and state.bluetooth.available),
        has_fn=lambda state: bool(state.bluetooth),
        is_on_fn=lambda state: bool(state.bluetooth and state.bluetooth.active),
        set_fn=lambda device, active: device.get_or_set_bluetooth_state(active=active),
    ),
    LaMetricSwitchEntityDescription(
        key="display",
        translation_key="display",
        entity_category=EntityCategory.CONFIG,
        available_fn=lambda _state: True,
        has_fn=lambda _state: True,
        is_on_fn=lambda state: state.display.on,
        set_fn=lambda device, on: device.get_or_set_display_state(on=on),
    ),
]


async def async_setup_entry(
    _hass: HomeAssistant,
    entry: LaMetricConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up switch entities for a config entry.

    The coordinator is obtained from the config entry's runtime data. Switch
    entities are not created for the SKY device model. For other models a
    `LaMetricSwitchEntity` is created for each description in `SWITCHES`
    where the device reports the feature is present (`has_fn`).
    """
    coordinator = entry.runtime_data

    if coordinator.data.model == DeviceModel.SKY:
        return

    async_add_entities(
        LaMetricSwitchEntity(
            coordinator=coordinator,
            description=description,
        )
        for description in SWITCHES
        if description.has_fn(coordinator.data)
    )


class LaMetricSwitchEntity(LaMetricEntity, SwitchEntity):
    """Representation of a LaMetric switch entity.

    The entity uses the description callbacks to determine availability,
    presence, and current state. State changes are executed against the
    `LaMetricDevice` client and the coordinator is refreshed afterwards.
    All remote calls are wrapped with `lametric_exception_handler` to
    centralize error handling and logging.
    """

    entity_description: LaMetricSwitchEntityDescription

    def __init__(
        self,
        coordinator: LaMetricDataUpdateCoordinator,
        description: LaMetricSwitchEntityDescription,
    ) -> None:
        """Initialize the switch entity.

        Args:
            coordinator: Data update coordinator providing device state and client.
            description: Switch entity description with accessors and setter.

        """
        super().__init__(coordinator=coordinator)

        self.entity_description = description
        self._attr_unique_id = f"{coordinator.data.serial_number}-{description.key}"

    @property
    def available(self) -> bool:
        """Return True if the entity is available for use."""
        return super().available and self.entity_description.available_fn(
            self.coordinator.data
        )

    @property
    def is_on(self) -> bool:
        """Return True if the switch is currently on."""
        return self.entity_description.is_on_fn(self.coordinator.data)

    @lametric_exception_handler
    async def async_turn_on(self, **_kwargs: Any) -> None:
        """Turn the switch on and refresh coordinator state."""
        await self.entity_description.set_fn(self.coordinator.lametric, True)
        await self.coordinator.async_request_refresh()

    @lametric_exception_handler
    async def async_turn_off(self, **_kwargs: Any) -> None:
        """Turn the switch off and refresh coordinator state."""
        await self.entity_description.set_fn(self.coordinator.lametric, False)
        await self.coordinator.async_request_refresh()
