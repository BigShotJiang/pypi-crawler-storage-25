"""Config flow for the aiometric_hass integration.

Provides discovery (SSDP/DHCP), manual entry, and cloud-assisted setup via
LaMetric's developer cloud. The flow handles creating and updating config
entries, and performs a test notification to verify connectivity. All log
messages provide device context (host or serial) for diagnostics but never
log sensitive fields such as API keys.
"""

from __future__ import annotations

from ipaddress import ip_address
from typing import TYPE_CHECKING, Any

import voluptuous as vol
from aiometric import (
    BuiltinSound,
    CloudDevice,
    DeviceModel,
    IconType,
    LaMetricCloud,
    LaMetricConnectionError,
    LaMetricDevice,
    Notification,
    NotificationModel,
    NotificationPriority,
    NotificationSound,
    SimpleFrame,
)
from homeassistant.config_entries import SOURCE_REAUTH, ConfigFlowResult
from homeassistant.const import CONF_API_KEY, CONF_DEVICE, CONF_HOST, CONF_MAC
from homeassistant.data_entry_flow import AbortFlow
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.config_entry_oauth2_flow import AbstractOAuth2FlowHandler
from homeassistant.helpers.device_registry import format_mac
from homeassistant.helpers.selector import (
    SelectOptionDict,
    SelectSelector,
    SelectSelectorConfig,
    SelectSelectorMode,
    TextSelector,
    TextSelectorConfig,
    TextSelectorType,
)
from homeassistant.helpers.service_info.ssdp import (
    ATTR_UPNP_FRIENDLY_NAME,
    ATTR_UPNP_SERIAL,
    SsdpServiceInfo,
)
from homeassistant.helpers.service_info.zeroconf import ZeroconfServiceInfo
from homeassistant.util.network import is_link_local
from yarl import URL

from .const import DOMAIN, LOGGER

if TYPE_CHECKING:
    import logging
    from collections.abc import Mapping

    from homeassistant.helpers.service_info.dhcp import DhcpServiceInfo

DEVICES_URL = "https://developer.lametric.com/user/devices"


class LaMetricFlowHandler(AbstractOAuth2FlowHandler, domain=DOMAIN):
    """Handle config flow and related steps for LaMetric devices.

    The handler supports:
    - SSDP discovery
    - DHCP updates
    - Manual host + API key entry
    - OAuth cloud device lookup (used to obtain host/api_key)
    - Re-auth flows
    """

    DOMAIN = DOMAIN
    VERSION = 1

    devices: dict[str, CloudDevice]
    discovered_host: str
    discovered_name: str
    discovered_serial: str | None
    discovered: bool = False

    @property
    def logger(self) -> logging.Logger:
        """Return the integration logger."""
        return LOGGER

    @property
    def extra_authorize_data(self) -> dict[str, Any]:
        """Return extra query parameters appended to the OAuth authorize URL."""
        return {"scope": "basic devices_read"}

    def is_matching(self, other_flow: LaMetricFlowHandler) -> bool:
        """Return True when another in-progress discovery targets the same host."""
        return bool(
            self.discovered
            and other_flow.discovered
            and getattr(self, "discovered_host", None)
            and self.discovered_host == getattr(other_flow, "discovered_host", None)
        )

    async def async_step_user(
        self, _user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Handle the initial step when the user starts the integration flow."""
        return await self.async_step_choice_enter_manual_or_fetch_cloud()

    async def async_step_ssdp(
        self, discovery_info: SsdpServiceInfo
    ) -> ConfigFlowResult:
        """Handle SSDP discovery and pre-fill host/serial where possible.

        Validates discovered location and prevents link-local addresses.
        """
        url = URL(discovery_info.ssdp_location or "")

        if url.host is None or not (
            serial := discovery_info.upnp.get(ATTR_UPNP_SERIAL)
        ):
            return self.async_abort(reason="invalid_discovery_info")

        if is_link_local(ip_address(url.host)):
            return self.async_abort(reason="link_local_address")

        await self.async_set_unique_id(serial)
        self._abort_if_unique_id_configured(updates={CONF_HOST: url.host})

        self.context.update(
            {
                "title_placeholders": {
                    "name": discovery_info.upnp.get(
                        ATTR_UPNP_FRIENDLY_NAME, "LaMetric TIME"
                    ),
                },
                "configuration_url": "https://developer.lametric.com",
            }
        )

        self.discovered = True
        self.discovered_host = str(url.host)
        self.discovered_name = str(
            discovery_info.upnp.get(ATTR_UPNP_FRIENDLY_NAME, "LaMetric TIME")
        )
        self.discovered_serial = serial

        return await self.async_step_choice_enter_manual_or_fetch_cloud()

    async def async_step_zeroconf(
        self, discovery_info: ZeroconfServiceInfo
    ) -> ConfigFlowResult:
        """Handle Zeroconf discovery with host-only matching.

        LaMetric Zeroconf discovery currently exposes only host, model, and
        display name. Without a stable unique identifier we fall back to host
        matching to suppress duplicate flows and use the discovered host for
        manual setup or later cloud correlation.
        """
        if is_link_local(discovery_info.ip_address):
            return self.async_abort(reason="link_local_address")

        self._async_abort_entries_match({CONF_HOST: discovery_info.host})

        self.context.update(
            {
                "title_placeholders": {
                    "name": discovery_info.name.removesuffix(
                        "._lametric-api._tcp.local."
                    ),
                },
                "configuration_url": "https://developer.lametric.com",
            }
        )

        self.discovered = True
        self.discovered_host = discovery_info.host
        self.discovered_name = discovery_info.name.removesuffix(
            "._lametric-api._tcp.local."
        )
        self.discovered_serial = None

        return await self.async_step_choice_enter_manual_or_fetch_cloud()

    async def async_step_reauth(
        self, _entry_data: Mapping[str, Any]
    ) -> ConfigFlowResult:
        """Start the re-authentication flow for an existing entry."""
        return await self.async_step_choice_enter_manual_or_fetch_cloud()

    async def async_step_choice_enter_manual_or_fetch_cloud(
        self, _user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Offer the user a choice to enter credentials manually or fetch from cloud."""
        return self.async_show_menu(
            step_id="choice_enter_manual_or_fetch_cloud",
            menu_options=["pick_implementation", "manual_entry"],
        )

    async def async_step_manual_entry(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Prompt for manual host and API key and attempt to create an entry.

        On failure, returns the form with an appropriate error (cannot_connect
        or unknown). Exceptions are logged with device context (host) for
        debugging while avoiding sensitive data exposure.
        """
        errors: dict[str, str] = {}

        if user_input is not None:
            if self.discovered:
                host = self.discovered_host
            elif self.source == SOURCE_REAUTH:
                host = self._get_reauth_entry().data[CONF_HOST]
            else:
                host = user_input[CONF_HOST]

            try:
                return await self._async_step_create_entry(
                    host, user_input[CONF_API_KEY]
                )
            except AbortFlow:
                raise
            except LaMetricConnectionError as ex:
                LOGGER.error("Connection to LaMetric device at %s failed: %s", host, ex)
                errors["base"] = "cannot_connect"
            except Exception:
                LOGGER.exception(
                    "Unexpected exception during manual entry for host %s", host
                )
                errors["base"] = "unknown"

        schema = {
            vol.Required(CONF_API_KEY): TextSelector(
                TextSelectorConfig(type=TextSelectorType.PASSWORD)
            )
        }

        if not self.discovered and self.source != SOURCE_REAUTH:
            schema = {vol.Required(CONF_HOST): TextSelector()} | schema

        return self.async_show_form(
            step_id="manual_entry",
            data_schema=vol.Schema(schema),
            description_placeholders={
                "devices_url": DEVICES_URL,
            },
            errors=errors,
        )

    async def async_step_cloud_fetch_devices(
        self, data: dict[str, Any]
    ) -> ConfigFlowResult:
        """Use OAuth token to fetch devices from LaMetric cloud.

        Presents the discovered devices to the user for selection.
        """
        lametric = LaMetricCloud(
            token=data["token"]["access_token"],
            session=async_get_clientsession(self.hass),
        )

        self.devices = {
            device.serial_number: device
            for device in sorted(await lametric.get_devices(), key=lambda d: d.name)
        }

        if not self.devices:
            return self.async_abort(reason="no_devices")

        return await self.async_step_cloud_select_device()

    async def async_step_cloud_select_device(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Allow selection of a cloud-discovered device and create the config entry.

        Handles the discovered and reauth cases and maps user selection to a
        device from the previously fetched `self.devices`.
        """
        if self.discovered and self.discovered_serial in self.devices:
            user_input = {CONF_DEVICE: self.discovered_serial}

        elif self.discovered:
            discovered_device = next(
                (
                    device
                    for device in self.devices.values()
                    if str(device.ipv4_internal) == self.discovered_host
                ),
                None,
            )
            if discovered_device is not None:
                user_input = {CONF_DEVICE: discovered_device.serial_number}

        elif self.source == SOURCE_REAUTH:
            reauth_unique_id = self._get_reauth_entry().unique_id

            if reauth_unique_id not in self.devices:
                return self.async_abort(reason="reauth_device_not_found")

            user_input = {CONF_DEVICE: reauth_unique_id}

        elif len(self.devices) == 1:
            user_input = {CONF_DEVICE: next(iter(self.devices.values())).serial_number}

        errors: dict[str, str] = {}

        if user_input is not None:
            device = self.devices[user_input[CONF_DEVICE]]

            try:
                return await self._async_step_create_entry(
                    str(device.ipv4_internal), device.api_key
                )
            except AbortFlow:
                raise
            except LaMetricConnectionError as ex:
                LOGGER.error(
                    "Connection to LaMetric device %s (serial=%s) failed: %s",
                    getattr(device, "ipv4_internal", "unknown"),
                    getattr(device, "serial_number", "unknown"),
                    ex,
                )
                errors["base"] = "cannot_connect"
            except Exception:
                LOGGER.exception(
                    "Unexpected exception while selecting cloud device %s",
                    getattr(device, "serial_number", "unknown"),
                )
                errors["base"] = "unknown"

        return self.async_show_form(
            step_id="cloud_select_device",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_DEVICE): SelectSelector(
                        SelectSelectorConfig(
                            mode=SelectSelectorMode.DROPDOWN,
                            options=[
                                SelectOptionDict(
                                    value=device.serial_number,
                                    label=device.name,
                                )
                                for device in self.devices.values()
                            ],
                        )
                    ),
                }
            ),
            errors=errors,
        )

    async def _async_step_create_entry(
        self, host: str, api_key: str
    ) -> ConfigFlowResult:
        """Attempt to connect to the device at `host` using `api_key`.

        Creates the config entry on success.

        Performs a small verification by retrieving device info and sending a
        short 'connected' notification. Connection errors are raised as
        LaMetricConnectionError and will be surfaced to the caller.
        """
        lametric = LaMetricDevice(
            host=host,
            api_key=api_key,
            session=async_get_clientsession(self.hass),
        )

        try:
            device = await lametric.get_device_state()
        except LaMetricConnectionError as ex:
            LOGGER.error("Failed to reach LaMetric device at %s: %s", host, ex)
            raise

        if self.source != SOURCE_REAUTH:
            await self.async_set_unique_id(
                device.serial_number,
                raise_on_progress=False,
            )
            self._abort_if_unique_id_configured(
                updates={CONF_HOST: lametric.host, CONF_API_KEY: lametric.api_key}
            )

        notify_sound: BuiltinSound | None = None
        if device.model != DeviceModel.SKY:
            notify_sound = BuiltinSound(id=NotificationSound.WIN)

        try:
            await lametric.notify(
                notification=Notification(
                    priority=NotificationPriority.CRITICAL,
                    icon_type=IconType.INFO,
                    model=NotificationModel(
                        cycles=2,
                        frames=[
                            SimpleFrame(text="Connected to Home Assistant!", icon=7956)
                        ],
                        sound=notify_sound,
                    ),
                )
            )
        except LaMetricConnectionError:
            # Treat a failure to notify as a connectivity issue;
            # surface to the flow caller.
            LOGGER.error("Notification test to LaMetric device at %s failed", host)
            raise
        except Exception:
            # Log unexpected errors but do not expose sensitive data in messages.
            LOGGER.exception(
                "Unexpected error while sending test notification to %s", host
            )

        if self.source == SOURCE_REAUTH:
            return self.async_update_reload_and_abort(
                self._get_reauth_entry(),
                data_updates={
                    CONF_HOST: lametric.host,
                    CONF_API_KEY: lametric.api_key,
                },
            )

        return self.async_create_entry(
            title=device.name,
            data={
                CONF_API_KEY: lametric.api_key,
                CONF_HOST: lametric.host,
                CONF_MAC: device.wifi.mac,
            },
        )

    async def async_step_dhcp(
        self, discovery_info: DhcpServiceInfo
    ) -> ConfigFlowResult:
        """Handle DHCP discovery to update an existing entry's host address."""
        mac = format_mac(discovery_info.macaddress)

        for entry in self._async_current_entries():
            if format_mac(entry.data[CONF_MAC]) == mac:
                self.hass.config_entries.async_update_entry(
                    entry,
                    data=entry.data | {CONF_HOST: discovery_info.ip},
                )
                self.hass.async_create_task(
                    self.hass.config_entries.async_reload(entry.entry_id)
                )
                return self.async_abort(reason="already_configured")

        return self.async_abort(reason="unknown")

    # Replace OAuth create entry with a fetch devices step
    # LaMetric only use OAuth to get device information, but doesn't
    # use it later on.
    async_oauth_create_entry = async_step_cloud_fetch_devices
