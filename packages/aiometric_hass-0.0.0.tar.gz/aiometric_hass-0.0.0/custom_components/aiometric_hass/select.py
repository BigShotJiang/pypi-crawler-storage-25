"""Select platform for the aiometric_hass integration.

This module exposes Home Assistant select entities for LaMetric devices.
Each select entity is described by a `LaMetricSelectEntityDescription`
which provides functions to read the current option from the device state
and to apply a selected option asynchronously against the `LaMetricDevice`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from aiometric import DeviceModel, DeviceState, DisplayMode, LaMetricDevice
from homeassistant.components.select import SelectEntity, SelectEntityDescription
from homeassistant.const import EntityCategory

from .entity import LaMetricEntity
from .helpers import lametric_exception_handler

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from homeassistant.core import HomeAssistant
    from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

    from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator


@dataclass(frozen=True, kw_only=True)
class LaMetricSelectEntityDescription(SelectEntityDescription):
    """Describe a LaMetric select entity.

    Attributes:
        current_fn: Callable that extracts the current option string from DeviceState.
        select_fn: Async callable that applies a selected option on LaMetricDevice.

    """

    current_fn: Callable[[DeviceState], str]
    select_fn: Callable[[LaMetricDevice, str], Awaitable[Any]]


SELECTS = [
    LaMetricSelectEntityDescription(
        key="brightness_mode",
        translation_key="brightness_mode",
        entity_category=EntityCategory.CONFIG,
        options=[mode.value for mode in DisplayMode],
        current_fn=lambda state: state.display.brightness_mode.value,
        select_fn=lambda device, option: device.get_or_set_display_state(
            brightness_mode=DisplayMode(option)
        ),
    ),
]


async def async_setup_entry(
    _hass: HomeAssistant,
    entry: LaMetricConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up select entities for a config entry.

    Retrieves the runtime coordinator from the config entry and creates a
    `LaMetricSelectEntity` for each description in `SELECTS`. Entities are
    not created for the SKY device model.
    """
    coordinator = entry.runtime_data

    if coordinator.data.model == DeviceModel.SKY:
        return

    async_add_entities(
        LaMetricSelectEntity(
            coordinator=coordinator,
            description=description,
        )
        for description in SELECTS
    )


class LaMetricSelectEntity(LaMetricEntity, SelectEntity):
    """Representation of a LaMetric select entity.

    The entity reports its current option via `current_fn` and applies a
    selected option using `select_fn`. All remote operations are decorated
    with `lametric_exception_handler` to centralize error handling.
    """

    entity_description: LaMetricSelectEntityDescription

    def __init__(
        self,
        coordinator: LaMetricDataUpdateCoordinator,
        description: LaMetricSelectEntityDescription,
    ) -> None:
        """Initialize the select entity.

        Args:
            coordinator: Data update coordinator providing device state and client.
            description: Select entity description with accessors and setter.

        """
        super().__init__(coordinator=coordinator)

        self.entity_description = description
        self._attr_unique_id = f"{coordinator.data.serial_number}-{description.key}"

    @property
    def current_option(self) -> str | None:
        """Return the current selected option from the device state."""
        return self.entity_description.current_fn(self.coordinator.data)

    @lametric_exception_handler
    async def async_select_option(self, option: str) -> None:
        """Apply the selected option on the device and refresh coordinator."""
        await self.entity_description.select_fn(self.coordinator.lametric, option)
        await self.coordinator.async_request_refresh()
