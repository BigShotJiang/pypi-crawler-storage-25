"""Base entity helpers for the aiometric_hass integration.

This module provides `LaMetricEntity`, a CoordinatorEntity subclass that
initializes common device information and connections for LaMetric devices.
All platform entities in this integration should inherit from
`LaMetricEntity` to reuse device identification and connection details.
"""

from __future__ import annotations

from homeassistant.helpers.device_registry import (
    CONNECTION_BLUETOOTH,
    CONNECTION_NETWORK_MAC,
    DeviceInfo,
    format_mac,
)
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import LaMetricDataUpdateCoordinator


class LaMetricEntity(CoordinatorEntity[LaMetricDataUpdateCoordinator]):
    """Coordinator-backed base entity for LaMetric devices.

    The base entity sets the entity's device information using the latest
    `DeviceState` available from the coordinator. This includes network and
    Bluetooth connections, identifiers, manufacturer/model information,
    software version, and a configuration URL for the device.
    """

    _attr_has_entity_name = True

    def __init__(self, coordinator: LaMetricDataUpdateCoordinator) -> None:
        """Initialize common device info for the entity.

        Args:
            coordinator: The data update coordinator that provides the latest
                `DeviceState` and the client used to control the device.

        """
        super().__init__(coordinator=coordinator)

        connections = {(CONNECTION_NETWORK_MAC, format_mac(coordinator.data.wifi.mac))}

        if coordinator.data.bluetooth is not None:
            connections.add(
                (CONNECTION_BLUETOOTH, format_mac(coordinator.data.bluetooth.mac))
            )

        self._attr_device_info = DeviceInfo(
            connections=connections,
            identifiers={(DOMAIN, coordinator.data.serial_number)},
            manufacturer="LaMetric Inc.",
            model_id=coordinator.data.model,
            name=coordinator.data.name,
            sw_version=coordinator.data.os_version,
            serial_number=coordinator.data.serial_number,
            configuration_url=f"https://{coordinator.data.wifi.ipv4}/",
        )
