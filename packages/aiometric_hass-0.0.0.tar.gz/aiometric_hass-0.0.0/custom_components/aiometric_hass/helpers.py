"""Helper utilities for the aiometric_hass integration.

This module provides:
- `lametric_exception_handler`: a decorator for entity operations that
  centralizes error handling for the aiometric library, logs diagnostics,
  and raises Home Assistant friendly errors.
- `async_get_coordinator_by_device_id`: helper to locate the runtime
  coordinator for a given device registry ID.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Concatenate

from aiometric import LaMetricConnectionError, LaMetricError
from homeassistant.core import HomeAssistant, callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers import device_registry as dr

from .const import DOMAIN, LOGGER
from .entity import LaMetricEntity

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine

    from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator


def lametric_exception_handler[LaMetricEntityT: LaMetricEntity, **P](
    func: Callable[Concatenate[LaMetricEntityT, P], Coroutine[Any, Any, Any]],
) -> Callable[Concatenate[LaMetricEntityT, P], Coroutine[Any, Any, None]]:
    """Wrap LaMetric entity async calls with error handling.

    The decorated coroutine will:
    - execute the wrapped function,
    - call `self.coordinator.async_update_listeners()` on success,
    - on connection errors mark coordinator update as failed, notify listeners,
      log the underlying error, and raise a descriptive HomeAssistantError,
    - on other LaMetric library errors log the issue and raise a descriptive
      HomeAssistantError.

    The raised HomeAssistantError messages are intentionally actionable and
    avoid exposing sensitive data such as API keys.
    """

    async def handler(self: LaMetricEntityT, *args: P.args, **kwargs: P.kwargs) -> None:
        try:
            await func(self, *args, **kwargs)
            self.coordinator.async_update_listeners()

        except LaMetricConnectionError as error:
            # Mark coordinator update as failed and notify listeners
            # so the UI reflects unavailability.
            self.coordinator.last_update_success = False
            self.coordinator.async_update_listeners()

            host = getattr(
                getattr(self.coordinator, "lametric", None), "host", "unknown"
            )
            LOGGER.error(
                "Communication failure with LaMetric device at %s: %s",
                host,
                error,
            )
            # Provide a clearer, actionable message while avoiding sensitive details.
            msg = (
                f"Could not communicate with LaMetric device at {host}. "
                "Check network connectivity and device settings."
            )
            raise HomeAssistantError(msg) from error

        except LaMetricError as error:
            host = getattr(
                getattr(self.coordinator, "lametric", None), "host", "unknown"
            )
            LOGGER.error(
                "Unexpected response from LaMetric device at %s: %s",
                host,
                error,
            )
            msg = (
                f"Received unexpected response from LaMetric device at {host}. "
                "Check device firmware and integration compatibility."
            )
            raise HomeAssistantError(msg) from error

    return handler


@callback
def async_get_coordinator_by_device_id(
    hass: HomeAssistant, device_id: str
) -> LaMetricDataUpdateCoordinator:
    """Return the runtime coordinator for the given device registry ID.

    Args:
        hass: Home Assistant instance.
        device_id: Device registry ID to look up.

    Returns:
        The associated `LaMetricDataUpdateCoordinator`.

    Raises:
        ValueError: if the device ID is unknown or no config entry/coordinator
                    is associated with the device.

    """
    device_registry = dr.async_get(hass)

    if (device_entry := device_registry.async_get(device_id)) is None:
        msg = f"Unknown LaMetric device ID: {device_id}"
        raise ValueError(msg)

    entry: LaMetricConfigEntry
    for entry in hass.config_entries.async_loaded_entries(DOMAIN):
        if entry.entry_id in device_entry.config_entries:
            return entry.runtime_data

    msg = f"No coordinator for device ID: {device_id}"
    raise ValueError(msg)
