"""Diagnostics helpers for the aiometric_hass integration.

This module provides the diagnostics hook used by Home Assistant to
collect and redact diagnostic information for a configured LaMetric device.
Collected data is redacted using `async_redact_data` to avoid exposing
sensitive fields.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from homeassistant.components.diagnostics import async_redact_data

if TYPE_CHECKING:
    from homeassistant.core import HomeAssistant

    from .coordinator import LaMetricConfigEntry


# Fields to redact from diagnostics output to avoid leaking sensitive data.
TO_REDACT = {
    "device_id",
    "name",
    "serial_number",
    "ssid",
}


async def async_get_config_entry_diagnostics(
    _hass: HomeAssistant, entry: LaMetricConfigEntry
) -> dict[str, Any]:
    """Return redacted diagnostics for the given config entry.

    Args:
        hass: Home Assistant instance (provided by the platform).
        entry: Config entry whose runtime coordinator contains device state.

    Returns:
        A dictionary with the device state serialized to JSON and redacted
        according to `TO_REDACT`.

    """
    coordinator = entry.runtime_data
    data = json.loads(coordinator.data.to_json())

    return async_redact_data(data, TO_REDACT)
