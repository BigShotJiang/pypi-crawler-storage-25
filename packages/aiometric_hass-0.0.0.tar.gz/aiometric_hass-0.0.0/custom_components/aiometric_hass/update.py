"""Update platform for the aiometric_hass integration.

This module exposes a firmware update entity for LaMetric devices that
support firmware updates. The platform creates a single `LaMetricUpdate`
entity when the device OS version indicates the update feature is available.
The update entity reports the installed and latest firmware versions and
uses the coordinator for access to the device state.
"""

from awesomeversion import AwesomeVersion
from homeassistant.components.update import UpdateDeviceClass, UpdateEntity
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator
from .entity import LaMetricEntity


async def async_setup_entry(
    _hass: HomeAssistant,
    config_entry: LaMetricConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up the update entity for a config entry.

    The coordinator with runtime data is retrieved from the config entry's
    `runtime_data`. If the device OS version is new enough to support update
    metadata (>= 2.3.0) a `LaMetricUpdate` entity is created and added.
    """
    coordinator = config_entry.runtime_data

    if coordinator.data.os_version >= AwesomeVersion("2.3.0"):
        async_add_entities([LaMetricUpdate(coordinator)])


class LaMetricUpdate(LaMetricEntity, UpdateEntity):
    """Representation of a device firmware update entity for LaMetric.

    The entity exposes the currently installed firmware version and the
    latest available version (if provided by the device state).
    """

    _attr_device_class = UpdateDeviceClass.FIRMWARE

    def __init__(self, coordinator: LaMetricDataUpdateCoordinator) -> None:
        """Initialize the update entity.

        Args:
            coordinator: Data update coordinator providing device state.

        """
        super().__init__(coordinator=coordinator)

        self._attr_unique_id = f"{coordinator.data.serial_number}-update"

    @property
    def installed_version(self) -> str:
        """Return the currently installed firmware version."""
        return str(self.coordinator.data.os_version)

    @property
    def latest_version(self) -> str | None:
        """Return the latest firmware version available, or the installed version.

        The device may include update metadata in `coordinator.data.update`.
        If not present, the installed version is returned as the latest
        known value to avoid presenting None when no update information
        is available.
        """
        if not self.coordinator.data.update_available:
            return str(self.coordinator.data.os_version)

        return str(self.coordinator.data.update_available.version)
