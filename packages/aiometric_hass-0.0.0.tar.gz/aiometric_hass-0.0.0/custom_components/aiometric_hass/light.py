"""Light platform for the aiometric_hass integration.

This module exposes Home Assistant light entities for supported LaMetric
devices (currently the SKY model). Each light entity is described by a
`LaMetricLightEntityDescription` which contains functions for reading and
writing brightness and on/off state from the coordinator's `DeviceState`
and the `LaMetricDevice` client.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from aiometric import DeviceModel, DeviceState, LaMetricDevice
from homeassistant.components.light import (
    ATTR_BRIGHTNESS,
    LightEntity,
    LightEntityDescription,
)
from homeassistant.const import EntityCategory
from homeassistant.util.color import brightness_to_value, value_to_brightness

from .const import BRIGHTNESS_SCALE
from .entity import LaMetricEntity
from .helpers import lametric_exception_handler

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from homeassistant.core import HomeAssistant
    from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

    from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator


@dataclass(frozen=True, kw_only=True)
class LaMetricLightEntityDescription(LightEntityDescription):
    """Describe a LaMetric light entity.

    Attributes:
        brightness_get_fn: Callable that extracts brightness (0-255) from a DeviceState.
        brightness_set_fn: Async callable that sets brightness on a LaMetricDevice.
        state_get_fn: Callable that returns the on/off state from a DeviceState.
        state_set_fn: Async callable that sets the on/off state on a LaMetricDevice.

    """

    brightness_get_fn: Callable[[DeviceState], int | None]
    brightness_set_fn: Callable[[LaMetricDevice, int], Awaitable[Any]]
    state_get_fn: Callable[[DeviceState], bool]
    state_set_fn: Callable[[LaMetricDevice, bool], Awaitable[Any]]


LIGHTS = [
    LaMetricLightEntityDescription(
        key="light",
        translation_key="light",
        entity_category=EntityCategory.CONFIG,
        brightness_get_fn=lambda state: state.display.brightness,
        brightness_set_fn=lambda device, brightness: device.get_or_set_display_state(
            brightness=brightness
        ),
        state_get_fn=lambda state: state.display.on,
        state_set_fn=lambda device, state: device.get_or_set_display_state(on=state),
    ),
]


async def async_setup_entry(
    _hass: HomeAssistant,
    entry: LaMetricConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up light entities for a config entry.

    Retrieves the runtime coordinator from the config entry and creates a
    `LaMetricLightEntity` for each description in `LIGHTS` when the device
    model supports a display (DeviceModel.SKY). Entities are only created
    if the description's `state_get_fn` returns a non-None value for the
    current device state.
    """
    coordinator = entry.runtime_data

    if coordinator.data.model != DeviceModel.SKY:
        return

    async_add_entities(
        LaMetricLightEntity(
            coordinator=coordinator,
            description=description,
        )
        for description in LIGHTS
        if description.state_get_fn(coordinator.data) is not None
    )


class LaMetricLightEntity(LaMetricEntity, LightEntity):
    """Representation of a LaMetric light entity.

    The entity reads its current state (on/off) and brightness via the
    functions provided in its `entity_description`. Changes to state or
    brightness are executed against the `LaMetricDevice` client obtained
    from the coordinator. All remote operations are decorated with the
    `lametric_exception_handler` to centralize error handling.
    """

    entity_description: LaMetricLightEntityDescription

    def __init__(
        self,
        coordinator: LaMetricDataUpdateCoordinator,
        description: LaMetricLightEntityDescription,
    ) -> None:
        """Initialize the LaMetric light entity.

        Args:
            coordinator: Data update coordinator that provides `DeviceState`
                and `LaMetricDevice` client.
            description: Light entity description containing getters and setters.

        """
        super().__init__(coordinator=coordinator)

        self.entity_description = description
        self._attr_unique_id = f"{coordinator.data.serial_number}-{description.key}"

    @property
    def is_on(self) -> bool | None:
        """Return True if the light is on, False if off, or None if unknown."""
        return self.entity_description.state_get_fn(self.coordinator.data)

    @property
    def brightness(self) -> int | None:
        """Return the current brightness (0-255) or None if not available."""
        raw = self.entity_description.brightness_get_fn(self.coordinator.data)
        if raw is None:
            return None
        return value_to_brightness(BRIGHTNESS_SCALE, float(raw))

    @lametric_exception_handler
    async def async_turn_on(self, **kwargs: Any) -> None:
        """Turn the light on.

        Calls the description's `state_set_fn` with `True`, applies the
        requested brightness (converted from HA's 0-255 scale to the device
        scale using `brightness_to_value` and `BRIGHTNESS_SCALE`), and then
        requests a coordinator refresh to update the entity state.

        Note: conversion uses `math.ceil` to avoid losing precision when the
        device expects integer brightness steps.
        """
        brigthness_value = math.ceil(
            brightness_to_value(BRIGHTNESS_SCALE, kwargs[ATTR_BRIGHTNESS])
        )

        await self.entity_description.state_set_fn(self.coordinator.lametric, True)
        await self.entity_description.brightness_set_fn(
            self.coordinator.lametric, brigthness_value
        )
        await self.coordinator.async_request_refresh()

    @lametric_exception_handler
    async def async_turn_off(self, **_kwargs: Any) -> None:
        """Turn the light off.

        Calls the description's `state_set_fn` with `False` and requests a
        coordinator refresh to update the entity state.
        """
        await self.entity_description.state_set_fn(self.coordinator.lametric, False)
        await self.coordinator.async_request_refresh()
