"""Constants for the aiometric_hass integration.

This module centralizes configuration and platform constants used across the
integration. Keep values here that are shared between platforms, services,
and helpers.

Notes:
- `BRIGHTNESS_SCALE` maps the device brightness scale used by the library
  (min, max) and is used with Home Assistant color helpers to convert
  between HA's 0-255 brightness and the device's native scale.
- `UPDATE_INTERVAL` controls the coordinator polling interval.
- `LOGGER` is the integration logger used elsewhere (do not log sensitive data).

"""

import logging
from datetime import timedelta
from typing import Final

from homeassistant.const import Platform

DOMAIN: Final = "aiometric_hass"

# Platforms provided by this integration
PLATFORMS = [
    Platform.BUTTON,
    Platform.LIGHT,
    Platform.NOTIFY,
    Platform.NUMBER,
    Platform.SWITCH,
    Platform.SCENE,
    Platform.SELECT,
    Platform.SENSOR,
    Platform.UPDATE,
]

# Integration logger (use for diagnostics; avoid logging secrets)
LOGGER = logging.getLogger(__package__)

# Coordinator update interval
UPDATE_INTERVAL = timedelta(seconds=30)

# Device brightness scale (min, max) used by the aiometric library/device.
# Convert between this scale and HA's 0-255 brightness using HA helpers.
BRIGHTNESS_SCALE = (1, 100)

# Service / notification related configuration keys
CONF_CYCLES: Final = "cycles"
CONF_DATA: Final = "data"
CONF_ICON_TYPE: Final = "icon_type"
CONF_LIFETIME: Final = "lifetime"
CONF_MESSAGE: Final = "message"
CONF_PRIORITY: Final = "priority"
CONF_SOUND: Final = "sound"

# Stream configuration keys
CONF_FILL_TYPE: Final = "fill_type"
CONF_RENDER_MODE: Final = "render_mode"
CONF_POST_PROCESS: Final = "post_process"

CONF_STREAM_STATE: Final = "state"
CONF_STREAM_RGB_DATA: Final = "rgb_data"
CONF_STREAM_X: Final = "start_x"
CONF_STREAM_Y: Final = "start_y"
CONF_STREAM_WIDTH: Final = "width"
CONF_STREAM_HEIGHT: Final = "height"

# Service names exposed by the integration
SERVICE_SHOW_MESSAGE: Final = "show_message"
SERVICE_SHOW_CHART: Final = "show_chart"
SERVICE_START_STREAM: Final = "start_stream"
SERVICE_SEND_FRAME: Final = "send_frame"
SERVICE_STOP_STREAM: Final = "stop_stream"
