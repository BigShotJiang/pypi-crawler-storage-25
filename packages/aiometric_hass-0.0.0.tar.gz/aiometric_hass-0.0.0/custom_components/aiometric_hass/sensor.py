"""Sensor platform for the aiometric_hass integration.

This module exposes Home Assistant sensor entities for LaMetric devices.
Each sensor entity is described by a `LaMetricSensorEntityDescription`
which contains a `value_fn` used to extract the sensor value from the
`LaMetricDevice` data object provided by the coordinator.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from homeassistant.components.sensor import (
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.const import PERCENTAGE, EntityCategory

from .entity import LaMetricEntity

if TYPE_CHECKING:
    from collections.abc import Callable

    from aiometric import DeviceState
    from homeassistant.core import HomeAssistant
    from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

    from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator


@dataclass(frozen=True, kw_only=True)
class LaMetricSensorEntityDescription(SensorEntityDescription):
    """Describe a LaMetric sensor entity.

    Attributes:
        value_fn: Callable that takes a `LaMetricDevice` and returns the
                  native sensor value (int or None).

    """

    value_fn: Callable[[DeviceState], int | None]


SENSORS = [
    LaMetricSensorEntityDescription(
        key="rssi",
        translation_key="rssi",
        entity_category=EntityCategory.DIAGNOSTIC,
        entity_registry_enabled_default=False,
        native_unit_of_measurement=PERCENTAGE,
        state_class=SensorStateClass.MEASUREMENT,
        value_fn=lambda state: state.wifi.signal_strength,
    ),
]


async def async_setup_entry(
    _hass: HomeAssistant,
    entry: LaMetricConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up sensor entities for a config entry.

    The runtime coordinator is provided via the config entry's `runtime_data`.
    For each sensor description in `SENSORS` a `LaMetricSensorEntity` instance
    is created and added to Home Assistant.
    """
    coordinator = entry.runtime_data

    async_add_entities(
        LaMetricSensorEntity(
            coordinator=coordinator,
            description=description,
        )
        for description in SENSORS
    )


class LaMetricSensorEntity(LaMetricEntity, SensorEntity):
    """Representation of a LaMetric sensor entity.

    This entity delegates obtaining its value to the `value_fn` stored in
    its `entity_description`. The unique ID is built from the device serial
    number and the description key.
    """

    entity_description: LaMetricSensorEntityDescription

    def __init__(
        self,
        coordinator: LaMetricDataUpdateCoordinator,
        description: LaMetricSensorEntityDescription,
    ) -> None:
        """Initialize the sensor entity.

        Args:
            coordinator: Data update coordinator that provides `LaMetricDevice` data.
            description: Sensor entity description containing metadata and `value_fn`.

        """
        super().__init__(coordinator=coordinator)

        self.entity_description = description
        self._attr_unique_id = f"{coordinator.data.serial_number}-{description.key}"

    @property
    def native_value(self) -> int | None:
        """Return the current native value for the sensor.

        The value is computed by calling the `value_fn` with the latest
        `LaMetricDevice` available from the coordinator.
        """
        return self.entity_description.value_fn(self.coordinator.data)
