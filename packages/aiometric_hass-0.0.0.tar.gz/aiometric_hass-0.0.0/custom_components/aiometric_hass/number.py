"""Number platform for the aiometric_hass integration.

This module exposes Home Assistant number entities that map device-level
numeric controls (for example display brightness and audio volume) to
Home Assistant `NumberEntity` objects. Each number entity is described by a
`LaMetricNumberEntityDescription` which provides functions to read the
current value, the allowed range, presence checks, and an async setter
which applies the requested value to the `LaMetricDevice`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from aiometric import DeviceModel, DeviceState, LaMetricDevice, ValueRange
from homeassistant.components.number import NumberEntity, NumberEntityDescription
from homeassistant.const import PERCENTAGE, EntityCategory

from .entity import LaMetricEntity
from .helpers import lametric_exception_handler

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from homeassistant.core import HomeAssistant
    from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

    from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator


@dataclass(frozen=True, kw_only=True)
class LaMetricNumberEntityDescription(NumberEntityDescription):
    """Describe a LaMetric number entity.

    Attributes:
        value_fn: Callable that returns the current value from a `DeviceState`.
        range_fn: Callable that returns a `ValueRange` or None for the device state.
        has_fn: Callable that determines whether the feature is present/available.
        set_value_fn: Async callable that sets the numeric value on `LaMetricDevice`.

    """

    value_fn: Callable[[DeviceState], int | None]
    range_fn: Callable[[DeviceState], ValueRange | None]
    has_fn: Callable[[DeviceState], bool]
    set_value_fn: Callable[[LaMetricDevice, int], Awaitable[Any]]


NUMBERS = [
    LaMetricNumberEntityDescription(
        key="brightness",
        translation_key="brightness",
        entity_category=EntityCategory.CONFIG,
        native_step=1,
        range_fn=lambda state: state.display.brightness_limit,
        native_unit_of_measurement=PERCENTAGE,
        has_fn=lambda _state: True,
        value_fn=lambda state: state.display.brightness,
        set_value_fn=lambda device, brightness: device.get_or_set_display_state(
            brightness=brightness
        ),
    ),
    LaMetricNumberEntityDescription(
        key="volume",
        translation_key="volume",
        entity_category=EntityCategory.CONFIG,
        native_step=1,
        range_fn=lambda state: state.audio.volume_range if state.audio else None,
        native_unit_of_measurement=PERCENTAGE,
        has_fn=lambda state: bool(state.audio and state.audio.available),
        value_fn=lambda state: state.audio.volume if state.audio else 0,
        set_value_fn=lambda device, volume: device.get_or_set_audio_state(
            volume=volume
        ),
    ),
]


async def async_setup_entry(
    _hass: HomeAssistant,
    entry: LaMetricConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up number entities for a config entry.

    The runtime coordinator is retrieved from the config entry. Number
    entities are not created for the SKY model (device model SKY does not
    expose the same number controls). For other models a `LaMetricNumberEntity`
    is created for each description in `NUMBERS`.
    """
    coordinator = entry.runtime_data

    if coordinator.data.model == DeviceModel.SKY:
        return

    async_add_entities(
        LaMetricNumberEntity(
            coordinator=coordinator,
            description=description,
        )
        for description in NUMBERS
    )


class LaMetricNumberEntity(LaMetricEntity, NumberEntity):
    """Representation of a LaMetric number entity.

    The entity obtains its current value and supported range from the
    corresponding callbacks on the `entity_description` and applies changes
    using the provided async setter. All remote operations are decorated
    with `lametric_exception_handler` to centralize error handling.
    """

    entity_description: LaMetricNumberEntityDescription

    def __init__(
        self,
        coordinator: LaMetricDataUpdateCoordinator,
        description: LaMetricNumberEntityDescription,
    ) -> None:
        """Initialize the number entity.

        Args:
            coordinator: Coordinator providing device state and client.
            description: Description object with accessors and setter.

        """
        super().__init__(coordinator=coordinator)

        self.entity_description = description
        self._attr_unique_id = f"{coordinator.data.serial_number}-{description.key}"

    @property
    def native_value(self) -> int | None:
        """Return the current native value for the entity (or None)."""
        return self.entity_description.value_fn(self.coordinator.data)

    @property
    def native_min_value(self) -> int:
        """Return the minimum supported native value for the entity."""
        if limits := self.entity_description.range_fn(self.coordinator.data):
            return int(limits.min)
        return 0

    @property
    def native_max_value(self) -> int:
        """Return the maximum supported native value for the entity."""
        if limits := self.entity_description.range_fn(self.coordinator.data):
            return int(limits.max)
        return 100

    @lametric_exception_handler
    async def async_set_native_value(self, value: float) -> None:
        """Set the native value on the device and refresh coordinator.

        The provided float value is forwarded to the configured `set_value_fn`
        and the coordinator is requested to refresh to reflect the change.
        """
        await self.entity_description.set_value_fn(
            self.coordinator.lametric, int(value)
        )
        await self.coordinator.async_request_refresh()
