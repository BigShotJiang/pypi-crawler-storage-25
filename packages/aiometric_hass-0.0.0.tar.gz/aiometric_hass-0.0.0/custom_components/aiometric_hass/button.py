"""Button platform for the aiometric_hass integration.

This module exposes Home Assistant button entities which allow users to
trigger actions on a LaMetric device (for example: switch to the next
app, dismiss notifications). Each button entity is described by a
`LaMetricButtonEntityDescription` which provides a `press_fn` used to
perform the corresponding action against a `LaMetricDevice`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from homeassistant.components.button import ButtonEntity, ButtonEntityDescription
from homeassistant.const import EntityCategory

from .entity import LaMetricEntity
from .helpers import lametric_exception_handler

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from aiometric import LaMetricDevice
    from homeassistant.core import HomeAssistant
    from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

    from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator


@dataclass(frozen=True, kw_only=True)
class LaMetricButtonEntityDescription(ButtonEntityDescription):
    """Describe a LaMetric button entity.

    Attributes:
        press_fn: Async callable that receives a `LaMetricDevice` and
                  performs the action associated with the button.

    """

    press_fn: Callable[[LaMetricDevice], Awaitable[Any]]


BUTTONS = [
    LaMetricButtonEntityDescription(
        key="app_next",
        translation_key="app_next",
        entity_category=EntityCategory.CONFIG,
        press_fn=lambda device: device.activate_next_app(),
    ),
    LaMetricButtonEntityDescription(
        key="app_previous",
        translation_key="app_previous",
        entity_category=EntityCategory.CONFIG,
        press_fn=lambda device: device.activate_previous_app(),
    ),
    LaMetricButtonEntityDescription(
        key="dismiss_current",
        translation_key="dismiss_current",
        entity_category=EntityCategory.CONFIG,
        press_fn=lambda device: device.dismiss_current_notification(),
    ),
    LaMetricButtonEntityDescription(
        key="dismiss_all",
        translation_key="dismiss_all",
        entity_category=EntityCategory.CONFIG,
        press_fn=lambda device: device.dismiss_all_notifications(),
    ),
]


async def async_setup_entry(
    _hass: HomeAssistant,
    entry: LaMetricConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up LaMetric button entities for a config entry.

    The coordinator with runtime data is retrieved from the config entry's
    `runtime_data`. A `LaMetricButtonEntity` is created for each description
    in `BUTTONS` and added to Home Assistant.
    """
    coordinator = entry.runtime_data

    async_add_entities(
        LaMetricButtonEntity(
            coordinator=coordinator,
            description=description,
        )
        for description in BUTTONS
    )


class LaMetricButtonEntity(LaMetricEntity, ButtonEntity):
    """Representation of a LaMetric button entity.

    The entity delegates execution of its action to the `press_fn` supplied
    in its `entity_description`. The unique id is composed of the device
    serial number and the description key.
    """

    entity_description: LaMetricButtonEntityDescription

    def __init__(
        self,
        coordinator: LaMetricDataUpdateCoordinator,
        description: LaMetricButtonEntityDescription,
    ) -> None:
        """Initialize the button entity.

        Args:
            coordinator: Data update coordinator that provides device data and client.
            description: Button entity description containing metadata and `press_fn`.

        """
        super().__init__(coordinator=coordinator)

        self.entity_description = description
        self._attr_unique_id = f"{coordinator.data.serial_number}-{description.key}"

    @lametric_exception_handler
    async def async_press(self) -> None:
        """Handle the button press.

        Calls the configured `press_fn` with the `LaMetricDevice` client from
        the coordinator. The `lametric_exception_handler` decorator ensures
        exceptions are handled and logged consistently.
        """
        await self.entity_description.press_fn(self.coordinator.lametric)
