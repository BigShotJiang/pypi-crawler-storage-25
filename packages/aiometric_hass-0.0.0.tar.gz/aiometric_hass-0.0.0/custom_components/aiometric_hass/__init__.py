"""aiometric_hass integration entrypoint.

This module sets up integration-level services and forwards config entries
to platform modules. It also uses discovery to load the notify platform
because the notify component does not support config entry platforms.

Functions:
- async_setup: register services used by the integration.
- async_setup_entry: create the coordinator, refresh data, and set up platforms.
- async_unload_entry: unload platforms and trigger notify reload when needed.
"""

from homeassistant.components.notify.legacy import async_reload as notify_async_reload
from homeassistant.const import CONF_NAME, Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers import discovery
from homeassistant.helpers.typing import ConfigType

from .const import DOMAIN, PLATFORMS
from .coordinator import LaMetricConfigEntry, LaMetricDataUpdateCoordinator
from .services import async_setup_services

CONFIG_SCHEMA = cv.config_entry_only_config_schema(DOMAIN)


async def async_setup(hass: HomeAssistant, _config: ConfigType) -> bool:
    """Perform integration setup not tied to a single config entry.

    This registers integration-level services (e.g. notification and
    streaming services) by calling `async_setup_services`.
    """
    async_setup_services(hass)

    return True


async def async_setup_entry(hass: HomeAssistant, entry: LaMetricConfigEntry) -> bool:
    """Set up a config entry.

    Creates a `LaMetricDataUpdateCoordinator`, performs the initial refresh,
    stores the coordinator on the entry as `runtime_data`, and forwards setup
    to the platforms listed in `PLATFORMS`.

    The notify platform is loaded via discovery because the notify component
    does not currently support config entry platforms; the discovery payload
    includes the device name and the originating entry id.
    """
    coordinator = LaMetricDataUpdateCoordinator(hass, entry)

    await coordinator.async_config_entry_first_refresh()

    entry.runtime_data = coordinator

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    # Set up notify platform, no entry support for notify component yet,
    # have to use discovery to load platform.
    hass.async_create_task(
        discovery.async_load_platform(
            hass,
            Platform.NOTIFY,
            DOMAIN,
            {CONF_NAME: coordinator.data.name, "entry_id": entry.entry_id},
            {},
        )
    )
    return True


async def async_unload_entry(hass: HomeAssistant, entry: LaMetricConfigEntry) -> bool:
    """Unload a config entry and its platforms.

    If platform unload succeeds, trigger a reload of the notify component to
    ensure the notify platform is updated/removed as needed.
    """
    if unload_ok := await hass.config_entries.async_unload_platforms(entry, PLATFORMS):
        await notify_async_reload(hass, DOMAIN)

    return unload_ok
