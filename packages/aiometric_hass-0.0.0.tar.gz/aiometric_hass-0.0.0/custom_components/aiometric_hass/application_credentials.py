"""Application credentials helper for the aiometric_hass integration.

This module provides the AuthorizationServer configuration required by
Home Assistant's application credentials flow to perform OAuth2 with
the LaMetric developer API.

The returned AuthorizationServer contains the authorization and token
endpoints used during the OAuth2 authorization code flow.
"""

from homeassistant.components.application_credentials import AuthorizationServer
from homeassistant.core import HomeAssistant


async def async_get_authorization_server(_hass: HomeAssistant) -> AuthorizationServer:
    """Return an AuthorizationServer configured for LaMetric's OAuth2 endpoints.

    Args:
        _hass: HomeAssistant instance (provided by Home Assistant, not used here).

    Returns:
        AuthorizationServer with `authorize_url` and `token_url` set to
        LaMetric's developer API endpoints.

    """
    return AuthorizationServer(
        authorize_url="https://developer.lametric.com/api/v2/oauth2/authorize",
        token_url="https://developer.lametric.com/api/v2/oauth2/token",  # noqa: S106
    )
