# aiometric

Asynchronous Python client for the LaMetric local device API and LaMetric Cloud API.

aiometric gives you typed models, async-first device/cloud clients, and practical helpers for common tasks such as reading device state, controlling display/audio, sending notifications, and querying cloud-connected devices.

## Features

- Async clients for local and cloud APIs
- Typed request/response models (dataclasses)
- Retries for transient connection failures
- Clear error classes for auth, timeout, and API version issues
- Optional streaming support via LMSP UDP frames

## Requirements

- Python 3.14+

## Installation

Install from PyPI:

```bash
pip install aiometric
```

Or with Poetry:

```bash
poetry add aiometric
```

## Quick Start

### Example 1: Connect to a local device and send a notification

```python
import asyncio

from aiometric import (
	LaMetricDevice,
	Notification,
	NotificationModel,
	SimpleFrame,
)


async def main() -> None:
	# Get API key from the LaMetric developer page / app settings.
	host = "192.168.1.100"
	api_key = "YOUR_DEVICE_API_KEY"

	async with LaMetricDevice(host=host, api_key=api_key) as device:
		state = await device.get_device_state()
		print(f"Connected to: {state.name} ({state.model})")

		# Update display brightness.
		display = await device.get_or_set_display_state(brightness=40)
		print(f"Brightness is now: {display.brightness}")

		# Send a simple notification.
		notification = Notification(
			model=NotificationModel(
				frames=[SimpleFrame(text="Hello from aiometric")],
				cycles=1,
				repeat=1,
			)
		)
		notification_id = await device.notify(notification)
		print(f"Notification sent: {notification_id}")


asyncio.run(main())
```

### Example 2: Use LaMetric Cloud API

```python
import asyncio

from aiometric import LaMetricCloud


async def main() -> None:
	token = "YOUR_CLOUD_ACCESS_TOKEN"

	async with LaMetricCloud(token=token) as cloud:
		user = await cloud.get_current_user()
		print(f"User: {user.email}")

		devices = await cloud.get_devices()
		print(f"Cloud devices: {len(devices)}")
		for device in devices:
			print(f"- {device.id}: {device.name} ({device.state})")


asyncio.run(main())
```

## Common Device Operations

Local client methods in `LaMetricDevice` include:

- `get_device_state()`
- `get_or_set_display_state(...)`
- `get_or_set_audio_state(...)`
- `get_or_set_bluetooth_state(...)`
- `get_wifi_state()`
- `get_apps()`, `get_app(package)`
- `notify(...)`, `get_notifications()`, `dismiss_notification(...)`
- `get_streaming_state()`, `start_stream(...)`, `send_stream_frame(...)`

Cloud client methods in `LaMetricCloud` include:

- `get_current_user()`
- `get_devices()`
- `get_device(device_id)`

## Error Handling

aiometric raises specific exception types you can catch:

- `LaMetricAuthenticationError`
- `LaMetricConnectionTimeoutError`
- `LaMetricConnectionError`
- `LaMetricInvalidApiVersionError`
- `LaMetricError` (base class)

Example:

```python
from aiometric import LaMetricAuthenticationError, LaMetricConnectionTimeoutError

try:
	...
except LaMetricAuthenticationError:
	print("Invalid token or API key")
except LaMetricConnectionTimeoutError:
	print("Request timed out")
```

## Development

Run tests:

```bash
poetry run pytest
```

Run all checks:

```bash
poetry run pre-commit run --all-files
```

## License

MIT
