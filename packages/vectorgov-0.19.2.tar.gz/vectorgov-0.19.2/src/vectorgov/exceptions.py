"""
Exceções customizadas do VectorGov SDK.
"""

from typing import Optional


class VectorGovError(Exception):
    """Exceção base para todos os erros do VectorGov SDK.

    Attributes:
        message: Mensagem de erro.
        status_code: Status HTTP (quando aplicável).
        response: Dict do body de erro parseado (quando aplicável).
        request_id: ID único da requisição que gerou o erro — extraído do
            body JSON ou do header ``X-Request-ID``. Forneça este valor ao
            reportar bugs ao suporte técnico. Pode ser ``None`` se o
            backend não enviou ou o erro foi local.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[dict] = None,
        request_id: Optional[str] = None,
    ):
        self.message = message
        self.status_code = status_code
        self.response = response
        self.request_id = request_id
        super().__init__(self.message)

    def __str__(self) -> str:
        parts = []
        if self.status_code:
            parts.append(f"[{self.status_code}] {self.message}")
        else:
            parts.append(self.message)
        if self.request_id:
            parts.append(f"(request_id={self.request_id})")
        return " ".join(parts)


class AuthError(VectorGovError):
    """Erro de autenticação (API key inválida ou expirada)."""

    def __init__(
        self,
        message: str = "API key inválida ou expirada",
        request_id: Optional[str] = None,
    ):
        super().__init__(message, status_code=401, request_id=request_id)


class RateLimitError(VectorGovError):
    """Rate limit excedido."""

    def __init__(
        self,
        message: str = "Rate limit excedido",
        retry_after: Optional[int] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, status_code=429, request_id=request_id)
        self.retry_after = retry_after

    def __str__(self) -> str:
        base = super().__str__()
        if self.retry_after:
            return f"{base}. Tente novamente em {self.retry_after} segundos."
        return base


class ValidationError(VectorGovError):
    """Erro de validação de parâmetros."""

    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, status_code=400, request_id=request_id)
        self.field = field


class TierError(VectorGovError):
    """Tier do cliente não inclui o recurso solicitado (ex: smart-search requer Premium)."""

    def __init__(
        self,
        message: str = "Recurso não disponível no seu plano atual",
        upgrade_url: Optional[str] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message, status_code=403, request_id=request_id)
        self.upgrade_url = upgrade_url

    def __str__(self) -> str:
        base = super().__str__()
        if self.upgrade_url:
            return f"{base}. Upgrade: {self.upgrade_url}"
        return base


class ServerError(VectorGovError):
    """Erro interno do servidor."""

    def __init__(
        self,
        message: str = "Erro interno do servidor",
        request_id: Optional[str] = None,
    ):
        super().__init__(message, status_code=500, request_id=request_id)


class ConnectionError(VectorGovError):
    """Erro de conexão com o servidor."""

    def __init__(
        self,
        message: str = "Não foi possível conectar ao servidor",
        request_id: Optional[str] = None,
    ):
        super().__init__(message, request_id=request_id)


class TimeoutError(VectorGovError):
    """Timeout na requisição."""

    def __init__(
        self,
        message: str = "A requisição excedeu o tempo limite",
        request_id: Optional[str] = None,
    ):
        super().__init__(message, request_id=request_id)
