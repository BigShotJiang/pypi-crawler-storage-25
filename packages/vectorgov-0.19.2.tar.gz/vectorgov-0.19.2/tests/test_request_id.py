"""Testes de request_id — SPEC-REQUEST-ID-UNIFICATION (v0.18.0).

Cobre:

- Campo ``request_id`` existe em todos os Result types com default vazio.
- Captura via body JSON do backend.
- Fallback via header ``X-Request-ID`` quando o body não traz o campo.
- Precedência: body > header.
- Exceções (``VectorGovError`` e subclasses) expõem ``request_id``.
- HTTPClient propaga ``request_id`` ao gerar exceções.
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from vectorgov import VectorGov
from vectorgov._http import HTTPClient
from vectorgov.exceptions import (
    AuthError,
    RateLimitError,
    TierError,
    ValidationError,
    VectorGovError,
)
from vectorgov.models import (
    CanonicalResult,
    FilesystemResult,
    GrepResult,
    HybridResult,
    LookupResult,
    MergedResult,
    SearchResult,
    SmartSearchResult,
)


# =============================================================================
# 1. Campo request_id existe em todos os Result types
# =============================================================================


class TestRequestIdFieldExists:
    """Todos os Result types devem aceitar ``request_id`` e default ``""``."""

    def test_search_result(self):
        r = SearchResult(hits=[], request_id="abc")
        assert r.request_id == "abc"
        assert SearchResult(hits=[]).request_id == ""

    def test_smart_search_result(self):
        r = SmartSearchResult(hits=[], request_id="sms-1")
        assert r.request_id == "sms-1"
        assert SmartSearchResult(hits=[]).request_id == ""

    def test_hybrid_result(self):
        r = HybridResult(query="q", hits=[], request_id="hyb-1")
        assert r.request_id == "hyb-1"
        assert HybridResult(query="q", hits=[]).request_id == ""

    def test_lookup_result(self):
        r = LookupResult(query="q", request_id="lkp-1")
        assert r.request_id == "lkp-1"
        assert LookupResult(query="q").request_id == ""

    def test_grep_result(self):
        r = GrepResult(
            matches=[],
            total=0,
            query="q",
            latency_ms=0,
            files_searched=0,
            request_id="grp-1",
        )
        assert r.request_id == "grp-1"
        # Default
        r2 = GrepResult(
            matches=[], total=0, query="q", latency_ms=0, files_searched=0,
        )
        assert r2.request_id == ""

    def test_filesystem_result(self):
        r = FilesystemResult(
            results=[],
            total=0,
            query="q",
            mode_used="auto",
            latency_ms=0,
            documents_searched=0,
            request_id="fs-1",
        )
        assert r.request_id == "fs-1"

    def test_merged_result(self):
        r = MergedResult(
            results=[],
            total=0,
            query="q",
            token_total=0,
            token_budget=0,
            hybrid_count=0,
            filesystem_count=0,
            mutual_count=0,
            latency_ms=0,
            request_id="mgd-1",
        )
        assert r.request_id == "mgd-1"

    def test_canonical_result(self):
        r = CanonicalResult(
            document_id="D",
            text="t",
            token_count=0,
            char_count=0,
            request_id="cn-1",
        )
        assert r.request_id == "cn-1"
        assert CanonicalResult(
            document_id="D", text="t", token_count=0, char_count=0,
        ).request_id == ""


# =============================================================================
# 2. Parsers de client.py propagam request_id do body
# =============================================================================


def _make_client():
    """Cria VectorGov sem passar pelo __init__ (parsers não usam self)."""
    from vectorgov.client import VectorGov as VG

    return VG.__new__(VG)


class TestParsersPropagateRequestId:
    """Os parsers em client.py devem copiar request_id do response para o Result."""

    def test_search_parser_captures_request_id(self):
        client = _make_client()
        response = {
            "hits": [],
            "total": 0,
            "latency_ms": 100,
            "cached": False,
            "query_id": "qid-123",
            "request_id": "a" * 32,
        }
        result = client._parse_search_response(
            query="teste", response=response, mode="balanced",
        )
        assert result.request_id == "a" * 32
        # query_id continua funcionando para compat
        assert result.query_id == "qid-123"

    def test_search_parser_empty_request_id_when_missing(self):
        client = _make_client()
        response = {"hits": [], "total": 0}
        result = client._parse_search_response(
            query="teste", response=response, mode="balanced",
        )
        assert result.request_id == ""

    def test_hybrid_parser_captures_request_id(self):
        client = _make_client()
        response = {
            "hits": [],
            "graph_expansion": [],
            "stats": {},
            "request_id": "b" * 32,
        }
        result = client._parse_hybrid_response(query="q", response=response)
        assert result.request_id == "b" * 32

    def test_lookup_parser_captures_request_id(self):
        client = _make_client()
        response = {
            "status": "not_found",
            "elapsed_ms": 50.0,
            "request_id": "c" * 32,
        }
        result = client._parse_lookup_response(reference="x", response=response)
        assert result.request_id == "c" * 32


# =============================================================================
# 3. HTTPClient — fallback do header X-Request-ID
# =============================================================================


def _make_mock_response(
    status: int,
    body: dict | str,
    request_id_header: str | None = None,
):
    """Cria mock de http.client.HTTPResponse."""
    mock_resp = MagicMock()
    mock_resp.status = status
    body_str = json.dumps(body) if isinstance(body, dict) else body
    mock_resp.read.return_value = body_str.encode("utf-8")

    def getheader(name, default=None):
        if name == "X-Request-ID":
            return request_id_header
        return default

    mock_resp.getheader.side_effect = getheader
    return mock_resp


class TestHttpClientHeaderFallback:
    """_http.py deve capturar X-Request-ID quando o body não traz o campo."""

    def _make_http(self):
        http = HTTPClient(base_url="https://api.test", api_key="vg_test")
        return http

    def test_body_has_request_id(self):
        """Quando o body já tem request_id, não tocar nele (body wins)."""
        http = self._make_http()

        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = _make_mock_response(
            status=200,
            body={"ok": True, "request_id": "body-id-xyz"},
            request_id_header="header-id-abc",
        )
        http._conn = mock_conn

        result = http.request("POST", "/x", data={"q": "test"})
        assert result["request_id"] == "body-id-xyz"  # body prevalece

    def test_body_missing_request_id_uses_header(self):
        """Fallback: quando body não tem, usar header X-Request-ID."""
        http = self._make_http()

        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = _make_mock_response(
            status=200,
            body={"ok": True},  # SEM request_id
            request_id_header="header-fallback-123",
        )
        http._conn = mock_conn

        result = http.request("POST", "/x", data={"q": "test"})
        assert result["request_id"] == "header-fallback-123"

    def test_no_request_id_anywhere(self):
        """Quando nem body nem header têm, não injeta nada (campo ausente)."""
        http = self._make_http()

        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = _make_mock_response(
            status=200,
            body={"ok": True},
            request_id_header=None,
        )
        http._conn = mock_conn

        result = http.request("POST", "/x", data={"q": "test"})
        assert "request_id" not in result or result.get("request_id") in ("", None)

    def test_body_empty_string_request_id_fallback_to_header(self):
        """request_id = "" no body é tratado como ausente e usa header."""
        http = self._make_http()

        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = _make_mock_response(
            status=200,
            body={"ok": True, "request_id": ""},
            request_id_header="header-win-456",
        )
        http._conn = mock_conn

        result = http.request("POST", "/x", data={"q": "test"})
        # Lógica do _http: `if not parsed.get("request_id")` → "" é falsy
        assert result["request_id"] == "header-win-456"


# =============================================================================
# 4. Exceptions expõem request_id
# =============================================================================


class TestExceptionsExposeRequestId:
    """Todas as exceções do SDK devem aceitar e expor request_id."""

    def test_base_error_request_id(self):
        err = VectorGovError("boom", status_code=500, request_id="err-1")
        assert err.request_id == "err-1"
        assert err.status_code == 500

    def test_base_error_request_id_default_none(self):
        err = VectorGovError("boom")
        assert err.request_id is None

    def test_base_error_str_includes_request_id(self):
        err = VectorGovError("boom", status_code=500, request_id="rid-xyz")
        s = str(err)
        assert "rid-xyz" in s
        assert "500" in s

    def test_auth_error_request_id(self):
        err = AuthError("bad key", request_id="auth-1")
        assert err.request_id == "auth-1"

    def test_rate_limit_error_request_id(self):
        err = RateLimitError(retry_after=10, request_id="rl-1")
        assert err.request_id == "rl-1"
        assert err.retry_after == 10

    def test_validation_error_request_id(self):
        err = ValidationError("bad field", field="query", request_id="val-1")
        assert err.request_id == "val-1"
        assert err.field == "query"

    def test_tier_error_request_id(self):
        err = TierError(upgrade_url="https://x", request_id="tier-1")
        assert err.request_id == "tier-1"


# =============================================================================
# 5. HTTPClient propaga request_id para exceções em erros HTTP
# =============================================================================


class TestHttpClientExceptionRequestId:
    """Erros HTTP devem incluir request_id na exceção (body > header)."""

    def _make_http(self):
        return HTTPClient(base_url="https://api.test", api_key="vg_test", max_retries=1)

    def test_400_error_body_request_id(self):
        http = self._make_http()
        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = _make_mock_response(
            status=400,
            body={"detail": "bad query", "request_id": "body-err-1"},
            request_id_header="header-err-2",
        )
        http._conn = mock_conn

        with pytest.raises(ValidationError) as exc_info:
            http.request("POST", "/x", data={"q": "test"})
        assert exc_info.value.request_id == "body-err-1"

    def test_401_error_header_fallback(self):
        http = self._make_http()
        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = _make_mock_response(
            status=401,
            body={"detail": "unauthorized"},  # sem request_id
            request_id_header="header-fall-1",
        )
        http._conn = mock_conn

        with pytest.raises(AuthError) as exc_info:
            http.request("POST", "/x", data={"q": "test"})
        assert exc_info.value.request_id == "header-fall-1"

    def test_500_error_request_id(self):
        http = self._make_http()
        mock_conn = MagicMock()
        mock_conn.getresponse.return_value = _make_mock_response(
            status=500,
            body={"detail": "internal"},
            request_id_header="server-err-99",
        )
        http._conn = mock_conn

        from vectorgov.exceptions import ServerError

        with pytest.raises(ServerError) as exc_info:
            http.request("POST", "/x", data={"q": "test"})
        assert exc_info.value.request_id == "server-err-99"


# =============================================================================
# 6. Duas chamadas consecutivas retornam request_ids diferentes
# =============================================================================


class TestUniqueRequestIds:
    """Chamadas diferentes devem expor request_ids distintos."""

    def test_two_calls_different_request_ids(self):
        http = HTTPClient(base_url="https://api.test", api_key="vg_test")

        responses = [
            _make_mock_response(200, {"ok": True, "request_id": "id-001"}),
            _make_mock_response(200, {"ok": True, "request_id": "id-002"}),
        ]

        mock_conn = MagicMock()
        mock_conn.getresponse.side_effect = responses
        http._conn = mock_conn

        r1 = http.request("POST", "/x", data={"q": "a"})
        r2 = http.request("POST", "/x", data={"q": "b"})

        assert r1["request_id"] == "id-001"
        assert r2["request_id"] == "id-002"
        assert r1["request_id"] != r2["request_id"]
