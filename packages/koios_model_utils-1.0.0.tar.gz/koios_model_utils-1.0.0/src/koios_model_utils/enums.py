"""String enums for Koios metadata values.

Every enum here is a :class:`enum.StrEnum` — members are real strings and
serialize transparently through ``json.dumps``, so users may pass either
the enum member or the raw string literal wherever metadata values are
expected.  The server consumes strings (case-insensitive for
normalization keys, exact-match for training keys), so both forms flow
through identically.

The string values match the names of the corresponding Django
``IntegerChoices`` members in
``koios-webapp-py/app/AiOpsInterface/apps/aiops/choices.py`` — renaming
a member on the server requires updating the matching member here (the
contract tests in ``tests/test_metadata.py`` pin this).
"""

from __future__ import annotations

from enum import StrEnum


class NormalizationType(StrEnum):
    """How a binding's value is mapped into / out of model space."""

    NONE = "none"
    MIN_MAX = "min_max"
    SYMMETRIC = "symmetric"
    Z_SCORE = "z_score"


class NormalizationSource(StrEnum):
    """Where normalization parameters come from at runtime."""

    # The tag's engineering range (range_min / range_max on the bound tag).
    TAG_RANGE = "tag_range"
    # Explicit ``custom_minimum`` / ``custom_maximum`` / ``custom_mean`` /
    # ``custom_std`` values embedded in the ONNX metadata.
    CUSTOM = "custom"


class ModelType(StrEnum):
    """How the predict engine applies the model's output to the bound tag.

    Maps to the server's ``OutputApplicationChoices``. The legacy
    ``POSITIONAL`` / ``VELOCITY`` aliases are still accepted by the
    server but should not be used in new code.
    """

    ABSOLUTE = "ABSOLUTE"
    RELATIVE = "RELATIVE"


class OutputMode(StrEnum):
    """Whether the model emits a continuous value or a categorical action."""

    CONTINUOUS = "CONTINUOUS"
    DISCRETE = "DISCRETE"


class Algorithm(StrEnum):
    """Stable-Baselines3 algorithm identifiers recognized by the exporter."""

    PPO = "PPO"
    SAC = "SAC"
    TD3 = "TD3"
    A2C = "A2C"
    DQN = "DQN"
