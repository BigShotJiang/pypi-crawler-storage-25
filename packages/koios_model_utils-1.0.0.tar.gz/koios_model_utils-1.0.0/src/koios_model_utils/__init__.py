"""koios-model-utils — utilities for exporting and annotating ONNX models for the Koios IoT platform."""

__version__ = "1.0.0"

from koios_model_utils.enums import (
    Algorithm,
    ModelType,
    NormalizationSource,
    NormalizationType,
    OutputMode,
)
from koios_model_utils.metadata import (
    InputBinding,
    OutputBinding,
    TrainingMeta,
    build_input_bindings,
    build_output_bindings,
    embed_koios_metadata,
)

# SB3-dependent exports — only available with koios-model-utils[sb3]
try:
    from koios_model_utils.callbacks import (
        ObsRangeCallback,
        VecNormalizeSyncCallback,
    )
    from koios_model_utils.export import (
        OnnxActorWrapper,
        OnnxDQNWrapper,
        detect_algorithm,
        export_onnx,
        load_vec_normalize_stats,
    )
except ImportError:
    pass

__all__ = [
    # enums (always available)
    "Algorithm",
    "ModelType",
    "NormalizationSource",
    "NormalizationType",
    "OutputMode",
    # metadata (always available)
    "InputBinding",
    "OutputBinding",
    "TrainingMeta",
    "embed_koios_metadata",
    "build_input_bindings",
    "build_output_bindings",
    # export (requires sb3 extra)
    "export_onnx",
    "detect_algorithm",
    "load_vec_normalize_stats",
    "OnnxActorWrapper",
    "OnnxDQNWrapper",
    # callbacks (requires sb3 extra)
    "ObsRangeCallback",
    "VecNormalizeSyncCallback",
]
