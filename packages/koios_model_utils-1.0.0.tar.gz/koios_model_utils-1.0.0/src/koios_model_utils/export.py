"""ONNX export — ``koios-export runs/tank_level_ppo/best_model.zip``."""

from __future__ import annotations

import argparse
import json
import pickle
import sys
import zipfile
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

from koios_model_utils.metadata import (
    InputBinding,
    OutputBinding,
    TrainingMeta,
    build_input_bindings,
    build_output_bindings,
    embed_koios_metadata,
)

# ---------------------------------------------------------------------------
# Algorithm detection
# ---------------------------------------------------------------------------

_ALGO_CLASS_PREFIXES = {
    "stable_baselines3.ppo": "PPO",
    "stable_baselines3.sac": "SAC",
    "stable_baselines3.td3": "TD3",
    "stable_baselines3.a2c": "A2C",
    "stable_baselines3.dqn": "DQN",
}


def detect_algorithm(model_path: str | Path) -> str:
    """Detect the SB3 algorithm from a saved .zip model.

    SB3 stores a ``data`` file inside the zip containing pickled metadata
    that includes the class path.  We read this without unpickling by
    scanning for the class prefix strings.
    """
    model_path = Path(model_path)
    with zipfile.ZipFile(model_path, "r") as zf:
        if "data" in zf.namelist():
            raw = zf.read("data")
            text = raw.decode("latin-1")  # binary-safe decode for scanning
            for prefix, algo_name in _ALGO_CLASS_PREFIXES.items():
                if prefix in text:
                    return algo_name

    # Fallback: try to infer from the directory or filename
    name_lower = model_path.stem.lower()
    for algo in ("sac", "td3", "a2c", "ppo"):
        if algo in name_lower:
            return algo.upper()

    return "PPO"  # Default assumption


# ---------------------------------------------------------------------------
# ONNX actor wrappers (require torch — imported lazily)
# ---------------------------------------------------------------------------


class OnnxActorWrapper(nn.Module):
    """Wraps an SB3 policy's actor-only forward path for ONNX export.

    Extracts the deterministic actor from both on-policy (PPO, A2C) and
    off-policy (SAC, TD3) architectures:

      - PPO/A2C: features_extractor -> mlp_extractor.policy_net -> action_net -> clamp
      - SAC:     features_extractor -> actor.latent_pi -> actor.mu -> tanh -> clamp
      - TD3:     features_extractor -> actor.latent_pi -> actor.mu -> clamp

    SAC uses a SquashedDiagGaussianDistribution — deterministic actions are
    ``tanh(mu)``, not raw ``mu``.  When *squash_output* is True, ``tanh`` is
    applied before clamping to match SB3's ``predict(deterministic=True)``.

    Normalization and denormalization are NOT baked in — the Koios predict
    engine applies them based on embedded ``koios.bindings`` metadata.

    Forward: obs [1, obs_depth, num_features] -> actions [1, num_actions]
    """

    def __init__(
        self,
        policy: nn.Module,
        action_low: torch.Tensor,
        action_high: torch.Tensor,
        *,
        squash_output: bool = False,
    ) -> None:
        super().__init__()
        self.register_buffer("action_low", action_low)
        self.register_buffer("action_high", action_high)
        self.squash_output = squash_output

        # Detect architecture: SAC/TD3 have policy.actor, PPO/A2C have mlp_extractor
        if hasattr(policy, "actor") and hasattr(policy.actor, "latent_pi"):
            # SAC / TD3: everything lives on the actor sub-module
            self.features_extractor = policy.actor.features_extractor
            self.hidden_net = policy.actor.latent_pi
            self.output_net = policy.actor.mu
        else:
            # PPO / A2C: features_extractor on policy, actor split across mlp_extractor + action_net
            self.features_extractor = policy.features_extractor
            self.hidden_net = policy.mlp_extractor.policy_net
            self.output_net = policy.action_net

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        features = self.features_extractor(obs)
        latent = self.hidden_net(features)
        actions = self.output_net(latent)
        if self.squash_output:
            actions = torch.tanh(actions)
        actions = torch.clamp(actions, self.action_low, self.action_high)
        return actions


class OnnxDQNWrapper(nn.Module):
    """Wraps DQN's Q-network for ONNX export.

    Outputs raw Q-values ``[1, num_actions]``.  The Koios predict engine
    applies ``argmax`` and ``action_map`` lookup.

    Forward: obs ``[1, obs_depth, num_features]`` -> q_values ``[1, num_actions]``
    """

    def __init__(self, policy: nn.Module) -> None:
        super().__init__()
        self.features_extractor = policy.q_net.features_extractor
        self.q_net = policy.q_net.q_net  # The actual Q-value MLP

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        features = self.features_extractor(obs)
        return self.q_net(features)


# ---------------------------------------------------------------------------
# VecNormalize stats loader
# ---------------------------------------------------------------------------


def load_vec_normalize_stats(
    stats_path: str | Path,
) -> tuple[np.ndarray, np.ndarray, float] | None:
    """Load observation mean/var from a saved VecNormalize pickle.

    Returns (mean, var, clip_obs) or None if loading fails.
    """
    try:
        with open(stats_path, "rb") as f:
            vec_normalize = pickle.load(f)
        mean = np.array(vec_normalize.obs_rms.mean, dtype=np.float32)
        var = np.array(vec_normalize.obs_rms.var, dtype=np.float32)
        clip_obs = float(getattr(vec_normalize, "clip_obs", 10.0))
        return mean, var, clip_obs
    except Exception as exc:
        print(f"WARNING: Could not load VecNormalize stats from {stats_path}: {exc}")
        return None


# ---------------------------------------------------------------------------
# Export function
# ---------------------------------------------------------------------------


def export_onnx(
    model_path: str | Path,
    output_path: str | Path | None = None,
    *,
    inputs: list[InputBinding] | None = None,
    outputs: list[OutputBinding] | None = None,
    training: TrainingMeta | None = None,
    opset_version: int = 18,
    verify: bool = True,
    num_verify_samples: int = 100,
) -> Path:
    """Export an SB3 model to ONNX for the Koios predict engine.

    The exported ONNX contains only the raw actor network — no observation
    normalization or output denormalization is baked in.  Instead, those
    parameters are embedded in ``koios.bindings`` metadata so the predict
    engine can apply them per-binding:

    - **Inputs**: Z-Score normalization from VecNormalize running stats.
    - **Outputs**: Symmetric denormalization from [-1, 1] to action ranges.

    Parameters
    ----------
    model_path:
        Path to an SB3 ``.zip`` model file.
    output_path:
        Destination ``.onnx`` file.  Defaults to the same directory and stem
        as *model_path* with ``.onnx`` extension.
    inputs:
        Optional input bindings for Koios metadata embedding.
    outputs:
        Optional output bindings for Koios metadata embedding.
    training:
        Optional training metadata for Koios metadata embedding.
    opset_version:
        ONNX opset version (default 18).
    verify:
        If True, validate the exported ONNX and compare outputs with SB3.
    num_verify_samples:
        Number of random observations to compare during verification.

    Returns
    -------
    Path to the exported ``.onnx`` file.
    """
    import onnx
    import stable_baselines3 as sb3

    model_path = Path(model_path)
    if output_path is None:
        output_path = model_path.with_suffix(".onnx")
    else:
        output_path = Path(output_path)

    # ------------------------------------------------------------------
    # 1. Load SB3 model
    # ------------------------------------------------------------------
    algo_name = detect_algorithm(model_path)
    algo_map = {"PPO": sb3.PPO, "SAC": sb3.SAC, "TD3": sb3.TD3, "A2C": sb3.A2C, "DQN": sb3.DQN}
    algo_cls = algo_map[algo_name]
    model = algo_cls.load(str(model_path), device="cpu")
    print(f"Loaded {algo_name} model from {model_path}")

    policy = model.policy
    policy.eval()

    obs_space = model.observation_space
    act_space = model.action_space
    is_dqn = algo_name == "DQN"

    # ------------------------------------------------------------------
    # 2. Load observation normalization stats (if VecNormalize was used)
    # ------------------------------------------------------------------
    obs_stats_np: tuple[np.ndarray, np.ndarray, float, float] | None = None
    obs_clip: float = 10.0
    obs_epsilon: float = 1e-8

    stats_path = model_path.parent / "vec_normalize.pkl"
    if stats_path.exists():
        stats = load_vec_normalize_stats(stats_path)
        if stats is not None:
            mean_np, var_np, obs_clip = stats
            obs_stats_np = (mean_np, var_np, obs_clip, obs_epsilon)
            print(f"Loaded VecNormalize stats from {stats_path} (will embed in metadata)")
            print(f"  obs shape: {mean_np.shape}, clip: {obs_clip}")

    # ------------------------------------------------------------------
    # 3. Create ONNX wrapper (raw actor — no baked normalization)
    # ------------------------------------------------------------------
    if is_dqn:
        wrapper = OnnxDQNWrapper(policy)
        output_names = ["q_values"]
    else:
        action_low = torch.tensor(act_space.low, dtype=torch.float32)
        action_high = torch.tensor(act_space.high, dtype=torch.float32)

        squash = algo_name == "SAC"

        wrapper = OnnxActorWrapper(
            policy,
            action_low,
            action_high,
            squash_output=squash,
        )
        output_names = ["actions"]
    wrapper.eval()

    # ------------------------------------------------------------------
    # 4. Build dummy input with static shape [1, obs_depth, num_features]
    # ------------------------------------------------------------------
    obs_shape = obs_space.shape
    dummy_input = torch.randn(1, *obs_shape, dtype=torch.float32)

    # ------------------------------------------------------------------
    # 5. Export to ONNX
    # ------------------------------------------------------------------
    torch.onnx.export(
        wrapper,
        (dummy_input,),
        str(output_path),
        opset_version=opset_version,
        input_names=["observations"],
        output_names=output_names,
        dynamic_axes=None,
    )
    print(f"Exported ONNX model to {output_path}")

    # ------------------------------------------------------------------
    # 5b. Consolidate external data into single file
    # ------------------------------------------------------------------
    data_path = output_path.parent / (output_path.name + ".data")
    if data_path.exists():
        onnx_model = onnx.load(str(output_path), load_external_data=True)
        for init in onnx_model.graph.initializer:
            if init.data_location == onnx.TensorProto.EXTERNAL:
                init.data_location = onnx.TensorProto.DEFAULT
        onnx.save_model(onnx_model, str(output_path))
        data_path.unlink()
        print("Consolidated external data into single .onnx file")

    # ------------------------------------------------------------------
    # 6. Validate with onnx checker
    # ------------------------------------------------------------------
    onnx_model = onnx.load(str(output_path))
    onnx.checker.check_model(onnx_model)
    print("ONNX model passes onnx.checker validation")

    # ------------------------------------------------------------------
    # 6b. Embed Koios training metadata
    # ------------------------------------------------------------------
    if inputs is not None and outputs is not None:
        embed_koios_metadata(
            onnx_model,
            inputs=inputs,
            outputs=outputs,
            training=training,
        )
        onnx.save_model(onnx_model, str(output_path))

    # ------------------------------------------------------------------
    # 7. Verify outputs match SB3
    # ------------------------------------------------------------------
    if verify:
        if is_dqn:
            _verify_dqn_outputs(policy, wrapper, obs_space, num_verify_samples)
        else:
            _verify_outputs(
                model,
                wrapper,
                obs_space,
                num_verify_samples,
                obs_mean_np=obs_stats_np[0] if obs_stats_np else None,
                obs_var_np=obs_stats_np[1] if obs_stats_np else None,
                obs_clip=obs_clip,
                obs_epsilon=obs_epsilon,
            )

    # ------------------------------------------------------------------
    # 8. Print summary
    # ------------------------------------------------------------------
    input_shape = [d.dim_value for d in onnx_model.graph.input[0].type.tensor_type.shape.dim]
    output_shape = [d.dim_value for d in onnx_model.graph.output[0].type.tensor_type.shape.dim]

    print(f"\n{'=' * 50}")
    print("ONNX Export Summary")
    print(f"{'=' * 50}")
    print(f"Algorithm:    {algo_name}")
    print("Input name:   observations")
    print(f"Input shape:  {input_shape}")
    print(f"Output name:  {output_names[0]}")
    print(f"Output shape: {output_shape}")
    print(f"Opset:        {opset_version}")
    if obs_stats_np is not None:
        print("Obs normalization: Z-Score (Koios-applied)")
    elif inputs is not None and any(b.normalization_type == "min_max" for b in inputs):
        print("Obs normalization: Min/Max (Koios-applied)")
    else:
        print("Obs normalization: none")
    if inputs is not None:
        print("Output denorm:     Symmetric (Koios-applied)")

    if input_shape and len(input_shape) == 3:
        print("\nPredict Engine mapping:")
        print(f"  depth_samples = {input_shape[1]}")
        print(f"  num_features  = {input_shape[2]}")
        print(f"  num_outputs   = {output_shape[1] if len(output_shape) > 1 else 1}")

    if outputs is not None:
        print("\nAction node mapping:")
        for i, out in enumerate(outputs):
            print(f"  binding_order={i + 1} -> {out.name}")

    print(f"{'=' * 50}")
    return output_path


# ---------------------------------------------------------------------------
# Verification helpers
# ---------------------------------------------------------------------------


def _verify_outputs(
    sb3_model: object,
    wrapper: object,
    obs_space: object,
    num_samples: int,
    obs_mean_np: np.ndarray | None = None,
    obs_var_np: np.ndarray | None = None,
    obs_clip: float = 10.0,
    obs_epsilon: float = 1e-8,
) -> None:
    """Compare SB3 predict() with ONNX wrapper on random observations."""
    max_action_diff = 0.0
    rng = np.random.default_rng(42)

    low = np.where(np.isfinite(obs_space.low), obs_space.low, -1.0)  # type: ignore[union-attr]
    high = np.where(np.isfinite(obs_space.high), obs_space.high, 1.0)  # type: ignore[union-attr]

    for _ in range(num_samples):
        raw_obs = rng.uniform(low, high).astype(np.float32)

        if obs_mean_np is not None and obs_var_np is not None:
            norm_obs = (raw_obs - obs_mean_np) / np.sqrt(obs_var_np + obs_epsilon)
            norm_obs = np.clip(norm_obs, -obs_clip, obs_clip)
        else:
            norm_obs = raw_obs

        sb3_action, _ = sb3_model.predict(norm_obs, deterministic=True)  # type: ignore[union-attr]

        obs_tensor = torch.from_numpy(norm_obs).unsqueeze(0)
        with torch.no_grad():
            onnx_action = wrapper(obs_tensor).numpy().squeeze(0)

        diff = np.max(np.abs(sb3_action - onnx_action))
        max_action_diff = max(max_action_diff, diff)

    print(f"Verification: max action diff across {num_samples} samples = {max_action_diff:.2e}")
    if max_action_diff > 1e-5:
        print(f"WARNING: max action diff {max_action_diff:.2e} exceeds 1e-5 threshold")
    else:
        print("Action verification PASSED (max diff < 1e-5)")


def _verify_dqn_outputs(
    policy: object,
    wrapper: object,
    obs_space: object,
    num_samples: int,
) -> None:
    """Compare DQN Q-network outputs with the ONNX wrapper on random observations."""
    max_diff = 0.0
    rng = np.random.default_rng(42)

    low = np.where(np.isfinite(obs_space.low), obs_space.low, -1.0)  # type: ignore[union-attr]
    high = np.where(np.isfinite(obs_space.high), obs_space.high, 1.0)  # type: ignore[union-attr]

    for _ in range(num_samples):
        raw_obs = rng.uniform(low, high).astype(np.float32)
        obs_tensor = torch.from_numpy(raw_obs).unsqueeze(0)

        with torch.no_grad():
            sb3_qvals = policy.q_net(obs_tensor)  # type: ignore[union-attr]
            onnx_qvals = wrapper(obs_tensor)

        diff = float(torch.max(torch.abs(sb3_qvals - onnx_qvals)).item())
        max_diff = max(max_diff, diff)

    print(f"Verification: max Q-value diff across {num_samples} samples = {max_diff:.2e}")
    if max_diff > 1e-5:
        print(f"WARNING: max Q-value diff {max_diff:.2e} exceeds 1e-5 threshold")
    else:
        print("Q-value verification PASSED (max diff < 1e-5)")


# ---------------------------------------------------------------------------
# CLI config bridge
# ---------------------------------------------------------------------------


def _bindings_from_config(
    config: object,
    model_path: Path,
    obs_stats: tuple[np.ndarray, np.ndarray, float, float] | None = None,
    obs_norm_minmax: tuple[np.ndarray, np.ndarray] | None = None,
    obs_range: tuple[np.ndarray, np.ndarray] | None = None,
) -> tuple[list[InputBinding], list[OutputBinding], TrainingMeta]:
    """Build bindings from a sim_training ExperimentConfig (lazy import).

    This bridges the old --config CLI interface.  It requires
    koios-scenario-simulator to be installed.
    """
    from sim_training.config import ExperimentConfig
    from sim_training.env import make_env

    assert isinstance(config, ExperimentConfig)

    env = make_env(config)
    unwrapped = env.unwrapped

    # Build description lookup from scenario
    probe = unwrapped._scenario_cls(rng=np.random.default_rng(0))
    node_specs = probe.define_nodes()
    desc_map = {s.name: s.description for s in node_specs}

    is_discrete = bool(getattr(config, "discrete_actions", None))

    inputs = build_input_bindings(
        list(unwrapped._obs_nodes),
        descriptions=desc_map,
        obs_stats=obs_stats,
        obs_norm_minmax=obs_norm_minmax,
        obs_range=obs_range,
    )
    outputs = build_output_bindings(
        list(unwrapped._action_nodes),
        unwrapped._action_ranges,
        descriptions=desc_map,
        discrete=is_discrete,
    )

    # Detect algorithm from best_model if available
    algo = config.algorithm
    best_model = config.run_dir / "best_model.zip"
    if best_model.exists():
        algo = detect_algorithm(best_model)

    training = TrainingMeta(
        scenario_name=config.scenario_name,
        algorithm=algo,
        obs_depth=config.obs_depth,
        sample_rate=config.dt,
        model_type="POSITIONAL",
    )
    if is_discrete:
        training.output_mode = "DISCRETE"
        action_map = getattr(config, "action_map", None)
        if action_map:
            training.action_map = action_map

    env.close()
    return inputs, outputs, training


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Export an SB3 model to ONNX for the Koios predict engine."
    )
    parser.add_argument(
        "model",
        help="Path to saved SB3 model .zip file.",
    )
    parser.add_argument(
        "--output",
        "-o",
        help="Output .onnx file path. Defaults to same directory with .onnx extension.",
    )
    parser.add_argument(
        "--config",
        "-c",
        help="Path to config YAML for action node metadata.",
    )
    parser.add_argument(
        "--opset",
        type=int,
        default=18,
        help="ONNX opset version (default: 18).",
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="Skip output verification against SB3 predict.",
    )
    parser.add_argument(
        "--verify-samples",
        type=int,
        default=100,
        help="Number of random samples for verification (default: 100).",
    )
    args = parser.parse_args()

    model_path = Path(args.model)
    if not model_path.exists():
        model_path = model_path.with_suffix(".zip")
    if not model_path.exists():
        print(f"Model not found: {args.model}")
        sys.exit(1)

    # Auto-detect config from model's directory if not specified
    config_path = args.config
    if config_path is None:
        candidate = model_path.parent / "config.yaml"
        if candidate.exists():
            config_path = str(candidate)

    # Build bindings from config (requires koios-scenario-simulator)
    inputs_list: list[InputBinding] | None = None
    outputs_list: list[OutputBinding] | None = None
    training_meta: TrainingMeta | None = None

    if config_path:
        try:
            from sim_training.config import load_config as _load_config

            config = _load_config(config_path)

            # Load VecNormalize stats (z_score)
            obs_stats_np: tuple[np.ndarray, np.ndarray, float, float] | None = None
            stats_file = model_path.parent / "vec_normalize.pkl"
            if stats_file.exists():
                stats = load_vec_normalize_stats(stats_file)
                if stats is not None:
                    mean_np, var_np, clip = stats
                    obs_stats_np = (mean_np, var_np, clip, 1e-8)

            # Load min_max normalization bounds
            obs_norm_minmax_data: tuple[np.ndarray, np.ndarray] | None = None
            minmax_file = model_path.parent / "minmax_normalize.json"
            if minmax_file.exists():
                with open(minmax_file) as f:
                    minmax_json = json.load(f)
                obs_norm_minmax_data = (
                    np.array(minmax_json["obs_mins"], dtype=np.float32),
                    np.array(minmax_json["obs_maxs"], dtype=np.float32),
                )
                print(f"Loaded min_max normalization from {minmax_file}")

            # Load observation ranges (failure bounds)
            obs_range_data: tuple[np.ndarray, np.ndarray] | None = None
            obs_range_path = model_path.parent / "obs_range.json"
            if obs_range_path.exists():
                with open(obs_range_path) as f:
                    range_json = json.load(f)
                obs_range_data = (
                    np.array(range_json["obs_min"], dtype=np.float32),
                    np.array(range_json["obs_max"], dtype=np.float32),
                )
                print(f"Loaded observation ranges from {obs_range_path}")

            inputs_list, outputs_list, training_meta = _bindings_from_config(
                config,
                model_path,
                obs_stats=obs_stats_np,
                obs_norm_minmax=obs_norm_minmax_data,
                obs_range=obs_range_data,
            )
        except ImportError:
            print("WARNING: sim_training not available — skipping metadata embedding.")
            print("Pass explicit bindings via the Python API instead.")

    try:
        export_onnx(
            model_path,
            output_path=args.output,
            inputs=inputs_list,
            outputs=outputs_list,
            training=training_meta,
            opset_version=args.opset,
            verify=not args.no_verify,
            num_verify_samples=args.verify_samples,
        )
    except KeyboardInterrupt:
        print("\nExport interrupted.")
        sys.exit(1)


if __name__ == "__main__":
    main()
