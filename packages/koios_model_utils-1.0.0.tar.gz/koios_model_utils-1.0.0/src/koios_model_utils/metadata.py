"""Koios ONNX metadata embedding — no torch/SB3 dependency."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime

import numpy as np
import onnx

from koios_model_utils.enums import (
    Algorithm,
    ModelType,
    NormalizationSource,
    NormalizationType,
    OutputMode,
)

# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class InputBinding:
    """Describes one input (observation) binding for the Koios predict engine."""

    name: str
    description: str = ""
    # Accepts a NormalizationType member or the raw string ("none", "min_max",
    # "symmetric", "z_score"). StrEnum members serialize transparently.
    normalization_type: NormalizationType | str = NormalizationType.NONE
    normalization_source: NormalizationSource | str | None = None
    custom_mean: float | None = None
    custom_std: float | None = None
    custom_minimum: float | None = None  # for min_max normalization
    custom_maximum: float | None = None  # for min_max normalization
    custom_failure: bool = False
    custom_failure_minimum: float | None = None
    custom_failure_maximum: float | None = None


@dataclass
class OutputBinding:
    """Describes one output (action) binding for the Koios predict engine."""

    name: str
    description: str = ""
    range_min: float | None = None
    range_max: float | None = None
    normalization_type: NormalizationType | str = NormalizationType.NONE
    normalization_source: NormalizationSource | str | None = None
    custom_minimum: float | None = None
    custom_maximum: float | None = None
    clamp_output: bool = False
    # Custom failure bounds — when True, the server uses the explicit
    # custom_failure_minimum/maximum values for failure detection instead
    # of deriving bounds from the normalization range.
    custom_failure: bool = False
    custom_failure_minimum: float | None = None
    custom_failure_maximum: float | None = None


@dataclass
class TrainingMeta:
    """Model-level training metadata for the Koios predict engine."""

    scenario_name: str = ""
    # Accepts an Algorithm member or a free-form string (custom training
    # pipelines can set this to anything; it's informational on the server).
    algorithm: Algorithm | str = ""
    obs_depth: int = 1
    sample_rate: float = 1.0
    # ABSOLUTE or RELATIVE. "POSITIONAL" / "VELOCITY" are accepted by the
    # server as backward-compat aliases but should not be used in new code.
    model_type: ModelType | str = ModelType.ABSOLUTE
    output_mode: OutputMode | str | None = None
    action_map: list[dict[str, object]] | None = None


# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------


def embed_koios_metadata(
    onnx_model: onnx.ModelProto,
    *,
    inputs: list[InputBinding],
    outputs: list[OutputBinding],
    training: TrainingMeta | None = None,
    output_denormalized: bool = False,
) -> None:
    """Embed ``koios.training`` and ``koios.bindings`` metadata into an ONNX model (in-place).

    Parameters
    ----------
    onnx_model:
        Loaded ONNX model proto (modified in-place).
    inputs:
        Input binding definitions (one per observation feature).
    outputs:
        Output binding definitions (one per action).
    training:
        Optional model-level training metadata.
    output_denormalized:
        Set True if the ONNX graph already emits physical values (i.e. the
        model's output is denormalized in-graph).  When True, the server
        configures outputs with ``normalization_type=NONE`` and uses the
        training action range as custom failure bounds.  Default False for
        standard SB3 exports whose outputs are still in normalized space.
    """
    # koios.training
    if training is None:
        training = TrainingMeta()

    training_meta: dict[str, object] = {
        "schema_version": 1,
        "scenario_name": training.scenario_name,
        "algorithm": training.algorithm,
        "obs_depth": training.obs_depth,
        "sample_rate": training.sample_rate,
        "model_type": training.model_type,
        "exported_at": datetime.now(UTC).isoformat(),
    }
    if training.output_mode is not None:
        training_meta["output_mode"] = training.output_mode
    if training.action_map is not None:
        training_meta["action_map"] = training.action_map

    # koios.bindings
    input_dicts = []
    for i, inp in enumerate(inputs):
        entry: dict[str, object] = {
            "binding_order": i + 1,
            "name": inp.name,
            "description": inp.description,
        }
        if inp.normalization_type != "none":
            entry["normalization_type"] = inp.normalization_type
            if inp.normalization_source is not None:
                entry["normalization_source"] = inp.normalization_source
            if inp.custom_mean is not None:
                entry["custom_mean"] = inp.custom_mean
            if inp.custom_std is not None:
                entry["custom_std"] = inp.custom_std
            if inp.custom_minimum is not None:
                entry["custom_minimum"] = inp.custom_minimum
            if inp.custom_maximum is not None:
                entry["custom_maximum"] = inp.custom_maximum
        if inp.custom_failure:
            # The server reads `failure_range_mode` (string or int from
            # FailureRangeModeChoices) to decide whether to use the custom
            # bounds. Without this key it defaults to NORMALIZATION_RANGE and
            # silently ignores custom_failure_minimum/maximum — writing
            # "CUSTOM" here flips it into the right mode.
            entry["failure_range_mode"] = "CUSTOM"
            if inp.custom_failure_minimum is not None:
                entry["custom_failure_minimum"] = inp.custom_failure_minimum
            if inp.custom_failure_maximum is not None:
                entry["custom_failure_maximum"] = inp.custom_failure_maximum
        input_dicts.append(entry)

    output_dicts = []
    for i, out in enumerate(outputs):
        entry = {
            "binding_order": i + 1,
            "name": out.name,
            "description": out.description,
            "normalization_type": out.normalization_type,
        }
        if out.range_min is not None:
            entry["range_min"] = out.range_min
        if out.range_max is not None:
            entry["range_max"] = out.range_max
        if out.normalization_source is not None:
            entry["normalization_source"] = out.normalization_source
        if out.custom_minimum is not None:
            entry["custom_minimum"] = out.custom_minimum
        if out.custom_maximum is not None:
            entry["custom_maximum"] = out.custom_maximum
        if out.clamp_output:
            entry["clamp_output"] = True
        if out.custom_failure:
            # See input handler — `failure_range_mode=CUSTOM` is the key the
            # server actually reads to switch on custom failure bounds.
            entry["failure_range_mode"] = "CUSTOM"
            if out.custom_failure_minimum is not None:
                entry["custom_failure_minimum"] = out.custom_failure_minimum
            if out.custom_failure_maximum is not None:
                entry["custom_failure_maximum"] = out.custom_failure_maximum
        output_dicts.append(entry)

    bindings_meta: dict[str, object] = {
        "schema_version": 1,
        "output_denormalized": output_denormalized,
        "inputs": input_dicts,
        "outputs": output_dicts,
    }

    onnx_model.metadata_props.append(
        onnx.StringStringEntryProto(key="koios.training", value=json.dumps(training_meta))
    )
    onnx_model.metadata_props.append(
        onnx.StringStringEntryProto(key="koios.bindings", value=json.dumps(bindings_meta))
    )

    print(f"Embedded koios.training metadata ({len(inputs)} inputs, {len(outputs)} outputs)")


# ---------------------------------------------------------------------------
# Convenience builders
# ---------------------------------------------------------------------------


def build_input_bindings(
    obs_nodes: list[str],
    *,
    descriptions: dict[str, str] | None = None,
    obs_stats: tuple[np.ndarray, np.ndarray, float, float] | None = None,
    obs_norm_minmax: tuple[np.ndarray, np.ndarray] | None = None,
    obs_range: tuple[np.ndarray, np.ndarray] | None = None,
) -> list[InputBinding]:
    """Build InputBinding list from node names + optional normalization stats.

    Parameters
    ----------
    obs_nodes:
        Observation node names (one per feature).
    descriptions:
        Optional ``{node_name: description}`` mapping.
    obs_stats:
        Optional ``(mean, var, clip, epsilon)`` from VecNormalize.  When
        provided, Z-Score normalization parameters are computed per feature.
        If the stats have shape ``(obs_depth, num_features)``, they are
        averaged across depth positions.
    obs_norm_minmax:
        Optional ``(obs_mins, obs_maxs)`` per-feature arrays for min/max
        normalization.  When provided (and ``obs_stats`` is not), sets
        ``normalization_type="min_max"`` with ``custom_minimum``/``custom_maximum``.
    obs_range:
        Optional ``(obs_min, obs_max)`` per-feature arrays from training.
        When provided, failure bounds are set per input binding.
    """
    desc = descriptions or {}
    num_features = len(obs_nodes)

    # Compute per-feature mean/std from VecNormalize stats
    feature_mean: np.ndarray | None = None
    feature_std: np.ndarray | None = None
    if obs_stats is not None:
        mean_np, var_np, _clip, epsilon = obs_stats
        if mean_np.ndim == 2:
            feature_mean = mean_np.mean(axis=0)
            feature_std = np.sqrt(var_np.mean(axis=0) + epsilon)
        elif mean_np.size > num_features:
            obs_depth = mean_np.size // num_features
            mean_2d = mean_np.reshape(obs_depth, num_features)
            var_2d = var_np.reshape(obs_depth, num_features)
            feature_mean = mean_2d.mean(axis=0)
            feature_std = np.sqrt(var_2d.mean(axis=0) + epsilon)
        else:
            feature_mean = mean_np.ravel()
            feature_std = np.sqrt(var_np.ravel() + epsilon)

    bindings = []
    for i, name in enumerate(obs_nodes):
        b = InputBinding(name=name, description=desc.get(name, ""))
        if feature_mean is not None and feature_std is not None:
            b.normalization_type = "z_score"
            b.normalization_source = "custom"
            b.custom_mean = float(feature_mean[i])
            b.custom_std = float(feature_std[i])
        elif obs_norm_minmax is not None:
            obs_mins, obs_maxs = obs_norm_minmax
            b.normalization_type = "min_max"
            b.normalization_source = "custom"
            b.custom_minimum = float(obs_mins[i])
            b.custom_maximum = float(obs_maxs[i])
        if obs_range is not None:
            obs_min, obs_max = obs_range
            b.custom_failure = True
            b.custom_failure_minimum = float(obs_min[i])
            b.custom_failure_maximum = float(obs_max[i])
        bindings.append(b)

    return bindings


def build_output_bindings(
    action_nodes: list[str],
    action_ranges: dict[str, tuple[float, float]],
    *,
    descriptions: dict[str, str] | None = None,
    discrete: bool = False,
) -> list[OutputBinding]:
    """Build OutputBinding list from action node names + ranges.

    Parameters
    ----------
    action_nodes:
        Action node names.
    action_ranges:
        ``{node_name: (low, high)}`` action space bounds.
    descriptions:
        Optional ``{node_name: description}`` mapping.
    discrete:
        If True, outputs get ``normalization_type="none"`` (DQN models).
    """
    desc = descriptions or {}
    bindings = []
    for name in action_nodes:
        if discrete:
            bindings.append(
                OutputBinding(
                    name=name,
                    description=desc.get(name, ""),
                    normalization_type="none",
                )
            )
        else:
            lo, hi = action_ranges[name]
            bindings.append(
                OutputBinding(
                    name=name,
                    description=desc.get(name, ""),
                    range_min=lo,
                    range_max=hi,
                    normalization_type="symmetric",
                    normalization_source="custom",
                    custom_minimum=lo,
                    custom_maximum=hi,
                    clamp_output=True,
                )
            )

    return bindings
