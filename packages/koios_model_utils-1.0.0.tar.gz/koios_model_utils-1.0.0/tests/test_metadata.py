"""Tests for koios_model_utils.metadata."""

from __future__ import annotations

import json

import numpy as np
import onnx
import pytest

from koios_model_utils.enums import (
    Algorithm,
    ModelType,
    NormalizationSource,
    NormalizationType,
    OutputMode,
)
from koios_model_utils.metadata import (
    InputBinding,
    OutputBinding,
    TrainingMeta,
    build_input_bindings,
    build_output_bindings,
    embed_koios_metadata,
)


def _make_dummy_onnx_model() -> onnx.ModelProto:
    """Create a minimal valid ONNX model for testing metadata embedding."""
    # Simple identity model: Y = X
    x = onnx.helper.make_tensor_value_info("X", onnx.TensorProto.FLOAT, [1, 3])
    y = onnx.helper.make_tensor_value_info("Y", onnx.TensorProto.FLOAT, [1, 3])
    node = onnx.helper.make_node("Identity", inputs=["X"], outputs=["Y"])
    graph = onnx.helper.make_graph([node], "test_graph", [x], [y])
    model = onnx.helper.make_model(graph, opset_imports=[onnx.helper.make_opsetid("", 18)])
    return model


class TestEmbedKoiosMetadata:
    def test_basic_embedding(self):
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(name="temperature", description="Tank temp (C)"),
            InputBinding(name="pressure", description="Vessel pressure (kPa)"),
        ]
        outputs = [
            OutputBinding(
                name="valve",
                range_min=0.0,
                range_max=100.0,
                normalization_type="symmetric",
                normalization_source="custom",
                custom_minimum=0.0,
                custom_maximum=100.0,
                clamp_output=True,
            ),
        ]
        training = TrainingMeta(
            scenario_name="tank_temperature",
            algorithm="PPO",
            obs_depth=5,
            sample_rate=1.0,
        )

        embed_koios_metadata(model, inputs=inputs, outputs=outputs, training=training)

        # Check metadata_props
        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert "koios.training" in meta_dict
        assert "koios.bindings" in meta_dict

        # Training metadata
        t = meta_dict["koios.training"]
        assert t["schema_version"] == 1
        assert t["scenario_name"] == "tank_temperature"
        assert t["algorithm"] == "PPO"
        assert t["obs_depth"] == 5
        assert t["sample_rate"] == 1.0
        assert t["model_type"] == "ABSOLUTE"
        assert "exported_at" in t

        # Bindings metadata
        b = meta_dict["koios.bindings"]
        assert b["schema_version"] == 1
        assert b["output_denormalized"] is False
        # obs_normalized is no longer written — it was never read by the server
        # (see CHANGELOG 1.0.0 contract-fix notes).
        assert "obs_normalized" not in b
        assert len(b["inputs"]) == 2
        assert len(b["outputs"]) == 1

        # Input bindings
        inp0 = b["inputs"][0]
        assert inp0["binding_order"] == 1
        assert inp0["name"] == "temperature"
        assert inp0["description"] == "Tank temp (C)"

        inp1 = b["inputs"][1]
        assert inp1["binding_order"] == 2
        assert inp1["name"] == "pressure"

        # Output binding
        out0 = b["outputs"][0]
        assert out0["binding_order"] == 1
        assert out0["name"] == "valve"
        assert out0["range_min"] == 0.0
        assert out0["range_max"] == 100.0
        assert out0["normalization_type"] == "symmetric"
        assert out0["custom_minimum"] == 0.0
        assert out0["custom_maximum"] == 100.0
        assert out0["clamp_output"] is True

    def test_no_training_meta(self):
        model = _make_dummy_onnx_model()
        inputs = [InputBinding(name="x")]
        outputs = [OutputBinding(name="y")]

        embed_koios_metadata(model, inputs=inputs, outputs=outputs)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        t = meta_dict["koios.training"]
        assert t["scenario_name"] == ""
        assert t["algorithm"] == ""

    def test_discrete_output_mode(self):
        model = _make_dummy_onnx_model()
        inputs = [InputBinding(name="x")]
        outputs = [OutputBinding(name="action", normalization_type="none")]
        training = TrainingMeta(
            output_mode="DISCRETE",
            action_map=[{"value": 0, "label": "low"}, {"value": 1, "label": "high"}],
        )

        embed_koios_metadata(model, inputs=inputs, outputs=outputs, training=training)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        t = meta_dict["koios.training"]
        assert t["output_mode"] == "DISCRETE"
        assert len(t["action_map"]) == 2

    def test_zscore_input_binding(self):
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(
                name="temp",
                normalization_type="z_score",
                normalization_source="custom",
                custom_mean=25.0,
                custom_std=5.0,
            ),
        ]
        outputs = [OutputBinding(name="y")]

        embed_koios_metadata(model, inputs=inputs, outputs=outputs)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        inp0 = meta_dict["koios.bindings"]["inputs"][0]
        assert inp0["normalization_type"] == "z_score"
        assert inp0["normalization_source"] == "custom"
        assert inp0["custom_mean"] == 25.0
        assert inp0["custom_std"] == 5.0

    def test_failure_bounds(self):
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(
                name="temp",
                custom_failure=True,
                custom_failure_minimum=10.0,
                custom_failure_maximum=90.0,
            ),
        ]
        outputs = [OutputBinding(name="y")]

        embed_koios_metadata(model, inputs=inputs, outputs=outputs)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        inp0 = meta_dict["koios.bindings"]["inputs"][0]
        # custom_failure=True must translate to the wire-level key the
        # server actually reads: failure_range_mode="CUSTOM".
        assert inp0["failure_range_mode"] == "CUSTOM"
        assert inp0["custom_failure_minimum"] == 10.0
        assert inp0["custom_failure_maximum"] == 90.0
        # The legacy custom_failure boolean was dead wire weight.
        assert "custom_failure" not in inp0


class TestContractWithWebapp:
    """Lock in the key names that koios-webapp-py's services.py reads.

    These are the keys consumed by `_apply_training_metadata` and
    `_apply_binding_metadata` in
    ``koios-webapp-py/app/AiOpsInterface/apps/aiops/services.py``. If any of
    these names change server-side, this test fails and forces a
    coordinated fix rather than silent drift.
    """

    # Fields the server reads from each top-level payload.
    SERVER_TRAINING_KEYS = frozenset(
        {
            "schema_version",
            "sample_rate",
            "model_type",
            "output_mode",
            "action_map",
        }
    )
    SERVER_BINDINGS_TOP_LEVEL_KEYS = frozenset(
        {"schema_version", "output_denormalized", "inputs", "outputs"}
    )
    SERVER_INPUT_ENTRY_KEYS = frozenset(
        {
            "binding_order",
            "name",
            "description",
            "normalization_type",
            "normalization_source",
            "custom_minimum",
            "custom_maximum",
            "custom_mean",
            "custom_std",
            "failure_range_mode",
            "custom_failure_minimum",
            "custom_failure_maximum",
        }
    )
    SERVER_OUTPUT_ENTRY_KEYS = frozenset(
        SERVER_INPUT_ENTRY_KEYS
        | {
            "range_min",
            "range_max",
            "clamp_output",
        }
    )

    def _embed_everything(self):
        """Emit a payload that exercises every field on every dataclass."""
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(
                name="temp",
                description="Tank temp",
                normalization_type="z_score",
                normalization_source="custom",
                custom_mean=25.0,
                custom_std=5.0,
                custom_minimum=0.0,
                custom_maximum=100.0,
                custom_failure=True,
                custom_failure_minimum=-10.0,
                custom_failure_maximum=110.0,
            ),
        ]
        outputs = [
            OutputBinding(
                name="valve",
                description="Valve %",
                range_min=0.0,
                range_max=100.0,
                normalization_type="symmetric",
                normalization_source="custom",
                custom_minimum=0.0,
                custom_maximum=100.0,
                clamp_output=True,
                custom_failure=True,
                custom_failure_minimum=-5.0,
                custom_failure_maximum=105.0,
            ),
        ]
        training = TrainingMeta(
            scenario_name="tank",
            algorithm="PPO",
            sample_rate=1.0,
            model_type="ABSOLUTE",
            output_mode="CONTINUOUS",
            action_map=[{"value": 0, "label": "off"}],
        )
        embed_koios_metadata(
            model,
            inputs=inputs,
            outputs=outputs,
            training=training,
            output_denormalized=True,
        )
        return {p.key: json.loads(p.value) for p in model.metadata_props}

    def test_training_payload_is_subset_of_server_keys(self):
        meta = self._embed_everything()["koios.training"]
        # Strip client-informational fields the server legitimately ignores.
        payload_keys = set(meta) - {
            "scenario_name",
            "algorithm",
            "obs_depth",
            "exported_at",
        }
        unknown = payload_keys - self.SERVER_TRAINING_KEYS
        assert not unknown, (
            f"koios.training contains keys the webapp does not read: {unknown}. "
            "Either remove them from metadata.py or teach the server about them."
        )

    def test_bindings_top_level_has_no_unknown_keys(self):
        b = self._embed_everything()["koios.bindings"]
        top_level = set(b)
        unknown = top_level - self.SERVER_BINDINGS_TOP_LEVEL_KEYS
        assert not unknown, (
            f"koios.bindings top-level contains keys the webapp does not read: {unknown}"
        )

    def test_input_entry_has_no_unknown_keys(self):
        b = self._embed_everything()["koios.bindings"]
        entry_keys = set(b["inputs"][0])
        unknown = entry_keys - self.SERVER_INPUT_ENTRY_KEYS
        assert not unknown, (
            f"koios.bindings.inputs[] entries contain keys the webapp does not read: {unknown}"
        )

    def test_output_entry_has_no_unknown_keys(self):
        b = self._embed_everything()["koios.bindings"]
        entry_keys = set(b["outputs"][0])
        unknown = entry_keys - self.SERVER_OUTPUT_ENTRY_KEYS
        assert not unknown, (
            f"koios.bindings.outputs[] entries contain keys the webapp does not read: {unknown}"
        )

    def test_custom_failure_flips_server_mode(self):
        """The bug this release fixes: custom_failure=True must produce
        failure_range_mode='CUSTOM' so the server actually applies the
        custom bounds instead of silently defaulting to NORMALIZATION_RANGE.
        """
        b = self._embed_everything()["koios.bindings"]
        assert b["inputs"][0]["failure_range_mode"] == "CUSTOM"
        assert b["outputs"][0]["failure_range_mode"] == "CUSTOM"


class TestEnumsInterchangeable:
    """Passing enum members must produce identical payloads to raw strings.

    The public dataclasses accept either a ``StrEnum`` member or a raw
    string; both paths must serialize through ``json.dumps`` to the same
    wire bytes.  This protects users who adopt the enums from subtly
    different output.
    """

    def _embed_with_strings(self):
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[
                InputBinding(
                    name="temp",
                    normalization_type="z_score",
                    normalization_source="custom",
                    custom_mean=1.0,
                    custom_std=2.0,
                ),
            ],
            outputs=[
                OutputBinding(
                    name="valve",
                    normalization_type="symmetric",
                    normalization_source="custom",
                    range_min=0.0,
                    range_max=100.0,
                    custom_minimum=0.0,
                    custom_maximum=100.0,
                ),
            ],
            training=TrainingMeta(
                algorithm="PPO",
                model_type="ABSOLUTE",
                output_mode="CONTINUOUS",
            ),
        )
        return {p.key: p.value for p in model.metadata_props}

    def _embed_with_enums(self):
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[
                InputBinding(
                    name="temp",
                    normalization_type=NormalizationType.Z_SCORE,
                    normalization_source=NormalizationSource.CUSTOM,
                    custom_mean=1.0,
                    custom_std=2.0,
                ),
            ],
            outputs=[
                OutputBinding(
                    name="valve",
                    normalization_type=NormalizationType.SYMMETRIC,
                    normalization_source=NormalizationSource.CUSTOM,
                    range_min=0.0,
                    range_max=100.0,
                    custom_minimum=0.0,
                    custom_maximum=100.0,
                ),
            ],
            training=TrainingMeta(
                algorithm=Algorithm.PPO,
                model_type=ModelType.ABSOLUTE,
                output_mode=OutputMode.CONTINUOUS,
            ),
        )
        return {p.key: p.value for p in model.metadata_props}

    def test_bindings_payload_identical(self):
        s = self._embed_with_strings()
        e = self._embed_with_enums()
        assert s["koios.bindings"] == e["koios.bindings"]

    def test_training_payload_identical_modulo_timestamp(self):
        s = json.loads(self._embed_with_strings()["koios.training"])
        e = json.loads(self._embed_with_enums()["koios.training"])
        s.pop("exported_at", None)
        e.pop("exported_at", None)
        assert s == e

    def test_enum_values_match_server_normalization_names(self):
        """Server's _parse_norm_type lowercases input and looks up against
        enum member names. Enum string values must match server enum names
        (case-insensitive) or the server silently falls back to NONE."""
        # Server NormalizationTypeChoices member names: NONE, MIN_MAX, SYMMETRIC, Z_SCORE
        assert {m.value for m in NormalizationType} == {
            "none",
            "min_max",
            "symmetric",
            "z_score",
        }
        # Server NormalizationSourceChoices member names: TAG_RANGE, CUSTOM
        assert {m.value for m in NormalizationSource} == {"tag_range", "custom"}


class TestBuildInputBindings:
    def test_basic(self):
        bindings = build_input_bindings(["temp", "pressure"])
        assert len(bindings) == 2
        assert bindings[0].name == "temp"
        assert bindings[1].name == "pressure"
        assert bindings[0].normalization_type == "none"

    def test_with_descriptions(self):
        bindings = build_input_bindings(
            ["temp"],
            descriptions={"temp": "Temperature (C)"},
        )
        assert bindings[0].description == "Temperature (C)"

    def test_with_obs_stats_1d(self):
        """Single-step obs (obs_depth=1) — stats are already per-feature."""
        mean = np.array([10.0, 20.0], dtype=np.float32)
        var = np.array([4.0, 9.0], dtype=np.float32)
        epsilon = 1e-8

        bindings = build_input_bindings(
            ["a", "b"],
            obs_stats=(mean, var, 10.0, epsilon),
        )

        assert bindings[0].normalization_type == "z_score"
        assert bindings[0].normalization_source == "custom"
        assert bindings[0].custom_mean == pytest.approx(10.0)
        assert bindings[0].custom_std == pytest.approx(np.sqrt(4.0 + epsilon))
        assert bindings[1].custom_mean == pytest.approx(20.0)
        assert bindings[1].custom_std == pytest.approx(np.sqrt(9.0 + epsilon))

    def test_with_obs_stats_2d(self):
        """Multi-step obs (obs_depth=3) — average across depth."""
        mean = np.array(
            [
                [10.0, 20.0],
                [11.0, 21.0],
                [12.0, 22.0],
            ],
            dtype=np.float32,
        )
        var = np.array(
            [
                [4.0, 9.0],
                [4.0, 9.0],
                [4.0, 9.0],
            ],
            dtype=np.float32,
        )
        epsilon = 1e-8

        bindings = build_input_bindings(
            ["a", "b"],
            obs_stats=(mean, var, 10.0, epsilon),
        )

        expected_mean_a = np.mean([10.0, 11.0, 12.0])
        expected_std_a = np.sqrt(np.mean([4.0, 4.0, 4.0]) + epsilon)
        assert bindings[0].custom_mean == pytest.approx(expected_mean_a)
        assert bindings[0].custom_std == pytest.approx(expected_std_a)

    def test_with_obs_stats_flat(self):
        """Flat stats (obs_depth * num_features) — reshape then average."""
        # 2 features, obs_depth=3 → flat array of 6
        mean = np.array([10.0, 20.0, 11.0, 21.0, 12.0, 22.0], dtype=np.float32)
        var = np.array([4.0, 9.0, 4.0, 9.0, 4.0, 9.0], dtype=np.float32)
        epsilon = 1e-8

        bindings = build_input_bindings(
            ["a", "b"],
            obs_stats=(mean, var, 10.0, epsilon),
        )

        expected_mean_a = np.mean([10.0, 11.0, 12.0])
        assert bindings[0].custom_mean == pytest.approx(expected_mean_a)

    def test_with_obs_range(self):
        obs_min = np.array([0.0, 10.0], dtype=np.float32)
        obs_max = np.array([100.0, 50.0], dtype=np.float32)

        bindings = build_input_bindings(
            ["a", "b"],
            obs_range=(obs_min, obs_max),
        )

        assert bindings[0].custom_failure is True
        assert bindings[0].custom_failure_minimum == 0.0
        assert bindings[0].custom_failure_maximum == 100.0
        assert bindings[1].custom_failure_minimum == 10.0
        assert bindings[1].custom_failure_maximum == 50.0

    def test_with_stats_and_range(self):
        mean = np.array([10.0], dtype=np.float32)
        var = np.array([4.0], dtype=np.float32)
        obs_min = np.array([0.0], dtype=np.float32)
        obs_max = np.array([100.0], dtype=np.float32)

        bindings = build_input_bindings(
            ["temp"],
            obs_stats=(mean, var, 10.0, 1e-8),
            obs_range=(obs_min, obs_max),
        )

        assert bindings[0].normalization_type == "z_score"
        assert bindings[0].custom_failure is True


class TestBuildOutputBindings:
    def test_continuous(self):
        bindings = build_output_bindings(
            ["valve"],
            action_ranges={"valve": (0.0, 100.0)},
        )
        assert len(bindings) == 1
        assert bindings[0].name == "valve"
        assert bindings[0].range_min == 0.0
        assert bindings[0].range_max == 100.0
        assert bindings[0].normalization_type == "symmetric"
        assert bindings[0].normalization_source == "custom"
        assert bindings[0].custom_minimum == 0.0
        assert bindings[0].custom_maximum == 100.0
        assert bindings[0].clamp_output is True

    def test_discrete(self):
        bindings = build_output_bindings(
            ["action"],
            action_ranges={"action": (0, 3)},
            discrete=True,
        )
        assert len(bindings) == 1
        assert bindings[0].normalization_type == "none"
        assert bindings[0].range_min is None

    def test_with_descriptions(self):
        bindings = build_output_bindings(
            ["valve"],
            action_ranges={"valve": (0.0, 100.0)},
            descriptions={"valve": "Control valve position (%)"},
        )
        assert bindings[0].description == "Control valve position (%)"
