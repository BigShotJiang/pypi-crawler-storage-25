# Changelog

All notable changes to `koios-model-utils` are documented here. The format
loosely follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and
this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-04-20

First stable release. This release fixes several wire-format bugs between
the client and the Koios webapp server — the result of the two sides
drifting apart before the contract was exercised end-to-end. See
[PR writeup] and `TestContractWithWebapp` for the tests that now lock
each key name into place.

### Fixed
- **Custom failure bounds were silently dropped for MIN_MAX / SYMMETRIC /
  NONE normalization.** The client wrote `custom_failure: true` along with
  `custom_failure_minimum/maximum`, but the server never read the
  `custom_failure` boolean — it reads `failure_range_mode` to decide
  whether to apply the custom bounds. Without that key the server
  defaulted to `NORMALIZATION_RANGE`, which derives failure bounds from
  the normalization range and ignores any custom values. Result:
  failure bounds quietly did nothing at runtime unless the binding
  happened to be Z-Score (which auto-forces CUSTOM server-side).

  1.0.0 now writes `failure_range_mode: "CUSTOM"` when `custom_failure`
  is True, which the server parses correctly. Applies to both input
  and output bindings.
- Dropped `custom_failure: true` (input entries) and `obs_normalized: false`
  (top-level bindings) from the wire payload — the server never read
  either one, so they were dead weight.

### Added
- **String enums** for every metadata value previously passed as a raw
  string: `NormalizationType`, `NormalizationSource`, `ModelType`,
  `OutputMode`, `Algorithm`. All are `enum.StrEnum` subclasses so
  members serialize transparently through `json.dumps`, and the
  dataclass fields accept either form (`NormalizationType.SYMMETRIC`
  or `"symmetric"` produce byte-identical payloads).  Raw strings are
  still fully supported.
- `OutputBinding.custom_failure`, `custom_failure_minimum`, and
  `custom_failure_maximum` — the server has always accepted these on
  output bindings but the client had no API for setting them.
- `embed_koios_metadata(..., output_denormalized: bool = False)` — lets
  users signal that the ONNX graph emits physical values already, so
  the server wires outputs as `normalization_type=NONE` and uses the
  training action range as custom failure bounds. Previously hardcoded
  to False; the "legacy MIN_MAX+CUSTOM auto-inference" branch on the
  server was the only reachable path.
- `TestContractWithWebapp` — tests that lock in the set of keys
  consumed by `koios-webapp-py`'s `_apply_training_metadata` and
  `_apply_binding_metadata`. If either side drifts, the tests fail
  loudly rather than silently dropping fields again.

### Changed
- Declared Production/Stable (was Alpha).
- `TrainingMeta.model_type` default is now `"ABSOLUTE"` (matches the
  current server enum name). The server still accepts the legacy
  `"POSITIONAL"` / `"VELOCITY"` aliases for backward compatibility —
  they just map to `ABSOLUTE` / `RELATIVE` respectively.

### License
- Relicensed from MIT to **Apache License 2.0** to align with the
  sibling Koios client libraries (`koios-client`, `koios-component-builder`).
  Apache 2.0 matches the prevailing convention for SDKs / client
  libraries at comparable companies (AWS, Google, OpenAI, Snowflake)
  and includes an explicit patent grant.  The `LICENSE` file at the
  repo root has been updated accordingly.

### Compatibility
- `schema_version` remains `1`. All fixes produce payloads the current
  webapp already accepts; this is entirely a client-side correctness
  release. No server-side changes required. No prior releases of this
  package have shipped real metadata into anyone's Koios install.

[1.0.0]: https://github.com/Ai-Ops-Inc/koios-model-utils/releases/tag/v1.0.0
