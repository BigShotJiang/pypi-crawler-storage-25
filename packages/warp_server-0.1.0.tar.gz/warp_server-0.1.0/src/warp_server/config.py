from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./warp.db"
    secret_key: str = "change-me-in-production"

    model_config = {"env_prefix": "WARP_"}


settings = Settings()
