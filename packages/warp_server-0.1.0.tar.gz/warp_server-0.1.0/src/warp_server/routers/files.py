import base64
import logging
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.database import get_db
from warp_server.models import (
    Commit,
    Function,
    FunctionComment,
    FunctionConstraint,
    Source,
    SourceUser,
    Symbol,
    Target,
    User,
)
from warp_server.models import Type as TypeModel
from warp_server.schemas import PushResponse
from warp_server.schemas import UploadFileJson as UploadFileJsonSchema
from warp_server.warp_parser import ParsedChunk, parse_warp_file

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/files", tags=["files"])


async def _check_push_access(db: AsyncSession, source_id, user: User) -> Source:
    result = await db.execute(select(Source).where(Source.id == source_id))
    source = result.scalar_one_or_none()
    if source is None:
        raise HTTPException(status_code=404, detail="Source not found")
    if user.role == "Admin":
        return source
    su = await db.execute(
        select(SourceUser).where(
            SourceUser.source_id == source_id, SourceUser.user_id == user.id
        )
    )
    if su.scalar_one_or_none() is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authorized"
        )
    return source


@router.post("", response_model=PushResponse)
async def push_file_multipart(
    file: UploadFile,
    name: str,
    source: str,
    description: str | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    source_id = UUID(source)
    await _check_push_access(db, source_id, user)

    file_bytes = await file.read()
    commit = Commit(
        source_id=source_id,
        user_id=user.id,
        name=name,
        description=description,
    )
    db.add(commit)
    await db.flush()

    try:
        chunks = parse_warp_file(file_bytes)
    except Exception:
        logger.exception("Failed to parse warp file")
        raise HTTPException(status_code=400, detail="Invalid warp file")

    await _ingest_chunks(db, chunks, commit.id, source_id)
    await db.commit()
    await db.refresh(commit)
    return PushResponse(commit_id=commit.id)


@router.post("/json", response_model=PushResponse)
async def push_file_json(
    body: UploadFileJsonSchema,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    await _check_push_access(db, body.source, user)

    try:
        file_bytes = base64.b64decode(body.file)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid base64 file data")

    commit = Commit(
        source_id=body.source,
        user_id=user.id,
        name=body.name,
        description=body.description,
    )
    db.add(commit)
    await db.flush()

    try:
        chunks = parse_warp_file(file_bytes)
    except Exception:
        logger.exception("Failed to parse warp file")
        raise HTTPException(status_code=400, detail="Invalid warp file")

    await _ingest_chunks(db, chunks, commit.id, body.source)
    await db.commit()
    await db.refresh(commit)
    return PushResponse(commit_id=commit.id)


# ---------------------------------------------------------------------------
# Ingestion logic
# ---------------------------------------------------------------------------


async def _get_or_create_target(
    db: AsyncSession, platform: str | None, arch: str | None
) -> Target:
    result = await db.execute(
        select(Target).where(Target.platform == platform, Target.arch == arch)
    )
    target = result.scalar_one_or_none()
    if target is not None:
        return target
    target = Target(platform=platform, arch=arch)
    db.add(target)
    await db.flush()
    return target


async def _get_or_create_symbol(
    db: AsyncSession,
    name: str,
    symbol_class: str,
    modifier: str,
) -> Symbol:
    result = await db.execute(
        select(Symbol).where(
            Symbol.name == name,
            Symbol.symbol_class == symbol_class,
            Symbol.modifier == modifier,
        )
    )
    sym = result.scalar_one_or_none()
    if sym is not None:
        return sym
    sym = Symbol(name=name, symbol_class=symbol_class, modifier=modifier)
    db.add(sym)
    await db.flush()
    return sym


async def _ingest_chunks(
    db: AsyncSession,
    chunks: list[ParsedChunk],
    commit_id: int,
    source_id: UUID,
) -> None:
    for chunk in chunks:
        target = await _get_or_create_target(
            db, chunk.target.platform, chunk.target.architecture
        )

        # --- Types ---
        for pt in chunk.types:
            existing = await db.execute(
                select(TypeModel).where(TypeModel.id == pt.guid)
            )
            if existing.scalar_one_or_none() is not None:
                continue
            db.add(
                TypeModel(
                    id=pt.guid,
                    commit_id=commit_id,
                    source_id=source_id,
                    name=pt.name,
                    data=pt.data,
                )
            )

        await db.flush()

        # --- Functions ---
        for pf in chunk.functions:
            sym = await _get_or_create_symbol(
                db, pf.symbol.name, pf.symbol.symbol_class, pf.symbol.modifier
            )

            func = Function(
                commit_id=commit_id,
                target_id=target.id,
                source_id=source_id,
                guid=pf.guid,
                symbol_id=sym.id,
                type_id=pf.type_guid,
                data=pf.data,
            )
            db.add(func)
            await db.flush()

            for pc in pf.comments:
                db.add(
                    FunctionComment(
                        function_id=func.id,
                        text=pc.text,
                        byte_offset=pc.byte_offset,
                    )
                )

            for pc in pf.constraints:
                db.add(
                    FunctionConstraint(
                        function_id=func.id,
                        guid=pc.guid,
                        byte_offset=pc.byte_offset,
                    )
                )
