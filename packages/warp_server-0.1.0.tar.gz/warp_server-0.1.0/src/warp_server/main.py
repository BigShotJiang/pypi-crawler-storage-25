from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI

from warp_server.database import engine
from warp_server.models import Base
from warp_server.routers import (
    auth,
    commits,
    files,
    functions,
    search,
    sources,
    status,
    symbols,
    targets,
    types,
    users,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


app = FastAPI(title="warp-server", version="0.1.0", lifespan=lifespan)

app.include_router(status.router)
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(sources.router)
app.include_router(commits.router)
app.include_router(targets.router)
app.include_router(symbols.router)
app.include_router(functions.router)
app.include_router(files.router)
app.include_router(types.router)
app.include_router(search.router)


def run():
    uvicorn.run("warp_server.main:app", host="0.0.0.0", port=8000, reload=True)


if __name__ == "__main__":
    run()
