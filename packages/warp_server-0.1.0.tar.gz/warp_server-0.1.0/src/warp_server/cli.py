import asyncio
import secrets
from datetime import datetime, timezone

import click
from sqlalchemy import select

from warp_server.database import async_session, engine
from warp_server.models import ApiKey, Base, Source, SourceTag, SourceUser, User


@click.group(name="warp-ctl", help="WARP server management CLI.")
def app():
    pass


@app.group(help="Manage users.")
def user():
    pass


@app.group(help="Manage API keys.")
def key():
    pass


@app.group(help="Manage sources.")
def source():
    pass


def _run(coro):
    return asyncio.run(coro)


async def _ensure_tables():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


# ── Users ────────────────────────────────────────────────────────────


@user.command("create")
@click.option("--email", required=True, help="User email address.")
@click.option(
    "--username", default=None, help="Username (defaults to email local part)."
)
@click.option("--role", default="User", help="Role: User or Admin.")
def user_create(email, username, role):
    """Create a new user."""

    async def _create():
        await _ensure_tables()
        async with async_session() as db:
            name = username or email.split("@")[0]
            u = User(email=email, username=name, role=role)
            db.add(u)
            await db.flush()
            raw_key = secrets.token_urlsafe(32)
            db.add(ApiKey(user_id=u.id, key=raw_key, name="default"))
            await db.commit()
            await db.refresh(u)
            click.echo(f"Created user id={u.id} username={u.username} role={u.role}")
            click.echo(f"API key: {raw_key}")
            click.echo("Store this key securely — it cannot be retrieved later.")

    _run(_create())


@user.command("list")
def user_list():
    """List all users."""

    async def _list():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).order_by(User.id))
            users = result.scalars().all()
            if not users:
                click.echo("No users found.")
                return
            click.echo(
                f"{'ID':<6} {'Username':<20} {'Email':<30} {'Role':<10} {'Created'}"
            )
            click.echo("-" * 80)
            for u in users:
                click.echo(
                    f"{u.id:<6} {u.username:<20} {u.email:<30} {u.role:<10} {u.created_at}"
                )

    _run(_list())


@user.command("delete")
@click.argument("user_id", type=int)
def user_delete(user_id):
    """Delete a user by ID."""

    async def _delete():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).where(User.id == user_id))
            u = result.scalar_one_or_none()
            if u is None:
                click.echo(f"User {user_id} not found.", err=True)
                raise SystemExit(1)
            await db.delete(u)
            await db.commit()
            click.echo(f"Deleted user id={user_id} username={u.username}")

    _run(_delete())


# ── API Keys ─────────────────────────────────────────────────────────


@key.command("create")
@click.option(
    "--user-id", required=True, type=int, help="User ID to create the key for."
)
@click.option("--name", default="default", help="Key name/label.")
def key_create(user_id, name):
    """Create an API key for a user."""

    async def _create():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).where(User.id == user_id))
            u = result.scalar_one_or_none()
            if u is None:
                click.echo(f"User {user_id} not found.", err=True)
                raise SystemExit(1)
            raw_key = secrets.token_urlsafe(32)
            api_key = ApiKey(
                user_id=u.id,
                key=raw_key,
                name=name,
                created_at=datetime.now(timezone.utc),
            )
            db.add(api_key)
            await db.commit()
            await db.refresh(api_key)
            click.echo(f"Created API key for user={u.username}")
            click.echo(f"Key: {raw_key}")
            click.echo("Store this key securely — it cannot be retrieved later.")

    _run(_create())


@key.command("list")
@click.option("--user-id", default=None, type=int, help="Filter keys by user ID.")
def key_list(user_id):
    """List API keys."""

    async def _list():
        await _ensure_tables()
        async with async_session() as db:
            query = select(ApiKey).order_by(ApiKey.id)
            if user_id is not None:
                query = query.where(ApiKey.user_id == user_id)
            result = await db.execute(query)
            keys = result.scalars().all()
            if not keys:
                click.echo("No API keys found.")
                return
            click.echo(
                f"{'ID':<6} {'User ID':<8} {'Name':<16} {'Key (prefix)':<14} {'Created':<26} {'Last Used'}"
            )
            click.echo("-" * 90)
            for k in keys:
                click.echo(
                    f"{k.id:<6} {k.user_id:<8} {k.name:<16} {k.key[:12] + '…':<14} {str(k.created_at):<26} {k.last_used_at or '—'}"
                )

    _run(_list())


@key.command("revoke")
@click.argument("key_id", type=int)
def key_revoke(key_id):
    """Revoke (delete) an API key."""

    async def _revoke():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(ApiKey).where(ApiKey.id == key_id))
            api_key = result.scalar_one_or_none()
            if api_key is None:
                click.echo(f"API key {key_id} not found.", err=True)
                raise SystemExit(1)
            await db.delete(api_key)
            await db.commit()
            click.echo(f"Revoked API key id={key_id}")

    _run(_revoke())


# ── Sources ──────────────────────────────────────────────────────────


@source.command("create")
@click.option("--name", required=True, help="Source name.")
@click.option("--user-id", default=None, type=int, help="User ID to add as owner.")
def source_create(name, user_id):
    """Create a new source."""

    async def _create():
        await _ensure_tables()
        async with async_session() as db:
            src = Source(name=name)
            db.add(src)
            await db.flush()
            if user_id is not None:
                db.add(SourceUser(source_id=src.id, user_id=user_id))
            db.add(SourceTag(source_id=src.id, tag="trusted"))
            await db.commit()
            await db.refresh(src)
            click.echo(f"Created source id={src.id} name={src.name}")

    _run(_create())


@source.command("list")
def source_list():
    """List all sources."""

    async def _list():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(Source).order_by(Source.name))
            sources = result.scalars().all()
            if not sources:
                click.echo("No sources found.")
                return
            click.echo(f"{'ID':<6} {'Name':<30} {'Created'}")
            click.echo("-" * 60)
            for s in sources:
                click.echo(f"{s.id:<6} {s.name:<30} {s.created_at}")

    _run(_list())


# ── Quick bootstrap ──────────────────────────────────────────────────


@app.command("bootstrap")
@click.option("--email", default="admin@localhost", help="Admin email.")
@click.option("--username", default="admin", help="Admin username.")
def bootstrap(email, username):
    """Create an admin user with an API key in one step."""

    async def _bootstrap():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).where(User.username == username))
            existing = result.scalar_one_or_none()
            if existing is not None:
                click.echo(
                    f"User '{username}' already exists (id={existing.id}), skipping creation."
                )
                return
            u = User(email=email, username=username, role="Admin")
            db.add(u)
            await db.flush()
            raw_key = secrets.token_urlsafe(32)
            db.add(ApiKey(user_id=u.id, key=raw_key, name="bootstrap"))
            await db.commit()
            await db.refresh(u)
            click.echo(f"Created admin user id={u.id} username={u.username}")
            click.echo(f"API key: {raw_key}")
            click.echo("Store this key securely — it cannot be retrieved later.")

    _run(_bootstrap())


if __name__ == "__main__":
    app()
