"""EvaluationEvolver — CORE-AGENT-2 S02.

Computes per-(agent, dimension, domain) performance scores from observed
Decision + Opinion evidence and writes them as bi-temporal ``evaluation``
MemoryItems via append-and-supersede.

Four proxy dimensions (blueprint §3 S02 / §5.1 OQ5-bis):
  1. ``decision_volume``      — per-day rate of decision activity
  2. ``supersession_rate``    — self-correction rate (SUPERSEDED_BY frequency)
  3. ``confidence_trajectory``— rolling mean delta between current and prior window
  4. ``reinforcement_balance``— net belief signal over opinion evidence

Design.md's 12 dimensions are deferred to ``CORE-DECISION-OUTCOME-1``.

Key correctness invariants (Codex rounds 1–10):
- Bootstrap branch first (R8 F1): if no prior version, use memory.add(); only
  when prev_id exists, use memory.ingest_superseding().
- Explicit add_edge AFTER every write (R5 F1, R7 F2, R9 F1): ingest_superseding()
  bypasses managed-type edge_fn callbacks.
- NO check_in_place_rewrite (R2 F3): guard is for in-place update_properties only.
- Score-delta gate: |delta| < EPSILON → skip (no version churn).
- Empty-evidence: return EvolverResult(notes=[...]) — never silent return [].
- trace_span wraps all work.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from smartmemory.agents.node import agent_item_id_for
from smartmemory.evaluations.queries import EvaluationQueriesExt
from smartmemory.models.memory_item import MemoryItem
from smartmemory.observability.tracing import trace_span
from smartmemory.plugins.base import EvolverPlugin, PluginMetadata
from smartmemory.plugins.evolvers.result import EvolverResult

_logger = logging.getLogger(__name__)

# Minimum absolute score delta to write a new version (avoid version churn)
_EPSILON = 0.01

# Proxy for prior-window cold-start: no decisions → assume middle confidence
_COLD_START_CONFIDENCE = 0.5


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass
class EvaluationEvolverConfig:
    """Constructor config for EvaluationEvolver (evolver-local, not PipelineConfig).

    Mirrors the ``EvaluationEvolverConfig`` section of evaluation-contract.json.
    """

    min_evidence_count: int = 5
    """Below this decision count, evolver writes nothing and returns a note."""

    lookback_days: int = 7
    """Window for decision_volume / supersession_rate / confidence_trajectory."""

    decay_after_days: int = 30
    """Evaluations older than this are not surfaced as current by EvaluationQueriesExt."""

    cold_start_score: float = 0.5
    """Returned by gate when no prior evaluation exists for (agent, dim, domain)."""

    freshness_days: int = 14
    """Gate-side stale window (distinct from decay_after_days)."""


# ---------------------------------------------------------------------------
# Proxy dimension helpers
# ---------------------------------------------------------------------------


def _compute_decision_volume(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
) -> tuple[float, list[str]]:
    """Per-day rate of decision activity for (agent, domain) in the lookback window.

    Score = decision_count / lookback_days (normalised per-day rate).

    Returns:
        (score, basis_ids) where basis_ids is the list of matched decision item_ids.
    """
    decisions = _get_decisions_in_window(memory, agent_id, domain, window_start)
    count = len(decisions)
    basis_ids = [_item_id(d) for d in decisions if _item_id(d)]

    # lookback window length in days
    now = datetime.now(timezone.utc)
    window_days = max(1, (now - window_start).days or 1)
    score = count / window_days

    return score, basis_ids


def _compute_supersession_rate(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
) -> tuple[float, list[str]]:
    """Fraction of agent's decisions in the window that were self-corrected.

    Score = SUPERSEDED_BY edge count / max(1, decision_count).
    High = frequent self-correction.

    SUPERSEDED_BY detection tries a graph edge query; falls back to counting
    decisions whose ``superseded`` / ``superseded_by`` property is set.
    """
    decisions = _get_decisions_in_window(memory, agent_id, domain, window_start)
    decision_count = len(decisions)
    basis_ids = [_item_id(d) for d in decisions if _item_id(d)]

    superseded_count = _count_superseded_decisions(memory, decisions)
    score = superseded_count / max(1, decision_count)

    return score, basis_ids


def _compute_confidence_trajectory(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
) -> tuple[float, list[str]]:
    """Delta between rolling confidence means: current window vs prior window.

    Score = mean(current confidence) - mean(prior confidence).
    Range is approximately [-1, 1]; clamped to [-1, 1].
    Prior window: [window_start - lookback_days, window_start).
    Cold-start prior (no prior decisions): 0.5.
    """
    now = datetime.now(timezone.utc)
    lookback_days = max(1, (now - window_start).days or 1)
    prior_start = window_start - timedelta(days=lookback_days)

    current_decisions = _get_decisions_in_window(memory, agent_id, domain, window_start)
    prior_decisions = _get_decisions_in_window(memory, agent_id, domain, prior_start, end=window_start)

    basis_ids = [_item_id(d) for d in current_decisions if _item_id(d)]

    current_mean = _mean_confidence(current_decisions) if current_decisions else _COLD_START_CONFIDENCE
    prior_mean = _mean_confidence(prior_decisions) if prior_decisions else _COLD_START_CONFIDENCE

    score = max(-1.0, min(1.0, current_mean - prior_mean))

    return score, basis_ids


def _compute_reinforcement_balance(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
) -> tuple[float, list[str]]:
    """Net belief signal across agent's opinion memories for this domain.

    Score = (sum_r - sum_c) / max(1, sum_r + sum_c).
    Range: [-1, 1].
    Uses Opinion.reinforcement_count / contradiction_count fields.
    """
    opinions = _get_opinions_for_agent_domain(memory, agent_id, domain)
    basis_ids = [_item_id(o) for o in opinions if _item_id(o)]

    sum_r = 0
    sum_c = 0
    for op in opinions:
        meta = _get_metadata(op)
        sum_r += int(meta.get("reinforcement_count") or 0)
        sum_c += int(meta.get("contradiction_count") or 0)

    score = (sum_r - sum_c) / max(1, sum_r + sum_c)

    return score, basis_ids


def _compute_task_completion_rate(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
) -> tuple[float, list[str]]:
    """Fraction of decisions reaching a terminal lifecycle state that completed —
    CORE-EVAL-DIMENSIONS-11-1 (CORE-DECISION-OUTCOME-1 D2 unlock).

    Score = count(status='completed') / count(status in {completed, failed, abandoned}).
    Range: [0, 1].

    Reads ONLY decisions whose lifecycle has terminated (one of the 3 new
    terminal statuses landed by CORE-DECISION-OUTCOME-1 D2). Decisions still in
    `active`/`pending`/`superseded`/`retracted` are excluded — they haven't yet
    revealed whether the work they describe ran to completion.

    Cold-start: empty basis when no decisions have reached a terminal status.
    Returns (0.0, []) so the per-dimension cold-start gate skips the write.
    """
    decisions = _get_decisions_in_window(memory, agent_id, domain, window_start)

    completed = 0
    terminal_basis: list[str] = []
    for d in decisions:
        status = _get_metadata(d).get("status")
        if status not in ("completed", "failed", "abandoned"):
            continue  # non-terminal — outside the denominator
        iid = _item_id(d)
        if iid:
            terminal_basis.append(iid)
        if status == "completed":
            completed += 1

    if not terminal_basis:
        return 0.0, []

    score = completed / len(terminal_basis)
    return score, terminal_basis


def _compute_context_retention(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
) -> tuple[float, list[str]]:
    """Context-utilisation rate over agent's decisions —
    CORE-EVAL-DIMENSIONS-11-1 (CORE-DECISION-OUTCOME-1 D3 unlock).

    Score = count(decisions with len(retrieved_context_ids) > 0) /
            count(decisions in window).
    Range: [0, 1].

    v1 interpretation: presence-based. A decision that carries at least one
    retrieved context id was made *with* retrieved priors at hand; one that
    carries none was made cold. Higher score = agent consistently grounds
    decisions in retrieved memory. v2 (future) could weight by overlap between
    retrieved_context_ids and the decision's evidence_ids, but that requires
    `evidence_ids` to be the *referenced subset* rather than the *full set*,
    which isn't enforced today.

    Cold-start: empty basis when the window has no decisions. Returns (0.0, []).
    """
    decisions = _get_decisions_in_window(memory, agent_id, domain, window_start)
    if not decisions:
        return 0.0, []

    basis_ids: list[str] = []
    with_context = 0
    for d in decisions:
        iid = _item_id(d)
        if iid:
            basis_ids.append(iid)
        rci = _get_metadata(d).get("retrieved_context_ids") or []
        # FalkorDB list-prop JSON-string defence (mirrors _ensure_list pattern;
        # local inline since this helper isn't imported in evaluation.py).
        if isinstance(rci, str):
            try:
                rci = json.loads(rci)
            except (json.JSONDecodeError, TypeError):
                rci = []
        if isinstance(rci, list) and len(rci) > 0:
            with_context += 1

    if not basis_ids:
        return 0.0, []

    score = with_context / len(basis_ids)
    return score, basis_ids


def _compute_accuracy(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
) -> tuple[float, list[str]]:
    """Success rate over decisions with an observed outcome — CORE-DECISION-OUTCOME-1 D5.

    Score = (success_count + 0.5 * partial_count) / count(decisions with outcome).
    Range: [0, 1]. `partial` outcomes earn half-credit so course-correction is
    not penalised as harshly as outright failure.

    Decisions with `outcome=abandoned` are *excluded* from the denominator —
    they never ran to completion, so counting them as failures would penalise
    agents for cancelling work that should have been cancelled.

    Cold-start: returns (0.0, []) when no decisions have outcomes set. The
    EvaluationEvolver's `min_evidence_count` gate then prevents a zero-noise
    Evaluation item from being written.

    Requires `Decision.outcome` (CORE-DECISION-OUTCOME-1 D1). The first-class
    overlay in `_get_metadata` exposes it as a top-level metadata key.
    """
    decisions = _get_decisions_in_window(memory, agent_id, domain, window_start)

    success = 0
    partial = 0
    scored_basis: list[str] = []
    for d in decisions:
        outcome = _get_metadata(d).get("outcome")
        if outcome not in ("success", "failure", "partial"):
            continue  # `abandoned` and None excluded from denominator
        iid = _item_id(d)
        if iid:
            scored_basis.append(iid)
        if outcome == "success":
            success += 1
        elif outcome == "partial":
            partial += 1

    if not scored_basis:
        return 0.0, []

    score = (success + 0.5 * partial) / len(scored_basis)
    return score, scored_basis


# ---------------------------------------------------------------------------
# Evidence retrieval helpers
# ---------------------------------------------------------------------------


def _get_decisions_in_window(
    memory: Any,
    agent_id: str,
    domain: str,
    window_start: datetime,
    end: datetime | None = None,
) -> list:
    """Fetch decisions for (agent_id, domain) with recorded_at in [window_start, end).

    Returns raw items (MemoryItem or dict) rather than hydrated Decision objects
    so that ``confidence`` is readable from the MemoryItem's first-class field
    (``item.confidence``) or from the raw dict's top-level property.  Hydrating to
    Decision via ``Decision.from_dict(metadata)`` loses ``confidence`` on SQLite
    because the managed-type framework lifts it to a first-class MemoryItem field
    (``_decision_first_class`` in decisions/declaration.py) rather than storing it
    in the metadata dict.

    Strategy:
    1. DecisionQueries._list_decisions_via_graph → raw dicts (FalkorDB) or [] (SQLite)
    2. Fallback to memory.search(memory_type="decision") → raw MemoryItems
    In both cases, filter by agent_id + domain + time window client-side.
    """
    end_dt = end or datetime.now(timezone.utc)
    raw_items = _list_raw_decisions(memory, agent_id, domain)

    result = []
    for item in raw_items:
        # Time window filter
        ts_str = _raw_ts(item)
        recorded_at = _parse_dt(ts_str)
        if recorded_at and window_start <= recorded_at < end_dt:
            result.append(item)
        elif recorded_at is None and end is None:
            # No timestamp — include in open-ended query as best-effort
            result.append(item)
    return result


def _dedup_decision_items(items: list) -> list:
    """Deduplicate decision items returned by SmartGraph.search_nodes.

    The managed-type framework stores each decision as two graph nodes on FalkorDB:
    - A managed node whose ``item_id`` is the deterministic decision_id (``dec_...``)
    - A raw storage node whose ``item_id`` is a UUID

    Both nodes match the ``memory_type="decision"`` predicate, doubling the count.
    This function collapses duplicates by preferring the ``dec_...`` node and
    dropping UUID nodes whose content matches a ``dec_...`` node already seen.

    Items without duplicates (e.g. from SQLite) pass through unchanged.
    """
    import re
    _DEC_RE = re.compile(r"^dec_[0-9a-f]+$")

    # Partition into managed (dec_*) and raw-uuid nodes
    managed: list = []
    raw_uuid: list = []
    for item in items:
        iid = getattr(item, "item_id", None) or (item.get("item_id") if isinstance(item, dict) else None) or ""
        if _DEC_RE.match(str(iid)):
            managed.append(item)
        else:
            raw_uuid.append(item)

    if not managed:
        # No managed nodes present — keep all (SQLite, or FalkorDB without managed type)
        return items

    # Build fingerprint set from managed nodes (content + agent_id)
    def _fp(item: Any) -> str:
        content = getattr(item, "content", None) or (item.get("content") if isinstance(item, dict) else "") or ""
        aid = _get_metadata(item).get("agent_id", "")
        return f"{aid}::{content[:80]}"

    managed_fps = {_fp(i) for i in managed}

    # Accept raw-uuid nodes only if their fingerprint is NOT already covered
    extra = [i for i in raw_uuid if _fp(i) not in managed_fps]
    if extra:
        _logger.debug(
            "EvaluationEvolver: %d raw-uuid decision nodes not matched by managed nodes — keeping",
            len(extra),
        )
    return managed + extra


def _list_raw_decisions(memory: Any, agent_id: str, domain: str) -> list:
    """Return raw decision records (dicts or MemoryItems) for (agent_id, domain).

    Tries graph-direct first (preserves all top-level fields including confidence),
    falls back to search, then DecisionQueries.get_active_decisions as last resort
    (which loses confidence on SQLite but still provides agent_id / domain for
    volume + supersession_rate computation).

    Each returned item has ``confidence`` accessible via:
    - dict item: ``item.get("confidence")``
    - MemoryItem: ``getattr(item, "confidence", None)``  (first-class field)
    - Decision (hydrated fallback): ``getattr(item, "confidence", 0.8)``
    """
    # --- SmartGraph.search_nodes (works on both SQLite and FalkorDB) ---
    # Tries SmartGraph.search_nodes first because it handles workspace scoping
    # internally and works on both backends without needing backend.graph.
    graph = getattr(memory, "_graph", None) or getattr(memory, "graph", None)
    if graph is not None:
        search_nodes_fn = getattr(graph, "search_nodes", None)
        if search_nodes_fn is not None:
            try:
                results = search_nodes_fn({"memory_type": "decision", "agent_id": agent_id})
                items = [
                    i for i in results
                    if _get_metadata(i).get("domain") == domain
                ]
                # Deduplicate: managed-type framework can write two nodes per decision
                # (one with decision_id as item_id, one with UUID as item_id). Prefer
                # the managed-type node (item_id starts with "dec_") and drop UUID
                # duplicates that share the same content fingerprint.
                if items:
                    items = _dedup_decision_items(items)
                if items:
                    return items
            except Exception as e:
                _logger.debug("EvaluationEvolver: SmartGraph.search_nodes decision failed: %s", e)

    # --- Raw Cypher query on FalkorDB ---
    if graph is not None:
        backend = getattr(graph, "backend", None) or getattr(graph, "_backend", None)
        if backend is not None:
            graph_attr = getattr(backend, "graph", None)
            if graph_attr is not None:
                try:
                    scope = getattr(memory, "scope_provider", None) or getattr(
                        memory, "_scope_provider", None
                    )
                    ws_id = None
                    if scope is not None:
                        ws_id = getattr(scope, "workspace_id", None)
                        if not ws_id:
                            try:
                                ws_id = scope.workspace.id
                            except Exception:
                                ws_id = None

                    if ws_id:
                        result = graph_attr.query(
                            "MATCH (n) WHERE n.memory_type = 'decision' "
                            "AND n.agent_id = $agent AND n.domain = $dom "
                            "AND n.workspace_id = $ws "
                            "RETURN n LIMIT 500",
                            {"agent": agent_id, "dom": domain, "ws": ws_id},
                        )
                    else:
                        # SEC-TENANT-QUERIES-1 Phase 8: OSS-mode fall-through.
                        # Bare ``SmartMemory()`` has no tenant boundary; the
                        # unscoped MATCH is safe by construction. Emit marker
                        # WARNING so no-silent-degradation asserters can pin
                        # the case.
                        _logger.warning(
                            "tenant_isolation.scope_missing.eval_decisions: "
                            "no resolvable workspace_id; falling back to "
                            "unscoped MATCH for agent=%r domain=%r (OSS-mode).",
                            agent_id, domain,
                        )
                        result = graph_attr.query(
                            "MATCH (n) WHERE n.memory_type = 'decision' "
                            "AND n.agent_id = $agent AND n.domain = $dom "
                            "RETURN n LIMIT 500",
                            {"agent": agent_id, "dom": domain},
                        )
                    items = []
                    for row in result.result_set:
                        node = row[0]
                        props = node.properties if hasattr(node, "properties") else node
                        items.append(props)
                    if items:
                        return items
                except Exception as e:
                    _logger.debug("EvaluationEvolver: graph decision query failed: %s", e)

    # --- Search fallback (SQLite + FalkorDB) ---
    try:
        raw = memory.search(query=f"decision {domain}", memory_type="decision", top_k=500)
        items = [
            i for i in raw
            if (
                getattr(i, "agent_id", None) == agent_id
                or (isinstance(i, dict) and i.get("agent_id") == agent_id)
                or (_get_metadata(i).get("agent_id") == agent_id)
            )
            and (
                getattr(i, "domain", None) == domain
                or (isinstance(i, dict) and i.get("domain") == domain)
                or (_get_metadata(i).get("domain") == domain)
            )
        ]
        if items:
            return items
    except Exception as e:
        _logger.warning("EvaluationEvolver: search fallback for decisions failed: %s", e)

    # --- Last resort: DecisionQueries.get_active_decisions (hydrated) ---
    try:
        from smartmemory.decisions.queries import DecisionQueries
        queries = DecisionQueries(memory)
        return queries.get_active_decisions(agent_id=agent_id, domain=domain, limit=500)
    except Exception as e:
        _logger.warning("EvaluationEvolver: all decision query paths failed: %s", e)
        return []


def _fallback_decision_search(memory: Any, agent_id: str, domain: str) -> list:
    """Search-based fallback for decision retrieval (logs WARNING)."""
    _logger.warning(
        "EvaluationEvolver: falling back to memory.search() for decisions "
        "(agent=%s domain=%s) — primary query path failed",
        agent_id, domain,
    )
    try:
        items = memory.search(
            query=f"decision {domain}",
            memory_type="decision",
            top_k=200,
        )
        return [
            i for i in items
            if _get_metadata(i).get("agent_id") == agent_id
            and _get_metadata(i).get("domain") == domain
        ]
    except Exception as e:
        _logger.warning("EvaluationEvolver: search fallback also failed: %s", e)
        return []


def _count_superseded_decisions(memory: Any, decisions: list) -> int:
    """Count decisions that have been superseded (have a SUPERSEDED_BY successor).

    Checks the ``superseded`` / ``superseded_by`` metadata fields first
    (O(n), no graph query). This works whether or not the graph edge is live
    because ingest_superseding() always sets both the flag and the edge.
    """
    count = 0
    for d in decisions:
        meta = _get_metadata(d)
        superseded = meta.get("superseded", False)
        superseded_by = meta.get("superseded_by")
        if superseded or superseded_by:
            count += 1
    return count


def _get_opinions_for_agent_domain(memory: Any, agent_id: str, domain: str) -> list:
    """Fetch opinion records for (agent_id, domain).

    Returns raw items (dicts or MemoryItems) with ``reinforcement_count``
    and ``contradiction_count`` accessible via ``_get_metadata``.

    Tries graph-direct query first (FalkorDB), then search fallback.
    Falls back to empty list (with WARNING) only when all paths fail.
    """
    # --- SmartGraph.search_nodes (works on both SQLite and FalkorDB) ---
    # This path preserves reinforcement_count / contradiction_count which are
    # stored as metadata dict keys after update_properties.
    graph = getattr(memory, "_graph", None) or getattr(memory, "graph", None)
    if graph is not None:
        search_nodes_fn = getattr(graph, "search_nodes", None)
        if search_nodes_fn is not None:
            try:
                # Filter by memory_type + agent_id to narrow the scan
                results = search_nodes_fn({"memory_type": "opinion", "agent_id": agent_id})
                items = [
                    i for i in results
                    if _get_metadata(i).get("domain") == domain
                ]
                if items:
                    return items
            except Exception as e:
                _logger.debug("EvaluationEvolver: SmartGraph.search_nodes opinion failed: %s", e)

    # --- Raw Cypher query on FalkorDB (additional path for large-scale) ---
    if graph is not None:
        backend = getattr(graph, "backend", None) or getattr(graph, "_backend", None)
        if backend is not None:
            graph_attr = getattr(backend, "graph", None)
            if graph_attr is not None:
                # SEC-TENANT-QUERIES-1 Phase 8: scope on workspace_id when present.
                scope = getattr(memory, "scope_provider", None) or getattr(memory, "_scope_provider", None)
                ws_id = getattr(scope, "workspace_id", None) if scope is not None else None
                try:
                    if ws_id:
                        result = graph_attr.query(
                            "MATCH (n) WHERE n.memory_type = 'opinion' "
                            "AND n.agent_id = $agent AND n.domain = $dom "
                            "AND n.workspace_id = $ws "
                            "RETURN n LIMIT 200",
                            {"agent": agent_id, "dom": domain, "ws": ws_id},
                        )
                    else:
                        # OSS-mode fall-through; see _list_raw_decisions for rationale.
                        _logger.warning(
                            "tenant_isolation.scope_missing.eval_opinions: "
                            "no resolvable workspace_id; falling back to "
                            "unscoped MATCH for agent=%r domain=%r (OSS-mode).",
                            agent_id, domain,
                        )
                        result = graph_attr.query(
                            "MATCH (n) WHERE n.memory_type = 'opinion' "
                            "AND n.agent_id = $agent AND n.domain = $dom "
                            "RETURN n LIMIT 200",
                            {"agent": agent_id, "dom": domain},
                        )
                    items = []
                    for row in result.result_set:
                        node = row[0]
                        props = node.properties if hasattr(node, "properties") else node
                        items.append(props)
                    if items:
                        return items
                except Exception as e:
                    _logger.debug("EvaluationEvolver: Cypher opinion query failed: %s", e)

    # --- Search fallback (may return 0 on lite hermetic without embeddings) ---
    try:
        raw = memory.search(query=f"opinion {domain}", memory_type="opinion", top_k=200)
        items = [
            i for i in raw
            if (
                _get_metadata(i).get("agent_id") == agent_id
                and _get_metadata(i).get("domain") == domain
            )
        ]
        if items:
            return items
    except Exception as e:
        _logger.debug("EvaluationEvolver: opinion search fallback failed: %s", e)

    _logger.warning(
        "EvaluationEvolver: no opinions found for agent=%s domain=%s — "
        "reinforcement_balance will be 0.0",
        agent_id, domain,
    )
    return []


# ---------------------------------------------------------------------------
# Data access utilities
# ---------------------------------------------------------------------------


def _get_metadata(item: Any) -> dict:
    """Extract a flat metadata dict from a MemoryItem, Decision, Opinion, or dict.

    Handles the managed-type framework's field promotion:
    - ``confidence`` is a first-class MemoryItem field (not in metadata dict for
      decision types — see ``_decision_first_class`` in decisions/declaration.py).
    - Always checks both the metadata dict AND top-level object attributes so
      that ``confidence``, ``agent_id``, etc. are accessible regardless of
      whether the item was returned by the search path (MemoryItem) or
      graph-direct path (dict).
    """
    if isinstance(item, dict):
        # Graph-direct: all fields are top-level in the dict
        return item

    # Build combined dict: metadata dict merged with top-level attributes.
    # Top-level attributes win because they are the "first-class" promotions.
    meta = getattr(item, "metadata", None)
    out: dict = {}
    if isinstance(meta, dict):
        out.update(meta)

    # Overlay first-class fields (confidence is the critical one for decisions).
    # CORE-DECISION-OUTCOME-1 D5: `outcome` joins the overlay so `_compute_accuracy`
    # can read it whether the source is a MemoryItem (declaration first_class_fn),
    # a Decision dataclass instance, or a raw graph dict.
    # CORE-EVAL-DIMENSIONS-11-1: `retrieved_context_ids` joins the overlay so
    # `_compute_context_retention` can see it on Decision (via metadata) AND on
    # MemoryItem (top-level dataclass attr).
    for attr in (
        "agent_id", "domain", "confidence", "reinforcement_count", "contradiction_count",
        "recorded_at", "created_at", "superseded", "superseded_by", "item_id",
        "status", "outcome", "retrieved_context_ids",
    ):
        val = getattr(item, attr, None)
        if val is not None:
            out[attr] = val

    return out


def _item_id(item: Any) -> str | None:
    """Extract item_id from a MemoryItem, Decision, Opinion, or dict."""
    if isinstance(item, dict):
        return item.get("item_id") or item.get("id")
    return getattr(item, "item_id", None)


def _raw_ts(item: Any) -> str:
    """Extract the best available timestamp string from any item representation.

    Decision objects store timestamps as ``created_at`` (datetime); raw dicts
    from graph queries have ``recorded_at`` / ``created_at`` as strings.
    """
    meta = _get_metadata(item)
    ts_str = meta.get("recorded_at") or meta.get("created_at") or ""
    if not ts_str:
        # For Decision objects: created_at is a datetime attribute
        raw_attr = getattr(item, "created_at", None)
        if raw_attr is not None:
            ts_str = raw_attr.isoformat() if hasattr(raw_attr, "isoformat") else str(raw_attr)
    return ts_str


def _parse_dt(raw: str) -> datetime | None:
    """Parse ISO 8601 datetime string; return None on failure."""
    if not raw:
        return None
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _mean_confidence(decisions: list) -> float:
    """Mean confidence across a list of decisions. Returns 0.5 on empty.

    Uses ``_get_metadata`` which merges metadata dict + first-class attributes,
    so ``confidence`` is found whether the item is a raw dict (graph-direct),
    MemoryItem (search path, confidence is a first-class field), or Decision
    (confidence on the dataclass attribute).
    """
    if not decisions:
        return _COLD_START_CONFIDENCE
    values = []
    for d in decisions:
        meta = _get_metadata(d)
        c = meta.get("confidence")
        if c is not None:
            values.append(float(c))
    return sum(values) / len(values) if values else _COLD_START_CONFIDENCE


def _trend(delta: float) -> str:
    """Map a score delta to a trend string."""
    if delta > _EPSILON:
        return "improving"
    if delta < -_EPSILON:
        return "declining"
    return "stable"


def _serialize_basis(ids: list[str]) -> str:
    """JSON-encode a list of basis item_ids for FalkorDB storage."""
    return json.dumps(ids)


# ---------------------------------------------------------------------------
# EvaluationEvolver
# ---------------------------------------------------------------------------


_DIMENSIONS = [
    "decision_volume",
    "supersession_rate",
    "confidence_trajectory",
    "reinforcement_balance",
    "accuracy",  # CORE-DECISION-OUTCOME-1 D5: first design.md-spec'd dimension unlocked
    # CORE-EVAL-DIMENSIONS-11-1: design.md-spec'd dimensions enabled by the
    # CORE-DECISION-OUTCOME-1 unlock. Both rely on the per-dimension cold-start
    # gate at _process_dimension to suppress zero-noise on bootstrap.
    "task_completion_rate",
    "context_retention",
]

_COMPUTE = {
    "decision_volume": _compute_decision_volume,
    "supersession_rate": _compute_supersession_rate,
    "confidence_trajectory": _compute_confidence_trajectory,
    "reinforcement_balance": _compute_reinforcement_balance,
    "accuracy": _compute_accuracy,  # CORE-DECISION-OUTCOME-1 D5
    "task_completion_rate": _compute_task_completion_rate,  # CORE-EVAL-DIMENSIONS-11-1
    "context_retention": _compute_context_retention,  # CORE-EVAL-DIMENSIONS-11-1
}


class EvaluationEvolver(EvolverPlugin):
    """Compute per-agent per-dimension per-domain evaluation scores.

    Evidence sources: ``decision`` and ``opinion`` memories with ``agent_id``
    and ``domain`` fields set (populated by CORE-AGENT-ATTRIBUTION-1).

    Writes ``evaluation`` memories via bi-temporal supersession:
    - First run for a (agent, dim, domain) slot: ``memory.add()`` (bootstrap).
    - Subsequent runs: ``memory.ingest_superseding()`` (append-and-supersede).
    - EVALUATED_BY edge written EXPLICITLY after every write (ingest_superseding
      bypasses managed-type edge_fn callbacks — blueprint correction C3).

    Does NOT call ``check_in_place_rewrite`` — that guard is for in-place
    ``update_properties()`` only, NOT for supersession (blueprint C3 / Codex R2 F3).
    """

    # Batch-only: runs during idle catch-up, not on individual mutation events
    TRIGGERS: set = set()

    @classmethod
    def metadata(cls) -> PluginMetadata:
        return PluginMetadata(
            name="evaluation",
            version="1.0.0",
            author="SmartMemory Team",
            description=(
                "Compute per-agent per-dimension per-domain evaluation scores "
                "from decision+episodic evidence (bi-temporal append)"
            ),
            plugin_type="evolver",
            dependencies=[],
            min_smartmemory_version="0.3.0",
            tags=["evaluation", "agent", "decision", "bi-temporal", "builtin"],
        )

    def __init__(self, config: Optional[EvaluationEvolverConfig] = None):
        self.config = config or EvaluationEvolverConfig()

    def evolve(self, memory: Any, log: Any = None, logger: Any = None) -> EvolverResult:
        """Run one evaluation cycle across all (agent, domain) combinations.

        For each combination that has enough evidence:
        1. Compute the 4 proxy dimension scores.
        2. Check the previous current evaluation (EvaluationQueriesExt.current).
        3. Bootstrap branch: memory.add() if no prior exists.
           Supersede branch: memory.ingest_superseding() if prior exists and delta > epsilon.
        4. Write EVALUATED_BY edge explicitly after every write.

        Args:
            memory: SmartMemory (or SecureSmartMemory) instance.
            log: Optional logger (legacy param name used by some callers).
            logger: Optional logger (used by evolution/cycle.py).

        Returns:
            EvolverResult with created_ids / updated_ids populated.
        """
        log = log or logger or _logger
        cfg = self.config

        with trace_span("pipeline.evolve.evaluation", {"lookback_days": cfg.lookback_days}):
            now = datetime.now(timezone.utc)
            window_start = now - timedelta(days=cfg.lookback_days)

            # Discover all (agent_id, domain) pairs from decisions in the window
            agent_domain_pairs = _discover_agent_domain_pairs(memory, window_start)

            if not agent_domain_pairs:
                log.info("EvaluationEvolver: no agent/domain pairs found — nothing to evaluate")
                return EvolverResult(notes=["no evidence accumulated since last cycle"])

            created_ids: list[str] = []
            updated_ids: list[str] = []

            for agent_id, domain in agent_domain_pairs:
                # Evidence gate: must have at least min_evidence_count decisions
                decisions_in_window = _get_decisions_in_window(
                    memory, agent_id, domain, window_start
                )
                if len(decisions_in_window) < cfg.min_evidence_count:
                    log.debug(
                        "EvaluationEvolver: insufficient evidence for agent=%s domain=%s "
                        "(%d < %d) — skipping",
                        agent_id, domain, len(decisions_in_window), cfg.min_evidence_count,
                    )
                    continue

                for dimension in _DIMENSIONS:
                    try:
                        new_id, prev_id = self._process_dimension(
                            memory=memory,
                            agent_id=agent_id,
                            domain=domain,
                            dimension=dimension,
                            window_start=window_start,
                            now=now,
                            cfg=cfg,
                            log=log,
                        )
                        if new_id:
                            created_ids.append(new_id)
                        if prev_id:
                            updated_ids.append(prev_id)
                    except Exception as e:
                        _logger.warning(
                            "EvaluationEvolver: error processing dimension=%s for "
                            "agent=%s domain=%s — skipping: %s",
                            dimension, agent_id, domain, e,
                        )

            log.info(
                "EvaluationEvolver: cycle complete — %d created, %d updated",
                len(created_ids), len(updated_ids),
            )
            return EvolverResult(
                created_ids=created_ids,
                updated_ids=updated_ids,
                deleted_ids=[],
                stats={
                    "agent_domain_pairs": len(agent_domain_pairs),
                    "dimensions": len(_DIMENSIONS),
                    "lookback_days": cfg.lookback_days,
                },
            )

    def _process_dimension(
        self,
        memory: Any,
        agent_id: str,
        domain: str,
        dimension: str,
        window_start: datetime,
        now: datetime,
        cfg: EvaluationEvolverConfig,
        log: Any,
    ) -> tuple[str | None, str | None]:
        """Compute + write one (agent, dimension, domain) evaluation.

        Returns:
            (new_eval_id | None, prev_eval_id | None).
            new_eval_id is None when |delta| < epsilon (no version written).
        """
        compute_fn = _COMPUTE[dimension]
        score, basis_ids = compute_fn(memory, agent_id, domain, window_start)

        # Query the currently-live evaluation for this slot
        queries = EvaluationQueriesExt(memory)
        prev_eval = queries.current(
            agent_id, dimension, domain,
            decay_after_days=cfg.decay_after_days,
        )
        prev_id = (
            getattr(prev_eval, "evaluation_id", None) or getattr(prev_eval, "item_id", None)
        ) if prev_eval else None
        prev_score = prev_eval.score if prev_eval else cfg.cold_start_score

        # CORE-DECISION-OUTCOME-1 D5: per-dimension cold-start gate. The four
        # v1 proxy dimensions never returned empty basis when the agent/domain
        # gate (min_evidence_count) had opened, because all four read from the
        # full decision/opinion windows. `_compute_accuracy` (and any future
        # dimension that filters by a sparse field like `outcome`) can legitimately
        # return `(0.0, [])` here — no decisions in the window had outcomes set.
        # Without this skip, the evolver would emit a zero-noise Evaluation per
        # cold-start cycle. Bootstrap (no prior) + empty basis → skip the write.
        if not basis_ids and prev_id is None:
            log.debug(
                "EvaluationEvolver: empty basis on bootstrap for %s/%s/%s — skipping (cold-start)",
                agent_id, dimension, domain,
            )
            return None, None

        score_delta = score - prev_score
        if prev_id is not None and abs(score_delta) < _EPSILON:
            log.debug(
                "EvaluationEvolver: delta=%.4f < epsilon for %s/%s/%s — skipping version",
                score_delta, agent_id, dimension, domain,
            )
            return None, None

        # Build the new Evaluation MemoryItem
        now_iso = now.isoformat()
        valid_from_iso = window_start.isoformat()
        trend_str = _trend(score_delta)
        sample_size = len(basis_ids)

        content = (
            f"Evaluation: agent={agent_id} dimension={dimension} domain={domain} "
            f"score={score:.4f} trend={trend_str}"
        )
        new_item = MemoryItem(
            content=content,
            memory_type="evaluation",
            origin="evolver:evaluation",
            metadata={
                # evaluation_id mirrors item_id so that _hydrate / Evaluation.from_dict
                # can round-trip the identifier even though memory.add() stores item_id.
                "evaluation_id": "",  # patched below after item_id is known
                "agent_id": agent_id,
                "dimension": dimension,
                "domain": domain,
                "score": score,
                "score_delta": score_delta,
                "trend": trend_str,
                "basis": _serialize_basis(basis_ids),
                "sample_size": sample_size,
                "valid_from": valid_from_iso,
                "valid_to": None,
                "recorded_at": now_iso,
                "evaluator": "EvaluationEvolver/v1",
                "superseded": False,
            },
        )
        # Patch evaluation_id = item_id so the graph node carries its own key.
        new_item.metadata["evaluation_id"] = new_item.item_id

        # --- Bootstrap branch (Codex R8 F1) ---
        # ingest_superseding() REQUIRES an existing node; raises if prev_id is None.
        if prev_id is None:
            created_id = memory.add(new_item)
            if isinstance(created_id, dict):
                created_id = created_id.get("item_id", new_item.item_id)
            log.debug(
                "EvaluationEvolver: bootstrap write %s/%s/%s → %s",
                agent_id, dimension, domain, created_id,
            )
        else:
            created_id = memory.ingest_superseding(new_item, supersedes=prev_id)
            if isinstance(created_id, dict):
                created_id = created_id.get("item_id", new_item.item_id)
            log.debug(
                "EvaluationEvolver: supersede write %s/%s/%s → %s (prev %s)",
                agent_id, dimension, domain, created_id, prev_id,
            )

        if not created_id:
            _logger.warning(
                "EvaluationEvolver: write returned no ID for %s/%s/%s — "
                "evaluation node may not have been persisted",
                agent_id, dimension, domain,
            )
            return None, prev_id

        # --- Explicit EVALUATED_BY edge (Codex R5 F1, R7 F2, R9 F1) ---
        # Required after BOTH bootstrap and supersede writes.
        # SmartMemory.add_edge uses relation_type= (not edge_type=).
        agent_node_id = agent_item_id_for(agent_id)
        try:
            memory.add_edge(
                source_id=agent_node_id,
                target_id=created_id,
                relation_type="EVALUATED_BY",
                properties={
                    "dimension": dimension,
                    "domain": domain,
                    "recorded_at": now_iso,
                },
            )
        except Exception as e:
            _logger.warning(
                "EvaluationEvolver: add_edge EVALUATED_BY failed for "
                "agent=%s → eval=%s: %s",
                agent_node_id, created_id, e,
            )

        return created_id, prev_id


# ---------------------------------------------------------------------------
# Agent/domain discovery
# ---------------------------------------------------------------------------


def _discover_agent_domain_pairs(
    memory: Any,
    window_start: datetime,
) -> list[tuple[str, str]]:
    """Scan recent decisions to find distinct (agent_id, domain) pairs.

    Falls back to opinion memories if decisions yield nothing.
    Deduplicates and excludes null agent_id.
    """
    pairs: set[tuple[str, str]] = set()

    try:
        from smartmemory.decisions.queries import DecisionQueries

        queries = DecisionQueries(memory)
        decisions = queries.get_active_decisions(limit=1000)
        now = datetime.now(timezone.utc)
        for d in decisions:
            meta = _get_metadata(d)
            agent_id = meta.get("agent_id")
            domain = meta.get("domain")
            if not agent_id or not domain:
                continue
            # Filter by window — if no recorded_at, include conservatively
            recorded_at_raw = meta.get("recorded_at") or meta.get("created_at") or ""
            if recorded_at_raw:
                dt = _parse_dt(recorded_at_raw)
                if dt and dt < window_start:
                    continue
            pairs.add((agent_id, domain))
    except Exception as e:
        _logger.warning(
            "EvaluationEvolver: decision scan failed during discovery: %s", e
        )

    if not pairs:
        # Fallback: scan opinions
        try:
            opinions = memory.search(query="opinion", memory_type="opinion", top_k=500)
            for op in opinions:
                meta = _get_metadata(op)
                agent_id = meta.get("agent_id")
                domain = meta.get("domain")
                if agent_id and domain:
                    pairs.add((agent_id, domain))
        except Exception as e:
            _logger.warning(
                "EvaluationEvolver: opinion fallback during discovery also failed: %s", e
            )

    return sorted(pairs)
