"""Decision lifecycle manager.

Handles creation, supersession, retraction, and conflict detection for decisions.
Path C migration (CORE-MANAGED-TYPE-FRAMEWORK-1 Phase 2): subclass of the
framework-derived `_DecisionManagerBase` with Decision-specific overrides for
first-class MemoryItem fields, rich edge property dicts, and conflict detection.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from smartmemory.decisions.declaration import _DecisionManagerBase

logger = logging.getLogger(__name__)


def __getattr__(name: str):
    """Backward-compat shim — pre-Path-C, Decision was importable from this module
    as a side effect of `from smartmemory.models.decision import Decision`. Some
    callers and tests rely on `from smartmemory.decisions.manager import Decision`.
    Lazy attribute lookup avoids the circular import that a top-level import would
    cause (manager → models.decision → declaration → decisions/__init__ → manager).
    """
    if name == "Decision":
        from smartmemory.models.decision import Decision

        return Decision
    raise AttributeError(f"module 'smartmemory.decisions.manager' has no attribute {name!r}")


class DecisionManager(_DecisionManagerBase):
    """Manage decision lifecycle - creation, supersession, retraction, reinforcement.

    Usage:
        manager = DecisionManager(smart_memory)
        decision = manager.create("User prefers dark mode", decision_type="preference")
        manager.reinforce(decision.decision_id, "evidence_mem_123")
        manager.supersede(decision.decision_id, new_decision, reason="Updated preference")
    """

    # ---- Storage primitives -------------------------------------------
    # Framework's `_store_instance` handles MemoryItem construction including
    # first-class lift of `confidence` and `derived_from` via the declaration's
    # `first_class_fn=_decision_first_class` hook. No override needed.

    def _hydrate(self, decision_id: str):
        """Fetch a Decision by ID and rehydrate from MemoryItem.metadata."""
        item = self.memory.get(decision_id)
        return self._to_decision(item)

    @staticmethod
    def _to_decision(item: Any):
        """Convert a MemoryItem (or dict) to a Decision, with content fallback."""
        from smartmemory.models.decision import Decision

        if item is None:
            return None
        if isinstance(item, Decision):
            return item
        metadata = getattr(item, "metadata", None)
        if isinstance(item, dict):
            metadata = item.get("metadata", item)
        if not isinstance(metadata, dict):
            return None
        if "content" not in metadata or not metadata["content"]:
            content = getattr(item, "content", None) or (item.get("content") if isinstance(item, dict) else "")
            metadata["content"] = content
        return Decision.from_dict(metadata)

    # ---- Public API (preserve named-parameter signatures) --------------

    def create(  # noqa: PLR0913
        self,
        content: str,
        decision_type: str = "inference",
        confidence: float = 0.8,
        source_type: str = "inferred",
        source_trace_id: str | None = None,
        source_session_id: str | None = None,
        evidence_ids: list[str] | None = None,
        domain: str | None = None,
        tags: list[str] | None = None,
        context_snapshot: dict[str, Any] | None = None,
        rejected_alternatives: list[str] | None = None,
        rationale: str | None = None,
        constraints: list[str] | None = None,
        agent_id: str | None = None,
        # CORE-DECISION-OUTCOME-1 D1: result-of-the-decision payload. Orthogonal
        # to lifecycle `status` — see design.md §D2. Default None so legacy callers
        # remain invisible to _compute_accuracy via `outcome IS NOT NULL` filter.
        outcome: str | None = None,
        outcome_metric: dict[str, Any] | None = None,
        outcome_at: "datetime | None" = None,
        # CORE-EVAL-DIMENSIONS-11-1: item_ids retrieved as context before this
        # decision was made. Stamped onto the wrapping MemoryItem's top-level
        # field via update_properties after _store_instance (the Decision
        # dataclass itself does not carry the field — it lives on MemoryItem
        # as a universal first-class attr per CORE-DECISION-OUTCOME-1 D3).
        # _compute_context_retention reads it via _get_metadata overlay.
        retrieved_context_ids: list[str] | None = None,
    ):
        """Create and store a new decision."""
        from smartmemory.models.decision import Decision

        decision = Decision(
            decision_id=Decision.generate_id(),
            content=content,
            decision_type=decision_type,
            confidence=confidence,
            source_type=source_type,
            source_trace_id=source_trace_id,
            source_session_id=source_session_id,
            evidence_ids=evidence_ids or [],
            domain=domain,
            tags=tags or [],
            context_snapshot=context_snapshot,
            rejected_alternatives=rejected_alternatives or [],
            rationale=rationale,
            constraints=constraints or [],
            agent_id=agent_id,
            # CORE-DECISION-OUTCOME-1 D1
            outcome=outcome,
            outcome_metric=outcome_metric,
            outcome_at=outcome_at,
        )

        self._store_instance(decision)

        # CORE-EVAL-DIMENSIONS-11-1: stamp retrieved_context_ids onto the wrapping
        # MemoryItem's top-level node property AFTER initial store. Goes through
        # the regular update_properties path so the FalkorDB list-prop codec and
        # SYSTEM_FIELDS allowlist both kick in correctly. No-op when empty.
        if retrieved_context_ids:
            try:
                self.memory.update_properties(
                    decision.decision_id,
                    {"retrieved_context_ids": list(retrieved_context_ids)},
                )
            except Exception as e:
                logger.warning(
                    "DecisionManager.create: failed to stamp retrieved_context_ids "
                    "on decision %s: %s — context_retention dimension will treat "
                    "this decision as cold.",
                    decision.decision_id, e,
                )

        # Provenance edges — match legacy DecisionManager.create() exactly.
        if source_trace_id and self.graph:
            self.graph.add_edge(
                source_id=source_trace_id,
                target_id=decision.decision_id,
                edge_type="PRODUCED",
                properties={
                    "confidence": 0.5,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "origin": "evolver:decision",
                },
            )

        if evidence_ids:
            for eid in evidence_ids:
                self._add_derived_from_edge(decision.decision_id, eid)

        return decision

    def get_decision(self, decision_id: str):
        """Retrieve a decision by ID. Alias matching legacy public API."""
        return self._hydrate(decision_id)

    # Override framework `.get` to use Decision-specific hydrate.
    def get(self, decision_id: str):
        return self._hydrate(decision_id)

    def supersede(self, old_decision_id: str, new_decision, reason: str):
        """Replace an old decision with a new one.

        Full override (not super()-then-modify) because the SUPERSEDES edge
        needs rich props {reason, timestamp, origin, confidence} and the
        evidence carry-forward semantics differ from the framework default.
        """
        from smartmemory.models.decision import Decision

        old = self._hydrate(old_decision_id)
        if old is None:
            raise ValueError(f"Decision not found: {old_decision_id}")

        # Assign the replacement id BEFORE persisting old.superseded_by,
        # otherwise the old node is committed with a blank pointer while the
        # SUPERSEDES edge later carries the real id — readers that trust the
        # property (incl. the bitemporal audit) would see inconsistent state.
        if not new_decision.decision_id:
            new_decision.decision_id = Decision.generate_id()

        old.status = "superseded"
        old.superseded_by = new_decision.decision_id
        old.updated_at = datetime.now(timezone.utc)
        self._update_decision(old)

        if old_decision_id not in new_decision.evidence_ids:
            new_decision.evidence_ids.append(old_decision_id)

        self._store_instance(new_decision)

        # Single transaction-time boundary clock, shared by the SUPERSEDES
        # edge and the version chain (CORE-BITEMPORAL-1 — do not invent a
        # second clock).
        supersede_ts = datetime.now(timezone.utc)

        if self.graph:
            self.graph.add_edge(
                source_id=new_decision.decision_id,
                target_id=old_decision_id,
                edge_type="SUPERSEDES",
                properties={
                    "reason": reason,
                    "timestamp": supersede_ts.isoformat(),
                    "origin": "evolver:decision",
                    "confidence": 0.5,
                },
            )

        # CORE-BITEMPORAL-1: record the transaction-time version boundary on
        # the OLD (logical) id so as-of queries reconstruct the prior belief.
        # Source created_at from the PERSISTED node, not the hydrated Decision
        # — Decision.from_dict fabricates created_at=now() when absent, which
        # would silently anchor v1 at hydration time. The raw node is honest:
        # real timestamp where it round-trips, None where it does not (the
        # hook then warns instead of degrading silently).
        old_created_at = None
        if self.graph is not None:
            try:
                raw = self.graph.get_node(old_decision_id)
                if raw is not None:
                    old_created_at = getattr(raw, "created_at", None)
                    if old_created_at is None:
                        md = getattr(raw, "metadata", None)
                        if isinstance(md, dict):
                            old_created_at = md.get("created_at") or md.get("reference_time")
            except Exception as e:
                logger.warning("supersede: could not read raw created_at for %s: %s", old_decision_id, e)

        # The logical supersession is already committed above; a version-write
        # failure must be surfaced loudly (no-silent-degradation) but must NOT
        # raise back to the caller and leave them thinking supersession failed.
        # Mirrors the guard at the semantic supersede call sites.
        from smartmemory.temporal.supersession_hook import version_on_supersede

        try:
            version_on_supersede(
                self.graph,
                logical_id=old_decision_id,
                old_content=old.content,
                new_content=new_decision.content,
                reason=reason,
                evidence_ids=new_decision.evidence_ids,
                ts=supersede_ts,
                memory_type="decision",
                old_created_at=old_created_at,
            )
        except Exception as e:
            logger.warning(
                "supersede: bitemporal version chain NOT written for %s "
                "(supersession itself committed); as-of/audit will be "
                "incomplete: %s",
                old_decision_id,
                e,
            )

        return new_decision

    def retract(self, decision_id: str, reason: str) -> None:
        """Retract a decision (mark as no longer valid).

        Writes retraction_reason into context_snapshot, NOT as a top-level
        property — matches legacy behavior at smartmemory/decisions/manager.py:184-188.
        """
        decision = self._hydrate(decision_id)
        if decision is None:
            raise ValueError(f"Decision not found: {decision_id}")

        decision.status = "retracted"
        decision.updated_at = datetime.now(timezone.utc)
        decision.context_snapshot = decision.context_snapshot or {}
        decision.context_snapshot["retraction_reason"] = reason
        self._update_decision(decision)

    def reinforce(self, decision_id: str, evidence_id: str):
        """Record supporting evidence for a decision.

        Full override — DERIVED_FROM edge needs rich props {role, origin, confidence}.
        """
        decision = self._hydrate(decision_id)
        if decision is None:
            raise ValueError(f"Decision not found: {decision_id}")

        decision.reinforce(evidence_id)
        self._update_decision(decision)
        self._add_derived_from_edge(decision_id, evidence_id)

        return decision

    def contradict(self, decision_id: str, evidence_id: str):
        """Record contradicting evidence for a decision.

        Full override — CONTRADICTS edge needs rich props {detected_at, origin, confidence}.
        """
        decision = self._hydrate(decision_id)
        if decision is None:
            raise ValueError(f"Decision not found: {decision_id}")

        decision.contradict(evidence_id)
        self._update_decision(decision)

        if self.graph:
            self.graph.add_edge(
                source_id=evidence_id,
                target_id=decision_id,
                edge_type="CONTRADICTS",
                properties={
                    "detected_at": datetime.now(timezone.utc).isoformat(),
                    "origin": "evolver:decision",
                    "confidence": 0.5,
                },
            )

        return decision

    def find_conflicts(self, decision, limit: int = 10) -> list:
        """Find existing active decisions that may conflict with the given one."""
        try:
            similar = self.memory.search(
                query=decision.content,
                memory_type="decision",
                top_k=limit,
            )
        except Exception as e:
            logger.warning(f"Conflict search failed: {e}")
            return []

        conflicts = []
        for candidate in similar:
            candidate_decision = self._to_decision(candidate)
            if candidate_decision is None:
                continue
            if candidate_decision.decision_id == decision.decision_id:
                continue
            if not candidate_decision.is_active:
                continue
            if decision.domain and candidate_decision.domain == decision.domain:
                conflicts.append(candidate_decision)
            elif self._content_overlap(decision.content, candidate_decision.content):
                conflicts.append(candidate_decision)

        return conflicts

    # ---- Internal helpers ----------------------------------------------

    def _update_decision(self, decision) -> None:
        """Update an existing decision's properties in the graph."""
        try:
            self.memory.update_properties(decision.decision_id, decision.to_dict())
        except Exception as e:
            logger.warning(f"Failed to update decision {decision.decision_id}: {e}")

    def _add_derived_from_edge(self, decision_id: str, evidence_id: str) -> None:
        """Create a DERIVED_FROM edge from decision to evidence."""
        if self.graph:
            try:
                self.graph.add_edge(
                    source_id=decision_id,
                    target_id=evidence_id,
                    edge_type="DERIVED_FROM",
                    properties={"role": "evidence", "origin": "evolver:decision", "confidence": 0.5},
                )
            except Exception as e:
                logger.debug(f"Failed to create DERIVED_FROM edge {decision_id} -> {evidence_id}: {e}")

    @staticmethod
    def _content_overlap(content1: str, content2: str) -> bool:
        """Simple heuristic check for content overlap between two decision statements."""
        words1 = set(content1.lower().split())
        words2 = set(content2.lower().split())
        if not words1 or not words2:
            return False
        overlap = len(words1 & words2) / min(len(words1), len(words2))
        return overlap > 0.5
