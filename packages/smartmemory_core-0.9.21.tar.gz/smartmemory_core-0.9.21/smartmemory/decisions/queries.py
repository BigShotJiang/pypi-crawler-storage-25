"""Decision query patterns.

Path C migration (CORE-MANAGED-TYPE-FRAMEWORK-1 Phase 2): subclass of the
framework-derived `_DecisionQueriesBase`. Domain-specific methods (provenance
chains, causal traversal) stay handwritten; standard list/lookup methods are
inherited from the base.
"""

from __future__ import annotations

import logging
from typing import Any, Literal

from smartmemory.decisions.declaration import _DecisionQueriesBase

logger = logging.getLogger(__name__)


class DecisionQueries(_DecisionQueriesBase):
    """Query patterns for decisions - filtered retrieval, provenance, causal chains.

    Usage:
        queries = DecisionQueries(smart_memory)
        active = queries.get_active_decisions(domain="preferences")
        chain = queries.get_causal_chain(decision_id, direction="causes")
    """

    # ---- Hydration override (content fallback) -------------------------

    def _hydrate(self, item: Any):
        """Convert a MemoryItem (or dict) to a Decision with content fallback.

        Mirrors legacy DecisionQueries._to_decision (queries.py:241-255).
        """
        from smartmemory.models.decision import Decision

        if item is None:
            return None
        if isinstance(item, Decision):
            return item
        metadata = getattr(item, "metadata", None)
        if isinstance(item, dict):
            metadata = item.get("metadata", item)
        if not isinstance(metadata, dict):
            return None
        if "content" not in metadata or not metadata["content"]:
            content = getattr(item, "content", None) or (item.get("content") if isinstance(item, dict) else "")
            metadata["content"] = content
        return Decision.from_dict(metadata)

    # alias used by existing tests
    _to_decision = _hydrate

    # ---- Filtered retrieval (legacy API surface) -----------------------

    def get_active_decisions(
        self,
        domain: str | None = None,
        decision_type: str | None = None,
        min_confidence: float = 0.0,
        limit: int = 50,
        agent_id: str | None = None,
    ) -> list:
        """Get all active decisions, optionally filtered.

        Uses direct graph query first (decisions are INDEXED — no embeddings,
        so search(query="*") is unreliable). Falls back to search() if the
        graph query path isn't available.
        """
        items = self._list_decisions_via_graph(limit * 2)
        if not items:
            try:
                items = self.memory.search(query="*", memory_type="decision", top_k=limit * 2)
            except Exception:
                items = []
            if not items:
                try:
                    items = self.memory.search(query="decision", memory_type="decision", top_k=limit * 2)
                except Exception:
                    items = []
            if not items:
                try:
                    items = self.memory.search(query="decision choice belief policy", top_k=limit * 2)
                    items = [i for i in items if getattr(i, "memory_type", None) == "decision"]
                except Exception as e:
                    logger.warning(f"Failed to search for decisions: {e}")
                    return []

        decisions = []
        for item in items:
            d = self._hydrate(item)
            if d is None or not d.is_active:
                continue
            if domain and d.domain != domain:
                continue
            if decision_type and d.decision_type != decision_type:
                continue
            if d.confidence < min_confidence:
                continue
            # CORE-AGENT-ATTRIBUTION-1: agent_id is an opt-in filter. NULL-valued
            # agent_id rows are excluded when the filter is set (mirrors the
            # `domain` filter's semantics — explicit ask narrows the view).
            if agent_id is not None and getattr(d, "agent_id", None) != agent_id:
                continue
            decisions.append(d)
            if len(decisions) >= limit:
                break

        return decisions

    def _list_decisions_via_graph(self, limit: int) -> list:
        """Direct graph query for decision nodes — bypasses vector search."""
        try:
            graph = getattr(self.memory, "_graph", None) or getattr(self.memory, "graph", None)
            if graph is None:
                return []
            backend = getattr(graph, "backend", None) or getattr(graph, "_backend", None)
            if backend is None:
                return []
            # Scope by workspace if available. Both ``SmartMemory`` and
            # ``SecureSmartMemory`` expose the scope provider as ``scope_provider``
            # (no leading underscore). Previously this read the non-existent
            # ``_scope_provider`` attribute, so ``ws_id`` was always None and the
            # query fell into the unscoped branch below — a cross-tenant leak
            # that only became exploitable once a foreign-identity filter
            # (``agent_id`` from CORE-AGENT-ATTRIBUTION-1) let a caller in
            # tenant B address tenant A's rows. See
            # ``tests/security/test_decision_tenant_isolation.py``.
            scope = getattr(self.memory, "scope_provider", None) or getattr(
                self.memory, "_scope_provider", None
            )
            ws_id = None
            if scope is not None:
                # Prefer the canonical ``workspace_id`` attribute exposed by
                # ``MemoryScopeProvider`` and ``DefaultScopeProvider``. Fall back
                # to ``scope.workspace.id`` for any provider variant that still
                # exposes the nested workspace object.
                ws_id = getattr(scope, "workspace_id", None)
                if not ws_id:
                    try:
                        ws_id = scope.workspace.id
                    except Exception:
                        ws_id = None
            if not ws_id:
                # SEC-TENANT-QUERIES-1 Phase 3 (audit H3): refuse to fall back
                # to the unscoped MATCH. The prior unscoped branch was the
                # exact failure shape that surfaced CORE-AGENT-ATTRIBUTION-1 —
                # a typo on the scope provider attribute let every decision
                # query fall through to an unscoped MATCH that returned cross-
                # tenant rows. Per no-silent-degradation.md the cure is fail-
                # loud (WARNING + empty result), not silent fall-through. OSS-
                # mode legitimately reaches this branch when no workspace was
                # ever configured; the WARNING captures the case and the
                # empty-result keeps OSS bare-SmartMemory() callers working.
                # Service-mode never reaches this branch — SecureSmartMemory's
                # construction-time M2 check guarantees backend.scope_provider
                # is set, and MemoryScopeProvider asserts workspace_id during
                # its own construction.
                logger.warning(
                    "tenant_isolation.scope_missing.decision_queries: "
                    "no resolvable workspace_id on memory.scope_provider; "
                    "returning empty list rather than running unscoped MATCH "
                    "(SEC-TENANT-QUERIES-1 H3)."
                )
                return []
            query = (
                "MATCH (n) WHERE n.memory_type = 'decision' AND n.item_id STARTS WITH 'dec_' "
                "AND n.workspace_id = $ws "
                "RETURN n ORDER BY n.created_at DESC LIMIT $limit"
            )
            result = backend.graph.query(query, {"ws": ws_id, "limit": limit})
            # FalkorDB nodes carry Decision fields as top-level properties
            # (decision_id, status, superseded_by, created_at, ...). _hydrate()'s
            # dict branch falls back to `item.get("metadata", item)`, so passing
            # the raw props dict lets Decision.from_dict() see every field.
            # Wrapping as MemoryItem first would strip the decision-specific fields.
            items = []
            for row in result.result_set:
                node = row[0]
                props = node.properties if hasattr(node, "properties") else node
                items.append(props)
            return items
        except RuntimeError:
            # SEC-TENANT-QUERIES-1 Phase 3: tenant-isolation guard. Must
            # propagate so callers see the failure-loud signal rather than the
            # silent search fallback that hid CORE-AGENT-ATTRIBUTION-1.
            raise
        except Exception as e:
            logger.debug(f"Graph-based decision listing failed, will fall back to search: {e}")
            return []

    def get_decisions_about(self, topic: str, limit: int = 20) -> list:
        """Get active decisions related to a topic via semantic search."""
        try:
            items = self.memory.search(query=topic, memory_type="decision", top_k=limit)
        except Exception as e:
            logger.warning(f"Failed to search decisions for topic '{topic}': {e}")
            return []

        decisions = []
        for item in items:
            d = self._hydrate(item)
            if d is not None and d.is_active:
                decisions.append(d)

        return decisions

    # ---- Graph traversal (domain-specific) -----------------------------

    def get_decision_provenance(self, decision_id: str) -> dict[str, Any]:
        """Get full provenance chain for a decision."""
        result: dict[str, Any] = {
            "decision": None,
            "reasoning_trace": None,
            "evidence": [],
            "superseded": [],
        }

        item = self.memory.get(decision_id)
        if item is None:
            return result
        result["decision"] = self._hydrate(item)

        if not self.graph:
            return result

        incoming = self.graph.get_incoming_neighbors(decision_id, edge_type="PRODUCED")
        if incoming:
            trace_node = incoming[0]
            result["reasoning_trace"] = trace_node

        # SmartGraph.get_neighbors returns [(MemoryItem, edge_type), ...] — unpack
        # the tuple before passing to consumers. Skipping this unwrap silently
        # drops every neighbor: _hydrate(tuple) returns None, and getattr(tuple,
        # "item_id", None) is None too.
        neighbors = self.graph.get_neighbors(decision_id, edge_type="DERIVED_FROM")
        if neighbors:
            for entry in neighbors:
                node = entry[0] if isinstance(entry, tuple) else entry
                node_id = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                result["evidence"].append({
                    "memory": node,
                    "memory_id": node_id,
                })

        superseded = self.graph.get_neighbors(decision_id, edge_type="SUPERSEDES")
        if superseded:
            for entry in superseded:
                node = entry[0] if isinstance(entry, tuple) else entry
                d = self._hydrate(node)
                if d:
                    result["superseded"].append(d)

        return result

    def get_decisions_with_provenance(
        self,
        memory_id: str,
        *,
        max_depth: int = 3,
        limit: int = 50,
        domain: str | None = None,
        decision_type: str | None = None,
        min_confidence: float = 0.0,
        agent_id: str | None = None,
    ) -> list[Any]:
        """Find active decisions whose provenance subgraph contains ``memory_id``.

        Inverse of ``get_decision_provenance``: walks **incoming** ``DERIVED_FROM``
        and ``CAUSED_BY`` edges from the seed memory back toward decisions. Mirrors
        the edge vocabulary of ``_traverse_causes`` but uses
        ``graph.get_incoming_neighbors`` (the inverse direction of the forward walk).

        Scope-gated at both ends via ``self.memory.get()``: the seed memory must be
        visible to the caller (else returns ``[]``), and each candidate decision
        must also be visible before inclusion. Required because ``self.graph`` binds
        to raw ``memory._graph`` and backend traversal is unscoped
        (``framework.py:800``). The dual gate makes this safe to expose at the
        ``GET /memory/decisions?provenance_memory_id=`` route surface without
        leaking cross-workspace existence.

        In-query filter composition: ``domain`` / ``decision_type`` /
        ``min_confidence`` consume candidates **before** they count against
        ``limit``. A call with ``limit=10`` returns exactly 10 matching-and-filtered
        decisions when that many exist, never silently fewer.

        Visited set guards against cycles; ``seen_decisions`` dict guards against
        emitting the same decision twice when multiple provenance paths converge
        on the seed memory. (NB: the pre-existing ``_traverse_causes`` /
        ``_traverse_effects`` at queries.py:239+ lack both — they should be patched
        with the same pattern in a follow-up, but that is out of scope for
        CORE-DECISION-PROVENANCE-LOOKUP-1.)

        **Transitive decision-chain provenance (CORE-DECISION-PROVENANCE-TRANSITIVE-1,
        2026-05-23):** decision-typed intermediates are BOTH recorded in
        ``seen_decisions`` AND traversed-through, so ``D2 CAUSED_BY D1 DERIVED_FROM M``
        returns both ``D1`` and ``D2`` when querying by ``M``. Match-and-continue
        semantic; intermediate decisions count toward ``limit``. A filter-rejected
        intermediate is still traversed through (so chains aren't broken when an
        intermediate doesn't match ``domain=...``), it just isn't emitted.
        """
        # Entry scope gate: verify the seed memory is visible to the caller.
        # Returns [] (not 404 / not raise) for unknown OR out-of-scope ids — these
        # two cases must be indistinguishable to prevent existence leakage.
        seed = self.memory.get(memory_id)
        if seed is None:
            return []
        if not self.graph:
            return []

        visited: set[str] = {memory_id}
        seen_decisions: dict[str, Any] = {}
        queue: list[tuple[str, int]] = [(memory_id, 0)]

        while queue and len(seen_decisions) < limit:
            node_id, depth = queue.pop(0)
            if depth >= max_depth:
                continue

            for edge_type in ("DERIVED_FROM", "CAUSED_BY"):
                try:
                    incoming = self.graph.get_incoming_neighbors(node_id, edge_type=edge_type)
                except Exception as e:
                    logger.warning("get_incoming_neighbors(%s, %s) failed: %s", node_id, edge_type, e)
                    continue

                for neighbor in incoming or []:
                    neighbor_id = (
                        neighbor.get("item_id") if isinstance(neighbor, dict)
                        else getattr(neighbor, "item_id", None)
                    )
                    if not neighbor_id or neighbor_id in visited:
                        continue
                    visited.add(neighbor_id)

                    memory_type = (
                        neighbor.get("memory_type") if isinstance(neighbor, dict)
                        else getattr(neighbor, "memory_type", None)
                    )

                    # Always enqueue for further BFS — non-decision intermediates
                    # are pure routing nodes; decision intermediates ALSO continue
                    # the walk per CORE-DECISION-PROVENANCE-TRANSITIVE-1 so that
                    # `D2 CAUSED_BY D1 DERIVED_FROM M` returns both D1 and D2.
                    # Symmetric with the forward `_traverse_causes` walker, which
                    # recurses through any node type on the same edge vocabulary.
                    queue.append((neighbor_id, depth + 1))

                    if memory_type != "decision":
                        continue
                    # Exit scope gate: re-fetch via SecureSmartMemory so the
                    # caller's scope filter is applied. None ⇒ out of scope ⇒ skip
                    # the emission but the BFS continues through it (the routing
                    # role is unaffected by output scope).
                    item = self.memory.get(neighbor_id)
                    if item is None:
                        continue
                    decision = self._hydrate(item)
                    if decision is None:
                        continue
                    # Active-only (mirrors get_active_decisions default contract).
                    if not getattr(decision, "is_active", True):
                        continue
                    # In-query filter predicates. A filter-rejected decision is
                    # still traversed through (already enqueued above) but is NOT
                    # emitted — keeps chains intact when an intermediate doesn't
                    # match `domain=...`.
                    if domain is not None and getattr(decision, "domain", None) != domain:
                        continue
                    if decision_type is not None and getattr(decision, "decision_type", None) != decision_type:
                        continue
                    if (getattr(decision, "confidence", 0.0) or 0.0) < min_confidence:
                        continue
                    # CORE-AGENT-ATTRIBUTION-1: agent_id filter. Same in-query
                    # placement as the other filters — applied to the candidate
                    # decision, BUT the BFS continues through (already enqueued
                    # above) so chains aren't broken by a non-matching intermediate.
                    if agent_id is not None and getattr(decision, "agent_id", None) != agent_id:
                        continue
                    seen_decisions[neighbor_id] = decision
                    if len(seen_decisions) >= limit:
                        break

                if len(seen_decisions) >= limit:
                    break

        # Match the existing list path's contract: newest-first.
        # (Codex review of the diff 2026-05-23 — without this, BFS edge-enumeration
        # order leaks into the API surface and `limit` becomes non-deterministic.)
        decisions_out = list(seen_decisions.values())
        decisions_out.sort(
            key=lambda d: getattr(d, "created_at", "") or "",
            reverse=True,
        )
        return decisions_out

    def get_causal_chain(
        self,
        decision_id: str,
        direction: Literal["causes", "effects", "both"] = "both",
        max_depth: int = 3,
    ) -> dict[str, Any]:
        """Trace causal chain from a decision."""
        item = self.memory.get(decision_id)
        result: dict[str, Any] = {
            "decision": self._hydrate(item) if item else None,
            "causes": [],
            "effects": [],
        }

        if not self.graph or item is None:
            return result

        if direction in ("causes", "both"):
            result["causes"] = self._traverse_causes(decision_id, max_depth)

        if direction in ("effects", "both"):
            result["effects"] = self._traverse_effects(decision_id, max_depth)

        return result

    def _traverse_causes(self, node_id: str, max_depth: int, current_depth: int = 0) -> list[dict[str, Any]]:
        """Recursively traverse cause edges (DERIVED_FROM, CAUSED_BY)."""
        if current_depth >= max_depth or not self.graph:
            return []

        causes: list[dict[str, Any]] = []

        for edge_type in ["DERIVED_FROM", "CAUSED_BY"]:
            neighbors = self.graph.get_neighbors(node_id, edge_type=edge_type)
            if not neighbors:
                continue
            for node in neighbors:
                node_id_val = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                causes.append({
                    "node": node,
                    "node_id": node_id_val,
                    "relationship": edge_type,
                    "depth": current_depth + 1,
                    "causes": self._traverse_causes(node_id_val, max_depth, current_depth + 1) if node_id_val else [],
                })

        return causes

    def _traverse_effects(self, node_id: str, max_depth: int, current_depth: int = 0) -> list[dict[str, Any]]:
        """Recursively traverse effect edges (CAUSES, INFLUENCES, PRODUCED)."""
        if current_depth >= max_depth or not self.graph:
            return []

        effects: list[dict[str, Any]] = []

        for edge_type in ["CAUSES", "INFLUENCES", "PRODUCED"]:
            neighbors = self.graph.get_neighbors(node_id, edge_type=edge_type)
            if not neighbors:
                continue
            for node in neighbors:
                node_id_val = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                effects.append({
                    "node": node,
                    "node_id": node_id_val,
                    "relationship": edge_type,
                    "depth": current_depth + 1,
                    "effects": self._traverse_effects(node_id_val, max_depth, current_depth + 1) if node_id_val else [],
                })

        return effects
