"""Evaluation memory type — CORE-AGENT-2 Slice S01.

Provides the ``Evaluation`` dataclass, ``EvaluationQueriesExt``, and the
``_EVALUATION_TYPE`` ManagedType declaration.
"""
