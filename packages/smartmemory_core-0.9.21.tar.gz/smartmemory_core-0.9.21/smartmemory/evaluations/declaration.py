"""ManagedType declaration for the ``evaluation`` memory type — CORE-AGENT-2 S01.

Evaluation records capture per-(agent, dimension, domain) performance scores
produced by the EvaluationEvolver (S02).  They are INDEXED (no embeddings)
and bi-temporal: each supersession writes a VERSIONED_TYPES chain via
``supersession_hook.version_on_supersede``.

Deterministic IDs: sha256(agent_id/dimension/domain/valid_from)[:12] →
"eval_<12 hex chars>".  This lets the evolver idempotently address the same
slot across runs without a full-table scan.

Blueprint gotchas (C1-C11):
- Currency predicate is ``superseded == False``, NOT ``valid_to is None``.
- ``basis`` needs an explicit serializer/deserializer (FalkorDB list-prop gap).
- ``superseded_by`` is reserved by the framework — do NOT declare it.
- Origin: "evolver:evaluation" → Tier 2 (recall + search visible).
- VERSIONED_TYPES in supersession_hook.py MUST include "evaluation".
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from smartmemory.managed import Field, ManagedType


# --- basis field codec (FalkorDB list-prop serialization gap) ---------------


def _serialize_basis(lst: list[str] | None) -> str:
    """Encode a list of evidence item_ids as a JSON string for FalkorDB storage."""
    return json.dumps(lst or [])


def _deserialize_basis(raw: Any) -> list[str]:
    """Decode a FalkorDB-stored basis value (JSON string or plain list)."""
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(x) for x in parsed]
        except (json.JSONDecodeError, TypeError):
            pass
    return []


# --- deterministic ID generator ---------------------------------------------


def _evaluation_id_generator(fields: dict[str, Any]) -> str:
    """Deterministic evaluation ID: sha256(agent_id/dimension/domain/valid_from)[:12]."""
    raw = (
        f"{fields.get('agent_id', '')}/"
        f"{fields.get('dimension', '')}/"
        f"{fields.get('domain', '')}/"
        f"{fields.get('valid_from', '')}"
    )
    return f"eval_{hashlib.sha256(raw.encode()).hexdigest()[:12]}"


# --- ManagedType declaration -------------------------------------------------


_EVALUATION_TYPE = ManagedType(
    name="evaluation",
    fields={
        # Identity triple: (agent_id, dimension, domain) is the unique slot
        "agent_id": Field(str, indexed=True),
        "dimension": Field(str, indexed=True),
        "domain": Field(str, indexed=True),
        # Score payload
        "score": Field(float, default=0.0),
        "score_delta": Field(float, default=0.0),
        "trend": Field(str, default="stable"),
        "basis": Field(
            list,
            serializer=_serialize_basis,
            deserializer=_deserialize_basis,
        ),
        "sample_size": Field(int, default=0),
        # Temporal bounds
        "valid_from": Field(str),
        "valid_to": Field(str, optional=True),
        "recorded_at": Field(str),
        # Producer tag
        "evaluator": Field(str, default="EvaluationEvolver/v1"),
        # Bi-temporal supersession flags
        # NOTE: superseded_by is RESERVED by the framework — do NOT declare it here.
        "superseded": Field(bool, optional=True, default=False),
        "superseded_at": Field(str, optional=True),
    },
    lifecycle="extended",  # adds reinforcement_count, contradiction_count, etc.
    id_field="evaluation_id",
    id_generator=_evaluation_id_generator,
    origin="evolver:evaluation",
    handler_origin="evolver:evaluation",
    index_specs=[
        "CREATE INDEX ON :evaluation(agent_id)",
        "CREATE INDEX ON :evaluation(dimension)",
        "CREATE INDEX ON :evaluation(domain)",
        "CREATE INDEX ON :evaluation(superseded)",
    ],
    describe_summary=(
        "Evaluation records — INDEXED, per-(agent, dimension, domain) performance "
        "scores produced by EvaluationEvolver; bi-temporal with supersession; "
        "recall + search visible (Tier 2)."
    ),
)

_EvaluationBase, _EvaluationHandlerBase, _EvaluationManagerBase, _EvaluationQueriesBase = (
    _EVALUATION_TYPE.derive()
)
