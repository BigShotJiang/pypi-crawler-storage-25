"""Evaluation query patterns — CORE-AGENT-2 S01.

Extends the framework-generated ``_EvaluationQueriesBase`` with:
- ``current(agent_id, dimension, domain)`` — live (non-superseded) record
  with optional freshness decay gate.
- ``history(agent_id, dimension, domain)`` — full supersession timeline.
- ``_list_evaluations_via_graph(limit)`` — mirrors
  ``DecisionQueries._list_decisions_via_graph`` exactly (workspace-scoped
  Cypher query against FalkorDB backend, fallback to search).

Blueprint notes:
- Currency predicate is ``superseded == False``, NOT ``valid_to is None``.
- INDEXED type — ``memory.search(query="*")`` is unreliable; graph query first.
- workspace_id read from ``scope_provider.workspace_id`` (no leading underscore).
- Never return [] silently from a fallback — log WARNING first.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from smartmemory.evaluations.declaration import _EvaluationQueriesBase

logger = logging.getLogger(__name__)


class EvaluationQueriesExt(_EvaluationQueriesBase):
    """Query patterns for evaluation records.

    Usage::

        queries = EvaluationQueriesExt(smart_memory)
        live = queries.current(agent_id="agent_xyz", dimension="decision_volume", domain="general")
        timeline = queries.history(agent_id="agent_xyz", dimension="decision_volume", domain="general")
    """

    # --- Hydration -----------------------------------------------------------

    def _hydrate(self, item: Any):
        """Convert a MemoryItem, dict, or Evaluation node to an Evaluation instance."""
        from smartmemory.models.evaluation import Evaluation

        if item is None:
            return None
        if isinstance(item, Evaluation):
            return item
        metadata = getattr(item, "metadata", None)
        if isinstance(item, dict):
            metadata = item.get("metadata", item)
        if not isinstance(metadata, dict):
            return None
        # Promote content from MemoryItem if missing from metadata
        if "content" not in metadata or not metadata["content"]:
            content = getattr(item, "content", None) or (
                item.get("content") if isinstance(item, dict) else ""
            )
            metadata["content"] = content
        return Evaluation.from_dict(metadata)

    # --- Currency query -------------------------------------------------------

    def current(
        self,
        agent_id: str,
        dimension: str,
        domain: str,
        *,
        decay_after_days: int = 30,
    ) -> "Evaluation | None":
        """Return the live (non-superseded) evaluation for this slot, or None.

        A result is also discarded when ``recorded_at`` is older than
        ``decay_after_days`` — the evolver has gone silent, so the score is
        stale and should not be surfaced.

        Currency predicate: ``superseded == False`` (blueprint C1).

        Args:
            agent_id: Agent whose scores are being queried.
            dimension: Performance dimension (e.g. "decision_volume").
            domain: Domain the score applies to (e.g. "general").
            decay_after_days: Drop results older than this many days (default 30).

        Returns:
            The current Evaluation, or None if no live record exists or all are stale.
        """
        candidates = self._list_evaluations_via_graph(limit=100)
        now = datetime.now(timezone.utc)

        live = []
        for raw in candidates:
            ev = self._hydrate(raw)
            if ev is None:
                continue
            if ev.agent_id != agent_id:
                continue
            if ev.dimension != dimension:
                continue
            if ev.domain != domain:
                continue
            if getattr(ev, "superseded", False):
                continue  # blueprint C1: currency is superseded==False
            live.append(ev)

        if not live:
            return None

        # Sort descending by recorded_at; take the most recent
        def _dt(ev: Any) -> datetime:
            raw = getattr(ev, "recorded_at", None) or ""
            try:
                d = datetime.fromisoformat(raw.replace("Z", "+00:00"))
                return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
            except Exception:
                return datetime.min.replace(tzinfo=timezone.utc)

        live.sort(key=_dt, reverse=True)
        best = live[0]

        # Freshness gate
        best_dt = _dt(best)
        if best_dt != datetime.min.replace(tzinfo=timezone.utc):
            age_days = (now - best_dt).days
            if age_days > decay_after_days:
                logger.debug(
                    "evaluation.current: slot (%s/%s/%s) is stale (%d days > %d) — returning None",
                    agent_id, dimension, domain, age_days, decay_after_days,
                )
                return None

        return best

    # --- History query -------------------------------------------------------

    def history(
        self,
        agent_id: str,
        dimension: str,
        domain: str,
        limit: int = 20,
    ) -> list:
        """Return full supersession timeline for this slot, newest first.

        No freshness filter — history always surfaces all records.

        Args:
            agent_id: Agent identifier.
            dimension: Performance dimension.
            domain: Domain.
            limit: Maximum records to return.

        Returns:
            List of Evaluation instances, sorted recorded_at descending.
        """
        candidates = self._list_evaluations_via_graph(limit=limit * 5)
        results = []
        for raw in candidates:
            ev = self._hydrate(raw)
            if ev is None:
                continue
            if ev.agent_id != agent_id:
                continue
            if ev.dimension != dimension:
                continue
            if ev.domain != domain:
                continue
            results.append(ev)
            if len(results) >= limit:
                break
        return results

    # --- Graph-direct listing (mirrors DecisionQueries._list_decisions_via_graph) ---

    def _list_evaluations_via_graph(self, limit: int) -> list:
        """Workspace-scoped Cypher query for evaluation nodes.

        INDEXED type — vector search is unreliable; graph query is the primary
        path.  Mirrors ``DecisionQueries._list_decisions_via_graph`` exactly,
        including the workspace scoping fix (scope_provider.workspace_id, no
        leading underscore).

        Never returns [] silently — falls back through three search tiers,
        logging WARNING before each degradation.
        """
        try:
            graph = getattr(self.memory, "_graph", None) or getattr(self.memory, "graph", None)
            if graph is None:
                return []
            backend = getattr(graph, "backend", None) or getattr(graph, "_backend", None)
            if backend is None:
                return []

            # Workspace scoping — read from scope_provider.workspace_id (no leading
            # underscore; per ScopeProvider-has-no-get_scope() memory note).
            scope = getattr(self.memory, "scope_provider", None) or getattr(
                self.memory, "_scope_provider", None
            )
            ws_id = None
            if scope is not None:
                ws_id = getattr(scope, "workspace_id", None)
                if not ws_id:
                    try:
                        ws_id = scope.workspace.id
                    except Exception:
                        ws_id = None

            if ws_id:
                query = (
                    "MATCH (n) WHERE n.memory_type = 'evaluation' "
                    "AND n.workspace_id = $ws "
                    "RETURN n ORDER BY n.recorded_at DESC LIMIT $limit"
                )
                result = backend.graph.query(query, {"ws": ws_id, "limit": limit})
            else:
                # SEC-TENANT-QUERIES-1 Phase 8: OSS-mode fall-through. The
                # bare ``SmartMemory()`` use case (no scope_provider) has no
                # tenant boundary by construction, so the unscoped MATCH is
                # safe. Emit a marker WARNING so the no-silent-degradation
                # asserters can pin the case, and add this callsite to the
                # contract test's allowlist as the explicit OSS-mode escape.
                logger.warning(
                    "tenant_isolation.scope_missing.evaluation_queries: "
                    "no resolvable workspace_id; falling back to unscoped "
                    "MATCH (OSS-mode bare-SmartMemory). SEC-TENANT-QUERIES-1 H3."
                )
                result = backend.graph.query(
                    "MATCH (n) WHERE n.memory_type = 'evaluation' "
                    "RETURN n ORDER BY n.recorded_at DESC LIMIT $limit",
                    {"limit": limit},
                )

            items = []
            for row in result.result_set:
                node = row[0]
                props = node.properties if hasattr(node, "properties") else node
                items.append(props)
            return items

        except Exception as e:
            logger.debug("Graph-based evaluation listing failed, falling back to search: %s", e)
            return self._fallback_search(limit)

    def _fallback_search(self, limit: int) -> list:
        """Three-tier search fallback when graph query is unavailable.

        Logs WARNING before each degradation (no-silent-degradation rule).
        Never returns [] without a log.
        """
        # Tier 1: typed search
        try:
            results = self.memory.search(query="*", memory_type="evaluation", top_k=limit)
            if results:
                return results
        except Exception as e:
            logger.warning(
                "evaluation._fallback_search tier-1 failed: %s — trying tier-2", e
            )

        # Tier 2: keyword search
        try:
            results = self.memory.search(query="evaluation score dimension domain", top_k=limit)
            if results:
                typed = [r for r in results if getattr(r, "memory_type", None) == "evaluation"]
                if typed:
                    return typed
        except Exception as e:
            logger.warning(
                "evaluation._fallback_search tier-2 failed: %s — returning []", e
            )

        logger.warning(
            "evaluation._fallback_search: all tiers exhausted — returning [] "
            "(INDEXED type, graph backend unavailable)"
        )
        return []
