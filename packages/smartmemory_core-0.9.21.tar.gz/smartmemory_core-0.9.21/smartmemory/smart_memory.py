import logging
import subprocess
import time
from contextlib import contextmanager
from typing import TYPE_CHECKING, Optional, Union, Any, Dict, List

if TYPE_CHECKING:
    from smartmemory.code.models import IndexResult

from smartmemory.activation.constants import ACTIVATION_FLOOR, DEFAULT_SCORE as ACTIVATION_DEFAULT_SCORE
from smartmemory.activation.score import compute_activation_score
from smartmemory.conversation.context import ConversationContext
from smartmemory.memory.pipeline.config import PipelineConfigBundle
from smartmemory.observability.tracing import trace_span
from smartmemory.graph.smartgraph import SmartGraph
from smartmemory.integration.archive.archive_provider import get_archive_provider
from smartmemory.memory.base import MemoryBase
from smartmemory.memory.ingestion.flow import MemoryIngestionFlow
from smartmemory.memory.pipeline.stages.crud import CRUD
from smartmemory.memory.pipeline.stages.enrichment import Enrichment
from smartmemory.memory.pipeline.stages.evolution import EvolutionOrchestrator
from smartmemory.memory.pipeline.stages.graph_operations import GraphOperations
from smartmemory.memory.pipeline.stages.grounding import Grounding
from smartmemory.memory.pipeline.stages.linking import Linking
from smartmemory.memory.pipeline.stages.monitoring import Monitoring
from smartmemory.memory.pipeline.stages.personalization import Personalization
from smartmemory.memory.pipeline.stages.search import Search
from smartmemory.clustering.global_cluster import GlobalClustering
from smartmemory.temporal.queries import TemporalQueries
from smartmemory.temporal.version_tracker import VersionTracker
from smartmemory.models.memory_item import MemoryItem
from smartmemory.plugins.resolvers.external_resolver import ExternalResolver
from smartmemory.interfaces import ScopeProvider
from smartmemory.managers.debug import DebugManager
from smartmemory.managers.enrichment import EnrichmentManager
from smartmemory.managers.evolution import EvolutionManager
from smartmemory.managers.monitoring import MonitoringManager
from smartmemory.procedure_matcher import ProcedureMatcher
from smartmemory.drift_detector import DriftDetector, DriftDetectorConfig
from smartmemory.graph.ontology_graph import OntologyGraph

logger = logging.getLogger(__name__)

# CORE-SYS2-1d: PRODUCED edge target types allowed by schema_validator.py:568
_PRODUCED_ALLOWED_TARGETS: frozenset = frozenset({"decision", "semantic", "episodic", "procedural", "zettel"})


# ---------------------------------------------------------------------------
# Surfacing API helpers (CORE-MEMORY-DYNAMICS-1 M1a)
# ---------------------------------------------------------------------------


class BudgetTooSmall(ValueError):
    """Raised by ``SmartMemory.get_working_context`` when ``max_tokens`` is
    smaller than the smallest mandatory item's token count.  Mapped to the
    contract's ``budget_too_small`` error code at the API boundary.
    """


class IngestPaused(RuntimeError):
    """Raised by ``SmartMemory.ingest`` family when the workspace's
    ``:MigrationState.ingest_paused`` flag is set.

    The flag is owned by the ontology unification migration script
    (``scripts/migrate_ontology_unify.py``, plan §340 / ONTO-RECONCILE-1)
    and is flipped on for the duration of the maintenance window so that
    live writes cannot interleave with the relabel passes and corrupt
    the schema (e.g. a write creating an ``:EntityType`` row halfway
    through Pass 1's ``:OntologyType`` relabel).

    Recovery (e.g. after an interrupted migration) is via the script's
    ``--unpause-ingest --workspace <id>`` CLI flag.
    """


def _estimate_tokens(text: str) -> int:
    """Cheap per-item token estimate — 1 token ≈ 4 characters.  Matches the
    contract's "per-item token count estimated from content length" note.
    """
    if not text:
        return 0
    return max(1, len(text) // 4)


def _recency_weight(metadata: Dict[str, Any]) -> float:
    """Return a 0–1 recency weight derived from metadata timestamps.  Falls
    back to 0.5 when no timestamp is available — deterministic neutral
    weight for the M1 stub ranker.  Full activation-weighted ranking ships
    in M2a.
    """
    from datetime import datetime, timezone

    ts = (
        metadata.get("last_boost_at")
        or metadata.get("updated_at")
        or metadata.get("created_at")
        or metadata.get("timestamp")
    )
    if not ts:
        return 0.5
    try:
        dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return 0.5
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    age_hours = max(0.0, (now - dt).total_seconds() / 3600.0)
    # Exponential half-life of 24h.
    import math

    return math.exp(-age_hours / 24.0)


def _freshness_boost(
    metadata: Dict[str, Any],
    window_hours: int,
    weight: float,
) -> float:
    """Linear-decay freshness boost for items younger than ``window_hours``.

    Returns ``(1 - age_hours/window_hours) × weight`` for items within the
    window, 0 for older items or items with no usable timestamp. This is
    an *additive* lift — it doesn't penalize older items, just boosts
    the fresh ones.
    """
    from datetime import datetime, timezone

    ts = metadata.get("created_at") or metadata.get("updated_at")
    if not ts:
        return 0.0
    try:
        dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return 0.0
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    age_hours = max(0.0, (now - dt).total_seconds() / 3600.0)
    if age_hours >= window_hours:
        return 0.0
    return (1.0 - age_hours / float(window_hours)) * float(weight)


def _apply_pipeline_profile(config: Any, profile: Any) -> None:
    """Copy lite-mode flags from a PipelineConfig profile onto a freshly-built config.

    Copies the 7 fields that SmartMemory Lite needs to override:
    coreference.enabled, extraction.llm_extract.enabled, enrich.enricher_names,
    enrich.wikidata.enabled, enrich.wikidata.sparql_enabled,
    evolve.run_evolution, evolve.run_clustering.
    """
    config.coreference.enabled = profile.coreference.enabled
    config.extraction.llm_extract.enabled = profile.extraction.llm_extract.enabled
    config.enrich.enricher_names = profile.enrich.enricher_names
    config.enrich.wikidata.enabled = profile.enrich.wikidata.enabled
    config.enrich.wikidata.sparql_enabled = profile.enrich.wikidata.sparql_enabled
    config.evolve.run_evolution = profile.evolve.run_evolution
    config.evolve.run_clustering = profile.evolve.run_clustering
    # RLM-1d: Propagate model router from profile if set
    if getattr(profile, "model_router", None) is not None:
        config.model_router = profile.model_router
    # CORE-EVENT-EXTRACT-1: Propagate store.accumulation from profile
    if hasattr(profile, "store") and hasattr(profile.store, "accumulation"):
        config.store.accumulation = profile.store.accumulation


class SmartMemory(MemoryBase):
    """
    Unified agentic memory store combining semantic, episodic, procedural, and working memory.
    Delegates responsibilities to submodules for store management, linking, enrichment, grounding, and personalization.

    API:
        ingest(item) - Full agentic pipeline: extract → store → link → enrich → ground → evolve.
                       Use for user-facing ingestion with all processing stages.
        add(item)    - Simple storage: normalize → store → embed.
                       Use for internal operations, derived items, and when pipeline is not needed.

    All linking operations should be accessed via SmartMemory methods only.
    Do not use Linking directly; it is an internal implementation detail.
    """

    def __init__(
        self,
        scope_provider: Optional[ScopeProvider] = None,
        *args,
        # Optional dependency injection (all default to None = create defaults)
        graph: Optional["SmartGraph"] = None,
        crud: Optional["CRUD"] = None,
        search: Optional["Search"] = None,
        linking: Optional["Linking"] = None,
        enrichment: Optional["Enrichment"] = None,
        grounding: Optional["Grounding"] = None,
        personalization: Optional["Personalization"] = None,
        monitoring: Optional["Monitoring"] = None,
        evolution: Optional["EvolutionOrchestrator"] = None,
        clustering: Optional["GlobalClustering"] = None,
        external_resolver: Optional["ExternalResolver"] = None,
        version_tracker: Optional["VersionTracker"] = None,
        temporal: Optional["TemporalQueries"] = None,
        enable_ontology: bool = True,
        vector_backend=None,
        cache=None,
        observability: bool = True,
        pipeline_profile: Optional[Any] = None,
        entity_ruler_patterns=None,
        ontology_store=None,  # DIST-FULL-LOCAL-1: InMemoryOntologyStore for local mode
        event_sink=None,  # DIST-LITE-3: InProcessQueueSink or None
        public_knowledge_store=None,  # ONTO-PUB-1: PublicKnowledgeStore or None
        trajectory_log_dir: str | None = None,  # RLM-1a
        compaction: str | None = None,  # RLM-1b: "standard" | "aggressive" | None (disabled)
        tier_compaction: bool = False,  # CORE-MEMORY-DYNAMICS-1 M2b Slice B: progressive tier compaction
        model_router=None,  # RLM-1d: PipelineModelRouter or None
        reranker_config=None,  # CORE-RERANK-1: RerankerConfig or None
        discoverability: bool = True,  # SELF-IMPROVE-2: post-link structural scoring
        search_gate_config=None,  # CORE-GATE-1: SearchGateConfig or None
        semantic_hop_config=None,  # CORE-MULTIHOP-2: SemanticHopConfig or None
        attention_fusion=None,  # CORE-ATTENTION-FUSION-1: AttentionFusionConfig or None
        surfacing_mode: str = "legacy",  # M3 Slice A: "legacy" | "router"
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        # CORE-MEMORY-DYNAMICS-1 M3 Slice A — surfacing mode gates the
        # SurfacingRouter and the new composite wiring. Default "legacy"
        # preserves M1a behaviour byte-for-byte for every existing caller.
        if surfacing_mode not in ("legacy", "router"):
            raise ValueError(
                f"surfacing_mode must be 'legacy' or 'router', got {surfacing_mode!r}",
            )
        self._surfacing_mode = surfacing_mode
        # Populated by get_working_context for observability/testing. Stays
        # None on legacy-mode memories that never surface.
        self.last_surfacing_decision = None
        self._ontology_store = ontology_store
        # DIST-FULL-LOCAL-1: when an ontology store is injected, enable ontology
        # so the full ontology block runs. The block uses ontology_store instead
        # of creating FalkorDB OntologyGraph — one code path for both modes.
        self._enable_ontology = enable_ontology or (ontology_store is not None)
        self._vector_backend = vector_backend
        self._cache = cache
        self._observability = observability
        self._pipeline_profile = pipeline_profile
        self._entity_ruler_patterns = entity_ruler_patterns
        self._event_sink = event_sink  # DIST-LITE-3
        self._trajectory_log_dir = trajectory_log_dir  # RLM-1a
        self._compaction = compaction  # RLM-1b
        self._tier_compaction = tier_compaction  # M2b Slice B — opt-in tier progression
        self._model_router = model_router  # RLM-1d
        self._discoverability = discoverability  # SELF-IMPROVE-2
        # CORE-GATE-1: search relevance gate
        from smartmemory.pipeline.config import SearchGateConfig

        self._search_gate_config = search_gate_config or SearchGateConfig()
        # CORE-RERANK-1: search reranking config
        from smartmemory.search.rerank import RerankerConfig

        self._reranker_config = reranker_config or RerankerConfig()
        # CORE-MULTIHOP-2 Phase 2: semantic hop planning config
        self._semantic_hop_config = semantic_hop_config
        # CORE-ATTENTION-FUSION-1: query-conditioned hop attention config
        self._attention_fusion = attention_fusion

        # Use DefaultScopeProvider if none provided (for OSS usage)
        # Service layer should always provide a secure ScopeProvider
        if scope_provider is None:
            # Lazy import to avoid circular dependency
            from smartmemory.scope_provider import DefaultScopeProvider

            scope_provider = DefaultScopeProvider()

        self.scope_provider = scope_provider  # Store for use in filtering methods
        self._graph = graph or SmartGraph(scope_provider=scope_provider)
        # M3 Slice C.4 — register post-write hook so ANY graph mutation
        # (via SmartMemory wrapper, internal pipeline code, evolvers, or
        # any code that holds a SmartGraph reference) invalidates the
        # PPR cache. Write-hook approach replaces the per-wrapper
        # invalidation calls that only covered SmartMemory's own public
        # methods (Codex Slice-C r2 finding).
        try:
            self._graph.register_write_hook(self._invalidate_ppr_cache_for_workspace)
        except Exception as exc:
            logger.debug(
                "Could not register PPR cache invalidation hook on graph (cache may stay stale): %s",
                exc,
            )

        # ONTO-PUB-1: Public knowledge store — mode-aware bootstrap
        if public_knowledge_store is not None:
            self._public_knowledge_store = public_knowledge_store
        else:
            self._public_knowledge_store = self._default_public_knowledge_store()

        # CORE-EVO-LIVE-1: Evolution queue for incremental evolution
        self._evolution_queue = None
        self._evolution_worker = None
        try:
            from smartmemory.evolution.queue import EvolutionQueue

            self._evolution_queue = EvolutionQueue()
        except Exception:
            pass

        # Initialize stages with proper delegation (use injected or create defaults)
        self._graph_ops = GraphOperations(self._graph)
        self._crud = crud or CRUD(self._graph, evolution_queue=self._evolution_queue, smart_memory=self)
        self._linking = linking or Linking(self._graph)
        self._enrichment = enrichment or Enrichment(self._graph)
        self._grounding = grounding or Grounding(self._graph)
        self._personalization = personalization or Personalization(self._graph)
        self._search = search or Search(self._graph)
        self._monitoring = monitoring or Monitoring(self._graph)
        self._evolution = evolution or EvolutionOrchestrator(self)
        self._clustering = clustering or GlobalClustering(self)
        self._external_resolver = external_resolver or ExternalResolver()

        # Initialize temporal queries with scope_provider for tenant isolation
        self.version_tracker = version_tracker or VersionTracker(self._graph, scope_provider=self.scope_provider)
        self.temporal = temporal or TemporalQueries(self, scope_provider=self.scope_provider)
        self._temporal_context = None  # For time-travel context manager

        # Defer flow construction until needed (lazy)
        self._ingestion_flow = None
        self._pipeline_runner = None
        self._pipeline_pattern_manager = None  # CODE-DEV-4: stored in _create_pipeline_runner()
        # CFS-1/CFS-2: Mutable state from the most recent ingest() call.
        # NOT thread-safe — each concurrent request must use its own SmartMemory instance.
        # SecureSmartMemory creates a per-request instance, satisfying this requirement.
        self._last_token_summary: dict | None = None
        self._last_trajectory = None  # RLM-1a: PipelineTrajectory | None
        self._last_search_diagnostics = None  # SEARCH-MULTIHOP-CLEANUP-1: dict | None
        # OL-2/OL-3/OL-4: Ontology pipeline results from the most recent ingest() call.
        self._last_entities: list = []
        self._last_relations: list = []
        self._last_ontology_version: str = ""
        self._last_ontology_registry_id: str = ""
        self._last_unresolved_entities: list = []
        self._last_constraint_violations: list = []
        self._procedure_matcher = ProcedureMatcher(self)
        self._last_procedure_match = None
        self._drift_detector = DriftDetector(providers=[], config=DriftDetectorConfig())

        # Set self on graph search module for SSG traversal.
        # Use _search_helper explicitly because self._graph.search is now the
        # method wrapper, not the helper instance.
        self._graph._search_helper.set_smart_memory(self)

        # Initialize sub-managers
        self._monitoring_mgr = MonitoringManager(self._monitoring)
        self._evolution_mgr = EvolutionManager(self._evolution, self._clustering)
        self._debug_mgr = DebugManager(self._graph, self._search, self.scope_provider)
        self._enrichment_mgr = EnrichmentManager(self._enrichment, self._grounding, self._external_resolver)

        # CORE-EVENT-EXTRACT-1: Wire AccumulationConfig into backend for multi-value property accumulation.
        # Prefer pipeline_profile's config if available, else use defaults.
        try:
            from smartmemory.pipeline.config import AccumulationConfig

            backend = getattr(self._graph, "backend", None)
            if backend and hasattr(backend, "set_accumulation_config"):
                accum_config = None
                if self._pipeline_profile and hasattr(self._pipeline_profile, "store"):
                    accum_config = getattr(self._pipeline_profile.store, "accumulation", None)
                if accum_config is None:
                    accum_config = AccumulationConfig()
                backend.set_accumulation_config(accum_config)
        except Exception:
            pass  # accumulation config wiring failure must not block startup

        # CORE-ENTITY-RESOLVE-1: Wire EntityResolver into FalkorDB backend for fuzzy search.
        # Config stored as instance attr so AliasLinkStage can share it.
        self._entity_resolve_config = None
        try:
            from smartmemory.graph.backends.falkordb import FalkorDBBackend
            from smartmemory.search.entity_resolve import EntityResolver, EntityResolveConfig

            self._entity_resolve_config = EntityResolveConfig()
            backend = getattr(self._graph, "backend", None)
            if isinstance(backend, FalkorDBBackend):
                resolver = EntityResolver(config=self._entity_resolve_config, backend=backend)
                backend.set_entity_resolver(resolver, config=self._entity_resolve_config)
        except Exception:
            pass  # Non-fatal: fuzzy tier simply won't activate

        # CORE-EVO-LIVE-1: Do NOT start worker eagerly in __init__.
        # Worker is lazy-started on first CRUD mutation via _ensure_evolution_worker().

    @property
    def graph(self):
        """Access to underlying graph storage."""
        return self._graph

    # =========================================================================
    # CORE-EVO-LIVE-1: Evolution worker lifecycle
    # =========================================================================

    def _ensure_evolution_worker(self) -> None:
        """Lazy-start the evolution worker daemon thread on first mutation.

        Respects the pipeline profile's run_evolution flag — if evolution is
        disabled (e.g. preview mode), the worker is not started.
        """
        if self._evolution_worker is not None and self._evolution_worker.is_active:
            return
        if self._evolution_queue is None:
            return
        # Respect evolution config — don't start if explicitly disabled
        if self._pipeline_profile is not None and not self._pipeline_profile.evolve.run_evolution:
            return
        try:
            from smartmemory.evolution.router import EvolutionRouter
            from smartmemory.evolution.worker import EvolutionWorker
            from smartmemory.plugins.manager import get_plugin_manager

            # Collect evolver instances with TRIGGERS
            plugin_manager = get_plugin_manager()
            registry = plugin_manager.registry
            evolver_names = registry.list_plugins("evolver")
            evolvers = []
            for name in evolver_names:
                evolver_class = registry.get_evolver(name)
                if evolver_class and getattr(evolver_class, "TRIGGERS", set()):
                    try:
                        evolvers.append(evolver_class())
                    except Exception as exc:
                        logger.debug("SmartMemory: failed to instantiate evolver %s: %s", name, exc)

            if not evolvers:
                return  # No incremental evolvers registered

            router = EvolutionRouter(evolvers)

            # Get backend and compute layer
            backend = getattr(self._graph, "backend", None)
            if backend is None:
                return
            graph_compute = getattr(backend, "_compute", None)
            if graph_compute is None:
                return

            self._evolution_worker = EvolutionWorker(
                queue=self._evolution_queue,
                router=router,
                backend=backend,
                graph=graph_compute,
                memory=self,
            )
            self._evolution_worker.ensure_started()
            logger.debug("SmartMemory: evolution worker started")
        except Exception as exc:
            logger.debug("SmartMemory: failed to start evolution worker: %s", exc)

    def close(self) -> None:
        """Shutdown background workers and release resources.

        Shuts down the evolution worker first (drain + join), then closes
        the backend. This ensures no worker thread operates on a closed
        connection.
        """
        if self._evolution_worker is not None:
            self._evolution_worker.shutdown(drain=True, timeout=10.0)
            # Block until thread actually exits before closing backend
            if self._evolution_worker.is_alive():
                logger.warning("SmartMemory.close: evolution worker still alive after shutdown — forcing")
            self._evolution_worker = None

        # Close ontology store before graph backend (may share the same SQLite file)
        if self._ontology_store is not None and hasattr(self._ontology_store, "close"):
            try:
                self._ontology_store.close()
            except Exception:
                pass

        backend = getattr(self._graph, "backend", None)
        if backend is not None and hasattr(backend, "close"):
            backend.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # =========================================================================
    # Pipeline v2 assembly
    # =========================================================================

    def _create_pipeline_runner(self):
        """Assemble the v2 pipeline runner from stage wrappers."""
        from smartmemory.pipeline.runner import PipelineRunner
        from smartmemory.pipeline.transport import InProcessTransport
        from smartmemory.pipeline.stages.classify import ClassifyStage
        from smartmemory.pipeline.stages.coreference import CoreferenceStageCommand
        from smartmemory.pipeline.stages.simplify import SimplifyStage
        from smartmemory.pipeline.stages.entity_ruler import EntityRulerStage
        from smartmemory.pipeline.stages.llm_extract import LLMExtractStage
        from smartmemory.pipeline.stages.ontology_constrain import OntologyConstrainStage
        from smartmemory.pipeline.stages.supersede import SupersedeStage
        from smartmemory.pipeline.stages.store import StoreStage
        from smartmemory.pipeline.stages.link import LinkStage
        from smartmemory.pipeline.stages.enrich import EnrichStage
        from smartmemory.pipeline.stages.ground import GroundStage
        from smartmemory.pipeline.stages.evolve import EvolveStage
        from smartmemory.memory.ingestion.enrichment import EnrichmentPipeline
        from smartmemory.memory.ingestion.observer import IngestionObserver

        # Reuse the existing ingestion flow for classify (it has the logic)
        if self._ingestion_flow is None:
            self._ingestion_flow = MemoryIngestionFlow(self, linking=self._linking, enrichment=self._enrichment)

        # Build enrichment pipeline
        observer = IngestionObserver()
        enrichment_pipeline = EnrichmentPipeline(self, self._enrichment, observer)

        # Resolve workspace_id for ontology and metrics.
        # SEC-TENANT-QUERIES-1 Phase 1 fix: prior code probed a phantom
        # ``self.scope_provider.get_scope()`` inside a bare ``try/except``;
        # ``get_scope()`` is not on the provider contract so every call
        # raised AttributeError and ``workspace_id`` silently stayed
        # ``"default"``, collapsing the ontology graph for ALL tenants to
        # ``ws_default_ontology``. Use the resolver. ``"default"`` is kept
        # only as the genuine OSS-mode fallback (helper returns None).
        workspace_id = self._resolve_scope_workspace_id() or "default"

        # Ontology block: ontology graph/store, registry, pattern manager, entity pair
        # cache, promotion queue. Uses injected ontology_store when available (local mode),
        # falls back to FalkorDB OntologyGraph (server mode).
        ontology_constrain_stage = None
        pattern_manager = None
        if self._enable_ontology:
            # DIST-FULL-LOCAL-1: use injected store (SQLiteOntologyStore) or
            # create FalkorDB OntologyGraph. Same code path for both.
            ontology_graph = self._ontology_store or OntologyGraph(workspace_id=workspace_id)

            # OL-2/OL-3: OntologyRegistry for version tracking (optional — requires MongoDB)
            from smartmemory.ontology.registry import OntologyRegistry

            ontology_registry = None
            ontology_snapshot = None
            try:
                ontology_registry = OntologyRegistry(config=None, scope_provider=self.scope_provider)
            except Exception:
                pass
            if ontology_registry:
                try:
                    snap = ontology_registry.get_snapshot("default")
                    from smartmemory.ontology.models import Ontology

                    ontology_snapshot = Ontology.from_dict(snap.get("snapshot", {}))
                except Exception:
                    pass

            # Phase 4: PatternManager for learned entity pattern dictionary scan.
            # FalkorDBPatternStore wraps ontology_graph — works on both FalkorDB
            # and SQLiteOntologyStore since both implement add_entity_pattern/get_entity_patterns.
            from smartmemory.ontology.pattern_manager import PatternManager

            try:
                from smartmemory.ontology.falkordb_pattern_store import FalkorDBPatternStore

                pattern_manager = PatternManager(
                    FalkorDBPatternStore(ontology_graph),
                    workspace_id=workspace_id,
                    redis_client=self._ruler_reload_redis_client(),  # C4: enable hot-reload
                )
            except Exception:
                # FalkorDBPatternStore may fail on SQLite store — fall through to
                # injected entity_ruler_patterns below
                pass
            if pattern_manager is not None:
                self._pipeline_pattern_manager = pattern_manager

            # Phase 4: EntityPairCache for relation caching
            from smartmemory.ontology.entity_pair_cache import EntityPairCache

            entity_pair_cache = EntityPairCache()

            # Phase 4: Promotion queue (optional — requires Redis)
            promotion_queue = None
            try:
                from smartmemory.observability.events import RedisStreamQueue

                promotion_queue = RedisStreamQueue.for_promote()
            except Exception:
                pass

            from smartmemory.relations.normalizer import RelationNormalizer
            from smartmemory.relations.validator import TypePairValidator

            # CORE-EXT-1c: Load workspace-promoted relation overlays
            workspace_aliases = None
            workspace_type_pairs = None
            try:
                from smartmemory.relations.overlays import load_workspace_overlays

                workspace_aliases, workspace_type_pairs = load_workspace_overlays(ontology_graph)
            except Exception:
                pass  # graceful — seed types still work without overlays

            relation_normalizer = RelationNormalizer(
                workspace_aliases=workspace_aliases or None,
            )
            type_pair_validator = TypePairValidator(
                mode="permissive",
                workspace_type_pairs=workspace_type_pairs or None,
            )

            # Store references for reload_relation_overlays() + extraction_worker
            self._ontology_graph = ontology_graph
            self._relation_normalizer = relation_normalizer
            self._type_pair_validator = type_pair_validator

            # ONTO-RECONCILE-1 Task 5: construct the unified OntologyService
            # and wire it into the stage so all ontology reads/writes from
            # the ingest pipeline flow through one mediation point.
            #
            # Workspace binding (Codex review 2026-05-03 Finding 3):
            # `OntologyService.__init__` reads `getattr(scope_provider,
            # "workspace_id", None)` directly. Many real ScopeProvider
            # implementations (notably `DefaultScopeProvider()` with no
            # explicit workspace) leave that attribute None and only
            # resolve workspace via `get_scope()`. Without an explicit
            # workspace_id on the provider, `EvidenceStore` and
            # `Promoter` never initialize and Path A writes raise.
            #
            # Bind a workspace-pinned `DefaultScopeProvider` to the
            # service that mirrors the resolved `workspace_id` already
            # used to construct the ontology graph (line 494-499 above).
            # User_id is forwarded from the original provider so audit
            # actor resolution stays accurate.
            from smartmemory.ontology.service import OntologyService
            from smartmemory.scope_provider import DefaultScopeProvider

            # SEC-TENANT-QUERIES-1 Phase 1 fix: same phantom-get_scope() bug
            # as the workspace_id site above. Use the dedicated resolver so
            # the audit-actor user_id is read from the provider's documented
            # attribute, not silently dropped.
            user_id = self._resolve_scope_user_id()

            service_scope = DefaultScopeProvider(
                workspace_id=workspace_id,
                user_id=user_id,
            )
            ontology_service = OntologyService(
                scope_provider=service_scope,
                ontology_graph=ontology_graph,
                ontology_registry=ontology_registry,
            )
            self._ontology_service = ontology_service

            ontology_constrain_stage = OntologyConstrainStage(
                ontology_graph,
                promotion_queue=promotion_queue,
                entity_pair_cache=entity_pair_cache,
                ontology_registry=ontology_registry,
                ontology_model=ontology_snapshot,
                relation_normalizer=relation_normalizer,
                type_pair_validator=type_pair_validator,
                pattern_manager=pattern_manager,
                ontology_service=ontology_service,
            )
            self._ontology_constrain_stage = ontology_constrain_stage

        # Allow injected pattern manager to override (PatternManager with JSONLPatternStore in Lite
        # mode, where enable_ontology=False leaves pattern_manager=None after the block above).
        if self._entity_ruler_patterns is not None:
            pattern_manager = self._entity_ruler_patterns

        from smartmemory.pipeline.stages.reasoning_detect import ReasoningDetectStage

        from smartmemory.pipeline.stages.temporal_resolve import TemporalResolveStage

        stages = [
            ClassifyStage(self._ingestion_flow),
            CoreferenceStageCommand(),
            SimplifyStage(),
            TemporalResolveStage(),  # CORE-TEMPORAL-RESOLVE-1: shift-left date resolution
            EntityRulerStage(pattern_manager=pattern_manager, public_knowledge_store=self._public_knowledge_store),
            LLMExtractStage(),
            ReasoningDetectStage(),  # CORE-SYS2-1c
        ]
        if ontology_constrain_stage is not None:
            stages.append(ontology_constrain_stage)
        from smartmemory.pipeline.stages.compact import CompactionStage

        from smartmemory.pipeline.stages.discoverability import DiscoverabilityStage

        from smartmemory.pipeline.stages.alias_link import AliasLinkStage

        from smartmemory.pipeline.stages.consolidation_router import ConsolidationRouterStage

        stages += [
            ConsolidationRouterStage(),  # CORE-MEMORY-DYNAMICS-1 M1a: observational routing
            StoreStage(self),
            SupersedeStage(self),  # CORE-SUPERSEDE-1: contradiction-aware fact supersession
            CompactionStage(),  # RLM-1b: strip intermediates after store
            LinkStage(self._linking),
            AliasLinkStage(self._graph, entity_resolve_config=self._entity_resolve_config),  # CORE-ENTITY-RESOLVE-1
        ]
        if self._discoverability:
            stages.append(DiscoverabilityStage(self))  # SELF-IMPROVE-2: post-link structural scoring
        stages += [
            EnrichStage(enrichment_pipeline),
            GroundStage(self, public_knowledge_store=self._public_knowledge_store),
            EvolveStage(self),
        ]

        return PipelineRunner(stages, InProcessTransport())

    @property
    def last_token_summary(self) -> dict | None:
        """Token usage summary from the most recent ``ingest()`` call, or None."""
        return self._last_token_summary

    @property
    def last_trajectory(self):
        """Pipeline trajectory from the most recent ``ingest()`` call, or None."""
        return self._last_trajectory

    @property
    def last_search_diagnostics(self) -> dict | None:
        """Per-search cleanup diagnostics from the most recent multi-hop ``search(..., cleanup=True)`` call.

        SEARCH-MULTIHOP-CLEANUP-1. Shape::

            {
                "query": str,
                "max_hops": int,
                "hops_executed": int,
                "cleanup_enabled": bool,
                "hops": [
                    {"hop_num": int, "query": str, "elapsed_ms": float,
                     "results": int, "cleanup": {resolved_count, unresolved_count,
                                                  ambiguous_count, refusal_count} | None},
                    ...
                ],
            }

        Returns ``None`` when no cleanup-enabled search has run yet, or when
        the most recent search did not enable cleanup. JSON-serializable for
        downstream trajectory persistence.
        """
        return getattr(self, "_last_search_diagnostics", None)

    @property
    def last_procedure_match(self):
        """Procedure match result from the most recent ``ingest()`` call, or None."""
        return self._last_procedure_match

    @property
    def last_entities(self) -> list:
        """Extracted entities from the most recent ``ingest()`` call."""
        return self._last_entities

    @property
    def last_relations(self) -> list:
        """Extracted relations from the most recent ``ingest()`` call."""
        return self._last_relations

    @property
    def last_ontology_version(self) -> str:
        """Ontology version from the most recent ``ingest()`` call."""
        return self._last_ontology_version

    @property
    def last_ontology_registry_id(self) -> str:
        """Ontology registry ID from the most recent ``ingest()`` call."""
        return self._last_ontology_registry_id

    @property
    def last_unresolved_entities(self) -> list:
        """Unresolved entities from the most recent ``ingest()`` call."""
        return self._last_unresolved_entities

    @property
    def last_constraint_violations(self) -> list:
        """Constraint violations from the most recent ``ingest()`` call."""
        return self._last_constraint_violations

    @property
    def procedure_matcher(self) -> ProcedureMatcher:
        """Access to the procedure matcher for configuration."""
        return self._procedure_matcher

    @property
    def drift_detector(self) -> DriftDetector:
        """Access to the drift detector for configuration."""
        return self._drift_detector

    # =========================================================================
    # Batch ingestion (RLM-1e)
    # =========================================================================

    async def ingest_batch(self, items, max_concurrent: int = 8, **ingest_kwargs):
        """Ingest multiple items concurrently.

        Uses ``asyncio.TaskGroup`` + ``Semaphore`` + ``to_thread`` to run
        ``ingest()`` for each item in a separate thread.  All keyword
        arguments are forwarded to ``ingest()`` per item.

        Returns ``BatchIngestResponse`` with results list and aggregate metrics.
        """
        from smartmemory.batch import ingest_batch

        return await ingest_batch(self, items, max_concurrent=max_concurrent, **ingest_kwargs)

    def ingest_batch_sync(self, items, max_concurrent: int = 8, **ingest_kwargs):
        """Synchronous wrapper around ``ingest_batch()``.

        Uses ``asyncio.run()`` — must not be called from within an existing event loop.
        Returns ``BatchIngestResponse`` with results list and aggregate metrics.
        """
        import asyncio

        return asyncio.run(self.ingest_batch(items, max_concurrent=max_concurrent, **ingest_kwargs))

    async def ingest_conversation(
        self,
        turns: list,
        session_boundaries: list = None,
        conversation_id: str = None,
        session_dates: list = None,
        turns_per_chunk: int = 15,
        max_chunk_chars: int = 12000,
        max_concurrent: int = 4,
        write_context: dict = None,
        **ingest_kwargs,
    ):
        """Ingest a conversation as session chunks through the full pipeline (RLM-1g)."""
        from smartmemory.conversation.bulk_ingest import ingest_conversation

        return await ingest_conversation(
            self,
            turns,
            session_boundaries=session_boundaries,
            conversation_id=conversation_id,
            session_dates=session_dates,
            turns_per_chunk=turns_per_chunk,
            max_chunk_chars=max_chunk_chars,
            max_concurrent=max_concurrent,
            write_context=write_context,
            **ingest_kwargs,
        )

    def ingest_conversation_sync(
        self,
        turns: list,
        session_boundaries: list = None,
        conversation_id: str = None,
        session_dates: list = None,
        turns_per_chunk: int = 15,
        max_chunk_chars: int = 12000,
        max_concurrent: int = 4,
        write_context: dict = None,
        **ingest_kwargs,
    ):
        """Synchronous wrapper for ingest_conversation() (RLM-1g)."""
        import asyncio

        return asyncio.run(
            self.ingest_conversation(
                turns,
                session_boundaries=session_boundaries,
                conversation_id=conversation_id,
                session_dates=session_dates,
                turns_per_chunk=turns_per_chunk,
                max_chunk_chars=max_chunk_chars,
                max_concurrent=max_concurrent,
                write_context=write_context,
                **ingest_kwargs,
            )
        )

    def create_pipeline_runner(self):
        """Create a configured PipelineRunner for breakpoint execution.

        Public API for Studio and other consumers that need run_to()/run_from().
        Returns cached runner instance (stateless — state flows through PipelineState).
        """
        if self._pipeline_runner is None:
            self._pipeline_runner = self._create_pipeline_runner()
        return self._pipeline_runner

    def reload_relation_overlays(self) -> None:
        """Reload workspace-promoted relation types into normalizer and validator.

        Called after RelationDiscoveryService.auto_promote() to pick up
        newly promoted relation types without creating a new SmartMemory instance.
        Updates both the normalizer and validator, then patches the
        OntologyConstrainStage's references so the next ingest() uses them.

        No-op when ontology is disabled or pipeline hasn't been built yet.
        """
        ontology_graph = getattr(self, "_ontology_graph", None)
        if ontology_graph is None:
            return

        from smartmemory.relations.normalizer import RelationNormalizer
        from smartmemory.relations.validator import TypePairValidator

        workspace_aliases = None
        workspace_type_pairs = None
        try:
            from smartmemory.relations.overlays import load_workspace_overlays

            workspace_aliases, workspace_type_pairs = load_workspace_overlays(ontology_graph)
        except Exception:
            return  # nothing to reload

        self._relation_normalizer = RelationNormalizer(
            workspace_aliases=workspace_aliases or None,
        )
        self._type_pair_validator = TypePairValidator(
            mode="permissive",
            workspace_type_pairs=workspace_type_pairs or None,
        )

        # Patch the OntologyConstrainStage so the next ingest() uses the new instances
        stage = getattr(self, "_ontology_constrain_stage", None)
        if stage is not None:
            stage._relation_normalizer = self._relation_normalizer
            stage._type_pair_validator = self._type_pair_validator

    def _default_public_knowledge_store(self):
        """Auto-bootstrap the appropriate PublicKnowledgeStore based on available infra.

        Mode detection uses self._graph (already constructed) — NOT an independent
        FalkorDB probe. If the graph is FalkorDB-backed, we're in service mode and
        MUST use FalkorDBPublicKnowledgeStore. No silent fallback to SQLite in
        service mode — that would create split-brain absorptions.
        """
        from smartmemory.graph.backends.falkordb import FalkorDBBackend

        is_service_mode = isinstance(getattr(self._graph, "backend", None), FalkorDBBackend)

        if is_service_mode:
            from smartmemory.grounding.falkordb_store import FalkorDBPublicKnowledgeStore

            return FalkorDBPublicKnowledgeStore()

        # Local mode — bundled SQLite snapshot
        try:
            from importlib.resources import files

            snapshot_path = files("smartmemory.data.public_knowledge") / "public_entities.sqlite"
            if snapshot_path.is_file():
                from smartmemory.grounding.sqlite_store import SQLitePublicKnowledgeStore

                return SQLitePublicKnowledgeStore(str(snapshot_path))
        except Exception:
            pass

        return None

    def _resolve_scope_workspace_id(self) -> Optional[str]:
        """Resolve the active workspace_id from the scope provider.

        ``get_scope()`` is **not** part of the ``ScopeProvider`` contract —
        no implementation (``DefaultScopeProvider``, ``MemoryScopeProvider``)
        defines it; the provider exposes ``workspace_id`` directly. We still
        probe ``get_scope()`` first for any future provider that adds it,
        then fall back to the documented bare-provider attribute. Returns
        ``None`` only for genuinely unscoped (OSS single-user) providers —
        callers must not coerce that to ``"default"`` (it would pollute
        tenant-scoped token/cost economics; see OBS-TOKEN-ATTR-1).
        """
        workspace_id = None
        get_scope = getattr(self.scope_provider, "get_scope", None)
        if callable(get_scope):
            try:
                workspace_id = getattr(get_scope(), "workspace_id", None)
            except Exception:
                logger.warning(
                    "scope_provider.get_scope() raised; falling back to "
                    "scope_provider.workspace_id for workspace attribution"
                )
        if not workspace_id:
            workspace_id = getattr(self.scope_provider, "workspace_id", None)
        return workspace_id

    def _resolve_scope_user_id(self) -> Optional[str]:
        """Resolve the active user_id from the scope provider.

        Sibling of ``_resolve_scope_workspace_id``. ``get_scope()`` is not
        part of the provider contract — read ``user_id`` directly. Returns
        ``None`` for OSS-mode providers; callers must not coerce that to
        a literal user_id (audit actor resolution would silently attribute
        actions to a non-existent user).

        SEC-TENANT-QUERIES-1 Phase 1: introduced so that the three
        ``smart_memory.py`` callsites that previously probed the phantom
        ``get_scope()`` inside a bare ``try/except`` (and silently kept
        the default fallback) read the real value uniformly.
        """
        return getattr(self.scope_provider, "user_id", None)

    def _build_pipeline_config(
        self,
        extractor_name=None,
        enricher_names=None,
        pipeline_config=None,
        sync=True,
        extract_decisions: bool = False,
        extract_reasoning: bool = False,
    ):
        """Map legacy ingest() parameters to a v2 PipelineConfig."""
        from smartmemory.pipeline.config import PipelineConfig

        config = PipelineConfig()

        if pipeline_config is not None:
            # Merge legacy PipelineConfigBundle fields into v2 config
            if pipeline_config.extraction and pipeline_config.extraction.extractor_name:
                config.extraction.extractor_name = pipeline_config.extraction.extractor_name
            if pipeline_config.extraction and pipeline_config.extraction.model:
                config.extraction.llm_extract.model = pipeline_config.extraction.model

        if extractor_name:
            config.extraction.extractor_name = extractor_name
        if enricher_names:
            config.enrich.enricher_names = list(enricher_names)
        if not sync:
            config.mode = "async"

        # Pull workspace from scope provider (OBS-TOKEN-ATTR-1)
        config.workspace_id = self._resolve_scope_workspace_id()

        # Apply constructor-injected pipeline profile (e.g. PipelineConfig.lite())
        if self._pipeline_profile is not None:
            _apply_pipeline_profile(config, self._pipeline_profile)
            # RLM-1a: Propagate profile_name from injected profile
            config.profile_name = getattr(self._pipeline_profile, "profile_name", "custom")

        # RLM-1a: Wire trajectory log_dir from constructor
        if self._trajectory_log_dir:
            config.trajectory.log_dir = self._trajectory_log_dir

        # RLM-1b: Wire compaction from constructor
        if self._compaction:
            config.compaction.enabled = True
            config.compaction.level = self._compaction

        # RLM-1d: Wire model router from constructor
        if self._model_router:
            config.model_router = self._model_router

        # SELF-IMPROVE-2: Wire discoverability config from constructor
        if not self._discoverability:
            from smartmemory.pipeline.stages.discoverability import DiscoverabilityConfig

            config.discoverability = DiscoverabilityConfig(enabled=False)

        # Caller flags override profiles — stamp AFTER profile application
        if extract_decisions:
            config.extraction.llm_extract.extract_decisions = True
        if extract_reasoning:
            config.extraction.reasoning_detect.enabled = True

        return config

    # =========================================================================
    # Dependency injection context (CORE-DI-1)
    # =========================================================================

    @contextmanager
    def _di_context(self):
        """Activate per-instance dependency overrides for the duration of one operation.

        Sets ContextVars for cache, vector_backend, observability, and event_sink so
        all downstream consumers (get_cache(), VectorStore(), _is_enabled(), emit_event())
        see this instance's configuration without mutating any process-wide global.
        Replaces the global-setter approach used before CORE-DI-1.
        """
        resets: list = []
        try:
            # Always set all four vars unconditionally so nested _di_context() calls
            # from default-config instances cannot inherit an outer instance's overrides.
            from smartmemory.utils.cache import _cache_ctx

            resets.append((_cache_ctx, _cache_ctx.set(self._cache)))

            from smartmemory.stores.vector.vector_store import _vector_backend_ctx

            resets.append((_vector_backend_ctx, _vector_backend_ctx.set(self._vector_backend)))

            from smartmemory.observability.tracing import _observability_ctx

            # None → use env default (observability=True); False → disabled
            resets.append((_observability_ctx, _observability_ctx.set(None if self._observability else False)))

            from smartmemory.observability.events import _current_sink

            resets.append((_current_sink, _current_sink.set(self._event_sink)))

            from smartmemory.grounding.store import _public_knowledge_ctx

            resets.append(
                (_public_knowledge_ctx, _public_knowledge_ctx.set(getattr(self, "_public_knowledge_store", None)))
            )

            yield
        finally:
            for var, token in reversed(resets):
                var.reset(token)

    # =========================================================================
    # Core operations (ingest, add, get, search, update, delete, link)
    # These stay inline as the hot path.
    # =========================================================================

    def _check_ingest_paused(self) -> None:
        """Raise ``IngestPaused`` if the workspace's migration window is open.

        Reads ``:MigrationState.ingest_paused`` for the current scope's
        workspace_id. Failure to reach the graph is treated as "not paused"
        — we don't want a transient FalkorDB blip to wedge the entire
        ingest path. The migration script sets the flag synchronously
        before its first relabel pass, so a missed read here is a
        narrow window that doesn't cost correctness for typical
        sub-second ingests.

        Workspace-id resolution: delegates to
        ``self._resolve_scope_workspace_id()`` (SEC-TENANT-QUERIES-1 Phase 1
        unified the three sites that previously inlined the buggy
        ``try: scope_provider.get_scope(); except Exception: pass`` pattern
        and silently fell back to ``"default"`` for every tenant). The
        ``or "default"`` here is the genuine OSS-mode fallback — the helper
        returns ``None`` only when the provider has no ``workspace_id`` at
        all, in which case the pause toggle deliberately targets the
        single shared OSS bucket.

        Known limitations (Codex review 2026-05-04):

          * **TOCTOU race (acknowledged, by-design):** the check is a
            one-shot read at API entry. If the migration script flips
            ``ingest_paused=true`` AFTER this check returns but BEFORE
            the pipeline's first graph mutation, that ingest will write
            during the maintenance window. This is the "maintenance
            window contract" not a hard lock — operators schedule
            migrations during low-volume periods and the race is
            sub-second wide for typical workloads. Tightening to a
            per-write check would require gating every pipeline stage,
            which the cost-benefit doesn't justify.

          * **Custom scope-provider fallback:** if a scope provider
            implements neither ``get_scope()`` nor a ``workspace_id``
            attribute, the check falls through to ``workspace_id="default"``.
            For unusual provider implementations this could let the
            pause toggle target the wrong workspace. Caller responsibility
            to expose at least one of the two interfaces.

        See: ``scripts/migrate_ontology_unify.py`` (producer side),
        plan §340, ONTO-RECONCILE-1 Sub-Checkpoint C.3.
        """
        # SEC-TENANT-QUERIES-1 Phase 1: shared resolver. The helper handles
        # the AttributeError / fallthrough cases internally and returns
        # None only for genuinely unscoped providers. We swallow any
        # unexpected error here and treat as "not paused" — a transient
        # provider blip should not wedge the ingest path (this is the
        # local-only nuance that ``_resolve_scope_workspace_id`` itself
        # doesn't enforce).
        try:
            workspace_id = self._resolve_scope_workspace_id() or "default"
        except Exception:  # noqa: BLE001
            return  # transient provider error — treat as not paused
        try:
            ontology_graph = self._ontology_store or OntologyGraph(workspace_id=workspace_id)
            backend = ontology_graph._get_backend()
            rows = backend.query(
                "MATCH (m:MigrationState {workspace_id: $ws, kind: 'ontology_unify'}) "
                "RETURN m.ingest_paused AS paused LIMIT 1",
                params={"ws": workspace_id},
                graph_name=ontology_graph._graph_name,
            )
        except Exception as e:  # noqa: BLE001
            logger.debug("ingest-pause check skipped (graph unreachable): %s", e)
            return
        if not rows:
            return
        head = rows[0]
        paused = head.get("paused") if isinstance(head, dict) else (head[0] if head else None)
        if paused:
            raise IngestPaused(
                f"workspace {workspace_id!r} is in an ontology-unification "
                "maintenance window; retry after the migration completes "
                "or run scripts/migrate_ontology_unify.py --unpause-ingest "
                f"--workspace {workspace_id} to clear"
            )

    def ingest(
        self,
        item,
        context=None,
        adapter_name=None,
        converter_name=None,
        extractor_name=None,
        enricher_names=None,
        conversation_context: Optional[Union[ConversationContext, Dict[str, Any]]] = None,
        pipeline_config: Optional[PipelineConfigBundle] = None,
        sync: Optional[bool] = None,
        auto_challenge: Optional[bool] = None,
        extract_decisions: bool = False,
        extract_reasoning: bool = False,
        **kwargs,
    ) -> Union[str, Dict[str, Any]]:
        """
        Primary entry point for ingesting items into SmartMemory.
        Runs the full canonical agentic memory ingestion flow with extraction, linking, enrichment, and evolution.
        For basic storage without the full pipeline, use add().

        Args:
            item: Content to ingest (str, dict, or MemoryItem)
            context: Additional context for processing
            adapter_name: Specific adapter to use
            converter_name: Specific converter to use
            extractor_name: Specific extractor to use
            enricher_names: Specific enrichers to use
            conversation_context: Conversation context for conversational memory
            sync: If True, run full pipeline synchronously; if False, persist and queue for background processing.
                  If None, defaults to sync=True (local mode).
            auto_challenge: If True, automatically challenge factual claims before ingesting.
                           If None, uses smart triggering (only challenges semantic facts with factual patterns).
            **kwargs: Additional processing options

        Returns:
            str: The item_id of the stored memory item (sync=True)
            dict: {"item_id": str, "queued": bool} (sync=False)

        Raises:
            IngestPaused: when the workspace's ontology-unification migration
                          window is open (``:MigrationState.ingest_paused``).
        """
        # ONTO-RECONCILE-1 §340: refuse new work during migration windows.
        # Check first — before any pipeline construction or state mutation.
        self._check_ingest_paused()

        # Determine effective mode
        if sync is None:
            try:
                from smartmemory.utils import get_config

                mode = ((get_config("ingestion") or {}).get("mode") or "").lower()
                sync = mode != "async"  # Default to sync unless explicitly async
            except Exception:
                sync = True  # Default to sync

        # Async path: Tier 1 pipeline (EntityRuler only) + enqueue for Tier 2 LLM enrichment
        if not sync:
            from smartmemory.pipeline.config import PipelineConfig

            normalized_item = self._crud.normalize_item(item)
            # CORE-ORIGIN-1: Warn if no origin is set
            if getattr(normalized_item, "origin", "unknown") == "unknown":
                logger.warning(
                    f"No origin set for {getattr(normalized_item, 'item_id', 'unknown')} — storing with origin='unknown'"
                )

            # Apply memory_type from context before storing
            if context and "memory_type" in context:
                current_type = getattr(normalized_item, "memory_type", "semantic")
                if current_type == "semantic":
                    normalized_item.memory_type = context["memory_type"]

            # Build Tier 1 config: spaCy + EntityRuler, no LLM extraction
            tier1_cfg = PipelineConfig.tier1()
            # OBS-TOKEN-ATTR-1: attribute async token usage to the workspace
            tier1_cfg.workspace_id = self._resolve_scope_workspace_id()
            # RLM-1a: Wire trajectory log_dir for async path
            if self._trajectory_log_dir:
                tier1_cfg.trajectory.log_dir = self._trajectory_log_dir
            # RLM-1b: Wire compaction for async path
            if self._compaction:
                tier1_cfg.compaction.enabled = True
                tier1_cfg.compaction.level = self._compaction

            if self._pipeline_runner is None:
                self._pipeline_runner = self._create_pipeline_runner()

            meta = dict(normalized_item.metadata or {})
            # Carry explicit memory_type from the MemoryItem into pipeline metadata so
            # it is not lost — metadata is the only channel PipelineRunner reads it from.
            if normalized_item.memory_type:
                meta.setdefault("memory_type", normalized_item.memory_type)
            # CORE-PROPS-1: Forward first-class fields from MemoryItem to pipeline metadata
            if getattr(normalized_item, "origin", None) and normalized_item.origin != "unknown":
                meta.setdefault("origin", normalized_item.origin)
            if getattr(normalized_item, "confidence", None) is not None and normalized_item.confidence != 1.0:
                meta.setdefault("confidence", normalized_item.confidence)
            if getattr(normalized_item, "reference", False):
                meta.setdefault("reference", True)
            if context:
                for k, v in context.items():
                    meta.setdefault(k, v)
            with self._di_context():
                state = self._pipeline_runner.run(
                    text=normalized_item.content or "",
                    config=tier1_cfg,
                    metadata=meta,
                )
            item_id = state.item_id
            entity_ids: dict = state.entity_ids or {}

            # RLM-1a: Save trajectory from async Tier 1 pipeline
            self._last_trajectory = state.trajectory

            # Enqueue for Tier 2 LLM worker
            queued = False
            try:
                from smartmemory.observability.events import RedisStreamQueue

                q = RedisStreamQueue.for_extract()
                q.enqueue(
                    {
                        "job_type": "extract",
                        "item_id": item_id,
                        "workspace_id": tier1_cfg.workspace_id or "",
                        "entity_ids": entity_ids,
                        "enable_ontology": self._enable_ontology,
                    }
                )
                queued = True
            except Exception:
                queued = False
            return {"item_id": item_id, "queued": queued, "entity_ids": entity_ids}
        # Normalize item using CRUD component (eliminates mixed abstraction)
        normalized_item = self._crud.normalize_item(item)
        # CORE-ORIGIN-1: Warn if no origin is set
        if getattr(normalized_item, "origin", "unknown") == "unknown":
            logger.warning(
                f"No origin set for {getattr(normalized_item, 'item_id', 'unknown')} — storing with origin='unknown'"
            )

        # Apply memory_type from context if the item has the default type
        # (happens when ingest() receives a raw string + context={"memory_type": "decision"})
        if context and "memory_type" in context:
            current_type = getattr(normalized_item, "memory_type", "semantic")
            if current_type == "semantic":
                normalized_item.memory_type = context["memory_type"]

        # Annotate with conversation metadata if provided (non-invasive)
        try:
            if conversation_context is not None:
                convo_dict: Dict[str, Any]
                if isinstance(conversation_context, ConversationContext):
                    convo_dict = conversation_context.to_dict()
                elif isinstance(conversation_context, dict):
                    convo_dict = dict(conversation_context)
                else:
                    convo_dict = {}
                # MemoryItem guarantees a metadata dict; normalize just in case
                if not isinstance(normalized_item.metadata, dict):
                    logger.warning("MemoryItem.metadata was not a dict; normalizing to empty dict")
                    normalized_item.metadata = {}
                # Only store lightweight identifiers to avoid bloat
                conv_id = convo_dict.get("conversation_id")
                if conv_id is not None:
                    normalized_item.metadata.setdefault("conversation_id", conv_id)
                    normalized_item.metadata.setdefault("provenance", {})
                    try:
                        if isinstance(normalized_item.metadata["provenance"], dict):
                            normalized_item.metadata["provenance"].setdefault("source", "conversation")
                    except Exception as e:
                        logger.debug(f"Failed to set conversation provenance on metadata: {e}")
        except Exception as e:
            logger.warning(f"Failed to annotate item with conversation metadata: {e}")

        # Special handling for pending memory - bypass ingestion pipeline
        memory_type = getattr(normalized_item, "memory_type", "semantic")
        if memory_type == "pending":
            return self.add(normalized_item, **kwargs)

        # Auto-challenge: detect contradictions before ingesting
        # Only runs when: auto_challenge=True, or auto_challenge=None and smart triggering says yes
        try:
            from smartmemory.reasoning.challenger import should_challenge, AssertionChallenger

            content = normalized_item.content or ""
            metadata = normalized_item.metadata or {}
            source = metadata.get("source") or (context or {}).get("source")

            do_challenge = auto_challenge
            if do_challenge is None:
                # Smart triggering: only challenge semantic facts with factual patterns
                do_challenge = should_challenge(
                    content=content, memory_type=memory_type, source=source, metadata=metadata
                )

            if do_challenge:
                challenger = AssertionChallenger(self, use_llm=False)  # Heuristics for speed
                challenge_result = challenger.challenge(content, memory_type=memory_type)

                if challenge_result.has_conflicts:
                    # Store challenge result in metadata for downstream handling
                    normalized_item.metadata["challenge_result"] = {
                        "has_conflicts": True,
                        "conflict_count": len(challenge_result.conflicts),
                        "overall_confidence": challenge_result.overall_confidence,
                        "conflicts": [c.to_dict() for c in challenge_result.conflicts[:3]],  # Limit stored
                    }
                    logger.info(
                        f"Auto-challenge found {len(challenge_result.conflicts)} conflicts for: {content[:50]}..."
                    )
        except Exception as e:
            logger.debug(f"Auto-challenge failed (non-fatal): {e}")

        # Check for explicit versioning via original_id
        # This supports the temporal test patterns where add() is used to create new versions
        if normalized_item.metadata and "original_id" in normalized_item.metadata:
            original_id = normalized_item.metadata["original_id"]
            try:
                version = self.version_tracker.create_version(
                    item_id=original_id,
                    content=normalized_item.content,
                    metadata=normalized_item.metadata,
                    change_reason="updated via add()",
                )
                # Return a unique ID for the version node, consistent with the expectation that
                # add() returns a unique ID for the new "item" (version)
                return f"version_{original_id}_{version.version_number}"
            except Exception as e:
                logger.warning(f"Failed to create version for {original_id}: {e}")
                # Fallback to normal add if versioning fails (e.g. original not found)

        # If this is called from internal code that needs basic storage, check for bypass flag
        if kwargs.pop("_bypass_ingestion", False):
            return self.add(normalized_item, **kwargs)

        # CFS-2: Automatic procedure matching — find a lighter pipeline profile
        procedure_match = None
        if self._procedure_matcher.config.enabled and pipeline_config is None:
            try:
                procedure_match = self._procedure_matcher.match(normalized_item.content or "")
                if procedure_match.matched and procedure_match.recommended_profile:
                    try:
                        from service_common.pipeline.profiles import get_pipeline_profile_registry

                        pipeline_config = get_pipeline_profile_registry().get_bundle(
                            procedure_match.recommended_profile
                        )
                    except (ImportError, KeyError):
                        pass  # OSS or unknown profile — fall through to default
            except Exception as e:
                logger.debug("CFS-2: Procedure matching failed (non-fatal): %s", e)
        self._last_procedure_match = procedure_match

        # Run full ingestion pipeline (v2)
        if self._pipeline_runner is None:
            self._pipeline_runner = self._create_pipeline_runner()

        pipeline_cfg = self._build_pipeline_config(
            extractor_name=extractor_name,
            enricher_names=enricher_names if enricher_names is not None else getattr(self, "_enricher_pipeline", []),
            pipeline_config=pipeline_config,
            sync=True,
            extract_decisions=extract_decisions,
            extract_reasoning=extract_reasoning,
        )

        # RLM-1a: Stamp profile_name from caller context (service/MCP path)
        if context and "profile_name" in context and pipeline_cfg.profile_name == "default":
            pipeline_cfg.profile_name = context["profile_name"]

        # Build metadata dict for the pipeline — merge context so memory_type flows through
        meta = dict(normalized_item.metadata or {})
        # CORE-PROPS-1: Forward first-class fields from MemoryItem to pipeline metadata
        if getattr(normalized_item, "origin", None) and normalized_item.origin != "unknown":
            meta.setdefault("origin", normalized_item.origin)
        if getattr(normalized_item, "confidence", None) is not None and normalized_item.confidence != 1.0:
            meta.setdefault("confidence", normalized_item.confidence)
        if getattr(normalized_item, "reference", False):
            meta.setdefault("reference", True)
        if context:
            for k, v in context.items():
                meta.setdefault(k, v)
        if conversation_context is not None:
            try:
                if isinstance(conversation_context, ConversationContext):
                    meta["conversation"] = conversation_context.to_dict()
                elif isinstance(conversation_context, dict):
                    meta["conversation"] = dict(conversation_context)
            except Exception as e:
                logger.debug(f"Failed to merge conversation_context into metadata: {e}")

        # PLAT-PROGRESS-1: bind progress context so every trace_span("pipeline.*") inside
        # _execute_stage_inner emits a ProgressEvent to sm:progress:<workspace_id>.
        _progress_run_id = str(__import__("uuid").uuid4())
        # workspace_id priority: pipeline_cfg (from scope provider) > context kwarg > "default"
        _progress_workspace_id = pipeline_cfg.workspace_id or (context or {}).get("workspace_id") or "default"
        try:
            from smartmemory.progress import bind as _progress_bind
            from smartmemory.progress import unbind as _progress_unbind

            _progress_bind(run_id=_progress_run_id, scope=f"workspace:{_progress_workspace_id}")
        except Exception as _pbind_exc:
            logger.debug("PLAT-PROGRESS-1: progress.bind() failed (non-fatal): %s", _pbind_exc)
            _progress_unbind = None

        try:
            with self._di_context():
                state = self._pipeline_runner.run(
                    text=normalized_item.content or "",
                    config=pipeline_cfg,
                    metadata=meta,
                )
        finally:
            if _progress_unbind is not None:
                try:
                    _progress_unbind()
                except Exception as _punbind_exc:
                    logger.debug("PLAT-PROGRESS-1: progress.unbind() failed: %s", _punbind_exc)

        # CORE-SYS2-1b: dispatch auto-extracted decisions — non-fatal, pipeline work is done
        # CORE-SYS2-1d: also fires when classify routes memory_type="decision"
        if (
            pipeline_cfg.extraction.llm_extract.extract_decisions and state.llm_decisions
        ) or state.memory_type == "decision":
            try:
                from smartmemory.decisions.manager import DecisionManager

                _threshold = pipeline_cfg.extraction.llm_extract.decision_confidence_threshold
                _dm = DecisionManager(memory=self)

                # CORE-SYS2-1d: classify-based dispatch — store primary item when
                # classified as "decision" but no LLM sub-decisions were extracted
                if state.memory_type == "decision" and not state.llm_decisions:
                    try:
                        _dm.create(
                            content=state.text,
                            decision_type="inference",
                            confidence=0.75,
                            source_type="inferred",
                            tags=["auto_classified"],
                        )
                    except Exception as _e:
                        logger.warning("Failed to store classify-dispatched decision: %s", _e)

                for _raw in state.llm_decisions or []:  # guard: None when classify-only path
                    if not isinstance(_raw, dict):
                        logger.debug("Skipping non-dict auto-extracted decision: %r", _raw)
                        continue
                    try:
                        _content = str(_raw.get("content", "")).strip()
                        if not _content:
                            continue
                        _confidence = float(_raw.get("confidence", 0))
                    except (TypeError, ValueError):
                        logger.debug("Skipping malformed auto-extracted decision: %r", _raw)
                        continue
                    if _confidence < _threshold:
                        continue
                    try:
                        _dm.create(
                            content=_content,
                            decision_type=_raw.get("decision_type", "inference"),
                            confidence=_confidence,
                            source_type="inferred",
                            tags=["auto_extracted"],
                        )
                    except Exception as _e:
                        logger.warning("Failed to store auto-extracted decision: %s", _e)
            except Exception as _e:
                logger.warning("Decision dispatch failed (non-fatal): %s", _e)

        # CORE-SYS2-1c: dispatch auto-extracted reasoning trace — non-fatal
        # CORE-SYS2-1d: also fires when classify routes memory_type="reasoning"
        # CORE-EXPERTISE-1 Phase 3 T12: persist via ReasoningManager.create_trace.
        # Behavior changes (intentional):
        #   - origin first-class on the persisted node ("pipeline:reasoning_extract"
        #     instead of "unknown")
        #   - structured ReasoningTrace persistence (steps, evaluation, task_context)
        #     replaces the legacy ad-hoc dict (trace_id/quality_score/step_count/...)
        #   - bypass=True: preserves pre-migration "store unconditionally" semantics
        #     for the auto-extract path. Honoring the quality gate here is a
        #     semantic change worth a separate decision.
        # Preserved (no behavior change vs pre-migration):
        #   - the gate at line 1499 (`if state.reasoning_trace:`)
        #   - state.item_id (NOT item.item_id — Codex flagged this in earlier review)
        #   - PRODUCED edge direction reasoning_id -> state.item_id, the codebase's
        #     canonical PRODUCED convention (schema_validator.py:591; matches
        #     decisions/declaration.py:80 and decisions/queries.py:125 which reads
        #     `get_incoming_neighbors(..., "PRODUCED")`). The framework's
        #     _reasoning_edges emits this direction when source_item_id is supplied.
        #   - the _PRODUCED_ALLOWED_TARGETS schema gate: only thread source_item_id
        #     through when state.memory_type is in the allowed set; otherwise the
        #     edge is skipped (source_item_id=None makes _reasoning_edges return [])
        if (
            pipeline_cfg.extraction.reasoning_detect.enabled or state.memory_type == "reasoning"
        ) and state.reasoning_trace:
            try:
                from smartmemory.reasoning import ReasoningManager

                _trace = state.reasoning_trace
                _source_id = state.item_id if state.item_id and state.memory_type in _PRODUCED_ALLOWED_TARGETS else None
                if state.item_id and not _source_id:
                    logger.debug(
                        "Skipping PRODUCED edge: source memory_type=%r not in allowed set",
                        state.memory_type,
                    )
                ReasoningManager(self).create_trace(
                    _trace,
                    source_item_id=_source_id,
                    origin="pipeline:reasoning_extract",
                    bypass=True,
                )
            except Exception as _e:
                logger.warning("Reasoning dispatch failed (non-fatal): %s", _e)

        # Save token usage summary for retrieval by service layer (CFS-1)
        if state.token_tracker:
            self._last_token_summary = state.token_tracker.summary()
        else:
            self._last_token_summary = None

        # RLM-1a: Save trajectory for retrieval by service layer
        self._last_trajectory = state.trajectory

        # Save extraction results for retrieval by service layer (/ingest/full)
        self._last_entities = list(state.entities or [])
        self._last_relations = list(state.relations or [])

        # Save ontology pipeline results for retrieval by service layer (OL-2/3/4)
        self._last_ontology_version = state.ontology_version
        self._last_ontology_registry_id = state.ontology_registry_id
        self._last_unresolved_entities = state.unresolved_entities
        self._last_constraint_violations = state.constraint_violations

        item_id = state.item_id

        # CORE-BG-1: emit pipeline event to Redis Stream for background worker consumers.
        # Fire-and-forget — failure must never raise or slow ingest().
        try:
            from smartmemory.streams.pipeline_producer import emit_pipeline_event

            emit_pipeline_event(
                item_id=item_id or "",
                workspace_id=pipeline_cfg.workspace_id,
                memory_type=str(getattr(normalized_item, "memory_type", "semantic")),
            )
        except Exception:
            pass  # observability failure must never break ingestion

        # Auto-version initial creation
        if item_id and self.version_tracker:
            try:
                # Only create if no versions exist (avoid double creation if logic changes)
                # We check cache first to avoid DB hit if possible, but get_versions does that
                versions = self.version_tracker.get_versions(item_id)
                if not versions:
                    self.version_tracker.create_version(
                        item_id=item_id,
                        content=normalized_item.content,
                        metadata=normalized_item.metadata,
                        change_reason="initial creation",
                    )
            except Exception as e:
                logger.debug(f"Failed to create initial version for {item_id}: {e}")

        return item_id

    def add(self, item, **kwargs) -> str:
        """
        Simple storage without the full ingestion pipeline.

        Use this for:
        - Internal operations (evolution, enrichment creating derived items)
        - Direct storage when extraction/linking/enrichment is not needed
        - Avoiding recursion in pipeline stages

        For full agentic ingestion with all processing stages, use ingest().

        Args:
            item: Content to store (str, dict, or MemoryItem)
            **kwargs: Additional storage options

        Returns:
            str: The item_id of the stored memory item
        """
        # Convert to MemoryItem if needed
        if hasattr(item, "to_memory_item"):
            item = item.to_memory_item()
        elif not isinstance(item, MemoryItem):
            # Convert dict or other types to MemoryItem
            if isinstance(item, dict):
                item = MemoryItem(**item)
            else:
                item = MemoryItem(content=str(item))

        # CORE-ORIGIN-1: Warn if no origin is set
        if getattr(item, "origin", "unknown") == "unknown":
            logger.warning(f"No origin set for {getattr(item, 'item_id', 'unknown')} — storing with origin='unknown'")

        # Route to appropriate memory store based on memory_type
        memory_type = getattr(item, "memory_type", "semantic")
        if memory_type == "pending":
            # Pending memory is always graph-backed. The previous in-memory
            # buffer fallback was removed — it created a parallel state path
            # disconnected from evolvers and search. All pending items now
            # persist via CRUD so self.pending (PendingMemory facade) and
            # search(memory_type="pending") see the same data.
            try:
                if not isinstance(item.metadata, dict):
                    logger.warning("MemoryItem.metadata was not a dict for pending item; normalizing to empty dict")
                    item.metadata = {}
                item.metadata.setdefault("memory_type", "pending")
                item.metadata.setdefault("provenance", {})
                if isinstance(item.metadata.get("provenance"), dict):
                    item.metadata["provenance"].setdefault("source", "pending_memory")
            except Exception as e:
                logger.warning(f"Failed to set default working memory metadata: {e}")
            with self._di_context():
                result = self._crud.add(item, **kwargs)
            item_id = result["memory_node_id"]
            self._create_lineage_edge(item, item_id)
            return item_id
        else:
            # For other memory types, use the standard CRUD.
            # _di_context must be outer so trace_span sees the per-instance observability
            # setting at entry and routes the emitted event to the correct sink at exit.
            with self._di_context():
                with trace_span(
                    "memory.add",
                    {
                        "memory_type": memory_type,
                        "content_length": len(getattr(item, "content", "") or ""),
                    },
                ) as span:
                    result = self._crud.add(item, **kwargs)
                    item_id = result["memory_node_id"]
                    span.attributes["memory_id"] = item_id
                    self._create_lineage_edge(item, item_id)
                    return item_id

    def ingest_structured(self, data: dict, schema: str, **kwargs) -> str:
        """Ingest structured data via a registered handler (CORE-STRUCT-1).

        Bypasses the NLP pipeline — the structure IS the content. The handler
        determines strategy (FULL/INDEXED/APPEND), validates, converts to
        MemoryItem, and declares edges and indexes.

        Args:
            data: Structured data dict matching the handler's schema.
            schema: Handler schema name (e.g. "decision", "tool_call").
            **kwargs: Additional options forwarded to add().

        Returns:
            str: The item_id of the stored memory item.

        Raises:
            KeyError: If no handler is registered for the schema.
            ValueError: If the data fails handler validation.
            IngestPaused: When the workspace's ontology-unification migration
                          window is open (``:MigrationState.ingest_paused``).
        """
        # ONTO-RECONCILE-1 §340: structured ingestion is also a write path
        # and must respect the maintenance window. add() (called below)
        # doesn't gate, so we gate here at the entry point.
        self._check_ingest_paused()

        from smartmemory.memory.ingestion.structured import get_structured_registry

        registry = get_structured_registry()
        handler = registry.get(schema)

        # Validate
        if not handler.validate(data):
            raise ValueError(f"Invalid data for schema '{schema}'")

        # Convert to MemoryItem
        item = handler.to_memory_item(data)
        item.origin = f"structured:{schema}"
        # confidence: MemoryItem default is 1.0 (schema-mapped = no extraction uncertainty).
        # Handlers may override (e.g. DecisionHandler sets per-decision confidence).
        # Ensure origin/confidence reach graph properties via metadata
        # (NodeTypeProcessor merges metadata into node properties, but not first-class fields)
        if not isinstance(item.metadata, dict):
            item.metadata = {}
        item.metadata["origin"] = item.origin
        item.metadata["confidence"] = item.confidence

        # Store via existing add() path — strategy controls embedding
        item_id = self.add(item, _strategy=handler.strategy.value, _embed=handler.embed, **kwargs)

        # Create handler-declared edges
        for source_id, target_id, edge_type, edge_props in handler.get_edges(data, item_id):
            try:
                self.add_edge(source_id, target_id, edge_type, edge_props)
            except Exception as e:
                logger.warning(f"Failed to create {edge_type} edge for structured:{schema}: {e}")

        # Ensure handler-declared indexes (lazy, idempotent)
        try:
            backend = self._graph.backend
            registry.ensure_indexes(schema, backend)
        except Exception as e:
            logger.debug(f"Index creation for schema '{schema}' skipped: {e}")

        return item_id

    # -------------------------------------------------------------------------
    # Document ingestion (CORE-STRUCT-DOC-1)
    # -------------------------------------------------------------------------

    @staticmethod
    def _document_id(source_url: str, content_hash: str) -> str:
        """Derive a deterministic parent document_id from canonical URL + content hash.

        Codex R2: bounded search is not robust for dedup on large multi-chunk
        documents. A deterministic id turns dedup into an O(1) `get()` lookup
        and removes any dependency on the search backend's state.
        """
        import hashlib

        digest = hashlib.sha256(f"{source_url}::{content_hash}".encode()).hexdigest()[:24]
        return f"doc:{digest}"

    def _find_document(self, source_url: str, content_hash: str) -> str | None:
        """Return an existing parent document_id via exact id lookup.

        Uses the deterministic id derived by `_document_id()`; survives arbitrary
        numbers of chunks and FalkorDB state pollution.
        """
        candidate = self._document_id(source_url, content_hash)
        try:
            existing = self.get(candidate)
        except Exception:
            existing = None
        if existing is None:
            return None
        return candidate

    def ingest_document(
        self,
        source: str,
        *,
        source_type: str = "auto",
        chunk_size: int = 2000,
        chunk_strategy: str = "paragraph",
        reference: bool = False,
    ) -> dict:
        """Ingest a document from a URL or file path (CORE-STRUCT-DOC-1).

        Creates a parent document node (INDEXED, no embedding) and chunk nodes
        (FULL, embedded) linked via PART_OF edges. Deduplicates by source URL
        and content hash — re-ingesting unchanged content returns the existing
        document_id immediately.

        Args:
            source: URL (http/https) or file path (.txt, .md, .pdf, .docx).
            source_type: Loader to use ("html", "pdf", "docx", "txt", "markdown",
                         or "auto" to detect from URL/extension).
            chunk_size: Maximum characters per chunk (default 2000).
            chunk_strategy: chunking.chunk_text strategy (default "paragraph").
            reference: Mark all created nodes as reference material.

        Returns:
            dict with keys:
              - document_id (str): item_id of the parent document node
              - chunk_ids (list[str]): item_ids of chunk nodes ([] if existing)
              - status (str): "ingested" or "existing"

        Raises:
            ImportError: If required loader dependency is not installed.
            ValueError: If source_type is unknown or source is unreadable.
        """
        import hashlib

        from smartmemory.memory.ingestion.document_loaders import load_document
        from smartmemory.utils.chunking import chunk_text

        doc = load_document(source, source_type)
        canonical_url = doc.source_url  # canonicalized by loader (abs path or original URL)

        content_hash = hashlib.sha256(doc.content.encode()).hexdigest()[:16]
        deterministic_id = self._document_id(canonical_url, content_hash)
        existing_id = self._find_document(canonical_url, content_hash)
        if existing_id:
            logger.debug("Document already ingested: source=%s id=%s", canonical_url, existing_id)
            return {"document_id": existing_id, "chunk_ids": [], "status": "existing"}

        # Parent node — INDEXED (no embedding), queryable by source_url.
        # item_id is deterministic so re-ingest hits the dedup path in O(1).
        parent_metadata = {
            "source_url": canonical_url,
            "file_type": doc.file_type,
            "page_count": doc.page_count,
            "content_hash": content_hash,
        }
        if reference:
            # Mirror pattern used by SeedItemHandler — reference flag persists
            # through add() only when present in metadata.
            parent_metadata["reference"] = True
        parent_item = MemoryItem(
            item_id=deterministic_id,
            content=doc.title or canonical_url,
            memory_type="document",
            origin="import:document",
            reference=reference,
            metadata=parent_metadata,
        )
        parent_id = self.add(parent_item, _strategy="INDEXED", _embed=False)

        # Chunk → child nodes; DocumentHandler creates PART_OF edge (chunk → parent)
        raw_chunks = chunk_text(doc.content, chunk_size=chunk_size, overlap=200, strategy=chunk_strategy)
        chunk_ids: list[str] = []
        for i, chunk_body in enumerate(raw_chunks):
            chunk_id = self.ingest_structured(
                {
                    "content": chunk_body,
                    "source_url": canonical_url,
                    "file_type": doc.file_type,
                    "chunk_index": i,
                    "total_chunks": len(raw_chunks),
                    "parent_document_id": parent_id,
                    "reference": reference,
                },
                schema="document",
            )
            chunk_ids.append(chunk_id)

        logger.info(
            "Document ingested: source=%s parent_id=%s chunks=%d",
            source,
            parent_id,
            len(chunk_ids),
        )
        return {"document_id": parent_id, "chunk_ids": chunk_ids, "status": "ingested"}

    def _create_lineage_edge(self, item, item_id: str) -> None:
        """CORE-PROPS-1 Phase 4: auto-create DERIVED_FROM edge for lineage."""
        derived_from = getattr(item, "derived_from", None)
        if derived_from and item_id and derived_from != item_id:
            try:
                # CORE-PROPS-1 Phase 5: propagate origin + confidence to edge
                props = {
                    "origin": getattr(item, "origin", "unknown"),
                    "confidence": getattr(item, "confidence", 1.0),
                }
                self.add_edge(item_id, derived_from, "DERIVED_FROM", props)
            except Exception as e:
                logger.debug(f"Failed to create DERIVED_FROM edge {item_id} → {derived_from}: {e}")

    def _add_impl(self, item, **kwargs) -> str:
        """Implement abstract method from MemoryBase."""
        result = self._crud.add(item, **kwargs)
        # PPR cache invalidation fires via SmartGraph's post-write hook
        # registered in __init__ — no per-wrapper call needed.
        return result["memory_node_id"]

    def _get_impl(self, key: str):
        return self._crud.get(key)

    def _update_impl(self, item, **kwargs):
        """Implement type-specific update logic by delegating to CRUD component."""
        return self._crud.update(item, **kwargs)

    def get_user_seed(self, user_id: str):
        """Return the User seed node for ``user_id``, or None if absent.

        CORE-USER-SEED-1. Scope-agnostic at this layer; ``SecureSmartMemory``
        adds workspace/tenant filtering at the wrapper.
        """
        from smartmemory.users.seed import get_user_seed as _get

        return _get(self, user_id)

    def get_evaluation(self, agent_id: str, dimension: str, domain: str):
        """Return the current evaluation for ``(agent_id, dimension, domain)`` as a dict.

        CORE-AGENT-2 S03-T4. Thin delegator to ``smartmemory.agents.evaluation:get_evaluation``.
        Wrapped in a trace span for observability. Returns ``None`` on cold-start or
        unseen ``(dimension, domain)`` tuples.

        SecureSmartMemory adds workspace-scope guard before delegating here.
        """
        from smartmemory.agents.evaluation import get_evaluation as _get_evaluation
        from smartmemory.observability.tracing import trace_span

        with trace_span(
            "memory.get_evaluation",
            {"agent_id": agent_id, "dimension": dimension, "domain": domain},
        ):
            return _get_evaluation(self, agent_id, dimension, domain)

    def get(self, item_id: str, **kwargs):
        with trace_span("memory.get", {"memory_id": item_id}) as span:
            result = self._crud.get(item_id)
            span.attributes["found"] = result is not None
            if result is not None:
                try:
                    from smartmemory.observability.retrieval_tracking import emit_retrieval_get

                    emit_retrieval_get(result, self.scope_provider)
                except Exception:
                    pass  # observability failure must never affect get() return
                # CORE-PROPS-1 Phase 3 atomic access tracking.
                # PLAT-SQLITE-SEGFAULT-1: was a daemon thread; same lifetime
                # bug as the search() path (SIGSEGV when the SQLite connection
                # closed while the thread was mid-execute). Inlined per spike
                # (p99 < 0.5ms for n=1).
                try:
                    from datetime import datetime as _dt, timezone as _tz

                    self._graph.backend.increment_access([item_id], _dt.now(_tz.utc).isoformat())
                except Exception:
                    pass  # access tracking failure must never affect get() return
            return result

    # Archive facades (provider hidden behind SmartMemory interface)
    def archive_put(
        self, conversation_id: str, payload: Union[bytes, Dict[str, Any]], metadata: Dict[str, Any]
    ) -> Dict[str, str]:
        """Persist a raw conversation artifact durably and return { archive_uri, content_hash }."""
        try:
            if metadata is None:
                metadata = {}
            result = get_archive_provider().put(conversation_id, payload, metadata)
            if not isinstance(result, dict) or "archive_uri" not in result or "content_hash" not in result:
                raise RuntimeError(
                    "ArchiveProvider.put returned invalid result; expected keys 'archive_uri' and 'content_hash'"
                )
            return result
        except Exception as e:
            logger.error(f"archive_put failed for conversation_id={conversation_id}: {e}")
            raise

    def archive_get(self, archive_uri: str) -> Union[bytes, Dict[str, Any]]:
        """Retrieve an archived artifact by its URI via the configured ArchiveProvider."""
        try:
            return get_archive_provider().get(archive_uri)
        except Exception as e:
            logger.error(f"archive_get failed for uri={archive_uri}: {e}")
            raise

    def find_shortest_path(self, start_id: str, end_id: str, max_hops: int = 5) -> Optional["MemoryPath"]:
        """Find the shortest path between two nodes in the knowledge graph.

        Args:
            start_id: Item ID of the start node.
            end_id: Item ID of the end node.
            max_hops: Maximum number of hops to traverse (capped at 10).

        Returns:
            MemoryPath with populated Triple objects, or None if no path found.
        """
        from smartmemory.graph.core.memory_path import MemoryPath, Triple

        max_hops = min(max_hops, 10)
        # SEC-TENANT-QUERIES-1 Phase 2 (audit H1): scope path traversal to the
        # caller's workspace. Without this, identifier collisions across tenants
        # (deterministic ids like ``wikipedia:Q42``) would let workspace B
        # traverse workspace A's graph by reusing A's item_ids.
        ws = self._resolve_scope_workspace_id()
        if ws is None:
            logger.warning(
                "tenant_isolation.scope_missing.find_shortest_path: "
                "refusing unscoped traversal; returning None."
            )
            return None
        # FalkorDB requires shortestPath in WITH/RETURN; build path expression
        # inside RETURN to satisfy that constraint while keeping the workspace
        # predicate on both endpoints.
        query = (
            "MATCH (start {item_id: $start_id, workspace_id: $ws}), "
            "(end {item_id: $end_id, workspace_id: $ws}) "
            f"WITH start, end, shortestPath((start)-[*..{max_hops}]->(end)) AS path "
            "RETURN nodes(path) as nodes, relationships(path) as rels"
        )
        try:
            results = self._graph.execute_query(
                query, {"start_id": start_id, "end_id": end_id, "ws": ws}
            )
        except Exception as e:
            logger.error(f"find_shortest_path failed: {e}")
            return None

        if not results:
            return None

        row = results[0]
        nodes_data = row[0] if isinstance(row, (list, tuple)) else row.get("nodes", [])
        rels_data = row[1] if isinstance(row, (list, tuple)) else row.get("rels", [])

        triples: list[Triple] = []
        for i, rel in enumerate(rels_data):
            src_node = nodes_data[i]
            tgt_node = nodes_data[i + 1]

            src_id = (
                src_node.properties.get("item_id", str(src_node.id))
                if hasattr(src_node, "properties")
                else str(src_node)
            )
            tgt_id = (
                tgt_node.properties.get("item_id", str(tgt_node.id))
                if hasattr(tgt_node, "properties")
                else str(tgt_node)
            )
            rel_type = rel.relation if hasattr(rel, "relation") else str(rel)

            triples.append(Triple(subject=src_id, predicate=rel_type, object=tgt_id))

        return MemoryPath(triples=triples)

    def execute_cypher(self, query: str, params: dict | None = None) -> list:
        """Execute a raw Cypher query against the graph backend.

        Args:
            query: Cypher query string with optional $param placeholders.
            params: Parameter dict for parameterized queries.

        Returns:
            List of result rows from the backend.
        """
        return self._graph.execute_query(query, params)

    def update_properties(self, item_id: str, properties: dict, write_mode: str | None = None):
        """Public wrapper to update memory node properties with merge/replace semantics."""
        return self._crud.update_memory_node(item_id, properties, write_mode)

    # Backward-compatible alias (deprecated)
    def update(self, item: Union[MemoryItem, dict], **kwargs):
        """Can take either dict or MemoryItem."""
        return self._crud.update(item)

    def add_edge(self, source_id: str, target_id: str, relation_type: str, properties: dict | None = None):
        """Public wrapper to add an edge between two nodes."""
        properties = properties or {}
        return self._graph.add_edge(
            source_id=source_id, target_id=target_id, edge_type=relation_type, properties=properties
        )
        # PPR cache invalidated via SmartGraph.add_edge's write-hook.

    # --- Expertise-layer wrappers (CORE-EXPERTISE-1 Phase 3 T7) -------------
    # Each ≤10 LOC; thin delegates to the corresponding Manager.

    def add_opinion(self, content: str, subject: str, **kwargs):
        """Create or upsert an opinion. Idempotent by subject."""
        from smartmemory.opinions import OpinionManager

        return OpinionManager(self).create(content, subject=subject, **kwargs)

    def add_decision(self, content: str, **kwargs):
        """Create a decision via DecisionManager.create. Returns a Decision instance.

        Accepts all Decision fields as kwargs (decision_type, confidence,
        rejected_alternatives, rationale, constraints, domain, tags, ...).
        """
        from smartmemory.decisions import DecisionManager

        return DecisionManager(self).create(content, **kwargs)

    def add_constraint(self, content: str, **kwargs):
        """Create a constraint via ConstraintManager.create. Returns a Constraint instance.

        Accepts all Constraint fields as kwargs (domain, source, ...).
        """
        from smartmemory.constraints import ConstraintManager

        return ConstraintManager(self).create(content, **kwargs)

    def add_learning(self, content: str, **kwargs):
        """Create a learned-lesson record via LearnedManager.create. Returns a Learned instance.

        Accepts all Learned fields as kwargs (category, incident_link, ...).
        """
        from smartmemory.learned import LearnedManager

        return LearnedManager(self).create(content, **kwargs)

    def add_observation(self, entity_id: str, fact_id: str, aspect: str | None = None):
        """Fold a fact into the entity's observation row. Idempotent."""
        from smartmemory.observations import ObservationManager

        return ObservationManager(self).add_source(entity_id, fact_id, aspect)

    def add_reasoning(self, trace, source_item_id: str | None = None, **kwargs):
        """Persist a ReasoningTrace via the quality gate."""
        from smartmemory.reasoning import ReasoningManager

        return ReasoningManager(self).create_trace(trace, source_item_id=source_item_id, **kwargs)

    def create_or_merge_node(self, item_id: str, properties: dict, memory_type: str | None = None):
        """Public wrapper to upsert a raw node with properties. Returns item_id."""
        self._graph.add_node(item_id=item_id, properties=properties, memory_type=memory_type)
        # PPR cache invalidated via SmartGraph.add_node's write-hook.
        return item_id

    # -- CORE-MEMORY-DYNAMICS-1 M2b Slice B: progressive compaction ---------

    def rehydrate_item(self, item_id: str, target_tier: str = "FULL"):
        """Restore ``item_id``'s content from its compaction snapshot.

        Reads from ``metadata[snapshots][target_tier]`` and writes the
        snapshot's content back as the live ``content``. Marks the item
        ``needs_reembed=True`` so a downstream enrichment pass can
        reconcile the embedding asynchronously (rehydration itself is
        sync and cheap — embedding regeneration is orthogonal).

        Unlike the sweep, this method is always available regardless of
        the ``tier_compaction`` opt-in flag; rehydration is a read-path
        operation.

        Args:
            item_id: Target item.
            target_tier: ``"FULL"`` by default. Any tier name in
                :data:`smartmemory.activation.compaction_constants.TIER_ORDER`
                is accepted; callers usually want the highest fidelity
                available.

        Returns:
            The updated ``MemoryItem``.

        Raises:
            ValueError: on unknown tier, missing item, or missing snapshot.
        """
        from smartmemory.activation.compaction import rehydrate_from_snapshot

        return rehydrate_from_snapshot(self, item_id, target_tier=target_tier)

    # -- CORE-SUPERSEDE-1: Fact supersession --------------------------------

    def supersede(self, old_id: str, new_id: str, reason: str | None = None) -> bool:
        """Manually mark old_id as superseded by new_id.

        Creates a SUPERSEDED_BY edge and sets superseded properties on the old node.

        Args:
            old_id: Item ID of the memory to supersede.
            new_id: Item ID of the replacement memory.
            reason: Optional human-readable reason for supersession.

        Returns:
            True if supersession was applied, False on failure.
        """
        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).isoformat()
        try:
            self.update_properties(
                old_id,
                {
                    "superseded": True,
                    "superseded_by": new_id,
                    "superseded_at": now,
                },
            )
            self.add_edge(
                source_id=old_id,
                target_id=new_id,
                relation_type="SUPERSEDED_BY",
                properties={
                    "confidence": 1.0,
                    "conflict_type": "manual",
                    "detected_at": now,
                    "detection_method": "manual",
                    "explanation": reason or "Manual supersession",
                },
            )
            logger.warning(
                "Manual supersession: %s superseded by %s (reason=%s)",
                old_id,
                new_id,
                reason or "none",
            )
            # CORE-BITEMPORAL-1: record the transaction-time boundary for
            # fact-bearing types. The hook's allowlist fences out telemetry,
            # so it is safe to call unconditionally with the old node's type.
            try:
                from datetime import datetime as _dt2, timezone as _tz2

                from smartmemory.temporal.supersession_hook import version_on_supersede

                old_node = self._graph.get_node(old_id)
                new_node = self._graph.get_node(new_id)
                if old_node is not None:
                    old_md = getattr(old_node, "metadata", None) or {}
                    o_created = (
                        getattr(old_node, "created_at", None)
                        or old_md.get("created_at")
                        or old_md.get("reference_time")
                    )
                    version_on_supersede(
                        self._graph,
                        logical_id=old_id,
                        old_content=getattr(old_node, "content", "") or "",
                        new_content=(getattr(new_node, "content", "") or "") if new_node is not None else "",
                        reason=reason or "manual supersession",
                        evidence_ids=[],
                        ts=_dt2.fromisoformat(now) if isinstance(now, str) else _dt2.now(_tz2.utc),
                        memory_type=getattr(old_node, "memory_type", "") or "",
                        old_created_at=o_created,
                    )
            except Exception as e:
                logger.warning("supersede: bitemporal hook failed for %s: %s", old_id, e)
            return True
        except Exception as e:
            logger.warning("Failed to supersede %s by %s: %s", old_id, new_id, e)
            return False

    def ingest_superseding(self, item: "MemoryItem", supersedes: str) -> str | None:
        """Store a new node from *item* and mark it as superseding *supersedes*.

        The new node's ``origin`` is preserved exactly as given on *item* — this
        method uses the origin-preserving ``add()`` path, NOT ``ingest_structured``
        (which would overwrite origin with ``structured:{schema}``).

        After the new node is stored, a ``SUPERSEDED_BY`` edge is written
        old→new and the old node's properties are updated (``superseded=True``,
        ``superseded_by=<new_id>``, ``superseded_at=<now>``).  The
        ``MutationEvent`` for the new node is emitted *after* the
        ``SUPERSEDED_BY`` edge is written so that evolution workers see the
        supersession context on first observe.

        Ordering guarantee: ``backend.transaction_context()`` is a documented
        no-op on FalkorDB (falkordb.py:161); it is a real transaction on SQLite
        (sqlite.py:367).  Therefore node→edge ordering is a real guarantee on
        SQLite and best-effort on FalkorDB.  Correctness for the watcher↔evolver
        race rests on the Slice-3 in-place precedence guard, not this primitive.

        Implementation note (APP-VAULT-SYNC-1 P2 S3 — suppress_event refactor):
        Deferred event emission is now requested via the ``_suppress_event=True``
        kwarg on ``CRUD.add()``.  This removes the earlier S2 global-state detach
        hack (temporarily setting ``_crud._evolution_queue = None``) which was
        fragile and required a INVARIANT comment to warn against re-use.  The
        kwarg path is clean, thread-safe, and composable.

        Args:
            item: The replacement ``MemoryItem``.  ``item.origin`` is preserved
                  (e.g. ``"import:vault"``).  ``item.memory_type`` is carried to
                  the new node unchanged.
            supersedes: ``item_id`` of the node being superseded (old node).

        Returns:
            The ``item_id`` of the newly created node on success, or ``None``
            if the supersession could NOT be established (the ``SUPERSEDED_BY``
            edge / old-node property write failed).  On the failure path the
            method does NOT emit the step-3 ``MutationEvent`` and does NOT log
            the success line — a ``None`` return is the failure signal the
            autonomous caller (``VaultWatcher``) must check so it never reports
            success while leaving an orphaned ``import:vault`` node with no
            supersession edge (no-silent-degradation: the operator must know
            the body edit did not land).
        """
        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).isoformat()

        # Capture the evolution queue reference for step 3 (post-edge emission).
        _crud = getattr(self, "_crud", None)
        _eq = getattr(_crud, "_evolution_queue", None) if _crud else None

        # 1. Store the new node via add() to preserve item.origin.
        #    Pass _suppress_event=True so CRUD.add() skips automatic MutationEvent
        #    emission — we emit manually in step 3 after the SUPERSEDED_BY edge is
        #    written (edge-before-event ordering rationale).
        #    This replaces the former detach hack (_crud._evolution_queue = None +
        #    try/finally restore) which mutated shared instance state and was fragile.
        new_id = self.add(item, _suppress_event=True)

        # 2. Write the SUPERSEDED_BY edge (old→new) and update old node props.
        #    Mirror supersede() semantics (smart_memory.py:2171).
        try:
            self.update_properties(
                supersedes,
                {
                    "superseded": True,
                    "superseded_by": new_id,
                    "superseded_at": now,
                },
            )
            self.add_edge(
                source_id=supersedes,
                target_id=new_id,
                relation_type="SUPERSEDED_BY",
                properties={
                    "confidence": 1.0,
                    "conflict_type": "vault_edit",
                    "detected_at": now,
                    "detection_method": "vault_watcher",
                    "explanation": "Human edited vault page body (APP-VAULT-SYNC-1 P2 S2)",
                },
            )
        except Exception as e:
            # I-1 (no-silent-degradation): the supersession could NOT be
            # established. We MUST NOT fall through to a successful return —
            # the autonomous caller would report success and leave an
            # orphaned `import:vault` node with no SUPERSEDED_BY edge and the
            # old node unflagged (both then project as a silent duplicate).
            # Do NOT emit the step-3 MutationEvent (a node with no
            # supersession context directly defeats this slice's
            # edge-before-event ordering rationale) and do NOT log the
            # success line. Return None as the failure signal the watcher
            # checks.
            logger.warning(
                "ingest_superseding: failed to write SUPERSEDED_BY edge "
                "%s→%s: %s — supersession NOT established; returning None so "
                "the caller can surface the failure (no orphan reported as "
                "success).",
                supersedes,
                new_id,
                e,
            )
            return None

        # 3. Emit MutationEvent for the new node *after* the edge is written.
        if _crud is not None and _eq is not None:
            try:
                from smartmemory.evolution.events import MutationEvent

                self._ensure_evolution_worker()
                if self._evolution_worker is not None:
                    event = MutationEvent(
                        item_id=new_id,
                        memory_type=str(getattr(item, "memory_type", "semantic") or "semantic"),
                        operation="add",
                        workspace_id=self._resolve_scope_workspace_id()
                        or "default",  # use actual scope; fallback for OSS lite mode
                        properties={"origin": getattr(item, "origin", "unknown")},
                    )
                    _eq.put(event)
            except Exception as e:
                logger.debug("ingest_superseding: MutationEvent emission failed: %s", e)

        logger.info(
            "ingest_superseding: new node %s supersedes %s (origin=%r)",
            new_id,
            supersedes,
            getattr(item, "origin", "unknown"),
        )
        return new_id

    def get_supersession_chain(self, item_id: str) -> list[dict]:
        """Get the chain of supersessions starting from item_id.

        Follows SUPERSEDED_BY edges forward (old -> new) and backward (new -> old)
        to build the full supersession history.

        Returns:
            List of dicts with item_id, direction, and edge properties.
        """
        chain: list[dict] = []
        # SEC-TENANT-QUERIES-1 Phase 2 (audit H2): scope supersession-chain
        # traversal to the caller's workspace. Without this, a foreign item_id
        # would return its cross-tenant supersession chain.
        ws = self._resolve_scope_workspace_id()
        if ws is None:
            logger.warning(
                "tenant_isolation.scope_missing.get_supersession_chain: "
                "refusing unscoped traversal; returning empty chain."
            )
            return chain
        try:
            # Forward chain: this item was superseded by newer items (this -> newer)
            query = (
                "MATCH (n {item_id: $item_id, workspace_id: $ws})"
                "-[r:SUPERSEDED_BY]->(m) "
                "WHERE m.workspace_id = $ws "
                "RETURN m.item_id AS target_id, r.detected_at AS detected_at, "
                "r.confidence AS confidence, r.explanation AS explanation"
            )
            rows = self._graph.execute_query(query, {"item_id": item_id, "ws": ws})
            for row in rows:
                if isinstance(row, dict):
                    chain.append(
                        {
                            "item_id": row.get("target_id"),
                            "direction": "superseded_by",
                            "detected_at": row.get("detected_at"),
                            "confidence": row.get("confidence"),
                            "explanation": row.get("explanation"),
                        }
                    )
                elif isinstance(row, (list, tuple)) and len(row) >= 1:
                    chain.append(
                        {
                            "item_id": row[0],
                            "direction": "superseded_by",
                            "detected_at": row[1] if len(row) > 1 else None,
                            "confidence": row[2] if len(row) > 2 else None,
                            "explanation": row[3] if len(row) > 3 else None,
                        }
                    )

            # Backward chain: older items that were superseded by this one (older -> this)
            query = (
                "MATCH (n)-[r:SUPERSEDED_BY]->(m {item_id: $item_id, workspace_id: $ws}) "
                "WHERE n.workspace_id = $ws "
                "RETURN n.item_id AS source_id, r.detected_at AS detected_at, "
                "r.confidence AS confidence, r.explanation AS explanation"
            )
            rows = self._graph.execute_query(query, {"item_id": item_id, "ws": ws})
            for row in rows:
                if isinstance(row, dict):
                    chain.append(
                        {
                            "item_id": row.get("source_id"),
                            "direction": "supersedes",
                            "detected_at": row.get("detected_at"),
                            "confidence": row.get("confidence"),
                            "explanation": row.get("explanation"),
                        }
                    )
                elif isinstance(row, (list, tuple)) and len(row) >= 1:
                    chain.append(
                        {
                            "item_id": row[0],
                            "direction": "supersedes",
                            "detected_at": row[1] if len(row) > 1 else None,
                            "confidence": row[2] if len(row) > 2 else None,
                            "explanation": row[3] if len(row) > 3 else None,
                        }
                    )
        except Exception as e:
            logger.warning("Failed to get supersession chain for %s: %s", item_id, e)

        return chain

    def delete(self, item_id: str, **kwargs) -> bool:
        with self._di_context():
            with trace_span("memory.delete", {"memory_id": item_id}) as span:
                result = self._crud.delete(item_id)
                span.attributes["success"] = result
                # PPR cache invalidated via SmartGraph's write-hook.
                return result

    def _should_skip_query(self, query: str, **search_kwargs) -> tuple[bool, str]:
        """CORE-GATE-1: Check if query is trivial and should skip search.

        Returns (should_skip, reason). Reasons: "empty", "confirmation", "punctuation", "".
        Exempt: wildcard "*", empty with explicit recall intent (sort_by or memory type filters).
        """
        cfg = self._search_gate_config
        if not cfg or not cfg.enabled:
            return False, ""
        # Exempt wildcard search ("*" returns full corpus)
        if query and query.strip() == "*":
            return False, ""

        memory_type = search_kwargs.get("memory_type")
        memory_types = search_kwargs.get("memory_types") or []
        has_memory_type_intent = bool(memory_type) or bool(memory_types)

        # Exempt empty-query when caller specifies recall intent.
        # Empty + memory_type(s) is corpus enumeration; empty + sort_by is recency recall.
        if not query or not query.strip():
            if search_kwargs.get("sort_by") or has_memory_type_intent:
                return False, ""
            return True, "empty"
        if len(query.strip()) < cfg.min_query_length:
            return True, "empty"
        q = query.strip().lower()
        if q in cfg.skip_tokens:
            return True, "confirmation"
        if not any(c.isalnum() for c in q):
            return True, "punctuation"
        return False, ""

    @staticmethod
    def _coerce_dt(value):
        """Best-effort coerce a value to a tz-aware UTC datetime, or None."""
        from datetime import datetime as _dt, timezone as _tz

        if value is None:
            return None
        if isinstance(value, _dt):
            return value if value.tzinfo else value.replace(tzinfo=_tz.utc)
        if isinstance(value, str):
            try:
                d = _dt.fromisoformat(value.replace("Z", "+00:00"))
                return d if d.tzinfo else d.replace(tzinfo=_tz.utc)
            except ValueError:
                return None
        return None

    def _apply_as_of_filter(self, results, as_of_date):
        """CORE-BITEMPORAL-1 transaction-time travel.

        For each result with a version chain, reconstruct the belief the
        system held at ``as_of_date`` (substitute content; drop if no
        version was current then). Items with no version chain are a single
        never-superseded belief: kept unless their creation time is strictly
        after ``as_of_date`` (they did not exist yet). On any per-item
        resolution error the item is KEPT and a WARNING is logged — never
        silently discarded (no-silent-degradation).
        """
        from smartmemory.temporal.version_tracker import VersionTracker

        as_of = self._coerce_dt(as_of_date)
        if as_of is None:
            logger.warning("as_of_date could not be coerced to a datetime; skipping as-of filter")
            return results

        try:
            vt = VersionTracker(self._graph)
        except Exception as e:  # pragma: no cover - defensive
            logger.warning("as-of filter: VersionTracker unavailable (%s); returning unfiltered", e)
            return results

        resolved = []
        for r in results:
            item_id = getattr(r, "item_id", None)
            if not item_id:
                resolved.append(r)
                continue
            try:
                versions = vt.get_versions(item_id, include_closed=True)
                if versions:
                    v = vt.get_version_at_time(item_id, as_of, time_type="transaction")
                    if v is None:
                        # No belief held at that instant — exclude.
                        continue
                    if (getattr(r, "content", None) or "") == (v.content or ""):
                        resolved.append(r)
                    else:
                        # MemoryItem.content is immutable once set, so a
                        # historical belief cannot be written in place. Return
                        # a copy carrying the resolved version's content. If
                        # the copy fails we surface it — never silently return
                        # the present belief for an as-of query.
                        try:
                            import copy as _copy

                            rc = _copy.copy(r)
                            object.__setattr__(rc, "content", v.content)
                            resolved.append(rc)
                        except Exception as e:
                            logger.warning(
                                "as-of: could not materialize historical content for "
                                "%s (%s); excluding to avoid returning the wrong "
                                "belief",
                                item_id,
                                e,
                            )
                            continue
                else:
                    created = self._coerce_dt(
                        getattr(r, "created_at", None)
                        or (getattr(r, "metadata", None) or {}).get("created_at")
                        or (getattr(r, "metadata", None) or {}).get("reference_time")
                    )
                    if created is not None and created > as_of:
                        continue  # did not exist yet at as_of_date
                    resolved.append(r)
            except Exception as e:
                logger.warning(
                    "as-of resolution failed for %s (%s); keeping item to avoid silent loss",
                    item_id,
                    e,
                )
                resolved.append(r)
        return resolved

    def search(
        self,
        query: str,
        top_k: int = 5,
        memory_type: str = None,
        conversation_context: Optional[Union[ConversationContext, Dict[str, Any]]] = None,
        decompose_query: bool = False,
        origin: Optional[str] = None,
        exclude_origins: Optional[list] = None,
        channel_weights: Optional[dict] = None,
        multi_hop: bool = False,
        max_hops: int = 3,
        budget_ms: int = 1500,
        semantic_hops: bool = False,
        cleanup: bool = False,  # SEARCH-MULTIHOP-CLEANUP-1: per-hop entity cleanup
        attention_fusion=None,  # CORE-ATTENTION-FUSION-1: per-call override of self._attention_fusion
        include_superseded: bool = False,
        include_consolidated: bool = False,
        expertise: bool = False,  # CORE-EXPERTISE-1 Phase 4a: typed-dict expertise channel
        as_of_date: Optional[Any] = None,  # CORE-BITEMPORAL-1: transaction-time travel (datetime | ISO-8601 str)
        **kwargs,
    ):
        """
        Search using canonical search component with automatic scope filtering.

        Filtering by tenant/workspace/user is handled automatically by ScopeProvider.
        This ensures consistent isolation across all search operations.

        Args:
            origin: If set, only return items whose origin starts with this prefix.
            exclude_origins: List of origin prefixes to exclude from results.
            multi_hop: If True, run multi-hop recursive retrieval (RLM-1c).
            max_hops: Maximum chain depth for multi-hop (1-10, default 3).
            budget_ms: Total time budget in ms across all hops (>= 100, default 1500).
            include_superseded: If True, include superseded memories in results (CORE-SUPERSEDE-1).
            as_of_date: Transaction-time travel (CORE-BITEMPORAL-1). When set,
                each result is resolved to the belief the system held at that
                wall-clock instant: versioned items return the version current
                then (or are dropped if none was), and items created after
                as_of_date are excluded. Distinct from include_superseded
                (a visibility flag, not a time filter).
        """
        # CORE-GATE-1: skip trivial queries before any search execution
        _skip, _reason = self._should_skip_query(query, memory_type=memory_type, **kwargs)
        if _skip:
            from smartmemory.observability.tracing import trace_log

            trace_log("search.gate_skip", {"reason": _reason, "query_length": len(query or "")})
            logger.debug("search gate skipped query (reason=%s)", _reason)
            if expertise:
                # CORE-EXPERTISE-1 Phase 4a: preserve typed-dict contract on gate skip.
                from smartmemory.search.expertise import EXPERTISE_TYPES

                return {k: [] for k in EXPERTISE_TYPES}
            return []

        # RLM-1c: validate multi-hop params early (before working memory branch)
        if multi_hop:
            if not (1 <= max_hops <= 10):
                raise ValueError(f"max_hops must be 1-10, got {max_hops}")
            if budget_ms < 100:
                raise ValueError(f"budget_ms must be >= 100, got {budget_ms}")
            if memory_type == "pending":
                raise ValueError("multi_hop is not supported for pending memory searches.")

        # CORE-SEARCH-2a: inject channel_weights into kwargs for all search paths
        if channel_weights is not None:
            kwargs["channel_weights"] = channel_weights

        if memory_type == "pending":
            if expertise:
                # CORE-EXPERTISE-1 Phase 4a: pending memory has no expertise types by construction.
                raise ValueError("expertise is not supported for pending memory searches.")
            if decompose_query:
                import hashlib

                logger.warning(
                    "decompose_query ignored for pending memory",
                    extra={
                        "reason": "pending_memory_exempt",
                        "memory_type": memory_type,
                        "decompose_query": decompose_query,
                        "query_hash": hashlib.sha256(str(query or "").encode()).hexdigest()[:12],
                    },
                )
            # Pending memory lives in the graph like every other memory type.
            # ScopeProvider handles tenant/user filtering automatically.
            _pm_fetch_k = top_k * 3 if (origin or exclude_origins) else top_k
            with self._di_context():
                results = self._search.search(query, top_k=_pm_fetch_k, memory_type="pending", **kwargs)

            # Optional: filter by conversation_id when provided
            conv_id = None
            try:
                if isinstance(conversation_context, ConversationContext):
                    conv_id = conversation_context.conversation_id
                elif isinstance(conversation_context, dict):
                    conv_id = conversation_context.get("conversation_id")
            except Exception as e:
                logger.debug(f"Failed to extract conversation_id from conversation_context: {e}")
                conv_id = None
            if conv_id and results:
                results = [r for r in results if getattr(r, "metadata", {}).get("conversation_id") == conv_id]

            # CORE-ORIGIN-1: apply origin filters on pending memory path
            if origin:
                results = [r for r in results if getattr(r, "origin", "").startswith(origin)]
            if exclude_origins:
                results = [
                    r for r in results if not any(getattr(r, "origin", "").startswith(p) for p in exclude_origins)
                ]
            # CORE-RECALL-LINEAGE-1 Phase 1: default-tier visibility filter
            # (mirrors the main search path above).
            if not origin:
                from smartmemory.origin_policy import filter_by_tiers, get_default_tiers

                results = filter_by_tiers(results, get_default_tiers("search"))
            return results[:top_k]

        # Use canonical search component directly
        # ScopeProvider handles all tenant/workspace/user filtering automatically.
        # _di_context must be outer so trace_span entry/exit see the per-instance config.
        with self._di_context():
            with trace_span(
                "memory.search",
                {
                    "query_length": len(query) if query else 0,
                    "top_k": top_k,
                    "memory_type": memory_type,
                },
            ) as span:
                # CORE-ORIGIN-1 + CORE-RERANK-1: over-fetch computation
                # Compute rerank skip conditions early so we don't over-fetch
                # for paths that won't rerank (structured, recency, wildcard).
                _structured_types = {"plan", "plan_task", "decision", "anchor", "tool_call", "hook_capture"}
                _skip_rerank = (
                    not self._reranker_config.enabled
                    or (memory_type in _structured_types if memory_type else False)
                    or kwargs.get("sort_by") == "recency"
                    or not query
                    or query.strip() in ("", "*")
                )
                # CORE-RECALL-LINEAGE-1 Phase 1: default tier filtering hides
                # tier-4 origins (hook:, structured:, version:snapshot, unknown
                # via legacy branch). Over-fetch 2x by default so the tier filter
                # cannot underfill top_k when tier-4 noise crowds the top of
                # the unfiltered result list. Explicit origin=/exclude_origins=
                # still bump to 3x.
                _origin_multiplier = 3 if (origin or exclude_origins) else 2
                _supersede_multiplier = 2 if not include_superseded else 1  # CORE-SUPERSEDE-1
                _consolidated_multiplier = 2 if not include_consolidated else 1  # CORE-CONSOLIDATE-1
                _rerank_multiplier = self._reranker_config.top_k_multiplier if not _skip_rerank else 1
                _expertise_multiplier = 3 if expertise else 1  # CORE-EXPERTISE-1 Phase 4a
                _fetch_k = (
                    top_k
                    * _origin_multiplier
                    * _supersede_multiplier
                    * _consolidated_multiplier
                    * _rerank_multiplier
                    * _expertise_multiplier
                )
                # CORE-ATTENTION-FUSION-1: per-call override wins over instance default
                _fusion_cfg = attention_fusion if attention_fusion is not None else self._attention_fusion
                if multi_hop and decompose_query:
                    # CORE-MULTIHOP-2: decompose first, then multi-hop each sub-query
                    results = self._decomposed_multi_hop_search(
                        query,
                        _fetch_k,
                        max_hops,
                        budget_ms,
                        memory_type=memory_type,
                        semantic_hops=semantic_hops,
                        fusion_config=_fusion_cfg,
                        cleanup=cleanup,
                        **kwargs,
                    )
                elif multi_hop:
                    results = self._multi_hop_search(
                        query,
                        _fetch_k,
                        max_hops,
                        budget_ms,
                        memory_type=memory_type,
                        semantic_hops=semantic_hops,
                        fusion_config=_fusion_cfg,
                        cleanup=cleanup,
                        **kwargs,
                    )
                elif decompose_query:
                    results = self._decomposed_search(query, _fetch_k, memory_type, **kwargs)
                else:
                    results = self._search.search(query, top_k=_fetch_k, memory_type=memory_type, **kwargs)
                span.attributes["results_count"] = len(results) if results else 0
                # CORE-ORIGIN-1: filter by origin prefix BEFORE top_k truncation
                if origin:
                    results = [r for r in results if getattr(r, "origin", "").startswith(origin)]
                if exclude_origins:
                    results = [
                        r for r in results if not any(getattr(r, "origin", "").startswith(p) for p in exclude_origins)
                    ]
                # CORE-RECALL-LINEAGE-1 Phase 1: apply default-tier visibility
                # filter unless the caller asked for a specific prefix. Tier-4
                # origins (hook:, structured:, version:snapshot) are dropped;
                # legacy 'unknown'-origin items remain visible via the
                # filter_by_tiers legacy branch (intentional — predates CORE-
                # ORIGIN-1 and has no producer-set tag to discriminate on).
                if not origin:
                    from smartmemory.origin_policy import filter_by_tiers, get_default_tiers

                    results = filter_by_tiers(results, get_default_tiers("search"))
                # CORE-SUPERSEDE-1: filter out superseded memories by default.
                # CORE-BITEMPORAL-1: when as_of_date is set, retain superseded
                # items so the transaction-time resolver can reconstruct the
                # belief held at that instant.
                if not include_superseded and as_of_date is None:
                    from smartmemory.pipeline.stages.supersede import _is_superseded

                    results = [r for r in results if not _is_superseded(r)]
                # CORE-CONSOLIDATE-1 amendment: filter out consolidated sources by default
                if not include_consolidated:
                    results = [r for r in results if not (getattr(r, "metadata", None) or {}).get("consolidated")]
                # CORE-BITEMPORAL-1: transaction-time travel — resolve each
                # result to the belief the system held at as_of_date.
                if as_of_date is not None:
                    results = self._apply_as_of_filter(results, as_of_date)
                # CORE-RERANK-1: cross-encoder reranking before top_k truncation
                if not _skip_rerank and len(results) > 1:
                    from smartmemory.search.rerank import CrossEncoderReranker

                    results = CrossEncoderReranker.rerank(
                        query,
                        results,
                        top_k,
                        model_name=self._reranker_config.model,
                        budget_ms=self._reranker_config.budget_ms,
                    )
                # Temporal boost: prefer earlier sessions for "when" queries
                # Only apply when reranking was active — skip for recency sort,
                # structured types, wildcard, and disabled reranker paths.
                if not _skip_rerank and len(results) > 1:
                    from smartmemory.search.rerank import CrossEncoderReranker as _CER

                    results = _CER.temporal_boost(query, results)
                if expertise:
                    # CORE-EXPERTISE-1 Phase 4a: bucket the (already reranked) pool into a typed
                    # dict; per-bucket cap = top_k. Skip the global top_k truncation.
                    from datetime import datetime as _dt, timezone as _tz

                    from smartmemory.search.expertise import filter_and_boost

                    final_results = filter_and_boost(results, now=_dt.now(_tz.utc), top_k=top_k)
                    _flat = [item for bucket in final_results.values() for item in bucket]
                else:
                    final_results = results[:top_k]
                    _flat = final_results
                try:
                    from smartmemory.observability.retrieval_tracking import emit_retrieval_search

                    emit_retrieval_search(_flat, query, self.scope_provider)
                except Exception:
                    pass  # observability failure must never affect search() return
                # CORE-PROPS-1 Phase 3 atomic batch access tracking.
                # PLAT-SQLITE-SEGFAULT-1: was a daemon thread; spike showed
                # increment_access p99 < 1ms even at 100 ids — async wrapper
                # cost more than the work it deferred and decoupled the write
                # lifetime from the SQLite connection (SIGSEGV on close).
                if _flat:
                    try:
                        from datetime import datetime as _dt, timezone as _tz

                        _ids = [getattr(r, "item_id", None) for r in _flat]
                        _ids = [i for i in _ids if i]
                        if _ids:
                            self._graph.backend.increment_access(_ids, _dt.now(_tz.utc).isoformat())
                    except Exception:
                        pass  # access tracking failure must never affect search() return
                return final_results

    # =========================================================================
    # Surfacing API — CORE-MEMORY-DYNAMICS-1 M1a
    # =========================================================================

    def get_working_context(
        self,
        session_id: str,
        query: str,
        k: int = 20,
        max_tokens: Optional[int] = None,
        strategy: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Return a contract-shaped surfacing response for the current turn.

        M1a stub: delegates to cross-type ``search()``, force-includes active
        anchors, and applies recency × relevance ranking.  ``strategy_used``
        is the fixed literal ``"fast:recency"`` — the full SurfacingRouter
        that expands this to multiple strategies arrives in M3a/M3b.

        Args:
            session_id: Session scope for anchor resolution.
            query:      Natural-language query.
            k:          Item-count cap on returned items.
            max_tokens: Token-budget cap (see contract).
            strategy:   Override hint — honored if set, else ``fast:recency``.

        Returns:
            Dict matching ``context-api-contract.json`` response shape.

        Raises:
            BudgetTooSmall: when ``max_tokens`` is smaller than the smallest
                mandatory item's token count.  Empty-result corpora return
                an empty ``items`` array without raising.
        """
        import uuid as _uuid

        from smartmemory.activation.constants import (
            FRESHNESS_BOOST_WEIGHT,
            FRESHNESS_WINDOW_HOURS,
            SESSION_PIN_MULTIPLIER,
        )
        from smartmemory.anchors.queries import AnchorQueries
        from smartmemory.search.surfacing_router import (
            SurfacingDecision,
            SurfacingRouter,
            SurfacingStrategy,
        )

        # Input validation — contract request section.
        if k < 1 or k > 100:
            raise ValueError(f"k must be in 1..100, got {k}")

        # ── Strategy precedence (M3 Slice A.3.4) ───────────────────────
        # Rule: explicit caller strategy wins; else router classifies (when
        # router mode is on); else default to fast:recency. Legacy mode
        # preserves the M1a loud-reject contract for non-fast:recency
        # explicit strategies.
        if self._surfacing_mode == "legacy":
            if strategy is not None and strategy != "fast:recency":
                raise ValueError(
                    f"strategy={strategy!r} is not implemented in M1a "
                    f"(legacy surfacing_mode); use surfacing_mode='router' "
                    f"or None/'fast:recency'",
                )
            decision = SurfacingDecision(
                strategy=SurfacingStrategy.FAST_RECENCY,
                confidence=1.0,
                reasons=["legacy_mode"],
                signals={},
            )
        else:  # router mode
            if strategy is not None:
                # Caller-explicit strategy wins.
                try:
                    chosen = SurfacingStrategy(strategy)
                except ValueError as exc:
                    raise ValueError(
                        f"unknown strategy {strategy!r}; valid values: {[s.value for s in SurfacingStrategy]}",
                    ) from exc
                decision = SurfacingDecision(
                    strategy=chosen,
                    confidence=1.0,
                    reasons=["caller_explicit"],
                    signals={},
                )
            else:
                decision = SurfacingRouter().classify(query)

            # A.3.7 — reserved strategies soft-degrade in router mode.
            if decision.strategy in (
                SurfacingStrategy.PROCEDURAL_LOOKUP,
                SurfacingStrategy.TEMPORAL_WINDOWED,
            ):
                logger.info(
                    "get_working_context: reserved strategy %s soft-degrading to fast:recency (not shipped in M3)",
                    decision.strategy.value,
                )
                decision = SurfacingDecision(
                    strategy=SurfacingStrategy.FAST_RECENCY,
                    confidence=decision.confidence,
                    reasons=decision.reasons
                    + [
                        "unimplemented_strategy_soft_degrade",
                    ],
                    signals=dict(decision.signals),
                )

        # Expose decision for observability / testing.
        self.last_surfacing_decision = decision
        strategy_used = decision.strategy.value
        in_router_mode = self._surfacing_mode == "router"

        # ── Session pins ────────────────────────────────────────────────
        # Read the pin set for this session once per call. Pinned items are
        # force-included (like anchors) and receive session_pin_boost in
        # the composite.
        #
        # **Workspace-bound-read** — SessionPinStore.pin() enforces a
        # write-side workspace binding (raises on cross-workspace). The
        # read side must enforce the matching invariant: if the session
        # is bound to a different workspace than the current memory's
        # scope provider, treat pins as empty. Otherwise a reused
        # session_id across workspaces could inherit another workspace's
        # pin set and surface cross-workspace items (Codex r1 finding).
        session_pins: Dict[str, float] = {}
        try:
            session_redis = self._session_redis_client()
            if session_redis is not None:
                from smartmemory.session.pins import SessionPinStore

                store = SessionPinStore(session_redis)
                current_ws = getattr(
                    getattr(self, "_scope_provider", None) or getattr(self, "scope_provider", None),
                    "workspace_id",
                    None,
                )
                bound_ws = store.get_workspace(session_id)
                if bound_ws is None or bound_ws == current_ws:
                    session_pins = store.get_pins(session_id)
                else:
                    logger.warning(
                        "get_working_context: session %s is pinned to "
                        "workspace %s; current memory is in %s — ignoring "
                        "pins for this call (cross-workspace leak guard)",
                        session_id,
                        bound_ws,
                        current_ws,
                    )
        except Exception as exc:
            logger.debug(
                "get_working_context: session-pin lookup failed for session=%s: %s",
                session_id,
                exc,
            )
            session_pins = {}

        decision_id = _uuid.uuid4().hex

        # Context assembly is not a user retrieval — tag the contextvar so the
        # retrieval hook suppresses activation boosts on the candidate hits.
        # Otherwise every get_working_context() call would self-boost every
        # surfaced item, creating a positive feedback loop (Codex r3).
        from smartmemory.observability.retrieval_tracking import retrieval_source

        _source_token = retrieval_source.set("context_assembly")
        try:
            # Over-fetch for ranking headroom per blueprint.
            raw_hits = list(self.search(query=query, top_k=max(k * 5, k)) or [])
        finally:
            retrieval_source.reset(_source_token)

        # Active anchors — force-included.
        # Drift warnings — read persisted needs_review state flagged by
        # AnchorReconciliationEvolver. Async compute + sync read keeps the
        # retrieval hot path off any LLM-ish drift computation.
        anchor_queries = AnchorQueries(self)
        try:
            anchor_rows = anchor_queries.get_active(session_id) or []
        except Exception:
            anchor_rows = []
        drift_warnings = self._collect_drift_warnings(
            anchor_queries,
            session_id,
        )

        # Build ranked item list.  Anchors first, then search results (de-duped).
        anchor_ids = {row.get("anchor_id") for row in anchor_rows}
        # Anchors are contract-mandatory — fabricate lightweight item dicts.
        # Activation is computed from the underlying MemoryItem when fetchable
        # (anchor rows come from AnchorQueries as dicts, which don't carry
        # metadata.activation). Fetch failure falls back to DEFAULT_SCORE; the
        # anchor is still force-included regardless.
        ranked: List[Dict[str, Any]] = []
        for row in anchor_rows:
            anchor_id = row.get("anchor_id")
            anchor_activation = ACTIVATION_DEFAULT_SCORE
            if anchor_id:
                # Use _crud.get directly to bypass retrieval-tracking (and
                # the activation boost it triggers via Slice B.3). Context
                # assembly must not masquerade as a user retrieval — that
                # would create a self-reinforcing feedback loop on anchors.
                try:
                    anchor_item = self._crud.get(anchor_id)
                    if anchor_item is not None:
                        anchor_activation = compute_activation_score(anchor_item)
                except Exception:
                    pass
            ranked.append(
                {
                    "item_id": anchor_id,
                    "content": row.get("content", ""),
                    "memory_type": row.get("anchor_type", "anchor"),
                    "metadata": {
                        "session_id": row.get("session_id"),
                        "anchor_status": row.get("status"),
                        "created_at": row.get("created_at"),
                    },
                    "score_breakdown": {
                        "activation": anchor_activation,
                        "relevance": 1.0,
                        "recency": 1.0,
                        # Slice A marker: router-mode centrality stays 0 until
                        # PPR lands in Slice C. Legacy mode keeps 1.0 so the
                        # legacy composite's multiplicative path is unchanged.
                        "centrality": 0.0 if in_router_mode else 1.0,
                        "anchor_forced": True,
                        "session_pin_boost": 0.0,
                        "freshness_boost": 0.0,
                    },
                    "_tokens": _estimate_tokens(row.get("content", "")),
                    "_mandatory": True,
                }
            )

        # Score each search hit. In legacy mode: the M1a composite
        # (relevance × recency × max(activation, floor)) with all new
        # fields zero. In router mode: wire session_pin_boost and
        # freshness_boost from metadata; centrality stays 0 until Slice C.
        for hit in raw_hits:
            hit_id = getattr(hit, "item_id", None)
            if hit_id and hit_id in anchor_ids:
                continue  # already force-included
            content = getattr(hit, "content", "")
            rel = float(getattr(hit, "score", 0.0) or 0.0)
            # Recency weight comes from metadata timestamp when present; default 0.5.
            md = getattr(hit, "metadata", {}) or {}
            recency = _recency_weight(md)
            pin_weight = session_pins.get(hit_id, 0.0) if hit_id else 0.0
            pin_boost = pin_weight * SESSION_PIN_MULTIPLIER if in_router_mode else 0.0
            fresh_boost = (
                _freshness_boost(md, FRESHNESS_WINDOW_HOURS, FRESHNESS_BOOST_WEIGHT) if in_router_mode else 0.0
            )
            # Legacy mode keeps centrality=1.0 (M1a stub value) because the
            # legacy composite multiplies it. Router mode uses 0.0 as the
            # Slice-A marker — Slice C fills it with PPR values.
            centrality = 0.0 if in_router_mode else 1.0
            ranked.append(
                {
                    "item_id": hit_id,
                    "content": content,
                    "memory_type": getattr(hit, "memory_type", "semantic"),
                    "metadata": dict(md),
                    "score_breakdown": {
                        "activation": compute_activation_score(hit),
                        "relevance": rel,
                        "recency": recency,
                        "centrality": centrality,
                        "anchor_forced": False,
                        "session_pin_boost": pin_boost,
                        "freshness_boost": fresh_boost,
                    },
                    "_tokens": _estimate_tokens(content),
                    "_mandatory": bool(pin_weight > 0),
                    "_pin_weight": pin_weight,
                }
            )

        # Composite ranking. Legacy preserves the M1a formula byte-for-byte.
        # Router mode uses the revised additive-lift formula from
        # design-m3.md §3.1:
        #
        #   base = max(activation, ACTIVATION_FLOOR) * relevance * recency
        #   centrality_lift = 1 + PPR_WEIGHT * centrality_norm    [≡ 1.0 in Slice A]
        #   score = base * centrality_lift + anchor_forced + session_pin + freshness
        def _composite(row: Dict[str, Any]) -> float:
            sb = row.get("score_breakdown") or {}
            activation = float(sb.get("activation", ACTIVATION_DEFAULT_SCORE))
            if in_router_mode:
                base = (
                    max(activation, ACTIVATION_FLOOR) * float(sb.get("relevance", 0.0)) * float(sb.get("recency", 0.0))
                )
                # centrality_norm=0 in Slice A (PPR lands in Slice C), so
                # centrality_lift collapses to 1.0. The term is still
                # computed so the formula shape is identical across slices.
                centrality_norm = float(sb.get("centrality", 0.0))
                from smartmemory.activation.constants import PPR_WEIGHT

                centrality_lift = 1.0 + PPR_WEIGHT * centrality_norm
                additive = (
                    (1.0 if sb.get("anchor_forced") else 0.0)
                    + float(sb.get("session_pin_boost", 0.0))
                    + float(sb.get("freshness_boost", 0.0))
                )
                return base * centrality_lift + additive
            # Legacy composite — unchanged from M1a.
            return float(sb.get("relevance", 0.0)) * float(sb.get("recency", 0.0)) * max(activation, ACTIVATION_FLOOR)

        # ── PPR centrality (M3 Slice C.6) ──────────────────────────────
        # PPR runs in router-mode deep:multi-hop. Produces per-item
        # centrality scores that feed into the bounded additive lift in
        # the composite. Cached per (workspace, seed_hash) with write-
        # through invalidation from mutation paths.
        ppr_scores: Dict[str, float] = {}
        if in_router_mode and decision.strategy == SurfacingStrategy.DEEP_MULTI_HOP and raw_hits:
            from smartmemory.search.ppr import personalized_pagerank

            ppr_seed_ids = [getattr(h, "item_id", None) for h in raw_hits[:5] if getattr(h, "item_id", None)]
            if ppr_seed_ids:
                try:
                    current_ws = getattr(
                        getattr(self, "_scope_provider", None) or getattr(self, "scope_provider", None),
                        "workspace_id",
                        None,
                    )
                    ppr_scores = personalized_pagerank(
                        self,
                        seed_item_ids=ppr_seed_ids,
                        cache=self._ppr_cache(),
                        workspace_id=current_ws,
                    )
                except Exception as exc:
                    logger.debug(
                        "get_working_context: PPR failed, centrality falls through to 0.0: %s",
                        exc,
                    )
                    ppr_scores = {}

        # ── Spreading activation (M3 Slice B.3) ─────────────────────────
        # Only router-mode deep:multi-hop invokes spreading. The scores
        # feed into the composite as an activation floor bump per design
        # §6.5: spreading-discovered items get their effective activation
        # raised to max(stored, spreading_score, ACTIVATION_FLOOR).
        spreading_scores: Dict[str, float] = {}
        if in_router_mode and decision.strategy == SurfacingStrategy.DEEP_MULTI_HOP and raw_hits:
            from smartmemory.search.spreading_activation import spread

            # Use top search hits as seeds. Capping at 5 keeps the
            # BFS frontier bounded in dense graphs.
            seed_ids = [getattr(h, "item_id", None) for h in raw_hits[:5] if getattr(h, "item_id", None)]
            if seed_ids:
                # spread() catches FalkorDB ResponseError internally and
                # returns {} on timeout/query-error. Other exceptions
                # (ValueError, bugs in callers, etc.) SHOULD propagate —
                # swallowing them would silently degrade 'deep:multi-hop'
                # to lexical-only while still reporting the strategy as
                # used, hiding real regressions. No try/except here.
                spreading_scores = spread(
                    self,
                    seed_item_ids=seed_ids,
                )

        # Apply the spreading floor bump to existing ranked rows and
        # force-include spreading-discovered items that weren't in raw_hits.
        if spreading_scores:
            ranked_by_id = {r.get("item_id"): r for r in ranked if r.get("item_id")}
            for item_id, spread_score in spreading_scores.items():
                if item_id in ranked_by_id:
                    # Bump the activation floor on existing row.
                    row = ranked_by_id[item_id]
                    sb = row["score_breakdown"]
                    current = float(sb.get("activation", 0.0))
                    bumped = max(current, float(spread_score), ACTIVATION_FLOOR)
                    sb["activation"] = bumped
                else:
                    # Spreading-discovered — fetch and add. The item
                    # wasn't a lexical match, so relevance=0 would zero
                    # out the multiplicative base. Use the spreading
                    # score itself as the relevance proxy — it IS a
                    # graph-structural relevance signal, just not a
                    # lexical one.
                    try:
                        new_item = self._crud.get(item_id)
                    except Exception:
                        new_item = None
                    if new_item is None:
                        continue
                    nm_md = getattr(new_item, "metadata", {}) or {}
                    stored_act = compute_activation_score(new_item)
                    bumped_act = max(
                        stored_act,
                        float(spread_score),
                        ACTIVATION_FLOOR,
                    )
                    # If this item is also session-pinned, the spreading
                    # path must preserve the pin semantics — otherwise
                    # pinned-through-spreading items lose both their
                    # _mandatory flag and their session_pin_boost. Flagged
                    # by Codex r1 on the Slice B.3 integration commit.
                    pinned_weight = session_pins.get(item_id, 0.0)
                    pin_boost_val = float(pinned_weight) * SESSION_PIN_MULTIPLIER if pinned_weight else 0.0
                    ranked.append(
                        {
                            "item_id": item_id,
                            "content": getattr(new_item, "content", ""),
                            "memory_type": getattr(
                                new_item,
                                "memory_type",
                                "semantic",
                            ),
                            "metadata": dict(nm_md),
                            "score_breakdown": {
                                "activation": bumped_act,
                                "relevance": float(spread_score),
                                "recency": _recency_weight(nm_md),
                                "centrality": 0.0,
                                "anchor_forced": False,
                                "session_pin_boost": pin_boost_val,
                                "freshness_boost": _freshness_boost(
                                    nm_md,
                                    FRESHNESS_WINDOW_HOURS,
                                    FRESHNESS_BOOST_WEIGHT,
                                ),
                            },
                            "_tokens": _estimate_tokens(
                                getattr(new_item, "content", ""),
                            ),
                            "_mandatory": bool(pinned_weight > 0),
                            "_pin_weight": float(pinned_weight),
                        }
                    )

        # M3 Slice A — pinned items that weren't in raw_hits must still
        # be force-included. Fetch each missing pinned id via _crud.get
        # (non-boosting read path per feedback_trace_before_every_fix) and
        # append it to ranked with _mandatory=True.
        if in_router_mode and session_pins:
            already_in_ranked = {r.get("item_id") for r in ranked if r.get("item_id")}
            for pinned_id, pinned_weight in session_pins.items():
                if pinned_id in already_in_ranked:
                    continue
                try:
                    pinned_item = self._crud.get(pinned_id)
                except Exception:
                    pinned_item = None
                if pinned_item is None:
                    continue  # pin references a deleted/unfetchable item
                pm_md = getattr(pinned_item, "metadata", {}) or {}
                pin_boost_val = float(pinned_weight) * SESSION_PIN_MULTIPLIER
                fresh_val = _freshness_boost(
                    pm_md,
                    FRESHNESS_WINDOW_HOURS,
                    FRESHNESS_BOOST_WEIGHT,
                )
                ranked.append(
                    {
                        "item_id": pinned_id,
                        "content": getattr(pinned_item, "content", ""),
                        "memory_type": getattr(pinned_item, "memory_type", "semantic"),
                        "metadata": dict(pm_md),
                        "score_breakdown": {
                            "activation": compute_activation_score(pinned_item),
                            "relevance": 0.0,  # not a query match
                            "recency": _recency_weight(pm_md),
                            "centrality": 0.0,
                            "anchor_forced": False,
                            "session_pin_boost": pin_boost_val,
                            "freshness_boost": fresh_val,
                        },
                        "_tokens": _estimate_tokens(
                            getattr(pinned_item, "content", ""),
                        ),
                        "_mandatory": True,
                        "_pin_weight": float(pinned_weight),
                    }
                )

        # ── Populate centrality from PPR (M3 Slice C.6) ─────────────────
        # Normalize PPR scores to [0, 1] over the candidate set so the
        # centrality_lift (1 + PPR_WEIGHT * centrality) is bounded.
        if ppr_scores:
            candidate_ppr = {
                r.get("item_id"): ppr_scores.get(r.get("item_id"), 0.0) for r in ranked if r.get("item_id")
            }
            max_ppr = max(candidate_ppr.values()) if candidate_ppr else 0.0
            if max_ppr > 0:
                for r in ranked:
                    iid = r.get("item_id")
                    if iid in candidate_ppr:
                        sb = r.get("score_breakdown") or {}
                        sb["centrality"] = candidate_ppr[iid] / max_ppr

        mandatory_first = [r for r in ranked if r.get("_mandatory")]
        non_mandatory = [r for r in ranked if not r.get("_mandatory")]
        non_mandatory.sort(key=_composite, reverse=True)
        # Sort mandatory items among themselves by composite so the highest-
        # scoring anchor/pin ranks first. Keeps ordering stable for tests.
        mandatory_first.sort(key=_composite, reverse=True)
        ranked = mandatory_first + non_mandatory

        # Budget gate — smallest anchor must fit. Per plan-m1a.md §4: if
        # any anchors exist the smallest mandatory is min(anchor tokens);
        # else it's the single highest-ranked item's tokens. Pinned items
        # (mandatory in the ranking sense but caller-requested) do NOT
        # participate in the budget raise — a caller asking for pins
        # knowingly accepts the size implication. Empty corpora never
        # raise (no mandatory item exists).
        if max_tokens is not None and ranked:
            anchor_token_counts = [
                r["_tokens"] for r in ranked if (r.get("score_breakdown") or {}).get("anchor_forced")
            ]
            if anchor_token_counts:
                smallest_mandatory = min(anchor_token_counts)
                if smallest_mandatory > max_tokens:
                    raise BudgetTooSmall(
                        f"budget_too_small: max_tokens={max_tokens} cannot "
                        f"fit the smallest anchor ({smallest_mandatory} tokens)"
                    )

        # Truncate to k, then to token budget.  When a later item is small
        # enough to fit remaining budget, take it — do not stop at the first
        # overflow (Codex review finding).
        trimmed: List[Dict[str, Any]] = []
        tokens_used = 0
        if in_router_mode:
            # Router mode (M3 Slice A) — mandatory items always included
            # regardless of k and max_tokens; non-mandatory capped at k
            # total and skipped over budget.
            mandatory_count = sum(1 for r in ranked if r.get("_mandatory"))
            for r in ranked:
                is_mandatory = r.pop("_mandatory", False)
                r.pop("_pin_weight", None)
                item_tokens = r.pop("_tokens")
                if not is_mandatory and (len(trimmed) - mandatory_count) >= k:
                    break  # k cap reached on non-mandatory items
                if max_tokens is not None and tokens_used + item_tokens > max_tokens and not is_mandatory:
                    continue  # over-budget non-mandatory; smaller may fit
                trimmed.append(r)
                tokens_used += item_tokens
        else:
            # Legacy mode — preserves M1a behaviour byte-for-byte. Total
            # output capped at k; anchors beyond the smallest-fit get
            # dropped + WARN logged.
            dropped_anchors: List[str] = []
            for r in ranked[: k + len(anchor_rows)]:
                if len(trimmed) >= k:
                    break
                item_tokens = r.pop("_tokens")
                is_mandatory = r.pop("_mandatory", False)
                r.pop("_pin_weight", None)
                if max_tokens is not None and tokens_used + item_tokens > max_tokens:
                    if is_mandatory:
                        dropped_anchors.append(str(r.get("item_id")))
                    continue
                trimmed.append(r)
                tokens_used += item_tokens
            if dropped_anchors:
                logger.warning(
                    "get_working_context dropped %d anchor(s) under max_tokens=%s: %s",
                    len(dropped_anchors),
                    max_tokens,
                    dropped_anchors,
                )

        # Emit telemetry (best-effort).
        try:
            from smartmemory.observability.tracing import trace_log

            trace_log(
                "surfacing.decide",
                {
                    "decision_id": decision_id,
                    "session_id": session_id,
                    "strategy_used": strategy_used,
                    "items_returned": len(trimmed),
                    "tokens_used": tokens_used,
                    "tokens_budget": max_tokens,
                },
            )
        except Exception:
            pass  # telemetry never blocks surfacing

        return {
            "decision_id": decision_id,
            "items": trimmed,
            "drift_warnings": drift_warnings,
            "strategy_used": strategy_used,
            "tokens_used": tokens_used,
            "tokens_budget": max_tokens,
            "deprecation": None,
        }

    # ── Drift warnings (M3+1 follow-up) ─────────────────────────────────

    def _collect_drift_warnings(
        self,
        anchor_queries: Any,
        session_id: str,
    ) -> List[Dict[str, Any]]:
        """Read persisted anchor-drift state for ``session_id``.

        Returns the ``drift_warnings`` payload matching
        ``context-api-contract.json``: a list of
        ``{anchor_id, severity, reason}`` dicts. Drift detection itself
        happens asynchronously in ``AnchorReconciliationEvolver`` — this
        method only reads the resulting ``anchor_status='needs_review'``
        flag, which keeps the surfacing hot path off LLM-ish computation.

        Severity is derived from the persisted ``drift_score`` (contract
        tiers: info < 0.5 <= significant < 0.8 <= critical). Missing or
        invalid ``drift_score`` defaults to ``critical`` — the evolver
        only flips ``needs_review`` on strong signals, so absence still
        implies critical.

        Never raises: a backend failure degrades to ``[]`` with a debug
        log. The surfacing call must not fail on account of drift read.
        """
        try:
            rows = anchor_queries.get_needs_review(session_id) or []
        except Exception as exc:
            logger.debug(
                "get_working_context: drift read failed for session=%s: %s",
                session_id,
                exc,
            )
            return []

        warnings: List[Dict[str, Any]] = []
        for row in rows:
            anchor_id = (row.get("anchor_id") or "") if isinstance(row, dict) else ""
            if not anchor_id:
                continue
            raw_score = row.get("drift_score") if isinstance(row, dict) else None
            try:
                score = float(raw_score) if raw_score is not None else None
            except (TypeError, ValueError):
                score = None
            if score is None:
                severity = "critical"
                reason = "anchor flagged for review"
            else:
                if score < 0.5:
                    severity = "info"
                elif score < 0.8:
                    severity = "significant"
                else:
                    severity = "critical"
                reason = f"anchor flagged for review (drift_score={score:.2f})"
            warnings.append(
                {
                    "anchor_id": anchor_id,
                    "severity": severity,
                    "reason": reason,
                }
            )
        return warnings

    # ── Session pin API (M3 Slice A.3.3) ────────────────────────────────

    def _ruler_reload_redis_client(self):
        """Dedicated Redis client for the ruler hot-reload pub/sub.

        SELF-IMPROVE-9 C4: PatternManager was constructed WITHOUT a redis
        client, so ``_subscribe_for_reload()`` never ran and the
        EntityRulerConsumer's post-persist reload reached no subscriber —
        a silent no-op. This must be a *separate* client from
        ``_session_redis_client`` because PatternManager puts its
        connection into SUBSCRIBE mode (a blocking listener); sharing the
        session-pin singleton would wedge it. Returns None on
        Redis-unreachable — PatternManager then runs without hot-reload
        (degraded, but logged at its call site).
        """
        cached = getattr(self, "_ruler_reload_redis_instance", None)
        if cached is not None:
            return cached
        try:
            import os
            import redis  # type: ignore

            client = redis.Redis(
                host=os.getenv("REDIS_HOST", "localhost"),
                port=int(os.getenv("REDIS_PORT", "9012")),
                db=int(os.getenv("ACTIVATION_REDIS_DB", "1")),
                decode_responses=True,
                socket_connect_timeout=1.0,
                socket_timeout=1.0,
            )
            client.ping()
        except Exception as exc:
            logger.debug("_ruler_reload_redis_client: Redis unavailable — %s", exc)
            self._ruler_reload_redis_instance = None
            return None
        self._ruler_reload_redis_instance = client
        return client

    def _session_redis_client(self):
        """Lazy singleton Redis client for the session-pin namespace.

        Uses the same DB as activation (DB 1, via ``ACTIVATION_REDIS_DB``
        env) since pins live alongside ``sm:activation:*`` keys. Returns
        None on Redis-unreachable — callers treat pins as empty.
        """
        cached = getattr(self, "_session_redis_instance", None)
        if cached is not None:
            return cached
        try:
            import os
            import redis  # type: ignore

            client = redis.Redis(
                host=os.getenv("REDIS_HOST", "localhost"),
                port=int(os.getenv("REDIS_PORT", "9012")),
                db=int(os.getenv("ACTIVATION_REDIS_DB", "1")),
                decode_responses=True,
                socket_connect_timeout=1.0,
                socket_timeout=1.0,
            )
            client.ping()
        except Exception as exc:
            logger.debug(
                "_session_redis_client: Redis unavailable — %s",
                exc,
            )
            self._session_redis_instance = None
            return None
        self._session_redis_instance = client
        return client

    def pin_item(
        self,
        session_id: str,
        item_id: str,
        weight: float = 1.0,
    ) -> None:
        """Pin ``item_id`` in ``session_id`` with additive weight.

        Pins force-include the item in ``get_working_context`` results and
        add ``weight × SESSION_PIN_MULTIPLIER`` to the score composite.
        First pin binds the session to the current workspace — subsequent
        pins with a different workspace raise
        :class:`SessionPinWorkspaceConflict`.
        """
        client = self._session_redis_client()
        if client is None:
            logger.warning(
                "pin_item: Redis unavailable; pin dropped for session=%s item=%s",
                session_id,
                item_id,
            )
            return
        workspace_id = getattr(
            getattr(self, "_scope_provider", None) or getattr(self, "scope_provider", None),
            "workspace_id",
            None,
        )
        if not workspace_id:
            raise ValueError(
                "pin_item requires a workspace-scoped SmartMemory — the current scope_provider has no workspace_id",
            )
        from smartmemory.session.pins import SessionPinStore

        SessionPinStore(client).pin(session_id, item_id, weight, workspace_id)

    def unpin_item(self, session_id: str, item_id: str) -> None:
        """Remove a pin. No-op if the pin doesn't exist."""
        client = self._session_redis_client()
        if client is None:
            return
        from smartmemory.session.pins import SessionPinStore

        SessionPinStore(client).unpin(session_id, item_id)

    # ── PPR cache helpers (M3 Slice C) ──────────────────────────────────

    def _ppr_cache(self):
        """Lazy singleton PPR cache over the session-pin Redis client.

        Shares DB 1 with activation keys — the ``sm:ppr:*`` prefix is
        disjoint from ``sm:activation:*`` and ``sm:session:*`` so there's
        no namespace collision. Returns None if Redis is unreachable
        (personalized_pagerank handles None gracefully).
        """
        cached = getattr(self, "_ppr_cache_instance", None)
        if cached is not None:
            return cached
        client = self._session_redis_client()
        if client is None:
            self._ppr_cache_instance = None
            return None
        from smartmemory.search.ppr_cache import PPRCache

        self._ppr_cache_instance = PPRCache(client)
        return self._ppr_cache_instance

    def _invalidate_ppr_cache_for_workspace(self) -> None:
        """Write-through invalidation hook for graph mutations.

        Called from add/ingest/update/delete paths whenever content
        that could change the PPR-relevant subgraph is modified. Safe
        to call unconditionally — the cache wrapper debounces bursts.
        NOT gated on surfacing_mode (Codex Slice C plan-r1 finding):
        a legacy-mode writer in workspace W still needs to invalidate
        W's cache, otherwise a concurrent router-mode reader serves
        stale data.
        """
        try:
            cache = self._ppr_cache()
            if cache is None:
                return
            ws_id = getattr(
                getattr(self, "_scope_provider", None) or getattr(self, "scope_provider", None),
                "workspace_id",
                None,
            )
            if ws_id:
                cache.invalidate_workspace(ws_id)
        except Exception as exc:
            logger.debug(
                "_invalidate_ppr_cache_for_workspace: failed silently: %s",
                exc,
            )

    def get_pins(self, session_id: str) -> Dict[str, float]:
        """Return the current pin set for ``session_id``.

        Applies the same cross-workspace guard as the read path in
        ``get_working_context`` — if the session is bound to a workspace
        other than the current memory's scope, returns ``{}`` and logs a
        WARNING. Callers that need the raw cross-workspace view must
        construct a ``SessionPinStore`` directly (there's no supported
        user-facing path for that).
        """
        client = self._session_redis_client()
        if client is None:
            return {}
        from smartmemory.session.pins import SessionPinStore

        store = SessionPinStore(client)
        current_ws = getattr(
            getattr(self, "_scope_provider", None) or getattr(self, "scope_provider", None),
            "workspace_id",
            None,
        )
        bound_ws = store.get_workspace(session_id)
        # Symmetric semantics with get_working_context's internal guard:
        # allow the read only when the session is either unbound or bound
        # to the current workspace. An unscoped memory (current_ws=None)
        # cannot safely see pins from any bound session — that would leak
        # on the same-session_id reuse path that the guard is here to
        # prevent.
        if not (bound_ws is None or bound_ws == current_ws):
            logger.warning(
                "get_pins: session %s is pinned to workspace %s; current "
                "memory scope is %s — returning empty set (cross-workspace "
                "leak guard)",
                session_id,
                bound_ws,
                current_ws,
            )
            return {}
        return store.get_pins(session_id)

    def _decomposed_search(self, query: str, top_k: int, memory_type: str = None, **kwargs) -> list:
        """Run decomposed search: split query into sub-queries, fan-out, RRF merge."""
        from smartmemory.search.query_decomposer import decompose
        from smartmemory.search.rrf_merge import rrf_merge

        sub_queries = decompose(query)

        if len(sub_queries) <= 1:
            return self._search.search(query, top_k=top_k, memory_type=memory_type, **kwargs)

        # Fan-out: pass top_k directly — no additional over-fetch here because
        # the downstream stack (Search → SmartGraphSearch → VectorStore) already
        # applies its own 2x multipliers at each level.
        result_lists = []
        for sq in sub_queries:
            results = self._search.search(sq, top_k=top_k, memory_type=memory_type, **kwargs)
            result_lists.append(results or [])

        return rrf_merge(result_lists, top_k=top_k)

    def _multi_hop_search(
        self,
        query: str,
        top_k: int,
        max_hops: int,
        budget_ms: int,
        memory_type: str = None,
        semantic_hops: bool = False,
        fusion_config=None,
        cleanup: bool = False,
        **kwargs,
    ) -> list:
        """Run multi-hop recursive retrieval (RLM-1c, CORE-MULTIHOP-2).

        CORE-ATTENTION-FUSION-1: ``fusion_config`` is forwarded into
        ``MultiHopSearch.execute`` to override fixed hop-decay weights.
        SEARCH-MULTIHOP-CLEANUP-1: ``cleanup`` enables per-hop entity cleanup.
        """
        from smartmemory.search.multi_hop import MultiHopSearch, SemanticHopPlanner

        def search_fn(q, top_k, **kw):
            return self._search.search(q, top_k=top_k, memory_type=memory_type, **kw)

        planner = None
        if semantic_hops or (self._semantic_hop_config and self._semantic_hop_config.enabled):
            planner = SemanticHopPlanner(config=self._semantic_hop_config)

        searcher = MultiHopSearch(search_fn=search_fn, planner=planner, graph=self._graph, memory=self)
        return searcher.execute(
            query,
            top_k=top_k,
            max_hops=max_hops,
            budget_ms=budget_ms,
            cleanup=cleanup,
            fusion_config=fusion_config,
            **kwargs,
        )

    def _decomposed_multi_hop_search(
        self,
        query: str,
        top_k: int,
        max_hops: int,
        budget_ms: int,
        memory_type: str = None,
        semantic_hops: bool = False,
        fusion_config=None,
        cleanup: bool = False,
        **kwargs,
    ) -> list:
        """CORE-MULTIHOP-2: decompose query into sub-queries, multi-hop each, RRF merge.

        CORE-ATTENTION-FUSION-1: ``fusion_config`` is forwarded to each
        sub-query's ``MultiHopSearch.execute`` call.
        """
        from smartmemory.search.multi_hop import MIN_HOP_BUDGET_MS, MultiHopSearch, SemanticHopPlanner
        from smartmemory.search.query_decomposer import decompose
        from smartmemory.search.rrf_merge import rrf_merge

        sub_queries = decompose(query)

        if len(sub_queries) <= 1:
            return self._multi_hop_search(
                query,
                top_k,
                max_hops,
                budget_ms,
                memory_type=memory_type,
                semantic_hops=semantic_hops,
                fusion_config=fusion_config,
                cleanup=cleanup,
                **kwargs,
            )

        def search_fn(q, top_k, **kw):
            return self._search.search(q, top_k=top_k, memory_type=memory_type, **kw)

        # CORE-MULTIHOP-2 Phase 2: planner selection
        planner = None
        if semantic_hops or (self._semantic_hop_config and self._semantic_hop_config.enabled):
            planner = SemanticHopPlanner(config=self._semantic_hop_config)

        # Split budget across sub-queries, capping total to caller's budget
        per_query_budget = max(budget_ms // len(sub_queries), MIN_HOP_BUDGET_MS)
        total_spent = 0.0

        result_lists = []
        for sq in sub_queries:
            remaining = budget_ms - total_spent
            if remaining < MIN_HOP_BUDGET_MS:
                break  # Budget exhausted — skip remaining sub-queries
            t0 = time.perf_counter()
            searcher = MultiHopSearch(search_fn=search_fn, planner=planner, graph=self._graph, memory=self)
            results = searcher.execute(
                sq,
                top_k=top_k,
                max_hops=max_hops,
                budget_ms=min(per_query_budget, remaining),
                cleanup=cleanup,
                fusion_config=fusion_config,
                **kwargs,
            )
            total_spent += (time.perf_counter() - t0) * 1000
            result_lists.append(results or [])

        return rrf_merge(result_lists, top_k=top_k)

    # Linking
    def link(self, source_id: str, target_id: str, link_type: Union[str, "LinkType"] = "RELATED") -> str:
        """Link two memory items."""
        if hasattr(link_type, "value"):
            link_type = link_type.value
        return self._linking.link(source_id, target_id, link_type)

    def get_links(self, item_id: str, memory_type: str = "semantic") -> List[str]:
        """Get all links (triples) for a memory item."""
        return self._linking.get_links(item_id, memory_type)

    def get_neighbors(self, item_id: str, direction: str = "both"):
        """Return neighboring MemoryItems for a node with link types.

        Args:
            item_id: Source node id.
            direction: "outgoing", "incoming", or "both" (default). Asymmetric
                edges like SUPERSEDES are written one-way; callers that need
                to know which side they are on should request a single
                direction at a time.
        """
        return self._graph_ops.get_neighbors(item_id, direction=direction)

    # Personalization & Feedback
    def personalize(self, traits: dict = None, preferences: dict = None) -> None:
        """Personalize the memory system for the current user."""
        return self._personalization.personalize(traits, preferences)

    def update_from_feedback(self, feedback: dict, memory_type: str = "semantic") -> None:
        return self._personalization.update_from_feedback(feedback, memory_type)

    def embeddings_search(self, embedding, top_k=5):
        """Search for memory items most similar to the given embedding."""
        with self._di_context():
            return self._search.embeddings_search(embedding, top_k=top_k)

    def add_tags(self, item_id: str, tags: list) -> bool:
        """Delegate add_tags to CRUD submodule."""
        return self._crud.add_tags(item_id, tags)

    def challenge(self, assertion: str, memory_type: str = "semantic", use_llm: bool = True):
        """Challenge an assertion against existing knowledge to detect contradictions."""
        from smartmemory.reasoning.challenger import AssertionChallenger

        challenger = AssertionChallenger(self, use_llm=use_llm)
        return challenger.challenge(assertion, memory_type=memory_type)

    # =========================================================================
    # Delegated to MonitoringManager
    # =========================================================================

    def summary(self) -> dict:
        return self._monitoring_mgr.summary()

    def orphaned_notes(self) -> list:
        return self._monitoring_mgr.orphaned_notes()

    def prune(self, strategy="old", days=365, **kwargs):
        return self._monitoring_mgr.prune(strategy, days, **kwargs)

    def find_old_notes(self, days: int = 365) -> list:
        return self._monitoring_mgr.find_old_notes(days)

    def self_monitor(self) -> dict:
        return self._monitoring_mgr.self_monitor()

    def reflect(self, top_k: int = 5) -> dict:
        return self._monitoring_mgr.reflect(top_k)

    def summarize(self, max_items: int = 10) -> dict:
        return self._monitoring_mgr.summarize(max_items)

    # =========================================================================
    # Delegated to EvolutionManager
    # =========================================================================

    def run_evolution_cycle(self):
        return self._evolution_mgr.run_evolution_cycle()

    # CORE-MEMORY-DYNAMICS-1 M1b: commit_working_to_episodic / commit_working_to_procedural
    # were removed — the ConsolidationRouter now routes at ingest.

    def run_clustering(self) -> dict:
        return self._evolution_mgr.run_clustering()

    # =========================================================================
    # Delegated to EnrichmentManager
    # =========================================================================

    def enrich(self, item_id: str, routines: Optional[List[str]] = None) -> None:
        return self._enrichment_mgr.enrich(item_id, routines)

    def ground(self, item_id: str, source_url: str, validation: Optional[dict] = None) -> None:
        return self._enrichment_mgr.ground(item_id, source_url, validation)

    def ground_context(self, context: dict):
        return self._enrichment_mgr.ground_context(context)

    def resolve_external(self, node: MemoryItem) -> Optional[list]:
        return self._enrichment_mgr.resolve_external(node)

    # =========================================================================
    # Delegated to DebugManager
    # =========================================================================

    def debug_search(self, query: str, top_k: int = 5) -> dict:
        return self._debug_mgr.debug_search(query, top_k)

    def get_all_items_debug(self) -> Dict[str, Any]:
        return self._debug_mgr.get_all_items_debug()

    def fix_search_if_broken(self) -> dict:
        fix_info, new_search = self._debug_mgr.fix_search_if_broken()
        self._search = new_search
        return fix_info

    def clear(self):
        """Clear all memory from ALL storage backends comprehensively."""
        with self._di_context():
            result = self._debug_mgr.clear()

        # Clear canonical memory store
        if getattr(self, "_canonical_store", None) is not None:
            self._canonical_store.clear()

        # Clear in-memory caches and mixins
        if getattr(self, "_cache", None) is not None:
            self._cache.clear()

        if hasattr(self, "_operation_stats"):
            for key in self._operation_stats:
                self._operation_stats[key] = 0

        # Clear any remaining memory type stores
        memory_types = ["semantic", "episodic", "procedural", "zettelkasten"]
        for memory_type in memory_types:
            if hasattr(self, f"_{memory_type}_store"):
                store = getattr(self, f"_{memory_type}_store")
                if hasattr(store, "clear"):
                    store.clear()

        return result

    # =========================================================================
    # Temporal query methods
    # =========================================================================

    def time_travel(self, to: str):
        """
        Time travel context manager.

        All queries executed within this context will use the specified
        time point as their reference.

        Args:
            to: Time point to travel to (ISO format: "2024-09-01" or "2024-09-01T00:00:00")

        Returns:
            Context manager

        Example:
            with memory.time_travel("2024-09-01"):
                # All queries in this block use Sept 1st as reference
                results = memory.search("Python")
                user = memory.get("user123")
        """
        from smartmemory.temporal.context import time_travel

        return time_travel(self, to)

    # =========================================================================
    # Graph Integrity Operations
    # =========================================================================

    def delete_run(self, run_id: str) -> int:
        """Delete all entities created by a specific pipeline run.

        Use this to clean up entities from a failed or re-run pipeline execution.
        All nodes with the matching run_id in their metadata will be deleted.

        Args:
            run_id: The pipeline run identifier (UUID string)

        Returns:
            Number of entities deleted
        """
        return self._graph.delete_by_run_id(run_id)

    def rename_entity_type(self, old_type: str, new_type: str) -> int:
        """Rename an entity type across all matching entities.

        Use this when the ontology evolves and entity types need to be renamed.
        All entities with entity_type=old_type will be updated to new_type.

        Args:
            old_type: Current entity type name
            new_type: New entity type name

        Returns:
            Number of entities updated
        """
        return self._graph.rename_entity_type(old_type, new_type)

    def merge_entity_types(self, source_types: List[str], target_type: str) -> int:
        """Merge multiple entity types into a single target type.

        Use this to consolidate fragmented or similar entity types.

        Args:
            source_types: List of entity types to merge
            target_type: The target entity type name

        Returns:
            Total number of entities updated
        """
        return self._graph.merge_entity_types(source_types, target_type)

    # ------------------------------------------------------------------
    # Code indexing — CODE-DEV-2/C
    # ------------------------------------------------------------------

    def ingest_code(
        self,
        directory: str,
        repo: str,
        commit_hash: Optional[str] = None,
        exclude_dirs: Optional[List[str]] = None,
        languages: Optional[List[str]] = None,
    ) -> "IndexResult":
        """Index a code repository into the SmartMemory knowledge graph.

        Parses Python (and optionally TypeScript/JavaScript) files, writes code
        entities and relationships as graph nodes/edges, and generates vector
        embeddings so code symbols appear in ``search()`` results.

        After indexing, ``seed_patterns_from_code()`` is called automatically to
        promote class/function names into the EntityRuler pattern set, improving
        future extraction over text that references this codebase.

        Args:
            directory: Absolute path to the repository root to index.
            repo: Short repository identifier (e.g. ``"smart-memory-service"``).
                Used as the namespace prefix on all generated node IDs.
            commit_hash: Optional git commit SHA to attach to the result.
                When ``None``, auto-detected via ``git rev-parse HEAD``.
                Pass ``""`` to suppress auto-detection and leave the field unset.
            exclude_dirs: Directory names to skip during file collection
                (e.g. ``["node_modules", ".venv"]``).
            languages: Languages to index. Defaults to ``["python"]``. Pass
                ``["python", "typescript"]`` to also index ``.ts``/``.tsx``/
                ``.js``/``.jsx`` files.

        Returns:
            ``IndexResult`` with counts of files parsed, entities created, edges
            created, and embeddings generated.
        """
        from smartmemory.code.indexer import CodeIndexer  # local to avoid circular import

        if commit_hash is None:
            try:
                git_result = subprocess.run(
                    ["git", "-C", directory, "rev-parse", "HEAD"],
                    capture_output=True,
                    text=True,
                )
                if git_result.returncode == 0:
                    commit_hash = git_result.stdout.strip()
            except (FileNotFoundError, OSError):
                pass  # git not on PATH — leave commit_hash as None

        exclude_set: Optional[set] = set(exclude_dirs) if exclude_dirs else None
        indexer = CodeIndexer(
            graph=self._graph,
            repo=repo,
            repo_root=directory,
            exclude_dirs=exclude_set,
            commit_hash=commit_hash or "",
        )
        with self._di_context():
            index_result = indexer.index(languages=languages)

        if index_result.entities:
            self.seed_patterns_from_code(index_result.entities)

        return index_result

    def seed_patterns_from_code(self, entities: list) -> None:
        """Seed EntityRuler patterns from indexed code entities.

        Extracts ``{name: entity_type}`` pairs from the entity list and merges
        them into the workspace's PatternManager so that future ``ingest()``
        calls recognise code symbols as named entities.

        Three paths:
        - **Lite mode** (``entity_ruler_patterns`` injected): calls ``add_patterns()``
          with ``initial_count=2`` to bypass the frequency threshold.
        - **Path A** (pipeline already initialised): adds patterns to the pipeline's
          PatternManager and reloads — patterns available immediately.
        - **Path B** (pipeline not yet initialised): persists to FalkorDB via a
          throwaway PatternManager — patterns load on next ``_create_pipeline_runner()``.

        Args:
            entities: List of ``CodeEntity`` objects (as returned in
                ``IndexResult.entities``).
        """
        # NOTE: _enable_ontology guard moved to early-return position. Prior behavior:
        # when enable_ontology=False and no entity_ruler_patterns injected,
        # this was a no-op buried inside the PatternManager lazy-init block.
        if not self._enable_ontology and self._entity_ruler_patterns is None:
            return

        patterns = {e.name: e.entity_type for e in entities if getattr(e, "name", None)}
        if not patterns:
            return

        # Path 1: injected manager supports add_patterns() — unified PatternManager (Lite mode).
        # If the injected manager only implements get_patterns() (read-only custom injector),
        # skip the early return so Path A/B can seed through _pipeline_pattern_manager.
        if self._entity_ruler_patterns is not None and hasattr(self._entity_ruler_patterns, "add_patterns"):
            self._entity_ruler_patterns.add_patterns(patterns, source="code_index", initial_count=2)
            logger.debug("seed_patterns_from_code: seeded %d patterns via injected manager", len(patterns))
            return

        # Paths A and B require ontology support (FalkorDB-backed PatternManager).
        # If ontology is disabled and the Lite path didn't fire, seeding is a no-op.
        if not self._enable_ontology:
            return

        # Path A: Pipeline already initialised — use its PatternManager directly
        if self._pipeline_pattern_manager is not None:
            accepted = self._pipeline_pattern_manager.add_patterns(patterns, source="code_index", initial_count=2)
            self._pipeline_pattern_manager.reload()
            logger.debug("seed_patterns_from_code: seeded %d (Path A — immediate reload)", accepted)
            return

        # Path B: Pipeline not yet initialised — persist to FalkorDB
        # Next _create_pipeline_runner() will pick them up via get_entity_patterns()
        try:
            from smartmemory.graph.ontology_graph import OntologyGraph
            from smartmemory.ontology.falkordb_pattern_store import FalkorDBPatternStore
            from smartmemory.ontology.pattern_manager import PatternManager

            # SEC-TENANT-QUERIES-1 Phase 1 fix: same phantom-get_scope() bug.
            # Path B (pipeline not yet initialised) was persisting learned
            # patterns to ``ws_default_ontology`` regardless of tenant.
            workspace_id = self._resolve_scope_workspace_id() or "default"

            ontology_graph = OntologyGraph(workspace_id=workspace_id)
            pm = PatternManager(
                FalkorDBPatternStore(ontology_graph),
                workspace_id=workspace_id,
                redis_client=self._ruler_reload_redis_client(),  # C4: enable hot-reload
            )
            accepted = pm.add_patterns(patterns, source="code_index", initial_count=2)
            logger.debug("seed_patterns_from_code: seeded %d (Path B — FalkorDB persist)", accepted)
        except Exception as exc:
            logger.debug("seed_patterns_from_code Path B failed: %s", exc)
