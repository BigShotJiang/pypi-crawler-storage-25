"""Agent helpers for CORE-AGENT-2.

Shared utilities for agent node identification and evaluation queries.
"""
