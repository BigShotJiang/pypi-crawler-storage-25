"""Public evaluation read API — CORE-AGENT-2 S03-T2.

Module-level functions that wrap ``EvaluationQueriesExt`` and return plain
``dict`` values (not ``Evaluation`` objects) for cross-repo compatibility.

Surface:
  get_evaluation(memory, agent_id, dimension, domain) → dict | None
  list_evaluation_history(memory, agent_id, dimension, domain, *, limit=20) → list[dict]
  list_evaluations(memory, agent_id, *, dimension=None, domain=None) → list[dict]

Design notes:
- Returns dicts, not dataclass instances — REST layer needs serialisable values.
- No ``include_history`` parameter anywhere (Codex Round-3 F3).
- All three functions are the delegation layer between SmartMemory / SecureSmartMemory
  and EvaluationQueriesExt.  Security scoping happens in SecureSmartMemory wrappers —
  these functions are scope-agnostic.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def _to_dict(ev: Any) -> dict | None:
    """Convert an Evaluation (or dict) to a plain dict, or return None."""
    if ev is None:
        return None
    if isinstance(ev, dict):
        return ev
    if hasattr(ev, "to_dict"):
        return ev.to_dict()
    # Fallback: try __dict__
    try:
        return vars(ev)
    except TypeError:
        logger.warning("evaluation._to_dict: cannot convert %r to dict", type(ev))
        return None


def get_evaluation(
    smart_memory: Any,
    agent_id: str,
    dimension: str,
    domain: str,
) -> dict | None:
    """Return the current evaluation for ``(agent_id, dimension, domain)`` as a dict.

    Returns ``None`` when no current (non-superseded, non-stale) evaluation exists
    for this slot.  This is the cold-start / unseen-tuple case — callers MUST NOT
    treat None as an error (REST surface returns ``200 {evaluation: null}``).

    Args:
        smart_memory: A ``SmartMemory`` or ``SecureSmartMemory`` instance.
        agent_id: Agent whose evaluation to retrieve.
        dimension: Performance dimension (e.g. ``"decision_volume"``).
        domain: Domain string (e.g. ``"python"``).

    Returns:
        Current evaluation as a dict, or ``None``.
    """
    from smartmemory.evaluations.queries import EvaluationQueriesExt

    queries = EvaluationQueriesExt(smart_memory)
    ev = queries.current(agent_id, dimension, domain)
    return _to_dict(ev)


def list_evaluation_history(
    smart_memory: Any,
    agent_id: str,
    dimension: str,
    domain: str,
    *,
    limit: int = 20,
) -> list[dict]:
    """Return the full supersession history for ``(agent_id, dimension, domain)``.

    Returns records sorted most-recent-first (newest ``recorded_at`` first).
    No freshness filter — history always surfaces all versions including stale ones.

    Args:
        smart_memory: A ``SmartMemory`` or ``SecureSmartMemory`` instance.
        agent_id: Agent identifier.
        dimension: Performance dimension.
        domain: Domain string.
        limit: Maximum records to return (default 20).

    Returns:
        List of evaluation dicts, newest first.
    """
    from smartmemory.evaluations.queries import EvaluationQueriesExt

    queries = EvaluationQueriesExt(smart_memory)
    items = queries.history(agent_id, dimension, domain, limit=limit)
    result = []
    for ev in items:
        d = _to_dict(ev)
        if d is not None:
            result.append(d)
    return result


def list_evaluations(
    smart_memory: Any,
    agent_id: str,
    *,
    dimension: str | None = None,
    domain: str | None = None,
) -> list[dict]:
    """Return current evaluations for an agent, optionally filtered by dimension/domain.

    Only returns the *current* (non-superseded, non-stale) version for each
    ``(dimension, domain)`` slot.  No history, no ``include_history`` flag.

    Args:
        smart_memory: A ``SmartMemory`` or ``SecureSmartMemory`` instance.
        agent_id: Agent identifier.
        dimension: If provided, filter to this dimension only.
        domain: If provided, filter to this domain only.

    Returns:
        List of current evaluation dicts (one per slot).
    """
    from smartmemory.evaluations.queries import EvaluationQueriesExt

    queries = EvaluationQueriesExt(smart_memory)
    # Fetch a broad set of evaluations and filter client-side
    candidates = queries._list_evaluations_via_graph(limit=500)

    results: list[dict] = []
    seen_slots: set[tuple[str, str]] = set()

    # Sort candidates newest-first before deduplication
    from datetime import datetime, timezone

    def _recorded_at(raw: Any) -> datetime:
        if isinstance(raw, dict):
            val = raw.get("recorded_at") or raw.get("metadata", {}).get("recorded_at", "")
        else:
            val = getattr(raw, "recorded_at", "") or ""
        try:
            d = datetime.fromisoformat(str(val).replace("Z", "+00:00"))
            return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
        except Exception:
            return datetime.min.replace(tzinfo=timezone.utc)

    candidates_sorted = sorted(candidates, key=_recorded_at, reverse=True)

    for raw in candidates_sorted:
        ev = queries._hydrate(raw)
        if ev is None:
            continue
        if ev.agent_id != agent_id:
            continue
        if getattr(ev, "superseded", False):
            continue  # only current versions
        if dimension is not None and ev.dimension != dimension:
            continue
        if domain is not None and ev.domain != domain:
            continue

        slot = (ev.dimension, ev.domain)
        if slot in seen_slots:
            continue  # already have the current version for this slot
        seen_slots.add(slot)

        d = _to_dict(ev)
        if d is not None:
            results.append(d)

    return results
