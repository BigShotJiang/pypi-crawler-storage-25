"""Agent node identity helper — CORE-AGENT-2 correction C10.

The AGENT graph node's `item_id` is a deterministic hash of the agent's
user_id.  This helper centralises the computation so there is a single
canonical definition (previously inlined at two sites):

  - smart-memory-core/smartmemory/pipeline/stages/link.py (CORE-AGENT-1)
  - smart-memory-service/memory_service/api/routes/agents.py (route creation)

Both call sites are replaced with `from smartmemory.agents.node import agent_item_id_for`.
"""

from __future__ import annotations

import hashlib


def agent_item_id_for(user_id: str) -> str:
    """Return the canonical item_id for an AGENT graph node.

    Deterministic: sha256(f"agent:{user_id}").hexdigest().

    Args:
        user_id: The agent's user identifier (not a human user_id).

    Returns:
        A 64-character hex string used as the AGENT node's item_id in the graph.
    """
    return hashlib.sha256(f"agent:{user_id}".encode()).hexdigest()
