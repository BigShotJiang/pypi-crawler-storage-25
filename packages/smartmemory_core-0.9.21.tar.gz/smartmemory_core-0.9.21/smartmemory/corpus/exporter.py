"""Corpus export: dump SmartMemory contents to corpus JSONL."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from smartmemory.corpus.format import CorpusEntity, CorpusRecord, CorpusRelation
from smartmemory.corpus.writer import CorpusWriter

logger = logging.getLogger(__name__)


class CorpusExporter:
    """Exports memories from SmartMemory to corpus JSONL format.

    Iterates the graph, optionally including extracted entities/relations.
    """

    def __init__(
        self,
        smart_memory: Any,
        memory_type: str | None = None,
        include_entities: bool = False,
        limit: int = 0,
    ):
        self._sm = smart_memory
        self._memory_type = memory_type
        self._include_entities = include_entities
        self._limit = limit

    def run(
        self,
        output_path: str | Path,
        source: str = "smartmemory-export",
        domain: str = "",
        progress_callback: Any | None = None,
    ) -> int:
        """Export memories to a corpus JSONL file.

        Args:
            output_path: Where to write the .jsonl file.
            source: Source identifier for the corpus header.
            domain: Domain tag for the corpus header.
            progress_callback: Called with (count, record) after each record.

        Returns:
            Number of records written.
        """
        items = self._fetch_items()

        with CorpusWriter(output_path, source=source, domain=domain) as writer:
            for item in items:
                record = self._item_to_record(item)
                if record:
                    writer.write_record(record)
                    if progress_callback:
                        progress_callback(writer.count, record)

        logger.info("Exported %d records to %s", writer.count, output_path)
        return writer.count

    def _fetch_items(self) -> list[dict[str, Any]]:
        """Fetch memory items from SmartMemory.

        Supports both FalkorDB (Cypher query) and SQLite (backend.get_all_nodes).
        """
        if not hasattr(self._sm, "graph"):
            return []
        graph = self._sm.graph
        backend = getattr(graph, "backend", None)
        # SQLite/lite backends don't have .query() — use get_all_nodes
        if backend is not None and not callable(getattr(graph, "query", None)):
            return self._fetch_from_backend(backend)
        return self._fetch_from_graph()

    def _fetch_from_backend(self, backend) -> list[dict[str, Any]]:
        """Fetch items from SQLite backend via get_all_nodes()."""
        try:
            nodes = backend.get_all_nodes()
            items = []
            for node in nodes:
                mt = node.get("memory_type", "")
                if mt in ("Version",):
                    continue
                if self._memory_type and mt != self._memory_type:
                    continue
                content = node.get("content", node.get("properties", {}).get("content", ""))
                if not content:
                    continue
                items.append({
                    "item_id": node.get("item_id", ""),
                    "content": content,
                    "memory_type": mt or "semantic",
                    "metadata": {},
                })
            if self._limit:
                items = items[:self._limit]
            return items
        except Exception as e:
            logger.error("Failed to fetch items from backend: %s", e)
            return []

    def _fetch_from_graph(self) -> list[dict[str, Any]]:
        """Fetch items via SmartGraph Cypher query (FalkorDB only).

        SEC-TENANT-QUERIES-1 Phase 8 (Codex r1): scopes on workspace_id when
        the underlying SmartMemory carries a scope_provider with workspace_id.
        Without scoping, this export would emit every tenant's data — a
        cross-tenant blast on what is typically an admin / debug export.
        """
        graph = self._sm.graph
        type_filter = ""
        params: dict[str, Any] = {}
        if self._memory_type:
            type_filter = f" AND n.memory_type = '{self._memory_type}'"
        limit_clause = f" LIMIT {self._limit}" if self._limit else ""

        ws_id = None
        scope = getattr(self._sm, "scope_provider", None) or getattr(
            self._sm, "_scope_provider", None
        )
        if scope is not None:
            ws_id = getattr(scope, "workspace_id", None)

        if ws_id:
            ws_filter = " AND n.workspace_id = $ws"
            params["ws"] = ws_id
        else:
            # OSS-mode bare ``SmartMemory()`` — no tenant boundary; export
            # is single-tenant by construction. Emit marker WARNING so
            # no-silent-degradation asserters can pin the case.
            logger.warning(
                "tenant_isolation.scope_missing.corpus_export: "
                "no resolvable workspace_id; exporting unscoped (OSS-mode)."
            )
            ws_filter = ""

        query = (
            f"MATCH (n:Memory) WHERE n.content IS NOT NULL"
            f"{type_filter}{ws_filter} RETURN n{limit_clause}"
        )
        try:
            result = graph.query(query, params) if params else graph.query(query)
            items = []
            for row in result.result_set:
                node = row[0]
                items.append(
                    {
                        "item_id": node.properties.get("item_id", ""),
                        "content": node.properties.get("content", ""),
                        "memory_type": node.properties.get("memory_type", "semantic"),
                        "metadata": {},
                    }
                )
            return items
        except Exception as e:
            logger.error("Failed to fetch items from graph: %s", e)
            return []

    def _item_to_record(self, item: dict[str, Any]) -> CorpusRecord | None:
        """Convert a memory item dict to a CorpusRecord."""
        content = item.get("content", "")
        if not content or not content.strip():
            return None

        entities: list[CorpusEntity] = []
        relations: list[CorpusRelation] = []

        if self._include_entities and hasattr(self._sm, "graph"):
            entities, relations = self._fetch_extractions(item.get("item_id", ""))

        return CorpusRecord(
            content=content,
            memory_type=item.get("memory_type", "semantic"),
            entities=entities,
            relations=relations,
            metadata=item.get("metadata", {}),
        )

    def _fetch_extractions(self, item_id: str) -> tuple[list[CorpusEntity], list[CorpusRelation]]:
        """Fetch entities and relations linked to a memory item."""
        if not item_id:
            return [], []

        entities: list[CorpusEntity] = []
        relations: list[CorpusRelation] = []
        graph = self._sm.graph

        try:
            # Fetch entities
            eq = (
                f"MATCH (m:Memory {{item_id: '{item_id}'}})-[:HAS_ENTITY]->(e:Entity) "
                f"RETURN e.name, e.entity_type, e.qid"
            )
            result = graph.query(eq)
            for row in result.result_set:
                entities.append(
                    CorpusEntity(
                        name=row[0] or "",
                        type=row[1] or "",
                        qid=row[2] or "",
                    )
                )

            # Fetch relations
            rq = (
                f"MATCH (m:Memory {{item_id: '{item_id}'}})-[:HAS_ENTITY]->(s:Entity)"
                f"-[r]->(t:Entity) "
                f"WHERE type(r) <> 'HAS_ENTITY' "
                f"RETURN s.name, type(r), t.name"
            )
            result = graph.query(rq)
            for row in result.result_set:
                relations.append(
                    CorpusRelation(
                        source=row[0] or "",
                        relation=row[1] or "",
                        target=row[2] or "",
                    )
                )
        except Exception as e:
            logger.warning("Failed to fetch extractions for %s: %s", item_id, e)

        return entities, relations
