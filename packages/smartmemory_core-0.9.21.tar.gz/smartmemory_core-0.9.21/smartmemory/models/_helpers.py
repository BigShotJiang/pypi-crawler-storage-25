"""Shared model helpers — defensive coercion utilities used by multiple dataclasses.

Lives separately from any concrete model to avoid the circular-import dance
between `decision.py`, `memory_item.py`, and the declaration modules.

Lifted from `models/decision.py:37-51` as part of CORE-DECISION-OUTCOME-1
Slice 1 (Foundation), so both Decision and MemoryItem can share the same
list-coercion behaviour against the known FalkorDB list-prop read-deserialize
gap (see project memory: `project_list_prop_read_deserialize_gap`).
"""

import json
from typing import Any


def _ensure_list(val: Any, default: list | None = None) -> list:
    """Coerce a value to a list, tolerating FalkorDB JSON-string serialization.

    FalkorDB serializes list-typed node properties as JSON strings on read.
    This helper decodes them back to a Python list. Falls back to ``default``
    (or ``[]``) on any non-list / parse failure. Never returns ``None``.
    """
    if default is None:
        default = []
    if isinstance(val, str):
        try:
            val = json.loads(val)
        except (json.JSONDecodeError, TypeError):
            return default
    return val if isinstance(val, list) else default
