"""Evaluation dataclass — CORE-AGENT-2 S01.

Extends the framework-generated ``_EvaluationBase`` with:
- FalkorDB JSON-string tolerance for ``basis`` (list-prop deserialize gap).
- ``to_dict()`` / ``from_dict()`` for the service/SDK layer.
- ``is_current`` property: ``superseded == False`` (NOT ``valid_to is None``).
"""

from __future__ import annotations

import json
from typing import Any

from smartmemory.evaluations.declaration import _EvaluationBase
from smartmemory.models.base import MemoryBaseModel


def _ensure_list_str(val: Any) -> list[str]:
    """Coerce to list[str], tolerating FalkorDB JSON-string serialization."""
    if val is None:
        return []
    if isinstance(val, list):
        return [str(x) for x in val]
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            if isinstance(parsed, list):
                return [str(x) for x in parsed]
        except (json.JSONDecodeError, TypeError):
            pass
    return []


class Evaluation(_EvaluationBase, MemoryBaseModel):
    """Per-(agent, dimension, domain) performance score record.

    INDEXED type — no embeddings.  Bi-temporal: each supersession mints a new
    Evaluation with ``superseded=False`` and flips the old one to
    ``superseded=True`` via ``ingest_superseding()``.
    """

    @property
    def is_current(self) -> bool:
        """True when this record is the live (non-superseded) belief.

        Currency predicate MUST be ``superseded == False``, NOT ``valid_to is
        None`` — ``ingest_superseding()`` writes the superseded flag, not
        valid_to.  See blueprint correction C1.
        """
        return not getattr(self, "superseded", False)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a flat dict suitable for API responses and storage."""
        return {
            "evaluation_id": self.evaluation_id,
            "content": self.content,
            "agent_id": self.agent_id,
            "dimension": self.dimension,
            "domain": self.domain,
            "score": self.score,
            "score_delta": self.score_delta,
            "trend": self.trend,
            # Stored as JSON string in FalkorDB; serialize list for the wire too
            "basis": (
                json.dumps(self.basis)
                if isinstance(self.basis, list)
                else (self.basis or "[]")
            ),
            "sample_size": self.sample_size,
            "valid_from": self.valid_from,
            "valid_to": self.valid_to,
            "recorded_at": self.recorded_at,
            "evaluator": self.evaluator,
            "superseded": getattr(self, "superseded", False),
            "superseded_by": getattr(self, "superseded_by", None),
            "superseded_at": getattr(self, "superseded_at", None),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Evaluation":
        """Deserialize from a flat dict (graph node properties, API payload, etc.)."""
        return cls(
            evaluation_id=d.get("evaluation_id", ""),
            content=d.get("content", ""),
            agent_id=d.get("agent_id", ""),
            dimension=d.get("dimension", ""),
            domain=d.get("domain", ""),
            score=float(d.get("score", 0.0)),
            score_delta=float(d.get("score_delta", 0.0)),
            trend=d.get("trend", "stable"),
            basis=_ensure_list_str(d.get("basis", [])),
            sample_size=int(d.get("sample_size", 0)),
            valid_from=d.get("valid_from", ""),
            valid_to=d.get("valid_to"),
            recorded_at=d.get("recorded_at", ""),
            evaluator=d.get("evaluator", "EvaluationEvolver/v1"),
            superseded=d.get("superseded", False),
            superseded_by=d.get("superseded_by"),
            superseded_at=d.get("superseded_at"),
        )
