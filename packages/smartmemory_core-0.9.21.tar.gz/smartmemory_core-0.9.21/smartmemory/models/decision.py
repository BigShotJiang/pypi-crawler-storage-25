"""
Decision Model for Decision Memory

Decisions are discrete conclusions, inferences, and choices with full provenance.
They capture what the system believes, with confidence tracking and lifecycle management.

Decisions can be produced by ReasoningTraces or created directly from explicit user
statements. Confidence follows the same reinforce/contradict pattern as OpinionMetadata.

Path C migration (CORE-MANAGED-TYPE-FRAMEWORK-1 Phase 2): the Decision dataclass is
now derived from `ManagedType` and lightly subclassed here for Decision-specific
behavior (computed properties, legacy `to_dict` field order, default-substituting
`from_dict`, model-level `reinforce`/`contradict` that touch evidence_ids + updated_at).
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Literal

from smartmemory.models._helpers import _ensure_list  # CORE-DECISION-OUTCOME-1 S1: shared helper
from smartmemory.models.base import MemoryBaseModel
from smartmemory.models.pending_requirement import PendingRequirement  # re-exported for back-compat

DecisionType = Literal[
    "inference",       # Concluded from evidence (e.g., "User prefers TypeScript")
    "preference",      # User preference detected
    "classification",  # Categorization decision
    "choice",          # Selection between options
    "belief",          # Adopted belief/opinion
    "policy",          # Rule to follow going forward
]

# CORE-DECISION-OUTCOME-1 D1: result-of-the-decision (orthogonal to lifecycle `status` below).
OutcomeStatus = Literal["success", "failure", "partial", "abandoned"]

DecisionSource = Literal["reasoning", "explicit", "imported", "inferred"]
# CORE-DECISION-OUTCOME-1 D2: extend lifecycle states with terminal `completed`/`failed`/`abandoned`.
# Must stay mirrored with `_ALLOWED_STATUSES` at `managed/framework.py:157`.
DecisionStatus = Literal[
    "active", "superseded", "retracted", "pending",
    "completed", "failed", "abandoned",
]


# PendingRequirement is now defined in smartmemory/models/pending_requirement.py
# and re-exported above. This breaks the circular import between models/decision
# and decisions/declaration.

from smartmemory.decisions.declaration import _DecisionBase  # noqa: E402


class Decision(_DecisionBase, MemoryBaseModel):
    """A discrete conclusion, inference, or choice derived from reasoning or observation.

    Decisions are first-class memory entities that capture what the system believes,
    with full provenance tracking back to the evidence and reasoning that produced them.

    Confidence follows the same diminishing-returns pattern as OpinionMetadata:
    - reinforce(): min(1.0, confidence + (1 - confidence) * 0.1)
    - contradict(): max(0.0, confidence - confidence * 0.15)
    """

    # ---- Properties -----------------------------------------------------

    @property
    def is_active(self) -> bool:
        """Whether this decision is currently active."""
        return self.status == "active"

    @property
    def is_pending(self) -> bool:
        """Whether this decision is waiting for more data."""
        return self.status == "pending"

    @property
    def has_unresolved_requirements(self) -> bool:
        """Whether any pending requirements remain unresolved."""
        return any(not r.resolved for r in self.pending_requirements)

    @property
    def has_provenance(self) -> bool:
        """Whether this decision has traceable provenance."""
        return self.source_trace_id is not None or len(self.evidence_ids) > 0

    @property
    def net_reinforcement(self) -> int:
        """Net reinforcement score (positive = supported, negative = contradicted)."""
        return self.reinforcement_count - self.contradiction_count

    @property
    def stability(self) -> float:
        """How stable this decision is (0-1). Higher = more stable."""
        total = self.reinforcement_count + self.contradiction_count
        if total == 0:
            return 0.5
        return self.reinforcement_count / total

    # ---- Model-level reinforce / contradict -----------------------------
    # Override framework's _model_reinforce/_model_contradict (which only touch
    # count + confidence + last_*_at) to ALSO update evidence_ids list and
    # updated_at — matching the legacy Decision behavior exactly.

    def reinforce(self, evidence_id: str) -> None:
        """Record supporting evidence. Confidence increases with diminishing returns."""
        self.reinforcement_count += 1
        self.last_reinforced_at = datetime.now(timezone.utc)
        self.updated_at = datetime.now(timezone.utc)
        if evidence_id not in self.evidence_ids:
            self.evidence_ids.append(evidence_id)
        self.confidence = min(1.0, self.confidence + (1 - self.confidence) * 0.1)

    def contradict(self, evidence_id: str) -> None:
        """Record contradicting evidence. Confidence decreases proportionally."""
        self.contradiction_count += 1
        self.last_contradicted_at = datetime.now(timezone.utc)
        self.updated_at = datetime.now(timezone.utc)
        if evidence_id not in self.contradicting_ids:
            self.contradicting_ids.append(evidence_id)
        self.confidence = max(0.0, self.confidence - self.confidence * 0.15)

    # ---- Serialization --------------------------------------------------
    # Override framework's _make_to_dict (which iterates dataclass fields in
    # framework order) to build a fresh dict in LEGACY field order. The framework
    # places (id, content, confidence) first; legacy puts confidence after
    # decision_type. Some downstream consumers compare ordered representations.

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for storage in MemoryItem.metadata."""
        return {
            "decision_id": self.decision_id,
            "content": self.content,
            "decision_type": self.decision_type,
            "confidence": self.confidence,
            "evidence_ids": self.evidence_ids,
            "contradicting_ids": self.contradicting_ids,
            "reinforcement_count": self.reinforcement_count,
            "contradiction_count": self.contradiction_count,
            "source_type": self.source_type,
            "source_trace_id": self.source_trace_id,
            "source_session_id": self.source_session_id,
            "context_snapshot": self.context_snapshot,
            "status": self.status,
            "superseded_by": self.superseded_by,
            "domain": self.domain,
            "agent_id": self.agent_id,
            "tags": self.tags,
            "rejected_alternatives": self.rejected_alternatives,
            "rationale": self.rationale,
            "constraints": self.constraints,
            "pending_requirements": [r.to_dict() for r in self.pending_requirements],
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "last_reinforced_at": self.last_reinforced_at.isoformat() if self.last_reinforced_at else None,
            "last_contradicted_at": self.last_contradicted_at.isoformat() if self.last_contradicted_at else None,
            # CORE-DECISION-OUTCOME-1 D1: outcome fields appended to preserve legacy
            # field order for any downstream consumer comparing ordered representations.
            "outcome": self.outcome,
            "outcome_metric": self.outcome_metric,
            "outcome_at": self.outcome_at.isoformat() if self.outcome_at else None,
            "net_reinforcement": self.net_reinforcement,
            "stability": self.stability,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Decision":
        """Deserialize from dict (e.g., from MemoryItem.metadata).

        Verbatim port of legacy Decision.from_dict — handles `created_at: None →
        datetime.now()`, FalkorDB JSON-string list tolerance via `_ensure_list`
        on 5 list fields, and double-decode of `pending_requirements` nested
        JSON strings. Framework's generic `_make_from_dict` does not handle these
        edge cases, so override is mandatory.
        """
        data = d
        created_at = data.get("created_at")
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        elif created_at is None:
            created_at = datetime.now(timezone.utc)

        updated_at = data.get("updated_at")
        if isinstance(updated_at, str):
            updated_at = datetime.fromisoformat(updated_at)

        last_reinforced = data.get("last_reinforced_at")
        if isinstance(last_reinforced, str):
            last_reinforced = datetime.fromisoformat(last_reinforced)

        last_contradicted = data.get("last_contradicted_at")
        if isinstance(last_contradicted, str):
            last_contradicted = datetime.fromisoformat(last_contradicted)

        # CORE-DECISION-OUTCOME-1 D1: outcome_at follows the same ISO-string-or-None
        # convention as the other lifecycle timestamps. outcome_metric defends
        # against FalkorDB dict-as-JSON-string round-trips (mirrors context_snapshot
        # handling — kept as-is since dict ser/de inherits from the codec layer).
        outcome_at = data.get("outcome_at")
        if isinstance(outcome_at, str):
            outcome_at = datetime.fromisoformat(outcome_at)
        outcome_metric_raw = data.get("outcome_metric")
        if isinstance(outcome_metric_raw, str):
            try:
                outcome_metric_raw = json.loads(outcome_metric_raw)
            except (json.JSONDecodeError, TypeError):
                outcome_metric_raw = None
        outcome_metric = outcome_metric_raw if isinstance(outcome_metric_raw, dict) else None

        pending_reqs_raw = data.get("pending_requirements", [])
        if isinstance(pending_reqs_raw, str):
            try:
                pending_reqs_raw = json.loads(pending_reqs_raw)
            except (json.JSONDecodeError, TypeError):
                pending_reqs_raw = []
        pending_requirements = []
        for r in (pending_reqs_raw or []):
            if isinstance(r, str):
                try:
                    r = json.loads(r)
                except (json.JSONDecodeError, TypeError):
                    continue
            if isinstance(r, dict):
                pending_requirements.append(PendingRequirement.from_dict(r))

        return cls(
            decision_id=data.get("decision_id", ""),
            content=data.get("content", ""),
            decision_type=data.get("decision_type", "inference"),
            confidence=data.get("confidence", 0.8),
            evidence_ids=_ensure_list(data.get("evidence_ids", [])),
            contradicting_ids=_ensure_list(data.get("contradicting_ids", [])),
            reinforcement_count=data.get("reinforcement_count", 0),
            contradiction_count=data.get("contradiction_count", 0),
            source_type=data.get("source_type", "inferred"),
            source_trace_id=data.get("source_trace_id"),
            source_session_id=data.get("source_session_id"),
            context_snapshot=data.get("context_snapshot"),
            status=data.get("status", "active"),
            superseded_by=data.get("superseded_by"),
            domain=data.get("domain"),
            agent_id=data.get("agent_id"),
            tags=_ensure_list(data.get("tags", [])),
            rejected_alternatives=_ensure_list(data.get("rejected_alternatives", [])),
            rationale=data.get("rationale"),
            constraints=_ensure_list(data.get("constraints", [])),
            pending_requirements=pending_requirements,
            created_at=created_at,
            updated_at=updated_at,
            last_reinforced_at=last_reinforced,
            last_contradicted_at=last_contradicted,
            # CORE-DECISION-OUTCOME-1 D1
            outcome=data.get("outcome"),
            outcome_metric=outcome_metric,
            outcome_at=outcome_at,
        )

    @staticmethod
    def generate_id() -> str:
        """Generate a unique decision ID."""
        return f"dec_{uuid.uuid4().hex[:12]}"
