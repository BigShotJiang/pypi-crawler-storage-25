#!/usr/bin/env python3
"""Consolidate duplicate ontology rows in ws_default_ontology.

Unblocks INSIGHTS-ONTO-CUTOVER-1 cutover and ONTO-RECONCILE-1 Task 11.

Per concept (PascalCase canonical `:OntologyType tier=working` already exists):

    Canonical:           (c:OntologyType {name: 'Person', tier: 'working'})  -- keep
    Duplicates to merge:
        d1: (:EntityType {name: 'Person', status: 'provisional'})            -- 0 edges, delete
        d2: (:EntityType {name: 'person'})                                   -- rewire + delete
        d3: (:EntityType:OntologyType {name: 'person'})                      -- rewire + delete

Rewires inbound INSTANCE_OF (:Entity → type) and IS_INSTANCE_OF (:EntityPattern → type)
edges from each duplicate to the canonical, then DETACH DELETEs the duplicate.

Edge case — Language: straggler exists, no canonical, 0 inbound edges. We create the
canonical so the ontology surface is consistent post-cutover.

Idempotent: re-running after success is a no-op (no rows match the duplicate predicates).

Usage:
    python scripts/consolidate_ws_default_ontology.py --dry-run
    python scripts/consolidate_ws_default_ontology.py --execute

Runs Cypher via `docker exec smartmemory-falkordb redis-cli GRAPH.QUERY ...` so it
works without any Python FalkorDB client installed in the local env.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from typing import Iterable

GRAPH = "ws_default_ontology"
CONTAINER = "smartmemory-falkordb"

# (canonical_pascalcase, lowercase_variants_to_absorb)
# canonical_pascalcase MUST already exist as (:OntologyType {name, tier='working'|'proposed'}).
# Verified present 2026-05-24 via dump.
CONCEPTS: list[tuple[str, list[str]]] = [
    ("Activity", ["activity"]),
    ("Concept", ["concept"]),
    ("Event", ["event"]),
    ("Location", ["location"]),
    ("Nationality", []),          # canonical exists, no lowercase variant
    ("Organization", ["organization"]),
    ("Person", ["person"]),
    ("Product", ["product"]),
    ("Technology", ["technology"]),
    ("Temporal", ["temporal"]),
    ("Work_Of_Art", ["work_of_art"]),
]

# Stragglers without an existing canonical. We create the canonical.
MISSING_CANONICALS: list[str] = ["Language"]


def cypher(query: str, *, dry_run: bool) -> str:
    """Run a Cypher query against `GRAPH` and return stdout."""
    if dry_run:
        print(f"  [dry-run] {query}")
        return ""
    proc = subprocess.run(
        ["docker", "exec", CONTAINER, "redis-cli", "GRAPH.QUERY", GRAPH, query, "--no-raw"],
        capture_output=True,
        text=True,
        check=True,
    )
    out = proc.stdout.strip()
    if proc.stderr:
        print(f"    stderr: {proc.stderr.strip()}", file=sys.stderr)
    return out


def rewire_and_delete(canonical: str, duplicate_predicate: str, dry_run: bool) -> None:
    """Rewire inbound edges from duplicates → canonical, then DETACH DELETE duplicates.

    `duplicate_predicate` is a WHERE clause body that selects the duplicate rows
    (bound as `d`). Canonical is bound as `c` via PascalCase + pure :OntologyType label.
    """
    # Rewire INSTANCE_OF edges (:Entity -> type)
    q1 = (
        f"MATCH (c:OntologyType {{name: '{canonical}'}}) WHERE NOT c:EntityType "
        f"WITH c MATCH (d) WHERE {duplicate_predicate} "
        f"WITH c, d MATCH (src:Entity)-[r:INSTANCE_OF]->(d) "
        f"MERGE (src)-[:INSTANCE_OF]->(c) "
        f"DELETE r"
    )
    print(f"  [INSTANCE_OF rewire] canonical={canonical}")
    print(cypher(q1, dry_run=dry_run))

    # Rewire IS_INSTANCE_OF edges (:EntityPattern -> type)
    q2 = (
        f"MATCH (c:OntologyType {{name: '{canonical}'}}) WHERE NOT c:EntityType "
        f"WITH c MATCH (d) WHERE {duplicate_predicate} "
        f"WITH c, d MATCH (src:EntityPattern)-[r:IS_INSTANCE_OF]->(d) "
        f"MERGE (src)-[:IS_INSTANCE_OF]->(c) "
        f"DELETE r"
    )
    print(f"  [IS_INSTANCE_OF rewire] canonical={canonical}")
    print(cypher(q2, dry_run=dry_run))

    # DETACH DELETE the duplicates (any remaining edges, e.g. zero-inbound rows)
    q3 = f"MATCH (d) WHERE {duplicate_predicate} DETACH DELETE d"
    print(f"  [DELETE duplicates] canonical={canonical}")
    print(cypher(q3, dry_run=dry_run))


def consolidate_concept(canonical: str, lowercase_variants: Iterable[str], dry_run: bool) -> None:
    """Absorb (a) PascalCase :EntityType-only and (b) lowercase variants into canonical."""
    print(f"\n--- Consolidating {canonical} ---")

    # Step A: absorb PascalCase :EntityType-only row (the with-status straggler).
    # Predicate: name = canonical AND has :EntityType AND NOT :OntologyType.
    pred_a = f"d.name = '{canonical}' AND d:EntityType AND NOT d:OntologyType"
    rewire_and_delete(canonical, pred_a, dry_run)

    # Step B: absorb lowercase variants (both :EntityType-only and dual-labeled).
    for lc in lowercase_variants:
        pred_b = f"d.name = '{lc}'"  # any label combo; canonical is PascalCase so no collision risk
        rewire_and_delete(canonical, pred_b, dry_run)


def create_missing_canonical(name: str, dry_run: bool) -> None:
    """Create (:OntologyType {name, tier='working'}) if not present."""
    # Idempotent via MERGE.
    q = (
        f"MERGE (c:OntologyType {{name: '{name}'}}) "
        f"ON CREATE SET c.tier = 'working' "
        f"RETURN c.name, c.tier"
    )
    print(f"\n--- Creating missing canonical: {name} ---")
    print(cypher(q, dry_run=dry_run))

    # Now absorb the straggler row with the same name (no canonical existed before this
    # call; after MERGE the canonical exists, but the straggler must lose :EntityType
    # and gain :OntologyType via deletion + edge rewire).
    pred = f"d.name = '{name}' AND d:EntityType AND NOT d:OntologyType"
    rewire_and_delete(name, pred, dry_run)


def verify_clean(dry_run: bool) -> bool:
    """Re-run the cutover gate queries. Return True if all-zero."""
    print("\n=== Cutover gate verification ===")
    if dry_run:
        print("  [dry-run] skipping verification")
        return False

    checks = [
        ("stragglers (EntityType ∧ ¬OntologyType)",
         "MATCH (n:EntityType) WHERE NOT n:OntologyType RETURN count(n)"),
        ("untiered (OntologyType ∧ tier IS NULL)",
         "MATCH (n:OntologyType) WHERE n.tier IS NULL RETURN count(n)"),
    ]
    all_clean = True
    for label, q in checks:
        out = cypher(q, dry_run=False)
        # parse second line of redis-cli output
        lines = [l.strip() for l in out.splitlines() if l.strip() and not l.startswith("Cached") and not l.startswith("Query")]
        # First line is the column header ("count(n)"), second is the value.
        value = lines[1] if len(lines) >= 2 else "?"
        marker = "✅" if value == "0" else "❌"
        print(f"  {marker} {label}: {value}")
        if value != "0":
            all_clean = False
    return all_clean


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--dry-run", action="store_true", help="Print Cypher without executing")
    mode.add_argument("--execute", action="store_true", help="Actually run the consolidation")
    args = ap.parse_args()

    dry_run = args.dry_run

    print(f"Graph: {GRAPH}")
    print(f"Mode:  {'DRY RUN' if dry_run else 'EXECUTE'}")

    for canonical, lowercase in CONCEPTS:
        consolidate_concept(canonical, lowercase, dry_run)

    for name in MISSING_CANONICALS:
        create_missing_canonical(name, dry_run)

    clean = verify_clean(dry_run)
    if dry_run:
        print("\nDry-run complete. Re-run with --execute to apply.")
        return 0
    if clean:
        print("\n✅ Cutover gate clean. INSIGHTS-ONTO-CUTOVER-1 unblocked for this workspace.")
        return 0
    print("\n❌ Cutover gate still failing. Inspect output above.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
