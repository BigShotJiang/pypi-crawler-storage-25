from __future__ import annotations

import argparse
import contextlib
import json
import os
import select
import shutil
import sys
import termios
import threading
import tty
from datetime import datetime, timezone
from typing import Any, Callable
from urllib.parse import urljoin, urlparse

from websockets.exceptions import ConnectionClosed, InvalidHandshake
from websockets.sync.client import connect as websocket_connect

from runtime_sdk import __version__
from runtime_sdk.client import DEFAULT_WARMUP_TIMEOUT, RuntimeAPIError, RuntimeClient
from runtime_sdk.config import (
    DEFAULT_BASE_URL,
    PendingSignup,
    RuntimeConfig,
    RuntimeConfigError,
    load_config,
    save_config,
)


# --------------------------------------------------------------------------- #
# TTY detection + lazy rich/questionary imports                               #
# --------------------------------------------------------------------------- #


def _interactive() -> bool:
    """True when we have a real terminal on both ends — enables fancy UI."""
    if os.environ.get("RUNTIME_NO_TTY"):
        return False
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except (AttributeError, ValueError):
        return False


SPINNER = "aesthetic"  # unicode ▰▱ progress-bar style; single place to tweak.


def _with_spinner(label: str, fn: Callable[[], Any]) -> Any:
    """Run fn(), wrapped in a rich spinner when interactive."""
    if not _interactive():
        return fn()
    with _UI.console().status(f"[cyan]{label}[/cyan]", spinner=SPINNER):
        return fn()


class _UI:
    """Lazy holder for rich + questionary so non-TTY paths stay import-cheap."""

    _console: Any = None
    _err_console: Any = None
    _questionary: Any = None
    _questionary_style: Any = None
    _rich_mods: dict[str, Any] | None = None

    @classmethod
    def console(cls) -> Any:
        if cls._console is None:
            from rich.console import Console

            cls._console = Console()
        return cls._console

    @classmethod
    def err(cls) -> Any:
        if cls._err_console is None:
            from rich.console import Console

            cls._err_console = Console(stderr=True)
        return cls._err_console

    @classmethod
    def q(cls) -> Any:
        if cls._questionary is None:
            import questionary

            cls._questionary = questionary
        return cls._questionary

    @classmethod
    def style(cls) -> Any:
        if cls._questionary_style is None:
            cls._questionary_style = cls.q().Style(
                [
                    ("qmark", "fg:#22c55e bold"),
                    ("question", "bold fg:#e5e7eb"),
                    ("answer", "fg:#22c55e bold"),
                    ("pointer", "fg:#60a5fa bold"),
                    ("highlighted", "fg:#ffffff bg:#1f2937 bold"),
                    ("selected", "fg:#22c55e bold"),
                    ("separator", "fg:#4b5563"),
                    ("instruction", "fg:#94a3b8 italic"),
                    ("text", "fg:#d1d5db"),
                    ("disabled", "fg:#6b7280 italic"),
                ]
            )
        return cls._questionary_style

    @classmethod
    def rich(cls) -> dict[str, Any]:
        if cls._rich_mods is None:
            from rich import box
            from rich.panel import Panel
            from rich.table import Table
            from rich.text import Text

            cls._rich_mods = {"Panel": Panel, "Text": Text, "Table": Table, "box": box}
        return cls._rich_mods


# --------------------------------------------------------------------------- #
# argparse                                                                    #
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="runtime")
    parser.add_argument("--base-url", help="Runtime API base URL")
    parser.add_argument("--version", action="version", version=f"runtime-sdk {__version__}")

    # Subcommand is optional: bare `runtime` defaults to `create`.
    subparsers = parser.add_subparsers(dest="command", required=False)

    signup = subparsers.add_parser("signup", help="Send an email verification code")
    signup.add_argument("email", nargs="?", default=None)
    signup.add_argument("--name", default=None)

    verify = subparsers.add_parser("verify", help="Verify an emailed code and save a fresh API key")
    verify.add_argument("code", nargs="?", default=None)
    verify.add_argument("--flow-id", type=int)

    login = subparsers.add_parser("login", help="Start email login or import an API key")
    login.add_argument(
        "identifier",
        nargs="?",
        default=None,
        help="Email address to send a code to, or an API key for backwards compatibility",
    )
    login.add_argument("--name", default=None, help="Optional display name for first-time email signup")
    login.add_argument(
        "--api-key",
        nargs="?",
        const="",
        default=None,
        help="Import an API key explicitly (prompts if omitted in interactive mode)",
    )

    subparsers.add_parser("whoami")
    subparsers.add_parser("logout")

    create_cmd = subparsers.add_parser("create", help="Create a new computer")
    create_cmd.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Subdomain name (e.g. redsox → redsox.runruntime.dev). Random if skipped.",
    )
    create_cmd.add_argument("--command", dest="startup_command", help="App startup command to run after create")
    create_cmd.add_argument("--cwd", help="Working directory for the startup command")
    create_cmd.add_argument("--port", type=int, help="App port to publish after startup")
    subparsers.add_parser("list", aliases=["ls"], help="List computers")

    enter_cmd = subparsers.add_parser("enter", help="Enter a computer's console")
    enter_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    info_cmd = subparsers.add_parser("info", help="Get computer details")
    info_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    start_cmd = subparsers.add_parser("start", help="Wake a cold computer")
    start_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    delete_cmd = subparsers.add_parser("delete", aliases=["rm"], help="Delete a computer")
    delete_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    run_cmd = subparsers.add_parser("run", help="Run a command in a computer")
    run_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    run_cmd.add_argument(
        "run_command",
        metavar="command",
        nargs="?",
        default=None,
        help="Command to run",
    )
    run_cmd.add_argument("--uid", type=int, help="User ID")
    run_cmd.add_argument("--gid", type=int, help="Group ID")
    run_cmd.add_argument("--cwd", help="Working directory")
    run_cmd.add_argument("--shell", help="Shell to use")

    publish_cmd = subparsers.add_parser(
        "publish", help="Pin the public URL to a local app port"
    )
    publish_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    publish_cmd.add_argument("port", nargs="?", type=int, default=None, help="Local app port")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # Bare `runtime` → create flow.
    if args.command is None:
        args.command = "create"
        args.name = None

    try:
        config = load_config()
        base_url = (
            args.base_url
            or os.environ.get("RUNTIME_BASE_URL")
            or config.base_url
            or DEFAULT_BASE_URL
        )
        config.base_url = base_url

        if args.command == "signup":
            return handle_signup(config, args.email, args.name)
        if args.command == "verify":
            return handle_verify(config, args.code, args.flow_id)
        if args.command == "login":
            return handle_login(config, args.identifier, args.name, args.api_key)
        if args.command == "whoami":
            return handle_whoami(config)
        if args.command == "logout":
            return handle_logout(config)
        if args.command == "create":
            return handle_create(
                config,
                args.name,
                getattr(args, "startup_command", None),
                getattr(args, "cwd", None),
                getattr(args, "port", None),
            )
        if args.command in ("list", "ls"):
            return handle_list(config)
        if args.command == "info":
            return handle_info(config, args.id)
        if args.command == "start":
            return handle_start(config, args.id)
        if args.command == "enter":
            return handle_enter(config, args.id)
        if args.command in ("delete", "rm"):
            return handle_delete(config, args.id)
        if args.command == "run":
            return handle_run(
                config, args.id, args.run_command, args.uid, args.gid, args.cwd, args.shell
            )
        if args.command == "publish":
            return handle_publish(config, args.id, args.port)
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)
    except RuntimeConfigError as exc:
        return report_error(str(exc))
    except KeyboardInterrupt:
        if _interactive():
            UI = _UI.err()
            UI.print("\n[dim]cancelled[/dim]")
            return 130
        return report_error("cancelled")

    return report_error("unknown command")


# --------------------------------------------------------------------------- #
# Shared helpers                                                              #
# --------------------------------------------------------------------------- #


def write_json(payload: dict[str, Any], *, error: bool = False) -> int:
    stream = sys.stderr if error else sys.stdout
    stream.write(json.dumps(payload) + "\n")
    return 1 if error else 0


def report_error(message: str, *, status_code: int | None = None) -> int:
    """Error output — JSON in non-TTY mode, rich in TTY mode."""
    if _interactive():
        err = _UI.err()
        suffix = f" [dim](http {status_code})[/dim]" if status_code is not None else ""
        err.print(f"[bold red]✗[/bold red] {message}{suffix}")
        return 1
    payload: dict[str, Any] = {"success": False, "error": message}
    if status_code is not None:
        payload["status_code"] = status_code
    return write_json(payload, error=True)


def report_success(payload: dict[str, Any], renderer: Callable[[dict[str, Any]], None] | None = None) -> int:
    """Success output — rich renderer in TTY, JSON otherwise."""
    if _interactive() and renderer is not None:
        renderer(payload)
        return 0
    return write_json({"success": True, **payload})


def _require_api_key(config: RuntimeConfig) -> int | None:
    if config.api_key:
        return None
    return report_error("missing api key; run login or verify first")


def _prompt_text(message: str, *, default: str | None = None) -> str | None:
    """Ask for a line of text. Returns None if the user left it blank.

    Ctrl-C propagates as KeyboardInterrupt, handled centrally by main().
    """
    answer = _UI.q().text(message, default=default or "").unsafe_ask()
    return answer.strip() or None


def _prompt_password(message: str) -> str | None:
    answer = _UI.q().password(message).unsafe_ask()
    return answer.strip() or None


def _prompt_confirm(message: str, *, default: bool = False) -> bool:
    return bool(_UI.q().confirm(message, default=default).unsafe_ask())


def _display_width(value: Any, minimum: int, maximum: int) -> int:
    text = str(value or "")
    return max(minimum, min(len(text), maximum))


def _fit_cell(value: Any, width: int) -> str:
    text = str(value or "")
    if width <= 0:
        return ""
    if len(text) > width:
        if width == 1:
            return "…"
        text = text[: width - 1] + "…"
    return text.ljust(width)


def _computer_power_state(c: dict[str, Any]) -> str:
    power = c.get("power_state")
    if power is not None:
        return str(power or "?")
    status = str(c.get("status") or "?")
    if status in ("warm", "cold"):
        return status
    if status == "deleted":
        return "cold"
    return "warm"



def _computer_internal_status(c: dict[str, Any]) -> str:
    internal = c.get("internal_status")
    if internal is not None:
        return str(internal or "?")
    return str(c.get("status") or "?")



def _computer_status_label(c: dict[str, Any]) -> str:
    power = _computer_power_state(c)
    internal = _computer_internal_status(c)
    if power == internal:
        return power
    if power == "warm" and internal == "running":
        return power
    return f"{power}/{internal}"



def _computer_matches_ref(c: dict[str, Any], ref: str) -> bool:
    ref = ref.strip()
    if not ref:
        return False

    candidates = {
        str(c.get("id") or "").strip(),
        str(c.get("slug") or "").strip(),
        str(c.get("hostname") or "").strip(),
        str(c.get("public_url") or "").strip(),
    }

    public_url = str(c.get("public_url") or "").strip()
    if public_url:
        parsed = urlparse(public_url)
        if parsed.netloc:
            candidates.add(parsed.netloc)
            first_label = parsed.netloc.split(".", 1)[0].strip()
            if first_label:
                candidates.add(first_label)

    return ref in {value for value in candidates if value}



def _resolve_computer_ref(client: RuntimeClient, ref: str) -> str:
    ref = ref.strip()
    if not ref:
        raise RuntimeAPIError("computer id is required")
    if ref.startswith("cmp_"):
        return ref

    try:
        payload = client.list_computers()
    except RuntimeAPIError:
        return ref

    computers = payload.get("computers") or []
    if not isinstance(computers, list):
        computers = []

    matches = [c for c in computers if isinstance(c, dict) and _computer_matches_ref(c, ref)]
    if len(matches) == 1:
        resolved = str(matches[0].get("id") or "").strip()
        return resolved or ref
    if len(matches) > 1:
        raise RuntimeAPIError(f"multiple computers matched {ref!r}; use the exact computer id")
    return ref



def _computer_name(c: dict[str, Any]) -> str:
    return str(c.get("slug") or c.get("id") or "?")



def _computer_url_label(c: dict[str, Any]) -> str:
    public_url = str(c.get("public_url") or "").strip()
    if not public_url:
        return ""
    parsed = urlparse(public_url)
    return parsed.netloc or public_url



def _computer_created_label(c: dict[str, Any]) -> str:
    raw = str(c.get("created_at") or "").strip()
    if not raw:
        return ""
    try:
        created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return raw
    delta = datetime.now(timezone.utc) - created.astimezone(timezone.utc)
    seconds = max(0, int(delta.total_seconds()))
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    return f"{days}d"



def _computer_status_style(status: str) -> str:
    if "cold" in status:
        return "bold cyan"
    if "warm" in status or "running" in status:
        return "bold green"
    if "archiving" in status or "restoring" in status:
        return "bold yellow"
    if "creating" in status:
        return "bold magenta"
    if "orphaned" in status:
        return "bold red"
    return "white"



def _computer_status_dot(status: str) -> str:
    if "cold" in status:
        return "◌"
    if "warm" in status or "running" in status:
        return "●"
    if "archiving" in status or "restoring" in status:
        return "◐"
    if "creating" in status:
        return "◔"
    if "orphaned" in status:
        return "✕"
    return "•"



def _computer_sort_key(c: dict[str, Any]) -> tuple[int, str, str]:
    status = _computer_status_label(c)
    priority = 1
    if "warm" in status or "running" in status:
        priority = 0
    elif "cold" in status:
        priority = 1
    elif "restoring" in status or "creating" in status:
        priority = 2
    else:
        priority = 3
    return (priority, _computer_name(c).lower(), str(c.get("id") or ""))



def _computer_table_layout(computers: list[dict[str, Any]]) -> dict[str, int]:
    term_width = shutil.get_terminal_size((100, 20)).columns
    slug_width = max(_display_width(_computer_name(c), len("name"), 24) for c in computers)
    status_width = max(
        _display_width(_computer_status_label(c), len("state"), 20)
        for c in computers
    )
    created_width = max(
        _display_width(_computer_created_label(c), len("age"), 8)
        for c in computers
    )
    reserved = slug_width + status_width + created_width + len("  ") * 3
    url_budget = max(16, term_width - reserved)
    url_width = max(
        len("url"),
        min(max(len(_computer_url_label(c)) for c in computers), url_budget),
    )
    return {
        "slug": slug_width,
        "status": status_width,
        "public_url": url_width,
        "created_at": created_width,
    }


def _format_computer_row(c: dict[str, Any], widths: dict[str, int]) -> str:
    return " │ ".join(
        [
            _fit_cell(_computer_name(c), widths["slug"]),
            _fit_cell(_computer_status_label(c), widths["status"]),
            _fit_cell(_computer_url_label(c), widths["public_url"]),
            _fit_cell(_computer_created_label(c), widths["created_at"]),
        ]
    )


def _computer_table_prompt(prompt: str, computers: list[dict[str, Any]]) -> tuple[str, dict[str, int]]:
    widths = _computer_table_layout(computers)
    header = " │ ".join(
        [
            _fit_cell("name", widths["slug"]),
            _fit_cell("state", widths["status"]),
            _fit_cell("url", widths["public_url"]),
            _fit_cell("age", widths["created_at"]),
        ]
    )
    divider = "─" * len(header)
    return f"{prompt}\n{header}\n{divider}", widths



def _computer_choice_title(c: dict[str, Any], widths: dict[str, int]) -> str:
    del widths
    status = _computer_status_label(c)
    url = _computer_url_label(c)
    created = _computer_created_label(c)
    parts = [f"{_computer_name(c)}", status]
    if url:
        parts.append(url)
    if created:
        parts.append(created)
    return "  ·  ".join(parts)



def _render_computer_summary(computers: list[dict[str, Any]]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    counts: dict[str, int] = {}
    for computer in computers:
        status = _computer_status_label(computer)
        counts[status] = counts.get(status, 0) + 1

    body = Text()
    body.append(f"total {len(computers)}", style="bold white")
    if counts:
        body.append("   ")
    first = True
    status_styles = {
        "warm": "bold green",
        "cold": "bold cyan",
        "running": "bold green",
        "archiving": "bold yellow",
        "restoring": "bold yellow",
        "creating": "bold magenta",
        "orphaned": "bold red",
    }
    for status in sorted(counts):
        if not first:
            body.append("  •  ", style="dim")
        first = False
        status_style = "bold white"
        for token, style in status_styles.items():
            if token in status:
                status_style = style
                break
        body.append(status, style=status_style)
        body.append(f" {counts[status]}", style="white")

    _UI.console().print(
        Panel(body, title="runtime", border_style="blue", expand=False, padding=(0, 1))
    )



def _render_computer_table(computers: list[dict[str, Any]], *, title: str | None = None) -> None:
    mods = _UI.rich()
    Table, box = mods["Table"], mods["box"]
    table = Table(
        title=title,
        box=box.MINIMAL_DOUBLE_HEAD,
        expand=True,
        show_lines=False,
        header_style="bold #7dd3fc",
        title_style="bold white",
        pad_edge=False,
        collapse_padding=True,
        row_styles=["", "dim"],
    )
    table.add_column("Name", style="bold white", no_wrap=True, ratio=2)
    table.add_column("State", no_wrap=True, ratio=2)
    table.add_column("URL", style="white", overflow="fold", ratio=4)
    table.add_column("Age", style="dim", no_wrap=True, justify="right", ratio=1)

    for computer in sorted(computers, key=_computer_sort_key):
        status = _computer_status_label(computer)
        status_style = _computer_status_style(status)
        table.add_row(
            _computer_name(computer),
            f"[{status_style}]{_computer_status_dot(status)} {status}[/{status_style}]",
            _computer_url_label(computer),
            _computer_created_label(computer),
        )

    _UI.console().print(table)


def _select_prompt(message: str, choices: list[Any]) -> Any:
    return _UI.q().select(
        message,
        choices=choices,
        qmark="●",
        pointer="❯",
        instruction="↑/↓ or j/k • Enter",
        use_indicator=True,
        style=_UI.style(),
    )


def _pick_computer(
    config: RuntimeConfig,
    prompt: str,
    predicate: Callable[[dict[str, Any]], bool] | None = None,
) -> dict[str, Any] | None:
    """Fetch computers and let the user arrow-key through them.

    Returns the picked computer dict, or None if the list is empty or the user
    explicitly chose "← cancel". Ctrl-C propagates as KeyboardInterrupt.
    """
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    payload = client.list_computers()
    computers = payload.get("computers") or []
    if not isinstance(computers, list):
        computers = []
    if predicate is not None:
        computers = [c for c in computers if isinstance(c, dict) and predicate(c)]
    computers = sorted(computers, key=_computer_sort_key)
    if not computers:
        _UI.err().print("[yellow]no matching computers found[/yellow]")
        return None

    questionary = _UI.q()
    widths = _computer_table_layout(computers)
    _render_computer_table(computers)
    choices = [
        questionary.Choice(title=_computer_choice_title(c, widths), value=c) for c in computers
    ]
    choices.append(questionary.Choice(title="← cancel", value=None))
    picked = _select_prompt(prompt, choices).unsafe_ask()
    return picked if isinstance(picked, dict) else None


# --------------------------------------------------------------------------- #
# Rich renderers                                                              #
# --------------------------------------------------------------------------- #


def _render_computer_panel(c: dict[str, Any], *, title: str = "computer") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    status = _computer_status_label(c)
    status_style = _computer_status_style(status)
    rows: list[tuple[str, str, str | None]] = [
        ("name", _computer_name(c), "bold white"),
        ("state", f"{_computer_status_dot(status)} {status}", status_style),
        ("url", _computer_url_label(c) or "—", "white"),
        ("age", _computer_created_label(c) or "—", "dim"),
        ("id", str(c.get("id") or "—"), "dim"),
    ]
    for label, value, style in rows:
        body.append(f"{label:<8}", style="dim")
        body.append(value, style=style or "white")
        body.append("\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False, padding=(0, 1)))


def _render_run_result(result: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel = mods["Panel"]
    console = _UI.console()
    stdout = result.get("stdout") or ""
    stderr = result.get("stderr") or ""
    exit_code = result.get("exit_code")
    if stdout:
        console.print(Panel(stdout.rstrip(), title="stdout", border_style="green", expand=False))
    if stderr:
        console.print(Panel(stderr.rstrip(), title="stderr", border_style="red", expand=False))
    color = "green" if exit_code == 0 else "red"
    console.print(f"[{color}]exit {exit_code}[/{color}]")


def _render_whoami_panel(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    owner = payload.get("owner") or {}
    rows: list[tuple[str, Any]] = [
        ("email", owner.get("email")),
        ("name", owner.get("name")),
        ("account id", payload.get("account_id")),
        ("trust tier", payload.get("trust_tier")),
    ]
    body = Text()
    for label, value in rows:
        if value is None:
            continue
        body.append(f"{label:<12}", style="dim")
        body.append(f"{value}\n")
    _UI.console().print(Panel(body, title="whoami", border_style="cyan", expand=False))


# --------------------------------------------------------------------------- #
# Command handlers                                                            #
# --------------------------------------------------------------------------- #


def _looks_like_api_key(value: str | None) -> bool:
    candidate = (value or "").strip()
    return candidate.startswith("rt_live_")


def _start_verification_flow(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    if email is None:
        if not _interactive():
            return report_error("email is required")
        email = _prompt_text("Email")
        if not email:
            return report_error("email is required")

    client = RuntimeClient(base_url=config.base_url)
    result = client.start_verification(email, name)
    config.pending_signup = PendingSignup(
        flow_id=int(result["flow_id"]),
        email=email,
        expires_at=result.get("expires_at"),
    )
    save_config(config)

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print(
            f"[green]✓[/green] verification code sent to [bold]{email}[/bold]"
        )
        _UI.console().print(
            f"[dim]then run:[/dim] runtime verify <code>"
        )

    return report_success(result, render)


def _login_with_api_key(config: RuntimeConfig, api_key: str | None) -> int:
    if api_key is None or api_key == "":
        if not _interactive():
            return report_error("api key is required")
        api_key = _prompt_password("API key")
        if not api_key:
            return report_error("api key is required")

    client = RuntimeClient(base_url=config.base_url, api_key=api_key)
    whoami = client.whoami()
    config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(_: dict[str, Any]) -> None:
        owner = whoami.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] api key saved")

    return report_success({"message": "logged in", **whoami}, render)


def handle_signup(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    return _start_verification_flow(config, email, name)


def handle_verify(config: RuntimeConfig, code: str | None, flow_id: int | None) -> int:
    pending = config.pending_signup
    resolved_flow_id = flow_id or (pending.flow_id if pending else None)
    if not resolved_flow_id:
        return report_error("missing flow id; run login first or pass --flow-id")

    if code is None:
        if not _interactive():
            return report_error("verification code is required")
        code = _prompt_text("Verification code")
        if not code:
            return report_error("verification code is required")

    client = RuntimeClient(base_url=config.base_url)
    result = client.verify(resolved_flow_id, code)
    api_key = result.get("api_key")
    if api_key:
        config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(payload: dict[str, Any]) -> None:
        owner = payload.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] verified, logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] verified, api key saved")

    return report_success(result, render)


def handle_login(
    config: RuntimeConfig,
    identifier: str | None,
    name: str | None,
    api_key: str | None,
) -> int:
    if api_key is not None:
        if identifier is not None:
            return report_error("pass either an email/api key argument or --api-key, not both")
        return _login_with_api_key(config, api_key)

    if _looks_like_api_key(identifier):
        return _login_with_api_key(config, identifier)

    return _start_verification_flow(config, identifier, name)


def handle_whoami(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.whoami()
    return report_success(result, _render_whoami_panel)


def handle_logout(config: RuntimeConfig) -> int:
    had_api_key = config.api_key is not None
    revoked = False
    if config.api_key:
        try:
            RuntimeClient(base_url=config.base_url, api_key=config.api_key).logout()
            revoked = True
        except RuntimeAPIError:
            revoked = False

    config.api_key = None
    config.pending_signup = None
    save_config(config)

    message = "logged out"
    if had_api_key and not revoked:
        message = "logged out locally"

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] {message}")

    return report_success({"message": message}, render)


def handle_create(
    config: RuntimeConfig,
    name: str | None,
    startup_command: str | None,
    cwd: str | None,
    port: int | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if name is None and _interactive():
        name = _prompt_text("Name your computer")

    if startup_command is None and port is not None:
        return report_error("startup command is required when port is provided")
    if startup_command is not None and port is None:
        return report_error("port is required when startup command is provided")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    label = "creating computer…"
    if startup_command is not None:
        label = f"creating computer and starting app on port {port}…"
    result = _with_spinner(
        label,
        lambda: client.create_computer(slug=name, command=startup_command, cwd=cwd, port=port),
    )

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="created")
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    code = report_success(result, render)
    if code != 0 or not _interactive():
        return code

    computer_id = result.get("id") or result.get("slug")
    if not computer_id:
        return code
    return _enter_computer(config, str(computer_id), announce_created=False)


def handle_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if _interactive():
        return _interactive_list(config)

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_computers())


def handle_info(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_computer(computer_id)
    return report_success(result, lambda p: _render_computer_panel(p, title="computer"))


def handle_start(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a cold computer to wake",
            lambda c: _computer_power_state(c) == "cold",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(f"warming {computer_id}…", lambda: client.start_computer(computer_id))

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="warmed")
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    return report_success(result, render)


def handle_enter(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not _interactive():
        return report_error("enter requires an interactive terminal")

    if computer_id is None:
        picked = _pick_computer(
            config,
            "Pick a computer to enter",
            lambda c: _computer_internal_status(c) in ("running", "cold"),
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, str(computer_id))
    return _enter_computer(config, str(computer_id))


def handle_delete(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    interactive_pick = False
    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer to delete")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")
        interactive_pick = True

    if interactive_pick:
        if not _prompt_confirm(
            f"Delete {computer_id}? This cannot be undone.", default=False
        ):
            _UI.console().print("[dim]cancelled[/dim]")
            return 0

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    display_ref = computer_id
    computer_id = _resolve_computer_ref(client, computer_id)
    client.delete_computer(computer_id)

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] deleted [bold]{display_ref}[/bold]")

    return report_success({"message": f"computer {display_ref} deleted"}, render)


def handle_run(
    config: RuntimeConfig,
    computer_id: str | None,
    command: str | None,
    uid: int | None,
    gid: int | None,
    cwd: str | None,
    shell: str | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a computer",
            lambda c: _computer_internal_status(c) == "running",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if command is None:
        if not _interactive():
            return report_error("command is required")
        command = _prompt_text("Command to run")
        if not command:
            return report_error("command is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"running on {computer_id}…",
        lambda: client.run_command(
            computer_id, command, uid=uid, gid=gid, cwd=cwd, shell=shell
        ),
    )
    return report_success(result, _render_run_result)


def handle_publish(config: RuntimeConfig, computer_id: str | None, port: int | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a computer",
            lambda c: _computer_internal_status(c) == "running",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if port is None:
        if not _interactive():
            return report_error("port is required")
        port_text = _prompt_text("Port to publish", default="3000")
        if not port_text:
            return report_error("port is required")
        try:
            port = int(port_text)
        except ValueError:
            return report_error("port must be a number")

    if port <= 0 or port > 65535:
        return report_error("port must be between 1 and 65535")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    _with_spinner(
        f"publishing port {port} on {computer_id}…",
        lambda: client.publish_port(computer_id, port),
    )

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(
            f"[green]✓[/green] public url for [bold]{computer_id}[/bold] pinned to [bold]{port}[/bold]"
        )

    return report_success(
        {
            "message": f"computer {computer_id} published port {port}",
            "computer_id": computer_id,
            "port": port,
        },
        render,
    )


def _enter_computer(config: RuntimeConfig, computer_id: str, *, announce_created: bool = True) -> int:
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    ticket_payload = _with_spinner(
        f"preparing console for {computer_id}…",
        lambda: client.create_terminal_ticket(computer_id),
    )
    ws_url = _resolve_terminal_ws_url(config.base_url, ticket_payload.get("ws_url"))
    if not ws_url:
        return report_error("terminal endpoint did not return a websocket url")

    if announce_created:
        _UI.console().print("[cyan]●[/cyan] Connecting to console...")
    else:
        _UI.console().print("[cyan]●[/cyan] Connecting to console...")

    try:
        return _run_terminal_session(ws_url)
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)
    except (InvalidHandshake, TimeoutError, OSError) as exc:
        return report_error(f"terminal failed: {exc}")


def _resolve_terminal_ws_url(base_url: str, ws_url: Any) -> str:
    text = str(ws_url or "").strip()
    if not text:
        return ""
    if text.startswith("ws://") or text.startswith("wss://"):
        return text

    parsed = urlparse(base_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    root = f"{scheme}://{parsed.netloc}"
    if text.startswith("/"):
        return root + text
    return urljoin(root + "/", text)


def _run_terminal_session(ws_url: str) -> int:
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return report_error("enter requires an interactive terminal")

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    stop = threading.Event()
    result: dict[str, Any] = {"code": 0, "error": None}
    output_state: dict[str, Any] = {"buffer": "", "suppressing_preamble": True}

    with websocket_connect(ws_url, open_timeout=DEFAULT_WARMUP_TIMEOUT, close_timeout=1) as ws:
        _send_terminal_resize(ws)

        def recv_loop() -> None:
            try:
                while not stop.is_set():
                    raw = ws.recv()
                    if raw is None:
                        result["code"] = 0
                        stop.set()
                        return
                    event = json.loads(raw)
                    event_type = str(event.get("type") or "")
                    if event_type == "ready":
                        continue
                    if event_type == "output":
                        data = _filter_terminal_output(str(event.get("data") or ""), output_state)
                        if data:
                            sys.stdout.write(data)
                            sys.stdout.flush()
                        continue
                    if event_type == "exit":
                        result["code"] = int(event.get("code") or 0)
                        message = str(event.get("message") or "").strip()
                        if message:
                            result["error"] = message
                        stop.set()
                        return
                    if event_type == "error":
                        result["code"] = 1
                        result["error"] = str(event.get("message") or "terminal error")
                        stop.set()
                        return
            except ConnectionClosed:
                stop.set()
            except Exception as exc:  # pragma: no cover - defensive for real TTY sessions
                result["code"] = 1
                result["error"] = str(exc)
                stop.set()

        recv_thread = threading.Thread(target=recv_loop, daemon=True)
        recv_thread.start()

        last_size = shutil.get_terminal_size((100, 24))
        try:
            tty.setraw(fd)
            while not stop.is_set():
                current_size = shutil.get_terminal_size((100, 24))
                if current_size != last_size:
                    _send_terminal_resize(ws)
                    last_size = current_size

                readable, _, _ = select.select([fd], [], [], 0.1)
                if fd not in readable:
                    continue
                data = os.read(fd, 1024)
                if not data:
                    stop.set()
                    break
                ws.send(json.dumps({"type": "input", "data": data.decode("utf-8", errors="ignore")}))
        finally:
            stop.set()
            with contextlib.suppress(Exception):
                ws.close()
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            recv_thread.join(timeout=1)

    sys.stdout.write("\n")
    sys.stdout.flush()
    tail = _flush_terminal_output(output_state)
    if tail:
        sys.stdout.write(tail)
        sys.stdout.flush()
    if result.get("error"):
        _UI.err().print(f"[bold red]✗[/bold red] {result['error']}")
    return int(result.get("code") or 0)


def _filter_terminal_output(chunk: str, state: dict[str, Any]) -> str:
    if not chunk:
        return ""
    if not state.get("suppressing_preamble", False):
        return _strip_terminal_noise(chunk)

    buffer = str(state.get("buffer") or "") + chunk
    marker = "\x1b[1;34mruntime@"
    idx = buffer.find(marker)
    if idx != -1:
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return _strip_terminal_noise(buffer[idx:])

    cleaned = _strip_terminal_noise(buffer)
    if cleaned and _should_release_terminal_output(cleaned):
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return cleaned

    if len(buffer) > 8192:
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return _strip_terminal_noise(buffer)

    state["buffer"] = buffer
    return ""



def _should_release_terminal_output(text: str) -> bool:
    if not text:
        return False
    if "\n" in text or "\r" in text:
        return True
    if len(text) >= 256:
        return True

    stripped = text.rstrip()
    return text.endswith(("$ ", "# ", "% ", "> ")) or stripped.endswith(("$", "#", "%", ">"))



def _flush_terminal_output(state: dict[str, Any]) -> str:
    buffer = str(state.get("buffer") or "")
    state["buffer"] = ""
    return _strip_terminal_noise(buffer)


def _strip_terminal_noise(text: str) -> str:
    if not text:
        return ""

    lines = text.splitlines(keepends=True)
    filtered: list[str] = []
    for line in lines:
        stripped = line.rstrip("\r\n")
        if stripped == "Running bootstrap command: export PS1='\\[\\033[1;34m\\]runtime@\\h\\[\\033[0m\\]:\\w\\$ '":
            continue
        if stripped == "Connected! Press Ctrl+] to exit.":
            continue
        if stripped == "* Image built by SlicerVM (2026)":
            continue
        if stripped == "* Website: https://slicervm.com":
            continue
        if stripped == "* Docs: https://docs.slicervm.com":
            continue
        filtered.append(line)
    return "".join(filtered)


def _send_terminal_resize(ws: Any) -> None:
    size = shutil.get_terminal_size((100, 24))
    ws.send(json.dumps({"type": "resize", "cols": size.columns, "rows": size.lines}))


# --------------------------------------------------------------------------- #
# Interactive list → detail → action loop                                    #
# --------------------------------------------------------------------------- #


def _interactive_list(config: RuntimeConfig) -> int:
    """Nested menu: table → pick VM → action → back."""
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    questionary = _UI.q()

    while True:
        payload = _with_spinner("fetching computers…", client.list_computers)
        computers = payload.get("computers") or []
        if not isinstance(computers, list):
            computers = []

        if not computers:
            _UI.console().print("[dim]no computers yet. create one with `runtime create`.[/dim]")
            return 0

        computers = sorted(computers, key=_computer_sort_key)
        _render_computer_summary(computers)
        widths = _computer_table_layout(computers)
        _render_computer_table(computers, title="computers")
        choices = [
            questionary.Choice(title=_computer_choice_title(c, widths), value=c)
            for c in computers
        ]
        choices.append(questionary.Separator())
        choices.append(questionary.Choice(title="↻ refresh", value="__refresh__"))
        choices.append(questionary.Choice(title="✕ quit", value="__quit__"))

        picked = _select_prompt("Pick a computer", choices).unsafe_ask()

        if picked == "__quit__":
            return 0
        if picked == "__refresh__":
            continue
        if not isinstance(picked, dict):
            continue

        action = _vm_detail_menu(client, picked)
        if action == "__quit__":
            return 0
        # otherwise: loop and refresh the list


def _vm_detail_menu(client: RuntimeClient, vm: dict[str, Any]) -> str:
    """Action menu for a single VM. Returns '__back__' or '__quit__'."""
    questionary = _UI.q()
    vm_id = vm.get("id") or vm.get("slug") or "?"
    slug = vm.get("slug") or vm_id

    while True:
        _render_computer_panel(vm, title=f"computer: {slug}")

        power_state = _computer_power_state(vm)
        internal_status = _computer_internal_status(vm)
        choices = []
        if internal_status in ("running", "cold"):
            choices.append(questionary.Choice(title="⌨ enter console", value="enter"))
        if internal_status == "running":
            choices.append(questionary.Choice(title="▶ run a command", value="run"))
            choices.append(questionary.Choice(title="⤴ publish a port", value="publish"))
        if power_state == "cold":
            choices.append(questionary.Choice(title="☀ start / wake", value="start"))
        choices.extend(
            [
                questionary.Choice(title="ℹ refresh info", value="info"),
                questionary.Choice(title="⧉ copy public url", value="url"),
                questionary.Choice(title="✕ delete", value="delete"),
                questionary.Separator(),
                questionary.Choice(title="← back", value="__back__"),
                questionary.Choice(title="✕ quit", value="__quit__"),
            ]
        )

        action = _select_prompt(
            f"What would you like to do with {slug}?",
            choices,
        ).unsafe_ask()

        if action == "__back__":
            return "__back__"
        if action == "__quit__":
            return "__quit__"

        if action == "enter":
            _enter_computer(RuntimeConfig(base_url=client.base_url, api_key=client.api_key), str(vm_id))
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "run":
            command = _prompt_text("Command to run")
            if not command:
                continue
            result = _with_spinner(
                f"running on {slug}…", lambda: client.run_command(vm_id, command)
            )
            _render_run_result(result)
            continue

        if action == "start":
            vm = _with_spinner(f"warming {slug}…", lambda: client.start_computer(vm_id))
            continue

        if action == "publish":
            port_text = _prompt_text("Port to publish", default="3000")
            if not port_text:
                continue
            try:
                port = int(port_text)
            except ValueError:
                _UI.err().print("[red]port must be a number[/red]")
                continue
            if port <= 0 or port > 65535:
                _UI.err().print("[red]port must be between 1 and 65535[/red]")
                continue
            _with_spinner(
                f"publishing port {port} on {slug}…",
                lambda: client.publish_port(vm_id, port),
            )
            _UI.console().print(
                f"[green]✓[/green] public url for [bold]{slug}[/bold] pinned to [bold]{port}[/bold]"
            )
            continue

        if action == "info":
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "url":
            url = vm.get("public_url") or ""
            if not url:
                _UI.console().print("[yellow]no public url on this computer[/yellow]")
                continue
            _UI.console().print(f"[cyan]{url}[/cyan]")
            continue

        if action == "delete":
            if not _prompt_confirm(
                f"Delete {slug}? This cannot be undone.", default=False
            ):
                _UI.console().print("[dim]cancelled[/dim]")
                continue
            _with_spinner(f"deleting {slug}…", lambda: client.delete_computer(vm_id))
            _UI.console().print(f"[green]✓[/green] deleted [bold]{slug}[/bold]")
            return "__back__"


if __name__ == "__main__":
    raise SystemExit(main())
