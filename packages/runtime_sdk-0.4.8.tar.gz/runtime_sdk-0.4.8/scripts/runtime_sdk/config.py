from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path


DEFAULT_BASE_URL = "http://127.0.0.1:8080"


class RuntimeConfigError(RuntimeError):
    pass


@dataclass(slots=True)
class PendingSignup:
    flow_id: int
    email: str
    expires_at: str | None = None


@dataclass(slots=True)
class RuntimeConfig:
    base_url: str = DEFAULT_BASE_URL
    api_key: str | None = None
    pending_signup: PendingSignup | None = None


def config_path() -> Path:
    root = os.environ.get("XDG_CONFIG_HOME")
    if root:
        return Path(root) / "runtime" / "config.json"
    return Path.home() / ".config" / "runtime" / "config.json"


def load_config() -> RuntimeConfig:
    path = config_path()
    if not path.exists():
        return RuntimeConfig(base_url=os.environ.get("RUNTIME_BASE_URL", DEFAULT_BASE_URL))

    try:
        data = json.loads(path.read_text())
    except OSError as exc:
        raise RuntimeConfigError(f"failed to read config: {exc}") from exc
    except ValueError as exc:
        raise RuntimeConfigError("config file contains invalid JSON") from exc
    if not isinstance(data, dict):
        raise RuntimeConfigError("config file must contain a JSON object")
    pending = data.get("pending_signup")
    try:
        return RuntimeConfig(
            base_url=data.get("base_url") or os.environ.get("RUNTIME_BASE_URL", DEFAULT_BASE_URL),
            api_key=data.get("api_key"),
            pending_signup=PendingSignup(**pending) if pending else None,
        )
    except (TypeError, ValueError) as exc:
        raise RuntimeConfigError("config file has an invalid shape") from exc


def save_config(config: RuntimeConfig) -> None:
    path = config_path()
    payload = asdict(config)
    try:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        path.write_text(json.dumps(payload, indent=2) + "\n")
        os.chmod(path, 0o600)
    except OSError as exc:
        raise RuntimeConfigError(f"failed to write config: {exc}") from exc
