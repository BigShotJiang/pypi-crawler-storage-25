"""
Central configuration for PitchBench.

Per-experiment data-generation parameters are namespaced as
``pitchbench_<exp>_VARIABLE`` and live in one of three places:

- ``evaluation_config.py``  — paper-locked benchmark values (default)
- ``analysis_config.py``    — q1 ablation values (loaded by ``pitchbench analyze``)
- a user-supplied file      — custom overrides merged on top of evaluation defaults
                              (passed via ``pitchbench generate --source <path>``)

Use ``apply_user_config(path)`` to merge a custom file over evaluation defaults.
Prompts and parsing logic stay in their experiment scripts — not here.
"""

import importlib.util
import os
import sys as _sys
from pathlib import Path

# ── Runtime / project root ────────────────────────────────────────────────────
_PROJECT_ROOT = Path(os.environ.get("PITCHBENCH_ROOT", ".")).resolve()

DATA_DIR      = _PROJECT_ROOT / "data"
GENERATED_DIR = DATA_DIR / "generated"
ANALYSIS_DIR  = DATA_DIR / "analysis"
RESULTS_DIR   = _PROJECT_ROOT / "results"

# ── Audio infrastructure (engine-level; not data-gen) ─────────────────────────
SAMPLE_RATE  = 16_000
NOTE_ON_DUR  = 1.7
RELEASE_DUR  = 0.5
FADE_OUT     = 0.05
TARGET_PEAK  = 0.9

def _resolve_sf2() -> str:
    if val := os.environ.get("PITCHBENCH_SF2"):
        print(f"Local soundfont from env")
        return val
    soundfonts_dir = DATA_DIR / "soundfonts"
    for ext in ("*.sf2", "*.sf3"):
        found = sorted(soundfonts_dir.glob(ext))
        if found:
            print("Local soundfont: found in data/soundfonts")
            return str(found[0])
    print("Local soundfont: using default /usr/share/sounds/sf2/FluidR3_GM.sf2")
    return "/usr/share/sounds/sf2/FluidR3_GM.sf2"

SF2_PATH: str = _resolve_sf2()

# ── Sources (engine-level catalogues) ─────────────────────────────────────────
GM_PROGRAMS_V1: dict[str, int] = {
    "piano":             0,
    "electric_keyboard": 4,
    "guitar":            24,
    "flute":             73,
    "trumpet":           56,
    "trombone":          57,
    "clarinet":          71,
    "oboe":              68,
    "violin":            40,
    "cello":             42,
    "organ":             19,
    "bass":              32,
    "synth_lead":        80,
    "synth_pad":         88,
    "voice":             52,
}

WAVEFORMS:   list[str] = ["sine", "sawtooth", "square", "triangle"]
ALL_SOURCES: list[str] = list(WAVEFORMS) + list(GM_PROGRAMS_V1.keys())

# ── API endpoints ─────────────────────────────────────────────────────────────
LOCAL_CONCURRENCY: int = int(os.environ.get("LOCAL_CONCURRENCY", "2"))

OPENROUTER_BASE_URL: str = os.environ.get(
    "OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"
)

DASHSCOPE_BASE_URL: str = os.environ.get(
    "DASHSCOPE_BASE_URL", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
)

DOREMI_PARSER_MODEL: str = "openrouter/google/gemini-2.5-flash-lite"
DEFAULT_LOCAL_URL:   str = os.environ.get("PITCHBENCH_LOCAL_URL", "http://localhost:8001")

CONCURRENCY: dict[str, int] = {
    "openrouter": int(os.environ.get("PITCHBENCH_CONCURRENCY_OPENROUTER", "20")),
    "dashscope":  int(os.environ.get("PITCHBENCH_CONCURRENCY_DASHSCOPE",  "10")),
    "manual":     1,
}


def concurrency_for(model_name: str) -> int:
    """Return the configured max-workers cap for ``model_name``."""
    if model_name == "manual":
        return CONCURRENCY["manual"]
    if model_name.startswith("openrouter/"):
        return CONCURRENCY["openrouter"]
    if model_name.startswith("dashscope/"):
        return CONCURRENCY["dashscope"]
    return max(1, LOCAL_CONCURRENCY)


DEFAULT_SAMPLE_SEED = 42

BENCHMARK_TIMESTAMP_TOLERANCE_MS = 250  # used by cat_b.py tolerance checks

# ── Load pitchbench_* and SAMPLING from evaluation_config by default ──────────
# ``pitchbench analyze`` overrides these at runtime via _inject_analysis_config().
import pitchbench.configs.evaluation_config as _eval_params  # noqa: E402
_this = _sys.modules[__name__]
for _n in dir(_eval_params):
    if _n.startswith("pitchbench_") or _n == "SAMPLING":
        setattr(_this, _n, getattr(_eval_params, _n))
del _this, _eval_params, _n

from pitchbench.configs.evaluation_config import SAMPLING  # noqa: E402
EXPERIMENT_DEFAULTS = SAMPLING


def apply_user_config(path: str) -> None:
    """Merge a user config file over the current evaluation defaults.

    The file must follow the same format as evaluation_config.py: plain
    ``pitchbench_<exp>_VAR = <value>`` assignments at module level.
    Variables that are missing from the file or set to ``None`` are left
    unchanged (evaluation defaults remain in effect).
    """
    spec = importlib.util.spec_from_file_location("_pitchbench_custom_config", Path(path).resolve())
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load user config from {path!r}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]

    this = _sys.modules[__name__]
    for name, value in vars(mod).items():
        if name.startswith("pitchbench_") and value is not None:
            setattr(this, name, value)

# ── Legacy aliases ────────────────────────────────────────────────────────────
DEFAULT_PITCHES           = [30, 36, 43, 48, 54, 60, 64, 69, 79, 88]
DEFAULT_DURATION_MS       = 5000
DEFAULT_DURATIONS_MS      = [1000, 5000]
DEFAULT_MIDI_MIN          = 29
DEFAULT_MIDI_MAX          = 89
DEFAULT_SELECTION         = [30, 36, 43, 48, 54, 60, 64, 69, 79, 88]
DEFAULT_TOTAL_DUR_MS      = 60_000
DEFAULT_TONE_POSITIONS_MS = [2_000, 7_000, 14_000, 22_000, 27_000, 41_000, 47_000, 53_000]
DEFAULT_GAP_MS            = 300
DEFAULT_N_TRIALS          = 3
DEFAULT_SEED              = 100
