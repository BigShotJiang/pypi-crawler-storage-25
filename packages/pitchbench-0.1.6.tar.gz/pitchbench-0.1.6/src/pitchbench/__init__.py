"""PitchBench — benchmark suite for pitch and acoustic perception in audio language models."""

__version__ = "0.1.0"
