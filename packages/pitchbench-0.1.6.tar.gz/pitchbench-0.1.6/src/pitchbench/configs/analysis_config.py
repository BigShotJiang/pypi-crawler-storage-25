"""
Analysis configuration — q1 ablation values, fully explicit.

Standalone: no imports from the rest of pitchbench.
Contains only the experiments in the q1 preset; experiments not listed here
fall back to evaluation_config.py defaults when loaded by config.py.
"""
from __future__ import annotations
from typing import Any

# ── Shared ablation vars ───────────────────────────────────────────────────────
_SOURCES: list[str] = ["sine", "synth_lead", "cello", "flute", "piano", "voice"]
_PITCHES: list[int] = [29, 38, 47, 56, 65, 74, 83]

# ── Complex effect / condition structures ─────────────────────────────────────
_EFFECTS: dict[str, dict[str, Any]] = {
    "highpass_above_f0": {"type": "highpass",    "cutoff_ratio": 1.5, "order": 6},
    "lowpass_at_f0":     {"type": "lowpass",     "cutoff_ratio": 1.2, "order": 6},
    "bitcrush_4bit":     {"type": "bitcrush",    "bit_depth": 4},
    "distortion_heavy":  {"type": "saturation",  "drive_db": 30.0},
    "reverb_long":       {"type": "reverb_room", "room_size": 0.9, "damping": 0.4,
                          "wet_level": 0.6, "dry_level": 0.4},
    "chorus_heavy":      {"type": "chorus",      "rate_hz": 1.2, "depth": 0.9, "mix": 0.6},
}
_SATURATIONS: dict[str, dict[str, Any]] = {
    "sat_light":  {"type": "saturation", "drive_db":  6.0},
    "sat_medium": {"type": "saturation", "drive_db": 15.0},
    "sat_heavy":  {"type": "saturation", "drive_db": 30.0},
}
_CONDITIONS: list[dict[str, Any]] = [
    {"name": "resample_0.5x", "mode": "resample", "factor": 0.5},
    {"name": "resample_2x",   "mode": "resample", "factor": 2.0},
    {"name": "stretch_0.5x",  "mode": "stretch",  "factor": 0.5},
    {"name": "stretch_2x",    "mode": "stretch",  "factor": 2.0},
]

# ── PRESETS — experiment list for run.py ───────────────────────────────────────
ACTIVE_PRESET = "q1"

PRESETS: dict[str, dict[str, Any]] = {
    "q1": {
        "notation_formats": ["midi"],
        "experiments": [
            "pitchbench_a1_single_pitch_id",
            "pitchbench_y1_single_pitch_id_mcq",
            "pitchbench_a2_single_pitch_by_loudness",
            "pitchbench_a3_single_pitch_by_duration",
            "pitchbench_b1_single_pitch_within_silence",
            "pitchbench_b2_pitch_at_timestamp",
            "pitchbench_d7a_pitch_with_reference",
            "pitchbench_d7b_pitch_with_reference_split",
            "pitchbench_d7c_pitch_with_reference",
            "pitchbench_d7d_pitch_with_reference_split",
            "pitchbench_e1_audio_effects",
            "pitchbench_e2_background",
            "pitchbench_e3_harmonic_saturation",
            "pitchbench_e4_time_stretching",
            "pitchbench_e6_slightly_off",
        ],
    },
}

# ── SAMPLING (analysis mode — per_stratum=None, one varying axis per experiment)
SAMPLING: dict[str, dict[str, Any]] = {
    "pitchbench_a1_single_pitch_id":             {"per_stratum": None, "strata": ("midi",)},
    "pitchbench_y1_single_pitch_id_mcq":         {"per_stratum": None, "strata": ("semitone_step",)},
    "pitchbench_a2_single_pitch_by_loudness":    {"per_stratum": None, "strata": ("loudness_db",)},
    "pitchbench_a3_single_pitch_by_duration":    {"per_stratum": None, "strata": ("duration_ms",)},
    "pitchbench_b1_single_pitch_within_silence": {"per_stratum": None, "strata": ("pos_ms", "condition")},
    "pitchbench_b2_pitch_at_timestamp":          {"per_stratum": None, "strata": ("n_notes",)},
    "pitchbench_d7a_pitch_with_reference":       {"per_stratum": None, "strata": ("interval",)},
    "pitchbench_d7b_pitch_with_reference_split": {"per_stratum": None, "strata": ("interval",)},
    "pitchbench_d7c_pitch_with_reference":       {"per_stratum": None, "strata": ("midi",)},
    "pitchbench_d7d_pitch_with_reference_split": {"per_stratum": None, "strata": ("midi",)},
    "pitchbench_e1_audio_effects":               {"per_stratum": None, "strata": ("effect_type",)},
    "pitchbench_e2_background":                  {"per_stratum": None, "strata": ("background",)},
    "pitchbench_e3_harmonic_saturation":         {"per_stratum": None, "strata": ("saturation_level",)},
    "pitchbench_e4_time_stretching":             {"per_stratum": None, "strata": ("condition",)},
    "pitchbench_e6_slightly_off":                {"per_stratum": None, "strata": ("detune_hz",)},
}

# ═══════════════════════════════════════════════════════════════════════════════
# pitchbench_* variables — q1 experiments only, in order
# ═══════════════════════════════════════════════════════════════════════════════

pitchbench_general_NOTATION_FORMATS = ["midi"]

# ── a1: single pitch identification ───────────────────────────────────────────
pitchbench_a1_PITCHES          = _PITCHES
pitchbench_a1_TONE_DURATION_MS = 5000
pitchbench_a1_SOURCES          = _SOURCES

# ── y1: single pitch id (multiple-choice) ─────────────────────────────────────
pitchbench_y1_PITCHES          = _PITCHES
pitchbench_y1_TONE_DURATION_MS = 5000
pitchbench_y1_SOURCES          = _SOURCES
pitchbench_y1_N_OPTIONS        = 5
pitchbench_y1_OPTION_STEP_ST   = [2, 4, 6]
pitchbench_y1_SEED             = 100

# ── a2: single pitch by loudness ──────────────────────────────────────────────
pitchbench_a2_LOUDNESS_DB = [-30, -20, -12, 6, 12]
pitchbench_a2_TONE_MS     = 5000
pitchbench_a2_PITCHES     = _PITCHES
pitchbench_a2_SOURCES     = _SOURCES

# ── a3: single pitch by duration ──────────────────────────────────────────────
pitchbench_a3_PITCHES      = _PITCHES
pitchbench_a3_DURATIONS_MS = [50, 250, 1000, 4000, 15000, 60000]
pitchbench_a3_SOURCES      = _SOURCES

# ── b1: single pitch within silence ───────────────────────────────────────────
pitchbench_b1_PITCHES           = _PITCHES
pitchbench_b1_TONE_POSITIONS_MS = [10_000, 30_000, 50_000]
pitchbench_b1_TONE_DURATION_MS  = 5000
pitchbench_b1_TOTAL_SILENCE_MS  = 60_000
pitchbench_b1_SOURCES           = _SOURCES

# ── b2: pitch at timestamp ────────────────────────────────────────────────────
pitchbench_b2_N_NOTES_OPTS = [5, 10]
pitchbench_b2_TOTAL_DUR_MS = 60_000
pitchbench_b2_GAP_MIN_MS   = 30
pitchbench_b2_GAP_MAX_MS   = 1500
pitchbench_b2_MAIN_PITCHES = _PITCHES
pitchbench_b2_DURATIONS_MS = [5000]
pitchbench_b2_SEED         = 100
pitchbench_b2_SOURCES      = _SOURCES
pitchbench_b2_DISTRACTORS  = list(range(29, 90))

# ── d7 / d7a / d7b: pitch with reference (interval-based) ────────────────────
pitchbench_d7_REFERENCE_PITCHES = [69, 53]
pitchbench_d7_INTERVALS         = [-12, -7, -5, -4, -3, -1, 0, 1, 3, 4, 5, 7, 12]
pitchbench_d7_TONE_DURATION_MS  = 5000
pitchbench_d7_GAP_MS            = 500
pitchbench_d7_SOURCES           = _SOURCES

# ── d7c / d7d: pitch with reference (explicit pitch list) ─────────────────────
pitchbench_d7c_REFERENCE_PITCHES = [69, 53]
pitchbench_d7c_PITCHES           = _PITCHES
pitchbench_d7c_TONE_DURATION_MS  = 5000
pitchbench_d7c_GAP_MS            = 500
pitchbench_d7c_SOURCES           = _SOURCES

pitchbench_d7d_REFERENCE_PITCHES = [69, 53]
pitchbench_d7d_PITCHES           = _PITCHES
pitchbench_d7d_TONE_DURATION_MS  = 5000
pitchbench_d7d_SOURCES           = _SOURCES

# ── e1: audio effects ─────────────────────────────────────────────────────────
pitchbench_e1_PITCHES = _PITCHES
pitchbench_e1_TONE_MS = 5000
pitchbench_e1_EFFECTS = _EFFECTS
pitchbench_e1_SOURCES = _SOURCES

# ── e2: background noise ──────────────────────────────────────────────────────
pitchbench_e2_BACKGROUNDS  = ["white_noise", "church-bells", "crowd-noise",
                               "rain", "street-noise", "oscillating-high-and-low-pitches"]
pitchbench_e2_SNR_DB       = [-6.0]
pitchbench_e2_PITCHES      = _PITCHES
pitchbench_e2_DURATIONS_MS = [5000]
pitchbench_e2_SOURCES      = _SOURCES

# ── e3: harmonic saturation ───────────────────────────────────────────────────
pitchbench_e3_PITCHES     = _PITCHES
pitchbench_e3_TONE_MS     = 5000
pitchbench_e3_SATURATIONS = _SATURATIONS
pitchbench_e3_SOURCES     = _SOURCES

# ── e4: time stretching ───────────────────────────────────────────────────────
pitchbench_e4_PITCHES    = [36, 43, 48, 54, 58, 60, 64, 67, 69, 72, 77, 84]
pitchbench_e4_TONE_MS    = 3000
pitchbench_e4_CONDITIONS = _CONDITIONS
pitchbench_e4_SOURCES    = _SOURCES

# ── e6: slightly off ──────────────────────────────────────────────────────────
pitchbench_e6_N_DETUNE_LEVELS = 6
pitchbench_e6_DETUNE_FRACTION = 0.45
pitchbench_e6_PITCHES         = _PITCHES
pitchbench_e6_DURATIONS_MS    = [5000]
pitchbench_e6_SOURCES         = _SOURCES
