MODEL_SHORT_NAMES: dict[str, str] = {
    "audio_flamingo_next_instruct": "Audio Flamingo Next Instruct",
    "openrouter_google_gemini_3_1_pro_preview": "Gemini 3.1 Pro",
    "openrouter_openai_gpt_4o_audio_preview": "GPT-4o Audio",
    "dashscope_qwen3_5_omni_flash": "Qwen 3.5 Omni Flash",
    "dashscope_qwen3_5_omni_plus": "Qwen 3.5 Omni Plus",
    "openrouter_google_gemini_flash_latest": "Gemini Flash",
}

MODEL_COLORS: dict[str, str] = {
    "audio_flamingo_next_instruct": "#2ECC71",                # green        (Flamingo)
    "openrouter_google_gemini_3_1_pro_preview": "#E67E22",    # orange       (Gemini Pro)
    "openrouter_openai_gpt_4o_audio_preview": "#3498DB",      # blue         (GPT-4o Audio)
    "openrouter_google_gemini_flash_latest": "#F1A62D",              # amber        (Gemini Flash)
    "dashscope_qwen3_5_omni_flash": "#F55C4B",                # red          (Qwen Omni Flash)
    "dashscope_qwen3_5_omni_plus": "#C0392B",                 # dark red     (Qwen Omni Plus)
}