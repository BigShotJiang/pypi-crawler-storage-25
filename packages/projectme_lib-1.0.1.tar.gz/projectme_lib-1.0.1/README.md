# ProjectME-lib | v1.0.1

> **A modern, fast and simple alternative to** `cookiecutter` **for generating project templates.**

![Python](https://img.shields.io/badge/python-3.11%2B-blue.svg)
![CLI](https://img.shields.io/badge/interface-Click-green.svg)
![License](https://img.shields.io/github/license/tutu-firmino/ProjectME-lib)
![PyPI version](https://badge.fury.io/py/projectme-lib.svg)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Linux%20%7C%20macOS-0078D6?logo=windows&logoColor=white)
![Downloads](https://img.shields.io/pypi/dm/projectme-lib.svg)

---

View it on [GitHub](https://github.com/tutu-firmino/ProjectME-lib)! | View it on [PyPI](https://pypi.org/project/projectme-lib/)!

---

## What is ProjectME?

ProjectME is a modern project scaffolding CLI designed to replace old, slow, complicated, verbose tools like `cookiecutter`.

It helps you generate ready-to-use project structures in seconds using a simple CLI or a `.projectme` configuration file.

### Core ideas:

-  Fast project generation
-  Simple and readable CLI
-  Config-driven workflow (`.projectme` TOML)
-  Modern templates out of the box
-  Developer experience first

Example:

```bash
projectme create my-app react --tailwind
```

---

## Why ProjectME?

**If you've used cookiecutter before, you probably ran into a few common pain points:**

- Too many prompts before you can start coding — `cookiecutter` asks for lots of input values up front, which can slow you down.

- Hard to iterate quickly — templates are generated once and updating them later (e.g., to incorporate template changes) can lead to conflicts or confusion.

- Verbose configuration for simple use cases — you often end up defining a large JSON config just to tweak basic settings.

- Opinionated and sometimes over-engineered — templates may include boilerplate you don’t want or need, making them feel heavy for small projects.

**ProjectME solves that by focusing on simplicity and developer velocity:**

- Minimal CLI arguments — fewer prompts and less friction to create a project

- Fast execution — generate templates quickly without unnecessary steps

- Sensible defaults — Vite included by default for web projects

- Optional `.projectme` config files — customize only when you want to

- Clean project structure — minimal boilerplate, easy to understand

---

## Installation

```bash
pip install projectme-lib
```

Then:

```bash
projectme --help
```

---

## Quick Start

**Just some quick examples. [More documentation at my repo](https://github.com/tutu-firmino/ProjectME-lib/blob/master/DOCUMENTATION.md).**

### Create a project instantly

```bash
projectme create my-app react
```

### With optional features

```bash
projectme create my-app react --tailwind --typescript --eslint
```

- Note: Vite is used by default for React projects.

---

## Configuration file (`.projectme`)

ProjectME supports TOML-based configuration files.

```toml
name = "my-app"
template = "react"
toolchain = "vite"
package_manager = "pnpm"

[options]
tailwind = true
typescript = true
eslint = true
prettier = true
```

Run:

```bash
projectme load
```

---

## Inspect configuration

```bash
projectme load --config .projectme
```

---

## Available Templates

- `react` — React + Vite starter
- `cli` — Python CLI boilerplate
- `nodejs` — Node.js project structure
- `pyproject` — Python project layout
- `fullstack` — frontend + backend starter
- `static-site` — simple static website

---

## Changelog

- **v1.0.0**: Stabilized project; added support for Linux/macOS; added features; expanded general support

- **v1.0.1** (current): Improved README.md

---

## Roadmap

- More default templates
- Extra customization options
- Plugin system for custom templates
- Template marketplace / registry
- Next.js & FastAPI presets
- Interactive TUI mode
- [GUI version](https://github.com/tutu-firmino/ProjectME)

---

## License

This project is licensed under the [MPL 2.0](https://github.com/tutu-firmino/ProjectME-lib/blob/master/LICENSE).