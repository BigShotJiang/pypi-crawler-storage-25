from functools import lru_cache
from importlib import import_module
import click

class LazyGroup(click.Group):
    def __init__(self, *args, lazy_commands=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._lazy_commands = dict(lazy_commands or {})

    def list_commands(self, ctx):
        return sorted((*super().list_commands(ctx), *self._lazy_commands))

    def get_command(self, ctx, cmd_name):
        command = super().get_command(ctx, cmd_name)
        if command is not None:
            return command

        import_path = self._lazy_commands.get(cmd_name)
        if import_path is None:
            return None

        return _load_command(import_path)

@lru_cache(maxsize=None)
def _load_command(import_path):
    module_name, command_name = import_path.rsplit(":", 1)
    module = import_module(module_name)
    return getattr(module, command_name)

@click.command(
    cls=LazyGroup,
    lazy_commands={
        "create": "src.core.cli.click:create",
        "load": "src.core.cli.click:load",
    },
)
def cli_main():
    return None

if __name__ == "__main__":
    cli_main()