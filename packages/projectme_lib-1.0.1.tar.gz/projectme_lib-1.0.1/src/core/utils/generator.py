from functools import lru_cache
import platform
import re
import shutil
import pathutilx as p

TEMPLATES_ROOT = p.resolve("../../templates", base=__file__)
TEXT_FILE_EXTENSIONS = frozenset(
    {
        ".txt",
        ".md",
        ".json",
        ".toml",
        ".yaml",
        ".yml",
        ".py",
        ".js",
        ".mjs",
        ".cjs",
        ".ts",
        ".tsx",
        ".jsx",
        ".html",
        ".css",
        ".scss",
        ".env",
        ".sh",
        ".zsh",
        ".bash",
        ".ps1",
        ".bat",
        ".cmd",
        ".xml",
    }
)
PLACEHOLDER_PATTERN = re.compile(r"\{\{([A-Za-z_][A-Za-z0-9_]*)\}\}")
PLATFORM_CONFIG = {
    "platform": platform.system().lower(),
    "platform_system": platform.system(),
    "platform_release": platform.release(),
}

@lru_cache(maxsize=1)
def list_supported_templates():
    if not TEMPLATES_ROOT.exists():
        return []

    templates = []
    for child in TEMPLATES_ROOT.iterdir():
        project_dir = child / "project"
        if child.is_dir() and project_dir.exists() and project_dir.is_dir():
            templates.append(child.name)
    return sorted(templates)

@lru_cache(maxsize=1)
def _template_directory_map():
    return {template_name: TEMPLATES_ROOT / template_name / "project" for template_name in list_supported_templates()}

def resolve_template_dir(template_name: str):
    template_dir = _template_directory_map().get(template_name)
    if template_dir is None:
        supported_templates = sorted(_template_directory_map())
        raise ValueError(f"Unsupported template '{template_name}'. Supported values: {sorted(supported_templates)}")

    if not template_dir.exists() or not template_dir.is_dir():
        raise FileNotFoundError(f"Template directory not found: {template_dir}")
    return template_dir

def _render_file(file_path, config):
    if not file_path.is_file():
        return

    if file_path.suffix.lower() not in TEXT_FILE_EXTENSIONS:
        return

    try:
        text = file_path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return

    if "{{" not in text:
        return

    updated = PLACEHOLDER_PATTERN.sub(
        lambda match: config.get(match.group(1), match.group(0)),
        text,
    )

    if updated != text:
        file_path.write_text(updated, encoding="utf-8")

def _render_directory(target_dir, config):
    replacements = {
        key: "" if value is None else str(value)
        for key, value in config.items()
        if not isinstance(value, dict)
    }
    for file_path in target_dir.rglob("*"):
        if file_path.is_file():
            _render_file(file_path, replacements)

def generate_project(config, force = False):
    if not isinstance(config, dict):
        raise TypeError("Project configuration must be a dictionary")

    project_name = config.get("name")
    template_name = config.get("template")
    if not project_name:
        raise ValueError("Project configuration must include 'name'")
    if not template_name:
        raise ValueError("Project configuration must include 'template'")

    merged_config = {**PLATFORM_CONFIG, **config}

    template_dir = resolve_template_dir(template_name)

    output_dir = config.get("output_dir")
    current_dir = p.cwd()
    root_destination = current_dir if output_dir is None else p.resolve(output_dir, base=current_dir)
    destination = root_destination / project_name

    if destination.exists() and not force:
        raise FileExistsError(f"Destination already exists: {destination}")

    shutil.copytree(template_dir, destination, dirs_exist_ok=force)
    _render_directory(destination, merged_config)

    return destination