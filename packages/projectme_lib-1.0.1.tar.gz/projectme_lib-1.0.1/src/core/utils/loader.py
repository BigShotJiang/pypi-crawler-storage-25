from functools import lru_cache
import tomllib
import pathutilx as p
from . import generator

SCHEMA_PATH = p.resolve("schema.toml", base=__file__)

def search():
    current = p.cwd()
    for folder in (current, *current.parents):
        candidate = folder / ".projectme"
        if candidate.exists():
            for parent in folder.parents:
                if (parent / ".projectme").exists():
                    raise FileExistsError("multiple .projectme files found")
            return candidate

    raise FileNotFoundError("no .projectme file found")

def load_raw(config_path = None):
    if config_path is None:
        config_path = search()
    with open(config_path, "r", encoding="utf-8") as f:
        return _parse_raw_config(f.read())


def _parse_toml(config_text):
    return tomllib.loads(config_text)

def _boolean_value(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    if isinstance(value, int):
        return value != 0
    return False

@lru_cache(maxsize=1)
def _load_schema():
    if not SCHEMA_PATH.exists():
        raise FileNotFoundError(f"ProjectME schema file not found: {SCHEMA_PATH}")
    with SCHEMA_PATH.open("rb") as f:
        schema = tomllib.load(f)
    if not isinstance(schema, dict):
        raise ValueError("ProjectME schema must be a TOML mapping")
    return schema

@lru_cache(maxsize=1)
def _template_values():
    return tuple(generator.list_supported_templates())

def _field_value(raw_config, field_def):
    name = field_def["name"]
    aliases = field_def.get("aliases", [])
    value = raw_config.get(name)
    if value is None:
        for alias in aliases:
            if alias in raw_config:
                value = raw_config[alias]
                break
    return value

def _coerce_field(value, field_def):
    if value is None:
        return None
    field_type = field_def.get("type")
    if field_type == "string":
        return str(value)
    if field_type == "boolean":
        return _boolean_value(value)
    if field_type == "enum":
        value = str(value).strip()
        allowed = field_def.get("values", [])
        if allowed and value not in allowed:
            raise ValueError(f"Invalid value for {field_def['name']}: {value}. Allowed: {allowed}")
        return value
    return value

def _validate_schema_fields(raw_config, field_defs, option_defs):
    allowed_keys = set(field_defs) | set(option_defs) | {"options"}
    unknown_keys = [key for key in raw_config if key not in allowed_keys]
    if unknown_keys:
        raise ValueError(f"Unknown .projectme fields: {sorted(unknown_keys)}")

    options_section = raw_config.get("options", {}) or {}
    if not isinstance(options_section, dict):
        raise TypeError("'options' must be a mapping/dictionary")

    unknown_options = [key for key in options_section if key not in option_defs]
    if unknown_options:
        raise ValueError(f"Unknown .projectme options: {sorted(unknown_options)}")

def _parse_raw_config(config_text):
    text = config_text.strip()
    if not text:
        raise ValueError(".projectme file is empty")

    try:
        raw_config = _parse_toml(config_text)
    except Exception as exc:
        raise ValueError("Unable to parse .projectme config. Supported format is TOML.") from exc

    if not isinstance(raw_config, dict):
        raise ValueError("parsed .projectme config must be a mapping/dictionary")

    return raw_config

def _normalize(raw_config):
    if not isinstance(raw_config, dict):
        raise TypeError(".projectme configuration must be a mapping/dictionary")

    schema = _load_schema()
    field_defs = {name: {**field_def, "name": name} for name, field_def in schema.get("fields", {}).items()}
    option_defs = {opt["name"]: {**opt, "name": opt["name"]} for opt in schema.get("options", [])}

    template_def = field_defs.get("template")
    if template_def is not None:
        template_def["values"] = _template_values()

    _validate_schema_fields(raw_config, field_defs, option_defs)

    normalized = {}
    options_section = raw_config.get("options", {}) or {}
    if not isinstance(options_section, dict):
        raise TypeError("'options' must be a mapping/dictionary")

    for name, field_def in field_defs.items():
        value = _field_value(raw_config, field_def)
        if value is None:
            value = field_def.get("default")
        if value is None and field_def.get("required", False):
            raise ValueError(f"Missing required field '{name}' in .projectme config")
        normalized[name] = _coerce_field(value, field_def)

    option_values = {}
    for name, option_def in option_defs.items():
        value = options_section.get(name)
        if value is None:
            value = raw_config.get(name, option_def.get("default", False))
        option_values[name] = _coerce_field(value, option_def)

    if option_values.get("cra"):
        normalized["toolchain"] = "cra"

    normalized["options"] = option_values
    normalized["flags"] = {name: bool(value) for name, value in option_values.items()}

    return normalized

def interpret(config):
    raw_config = _parse_raw_config(config)
    return _normalize(raw_config)

def interpret_dict(raw_config):
    return _normalize(raw_config.copy())

def load():
    raw_config = load_raw()
    return interpret_dict(raw_config)