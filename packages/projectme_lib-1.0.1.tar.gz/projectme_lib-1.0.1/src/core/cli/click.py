import click
from ..utils import generator, loader

TOOLCHAIN_CHOICES = ["vite", "cra"]
PACKAGE_MANAGER_CHOICES = ["npm", "yarn", "pnpm"]

class TemplateChoice(click.ParamType):
    name = "template"

    def shell_complete(self, incomplete):
        return [
            click.shell_completion.CompletionItem(template)
            for template in generator.list_supported_templates()
            if template.startswith(incomplete)
        ]

    def convert(self, value, param, ctx):
        supported_templates = generator.list_supported_templates()
        if value in supported_templates:
            return value
        self.fail(
            f"{value!r} is not one of {', '.join(supported_templates)}",
            param,
            ctx,
        )

TEMPLATE_CHOICE = TemplateChoice()

def _build_raw_config(
    name,
    template,
    toolchain,
    package_manager,
    output_dir,
    description,
    tailwind,
    cra,
    typescript,
    eslint,
    prettier,
    storybook,
):
    raw_config = {}
    if name:
        raw_config["name"] = name
    if template:
        raw_config["template"] = template
    if toolchain:
        raw_config["toolchain"] = toolchain
    if package_manager:
        raw_config["package_manager"] = package_manager
    if output_dir:
        raw_config["output_dir"] = output_dir
    if description:
        raw_config["description"] = description

    options = {}
    if tailwind:
        options["tailwind"] = True
    if cra:
        options["cra"] = True
    if typescript:
        options["typescript"] = True
    if eslint:
        options["eslint"] = True
    if prettier:
        options["prettier"] = True
    if storybook:
        options["storybook"] = True
    if options:
        raw_config["options"] = options

    return raw_config

@click.command()
@click.option("--config", type=click.Path(exists=True, dir_okay=False), help="Path to a .projectme file")
@click.option("--name", help="Project name")
@click.option("--template", type=TEMPLATE_CHOICE, help="Template or stack name")
@click.option("--toolchain", type=click.Choice(TOOLCHAIN_CHOICES), help="Toolchain to use")
@click.option(
    "--package-manager",
    type=click.Choice(PACKAGE_MANAGER_CHOICES),
    help="Package manager to use",
)
@click.option("--output-dir", type=click.Path(file_okay=False), default=None, help="Destination directory for the generated project")
@click.option("--description", help="Project description")
@click.option("--tailwind", is_flag=True)
@click.option("--cra", is_flag=True)
@click.option("--typescript", is_flag=True)
@click.option("--eslint", is_flag=True)
@click.option("--prettier", is_flag=True)
@click.option("--storybook", is_flag=True)
@click.option("--force", is_flag=True, help="Overwrite existing output directory if it already exists")
def create(
    config,
    name,
    template,
    toolchain,
    package_manager,
    output_dir,
    description,
    tailwind,
    cra,
    typescript,
    eslint,
    prettier,
    storybook,
    force,
):
    raw_config = {}
    if config:
        raw_config = loader.load_raw(config)
    else:
        try:
            raw_config = loader.load_raw()
        except FileNotFoundError:
            raw_config = {}

    raw_config.update(
        _build_raw_config(
            name,
            template,
            toolchain,
            package_manager,
            output_dir,
            description,
            tailwind,
            cra,
            typescript,
            eslint,
            prettier,
            storybook,
        )
    )

    config_data = loader.interpret_dict(raw_config)
    destination_path = generator.generate_project(config_data, force=force)

    click.echo(f"Created project at {destination_path}")

@click.command()
@click.option("--config", type=click.Path(exists=True, dir_okay=False), help="Path to a .projectme file")
def load(config):
    click.echo("Searching for .projectme file...")
    if config:
        raw_config = loader.load_raw(config)
        config_data = loader.interpret_dict(raw_config)
    else:
        config_data = loader.load()

    click.echo("Interpreted .projectme config:")
    click.echo(config_data)