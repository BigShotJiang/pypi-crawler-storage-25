# {{name}}

{{description}}

Static site starter generated on `{{platform_system}}`.
