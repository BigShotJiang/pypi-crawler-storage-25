def hello():
    print("Hello, World!")
    input()