import subfolder.file as f

f.hello()