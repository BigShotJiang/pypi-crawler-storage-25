def main():
    print("{{name}} is running on {{platform_system}} {{platform_release}}")


if __name__ == "__main__":
    main()
