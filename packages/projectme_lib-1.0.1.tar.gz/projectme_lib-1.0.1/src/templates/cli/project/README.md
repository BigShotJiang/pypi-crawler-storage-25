# {{name}}

{{description}}

Small cross-platform Python CLI starter generated for `{{platform_system}}`.

## Run

```bash
python main.py
```
