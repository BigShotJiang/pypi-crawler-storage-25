export default function App() {
  return (
    <div className="container">
      <h1>ProjectME Template</h1>
      <p>Hello, World!</p>
    </div>
  )
}