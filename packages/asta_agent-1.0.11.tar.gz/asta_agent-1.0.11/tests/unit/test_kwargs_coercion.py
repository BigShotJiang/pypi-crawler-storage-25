"""Tests for ``_coerce_to_annotation`` and ``_build_kwargs`` Pydantic coercion.

Repro for the bug where JSON-deserialized dicts were passed through to task
handlers whose signatures declared Pydantic ``BaseModel`` subclasses, causing
``AttributeError: 'dict' object has no attribute 'model_dump'`` deep inside
the handler.
"""

from __future__ import annotations

from typing import Annotated, Optional

import pytest
from pydantic import BaseModel, Field

from asta_agent.executor import AstaAgentExecutor, _coerce_to_annotation
from asta_agent.registry import _Param, TaskDef


class PaperEntry(BaseModel):
    corpus_id: str | None = None
    paper_markdown: str | None = None


class PaperStore(BaseModel):
    paperstore: dict[str, PaperEntry] = Field(default_factory=dict)


PaperStoreInput = Annotated[
    Optional[PaperStore],
    Field(description="Optional pre-collected paper store", default=None),
]


def test_coerce_dict_to_pydantic_model():
    out = _coerce_to_annotation({"paperstore": {"abc": {"corpus_id": "abc"}}}, PaperStore)
    assert isinstance(out, PaperStore)
    assert out.paperstore["abc"].corpus_id == "abc"


def test_coerce_dict_via_annotated_optional():
    """The real-world shape used by theorizer (Annotated[Optional[Model], Field])."""
    out = _coerce_to_annotation({"paperstore": {}}, PaperStoreInput)
    assert isinstance(out, PaperStore)


def test_coerce_passes_none_through():
    assert _coerce_to_annotation(None, PaperStoreInput) is None


def test_coerce_passes_instances_through():
    obj = PaperStore(paperstore={})
    assert _coerce_to_annotation(obj, PaperStore) is obj


def test_coerce_passes_primitives_through():
    assert _coerce_to_annotation(42, int) == 42
    assert _coerce_to_annotation("x", str) == "x"
    assert _coerce_to_annotation({"a": 1}, dict) == {"a": 1}


def test_coerce_passes_unannotated_through():
    # annotation=None (no hint registered) → identity
    payload = {"some": "dict"}
    assert _coerce_to_annotation(payload, None) is payload


def test_build_kwargs_coerces_pydantic_param():
    """The integration: _build_kwargs should hand the handler a Pydantic instance."""

    def handler(paper_store: PaperStoreInput) -> None:
        pass

    task_def = TaskDef(
        name="t",
        fn=handler,
        params=[_Param(name="paper_store", required=False, annotation=PaperStoreInput)],
    )
    # Use a fresh executor instance just to access _build_kwargs.
    exe = AstaAgentExecutor.__new__(AstaAgentExecutor)
    kwargs = exe._build_kwargs(task_def, {"paper_store": {"paperstore": {}}})
    assert isinstance(kwargs["paper_store"], PaperStore)


def test_build_kwargs_skips_missing_keys():
    def handler(x: PaperStoreInput) -> None:
        pass

    task_def = TaskDef(
        name="t",
        fn=handler,
        params=[_Param(name="x", required=False, annotation=PaperStoreInput)],
    )
    exe = AstaAgentExecutor.__new__(AstaAgentExecutor)
    assert exe._build_kwargs(task_def, {}) == {}


def test_extract_params_resolves_string_annotations(tmp_path):
    """Regression: handlers in modules using 'from __future__ import annotations'
    must still get Pydantic-coerced kwargs. ``inspect.Parameter.annotation`` is a
    string in that case; ``extract_params`` should resolve via get_type_hints.
    """
    import textwrap
    handler_module = tmp_path / "handler_mod.py"
    handler_module.write_text(textwrap.dedent('''
        from __future__ import annotations
        from typing import Annotated, Optional
        from pydantic import BaseModel, Field

        class PaperStore(BaseModel):
            paperstore: dict = {}

        PaperStoreInput = Annotated[Optional[PaperStore], Field(default=None)]

        def handler(paper_store: PaperStoreInput = None) -> None:
            assert paper_store is None or isinstance(paper_store, PaperStore), \
                f"expected PaperStore, got {type(paper_store).__name__}"
    '''))
    import importlib.util
    spec = importlib.util.spec_from_file_location("handler_mod", handler_module)
    mod = importlib.util.module_from_spec(spec)
    import sys; sys.modules["handler_mod"] = mod
    spec.loader.exec_module(mod)

    from asta_agent.registry import extract_params
    params, _ = extract_params(mod.handler)
    assert len(params) == 1
    p = params[0]
    # The annotation should be the resolved Annotated[...] not the string
    assert p.annotation is not None
    assert not isinstance(p.annotation, str), f"got string annotation: {p.annotation!r}"

    # And _build_kwargs should produce a real PaperStore
    from asta_agent.executor import AstaAgentExecutor
    from asta_agent.registry import TaskDef
    td = TaskDef(name="t", fn=mod.handler, params=params)
    exe = AstaAgentExecutor.__new__(AstaAgentExecutor)
    kwargs = exe._build_kwargs(td, {"paper_store": {"paperstore": {}}})
    assert isinstance(kwargs["paper_store"], mod.PaperStore)
