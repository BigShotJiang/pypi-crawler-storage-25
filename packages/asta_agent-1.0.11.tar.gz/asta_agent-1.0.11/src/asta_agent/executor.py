"""Bridge between a2a-sdk's AgentExecutor and Asta @task functions."""

from __future__ import annotations

import asyncio
import logging
import types
import uuid
from typing import TYPE_CHECKING, Annotated, Any, Union, get_args, get_origin

from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.types import (
    DataPart,
    Message,
    TaskState,
    TaskStatus,
    TaskStatusUpdateEvent,
    TextPart,
)
from pydantic import BaseModel

from asta_agent.context import AstaContext

if TYPE_CHECKING:
    from a2a.server.tasks import TaskStore

    from asta_agent.registry import TaskDef

logger = logging.getLogger(__name__)


def _coerce_to_annotation(value: Any, annotation: Any) -> Any:
    """Coerce a JSON-deserialized value to its declared parameter annotation
    when the annotation resolves to a Pydantic ``BaseModel`` subclass.

    Handles ``Annotated[T, ...]`` and ``Optional[T]`` / ``T | None`` wrappers
    so that ``Annotated[Optional[MyModel], Field(...)]`` (the idiomatic shape
    for optional Pydantic inputs) is correctly recognised. Non-Pydantic
    annotations, primitives, ``None`` values, and already-correctly-typed
    instances pass through unchanged.
    """
    if annotation is None or value is None:
        return value

    if get_origin(annotation) is Annotated:
        annotation = get_args(annotation)[0]

    if get_origin(annotation) in (Union, types.UnionType):
        non_none = [t for t in get_args(annotation) if t is not type(None)]
        if len(non_none) == 1:
            annotation = non_none[0]

    if isinstance(annotation, type) and issubclass(annotation, BaseModel) and isinstance(value, dict):
        return annotation.model_validate(value)
    return value


class AstaAgentExecutor(AgentExecutor):
    """Routes incoming A2A messages to registered @task functions.

    The execute() method emits a non-final 'submitted' event so that
    message/send returns immediately, then runs the task function in a
    background asyncio.Task. The background task updates the task store
    directly (bypassing the event queue which is no longer consumed after
    the HTTP response is sent).
    """

    def __init__(self, tasks: list[TaskDef], task_store: TaskStore, push_config_store: Any = None):
        self._tasks = tasks
        self._by_id = {td.skill_id: td for td in tasks}
        self._task_store = task_store
        self._push_config_store = push_config_store

    async def execute(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        message = context.message
        if message is None:
            await self._fail(context, event_queue, "No message in request")
            return

        skill_id, input_data = self._extract_request(message)
        task_def = self._route(skill_id, input_data)

        task_id = context.task_id or ""
        context_id = context.context_id or ""

        kwargs = self._build_kwargs(task_def, input_data)

        loop = asyncio.get_running_loop()
        ctx = AstaContext(
            task_id=task_id,
            context_id=context_id,
            task_store=self._task_store,
            loop=loop,
            push_config_store=self._push_config_store,
        )

        if task_def.context_param:
            kwargs[task_def.context_param] = ctx

        # Emit a non-final 'submitted' event so message/send returns
        # immediately with the task in submitted state.
        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                status=TaskStatus(
                    state=TaskState.submitted,
                    message=Message(
                        message_id=str(uuid.uuid4()),
                        role="agent",
                        parts=[TextPart(text="Task accepted")],
                        task_id=task_id,
                        context_id=context_id,
                    ),
                ),
                final=False,
            )
        )

        # Run the task function in the background. It updates the task
        # store directly via AstaContext.
        async def _run_background() -> None:
            try:
                await asyncio.to_thread(task_def.fn, **kwargs)
            except Exception:
                logger.exception("Task %s failed", task_id)
                await ctx.async_fail("Unhandled exception in task handler")
                return

            if not ctx._terminal_sent:
                await ctx.async_complete(None)

        asyncio.create_task(_run_background())

    async def cancel(
        self, context: RequestContext, event_queue: EventQueue
    ) -> None:
        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=context.task_id or "",
                context_id=context.context_id or "",
                status=TaskStatus(state=TaskState.canceled),
                final=True,
            )
        )

    def _extract_request(self, message: Any) -> tuple[str | None, dict]:
        """Extract skill_id and input data from the incoming message."""
        for part in message.parts:
            # a2a-sdk uses a discriminated union: Part(root=DataPart(...))
            inner_part = getattr(part, "root", part)
            if isinstance(inner_part, DataPart):
                data = inner_part.data
                skill = data.get("kind")
                if isinstance(skill, str):
                    inner = data.get("data", {})
                    return skill, inner if isinstance(inner, dict) else {}
                return None, data
        return None, {}

    def _route(self, skill_id: str | None, input_data: dict) -> TaskDef:
        """Resolve which task to run."""
        if skill_id is not None:
            td = self._by_id.get(skill_id)
            if td is not None:
                return td
            # Fall back to single task if only one is registered
            if len(self._tasks) == 1:
                logger.info(
                    "Skill %r not found, falling back to sole task %r",
                    skill_id,
                    self._tasks[0].skill_id,
                )
                return self._tasks[0]
            raise ValueError(
                f"Unknown skill: {skill_id!r}. "
                f"Available: {list(self._by_id.keys())}"
            )

        if len(self._tasks) == 1:
            return self._tasks[0]

        for td in self._tasks:
            required = [p for p in td.params if p.required]
            if all(p.name in input_data for p in required):
                return td

        raise ValueError(
            f"No task matches input keys: {list(input_data.keys())}"
        )

    def _build_kwargs(self, task_def: TaskDef, input_data: dict) -> dict:
        """Map input_data to function keyword arguments, coercing JSON dicts
        into the declared Pydantic ``BaseModel`` types where parameter
        annotations specify them. See ``_coerce_to_annotation`` for the rules.
        """
        kwargs: dict[str, Any] = {}
        for p in task_def.params:
            if p.name in input_data:
                kwargs[p.name] = _coerce_to_annotation(input_data[p.name], p.annotation)
        return kwargs

    async def _fail(
        self,
        context: RequestContext,
        event_queue: EventQueue,
        error: str,
    ) -> None:
        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=context.task_id or "",
                context_id=context.context_id or "",
                status=TaskStatus(state=TaskState.failed),
                final=True,
            )
        )
