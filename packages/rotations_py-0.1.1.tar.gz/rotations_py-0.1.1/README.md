# rotations-py

A pure-numpy Python library for 3D rotation representations. Convert freely between four representations, compose rotations, and apply them to vectors.

## Representations

| Class | Stores | Use when |
|-------|--------|----------|
| `SO3` | 3×3 rotation matrix | applying rotations, interfacing with linear algebra |
| `Quaternion` | `(w, x, y, z)` unit quaternion | interpolation, game engines, aerospace |
| `AxisAngle` | unit axis + angle (radians) | human-readable construction |
| `Screw` | rotation vector `w = axis · θ` | optimization, robotics, Lie group math |

## Installation

```bash
uv add rotations-py
```

## Usage

```python
import numpy as np
from rotations import SO3, Quaternion, AxisAngle, Screw

# construct
r = AxisAngle([0, 0, 1], np.pi/2)   # 90° around z

# convert between representations
r.to_so3()
r.to_quaternion()
r.to_screw()

# apply to a vector
r @ [1, 0, 0]           # → [0, 1, 0]

# compose two rotations
r1 = AxisAngle([0, 0, 1], np.pi/2)
r2 = AxisAngle([1, 0, 0], np.pi/2)
r3 = r1 @ r2            # result is same type as r1

# inverse
~r                       # AxisAngle for 90° around -z
r @ ~r                   # → identity
```

## Conversion graph

```
SO3  ←→  Quaternion  ←→  AxisAngle  ←→  Screw
```

See [description.md](description.md) for the full math behind each conversion.

## Development

To run tests
```bash
uv run pytest
```

To run the linter and formatter
```bash
uv run ruff check           # check lint
uv run ruff format --check  # check format
uv run ruff check --fix     # lint and auto-fix
uv run ruff format          # format and fix
```

To run the static type checker
```bash
uv run mypy rotations/
```