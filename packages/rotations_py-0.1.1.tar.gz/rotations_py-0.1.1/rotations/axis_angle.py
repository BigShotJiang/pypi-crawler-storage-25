from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from rotations._base import Rotation

if TYPE_CHECKING:
    from rotations.so3 import SO3
    from rotations.quaternion import Quaternion
    from rotations.screw import Screw


class AxisAngle(Rotation):
    def __init__(self, axis: np.ndarray, angle: float) -> None:
        axis = np.asarray(axis, dtype=float)
        if axis.shape != (3,):
            raise ValueError(f"Expected (3,) axis, got {axis.shape}")
        norm = np.linalg.norm(axis)
        if norm < 1e-10:
            raise ValueError("Axis has zero length")
        self._axis = axis / norm
        self._angle = float(angle)

    @classmethod
    def identity(cls) -> AxisAngle:
        return cls(np.array([1.0, 0.0, 0.0]), 0.0)

    # save as property instead of separate attributes to ensure immutability and normalization
    @property
    def axis(self) -> np.ndarray:
        return self._axis

    @property
    def angle(self) -> float:
        return self._angle

    # --- conversions ---

    def to_axis_angle(self) -> AxisAngle:
        return self

    def to_quaternion(self) -> "Quaternion":
        from rotations.quaternion import Quaternion

        return Quaternion(
            np.array(
                [
                    np.cos(self._angle / 2),
                    np.sin(self._angle / 2) * self._axis[0],
                    np.sin(self._angle / 2) * self._axis[1],
                    np.sin(self._angle / 2) * self._axis[2],
                ]
            )
        )

    def to_so3(self) -> "SO3":
        from rotations.so3 import SO3

        n = self._axis
        θ = self._angle
        K = np.array(
            [
                [0, -n[2], n[1]],
                [n[2], 0, -n[0]],
                [-n[1], n[0], 0],
            ]
        )

        # Rodrigues' formula: R = I + sin(θ) K + (1 - cos(θ)) K^2
        R = np.eye(3) + np.sin(θ) * K + (1 - np.cos(θ)) * K @ K
        return SO3(R)

    def to_screw(self) -> "Screw":
        from rotations.screw import Screw

        return Screw(self._axis * self._angle)

    # --- operations ---

    def _from_so3(self, r: "SO3") -> AxisAngle:
        return r.to_axis_angle()

    # --- dunder ---

    def __repr__(self) -> str:
        deg = np.degrees(self._angle)
        return f"axis={self._axis}, angle={deg:.4f}°"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Rotation):
            return NotImplemented

        # convert both to quaternions for comparison,
        # since axis-angle can have multiple representations for the same rotation
        # (e.g. axis flipped and angle negated)
        # (e.g. axis=[0,0,1], angle=90° vs axis=[0,0,-1], angle=-90°)
        q_other = other.to_quaternion()
        q_self = self.to_quaternion()
        return q_self == q_other
