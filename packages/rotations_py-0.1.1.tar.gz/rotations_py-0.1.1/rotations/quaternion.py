from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from rotations._base import Rotation

if TYPE_CHECKING:
    from rotations.so3 import SO3
    from rotations.axis_angle import AxisAngle
    from rotations.screw import Screw


class Quaternion(Rotation):
    def __init__(self, wxyz: np.ndarray) -> None:
        wxyz = np.asarray(wxyz, dtype=float)
        if wxyz.shape != (4,):
            raise ValueError(f"Expected (4,) array, got {wxyz.shape}")
        norm = np.linalg.norm(wxyz)
        if norm < 1e-10:
            raise ValueError("Quaternion has zero norm")
        self._wxyz = wxyz / norm

    @classmethod
    def identity(cls) -> Quaternion:
        return cls(np.array([1.0, 0.0, 0.0, 0.0]))

    # save as property instead of separate attributes to ensure immutability and normalization
    @property
    def w(self) -> float:
        return self._wxyz[0]

    @property
    def x(self) -> float:
        return self._wxyz[1]

    @property
    def y(self) -> float:
        return self._wxyz[2]

    @property
    def z(self) -> float:
        return self._wxyz[3]

    # --- conversions ---

    def to_quaternion(self) -> Quaternion:
        return self

    def to_so3(self) -> "SO3":
        from rotations.so3 import SO3

        w, x, y, z = self.w, self.x, self.y, self.z
        R = np.array(
            [
                [1 - 2 * (y**2 + z**2), 2 * (x * y - w * z), 2 * (x * z + w * y)],
                [2 * (x * y + w * z), 1 - 2 * (x**2 + z**2), 2 * (y * z - w * x)],
                [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x**2 + y**2)],
            ]
        )
        return SO3(R)

    def to_axis_angle(self) -> "AxisAngle":
        from rotations.axis_angle import AxisAngle

        # clamp w to [-1, 1] to guard against floating-point drift past 1
        angle = 2.0 * np.arccos(np.clip(self.w, -1.0, 1.0))
        s = np.sin(angle / 2.0)
        if abs(s) < 1e-10:
            return AxisAngle(np.array([1.0, 0.0, 0.0]), 0.0)
        axis = np.array([self.x, self.y, self.z]) / s
        return AxisAngle(axis, angle)

    def to_screw(self) -> "Screw":
        return self.to_axis_angle().to_screw()

    # --- operations (override base for direct implementations) ---

    def _from_so3(self, r: "SO3") -> Quaternion:
        return r.to_quaternion()

    def compose(self, other: Rotation) -> Quaternion:
        q = other.to_quaternion()
        w1, x1, y1, z1 = self.w, self.x, self.y, self.z
        w2, x2, y2, z2 = q.w, q.x, q.y, q.z
        return Quaternion(
            np.array(
                [
                    w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
                    w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
                    w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
                    w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
                ]
            )
        )

    def inverse(self) -> Quaternion:
        return Quaternion(np.array([self.w, -self.x, -self.y, -self.z]))

    # --- dunder ---

    def __repr__(self) -> str:
        return f"w={self.w:.6f}, x={self.x:.6f}, y={self.y:.6f}, z={self.z:.6f}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Rotation):
            return NotImplemented
        q = other.to_quaternion()
        return np.allclose(self._wxyz, q._wxyz) or np.allclose(self._wxyz, -q._wxyz)
