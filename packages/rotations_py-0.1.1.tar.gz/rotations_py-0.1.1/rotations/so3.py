from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from rotations._base import Rotation

if TYPE_CHECKING:
    from rotations.quaternion import Quaternion
    from rotations.axis_angle import AxisAngle
    from rotations.screw import Screw


class SO3(Rotation):
    def __init__(self, matrix: np.ndarray) -> None:
        # ensure it's a float array for numerical checks, and also to allow lists as input
        matrix = np.asarray(matrix, dtype=float)

        # simple checks to ensure it's a valid rotation matrix
        if matrix.shape != (3, 3):
            raise ValueError(f"Expected (3,3) matrix, got {matrix.shape}")
        if not np.allclose(matrix @ matrix.T, np.eye(3), atol=1e-6):
            raise ValueError("Matrix is not orthogonal (R @ R.T must be I)")
        if not np.isclose(np.linalg.det(matrix), 1.0, atol=1e-6):
            raise ValueError(
                "Matrix determinant must be 1 for it to be a valid rotation"
            )
        self._matrix = matrix

    @classmethod
    def identity(cls) -> SO3:
        return cls(np.eye(3))

    # --- conversions ---

    def to_so3(self) -> SO3:
        return self

    def to_quaternion(self) -> "Quaternion":
        from rotations.quaternion import Quaternion

        R = self._matrix
        trace = R[0, 0] + R[1, 1] + R[2, 2]

        if trace > 0:
            s = 0.5 / np.sqrt(trace + 1.0)
            w = 0.25 / s
            x = (R[2, 1] - R[1, 2]) * s
            y = (R[0, 2] - R[2, 0]) * s
            z = (R[1, 0] - R[0, 1]) * s
        elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
            s = 2.0 * np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
            w = (R[2, 1] - R[1, 2]) / s
            x = 0.25 * s
            y = (R[0, 1] + R[1, 0]) / s
            z = (R[0, 2] + R[2, 0]) / s
        elif R[1, 1] > R[2, 2]:
            s = 2.0 * np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
            w = (R[0, 2] - R[2, 0]) / s
            x = (R[0, 1] + R[1, 0]) / s
            y = 0.25 * s
            z = (R[1, 2] + R[2, 1]) / s
        else:
            s = 2.0 * np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
            w = (R[1, 0] - R[0, 1]) / s
            x = (R[0, 2] + R[2, 0]) / s
            y = (R[1, 2] + R[2, 1]) / s
            z = 0.25 * s

        return Quaternion(np.array([w, x, y, z]))

    def to_axis_angle(self) -> "AxisAngle":
        return self.to_quaternion().to_axis_angle()

    def to_screw(self) -> "Screw":
        return self.to_axis_angle().to_screw()

    # --- operations (override base to avoid redundant SO3 conversion) ---

    def _from_so3(self, r: SO3) -> SO3:
        return r

    def compose(self, other: Rotation) -> SO3:
        return SO3(self._matrix @ other.to_so3()._matrix)

    def inverse(self) -> SO3:
        return SO3(self._matrix.T)

    def apply(self, v: np.ndarray) -> np.ndarray:
        return self._matrix @ np.asarray(v, dtype=float)

    # --- dunder ---

    def __repr__(self) -> str:
        return f"{self._matrix}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Rotation):
            return NotImplemented
        return np.allclose(self._matrix, other.to_so3()._matrix)
