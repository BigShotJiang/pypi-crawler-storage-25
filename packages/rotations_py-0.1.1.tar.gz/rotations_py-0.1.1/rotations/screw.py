from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from rotations._base import Rotation

if TYPE_CHECKING:
    from rotations.so3 import SO3
    from rotations.quaternion import Quaternion
    from rotations.axis_angle import AxisAngle


class Screw(Rotation):
    def __init__(self, w: np.ndarray) -> None:
        w = np.asarray(w, dtype=float)
        if w.shape != (3,):
            raise ValueError(f"Expected (3,) array, got {w.shape}")
        self._w = w

    @classmethod
    def identity(cls) -> Screw:
        return cls(np.zeros(3))

    @property
    def w(self) -> np.ndarray:
        return self._w

    # --- conversions ---

    def to_screw(self) -> Screw:
        return self

    def to_axis_angle(self) -> "AxisAngle":
        from rotations.axis_angle import AxisAngle

        angle = np.linalg.norm(self.w)
        if angle < 1e-10:
            return AxisAngle.identity()
        return AxisAngle(self.w / angle, float(angle))

    def to_quaternion(self) -> "Quaternion":
        return self.to_axis_angle().to_quaternion()

    def to_so3(self) -> "SO3":
        return self.to_axis_angle().to_so3()

    # --- operations ---

    def _from_so3(self, r: "SO3") -> Screw:
        return r.to_screw()

    # --- dunder ---

    def __repr__(self) -> str:
        return f"w={self._w}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Rotation):
            return NotImplemented

        # convert both to quaternions for a more robust equality check
        # (handles numerical issues better than axis-angle or SO(3) matrix)
        quaternion_self = self.to_quaternion()
        quaternion_other = other.to_quaternion()
        return quaternion_self == quaternion_other
