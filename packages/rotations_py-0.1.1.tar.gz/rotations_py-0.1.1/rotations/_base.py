from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from rotations.so3 import SO3
    from rotations.quaternion import Quaternion
    from rotations.axis_angle import AxisAngle
    from rotations.screw import Screw


class Rotation(ABC):
    @abstractmethod
    def to_so3(self) -> "SO3": ...

    @abstractmethod
    def to_quaternion(self) -> "Quaternion": ...

    @abstractmethod
    def to_axis_angle(self) -> "AxisAngle": ...

    @abstractmethod
    def to_screw(self) -> "Screw": ...

    @abstractmethod
    def _from_so3(self, r: "SO3") -> "Rotation": ...

    def compose(self, other: "Rotation") -> "Rotation":
        return self._from_so3(self.to_so3().compose(other))

    def inverse(self) -> "Rotation":
        return self._from_so3(self.to_so3().inverse())

    def apply(self, v: np.ndarray) -> np.ndarray:
        return self.to_so3().apply(v)

    def __mul__(self, other: "Rotation") -> "Rotation":
        return self.compose(other)

    def __invert__(self) -> "Rotation":
        return self.inverse()

    def __matmul__(self, other: "Rotation | np.ndarray") -> "Rotation | np.ndarray":
        if isinstance(other, Rotation):
            return self.compose(other)
        return self.apply(other)
