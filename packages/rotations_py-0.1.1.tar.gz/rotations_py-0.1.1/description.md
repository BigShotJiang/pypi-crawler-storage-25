# Rotation Representations

Every class in this library describes the same thing — a 3D rotation — but stores it differently. Think of them as different languages saying the same sentence. Each has tradeoffs in compactness, numerical stability, and ease of use.

---

## The core idea: what is a rotation?

A rotation in 3D is fully defined by two things: an **axis** (a direction in space) and an **angle** (how far to spin around that axis). All four representations are just different ways to pack that information into numbers.

---

## SO3 — Rotation Matrix

**What it stores:** a 3×3 grid of numbers (9 values total).

This is the most direct form. Each column of the matrix tells you where the x, y, and z axes end up after the rotation. To rotate a point, you just multiply the matrix by the point's coordinates.

```
[1  0   0 ]       rotates nothing (identity)
[0  0  -1 ]   →   rotates 90° around x-axis
[0  1   0 ]
```

**Pros:** applying a rotation is a simple matrix multiply; composing two rotations is matrix multiplication.

**Cons:** 9 numbers to store a rotation that only has 3 degrees of freedom. The extra 6 numbers are redundancy (the orthogonality constraint). Floating-point errors can slowly corrupt the matrix into something that is no longer a valid rotation.

---

## Quaternion

**What it stores:** 4 numbers `(w, x, y, z)`.

A quaternion is a 4D number. For rotations, you always use *unit* quaternions — ones that live on a 4D sphere (w² + x² + y² + z² = 1). The relationship to axis-angle is:

```
w = cos(θ/2)
x = sin(θ/2) · axis_x
y = sin(θ/2) · axis_y
z = sin(θ/2) · axis_z
```

The "half angle" is not a typo — it falls out of the algebra and is the reason quaternions handle rotations correctly without gimbal lock.

**Pros:** compact (4 numbers), numerically stable, easy to interpolate smoothly between two orientations (called SLERP), and fast to compose (one quaternion multiply instead of a 3×3 matrix multiply). Used everywhere in game engines, robotics, and aerospace.

**Cons:** not geometrically intuitive. Also, `q` and `-q` represent the same rotation (the sphere wraps around twice), which can cause sign-flip surprises.

---

## AxisAngle

**What it stores:** a unit vector `axis` (3 numbers) + a scalar `angle` (1 number) = 4 numbers total.

This is the most human-readable form. "Rotate 90 degrees around the z-axis" is exactly what it says.

```
axis  = [0, 0, 1]   (pointing straight up)
angle = π/2         (90 degrees)
```

**Pros:** immediately intuitive. Easy to construct by hand.

**Cons:** applying a rotation directly from axis-angle requires computing Rodrigues' rotation formula on the fly (more work than a matrix multiply). Composing two axis-angle rotations is awkward — you usually convert to matrix or quaternion first.

---

## RodriguesParams / Gibbs vector — not implemented

This form stores `v = axis · tan(θ/2)`. It has a closed-form composition formula and occasionally appears in filtering literature, but it blows up at θ = 180° (because `tan(90°) = ∞`), making it unable to represent all rotations. Screw covers the same "compact 3-vector" use case without that limitation, so this library omits RodriguesParams entirely.

> **Naming note:** OpenCV's `cv2.Rodrigues()` is named after the same mathematician but uses `axis · θ` (Screw), not this form.

---

## Screw (rotation vector / exponential coordinates)

**What it stores:** a single 3-vector `w = axis · θ`.

> **How is this different from AxisAngle?** AxisAngle keeps the axis (a unit vector) and the angle (a scalar) as two separate fields. Screw merges them into one vector by multiplying them together — the direction of `w` is the axis and the length of `w` is the angle. Same information, different packaging. The payoff is that `w` behaves like a plain 3D vector, so you can scale it, add it, and differentiate it, which AxisAngle does not support directly.

Like Rodrigues, this packs axis and angle into 3 numbers — but using `θ` directly instead of `tan(θ/2)`. The direction of `w` is the axis; the magnitude `|w|` is the angle in radians.

```
θ = 30°  →  |w| = π/6  ≈ 0.52
θ = 90°  →  |w| = π/2  ≈ 1.57
θ = 180° →  |w| = π    ≈ 3.14   ← works fine
θ = 360° →  |w| = 2π   ← wraps back to identity
```

This is the **Lie algebra** representation of SO(3). The rotation matrix is recovered via the matrix exponential: `R = exp([w]×)`, where `[w]×` is the skew-symmetric matrix of `w`. The matrix logarithm of `R` gives back `w`.

**Pros:** only 3 numbers, no singularity until a full 360° rotation, linear near the identity (which makes it great for optimization, integration, and machine learning on rotations), and directly generalizes to SE(3) (rigid-body motion with translation).

**Cons:** the matrix exponential formula is slightly more expensive to evaluate than e.g. a quaternion rotation. Also wraps around every 360°, so it cannot distinguish "rotate 0°" from "rotate 360°" — but that distinction rarely matters in practice.

> **Used by:** OpenCV (`cv2.Rodrigues` converts between this and a rotation matrix — despite the name, it is this form, not the Gibbs vector above) and Open3D (`get_rotation_matrix_from_axis_angle`, and the internal representation used by its ICP/registration results).

---

## Side-by-side comparison

| Representation | # values | Singularity      | Intuitive? | Good for               |
|----------------|----------|------------------|------------|------------------------|
| SO3            | 9        | none             | medium     | applying rotations     |
| Quaternion     | 4        | none             | low        | interpolation, games   |
| AxisAngle      | 3+1      | none             | high       | human construction     |
| Screw    | 3        | θ = 360° (wraps) | medium     | optimization, robotics |

---

## How they relate

All roads lead through `AxisAngle`. The axis and angle are the raw ingredients every other form is derived from:

```
AxisAngle  ──→  θ → θ/2 → cos/sin  ──→  Quaternion
AxisAngle  ──→  axis·θ              ──→  Screw
AxisAngle  ──→  Rodrigues' formula  ──→  SO3
```

---

## Conversion math

### AxisAngle → Quaternion

Given axis `n = [nx, ny, nz]` (unit vector) and angle `θ`:

```
w = cos(θ/2)
x = sin(θ/2) · nx
y = sin(θ/2) · ny
z = sin(θ/2) · nz
```

The half-angle comes from how quaternion multiplication works — rotating by `q` twice applies the full angle, so each quaternion only needs to encode half of it.

---

### Quaternion → AxisAngle

```
θ = 2 · arccos(w)
n = (x, y, z) / sin(θ/2)
```

Special case: if `θ ≈ 0` the axis is undefined (any axis works for a zero rotation), so we return a default axis like `[1, 0, 0]`.

---

### AxisAngle → SO3 (Rodrigues' rotation formula)

First build the **skew-symmetric matrix** `K` of the axis `n`:

```
    [ 0   -nz   ny ]
K = [ nz   0   -nx ]
    [-ny   nx    0  ]
```

`K` has the property that `K·v = n × v` (cross product with n) for any vector v. Then:

```
R = I + sin(θ)·K + (1 - cos(θ))·K²
```

You can read this geometrically: `I` keeps the component of a vector along the axis unchanged, `sin(θ)·K` adds the perpendicular rotation, and `(1-cos(θ))·K²` corrects the radial component.

---

### SO3 → Quaternion (Shepperd's method)

The rotation matrix written out in terms of quaternion components is:

```
R = [ 1-2(y²+z²)   2(xy-wz)    2(xz+wy) ]
    [ 2(xy+wz)    1-2(x²+z²)   2(yz-wx) ]
    [ 2(xz-wy)    2(yz+wx)    1-2(x²+y²)]
```

Taking the trace (sum of diagonal):

```
tr(R) = 3 - 4(x²+y²+z²) = 3 - 4(1-w²) = 4w² - 1

→  w = sqrt(tr(R) + 1) / 2
→  x = (R[2,1] - R[1,2]) / (4w)
→  y = (R[0,2] - R[2,0]) / (4w)
→  z = (R[1,0] - R[0,1]) / (4w)
```

The problem: if `w ≈ 0` (rotation near 180°), dividing by `4w` blows up. Shepperd's fix is to always solve for the **largest** of `{w, x, y, z}` first, since the largest one is furthest from zero. The other three are then recovered by dividing by it instead. Four branches, one per largest component.

---

### Screw ↔ AxisAngle

This is just packing/unpacking:

```
Screw → AxisAngle:   θ = |w|,   n = w / |w|
AxisAngle → Screw:   w = n · θ
```

Special case: if `|w| ≈ 0` it's the identity rotation, axis is arbitrary.

---

### Screw → SO3 (matrix exponential)

The rotation vector `w` is the **Lie algebra** element — an element of the tangent space at the identity. The map back to a rotation matrix is the matrix exponential:

```
R = exp([w]×)
```

where `[w]×` is the skew-symmetric matrix of `w` (same shape as `K` above but with the unnormalised `w`). Expanding the matrix exponential series and simplifying gives exactly Rodrigues' formula again, just written in terms of `w` directly:

```
R = I + (sin(θ)/θ)·[w]× + ((1 - cos(θ))/θ²)·[w]×²

where θ = |w|
```

When `θ → 0` both coefficients approach their limits (`sin(θ)/θ → 1`, `(1-cos(θ))/θ² → 1/2`) so there is no singularity.
