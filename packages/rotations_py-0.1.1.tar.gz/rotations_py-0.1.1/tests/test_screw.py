import numpy as np
import pytest
from rotations import Screw


# --- construction ---


def test_identity():
    s = Screw.identity()
    assert np.allclose(s.w, [0, 0, 0])


def test_accepts_list_input():
    Screw([0, 0, 1])


def test_rejects_wrong_shape():
    with pytest.raises(ValueError):
        Screw([0, 0])


# --- apply ---


def test_apply_identity():
    v = [1, 2, 3]
    assert np.allclose(Screw.identity() @ v, v)


def test_apply_90_around_z():
    s = Screw([0, 0, np.pi / 2])
    assert np.allclose(s @ [1, 0, 0], [0, 1, 0], atol=1e-10)


# --- compose and inverse ---


def test_compose_with_inverse_is_identity():
    s = Screw([0, 0, 1.2])
    result = s @ ~s
    assert isinstance(result, Screw)
    assert result == Screw.identity()


def test_compose_returns_screw():
    s1 = Screw([0, 0, 0.5])
    s2 = Screw([0.3, 0, 0])
    assert isinstance(s1 @ s2, Screw)


def test_inverse_undoes_rotation():
    s = Screw([0, 0, np.pi / 2])
    v = [1, 0, 0]
    assert np.allclose(~s @ (s @ v), v, atol=1e-10)


# --- equality ---


def test_full_turn_is_identity():
    s = Screw([0, 0, 2 * np.pi])
    assert s == Screw.identity()


# --- conversions ---


def test_roundtrip_screw_so3_screw():
    s = Screw([0, 0, 1.2])
    assert s == s.to_so3().to_screw()


def test_roundtrip_screw_quaternion_screw():
    s = Screw([0, 0, 1.2])
    assert s == s.to_quaternion().to_screw()


def test_roundtrip_screw_axis_angle_screw():
    s = Screw([0, 0, 1.2])
    assert s == s.to_axis_angle().to_screw()
