import numpy as np
import pytest
from rotations import Quaternion


def quat_z(angle):
    return Quaternion([np.cos(angle / 2), 0, 0, np.sin(angle / 2)])


# --- construction ---


def test_identity():
    q = Quaternion.identity()
    assert np.allclose(q._wxyz, [1, 0, 0, 0])


def test_normalises_on_construction():
    q = Quaternion([2, 0, 0, 0])
    assert np.isclose(np.linalg.norm(q._wxyz), 1.0)


def test_rejects_zero_quaternion():
    with pytest.raises(ValueError):
        Quaternion([0, 0, 0, 0])


def test_accepts_list_input():
    Quaternion([1, 0, 0, 0])


# --- apply ---


def test_apply_identity():
    v = [1, 2, 3]
    assert np.allclose(Quaternion.identity() @ v, v)


def test_apply_90_around_z():
    assert np.allclose(quat_z(np.pi / 2) @ [1, 0, 0], [0, 1, 0], atol=1e-10)


# --- compose and inverse ---


def test_compose_with_inverse_is_identity():
    q = quat_z(1.2)
    result = q @ ~q
    assert isinstance(result, Quaternion)
    assert result == Quaternion.identity()


def test_inverse_is_conjugate():
    q = quat_z(1.2)
    qi = ~q
    assert np.isclose(qi.w, q.w)
    assert np.allclose([qi.x, qi.y, qi.z], [-q.x, -q.y, -q.z])


def test_compose_returns_quaternion():
    q1, q2 = quat_z(0.5), quat_z(0.3)
    assert isinstance(q1 @ q2, Quaternion)


# --- equality ---


def test_q_equals_negative_q():
    q = quat_z(1.2)
    assert q == Quaternion(-q._wxyz)


def test_different_rotations_not_equal():
    assert quat_z(0.5) != quat_z(1.0)


# --- conversions ---


def test_roundtrip_quaternion_so3_quaternion():
    q = quat_z(1.2)
    assert q == q.to_so3().to_quaternion()


def test_roundtrip_quaternion_axis_angle_quaternion():
    q = quat_z(1.2)
    assert q == q.to_axis_angle().to_quaternion()


def test_roundtrip_quaternion_screw_quaternion():
    q = quat_z(1.2)
    assert q == q.to_screw().to_quaternion()


def test_identity_to_axis_angle():
    aa = Quaternion.identity().to_axis_angle()
    assert np.isclose(aa.angle, 0.0)
