import numpy as np
import pytest
from rotations import AxisAngle


# --- construction ---


def test_identity():
    aa = AxisAngle.identity()
    assert np.isclose(aa.angle, 0.0)


def test_normalises_axis():
    aa = AxisAngle([0, 0, 5], np.pi / 2)
    assert np.allclose(aa.axis, [0, 0, 1])


def test_rejects_zero_axis():
    with pytest.raises(ValueError):
        AxisAngle([0, 0, 0], 1.0)


def test_accepts_list_input():
    AxisAngle([0, 0, 1], np.pi / 2)


# --- apply ---


def test_apply_identity():
    v = [1, 2, 3]
    assert np.allclose(AxisAngle.identity() @ v, v)


def test_apply_90_around_z():
    aa = AxisAngle([0, 0, 1], np.pi / 2)
    assert np.allclose(aa @ [1, 0, 0], [0, 1, 0], atol=1e-10)


def test_apply_90_around_x():
    aa = AxisAngle([1, 0, 0], np.pi / 2)
    assert np.allclose(aa @ [0, 1, 0], [0, 0, 1], atol=1e-10)


def test_axis_unchanged_by_rotation():
    aa = AxisAngle([0, 0, 1], np.pi / 2)
    assert np.allclose(aa @ [0, 0, 1], [0, 0, 1], atol=1e-10)


# --- compose and inverse ---


def test_compose_with_inverse_is_identity():
    aa = AxisAngle([0, 0, 1], 1.2)
    result = aa @ ~aa
    assert isinstance(result, AxisAngle)
    assert np.isclose(result.angle, 0.0, atol=1e-10)


def test_compose_returns_axis_angle():
    aa1 = AxisAngle([0, 0, 1], 0.5)
    aa2 = AxisAngle([1, 0, 0], 0.3)
    assert isinstance(aa1 @ aa2, AxisAngle)


def test_inverse_undoes_rotation():
    aa = AxisAngle([0, 0, 1], np.pi / 2)
    v = [1, 0, 0]
    assert np.allclose(~aa @ (aa @ v), v, atol=1e-10)


# --- conversions ---


def test_roundtrip_axis_angle_so3_axis_angle():
    aa = AxisAngle([0, 0, 1], 1.2)
    result = aa.to_so3().to_axis_angle()
    assert np.allclose(result.axis, aa.axis, atol=1e-10)
    assert np.isclose(result.angle, aa.angle, atol=1e-10)


def test_roundtrip_axis_angle_quaternion_axis_angle():
    aa = AxisAngle([0, 0, 1], 1.2)
    result = aa.to_quaternion().to_axis_angle()
    assert np.allclose(result.axis, aa.axis, atol=1e-10)
    assert np.isclose(result.angle, aa.angle, atol=1e-10)


def test_roundtrip_axis_angle_screw_axis_angle():
    aa = AxisAngle([0, 0, 1], 1.2)
    result = aa.to_screw().to_axis_angle()
    assert np.allclose(result.axis, aa.axis, atol=1e-10)
    assert np.isclose(result.angle, aa.angle, atol=1e-10)
