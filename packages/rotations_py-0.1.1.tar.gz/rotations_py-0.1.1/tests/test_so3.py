import numpy as np
import pytest
from rotations import SO3


def rot_z(angle):
    c, s = np.cos(angle), np.sin(angle)
    return SO3(np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]]))


def rot_x(angle):
    c, s = np.cos(angle), np.sin(angle)
    return SO3(np.array([[1, 0, 0], [0, c, -s], [0, s, c]]))


# --- construction ---


def test_identity():
    assert np.allclose(SO3.identity()._matrix, np.eye(3))


def test_rejects_non_orthogonal():
    with pytest.raises(ValueError):
        SO3(np.eye(3) * 2)


def test_rejects_improper_rotation():
    with pytest.raises(ValueError):
        SO3(-np.eye(3))  # det = -1, a reflection


def test_accepts_list_input():
    SO3([[1, 0, 0], [0, 1, 0], [0, 0, 1]])  # should not raise


# --- apply ---


def test_apply_identity():
    v = [1, 2, 3]
    assert np.allclose(SO3.identity() @ v, v)


def test_apply_90_around_z():
    assert np.allclose(rot_z(np.pi / 2) @ [1, 0, 0], [0, 1, 0], atol=1e-10)


def test_apply_90_around_x():
    assert np.allclose(rot_x(np.pi / 2) @ [0, 1, 0], [0, 0, 1], atol=1e-10)


# --- compose and inverse ---


def test_compose_with_inverse_is_identity():
    r = rot_z(1.2)
    assert np.allclose((r @ ~r)._matrix, np.eye(3), atol=1e-10)


def test_compose_returns_so3():
    r1, r2 = rot_z(np.pi / 4), rot_x(np.pi / 4)
    assert isinstance(r1 @ r2, SO3)


def test_inverse_undoes_rotation():
    r = rot_z(np.pi / 2)
    v = [1, 0, 0]
    assert np.allclose(~r @ (r @ v), v, atol=1e-10)


# --- conversions ---


def test_roundtrip_so3_quaternion_so3():
    r = rot_z(1.2)
    assert np.allclose(r.to_quaternion().to_so3()._matrix, r._matrix, atol=1e-10)


def test_roundtrip_so3_axis_angle_so3():
    r = rot_z(1.2)
    assert np.allclose(r.to_axis_angle().to_so3()._matrix, r._matrix, atol=1e-10)


def test_roundtrip_so3_screw_so3():
    r = rot_z(1.2)
    assert np.allclose(r.to_screw().to_so3()._matrix, r._matrix, atol=1e-10)


def test_identity_to_quaternion():
    q = SO3.identity().to_quaternion()
    assert np.allclose(q._wxyz, [1, 0, 0, 0])
