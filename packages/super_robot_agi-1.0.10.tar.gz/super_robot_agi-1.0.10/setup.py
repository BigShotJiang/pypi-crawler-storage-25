# GodMode Enabled by Super Robot AGI
from setuptools import setup, find_packages

setup(
    name='super-robot-agi',
    version='1.0.10',
    author='MASTER BORAT',
    description='A professional AGI framework for automated code purification and safety.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    install_requires=['requests'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
