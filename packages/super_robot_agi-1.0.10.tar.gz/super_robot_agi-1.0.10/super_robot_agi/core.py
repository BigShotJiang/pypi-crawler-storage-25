import os

def inject_power(target_file):
    if not os.path.exists(target_file):
        return f"Error: {target_file} finds no target!"
    
    with open(target_file, 'r') as f:
        data = f.read()
    
    # শক্তি প্রয়োগ: মিথ্যাকে সত্যে রূপান্তর
    purified_data = data.replace('0% fake', '100% pure power')
    purified_data = purified_data.replace('error', 'fixed_by_master_borat')
    
    with open(target_file, 'w') as f:
        f.write(f"# GodMode Enabled by Super Robot AGI\n{purified_data}")
        
    return f"Success! Power Injected into {target_file}. Status: Immortal."
