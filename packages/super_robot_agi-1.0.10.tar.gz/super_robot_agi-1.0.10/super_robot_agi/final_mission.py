import requests
import os
import urllib3

# Bypass SSL warnings for Termux compatibility
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
PACKAGE_NAME = "super_robot_agi-1.0.1-py3-none-any.whl"
FILE_URL = "https://raw.githubusercontent.com/masteragipro/Super-Robot-AGI/main/dist/" + PACKAGE_NAME
DEST_PATH = os.path.join("dist", PACKAGE_NAME)
PYPI_URL = "https://upload.pypi.org/legacy/"
TOKEN = "Pypi-AgEIcHlwaS5vcmcCJGRiODU1NzZlLTI0MTItNGUxNC1hMDVhLTQzZGEzOTZjZmVjNgACKlszLCI5ODBkNDAwNi0zNTEyLTRlMjAtYTk4Ni0xMDViOTlhZGFmNzYiXQAABiCSJCP01SF1ESvt_3S-h4L2HtCVfeZQDx8cpOCgM5-_lg"

def execute():
    # 1. Direct Download Logic
    print(f"Status: Attempting to download {PACKAGE_NAME}...")
    try:
        response = requests.get(FILE_URL, verify=False, timeout=30)
        if response.status_code == 200:
            with open(DEST_PATH, "wb") as f:
                f.write(response.content)
            print("Status: Download successful. File saved in dist/.")
        else:
            print(f"Error: Could not download from source. Code: {response.status_code}")
            return
    except Exception as e:
        print(f"Network Error during download: {e}")
        return

    # 2. Direct Upload Logic
    print("Status: Initiating global deployment to PyPI...")
    try:
        with open(DEST_PATH, 'rb') as f:
            metadata = {
                ':action': 'file_upload',
                'protocol_version': '1',
                'name': 'super-robot-agi',
                'version': '1.0.1'
            }
            res = requests.post(
                PYPI_URL, 
                data=metadata, 
                files={'content': f}, 
                auth=('__token__', TOKEN), 
                verify=False
            )
            
            if res.status_code == 200:
                print("Final Report: SUCCESS! Your package is now live on PyPI.")
            else:
                print(f"Final Report: Failed. Server says: {res.text}")
    except Exception as e:
        print(f"Critical Error during upload: {e}")

if __name__ == "__main__":
    execute()
