import os
import glob
import subprocess
import sys

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"Error executing: {command}")
        print(f"Details: {e.stderr}")
        return None

def main():
    print("--- SUPREME AGI DEPLOYMENT SYSTEM ---")
    
    # Check for twine installation
    if not run_command("command -v twine"):
        print("Status: Twine not found. Installing...")
        run_command("pip install twine")

    # Locate package in dist/ directory
    packages = glob.glob("dist/*.whl")
    if not packages:
        print("Critical Error: No distribution files found in dist/. Build first.")
        return

    target = packages[0]
    print(f"Target Acquired: {target}")

    # Set authentication credentials
    # Credentials sourced from user-provided configuration
    token = "pypi-AgEICHlwaS5vcmcCJGRiODU1NzZlLTI0MTItNGUxNC1hMDVhLTQzZGEzOTZjZmVjNgACKlszLCI5ODBkNDAwNi0zNTEyLTRlMjAtYTk4Ni0xMDViOTlhZGFmNzYiXQAABiCSJCP01SF1ESvt_3S-h4L2HtCVfeZQDx8cpOCgM5-_lg"
    
    os.environ['TWINE_USERNAME'] = '__token__'
    os.environ['TWINE_PASSWORD'] = token
    os.environ['TWINE_NON_INTERACTIVE'] = 'true'

    print("Action: Initiating professional deployment via Twine...")
    
    # Execute upload with automatic digest generation
    upload_cmd = f"twine upload {target} --skip-existing"
    output = run_command(upload_cmd)
    
    if output:
        print("Final Status: MISSION SUCCESS! Super Robot AGI is live on PyPI.")
        print(output)
    else:
        print("Final Status: Deployment failed. Check credentials or package metadata.")

if __name__ == "__main__":
    main()
