import requests
import os
import glob

def direct_mission():
    print("--- DIRECT SUPREME DEPLOYMENT (NO TWINE) ---")
    
    # আপনার বিল্ড করা ফাইলটি খুঁজে বের করা
    pkgs = glob.glob("dist/*.whl")
    if not pkgs:
        print("Error: No .whl file found in dist/ folder. Build first.")
        return
    
    target = sorted(pkgs)[-1]
    filename = os.path.basename(target)
    
    # PyPI API URL and Secure Token
    url = "https://upload.pypi.org/legacy/"
    token = "pypi-AgEICHlwaS5vcmcCJGRiODU1NzZlLTI0MTItNGUxNC1hMDVhLTQzZGEzOTZjZmVjNgACKlszLCI5ODBkNDAwNi0zNTEyLTRlMjAtYTk4Ni0xMDViOTlhZGFmNzYiXQAABiCSJCP01SF1ESvt_3S-h4L2HtCVfeZQDx8cpOCgM5-_lg"

    print(f"Uploading {filename} directly to PyPI...")

    with open(target, 'rb') as f:
        files = {'content': (filename, f)}
        # Metadata needed for direct legacy API
        data = {
            ':action': 'file_upload',
            'protocol_version': '1',
        }
        
        try:
            response = requests.post(
                url, 
                data=data, 
                files=files, 
                auth=('__token__', token),
                timeout=60
            )
            
            if response.status_code == 200:
                print("\n[ SUCCESS ] Super Robot AGI is now LIVE on PyPI!")
            else:
                print(f"\n[ FAILED ] Code: {response.status_code}")
                print(f"Server Response: {response.text}")
        except Exception as e:
            print(f"Critical System Error: {e}")

if __name__ == "__main__":
    direct_mission()
