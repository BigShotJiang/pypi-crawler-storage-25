from setuptools import setup, find_packages
import os

setup(
    name="super-robot-agi",
    version="1.0.1",
    author="Borat",
    description="Mandatory safety and automation framework.",
    long_description="A 1% risk-free safety framework for AI validation.",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires='>=3.6',
)
