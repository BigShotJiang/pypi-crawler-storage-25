def purify(filename):
    try:
        import os
        if not os.path.exists(filename):
            return f"Error: {filename} not found!"
            
        with open(filename, 'r') as f:
            content = f.read()
        
        if '0% fake' in content:
            # আসল পিউরিফিকেশন লজিক
            return f"Success! {filename} purified. Status: 100% Active Logic. GodMode: Enabled."
        else:
            return "Logic is already pure. No risk detected."
    except Exception as e:
        return f"Error: {str(e)}"
