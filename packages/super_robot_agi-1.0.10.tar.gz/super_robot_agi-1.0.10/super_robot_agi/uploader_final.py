import requests
import glob
import urllib3
import os

# Bypass Termux SSL certificate issues
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# API Configuration
PYPI_URL = "https://upload.pypi.org/legacy/"
TOKEN = "pypi-AgEIcHlwaS5vcmcCJGRiODU1NzZlLTI0MTItNGUxNC1hMDVhLTQzZGEzOTZjZmVjNgACKlszLCI5ODBkNDAwNi0zNTEyLTRlMjAtYTk4Ni0xMDViOTlhZGFmNzYiXQAABiCSJCP01SF1ESvt_3S-h4L2HtCVfeZQDx8cpOCgM5-_lg"

def run_mission():
    # Identify the package file in dist directory
    files = glob.glob("dist/*.whl")
    if not files:
        print("System Error: No .whl file found in dist/ folder.")
        return

    package_file = files[0]
    print(f"System Message: File identified -> {package_file}")

    metadata = {
        ':action': 'file_upload',
        'protocol_version': '1',
        'name': 'super-robot-agi',
        'version': '1.0.1'
    }

    try:
        print("Action: Initiating secure upload to PyPI...")
        with open(package_file, 'rb') as f:
            response = requests.post(
                PYPI_URL, 
                data=metadata, 
                files={'content': f}, 
                auth=('__token__', TOKEN), 
                verify=False,
                timeout=60
            )
            
            if response.status_code == 200:
                print("Final Status: MISSION SUCCESS! Super Robot AGI is live on PyPI.")
            else:
                print(f"Final Status: Upload failed. Code: {response.status_code}")
                print(f"Server Response: {response.text}")
                
    except Exception as e:
        print(f"Critical System Failure: {str(e)}")

if __name__ == "__main__":
    run_mission()
