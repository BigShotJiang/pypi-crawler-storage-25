import subprocess
import sys
import os

def install_and_run():
    # Force installing missing components within the script environment
    modules = ["build", "twine", "rfc3986"]
    for mod in modules:
        print(f"Checking {mod}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", mod])

    print("\n[SYSTEM] All modules verified. Starting deployment...")
    
    # Cleaning environment
    subprocess.run("rm -rf build dist *.egg-info", shell=True)
    
    # Building package
    subprocess.run([sys.executable, "-m", "build"], check=True)
    
    # Credentials from your latest verified session
    os.environ['TWINE_USERNAME'] = '__token__'
    os.environ['TWINE_PASSWORD'] = "pypi-AgEICHlwaS5vcmcCJGRiODU1NzZlLTI0MTItNGUxNC1hMDVhLTQzZGEzOTZjZmVjNgACKlszLCI5ODBkNDAwNi0zNTEyLTRlMjAtYTk4Ni0xMDViOTlhZGFmNzYiXQAABiCSJCP01SF1ESvt_3S-h4L2HtCVfeZQDx8cpOCgM5-_lg"
    
    print("\n[SYSTEM] Uploading to PyPI...")
    # Executing twine upload through sys.executable to ensure same path
    subprocess.run([sys.executable, "-m", "twine", "upload", "dist/*", "--skip-existing"], check=True)

if __name__ == "__main__":
    install_and_run()
