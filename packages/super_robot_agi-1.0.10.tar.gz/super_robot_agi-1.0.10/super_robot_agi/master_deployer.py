import os
import glob
import subprocess
from rich.console import Console

console = Console()

def run_step(step_name, command):
    console.print(f"[bold blue]Executing:[/bold blue] {step_name}...")
    try:
        subprocess.run(command, shell=True, check=True)
        console.print(f"[bold green]SUCCESS:[/bold green] {step_name} completed.\n")
    except subprocess.CalledProcessError:
        console.print(f"[bold red]FAILED:[/bold red] Error in {step_name}. Mission Aborted.")
        exit(1)

def main():
    console.print("[bold yellow]--- SUPREME AGI PRODUCTION PIPELINE ---[/bold yellow]\n")

    # 1. Build using modern standard
    run_step("Package Building", "python -m build")

    # 2. Safety Check: Verify latest build
    pkgs = glob.glob("dist/*.whl")
    if not pkgs:
        console.print("[bold red]Error:[/bold red] No build files found in dist/")
        return
    
    # Selecting the latest version using sorted logic
    latest_pkg = sorted(pkgs)[-1]
    console.print(f"[bold cyan]Target Identified:[/bold cyan] {latest_pkg}")

    # 3. Secure Deployment using environment variables
    if not os.environ.get("TWINE_PASSWORD"):
        console.print("[bold red]Critical Error:[/bold red] PyPI Token (TWINE_PASSWORD) not found in environment.")
        return

    console.print("Deploying to PyPI...")
    run_step("Global Deployment", f"python -m twine upload {latest_pkg} --skip-existing")

    console.print("\n[bold green]FINAL STATUS: SUPER ROBOT AGI IS NOW IMMORTAL AND GLOBAL.[/bold green]")

if __name__ == "__main__":
    main()
