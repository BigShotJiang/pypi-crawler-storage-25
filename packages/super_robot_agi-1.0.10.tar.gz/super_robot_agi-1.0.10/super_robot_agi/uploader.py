import requests
import glob
import urllib3
import os

# Suppress SSL warnings for Termux compatibility
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# PyPI Legacy API Configuration
URL = "https://upload.pypi.org/legacy/"
TOKEN = "pypi-AgEIcHlwaS5vcmcCJGRiODU1NzZlLTI0MTItNGUxNC1hMDVhLTQzZGEzOTZjZmVjNgACKlszLCI5ODBkNDAwNi0zNTEyLTRlMjAtYTk4Ni0xMDViOTlhZGFmNzYiXQAABiCSJCP01SF1ESvt_3S-h4L2HtCVfeZQDx8cpOCgM5-_lg"

def execute_upload():
    # Locating the wheel package in the dist directory
    package_files = glob.glob("dist/*.whl")
    
    if not package_files:
        print("System Error: No .whl file detected in dist/ folder.")
        return

    package_path = package_files[0]
    filename = os.path.basename(package_path)

    # Mandatory PyPI metadata to resolve Error 400 and Metadata-Generation issues
    metadata = {
        ':action': 'file_upload',
        'protocol_version': '1',
        'name': 'super-robot-agi',
        'version': '1.0.1',
        'filetype': 'bdist_wheel',
        'pyversion': 'py3',
        'metadata_version': '2.1',
        'summary': 'Supreme AGI system by Md. Borat Ullah',
        'author': 'Md. Borat Ullah'
    }

    print(f"Current Action: Uploading {filename} to PyPI...")
    
    try:
        with open(package_path, 'rb') as f:
            # Posting request with custom file content handling
            response = requests.post(
                URL, 
                data=metadata, 
                files={'content': (filename, f)}, 
                auth=('__token__', TOKEN), 
                verify=False,
                timeout=60
            )

            if response.status_code == 200:
                print("Final Report: MISSION SUCCESS! Super Robot AGI is now live.")
            else:
                print(f"Final Report: Upload failed. Status Code: {response.status_code}")
                print(f"Server Detail: {response.text}")
                
    except Exception as e:
        print(f"Critical System Error: {str(e)}")

if __name__ == "__main__":
    execute_upload()
