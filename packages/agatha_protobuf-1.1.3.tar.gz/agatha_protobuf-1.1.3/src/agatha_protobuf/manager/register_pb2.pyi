from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class CreateActionRequest(_message.Message):
    __slots__ = ("tenant", "action", "url", "key")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    action: str
    url: str
    key: str
    def __init__(self, tenant: _Optional[str] = ..., action: _Optional[str] = ..., url: _Optional[str] = ..., key: _Optional[str] = ...) -> None: ...

class CreateActionResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
