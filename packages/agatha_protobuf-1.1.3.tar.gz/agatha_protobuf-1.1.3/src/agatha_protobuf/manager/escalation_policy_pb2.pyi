from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EscalationPolicy(_message.Message):
    __slots__ = ("id", "tenant_id", "name", "target_roles", "contacts", "fallback_policy_id", "ack_timeout_minutes", "active", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TARGET_ROLES_FIELD_NUMBER: _ClassVar[int]
    CONTACTS_FIELD_NUMBER: _ClassVar[int]
    FALLBACK_POLICY_ID_FIELD_NUMBER: _ClassVar[int]
    ACK_TIMEOUT_MINUTES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    name: str
    target_roles: _containers.RepeatedScalarFieldContainer[str]
    contacts: _containers.RepeatedCompositeFieldContainer[PolicyContact]
    fallback_policy_id: str
    ack_timeout_minutes: int
    active: bool
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., name: _Optional[str] = ..., target_roles: _Optional[_Iterable[str]] = ..., contacts: _Optional[_Iterable[_Union[PolicyContact, _Mapping]]] = ..., fallback_policy_id: _Optional[str] = ..., ack_timeout_minutes: _Optional[int] = ..., active: bool = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class PolicyContact(_message.Message):
    __slots__ = ("role", "email", "webhook_url", "phone")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    WEBHOOK_URL_FIELD_NUMBER: _ClassVar[int]
    PHONE_FIELD_NUMBER: _ClassVar[int]
    role: str
    email: str
    webhook_url: str
    phone: str
    def __init__(self, role: _Optional[str] = ..., email: _Optional[str] = ..., webhook_url: _Optional[str] = ..., phone: _Optional[str] = ...) -> None: ...

class CreateEscalationPolicyRequest(_message.Message):
    __slots__ = ("tenant_id", "name", "target_roles", "contacts", "fallback_policy_id", "ack_timeout_minutes", "active")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TARGET_ROLES_FIELD_NUMBER: _ClassVar[int]
    CONTACTS_FIELD_NUMBER: _ClassVar[int]
    FALLBACK_POLICY_ID_FIELD_NUMBER: _ClassVar[int]
    ACK_TIMEOUT_MINUTES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    name: str
    target_roles: _containers.RepeatedScalarFieldContainer[str]
    contacts: _containers.RepeatedCompositeFieldContainer[PolicyContact]
    fallback_policy_id: str
    ack_timeout_minutes: int
    active: bool
    def __init__(self, tenant_id: _Optional[str] = ..., name: _Optional[str] = ..., target_roles: _Optional[_Iterable[str]] = ..., contacts: _Optional[_Iterable[_Union[PolicyContact, _Mapping]]] = ..., fallback_policy_id: _Optional[str] = ..., ack_timeout_minutes: _Optional[int] = ..., active: bool = ...) -> None: ...

class UpdateEscalationPolicyRequest(_message.Message):
    __slots__ = ("tenant_id", "id", "name", "target_roles", "contacts", "fallback_policy_id", "ack_timeout_minutes", "active")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TARGET_ROLES_FIELD_NUMBER: _ClassVar[int]
    CONTACTS_FIELD_NUMBER: _ClassVar[int]
    FALLBACK_POLICY_ID_FIELD_NUMBER: _ClassVar[int]
    ACK_TIMEOUT_MINUTES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    id: str
    name: str
    target_roles: _containers.RepeatedScalarFieldContainer[str]
    contacts: _containers.RepeatedCompositeFieldContainer[PolicyContact]
    fallback_policy_id: str
    ack_timeout_minutes: int
    active: bool
    def __init__(self, tenant_id: _Optional[str] = ..., id: _Optional[str] = ..., name: _Optional[str] = ..., target_roles: _Optional[_Iterable[str]] = ..., contacts: _Optional[_Iterable[_Union[PolicyContact, _Mapping]]] = ..., fallback_policy_id: _Optional[str] = ..., ack_timeout_minutes: _Optional[int] = ..., active: bool = ...) -> None: ...

class GetEscalationPolicyRequest(_message.Message):
    __slots__ = ("tenant_id", "id")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    id: str
    def __init__(self, tenant_id: _Optional[str] = ..., id: _Optional[str] = ...) -> None: ...

class ListEscalationPoliciesRequest(_message.Message):
    __slots__ = ("tenant_id",)
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    def __init__(self, tenant_id: _Optional[str] = ...) -> None: ...

class ListEscalationPoliciesResponse(_message.Message):
    __slots__ = ("policies",)
    POLICIES_FIELD_NUMBER: _ClassVar[int]
    policies: _containers.RepeatedCompositeFieldContainer[EscalationPolicy]
    def __init__(self, policies: _Optional[_Iterable[_Union[EscalationPolicy, _Mapping]]] = ...) -> None: ...

class DeleteEscalationPolicyRequest(_message.Message):
    __slots__ = ("tenant_id", "id")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    id: str
    def __init__(self, tenant_id: _Optional[str] = ..., id: _Optional[str] = ...) -> None: ...

class ResolveEscalationPolicyRequest(_message.Message):
    __slots__ = ("tenant_id", "id")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    id: str
    def __init__(self, tenant_id: _Optional[str] = ..., id: _Optional[str] = ...) -> None: ...

class ResolveEscalationPolicyResponse(_message.Message):
    __slots__ = ("policy",)
    POLICY_FIELD_NUMBER: _ClassVar[int]
    policy: EscalationPolicy
    def __init__(self, policy: _Optional[_Union[EscalationPolicy, _Mapping]] = ...) -> None: ...
