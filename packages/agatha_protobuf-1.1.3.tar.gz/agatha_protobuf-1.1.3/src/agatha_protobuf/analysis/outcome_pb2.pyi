from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class RecordOutcomeRequest(_message.Message):
    __slots__ = ("session_id", "student_id", "tool_id", "mood_delta", "engagement_recovery", "tool_reuse_rate", "human_rating", "tenant")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    STUDENT_ID_FIELD_NUMBER: _ClassVar[int]
    TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    MOOD_DELTA_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_RECOVERY_FIELD_NUMBER: _ClassVar[int]
    TOOL_REUSE_RATE_FIELD_NUMBER: _ClassVar[int]
    HUMAN_RATING_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    student_id: str
    tool_id: str
    mood_delta: float
    engagement_recovery: float
    tool_reuse_rate: float
    human_rating: float
    tenant: str
    def __init__(self, session_id: _Optional[str] = ..., student_id: _Optional[str] = ..., tool_id: _Optional[str] = ..., mood_delta: _Optional[float] = ..., engagement_recovery: _Optional[float] = ..., tool_reuse_rate: _Optional[float] = ..., human_rating: _Optional[float] = ..., tenant: _Optional[str] = ...) -> None: ...

class RecordOutcomeResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...
