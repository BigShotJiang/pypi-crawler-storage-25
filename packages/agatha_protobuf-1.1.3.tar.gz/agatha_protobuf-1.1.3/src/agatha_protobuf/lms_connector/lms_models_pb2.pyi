from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class LMSCourse(_message.Message):
    __slots__ = ("id", "lms_type", "external_id", "name", "description", "state", "teacher_name", "teacher_email", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    TEACHER_NAME_FIELD_NUMBER: _ClassVar[int]
    TEACHER_EMAIL_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    lms_type: str
    external_id: str
    name: str
    description: str
    state: str
    teacher_name: str
    teacher_email: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., lms_type: _Optional[str] = ..., external_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., state: _Optional[str] = ..., teacher_name: _Optional[str] = ..., teacher_email: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class LMSAssignment(_message.Message):
    __slots__ = ("id", "lms_type", "external_id", "course_external_id", "title", "description", "state", "max_points", "due_date", "work_type", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    MAX_POINTS_FIELD_NUMBER: _ClassVar[int]
    DUE_DATE_FIELD_NUMBER: _ClassVar[int]
    WORK_TYPE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    lms_type: str
    external_id: str
    course_external_id: str
    title: str
    description: str
    state: str
    max_points: float
    due_date: str
    work_type: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., lms_type: _Optional[str] = ..., external_id: _Optional[str] = ..., course_external_id: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., state: _Optional[str] = ..., max_points: _Optional[float] = ..., due_date: _Optional[str] = ..., work_type: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class LMSSubmission(_message.Message):
    __slots__ = ("id", "lms_type", "external_id", "assignment_external_id", "student_external_id", "state", "score", "max_points", "grade", "late", "submitted_at", "graded_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENT_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    STUDENT_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    MAX_POINTS_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    LATE_FIELD_NUMBER: _ClassVar[int]
    SUBMITTED_AT_FIELD_NUMBER: _ClassVar[int]
    GRADED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    lms_type: str
    external_id: str
    assignment_external_id: str
    student_external_id: str
    state: str
    score: float
    max_points: float
    grade: str
    late: bool
    submitted_at: str
    graded_at: str
    def __init__(self, id: _Optional[str] = ..., lms_type: _Optional[str] = ..., external_id: _Optional[str] = ..., assignment_external_id: _Optional[str] = ..., student_external_id: _Optional[str] = ..., state: _Optional[str] = ..., score: _Optional[float] = ..., max_points: _Optional[float] = ..., grade: _Optional[str] = ..., late: bool = ..., submitted_at: _Optional[str] = ..., graded_at: _Optional[str] = ...) -> None: ...

class LMSEnrollment(_message.Message):
    __slots__ = ("id", "lms_type", "course_external_id", "user_external_id", "role", "state", "current_score", "current_grade", "enrolled_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    USER_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_SCORE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_GRADE_FIELD_NUMBER: _ClassVar[int]
    ENROLLED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    lms_type: str
    course_external_id: str
    user_external_id: str
    role: str
    state: str
    current_score: float
    current_grade: str
    enrolled_at: str
    def __init__(self, id: _Optional[str] = ..., lms_type: _Optional[str] = ..., course_external_id: _Optional[str] = ..., user_external_id: _Optional[str] = ..., role: _Optional[str] = ..., state: _Optional[str] = ..., current_score: _Optional[float] = ..., current_grade: _Optional[str] = ..., enrolled_at: _Optional[str] = ...) -> None: ...

class LMSStudent(_message.Message):
    __slots__ = ("external_id", "lms_type", "email", "first_name", "last_name", "full_name", "photo_url")
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    FULL_NAME_FIELD_NUMBER: _ClassVar[int]
    PHOTO_URL_FIELD_NUMBER: _ClassVar[int]
    external_id: str
    lms_type: str
    email: str
    first_name: str
    last_name: str
    full_name: str
    photo_url: str
    def __init__(self, external_id: _Optional[str] = ..., lms_type: _Optional[str] = ..., email: _Optional[str] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., full_name: _Optional[str] = ..., photo_url: _Optional[str] = ...) -> None: ...
