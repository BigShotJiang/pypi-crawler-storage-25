from agatha_protobuf.lms_connector import lms_models_pb2 as _lms_models_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ListCoursesRequest(_message.Message):
    __slots__ = ("lms_type", "page_size", "page_token")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    page_size: int
    page_token: str
    def __init__(self, lms_type: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListCoursesResponse(_message.Message):
    __slots__ = ("courses", "next_page_token")
    COURSES_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    courses: _containers.RepeatedCompositeFieldContainer[_lms_models_pb2.LMSCourse]
    next_page_token: str
    def __init__(self, courses: _Optional[_Iterable[_Union[_lms_models_pb2.LMSCourse, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class GetCourseRequest(_message.Message):
    __slots__ = ("lms_type", "external_id")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    external_id: str
    def __init__(self, lms_type: _Optional[str] = ..., external_id: _Optional[str] = ...) -> None: ...

class GetCourseStudentsRequest(_message.Message):
    __slots__ = ("lms_type", "course_external_id", "page_size", "page_token")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    course_external_id: str
    page_size: int
    page_token: str
    def __init__(self, lms_type: _Optional[str] = ..., course_external_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class GetCourseStudentsResponse(_message.Message):
    __slots__ = ("students", "next_page_token")
    STUDENTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    students: _containers.RepeatedCompositeFieldContainer[_lms_models_pb2.LMSStudent]
    next_page_token: str
    def __init__(self, students: _Optional[_Iterable[_Union[_lms_models_pb2.LMSStudent, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class ListAssignmentsRequest(_message.Message):
    __slots__ = ("lms_type", "course_external_id", "page_size", "page_token")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    course_external_id: str
    page_size: int
    page_token: str
    def __init__(self, lms_type: _Optional[str] = ..., course_external_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListAssignmentsResponse(_message.Message):
    __slots__ = ("assignments", "next_page_token")
    ASSIGNMENTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    assignments: _containers.RepeatedCompositeFieldContainer[_lms_models_pb2.LMSAssignment]
    next_page_token: str
    def __init__(self, assignments: _Optional[_Iterable[_Union[_lms_models_pb2.LMSAssignment, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class GetAssignmentRequest(_message.Message):
    __slots__ = ("lms_type", "course_external_id", "assignment_external_id")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENT_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    course_external_id: str
    assignment_external_id: str
    def __init__(self, lms_type: _Optional[str] = ..., course_external_id: _Optional[str] = ..., assignment_external_id: _Optional[str] = ...) -> None: ...

class ListSubmissionsRequest(_message.Message):
    __slots__ = ("lms_type", "course_external_id", "assignment_external_id", "page_size", "page_token")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNMENT_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    course_external_id: str
    assignment_external_id: str
    page_size: int
    page_token: str
    def __init__(self, lms_type: _Optional[str] = ..., course_external_id: _Optional[str] = ..., assignment_external_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListSubmissionsResponse(_message.Message):
    __slots__ = ("submissions", "next_page_token")
    SUBMISSIONS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    submissions: _containers.RepeatedCompositeFieldContainer[_lms_models_pb2.LMSSubmission]
    next_page_token: str
    def __init__(self, submissions: _Optional[_Iterable[_Union[_lms_models_pb2.LMSSubmission, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class GetStudentGradesRequest(_message.Message):
    __slots__ = ("lms_type", "course_external_id", "student_external_id")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    STUDENT_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    course_external_id: str
    student_external_id: str
    def __init__(self, lms_type: _Optional[str] = ..., course_external_id: _Optional[str] = ..., student_external_id: _Optional[str] = ...) -> None: ...

class GetStudentGradesResponse(_message.Message):
    __slots__ = ("submissions",)
    SUBMISSIONS_FIELD_NUMBER: _ClassVar[int]
    submissions: _containers.RepeatedCompositeFieldContainer[_lms_models_pb2.LMSSubmission]
    def __init__(self, submissions: _Optional[_Iterable[_Union[_lms_models_pb2.LMSSubmission, _Mapping]]] = ...) -> None: ...

class ListEnrollmentsRequest(_message.Message):
    __slots__ = ("lms_type", "course_external_id", "page_size", "page_token")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    COURSE_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    course_external_id: str
    page_size: int
    page_token: str
    def __init__(self, lms_type: _Optional[str] = ..., course_external_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListEnrollmentsResponse(_message.Message):
    __slots__ = ("enrollments", "next_page_token")
    ENROLLMENTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    enrollments: _containers.RepeatedCompositeFieldContainer[_lms_models_pb2.LMSEnrollment]
    next_page_token: str
    def __init__(self, enrollments: _Optional[_Iterable[_Union[_lms_models_pb2.LMSEnrollment, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class RegisterLMSConnectionRequest(_message.Message):
    __slots__ = ("lms_type", "client_id", "client_secret", "auth_code", "instance_url")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CLIENT_SECRET_FIELD_NUMBER: _ClassVar[int]
    AUTH_CODE_FIELD_NUMBER: _ClassVar[int]
    INSTANCE_URL_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    client_id: str
    client_secret: str
    auth_code: str
    instance_url: str
    def __init__(self, lms_type: _Optional[str] = ..., client_id: _Optional[str] = ..., client_secret: _Optional[str] = ..., auth_code: _Optional[str] = ..., instance_url: _Optional[str] = ...) -> None: ...

class RegisterLMSConnectionResponse(_message.Message):
    __slots__ = ("status", "message")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    status: str
    message: str
    def __init__(self, status: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class GetConnectionStatusRequest(_message.Message):
    __slots__ = ("lms_type",)
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    def __init__(self, lms_type: _Optional[str] = ...) -> None: ...

class ConnectionStatus(_message.Message):
    __slots__ = ("lms_type", "status", "expires_at")
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    status: str
    expires_at: str
    def __init__(self, lms_type: _Optional[str] = ..., status: _Optional[str] = ..., expires_at: _Optional[str] = ...) -> None: ...

class RefreshTokenRequest(_message.Message):
    __slots__ = ("lms_type",)
    LMS_TYPE_FIELD_NUMBER: _ClassVar[int]
    lms_type: str
    def __init__(self, lms_type: _Optional[str] = ...) -> None: ...

class RefreshTokenResponse(_message.Message):
    __slots__ = ("status", "expires_at")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    status: str
    expires_at: str
    def __init__(self, status: _Optional[str] = ..., expires_at: _Optional[str] = ...) -> None: ...
