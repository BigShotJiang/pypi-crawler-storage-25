from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ClinicalEvidenceLevel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EVIDENCE_LEVEL_UNSPECIFIED: _ClassVar[ClinicalEvidenceLevel]
    LOW: _ClassVar[ClinicalEvidenceLevel]
    MEDIUM: _ClassVar[ClinicalEvidenceLevel]
    HIGH: _ClassVar[ClinicalEvidenceLevel]
EVIDENCE_LEVEL_UNSPECIFIED: ClinicalEvidenceLevel
LOW: ClinicalEvidenceLevel
MEDIUM: ClinicalEvidenceLevel
HIGH: ClinicalEvidenceLevel

class CopingTool(_message.Message):
    __slots__ = ("id", "tenant_id", "external_id", "label", "category", "metadata", "created_at", "updated_at", "therapist_reviewed_at", "clinical_evidence_level", "age_min", "age_max")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    THERAPIST_REVIEWED_AT_FIELD_NUMBER: _ClassVar[int]
    CLINICAL_EVIDENCE_LEVEL_FIELD_NUMBER: _ClassVar[int]
    AGE_MIN_FIELD_NUMBER: _ClassVar[int]
    AGE_MAX_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    external_id: str
    label: str
    category: str
    metadata: _containers.ScalarMap[str, str]
    created_at: str
    updated_at: str
    therapist_reviewed_at: str
    clinical_evidence_level: ClinicalEvidenceLevel
    age_min: int
    age_max: int
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., external_id: _Optional[str] = ..., label: _Optional[str] = ..., category: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., therapist_reviewed_at: _Optional[str] = ..., clinical_evidence_level: _Optional[_Union[ClinicalEvidenceLevel, str]] = ..., age_min: _Optional[int] = ..., age_max: _Optional[int] = ...) -> None: ...

class CreateCopingToolRequest(_message.Message):
    __slots__ = ("tenant_id", "external_id", "label", "category", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    external_id: str
    label: str
    category: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, tenant_id: _Optional[str] = ..., external_id: _Optional[str] = ..., label: _Optional[str] = ..., category: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class GetCopingToolRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class ListCopingToolsRequest(_message.Message):
    __slots__ = ("tenant_id", "category", "page_size", "page_token")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    category: str
    page_size: int
    page_token: str
    def __init__(self, tenant_id: _Optional[str] = ..., category: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListCopingToolsResponse(_message.Message):
    __slots__ = ("coping_tools", "next_page_token")
    COPING_TOOLS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    coping_tools: _containers.RepeatedCompositeFieldContainer[CopingTool]
    next_page_token: str
    def __init__(self, coping_tools: _Optional[_Iterable[_Union[CopingTool, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateCopingToolRequest(_message.Message):
    __slots__ = ("id", "tenant_id", "label", "category", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    label: str
    category: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., label: _Optional[str] = ..., category: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class DeleteCopingToolRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class DeleteCopingToolResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
