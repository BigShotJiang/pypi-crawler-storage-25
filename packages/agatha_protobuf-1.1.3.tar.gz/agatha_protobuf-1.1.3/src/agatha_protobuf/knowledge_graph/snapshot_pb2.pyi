from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Snapshot(_message.Message):
    __slots__ = ("id", "person_id", "tenant_id", "mood_baseline", "mood_volatility", "engagement_trend", "attendance_rate", "sleep_trend", "support_index", "routine_consistency", "full_recomputed_at", "risk_recomputed_at", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    MOOD_BASELINE_FIELD_NUMBER: _ClassVar[int]
    MOOD_VOLATILITY_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_TREND_FIELD_NUMBER: _ClassVar[int]
    ATTENDANCE_RATE_FIELD_NUMBER: _ClassVar[int]
    SLEEP_TREND_FIELD_NUMBER: _ClassVar[int]
    SUPPORT_INDEX_FIELD_NUMBER: _ClassVar[int]
    ROUTINE_CONSISTENCY_FIELD_NUMBER: _ClassVar[int]
    FULL_RECOMPUTED_AT_FIELD_NUMBER: _ClassVar[int]
    RISK_RECOMPUTED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    person_id: str
    tenant_id: str
    mood_baseline: float
    mood_volatility: float
    engagement_trend: float
    attendance_rate: float
    sleep_trend: float
    support_index: float
    routine_consistency: float
    full_recomputed_at: str
    risk_recomputed_at: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., mood_baseline: _Optional[float] = ..., mood_volatility: _Optional[float] = ..., engagement_trend: _Optional[float] = ..., attendance_rate: _Optional[float] = ..., sleep_trend: _Optional[float] = ..., support_index: _Optional[float] = ..., routine_consistency: _Optional[float] = ..., full_recomputed_at: _Optional[str] = ..., risk_recomputed_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class UpsertSnapshotRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "mood_baseline", "mood_volatility", "engagement_trend", "attendance_rate", "sleep_trend", "support_index", "routine_consistency", "recomputation_type")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    MOOD_BASELINE_FIELD_NUMBER: _ClassVar[int]
    MOOD_VOLATILITY_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_TREND_FIELD_NUMBER: _ClassVar[int]
    ATTENDANCE_RATE_FIELD_NUMBER: _ClassVar[int]
    SLEEP_TREND_FIELD_NUMBER: _ClassVar[int]
    SUPPORT_INDEX_FIELD_NUMBER: _ClassVar[int]
    ROUTINE_CONSISTENCY_FIELD_NUMBER: _ClassVar[int]
    RECOMPUTATION_TYPE_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    mood_baseline: float
    mood_volatility: float
    engagement_trend: float
    attendance_rate: float
    sleep_trend: float
    support_index: float
    routine_consistency: float
    recomputation_type: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., mood_baseline: _Optional[float] = ..., mood_volatility: _Optional[float] = ..., engagement_trend: _Optional[float] = ..., attendance_rate: _Optional[float] = ..., sleep_trend: _Optional[float] = ..., support_index: _Optional[float] = ..., routine_consistency: _Optional[float] = ..., recomputation_type: _Optional[str] = ...) -> None: ...

class GetLatestSnapshotRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class ListSnapshotsRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "page_size", "page_token")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    page_size: int
    page_token: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListSnapshotsResponse(_message.Message):
    __slots__ = ("snapshots", "next_page_token")
    SNAPSHOTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    snapshots: _containers.RepeatedCompositeFieldContainer[Snapshot]
    next_page_token: str
    def __init__(self, snapshots: _Optional[_Iterable[_Union[Snapshot, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...
