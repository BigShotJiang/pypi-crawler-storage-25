from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Consent(_message.Message):
    __slots__ = ("id", "person_id", "tenant_id", "data_category", "purpose", "granted_by", "granted_at", "expires_at", "revoked_at", "status", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_CATEGORY_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    GRANTED_BY_FIELD_NUMBER: _ClassVar[int]
    GRANTED_AT_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    REVOKED_AT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    person_id: str
    tenant_id: str
    data_category: str
    purpose: str
    granted_by: str
    granted_at: str
    expires_at: str
    revoked_at: str
    status: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., data_category: _Optional[str] = ..., purpose: _Optional[str] = ..., granted_by: _Optional[str] = ..., granted_at: _Optional[str] = ..., expires_at: _Optional[str] = ..., revoked_at: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class GrantConsentRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "data_category", "purpose", "granted_by", "expires_at")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_CATEGORY_FIELD_NUMBER: _ClassVar[int]
    PURPOSE_FIELD_NUMBER: _ClassVar[int]
    GRANTED_BY_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    data_category: str
    purpose: str
    granted_by: str
    expires_at: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., data_category: _Optional[str] = ..., purpose: _Optional[str] = ..., granted_by: _Optional[str] = ..., expires_at: _Optional[str] = ...) -> None: ...

class RevokeConsentRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class CheckConsentRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "data_category")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_CATEGORY_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    data_category: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., data_category: _Optional[str] = ...) -> None: ...

class CheckConsentResponse(_message.Message):
    __slots__ = ("has_consent", "consent_id")
    HAS_CONSENT_FIELD_NUMBER: _ClassVar[int]
    CONSENT_ID_FIELD_NUMBER: _ClassVar[int]
    has_consent: bool
    consent_id: str
    def __init__(self, has_consent: bool = ..., consent_id: _Optional[str] = ...) -> None: ...

class ListConsentsRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "data_category", "status", "page_size", "page_token")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_CATEGORY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    data_category: str
    status: str
    page_size: int
    page_token: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., data_category: _Optional[str] = ..., status: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListConsentsResponse(_message.Message):
    __slots__ = ("consents", "next_page_token")
    CONSENTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    consents: _containers.RepeatedCompositeFieldContainer[Consent]
    next_page_token: str
    def __init__(self, consents: _Optional[_Iterable[_Union[Consent, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class GetConsentRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...
