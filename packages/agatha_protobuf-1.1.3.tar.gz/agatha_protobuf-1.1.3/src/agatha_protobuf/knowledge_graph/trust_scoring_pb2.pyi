from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TrustDimension(_message.Message):
    __slots__ = ("name", "score", "weight")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    name: str
    score: float
    weight: float
    def __init__(self, name: _Optional[str] = ..., score: _Optional[float] = ..., weight: _Optional[float] = ...) -> None: ...

class TrustScoreResult(_message.Message):
    __slots__ = ("composite_score", "consent_gate", "dimensions", "status")
    COMPOSITE_SCORE_FIELD_NUMBER: _ClassVar[int]
    CONSENT_GATE_FIELD_NUMBER: _ClassVar[int]
    DIMENSIONS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    composite_score: float
    consent_gate: bool
    dimensions: _containers.RepeatedCompositeFieldContainer[TrustDimension]
    status: str
    def __init__(self, composite_score: _Optional[float] = ..., consent_gate: bool = ..., dimensions: _Optional[_Iterable[_Union[TrustDimension, _Mapping]]] = ..., status: _Optional[str] = ...) -> None: ...

class EvaluateTrustRequest(_message.Message):
    __slots__ = ("tenant_id", "person_id", "source", "event_type", "payload", "has_consent", "data_hash", "timestamp")
    class PayloadEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    HAS_CONSENT_FIELD_NUMBER: _ClassVar[int]
    DATA_HASH_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    person_id: str
    source: str
    event_type: str
    payload: _containers.ScalarMap[str, str]
    has_consent: bool
    data_hash: str
    timestamp: str
    def __init__(self, tenant_id: _Optional[str] = ..., person_id: _Optional[str] = ..., source: _Optional[str] = ..., event_type: _Optional[str] = ..., payload: _Optional[_Mapping[str, str]] = ..., has_consent: bool = ..., data_hash: _Optional[str] = ..., timestamp: _Optional[str] = ...) -> None: ...
