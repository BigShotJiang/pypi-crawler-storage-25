from agatha_protobuf.knowledge_graph import trust_scoring_pb2 as _trust_scoring_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BehavioralEvent(_message.Message):
    __slots__ = ("id", "person_id", "tenant_id", "timestamp", "source", "event_type", "payload", "trust_score", "consent_id", "status", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    TRUST_SCORE_FIELD_NUMBER: _ClassVar[int]
    CONSENT_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    person_id: str
    tenant_id: str
    timestamp: str
    source: str
    event_type: str
    payload: _struct_pb2.Struct
    trust_score: _trust_scoring_pb2.TrustScoreResult
    consent_id: str
    status: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., timestamp: _Optional[str] = ..., source: _Optional[str] = ..., event_type: _Optional[str] = ..., payload: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., trust_score: _Optional[_Union[_trust_scoring_pb2.TrustScoreResult, _Mapping]] = ..., consent_id: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class IngestEventRequest(_message.Message):
    __slots__ = ("tenant_id", "source", "event_type", "payload", "external_ids_source", "external_ids_id", "timestamp", "data_hash")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_IDS_SOURCE_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_IDS_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    DATA_HASH_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    source: str
    event_type: str
    payload: _struct_pb2.Struct
    external_ids_source: _containers.RepeatedScalarFieldContainer[str]
    external_ids_id: _containers.RepeatedScalarFieldContainer[str]
    timestamp: str
    data_hash: str
    def __init__(self, tenant_id: _Optional[str] = ..., source: _Optional[str] = ..., event_type: _Optional[str] = ..., payload: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., external_ids_source: _Optional[_Iterable[str]] = ..., external_ids_id: _Optional[_Iterable[str]] = ..., timestamp: _Optional[str] = ..., data_hash: _Optional[str] = ...) -> None: ...

class IngestEventResponse(_message.Message):
    __slots__ = ("event", "trust_score", "routing_decision")
    EVENT_FIELD_NUMBER: _ClassVar[int]
    TRUST_SCORE_FIELD_NUMBER: _ClassVar[int]
    ROUTING_DECISION_FIELD_NUMBER: _ClassVar[int]
    event: BehavioralEvent
    trust_score: _trust_scoring_pb2.TrustScoreResult
    routing_decision: str
    def __init__(self, event: _Optional[_Union[BehavioralEvent, _Mapping]] = ..., trust_score: _Optional[_Union[_trust_scoring_pb2.TrustScoreResult, _Mapping]] = ..., routing_decision: _Optional[str] = ...) -> None: ...

class GetEventRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class GetEventTimelineRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "event_type", "from_timestamp", "to_timestamp", "page_size", "page_token")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    FROM_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    TO_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    event_type: str
    from_timestamp: str
    to_timestamp: str
    page_size: int
    page_token: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., event_type: _Optional[str] = ..., from_timestamp: _Optional[str] = ..., to_timestamp: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class GetEventTimelineResponse(_message.Message):
    __slots__ = ("events", "next_page_token")
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[BehavioralEvent]
    next_page_token: str
    def __init__(self, events: _Optional[_Iterable[_Union[BehavioralEvent, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class BatchIngestEventsRequest(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[IngestEventRequest]
    def __init__(self, events: _Optional[_Iterable[_Union[IngestEventRequest, _Mapping]]] = ...) -> None: ...

class BatchIngestEventsResponse(_message.Message):
    __slots__ = ("total", "accepted", "flagged", "quarantined", "rejected", "results")
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    ACCEPTED_FIELD_NUMBER: _ClassVar[int]
    FLAGGED_FIELD_NUMBER: _ClassVar[int]
    QUARANTINED_FIELD_NUMBER: _ClassVar[int]
    REJECTED_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    total: int
    accepted: int
    flagged: int
    quarantined: int
    rejected: int
    results: _containers.RepeatedCompositeFieldContainer[IngestEventResponse]
    def __init__(self, total: _Optional[int] = ..., accepted: _Optional[int] = ..., flagged: _Optional[int] = ..., quarantined: _Optional[int] = ..., rejected: _Optional[int] = ..., results: _Optional[_Iterable[_Union[IngestEventResponse, _Mapping]]] = ...) -> None: ...
