from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GraphTrustedPerson(_message.Message):
    __slots__ = ("id", "tenant_id", "name", "relationship", "contact", "category", "role", "status", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    RELATIONSHIP_FIELD_NUMBER: _ClassVar[int]
    CONTACT_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    name: str
    relationship: str
    contact: str
    category: str
    role: str
    status: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., name: _Optional[str] = ..., relationship: _Optional[str] = ..., contact: _Optional[str] = ..., category: _Optional[str] = ..., role: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class TrustRelationship(_message.Message):
    __slots__ = ("id", "person_id", "trusted_person_id", "tenant_id", "priority", "available", "notes", "status", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TRUSTED_PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    person_id: str
    trusted_person_id: str
    tenant_id: str
    priority: int
    available: bool
    notes: str
    status: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., person_id: _Optional[str] = ..., trusted_person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., priority: _Optional[int] = ..., available: bool = ..., notes: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class AddTrustedPersonRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "name", "relationship", "contact", "category", "role", "priority", "available", "notes")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    RELATIONSHIP_FIELD_NUMBER: _ClassVar[int]
    CONTACT_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    name: str
    relationship: str
    contact: str
    category: str
    role: str
    priority: int
    available: bool
    notes: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., name: _Optional[str] = ..., relationship: _Optional[str] = ..., contact: _Optional[str] = ..., category: _Optional[str] = ..., role: _Optional[str] = ..., priority: _Optional[int] = ..., available: bool = ..., notes: _Optional[str] = ...) -> None: ...

class GetTrustRelationshipRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class ListTrustRelationshipsRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "page_size", "page_token")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    page_size: int
    page_token: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListTrustRelationshipsResponse(_message.Message):
    __slots__ = ("trust_relationships", "next_page_token")
    TRUST_RELATIONSHIPS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    trust_relationships: _containers.RepeatedCompositeFieldContainer[TrustRelationship]
    next_page_token: str
    def __init__(self, trust_relationships: _Optional[_Iterable[_Union[TrustRelationship, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class RemoveTrustRelationshipRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class RemoveTrustRelationshipResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
