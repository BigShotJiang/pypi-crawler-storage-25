from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExternalID(_message.Message):
    __slots__ = ("source", "id")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    source: str
    id: str
    def __init__(self, source: _Optional[str] = ..., id: _Optional[str] = ...) -> None: ...

class Person(_message.Message):
    __slots__ = ("id", "tenant_id", "external_ids", "first_name", "last_name", "date_of_birth", "grade", "status", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_IDS_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    DATE_OF_BIRTH_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    external_ids: _containers.RepeatedCompositeFieldContainer[ExternalID]
    first_name: str
    last_name: str
    date_of_birth: str
    grade: str
    status: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., external_ids: _Optional[_Iterable[_Union[ExternalID, _Mapping]]] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., date_of_birth: _Optional[str] = ..., grade: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class ResolvePersonRequest(_message.Message):
    __slots__ = ("tenant_id", "external_ids", "first_name", "last_name", "date_of_birth", "grade")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_IDS_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    DATE_OF_BIRTH_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    external_ids: _containers.RepeatedCompositeFieldContainer[ExternalID]
    first_name: str
    last_name: str
    date_of_birth: str
    grade: str
    def __init__(self, tenant_id: _Optional[str] = ..., external_ids: _Optional[_Iterable[_Union[ExternalID, _Mapping]]] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., date_of_birth: _Optional[str] = ..., grade: _Optional[str] = ...) -> None: ...

class GetPersonRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class LinkExternalIDRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "external_id")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    external_id: ExternalID
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., external_id: _Optional[_Union[ExternalID, _Mapping]] = ...) -> None: ...

class ListPersonsRequest(_message.Message):
    __slots__ = ("tenant_id", "page_size", "page_token")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    page_size: int
    page_token: str
    def __init__(self, tenant_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListPersonsResponse(_message.Message):
    __slots__ = ("persons", "next_page_token")
    PERSONS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    persons: _containers.RepeatedCompositeFieldContainer[Person]
    next_page_token: str
    def __init__(self, persons: _Optional[_Iterable[_Union[Person, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdatePersonRequest(_message.Message):
    __slots__ = ("id", "tenant_id", "first_name", "last_name", "date_of_birth", "grade")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    FIRST_NAME_FIELD_NUMBER: _ClassVar[int]
    LAST_NAME_FIELD_NUMBER: _ClassVar[int]
    DATE_OF_BIRTH_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    first_name: str
    last_name: str
    date_of_birth: str
    grade: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., first_name: _Optional[str] = ..., last_name: _Optional[str] = ..., date_of_birth: _Optional[str] = ..., grade: _Optional[str] = ...) -> None: ...

class DeletePersonRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class DeletePersonResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ErasePersonRequest(_message.Message):
    __slots__ = ("id", "tenant_id", "reason", "requested_by")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_BY_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    reason: str
    requested_by: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., reason: _Optional[str] = ..., requested_by: _Optional[str] = ...) -> None: ...

class ErasePersonResponse(_message.Message):
    __slots__ = ("id", "erased_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    ERASED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    erased_at: str
    def __init__(self, id: _Optional[str] = ..., erased_at: _Optional[str] = ...) -> None: ...
