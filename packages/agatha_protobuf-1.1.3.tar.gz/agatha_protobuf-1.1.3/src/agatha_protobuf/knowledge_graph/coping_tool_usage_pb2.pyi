from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ToolUsage(_message.Message):
    __slots__ = ("id", "person_id", "coping_tool_id", "tenant_id", "before_mood", "after_mood", "risk_context", "timestamp", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    COPING_TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    BEFORE_MOOD_FIELD_NUMBER: _ClassVar[int]
    AFTER_MOOD_FIELD_NUMBER: _ClassVar[int]
    RISK_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    person_id: str
    coping_tool_id: str
    tenant_id: str
    before_mood: float
    after_mood: float
    risk_context: str
    timestamp: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., person_id: _Optional[str] = ..., coping_tool_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., before_mood: _Optional[float] = ..., after_mood: _Optional[float] = ..., risk_context: _Optional[str] = ..., timestamp: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class RecordToolUsageRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "coping_tool_id", "before_mood", "after_mood", "risk_context", "timestamp")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    COPING_TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    BEFORE_MOOD_FIELD_NUMBER: _ClassVar[int]
    AFTER_MOOD_FIELD_NUMBER: _ClassVar[int]
    RISK_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    coping_tool_id: str
    before_mood: float
    after_mood: float
    risk_context: str
    timestamp: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., coping_tool_id: _Optional[str] = ..., before_mood: _Optional[float] = ..., after_mood: _Optional[float] = ..., risk_context: _Optional[str] = ..., timestamp: _Optional[str] = ...) -> None: ...

class GetToolUsageRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class ListToolUsagesRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "coping_tool_id", "page_size", "page_token")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    COPING_TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    coping_tool_id: str
    page_size: int
    page_token: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., coping_tool_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListToolUsagesResponse(_message.Message):
    __slots__ = ("tool_usages", "next_page_token")
    TOOL_USAGES_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    tool_usages: _containers.RepeatedCompositeFieldContainer[ToolUsage]
    next_page_token: str
    def __init__(self, tool_usages: _Optional[_Iterable[_Union[ToolUsage, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...
