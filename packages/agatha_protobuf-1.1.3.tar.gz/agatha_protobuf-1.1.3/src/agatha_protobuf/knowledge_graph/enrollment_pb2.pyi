from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Organization(_message.Message):
    __slots__ = ("id", "tenant_id", "name", "type", "address", "district", "status", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    DISTRICT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    name: str
    type: str
    address: str
    district: str
    status: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., name: _Optional[str] = ..., type: _Optional[str] = ..., address: _Optional[str] = ..., district: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class Enrollment(_message.Message):
    __slots__ = ("id", "person_id", "organization_id", "tenant_id", "role", "grade", "start_date", "end_date", "status", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    person_id: str
    organization_id: str
    tenant_id: str
    role: str
    grade: str
    start_date: str
    end_date: str
    status: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., person_id: _Optional[str] = ..., organization_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., role: _Optional[str] = ..., grade: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class EnrollPersonRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "organization_name", "organization_type", "role", "grade", "start_date")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_NAME_FIELD_NUMBER: _ClassVar[int]
    ORGANIZATION_TYPE_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    organization_name: str
    organization_type: str
    role: str
    grade: str
    start_date: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., organization_name: _Optional[str] = ..., organization_type: _Optional[str] = ..., role: _Optional[str] = ..., grade: _Optional[str] = ..., start_date: _Optional[str] = ...) -> None: ...

class GetEnrollmentRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class ListEnrollmentsRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "page_size", "page_token")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    page_size: int
    page_token: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListEnrollmentsResponse(_message.Message):
    __slots__ = ("enrollments", "next_page_token")
    ENROLLMENTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    enrollments: _containers.RepeatedCompositeFieldContainer[Enrollment]
    next_page_token: str
    def __init__(self, enrollments: _Optional[_Iterable[_Union[Enrollment, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class RemoveEnrollmentRequest(_message.Message):
    __slots__ = ("id", "tenant_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class RemoveEnrollmentResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
