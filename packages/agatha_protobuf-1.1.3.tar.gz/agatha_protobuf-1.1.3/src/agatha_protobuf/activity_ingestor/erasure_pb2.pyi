from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class EraseUserDataRequest(_message.Message):
    __slots__ = ("user_id", "tenant_id")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    tenant_id: str
    def __init__(self, user_id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class EraseUserDataResponse(_message.Message):
    __slots__ = ("user_id", "records_erased")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    RECORDS_ERASED_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    records_erased: int
    def __init__(self, user_id: _Optional[str] = ..., records_erased: _Optional[int] = ...) -> None: ...
