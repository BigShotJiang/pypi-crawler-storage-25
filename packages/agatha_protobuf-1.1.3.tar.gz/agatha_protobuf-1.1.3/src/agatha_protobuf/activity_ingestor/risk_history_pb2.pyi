from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RiskHistory(_message.Message):
    __slots__ = ("id", "user", "risk_level", "risk_type", "description", "source", "flagged", "resolved_at", "severity", "recommendations", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    RISK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    RISK_TYPE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    FLAGGED_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_AT_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    RECOMMENDATIONS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    risk_level: int
    risk_type: str
    description: str
    source: str
    flagged: bool
    resolved_at: str
    severity: str
    recommendations: _containers.RepeatedScalarFieldContainer[str]
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., risk_level: _Optional[int] = ..., risk_type: _Optional[str] = ..., description: _Optional[str] = ..., source: _Optional[str] = ..., flagged: bool = ..., resolved_at: _Optional[str] = ..., severity: _Optional[str] = ..., recommendations: _Optional[_Iterable[str]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateRiskHistoryRequest(_message.Message):
    __slots__ = ("user", "risk_level", "risk_type", "description", "source", "flagged", "resolved_at", "severity", "recommendations")
    USER_FIELD_NUMBER: _ClassVar[int]
    RISK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    RISK_TYPE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    FLAGGED_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_AT_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    RECOMMENDATIONS_FIELD_NUMBER: _ClassVar[int]
    user: str
    risk_level: int
    risk_type: str
    description: str
    source: str
    flagged: bool
    resolved_at: str
    severity: str
    recommendations: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, user: _Optional[str] = ..., risk_level: _Optional[int] = ..., risk_type: _Optional[str] = ..., description: _Optional[str] = ..., source: _Optional[str] = ..., flagged: bool = ..., resolved_at: _Optional[str] = ..., severity: _Optional[str] = ..., recommendations: _Optional[_Iterable[str]] = ...) -> None: ...

class GetRiskHistoryRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListRiskHistoriesRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListRiskHistoriesResponse(_message.Message):
    __slots__ = ("risk_histories", "next_page_token")
    RISK_HISTORIES_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    risk_histories: _containers.RepeatedCompositeFieldContainer[RiskHistory]
    next_page_token: str
    def __init__(self, risk_histories: _Optional[_Iterable[_Union[RiskHistory, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateRiskHistoryRequest(_message.Message):
    __slots__ = ("id", "risk_level", "risk_type", "description", "source", "flagged", "resolved_at", "severity", "recommendations")
    ID_FIELD_NUMBER: _ClassVar[int]
    RISK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    RISK_TYPE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    FLAGGED_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_AT_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    RECOMMENDATIONS_FIELD_NUMBER: _ClassVar[int]
    id: str
    risk_level: int
    risk_type: str
    description: str
    source: str
    flagged: bool
    resolved_at: str
    severity: str
    recommendations: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, id: _Optional[str] = ..., risk_level: _Optional[int] = ..., risk_type: _Optional[str] = ..., description: _Optional[str] = ..., source: _Optional[str] = ..., flagged: bool = ..., resolved_at: _Optional[str] = ..., severity: _Optional[str] = ..., recommendations: _Optional[_Iterable[str]] = ...) -> None: ...

class DeleteRiskHistoryRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteRiskHistoryResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
