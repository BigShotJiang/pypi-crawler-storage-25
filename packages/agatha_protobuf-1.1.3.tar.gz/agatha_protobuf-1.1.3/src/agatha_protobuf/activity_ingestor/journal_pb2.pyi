from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Journal(_message.Message):
    __slots__ = ("id", "user", "title", "content", "mood", "tags", "sentiment", "keywords", "entities", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    MOOD_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    SENTIMENT_FIELD_NUMBER: _ClassVar[int]
    KEYWORDS_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    title: str
    content: str
    mood: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    sentiment: float
    keywords: _containers.RepeatedScalarFieldContainer[str]
    entities: _containers.RepeatedScalarFieldContainer[str]
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., title: _Optional[str] = ..., content: _Optional[str] = ..., mood: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., sentiment: _Optional[float] = ..., keywords: _Optional[_Iterable[str]] = ..., entities: _Optional[_Iterable[str]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateJournalRequest(_message.Message):
    __slots__ = ("user", "title", "content", "mood", "tags", "sentiment", "keywords", "entities")
    USER_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    MOOD_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    SENTIMENT_FIELD_NUMBER: _ClassVar[int]
    KEYWORDS_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    user: str
    title: str
    content: str
    mood: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    sentiment: float
    keywords: _containers.RepeatedScalarFieldContainer[str]
    entities: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, user: _Optional[str] = ..., title: _Optional[str] = ..., content: _Optional[str] = ..., mood: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., sentiment: _Optional[float] = ..., keywords: _Optional[_Iterable[str]] = ..., entities: _Optional[_Iterable[str]] = ...) -> None: ...

class GetJournalRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListJournalsRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListJournalsResponse(_message.Message):
    __slots__ = ("journals", "next_page_token")
    JOURNALS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    journals: _containers.RepeatedCompositeFieldContainer[Journal]
    next_page_token: str
    def __init__(self, journals: _Optional[_Iterable[_Union[Journal, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateJournalRequest(_message.Message):
    __slots__ = ("id", "title", "content", "mood", "tags", "sentiment", "keywords", "entities")
    ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    MOOD_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    SENTIMENT_FIELD_NUMBER: _ClassVar[int]
    KEYWORDS_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    id: str
    title: str
    content: str
    mood: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    sentiment: float
    keywords: _containers.RepeatedScalarFieldContainer[str]
    entities: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, id: _Optional[str] = ..., title: _Optional[str] = ..., content: _Optional[str] = ..., mood: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., sentiment: _Optional[float] = ..., keywords: _Optional[_Iterable[str]] = ..., entities: _Optional[_Iterable[str]] = ...) -> None: ...

class DeleteJournalRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteJournalResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
