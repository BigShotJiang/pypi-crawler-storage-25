from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class WinGratitude(_message.Message):
    __slots__ = ("id", "user", "type", "title", "description", "category", "emotion", "related_goal", "shared_with", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    EMOTION_FIELD_NUMBER: _ClassVar[int]
    RELATED_GOAL_FIELD_NUMBER: _ClassVar[int]
    SHARED_WITH_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    type: str
    title: str
    description: str
    category: str
    emotion: str
    related_goal: str
    shared_with: _containers.RepeatedScalarFieldContainer[str]
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., type: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., emotion: _Optional[str] = ..., related_goal: _Optional[str] = ..., shared_with: _Optional[_Iterable[str]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateWinGratitudeRequest(_message.Message):
    __slots__ = ("user", "type", "title", "description", "category", "emotion", "related_goal", "shared_with")
    USER_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    EMOTION_FIELD_NUMBER: _ClassVar[int]
    RELATED_GOAL_FIELD_NUMBER: _ClassVar[int]
    SHARED_WITH_FIELD_NUMBER: _ClassVar[int]
    user: str
    type: str
    title: str
    description: str
    category: str
    emotion: str
    related_goal: str
    shared_with: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, user: _Optional[str] = ..., type: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., emotion: _Optional[str] = ..., related_goal: _Optional[str] = ..., shared_with: _Optional[_Iterable[str]] = ...) -> None: ...

class GetWinGratitudeRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListWinGratitudesRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListWinGratitudesResponse(_message.Message):
    __slots__ = ("win_gratitudes", "next_page_token")
    WIN_GRATITUDES_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    win_gratitudes: _containers.RepeatedCompositeFieldContainer[WinGratitude]
    next_page_token: str
    def __init__(self, win_gratitudes: _Optional[_Iterable[_Union[WinGratitude, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateWinGratitudeRequest(_message.Message):
    __slots__ = ("id", "type", "title", "description", "category", "emotion", "related_goal", "shared_with")
    ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    EMOTION_FIELD_NUMBER: _ClassVar[int]
    RELATED_GOAL_FIELD_NUMBER: _ClassVar[int]
    SHARED_WITH_FIELD_NUMBER: _ClassVar[int]
    id: str
    type: str
    title: str
    description: str
    category: str
    emotion: str
    related_goal: str
    shared_with: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, id: _Optional[str] = ..., type: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., emotion: _Optional[str] = ..., related_goal: _Optional[str] = ..., shared_with: _Optional[_Iterable[str]] = ...) -> None: ...

class DeleteWinGratitudeRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteWinGratitudeResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
