from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SubjectGrade(_message.Message):
    __slots__ = ("subject", "score", "grade")
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    subject: str
    score: float
    grade: str
    def __init__(self, subject: _Optional[str] = ..., score: _Optional[float] = ..., grade: _Optional[str] = ...) -> None: ...

class SchoolInfo(_message.Message):
    __slots__ = ("id", "user", "school_name", "grade", "subjects", "performance", "notes", "grades", "attendance", "semester", "year", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    SCHOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    SUBJECTS_FIELD_NUMBER: _ClassVar[int]
    PERFORMANCE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    GRADES_FIELD_NUMBER: _ClassVar[int]
    ATTENDANCE_FIELD_NUMBER: _ClassVar[int]
    SEMESTER_FIELD_NUMBER: _ClassVar[int]
    YEAR_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    school_name: str
    grade: str
    subjects: _containers.RepeatedScalarFieldContainer[str]
    performance: str
    notes: str
    grades: _containers.RepeatedCompositeFieldContainer[SubjectGrade]
    attendance: float
    semester: str
    year: int
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., school_name: _Optional[str] = ..., grade: _Optional[str] = ..., subjects: _Optional[_Iterable[str]] = ..., performance: _Optional[str] = ..., notes: _Optional[str] = ..., grades: _Optional[_Iterable[_Union[SubjectGrade, _Mapping]]] = ..., attendance: _Optional[float] = ..., semester: _Optional[str] = ..., year: _Optional[int] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateSchoolInfoRequest(_message.Message):
    __slots__ = ("user", "school_name", "grade", "subjects", "performance", "notes", "grades", "attendance", "semester", "year")
    USER_FIELD_NUMBER: _ClassVar[int]
    SCHOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    SUBJECTS_FIELD_NUMBER: _ClassVar[int]
    PERFORMANCE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    GRADES_FIELD_NUMBER: _ClassVar[int]
    ATTENDANCE_FIELD_NUMBER: _ClassVar[int]
    SEMESTER_FIELD_NUMBER: _ClassVar[int]
    YEAR_FIELD_NUMBER: _ClassVar[int]
    user: str
    school_name: str
    grade: str
    subjects: _containers.RepeatedScalarFieldContainer[str]
    performance: str
    notes: str
    grades: _containers.RepeatedCompositeFieldContainer[SubjectGrade]
    attendance: float
    semester: str
    year: int
    def __init__(self, user: _Optional[str] = ..., school_name: _Optional[str] = ..., grade: _Optional[str] = ..., subjects: _Optional[_Iterable[str]] = ..., performance: _Optional[str] = ..., notes: _Optional[str] = ..., grades: _Optional[_Iterable[_Union[SubjectGrade, _Mapping]]] = ..., attendance: _Optional[float] = ..., semester: _Optional[str] = ..., year: _Optional[int] = ...) -> None: ...

class GetSchoolInfoRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListSchoolInfosRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListSchoolInfosResponse(_message.Message):
    __slots__ = ("school_infos", "next_page_token")
    SCHOOL_INFOS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    school_infos: _containers.RepeatedCompositeFieldContainer[SchoolInfo]
    next_page_token: str
    def __init__(self, school_infos: _Optional[_Iterable[_Union[SchoolInfo, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateSchoolInfoRequest(_message.Message):
    __slots__ = ("id", "school_name", "grade", "subjects", "performance", "notes", "grades", "attendance", "semester", "year")
    ID_FIELD_NUMBER: _ClassVar[int]
    SCHOOL_NAME_FIELD_NUMBER: _ClassVar[int]
    GRADE_FIELD_NUMBER: _ClassVar[int]
    SUBJECTS_FIELD_NUMBER: _ClassVar[int]
    PERFORMANCE_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    GRADES_FIELD_NUMBER: _ClassVar[int]
    ATTENDANCE_FIELD_NUMBER: _ClassVar[int]
    SEMESTER_FIELD_NUMBER: _ClassVar[int]
    YEAR_FIELD_NUMBER: _ClassVar[int]
    id: str
    school_name: str
    grade: str
    subjects: _containers.RepeatedScalarFieldContainer[str]
    performance: str
    notes: str
    grades: _containers.RepeatedCompositeFieldContainer[SubjectGrade]
    attendance: float
    semester: str
    year: int
    def __init__(self, id: _Optional[str] = ..., school_name: _Optional[str] = ..., grade: _Optional[str] = ..., subjects: _Optional[_Iterable[str]] = ..., performance: _Optional[str] = ..., notes: _Optional[str] = ..., grades: _Optional[_Iterable[_Union[SubjectGrade, _Mapping]]] = ..., attendance: _Optional[float] = ..., semester: _Optional[str] = ..., year: _Optional[int] = ...) -> None: ...

class DeleteSchoolInfoRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteSchoolInfoResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
