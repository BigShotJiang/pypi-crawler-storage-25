from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MoodEntry(_message.Message):
    __slots__ = ("id", "intensity", "context", "source")
    ID_FIELD_NUMBER: _ClassVar[int]
    INTENSITY_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    id: str
    intensity: int
    context: str
    source: str
    def __init__(self, id: _Optional[str] = ..., intensity: _Optional[int] = ..., context: _Optional[str] = ..., source: _Optional[str] = ...) -> None: ...

class MoodHistory(_message.Message):
    __slots__ = ("id", "user", "mood", "note", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    MOOD_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    mood: _containers.RepeatedCompositeFieldContainer[MoodEntry]
    note: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., mood: _Optional[_Iterable[_Union[MoodEntry, _Mapping]]] = ..., note: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateMoodHistoryRequest(_message.Message):
    __slots__ = ("user", "mood", "note")
    USER_FIELD_NUMBER: _ClassVar[int]
    MOOD_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    user: str
    mood: _containers.RepeatedCompositeFieldContainer[MoodEntry]
    note: str
    def __init__(self, user: _Optional[str] = ..., mood: _Optional[_Iterable[_Union[MoodEntry, _Mapping]]] = ..., note: _Optional[str] = ...) -> None: ...

class GetMoodHistoryRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListMoodHistoriesRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token", "mood")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    MOOD_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    mood: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ..., mood: _Optional[str] = ...) -> None: ...

class ListMoodHistoriesResponse(_message.Message):
    __slots__ = ("mood_histories", "next_page_token")
    MOOD_HISTORIES_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    mood_histories: _containers.RepeatedCompositeFieldContainer[MoodHistory]
    next_page_token: str
    def __init__(self, mood_histories: _Optional[_Iterable[_Union[MoodHistory, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateMoodHistoryRequest(_message.Message):
    __slots__ = ("id", "mood", "note")
    ID_FIELD_NUMBER: _ClassVar[int]
    MOOD_FIELD_NUMBER: _ClassVar[int]
    NOTE_FIELD_NUMBER: _ClassVar[int]
    id: str
    mood: _containers.RepeatedCompositeFieldContainer[MoodEntry]
    note: str
    def __init__(self, id: _Optional[str] = ..., mood: _Optional[_Iterable[_Union[MoodEntry, _Mapping]]] = ..., note: _Optional[str] = ...) -> None: ...

class DeleteMoodHistoryRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteMoodHistoryResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
