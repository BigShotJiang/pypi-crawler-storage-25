from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Milestone(_message.Message):
    __slots__ = ("title", "completed")
    TITLE_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_FIELD_NUMBER: _ClassVar[int]
    title: str
    completed: bool
    def __init__(self, title: _Optional[str] = ..., completed: bool = ...) -> None: ...

class PersonalGoal(_message.Message):
    __slots__ = ("id", "user", "title", "description", "category", "status", "target_date", "progress", "target", "next_check_in", "streak", "milestones", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TARGET_DATE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    NEXT_CHECK_IN_FIELD_NUMBER: _ClassVar[int]
    STREAK_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    title: str
    description: str
    category: str
    status: str
    target_date: str
    progress: int
    target: str
    next_check_in: str
    streak: int
    milestones: _containers.RepeatedCompositeFieldContainer[Milestone]
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., status: _Optional[str] = ..., target_date: _Optional[str] = ..., progress: _Optional[int] = ..., target: _Optional[str] = ..., next_check_in: _Optional[str] = ..., streak: _Optional[int] = ..., milestones: _Optional[_Iterable[_Union[Milestone, _Mapping]]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreatePersonalGoalRequest(_message.Message):
    __slots__ = ("user", "title", "description", "category", "status", "target_date", "progress", "target", "next_check_in", "streak", "milestones")
    USER_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TARGET_DATE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    NEXT_CHECK_IN_FIELD_NUMBER: _ClassVar[int]
    STREAK_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    user: str
    title: str
    description: str
    category: str
    status: str
    target_date: str
    progress: int
    target: str
    next_check_in: str
    streak: int
    milestones: _containers.RepeatedCompositeFieldContainer[Milestone]
    def __init__(self, user: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., status: _Optional[str] = ..., target_date: _Optional[str] = ..., progress: _Optional[int] = ..., target: _Optional[str] = ..., next_check_in: _Optional[str] = ..., streak: _Optional[int] = ..., milestones: _Optional[_Iterable[_Union[Milestone, _Mapping]]] = ...) -> None: ...

class GetPersonalGoalRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListPersonalGoalsRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListPersonalGoalsResponse(_message.Message):
    __slots__ = ("personal_goals", "next_page_token")
    PERSONAL_GOALS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    personal_goals: _containers.RepeatedCompositeFieldContainer[PersonalGoal]
    next_page_token: str
    def __init__(self, personal_goals: _Optional[_Iterable[_Union[PersonalGoal, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdatePersonalGoalRequest(_message.Message):
    __slots__ = ("id", "title", "description", "category", "status", "target_date", "progress", "target", "next_check_in", "streak", "milestones")
    ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TARGET_DATE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    NEXT_CHECK_IN_FIELD_NUMBER: _ClassVar[int]
    STREAK_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    id: str
    title: str
    description: str
    category: str
    status: str
    target_date: str
    progress: int
    target: str
    next_check_in: str
    streak: int
    milestones: _containers.RepeatedCompositeFieldContainer[Milestone]
    def __init__(self, id: _Optional[str] = ..., title: _Optional[str] = ..., description: _Optional[str] = ..., category: _Optional[str] = ..., status: _Optional[str] = ..., target_date: _Optional[str] = ..., progress: _Optional[int] = ..., target: _Optional[str] = ..., next_check_in: _Optional[str] = ..., streak: _Optional[int] = ..., milestones: _Optional[_Iterable[_Union[Milestone, _Mapping]]] = ...) -> None: ...

class DeletePersonalGoalRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeletePersonalGoalResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
