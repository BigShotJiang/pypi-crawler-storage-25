from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TrustedPerson(_message.Message):
    __slots__ = ("id", "user", "name", "relationship", "contact", "notes", "category", "role", "priority", "available", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    RELATIONSHIP_FIELD_NUMBER: _ClassVar[int]
    CONTACT_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    name: str
    relationship: str
    contact: str
    notes: str
    category: str
    role: str
    priority: int
    available: bool
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., name: _Optional[str] = ..., relationship: _Optional[str] = ..., contact: _Optional[str] = ..., notes: _Optional[str] = ..., category: _Optional[str] = ..., role: _Optional[str] = ..., priority: _Optional[int] = ..., available: bool = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateTrustedPersonRequest(_message.Message):
    __slots__ = ("user", "name", "relationship", "contact", "notes", "category", "role", "priority", "available")
    USER_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    RELATIONSHIP_FIELD_NUMBER: _ClassVar[int]
    CONTACT_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    user: str
    name: str
    relationship: str
    contact: str
    notes: str
    category: str
    role: str
    priority: int
    available: bool
    def __init__(self, user: _Optional[str] = ..., name: _Optional[str] = ..., relationship: _Optional[str] = ..., contact: _Optional[str] = ..., notes: _Optional[str] = ..., category: _Optional[str] = ..., role: _Optional[str] = ..., priority: _Optional[int] = ..., available: bool = ...) -> None: ...

class GetTrustedPersonRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListTrustedPeopleRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListTrustedPeopleResponse(_message.Message):
    __slots__ = ("trusted_people", "next_page_token")
    TRUSTED_PEOPLE_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    trusted_people: _containers.RepeatedCompositeFieldContainer[TrustedPerson]
    next_page_token: str
    def __init__(self, trusted_people: _Optional[_Iterable[_Union[TrustedPerson, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateTrustedPersonRequest(_message.Message):
    __slots__ = ("id", "name", "relationship", "contact", "notes", "category", "role", "priority", "available")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    RELATIONSHIP_FIELD_NUMBER: _ClassVar[int]
    CONTACT_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    relationship: str
    contact: str
    notes: str
    category: str
    role: str
    priority: int
    available: bool
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., relationship: _Optional[str] = ..., contact: _Optional[str] = ..., notes: _Optional[str] = ..., category: _Optional[str] = ..., role: _Optional[str] = ..., priority: _Optional[int] = ..., available: bool = ...) -> None: ...

class DeleteTrustedPersonRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteTrustedPersonResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
