from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SurveyResponse(_message.Message):
    __slots__ = ("question", "answer", "score")
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    ANSWER_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    question: str
    answer: str
    score: int
    def __init__(self, question: _Optional[str] = ..., answer: _Optional[str] = ..., score: _Optional[int] = ...) -> None: ...

class MiniSurvey(_message.Message):
    __slots__ = ("id", "user", "survey_type", "responses", "score", "completed_at", "duration", "category", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    SURVEY_TYPE_FIELD_NUMBER: _ClassVar[int]
    RESPONSES_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    survey_type: str
    responses: _containers.RepeatedCompositeFieldContainer[SurveyResponse]
    score: int
    completed_at: str
    duration: int
    category: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., survey_type: _Optional[str] = ..., responses: _Optional[_Iterable[_Union[SurveyResponse, _Mapping]]] = ..., score: _Optional[int] = ..., completed_at: _Optional[str] = ..., duration: _Optional[int] = ..., category: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateMiniSurveyRequest(_message.Message):
    __slots__ = ("user", "survey_type", "responses", "score", "completed_at", "duration", "category")
    USER_FIELD_NUMBER: _ClassVar[int]
    SURVEY_TYPE_FIELD_NUMBER: _ClassVar[int]
    RESPONSES_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    user: str
    survey_type: str
    responses: _containers.RepeatedCompositeFieldContainer[SurveyResponse]
    score: int
    completed_at: str
    duration: int
    category: str
    def __init__(self, user: _Optional[str] = ..., survey_type: _Optional[str] = ..., responses: _Optional[_Iterable[_Union[SurveyResponse, _Mapping]]] = ..., score: _Optional[int] = ..., completed_at: _Optional[str] = ..., duration: _Optional[int] = ..., category: _Optional[str] = ...) -> None: ...

class GetMiniSurveyRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListMiniSurveysRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListMiniSurveysResponse(_message.Message):
    __slots__ = ("mini_surveys", "next_page_token")
    MINI_SURVEYS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    mini_surveys: _containers.RepeatedCompositeFieldContainer[MiniSurvey]
    next_page_token: str
    def __init__(self, mini_surveys: _Optional[_Iterable[_Union[MiniSurvey, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateMiniSurveyRequest(_message.Message):
    __slots__ = ("id", "survey_type", "responses", "score", "completed_at", "duration", "category")
    ID_FIELD_NUMBER: _ClassVar[int]
    SURVEY_TYPE_FIELD_NUMBER: _ClassVar[int]
    RESPONSES_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    id: str
    survey_type: str
    responses: _containers.RepeatedCompositeFieldContainer[SurveyResponse]
    score: int
    completed_at: str
    duration: int
    category: str
    def __init__(self, id: _Optional[str] = ..., survey_type: _Optional[str] = ..., responses: _Optional[_Iterable[_Union[SurveyResponse, _Mapping]]] = ..., score: _Optional[int] = ..., completed_at: _Optional[str] = ..., duration: _Optional[int] = ..., category: _Optional[str] = ...) -> None: ...

class DeleteMiniSurveyRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteMiniSurveyResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
