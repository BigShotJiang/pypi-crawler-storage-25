from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SleepProfile(_message.Message):
    __slots__ = ("id", "user", "hours_slept", "quality", "bed_time", "wake_time", "notes", "disruptions", "environment", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    HOURS_SLEPT_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    BED_TIME_FIELD_NUMBER: _ClassVar[int]
    WAKE_TIME_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    DISRUPTIONS_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    user: str
    hours_slept: float
    quality: int
    bed_time: str
    wake_time: str
    notes: str
    disruptions: int
    environment: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., user: _Optional[str] = ..., hours_slept: _Optional[float] = ..., quality: _Optional[int] = ..., bed_time: _Optional[str] = ..., wake_time: _Optional[str] = ..., notes: _Optional[str] = ..., disruptions: _Optional[int] = ..., environment: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateSleepProfileRequest(_message.Message):
    __slots__ = ("user", "hours_slept", "quality", "bed_time", "wake_time", "notes", "disruptions", "environment")
    USER_FIELD_NUMBER: _ClassVar[int]
    HOURS_SLEPT_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    BED_TIME_FIELD_NUMBER: _ClassVar[int]
    WAKE_TIME_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    DISRUPTIONS_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    user: str
    hours_slept: float
    quality: int
    bed_time: str
    wake_time: str
    notes: str
    disruptions: int
    environment: str
    def __init__(self, user: _Optional[str] = ..., hours_slept: _Optional[float] = ..., quality: _Optional[int] = ..., bed_time: _Optional[str] = ..., wake_time: _Optional[str] = ..., notes: _Optional[str] = ..., disruptions: _Optional[int] = ..., environment: _Optional[str] = ...) -> None: ...

class GetSleepProfileRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListSleepProfilesRequest(_message.Message):
    __slots__ = ("user", "page_size", "page_token")
    USER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    user: str
    page_size: int
    page_token: str
    def __init__(self, user: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListSleepProfilesResponse(_message.Message):
    __slots__ = ("sleep_profiles", "next_page_token")
    SLEEP_PROFILES_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    sleep_profiles: _containers.RepeatedCompositeFieldContainer[SleepProfile]
    next_page_token: str
    def __init__(self, sleep_profiles: _Optional[_Iterable[_Union[SleepProfile, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateSleepProfileRequest(_message.Message):
    __slots__ = ("id", "hours_slept", "quality", "bed_time", "wake_time", "notes", "disruptions", "environment")
    ID_FIELD_NUMBER: _ClassVar[int]
    HOURS_SLEPT_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    BED_TIME_FIELD_NUMBER: _ClassVar[int]
    WAKE_TIME_FIELD_NUMBER: _ClassVar[int]
    NOTES_FIELD_NUMBER: _ClassVar[int]
    DISRUPTIONS_FIELD_NUMBER: _ClassVar[int]
    ENVIRONMENT_FIELD_NUMBER: _ClassVar[int]
    id: str
    hours_slept: float
    quality: int
    bed_time: str
    wake_time: str
    notes: str
    disruptions: int
    environment: str
    def __init__(self, id: _Optional[str] = ..., hours_slept: _Optional[float] = ..., quality: _Optional[int] = ..., bed_time: _Optional[str] = ..., wake_time: _Optional[str] = ..., notes: _Optional[str] = ..., disruptions: _Optional[int] = ..., environment: _Optional[str] = ...) -> None: ...

class DeleteSleepProfileRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteSleepProfileResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...
