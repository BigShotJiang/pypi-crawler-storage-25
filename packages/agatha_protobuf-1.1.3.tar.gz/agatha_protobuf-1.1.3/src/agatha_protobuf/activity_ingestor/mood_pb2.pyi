from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Asset(_message.Message):
    __slots__ = ("type", "url")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    type: str
    url: str
    def __init__(self, type: _Optional[str] = ..., url: _Optional[str] = ...) -> None: ...

class Tip(_message.Message):
    __slots__ = ("description", "link", "title")
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    LINK_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    description: str
    link: str
    title: str
    def __init__(self, description: _Optional[str] = ..., link: _Optional[str] = ..., title: _Optional[str] = ...) -> None: ...

class MoodCategory(_message.Message):
    __slots__ = ("id", "label", "identifier", "order", "platform")
    ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    PLATFORM_FIELD_NUMBER: _ClassVar[int]
    id: str
    label: str
    identifier: str
    order: int
    platform: str
    def __init__(self, id: _Optional[str] = ..., label: _Optional[str] = ..., identifier: _Optional[str] = ..., order: _Optional[int] = ..., platform: _Optional[str] = ...) -> None: ...

class Mood(_message.Message):
    __slots__ = ("id", "color", "cover", "description", "identifier", "label", "category", "order", "text_color", "tips", "video")
    ID_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    COVER_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    TEXT_COLOR_FIELD_NUMBER: _ClassVar[int]
    TIPS_FIELD_NUMBER: _ClassVar[int]
    VIDEO_FIELD_NUMBER: _ClassVar[int]
    id: str
    color: str
    cover: Asset
    description: str
    identifier: str
    label: str
    category: MoodCategory
    order: int
    text_color: str
    tips: _containers.RepeatedCompositeFieldContainer[Tip]
    video: Asset
    def __init__(self, id: _Optional[str] = ..., color: _Optional[str] = ..., cover: _Optional[_Union[Asset, _Mapping]] = ..., description: _Optional[str] = ..., identifier: _Optional[str] = ..., label: _Optional[str] = ..., category: _Optional[_Union[MoodCategory, _Mapping]] = ..., order: _Optional[int] = ..., text_color: _Optional[str] = ..., tips: _Optional[_Iterable[_Union[Tip, _Mapping]]] = ..., video: _Optional[_Union[Asset, _Mapping]] = ...) -> None: ...

class CreateMoodRequest(_message.Message):
    __slots__ = ("color", "cover", "description", "identifier", "label", "category", "order", "text_color", "tips", "video")
    COLOR_FIELD_NUMBER: _ClassVar[int]
    COVER_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    TEXT_COLOR_FIELD_NUMBER: _ClassVar[int]
    TIPS_FIELD_NUMBER: _ClassVar[int]
    VIDEO_FIELD_NUMBER: _ClassVar[int]
    color: str
    cover: Asset
    description: str
    identifier: str
    label: str
    category: str
    order: int
    text_color: str
    tips: _containers.RepeatedCompositeFieldContainer[Tip]
    video: Asset
    def __init__(self, color: _Optional[str] = ..., cover: _Optional[_Union[Asset, _Mapping]] = ..., description: _Optional[str] = ..., identifier: _Optional[str] = ..., label: _Optional[str] = ..., category: _Optional[str] = ..., order: _Optional[int] = ..., text_color: _Optional[str] = ..., tips: _Optional[_Iterable[_Union[Tip, _Mapping]]] = ..., video: _Optional[_Union[Asset, _Mapping]] = ...) -> None: ...

class UpdateMoodRequest(_message.Message):
    __slots__ = ("id", "color", "cover", "description", "identifier", "label", "category", "order", "text_color", "tips", "video")
    ID_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    COVER_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IDENTIFIER_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    TEXT_COLOR_FIELD_NUMBER: _ClassVar[int]
    TIPS_FIELD_NUMBER: _ClassVar[int]
    VIDEO_FIELD_NUMBER: _ClassVar[int]
    id: str
    color: str
    cover: Asset
    description: str
    identifier: str
    label: str
    category: str
    order: int
    text_color: str
    tips: _containers.RepeatedCompositeFieldContainer[Tip]
    video: Asset
    def __init__(self, id: _Optional[str] = ..., color: _Optional[str] = ..., cover: _Optional[_Union[Asset, _Mapping]] = ..., description: _Optional[str] = ..., identifier: _Optional[str] = ..., label: _Optional[str] = ..., category: _Optional[str] = ..., order: _Optional[int] = ..., text_color: _Optional[str] = ..., tips: _Optional[_Iterable[_Union[Tip, _Mapping]]] = ..., video: _Optional[_Union[Asset, _Mapping]] = ...) -> None: ...

class GetMoodRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteMoodRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class DeleteMoodResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class ListMoodsRequest(_message.Message):
    __slots__ = ("category",)
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    category: str
    def __init__(self, category: _Optional[str] = ...) -> None: ...

class ListMoodsResponse(_message.Message):
    __slots__ = ("moods",)
    MOODS_FIELD_NUMBER: _ClassVar[int]
    moods: _containers.RepeatedCompositeFieldContainer[Mood]
    def __init__(self, moods: _Optional[_Iterable[_Union[Mood, _Mapping]]] = ...) -> None: ...

class ListMoodCategoriesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListMoodCategoriesResponse(_message.Message):
    __slots__ = ("categories",)
    CATEGORIES_FIELD_NUMBER: _ClassVar[int]
    categories: _containers.RepeatedCompositeFieldContainer[MoodCategory]
    def __init__(self, categories: _Optional[_Iterable[_Union[MoodCategory, _Mapping]]] = ...) -> None: ...
