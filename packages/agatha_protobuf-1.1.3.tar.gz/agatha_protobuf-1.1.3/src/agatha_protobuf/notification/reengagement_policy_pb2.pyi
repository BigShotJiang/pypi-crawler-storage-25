from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class GetPolicyRequest(_message.Message):
    __slots__ = ("tenant",)
    TENANT_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    def __init__(self, tenant: _Optional[str] = ...) -> None: ...

class UpsertPolicyRequest(_message.Message):
    __slots__ = ("tenant", "frequency_cap_24h", "cooldown_min_between_modals", "critical_suppression_flag")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    FREQUENCY_CAP_24H_FIELD_NUMBER: _ClassVar[int]
    COOLDOWN_MIN_BETWEEN_MODALS_FIELD_NUMBER: _ClassVar[int]
    CRITICAL_SUPPRESSION_FLAG_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    frequency_cap_24h: int
    cooldown_min_between_modals: int
    critical_suppression_flag: bool
    def __init__(self, tenant: _Optional[str] = ..., frequency_cap_24h: _Optional[int] = ..., cooldown_min_between_modals: _Optional[int] = ..., critical_suppression_flag: bool = ...) -> None: ...

class ReengagementPolicy(_message.Message):
    __slots__ = ("tenant", "frequency_cap_24h", "cooldown_min_between_modals", "critical_suppression_flag")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    FREQUENCY_CAP_24H_FIELD_NUMBER: _ClassVar[int]
    COOLDOWN_MIN_BETWEEN_MODALS_FIELD_NUMBER: _ClassVar[int]
    CRITICAL_SUPPRESSION_FLAG_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    frequency_cap_24h: int
    cooldown_min_between_modals: int
    critical_suppression_flag: bool
    def __init__(self, tenant: _Optional[str] = ..., frequency_cap_24h: _Optional[int] = ..., cooldown_min_between_modals: _Optional[int] = ..., critical_suppression_flag: bool = ...) -> None: ...
