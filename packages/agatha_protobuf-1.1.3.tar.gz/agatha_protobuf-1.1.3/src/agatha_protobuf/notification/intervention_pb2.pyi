from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Pathway(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PATHWAY_UNSPECIFIED: _ClassVar[Pathway]
    ROUTINE: _ClassVar[Pathway]
    OBSERVATION: _ClassVar[Pathway]
    IMMEDIATE_SAFETY: _ClassVar[Pathway]

class SupportBlockType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SUPPORT_BLOCK_TYPE_UNSPECIFIED: _ClassVar[SupportBlockType]
    VALIDATION: _ClassVar[SupportBlockType]
    NORMALIZATION: _ClassVar[SupportBlockType]
    PSYCHOEDUCATION: _ClassVar[SupportBlockType]
PATHWAY_UNSPECIFIED: Pathway
ROUTINE: Pathway
OBSERVATION: Pathway
IMMEDIATE_SAFETY: Pathway
SUPPORT_BLOCK_TYPE_UNSPECIFIED: SupportBlockType
VALIDATION: SupportBlockType
NORMALIZATION: SupportBlockType
PSYCHOEDUCATION: SupportBlockType

class SupportBlock(_message.Message):
    __slots__ = ("type", "content", "order")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    type: SupportBlockType
    content: str
    order: int
    def __init__(self, type: _Optional[_Union[SupportBlockType, str]] = ..., content: _Optional[str] = ..., order: _Optional[int] = ...) -> None: ...

class InterventionTool(_message.Message):
    __slots__ = ("id", "name", "description", "tool_type")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TOOL_TYPE_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    description: str
    tool_type: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., tool_type: _Optional[str] = ...) -> None: ...

class ActionPayload(_message.Message):
    __slots__ = ("tools",)
    TOOLS_FIELD_NUMBER: _ClassVar[int]
    tools: _containers.RepeatedCompositeFieldContainer[InterventionTool]
    def __init__(self, tools: _Optional[_Iterable[_Union[InterventionTool, _Mapping]]] = ...) -> None: ...

class InterventionPayload(_message.Message):
    __slots__ = ("session_id", "pathway", "support_blocks", "action_payload")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    PATHWAY_FIELD_NUMBER: _ClassVar[int]
    SUPPORT_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    ACTION_PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    pathway: Pathway
    support_blocks: _containers.RepeatedCompositeFieldContainer[SupportBlock]
    action_payload: ActionPayload
    def __init__(self, session_id: _Optional[str] = ..., pathway: _Optional[_Union[Pathway, str]] = ..., support_blocks: _Optional[_Iterable[_Union[SupportBlock, _Mapping]]] = ..., action_payload: _Optional[_Union[ActionPayload, _Mapping]] = ...) -> None: ...

class GetInterventionRequest(_message.Message):
    __slots__ = ("student_id", "tenant", "risk_level")
    STUDENT_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    RISK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    student_id: str
    tenant: str
    risk_level: int
    def __init__(self, student_id: _Optional[str] = ..., tenant: _Optional[str] = ..., risk_level: _Optional[int] = ...) -> None: ...
