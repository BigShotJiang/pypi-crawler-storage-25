from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Webhook(_message.Message):
    __slots__ = ("id", "tenant", "name", "url", "events", "active", "deleted_at", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    DELETED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    name: str
    url: str
    events: _containers.RepeatedScalarFieldContainer[str]
    active: bool
    deleted_at: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., events: _Optional[_Iterable[str]] = ..., active: bool = ..., deleted_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateWebhookRequest(_message.Message):
    __slots__ = ("tenant", "name", "url", "events", "active")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    name: str
    url: str
    events: _containers.RepeatedScalarFieldContainer[str]
    active: bool
    def __init__(self, tenant: _Optional[str] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., events: _Optional[_Iterable[str]] = ..., active: bool = ...) -> None: ...

class GetWebhookRequest(_message.Message):
    __slots__ = ("id", "tenant")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class ListWebhooksRequest(_message.Message):
    __slots__ = ("tenant", "page_size", "page_token")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    page_size: int
    page_token: str
    def __init__(self, tenant: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListWebhooksResponse(_message.Message):
    __slots__ = ("webhooks", "next_page_token")
    WEBHOOKS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    webhooks: _containers.RepeatedCompositeFieldContainer[Webhook]
    next_page_token: str
    def __init__(self, webhooks: _Optional[_Iterable[_Union[Webhook, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class UpdateWebhookRequest(_message.Message):
    __slots__ = ("id", "tenant", "name", "url", "events", "active")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    name: str
    url: str
    events: _containers.RepeatedScalarFieldContainer[str]
    active: bool
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., events: _Optional[_Iterable[str]] = ..., active: bool = ...) -> None: ...

class DeleteWebhookRequest(_message.Message):
    __slots__ = ("id", "tenant")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class DeleteWebhookResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class SendEmailRequest(_message.Message):
    __slots__ = ("tenant", "template_name", "dynamic_data", "recipients", "from_name")
    class DynamicDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TENANT_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_NAME_FIELD_NUMBER: _ClassVar[int]
    DYNAMIC_DATA_FIELD_NUMBER: _ClassVar[int]
    RECIPIENTS_FIELD_NUMBER: _ClassVar[int]
    FROM_NAME_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    template_name: str
    dynamic_data: _containers.ScalarMap[str, str]
    recipients: _containers.RepeatedScalarFieldContainer[str]
    from_name: str
    def __init__(self, tenant: _Optional[str] = ..., template_name: _Optional[str] = ..., dynamic_data: _Optional[_Mapping[str, str]] = ..., recipients: _Optional[_Iterable[str]] = ..., from_name: _Optional[str] = ...) -> None: ...

class SendEmailResponse(_message.Message):
    __slots__ = ("notification_id", "status")
    NOTIFICATION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    notification_id: str
    status: str
    def __init__(self, notification_id: _Optional[str] = ..., status: _Optional[str] = ...) -> None: ...

class EmailNotification(_message.Message):
    __slots__ = ("id", "tenant", "template_name", "recipients", "status", "sg_message_id", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    TEMPLATE_NAME_FIELD_NUMBER: _ClassVar[int]
    RECIPIENTS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SG_MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    template_name: str
    recipients: _containers.RepeatedScalarFieldContainer[str]
    status: str
    sg_message_id: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., template_name: _Optional[str] = ..., recipients: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., sg_message_id: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class GetEmailNotificationRequest(_message.Message):
    __slots__ = ("id", "tenant")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class ListEmailNotificationsRequest(_message.Message):
    __slots__ = ("tenant", "status_filter", "page_size", "page_token")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    status_filter: str
    page_size: int
    page_token: str
    def __init__(self, tenant: _Optional[str] = ..., status_filter: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ...) -> None: ...

class ListEmailNotificationsResponse(_message.Message):
    __slots__ = ("notifications", "next_page_token")
    NOTIFICATIONS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    notifications: _containers.RepeatedCompositeFieldContainer[EmailNotification]
    next_page_token: str
    def __init__(self, notifications: _Optional[_Iterable[_Union[EmailNotification, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class EmailEvent(_message.Message):
    __slots__ = ("id", "notification_id", "event", "email", "timestamp", "sg_event_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    NOTIFICATION_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SG_EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    notification_id: str
    event: str
    email: str
    timestamp: int
    sg_event_id: str
    def __init__(self, id: _Optional[str] = ..., notification_id: _Optional[str] = ..., event: _Optional[str] = ..., email: _Optional[str] = ..., timestamp: _Optional[int] = ..., sg_event_id: _Optional[str] = ...) -> None: ...

class AlertContact(_message.Message):
    __slots__ = ("id", "tenant", "email", "name", "role", "active", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    email: str
    name: str
    role: str
    active: bool
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., email: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., active: bool = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateAlertContactRequest(_message.Message):
    __slots__ = ("tenant", "email", "name", "role", "active")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    email: str
    name: str
    role: str
    active: bool
    def __init__(self, tenant: _Optional[str] = ..., email: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., active: bool = ...) -> None: ...

class GetAlertContactRequest(_message.Message):
    __slots__ = ("id", "tenant")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class ListAlertContactsRequest(_message.Message):
    __slots__ = ("tenant",)
    TENANT_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    def __init__(self, tenant: _Optional[str] = ...) -> None: ...

class ListAlertContactsResponse(_message.Message):
    __slots__ = ("contacts",)
    CONTACTS_FIELD_NUMBER: _ClassVar[int]
    contacts: _containers.RepeatedCompositeFieldContainer[AlertContact]
    def __init__(self, contacts: _Optional[_Iterable[_Union[AlertContact, _Mapping]]] = ...) -> None: ...

class UpdateAlertContactRequest(_message.Message):
    __slots__ = ("id", "tenant", "email", "name", "role", "active")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    email: str
    name: str
    role: str
    active: bool
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., email: _Optional[str] = ..., name: _Optional[str] = ..., role: _Optional[str] = ..., active: bool = ...) -> None: ...

class DeleteAlertContactRequest(_message.Message):
    __slots__ = ("id", "tenant")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class DeleteAlertContactResponse(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class RiskAlert(_message.Message):
    __slots__ = ("id", "tenant_id", "person_id", "risk_level", "categorical", "pathway", "urgency", "compound_score", "sla_minutes", "requires_ack", "status", "acknowledged_at", "acknowledged_by", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    RISK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORICAL_FIELD_NUMBER: _ClassVar[int]
    PATHWAY_FIELD_NUMBER: _ClassVar[int]
    URGENCY_FIELD_NUMBER: _ClassVar[int]
    COMPOUND_SCORE_FIELD_NUMBER: _ClassVar[int]
    SLA_MINUTES_FIELD_NUMBER: _ClassVar[int]
    REQUIRES_ACK_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_AT_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_BY_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant_id: str
    person_id: str
    risk_level: int
    categorical: str
    pathway: str
    urgency: str
    compound_score: float
    sla_minutes: int
    requires_ack: bool
    status: str
    acknowledged_at: str
    acknowledged_by: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., person_id: _Optional[str] = ..., risk_level: _Optional[int] = ..., categorical: _Optional[str] = ..., pathway: _Optional[str] = ..., urgency: _Optional[str] = ..., compound_score: _Optional[float] = ..., sla_minutes: _Optional[int] = ..., requires_ack: bool = ..., status: _Optional[str] = ..., acknowledged_at: _Optional[str] = ..., acknowledged_by: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class GetRiskAlertRequest(_message.Message):
    __slots__ = ("id", "tenant")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class ListRiskAlertsRequest(_message.Message):
    __slots__ = ("tenant", "status_filter")
    TENANT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FILTER_FIELD_NUMBER: _ClassVar[int]
    tenant: str
    status_filter: str
    def __init__(self, tenant: _Optional[str] = ..., status_filter: _Optional[str] = ...) -> None: ...

class ListRiskAlertsResponse(_message.Message):
    __slots__ = ("alerts",)
    ALERTS_FIELD_NUMBER: _ClassVar[int]
    alerts: _containers.RepeatedCompositeFieldContainer[RiskAlert]
    def __init__(self, alerts: _Optional[_Iterable[_Union[RiskAlert, _Mapping]]] = ...) -> None: ...

class AcknowledgeRiskAlertRequest(_message.Message):
    __slots__ = ("id", "tenant", "acknowledged_by")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_BY_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    acknowledged_by: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., acknowledged_by: _Optional[str] = ...) -> None: ...

class UpdateRiskAlertRoutingStatusRequest(_message.Message):
    __slots__ = ("alert_id", "routing_status")
    ALERT_ID_FIELD_NUMBER: _ClassVar[int]
    ROUTING_STATUS_FIELD_NUMBER: _ClassVar[int]
    alert_id: str
    routing_status: str
    def __init__(self, alert_id: _Optional[str] = ..., routing_status: _Optional[str] = ...) -> None: ...

class UpdateRiskAlertRoutingStatusResponse(_message.Message):
    __slots__ = ("alert_id", "routing_status")
    ALERT_ID_FIELD_NUMBER: _ClassVar[int]
    ROUTING_STATUS_FIELD_NUMBER: _ClassVar[int]
    alert_id: str
    routing_status: str
    def __init__(self, alert_id: _Optional[str] = ..., routing_status: _Optional[str] = ...) -> None: ...
