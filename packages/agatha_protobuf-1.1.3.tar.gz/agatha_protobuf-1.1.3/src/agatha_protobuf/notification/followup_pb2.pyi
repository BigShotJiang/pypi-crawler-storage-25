from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ScheduleFollowupRequest(_message.Message):
    __slots__ = ("session_id", "student_id", "tenant", "current_risk_level")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    STUDENT_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    CURRENT_RISK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    student_id: str
    tenant: str
    current_risk_level: int
    def __init__(self, session_id: _Optional[str] = ..., student_id: _Optional[str] = ..., tenant: _Optional[str] = ..., current_risk_level: _Optional[int] = ...) -> None: ...

class FollowUpSchedule(_message.Message):
    __slots__ = ("id", "session_id", "student_id", "tenant", "status", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    STUDENT_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    session_id: str
    student_id: str
    tenant: str
    status: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., session_id: _Optional[str] = ..., student_id: _Optional[str] = ..., tenant: _Optional[str] = ..., status: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class ScheduleFollowupResponse(_message.Message):
    __slots__ = ("fired", "suppression_reason", "schedule")
    FIRED_FIELD_NUMBER: _ClassVar[int]
    SUPPRESSION_REASON_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    fired: bool
    suppression_reason: str
    schedule: FollowUpSchedule
    def __init__(self, fired: bool = ..., suppression_reason: _Optional[str] = ..., schedule: _Optional[_Union[FollowUpSchedule, _Mapping]] = ...) -> None: ...
