from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class InterventionState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EXPRESSION: _ClassVar[InterventionState]
    SUPPORT: _ClassVar[InterventionState]
    ACTION: _ClassVar[InterventionState]
    FOLLOW_UP: _ClassVar[InterventionState]
EXPRESSION: InterventionState
SUPPORT: InterventionState
ACTION: InterventionState
FOLLOW_UP: InterventionState

class StateLock(_message.Message):
    __slots__ = ("support_screen_viewed",)
    SUPPORT_SCREEN_VIEWED_FIELD_NUMBER: _ClassVar[int]
    support_screen_viewed: bool
    def __init__(self, support_screen_viewed: bool = ...) -> None: ...

class StateTransition(_message.Message):
    __slots__ = ("to", "timestamp", "allowed")
    FROM_FIELD_NUMBER: _ClassVar[int]
    TO_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_FIELD_NUMBER: _ClassVar[int]
    to: InterventionState
    timestamp: str
    allowed: bool
    def __init__(self, to: _Optional[_Union[InterventionState, str]] = ..., timestamp: _Optional[str] = ..., allowed: bool = ..., **kwargs) -> None: ...

class InterventionSession(_message.Message):
    __slots__ = ("session_id", "student_id", "tenant", "current_state", "state_locks", "audit_trail", "created_at", "updated_at")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    STUDENT_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    CURRENT_STATE_FIELD_NUMBER: _ClassVar[int]
    STATE_LOCKS_FIELD_NUMBER: _ClassVar[int]
    AUDIT_TRAIL_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    student_id: str
    tenant: str
    current_state: InterventionState
    state_locks: StateLock
    audit_trail: _containers.RepeatedCompositeFieldContainer[StateTransition]
    created_at: str
    updated_at: str
    def __init__(self, session_id: _Optional[str] = ..., student_id: _Optional[str] = ..., tenant: _Optional[str] = ..., current_state: _Optional[_Union[InterventionState, str]] = ..., state_locks: _Optional[_Union[StateLock, _Mapping]] = ..., audit_trail: _Optional[_Iterable[_Union[StateTransition, _Mapping]]] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CreateSessionRequest(_message.Message):
    __slots__ = ("student_id", "tenant")
    STUDENT_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    student_id: str
    tenant: str
    def __init__(self, student_id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class GetSessionRequest(_message.Message):
    __slots__ = ("session_id", "tenant")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    tenant: str
    def __init__(self, session_id: _Optional[str] = ..., tenant: _Optional[str] = ...) -> None: ...

class TransitionRequest(_message.Message):
    __slots__ = ("session_id", "to_state", "tenant")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    TO_STATE_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    to_state: InterventionState
    tenant: str
    def __init__(self, session_id: _Optional[str] = ..., to_state: _Optional[_Union[InterventionState, str]] = ..., tenant: _Optional[str] = ...) -> None: ...

class TransitionResponse(_message.Message):
    __slots__ = ("success", "error", "updated_session")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    UPDATED_SESSION_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    updated_session: InterventionSession
    def __init__(self, success: bool = ..., error: _Optional[str] = ..., updated_session: _Optional[_Union[InterventionSession, _Mapping]] = ...) -> None: ...
