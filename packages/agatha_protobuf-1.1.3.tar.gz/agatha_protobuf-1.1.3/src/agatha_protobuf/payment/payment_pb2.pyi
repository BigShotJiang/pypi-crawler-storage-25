from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateAccountRequest(_message.Message):
    __slots__ = ("email", "id", "name")
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    email: str
    id: str
    name: str
    def __init__(self, email: _Optional[str] = ..., id: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class CreateAccountResponse(_message.Message):
    __slots__ = ("account_id",)
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    account_id: str
    def __init__(self, account_id: _Optional[str] = ...) -> None: ...

class CreateCardRequest(_message.Message):
    __slots__ = ("card",)
    CARD_FIELD_NUMBER: _ClassVar[int]
    card: Card
    def __init__(self, card: _Optional[_Union[Card, _Mapping]] = ...) -> None: ...

class CreateCardResponse(_message.Message):
    __slots__ = ("card_id",)
    CARD_ID_FIELD_NUMBER: _ClassVar[int]
    card_id: str
    def __init__(self, card_id: _Optional[str] = ...) -> None: ...

class Card(_message.Message):
    __slots__ = ("cvc", "exp_month", "exp_year", "number", "token")
    CVC_FIELD_NUMBER: _ClassVar[int]
    EXP_MONTH_FIELD_NUMBER: _ClassVar[int]
    EXP_YEAR_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    cvc: str
    exp_month: int
    exp_year: int
    number: str
    token: str
    def __init__(self, cvc: _Optional[str] = ..., exp_month: _Optional[int] = ..., exp_year: _Optional[int] = ..., number: _Optional[str] = ..., token: _Optional[str] = ...) -> None: ...

class Account(_message.Message):
    __slots__ = ("id", "tenant", "Account", "amount", "agreement_free", "deleted_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    AGREEMENT_FREE_FIELD_NUMBER: _ClassVar[int]
    DELETED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    Account: str
    amount: str
    agreement_free: bool
    deleted_at: str
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., Account: _Optional[str] = ..., amount: _Optional[str] = ..., agreement_free: bool = ..., deleted_at: _Optional[str] = ...) -> None: ...
