import datetime

from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class UpdateBalanceRequest(_message.Message):
    __slots__ = ("amount", "metadata")
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    amount: int
    metadata: str
    def __init__(self, amount: _Optional[int] = ..., metadata: _Optional[str] = ...) -> None: ...

class UpdateBalanceResponse(_message.Message):
    __slots__ = ("transaction_id", "status")
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    transaction_id: str
    status: str
    def __init__(self, transaction_id: _Optional[str] = ..., status: _Optional[str] = ...) -> None: ...

class GetBalanceRequest(_message.Message):
    __slots__ = ("user_id",)
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    def __init__(self, user_id: _Optional[str] = ...) -> None: ...

class GetBalanceResponse(_message.Message):
    __slots__ = ("current_balance", "currency", "user_id")
    CURRENT_BALANCE_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    current_balance: int
    currency: str
    user_id: str
    def __init__(self, current_balance: _Optional[int] = ..., currency: _Optional[str] = ..., user_id: _Optional[str] = ...) -> None: ...

class ListTransactionsRequest(_message.Message):
    __slots__ = ("user_id", "page_size", "page_token", "start_time", "end_time")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    START_TIME_FIELD_NUMBER: _ClassVar[int]
    END_TIME_FIELD_NUMBER: _ClassVar[int]
    user_id: str
    page_size: int
    page_token: str
    start_time: _timestamp_pb2.Timestamp
    end_time: _timestamp_pb2.Timestamp
    def __init__(self, user_id: _Optional[str] = ..., page_size: _Optional[int] = ..., page_token: _Optional[str] = ..., start_time: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., end_time: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ListTransactionsResponse(_message.Message):
    __slots__ = ("transactions", "next_page_token", "total_count")
    TRANSACTIONS_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    transactions: _containers.RepeatedCompositeFieldContainer[TransactionDetails]
    next_page_token: str
    total_count: int
    def __init__(self, transactions: _Optional[_Iterable[_Union[TransactionDetails, _Mapping]]] = ..., next_page_token: _Optional[str] = ..., total_count: _Optional[int] = ...) -> None: ...

class GetTransactionRequest(_message.Message):
    __slots__ = ("transaction_id",)
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    transaction_id: str
    def __init__(self, transaction_id: _Optional[str] = ...) -> None: ...

class TransactionDetails(_message.Message):
    __slots__ = ("transaction_id", "user_id", "amount", "currency", "type", "status", "description", "created_at")
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    transaction_id: str
    user_id: str
    amount: int
    currency: str
    type: str
    status: str
    description: str
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, transaction_id: _Optional[str] = ..., user_id: _Optional[str] = ..., amount: _Optional[int] = ..., currency: _Optional[str] = ..., type: _Optional[str] = ..., status: _Optional[str] = ..., description: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class BillingSetting(_message.Message):
    __slots__ = ("id", "tenant", "payment", "auto_charge_amount", "paid_limit", "not_paid_limit", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_FIELD_NUMBER: _ClassVar[int]
    PAYMENT_FIELD_NUMBER: _ClassVar[int]
    AUTO_CHARGE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    PAID_LIMIT_FIELD_NUMBER: _ClassVar[int]
    NOT_PAID_LIMIT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    tenant: str
    payment: str
    auto_charge_amount: bool
    paid_limit: int
    not_paid_limit: bool
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., tenant: _Optional[str] = ..., payment: _Optional[str] = ..., auto_charge_amount: bool = ..., paid_limit: _Optional[int] = ..., not_paid_limit: bool = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CreateBillingSettingRequest(_message.Message):
    __slots__ = ("auto_charge_amount", "paid_limit", "not_paid_limit")
    AUTO_CHARGE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    PAID_LIMIT_FIELD_NUMBER: _ClassVar[int]
    NOT_PAID_LIMIT_FIELD_NUMBER: _ClassVar[int]
    auto_charge_amount: bool
    paid_limit: int
    not_paid_limit: bool
    def __init__(self, auto_charge_amount: bool = ..., paid_limit: _Optional[int] = ..., not_paid_limit: bool = ...) -> None: ...

class UpdateBillingSettingRequest(_message.Message):
    __slots__ = ("auto_charge_amount", "paid_limit", "not_paid_limit")
    AUTO_CHARGE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    PAID_LIMIT_FIELD_NUMBER: _ClassVar[int]
    NOT_PAID_LIMIT_FIELD_NUMBER: _ClassVar[int]
    auto_charge_amount: bool
    paid_limit: int
    not_paid_limit: bool
    def __init__(self, auto_charge_amount: bool = ..., paid_limit: _Optional[int] = ..., not_paid_limit: bool = ...) -> None: ...

class BillingSettingResponse(_message.Message):
    __slots__ = ("billing_setting",)
    BILLING_SETTING_FIELD_NUMBER: _ClassVar[int]
    billing_setting: BillingSetting
    def __init__(self, billing_setting: _Optional[_Union[BillingSetting, _Mapping]] = ...) -> None: ...
