from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CohortScopeType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    COHORT_SCOPE_UNSPECIFIED: _ClassVar[CohortScopeType]
    COHORT_SCOPE_TENANT: _ClassVar[CohortScopeType]
    COHORT_SCOPE_ORGANIZATION: _ClassVar[CohortScopeType]
    COHORT_SCOPE_DISTRICT: _ClassVar[CohortScopeType]
    COHORT_SCOPE_CLASSROOM: _ClassVar[CohortScopeType]
COHORT_SCOPE_UNSPECIFIED: CohortScopeType
COHORT_SCOPE_TENANT: CohortScopeType
COHORT_SCOPE_ORGANIZATION: CohortScopeType
COHORT_SCOPE_DISTRICT: CohortScopeType
COHORT_SCOPE_CLASSROOM: CohortScopeType

class MetricValue(_message.Message):
    __slots__ = ("baseline", "current_window", "delta", "volatility", "trust_score", "status", "z_score", "is_anomalous")
    BASELINE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_WINDOW_FIELD_NUMBER: _ClassVar[int]
    DELTA_FIELD_NUMBER: _ClassVar[int]
    VOLATILITY_FIELD_NUMBER: _ClassVar[int]
    TRUST_SCORE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    Z_SCORE_FIELD_NUMBER: _ClassVar[int]
    IS_ANOMALOUS_FIELD_NUMBER: _ClassVar[int]
    baseline: float
    current_window: float
    delta: float
    volatility: float
    trust_score: float
    status: str
    z_score: float
    is_anomalous: bool
    def __init__(self, baseline: _Optional[float] = ..., current_window: _Optional[float] = ..., delta: _Optional[float] = ..., volatility: _Optional[float] = ..., trust_score: _Optional[float] = ..., status: _Optional[str] = ..., z_score: _Optional[float] = ..., is_anomalous: bool = ...) -> None: ...

class Tier1Snapshot(_message.Message):
    __slots__ = ("person_id", "tenant_id", "mood_baseline", "engagement_delta", "sleep_trend", "support_index", "routine_consistency", "composite_trust_score", "status", "risk_recomputed_at", "full_recomputed_at", "created_at")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    MOOD_BASELINE_FIELD_NUMBER: _ClassVar[int]
    ENGAGEMENT_DELTA_FIELD_NUMBER: _ClassVar[int]
    SLEEP_TREND_FIELD_NUMBER: _ClassVar[int]
    SUPPORT_INDEX_FIELD_NUMBER: _ClassVar[int]
    ROUTINE_CONSISTENCY_FIELD_NUMBER: _ClassVar[int]
    COMPOSITE_TRUST_SCORE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    RISK_RECOMPUTED_AT_FIELD_NUMBER: _ClassVar[int]
    FULL_RECOMPUTED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    mood_baseline: MetricValue
    engagement_delta: MetricValue
    sleep_trend: MetricValue
    support_index: MetricValue
    routine_consistency: MetricValue
    composite_trust_score: float
    status: str
    risk_recomputed_at: str
    full_recomputed_at: str
    created_at: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., mood_baseline: _Optional[_Union[MetricValue, _Mapping]] = ..., engagement_delta: _Optional[_Union[MetricValue, _Mapping]] = ..., sleep_trend: _Optional[_Union[MetricValue, _Mapping]] = ..., support_index: _Optional[_Union[MetricValue, _Mapping]] = ..., routine_consistency: _Optional[_Union[MetricValue, _Mapping]] = ..., composite_trust_score: _Optional[float] = ..., status: _Optional[str] = ..., risk_recomputed_at: _Optional[str] = ..., full_recomputed_at: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class MetricFactor(_message.Message):
    __slots__ = ("source_event_type", "weight", "contribution", "trust_score", "timestamp")
    SOURCE_EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    CONTRIBUTION_FIELD_NUMBER: _ClassVar[int]
    TRUST_SCORE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    source_event_type: str
    weight: float
    contribution: float
    trust_score: float
    timestamp: str
    def __init__(self, source_event_type: _Optional[str] = ..., weight: _Optional[float] = ..., contribution: _Optional[float] = ..., trust_score: _Optional[float] = ..., timestamp: _Optional[str] = ...) -> None: ...

class MetricFactorsResponse(_message.Message):
    __slots__ = ("person_id", "metric_name", "factors", "time_window", "composite_trust")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    FACTORS_FIELD_NUMBER: _ClassVar[int]
    TIME_WINDOW_FIELD_NUMBER: _ClassVar[int]
    COMPOSITE_TRUST_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    metric_name: str
    factors: _containers.RepeatedCompositeFieldContainer[MetricFactor]
    time_window: str
    composite_trust: float
    def __init__(self, person_id: _Optional[str] = ..., metric_name: _Optional[str] = ..., factors: _Optional[_Iterable[_Union[MetricFactor, _Mapping]]] = ..., time_window: _Optional[str] = ..., composite_trust: _Optional[float] = ...) -> None: ...

class RecomputeResponse(_message.Message):
    __slots__ = ("success", "message", "snapshot", "recomputed_at")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    RECOMPUTED_AT_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    snapshot: Tier1Snapshot
    recomputed_at: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ..., snapshot: _Optional[_Union[Tier1Snapshot, _Mapping]] = ..., recomputed_at: _Optional[str] = ...) -> None: ...

class GetSnapshotRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class GetMetricFactorsRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "metric_name", "time_window")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    TIME_WINDOW_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    metric_name: str
    time_window: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., metric_name: _Optional[str] = ..., time_window: _Optional[str] = ...) -> None: ...

class TierARequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "event_type", "event_id")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    event_type: str
    event_id: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., event_type: _Optional[str] = ..., event_id: _Optional[str] = ...) -> None: ...

class TierBRequest(_message.Message):
    __slots__ = ("tenant_id",)
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    def __init__(self, tenant_id: _Optional[str] = ...) -> None: ...

class CryptoShredRequest(_message.Message):
    __slots__ = ("person_id", "tenant_id", "reason")
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    person_id: str
    tenant_id: str
    reason: str
    def __init__(self, person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class CryptoShredResponse(_message.Message):
    __slots__ = ("success", "message", "rows_scrubbed", "shredded_at")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ROWS_SCRUBBED_FIELD_NUMBER: _ClassVar[int]
    SHREDDED_AT_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message: str
    rows_scrubbed: int
    shredded_at: str
    def __init__(self, success: bool = ..., message: _Optional[str] = ..., rows_scrubbed: _Optional[int] = ..., shredded_at: _Optional[str] = ...) -> None: ...

class RiskClassificationProto(_message.Message):
    __slots__ = ("level", "pathway", "urgency", "categorical", "compound_score", "primary_concern", "requires_human_ack", "sla_minutes")
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    PATHWAY_FIELD_NUMBER: _ClassVar[int]
    URGENCY_FIELD_NUMBER: _ClassVar[int]
    CATEGORICAL_FIELD_NUMBER: _ClassVar[int]
    COMPOUND_SCORE_FIELD_NUMBER: _ClassVar[int]
    PRIMARY_CONCERN_FIELD_NUMBER: _ClassVar[int]
    REQUIRES_HUMAN_ACK_FIELD_NUMBER: _ClassVar[int]
    SLA_MINUTES_FIELD_NUMBER: _ClassVar[int]
    level: int
    pathway: str
    urgency: str
    categorical: str
    compound_score: float
    primary_concern: str
    requires_human_ack: bool
    sla_minutes: int
    def __init__(self, level: _Optional[int] = ..., pathway: _Optional[str] = ..., urgency: _Optional[str] = ..., categorical: _Optional[str] = ..., compound_score: _Optional[float] = ..., primary_concern: _Optional[str] = ..., requires_human_ack: bool = ..., sla_minutes: _Optional[int] = ...) -> None: ...

class RiskAlertContextProto(_message.Message):
    __slots__ = ("primary_emotion", "explanation_summary", "contributing_factors", "protective_factors")
    PRIMARY_EMOTION_FIELD_NUMBER: _ClassVar[int]
    EXPLANATION_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    CONTRIBUTING_FACTORS_FIELD_NUMBER: _ClassVar[int]
    PROTECTIVE_FACTORS_FIELD_NUMBER: _ClassVar[int]
    primary_emotion: str
    explanation_summary: str
    contributing_factors: _containers.RepeatedScalarFieldContainer[str]
    protective_factors: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, primary_emotion: _Optional[str] = ..., explanation_summary: _Optional[str] = ..., contributing_factors: _Optional[_Iterable[str]] = ..., protective_factors: _Optional[_Iterable[str]] = ...) -> None: ...

class RiskAlertObservabilityProto(_message.Message):
    __slots__ = ("evidence_trust_score", "data_freshness_ms")
    EVIDENCE_TRUST_SCORE_FIELD_NUMBER: _ClassVar[int]
    DATA_FRESHNESS_MS_FIELD_NUMBER: _ClassVar[int]
    evidence_trust_score: float
    data_freshness_ms: int
    def __init__(self, evidence_trust_score: _Optional[float] = ..., data_freshness_ms: _Optional[int] = ...) -> None: ...

class RiskAlertRoutingProto(_message.Message):
    __slots__ = ("target_roles", "primary_escalation_policy_id", "fallback_escalation_policy_id", "requires_human_ack", "ack_deadline_utc")
    TARGET_ROLES_FIELD_NUMBER: _ClassVar[int]
    PRIMARY_ESCALATION_POLICY_ID_FIELD_NUMBER: _ClassVar[int]
    FALLBACK_ESCALATION_POLICY_ID_FIELD_NUMBER: _ClassVar[int]
    REQUIRES_HUMAN_ACK_FIELD_NUMBER: _ClassVar[int]
    ACK_DEADLINE_UTC_FIELD_NUMBER: _ClassVar[int]
    target_roles: _containers.RepeatedScalarFieldContainer[str]
    primary_escalation_policy_id: str
    fallback_escalation_policy_id: str
    requires_human_ack: bool
    ack_deadline_utc: str
    def __init__(self, target_roles: _Optional[_Iterable[str]] = ..., primary_escalation_policy_id: _Optional[str] = ..., fallback_escalation_policy_id: _Optional[str] = ..., requires_human_ack: bool = ..., ack_deadline_utc: _Optional[str] = ...) -> None: ...

class RiskAlertSystemProto(_message.Message):
    __slots__ = ("model_version", "threshold_version")
    MODEL_VERSION_FIELD_NUMBER: _ClassVar[int]
    THRESHOLD_VERSION_FIELD_NUMBER: _ClassVar[int]
    model_version: str
    threshold_version: str
    def __init__(self, model_version: _Optional[str] = ..., threshold_version: _Optional[str] = ...) -> None: ...

class RiskAlertEventProto(_message.Message):
    __slots__ = ("event_id", "person_id", "tenant_id", "timestamp", "risk_level", "categorical", "pathway", "urgency", "compound_score", "sla_minutes", "requires_ack", "trigger_signals", "primary_concern", "audit_id", "classification", "context", "observability", "routing", "system", "confidence", "risk_score")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    RISK_LEVEL_FIELD_NUMBER: _ClassVar[int]
    CATEGORICAL_FIELD_NUMBER: _ClassVar[int]
    PATHWAY_FIELD_NUMBER: _ClassVar[int]
    URGENCY_FIELD_NUMBER: _ClassVar[int]
    COMPOUND_SCORE_FIELD_NUMBER: _ClassVar[int]
    SLA_MINUTES_FIELD_NUMBER: _ClassVar[int]
    REQUIRES_ACK_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_SIGNALS_FIELD_NUMBER: _ClassVar[int]
    PRIMARY_CONCERN_FIELD_NUMBER: _ClassVar[int]
    AUDIT_ID_FIELD_NUMBER: _ClassVar[int]
    CLASSIFICATION_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    OBSERVABILITY_FIELD_NUMBER: _ClassVar[int]
    ROUTING_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    RISK_SCORE_FIELD_NUMBER: _ClassVar[int]
    event_id: str
    person_id: str
    tenant_id: str
    timestamp: str
    risk_level: int
    categorical: str
    pathway: str
    urgency: str
    compound_score: float
    sla_minutes: int
    requires_ack: bool
    trigger_signals: _containers.RepeatedScalarFieldContainer[str]
    primary_concern: str
    audit_id: str
    classification: RiskClassificationProto
    context: RiskAlertContextProto
    observability: RiskAlertObservabilityProto
    routing: RiskAlertRoutingProto
    system: RiskAlertSystemProto
    confidence: float
    risk_score: float
    def __init__(self, event_id: _Optional[str] = ..., person_id: _Optional[str] = ..., tenant_id: _Optional[str] = ..., timestamp: _Optional[str] = ..., risk_level: _Optional[int] = ..., categorical: _Optional[str] = ..., pathway: _Optional[str] = ..., urgency: _Optional[str] = ..., compound_score: _Optional[float] = ..., sla_minutes: _Optional[int] = ..., requires_ack: bool = ..., trigger_signals: _Optional[_Iterable[str]] = ..., primary_concern: _Optional[str] = ..., audit_id: _Optional[str] = ..., classification: _Optional[_Union[RiskClassificationProto, _Mapping]] = ..., context: _Optional[_Union[RiskAlertContextProto, _Mapping]] = ..., observability: _Optional[_Union[RiskAlertObservabilityProto, _Mapping]] = ..., routing: _Optional[_Union[RiskAlertRoutingProto, _Mapping]] = ..., system: _Optional[_Union[RiskAlertSystemProto, _Mapping]] = ..., confidence: _Optional[float] = ..., risk_score: _Optional[float] = ...) -> None: ...

class CohortMetricsRequest(_message.Message):
    __slots__ = ("tenant_id", "scope_type", "scope_id", "metric_names", "window")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    SCOPE_TYPE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_ID_FIELD_NUMBER: _ClassVar[int]
    METRIC_NAMES_FIELD_NUMBER: _ClassVar[int]
    WINDOW_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    scope_type: CohortScopeType
    scope_id: str
    metric_names: _containers.RepeatedScalarFieldContainer[str]
    window: str
    def __init__(self, tenant_id: _Optional[str] = ..., scope_type: _Optional[_Union[CohortScopeType, str]] = ..., scope_id: _Optional[str] = ..., metric_names: _Optional[_Iterable[str]] = ..., window: _Optional[str] = ...) -> None: ...

class CohortMetricValue(_message.Message):
    __slots__ = ("metric_name", "weighted_mean", "stddev", "median", "person_count", "composite_trust")
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    WEIGHTED_MEAN_FIELD_NUMBER: _ClassVar[int]
    STDDEV_FIELD_NUMBER: _ClassVar[int]
    MEDIAN_FIELD_NUMBER: _ClassVar[int]
    PERSON_COUNT_FIELD_NUMBER: _ClassVar[int]
    COMPOSITE_TRUST_FIELD_NUMBER: _ClassVar[int]
    metric_name: str
    weighted_mean: float
    stddev: float
    median: float
    person_count: int
    composite_trust: float
    def __init__(self, metric_name: _Optional[str] = ..., weighted_mean: _Optional[float] = ..., stddev: _Optional[float] = ..., median: _Optional[float] = ..., person_count: _Optional[int] = ..., composite_trust: _Optional[float] = ...) -> None: ...

class CohortMetricsResponse(_message.Message):
    __slots__ = ("tenant_id", "scope_type", "scope_id", "metrics", "window_start", "window_end", "cohort_size")
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    SCOPE_TYPE_FIELD_NUMBER: _ClassVar[int]
    SCOPE_ID_FIELD_NUMBER: _ClassVar[int]
    METRICS_FIELD_NUMBER: _ClassVar[int]
    WINDOW_START_FIELD_NUMBER: _ClassVar[int]
    WINDOW_END_FIELD_NUMBER: _ClassVar[int]
    COHORT_SIZE_FIELD_NUMBER: _ClassVar[int]
    tenant_id: str
    scope_type: CohortScopeType
    scope_id: str
    metrics: _containers.RepeatedCompositeFieldContainer[CohortMetricValue]
    window_start: str
    window_end: str
    cohort_size: int
    def __init__(self, tenant_id: _Optional[str] = ..., scope_type: _Optional[_Union[CohortScopeType, str]] = ..., scope_id: _Optional[str] = ..., metrics: _Optional[_Iterable[_Union[CohortMetricValue, _Mapping]]] = ..., window_start: _Optional[str] = ..., window_end: _Optional[str] = ..., cohort_size: _Optional[int] = ...) -> None: ...

class UpdateAuditRoutingStatusRequest(_message.Message):
    __slots__ = ("audit_id", "routing_status")
    AUDIT_ID_FIELD_NUMBER: _ClassVar[int]
    ROUTING_STATUS_FIELD_NUMBER: _ClassVar[int]
    audit_id: str
    routing_status: str
    def __init__(self, audit_id: _Optional[str] = ..., routing_status: _Optional[str] = ...) -> None: ...
