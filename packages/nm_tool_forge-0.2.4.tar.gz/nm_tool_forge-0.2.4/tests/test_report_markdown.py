from __future__ import annotations

from collections import Counter
from pathlib import Path

from loganalysis.models import AnalysisConfig, AnalysisSummary, FileAnalysis
from loganalysis.report_markdown import build_markdown_report, parse_report_markdown


def test_build_and_parse_markdown_report_roundtrip(tmp_path: Path) -> None:
    normalized_key = ("ERROR", 'Conversion: X =<VALUE> The record was not found in table "Teile".')
    analysis = FileAnalysis(
        file=tmp_path / "demo.txt",
        total_lines=5,
        total_entries=4,
        unknown_lines=0,
        raw_counts=Counter({("ERROR", 'Conversion: X =3100110. 138 The record was not found in table "Teile".'): 2}),
        norm_counts=Counter({normalized_key: 2}),
        norm_examples={
            normalized_key: Counter({'Conversion: X =3100110. 138 The record was not found in table "Teile".': 2})
        },
        backup_path=tmp_path / "backup" / "demo.txt.bak",
    )
    summary = AnalysisSummary(
        analyses=[analysis],
        global_raw=Counter(analysis.raw_counts),
        global_norm=Counter(analysis.norm_counts),
        global_norm_examples={normalized_key: Counter(analysis.norm_examples[normalized_key])},
    )
    config = AnalysisConfig(
        logs_dir=tmp_path / "logs",
        out_dir=tmp_path / "out",
        backup_dir=tmp_path / "backup",
        top_examples=3,
        convert=False,
    )

    markdown = build_markdown_report(summary, config)
    parsed = parse_report_markdown(markdown)

    assert markdown.startswith("# Log Analysis Report")
    assert parsed.metadata[0][0] == "Logs directory"
    assert parsed.sections[0].title == "File: demo.txt"
    assert parsed.sections[0].table is not None
    assert parsed.sections[0].table.rows[0][0] == "ERROR"
    assert parsed.sections[-1].title == "Overall summary (all files)"
