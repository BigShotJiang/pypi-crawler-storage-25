from __future__ import annotations

from pathlib import Path

from loganalysis.parsing import is_entry_start, iter_logical_entries, parse_entry


def test_is_entry_start_recognizes_supported_severity_tokens() -> None:
    assert is_entry_start("ERROR, Something failed")
    assert is_entry_start("Warn\tLine 12: Something happened")
    assert not is_entry_start("Trace: no supported severity")


def test_iter_logical_entries_keeps_multiline_entries_together(tmp_path: Path) -> None:
    log_path = tmp_path / "demo.txt"
    log_path.write_text(
        "INFO, Start import\n"
        "continued details\n"
        "ERROR, Failed import\n"
        "stack line 1\n"
        "stack line 2\n",
        encoding="utf-8",
    )

    entries = list(iter_logical_entries(log_path, encoding="utf-8"))

    assert entries == [
        "INFO, Start import\ncontinued details\n",
        "ERROR, Failed import\nstack line 1\nstack line 2\n",
    ]


def test_parse_entry_removes_line_prefix_and_trailing_dataset() -> None:
    parsed = parse_entry("ERROR, Line 42: Invalid row ; foo; bar; baz")

    assert parsed is not None
    assert parsed.severity == "ERROR"
    assert parsed.message == "Invalid row"
