import pytest

from csvchunking.chunker import split_csv


def make_csv(tmp_path, name, header, rows, encoding="utf-8-sig", delimiter=";"):
    file = tmp_path / name
    with open(file, "w", encoding=encoding, newline="") as f:
        f.write(delimiter.join(header) + "\n")
        for row in rows:
            f.write(delimiter.join(row) + "\n")
    return file


def test_regular_split(tmp_path):
    header = ["col1", "col2"]
    rows = [["A", "1"], ["B", "2"], ["C", "3"], ["D", "4"], ["E", "5"]]
    file = make_csv(tmp_path, "sample.csv", header, rows)
    result = split_csv(file, chunk_size=2)
    assert result.files_created == 3
    for out in result.output_files:
        with open(out, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
            assert lines[0] == "col1;col2"
    assert (result.output_dir / "sample_01.csv").exists()
    assert (result.output_dir / "sample_02.csv").exists()
    assert (result.output_dir / "sample_03.csv").exists()


def test_header_in_each_file(tmp_path):
    header = ["foo", "bar"]
    rows = [["x", "1"], ["y", "2"], ["z", "3"]]
    file = make_csv(tmp_path, "test.csv", header, rows)
    result = split_csv(file, chunk_size=1)
    for out in result.output_files:
        with open(out, encoding="utf-8-sig") as f:
            assert f.readline().strip() == "foo;bar"


def test_filename_with_spaces(tmp_path):
    header = ["a", "b"]
    rows = [["1", "2"]]
    file = make_csv(tmp_path, "Part-Storage Areas Relationships.csv", header, rows)
    result = split_csv(file, chunk_size=1)
    assert result.output_dir.name == "Part-Storage Areas Relationships"
    assert (result.output_dir / "Part-Storage Areas Relationships_01.csv").exists()


def test_invalid_chunk_size(tmp_path):
    header = ["a", "b"]
    rows = [["1", "2"]]
    file = make_csv(tmp_path, "fail.csv", header, rows)
    with pytest.raises(ValueError):
        split_csv(file, chunk_size=0)
    with pytest.raises(ValueError):
        split_csv(file, chunk_size=-1)


def test_empty_file(tmp_path):
    file = tmp_path / "empty.csv"
    file.write_text("")
    with pytest.raises(ValueError):
        split_csv(file, chunk_size=1)
