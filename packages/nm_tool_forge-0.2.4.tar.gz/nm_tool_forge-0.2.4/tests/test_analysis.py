from __future__ import annotations

from pathlib import Path

from loganalysis.analysis import analyze_file, run_analysis
from loganalysis.models import AnalysisConfig


def test_analyze_file_aggregates_raw_and_normalized_counts(tmp_path: Path) -> None:
    log_path = tmp_path / "demo.txt"
    log_path.write_text(
        "ERROR, Conversion: X =3100110. 138 The record was not found in table \"Teile\".\n"
        "ERROR, Conversion: X =999. 139 The record was not found in table \"Teile\".\n"
        "WARNING, Different issue\n",
        encoding="utf-8",
    )

    result = analyze_file(log_path)

    assert result.total_lines == 3
    assert result.total_entries == 3
    assert result.unknown_lines == 0
    assert result.raw_counts[("WARNING", "Different issue")] == 1
    normalized_key = ("ERROR", 'Conversion: X =<VALUE> The record was not found in table "Teile".')
    assert result.norm_counts[normalized_key] == 2
    assert len(result.norm_examples[normalized_key]) == 2


def test_run_analysis_writes_outputs_and_report(tmp_path: Path) -> None:
    logs_dir = tmp_path / "logs"
    out_dir = tmp_path / "out"
    logs_dir.mkdir()
    (logs_dir / "app.txt").write_text(
        "INFO, Start\n"
        "ERROR, Conversion: X =3100110. 138 The record was not found in table \"Teile\".\n",
        encoding="utf-8",
    )

    result = run_analysis(
        AnalysisConfig(
            logs_dir=logs_dir,
            out_dir=out_dir,
            backup_dir=out_dir / "backup",
            top_examples=2,
            convert=False,
        )
    )

    assert result.report_path.exists()
    assert (out_dir / "app.aggregated.csv").exists()
    assert (out_dir / "app.aggregated.normalized.csv").exists()
    assert (out_dir / "summary.all_files.csv").exists()
    assert result.summary.analyses[0].backup_path is not None
    assert "## File: app.txt" in result.report_path.read_text(encoding="utf-8")
