from __future__ import annotations

from pathlib import Path

from loganalysis.report_html import render_report_html_document, resolve_report_date
from loganalysis.report_markdown import parse_report_markdown


def test_render_report_html_contains_expected_fragments(tmp_path: Path) -> None:
    markdown = """# Log Analysis Report

- Logs directory: `D:\\logs`
- Output directory: `D:\\out`
- Backup directory: `D:\\out\\backup`
- Timestamp: 2026-03-24T16:14:21

## File: Customers_Log.txt

- Backup: `D:\\out\\backup\\Customers_Log.txt.bak`
- Physical lines: 10
- Logical entries: 10
- UNKNOWN severity entries: 0

### Top messages (normalized)

| Severity | Count | Normalized message | Examples |
|---|---:|---|---|
| ERROR | 2 | <N>.<N>.<N>/<N>:<N>:<N> - Missing path <PATH> | Example A<br>Example B |
"""
    md_path = tmp_path / "report.md"
    md_path.write_text(markdown, encoding="utf-8")

    report = parse_report_markdown(markdown)
    html = render_report_html_document(report, md_path.name, resolve_report_date(report, md_path))

    assert "@page" in html
    assert 'counter(page) " / " counter(pages)' in html
    assert '<div class="report-table-wrap"><table class="report-table">' in html
    assert '<th class="col-severity">Severity</th>' in html
    assert '<div class="examples"><div>Example A</div><div>Example B</div></div>' in html
    assert "Missing path &lt;PATH&gt;" in html
    assert "<N>.<N>.<N>/<N>:<N>:<N>" not in html
