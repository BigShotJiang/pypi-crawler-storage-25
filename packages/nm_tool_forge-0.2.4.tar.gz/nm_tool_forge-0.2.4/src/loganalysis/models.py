from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

MessageKey = tuple[str, str]


@dataclass(frozen=True)
class ParsedLine:
    """Structured representation of a parsed logical log entry."""

    severity: str
    message: str


@dataclass
class FileAnalysis:
    """Aggregated analysis results for a single log file."""

    file: Path
    total_lines: int
    total_entries: int
    unknown_lines: int
    raw_counts: Counter[MessageKey]
    norm_counts: Counter[MessageKey]
    norm_examples: dict[MessageKey, Counter[str]]
    backup_path: Path | None = None


@dataclass
class AnalysisSummary:
    """Combined analysis data across all processed files."""

    analyses: list[FileAnalysis] = field(default_factory=list)
    global_raw: Counter[MessageKey] = field(default_factory=Counter)
    global_norm: Counter[MessageKey] = field(default_factory=Counter)
    global_norm_examples: dict[MessageKey, Counter[str]] = field(default_factory=dict)


@dataclass(frozen=True)
class AnalysisConfig:
    """Configuration for a full analysis run."""

    logs_dir: Path
    out_dir: Path
    backup_dir: Path | None = None
    top_examples: int = 3
    convert: bool = False


@dataclass
class AnalysisRunResult:
    """Paths and conversion results produced by a full analysis run."""

    out_dir: Path
    backup_dir: Path
    report_path: Path
    summary: AnalysisSummary
    html_path: Path | None = None
    pdf_path: Path | None = None
    convert_status: dict[str, object] = field(default_factory=dict)
