from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

from .analysis import NoLogFilesError, run_analysis
from .constants import DEFAULT_LOGS_DIR, DEFAULT_OUT_DIR, DEFAULT_TOP_EXAMPLES, EXIT_SUCCESS
from .models import AnalysisConfig
from .selftest import run_self_tests


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line parser for the log analysis tool."""

    parser = argparse.ArgumentParser(
        description="Aggregated analysis of log files (INFO/ERROR/WARNING) in logs/*.txt",
    )
    parser.add_argument(
        "--logs-dir",
        default=DEFAULT_LOGS_DIR,
        help=f"Subdirectory with log files (Default: {DEFAULT_LOGS_DIR})",
    )
    parser.add_argument("--out-dir", default=DEFAULT_OUT_DIR, help=f"Output directory (Default: {DEFAULT_OUT_DIR})")
    parser.add_argument("--backup-dir", default=None, help="Backup directory (Default: <out-dir>/backup)")
    parser.add_argument(
        "--top-examples",
        type=int,
        default=DEFAULT_TOP_EXAMPLES,
        help=f"Number of example variants per normalized message in the report (Default: {DEFAULT_TOP_EXAMPLES})",
    )
    parser.add_argument(
        "--convert",
        action="store_true",
        help="Convert report.md to report.html and report.pdf when supported after analysis.",
    )
    parser.add_argument("--self-test", action="store_true", help="Run built-in self-tests and exit.")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point for `python -m loganalysis` and the console script."""

    parser = build_parser()
    args = parser.parse_args(argv)

    if args.self_test:
        run_self_tests()
        print("Self-tests passed.")
        return EXIT_SUCCESS

    config = AnalysisConfig(
        logs_dir=Path(args.logs_dir),
        out_dir=Path(args.out_dir),
        backup_dir=Path(args.backup_dir) if args.backup_dir else (Path(args.out_dir) / "backup"),
        top_examples=args.top_examples,
        convert=args.convert,
    )

    try:
        result = run_analysis(config)
    except NoLogFilesError as exc:
        print(str(exc))
        return exc.exit_code

    if config.convert:
        print(f"Converting {result.report_path} to HTML and PDF...")
        if result.convert_status.get("html_created"):
            print(f"- HTML: {result.html_path.resolve() if result.html_path else 'created'}")
        else:
            print("- HTML: failed")

        if result.convert_status.get("pdf_created"):
            print(f"- PDF: {result.pdf_path.resolve() if result.pdf_path else 'created'}")
        else:
            pdf_reason = result.convert_status.get("pdf_reason")
            if pdf_reason == "pandoc_missing":
                print("- PDF: skipped (pandoc not available)")
            elif pdf_reason == "no_pdf_engine":
                print("- PDF: skipped (no PDF engine found)")
            elif pdf_reason == "html_failed":
                print("- PDF: skipped (HTML conversion failed)")
            elif pdf_reason == "pdf_not_created":
                print("- PDF: not created")
            else:
                print("- PDF: failed")

    print("Analysis completed.")
    print(f"- Backups: {result.backup_dir.resolve()}")
    print(f"- Outputs: {result.out_dir.resolve()}")
    print(f"- Report: {result.report_path.resolve()}")
    return EXIT_SUCCESS
