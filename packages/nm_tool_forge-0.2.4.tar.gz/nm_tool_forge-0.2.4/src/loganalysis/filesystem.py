from __future__ import annotations

import datetime as dt
import shutil
from pathlib import Path


def now_stamp() -> str:
    """Return a filesystem-safe timestamp."""

    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def ensure_dir(path: Path) -> None:
    """Create a directory and all missing parents."""

    path.mkdir(parents=True, exist_ok=True)


def backup_file(src: Path, backup_root: Path) -> Path:
    """Create a timestamped backup copy of a source file."""

    ensure_dir(backup_root)
    dst = backup_root / f"{src.name}.{now_stamp()}.bak"
    shutil.copy2(src, dst)
    return dst
