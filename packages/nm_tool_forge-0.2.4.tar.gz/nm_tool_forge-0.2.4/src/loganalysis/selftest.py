from __future__ import annotations

from .constants import NORMALIZATION_SELF_TEST_CASES
from .normalization import normalize_message
from .parsing import is_entry_start
from .report_html import render_report_html_document
from .report_markdown import parse_report_markdown
from .report_pdf import build_pdf_safe_markdown, escape_latex_text, make_markdown_table_line_pdf_safe


def run_self_tests() -> None:
    """Run deterministic built-in assertions for quick local verification."""

    for raw_message, expected in NORMALIZATION_SELF_TEST_CASES:
        actual = normalize_message(raw_message)
        assert actual == expected, f"normalize_message({raw_message!r}) -> {actual!r}, expected {expected!r}"

    assert is_entry_start("ERROR\tLine 1: tab-separated severity")
    assert (
        escape_latex_text(r"D:\DATEN_UEBERNAHME\A&B")
        == r"D:\textbackslash{}DATEN\_UEBERNAHME\textbackslash{}A\&B"
    )
    assert make_markdown_table_line_pdf_safe("|---|---:|---|") == "|---|---:|---|"
    assert (
        make_markdown_table_line_pdf_safe(r"| ERROR | D:\DATEN_1<br>foo |")
        == r"| ERROR | D:\textbackslash{}DATEN\_1 ; foo |"
    )
    assert build_pdf_safe_markdown("plain\n| A | B |\n").endswith("\n")

    sample_report_markdown = """# Log Analysis Report

- Logs directory: `D:\\logs`
- Output directory: `D:\\out`
- Backup directory: `D:\\out\\backup`
- Timestamp: 2026-03-24T16:14:21

## File: Customers_Log.txt

- Backup: `log_analyse_out\\backup\\Customers_Log.txt.20260324_161421.bak`
- Physical lines: 27597
- Logical entries: 27597
- UNKNOWN severity entries: 0

### Top messages (normalized)

| Severity | Count | Normalized message | Examples |
|---|---:|---|---|
| ERROR | 2 | Missing path <PATH> | Example A<br>Example B |
"""

    parsed_report = parse_report_markdown(sample_report_markdown)
    assert parsed_report.title == "Log Analysis Report"
    assert parsed_report.metadata[0] == ("Logs directory", "`D:\\logs`")
    assert parsed_report.sections[0].title == "File: Customers_Log.txt"
    assert parsed_report.sections[0].table is not None
    assert parsed_report.sections[0].table.rows[0][3] == "Example A<br>Example B"

    rendered_html = render_report_html_document(parsed_report, "report.md", "2026-03-24")
    assert "@page" in rendered_html
    assert 'counter(page) " / " counter(pages)' in rendered_html
    assert '<section class="file-block">' in rendered_html
    assert '<div class="report-table-wrap"><table class="report-table">' in rendered_html
    assert '<th class="col-examples">Examples</th>' in rendered_html
    assert '<div class="examples"><div>Example A</div><div>Example B</div></div>' in rendered_html
