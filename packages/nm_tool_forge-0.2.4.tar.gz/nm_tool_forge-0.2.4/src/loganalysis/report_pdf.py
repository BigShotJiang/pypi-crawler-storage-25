from __future__ import annotations

import shutil
from contextlib import redirect_stderr, redirect_stdout
from io import StringIO

from .constants import (
    COMMON_MOJIBAKE_TOKENS,
    LATEX_PDF_ENGINES,
    LATEX_SPECIAL_CHAR_REPLACEMENTS,
    RE_MARKDOWN_TABLE_SEPARATOR,
)


def select_pdf_engine() -> str | None:
    """Return the preferred available PDF engine."""

    try:
        with redirect_stderr(StringIO()), redirect_stdout(StringIO()):
            import weasyprint  # noqa: F401

        return "weasyprint"
    except ModuleNotFoundError:
        pass
    except Exception:
        print("[WARN] WeasyPrint is installed but not usable on this system. Falling back to other PDF engines.")

    if shutil.which("wkhtmltopdf"):
        return "wkhtmltopdf"

    for engine in ("xelatex", "pdflatex"):
        if engine not in LATEX_PDF_ENGINES:
            continue
        if shutil.which(engine):
            return engine
    return None


def escape_latex_text(text: str) -> str:
    """Escape plain text for use in LaTeX-backed PDF conversions."""

    return "".join(LATEX_SPECIAL_CHAR_REPLACEMENTS.get(char, char) for char in text)


def contains_common_mojibake(text: str) -> bool:
    """Return whether the text contains known mojibake fragments."""

    return any(token in text for token in COMMON_MOJIBAKE_TOKENS)


def make_markdown_table_line_pdf_safe(line: str) -> str:
    """Escape markdown table cells for LaTeX-backed PDF generation."""

    if not line.lstrip().startswith("|"):
        return line

    if RE_MARKDOWN_TABLE_SEPARATOR.match(line.strip()):
        return line

    parts = line.split("|")
    if len(parts) < 3:
        return line

    safe_parts = [parts[0]]
    for cell in parts[1:-1]:
        cell_text = cell.replace("<br>", " ; ").replace("<BR>", " ; ")
        safe_parts.append(escape_latex_text(cell_text))
    safe_parts.append(parts[-1])
    return "|".join(safe_parts)


def build_pdf_safe_markdown(markdown: str) -> str:
    """Build a LaTeX-safe markdown variant for pandoc-based PDF conversion."""

    safe_lines = [make_markdown_table_line_pdf_safe(line) for line in markdown.splitlines()]
    safe_markdown = "\n".join(safe_lines)
    if markdown.endswith("\n"):
        safe_markdown += "\n"
    return safe_markdown
