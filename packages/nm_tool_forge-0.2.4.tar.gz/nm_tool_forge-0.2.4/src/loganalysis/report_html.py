from __future__ import annotations

import datetime as dt
import html as html_lib
from pathlib import Path

from .constants import RE_HTML_BREAK, RE_INLINE_CODE_SPAN, RE_LEADING_TIMESTAMP_PLACEHOLDER
from .report_models import ReportDocument, ReportSection, ReportTable


def sanitize_html_text(text: str) -> str:
    """Remove HTML-only placeholder fragments before rendering."""

    return RE_LEADING_TIMESTAMP_PLACEHOLDER.sub("", text).strip()


def render_inline_markdown_html(text: str) -> str:
    """Render the supported inline markdown subset to HTML."""

    parts = RE_INLINE_CODE_SPAN.split(sanitize_html_text(text))
    rendered_parts: list[str] = []
    for part in parts:
        if not part:
            continue
        if part.startswith("`") and part.endswith("`"):
            rendered_parts.append(f"<code>{html_lib.escape(part[1:-1], quote=False)}</code>")
        else:
            rendered_parts.append(html_lib.escape(part, quote=False))
    return "".join(rendered_parts)


def render_metadata_list_html(items: tuple[tuple[str, str], ...], css_class: str) -> str:
    """Render report metadata entries as a compact bullet list."""

    if not items:
        return ""

    rendered_items: list[str] = []
    for label, value in items:
        label_html = html_lib.escape(label, quote=False)
        value_html = render_inline_markdown_html(value)
        separator = ": " if value else ""
        rendered_items.append(f"<li><span class=\"meta-label\">{label_html}</span>{separator}{value_html}</li>")
    return f"<ul class=\"{css_class}\">{''.join(rendered_items)}</ul>"


def render_examples_html(cell_text: str) -> str:
    """Render `<br>`-separated example values as stacked HTML blocks."""

    examples = [item.strip() for item in RE_HTML_BREAK.split(cell_text) if item.strip()]
    if not examples:
        return ""

    rendered = "".join(f"<div>{render_inline_markdown_html(example)}</div>" for example in examples)
    return f"<div class=\"examples\">{rendered}</div>"


def report_table_column_class(index: int) -> str:
    """Return the semantic CSS class for a report table column."""

    column_classes = ("col-severity", "col-count", "col-message", "col-examples")
    if 0 <= index < len(column_classes):
        return column_classes[index]
    return f"col-{index + 1}"


def render_report_table_html(table: ReportTable) -> str:
    """Render one report table to HTML."""

    thead_cells = "".join(
        f"<th class=\"{report_table_column_class(index)}\">{html_lib.escape(header, quote=False)}</th>"
        for index, header in enumerate(table.headers)
    )

    body_rows: list[str] = []
    for row in table.rows:
        cells: list[str] = []
        for index, cell in enumerate(row):
            header = table.headers[index].lower() if index < len(table.headers) else ""
            if header == "examples":
                cell_html = render_examples_html(cell)
            else:
                cell_html = render_inline_markdown_html(cell)
            cells.append(f"<td class=\"{report_table_column_class(index)}\">{cell_html}</td>")
        body_rows.append(f"<tr>{''.join(cells)}</tr>")

    return (
        "<div class=\"report-table-wrap\">"
        "<table class=\"report-table\">"
        f"<thead><tr>{thead_cells}</tr></thead>"
        f"<tbody>{''.join(body_rows)}</tbody>"
        "</table>"
        "</div>"
    )


def css_string_literal(text: str) -> str:
    """Escape plain text for use in CSS string literals."""

    escaped = text.replace("\\", r"\\").replace('"', r"\"").replace("\n", r"\A ")
    return f'"{escaped}"'


def resolve_report_date(report: ReportDocument, md_path: Path) -> str:
    """Resolve the report date shown in the page header."""

    for label, value in report.metadata:
        if label.lower() != "timestamp":
            continue
        raw_value = value.replace("`", "").strip()
        try:
            return dt.datetime.fromisoformat(raw_value).date().isoformat()
        except ValueError:
            if len(raw_value) >= 10:
                return raw_value[:10]

    return dt.datetime.fromtimestamp(md_path.stat().st_mtime).date().isoformat()


def build_report_styles(report_name: str, report_date: str) -> str:
    """Return the shared CSS used by HTML and HTML-to-PDF rendering."""

    return f"""
    @page {{
        size: A4 portrait;
        margin: 1.2cm 1cm 1.4cm 1.1cm;

        @top-left {{
            content: {css_string_literal(report_name)};
            font-family: Arial, Helvetica, sans-serif;
            font-size: 9pt;
            color: #222;
        }}

        @top-right {{
            content: {css_string_literal(report_date)};
            font-family: Arial, Helvetica, sans-serif;
            font-size: 9pt;
            color: #222;
        }}

        @bottom-center {{
            content: counter(page) " / " counter(pages);
            font-family: Arial, Helvetica, sans-serif;
            font-size: 9pt;
            color: #222;
        }}
    }}

    html, body {{
        font-family: Arial, Helvetica, sans-serif;
        font-size: 10pt;
        line-height: 1.35;
        color: #222;
        margin: 0;
        padding: 0;
    }}

    body {{
        background: #fff;
    }}

    .report-shell {{
        width: 100%;
    }}

    h1 {{
        font-size: 24pt;
        font-weight: 500;
        margin: 0 0 0.35cm 0;
        border-bottom: 1px solid #666;
        padding-bottom: 0.18cm;
    }}

    h2 {{
        font-size: 14pt;
        font-weight: 500;
        margin: 0.35cm 0 0.16cm 0;
    }}

    h3 {{
        font-size: 11pt;
        font-weight: 600;
        margin: 0.24cm 0 0.12cm 0;
    }}

    p {{
        margin: 0.1cm 0 0.2cm 0;
    }}

    ul {{
        margin: 0.1cm 0 0.35cm 0.45cm;
        padding-left: 0.35cm;
    }}

    li {{
        margin: 0.05cm 0;
    }}

    code {{
        color: #c8a46a;
        background: transparent;
        padding: 0;
        border-radius: 0;
        font-size: 0.98em;
    }}

    section.file-block {{
        margin: 0.22cm 0 0.34cm 0;
    }}

    section.file-block > :first-child {{
        margin-top: 0;
    }}

    .section-note {{
        margin: 0.1cm 0 0.24cm 0;
        color: #555;
        font-style: italic;
    }}

    .report-table-wrap {{
        width: 100%;
        box-sizing: border-box;
        padding-right: 1cm;
        margin: 0.15cm 0 0.35cm 0;
    }}

    .report-table {{
        width: 100%;
        max-width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
        margin: 0;
        font-size: 9.5pt;
    }}

    .report-table,
    .report-table th,
    .report-table td,
    .report-table-wrap {{
        box-sizing: border-box;
    }}

    .report-table thead {{
        display: table-header-group;
    }}

    .report-table thead th {{
        text-align: left;
        font-weight: 700;
        border-bottom: 1px solid #444;
        padding: 0.12cm 0.16cm 0.12cm 0.16cm;
    }}

    .report-table tbody td {{
        vertical-align: top;
        padding: 0.12cm 0.16cm;
        border-bottom: 1px solid #777;
    }}

    .report-table .col-severity {{
        width: 11%;
        white-space: nowrap;
        overflow-wrap: normal;
        word-break: normal;
        hyphens: manual;
    }}

    .report-table .col-count {{
        width: 8%;
        text-align: right;
        font-variant-numeric: tabular-nums;
    }}

    .report-table .col-message {{
        width: 29%;
    }}

    .report-table .col-examples {{
        width: 52%;
        padding-right: 0.18cm;
        overflow-wrap: anywhere;
        word-break: break-word;
        hyphens: auto;
        white-space: normal;
    }}

    .report-table td,
    .report-table th {{
        overflow-wrap: break-word;
        word-break: normal;
        hyphens: auto;
    }}

    .report-table tr,
    .report-table td,
    .report-table th {{
        break-inside: avoid;
        page-break-inside: avoid;
    }}

    .examples {{
        width: 100%;
        max-width: 100%;
        line-height: 1.22;
    }}

    .examples > div {{
        display: block;
        width: 100%;
        max-width: 100%;
        overflow-wrap: anywhere;
        word-break: break-word;
        white-space: normal;
    }}

    .examples > div + div {{
        margin-top: 0.06cm;
    }}

    @media screen {{
        body {{
            margin: 1rem auto;
            max-width: 1180px;
            padding: 0 1rem 2rem;
        }}
    }}
    """


def render_report_html_document(report: ReportDocument, report_name: str, report_date: str) -> str:
    """Render a structured report document to a full standalone HTML document."""

    section_html_parts: list[str] = []
    for section in report.sections:
        section_html_parts.append(render_report_section_html(section))

    meta_html = render_metadata_list_html(report.metadata, "report-meta")
    styles = build_report_styles(report_name, report_date)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html_lib.escape(report.title, quote=False)}</title>
    <style>
{styles}
    </style>
</head>
<body>
    <main class="report-shell">
        <h1>{render_inline_markdown_html(report.title)}</h1>
        {meta_html}
        {''.join(section_html_parts)}
    </main>
</body>
</html>
"""


def render_report_section_html(section: ReportSection) -> str:
    """Render one report section to HTML."""

    section_class = "file-block summary-block" if section.title.lower().startswith("overall summary") else "file-block"
    parts = [f"<section class=\"{section_class}\">"]
    parts.append(f"<h2>{render_inline_markdown_html(section.title)}</h2>")
    metadata_html = render_metadata_list_html(section.metadata, "file-meta")
    if metadata_html:
        parts.append(metadata_html)
    if section.subtitle:
        parts.append(f"<h3>{render_inline_markdown_html(section.subtitle)}</h3>")
    if section.note:
        parts.append(f"<p class=\"section-note\">{render_inline_markdown_html(section.note)}</p>")
    if section.table:
        parts.append(render_report_table_html(section.table))
    parts.append("</section>")
    return "".join(parts)
