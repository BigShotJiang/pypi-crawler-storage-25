from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

from .constants import DEFAULT_OUT_DIR, DEFAULT_TOP_EXAMPLES, EXIT_NO_LOG_FILES
from .csv_export import write_csv
from .encoding import count_physical_lines, detect_encoding
from .filesystem import backup_file, ensure_dir
from .models import AnalysisConfig, AnalysisRunResult, AnalysisSummary, FileAnalysis, MessageKey
from .normalization import normalize_message
from .parsing import iter_logical_entries, parse_entry
from .report_markdown import build_markdown_report


class NoLogFilesError(FileNotFoundError):
    """Raised when no matching log files are found for an analysis run."""

    exit_code = EXIT_NO_LOG_FILES


def analyze_file(file_path: Path) -> FileAnalysis:
    """Analyze one log file and aggregate raw and normalized message counts."""

    raw_counts: Counter[MessageKey] = Counter()
    norm_counts: Counter[MessageKey] = Counter()
    norm_examples: dict[MessageKey, Counter[str]] = defaultdict(Counter)

    unknown_lines = 0
    total_entries = 0

    encoding = detect_encoding(file_path)
    total_lines = count_physical_lines(file_path, encoding=encoding)

    for entry in iter_logical_entries(file_path, encoding=encoding):
        total_entries += 1
        parsed = parse_entry(entry)
        if not parsed:
            continue

        severity = parsed.severity
        message = parsed.message

        if severity == "UNKNOWN":
            unknown_lines += 1

        raw_counts[(severity, message)] += 1

        normalized_message = normalize_message(message)
        norm_key = (severity, normalized_message)
        norm_counts[norm_key] += 1
        norm_examples[norm_key][message] += 1

    return FileAnalysis(
        file=file_path,
        total_lines=total_lines,
        total_entries=total_entries,
        unknown_lines=unknown_lines,
        raw_counts=raw_counts,
        norm_counts=norm_counts,
        norm_examples=dict(norm_examples),
    )


def sorted_rows(counter: Counter[MessageKey]) -> list[tuple[str, str, int]]:
    """Return aggregated rows in a stable severity/count/message order."""

    return [
        (severity, message, count)
        for (severity, message), count in sorted(
            counter.items(),
            key=lambda item: (item[0][0], -item[1], item[0][1]),
        )
    ]


def find_log_files(logs_dir: Path) -> list[Path]:
    """Return all supported log files from the configured logs directory."""

    return sorted(logs_dir.glob("*.txt"))


def build_default_config(
    *,
    logs_dir: Path,
    out_dir: Path | None = None,
    backup_dir: Path | None = None,
    top_examples: int = DEFAULT_TOP_EXAMPLES,
    convert: bool = False,
) -> AnalysisConfig:
    """Build an analysis configuration with default output locations."""

    resolved_out_dir = out_dir or Path(DEFAULT_OUT_DIR)
    resolved_backup_dir = backup_dir or (resolved_out_dir / "backup")
    return AnalysisConfig(
        logs_dir=logs_dir,
        out_dir=resolved_out_dir,
        backup_dir=resolved_backup_dir,
        top_examples=top_examples,
        convert=convert,
    )


def run_analysis(config: AnalysisConfig) -> AnalysisRunResult:
    """Run the full analysis workflow and write CSV and report outputs."""

    logs_dir = config.logs_dir
    out_dir = config.out_dir
    backup_dir = config.backup_dir or (out_dir / "backup")

    ensure_dir(out_dir)
    ensure_dir(backup_dir)

    log_files = find_log_files(logs_dir)
    if not log_files:
        raise NoLogFilesError(f"No *.txt files found in: {logs_dir.resolve()}")

    summary = AnalysisSummary(
        analyses=[],
        global_raw=Counter(),
        global_norm=Counter(),
        global_norm_examples={},
    )

    for log_file in log_files:
        backup_path = backup_file(log_file, backup_dir)
        analysis = analyze_file(log_file)
        analysis.backup_path = backup_path
        summary.analyses.append(analysis)

        summary.global_raw.update(analysis.raw_counts)
        summary.global_norm.update(analysis.norm_counts)
        for key, counter in analysis.norm_examples.items():
            summary.global_norm_examples.setdefault(key, Counter()).update(counter)

        write_csv(
            out_dir / f"{log_file.stem}.aggregated.csv",
            sorted_rows(analysis.raw_counts),
            headers=["SEVERITY", "MESSAGE", "COUNT"],
        )
        write_csv(
            out_dir / f"{log_file.stem}.aggregated.normalized.csv",
            sorted_rows(analysis.norm_counts),
            headers=["SEVERITY", "MESSAGE_NORMALIZED", "COUNT"],
        )

    write_csv(
        out_dir / "summary.all_files.csv",
        sorted_rows(summary.global_raw),
        headers=["SEVERITY", "MESSAGE", "COUNT"],
    )
    write_csv(
        out_dir / "summary.all_files.normalized.csv",
        sorted_rows(summary.global_norm),
        headers=["SEVERITY", "MESSAGE_NORMALIZED", "COUNT"],
    )

    report_path = out_dir / "report.md"
    report_path.write_text(build_markdown_report(summary, config), encoding="utf-8", newline="\n")

    result = AnalysisRunResult(
        out_dir=out_dir,
        backup_dir=backup_dir,
        report_path=report_path,
        summary=summary,
    )

    if config.convert:
        from .converters import convert_report_md_to_html_pdf

        result.html_path = out_dir / "report.html"
        result.pdf_path = out_dir / "report.pdf"
        result.convert_status = convert_report_md_to_html_pdf(result.report_path, result.html_path, result.pdf_path)

    return result
