import argparse
import sys
from pathlib import Path

from .chunker import split_csv


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Split a large CSV file into smaller chunks with a header row.",
    )
    parser.add_argument("input_file", help="Path to the CSV file")
    parser.add_argument(
        "--chunk-size",
        type=int,
        required=True,
        help="Number of data rows per output file; must be greater than 0",
    )
    parser.add_argument("--encoding", default="utf-8-sig", help="Input and output encoding (Default: utf-8-sig)")
    args = parser.parse_args()
    try:
        result = split_csv(Path(args.input_file), args.chunk_size, encoding=args.encoding)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    print("CSV chunking completed.")
    print(f"- Input: {result.input_file}")
    print(f"- Output directory: {result.output_dir}")
    print(f"- Chunk size: {result.chunk_size}")
    print(f"- Data rows processed: {result.data_rows_processed}")
    print(f"- Files created: {result.files_created}")
