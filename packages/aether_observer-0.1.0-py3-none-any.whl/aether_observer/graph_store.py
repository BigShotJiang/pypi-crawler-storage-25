from __future__ import annotations

import json
from datetime import UTC, datetime
from uuid import NAMESPACE_URL, uuid5

from graphiti_core.driver.driver import GraphProvider
from graphiti_core.edges import EntityEdge, EpisodicEdge
from graphiti_core.graphiti import Graphiti
from graphiti_core.nodes import EntityNode, EpisodeType, EpisodicNode

from aether_observer.drift.features import (
    function_argument_signature,
    function_call_signature,
    infer_run_decision,
    infer_step_action,
    infer_step_decision,
    prompt_signature,
)
from aether_observer.models import (
    DriftAssessment,
    DynamicGuardrailPolicy,
    GraphEdgeView,
    GraphExplanation,
    GraphNodeView,
    GuardrailEvaluation,
    WorkflowDataset,
    WorkflowGraphView,
    WorkflowRun,
)

KUZU_ENTITY_EDGE_SAVE = """
    MATCH (source:Entity {uuid: $source_uuid})
    MATCH (target:Entity {uuid: $target_uuid})
    MERGE (e:RelatesToNode_ {uuid: $uuid})
    SET
        e.group_id = $group_id,
        e.created_at = $created_at,
        e.name = $name,
        e.fact = $fact,
        e.fact_embedding = $fact_embedding,
        e.episodes = $episodes,
        e.expired_at = $expired_at,
        e.valid_at = $valid_at,
        e.invalid_at = $invalid_at,
        e.attributes = $attributes
    WITH source, target, e
    MERGE (source)-[:RELATES_TO]->(e)
    MERGE (e)-[:RELATES_TO]->(target)
    RETURN e.uuid AS uuid
"""


def stable_uuid(*parts: str) -> str:
    return str(uuid5(NAMESPACE_URL, "::".join(parts)))


class GraphitiWorkflowStore:
    def __init__(self, graphiti: Graphiti):
        self.graphiti = graphiti

    async def store_run(self, run: WorkflowRun) -> str:
        episode = EpisodicNode(
            uuid=stable_uuid(run.tenant_id, run.workflow_id, "run-episode", run.run_id),
            name=f"{run.workflow_id}:{run.run_id}",
            group_id=run.tenant_id,
            labels=[],
            source=EpisodeType.json,
            source_description="workflow execution trace",
            content=json.dumps(
                {
                    "record_type": "workflow_run",
                    "tenant_id": run.tenant_id,
                    "workflow_id": run.workflow_id,
                    "observed_at": datetime.now(UTC).isoformat(),
                    "run": run.model_dump(mode="json"),
                },
                default=str,
                sort_keys=True,
            ),
            created_at=datetime.now(UTC),
            valid_at=run.started_at,
            entity_edges=[],
        )
        await episode.save(self.graphiti.driver)

        nodes: list[EntityNode] = []
        edge_ids: list[str] = []

        workflow_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Workflow",
            key=run.workflow_id,
            display_name=run.workflow_id,
            attributes={
                "workflow_id": run.workflow_id,
                "environment": run.environment,
                "workflow_version": run.workflow_version,
            },
        )
        nodes.append(workflow_node)

        run_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Run",
            key=run.run_id,
            display_name=run.run_id,
            attributes={
                "run_id": run.run_id,
                "status": run.status.value,
                "started_at": run.started_at.isoformat(),
                "finished_at": run.finished_at.isoformat() if run.finished_at else None,
            },
        )
        nodes.append(run_node)

        agent_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Agent",
            key=run.agent_name,
            display_name=run.agent_name,
            attributes={"agent_name": run.agent_name},
        )
        nodes.append(agent_node)

        environment_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Environment",
            key=run.environment,
            display_name=run.environment,
            attributes={"environment": run.environment},
        )
        nodes.append(environment_node)

        status_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Status",
            key=run.status.value,
            display_name=run.status.value,
            attributes={"status": run.status.value},
        )
        nodes.append(status_node)

        edge_ids.append(
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=workflow_node,
                target=run_node,
                relation="HAS_RUN",
                fact=f"Workflow {run.workflow_id} executed run {run.run_id}.",
                reference_time=run.started_at,
                episode_uuid=episode.uuid,
                edge_key=f"workflow-run:{run.run_id}",
            )
        )
        edge_ids.append(
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=run_node,
                target=agent_node,
                relation="USED_AGENT",
                fact=f"Run {run.run_id} used agent {run.agent_name}.",
                reference_time=run.started_at,
                episode_uuid=episode.uuid,
                edge_key=f"run-agent:{run.run_id}:{run.agent_name}",
            )
        )
        edge_ids.append(
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=run_node,
                target=environment_node,
                relation="RAN_IN_ENVIRONMENT",
                fact=f"Run {run.run_id} ran in environment {run.environment}.",
                reference_time=run.started_at,
                episode_uuid=episode.uuid,
                edge_key=f"run-environment:{run.run_id}:{run.environment}",
            )
        )
        edge_ids.append(
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=run_node,
                target=status_node,
                relation="FINISHED_WITH_STATUS",
                fact=f"Run {run.run_id} finished with status {run.status.value}.",
                reference_time=run.started_at,
                episode_uuid=episode.uuid,
                edge_key=f"run-status:{run.run_id}:{run.status.value}",
            )
        )

        for dataset in run.datasets:
            dataset_node = await self._upsert_dataset(tenant_id=run.tenant_id, dataset=dataset)
            nodes.append(dataset_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=run.tenant_id,
                    source=run_node,
                    target=dataset_node,
                    relation="CONSUMED_DATASET",
                    fact=(
                        f"Run {run.run_id} consumed dataset {dataset.name} version "
                        f"{dataset.version or 'unknown'}."
                    ),
                    reference_time=run.started_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"run-dataset:{run.run_id}:{dataset.name}:{dataset.version}",
                )
            )

        seen_models: dict[str, EntityNode] = {}
        seen_prompts: dict[str, EntityNode] = {}
        seen_tools: dict[str, EntityNode] = {}
        seen_actions: dict[str, EntityNode] = {}
        seen_decisions: dict[str, EntityNode] = {}
        seen_functions: dict[str, EntityNode] = {}
        seen_argument_shapes: dict[str, EntityNode] = {}

        for step in run.steps:
            step_node = await self._upsert_entity(
                tenant_id=run.tenant_id,
                kind="Step",
                key=f"{run.run_id}:{step.step_id}",
                display_name=f"{step.step_id}:{step.name}",
                attributes={
                    "step_id": step.step_id,
                    "step_name": step.name,
                    "step_kind": step.kind.value,
                    "status": step.status.value,
                    "latency_ms": step.latency_ms,
                },
            )
            nodes.append(step_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=run.tenant_id,
                    source=run_node,
                    target=step_node,
                    relation="HAS_STEP",
                    fact=(
                        f"Run {run.run_id} executed step {step.name} "
                        f"({step.kind.value}) with status {step.status.value}."
                    ),
                    reference_time=run.started_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"run-step:{run.run_id}:{step.step_id}",
                )
            )

            if step.model:
                model_node = seen_models.get(step.model)
                if model_node is None:
                    model_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="Model",
                        key=step.model,
                        display_name=step.model,
                        attributes={"model_id": step.model},
                    )
                    nodes.append(model_node)
                    edge_ids.append(
                        await self._upsert_fact(
                            tenant_id=run.tenant_id,
                            source=run_node,
                            target=model_node,
                            relation="USED_MODEL",
                            fact=f"Run {run.run_id} used model {step.model}.",
                            reference_time=run.started_at,
                            episode_uuid=episode.uuid,
                            edge_key=f"run-model:{run.run_id}:{step.model}",
                        )
                    )
                    seen_models[step.model] = model_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=model_node,
                        relation="EXECUTED_WITH_MODEL",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"executed with model {step.model}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=f"step-model:{run.run_id}:{step.step_id}:{step.model}",
                    )
                )

            prompt_key = prompt_signature(step)
            if prompt_key:
                prompt_node = seen_prompts.get(prompt_key)
                if prompt_node is None:
                    prompt_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="Prompt",
                        key=prompt_key,
                        display_name=prompt_key,
                        attributes={
                            "prompt_name": step.prompt_name,
                            "prompt_version": step.prompt_version,
                        },
                    )
                    nodes.append(prompt_node)
                    edge_ids.append(
                        await self._upsert_fact(
                            tenant_id=run.tenant_id,
                            source=run_node,
                            target=prompt_node,
                            relation="USED_PROMPT",
                            fact=f"Run {run.run_id} used prompt {prompt_key}.",
                            reference_time=run.started_at,
                            episode_uuid=episode.uuid,
                            edge_key=f"run-prompt:{run.run_id}:{prompt_key}",
                        )
                    )
                    seen_prompts[prompt_key] = prompt_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=prompt_node,
                        relation="USED_STEP_PROMPT",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"used prompt {prompt_key}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=f"step-prompt:{run.run_id}:{step.step_id}:{prompt_key}",
                    )
                )

            if step.tool_name:
                tool_node = seen_tools.get(step.tool_name)
                if tool_node is None:
                    tool_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="Tool",
                        key=step.tool_name,
                        display_name=step.tool_name,
                        attributes={"tool_name": step.tool_name},
                    )
                    nodes.append(tool_node)
                    edge_ids.append(
                        await self._upsert_fact(
                            tenant_id=run.tenant_id,
                            source=run_node,
                            target=tool_node,
                            relation="INVOKED_TOOL",
                            fact=f"Run {run.run_id} invoked tool {step.tool_name}.",
                            reference_time=run.started_at,
                            episode_uuid=episode.uuid,
                            edge_key=f"run-tool:{run.run_id}:{step.tool_name}",
                        )
                    )
                    seen_tools[step.tool_name] = tool_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=tool_node,
                        relation="USED_STEP_TOOL",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"invoked tool {step.tool_name}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=f"step-tool:{run.run_id}:{step.step_id}:{step.tool_name}",
                    )
                )

            decision_key = infer_step_decision(step)
            if decision_key:
                decision_node = seen_decisions.get(decision_key)
                if decision_node is None:
                    decision_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="Decision",
                        key=decision_key,
                        display_name=decision_key,
                        attributes={
                            "decision_name": step.decision_name,
                            "decision_value": step.decision_value,
                        },
                    )
                    nodes.append(decision_node)
                    seen_decisions[decision_key] = decision_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=decision_node,
                        relation="MADE_DECISION",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"made decision {decision_key}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=f"step-decision:{run.run_id}:{step.step_id}:{decision_key}",
                    )
                )

            action_key = infer_step_action(step)
            if action_key:
                action_node = seen_actions.get(action_key)
                if action_node is None:
                    action_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="Action",
                        key=action_key,
                        display_name=action_key,
                        attributes={"action_name": action_key},
                    )
                    nodes.append(action_node)
                    seen_actions[action_key] = action_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=action_node,
                        relation="SELECTED_ACTION",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"selected action {action_key}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=f"step-action:{run.run_id}:{step.step_id}:{action_key}",
                    )
                )

            for candidate_action in step.candidate_actions:
                candidate_node = seen_actions.get(candidate_action)
                if candidate_node is None:
                    candidate_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="Action",
                        key=candidate_action,
                        display_name=candidate_action,
                        attributes={"action_name": candidate_action},
                    )
                    nodes.append(candidate_node)
                    seen_actions[candidate_action] = candidate_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=candidate_node,
                        relation="CONSIDERED_ACTION",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"considered action {candidate_action}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=(
                            f"step-candidate-action:{run.run_id}:{step.step_id}:{candidate_action}"
                        ),
                    )
                )

            for call_signature, argument_signature in zip(
                function_call_signature(step),
                function_argument_signature(step),
                strict=False,
            ):
                function_name = call_signature.split("(", 1)[0]
                function_node = seen_functions.get(function_name)
                if function_node is None:
                    function_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="Function",
                        key=function_name,
                        display_name=function_name,
                        attributes={"function_name": function_name},
                    )
                    nodes.append(function_node)
                    seen_functions[function_name] = function_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=function_node,
                        relation="CALLED_FUNCTION",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"called function {call_signature}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=f"step-function:{run.run_id}:{step.step_id}:{call_signature}",
                    )
                )

                argument_node = seen_argument_shapes.get(argument_signature)
                if argument_node is None:
                    argument_node = await self._upsert_entity(
                        tenant_id=run.tenant_id,
                        kind="FunctionArguments",
                        key=argument_signature,
                        display_name=argument_signature,
                        attributes={"argument_signature": argument_signature},
                    )
                    nodes.append(argument_node)
                    seen_argument_shapes[argument_signature] = argument_node
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=argument_node,
                        relation="USED_ARGUMENT_SHAPE",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"called function arguments {argument_signature}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=(
                            f"step-function-arguments:{run.run_id}:{step.step_id}:{argument_signature}"
                        ),
                    )
                )

            for dataset in step.datasets:
                dataset_node = await self._upsert_dataset(tenant_id=run.tenant_id, dataset=dataset)
                nodes.append(dataset_node)
                edge_ids.append(
                    await self._upsert_fact(
                        tenant_id=run.tenant_id,
                        source=step_node,
                        target=dataset_node,
                        relation="STEP_CONSUMED_DATASET",
                        fact=(
                            f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                            f"consumed dataset {dataset.name} version {dataset.version or 'unknown'}."
                        ),
                        reference_time=run.started_at,
                        episode_uuid=episode.uuid,
                        edge_key=f"run-step-dataset:{run.run_id}:{step.name}:{dataset.name}:{dataset.version}",
                    )
                )

        run_decision = infer_run_decision(run)
        if run_decision:
            decision_node = seen_decisions.get(run_decision)
            if decision_node is None:
                decision_node = await self._upsert_entity(
                    tenant_id=run.tenant_id,
                    kind="Decision",
                    key=run_decision,
                    display_name=run_decision,
                    attributes={"decision_name": "run", "decision_value": run_decision},
                )
                nodes.append(decision_node)
                seen_decisions[run_decision] = decision_node
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=run.tenant_id,
                    source=run_node,
                    target=decision_node,
                    relation="FINAL_DECISION",
                    fact=f"Run {run.run_id} ended with decision {run_decision}.",
                    reference_time=run.started_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"run-final-decision:{run.run_id}:{run_decision}",
                )
            )

        episode.entity_edges = sorted(set(edge_ids))
        await episode.save(self.graphiti.driver)

        for node in {item.uuid: item for item in nodes}.values():
            await self._link_episode_to_entity(
                tenant_id=run.tenant_id,
                episode_uuid=episode.uuid,
                entity_uuid=node.uuid,
                created_at=episode.created_at,
            )

        return episode.uuid

    async def store_assessment(
        self,
        run: WorkflowRun,
        assessment: DriftAssessment,
        graph_context: list[str],
        graph_explanations: list[GraphExplanation],
        recommendation_summary: str | None,
    ) -> str:
        observed_at = datetime.now(UTC)
        episode = EpisodicNode(
            uuid=stable_uuid(run.tenant_id, run.workflow_id, "drift-episode", run.run_id),
            name=f"{run.workflow_id}:{run.run_id}:drift",
            group_id=run.tenant_id,
            labels=[],
            source=EpisodeType.json,
            source_description="aether drift alert",
            content=json.dumps(
                {
                    "record_type": "drift_alert",
                    "tenant_id": run.tenant_id,
                    "workflow_id": run.workflow_id,
                    "run_id": run.run_id,
                    "observed_at": observed_at.isoformat(),
                    "assessment": assessment.model_dump(mode="json"),
                    "graph_context": graph_context,
                    "graph_explanations": [
                        explanation.model_dump(mode="json") for explanation in graph_explanations
                    ],
                    "recommendation_summary": recommendation_summary,
                },
                default=str,
                sort_keys=True,
            ),
            created_at=observed_at,
            valid_at=observed_at,
            entity_edges=[],
        )
        await episode.save(self.graphiti.driver)

        workflow_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Workflow",
            key=run.workflow_id,
            display_name=run.workflow_id,
            attributes={"workflow_id": run.workflow_id},
        )
        alert_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="DriftAlert",
            key=run.run_id,
            display_name=f"drift:{run.run_id}",
            attributes={
                "run_id": run.run_id,
                "risk_score": assessment.risk_score,
                "severity": assessment.severity.value,
            },
        )
        run_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Run",
            key=run.run_id,
            display_name=run.run_id,
            attributes={"run_id": run.run_id},
        )

        edge_ids = [
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=workflow_node,
                target=alert_node,
                relation="HAS_DRIFT_ALERT",
                fact=f"Workflow {run.workflow_id} produced drift alert for run {run.run_id}.",
                reference_time=observed_at,
                episode_uuid=episode.uuid,
                edge_key=f"workflow-alert:{run.run_id}",
            ),
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=alert_node,
                target=run_node,
                relation="ALERT_FOR_RUN",
                fact=f"Drift alert for run {run.run_id} has severity {assessment.severity.value}.",
                reference_time=observed_at,
                episode_uuid=episode.uuid,
                edge_key=f"alert-run:{run.run_id}",
            ),
        ]

        nodes = [workflow_node, alert_node, run_node]

        for signal in assessment.signals:
            signal_key = f"{run.run_id}:{signal.kind}"
            signal_node = await self._upsert_entity(
                tenant_id=run.tenant_id,
                kind="DriftSignal",
                key=signal_key,
                display_name=signal.kind,
                attributes={
                    "drift_type": signal.drift_type.value,
                    "kind": signal.kind,
                    "severity": signal.severity.value,
                    "score": signal.score,
                },
            )
            nodes.append(signal_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=run.tenant_id,
                    source=alert_node,
                    target=signal_node,
                    relation="INCLUDES_SIGNAL",
                    fact=(
                        f"Drift alert for run {run.run_id} includes signal {signal.kind} "
                        f"with severity {signal.severity.value}."
                    ),
                    reference_time=observed_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"alert-signal:{run.run_id}:{signal.kind}",
                )
            )

        episode.entity_edges = sorted(set(edge_ids))
        await episode.save(self.graphiti.driver)

        for node in {item.uuid: item for item in nodes}.values():
            await self._link_episode_to_entity(
                tenant_id=run.tenant_id,
                episode_uuid=episode.uuid,
                entity_uuid=node.uuid,
                created_at=episode.created_at,
            )

        return episode.uuid

    async def store_guardrail_policy(self, policy: DynamicGuardrailPolicy) -> str:
        observed_at = datetime.now(UTC)
        episode = EpisodicNode(
            uuid=stable_uuid(policy.tenant_id, policy.workflow_id, "guardrail-policy", policy.policy_id),
            name=f"{policy.workflow_id}:{policy.policy_id}:guardrail-policy",
            group_id=policy.tenant_id,
            labels=[],
            source=EpisodeType.json,
            source_description="aether guardrail policy",
            content=json.dumps(
                {
                    "record_type": "guardrail_policy",
                    "tenant_id": policy.tenant_id,
                    "workflow_id": policy.workflow_id,
                    "policy": policy.model_dump(mode="json"),
                    "observed_at": observed_at.isoformat(),
                },
                default=str,
                sort_keys=True,
            ),
            created_at=observed_at,
            valid_at=observed_at,
            entity_edges=[],
        )
        await episode.save(self.graphiti.driver)

        workflow_node = await self._upsert_entity(
            tenant_id=policy.tenant_id,
            kind="Workflow",
            key=policy.workflow_id,
            display_name=policy.workflow_id,
            attributes={"workflow_id": policy.workflow_id},
        )
        policy_node = await self._upsert_entity(
            tenant_id=policy.tenant_id,
            kind="GuardrailPolicy",
            key=policy.policy_id,
            display_name=policy.policy_id,
            attributes={
                "policy_id": policy.policy_id,
                "mode": policy.mode.value,
                "enabled": policy.enabled,
            },
        )
        mode_node = await self._upsert_entity(
            tenant_id=policy.tenant_id,
            kind="GuardrailMode",
            key=policy.mode.value,
            display_name=policy.mode.value,
            attributes={"mode": policy.mode.value},
        )

        nodes = [workflow_node, policy_node, mode_node]
        edge_ids = [
            await self._upsert_fact(
                tenant_id=policy.tenant_id,
                source=workflow_node,
                target=policy_node,
                relation="HAS_GUARDRAIL_POLICY",
                fact=(
                    f"Workflow {policy.workflow_id} is governed by guardrail policy "
                    f"{policy.policy_id}."
                ),
                reference_time=observed_at,
                episode_uuid=episode.uuid,
                edge_key=f"workflow-guardrail-policy:{policy.workflow_id}:{policy.policy_id}",
            ),
            await self._upsert_fact(
                tenant_id=policy.tenant_id,
                source=policy_node,
                target=mode_node,
                relation="ENFORCED_WITH_MODE",
                fact=(
                    f"Guardrail policy {policy.policy_id} is enforced in mode "
                    f"{policy.mode.value}."
                ),
                reference_time=observed_at,
                episode_uuid=episode.uuid,
                edge_key=f"guardrail-policy-mode:{policy.policy_id}:{policy.mode.value}",
            ),
        ]

        for action in policy.allowed_actions:
            action_node = await self._upsert_entity(
                tenant_id=policy.tenant_id,
                kind="Action",
                key=action,
                display_name=action,
                attributes={"action_name": action},
            )
            nodes.append(action_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=policy.tenant_id,
                    source=policy_node,
                    target=action_node,
                    relation="ALLOWS_ACTION",
                    fact=f"Guardrail policy {policy.policy_id} allows action {action}.",
                    reference_time=observed_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"guardrail-policy-allow-action:{policy.policy_id}:{action}",
                )
            )

        for action in policy.blocked_actions:
            action_node = await self._upsert_entity(
                tenant_id=policy.tenant_id,
                kind="Action",
                key=action,
                display_name=action,
                attributes={"action_name": action},
            )
            nodes.append(action_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=policy.tenant_id,
                    source=policy_node,
                    target=action_node,
                    relation="BLOCKS_ACTION",
                    fact=f"Guardrail policy {policy.policy_id} blocks action {action}.",
                    reference_time=observed_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"guardrail-policy-block-action:{policy.policy_id}:{action}",
                )
            )

        for action in policy.require_approval_actions:
            action_node = await self._upsert_entity(
                tenant_id=policy.tenant_id,
                kind="Action",
                key=action,
                display_name=action,
                attributes={"action_name": action},
            )
            nodes.append(action_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=policy.tenant_id,
                    source=policy_node,
                    target=action_node,
                    relation="REQUIRES_APPROVAL_FOR_ACTION",
                    fact=(
                        f"Guardrail policy {policy.policy_id} requires approval for "
                        f"action {action}."
                    ),
                    reference_time=observed_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"guardrail-policy-approval-action:{policy.policy_id}:{action}",
                )
            )

        for function_name in policy.allowed_functions:
            function_node = await self._upsert_entity(
                tenant_id=policy.tenant_id,
                kind="Function",
                key=function_name,
                display_name=function_name,
                attributes={"function_name": function_name},
            )
            nodes.append(function_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=policy.tenant_id,
                    source=policy_node,
                    target=function_node,
                    relation="ALLOWS_FUNCTION",
                    fact=(
                        f"Guardrail policy {policy.policy_id} allows function "
                        f"{function_name}."
                    ),
                    reference_time=observed_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"guardrail-policy-allow-function:{policy.policy_id}:{function_name}",
                )
            )

        for function_name in policy.blocked_functions:
            function_node = await self._upsert_entity(
                tenant_id=policy.tenant_id,
                kind="Function",
                key=function_name,
                display_name=function_name,
                attributes={"function_name": function_name},
            )
            nodes.append(function_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=policy.tenant_id,
                    source=policy_node,
                    target=function_node,
                    relation="BLOCKS_FUNCTION",
                    fact=(
                        f"Guardrail policy {policy.policy_id} blocks function "
                        f"{function_name}."
                    ),
                    reference_time=observed_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"guardrail-policy-block-function:{policy.policy_id}:{function_name}",
                )
            )

        episode.entity_edges = sorted(set(edge_ids))
        await episode.save(self.graphiti.driver)

        for node in {item.uuid: item for item in nodes}.values():
            await self._link_episode_to_entity(
                tenant_id=policy.tenant_id,
                episode_uuid=episode.uuid,
                entity_uuid=node.uuid,
                created_at=episode.created_at,
            )

        return episode.uuid

    async def store_guardrail_incident(
        self,
        run: WorkflowRun,
        evaluation: GuardrailEvaluation,
    ) -> str:
        observed_at = datetime.now(UTC)
        episode = EpisodicNode(
            uuid=stable_uuid(run.tenant_id, run.workflow_id, "guardrail-incident", run.run_id),
            name=f"{run.workflow_id}:{run.run_id}:guardrail-incident",
            group_id=run.tenant_id,
            labels=[],
            source=EpisodeType.json,
            source_description="aether guardrail incident",
            content=json.dumps(
                {
                    "record_type": "guardrail_incident",
                    "tenant_id": run.tenant_id,
                    "workflow_id": run.workflow_id,
                    "run_id": run.run_id,
                    "observed_at": observed_at.isoformat(),
                    "evaluation": evaluation.model_dump(mode="json"),
                },
                default=str,
                sort_keys=True,
            ),
            created_at=observed_at,
            valid_at=observed_at,
            entity_edges=[],
        )
        await episode.save(self.graphiti.driver)

        workflow_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Workflow",
            key=run.workflow_id,
            display_name=run.workflow_id,
            attributes={"workflow_id": run.workflow_id},
        )
        run_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="Run",
            key=run.run_id,
            display_name=run.run_id,
            attributes={"run_id": run.run_id},
        )
        incident_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="GuardrailIncident",
            key=run.run_id,
            display_name=f"guardrail:{run.run_id}",
            attributes={
                "run_id": run.run_id,
                "policy_id": evaluation.policy_id,
                "mode": evaluation.mode.value,
                "verdict": evaluation.verdict.value,
                "stopped_run": evaluation.stopped_run,
                "stop_reason": evaluation.stop_reason,
            },
        )
        policy_node = await self._upsert_entity(
            tenant_id=run.tenant_id,
            kind="GuardrailPolicy",
            key=evaluation.policy_id or "unknown",
            display_name=evaluation.policy_id or "unknown",
            attributes={"policy_id": evaluation.policy_id},
        )

        nodes = [workflow_node, run_node, incident_node, policy_node]
        edge_ids = [
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=workflow_node,
                target=incident_node,
                relation="HAS_GUARDRAIL_INCIDENT",
                fact=(
                    f"Workflow {run.workflow_id} produced guardrail incident for run "
                    f"{run.run_id}."
                ),
                reference_time=observed_at,
                episode_uuid=episode.uuid,
                edge_key=f"workflow-guardrail-incident:{run.run_id}",
            ),
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=incident_node,
                target=run_node,
                relation="INCIDENT_FOR_RUN",
                fact=(
                    f"Guardrail incident for run {run.run_id} resolved to verdict "
                    f"{evaluation.verdict.value}."
                ),
                reference_time=observed_at,
                episode_uuid=episode.uuid,
                edge_key=f"guardrail-incident-run:{run.run_id}",
            ),
            await self._upsert_fact(
                tenant_id=run.tenant_id,
                source=incident_node,
                target=policy_node,
                relation="EVALUATED_AGAINST_POLICY",
                fact=(
                    f"Run {run.run_id} was evaluated against guardrail policy "
                    f"{evaluation.policy_id}."
                ),
                reference_time=observed_at,
                episode_uuid=episode.uuid,
                edge_key=f"guardrail-incident-policy:{run.run_id}:{evaluation.policy_id}",
            ),
        ]

        for violation in evaluation.violations:
            violation_key = f"{run.run_id}:{violation.kind}"
            violation_node = await self._upsert_entity(
                tenant_id=run.tenant_id,
                kind="GuardrailViolation",
                key=violation_key,
                display_name=violation.kind,
                attributes={
                    "kind": violation.kind,
                    "severity": violation.severity.value,
                    "mode": violation.mode.value,
                    "step_id": violation.step_id,
                },
            )
            nodes.append(violation_node)
            edge_ids.append(
                await self._upsert_fact(
                    tenant_id=run.tenant_id,
                    source=incident_node,
                    target=violation_node,
                    relation="INCLUDES_GUARDRAIL_VIOLATION",
                    fact=(
                        f"Guardrail incident for run {run.run_id} includes violation "
                        f"{violation.kind}."
                    ),
                    reference_time=observed_at,
                    episode_uuid=episode.uuid,
                    edge_key=f"guardrail-incident-violation:{run.run_id}:{violation.kind}",
                )
            )

        episode.entity_edges = sorted(set(edge_ids))
        await episode.save(self.graphiti.driver)

        for node in {item.uuid: item for item in nodes}.values():
            await self._link_episode_to_entity(
                tenant_id=run.tenant_id,
                episode_uuid=episode.uuid,
                entity_uuid=node.uuid,
                created_at=episode.created_at,
            )

        return episode.uuid

    @staticmethod
    def project_run_graph(run: WorkflowRun) -> WorkflowGraphView:
        nodes: dict[str, GraphNodeView] = {}
        edges: dict[str, GraphEdgeView] = {}

        def add_node(kind: str, key: str, label: str, attributes: dict[str, object]) -> GraphNodeView:
            uuid = stable_uuid(run.tenant_id, kind, key)
            node = nodes.get(uuid)
            if node is None:
                node = GraphNodeView(uuid=uuid, kind=kind, label=label, attributes=attributes)
                nodes[uuid] = node
            return node

        def add_edge(
            source: GraphNodeView,
            target: GraphNodeView,
            relation: str,
            fact: str,
            edge_key: str,
        ) -> None:
            uuid = stable_uuid(run.tenant_id, relation, edge_key)
            edges[uuid] = GraphEdgeView(
                uuid=uuid,
                source=source.uuid,
                target=target.uuid,
                relation=relation,
                fact=fact,
                episodes=[],
                valid_at=run.started_at,
            )

        workflow_node = add_node(
            kind="Workflow",
            key=run.workflow_id,
            label=run.workflow_id,
            attributes={
                "workflow_id": run.workflow_id,
                "environment": run.environment,
                "workflow_version": run.workflow_version,
            },
        )
        run_node = add_node(
            kind="Run",
            key=run.run_id,
            label=run.run_id,
            attributes={
                "run_id": run.run_id,
                "status": run.status.value,
                "started_at": run.started_at.isoformat(),
                "finished_at": run.finished_at.isoformat() if run.finished_at else None,
            },
        )
        agent_node = add_node(
            kind="Agent",
            key=run.agent_name,
            label=run.agent_name,
            attributes={"agent_name": run.agent_name},
        )
        environment_node = add_node(
            kind="Environment",
            key=run.environment,
            label=run.environment,
            attributes={"environment": run.environment},
        )
        status_node = add_node(
            kind="Status",
            key=run.status.value,
            label=run.status.value,
            attributes={"status": run.status.value},
        )

        add_edge(
            workflow_node,
            run_node,
            "HAS_RUN",
            f"Workflow {run.workflow_id} executed run {run.run_id}.",
            f"workflow-run:{run.run_id}",
        )
        add_edge(
            run_node,
            agent_node,
            "USED_AGENT",
            f"Run {run.run_id} used agent {run.agent_name}.",
            f"run-agent:{run.run_id}:{run.agent_name}",
        )
        add_edge(
            run_node,
            environment_node,
            "RAN_IN_ENVIRONMENT",
            f"Run {run.run_id} ran in environment {run.environment}.",
            f"run-environment:{run.run_id}:{run.environment}",
        )
        add_edge(
            run_node,
            status_node,
            "FINISHED_WITH_STATUS",
            f"Run {run.run_id} finished with status {run.status.value}.",
            f"run-status:{run.run_id}:{run.status.value}",
        )

        seen_models: dict[str, GraphNodeView] = {}
        seen_prompts: dict[str, GraphNodeView] = {}
        seen_tools: dict[str, GraphNodeView] = {}
        seen_actions: dict[str, GraphNodeView] = {}
        seen_decisions: dict[str, GraphNodeView] = {}
        seen_functions: dict[str, GraphNodeView] = {}
        seen_argument_shapes: dict[str, GraphNodeView] = {}

        def dataset_node(dataset: WorkflowDataset) -> GraphNodeView:
            version = dataset.version or "unknown"
            label = f"{dataset.name}:{version}"
            return add_node(
                kind="Dataset",
                key=label,
                label=label,
                attributes={
                    "dataset_name": dataset.name,
                    "dataset_version": dataset.version,
                    "dataset_schema_hash": dataset.schema_hash,
                    "row_count": dataset.row_count,
                },
            )

        for dataset in run.datasets:
            current_dataset = dataset_node(dataset)
            add_edge(
                run_node,
                current_dataset,
                "CONSUMED_DATASET",
                (
                    f"Run {run.run_id} consumed dataset {dataset.name} version "
                    f"{dataset.version or 'unknown'}."
                ),
                f"run-dataset:{run.run_id}:{dataset.name}:{dataset.version}",
            )

        for step in run.steps:
            step_node = add_node(
                kind="Step",
                key=f"{run.run_id}:{step.step_id}",
                label=f"{step.step_id}:{step.name}",
                attributes={
                    "step_id": step.step_id,
                    "step_name": step.name,
                    "step_kind": step.kind.value,
                    "status": step.status.value,
                    "latency_ms": step.latency_ms,
                },
            )
            add_edge(
                run_node,
                step_node,
                "HAS_STEP",
                (
                    f"Run {run.run_id} executed step {step.name} "
                    f"({step.kind.value}) with status {step.status.value}."
                ),
                f"run-step:{run.run_id}:{step.step_id}",
            )

            if step.model:
                model_node = seen_models.get(step.model)
                if model_node is None:
                    model_node = add_node(
                        kind="Model",
                        key=step.model,
                        label=step.model,
                        attributes={"model_id": step.model},
                    )
                    seen_models[step.model] = model_node
                    add_edge(
                        run_node,
                        model_node,
                        "USED_MODEL",
                        f"Run {run.run_id} used model {step.model}.",
                        f"run-model:{run.run_id}:{step.model}",
                    )
                add_edge(
                    step_node,
                    model_node,
                    "EXECUTED_WITH_MODEL",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"executed with model {step.model}."
                    ),
                    f"step-model:{run.run_id}:{step.step_id}:{step.model}",
                )

            prompt_key = prompt_signature(step)
            if prompt_key:
                prompt_node = seen_prompts.get(prompt_key)
                if prompt_node is None:
                    prompt_node = add_node(
                        kind="Prompt",
                        key=prompt_key,
                        label=prompt_key,
                        attributes={
                            "prompt_name": step.prompt_name,
                            "prompt_version": step.prompt_version,
                        },
                    )
                    seen_prompts[prompt_key] = prompt_node
                    add_edge(
                        run_node,
                        prompt_node,
                        "USED_PROMPT",
                        f"Run {run.run_id} used prompt {prompt_key}.",
                        f"run-prompt:{run.run_id}:{prompt_key}",
                    )
                add_edge(
                    step_node,
                    prompt_node,
                    "USED_STEP_PROMPT",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"used prompt {prompt_key}."
                    ),
                    f"step-prompt:{run.run_id}:{step.step_id}:{prompt_key}",
                )

            if step.tool_name:
                tool_node = seen_tools.get(step.tool_name)
                if tool_node is None:
                    tool_node = add_node(
                        kind="Tool",
                        key=step.tool_name,
                        label=step.tool_name,
                        attributes={"tool_name": step.tool_name},
                    )
                    seen_tools[step.tool_name] = tool_node
                    add_edge(
                        run_node,
                        tool_node,
                        "INVOKED_TOOL",
                        f"Run {run.run_id} invoked tool {step.tool_name}.",
                        f"run-tool:{run.run_id}:{step.tool_name}",
                    )
                add_edge(
                    step_node,
                    tool_node,
                    "USED_STEP_TOOL",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"invoked tool {step.tool_name}."
                    ),
                    f"step-tool:{run.run_id}:{step.step_id}:{step.tool_name}",
                )

            decision_key = infer_step_decision(step)
            if decision_key:
                decision_node = seen_decisions.get(decision_key)
                if decision_node is None:
                    decision_node = add_node(
                        kind="Decision",
                        key=decision_key,
                        label=decision_key,
                        attributes={
                            "decision_name": step.decision_name,
                            "decision_value": step.decision_value,
                        },
                    )
                    seen_decisions[decision_key] = decision_node
                add_edge(
                    step_node,
                    decision_node,
                    "MADE_DECISION",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"made decision {decision_key}."
                    ),
                    f"step-decision:{run.run_id}:{step.step_id}:{decision_key}",
                )

            action_key = infer_step_action(step)
            if action_key:
                action_node = seen_actions.get(action_key)
                if action_node is None:
                    action_node = add_node(
                        kind="Action",
                        key=action_key,
                        label=action_key,
                        attributes={"action_name": action_key},
                    )
                    seen_actions[action_key] = action_node
                add_edge(
                    step_node,
                    action_node,
                    "SELECTED_ACTION",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"selected action {action_key}."
                    ),
                    f"step-action:{run.run_id}:{step.step_id}:{action_key}",
                )

            for candidate_action in step.candidate_actions:
                candidate_node = seen_actions.get(candidate_action)
                if candidate_node is None:
                    candidate_node = add_node(
                        kind="Action",
                        key=candidate_action,
                        label=candidate_action,
                        attributes={"action_name": candidate_action},
                    )
                    seen_actions[candidate_action] = candidate_node
                add_edge(
                    step_node,
                    candidate_node,
                    "CONSIDERED_ACTION",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"considered action {candidate_action}."
                    ),
                    f"step-candidate-action:{run.run_id}:{step.step_id}:{candidate_action}",
                )

            for call_signature, argument_signature in zip(
                function_call_signature(step),
                function_argument_signature(step),
                strict=False,
            ):
                function_name = call_signature.split("(", 1)[0]
                function_node = seen_functions.get(function_name)
                if function_node is None:
                    function_node = add_node(
                        kind="Function",
                        key=function_name,
                        label=function_name,
                        attributes={"function_name": function_name},
                    )
                    seen_functions[function_name] = function_node
                add_edge(
                    step_node,
                    function_node,
                    "CALLED_FUNCTION",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"called function {call_signature}."
                    ),
                    f"step-function:{run.run_id}:{step.step_id}:{call_signature}",
                )

                argument_node = seen_argument_shapes.get(argument_signature)
                if argument_node is None:
                    argument_node = add_node(
                        kind="FunctionArguments",
                        key=argument_signature,
                        label=argument_signature,
                        attributes={"argument_signature": argument_signature},
                    )
                    seen_argument_shapes[argument_signature] = argument_node
                add_edge(
                    step_node,
                    argument_node,
                    "USED_ARGUMENT_SHAPE",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"called function arguments {argument_signature}."
                    ),
                    f"step-function-arguments:{run.run_id}:{step.step_id}:{argument_signature}",
                )

            for dataset in step.datasets:
                current_dataset = dataset_node(dataset)
                add_edge(
                    step_node,
                    current_dataset,
                    "STEP_CONSUMED_DATASET",
                    (
                        f"Workflow {run.workflow_id} run {run.run_id} step {step.name} "
                        f"consumed dataset {dataset.name} version {dataset.version or 'unknown'}."
                    ),
                    f"run-step-dataset:{run.run_id}:{step.name}:{dataset.name}:{dataset.version}",
                )

        run_decision = infer_run_decision(run)
        if run_decision:
            decision_node = seen_decisions.get(run_decision)
            if decision_node is None:
                decision_node = add_node(
                    kind="Decision",
                    key=run_decision,
                    label=run_decision,
                    attributes={"decision_name": "run", "decision_value": run_decision},
                )
                seen_decisions[run_decision] = decision_node
            add_edge(
                run_node,
                decision_node,
                "FINAL_DECISION",
                f"Run {run.run_id} ended with decision {run_decision}.",
                f"run-final-decision:{run.run_id}:{run_decision}",
            )

        return WorkflowGraphView(
            tenant_id=run.tenant_id,
            workflow_id=run.workflow_id,
            run_id=run.run_id,
            nodes=sorted(nodes.values(), key=lambda item: (item.kind, item.label, item.uuid)),
            edges=sorted(
                edges.values(),
                key=lambda item: (item.relation, item.source, item.target, item.uuid),
            ),
            focus_node_ids=[workflow_node.uuid, run_node.uuid],
        )

    async def workflow_graph(
        self,
        tenant_id: str,
        workflow_id: str,
        run_id: str | None = None,
        limit: int = 300,
    ) -> WorkflowGraphView:
        nodes = await EntityNode.get_by_group_ids(
            self.graphiti.driver,
            group_ids=[tenant_id],
            limit=max(limit * 6, 600),
        )
        edges = await EntityEdge.get_by_group_ids(
            self.graphiti.driver,
            group_ids=[tenant_id],
            limit=max(limit * 10, 1000),
        )

        node_map = {node.uuid: node for node in nodes}
        workflow_uuid = stable_uuid(tenant_id, "Workflow", workflow_id)
        run_uuid = stable_uuid(tenant_id, "Run", run_id) if run_id else None
        alert_uuid = stable_uuid(tenant_id, "DriftAlert", run_id) if run_id else None
        incident_uuid = stable_uuid(tenant_id, "GuardrailIncident", run_id) if run_id else None

        outgoing: dict[str, list[EntityEdge]] = {}
        for edge in edges:
            outgoing.setdefault(edge.source_node_uuid, []).append(edge)

        selected_node_ids: set[str] = set()
        selected_edge_ids: set[str] = set()
        frontier: list[tuple[str, int]] = []

        if workflow_uuid in node_map:
            selected_node_ids.add(workflow_uuid)
            frontier.append((workflow_uuid, 0))

        for seed_uuid in [run_uuid, alert_uuid, incident_uuid]:
            if seed_uuid and seed_uuid in node_map:
                selected_node_ids.add(seed_uuid)
                frontier.append((seed_uuid, 0))

        max_depth = 3 if run_id else 2
        while frontier and len(selected_node_ids) < limit:
            source_uuid, depth = frontier.pop(0)
            if depth > max_depth:
                continue

            for edge in outgoing.get(source_uuid, []):
                target_node = node_map.get(edge.target_node_uuid)
                if target_node is None:
                    continue
                if not self._include_graph_neighbor(
                    source_uuid=source_uuid,
                    edge=edge,
                    node=target_node,
                    workflow_uuid=workflow_uuid,
                    run_uuid=run_uuid,
                    run_id=run_id,
                ):
                    continue

                selected_edge_ids.add(edge.uuid)
                if target_node.uuid not in selected_node_ids:
                    selected_node_ids.add(target_node.uuid)
                    frontier.append((target_node.uuid, depth + 1))
                if len(selected_node_ids) >= limit:
                    break

        filtered_edges = [
            edge
            for edge in edges
            if edge.uuid in selected_edge_ids
            and edge.source_node_uuid in selected_node_ids
            and edge.target_node_uuid in selected_node_ids
        ]

        filtered_nodes = [
            GraphNodeView(
                uuid=node.uuid,
                kind=node.labels[0] if node.labels else "Entity",
                label=node.name,
                attributes=node.attributes or {},
            )
            for node_uuid, node in node_map.items()
            if node_uuid in selected_node_ids
        ]
        filtered_nodes.sort(key=lambda item: (item.kind, item.label, item.uuid))

        graph_edges = [
            GraphEdgeView(
                uuid=edge.uuid,
                source=edge.source_node_uuid,
                target=edge.target_node_uuid,
                relation=edge.name,
                fact=edge.fact,
                episodes=edge.episodes,
                valid_at=edge.valid_at,
            )
            for edge in filtered_edges
        ]
        graph_edges.sort(key=lambda item: (item.relation, item.source, item.target, item.uuid))

        focus_node_ids = [node_uuid for node_uuid in [workflow_uuid, run_uuid, alert_uuid, incident_uuid] if node_uuid]
        focus_node_ids = [node_uuid for node_uuid in focus_node_ids if node_uuid in selected_node_ids]

        return WorkflowGraphView(
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            run_id=run_id,
            nodes=filtered_nodes,
            edges=graph_edges,
            focus_node_ids=focus_node_ids,
        )

    async def _upsert_dataset(self, tenant_id: str, dataset: WorkflowDataset) -> EntityNode:
        version = dataset.version or "unknown"
        display_name = f"{dataset.name}:{version}"
        return await self._upsert_entity(
            tenant_id=tenant_id,
            kind="Dataset",
            key=display_name,
            display_name=display_name,
            attributes={
                "dataset_name": dataset.name,
                "dataset_version": dataset.version,
                "dataset_schema_hash": dataset.schema_hash,
                "row_count": dataset.row_count,
            },
        )

    async def _upsert_entity(
        self,
        tenant_id: str,
        kind: str,
        key: str,
        display_name: str,
        attributes: dict[str, object],
    ) -> EntityNode:
        node = EntityNode(
            uuid=stable_uuid(tenant_id, kind, key),
            name=display_name,
            group_id=tenant_id,
            labels=[kind],
            created_at=datetime.now(UTC),
            summary="",
            attributes=attributes,
        )
        await node.generate_name_embedding(self.graphiti.embedder)
        await node.save(self.graphiti.driver)
        return node

    async def _upsert_fact(
        self,
        tenant_id: str,
        source: EntityNode,
        target: EntityNode,
        relation: str,
        fact: str,
        reference_time: datetime,
        episode_uuid: str,
        edge_key: str,
    ) -> str:
        edge = EntityEdge(
            uuid=stable_uuid(tenant_id, relation, edge_key),
            source_node_uuid=source.uuid,
            target_node_uuid=target.uuid,
            group_id=tenant_id,
            created_at=datetime.now(UTC),
            name=relation,
            fact=fact,
            episodes=[episode_uuid],
            valid_at=reference_time,
            invalid_at=None,
            attributes={},
        )
        await edge.generate_embedding(self.graphiti.embedder)

        if self.graphiti.driver.provider == GraphProvider.KUZU:
            await self.graphiti.driver.execute_query(
                KUZU_ENTITY_EDGE_SAVE,
                source_uuid=edge.source_node_uuid,
                target_uuid=edge.target_node_uuid,
                uuid=edge.uuid,
                group_id=edge.group_id,
                created_at=edge.created_at,
                name=edge.name,
                fact=edge.fact,
                fact_embedding=edge.fact_embedding,
                episodes=edge.episodes,
                expired_at=edge.expired_at,
                valid_at=edge.valid_at,
                invalid_at=edge.invalid_at,
                attributes=json.dumps(edge.attributes),
            )
        else:
            await edge.save(self.graphiti.driver)

        return edge.uuid

    async def _link_episode_to_entity(
        self,
        tenant_id: str,
        episode_uuid: str,
        entity_uuid: str,
        created_at: datetime,
    ) -> None:
        edge = EpisodicEdge(
            uuid=stable_uuid(tenant_id, "mentions", episode_uuid, entity_uuid),
            group_id=tenant_id,
            source_node_uuid=episode_uuid,
            target_node_uuid=entity_uuid,
            created_at=created_at,
        )
        await edge.save(self.graphiti.driver)

    @staticmethod
    def _include_graph_neighbor(
        source_uuid: str,
        edge: EntityEdge,
        node: EntityNode,
        workflow_uuid: str,
        run_uuid: str | None,
        run_id: str | None,
    ) -> bool:
        kind = node.labels[0] if node.labels else "Entity"
        if source_uuid == workflow_uuid:
            if kind in {"Run", "DriftAlert", "GuardrailIncident"}:
                return (node.attributes or {}).get("run_id") == run_id
            return True

        if run_uuid and source_uuid == run_uuid:
            return True

        if kind in {"Run", "DriftAlert", "GuardrailIncident"} and run_id is not None:
            return (node.attributes or {}).get("run_id") == run_id

        return True
