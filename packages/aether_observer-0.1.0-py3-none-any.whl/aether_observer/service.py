from __future__ import annotations

import asyncio
import json
import re
from datetime import UTC, datetime, timedelta
from typing import Any, Mapping

from pydantic import BaseModel

from graphiti_core.driver.driver import GraphProvider
from graphiti_core.edges import EntityEdge
from graphiti_core.nodes import EpisodeType
from graphiti_core.prompts.models import Message

from aether_observer.adapters import default_adapters
from aether_observer.adapters.base import BaseWorkflowAdapter
from aether_observer.config import Settings, get_settings
from aether_observer.drift.engine import DriftEngine
from aether_observer.drift.features import build_features, dominant_sequence, dominant_values, safe_mean
from aether_observer.guardrails import GuardrailEngine
from aether_observer.graph_store import GraphitiWorkflowStore
from aether_observer.models import (
    DriftAssessment,
    DynamicGuardrailPolicy,
    ExperimentSummary,
    GraphDriftPolicy,
    GraphExplanation,
    GuardrailCheckResult,
    GuardrailCheckStatus,
    GuardrailEvaluation,
    GuardrailExplanation,
    GuardrailMode,
    GuardrailVerdict,
    GuardrailViolation,
    ObservationResult,
    RunStatus,
    Severity,
    StoredDriftAlert,
    StoredGuardrailIncident,
    WorkflowGraphView,
    WorkflowRun,
)
from aether_observer.runtime import RuntimeBundle, build_runtime


class AdvisoryResponse(BaseModel):
    summary: str


class MitigationAdvisor:
    def __init__(self, runtime: RuntimeBundle, enabled: bool = True):
        self.runtime = runtime
        self.enabled = enabled

    async def summarize(
        self,
        run: WorkflowRun,
        assessment: DriftAssessment,
        graph_context: list[str],
    ) -> str | None:
        if not assessment.signals:
            return None

        if not self.enabled:
            return self._fallback_summary(assessment)

        messages = [
            Message(
                role="system",
                content=(
                    "You are an enterprise observability agent. Summarize the drift findings and "
                    "prioritized mitigation in less than 120 words."
                ),
            ),
            Message(
                role="user",
                content=json.dumps(
                    {
                        "workflow_id": run.workflow_id,
                        "run_id": run.run_id,
                        "signals": [signal.model_dump(mode="json") for signal in assessment.signals],
                        "graph_context": graph_context,
                    },
                    default=str,
                ),
            ),
        ]

        try:
            response = await self.runtime.llm_client.generate_response(
                messages=messages,
                response_model=AdvisoryResponse,
                prompt_name="drift_mitigation_summary",
            )
            summary = response.get("summary")
            if isinstance(summary, str) and summary.strip():
                return summary.strip()
        except Exception:
            return self._fallback_summary(assessment)

        return self._fallback_summary(assessment)

    def _fallback_summary(self, assessment: DriftAssessment) -> str:
        top_signals = assessment.signals[:3]
        signal_names = ", ".join(signal.title for signal in top_signals)
        actions: list[str] = []
        for signal in top_signals:
            actions.extend(signal.recommended_actions[:1])
        action_text = " ".join(actions[:2])
        return f"Detected {signal_names}. Prioritize: {action_text}".strip()


class ObservabilityService:
    def __init__(
        self,
        settings: Settings,
        runtime: RuntimeBundle,
        drift_engine: DriftEngine | None = None,
        guardrail_engine: GuardrailEngine | None = None,
        adapters: dict[str, BaseWorkflowAdapter] | None = None,
    ):
        self.settings = settings
        self.runtime = runtime
        self.drift_engine = drift_engine or DriftEngine()
        self.guardrail_engine = guardrail_engine or GuardrailEngine()
        self.adapters = adapters or default_adapters()
        self.advisor = MitigationAdvisor(runtime, enabled=settings.enable_llm_mitigation)
        self.store = GraphitiWorkflowStore(runtime.graphiti)

    @classmethod
    async def create(cls, settings: Settings | None = None) -> "ObservabilityService":
        active_settings = settings or get_settings()
        runtime = await build_runtime(active_settings)
        return cls(settings=active_settings, runtime=runtime)

    async def close(self) -> None:
        await self.runtime.close()

    def register_adapter(self, adapter: BaseWorkflowAdapter) -> None:
        self.adapters[adapter.name] = adapter

    def _history_cutoff(self, reference_time: datetime) -> datetime | None:
        if self.settings.history_window_days <= 0:
            return None
        return reference_time - timedelta(days=self.settings.history_window_days)

    def _coerce_datetime(self, value: Any) -> datetime | None:
        if isinstance(value, datetime):
            return value if value.tzinfo is not None else value.replace(tzinfo=UTC)
        if value in (None, ""):
            return None
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)
        except ValueError:
            return None

    def _document_timestamp(self, document: Mapping[str, Any]) -> datetime | None:
        observed_at = self._coerce_datetime(document.get("observed_at"))
        if observed_at is not None:
            return observed_at

        run_payload = document.get("run")
        if isinstance(run_payload, Mapping):
            for field in ("started_at", "finished_at"):
                timestamp = self._coerce_datetime(run_payload.get(field))
                if timestamp is not None:
                    return timestamp

        evaluation = document.get("evaluation")
        if isinstance(evaluation, Mapping):
            for field in ("observed_at",):
                timestamp = self._coerce_datetime(evaluation.get(field))
                if timestamp is not None:
                    return timestamp

        return None

    def _is_within_history_window(self, timestamp: datetime | None, reference_time: datetime) -> bool:
        if timestamp is None:
            return True
        cutoff = self._history_cutoff(reference_time)
        if cutoff is None:
            return True
        return timestamp >= cutoff

    def _guardrail_warmup_remaining(self, baseline_run_count: int) -> int:
        return max(self.settings.guardrail_warmup_runs - baseline_run_count, 0)

    async def _retrieve_json_documents(
        self,
        tenant_id: str,
        reference_time: datetime,
        *,
        last_n: int,
    ) -> list[dict[str, Any]]:
        episodes = await self.runtime.graphiti.retrieve_episodes(
            reference_time=reference_time,
            last_n=last_n,
            group_ids=[tenant_id],
            source=EpisodeType.json,
        )
        documents: list[dict[str, Any]] = []
        for episode in episodes:
            if not episode.content:
                continue
            try:
                document = json.loads(episode.content)
            except json.JSONDecodeError:
                continue
            if isinstance(document, dict):
                documents.append(document)
        return documents

    async def observe(
        self,
        payload: Mapping[str, Any] | WorkflowRun,
        adapter: str = "generic",
        dry_run: bool = False,
    ) -> ObservationResult:
        run = self._normalize_run(payload, adapter)
        policy = await self._resolve_guardrail_policy(payload, run)
        graph_drift_policy = self._resolve_graph_drift_policy(payload, run)
        history = await self._load_workflow_history(run.tenant_id, run.workflow_id, run.started_at)
        history_features = [build_features(item) for item in history]
        current_features = build_features(run)

        stored_run_episode_uuid = None
        stored_drift_episode_uuid = None
        stored_guardrail_episode_uuid = None

        if len(history) < self.settings.min_history:
            assessment = DriftAssessment(
                baseline_run_count=len(history),
                risk_score=0.0,
                severity=Severity.info,
                signals=[],
            )
        else:
            current_graph = self.store.project_run_graph(run)
            history_graphs = await self._load_history_graphs(
                tenant_id=run.tenant_id,
                workflow_id=run.workflow_id,
                history=history,
            )
            assessment = self.drift_engine.evaluate(
                run,
                history,
                current_graph=current_graph,
                history_graphs=history_graphs,
            )

        guardrail_result = None
        warmup_remaining = self._guardrail_warmup_remaining(len(history))
        if warmup_remaining:
            run.metadata["guardrail_baselining"] = True
            run.metadata["guardrail_warmup_remaining"] = warmup_remaining
        else:
            guardrail_result = self.guardrail_engine.evaluate(
                run=run,
                current=current_features,
                history=history_features,
                policy=policy,
            )
            guardrail_result = await self.guardrail_engine.evaluate_runtime_checks(
                run=run,
                policy=policy,
                llm_client=self.runtime.llm_client,
                evaluation=guardrail_result,
            )
        if not warmup_remaining:
            guardrail_result = self._apply_graph_drift_policy(
                run=run,
                assessment=assessment,
                evaluation=guardrail_result,
                policy=graph_drift_policy,
            )
        if guardrail_result is not None and guardrail_result.stopped_run:
            run.status = RunStatus.failed
            run.metadata["guardrail_stopped"] = True
            run.metadata["guardrail_stop_reason"] = guardrail_result.stop_reason
            run.metadata["graph_drift_stopped"] = any(
                violation.kind == "graph_native_drift_guardrail"
                for violation in guardrail_result.violations
            )

        guardrail_explanations = await self._build_guardrail_explanations(
            run=run,
            evaluation=guardrail_result,
            current=current_features,
            history=history_features,
            policy=policy,
        )
        if guardrail_result is not None:
            guardrail_result.graph_explanations = guardrail_explanations

        if not dry_run:
            stored_run_episode_uuid = await self._store_run(run)

        graph_explanations = await self._build_graph_explanations(
            run=run,
            assessment=assessment,
            current=current_features,
            history=history_features,
        )
        graph_context = await self._fetch_graph_context(
            run,
            assessment,
            graph_explanations,
            guardrail_explanations,
        )
        recommendation_summary = await self.advisor.summarize(run, assessment, graph_context)

        if not dry_run and assessment.signals:
            stored_drift_episode_uuid = await self._store_assessment(
                run=run,
                assessment=assessment,
                graph_context=graph_context,
                graph_explanations=graph_explanations,
                recommendation_summary=recommendation_summary,
            )
        if not dry_run and guardrail_result is not None and guardrail_result.violations:
            stored_guardrail_episode_uuid = await self.store.store_guardrail_incident(
                run=run,
                evaluation=guardrail_result,
            )

        return ObservationResult(
            run=run,
            baseline_run_count=assessment.baseline_run_count,
            risk_score=assessment.risk_score,
            severity=assessment.severity,
            signals=assessment.signals,
            guardrail_result=guardrail_result,
            stored_run_episode_uuid=stored_run_episode_uuid,
            stored_drift_episode_uuid=stored_drift_episode_uuid,
            stored_guardrail_episode_uuid=stored_guardrail_episode_uuid,
            graph_context=graph_context,
            graph_explanations=graph_explanations,
            recommendation_summary=recommendation_summary,
        )

    async def evaluate_guardrails(
        self,
        payload: Mapping[str, Any] | WorkflowRun,
        adapter: str = "generic",
        persist_incident: bool = True,
    ) -> tuple[WorkflowRun, GuardrailEvaluation | None]:
        run = self._normalize_run(payload, adapter)
        policy = await self._resolve_guardrail_policy(payload, run)
        history = await self._load_workflow_history(run.tenant_id, run.workflow_id, run.started_at)
        history_features = [build_features(item) for item in history]
        current_features = build_features(run)

        warmup_remaining = self._guardrail_warmup_remaining(len(history))
        if warmup_remaining:
            run.metadata["guardrail_baselining"] = True
            run.metadata["guardrail_warmup_remaining"] = warmup_remaining
            evaluation = None
        else:
            evaluation = self.guardrail_engine.evaluate(
                run=run,
                current=current_features,
                history=history_features,
                policy=policy,
            )
            evaluation = await self.guardrail_engine.evaluate_runtime_checks(
                run=run,
                policy=policy,
                llm_client=self.runtime.llm_client,
                evaluation=evaluation,
            )
        explanations = await self._build_guardrail_explanations(
            run=run,
            evaluation=evaluation,
            current=current_features,
            history=history_features,
            policy=policy,
        )
        if evaluation is not None:
            evaluation.graph_explanations = explanations
            if evaluation.stopped_run:
                run.status = RunStatus.failed
                run.metadata["guardrail_stopped"] = True
                run.metadata["guardrail_stop_reason"] = evaluation.stop_reason
            if persist_incident and evaluation.violations:
                await self.store.store_guardrail_incident(run=run, evaluation=evaluation)
        return run, evaluation

    def register_guardrail_function(self, name: str, fn) -> None:
        self.guardrail_engine.register_function_guardrail(name, fn)


    async def upsert_guardrail_policy(
        self,
        policy: DynamicGuardrailPolicy | Mapping[str, Any],
    ) -> tuple[DynamicGuardrailPolicy, str]:
        normalized = (
            policy if isinstance(policy, DynamicGuardrailPolicy) else DynamicGuardrailPolicy.model_validate(policy)
        )
        episode_uuid = await self.store.store_guardrail_policy(normalized)
        return normalized, episode_uuid

    async def get_guardrail_policy(
        self,
        tenant_id: str,
        workflow_id: str,
    ) -> DynamicGuardrailPolicy | None:
        documents = await self._retrieve_json_documents(
            tenant_id=tenant_id,
            reference_time=datetime.now(UTC),
            last_n=max(self.settings.history_window, 20) * 4,
        )
        for document in documents:
            if document.get("record_type") != "guardrail_policy":
                continue
            if document.get("workflow_id") != workflow_id:
                continue
            policy_payload = document.get("policy")
            if policy_payload is None:
                continue
            return DynamicGuardrailPolicy.model_validate(policy_payload)
        return None

    async def workflow_guardrail_incidents(
        self,
        tenant_id: str,
        workflow_id: str,
        limit: int | None = None,
    ) -> list[StoredGuardrailIncident]:
        reference_time = datetime.now(UTC)
        documents = await self._retrieve_json_documents(
            tenant_id=tenant_id,
            reference_time=reference_time,
            last_n=(limit or self.settings.history_window) * 6,
        )
        incidents: list[StoredGuardrailIncident] = []
        for document in documents:
            if document.get("record_type") != "guardrail_incident":
                continue
            if document.get("workflow_id") != workflow_id:
                continue
            observed_at = self._document_timestamp(document)
            if not self._is_within_history_window(observed_at, reference_time):
                continue
            evaluation = document.get("evaluation") or {}
            incidents.append(
                StoredGuardrailIncident(
                    tenant_id=document.get("tenant_id", tenant_id),
                    workflow_id=document.get("workflow_id", workflow_id),
                    run_id=document.get("run_id", ""),
                    observed_at=observed_at or reference_time,
                    policy_id=evaluation.get("policy_id", ""),
                    mode=evaluation.get("mode", "observe"),
                    verdict=evaluation.get("verdict", "pass"),
                    checks=evaluation.get("checks", []),
                    violations=evaluation.get("violations", []),
                    graph_explanations=evaluation.get("graph_explanations", []),
                    stopped_run=evaluation.get("stopped_run", False),
                    stop_reason=evaluation.get("stop_reason"),
                )
            )
        return incidents[: limit or self.settings.history_window]

    async def workflow_history(
        self,
        tenant_id: str,
        workflow_id: str,
        limit: int | None = None,
    ) -> list[WorkflowRun]:
        when = datetime.now(UTC)
        runs = await self._load_workflow_history(
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            reference_time=when,
            limit=limit,
        )
        return runs

    async def tenant_experiments(
        self,
        tenant_id: str,
        limit: int | None = None,
    ) -> list[ExperimentSummary]:
        reference_time = datetime.now(UTC)
        documents = await self._retrieve_json_documents(
            tenant_id=tenant_id,
            reference_time=reference_time,
            last_n=max((limit or self.settings.history_window) * 20, 120),
        )

        summaries: dict[str, ExperimentSummary] = {}
        latest_alert_timestamps: dict[str, datetime] = {}
        latest_guardrail_timestamps: dict[str, datetime] = {}

        for document in documents:
            workflow_id = document.get("workflow_id")
            if not workflow_id:
                continue

            timestamp = self._document_timestamp(document)
            if not self._is_within_history_window(timestamp, reference_time):
                continue

            summary = summaries.setdefault(
                workflow_id,
                ExperimentSummary(
                    tenant_id=tenant_id,
                    workflow_id=workflow_id,
                ),
            )

            record_type = document.get("record_type")
            if record_type == "workflow_run":
                run_payload = document.get("run")
                if run_payload is None:
                    continue
                run = WorkflowRun.model_validate(run_payload)
                summary.run_count += 1
                if summary.latest_observed_at is None or run.started_at >= summary.latest_observed_at:
                    summary.latest_run_id = run.run_id
                    summary.latest_agent_name = run.agent_name
                    summary.latest_observed_at = run.started_at
                    summary.latest_status = run.status
            elif record_type == "drift_alert":
                summary.drift_alert_count += 1
                if timestamp is not None and timestamp >= latest_alert_timestamps.get(workflow_id, datetime.min.replace(tzinfo=UTC)):
                    assessment = document.get("assessment") or {}
                    summary.latest_risk_score = float(assessment.get("risk_score", 0.0))
                    severity = assessment.get("severity", Severity.info)
                    summary.latest_severity = severity if isinstance(severity, Severity) else Severity(severity)
                    latest_alert_timestamps[workflow_id] = timestamp
            elif record_type == "guardrail_incident":
                summary.guardrail_incident_count += 1
                evaluation = document.get("evaluation") or {}
                if evaluation.get("stopped_run"):
                    summary.blocked_run_count += 1
                if timestamp is not None and timestamp >= latest_guardrail_timestamps.get(workflow_id, datetime.min.replace(tzinfo=UTC)):
                    verdict = evaluation.get("verdict", GuardrailVerdict.pass_)
                    summary.latest_guardrail_verdict = (
                        verdict if isinstance(verdict, GuardrailVerdict) else GuardrailVerdict(verdict)
                    )
                    latest_guardrail_timestamps[workflow_id] = timestamp

        ordered = sorted(
            summaries.values(),
            key=lambda item: item.latest_observed_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return ordered[: limit or self.settings.history_window]

    async def workflow_alerts(
        self,
        tenant_id: str,
        workflow_id: str,
        limit: int | None = None,
    ) -> list[StoredDriftAlert]:
        when = datetime.now(UTC)
        documents = await self._retrieve_json_documents(
            tenant_id=tenant_id,
            reference_time=when,
            last_n=(limit or self.settings.history_window) * 6,
        )
        alerts: list[StoredDriftAlert] = []
        for document in documents:
            if document.get("record_type") != "drift_alert":
                continue
            if document.get("workflow_id") != workflow_id:
                continue
            observed_at = self._document_timestamp(document)
            if not self._is_within_history_window(observed_at, when):
                continue

            assessment = document.get("assessment") or {}
            alerts.append(
                StoredDriftAlert(
                    tenant_id=document.get("tenant_id", tenant_id),
                    workflow_id=document.get("workflow_id", workflow_id),
                    run_id=document.get("run_id", ""),
                    observed_at=observed_at or when,
                    risk_score=float(assessment.get("risk_score", 0)),
                    severity=assessment.get("severity", Severity.info),
                    signals=assessment.get("signals", []),
                    graph_context=document.get("graph_context", []),
                    graph_explanations=document.get("graph_explanations", []),
                    recommendation_summary=document.get("recommendation_summary"),
                )
            )

        return alerts[: limit or self.settings.history_window]

    async def workflow_graph(
        self,
        tenant_id: str,
        workflow_id: str,
        run_id: str | None = None,
        limit: int = 300,
    ) -> WorkflowGraphView:
        return await self.store.workflow_graph(
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            run_id=run_id,
            limit=limit,
        )

    async def _load_history_graphs(
        self,
        tenant_id: str,
        workflow_id: str,
        history: list[WorkflowRun],
    ) -> list[WorkflowGraphView]:
        if not history:
            return []

        queried = await asyncio.gather(
            *[
                self.store.workflow_graph(
                    tenant_id=tenant_id,
                    workflow_id=workflow_id,
                    run_id=item.run_id,
                )
                for item in history
            ]
        )

        graphs: list[WorkflowGraphView] = []
        for item, graph in zip(history, queried, strict=False):
            if graph.nodes and graph.edges:
                graphs.append(graph)
                continue
            graphs.append(self.store.project_run_graph(item))
        return graphs

    async def search_facts(self, tenant_id: str, query: str, limit: int = 10) -> list[str]:
        edges = await self._search_edges(tenant_id=tenant_id, query=query, limit=limit)
        facts: list[str] = []
        for edge in edges:
            validity = edge.invalid_at.isoformat() if edge.invalid_at else "present"
            rendered = f"{edge.fact} [valid_at={edge.valid_at}, invalid_at={validity}]"
            if rendered not in facts:
                facts.append(rendered)
        return facts

    def _normalize_run(
        self,
        payload: Mapping[str, Any] | WorkflowRun,
        adapter: str,
    ) -> WorkflowRun:
        if adapter not in self.adapters:
            raise ValueError(f"Unknown adapter: {adapter}")
        return self.adapters[adapter].normalize(payload)

    async def _resolve_guardrail_policy(
        self,
        payload: Mapping[str, Any] | WorkflowRun,
        run: WorkflowRun,
    ) -> DynamicGuardrailPolicy | None:
        if isinstance(payload, Mapping):
            inline = payload.get("guardrail_policy")
            if inline is not None:
                if isinstance(inline, DynamicGuardrailPolicy):
                    return inline
                policy_payload = dict(inline)
                policy_payload.setdefault("tenant_id", run.tenant_id)
                policy_payload.setdefault("workflow_id", run.workflow_id)
                return DynamicGuardrailPolicy.model_validate(policy_payload)
        inline_from_run = run.metadata.get("guardrail_policy")
        if inline_from_run is not None:
            if isinstance(inline_from_run, DynamicGuardrailPolicy):
                return inline_from_run
            policy_payload = dict(inline_from_run)
            policy_payload.setdefault("tenant_id", run.tenant_id)
            policy_payload.setdefault("workflow_id", run.workflow_id)
            return DynamicGuardrailPolicy.model_validate(policy_payload)
        return await self.get_guardrail_policy(run.tenant_id, run.workflow_id)

    def _resolve_graph_drift_policy(
        self,
        payload: Mapping[str, Any] | WorkflowRun,
        run: WorkflowRun,
    ) -> GraphDriftPolicy | None:
        if isinstance(payload, Mapping):
            inline = payload.get("graph_drift_policy")
            if inline is not None:
                if isinstance(inline, GraphDriftPolicy):
                    return inline
                return GraphDriftPolicy.model_validate(inline)

        inline_from_run = run.metadata.get("graph_drift_policy")
        if inline_from_run is None:
            return None
        if isinstance(inline_from_run, GraphDriftPolicy):
            return inline_from_run
        return GraphDriftPolicy.model_validate(inline_from_run)

    def _apply_graph_drift_policy(
        self,
        run: WorkflowRun,
        assessment: DriftAssessment,
        evaluation: GuardrailEvaluation | None,
        policy: GraphDriftPolicy | None,
    ) -> GuardrailEvaluation | None:
        if policy is None or not policy.enabled:
            return evaluation

        if assessment.baseline_run_count < policy.warmup_runs:
            run.metadata["graph_drift_baselining"] = True
            run.metadata["graph_drift_warmup_remaining"] = policy.warmup_runs - assessment.baseline_run_count
            return evaluation

        graph_signals = [
            signal
            for signal in assessment.signals
            if signal.kind in policy.signal_kinds and signal.score >= policy.min_score
        ]
        if not graph_signals:
            return evaluation

        result = evaluation or GuardrailEvaluation(
            policy_id=policy.policy_id or f"graph-drift:{run.workflow_id}",
            mode=GuardrailMode.block if policy.stop_on_drift else GuardrailMode.warn,
            verdict=GuardrailVerdict.pass_,
        )
        result.policy_id = result.policy_id or policy.policy_id or f"graph-drift:{run.workflow_id}"
        result.mode = GuardrailMode.block if policy.stop_on_drift else GuardrailMode.warn

        top_signal = max(graph_signals, key=lambda item: item.score)
        summary = (
            f"Graph-native drift activated after warmup ({policy.warmup_runs} baseline runs). "
            f"Triggered by {', '.join(signal.kind for signal in graph_signals[:3])}."
        )
        stop_workflow = policy.stop_on_drift

        result.checks.append(
            GuardrailCheckResult(
                guardrail_id=policy.policy_id or "graph-native-drift",
                kind="graph_native_drift_guardrail",
                status=GuardrailCheckStatus.fail,
                title="Graph-native drift guardrail failed",
                summary=summary,
                stop_workflow=stop_workflow,
                evidence={
                    "warmup_runs": policy.warmup_runs,
                    "baseline_run_count": assessment.baseline_run_count,
                    "triggered_signals": [signal.model_dump(mode="json") for signal in graph_signals],
                },
                recommended_actions=[
                    "Inspect the current workflow graph against the stable baseline before allowing this run path.",
                    "Increase the warmup window only if the workflow is still intentionally re-baselining.",
                ],
            )
        )
        result.violations.append(
            GuardrailViolation(
                policy_id=result.policy_id or "graph-native-drift",
                kind="graph_native_drift_guardrail",
                severity=top_signal.severity,
                mode=result.mode,
                title="Graph-native drift guardrail failed",
                summary=summary,
                score=top_signal.score,
                evidence={
                    "warmup_runs": policy.warmup_runs,
                    "baseline_run_count": assessment.baseline_run_count,
                    "triggered_signal_kinds": [signal.kind for signal in graph_signals],
                    "top_signal": top_signal.model_dump(mode="json"),
                },
                recommended_actions=[
                    "Review graph topology and motif changes before allowing this run in production.",
                    "Pin or waive the changed route explicitly if it is intentional.",
                ],
            )
        )

        if stop_workflow:
            result.verdict = GuardrailVerdict.block
            result.stopped_run = True
            result.stop_reason = (
                f"Graph-native drift detected after {policy.warmup_runs} baseline runs."
            )
        elif result.verdict == GuardrailVerdict.pass_:
            result.verdict = GuardrailVerdict.warn

        run.metadata["graph_drift_policy_id"] = result.policy_id
        run.metadata["graph_drift_signal_kinds"] = [signal.kind for signal in graph_signals]
        return result

    async def _load_workflow_history(
        self,
        tenant_id: str,
        workflow_id: str,
        reference_time: datetime,
        limit: int | None = None,
    ) -> list[WorkflowRun]:
        documents = await self._retrieve_json_documents(
            tenant_id=tenant_id,
            reference_time=reference_time,
            last_n=(limit or self.settings.history_window) * 6,
        )
        runs: list[WorkflowRun] = []
        for document in documents:
            if document.get("record_type") != "workflow_run":
                continue
            if document.get("workflow_id") != workflow_id:
                continue
            run_payload = document.get("run")
            if run_payload is None:
                continue
            run = WorkflowRun.model_validate(run_payload)
            if not self._is_within_history_window(run.started_at, reference_time):
                continue
            runs.append(run)
        return runs[: limit or self.settings.history_window]

    async def _store_run(self, run: WorkflowRun) -> str:
        return await self.store.store_run(run)

    async def _store_assessment(
        self,
        run: WorkflowRun,
        assessment: DriftAssessment,
        graph_context: list[str],
        graph_explanations: list[GraphExplanation],
        recommendation_summary: str | None,
    ) -> str:
        return await self.store.store_assessment(
            run=run,
            assessment=assessment,
            graph_context=graph_context,
            graph_explanations=graph_explanations,
            recommendation_summary=recommendation_summary,
        )

    async def _fetch_graph_context(
        self,
        run: WorkflowRun,
        assessment: DriftAssessment,
        graph_explanations: list[GraphExplanation],
        guardrail_explanations: list[GuardrailExplanation],
    ) -> list[str]:
        if not assessment.signals and not guardrail_explanations:
            return []

        query_parts = [run.workflow_id, run.agent_name]
        query_parts.extend(signal.kind for signal in assessment.signals[:2])
        query_parts.extend(explanation.violation_kind for explanation in guardrail_explanations[:2])
        query = " ".join(query_parts)

        edges = await self._search_edges(tenant_id=run.tenant_id, query=query, limit=5)

        facts: list[str] = []
        for explanation in graph_explanations:
            for fact in explanation.graph_facts[:2]:
                if fact not in facts:
                    facts.append(fact)
        for explanation in guardrail_explanations:
            for fact in explanation.graph_facts[:2]:
                if fact not in facts:
                    facts.append(fact)
        for edge in edges:
            fact = edge.fact
            if fact not in facts:
                facts.append(fact)
        return facts[:8]

    async def _build_graph_explanations(
        self,
        run: WorkflowRun,
        assessment: DriftAssessment,
        current,
        history,
    ) -> list[GraphExplanation]:
        if not assessment.signals or not history:
            return []

        explanations: list[GraphExplanation] = []
        for signal in assessment.signals:
            current_state = self._current_state_for_signal(signal.kind, current, signal.evidence)
            baseline_state = self._baseline_state_for_signal(signal.kind, history, signal.evidence)
            query = " ".join(
                [run.workflow_id, run.run_id, signal.kind, *current_state[:2], *baseline_state[:2]]
            )
            edges = await self._search_edges(tenant_id=run.tenant_id, query=query, limit=6)
            graph_facts: list[str] = []
            for edge in edges:
                if edge.fact not in graph_facts:
                    graph_facts.append(edge.fact)
            explanations.append(
                GraphExplanation(
                    signal_kind=signal.kind,
                    title=signal.title,
                    summary=signal.summary,
                    current_state=current_state,
                    baseline_state=baseline_state,
                    graph_facts=graph_facts,
                )
            )
        return explanations

    @staticmethod
    def _display_sequence(label: str, values: list[str]) -> str:
        if not values:
            return f"{label}: none"
        return f"{label}: {' -> '.join(values)}"

    @staticmethod
    def _display_set(label: str, values: list[str]) -> str:
        if not values:
            return f"{label}: none"
        return f"{label}: {', '.join(values)}"

    def _current_state_for_signal(self, signal_kind: str, current, evidence: dict[str, Any]) -> list[str]:
        if signal_kind == "tool_sequence_drift":
            return [
                self._display_sequence("tool_sequence", current.tool_sequence),
                self._display_set("tool_set", sorted(current.tool_set)),
            ]
        if signal_kind == "decision_outcome_drift":
            return [
                self._display_sequence("decision_sequence", current.decision_sequence),
                self._display_set("decision_set", sorted(current.decision_set)),
            ]
        if signal_kind == "action_route_drift":
            return [
                self._display_sequence("action_sequence", current.action_sequence),
                self._display_set("action_set", sorted(current.action_set)),
            ]
        if signal_kind == "function_call_drift":
            return [
                self._display_sequence("function_calls", current.function_call_sequence),
                self._display_set("function_call_set", sorted(current.function_call_set)),
            ]
        if signal_kind == "function_arguments_drift":
            return [
                self._display_set(
                    "function_argument_shapes",
                    sorted(current.function_argument_signatures),
                )
            ]
        if signal_kind == "prompt_drift":
            return [self._display_set("prompt_signatures", sorted(current.prompt_signatures))]
        if signal_kind == "model_drift":
            return [self._display_set("models", sorted(current.model_set))]
        if signal_kind == "input_schema_drift":
            return [self._display_set("input_keys", sorted(current.input_schema))]
        if signal_kind == "output_schema_drift":
            return [self._display_set("output_keys", sorted(current.output_schema))]
        if signal_kind == "dataset_version_drift":
            return [self._display_set("datasets", sorted(current.dataset_signatures))]
        if signal_kind == "payload_volume_drift":
            return [
                f"input_size_bytes: {current.input_size}",
                f"output_size_bytes: {current.output_size}",
            ]
        if signal_kind == "step_count_regression":
            return [
                f"step_count: {current.step_count}",
                f"llm_steps: {current.llm_step_count}, tool_steps: {current.tool_step_count}",
            ]
        if signal_kind == "latency_regression":
            return [f"latency_ms: {current.latency_ms}"]
        if signal_kind == "graph_topology_drift":
            return [
                self._display_set("graph_edge_types", sorted(evidence.get("current_edge_types", []))[:6]),
                self._display_set("graph_paths", sorted(evidence.get("current_path_signatures", []))[:6]),
            ]
        if signal_kind == "graph_motif_drift":
            return [
                self._display_set("graph_step_motifs", sorted(evidence.get("current_step_motifs", []))[:6])
            ]
        if signal_kind == "missing_expected_relation":
            return [
                self._display_set("graph_paths", sorted(evidence.get("current_path_signatures", []))[:6]),
                self._display_set(
                    "missing_graph_paths",
                    sorted(evidence.get("missing_path_signatures", []))[:6],
                ),
            ]
        if signal_kind == "new_relation_drift":
            return [
                self._display_set("graph_paths", sorted(evidence.get("current_path_signatures", []))[:6]),
                self._display_set("new_graph_paths", sorted(evidence.get("new_path_signatures", []))[:6]),
            ]
        if signal_kind == "graph_volume_drift":
            return [
                f"graph_node_count: {evidence.get('node_count')}",
                f"graph_edge_count: {evidence.get('edge_count')}",
            ]
        return []

    def _baseline_state_for_signal(self, signal_kind: str, history, evidence: dict[str, Any]) -> list[str]:
        if signal_kind == "tool_sequence_drift":
            return [
                self._display_sequence(
                    "baseline_tool_sequence",
                    dominant_sequence([item.tool_sequence for item in history]),
                ),
                self._display_set(
                    "baseline_tool_set",
                    dominant_values([item.tool_set for item in history]),
                ),
            ]
        if signal_kind == "decision_outcome_drift":
            return [
                self._display_sequence(
                    "baseline_decision_sequence",
                    dominant_sequence([item.decision_sequence for item in history]),
                ),
                self._display_set(
                    "baseline_decision_set",
                    dominant_values([item.decision_set for item in history]),
                ),
            ]
        if signal_kind == "action_route_drift":
            return [
                self._display_sequence(
                    "baseline_action_sequence",
                    dominant_sequence([item.action_sequence for item in history]),
                ),
                self._display_set(
                    "baseline_action_set",
                    dominant_values([item.action_set for item in history]),
                ),
            ]
        if signal_kind == "function_call_drift":
            return [
                self._display_sequence(
                    "baseline_function_calls",
                    dominant_sequence([item.function_call_sequence for item in history]),
                ),
                self._display_set(
                    "baseline_function_call_set",
                    dominant_values([item.function_call_set for item in history]),
                ),
            ]
        if signal_kind == "function_arguments_drift":
            return [
                self._display_set(
                    "baseline_function_argument_shapes",
                    dominant_values([item.function_argument_signatures for item in history]),
                )
            ]
        if signal_kind == "prompt_drift":
            return [
                self._display_set(
                    "baseline_prompts",
                    dominant_values([item.prompt_signatures for item in history]),
                )
            ]
        if signal_kind == "model_drift":
            return [
                self._display_set(
                    "baseline_models",
                    dominant_values([item.model_set for item in history]),
                )
            ]
        if signal_kind == "input_schema_drift":
            return [
                self._display_set(
                    "baseline_input_keys",
                    dominant_values([item.input_schema for item in history]),
                )
            ]
        if signal_kind == "output_schema_drift":
            return [
                self._display_set(
                    "baseline_output_keys",
                    dominant_values([item.output_schema for item in history]),
                )
            ]
        if signal_kind == "dataset_version_drift":
            return [
                self._display_set(
                    "baseline_datasets",
                    dominant_values([item.dataset_signatures for item in history]),
                )
            ]
        if signal_kind == "payload_volume_drift":
            return [
                f"baseline_input_size_bytes: {round(safe_mean(item.input_size for item in history), 1)}",
                f"baseline_output_size_bytes: {round(safe_mean(item.output_size for item in history), 1)}",
            ]
        if signal_kind == "step_count_regression":
            return [
                f"baseline_mean_step_count: {round(safe_mean(item.step_count for item in history), 1)}",
                (
                    "baseline_mean_llm_steps: "
                    f"{round(safe_mean(item.llm_step_count for item in history), 1)}, "
                    f"baseline_mean_tool_steps: {round(safe_mean(item.tool_step_count for item in history), 1)}"
                ),
            ]
        if signal_kind == "latency_regression":
            return [f"baseline_mean_latency_ms: {round(safe_mean(item.latency_ms for item in history), 1)}"]
        if signal_kind == "graph_topology_drift":
            return [
                self._display_set("baseline_graph_edge_types", sorted(evidence.get("baseline_edge_types", []))[:6]),
                self._display_set(
                    "baseline_graph_paths",
                    sorted(evidence.get("baseline_path_signatures", []))[:6],
                ),
            ]
        if signal_kind == "graph_motif_drift":
            return [
                self._display_set(
                    "baseline_graph_step_motifs",
                    sorted(evidence.get("baseline_step_motifs", []))[:6],
                )
            ]
        if signal_kind == "missing_expected_relation":
            return [
                self._display_set(
                    "baseline_graph_paths",
                    sorted(evidence.get("baseline_path_signatures", []))[:6],
                )
            ]
        if signal_kind == "new_relation_drift":
            return [
                self._display_set(
                    "baseline_graph_paths",
                    sorted(evidence.get("baseline_path_signatures", []))[:6],
                )
            ]
        if signal_kind == "graph_volume_drift":
            return [
                f"baseline_mean_graph_node_count: {evidence.get('baseline_mean_node_count')}",
                f"baseline_mean_graph_edge_count: {evidence.get('baseline_mean_edge_count')}",
            ]
        return []

    async def _build_guardrail_explanations(
        self,
        run: WorkflowRun,
        evaluation: GuardrailEvaluation | None,
        current,
        history,
        policy: DynamicGuardrailPolicy | None,
    ) -> list[GuardrailExplanation]:
        if evaluation is None or not evaluation.violations:
            return []

        explanations: list[GuardrailExplanation] = []
        for violation in evaluation.violations:
            current_state = self._guardrail_current_state(violation.kind, violation.evidence, current)
            expected_state = self._guardrail_expected_state(violation.kind, violation.evidence, history, policy)
            query = " ".join(
                [run.workflow_id, run.run_id, violation.kind, *current_state[:2], *expected_state[:2]]
            )
            edges = await self._search_edges(tenant_id=run.tenant_id, query=query, limit=6)
            graph_facts: list[str] = []
            for edge in edges:
                if edge.fact not in graph_facts:
                    graph_facts.append(edge.fact)
            explanations.append(
                GuardrailExplanation(
                    policy_id=violation.policy_id,
                    violation_kind=violation.kind,
                    title=violation.title,
                    summary=violation.summary,
                    current_state=current_state,
                    expected_state=expected_state,
                    graph_facts=graph_facts,
                )
            )
        return explanations

    def _guardrail_current_state(self, kind: str, evidence: dict[str, Any], current) -> list[str]:
        if kind == "decision_guardrail_violation":
            return [self._display_set("current_decisions", sorted(current.decision_set))]
        if kind in {"action_guardrail_violation", "blocked_action", "approval_required_action"}:
            return [
                self._display_set("current_actions", sorted(current.action_set)),
                self._display_set(
                    "triggered_actions",
                    sorted(
                        {
                            value
                            for key, value in evidence.items()
                            if key in {"blocked_action", "approval_required_action"}
                        }
                    ),
                ),
            ]
        if kind in {"function_guardrail_violation", "blocked_function", "function_contract_violation"}:
            return [
                self._display_set("current_function_names", sorted({_split for _split in [
                    item.split("(", 1)[0] for item in current.function_call_set
                ]})),
                self._display_set(
                    "current_argument_keys",
                    sorted(evidence.get("argument_keys", [])),
                ),
            ]
        if kind == "model_guardrail_violation":
            return [self._display_set("current_models", sorted(current.model_set))]
        if kind == "prompt_guardrail_violation":
            return [self._display_set("current_prompts", sorted(current.prompt_signatures))]
        if kind == "tool_guardrail_violation":
            return [self._display_set("current_tools", sorted(current.tool_set))]
        if kind == "dataset_guardrail_violation":
            return [
                f"dataset: {evidence.get('dataset_name')}:{evidence.get('dataset_version')}"
            ]
        if kind == "step_budget_violation":
            return [f"step_count: {current.step_count}"]
        if kind == "latency_budget_violation":
            return [f"latency_ms: {current.latency_ms}"]
        if kind in {"runtime_function_guardrail_failure", "runtime_function_guardrail_error"}:
            return [
                f"guardrail_function: {evidence.get('function_name')}",
                self._display_set("current_actions", sorted(current.action_set)),
            ]
        if kind in {"natural_language_guardrail_failure", "natural_language_guardrail_error"}:
            return [
                f"instruction: {evidence.get('instruction')}",
                self._display_set("current_actions", sorted(current.action_set)),
            ]
        if kind == "graph_native_drift_guardrail":
            return [
                f"triggered_signals: {', '.join(evidence.get('triggered_signal_kinds', []))}",
                f"baseline_run_count: {evidence.get('baseline_run_count')}",
            ]
        return []

    def _guardrail_expected_state(
        self,
        kind: str,
        evidence: dict[str, Any],
        history,
        policy: DynamicGuardrailPolicy | None,
    ) -> list[str]:
        if kind == "decision_guardrail_violation":
            return [self._display_set("expected_decisions", evidence.get("expected_decisions", []))]
        if kind in {"action_guardrail_violation", "blocked_action", "approval_required_action"}:
            values = (
                evidence.get("expected_actions")
                or (policy.allowed_actions if policy else [])
                or (policy.require_approval_actions if policy else [])
                or (policy.blocked_actions if policy else [])
            )
            return [self._display_set("expected_actions", values)]
        if kind in {"function_guardrail_violation", "blocked_function"}:
            return [
                self._display_set(
                    "expected_functions",
                    evidence.get("expected_functions", policy.allowed_functions if policy else []),
                )
            ]
        if kind == "function_contract_violation":
            return [
                self._display_set(
                    "required_argument_keys",
                    evidence.get("missing_keys", []),
                ),
                self._display_set(
                    "approved_argument_keys",
                    policy.function_contracts.get(
                        evidence.get("function_name", ""),
                        None,
                    ).allowed_keys
                    if policy and policy.function_contracts.get(evidence.get("function_name", ""))
                    else [],
                ),
            ]
        if kind == "model_guardrail_violation":
            return [
                self._display_set(
                    "expected_models",
                    evidence.get("expected_models", policy.allowed_models if policy else []),
                )
            ]
        if kind == "prompt_guardrail_violation":
            return [
                self._display_set(
                    "expected_prompts",
                    evidence.get("expected_prompts", policy.allowed_prompts if policy else []),
                )
            ]
        if kind == "tool_guardrail_violation":
            return [
                self._display_set(
                    "expected_tools",
                    evidence.get("expected_tools", policy.allowed_tools if policy else []),
                )
            ]
        if kind == "dataset_guardrail_violation":
            return [self._display_set("expected_versions", evidence.get("expected_versions", []))]
        if kind == "step_budget_violation":
            return [f"max_step_count: {policy.max_step_count if policy else None}"]
        if kind == "latency_budget_violation":
            return [f"max_latency_ms: {policy.max_latency_ms if policy else None}"]
        if kind in {"runtime_function_guardrail_failure", "runtime_function_guardrail_error"}:
            return [
                "expected: registered executable guardrail should pass",
            ]
        if kind in {"natural_language_guardrail_failure", "natural_language_guardrail_error"}:
            return [
                "expected: natural-language guardrail instruction should pass",
            ]
        if kind == "graph_native_drift_guardrail":
            return [
                f"warmup_runs: {evidence.get('warmup_runs')}",
                "expected: no graph-native drift signals above threshold",
            ]
        return []

    async def _search_edges(self, tenant_id: str, query: str, limit: int) -> list[EntityEdge]:
        if self.runtime.graphiti.driver.provider == GraphProvider.KUZU:
            return await self._search_edges_kuzu_fallback(
                tenant_id=tenant_id,
                query=query,
                limit=limit,
            )

        try:
            return await self.runtime.graphiti.search(
                query=query,
                group_ids=[tenant_id],
                num_results=limit,
            )
        except Exception:
            return []

    async def _search_edges_kuzu_fallback(
        self,
        tenant_id: str,
        query: str,
        limit: int,
    ) -> list[EntityEdge]:
        try:
            edges = await EntityEdge.get_by_group_ids(
                self.runtime.graphiti.driver,
                group_ids=[tenant_id],
                limit=max(limit * 20, 50),
            )
        except Exception:
            return []

        query_tokens = self._tokenize(query)
        ranked = sorted(
            edges,
            key=lambda edge: self._edge_match_score(edge, query_tokens),
            reverse=True,
        )
        filtered = [edge for edge in ranked if self._edge_match_score(edge, query_tokens) > 0]
        return filtered[:limit]

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        return {token for token in re.findall(r"[a-zA-Z0-9_]+", text.lower()) if token}

    def _edge_match_score(self, edge: EntityEdge, query_tokens: set[str]) -> float:
        haystack = f"{edge.name} {edge.fact}".lower()
        edge_tokens = self._tokenize(haystack)
        if not query_tokens or not edge_tokens:
            return 0.0
        overlap = len(query_tokens & edge_tokens)
        return overlap / len(query_tokens)
