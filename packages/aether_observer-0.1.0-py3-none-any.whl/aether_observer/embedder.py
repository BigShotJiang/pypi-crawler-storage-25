from __future__ import annotations

import asyncio
from collections.abc import Iterable

import numpy as np

from graphiti_core.embedder.client import EmbedderClient


class SentenceTransformerEmbedder(EmbedderClient):
    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer

        self.model = SentenceTransformer(model_name)

    async def create(
        self, input_data: str | list[str] | Iterable[int] | Iterable[Iterable[int]]
    ) -> list[float]:
        if isinstance(input_data, str):
            text = input_data
        elif isinstance(input_data, list) and input_data and isinstance(input_data[0], str):
            text = input_data[0]
        else:
            text = str(list(input_data))

        embeddings = await asyncio.to_thread(
            self.model.encode,
            [text],
            normalize_embeddings=True,
            convert_to_numpy=True,
        )
        return np.asarray(embeddings[0]).tolist()

    async def create_batch(self, input_data_list: list[str]) -> list[list[float]]:
        embeddings = await asyncio.to_thread(
            self.model.encode,
            input_data_list,
            normalize_embeddings=True,
            convert_to_numpy=True,
        )
        return [np.asarray(item).tolist() for item in embeddings]
