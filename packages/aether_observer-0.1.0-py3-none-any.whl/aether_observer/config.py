from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Aether Observer"
    app_env: str = "dev"
    api_key: str | None = None

    graph_backend: Literal["kuzu", "neo4j"] = "kuzu"
    kuzu_db_path: str = ".aether/kuzu"
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "password"

    mlx_base_url: str = "http://127.0.0.1:8000/v1"
    mlx_api_key: str = "mlx"
    mlx_model: str = "mlx-community/Qwen2.5-7B-Instruct-4bit"
    mlx_temperature: float = 0.0
    llm_max_tokens: int = 4096
    enable_llm_mitigation: bool = True

    embeddings_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    history_window: int = 20
    history_window_days: int = 20
    min_history: int = 3
    guardrail_warmup_runs: int = 0

    host: str = "0.0.0.0"
    port: int = 8080

    model_config = SettingsConfigDict(
        env_prefix="AETHER_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def kuzu_path(self) -> Path:
        return Path(self.kuzu_db_path)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
