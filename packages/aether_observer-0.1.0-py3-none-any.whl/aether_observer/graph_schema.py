from pydantic import BaseModel


class WorkflowEntity(BaseModel):
    workflow_id: str
    environment: str | None = None
    workflow_version: str | None = None


class AgentEntity(BaseModel):
    agent_name: str
    model: str | None = None
    prompt_version: str | None = None


class RunEntity(BaseModel):
    run_id: str
    status: str
    started_at: str | None = None
    finished_at: str | None = None


class ToolEntity(BaseModel):
    tool_name: str
    status: str | None = None


class DatasetEntity(BaseModel):
    dataset_name: str
    dataset_version: str | None = None
    dataset_schema_hash: str | None = None


class DriftSignalEntity(BaseModel):
    drift_type: str
    kind: str
    severity: str


OBSERVABILITY_ENTITY_TYPES: dict[str, type[BaseModel]] = {
    "Workflow": WorkflowEntity,
    "Agent": AgentEntity,
    "Run": RunEntity,
    "Tool": ToolEntity,
    "Dataset": DatasetEntity,
    "DriftSignal": DriftSignalEntity,
}

OBSERVABILITY_EXTRACTION_INSTRUCTIONS = """
Focus on workflow topology, prompt versions, model names, tool usage, dataset versions,
schema hashes, status changes, drift indicators, and temporal changes between runs.
Treat conflicting or changed facts as versioned workflow history rather than noise.
"""
