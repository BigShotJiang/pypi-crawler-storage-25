from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from aether_observer.config import Settings, get_settings
from aether_observer.demo import seed_demo_scenario
from aether_observer.models import DynamicGuardrailPolicy
from aether_observer.service import ObservabilityService

STATIC_DIR = Path(__file__).resolve().parent / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    service = await ObservabilityService.create(settings)
    app.state.settings = settings
    app.state.service = service
    try:
        yield
    finally:
        await service.close()


app = FastAPI(
    title="Aether Observer",
    description="Graphiti-backed observability agent for external workflows.",
    lifespan=lifespan,
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class DemoSeedRequest(BaseModel):
    tenant_id: str = "acme"
    workflow_id: str = "claims-triage"
    environment: str = "dev"


class GuardrailPolicyRequest(BaseModel):
    policy: DynamicGuardrailPolicy


def get_service(request: Request) -> ObservabilityService:
    return request.app.state.service


def get_active_settings(request: Request) -> Settings:
    return request.app.state.settings


def require_api_key(
    settings: Settings = Depends(get_active_settings),
    x_api_key: str | None = Header(default=None),
) -> None:
    if settings.api_key and x_api_key != settings.api_key:
        raise HTTPException(status_code=401, detail="invalid api key")


@app.get("/")
async def dashboard() -> FileResponse:
    return FileResponse(STATIC_DIR / "dashboard.html")


@app.get("/health", dependencies=[Depends(require_api_key)])
async def health(settings: Settings = Depends(get_active_settings)) -> dict[str, Any]:
    return {
        "status": "ok",
        "environment": settings.app_env,
        "graph_backend": settings.graph_backend,
        "mlx_base_url": settings.mlx_base_url,
        "mlx_model": settings.mlx_model,
    }


@app.post("/observe", dependencies=[Depends(require_api_key)])
async def observe(
    payload: dict[str, Any],
    adapter: str = Query(default="generic"),
    dry_run: bool = Query(default=False),
    service: ObservabilityService = Depends(get_service),
):
    try:
        return await service.observe(payload=payload, adapter=adapter, dry_run=dry_run)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/workflows/{tenant_id}/{workflow_id}/history", dependencies=[Depends(require_api_key)])
async def workflow_history(
    tenant_id: str,
    workflow_id: str,
    limit: int = Query(default=20, ge=1, le=200),
    service: ObservabilityService = Depends(get_service),
):
    return await service.workflow_history(tenant_id=tenant_id, workflow_id=workflow_id, limit=limit)


@app.get("/tenants/{tenant_id}/experiments", dependencies=[Depends(require_api_key)])
async def tenant_experiments(
    tenant_id: str,
    limit: int = Query(default=12, ge=1, le=100),
    service: ObservabilityService = Depends(get_service),
):
    return await service.tenant_experiments(tenant_id=tenant_id, limit=limit)


@app.get("/workflows/{tenant_id}/{workflow_id}/alerts", dependencies=[Depends(require_api_key)])
async def workflow_alerts(
    tenant_id: str,
    workflow_id: str,
    limit: int = Query(default=20, ge=1, le=200),
    service: ObservabilityService = Depends(get_service),
):
    return await service.workflow_alerts(tenant_id=tenant_id, workflow_id=workflow_id, limit=limit)


@app.get("/workflows/{tenant_id}/{workflow_id}/graph", dependencies=[Depends(require_api_key)])
async def workflow_graph(
    tenant_id: str,
    workflow_id: str,
    run_id: str | None = Query(default=None),
    limit: int = Query(default=300, ge=20, le=2000),
    service: ObservabilityService = Depends(get_service),
):
    return await service.workflow_graph(
        tenant_id=tenant_id,
        workflow_id=workflow_id,
        run_id=run_id,
        limit=limit,
    )


@app.get(
    "/workflows/{tenant_id}/{workflow_id}/guardrails/policy",
    dependencies=[Depends(require_api_key)],
)
async def get_guardrail_policy(
    tenant_id: str,
    workflow_id: str,
    service: ObservabilityService = Depends(get_service),
):
    policy = await service.get_guardrail_policy(tenant_id=tenant_id, workflow_id=workflow_id)
    if policy is None:
        raise HTTPException(status_code=404, detail="guardrail policy not found")
    return policy


@app.put(
    "/workflows/{tenant_id}/{workflow_id}/guardrails/policy",
    dependencies=[Depends(require_api_key)],
)
async def put_guardrail_policy(
    tenant_id: str,
    workflow_id: str,
    payload: GuardrailPolicyRequest,
    service: ObservabilityService = Depends(get_service),
):
    policy_data = payload.policy.model_dump(mode="json")
    policy_data["tenant_id"] = tenant_id
    policy_data["workflow_id"] = workflow_id
    policy, stored_episode_uuid = await service.upsert_guardrail_policy(policy_data)
    return {"policy": policy, "stored_episode_uuid": stored_episode_uuid}


@app.get(
    "/workflows/{tenant_id}/{workflow_id}/guardrails/incidents",
    dependencies=[Depends(require_api_key)],
)
async def workflow_guardrail_incidents(
    tenant_id: str,
    workflow_id: str,
    limit: int = Query(default=20, ge=1, le=200),
    service: ObservabilityService = Depends(get_service),
):
    return await service.workflow_guardrail_incidents(
        tenant_id=tenant_id,
        workflow_id=workflow_id,
        limit=limit,
    )


@app.get("/facts", dependencies=[Depends(require_api_key)])
async def facts(
    tenant_id: str,
    query: str,
    limit: int = Query(default=10, ge=1, le=50),
    service: ObservabilityService = Depends(get_service),
):
    return {"facts": await service.search_facts(tenant_id=tenant_id, query=query, limit=limit)}


@app.post("/demo/seed", dependencies=[Depends(require_api_key)])
async def demo_seed(
    payload: DemoSeedRequest,
    service: ObservabilityService = Depends(get_service),
):
    return await seed_demo_scenario(
        service=service,
        tenant_id=payload.tenant_id,
        workflow_id=payload.workflow_id,
        environment=payload.environment,
    )
