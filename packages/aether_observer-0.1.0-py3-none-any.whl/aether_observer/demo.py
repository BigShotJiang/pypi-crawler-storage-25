from __future__ import annotations

from datetime import UTC, datetime, timedelta

from aether_observer.models import (
    DynamicBaselineConfig,
    DynamicGuardrailPolicy,
    FunctionCall,
    FunctionContract,
    NaturalLanguageGuardrail,
    ObservationResult,
    RunStatus,
    RuntimeFunctionGuardrail,
    StepKind,
    WorkflowDataset,
    WorkflowRun,
    WorkflowStep,
)
from aether_observer.service import ObservabilityService


def build_demo_run(
    tenant_id: str,
    workflow_id: str,
    run_id: str,
    started_at: datetime,
    environment: str = "dev",
    prompt_version: str = "planner-v1",
    model: str = "mlx-community/Qwen2.5-1.5B-Instruct-4bit",
    tools: tuple[str, ...] = ("policy_lookup", "claims_db"),
    dataset_version: str = "2026-01",
    include_extra_input: bool = False,
    planner_decision: str = "policy_lookup",
    planner_action: str = "policy_lookup",
    final_decision: str = "review",
) -> WorkflowRun:
    input_payload = {"claim_type": "auto", "region": "ca", "priority": "normal"}
    if include_extra_input:
        input_payload["broker_override"] = True
        input_payload["attachment_manifest"] = [{"kind": "pdf", "pages": 8}]

    steps = [
        WorkflowStep(
            step_id="s1",
            name="plan",
            kind=StepKind.llm,
            status=RunStatus.success,
            model=model,
            prompt_version=prompt_version,
            decision_name="routing_policy",
            decision_value=planner_decision,
            selected_action=planner_action,
            candidate_actions=["policy_lookup", "web_search", "manual_review_router"],
            function_calls=[
                FunctionCall(
                    function_name="route_claim",
                    arguments={
                        "claim_type": input_payload["claim_type"],
                        "region": input_payload["region"],
                        "priority": input_payload["priority"],
                        "policy_version": dataset_version,
                        **(
                            {"broker_override": True, "attachment_manifest": input_payload["attachment_manifest"]}
                            if include_extra_input
                            else {}
                        ),
                    },
                )
            ],
            latency_ms=800,
        )
    ]
    for index, tool in enumerate(tools, start=2):
        if tool == "policy_lookup":
            function_name = "lookup_policy_rules"
            function_args = {
                "claim_type": input_payload["claim_type"],
                "region": input_payload["region"],
                "policy_version": dataset_version,
            }
        elif tool == "claims_db":
            function_name = "fetch_claim_history"
            function_args = {
                "claim_type": input_payload["claim_type"],
                "region": input_payload["region"],
            }
        elif tool == "web_search":
            function_name = "web_search_public_guidance"
            function_args = {
                "query": "california auto claim escalation thresholds",
                "region": input_payload["region"],
                "attachment_manifest": input_payload.get("attachment_manifest", []),
            }
        else:
            function_name = "route_to_manual_review"
            function_args = {
                "claim_type": input_payload["claim_type"],
                "region": input_payload["region"],
                "broker_override": input_payload.get("broker_override", False),
                "reason": "risk_escalation",
            }
        steps.append(
            WorkflowStep(
                step_id=f"s{index}",
                name=tool,
                kind=StepKind.tool,
                status=RunStatus.success,
                selected_action=tool,
                tool_name=tool,
                function_calls=[
                    FunctionCall(
                        function_name=function_name,
                        arguments=function_args,
                    )
                ],
                latency_ms=220,
                datasets=[
                    WorkflowDataset(
                        name="claims_policy",
                        version=dataset_version,
                        schema_hash=f"claims-policy-{dataset_version}",
                    )
                ],
            )
        )

    finished_at = started_at + timedelta(milliseconds=sum(step.latency_ms or 0 for step in steps))

    return WorkflowRun(
        tenant_id=tenant_id,
        workflow_id=workflow_id,
        run_id=run_id,
        agent_name="triage-orchestrator",
        environment=environment,
        status=RunStatus.success,
        started_at=started_at,
        finished_at=finished_at,
        input_payload=input_payload,
        output_payload={"decision": final_decision, "confidence": 0.74},
        datasets=[
            WorkflowDataset(
                name="claims_policy",
                version=dataset_version,
                schema_hash=f"claims-policy-{dataset_version}",
            )
        ],
        steps=steps,
    )


def build_demo_guardrail_policy(
    tenant_id: str,
    workflow_id: str,
) -> DynamicGuardrailPolicy:
    return DynamicGuardrailPolicy(
        policy_id=f"{workflow_id}-dynamic-guardrails",
        tenant_id=tenant_id,
        workflow_id=workflow_id,
        mode="block",
        allowed_models=["mlx-community/Qwen2.5-1.5B-Instruct-4bit"],
        allowed_prompts=["planner-v1"],
        allowed_tools=["policy_lookup", "claims_db"],
        allowed_actions=["policy_lookup", "claims_db"],
        require_approval_actions=["manual_review_router"],
        allowed_functions=["route_claim", "lookup_policy_rules", "fetch_claim_history"],
        function_contracts={
            "route_claim": FunctionContract(
                required_keys=["claim_type", "region", "priority", "policy_version"],
                allowed_keys=["claim_type", "region", "priority", "policy_version"],
                allow_additional_keys=False,
            )
        },
        dataset_version_policies={"claims_policy": ["2026-01"]},
        max_step_count=4,
        max_latency_ms=1800,
        runtime_function_guardrails=[
            RuntimeFunctionGuardrail(
                guardrail_id="no-public-web-search",
                function_name="disallow_public_web_search",
                title="No public web search",
                description="Stops any workflow instance that routes through public web search.",
                stop_on_failure=True,
            )
        ],
        natural_language_guardrails=[
            NaturalLanguageGuardrail(
                guardrail_id="llm-route-safety",
                title="Route safety instruction",
                instruction=(
                    "Fail if any step uses the web_search action or routes to manual_review_router "
                    "for a normal insurance claim. If it fails, point to the offending step_id."
                ),
                stop_on_failure=True,
            )
        ],
        dynamic_baseline=DynamicBaselineConfig(
            decisions_from_history=True,
            actions_from_history=True,
            functions_from_history=True,
        ),
    )


async def seed_demo_scenario(
    service: ObservabilityService,
    tenant_id: str = "acme",
    workflow_id: str = "claims-triage",
    environment: str = "dev",
) -> list[ObservationResult]:
    await service.upsert_guardrail_policy(build_demo_guardrail_policy(tenant_id, workflow_id))
    anchor = datetime.now(UTC) - timedelta(minutes=8)
    results: list[ObservationResult] = []

    for index in range(4):
        run = build_demo_run(
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            run_id=f"baseline-{index}",
            started_at=anchor + timedelta(minutes=index),
            environment=environment,
        )
        results.append(await service.observe(run))

    drifted = build_demo_run(
        tenant_id=tenant_id,
        workflow_id=workflow_id,
        run_id="drifted-1",
        started_at=anchor + timedelta(minutes=5),
        environment=environment,
        prompt_version="planner-v2",
        model="mlx-community/Llama-3.2-3B-Instruct-4bit",
        tools=("web_search", "policy_lookup", "manual_review_router"),
        dataset_version="2026-02",
        include_extra_input=True,
        planner_decision="manual_review_router",
        planner_action="web_search",
        final_decision="manual_review",
    )
    results.append(await service.observe(drifted))

    return results
