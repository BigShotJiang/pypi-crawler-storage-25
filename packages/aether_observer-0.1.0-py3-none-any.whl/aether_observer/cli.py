from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from aether_observer.config import get_settings
from aether_observer.service import ObservabilityService


async def observe_file(path: Path, adapter: str, dry_run: bool) -> None:
    service = await ObservabilityService.create()
    try:
        payload = json.loads(path.read_text())
        result = await service.observe(payload=payload, adapter=adapter, dry_run=dry_run)
        print(json.dumps(result.model_dump(mode="json"), indent=2))
    finally:
        await service.close()


async def print_history(tenant_id: str, workflow_id: str, limit: int) -> None:
    service = await ObservabilityService.create()
    try:
        result = await service.workflow_history(tenant_id=tenant_id, workflow_id=workflow_id, limit=limit)
        print(json.dumps([item.model_dump(mode="json") for item in result], indent=2))
    finally:
        await service.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Aether Observer CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    serve_parser = subparsers.add_parser("serve", help="Run the FastAPI server")
    serve_parser.add_argument("--reload", action="store_true")

    observe_parser = subparsers.add_parser("observe", help="Observe a workflow run from a JSON file")
    observe_parser.add_argument("path", type=Path)
    observe_parser.add_argument("--adapter", default="generic")
    observe_parser.add_argument("--dry-run", action="store_true")

    history_parser = subparsers.add_parser("history", help="Print workflow history from Graphiti")
    history_parser.add_argument("tenant_id")
    history_parser.add_argument("workflow_id")
    history_parser.add_argument("--limit", type=int, default=20)

    args = parser.parse_args()
    settings = get_settings()

    if args.command == "serve":
        try:
            import uvicorn
        except ImportError:
            print(
                "Server dependencies not installed.\n"
                "Install with: pip install aether-observer[server]"
            )
            raise SystemExit(1)
        uvicorn.run(
            "aether_observer.api:app",
            host=settings.host,
            port=settings.port,
            reload=args.reload,
        )
        return

    if args.command == "observe":
        asyncio.run(observe_file(args.path, adapter=args.adapter, dry_run=args.dry_run))
        return

    if args.command == "history":
        asyncio.run(print_history(args.tenant_id, args.workflow_id, args.limit))


if __name__ == "__main__":
    main()
