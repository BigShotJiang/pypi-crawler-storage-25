from __future__ import annotations

import re
from dataclasses import dataclass

from graphiti_core import Graphiti
from graphiti_core.cross_encoder.client import CrossEncoderClient
from graphiti_core.driver.kuzu_driver import KuzuDriver
from graphiti_core.llm_client.config import LLMConfig

from aether_observer.config import Settings
from aether_observer.embedder import SentenceTransformerEmbedder
from aether_observer.llm import MLXLLMClient


def tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[a-zA-Z0-9_]+", text.lower()) if token}


class LocalKeywordCrossEncoder(CrossEncoderClient):
    async def rank(self, query: str, passages: list[str]) -> list[tuple[str, float]]:
        query_tokens = tokenize(query)
        ranked: list[tuple[str, float]] = []
        for passage in passages:
            passage_tokens = tokenize(passage)
            if not query_tokens or not passage_tokens:
                score = 0.0
            else:
                score = len(query_tokens & passage_tokens) / len(query_tokens | passage_tokens)
            ranked.append((passage, score))
        return sorted(ranked, key=lambda item: item[1], reverse=True)


class TenantAwareKuzuDriver(KuzuDriver):
    def __init__(self, db: str = ":memory:", max_concurrent_queries: int = 1):
        super().__init__(db=db, max_concurrent_queries=max_concurrent_queries)
        self._database = ""

    def clone(self, database: str):
        return self.with_database(database)


@dataclass
class RuntimeBundle:
    graphiti: Graphiti
    llm_client: MLXLLMClient

    async def close(self) -> None:
        await self.graphiti.close()


async def build_runtime(settings: Settings) -> RuntimeBundle:
    llm_client = MLXLLMClient(
        config=LLMConfig(
            api_key=settings.mlx_api_key,
            model=settings.mlx_model,
            base_url=settings.mlx_base_url,
            temperature=settings.mlx_temperature,
            max_tokens=settings.llm_max_tokens,
        )
    )
    embedder = SentenceTransformerEmbedder(settings.embeddings_model)
    cross_encoder = LocalKeywordCrossEncoder()

    if settings.graph_backend == "kuzu":
        settings.kuzu_path.parent.mkdir(parents=True, exist_ok=True)
        driver = TenantAwareKuzuDriver(db=str(settings.kuzu_path))
        graphiti = Graphiti(
            graph_driver=driver,
            llm_client=llm_client,
            embedder=embedder,
            cross_encoder=cross_encoder,
        )
    else:
        graphiti = Graphiti(
            uri=settings.neo4j_uri,
            user=settings.neo4j_user,
            password=settings.neo4j_password,
            llm_client=llm_client,
            embedder=embedder,
            cross_encoder=cross_encoder,
        )

    await graphiti.build_indices_and_constraints()
    return RuntimeBundle(graphiti=graphiti, llm_client=llm_client)
