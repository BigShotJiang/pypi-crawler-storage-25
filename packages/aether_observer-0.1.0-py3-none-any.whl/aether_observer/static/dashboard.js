const state = {
  apiKey: "",
  latestObservation: null,
  health: null,
  experiments: [],
  history: [],
  alerts: [],
  guardrailIncidents: [],
  guardrailPolicy: null,
  facts: [],
  selectedRunId: null,
  selectedWorkflowNodeId: null,
  workflowCanvasModel: null,
  workflowLayouts: {},
  graphData: null,
  graphError: null,
  graphCache: {},
  selectedGraphNodeId: null,
  graphFocusNodeIds: [],
  graphLayouts: {},
  ui: {
    showControls: false,
    showMetrics: false,
    showSecondary: false,
    workflowView: "canvas",
    graphView: "canvas",
    dockTab: "alerts",
    activePage: "overview",
  },
};

const els = {
  apiKeyInput: document.getElementById("apiKeyInput"),
  tenantInput: document.getElementById("tenantInput"),
  workflowInput: document.getElementById("workflowInput"),
  factsQueryInput: document.getElementById("factsQueryInput"),
  payloadEditor: document.getElementById("payloadEditor"),
  controlOverlay: document.getElementById("controlOverlay"),
  appPageButtons: document.querySelectorAll("[data-app-page]"),
  pagePanels: document.querySelectorAll("[data-page-panel]"),
  pageTitle: document.getElementById("pageTitle"),
  pageSubtitle: document.getElementById("pageSubtitle"),
  toggleControlsButton: document.getElementById("toggleControlsButton"),
  toggleMetricsButton: document.getElementById("toggleMetricsButton"),
  toggleSecondaryButton: document.getElementById("toggleSecondaryButton"),
  seedDemoButton: document.getElementById("seedDemoButton"),
  refreshButton: document.getElementById("refreshButton"),
  loadSampleButton: document.getElementById("loadSampleButton"),
  observeButton: document.getElementById("observeButton"),
  workflowViewButtons: document.querySelectorAll("[data-workflow-view]"),
  graphViewButtons: document.querySelectorAll("[data-graph-view]"),
  focusLatestButton: document.getElementById("focusLatestButton"),
  openSelectedButton: document.getElementById("openSelectedButton"),
  reloadGraphButton: document.getElementById("reloadGraphButton"),
  centerGraphButton: document.getElementById("centerGraphButton"),
  runtimeStatus: document.getElementById("runtimeStatus"),
  statusOrb: document.getElementById("statusOrb"),
  scopeTenantChip: document.getElementById("scopeTenantChip"),
  scopeWorkflowChip: document.getElementById("scopeWorkflowChip"),
  healthMetric: document.getElementById("healthMetric"),
  backendMetric: document.getElementById("backendMetric"),
  riskMetric: document.getElementById("riskMetric"),
  severityMetric: document.getElementById("severityMetric"),
  historyMetric: document.getElementById("historyMetric"),
  alertsMetric: document.getElementById("alertsMetric"),
  experimentsGrid: document.getElementById("experimentsGrid"),
  historyList: document.getElementById("historyList"),
  alertsList: document.getElementById("alertsList"),
  factsList: document.getElementById("factsList"),
  latestSummary: document.getElementById("latestSummary"),
  guardrailPageContent: document.getElementById("guardrailPageContent"),
  guardrailPolicySummary: document.getElementById("guardrailPolicySummary"),
  guardrailIncidentList: document.getElementById("guardrailIncidentList"),
  consoleOutput: document.getElementById("consoleOutput"),
  canvasMeta: document.getElementById("canvasMeta"),
  workflowCanvas: document.getElementById("workflowCanvas"),
  workflowCanvasNodes: document.getElementById("workflowCanvasNodes"),
  workflowCanvasLinks: document.getElementById("workflowCanvasLinks"),
  workflowCanvasEmpty: document.getElementById("workflowCanvasEmpty"),
  workflowCanvasScroll: document.getElementById("workflowCanvasScroll"),
  canvasInspector: document.getElementById("canvasInspector"),
  graphMeta: document.getElementById("graphMeta"),
  graphSurface: document.getElementById("graphSurface"),
  graphLinks: document.getElementById("graphLinks"),
  graphNodes: document.getElementById("graphNodes"),
  graphEmpty: document.getElementById("graphEmpty"),
  graphCanvasScroll: document.getElementById("graphCanvasScroll"),
  graphInspector: document.getElementById("graphInspector"),
  detailDrawer: document.getElementById("detailDrawer"),
  detailOverlay: document.getElementById("detailOverlay"),
  detailBody: document.getElementById("detailBody"),
  detailClose: document.getElementById("detailClose"),
  dockTabButtons: document.querySelectorAll("[data-dock-tab]"),
  dockPanels: document.querySelectorAll("[data-dock-panel]"),
};

function samplePayload() {
  return {
    tenant_id: els.tenantInput.value.trim() || "acme",
    workflow_id: els.workflowInput.value.trim() || "claims-triage",
    run_id: `manual-${Date.now()}`,
    agent_name: "triage-orchestrator",
    environment: "dev",
    status: "success",
    started_at: new Date(Date.now() - 90 * 1000).toISOString(),
    finished_at: new Date(Date.now() - 88 * 1000).toISOString(),
    input_payload: {
      claim_type: "auto",
      region: "ca",
      priority: "normal",
      customer_tier: "gold",
    },
    output_payload: {
      decision: "review",
      confidence: 0.74,
      destination: "manual_review_queue",
    },
    datasets: [
      {
        name: "claims_policy",
        version: "2026-01",
        schema_hash: "claims-policy-2026-01",
      },
    ],
    guardrail_policy: {
      policy_id: "inline-client-guardrails",
      tenant_id: els.tenantInput.value.trim() || "acme",
      workflow_id: els.workflowInput.value.trim() || "claims-triage",
      mode: "block",
      allowed_models: ["mlx-community/Qwen2.5-1.5B-Instruct-4bit"],
      allowed_prompts: ["planner-v1"],
      allowed_tools: ["policy_lookup", "claims_db"],
      allowed_actions: ["policy_lookup", "claims_db"],
      require_approval_actions: ["manual_review_router"],
      allowed_functions: ["route_claim", "lookup_policy_rules", "fetch_claim_history"],
      function_contracts: {
        route_claim: {
          required_keys: ["claim_type", "region", "priority", "policy_version"],
          allowed_keys: ["claim_type", "region", "priority", "policy_version"],
          allow_additional_keys: false,
        },
      },
      dataset_version_policies: {
        claims_policy: ["2026-01"],
      },
      max_step_count: 4,
      max_latency_ms: 1800,
      runtime_function_guardrails: [
        {
          guardrail_id: "no-public-web-search",
          function_name: "disallow_public_web_search",
          title: "No public web search",
          description: "Stops any workflow instance that routes through public web search.",
          stop_on_failure: true,
        },
      ],
      natural_language_guardrails: [
        {
          guardrail_id: "llm-route-safety",
          title: "Route safety instruction",
          instruction:
            "Fail if any step uses the web_search action or routes to manual_review_router for a normal insurance claim. If it fails, point to the offending step_id.",
          stop_on_failure: true,
        },
      ],
      dynamic_baseline: {
        decisions_from_history: true,
        actions_from_history: true,
        functions_from_history: true,
      },
    },
    steps: [
      {
        step_id: "s1",
        name: "plan",
        kind: "llm",
        status: "success",
        model: "mlx-community/Qwen2.5-1.5B-Instruct-4bit",
        prompt_version: "planner-v1",
        decision_name: "routing_policy",
        decision_value: "policy_lookup",
        selected_action: "policy_lookup",
        candidate_actions: ["policy_lookup", "web_search", "manual_review_router"],
        function_calls: [
          {
            function_name: "route_claim",
            arguments: {
              claim_type: "auto",
              region: "ca",
              priority: "normal",
              policy_version: "2026-01",
            },
          },
        ],
        latency_ms: 800,
      },
      {
        step_id: "s2",
        name: "policy_lookup",
        kind: "tool",
        status: "success",
        tool_name: "policy_lookup",
        selected_action: "policy_lookup",
        function_calls: [
          {
            function_name: "lookup_policy_rules",
            arguments: {
              claim_type: "auto",
              region: "ca",
              policy_version: "2026-01",
            },
          },
        ],
        latency_ms: 220,
      },
      {
        step_id: "s3",
        name: "claims_db",
        kind: "tool",
        status: "success",
        tool_name: "claims_db",
        selected_action: "claims_db",
        function_calls: [
          {
            function_name: "fetch_claim_history",
            arguments: {
              claim_type: "auto",
              region: "ca",
            },
          },
        ],
        latency_ms: 220,
      },
    ],
  };
}

function headers() {
  const result = { "Content-Type": "application/json" };
  if (state.apiKey) {
    result["X-API-Key"] = state.apiKey;
  }
  return result;
}

async function apiRequest(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      ...headers(),
      ...(options.headers || {}),
    },
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(`${response.status} ${message}`);
  }

  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }
  return response.text();
}

function logLine(message) {
  const stamp = new Date().toLocaleTimeString();
  els.consoleOutput.textContent = `[${stamp}] ${message}\n${els.consoleOutput.textContent}`.trimEnd();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function safeJson(value) {
  return escapeHtml(JSON.stringify(value, null, 2));
}

function severityClass(severity) {
  return `severity-${severity || "info"}`;
}

function formatTimestamp(value) {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleString();
  } catch {
    return String(value);
  }
}

function durationForRun(run) {
  if (!run?.started_at || !run?.finished_at) return "—";
  const durationMs = new Date(run.finished_at) - new Date(run.started_at);
  if (Number.isNaN(durationMs)) return "—";
  return `${(durationMs / 1000).toFixed(2)}s`;
}

function unique(values) {
  return [...new Set((values || []).filter(Boolean))];
}

function alertSnapshotForObservation(observation) {
  if (!observation?.run) return null;
  return {
    run_id: observation.run.run_id,
    observed_at: observation.run.finished_at || observation.run.started_at,
    severity: observation.severity,
    risk_score: observation.risk_score,
    signals: observation.signals || [],
    graph_explanations: observation.graph_explanations || [],
    recommendation_summary: observation.recommendation_summary || "",
  };
}

function guardrailSnapshotForObservation(observation) {
  if (!observation?.run || !observation.guardrail_result) return null;
  return {
    run_id: observation.run.run_id,
    observed_at: observation.run.finished_at || observation.run.started_at,
    policy_id: observation.guardrail_result.policy_id,
    mode: observation.guardrail_result.mode,
    verdict: observation.guardrail_result.verdict,
    violations: observation.guardrail_result.violations || [],
    graph_explanations: observation.guardrail_result.graph_explanations || [],
    checks: observation.guardrail_result.checks || [],
    stopped_run: Boolean(observation.guardrail_result.stopped_run),
    stop_reason: observation.guardrail_result.stop_reason || "",
  };
}

function knownRuns() {
  const runs = [...state.history];
  const latestRun = state.latestObservation?.run;
  if (latestRun && !runs.some((run) => run.run_id === latestRun.run_id)) {
    runs.unshift(latestRun);
  }
  return runs;
}

function findRun(runId) {
  return knownRuns().find((run) => run.run_id === runId) || null;
}

function alertForRun(runId) {
  if (!runId) return null;
  const existing = state.alerts.find((alert) => alert.run_id === runId);
  if (existing) return existing;
  const latest = alertSnapshotForObservation(state.latestObservation);
  if (latest?.run_id === runId) return latest;
  return null;
}

function guardrailForRun(runId) {
  if (!runId) return null;
  const existing = state.guardrailIncidents.find((incident) => incident.run_id === runId);
  if (existing) return existing;
  const latest = guardrailSnapshotForObservation(state.latestObservation);
  if (latest?.run_id === runId) return latest;
  return null;
}

function getSelectedRun() {
  return findRun(state.selectedRunId) || state.latestObservation?.run || state.history[0] || null;
}

function ensureSelectedRun() {
  const run = getSelectedRun();
  if (!run) {
    state.selectedRunId = null;
    state.selectedWorkflowNodeId = null;
    return null;
  }

  state.selectedRunId = run.run_id;
  if (!state.selectedWorkflowNodeId) {
    state.selectedWorkflowNodeId = `run:${run.run_id}`;
  }
  return run;
}

const UI_STATE_STORAGE_KEY = "aether-observer-ui-state-v4";

const PAGE_META = {
  overview: {
    title: "Overview",
    subtitle: "Tenant-wide experiment overview plus the latest observation and risk snapshot for the selected workflow.",
  },
  canvas: {
    title: "Workflow Canvas",
    subtitle: "Trace the selected run through planner decisions, actions, function calls, and guardrail failures.",
  },
  graph: {
    title: "Graphiti Evidence",
    subtitle: "Inspect the persisted Graphiti subgraph and connected entity facts for the selected workflow run.",
  },
  guardrails: {
    title: "Guardrails",
    subtitle: "Review policy configuration, executable checks, LLM instructions, incidents, and workflow stops.",
  },
};

function loadUiState() {
  try {
    const raw = window.localStorage.getItem(UI_STATE_STORAGE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    state.ui = {
      ...state.ui,
      ...(parsed || {}),
    };
  } catch {
    // ignore malformed local UI state
  }
}

function persistUiState() {
  try {
    window.localStorage.setItem(UI_STATE_STORAGE_KEY, JSON.stringify(state.ui));
  } catch {
    // ignore storage failures
  }
}

function setActiveToggle(buttons, activeValue, datasetKey) {
  buttons.forEach((button) => {
    button.classList.toggle("active", button.dataset[datasetKey] === activeValue);
  });
}

function setToggleButton(button, active, activeLabel, inactiveLabel) {
  if (!button) return;
  button.classList.toggle("active", active);
  button.textContent = active ? activeLabel : inactiveLabel;
}

function applyUiState() {
  document.body.classList.toggle("controls-open", state.ui.showControls);
  document.body.classList.toggle("metrics-collapsed", !state.ui.showMetrics);
  document.body.classList.toggle("secondary-collapsed", !state.ui.showSecondary);
  document.body.classList.toggle("metrics-visible", state.ui.showMetrics);
  document.body.classList.toggle("dock-visible", state.ui.showSecondary);
  document.body.classList.remove("page-overview", "page-canvas", "page-graph", "page-guardrails");
  document.body.classList.add(`page-${state.ui.activePage}`);

  document.body.classList.remove("workflow-view-split", "workflow-view-canvas", "workflow-view-inspector");
  document.body.classList.add(`workflow-view-${state.ui.workflowView}`);
  document.body.classList.remove("graph-view-split", "graph-view-canvas", "graph-view-inspector");
  document.body.classList.add(`graph-view-${state.ui.graphView}`);

  setToggleButton(els.toggleControlsButton, state.ui.showControls, "Hide Controls", "Show Controls");
  setToggleButton(els.toggleMetricsButton, state.ui.showMetrics, "Hide Metrics", "Show Metrics");
  setToggleButton(els.toggleSecondaryButton, state.ui.showSecondary, "Hide Activity", "Show Activity");
  setActiveToggle(els.appPageButtons, state.ui.activePage, "appPage");
  setActiveToggle(els.workflowViewButtons, state.ui.workflowView, "workflowView");
  setActiveToggle(els.graphViewButtons, state.ui.graphView, "graphView");
  setActiveToggle(els.dockTabButtons, state.ui.dockTab, "dockTab");
  els.pagePanels.forEach((panel) => {
    panel.hidden = panel.dataset.pagePanel !== state.ui.activePage;
  });
  els.dockPanels.forEach((panel) => {
    panel.hidden = panel.dataset.dockPanel !== state.ui.dockTab;
  });
  const pageMeta = PAGE_META[state.ui.activePage] || PAGE_META.overview;
  if (els.pageTitle) {
    els.pageTitle.textContent = pageMeta.title;
  }
  if (els.pageSubtitle) {
    els.pageSubtitle.textContent = pageMeta.subtitle;
  }
}

function toggleUiFlag(flag) {
  state.ui[flag] = !state.ui[flag];
  persistUiState();
  applyUiState();
}

function setUiView(key, value) {
  state.ui[key] = value;
  persistUiState();
  applyUiState();
}

function setDockTab(value) {
  state.ui.dockTab = value;
  if (!state.ui.showSecondary) {
    state.ui.showSecondary = true;
  }
  persistUiState();
  applyUiState();
}

function setActivePage(value) {
  state.ui.activePage = value;
  persistUiState();
  applyUiState();
  if (window.location.hash !== `#${value}`) {
    history.replaceState(null, "", `#${value}`);
  }
}

function loadPageFromLocation() {
  const hash = window.location.hash.replace("#", "").trim();
  if (hash && PAGE_META[hash]) {
    state.ui.activePage = hash;
    return true;
  }
  return false;
}

function updateScopeChips() {
  const tenant = els.tenantInput.value.trim() || "acme";
  const workflow = els.workflowInput.value.trim() || "claims-triage";
  els.scopeTenantChip.textContent = `tenant ${tenant}`;
  els.scopeWorkflowChip.textContent = `workflow ${workflow}`;
}

function workflowLayoutForRun(runId) {
  if (!state.workflowLayouts[runId]) {
    state.workflowLayouts[runId] = {};
  }
  return state.workflowLayouts[runId];
}

function graphLayoutKey(graphData) {
  return `${graphData.workflow_id}:${graphData.run_id || "workflow"}`;
}

function graphLayoutForGraph(graphData) {
  const key = graphLayoutKey(graphData);
  if (!state.graphLayouts[key]) {
    state.graphLayouts[key] = {};
  }
  return state.graphLayouts[key];
}

function renderStateList(lines) {
  if (!lines || !lines.length) {
    return `<p class="item-meta">No state captured.</p>`;
  }
  return `<ul class="state-list">${lines.map((line) => `<li>${escapeHtml(line)}</li>`).join("")}</ul>`;
}

function renderGraphExplanations(explanations) {
  if (!explanations || !explanations.length) {
    return `<p class="empty-state">No graph-backed explanations generated for this observation.</p>`;
  }

  return explanations
    .map((explanation) => {
      const graphFacts = explanation.graph_facts || [];
      return `
        <article class="explanation-card">
          <p class="item-title">${escapeHtml(explanation.title || explanation.signal_kind)}</p>
          <p class="item-meta">${escapeHtml(explanation.summary || "No explanation summary stored.")}</p>
          <div class="explanation-grid">
            <div>
              <p class="explanation-label">Current State</p>
              ${renderStateList(explanation.current_state || [])}
            </div>
            <div>
              <p class="explanation-label">Baseline State</p>
              ${renderStateList(explanation.baseline_state || explanation.expected_state || [])}
            </div>
          </div>
          <div>
            <p class="explanation-label">Graph Facts</p>
            ${renderStateList(graphFacts)}
          </div>
        </article>
      `;
    })
    .join("");
}

function renderGuardrailResult(guardrailResult) {
  if (!guardrailResult) {
    return `<p class="empty-state">No guardrail policy was applied to this run.</p>`;
  }

  const checks = (guardrailResult.checks || [])
    .map((check) => {
      const symbol =
        check.status === "pass" ? "✓" : check.status === "error" ? "!" : "×";
      const cssClass =
        check.status === "pass"
          ? "guardrail-check-pass"
          : check.status === "error"
            ? "guardrail-check-error"
            : "guardrail-check-fail";
      return `
        <article class="guardrail-check ${cssClass}">
          <div class="guardrail-check-head">
            <span class="guardrail-check-symbol">${symbol}</span>
            <div>
              <p class="item-title">${escapeHtml(check.title || check.guardrail_id)}</p>
              <p class="item-meta">${escapeHtml(check.kind)}</p>
            </div>
            <span class="item-pill">${escapeHtml(check.status)}</span>
          </div>
          <p class="item-meta">${escapeHtml(check.summary || "No summary stored.")}</p>
          ${check.stop_workflow ? '<p class="guardrail-stop-note">Stops workflow on failure</p>' : ""}
        </article>
      `;
    })
    .join("");

  const chips = (guardrailResult.violations || [])
    .map((violation) => `<span class="signal-chip">${escapeHtml(violation.kind)}</span>`)
    .join("");

  const explanations = (guardrailResult.graph_explanations || [])
    .map(
      (explanation) => `
        <article class="explanation-card">
          <p class="item-title">${escapeHtml(explanation.title)}</p>
          <p class="item-meta">${escapeHtml(explanation.summary)}</p>
          <div class="explanation-grid">
            <div>
              <p class="explanation-label">Current State</p>
              ${renderStateList(explanation.current_state || [])}
            </div>
            <div>
              <p class="explanation-label">Expected State</p>
              ${renderStateList(explanation.expected_state || [])}
            </div>
          </div>
          <div>
            <p class="explanation-label">Graph Facts</p>
            ${renderStateList(explanation.graph_facts || [])}
          </div>
        </article>
      `,
    )
    .join("");

  const verdictSeverity =
    guardrailResult.verdict === "block"
      ? "critical"
      : guardrailResult.verdict === "warn"
        ? "high"
        : "low";

  return `
    <article class="summary-card ${severityClass(verdictSeverity)}">
      <div class="item-row">
        <div>
          <p class="item-title">Guardrail Verdict</p>
          <p class="item-subtitle">policy ${escapeHtml(guardrailResult.policy_id || "none")} · mode ${escapeHtml(guardrailResult.mode)}</p>
        </div>
        <span class="item-pill">${escapeHtml(guardrailResult.verdict)}</span>
      </div>
      ${
        guardrailResult.stopped_run
          ? `<p class="guardrail-stop-banner">× workflow stopped · ${escapeHtml(guardrailResult.stop_reason || "blocking guardrail failed")}</p>`
          : ""
      }
      <div class="signals">${chips || '<span class="signal-chip">no violations</span>'}</div>
    </article>
    ${
      checks
        ? `<div class="guardrail-check-grid">${checks}</div>`
        : '<p class="empty-state">No executable guardrails were run for this observation.</p>'
    }
    ${explanations || '<p class="empty-state">No guardrail explanations generated for this run.</p>'}
  `;
}

function renderHealth() {
  if (!state.health) return;
  els.healthMetric.textContent = String(state.health.status || "-").toUpperCase();
  els.backendMetric.textContent = `${state.health.graph_backend} + ${state.health.mlx_model}`;
  els.runtimeStatus.textContent = `${String(state.health.status || "unknown").toUpperCase()} / ${state.health.environment}`;
  els.statusOrb.classList.add("online");
  els.statusOrb.classList.remove("error");
}

function renderMetrics() {
  const latest = state.latestObservation;
  els.riskMetric.textContent = latest ? Number(latest.risk_score || 0).toFixed(3) : "-";
  els.severityMetric.textContent = latest
    ? `Latest severity: ${latest.severity}`
    : "Run an observation to populate";
  els.historyMetric.textContent = String(state.history.length);
  els.alertsMetric.textContent = String(state.alerts.length);
}

function renderExperiments() {
  if (!els.experimentsGrid) return;

  const experiments = state.experiments || [];
  const selectedWorkflow = els.workflowInput.value.trim();
  if (!experiments.length) {
    els.experimentsGrid.innerHTML =
      '<p class="empty-state">No experiments discovered for this tenant yet. Observe a few runs or seed the demo to populate the workspace.</p>';
    return;
  }

  els.experimentsGrid.innerHTML = experiments
    .map((experiment) => {
      const severity = experiment.latest_severity || "info";
      const isActive = experiment.workflow_id === selectedWorkflow;
      const verdict = experiment.latest_guardrail_verdict || "pass";
      return `
        <button
          class="experiment-card ${severityClass(severity)} ${isActive ? "active" : ""}"
          type="button"
          data-workflow-select="${escapeHtml(experiment.workflow_id)}"
        >
          <div class="experiment-card-head">
            <div>
              <p class="panel-kicker">workflow</p>
              <h3>${escapeHtml(experiment.workflow_id)}</h3>
            </div>
            <span class="item-pill">${escapeHtml(verdict)}</span>
          </div>
          <p class="experiment-card-copy">
            ${escapeHtml(experiment.latest_agent_name || "No agent metadata yet")} · latest ${escapeHtml(formatTimestamp(experiment.latest_observed_at))}
          </p>
          <div class="experiment-card-metrics">
            <span class="canvas-metric">${experiment.run_count} run${experiment.run_count === 1 ? "" : "s"}</span>
            <span class="canvas-metric">${experiment.drift_alert_count} alert${experiment.drift_alert_count === 1 ? "" : "s"}</span>
            <span class="canvas-metric">${experiment.guardrail_incident_count} incident${experiment.guardrail_incident_count === 1 ? "" : "s"}</span>
            <span class="canvas-metric ${experiment.blocked_run_count ? "canvas-metric-stop" : ""}">${experiment.blocked_run_count} blocked</span>
          </div>
          <div class="experiment-card-footer">
            <span class="item-meta">latest risk ${experiment.latest_risk_score != null ? Number(experiment.latest_risk_score).toFixed(3) : "—"}</span>
            <span class="item-meta">${escapeHtml(experiment.latest_status || "unknown")}</span>
          </div>
        </button>
      `;
    })
    .join("");

  els.experimentsGrid.querySelectorAll("[data-workflow-select]").forEach((element) => {
    element.addEventListener("click", () => {
      els.workflowInput.value = element.dataset.workflowSelect || "";
      updateScopeChips();
      void refreshWorkflowViews();
      logLine(`switched workspace to ${element.dataset.workflowSelect}`);
    });
  });
}

function renderStepTimeline(steps) {
  if (!steps || !steps.length) {
    return `<p class="empty-state">No steps recorded.</p>`;
  }

  return `<div class="step-timeline">${steps
    .map((step, index) => {
      const fnCalls = (step.function_calls || [])
        .map(
          (call) =>
            `<span class="fn-chip">${escapeHtml(call.function_name)}(${escapeHtml(Object.keys(call.arguments || {}).join(", "))})</span>`,
        )
        .join("");
      const kindIcon = step.kind === "llm" ? "LLM" : "TOOL";
      return `
        <div class="step-node ${step.status === "success" ? "step-ok" : "step-fail"}">
          <div class="step-connector">${index < steps.length - 1 ? '<div class="step-line"></div>' : ""}</div>
          <div class="step-content">
            <div class="step-header">
              <span class="step-kind-badge">${kindIcon}</span>
              <span class="step-name">${escapeHtml(step.name)}</span>
              ${step.latency_ms != null ? `<span class="step-latency">${step.latency_ms} ms</span>` : ""}
            </div>
            ${step.model ? `<p class="step-detail">Model: ${escapeHtml(step.model)}</p>` : ""}
            ${step.prompt_version ? `<p class="step-detail">Prompt: ${escapeHtml(step.prompt_version)}</p>` : ""}
            ${step.tool_name ? `<p class="step-detail">Tool: ${escapeHtml(step.tool_name)}</p>` : ""}
            ${step.decision_name ? `<p class="step-detail">Decision: ${escapeHtml(step.decision_name)} → ${escapeHtml(step.decision_value || "?")}</p>` : ""}
            ${step.selected_action ? `<p class="step-detail">Action: ${escapeHtml(step.selected_action)}</p>` : ""}
            ${fnCalls ? `<div class="step-fns">${fnCalls}</div>` : ""}
          </div>
        </div>
      `;
    })
    .join("")}</div>`;
}

function renderRunDetail(run, alert) {
  const started = formatTimestamp(run.started_at);
  const finished = run.finished_at ? formatTimestamp(run.finished_at) : "—";
  const duration = durationForRun(run);
  const models = unique(run.steps.map((step) => step.model));
  const tools = unique(run.steps.map((step) => step.tool_name));
  const datasets = (run.datasets || []).map((dataset) => `${dataset.name}:${dataset.version}`);
  const guardrail = guardrailForRun(run.run_id);

  let alertSection = "";
  if (alert) {
    const signalChips = (alert.signals || [])
      .map((signal) => {
        const color =
          signal.severity === "critical"
            ? "var(--critical)"
            : signal.severity === "high"
              ? "var(--high)"
              : signal.severity === "medium"
                ? "var(--medium)"
                : "var(--low)";
        return `<span class="signal-chip-detail" style="border-color:${color};color:${color}">${escapeHtml(signal.kind)} <small>${Number(signal.score || 0).toFixed(2)}</small></span>`;
      })
      .join("");

    const signalDetails = (alert.signals || [])
      .map(
        (signal) => `
          <div class="signal-detail-card">
            <div class="signal-detail-header">
              <span class="signal-detail-kind">${escapeHtml(signal.kind)}</span>
              <span class="signal-detail-score severity-pill-${signal.severity}">${escapeHtml(signal.severity)} · ${Number(signal.score || 0).toFixed(2)}</span>
            </div>
            <p class="signal-detail-summary">${escapeHtml(signal.summary || "No summary stored.")}</p>
            ${signal.recommended_actions?.length ? `<ul class="signal-actions">${signal.recommended_actions.map((action) => `<li>${escapeHtml(action)}</li>`).join("")}</ul>` : ""}
          </div>
        `,
      )
      .join("");

    alertSection = `
      <div class="detail-section">
        <h3 class="detail-section-title">Drift Signals</h3>
        <div class="detail-kv"><span class="detail-key">Risk Score</span><span class="detail-val">${Number(alert.risk_score || 0).toFixed(3)}</span></div>
        <div class="detail-kv"><span class="detail-key">Severity</span><span class="item-pill severity-pill-${alert.severity}">${escapeHtml(alert.severity)}</span></div>
        <div class="signals-wrap">${signalChips}</div>
        ${signalDetails}
        ${alert.recommendation_summary ? `<div class="recommendation-box"><p class="recommendation-label">Recommendation</p><p>${escapeHtml(alert.recommendation_summary)}</p></div>` : ""}
      </div>
      ${(alert.graph_explanations || []).length ? `<div class="detail-section"><h3 class="detail-section-title">Graph Explanations</h3>${renderGraphExplanations(alert.graph_explanations)}</div>` : ""}
    `;
  }

  return `
    <div class="detail-header-bar ${alert ? severityClass(alert.severity) : ""}">
      <h2 class="detail-run-id">${escapeHtml(run.run_id)}</h2>
      <span class="item-pill">${escapeHtml(run.status)}</span>
    </div>

    <div class="detail-section">
      <h3 class="detail-section-title">Run Info</h3>
      <div class="detail-kv-grid">
        <div class="detail-kv"><span class="detail-key">Agent</span><span class="detail-val">${escapeHtml(run.agent_name || "—")}</span></div>
        <div class="detail-kv"><span class="detail-key">Environment</span><span class="detail-val">${escapeHtml(run.environment || "—")}</span></div>
        <div class="detail-kv"><span class="detail-key">Started</span><span class="detail-val">${escapeHtml(started)}</span></div>
        <div class="detail-kv"><span class="detail-key">Finished</span><span class="detail-val">${escapeHtml(finished)}</span></div>
        <div class="detail-kv"><span class="detail-key">Duration</span><span class="detail-val">${escapeHtml(duration)}</span></div>
        <div class="detail-kv"><span class="detail-key">Steps</span><span class="detail-val">${run.steps.length}</span></div>
        ${models.length ? `<div class="detail-kv"><span class="detail-key">Models</span><span class="detail-val">${models.map(escapeHtml).join(", ")}</span></div>` : ""}
        ${tools.length ? `<div class="detail-kv"><span class="detail-key">Tools</span><span class="detail-val">${tools.map(escapeHtml).join(", ")}</span></div>` : ""}
        ${datasets.length ? `<div class="detail-kv"><span class="detail-key">Datasets</span><span class="detail-val">${datasets.map(escapeHtml).join(", ")}</span></div>` : ""}
      </div>
    </div>

    <div class="detail-section">
      <h3 class="detail-section-title">Payloads</h3>
      <div class="payload-grid">
        <div>
          <p class="explanation-label">Input</p>
          <pre class="payload-pre">${safeJson(run.input_payload)}</pre>
        </div>
        <div>
          <p class="explanation-label">Output</p>
          <pre class="payload-pre">${safeJson(run.output_payload)}</pre>
        </div>
      </div>
    </div>

    <div class="detail-section">
      <h3 class="detail-section-title">Step Timeline</h3>
      ${renderStepTimeline(run.steps || [])}
    </div>

    ${
      guardrail
        ? `<div class="detail-section"><h3 class="detail-section-title">Guardrails</h3>${renderGuardrailResult(guardrail)}</div>`
        : ""
    }

    ${alertSection}
  `;
}

function openDrawer(html) {
  els.detailBody.innerHTML = html;
  els.detailDrawer.classList.add("open");
  els.detailOverlay.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeDrawer() {
  els.detailDrawer.classList.remove("open");
  els.detailOverlay.classList.remove("open");
  document.body.style.overflow = "";
}

function openSelectedRunDetail() {
  const run = getSelectedRun();
  if (!run) {
    logLine("no selected run to open");
    return;
  }
  openDrawer(renderRunDetail(run, alertForRun(run.run_id)));
}

function workflowNodeKindLabel(nodeType) {
  switch (nodeType) {
    case "run":
      return "Run";
    case "step-llm":
      return "LLM Step";
    case "step-tool":
      return "Tool Step";
    case "decision":
      return "Decision";
    case "action":
      return "Action Route";
    case "functions":
      return "Function Calls";
    case "output":
      return "Outcome";
    default:
      return "Node";
  }
}

function failedGuardrailChecksForRun(runId) {
  const guardrail = guardrailForRun(runId);
  if (!guardrail) return [];
  return (guardrail.checks || []).filter((check) => check.status && check.status !== "pass");
}

function guardrailChecksForNode(node, runId) {
  const checks = failedGuardrailChecksForRun(runId);
  if (!checks.length) return [];

  let stepId = null;
  if (node.type === "step-llm" || node.type === "step-tool" || node.type === "decision" || node.type === "action") {
    stepId = node.raw?.step_id || null;
  } else if (node.type === "functions") {
    stepId = node.raw?.step?.step_id || null;
  }

  if (stepId) {
    const stepChecks = checks.filter((check) => check.step_id === stepId);
    if (stepChecks.length) return stepChecks;
  }

  if (node.type === "run" || node.type === "output") {
    return checks;
  }

  return [];
}

function renderGuardrailMarkers(node, runId) {
  const checks = guardrailChecksForNode(node, runId);
  if (!checks.length) return "";

  const count = checks.length;
  const label = checks[0].status === "error" ? "!" : "×";
  return `
    <div class="guardrail-node-markers">
      <span class="guardrail-node-cross">${label}</span>
      <span class="guardrail-node-count">${count}</span>
    </div>
  `;
}

function buildWorkflowCanvasModel(run, alert) {
  const nodes = [];
  const edges = [];
  const columnWidth = 320;
  const startX = 56;
  const firstStepX = 360;
  const yLevels = {
    top: 94,
    decision: 252,
    action: 402,
    functions: 548,
    run: 252,
  };

  let maxY = 0;

  function addNode(node) {
    const normalized = {
      width: 232,
      height: 118,
      lines: [],
      ...node,
    };
    nodes.push(normalized);
    maxY = Math.max(maxY, normalized.y + normalized.height);
    return normalized;
  }

  const runModels = unique(run.steps.map((step) => step.model));
  addNode({
    id: `run:${run.run_id}`,
    type: "run",
    x: startX,
    y: yLevels.run,
    width: 226,
    height: 126,
    kicker: "Run Ingress",
    title: run.run_id,
    badge: (alert?.severity || run.status || "active").toUpperCase(),
    caption: `${run.agent_name || "agent"} · ${run.environment || "env"}`,
    lines: [
      `${run.steps.length} step(s)`,
      durationForRun(run),
      runModels[0] ? runModels[0] : "No model metadata",
    ],
    raw: run,
  });

  let previousTopId = `run:${run.run_id}`;
  run.steps.forEach((step, index) => {
    const baseX = firstStepX + index * columnWidth;
    const stepNode = addNode({
      id: `step:${step.step_id}`,
      type: step.kind === "llm" ? "step-llm" : "step-tool",
      x: baseX,
      y: yLevels.top,
      width: 238,
      height: 126,
      kicker: `Step ${index + 1}`,
      title: step.name,
      badge: String(step.status || step.kind || "step").toUpperCase(),
      caption: step.kind === "llm" ? step.model || "LLM step" : step.tool_name || "Tool step",
      lines: [
        step.prompt_version ? `Prompt ${step.prompt_version}` : null,
        step.decision_name ? `Decision ${step.decision_name}` : null,
        step.latency_ms != null ? `${step.latency_ms} ms` : null,
      ].filter(Boolean),
      raw: step,
    });

    edges.push({ from: previousTopId, to: stepNode.id, branch: false });
    previousTopId = stepNode.id;
    let branchFrom = stepNode.id;

    if (step.decision_name || step.decision_value) {
      const decisionNode = addNode({
        id: `decision:${step.step_id}`,
        type: "decision",
        x: baseX + 12,
        y: yLevels.decision,
        width: 214,
        height: 112,
        kicker: "Decision",
        title: step.decision_name || "Decision output",
        badge: "ROUTE",
        caption: step.decision_value || "No decision value",
        lines: (step.candidate_actions || []).slice(0, 3).map((candidate) => `Candidate ${candidate}`),
        raw: step,
      });
      edges.push({ from: branchFrom, to: decisionNode.id, branch: true });
      branchFrom = decisionNode.id;
    }

    if (step.selected_action) {
      const actionNode = addNode({
        id: `action:${step.step_id}`,
        type: "action",
        x: baseX + 12,
        y: yLevels.action,
        width: 214,
        height: 106,
        kicker: "Action",
        title: step.selected_action,
        badge: "EXEC",
        caption: step.tool_name ? `Tool ${step.tool_name}` : "Selected route",
        lines: [
          (step.candidate_actions || []).length > 1
            ? `${step.candidate_actions.length - 1} alternate route(s)`
            : "No alternate routes",
        ],
        raw: step,
      });
      edges.push({ from: branchFrom, to: actionNode.id, branch: true });
      branchFrom = actionNode.id;
    }

    if ((step.function_calls || []).length) {
      const functionCalls = step.function_calls || [];
      const functionLines = functionCalls.slice(0, 4).map((call) => {
        const argumentKeys = Object.keys(call.arguments || {});
        return `${call.function_name}(${argumentKeys.join(", ")})`;
      });
      addNode({
        id: `functions:${step.step_id}`,
        type: "functions",
        x: baseX + 12,
        y: yLevels.functions,
        width: 226,
        height: Math.max(116, 100 + Math.min(functionCalls.length, 4) * 20),
        kicker: "Function Calls",
        title: `${functionCalls.length} call${functionCalls.length === 1 ? "" : "s"}`,
        badge: "IO",
        caption: functionCalls[0]?.function_name || "No function metadata",
        lines: functionLines,
        raw: { step, function_calls: functionCalls },
      });
      edges.push({ from: branchFrom, to: `functions:${step.step_id}`, branch: true });
    }
  });

  const outcomeX = run.steps.length ? firstStepX + run.steps.length * columnWidth : firstStepX + columnWidth;
  const outcomeLines = [];
  if (run.output_payload?.decision) outcomeLines.push(`Decision ${run.output_payload.decision}`);
  if (run.output_payload?.confidence != null) outcomeLines.push(`Confidence ${run.output_payload.confidence}`);
  if (alert) outcomeLines.push(`Risk ${Number(alert.risk_score || 0).toFixed(3)}`);
  addNode({
    id: `output:${run.run_id}`,
    type: "output",
    x: outcomeX,
    y: yLevels.run,
    width: 226,
    height: 126,
    kicker: "Run Exit",
    title: run.output_payload?.destination || "Outcome",
    badge: (alert?.severity || run.status || "done").toUpperCase(),
    caption: run.status || "unknown",
    lines: outcomeLines.length ? outcomeLines : ["No output summary"],
    raw: { run, alert },
  });

  edges.push({ from: previousTopId, to: `output:${run.run_id}`, branch: false });

  const layout = workflowLayoutForRun(run.run_id);
  const laidOutNodes = nodes.map((node) => ({ ...node, ...(layout[node.id] || {}) }));

  return {
    runId: run.run_id,
    width: Math.max(outcomeX + 320, 1240),
    height: Math.max(maxY + 140, 760),
    nodes: laidOutNodes,
    edges,
    alert,
  };
}

function pathForEdge(edge, nodeMap) {
  const fromNode = nodeMap.get(edge.from);
  const toNode = nodeMap.get(edge.to);
  if (!fromNode || !toNode) return "";

  const horizontal = Math.abs(fromNode.y - toNode.y) < 60;
  if (horizontal) {
    const x1 = fromNode.x + fromNode.width;
    const y1 = fromNode.y + fromNode.height / 2;
    const x2 = toNode.x;
    const y2 = toNode.y + toNode.height / 2;
    const c1x = x1 + 72;
    const c2x = x2 - 72;
    return `M ${x1} ${y1} C ${c1x} ${y1}, ${c2x} ${y2}, ${x2} ${y2}`;
  }

  const x1 = fromNode.x + fromNode.width / 2;
  const y1 = fromNode.y + fromNode.height;
  const x2 = toNode.x + toNode.width / 2;
  const y2 = toNode.y;
  const c1y = y1 + 38;
  const c2y = y2 - 38;
  return `M ${x1} ${y1} C ${x1} ${c1y}, ${x2} ${c2y}, ${x2} ${y2}`;
}

function renderSvgLinks(svgEl, model, options = {}) {
  const nodeMap = new Map(model.nodes.map((node) => [node.id || node.uuid, node]));
  const arrowId = options.arrowId || "sharedArrow";
  const arrowFill = options.arrowFill || "rgba(141, 199, 255, 0.72)";
  const edges = model.edges || [];
  const focusSet = new Set(options.focusEdgeIds || []);
  const defs = `
    <defs>
      <marker id="${arrowId}" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L0,7 L8,3.5 z" fill="${arrowFill}"></path>
      </marker>
    </defs>
  `;
  const paths = edges
    .map((edge) => {
      const path = pathForEdge(edge, nodeMap);
      const edgeId = edge.id || edge.uuid || `${edge.from}:${edge.to}`;
      const classes = [options.baseClass || "canvas-link"];
      if (edge.branch) classes.push("branch");
      if (focusSet.has(edgeId)) classes.push("focus");
      return `<path class="${classes.join(" ")}" d="${path}" marker-end="url(#${arrowId})"></path>`;
    })
    .join("");

  svgEl.setAttribute("viewBox", `0 0 ${model.width} ${model.height}`);
  svgEl.innerHTML = `${defs}${paths}`;
}

function renderWorkflowCanvasMeta(run, alert) {
  const guardrail = guardrailForRun(run.run_id);
  const tools = unique(run.steps.map((step) => step.tool_name));
  const models = unique(run.steps.map((step) => step.model));
  const badges = [
    `<span class="canvas-metric">run ${escapeHtml(run.run_id)}</span>`,
    `<span class="canvas-metric">${run.steps.length} step(s)</span>`,
    `<span class="canvas-metric">duration ${escapeHtml(durationForRun(run))}</span>`,
    models[0] ? `<span class="canvas-metric">model ${escapeHtml(models.join(", "))}</span>` : "",
    tools.length ? `<span class="canvas-metric">tools ${escapeHtml(tools.join(", "))}</span>` : "",
    alert ? `<span class="canvas-metric">risk ${Number(alert.risk_score || 0).toFixed(3)} · ${escapeHtml(alert.severity)}</span>` : "",
    guardrail
      ? `<span class="canvas-metric ${guardrail.stopped_run ? "canvas-metric-stop" : ""}">guardrails ${escapeHtml(guardrail.verdict || "pass")}</span>`
      : "",
  ]
    .filter(Boolean)
    .join("");

  els.canvasMeta.innerHTML = `
    <div class="canvas-badges">${badges}</div>
    <p class="detail-note">Drag nodes to reorganize the workflow map. Selecting a workflow node syncs the Graphiti entity graph below.</p>
  `;
}

function renderWorkflowInspector() {
  const run = getSelectedRun();
  const model = state.workflowCanvasModel;
  if (!run || !model) {
    els.canvasInspector.innerHTML = `<p class="empty-state">No workflow selected.</p>`;
    return;
  }

  const node = model.nodes.find((candidate) => candidate.id === state.selectedWorkflowNodeId) || model.nodes[0];
  let body = "";
  if (node.type === "run") {
    body = `
      <div class="inspector-card">
        <p class="inspector-label">Run Summary</p>
        <p class="inspector-meta">${escapeHtml(run.agent_name || "agent")} in ${escapeHtml(run.environment || "unknown")} · ${escapeHtml(durationForRun(run))}</p>
        <div class="canvas-badges">
          <span class="canvas-metric">status ${escapeHtml(run.status)}</span>
          <span class="canvas-metric">started ${escapeHtml(formatTimestamp(run.started_at))}</span>
          <span class="canvas-metric">finished ${escapeHtml(formatTimestamp(run.finished_at))}</span>
        </div>
      </div>
      <div class="inspector-card">
        <p class="inspector-label">Payload Snapshot</p>
        <pre>${safeJson({ input_payload: run.input_payload, output_payload: run.output_payload })}</pre>
      </div>
    `;
  } else if (node.type === "functions") {
    body = `
      <div class="inspector-card">
        <p class="inspector-label">Function Calls</p>
        <pre>${safeJson(node.raw.function_calls || [])}</pre>
      </div>
    `;
  } else if (node.type === "output") {
    body = `
      <div class="inspector-card">
        <p class="inspector-label">Outcome Snapshot</p>
        <pre>${safeJson(node.raw)}</pre>
      </div>
    `;
  } else {
    body = `
      <div class="inspector-card">
        <p class="inspector-label">Step Payload</p>
        <pre>${safeJson(node.raw)}</pre>
      </div>
    `;
  }

  els.canvasInspector.innerHTML = `
    <h4>${escapeHtml(node.title)}</h4>
    <p class="inspector-meta">${escapeHtml(workflowNodeKindLabel(node.type))} · ${escapeHtml(node.caption || "No caption")}</p>
    <div class="canvas-badges">
      <span class="canvas-metric">${escapeHtml(node.badge || "node")}</span>
      <span class="canvas-metric">${escapeHtml(node.kicker || "workflow")}</span>
    </div>
    <div class="inspector-grid">${body}</div>
  `;
}

function setWorkflowNodePosition(nodeId, x, y) {
  const model = state.workflowCanvasModel;
  if (!model) return;
  const node = model.nodes.find((candidate) => candidate.id === nodeId);
  if (!node) return;
  node.x = Math.max(24, x);
  node.y = Math.max(24, y);
  workflowLayoutForRun(model.runId)[nodeId] = { x: node.x, y: node.y };
}

function bindMovableNode(element, options) {
  let drag = null;

  element.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    const node = options.getNode();
    if (!node) return;

    drag = {
      startX: event.clientX,
      startY: event.clientY,
      originX: node.x,
      originY: node.y,
      moved: false,
    };

    const handleMove = (moveEvent) => {
      if (!drag) return;
      const dx = moveEvent.clientX - drag.startX;
      const dy = moveEvent.clientY - drag.startY;
      if (!drag.moved && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) {
        drag.moved = true;
      }
      if (!drag.moved) return;

      options.setPosition(drag.originX + dx, drag.originY + dy);
      options.redraw();
    };

    const handleUp = () => {
      if (!drag) return;
      const moved = drag.moved;
      drag = null;
      window.removeEventListener("pointermove", handleMove);
      window.removeEventListener("pointerup", handleUp);
      if (!moved || options.selectAfterDrag) {
        options.onSelect();
      }
    };

    window.addEventListener("pointermove", handleMove);
    window.addEventListener("pointerup", handleUp, { once: true });
    event.preventDefault();
  });
}

function renderWorkflowCanvas() {
  const run = ensureSelectedRun();
  if (!run) {
    els.workflowCanvas.style.width = "100%";
    els.workflowCanvas.style.height = "760px";
    els.workflowCanvasNodes.innerHTML = "";
    els.workflowCanvasLinks.innerHTML = "";
    els.workflowCanvasEmpty.style.display = "grid";
    els.canvasMeta.textContent = "Select a run to render the agent workflow, decisions, and function calls.";
    state.workflowCanvasModel = null;
    renderWorkflowInspector();
    return;
  }

  const alert = alertForRun(run.run_id);
  const model = buildWorkflowCanvasModel(run, alert);
  state.workflowCanvasModel = model;

  if (!model.nodes.some((node) => node.id === state.selectedWorkflowNodeId)) {
    state.selectedWorkflowNodeId = `run:${run.run_id}`;
  }

  els.workflowCanvas.style.width = `${model.width}px`;
  els.workflowCanvas.style.height = `${model.height}px`;
  els.workflowCanvasEmpty.style.display = "none";
  renderWorkflowCanvasMeta(run, alert);
  renderSvgLinks(els.workflowCanvasLinks, model, {
    arrowId: "workflowArrow",
    arrowFill: "rgba(141, 199, 255, 0.72)",
    baseClass: "canvas-link",
  });

  els.workflowCanvasNodes.innerHTML = model.nodes
    .map(
      (node) => `
        <article
          class="canvas-node ${state.selectedWorkflowNodeId === node.id ? "selected" : ""}"
          data-node-id="${escapeHtml(node.id)}"
          data-node-type="${escapeHtml(node.type)}"
          style="left:${node.x}px; top:${node.y}px; width:${node.width}px; height:${node.height}px;"
        >
          <div class="canvas-node-head">
            <p class="canvas-node-kicker">${escapeHtml(node.kicker || "Node")}</p>
            <div class="canvas-node-head-right">
              ${renderGuardrailMarkers(node, model.runId)}
              <span class="canvas-node-badge">${escapeHtml(node.badge || "node")}</span>
            </div>
          </div>
          <h4 class="canvas-node-title">${escapeHtml(node.title)}</h4>
          <p class="canvas-node-caption">${escapeHtml(node.caption || "")}</p>
          <div class="canvas-node-list">${(node.lines || []).map((line) => `<span>${escapeHtml(line)}</span>`).join("")}</div>
        </article>
      `,
    )
    .join("");

  els.workflowCanvasNodes.querySelectorAll(".canvas-node").forEach((element) => {
    const nodeId = element.dataset.nodeId;
    bindMovableNode(element, {
      getNode: () => state.workflowCanvasModel?.nodes.find((node) => node.id === nodeId),
      setPosition: (x, y) => setWorkflowNodePosition(nodeId, x, y),
      redraw: () => {
        renderSvgLinks(els.workflowCanvasLinks, state.workflowCanvasModel, {
          arrowId: "workflowArrow",
          arrowFill: "rgba(141, 199, 255, 0.72)",
          baseClass: "canvas-link",
        });
        const node = state.workflowCanvasModel?.nodes.find((candidate) => candidate.id === nodeId);
        if (node) {
          element.style.left = `${node.x}px`;
          element.style.top = `${node.y}px`;
        }
      },
      onSelect: () => {
        state.selectedWorkflowNodeId = nodeId;
        syncGraphSelectionFromWorkflowNode();
        renderWorkflowCanvas();
        renderGraph();
        logLine(`inspecting workflow node ${nodeId}`);
      },
      selectAfterDrag: true,
    });
  });

  renderWorkflowInspector();
}

function graphKindColumn(kind) {
  if (["Workflow", "GuardrailPolicy", "GuardrailMode"].includes(kind)) return 0;
  if (["Run", "DriftAlert", "GuardrailIncident", "Agent", "Environment", "Status"].includes(kind)) return 1;
  if (["Step", "Decision", "Action", "DriftSignal", "GuardrailViolation"].includes(kind)) return 2;
  return 3;
}

function graphNodeSummary(node) {
  const attrs = node.attributes || {};
  if (node.kind === "Run") {
    return `${attrs.status || "unknown"} · ${attrs.started_at ? formatTimestamp(attrs.started_at) : "run"}`;
  }
  if (node.kind === "Step") {
    return `${attrs.step_kind || "step"} · ${attrs.step_name || node.label}`;
  }
  if (node.kind === "Decision") {
    return `${attrs.decision_name || "decision"} → ${attrs.decision_value || "?"}`;
  }
  if (node.kind === "Action") {
    return attrs.action_name || node.label;
  }
  if (node.kind === "Function") {
    return attrs.function_name || node.label;
  }
  if (node.kind === "FunctionArguments") {
    return attrs.argument_signature || node.label;
  }
  if (node.kind === "Dataset") {
    return `${attrs.dataset_name || node.label}${attrs.dataset_version ? `:${attrs.dataset_version}` : ""}`;
  }
  if (node.kind === "DriftAlert") {
    return `severity ${attrs.severity || "info"} · risk ${attrs.risk_score || 0}`;
  }
  if (node.kind === "GuardrailIncident") {
    return `${attrs.mode || "observe"} · ${attrs.verdict || "pass"}`;
  }
  return Object.entries(attrs)
    .slice(0, 2)
    .map(([key, value]) => `${key}:${value}`)
    .join(" · ") || "Graph entity";
}

function buildGraphModel(graphData) {
  const grouped = new Map();
  graphData.nodes.forEach((node) => {
    const column = graphKindColumn(node.kind);
    if (!grouped.has(column)) grouped.set(column, []);
    grouped.get(column).push(node);
  });
  for (const bucket of grouped.values()) {
    bucket.sort((left, right) => `${left.kind}:${left.label}`.localeCompare(`${right.kind}:${right.label}`));
  }

  const columnX = [64, 336, 620, 910];
  const columnY = [72, 72, 72, 72];
  const layout = graphLayoutForGraph(graphData);
  const nodes = [];

  for (const column of [0, 1, 2, 3]) {
    for (const node of grouped.get(column) || []) {
      const width = column === 3 ? 240 : 228;
      const height = 112;
      const positioned = {
        id: node.uuid,
        uuid: node.uuid,
        kind: node.kind,
        label: node.label,
        attributes: node.attributes || {},
        x: columnX[column],
        y: columnY[column],
        width,
        height,
        summary: graphNodeSummary(node),
      };
      if (layout[node.uuid]) {
        positioned.x = layout[node.uuid].x;
        positioned.y = layout[node.uuid].y;
      }
      nodes.push(positioned);
      columnY[column] += height + 28;
    }
  }

  const maxY = nodes.reduce((max, node) => Math.max(max, node.y + node.height), 720);
  return {
    runId: graphData.run_id,
    workflowId: graphData.workflow_id,
    width: Math.max(1220, ...nodes.map((node) => node.x + node.width + 90)),
    height: Math.max(820, maxY + 120),
    nodes,
    edges: graphData.edges.map((edge) => ({
      id: edge.uuid,
      from: edge.source,
      to: edge.target,
      relation: edge.relation,
      fact: edge.fact,
    })),
  };
}

function workflowNodeToGraphCandidates() {
  const run = getSelectedRun();
  const graphData = state.graphData;
  const model = state.workflowCanvasModel;
  if (!run || !graphData || !model) return graphData?.focus_node_ids || [];

  const selectedNode = model.nodes.find((node) => node.id === state.selectedWorkflowNodeId);
  if (!selectedNode) return graphData.focus_node_ids || [];

  const graphNodes = graphData.nodes || [];
  if (selectedNode.type === "run") {
    return graphNodes
      .filter((node) => node.kind === "Run" && (node.attributes || {}).run_id === run.run_id)
      .map((node) => node.uuid);
  }

  if (selectedNode.type === "step-llm" || selectedNode.type === "step-tool") {
    const stepId = selectedNode.raw?.step_id;
    return graphNodes
      .filter((node) => node.kind === "Step" && (node.attributes || {}).step_id === stepId)
      .map((node) => node.uuid);
  }

  if (selectedNode.type === "decision") {
    const step = selectedNode.raw || {};
    return graphNodes
      .filter(
        (node) =>
          node.kind === "Decision" &&
          (node.attributes || {}).decision_name === step.decision_name &&
          ((node.attributes || {}).decision_value || "") === (step.decision_value || ""),
      )
      .map((node) => node.uuid);
  }

  if (selectedNode.type === "action") {
    const step = selectedNode.raw || {};
    return graphNodes
      .filter((node) => node.kind === "Action" && (node.attributes || {}).action_name === step.selected_action)
      .map((node) => node.uuid);
  }

  if (selectedNode.type === "functions") {
    const calls = (selectedNode.raw?.function_calls || []).map((call) => call.function_name);
    return graphNodes
      .filter((node) => node.kind === "Function" && calls.includes((node.attributes || {}).function_name || node.label))
      .map((node) => node.uuid);
  }

  if (selectedNode.type === "output") {
    const runSpecific = graphNodes
      .filter(
        (node) =>
          ["DriftAlert", "GuardrailIncident"].includes(node.kind) &&
          (node.attributes || {}).run_id === run.run_id,
      )
      .map((node) => node.uuid);
    if (runSpecific.length) return runSpecific;

    return graphNodes
      .filter(
        (node) =>
          node.kind === "Decision" &&
          ((node.attributes || {}).decision_value || "") === (run.output_payload?.decision || ""),
      )
      .map((node) => node.uuid);
  }

  return graphData.focus_node_ids || [];
}

function syncGraphSelectionFromWorkflowNode() {
  if (!state.graphData) {
    state.graphFocusNodeIds = [];
    state.selectedGraphNodeId = null;
    return;
  }

  const matches = workflowNodeToGraphCandidates();
  state.graphFocusNodeIds = matches.length ? matches : state.graphData.focus_node_ids || [];
  if (!state.graphFocusNodeIds.includes(state.selectedGraphNodeId)) {
    state.selectedGraphNodeId =
      state.graphFocusNodeIds[0] || state.graphData.focus_node_ids?.[0] || state.graphData.nodes?.[0]?.uuid || null;
  }
}

function renderGraphMeta(graphData) {
  const runLabel = graphData.run_id ? `run ${graphData.run_id}` : `workflow ${graphData.workflow_id}`;
  const focusText = state.graphFocusNodeIds.length
    ? `${state.graphFocusNodeIds.length} synced focus node${state.graphFocusNodeIds.length === 1 ? "" : "s"}`
    : "No synced focus nodes";
  els.graphMeta.innerHTML = `
    <div class="graph-badges">
      <span class="canvas-metric">${escapeHtml(runLabel)}</span>
      <span class="canvas-metric">${graphData.nodes.length} entities</span>
      <span class="canvas-metric">${graphData.edges.length} relations</span>
      <span class="canvas-metric">${escapeHtml(focusText)}</span>
    </div>
    <p class="detail-note">This is the persisted Graphiti subgraph for the selected run. Drag entities to make the story clearer for demos or client reviews.</p>
  `;
}

function graphFocusEdgeIds() {
  if (!state.graphData) return [];
  const focusSet = new Set(state.graphFocusNodeIds);
  return (state.graphData.edges || [])
    .filter((edge) => focusSet.has(edge.source) || focusSet.has(edge.target))
    .map((edge) => edge.uuid);
}

function setGraphNodePosition(nodeId, x, y) {
  if (!state.graphData) return;
  const layout = graphLayoutForGraph(state.graphData);
  layout[nodeId] = { x: Math.max(30, x), y: Math.max(30, y) };
  const model = state.graphModel;
  if (!model) return;
  const node = model.nodes.find((candidate) => candidate.id === nodeId);
  if (!node) return;
  node.x = layout[nodeId].x;
  node.y = layout[nodeId].y;
}

function renderGraphInspector() {
  const graphData = state.graphData;
  const model = state.graphModel;
  if (!graphData || !model) {
    els.graphInspector.innerHTML = `<p class="empty-state">No Graphiti graph loaded for the selected run.</p>`;
    return;
  }

  const selectedId = state.selectedGraphNodeId || graphData.focus_node_ids?.[0] || graphData.nodes?.[0]?.uuid;
  const node = model.nodes.find((candidate) => candidate.id === selectedId);
  if (!node) {
    els.graphInspector.innerHTML = `<p class="empty-state">No graph entity selected.</p>`;
    return;
  }

  const connectedEdges = (graphData.edges || []).filter(
    (edge) => edge.source === node.uuid || edge.target === node.uuid,
  );
  const edgeCards = connectedEdges.length
    ? connectedEdges
        .slice(0, 8)
        .map(
          (edge) => `
            <div class="inspector-card">
              <p class="inspector-label">${escapeHtml(edge.relation)}</p>
              <p class="inspector-meta">${escapeHtml(edge.fact)}</p>
            </div>
          `,
        )
        .join("")
    : `<div class="inspector-card"><p class="inspector-meta">No connected graph facts for this entity.</p></div>`;

  els.graphInspector.innerHTML = `
    <h4>${escapeHtml(node.label)}</h4>
    <p class="inspector-meta">${escapeHtml(node.kind)} · ${escapeHtml(node.summary)}</p>
    <div class="graph-badges">
      <span class="canvas-metric">uuid ${escapeHtml(node.uuid.slice(0, 8))}</span>
      <span class="canvas-metric">${connectedEdges.length} connected fact${connectedEdges.length === 1 ? "" : "s"}</span>
    </div>
    <div class="inspector-grid">
      <div class="inspector-card">
        <p class="inspector-label">Attributes</p>
        <pre>${safeJson(node.attributes || {})}</pre>
      </div>
      ${edgeCards}
    </div>
  `;
}

function renderGraph() {
  if (!state.graphData || !(state.graphData.nodes || []).length) {
    els.graphSurface.style.width = "100%";
    els.graphSurface.style.height = "780px";
    els.graphNodes.innerHTML = "";
    els.graphLinks.innerHTML = "";
    els.graphEmpty.style.display = "grid";
    els.graphMeta.innerHTML = state.graphError
      ? `<p class="detail-note">Graphiti graph unavailable: ${escapeHtml(state.graphError)}. If you just updated the app, restart the API so the new <code>/graph</code> route is active.</p>`
      : "The Graphiti entity graph will load for the selected run and sync to your workflow node selection.";
    state.graphModel = null;
    renderGraphInspector();
    return;
  }

  const model = buildGraphModel(state.graphData);
  state.graphModel = model;
  if (!model.nodes.some((node) => node.id === state.selectedGraphNodeId)) {
    state.selectedGraphNodeId = state.graphFocusNodeIds[0] || state.graphData.focus_node_ids?.[0] || model.nodes[0]?.id || null;
  }

  els.graphSurface.style.width = `${model.width}px`;
  els.graphSurface.style.height = `${model.height}px`;
  els.graphEmpty.style.display = "none";
  renderGraphMeta(state.graphData);
  renderSvgLinks(els.graphLinks, model, {
    arrowId: "graphArrow",
    arrowFill: "rgba(141, 199, 255, 0.68)",
    baseClass: "graph-link",
    focusEdgeIds: graphFocusEdgeIds(),
  });

  const focusSet = new Set(state.graphFocusNodeIds);
  els.graphNodes.innerHTML = model.nodes
    .map(
      (node) => `
        <article
          class="graph-node ${state.selectedGraphNodeId === node.id ? "selected" : ""} ${focusSet.has(node.id) ? "focused" : ""}"
          data-node-id="${escapeHtml(node.id)}"
          data-kind="${escapeHtml(node.kind)}"
          style="left:${node.x}px; top:${node.y}px; width:${node.width}px; height:${node.height}px;"
        >
          <div class="graph-node-topline">
            <p class="graph-node-kind">${escapeHtml(node.kind)}</p>
            <span class="canvas-node-badge">${escapeHtml(String(Object.keys(node.attributes || {}).length))} fields</span>
          </div>
          <h4 class="graph-node-title">${escapeHtml(node.label)}</h4>
          <p class="graph-node-summary">${escapeHtml(node.summary)}</p>
        </article>
      `,
    )
    .join("");

  els.graphNodes.querySelectorAll(".graph-node").forEach((element) => {
    const nodeId = element.dataset.nodeId;
    bindMovableNode(element, {
      getNode: () => state.graphModel?.nodes.find((node) => node.id === nodeId),
      setPosition: (x, y) => setGraphNodePosition(nodeId, x, y),
      redraw: () => {
        renderSvgLinks(els.graphLinks, state.graphModel, {
          arrowId: "graphArrow",
          arrowFill: "rgba(141, 199, 255, 0.68)",
          baseClass: "graph-link",
          focusEdgeIds: graphFocusEdgeIds(),
        });
        const node = state.graphModel?.nodes.find((candidate) => candidate.id === nodeId);
        if (node) {
          element.style.left = `${node.x}px`;
          element.style.top = `${node.y}px`;
        }
      },
      onSelect: () => {
        state.selectedGraphNodeId = nodeId;
        state.graphFocusNodeIds = [nodeId];
        renderGraph();
        logLine(`inspecting graph entity ${nodeId}`);
      },
      selectAfterDrag: true,
    });
  });

  renderGraphInspector();
}

async function refreshGraphView(options = {}) {
  const { force = false } = options;
  const run = getSelectedRun();
  if (!run) {
    state.graphData = null;
    state.graphError = null;
    state.selectedGraphNodeId = null;
    state.graphFocusNodeIds = [];
    renderGraph();
    return;
  }

  const cacheKey = `${run.tenant_id}:${run.workflow_id}:${run.run_id}`;
  if (!force && state.graphCache[cacheKey]) {
    state.graphData = state.graphCache[cacheKey];
    state.graphError = null;
    syncGraphSelectionFromWorkflowNode();
    renderGraph();
    return;
  }

  try {
    const graphData = await apiRequest(
      `/workflows/${encodeURIComponent(run.tenant_id)}/${encodeURIComponent(run.workflow_id)}/graph?run_id=${encodeURIComponent(run.run_id)}&limit=400`,
    );
    state.graphCache[cacheKey] = graphData;
    state.graphData = graphData;
    state.graphError = null;
    syncGraphSelectionFromWorkflowNode();
    renderGraph();
    logLine(`loaded Graphiti graph for ${run.run_id} with ${graphData.nodes.length} nodes`);
  } catch (error) {
    state.graphData = null;
    state.graphError = error.message;
    state.selectedGraphNodeId = null;
    state.graphFocusNodeIds = [];
    renderGraph();
    logLine(`graph load failed: ${error.message}`);
  }
}

function centerNodeInScroller(scroller, selector) {
  const element = selector;
  if (!scroller || !element) return;
  const targetLeft = element.offsetLeft - scroller.clientWidth / 2 + element.clientWidth / 2;
  const targetTop = element.offsetTop - scroller.clientHeight / 2 + element.clientHeight / 2;
  scroller.scrollTo({
    left: Math.max(0, targetLeft),
    top: Math.max(0, targetTop),
    behavior: "smooth",
  });
}

function centerGraphOnSelection() {
  if (!state.selectedGraphNodeId) return;
  const element = els.graphNodes.querySelector(`[data-node-id="${CSS.escape(state.selectedGraphNodeId)}"]`);
  centerNodeInScroller(els.graphCanvasScroll, element);
}

async function selectRun(runId, options = {}) {
  const { open = true, source = "history" } = options;
  const run = findRun(runId);
  if (!run) return;

  state.selectedRunId = run.run_id;
  state.selectedWorkflowNodeId = `run:${run.run_id}`;
  state.selectedGraphNodeId = null;
  state.graphFocusNodeIds = [];

  renderHistory();
  renderWorkflowCanvas();
  renderGuardrailPage();
  await refreshGraphView();

  if (open) {
    openDrawer(renderRunDetail(run, alertForRun(run.run_id)));
  }

  logLine(`selected run ${run.run_id} from ${source}`);
}

async function selectAlert(runId) {
  const alert = alertForRun(runId);
  if (!alert) return;

  state.selectedRunId = runId;
  state.selectedWorkflowNodeId = `run:${runId}`;
  state.selectedGraphNodeId = null;
  state.graphFocusNodeIds = [];

  renderHistory();
  renderWorkflowCanvas();
  renderGuardrailPage();
  await refreshGraphView();

  const run = findRun(runId);
  if (run) {
    openDrawer(renderRunDetail(run, alert));
  } else {
    const signalDetails = (alert.signals || [])
      .map(
        (signal) => `
          <div class="signal-detail-card">
            <div class="signal-detail-header">
              <span class="signal-detail-kind">${escapeHtml(signal.kind)}</span>
              <span class="signal-detail-score severity-pill-${signal.severity}">${escapeHtml(signal.severity)} · ${Number(signal.score || 0).toFixed(2)}</span>
            </div>
            <p class="signal-detail-summary">${escapeHtml(signal.summary || "No summary stored.")}</p>
            ${signal.recommended_actions?.length ? `<ul class="signal-actions">${signal.recommended_actions.map((action) => `<li>${escapeHtml(action)}</li>`).join("")}</ul>` : ""}
          </div>
        `,
      )
      .join("");

    openDrawer(`
      <div class="detail-header-bar ${severityClass(alert.severity)}">
        <h2 class="detail-run-id">${escapeHtml(alert.run_id)}</h2>
        <span class="item-pill">${escapeHtml(alert.severity)}</span>
      </div>
      <div class="detail-section">
        <h3 class="detail-section-title">Alert Details</h3>
        <div class="detail-kv"><span class="detail-key">Risk Score</span><span class="detail-val">${Number(alert.risk_score || 0).toFixed(3)}</span></div>
        ${signalDetails}
        ${alert.recommendation_summary ? `<div class="recommendation-box"><p class="recommendation-label">Recommendation</p><p>${escapeHtml(alert.recommendation_summary)}</p></div>` : ""}
      </div>
      ${(alert.graph_explanations || []).length ? `<div class="detail-section"><h3 class="detail-section-title">Graph Explanations</h3>${renderGraphExplanations(alert.graph_explanations)}</div>` : ""}
    `);
  }

  logLine(`inspecting alert for ${runId}`);
}

function renderHistory() {
  if (!state.history.length && !state.latestObservation?.run) {
    els.historyList.innerHTML = `<p class="empty-state">No stored runs yet. Seed the demo scenario or submit a payload to build the workflow ledger.</p>`;
    return;
  }

  const runs = knownRuns();
  els.historyList.innerHTML = runs
    .map((run) => {
      const alert = alertForRun(run.run_id);
      const guardrail = guardrailForRun(run.run_id);
      const severity =
        guardrail?.stopped_run ? "critical" : guardrail?.verdict === "warn" ? "high" : alert ? alert.severity : "info";
      const started = formatTimestamp(run.started_at);
      const stepCount = run.steps.length;
      const models = unique(run.steps.map((step) => step.model));
      const selected = state.selectedRunId === run.run_id;
      return `
        <article class="history-item clickable ${severityClass(severity)} ${selected ? "selected" : ""}" data-run-id="${escapeHtml(run.run_id)}">
          <div class="item-row">
            <div>
              <p class="item-title">${escapeHtml(run.run_id)}</p>
              <p class="item-subtitle">${escapeHtml(run.agent_name || "agent")} · ${escapeHtml(started)}</p>
            </div>
            <div class="item-row-right">
              ${
                guardrail?.stopped_run
                  ? '<span class="history-guardrail-cross" title="workflow stopped by guardrails">×</span>'
                  : ""
              }
              <span class="item-pill">${escapeHtml(guardrail ? guardrail.verdict : alert ? severity : run.status)}</span>
              <span class="item-chevron">›</span>
            </div>
          </div>
          <p class="item-meta">${stepCount} step(s) · ${escapeHtml(models.join(", ") || "No model metadata")}</p>
          ${guardrail?.checks?.length ? `<div class="signals">${guardrail.checks.slice(0, 3).map((check) => `<span class="signal-chip">${escapeHtml(check.status === "pass" ? `✓ ${check.guardrail_id}` : `× ${check.guardrail_id}`)}</span>`).join("")}</div>` : alert ? `<div class="signals">${(alert.signals || []).slice(0, 4).map((signal) => `<span class="signal-chip">${escapeHtml(signal.kind)}</span>`).join("")}${(alert.signals || []).length > 4 ? `<span class="signal-chip">+${(alert.signals || []).length - 4} more</span>` : ""}</div>` : ""}
        </article>
      `;
    })
    .join("");

  els.historyList.querySelectorAll(".history-item.clickable").forEach((element) => {
    element.addEventListener("click", () => {
      void selectRun(element.dataset.runId, { open: true, source: "history" });
    });
  });
}

function renderAlerts() {
  if (!state.alerts.length && !state.latestObservation) {
    els.alertsList.innerHTML = `<p class="empty-state">No drift alerts stored for this workflow yet.</p>`;
    return;
  }

  const alerts = [...state.alerts];
  const latestAlert = alertSnapshotForObservation(state.latestObservation);
  if (latestAlert && !alerts.some((alert) => alert.run_id === latestAlert.run_id)) {
    alerts.unshift(latestAlert);
  }

  if (!alerts.length) {
    els.alertsList.innerHTML = `<p class="empty-state">No drift alerts stored for this workflow yet.</p>`;
    return;
  }

  els.alertsList.innerHTML = alerts
    .map((alert) => {
      const signalChips = (alert.signals || [])
        .map((signal) => `<span class="signal-chip">${escapeHtml(signal.kind)}</span>`)
        .join("");
      const observedAt = formatTimestamp(alert.observed_at);
      const explanationCount = (alert.graph_explanations || []).length;
      return `
        <article class="alert-item clickable ${severityClass(alert.severity)}" data-run-id="${escapeHtml(alert.run_id)}">
          <div class="item-row">
            <div>
              <p class="item-title">${escapeHtml(alert.run_id)}</p>
              <p class="item-subtitle">${escapeHtml(observedAt)}</p>
            </div>
            <div class="item-row-right">
              <span class="item-pill">${escapeHtml(alert.severity)}</span>
              <span class="item-chevron">›</span>
            </div>
          </div>
          <p class="item-meta">risk ${Number(alert.risk_score || 0).toFixed(3)} · ${explanationCount} explanation${explanationCount === 1 ? "" : "s"}</p>
          <div class="signals">${signalChips || '<span class="signal-chip">no signals</span>'}</div>
          <p class="item-meta">${escapeHtml(alert.recommendation_summary || "Click to inspect drift evidence.")}</p>
        </article>
      `;
    })
    .join("");

  els.alertsList.querySelectorAll(".alert-item.clickable").forEach((element) => {
    element.addEventListener("click", () => {
      void selectAlert(element.dataset.runId);
    });
  });
}

function renderLatestObservation() {
  const latest = state.latestObservation;
  if (!latest) {
    els.latestSummary.innerHTML = `<p class="empty-state">No observation selected yet. Run the demo scenario or post a payload.</p>`;
    return;
  }

  const signalChips = (latest.signals || [])
    .map((signal) => `<span class="signal-chip">${escapeHtml(signal.kind)}</span>`)
    .join("");
  const explanations = renderGraphExplanations(latest.graph_explanations || []);
  const guardrails = renderGuardrailResult(latest.guardrail_result);

  els.latestSummary.innerHTML = `
    <article class="summary-card clickable ${severityClass(latest.severity)}" data-run-id="${escapeHtml(latest.run.run_id)}">
      <div class="item-row">
        <div>
          <p class="item-title">${escapeHtml(latest.run.run_id)}</p>
          <p class="item-subtitle">${escapeHtml(latest.run.workflow_id)} · baseline ${latest.baseline_run_count}</p>
        </div>
        <div class="item-row-right">
          <span class="item-pill">${escapeHtml(latest.severity)}</span>
          <span class="item-chevron">›</span>
        </div>
      </div>
      <p class="item-meta">risk ${Number(latest.risk_score || 0).toFixed(3)}</p>
      <div class="signals">${signalChips || '<span class="signal-chip">no active drift</span>'}</div>
      <p class="item-meta">${escapeHtml(latest.recommendation_summary || "No mitigation summary generated.")}</p>
    </article>
    ${guardrails}
    ${explanations}
  `;

  els.latestSummary.querySelectorAll(".summary-card.clickable").forEach((element) => {
    element.addEventListener("click", () => {
      void selectRun(element.dataset.runId, { open: true, source: "latest" });
    });
  });
}

function renderFacts() {
  if (!state.facts.length) {
    els.factsList.innerHTML = `<p class="empty-state">No facts returned for the current query.</p>`;
    return;
  }

  els.factsList.innerHTML = state.facts
    .map((fact) => `<article class="fact-item">${escapeHtml(fact)}</article>`)
    .join("");
}

function renderGuardrailPolicySummary() {
  if (!els.guardrailPolicySummary) return;
  const policy = state.guardrailPolicy;
  if (!policy) {
    els.guardrailPolicySummary.innerHTML = `<p class="empty-state">No persisted guardrail policy for this workflow yet. Use the operator drawer or demo seed to attach one.</p>`;
    return;
  }

  const runtimeFns = policy.runtime_function_guardrails || [];
  const naturalLanguage = policy.natural_language_guardrails || [];
  const chips = [
    `<span class="canvas-metric">mode ${escapeHtml(policy.mode)}</span>`,
    `<span class="canvas-metric">${runtimeFns.length} runtime function guardrail${runtimeFns.length === 1 ? "" : "s"}</span>`,
    `<span class="canvas-metric">${naturalLanguage.length} natural-language guardrail${naturalLanguage.length === 1 ? "" : "s"}</span>`,
    policy.max_step_count != null ? `<span class="canvas-metric">max steps ${policy.max_step_count}</span>` : "",
    policy.max_latency_ms != null ? `<span class="canvas-metric">max latency ${policy.max_latency_ms} ms</span>` : "",
  ]
    .filter(Boolean)
    .join("");

  const staticRules = [
    ["Allowed Actions", (policy.allowed_actions || []).join(", ") || "—"],
    ["Allowed Functions", (policy.allowed_functions || []).join(", ") || "—"],
    ["Allowed Models", (policy.allowed_models || []).join(", ") || "—"],
    ["Allowed Prompts", (policy.allowed_prompts || []).join(", ") || "—"],
    ["Allowed Tools", (policy.allowed_tools || []).join(", ") || "—"],
  ];

  els.guardrailPolicySummary.innerHTML = `
    <div class="canvas-badges">${chips}</div>
    <div class="guardrail-policy-grid">
      <div class="inspector-card">
        <p class="inspector-label">Static Envelope</p>
        <div class="policy-rule-list">
          ${staticRules
            .map(
              ([label, value]) => `
                <div class="detail-kv">
                  <span class="detail-key">${escapeHtml(label)}</span>
                  <span class="detail-val">${escapeHtml(value)}</span>
                </div>
              `,
            )
            .join("")}
        </div>
      </div>
      <div class="inspector-card">
        <p class="inspector-label">Executable Function Guardrails</p>
        ${
          runtimeFns.length
            ? runtimeFns
                .map(
                  (guardrail) => `
                    <div class="policy-guardrail-card">
                      <p class="item-title">${escapeHtml(guardrail.title || guardrail.guardrail_id)}</p>
                      <p class="item-meta">${escapeHtml(guardrail.function_name)}</p>
                      <p class="item-meta">${escapeHtml(guardrail.description || "No description stored.")}</p>
                    </div>
                  `,
                )
                .join("")
            : '<p class="empty-state">No executable function guardrails configured.</p>'
        }
      </div>
      <div class="inspector-card">
        <p class="inspector-label">Natural-Language Guardrails</p>
        ${
          naturalLanguage.length
            ? naturalLanguage
                .map(
                  (guardrail) => `
                    <div class="policy-guardrail-card">
                      <p class="item-title">${escapeHtml(guardrail.title || guardrail.guardrail_id)}</p>
                      <p class="item-meta">${escapeHtml(guardrail.instruction)}</p>
                    </div>
                  `,
                )
                .join("")
            : '<p class="empty-state">No natural-language guardrails configured.</p>'
        }
      </div>
    </div>
  `;
}

function renderGuardrailIncidentList() {
  if (!els.guardrailIncidentList) return;
  const incidents = [...state.guardrailIncidents];
  const latest = guardrailSnapshotForObservation(state.latestObservation);
  if (latest && !incidents.some((incident) => incident.run_id === latest.run_id)) {
    incidents.unshift(latest);
  }

  if (!incidents.length) {
    els.guardrailIncidentList.innerHTML = `<p class="empty-state">No guardrail incidents recorded for this workflow yet.</p>`;
    return;
  }

  els.guardrailIncidentList.innerHTML = incidents
    .map((incident) => {
      const checks = incident.checks || [];
      const cross = incident.stopped_run ? '<span class="history-guardrail-cross">×</span>' : "";
      return `
        <article class="alert-item clickable ${severityClass(incident.stopped_run ? "critical" : incident.verdict === "warn" ? "high" : "low")}" data-run-id="${escapeHtml(incident.run_id)}">
          <div class="item-row">
            <div>
              <p class="item-title">${escapeHtml(incident.run_id)}</p>
              <p class="item-subtitle">policy ${escapeHtml(incident.policy_id || "none")} · ${escapeHtml(formatTimestamp(incident.observed_at))}</p>
            </div>
            <div class="item-row-right">
              ${cross}
              <span class="item-pill">${escapeHtml(incident.verdict)}</span>
              <span class="item-chevron">›</span>
            </div>
          </div>
          <p class="item-meta">${checks.length} check${checks.length === 1 ? "" : "s"} · ${(incident.violations || []).length} violation${(incident.violations || []).length === 1 ? "" : "s"}</p>
          <div class="signals">
            ${
              checks.length
                ? checks
                    .slice(0, 3)
                    .map(
                      (check) =>
                        `<span class="signal-chip">${escapeHtml(check.status === "pass" ? `✓ ${check.guardrail_id}` : `× ${check.guardrail_id}`)}</span>`,
                    )
                    .join("")
                : '<span class="signal-chip">no checks</span>'
            }
          </div>
          ${
            incident.stop_reason
              ? `<p class="item-meta">${escapeHtml(incident.stop_reason)}</p>`
              : ""
          }
        </article>
      `;
    })
    .join("");

  els.guardrailIncidentList.querySelectorAll(".alert-item.clickable").forEach((element) => {
    element.addEventListener("click", () => {
      void selectRun(element.dataset.runId, { open: true, source: "guardrails" });
    });
  });
}

function renderGuardrailPage() {
  renderGuardrailPolicySummary();
  renderGuardrailIncidentList();
  if (!els.guardrailPageContent) return;
  const selectedRunId = state.selectedRunId || state.latestObservation?.run?.run_id || null;
  const selectedIncident = guardrailForRun(selectedRunId);
  const latest =
    selectedIncident && state.latestObservation?.run?.run_id === selectedIncident.run_id
      ? state.latestObservation?.guardrail_result
      : selectedIncident;
  els.guardrailPageContent.innerHTML = latest
    ? renderGuardrailResult(latest)
    : `<p class="empty-state">No live guardrail evaluation available yet. Run the demo or observe a payload.</p>`;
}

async function refreshHealth() {
  try {
    state.health = await apiRequest("/health");
    renderHealth();
    logLine(`health check ok: ${state.health.graph_backend} / ${state.health.mlx_model}`);
  } catch (error) {
    els.runtimeStatus.textContent = "API Error";
    els.statusOrb.classList.add("error");
    els.statusOrb.classList.remove("online");
    logLine(`health check failed: ${error.message}`);
  }
}

async function refreshWorkflowViews() {
  const tenant = els.tenantInput.value.trim();
  const workflow = els.workflowInput.value.trim();
  const factsQuery = encodeURIComponent(els.factsQueryInput.value.trim());

  if (!tenant || !workflow) {
    logLine("tenant and workflow are required");
    return;
  }

  try {
    const [experiments, history, alerts, guardrailIncidents, facts, guardrailPolicy] = await Promise.all([
      apiRequest(`/tenants/${encodeURIComponent(tenant)}/experiments?limit=12`),
      apiRequest(`/workflows/${encodeURIComponent(tenant)}/${encodeURIComponent(workflow)}/history?limit=12`),
      apiRequest(`/workflows/${encodeURIComponent(tenant)}/${encodeURIComponent(workflow)}/alerts?limit=8`),
      apiRequest(
        `/workflows/${encodeURIComponent(tenant)}/${encodeURIComponent(workflow)}/guardrails/incidents?limit=8`,
      ),
      apiRequest(`/facts?tenant_id=${encodeURIComponent(tenant)}&query=${factsQuery}&limit=8`),
      apiRequest(`/workflows/${encodeURIComponent(tenant)}/${encodeURIComponent(workflow)}/guardrails/policy`).catch(
        () => null,
      ),
    ]);

    state.experiments = experiments;
    state.history = history;
    state.alerts = alerts;
    state.guardrailIncidents = guardrailIncidents;
    state.guardrailPolicy = guardrailPolicy;
    state.facts = facts.facts || [];

    ensureSelectedRun();
    renderExperiments();
    renderHistory();
    renderAlerts();
    renderFacts();
    renderLatestObservation();
    renderGuardrailPage();
    renderMetrics();
    renderWorkflowCanvas();
    await refreshGraphView();
    logLine(`refreshed dashboard for ${tenant}/${workflow}`);
  } catch (error) {
    logLine(`refresh failed: ${error.message}`);
  }
}

async function seedDemo() {
  const tenant = els.tenantInput.value.trim();
  const workflow = els.workflowInput.value.trim();
  logLine(`seeding demo scenario for ${tenant}/${workflow}`);
  els.seedDemoButton.disabled = true;
  els.seedDemoButton.textContent = "Seeding…";

  try {
    const results = await apiRequest("/demo/seed", {
      method: "POST",
      body: JSON.stringify({
        tenant_id: tenant,
        workflow_id: workflow,
        environment: "dev",
      }),
    });

    state.latestObservation = results[results.length - 1] || null;
    if (state.latestObservation?.run) {
      state.selectedRunId = state.latestObservation.run.run_id;
      state.selectedWorkflowNodeId = `run:${state.latestObservation.run.run_id}`;
      state.graphCache = {};
    }
    renderLatestObservation();
    renderGuardrailPage();
    renderMetrics();
    renderWorkflowCanvas();
    await refreshWorkflowViews();
    logLine(`demo scenario completed with ${results.length} observations`);
  } catch (error) {
    logLine(`demo scenario failed: ${error.message}`);
  } finally {
    els.seedDemoButton.disabled = false;
    els.seedDemoButton.textContent = "Run Demo Scenario";
  }
}

async function observePayload() {
  try {
    const payload = JSON.parse(els.payloadEditor.value);
    els.observeButton.disabled = true;
    els.observeButton.textContent = "Observing…";
    const result = await apiRequest("/observe", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    state.latestObservation = result;
    if (result?.run) {
      state.selectedRunId = result.run.run_id;
      state.selectedWorkflowNodeId = `run:${result.run.run_id}`;
      state.graphCache = {};
    }
    renderLatestObservation();
    renderGuardrailPage();
    renderMetrics();
    renderWorkflowCanvas();
    await refreshWorkflowViews();
    logLine(`observed payload ${result.run.run_id} with severity ${result.severity}`);
  } catch (error) {
    logLine(`observe failed: ${error.message}`);
  } finally {
    els.observeButton.disabled = false;
    els.observeButton.textContent = "Observe Payload";
  }
}

function loadSamplePayload() {
  els.payloadEditor.value = JSON.stringify(samplePayload(), null, 2);
  logLine("sample payload loaded into editor");
}

async function focusLatestRun() {
  const latestRun = state.latestObservation?.run || state.history[0];
  if (!latestRun) {
    logLine("no run available to focus");
    return;
  }

  setActivePage("canvas");
  await selectRun(latestRun.run_id, { open: false, source: "focus" });
  const nodeElement = els.workflowCanvasNodes.querySelector(`[data-node-id="${CSS.escape(`run:${latestRun.run_id}`)}"]`);
  centerNodeInScroller(els.workflowCanvasScroll, nodeElement);
  centerGraphOnSelection();
}

async function reloadGraph() {
  await refreshGraphView({ force: true });
}

function bindEvents() {
  els.apiKeyInput.addEventListener("input", (event) => {
    state.apiKey = event.target.value.trim();
  });
  els.tenantInput.addEventListener("input", updateScopeChips);
  els.workflowInput.addEventListener("input", updateScopeChips);
  els.appPageButtons.forEach((button) => {
    button.addEventListener("click", () => setActivePage(button.dataset.appPage));
  });
  els.toggleControlsButton.addEventListener("click", () => toggleUiFlag("showControls"));
  els.toggleMetricsButton.addEventListener("click", () => toggleUiFlag("showMetrics"));
  els.toggleSecondaryButton.addEventListener("click", () => toggleUiFlag("showSecondary"));
  els.workflowViewButtons.forEach((button) => {
    button.addEventListener("click", () => setUiView("workflowView", button.dataset.workflowView));
  });
  els.graphViewButtons.forEach((button) => {
    button.addEventListener("click", () => setUiView("graphView", button.dataset.graphView));
  });
  els.dockTabButtons.forEach((button) => {
    button.addEventListener("click", () => setDockTab(button.dataset.dockTab));
  });
  els.seedDemoButton.addEventListener("click", seedDemo);
  els.refreshButton.addEventListener("click", refreshWorkflowViews);
  els.loadSampleButton.addEventListener("click", loadSamplePayload);
  els.observeButton.addEventListener("click", observePayload);
  els.focusLatestButton.addEventListener("click", () => {
    void focusLatestRun();
  });
  els.openSelectedButton.addEventListener("click", openSelectedRunDetail);
  els.reloadGraphButton.addEventListener("click", () => {
    void reloadGraph();
  });
  els.centerGraphButton.addEventListener("click", centerGraphOnSelection);
  els.controlOverlay.addEventListener("click", () => {
    if (!state.ui.showControls) return;
    toggleUiFlag("showControls");
  });
  els.detailClose.addEventListener("click", closeDrawer);
  els.detailOverlay.addEventListener("click", closeDrawer);
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (els.detailDrawer.classList.contains("open")) {
      closeDrawer();
      return;
    }
    if (state.ui.showControls) {
      toggleUiFlag("showControls");
    }
  });
  window.addEventListener("hashchange", () => {
    if (loadPageFromLocation()) {
      persistUiState();
      applyUiState();
    }
  });
}

async function boot() {
  loadUiState();
  loadPageFromLocation();
  bindEvents();
  updateScopeChips();
  loadSamplePayload();
  applyUiState();
  renderExperiments();
  renderWorkflowCanvas();
  renderGraph();
  renderGuardrailPage();
  await refreshHealth();
  await refreshWorkflowViews();
  renderLatestObservation();
  renderGuardrailPage();
  renderMetrics();
  renderWorkflowCanvas();
  renderGraph();
}

boot();
