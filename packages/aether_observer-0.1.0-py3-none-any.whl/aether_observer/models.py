from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class StepKind(str, Enum):
    llm = "llm"
    tool = "tool"
    retrieval = "retrieval"
    handoff = "handoff"
    guardrail = "guardrail"
    system = "system"
    other = "other"


class RunStatus(str, Enum):
    success = "success"
    warning = "warning"
    failed = "failed"


class DriftType(str, Enum):
    data = "data_drift"
    agentic = "agentic_drift"
    operational = "operational_regression"


class Severity(str, Enum):
    info = "info"
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class GuardrailMode(str, Enum):
    observe = "observe"
    warn = "warn"
    block = "block"


class GuardrailVerdict(str, Enum):
    pass_ = "pass"
    warn = "warn"
    block = "block"


class GuardrailCheckStatus(str, Enum):
    pass_ = "pass"
    fail = "fail"
    error = "error"


class WorkflowDataset(BaseModel):
    name: str
    version: str | None = None
    schema_hash: str | None = None
    freshness_at: datetime | None = None
    row_count: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class FunctionCall(BaseModel):
    call_id: str | None = None
    function_name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    result: Any = None
    status: RunStatus = RunStatus.success
    latency_ms: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkflowStep(BaseModel):
    step_id: str
    name: str
    kind: StepKind = StepKind.other
    status: RunStatus = RunStatus.success
    model: str | None = None
    prompt_name: str | None = None
    prompt_version: str | None = None
    prompt_text: str | None = None
    decision_name: str | None = None
    decision_value: str | None = None
    selected_action: str | None = None
    candidate_actions: list[str] = Field(default_factory=list)
    tool_name: str | None = None
    function_calls: list[FunctionCall] = Field(default_factory=list)
    input_payload: Any = None
    output_payload: Any = None
    datasets: list[WorkflowDataset] = Field(default_factory=list)
    latency_ms: int | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkflowRun(BaseModel):
    tenant_id: str
    workflow_id: str
    run_id: str
    agent_name: str
    environment: str = "dev"
    workflow_version: str | None = None
    status: RunStatus = RunStatus.success
    started_at: datetime
    finished_at: datetime | None = None
    input_payload: Any = None
    output_payload: Any = None
    datasets: list[WorkflowDataset] = Field(default_factory=list)
    steps: list[WorkflowStep] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class DriftSignal(BaseModel):
    drift_type: DriftType
    kind: str
    severity: Severity
    score: float
    title: str
    summary: str
    evidence: dict[str, Any] = Field(default_factory=dict)
    recommended_actions: list[str] = Field(default_factory=list)


class DriftAssessment(BaseModel):
    baseline_run_count: int
    risk_score: float
    severity: Severity
    signals: list[DriftSignal] = Field(default_factory=list)


class GraphDriftPolicy(BaseModel):
    policy_id: str | None = None
    enabled: bool = True
    warmup_runs: int = 3
    min_score: float = 0.35
    stop_on_drift: bool = True
    signal_kinds: list[str] = Field(
        default_factory=lambda: [
            "graph_topology_drift",
            "graph_motif_drift",
            "missing_expected_relation",
            "new_relation_drift",
        ]
    )
    metadata: dict[str, Any] = Field(default_factory=dict)


class DynamicBaselineConfig(BaseModel):
    decisions_from_history: bool = False
    actions_from_history: bool = False
    functions_from_history: bool = False
    models_from_history: bool = False
    prompts_from_history: bool = False
    tools_from_history: bool = False
    datasets_from_history: bool = False


class FunctionContract(BaseModel):
    required_keys: list[str] = Field(default_factory=list)
    allowed_keys: list[str] = Field(default_factory=list)
    blocked_keys: list[str] = Field(default_factory=list)
    allow_additional_keys: bool = True


class RuntimeFunctionGuardrail(BaseModel):
    guardrail_id: str
    function_name: str
    title: str | None = None
    description: str | None = None
    stop_on_failure: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)


class NaturalLanguageGuardrail(BaseModel):
    guardrail_id: str
    instruction: str
    title: str | None = None
    stop_on_failure: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)


class DynamicGuardrailPolicy(BaseModel):
    policy_id: str
    tenant_id: str
    workflow_id: str
    enabled: bool = True
    mode: GuardrailMode = GuardrailMode.warn
    allowed_decisions: list[str] = Field(default_factory=list)
    allowed_actions: list[str] = Field(default_factory=list)
    blocked_actions: list[str] = Field(default_factory=list)
    require_approval_actions: list[str] = Field(default_factory=list)
    allowed_functions: list[str] = Field(default_factory=list)
    blocked_functions: list[str] = Field(default_factory=list)
    function_contracts: dict[str, FunctionContract] = Field(default_factory=dict)
    allowed_models: list[str] = Field(default_factory=list)
    allowed_prompts: list[str] = Field(default_factory=list)
    allowed_tools: list[str] = Field(default_factory=list)
    dataset_version_policies: dict[str, list[str]] = Field(default_factory=dict)
    max_step_count: int | None = None
    max_latency_ms: int | None = None
    runtime_function_guardrails: list[RuntimeFunctionGuardrail] = Field(default_factory=list)
    natural_language_guardrails: list[NaturalLanguageGuardrail] = Field(default_factory=list)
    dynamic_baseline: DynamicBaselineConfig = Field(default_factory=DynamicBaselineConfig)
    metadata: dict[str, Any] = Field(default_factory=dict)


class GuardrailViolation(BaseModel):
    policy_id: str
    kind: str
    severity: Severity
    mode: GuardrailMode
    title: str
    summary: str
    step_id: str | None = None
    score: float = 1.0
    evidence: dict[str, Any] = Field(default_factory=dict)
    recommended_actions: list[str] = Field(default_factory=list)


class GuardrailCheckResult(BaseModel):
    guardrail_id: str
    kind: str
    status: GuardrailCheckStatus = GuardrailCheckStatus.pass_
    title: str
    summary: str
    stop_workflow: bool = False
    step_id: str | None = None
    evidence: dict[str, Any] = Field(default_factory=dict)
    recommended_actions: list[str] = Field(default_factory=list)


class GuardrailFunctionResult(BaseModel):
    passed: bool
    summary: str | None = None
    step_id: str | None = None
    evidence: dict[str, Any] = Field(default_factory=dict)
    recommended_actions: list[str] = Field(default_factory=list)


class GuardrailExplanation(BaseModel):
    policy_id: str
    violation_kind: str
    title: str
    summary: str
    current_state: list[str] = Field(default_factory=list)
    expected_state: list[str] = Field(default_factory=list)
    graph_facts: list[str] = Field(default_factory=list)


class GuardrailEvaluation(BaseModel):
    policy_id: str | None = None
    mode: GuardrailMode = GuardrailMode.observe
    verdict: GuardrailVerdict = GuardrailVerdict.pass_
    checks: list[GuardrailCheckResult] = Field(default_factory=list)
    violations: list[GuardrailViolation] = Field(default_factory=list)
    graph_explanations: list[GuardrailExplanation] = Field(default_factory=list)
    stopped_run: bool = False
    stop_reason: str | None = None


class StoredGuardrailIncident(BaseModel):
    tenant_id: str
    workflow_id: str
    run_id: str
    observed_at: datetime
    policy_id: str
    mode: GuardrailMode
    verdict: GuardrailVerdict
    checks: list[GuardrailCheckResult] = Field(default_factory=list)
    violations: list[GuardrailViolation] = Field(default_factory=list)
    graph_explanations: list[GuardrailExplanation] = Field(default_factory=list)
    stopped_run: bool = False
    stop_reason: str | None = None


class GraphExplanation(BaseModel):
    signal_kind: str
    title: str
    summary: str
    current_state: list[str] = Field(default_factory=list)
    baseline_state: list[str] = Field(default_factory=list)
    graph_facts: list[str] = Field(default_factory=list)


class ObservationResult(BaseModel):
    run: WorkflowRun
    baseline_run_count: int
    risk_score: float
    severity: Severity
    signals: list[DriftSignal] = Field(default_factory=list)
    guardrail_result: GuardrailEvaluation | None = None
    stored_run_episode_uuid: str | None = None
    stored_drift_episode_uuid: str | None = None
    stored_guardrail_episode_uuid: str | None = None
    graph_context: list[str] = Field(default_factory=list)
    graph_explanations: list[GraphExplanation] = Field(default_factory=list)
    recommendation_summary: str | None = None


class StoredDriftAlert(BaseModel):
    tenant_id: str
    workflow_id: str
    run_id: str
    observed_at: datetime
    risk_score: float
    severity: Severity
    signals: list[DriftSignal] = Field(default_factory=list)
    graph_context: list[str] = Field(default_factory=list)
    graph_explanations: list[GraphExplanation] = Field(default_factory=list)
    recommendation_summary: str | None = None


class ExperimentSummary(BaseModel):
    tenant_id: str
    workflow_id: str
    latest_run_id: str | None = None
    latest_agent_name: str | None = None
    latest_observed_at: datetime | None = None
    latest_status: RunStatus | None = None
    latest_risk_score: float | None = None
    latest_severity: Severity | None = None
    latest_guardrail_verdict: GuardrailVerdict | None = None
    run_count: int = 0
    drift_alert_count: int = 0
    guardrail_incident_count: int = 0
    blocked_run_count: int = 0


class GraphNodeView(BaseModel):
    uuid: str
    kind: str
    label: str
    attributes: dict[str, Any] = Field(default_factory=dict)


class GraphEdgeView(BaseModel):
    uuid: str
    source: str
    target: str
    relation: str
    fact: str
    episodes: list[str] = Field(default_factory=list)
    valid_at: datetime | None = None


class WorkflowGraphView(BaseModel):
    tenant_id: str
    workflow_id: str
    run_id: str | None = None
    nodes: list[GraphNodeView] = Field(default_factory=list)
    edges: list[GraphEdgeView] = Field(default_factory=list)
    focus_node_ids: list[str] = Field(default_factory=list)
