from __future__ import annotations

import json
import logging
import typing

import openai
from openai import AsyncOpenAI
from pydantic import BaseModel

from graphiti_core.llm_client.client import LLMClient
from graphiti_core.llm_client.config import DEFAULT_MAX_TOKENS, LLMConfig, ModelSize
from graphiti_core.llm_client.errors import RateLimitError
from graphiti_core.prompts.models import Message

logger = logging.getLogger(__name__)


def extract_json_object(raw_text: str) -> dict[str, typing.Any]:
    cleaned = raw_text.strip()
    if not cleaned:
        return {}

    try:
        parsed = json.loads(cleaned)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    decoder = json.JSONDecoder()
    for index, char in enumerate(cleaned):
        if char != "{":
            continue
        try:
            parsed, _ = decoder.raw_decode(cleaned[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            return parsed

    raise json.JSONDecodeError("No JSON object found in model response", cleaned, 0)


class MLXLLMClient(LLMClient):
    def __init__(self, config: LLMConfig | None = None, client: AsyncOpenAI | None = None):
        super().__init__(config or LLMConfig())
        self.client = client or AsyncOpenAI(
            api_key=self.config.api_key or "mlx",
            base_url=self.config.base_url,
        )

    async def _generate_response(
        self,
        messages: list[Message],
        response_model: type[BaseModel] | None = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        model_size: ModelSize = ModelSize.medium,
    ) -> dict[str, typing.Any]:
        del response_model, model_size

        payload = [
            {"role": message.role, "content": message.content}
            for message in messages
            if message.role in {"system", "user"}
        ]
        request = {
            "model": self.model,
            "messages": payload,
            "temperature": self.temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = await self.client.chat.completions.create(
                **request,
                response_format={"type": "json_object"},
            )
        except openai.RateLimitError as exc:
            raise RateLimitError from exc
        except Exception as exc:
            logger.warning("MLX JSON mode unavailable, retrying without response_format: %s", exc)
            response = await self.client.chat.completions.create(**request)

        content = response.choices[0].message.content or "{}"
        return extract_json_object(content)

    def _get_provider_type(self) -> str:
        return "mlx"
