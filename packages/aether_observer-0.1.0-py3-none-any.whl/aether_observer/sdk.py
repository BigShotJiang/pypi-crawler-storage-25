"""Lightweight SDK for instrumenting agentic workflows.

Usage (sync)::

    import aether_observer as aether

    aether.init(workflow_id="claims-triage", tenant_id="acme")
    aether.log_step(name="plan", kind="llm", model="gpt-4")
    result = aether.finish()

Usage (async)::

    async with aether.arun(workflow_id="claims-triage", tenant_id="acme"):
        aether.log_step(name="plan", kind="llm", model="gpt-4")

All run state is stored in :mod:`contextvars` so concurrent async
tasks each get their own independent run context.
"""

from __future__ import annotations

import asyncio
import atexit
import uuid
import webbrowser
from contextlib import asynccontextmanager, contextmanager
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Any, AsyncIterator, Iterator

from aether_observer.config import Settings, get_settings
from aether_observer.models import (
    GraphDriftPolicy,
    GuardrailEvaluation,
    ObservationResult,
    RunStatus,
    StepKind,
    WorkflowRun,
    WorkflowStep,
)

# ---------------------------------------------------------------------------
# Context variables — each async task / thread gets its own copy
# ---------------------------------------------------------------------------

_active_run: ContextVar[WorkflowRun | None] = ContextVar("_active_run", default=None)
_active_steps: ContextVar[list[WorkflowStep] | None] = ContextVar("_active_steps", default=None)
_step_counter: ContextVar[int] = ContextVar("_step_counter", default=0)
_registered_guardrail_functions: dict[str, Any] = {}
_sdk_settings_overrides: dict[str, Any] = {}

_SETTINGS_ALIASES = {
    "graph_path": "kuzu_db_path",
    "max_observations": "history_window",
    "sliding_window_days": "history_window_days",
    "observations_before_guardrails": "guardrail_warmup_runs",
}

_SUPPORTED_SETTINGS = {
    "app_name",
    "app_env",
    "api_key",
    "graph_backend",
    "kuzu_db_path",
    "neo4j_uri",
    "neo4j_user",
    "neo4j_password",
    "mlx_base_url",
    "mlx_api_key",
    "mlx_model",
    "mlx_temperature",
    "llm_max_tokens",
    "enable_llm_mitigation",
    "embeddings_model",
    "history_window",
    "history_window_days",
    "min_history",
    "guardrail_warmup_runs",
    "host",
    "port",
}

# ---------------------------------------------------------------------------
# Singleton service + persistent event loop for sync callers
# ---------------------------------------------------------------------------

_service_instance: Any = None  # ObservabilityService | None
_bg_loop: asyncio.AbstractEventLoop | None = None


def _get_loop() -> asyncio.AbstractEventLoop:
    """Return (or create) a persistent background event loop for sync SDK calls."""
    global _bg_loop
    if _bg_loop is None or _bg_loop.is_closed():
        _bg_loop = asyncio.new_event_loop()
    return _bg_loop


def _run_sync(coro: Any) -> Any:
    """Execute *coro* from a synchronous call-site.

    Uses a persistent event loop so the :class:`ObservabilityService`
    stays alive across multiple ``finish()`` calls in the same process.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return _get_loop().run_until_complete(coro)
    raise RuntimeError(
        "Cannot call sync SDK functions from a running event loop. "
        "Use the async variants (afinish, arun) instead."
    )


def _normalized_settings_overrides(overrides: dict[str, Any]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in overrides.items():
        setting_key = _SETTINGS_ALIASES.get(key, key)
        if setting_key in _SUPPORTED_SETTINGS and value is not None:
            normalized[setting_key] = value
    return normalized


def _consume_settings_overrides(kwargs: dict[str, Any]) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    for key in list(kwargs.keys()):
        setting_key = _SETTINGS_ALIASES.get(key, key)
        if setting_key in _SUPPORTED_SETTINGS:
            overrides[key] = kwargs.pop(key)
    return overrides


def _dispose_service_instance() -> None:
    global _service_instance
    if _service_instance is None:
        return

    service = _service_instance
    _service_instance = None

    try:
        running_loop = asyncio.get_running_loop()
    except RuntimeError:
        if _bg_loop is not None and not _bg_loop.is_closed():
            try:
                _bg_loop.run_until_complete(service.close())
            except Exception:
                pass
        return

    try:
        running_loop.create_task(service.close())
    except Exception:
        pass


def _apply_settings_overrides(overrides: dict[str, Any]) -> None:
    global _sdk_settings_overrides
    normalized = _normalized_settings_overrides(overrides)
    if not normalized:
        return

    updated = {**_sdk_settings_overrides, **normalized}
    if updated == _sdk_settings_overrides:
        return

    _sdk_settings_overrides = updated
    _dispose_service_instance()


async def get_or_create_service() -> Any:
    """Lazily create the in-process :class:`ObservabilityService`.

    The service is cached as a module-level singleton so repeated calls
    reuse the same Graphiti connection and embedding model.
    """
    global _service_instance
    if _service_instance is None:
        from aether_observer.service import ObservabilityService

        settings = (
            Settings(**_sdk_settings_overrides)
            if _sdk_settings_overrides
            else get_settings()
        )
        _service_instance = await ObservabilityService.create(settings)
        for name, fn in _registered_guardrail_functions.items():
            _service_instance.register_guardrail_function(name, fn)
    return _service_instance


def _cleanup() -> None:
    global _service_instance, _bg_loop
    if _service_instance is not None and _bg_loop is not None and not _bg_loop.is_closed():
        try:
            _bg_loop.run_until_complete(_service_instance.close())
        except Exception:
            pass
        _service_instance = None
    if _bg_loop is not None and not _bg_loop.is_closed():
        _bg_loop.close()
        _bg_loop = None


atexit.register(_cleanup)


# ---------------------------------------------------------------------------
# Public API — init / log_step / finish
# ---------------------------------------------------------------------------


class WorkflowGuardrailStop(RuntimeError):
    def __init__(self, run_id: str, evaluation: GuardrailEvaluation):
        message = evaluation.stop_reason or f"Workflow {run_id} was stopped by guardrails."
        super().__init__(message)
        self.run_id = run_id
        self.evaluation = evaluation


def register_guardrail_function(name: str, fn: Any) -> None:
    _registered_guardrail_functions[name] = fn
    if _service_instance is not None:
        _service_instance.register_guardrail_function(name, fn)


def init(
    *,
    workflow_id: str,
    tenant_id: str,
    agent_name: str = "sdk-agent",
    environment: str = "dev",
    run_id: str | None = None,
    **kwargs: Any,
) -> str:
    """Start a new workflow run and return the *run_id*.

    All subsequent :func:`log_step` calls append to this run until
    :func:`finish` (or :func:`afinish`) is called.
    """
    if _active_run.get() is not None:
        raise RuntimeError("A run is already active — call finish() first.")

    _apply_settings_overrides(_consume_settings_overrides(kwargs))

    guardrail_policy = kwargs.pop("guardrail_policy", None)
    graph_drift_policy = kwargs.pop("graph_drift_policy", None)
    rid = run_id or f"run-{uuid.uuid4().hex[:12]}"
    kwargs.setdefault("started_at", datetime.now(UTC))
    run = WorkflowRun(
        tenant_id=tenant_id,
        workflow_id=workflow_id,
        run_id=rid,
        agent_name=agent_name,
        environment=environment,
        **kwargs,
    )
    if guardrail_policy is not None:
        run.metadata["guardrail_policy"] = guardrail_policy
    if graph_drift_policy is not None:
        normalized_graph_drift_policy = (
            graph_drift_policy
            if isinstance(graph_drift_policy, GraphDriftPolicy)
            else GraphDriftPolicy.model_validate(graph_drift_policy)
        )
        run.metadata["graph_drift_policy"] = normalized_graph_drift_policy.model_dump(mode="json")
    _active_run.set(run)
    _active_steps.set([])
    _step_counter.set(0)
    return rid


def log_step(
    *,
    name: str,
    kind: str | StepKind = "other",
    step_id: str | None = None,
    **kwargs: Any,
) -> str:
    """Append a step to the active run and return the *step_id*.

    Accepts any :class:`~aether_observer.models.WorkflowStep` field as a
    keyword argument (``model``, ``prompt_version``, ``tool_name``,
    ``function_calls``, ``latency_ms``, etc.).
    """
    if _active_run.get() is None:
        raise RuntimeError("No active run — call init() first.")

    steps = _active_steps.get()
    if steps is None:
        raise RuntimeError("No active run — call init() first.")

    counter = _step_counter.get() + 1
    _step_counter.set(counter)
    sid = step_id or f"step-{counter}"

    if isinstance(kind, str):
        kind = StepKind(kind)

    step = WorkflowStep(step_id=sid, name=name, kind=kind, **kwargs)
    steps.append(step)
    return sid


def log(
    data: Any | None = None,
    *,
    name: str = "log",
    kind: str | StepKind = "system",
    step_id: str | None = None,
    **kwargs: Any,
) -> str:
    """W&B-style logging helper that records arbitrary workflow events as steps."""
    payload = dict(kwargs)
    metadata = dict(payload.pop("metadata", {}) or {})
    consumed: set[str] = set()

    if isinstance(data, dict):
        known_fields = {
            "model",
            "prompt_name",
            "prompt_version",
            "prompt_text",
            "decision_name",
            "decision_value",
            "selected_action",
            "candidate_actions",
            "tool_name",
            "function_calls",
            "input_payload",
            "output_payload",
            "datasets",
            "latency_ms",
            "tags",
            "status",
        }
        for key in known_fields:
            if key in data and key not in payload:
                payload[key] = data[key]
                consumed.add(key)
        metadata.update({key: value for key, value in data.items() if key not in consumed})
    elif data is not None:
        payload.setdefault("output_payload", data)

    if metadata:
        payload["metadata"] = metadata
    return log_step(name=name, kind=kind, step_id=step_id, **payload)


# -- async finish -----------------------------------------------------------

async def afinish(
    *,
    status: str | RunStatus = "success",
    open_browser: bool = True,
    dry_run: bool = False,
    stop_on_block: bool = True,
    **kwargs: Any,
) -> ObservationResult:
    """Finalize the active run and submit it for observation (async).

    Returns the full :class:`~aether_observer.models.ObservationResult`
    including drift signals and guardrail evaluations.
    """
    run = _active_run.get()
    if run is None:
        raise RuntimeError("No active run — call init() first.")

    if isinstance(status, str):
        status = RunStatus(status)

    run.status = status
    run.finished_at = datetime.now(UTC)
    run.steps = _active_steps.get() or []
    for key, value in kwargs.items():
        if hasattr(run, key):
            setattr(run, key, value)

    service = await get_or_create_service()
    result: ObservationResult = await service.observe(payload=run, dry_run=dry_run)

    # Reset context
    _active_run.set(None)
    _active_steps.set(None)
    _step_counter.set(0)

    if open_browser:
        _open_dashboard(run.run_id, service.settings)

    if stop_on_block and result.guardrail_result and result.guardrail_result.stopped_run:
        raise WorkflowGuardrailStop(run.run_id, result.guardrail_result)

    return result


# -- sync finish ------------------------------------------------------------

def finish(
    *,
    status: str | RunStatus = "success",
    open_browser: bool = True,
    dry_run: bool = False,
    stop_on_block: bool = True,
    **kwargs: Any,
) -> ObservationResult:
    """Finalize the active run and submit it for observation (sync).

    Equivalent to :func:`afinish` but safe to call from non-async code.
    If you are inside an ``async def``, use ``await afinish(...)`` instead.
    """
    result = _run_sync(
        afinish(
            status=status,
            open_browser=open_browser,
            dry_run=dry_run,
            stop_on_block=stop_on_block,
            **kwargs,
        )
    )
    # ContextVar mutations inside the coroutine don't propagate back
    # to the calling thread, so reset them here explicitly.
    _active_run.set(None)
    _active_steps.set(None)
    _step_counter.set(0)
    return result


def set_guardrail_policy(policy: Any) -> None:
    run = _active_run.get()
    if run is None:
        raise RuntimeError("No active run — call init() first.")
    run.metadata["guardrail_policy"] = policy


def set_graph_drift_policy(policy: GraphDriftPolicy | dict[str, Any]) -> None:
    run = _active_run.get()
    if run is None:
        raise RuntimeError("No active run — call init() first.")
    normalized_policy = (
        policy if isinstance(policy, GraphDriftPolicy) else GraphDriftPolicy.model_validate(policy)
    )
    run.metadata["graph_drift_policy"] = normalized_policy.model_dump(mode="json")


def _active_run_snapshot() -> WorkflowRun:
    run = _active_run.get()
    if run is None:
        raise RuntimeError("No active run — call init() first.")
    snapshot = run.model_copy(deep=True)
    snapshot.steps = list(_active_steps.get() or [])
    if snapshot.finished_at is None:
        snapshot.finished_at = datetime.now(UTC)
    return snapshot


async def acheck_guardrails(
    *,
    persist_incident: bool = True,
    stop_on_block: bool = True,
) -> GuardrailEvaluation | None:
    snapshot = _active_run_snapshot()
    service = await get_or_create_service()
    run, evaluation = await service.evaluate_guardrails(
        payload=snapshot,
        persist_incident=persist_incident,
    )
    if evaluation is not None and evaluation.stopped_run:
        active = _active_run.get()
        if active is not None:
            active.status = RunStatus.failed
            active.metadata["guardrail_stopped"] = True
            active.metadata["guardrail_stop_reason"] = evaluation.stop_reason
        if stop_on_block:
            raise WorkflowGuardrailStop(run.run_id, evaluation)
    return evaluation


def check_guardrails(
    *,
    persist_incident: bool = True,
    stop_on_block: bool = True,
) -> GuardrailEvaluation | None:
    return _run_sync(
        acheck_guardrails(
            persist_incident=persist_incident,
            stop_on_block=stop_on_block,
        )
    )


async def aguardrail(
    policy: Any | None = None,
    *,
    finalize: bool = True,
    persist_incident: bool = True,
    stop_on_block: bool = True,
    open_browser: bool = False,
    status: str | RunStatus = "success",
    dry_run: bool = False,
    **kwargs: Any,
) -> ObservationResult | GuardrailEvaluation | None:
    """Evaluate guardrails for the active run.

    When ``finalize`` is true, this completes the run and persists the
    observation, which makes the ``init() -> log() -> guardrail()`` flow
    usable as the simple package API. Set ``finalize=False`` to run a
    mid-flight guardrail check without closing the run.
    """
    if policy is not None:
        set_guardrail_policy(policy)
    if finalize:
        return await afinish(
            status=status,
            open_browser=open_browser,
            dry_run=dry_run,
            stop_on_block=stop_on_block,
            **kwargs,
        )
    return await acheck_guardrails(
        persist_incident=persist_incident,
        stop_on_block=stop_on_block,
    )


def guardrail(
    policy: Any | None = None,
    *,
    finalize: bool = True,
    persist_incident: bool = True,
    stop_on_block: bool = True,
    open_browser: bool = False,
    status: str | RunStatus = "success",
    dry_run: bool = False,
    **kwargs: Any,
) -> ObservationResult | GuardrailEvaluation | None:
    return _run_sync(
        aguardrail(
            policy,
            finalize=finalize,
            persist_incident=persist_incident,
            stop_on_block=stop_on_block,
            open_browser=open_browser,
            status=status,
            dry_run=dry_run,
            **kwargs,
        )
    )


async def acheck_graph_drift(
    *,
    stop_on_block: bool = True,
) -> ObservationResult:
    snapshot = _active_run_snapshot()
    service = await get_or_create_service()
    result: ObservationResult = await service.observe(payload=snapshot, dry_run=True)
    if stop_on_block and result.guardrail_result and result.guardrail_result.stopped_run:
        active = _active_run.get()
        if active is not None:
            active.status = RunStatus.failed
            active.metadata["guardrail_stopped"] = True
            active.metadata["guardrail_stop_reason"] = result.guardrail_result.stop_reason
        raise WorkflowGuardrailStop(snapshot.run_id, result.guardrail_result)
    return result


def check_graph_drift(
    *,
    stop_on_block: bool = True,
) -> ObservationResult:
    return _run_sync(
        acheck_graph_drift(
            stop_on_block=stop_on_block,
        )
    )


# ---------------------------------------------------------------------------
# Context managers
# ---------------------------------------------------------------------------


@contextmanager
def run(
    *,
    workflow_id: str,
    tenant_id: str,
    agent_name: str = "sdk-agent",
    environment: str = "dev",
    run_id: str | None = None,
    open_browser: bool = True,
    **kwargs: Any,
) -> Iterator[str]:
    """Sync context manager that wraps :func:`init` / :func:`finish`.

    Yields the *run_id*.  On unhandled exceptions the run is finalized
    with ``status="failed"``.
    """
    rid = init(
        workflow_id=workflow_id,
        tenant_id=tenant_id,
        agent_name=agent_name,
        environment=environment,
        run_id=run_id,
        **kwargs,
    )
    failed = False
    try:
        yield rid
    except BaseException:
        failed = True
        try:
            finish(status="failed", open_browser=False)
        except Exception:
            pass
        raise
    if not failed:
        finish(open_browser=open_browser)


@asynccontextmanager
async def arun(
    *,
    workflow_id: str,
    tenant_id: str,
    agent_name: str = "sdk-agent",
    environment: str = "dev",
    run_id: str | None = None,
    open_browser: bool = True,
    **kwargs: Any,
) -> AsyncIterator[str]:
    """Async context manager that wraps :func:`init` / :func:`afinish`.

    Yields the *run_id*.  On unhandled exceptions the run is finalized
    with ``status="failed"``.
    """
    rid = init(
        workflow_id=workflow_id,
        tenant_id=tenant_id,
        agent_name=agent_name,
        environment=environment,
        run_id=run_id,
        **kwargs,
    )
    failed = False
    try:
        yield rid
    except BaseException:
        failed = True
        try:
            await afinish(status="failed", open_browser=False)
        except Exception:
            pass
        raise
    if not failed:
        await afinish(open_browser=open_browser)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _open_dashboard(run_id: str, settings: Any) -> None:
    host = "127.0.0.1" if settings.host in ("0.0.0.0", "::") else settings.host
    url = f"http://{host}:{settings.port}/?run_id={run_id}"
    try:
        webbrowser.open(url)
    except Exception:
        pass
