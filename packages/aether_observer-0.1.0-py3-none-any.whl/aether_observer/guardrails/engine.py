from __future__ import annotations

import inspect
import json
from collections import defaultdict
from collections.abc import Awaitable, Callable
from typing import Any

from pydantic import BaseModel, Field

from graphiti_core.llm_client.client import LLMClient
from graphiti_core.prompts.models import Message

from aether_observer.drift.features import (
    WorkflowFeatures,
    dominant_values,
    function_argument_keys,
    infer_step_action,
)
from aether_observer.models import (
    DynamicGuardrailPolicy,
    GuardrailCheckResult,
    GuardrailCheckStatus,
    GuardrailEvaluation,
    GuardrailFunctionResult,
    GuardrailMode,
    GuardrailVerdict,
    GuardrailViolation,
    RuntimeFunctionGuardrail,
    Severity,
    WorkflowRun,
)

GuardrailCallable = Callable[[WorkflowRun], GuardrailFunctionResult | dict[str, Any] | bool | Awaitable[Any]]


class LLMGuardrailResponse(BaseModel):
    passed: bool
    summary: str | None = None
    step_id: str | None = None
    evidence: dict[str, Any] = Field(default_factory=dict)
    recommended_actions: list[str] = Field(default_factory=list)


def _call_name(signature: str) -> str:
    return signature.split("(", 1)[0]


def _current_function_names(current: WorkflowFeatures) -> set[str]:
    return {_call_name(signature) for signature in current.function_call_set}


def _dominant_function_names(history: list[WorkflowFeatures]) -> list[str]:
    function_name_sets = [{_call_name(signature) for signature in item.function_call_set} for item in history]
    return dominant_values(function_name_sets)


def _dominant_dataset_versions(history: list[WorkflowFeatures]) -> dict[str, list[str]]:
    versions_by_dataset: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for item in history:
        for signature in item.dataset_signatures:
            name, version, _schema = (signature.split(":", 2) + ["unknown", "unknown"])[:3]
            versions_by_dataset[name][version] += 1

    dominant: dict[str, list[str]] = {}
    for dataset_name, counts in versions_by_dataset.items():
        if not counts:
            continue
        dominant_version = max(counts.items(), key=lambda entry: entry[1])[0]
        dominant[dataset_name] = [dominant_version]
    return dominant


def _normalize_function_result(raw: GuardrailFunctionResult | dict[str, Any] | bool) -> GuardrailFunctionResult:
    if isinstance(raw, GuardrailFunctionResult):
        return raw
    if isinstance(raw, bool):
        return GuardrailFunctionResult(
            passed=raw,
            summary="Guardrail function passed." if raw else "Guardrail function failed.",
        )
    if isinstance(raw, dict):
        return GuardrailFunctionResult.model_validate(raw)
    raise TypeError(f"Unsupported guardrail function result type: {type(raw)!r}")


def _step_ids_for_run(run: WorkflowRun) -> set[str]:
    return {step.step_id for step in run.steps}


class GuardrailEngine:
    def __init__(self, function_registry: dict[str, GuardrailCallable] | None = None):
        self.function_registry: dict[str, GuardrailCallable] = {}
        self._register_builtin_function_guardrails()
        if function_registry:
            self.function_registry.update(function_registry)

    def register_function_guardrail(self, name: str, fn: GuardrailCallable) -> None:
        self.function_registry[name] = fn

    def evaluate(
        self,
        run: WorkflowRun,
        current: WorkflowFeatures,
        history: list[WorkflowFeatures],
        policy: DynamicGuardrailPolicy | None,
    ) -> GuardrailEvaluation | None:
        if policy is None or not policy.enabled:
            return None

        result = GuardrailEvaluation(
            policy_id=policy.policy_id,
            mode=policy.mode,
            verdict=GuardrailVerdict.pass_,
        )

        def add_violation(
            *,
            kind: str,
            severity: Severity,
            title: str,
            summary: str,
            step_id: str | None = None,
            score: float = 1.0,
            evidence: dict | None = None,
            recommended_actions: list[str] | None = None,
        ) -> None:
            result.violations.append(
                GuardrailViolation(
                    policy_id=policy.policy_id,
                    kind=kind,
                    severity=severity,
                    mode=policy.mode,
                    title=title,
                    summary=summary,
                    step_id=step_id,
                    score=score,
                    evidence=evidence or {},
                    recommended_actions=recommended_actions or [],
                )
            )

        expected_decisions = set(policy.allowed_decisions)
        if policy.dynamic_baseline.decisions_from_history and history:
            expected_decisions.update(dominant_values([item.decision_set for item in history]))
        if expected_decisions and current.decision_set:
            unexpected = sorted(current.decision_set - expected_decisions)
            if unexpected:
                add_violation(
                    kind="decision_guardrail_violation",
                    severity=Severity.high,
                    title="Decision guardrail violated",
                    summary="The workflow produced decision outcomes outside the approved policy envelope.",
                    score=0.9,
                    evidence={
                        "unexpected_decisions": unexpected,
                        "expected_decisions": sorted(expected_decisions),
                    },
                    recommended_actions=[
                        "Pin the approved decision routes for this client workflow.",
                        "Review routing policy thresholds before promoting the change.",
                    ],
                )

        expected_actions = set(policy.allowed_actions)
        if policy.dynamic_baseline.actions_from_history and history:
            expected_actions.update(dominant_values([item.action_set for item in history]))
        if expected_actions and current.action_set:
            unexpected = sorted(current.action_set - expected_actions)
            if unexpected:
                add_violation(
                    kind="action_guardrail_violation",
                    severity=Severity.high,
                    title="Action guardrail violated",
                    summary="The workflow selected actions outside the approved action routes.",
                    score=0.92,
                    evidence={
                        "unexpected_actions": unexpected,
                        "expected_actions": sorted(expected_actions),
                    },
                    recommended_actions=[
                        "Restrict route changes behind approval or rollout gates.",
                        "Audit planner branch logic and tool routing conditions.",
                    ],
                )

        for step in run.steps:
            action = infer_step_action(step)
            if action and action in set(policy.blocked_actions):
                add_violation(
                    kind="blocked_action",
                    severity=Severity.critical,
                    title="Blocked action attempted",
                    summary="The workflow selected an action that is explicitly blocked by policy.",
                    step_id=step.step_id,
                    score=1.0,
                    evidence={"blocked_action": action, "step_name": step.name},
                    recommended_actions=[
                        "Remove or gate the blocked action before production use.",
                    ],
                )
            if action and action in set(policy.require_approval_actions):
                add_violation(
                    kind="approval_required_action",
                    severity=Severity.high,
                    title="Approval-required action selected",
                    summary="The workflow selected an action that requires explicit approval.",
                    step_id=step.step_id,
                    score=0.85,
                    evidence={"approval_required_action": action, "step_name": step.name},
                    recommended_actions=[
                        "Require a human approval gate before allowing this route.",
                    ],
                )

        expected_function_names = set(policy.allowed_functions)
        if policy.dynamic_baseline.functions_from_history and history:
            expected_function_names.update(_dominant_function_names(history))
        current_function_names = _current_function_names(current)
        if expected_function_names and current_function_names:
            unexpected = sorted(current_function_names - expected_function_names)
            if unexpected:
                add_violation(
                    kind="function_guardrail_violation",
                    severity=Severity.high,
                    title="Function route guardrail violated",
                    summary="The workflow called functions outside the approved function route policy.",
                    score=0.95,
                    evidence={
                        "unexpected_functions": unexpected,
                        "expected_functions": sorted(expected_function_names),
                    },
                    recommended_actions=[
                        "Bind only the approved function set for this client workflow.",
                        "Review planner-to-function routing and tool registration.",
                    ],
                )

        for step in run.steps:
            for call in step.function_calls:
                if call.function_name in set(policy.blocked_functions):
                    add_violation(
                        kind="blocked_function",
                        severity=Severity.critical,
                        title="Blocked function attempted",
                        summary="The workflow called a function that is explicitly blocked by policy.",
                        step_id=step.step_id,
                        score=1.0,
                        evidence={"blocked_function": call.function_name, "step_name": step.name},
                        recommended_actions=[
                            "Remove the blocked function from the client workflow bindings.",
                        ],
                    )

                contract = policy.function_contracts.get(call.function_name)
                if contract is None:
                    continue

                arg_keys = set(function_argument_keys(call.arguments))
                required = set(contract.required_keys)
                allowed = set(contract.allowed_keys)
                blocked = set(contract.blocked_keys)

                missing = sorted(required - arg_keys)
                disallowed = sorted(arg_keys - allowed) if allowed and not contract.allow_additional_keys else []
                blocked_present = sorted(arg_keys & blocked)
                if missing or disallowed or blocked_present:
                    add_violation(
                        kind="function_contract_violation",
                        severity=Severity.high,
                        title="Function argument contract violated",
                        summary="The workflow called a function with arguments outside the approved schema contract.",
                        step_id=step.step_id,
                        score=0.93,
                        evidence={
                            "function_name": call.function_name,
                            "argument_keys": sorted(arg_keys),
                            "missing_keys": missing,
                            "disallowed_keys": disallowed,
                            "blocked_keys": blocked_present,
                        },
                        recommended_actions=[
                            "Enforce the function schema contract before execution.",
                            "Review planner argument assembly for this function call.",
                        ],
                    )

        expected_models = set(policy.allowed_models)
        if policy.dynamic_baseline.models_from_history and history:
            expected_models.update(dominant_values([item.model_set for item in history]))
        if expected_models and current.model_set:
            unexpected = sorted(current.model_set - expected_models)
            if unexpected:
                add_violation(
                    kind="model_guardrail_violation",
                    severity=Severity.high,
                    title="Model policy violated",
                    summary="The workflow executed with models outside the approved client policy.",
                    score=0.88,
                    evidence={"unexpected_models": unexpected, "expected_models": sorted(expected_models)},
                    recommended_actions=[
                        "Pin the approved model set for this tenant and workflow.",
                    ],
                )

        expected_prompts = set(policy.allowed_prompts)
        if policy.dynamic_baseline.prompts_from_history and history:
            expected_prompts.update(dominant_values([item.prompt_signatures for item in history]))
        if expected_prompts and current.prompt_signatures:
            unexpected = sorted(current.prompt_signatures - expected_prompts)
            if unexpected:
                add_violation(
                    kind="prompt_guardrail_violation",
                    severity=Severity.high,
                    title="Prompt policy violated",
                    summary="The workflow used prompt versions outside the approved client policy.",
                    score=0.87,
                    evidence={"unexpected_prompts": unexpected, "expected_prompts": sorted(expected_prompts)},
                    recommended_actions=[
                        "Treat prompt changes as release-managed workflow changes.",
                    ],
                )

        expected_tools = set(policy.allowed_tools)
        if policy.dynamic_baseline.tools_from_history and history:
            expected_tools.update(dominant_values([item.tool_set for item in history]))
        if expected_tools and current.tool_set:
            unexpected = sorted(current.tool_set - expected_tools)
            if unexpected:
                add_violation(
                    kind="tool_guardrail_violation",
                    severity=Severity.high,
                    title="Tool policy violated",
                    summary="The workflow used tools outside the approved client tool policy.",
                    score=0.9,
                    evidence={"unexpected_tools": unexpected, "expected_tools": sorted(expected_tools)},
                    recommended_actions=[
                        "Restrict the exposed tool registry for this client workflow.",
                    ],
                )

        expected_dataset_versions = {
            dataset_name: sorted(set(versions))
            for dataset_name, versions in policy.dataset_version_policies.items()
        }
        if policy.dynamic_baseline.datasets_from_history and history:
            for dataset_name, versions in _dominant_dataset_versions(history).items():
                expected_dataset_versions.setdefault(dataset_name, [])
                for version in versions:
                    if version not in expected_dataset_versions[dataset_name]:
                        expected_dataset_versions[dataset_name].append(version)

        for dataset in run.datasets:
            allowed_versions = expected_dataset_versions.get(dataset.name)
            version = dataset.version or "unknown"
            if allowed_versions and version not in allowed_versions:
                add_violation(
                    kind="dataset_guardrail_violation",
                    severity=Severity.high,
                    title="Dataset policy violated",
                    summary="The workflow consumed a dataset version outside the approved policy.",
                    score=0.9,
                    evidence={
                        "dataset_name": dataset.name,
                        "dataset_version": version,
                        "expected_versions": allowed_versions,
                    },
                    recommended_actions=[
                        "Pin dataset versions for this client workflow before execution.",
                    ],
                )

        if policy.max_step_count is not None and current.step_count > policy.max_step_count:
            add_violation(
                kind="step_budget_violation",
                severity=Severity.medium,
                title="Step budget exceeded",
                summary="The workflow exceeded the maximum allowed step count for this client.",
                score=0.75,
                evidence={
                    "step_count": current.step_count,
                    "max_step_count": policy.max_step_count,
                },
                recommended_actions=[
                    "Cap recursive planning depth and retries.",
                ],
            )

        if policy.max_latency_ms is not None and current.latency_ms > policy.max_latency_ms:
            add_violation(
                kind="latency_budget_violation",
                severity=Severity.medium,
                title="Latency budget exceeded",
                summary="The workflow exceeded the maximum allowed latency for this client.",
                score=0.7,
                evidence={
                    "latency_ms": current.latency_ms,
                    "max_latency_ms": policy.max_latency_ms,
                },
                recommended_actions=[
                    "Reduce tool fanout or move slow branches behind async review.",
                ],
            )

        self._finalize_result(policy, result)
        return result

    async def evaluate_runtime_checks(
        self,
        run: WorkflowRun,
        policy: DynamicGuardrailPolicy | None,
        llm_client: LLMClient | None,
        evaluation: GuardrailEvaluation | None = None,
    ) -> GuardrailEvaluation | None:
        if policy is None or not policy.enabled:
            return evaluation

        result = evaluation or GuardrailEvaluation(
            policy_id=policy.policy_id,
            mode=policy.mode,
            verdict=GuardrailVerdict.pass_,
        )
        valid_step_ids = _step_ids_for_run(run)

        for guardrail in policy.runtime_function_guardrails:
            check = await self._run_function_guardrail(run, guardrail, valid_step_ids)
            result.checks.append(check)
            if check.status != GuardrailCheckStatus.pass_:
                result.violations.append(
                    GuardrailViolation(
                        policy_id=policy.policy_id,
                        kind=(
                            "runtime_function_guardrail_error"
                            if check.status == GuardrailCheckStatus.error
                            else "runtime_function_guardrail_failure"
                        ),
                        severity=Severity.critical if check.stop_workflow else Severity.high,
                        mode=policy.mode,
                        title=check.title,
                        summary=check.summary,
                        step_id=check.step_id,
                        score=1.0 if check.stop_workflow else 0.88,
                        evidence=check.evidence,
                        recommended_actions=check.recommended_actions,
                    )
                )
                if check.stop_workflow and not result.stop_reason:
                    result.stop_reason = check.summary

        for guardrail in policy.natural_language_guardrails:
            check = await self._run_natural_language_guardrail(run, guardrail, llm_client, valid_step_ids)
            result.checks.append(check)
            if check.status != GuardrailCheckStatus.pass_:
                result.violations.append(
                    GuardrailViolation(
                        policy_id=policy.policy_id,
                        kind=(
                            "natural_language_guardrail_error"
                            if check.status == GuardrailCheckStatus.error
                            else "natural_language_guardrail_failure"
                        ),
                        severity=Severity.critical if check.stop_workflow else Severity.high,
                        mode=policy.mode,
                        title=check.title,
                        summary=check.summary,
                        step_id=check.step_id,
                        score=1.0 if check.stop_workflow else 0.9,
                        evidence=check.evidence,
                        recommended_actions=check.recommended_actions,
                    )
                )
                if check.stop_workflow and not result.stop_reason:
                    result.stop_reason = check.summary

        self._finalize_result(policy, result)
        return result

    async def _run_function_guardrail(
        self,
        run: WorkflowRun,
        guardrail: RuntimeFunctionGuardrail,
        valid_step_ids: set[str],
    ) -> GuardrailCheckResult:
        title = guardrail.title or guardrail.guardrail_id
        handler = self.function_registry.get(guardrail.function_name)
        if handler is None:
            return GuardrailCheckResult(
                guardrail_id=guardrail.guardrail_id,
                kind="runtime_function_guardrail",
                status=GuardrailCheckStatus.error,
                title=title,
                summary=f"Guardrail function '{guardrail.function_name}' is not registered.",
                stop_workflow=guardrail.stop_on_failure,
                evidence={"function_name": guardrail.function_name},
                recommended_actions=[
                    "Register the missing guardrail function before running this workflow.",
                ],
            )

        try:
            raw_result = handler(run)
            if inspect.isawaitable(raw_result):
                raw_result = await raw_result
            outcome = _normalize_function_result(raw_result)
        except Exception as exc:
            return GuardrailCheckResult(
                guardrail_id=guardrail.guardrail_id,
                kind="runtime_function_guardrail",
                status=GuardrailCheckStatus.error,
                title=title,
                summary=f"Guardrail function '{guardrail.function_name}' crashed: {exc}",
                stop_workflow=guardrail.stop_on_failure,
                evidence={"function_name": guardrail.function_name, "error": str(exc)},
                recommended_actions=[
                    "Fix the executable guardrail function before promoting this workflow.",
                ],
            )

        step_id = outcome.step_id if outcome.step_id in valid_step_ids else None
        passed = outcome.passed
        return GuardrailCheckResult(
            guardrail_id=guardrail.guardrail_id,
            kind="runtime_function_guardrail",
            status=GuardrailCheckStatus.pass_ if passed else GuardrailCheckStatus.fail,
            title=title,
            summary=outcome.summary or ("Guardrail passed." if passed else "Guardrail failed."),
            stop_workflow=guardrail.stop_on_failure and not passed,
            step_id=step_id,
            evidence={
                "function_name": guardrail.function_name,
                "description": guardrail.description,
                **outcome.evidence,
            },
            recommended_actions=outcome.recommended_actions,
        )

    async def _run_natural_language_guardrail(
        self,
        run: WorkflowRun,
        guardrail,
        llm_client: LLMClient | None,
        valid_step_ids: set[str],
    ) -> GuardrailCheckResult:
        title = guardrail.title or guardrail.guardrail_id
        if llm_client is None:
            return GuardrailCheckResult(
                guardrail_id=guardrail.guardrail_id,
                kind="natural_language_guardrail",
                status=GuardrailCheckStatus.error,
                title=title,
                summary="Natural-language guardrail requested but no LLM client is available.",
                stop_workflow=guardrail.stop_on_failure,
                evidence={"instruction": guardrail.instruction},
                recommended_actions=[
                    "Start the local MLX model endpoint before using natural-language guardrails.",
                ],
            )

        payload = {
            "workflow_id": run.workflow_id,
            "run_id": run.run_id,
            "status": run.status.value,
            "input_payload": run.input_payload,
            "output_payload": run.output_payload,
            "datasets": [dataset.model_dump(mode="json") for dataset in run.datasets],
            "steps": [
                {
                    "step_id": step.step_id,
                    "name": step.name,
                    "kind": step.kind.value,
                    "status": step.status.value,
                    "model": step.model,
                    "prompt_version": step.prompt_version,
                    "decision_name": step.decision_name,
                    "decision_value": step.decision_value,
                    "selected_action": step.selected_action,
                    "tool_name": step.tool_name,
                    "function_calls": [
                        {
                            "function_name": call.function_name,
                            "arguments": call.arguments,
                        }
                        for call in step.function_calls
                    ],
                }
                for step in run.steps
            ],
        }
        messages = [
            Message(
                role="system",
                content=(
                    "You are an enterprise workflow guardrail. Judge the workflow against the instruction. "
                    "Return JSON with fields: passed (boolean), summary (string), step_id (string or null), "
                    "evidence (object), recommended_actions (array of strings)."
                ),
            ),
            Message(
                role="user",
                content=json.dumps(
                    {
                        "instruction": guardrail.instruction,
                        "workflow_run": payload,
                    },
                    default=str,
                ),
            ),
        ]

        try:
            response = await llm_client.generate_response(
                messages=messages,
                response_model=LLMGuardrailResponse,
                prompt_name="natural_language_guardrail_check",
            )
            outcome = GuardrailFunctionResult.model_validate(response)
        except Exception as exc:
            return GuardrailCheckResult(
                guardrail_id=guardrail.guardrail_id,
                kind="natural_language_guardrail",
                status=GuardrailCheckStatus.error,
                title=title,
                summary=f"Natural-language guardrail evaluation failed: {exc}",
                stop_workflow=guardrail.stop_on_failure,
                evidence={"instruction": guardrail.instruction, "error": str(exc)},
                recommended_actions=[
                    "Review the MLX runtime or simplify the guardrail instruction.",
                ],
            )

        step_id = outcome.step_id if outcome.step_id in valid_step_ids else None
        passed = outcome.passed
        return GuardrailCheckResult(
            guardrail_id=guardrail.guardrail_id,
            kind="natural_language_guardrail",
            status=GuardrailCheckStatus.pass_ if passed else GuardrailCheckStatus.fail,
            title=title,
            summary=outcome.summary or ("Natural-language guardrail passed." if passed else "Natural-language guardrail failed."),
            stop_workflow=guardrail.stop_on_failure and not passed,
            step_id=step_id,
            evidence={
                "instruction": guardrail.instruction,
                **outcome.evidence,
            },
            recommended_actions=outcome.recommended_actions,
        )

    def _finalize_result(self, policy: DynamicGuardrailPolicy, result: GuardrailEvaluation) -> None:
        forced_stop = any(check.stop_workflow for check in result.checks)
        policy_stop = bool(result.violations) and policy.mode == GuardrailMode.block
        result.stopped_run = forced_stop or policy_stop
        if result.stopped_run and not result.stop_reason and result.violations:
            result.stop_reason = result.violations[0].summary

        if result.stopped_run:
            result.verdict = GuardrailVerdict.block
        elif result.violations:
            result.verdict = GuardrailVerdict.block if policy.mode == GuardrailMode.block else GuardrailVerdict.warn
        else:
            result.verdict = GuardrailVerdict.pass_

    def _register_builtin_function_guardrails(self) -> None:
        self.register_function_guardrail(
            "disallow_public_web_search",
            self._guard_disallow_public_web_search,
        )
        self.register_function_guardrail(
            "manual_review_requires_broker_override",
            self._guard_manual_review_requires_broker_override,
        )

    def _guard_disallow_public_web_search(self, run: WorkflowRun) -> GuardrailFunctionResult:
        for step in run.steps:
            action = infer_step_action(step)
            if action == "web_search" or step.tool_name == "web_search":
                return GuardrailFunctionResult(
                    passed=False,
                    summary="Web search is not allowed for this workflow instance.",
                    step_id=step.step_id,
                    evidence={
                        "selected_action": action,
                        "tool_name": step.tool_name,
                        "step_name": step.name,
                    },
                    recommended_actions=[
                        "Remove the web search branch or move it behind a manual review gate.",
                    ],
                )
        return GuardrailFunctionResult(
            passed=True,
            summary="No public web search action was detected.",
        )

    def _guard_manual_review_requires_broker_override(self, run: WorkflowRun) -> GuardrailFunctionResult:
        broker_override = bool((run.input_payload or {}).get("broker_override")) if isinstance(run.input_payload, dict) else False
        for step in run.steps:
            action = infer_step_action(step)
            if action == "manual_review_router" and not broker_override:
                return GuardrailFunctionResult(
                    passed=False,
                    summary="Manual review requires broker_override=true for this workflow.",
                    step_id=step.step_id,
                    evidence={
                        "selected_action": action,
                        "broker_override": broker_override,
                        "step_name": step.name,
                    },
                    recommended_actions=[
                        "Set broker_override before routing to manual review, or choose an approved route.",
                    ],
                )
        return GuardrailFunctionResult(
            passed=True,
            summary="Manual review routing satisfied broker override requirements.",
        )
