"""Aether Observer — observability, drift detection, and guardrails for agentic workflows."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("aether-observer")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

from aether_observer.models import GraphDriftPolicy
from aether_observer.sdk import (
    acheck_guardrails,
    acheck_graph_drift,
    aguardrail,
    afinish,
    arun,
    check_guardrails,
    check_graph_drift,
    finish,
    guardrail,
    init,
    log,
    log_step,
    register_guardrail_function,
    run,
    set_guardrail_policy,
    set_graph_drift_policy,
    WorkflowGuardrailStop,
)

__all__ = [
    "__version__",
    "GraphDriftPolicy",
    "acheck_guardrails",
    "acheck_graph_drift",
    "aguardrail",
    "afinish",
    "arun",
    "check_guardrails",
    "check_graph_drift",
    "finish",
    "guardrail",
    "init",
    "log",
    "log_step",
    "register_guardrail_function",
    "run",
    "set_guardrail_policy",
    "set_graph_drift_policy",
    "WorkflowGuardrailStop",
]
