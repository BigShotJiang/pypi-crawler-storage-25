from __future__ import annotations

from aether_observer.drift.features import (
    WorkflowFeatures,
    jaccard_similarity,
    normalized_deviation,
    safe_mean,
    severity_from_score,
)
from aether_observer.models import DriftSignal, DriftType


class DataDriftDetector:
    def detect(
        self,
        current: WorkflowFeatures,
        history: list[WorkflowFeatures],
    ) -> list[DriftSignal]:
        if not history:
            return []

        signals: list[DriftSignal] = []

        input_similarity = safe_mean(
            jaccard_similarity(current.input_schema, item.input_schema) for item in history
        )
        output_similarity = safe_mean(
            jaccard_similarity(current.output_schema, item.output_schema) for item in history
        )
        dataset_similarity = safe_mean(
            jaccard_similarity(current.dataset_signatures, item.dataset_signatures) for item in history
        )
        input_size_drift = normalized_deviation(
            current.input_size, [item.input_size for item in history]
        )
        output_size_drift = normalized_deviation(
            current.output_size, [item.output_size for item in history]
        )

        input_score = 1 - input_similarity
        output_score = 1 - output_similarity
        dataset_score = 1 - dataset_similarity

        if input_score >= 0.35:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.data,
                    kind="input_schema_drift",
                    severity=severity_from_score(input_score),
                    score=round(input_score, 3),
                    title="Input schema drift detected",
                    summary="The current input payload structure differs materially from recent runs.",
                    evidence={
                        "input_similarity": round(input_similarity, 3),
                        "current_input_schema": sorted(current.input_schema),
                    },
                    recommended_actions=[
                        "Validate upstream producer contracts before executing the workflow.",
                        "Add coercion and required-field guards at workflow ingress.",
                    ],
                )
            )

        if output_score >= 0.35:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.data,
                    kind="output_schema_drift",
                    severity=severity_from_score(output_score),
                    score=round(output_score, 3),
                    title="Output schema drift detected",
                    summary="The workflow is emitting a materially different response shape than its recent baseline.",
                    evidence={
                        "output_similarity": round(output_similarity, 3),
                        "current_output_schema": sorted(current.output_schema),
                    },
                    recommended_actions=[
                        "Pin a response contract for the workflow output.",
                        "Add schema validation before downstream handoff.",
                    ],
                )
            )

        if dataset_score >= 0.4 and current.dataset_signatures:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.data,
                    kind="dataset_version_drift",
                    severity=severity_from_score(dataset_score),
                    score=round(dataset_score, 3),
                    title="Dataset/version drift detected",
                    summary="The workflow consumed datasets or schema hashes that do not align with recent runs.",
                    evidence={
                        "dataset_similarity": round(dataset_similarity, 3),
                        "current_datasets": sorted(current.dataset_signatures),
                    },
                    recommended_actions=[
                        "Freeze upstream dataset versions for stable production workflows.",
                        "Treat schema hash changes as approval-gated deployment events.",
                    ],
                )
            )

        max_volume_score = max(input_size_drift, output_size_drift)
        if max_volume_score >= 0.6:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.data,
                    kind="payload_volume_drift",
                    severity=severity_from_score(max_volume_score),
                    score=round(max_volume_score, 3),
                    title="Payload volume drift detected",
                    summary="Payload size shifted sharply relative to recent runs, which often precedes extraction errors or hallucinated structure.",
                    evidence={
                        "input_size": current.input_size,
                        "output_size": current.output_size,
                        "input_size_drift": round(input_size_drift, 3),
                        "output_size_drift": round(output_size_drift, 3),
                    },
                    recommended_actions=[
                        "Add payload-size guardrails and truncation policy checks.",
                        "Review upstream batching or chunking changes.",
                    ],
                )
            )

        return signals
