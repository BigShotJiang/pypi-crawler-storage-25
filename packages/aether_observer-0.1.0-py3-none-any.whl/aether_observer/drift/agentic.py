from __future__ import annotations

from aether_observer.drift.features import (
    WorkflowFeatures,
    dominant_ratio,
    dominant_sequence,
    dominant_values,
    jaccard_similarity,
    normalized_deviation,
    safe_mean,
    sequence_similarity,
    severity_from_score,
)
from aether_observer.models import DriftSignal, DriftType


class AgenticDriftDetector:
    def detect(
        self,
        current: WorkflowFeatures,
        history: list[WorkflowFeatures],
    ) -> list[DriftSignal]:
        if not history:
            return []

        signals: list[DriftSignal] = []

        tool_sequence_similarity = safe_mean(
            sequence_similarity(current.tool_sequence, item.tool_sequence) for item in history
        )
        tool_set_similarity = safe_mean(
            jaccard_similarity(current.tool_set, item.tool_set) for item in history
        )
        prompt_alignment = dominant_ratio(
            current.prompt_signatures, [item.prompt_signatures for item in history]
        )
        model_alignment = dominant_ratio(current.model_set, [item.model_set for item in history])
        decision_sequence_similarity = safe_mean(
            sequence_similarity(current.decision_sequence, item.decision_sequence) for item in history
        )
        decision_set_similarity = safe_mean(
            jaccard_similarity(current.decision_set, item.decision_set) for item in history
        )
        action_sequence_similarity = safe_mean(
            sequence_similarity(current.action_sequence, item.action_sequence) for item in history
        )
        action_set_similarity = safe_mean(
            jaccard_similarity(current.action_set, item.action_set) for item in history
        )
        function_call_sequence_similarity = safe_mean(
            sequence_similarity(current.function_call_sequence, item.function_call_sequence)
            for item in history
        )
        function_call_set_similarity = safe_mean(
            jaccard_similarity(current.function_call_set, item.function_call_set) for item in history
        )
        function_argument_similarity = safe_mean(
            jaccard_similarity(current.function_argument_signatures, item.function_argument_signatures)
            for item in history
        )
        step_count_drift = normalized_deviation(
            current.step_count, [item.step_count for item in history]
        )
        latency_drift = normalized_deviation(current.latency_ms, [item.latency_ms for item in history])

        tool_sequence_score = 1 - tool_sequence_similarity
        prompt_score = 1 - prompt_alignment if current.prompt_signatures else 0.0
        model_score = 1 - model_alignment if current.model_set else 0.0
        decision_score = max(1 - decision_sequence_similarity, 1 - decision_set_similarity)
        action_score = max(1 - action_sequence_similarity, 1 - action_set_similarity)
        function_call_score = max(
            1 - function_call_sequence_similarity, 1 - function_call_set_similarity
        )
        function_arguments_score = 1 - function_argument_similarity

        if tool_sequence_score >= 0.35 or (1 - tool_set_similarity) >= 0.35:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="tool_sequence_drift",
                    severity=severity_from_score(max(tool_sequence_score, 1 - tool_set_similarity)),
                    score=round(max(tool_sequence_score, 1 - tool_set_similarity), 3),
                    title="Tool-chain drift detected",
                    summary="The workflow used a materially different tool path than its recent baseline.",
                    evidence={
                        "tool_sequence_similarity": round(tool_sequence_similarity, 3),
                        "tool_set_similarity": round(tool_set_similarity, 3),
                        "current_tool_sequence": current.tool_sequence,
                    },
                    recommended_actions=[
                        "Review planner and router prompts for unintended action changes.",
                        "Pin tool policy versions for production workflows with strict paths.",
                    ],
                )
            )

        if decision_score >= 0.35 and current.decision_sequence:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="decision_outcome_drift",
                    severity=severity_from_score(decision_score),
                    score=round(decision_score, 3),
                    title="Decision policy drift detected",
                    summary="The workflow is reaching materially different decision outcomes than its recent baseline.",
                    evidence={
                        "decision_sequence_similarity": round(decision_sequence_similarity, 3),
                        "decision_set_similarity": round(decision_set_similarity, 3),
                        "current_decisions": current.decision_sequence,
                        "baseline_decisions": dominant_sequence(
                            [item.decision_sequence for item in history]
                        ),
                    },
                    recommended_actions=[
                        "Inspect router and policy decision criteria, not just tool topology.",
                        "Pin decision policy versions and evaluate changed thresholds before deployment.",
                    ],
                )
            )

        if action_score >= 0.35 and current.action_sequence:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="action_route_drift",
                    severity=severity_from_score(action_score),
                    score=round(action_score, 3),
                    title="Action route drift detected",
                    summary="The workflow selected materially different actions or branches than its recent baseline.",
                    evidence={
                        "action_sequence_similarity": round(action_sequence_similarity, 3),
                        "action_set_similarity": round(action_set_similarity, 3),
                        "current_actions": current.action_sequence,
                        "baseline_actions": dominant_sequence(
                            [item.action_sequence for item in history]
                        ),
                    },
                    recommended_actions=[
                        "Review planner branch conditions and action-selection guards.",
                        "Add approval gates for route changes that alter external side effects.",
                    ],
                )
            )

        if function_call_score >= 0.35 and current.function_call_sequence:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="function_call_drift",
                    severity=severity_from_score(function_call_score),
                    score=round(function_call_score, 3),
                    title="Function-call drift detected",
                    summary="The workflow invoked a materially different function-call path than its recent baseline.",
                    evidence={
                        "function_call_sequence_similarity": round(
                            function_call_sequence_similarity, 3
                        ),
                        "function_call_set_similarity": round(function_call_set_similarity, 3),
                        "current_function_calls": current.function_call_sequence,
                        "baseline_function_calls": dominant_sequence(
                            [item.function_call_sequence for item in history]
                        ),
                    },
                    recommended_actions=[
                        "Inspect function router behavior and tool-to-function bindings.",
                        "Pin allowed function-call plans for production-grade agents.",
                    ],
                )
            )

        if function_arguments_score >= 0.4 and current.function_argument_signatures:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="function_arguments_drift",
                    severity=severity_from_score(function_arguments_score),
                    score=round(function_arguments_score, 3),
                    title="Function-argument drift detected",
                    summary="Function call shapes changed materially, indicating the agent is making different execution decisions.",
                    evidence={
                        "function_argument_similarity": round(function_argument_similarity, 3),
                        "current_function_argument_signatures": sorted(
                            current.function_argument_signatures
                        ),
                        "baseline_function_argument_signatures": dominant_values(
                            [item.function_argument_signatures for item in history]
                        ),
                    },
                    recommended_actions=[
                        "Validate argument contracts and side-effect scope before execution.",
                        "Add function-call schema guards for high-risk actions.",
                    ],
                )
            )

        if prompt_score >= 0.4:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="prompt_drift",
                    severity=severity_from_score(prompt_score),
                    score=round(prompt_score, 3),
                    title="Prompt drift detected",
                    summary="Prompt signatures do not align with the dominant recent baseline for this workflow.",
                    evidence={
                        "prompt_alignment": round(prompt_alignment, 3),
                        "current_prompts": sorted(current.prompt_signatures),
                    },
                    recommended_actions=[
                        "Treat prompt revisions as versioned releases with workflow-level approvals.",
                        "Compare the current prompt set against the last known stable run.",
                    ],
                )
            )

        if model_score >= 0.35:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="model_drift",
                    severity=severity_from_score(model_score),
                    score=round(model_score, 3),
                    title="Model drift detected",
                    summary="The workflow executed against a different model set than its recent baseline.",
                    evidence={
                        "model_alignment": round(model_alignment, 3),
                        "current_models": sorted(current.model_set),
                    },
                    recommended_actions=[
                        "Pin model versions per workflow tier instead of inheriting global defaults.",
                        "Re-baseline this workflow only after validating quality and latency.",
                    ],
                )
            )

        if step_count_drift >= 0.5:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.operational,
                    kind="step_count_regression",
                    severity=severity_from_score(step_count_drift),
                    score=round(step_count_drift, 3),
                    title="Step-count regression detected",
                    summary="The workflow used significantly more or fewer steps than its recent baseline.",
                    evidence={"current_step_count": current.step_count},
                    recommended_actions=[
                        "Inspect planner branching and retry loops.",
                        "Set hard caps for recursive planning and handoff depth.",
                    ],
                )
            )

        if latency_drift >= 0.6 and current.latency_ms > 0:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.operational,
                    kind="latency_regression",
                    severity=severity_from_score(latency_drift),
                    score=round(latency_drift, 3),
                    title="Latency regression detected",
                    summary="Execution latency deviated sharply from the recent workflow baseline.",
                    evidence={"latency_ms": current.latency_ms},
                    recommended_actions=[
                        "Inspect new tool dependencies and model routing choices.",
                        "Add SLA-aware policies for slow retrieval or retry-heavy branches.",
                    ],
                )
            )

        return signals
