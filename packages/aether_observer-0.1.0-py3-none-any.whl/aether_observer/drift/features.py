from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass
from difflib import SequenceMatcher
from hashlib import sha256
from statistics import mean
from typing import Any, Iterable

from aether_observer.models import Severity, StepKind, WorkflowRun, WorkflowStep


def stable_digest(value: Any) -> str:
    serialized = json.dumps(value, sort_keys=True, default=str)
    return sha256(serialized.encode("utf-8")).hexdigest()[:16]


def flatten_keys(value: Any, prefix: str = "") -> set[str]:
    keys: set[str] = set()
    if isinstance(value, dict):
        for key, nested in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            keys.add(path)
            keys.update(flatten_keys(nested, path))
    elif isinstance(value, list):
        keys.add(f"{prefix}[]" if prefix else "[]")
        for item in value:
            keys.update(flatten_keys(item, f"{prefix}[]" if prefix else "[]"))
    return keys


def payload_size(value: Any) -> int:
    if value is None:
        return 0
    return len(json.dumps(value, sort_keys=True, default=str))


def jaccard_similarity(left: Iterable[str], right: Iterable[str]) -> float:
    a = set(left)
    b = set(right)
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def sequence_similarity(left: list[str], right: list[str]) -> float:
    if not left and not right:
        return 1.0
    return SequenceMatcher(a=left, b=right).ratio()


def safe_mean(values: Iterable[float]) -> float:
    values_list = list(values)
    if not values_list:
        return 0.0
    return float(mean(values_list))


def dominant_ratio(current: set[str], history: list[set[str]]) -> float:
    if not current or not history:
        return 0.0
    counter = Counter(tuple(sorted(item)) for item in history if item)
    if not counter:
        return 0.0
    dominant, count = counter.most_common(1)[0]
    dominant_set = set(dominant)
    overlap = jaccard_similarity(current, dominant_set)
    return overlap * (count / len(history))


def normalized_deviation(value: float, baseline: list[float]) -> float:
    cleaned = [item for item in baseline if item >= 0]
    if not cleaned:
        return 0.0
    baseline_mean = safe_mean(cleaned)
    if baseline_mean == 0:
        return 0.0 if value == 0 else 1.0
    return min(abs(value - baseline_mean) / baseline_mean, 1.0)


def severity_from_score(score: float) -> Severity:
    if score >= 0.85:
        return Severity.critical
    if score >= 0.65:
        return Severity.high
    if score >= 0.4:
        return Severity.medium
    if score >= 0.2:
        return Severity.low
    return Severity.info


def prompt_signature(step: WorkflowStep) -> str | None:
    if step.prompt_version:
        return step.prompt_version
    if step.prompt_name:
        return step.prompt_name
    if step.prompt_text:
        return stable_digest(step.prompt_text)
    return None


def infer_step_decision(step: WorkflowStep) -> str | None:
    if step.decision_name or step.decision_value:
        decision_name = step.decision_name or step.name
        decision_value = step.decision_value or step.selected_action or "unknown"
        return f"{decision_name}:{decision_value}"

    if isinstance(step.output_payload, dict):
        for key in ("decision", "route", "selected_action", "action", "verdict", "outcome"):
            if key in step.output_payload:
                return f"{step.name}:{key}={step.output_payload[key]}"
    return None


def infer_step_action(step: WorkflowStep) -> str | None:
    if step.selected_action:
        return step.selected_action
    if step.tool_name:
        return step.tool_name
    if step.kind in {StepKind.handoff, StepKind.guardrail, StepKind.retrieval}:
        return f"{step.kind.value}:{step.name}"
    return None


def function_argument_keys(arguments: dict[str, Any]) -> list[str]:
    return sorted(flatten_keys(arguments))


def function_call_signature(step: WorkflowStep) -> list[str]:
    signatures: list[str] = []
    if step.function_calls:
        for call in step.function_calls:
            arg_keys = function_argument_keys(call.arguments)
            schema = ",".join(arg_keys) if arg_keys else "no_args"
            signatures.append(f"{call.function_name}({schema})")
        return signatures

    if step.tool_name:
        arg_keys = function_argument_keys(step.input_payload) if isinstance(step.input_payload, dict) else []
        schema = ",".join(arg_keys) if arg_keys else "no_args"
        signatures.append(f"{step.tool_name}({schema})")
    return signatures


def function_argument_signature(step: WorkflowStep) -> list[str]:
    signatures: list[str] = []
    if step.function_calls:
        for call in step.function_calls:
            arg_keys = function_argument_keys(call.arguments)
            schema = ",".join(arg_keys) if arg_keys else "no_args"
            signatures.append(f"{call.function_name}:{schema}")
        return signatures

    if step.tool_name:
        arg_keys = function_argument_keys(step.input_payload) if isinstance(step.input_payload, dict) else []
        schema = ",".join(arg_keys) if arg_keys else "no_args"
        signatures.append(f"{step.tool_name}:{schema}")
    return signatures


def infer_run_decision(run: WorkflowRun) -> str | None:
    if isinstance(run.output_payload, dict):
        for key in ("decision", "route", "selected_action", "action", "verdict", "outcome"):
            if key in run.output_payload:
                return f"run:{key}={run.output_payload[key]}"
    return None


def dominant_sequence(history: list[list[str]]) -> list[str]:
    counter = Counter(tuple(item) for item in history if item)
    if not counter:
        return []
    return list(counter.most_common(1)[0][0])


def dominant_values(history: list[set[str]]) -> list[str]:
    counter = Counter(tuple(sorted(item)) for item in history if item)
    if not counter:
        return []
    return list(counter.most_common(1)[0][0])


@dataclass
class WorkflowFeatures:
    tool_sequence: list[str]
    tool_set: set[str]
    prompt_signatures: set[str]
    model_set: set[str]
    decision_sequence: list[str]
    decision_set: set[str]
    action_sequence: list[str]
    action_set: set[str]
    function_call_sequence: list[str]
    function_call_set: set[str]
    function_argument_signatures: set[str]
    input_schema: set[str]
    output_schema: set[str]
    dataset_signatures: set[str]
    step_count: int
    llm_step_count: int
    tool_step_count: int
    retrieval_step_count: int
    error_step_count: int
    latency_ms: int
    input_size: int
    output_size: int


def build_features(run: WorkflowRun) -> WorkflowFeatures:
    tool_sequence: list[str] = []
    tool_set: set[str] = set()
    prompt_signatures: set[str] = set()
    model_set: set[str] = set()
    decision_sequence: list[str] = []
    decision_set: set[str] = set()
    action_sequence: list[str] = []
    action_set: set[str] = set()
    function_call_sequence: list[str] = []
    function_call_set: set[str] = set()
    function_argument_signatures: set[str] = set()
    dataset_signatures: set[str] = set()
    llm_step_count = 0
    tool_step_count = 0
    retrieval_step_count = 0
    error_step_count = 0

    for dataset in run.datasets:
        dataset_signatures.add(f"{dataset.name}:{dataset.version}:{dataset.schema_hash}")

    for step in run.steps:
        if step.tool_name:
            tool_sequence.append(step.tool_name)
            tool_set.add(step.tool_name)
        else:
            tool_sequence.append(step.kind.value)

        signature = prompt_signature(step)
        if signature:
            prompt_signatures.add(signature)
        if step.model:
            model_set.add(step.model)

        decision = infer_step_decision(step)
        if decision:
            decision_sequence.append(decision)
            decision_set.add(decision)

        action = infer_step_action(step)
        if action:
            action_sequence.append(action)
            action_set.add(action)

        for signature in function_call_signature(step):
            function_call_sequence.append(signature)
            function_call_set.add(signature)

        for signature in function_argument_signature(step):
            function_argument_signatures.add(signature)

        for dataset in step.datasets:
            dataset_signatures.add(f"{dataset.name}:{dataset.version}:{dataset.schema_hash}")

        if step.kind == StepKind.llm:
            llm_step_count += 1
        if step.kind == StepKind.tool:
            tool_step_count += 1
        if step.kind == StepKind.retrieval:
            retrieval_step_count += 1
        if step.status.value != "success":
            error_step_count += 1

    total_latency = sum(step.latency_ms or 0 for step in run.steps)
    if total_latency == 0 and run.finished_at is not None:
        total_latency = int((run.finished_at - run.started_at).total_seconds() * 1000)

    run_decision = infer_run_decision(run)
    if run_decision:
        decision_sequence.append(run_decision)
        decision_set.add(run_decision)

    return WorkflowFeatures(
        tool_sequence=tool_sequence,
        tool_set=tool_set,
        prompt_signatures=prompt_signatures,
        model_set=model_set,
        decision_sequence=decision_sequence,
        decision_set=decision_set,
        action_sequence=action_sequence,
        action_set=action_set,
        function_call_sequence=function_call_sequence,
        function_call_set=function_call_set,
        function_argument_signatures=function_argument_signatures,
        input_schema=flatten_keys(run.input_payload),
        output_schema=flatten_keys(run.output_payload),
        dataset_signatures=dataset_signatures,
        step_count=len(run.steps),
        llm_step_count=llm_step_count,
        tool_step_count=tool_step_count,
        retrieval_step_count=retrieval_step_count,
        error_step_count=error_step_count,
        latency_ms=total_latency,
        input_size=payload_size(run.input_payload),
        output_size=payload_size(run.output_payload),
    )
