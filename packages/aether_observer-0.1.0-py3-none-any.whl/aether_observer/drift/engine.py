from __future__ import annotations

from aether_observer.drift.agentic import AgenticDriftDetector
from aether_observer.drift.data import DataDriftDetector
from aether_observer.drift.graph_native import GraphNativeDriftDetector
from aether_observer.drift.features import build_features, safe_mean, severity_from_score
from aether_observer.models import DriftAssessment, WorkflowGraphView, WorkflowRun


class DriftEngine:
    def __init__(
        self,
        data_detector: DataDriftDetector | None = None,
        agentic_detector: AgenticDriftDetector | None = None,
        graph_detector: GraphNativeDriftDetector | None = None,
    ) -> None:
        self.data_detector = data_detector or DataDriftDetector()
        self.agentic_detector = agentic_detector or AgenticDriftDetector()
        self.graph_detector = graph_detector or GraphNativeDriftDetector()

    def evaluate(
        self,
        current: WorkflowRun,
        history: list[WorkflowRun],
        *,
        current_graph: WorkflowGraphView | None = None,
        history_graphs: list[WorkflowGraphView] | None = None,
    ) -> DriftAssessment:
        baseline = [build_features(item) for item in history]
        current_features = build_features(current)

        signals = self.data_detector.detect(current_features, baseline)
        signals.extend(self.agentic_detector.detect(current_features, baseline))
        if current_graph is not None and history_graphs:
            signals.extend(self.graph_detector.detect(current_graph, history_graphs))

        risk_score = safe_mean(signal.score for signal in signals)
        severity = severity_from_score(risk_score)

        return DriftAssessment(
            baseline_run_count=len(history),
            risk_score=round(risk_score, 3),
            severity=severity,
            signals=sorted(signals, key=lambda item: item.score, reverse=True),
        )
