from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import math

from aether_observer.drift.features import jaccard_similarity, normalized_deviation, safe_mean, severity_from_score
from aether_observer.models import DriftSignal, DriftType, GraphNodeView, WorkflowGraphView

STRUCTURAL_RELATIONS = {
    "HAS_STEP",
    "EXECUTED_WITH_MODEL",
    "USED_STEP_PROMPT",
    "USED_STEP_TOOL",
    "MADE_DECISION",
    "SELECTED_ACTION",
    "CONSIDERED_ACTION",
    "CALLED_FUNCTION",
    "USED_ARGUMENT_SHAPE",
    "STEP_CONSUMED_DATASET",
    "FINAL_DECISION",
}

STEP_RELATIONS = STRUCTURAL_RELATIONS - {"HAS_STEP", "FINAL_DECISION"}


@dataclass
class GraphSnapshot:
    relation_set: set[str]
    edge_type_set: set[str]
    path_signatures: set[str]
    step_motifs: set[str]
    node_count: int
    edge_count: int


class GraphNativeDriftDetector:
    def detect(
        self,
        current: WorkflowGraphView,
        history: list[WorkflowGraphView],
    ) -> list[DriftSignal]:
        if not history:
            return []

        current_snapshot = snapshot_graph(current)
        history_snapshots = [snapshot_graph(item) for item in history if item.nodes or item.edges]
        if not history_snapshots:
            return []

        signals: list[DriftSignal] = []

        relation_similarity = safe_mean(
            jaccard_similarity(current_snapshot.relation_set, item.relation_set)
            for item in history_snapshots
        )
        edge_type_similarity = safe_mean(
            jaccard_similarity(current_snapshot.edge_type_set, item.edge_type_set)
            for item in history_snapshots
        )
        path_similarity = safe_mean(
            jaccard_similarity(current_snapshot.path_signatures, item.path_signatures)
            for item in history_snapshots
        )
        motif_similarity = safe_mean(
            jaccard_similarity(current_snapshot.step_motifs, item.step_motifs)
            for item in history_snapshots
        )
        node_count_drift = normalized_deviation(
            current_snapshot.node_count, [item.node_count for item in history_snapshots]
        )
        edge_count_drift = normalized_deviation(
            current_snapshot.edge_count, [item.edge_count for item in history_snapshots]
        )

        topology_score = max(
            1 - relation_similarity,
            1 - edge_type_similarity,
            1 - path_similarity,
        )
        motif_score = 1 - motif_similarity if current_snapshot.step_motifs else 0.0
        volume_score = max(node_count_drift, edge_count_drift)

        expected_paths = frequent_signatures(
            [item.path_signatures for item in history_snapshots],
            len(history_snapshots),
        )
        current_paths = current_snapshot.path_signatures
        missing_paths = sorted(expected_paths - current_paths)
        novel_paths = sorted(current_paths - expected_paths)
        missing_ratio = len(missing_paths) / len(expected_paths) if expected_paths else 0.0
        novel_ratio = len(novel_paths) / len(current_paths) if current_paths else 0.0

        expected_motifs = frequent_signatures(
            [item.step_motifs for item in history_snapshots],
            len(history_snapshots),
        )

        if topology_score >= 0.35:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="graph_topology_drift",
                    severity=severity_from_score(topology_score),
                    score=round(topology_score, 3),
                    title="Graph topology drift detected",
                    summary=(
                        "The persisted workflow subgraph no longer matches the dominant "
                        "structural shape of recent runs."
                    ),
                    evidence={
                        "relation_similarity": round(relation_similarity, 3),
                        "edge_type_similarity": round(edge_type_similarity, 3),
                        "path_similarity": round(path_similarity, 3),
                        "current_relations": sorted(current_snapshot.relation_set),
                        "current_edge_types": sorted(current_snapshot.edge_type_set),
                        "current_path_signatures": sorted(current_snapshot.path_signatures),
                        "baseline_relations": sorted(
                            frequent_signatures(
                                [item.relation_set for item in history_snapshots],
                                len(history_snapshots),
                            )
                        ),
                        "baseline_edge_types": sorted(
                            frequent_signatures(
                                [item.edge_type_set for item in history_snapshots],
                                len(history_snapshots),
                            )
                        ),
                        "baseline_path_signatures": sorted(expected_paths),
                    },
                    recommended_actions=[
                        "Review the workflow graph delta, not just flat tool sequences.",
                        "Re-baseline only after confirming the new topology is an intentional release.",
                    ],
                )
            )

        if motif_score >= 0.35 and current_snapshot.step_motifs:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="graph_motif_drift",
                    severity=severity_from_score(motif_score),
                    score=round(motif_score, 3),
                    title="Graph motif drift detected",
                    summary=(
                        "Step-level decision/action/function motifs changed materially relative to "
                        "recent workflow graphs."
                    ),
                    evidence={
                        "motif_similarity": round(motif_similarity, 3),
                        "current_step_motifs": sorted(current_snapshot.step_motifs),
                        "baseline_step_motifs": sorted(expected_motifs),
                    },
                    recommended_actions=[
                        "Inspect which step motifs changed before approving the new run path.",
                        "Use guardrails to pin high-risk decision and function motifs in production.",
                    ],
                )
            )

        if missing_ratio >= 0.25 and missing_paths:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="missing_expected_relation",
                    severity=severity_from_score(missing_ratio),
                    score=round(missing_ratio, 3),
                    title="Expected graph relations missing",
                    summary=(
                        "The current run is missing path relations that appear consistently in the "
                        "baseline workflow graph."
                    ),
                    evidence={
                        "missing_ratio": round(missing_ratio, 3),
                        "missing_path_signatures": missing_paths,
                        "baseline_path_signatures": sorted(expected_paths),
                        "current_path_signatures": sorted(current_paths),
                    },
                    recommended_actions=[
                        "Check whether the run skipped required planner, tool, or function edges.",
                        "Block releases that remove expected graph paths without approval.",
                    ],
                )
            )

        if novel_ratio >= 0.25 and novel_paths:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.agentic,
                    kind="new_relation_drift",
                    severity=severity_from_score(novel_ratio),
                    score=round(novel_ratio, 3),
                    title="New graph relations detected",
                    summary=(
                        "The current run introduced new workflow graph paths that do not exist in "
                        "the recent baseline."
                    ),
                    evidence={
                        "new_ratio": round(novel_ratio, 3),
                        "new_path_signatures": novel_paths,
                        "baseline_path_signatures": sorted(expected_paths),
                        "current_path_signatures": sorted(current_paths),
                    },
                    recommended_actions=[
                        "Review the newly introduced graph edges before promoting this workflow version.",
                        "Add explicit guardrails for novel actions and function-call branches.",
                    ],
                )
            )

        if volume_score >= 0.5:
            signals.append(
                DriftSignal(
                    drift_type=DriftType.operational,
                    kind="graph_volume_drift",
                    severity=severity_from_score(volume_score),
                    score=round(volume_score, 3),
                    title="Graph volume drift detected",
                    summary=(
                        "The current run produced a materially different graph size than recent runs, "
                        "which often signals skipped or repeated execution branches."
                    ),
                    evidence={
                        "node_count": current_snapshot.node_count,
                        "edge_count": current_snapshot.edge_count,
                        "node_count_drift": round(node_count_drift, 3),
                        "edge_count_drift": round(edge_count_drift, 3),
                        "baseline_mean_node_count": round(
                            safe_mean(item.node_count for item in history_snapshots), 1
                        ),
                        "baseline_mean_edge_count": round(
                            safe_mean(item.edge_count for item in history_snapshots), 1
                        ),
                    },
                    recommended_actions=[
                        "Inspect repeated branches, retries, or missing segments in the workflow graph.",
                        "Set graph-level step and branch budgets for high-risk agent flows.",
                    ],
                )
            )

        return signals


def frequent_signatures(history: list[set[str]], history_count: int) -> set[str]:
    if not history or history_count <= 0:
        return set()
    counter = Counter(signature for item in history for signature in item)
    threshold = max(1, math.ceil(history_count / 2))
    return {signature for signature, count in counter.items() if count >= threshold}


def snapshot_graph(graph: WorkflowGraphView) -> GraphSnapshot:
    node_map = {node.uuid: node for node in graph.nodes}
    outgoing: dict[str, list] = defaultdict(list)
    relation_set: set[str] = set()
    edge_type_set: set[str] = set()

    for edge in graph.edges:
        source = node_map.get(edge.source)
        target = node_map.get(edge.target)
        if source is None or target is None or edge.relation not in STRUCTURAL_RELATIONS:
            continue
        outgoing[edge.source].append(edge)
        relation_set.add(edge.relation)
        edge_type_set.add(f"{source.kind}:{edge.relation}:{target.kind}")

    path_signatures: set[str] = set()
    step_motifs: set[str] = set()

    for node in graph.nodes:
        if node.kind != "Run":
            continue
        for edge in outgoing.get(node.uuid, []):
            target = node_map.get(edge.target)
            if target is None:
                continue
            if edge.relation == "HAS_STEP" and target.kind == "Step":
                step_token = step_identity(target)
                path_signatures.add(f"Run->{edge.relation}->{step_token}")
                motif_components: list[str] = []
                for child_edge in outgoing.get(target.uuid, []):
                    if child_edge.relation not in STEP_RELATIONS:
                        continue
                    child = node_map.get(child_edge.target)
                    if child is None:
                        continue
                    child_token = node_identity(child)
                    path_signatures.add(
                        f"{step_token}->{child_edge.relation}->{child_token}"
                    )
                    motif_components.append(f"{child_edge.relation}={child_token}")
                step_motifs.add(
                    f"{step_token}|{'|'.join(sorted(set(motif_components))) if motif_components else 'no-structural-edges'}"
                )
                continue
            path_signatures.add(
                f"Run->{edge.relation}->{node_identity(target)}"
            )

    filtered_edge_count = sum(1 for edge in graph.edges if edge.relation in STRUCTURAL_RELATIONS)
    return GraphSnapshot(
        relation_set=relation_set,
        edge_type_set=edge_type_set,
        path_signatures=path_signatures,
        step_motifs=step_motifs,
        node_count=len(graph.nodes),
        edge_count=filtered_edge_count,
    )


def step_identity(node: GraphNodeView) -> str:
    step_id = str(node.attributes.get("step_id") or node.label)
    step_name = str(node.attributes.get("step_name") or node.label)
    step_kind = str(node.attributes.get("step_kind") or node.kind)
    return f"Step:{step_id}:{step_name}:{step_kind}"


def node_identity(node: GraphNodeView) -> str:
    if node.kind == "Step":
        return step_identity(node)
    attributes = node.attributes or {}
    if node.kind == "Decision":
        decision_name = attributes.get("decision_name") or node.label
        decision_value = attributes.get("decision_value") or node.label
        return f"Decision:{decision_name}:{decision_value}"
    if node.kind == "Action":
        action_name = attributes.get("action_name") or node.label
        return f"Action:{action_name}"
    if node.kind == "Function":
        function_name = attributes.get("function_name") or node.label
        return f"Function:{function_name}"
    if node.kind == "FunctionArguments":
        argument_signature = attributes.get("argument_signature") or node.label
        return f"FunctionArguments:{argument_signature}"
    if node.kind == "Dataset":
        dataset_name = attributes.get("dataset_name") or node.label
        dataset_version = attributes.get("dataset_version") or "unknown"
        return f"Dataset:{dataset_name}:{dataset_version}"
    if node.kind == "Model":
        model_id = attributes.get("model_id") or node.label
        return f"Model:{model_id}"
    if node.kind == "Prompt":
        prompt_name = attributes.get("prompt_name") or node.label
        prompt_version = attributes.get("prompt_version") or node.label
        return f"Prompt:{prompt_name}:{prompt_version}"
    if node.kind == "Tool":
        tool_name = attributes.get("tool_name") or node.label
        return f"Tool:{tool_name}"
    return f"{node.kind}:{node.label}"
