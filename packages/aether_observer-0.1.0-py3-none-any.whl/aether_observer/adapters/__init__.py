from aether_observer.adapters.base import BaseWorkflowAdapter
from aether_observer.adapters.generic import GenericWorkflowAdapter


def default_adapters() -> dict[str, BaseWorkflowAdapter]:
    adapter = GenericWorkflowAdapter()
    return {adapter.name: adapter}


__all__ = ["BaseWorkflowAdapter", "GenericWorkflowAdapter", "default_adapters"]
