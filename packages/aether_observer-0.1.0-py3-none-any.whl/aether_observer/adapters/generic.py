from __future__ import annotations

from typing import Any, Mapping

from aether_observer.adapters.base import BaseWorkflowAdapter
from aether_observer.models import WorkflowRun


class GenericWorkflowAdapter(BaseWorkflowAdapter):
    name = "generic"

    def normalize(self, payload: Mapping[str, Any] | WorkflowRun) -> WorkflowRun:
        if isinstance(payload, WorkflowRun):
            return payload
        return WorkflowRun.model_validate(payload)
