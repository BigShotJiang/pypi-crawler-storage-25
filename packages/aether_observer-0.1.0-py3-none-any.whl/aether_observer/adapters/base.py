from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Mapping

from aether_observer.models import WorkflowRun


class BaseWorkflowAdapter(ABC):
    name: str

    @abstractmethod
    def normalize(self, payload: Mapping[str, Any] | WorkflowRun) -> WorkflowRun:
        raise NotImplementedError
