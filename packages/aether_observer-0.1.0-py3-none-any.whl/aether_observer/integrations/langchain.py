from __future__ import annotations

from typing import Any

from aether_observer.sdk import log, log_step

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError:  # pragma: no cover - optional dependency
    class BaseCallbackHandler:  # type: ignore[override]
        """Fallback base class when LangChain is not installed."""

        raise_error = False
        run_inline = True


class AetherLangChainHandler(BaseCallbackHandler):
    """LangChain callback bridge for Aether's W&B-style SDK surface."""

    raise_error = False
    run_inline = True

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        **kwargs: Any,
    ) -> None:
        log(
            {
                "serialized": serialized,
                "langchain_event": "chain_start",
                "langchain_run_id": str(kwargs.get("run_id", "")),
                "parent_run_id": str(kwargs.get("parent_run_id", "")),
                "tags": kwargs.get("tags", []),
            },
            name=serialized.get("name", "chain_start"),
            kind="system",
            input_payload=inputs,
        )

    def on_chain_end(self, outputs: dict[str, Any], **kwargs: Any) -> None:
        log(
            {
                "langchain_event": "chain_end",
                "langchain_run_id": str(kwargs.get("run_id", "")),
            },
            name="chain_end",
            kind="system",
            output_payload=outputs,
        )

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        **kwargs: Any,
    ) -> None:
        log_step(
            name=serialized.get("name", "llm"),
            kind="llm",
            prompt_text="\n\n".join(prompts),
            metadata={
                "serialized": serialized,
                "langchain_event": "llm_start",
                "langchain_run_id": str(kwargs.get("run_id", "")),
                "invocation_params": kwargs.get("invocation_params", {}),
            },
        )

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        generations = getattr(response, "generations", None)
        output_payload = {
            "generations": generations,
            "llm_output": getattr(response, "llm_output", None),
        }
        log(
            {
                "langchain_event": "llm_end",
                "langchain_run_id": str(kwargs.get("run_id", "")),
            },
            name="llm_end",
            kind="llm",
            output_payload=output_payload,
        )

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        log_step(
            name=serialized.get("name", "tool"),
            kind="tool",
            tool_name=serialized.get("name"),
            input_payload={"input": input_str},
            metadata={
                "serialized": serialized,
                "langchain_event": "tool_start",
                "langchain_run_id": str(kwargs.get("run_id", "")),
            },
        )

    def on_tool_end(self, output: Any, **kwargs: Any) -> None:
        log(
            {
                "langchain_event": "tool_end",
                "langchain_run_id": str(kwargs.get("run_id", "")),
            },
            name="tool_end",
            kind="tool",
            output_payload={"output": output},
        )

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        log(
            {
                "tool": getattr(action, "tool", None),
                "tool_input": getattr(action, "tool_input", None),
                "log": getattr(action, "log", None),
                "langchain_event": "agent_action",
                "langchain_run_id": str(kwargs.get("run_id", "")),
            },
            name="agent_action",
            kind="handoff",
        )

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        log(
            {
                "return_values": getattr(finish, "return_values", None),
                "log": getattr(finish, "log", None),
                "langchain_event": "agent_finish",
                "langchain_run_id": str(kwargs.get("run_id", "")),
            },
            name="agent_finish",
            kind="handoff",
        )

    def on_retriever_start(
        self,
        serialized: dict[str, Any],
        query: str,
        **kwargs: Any,
    ) -> None:
        log_step(
            name=serialized.get("name", "retriever"),
            kind="retrieval",
            input_payload={"query": query},
            metadata={
                "serialized": serialized,
                "langchain_event": "retriever_start",
                "langchain_run_id": str(kwargs.get("run_id", "")),
            },
        )

    def on_retriever_end(self, documents: list[Any], **kwargs: Any) -> None:
        log(
            {
                "langchain_event": "retriever_end",
                "langchain_run_id": str(kwargs.get("run_id", "")),
                "document_count": len(documents),
            },
            name="retriever_end",
            kind="retrieval",
            output_payload={"documents": documents},
        )
