import shutil
import tempfile
from typing import Callable, List, Union

import sh

# from ..editors import SectionHeaderEditor
from ..constants import SECTION
from ..util import readelf_hexdump_to_bytearray
from ..core.elf import Elf


class SectionEditor:
    elf: Elf
    name: str
    tag: SECTION
    # readsection: Callable

    def __init__(self, elf: Elf, section: SECTION):
        self.elf = elf
        self.name = section.value
        self.tag = section
        # self.readsection = elf.readelf.bake(x=self.name)
        # self.readsection = elf.readelf.bake(x=1)

    def readelf_dump_section(self, rev_idx: int = -1) -> str | None:
        # readelf rarely fails; retry once then give up.
        for _ in range(2):
            try:
                return self.elf.readelf(self.elf.revisions[rev_idx], x=self.name)
            except sh.ErrorReturnCode:
                pass
        return None

    def read_content(self, rev_idx: int = -1, no_ext_checking: bool = False) -> bytearray | None:
        from .section_header_editor import SectionHeaderEditor

        if not no_ext_checking and not SectionHeaderEditor(self.elf).read_section_header(self.tag, rev_idx=rev_idx):
            return

        rev = self.elf.revisions[rev_idx]
        cache = self.elf.get_cache(rev, 'sec: ' + str(self.tag))

        if content := cache.lookup():
            return content

        if self.name == str(SECTION.SHSTRTAB):
            # Unfortunately, objdump cannot dump .shstrtab
            # print(f'readelf hexdump (with {self.readsection}): \n{self.readsection(rev)}')
            if not (readelf_dump := self.readelf_dump_section(rev_idx)):
                return
            content = readelf_hexdump_to_bytearray(readelf_dump)
            cache.update(content)
            return content

        tmpf = tempfile.mktemp(suffix=self.name, dir=self.elf.workdir.name)

        try:
            self.elf.objcopy('--dump-section', self.name + '=' + tmpf, rev)

            with open(tmpf, 'rb') as f:
                content = bytearray(f.read())
        except (FileNotFoundError, sh.ErrorReturnCode):
            if not (readelf_dump := self.readelf_dump_section(rev_idx)):
                return
            content = readelf_hexdump_to_bytearray(readelf_dump)
            cache.update(content)
            return content

        cache.update(content)

        return content

    def write_content(self, content: bytes):
        from .section_header_editor import SectionHeaderEditor

        current_rev = self.elf.get_current_revision()
        next_rev = tempfile.mktemp(dir=self.elf.workdir.name)

        curr_content = self.read_content() or b''

        if (len(content) > 0
            and len(content) == len(curr_content)
            and (she := SectionHeaderEditor(self.elf))
            and (sh := she.read_section_header(self.tag))):
            # she: SectionHeaderEditor = self.elf.get_editor(EDITOR.SECTION_HEADER)
            shutil.copy2(current_rev, next_rev)
            with open(next_rev, 'r+b') as f:
                f.seek(sh.offset)
                f.write(content)
        else:
            tmpf = tempfile.mktemp(suffix=self.name, dir=self.elf.workdir.name)

            with open(tmpf, 'wb') as f:
                f.write(content)

            self.elf.objcopy('--update-section', self.name + '=' + tmpf,
                             current_rev, next_rev)

        self.elf.revisions.append(next_rev)

    def find(self, target: Union[bytes, str]) -> int:
        if isinstance(target, str):
            target = target.encode('ascii')

        if not (curr_content := self.read_content()):
            return -1

        return curr_content.find(target)

    def __str__(self):
        return self.name
