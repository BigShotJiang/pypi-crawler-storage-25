# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2026-03-25
### Added
- Initial release of the `llm-cache-lite` library.
- SQLite backend for local caching (`SQLiteBackend`).
- Universal `@llm_cache` decorator for zero-boilerplate integration with any LLM function.
- `CacheSettings` using Pydantic for strict type validation.

## [0.2.0] - 2026-03-28
### Added
- Implement TTL (Time-To-Live) support to automatically expire old cache entries.

## [0.2.1] - 2026-03-29
### Changed
- Replace print statements with standard logging

## [0.3.0] - 2026-04-04
### Added
- Add native async/await support