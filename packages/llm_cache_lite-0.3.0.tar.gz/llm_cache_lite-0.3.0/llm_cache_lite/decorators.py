"""
Core decorators for llm-cache-lite.
Provides the @llm_cache decorator to seamlessly cache LLM function responses.
"""

import functools
import inspect
import json
import logging
from typing import Callable, Any, Optional
from .cache import SQLiteBackend
from .config import CacheSettings

logger = logging.getLogger(__name__)

def llm_cache(settings: Optional[CacheSettings] = None) -> Callable:
    """
    A decorator that caches the return value of any LLM function.
    It automatically generates a unique cache key based on function name and its arguments.

    Arg:
    settings (Optional[CacheSettings], optional): Configuration for the database path and TTL.
            If not provided, default settings are used.
    """

    # Initialize the database backend once per decorated function
    backend = SQLiteBackend(settings=settings)
    def decorator(func: Callable) -> Callable:
        if inspect.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs) -> Any:
                # Serialize arguments to create a unique fingerprint for this exact call
                call_details = {
                    "func": func.__name__,
                    "args": [str(arg) for arg in args],
                    "kwargs": {k: str(v) for k, v in kwargs.items()},
                }

                # Create a string representation to use as the prompt/key
                prompt_key = json.dumps(call_details, sort_keys=True)
                cached_result = backend.get(prompt=prompt_key)
                if cached_result:
                    logger.debug(f"Cache hit for async '{func.__name__}'!")
                    return cached_result
                logger.debug(f"Cache miss. Executing async '{func.__name__}'!")
                result = await func(*args, **kwargs)
                if isinstance(result, str):
                    backend.set(prompt=prompt_key, response=result)
                else:
                    logger.warning(f"Warning: Could not cache result of '{func.__name__}'!"
                                   f"Expected a string return type.")
                return result

            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                # Serialize arguments to create a unique fingerprint for this exact call
                call_details = {
                    "func": func.__name__,
                    "args": [str(arg) for arg in args],
                    "kwargs": {k: str(v) for k, v in kwargs.items()},
                }

                # Create a string representation to use as the prompt/key
                prompt_key = json.dumps(call_details, sort_keys=True)
                cached_result = backend.get(prompt=prompt_key)
                if cached_result:
                    logger.debug(f"Cache hit for '{func.__name__}'!")
                    return cached_result
                logger.debug(f"Cache miss. Executing '{func.__name__}'!")
                result = func(*args, **kwargs)
                if isinstance(result, str):
                    backend.set(prompt=prompt_key, response=result)
                else:
                    logger.warning(f"Warning: Could not cache result of '{func.__name__}'!"
                          f"Expected a string return type.")
                return result
            return sync_wrapper
    return decorator
