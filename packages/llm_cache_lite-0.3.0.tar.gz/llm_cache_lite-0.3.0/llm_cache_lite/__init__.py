"""
llm-cache-lite
A lightweight, decorator-based caching library for LLM API calls.
"""

from importlib.metadata import version, PackageNotFoundError
from .decorators import llm_cache
from .config import CacheSettings

try:
    __version__ = version("llm-cache-lite")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["llm_cache", "CacheSettings", "__version__"]
