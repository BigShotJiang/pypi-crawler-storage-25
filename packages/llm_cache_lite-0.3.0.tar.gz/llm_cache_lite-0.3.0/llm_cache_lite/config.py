"""
Configuration models for llm-cache-lite.
Uses Pydantic for robust type checking and validation of cache settings.
"""

from pydantic import BaseModel, Field

class CacheSettings(BaseModel):
    """
    Settings for configuring the LLM cache behavior.
    Automatically validates types and values upon instantiation.
    """
    db_path: str = Field(
        default="llm_cache.db",
        description="The file path to the SQLite database used for caching."
    )
    ttl_seconds: int = Field(
        default=0,
        ge=0,
        description="Time to live in seconds"
    )
