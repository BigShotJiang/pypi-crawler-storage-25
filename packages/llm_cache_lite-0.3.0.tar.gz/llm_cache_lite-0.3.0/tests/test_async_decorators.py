"""
Unit tests for the asynchronous support of the caching decorators.
Ensures that the @llm_cache decorator correctly intercepts calls,
stores results, respects TTL, and prevents redundant executions.
"""

import pytest
import asyncio
from unittest.mock import AsyncMock

from llm_cache_lite import llm_cache, CacheSettings

@pytest.fixture
def settings():
    """
    Provide test settings with an in-memory SQLite database for speed
    and a short TTL (1 second) to test cache expiration.
    """
    return CacheSettings(db_path=":memory:", ttl_seconds=1)

@pytest.mark.asyncio
async def test_async_llm_cache(settings):
    """
        Test that the llm_cache decorator correctly handles async functions.
    """
    # Create an async AI call
    mock_api_call = AsyncMock(return_value="Async response")

    @llm_cache(settings=settings)
    async def dummy_async_ai_function(prompt: str) -> str:
        return await mock_api_call(prompt)

    # First call: Cache is empty, should execute the mock API
    result = await dummy_async_ai_function("Async request?")
    assert result == "Async response"
    assert mock_api_call.call_count == 1

    # Second call: Should hit the cache, call_count remains 1
    result2 = await dummy_async_ai_function("Async request?")
    assert result2 == "Async response"
    assert mock_api_call.call_count == 1

    # Wait for the TTL to expire
    await asyncio.sleep(2)

    # Third call: Cache expired, should execute the mock API again
    result3 = await dummy_async_ai_function("Async request?")
    assert result3 == "Async response"
    assert mock_api_call.call_count == 2
