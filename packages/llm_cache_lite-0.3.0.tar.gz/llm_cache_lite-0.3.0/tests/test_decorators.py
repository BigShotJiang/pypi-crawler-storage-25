"""
Unit tests for the caching decorators.
Ensures that the @llm_cache decorator correctly intercepts calls,
stores results, respects TTL, and prevents redundant executions.
"""
import time
from unittest.mock import MagicMock
from llm_cache_lite import llm_cache, CacheSettings

test_settings = CacheSettings(db_path=":memory:")

def test_llm_cache_decorator():
    """
        Test the core caching logic of the @llm_cache decorator.

        Verifies that:
        1. The first call executes the underlying function (cache miss).
        2. The second call executes the underlying function (cache hit).
        3. A call with different arguments executes the function again.
    """
    mock_api_call = MagicMock(return_value="Mocked AI Response")
    @llm_cache(settings=test_settings)
    def dummy_ai_function(prompt: str) -> str:
        return mock_api_call(prompt)

    result1 = dummy_ai_function(prompt="Hello ai")
    assert result1 == "Mocked AI Response"
    assert mock_api_call.call_count == 1

    result2 = dummy_ai_function(prompt="Hello ai")
    assert result2 == "Mocked AI Response"
    assert mock_api_call.call_count == 1

    result3 = dummy_ai_function(prompt="What is the weather?")
    assert result3 == "Mocked AI Response"
    assert mock_api_call.call_count == 2

def test_ttl_expiration():

    test_settings_ttl = CacheSettings(db_path=":memory:", ttl_seconds=1)
    mock_api_call = MagicMock(return_value="Mocked AI Response")

    @llm_cache(settings=test_settings_ttl)
    def dummy_ai_function(prompt: str) -> str:
        return mock_api_call(prompt)

    # First call
    dummy_ai_function(prompt="Hello ai, Check the Time")
    assert mock_api_call.call_count == 1

    # Return from cache
    dummy_ai_function(prompt="Hello ai, Check the Time")
    assert mock_api_call.call_count == 1

    # Wait for the cache to expire
    time.sleep(3)

    # Third call after expiration
    dummy_ai_function(prompt="Hello ai, Check the Time")
    assert mock_api_call.call_count == 2
