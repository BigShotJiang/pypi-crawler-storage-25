import os
from pathlib import Path
from PIL import Image
from typing import Optional, Tuple
from ..logger import logger

def convert_to_px(value: float, unit: str, dpi: int) -> int:
    """Converts a given value and unit (px, cm, in) to pixels."""
    unit = unit.lower()
    if unit == 'px':
        return int(value)
    elif unit == 'in':
        return int(value * dpi)
    elif unit == 'cm':
        return int((value / 2.54) * dpi)
    elif unit == 'mm':
        return int((value / 25.4) * dpi)
    else:
        raise ValueError(f"Unsupported unit: {unit}")


def get_preset_dimensions(preset: str) -> Optional[Tuple[int, int]]:
    """Returns (width, height) in pixels for known presets."""
    preset = preset.lower()
    presets = {
        '1080p': (1920, 1080),
        '4k': (3840, 2160),
        'a4': (2480, 3508),        # roughly A4 at 300 DPI
        'instagram': (1080, 1080)
    }
    return presets.get(preset)

def resize_image(
    input_path: Path,
    output_path: Optional[Path] = None,
    width: Optional[float] = None,
    height: Optional[float] = None,
    unit: str = 'px',
    dpi: int = 300,
    keep_aspect: bool = True,
    preset: Optional[str] = None
) -> Optional[Path]:
    """Resizes an image and returns the output path."""
    try:
        input_path = Path(input_path)
        if not output_path:
            output_path = input_path.parent / f"resized_{input_path.name}"
        
        with Image.open(input_path) as img:
            orig_w, orig_h = img.size
            target_w, target_h = None, None

            if preset:
                preset_dims = get_preset_dimensions(preset)
                if preset_dims:
                    target_w, target_h = preset_dims
                else:
                    raise ValueError(f"Unknown preset: {preset}")
            else:
                if width is not None:
                    target_w = convert_to_px(width, unit, dpi)
                if height is not None:
                    target_h = convert_to_px(height, unit, dpi)

            if target_w is None and target_h is None:
                raise ValueError("Must specify width, height, or preset")

            # Calculate missing dimension if keep_aspect is True
            if keep_aspect:
                if target_w and target_h is None:
                    ratio = target_w / orig_w
                    target_h = int(orig_h * ratio)
                elif target_h and target_w is None:
                    ratio = target_h / orig_h
                    target_w = int(orig_w * ratio)
                elif target_w and target_h:
                    # Fit within the bounding box (target_w, target_h)
                    ratio = min(target_w / orig_w, target_h / orig_h)
                    target_w = int(orig_w * ratio)
                    target_h = int(orig_h * ratio)
            else:
                if target_w is None:
                    target_w = orig_w
                if target_h is None:
                    target_h = orig_h

            # Convert to RGB if needed (e.g. for JPEG)
            img_format = img.format or input_path.suffix.lstrip('.').upper()
            if img_format == 'JPG':
                img_format = 'JPEG'
                
            if img.mode != 'RGB' and img_format in ['JPEG']:
                img = img.convert('RGB')

            resized_img = img.resize((target_w, target_h), Image.Resampling.LANCZOS)
            
            # Apply DPI to saved image
            resized_img.save(output_path, dpi=(dpi, dpi), format=img_format)
            
            logger.info(f"Resized {input_path.name} to {target_w}x{target_h} px")
            return output_path
            
    except Exception as e:
        logger.error(f"Failed to resize image {input_path}: {e}")
        logger.debug("Stack trace:", exc_info=True)
        return None
