import typer
import questionary
from pathlib import Path
from ..utils import console
from ..handlers.batch import compress_folder_unified
from .resizer import resize_image
from PIL import Image
from rich.table import Table
from rich.panel import Panel
import webbrowser


def run_wizard():
    """Runs the interactive wizard."""
    console.print("\n[bold cyan]Welcome to the ilovecli Interactive Wizard! 🧙‍♂️[/bold cyan]\n")
    
    action = questionary.select(
        "What would you like to do?",
        choices=[
            questionary.Choice("🗜️  Compress a file (Image/PDF/Video)", value="compress"),
            questionary.Choice("📁  Compress a folder", value="folder"),
            questionary.Choice("🎯  Compress to Target Size", value="target"),
            questionary.Choice("🖼️  Resize an Image", value="resize"),
            questionary.Separator(),
            questionary.Choice("❌  Exit", value="exit")
        ]
    ).ask()

    if not action or action == "exit":
        raise typer.Exit()
        
    action_type = action
    
    path_str = questionary.path("Enter path to file or folder:", default=str(Path.cwd())).ask()

    if not path_str:
        return
        
    path = Path(path_str)
    
    if not path.exists():
        console.print(f"❌ Path not found: {path_str}", style="red")
        return

    if action_type == "resize":
        _wizard_resize(path)
    elif action_type == "folder" or path.is_dir():
        _wizard_folder(path)
    elif action_type == "target":
        _wizard_target(path)
    else:
        _wizard_compress(path)

def _show_summary_and_confirm(title: str, details: dict) -> bool:
    table = Table(title=f"📋 {title} Summary", show_header=False, box=None)
    for k, v in details.items():
        table.add_row(f"[cyan]{k}:[/cyan]", str(v))
    
    console.print(Panel(table, border_style="green", expand=False))
    return questionary.confirm("🚀 Ready to execute?", default=True).ask()

def _final_actions(output_path: Path):
    if output_path and output_path.exists():
        console.print(f"\n✨ [bold green]Success![/bold green] Output: [underline]{output_path.absolute()}[/underline]\n")
        
        choices = [
            questionary.Choice("📁 Open output directory", value="open"),
            questionary.Choice("🔙 Back to main menu", value="menu"),
            questionary.Choice("🚪 Quit", value="quit")
        ]
        
        post_action = questionary.select("Next steps?", choices=choices).ask()
        
        if post_action == "open":
            dir_to_open = output_path.parent if output_path.is_file() else output_path
            webbrowser.open(str(dir_to_open.absolute()))
        elif post_action == "menu":
            run_wizard()
        else:
            raise typer.Exit()


def _wizard_resize(path: Path):
    if not path.is_file():
        console.print("❌ Must select a file for resizing.", style="red")
        return
        
    unit = questionary.select(
        "Which unit do you want to use?",
        choices=["px", "cm", "in"]
    ).ask()
    
    use_preset = questionary.confirm("Do you want to use a preset profile?").ask()
    
    preset = None
    width = None
    height = None
    
    if use_preset:
        preset = questionary.select(
            "Select preset:",
            choices=["1080p", "4k", "a4", "instagram"]
        ).ask()
    else:
        width_str = questionary.text(f"Enter target width in {unit} (leave empty to skip):").ask()
        height_str = questionary.text(f"Enter target height in {unit} (leave empty to skip):").ask()
        if width_str:
            width = float(width_str)
        if height_str:
            height = float(height_str)
            
    dpi_str = questionary.text("Enter target DPI (default 300):", default="300").ask()
    dpi = int(dpi_str) if dpi_str else 300
    
    keep_aspect = questionary.confirm("Maintain aspect ratio?", default=True).ask()
    
    output_path_str = questionary.path("Output path (leave empty for auto):").ask()
    output_path = Path(output_path_str) if output_path_str else None
    
    details = {
        "File": path.name,
        "Mode": "Preset" if use_preset else "Manual",
        "Unit": unit,
        "DPI": dpi,
        "Keep Aspect": "Yes" if keep_aspect else "No"
    }
    if use_preset:
        details["Preset"] = preset
    else:
        details["Dimensions"] = f"{width or '?'} x {height or '?'} {unit}"

    if _show_summary_and_confirm("Resize", details):
        out = resize_image(path, output_path, width, height, unit, dpi, keep_aspect, preset)
        if out:
            try:
                with Image.open(out) as img:
                    console.print(f"✅ Final Resolution: [bold green]{img.size[0]} x {img.size[1]}[/bold green] px")
            except:
                pass
            _final_actions(out)

def _wizard_folder(path: Path):
    from ilovecli.cli import folder
    
    console.print(f"\n[bold cyan]Media-agnostic Folder Batch Optimization[/bold cyan]")
    overwrite = questionary.confirm("Overwrite existing files?", default=False).ask()
    recursive = questionary.confirm("Process subfolders recursively?", default=True).ask()
    
    details = {
        "Folder": path,
        "Overwrite": "Yes" if overwrite else "No",
        "Recursive": "Yes" if recursive else "No"
    }
    
    if _show_summary_and_confirm("Batch Process", details):
        folder(path, overwrite=overwrite, recursive=recursive)
        _final_actions(path / "compressed_output")

def _wizard_target(path: Path):
    from ilovecli.cli import target
    if not path.is_file():
        console.print("❌ Must select a file for target compression.", style="red")
        return
        
    size_str = questionary.text("Enter target size in KB:").ask()
    if not size_str: return
        
    try:
        size = int(size_str)
    except ValueError:
        console.print("❌ Invalid size", style="red")
        return
    
    details = {
        "File": path.name,
        "Target Size": f"{size} KB"
    }
        
    if _show_summary_and_confirm("Target-Size", details):
        target(path, size)
        # Assuming target saves with 'target_' prefix in same dir
        _final_actions(path.parent / f"target_{path.name}")

def _wizard_compress(path: Path):
    from ilovecli.cli import compress
    
    console.print(f"\n[bold cyan]Standard Media Optimization[/bold cyan]")
    
    # Advanced options check
    adv = questionary.confirm("Customize compression settings? (Quality/CRF)", default=False).ask()
    
    quality = None
    crf = None
    
    if adv:
        import mimetypes
        mime, _ = mimetypes.guess_type(str(path))
        if mime and mime.startswith("video"):
            crf_str = questionary.text("Video CRF (18-35, default 28):", default="28").ask()
            crf = int(crf_str) if crf_str else 28
        else:
            q_str = questionary.text("Compression Quality (10-95, default 75):", default="75").ask()
            quality = int(q_str) if q_str else 75

    details = {
        "File": path.name,
        "Custom Settings": "Yes" if adv else "No"
    }
    if quality: details["Quality"] = quality
    if crf: details["CRF"] = crf
        
    if _show_summary_and_confirm("Compress", details):
        compress(path, quality=quality, crf=crf)
        _final_actions(path.parent / f"compressed_{path.name}")


