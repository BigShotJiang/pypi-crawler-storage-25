import typer
from pathlib import Path
from rich.console import Console
from rich.progress import Spinner
from rich.text import Text
import shutil
import mimetypes
import requests
import json
from rich.panel import Panel
from typing import List, Optional
try:
    from typing import Annotated
except ImportError:
    from typing_extensions import Annotated



from ilovecli import (
    compress_image,
    compress_folder_unified,
    compress_pdf,
    compress_video,
    convert_image,
    compress_to_target_size,
    compress_pdf_to_target_size,
    compress_video_to_target_size,
    __version__,
)
from ilovecli.logger import logger
from ilovecli.config import load_config


console = Console()

# 1. Added an epilogue for a polished footer in the main help menu
app = typer.Typer(
    help="🚀 [bold green]ilovecli[/bold green] - The Ultimate Image, PDF & Video Compressor",
    epilog="Made with ❤️  | Use [bold cyan]ilovecli <command> --help[/bold cyan] for detailed usage of a specific command.",
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]},
    rich_markup_mode="rich"
)

SUPPORTED_IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".webp"]
SUPPORTED_VIDEO_EXTS = [".mp4", ".mkv", ".mov"]
SUPPORTED_PDF_EXTS = [".pdf"]

def show_banner():
    banner = r"""
      ❤️    _  _                      _  _    ❤️
      ❤️   (_)| | _____   _____   ___| |(_)   ❤️
      ❤️   | || |/ _ \ \ / / _ \ / __| || |   ❤️
      ❤️   | || | (_) \ V /  __/  (__| || |   ❤️
      ❤️   |_||_|\___/ \_/ \___| \___|_||_|   ❤️
    """
    console.print(Panel(banner, title="🚀 The ultimate media compressor", border_style="cyan", subtitle=f"v{__version__}"))

@app.callback(invoke_without_command=True)
def main(

    ctx: typer.Context,
    verbose: bool = typer.Option(False, "--verbose", help="Enable verbose output"),
    debug: bool = typer.Option(False, "--debug", help="Enable debug output"),
    version: bool = typer.Option(False, "--version", "-v", help="Show version", is_eager=True),
    author: bool = typer.Option(False, "--author", "-a", help="Show author info", is_eager=True),
    info: bool = typer.Option(False, "--info", "-i", help="Show project info", is_eager=True),
):
    from ilovecli.logger import set_log_level
    set_log_level(verbose, debug)
    if version:
        console.print(f"[bold cyan]ilovecli[/bold cyan] v{__version__}")
        raise typer.Exit()
    if author:
        console.print("👨‍💻 Author: Deep Dhabal")
        console.print("🎓 Computer Science Student | Cloud & Dev Enthusiast")
        raise typer.Exit()
    if info:
        show_banner()
        console.print("[bold cyan]ilovecli[/bold cyan] - Compress images, PDFs, and videos")
        console.print(f"📦 Version: {__version__}")
        console.print("⚡ Built with Typer & Rich")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        show_banner()
        console.print("Use [bold cyan]ilovecli --help[/bold cyan] to see available commands or run [bold cyan]ilovecli wizard[/bold cyan] for interactive mode.")

@app.command(
    rich_help_panel="[bold yellow]✨ Interactive[/bold yellow]",
    short_help="Run the interactive step-by-step wizard."
)
def wizard():
    """
    [bold green]Run the interactive wizard.[/bold green]
    
    The wizard will guide you through compressing, resizing, or batch processing files.
    """
    from ilovecli.core.wizard import run_wizard
    run_wizard()

@app.command(
    rich_help_panel="[bold cyan]🚀 Core Features[/bold cyan]",
    short_help="Resize an image with advanced unit conversion."
)
def resize(
    file: Annotated[Path, typer.Argument(help="Path to the image file")],
    width: Annotated[Optional[float], typer.Option("--width", "-w", help="Target width")] = None,
    height: Annotated[Optional[float], typer.Option("--height", "-H", help="Target height")] = None,
    unit: Annotated[str, typer.Option("--unit", "-u", help="Unit to use (px, cm, in)")] = "px",
    dpi: Annotated[int, typer.Option("--dpi", "-d", help="Target DPI")] = 300,
    keep_aspect: Annotated[bool, typer.Option("--keep-aspect", "-k", help="Maintain aspect ratio")] = True,
    preset: Annotated[Optional[str], typer.Option("--preset", "-p", help="Use a preset (1080p, 4k, a4, instagram)")] = None,
    output_dir: Annotated[Optional[Path], typer.Option("--output", "-o", help="Specific output file path or directory")] = None
):
    """
    [bold green]Resize an image robustly.[/bold green]
    
    Supports changing standard pixel sizes, or using physical dimensions like cm or inches.
    
    [blue]Examples:[/blue]
    ilovecli resize input.jpg --width 10 --height 15 --unit cm --dpi 300
    ilovecli resize input.jpg --preset instagram
    """
    from ilovecli.core.resizer import resize_image
    
    if not file.exists():
        console.print("❌ File not found", style="red")
        raise typer.Exit(1)
        
    out_path = None
    if output_dir:
        output_dir = Path(output_dir)
        if output_dir.is_dir():
            out_path = output_dir / f"resized_{file.name}"
        else:
            output_dir.parent.mkdir(parents=True, exist_ok=True)
            out_path = output_dir

    try:
        res = resize_image(file, out_path, width, height, unit, dpi, keep_aspect, preset)
        if res:
            from PIL import Image
            with Image.open(res) as img:
                console.print(f"✅ Final size: {img.size[0]} x {img.size[1]} px")
            console.print(f"✅ Resized successfully: {res.name}", style="green")
            
    except Exception as e:
        console.print(f"❌ Resizing failed: {e}", style="red")
        raise typer.Exit(1)

@app.command(
    name="config",
    rich_help_panel="[bold yellow]🧰 Utilities[/bold yellow]",
    short_help="Manage ilovecli presets and configuration."
)
def manage_config(
    show: Annotated[bool, typer.Option("--show", help="Show current configuration")] = False
):
    """
    [bold green]Manage ilovecli presets and configuration.[/bold green]
    """
    if show:
        config = load_config()
        console.print("[bold cyan]Current Configuration:[/bold cyan]")
        console.print(json.dumps(config, indent=2))
    else:
        console.print("Use --show to view the current configuration file in ~/.iloveclirc.")




# 2. Grouped into Panels using rich_help_panel and added short_help
@app.command(
    rich_help_panel="[bold cyan]🚀 Core Compression[/bold cyan]",
    short_help="Auto-detect & compress a single file (Img/PDF/Vid)."
)
@app.command(name="c", hidden=True)
def compress(
    file: Annotated[Path, typer.Argument(help="Path to the file to compress")],
    quality: Annotated[Optional[int], typer.Option("--quality", "-q", help="Image quality (10-95)")] = None,
    pdf_quality: Annotated[Optional[str], typer.Option("--pdf-quality", "-p", help="PDF quality profile")] = None,
    crf: Annotated[Optional[int], typer.Option("--crf", "-c", help="Video CRF (18-35)")] = None,
    strip_exif: Annotated[Optional[bool], typer.Option("--strip", help="Strip EXIF metadata from images")] = None,
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir", "-O", help="Directory to save compressed file")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", "-D", help="Show preview without compressing")] = False
):



    """
    [bold green]Auto-detect and compress a file.[/bold green]
    
    [blue]Alias:[/blue] [bold]c[/bold]
    
    Automatically detects the file type (image, video, or PDF) and applies the optimal compression. 
    """
    config = load_config()
    quality = quality if quality is not None else config["quality"]
    pdf_quality = pdf_quality if pdf_quality is not None else config["pdf_quality"]
    crf = crf if crf is not None else config["crf"]
    strip_exif = strip_exif if strip_exif is not None else config["strip_exif"]

    if not file.exists():
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    out_path = None
    if output_dir:
        output_dir.mkdir(parents=True, exist_ok=True)
        out_path = output_dir / f"compressed_{file.name}"

    mime_type, _ = mimetypes.guess_type(str(file))
    try:
        logger.info(f"Starting compression for {file.name}")
        with console.status(f"Compressing {file.name}...", spinner="dots"):
            if mime_type and mime_type.startswith("image/"):
                compress_image(str(file), quality=quality, strip_exif=strip_exif, output_path=str(out_path) if out_path else None, dry_run=dry_run)
            elif mime_type == "application/pdf" or file.suffix.lower() == ".pdf":
                compress_pdf(str(file), quality=pdf_quality, output_path=str(out_path) if out_path else None, dry_run=dry_run)
            elif mime_type and mime_type.startswith("video/"):
                compress_video(str(file), crf=crf, output_path=str(out_path) if out_path else None, dry_run=dry_run)


            else:
                console.print(f"❌ Unsupported file type: {mime_type or 'Unknown'}", style="red")
                raise typer.Exit()
        console.print(f"✅ Compression completed: {file.name}", style="green")
        logger.info("Compression completed successfully")
    except Exception as e:
        logger.error(f"Error during compression: {e}")
        logger.debug("Stack trace:", exc_info=True)
        console.print(f"❌ Error: {e}", style="red")
        raise typer.Exit(1)

@app.command(
    rich_help_panel="[bold cyan]🚀 Core Compression[/bold cyan]",
    short_help="Compress an entire folder of media concurrently."
)
@app.command(name="f", hidden=True)
def folder(
    path: Annotated[Path, typer.Argument(help="Path to the folder")],
    quality: Annotated[Optional[int], typer.Option("--quality", "-q", help="Image quality (10-95)")] = None,
    pdf_quality: Annotated[Optional[str], typer.Option("--pdf-quality", "-p", help="PDF quality profile")] = None,
    crf: Annotated[Optional[int], typer.Option("--crf", "-c", help="Video CRF (18-35)")] = None,
    overwrite: Annotated[bool, typer.Option("--overwrite", "-o", help="Overwrite existing compressed files")] = False,
    recursive: Annotated[bool, typer.Option("--recursive", "-r", help="Recursively compress in subfolders")] = False,
    exclude: Annotated[List[str], typer.Option("--exclude", "-e", help="Folders to exclude")] = [],
    smart: Annotated[bool, typer.Option("--smart", "-s", help="Auto-adjust quality")] = False,
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir", "-O", help="Directory to save compressed files")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", "-D", help="Show preview without compressing")] = False
):



    """
    [bold green]Compress an entire folder of media concurrently.[/bold green]
    
    [blue]Alias:[/blue] [bold]f[/bold]
    
    Automatically detects and processes images, PDFs, and videos in parallel.
    """
    if not path.exists():
        console.print("❌ Folder not found", style="red")
        raise typer.Exit()

    config = load_config()
    batch_config = {
        "quality": quality if quality is not None else (-1 if smart else config["quality"]),
        "pdf_quality": pdf_quality if pdf_quality is not None else config["pdf_quality"],
        "crf": crf if crf is not None else config["crf"],
        "strip_exif": config["strip_exif"]
    }

    logger.info(f"Starting unified folder compression: {path}")
    if overwrite and not dry_run:
        typer.confirm("You are about to overwrite existing compressed files. Continue?", abort=True)
    
    compress_folder_unified(str(path), batch_config, overwrite, recursive, exclude, output_dir=output_dir, dry_run=dry_run)

    console.print(f"✅ Folder processing completed: {path}", style="green")



@app.command(
    rich_help_panel="[bold cyan]🚀 Core Compression[/bold cyan]",
    short_help="Compress a file to a precise target size in KB."
)
@app.command(name="t", hidden=True)
def target(
    file: Annotated[Path, typer.Argument(help="Path to the file")],
    size_kb: Annotated[int, typer.Argument(help="Target size in KB")],
    pdf_quality: Annotated[str, typer.Option("--quality", "-q", help="PDF profile")] = "screen",
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir", "-O", help="Directory to save compressed file")] = None
):


    """
    [bold green]Compress a file to a precise target size in KB.[/bold green]
    
    [blue]Alias:[/blue] [bold]t[/bold]
    
    Works for both images and PDFs utilizing binary search algorithms.
    
    [bold yellow]PDF Quality Profiles:[/bold yellow]
    - [cyan]screen[/cyan]: Fast compression, extremely low quality (72 DPI). Best for email/web.
    - [cyan]ebook[/cyan]: Good balance of quality and size (150 DPI). Best for general reading.
    - [cyan]printer[/cyan]: High quality for physical printing (300 DPI).
    - [cyan]prepress[/cyan]: Lossless, extremely high quality (300 DPI+). Minimal size reduction.
    """
    if not file.exists():
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    mime_type, _ = mimetypes.guess_type(str(file))
    initial_sz_mb = file.stat().st_size / (1024 * 1024)
    logger.info(f"Starting target compression for {file.name} to {size_kb} KB")

    out_path = None
    if output_dir:
        output_dir.mkdir(parents=True, exist_ok=True)
        out_path = output_dir / f"target_{file.name}"

    try:
        with console.status(f"Compressing {file.name} ({initial_sz_mb:.2f} MB) to {size_kb} KB...", spinner="dots"):
            if mime_type and mime_type.startswith("image/"):
                out_path = compress_to_target_size(str(file), size_kb, output_path=out_path)
            elif mime_type == "application/pdf" or file.suffix.lower() == ".pdf":
                out_path = compress_pdf_to_target_size(str(file), size_kb, quality=pdf_quality, output_path=out_path)
            elif mime_type and mime_type.startswith("video/"):
                out_path = compress_video_to_target_size(str(file), size_kb, output_path=out_path)

            else:
                console.print("❌ Target compression only supported for images, PDFs, and videos", style="red")
                raise typer.Exit(1)

            
            if not out_path:
                raise ValueError("Could not compress file to desired target size.")

        out_file = Path(out_path)
        final_size_kb = round(out_file.stat().st_size / 1024, 2)
        console.print(f"✅ Target compression completed: {out_file.name} ({final_size_kb} KB)", style="green")
        logger.info("Target compression completed successfully")
    except Exception as e:
        logger.error(f"Error during target compression: {e}")
        logger.debug("Stack trace:", exc_info=True)
        console.print(f"❌ Target compression failed: {e}", style="red")
        raise typer.Exit(1)

@app.command(
    name="url",
    rich_help_panel="[bold yellow]🧰 Utilities[/bold yellow]",
    short_help="Download, compress, and resize a file from a URL."
)
@app.command(name="u", hidden=True)
def url(
    link: str = typer.Argument(..., help="URL to the file"),
    output: Path = typer.Option(None, "--output", "-o", help="Specific output filename"),
    quality: int = typer.Option(75, "--quality", "-q", help="Image quality (10-95)"),
    width: Annotated[Optional[float], typer.Option("--width", "-w", help="Target width (auto-resizes image)")] = None,
    height: Annotated[Optional[float], typer.Option("--height", "-H", help="Target height")] = None,
    unit: Annotated[str, typer.Option("--unit", "-u", help="Unit for resizing (px, cm, in)")] = "px",
    dpi: Annotated[int, typer.Option("--dpi", "-d", help="DPI for resizing")] = 300,
):
    """
    [bold green]Download and process a file directly from a URL.[/bold green]
    
    Uses [bold]cloudscraper[/bold] to bypass bot protection, mimics human behavior with randomized delays,
    and includes deep-scraping fallbacks.
    """
    import cloudscraper
    import time
    import random
    from rich.progress import Progress, TextColumn, BarColumn, DownloadColumn, TransferSpeedColumn
    from urllib.parse import urlparse
    
    try:
        scraper = cloudscraper.create_scraper(
            browser={
                'browser': 'chrome',
                'platform': 'windows',
                'desktop': True
            }
        )
        # Enhanced human-like headers
        scraper.headers.update({
            "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Referer": "https://www.google.com/",
            "Sec-Fetch-Dest": "image",
            "Sec-Fetch-Mode": "no-cors",
            "Sec-Fetch-Site": "cross-site",
        })
        
        logger.info(f"Initiating request for: {link}")
        console.print("[dim]⧗ Preparing secure connection...[/dim]")
        time.sleep(random.uniform(1.2, 2.5))
        
        response = scraper.get(link, stream=True, timeout=30, allow_redirects=True)
        
        # 403 Fallback: Mobile Emulation
        if response.status_code == 403:
            console.print("\n[bold yellow]⚠️ Standard bypass failed. Attempting deep-scraping (Mobile Mode)...[/bold yellow]")
            scraper.headers.update({"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1"})
            time.sleep(1.5)
            response = scraper.get(link, stream=True, timeout=30)

        if response.status_code != 200:
            console.print(f"\n[bold red]❌ Access Denied (Status: {response.status_code})[/bold red]")
            console.print("[yellow]This site has extremely aggressive protection. Please download manually and use 'ilovecli compress'.[/yellow]")
            raise typer.Exit(1)
            
        total_size = int(response.headers.get('content-length', 0))
        
        parsed_url = urlparse(link)
        fname = Path(parsed_url.path).name or "downloaded_file"
        save_path = output if output else Path(fname)
        
        with Progress(
            TextColumn("[bold blue]{task.fields[filename]}", justify="right"),
            BarColumn(bar_width=None),
            "[progress.percentage]{task.percentage:>3.1f}%",
            "•",
            DownloadColumn(),
            "•",
            TransferSpeedColumn(),
            console=console
        ) as progress:
            task_id = progress.add_task("download", filename=save_path.name, total=total_size)
            with open(save_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        progress.update(task_id, advance=len(chunk))

        console.print(f"\n✅ Downloaded: [bold cyan]{save_path.name}[/bold cyan]", style="green")

        # 1. Compress
        compress(save_path, quality=quality, pdf_quality="ebook", crf=28)
        
        # 2. Optional Resize
        if width or height:
            mime_type, _ = mimetypes.guess_type(str(save_path))
            if mime_type and mime_type.startswith("image/"):
                from ilovecli.core.resizer import resize_image
                compressed_path = save_path.parent / f"compressed_{save_path.name}"
                target_path = compressed_path if compressed_path.exists() else save_path
                
                console.print(f"📐 Auto-resizing to {width or '?'}x{height or '?'} {unit}...")
                resize_image(target_path, width=width, height=height, unit=unit, dpi=dpi)
            else:
                console.print("⚠️  Skipping resize: File is not an image.", style="yellow")
                
    except Exception as e:
        logger.error(f"Failed URL operation: {e}")
        console.print(f"❌ Operation failed: {e}", style="red")
        raise typer.Exit(1)



@app.command(
    rich_help_panel="[bold yellow]🧰 Utilities[/bold yellow]",
    short_help="Convert an image from one format to another."
)
@app.command(name="cv", hidden=True)
def convert(
    input: Path = typer.Argument(..., help="Input file path"),
    output: Path = typer.Argument(..., help="Output file path (e.g., output.webp)")
):
    """
    [bold green]Convert an image from one format to another.[/bold green]
    
    [blue]Alias:[/blue] [bold]cv[/bold]
    
    Simple utility to convert images safely (e.g., png to jpg or webp).
    """
    logger.info(f"Converting {input.name} to {output.name}")
    with console.status(f"Converting {input.name}...", spinner="dots"):
        convert_image(str(input), str(output))
    console.print(f"✅ Conversion completed: {output.name}", style="green")

from ilovecli.utils import print_system_info

@app.command(
    rich_help_panel="[bold magenta]🛠️  Diagnostics[/bold magenta]",
    short_help="Check system dependencies (FFmpeg, Ghostscript)."
)
@app.command(name="d", hidden=True)
def doctor():
    """
    [bold green]System dependencies check for compression engines.[/bold green]
    
    [blue]Alias:[/blue] [bold]d[/bold]
    
    Verifies if your system has FFmpeg (for videos) and Ghostscript (for PDFs) installed securely.
    """
    console.print("[bold cyan]ilovecli[/bold cyan] System Doctor 🩺\n", style="bold")
    print_system_info()
    console.print("")
    
    ffmpeg_path = shutil.which("ffmpeg")

    if ffmpeg_path:
        console.print(f"✅ FFmpeg found: [green]{ffmpeg_path}[/green]")
    else:
        console.print("❌ FFmpeg NOT found (Video compression will not work)", style="red")

    gs_path = shutil.which("gs")
    if gs_path:
        console.print(f"✅ Ghostscript found: [green]{gs_path}[/green]")
    else:
        console.print("❌ Ghostscript NOT found (PDF compression will not work)", style="red")

@app.command(
    rich_help_panel="[bold yellow]🧰 Utilities[/bold yellow]",
    short_help="Auto-install system dependencies (FFmpeg, Ghostscript)."
)
@app.command(name="install", hidden=True)
def install_deps():
    """
    [bold green]Auto-install system dependencies.[/bold green]
    
    [blue]Alias:[/blue] [bold]install[/bold]
    
    Detects your operating system (Linux, macOS, Windows) and automatically installs FFmpeg and Ghostscript using the native package manager (apt, brew, winget).
    """
    import platform
    import subprocess
    system = platform.system().lower()
    console.print("[bold cyan]ilovecli[/bold cyan] Dependency Installer 🚀\n", style="bold")
    
    try:
        if system == "linux":
            import shutil
            if shutil.which("apt-get"):
                console.print("🐧 Detected Linux (apt). Attempting to install...", style="yellow")
                subprocess.run(["sudo", "apt-get", "update"], check=True)
                subprocess.run(["sudo", "apt-get", "install", "-y", "ffmpeg", "ghostscript"], check=True)
            elif shutil.which("pacman"):
                console.print("🐧 Detected Linux (pacman). Attempting to install...", style="yellow")
                subprocess.run(["sudo", "pacman", "-Sy", "ffmpeg", "ghostscript", "--noconfirm"], check=True)
            elif shutil.which("dnf"):
                console.print("🐧 Detected Linux (dnf). Attempting to install...", style="yellow")
                subprocess.run(["sudo", "dnf", "install", "-y", "ffmpeg", "ghostscript"], check=True)
            elif shutil.which("yum"):
                console.print("🐧 Detected Linux (yum). Attempting to install...", style="yellow")
                subprocess.run(["sudo", "yum", "install", "-y", "ffmpeg", "ghostscript"], check=True)
            elif shutil.which("zypper"):
                console.print("🐧 Detected Linux (zypper). Attempting to install...", style="yellow")
                subprocess.run(["sudo", "zypper", "install", "-y", "ffmpeg", "ghostscript"], check=True)
            elif shutil.which("apk"):
                console.print("🐧 Detected Linux (apk). Attempting to install...", style="yellow")
                subprocess.run(["sudo", "apk", "add", "ffmpeg", "ghostscript"], check=True)
            else:
                console.print("❌ Could not detect a supported Linux package manager. Please install FFmpeg and Ghostscript manually.", style="red")
                raise typer.Exit(1)
        elif system == "darwin":
            console.print("🍎 Detected macOS. Attempting to install via Homebrew...", style="yellow")
            subprocess.run(["brew", "install", "ffmpeg", "ghostscript"], check=True)
        elif system == "windows":
            console.print("🪟 Detected Windows. Attempting to install via winget...", style="yellow")
            subprocess.run(["winget", "install", "ffmpeg", "Ghostscript.Ghostscript"], check=True)
        else:
            console.print(f"❌ Unsupported OS for auto-install: {system}. Please install manually.", style="red")
            raise typer.Exit(1)
            
        console.print("\n✅ All system dependencies installed successfully! You are ready to compress.", style="bold green")
    except Exception as e:
        logger.error(f"Failed to auto-install dependencies: {e}")
        console.print(f"\n❌ Auto-installation failed. Please install FFmpeg and Ghostscript manually.", style="bold red")
        raise typer.Exit(1)

if __name__ == "__main__":
    app()