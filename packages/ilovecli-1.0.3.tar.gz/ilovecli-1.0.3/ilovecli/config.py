import json
from pathlib import Path
from typing import Any, Dict

CONFIG_FILE = Path.home() / ".iloveclirc"

DEFAULT_CONFIG = {
    "quality": 60,
    "pdf_quality": "ebook",
    "crf": 28,
    "strip_exif": False,
    "output_dir": None
}

def load_config() -> Dict[str, Any]:
    """Load configuration from ~/.iloveclirc."""
    if not CONFIG_FILE.exists():
        return DEFAULT_CONFIG.copy()
    
    try:
        with open(CONFIG_FILE, "r") as f:
            user_config = json.load(f)
            # Merge with defaults to ensure all keys exist
            config = DEFAULT_CONFIG.copy()
            config.update(user_config)
            return config
    except Exception:
        return DEFAULT_CONFIG.copy()

def save_config(config: Dict[str, Any]):
    """Save configuration to ~/.iloveclirc."""
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)
    except Exception as e:
        print(f"Error saving config: {e}")

def get_config_value(key: str) -> Any:
    """Get a specific config value."""
    config = load_config()
    return config.get(key, DEFAULT_CONFIG.get(key))
