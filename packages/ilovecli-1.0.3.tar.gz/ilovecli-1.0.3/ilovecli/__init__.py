from .handlers.image import (
    compress_image,
    convert_image,
    compress_to_target_size,
)
from .handlers.batch import compress_folder_unified


from .handlers.pdf import (
    compress_pdf,
    compress_pdf_to_target_size,
)

from .handlers.video import (
    compress_video,
    compress_video_to_target_size,
)

__all__ = [
    "compress_image",
    "compress_folder_unified",
    "convert_image",
    "compress_to_target_size",
    "compress_pdf",
    "compress_pdf_to_target_size",
    "compress_video",
    "compress_video_to_target_size",
]



__version__ = "1.0.1"