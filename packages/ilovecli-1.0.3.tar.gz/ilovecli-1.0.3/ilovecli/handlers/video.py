import subprocess
import os
from pathlib import Path
from typing import Optional, Any
from rich.console import Console
from ..utils import print_size_report
from .base import BaseHandler

console = Console()

class VideoHandler(BaseHandler):
    @property
    def name(self) -> str:
        return "Video"

    def is_supported(self, file_path: Path) -> bool:
        return file_path.suffix.lower() in {".mp4", ".mkv", ".mov", ".avi", ".webm"}

    def compress(
        self,
        input_path: Path,
        output_path: Optional[Path] = None,
        crf: int = 28,
        show_progress: bool = True,
        dry_run: bool = False,
        **kwargs: Any
    ) -> bool:
        """Compress a single video and save with a real-time progress bar."""
        import re
        from rich.progress import Progress, TextColumn, BarColumn, TimeRemainingColumn, TaskProgressColumn
        
        input_path = Path(input_path)
        output = output_path if output_path else input_path.parent / f"compressed_{input_path.name}"
        original_size = input_path.stat().st_size

        if dry_run:
            logger.info(f"[Dry-run] Would compress {input_path.name} to {output.name}")
            print_size_report(original_size, int(original_size * 0.4), filename=f"[Preview] {input_path.name}")
            return True


        try:
            # Get total duration first for progress bar
            duration_proc = subprocess.run([
                "ffprobe", "-v", "error", "-show_entries",
                "format=duration", "-of",
                "default=noprint_wrappers=1:nokey=1", str(input_path)
            ], capture_output=True, text=True, check=True)
            total_duration = float(duration_proc.stdout.strip())

            command = [
                "ffmpeg", "-i", str(input_path),
                "-vcodec", "libx265", "-crf", str(crf),
                "-preset", "medium", "-threads", "0",
                "-tag:v", "hvc1", "-movflags", "+faststart",
                "-y", str(output)
            ]

            if not show_progress:
                subprocess.run(command, check=True, capture_output=True)
            else:
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    universal_newlines=True
                )

                with Progress(
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TaskProgressColumn(),
                    TimeRemainingColumn(),
                    console=console
                ) as progress:
                    task = progress.add_task(f"[cyan]Crunching {input_path.name}...", total=total_duration)
                    
                    for line in process.stdout:
                        # Parse time=00:00:12.34
                        match = re.search(r"time=(\d+):(\d+):(\d+\.\d+)", line)
                        if match:
                            h, m, s = map(float, match.groups())
                            current_time = h * 3600 + m * 60 + s
                            progress.update(task, completed=current_time)
                    
                process.wait()
                if process.returncode != 0:
                    raise subprocess.CalledProcessError(process.returncode, command)

            print_size_report(original_size, output.stat().st_size, filename=input_path.name)
            return True

        except Exception as e:
            console.print(f"❌ Video compression failed: {e}", style="red")
            return False


    def compress_to_target_size(
        self,
        input_path: Path,
        target_kb: int,
        output_path: Optional[Path] = None,
        **kwargs: Any
    ) -> Optional[Path]:
        """
        Compress video to fit within target size using bitrate calculation.
        Uses a 2-pass approach for better precision.
        """
        import re
        from rich.progress import Progress, TextColumn, BarColumn, TimeRemainingColumn, TaskProgressColumn
        
        input_path = Path(input_path)
        output = output_path if output_path else input_path.parent / f"target_{input_path.name}"
        target_bytes = target_kb * 1024
        
        try:
            # 1. Get duration using ffprobe
            duration_proc = subprocess.run([
                "ffprobe", "-v", "error", "-show_entries",
                "format=duration", "-of",
                "default=noprint_wrappers=1:nokey=1", str(input_path)
            ], capture_output=True, text=True, check=True)
            
            duration = float(duration_proc.stdout.strip())
            
            # 2. Calculate required bitrate
            audio_bitrate = 128 * 1024
            total_bitrate = (target_bytes * 8) / duration
            video_bitrate = int(max(total_bitrate - audio_bitrate, 100 * 1024))

            # 3. Two-pass encoding with progress
            with Progress(
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                TimeRemainingColumn(),
                console=console
            ) as progress:
                # Pass 1
                task1 = progress.add_task(f"[yellow]Analysing {input_path.name} (Pass 1)...", total=duration)
                pass1_cmd = [
                    "ffmpeg", "-y", "-i", str(input_path),
                    "-c:v", "libx265", "-b:v", str(video_bitrate),
                    "-x265-params", "pass=1", "-an", "-f", "mp4",
                    os.devnull if os.name != 'nt' else 'NUL'
                ]
                proc1 = subprocess.Popen(pass1_cmd, stderr=subprocess.STDOUT, stdout=subprocess.PIPE, universal_newlines=True)
                for line in proc1.stdout:
                    match = re.search(r"time=(\d+):(\d+):(\d+\.\d+)", line)
                    if match:
                        h, m, s = map(float, match.groups())
                        progress.update(task1, completed=h * 3600 + m * 60 + s)
                proc1.wait()

                # Pass 2
                task2 = progress.add_task(f"[green]Optimizing {input_path.name} (Pass 2)...", total=duration)
                pass2_cmd = [
                    "ffmpeg", "-y", "-i", str(input_path),
                    "-c:v", "libx265", "-b:v", str(video_bitrate),
                    "-x265-params", "pass=2", 
                    "-c:a", "aac", "-b:a", "128k",
                    "-tag:v", "hvc1", "-movflags", "+faststart",
                    str(output)
                ]
                proc2 = subprocess.Popen(pass2_cmd, stderr=subprocess.STDOUT, stdout=subprocess.PIPE, universal_newlines=True)
                for line in proc2.stdout:
                    match = re.search(r"time=(\d+):(\d+):(\d+\.\d+)", line)
                    if match:
                        h, m, s = map(float, match.groups())
                        progress.update(task2, completed=h * 3600 + m * 60 + s)
                proc2.wait()

            # Cleanup
            for logfile in Path(".").glob("x265_2pass.log*"):
                logfile.unlink()

            final_size = output.stat().st_size
            print_size_report(input_path.stat().st_size, final_size, filename=input_path.name)
            return output

        except Exception as e:
            console.print(f"❌ Video targeting failed: {e}", style="red")
            return None


# Global instance
video_handler = VideoHandler()

def compress_video(input_path: str, crf: int = 28, output_path: str = None, **kwargs):
    return video_handler.compress(Path(input_path), Path(output_path) if output_path else None, crf=crf, **kwargs)


def compress_video_to_target_size(input_path: str, target_kb: int, output_path: str = None, **kwargs):
    return video_handler.compress_to_target_size(Path(input_path), target_kb, Path(output_path) if output_path else None, **kwargs)