import subprocess
import os
from pathlib import Path
from typing import Optional, Any
from rich.console import Console
from ..utils import print_size_report
from .base import BaseHandler

console = Console()

class PDFHandler(BaseHandler):
    @property
    def name(self) -> str:
        return "PDF"

    def is_supported(self, file_path: Path) -> bool:
        return file_path.suffix.lower() == ".pdf"

    def compress(
        self,
        input_path: Path,
        output_path: Optional[Path] = None,
        quality: str = "ebook",
        dry_run: bool = False,
        **kwargs: Any
    ) -> bool:
        """
        Compress PDF using Ghostscript with standard PDFSETTINGS.
        quality: screen, ebook, printer, prepress
        """
        input_path = Path(input_path)
        output = output_path if output_path else input_path.parent / f"compressed_{input_path.name}"
        original_size = input_path.stat().st_size

        if dry_run:
            logger.info(f"[Dry-run] Would compress {input_path.name} to {output.name}")
            print_size_report(original_size, int(original_size * 0.7), filename=f"[Preview] {input_path.name}")
            return True


        result = subprocess.run([
            "gs",
            "-sDEVICE=pdfwrite",
            "-dCompatibilityLevel=1.4",
            f"-dPDFSETTINGS=/{quality}",
            "-dNOPAUSE",
            "-dQUIET",
            "-dBATCH",
            f"-sOutputFile={str(output)}",
            str(input_path)
        ])

        if result.returncode != 0:
            console.print("❌ Ghostscript failed", style="red")
            return False

        print_size_report(original_size, output.stat().st_size, filename=input_path.name)
        return True

    def compress_to_target_size(
        self,
        input_path: Path,
        target_kb: int,
        output_path: Optional[Path] = None,
        quality: str = "screen",
        **kwargs: Any
    ) -> Optional[Path]:
        """
        Compress PDF to a target size in KB using a combination of:
        1. Ghostscript PDFSETTINGS
        2. Optional DPI downsampling for images
        """
        input_path = Path(input_path)
        output = output_path if output_path else input_path.parent / f"target_{input_path.name}"
        target_bytes = target_kb * 1024
        original_size = input_path.stat().st_size

        # If already below target
        if original_size <= target_bytes:
            console.print(f"✅ Already under target size ({target_kb} KB)")
            return input_path

        # Step 1: Apply Ghostscript PDFSETTINGS compression first
        subprocess.run([
            "gs",
            "-sDEVICE=pdfwrite",
            "-dCompatibilityLevel=1.4",
            f"-dPDFSETTINGS=/{quality}",
            "-dNOPAUSE",
            "-dQUIET",
            "-dBATCH",
            f"-sOutputFile={str(output)}",
            str(input_path)
        ], check=True)

        current_size = output.stat().st_size
        if current_size <= target_bytes:
            console.print(f"✅ Saved as {output.name} | Size: {round(current_size/1024,2)} KB")
            return output

        # Step 2: DPI downsampling (for image-heavy PDFs)
        low, high = 50, 300
        best_dpi = None
        
        max_iterations = 5
        iterations = 0

        import tempfile
        
        last_new_size = current_size
        while low <= high and iterations < max_iterations:
            iterations += 1
            mid = (low + high) // 2
            
            # Use a temporary file to avoid slow disk I/O on the final location
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=True) as tmp_pdf:
                subprocess.run([
                    "gs",
                    "-sDEVICE=pdfwrite",
                    "-dCompatibilityLevel=1.4",
                    "-dDownsampleColorImages=true",
                    "-dColorImageResolution=" + str(mid),
                    "-dDownsampleGrayImages=true",
                    "-dGrayImageResolution=" + str(mid),
                    "-dDownsampleMonoImages=true",
                    "-dMonoImageResolution=" + str(mid),
                    "-dNOPAUSE",
                    "-dQUIET",
                    "-dBATCH",
                    "-sOutputFile=" + tmp_pdf.name,
                    str(input_path)
                ], check=True)

                last_new_size = os.path.getsize(tmp_pdf.name)
            
            if target_bytes * 0.95 <= last_new_size <= target_bytes * 1.05:
                best_dpi = mid
                break
                
            if last_new_size > target_bytes:
                high = mid - 1
            else:
                best_dpi = mid
                low = mid + 1

        if best_dpi is None:
            console.print(f"❌ Could not reach target size ({target_kb} KB). Final size: {round(last_new_size/1024,2)} KB", style="red")
            return None

        # Final save using best DPI
        subprocess.run([
            "gs",
            "-sDEVICE=pdfwrite",
            "-dCompatibilityLevel=1.4",
            "-dDownsampleColorImages=true",
            "-dColorImageResolution=" + str(best_dpi),
            "-dDownsampleGrayImages=true",
            "-dGrayImageResolution=" + str(best_dpi),
            "-dDownsampleMonoImages=true",
            "-dMonoImageResolution=" + str(best_dpi),
            "-dNOPAUSE",
            "-dQUIET",
            "-dBATCH",
            "-sOutputFile=" + str(output),
            str(input_path)
        ], check=True)

        final_size_kb = round(output.stat().st_size / 1024, 2)
        console.print(f"✅ Saved as {output.name}")
        console.print(f"📦 Final Size: {final_size_kb} KB")
        console.print(f"🎯 DPI Used: {best_dpi}")
        return output

# Global instance
pdf_handler = PDFHandler()

def compress_pdf(input_path: str, quality: str = "ebook", output_path: str = None, **kwargs):
    return pdf_handler.compress(Path(input_path), Path(output_path) if output_path else None, quality=quality, **kwargs)


def compress_pdf_to_target_size(input_path: str, target_kb: int, quality: str = "screen", output_path: str = None, **kwargs):
    return pdf_handler.compress_to_target_size(Path(input_path), target_kb, Path(output_path) if output_path else None, quality=quality, **kwargs)