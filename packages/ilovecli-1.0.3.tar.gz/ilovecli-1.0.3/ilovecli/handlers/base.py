from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Any


class BaseHandler(ABC):
    """Base class for all media compression handlers."""

    @abstractmethod
    def compress(
        self,
        input_path: Path,
        output_path: Optional[Path] = None,
        dry_run: bool = False,
        **kwargs: Any
    ) -> bool:
        """Compress a single file."""
        pass

    @abstractmethod
    def compress_to_target_size(
        self,
        input_path: Path,
        target_kb: int,
        output_path: Optional[Path] = None,
        dry_run: bool = False,
        **kwargs: Any
    ) -> Optional[Path]:
        """Compress a file to fit within a target size."""
        pass


    @abstractmethod
    def is_supported(self, file_path: Path) -> bool:
        """Check if the file format is supported by this handler."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Name of the handler."""
        pass
