from pathlib import Path
from multiprocessing import Pool, cpu_count
from PIL import Image
import logging
import io
from typing import Tuple, List, Optional, Any, Dict
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from ..logger import logger
from ..utils import console, print_size_report
from .base import BaseHandler

SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"}

class ImageHandler(BaseHandler):
    @property
    def name(self) -> str:
        return "Image"

    def is_supported(self, file_path: Path) -> bool:
        return file_path.suffix.lower() in SUPPORTED_EXTENSIONS

    def compress(
        self,
        input_path: Path,
        output_path: Optional[Path] = None,
        quality: int = 60,
        strip_exif: bool = False,
        dry_run: bool = False,
        **kwargs: Any
    ) -> bool:
        """Compress a single image and save."""
        try:
            input_path = Path(input_path)
            output_path = Path(output_path) if output_path else input_path.parent / f"compressed_{input_path.name}"
            original_size = input_path.stat().st_size

            if dry_run:
                logger.info(f"[Dry-run] Would compress {input_path.name} to {output_path.name}")
                print_size_report(original_size, int(original_size * 0.5), filename=f"[Preview] {input_path.name}")
                return True


            with Image.open(input_path) as img:
                fmt = img.format.upper() if img.format else "JPEG"
                
                # Metadata handling
                if strip_exif:
                    data = list(img.getdata())
                    img_no_exif = Image.new(img.mode, img.size)
                    img_no_exif.putdata(data)
                    img = img_no_exif

                use_quality = quality
                if quality == -1: # Smart mode
                    total_pixels = img.size[0] * img.size[1]
                    if total_pixels > 4000000:
                        use_quality = 50
                    elif total_pixels > 1000000:
                        use_quality = 65
                    else:
                        use_quality = 80

                if fmt in ["JPEG", "JPG"]:
                    img.save(output_path, quality=use_quality, optimize=True)
                elif fmt == "PNG":
                    compress_level = max(0, min(9, int((100 - use_quality) / 10)))
                    img.save(output_path, optimize=True, compress_level=compress_level)
                elif fmt == "WEBP":
                    img.save(output_path, format="WEBP", quality=use_quality, optimize=True)
                else:
                    img.save(output_path)

            new_size = output_path.stat().st_size
            print_size_report(original_size, new_size, filename=input_path.name)
            logger.info(f"Compressed {input_path.name} -> {output_path.name}")
            return True

        except Exception as e:
            logger.error(f"Failed to compress {input_path.name}: {e}")
            logger.debug("Stack trace:", exc_info=True)
            return False

    def compress_to_target_size(
        self,
        input_path: Path,
        target_kb: int,
        output_path: Optional[Path] = None,
        **kwargs: Any
    ) -> Optional[Path]:
        """Compress image to fit within target size using binary search over quality."""
        try:
            input_path = Path(input_path)
            output = output_path if output_path else input_path.parent / f"target_{input_path.name}"
            target_bytes = target_kb * 1024

            with Image.open(input_path) as img:
                format = img.format if img.format else "JPEG"
                if format not in ["JPEG", "WEBP"]:
                    logger.warning(f"Target size compression is highly inefficient for {format}. Converting to WEBP for targeting.")
                    format = "WEBP"
                    output = output.with_suffix(".webp")

                if img.mode != "RGB" and format == "JPEG":
                    img = img.convert("RGB")

                low, high = 5, 95
                best_quality = None
                iterations = 0

                while low <= high:
                    iterations += 1
                    mid = (low + high) // 2
                    buffer = io.BytesIO()
                    img.save(buffer, format=format, quality=mid, optimize=True)
                    size = buffer.getbuffer().nbytes

                    if size > target_bytes:
                        high = mid - 1
                    else:
                        best_quality = mid
                        low = mid + 1

                if best_quality is None:
                    logger.error(f"Could not compress {input_path.name} to desired size {target_kb}KB")
                    return None

                img.save(output, format=format, quality=best_quality, optimize=True)
                final_size_kb = output.stat().st_size / 1024
                logger.info(f"Target compression complete: {output.name} | Final size: {final_size_kb:.2f} KB | Quality: {best_quality} | Iterations: {iterations}")
                return output

        except Exception as e:
            logger.error(f"Failed target compression for {input_path.name}: {e}")
            logger.debug("Stack trace:", exc_info=True)
            return None

    def convert(self, input_path: Path, output_path: Path) -> bool:
        """Convert image format."""
        try:
            with Image.open(input_path) as img:
                img.save(output_path)
            logger.info(f"Image converted: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Failed converting {input_path}: {e}")
            logger.debug("Stack trace:", exc_info=True)
            return False

# Global instance for easy access
image_handler = ImageHandler()

# Wrapper functions for backward compatibility
def compress_image(input_path: str, quality: int = 60, output_path: str = None, **kwargs):
    return image_handler.compress(Path(input_path), Path(output_path) if output_path else None, quality=quality, **kwargs)


def _compress_single(args: Tuple[str, int, str]):
    return compress_image(*args)

def compress_folder_parallel(folder_path: str, quality: int = 60, overwrite: bool = False, recursive: bool = False, exclude: List[str] = None, smart: bool = False):
    """Compress all supported images in a folder using multiprocessing."""
    folder = Path(folder_path)
    exclude = exclude or []
    if not folder.is_dir():
        logger.error(f"Folder not found: {folder}")
        return

    files = []
    if recursive:
        for p in folder.rglob("*"):
            if p.is_file() and image_handler.is_supported(p):
                if not any(ex in p.parts for ex in exclude):
                    files.append(p)
    else:
        files = [f for f in folder.iterdir() if f.is_file() and image_handler.is_supported(f)]

    if not files:
        logger.warning(f"No supported images found in folder: {folder.absolute()}")
        return

    output_folder = folder / "compressed_output"
    output_folder.mkdir(exist_ok=True)

    tasks = []
    for file in files:
        target_path = output_folder / f"compressed_{file.name}"
        if not overwrite and target_path.exists():
            logger.info(f"Skipping {file.name} (already compressed)")
            continue
        tasks.append((str(file), quality if not smart else -1, str(target_path)))

    if not tasks:
        logger.info("Nothing to compress after checking existing files")
        return

    workers = min(cpu_count(), len(tasks))
    logger.info(f"Using {workers} CPU cores for compressing {len(tasks)} images")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task_id = progress.add_task("[cyan]Compressing...", total=len(tasks))
        with Pool(workers) as pool:
            for _ in pool.imap_unordered(_compress_single, tasks):
                progress.advance(task_id)

    logger.info("Parallel folder compression completed")

def convert_image(input_path: str, output_path: str):
    return image_handler.convert(Path(input_path), Path(output_path))

def compress_to_target_size(input_path: str, target_kb: int, output_path: str = None, **kwargs):
    return image_handler.compress_to_target_size(Path(input_path), target_kb, Path(output_path) if output_path else None, **kwargs)