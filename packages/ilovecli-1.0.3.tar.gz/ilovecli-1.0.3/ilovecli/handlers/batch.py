from pathlib import Path
from multiprocessing import Pool, cpu_count
from typing import List, Tuple, Dict, Any
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from ..logger import logger
from ..utils import console
from .image import image_handler
from .pdf import pdf_handler
from .video import video_handler

def _process_item(args: Tuple[Path, Dict[str, Any], Path, bool, bool]) -> bool:
    file_path, config, output_folder, overwrite, dry_run = args
    
    # Check which handler supports this file
    handler = None
    if image_handler.is_supported(file_path):
        handler = image_handler
    elif pdf_handler.is_supported(file_path):
        handler = pdf_handler
    elif video_handler.is_supported(file_path):
        handler = video_handler
        
    if not handler:
        return False

    target_path = output_folder / f"compressed_{file_path.name}"
    if not overwrite and target_path.exists() and not dry_run:
        logger.info(f"Skipping {file_path.name} (already exists)")
        return False

    # Prepare specific kwargs for the handler
    kwargs = {"dry_run": dry_run}
    if handler.name == "Image":
        kwargs.update({"quality": config.get("quality", 60), "strip_exif": config.get("strip_exif", False)})
    elif handler.name == "PDF":
        kwargs.update({"quality": config.get("pdf_quality", "ebook")})
    elif handler.name == "Video":
        kwargs.update({"crf": config.get("crf", 28)})

    return handler.compress(file_path, target_path, **kwargs)

def compress_folder_unified(
    folder_path: str,
    config: Dict[str, Any],
    overwrite: bool = False,
    recursive: bool = False,
    exclude: List[str] = None,
    output_dir: Path = None,
    dry_run: bool = False
):

    """Compress all supported media in a folder concurrently."""
    folder = Path(folder_path)
    exclude = exclude or []
    
    if not folder.is_dir():
        logger.error(f"Folder not found: {folder}")
        return

    files = []
    pattern = "**/*" if recursive else "*"
    
    for p in folder.glob(pattern):
        if p.is_file():
            # Check if any handler supports this file
            if any(h.is_supported(p) for f in [p] if (h := next((h for h in [image_handler, pdf_handler, video_handler] if h.is_supported(f)), None))):
                if not any(ex in p.parts for ex in exclude):
                    files.append(p)

    # Simplified support check
    files = []
    for p in folder.glob(pattern):
        if p.is_file():
            if image_handler.is_supported(p) or pdf_handler.is_supported(p) or video_handler.is_supported(p):
                if not any(ex in p.parts for ex in exclude):
                    files.append(p)

    if not files:
        logger.warning(f"No supported media found in folder: {folder.absolute()}")
        return

    final_output_dir = output_dir if output_dir else folder / "compressed_output"
    final_output_dir.mkdir(parents=True, exist_ok=True)

    tasks = [(f, config, final_output_dir, overwrite, dry_run) for f in files]

    
    # Use fewer workers for video since FFmpeg is already multi-threaded
    has_video = any(video_handler.is_supported(f) for f in files)
    workers = min(cpu_count(), len(tasks))
    if has_video:
        workers = max(1, workers // 2)

    logger.info(f"Unified batch processing: {len(files)} files using {workers} workers")

    results = []
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task_id = progress.add_task("[cyan]Processing Batch...", total=len(tasks))
        with Pool(workers) as pool:
            for success in pool.imap_unordered(_process_item, tasks):
                results.append(success)
                progress.advance(task_id)

    # Summary Dashboard
    total_files = len(files)
    successful = sum(1 for r in results if r)
    
    # Calculate savings (requires gathering sizes, but we can approximate or just show counts)
    from rich.table import Table
    from rich.panel import Panel
    
    table = Table(show_header=True, header_style="bold magenta", box=None)
    table.add_column("Metric", style="dim", width=20)
    table.add_column("Value")
    
    table.add_row("Total Files Detected", str(total_files))
    table.add_row("Successfully Optimized", f"[green]{successful}[/green]")
    table.add_row("Failed/Skipped", f"[red]{total_files - successful}[/red]")
    table.add_row("Concurrency Level", f"{workers} Cores")

    console.print("\n")
    console.print(Panel(table, title="📊 Batch Summary Dashboard", border_style="cyan", expand=False))
    
    logger.info("Unified batch processing completed")


