import pytest
from pathlib import Path
from ilovecli.handlers.image import image_handler
from ilovecli.handlers.pdf import pdf_handler
from ilovecli.handlers.video import video_handler

def test_handler_names():
    assert image_handler.name == "Image"
    assert pdf_handler.name == "PDF"
    assert video_handler.name == "Video"

def test_image_support():
    assert image_handler.is_supported(Path("test.jpg")) is True
    assert image_handler.is_supported(Path("test.png")) is True
    assert image_handler.is_supported(Path("test.pdf")) is False

def test_pdf_support():
    assert pdf_handler.is_supported(Path("test.pdf")) is True
    assert pdf_handler.is_supported(Path("test.jpg")) is False

def test_video_support():
    assert video_handler.is_supported(Path("test.mp4")) is True
    assert video_handler.is_supported(Path("test.mkv")) is True
    assert video_handler.is_supported(Path("test.txt")) is False
