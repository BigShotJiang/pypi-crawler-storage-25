
<div align="center">
  <h1>🚀 ilovecli</h1>
  <p><b>The ultimate, high-performance media optimization suite for your terminal.</b></p>
  <p><i>Version 1.0.3</i></p>
</div>

<p align="center">
  <a href="#-features">Features</a> •
  <a href="#-installation">Installation</a> •
  <a href="#-quick-start">Quick Start</a> •
  <a href="#-advanced-usage">Advanced Usage</a> •
  <a href="#-license">License</a>
</p>

---

`ilovecli` is an impossibly fast, cross-platform command-line utility built to seamlessly **compress, resize, and optimize Images, PDFs, and Videos**. 

Designed for both beginners and power-users, it maps complex formatting engines (like FFmpeg and Ghostscript) into an elegant, interactive interface. Whether you are batch-shrinking gigabytes of vacation photos or stripping megabytes out of a corporate PDF, `ilovecli` handles it instantly.

## ✨ Core Features

*   **🧙‍♂️ Interactive UI:** A gorgeous, keyboard-driven `wizard` for users who prefer menus over typing commands.
*   **🖼️ Precision Resizer:** Scale images with mathematical accuracy using pixels (`px`), centimeters (`cm`), or millimeters (`mm`). Perfect for digital design and print media.
*   **🗜️ Smart Compression Engine:** Multi-threaded optimization for Images (JPG, PNG, WEBP), PDFs, and Videos (HEVC/libx265).
*   **🎯 Target-Size Isolation:** Specify an exact file size (e.g., "Max 5MB"), and our binary-search algorithm will calculate the perfect compression ratio automatically.
*   **🌐 Anti-Bot Web Fetcher:** Download media directly from highly protected sites (like Freepik) utilizing built-in Cloudflare bypass protocols.
*   **📁 Mass Batching:** Process entire directory trees recursively, utilizing 100% of available CPU cores.

---

## 📦 Installation

This project requires **Python 3.8+**. It is highly recommended to install it globally using `pipx` to avoid environment conflicts.

```bash
pipx install ilovecli
# Fallback standard installation:
# pip install ilovecli
```

### Auto-Install Dependencies (Highly Recommended)
`ilovecli` heavily benefits from native system engines (FFmpeg & Ghostscript). Let the CLI provision these for your specific operating system automatically:

```bash
ilovecli install
```

---

## 🚀 Quick Start Guide

### 1. The Interactive Wizard (Easiest Method)
If you do not want to memorize manual arguments, simply launch the step-by-step terminal UI:
```bash
ilovecli wizard
```

### 2. Standard Compression (`compress` / `c`)
The engine automatically detects the MIME type and routes the file safely to the correct compressor.
```bash
ilovecli c photo.jpg          # Optimize an image
ilovecli c document.pdf       # Shrink a PDF
ilovecli c video.mp4          # Compress a video (HEVC)
```

### 3. Image Precision Resizing (`resize`)
Safely scale images while automatically maintaining their aspect ratio.
```bash
# Standard pixel resizing
ilovecli resize header.png --width 1920

# Professional print resizing (20cm width at 300 DPI)
ilovecli resize poster.jpg --width 20 --unit cm --dpi 300

# Built-in dimensional presets
ilovecli resize post.jpg --preset instagram
```

### 4. Target-Size Algorithms (`target` / `t`)
Strict email attachment limits? Force a file below a specific KB threshold.
```bash
ilovecli t presentation.pdf 2000    # Compresses until strictly under 2MB
ilovecli t large_photo.jpg 500      # Compresses until strictly under 500KB
```

### 5. Fetch & Optimize (`url` / `u`)
Download a remote file, bypass bot-protection, and immediately push it through the compression/resize pipeline.
```bash
ilovecli url https://example.com/source.png --width 1000
```

### 6. Parallel Folder Processing (`folder` / `f`)
Execute multi-threaded compression across an entire directory.
```bash
ilovecli f ./assets --smart
```

---

## ⚙️ Advanced Settings & Tuning

### PDF Export Profiles
Control exact DPI outputs for your PDFs using the `-p` (profile) flag.
*   `screen`: Extreme compression for emails and speedy web viewing (**72 DPI**).
*   `ebook`: Balanced file size and crisp vector rendering (**150 DPI**). *(Default)*
*   `printer`: High-fidelity resolution for home/office printing (**300 DPI**).
*   `prepress`: Lossless, commercial-grade print quality (**300 DPI+**).

*Example:* `ilovecli c report.pdf -p printer`

### Video Adjustments (HEVC)
`ilovecli` utilizes **libx265 (HEVC)** for video, cutting file sizes in half compared to older h264 standards. You can manually adjust the Constant Rate Factor (`-c`).
-   **Lower CRF (18):** Visually lossless quality, larger file sizes.
-   **Higher CRF (35):** Maximum compression, noticeable quality reduction. 

*Example:* `ilovecli c raw_footage.mp4 -c 28`

---

## 🛠 System Diagnostics

Verify the integrity of your installed dependencies (FFmpeg/Ghostscript) at any time:
```bash
ilovecli doctor
```

## 🐳 Docker Deployment

For CI/CD pipelines or users who wish to avoid local dependency installations:

```bash
docker build -t ilovecli .
docker run --rm -v $(pwd):/data ilovecli c /data/huge_file.pdf
```

---

## 📄 License & Contributing

Distributed under the **MIT License**. We welcome pull requests, bug reports, and ideas! If this tool has accelerated your workflow or saved your server space, please consider leaving a ⭐ on the repository.


