from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import requests

from .config import SDKConfig
from .errors import (
    SDKResponseError,
    SDKTransportError,
    raise_for_status,
)


class HTTPClient:
    def __init__(
        self,
        config: SDKConfig,
        api_key: str | None = None,
        session: requests.Session | None = None,
    ) -> None:
        self._config = config
        self._api_key = api_key
        self._session = session or requests.Session()

    def _headers(
        self,
        api_key_override: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
    ) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        token = api_key_override if api_key_override is not None else self._api_key
        if token:
            headers["Authorization"] = f"Bearer {token}"

        if extra_headers:
            headers.update(extra_headers)

        return headers

    def _request_json(
        self,
        method: str,
        url: str,
        *,
        json_payload: Mapping[str, Any] | None = None,
        timeout_seconds: int,
        api_key_override: str | None = None,
        extra_headers: Mapping[str, str] | None = None,
    ) -> object:
        try:
            response = self._session.request(
                method=method,
                url=url,
                json=json_payload,
                headers=self._headers(api_key_override, extra_headers),
                timeout=timeout_seconds,
            )
        except requests.RequestException:
            raise SDKTransportError("Unable to reach service.") from None

        raise_for_status(response)

        try:
            return response.json()
        except ValueError:
            raise SDKResponseError("Received invalid JSON response.") from None

    def post_sdk(
        self,
        path: str,
        *,
        payload: Mapping[str, Any] | None = None,
        timeout_seconds: int | None = None,
        api_key_override: str | None = None,
    ) -> object:
        url = f"{self._config.sdk_base_url.rstrip('/')}/{path.lstrip('/')}"
        timeout = timeout_seconds or self._config.sdk_timeout_seconds
        return self._request_json(
            "POST",
            url,
            json_payload=payload,
            timeout_seconds=timeout,
            api_key_override=api_key_override,
        )

    def get_sdk(
        self,
        path: str,
        *,
        timeout_seconds: int | None = None,
        api_key_override: str | None = None,
    ) -> object:
        url = f"{self._config.sdk_base_url.rstrip('/')}/{path.lstrip('/')}"
        timeout = timeout_seconds or self._config.sdk_timeout_seconds
        return self._request_json(
            "GET",
            url,
            timeout_seconds=timeout,
            api_key_override=api_key_override,
        )

    def post_inference(
        self,
        payload: Mapping[str, Any],
        *,
        timeout_seconds: int | None = None,
        api_key_override: str | None = None,
    ) -> object:
        timeout = timeout_seconds or self._config.inference_timeout_seconds
        return self._request_json(
            "POST",
            self._config.inference_base_url,
            json_payload=payload,
            timeout_seconds=timeout,
            api_key_override=api_key_override,
        )

    def get_absolute(
        self,
        url: str,
        *,
        timeout_seconds: int | None = None,
        api_key_override: str | None = None,
    ) -> object:
        timeout = timeout_seconds or self._config.inference_timeout_seconds
        return self._request_json(
            "GET",
            url,
            timeout_seconds=timeout,
            api_key_override=api_key_override,
        )
