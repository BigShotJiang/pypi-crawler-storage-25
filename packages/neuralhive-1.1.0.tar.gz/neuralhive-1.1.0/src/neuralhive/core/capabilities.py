from __future__ import annotations

from typing import TypedDict


class Capability(TypedDict):
    supported_verbs: list[str]
    required_inputs_by_verb: dict[str, list[str]]
    allowed_inputs_by_verb: dict[str, list[str]]


def _cap(
    verbs: list[str],
    required: dict[str, list[str]],
    allowed: dict[str, list[str]],
) -> Capability:
    return {
        "supported_verbs": verbs,
        "required_inputs_by_verb": required,
        "allowed_inputs_by_verb": allowed,
    }


_EMPTY_CAPABILITY: Capability = _cap([], {}, {})

_TASK_CAPABILITY_MAP: dict[str, Capability] = {
    "object_detection": _cap(["detect"], {"detect": ["image"]}, {"detect": ["image"]}),
    "face_detection": _cap(["detect"], {"detect": ["image"]}, {"detect": ["image"]}),
    "instance_segmentation": _cap(
        ["segment", "detect"],
        {"segment": ["image"], "detect": ["image"]},
        {"segment": ["image"], "detect": ["image"]},
    ),
    "sam3": _cap(
        ["segment", "detect"],
        {"segment": ["image", "prompt"], "detect": ["image", "prompt"]},
        {"segment": ["image", "prompt"], "detect": ["image", "prompt"]},
    ),
    "face_recognition": _cap(["recognize"], {"recognize": ["image"]}, {"recognize": ["image"]}),
    "person_reid": _cap(["reidentify"], {"reidentify": ["image"]}, {"reidentify": ["image"]}),
    "pose_estimation": _cap(["estimate_pose"], {"estimate_pose": ["image"]}, {"estimate_pose": ["image"]}),
    "text_embeddings": _cap(["embed"], {"embed": ["text"]}, {"embed": ["text"]}),
    "clip": _cap(["embed"], {"embed": ["text_or_image"]}, {"embed": ["text", "image"]}),
    "slm": _cap(
        ["generate_text"],
        {"generate_text": ["prompt"]},
        {"generate_text": ["prompt", "text"]},
    ),
    "vlm": _cap(
        ["analyze", "generate_text"],
        {
            "analyze": ["text_or_images_or_videos"],
            "generate_text": ["prompt_or_multimodal_input"],
        },
        {
            "analyze": ["text", "images", "videos"],
            "generate_text": ["prompt", "text", "image", "images", "videos"],
        },
    ),
    "3d_asset_generation": _cap(
        ["generate_3d"],
        {"generate_3d": ["image"]},
        {"generate_3d": ["image"]},
    ),
    "image_generation": _cap(
        ["generate_image"],
        {"generate_image": ["prompt"]},
        {"generate_image": ["prompt"]},
    ),
}


def normalize_task(task: str) -> str:
    return str(task).strip().lower().replace("-", "_").replace(" ", "_")


def capabilities_for_task(task: str) -> Capability:
    normalized = normalize_task(task)
    cap = _TASK_CAPABILITY_MAP.get(normalized)
    if cap is not None:
        return cap
    return _EMPTY_CAPABILITY
