from __future__ import annotations

import configparser
import os
from pathlib import Path

ENV_API_KEY = "NEURALHIVE_API_KEY"
DEFAULT_PROFILE = "default"


def _clean(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped if stripped else None


def _credentials_path() -> Path:
    return Path.home() / ".neuralhive" / "credentials"


def _read_api_key_from_credentials_file(path: Path | None = None) -> str | None:
    target = path if path is not None else _credentials_path()
    if not target.exists() or not target.is_file():
        return None

    parser = configparser.ConfigParser()
    try:
        parser.read(target, encoding="utf-8")
    except Exception:
        return None

    if not parser.has_section(DEFAULT_PROFILE):
        return None

    return _clean(parser.get(DEFAULT_PROFILE, "api_key", fallback=None))


def resolve_api_key(explicit_api_key: str | None = None) -> str | None:
    explicit = _clean(explicit_api_key)
    if explicit is not None:
        return explicit

    env_value = _clean(os.getenv(ENV_API_KEY))
    if env_value is not None:
        return env_value

    return _read_api_key_from_credentials_file()


def store_api_key(api_key: str, path: Path | None = None) -> Path:
    value = _clean(api_key)
    if value is None:
        raise ValueError("Invalid `api_key` value.") from None

    target = path if path is not None else _credentials_path()
    target.parent.mkdir(parents=True, exist_ok=True)

    parser = configparser.ConfigParser()
    if target.exists() and target.is_file():
        try:
            parser.read(target, encoding="utf-8")
        except Exception:
            parser = configparser.ConfigParser()

    if not parser.has_section(DEFAULT_PROFILE):
        parser.add_section(DEFAULT_PROFILE)
    parser.set(DEFAULT_PROFILE, "api_key", value)

    with target.open("w", encoding="utf-8") as fp:
        parser.write(fp)

    try:
        os.chmod(target, 0o600)
    except Exception:
        pass

    return target
