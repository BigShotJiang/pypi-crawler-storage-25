from __future__ import annotations

import requests


class SDKInternalError(Exception):
    """Base internal SDK exception."""


class SDKAuthError(SDKInternalError):
    """Authentication failed (401)."""


class SDKPermissionError(SDKInternalError):
    """Authorization failed (403)."""


class SDKNotFoundError(SDKInternalError):
    """Requested resource not found (404)."""


class SDKServiceError(SDKInternalError):
    """Service-side failure (5xx)."""


class SDKRequestError(SDKInternalError):
    """Client/request-side failure (4xx except auth/perm/notfound)."""


class SDKTransportError(SDKInternalError):
    """Network transport failure."""


class SDKResponseError(SDKInternalError):
    """Invalid/unexpected response payload."""


def raise_for_status(response: requests.Response) -> None:
    status_code = response.status_code

    if status_code == 401:
        raise SDKAuthError("Authentication failed.") from None

    if status_code == 403:
        raise SDKPermissionError("Access denied.") from None

    if status_code == 404:
        raise SDKNotFoundError("Resource not found.") from None

    if status_code >= 500:
        raise SDKServiceError("Service is temporarily unavailable.") from None

    if status_code >= 400:
        raise SDKRequestError(f"Request failed with status code {status_code}.") from None
