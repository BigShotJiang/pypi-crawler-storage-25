from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class SDKConfig:
    sdk_base_url: str = "https://neuralhive.ai/sdk-api/v1"
    inference_base_url: str = "https://infra.neuralhive.ai/api/v1/inference"
    connect_timeout_seconds: int = 30
    sdk_timeout_seconds: int = 60
    inference_timeout_seconds: int = 600
    poll_interval_seconds: int = 5
    max_poll_attempts: int = 1000

    @classmethod
    def from_env(cls) -> "SDKConfig":
        def _to_int(name: str, default: int) -> int:
            raw = os.getenv(name)
            if not raw:
                return default
            try:
                return int(raw)
            except ValueError:
                return default

        default = cls()
        return cls(
            sdk_base_url=os.getenv("NH_SDK_BASE_URL", default.sdk_base_url),
            inference_base_url=os.getenv(
                "NH_INFERENCE_BASE_URL",
                default.inference_base_url,
            ),
            connect_timeout_seconds=_to_int(
                "NH_CONNECT_TIMEOUT_SECONDS",
                default.connect_timeout_seconds,
            ),
            sdk_timeout_seconds=_to_int(
                "NH_SDK_TIMEOUT_SECONDS",
                default.sdk_timeout_seconds,
            ),
            inference_timeout_seconds=_to_int(
                "NH_INFERENCE_TIMEOUT_SECONDS",
                default.inference_timeout_seconds,
            ),
            poll_interval_seconds=_to_int(
                "NH_POLL_INTERVAL_SECONDS",
                default.poll_interval_seconds,
            ),
            max_poll_attempts=_to_int(
                "NH_MAX_POLL_ATTEMPTS",
                default.max_poll_attempts,
            ),
        )
