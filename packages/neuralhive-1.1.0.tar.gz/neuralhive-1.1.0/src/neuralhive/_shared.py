from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .core.config import SDKConfig
from .core.errors import (
    SDKAuthError,
    SDKNotFoundError,
    SDKPermissionError,
    SDKRequestError,
    SDKResponseError,
    SDKServiceError,
    SDKTransportError,
)
from .core.http import HTTPClient
from .services.inference import InferenceService
from .services.models import ModelsService

HEADERS = {"Content-Type": "application/json"}

_api_key: str | None = None
_runtime_config: SDKConfig = SDKConfig.from_env()


def set_runtime_config(config: SDKConfig) -> None:
    global _runtime_config
    _runtime_config = config


def get_runtime_config() -> SDKConfig:
    return _runtime_config


def require_str(value: object, name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"Invalid `{name}` value.") from None
    if not value.strip():
        raise ValueError(f"Invalid `{name}` value.") from None
    return value


def set_api_key(value: str) -> None:
    global _api_key
    _api_key = require_str(value, "api_key")


def get_api_key() -> str | None:
    return _api_key


def build_headers(extra_headers: Mapping[str, str] | None = None) -> dict[str, str]:
    headers = dict(HEADERS)
    if _api_key:
        headers["Authorization"] = f"Bearer {_api_key}"

    if extra_headers:
        headers.update(extra_headers)

    return headers


def _map_common_error(exc: Exception) -> None:
    if isinstance(exc, SDKAuthError):
        raise RuntimeError("Authentication failed. Please verify your API key.") from None

    if isinstance(exc, SDKPermissionError):
        raise RuntimeError("Access denied for this request.") from None

    if isinstance(exc, SDKNotFoundError):
        raise RuntimeError("Requested resource was not found.") from None

    if isinstance(exc, SDKServiceError):
        raise RuntimeError("Service is temporarily unavailable. Please try again.") from None

    if isinstance(exc, (SDKRequestError, SDKResponseError)):
        raise RuntimeError("Request could not be completed. Please try again.") from None

    if isinstance(exc, SDKTransportError):
        raise RuntimeError("Unable to reach service. Please try again.") from None

    raise RuntimeError("Request could not be completed. Please try again.") from None


def get_http_client(api_key_override: str | None = None) -> HTTPClient:
    token = api_key_override if api_key_override is not None else _api_key
    return HTTPClient(config=get_runtime_config(), api_key=token)


def verify_api_key(api_key: str) -> None:
    token = require_str(api_key, "api_key")
    config = get_runtime_config()

    try:
        service = ModelsService(config=config, api_key=token)
        service.connect(token)
    except SDKTransportError:
        raise RuntimeError("Unable to verify API key at the moment. Please try again.") from None
    except Exception as exc:
        _map_common_error(exc)


def get_sdk_json(path: str) -> object:
    config = get_runtime_config()
    if not config.sdk_base_url:
        raise RuntimeError("Service is not configured correctly.") from None

    path = require_str(path, "path")

    try:
        client = get_http_client()
        return client.get_sdk(path, timeout_seconds=config.sdk_timeout_seconds)
    except Exception as exc:
        _map_common_error(exc)


def post_json(payload: Mapping[str, Any]) -> object:
    config = get_runtime_config()
    if not config.inference_base_url:
        raise RuntimeError("Service is not configured correctly.") from None

    try:
        service = InferenceService(config=config, api_key=get_api_key())
        return service.run(payload)
    except Exception as exc:
        _map_common_error(exc)


def require_result_object(data: object) -> Mapping[str, object]:
    if not isinstance(data, Mapping):
        raise RuntimeError("Received an invalid response from service.") from None

    status = data.get("status")
    if status != "success":
        raise RuntimeError("Received an unexpected response from service.") from None

    result = data.get("result")
    if not isinstance(result, Mapping):
        raise RuntimeError("Received an invalid result from service.") from None

    return result


def is_float_list(value: object) -> bool:
    return isinstance(value, list) and all(isinstance(item, (int, float)) for item in value)


def is_float_matrix(value: object) -> bool:
    return isinstance(value, list) and all(is_float_list(item) for item in value)


def is_int_list(value: object) -> bool:
    return isinstance(value, list) and all(isinstance(item, int) for item in value)
