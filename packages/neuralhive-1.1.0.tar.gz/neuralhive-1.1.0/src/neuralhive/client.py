from __future__ import annotations

import base64
from collections.abc import Callable
from typing import Any

from ._shared import require_str, set_api_key, set_runtime_config, verify_api_key
from .core.capabilities import capabilities_for_task
from .core.config import SDKConfig
from .core.credentials import resolve_api_key
from .models.clip_embeddings import image as clip_image_embeddings
from .models.clip_embeddings import text as clip_text_embeddings
from .models.face_detection import face_detection as run_face_detection
from .models.face_recognition import face_recognition as run_face_recognition
from .models.image_generation import image_generation as run_image_generation
from .models.instance_segmentation import instance_segmentation as run_instance_segmentation
from .models import get_model as get_model_details
from .models import list_models as list_available_models
from .models.object_detection import object_detection as run_object_detection
from .models.person_reid import person_reid as run_person_reid
from .models.pose_estimation import pose_estimation as run_pose_estimation
from .models.sam3 import sam3 as run_sam3
from .models.slm import slm as run_slm
from .models.text_embeddings import text_embeddings as run_text_embeddings
from .models.three_d_asset_generation import three_d_asset_generation as run_three_d_asset_generation
from .models.vlm import vlm as run_vlm


def _raise_user_error(message: str) -> None:
    raise Exception(message) from None


class _LocalValidationError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class _EndpointBase:
    def __init__(self, client: "Client") -> None:
        self._client = client

    def _run_safe(self, fn: Callable[..., Any], message: str, *args: Any, **kwargs: Any) -> Any:
        return self._client._run_safe(fn, message, *args, **kwargs)

    def _run_inference(
        self,
        fn: Callable[..., Any],
        message: str,
        *,
        verb: str,
        model_id: str,
        inputs: dict[str, object],
        args: tuple[Any, ...] = (),
        kwargs: dict[str, Any] | None = None,
    ) -> Any:
        return self._client._run_inference_safe(
            fn,
            message,
            verb=verb,
            model_id=model_id,
            inputs=inputs,
            args=args,
            kwargs={} if kwargs is None else kwargs,
        )


class _ModelsClient(_EndpointBase):
    def list(self):
        return self._run_safe(list_available_models, "Unable to fetch models. Please try again.")

    def get(self, model_id: str):
        return self._run_safe(
            get_model_details,
            "Unable to fetch model details. Please verify the model id and try again.",
            model_id,
        )


class _ClipClient(_EndpointBase):
    def text(self, input_text: str, model_id: str):
        return self._run_inference(
            clip_text_embeddings,
            "Unable to run text inference. Please check your input and try again.",
            verb="embed",
            model_id=model_id,
            inputs={"text": input_text},
            args=(input_text, model_id),
        )

    def image(self, image_b64: str, model_id: str):
        return self._run_inference(
            clip_image_embeddings,
            "Unable to run image inference. Please check your input and try again.",
            verb="embed",
            model_id=model_id,
            inputs={"image": image_b64},
            args=(image_b64, model_id),
        )


class _TextModelClient(_EndpointBase):
    def __init__(
        self,
        client: "Client",
        fn: Callable[[str, str], Any],
        message: str,
        *,
        verb: str,
        input_key: str,
        deprecated_call: str | None = None,
        new_call: str | None = None,
    ) -> None:
        super().__init__(client)
        self._fn = fn
        self._message = message
        self._verb = verb
        self._input_key = input_key
        self._deprecated_call = deprecated_call
        self._new_call = new_call

    def __call__(self, text: str, model_id: str):
        inputs = {self._input_key: text}
        # For generate_text contract, `prompt` is canonical required input.
        if self._verb == "generate_text":
            inputs["prompt"] = text
        return self._run_inference(
            self._fn,
            self._message,
            verb=self._verb,
            model_id=model_id,
            inputs=inputs,
            args=(text, model_id),
        )


class _ImageModelClient(_EndpointBase):
    def __init__(
        self,
        client: "Client",
        fn: Callable[[str, str], Any],
        message: str,
        *,
        verb: str,
        deprecated_call: str | None = None,
        new_call: str | None = None,
    ) -> None:
        super().__init__(client)
        self._fn = fn
        self._message = message
        self._verb = verb
        self._deprecated_call = deprecated_call
        self._new_call = new_call

    def __call__(self, image: str, model_id: str):
        return self._run_inference(
            self._fn,
            self._message,
            verb=self._verb,
            model_id=model_id,
            inputs={"image": image},
            args=(image, model_id),
        )


class _ImageB64ModelClient(_EndpointBase):
    def __init__(
        self,
        client: "Client",
        fn: Callable[[str, str], Any],
        message: str,
        *,
        verb: str,
        deprecated_call: str | None = None,
        new_call: str | None = None,
    ) -> None:
        super().__init__(client)
        self._fn = fn
        self._message = message
        self._verb = verb
        self._deprecated_call = deprecated_call
        self._new_call = new_call

    def __call__(self, image_b64: str, model_id: str):
        return self._run_inference(
            self._fn,
            self._message,
            verb=self._verb,
            model_id=model_id,
            inputs={"image": image_b64},
            args=(image_b64, model_id),
        )


class _VlmClient(_EndpointBase):
    def __call__(
        self,
        model_id: str,
        text: str | None = None,
        images: str | list[str] | None = None,
        videos: str | list[str] | None = None,
    ):
        return self._run_inference(
            run_vlm,
            "Unable to run VLM inference. Please check your input and try again.",
            verb="analyze",
            model_id=model_id,
            inputs={
                "text": text,
                "images": images,
                "videos": videos,
                "prompt": text,
            },
            kwargs={
                "model_id": model_id,
                "text": text,
                "images": images,
                "videos": videos,
            },
        )


class _Sam3Client(_EndpointBase):
    def __call__(self, image: str, prompt: str, model_id: str):
        return self._run_inference(
            run_sam3,
            "Unable to run SAM3 inference. Please check your input and try again.",
            verb="segment",
            model_id=model_id,
            inputs={"image": image, "prompt": prompt},
            args=(image, prompt, model_id),
        )


class _PersonReIdClient(_ImageB64ModelClient):
    def __init__(self, client: "Client") -> None:
        super().__init__(
            client,
            run_person_reid,
            "Unable to run person re-identification. Please check your input and try again.",
            verb="reidentify",
            deprecated_call="client.person_reid(image_b64, model_id)",
            new_call="client.reidentify(image, model_id)",
        )

    def run(self, image_b64: str, model_id: str):
        return self.__call__(image_b64, model_id)


class Client:
    def __init__(self, api_key: str | None = None) -> None:
        if api_key is not None and (not isinstance(api_key, str) or not api_key.strip()):
            _raise_user_error("Please provide a valid API key.")
        self._api_key = resolve_api_key(api_key)
        self._connected = False
        self._models_cache_loaded = False
        self._model_capabilities_cache: dict[str, dict[str, object]] = {}
        # SDK runtime config is internal-only and intentionally not user-overridable.
        self._config = SDKConfig()
        set_runtime_config(self._config)

        # Verb-first public surface only.

    def _run_safe(self, fn: Callable[..., Any], message: str, *args: Any, **kwargs: Any) -> Any:
        self._ensure_connected()
        try:
            return fn(*args, **kwargs)
        except Exception:
            _raise_user_error(message)

    def _run_inference_safe(
        self,
        fn: Callable[..., Any],
        message: str,
        *,
        verb: str,
        model_id: str,
        inputs: dict[str, object],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any:
        self._ensure_connected()
        try:
            self._validate_input_formats(
                verb=verb,
                model_id=model_id,
                inputs=inputs,
            )
            self._validate_inference_call(verb=verb, model_id=model_id, inputs=inputs)
            return fn(*args, **kwargs)
        except _LocalValidationError as exc:
            if exc.code in {
                "invalid_image_format",
                "invalid_images_format",
                "unsupported_inputs",
                "required_inputs_missing",
            }:
                _raise_user_error(str(exc))
            if exc.code in {"model_not_available", "verb_not_supported"} and self._models_cache_loaded:
                try:
                    self._refresh_model_capabilities_cache()
                    self._validate_input_formats(
                        verb=verb,
                        model_id=model_id,
                        inputs=inputs,
                    )
                    self._validate_inference_call(verb=verb, model_id=model_id, inputs=inputs)
                    return fn(*args, **kwargs)
                except Exception:
                    _raise_user_error(message)
            _raise_user_error(message)
        except Exception:
            _raise_user_error(message)

    def _connect(self) -> None:
        if self._connected:
            return

        if not isinstance(self._api_key, str) or not self._api_key.strip():
            _raise_user_error("Please provide an API key.")

        try:
            verify_api_key(self._api_key)
            set_api_key(self._api_key)
            self._connected = True
        except Exception:
            _raise_user_error("Authentication failed. Please verify your API key and try again.")

        try:
            self._refresh_model_capabilities_cache()
        except Exception:
            self._model_capabilities_cache = {}
            self._models_cache_loaded = False

    def _refresh_model_capabilities_cache(self) -> None:
        models = list_available_models()
        if not isinstance(models, list):
            self._model_capabilities_cache = {}
            self._models_cache_loaded = False
            return

        cache: dict[str, dict[str, object]] = {}
        for item in models:
            if not isinstance(item, dict):
                continue

            model_id_raw = item.get("_id")
            if not isinstance(model_id_raw, str) or not model_id_raw.strip():
                continue
            model_id = model_id_raw.strip()
            task = str(item.get("task", ""))
            capability = capabilities_for_task(task)
            supported_verbs = list(capability["supported_verbs"])
            required_inputs = dict(capability["required_inputs_by_verb"])
            allowed_inputs = dict(capability["allowed_inputs_by_verb"])

            cache[model_id] = {
                "name": str(item.get("name", "")),
                "task": task,
                "supported_verbs": supported_verbs,
                "required_inputs_by_verb": required_inputs,
                "allowed_inputs_by_verb": allowed_inputs,
            }

        self._model_capabilities_cache = cache
        self._models_cache_loaded = True

    def _task_for_model(self, model_id: str) -> str:
        capability = self._model_capabilities_cache.get(model_id)
        if not isinstance(capability, dict):
            return ""
        task = capability.get("task")
        return str(task).strip().lower() if isinstance(task, str) else ""

    def _ensure_connected(self) -> None:
        if not self._connected:
            self._connect()

    def _validate_inference_call(self, *, verb: str, model_id: str, inputs: dict[str, object]) -> None:
        normalized_model_id = require_str(model_id, "model_id")
        normalized_verb = require_str(verb, "verb")

        if not self._models_cache_loaded:
            return

        capability = self._model_capabilities_cache.get(normalized_model_id)
        if capability is None:
            raise _LocalValidationError(
                "model_not_available",
                "Model is not available for this API key.",
            ) from None

        supported_verbs = capability.get("supported_verbs")
        if not isinstance(supported_verbs, list):
            supported_verbs = []

        if normalized_verb not in supported_verbs:
            raise _LocalValidationError(
                "verb_not_supported",
                "Selected model does not support requested operation.",
            ) from None

        required_map = capability.get("required_inputs_by_verb")
        if not isinstance(required_map, dict):
            required_map = {}

        required = required_map.get(normalized_verb)
        if not isinstance(required, list):
            required = []

        allowed_map = capability.get("allowed_inputs_by_verb")
        if not isinstance(allowed_map, dict):
            allowed_map = {}
        allowed = allowed_map.get(normalized_verb)
        if not isinstance(allowed, list):
            allowed = []

        present_inputs = self._collect_present_inputs(inputs)
        if allowed and not self._inputs_within_allowed_set(present_inputs, set(allowed)):
            bad_fields = sorted(field for field in present_inputs if field not in set(allowed))
            bad_field = bad_fields[0] if bad_fields else "input"
            raise _LocalValidationError(
                "unsupported_inputs",
                f"Invalid input for {normalized_verb} ({self._model_label(normalized_model_id)}): '{bad_field}' is not allowed.",
            ) from None

        missing_required = self._first_missing_required(required, present_inputs)
        if missing_required is not None:
            raise _LocalValidationError(
                "required_inputs_missing",
                f"Missing required input for {normalized_verb} ({self._model_label(normalized_model_id)}): '{missing_required}'.",
            ) from None

    @staticmethod
    def _collect_present_inputs(inputs: dict[str, object]) -> set[str]:
        present: set[str] = set()
        for key, value in inputs.items():
            if isinstance(value, str):
                if value.strip():
                    present.add(key)
                continue
            if isinstance(value, list):
                if len(value) > 0:
                    present.add(key)
                continue
            if value is not None:
                present.add(key)
        return present

    @staticmethod
    def _inputs_satisfy_requirements(required: list[str], present: set[str]) -> bool:
        for field in required:
            if field == "text_or_image":
                if "text" not in present and "image" not in present:
                    return False
                continue

            if field == "text_or_images_or_videos":
                if "text" not in present and "images" not in present and "videos" not in present:
                    return False
                continue

            if field == "prompt_or_multimodal_input":
                if (
                    "prompt" not in present
                    and "image" not in present
                    and "images" not in present
                    and "videos" not in present
                ):
                    return False
                continue

            if field == "image_or_prompt":
                if "image" not in present and "prompt" not in present:
                    return False
                continue

            if field not in present:
                return False

        return True

    @staticmethod
    def _first_missing_required(required: list[str], present: set[str]) -> str | None:
        for field in required:
            if field == "text_or_image":
                if "text" not in present and "image" not in present:
                    return "text or image"
                continue

            if field == "text_or_images_or_videos":
                if "text" not in present and "images" not in present and "videos" not in present:
                    return "text or images or videos"
                continue

            if field == "prompt_or_multimodal_input":
                if (
                    "prompt" not in present
                    and "image" not in present
                    and "images" not in present
                    and "videos" not in present
                ):
                    return "prompt or multimedia input"
                continue

            if field == "image_or_prompt":
                if "image" not in present and "prompt" not in present:
                    return "image or prompt"
                continue

            if field not in present:
                return field

        return None

    @staticmethod
    def _inputs_within_allowed_set(present: set[str], allowed: set[str]) -> bool:
        for field in present:
            if field not in allowed:
                return False
        return True

    def _validate_input_formats(self, *, verb: str, model_id: str, inputs: dict[str, object]) -> None:
        image_value = inputs.get("image")
        if isinstance(image_value, str) and image_value.strip():
            if not self._is_valid_base64_string(image_value):
                raise _LocalValidationError(
                    "invalid_image_format",
                    f"Invalid input for {verb} ({self._model_label(model_id)}): 'image' must be a base64-encoded string.",
                ) from None

        images_value = inputs.get("images")
        if isinstance(images_value, str) and images_value.strip():
            if not self._is_valid_base64_string(images_value):
                raise _LocalValidationError(
                    "invalid_images_format",
                    f"Invalid input for {verb} ({self._model_label(model_id)}): 'images' must be base64-encoded string(s).",
                ) from None
        elif isinstance(images_value, list):
            for item in images_value:
                if not isinstance(item, str) or not item.strip() or not self._is_valid_base64_string(item):
                    raise _LocalValidationError(
                        "invalid_images_format",
                        f"Invalid input for {verb} ({self._model_label(model_id)}): 'images' must be base64-encoded string(s).",
                    ) from None

    def _model_label(self, model_id: str) -> str:
        capability = self._model_capabilities_cache.get(model_id)
        if isinstance(capability, dict):
            name = capability.get("name")
            if isinstance(name, str) and name.strip():
                return f"{name.strip()} [{model_id}]"
        return model_id

    @staticmethod
    def _base64_payload(value: str) -> str:
        stripped = value.strip()
        if ";base64," in stripped:
            parts = stripped.split(",", 1)
            if len(parts) == 2:
                return parts[1].strip()
        return stripped

    @classmethod
    def _is_valid_base64_string(cls, value: str) -> bool:
        payload = cls._base64_payload(value)
        if not payload:
            return False
        try:
            decoded = base64.b64decode(payload, validate=True)
            return len(decoded) > 0
        except Exception:
            return False

    # Verb-first surface.
    def list_models(self):
        return self._run_safe(list_available_models, "Unable to fetch models. Please try again.")

    def get_model(self, model_id: str):
        return self._run_safe(
            get_model_details,
            "Unable to fetch model details. Please verify the model id and try again.",
            model_id,
        )

    def detect(self, model_id: str, image: str, prompt: str | None = None):
        normalized_model_id = require_str(model_id, "model_id")
        task = self._task_for_model(normalized_model_id)

        if task == "sam3":
            return self._run_inference_safe(
                run_sam3,
                "Unable to run detection. Please check your input and try again.",
                verb="detect",
                model_id=normalized_model_id,
                inputs={"image": image, "prompt": prompt},
                args=(image, "" if prompt is None else prompt, normalized_model_id),
                kwargs={},
            )

        if task == "face_detection":
            return self._run_inference_safe(
                run_face_detection,
                "Unable to run detection. Please check your input and try again.",
                verb="detect",
                model_id=normalized_model_id,
                inputs={"image": image, "prompt": prompt},
                args=(image, normalized_model_id),
                kwargs={},
            )

        if task == "instance_segmentation":
            return self._run_inference_safe(
                run_instance_segmentation,
                "Unable to run detection. Please check your input and try again.",
                verb="detect",
                model_id=normalized_model_id,
                inputs={"image": image, "prompt": prompt},
                args=(image, normalized_model_id),
                kwargs={},
            )

        return self._run_inference_safe(
            run_object_detection,
            "Unable to run detection. Please check your input and try again.",
            verb="detect",
            model_id=normalized_model_id,
            inputs={"image": image, "prompt": prompt},
            args=(image, normalized_model_id),
            kwargs={},
        )

    def segment(self, model_id: str, image: str, prompt: str | None = None):
        normalized_model_id = require_str(model_id, "model_id")
        task = self._task_for_model(normalized_model_id)

        if task == "sam3":
            return self._run_inference_safe(
                run_sam3,
                "Unable to run segmentation. Please check your input and try again.",
                verb="segment",
                model_id=normalized_model_id,
                inputs={"image": image, "prompt": prompt},
                args=(image, "" if prompt is None else prompt, normalized_model_id),
                kwargs={},
            )

        return self._run_inference_safe(
            run_instance_segmentation,
            "Unable to run segmentation. Please check your input and try again.",
            verb="segment",
            model_id=normalized_model_id,
            inputs={"image": image, "prompt": prompt},
            args=(image, normalized_model_id),
            kwargs={},
        )

    def recognize(self, model_id: str, image: str):
        normalized_model_id = require_str(model_id, "model_id")
        return self._run_inference_safe(
            run_face_recognition,
            "Unable to run recognition. Please check your input and try again.",
            verb="recognize",
            model_id=normalized_model_id,
            inputs={"image": image},
            args=(image, normalized_model_id),
            kwargs={},
        )

    def reidentify(self, model_id: str, image: str):
        normalized_model_id = require_str(model_id, "model_id")
        return self._run_inference_safe(
            run_person_reid,
            "Unable to run re-identification. Please check your input and try again.",
            verb="reidentify",
            model_id=normalized_model_id,
            inputs={"image": image},
            args=(image, normalized_model_id),
            kwargs={},
        )

    def estimate_pose(self, model_id: str, image: str):
        normalized_model_id = require_str(model_id, "model_id")
        return self._run_inference_safe(
            run_pose_estimation,
            "Unable to run pose estimation. Please check your input and try again.",
            verb="estimate_pose",
            model_id=normalized_model_id,
            inputs={"image": image},
            args=(image, normalized_model_id),
            kwargs={},
        )

    def embed(self, model_id: str, text: str | None = None, image: str | None = None):
        normalized_model_id = require_str(model_id, "model_id")

        has_text = isinstance(text, str) and bool(text.strip())
        has_image = isinstance(image, str) and bool(image.strip())
        if has_text == has_image:
            _raise_user_error("Provide exactly one input: `text` or `image`.")

        task = self._task_for_model(normalized_model_id)

        if has_text:
            payload_text = text if text is not None else ""
            if task == "clip":
                return self._run_inference_safe(
                    clip_text_embeddings,
                    "Unable to run embeddings. Please check your input and try again.",
                    verb="embed",
                    model_id=normalized_model_id,
                    inputs={"text": payload_text},
                    args=(payload_text, normalized_model_id),
                    kwargs={},
                )

            return self._run_inference_safe(
                run_text_embeddings,
                "Unable to run embeddings. Please check your input and try again.",
                verb="embed",
                model_id=normalized_model_id,
                inputs={"text": payload_text},
                args=(payload_text, normalized_model_id),
                kwargs={},
            )

        payload_image = image if image is not None else ""
        return self._run_inference_safe(
            clip_image_embeddings,
            "Unable to run embeddings. Please check your input and try again.",
            verb="embed",
            model_id=normalized_model_id,
            inputs={"image": payload_image},
            args=(payload_image, normalized_model_id),
            kwargs={},
        )

    def generate_text(
        self,
        model_id: str,
        prompt: str,
        image: str | None = None,
        images: str | list[str] | None = None,
        videos: str | list[str] | None = None,
    ) -> str:
        normalized_model_id = require_str(model_id, "model_id")
        task = self._task_for_model(normalized_model_id)

        if task == "slm":
            return self._run_inference_safe(
                run_slm,
                "Unable to generate text. Please check your input and try again.",
                verb="generate_text",
                model_id=normalized_model_id,
                inputs={"prompt": prompt, "text": prompt},
                args=(prompt, normalized_model_id),
                kwargs={},
            )

        vlm_images = images
        if image is not None:
            if isinstance(vlm_images, list):
                vlm_images = [image, *vlm_images]
            elif isinstance(vlm_images, str):
                vlm_images = [image, vlm_images]
            else:
                vlm_images = image

        return self._run_inference_safe(
            run_vlm,
            "Unable to generate text. Please check your input and try again.",
            verb="generate_text",
            model_id=normalized_model_id,
            inputs={
                "prompt": prompt,
                "text": prompt,
                "image": image,
                "images": vlm_images,
                "videos": videos,
            },
            args=(),
            kwargs={
                "model_id": normalized_model_id,
                "text": prompt,
                "images": vlm_images,
                "videos": videos,
            },
        )

    def analyze(
        self,
        model_id: str,
        text: str | None = None,
        images: str | list[str] | None = None,
        videos: str | list[str] | None = None,
    ) -> str:
        normalized_model_id = require_str(model_id, "model_id")
        return self._run_inference_safe(
            run_vlm,
            "Unable to analyze input. Please check your input and try again.",
            verb="analyze",
            model_id=normalized_model_id,
            inputs={"text": text, "images": images, "videos": videos},
            args=(),
            kwargs={
                "model_id": normalized_model_id,
                "text": text,
                "images": images,
                "videos": videos,
            },
        )

    def generate_image(self, model_id: str, prompt: str) -> str:
        normalized_model_id = require_str(model_id, "model_id")
        return self._run_inference_safe(
            run_image_generation,
            "Unable to generate image. Please check your input and try again.",
            verb="generate_image",
            model_id=normalized_model_id,
            inputs={"prompt": prompt},
            args=(prompt, normalized_model_id),
            kwargs={},
        )

    def generate_3d(self, model_id: str, image: str) -> str:
        normalized_model_id = require_str(model_id, "model_id")
        return self._run_inference_safe(
            run_three_d_asset_generation,
            "Unable to generate 3D asset. Please check your input and try again.",
            verb="generate_3d",
            model_id=normalized_model_id,
            inputs={"image": image},
            args=(image, normalized_model_id),
            kwargs={},
        )
