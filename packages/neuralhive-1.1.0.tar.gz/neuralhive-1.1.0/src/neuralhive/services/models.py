from __future__ import annotations

from ..core.config import SDKConfig
from ..core.http import HTTPClient


def _require_model_id(model_id: object) -> str:
    if not isinstance(model_id, str) or not model_id.strip():
        raise ValueError("Invalid `model_id` value.") from None
    return model_id


class ModelsService:
    def __init__(self, config: SDKConfig, api_key: str | None = None) -> None:
        self._config = config
        self._client = HTTPClient(config=config, api_key=api_key)

    def connect(self, api_key: str) -> object:
        return self._client.post_sdk(
            "connect",
            timeout_seconds=self._config.connect_timeout_seconds,
            api_key_override=api_key,
        )

    def list_models(self) -> object:
        return self._client.get_sdk(
            "models",
            timeout_seconds=self._config.sdk_timeout_seconds,
        )

    def get_model(self, model_id: str) -> object:
        normalized_model_id = _require_model_id(model_id)
        return self._client.get_sdk(
            f"models/{normalized_model_id}",
            timeout_seconds=self._config.sdk_timeout_seconds,
        )
