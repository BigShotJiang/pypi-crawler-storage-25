from __future__ import annotations

from collections.abc import Mapping
from time import sleep
from typing import Any

from ..core.config import SDKConfig
from ..core.http import HTTPClient


class InferenceService:
    def __init__(self, config: SDKConfig, api_key: str | None = None) -> None:
        self._config = config
        self._client = HTTPClient(config=config, api_key=api_key)

    def run(self, payload: Mapping[str, Any]) -> object:
        return self._client.post_inference(
            payload,
            timeout_seconds=self._config.inference_timeout_seconds,
        )

    def poll_result(self, request_id: str) -> object:
        normalized_request_id = request_id.strip()
        if not normalized_request_id:
            raise RuntimeError("Invalid request id.") from None

        results_url = (
            f"{self._config.inference_base_url.rstrip('/')}/results/{normalized_request_id}"
        )

        for _ in range(self._config.max_poll_attempts):
            payload = self._client.get_absolute(
                results_url,
                timeout_seconds=self._config.inference_timeout_seconds,
            )

            if not isinstance(payload, Mapping):
                raise RuntimeError("Invalid polling response.") from None

            status = str(payload.get("status", "")).strip().lower()
            if status in {"completed", "failed"}:
                return payload

            if status == "processing":
                sleep(self._config.poll_interval_seconds)
                continue

            return payload

        return {
            "status": "processing",
            "request_id": normalized_request_id,
            "message": "Result not ready yet. Please wait and try again.",
        }
