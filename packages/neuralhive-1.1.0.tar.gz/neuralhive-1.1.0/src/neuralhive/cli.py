from __future__ import annotations

import argparse
import sys
from importlib.metadata import PackageNotFoundError, version

from .core.credentials import store_api_key


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="neuralhive")
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show installed neuralhive version",
    )
    subparsers = parser.add_subparsers(dest="command")

    configure = subparsers.add_parser("configure", help="Configure NeuralHive SDK credentials")
    configure.add_argument("--api-key", required=True, help="NeuralHive API key")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.version:
        try:
            current = version("neuralhive")
        except PackageNotFoundError:
            current = "unknown"
        print(current)
        return 0

    if args.command == "configure":
        try:
            target = store_api_key(args.api_key)
        except ValueError:
            print("Invalid API key. Please provide a non-empty key.", file=sys.stderr)
            return 1
        except Exception:
            print("Unable to save credentials. Please try again.", file=sys.stderr)
            return 1

        print(f"Credentials saved to {target}")
        return 0

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
