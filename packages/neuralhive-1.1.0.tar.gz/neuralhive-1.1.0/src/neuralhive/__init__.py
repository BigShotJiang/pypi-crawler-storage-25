from .client import Client

__all__ = ["Client"]

# Keep package root surface minimal (Client-only).
for _private_name in ("clip_embeddings", "object_detection", "person_reid", "text_embeddings", "slm", "sam3", "face_recognition", "face_detection", "three_d_asset_generation", "pose_estimation", "instance_segmentation", "vlm", "models"):
    globals().pop(_private_name, None)
del _private_name
