from __future__ import annotations

from .._shared import post_json
from ..adapters.object_detection import Result as DetectionResult
from ..adapters.object_detection import build_payload, parse_result


def object_detection(image_b64: str, model_id: str) -> DetectionResult:
    try:
        payload = build_payload(image_b64=image_b64, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run object detection. Please try again.") from None
