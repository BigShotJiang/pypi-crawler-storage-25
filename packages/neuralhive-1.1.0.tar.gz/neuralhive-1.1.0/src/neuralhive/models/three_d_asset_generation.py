from __future__ import annotations

from .._shared import get_api_key, get_runtime_config
from ..adapters.three_d_asset_generation import build_payload, parse_result
from ..services.inference import InferenceService


def _service() -> InferenceService:
    return InferenceService(config=get_runtime_config(), api_key=get_api_key())


def three_d_asset_generation(image: str, model_id: str) -> str:
    try:
        payload = build_payload(image=image, model_id=model_id)

        initial_response = _service().run(payload)
        initial_parse = parse_result(initial_response)

        if initial_parse["status"] == "completed":
            return initial_parse["url"]

        if initial_parse["status"] == "accepted" and initial_parse["request_id"]:
            polled_response = _service().poll_result(initial_parse["request_id"])
            polled_parse = parse_result(polled_response)
            if polled_parse["status"] == "completed":
                return polled_parse["url"]
            return ""

        if initial_parse["status"] in {"processing", "failed"}:
            return ""

        return ""
    except Exception:
        return ""
