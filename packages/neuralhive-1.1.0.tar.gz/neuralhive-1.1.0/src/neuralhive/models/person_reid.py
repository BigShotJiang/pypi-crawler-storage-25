from __future__ import annotations

from .._shared import post_json
from ..adapters.person_reid import Result as PersonReIDResult
from ..adapters.person_reid import build_payload, parse_result


def person_reid(image_b64: str, model_id: str) -> PersonReIDResult:
    try:
        payload = build_payload(image_b64=image_b64, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run person re-identification. Please try again.") from None
