from __future__ import annotations

from .._shared import post_json
from ..adapters.slm import build_payload, parse_result


def slm(text: str, model_id: str) -> str:
    try:
        payload = build_payload(text=text, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run SLM inference. Please try again.") from None
