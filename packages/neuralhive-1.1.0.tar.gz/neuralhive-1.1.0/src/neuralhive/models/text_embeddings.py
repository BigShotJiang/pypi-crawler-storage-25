from __future__ import annotations

from .._shared import post_json
from ..adapters.text_embeddings import build_payload, parse_result


def text_embeddings(text: str, model_id: str) -> list[float]:
    try:
        payload = build_payload(text=text, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run text embeddings. Please try again.") from None
