from __future__ import annotations

from .._shared import post_json
from ..adapters.face_detection import Result as FaceDetectionResult
from ..adapters.face_detection import build_payload, parse_result


def face_detection(image: str, model_id: str) -> FaceDetectionResult:
    try:
        payload = build_payload(image=image, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run face detection inference. Please try again.") from None
