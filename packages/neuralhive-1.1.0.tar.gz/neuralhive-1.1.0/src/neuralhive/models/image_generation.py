from __future__ import annotations

from .._shared import post_json
from ..adapters.image_generation import build_payload, parse_result


def image_generation(prompt: str, model_id: str) -> str:
    try:
        payload = build_payload(prompt=prompt, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run image generation. Please try again.") from None
