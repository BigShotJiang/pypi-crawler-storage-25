from __future__ import annotations

from .._shared import post_json
from ..adapters.instance_segmentation import Result as InstanceSegmentationResult
from ..adapters.instance_segmentation import build_payload, parse_result


def instance_segmentation(image: str, model_id: str) -> InstanceSegmentationResult:
    try:
        payload = build_payload(image=image, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run instance segmentation inference. Please try again.") from None
