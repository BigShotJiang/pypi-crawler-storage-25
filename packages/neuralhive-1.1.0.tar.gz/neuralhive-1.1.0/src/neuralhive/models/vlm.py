from __future__ import annotations

from .._shared import post_json
from ..adapters.vlm import MAX_IMAGES_TOTAL_BYTES, MAX_VIDEOS_TOTAL_BYTES, build_payload, parse_result


def vlm(
    model_id: str,
    text: str | None = None,
    images: str | list[str] | None = None,
    videos: str | list[str] | None = None,
) -> str:
    try:
        payload = build_payload(
            model_id=model_id,
            text=text,
            images=images,
            videos=videos,
        )
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run VLM inference. Please try again.") from None
