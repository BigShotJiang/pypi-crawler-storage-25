from __future__ import annotations

from .._shared import post_json
from ..adapters.face_recognition import build_payload, parse_result


def face_recognition(image: str, model_id: str) -> list[float]:
    try:
        payload = build_payload(image=image, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run face recognition inference. Please try again.") from None
