from __future__ import annotations

from collections.abc import Mapping
from typing import TypedDict

from .._shared import get_api_key, get_runtime_config, require_str
from ..services.models import ModelsService


class ModelItem(TypedDict, total=False):
    _id: str
    name: str
    task: str
    project: str
    deploy_status: str


class ModelDetails(TypedDict, total=False):
    _id: str
    name: str
    task: str
    project: str
    deploy_status: str
    is_uploaded: bool


def _service() -> ModelsService:
    return ModelsService(config=get_runtime_config(), api_key=get_api_key())


def list_models() -> list[ModelItem]:
    try:
        data = _service().list_models()
        if not isinstance(data, Mapping):
            raise RuntimeError("Received an invalid response from service.") from None

        models = data.get("models")
        if not isinstance(models, list):
            raise RuntimeError("Received an invalid models response.") from None

        parsed: list[ModelItem] = []
        for item in models:
            if not isinstance(item, Mapping):
                continue

            task = str(item.get("task", ""))
            parsed.append(
                {
                    "_id": str(item.get("_id", "")),
                    "name": str(item.get("name", "")),
                    "task": task,
                }
            )

        return parsed
    except Exception:
        raise RuntimeError("Unable to fetch models. Please try again.") from None


def get_model(model_id: str) -> ModelDetails:
    try:
        normalized_model_id = require_str(model_id, "model_id")
        data = _service().get_model(normalized_model_id)

        if not isinstance(data, Mapping):
            raise RuntimeError("Received an invalid response from service.") from None

        model = data.get("model")
        if not isinstance(model, Mapping):
            raise RuntimeError("Received an invalid model response.") from None

        task = str(model.get("task", ""))
        return {
            "_id": str(model.get("_id", "")),
            "name": str(model.get("name", "")),
            "task": task,
            "project": str(model.get("project", "")),
            "deploy_status": str(model.get("deploy_status", "")),
            "is_uploaded": bool(model.get("is_uploaded", False)),
        }
    except Exception:
        raise RuntimeError("Unable to fetch model details. Please try again.") from None
