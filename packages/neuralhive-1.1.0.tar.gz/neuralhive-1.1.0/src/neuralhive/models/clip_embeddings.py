from __future__ import annotations

from typing import Literal, TypedDict, cast

from .._shared import is_float_list, is_float_matrix, post_json, require_result_object, require_str


Embeddings = list[float] | list[list[float]]


class _EmbeddingsResult(TypedDict):
    embeddings: Embeddings


class _EmbeddingsResponse(TypedDict):
    result: _EmbeddingsResult


class _InferencePayload(TypedDict):
    data_type: Literal["text", "image"]
    model_type: Literal["clip"]
    payloads: str
    model_id: str


def _parse_embeddings(data: object) -> Embeddings:
    result = require_result_object(data)

    embeddings = result.get("embeddings")
    if is_float_list(embeddings):
        return [float(item) for item in embeddings]

    if is_float_matrix(embeddings):
        return [[float(item) for item in row] for row in embeddings]

    raise RuntimeError("Received an invalid embeddings response.") from None


def _post_embeddings(payload: _InferencePayload) -> Embeddings:
    data = post_json(payload)
    parsed_embeddings = _parse_embeddings(data)

    _typed_response: _EmbeddingsResponse = cast(
        _EmbeddingsResponse, {"result": {"embeddings": parsed_embeddings}}
    )
    return _typed_response["result"]["embeddings"]


def text(input_text: str, model_id: str) -> Embeddings:
    try:
        require_str(input_text, "input_text")
        require_str(model_id, "model_id")
        payload: _InferencePayload = {
            "data_type": "text",
            "model_type": "clip",
            "payloads": input_text,
            "model_id": model_id,
        }
        return _post_embeddings(payload)
    except Exception:
        raise RuntimeError("Unable to run text inference. Please try again.") from None


def image(image_b64: str, model_id: str) -> Embeddings:
    try:
        require_str(image_b64, "image_b64")
        require_str(model_id, "model_id")
        payload: _InferencePayload = {
            "data_type": "image",
            "model_type": "clip",
            "payloads": image_b64,
            "model_id": model_id,
        }
        return _post_embeddings(payload)
    except Exception:
        raise RuntimeError("Unable to run image inference. Please try again.") from None
