from __future__ import annotations

from .._shared import post_json
from ..adapters.pose_estimation import Result as PoseEstimationResult
from ..adapters.pose_estimation import build_payload, parse_result


def pose_estimation(image: str, model_id: str) -> PoseEstimationResult:
    try:
        payload = build_payload(image=image, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run pose estimation inference. Please try again.") from None
