from __future__ import annotations

from .._shared import post_json
from ..adapters.sam3 import Result as Sam3Result
from ..adapters.sam3 import build_payload, parse_result


def sam3(image: str, prompt: str, model_id: str) -> Sam3Result:
    try:
        payload = build_payload(image=image, prompt=prompt, model_id=model_id)
        return parse_result(post_json(payload))
    except Exception:
        raise RuntimeError("Unable to run SAM3 inference. Please try again.") from None
