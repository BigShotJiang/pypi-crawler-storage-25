from __future__ import annotations

from collections.abc import Mapping
from typing import Literal, TypedDict

from .._shared import require_str


class Payload(TypedDict):
    model_id: str
    model_type: Literal["3d_asset_generation"]
    image: str


class ParseResult(TypedDict):
    status: str
    request_id: str
    url: str


def build_payload(image: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "3d_asset_generation",
        "image": require_str(image, "image"),
    }


def _extract_completed_url(data: Mapping[str, object]) -> str:
    result = data.get("result")
    if not isinstance(result, Mapping):
        return ""
    glb_file_url = result.get("glb_file_url")
    return glb_file_url if isinstance(glb_file_url, str) else ""


def parse_result(response: object) -> ParseResult:
    if not isinstance(response, Mapping):
        return {"status": "", "request_id": "", "url": ""}

    status = str(response.get("status", "")).strip().lower()
    request_id_raw = response.get("request_id")
    request_id = str(request_id_raw).strip() if request_id_raw is not None else ""

    if status == "completed":
        return {"status": status, "request_id": request_id, "url": _extract_completed_url(response)}

    if status in {"accepted", "processing", "failed"}:
        return {"status": status, "request_id": request_id, "url": ""}

    return {"status": "", "request_id": request_id, "url": ""}
