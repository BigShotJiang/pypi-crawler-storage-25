from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import require_result_object, require_str


class Result(TypedDict):
    embeddings: list[object]
    masks: list[object]
    visibility_scores: list[object]


class Payload(TypedDict):
    image: str
    model_id: str
    model_type: Literal["person_reid"]


def build_payload(image_b64: str, model_id: str) -> Payload:
    return {
        "image": require_str(image_b64, "image_b64"),
        "model_id": require_str(model_id, "model_id"),
        "model_type": "person_reid",
    }


def _is_numeric_nested(value: object) -> bool:
    if isinstance(value, (int, float)):
        return True
    if isinstance(value, list):
        return all(_is_numeric_nested(item) for item in value)
    return False


def _normalize_numeric_nested(value: object) -> object:
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, list):
        return [_normalize_numeric_nested(item) for item in value]
    raise RuntimeError("Received an invalid response from service.") from None


def parse_result(response: object) -> Result:
    result = require_result_object(response)

    embeddings = result.get("embeddings")
    masks = result.get("masks")
    visibility_scores = result.get("visibility_scores")

    if not isinstance(embeddings, list) or not _is_numeric_nested(embeddings):
        raise RuntimeError("Received an invalid embeddings response.") from None
    if not isinstance(masks, list) or not _is_numeric_nested(masks):
        raise RuntimeError("Received an invalid masks response.") from None
    if not isinstance(visibility_scores, list) or not _is_numeric_nested(visibility_scores):
        raise RuntimeError("Received an invalid visibility response.") from None

    return {
        "embeddings": [_normalize_numeric_nested(item) for item in embeddings],
        "masks": [_normalize_numeric_nested(item) for item in masks],
        "visibility_scores": [_normalize_numeric_nested(item) for item in visibility_scores],
    }
