from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import require_result_object, require_str


class Result(TypedDict):
    masks: list[object]
    boxes: list[object]
    score: str
    image_height: str
    image_width: str


class Payload(TypedDict):
    model_id: str
    model_type: Literal["sam3"]
    image: str
    prompt: str


def build_payload(image: str, prompt: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "sam3",
        "image": require_str(image, "image"),
        "prompt": require_str(prompt, "prompt"),
    }


def parse_result(response: object) -> Result:
    result = require_result_object(response)

    masks = result.get("masks")
    boxes = result.get("boxes")

    if not isinstance(masks, list):
        masks = []
    if not isinstance(boxes, list):
        boxes = []

    score_value = result.get("score")
    if score_value is None:
        scores = result.get("scores")
        if isinstance(scores, list) and scores:
            score_value = scores[0]

    return {
        "masks": masks,
        "boxes": boxes,
        "score": "" if score_value is None else str(score_value),
        "image_height": str(result.get("image_height", "")),
        "image_width": str(result.get("image_width", "")),
    }
