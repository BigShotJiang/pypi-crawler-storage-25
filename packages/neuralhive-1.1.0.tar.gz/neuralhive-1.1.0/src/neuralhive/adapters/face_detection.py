from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import require_result_object, require_str


class Result(TypedDict):
    boxes: list[object]
    classes: list[object]
    scores: list[object]
    masks: list[object]


class Payload(TypedDict):
    model_id: str
    model_type: Literal["face_detection"]
    image: str


def build_payload(image: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "face_detection",
        "image": require_str(image, "image"),
    }


def parse_result(response: object) -> Result:
    result = require_result_object(response)

    boxes = result.get("boxes")
    classes = result.get("classes")
    scores = result.get("scores")
    masks = result.get("masks")

    return {
        "boxes": boxes if isinstance(boxes, list) else [],
        "classes": classes if isinstance(classes, list) else [],
        "scores": scores if isinstance(scores, list) else [],
        "masks": masks if isinstance(masks, list) else [],
    }
