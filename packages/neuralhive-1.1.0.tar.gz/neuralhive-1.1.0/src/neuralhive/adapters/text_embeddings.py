from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import is_float_list, require_result_object, require_str


class Payload(TypedDict):
    model_id: str
    model_type: Literal["text_embeddings"]
    text: str


def build_payload(text: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "text_embeddings",
        "text": require_str(text, "text"),
    }


def parse_result(response: object) -> list[float]:
    result = require_result_object(response)
    embeddings = result.get("embeddings")
    if not is_float_list(embeddings):
        raise RuntimeError("Received an invalid embeddings response.") from None
    return [float(item) for item in embeddings]
