from __future__ import annotations

from collections.abc import Mapping
from typing import Literal, TypedDict

from .._shared import require_str


class Payload(TypedDict):
    model_id: str
    model_type: Literal["slm"]
    text: str


def build_payload(text: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "slm",
        "text": require_str(text, "text"),
    }


def parse_result(response: object) -> str:
    if not isinstance(response, Mapping):
        return ""

    choices = response.get("choices")
    if not isinstance(choices, list) and isinstance(response.get("result"), Mapping):
        choices = response["result"].get("choices")

    if not isinstance(choices, list) or not choices:
        return ""

    first = choices[0]
    if not isinstance(first, Mapping):
        return ""

    message = first.get("message")
    if not isinstance(message, Mapping):
        return ""

    content = message.get("content")
    return content if isinstance(content, str) else ""
