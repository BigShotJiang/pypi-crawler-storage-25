from __future__ import annotations

from collections.abc import Mapping
from math import ceil
from typing import Any, Literal, TypedDict

from .._shared import require_str

MAX_IMAGES_TOTAL_BYTES = 5 * 1024 * 1024
MAX_VIDEOS_TOTAL_BYTES = 30 * 1024 * 1024


class Payload(TypedDict, total=False):
    model_id: str
    model_type: Literal["vlm"]
    prompt: str
    payloads: dict[str, list[str]]
    data_type: Literal["text", "image", "video", "multimedia"]


def _is_url(value: str) -> bool:
    lowered = value.lower()
    return lowered.startswith("http://") or lowered.startswith("https://")


def _extract_base64_data(value: str) -> str:
    item = value.strip()
    if "," in item and ";base64" in item:
        _, encoded = item.split(",", 1)
        return encoded.strip()
    return item


def _approx_base64_bytes(value: str) -> int:
    encoded = _extract_base64_data(value)
    if not encoded:
        return 0
    padding = encoded.count("=")
    return max(0, ceil((len(encoded) * 3) / 4) - padding)


def _to_str_list(value: str | list[str] | None, field_name: str) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [require_str(value, field_name)]
    if isinstance(value, list):
        parsed: list[str] = []
        for idx, item in enumerate(value):
            parsed.append(require_str(item, f"{field_name}[{idx}]"))
        return parsed
    raise ValueError(f"Invalid `{field_name}` value.") from None


def _sum_binary_bytes(items: list[str]) -> int:
    total = 0
    for item in items:
        if _is_url(item):
            continue
        total += _approx_base64_bytes(item)
    return total


def build_payload(
    model_id: str,
    text: str | None = None,
    images: str | list[str] | None = None,
    videos: str | list[str] | None = None,
) -> Payload:
    normalized_model_id = require_str(model_id, "model_id")

    normalized_text = ""
    if text is not None and str(text).strip():
        normalized_text = require_str(text, "text")

    normalized_images = _to_str_list(images, "images")
    normalized_videos = _to_str_list(videos, "videos")

    if not normalized_text and not normalized_images and not normalized_videos:
        raise ValueError("At least one input is required.") from None

    images_total = _sum_binary_bytes(normalized_images)
    videos_total = _sum_binary_bytes(normalized_videos)

    if images_total > MAX_IMAGES_TOTAL_BYTES:
        raise ValueError("Total images payload exceeds 5MB.") from None
    if videos_total > MAX_VIDEOS_TOTAL_BYTES:
        raise ValueError("Total videos payload exceeds 30MB.") from None

    has_images = len(normalized_images) > 0
    has_videos = len(normalized_videos) > 0

    vlm_data_type: Literal["text", "image", "video", "multimedia"] = "text"
    if has_images and has_videos:
        vlm_data_type = "multimedia"
    elif has_images:
        vlm_data_type = "image"
    elif has_videos:
        vlm_data_type = "video"

    payload: Payload = {
        "model_id": normalized_model_id,
        "model_type": "vlm",
        "prompt": normalized_text,
        "data_type": vlm_data_type,
    }

    if has_images or has_videos:
        payload["payloads"] = {
            "images": normalized_images,
            "videos": normalized_videos,
        }

    return payload


def parse_result(response: object) -> str:
    if not isinstance(response, Mapping):
        return ""

    result = response.get("result")
    choices_source: Any = response.get("choices")
    if isinstance(result, Mapping) and not isinstance(choices_source, list):
        choices_source = result.get("choices")

    if not isinstance(choices_source, list) or not choices_source:
        return ""

    first_choice = choices_source[0]
    if not isinstance(first_choice, Mapping):
        return ""

    message = first_choice.get("message")
    if not isinstance(message, Mapping):
        return ""

    content = message.get("content")
    return content if isinstance(content, str) else ""
