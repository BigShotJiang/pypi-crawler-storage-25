from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import is_float_list, require_result_object, require_str


class Payload(TypedDict):
    model_id: str
    model_type: Literal["face_recognition"]
    image: str


def build_payload(image: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "face_recognition",
        "image": require_str(image, "image"),
    }


def parse_result(response: object) -> list[float]:
    result = require_result_object(response)
    feature = result.get("feature")

    if not is_float_list(feature):
        raise RuntimeError("Received an invalid embeddings response.") from None

    return [float(item) for item in feature]
