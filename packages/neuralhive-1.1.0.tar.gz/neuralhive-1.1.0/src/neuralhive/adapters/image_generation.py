from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import require_result_object, require_str


class Payload(TypedDict):
    model_id: str
    model_type: Literal["image_generation"]
    text: str


def build_payload(prompt: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "image_generation",
        "text": require_str(prompt, "prompt"),
    }


def parse_result(response: object) -> str:
    result = require_result_object(response)
    image_url = result.get("image_url")
    return image_url if isinstance(image_url, str) else ""
