from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import require_result_object, require_str


class Result(TypedDict):
    keypoints: list[object]
    scores: list[object]


class Payload(TypedDict):
    model_id: str
    model_type: Literal["pose_estimation"]
    image: str


def build_payload(image: str, model_id: str) -> Payload:
    return {
        "model_id": require_str(model_id, "model_id"),
        "model_type": "pose_estimation",
        "image": require_str(image, "image"),
    }


def parse_result(response: object) -> Result:
    result = require_result_object(response)
    keypoints = result.get("keypoints")
    scores = result.get("scores")

    return {
        "keypoints": keypoints if isinstance(keypoints, list) else [],
        "scores": scores if isinstance(scores, list) else [],
    }
