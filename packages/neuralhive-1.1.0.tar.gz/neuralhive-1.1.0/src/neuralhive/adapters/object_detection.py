from __future__ import annotations

from typing import Literal, TypedDict

from .._shared import is_float_list, is_float_matrix, require_result_object, require_str


class Result(TypedDict):
    boxes: list[list[float]]
    classes: list[int]
    scores: list[float]


class Payload(TypedDict):
    image: str
    model_id: str
    model_type: Literal["object_detection"]


def build_payload(image_b64: str, model_id: str) -> Payload:
    return {
        "image": require_str(image_b64, "image_b64"),
        "model_id": require_str(model_id, "model_id"),
        "model_type": "object_detection",
    }


def _parse_classes(value: object) -> list[int]:
    if not isinstance(value, list):
        raise RuntimeError("Received an invalid classes response.") from None

    parsed: list[int] = []
    for item in value:
        if isinstance(item, int):
            parsed.append(item)
            continue

        if isinstance(item, float) and item.is_integer():
            parsed.append(int(item))
            continue

        if isinstance(item, str):
            stripped = item.strip()
            if stripped.isdigit():
                parsed.append(int(stripped))
                continue

        raise RuntimeError("Received an invalid classes response.") from None

    return parsed


def parse_result(response: object) -> Result:
    result = require_result_object(response)

    boxes = result.get("boxes")
    classes = result.get("classes")
    scores = result.get("scores")

    if not is_float_matrix(boxes):
        raise RuntimeError("Received an invalid boxes response.") from None
    parsed_classes = _parse_classes(classes)
    if not is_float_list(scores):
        raise RuntimeError("Received an invalid scores response.") from None

    return {
        "boxes": [[float(item) for item in box] for box in boxes],
        "classes": parsed_classes,
        "scores": [float(item) for item in scores],
    }
