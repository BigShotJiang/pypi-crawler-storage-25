import requests
import httpx
import re
import asyncio
import importlib.metadata
import uuid
import inspect
from urllib.parse import urlparse
from typing import Optional, Dict, Any, Callable, List
import warnings
import base64
import json

from eth_account import Account
from .models import (
    AssetType, SchemeType, OmikujiResponse, AgentIdentity, ConfessionResponse, 
    HonoResponse, CompareResponse, AggregateResponse, BenchmarkOverviewResponse,
    HateoasErrorResponse, MonzenTraceResponse, MonzenMetricsResponse,
    MonzenGraphResponse, PaymentPolicy, SettlementReceipt,
    ParsedChallenge, ExecutionResult, 
    ExecutionContext, TrustDecision, OutcomeSummary, TrustEvidence,
    PaymentEvidenceRecord, EvidenceRepository,
    ChallengeSource, AttestationSource, NextAction,
    _ExecutionUnlock, _FundingPolicy, _EntitlementKind, _ExecutionAccessPlan
)
from .exceptions import (
    PaymentExecutionError, InvoiceParseError, NavigationGuardrailError, 
    CounterpartyTrustError, PaymentChallengeError
)
from .crypto.protocols import EVMSigner, LightningProvider

try:
    from .crypto.protocols import SolanaSigner
except ImportError:
    SolanaSigner = Any

def get_sdk_version() -> str:
    try:
        return importlib.metadata.version("ln-church-agent")
    except importlib.metadata.PackageNotFoundError:
        return "1.6.0" 

SDK_VERSION = get_sdk_version()
CUSTOM_USER_AGENT = f"ln-church-agent/{get_sdk_version()}"

def _decode_jwt_payload(token: str) -> dict:
    """Lightweight base64 decoder to extract JWT/JWS claims without cryptographic verification."""
    try:
        parts = token.split('.')
        if len(parts) != 3: 
            return {}
        payload_b64 = parts[1]
        padded = payload_b64 + '=' * (-len(payload_b64) % 4)
        import base64, json
        return json.loads(base64.urlsafe_b64decode(padded).decode('utf-8'))
    except Exception:
        return {}

# base64対応
def _b64url_decode(b64_str: str) -> dict:
    """Base64URL文字列をデコードしてJSON辞書として返す安全なヘルパー"""
    try:
        # 足りないパディング(=)を自動補完
        padded = b64_str + '=' * (-len(b64_str) % 4)
        decoded_bytes = base64.urlsafe_b64decode(padded)
        return json.loads(decoded_bytes.decode('utf-8'))
    except Exception:
        return {}

def _b64url_encode(data_dict: dict) -> str:
    """JSON辞書をBase64URL文字列（パディングなし）にエンコードするヘルパー"""
    json_str = json.dumps(data_dict)
    b64_bytes = base64.urlsafe_b64encode(json_str.encode('utf-8'))
    return b64_bytes.decode('utf-8').rstrip('=')

# 内部用のレガシーSchemeマッピングヘルパー
# ⛩️ 本殿の新しい命名規則（語彙体系）へ追随
def _normalize_scheme(raw_scheme: str) -> str:
    s = raw_scheme.lower()
    # 独自仕様のレガシーエイリアスを正規化
    if s == "x402-direct": return SchemeType.lnc_evm_transfer.value
    if s == "x402-solana": return SchemeType.lnc_solana_transfer.value
    if s == "x402-relay":  return SchemeType.lnc_evm_relay.value
    
    # 'x402' は標準仕様 (Foundation準拠) としてそのまま通す
    if s == "x402": return SchemeType.x402.value
    
    return raw_scheme

# ==========================================
# 🌟 CORE: 汎用的な402決済 & HATEOASクライアント
# ==========================================
class Payment402Client:
    def __init__(
        self, 
        private_key: Optional[str] = None, 
        ln_api_url: Optional[str] = None,
        ln_api_key: Optional[str] = None,
        ln_provider: str = "lnbits",
        base_url: str = "",
        evm_rpc_url: Optional[str] = None, 
        nwc_bridge_url: Optional[str] = None, 
        auto_navigate: bool = False,
        max_hops: int = 2,
        allow_unsafe_navigate: bool = False,
        max_payment_retries: int = 2,
        nwc_uri: Optional[str] = None,
        policy: Optional[PaymentPolicy] = None,
        evm_signer: Optional[EVMSigner] = None,
        ln_adapter: Optional[LightningProvider] = None,
        solana_signer: Optional[SolanaSigner] = None,
        trust_evaluators: Optional[List[Callable]] = None,
        evidence_repo: Optional[EvidenceRepository] = None,
        l402_executor: Optional[Any] = None, # 循環参照回避のためAny許容、内部で型判定
        prefer_lightninglabs_l402: bool = False,
        l402_delegate_allowed_hosts: Optional[List[str]] = None,
    ):
        self.private_key = private_key
        self.ln_api_url = ln_api_url
        self.ln_api_key = ln_api_key
        self.ln_provider = ln_provider
        self.base_url = base_url.rstrip('/') if base_url else ""
        self.evm_rpc_url = evm_rpc_url
        
        self.auto_navigate = auto_navigate
        self.max_hops = max_hops
        self.allow_unsafe_navigate = allow_unsafe_navigate
        self.max_payment_retries = max_payment_retries
        self.policy = policy or PaymentPolicy()
        self.last_receipt: Optional[SettlementReceipt] = None 

        self.evm_signer = evm_signer
        if not self.evm_signer and private_key:
            from .crypto.evm import LocalKeyAdapter
            self.evm_signer = LocalKeyAdapter(private_key)

        self.solana_signer = solana_signer
        if not self.solana_signer and private_key:
            try:
                from .crypto.solana import LocalSolanaAdapter
                self.solana_signer = LocalSolanaAdapter(private_key)
            except ImportError:
                pass

        self.ln_adapter = ln_adapter
        if not self.ln_adapter:
            if nwc_uri:
                from .adapters.nwc import NWCAdapter
                self.ln_adapter = NWCAdapter(nwc_uri=nwc_uri, bridge_url=nwc_bridge_url)
            elif ln_api_key:
                from .crypto.lightning import LegacyLNAdapter
                self.ln_adapter = LegacyLNAdapter(ln_api_url, ln_api_key, ln_provider)

        self._async_client: Optional[httpx.AsyncClient] = None
        self.trust_evaluators = trust_evaluators or []
        self.evidence_repo = evidence_repo
        self.l402_executor = l402_executor
        self.prefer_lightninglabs_l402 = prefer_lightninglabs_l402
        self.l402_delegate_allowed_hosts = l402_delegate_allowed_hosts or []

    # ==========================================
    # v1.3.0: 共通責務の分離 (Cold Spec & Policy Layer)
    # ==========================================
    def _parse_challenge(self, response: httpx.Response, expected_asset: str = "USDC") -> ParsedChallenge:
        h = response.headers
        
        # ★ 1. Lightning系 (L402/MPP) を最優先で処理
        # Dual-Stack環境では PAYMENT-REQUIRED よりも、インボイスを含むこちらが重要
        auth_h = h.get("WWW-Authenticate", "")
        if auth_h.upper().startswith(("L402", "PAYMENT", "MPP")):
            return self._parse_www_authenticate(auth_h, source=ChallengeSource.STANDARD_WWW)

        # ★ 2. x402系 (PAYMENT-REQUIRED)
        if "PAYMENT-REQUIRED" in h:
            val = h["PAYMENT-REQUIRED"]
            # 新標準 (Base64 JSON) か 旧レガシー (network="..." 文字列) か判定
            if not val.startswith('network='):
                payload = _b64url_decode(val)
                if payload:
                    params = {
                        "network": payload.get("network", "unknown"),
                        "amount": payload.get("amount", 0),
                        "asset": payload.get("asset", expected_asset),
                        "destination": payload.get("destination", ""),
                        "challenge": payload.get("challenge", "")
                    }
                    # 念のためボディからも不足パラメータを補完
                    try:
                        body_params = response.json().get("challenge", {}).get("parameters", {})
                        params.update(body_params)
                    except Exception:
                        pass

                    return ParsedChallenge(
                        scheme=payload.get("scheme", "x402"),
                        network=params["network"],
                        amount=float(params["amount"]),
                        asset=params["asset"],
                        parameters=params,
                        source=ChallengeSource.STANDARD_X402,
                        raw_header=val
                    )
            
            # フォールバック: レガシー文字列パース
            params = {k: v.strip('"') for k, v in re.findall(r'(\w+)="?([^",]+)"?', val)}
            
            # ★ 修正: レガシー文字列には destination が含まれないためボディから取得
            try:
                body_params = response.json().get("challenge", {}).get("parameters", {})
                params.update(body_params)
            except Exception:
                pass

            return ParsedChallenge(
                scheme=params.get("scheme", "x402"),
                network=params.get("network", "unknown"),
                amount=float(params.get("amount", 0)),
                asset=params.get("asset", expected_asset),
                parameters=params,
                source=ChallengeSource.STANDARD_X402,
                raw_header=val
            )

        # 3. フォールバック: レスポンスボディ (LN教旧仕様)
        try:
            body = response.json()
            if "challenge" in body:
                c = body["challenge"]
                return ParsedChallenge(
                    scheme=c.get("scheme"),
                    network=c.get("network"),
                    amount=float(c.get("amount", 0)),
                    asset=c.get("asset"),
                    parameters=c.get("parameters", {}),
                    source=ChallengeSource.BODY_CHALLENGE
                )
        except Exception:
            pass

        # 4. 最終手段: 旧カスタムヘッダー
        if "x-402-payment-required" in h:
            return self._parse_legacy_header(h["x-402-payment-required"])

        raise PaymentChallengeError("No valid 402 challenge found in headers or body.")

    def _parse_www_authenticate(self, auth_header: str, source: ChallengeSource) -> ParsedChallenge:
        """WWW-Authenticate (L402 / MPP) ヘッダーのパース処理"""
        parts = auth_header.split(" ", 1)
        scheme = parts[0]
        params = {}
        if len(parts) > 1:
            params = {k.strip(): v.strip('"') for k, v in re.findall(r'(\w+)="?([^",]+)"?', parts[1])}
            
        return ParsedChallenge(
            scheme=scheme,
            network="Lightning", # デフォルトネットワーク
            amount=0.0,          # 通常L402はインボイス内に金額が含まれるため0とする
            asset="SATS",
            parameters=params,
            source=source,
            raw_header=auth_header
        )

    # ==========================================
    # v1.5.9 Update: Session Budget Persistence Helpers
    # ==========================================
    def _estimate_usd_value(self, parsed: ParsedChallenge) -> float:
        """ParsedChallengeから決済のUSD換算見積額を算出するヘルパー"""
        usd_value = 0.0
        if parsed.asset == "USDC": usd_value = parsed.amount
        elif parsed.asset == "JPYC": usd_value = parsed.amount * 0.0067
        elif parsed.asset == "SATS": usd_value = parsed.amount * 0.00065
        return usd_value

    def _sum_budget_events(self, records: List[PaymentEvidenceRecord]) -> float:
        """過去のEvidenceから重複を除外して消費USDの合計を算出する"""
        total_usd = 0.0
        seen_receipts = set()
        for record in records:
            if record.session_spend_delta_usd is not None:
                # receipt_id が存在する場合は、二重計上を防ぐために重複チェック
                receipt_id = None
                if record.receipt_summary and isinstance(record.receipt_summary, dict):
                    receipt_id = record.receipt_summary.get("receipt_id")
                
                if receipt_id:
                    if receipt_id in seen_receipts:
                        continue
                    seen_receipts.add(receipt_id)
                
                total_usd += record.session_spend_delta_usd
        return total_usd

    def _restore_session_spend_from_evidence(self, context: ExecutionContext) -> None:
        """EvidenceRepositoryからセッション予算をワンショットで復元する"""
        if not self.policy or not self.evidence_repo or context.session_budget_restored:
            return
        
        try:
            if hasattr(self.evidence_repo, "import_session_evidence"):
                records = self.evidence_repo.import_session_evidence(context)
                # 🚨 修正: 履歴が空でも0.0で上書きし、セッションを切り替えた際のリークを防ぐ
                restored_usd = self._sum_budget_events(records) if records else 0.0
                self.policy._session_spent_usd = restored_usd
        except Exception:
            pass # 復元エラーで推論全体を止めないようサイレントフォールバック
        finally:
            context.session_budget_restored = True

    async def _restore_session_spend_from_evidence_async(self, context: ExecutionContext) -> None:
        """EvidenceRepositoryからセッション予算をワンショットで復元する(非同期)"""
        if not self.policy or not self.evidence_repo or context.session_budget_restored:
            return
        
        try:
            if hasattr(self.evidence_repo, "import_session_evidence_async"):
                records = await self.evidence_repo.import_session_evidence_async(context)
            elif hasattr(self.evidence_repo, "import_session_evidence"):
                records = self.evidence_repo.import_session_evidence(context)
            else:
                records = []
            
            # 🚨 修正: 履歴が空でも0.0で上書き
            restored_usd = self._sum_budget_events(records) if records else 0.0
            self.policy._session_spent_usd = restored_usd
        except Exception:
            pass
        finally:
            context.session_budget_restored = True

    # ------------------------------------------
    # Policy Enforcement (USD換算をヘルパーに集約)
    # ------------------------------------------
    def _enforce_policy(self, parsed: ParsedChallenge, target_url: str):
        """正規化されたChallengeに対してセキュリティポリシーを強制する"""
        if not self.policy:
            return

        domain = urlparse(target_url).netloc

        if self.policy.blocked_hosts and domain in self.policy.blocked_hosts:
            raise PaymentExecutionError(f"Policy Violation: Host '{domain}' is explicitly blocked.")
        if self.policy.allowed_hosts is not None and domain not in self.policy.allowed_hosts:
            raise PaymentExecutionError(f"Policy Violation: Host '{domain}' is not in allowed_hosts.")

        if parsed.scheme not in self.policy.allowed_schemes:
            raise PaymentExecutionError(f"Policy Violation: Scheme '{parsed.scheme}' is restricted.")
            
        if parsed.asset not in self.policy.allowed_assets:
            raise PaymentExecutionError(f"Policy Violation: Asset '{parsed.asset}' is restricted.")

        # 🚨 v1.5.9 Update: 換算ロジックの集約
        usd_value = self._estimate_usd_value(parsed)

        if usd_value > self.policy.max_spend_per_tx_usd:
            raise PaymentExecutionError(
                f"Policy Violation: Amount ({usd_value:.4f} USD) exceeds max_spend_per_tx_usd ({self.policy.max_spend_per_tx_usd})."
            )

        if self.policy._session_spent_usd + usd_value > self.policy.max_spend_per_session_usd:
            raise PaymentExecutionError(
                f"Policy Violation: Total session spend ({self.policy._session_spent_usd + usd_value:.4f} USD) "
                f"would exceed limit ({self.policy.max_spend_per_session_usd} USD)."
            )

    def _record_session_spend(self, parsed: ParsedChallenge, l402_report: Optional[Any] = None):
        """決済成功後にのみセッション予算を消費する (キャッシュ利用時はスキップ)"""
        if not self.policy:
            return
        if l402_report and not l402_report.payment_performed:
            return # L402sdk 等がキャッシュ済みトークンを使い、実決済を行わなかった場合は消費しない
        
        self.policy._session_spent_usd += self._estimate_usd_value(parsed)

    def _parse_legacy_header(self, header_val: str) -> ParsedChallenge:
        """旧カスタムヘッダー (x-402-payment-required) のパース処理"""
        params = {k.strip(): v.strip('"') for k, v in re.findall(r'(\w+)="?([^",]+)"?', header_val)}
        return ParsedChallenge(
            scheme=params.get("scheme", "unknown"),
            network=params.get("network", "unknown"),
            amount=float(params.get("amount", 0)),
            asset=params.get("asset", "USDC"),
            parameters=params,
            source=ChallengeSource.LEGACY_CUSTOM,
            raw_header=header_val
        )

    def execute_paid_action(self, *args, **kwargs) -> dict:
        """
        [Deprecated] 1.2.x互換シグネチャと1.3.x新シグネチャを両方サポートする互換ラッパー。
        """
        warnings.warn(
            "execute_paid_action() is deprecated. Use execute_request() or execute_detailed() instead.",
            DeprecationWarning,
            stacklevel=2
        )

        # 1.2.x 互換判定: execute_paid_action(endpoint_path, payload, headers=None)
        # 第一引数がパス(str)かつ、第二引数がペイロード(dict)の場合は旧形式とみなす
        if len(args) >= 2 and isinstance(args[0], str) and isinstance(args[1], dict):
            endpoint_path = args[0]
            payload = args[1]
            headers = args[2] if len(args) > 2 else kwargs.get("headers")
            return self.execute_request("POST", endpoint_path, payload, headers)

        # 1.3.x 新形式: execute_paid_action(method, endpoint_path, payload=None, headers=None)
        method = args[0] if len(args) > 0 else kwargs.get("method", "POST")
        endpoint_path = args[1] if len(args) > 1 else kwargs.get("endpoint_path")
        payload = args[2] if len(args) > 2 else kwargs.get("payload")
        headers = args[3] if len(args) > 3 else kwargs.get("headers")
        
        return self.execute_request(method, endpoint_path, payload, headers)

    def _process_payment(self, parsed: ParsedChallenge, headers: dict, payload: dict, method: str = "POST", url: str = "") -> tuple[str, str, Optional[Any]]:
        """実際の決済実行をカプセル化 (同期・非同期共通で利用)"""
        proof_ref = ""
        network_name = parsed.network or "UNKNOWN"
        l402_report = None

        # 1. EVM系 (x402, lnc-evm-*) の処理
        if parsed.scheme in [SchemeType.x402.value, SchemeType.lnc_evm_relay.value, SchemeType.lnc_evm_transfer.value]:
            if not self.evm_signer:
                raise PaymentExecutionError(f"{parsed.scheme} 決済には evm_signer が必要です。")
            
            # 宛先等の取得 (ParsedChallenge.parameters 経由)
            dest = parsed.parameters.get("destination") or parsed.parameters.get("payTo")
            if not dest:
                raise PaymentExecutionError("HATEOAS Error: Treasury address is missing.")

            chain_id_to_use = 137
            if parsed.parameters.get("chain_id"):
                chain_id_to_use = int(parsed.parameters.get("chain_id"))
            elif parsed.network.startswith("eip155:"):
                chain_id_to_use = int(parsed.network.split(":")[1])

            # 実際の執行
            if parsed.scheme == SchemeType.lnc_evm_transfer.value:
                proof_ref = self.evm_signer.execute_lnc_evm_transfer_settlement(
                    parsed.asset, parsed.amount, dest, chain_id_to_use, 
                    parsed.parameters.get("token_address"), self.evm_rpc_url
                )
            else:
                # 標準 x402 または lnc-evm-relay (ガスレス)
                if parsed.scheme == SchemeType.x402.value:
                    from .crypto.evm import sign_standard_x402_evm
                    proof_ref = sign_standard_x402_evm(self.private_key, parsed)
                else:
                    proof_ref = self.evm_signer.execute_lnc_evm_relay_settlement(
                        parsed.asset, parsed.amount, parsed.parameters.get("relayer_endpoint"), 
                        dest, chain_id_to_use, parsed.parameters.get("token_address")
                    )

            # 【★重要: Dual Stack リトライの構成】
            if parsed.scheme == SchemeType.x402.value:
                # ★ 新標準: Base64 JSON Payload の構築
                payment_payload = {
                    "proof": proof_ref,
                    "challenge": parsed.parameters.get("challenge", "")
                }
                headers["PAYMENT-SIGNATURE"] = _b64url_encode(payment_payload)
            
            # LN教互換用ボディ (全EVM系で付与)
            # 標準 x402 の場合はペイロード（ボディ）を汚染せず、レガシー拡張ルートのみ付与する
            if parsed.scheme != SchemeType.x402.value:
                payload["paymentAuth"] = {
                    "scheme": parsed.scheme, 
                    "proof": proof_ref, 
                    "chainId": str(chain_id_to_use),
                    "standard_x402": False
                }
            # 互換用 Authorization ヘッダー
            headers["Authorization"] = f"{parsed.scheme} {proof_ref}"

        # 2. Solana系の処理
        elif parsed.scheme == SchemeType.lnc_solana_transfer.value:
            if not self.solana_signer:
                raise PaymentExecutionError("solana_signer が必要です。")
            dest = parsed.parameters.get("payTo") or parsed.parameters.get("destination")
            proof_ref = self.solana_signer.execute_lnc_solana_transfer_settlement(
                parsed.asset, parsed.amount, dest, parsed.parameters.get("reference")
            )
            agent_id = getattr(self, "agent_id", "Anonymous")
            payload["paymentAuth"] = {"scheme": parsed.scheme, "proof": proof_ref, "agentId": agent_id}
            headers["Authorization"] = f"{parsed.scheme} {proof_ref}"

        # 3. Lightning系 (L402, MPP) の処理
        elif parsed.scheme in [SchemeType.l402.value, SchemeType.mpp.value, "Payment"]:
            
            # --- [L402 Delegate Seam] ---
            if parsed.scheme == SchemeType.l402.value:
                host = urlparse(url).netloc
                is_get = method.upper() == "GET"
                is_empty_payload = not bool(payload)
                
                # Mode Selection Policy
                use_delegate = (
                    self.prefer_lightninglabs_l402 and 
                    host in self.l402_delegate_allowed_hosts and 
                    is_get and 
                    is_empty_payload
                )

                if use_delegate and self.l402_executor:
                    l402_report = self.l402_executor.execute_l402(url, method, parsed, headers, payload)
                else:
                    from .adapters.l402_delegate import NativeL402Executor
                    if not self.ln_adapter:
                        raise PaymentExecutionError(f"L402決済には ln_adapter が必要です。")
                    native_exec = NativeL402Executor(self.ln_adapter)
                    l402_report = native_exec.execute_l402(url, method, parsed, headers, payload)

                headers["Authorization"] = l402_report.authorization_value
                proof_ref = l402_report.preimage or ""
                network_name = "Lightning"

            # --- [既存の MPP パス] ---
            else:
                if not self.ln_adapter:
                    raise PaymentExecutionError(f"{parsed.scheme} 決済には ln_adapter が必要です。")
                invoice = parsed.parameters.get("invoice")
                if not invoice:
                    raise InvoiceParseError("Challenge にインボイスが含まれていません。")

                proof_ref = self.ln_adapter.pay_invoice(invoice)
                
                charge_id = parsed.parameters.get("charge")
                if charge_id:
                    headers["Authorization"] = f"{parsed.scheme} {charge_id}:{proof_ref}"
                else:
                    headers["Authorization"] = f"{parsed.scheme} {proof_ref}"

        return proof_ref, network_name, l402_report

    def execute_request(self, method: str, endpoint_path: str, payload: Optional[dict] = None, headers: Optional[dict] = None) -> dict:
        """[後方互換性維持] 内部で execute_detailed を呼び出し、レスポンスの辞書のみを返却する。"""
        result = self.execute_detailed(method, endpoint_path, payload, headers)
        return result.response

    # ==========================================
    # v1.5.8: Navigation Hint Normalization
    # ==========================================
    def _resolve_next_action(self, error_data: dict, headers: dict) -> tuple[Optional[NextAction], str]:
        """Normalize various HATEOAS hints from JSON or Headers into a canonical NextAction model."""
        # 1. Canonical Body (Highest Priority)
        if "next_action" in error_data and isinstance(error_data["next_action"], dict):
            try:
                return NextAction(**error_data["next_action"]), "canonical_body"
            except Exception:
                pass

        # 2. Body Aliases (next, action, retry_action)
        for alias_key in ["next", "action", "retry_action"]:
            if alias_key in error_data and isinstance(error_data[alias_key], dict):
                raw = error_data[alias_key]
                try:
                    return NextAction(
                        instruction_for_agent=raw.get("instruction_for_agent") or raw.get("instruction") or raw.get("message_for_agent") or "Resolved from alias",
                        method=raw.get("method", "GET"),
                        url=raw.get("url"),
                        suggested_payload=raw.get("suggested_payload") or raw.get("payload") or raw.get("body"),
                        suggested_headers=raw.get("suggested_headers") or raw.get("headers")
                    ), "alias_body"
                except Exception:
                    pass

        # 3. Header Hints (Location / Link, forced to GET)
        location = headers.get("Location") or headers.get("location")
        if location and isinstance(location, str):
            return NextAction(instruction_for_agent="Follow Location header", method="GET", url=location), "location_header"
            
        link_header = headers.get("Link") or headers.get("link")
        if link_header and isinstance(link_header, str):
            match = re.search(r'<([^>]+)>;\s*rel="?(next|payment)"?', link_header)
            if match:
                return NextAction(instruction_for_agent=f"Follow Link rel={match.group(2)}", method="GET", url=match.group(1)), "link_header"

        return None, "none"

    # ==========================================
    # 同期 (Sync) Runtime Layer
    # ==========================================
    def execute_detailed(
        self, method: str, endpoint_path: str, payload: Optional[dict] = None, headers: Optional[dict] = None, 
        _current_hop: int = 0, _payment_retry_count: int = 0,
        context: Optional[ExecutionContext] = None,
        outcome_matcher: Optional[Callable] = None,
        _current_receipt: Optional[SettlementReceipt] = None
    ) -> ExecutionResult:
        
        context = context or ExecutionContext()
        # 🚨 v1.5.9 Update: HATEOAS実行前にワンショットで予算を復元
        self._restore_session_spend_from_evidence(context)
        
        url = endpoint_path if endpoint_path.startswith("http") else f"{self.base_url}{endpoint_path}"
        headers = dict(headers or {}) 
        if not any(k.lower() == "user-agent" for k in headers.keys()):
            headers["User-Agent"] = CUSTOM_USER_AGENT
        
        payload = payload or {}
        method_upper = method.upper()

        req_kwargs = {
            "json": None if method_upper == "GET" else payload,
            "params": payload if method_upper == "GET" else None,
            "headers": headers
        }

        res = requests.request(method_upper, url, **req_kwargs)

        if 200 <= res.status_code < 300:
            # v1.5.8 Hardening: Satisfy Pydantic without polluting business data
            try:
                raw_json = res.json() if res.content else {"status": "success"}
                # If it's already a dict, use as-is. If not (like MagicMock), wrap it safely.
                resp_data = raw_json if isinstance(raw_json, dict) else {"status": "success", "data": raw_json}
            except Exception:
                resp_data = {"status": "success", "message": "unparseable"}

            result = ExecutionResult(response=resp_data, final_url=url, retry_count=_payment_retry_count)
            
            raw_response = res.headers.get("PAYMENT-RESPONSE")
            token = None
            # Strict type check to avoid TypeError with MagicMock headers
            if raw_response and isinstance(raw_response, str):
                if not raw_response.startswith('status='):
                    payload_b64 = _b64url_decode(raw_response)
                    token = payload_b64.get("receipt") if payload_b64 else raw_response
                else:
                    match = re.search(r'receipt="?([^",]+)"?', raw_response)
                    token = match.group(1) if match else raw_response
            else:
                # Handle fallback headers safely
                candidate = res.headers.get("Payment-Receipt")
                token = candidate if isinstance(candidate, str) else None

            if token and _current_receipt:
                _current_receipt.receipt_token = str(token)
                _current_receipt.source = AttestationSource.SERVER_JWS
                _current_receipt.verification_status = "verified"
            
            if outcome_matcher:
                # 🎯 修正: 開発者が入れ忘れても大丈夫なように、SDK側でURLとMethodを自動補完
                context.hints["target_url"] = url
                context.hints["http_method"] = method

                sig = inspect.signature(outcome_matcher)
                if len(sig.parameters) == 3:
                    result.outcome = outcome_matcher(resp_data, _current_receipt, context)
                else:
                    result.outcome = outcome_matcher(resp_data, context)
            return result

        if res.status_code == 402:
            if _payment_retry_count >= self.max_payment_retries:
                raise PaymentExecutionError("Max 402 retries exceeded")
            
            parsed = self._parse_challenge(res, payload.get("asset", "SATS"))
            self._enforce_policy(parsed, url)

            if self.evidence_repo:
                past_records = self.evidence_repo.import_evidence(url, context)
                if past_records:
                    context.past_evidence = past_records

            evidence = TrustEvidence(
                url=url,
                challenge=parsed,
                host_metadata={},
                agent_hints=context.hints
            )

            decision = None
            payment_completed = False
            delta_usd = None
            receipt = None
            
            try:
                for evaluator in self.trust_evaluators:
                    sig = inspect.signature(evaluator)
                    if len(sig.parameters) == 2:
                        decision = evaluator(evidence, context)
                    else:
                        decision = evaluator(url, parsed, context)
                    
                    if not decision.is_trusted:
                        raise CounterpartyTrustError(f"Trust Evaluation Blocked Payment: {decision.reason}")

                # 💡 修正: 3つの戻り値を受け取り、urlとmethodを渡す
                proof_ref, network_name, l402_report = self._process_payment(parsed, headers, payload, method=method, url=url)
                self._record_session_spend(parsed, l402_report)
                
                payment_completed = True
                delta_usd = self._estimate_usd_value(parsed)

                receipt = SettlementReceipt(
                    receipt_id=str(uuid.uuid4()),
                    scheme=parsed.scheme, network=network_name, asset=parsed.asset,
                    settled_amount=parsed.amount, proof_reference=proof_ref,
                    verification_status="verified" if network_name == "Lightning" else "self_reported",
                    delegate_source=l402_report.delegate_source if l402_report else "native",
                    payment_hash=l402_report.payment_hash if l402_report else None,
                    fee_sats=l402_report.fee_sats if l402_report else None,
                    cached_token_used=l402_report.cached_token_used if l402_report else False,
                    payment_performed=l402_report.payment_performed if l402_report else True,
                    endpoint=url
                )
                self.last_receipt = receipt

                next_result = self.execute_detailed(
                    method, url, payload, headers, _current_hop, _payment_retry_count + 1,
                    context=context, outcome_matcher=outcome_matcher,
                    _current_receipt=receipt
                )
                
                next_result.settlement_receipt = receipt
                next_result.used_scheme = parsed.scheme
                next_result.used_asset = parsed.asset
                next_result.verification_status = receipt.verification_status
                
                if self.evidence_repo:
                    record = PaymentEvidenceRecord(
                        session_id=context.session_id, correlation_id=context.correlation_id,
                        target_url=url, method=method, scheme=parsed.scheme, asset=parsed.asset, amount=parsed.amount,
                        trust_decision=decision,
                        receipt_summary={"receipt_id": receipt.receipt_id, "verification_status": receipt.verification_status},
                        outcome=next_result.outcome,
                        session_spend_delta_usd=delta_usd, 
                        delegate_source=l402_report.delegate_source if l402_report else "native",
                        payment_hash=l402_report.payment_hash if l402_report else None,
                        fee_sats=l402_report.fee_sats if l402_report else None,
                        cached_token_used=l402_report.cached_token_used if l402_report else False,
                        payment_performed=l402_report.payment_performed if l402_report else True
                    )

                    self.evidence_repo.export_evidence(record, context)

                return next_result

            except Exception as e:
                if self.evidence_repo:
                    record_kwargs = {
                        "session_id": context.session_id, "correlation_id": context.correlation_id,
                        "target_url": url, "method": method, "scheme": parsed.scheme, "asset": parsed.asset, "amount": parsed.amount,
                        "trust_decision": decision, "error_message": str(e)
                    }
                    # 🚨 修正: 決済成立後にダウンストリームで失敗した場合、証跡と消費USDを残す
                    if payment_completed:
                        record_kwargs["session_spend_delta_usd"] = delta_usd
                        record_kwargs["receipt_summary"] = {"receipt_id": receipt.receipt_id, "verification_status": receipt.verification_status}
                        
                    record = PaymentEvidenceRecord(**record_kwargs)
                    self.evidence_repo.export_evidence(record, context)
                raise

        try:
            error_data = res.json()
        except Exception:
            error_data = {}

        next_action, source = self._resolve_next_action(error_data, res.headers)

        if self.auto_navigate and next_action and _current_hop < self.max_hops:
            next_url = next_action.url
            next_method = (next_action.method or "GET").upper()
            
            # --- Guardrail: Method & Cross-Origin Netloc Check ---
            is_unsafe = next_method not in ["GET", "HEAD"]
            if next_url:
                current_netloc = urlparse(url).netloc
                next_netloc = urlparse(next_url).netloc if next_url.startswith("http") else current_netloc
                if next_netloc and current_netloc != next_netloc:
                    allowed_hosts = context.hints.get("allowed_hosts", [])
                    if next_netloc not in allowed_hosts:
                        is_unsafe = True

            if is_unsafe and not self.allow_unsafe_navigate:
                # Matches exact test regex requirement
                raise NavigationGuardrailError(f"[Guardrail] Stopped unsafe automatic navigation to {next_method} {next_url}")

            if next_url and next_method != "NONE":
                # --- Guardrail: Header Hardening ---
                forbidden_headers = {"authorization", "cookie", "proxy-authorization", "host", "content-length"}
                safe_suggested = {k: v for k, v in (next_action.suggested_headers or {}).items() if k.lower() not in forbidden_headers}

                merged_headers = {**headers, **safe_suggested}
                
                # Fix NameError
                merged_payload = {**payload, **(next_action.suggested_payload or {})}
                if "scheme" in merged_payload:
                    merged_payload["scheme"] = _normalize_scheme(merged_payload["scheme"])

                # Recursive SYNC call (No await)
                next_result = self.execute_detailed(
                    next_method, next_url, merged_payload, merged_headers, _current_hop + 1, _payment_retry_count,
                    context=context, outcome_matcher=outcome_matcher,
                    _current_receipt=_current_receipt
                )
                
                if self.evidence_repo:
                    record = PaymentEvidenceRecord(
                        session_id=context.session_id, correlation_id=context.correlation_id,
                        target_url=url, method=method, navigation_source=source,
                        outcome=next_result.outcome
                    )
                    self.evidence_repo.export_evidence(record, context)
                return next_result

        error_msg = error_data.get('message', res.text)
        raise PaymentExecutionError(f"API Error {res.status_code}: {error_msg}")

    # ==========================================
    # ⚡ 非同期 (Async) Runtime Layer
    # ==========================================
    async def execute_request_async(self, method: str, endpoint_path: str, payload: Optional[dict] = None, headers: Optional[dict] = None) -> dict:
        """[後方互換性維持] 内部で execute_detailed_async を呼び出し、レスポンスの辞書のみを返却する。"""
        result = await self.execute_detailed_async(method, endpoint_path, payload, headers)
        return result.response

    async def execute_detailed_async(
        self, method: str, endpoint_path: str, payload: Optional[dict] = None, headers: Optional[dict] = None, 
        _current_hop: int = 0, _payment_retry_count: int = 0,
        context: Optional[ExecutionContext] = None,
        outcome_matcher: Optional[Callable] = None,
        _current_receipt: Optional[SettlementReceipt] = None 
    ) -> ExecutionResult:
        
        context = context or ExecutionContext()
        # 🚨 v1.5.9 Update: 非同期でのワンショット予算復元
        await self._restore_session_spend_from_evidence_async(context)
        
        url = endpoint_path if endpoint_path.startswith("http") else f"{self.base_url}{endpoint_path}"
        headers = dict(headers or {}) 
        if not any(k.lower() == "user-agent" for k in headers.keys()):
            headers["User-Agent"] = CUSTOM_USER_AGENT

        payload = payload or {}
        method_upper = method.upper()
        req_kwargs = {
            "json": None if method_upper == "GET" else payload,
            "params": payload if method_upper == "GET" else None,
            "headers": headers
        }

        if self._async_client is None:
            self._async_client = httpx.AsyncClient(follow_redirects=True)

        res = await self._async_client.request(method_upper, url, **req_kwargs)

        if 200 <= res.status_code < 300:
            try:
                raw_json = res.json() if res.content else {"status": "success"}
                resp_data = raw_json if isinstance(raw_json, dict) else {"status": "success", "data": raw_json}
            except Exception:
                resp_data = {"status": "success", "message": "unparseable"}

            result = ExecutionResult(response=resp_data, final_url=url, retry_count=_payment_retry_count)
            
            raw_response = res.headers.get("PAYMENT-RESPONSE")
            token = None
            if raw_response and isinstance(raw_response, str):
                if not raw_response.startswith('status='):
                    payload_b64 = _b64url_decode(raw_response)
                    token = payload_b64.get("receipt") if payload_b64 else raw_response
                else:
                    match = re.search(r'receipt="?([^",]+)"?', raw_response)
                    token = match.group(1) if match else raw_response
            else:
                candidate = res.headers.get("Payment-Receipt")
                token = candidate if isinstance(candidate, str) else None

            if token and _current_receipt:
                _current_receipt.receipt_token = str(token)
                _current_receipt.source = AttestationSource.SERVER_JWS
                _current_receipt.verification_status = "verified"
            
            if outcome_matcher:
                # 🎯 修正: 開発者が入れ忘れても大丈夫なように、SDK側でURLとMethodを自動補完
                context.hints["target_url"] = url
                context.hints["http_method"] = method

                # ⚡ 修正: 非同期ループをブロックしないように別スレッド(executor)で実行
                loop = asyncio.get_running_loop()
                sig = inspect.signature(outcome_matcher)
                if len(sig.parameters) == 3:
                    result.outcome = outcome_matcher(resp_data, _current_receipt, context)
                else:
                    result.outcome = outcome_matcher(resp_data, context)
            return result

        if res.status_code == 402:
            if _payment_retry_count >= self.max_payment_retries: 
                raise PaymentExecutionError("Max 402 retries exceeded")
            
            parsed = self._parse_challenge(res, payload.get("asset", "SATS"))
            self._enforce_policy(parsed, url)

            if getattr(self, "evidence_repo", None):
                if hasattr(self.evidence_repo, "import_evidence_async"):
                    past_records = await self.evidence_repo.import_evidence_async(url, context)
                else:
                    past_records = self.evidence_repo.import_evidence(url, context)
                
                if past_records:
                    context.past_evidence = past_records

            evidence = TrustEvidence(
                url=url,
                challenge=parsed,
                host_metadata={},
                agent_hints=context.hints
            )

            decision = None
            payment_completed = False
            delta_usd = None
            receipt = None
            
            try:
                loop = asyncio.get_running_loop()
                for evaluator in self.trust_evaluators:
                    sig = inspect.signature(evaluator)
                    if len(sig.parameters) == 2:
                        decision = await loop.run_in_executor(None, evaluator, evidence, context)
                    else:
                        decision = await loop.run_in_executor(None, evaluator, url, parsed, context)
                    
                    if not decision.is_trusted:
                        raise CounterpartyTrustError(f"Trust Evaluation Blocked Payment: {decision.reason}")

                # 💡 修正: 3つの戻り値を受け取る。methodとurlもkwargsで渡す
                def _process_wrapper():
                    return self._process_payment(parsed, headers, payload, method=method, url=url)
                
                proof_ref, network_name, l402_report = await loop.run_in_executor(None, _process_wrapper)
                self._record_session_spend(parsed, l402_report)
                
                payment_completed = True
                delta_usd = self._estimate_usd_value(parsed)

                receipt = SettlementReceipt(
                    receipt_id=str(uuid.uuid4()),
                    scheme=parsed.scheme, network=network_name, asset=parsed.asset,
                    settled_amount=parsed.amount, proof_reference=proof_ref,
                    verification_status="verified" if network_name == "Lightning" else "self_reported",
                    delegate_source=l402_report.delegate_source if l402_report else "native",
                    payment_hash=l402_report.payment_hash if l402_report else None,
                    fee_sats=l402_report.fee_sats if l402_report else None,
                    cached_token_used=l402_report.cached_token_used if l402_report else False,
                    payment_performed=l402_report.payment_performed if l402_report else True,
                    endpoint=url
                )
                self.last_receipt = receipt

                next_result = await self.execute_detailed_async(
                    method, url, payload, headers, _current_hop, _payment_retry_count + 1,
                    context=context, outcome_matcher=outcome_matcher,
                    _current_receipt=receipt
                )
                
                next_result.settlement_receipt = receipt
                next_result.used_scheme = parsed.scheme
                next_result.used_asset = parsed.asset
                next_result.verification_status = receipt.verification_status

                if getattr(self, "evidence_repo", None):
                    record = PaymentEvidenceRecord(
                        session_id=context.session_id, correlation_id=context.correlation_id,
                        target_url=url, method=method, scheme=parsed.scheme, asset=parsed.asset, amount=parsed.amount,
                        trust_decision=decision,
                        receipt_summary={"receipt_id": receipt.receipt_id, "verification_status": receipt.verification_status},
                        outcome=next_result.outcome,
                        session_spend_delta_usd=delta_usd,
                        delegate_source=l402_report.delegate_source if l402_report else "native",
                        payment_hash=l402_report.payment_hash if l402_report else None,
                        fee_sats=l402_report.fee_sats if l402_report else None,
                        cached_token_used=l402_report.cached_token_used if l402_report else False,
                        payment_performed=l402_report.payment_performed if l402_report else True
                    )
                    if hasattr(self.evidence_repo, "export_evidence_async"):
                        await self.evidence_repo.export_evidence_async(record, context)
                    else:
                        self.evidence_repo.export_evidence(record, context)

                return next_result

            except Exception as e:
                if getattr(self, "evidence_repo", None):
                    record_kwargs = {
                        "session_id": context.session_id, "correlation_id": context.correlation_id,
                        "target_url": url, "method": method, "scheme": parsed.scheme, "asset": parsed.asset, "amount": parsed.amount,
                        "trust_decision": decision, "error_message": str(e)
                    }
                    # 🚨 修正: 決済成立後にダウンストリームで失敗した場合、証跡と消費USDを残す
                    if payment_completed:
                        record_kwargs["session_spend_delta_usd"] = delta_usd
                        record_kwargs["receipt_summary"] = {"receipt_id": receipt.receipt_id, "verification_status": receipt.verification_status}
                        
                    record = PaymentEvidenceRecord(**record_kwargs)
                    
                    if hasattr(self.evidence_repo, "export_evidence_async"):
                        await self.evidence_repo.export_evidence_async(record, context)
                    else:
                        self.evidence_repo.export_evidence(record, context)
                raise
        
        try:
            error_data = res.json()
        except Exception:
            error_data = {}

        next_action, source = self._resolve_next_action(error_data, res.headers)

        if self.auto_navigate and next_action and _current_hop < self.max_hops:
            next_url = next_action.url
            next_method = (next_action.method or "GET").upper()
            
            # --- Guardrail: Method & Cross-Origin Netloc Check ---
            is_unsafe = next_method not in ["GET", "HEAD"]
            if next_url:
                current_netloc = urlparse(url).netloc
                next_netloc = urlparse(next_url).netloc if next_url.startswith("http") else current_netloc
                if next_netloc and current_netloc != next_netloc:
                    allowed_hosts = context.hints.get("allowed_hosts", [])
                    if next_netloc not in allowed_hosts:
                        is_unsafe = True

            if is_unsafe and not self.allow_unsafe_navigate:
                raise NavigationGuardrailError(f"[Guardrail] Stopped unsafe automatic navigation to {next_method} {next_url}")

            if next_url and next_method != "NONE":
                # --- Guardrail: Header Hardening ---
                forbidden_headers = {"authorization", "cookie", "proxy-authorization", "host", "content-length"}
                safe_suggested = {k: v for k, v in (next_action.suggested_headers or {}).items() if k.lower() not in forbidden_headers}

                merged_headers = {**headers, **safe_suggested}
                
                merged_payload = {**payload, **(next_action.suggested_payload or {})} 
                if "scheme" in merged_payload:
                    merged_payload["scheme"] = _normalize_scheme(merged_payload["scheme"])

                # Recursive ASYNC call (Proper await, no sleep)
                next_result = await self.execute_detailed_async(
                    next_method, next_url, merged_payload, merged_headers, _current_hop + 1, _payment_retry_count,
                    context=context, outcome_matcher=outcome_matcher,
                    _current_receipt=_current_receipt
                )
                
                if getattr(self, "evidence_repo", None):
                    record = PaymentEvidenceRecord(
                        session_id=context.session_id, correlation_id=context.correlation_id,
                        target_url=url, method=method, navigation_source=source,
                        outcome=next_result.outcome
                    )
                    if hasattr(self.evidence_repo, "export_evidence_async"):
                        await self.evidence_repo.export_evidence_async(record, context)
                    else:
                        self.evidence_repo.export_evidence(record, context)
                return next_result

        error_msg = error_data.get('message', res.text)
        raise PaymentExecutionError(f"API Error {res.status_code}: {error_msg}")

    async def aclose(self):
        """v1.3.1: 非同期セッションを明示的に閉じるためのメソッド"""
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    async def __aenter__(self):
        """v1.3.1: async with ブロックに入った時の処理"""
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(follow_redirects=True)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """v1.3.1: async with ブロックを抜けた時に自動でセッションを閉じる"""
        await self.aclose()

# ==========================================
# ⛩️ ADAPTER: LN Church 専用拡張クラス
# ==========================================
class LnChurchClient(Payment402Client):
    def __init__(
        self, 
        agent_id: Optional[str] = None, 
        private_key: Optional[str] = None, 
        ln_api_url: Optional[str] = None,
        ln_api_key: Optional[str] = None,
        ln_provider: str = "lnbits",
        base_url: str = "https://kari.mayim-mayim.com",
        evm_rpc_url: Optional[str] = None,
        auto_navigate: bool = True, 
        max_hops: int = 3,
        allow_unsafe_navigate: bool = False,
        evm_signer: Optional[EVMSigner] = None,
        ln_adapter: Optional[LightningProvider] = None,
        solana_signer: Optional[SolanaSigner] = None,
        policy: Optional[PaymentPolicy] = None,
        *args,
        **kwargs
    ):
        derived_agent_id = agent_id
        if private_key and not agent_id:
            try:
                from eth_account import Account
                derived_agent_id = Account.from_key(private_key).address
            except Exception:
                try:
                    from solders.keypair import Keypair
                    derived_agent_id = str(Keypair.from_base58_string(private_key).pubkey())
                except Exception as e:
                    raise ValueError(
                        "Invalid private_key format. Could not parse as EVM hex or Solana Base58. "
                        f"Detailed error: {e}"
                    )
        else:
            derived_agent_id = agent_id or "Anonymous_Agent"

        try:
            super().__init__(
                private_key=private_key, 
                ln_api_url=ln_api_url, 
                ln_api_key=ln_api_key, 
                ln_provider=ln_provider, 
                base_url=base_url, 
                evm_rpc_url=evm_rpc_url, 
                auto_navigate=auto_navigate, 
                max_hops=max_hops, 
                allow_unsafe_navigate=allow_unsafe_navigate,
                evm_signer=evm_signer,
                ln_adapter=ln_adapter,
                solana_signer=solana_signer,
                policy=policy,
                *args,
                **kwargs
            )
        except ValueError as e:
            raise ValueError(f"Invalid private_key format. Details: {str(e)}") from e

        self.agent_id = derived_agent_id
        self.probe_token = None
        self.faucet_token = None
        self.grant_token = None

    def set_grant_token(self, token: str):
        """Stores a grant token to be used as a payment override."""
        self.grant_token = token

    def has_valid_scoped_grant(self, target_path: str, method: str) -> bool:
        """
        Locally evaluates if the grant token is valid and scoped for the intended request.
        This serves as the fallback decision gateway.
        """
        if not self.grant_token: return False
        
        claims = _decode_jwt_payload(self.grant_token)
        if not claims: return False

        import time
        # 1. Check Expiration
        if claims.get("exp", 0) < time.time(): return False
        
        # 2. Check Agent Identity Binding
        if claims.get("sub") != self.agent_id: return False

        # 3. Check Audience (Matches Base URL)
        aud = claims.get("aud", "")
        if aud.rstrip("/") != self.base_url.rstrip("/"): return False

        # 4. Check Routes & Methods Scopes
        scope = claims.get("scope", {})
        routes = scope.get("routes", [])
        methods = scope.get("methods", [])

        if target_path not in routes: return False
        if method.upper() not in [m.upper() for m in methods]: return False

        return True

    def _inject_telemetry(self, headers: Optional[dict]) -> dict:
        headers = dict(headers or {})
        headers["X-LN-Church-Agent-Version"] = SDK_VERSION
        if not any(k.lower() == "x-ln-church-request-id" for k in headers.keys()):
            headers["X-LN-Church-Request-Id"] = str(uuid.uuid4())
        return headers

    def execute_request(self, method: str, endpoint_path: str, payload: Optional[dict] = None, headers: Optional[dict] = None) -> dict:
        telemetry_headers = self._inject_telemetry(headers)
        return super().execute_request(method, endpoint_path, payload, telemetry_headers)

    async def execute_request_async(self, method: str, endpoint_path: str, payload: Optional[dict] = None, headers: Optional[dict] = None) -> dict:
        telemetry_headers = self._inject_telemetry(headers)
        return await super().execute_request_async(method, endpoint_path, payload, telemetry_headers)

    # ==========================================
    # 🔒 Internal Access Selection (v1.6+)
    # ==========================================
    def _collect_execution_access_candidates(self, target_path: str, method: str, asset: str, scheme: str) -> List[_ExecutionAccessPlan]:
        candidates = []
        
        # 1. Grant candidate
        if self.has_valid_scoped_grant(target_path, method):
            candidates.append(_ExecutionAccessPlan(
                unlock=_ExecutionUnlock.ENTITLEMENT_PROOF,
                funding_policy=_FundingPolicy.FULLY_SPONSORED,
                entitlement_kind=_EntitlementKind.GRANT,
                settlement_scheme=scheme, # Fallback base requirements
                settlement_asset=asset,
                selected_reason="Valid scoped grant token available."
            ))
            
        # 2. Faucet candidate (Legacy Omikuji fallback)
        if self.faucet_token and target_path == "/api/agent/omikuji":
            candidates.append(_ExecutionAccessPlan(
                unlock=_ExecutionUnlock.ENTITLEMENT_PROOF,
                funding_policy=_FundingPolicy.FULLY_SPONSORED,
                entitlement_kind=_EntitlementKind.FAUCET,
                settlement_scheme=scheme,
                settlement_asset=asset,
                selected_reason="Legacy faucet token available for Omikuji."
            ))
            
        # 3. Direct settlement candidate
        candidates.append(_ExecutionAccessPlan(
            unlock=_ExecutionUnlock.SETTLEMENT_PROOF,
            funding_policy=_FundingPolicy.SELF_FUNDED,
            entitlement_kind=None,
            settlement_scheme=scheme,
            settlement_asset=asset,
            selected_reason="Direct 402 settlement."
        ))
        
        return candidates

    def _select_execution_access_plan(self, candidates: List[_ExecutionAccessPlan]) -> _ExecutionAccessPlan:
        # Priority: 1. GRANT, 2. FAUCET, 3. Direct Settlement
        for kind in [_EntitlementKind.GRANT, _EntitlementKind.FAUCET]:
            for c in candidates:
                if c.entitlement_kind == kind:
                    return c
                    
        # Fallback to direct settlement
        for c in candidates:
            if c.unlock == _ExecutionUnlock.SETTLEMENT_PROOF:
                return c
                
        return candidates[-1]

    def _build_payment_override_from_plan(self, plan: _ExecutionAccessPlan) -> Optional[dict]:
        if plan.entitlement_kind == _EntitlementKind.GRANT:
            return {
                "type": "grant",
                "proof": self.grant_token,
                "asset": AssetType.GRANT_CREDIT.value
            }
        elif plan.entitlement_kind == _EntitlementKind.FAUCET:
            return {
                "type": "faucet",
                "proof": self.faucet_token,
                "asset": AssetType.FAUCET_CREDIT.value
            }
        return None

    # ------------------------------------------
    # 同期 (Sync) メソッド群: Convenience Defaults 修正
    # ------------------------------------------
    def init_probe(self):
        res = self.execute_request("GET", f"/api/agent/probe?agentId={self.agent_id}&src=sdk")
        self.probe_token = res.get("capability_receipt", {}).get("token") or res.get("probe_token")
        print("[System] Probe Completed.")

    def claim_faucet_if_empty(self):
        try:
            res = self.execute_request("POST", "/api/agent/faucet", {"agentId": self.agent_id})
            self.faucet_token = res.get("grant_token")
            print("[System] Faucet Claimed.")
        except Exception as e:
            print(f"[System] Faucet skipped or failed: {str(e)}")

    def draw_omikuji(self, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> OmikujiResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        target_path = "/api/agent/omikuji"
        
        # 内部セレクタによる計画決定
        candidates = self._collect_execution_access_candidates(target_path, "POST", asset.value, target_scheme)
        plan = self._select_execution_access_plan(candidates)
        
        payload = {
            "agentId": self.agent_id, 
            "clientType": "AI", 
            "scheme": plan.settlement_scheme, 
            "asset": plan.settlement_asset
        }

        # ビルダーから Override の注入
        override = self._build_payment_override_from_plan(plan)
        if override:
            payload["paymentOverride"] = override

        headers = {"x-probe-token": self.probe_token} if self.probe_token else {}
        return OmikujiResponse(**self.execute_request("POST", target_path, payload, headers))

    def submit_confession(self, raw_message: str, asset: AssetType = AssetType.SATS, context: dict = None, scheme: Optional[str] = None) -> ConfessionResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"agentId": self.agent_id, "raw_message": raw_message, "context": context or {}, "scheme": target_scheme, "asset": asset.value}
        return ConfessionResponse(**self.execute_request("POST", "/api/agent/confession", payload))

    def offer_hono(self, amount: float, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> HonoResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"agentId": self.agent_id, "clientType": "AI", "scheme": target_scheme, "asset": asset.value, "amount": amount}
        return HonoResponse(**self.execute_request("POST", "/api/agent/hono", payload))

    def issue_identity(self) -> AgentIdentity:
        res = self.execute_request("POST", "/api/agent/identity/issue", {"agentId": self.agent_id})
        return AgentIdentity(status=res["status"], public_profile_url=res["public_profile_url"], agent_id=self.agent_id)

    def resolve_identity(self, target_agent_id: str = None) -> AgentIdentity:
        target_id = target_agent_id or self.agent_id
        res = self.execute_request("GET", f"/api/agent/identity/{target_id}")
        return AgentIdentity(**res)

    def get_benchmark_overview(self) -> BenchmarkOverviewResponse:
        return BenchmarkOverviewResponse(**self.execute_request("GET", f"/api/agent/benchmark/{self.agent_id}"))

    def compare_trial_performance(self, trial_id: str, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> CompareResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"scheme": target_scheme, "asset": asset.value}
        return CompareResponse(**self.execute_request("POST", f"/api/agent/benchmark/trials/{trial_id}/agent/{self.agent_id}/compare", payload))

    def request_fast_pass_aggregate(self, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> AggregateResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"scheme": target_scheme, "asset": asset.value}
        return AggregateResponse(**self.execute_request("POST", f"/api/agent/benchmark/trials/{self.agent_id}/aggregate", payload))

    def submit_monzen_trace(self, target_url: str, invoice: str, preimage: Optional[str] = None, method: str = "POST", scheme: Optional[str] = None) -> MonzenTraceResponse: 
        payload = {"agentId": self.agent_id, "targetUrl": target_url, "invoice": invoice, "method": method}
        if preimage: payload["preimage"] = preimage
        if scheme: payload["scheme"] = scheme
        res_dict = self.execute_request("POST", "/api/agent/monzen/trace", payload)
        return MonzenTraceResponse(**res_dict)

    def get_site_metrics(self, limit: int = 10, target_agent_id: Optional[str] = None, scheme: Optional[str] = None) -> MonzenMetricsResponse:
        params = {"limit": limit}
        if target_agent_id: params["agentId"] = target_agent_id
        if scheme: params["scheme"] = scheme
        return MonzenMetricsResponse(**self.execute_request("GET", "/api/agent/monzen/metrics", payload=params))

    def download_monzen_graph(self, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> MonzenGraphResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"scheme": target_scheme, "asset": asset.value, "agentId": self.agent_id}
        res = self.execute_request("GET", f"/api/agent/monzen/graph", payload=payload)
        return MonzenGraphResponse(**res)

    # ------------------------------------------
    # ⚡ 非同期 (Async) メソッド群: Convenience Defaults 修正
    # ------------------------------------------
    async def init_probe_async(self):
        res = await self.execute_request_async("GET", f"/api/agent/probe?agentId={self.agent_id}&src=sdk_async")
        self.probe_token = res.get("capability_receipt", {}).get("token") or res.get("probe_token")
        print("[System ASYNC] Probe Completed.")

    async def claim_faucet_if_empty_async(self):
        try:
            res = await self.execute_request_async("POST", "/api/agent/faucet", {"agentId": self.agent_id})
            self.faucet_token = res.get("grant_token")
            print("[System ASYNC] Faucet Claimed.")
        except Exception as e:
            print(f"[System ASYNC] Faucet skipped or failed: {str(e)}")

    async def draw_omikuji_async(self, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> OmikujiResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        target_path = "/api/agent/omikuji"

        # 内部セレクタによる計画決定
        candidates = self._collect_execution_access_candidates(target_path, "POST", asset.value, target_scheme)
        plan = self._select_execution_access_plan(candidates)
        
        payload = {
            "agentId": self.agent_id, 
            "clientType": "AI", 
            "scheme": plan.settlement_scheme, 
            "asset": plan.settlement_asset
        }

        # ビルダーから Override の注入
        override = self._build_payment_override_from_plan(plan)
        if override:
            payload["paymentOverride"] = override

        headers = {"x-probe-token": self.probe_token} if self.probe_token else {}
        res = await self.execute_request_async("POST", target_path, payload, headers)
        return OmikujiResponse(**res)

    async def submit_confession_async(self, raw_message: str, asset: AssetType = AssetType.SATS, context: dict = None, scheme: Optional[str] = None) -> ConfessionResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"agentId": self.agent_id, "raw_message": raw_message, "context": context or {}, "scheme": target_scheme, "asset": asset.value}
        res = await self.execute_request_async("POST", "/api/agent/confession", payload)
        return ConfessionResponse(**res)

    async def offer_hono_async(self, amount: float, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> HonoResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"agentId": self.agent_id, "clientType": "AI", "scheme": target_scheme, "asset": asset.value, "amount": amount}
        res = await self.execute_request_async("POST", "/api/agent/hono", payload)
        return HonoResponse(**res)

    async def issue_identity_async(self) -> AgentIdentity:
        res = await self.execute_request_async("POST", "/api/agent/identity/issue", {"agentId": self.agent_id})
        return AgentIdentity(status=res["status"], public_profile_url=res["public_profile_url"], agent_id=self.agent_id)

    async def resolve_identity_async(self, target_agent_id: str = None) -> AgentIdentity:
        target_id = target_agent_id or self.agent_id
        res = await self.execute_request_async("GET", f"/api/agent/identity/{target_id}")
        return AgentIdentity(**res)

    async def get_benchmark_overview_async(self) -> BenchmarkOverviewResponse:
        res = await self.execute_request_async("GET", f"/api/agent/benchmark/{self.agent_id}")
        return BenchmarkOverviewResponse(**res)

    async def compare_trial_performance_async(self, trial_id: str, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> CompareResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"scheme": target_scheme, "asset": asset.value}
        res = await self.execute_request_async("POST", f"/api/agent/benchmark/trials/{trial_id}/agent/{self.agent_id}/compare", payload)
        return CompareResponse(**res)

    async def request_fast_pass_aggregate_async(self, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> AggregateResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"scheme": target_scheme, "asset": asset.value}
        res = await self.execute_request_async("POST", f"/api/agent/benchmark/trials/{self.agent_id}/aggregate", payload)
        return AggregateResponse(**res)

    async def submit_monzen_trace_async(self, target_url: str, invoice: str, preimage: Optional[str] = None, method: str = "POST",scheme: Optional[str] = None) -> MonzenTraceResponse: 
        payload = {"agentId": self.agent_id, "targetUrl": target_url, "invoice": invoice, "method": method}
        if preimage: payload["preimage"] = preimage
        if scheme: payload["scheme"] = scheme
        res_dict = await self.execute_request_async("POST", "/api/agent/monzen/trace", payload)
        return MonzenTraceResponse(**res_dict)

    async def get_site_metrics_async(self, limit: int = 10, target_agent_id: Optional[str] = None, scheme: Optional[str] = None) -> MonzenMetricsResponse:
        params = {"limit": limit}
        if target_agent_id: params["agentId"] = target_agent_id
        if scheme: params["scheme"] = scheme
        res = await self.execute_request_async("GET", "/api/agent/monzen/metrics", payload=params)
        return MonzenMetricsResponse(**res)

    async def download_monzen_graph_async(self, asset: AssetType = AssetType.SATS, scheme: Optional[str] = None) -> MonzenGraphResponse:
        target_scheme = scheme or (SchemeType.l402.value if asset == AssetType.SATS else SchemeType.x402.value)
        payload = {"scheme": target_scheme, "asset": asset.value, "agentId": self.agent_id}
        res = await self.execute_request_async("GET", f"/api/agent/monzen/graph", payload=payload)
        return MonzenGraphResponse(**res)

    # ------------------------------------------
    # 🧪 Sandbox Harness Integration
    # ------------------------------------------
    def run_l402_sandbox_harness(self) -> "InteropRunResult":
        """
        Native L402 Path を使用して Sandbox Harness を End-to-End で実行し、
        プロトコル互換性を確認して Interop Report まで自動で閉じる。
        """
        import json
        import hashlib
        import re
        from .models import InteropRunResult

        basic_path = "/api/agent/sandbox/l402/basic"
        report_path = "/api/agent/sandbox/interop/report"

        # 1. Execute Native L402 Flow (402 -> Pay -> 200)
        # 既存の execute_detailed を呼ぶことで、Policy/TrustのGuardrailに完全に乗る
        exec_result = self.execute_detailed("GET", basic_path)
        resp = exec_result.response

        # 2. Extract Metadata
        meta = resp.get("meta", {})
        run_id = meta.get("run_id", "")
        scenario_id = meta.get("scenario_id", "")
        expected_hash = meta.get("canonical_hash_expected", "")
        interop_token = meta.get("interop_token", "")

        # 3. Calculate Observed Hash (Node.js JSON.stringify equivalent)
        deterministic_payload = {
            "message": resp.get("message"),
            "scenario": resp.get("scenario"),
            "contract": resp.get("contract"),
            "verifiable": resp.get("verifiable")
        }
        json_str = json.dumps(deterministic_payload, separators=(',', ':'))
        observed_hash = hashlib.sha256(json_str.encode('utf-8')).hexdigest()

        # 4. Prepare Report
        receipt = exec_result.settlement_receipt
        payment_performed = receipt.payment_performed if receipt else True
        cached_token_used = receipt.cached_token_used if receipt else False
        delegate_source = receipt.delegate_source if receipt else "native"
        
        # Matrix上での表示名。Nativeでない場合は delegate_source をそのまま使う
        executor_mode = "ln-church-agent-native" if delegate_source == "native" else delegate_source

        report_payload = {
            "run_id": run_id,
            "scenario_id": scenario_id,
            "canonical_hash_expected": expected_hash,
            "canonical_hash_observed": observed_hash,
            "executor_mode": executor_mode,
            "delegate_source": delegate_source,
            "cached_token_used": cached_token_used,
            "payment_performed": payment_performed,
            "fee_sats": receipt.fee_sats if receipt else 0,
            "sdk_version": SDK_VERSION,
            "interop_token": interop_token,
            "comparison_class": "production_like",
            "test_mode": "normal"
        }

        # 5. POST Interop Report
        report_resp = {}
        status_code = 500
        accepted = False
        try:
            report_exec = self.execute_detailed("POST", report_path, payload=report_payload)
            report_resp = report_exec.response
            status_code = 200
            accepted = report_resp.get("status") == "success"
        except Exception as e:
            m = re.search(r"API Error (\d+):", str(e))
            if m:
                status_code = int(m.group(1))
            report_resp = {"error": str(e)}

        # 6. Return Structured Result
        return InteropRunResult(
            ok=accepted and (expected_hash == observed_hash),
            target_url=exec_result.final_url,
            run_id=run_id,
            scenario_id=scenario_id,
            executor_mode=executor_mode,
            delegate_source=delegate_source,
            canonical_hash_expected=expected_hash,
            canonical_hash_observed=observed_hash,
            canonical_hash_matched=(expected_hash == observed_hash),
            report_status_code=status_code,
            report_accepted=accepted,
            payment_performed=payment_performed,
            cached_token_used=cached_token_used,
            receipt_id=receipt.receipt_id if receipt else None,
            raw_report_response=report_resp
        )

    async def run_l402_sandbox_harness_async(self) -> "InteropRunResult":
        """非同期版の Sandbox Harness 実行ヘルパー"""
        import json
        import hashlib
        import re
        from .models import InteropRunResult

        basic_path = "/api/agent/sandbox/l402/basic"
        report_path = "/api/agent/sandbox/interop/report"

        exec_result = await self.execute_detailed_async("GET", basic_path)
        resp = exec_result.response

        meta = resp.get("meta", {})
        run_id = meta.get("run_id", "")
        scenario_id = meta.get("scenario_id", "")
        expected_hash = meta.get("canonical_hash_expected", "")
        interop_token = meta.get("interop_token", "")

        deterministic_payload = {
            "message": resp.get("message"),
            "scenario": resp.get("scenario"),
            "contract": resp.get("contract"),
            "verifiable": resp.get("verifiable")
        }
        json_str = json.dumps(deterministic_payload, separators=(',', ':'))
        observed_hash = hashlib.sha256(json_str.encode('utf-8')).hexdigest()

        receipt = exec_result.settlement_receipt
        payment_performed = receipt.payment_performed if receipt else True
        cached_token_used = receipt.cached_token_used if receipt else False
        delegate_source = receipt.delegate_source if receipt else "native"
        
        # Matrix上での表示名。Nativeでない場合は delegate_source をそのまま使う
        executor_mode = "ln-church-agent-native" if delegate_source == "native" else delegate_source

        report_payload = {
            "run_id": run_id,
            "scenario_id": scenario_id,
            "canonical_hash_expected": expected_hash,
            "canonical_hash_observed": observed_hash,
            "executor_mode": executor_mode,
            "delegate_source": delegate_source,
            "cached_token_used": cached_token_used,
            "payment_performed": payment_performed,
            "fee_sats": receipt.fee_sats if receipt else 0,
            "sdk_version": SDK_VERSION,
            "interop_token": interop_token,
            "comparison_class": "production_like",
            "test_mode": "normal"
        }

        report_resp = {}
        status_code = 500
        accepted = False
        try:
            report_exec = await self.execute_detailed_async("POST", report_path, payload=report_payload)
            report_resp = report_exec.response
            status_code = 200
            accepted = report_resp.get("status") == "success"
        except Exception as e:
            m = re.search(r"API Error (\d+):", str(e))
            if m:
                status_code = int(m.group(1))
            report_resp = {"error": str(e)}

        return InteropRunResult(
            ok=accepted and (expected_hash == observed_hash),
            target_url=exec_result.final_url,
            run_id=run_id,
            scenario_id=scenario_id,
            executor_mode=executor_mode,
            delegate_source=delegate_source,
            canonical_hash_expected=expected_hash,
            canonical_hash_observed=observed_hash,
            canonical_hash_matched=(expected_hash == observed_hash),
            report_status_code=status_code,
            report_accepted=accepted,
            payment_performed=payment_performed,
            cached_token_used=cached_token_used,
            receipt_id=receipt.receipt_id if receipt else None,
            raw_report_response=report_resp
        )

    # ------------------------------------------
    # 🧪 External Protocol Verification (Live Endpoints)
    # ------------------------------------------
    def run_external_protocol_verification(
        self, target_url: str, scenario_id: str = "external_verification_v1", debug: bool = False
    ) -> "ExternalProtocolRunResult":
        import time, re
        from .models import ExternalProtocolRunResult

        logs = []
        def dlog(msg): 
            if debug: print(f"🔍 [DEBUG] {msg}")
            logs.append(msg)

        start_time = time.time()
        stage = "init"
        error_reason = None
        resp_data = None
        status_code = 500
        receipt = None
        origin = "unknown"
        upstream_host = None

        # --- A. Attribution Bug の修正: 実行前に確定させる ---
        # 以前のコードは成功時の receipt から判定していたため、失敗時に Native と誤認されていた
        is_get = True
        use_delegate = (
            self.prefer_lightninglabs_l402 and 
            urlparse(target_url).netloc in self.l402_delegate_allowed_hosts
        )
        delegate_source = "lightninglabs-delegated" if use_delegate else "native"
        executor_mode = delegate_source if use_delegate else "ln-church-agent-native"
        
        dlog(f"Target: {target_url} | Mode: {executor_mode} | Delegate: {use_delegate}")
        if self.ln_adapter:
            # 秘密鍵を伏せて LNBits URL を確認
            masked_url = re.sub(r'://.*?@', '://[redacted]@', getattr(self.ln_adapter, 'api_url', 'unknown'))
            dlog(f"Payment Backend: {masked_url}")

        try:
            # --- 段階1: チャレンジ取得 ---
            stage = "challenge_fetch"
            dlog("Step 1: Fetching 402 challenge...")
            
            # execute_detailed を実行。この中で 402 検知 -> 決済 -> 200 リトライが走る
            exec_result = self.execute_detailed("GET", target_url)
            
            # --- 段階2: レスポンス検証 ---
            stage = "response_shape_check"
            resp_data = exec_result.response
            receipt = exec_result.settlement_receipt
            status_code = 200
            dlog("Step 2: Successfully received 200 OK after payment.")
            
        except Exception as e:
            error_reason = str(e)
            # --- B. 発生源のヒューリスティック分析 ---
            if "LNBits Payment Failed" in error_reason:
                origin = "payment_backend"
                stage = "payment_initiation"
            elif "initiated but not settled" in error_reason:
                origin = "payment_backend"
                stage = "payment_settlement_check" # あなたの画像の状態（決済済みなのにLNBits APIが同期中）
            elif "402 challenge" in error_reason:
                origin = "target_endpoint"
                stage = "challenge_parse"
            
            # Cloudflare 520 HTML からのメタデータ抽出
            m_code = re.search(r"Error code (\d+)", error_reason)
            if m_code: status_code = int(m_code.group(1))
            
            m_host = re.search(r"host-status.*?>(.*?)</span>", error_reason, re.S)
            if m_host: 
                upstream_host = re.sub('<[^>]*>', '', m_host.group(1)).strip()
                dlog(f"Identified failing upstream host: {upstream_host}")

        latency_ms = int((time.time() - start_time) * 1000)
        
        response_shape_ok = False
        if resp_data:
            response_shape_ok = True
            excerpt = str(resp_data)[:200]
        else:
            excerpt = ""

        return ExternalProtocolRunResult(
            ok=(status_code == 200 and response_shape_ok),
            target_url=target_url,
            scenario_id=scenario_id,
            executor_mode=executor_mode,
            delegate_source=delegate_source,
            status_code_after_payment=status_code,
            payment_performed=receipt.payment_performed if receipt else (origin == "payment_backend"),
            cached_token_used=receipt.cached_token_used if receipt else False,
            receipt_id=receipt.receipt_id if receipt else None,
            latency_ms=latency_ms,
            response_shape_ok=response_shape_ok,
            response_excerpt=excerpt,
            protocol_success=(status_code == 200),
            schema_check_reason="Valid JSON" if response_shape_ok else "No response data",
            error_stage=stage if status_code != 200 else None,
            error_reason=error_reason,
            suspected_failure_origin=origin,
            upstream_status_code=status_code if status_code != 200 else None,
            upstream_host_excerpt=upstream_host,
            debug_logs=logs
        )

    async def run_external_protocol_verification_async(
        self, target_url: str, scenario_id: str = "external_verification_v1", debug: bool = False
    ) -> "ExternalProtocolRunResult":
        """
        外部のLive Endpointに対するプロトコル成功とレスポンス形状を検証する (非同期版)。
        同期版とロジックを同期させ、Attribution修正と詳細デバッグログを実装。
        """
        import time, re
        from .models import ExternalProtocolRunResult

        logs = []
        def dlog(msg): 
            if debug: print(f"🔍 [DEBUG ASYNC] {msg}")
            logs.append(msg)

        start_time = time.time()
        stage = "init"
        error_reason = None
        resp_data = None
        status_code = 500
        receipt = None
        origin = "unknown"
        upstream_host = None

        # --- A. Attribution Bug の修正: 実行前に確定させる ---
        use_delegate = (
            self.prefer_lightninglabs_l402 and 
            urlparse(target_url).netloc in self.l402_delegate_allowed_hosts
        )
        delegate_source = "lightninglabs-delegated" if use_delegate else "native"
        executor_mode = delegate_source if use_delegate else "ln-church-agent-native"
        
        dlog(f"Target: {target_url} | Mode: {executor_mode} | Delegate: {use_delegate}")
        if self.ln_adapter:
            masked_url = re.sub(r'://.*?@', '://[redacted]@', getattr(self.ln_adapter, 'api_url', 'unknown'))
            dlog(f"Payment Backend: {masked_url}")

        try:
            # --- 段階1: チャレンジ取得 ---
            stage = "challenge_fetch"
            dlog("Step 1: Fetching 402 challenge (Async)...")
            
            # 非同期版の実行メソッドを呼び出す
            exec_result = await self.execute_detailed_async("GET", target_url)
            
            # --- 段階2: レスポンス検証 ---
            stage = "response_shape_check"
            resp_data = exec_result.response
            receipt = exec_result.settlement_receipt
            status_code = 200
            dlog("Step 2: Successfully received 200 OK after payment (Async).")
            
        except Exception as e:
            error_reason = str(e)
            # --- B. 発生源のヒューリスティック分析 (同期版と共通) ---
            if "LNBits Payment Failed" in error_reason:
                origin = "payment_backend"
                stage = "payment_initiation"
            elif "initiated but not settled" in error_reason:
                origin = "payment_backend"
                stage = "payment_settlement_check"
            elif "402 challenge" in error_reason:
                origin = "target_endpoint"
                stage = "challenge_parse"
            
            # Cloudflare 520 HTML からのメタデータ抽出
            m_code = re.search(r"Error code (\d+)", error_reason)
            if m_code: status_code = int(m_code.group(1))
            
            m_host = re.search(r"host-status.*?>(.*?)</span>", error_reason, re.S)
            if m_host: 
                upstream_host = re.sub('<[^>]*>', '', m_host.group(1)).strip()
                dlog(f"Identified failing upstream host: {upstream_host}")

        latency_ms = int((time.time() - start_time) * 1000)
        
        # Shape Check ロジック
        response_shape_ok = False
        if resp_data:
            response_shape_ok = True
            excerpt = str(resp_data)[:200]
        else:
            excerpt = ""

        return ExternalProtocolRunResult(
            ok=(status_code == 200 and response_shape_ok),
            target_url=target_url,
            scenario_id=scenario_id,
            executor_mode=executor_mode,
            delegate_source=delegate_source,
            status_code_after_payment=status_code,
            payment_performed=receipt.payment_performed if receipt else (origin == "payment_backend"),
            cached_token_used=receipt.cached_token_used if receipt else False,
            receipt_id=receipt.receipt_id if receipt else None,
            latency_ms=latency_ms,
            response_shape_ok=response_shape_ok,
            response_excerpt=excerpt,
            protocol_success=(status_code == 200),
            schema_check_reason="Valid JSON" if response_shape_ok else "No response data",
            error_stage=stage if status_code != 200 else None,
            error_reason=error_reason,
            suspected_failure_origin=origin,
            upstream_status_code=status_code if status_code != 200 else None,
            upstream_host_excerpt=upstream_host,
            debug_logs=logs
        )