"""Thin Python wrappers for Rust-owned PACT nodes.

These classes are ergonomic host objects only. They do not own projection,
storage, lifecycle, selector, or commit semantics.
"""

from __future__ import annotations

import html
import time
from typing import Any, ClassVar, Optional

from pydantic import BaseModel, ConfigDict, Field


def generate_hash_id(node_type: str = "node", parent_id: str = "") -> str:
    seed = f"{parent_id}:{node_type}:{time.time_ns()}"
    return f"{node_type.replace('_', '')[:4] or 'node'}_{abs(hash(seed)) & 0xffffffff:08x}"


class Metadata(BaseModel):
    """Host-side metadata bag.

    Canonical PACT fields live on the node itself. `props` is retained only so
    existing scaffold XML helpers can keep their local rendering attributes.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")

    props: dict[str, Any] = Field(default_factory=dict)
    aux: dict[str, Any] = Field(default_factory=dict)
    active: bool = True
    source: str = "host"
    turn_index: int = 0
    priority: int = 0
    creation_index: int = 0
    born_turn_index: int = 0


class XMLAttributeAccessor:
    def __init__(self, attrs: dict[str, Any]):
        self._attrs = attrs

    def __getitem__(self, key: str) -> Any:
        return self._attrs[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._attrs[str(key)] = value

    def __delitem__(self, key: str) -> None:
        del self._attrs[key]

    def __contains__(self, key: str) -> bool:
        return key in self._attrs

    def get(self, key: str, default: Any = None) -> Any:
        return self._attrs.get(key, default)

    def keys(self):
        return self._attrs.keys()

    def items(self):
        return self._attrs.items()

    def update(self, *args: Any, **kwargs: Any) -> None:
        self._attrs.update(*args, **kwargs)


class PACTCore(BaseModel):
    """Base host wrapper for a canonical PACT node."""

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")

    type: ClassVar[str] = "pact_node"
    description: ClassVar[str] = ""

    id: str = Field(default_factory=lambda: generate_hash_id())
    content: Any = ""
    ttl: Optional[int] = None
    cad: Optional[int] = None
    key: Optional[str] = None
    tags: list[str] = Field(default_factory=list)
    metadata: Metadata = Field(default_factory=Metadata)
    parent_id: Optional[str] = None
    offset: Optional[int] = None
    pact_depth: Optional[int] = None
    priority: Optional[int] = None
    transaction_index: Optional[int] = None
    created_at_ns: int = Field(default_factory=time.time_ns)
    creation_index: int = 0
    attrs: dict[str, Any] = Field(default_factory=dict)
    org: dict[str, Any] = Field(default_factory=dict)
    surface: dict[str, Any] = Field(default_factory=dict)
    content_ref: str | dict[str, Any] | None = None

    @property
    def current_episode(self) -> int:
        return self.metadata.turn_index

    @current_episode.setter
    def current_episode(self, value: int) -> None:
        self.metadata.turn_index = int(value)

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        kwargs.pop("mode", None)
        data = super().model_dump(mode="python", **kwargs)
        data["type"] = self.type
        data["nodeType"] = self.type
        if self.attrs:
            data["attrs"] = dict(self.attrs)
        else:
            data.pop("attrs", None)
        if self.org:
            data["org"] = dict(self.org)
        else:
            data.pop("org", None)
        if self.surface:
            data["surface"] = dict(self.surface)
        else:
            data.pop("surface", None)
        return data

    def to_pact_node(self) -> dict[str, Any]:
        return self.model_dump()

    def render(self, *_: Any, **__: Any) -> str:
        return str(self.content or "")

    def __str__(self) -> str:
        return self.render()


class PACTNode(PACTCore):
    pass


class PactCore(PACTNode):
    pass


class PACTSegment(PACTCore):
    pass


class PACTContainer(PACTCore):
    type: ClassVar[str] = "message_container"
    content: list[Any] = Field(default_factory=list)

    @property
    def core(self) -> "PACTContainer":
        return self

    def append(self, component: Any) -> None:
        self.content.append(component)

    def __iter__(self):
        return iter(self.content)

    def __len__(self) -> int:
        return len(self.content)

    def __getitem__(self, index: int) -> Any:
        return self.content[index]


class PactRoot(PACTCore):
    type: ClassVar[str] = "root"


class MessageTurn(PACTSegment):
    type: ClassVar[str] = "message_turn"
    role: str | None = None
    content: PACTContainer = Field(default_factory=PACTContainer)


class MessageContainer(PACTContainer):
    type: ClassVar[str] = "message_container"


class SystemHeader(PACTCore):
    type: ClassVar[str] = "system_header"


class TextContent(PACTNode):
    type: ClassVar[str] = "text_content"


class XMLComponent(PACTNode):
    type: str = "xml"

    def model_post_init(self, __context: Any) -> None:
        extra = getattr(self, "__pydantic_extra__", None) or {}
        for key, value in extra.items():
            if key == "type" or value is None:
                continue
            if isinstance(value, (str, int, float, bool)) and key not in self.metadata.props:
                self.metadata.props[key] = value

    @property
    def xml(self) -> "XMLComponent":
        return self

    def _render_props(self) -> dict[str, Any]:
        props = dict(self.metadata.props)
        props.update(self.attrs_as_plain_dict())
        props.update(self._xml_field_attrs())
        return props

    def attrs_as_plain_dict(self) -> dict[str, Any]:
        return dict(self.attrs.items())

    def _xml_field_attrs(self) -> dict[str, Any]:
        excluded = {
            "id",
            "content",
            "ttl",
            "cad",
            "key",
            "tags",
            "metadata",
            "parent_id",
            "offset",
            "pact_depth",
            "priority",
            "transaction_index",
            "created_at_ns",
            "creation_index",
            "attrs",
            "org",
            "surface",
            "content_ref",
            "type",
            "nodeType",
            "previous_content",
        }
        data = super().model_dump()
        attrs: dict[str, Any] = {}
        for key, value in data.items():
            if key in excluded or value is None:
                continue
            if isinstance(value, (str, int, float, bool)):
                attrs[key] = value
        return attrs

    def render(self, *_: Any, **__: Any) -> str:
        tag = self.type
        attrs = []
        for key, value in self._render_props().items():
            if value is None:
                continue
            escaped = html.escape(str(value), quote=True)
            attrs.append(f'{key}="{escaped}"')
        attr_text = (" " + " ".join(attrs)) if attrs else ""
        body = self._render_body()
        if not body:
            return f"<{tag}{attr_text}/>"
        return f"<{tag}{attr_text}>{body}</{tag}>"

    def _render_body(self) -> str:
        if self.content is None:
            return ""
        if isinstance(self.content, list):
            rendered = []
            for item in self.content:
                if isinstance(item, XMLComponent):
                    rendered.append(item.render())
                elif hasattr(item, "render"):
                    rendered.append(str(item.render()))
                else:
                    rendered.append(html.escape(str(item)))
            return "".join(rendered)
        return html.escape(str(self.content))


PACTContent = PACTNode
ContextHook = PACTNode


__all__ = [
    "Metadata",
    "XMLAttributeAccessor",
    "PACTCore",
    "PACTNode",
    "PactCore",
    "PactRoot",
    "PACTSegment",
    "PACTContainer",
    "MessageTurn",
    "MessageContainer",
    "SystemHeader",
    "TextContent",
    "XMLComponent",
    "PACTContent",
    "ContextHook",
    "generate_hash_id",
]
