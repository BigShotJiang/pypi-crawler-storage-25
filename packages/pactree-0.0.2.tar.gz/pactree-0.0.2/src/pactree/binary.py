"""Binary bridge for the definitive Pactree engine."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any


def pact_binary_path() -> Path:
    override = os.environ.get("PACTREE_BIN") or os.environ.get("EGREGORE_PACT_BIN")
    if override:
        return Path(override)

    current = Path(__file__).resolve()
    for parent in current.parents:
        candidate = parent / "pactree" / "target" / "debug" / "pactree"
        if candidate.exists():
            return candidate

    raise RuntimeError(
        "pactree binary not found; run `cargo build` in the pactree project "
        "or set PACTREE_BIN"
    )


def normalize_pact_tree_via_binary(
    pact_tree: dict[str, Any] | list[Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    if isinstance(pact_tree, str):
        pact_json = pact_tree
    else:
        pact_json = json.dumps(pact_tree, ensure_ascii=False, separators=(",", ":"))

    env = os.environ.copy()
    env["PACT_BLOB_INLINE_LIMIT"] = str(blob_inline_limit)
    proc = subprocess.run(
        [str(pact_binary_path()), "normalize"],
        input=pact_json,
        text=True,
        capture_output=True,
        check=False,
        env=env,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "pactree normalize failed")

    normalized = json.loads(proc.stdout)
    if not isinstance(normalized, dict):
        raise ValueError("pactree returned a non-object normalized payload")
    return normalized


def select_pact_tree_via_binary(
    pact_tree: dict[str, Any] | list[Any] | str,
    selector: str,
) -> list[dict[str, Any]]:
    if isinstance(pact_tree, str):
        pact_json = pact_tree
    else:
        pact_json = json.dumps(pact_tree, ensure_ascii=False, separators=(",", ":"))

    proc = subprocess.run(
        [str(pact_binary_path()), "select", selector],
        input=pact_json,
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "pactree select failed")

    selected = json.loads(proc.stdout)
    if not isinstance(selected, list):
        raise ValueError("pactree returned a non-list selector payload")
    return selected


def delete_pact_tree_via_binary(
    pact_tree: dict[str, Any] | list[Any] | str,
    selector: str,
) -> dict[str, Any]:
    if isinstance(pact_tree, str):
        pact_json = pact_tree
    else:
        pact_json = json.dumps(pact_tree, ensure_ascii=False, separators=(",", ":"))

    proc = subprocess.run(
        [str(pact_binary_path()), "delete", selector],
        input=pact_json,
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "pactree delete failed")

    deleted = json.loads(proc.stdout)
    if not isinstance(deleted, dict):
        raise ValueError("pactree returned a non-object delete payload")
    return deleted


__all__ = [
    "delete_pact_tree_via_binary",
    "normalize_pact_tree_via_binary",
    "pact_binary_path",
    "select_pact_tree_via_binary",
]
