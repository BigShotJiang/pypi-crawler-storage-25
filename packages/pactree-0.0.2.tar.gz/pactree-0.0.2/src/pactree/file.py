"""Transitional Python facade for canonical Rust `.pact` files.

The storage engine lives in Rust. This module keeps Python at the API edge:
paths and JSON-shaped payloads in, JSON-shaped reports out. It should remain a
compatibility wrapper; the release-facing PACT interface is the native
`.pact`/`pactree` binary surface.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .native import (
    pact_file_append_content_manifest,
    pact_file_append_commit,
    pact_file_append_trace,
    pact_file_append_views,
    pact_file_bundle_create,
    pact_file_bundle_export_full,
    pact_file_bundle_prune,
    pact_file_bundle_verify,
    pact_file_create,
    pact_file_content_manifest_payload,
    pact_file_content_payload,
    pact_file_cycles,
    pact_file_import,
    pact_file_import_check,
    pact_file_info,
    pact_file_inspect,
    pact_file_materialize,
    pact_file_merge,
    pact_file_open,
    pact_file_open_head_fast,
    pact_file_project_range,
    pact_file_projection,
    pact_file_query,
    pact_file_repair,
    pact_file_root_store,
    pact_file_slice,
    pact_file_validate,
    pact_file_view_detach,
    pact_file_view_merge,
    pact_file_view_merge_preflight,
    pact_file_view_projection,
    pact_file_view_query,
    pact_file_view_rebase,
)


def create(
    path: str | Path,
    root_store: dict[str, Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_file_create(
        str(path),
        root_store,
        blob_inline_limit=blob_inline_limit,
    )


def append_views(
    path: str | Path,
    view_records: dict[str, Any] | list[Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_file_append_views(
        str(path),
        view_records,
        blob_inline_limit=blob_inline_limit,
    )


def append_commit(
    path: str | Path,
    commit: dict[str, Any] | str,
    node_records: list[Any] | str,
    content_store: dict[str, Any] | str | None = None,
) -> dict[str, Any]:
    return pact_file_append_commit(str(path), commit, node_records, content_store)


def append_trace(
    path: str | Path,
    trace: dict[str, Any] | str,
) -> dict[str, Any]:
    return pact_file_append_trace(str(path), trace)


def append_content_manifest(
    path: str | Path,
    manifest: dict[str, Any] | str,
) -> dict[str, Any]:
    return pact_file_append_content_manifest(str(path), manifest)


def content_manifest_payload(path: str | Path, manifest_id: str) -> dict[str, Any]:
    return pact_file_content_manifest_payload(str(path), manifest_id)


def content_payload(path: str | Path, content_id: str) -> dict[str, Any]:
    return pact_file_content_payload(str(path), content_id)


def inspect(path: str | Path) -> dict[str, Any]:
    return pact_file_inspect(str(path))


def info(path: str | Path) -> dict[str, Any]:
    return pact_file_info(str(path))


def validate(path: str | Path) -> dict[str, Any]:
    return pact_file_validate(str(path))


def bundle_create(path: str | Path) -> dict[str, Any]:
    return pact_file_bundle_create(str(path))


def bundle_verify(path: str | Path) -> dict[str, Any]:
    return pact_file_bundle_verify(str(path))


def bundle_export_full(path: str | Path, output_path: str | Path) -> dict[str, Any]:
    return pact_file_bundle_export_full(str(path), str(output_path))


def bundle_prune(path: str | Path) -> dict[str, Any]:
    return pact_file_bundle_prune(str(path))


def materialize(
    path: str | Path,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
) -> dict[str, Any]:
    return pact_file_materialize(
        str(path),
        branch_id=branch_id,
        revision=revision,
    )


def projection(
    path: str | Path,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
    view: str | None = None,
    component_id: str | None = None,
) -> dict[str, Any]:
    return pact_file_projection(
        str(path),
        branch_id=branch_id,
        revision=revision,
        blob_inline_limit=blob_inline_limit,
        view=view,
        component_id=component_id,
    )


def project(
    path: str | Path,
    range: str | None = None,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
    view: str | None = None,
    component_id: str | None = None,
) -> dict[str, Any]:
    """Project a `.pact` file, optionally restricted by the unified range syntax.

    `range` uses the same CLI grammar as `pact project`, currently `start..end`
    over cycle numbers.
    """
    if range is None:
        return projection(
            path,
            branch_id=branch_id,
            revision=revision,
            blob_inline_limit=blob_inline_limit,
            view=view,
            component_id=component_id,
        )
    return pact_file_project_range(
        str(path),
        range,
        branch_id=branch_id,
        revision=revision,
        blob_inline_limit=blob_inline_limit,
        view=view,
        component_id=component_id,
    )


def open(
    path: str | Path,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_file_open(
        str(path),
        branch_id=branch_id,
        revision=revision,
        blob_inline_limit=blob_inline_limit,
    )


def open_head_fast(path: str | Path) -> dict[str, Any]:
    return pact_file_open_head_fast(str(path))


def cycles(path: str | Path) -> dict[str, Any]:
    return pact_file_cycles(str(path))


def view_projection(
    path: str | Path,
    view_id: str,
    *,
    blob_inline_limit: int = 1024,
    view: str | None = None,
    component_id: str | None = None,
) -> dict[str, Any]:
    return pact_file_view_projection(
        str(path),
        view_id,
        blob_inline_limit=blob_inline_limit,
        view=view,
        component_id=component_id,
    )


def view_query(
    path: str | Path,
    view_id: str,
    query_kind: str,
    *,
    key: str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_file_view_query(
        str(path),
        view_id,
        query_kind,
        key=key,
        blob_inline_limit=blob_inline_limit,
    )


def view_merge_preflight(path: str | Path, view_id: str) -> dict[str, Any]:
    return pact_file_view_merge_preflight(str(path), view_id)


def view_merge(
    path: str | Path,
    view_id: str,
    *,
    policy: str | None = None,
) -> dict[str, Any]:
    return pact_file_view_merge(str(path), view_id, policy=policy)


def view_detach(path: str | Path, view_id: str, detached_branch_id: str) -> dict[str, Any]:
    return pact_file_view_detach(str(path), view_id, detached_branch_id)


def view_rebase(
    path: str | Path,
    view_id: str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_file_view_rebase(
        str(path),
        view_id,
        blob_inline_limit=blob_inline_limit,
    )


def root_store(path: str | Path) -> dict[str, Any]:
    return pact_file_root_store(str(path))


def query(
    path: str | Path,
    query_kind: str,
    *,
    key: str | None = None,
) -> dict[str, Any]:
    return pact_file_query(str(path), query_kind, key=key)


def repair(
    source_path: str | Path,
    repaired_path: str | Path,
    *,
    truncate_corrupt_tail: bool = False,
) -> dict[str, Any]:
    return pact_file_repair(
        str(source_path),
        str(repaired_path),
        truncate_corrupt_tail=truncate_corrupt_tail,
    )


def slice(
    source_path: str | Path,
    output_path: str | Path,
    spec: dict[str, Any] | str,
) -> dict[str, Any]:
    return pact_file_slice(str(source_path), str(output_path), spec)


def import_check(path: str | Path) -> dict[str, Any]:
    return pact_file_import_check(str(path))


def import_slice(target_path: str | Path, slice_path: str | Path) -> dict[str, Any]:
    return pact_file_import(str(target_path), str(slice_path))


def merge(target_path: str | Path, slice_path: str | Path) -> dict[str, Any]:
    return pact_file_merge(str(target_path), str(slice_path))


__all__ = [
    "append_content_manifest",
    "append_commit",
    "append_trace",
    "append_views",
    "bundle_create",
    "bundle_export_full",
    "bundle_prune",
    "bundle_verify",
    "create",
    "content_manifest_payload",
    "content_payload",
    "cycles",
    "import_slice",
    "import_check",
    "info",
    "inspect",
    "materialize",
    "merge",
    "open",
    "open_head_fast",
    "project",
    "projection",
    "query",
    "repair",
    "root_store",
    "slice",
    "validate",
    "view_detach",
    "view_merge",
    "view_merge_preflight",
    "view_projection",
    "view_query",
    "view_rebase",
]
