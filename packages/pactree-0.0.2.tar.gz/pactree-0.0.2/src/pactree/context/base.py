"""Rust-backed PACT context facade.

This module is intentionally small. Python hosts submit typed intent and read
typed projections; Rust PACT owns mutation, selector, projection, lifecycle,
trace, commit, head, and storage semantics.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional

from ..components.core import (
    MessageTurn,
    PACTContainer,
    PACTCore,
    PACTNode,
    PactRoot,
    SystemHeader,
    TextContent,
)
from ..native import pact_file_create, select_pact_subtrees
from .native_bridge import PactContextBridge

try:
    from egregore.core.messaging.provider_echo import merge_provider_echo_from_aux
except ModuleNotFoundError:
    def merge_provider_echo_from_aux(target: dict[str, Any], aux: Any) -> None:
        if isinstance(aux, dict) and isinstance(aux.get("surface"), dict):
            target.setdefault("surface", {}).update(aux["surface"])


@dataclass
class UpdateResult:
    success: bool = True
    updated_components: list[Any] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


class _ToolRegistry:
    """Execution helper only; canonical pairing lives in Rust PACT."""

    def __init__(self) -> None:
        self._tool_executions: dict[str, list[str]] = {}

    def register_tool_pair(self, call_id: str, call_component_id: str) -> None:
        self._tool_executions.setdefault(str(call_id), [])
        if call_component_id not in self._tool_executions[str(call_id)]:
            self._tool_executions[str(call_id)].append(call_component_id)

    def complete_tool_pair(self, call_id: str, result_component_id: str) -> None:
        self._tool_executions.setdefault(str(call_id), [])
        if result_component_id not in self._tool_executions[str(call_id)]:
            self._tool_executions[str(call_id)].append(result_component_id)

    def unregister_tool_pair(self, call_id: str) -> None:
        self._tool_executions.pop(str(call_id), None)

    def apply_operation_report(self, *_: Any, **__: Any) -> None:
        return None

    def get_components_for_rehydration(self, *_: Any, **__: Any) -> list[Any]:
        return []


class _ContentFacade:
    def __init__(self, context: "Context") -> None:
        self._context = context

    def iter_depth_items(self):
        yield -1, self._context.system_header
        yield 0, self._context.active_message

    def __iter__(self):
        return iter([self._context.system_header, self._context.active_message])

    def __len__(self) -> int:
        return 2

    def __getitem__(self, depth: int):
        if depth == -1:
            return self._context.system_header
        if depth == 0:
            return self._context.active_message
        raise IndexError(depth)

    def depths(self) -> list[int]:
        return [-1, 0]


class Context(PactRoot):
    """Thin Python interface over a Rust `NativeResolver`."""

    def __init__(self, template: Optional[Any] = None, agent_id: Optional[str] = None, **kwargs: Any):
        super().__init__(**kwargs)
        self.agent_id = agent_id
        self.branch_id = "main"
        self._sequence = 0
        self._current_episode = 0
        self._cancelled = False
        self._hooks = None
        self._agent_ref = None
        self.context_manager = None
        self._registry = _ToolRegistry()
        self._node_cache: dict[str, Any] = {}
        self._system_header = SystemHeader(id="system", content="")
        self._active_message = MessageTurn(id="active", role="user")
        self.content = _ContentFacade(self)
        self._resolver = PactContextBridge(self._initial_tree(), branch_id=self.branch_id)
        self._pact = self._resolver
        self._session_storage_root: Path | None = None
        self._session_id: str | None = None
        self._pact_file_path: Path | None = None
        self._context_history: Any | None = None

    def _initial_tree(self) -> dict[str, Any]:
        return {
            "id": "root",
            "nodeType": "root",
            "type": "root",
            "children": [
                {
                    "id": "system",
                    "nodeType": "system_header",
                    "type": "system_header",
                    "role": "system",
                    "children": [],
                }
            ],
        }

    @property
    def current_episode(self) -> int:
        return self._current_episode

    @current_episode.setter
    def current_episode(self, value: int) -> None:
        self._current_episode = int(value)

    @property
    def is_cancelled(self) -> bool:
        return self._cancelled

    def cancel(self) -> None:
        self._cancelled = True

    def reset_cancel(self) -> None:
        self._cancelled = False

    @property
    def system_header(self) -> SystemHeader:
        return self._system_header

    @property
    def conversation_history(self) -> _ContentFacade:
        return self.content

    @property
    def active_message(self) -> MessageTurn:
        return self._active_message

    def _set_agent_ref(self, agent: Any) -> None:
        self._agent_ref = agent

    def set_agent(self, agent: Any) -> None:
        self._set_agent_ref(agent)

    def configure_session_storage(
        self,
        *,
        session_storage_root: str | Path | None = None,
        session_id: str | None = None,
    ) -> Path | None:
        """Bind this Context's native Pact resolver to the session file.

        The host supplies only storage identity. Creation and future commit
        persistence remain native PACT responsibilities.
        """

        if session_storage_root is not None:
            self._session_storage_root = Path(session_storage_root).expanduser()
        if session_id is not None:
            self._session_id = str(session_id)
        return self._ensure_pact_file_bound(create=True)

    def _set_context_history(self, history: Any) -> None:
        """Attach host trace storage without giving it Pact authority."""

        self._context_history = history
        storage_root = getattr(history, "storage_root", None)
        session_id = getattr(history, "id", None) or getattr(history, "agent_id", None)
        self.configure_session_storage(
            session_storage_root=storage_root,
            session_id=str(session_id) if session_id else None,
        )

    def _session_pact_file_path(self) -> Path | None:
        root = self._session_storage_root
        session_id = self._session_id or self.agent_id
        if root is None or not session_id:
            return None
        return root / str(session_id) / "pact" / "session.pact"

    def _ensure_pact_file_bound(self, *, create: bool = False) -> Path | None:
        path = self._session_pact_file_path()
        if path is None:
            return None
        if self._pact_file_path == path and path.exists():
            return path
        path.parent.mkdir(parents=True, exist_ok=True)
        if create and not path.exists():
            pact_file_create(str(path), self._resolver.root_store(), blob_inline_limit=1024)
        if path.exists():
            self._resolver.bind_file(str(path))
            self._pact_file_path = path
        return path

    def _set_hooks(self, hooks: Any, agent_id: str | None = None) -> None:
        self._hooks = hooks
        if agent_id:
            self.agent_id = agent_id

    def queue_injection(self, *_: Any, **__: Any) -> None:
        return None

    def drain_injections(self) -> list[Any]:
        return []

    def set_token_counter(self, *_: Any, **__: Any) -> None:
        return None

    def register_reactive_scaffold(self, *_: Any, **__: Any) -> None:
        return None

    def _env(self, source: str = "host", *, aux: dict[str, Any] | None = None) -> dict[str, Any]:
        return {
            "branch_id": self.branch_id,
            "source": source,
            "source_id": self.agent_id,
            "host_timestamp_ns": time.time_ns(),
            "idempotency_key": None,
            "aux": aux or {},
        }

    def _submit_ops(self, ops: list[dict[str, Any]]) -> None:
        self._ensure_pact_file_bound(create=True)
        outcome = self._resolver.submit(ops)
        rejected = outcome.get("rejected") or []
        if rejected:
            reasons = "; ".join(str(item.get("reason") or item) for item in rejected)
            raise RuntimeError(reasons)

    @staticmethod
    def _boundary(trigger: str) -> str:
        text = str(trigger or "")
        if "before_provider" in text or "pre_request" in text:
            return "pre_request"
        if "after_provider" in text or "post_response" in text:
            return "post_response"
        if text in {
            "authored",
            "pre_request",
            "post_request_alteration",
            "request",
            "response",
            "post_response_alteration",
            "post_response",
            "adhoc",
        }:
            return text
        return "adhoc"

    def _new_id(self, prefix: str) -> str:
        self._sequence += 1
        return f"{prefix}_{self._sequence:08x}"

    def _component_text(self, component: Any) -> str:
        if isinstance(component, str):
            return component
        value = getattr(component, "content", None)
        if value is None:
            return ""
        return value if isinstance(value, str) else str(value)

    def _node_payload(self, component: Any) -> dict[str, Any]:
        if isinstance(component, PACTCore):
            return component.model_dump(exclude_none=True)
        if isinstance(component, dict):
            return {key: value for key, value in component.items() if value is not None}
        return TextContent(content=str(component)).model_dump(exclude_none=True)

    def _component_for_update_result(self, component: Any, node: dict[str, Any]) -> Any:
        if hasattr(component, "id"):
            return component
        if (node.get("nodeType") or node.get("type")) == "text_content":
            return TextContent(id=str(node.get("id")), content=str(node.get("content") or ""))
        return PACTNode(id=str(node.get("id")), content=str(node.get("content") or ""))

    @staticmethod
    def _is_tool_component(component: Any) -> bool:
        node_type = getattr(component, "type", None)
        return node_type in {"tool_call", "scaffold_call", "tool_result", "scaffold_result"}

    @staticmethod
    def _is_tool_call(component: Any) -> bool:
        return getattr(component, "type", None) in {"tool_call", "scaffold_call"} or (
            hasattr(component, "tool_call_id") and hasattr(component, "parameters")
        )

    @staticmethod
    def _is_tool_result(component: Any) -> bool:
        return getattr(component, "type", None) in {"tool_result", "scaffold_result"} or (
            hasattr(component, "tool_call_id") and hasattr(component, "success")
        )

    def _add_message_batch(self, role: str, contents: Iterable[Any]) -> UpdateResult:
        components = list(contents or [])
        if not components:
            return UpdateResult()
        message_aux: dict[str, Any] = {}
        for component in components:
            metadata = getattr(component, "metadata", None)
            aux = getattr(metadata, "aux", None) if metadata is not None else None
            merge_provider_echo_from_aux(message_aux, aux)
        text_parts = [
            self._component_text(component)
            for component in components
            if not self._is_tool_component(component) and self._component_text(component)
        ]
        text = "\n".join(text_parts) if text_parts else None
        ops = [
            {
                "kind": "add_message",
                "envelope": self._env(
                    "user" if role == "user" else "assistant",
                    aux=message_aux,
                ),
                "role": role,
                "text": text,
                "content_ref": None,
            }
        ]
        seen_tool_calls: set[str] = set()
        seen_tool_results: set[str] = set()
        for component in components:
            if self._is_tool_call(component):
                call_id = str(getattr(component, "tool_call_id"))
                if call_id in seen_tool_calls:
                    continue
                seen_tool_calls.add(call_id)
                ops.append(
                    {
                        "kind": "tool_call_started",
                        "envelope": self._env("assistant"),
                        "tool_call_id": call_id,
                        "tool_name": str(getattr(component, "tool_name")),
                        "parameters": getattr(component, "parameters", {}) or {},
                    }
                )
            elif self._is_tool_result(component):
                call_id = str(getattr(component, "tool_call_id"))
                if call_id in seen_tool_results:
                    continue
                seen_tool_results.add(call_id)
                content = self._component_text(component)
                ops.append(
                    {
                        "kind": "tool_result_attached",
                        "envelope": self._env("host"),
                        "tool_call_id": call_id,
                        "tool_name": str(getattr(component, "tool_name", "") or ""),
                        "result_text": content,
                        "result_ref": None,
                        "success": bool(getattr(component, "success", True)),
                    }
                )
        self._submit_ops(ops)
        for component in components:
            component_id = getattr(component, "id", None)
            if component_id:
                self._node_cache[str(component_id)] = component
        self._current_episode += 1
        return UpdateResult(updated_components=components)

    def add_system(self, content: Any) -> UpdateResult:
        return self._add_message_batch("system", [content])

    def add_user(self, content: Any) -> UpdateResult:
        return self._add_message_batch("user", [content])

    def add_user_batch(self, contents: Iterable[Any]) -> UpdateResult:
        return self._add_message_batch("user", contents)

    def add_assistant(self, content: Any) -> UpdateResult:
        return self._add_message_batch("assistant", [content])

    def add_assistant_batch(self, contents: Iterable[Any]) -> UpdateResult:
        return self._add_message_batch("assistant", contents)

    def pact_insert(self, selector: Any, component: Any) -> UpdateResult:
        if self._is_tool_result(component):
            return self.add_user(component)
        if self._is_tool_call(component):
            return self.add_assistant(component)
        node = self._node_payload(component)
        node.setdefault("id", self._new_id("node"))
        node.setdefault("nodeType", node.get("type") or "pact_node")
        node.setdefault("type", node.get("nodeType") or "pact_node")
        self._submit_ops(
            [
                {
                    "kind": "insert_node",
                    "envelope": self._env("host", aux={"selector": str(selector)}),
                    "target_selector": str(selector),
                    "node": node,
                }
            ]
        )
        stored_component = self._component_for_update_result(component, node)
        self._node_cache[str(node["id"])] = stored_component
        return UpdateResult(updated_components=[stored_component])

    insert = pact_insert

    def pact_update(self, selector_or_component: Any, component: Any = None, mode: str = "replace", **_: Any) -> UpdateResult:
        target = component if component is not None else selector_or_component
        if self._is_tool_result(target):
            return self.add_user(target)
        if self._is_tool_call(target):
            return self.add_assistant(target)
        node = self._node_payload(target)
        node.setdefault("id", getattr(target, "id", None) or self._new_id("node"))
        node.setdefault("nodeType", node.get("type") or "pact_node")
        node.setdefault("type", node.get("nodeType") or "pact_node")
        selector = str(selector_or_component)
        kind = "append_node" if mode == "append" else "replace_node"
        op: dict[str, Any] = {
            "kind": kind,
            "envelope": self._env("host", aux={"selector": selector, "mode": mode}),
            "target_selector": selector,
            "node": node,
        }
        if mode == "append":
            offset = getattr(target, "offset", None)
            if offset is not None:
                op["offset"] = int(offset)
        self._submit_ops([op])
        stored_component = self._component_for_update_result(target, node)
        self._node_cache[str(node["id"])] = stored_component
        return UpdateResult(updated_components=[stored_component])

    update = pact_update

    def pact_delete(self, selector_or_component: Any) -> UpdateResult:
        target_id = getattr(selector_or_component, "id", None)
        op: dict[str, Any] = {
            "kind": "delete_subtree",
            "envelope": self._env("host"),
        }
        if target_id:
            op["target_node_id"] = str(target_id)
        else:
            op["target_selector"] = str(selector_or_component)
        self._submit_ops([op])
        return UpdateResult()

    delete = pact_delete

    def select(self, selector: str, trace_checkpoint: Optional[str] = None) -> list[Any]:
        tree = self._resolver.preview(branch_id=self.branch_id)
        selector_text = str(selector)
        nodes = select_pact_subtrees(tree, selector_text)
        if not nodes and "+tool_call" in selector_text:
            nodes = select_pact_subtrees(tree, "+tool_call")
        if not nodes and "+tool_result" in selector_text:
            nodes = select_pact_subtrees(tree, "+tool_result")
        return [self._component_from_node(node) for node in nodes]

    def _walk(self, node: Any):
        if isinstance(node, dict):
            yield node
            for child in node.get("children") or []:
                yield from self._walk(child)
        elif isinstance(node, list):
            for item in node:
                yield from self._walk(item)

    def _component_from_node(self, node: dict[str, Any]) -> Any:
        cached = self._node_cache.get(str(node.get("id")))
        if cached is not None:
            return cached
        kind = node.get("nodeType") or node.get("type")
        if kind == "tool_call":
            from egregore.core.tool_calling.context_components import ToolCall

            attrs = node.get("attrs") if isinstance(node.get("attrs"), dict) else {}
            return ToolCall(
                id=str(node.get("id")),
                tool_call_id=str(node.get("tool_call_id") or attrs.get("tool_call_id") or ""),
                tool_name=str(node.get("tool_name") or attrs.get("tool_name") or ""),
                parameters=node.get("parameters") or attrs.get("parameters") or {},
            )
        if kind == "tool_result":
            from egregore.core.tool_calling.context_components import ToolResult

            attrs = node.get("attrs") if isinstance(node.get("attrs"), dict) else {}
            return ToolResult(
                id=str(node.get("id")),
                tool_call_id=str(node.get("tool_call_id") or attrs.get("tool_call_id") or ""),
                tool_name=str(node.get("tool_name") or attrs.get("tool_name") or ""),
                success=bool(node.get("success", attrs.get("success", True))),
                content=str(node.get("content") or node.get("result") or attrs.get("result") or ""),
            )
        if kind == "text_content":
            return TextContent(id=str(node.get("id")), content=node.get("content") or "")
        return PACTNode(
            id=str(node.get("id")),
            content=node.get("content") or "",
            attrs=node.get("attrs") if isinstance(node.get("attrs"), dict) else {},
        )

    def render(self, **_: Any) -> str:
        thread = self.pact_build_provider_thread(include_partial_tool_calls=True, fail_on_orphan_tool_calls=False)
        return str(thread)

    def render_to_thread(self, provider_surface: Any = None):
        from egregore.core.messaging import ProviderThread

        return ProviderThread.model_validate(
            self.pact_build_provider_thread(include_partial_tool_calls=True, fail_on_orphan_tool_calls=False)
        )

    def to_pact(self) -> dict[str, Any] | list[Any]:
        return self._resolver.preview(branch_id=self.branch_id)

    def _native_pact_root(self) -> dict[str, Any]:
        return self._resolver.root_store()

    def pact_native_preview(self) -> dict[str, Any] | list[Any]:
        return self._resolver.preview(branch_id=self.branch_id)

    def pact_native_root_store(self) -> dict[str, Any]:
        return self._resolver.root_store()

    def pact_commit_boundary(self, boundary: str = "adhoc") -> dict[str, Any] | None:
        return self._resolver.commit_staged(self.branch_id, self._boundary(boundary))

    def pact_list_components(self, *, kind: str | None = None) -> list[dict[str, Any]]:
        return self._resolver.list_components(kind=kind)

    def pact_component_payload_for_ref(self, ref_id: str) -> dict[str, Any] | None:
        return self._resolver.component_payload_for_ref(ref_id)

    def pact_component_current_payload(self, component_id: str) -> dict[str, Any] | None:
        return self._resolver.component_current_state_payload(component_id)

    def pact_component_projection(self, component_id: str) -> dict[str, Any] | None:
        return self._resolver.component_current_projection_payload(component_id)

    def pact_attach_notification(self, *_: Any, **__: Any) -> None:
        return None

    def seal(self, trigger: str = "context_seal", flush: bool = False) -> str:
        self._ensure_pact_file_bound(create=True)
        self._resolver.resolve(self.branch_id, self._boundary(trigger))
        return f"trace_{time.time_ns():x}"

    def pact_build_provider_thread(
        self,
        *,
        include_partial_tool_calls: bool = False,
        fail_on_orphan_tool_calls: bool = True,
    ) -> dict[str, Any]:
        return self._resolver.build_provider_thread(
            self.branch_id,
            include_partial_tool_calls=include_partial_tool_calls,
            fail_on_orphan_tool_calls=fail_on_orphan_tool_calls,
        )

    def pact_commit_provider_surface(
        self,
        boundary: str = "provider_surface",
        *,
        include_partial_tool_calls: bool = False,
        fail_on_orphan_tool_calls: bool = True,
    ) -> dict[str, Any]:
        self._ensure_pact_file_bound(create=True)
        return self._resolver.commit_provider_surface(
            self.branch_id,
            self._boundary(boundary),
            include_partial_tool_calls=include_partial_tool_calls,
            fail_on_orphan_tool_calls=fail_on_orphan_tool_calls,
        )

    def pact_record_tool_lifecycle(self, *_: Any, **__: Any) -> None:
        return None

    def pact_enforce_replace_retention(self, *_: Any, **__: Any) -> int:
        return 0

    def pact_invalidate_scaffold_renders(self, *_: Any, **__: Any) -> None:
        return None

    def pact_flush_scaffold_renders(self, *_: Any, **__: Any) -> None:
        return None

    def pact_record_auxiliary_state(self, *_: Any, **__: Any) -> None:
        return None

    def pact_record_trace_boundary(self, *_: Any, **__: Any) -> None:
        return None


__all__ = ["Context", "UpdateResult"]
