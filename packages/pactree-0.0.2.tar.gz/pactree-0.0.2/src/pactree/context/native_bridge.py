"""Compatibility import for the Rust PACT resolver.

The old Python bridge authority was removed. `PactContextBridge` is now only a
thin alias used by host code that has not renamed its import yet.
"""

from __future__ import annotations

from ..native import NativeResolver


class PactContextBridge(NativeResolver):
    pass


__all__ = ["PactContextBridge"]
