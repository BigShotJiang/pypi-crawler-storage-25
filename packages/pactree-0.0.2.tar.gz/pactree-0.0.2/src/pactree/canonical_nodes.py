"""Rust-owned canonical PACT node classes.

Python gets ergonomic dataclasses, but Rust owns the grammar: every public
class materializes by calling the native PACT constructor/validator.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, ClassVar, Mapping

from .native import pact_canonical_node, pact_canonical_node_kinds


def canonical_node_kinds() -> tuple[str, ...]:
    return pact_canonical_node_kinds()


def _drop_none(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


_BASE_NODE_FIELDS = {
    "id",
    "nodeType",
    "node_type",
    "type",
    "parent_id",
    "role",
    "offset",
    "pact_depth",
    "priority",
    "transaction_index",
    "created_at_ns",
    "created_at_iso",
    "creation_index",
    "attrs",
    "org",
    "surface",
    "content",
    "content_ref",
    "provenance",
    "children",
}


_CANONICAL_CLASS_BY_KIND: dict[str, type["PACTNode"]] = {}


def _payload_slot(payload: Mapping[str, Any], key: str) -> Any:
    if key in payload:
        return payload[key]
    attrs = payload.get("attrs")
    if isinstance(attrs, Mapping):
        return attrs.get(key)
    return None


def _base_kwargs(payload: Mapping[str, Any]) -> dict[str, Any]:
    kwargs: dict[str, Any] = {}
    extra: dict[str, Any] = {}
    for key, value in payload.items():
        if key == "nodeType":
            kwargs["nodeType"] = value
        elif key in _BASE_NODE_FIELDS:
            kwargs[key] = value
        else:
            extra[key] = value
    if extra:
        kwargs["extra"] = extra
    return kwargs


def node_from_payload(kind: str, payload: Mapping[str, Any]) -> "PACTNode":
    """Build a Python canonical node from a JSON-shaped payload.

    This keeps the Python side idiomatic while still delegating the grammar and
    validation to Rust when the node is materialized.
    """

    if not isinstance(payload, Mapping):
        raise TypeError("canonical PACT node payload must be a mapping")

    cls = _CANONICAL_CLASS_BY_KIND.get(kind) or _CANONICAL_CLASS_BY_KIND.get(
        str(payload.get("nodeType") or payload.get("node_type") or payload.get("type") or "")
    )
    if cls is None:
        cls = PACTNode

    kwargs = _base_kwargs(payload)
    if cls is ToolCall:
        for key in ("tool_call_id", "tool_name", "parameters"):
            value = _payload_slot(payload, key)
            if value is not None:
                kwargs[key] = value
    elif cls is ToolResult:
        for key in ("tool_call_id", "tool_name", "success", "result", "error_message"):
            value = _payload_slot(payload, key)
            if value is not None:
                kwargs[key] = value
    return cls(**kwargs)


@dataclass(kw_only=True)
class PACTNode:
    """Generic PACT escape hatch.

    Use this for host/app extension nodes. Typed classes below are preferred
    for canonical provider-visible nodes.
    """

    KIND: ClassVar[str] = "PACTNode"

    id: str
    nodeType: str | None = None
    node_type: str | None = None
    type: str | None = None
    parent_id: str | None = None
    role: str | None = None
    offset: int | None = None
    pact_depth: int | None = None
    priority: int | None = None
    transaction_index: int | None = None
    created_at_ns: int | None = None
    created_at_iso: str | None = None
    creation_index: int | None = None
    attrs: dict[str, Any] | None = None
    org: dict[str, Any] | None = None
    surface: dict[str, Any] | None = None
    content: str | None = None
    content_ref: str | dict[str, Any] | None = None
    provenance: dict[str, Any] | None = None
    children: list[PACTNode | dict[str, Any]] | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_payload(self) -> dict[str, Any]:
        payload = _drop_none(
            {
                "id": self.id,
                "nodeType": self.nodeType or self.node_type or self.type,
                "type": self.type,
                "parent_id": self.parent_id,
                "role": self.role,
                "offset": self.offset,
                "pact_depth": self.pact_depth,
                "priority": self.priority,
                "transaction_index": self.transaction_index,
                "created_at_ns": self.created_at_ns,
                "created_at_iso": self.created_at_iso,
                "creation_index": self.creation_index,
                "attrs": self.attrs,
                "org": self.org,
                "surface": self.surface,
                "content": self.content,
                "content_ref": self.content_ref,
                "provenance": self.provenance,
                "children": [
                    child.to_dict() if isinstance(child, PACTNode) else child
                    for child in self.children
                ]
                if self.children is not None
                else None,
            }
        )
        payload.update(self.extra)
        return payload

    def to_dict(self) -> dict[str, Any]:
        return pact_canonical_node(self.KIND, self.to_payload())

    def __getitem__(self, key: str) -> Any:
        return self.to_dict()[key]


@dataclass(kw_only=True)
class PactRoot(PACTNode):
    KIND: ClassVar[str] = "PactRoot"


@dataclass(kw_only=True)
class SystemHeader(PACTNode):
    KIND: ClassVar[str] = "SystemHeader"


@dataclass(kw_only=True)
class ConversationHistory(PACTNode):
    KIND: ClassVar[str] = "ConversationHistory"


@dataclass(kw_only=True)
class ActiveMessage(PACTNode):
    KIND: ClassVar[str] = "ActiveMessage"


@dataclass(kw_only=True)
class MessageTurn(PACTNode):
    KIND: ClassVar[str] = "MessageTurn"


@dataclass(kw_only=True)
class MessageContainer(PACTNode):
    KIND: ClassVar[str] = "MessageContainer"


@dataclass(kw_only=True)
class TextContent(PACTNode):
    KIND: ClassVar[str] = "TextContent"


@dataclass(kw_only=True)
class ImageContent(PACTNode):
    KIND: ClassVar[str] = "ImageContent"


@dataclass(kw_only=True)
class AudioContent(PACTNode):
    KIND: ClassVar[str] = "AudioContent"


@dataclass(kw_only=True)
class VideoContent(PACTNode):
    KIND: ClassVar[str] = "VideoContent"


@dataclass(kw_only=True)
class DocumentContent(PACTNode):
    KIND: ClassVar[str] = "DocumentContent"


@dataclass(kw_only=True)
class ToolCall(PACTNode):
    KIND: ClassVar[str] = "ToolCall"

    tool_call_id: str
    tool_name: str
    parameters: dict[str, Any]

    def to_payload(self) -> dict[str, Any]:
        payload = super().to_payload()
        payload.update(
            {
                "tool_call_id": self.tool_call_id,
                "tool_name": self.tool_name,
                "parameters": self.parameters,
            }
        )
        return payload


@dataclass(kw_only=True)
class ToolResult(PACTNode):
    KIND: ClassVar[str] = "ToolResult"

    tool_call_id: str
    tool_name: str
    success: bool
    result: Any = None
    error_message: str | None = None

    def to_payload(self) -> dict[str, Any]:
        payload = super().to_payload()
        payload.update(
            _drop_none(
                {
                    "tool_call_id": self.tool_call_id,
                    "tool_name": self.tool_name,
                    "success": self.success,
                    "result": self.result,
                    "error_message": self.error_message,
                }
            )
        )
        return payload


_CANONICAL_CLASS_BY_KIND.update(
    {
        "PACTNode": PACTNode,
        "pact_node": PACTNode,
        "PactRoot": PactRoot,
        "root": PactRoot,
        "SystemHeader": SystemHeader,
        "system_header": SystemHeader,
        "ConversationHistory": ConversationHistory,
        "conversation_history": ConversationHistory,
        "ActiveMessage": ActiveMessage,
        "active_message": ActiveMessage,
        "MessageTurn": MessageTurn,
        "message_turn": MessageTurn,
        "MessageContainer": MessageContainer,
        "message_container": MessageContainer,
        "TextContent": TextContent,
        "text_content": TextContent,
        "ImageContent": ImageContent,
        "image_content": ImageContent,
        "AudioContent": AudioContent,
        "audio_content": AudioContent,
        "VideoContent": VideoContent,
        "video_content": VideoContent,
        "DocumentContent": DocumentContent,
        "document_content": DocumentContent,
        "ToolCall": ToolCall,
        "tool_call": ToolCall,
        "ToolResult": ToolResult,
        "tool_result": ToolResult,
    }
)


__all__ = [
    "PACTNode",
    "PactRoot",
    "SystemHeader",
    "ConversationHistory",
    "ActiveMessage",
    "MessageTurn",
    "MessageContainer",
    "TextContent",
    "ImageContent",
    "AudioContent",
    "VideoContent",
    "DocumentContent",
    "ToolCall",
    "ToolResult",
    "canonical_node_kinds",
    "node_from_payload",
]
