"""Hash helpers for PACT-derived projection payloads."""

from __future__ import annotations

import json
from hashlib import sha256
from typing import Any


def projection_payload(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, dict):
        return {str(key): projection_payload(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [projection_payload(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)


def projection_hash(value: Any) -> str:
    payload = projection_payload(value)
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return sha256(encoded.encode("utf-8")).hexdigest()


def projection_token_estimate(value: Any) -> int:
    payload = projection_payload(value)
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return max(1, (len(encoded) + 3) // 4) if encoded else 0


__all__ = ["projection_hash", "projection_payload", "projection_token_estimate"]
