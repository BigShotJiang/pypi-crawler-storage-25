"""Transitional Python surface for the Rust PACT core.

The canonical PACT substrate lives in Rust. This PyO3-backed module exists so
the current Python runtime can call the Rust engine while the runtime migrates.
It is not the release boundary: released PACT workflows should operate through
the native `.pact` file/binary surface, with Python as an optional host.
"""

from __future__ import annotations

import json
from datetime import date, datetime, time
from typing import Any


def _json_default(value: Any) -> Any:
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, set):
        return sorted(value, key=repr)
    if isinstance(value, tuple):
        return list(value)
    if value.__class__.__name__ == "Pos" and isinstance(getattr(value, "selector", None), str):
        return value.selector
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return value.to_dict()
    if hasattr(value, "model_dump"):
        return value.model_dump()
    raise TypeError(f"Object of type {value.__class__.__name__} is not JSON serializable")


def _json_safe_key(value: Any) -> str | int | float | bool | None:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, tuple):
        return json.dumps(_json_safe(value), ensure_ascii=False, separators=(",", ":"))
    return str(value)


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {_json_safe_key(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, set):
        return [_json_safe(item) for item in sorted(value, key=repr)]
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if value.__class__.__name__ == "Pos" and isinstance(getattr(value, "selector", None), str):
        return value.selector
    if callable(value):
        name = getattr(value, "__qualname__", None) or getattr(value, "__name__", None)
        return f"<callable:{name or type(value).__name__}>"
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return _json_safe(value.to_dict())
    if hasattr(value, "model_dump"):
        return _json_safe(value.model_dump())
    return value


def _pact_json(pact_tree: dict[str, Any] | list[Any] | str) -> str:
    if isinstance(pact_tree, str):
        return pact_tree
    return json.dumps(_json_safe(pact_tree), ensure_ascii=False, separators=(",", ":"), default=_json_default)


class _AttrDict(dict):
    """Dict with attribute access for legacy runtime smoke probes."""

    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc


def _resolver_outcome(payload: dict[str, Any]) -> _AttrDict:
    payload.setdefault("views", {})
    payload.setdefault("component_transactions", [])
    return _AttrDict(payload)


def _component_json(component: Any) -> str:
    if isinstance(component, str):
        return component
    if isinstance(component, dict):
        return _pact_json(component)
    if hasattr(component, "to_canonical_node") and callable(component.to_canonical_node):
        return _pact_json(component.to_canonical_node().to_dict())
    if hasattr(component, "to_dict") and callable(component.to_dict):
        return _pact_json(component.to_dict())
    if hasattr(component, "model_dump"):
        return _pact_json(component.model_dump())
    raise TypeError(
        "unsupported PACT component boundary object: expected canonical PACT node, "
        f"dict, JSON string, or object with model_dump(), got {type(component).__name__}"
    )


def _native_module():
    try:
        from egregore import _native
    except Exception as exc:  # pragma: no cover - depends on build artifact
        raise RuntimeError(
            "the Pactree engine is unavailable; install a Pactree release with "
            "the Rust engine binary or set PACTREE_BIN"
        ) from exc
    return _native


def normalize_pact_tree(
    pact_tree: dict[str, Any] | list[Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    normalized_json = _native_module().normalize_pact_tree(
        _pact_json(pact_tree),
        blob_inline_limit,
    )
    normalized = json.loads(normalized_json)
    if not isinstance(normalized, dict):
        raise ValueError("native PACT normalizer returned a non-object payload")
    return normalized


def select_pact_tree(
    pact_tree: dict[str, Any] | list[Any] | str,
    selector: str,
) -> list[dict[str, Any]]:
    selected_json = _native_module().select_pact_tree(_pact_json(pact_tree), selector)
    selected = json.loads(selected_json)
    if not isinstance(selected, list):
        raise ValueError("native PACT selector returned a non-list payload")
    return selected


def select_pact_subtrees(
    pact_tree: dict[str, Any] | list[Any] | str,
    selector: str,
) -> list[dict[str, Any]]:
    selected_json = _native_module().select_pact_subtrees(_pact_json(pact_tree), selector)
    selected = json.loads(selected_json)
    if not isinstance(selected, list):
        raise ValueError("native PACT subtree selector returned a non-list payload")
    return selected


def render_pact_tree_xml(pact_tree: dict[str, Any] | list[Any] | str) -> str:
    rendered = _native_module().render_pact_tree_xml(_pact_json(pact_tree))
    if not isinstance(rendered, str):
        raise ValueError("native PACT renderer returned a non-string payload")
    return rendered


def delete_pact_tree(
    pact_tree: dict[str, Any] | list[Any] | str,
    selector: str,
) -> dict[str, Any]:
    deleted_json = _native_module().delete_pact_tree(_pact_json(pact_tree), selector)
    deleted = json.loads(deleted_json)
    if not isinstance(deleted, dict):
        raise ValueError("native PACT delete returned a non-object payload")
    return deleted


def pact_mutation_request_validate(request: dict[str, Any] | str) -> dict[str, Any]:
    request_json = _native_module().pact_mutation_request_validate(_pact_json(request))
    validated = json.loads(request_json)
    if not isinstance(validated, dict):
        raise ValueError("native PACT mutation request validator returned a non-object payload")
    return validated


def pact_operation_report_validate(report: dict[str, Any] | str) -> dict[str, Any]:
    report_json = _native_module().pact_operation_report_validate(_pact_json(report))
    validated = json.loads(report_json)
    if not isinstance(validated, dict):
        raise ValueError("native PACT operation report validator returned a non-object payload")
    return validated


def pact_node_from_component(component: Any) -> dict[str, Any]:
    node_json = _native_module().pact_node_from_component(_component_json(component))
    node = json.loads(node_json)
    if not isinstance(node, dict):
        raise ValueError("native PACT node conversion returned a non-object payload")
    return node


def pact_canonical_node_kinds() -> tuple[str, ...]:
    kinds_json = _native_module().pact_canonical_node_kinds()
    kinds = json.loads(kinds_json)
    if not isinstance(kinds, list) or not all(isinstance(item, str) for item in kinds):
        raise ValueError("native PACT canonical node kind list returned a malformed payload")
    return tuple(kinds)


def pact_canonical_node(kind: str, payload: dict[str, Any] | str) -> dict[str, Any]:
    node_json = _native_module().pact_canonical_node(kind, _pact_json(payload))
    node = json.loads(node_json)
    if not isinstance(node, dict):
        raise ValueError("native PACT canonical node constructor returned a non-object payload")
    return node


def pact_node_prepare_for_context(
    component: Any,
    context: dict[str, Any] | str,
) -> dict[str, Any]:
    prepared_json = _native_module().pact_node_prepare_for_context(
        _component_json(component),
        _pact_json(context),
    )
    prepared = json.loads(prepared_json)
    if not isinstance(prepared, dict) or not isinstance(prepared.get("node"), dict):
        raise ValueError("native PACT node preparation returned a malformed payload")
    return prepared


def pact_node_project(node: dict[str, Any] | str) -> dict[str, Any]:
    projected_json = _native_module().pact_node_project(_pact_json(node))
    projected = json.loads(projected_json)
    if not isinstance(projected, dict):
        raise ValueError("native PACT node projection returned a non-object payload")
    return projected


def pact_store_new(
    pact_tree: dict[str, Any] | list[Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    store_json = _native_module().pact_store_new(
        _pact_json(pact_tree),
        blob_inline_limit,
    )
    store = json.loads(store_json)
    if not isinstance(store, dict):
        raise ValueError("native PACT store returned a non-object payload")
    return store


def pact_root_store_new(
    pact_tree: dict[str, Any] | list[Any] | str,
    *,
    branch_id: str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    root_store_json = _native_module().pact_root_store_new(
        _pact_json(pact_tree),
        branch_id,
        blob_inline_limit,
    )
    root_store = json.loads(root_store_json)
    if not isinstance(root_store, dict):
        raise ValueError("native PACT root store returned a non-object payload")
    return root_store


def pact_root_store_from_store(
    store: dict[str, Any] | str,
    *,
    branch_id: str | None = None,
) -> dict[str, Any]:
    root_store_json = _native_module().pact_root_store_from_store(
        _pact_json(store),
        branch_id,
    )
    root_store = json.loads(root_store_json)
    if not isinstance(root_store, dict):
        raise ValueError("native PACT root store conversion returned a non-object payload")
    return root_store


def pact_root_store_fork_at_revision(
    root_store: dict[str, Any] | str,
    *,
    from_branch_id: str,
    revision: int | None = None,
    new_branch_id: str | None = None,
    aux: dict[str, Any] | str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    aux_json = _pact_json(aux) if aux is not None else None
    root_store_json = _native_module().pact_root_store_fork_at_revision(
        _pact_json(root_store),
        from_branch_id,
        revision,
        new_branch_id,
        aux_json,
        blob_inline_limit,
    )
    forked = json.loads(root_store_json)
    if not isinstance(forked, dict):
        raise ValueError("native PACT root store fork returned a non-object payload")
    return forked


def pact_root_store_fork_at_node(
    root_store: dict[str, Any] | str,
    *,
    from_branch_id: str,
    node_id: str,
    new_branch_id: str | None = None,
    aux: dict[str, Any] | str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    aux_json = _pact_json(aux) if aux is not None else None
    root_store_json = _native_module().pact_root_store_fork_at_node(
        _pact_json(root_store),
        from_branch_id,
        node_id,
        new_branch_id,
        aux_json,
        blob_inline_limit,
    )
    forked = json.loads(root_store_json)
    if not isinstance(forked, dict):
        raise ValueError("native PACT root store node fork returned a non-object payload")
    return forked


def pact_root_store_record_transaction_trace(
    root_store: dict[str, Any] | str,
    trace: dict[str, Any] | str,
) -> dict[str, Any]:
    root_store_json = _native_module().pact_root_store_record_transaction_trace(
        _pact_json(root_store),
        _pact_json(trace),
    )
    updated = json.loads(root_store_json)
    if not isinstance(updated, dict):
        raise ValueError("native PACT root store transaction record returned a non-object payload")
    return updated


def pact_root_store_fork_at_transaction(
    root_store: dict[str, Any] | str,
    *,
    from_branch_id: str,
    transaction_id: str,
    new_branch_id: str | None = None,
    aux: dict[str, Any] | str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    aux_json = _pact_json(aux) if aux is not None else None
    root_store_json = _native_module().pact_root_store_fork_at_transaction(
        _pact_json(root_store),
        from_branch_id,
        transaction_id,
        new_branch_id,
        aux_json,
        blob_inline_limit,
    )
    forked = json.loads(root_store_json)
    if not isinstance(forked, dict):
        raise ValueError("native PACT root store transaction fork returned a non-object payload")
    return forked


def pact_root_store_materialize_branch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
    revision: int | None = None,
) -> dict[str, Any]:
    materialized_json = _native_module().pact_root_store_materialize_branch(
        _pact_json(root_store),
        branch_id,
        revision,
    )
    materialized = json.loads(materialized_json)
    if not isinstance(materialized, dict):
        raise ValueError("native PACT branch materialize returned a non-object payload")
    return materialized


def pact_root_store_project_branch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    view_json = _native_module().pact_root_store_project_branch(
        _pact_json(root_store),
        branch_id,
        revision,
        blob_inline_limit,
    )
    view = json.loads(view_json)
    if not isinstance(view, dict):
        raise ValueError("native PACT branch project returned a non-object payload")
    return view


def pact_root_store_inspect(root_store: dict[str, Any] | str) -> dict[str, Any]:
    inspect_json = _native_module().pact_root_store_inspect(_pact_json(root_store))
    inspection = json.loads(inspect_json)
    if not isinstance(inspection, dict):
        raise ValueError("native PACT root inspect returned a non-object payload")
    return inspection


def pact_root_store_inspect_branch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
) -> dict[str, Any]:
    inspect_json = _native_module().pact_root_store_inspect_branch(
        _pact_json(root_store),
        branch_id,
    )
    inspection = json.loads(inspect_json)
    if not isinstance(inspection, dict):
        raise ValueError("native PACT branch inspect returned a non-object payload")
    return inspection


def pact_root_store_append_branch_patch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
    patch: dict[str, Any] | str,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    updated_json = _native_module().pact_root_store_append_branch_patch(
        _pact_json(root_store),
        branch_id,
        _pact_json(patch),
        blob_inline_limit,
    )
    updated = json.loads(updated_json)
    if not isinstance(updated, dict):
        raise ValueError("native PACT root branch append returned a non-object payload")
    return updated


def pact_store_append_patch(
    store: dict[str, Any] | str,
    patch: dict[str, Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    updated_json = _native_module().pact_store_append_patch(
        _pact_json(store),
        _pact_json(patch),
        blob_inline_limit,
    )
    updated = json.loads(updated_json)
    if not isinstance(updated, dict):
        raise ValueError("native PACT store append returned a non-object payload")
    return updated


def pact_store_materialize(
    store: dict[str, Any] | str,
    *,
    revision: int | None = None,
) -> dict[str, Any]:
    materialized_json = _native_module().pact_store_materialize(_pact_json(store), revision)
    materialized = json.loads(materialized_json)
    if not isinstance(materialized, dict):
        raise ValueError("native PACT store materialize returned a non-object payload")
    return materialized


def pact_store_checkpoint(
    store: dict[str, Any] | str,
    *,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    checkpoint_json = _native_module().pact_store_checkpoint(
        _pact_json(store),
        revision,
        blob_inline_limit,
    )
    checkpoint = json.loads(checkpoint_json)
    if not isinstance(checkpoint, dict):
        raise ValueError("native PACT store checkpoint returned a non-object payload")
    return checkpoint


def pact_store_fork(
    store: dict[str, Any] | str,
    *,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    forked_json = _native_module().pact_store_fork(
        _pact_json(store),
        revision,
        blob_inline_limit,
    )
    forked = json.loads(forked_json)
    if not isinstance(forked, dict):
        raise ValueError("native PACT store fork returned a non-object payload")
    return forked


def pact_content_store_put_inline(
    store: dict[str, Any] | str | None,
    *,
    kind: str,
    content: str,
    preview_chars: int = 160,
) -> dict[str, Any]:
    store_json = _pact_json(store) if store is not None else None
    content_store_json = _native_module().pact_content_store_put_inline(
        store_json,
        kind,
        content,
        preview_chars,
    )
    content_store = json.loads(content_store_json)
    if not isinstance(content_store, dict):
        raise ValueError("native PACT content store returned a non-object payload")
    return content_store


def pact_transaction_trace_validate(trace: dict[str, Any] | str) -> dict[str, Any]:
    trace_json = _native_module().pact_transaction_trace_validate(_pact_json(trace))
    validated = json.loads(trace_json)
    if not isinstance(validated, dict):
        raise ValueError("native PACT transaction trace returned a non-object payload")
    return validated


def pact_transaction_trace_build(request: dict[str, Any] | str) -> dict[str, Any]:
    trace_json = _native_module().pact_transaction_trace_build(_pact_json(request))
    trace = json.loads(trace_json)
    if not isinstance(trace, dict):
        raise ValueError("native PACT transaction trace builder returned a non-object payload")
    return trace


def pact_file_create(
    path: str,
    root_store: dict[str, Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    manifest_json = _native_module().pact_file_create(
        str(path),
        _pact_json(root_store),
        blob_inline_limit,
    )
    manifest = json.loads(manifest_json)
    if not isinstance(manifest, dict):
        raise ValueError("native PACT file create returned a non-object payload")
    return manifest


def pact_file_append_views(
    path: str,
    view_records: dict[str, Any] | list[Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    manifest_json = _native_module().pact_file_append_views(
        str(path),
        _pact_json(view_records),
        blob_inline_limit,
    )
    manifest = json.loads(manifest_json)
    if not isinstance(manifest, dict):
        raise ValueError("native PACT view append returned a non-object payload")
    return manifest


def pact_file_append_commit(
    path: str,
    commit: dict[str, Any] | str,
    node_records: list[Any] | str,
    content_store: dict[str, Any] | str | None = None,
) -> dict[str, Any]:
    if content_store is None:
        manifest_json = _native_module().pact_file_append_commit(
            str(path),
            _pact_json(commit),
            _pact_json(node_records),
        )
    else:
        manifest_json = _native_module().pact_file_append_commit_with_content(
            str(path),
            _pact_json(commit),
            _pact_json(node_records),
            _pact_json(content_store),
        )
    manifest = json.loads(manifest_json)
    if not isinstance(manifest, dict):
        raise ValueError("native PACT commit append returned a non-object payload")
    return manifest


def pact_file_append_trace(
    path: str,
    trace: dict[str, Any] | str,
) -> dict[str, Any]:
    manifest_json = _native_module().pact_file_append_trace(
        str(path),
        _pact_json(trace),
    )
    manifest = json.loads(manifest_json)
    if not isinstance(manifest, dict):
        raise ValueError("native PACT trace append returned a non-object payload")
    return manifest


def pact_file_append_content_manifest(
    path: str,
    manifest: dict[str, Any] | str,
) -> dict[str, Any]:
    manifest_json = _native_module().pact_file_append_content_manifest(
        str(path),
        _pact_json(manifest),
    )
    report = json.loads(manifest_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT content manifest append returned a non-object payload")
    return report


def pact_file_content_manifest_payload(path: str, manifest_id: str) -> dict[str, Any]:
    payload_json = _native_module().pact_file_content_manifest_payload(
        str(path),
        str(manifest_id),
    )
    payload = json.loads(payload_json)
    if not isinstance(payload, dict):
        raise ValueError("native PACT content manifest payload returned a non-object payload")
    return payload


def pact_file_content_payload(path: str, content_id: str) -> dict[str, Any]:
    payload_json = _native_module().pact_file_content_payload(
        str(path),
        str(content_id),
    )
    payload = json.loads(payload_json)
    if not isinstance(payload, dict):
        raise ValueError("native PACT content payload returned a non-object payload")
    return payload


def pact_file_inspect(path: str) -> dict[str, Any]:
    manifest_json = _native_module().pact_file_inspect(str(path))
    manifest = json.loads(manifest_json)
    if not isinstance(manifest, dict):
        raise ValueError("native PACT file inspect returned a non-object payload")
    return manifest


def pact_file_info(path: str) -> dict[str, Any]:
    info_json = _native_module().pact_file_info(str(path))
    info = json.loads(info_json)
    if not isinstance(info, dict):
        raise ValueError("native PACT file info returned a non-object payload")
    return info


def pact_file_validate(path: str) -> dict[str, Any]:
    validation_json = _native_module().pact_file_validate(str(path))
    validation = json.loads(validation_json)
    if not isinstance(validation, dict):
        raise ValueError("native PACT file validate returned a non-object payload")
    return validation


def pact_file_bundle_create(path: str) -> dict[str, Any]:
    report_json = _native_module().pact_file_bundle_create(str(path))
    report = json.loads(report_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT bundle create returned a non-object payload")
    return report


def pact_file_bundle_verify(path: str) -> dict[str, Any]:
    report_json = _native_module().pact_file_bundle_verify(str(path))
    report = json.loads(report_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT bundle verify returned a non-object payload")
    return report


def pact_file_bundle_export_full(path: str, output_path: str) -> dict[str, Any]:
    report_json = _native_module().pact_file_bundle_export_full(str(path), str(output_path))
    report = json.loads(report_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT bundle export returned a non-object payload")
    return report


def pact_file_bundle_prune(path: str) -> dict[str, Any]:
    report_json = _native_module().pact_file_bundle_prune(str(path))
    report = json.loads(report_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT bundle prune returned a non-object payload")
    return report


def pact_file_materialize(
    path: str,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
) -> dict[str, Any]:
    materialized_json = _native_module().pact_file_materialize(
        str(path),
        branch_id,
        revision,
    )
    materialized = json.loads(materialized_json)
    if not isinstance(materialized, dict):
        raise ValueError("native PACT file materialize returned a non-object payload")
    return materialized


def pact_file_projection(
    path: str,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
    view: str | None = None,
    component_id: str | None = None,
) -> dict[str, Any]:
    projection_json = _native_module().pact_file_projection(
        str(path),
        branch_id,
        revision,
        blob_inline_limit,
        view,
        component_id,
    )
    projection = json.loads(projection_json)
    if not isinstance(projection, dict):
        raise ValueError("native PACT file projection returned a non-object payload")
    return projection


def pact_file_project_range(
    path: str,
    range: str,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
    view: str | None = None,
    component_id: str | None = None,
) -> dict[str, Any]:
    projection_json = _native_module().pact_file_project_range(
        str(path),
        range,
        branch_id,
        revision,
        blob_inline_limit,
        view,
        component_id,
    )
    projection = json.loads(projection_json)
    if not isinstance(projection, dict):
        raise ValueError("native PACT file ranged projection returned a non-object payload")
    return projection


def pact_file_open(
    path: str,
    *,
    branch_id: str | None = None,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    opened_json = _native_module().pact_file_open(
        str(path),
        branch_id,
        revision,
        blob_inline_limit,
    )
    opened = json.loads(opened_json)
    if not isinstance(opened, dict):
        raise ValueError("native PACT file open returned a non-object payload")
    return opened


def pact_file_open_head_fast(path: str) -> dict[str, Any]:
    head_json = _native_module().pact_file_open_head_fast(str(path))
    head = json.loads(head_json)
    if not isinstance(head, dict):
        raise ValueError("native PACT fast head open returned a non-object payload")
    return head


def pact_file_cycles(path: str) -> dict[str, Any]:
    cycles_json = _native_module().pact_file_cycles(str(path))
    cycles = json.loads(cycles_json)
    if not isinstance(cycles, dict):
        raise ValueError("native PACT file cycles returned a non-object payload")
    return cycles


def pact_file_view_projection(
    path: str,
    view_id: str,
    *,
    blob_inline_limit: int = 1024,
    view: str | None = None,
    component_id: str | None = None,
) -> dict[str, Any]:
    projection_json = _native_module().pact_file_view_projection(
        str(path),
        view_id,
        blob_inline_limit,
        view,
        component_id,
    )
    projection = json.loads(projection_json)
    if not isinstance(projection, dict):
        raise ValueError("native PACT file view projection returned a non-object payload")
    return projection


def pact_file_view_query(
    path: str,
    view_id: str,
    query: str,
    *,
    key: str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    query_json = _native_module().pact_file_view_query(
        str(path),
        view_id,
        query,
        key,
        blob_inline_limit,
    )
    result = json.loads(query_json)
    if not isinstance(result, dict):
        raise ValueError("native PACT file view query returned a non-object payload")
    return result


def pact_file_view_merge_preflight(path: str, view_id: str) -> dict[str, Any]:
    preflight_json = _native_module().pact_file_view_merge_preflight(str(path), view_id)
    preflight = json.loads(preflight_json)
    if not isinstance(preflight, dict):
        raise ValueError("native PACT file view merge preflight returned a non-object payload")
    return preflight


def pact_file_view_merge(
    path: str,
    view_id: str,
    *,
    policy: str | None = None,
) -> dict[str, Any]:
    merge_json = _native_module().pact_file_view_merge(str(path), view_id, policy)
    merge = json.loads(merge_json)
    if not isinstance(merge, dict):
        raise ValueError("native PACT file view merge returned a non-object payload")
    return merge


def pact_file_view_detach(
    path: str,
    view_id: str,
    detached_branch_id: str,
) -> dict[str, Any]:
    manifest_json = _native_module().pact_file_view_detach(
        str(path),
        view_id,
        detached_branch_id,
    )
    manifest = json.loads(manifest_json)
    if not isinstance(manifest, dict):
        raise ValueError("native PACT file view detach returned a non-object payload")
    return manifest


def pact_file_view_rebase(
    path: str,
    view_id: str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    rebase_json = _native_module().pact_file_view_rebase(
        str(path),
        view_id,
        blob_inline_limit,
    )
    report = json.loads(rebase_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT file view rebase returned a non-object payload")
    return report


def pact_file_root_store(path: str) -> dict[str, Any]:
    root_store_json = _native_module().pact_file_root_store(str(path))
    root_store = json.loads(root_store_json)
    if not isinstance(root_store, dict):
        raise ValueError("native PACT file root-store reconstruction returned a non-object payload")
    return root_store


def pact_file_query(
    path: str,
    query: str,
    *,
    key: str | None = None,
) -> dict[str, Any]:
    query_json = _native_module().pact_file_query(str(path), query, key)
    result = json.loads(query_json)
    if not isinstance(result, dict):
        raise ValueError("native PACT file query returned a non-object payload")
    return result


def pact_file_repair(
    source_path: str,
    repaired_path: str,
    *,
    truncate_corrupt_tail: bool = False,
) -> dict[str, Any]:
    repair_json = _native_module().pact_file_repair(
        str(source_path),
        str(repaired_path),
        truncate_corrupt_tail,
    )
    report = json.loads(repair_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT file repair returned a non-object payload")
    return report


def pact_file_slice(
    source_path: str,
    output_path: str,
    spec: dict[str, Any] | str,
) -> dict[str, Any]:
    slice_json = _native_module().pact_file_slice(
        str(source_path),
        str(output_path),
        _pact_json(spec),
    )
    validation = json.loads(slice_json)
    if not isinstance(validation, dict):
        raise ValueError("native PACT file slice returned a non-object payload")
    return validation


def pact_file_import_check(path: str) -> dict[str, Any]:
    validation_json = _native_module().pact_file_import_check(str(path))
    validation = json.loads(validation_json)
    if not isinstance(validation, dict):
        raise ValueError("native PACT file import check returned a non-object payload")
    return validation


def pact_file_import(target_path: str, slice_path: str) -> dict[str, Any]:
    import_json = _native_module().pact_file_import(str(target_path), str(slice_path))
    report = json.loads(import_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT file import returned a non-object payload")
    return report


def pact_file_merge(target_path: str, slice_path: str) -> dict[str, Any]:
    merge_json = _native_module().pact_file_merge(str(target_path), str(slice_path))
    report = json.loads(merge_json)
    if not isinstance(report, dict):
        raise ValueError("native PACT file merge returned a non-object payload")
    return report


def native_core_offset_array(source_json: str | None = None) -> Any:
    native = _native_module()
    if source_json is None:
        return native.NativeCoreOffsetArray()
    return native.NativeCoreOffsetArray.from_json(source_json)


def native_depth_array(source_json: str | None = None) -> Any:
    native = _native_module()
    if source_json is None:
        return native.NativeDepthArray()
    return native.NativeDepthArray.from_json(source_json)


class NativeResolver:
    """Python wrapper around the Rust `pactree::resolver::PactResolver`.

    Phase 1 of the canonical full PACT runtime migration plan
    (`internal/plans/canonical-full-pact-runtime-migration-plan.md`).
    Hosts submit typed `PactOperation` dicts and drive the
    resolve/commit cycle entirely in Rust.
    """

    def __init__(
        self,
        pact_tree: dict[str, Any] | list[Any] | str,
        *,
        branch_id: str | None = None,
        file_path: str | None = None,
        seed_root_store: dict[str, Any] | str | None = None,
    ) -> None:
        seed_json = None
        if seed_root_store is not None:
            seed_json = _pact_json(seed_root_store)
        self._inner = _native_module().NativeResolver(
            _pact_json(pact_tree),
            branch_id=branch_id,
            file_path=file_path,
            seed_root_store_json=seed_json,
        )

    @classmethod
    def open_file(cls, path: str) -> "NativeResolver":
        """Phase 10: reconstruct a resolver from an existing `.pact` file."""
        inst = cls.__new__(cls)
        inst._inner = _native_module().NativeResolver.open_file(str(path))
        return inst

    def bind_file(self, path: str) -> None:
        self._inner.bind_file(str(path))

    def submit(self, ops: list[dict[str, Any]]) -> dict[str, Any]:
        ops_json = _pact_json(ops)
        outcome_json = self._inner.submit(ops_json)
        return json.loads(outcome_json)

    def resolve(
        self,
        branch_id: str | None = None,
        boundary: str = "adhoc",
    ) -> dict[str, Any]:
        if branch_id is None:
            branch_id = "main"
        if boundary == "inspect":
            boundary = "adhoc"
        outcome_json = self._inner.resolve(branch_id, boundary)
        return _resolver_outcome(json.loads(outcome_json))

    def commit(self, resolved_boundary: dict[str, Any]) -> dict[str, Any]:
        payload = json.dumps(resolved_boundary, default=_json_default, ensure_ascii=False)
        ref_json = self._inner.commit(payload)
        return json.loads(ref_json)

    def pending_count(self, branch_id: str) -> int:
        return int(self._inner.pending_count(branch_id))

    def list_components(self, *, kind: str | None = None) -> list[dict[str, Any]]:
        records_json = self._inner.list_components(kind)
        return json.loads(records_json)

    def component_payload_for_ref(self, ref_id: str) -> dict[str, Any] | None:
        """Phase 5: substrate-native payload lookup by content ref id."""
        payload_json = self._inner.component_payload_for_ref(ref_id)
        if payload_json is None:
            return None
        return json.loads(payload_json)

    def component_current_state_payload(
        self, component_id: str
    ) -> dict[str, Any] | None:
        """Phase 5: substrate-native current-state payload for a component."""
        payload_json = self._inner.component_current_state_payload(component_id)
        if payload_json is None:
            return None
        return json.loads(payload_json)

    def component_current_projection_payload(
        self, component_id: str
    ) -> dict[str, Any] | None:
        """Phase 5: substrate-native current-projection payload."""
        payload_json = self._inner.component_current_projection_payload(component_id)
        if payload_json is None:
            return None
        return json.loads(payload_json)

    def component_store_payload(self, ref_id: str, payload: Any) -> None:
        """Phase 5: write a payload under a content ref. Used by hosts
        whose render/state ops carry inline payloads alongside refs."""
        self._inner.component_store_payload(
            ref_id,
            json.dumps(payload, default=_json_default, ensure_ascii=False),
        )

    def pending_external(self, branch_id: str) -> list[dict[str, Any]]:
        return json.loads(self._inner.pending_external(branch_id))

    def record_external_failure(
        self, branch_id: str, idempotency_key: str, reason: str
    ) -> None:
        self._inner.record_external_failure(branch_id, idempotency_key, reason)

    def list_tool_calls(self) -> list[dict[str, Any]]:
        return json.loads(self._inner.list_tool_calls())

    def unpaired_tool_call_ids(self) -> list[str]:
        return list(self._inner.unpaired_tool_call_ids())

    def root_store(self) -> dict[str, Any]:
        """Return the native root store without materializing a full tree."""
        return json.loads(self._inner.root_store())

    def materialize(
        self,
        *,
        branch_id: str,
        revision: int | None = None,
    ) -> dict[str, Any] | list[Any]:
        return json.loads(self._inner.materialize(branch_id, revision))

    def preview(self, *, branch_id: str) -> dict[str, Any] | list[Any]:
        return json.loads(self._inner.preview(branch_id))

    def discard_staged(self, branch_id: str) -> bool:
        """Drop the staged-but-uncommitted workspace for a branch.

        Returns True if work was discarded, False if there was nothing
        staged. The committed branch head is unaffected.
        """
        return bool(self._inner.discard_staged(branch_id))

    def has_staged(self, branch_id: str) -> bool:
        """Whether `branch_id` currently has staged-but-uncommitted work."""
        return bool(self._inner.has_staged(branch_id))

    def commit_staged(
        self, branch_id: str, boundary: str
    ) -> dict[str, Any] | None:
        """Resolve pending ops and commit the staged workspace at the
        named boundary in one step. Returns the commit ref, or None if
        there was nothing to commit.
        """
        commit_ref_json = self._inner.commit_staged(branch_id, boundary)
        if commit_ref_json is None:
            return None
        return json.loads(commit_ref_json)

    def open_view_read_only_live(self, source_branch_id: str) -> dict[str, Any]:
        return json.loads(self._inner.open_view_read_only_live(source_branch_id))

    def open_view_read_only_pinned(
        self, source_branch_id: str, *, revision: int | None = None
    ) -> dict[str, Any]:
        return json.loads(
            self._inner.open_view_read_only_pinned(source_branch_id, revision)
        )

    def open_view_mutable_consumer(
        self, source_branch_id: str, consumer_branch_id: str
    ) -> dict[str, Any]:
        return json.loads(
            self._inner.open_view_mutable_consumer(source_branch_id, consumer_branch_id)
        )

    def resolve_view(self, view_ref: dict[str, Any]) -> dict[str, Any]:
        payload = json.dumps(view_ref, default=_json_default, ensure_ascii=False)
        return json.loads(self._inner.resolve_view(payload))

    def build_provider_thread(
        self,
        branch_id: str,
        *,
        revision: int | None = None,
        include_partial_tool_calls: bool = False,
        fail_on_orphan_tool_calls: bool = True,
    ) -> dict[str, Any]:
        thread_json = self._inner.build_provider_thread(
            branch_id,
            revision,
            include_partial_tool_calls,
            fail_on_orphan_tool_calls,
        )
        return json.loads(thread_json)

    def commit_provider_surface(
        self,
        branch_id: str,
        boundary: str,
        *,
        include_partial_tool_calls: bool = False,
        fail_on_orphan_tool_calls: bool = True,
    ) -> dict[str, Any]:
        report_json = self._inner.commit_provider_surface(
            branch_id,
            boundary,
            include_partial_tool_calls,
            fail_on_orphan_tool_calls,
        )
        report = json.loads(report_json)
        if not isinstance(report, dict):
            raise ValueError("native provider surface commit returned a non-object payload")
        return report


class PactRuntime:
    """Wrapper around the Rust PactRuntime handle."""

    def __init__(
        self,
        pact_tree: dict[str, Any] | list[Any] | str,
        *,
        branch_id: str | None = None,
        blob_inline_limit: int = 1024,
        file_path: str | None = None,
    ) -> None:
        pact_json = _pact_json(pact_tree)
        self._handle = _native_module().PactRuntime(
            pact_json,
            branch_id=branch_id,
            blob_inline_limit=blob_inline_limit,
            file_path=file_path,
        )

    def apply_mutation(self, request: dict[str, Any] | str) -> dict[str, Any]:
        request_json = _pact_json(request)
        report_json = self._handle.apply_mutation(request_json)
        return json.loads(report_json)

    def apply_batch(self, requests: list[dict[str, Any] | str]) -> dict[str, Any]:
        requests_json = [_pact_json(req) for req in requests]
        report_json = self._handle.apply_batch(requests_json)
        return json.loads(report_json)

    def project(
        self,
        view: str,
        *,
        range_spec: str | None = None,
        branch: str | None = None,
        revision: int | None = None,
    ) -> dict[str, Any]:
        proj_json = self._handle.project(
            view,
            range=range_spec,
            branch=branch,
            revision=revision,
        )
        return json.loads(proj_json)

    def materialize(
        self,
        *,
        branch: str | None = None,
        revision: int | None = None,
    ) -> dict[str, Any] | list[Any]:
        mat_json = self._handle.materialize(
            branch=branch,
            revision=revision,
        )
        return json.loads(mat_json)

    def build_provider_thread(
        self,
        *,
        branch: str | None = None,
        revision: int | None = None,
        include_partial_tool_calls: bool = False,
        fail_on_orphan_tool_calls: bool = True,
    ) -> dict[str, Any]:
        thread_json = self._handle.build_provider_thread(
            branch=branch,
            revision=revision,
            include_partial_tool_calls=include_partial_tool_calls,
            fail_on_orphan_tool_calls=fail_on_orphan_tool_calls,
        )
        return json.loads(thread_json)

    def commit_trace(self, trace_request: dict[str, Any] | str) -> dict[str, Any]:
        trace_json = _pact_json(trace_request)
        ref_json = self._handle.commit_trace(trace_json)
        return json.loads(ref_json)


__all__ = [
    "NativeResolver",
    "PactRuntime",
    "delete_pact_tree",
    "native_core_offset_array",
    "native_depth_array",
    "normalize_pact_tree",
    "pact_canonical_node",
    "pact_canonical_node_kinds",
    "pact_mutation_request_validate",
    "pact_node_from_component",
    "pact_node_project",
    "pact_operation_report_validate",
    "pact_content_store_put_inline",
    "pact_file_append_content_manifest",
    "pact_file_append_commit",
    "pact_file_append_trace",
    "pact_file_append_views",
    "pact_file_bundle_create",
    "pact_file_bundle_export_full",
    "pact_file_bundle_prune",
    "pact_file_bundle_verify",
    "pact_file_create",
    "pact_file_content_manifest_payload",
    "pact_file_content_payload",
    "pact_file_cycles",
    "pact_file_import",
    "pact_file_import_check",
    "pact_file_info",
    "pact_file_inspect",
    "pact_file_materialize",
    "pact_file_merge",
    "pact_file_open",
    "pact_file_open_head_fast",
    "pact_file_project_range",
    "pact_file_projection",
    "pact_file_query",
    "pact_file_repair",
    "pact_file_root_store",
    "pact_file_slice",
    "pact_file_validate",
    "pact_file_view_detach",
    "pact_file_view_merge",
    "pact_file_view_merge_preflight",
    "pact_file_view_projection",
    "pact_file_view_query",
    "pact_file_view_rebase",
    "pact_root_store_append_branch_patch",
    "pact_root_store_fork_at_node",
    "pact_root_store_fork_at_revision",
    "pact_root_store_fork_at_transaction",
    "pact_root_store_from_store",
    "pact_root_store_inspect",
    "pact_root_store_inspect_branch",
    "pact_root_store_materialize_branch",
    "pact_root_store_new",
    "pact_root_store_project_branch",
    "pact_root_store_record_transaction_trace",
    "pact_store_append_patch",
    "pact_store_checkpoint",
    "pact_store_fork",
    "pact_store_materialize",
    "pact_store_new",
    "pact_transaction_trace_build",
    "pact_transaction_trace_validate",
    "render_pact_tree_xml",
    "select_pact_subtrees",
    "select_pact_tree",
]
