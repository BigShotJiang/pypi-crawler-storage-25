"""PACT tree normalization.

The public API lives in Python so callers do not need to know how the native
extension is packaged. The implementation is Rust/PyO3 because Context
Explorer and Lens need to normalize large PACT trees without dragging the UI
through a recursive JSON blob every refresh.
"""

from __future__ import annotations

from typing import Any

from .native import normalize_pact_tree as _normalize_pact_tree_native


def normalize_pact_tree(
    pact_tree: dict[str, Any] | list[Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    """Return a normalized node-table projection for a PACT tree.

    Args:
        pact_tree: PACT JSON as a Python object or compact JSON string.
        blob_inline_limit: Text content at or below this character count stays
            inline. Larger text becomes a blob ref with a short preview.

    Raises:
        RuntimeError: if the Rust/PyO3 extension is not installed.
        ValueError: if the native extension returns malformed JSON.
    """

    return _normalize_pact_tree_native(
        pact_tree,
        blob_inline_limit=blob_inline_limit,
    )


__all__ = ["normalize_pact_tree"]
