"""Internal PACT node boundary.

Python components stay ergonomic. When a context operation needs the canonical
node shape, it crosses this module and Rust validates/projects the node.
"""

from __future__ import annotations

from typing import Any

from .native import pact_node_from_component, pact_node_prepare_for_context, pact_node_project


def native_node_for_component(component: Any) -> dict[str, Any]:
    """Project a Python PACT component into the Rust-owned node model."""

    return pact_node_from_component(component)


def native_node_for_component_in_context(
    component: Any,
    context: dict[str, Any],
) -> dict[str, Any]:
    """Project and stamp a Python component through the Rust node boundary."""

    if hasattr(component, "model_dump") and callable(component.model_dump):
        component = component.model_dump()
    return pact_node_prepare_for_context(component, context)


def component_projection_from_native_node(node: dict[str, Any] | str) -> dict[str, Any]:
    """Project a Rust-owned node back into JSON-shaped Python component data."""

    return pact_node_project(node)


__all__ = [
    "component_projection_from_native_node",
    "native_node_for_component",
    "native_node_for_component_in_context",
]
