"""Compatibility facade for Rust-owned PACT store operations.

The Python store implementation was removed during the Rust PACT migration.
Some Egregore runtime edges still import the old function names, so this module
keeps that import surface alive while delegating every operation to the native
PyO3-backed substrate.
"""

from __future__ import annotations

from typing import Any

from .native import (
    pact_content_store_put_inline,
    pact_root_store_append_branch_patch,
    pact_root_store_fork_at_node,
    pact_root_store_fork_at_revision,
    pact_root_store_fork_at_transaction,
    pact_root_store_from_store,
    pact_root_store_inspect,
    pact_root_store_inspect_branch,
    pact_root_store_materialize_branch,
    pact_root_store_new,
    pact_root_store_project_branch,
    pact_root_store_record_transaction_trace,
    pact_store_append_patch,
    pact_store_checkpoint,
    pact_store_fork,
    pact_store_materialize,
    pact_store_new,
    pact_transaction_trace_build,
    pact_transaction_trace_validate,
)


def _dump_component(value: Any) -> Any:
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return value.to_dict()
    if hasattr(value, "model_dump") and callable(value.model_dump):
        return value.model_dump()
    return value


def _coerce_context_dump(value: Any) -> Any:
    """Convert legacy Context.model_dump() facades into a plain Pact tree.

    The Rust native bridge can serialize canonical dict/list trees directly.
    Older tests and a few artifact readers still pass a Context dump whose
    `content` field is a Python facade, so flatten that facade at the adapter
    boundary instead of making storage Python-owned again.
    """

    if not isinstance(value, dict):
        return value
    content = value.get("content")
    iter_depth_items = getattr(content, "iter_depth_items", None)
    if not callable(iter_depth_items):
        return value
    tree = {key: item for key, item in value.items() if key != "content"}
    tree.setdefault("nodeType", tree.get("type") or "root")
    tree.setdefault("type", tree.get("nodeType") or "root")
    tree["children"] = [
        _dump_component(component)
        for _, component in iter_depth_items()
        if component is not None
    ]
    return tree


def create_pact_store(
    pact_tree: dict[str, Any] | list[Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_store_new(
        _coerce_context_dump(pact_tree),
        blob_inline_limit=blob_inline_limit,
    )


def materialize_pact_store(
    store: dict[str, Any] | str,
    *,
    revision: int | None = None,
) -> dict[str, Any]:
    return pact_store_materialize(store, revision=revision)


def append_pact_patch(
    store: dict[str, Any] | str,
    patch: dict[str, Any] | str,
    *,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_store_append_patch(
        store,
        patch,
        blob_inline_limit=blob_inline_limit,
    )


def checkpoint_pact_store(
    store: dict[str, Any] | str,
    *,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_store_checkpoint(
        store,
        revision=revision,
        blob_inline_limit=blob_inline_limit,
    )


def fork_pact_store(
    store: dict[str, Any] | str,
    *,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_store_fork(
        store,
        revision=revision,
        blob_inline_limit=blob_inline_limit,
    )


def create_pact_root_store(
    pact_tree: dict[str, Any] | list[Any] | str,
    *,
    branch_id: str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_root_store_new(
        _coerce_context_dump(pact_tree),
        branch_id=branch_id,
        blob_inline_limit=blob_inline_limit,
    )


def convert_pact_store_to_root_store(
    store: dict[str, Any] | str,
    *,
    branch_id: str | None = None,
) -> dict[str, Any]:
    return pact_root_store_from_store(store, branch_id=branch_id)


def inspect_pact_root_store(
    root_store: dict[str, Any] | str,
) -> dict[str, Any]:
    return pact_root_store_inspect(root_store)


def inspect_pact_root_store_branch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
) -> dict[str, Any]:
    return pact_root_store_inspect_branch(root_store, branch_id=branch_id)


def materialize_pact_root_store_branch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
    revision: int | None = None,
) -> dict[str, Any]:
    return pact_root_store_materialize_branch(
        root_store,
        branch_id=branch_id,
        revision=revision,
    )


def project_pact_root_store_branch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
    revision: int | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_root_store_project_branch(
        root_store,
        branch_id=branch_id,
        revision=revision,
        blob_inline_limit=blob_inline_limit,
    )


def append_pact_root_store_branch_patch(
    root_store: dict[str, Any] | str,
    *,
    branch_id: str,
    patch: dict[str, Any] | str,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_root_store_append_branch_patch(
        root_store,
        branch_id=branch_id,
        patch=patch,
        blob_inline_limit=blob_inline_limit,
    )


def fork_pact_root_store_at_revision(
    root_store: dict[str, Any] | str,
    *,
    from_branch_id: str,
    revision: int | None = None,
    new_branch_id: str | None = None,
    aux: dict[str, Any] | str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_root_store_fork_at_revision(
        root_store,
        from_branch_id=from_branch_id,
        revision=revision,
        new_branch_id=new_branch_id,
        aux=aux,
        blob_inline_limit=blob_inline_limit,
    )


def fork_pact_root_store_at_node(
    root_store: dict[str, Any] | str,
    *,
    from_branch_id: str,
    node_id: str,
    new_branch_id: str | None = None,
    aux: dict[str, Any] | str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_root_store_fork_at_node(
        root_store,
        from_branch_id=from_branch_id,
        node_id=node_id,
        new_branch_id=new_branch_id,
        aux=aux,
        blob_inline_limit=blob_inline_limit,
    )


def record_pact_root_store_transaction_trace(
    root_store: dict[str, Any] | str,
    trace: dict[str, Any] | str,
) -> dict[str, Any]:
    return pact_root_store_record_transaction_trace(root_store, trace)


def fork_pact_root_store_at_transaction(
    root_store: dict[str, Any] | str,
    *,
    from_branch_id: str,
    transaction_id: str,
    new_branch_id: str | None = None,
    aux: dict[str, Any] | str | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    return pact_root_store_fork_at_transaction(
        root_store,
        from_branch_id=from_branch_id,
        transaction_id=transaction_id,
        new_branch_id=new_branch_id,
        aux=aux,
        blob_inline_limit=blob_inline_limit,
    )


def context_copy(
    root_store: dict[str, Any] | str,
    *,
    from_branch_id: str,
    revision: int | None = None,
    node_id: str | None = None,
    transaction_id: str | None = None,
    new_copy_id: str | None = None,
    copy_kind: str = "context_copy",
    owner: dict[str, Any] | None = None,
    transient: bool = False,
    aux: dict[str, Any] | None = None,
    blob_inline_limit: int = 1024,
) -> dict[str, Any]:
    fork_aux = {
        "branch_kind": "context_copy",
        "copy_kind": copy_kind,
        "source_branch_id": from_branch_id,
        "transient": transient,
        **({"owner": owner} if owner is not None else {}),
        **dict(aux or {}),
    }
    if transaction_id:
        return pact_root_store_fork_at_transaction(
            root_store,
            from_branch_id=from_branch_id,
            transaction_id=transaction_id,
            new_branch_id=new_copy_id,
            aux=fork_aux,
            blob_inline_limit=blob_inline_limit,
        )
    if node_id:
        return pact_root_store_fork_at_node(
            root_store,
            from_branch_id=from_branch_id,
            node_id=node_id,
            new_branch_id=new_copy_id,
            aux=fork_aux,
            blob_inline_limit=blob_inline_limit,
        )
    return pact_root_store_fork_at_revision(
        root_store,
        from_branch_id=from_branch_id,
        revision=revision,
        new_branch_id=new_copy_id,
        aux=fork_aux,
        blob_inline_limit=blob_inline_limit,
    )


def put_pact_content(
    store: dict[str, Any] | str | None,
    *,
    kind: str,
    content: str,
    preview_chars: int = 160,
    blob_inline_limit: int | None = None,
) -> dict[str, Any]:
    del blob_inline_limit
    return pact_content_store_put_inline(
        store,
        kind=kind,
        content=content,
        preview_chars=preview_chars,
    )


def build_pact_transaction_trace(
    request: dict[str, Any] | str,
) -> dict[str, Any]:
    return pact_transaction_trace_build(request)


def validate_pact_transaction_trace(
    trace: dict[str, Any] | str,
) -> dict[str, Any]:
    return pact_transaction_trace_validate(trace)


__all__ = [
    "append_pact_patch",
    "append_pact_root_store_branch_patch",
    "build_pact_transaction_trace",
    "checkpoint_pact_store",
    "context_copy",
    "convert_pact_store_to_root_store",
    "create_pact_root_store",
    "create_pact_store",
    "fork_pact_root_store_at_node",
    "fork_pact_root_store_at_revision",
    "fork_pact_root_store_at_transaction",
    "fork_pact_store",
    "inspect_pact_root_store",
    "inspect_pact_root_store_branch",
    "materialize_pact_root_store_branch",
    "materialize_pact_store",
    "project_pact_root_store_branch",
    "put_pact_content",
    "record_pact_root_store_transaction_trace",
    "validate_pact_transaction_trace",
]
