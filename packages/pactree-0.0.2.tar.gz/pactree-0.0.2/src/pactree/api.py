"""
PACT Facade: Single entry-point insert/update/delete under pact.

Goal:
- Provide our own API surface within the module for single-point ops.

This facade delegates to the Context PACT API so every mutation crosses the
resolver/report boundary. It does not perform independent registry repair.
"""

from __future__ import annotations

from typing import Any, Tuple, Union

# Import real types — no Any aliasing
from pactree.components.core import PACTCore
from pactree.context.position import Pos
from pactree.context.base import UpdateResult


Selector = Union[str, "Pos", Tuple["Pos", ...]]


class PactFacade:
    """Facade wrapping a Context instance with single-point ops."""

    def __init__(self, context: Any):
        self.context = context

    # --- Public API ---

    def insert(self, selector: Selector, component: Union[PACTCore, str]) -> UpdateResult:
        """Insert component through the resolver-owned context boundary."""
        return self.context.pact_insert(selector, component)

    def update(
        self,
        selector_or_component: Union[str, PACTCore, None] = None,
        *,
        component: Union[PACTCore, None] = None,
        mode: str = "replace",
        content: Union[str, None] = None,
        **kwargs: Any,
    ) -> UpdateResult:
        """Update through the resolver-owned context boundary."""
        return self.context.pact_update(
            selector_or_component,
            component=component,
            mode=mode,
            content=content,
            **kwargs,
        )

    def delete(self, selector: Union[str, PACTCore]) -> UpdateResult:
        """Delete through the resolver-owned context boundary."""
        return self.context.pact_delete(selector)


# --- Module-level convenience ---

def insert(context: Any, selector: Selector, component: Union[PACTCore, str]) -> UpdateResult:
    return PactFacade(context).insert(selector, component)


def update(
    context: Any,
    selector_or_component: Union[str, PACTCore, None] = None,
    *,
    component: Union[PACTCore, None] = None,
    mode: str = "replace",
    content: Union[str, None] = None,
    **kwargs: Any,
) -> UpdateResult:
    return PactFacade(context).update(
        selector_or_component, component=component, mode=mode, content=content, **kwargs
    )


def delete(context: Any, selector: Union[str, PACTCore]) -> UpdateResult:
    return PactFacade(context).delete(selector)
