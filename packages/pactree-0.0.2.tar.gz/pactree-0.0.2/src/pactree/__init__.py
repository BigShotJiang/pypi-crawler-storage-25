"""Python host edge for the Rust-owned Pactree substrate."""

from __future__ import annotations

from typing import Any

from ._version import __version__
from . import canonical_nodes, file
from .engine import EngineUnavailableError, engine_available
from .normalizer import normalize_pact_tree


def __getattr__(name: str) -> Any:
    if name in {"Context", "UpdateResult"}:
        from .context import Context, UpdateResult

        return {"Context": Context, "UpdateResult": UpdateResult}[name]
    if name in {
        "NativeResolver",
        "PactRuntime",
        "delete_pact_tree",
        "render_pact_tree_xml",
        "select_pact_subtrees",
        "select_pact_tree",
    }:
        from . import native

        return getattr(native, name)
    raise AttributeError(name)


def content_ref(ref_id: str, **metadata: Any) -> dict[str, Any]:
    """Canonical content reference payload used by host integrations."""
    payload: dict[str, Any] = {"id": str(ref_id)}
    payload.update(metadata)
    return payload


def node_ref(node_id: str, **metadata: Any) -> dict[str, Any]:
    """Canonical node reference payload used by host integrations."""
    payload: dict[str, Any] = {"node_id": str(node_id)}
    payload.update(metadata)
    return payload


def external_ref(uri: str, **metadata: Any) -> dict[str, Any]:
    """Canonical external reference payload.

    This is a reference descriptor only; it does not persist external bytes in
    Python and does not create component records.
    """
    payload: dict[str, Any] = {"uri": str(uri)}
    payload.update(metadata)
    return payload

__all__ = [
    "canonical_nodes",
    "Context",
    "content_ref",
    "delete_pact_tree",
    "EngineUnavailableError",
    "engine_available",
    "external_ref",
    "file",
    "NativeResolver",
    "node_ref",
    "normalize_pact_tree",
    "PactRuntime",
    "render_pact_tree_xml",
    "select_pact_subtrees",
    "select_pact_tree",
    "UpdateResult",
    "__version__",
]
