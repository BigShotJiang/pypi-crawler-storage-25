# Pactree

Pactree is a deterministic context-tree substrate for AI agents and
applications. It is designed to make context explicit: ordered, queryable,
branchable, compact on disk, and stable across Python and Rust runtimes.

The project centers on the `.pact` file format and a Rust engine for
context trees, operations, selectors, projections, traces, and rewind/fork
workflows. The Python package provides the ergonomic host API that applications
use to build, inspect, and persist those trees.

Core goals:

- deterministic tree layout for agent context
- compact content-addressed storage
- branch, rewind, and what-if workflows
- provider-facing projections without losing substrate structure
- a clean Python API backed by a canonical Rust implementation

This is an early `0.0.x` release while the standalone package is being split
out. The public namespace is available now; the Pactree engine binary and Python
bindings will land in the next extraction releases.
