from __future__ import annotations

import pytest

import pactree
from pactree import file

def test_shim_import_surface() -> None:
    assert pactree.__version__ == "0.0.2"
    assert pactree.engine_available() is False
    assert pactree.Context.__name__ == "Context"


def test_engine_calls_report_unavailable_engine() -> None:
    with pytest.raises(RuntimeError, match="Pactree engine is unavailable"):
        pactree.Context()

    with pytest.raises(RuntimeError, match="Pactree engine is unavailable"):
        file.info("session.pact")
