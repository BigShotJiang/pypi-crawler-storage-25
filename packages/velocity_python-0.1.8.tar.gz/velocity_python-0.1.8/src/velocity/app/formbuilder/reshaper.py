"""velocity.app.formbuilder.reshaper

Reshape a raw ``form_builder_template`` database row into the public ``fb``
payload structure as produced by ``DonateMainEvents.OnActionGetFormBuilder``.

The single public entry-point is :func:`reshape_formbuilder_template`.  It is
a **pure function** — the input is deep-copied and never mutated.

Payment tokens, reCAPTCHA keys, and live thermometer totals are **not**
included; those are runtime secrets and database query results that the caller
must add separately (as DonateMain does in
``OnActionGetFormBuilder``).  The returned dict is safe to serialise and
return as a preview payload.

Usage::

    from velocity.app.formbuilder.reshaper import reshape_formbuilder_template

    fb = reshape_formbuilder_template(template_row.to_dict())
"""

import ast
import copy
from typing import Any, Dict, Optional


# ---------------------------------------------------------------------------
# Internal per-metric / per-donation helpers
# ---------------------------------------------------------------------------

def _parse_key_value_string(raw: Optional[str]) -> Dict[str, Any]:
    """Parse a ``"key1: val1, key2: val2"`` string into a dict.

    Wraps the string in braces and calls ``ast.literal_eval``, exactly as the
    original DonateMain ``getMetric`` / ``getDonation`` functions do.
    Returns an empty dict on failure so a bad value never crashes the reshaper.
    """
    if not raw:
        return {}
    try:
        return ast.literal_eval("{" + raw + "}")
    except Exception:
        return {}


def _extract_metric(count: int, data: Dict[str, Any]) -> Dict[str, Any]:
    """Extract metric_{count}_* fields from *data* (mutates *data*).

    Returns the nested metric dict when the metric has a label and is not
    hidden, otherwise returns ``{}``.  Either way all flat metric_N_* keys
    are removed from *data*.
    """
    prefix = f"metric_{count}_"
    flat_keys = [
        "header", "image", "label", "secondarytext", "helpertext",
        "values", "defaultvalue", "show_other", "other_minimum_value",
        "orientation",
    ]

    is_hidden = data.get(f"{prefix}hide_donation_from_ui")
    has_label = data.get(f"{prefix}label")

    if not is_hidden and has_label:
        result = {
            "header": data.pop(f"{prefix}header", None),
            "image": data.pop(f"{prefix}image", None),
            "label": data.pop(f"{prefix}label", None),
            "secondarytext": data.pop(f"{prefix}secondarytext", None),
            "helpertext": data.pop(f"{prefix}helpertext", None),
            "values": _parse_key_value_string(data.pop(f"{prefix}values", None)),
            "defaultvalue": data.pop(f"{prefix}defaultvalue", None),
            "show_other": data.pop(f"{prefix}show_other", ""),
            "other_minimum_value": data.pop(f"{prefix}other_minimum_value", ""),
            "orientation": data.pop(f"{prefix}orientation", ""),
        }
        data.pop(f"{prefix}hide_donation_from_ui", None)
        return result

    # Strip all flat keys even when hidden / empty
    for key in flat_keys:
        data.pop(f"{prefix}{key}", None)
    data.pop(f"{prefix}hide_donation_from_ui", None)
    return {}


def _extract_donation(count: int, data: Dict[str, Any]) -> Dict[str, Any]:
    """Extract donation_{count}_* fields from *data* (mutates *data*).

    Returns the nested donation dict when the donation has a label and is not
    hidden, otherwise returns ``{}``.  Either way all flat donation_N_* keys
    are removed from *data*.
    """
    prefix = f"donation_{count}_"
    flat_keys = [
        "header", "image", "html", "label", "secondarytext", "helpertext",
        "values", "defaultvalue", "show_other", "other_minimum_value",
        "orientation", "dropdown", "dropdown_label",
    ]

    is_hidden = data.get(f"{prefix}hide_donation_from_ui")
    has_label = data.get(f"{prefix}label")

    if not is_hidden and has_label:
        result = {
            "header": data.pop(f"{prefix}header", None),
            "image": data.pop(f"{prefix}image", None),
            "html": data.pop(f"{prefix}html", None),
            "label": data.pop(f"{prefix}label", None),
            "secondarytext": data.pop(f"{prefix}secondarytext", None),
            "helpertext": data.pop(f"{prefix}helpertext", None),
            "values": _parse_key_value_string(data.pop(f"{prefix}values", None)),
            "defaultvalue": data.pop(f"{prefix}defaultvalue", None),
            "show_other": data.pop(f"{prefix}show_other", ""),
            "other_minimum_value": data.pop(f"{prefix}other_minimum_value", ""),
            "orientation": data.pop(f"{prefix}orientation", ""),
            "dropdown": data.pop(f"{prefix}dropdown", None),
            "dropdown_label": data.pop(f"{prefix}dropdown_label", None),
        }
        data.pop(f"{prefix}hide_donation_from_ui", None)
        return result

    for key in flat_keys:
        data.pop(f"{prefix}{key}", None)
    data.pop(f"{prefix}hide_donation_from_ui", None)
    return {}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def reshape_formbuilder_template(raw_row: Dict[str, Any]) -> Dict[str, Any]:
    """Reshape a raw ``form_builder_template`` DB row into the public ``fb`` dict.

    This replicates exactly what ``DonateMainEvents.OnActionGetFormBuilder``
    does to reshape the flat database row before returning it to the browser,
    without the live DB queries (thermometer totals) or runtime secrets
    (payment tokens, reCAPTCHA keys).

    The caller is responsible for:

    - Passing in a plain Python dict (call ``.to_dict()`` on a velocity DB
      row first so that Decimal and datetime values are already serialisable).
    - Optionally adding ``fb["thermometer"]`` / ``fb["rival_thermometer"]``
      after the call if live totals are desired.

    Returns a new dict; the input is never mutated.

    Example::

        row = tx.table("form_builder_template").one({"sys_id": sys_id})
        fb  = reshape_formbuilder_template(row.to_dict())
    """
    fb = copy.deepcopy(raw_row)

    fb["metrics"] = {
        f"metric_{i}": _extract_metric(i, fb) for i in range(1, 10)
    }
    fb["donations"] = {
        f"donation_{i}": _extract_donation(i, fb) for i in range(1, 10)
    }

    # Expose the primary key under the public name used by DonateMain
    fb["_num_entries"] = fb.get("sys_id")

    # Strip internal / private fields
    for key in list(fb.keys()):
        if key.startswith("sys_"):
            del fb[key]

    for key in (
        # UI-only computed column (row counter) — never a real DB column
        "row_number",
        "url_slug",
        "url_slug_alternate",
        # Administrative / validation metadata — not read by DonateMain frontend
        "is_published",
        "datetime_last_validated",
        "last_validation_result",
        "last_validation_reason",
        # Backend-only: security / fraud prevention
        "whitelist_end_date",
        "recaptcha_version",
        "recaptcha_v3_score_threshold",
        # Backend-only: routing / campaign metadata
        "campaign",
        "sub_campaign",
        # Backend-only: email receipts (server-side sending only)
        "receipt_from_address",
        "receipt_subject",
        "receipt_body_text",
        "mail_bcc",
        # Backend-only: rally out-of-band receipts
        "rally_receipt_from_address",
        "rally_receipt_subject",
        "rally_receipt_body_text",
        "rally_mail_bcc",
    ):
        fb.pop(key, None)

    return fb
