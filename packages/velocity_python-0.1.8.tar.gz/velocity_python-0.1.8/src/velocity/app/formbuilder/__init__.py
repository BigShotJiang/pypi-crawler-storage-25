"""velocity.app.formbuilder — shared logic for form_builder_template records."""
