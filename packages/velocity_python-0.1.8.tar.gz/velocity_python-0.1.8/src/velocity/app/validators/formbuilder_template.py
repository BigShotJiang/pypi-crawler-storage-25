"""Pure-Python validator for form_builder_template dicts.

Authoritative location: velocity.app.validators.formbuilder_template

Called by:
  - BackOffice before_write hook (rwx/form_builder_template.py)
  - BackOffice CLI: scripts/validate_formbuilder_templates.py
  - DonateMain CLI: scripts/formbuilder_validator.py (shim — imports from here)
  - Tests: velocity-python/tests/app/validators/test_formbuilder_template.py
           BackOffice.demo/tests/backend/test_form_builder_template_hook.py
           DonateMain.demo/tests/backend/test_formbuilder_validators.py

No external dependencies — only the stdlib so it runs everywhere the test suite runs.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List

# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
# Also accept RFC 5322 display-name format: "Label <user@example.com>"
_EMAIL_DISPLAY_RE = re.compile(r"<[^@\s>]+@[^@\s>]+\.[^@\s>]+>$")
_URL_RE = re.compile(r"^https?://", re.IGNORECASE)

# Braintree: descriptor must be <= 22 characters, NAME*TEXT format.
_BT_DESCRIPTOR_MAX_LEN = 22


def _str_val(fb: Dict[str, Any], key: str) -> str:
    """Return the stripped string value for a key, or '' when None/missing."""
    v = fb.get(key)
    return v.strip() if isinstance(v, str) else ""


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #

Issue = Dict[str, str]  # {field, severity, message}


def validate_formbuilder_template(fb: Dict[str, Any]) -> List[Issue]:
    """Validate a form_builder_template dict for known configuration problems.

    Returns a list of issue dicts::

        [{"field": "...", "severity": "error"|"warning", "message": "..."}]

    An empty list means no issues were found.

    Severities:
      error   – will cause a runtime crash or silent payment failure.
      warning – likely produces a broken/confusing user experience.
    """
    issues: List[Issue] = []

    def error(field: str, message: str) -> None:
        issues.append({"field": field, "severity": "error", "message": message})

    def warning(field: str, message: str) -> None:
        issues.append({"field": field, "severity": "warning", "message": message})

    # ---------------------------------------------------------------------- #
    # Identity
    # ---------------------------------------------------------------------- #
    if not _str_val(fb, "client"):
        error("client", "client is required; KeyError will crash the handler")

    if not _str_val(fb, "campaign"):
        error("campaign", "campaign is required; KeyError will crash the handler")

    if not _str_val(fb, "url_slug"):
        error("url_slug", "url_slug is required; template will not be routable")

    # ---------------------------------------------------------------------- #
    # Receipt email fields
    # (used with direct key access: fb["receipt_from_address"] etc.)
    # ---------------------------------------------------------------------- #
    from_addr = _str_val(fb, "receipt_from_address")
    if not from_addr:
        error(
            "receipt_from_address",
            "receipt_from_address is empty; donation receipt emails will fail to send",
        )
    elif not _EMAIL_RE.match(from_addr) and not _EMAIL_DISPLAY_RE.search(from_addr):
        error(
            "receipt_from_address",
            f"receipt_from_address '{from_addr}' is not a valid email address",
        )

    if not _str_val(fb, "receipt_subject"):
        warning(
            "receipt_subject",
            "receipt_subject is empty; donation receipt email subject will be blank",
        )

    if not _str_val(fb, "receipt_body_text"):
        error(
            "receipt_body_text",
            "receipt_body_text is empty; donation receipt emails will have no content",
        )

    # ---------------------------------------------------------------------- #
    # Braintree transaction descriptor
    # Rules: <= 22 chars, should contain '*', ASCII printable only.
    # ---------------------------------------------------------------------- #
    descriptor = _str_val(fb, "descriptor")
    if descriptor:
        if len(descriptor) > _BT_DESCRIPTOR_MAX_LEN:
            error(
                "descriptor",
                f"descriptor is {len(descriptor)} chars (max {_BT_DESCRIPTOR_MAX_LEN}); "
                "Braintree will reject the transaction",
            )
        if "*" not in descriptor:
            warning(
                "descriptor",
                f"descriptor '{descriptor}' should follow 'NAME*TEXT' format for Braintree",
            )
        bad_chars = [c for c in descriptor if not (32 <= ord(c) <= 126)]
        if bad_chars:
            error(
                "descriptor",
                f"descriptor contains non-ASCII/non-printable characters: {bad_chars!r}",
            )

    # ---------------------------------------------------------------------- #
    # Content — at least one active donation or metric must be configured
    # ---------------------------------------------------------------------- #
    has_content = _has_donation_content(fb) or _has_metric_content(fb)
    if not has_content:
        warning(
            "donations/metrics",
            "template has no donation amounts or metrics configured; the form will be empty",
        )

    # ---------------------------------------------------------------------- #
    # Share URL (used in confirmation email)
    # ---------------------------------------------------------------------- #
    share_url = _str_val(fb, "share_url")
    if share_url and not _URL_RE.match(share_url):
        warning(
            "share_url",
            f"share_url '{share_url}' does not look like a valid URL (expected https://...)",
        )

    # ---------------------------------------------------------------------- #
    # Confirmation page text
    # ---------------------------------------------------------------------- #
    if not _str_val(fb, "confirmation_header_text"):
        warning(
            "confirmation_header_text",
            "confirmation_header_text is empty; the thank-you page header will be blank",
        )

    return issues


# --------------------------------------------------------------------------- #
# Internal helpers
# --------------------------------------------------------------------------- #


def _has_donation_content(fb: Dict[str, Any]) -> bool:
    """Return True if at least one visible donation is configured."""
    donations = fb.get("donations")
    if isinstance(donations, dict):
        for key, item in donations.items():
            hide_key = f"donation_{key}_hide_donation_from_ui"
            if fb.get(hide_key):
                continue
            if isinstance(item, dict) and item.get("label"):
                return True
    # Legacy numbered fields
    for i in range(1, 10):
        if fb.get(f"donation_{i}_hide_donation_from_ui"):
            continue
        if _str_val(fb, f"donation_{i}_label") or fb.get(f"donation_{i}_values"):
            return True
    return False


def _has_metric_content(fb: Dict[str, Any]) -> bool:
    """Return True if at least one visible metric is configured."""
    metrics = fb.get("metrics")
    if isinstance(metrics, dict):
        for key, item in metrics.items():
            hide_key = f"{key}_hide_donation_from_ui"
            if fb.get(hide_key):
                continue
            if isinstance(item, dict) and item.get("label"):
                return True
    # Legacy numbered fields
    for i in range(1, 10):
        if fb.get(f"metric_{i}_hide_donation_from_ui"):
            continue
        if _str_val(fb, f"metric_{i}_label") or fb.get(f"metric_{i}_values"):
            return True
    return False
