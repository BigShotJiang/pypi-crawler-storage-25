"""velocity.app.validators — domain validators for shared application entities."""
