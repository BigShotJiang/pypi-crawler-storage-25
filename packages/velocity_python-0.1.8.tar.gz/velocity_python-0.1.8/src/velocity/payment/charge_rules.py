"""Shared immediate-charge validation helpers for payment flows."""

from __future__ import annotations

from typing import Any


def should_charge_immediately(total_charge_amount: Any) -> bool:
    """Return True when an immediate payment should be submitted to a processor."""
    if total_charge_amount in (None, ""):
        return False
    try:
        return float(total_charge_amount) > 0
    except (TypeError, ValueError):
        return False


def is_below_immediate_charge_minimum(
    total_charge_amount: Any, minimum_donation_amount: Any
) -> bool:
    """Return True only when an actual immediate charge exists and is below the minimum."""
    if not should_charge_immediately(total_charge_amount):
        return False
    try:
        return float(total_charge_amount) < float(minimum_donation_amount)
    except (TypeError, ValueError):
        return False


def is_above_immediate_charge_maximum(
    total_charge_amount: Any, maximum_donation_amount: Any
) -> bool:
    """Return True only when an actual immediate charge exists and is above the maximum."""
    if not should_charge_immediately(total_charge_amount):
        return False
    try:
        return float(total_charge_amount) > float(maximum_donation_amount)
    except (TypeError, ValueError):
        return False
