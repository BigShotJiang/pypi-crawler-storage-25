"""Demo-only payment profile helpers for charging copied production users safely."""

import hashlib
import os
from typing import Dict, List, Optional

from .profiles import get_payment_profile_sources, upsert_payment_profile
from .router import get_processor_config

_DEMO_STRIPE_TOKEN = "tok_visa"
_DEMO_AUTHORIZE_CARD_NUMBER = "4111111111111111"
_DEMO_AUTHORIZE_EXPIRATION = "2030-12"
_DEMO_AUTHORIZE_CARD_CODE = "123"
_DEMO_BRAINTREE_CARD_NUMBERS = [
    "4111111111111111",
    "4012888888881881",
    "5555555555554444",
    "6011000991300009",
    "378282246310005",
]


def is_demo_environment() -> bool:
    return str(os.environ.get("USER_BRANCH") or "demo").lower() != "production"


def build_demo_profile_email(email_address: str, processor_code: str) -> str:
    email_address = str(email_address or "")
    if "@" not in email_address:
        return email_address
    local_part, domain = email_address.split("@", 1)
    return f"{local_part}+demo-{processor_code}@{domain}"


def _format_expiration_date(year, month) -> str:
    return f"{year}-{str(month).zfill(2)}"


def _save_payment_profile(tx, data: Dict) -> Dict:
    upsert_payment_profile(
        tx,
        data,
        key={"payment_profile_id": data["payment_profile_id"]},
    )
    tx.commit()
    return data


def _stable_hash(value: str) -> int:
    return int(hashlib.sha256(str(value).encode("utf-8")).hexdigest(), 16)


def _build_demo_braintree_card_spec(email_address: str) -> Dict[str, str]:
    digest = _stable_hash(email_address)
    card_number = _DEMO_BRAINTREE_CARD_NUMBERS[digest % len(_DEMO_BRAINTREE_CARD_NUMBERS)]
    expiration_month = (digest % 12) + 1
    expiration_year = 2027 + ((digest // len(_DEMO_BRAINTREE_CARD_NUMBERS)) % 3)
    postal_code = f"{10000 + (digest % 89999):05d}"
    return {
        "number": card_number,
        "expiration_date": f"{expiration_month:02d}/{expiration_year}",
        "last4": card_number[-4:],
        "expiration_month": f"{expiration_month:02d}",
        "expiration_year": str(expiration_year),
        "postal_code": postal_code,
    }


def _find_matching_braintree_payment_method(customer, card_spec: Dict[str, str]):
    for payment_method in customer.payment_methods:
        if getattr(payment_method, "last_4", None) != card_spec["last4"]:
            continue
        if str(getattr(payment_method, "expiration_month", "")).zfill(2) != card_spec["expiration_month"]:
            continue
        if str(getattr(payment_method, "expiration_year", "")) != card_spec["expiration_year"]:
            continue
        return payment_method
    return None


def get_card_lookup_id(card: Dict) -> str:
    return str(
        card.get("lookup_id")
        or card.get("sys_id")
        or card.get("payment_profile_id")
        or card.get("customer_profile_id")
        or card.get("src")
        or "unknown-card"
    )


def _get_demo_braintree_card(tx, user: Dict) -> Dict:
    import braintree

    config = get_processor_config("braintree")
    environment = (
        braintree.Environment.Production
        if str(config.get("environment") or "sandbox").lower() == "production"
        else braintree.Environment.Sandbox
    )
    gateway = braintree.BraintreeGateway(
        braintree.Configuration(
            environment=environment,
            merchant_id=config["merchant_id"],
            public_key=config["public_key"],
            private_key=config["private_key"],
        )
    )

    demo_email = build_demo_profile_email(user["email_address"], "bt")
    card_spec = _build_demo_braintree_card_spec(user["email_address"])
    customer = None

    collection = gateway.customer.search(braintree.CustomerSearch.email == demo_email)
    for existing_customer in collection.items:
        customer = existing_customer
        payment_method = _find_matching_braintree_payment_method(
            existing_customer, card_spec
        )
        if payment_method:
            return _save_payment_profile(
                tx,
                {
                    "src": "BT",
                    "card_type": getattr(payment_method, "card_type", "Visa"),
                    "card_number": getattr(payment_method, "last_4", card_spec["last4"]),
                    "expiration_date": _format_expiration_date(
                        getattr(payment_method, "expiration_year", card_spec["expiration_year"]),
                        getattr(payment_method, "expiration_month", card_spec["expiration_month"]),
                    ),
                    "payment_profile_id": payment_method.token,
                    "customer_profile_id": payment_method.customer_id,
                    "email_address": user["email_address"],
                    "first_name": user.get("first_name")
                    or user["email_address"].split("@")[0],
                    "last_name": user.get("last_name") or "Demo",
                    "is_default": getattr(payment_method, "default", True),
                },
            )

    if customer is None:
        result = gateway.customer.create(
            {
                "email": demo_email,
                "first_name": user.get("first_name")
                or user["email_address"].split("@")[0],
                "last_name": user.get("last_name") or "Demo",
            }
        )
        if not result.is_success:
            raise RuntimeError(result.message)
        customer = result.customer

    payment_method_result = gateway.credit_card.create(
        {
            "customer_id": customer.id,
            "number": card_spec["number"],
            "expiration_date": card_spec["expiration_date"],
            "cvv": "123",
            "billing_address": {"postal_code": card_spec["postal_code"]},
            "options": {"make_default": True, "verify_card": True},
        }
    )
    if not payment_method_result.is_success:
        raise RuntimeError(payment_method_result.message)

    payment_method = payment_method_result.credit_card
    return _save_payment_profile(
        tx,
        {
            "src": "BT",
            "card_type": getattr(payment_method, "card_type", "Visa"),
            "card_number": getattr(payment_method, "last_4", card_spec["last4"]),
            "expiration_date": _format_expiration_date(
                getattr(payment_method, "expiration_year", card_spec["expiration_year"]),
                getattr(payment_method, "expiration_month", card_spec["expiration_month"]),
            ),
            "payment_profile_id": payment_method.token,
            "customer_profile_id": customer.id,
            "email_address": user["email_address"],
            "first_name": user.get("first_name")
            or user["email_address"].split("@")[0],
            "last_name": user.get("last_name") or "Demo",
            "is_default": True,
        },
    )


def _get_demo_stripe_card(tx, user: Dict) -> Dict:
    import stripe

    stripe_config = get_processor_config("stripe")
    api_key = stripe_config["api_key"]
    demo_email = build_demo_profile_email(user["email_address"], "st")
    full_name = user.get("full_name") or user["email_address"]

    customers = stripe.Customer.list(email=demo_email, limit=1, api_key=api_key)
    if customers.data:
        customer = customers.data[0]
    else:
        customer = stripe.Customer.create(
            email=demo_email,
            name=full_name,
            metadata={
                "platform": "caringcent",
                "environment": "demo",
                "source_email": user["email_address"],
            },
            api_key=api_key,
        )

    payment_methods = stripe.PaymentMethod.list(
        customer=customer.id, type="card", limit=1, api_key=api_key
    )
    if payment_methods.data:
        payment_method = payment_methods.data[0]
    else:
        payment_method = stripe.PaymentMethod.create(
            type="card",
            card={"token": _DEMO_STRIPE_TOKEN},
            billing_details={"email": demo_email, "name": full_name},
            api_key=api_key,
        )
        payment_method = stripe.PaymentMethod.attach(
            payment_method.id, customer=customer.id, api_key=api_key
        )
        stripe.Customer.modify(
            customer.id,
            invoice_settings={"default_payment_method": payment_method.id},
            api_key=api_key,
        )

    return _save_payment_profile(
        tx,
        {
            "src": "ST",
            "card_type": getattr(payment_method.card, "brand", "visa"),
            "card_number": getattr(payment_method.card, "last4", "4242"),
            "expiration_date": _format_expiration_date(
                getattr(payment_method.card, "exp_year", "2030"),
                getattr(payment_method.card, "exp_month", "12"),
            ),
            "payment_profile_id": payment_method.id,
            "customer_profile_id": customer.id,
            "email_address": user["email_address"],
            "first_name": user.get("first_name")
            or user["email_address"].split("@")[0],
            "last_name": user.get("last_name") or "Demo",
            "is_default": True,
        },
    )


def _get_demo_authorize_card(tx, user: Dict) -> Dict:
    from .authorizenet_adapter import AuthorizeNetAdapter

    adapter = AuthorizeNetAdapter(get_processor_config("authorizenet"))
    demo_email = build_demo_profile_email(user["email_address"], "an")
    customer_result = adapter.get_or_create_customer_profile(
        tx,
        {
            "email_address": demo_email,
            "name": user.get("full_name") or user["email_address"],
        },
    )
    customer_profile_id = customer_result["customer_profile_id"]
    existing = (
        tx.table("payment_profiles")
        .select(
            where={
                "src": "AN",
                "email_address": user["email_address"],
                "customer_profile_id": customer_profile_id,
            },
            orderby="is_default desc, sys_id desc",
        )
        .as_dict()
        .all()
    )
    if existing:
        return existing[0]

    payment_result = adapter.attach_payment_method(
        tx,
        customer_profile_id,
        "",
        {
            "card_number": _DEMO_AUTHORIZE_CARD_NUMBER,
            "expiration_date": _DEMO_AUTHORIZE_EXPIRATION,
            "card_code": _DEMO_AUTHORIZE_CARD_CODE,
            "first_name": user.get("first_name")
            or user["email_address"].split("@")[0],
            "last_name": user.get("last_name") or "Demo",
            "set_default": True,
        },
    )
    return _save_payment_profile(
        tx,
        {
            "src": "AN",
            "card_type": "Visa",
            "card_number": _DEMO_AUTHORIZE_CARD_NUMBER[-4:],
            "expiration_date": _DEMO_AUTHORIZE_EXPIRATION,
            "payment_profile_id": payment_result["payment_profile_id"],
            "customer_profile_id": customer_profile_id,
            "email_address": user["email_address"],
            "first_name": user.get("first_name")
            or user["email_address"].split("@")[0],
            "last_name": user.get("last_name") or "Demo",
            "is_default": True,
        },
    )


def get_demo_card_for_source(tx, user: Dict, source: str) -> Optional[Dict]:
    if source == "BT":
        return _get_demo_braintree_card(tx, user)
    if source == "ST":
        return _get_demo_stripe_card(tx, user)
    if source == "AN":
        return _get_demo_authorize_card(tx, user)
    return None


def resolve_demo_charge_cards(tx, user: Dict, payment_processor: str, cards: List[Dict]):
    if not is_demo_environment():
        return cards

    resolved_cards = []
    demo_cards_by_source = {}
    for card in cards:
        source = card.get("src")
        if source not in demo_cards_by_source:
            demo_cards_by_source[source] = get_demo_card_for_source(tx, user, source)
        demo_card = demo_cards_by_source[source]
        if demo_card:
            merged_card = dict(card)
            merged_card.update(demo_card)
            merged_card["lookup_id"] = demo_card.get("payment_profile_id")
            resolved_cards.append(merged_card)
        else:
            resolved_cards.append(card)

    if resolved_cards:
        return resolved_cards

    for source in get_payment_profile_sources(payment_processor):
        demo_card = get_demo_card_for_source(tx, user, source)
        if demo_card:
            demo_card["lookup_id"] = demo_card.get("payment_profile_id")
            return [demo_card]

    return cards