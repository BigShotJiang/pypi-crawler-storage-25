import importlib as _importlib
import os

DEBUG = (os.environ.get("ENV") != "production") or (os.environ.get("DEBUG") == "Y")


# This is helpful for running HTTPS clients on lambda.
if os.path.exists("/opt/python/ca-certificates.crt"):
    os.environ["REQUESTS_CA_BUNDLE"] = "/opt/python/ca-certificates.crt"


class AWS(object):
    # Get AWS EC2 Instance ID. Must run this from the EC2 instance itself to get the ID
    @staticmethod
    def instance_id(cls):
        import requests
        response = requests.get("http://169.254.169.254/latest/meta-data/instance-id")
        instance_id = response.text
        return instance_id


# Lazy-load heavy modules (boto3-dependent) on first access
_LAZY_ATTRS = {
    "AmplifyProject": "velocity.aws.amplify",
    "BackendDeploymentConfig": "velocity.aws.amplify_build",
    "build_environment_variables": "velocity.aws.amplify_build",
    "get_amplify_app_id_and_branch": "velocity.aws.amplify_build",
    "initialize_build_environment": "velocity.aws.amplify_build",
    "run_backend_deployment": "velocity.aws.amplify_build",
    "update_lambda_layers_to_latest": "velocity.aws.amplify_build",
}


def __getattr__(name: str):
    if name in _LAZY_ATTRS:
        module = _importlib.import_module(_LAZY_ATTRS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "AmplifyProject",
    "AWS",
    "BackendDeploymentConfig",
    "build_environment_variables",
    "get_amplify_app_id_and_branch",
    "initialize_build_environment",
    "run_backend_deployment",
    "update_lambda_layers_to_latest",
]
