"""
R15 — Async Support for velocity-python.

Provides async versions of the core database classes that leverage
psycopg v3's native ``AsyncConnection`` / ``AsyncCursor``.

Usage::

    engine = initialize(...)  # normal sync Engine

    async with engine.async_transaction() as tx:
        result = await tx.table("orders").select(where={"status": "pending"})
        rows = await result.all()

    # Parallel queries via gather():
    async with engine.async_transaction() as tx:
        orders, payments = await tx.gather(
            tx.table("orders").select(where={"user_id": 1}),
            tx.table("payments").select(where={"user_id": 1}),
        )

The sync API is unchanged and remains the default.  Async classes are
opt-in and only imported when needed.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time as _time
from collections import OrderedDict
from collections.abc import Mapping
from typing import Any

from velocity.db.core.row import Row
from velocity.db import exceptions

_logger = logging.getLogger("velocity.db.async")

# Reuse thresholds from the sync transaction module.
_SLOW_QUERY_MS = int(os.environ.get("VELOCITY_SLOW_QUERY_MS", "500"))
_N_PLUS_1_THRESHOLD = int(os.environ.get("VELOCITY_N_PLUS_1_THRESHOLD", "10"))
_DEFAULT_QUERY_CACHE_SIZE = int(os.environ.get("VELOCITY_QUERY_CACHE_SIZE", "100"))


# ──────────────────────────────────────────────────────────────────────
# AsyncResult
# ──────────────────────────────────────────────────────────────────────


class AsyncResult:
    """Async wrapper around a psycopg ``AsyncCursor``.

    Mirrors the sync :class:`Result` API but all data-fetching methods
    are coroutines.
    """

    def __init__(self, cursor, tx=None, sql=None, params=None):
        self._cursor = cursor
        self._tx = tx
        self._sql = sql
        self._params = params
        self._headers: list[str] = []
        self._exhausted = False
        self._initialised = False
        self.transform = lambda row: dict(zip(self.headers, row))

    async def _init(self):
        """Lazily resolve headers from cursor description.

        Must be called *after* the execute that created this result
        (the cursor description is only available after execute completes).
        """
        if self._initialised:
            return
        self._initialised = True
        try:
            description = getattr(self._cursor, "description", None) or []
            for col in description:
                if hasattr(col, "name"):
                    self._headers.append(col.name.lower())
                elif hasattr(col, "__getitem__"):
                    self._headers.append(col[0].lower())
                else:
                    self._headers.append(f"column_{len(self._headers)}")
        except (AttributeError, TypeError, IndexError):
            pass

    @property
    def headers(self) -> list[str]:
        return self._headers

    @property
    def sql(self):
        return self._sql

    @property
    def params(self):
        return self._params

    # ── Transforms ────────────────────────────────────────────────

    def as_dict(self) -> AsyncResult:
        self.transform = lambda row: dict(zip(self.headers, row))
        return self

    def as_list(self) -> AsyncResult:
        self.transform = lambda row: list(row)
        return self

    def as_tuple(self) -> AsyncResult:
        self.transform = lambda row: row
        return self

    def as_rows(self, table: AsyncTable) -> AsyncResult:
        """Transform rows into :class:`Row` objects with pre-populated caches."""
        self.as_dict()
        _orig = self.transform
        self.transform = lambda raw: Row._from_data(table._sync_table, _orig(raw))
        return self

    # ── Fetching ──────────────────────────────────────────────────

    async def fetchone(self):
        """Fetch and transform a single row, or return ``None``."""
        await self._init()
        if self._exhausted or not self._cursor:
            return None
        raw = await self._cursor.fetchone()
        if raw is None:
            self._exhausted = True
            return None
        return self.transform(raw)

    async def all(self) -> list:
        """Fetch all remaining rows into a list."""
        await self._init()
        if self._exhausted or not self._cursor:
            return []
        raw_rows = await self._cursor.fetchall()
        self._exhausted = True
        return [self.transform(r) for r in raw_rows]

    async def one(self, default=None):
        """Return the first row, or *default*."""
        row = await self.fetchone()
        self._exhausted = True
        return row if row is not None else default

    async def scalar(self, default=None):
        """Return the first column of the first row, or *default*."""
        await self._init()
        if self._exhausted or not self._cursor:
            return default
        raw = await self._cursor.fetchone()
        self._exhausted = True
        if raw is None:
            return default
        return raw[0]

    def __aiter__(self):
        return self

    async def __anext__(self):
        if not self._initialised:
            await self._init()
        row = await self.fetchone()
        if row is None:
            raise StopAsyncIteration
        return row

    async def close(self):
        if self._cursor:
            await self._cursor.close()
            self._cursor = None
        self._exhausted = True


# ──────────────────────────────────────────────────────────────────────
# AsyncTable
# ──────────────────────────────────────────────────────────────────────


class AsyncTable:
    """Async facade over a database table.

    Provides the most-used CRUD operations as coroutines.  Less-common
    DDL / metadata helpers remain on the sync :class:`Table` (accessible
    via ``._sync_table``).
    """

    def __init__(self, tx: AsyncTransaction, name: str):
        self._tx = tx
        self.name = name.lower()
        self.sql = tx.engine.sql
        # Lazily-constructed sync Table for methods we delegate to
        self._sync_table_obj = None

    @property
    def _sync_table(self):
        """Return a lightweight sync Table for Row construction etc."""
        if self._sync_table_obj is None:
            from velocity.db.core.table import Table
            # Build a minimal sync table — uses the tx's sync fallback cursor
            self._sync_table_obj = _SyncTableProxy(self._tx, self.name, self.sql)
        return self._sync_table_obj

    # ── SELECT ────────────────────────────────────────────────────

    async def select(
        self,
        columns=None,
        where=None,
        orderby=None,
        groupby=None,
        having=None,
        start=None,
        qty=None,
        lock=None,
        skip_locked=None,
    ) -> AsyncResult:
        """Async SELECT returning an :class:`AsyncResult`."""
        sql, vals = self.sql.select(
            self._tx._sync_tx_proxy,
            columns=columns,
            table=self.name,
            where=where,
            orderby=orderby,
            groupby=groupby,
            having=having,
            start=start,
            qty=qty,
            lock=lock,
            skip_locked=skip_locked,
        )
        return await self._tx.execute(sql, vals)

    async def select_rows(
        self, where=None, orderby=None, qty=None, lock=None, skip_locked=None,
    ) -> list[Row]:
        """Fetch rows as pre-populated :class:`Row` objects (no N+1)."""
        result = await self.select(
            where=where, orderby=orderby, qty=qty, lock=lock, skip_locked=skip_locked,
        )
        dicts = await result.all()
        return [Row._from_data(self._sync_table, d) for d in dicts]

    async def count(self, where=None) -> int:
        """Return count of matching rows."""
        sql, vals = self.sql.select(
            self._tx._sync_tx_proxy,
            columns="count(*)", table=self.name, where=where,
        )
        result = await self._tx.execute(sql, vals)
        return await result.scalar()

    # ── INSERT ────────────────────────────────────────────────────

    async def insert(self, data, **kwds):
        """Insert a single row."""
        sql, vals = self.sql.insert(self.name, data)
        if kwds.get("sql_only"):
            return sql, vals
        result = await self._tx.execute(sql, vals)
        self._tx.invalidate_cache(self.name)
        return result._cursor.rowcount if result._cursor else 0

    async def insert_many(self, rows, page_size=1000):
        """Insert multiple rows in a single batched statement."""
        if not rows:
            return 0
        sql, args_list, template = self.sql.insert_many(self.name, rows)
        total = await self._tx._execute_values(sql, args_list, template, page_size)
        self._tx.invalidate_cache(self.name)
        return total

    # ── UPDATE ────────────────────────────────────────────────────

    async def update(self, data, where=None, pk=None, **kwds):
        """Update rows matching *where*/*pk*."""
        actual_where = pk or where
        sql, vals = self.sql.update(self.name, data, actual_where)
        if kwds.get("sql_only"):
            return sql, vals
        result = await self._tx.execute(sql, vals)
        self._tx.invalidate_cache(self.name)
        return result._cursor.rowcount if result._cursor else 0

    async def update_or_insert(self, update_data, insert_data=None, where=None, pk=None):
        """Update existing row, or insert if none found."""
        actual_where = pk or where
        rowcount = await self.update(update_data, where=actual_where)
        if rowcount:
            return rowcount
        combined = dict(actual_where or {})
        combined.update(update_data)
        if insert_data:
            combined.update(insert_data)
        return await self.insert(combined)

    # ── DELETE ────────────────────────────────────────────────────

    async def delete(self, where, **kwds):
        """Delete rows matching *where*."""
        sql, vals = self.sql.delete(self.name, where)
        if kwds.get("sql_only"):
            return sql, vals
        result = await self._tx.execute(sql, vals)
        self._tx.invalidate_cache(self.name)
        return result._cursor.rowcount if result._cursor else 0

    # ── MERGE / UPSERT ───────────────────────────────────────────

    async def merge(self, data, pk=None, **kwds):
        """Upsert a single row via ON CONFLICT DO UPDATE."""
        if pk is None:
            pk = self.sql.primary_keys(self._tx._sync_tx_proxy, self.name)
        sql, vals = self.sql.merge(self.name, data, pk)
        if kwds.get("sql_only"):
            return sql, vals
        result = await self._tx.execute(sql, vals)
        self._tx.invalidate_cache(self.name)
        return result._cursor.rowcount if result._cursor else 0

    # ── Row helpers ───────────────────────────────────────────────

    async def find(self, where, lock=None):
        """Find a single row, return as Row or None."""
        result = await self.select("sys_id", where=where, qty=2, lock=lock)
        rows = await result.all()
        if not rows:
            return None
        if len(rows) > 1:
            raise exceptions.DuplicateRowsFoundError(
                f"More than one entry found in {self.name}."
            )
        return Row._from_data(self._sync_table, rows[0])

    async def ids(self, where=None, orderby=None, qty=None, lock=None, skip_locked=None):
        """Return list of sys_id values for matching rows."""
        result = await self.select(
            "sys_id", where=where, orderby=orderby, qty=qty,
            lock=lock, skip_locked=skip_locked,
        )
        rows = await result.all()
        return [r["sys_id"] for r in rows]


class _SyncTableProxy:
    """Minimal object that satisfies Row._from_data(table, ...) requirements.

    Row only needs ``table.name`` for its ``__eq__``/``__hash__`` and
    ``table.select()``, ``table.update_or_insert()`` etc. for write-through.
    This proxy provides just enough interface so pre-populated Rows work.
    """

    def __init__(self, async_tx, name, sql):
        self.name = name.lower()
        self.sql = sql
        self._async_tx = async_tx
        self.tx = _SyncTxStub(async_tx)

    def select(self, **kwargs):
        raise RuntimeError(
            "Cannot perform sync select on an async-created Row. "
            "Use the async table methods instead."
        )

    def update_or_insert(self, data, pk=None):
        raise RuntimeError(
            "Cannot perform sync write on an async-created Row. "
            "Use the async table methods instead."
        )

    def get_value(self, column, pk):
        raise RuntimeError(
            "Cannot perform sync get_value on an async-created Row. "
            "Use the async table methods instead."
        )


class _SyncTxStub:
    """Minimal stub so SQL builders that need tx.engine can work."""

    def __init__(self, async_tx):
        self.engine = async_tx.engine


# ──────────────────────────────────────────────────────────────────────
# AsyncTransaction
# ──────────────────────────────────────────────────────────────────────


class AsyncTransaction:
    """Async counterpart to :class:`Transaction`.

    Opens a ``psycopg.AsyncConnection`` and provides async query execution,
    commit/rollback, and a ``gather()`` helper for parallel queries.

    Usage::

        async with engine.async_transaction() as tx:
            result = await tx.table("orders").select(where={"status": "active"})
            rows = await result.all()
    """

    def __init__(self, engine):
        self.engine = engine
        self.connection = None
        self._query_count = 0
        self._query_time_ms = 0.0
        # R5 — query cache (mirrors sync Transaction)
        self._query_cache: OrderedDict = OrderedDict()
        self._query_cache_max = _DEFAULT_QUERY_CACHE_SIZE
        # R14 — N+1 tracking
        self._table_select_counts: dict[str, int] = {}
        self._n1_warned: set[str] = set()
        # Proxy object for SQL builders that expect a sync-like tx
        self._sync_tx_proxy = _SyncTxStub(self)

    async def __aenter__(self):
        await self._ensure_connection()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            await self.rollback()
        await self.close()

    async def _ensure_connection(self):
        """Open an async connection if not already open."""
        if self.connection is not None:
            return

        try:
            import psycopg
        except ImportError as exc:
            raise ImportError(
                "psycopg v3 required for async support. "
                "Install with: pip install velocity-python[postgres]"
            ) from exc

        config = self.engine.config
        if isinstance(config, dict):
            timeout = config.get(
                "connect_timeout",
                int(os.environ.get("VELOCITY_CONNECT_TIMEOUT", "5")),
            )
            conn_config = config.copy()
            conn_config.setdefault("connect_timeout", timeout)
            # autocommit=False by default — we manage transactions explicitly
            self.connection = await psycopg.AsyncConnection.connect(
                **conn_config, autocommit=False,
            )
        elif isinstance(config, str):
            self.connection = await psycopg.AsyncConnection.connect(
                config, autocommit=False,
            )
        else:
            raise TypeError(f"Unsupported config type for async connection: {type(config)}")

    async def execute(self, sql, parms=None, prepare=None) -> AsyncResult:
        """Execute SQL and return an :class:`AsyncResult`."""
        await self._ensure_connection()

        # Resolve prepare flag
        if prepare is None:
            prepare = getattr(self.engine, "prepare_enabled", False)

        cursor = self.connection.cursor()
        t0 = _time.perf_counter()
        try:
            if parms:
                await cursor.execute(sql, parms, prepare=prepare)
            else:
                await cursor.execute(sql, prepare=prepare)
        except TypeError:
            # Driver may not support prepare kwarg
            try:
                if parms:
                    await cursor.execute(sql, parms)
                else:
                    await cursor.execute(sql)
            except Exception as e:
                raise self.engine.process_error(e, sql, parms)
        except Exception as e:
            raise self.engine.process_error(e, sql, parms)

        elapsed_ms = (_time.perf_counter() - t0) * 1000
        self._query_count += 1
        self._query_time_ms += elapsed_ms

        # R12 — Slow query logging
        if _SLOW_QUERY_MS and elapsed_ms > _SLOW_QUERY_MS:
            _logger.warning(
                "Slow async query: %.1f ms sql=%s",
                elapsed_ms, sql[:200],
                extra={"query_duration_ms": round(elapsed_ms, 1)},
            )

        # R14 — N+1 detection
        if _N_PLUS_1_THRESHOLD:
            from velocity.db.core.transaction import _classify_sql, _extract_table_name
            op = _classify_sql(sql)
            if op == "SELECT":
                tbl = _extract_table_name(sql)
                if tbl:
                    self._table_select_counts[tbl] = self._table_select_counts.get(tbl, 0) + 1
                    count = self._table_select_counts[tbl]
                    if count > _N_PLUS_1_THRESHOLD and tbl not in self._n1_warned:
                        self._n1_warned.add(tbl)
                        _logger.warning(
                            "Possible N+1: table %s queried %d times in async transaction",
                            tbl, count,
                        )

        result = AsyncResult(cursor, self, sql, parms)
        await result._init()
        return result

    async def _execute_values(self, sql, args_list, template=None, page_size=1000):
        """Async multi-row VALUES expansion (mirrors sync ``_execute_values``)."""
        await self._ensure_connection()

        if not template:
            ncols = len(args_list[0]) if args_list else 0
            template = "(" + ", ".join(["%s"] * ncols) + ")"

        cursor = self.connection.cursor()
        total = 0
        try:
            for offset in range(0, len(args_list), page_size):
                page = args_list[offset: offset + page_size]
                values_clause = ", ".join([template] * len(page))
                query = sql.replace("%s", values_clause, 1)
                flat_params = []
                for row in page:
                    flat_params.extend(row)
                await cursor.execute(query, flat_params)
                total += cursor.rowcount
        except Exception as e:
            raise self.engine.process_error(e, sql, args_list)
        return total

    async def commit(self):
        """Commit the async transaction."""
        if self.connection:
            await self.connection.commit()
            if self._query_count:
                _logger.debug(
                    "Async transaction commit: %d queries in %.1f ms",
                    self._query_count, self._query_time_ms,
                )

    async def rollback(self):
        """Rollback the async transaction."""
        if self.connection:
            try:
                await self.connection.rollback()
            except Exception:
                pass

    async def close(self):
        """Commit (if needed) and close the async connection."""
        if self.connection:
            try:
                await self.commit()
            except Exception:
                pass
            try:
                await self.connection.close()
            except Exception:
                pass
            self.connection = None

    # ── Factory methods ───────────────────────────────────────────

    def table(self, name: str) -> AsyncTable:
        """Return an :class:`AsyncTable` for the given table name."""
        return AsyncTable(self, name)

    # ── Parallel query helper (Phase 3) ───────────────────────────

    async def gather(self, *coroutines):
        """Execute multiple async queries in parallel.

        Each argument should be an *awaitable* (typically a coroutine
        returned by an ``await``-less call to an async table method).

        Returns results in the same order as the arguments::

            async with engine.async_transaction() as tx:
                orders, payments = await tx.gather(
                    tx.table("orders").select(where={"user_id": 1}),
                    tx.table("payments").select(where={"user_id": 1}),
                )

        .. note::

           psycopg v3 ``AsyncConnection`` does NOT support true concurrent
           queries on a *single* connection (PostgreSQL protocol limitation).
           ``gather()`` currently executes sequentially on the shared
           connection.  For true parallelism, use separate transactions
           (separate connections).  This helper is still useful for:

           - Readability / intent (declaring queries are independent)
           - Future-proofing (parallel execution when using pipeline mode)
           - Overlapping DB I/O with ``asyncio.create_task`` for other
             non-DB coroutines
        """
        results = []
        for coro in coroutines:
            results.append(await coro)
        return tuple(results)

    # ── Query cache (R5 mirrors) ──────────────────────────────────

    def _cache_key(self, sql, parms):
        if parms is None:
            return (sql,)
        if isinstance(parms, dict):
            return (sql, tuple(sorted(parms.items())))
        return (sql, tuple(parms))

    def _cache_get(self, key):
        if key in self._query_cache:
            self._query_cache.move_to_end(key)
            return self._query_cache[key]
        return None

    def _cache_put(self, key, rows):
        self._query_cache[key] = rows
        self._query_cache.move_to_end(key)
        while len(self._query_cache) > self._query_cache_max:
            self._query_cache.popitem(last=False)

    def invalidate_cache(self, table_name=None):
        if table_name is None:
            self._query_cache.clear()
            return
        tbl_lower = table_name.lower()
        to_remove = [k for k in self._query_cache if tbl_lower in k[0].lower()]
        for k in to_remove:
            del self._query_cache[k]
