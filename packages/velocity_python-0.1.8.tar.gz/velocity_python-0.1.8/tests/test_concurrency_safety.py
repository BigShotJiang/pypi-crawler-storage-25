"""
Tests for R4 — Concurrency & Lambda Safety.

Covers:
- IF NOT EXISTS in DDL (create_table, alter_add, create index)
- Thread-safe schema_locked property
- reset_id_on_dup_key increased retries (10)
- @create_missing DbObjectExistsError handling
- Advisory lock helper
"""

import hashlib
import threading
import pytest
from unittest.mock import MagicMock, patch, call

from velocity.db import exceptions
from velocity.db.core.decorators import (
    create_missing,
    reset_id_on_dup_key,
    retry_on_dup_key,
)
from velocity.db.servers.postgres.sql import SQL


# ── DDL IF NOT EXISTS tests ─────────────────────────────────────────


class TestCreateTableIfNotExists:
    """Verify CREATE TABLE uses IF NOT EXISTS."""

    def test_create_table_has_if_not_exists(self):
        sql, _ = SQL.create_table("test_table")
        assert "CREATE TABLE IF NOT EXISTS" in sql

    def test_create_table_with_drop(self):
        sql, _ = SQL.create_table("test_table", drop=True)
        assert "DROP TABLE" in sql
        assert "CREATE TABLE IF NOT EXISTS" in sql

    def test_create_table_columns_use_if_not_exists(self):
        sql, _ = SQL.create_table("test_table", {"name": "Alice", "age": 30})
        assert "ADD COLUMN IF NOT EXISTS" in sql

    def test_create_index_has_if_not_exists(self):
        sql, _ = SQL.create_table("test_table")
        assert "CREATE INDEX IF NOT EXISTS" in sql

    def test_create_table_with_schema(self):
        sql, _ = SQL.create_table("myschema.test_table")
        assert "CREATE TABLE IF NOT EXISTS" in sql


class TestAlterAddIfNotExists:
    """Verify ALTER TABLE ADD COLUMN uses IF NOT EXISTS."""

    def test_alter_add_has_if_not_exists(self):
        sql, _ = SQL.alter_add("test_table", {"name": "Alice"})
        assert "IF NOT EXISTS" in sql

    def test_alter_add_now_has_if_not_exists(self):
        sql, _ = SQL.alter_add("test_table", {"created": "@@now()"})
        assert "IF NOT EXISTS" in sql


# ── Thread-safe schema_locked tests ─────────────────────────────────


class TestSchemaLockedThreadSafety:
    """Verify schema_locked uses proper locking."""

    def _make_engine(self, locked=False):
        from velocity.db.core.engine import Engine
        engine = Engine.__new__(Engine)
        engine._Engine__schema_locked = locked
        engine._Engine__schema_lock = threading.Lock()
        return engine

    def test_schema_locked_default_false(self):
        engine = self._make_engine()
        assert engine.schema_locked is False

    def test_lock_unlock_schema(self):
        engine = self._make_engine()
        engine.lock_schema()
        assert engine.schema_locked is True
        engine.unlock_schema()
        assert engine.schema_locked is False

    def test_unlocked_schema_context_manager(self):
        engine = self._make_engine(locked=True)
        assert engine.schema_locked is True
        with engine.unlocked_schema():
            assert engine.schema_locked is False
        assert engine.schema_locked is True

    def test_unlocked_schema_restores_on_exception(self):
        engine = self._make_engine(locked=True)
        with pytest.raises(ValueError):
            with engine.unlocked_schema():
                raise ValueError("boom")
        assert engine.schema_locked is True

    def test_concurrent_lock_unlock(self):
        """Multiple threads toggling schema_locked shouldn't corrupt state."""
        engine = self._make_engine()
        errors = []

        def toggle(n):
            try:
                for _ in range(100):
                    engine.lock_schema()
                    _ = engine.schema_locked
                    engine.unlock_schema()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=toggle, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert engine.schema_locked is False


# ── reset_id_on_dup_key retries tests ───────────────────────────────


class TestResetIdOnDupKeyRetries:
    """Verify reset_id_on_dup_key allows up to 10 retries."""

    def _make_table(self, fail_count):
        """Create a mock Table whose insert fails fail_count times."""
        table = MagicMock()
        table.tx = MagicMock()
        table.tx.create_savepoint = MagicMock(return_value="sp")
        table.tx.release_savepoint = MagicMock()
        table.tx.rollback_savepoint = MagicMock()
        table.cursor = MagicMock(return_value=MagicMock())
        table.set_sequence = MagicMock()
        table.max = MagicMock(return_value=1000)

        self._call_count = 0
        self._fail_count = fail_count
        return table

    def test_retries_up_to_10(self):
        """Should succeed after up to 10 retries."""
        table = self._make_table(9)

        @reset_id_on_dup_key
        def fake_insert(self_, data):
            self._call_count += 1
            if self._call_count <= self._fail_count:
                raise exceptions.DbDuplicateKeyError("duplicate key sys_id")
            return 1

        with patch("velocity.db.core.decorators.time.sleep"):
            result = fake_insert(table, data={"name": "test"})

        assert result == 1
        assert self._call_count == 10  # 9 fails + 1 success

    def test_fails_after_10_retries(self):
        """Should raise after 10+ failures."""
        table = self._make_table(11)

        @reset_id_on_dup_key
        def fake_insert(self_, data):
            self._call_count += 1
            raise exceptions.DbDuplicateKeyError("duplicate key sys_id")

        with patch("velocity.db.core.decorators.time.sleep"):
            with pytest.raises(exceptions.DbDuplicateKeyError):
                fake_insert(table, data={"name": "test"})

        # 1 initial + 10 retries = 11 calls
        assert self._call_count == 11

    def test_explicit_sys_id_not_retried(self):
        """If sys_id is in data, should not retry."""
        table = self._make_table(1)

        @reset_id_on_dup_key
        def fake_insert(self_, data):
            raise exceptions.DbDuplicateKeyError("duplicate key sys_id")

        with pytest.raises(exceptions.DbDuplicateKeyError):
            fake_insert(table, data={"sys_id": 42, "name": "test"})


# ── @create_missing DbObjectExistsError handling ────────────────────


class TestCreateMissingRaceHandling:
    """Verify @create_missing handles DbObjectExistsError during DDL."""

    def _make_table(self):
        table = MagicMock()
        table.name = "test_table"
        table.tx = MagicMock()
        table.tx.create_savepoint = MagicMock(return_value="sp")
        table.tx.release_savepoint = MagicMock()
        table.tx.rollback_savepoint = MagicMock()
        table.tx.advisory_lock = MagicMock()
        table.tx.engine = MagicMock()
        table.tx.engine.schema_locked = False
        table.cursor = MagicMock(return_value=MagicMock())
        table.alter = MagicMock()
        table.create = MagicMock()
        return table

    def test_column_missing_then_alter_succeeds(self):
        """Normal path: column missing → alter → retry succeeds."""
        table = self._make_table()
        call_count = [0]

        @create_missing
        def fake_insert(self_, data):
            call_count[0] += 1
            if call_count[0] == 1:
                raise exceptions.DbColumnMissingError("column foo missing")
            return 1

        result = fake_insert(table, {"foo": "bar"})
        assert result == 1
        table.alter.assert_called_once()
        table.tx.advisory_lock.assert_called_once_with("velocity_ddl_test_table")

    def test_column_missing_alter_raises_exists(self):
        """Race condition: alter raises DbObjectExistsError → still retries."""
        table = self._make_table()
        table.alter.side_effect = exceptions.DbObjectExistsError("already exists")
        call_count = [0]

        @create_missing
        def fake_insert(self_, data):
            call_count[0] += 1
            if call_count[0] == 1:
                raise exceptions.DbColumnMissingError("column foo missing")
            return 1

        result = fake_insert(table, {"foo": "bar"})
        assert result == 1
        assert call_count[0] == 2

    def test_table_missing_then_create_succeeds(self):
        """Normal path: table missing → create → retry succeeds."""
        table = self._make_table()
        call_count = [0]

        @create_missing
        def fake_insert(self_, data):
            call_count[0] += 1
            if call_count[0] == 1:
                raise exceptions.DbTableMissingError("table missing")
            return 1

        result = fake_insert(table, {"foo": "bar"})
        assert result == 1
        table.create.assert_called_once()
        table.tx.advisory_lock.assert_called_once_with("velocity_ddl_test_table")

    def test_table_missing_create_raises_exists(self):
        """Race condition: create raises DbObjectExistsError → still retries."""
        table = self._make_table()
        table.create.side_effect = exceptions.DbObjectExistsError("already exists")
        call_count = [0]

        @create_missing
        def fake_insert(self_, data):
            call_count[0] += 1
            if call_count[0] == 1:
                raise exceptions.DbTableMissingError("table missing")
            return 1

        result = fake_insert(table, {"foo": "bar"})
        assert result == 1
        assert call_count[0] == 2

    def test_schema_locked_raises(self):
        """When schema is locked, should raise DbSchemaLockedError."""
        table = self._make_table()
        table.tx.engine.schema_locked = True

        @create_missing
        def fake_insert(self_, data):
            raise exceptions.DbTableMissingError("table missing")

        with pytest.raises(exceptions.DbSchemaLockedError):
            fake_insert(table, {"foo": "bar"})

    def test_advisory_lock_failure_is_nonfatal(self):
        """If advisory_lock raises, DDL should still proceed."""
        table = self._make_table()
        table.tx.advisory_lock.side_effect = Exception("not postgres")
        call_count = [0]

        @create_missing
        def fake_insert(self_, data):
            call_count[0] += 1
            if call_count[0] == 1:
                raise exceptions.DbTableMissingError("table missing")
            return 1

        result = fake_insert(table, {"foo": "bar"})
        assert result == 1
        table.create.assert_called_once()


# ── Advisory lock tests ─────────────────────────────────────────────


class TestAdvisoryLock:
    """Tests for Transaction.advisory_lock()."""

    def test_integer_key(self):
        from velocity.db.core.transaction import Transaction

        engine = MagicMock()
        engine.pool_enabled = False
        conn = MagicMock()
        tx = Transaction(engine, connection=conn)

        mock_cursor = MagicMock()
        tx.cursor = MagicMock(return_value=mock_cursor)

        # Mock _execute to capture the call
        with patch.object(tx, "_execute") as mock_exec:
            tx.advisory_lock(42)

        mock_exec.assert_called_once_with(
            "SELECT pg_advisory_xact_lock(%s)", (42,)
        )

    def test_string_key_hashed(self):
        from velocity.db.core.transaction import Transaction

        engine = MagicMock()
        engine.pool_enabled = False
        conn = MagicMock()
        tx = Transaction(engine, connection=conn)

        with patch.object(tx, "_execute") as mock_exec:
            tx.advisory_lock("velocity_ddl_my_table")

        # Verify the key is a hashed integer
        args = mock_exec.call_args[0]
        assert args[0] == "SELECT pg_advisory_xact_lock(%s)"
        key = args[1][0]
        assert isinstance(key, int)

        # Verify it's deterministic
        digest = hashlib.sha256(b"velocity_ddl_my_table").digest()
        expected = int.from_bytes(digest[:8], byteorder="big", signed=True)
        assert key == expected

    def test_same_string_same_key(self):
        """Same string should always produce the same lock key."""
        from velocity.db.core.transaction import Transaction

        engine = MagicMock()
        engine.pool_enabled = False

        keys = []
        for _ in range(3):
            tx = Transaction(engine, connection=MagicMock())
            with patch.object(tx, "_execute") as mock_exec:
                tx.advisory_lock("test_lock")
            keys.append(mock_exec.call_args[0][1][0])

        assert keys[0] == keys[1] == keys[2]
