"""
Tests for R15 — Async Support.

Covers:
- AsyncResult: transforms, fetching, iteration
- AsyncTable: select, insert, update, delete, merge, count, find, ids, select_rows
- AsyncTransaction: context manager, execute, commit, rollback, gather, cache
- Engine.async_transaction() integration
- N+1 detection in async mode
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

from velocity.db.core.async_support import (
    AsyncResult,
    AsyncTable,
    AsyncTransaction,
    _SyncTableProxy,
)
from velocity.db.core.row import Row


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────


def _make_async_cursor(rows, columns):
    """Create a mock async cursor that yields *rows* with *columns*."""
    cursor = AsyncMock()
    col_desc = [MagicMock(name=c) for c in columns]
    for desc, name in zip(col_desc, columns):
        desc.name = name
    cursor.description = col_desc
    cursor.fetchone = AsyncMock(side_effect=[*rows, None])
    cursor.fetchall = AsyncMock(return_value=list(rows))
    cursor.rowcount = len(rows)
    cursor.close = AsyncMock()
    return cursor


def _make_mock_conn(cursor=None):
    """Create a mock AsyncConnection.

    cursor() is synchronous in psycopg v3 even on AsyncConnection,
    so we use a plain MagicMock with async commit/rollback/close.
    """
    conn = MagicMock()
    if cursor is not None:
        conn.cursor.return_value = cursor
    conn.commit = AsyncMock()
    conn.rollback = AsyncMock()
    conn.close = AsyncMock()
    return conn


def _make_engine(config=None):
    """Build a mock Engine suitable for async tests."""
    engine = MagicMock()
    engine.config = config or {
        "dbname": "testdb",
        "host": "localhost",
        "user": "test",
        "password": "test",
    }
    engine.sql = MagicMock()
    engine.sql.server = "PostgreSQL"
    engine.prepare_enabled = False
    engine.process_error = MagicMock(side_effect=lambda e, *a: e)
    return engine


# ──────────────────────────────────────────────────────────────────────
# AsyncResult
# ──────────────────────────────────────────────────────────────────────


class TestAsyncResult:
    @pytest.mark.asyncio
    async def test_all_as_dict(self):
        rows = [(1, "Alice"), (2, "Bob")]
        cursor = _make_async_cursor(rows, ["sys_id", "name"])
        result = AsyncResult(cursor)
        data = await result.all()
        assert len(data) == 2
        assert data[0] == {"sys_id": 1, "name": "Alice"}
        assert data[1] == {"sys_id": 2, "name": "Bob"}

    @pytest.mark.asyncio
    async def test_one(self):
        cursor = _make_async_cursor([(42, "test")], ["sys_id", "name"])
        result = AsyncResult(cursor)
        row = await result.one()
        assert row == {"sys_id": 42, "name": "test"}

    @pytest.mark.asyncio
    async def test_one_empty(self):
        cursor = _make_async_cursor([], ["sys_id"])
        result = AsyncResult(cursor)
        row = await result.one(default="missing")
        assert row == "missing"

    @pytest.mark.asyncio
    async def test_scalar(self):
        cursor = _make_async_cursor([(99,)], ["count"])
        result = AsyncResult(cursor)
        val = await result.scalar()
        assert val == 99

    @pytest.mark.asyncio
    async def test_scalar_empty(self):
        cursor = _make_async_cursor([], ["count"])
        result = AsyncResult(cursor)
        val = await result.scalar(default=0)
        assert val == 0

    @pytest.mark.asyncio
    async def test_as_list(self):
        cursor = _make_async_cursor([(1, "a")], ["id", "name"])
        result = AsyncResult(cursor)
        result.as_list()
        data = await result.all()
        assert data == [[1, "a"]]

    @pytest.mark.asyncio
    async def test_as_tuple(self):
        cursor = _make_async_cursor([(1, "a")], ["id", "name"])
        result = AsyncResult(cursor)
        result.as_tuple()
        data = await result.all()
        assert data == [(1, "a")]

    @pytest.mark.asyncio
    async def test_as_rows(self):
        cursor = _make_async_cursor([(1, "Alice")], ["sys_id", "name"])
        table = MagicMock()
        table.name = "users"
        async_table = MagicMock()
        async_table._sync_table = table

        result = AsyncResult(cursor)
        result.as_rows(async_table)
        data = await result.all()
        assert len(data) == 1
        assert isinstance(data[0], Row)
        assert data[0]["name"] == "Alice"
        table.select.assert_not_called()

    @pytest.mark.asyncio
    async def test_async_iteration(self):
        rows = [(1,), (2,), (3,)]
        cursor = _make_async_cursor(rows, ["id"])
        result = AsyncResult(cursor)
        result.as_dict()

        collected = []
        async for row in result:
            collected.append(row)
        assert len(collected) == 3
        assert collected[0] == {"id": 1}

    @pytest.mark.asyncio
    async def test_close(self):
        cursor = _make_async_cursor([], ["id"])
        result = AsyncResult(cursor)
        await result.close()
        assert result._exhausted
        assert result._cursor is None

    @pytest.mark.asyncio
    async def test_headers(self):
        cursor = _make_async_cursor([], ["SYS_ID", "Name"])
        result = AsyncResult(cursor)
        await result._init()
        assert result.headers == ["sys_id", "name"]


# ──────────────────────────────────────────────────────────────────────
# AsyncTransaction
# ──────────────────────────────────────────────────────────────────────


class TestAsyncTransaction:
    @pytest.mark.asyncio
    async def test_context_manager_connect_and_close(self):
        engine = _make_engine()

        mock_conn = _make_mock_conn()

        with patch("velocity.db.core.async_support.psycopg", create=True) as mock_psycopg:
            mock_psycopg.AsyncConnection.connect = AsyncMock(return_value=mock_conn)

            tx = AsyncTransaction(engine)
            with patch.dict("sys.modules", {"psycopg": mock_psycopg}):
                await tx._ensure_connection()
                assert tx.connection is mock_conn

                await tx.close()
                mock_conn.commit.assert_awaited()
                mock_conn.close.assert_awaited()

    @pytest.mark.asyncio
    async def test_execute_returns_async_result(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_cursor = _make_async_cursor([(1,)], ["count"])
        tx.connection = _make_mock_conn(mock_cursor)

        result = await tx.execute("SELECT count(*) FROM orders")

        assert isinstance(result, AsyncResult)
        assert tx._query_count == 1
        assert tx._query_time_ms > 0

    @pytest.mark.asyncio
    async def test_execute_tracks_time(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_cursor = _make_async_cursor([(1,)], ["id"])
        tx.connection = _make_mock_conn(mock_cursor)

        await tx.execute("SELECT 1")
        assert tx._query_count == 1
        assert tx._query_time_ms >= 0

    @pytest.mark.asyncio
    async def test_commit(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_conn = _make_mock_conn()
        tx.connection = mock_conn
        tx._query_count = 5

        await tx.commit()
        mock_conn.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_rollback(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_conn = _make_mock_conn()
        tx.connection = mock_conn

        await tx.rollback()
        mock_conn.rollback.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_rollback_on_exception(self):
        """__aexit__ should rollback on exception."""
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_conn = _make_mock_conn()
        tx.connection = mock_conn

        try:
            async with tx:
                raise ValueError("boom")
        except ValueError:
            pass

        mock_conn.rollback.assert_awaited()

    @pytest.mark.asyncio
    async def test_table_returns_async_table(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)
        tbl = tx.table("orders")
        assert isinstance(tbl, AsyncTable)
        assert tbl.name == "orders"

    @pytest.mark.asyncio
    async def test_query_cache(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        key = tx._cache_key("SELECT * FROM t", None)
        assert tx._cache_get(key) is None

        tx._cache_put(key, [{"id": 1}])
        assert tx._cache_get(key) == [{"id": 1}]

        tx.invalidate_cache("t")
        assert tx._cache_get(key) is None

    @pytest.mark.asyncio
    async def test_invalidate_cache_all(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        tx._cache_put(("SELECT 1",), [1])
        tx._cache_put(("SELECT 2",), [2])
        tx.invalidate_cache()
        assert len(tx._query_cache) == 0


# ──────────────────────────────────────────────────────────────────────
# AsyncTable
# ──────────────────────────────────────────────────────────────────────


class TestAsyncTable:
    def _make_tx_and_table(self, rows_data, columns):
        """Return (AsyncTransaction, AsyncTable) with mocked execute."""
        engine = _make_engine()
        engine.sql.select.return_value = ("SELECT ...", ())
        engine.sql.insert.return_value = ("INSERT ...", ())
        engine.sql.update.return_value = ("UPDATE ...", ())
        engine.sql.delete.return_value = ("DELETE ...", ())
        engine.sql.merge.return_value = ("MERGE ...", ())
        engine.sql.insert_many.return_value = ("INSERT ... %s", [(1,)], "(%s)")

        tx = AsyncTransaction(engine)

        mock_cursor = _make_async_cursor(
            [tuple(d[c] for c in columns) for d in rows_data],
            columns,
        )
        tx.connection = _make_mock_conn(mock_cursor)

        table = tx.table("orders")
        return tx, table

    @pytest.mark.asyncio
    async def test_select(self):
        tx, table = self._make_tx_and_table(
            [{"sys_id": 1, "name": "Alice"}], ["sys_id", "name"]
        )
        result = await table.select(where={"status": "active"})
        assert isinstance(result, AsyncResult)
        rows = await result.all()
        assert len(rows) == 1
        assert rows[0]["name"] == "Alice"

    @pytest.mark.asyncio
    async def test_select_rows(self):
        tx, table = self._make_tx_and_table(
            [{"sys_id": 1, "name": "Alice"}, {"sys_id": 2, "name": "Bob"}],
            ["sys_id", "name"],
        )
        rows = await table.select_rows(where={"status": "active"})
        assert len(rows) == 2
        assert all(isinstance(r, Row) for r in rows)
        assert rows[0]["name"] == "Alice"
        assert tx._query_count == 1

    @pytest.mark.asyncio
    async def test_count(self):
        engine = _make_engine()
        engine.sql.select.return_value = ("SELECT count(*) FROM orders", ())

        tx = AsyncTransaction(engine)
        mock_cursor = _make_async_cursor([(42,)], ["count"])
        tx.connection = _make_mock_conn(mock_cursor)

        table = tx.table("orders")
        c = await table.count()
        assert c == 42

    @pytest.mark.asyncio
    async def test_insert(self):
        tx, table = self._make_tx_and_table([], [])
        result = await table.insert({"name": "Carol"})
        assert tx._query_count == 1

    @pytest.mark.asyncio
    async def test_update(self):
        tx, table = self._make_tx_and_table([], [])
        result = await table.update({"name": "Dave"}, where={"sys_id": 1})
        assert tx._query_count == 1

    @pytest.mark.asyncio
    async def test_delete(self):
        tx, table = self._make_tx_and_table([], [])
        result = await table.delete(where={"sys_id": 1})
        assert tx._query_count == 1

    @pytest.mark.asyncio
    async def test_merge(self):
        engine = _make_engine()
        engine.sql.merge.return_value = ("INSERT ... ON CONFLICT", ())
        engine.sql.primary_keys = MagicMock(return_value=["sys_id"])

        tx = AsyncTransaction(engine)
        mock_cursor = _make_async_cursor([], [])
        tx.connection = _make_mock_conn(mock_cursor)

        table = tx.table("orders")
        await table.merge({"sys_id": 1, "name": "test"})
        assert tx._query_count == 1

    @pytest.mark.asyncio
    async def test_ids(self):
        tx, table = self._make_tx_and_table(
            [{"sys_id": 10}, {"sys_id": 20}], ["sys_id"]
        )
        ids = await table.ids(where={"status": "active"})
        assert ids == [10, 20]

    @pytest.mark.asyncio
    async def test_find_single(self):
        tx, table = self._make_tx_and_table(
            [{"sys_id": 5}], ["sys_id"]
        )
        row = await table.find(where={"name": "test"})
        assert isinstance(row, Row)
        assert row.pk == {"sys_id": 5}

    @pytest.mark.asyncio
    async def test_find_none(self):
        tx, table = self._make_tx_and_table([], ["sys_id"])
        row = await table.find(where={"name": "nope"})
        assert row is None

    @pytest.mark.asyncio
    async def test_sql_only(self):
        engine = _make_engine()
        engine.sql.select.return_value = ("SELECT ...", ())
        engine.sql.insert.return_value = ("INSERT ...", ())
        engine.sql.delete.return_value = ("DELETE ...", ())

        tx = AsyncTransaction(engine)
        tx.connection = _make_mock_conn()
        table = tx.table("orders")

        ins = await table.insert({"name": "x"}, sql_only=True)
        assert ins == ("INSERT ...", ())

        dl = await table.delete(where={"sys_id": 1}, sql_only=True)
        assert dl == ("DELETE ...", ())


# ──────────────────────────────────────────────────────────────────────
# gather()
# ──────────────────────────────────────────────────────────────────────


class TestGather:
    @pytest.mark.asyncio
    async def test_gather_multiple_results(self):
        engine = _make_engine()
        engine.sql.select.return_value = ("SELECT ...", ())

        tx = AsyncTransaction(engine)

        cursor1 = _make_async_cursor([(1, "order1")], ["sys_id", "name"])
        cursor2 = _make_async_cursor([(10, 99.99)], ["sys_id", "amount"])

        mock_conn = _make_mock_conn()
        mock_conn.cursor.side_effect = [cursor1, cursor2]
        tx.connection = mock_conn

        orders_table = tx.table("orders")
        payments_table = tx.table("payments")

        r1, r2 = await tx.gather(
            orders_table.select(where={"user_id": 1}),
            payments_table.select(where={"user_id": 1}),
        )

        assert isinstance(r1, AsyncResult)
        assert isinstance(r2, AsyncResult)

    @pytest.mark.asyncio
    async def test_gather_preserves_order(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        async def coro_a():
            return "A"

        async def coro_b():
            return "B"

        async def coro_c():
            return "C"

        a, b, c = await tx.gather(coro_a(), coro_b(), coro_c())
        assert (a, b, c) == ("A", "B", "C")

    @pytest.mark.asyncio
    async def test_gather_single(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        async def coro():
            return 42

        (result,) = await tx.gather(coro())
        assert result == 42


# ──────────────────────────────────────────────────────────────────────
# N+1 Detection
# ──────────────────────────────────────────────────────────────────────


class TestAsyncNPlusOne:
    @pytest.mark.asyncio
    async def test_n1_warning_logged(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_conn = _make_mock_conn()
        tx.connection = mock_conn

        with patch("velocity.db.core.async_support._N_PLUS_1_THRESHOLD", 3):
            with patch("velocity.db.core.async_support._logger") as mock_logger:
                for i in range(5):
                    cursor = _make_async_cursor([(i,)], ["id"])
                    mock_conn.cursor.return_value = cursor
                    await tx.execute("SELECT * FROM orders WHERE sys_id = %s", (i,))

                warning_calls = [
                    c for c in mock_logger.warning.call_args_list
                    if "N+1" in str(c)
                ]
                assert len(warning_calls) == 1

    @pytest.mark.asyncio
    async def test_n1_no_warning_below_threshold(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_conn = _make_mock_conn()
        tx.connection = mock_conn

        with patch("velocity.db.core.async_support._N_PLUS_1_THRESHOLD", 10):
            with patch("velocity.db.core.async_support._logger") as mock_logger:
                for i in range(3):
                    cursor = _make_async_cursor([(i,)], ["id"])
                    mock_conn.cursor.return_value = cursor
                    await tx.execute("SELECT * FROM orders WHERE sys_id = %s", (i,))

                warning_calls = [
                    c for c in mock_logger.warning.call_args_list
                    if "N+1" in str(c)
                ]
                assert len(warning_calls) == 0


# ──────────────────────────────────────────────────────────────────────
# Engine integration
# ──────────────────────────────────────────────────────────────────────


class TestEngineAsyncTransaction:
    def test_async_transaction_returns_async_tx(self):
        from velocity.db.core.engine import Engine

        driver = MagicMock()
        sql = MagicMock()
        sql.server = "PostgreSQL"
        engine = Engine(driver, {"dbname": "test", "host": "localhost"}, sql,
                        pool_enabled=False)

        tx = engine.async_transaction()
        assert isinstance(tx, AsyncTransaction)
        assert tx.engine is engine


# ──────────────────────────────────────────────────────────────────────
# _SyncTableProxy
# ──────────────────────────────────────────────────────────────────────


class TestSyncTableProxy:
    def test_name(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)
        proxy = _SyncTableProxy(tx, "Orders", engine.sql)
        assert proxy.name == "orders"

    def test_select_raises(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)
        proxy = _SyncTableProxy(tx, "orders", engine.sql)
        with pytest.raises(RuntimeError, match="sync select"):
            proxy.select(where={"sys_id": 1})

    def test_update_or_insert_raises(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)
        proxy = _SyncTableProxy(tx, "orders", engine.sql)
        with pytest.raises(RuntimeError, match="sync write"):
            proxy.update_or_insert({"name": "x"}, pk={"sys_id": 1})

    def test_get_value_raises(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)
        proxy = _SyncTableProxy(tx, "orders", engine.sql)
        with pytest.raises(RuntimeError, match="sync get_value"):
            proxy.get_value("name", {"sys_id": 1})


# ──────────────────────────────────────────────────────────────────────
# AsyncTransaction._execute_values
# ──────────────────────────────────────────────────────────────────────


class TestAsyncExecuteValues:
    @pytest.mark.asyncio
    async def test_execute_values_basic(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_cursor = AsyncMock()
        mock_cursor.rowcount = 3
        tx.connection = _make_mock_conn(mock_cursor)

        total = await tx._execute_values(
            "INSERT INTO t VALUES %s",
            [(1, "a"), (2, "b"), (3, "c")],
        )
        assert total == 3

    @pytest.mark.asyncio
    async def test_execute_values_with_template(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_cursor = AsyncMock()
        mock_cursor.rowcount = 2
        tx.connection = _make_mock_conn(mock_cursor)

        total = await tx._execute_values(
            "INSERT INTO t VALUES %s",
            [(1, "a"), (2, "b")],
            template="(%s, %s)",
        )
        assert total == 2

    @pytest.mark.asyncio
    async def test_execute_values_paging(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        mock_cursor = AsyncMock()
        mock_cursor.rowcount = 2
        tx.connection = _make_mock_conn(mock_cursor)

        total = await tx._execute_values(
            "INSERT INTO t VALUES %s",
            [(1,), (2,), (3,), (4,)],
            page_size=2,
        )
        # Two batches of 2 rows each; mock returns rowcount=2 for each
        assert total == 4
        assert mock_cursor.execute.await_count == 2


# ──────────────────────────────────────────────────────────────────────
# Slow query logging
# ──────────────────────────────────────────────────────────────────────


class TestAsyncSlowQueryLogging:
    @pytest.mark.asyncio
    async def test_slow_query_logged(self):
        engine = _make_engine()
        tx = AsyncTransaction(engine)

        # Create a cursor whose execute takes measurable time
        import time as _time

        async def slow_execute(*args, **kwargs):
            _time.sleep(0.01)  # 10ms

        mock_cursor = MagicMock()
        mock_cursor.description = [MagicMock()]
        mock_cursor.description[0].name = "id"
        mock_cursor.execute = slow_execute

        tx.connection = _make_mock_conn(mock_cursor)

        with patch("velocity.db.core.async_support._SLOW_QUERY_MS", 1):  # 1ms threshold
            with patch("velocity.db.core.async_support._logger") as mock_logger:
                await tx.execute("SELECT * FROM large_table")
                slow_calls = [
                    c for c in mock_logger.warning.call_args_list
                    if "Slow" in str(c)
                ]
                assert len(slow_calls) >= 1
