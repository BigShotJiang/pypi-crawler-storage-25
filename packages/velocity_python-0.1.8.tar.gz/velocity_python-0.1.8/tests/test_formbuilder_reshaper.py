"""Tests for velocity.app.formbuilder.reshaper."""
import copy
import pytest
from velocity.app.formbuilder.reshaper import (
    reshape_formbuilder_template,
    _extract_metric,
    _extract_donation,
    _parse_key_value_string,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_row(**overrides):
    """Return a minimal form_builder_template dict with all expected fields."""
    base = {
        "sys_id": 42,
        "sys_created": "2024-01-01",
        "sys_modified": "2024-01-02",
        "client": "TIGERS",
        "campaign": "2024",
        "sub_campaign": "",
        "is_published": True,
        "datetime_last_validated": "2024-01-01T00:00:00Z",
        "last_validation_result": "passed",
        "last_validation_reason": "[]",
        "url_slug": "tigers-2024",
        "url_slug_alternate": "",
        "primary_color": "#003087",
        "secondary_color": "#FF7900",
        "header_font": "Roboto",
        "text_font": "Open Sans",
        "page_title": "Give to Tigers",
        "descriptor": "TIGERS DONATION",
        "campaign_end_date": None,
        "show_rival_thermometer": False,
        "rival_client": None,
        "rival_campaign": None,
        "campaign_start_dollars": None,
        "campaign_start_donors": None,
        "campaign_goal_dollars": None,
        "campaign_goal_donors": None,
    }
    # Add 9 empty metric slots
    for i in range(1, 10):
        p = f"metric_{i}_"
        base.update({
            f"{p}hide_donation_from_ui": False,
            f"{p}header": "",
            f"{p}image": "",
            f"{p}label": "",
            f"{p}secondarytext": "",
            f"{p}helpertext": "",
            f"{p}values": "",
            f"{p}defaultvalue": "",
            f"{p}show_other": False,
            f"{p}other_minimum_value": "",
            f"{p}orientation": "horizontal",
        })
    # Add 9 empty donation slots
    for i in range(1, 10):
        p = f"donation_{i}_"
        base.update({
            f"{p}hide_donation_from_ui": False,
            f"{p}header": "",
            f"{p}html": "",
            f"{p}image": "",
            f"{p}label": "",
            f"{p}secondarytext": "",
            f"{p}helpertext": "",
            f"{p}values": "",
            f"{p}defaultvalue": "",
            f"{p}show_other": False,
            f"{p}other_minimum_value": "",
            f"{p}orientation": "vertical",
            f"{p}dropdown": "",
            f"{p}dropdown_label": "",
        })
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# _parse_key_value_string
# ---------------------------------------------------------------------------

class TestParseKeyValueString:
    def test_empty_string_returns_empty_dict(self):
        assert _parse_key_value_string("") == {}

    def test_none_returns_empty_dict(self):
        assert _parse_key_value_string(None) == {}

    def test_simple_string_values(self):
        result = _parse_key_value_string('"Entry A": "25", "Entry B": "50"')
        assert result == {"Entry A": "25", "Entry B": "50"}

    def test_numeric_values(self):
        result = _parse_key_value_string('"$25": 25, "$50": 50')
        assert result == {"$25": 25, "$50": 50}

    def test_malformed_string_returns_empty_dict(self):
        assert _parse_key_value_string("not valid python") == {}


# ---------------------------------------------------------------------------
# Input immutability
# ---------------------------------------------------------------------------

class TestImmutability:
    def test_input_dict_not_mutated(self):
        row = _make_row(metric_1_label="Seats", metric_1_values='"A": "1"')
        original = copy.deepcopy(row)
        reshape_formbuilder_template(row)
        assert row == original

    def test_returns_new_object(self):
        row = _make_row()
        result = reshape_formbuilder_template(row)
        assert result is not row


# ---------------------------------------------------------------------------
# Field stripping
# ---------------------------------------------------------------------------

class TestFieldStripping:
    def test_sys_fields_stripped(self):
        row = _make_row()
        result = reshape_formbuilder_template(row)
        assert not any(k.startswith("sys_") for k in result)

    def test_url_slug_stripped(self):
        row = _make_row(url_slug="tigers", url_slug_alternate="t2024")
        result = reshape_formbuilder_template(row)
        assert "url_slug" not in result
        assert "url_slug_alternate" not in result

    def test_admin_metadata_stripped(self):
        row = _make_row(
            is_published=True,
            datetime_last_validated="2024-01-01T00:00:00Z",
            last_validation_result="passed",
            last_validation_reason="[]",
        )
        result = reshape_formbuilder_template(row)
        assert "is_published" not in result
        assert "datetime_last_validated" not in result
        assert "last_validation_result" not in result
        assert "last_validation_reason" not in result

    def test_backend_only_fields_stripped(self):
        """Fields used only on the server side must never reach the browser."""
        row = _make_row(
            whitelist_end_date="2024-12-31",
            recaptcha_version="v3",
            recaptcha_v3_score_threshold=0.5,
            campaign="2024-annual",
            sub_campaign="fall",
            receipt_from_address="receipts@example.com",
            receipt_subject="Thank you",
            receipt_body_text="<p>Thank you!</p>",
            mail_bcc="bcc@example.com",
            rally_receipt_from_address="rally@example.com",
            rally_receipt_subject="Rally receipt",
            rally_receipt_body_text="<p>Rally!</p>",
            rally_mail_bcc="rallybcc@example.com",
        )
        result = reshape_formbuilder_template(row)
        backend_only = [
            "whitelist_end_date",
            "recaptcha_version",
            "recaptcha_v3_score_threshold",
            "campaign",
            "sub_campaign",
            "receipt_from_address",
            "receipt_subject",
            "receipt_body_text",
            "mail_bcc",
            "rally_receipt_from_address",
            "rally_receipt_subject",
            "rally_receipt_body_text",
            "rally_mail_bcc",
        ]
        for field in backend_only:
            assert field not in result, f"Backend-only field '{field}' must be stripped"

    def test_num_entries_added(self):
        row = _make_row()
        result = reshape_formbuilder_template(row)
        assert result["_num_entries"] == 42

    def test_flat_metric_keys_stripped(self):
        row = _make_row(metric_1_label="Seats")
        result = reshape_formbuilder_template(row)
        flat_metric_keys = [k for k in result if k.startswith("metric_")]
        assert flat_metric_keys == [], flat_metric_keys

    def test_flat_donation_keys_stripped(self):
        row = _make_row(donation_1_label="Game")
        result = reshape_formbuilder_template(row)
        flat_donation_keys = [k for k in result if k.startswith("donation_")]
        assert flat_donation_keys == [], flat_donation_keys


# ---------------------------------------------------------------------------
# Metric reshaping
# ---------------------------------------------------------------------------

class TestMetricReshaping:
    def test_metric_with_label_included(self):
        row = _make_row(
            metric_1_label="Seats",
            metric_1_header="Choose seats",
            metric_1_values='"1 Seat": "1", "2 Seats": "2"',
            metric_1_defaultvalue="1",
            metric_1_orientation="vertical",
        )
        result = reshape_formbuilder_template(row)
        m = result["metrics"]["metric_1"]
        assert m["label"] == "Seats"
        assert m["header"] == "Choose seats"
        assert m["values"] == {"1 Seat": "1", "2 Seats": "2"}
        assert m["defaultvalue"] == "1"
        assert m["orientation"] == "vertical"

    def test_metric_without_label_is_empty_dict(self):
        row = _make_row()
        result = reshape_formbuilder_template(row)
        for i in range(1, 10):
            assert result["metrics"][f"metric_{i}"] == {}

    def test_hidden_metric_is_empty_dict(self):
        row = _make_row(metric_1_label="Seats", metric_1_hide_donation_from_ui=True)
        result = reshape_formbuilder_template(row)
        assert result["metrics"]["metric_1"] == {}

    def test_all_9_metric_slots_present(self):
        row = _make_row()
        result = reshape_formbuilder_template(row)
        assert set(result["metrics"].keys()) == {f"metric_{i}" for i in range(1, 10)}

    def test_multiple_active_metrics(self):
        row = _make_row(metric_1_label="A", metric_2_label="B", metric_3_label="C")
        result = reshape_formbuilder_template(row)
        for key in ("metric_1", "metric_2", "metric_3"):
            assert result["metrics"][key] != {}
        for key in (f"metric_{i}" for i in range(4, 10)):
            assert result["metrics"][key] == {}


# ---------------------------------------------------------------------------
# Donation reshaping
# ---------------------------------------------------------------------------

class TestDonationReshaping:
    def test_donation_with_label_included(self):
        row = _make_row(
            donation_1_label="General Gift",
            donation_1_header="Support us",
            donation_1_values='"$25": 25, "$50": 50',
            donation_1_defaultvalue="25",
            donation_1_html="<b>Thanks</b>",
            donation_1_dropdown_label="Fund",
            donation_1_dropdown="General,Athletics",
        )
        result = reshape_formbuilder_template(row)
        d = result["donations"]["donation_1"]
        assert d["label"] == "General Gift"
        assert d["values"] == {"$25": 25, "$50": 50}
        assert d["html"] == "<b>Thanks</b>"
        assert d["dropdown_label"] == "Fund"

    def test_donation_without_label_is_empty_dict(self):
        row = _make_row()
        result = reshape_formbuilder_template(row)
        for i in range(1, 10):
            assert result["donations"][f"donation_{i}"] == {}

    def test_hidden_donation_is_empty_dict(self):
        row = _make_row(donation_1_label="Gift", donation_1_hide_donation_from_ui=True)
        result = reshape_formbuilder_template(row)
        assert result["donations"]["donation_1"] == {}

    def test_all_9_donation_slots_present(self):
        row = _make_row()
        result = reshape_formbuilder_template(row)
        assert set(result["donations"].keys()) == {f"donation_{i}" for i in range(1, 10)}


# ---------------------------------------------------------------------------
# Top-level field preservation
# ---------------------------------------------------------------------------

class TestTopLevelFields:
    def test_branding_fields_preserved(self):
        row = _make_row(primary_color="#003087", page_title="Give Now")
        result = reshape_formbuilder_template(row)
        assert result["primary_color"] == "#003087"
        assert result["page_title"] == "Give Now"

    def test_client_preserved(self):
        """client is used by the frontend (RivalThermometer, Braintree display name)."""
        row = _make_row(client="TIGERS", campaign="2024")
        result = reshape_formbuilder_template(row)
        assert result["client"] == "TIGERS"
        assert "campaign" not in result  # campaign is backend-only routing metadata

    def test_unknown_custom_fields_preserved(self):
        """Extra columns added to the DB table should pass through untouched."""
        row = _make_row(custom_new_field="hello")
        result = reshape_formbuilder_template(row)
        assert result["custom_new_field"] == "hello"
