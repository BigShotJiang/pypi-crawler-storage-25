"""
Tests for R3 — Row.batch_update() context manager.
"""

import pytest
from unittest.mock import MagicMock, call, patch

from velocity.db.core.row import Row


def _make_row(cache=None, pk=None):
    """Create a Row with a mocked table, bypassing DB access."""
    table = MagicMock()
    table.name = "test_table"
    table.select.return_value.as_dict.return_value.one.return_value = cache or {
        "name": "Alice",
        "email": "alice@example.com",
        "sys_id": 1,
    }
    table.update_or_insert = MagicMock()

    row = Row.__new__(Row)
    object.__setattr__(row, "table", table)
    object.__setattr__(row, "pk", pk or {"sys_id": 1})
    object.__setattr__(row, "_cache", dict(cache) if cache else None)
    object.__setattr__(row, "_column_set", None)
    object.__setattr__(row, "_batching", False)
    object.__setattr__(row, "_pending", {})
    object.__setattr__(row, "_cache_ttl", None)
    object.__setattr__(row, "_cache_time", None)
    object.__setattr__(row, "_no_cache", False)
    return row


class TestBatchUpdateContextManager:
    """Tests for Row.batch_update()."""

    def test_single_update_on_exit(self):
        """Multiple assignments inside batch should produce one DB call."""
        row = _make_row({"name": "Alice", "email": "old@example.com", "sys_id": 1})

        with row.batch_update():
            row["name"] = "Bob"
            row["email"] = "bob@example.com"

        # Should be exactly ONE update_or_insert call with both columns
        row.table.update_or_insert.assert_called_once_with(
            {"name": "Bob", "email": "bob@example.com"}, pk={"sys_id": 1}
        )

    def test_no_db_call_during_batch(self):
        """No DB writes should happen inside the batch context."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with row.batch_update():
            row["name"] = "Bob"
            row.table.update_or_insert.assert_not_called()

    def test_reads_see_pending_values(self):
        """Reads inside the batch should see the pending (optimistic) values."""
        row = _make_row({"name": "Alice", "email": "old@example.com", "sys_id": 1})

        with row.batch_update():
            row["name"] = "Bob"
            assert row["name"] == "Bob"
            assert row["email"] == "old@example.com"

    def test_empty_batch_no_db_call(self):
        """If nothing is set inside the batch, no DB call should happen."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with row.batch_update():
            pass

        row.table.update_or_insert.assert_not_called()

    def test_exception_discards_pending(self):
        """On exception, pending changes are discarded and cache invalidated."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with pytest.raises(ValueError):
            with row.batch_update():
                row["name"] = "Bob"
                raise ValueError("oops")

        # No DB write should have occurred
        row.table.update_or_insert.assert_not_called()
        # Cache should be invalidated
        assert row._cache is None
        assert row._pending == {}
        assert row._batching is False

    def test_batching_flag_reset_on_normal_exit(self):
        """After batch_update exits normally, _batching is False."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with row.batch_update():
            assert row._batching is True

        assert row._batching is False
        assert row._pending == {}

    def test_batching_flag_reset_on_error(self):
        """After batch_update exits with error, _batching is False."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with pytest.raises(RuntimeError):
            with row.batch_update():
                assert row._batching is True
                raise RuntimeError("fail")

        assert row._batching is False

    def test_last_write_wins(self):
        """Multiple writes to the same key should keep the last value."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with row.batch_update():
            row["name"] = "Bob"
            row["name"] = "Charlie"

        row.table.update_or_insert.assert_called_once_with(
            {"name": "Charlie"}, pk={"sys_id": 1}
        )

    def test_pk_write_still_raises(self):
        """Writing to a PK column inside batch should still raise."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with pytest.raises(Exception, match="Cannot update a primary key"):
            with row.batch_update():
                row["sys_id"] = 999

    def test_normal_setitem_still_immediate_outside_batch(self):
        """Outside batch_update, __setitem__ should still write immediately."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        row["name"] = "Bob"

        row.table.update_or_insert.assert_called_once_with(
            {"name": "Bob"}, pk={"sys_id": 1}
        )

    def test_attribute_style_access_batched(self):
        """Attribute-style writes should also be deferred inside batch."""
        row = _make_row({"name": "Alice", "email": "old@example.com", "sys_id": 1})

        with row.batch_update():
            row.name = "Bob"
            row.email = "bob@example.com"

        row.table.update_or_insert.assert_called_once_with(
            {"name": "Bob", "email": "bob@example.com"}, pk={"sys_id": 1}
        )

    def test_update_method_not_batched(self):
        """The .update() method should still write immediately even inside batch,
        since it already batches by design."""
        row = _make_row({"name": "Alice", "email": "old@example.com", "sys_id": 1})

        # update() calls table.update_or_insert directly
        row.update({"name": "Bob", "email": "bob@example.com"})

        row.table.update_or_insert.assert_called_once()

    def test_special_value_batched(self):
        """@@-prefixed special values should be deferred like any other value."""
        row = _make_row({"name": "Alice", "sys_modified": None, "sys_id": 1})

        with row.batch_update():
            row["name"] = "Bob"
            row["sys_modified"] = "@@CURRENT_TIMESTAMP"

        row.table.update_or_insert.assert_called_once_with(
            {"name": "Bob", "sys_modified": "@@CURRENT_TIMESTAMP"},
            pk={"sys_id": 1},
        )

    def test_nested_batch_not_supported(self):
        """Entering batch_update while already batching resets pending —
        this documents current behavior (no nesting support)."""
        row = _make_row({"name": "Alice", "email": "a@example.com", "sys_id": 1})

        with row.batch_update():
            row["name"] = "Bob"
            with row.batch_update():
                row["email"] = "bob@example.com"
            # Inner exit flushes only email
            assert row.table.update_or_insert.call_count == 1
            row.table.update_or_insert.assert_called_with(
                {"email": "bob@example.com"}, pk={"sys_id": 1}
            )

    def test_batch_returns_row(self):
        """The context manager should yield the row."""
        row = _make_row({"name": "Alice", "sys_id": 1})

        with row.batch_update() as r:
            assert r is row
