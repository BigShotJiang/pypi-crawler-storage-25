"""Unit tests for velocity.app.validators.formbuilder_template.

These tests are the canonical regression suite for the shared validator.
Consumer-project tests (DonateMain, BackOffice) import from this module via
velocity so their suites should stay in sync.

Runs entirely offline — no database or network access required.

  python -m pytest tests/test_formbuilder_template_validator.py -v
"""

from __future__ import annotations

import unittest

from velocity.app.validators.formbuilder_template import validate_formbuilder_template


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _make_valid_fb(**overrides) -> dict:
    """Return the minimal template dict that passes all validations."""
    base = {
        "client": "TestClient",
        "campaign": "test_campaign",
        "url_slug": "/test/campaign",
        "receipt_from_address": "noreply@example.com",
        "receipt_subject": "Thank you for your donation",
        "receipt_body_text": "<p>Dear {first_name}, thank you for donating!</p>",
        "descriptor": "CaringCent*TEST",
        "confirmation_header_text": "Thank you!",
        "share_url": "https://donate.example.org/campaign",
        "donations": {
            "d1": {"label": "Give $25", "values": {"$25": "25"}},
        },
    }
    base.update(overrides)
    return base


def _errors(issues, field=None):
    return [
        i
        for i in issues
        if i["severity"] == "error" and (field is None or i["field"] == field)
    ]


def _warnings(issues, field=None):
    return [
        i
        for i in issues
        if i["severity"] == "warning" and (field is None or i["field"] == field)
    ]


# --------------------------------------------------------------------------- #
# Baseline
# --------------------------------------------------------------------------- #


class ValidTemplatePassesTests(unittest.TestCase):

    def test_valid_template_has_no_issues(self):
        issues = validate_formbuilder_template(_make_valid_fb())
        self.assertEqual(issues, [], f"Unexpected issues: {issues}")

    def test_returns_a_list(self):
        result = validate_formbuilder_template(_make_valid_fb())
        self.assertIsInstance(result, list)


# --------------------------------------------------------------------------- #
# Identity fields
# --------------------------------------------------------------------------- #


class IdentityFieldTests(unittest.TestCase):

    def test_missing_client_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(_make_valid_fb(client="")), "client"))

    def test_none_client_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(_make_valid_fb(client=None)), "client"))

    def test_missing_campaign_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(_make_valid_fb(campaign="")), "campaign"))

    def test_missing_url_slug_is_error(self):
        fb = _make_valid_fb()
        del fb["url_slug"]
        self.assertTrue(_errors(validate_formbuilder_template(fb), "url_slug"))

    def test_none_url_slug_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(_make_valid_fb(url_slug=None)), "url_slug"))


# --------------------------------------------------------------------------- #
# Receipt email fields
# --------------------------------------------------------------------------- #


class ReceiptEmailFieldTests(unittest.TestCase):

    def test_empty_from_address_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(
            _make_valid_fb(receipt_from_address="")), "receipt_from_address"))

    def test_none_from_address_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(
            _make_valid_fb(receipt_from_address=None)), "receipt_from_address"))

    def test_invalid_from_address_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(
            _make_valid_fb(receipt_from_address="not-an-email")), "receipt_from_address"))

    def test_display_name_format_passes(self):
        """'Display Name <user@example.com>' is RFC 5322 valid and used in practice."""
        issues = validate_formbuilder_template(
            _make_valid_fb(receipt_from_address="Tigers Athletics <noreply@example.com>"))
        self.assertFalse(_errors(issues, "receipt_from_address"))

    def test_empty_subject_is_warning(self):
        self.assertTrue(_warnings(validate_formbuilder_template(
            _make_valid_fb(receipt_subject="")), "receipt_subject"))

    def test_empty_body_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(
            _make_valid_fb(receipt_body_text="")), "receipt_body_text"))


# --------------------------------------------------------------------------- #
# Braintree descriptor
# --------------------------------------------------------------------------- #


class DescriptorTests(unittest.TestCase):

    def test_valid_descriptor_passes(self):
        issues = validate_formbuilder_template(_make_valid_fb())
        self.assertFalse(_errors(issues, "descriptor"))
        self.assertFalse(_warnings(issues, "descriptor"))

    def test_omitted_descriptor_passes(self):
        fb = _make_valid_fb()
        del fb["descriptor"]
        issues = validate_formbuilder_template(fb)
        self.assertFalse(_errors(issues, "descriptor"))

    def test_descriptor_too_long_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(
            _make_valid_fb(descriptor="A" * 23)), "descriptor"))

    def test_descriptor_exactly_22_chars_passes(self):
        issues = validate_formbuilder_template(_make_valid_fb(descriptor="CaringCent*EXACTLY22CH"))
        self.assertFalse(_errors(issues, "descriptor"))

    def test_descriptor_without_asterisk_is_warning(self):
        fb = _make_valid_fb(descriptor="CaringCentNOASTERISK")
        issues = validate_formbuilder_template(fb)
        self.assertTrue(_warnings(issues, "descriptor"))

    def test_descriptor_with_non_ascii_is_error(self):
        self.assertTrue(_errors(validate_formbuilder_template(
            _make_valid_fb(descriptor="CaringCent*\x80TEST")), "descriptor"))


# --------------------------------------------------------------------------- #
# Content — donations / metrics
# --------------------------------------------------------------------------- #


class ContentConfigurationTests(unittest.TestCase):

    def test_no_donations_no_metrics_is_warning(self):
        fb = _make_valid_fb()
        del fb["donations"]
        self.assertTrue(_warnings(validate_formbuilder_template(fb), "donations/metrics"))

    def test_modern_donations_dict_counts_as_content(self):
        issues = validate_formbuilder_template(_make_valid_fb())
        self.assertFalse(_warnings(issues, "donations/metrics"))

    def test_hidden_donation_does_not_count_as_content(self):
        fb = _make_valid_fb()
        fb["donations"] = {"d1": {"label": "Hidden", "values": {}}}
        fb["donation_d1_hide_donation_from_ui"] = True
        issues = validate_formbuilder_template(fb)
        self.assertTrue(_warnings(issues, "donations/metrics"))

    def test_legacy_numbered_donation_fields_count_as_content(self):
        fb = _make_valid_fb()
        del fb["donations"]
        fb["donation_1_label"] = "Give $25"
        issues = validate_formbuilder_template(fb)
        self.assertFalse(_warnings(issues, "donations/metrics"))


# --------------------------------------------------------------------------- #
# Share URL
# --------------------------------------------------------------------------- #


class ShareUrlTests(unittest.TestCase):

    def test_missing_share_url_is_ok(self):
        fb = _make_valid_fb()
        del fb["share_url"]
        self.assertFalse(_warnings(validate_formbuilder_template(fb), "share_url"))

    def test_valid_https_url_passes(self):
        issues = validate_formbuilder_template(_make_valid_fb())
        self.assertFalse(_warnings(issues, "share_url"))

    def test_non_url_share_url_is_warning(self):
        self.assertTrue(_warnings(validate_formbuilder_template(
            _make_valid_fb(share_url="not-a-url")), "share_url"))


# --------------------------------------------------------------------------- #
# Confirmation page text
# --------------------------------------------------------------------------- #


class ConfirmationTextTests(unittest.TestCase):

    def test_empty_confirmation_header_is_warning(self):
        self.assertTrue(_warnings(validate_formbuilder_template(
            _make_valid_fb(confirmation_header_text="")), "confirmation_header_text"))

    def test_valid_confirmation_header_passes(self):
        issues = validate_formbuilder_template(_make_valid_fb())
        self.assertFalse(_warnings(issues, "confirmation_header_text"))


if __name__ == "__main__":
    unittest.main()
