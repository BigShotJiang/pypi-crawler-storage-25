from types import SimpleNamespace

from velocity.payment import (
    build_stripe_payment_profile,
    get_payment_profile_sources,
    normalize_payment_processor,
    upsert_payment_profile,
)


def test_normalize_payment_processor_defaults_to_braintree():
    assert normalize_payment_processor(None) == "braintree"
    assert normalize_payment_processor("") == "braintree"
    assert normalize_payment_processor("braintree") == "braintree"


def test_normalize_payment_processor_preserves_known_and_unknown_values():
    assert normalize_payment_processor("STRIPE") == "stripe"
    assert normalize_payment_processor("paypal") == "paypal"


def test_get_payment_profile_sources_by_processor():
    assert get_payment_profile_sources("stripe") == ["ST"]
    assert get_payment_profile_sources("braintree") == ["BT"]
    assert get_payment_profile_sources("authorize_net") == ["AN"]


def test_build_stripe_payment_profile_maps_stripe_card_fields():
    payment_method = SimpleNamespace(
        id="pm_123",
        card=SimpleNamespace(brand="visa", last4="4242", exp_year=2030, exp_month=6),
        billing_details=SimpleNamespace(name="Ada Lovelace"),
    )

    profile = build_stripe_payment_profile("cus_123", payment_method, "ada@example.com")

    assert profile["src"] == "ST"
    assert profile["payment_profile_id"] == "pm_123"
    assert profile["customer_profile_id"] == "cus_123"
    assert profile["card_type"] == "Visa"
    assert profile["card_number"] == "4242"
    assert profile["expiration_date"] == "2030-06"
    assert profile["first_name"] == "Ada"
    assert profile["last_name"] == "Lovelace"


def test_upsert_payment_profile_falls_back_to_insert_and_index_creation():
    calls = []

    class FakeTable:
        def upsert(self, profile_data, key):
            raise RuntimeError("upsert unavailable")

        def insert(self, profile_data):
            calls.append(("insert", profile_data))

        def create_index(self, field_name, unique=False):
            calls.append(("create_index", field_name, unique))

    class FakeTx:
        def table(self, table_name):
            assert table_name == "payment_profiles"
            return FakeTable()

    upsert_payment_profile(
        FakeTx(),
        {"payment_profile_id": "pm_123", "email_address": "ada@example.com"},
    )

    assert calls[0][0] == "insert"
    assert calls[0][1]["payment_profile_id"] == "pm_123"
    assert calls[1] == ("create_index", "payment_profile_id", True)