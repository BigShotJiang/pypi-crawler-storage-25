from velocity.payment.demo_profiles import resolve_demo_charge_cards


def test_resolve_demo_charge_cards_replaces_existing_cards(monkeypatch):
    user = {"email_address": "person@example.com"}
    prod_card = {
        "src": "BT",
        "payment_profile_id": "prod-token",
        "customer_profile_id": "prod-customer",
    }

    monkeypatch.setattr(
        "velocity.payment.demo_profiles.is_demo_environment", lambda: True
    )
    monkeypatch.setattr(
        "velocity.payment.demo_profiles.get_demo_card_for_source",
        lambda tx, user, source: {
            "src": source,
            "payment_profile_id": "demo-token",
            "customer_profile_id": "demo-customer",
        },
    )

    resolved = resolve_demo_charge_cards(None, user, "braintree", [prod_card])

    assert resolved == [
        {
            "src": "BT",
            "payment_profile_id": "demo-token",
            "customer_profile_id": "demo-customer",
        }
    ]


def test_resolve_demo_charge_cards_creates_fallback_card_when_none_exist(monkeypatch):
    user = {"email_address": "person@example.com"}

    monkeypatch.setattr(
        "velocity.payment.demo_profiles.is_demo_environment", lambda: True
    )
    monkeypatch.setattr(
        "velocity.payment.demo_profiles.get_demo_card_for_source",
        lambda tx, user, source: {
            "src": source,
            "payment_profile_id": f"{source.lower()}-demo-token",
            "customer_profile_id": f"{source.lower()}-demo-customer",
        },
    )

    resolved = resolve_demo_charge_cards(None, user, "stripe", [])

    assert resolved == [
        {
            "src": "ST",
            "payment_profile_id": "st-demo-token",
            "customer_profile_id": "st-demo-customer",
        }
    ]