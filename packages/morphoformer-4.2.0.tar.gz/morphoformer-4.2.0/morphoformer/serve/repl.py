"""Interactive REPL for morphological reinflection inference.

Loads a trained checkpoint and provides a loop where the user
can type lemma + tags + language and see the predicted surface form.
"""

from __future__ import annotations

from pathlib import Path

import torch

from chartoken import CharVocab, FeatureVocab
from morphoformer.config.schema import MorphoformerConfig
from morphoformer.inference.predict import predict_form
from morphoformer.model.model import Morphoformer
from vpterm.style import Style
from vpterm.panel import Panel
from vpterm.terminal import Terminal, get_terminal


def _print_welcome(terminal: Terminal, config: MorphoformerConfig, checkpoint_path: str) -> None:
    """Print a welcome panel with model info."""
    panel = Panel(title="MorphFormer — Interactive Mode")

    panel.add_section("Model")
    panel.add_kv("checkpoint", checkpoint_path)
    panel.add_kv("device", config.train.device)
    panel.add_kv("languages", " ".join(sorted(config.languages.keys())))

    panel.add_blank()
    panel.add_section("Usage")
    panel.add_line(f"  {Style.bold('lemma;TAG1;TAG2;... language')}  — predict surface form")
    panel.add_line(f"  {Style.bold('quit')} / {Style.bold('exit')}              — exit the REPL")
    panel.add_line(f"  {Style.bold('help')}                       — show this help")

    terminal.writeln(panel.render())
    terminal.blank_line()


def _print_help(terminal: Terminal) -> None:
    """Print help for REPL commands."""
    terminal.writeln(f"  {Style.bold('Input format:')} lemma;TAG1;TAG2;... language")
    terminal.writeln(f"  {Style.dim('Example:')}      бежать;V;PST;SG;FEM rus")
    terminal.writeln(f"  {Style.dim('Commands:')}     quit, exit, help")
    terminal.blank_line()


def _parse_input(raw: str) -> tuple[str, list[str], str] | None:
    """Parse user input into (lemma, tags, language).

    Expected format: lemma;TAG1;TAG2;... language
    Returns None if the input cannot be parsed.
    """
    parts = raw.strip().rsplit(maxsplit=1)
    if len(parts) != 2:
        return None
    lemma_tags, language = parts
    segments = [segment.strip() for segment in lemma_tags.split(";") if segment.strip()]
    if len(segments) < 2:
        return None
    lemma = segments[0]
    tags = segments[1:]
    return lemma, tags, language


def run_serve(
    config: MorphoformerConfig,
    model: Morphoformer,
    char_vocab: CharVocab,
    feature_vocab: FeatureVocab,
    device: torch.device,
    checkpoint_path: str,
) -> None:
    """Run the interactive REPL loop."""
    terminal = get_terminal()
    _print_welcome(terminal, config, checkpoint_path)

    prompt = f" {Style.cyan('morph')} {Style.dim('>')} "

    while True:
        try:
            raw = input(prompt)
        except (EOFError, KeyboardInterrupt):
            terminal.blank_line()
            terminal.status("Session ended.", kind="stop")
            break

        stripped = raw.strip()
        if not stripped:
            continue

        if stripped in ("quit", "exit"):
            terminal.status("Session ended.", kind="stop")
            break

        if stripped == "help":
            _print_help(terminal)
            continue

        parsed = _parse_input(stripped)
        if parsed is None:
            terminal.writeln(
                f"  {Style.error('!')} Invalid input. Expected: "
                f"{Style.bold('lemma;TAG1;TAG2;... language')}"
            )
            terminal.writeln(f"  {Style.dim('Example:')} бежать;V;PST;SG;FEM rus")
            continue

        lemma, tags, language = parsed

        if language not in model.language_to_id:
            available = ", ".join(sorted(model.language_to_id.keys()))
            terminal.writeln(
                f"  {Style.error('!')} Unknown language {Style.bold(language)}. "
                f"Available: {Style.dim(available)}"
            )
            continue

        try:
            result = predict_form(
                model,
                char_vocab,
                feature_vocab,
                lemma=lemma,
                tags=tags,
                language=language,
                max_len=config.data.max_len,
                max_features=config.data.max_features,
                device=device,
            )
            terminal.writeln(
                f"  {Style.dim('lemma')}    {Style.bold(lemma)}\n"
                f"  {Style.dim('tags')}     {Style.cyan(';'.join(tags))}\n"
                f"  {Style.dim('language')} {language}\n"
                f"  {Style.dim('result')}   {Style.success(Style.bold(result))}"
            )
        except Exception as error:
            terminal.writeln(f"  {Style.error('!')} Prediction failed: {error}")

        terminal.blank_line()
