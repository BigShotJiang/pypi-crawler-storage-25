from __future__ import annotations

import argparse
import sys
from pathlib import Path
from pprint import pprint

from morphoformer.config.loader import load_config
from morphoformer.inference.predict import predict_form
from morphoformer.training.trainer import MorphoformerTrainer


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="morphoformer")
    subparsers = parser.add_subparsers(dest="command", required=True)

    download_parser = subparsers.add_parser("download")
    download_parser.add_argument("--lang", default="all", help="Comma-separated language codes or 'all'")
    download_parser.add_argument("--out-dir", default="data", dest="out_dir")
    download_parser.add_argument("--merge", action="store_true")
    download_parser.add_argument("--list-languages", action="store_true", dest="list_languages")

    inspect_parser = subparsers.add_parser("inspect-config")
    inspect_parser.add_argument("--config", required=True)

    train_parser = subparsers.add_parser("train")
    train_parser.add_argument("--config", required=True)

    infer_parser = subparsers.add_parser("infer")
    infer_parser.add_argument("--config", required=True, help="Path to TOML config file")
    infer_parser.add_argument("--checkpoint", required=True, help="Path to trained checkpoint")
    infer_parser.add_argument("--lemma", required=True, help="Input lemma to reinflect")
    infer_parser.add_argument("--tags", required=True, help="Semicolon-separated UniMorph tags")
    infer_parser.add_argument("--lang", required=True, help="Language code (e.g., rus, bul, spa)")

    serve_parser = subparsers.add_parser("serve", help="Interactive REPL for inference")
    serve_parser.add_argument("--config", required=True, help="Path to TOML config file")
    serve_parser.add_argument("--checkpoint", required=True, help="Path to trained checkpoint")
    return parser


def _merge_downloaded_files(out_dir: Path) -> None:
    from sigmorphon import merge_tsv

    train_files = sorted(out_dir.glob("*_train.tsv"))
    if train_files:
        merged_train = out_dir / "merged_train.tsv"
        train_count = merge_tsv(train_files, merged_train)
        print(f"Merged train: {merged_train} ({train_count} rows)", flush=True)

    dev_files = sorted(out_dir.glob("*_dev.tsv"))
    if dev_files:
        merged_dev = out_dir / "merged_dev.tsv"
        dev_count = merge_tsv(dev_files, merged_dev)
        print(f"Merged dev: {merged_dev} ({dev_count} rows)", flush=True)


def _download_command(args: argparse.Namespace) -> None:
    from sigmorphon import DATASETS, download_all, get_available_languages

    available_languages = get_available_languages()
    if args.list_languages:
        for language in available_languages:
            print(language, flush=True)
        return

    out_dir = Path(args.out_dir)
    if args.lang == "all":
        languages = ["all"]
    else:
        languages = [language.strip() for language in args.lang.split(",") if language.strip()]
        invalid_languages = [
            language for language in languages if language not in available_languages and language not in DATASETS
        ]
        if invalid_languages:
            print(
                f"Warning: these languages may be unavailable: {', '.join(invalid_languages)}",
                file=sys.stderr,
                flush=True,
            )

    download_all(languages, out_dir)
    if args.merge:
        _merge_downloaded_files(out_dir)


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "download":
            _download_command(args)
            return

        if args.command == "inspect-config":
            config = load_config(args.config)
            pprint(config)
            return

        config = load_config(args.config)
        trainer = MorphoformerTrainer(config)

        if args.command == "train":
            print(f"Starting training with config={args.config}", flush=True)
            checkpoint = trainer.train()
            print(f"checkpoint={checkpoint}", flush=True)
            return

        model, char_vocab, feature_vocab = trainer.load_model(args.checkpoint)

        if args.command == "serve":
            from morphoformer.serve.repl import run_serve

            run_serve(
                config=config,
                model=model,
                char_vocab=char_vocab,
                feature_vocab=feature_vocab,
                device=trainer.device,
                checkpoint_path=args.checkpoint,
            )
            return

        result = predict_form(
            model,
            char_vocab,
            feature_vocab,
            lemma=args.lemma,
            tags=[tag for tag in args.tags.split(";") if tag],
            language=args.lang,
            max_len=config.data.max_len,
            max_features=config.data.max_features,
            device=trainer.device,
        )
        print(result, flush=True)
    except KeyboardInterrupt:
        print("Interrupted by user.", file=sys.stderr, flush=True)
        raise SystemExit(130)


if __name__ == "__main__":
    main()
