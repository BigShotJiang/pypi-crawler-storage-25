"""MorphFormer v4 training loop with per-expert loss tracking and structured logging.

Uses morphlog for beautiful terminal output with per-expert loss breakdown
(e.g., family/slavic=5.12, language/rus=5.11).
"""

from __future__ import annotations

import math
import time
from pathlib import Path
from typing import TypedDict, cast

import torch

from morphoformer import __version__ as MORPHOFORMER_VERSION
from chartoken import CharVocab, FeatureVocab, PAD
from chartoken.feature_vocab import FeatureVocabState
from chartoken.vocab import CharVocabState
from morphoformer.config.schema import DataConfig, MorphoformerConfig, OptimizerConfig, TrainConfig
from morphoformer.model.model import Morphoformer
from morphlog import TrainLogger
from sigmorphon import MorphDataset, load_tsv_pattern
from sigmorphon.dataset import MorphRow
from trainkit import MultiLevelSequenceLoss, create_cosine_schedule, freeze_stages, load_checkpoint, save_checkpoint


class MorphoformerCheckpointMetadata(TypedDict):
    package_version: str
    model_family: str
    model_series: str
    train_stage: str
    device: str
    d_model: int
    dim_ff: int
    num_heads: int
    num_kv_heads: int
    universal_layers: int
    family_layers: int
    language_layers: int
    num_languages: int


class MorphoformerCheckpointBase(TypedDict):
    model_state: dict[str, torch.Tensor]
    optimizer_state: dict[str, object]
    char_vocab: CharVocabState
    feature_vocab: FeatureVocabState
    language_to_id: dict[str, int]
    epoch: int


class MorphoformerCheckpointOptional(TypedDict, total=False):
    global_step: int
    best_dev_loss: float
    metadata: MorphoformerCheckpointMetadata


class MorphoformerCheckpoint(MorphoformerCheckpointBase, MorphoformerCheckpointOptional):
    pass


def _create_grad_scaler(device_type: str, enabled: bool) -> torch.GradScaler:
    return torch.GradScaler(device_type, enabled=enabled)


def _optimizer_step_completed(scaler: torch.GradScaler, previous_scale: float) -> bool:
    if not scaler.is_enabled():
        return True
    return scaler.get_scale() >= previous_scale


def _estimate_batch_count(num_samples: int, batch_size: int) -> int:
    return max(1, math.ceil(num_samples / batch_size))


def _parameter_counts(model: torch.nn.Module) -> tuple[int, int]:
    total_params = sum(parameter.numel() for parameter in model.parameters())
    trainable_params = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
    return total_params, trainable_params


class MorphoformerTrainer:
    """CELMoE trainer with per-expert loss tracking and structured logging."""

    def __init__(self, config: MorphoformerConfig) -> None:
        self.config: MorphoformerConfig = config
        self.data_config: DataConfig = config.data
        self.train_config: TrainConfig = config.train
        self.optimizer_config: OptimizerConfig = config.optimizer
        self.device = torch.device(
            self.train_config.device if self.train_config.device != "cuda" or torch.cuda.is_available() else "cpu"
        )
        self.logger = TrainLogger()

    def _build_vocabs(self, rows: list[MorphRow]) -> tuple[CharVocab, FeatureVocab]:
        texts = [lemma for lemma, _, _, _ in rows] + [surface for _, _, surface, _ in rows]
        tags = [features for _, features, _, _ in rows]
        return CharVocab.from_texts(texts), FeatureVocab.from_tags(tags)

    def _build_language_map(self) -> dict[str, int]:
        return {language: idx for idx, language in enumerate(sorted(self.config.languages))}

    def _create_dataset(
        self,
        rows: list[MorphRow],
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        language_to_id: dict[str, int],
    ) -> MorphDataset:
        return MorphDataset(
            rows,
            char_vocab,
            feature_vocab,
            language_to_id,
            max_len=self.data_config.max_len,
            max_features=self.data_config.max_features,
        )

    def _checkpoint_metadata(self, model: Morphoformer) -> MorphoformerCheckpointMetadata:
        model_config = self.config.model
        return {
            "package_version": MORPHOFORMER_VERSION,
            "model_family": model.model_family,
            "model_series": model.model_series,
            "train_stage": self.train_config.stage,
            "device": self.device.type,
            "d_model": model_config.d_model,
            "dim_ff": model_config.dim_ff,
            "num_heads": model_config.num_heads,
            "num_kv_heads": model_config.num_kv_heads,
            "universal_layers": model_config.universal_layers,
            "family_layers": model_config.family_layers,
            "language_layers": model_config.language_layers,
            "num_languages": len(self.config.languages),
        }

    def _checkpoint_payload(
        self,
        model: Morphoformer,
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        optimizer: torch.optim.Optimizer,
        epoch: int,
        global_step: int,
        best_dev_loss: float,
    ) -> MorphoformerCheckpoint:
        return {
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "char_vocab": char_vocab.to_dict(),
            "feature_vocab": feature_vocab.to_dict(),
            "language_to_id": model.language_to_id,
            "epoch": epoch,
            "global_step": global_step,
            "best_dev_loss": best_dev_loss,
            "metadata": self._checkpoint_metadata(model),
        }

    def train(self) -> Path:
        """Run the full training loop with per-expert loss tracking."""
        train_config = self.train_config
        optimizer_config = self.optimizer_config
        train_rows = load_tsv_pattern(self.data_config.train_path)
        dev_rows = load_tsv_pattern(self.data_config.dev_path)
        char_vocab, feature_vocab = self._build_vocabs(train_rows + dev_rows)
        language_to_id = self._build_language_map()
        train_data = self._create_dataset(train_rows, char_vocab, feature_vocab, language_to_id)
        dev_data = self._create_dataset(dev_rows, char_vocab, feature_vocab, language_to_id)

        model = Morphoformer(
            self.config,
            vocab_size=char_vocab.size,
            feature_vocab_size=feature_vocab.size,
            language_to_id=language_to_id,
        ).to(self.device)
        freeze_stages(model, train_config.stage)
        batch_size: int = train_config.batch_size
        train_batches_per_epoch = _estimate_batch_count(train_data.num_samples, batch_size)
        dev_batches_per_epoch = _estimate_batch_count(dev_data.num_samples, batch_size)
        total_train_batches = train_batches_per_epoch * train_config.epochs
        total_params, trainable_params = _parameter_counts(model)
        families = sorted({payload.family for payload in self.config.languages.values()})

        self.logger.training_header(
            version=MORPHOFORMER_VERSION,
            model_family=model.model_family,
            model_series=model.model_series,
            stage=train_config.stage,
            device=self.device.type,
            amp=train_config.mixed_precision,
            train_rows=train_data.num_samples,
            dev_rows=dev_data.num_samples,
            num_languages=len(self.config.languages),
            num_families=len(families),
            families=families,
            languages=sorted(self.config.languages.keys()),
            max_len=self.data_config.max_len,
            max_features=self.data_config.max_features,
            d_model=self.config.model.d_model,
            dim_ff=self.config.model.dim_ff,
            num_heads=self.config.model.num_heads,
            num_kv_heads=self.config.model.num_kv_heads,
            universal_layers=self.config.model.universal_layers,
            family_layers=self.config.model.family_layers,
            language_layers=self.config.model.language_layers,
            total_params=total_params,
            trainable_params=trainable_params,
            epochs=train_config.epochs,
            batch_size=batch_size,
            train_batches=train_batches_per_epoch,
            dev_batches=dev_batches_per_epoch,
            total_steps=train_config.total_steps,
            warmup_steps=train_config.warmup_steps,
            lr=optimizer_config.lr,
            weight_decay=optimizer_config.weight_decay,
            betas=optimizer_config.betas,
            output_dir=train_config.output_dir,
            loss_weights={
                "final": train_config.final_loss_weight,
                "universal": train_config.universal_loss_weight,
                "family": train_config.family_loss_weight,
                "language": train_config.language_loss_weight,
            },
        )

        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=optimizer_config.lr,
            betas=optimizer_config.betas,
            weight_decay=optimizer_config.weight_decay,
        )
        scheduler = create_cosine_schedule(
            optimizer,
            warmup_steps=train_config.warmup_steps,
            total_steps=train_config.total_steps,
        )
        criterion = MultiLevelSequenceLoss(
            pad_id=PAD,
            final_weight=train_config.final_loss_weight,
            universal_weight=train_config.universal_loss_weight,
            family_weight=train_config.family_loss_weight,
            language_weight=train_config.language_loss_weight,
        )

        scaler = _create_grad_scaler(
            self.device.type,
            self.device.type == "cuda" and train_config.mixed_precision,
        )
        output_dir = Path(train_config.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        best_path = output_dir / "best.pt"
        interrupted_path = output_dir / "interrupted.pt"
        best_dev_loss = float("inf")
        global_step = 0
        train_start_time = time.perf_counter()
        current_epoch = 0
        current_batch = 0

        try:
            for epoch in range(1, train_config.epochs + 1):
                current_epoch = epoch
                current_batch = 0
                epoch_start_time = time.perf_counter()
                model.train()
                self.logger.epoch_start(epoch, train_config.epochs, train_batches_per_epoch, dev_batches_per_epoch)

                for batch_index, batch in enumerate(train_data.epoch_batches(batch_size, self.device), start=1):
                    current_batch = batch_index
                    source, target, language_ids, feature_ids, feature_mask = batch
                    optimizer.zero_grad(set_to_none=True)
                    with torch.autocast(device_type=self.device.type, enabled=scaler.is_enabled()):
                        output = model(source, language_ids, feature_ids, feature_mask)
                        losses = criterion(output, target)
                    scaler.scale(losses.total).backward()
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), train_config.clip_grad_norm)
                    previous_scale = scaler.get_scale()
                    scaler.step(optimizer)
                    scaler.update()
                    if _optimizer_step_completed(scaler, previous_scale):
                        scheduler.step()
                        global_step += 1
                    if global_step > 0 and global_step % train_config.log_interval == 0:
                        completed_batches = (epoch - 1) * train_batches_per_epoch + batch_index
                        elapsed = time.perf_counter() - train_start_time
                        self.logger.batch_update(
                            epoch=epoch,
                            total_epochs=train_config.epochs,
                            batch=batch_index,
                            total_batches=train_batches_per_epoch,
                            step=global_step,
                            total_steps=train_config.total_steps,
                            learning_rate=optimizer.param_groups[0]["lr"],
                            losses=losses.as_scalars(),
                            elapsed_seconds=elapsed,
                            total_completed_batches=completed_batches,
                            total_train_batches=total_train_batches,
                            best_dev_loss=best_dev_loss,
                        )

                dev_loss, dev_expert_losses = self.evaluate(model, dev_data, criterion)
                epoch_elapsed = time.perf_counter() - epoch_start_time
                elapsed = time.perf_counter() - train_start_time
                remaining_epochs = max(0, train_config.epochs - epoch)
                remaining_seconds = (elapsed / max(1, epoch)) * remaining_epochs
                improved = dev_loss < best_dev_loss
                checkpoint_path = None
                if improved:
                    best_dev_loss = dev_loss
                    save_checkpoint(
                        best_path,
                        self._checkpoint_payload(
                            model, char_vocab, feature_vocab,
                            optimizer, epoch, global_step, best_dev_loss,
                        ),
                    )
                    checkpoint_path = str(best_path)
                self.logger.epoch_end(
                    epoch=epoch,
                    total_epochs=train_config.epochs,
                    dev_loss=dev_loss,
                    best_dev_loss=best_dev_loss,
                    improved=improved,
                    epoch_elapsed=epoch_elapsed,
                    total_elapsed=elapsed,
                    remaining_seconds=remaining_seconds,
                    checkpoint_path=checkpoint_path,
                    dev_expert_losses=dev_expert_losses,
                )

        except KeyboardInterrupt:
            optimizer.zero_grad(set_to_none=True)
            interrupted_elapsed = time.perf_counter() - train_start_time
            save_checkpoint(
                interrupted_path,
                self._checkpoint_payload(
                    model, char_vocab, feature_vocab,
                    optimizer, current_epoch, global_step, best_dev_loss,
                ),
            )
            self.logger.training_interrupted(
                epoch=current_epoch,
                total_epochs=train_config.epochs,
                batch=current_batch,
                total_batches=train_batches_per_epoch,
                step=global_step,
                total_steps=train_config.total_steps,
                elapsed_seconds=interrupted_elapsed,
                checkpoint_path=str(interrupted_path),
            )
            return interrupted_path

        total_elapsed = time.perf_counter() - train_start_time
        self.logger.training_complete(str(best_path), best_dev_loss, total_elapsed)
        return best_path

    def evaluate(
        self,
        model: Morphoformer,
        dataset: MorphDataset,
        criterion: MultiLevelSequenceLoss,
    ) -> tuple[float, dict[str, float]]:
        """Evaluate on dev set, returning total loss and per-expert breakdown.

        Returns:
            Tuple of (total_dev_loss, per_expert_losses_dict).
        """
        model.eval()
        total_losses: list[float] = []
        accumulated_expert_losses: dict[str, list[float]] = {}
        batch_size: int = self.train_config.batch_size
        with torch.no_grad():
            for source, target, language_ids, feature_ids, feature_mask in dataset.epoch_batches(
                batch_size,
                self.device,
            ):
                output = model(source, language_ids, feature_ids, feature_mask)
                breakdown = criterion(output, target)
                total_losses.append(float(breakdown.total.detach().cpu()))

                for expert_key, expert_loss in breakdown.per_expert.items():
                    if expert_key not in accumulated_expert_losses:
                        accumulated_expert_losses[expert_key] = []
                    accumulated_expert_losses[expert_key].append(expert_loss)

        avg_total = sum(total_losses) / max(1, len(total_losses))
        avg_expert: dict[str, float] = {}
        for key, values in accumulated_expert_losses.items():
            avg_expert[key] = sum(values) / max(1, len(values))
        return avg_total, avg_expert

    def load_model(self, checkpoint_path: str | Path) -> tuple[Morphoformer, CharVocab, FeatureVocab]:
        """Load model from checkpoint for inference."""
        checkpoint = cast(MorphoformerCheckpoint, load_checkpoint(checkpoint_path, map_location=self.device))
        char_vocab = CharVocab.from_dict(checkpoint["char_vocab"])
        feature_vocab = FeatureVocab.from_dict(checkpoint["feature_vocab"])
        language_to_id = checkpoint["language_to_id"]
        model = Morphoformer(
            self.config,
            vocab_size=char_vocab.size,
            feature_vocab_size=feature_vocab.size,
            language_to_id=language_to_id,
        ).to(self.device)
        model.load_state_dict(checkpoint["model_state"])
        model.eval()
        return model, char_vocab, feature_vocab
