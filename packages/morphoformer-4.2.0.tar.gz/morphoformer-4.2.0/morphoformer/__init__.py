"""Public API for the morphoformer application package."""

from morphoformer.config.loader import load_config
from morphoformer.model.model import Morphoformer

__all__: list[str] = [
    "Morphoformer",
    "load_config",
]

__version__: str = "4.2.0"
