# -*- coding: utf-8 -*-

import os

import pytest

from PyPDFForm import Fields, PdfWrapper


def test_create_field_deprecated(template_stream):
    with pytest.warns(
        DeprecationWarning,
        match="PdfWrapper.create_field will be deprecated soon. Use PdfWrapper.bulk_create_fields instead.",
    ):
        assert (
            PdfWrapper(template_stream)
            .create_field(Fields.TextField("foo", 1, 100, 100))
            .read()
            == PdfWrapper(template_stream)
            .bulk_create_fields([Fields.TextField("foo", 1, 100, 100)])
            .read()
        )


@pytest.mark.posix_only
def test_create_checkbox_complex_fill(template_stream, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_checkbox_complex_fill.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.CheckBoxField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                    size=100,
                    button_style="check",
                    tick_color=(0, 1, 0),
                    bg_color=(0, 0, 1),
                    border_color=(1, 0, 0),
                    border_width=5,
                )
            ]
        )
        obj.fill(obj.sample_data)

        assert obj.schema["properties"]["foo"]["type"] == "boolean"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_checkbox_check_fill(template_stream, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_checkbox_check_fill.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.CheckBoxField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                    button_style="check",
                )
            ]
        )
        obj.fill(obj.sample_data)

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_checkbox_circle_fill(template_stream, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_checkbox_circle_fill.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.CheckBoxField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                    button_style="circle",
                )
            ]
        )
        obj.fill(obj.sample_data)

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_checkbox_cross_fill(template_stream, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_checkbox_cross_fill.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.CheckBoxField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                    button_style="cross",
                )
            ]
        )
        obj.fill(obj.sample_data)

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_text_alpha_bg_color(template_stream, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_text_alpha_bg_color.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.TextField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                    bg_color=(0, 0, 1, 0),
                )
            ]
        )
        assert obj.schema["properties"]["foo"]["type"] == "string"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_text_align_center(template_stream, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_text_align_center.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.TextField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                    alignment=1,
                )
            ]
        )
        assert obj.schema["properties"]["foo"]["type"] == "string"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_text_multiline(template_stream, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_text_align_multiline.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.TextField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                    multiline=True,
                )
            ]
        )
        assert obj.schema["properties"]["foo"]["type"] == "string"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_text_complex_filled(
    template_stream, pdf_samples, sample_font_stream, request
):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_text_complex_filled.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = (
            PdfWrapper(template_stream)
            .register_font("new_font", sample_font_stream)
            .bulk_create_fields(
                [
                    Fields.TextField(
                        name="foo",
                        page_number=1,
                        x=100,
                        y=100,
                        width=400,
                        height=400,
                        max_length=2,
                        font="new_font",
                        font_size=50,
                        font_color=(1, 0.5, 1),
                        bg_color=(0, 0, 1),
                        border_color=(1, 0, 0),
                        border_width=5,
                    )
                ]
            )
        )
        obj.fill(obj.sample_data)

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_text_comb(template_stream, pdf_samples, request):
    expected_path = os.path.join(pdf_samples, "widget", "test_create_text_comb.pdf")
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.TextField(
                    "foo",
                    page_number=1,
                    x=100,
                    y=100,
                    max_length=3,
                    comb=True,
                )
            ]
        )

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_checkbox_persist_old_widgets_fill(
    template_stream, pdf_samples, request
):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_checkbox_persist_old_widgets_fill.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream)
        obj.widgets["test"].font_size = 30
        obj.widgets["test"].font_color = (0, 1, 0)
        obj.bulk_create_fields(
            [
                Fields.CheckBoxField(
                    name="foo",
                    page_number=1,
                    x=100,
                    y=100,
                )
            ]
        ).fill(obj.sample_data)
        assert obj.schema["properties"]["foo"]["type"] == "boolean"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_widget_sejda_fill_flatten_before(sejda_template, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_widget_sejda_fill_flatten_before.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(sejda_template)
        obj.fill(obj.sample_data, flatten=True).bulk_create_fields(
            [
                Fields.TextField(
                    name="new_text_field_widget",
                    page_number=1,
                    x=72,
                    y=730,
                    width=120,
                    height=40,
                    max_length=6,
                    font="Helvetica",
                    font_size=20,
                    font_color=(0, 0, 1),
                )
            ]
        ).fill(obj.sample_data)
        assert obj.schema["properties"]["new_text_field_widget"]["type"] == "string"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_widget_sejda_fill_flatten_after(sejda_template, pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_widget_sejda_fill_flatten_after.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(sejda_template)
        obj.fill(obj.sample_data).bulk_create_fields(
            [
                Fields.TextField(
                    name="new_text_field_widget",
                    page_number=1,
                    x=72,
                    y=730,
                    width=120,
                    height=40,
                    max_length=6,
                    font="Helvetica",
                    font_size=20,
                    font_color=(0, 0, 1),
                )
            ]
        ).fill(obj.sample_data, flatten=True)
        assert obj.schema["properties"]["new_text_field_widget"]["type"] == "string"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


def test_create_widget_sejda_schema(sejda_template):
    obj = PdfWrapper(sejda_template)
    old_schema = obj.schema
    schema = (
        PdfWrapper(sejda_template)
        .bulk_create_fields(
            [
                Fields.TextField(
                    name="new_text_field_widget",
                    page_number=1,
                    x=72,
                    y=730,
                    width=120,
                    height=40,
                    max_length=6,
                    font="Times-Roman",
                    font_size=20,
                    font_color=(0, 0, 1),
                )
            ]
        )
        .schema
    )

    assert schema["properties"]["new_text_field_widget"]
    assert len(schema["properties"]) == len(old_schema["properties"]) + 1


def test_fill_cmyk_color(pdf_samples, request):
    expected_path = os.path.join(pdf_samples, "widget", "test_fill_cmyk_color.pdf")
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(
            os.path.join(pdf_samples, "widget", "sample_template_with_cmyk_color.pdf")
        ).fill({"foo": "foo"})

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_radio_complex(template_stream, pdf_samples, request):
    expected_path = os.path.join(pdf_samples, "widget", "test_create_radio_complex.pdf")
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(template_stream).bulk_create_fields(
            [
                Fields.RadioGroup(
                    name="radio",
                    page_number=2,
                    x=[50, 100, 150],
                    y=[50, 100, 150],
                    size=50,
                    button_style="check",
                    shape="circle",
                    tick_color=(0, 1, 0),
                    bg_color=(0, 0, 1, 1),
                    border_color=(1, 0, 0),
                    border_width=5,
                )
            ]
        )
        assert obj.schema["properties"]["radio"]["type"] == "integer"

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_required_fields(pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_required_fields.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(os.path.join(pdf_samples, "dummy.pdf")).bulk_create_fields(
            [
                Fields.TextField(
                    name="new_text", page_number=1, x=100, y=100, required=True
                ),
                Fields.CheckBoxField(
                    name="new_check", page_number=1, x=100, y=200, required=True
                ),
                Fields.RadioGroup(
                    name="new_radio_group",
                    page_number=1,
                    x=[300, 350, 400],
                    y=[100, 150, 200],
                    required=True,
                ),
                Fields.DropdownField(
                    name="new_dropdown",
                    page_number=1,
                    x=400,
                    y=400,
                    required=True,
                    options=["apple", "banana", "cherry"],
                ),
                Fields.ImageField(
                    name="new_image",
                    page_number=1,
                    x=300,
                    y=600,
                    required=True,
                ),
                Fields.SignatureField(
                    name="new_signature", page_number=1, x=100, y=600, required=True
                ),
            ]
        )

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_not_required_fields(pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_not_required_fields.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(os.path.join(pdf_samples, "dummy.pdf")).bulk_create_fields(
            [
                Fields.TextField(
                    name="new_text", page_number=1, x=100, y=100, required=False
                ),
                Fields.CheckBoxField(
                    name="new_check", page_number=1, x=100, y=200, required=False
                ),
                Fields.RadioGroup(
                    name="new_radio_group",
                    page_number=1,
                    x=[300, 350, 400],
                    y=[100, 150, 200],
                    required=False,
                ),
                Fields.DropdownField(
                    name="new_dropdown",
                    page_number=1,
                    x=400,
                    y=400,
                    required=False,
                    options=["apple", "banana", "cherry"],
                ),
                Fields.ImageField(
                    name="new_image",
                    page_number=1,
                    x=300,
                    y=600,
                    required=False,
                ),
                Fields.SignatureField(
                    name="new_signature", page_number=1, x=100, y=600, required=False
                ),
            ]
        )

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected


@pytest.mark.posix_only
def test_create_fields_with_tooltips(pdf_samples, request):
    expected_path = os.path.join(
        pdf_samples, "widget", "test_create_fields_with_tooltips.pdf"
    )
    with open(expected_path, "rb+") as f:
        obj = PdfWrapper(os.path.join(pdf_samples, "dummy.pdf")).bulk_create_fields(
            [
                Fields.TextField(
                    name="new_text", page_number=1, x=100, y=100, tooltip="new_text"
                ),
                Fields.CheckBoxField(
                    name="new_check",
                    page_number=1,
                    x=100,
                    y=200,
                    tooltip="new_checkbox",
                ),
                Fields.RadioGroup(
                    name="new_radio_group",
                    page_number=1,
                    x=[300, 350, 400],
                    y=[100, 150, 200],
                    tooltip="new_radio_group",
                ),
                Fields.DropdownField(
                    name="new_dropdown",
                    page_number=1,
                    x=400,
                    y=400,
                    options=["apple", "banana", "cherry"],
                    tooltip="new_dropdown",
                ),
                Fields.ImageField(
                    name="new_image",
                    page_number=1,
                    x=300,
                    y=600,
                    tooltip="new_image",
                ),
                Fields.SignatureField(
                    name="new_signature",
                    page_number=1,
                    x=100,
                    y=600,
                    tooltip="new_signature",
                ),
            ]
        )

        request.config.results["expected_path"] = expected_path
        request.config.results["stream"] = obj.read()

        expected = f.read()

        assert len(obj.read()) == len(expected)
        assert obj.read() == expected
