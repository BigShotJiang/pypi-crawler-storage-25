# QA STLC Agents — Complete Setup Guide

## The error explained

```
spawn /Users/gk/Downloads/qa-stlc-monorepo/src/qa_stlc_agents/agent_playwright_generator ENOENT
```

The MCP client is trying to run the **Python source folder** as an executable.
The correct path is the wrapper script inside `.venv/bin/`, e.g.
`/Users/gk/Downloads/qa-stlc-monorepo-playwright-mcp/.venv/bin/qa-playwright-generator`

This happens when `make mcp-config` was never run (so no `.mcp.json` exists), or the
config was generated for a different copy of the repo, or an old hand-written config
is still pointing at the wrong path.

The fix is to run `make mcp-config` from inside the correct repo folder. The steps
below cover everything from scratch.

---

## Prerequisites (install once)

```bash
# 1. Python 3.10–3.13 — check your version
python3 --version        # must be 3.10, 3.11, 3.12, or 3.13

# 2. Node.js 18+ — needed for Playwright MCP
node --version           # must be v18 or higher
npm --version

# 3. Claude Code CLI — must be installed and on PATH
claude --version
```

If `python3 --version` shows 3.9 or earlier, install a newer version via
`brew install python@3.12` (macOS) or `pyenv`.

---

## Step 1 — Open a terminal in the project folder

```bash
cd /Users/gk/Downloads/qa-stlc-monorepo-playwright-mcp
```

**All commands below are run from this folder.**

---

## Step 2 — Clean any broken previous install

```bash
make clean
```

This removes `.venv`, `__pycache__`, `dist`, and any stale `.mcp.json`.
If `make` is not found, run the commands manually:

```bash
rm -rf .venv __pycache__ dist *.egg-info .mcp.json .vscode/mcp.json
```

---

## Step 3 — Install the three QA agents

```bash
make install
```

This creates a fresh `.venv` and installs all three agent entry points:

```
.venv/bin/qa-test-case-manager
.venv/bin/qa-gherkin-generator
.venv/bin/qa-playwright-generator
```

Also install pytest for running tests:

```bash
make install-dev
```

**Verify the binaries exist:**

```bash
ls -la .venv/bin/qa-*
```

You should see three files. If they are missing, the install failed — re-run
`make install` and check for errors.

---

## Step 4 — Run the tests to confirm everything works

```bash
make test
```

Expected output: `18 passed`. If any test fails, something went wrong in Step 3.

---

## Step 5 — Install skill files

```bash
make skills
```

This copies the three Markdown skill files into `.claude/skills/` so Claude Code
can read them.

---

## Step 6 — Generate the MCP config with correct absolute paths

```bash
make mcp-config
```

This runs `scripts/generate-mcp-config.py` which writes `.mcp.json` with the exact
absolute paths to the `.venv/bin/` binaries on your machine. Open `.mcp.json` and
confirm it looks like this (paths will reflect your machine):

```json
{
  "mcpServers": {
    "qa-test-case-manager": {
      "command": "/Users/gk/Downloads/qa-stlc-monorepo-playwright-mcp/.venv/bin/qa-test-case-manager"
    },
    "qa-gherkin-generator": {
      "command": "/Users/gk/Downloads/qa-stlc-monorepo-playwright-mcp/.venv/bin/qa-gherkin-generator"
    },
    "qa-playwright-generator": {
      "command": "/Users/gk/Downloads/qa-stlc-monorepo-playwright-mcp/.venv/bin/qa-playwright-generator"
    },
    "playwright": {
      "type": "url",
      "url": "ws://localhost:8931"
    }
  }
}
```

**The `command` values must be absolute paths ending in `.venv/bin/qa-*`, not source
directories.** If you see `src/qa_stlc_agents/...` anywhere in this file, delete the
file and re-run `make mcp-config`.

---

## Step 7 — Verify MSAL auth (Azure DevOps login)

```bash
make verify
```

One of two things will happen:

- **"Signed in as: your@email.com"** — you're already authenticated, nothing else needed.
- **"No cached token"** — a browser window will open the first time a tool is called.
  Sign in with your Microsoft/Azure DevOps account once; the token is cached for ~90 days.

---

## Step 8 — Start Playwright MCP (keep this terminal running)

Open a **new terminal tab** (keep the project terminal open):

```bash
npx @playwright/mcp@latest --port 8931
```

You should see output like:
```
Playwright MCP server listening on ws://localhost:8931
```

Leave this running. If you close it, the `playwright` MCP server will be unavailable
and browser-based locator verification will not work (generation still works, just
without live DOM verification).

> **First run only:** `npx` will download `@playwright/mcp` automatically.
> This requires Node.js 18+ and internet access.

---

## Step 9 — Open Claude Code in this project

```bash
# From the project folder:
claude
```

Or open Claude Code from your application launcher and use `File → Open Folder` to
open `/Users/gk/Downloads/qa-stlc-monorepo-playwright-mcp`.

Claude Code automatically reads `.mcp.json` from the project root and starts all
four servers.

---

## Step 10 — Verify all four MCP servers are loaded

In Claude Code, type:

```
/mcp
```

You should see all four servers listed as **connected**:

```
● qa-test-case-manager     connected    3 tools
● qa-gherkin-generator     connected    2 tools
● qa-playwright-generator  connected    4 tools
● playwright               connected    20+ tools
```

If any show **error** or **disconnected**:

| Server | Fix |
|--------|-----|
| `qa-test-case-manager` | Re-run `make install`, then `make mcp-config` |
| `qa-gherkin-generator` | Re-run `make install`, then `make mcp-config` |
| `qa-playwright-generator` | Re-run `make install`, then `make mcp-config` |
| `playwright` | Start `npx @playwright/mcp@latest --port 8931` in a separate terminal |

---

## Step 11 — Run the pipeline

Paste this prompt into Claude Code, filling in your details:

```
Generate test cases, Gherkin BDD feature file, and self-healing Playwright
TypeScript automation for work item #<ID> in <ProjectName> at
https://dev.azure.com/<org>.

The live app is running at https://<your-app-url>.
Credentials: <email> / <password>
```

---

## Troubleshooting

### "spawn ... ENOENT" error in MCP logs

The path in `.mcp.json` or `.vscode/mcp.json` is wrong.

```bash
# Delete any stale config and regenerate
rm -f .mcp.json .vscode/mcp.json
make mcp-config          # for Claude Code
make mcp-config-vscode   # for VS Code / Copilot
```

### "No module named pytest"

```bash
make install-dev
```

### "No module named mcp" or import errors

The venv is not activated or install is incomplete:

```bash
make clean
make install
```

### Browser opens for Azure DevOps login

This is normal on first use. Sign in once and the token is cached for ~90 days.
In CI/CD, set `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`, `AZURE_TENANT_ID`
environment variables to use a service principal instead.

### Playwright MCP not connecting

```bash
# Check if port 8931 is already in use
lsof -i :8931

# Kill whatever is on it and restart
kill -9 <PID>
npx @playwright/mcp@latest --port 8931
```

### `make` command not found (macOS)

```bash
xcode-select --install
```

---

## Quick-reference: commands to run in order

```bash
cd /Users/gk/Downloads/qa-stlc-monorepo-playwright-mcp

make clean          # wipe any broken state
make install        # install the three agents into .venv
make install-dev    # add pytest
make test           # confirm 18 tests pass
make skills         # copy skill files to .claude/skills/
make mcp-config     # write .mcp.json with correct absolute paths
make verify         # check Azure DevOps auth

# In a separate terminal — keep running:
npx @playwright/mcp@latest --port 8931

# Then open Claude Code in this folder and run /mcp to confirm all 4 servers connected
claude
```
