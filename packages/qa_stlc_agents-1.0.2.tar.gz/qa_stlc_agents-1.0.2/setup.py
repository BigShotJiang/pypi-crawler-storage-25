#!/usr/bin/env python3
"""
setup.py — One-file setup for QA STLC Agents. No make required.

Usage:
    python3 setup.py              # full setup: install → test → skills → mcp-config → verify
    python3 setup.py install      # create .venv and pip install
    python3 setup.py test         # run pytest
    python3 setup.py skills       # copy skill files to .claude/skills/
    python3 setup.py skills-vscode# copy skill files to .github/copilot-instructions/
    python3 setup.py mcp-config   # write Claude Code MCP config (.mcp.json)
    python3 setup.py mcp-vscode   # write VS Code MCP config (.vscode/mcp.json)
    python3 setup.py verify       # check MSAL auth status
    python3 setup.py clean        # remove .venv, __pycache__, dist, .mcp.json

Runs on Python 3.10+ with no external tools. Works on macOS, Linux, and Windows.
"""

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

# ── Project root is always the directory this file lives in ───────────────────
ROOT = Path(__file__).parent.resolve()

# ── Virtual-environment layout (Windows vs Unix) ──────────────────────────────
IS_WINDOWS  = platform.system() == "Windows"
VENV_DIR    = ROOT / ".venv"
BIN_DIR     = VENV_DIR / ("Scripts" if IS_WINDOWS else "bin")
EXT         = ".exe" if IS_WINDOWS else ""
VENV_PYTHON = BIN_DIR / f"python{EXT}"
VENV_PIP    = BIN_DIR / f"pip{EXT}"

# ── MCP agent entry-point binaries (created by pip install -e .) ──────────────
AGENTS = {
    "qa-test-case-manager":    BIN_DIR / f"qa-test-case-manager{EXT}",
    "qa-gherkin-generator":    BIN_DIR / f"qa-gherkin-generator{EXT}",
    "qa-playwright-generator": BIN_DIR / f"qa-playwright-generator{EXT}",
    "qa-helix-writer":         BIN_DIR / f"qa-helix-writer{EXT}",
}

PLAYWRIGHT_MCP_PORT = 8931


# ── Helpers ───────────────────────────────────────────────────────────────────

def run(*args, check=True, **kwargs):
    """Run a subprocess command, printing it first."""
    print(f"  $ {' '.join(str(a) for a in args)}")
    return subprocess.run([str(a) for a in args], check=check, **kwargs)


def section(title):
    width = max(len(title) + 4, 50)
    print()
    print("─" * width)
    print(f"  {title}")
    print("─" * width)


def ok(msg):
    print(f"✓  {msg}")


def warn(msg):
    print(f"⚠  {msg}")


def die(msg):
    print(f"✗  {msg}", file=sys.stderr)
    sys.exit(1)


# ── Commands ──────────────────────────────────────────────────────────────────

def cmd_install():
    section("Creating virtual environment")
    run(sys.executable, "-m", "venv", VENV_DIR)
    ok(f"Virtual environment created at {VENV_DIR}")

    section("Upgrading pip")
    run(VENV_PYTHON, "-m", "pip", "install", "--upgrade", "pip", "--quiet")

    section("Installing QA STLC agents (editable)")
    run(VENV_PYTHON, "-m", "pip", "install", "-e", ROOT, "--quiet")

    section("Installing dev dependencies (pytest)")
    run(VENV_PYTHON, "-m", "pip", "install", "pytest", "pytest-asyncio", "--quiet")

    section("Verifying agent binaries")
    missing = []
    for name, path in AGENTS.items():
        if path.exists():
            ok(f"{name}  →  {path}")
        else:
            warn(f"{name} binary not found at {path}")
            missing.append(name)
    if missing:
        die("Installation incomplete — some binaries are missing. Check pip output above.")


def cmd_test():
    section("Running tests")
    if not VENV_PYTHON.exists():
        die("Virtual environment not found. Run:  python3 setup.py install")
    run(VENV_PYTHON, "-m", "pytest", ROOT / "tests", "-v")


def cmd_skills():
    section("Installing skill files → .claude/skills/")
    dest = ROOT / ".claude" / "skills"
    dest.mkdir(parents=True, exist_ok=True)

    skills_src = ROOT / "skills"
    files = [
        "generate-test-cases.md",
        "generate-gherkin.md",
        "generate-playwright-code.md",
        "write-helix-files.md",
        "deduplication-protocol.md",
    ]
    for f in files:
        shutil.copy(skills_src / f, dest / f)
        ok(f"Copied {f}")

    # Also copy AGENT-BEHAVIOR.md one level up into .claude/
    agent_beh = ROOT / "AGENT-BEHAVIOR.md"
    if agent_beh.exists():
        shutil.copy(agent_beh, ROOT / ".claude" / "AGENT-BEHAVIOR.md")
        ok("Copied AGENT-BEHAVIOR.md → .claude/")

    print()
    print("Skills available to Claude Code:")
    print("  • AGENT-BEHAVIOR.md           → zero-inference contract (read first)")
    for f in files:
        print(f"  • {f}")


def cmd_skills_vscode():
    section("Installing skill files → .github/copilot-instructions/")
    dest = ROOT / ".github" / "copilot-instructions"
    dest.mkdir(parents=True, exist_ok=True)

    for f in (ROOT / "skills").glob("*.md"):
        shutil.copy(f, dest / f.name)
        ok(f"Copied {f.name}")

    agent_beh = ROOT / "AGENT-BEHAVIOR.md"
    if agent_beh.exists():
        shutil.copy(agent_beh, dest / "AGENT-BEHAVIOR.md")
        ok("Copied AGENT-BEHAVIOR.md")

    print()
    print("Add to VS Code settings.json or .github/copilot-instructions.md:")
    print("  @.github/copilot-instructions/AGENT-BEHAVIOR.md")


def _build_claude_config() -> dict:
    servers = {name: {"command": str(path)} for name, path in AGENTS.items()}
    servers["playwright"] = {"type": "url", "url": f"ws://localhost:{PLAYWRIGHT_MCP_PORT}"}
    return {"mcpServers": servers}


def _build_vscode_config() -> dict:
    # Minimal command-only format — VS Code does not require type/args/env for stdio agents.
    # All four agents are included: the three ADO agents plus qa-helix-writer which is called
    # from the automation repo (Helix-QA) to write generated files to the correct disk layout.
    servers = {
        name: {"command": str(path)}
        for name, path in AGENTS.items()
    }
    # Playwright MCP uses HTTP transport with the /mcp path suffix VS Code expects.
    servers["playwright"] = {
        "type": "http",
        "url": f"http://localhost:{PLAYWRIGHT_MCP_PORT}/mcp",
    }
    return {"servers": servers}


def _check_binaries_for_config():
    missing = [n for n, p in AGENTS.items() if not p.exists()]
    if missing:
        warn("Some agent binaries not found — run  python3 setup.py install  first:")
        for n in missing:
            print(f"   {AGENTS[n]}")
        print()


def cmd_mcp_config():
    section("Writing Claude Code MCP config → .mcp.json")
    _check_binaries_for_config()
    out = ROOT / ".mcp.json"
    out.write_text(json.dumps(_build_claude_config(), indent=2) + "\n", encoding="utf-8")
    ok(f"Written to {out}")
    print()
    print("Next steps:")
    print(f"  1. Start Playwright MCP:  npx @playwright/mcp@latest --port {PLAYWRIGHT_MCP_PORT}")
    print("  2. Open this project in Claude Code")
    print("  3. Run /mcp to verify all five servers are loaded")


def cmd_mcp_vscode():
    section("Writing VS Code MCP config → .vscode/mcp.json")
    _check_binaries_for_config()
    vscode_dir = ROOT / ".vscode"
    vscode_dir.mkdir(exist_ok=True)
    out = vscode_dir / "mcp.json"
    out.write_text(json.dumps(_build_vscode_config(), indent=2) + "\n", encoding="utf-8")
    ok(f"Written to {out}")
    print()
    print("Next steps:")
    print(f"  1. Start Playwright MCP:  npx @playwright/mcp@latest --port {PLAYWRIGHT_MCP_PORT}")
    print("  2. Open VS Code in this workspace — MCP servers appear in the MCP panel")
    print("  3. GitHub Copilot Chat picks them up automatically on next conversation")


def cmd_verify():
    section("Checking MSAL auth status")
    if not VENV_PYTHON.exists():
        die("Virtual environment not found. Run:  python3 setup.py install")
    result = run(
        VENV_PYTHON, "-c",
        "from qa_stlc_agents.shared.auth import get_signed_in_user; "
        "u = get_signed_in_user(); "
        "print('Signed in as: ' + u if u else "
        "'No cached token — browser will open on first tool call')",
        check=False, capture_output=True, text=True,
    )
    print(result.stdout.strip() or result.stderr.strip())


def cmd_clean():
    section("Cleaning build artifacts")
    targets = [
        VENV_DIR,
        ROOT / "dist",
        ROOT / ".mcp.json",
    ]
    # Find all __pycache__ and *.egg-info directories
    for pattern in ("**/__pycache__", "**/*.egg-info"):
        targets.extend(ROOT.glob(pattern))

    for t in targets:
        t = Path(t)
        if t.exists():
            if t.is_dir():
                shutil.rmtree(t)
            else:
                t.unlink()
            ok(f"Removed {t.relative_to(ROOT)}")

    # Remove .pyc files
    for pyc in ROOT.glob("**/*.pyc"):
        pyc.unlink()

    ok("Clean complete")


def cmd_full():
    """Default: full setup pipeline."""
    cmd_install()
    cmd_test()
    cmd_skills()
    cmd_mcp_config()
    cmd_verify()

    print()
    print("=" * 55)
    print("  ✅  Setup complete!")
    print("=" * 55)
    print()
    print("Start Playwright MCP in a new terminal:")
    print(f"  npx @playwright/mcp@latest --port {PLAYWRIGHT_MCP_PORT}")
    print()
    print("For VS Code, also run:")
    print("  python3 setup.py mcp-vscode")
    print()
    print("Then open Claude Code:")
    print("  claude")


# ── Dispatch ──────────────────────────────────────────────────────────────────
COMMANDS = {
    "install":       cmd_install,
    "test":          cmd_test,
    "skills":        cmd_skills,
    "skills-vscode": cmd_skills_vscode,
    "mcp-config":    cmd_mcp_config,
    "mcp-vscode":    cmd_mcp_vscode,
    "verify":        cmd_verify,
    "clean":         cmd_clean,
}

if __name__ == "__main__":
    cmd_name = sys.argv[1] if len(sys.argv) > 1 else None

    if cmd_name is None:
        cmd_full()
    elif cmd_name in COMMANDS:
        COMMANDS[cmd_name]()
    else:
        print(f"Unknown command: {cmd_name}")
        print()
        print("Available commands:")
        print("  (none)         full setup: install → test → skills → mcp-config → verify")
        for name in COMMANDS:
            print(f"  {name}")
        sys.exit(1)
