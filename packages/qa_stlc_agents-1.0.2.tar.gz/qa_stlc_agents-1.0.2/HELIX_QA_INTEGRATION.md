# Playwright Generation Agent — Helix-QA Integration Guide

## Overview

The Playwright code generation agent (Agent 3) now includes full support for the Helix-QA automation framework. Generated code is intelligently merged with existing files using append-only operations, automatic deduplication, and conflict resolution. **No files are ever overwritten.**

## Key Features

### ✓ Append-Only File Operations
- Generated files are **never overwritten**
- New content is always appended to existing files
- Infrastructure files (LocatorHealer, etc.) are never touched if they exist
- Preserves all hand-edited code and comments

### ✓ Automatic Deduplication
- **Locators**: Duplicate keys are skipped
- **Methods**: Duplicate method names are skipped
- **Steps**: Duplicate step patterns are skipped  
- **Scenarios**: Duplicate scenario titles are skipped

### ✓ Conflict Resolution
- When locator name conflicts occur (same key, different selector):
  - New locator automatically gets renamed: `submitBtn_1`, `submitBtn_2`, etc.
  - Existing locator is never modified or removed
  - Conflict information returned in response

### ✓ Helix-QA File Structure
Automatically discovers and manages these paths:
```
helix-project-root/
├── src/
│   ├── locators/
│   │   └── {kebab}.locators.ts          ← Locators merged here
│   ├── pages/
│   │   └── {kebab}.page.ts              ← Page objects merged here
│   ├── test/
│   │   ├── steps/
│   │   │   └── {kebab}.steps.ts         ← Step definitions merged here
│   │   └── features/
│   │       └── {kebab}.feature          ← Feature files merged here
│   └── utils/
│       └── locators/
│           └── *.ts                     ← Utility locators merged here
└── config/
    └── cucumber.js                      ← Profiles appended
```

## Usage

### Basic Generation (Without Helix-QA)

```json
{
  "gherkin_content": "Feature: User Login\n  Scenario: ...",
  "page_class_name": "HomePage",
  "app_name": "myapp",
  "healing_strategy": "role-label-text-ai",
  "auth_hook": "microsoft-sso",
  "enable_visual_regression": true,
  "enable_timing_healing": true
}
```

Response:
```json
{
  "files": {
    "src/locators/home-page.locators.ts": "...",
    "src/pages/home-page.page.ts": "...",
    "src/test/steps/home-page.steps.ts": "...",
    "src/test/features/home-page.feature": "...",
    "config/cucumber.js (add this profile)": "..."
  },
  "file_count": 5,
  "note": "..."
}
```

### Helix-QA Integration (With Auto-Merge)

```json
{
  "gherkin_content": "Feature: User Login\n  Scenario: ...",
  "page_class_name": "HomePage",
  "app_name": "myapp",
  "healing_strategy": "role-label-text-ai",
  "auth_hook": "microsoft-sso",
  "enable_visual_regression": true,
  "enable_timing_healing": true,
  "helix_project_root": "/path/to/helix-qa"
}
```

Response:
```json
{
  "files": {
    "src/locators/home-page.locators.ts": "...",  ← MERGED content
    "src/pages/home-page.page.ts": "...",          ← MERGED content
    "src/test/steps/home-page.steps.ts": "...",    ← MERGED content
    "src/test/features/home-page.feature": "...",  ← MERGED content
    "config/cucumber.js (add this profile)": "..."
  },
  "file_count": 5,
  "note": "✓ Helix-QA Integration: Files prepared for /path/to/helix-qa\n  • Locators merged (no duplicates, conflicts renamed)\n  • Page objects merged (new methods appended)\n  • Step definitions merged (new steps appended)\n  • Feature file merged (new scenarios appended)\n  Ready to write to disk using write-helix-files or agent 4."
}
```

## Merge Behavior Details

### Locators (locators.ts)

**Scenario 1: New locator (no conflict)**
```typescript
// EXISTING
export const HomePageLocators = {
  pageContainer: { selector: "[data-testid='home-container']", ... },
  submitBtn: { selector: "[data-testid='submit']", ... },
};

// NEW GENERATED
submitBtn: { selector: "[data-testid='submit']", ... },  // ← SKIPPED (duplicate)
saveBtn: { selector: "[data-testid='save']", ... },      // ← APPENDED

// RESULT
export const HomePageLocators = {
  pageContainer: { selector: "[data-testid='home-container']", ... },
  submitBtn: { selector: "[data-testid='submit']", ... },
  saveBtn: { selector: "[data-testid='save']", ... },    // ← NEW ENTRY
};
```

**Scenario 2: Locator conflict (same key, different selector)**
```typescript
// EXISTING
submitBtn: { selector: "[data-testid='submit']", ... },

// NEW GENERATED (conflict)
submitBtn: { selector: "[role='button'][aria-label='Submit']", ... },

// RESULT
submitBtn: { selector: "[data-testid='submit']", ... },           // ← UNCHANGED
submitBtn_1: { selector: "[role='button'][aria-label='Submit']", ... }, // ← RENAMED
```

### Page Objects (page.ts)

**Behavior**: Only new methods are appended. Existing methods are never modified.

```typescript
// EXISTING
async navigate(): Promise<void> { ... }
async fillForm(): Promise<void> { ... }

// NEW GENERATED
async navigate(): Promise<void> { ... }        // ← SKIPPED (duplicate)
async verifySuccess(): Promise<void> { ... }   // ← APPENDED
async closeModal(): Promise<void> { ... }      // ← APPENDED

// RESULT
async navigate(): Promise<void> { ... }
async fillForm(): Promise<void> { ... }
async verifySuccess(): Promise<void> { ... }   // ← NEW METHOD
async closeModal(): Promise<void> { ... }      // ← NEW METHOD
```

### Step Definitions (steps.ts)

**Behavior**: Only new step patterns are appended. Duplicate patterns are skipped.

```typescript
// EXISTING
Given(/^the user navigates to the home page$/, ...);
When(/^the user clicks submit$/, ...);

// NEW GENERATED
Given(/^the user navigates to the home page$/, ...);  // ← SKIPPED
When(/^the user clicks save$/, ...);                   // ← APPENDED
Then(/^success toast appears$/, ...);                  // ← APPENDED

// RESULT includes all three step definitions
```

### Feature Files (feature)

**Behavior**: Only new scenarios are appended. Duplicate scenario titles are skipped.

```gherkin
# EXISTING
Feature: User Management
  Scenario: Create user
    Given the user navigates to users page
    When the user creates a new user
    Then the user is added to the list

# NEW GENERATED
Feature: User Management
  Scenario: Create user
    # ... (SKIPPED - duplicate title)
  Scenario: Edit user
    # ... (APPENDED)
  Scenario: Delete user
    # ... (APPENDED)

# RESULT
Feature: User Management
  Scenario: Create user
    ...
  Scenario: Edit user
    ...
  Scenario: Delete user
    ...
```

## Integration with Agent 4 (Helix Writer)

After calling `generate_playwright_code` with `helix_project_root`:

1. The generated `files` dict contains **merged content**
2. Pass this directly to Agent 4's `write_helix_files` tool
3. Agent 4 writes the merged files to disk
4. No additional deduplication needed — it's already done

```python
# Agent 3 generates with Helix-QA integration
result = generate_playwright_code(
    gherkin_content=...,
    page_class_name="HomePage",
    helix_project_root="/path/to/helix-qa"
)

# Pass result["files"] directly to Agent 4
write_helix_files(
    helix_root="/path/to/helix-qa",
    files=result["files"]  # Already merged
)
```

## Conflict Resolution Workflow

### When Locator Name Conflicts Occur

1. **Detection**: Agent detects existing locator key with different selector
2. **Naming**: New locator renamed to `{key}_1`, `{key}_2`, etc.
3. **Reporting**: Response includes conflict information
4. **Review**: User reviews merged content before writing
5. **Optional Rename**: User can manually rename if needed before writing to disk

Example response:
```json
{
  "note": "✓ Helix-QA Integration: Files prepared...\n  ⚠ Conflict: submitBtn selector mismatch\n    • Existing: [data-testid='submit']\n    • New (renamed to submitBtn_1): [role='button']\n  Review and rename if needed before writing."
}
```

## Best Practices

### 1. Version Control First
```bash
git add src/
git commit -m "checkpoint before Playwright generation"
```

### 2. Review Merged Content
Inspect the `files` dict in the response before writing:
- Check for conflicts in the merge notes
- Verify new methods/steps/scenarios are sensible
- Look for any unexpected behavior

### 3. Write to Disk
Use Agent 4 (helix-writer) to commit the merged files:
```python
write_helix_files(
    helix_root="/path/to/helix-qa",
    files=result["files"]
)
```

### 4. Run Tests
```bash
cd /path/to/helix-qa
npm test
```

### 5. Resolve Conflicts Later (if needed)
If you renamed a locator conflict and want to consolidate later:
1. Review both selector strategies
2. Remove duplicate if one is clearly wrong
3. Keep or merge selector chains if both are valid healing strategies

## Technical Details

### Merge Algorithms

**Locators**: 
- Keyed by locator name
- Parse existing to extract keys
- Compare new keys against existing
- On conflict, generate unique name

**Methods/Steps**:
- Parsed by regex pattern matching
- Compare signatures or patterns
- Skip duplicates, append new

**Scenarios**:
- Parsed by "Scenario:" header
- Extract scenario titles
- Skip duplicates by title, append new scenarios

**Utility Locators**:
- Parsed as `export const` statements
- Compare key names
- Skip existing, append new

### File Structure Recognition

The agent looks for these exact paths in the Helix-QA project:
1. `src/locators/{kebab}.locators.ts`
2. `src/pages/{kebab}.page.ts`
3. `src/test/steps/{kebab}.steps.ts`
4. `src/test/features/{kebab}.feature`

If any file exists, merge logic is applied. If missing, fresh content is created.

## Error Handling

### File Read Errors
- Returns empty content (treated as new file)
- Merge proceeds normally
- App-level error handling catches any issues

### Parse Errors
- Invalid TypeScript/Gherkin is logged
- Safe fallback: treat as new content
- Merge proceeds conservatively

### Path Issues
- Validates helix_project_root exists
- Creates directories during write (Agent 4)
- Never modifies parent directories

## Limitations

1. **No Deep Merge**: Import statements and module setup are not merged deeply
   - Only method bodies and locator entries are merged
   - Keep utilities and imports in stable files separately

2. **No Intelligent Refactoring**: Doesn't rename variables or consolidate code
   - Only detects exact duplicates
   - User must manually review for semantic duplication

3. **Regex-Based Parsing**: Uses regex for TypeScript/Gherkin parsing
   - Handles standard patterns reliably
   - Edge cases (nested objects, complex formatting) may need manual review

## FAQ

**Q: What if I have a locator that should be replaced?**  
A: The merge prevents overwrites by design. Delete the old locator manually, then regenerate.

**Q: Can I merge across multiple features?**  
A: Yes—each page class generates its own `{kebab}` files. Multiple page classes integrate independently.

**Q: What about the feature file content—does it preserve step formatting?**  
A: Yes—the entire Gherkin syntax is preserved, including comments and formatting.

**Q: Can I merge without providing `helix_project_root`?**  
A: Yes—you get fresh files without merge logic. Useful for new pages or standalone generation.

**Q: What if a method signature changes?**  
A: Only exact duplicates are skipped. Changed signatures are appended as new methods. Manual cleanup may be needed.

## Summary

The Helix-QA integration ensures that generated code:
- ✓ Never overwrites existing hand-edited files
- ✓ Automatically deduplicates on merge
- ✓ Resolves naming conflicts intelligently
- ✓ Integrates seamlessly with Agent 4 (helix-writer)
- ✓ Preserves all existing code and structure

Use this workflow to generate Playwright code confidently, knowing your existing automation framework remains intact and safe.
