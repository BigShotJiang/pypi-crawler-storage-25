#!/usr/bin/env bash
# install-skills.sh — Install QA STLC Agent skills into a coding agent
#
# Usage:
#   ./scripts/install-skills.sh               # Claude Code (.claude/skills/)
#   ./scripts/install-skills.sh vscode        # VS Code (.github/copilot-instructions/)
#   ./scripts/install-skills.sh print         # Print skill paths only
#
# Equivalent to: npx skills add https://github.com/qa-gentic/qa-stlc-agents
#
# After installing skills, start Playwright MCP before running any generation workflow:
#   npx @playwright/mcp@latest --port 8931

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SKILLS_DIR="$ROOT_DIR/skills"

TARGET="${1:-claude}"

case "$TARGET" in
  vscode)
    DEST="$PWD/.github/copilot-instructions"
    mkdir -p "$DEST"
    cp "$SKILLS_DIR"/*.md "$DEST/"
    cp "$ROOT_DIR/AGENT-BEHAVIOR.md" "$DEST/"
    echo "✓ Skills + AGENT-BEHAVIOR.md installed to $DEST"
    echo "  NOTE: The committed .github/copilot-instructions/ files must always match"
    echo "  the skills/ originals. Run this command whenever skills/ or AGENT-BEHAVIOR.md changes."
    echo "  Add to .github/copilot-instructions.md: @.github/copilot-instructions/AGENT-BEHAVIOR.md"
    echo ""
    echo "  Start Playwright MCP before running generation workflows:"
    echo "    npx @playwright/mcp@latest --port 8931"
    ;;
  print)
    echo "Available skills:"
    ls "$SKILLS_DIR"/*.md
    ;;
  *)
    # Default: Claude Code
    DEST="$PWD/.claude/skills"
    mkdir -p "$DEST"
    cp "$SKILLS_DIR/generate-test-cases.md"      "$DEST/"
    cp "$SKILLS_DIR/generate-gherkin.md"          "$DEST/"
    cp "$SKILLS_DIR/generate-playwright-code.md"  "$DEST/"
    cp "$SKILLS_DIR/write-helix-files.md"         "$DEST/"
    cp "$SKILLS_DIR/deduplication-protocol.md"    "$DEST/"
    cp "$ROOT_DIR/AGENT-BEHAVIOR.md"              "$PWD/.claude/"
    echo "✓ 5 skills + AGENT-BEHAVIOR.md installed to .claude/"
    echo ""
    echo "Skills available to Claude Code:"
    echo "  • AGENT-BEHAVIOR.md           → zero-inference contract (read first)"
    echo "  • generate-test-cases.md      → ADO work item → test cases"
    echo "  • generate-gherkin.md         → Feature → BDD .feature file"
    echo "  • generate-playwright-code.md → Gherkin → self-healing Playwright TypeScript"
    echo "  • write-helix-files.md        → Generated files → Helix-QA project on disk"
    echo "  • deduplication-protocol.md  → mandatory pre-flight deduplication gate"
    echo ""
    echo "Start Playwright MCP before running generation workflows:"
    echo "  npx @playwright/mcp@latest --port 8931"
    echo "  # headless: npx @playwright/mcp@latest --headless --port 8931"
    ;;
esac
