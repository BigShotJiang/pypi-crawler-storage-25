#!/usr/bin/env python3
"""
generate-mcp-config.py — Write MCP server config for Claude Code or VS Code.

Usage:
    python3 scripts/generate-mcp-config.py              # Claude Code  → .mcp.json
    python3 scripts/generate-mcp-config.py --vscode     # VS Code      → .vscode/mcp.json
    python3 scripts/generate-mcp-config.py --print      # Print both, write nothing

The generated config uses absolute paths to this project's .venv binaries so
the MCP servers start without needing the project on PATH.

Playwright MCP is registered as a URL-type server pointing to a locally running
playwright-mcp process. Start it first:
    npx @playwright/mcp@latest               # default port 8931
    npx @playwright/mcp@latest --port 8931   # explicit port

Windows note: binaries live in .venv\\Scripts\\ not .venv/bin/
"""

import json
import pathlib
import platform
import sys

# ── Paths ─────────────────────────────────────────────────────────────────────
ROOT = pathlib.Path(__file__).parent.parent.resolve()

# Windows uses Scripts/, Unix uses bin/
BIN_DIR = ROOT / ".venv" / ("Scripts" if platform.system() == "Windows" else "bin")

# Binary extension on Windows
EXT = ".exe" if platform.system() == "Windows" else ""

# The three QA STLC stdio agents (Python, pip-installed into .venv)
_STDIO_AGENTS = {
    "qa-test-case-manager":    BIN_DIR / f"qa-test-case-manager{EXT}",
    "qa-gherkin-generator":    BIN_DIR / f"qa-gherkin-generator{EXT}",
    "qa-playwright-generator": BIN_DIR / f"qa-playwright-generator{EXT}",
}

# Playwright MCP — launched separately via npx, communicates over WebSocket.
# Change this port if you start playwright-mcp on a different port.
PLAYWRIGHT_MCP_PORT = 8931
PLAYWRIGHT_MCP_URL  = f"ws://localhost:{PLAYWRIGHT_MCP_PORT}"


# ── Validate binaries exist ───────────────────────────────────────────────────
def check_binaries():
    missing = [name for name, path in _STDIO_AGENTS.items() if not path.exists()]
    if missing:
        print("⚠  Some binaries not found — run `make install` first:")
        for name in missing:
            print(f"   {_STDIO_AGENTS[name]}")
        print()


# ── Config builders ───────────────────────────────────────────────────────────
def claude_config() -> dict:
    """
    Claude Code format (.mcp.json).
    https://docs.claude.ai/en/docs/claude-code/mcp

    Playwright MCP is registered as a URL server — Claude Code connects to an
    already-running playwright-mcp WebSocket process.
    """
    servers = {
        name: {"command": str(path)}
        for name, path in _STDIO_AGENTS.items()
    }
    # Playwright MCP: URL/WebSocket transport
    servers["playwright"] = {
        "type": "url",
        "url": PLAYWRIGHT_MCP_URL,
    }
    return {"mcpServers": servers}


def vscode_config() -> dict:
    """
    VS Code MCP format (.vscode/mcp.json).
    https://code.visualstudio.com/docs/copilot/chat/mcp-servers

    Uses 'type: stdio' for the QA STLC agents and 'type: url' for Playwright MCP.
    """
    servers = {}
    for name, path in _STDIO_AGENTS.items():
        servers[name] = {
            "type": "stdio",
            "command": str(path),
            "args": [],
            "env": {
                # Pass through auth env vars if set — useful for CI/CD
                "AZURE_TENANT_ID":     "${env:AZURE_TENANT_ID}",
                "AZURE_CLIENT_ID":     "${env:AZURE_CLIENT_ID}",
                "AZURE_CLIENT_SECRET": "${env:AZURE_CLIENT_SECRET}",
            },
        }
    # Playwright MCP: URL/WebSocket transport
    servers["playwright"] = {
        "type": "url",
        "url": PLAYWRIGHT_MCP_URL,
    }
    return {"servers": servers}


def _playwright_hint():
    return (
        f"\n  Start Playwright MCP first:\n"
        f"    npx @playwright/mcp@latest --port {PLAYWRIGHT_MCP_PORT}\n"
        f"    # headless CI: npx @playwright/mcp@latest --headless --port {PLAYWRIGHT_MCP_PORT}\n"
    )


# ── Main ──────────────────────────────────────────────────────────────────────
mode = sys.argv[1] if len(sys.argv) > 1 else "--claude"

if mode not in ("--claude", "--vscode", "--print"):
    print(f"Unknown option: {mode}")
    print("Usage: python3 scripts/generate-mcp-config.py [--claude | --vscode | --print]")
    sys.exit(1)

check_binaries()

if mode == "--print":
    print("=== Claude Code  (.mcp.json) ===")
    print(json.dumps(claude_config(), indent=2))
    print("\n=== VS Code  (.vscode/mcp.json) ===")
    print(json.dumps(vscode_config(), indent=2))
    print(_playwright_hint())

elif mode == "--vscode":
    vscode_dir = ROOT / ".vscode"
    vscode_dir.mkdir(exist_ok=True)
    out = vscode_dir / "mcp.json"
    out.write_text(json.dumps(vscode_config(), indent=2) + "\n", encoding="utf-8")
    print(f"✓  Written to {out}")
    print()
    print("Next steps:")
    print(_playwright_hint())
    print("  1. Open VS Code in this workspace")
    print("  2. Install the 'MCP Servers' extension if not already installed")
    print("  3. Reload the window — all four MCP servers will appear in the MCP panel")
    print("  4. GitHub Copilot Chat will pick them up automatically on next conversation")

else:  # --claude (default)
    out = ROOT / ".mcp.json"
    out.write_text(json.dumps(claude_config(), indent=2) + "\n", encoding="utf-8")
    print(f"✓  Written to {out}")
    print()
    print("Next steps:")
    print(_playwright_hint())
    print("  1. Open this project in Claude Code")
    print("  2. Run: /mcp  (to verify all four servers are loaded)")
    print("  3. Ask: 'Generate test cases for work item #<id> in <project>'")