# QA STLC Agents — End-to-End Walkthrough

This walkthrough takes a real Azure DevOps work item from raw acceptance criteria all
the way to running, self-healing Playwright tests. Each step shows the exact tool call,
what the agent does internally, and what ends up in ADO.

The scenario used throughout: **User Profile Photo Management** — a feature that lets
users upload, crop, and update their profile photo in a web application.

---

## Prerequisites

```bash
git clone https://github.com/qa-gentic/qa-stlc-agents
cd qa-stlc-agents

make install       # creates .venv, pip install -e .
make skills        # copies skill files to .claude/skills/
make mcp-config    # writes .mcp.json with correct binary paths
make verify        # confirms MSAL auth (may open browser once)

# Start Playwright MCP (required for Step 3.0 locator verification)
npx @playwright/mcp@latest --port 8931
```

Open your MCP client (Claude Code, VS Code with Copilot, etc.) and restart it to
load all four MCP servers (`qa-test-case-manager`, `qa-gherkin-generator`,
`qa-playwright-generator`, `playwright`).

---

## Phase 1 — Test Case Generation (Agent 1)

### The prompt

> "Generate test cases for work item #12345 in MyProject at
>  https://dev.azure.com/myorg"

The agent reads `skills/generate-test-cases.md`, then calls:

### Step 1.1 — Fetch the work item

```
fetch_work_item(
  work_item_id=12345,
  organization_url="https://dev.azure.com/myorg",
  project_name="MyProject"
)
```

**What happens internally:**

Agent 1 calls `GET /wit/workitems/12345?$expand=relations&api-version=7.1`. The
`_strip_html()` function converts ADO rich text fields to plain text. The
`_extract_coverage_hints()` function scans the acceptance criteria for keywords and
returns a set of coverage categories that need test cases.

**Response (abbreviated):**

```json
{
  "work_item": {
    "id": 12345,
    "type": "Product Backlog Item",
    "title": "User Profile Photo Management",
    "acceptance_criteria": "User can upload JPG/PNG up to 5 MB. An image crop editor is shown. Save button updates the header. Cancel discards changes. Success toast is displayed. If file exceeds 5 MB, an error toast is shown.",
    "area_path": "MyProject\\Team Alpha",
    "iteration_path": "MyProject\\Sprint 12",
    "story_points": 5
  },
  "parent_feature": {
    "id": 11000,
    "title": "User Profile Management"
  },
  "existing_test_cases_count": 0,
  "coverage_hints": [
    "file_size_boundary", "image_manipulation", "toast_notifications",
    "cancel_flows", "post_action_state", "file_formats"
  ]
}
```

The agent reads `story_points=5` → Medium complexity (6–12 TCs). Six coverage hints
are flagged. The agent designs one test case per major journey, applying the
granularity merge rule: steps that form a single user journey are merged into one TC
rather than split into micro-interactions.

### Step 1.2 — Create and link test cases

```
create_and_link_test_cases(
  work_item_id=12345,
  organization_url="https://dev.azure.com/myorg",
  project_name="MyProject",
  test_cases=[
    {
      "title": "TC_12345_01 — User uploads valid profile photo and sees success confirmation",
      "priority": 2,
      "steps": [
        {"action": "Navigate to My Profile", "expected_result": "Profile section opens"},
        {"action": "Click Update Photo and select a valid JPG under 5 MB", "expected_result": "Image crop editor opens with preview"},
        {"action": "Adjust crop and click Save", "expected_result": "Success toast displayed, photo updated in header"}
      ]
    },
    {
      "title": "TC_12345_02 — Upload at exact 5 MB boundary is accepted",
      "priority": 2,
      "steps": [
        {"action": "Select a file of exactly 5,242,880 bytes", "expected_result": "File is accepted, crop editor opens"},
        {"action": "Save the crop", "expected_result": "Photo saved successfully"}
      ]
    },
    {
      "title": "TC_12345_03 — File exceeding 5 MB is rejected with error toast",
      "priority": 1,
      "steps": [
        {"action": "Select a file of 5,242,881 bytes (1 byte over limit)", "expected_result": "Error toast 'File too large' displayed"},
        {"action": "Verify current photo unchanged", "expected_result": "Original photo or initials avatar still shown"}
      ]
    }
    // ... 5 more test cases covering cancel flows, file formats, initials fallback, persistence
  ]
)
```

**What happens internally:**

For each test case, `_build_steps_xml()` generates the `Microsoft.VSTS.TCM.Steps`
XML format required by ADO. Agent 1 calls `POST /wit/workitems/$Test Case` for each
TC, then calls `PATCH /wit/workitems/12345` to add a `TestedBy-Forward` relation
linking each new TC to PBI 12345. Area path and iteration path are automatically
inherited — the caller does not need to specify them.

**Result in ADO:** 8 test cases created and linked to PBI 12345. Each TC is visible
under the Tests tab of the work item.

---

## Phase 2 — Gherkin BDD Generation (Agent 2)

### The prompt

> "Generate a Gherkin regression suite for Feature #11000 in MyProject at
>  https://dev.azure.com/myorg"

The agent reads `skills/generate-gherkin.md`, then calls:

### Step 2.1 — Fetch the feature hierarchy

```
fetch_feature_hierarchy(
  feature_id=11000,
  organization_url="https://dev.azure.com/myorg",
  project_name="MyProject"
)
```

**What happens internally:**

Agent 2 fetches Feature 11000, then walks all child relations to fetch each child PBI
and Bug. For each child it fetches the linked test cases and their full XML steps.
The response includes an embedded `_GHERKIN_EXAMPLE` showing correct style.

**Response (abbreviated):**

```json
{
  "feature": {
    "id": 11000,
    "title": "User Profile Management",
    "acceptance_criteria": "..."
  },
  "child_work_items": [
    {
      "id": 12345,
      "title": "User Profile Photo Management",
      "acceptance_criteria": "...",
      "linked_test_cases": [
        { "title": "TC_12345_01 — User uploads valid profile photo...", "steps": [...] }
        // ... 7 more TCs
      ]
    }
  ],
  "best_practice_example": "// ... reference .feature file showing correct tag usage, Background, Scenario Outline style"
}
```

The coding agent reads all 8 test cases, identifies the feature-level journeys, and
writes 7 scenarios following the skill's rules: one `@smoke` happy path, the rest
`@regression`, one `Scenario Outline` for the file size boundary data, a `Background`
for the shared login precondition.

### Step 2.2 — Attach the feature file

```
attach_gherkin_to_feature(
  feature_id=11000,
  feature_title="User Profile Management",
  organization_url="https://dev.azure.com/myorg",
  project_name="MyProject",
  gherkin_content="""
@user_profile @regression
Feature: User Profile Photo Management
  As an authenticated user
  I want to manage my profile photo
  So that my identity is represented correctly across the platform

  Background:
    Given user logs in with Microsoft SSO as "standard_user"

  @smoke
  Scenario: User uploads a valid photo and sees confirmation
    Given the user navigates to the Profile Photo section
    When the user selects a valid JPG file under 5 MB
    And the user adjusts the crop and clicks Save
    Then a success toast notification should be displayed
    And the profile photo is updated in the application header

  @regression
  Scenario Outline: File size boundary validation
    Given the user navigates to the Profile Photo section
    When the user attempts to upload a file of <size> bytes
    Then <outcome>
    Examples:
      | size      | outcome                            |
      | 5242880   | the file is accepted               |
      | 5242881   | an error toast should be displayed |

  @regression
  Scenario: Cancel discards changes without saving
    Given the user has opened the image crop editor
    When the user clicks the Cancel button
    Then the original photo or initials avatar is still displayed

  // ... 4 more scenarios
"""
)
```

**Result in ADO:** File `11000_user-profile-management_regression.feature` is
uploaded and attached to Feature 11000. The `.feature` file is visible under the
Attachments tab.

---

## Phase 3 — Playwright Code Generation (Agent 3)

### Step 3.0 (recommended) — Build a verified locator map using Playwright MCP

Playwright MCP must already be running:
```bash
npx @playwright/mcp@latest --port 8931
```

The coding agent drives the browser through Playwright MCP tools — no Chrome DevTools
port to open, no WebSocket wrangling, no extra dependencies.

**Phase 3.0a — Login**

```
playwright:browser_navigate  url="https://your-app.dev.com/login"
playwright:browser_snapshot
```

The snapshot returns the login screen accessibility tree. The agent identifies the
email input, password input, and submit button by their role and name, then
authenticates:

```
playwright:browser_fill  ref="<email-input-ref>"    value="user@example.com"
playwright:browser_fill  ref="<password-input-ref>" value="<password>"
playwright:browser_click ref="<login-button-ref>"
playwright:browser_wait_for_url  url="**/dashboard**"  timeout=10000
```

Login element refs (`loginEmail`, `loginPassword`, `loginSubmit`) are stored in the
context map with their derived selectors and stability scores.

**Phase 3.0b — Navigate to the Profile page and snapshot**

```
playwright:browser_navigate  url="https://your-app.dev.com/profile"
playwright:browser_snapshot
```

The agent parses the accessibility tree for nodes matching the element hints derived
from the Gherkin `When`/`Then` steps:

| Gherkin step | Matched AX node |
|---|---|
| `When the user selects a valid JPG file under 5 MB` | `input[type=file]` — role: `generic`, ref: `s1e7` |
| `When the user adjusts the crop and clicks Save` | Save button — role: `button`, name: `Save` |
| `Then a success toast notification should be displayed` | Alert — role: `alert`, name: `Profile photo updated` |

From each matched node the agent applies the stability ranking:

```json
{
  "saveButton": {
    "selector": "[data-testid='profile-save-btn']",
    "intent":   "save changes button",
    "stability": 100,
    "visualIntent": true
  },
  "fileInput": {
    "selector": "input[type='file']",
    "intent":   "file upload input",
    "stability": 70
  },
  "successToast": {
    "selector": "[role='alert']",
    "intent":   "success notification toast",
    "stability": 60,
    "visualIntent": true
  }
}
```

Every selector was derived from a real accessibility tree node — no hallucinated
`data-testid` values that don't exist in the DOM.

**Phase 3.0c — Trigger the image crop editor (transient screen)**

The crop editor only appears after selecting a file. The agent drives to it:

```
playwright:browser_snapshot                       ← find the file input ref
playwright:browser_click  ref="<fileInput-ref>"
playwright:browser_wait_for_timeout  timeout=1500
playwright:browser_snapshot                       ← capture crop editor elements
```

From this second snapshot, locators for `cropHandle`, `zoomSlider`, `cancelBtn` are
added to the context map.

**Merged context_map (passed to generate_playwright_code):**

```json
{
  "loginEmail":    { "selector": "#email",                            "intent": "Email input",          "stability": 80 },
  "loginPassword": { "selector": "#password",                         "intent": "Password input",       "stability": 80 },
  "loginSubmit":   { "selector": "#btn-login",                        "intent": "Log In button",        "stability": 80 },
  "saveButton":    { "selector": "[data-testid='profile-save-btn']",  "intent": "save changes button",  "stability": 100 },
  "fileInput":     { "selector": "input[type='file']",                "intent": "file upload input",    "stability": 70  },
  "successToast":  { "selector": "[role='alert']",                    "intent": "success toast",        "stability": 60  },
  "cancelBtn":     { "selector": "[data-testid='profile-cancel']",    "intent": "cancel button",        "stability": 100 },
  "cropHandle":    { "selector": "[data-testid='crop-handle']",       "intent": "image crop handle",    "stability": 100 }
}
```

### Step 3.1 — Scaffold the infrastructure (once per project)

```
scaffold_locator_repository(
  output_dir="src/utils/locators",
  enable_ai_vision=true,
  repository_path="test-results/locator-repository.json",
  dashboard_port=7890,
  enable_timing_healing=true,
  enable_visual_regression=true,
  enable_devtools_healer=true
)
```

Generates six files: `LocatorHealer.ts`, `LocatorRepository.ts`, `TimingHealer.ts`,
`VisualIntentChecker.ts`, `DevToolsHealer.ts`, `HealingDashboard.ts`.

Note: `DevToolsHealer.ts` uses `page.context().newCDPSession(page)` at **test
runtime** — this is Playwright's built-in CDPSession, entirely separate from the
Playwright MCP server used in Step 3.0.

### Step 3.2 — Generate the page object and step definitions

```
generate_playwright_code(
  gherkin_content="<the .feature file from Phase 2>",
  page_class_name="UserProfilePhotoManagement",
  app_name="amplify",
  healing_strategy="role-label-text-ai",
  auth_hook="microsoft-sso",
  enable_visual_regression=true,
  enable_timing_healing=true,
  context_map=<result from Step 3.0>
)
```

**Generated `locators.ts` (excerpt):**

```typescript
/**
 * Locators: UserProfilePhotoManagementPage
 * Selectors derived from Playwright MCP accessibility tree snapshot.
 * Stability rank: data-testid (100) > aria-role+name (90) > id (80) > aria-label (70) > placeholder (60)
 */
export const UserProfilePhotoManagementLocators = {
  // stability=100 strategy=data-testid
  saveButton:   { selector: "[data-testid='profile-save-btn']", intent: 'save changes button',    visualIntent: true  },
  cancelBtn:    { selector: "[data-testid='profile-cancel']",   intent: 'cancel button'                               },
  cropHandle:   { selector: "[data-testid='crop-handle']",      intent: 'image crop handle'                           },

  // stability=70 strategy=input-type
  fileInput:    { selector: "input[type='file']",               intent: 'file upload input'                           },

  // stability=60 strategy=aria-role
  successToast: { selector: "[role='alert']",                   intent: 'success notification toast', visualIntent: true },
} as const;
```

### Step 3.3 — Validate step coverage

```
validate_gherkin_steps(gherkin_content="<the .feature file>")
```

Returns `{ total_unique_steps: 18, by_keyword: { Given: [...], When: [...], Then: [...] } }`.
The agent cross-checks that each step string has an implementation in `steps.ts`.

### Step 3.4 — Attach the generated files to ADO

```
attach_code_to_work_item(
  organization_url="https://dev.azure.com/myorg",
  project_name="MyProject",
  work_item_id=12345,
  files=[
    { "file_name": "locators.ts",                             "content": "..." },
    { "file_name": "UserProfilePhotoManagement.page.ts",      "content": "..." },
    { "file_name": "user-profile-photo-management.steps.ts",  "content": "..." }
  ]
)
```

**Result in ADO:** The three `.ts` files are attached to PBI 12345. Requirement,
test cases, Gherkin feature, and automation code are all linked in one ADO work item
thread.

---

## Phase 4 — Running the Tests

```bash
ENABLE_SELF_HEALING=true \
HEALING_DASHBOARD_PORT=7890 \
ENV=dev1 BROWSER=chrome APP=amplify \
cucumber-js --config=config/cucumber.js -p user_profile_photo_management
```

### First run

- `locator-repository.json` does not exist yet
- Every locator goes through the full resolution chain
- Bounding boxes are captured after each successful click
- Visual baselines are created (no diff, tests pass)
- TimingHealer records actual network durations as observed data

### Subsequent runs

- Strategy 1 (cached healed selector) fires for any element that was healed on a
  previous run — the rest of the chain is skipped entirely
- TimingHealer uses adjusted timeouts derived from the observed durations
- VisualIntentChecker diffs element screenshots against the saved baselines

### When a selector breaks (e.g. after a UI refactor)

Say the developer renamed `data-testid='profile-save-btn'` to `data-testid='save-profile-button'`.

Strategy 1 tries the cached selector — fails. Strategy 2 (primary) fails. Strategy 3
tries `page.getByRole('button', { name: /save/i })` — succeeds. `LocatorHealer`
updates `healedSelector` to `[role-healed:button]` and calls
`DevToolsHealer.captureBoundingBox` to refresh the bbox.

Simultaneously, `repo.queueSuggestion("saveButton", "[role-healed:button]", "role")` is
called. At `http://localhost:7890` the engineer sees:

```
Key: saveButton   |  Current: [data-testid='profile-save-btn']
Suggested: [role-healed:button]   |  Strategy: role   |  Time: 2026-03-22 14:31

[ Approve ]  [ Reject ]
```

The engineer knows the real fix is `[data-testid='save-profile-button']`. They click
Reject, update `locators.ts` directly, and the next run uses the correct `data-testid`
permanently. The suggestion was a useful signal; it did not auto-corrupt the test.

### When an API slows down

An upstream service change causes the photo upload endpoint to take 1200ms instead
of the baseline 430ms.

`TimingHealer` observes a 179% drift. It automatically adjusts the `submitForm`
timeout to 1800ms (1200 × 1.5 headroom) for this run — the test does not time out.
At `http://localhost:7890`:

```
Key: timing:submitForm   |  Current: timeout:430ms
Suggested: timeout:1800   |  Strategy: timing-drift   |  Time: 2026-03-22 14:35

[ Approve ]  [ Reject ]
```

The engineer approves. The new baseline is committed. Future runs use 1800ms until
the API recovers or a new measurement is taken.

### When a visual element changes

A design update changes the success toast from green to teal. `LocatorHealer` finds
the element and it passes the assertVisible check. `VisualIntentChecker.check()` runs
and the pixel diff is 3.2% — above the 0.5% threshold.

At `http://localhost:7890`:

```
Key: visual:successToast   |  Intent: success notification toast
Strategy: visual-regression   |  [ View diff ]   |  Time: 2026-03-22 14:38

[ Approve ]  [ Reject ]
```

The engineer clicks "View diff" and sees the before/after screenshots side by side.
The teal colour is intentional. They click Approve — the new baseline is saved and
future runs compare against the teal version.

---

## Summary

One prompt from the engineer triggers the entire pipeline:

> "Generate test cases, Gherkin, and Playwright automation for work item #12345 in
>  MyProject at https://dev.azure.com/myorg, using the live app at
>  http://localhost:4200"

The coding agent reads all three skill files, navigates and snapshots the live app
using Playwright MCP, fetches the ADO work item, creates and links test cases, fetches
the feature hierarchy, generates the Gherkin file and attaches it, then generates all
six infrastructure files plus the page object, step defs, and locators — with every
selector derived from a real accessibility tree node before it is written to disk.

What the engineer reviews at the end:
- 8 structured test cases linked to PBI 12345 in ADO
- A `.feature` file attached to Feature 11000 in ADO
- Playwright TypeScript code attached to PBI 12345 in ADO
- A running test suite with self-healing on all four layers
- `http://localhost:7890` for reviewing any AI-suggested changes before they commit

Nothing is committed to the repository without human review. The healing system
produces output; engineers decide what stays.