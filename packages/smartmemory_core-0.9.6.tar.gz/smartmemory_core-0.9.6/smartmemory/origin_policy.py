"""Origin tier policy for CORE-ORIGIN-1.

Maps origin prefixes to visibility tiers and provides filtering functions
for recall and search. Tiers control default visibility:

- Tier 1: User-authored content (always visible)
- Tier 2: Graduated evolved content (visible in recall + search)
- Tier 3: Speculative derived content (visible in search only)
- Tier 4: System infrastructure (hidden by default)
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Prefix → tier mapping. Longer prefixes match first (most specific wins).
# Order within a tier doesn't matter — matching is prefix-based.
_TIER_PREFIXES: list[tuple[str, int]] = [
    # Tier 1: User content
    ("user:", 1),
    ("cli:", 1),
    ("api:", 1),
    ("import:", 1),
    ("code:index", 1),
    # CORE-USER-SEED-1: signup-time identity seeding
    ("signup:user_seed", 1),
    ("signup:user_seed_backfill", 1),
    ("signup:user_seed_domain", 1),
    # Tier 2: Graduated evolved
    ("evolver:episodic_to_semantic", 2),
    ("evolver:working_to_episodic", 2),
    ("evolver:working_to_procedural", 2),
    ("evolver:episodic_to_zettel", 2),
    ("code:derived", 2),
    ("mcp:memory_add", 2),
    # Tier 2: Pipeline-derived (CORE-EXPERTISE-1 Phase 3 T12) — reasoning traces
    # produced by the in-pipeline reasoning extractor are tied to user content
    # and are high-quality enough to be visible in recall + search.
    ("pipeline:reasoning_extract", 2),
    # Tier 3: Speculative derived
    ("evolver:opinion_", 3),
    ("evolver:observation_", 3),
    ("evolver:decision_", 3),
    # Tier 3: Reasoning validator (CORE-EXPERTISE-1 Phase 3 T13) — parallel to
    # evolver:opinion_ / evolver:observation_; visible in search but not recall.
    ("evolver:reasoning_", 3),
    ("enricher:", 3),
    ("conversation:", 3),
    # Tier 2: Lifecycle graduated (DIST-AGENT-HOOKS-1) + Reflector (CORE-GAPS-5)
    ("hook:persist", 2),
    ("lifecycle:distill", 2),
    ("observe:reflect", 2),
    # Tier 3: Lifecycle speculative (DIST-AGENT-HOOKS-1)
    ("hook:observe", 3),
    ("hook:learn", 3),
    # Tier 4: System infrastructure
    ("hook:", 4),
    ("structured:", 4),
    ("unknown", 4),
]

# Sort by prefix length descending so longest (most specific) matches first
_TIER_PREFIXES.sort(key=lambda x: -len(x[0]))

# Default tiers included for each mode
_DEFAULT_TIERS = {
    "recall": {1, 2},
    "search": {1, 2, 3},
}


def get_tier(origin: str) -> int:
    """Get the visibility tier for an origin string.

    Uses longest-prefix matching. Returns tier 4 if no prefix matches.
    """
    if not origin:
        return 4
    for prefix, tier in _TIER_PREFIXES:
        if origin.startswith(prefix):
            return tier
    return 4  # unknown origins default to hidden


def get_default_tiers(mode: str) -> set[int]:
    """Get default included tiers for a mode.

    Args:
        mode: "recall" (tiers 1+2) or "search" (tiers 1+2+3).

    Returns:
        Set of tier numbers to include.
    """
    return _DEFAULT_TIERS.get(mode, {1, 2, 3})


def filter_by_tiers(
    items: list[Any],
    tiers: set[int],
    show_all: bool = False,
) -> list[Any]:
    """Filter items by origin tier.

    Items with missing or "unknown" origin are always included (legacy data
    predating CORE-ORIGIN-1 has no origin tag and must remain visible).

    Args:
        items: List of objects with an `origin` attribute.
        tiers: Set of tier numbers to include.
        show_all: If True, bypass filtering and return all items.

    Returns:
        Filtered list.
    """
    if show_all:
        return items
    result = []
    for item in items:
        item_origin = getattr(item, "origin", None) or "unknown"
        if item_origin == "unknown":
            result.append(item)  # legacy untagged items always visible
        elif get_tier(item_origin) in tiers:
            result.append(item)
    return result


def filter_by_prefix(
    items: list[Any],
    origin_prefix: str,
) -> list[Any]:
    """Filter items to only those matching an origin prefix.

    Args:
        items: List of objects with an `origin` attribute.
        origin_prefix: Prefix to match (e.g. "user", "evolver:opinion_").

    Returns:
        Filtered list.
    """
    return [
        item for item in items
        if getattr(item, "origin", "").startswith(origin_prefix)
    ]
