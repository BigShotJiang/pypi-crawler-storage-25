"""ONTO-RECONCILE-1 — OntologyService.

The single mediation point for all ontology reads and writes. CI grep
enforces that no Cypher against ontology labels exists outside this
module. See `plan.md` Task 1 for the full contract.

This file currently implements the **Task 1 skeleton**: dataclass-shaped
constructor, full method surface, and `NotImplementedError` stubs.
Subsequent Phase 1 tasks (2, 2b, 2c, 2d, 2e, 2f, 3, 3b) replace each
stub with a real implementation, gated by integration tests against
real FalkorDB.
"""

from __future__ import annotations

import logging
from dataclasses import replace as _dataclass_replace
from typing import Any, Literal

from smartmemory.interfaces import ScopeProvider
from smartmemory.ontology.observations import Observation

logger = logging.getLogger(__name__)


def replace_observation_type_name(observation: Observation, new_name: str) -> Observation:
    """Return a copy of `observation` with `type_name` replaced.

    Pulled out as a helper so service.record_observation reads cleanly
    and so the immutability of the input observation is explicit.
    """
    return _dataclass_replace(observation, type_name=new_name)


def _normalize_type_identifier(identifier: str) -> str:
    """Apply the Task 1 type-name normalization rule.

    iri (`http://...` / `https://...`) and qid (`Q\\d+`) are external
    identifiers — never normalize. Plain names get `.title()` so callers
    can pass "doctor" or "Doctor" interchangeably.

    Centralized so every evidence-write entry point (record_observation,
    set_evidence_cohesion) uses ONE normalization rule. Without this,
    BatchObserver's cohesion write could land in a different identity
    slot than the evidence row written by record_observation, silently
    bypassing the cohesion gate.
    """
    if not identifier:
        return identifier
    if identifier.startswith("http://") or identifier.startswith("https://"):
        return identifier
    if identifier.startswith("Q") and identifier[1:].isdigit():
        return identifier
    return identifier.title()
from smartmemory.ontology.types import (
    ApplyResult,
    Layer,
    OntologyRelation,
    OntologyType,
    Tier,
)


class OntologyService:
    """Single mediation point for ontology reads and writes.

    The service binds a `ScopeProvider` at construction time; inline
    write paths (e.g. `record_observation`) resolve `workspace_id` from
    the provider rather than accepting it as a parameter. This mirrors
    the `SecureSmartMemory` pattern.

    Identifiers in read/write methods accept iri | qid | name and are
    resolved internally per the identity rule (iri → qid → composite).

    Type-name case normalization (`.title()`) is applied INTERNALLY at
    the service boundary in `record_observation` and `transition`.
    Callers pass raw type names. `iri` and `wikidata_qid` are never
    normalized — they're external identifiers.
    """

    def __init__(
        self,
        *,
        scope_provider: ScopeProvider,
        ontology_graph: Any | None,
        ontology_registry: Any | None,
        layer_resolver: Any | None = None,
        promotion_config: Any | None = None,
        promoter_blocklist: frozenset[str] | None = None,
    ):
        self.scope_provider = scope_provider
        self._graph = ontology_graph
        self._registry = ontology_registry
        # Default to a graph-backed LayerResolver when none is injected,
        # so `get_type(layer_resolution="effective")` and other resolver
        # callers work out of the box. Tests / advanced callers can pass
        # a custom resolver (e.g. for stubbed-pack scenarios).
        if layer_resolver is None and ontology_graph is not None:
            from smartmemory.ontology.layers import LayerResolver

            self._layers = LayerResolver(ontology_graph)
        else:
            self._layers = layer_resolver

        # Task 3b: build EvidenceStore + Promoter when a graph is bound.
        # Lazy-build avoids forcing test fixtures that pass `ontology_graph=None`
        # to also construct config/store. Pipelines that exercise the
        # observers always have a graph.
        self._evidence_store = None
        self._promoter = None
        if ontology_graph is not None:
            from smartmemory.ontology.evidence_store import EvidenceStore
            from smartmemory.ontology.promoter import Promoter

            ws = getattr(scope_provider, "workspace_id", None)
            if ws:
                self._evidence_store = EvidenceStore(ontology_graph, workspace_id=ws)
                if promotion_config is None:
                    from smartmemory.pipeline.config import PromotionConfig

                    promotion_config = PromotionConfig()
                self._promotion_config = promotion_config
                self._promoter = Promoter(
                    evidence_store=self._evidence_store,
                    config=promotion_config,
                    blocklist=promoter_blocklist,
                )

    # ------------------------------------------------------------------
    # DIST-LITE-ONTO-1: governance shielding
    # ------------------------------------------------------------------

    def _safe_governance(self, fn, *args, **kwargs):
        """Call a governance method, catching `UnsupportedBackendError` only.

        Use ONLY for `_write_audit_entry` calls. Evidence/cohesion shielding
        lives inside `EvidenceStore` (DIST-LITE-ONTO-1 design v2).
        Pack-registry calls (`_record_pack_installation`,
        `_remove_pack_installation`) must remain unshielded so
        `install_pack` / `uninstall_pack` fail loudly on lite backends.

        DO NOT wrap reads/writes outside the audit path — a too-broad catch
        would silently disable `ontology_constrain` reads and re-create the
        original ingest break (gaps.md CORE-29).
        """
        from smartmemory.backends.unsupported import UnsupportedBackendError
        try:
            return fn(*args, **kwargs)
        except UnsupportedBackendError as e:
            logger.debug("Audit log no-op on lite backend: %s", e)
            return None

    # ------------------------------------------------------------------
    # Read methods
    # ------------------------------------------------------------------

    def get_type(
        self,
        identifier: str,
        layer_resolution: Literal["effective", "private", "domain", "public"] = "effective",
        *,
        installed_packs: list[str] | None = None,
    ) -> OntologyType | None:
        """Resolve a type by iri/qid/name.

        `layer_resolution="effective"` walks `private → domain → public`
        via `LayerResolver`. Explicit single-layer values bypass the
        resolver and read that layer directly.

        `installed_packs` filters the domain layer (Task 2b). When
        `:PackInstallation` (Task 2e) lands, callers should source this
        from the workspace's installation set rather than passing it
        through; for now an explicit list is the supported path.
        """
        if layer_resolution == "effective":
            packs = self._installed_packs_for_workspace() if installed_packs is None else installed_packs
            return self._layers.resolve_effective(
                identifier,
                workspace_id=self.scope_provider.workspace_id,
                installed_packs=packs,
            )
        return self._graph._get_ontology_type(
            identifier,
            layer=layer_resolution,
            workspace_id=self.scope_provider.workspace_id,
        )

    def get_type_status(
        self,
        identifier: str,
        *,
        installed_packs: list[str] | None = None,
    ) -> Literal["working", "proposed", "confirmed", "retired"] | None:
        """Return the effective tier of a type, or None if not found.

        Resolution uses `LayerResolver` so the answer reflects the
        layer-precedence rule (`private → domain → public`) rather than
        whichever layer the type happens to exist in.
        """
        packs = self._installed_packs_for_workspace() if installed_packs is None else installed_packs
        got = self._layers.resolve_effective(
            identifier,
            workspace_id=self.scope_provider.workspace_id,
            installed_packs=packs,
        )
        return got.tier if got is not None else None

    def get_relation_type(
        self,
        identifier: str,
        layer_resolution: Literal["effective", "private", "domain", "public"] = "effective",
        *,
        installed_packs: list[str] | None = None,
    ) -> OntologyRelation | None:
        """Resolve a relation type by iri/pid/name. Mirror of `get_type`.

        `layer_resolution="effective"` walks `private → domain → public`
        via `LayerResolver.resolve_relation_effective`. Explicit single-
        layer values bypass the resolver and read that layer directly.
        """
        if layer_resolution == "effective":
            packs = self._installed_packs_for_workspace() if installed_packs is None else installed_packs
            return self._layers.resolve_relation_effective(
                identifier,
                workspace_id=self.scope_provider.workspace_id,
                installed_packs=packs,
            )
        return self._graph._get_ontology_relation(
            identifier,
            layer=layer_resolution,
            workspace_id=self.scope_provider.workspace_id,
        )

    def list_types(
        self,
        *,
        tier: Tier | None = None,
        layer: Layer | None = None,
        pack_id: str | None = None,
        has_iri: bool | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> list[OntologyType]:
        """List types with filters, scoped to the bound workspace.

        `cursor` is reserved for later pagination work; Task 2 returns the
        full filtered set up to `limit` (None = no limit).
        """
        return self._graph._list_ontology_types(
            tier=tier,
            layer=layer,
            pack_id=pack_id,
            workspace_id=self.scope_provider.workspace_id,
            has_iri=has_iri,
            limit=limit,
        )

    def list_relation_types(
        self,
        *,
        tier: Tier | None = None,
        layer: Layer | None = None,
        pack_id: str | None = None,
        has_iri: bool | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> list[OntologyRelation]:
        """List relation types with filters, scoped to the bound workspace.

        Mirror of `list_types`. `cursor` is reserved for later pagination
        work; Task 2c returns the full filtered set up to `limit`.
        """
        return self._graph._list_ontology_relations(
            tier=tier,
            layer=layer,
            pack_id=pack_id,
            workspace_id=self.scope_provider.workspace_id,
            has_iri=has_iri,
            limit=limit,
        )

    def priming_payload(
        self,
        workspace_id: str,
        *,
        max_types: int = 200,
        max_tokens: int = 2000,
        scope_hints: list[str] | None = None,
    ) -> dict:
        """Token-budget-aware effective view for batch-mode LLM priming.

        Default scope: `confirmed`-tier only.

        Eviction order (Codex Phase 3 Round 1 Finding H — doc/reality
        alignment): types are read in `frequency DESC, name ASC` order
        from `_list_ontology_types`, so the highest-frequency types are
        kept first under budget pressure and trailing low-frequency
        entries are evicted to fit `max_tokens`. The earlier docstring
        promised "frequency × recency" eviction; the substrate ranks on
        frequency only today. A recency-weighted ranking would need a
        graph-side `last_seen` index that doesn't exist yet — that
        upgrade is Phase 4 work.

        Unlike inline-path methods, `workspace_id` is an explicit parameter
        because batch/admin callers may compose payloads for workspaces
        other than the service's bound scope (e.g. cross-workspace
        snapshots, scheduled inference runs). The current implementation
        scopes the read to the bound graph, which is the same workspace
        scope `_list_ontology_types` honors.

        Token estimation uses the standard 4-chars-per-token heuristic over
        the serialized payload — close enough for budget-gating without
        importing a tokenizer here. Callers that need exact accounting
        should re-tokenize against their target model.
        """
        if self._graph is None:
            raise RuntimeError("priming_payload requires a bound ontology_graph")

        # Codex Phase 3 Round 3 Finding K (Phase 4 Task 12f): bounded
        # graph-side fetch + per-instance TTL cache.
        #
        # The previous implementation read every confirmed-tier row in
        # the workspace via `_list_ontology_types(limit=None)` on every
        # call, which is unbounded under large ontologies. The new
        # path uses a dedicated graph helper that projects only the
        # priming fields and applies `ORDER BY frequency DESC LIMIT
        # max_types * 2` at the Cypher layer (overfetch buffer for the
        # Python token-budget eviction below).
        #
        # Cache: keyed by `(workspace_id, max_types, max_tokens)`. TTL
        # 60s — priming is a best-effort hint, not a correctness
        # guarantee, so a slightly-stale snapshot is acceptable in
        # exchange for cutting the call cost. Cache hit returns the
        # cached dict; miss reads the graph, builds the payload, fills
        # the cache.
        import copy as _copy
        import time

        # Phase 4 Task 12e: scope_hints body honoring. Default scope is
        # confirmed-tier only; opt-in adds proposed-tier rows. Normalize
        # to a frozenset so cache keys are order-independent and
        # deduplicated. Retired tier is never added regardless.
        scope_hints_frozen = frozenset(s.lower() for s in (scope_hints or []) if isinstance(s, str))
        include_proposed = "proposed" in scope_hints_frozen

        cache_key = (workspace_id, int(max_types), int(max_tokens), scope_hints_frozen)
        now = time.monotonic()
        cached = getattr(self, "_priming_cache", None)
        if cached is not None:
            entry = cached.get(cache_key)
            if entry is not None and entry["expires_at"] > now:
                # Codex Phase 4 Task 12f Round 2 Finding O: return a
                # deep copy so caller mutations can't corrupt the
                # cached payload for subsequent readers.
                return _copy.deepcopy(entry["payload"])

        # Codex Phase 4 Task 12f Round 2 Finding N: capture the
        # workspace generation BEFORE reading the graph. If a
        # concurrent invalidator fires while we're reading, the
        # generation will have moved by the time we try to fill the
        # cache, and we'll skip the fill — preventing stale-write
        # poisoning.
        gens = getattr(self, "_priming_generation", None)
        gen_at_read_start = (gens or {}).get(workspace_id, 0)

        # Read confirmed-tier types — the load-bearing rule from
        # design.md trust_origin matrix: only `confirmed` types are
        # stable enough to prime an LLM with by default. Proposed
        # entries are unstable hypotheses; priming with them risks the
        # LLM over-generating types it has been told are "known".
        # Working/retired tiers are never primed.
        #
        # Phase 4 Task 12e: when `scope_hints=["proposed"]`, also read
        # proposed-tier rows. Curators opt in for inference runs that
        # benefit from in-flight hypotheses (cross-document
        # consistency, evolving ontologies). Each row carries its
        # source `tier`, so downstream callers (e.g. Task 12a's
        # confidence boost) can gate behavior — only confirmed-tier
        # matches inherit the trust floor; proposed-tier matches do
        # not.
        #
        # Phase 4 Task 12f: bounded graph-side fetch via the dedicated
        # priming helper. Overfetch by 2x so the token-budget eviction
        # below has buffer to drop entries without losing the most
        # important rows. The graph-side `ORDER BY frequency DESC,
        # name ASC` mirrors what the previous Python sort produced;
        # cross-tier merge below re-applies the same key.
        overfetch_limit = max(int(max_types) * 2, int(max_types))
        tiers_to_read = ["confirmed"]
        if include_proposed:
            tiers_to_read.append("proposed")
            logger.info(
                "priming_payload(workspace=%s) including proposed-tier rows "
                "via scope_hints — caller has opted into unstable hypotheses",
                workspace_id,
            )

        serialized: list[dict] = []
        for tier_name in tiers_to_read:
            serialized.extend(
                self._graph._list_ontology_types_for_priming(
                    workspace_id=workspace_id,
                    tier=tier_name,
                    limit=overfetch_limit,
                )
            )

        # Cross-tier merge: each per-tier read is already sorted by
        # frequency DESC, name ASC (graph-side); re-apply the same key
        # over the union so high-frequency proposed types can outrank
        # low-frequency confirmed ones under the budget.
        serialized.sort(key=lambda r: (-int(r.get("frequency") or 0), r.get("name") or ""))
        # Trim to max_types BEFORE token-budget eviction so eviction
        # operates on the priming-relevant slice only.
        serialized = serialized[: int(max_types)]

        # Token-budget gate. Use 4-chars-per-token heuristic — overshoots
        # slightly for English which is fine for budget purposes (we'd
        # rather under-fill than overflow the model's context window).
        def _estimate(payload_types: list[dict]) -> int:
            import json as _json

            return len(_json.dumps(payload_types, separators=(",", ":"))) // 4

        # Evict trailing entries until the budget fits. Cheap O(n) loop —
        # the list is already capped at `max_types` (200 by default),
        # so worst-case is bounded.
        while serialized and _estimate(serialized) > max_tokens:
            serialized.pop()

        # `version` is a short fingerprint so callers can cache primings
        # cheaply — workspace-id + count is sufficient identity for this
        # scope today; bump to a content hash if multi-snapshot caching
        # becomes a concern.
        # Codex review (2026-05-03 Phase 3 Round 1 Finding E): the
        # previous version key was `{workspace}:confirmed:{count}`,
        # which collides whenever one type is swapped for another at
        # the same count. Any priming cache keyed by `version` would
        # then serve stale content. Use a content hash so the key
        # changes whenever the serialized payload changes (different
        # names, aliases, qids, or count).
        import hashlib
        import json as _json

        content_hash = hashlib.sha256(
            _json.dumps(serialized, separators=(",", ":"), sort_keys=True).encode("utf-8")
        ).hexdigest()[:16]
        # Phase 4 Task 12e: include scope marker so version differs
        # between confirmed-only and confirmed+proposed payloads even
        # when content_hash happens to collide (empty workspaces, etc).
        scope_marker = "+".join(sorted({"confirmed", *tiers_to_read}))
        version = f"{workspace_id}:{scope_marker}:{len(serialized)}:{content_hash}"

        payload = {
            "version": version,
            "types": serialized,
            "estimated_tokens": _estimate(serialized),
        }

        # Phase 4 Task 12f Round 2 Finding N: only fill the cache if
        # the workspace generation hasn't moved since we started
        # reading. A concurrent invalidator increments the generation;
        # detecting the mismatch tells us our snapshot is stale and we
        # must NOT cache it. Caller still gets the just-built payload
        # (correct at the time it was read; just don't reuse it).
        if not hasattr(self, "_priming_cache"):
            self._priming_cache = {}
        if not hasattr(self, "_priming_generation"):
            self._priming_generation = {}
        gen_now = self._priming_generation.get(workspace_id, 0)
        if gen_now == gen_at_read_start:
            self._priming_cache[cache_key] = {
                "payload": _copy.deepcopy(payload),
                "expires_at": now + 60.0,
            }
        return payload

    def get_audit_for_type(self, type_id: str) -> list[dict]:
        """Read the append-only audit log entries for a type identifier.

        Returns chronologically-ordered (oldest first) list of audit
        entries whose `target_type_id` matches `type_id`. The substrate
        does NOT normalize the type_id at write time, so callers query
        with the same identifier they used at write time (typically
        the type name).
        """
        return self._graph._get_audit_for_type(type_id)

    def get_audit_summary(
        self,
        *,
        since: str,
        until: str | None = None,
        group_by: list[str] | None = None,
        recent_limit: int = 50,
    ) -> dict:
        """ONTO-RECONCILE-1 Phase 6 — bounded audit aggregation over a window.

        Operator-facing summary of the substrate's append-only audit log.
        Two bounded queries (counts + recent-actions), substrate-side; this
        wrapper validates inputs and routes to `OntologyGraph._get_audit_summary`.

        ``before_json``, ``after_json``, and ``evidence_ref`` are EXCLUDED
        from `recent_actions` per the privacy contract — they carry
        caller-supplied content (entity_id, free-text reasons, JSON
        payloads).

        NOT wrapped in `_safe_governance` (write-shield). Audit reads
        on a lite backend instead surface as an empty-shape return with
        a WARNING log per `no-silent-degradation.md`.

        Parameters
        ----------
        since : str
            ISO-8601 lower bound (inclusive). Required.
        until : str | None
            ISO-8601 upper bound (inclusive). Default open-ended.
        group_by : list[str] | None
            Reserved for future caller-driven group keys. Today the
            substrate always groups by `(action, actor)` jointly and
            folds into `by_action` and `by_actor`. Validation: any
            value MUST be a subset of {"action", "actor"}; passing
            other strings raises `ValueError`.
        recent_limit : int
            Cap on `recent_actions` rows. Default 50.
        """
        # Input validation (cheap fail-fast; no backend call).
        # Use datetime.fromisoformat for real ISO-8601 parsing — surface-level
        # 'T'-substring check (Codex review round 1 finding #1) lets through
        # malformed strings that then cause silent wrong-result Cypher
        # comparisons via lex order.
        from datetime import datetime as _datetime
        if not isinstance(since, str):
            raise ValueError(
                f"`since` must be ISO-8601 string, got {type(since).__name__}"
            )
        try:
            _datetime.fromisoformat(since.replace("Z", "+00:00"))
        except (TypeError, ValueError) as e:
            raise ValueError(
                f"`since` must be ISO-8601 (e.g. '2026-05-01T00:00:00+00:00'), got {since!r}: {e}"
            )
        # Reject date-only forms — Codex review round 2 nit. fromisoformat
        # accepts '2026-05-01' but the substrate compares against full
        # ISO timestamps, and the docstring advertises timestamp specificity.
        if "T" not in since:
            raise ValueError(
                f"`since` must be a full ISO-8601 timestamp (with 'T'), got date-only {since!r}"
            )
        if until is not None:
            if not isinstance(until, str):
                raise ValueError(
                    f"`until` must be ISO-8601 string or None, got {type(until).__name__}"
                )
            try:
                _datetime.fromisoformat(until.replace("Z", "+00:00"))
            except (TypeError, ValueError) as e:
                raise ValueError(
                    f"`until` must be ISO-8601 or None, got {until!r}: {e}"
                )
            if "T" not in until:
                raise ValueError(
                    f"`until` must be a full ISO-8601 timestamp (with 'T'), got date-only {until!r}"
                )
        if group_by is not None:
            allowed = {"action", "actor"}
            invalid = set(group_by) - allowed
            if invalid:
                raise ValueError(
                    f"`group_by` items must be in {sorted(allowed)}, got invalid: {sorted(invalid)}"
                )
        if not isinstance(recent_limit, int) or recent_limit < 0:
            raise ValueError(f"`recent_limit` must be a non-negative int, got {recent_limit!r}")

        from smartmemory.backends.unsupported import UnsupportedBackendError

        try:
            return self._graph._get_audit_summary(
                since=since, until=until, recent_limit=recent_limit
            )
        except UnsupportedBackendError as e:
            # LITE-mode parity: visible degradation, NOT _safe_governance
            # (that helper's docstring forbids wrapping reads — caused
            # gaps.md CORE-29). Empty shape + WARNING log.
            logger.warning("audit_summary unavailable on lite backend: %s", e)
            return {
                "total_rows": 0,
                "by_action": {},
                "by_actor": {},
                "recent_actions": [],
                "since": since,
                "until": until,
            }

    # ------------------------------------------------------------------
    # Write methods
    # ------------------------------------------------------------------

    def record_observation(self, observation: Observation) -> None:
        """Per-ingest write from any observer (Online or Batch).

        Workspace is resolved from the service's bound `ScopeProvider`,
        not from the observation. Always writes to the private layer
        for that workspace.

        Type-name case normalization (`.title()`) is applied internally
        when the identifier is a name; iri (`http://`) and qid (`Q\\d+`)
        pass through unmodified.

        Flow:
          1. Normalize observation.type_name (.title()) — iri/qid untouched.
          2. EvidenceStore.add(observation) — accumulate signals.
          3. Promoter.evaluate(identifier) — apply gates.
          4. On positive verdict + actual tier change: write tier +
             audit('promoter_verdict'). Same-tier no-op skips both.

        Audit-atomicity gap (Task 2f): tier write and audit write are
        sequential, not transactional. If audit fails the tier change
        has already landed and the exception propagates per Task 2d's
        no-silent-swallow rule. Bulk transactional path lands with Task 8.
        """
        if self._promoter is None or self._evidence_store is None:
            raise RuntimeError(
                "OntologyService.record_observation requires ontology_graph and a "
                "scope_provider with workspace_id at construction time"
            )

        # Normalize the type name (Task 1 contract — iri/qid pass through).
        normalized_name = _normalize_type_identifier(observation.type_name)
        normalized_obs = (
            observation
            if normalized_name == observation.type_name
            else replace_observation_type_name(observation, normalized_name)
        )

        identifier = (
            normalized_obs.type_iri or normalized_obs.type_qid or normalized_obs.type_name
        )

        # ONTO-RECONCILE-1 Phase 2 (Task 5 — Path A migration): ensure a
        # `:OntologyType` row exists somewhere in the effective layer
        # walk before accumulating evidence. The legacy stage path used
        # to call `OntologyGraph.add_provisional` which always wrote a
        # private-layer row; in the unified flow `record_observation`
        # is the single mediation point.
        #
        # Codex review (2026-05-03 Finding 1): we MUST consult the full
        # layer walk first, not just the private layer. If the type
        # already exists at `confirmed` on `domain` or `public` (e.g.
        # from `bootstrap_wikidata_seed` or a pack install), creating
        # a private `working` overlay would shadow the stronger row
        # and regress `get_type_status()` to working. Only synthesize
        # a private row when NO effective row exists at any layer.
        # `_upsert_ontology_type` is never-demote, so the synthesized
        # private working row is safe even when subsequent observations
        # promote it — the upsert leaves promoted rows untouched.
        ws = self.scope_provider.workspace_id
        installed_packs = self._installed_packs_for_workspace()
        effective = self._layers.resolve_effective(
            identifier,
            workspace_id=ws,
            installed_packs=installed_packs,
        )
        if effective is None:
            ot = OntologyType(
                name=normalized_obs.type_name,
                # NOTE: iri/qid must be None (not "") so the
                # composite-name lookup path
                # (`iri IS NULL AND wikidata_qid IS NULL AND name = $id`)
                # matches the row on subsequent observations. Empty string
                # ≠ NULL in FalkorDB and silently breaks evidence accrual.
                iri=normalized_obs.type_iri or None,
                wikidata_qid=normalized_obs.type_qid or None,
                tier="working",
                layer="private",
                workspace_id=ws,
            )
            self._graph._upsert_ontology_type(ot)

        # Step 2: accumulate evidence.
        self._evidence_store.add(normalized_obs)

        # Step 3: evaluate gates.
        # Resolve current tier from the type's effective view using the
        # STRONGEST identifier (iri → qid → name). Resolving by name only
        # would miss iri/qid-anchored rows because the composite-name
        # lookup requires `iri IS NULL AND wikidata_qid IS NULL`. If the
        # type doesn't exist in the private layer yet, treat current_tier
        # as "working" — the Promoter will gate on min_frequency etc.
        existing = self._layers.resolve_effective(
            identifier,
            workspace_id=self.scope_provider.workspace_id,
            installed_packs=self._installed_packs_for_workspace(),
        )
        current_tier = existing.tier if existing is not None else "working"

        verdict = self._promoter.evaluate(
            identifier,
            type_name=normalized_obs.type_name,
            mode=normalized_obs.mode,
            current_tier=current_tier,
        )

        # Step 4: same-tier no-op (mirror Task 3 transition pattern).
        if not verdict.promote or current_tier == verdict.to_tier:
            return
        if existing is None:
            # Promoter said "promote" but no row exists yet — observation
            # discarded by `_record_observation_evidence`'s warning path.
            # Skip the tier write rather than crash; audit isn't written
            # because no graph state changed.
            return

        self._graph._set_ontology_type_tier(existing, verdict.to_tier)
        # Phase 4 Task 12f Finding L: a tier change to/from `confirmed`
        # invalidates priming for this workspace.
        self._invalidate_priming_cache(self.scope_provider.workspace_id)
        # Audit AFTER the graph write succeeds. `target_type_id` records
        # the caller's verbatim identifier (Task 2f contract).
        self._safe_governance(self._graph._write_audit_entry,
            actor=self._resolve_actor(),
            action="promoter_verdict",
            target_type_id=identifier,
            before_json=f'{{"tier": "{current_tier}"}}',
            after_json=f'{{"tier": "{verdict.to_tier}", "trust_origin": "{verdict.trust_origin}"}}',
            evidence_ref=verdict.reason,
        )

    def set_evidence_cohesion(self, identifier: str, cohesion: float) -> None:
        """Update the corpus-level cohesion signal for a type. Batch-only.

        Routes through `EvidenceStore.set_cohesion`. Used by
        `BatchObserver` after corpus_score() runs.

        Applies the same Task 1 identifier normalization as
        `record_observation` so the cohesion write lands on the same row
        as the evidence (without this, "doctor" cohesion would target a
        different identity slot than the "Doctor" evidence row and the
        batch cohesion gate would silently never see the value).
        """
        if self._evidence_store is None:
            raise RuntimeError(
                "set_evidence_cohesion requires an EvidenceStore (graph + workspace must be bound)"
            )
        self._evidence_store.set_cohesion(_normalize_type_identifier(identifier), cohesion)

    def record_relation_observation(self, observation: Observation) -> None:
        """Per-ingest write for relation observations.

        ONTO-RELFREQ-MIGRATE-1 (2026-05-04): writes `:OntologyRelation`
        only. The legacy two-call shape (`add_provisional_relation_type`
        + `increment_relation_frequency`) wrote `:RelationType`, which
        ONTO-RECONCILE-1 Task 10's migration retired. Routing inline
        observations through the unified label is what unblocks Task 11
        (drop legacy `:RelationType`) — without this rewrite, every
        ingest would re-create the legacy rows the migration just
        cleaned up.

        Single-Cypher upsert via
        `OntologyGraph._upsert_inline_ontology_relation_observation`:
        first observation creates the row at tier='working',
        source='inline', layer='private', workspace_id=current;
        subsequent observations accumulate `confidence` into `frequency`
        and bump `last_seen`. Identity is `(name, layer, workspace_id)`
        because inline observations have no `iri`/`wikidata_pid` until
        grounding fires. Tier never demotes; if a curator has already
        promoted the relation to confirmed, repeat inline observations
        leave the tier alone (the MERGE's `ON MATCH` doesn't touch
        tier/source/layer).

        Stopword/short-label filtering is the caller's responsibility
        (currently `_normalize_and_score_relations` in
        `OntologyConstrainStage`). Empty `type_name` is a silent no-op
        per the original contract.
        """
        if self._graph is None:
            raise RuntimeError(
                "OntologyService.record_relation_observation requires a bound ontology_graph"
            )
        name = observation.type_name
        if not name:
            return
        self._graph._upsert_inline_ontology_relation_observation(
            name, observation.confidence
        )

    def upsert_inline_ontology_pattern(
        self,
        name: str,
        label: str,
        confidence: float,
        *,
        workspace_id: str | None = None,
        is_global: bool = False,
        source: str = "llm_discovery",
        initial_count: int = 1,
        registry_id: str | None = None,
    ) -> bool:
        """Per-write surface for inline pattern observations.

        ONTO-PATTERN-MIGRATE-1 (2026-05-04): writes patterns whose
        `IS_INSTANCE_OF` edge targets a dual-labelled
        `:EntityType:OntologyType` parent, not a single-label `:EntityType`.
        Unblocks ONTO-RECONCILE-1 Task 11 (drop legacy `:EntityType`).

        Most in-tree callers invoke `OntologyGraph._upsert_inline_ontology_pattern`
        directly because they don't have an `OntologyService` instance in
        scope (constructor requires `scope_provider` + `ontology_registry`
        kwargs). This service surface ships for symmetry with the sibling
        `record_relation_observation` and for callers that already hold a
        constructed service.
        """
        if self._graph is None:
            raise RuntimeError(
                "OntologyService.upsert_inline_ontology_pattern requires a bound ontology_graph"
            )
        if not name or not label:
            return False
        return self._graph._upsert_inline_ontology_pattern(
            name=name,
            label=label,
            confidence=confidence,
            workspace_id=workspace_id,
            is_global=is_global,
            source=source,
            initial_count=initial_count,
            registry_id=registry_id,
        )

    def apply_changeset(
        self,
        ir: Any,  # OntologyIR
        *,
        source: Literal["batch", "manual", "inline_replay", "imported_owl"],
        target_layer: Literal["private", "domain", "public"] = "private",
        pack_id: str | None = None,
        pack_version: str | None = None,
        auto_approve: bool = False,
    ) -> ApplyResult:
        """Bulk write from BatchObserver, ManualObserver, or import paths.

        Substrate semantics (per design.md trust_origin matrix +
        plan.md §3 Task 8):

        Tier policy:
            auto_approve=False (default — batch / manual review path)
                new types  → tier="proposed",  trust_origin="batch_proposed"
                new rels   → tier="proposed",  trust_origin="batch_proposed"
            auto_approve=True (trusted bulk imports — OWL bootstrap,
                pack install)
                new types  → tier="confirmed", trust_origin="imported"
                new rels   → tier="confirmed", trust_origin="imported"

        Approved-only filter: only IR entries with `status="approved"`
        are written. This closes blueprint correction #1 — the route
        handler historically wrote *every* concept while
        `materialize_ontology` filtered to approved + min_confidence;
        routing through this orchestrator unifies the gate.

        Audit: every type/relation/taxonomy edge that lands writes one
        `:OntologyAudit` row with action='changeset_applied'. The audit
        chain is consistent with Task 2f's "audit reflects what landed
        in the graph, not attempts" rule.

        Atomicity (Codex Phase 3 Round 1 Finding F): writes are
        per-row, NOT wrapped in a single backend transaction. Each
        type/relation upsert is followed by its audit row, and the
        whole batch is followed by an optional registry snapshot. A
        failure mid-batch leaves earlier graph + audit writes
        committed and exits early via exception propagation. Callers
        observe this through:
          1. The exception itself (graph-write or audit-write raise).
          2. `result.warnings` listing any post-graph audit failures
             that occurred before propagation.
          3. The per-category counts reflecting what actually landed
             before the failure point.
        Full transactional bulk apply lands with Phase 4's
        substrate-side transaction support; today the substrate
        documents the gap rather than hiding it.

        Idempotency: `_upsert_ontology_type` / `_upsert_ontology_relation`
        are never-demote (Task 2 / 2c contract); replays leave already
        promoted rows untouched. So a retry after a partial-apply
        failure converges the substrate to the desired end state.

        Registry composition: when `self._registry` is bound (production),
        the substrate calls `OntologyRegistry.apply_changeset` for
        snapshot persistence. Without a registry (tests, lite mode),
        snapshot persistence is skipped — graph rows + audit are still
        written. The full registry round-trip needs MongoDB; substrate
        tests exercise the graph-only path.

        Returns:
            `ApplyResult` with per-category counts.
        """
        if self._graph is None:
            raise RuntimeError("apply_changeset requires a bound ontology_graph")

        result = ApplyResult(new_version=getattr(ir, "registry_id", "") or "test")

        # Tier and trust_origin selection per the matrix above.
        if auto_approve:
            tier_for_new = "confirmed"
            trust_origin = "imported"
        else:
            tier_for_new = "proposed"
            trust_origin = "batch_proposed"

        # Source enum — must be one of the documented Source literals.
        # `imported_owl` is the OWL/pack-import path; everything else
        # uses the source value supplied at the call site.
        type_source = "imported_owl" if source == "imported_owl" else source
        if type_source not in (
            "inline", "batch", "manual", "inline_replay", "imported_owl",
            "migration_recovered",
        ):
            type_source = "batch"

        workspace_id = self.scope_provider.workspace_id
        actor = self._resolve_actor()

        # ------------------------------------------------------------------
        # Concepts → :OntologyType
        # ------------------------------------------------------------------
        from smartmemory.ontology.ir_models import Status

        for concept in getattr(ir, "concepts", []) or []:
            if getattr(concept, "status", None) != Status.APPROVED:
                result.rejected += 1
                continue
            label = getattr(concept, "label", "") or ""
            if not label:
                result.rejected += 1
                continue
            ot = OntologyType(
                name=_normalize_type_identifier(label),
                tier=tier_for_new,
                trust_origin=trust_origin,
                layer=target_layer,
                workspace_id=workspace_id,
                pack_id=pack_id,
                pack_version=pack_version,
                source=type_source,
                confidence=getattr(concept, "confidence", 0.0) or 0.0,
                aliases=list(getattr(concept, "synonyms", []) or []),
            )
            self._graph._upsert_ontology_type(ot)
            result.types_added += 1
            # Codex Phase 3 Round 1 Finding F: audit-write atomicity
            # gap. The graph row has already committed; if the audit
            # write fails, raising would abort the rest of the batch
            # and leave a half-written changeset. Track the gap in
            # `result.warnings` so callers can detect missing audit
            # rows after the apply completes, then continue. Per
            # Task 2f's documented audit caveat.
            try:
                # `_safe_governance` returns the audit_id on FalkorDB (truthy)
                # or None when the SQLite backend shielded an
                # `UnsupportedBackendError` (lite mode has no audit log).
                # Only count rows that actually landed — DIST-LITE-ONTO-1
                # post-Codex finding F.
                _audit_id = self._safe_governance(self._graph._write_audit_entry,
                    actor=actor,
                    action="changeset_applied",
                    target_type_id=ot.name,
                    after_json=(
                        f'{{"tier": "{tier_for_new}", '
                        f'"trust_origin": "{trust_origin}", '
                        f'"layer": "{target_layer}"}}'
                    ),
                    evidence_ref=getattr(ir, "registry_id", "") or "",
                )
                if _audit_id is not None:
                    result.audit_entries_written += 1
            except Exception as audit_err:
                result.warnings.append(
                    f"audit_write_failed: type={ot.name!r} "
                    f"(graph row committed; audit row missing): {audit_err}"
                )

        # ------------------------------------------------------------------
        # Relations → :OntologyRelation
        # ------------------------------------------------------------------
        for relation in getattr(ir, "relations", []) or []:
            if getattr(relation, "status", None) != Status.APPROVED:
                result.rejected += 1
                continue
            label = getattr(relation, "label", "") or ""
            if not label:
                result.rejected += 1
                continue
            # Relations follow the Cypher edge-label convention (lowercase
            # snake_case like "works_at"); we deliberately skip the
            # title-case normalization that types use. iri/qid still
            # pass through unmodified.
            rel = OntologyRelation(
                name=label,
                tier=tier_for_new,
                trust_origin=trust_origin,
                layer=target_layer,
                workspace_id=workspace_id,
                pack_id=pack_id,
                pack_version=pack_version,
                source=type_source,
                confidence=getattr(relation, "confidence", 0.0) or 0.0,
                aliases=list(getattr(relation, "aliases", []) or []),
            )
            self._graph._upsert_ontology_relation(rel)
            result.relations_added += 1
            # Same audit-atomicity gap as the type loop above (Finding F).
            try:
                # See type-loop above for rationale (DIST-LITE-ONTO-1 post-Codex finding F).
                _audit_id = self._safe_governance(self._graph._write_audit_entry,
                    actor=actor,
                    action="changeset_applied",
                    target_type_id=rel.name,
                    after_json=(
                        f'{{"tier": "{tier_for_new}", '
                        f'"trust_origin": "{trust_origin}", '
                        f'"layer": "{target_layer}", '
                        f'"kind": "relation"}}'
                    ),
                    evidence_ref=getattr(ir, "registry_id", "") or "",
                )
                if _audit_id is not None:
                    result.audit_entries_written += 1
            except Exception as audit_err:
                result.warnings.append(
                    f"audit_write_failed: relation={rel.name!r} "
                    f"(graph row committed; audit row missing): {audit_err}"
                )

        # ------------------------------------------------------------------
        # Taxonomy → IS_A edges
        # ------------------------------------------------------------------
        # Phase 4 Task 12b: materialize approved taxonomy entries as
        # `(:OntologyType {name: child})-[:IS_A]->(:OntologyType {name: parent})`
        # edges via the new `_upsert_taxonomy_edge` substrate helper.
        # Idempotent (MERGE semantics); per-row missing-endpoint paths
        # surface as warnings, not silent drops, per
        # `feedback_no_silent_fallbacks`.
        #
        # Resolution: taxonomy IR carries concept IDs (`tax.parent`,
        # `tax.child`); concepts get upserted as `OntologyType` with
        # `name=_normalize_type_identifier(concept.label)`. Build a
        # `concept_id → name` lookup over the IR's concepts, then
        # resolve each taxonomy entry through it.
        concept_id_to_name = {
            c.id: _normalize_type_identifier(c.label)
            for c in (getattr(ir, "concepts", []) or [])
            if c.id and c.label
        }
        for tax in (getattr(ir, "taxonomy", []) or []):
            if getattr(tax, "status", None) != Status.APPROVED:
                continue
            parent_name = concept_id_to_name.get(tax.parent)
            child_name = concept_id_to_name.get(tax.child)
            if not parent_name or not child_name:
                # Per `feedback_no_silent_fallbacks`: surface, don't
                # drop. Caller can decide whether to retry with the
                # missing endpoints in scope.
                result.warnings.append(
                    f"taxonomy_endpoint_missing: parent={tax.parent!r} "
                    f"(resolved={parent_name!r}), child={tax.child!r} "
                    f"(resolved={child_name!r})"
                )
                continue
            try:
                created = self._graph._upsert_taxonomy_edge(
                    parent_name=parent_name,
                    child_name=child_name,
                    workspace_id=workspace_id,
                    source=type_source,
                    evidence_ref=getattr(ir, "registry_id", "") or "",
                )
            except Exception as e:
                result.warnings.append(
                    f"taxonomy_write_failed: parent={parent_name!r} "
                    f"child={child_name!r}: {e}"
                )
                continue
            if created:
                result.taxonomy_edges_added += 1
                # Audit per actual edge write.
                try:
                    _audit_id = self._safe_governance(
                        self._graph._write_audit_entry,
                        actor=actor,
                        action="taxonomy_added",
                        target_type_id=child_name,
                        after_json=(
                            f'{{"parent": "{parent_name}", '
                            f'"child": "{child_name}", '
                            f'"edge_kind": "IS_A"}}'
                        ),
                        evidence_ref=getattr(ir, "registry_id", "") or "",
                    )
                    if _audit_id is not None:
                        result.audit_entries_written += 1
                except Exception as audit_err:
                    result.warnings.append(
                        f"audit_write_failed: taxonomy {child_name!r}->"
                        f"{parent_name!r} (edge committed; audit missing): "
                        f"{audit_err}"
                    )

        # ------------------------------------------------------------------
        # Optional registry snapshot persistence
        # ------------------------------------------------------------------
        # When the registry is bound (production), persist a snapshot so
        # downstream consumers can read a frozen view. When it isn't
        # bound (tests, lite mode), the graph rows + audit are the
        # authoritative state — registry composition is a SHOULD, not
        # a MUST, at the substrate level.
        # Phase 4 Task 12f Finding L: a changeset can write
        # confirmed-tier rows (auto_approve=True path) that should
        # show up in subsequent priming. Invalidate the workspace's
        # priming cache before returning. Cheap; runs once per
        # changeset rather than per-row.
        if result.types_added or result.relations_added:
            self._invalidate_priming_cache(workspace_id)

        if self._registry is not None:
            try:
                snapshot_id = self._registry.apply_changeset(
                    registry_id=getattr(ir, "registry_id", "default") or "default",
                    base_version="",
                    changeset_dict=ir.to_dict() if hasattr(ir, "to_dict") else {},
                    message=f"apply_changeset source={source} target_layer={target_layer}",
                )
                result.snapshot_id = snapshot_id
            except Exception as e:
                # Snapshot persistence is opportunistic — log and
                # continue. The graph state is the source of truth.
                result.warnings.append(f"registry snapshot skipped: {e}")

        return result

    def transition(
        self,
        identifier: str,
        to_tier: Tier,
        reason: str,
        actor: str,
    ) -> None:
        """Decisive tier transition.

        `identifier` accepts iri/qid/name; resolved internally per the
        identity rule via LayerResolver. `actor` is the user_id (or
        `"system"` for migration script). Writes one `:OntologyAudit`
        entry per actual tier change.

        - Same-tier transition (replay) is a legal no-op — no tier
          write, no audit entry.
        - Illegal transitions (demotion, skip-forward) raise ValueError.
        - Calling on an absent type raises ValueError (transition is
          decisive, unlike `link_instance_to_type`'s silent-skip).
        - Type-name case normalization (`.title()`) applied internally
          when `identifier` is a name (iri/qid passed as-is).
        """
        from smartmemory.ontology.tiers import can_transition

        # Normalize per Task 1 contract via the shared helper — keeps
        # transition / record_observation / set_evidence_cohesion in
        # lockstep on the iri/qid/title rule.
        normalized = _normalize_type_identifier(identifier)

        # Resolve the existing type via LayerResolver (auto-fetches
        # installed_packs from the manifest; same path get_type uses).
        packs = self._installed_packs_for_workspace()
        existing = self._layers.resolve_effective(
            normalized,
            workspace_id=self.scope_provider.workspace_id,
            installed_packs=packs,
        )
        if existing is None:
            raise ValueError(
                f"transition: type {identifier!r} not found in workspace {self.scope_provider.workspace_id!r}"
            )

        if not can_transition(existing.tier, to_tier, reason):
            raise ValueError(
                f"illegal tier transition: {existing.tier!r} → {to_tier!r} "
                f"for type {existing.name!r} (reason: {reason!r})"
            )

        # Same-tier no-op — validator permits it but audit must reflect
        # what actually changed. Mirror of Task 2f's "audit reflects
        # what landed in the graph, not attempts."
        if existing.tier == to_tier:
            return

        self._graph._set_ontology_type_tier(existing, to_tier)
        # Phase 4 Task 12f Finding L: tier transitions to/from
        # `confirmed` invalidate priming for this workspace.
        self._invalidate_priming_cache(self.scope_provider.workspace_id)
        # Audit AFTER graph write succeeds. Same atomicity caveat as
        # other Task 2f writers — propagation of audit failures is
        # documented in the audit-section docstring above.
        #
        # `target_type_id` stores the caller's identifier verbatim per
        # Task 2f's contract — `get_audit_for_type` is a "read with the
        # same identifier you wrote with" lookup. So a transition called
        # via iri/qid is queryable by that iri/qid, and a name-based
        # transition is queryable by the same case-variant the caller
        # used. Symmetric with `link_instance_to_type` and `install_pack`.
        self._safe_governance(self._graph._write_audit_entry,
            actor=self._resolve_actor(actor),
            action="tier_transition",
            target_type_id=identifier,
            before_json=f'{{"tier": "{existing.tier}"}}',
            after_json=f'{{"tier": "{to_tier}"}}',
            evidence_ref=reason,
        )

    def retire_type(self, identifier: str, reason: str, actor: str) -> None:
        """Substrate's minimum-viable management. Implemented in Task 1f."""
        raise NotImplementedError("Task 1 management slice")

    def override_auto_promote(self, identifier: str, allow: bool, actor: str) -> None:
        """Substrate's minimum-viable management. Implemented in Task 1f."""
        raise NotImplementedError("Task 1 management slice")

    def link_instance_to_type(
        self,
        entity_id: str,
        type_identifier: str,
        *,
        installed_packs: list[str] | None = None,
    ) -> None:
        """Create the `(:Entity)-[:INSTANCE_OF]->(:OntologyType)` edge.

        Resolves `type_identifier` (iri / qid / name) via `LayerResolver`
        with effective-layer precedence, then MERGEs the edge in the
        ontology graph. Idempotent — replay creates no duplicates.

        **Cross-graph reality:** `:Entity` lives in the data graph,
        `:OntologyType` lives in the ontology graph; FalkorDB graphs
        are isolated. The substrate mirrors a minimal `:Entity` stub
        in the ontology graph to anchor the edge intra-graph. The real
        entity in the data graph is untouched.

        **Silent-skip:** if no type matches the identifier (the type
        may legitimately not exist yet during early ingest), this is a
        no-op — no error, no stub `:Entity` created. The Promoter
        (Task 3b) handles type-creation; linking is a downstream side
        effect that gracefully waits.
        """
        packs = self._installed_packs_for_workspace() if installed_packs is None else installed_packs
        resolved = self._layers.resolve_effective(
            type_identifier,
            workspace_id=self.scope_provider.workspace_id,
            installed_packs=packs,
        )
        if resolved is None:
            return  # Silent skip — type not in any layer (or hidden by pack gating).
        self._graph._link_entity_to_type(entity_id, resolved)
        # Audit AFTER the write succeeds. If the backend write raises,
        # the exception propagates (per Task 2d's no-silent-swallow rule)
        # and the audit is not written — audit reflects the graph, not
        # attempts. `target_type_id` records the caller's identifier
        # (what the human knows) rather than the resolved row's slot.
        self._safe_governance(self._graph._write_audit_entry,
            actor=self._resolve_actor(),
            action="link_created",
            target_type_id=type_identifier,
            evidence_ref=entity_id,
        )

    # ------------------------------------------------------------------
    # Priming cache invalidation (Phase 4 Task 12f / Codex Round 1 Finding L)
    # ------------------------------------------------------------------
    #
    # Every confirmed-tier-affecting write path calls
    # `_invalidate_priming_cache(workspace_id)` so the next
    # `priming_payload()` call reads fresh data instead of serving
    # the up-to-60s-stale cached payload. Workspace-scoped: a write
    # in workspace A doesn't drop B's cache.

    def _invalidate_priming_cache(self, workspace_id: str | None = None) -> None:
        """Drop cached priming payloads for `workspace_id` and bump
        the workspace generation counter.

        Codex Phase 4 Task 12f Round 2 Finding N: a naive
        invalidate-and-clear is racy. A concurrent reader that missed
        cache → started a graph read → invalidate fires → reader
        completes and stores the stale payload would defeat the
        invalidation for the full 60s TTL.

        Mitigation: every write path bumps `_priming_generation`. The
        reader captures the generation BEFORE reading the graph, and
        only stores the payload if the generation hasn't moved. A
        concurrent invalidate increments the counter, so a stale
        reader detects the mid-flight write and skips its cache fill.

        When `workspace_id` is None (rare — full reset), drops every
        cached entry and bumps the global generation.
        """
        cache = getattr(self, "_priming_cache", None)
        if cache is None:
            cache = {}
            self._priming_cache = cache
        gens = getattr(self, "_priming_generation", None)
        if gens is None:
            gens = {}
            self._priming_generation = gens

        if workspace_id is None:
            cache.clear()
            for k in list(gens.keys()):
                gens[k] = gens.get(k, 0) + 1
            return

        keys_to_drop = [k for k in cache.keys() if k[0] == workspace_id]
        for k in keys_to_drop:
            cache.pop(k, None)
        gens[workspace_id] = gens.get(workspace_id, 0) + 1

    # ------------------------------------------------------------------
    # Bootstrap (Task 6b — substrate-only OWL work)
    # ------------------------------------------------------------------

    def bootstrap_wikidata_seed(self) -> int:
        """Write SmartMemory's seed entity types to the public ontology layer.

        Walks the canonical `WIKIDATA_TYPE_MAP` (Wikidata P31 QID → SmartMemory
        type name) and emits one `:OntologyType` row per UNIQUE mapped type
        name. Rows land at:

            layer="public"          — the substrate's "everyone sees it" layer
            tier="confirmed"        — seed types are pre-curated, not gated
            trust_origin="imported" — distinguishes OWL bootstrap from observer
            source="imported_owl"   — provenance trail for migrators

        The mapping has multiple QIDs collapsing to a single name (e.g.
        Q9143 "programming language" + Q271680 "software framework" both →
        "Technology"). We dedupe on the value so the public layer carries
        one row per concept, not one row per Wikidata source class.
        Per-QID equivalences belong on the row's `equivalent_iris` /
        `equivalent_qids` collections; the substrate today doesn't track
        that backlink and won't synthesize it here. ONTO-IO-1 owns the
        full OWL/RDF import path (per plan.md §3 Task 6b out-of-scope
        notes).

        **Idempotency.** `_upsert_ontology_type` is never-demote
        (Task 2 contract): a second bootstrap call leaves rows already
        at higher or equal tiers untouched. A `confirmed` row stays
        `confirmed`; a hypothetically-promoted-to-`retired` row stays
        `retired`. This is the right semantics for replay-safety —
        operators who advanced a seed type don't get clobbered when
        the importer re-runs.

        Returns:
            Number of unique type names written (or attempted to write
            on replay — count of distinct values in `WIKIDATA_TYPE_MAP`).
            Caller can compare to `len(set(WIKIDATA_TYPE_MAP.values()))`
            for the contract assertion.

        Raises:
            RuntimeError: if no `ontology_graph` was bound at construction.
        """
        if self._graph is None:
            raise RuntimeError(
                "OntologyService.bootstrap_wikidata_seed requires a bound ontology_graph"
            )
        from smartmemory.grounding.type_map import WIKIDATA_TYPE_MAP

        unique_names = sorted(set(WIKIDATA_TYPE_MAP.values()))

        # Codex Phase 3 Round 1 Finding G: `bootstrap_wikidata_seed` is
        # contractually append-only with respect to `WIKIDATA_TYPE_MAP`.
        # If the map shrinks (entry removed) or renames (value changed)
        # between runs, prior public-layer rows orphan because we don't
        # walk existing rows to reconcile. Detect drift by comparing
        # the current public-layer seed set against `unique_names` and
        # log at WARNING per `feedback_no_silent_fallbacks`. Operators
        # can re-curate via direct retire / transition; an automatic
        # reconciliation pass is Phase 4 work because it requires
        # provenance distinguishing seed-imported rows from operator-
        # curated public rows (today both look identical at the schema
        # level — both are layer=public/tier=confirmed).
        try:
            existing_public = self._graph._list_ontology_types(
                layer="public",
                tier="confirmed",
                workspace_id=self.scope_provider.workspace_id,
            )
            existing_names = {ot.name for ot in existing_public if ot.name}
            orphan_candidates = existing_names - set(unique_names)
            if orphan_candidates:
                import logging
                _log = logging.getLogger(__name__)
                _log.warning(
                    "bootstrap_wikidata_seed: %d public-layer types are not in "
                    "the current WIKIDATA_TYPE_MAP and may be orphaned by a "
                    "shrunk/renamed map: %s. Substrate is append-only for "
                    "seeds; manual reconciliation required.",
                    len(orphan_candidates),
                    sorted(orphan_candidates),
                )
        except Exception as e:
            # Drift detection is best-effort — never block the bootstrap.
            import logging
            logging.getLogger(__name__).debug(
                "bootstrap_wikidata_seed drift-check skipped: %s", e
            )

        for name in unique_names:
            ot = OntologyType(
                name=name,
                # No iri/qid for seed types — they're SmartMemory-internal
                # abstractions, not Wikidata classes. Multiple Wikidata
                # P31 values flow into each one. Future ONTO-IO-1 work
                # may attach `equivalent_iris=[...]` listing the source
                # QIDs, but the substrate doesn't model that today.
                iri=None,
                wikidata_qid=None,
                tier="confirmed",
                layer="public",
                # Public layer is workspace-agnostic in the contract, but
                # `_upsert_ontology_type` requires a workspace_id; bind
                # to the service's bound workspace. LayerResolver's
                # public-layer walk reads cross-workspace per the
                # design, so this anchor doesn't gate visibility.
                workspace_id=self.scope_provider.workspace_id,
                trust_origin="imported",
                source="imported_owl",
            )
            self._graph._upsert_ontology_type(ot)

        # Codex Phase 4 Task 12f Round 3 Finding Q: invalidate AFTER
        # the write loop, not before. A pre-loop bump would let a
        # concurrent reader cache a pre-write snapshot for 60s
        # because the reader's gen-at-read-start would already
        # match the post-bump value (the bump completed before any
        # writes landed). Post-loop bump ensures any reader whose
        # graph read overlapped the loop sees the generation move
        # before they try to fill the cache.
        if unique_names:
            self._invalidate_priming_cache(self.scope_provider.workspace_id)
        return len(unique_names)

    def reconcile_seed(self, *, retire: bool = False) -> "ReconcileResult":
        """Reconcile public-layer seed rows against the current
        `WIKIDATA_TYPE_MAP`.

        Phase 4 Task 13c — Codex Phase 3 Round 1 Finding G follow-up.
        `bootstrap_wikidata_seed` is contractually append-only and only
        warns on drift; this method gives operators a programmatic path
        to retire orphaned rows when the map shrinks or renames.

        Walks public-layer rows at `tier="confirmed"` in the bound
        workspace, diffs against the unique values of
        `WIKIDATA_TYPE_MAP`, and:
        - `retire=False` (default): returns counts without acting,
          preserving append-only semantics.
        - `retire=True`: transitions each orphan to `retired` tier and
          writes one `:OntologyAudit` row per retirement with
          `actor="reconcile_seed"`, `action="tier_transition"`.

        Same atomicity caveat as other Task 2f writers: graph write
        lands first, audit follows; failures propagate per the
        no-silent-swallow rule.

        Returns:
            `ReconcileResult` — orphan count, retired count, names,
            and any non-fatal warnings (e.g. graph read errors).

        Raises:
            RuntimeError: if no `ontology_graph` is bound.
        """
        from smartmemory.ontology.types import ReconcileResult
        from smartmemory.grounding.type_map import WIKIDATA_TYPE_MAP

        if self._graph is None:
            raise RuntimeError(
                "OntologyService.reconcile_seed requires a bound ontology_graph"
            )

        result = ReconcileResult()
        valid_names = set(WIKIDATA_TYPE_MAP.values())

        try:
            existing = self._graph._list_ontology_types(
                layer="public",
                tier="confirmed",
                workspace_id=self.scope_provider.workspace_id,
            )
        except Exception as e:
            result.warnings.append(f"reconcile_seed graph read failed: {e}")
            logger.warning("reconcile_seed graph read failed: %s", e)
            return result

        orphans = [ot for ot in existing if ot.name and ot.name not in valid_names]
        result.orphaned = len(orphans)
        result.orphan_names = sorted(ot.name for ot in orphans)

        if not retire or not orphans:
            return result

        for ot in orphans:
            try:
                self._graph._set_ontology_type_tier(ot, "retired")
            except Exception as e:
                result.warnings.append(
                    f"reconcile_seed: failed to retire {ot.name!r}: {e}"
                )
                logger.warning("reconcile_seed retire failed for %r: %s", ot.name, e)
                continue
            self._safe_governance(
                self._graph._write_audit_entry,
                actor="reconcile_seed",
                action="tier_transition",
                target_type_id=ot.name,
                before_json=f'{{"tier": "{ot.tier}"}}',
                after_json='{"tier": "retired"}',
                evidence_ref=f"reconcile_seed: orphan vs WIKIDATA_TYPE_MAP",
            )
            result.retired += 1

        if result.retired:
            self._invalidate_priming_cache(self.scope_provider.workspace_id)

        return result

    def ensure_indexes(self) -> None:
        """Create FalkorDB indexes for `:OntologyType` (Task 2),
        `:OntologyRelation` (Task 2c), `:PackInstallation` (Task 2e),
        and `:OntologyAudit` (Task 2f). Mirrors the
        `FalkorDBGraphService._create_indexes()` pattern (CREATE INDEX +
        per-statement try/except for idempotency)."""
        self._graph.ensure_ontology_type_indexes()
        self._graph.ensure_ontology_relation_indexes()
        self._graph.ensure_pack_installation_indexes()
        self._graph.ensure_ontology_audit_indexes()

    # ------------------------------------------------------------------
    # Audit (Task 2f) — every mutating method writes one entry
    # ------------------------------------------------------------------
    #
    # **Atomicity caveat.** Audit writes are sequential second-step
    # writes after the graph mutation, NOT transactional with it. If
    # `_write_audit_entry` raises, the graph mutation has already
    # landed and the audit row is missing. The exception propagates
    # (per Task 2d's no-silent-swallow rule), so callers can detect
    # the inconsistency and decide on repair, but the substrate does
    # not roll back the graph state. Full transactional audit lands
    # with `apply_changeset` (Task 8) under the workspace-scoped lock
    # planned for the bulk write path.

    def _resolve_actor(self, explicit: str | None = None) -> str:
        """Resolve actor for an audit entry.

        Priority: explicit caller-supplied (e.g. install_pack's
        `installed_by`, transition's `actor`) > scope_provider's user_id
        > "system". The "system" default covers pipeline-fired calls
        (link_instance_to_type from OntologyConstrainStage) where there
        is no user context.
        """
        if explicit:
            return explicit
        user_id = getattr(self.scope_provider, "user_id", None)
        return user_id or "system"

    # ------------------------------------------------------------------
    # Pack installation manifest (Task 2e)
    # ------------------------------------------------------------------

    def install_pack(
        self,
        pack_id: str,
        pack_version: str,
        *,
        source: str,
        installed_by: str,
    ) -> None:
        """Record a pack as installed in the bound workspace.

        Idempotent on `(workspace_id, pack_id, pack_version)`. Replaying
        the same install does NOT overwrite the original `installed_at` /
        `installed_by` / `source` (those are audit-relevant).

        Pack content (`:OntologyType` / `:OntologyRelation` rows) is a
        separate concern — install_pack only writes the manifest. The
        pack-install pipeline (ONTO-PACKS-INSTALL-1) will compose this
        with `apply_changeset(target_layer="domain", pack_id=...,
        pack_version=...)`.
        """
        self._graph._record_pack_installation(
            self.scope_provider.workspace_id,
            pack_id,
            pack_version,
            installed_by=installed_by,
            source=source,
        )
        # Audit: record the install action. The actor is the explicit
        # `installed_by` (caller-supplied), not the scope provider —
        # installs are explicitly attributed even when the bound
        # provider has its own user_id.
        self._safe_governance(self._graph._write_audit_entry,
            actor=installed_by,
            action="pack_installed",
            target_pack_id=pack_id,
            target_pack_version=pack_version,
            after_json=f'{{"source": "{source}"}}',
        )

    def uninstall_pack(self, pack_id: str, pack_version: str) -> None:
        """Remove the pack-installation manifest row for the bound workspace.

        Pack content (the actual `:OntologyType` rows tagged with
        `pack_id`/`pack_version`) is NOT removed here — that's
        `_drop_pack_version` on the graph, called explicitly by the
        pack-uninstall pipeline. Keeping manifest-removal separate from
        content-removal lets a caller temporarily hide a pack without
        deleting its contributions.
        """
        removed = self._graph._remove_pack_installation(self.scope_provider.workspace_id, pack_id, pack_version)
        # Audit only when the graph actually changed. An uninstall against
        # a non-installed pack is a true no-op and writing an audit entry
        # for it would imply a state change that didn't happen — same
        # rule as `link_instance_to_type`'s silent-skip path.
        if removed:
            self._safe_governance(self._graph._write_audit_entry,
                actor=self._resolve_actor(),
                action="pack_uninstalled",
                target_pack_id=pack_id,
                target_pack_version=pack_version,
            )

    def list_installations(self) -> list[dict]:
        """Return the bound workspace's installed packs.

        Each row: `{pack_id, pack_version, installed_at, installed_by, source}`.
        Used by `_installed_packs_for_workspace` for the auto-resolve
        path (so callers don't need to pass `installed_packs` to
        `get_type` / `get_relation_type` / `link_instance_to_type`).
        """
        return self._graph._list_workspace_installations(self.scope_provider.workspace_id)

    def _installed_packs_for_workspace(self) -> list[str]:
        """Workspace's installed pack_ids — input to `LayerResolver`.

        Returns the deduped, ordered list of installed `pack_id`s. The
        domain layer's per-pack precedence is determined by this order
        (see `LayerResolver._walk_layers`); we emit by `(pack_id,
        pack_version)` order from the graph helper, which means a
        single pack with multiple installed versions appears once per
        version. Per-version precedence is rarely meaningful in
        practice; collapsing duplicates is fine.

        No caching today — per-read DB hit is acceptable while pack
        churn is low. If this becomes hot, cache per-instance with
        invalidation on install/uninstall.
        """
        seen: set[str] = set()
        ordered: list[str] = []
        for row in self.list_installations():
            pack_id = row.get("pack_id")
            if pack_id and pack_id not in seen:
                seen.add(pack_id)
                ordered.append(pack_id)
        return ordered
