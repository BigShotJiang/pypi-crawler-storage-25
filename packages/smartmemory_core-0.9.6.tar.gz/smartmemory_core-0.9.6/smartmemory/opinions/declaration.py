"""ManagedType declaration for the `opinion` memory type.

Opinions are beliefs with confidence scores formed from pattern recognition
across episodic memories. They can be reinforced or contradicted over time.
Subject-keyed deterministic IDs let evolvers idempotently update the same
opinion across runs.

See smart-memory-docs/docs/features/CORE-EXPERTISE-1/phase-3-backfill-managers/
plan.md (T3).
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from smartmemory.managed import Field, ManagedType
from smartmemory.models.opinion import Disposition


def _sha12(s: str | None) -> str:
    return hashlib.sha256((s or "").encode("utf-8")).hexdigest()[:12]


def _opinion_id_generator(fields: dict[str, Any]) -> str:
    subject = fields.get("subject") or fields.get("content") or ""
    return f"opinion_{_sha12(subject)}"


def _serialize_disposition(d):
    if d is None:
        return None
    if isinstance(d, dict):
        return d
    return d.to_dict()


def _deserialize_disposition(raw):
    if raw is None:
        return None
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return None
    if isinstance(raw, dict):
        return Disposition.from_dict(raw)
    return raw


def _opinion_reinforce_extra(instance, evidence_id: str) -> None:
    """Append evidence_id to formed_from on reinforce. Called AFTER base math."""
    existing = list(getattr(instance, "formed_from", None) or [])
    if evidence_id and evidence_id not in existing:
        existing.append(evidence_id)
    instance.formed_from = existing


def _opinion_contradict_extra(instance, evidence_id: str) -> None:
    """Append evidence_id to formed_from on contradict. Mirrors reinforce_extra."""
    existing = list(getattr(instance, "formed_from", None) or [])
    if evidence_id and evidence_id not in existing:
        existing.append(evidence_id)
    instance.formed_from = existing


def _net_reinforcement(inst) -> int:
    return (inst.reinforcement_count or 0) - (inst.contradiction_count or 0)


def _stability(inst) -> float:
    total = (inst.reinforcement_count or 0) + (inst.contradiction_count or 0)
    if total == 0:
        return 0.5
    return (inst.reinforcement_count or 0) / total


def _opinion_first_class(instance) -> dict:
    return {"confidence": instance.confidence}


_OPINION_TYPE = ManagedType(
    name="opinion",
    fields={
        "subject": Field(str, optional=True, indexed=True),
        "subject_type": Field(str, optional=True),
        "formed_from": Field(list),
        "disposition": Field(
            Disposition,
            optional=True,
            serializer=_serialize_disposition,
            deserializer=_deserialize_disposition,
        ),
    },
    default_confidence=0.5,
    origin="user:opinion",
    handler_origin="evolver:opinion",
    lifecycle="extended",
    id_field="opinion_id",
    id_generator=_opinion_id_generator,
    reinforce_extra=_opinion_reinforce_extra,
    contradict_extra=_opinion_contradict_extra,
    computed_properties={
        "net_reinforcement": _net_reinforcement,
        "stability": _stability,
    },
    first_class_fn=_opinion_first_class,
    describe_summary=(
        "Opinion records — beliefs with confidence scores; "
        "subject-keyed deterministic IDs; reinforce/contradict update confidence."
    ),
)


_OpinionBase, _OpinionHandlerBase, _OpinionManagerBase, _OpinionQueriesBase = _OPINION_TYPE.derive()
