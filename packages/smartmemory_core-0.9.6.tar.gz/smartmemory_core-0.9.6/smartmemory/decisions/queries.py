"""Decision query patterns.

Path C migration (CORE-MANAGED-TYPE-FRAMEWORK-1 Phase 2): subclass of the
framework-derived `_DecisionQueriesBase`. Domain-specific methods (provenance
chains, causal traversal) stay handwritten; standard list/lookup methods are
inherited from the base.
"""

from __future__ import annotations

import logging
from typing import Any, Literal

from smartmemory.decisions.declaration import _DecisionQueriesBase

logger = logging.getLogger(__name__)


class DecisionQueries(_DecisionQueriesBase):
    """Query patterns for decisions - filtered retrieval, provenance, causal chains.

    Usage:
        queries = DecisionQueries(smart_memory)
        active = queries.get_active_decisions(domain="preferences")
        chain = queries.get_causal_chain(decision_id, direction="causes")
    """

    # ---- Hydration override (content fallback) -------------------------

    def _hydrate(self, item: Any):
        """Convert a MemoryItem (or dict) to a Decision with content fallback.

        Mirrors legacy DecisionQueries._to_decision (queries.py:241-255).
        """
        from smartmemory.models.decision import Decision

        if item is None:
            return None
        if isinstance(item, Decision):
            return item
        metadata = getattr(item, "metadata", None)
        if isinstance(item, dict):
            metadata = item.get("metadata", item)
        if not isinstance(metadata, dict):
            return None
        if "content" not in metadata or not metadata["content"]:
            content = getattr(item, "content", None) or (item.get("content") if isinstance(item, dict) else "")
            metadata["content"] = content
        return Decision.from_dict(metadata)

    # alias used by existing tests
    _to_decision = _hydrate

    # ---- Filtered retrieval (legacy API surface) -----------------------

    def get_active_decisions(
        self,
        domain: str | None = None,
        decision_type: str | None = None,
        min_confidence: float = 0.0,
        limit: int = 50,
    ) -> list:
        """Get all active decisions, optionally filtered."""
        try:
            items = self.memory.search(query="*", memory_type="decision", top_k=limit * 2)
        except Exception:
            try:
                items = self.memory.search(query="decision", memory_type="decision", top_k=limit * 2)
            except Exception as e:
                logger.warning(f"Failed to search for decisions: {e}")
                return []

        decisions = []
        for item in items:
            d = self._hydrate(item)
            if d is None or not d.is_active:
                continue
            if domain and d.domain != domain:
                continue
            if decision_type and d.decision_type != decision_type:
                continue
            if d.confidence < min_confidence:
                continue
            decisions.append(d)
            if len(decisions) >= limit:
                break

        return decisions

    def get_decisions_about(self, topic: str, limit: int = 20) -> list:
        """Get active decisions related to a topic via semantic search."""
        try:
            items = self.memory.search(query=topic, memory_type="decision", top_k=limit)
        except Exception as e:
            logger.warning(f"Failed to search decisions for topic '{topic}': {e}")
            return []

        decisions = []
        for item in items:
            d = self._hydrate(item)
            if d is not None and d.is_active:
                decisions.append(d)

        return decisions

    # ---- Graph traversal (domain-specific) -----------------------------

    def get_decision_provenance(self, decision_id: str) -> dict[str, Any]:
        """Get full provenance chain for a decision."""
        result: dict[str, Any] = {
            "decision": None,
            "reasoning_trace": None,
            "evidence": [],
            "superseded": [],
        }

        item = self.memory.get(decision_id)
        if item is None:
            return result
        result["decision"] = self._hydrate(item)

        if not self.graph:
            return result

        incoming = self.graph.get_incoming_neighbors(decision_id, edge_type="PRODUCED")
        if incoming:
            trace_node = incoming[0]
            result["reasoning_trace"] = trace_node

        neighbors = self.graph.get_neighbors(decision_id, edge_type="DERIVED_FROM")
        if neighbors:
            for node in neighbors:
                node_id = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                result["evidence"].append({
                    "memory": node,
                    "memory_id": node_id,
                })

        superseded = self.graph.get_neighbors(decision_id, edge_type="SUPERSEDES")
        if superseded:
            for node in superseded:
                d = self._hydrate(node)
                if d:
                    result["superseded"].append(d)

        return result

    def get_causal_chain(
        self,
        decision_id: str,
        direction: Literal["causes", "effects", "both"] = "both",
        max_depth: int = 3,
    ) -> dict[str, Any]:
        """Trace causal chain from a decision."""
        item = self.memory.get(decision_id)
        result: dict[str, Any] = {
            "decision": self._hydrate(item) if item else None,
            "causes": [],
            "effects": [],
        }

        if not self.graph or item is None:
            return result

        if direction in ("causes", "both"):
            result["causes"] = self._traverse_causes(decision_id, max_depth)

        if direction in ("effects", "both"):
            result["effects"] = self._traverse_effects(decision_id, max_depth)

        return result

    def _traverse_causes(self, node_id: str, max_depth: int, current_depth: int = 0) -> list[dict[str, Any]]:
        """Recursively traverse cause edges (DERIVED_FROM, CAUSED_BY)."""
        if current_depth >= max_depth or not self.graph:
            return []

        causes: list[dict[str, Any]] = []

        for edge_type in ["DERIVED_FROM", "CAUSED_BY"]:
            neighbors = self.graph.get_neighbors(node_id, edge_type=edge_type)
            if not neighbors:
                continue
            for node in neighbors:
                node_id_val = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                causes.append({
                    "node": node,
                    "node_id": node_id_val,
                    "relationship": edge_type,
                    "depth": current_depth + 1,
                    "causes": self._traverse_causes(node_id_val, max_depth, current_depth + 1) if node_id_val else [],
                })

        return causes

    def _traverse_effects(self, node_id: str, max_depth: int, current_depth: int = 0) -> list[dict[str, Any]]:
        """Recursively traverse effect edges (CAUSES, INFLUENCES, PRODUCED)."""
        if current_depth >= max_depth or not self.graph:
            return []

        effects: list[dict[str, Any]] = []

        for edge_type in ["CAUSES", "INFLUENCES", "PRODUCED"]:
            neighbors = self.graph.get_neighbors(node_id, edge_type=edge_type)
            if not neighbors:
                continue
            for node in neighbors:
                node_id_val = node.get("item_id") if isinstance(node, dict) else getattr(node, "item_id", None)
                effects.append({
                    "node": node,
                    "node_id": node_id_val,
                    "relationship": edge_type,
                    "depth": current_depth + 1,
                    "effects": self._traverse_effects(node_id_val, max_depth, current_depth + 1) if node_id_val else [],
                })

        return effects
