# The New Navigators

## Chapter 1: The Resonance Academy

Five years after the moratorium, Kael Vandris stood before the first class of the Resonance Academy on Araxis. Twenty students — ten from Hegemony worlds, ten Araxeen — sat in a chamber carved from living chronodust crystal, its walls pulsing with the slow rhythm of the sandweaver network.

"You are here to learn a new way of navigating," Kael told them. "Not the old way — burning chronodust in sealed chambers until your body breaks down. Not the Consortium way — taking what you need without regard for consequence. A new way. One that works with the sandweavers, not against them."

The curriculum merged the Cognitive Order's three pillars with the Keepers' Resonance discipline. Students spent their mornings in Pattern, Control, and Projection exercises adapted from the Order's archives. Afternoons were devoted to Resonance practice in the caves, under the supervision of Keepers who had been teaching these methods for generations.

The integration was not seamless. The Order's methods were analytical, reductive, sequential. The Keepers' methods were holistic, intuitive, simultaneous. Students trained in one tradition struggled with the other. But those who could bridge the gap — who could hold both Pattern and Resonance at once — achieved something neither tradition could produce alone: they could communicate with the sandweaver network without losing their individual identity.

## Chapter 2: The First Symbiotic Fold

The first symbiotic fold — a fold conducted in cooperation with the sandweavers rather than at their expense — took place one year after the Academy opened. The navigator was Amara Chen, a twenty-two-year-old from the ocean world of Pelago who had shown an extraordinary aptitude for Resonance.

The procedure was nothing like traditional fold navigation. There was no sealed chamber, no chronodust vapor, no physical degradation. Amara sat in the cave network's central chamber, surrounded by six juvenile sandweavers who had been gradually acclimated to her presence over months of Resonance practice.

She entered Resonance. The weavers responded — their bioluminescence synchronizing with her breathing, their vibrations aligning with her heartbeat. Together, human and sandweaver, they perceived the substrate topology of the space between Araxis and Caldera.

The fold opened. Not the violent tearing of traditional navigation, but a gentle parting — like pushing through a curtain rather than smashing through a wall. The ship that passed through reported the smoothest fold transit in recorded history. Zero substrate degradation. Zero navigator damage.

Amara opened her eyes and smiled. "They showed me the way," she said. "I just had to ask."

## Chapter 3: The Legacy

Kael Vandris governed Araxis for forty more years. He never took the title of Emperor, though it was offered twice. He never left Araxis, though the new fold network made travel effortless. He spent his final decades deepening his Resonance with the sandweaver consciousness, contributing human perspectives to a planetary intelligence that had existed for twelve millennia.

Lady Senna died at ninety-three, sharp-minded to the end, in the cave chamber where she had first taken refuge during the Consortium's assassination attempt. Her last words were to Dhamira: "I never understood Resonance. But I trusted the people who did. I think that was enough."

Dhamira outlived them all. The Araxeen lifespan, sustained by the low-level chronodust exposure in the caves, extended well past two centuries. She continued teaching at the Resonance Academy, her methods unchanged, her patience infinite.

The Hegemony evolved into the Accord — a loose federation of twelve systems connected by symbiotic fold routes, each route maintained by a partnership between human navigators and local sandweaver populations that had been seeded on habitable worlds across the network. The chronodust trade ceased. There was nothing to trade. The sandweavers produced what was needed, where it was needed, in cooperation with navigators who asked rather than took.

It was not utopia. There were disputes, shortages, the ordinary frictions of civilization. But the substrate was stable. The fractures were healed. And when navigators folded space, the sandweavers folded with them — two species, intertwined, crossing the stars together.

Kael's last entry in his personal journal, written the night before his death at eighty-one, read: "The desert taught me to conserve. The caves taught me to connect. The weavers taught me that intelligence is not a property of individuals but of relationships. I was not a great leader. I was a adequate translator between species that needed each other and did not know it."

The sandweavers remembered him. In the network's vast, distributed memory, his pattern was preserved — not as data, but as a vibration. A resonance. A note in the chord of a consciousness older than human civilization.

It was, Dhamira would say, the highest honor Araxis could bestow.
