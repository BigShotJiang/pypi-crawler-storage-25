import asyncio
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from rank_bm25 import BM25Okapi

from x64rag.retrieval.common.logging import get_logger
from x64rag.retrieval.common.models import RetrievedChunk, VectorResult
from x64rag.retrieval.modules.ingestion.embeddings.base import BaseEmbeddings
from x64rag.retrieval.modules.ingestion.embeddings.sparse.base import BaseSparseEmbeddings
from x64rag.retrieval.modules.retrieval.search.fusion import reciprocal_rank_fusion
from x64rag.retrieval.stores.vector.base import BaseVectorStore

logger = get_logger("retrieval.methods.vector")

_GLOBAL_KEY = "__global__"


def _tokenize(text: str) -> list[str]:
    return re.findall(r"\w+", text.lower())


@dataclass
class _BM25Entry:
    index: BM25Okapi | None
    chunks: list[dict[str, Any]] = field(default_factory=list)
    last_used: float = 0.0


class VectorRetrieval:
    """Unified vector retrieval method combining dense/hybrid search with optional BM25."""

    def __init__(
        self,
        vector_store: BaseVectorStore,
        embeddings: BaseEmbeddings,
        sparse_embeddings: BaseSparseEmbeddings | None = None,
        parent_expansion: bool = False,
        bm25_enabled: bool = False,
        bm25_max_indexes: int = 16,
        bm25_tokenizer: Callable[[str], list[str]] | None = None,
        weight: float = 1.0,
        top_k: int | None = None,
    ) -> None:
        self._store = vector_store
        self._embeddings = embeddings
        self._sparse = sparse_embeddings
        self._parent_expansion = parent_expansion
        self._bm25_enabled = bm25_enabled
        self._bm25_max_indexes = bm25_max_indexes
        self._tokenize_fn = bm25_tokenizer or _tokenize
        self._weight = weight
        self._top_k = top_k
        self._bm25_cache: dict[str, _BM25Entry] = {}
        self._bm25_lock = asyncio.Lock()

    @property
    def name(self) -> str:
        return "vector"

    @property
    def weight(self) -> float:
        return self._weight

    @property
    def top_k(self) -> int | None:
        return self._top_k

    async def search(
        self,
        query: str,
        top_k: int = 10,
        filters: dict[str, Any] | None = None,
        knowledge_id: str | None = None,
    ) -> list[RetrievedChunk]:
        start = time.perf_counter()
        try:
            results = await self._do_search(query, top_k, filters, knowledge_id)
            elapsed = (time.perf_counter() - start) * 1000
            logger.info("%d results in %.1fms", len(results), elapsed)
            return results
        except Exception:
            elapsed = (time.perf_counter() - start) * 1000
            logger.warning("vector retrieval failed in %.1fms", elapsed, exc_info=True)
            return []

    async def invalidate_cache(self, knowledge_id: str | None = None) -> None:
        key = knowledge_id if knowledge_id is not None else _GLOBAL_KEY
        async with self._bm25_lock:
            self._bm25_cache.pop(key, None)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _do_search(
        self,
        query: str,
        top_k: int,
        filters: dict[str, Any] | None,
        knowledge_id: str | None,
    ) -> list[RetrievedChunk]:
        # Dense / hybrid vector search
        dense_results = await self._vector_search(query, top_k, filters)

        if not self._bm25_enabled:
            return dense_results

        # BM25 keyword search
        bm25_results = await self._bm25_search(query, top_k, knowledge_id)

        if not bm25_results:
            return dense_results

        return reciprocal_rank_fusion([dense_results, bm25_results])[:top_k]

    # ------------------------------------------------------------------
    # Dense / hybrid search (from VectorSearch)
    # ------------------------------------------------------------------

    async def _vector_search(
        self,
        query: str,
        top_k: int,
        filters: dict[str, Any] | None,
    ) -> list[RetrievedChunk]:
        if self._sparse:
            dense_result, sparse_vector = await asyncio.gather(
                self._embeddings.embed([query]),
                self._sparse.embed_sparse_query(query),
            )
            query_vector = dense_result[0] if dense_result else None
            if not query_vector:
                logger.warning("embedding returned no vectors for query")
                return []
            results = await self._store.hybrid_search(
                vector=query_vector,
                sparse_vector=sparse_vector,
                top_k=top_k,
                filters=filters,
            )
            logger.info("%d candidates from hybrid search", len(results))
        else:
            vectors = await self._embeddings.embed([query])
            if not vectors:
                logger.warning("embedding returned no vectors for query")
                return []
            query_vector = vectors[0]
            results = await self._store.search(vector=query_vector, top_k=top_k, filters=filters)
            logger.info("%d candidates from dense search", len(results))

        results = [r for r in results if r.payload.get("chunk_type", "child") == "child"]

        if self._parent_expansion and results:
            results = await self._expand_parents(results)

        return [self._result_to_chunk(r) for r in results]

    async def _expand_parents(self, results: list[VectorResult]) -> list[VectorResult]:
        """For each child result with a parent_id, fetch the parent and return its content instead."""
        parent_ids = set()
        for r in results:
            pid = r.payload.get("parent_id")
            if pid:
                parent_ids.add(pid)

        if not parent_ids:
            return results

        parents = await self._store.retrieve(list(parent_ids))
        parent_map = {p.point_id: p for p in parents}

        expanded = []
        seen_parents: set[str] = set()

        for r in results:
            pid = r.payload.get("parent_id")
            if pid and pid in parent_map:
                if pid in seen_parents:
                    continue
                seen_parents.add(pid)
                parent = parent_map[pid]
                expanded.append(
                    VectorResult(
                        point_id=r.point_id,
                        score=r.score,
                        payload={**parent.payload, "expanded_from_child": r.point_id},
                    )
                )
            else:
                expanded.append(r)

        return expanded

    @staticmethod
    def _result_to_chunk(r: VectorResult) -> RetrievedChunk:
        return RetrievedChunk(
            chunk_id=r.point_id,
            content=r.payload.get("content", ""),
            score=r.score,
            page_number=r.payload.get("page_number"),
            section=r.payload.get("section"),
            source_id=r.payload.get("source_id", ""),
            source_type=r.payload.get("source_type"),
            source_weight=r.payload.get("source_weight", 1.0),
            source_metadata={
                "name": r.payload.get("source_name", ""),
                "file_url": r.payload.get("file_url", ""),
                "tags": r.payload.get("tags", []),
                "chunk_type": r.payload.get("chunk_type", "child"),
                "parent_id": r.payload.get("parent_id"),
            },
        )

    # ------------------------------------------------------------------
    # BM25 keyword search (from KeywordSearch)
    # ------------------------------------------------------------------

    async def _bm25_search(
        self,
        query: str,
        top_k: int,
        knowledge_id: str | None,
    ) -> list[RetrievedChunk]:
        key = knowledge_id if knowledge_id is not None else _GLOBAL_KEY
        if key not in self._bm25_cache:
            await self._build_bm25_index(knowledge_id)

        entry = self._bm25_cache.get(key)
        if entry is None or entry.index is None or not entry.chunks:
            return []

        entry.last_used = time.monotonic()

        tokenized_query = self._tokenize_fn(query)
        scores = entry.index.get_scores(tokenized_query)

        scored = sorted(
            zip(scores, entry.chunks, strict=True),
            key=lambda x: x[0],
            reverse=True,
        )

        results = []
        for score, chunk in scored:
            if score <= 0:
                break
            results.append(
                RetrievedChunk(
                    chunk_id=chunk["point_id"],
                    content=chunk["content"],
                    score=float(score),
                    page_number=chunk["page_number"],
                    section=chunk["section"],
                    source_id=chunk["source_id"],
                    source_type=chunk["source_type"],
                    source_weight=chunk["source_weight"],
                    source_metadata={
                        "name": chunk["source_name"],
                        "file_url": chunk["file_url"],
                        "tags": chunk["tags"],
                    },
                )
            )
            if len(results) >= top_k:
                break

        logger.info("%d candidates from bm25 search", len(results))
        return results

    async def _build_bm25_index(self, knowledge_id: str | None) -> None:
        key = knowledge_id if knowledge_id is not None else _GLOBAL_KEY
        if key in self._bm25_cache:
            return
        async with self._bm25_lock:
            if key in self._bm25_cache:
                return

            filters = {"knowledge_id": knowledge_id} if knowledge_id is not None else None
            all_chunks: list[dict[str, Any]] = []
            offset = None

            while True:
                results, next_offset = await self._store.scroll(filters=filters, limit=500, offset=offset)
                for r in results:
                    all_chunks.append(
                        {
                            "point_id": r.point_id,
                            "content": r.payload.get("content", ""),
                            "page_number": r.payload.get("page_number"),
                            "section": r.payload.get("section"),
                            "source_id": r.payload.get("source_id", ""),
                            "source_type": r.payload.get("source_type"),
                            "source_weight": r.payload.get("source_weight", 1.0),
                            "source_name": r.payload.get("source_name", ""),
                            "file_url": r.payload.get("file_url", ""),
                            "tags": r.payload.get("tags", []),
                        }
                    )
                if next_offset is None or not results:
                    break
                offset = next_offset

            self._evict_lru()

            if not all_chunks:
                self._bm25_cache[key] = _BM25Entry(index=None, last_used=time.monotonic())
                return

            loop = asyncio.get_running_loop()
            tokenize_fn = self._tokenize_fn
            tokenized = await loop.run_in_executor(None, lambda: [tokenize_fn(c["content"]) for c in all_chunks])
            index = await loop.run_in_executor(None, lambda: BM25Okapi(tokenized))
            self._bm25_cache[key] = _BM25Entry(index=index, chunks=all_chunks, last_used=time.monotonic())
            logger.info("built bm25 index for knowledge_id=%s: %d chunks", knowledge_id, len(all_chunks))

    def _evict_lru(self) -> None:
        if len(self._bm25_cache) < self._bm25_max_indexes:
            return
        oldest_key = min(self._bm25_cache, key=lambda k: self._bm25_cache[k].last_used)
        del self._bm25_cache[oldest_key]
        logger.info("evicted bm25 index for key=%s (lru)", oldest_key)
