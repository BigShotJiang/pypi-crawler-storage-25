from x64rag.retrieval.common.logging import get_logger
from x64rag.retrieval.stores.metadata.base import BaseMetadataStore

logger = get_logger("knowledge/migration")


async def check_embedding_migration(
    metadata_store: BaseMetadataStore | None,
    embedding_model_name: str,
) -> int:
    """Check if the configured embedding model differs from stored sources.

    Flags affected sources as stale. Returns count of stale sources.
    Only works with metadata store. Returns 0 without one.
    """
    if metadata_store is None:
        return 0

    sources = await metadata_store.list_sources()
    stale_count = 0

    for source in sources:
        if source.embedding_model != embedding_model_name and not source.stale:
            await metadata_store.update_source(source.source_id, stale=True)
            stale_count += 1
            logger.warning(
                "source '%s' marked stale: embedded with '%s', current is '%s'",
                source.metadata.get("name", source.source_id),
                source.embedding_model,
                embedding_model_name,
            )

    if stale_count:
        logger.warning(
            "%d sources need re-ingestion due to embedding model change (%s)",
            stale_count,
            embedding_model_name,
        )

    return stale_count
