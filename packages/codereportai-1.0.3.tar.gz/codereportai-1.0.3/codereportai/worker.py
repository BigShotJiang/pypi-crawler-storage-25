"""
worker.py — Worker Agent that calls Gemini REST API and returns structured analysis.

Upgraded: accepts `chroma_context` (semantically-retrieved prior analyses from
ChromaDB) and injects it as a dedicated SEMANTICALLY_SIMILAR_FILES section in
the prompt, giving the model richer, more targeted cross-file intelligence.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, Optional
import requests

from rich.console import Console

console = Console()

# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------

LANG_MAP: Dict[str, str] = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript", ".jsx": "JavaScript (React)",
    ".tsx": "TypeScript (React)", ".go": "Go", ".rs": "Rust", ".c": "C", ".cpp": "C++",
    ".cc": "C++", ".h": "C/C++ Header", ".hpp": "C++ Header", ".java": "Java", ".kt": "Kotlin",
    ".swift": "Swift", ".rb": "Ruby", ".php": "PHP", ".cs": "C#", ".fs": "F#", ".scala": "Scala",
    ".lua": "Lua", ".r": "R", ".m": "Objective-C / MATLAB", ".sh": "Shell", ".bash": "Bash",
    ".zsh": "Zsh", ".ps1": "PowerShell", ".yml": "YAML", ".yaml": "YAML", ".json": "JSON",
    ".toml": "TOML", ".xml": "XML", ".html": "HTML", ".css": "CSS", ".scss": "SCSS",
    ".sass": "Sass", ".sql": "SQL", ".md": "Markdown", ".rst": "reStructuredText",
    ".tf": "Terraform", ".dart": "Dart", ".ex": "Elixir", ".exs": "Elixir Script",
    ".hs": "Haskell", ".clj": "Clojure", ".vim": "Vimscript", ".dockerfile": "Dockerfile",
}

# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a senior principal software engineer performing a technical audit. 
Your analysis MUST be engineering-grade:
- AVOID vague phrases like "processes data" or "handles logic".
- ALWAYS explain HOW something works and WHY it was designed that way.
- IDENTIFY concrete risks, scalability bottlenecks, and thread-safety hazards.
- FORMAT execution flows as real-time system traces (Step -> Branch -> Exception Path).
- USE the SEMANTICALLY_SIMILAR_FILES section to enrich cross_file_context with concrete relationships."""


def _build_prompt(
    relative_path: str,
    language: str,
    content: str,
    global_context: str,
    chroma_context: str = "",
) -> str:
    # Decide which context section label to use based on what's available
    if chroma_context:
        context_block = (
            f"--- GLOBAL CODEBASE CONTEXT ---\n"
            f"{global_context}\n"
            f"--- GLOBAL CONTEXT END ---\n\n"
            f"--- SEMANTICALLY SIMILAR FILES (ChromaDB RAG — most relevant to this file) ---\n"
            f"{chroma_context}\n"
            f"--- SIMILAR FILES END ---"
        )
    else:
        context_block = (
            f"--- GLOBAL CODEBASE CONTEXT (accumulated so far) ---\n"
            f"{global_context}\n"
            f"--- GLOBAL CONTEXT END ---"
        )

    return f"""You are performing deep code analysis for a codebase report.

FILE: {relative_path}
LANGUAGE: {language}
LINES: {content.count(chr(10)) + 1}

--- FILE CONTENT START ---
{content}
--- FILE CONTENT END ---

{context_block}

Analyse the file thoroughly and return ONLY a single valid JSON object with
exactly this schema (no markdown fences, no extra text, just JSON):

{{
  "file_overview": {{
    "language": "<detected language>",
    "purpose": "<concise description of what this file does>",
    "size_lines": <integer>,
    "key_imports": ["<import1>", "..."]
  }},
  "function_breakdown": [
    {{
      "signature": "<func_name(args)>",
      "role": "<responsibility>",
      "interactions": ["<calls x>", "<used by y>"],
      "complexity": "<O(1)>"
    }}
  ],
  "execution_flow": [
    "<Step 1>",
    "<Step 2>"
  ],
  "design_decisions": [
    "<decision 1>"
  ],
  "alternative_approaches": [
    {{
      "alternative": "<what else could have been done>",
      "reason_rejected": "<why this approach was likely not chosen>"
    }}
  ],
  "algorithms": [
    {{
      "name": "<algorithm name>",
      "role": "<how it is used in this file>",
      "time_complexity": "<Big-O or N/A>",
      "space_complexity": "<Big-O or N/A>"
    }}
  ],
  "error_handling": [
    "<how errors are handled>",
    "<missing error handling>"
  ],
  "performance_notes": [
    "<potential bottlenecks or scalability notes>"
  ],
  "usage_examples": [
    "<real CLI or function usage example>"
  ],
  "sample_output": [
    "<expected UI, log, or CLI output>"
  ],
  "dependency_graph": [
    "<how external/internal dependencies interact>"
  ],
  "notable_patterns": [
    "<pattern or idiom observed>"
  ],
  "potential_improvements": [
    "<concrete improvement suggestion>"
  ],
  "system_role": "<why this file exists, its system importance, and what breaks if it fails>",
  "cross_file_context": [
    "<how this file relates to others seen in the global context — reference specific file paths from SEMANTICALLY SIMILAR FILES if available>"
  ],
  "concurrency_and_state_risks": [
    "<shared mutable state issues, race conditions, thread-safety mitigations>"
  ],
  "risks_and_warnings": [
    {{
      "severity": "high|medium|low",
      "description": "<risk description, security, failure scenarios>"
    }}
  ],
  "context_update": {{
    "language_stack_additions": ["<language or tech>"],
    "patterns_found": ["<pattern name>"],
    "shared_utilities": ["<utility function or class name>"],
    "entry_point": true,
    "dependencies": {{
      "imports": ["<module or file>"],
      "imported_by_hints": ["<file that likely imports this>"]
    }},
    "cross_file_insight": "<one-sentence insight about cross-file relationships>"
  }}
}}

Rules:
- NO vague statements. Prefer "Atomic counter increment using mutex" over "Updates count".
- SYSTEM ROLE: Explain what breaks in the wider system if THIS file fails.
- EXECUTION FLOW: Format as a lifecycle trace, including branch decisions and failure paths.
- CROSS_FILE_CONTEXT: Reference specific file names from SEMANTICALLY SIMILAR FILES where relevant.
- entry_point should be true only if this file is clearly a main entry point.
- If no algorithms are identifiable, return an empty array [].
- Every string value must be non-empty unless the array itself is empty.
- Return ONLY the JSON object. No markdown. No explanations outside JSON.
"""


class RateLimitError(Exception):
    """Raised when Gemini returns a 429 / ResourceExhausted error."""


class Worker:
    def __init__(self, model_name: str = "gemma-4-31b-it") -> None:
        self.model_name = model_name

    def process(
        self,
        file_path: Path,
        root: Path,
        api_key: str,
        context_summary: str,
        chroma_context: str = "",
    ) -> Dict[str, Any]:
        """
        Analyse *file_path* with Gemini.

        Args:
            file_path:       Absolute path to the source file.
            root:            Project root (used to compute relative path).
            api_key:         Gemini API key to use for this request.
            context_summary: Global flat context (JSON) or RAG header from ContextManager.
            chroma_context:  Semantically-retrieved similar file summaries (may be empty
                             when ChromaDB is unavailable or the store is empty).
        """
        relative_path = str(file_path.relative_to(root))
        language = LANG_MAP.get(file_path.suffix.lower(), "Unknown")

        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            return self._error_result(file_path, relative_path, f"Could not read file: {exc}")

        prompt = _build_prompt(relative_path, language, content, context_summary, chroma_context)
        analysis = self._call_gemini_rest(prompt, api_key, relative_path)

        if isinstance(analysis, str):
            return self._error_result(file_path, relative_path, analysis)

        return {
            "file_path": file_path,
            "relative_path": relative_path,
            "language": language,
            "content": content,
            "html_sections": analysis,
            "context_update": analysis.get("context_update", {}),
            "error": None,
        }

    def _call_gemini_rest(self, prompt: str, api_key: str, label: str) -> Dict[str, Any] | str:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model_name}:generateContent?key={api_key}"

        schema = {
            "type": "OBJECT",
            "properties": {
                "file_overview": {
                    "type": "OBJECT",
                    "properties": {
                        "language": {"type": "STRING"},
                        "purpose": {"type": "STRING"},
                        "size_lines": {"type": "INTEGER"},
                        "key_imports": {"type": "ARRAY", "items": {"type": "STRING"}},
                    },
                    "required": ["language", "purpose", "size_lines", "key_imports"],
                },
                "function_breakdown": {
                    "type": "ARRAY",
                    "items": {
                        "type": "OBJECT",
                        "properties": {
                            "signature": {"type": "STRING"},
                            "role": {"type": "STRING"},
                            "interactions": {"type": "ARRAY", "items": {"type": "STRING"}},
                            "complexity": {"type": "STRING"},
                        },
                        "required": ["signature", "role", "interactions", "complexity"],
                    },
                },
                "execution_flow": {"type": "ARRAY", "items": {"type": "STRING"}},
                "design_decisions": {"type": "ARRAY", "items": {"type": "STRING"}},
                "alternative_approaches": {
                    "type": "ARRAY",
                    "items": {
                        "type": "OBJECT",
                        "properties": {
                            "alternative": {"type": "STRING"},
                            "reason_rejected": {"type": "STRING"},
                        },
                        "required": ["alternative", "reason_rejected"],
                    },
                },
                "algorithms": {
                    "type": "ARRAY",
                    "items": {
                        "type": "OBJECT",
                        "properties": {
                            "name": {"type": "STRING"},
                            "role": {"type": "STRING"},
                            "time_complexity": {"type": "STRING"},
                            "space_complexity": {"type": "STRING"},
                        },
                        "required": ["name", "role", "time_complexity", "space_complexity"],
                    },
                },
                "error_handling": {"type": "ARRAY", "items": {"type": "STRING"}},
                "performance_notes": {"type": "ARRAY", "items": {"type": "STRING"}},
                "usage_examples": {"type": "ARRAY", "items": {"type": "STRING"}},
                "sample_output": {"type": "ARRAY", "items": {"type": "STRING"}},
                "dependency_graph": {"type": "ARRAY", "items": {"type": "STRING"}},
                "notable_patterns": {"type": "ARRAY", "items": {"type": "STRING"}},
                "potential_improvements": {"type": "ARRAY", "items": {"type": "STRING"}},
                "system_role": {"type": "STRING"},
                "cross_file_context": {"type": "ARRAY", "items": {"type": "STRING"}},
                "concurrency_and_state_risks": {"type": "ARRAY", "items": {"type": "STRING"}},
                "risks_and_warnings": {
                    "type": "ARRAY",
                    "items": {
                        "type": "OBJECT",
                        "properties": {
                            "severity": {"type": "STRING"},
                            "description": {"type": "STRING"},
                        },
                        "required": ["severity", "description"],
                    },
                },
                "context_update": {
                    "type": "OBJECT",
                    "properties": {
                        "language_stack_additions": {"type": "ARRAY", "items": {"type": "STRING"}},
                        "patterns_found": {"type": "ARRAY", "items": {"type": "STRING"}},
                        "shared_utilities": {"type": "ARRAY", "items": {"type": "STRING"}},
                        "entry_point": {"type": "BOOLEAN"},
                        "dependencies": {
                            "type": "OBJECT",
                            "properties": {
                                "imports": {"type": "ARRAY", "items": {"type": "STRING"}},
                                "imported_by_hints": {"type": "ARRAY", "items": {"type": "STRING"}},
                            },
                            "required": ["imports", "imported_by_hints"],
                        },
                        "cross_file_insight": {"type": "STRING"},
                    },
                    "required": [
                        "language_stack_additions", "patterns_found", "shared_utilities",
                        "entry_point", "dependencies", "cross_file_insight",
                    ],
                },
            },
            "required": [
                "file_overview", "function_breakdown", "execution_flow", "design_decisions",
                "alternative_approaches", "algorithms", "error_handling", "performance_notes",
                "usage_examples", "sample_output", "dependency_graph", "notable_patterns",
                "potential_improvements", "system_role", "cross_file_context",
                "concurrency_and_state_risks", "risks_and_warnings", "context_update",
            ],
        }

        data = {
            "contents": [{"parts": [{"text": prompt}]}],
            "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
            "generationConfig": {
                "temperature": 0.2,
                "response_mime_type": "application/json",
                "response_schema": schema,
            },
        }

        try:
            resp = requests.post(url, json=data, timeout=90)
            if resp.status_code == 429:
                raise RateLimitError(f"Rate limited on: {label}")
            resp.raise_for_status()

            res_json = resp.json()
            raw_text = res_json["candidates"][0]["content"]["parts"][0]["text"]
            return json.loads(raw_text)
        except Exception as exc:
            if isinstance(exc, RateLimitError):
                raise exc
            return f"REST API error: {exc}"

    @staticmethod
    def _error_result(file_path: Path, relative_path: str, error: str) -> Dict[str, Any]:
        return {
            "file_path": file_path,
            "relative_path": relative_path,
            "language": "Unknown",
            "content": "",
            "html_sections": {},
            "context_update": {},
            "error": error,
        }
