"""
embedder.py — ChromaStore: persistent semantic memory for CodeReportAI.

Wraps ChromaDB with Gemini Embeddings REST API (gemini-embedding-001) to provide:
  - Per-file analysis storage with semantic vectors
  - RAG-style retrieval: "give me the most relevant prior analyses for this file"
  - Full-corpus retrieval for the Synthesis Agent

Collections:
  code_files        — one document per analysed source file
  project_insights  — cross-file synthesis records
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from rich.console import Console

console = Console()

_EMBED_MODEL = "models/gemini-embedding-001"
_EMBED_DIM = 768  # gemini-embedding-001 output dimension


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _gemini_embed(text: str, api_key: str, task_type: str = "RETRIEVAL_DOCUMENT") -> List[float]:
    """Call Gemini Embeddings REST API; return float vector. Returns [] on failure."""
    url = f"https://generativelanguage.googleapis.com/v1beta/{_EMBED_MODEL}:embedContent?key={api_key}"
    # Gemini embedding has a token limit; truncate aggressively if needed
    text = text[:8000]
    payload = {
        "model": _EMBED_MODEL,
        "content": {"parts": [{"text": text}]},
        "task_type": task_type,
    }
    try:
        resp = requests.post(url, json=payload, timeout=30)
        resp.raise_for_status()
        return resp.json()["embedding"]["values"]
    except Exception as exc:
        console.print(f"[yellow]Embed warning: {exc}[/yellow]")
        return []


def _batch_gemini_embed(
    pairs: List[Dict[str, str]],   # [{"text": ..., "task_type": ...}, ...]
    api_key: str,
) -> List[List[float]]:
    """Batch embedding via batchEmbedContents endpoint."""
    url = f"https://generativelanguage.googleapis.com/v1beta/{_EMBED_MODEL}:batchEmbedContents?key={api_key}"
    requests_list = [
        {
            "model": _EMBED_MODEL,
            "content": {"parts": [{"text": p["text"][:8000]}]},
            "task_type": p.get("task_type", "RETRIEVAL_DOCUMENT"),
        }
        for p in pairs
    ]
    payload = {"requests": requests_list}
    try:
        resp = requests.post(url, json=payload, timeout=60)
        resp.raise_for_status()
        return [e["values"] for e in resp.json()["embeddings"]]
    except Exception as exc:
        console.print(f"[yellow]Batch embed warning: {exc}[/yellow]")
        return [[] for _ in pairs]


def _build_doc_text(result: Dict[str, Any]) -> str:
    """Build a rich text representation of an analysis result for embedding."""
    sections = result.get("html_sections", {})
    parts = [
        f"FILE: {result.get('relative_path', '')}",
        f"LANGUAGE: {result.get('language', '')}",
        f"PURPOSE: {sections.get('file_overview', {}).get('purpose', '')}",
        f"SYSTEM_ROLE: {sections.get('system_role', '')}",
        "ALGORITHMS: " + "; ".join(a.get("name", "") for a in sections.get("algorithms", [])),
        "PATTERNS: " + "; ".join(sections.get("notable_patterns", [])),
        "IMPROVEMENTS: " + "; ".join(sections.get("potential_improvements", [])[:3]),
        "RISKS: " + "; ".join(
            r.get("description", "") for r in sections.get("risks_and_warnings", [])
        ),
        "CROSS_FILE: " + "; ".join(sections.get("cross_file_context", [])[:3]),
        "DESIGN: " + "; ".join(sections.get("design_decisions", [])[:3]),
        "IMPORTS: " + "; ".join(sections.get("file_overview", {}).get("key_imports", [])),
    ]
    return "\n".join(p for p in parts if p.split(": ", 1)[-1].strip())


# ---------------------------------------------------------------------------
# ChromaStore
# ---------------------------------------------------------------------------

class ChromaStore:
    """
    Persistent semantic store backed by ChromaDB.

    Lifecycle:
      1. `ChromaStore(db_dir)` — opens or creates the on-disk collection
      2. `embed_and_store(result, api_key)` — after each Worker completes
      3. `retrieve_relevant_context(...)` — before each Worker runs (RAG)
      4. `get_all_summaries()` — for the SynthesisAgent

    Falls back gracefully (returns empty strings / lists) when ChromaDB is
    unavailable or embeddings fail, so the rest of the pipeline is unaffected.
    """

    def __init__(self, db_dir: Path) -> None:
        self.db_dir = db_dir
        self._client = None
        self._code_col = None
        self._insights_col = None
        self._available = False
        self._init_db()

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _init_db(self) -> None:
        """Initialise ChromaDB client and collections. Safe to call multiple times."""
        try:
            import chromadb  # lazy import — keeps startup fast if not installed

            self.db_dir.mkdir(parents=True, exist_ok=True)
            self._client = chromadb.PersistentClient(path=str(self.db_dir))

            # Use cosine similarity — better for semantic search over text embeddings
            self._code_col = self._client.get_or_create_collection(
                name="code_files",
                metadata={"hnsw:space": "cosine"},
            )
            self._insights_col = self._client.get_or_create_collection(
                name="project_insights",
                metadata={"hnsw:space": "cosine"},
            )
            self._available = True
            console.print(
                f"[dim green]ChromaDB ready — {self._code_col.count()} file(s) in memory[/dim green]"
            )
        except ImportError:
            console.print(
                "[yellow]chromadb not installed — running without semantic memory. "
                "Install with: pip install chromadb[/yellow]"
            )
        except Exception as exc:
            console.print(f"[yellow]ChromaDB init failed ({exc}) — running without semantic memory[/yellow]")

    @property
    def available(self) -> bool:
        return self._available

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def embed_and_store(self, result: Dict[str, Any], api_key: str) -> bool:
        """
        Embed the analysis result and upsert into the code_files collection.

        Uses relative_path as the stable document ID so re-runs overwrite
        the old embedding rather than creating duplicates.

        Returns True on success, False on any failure (non-fatal).
        """
        if not self._available:
            return False

        relative_path = result.get("relative_path", "")
        if not relative_path:
            return False

        doc_text = _build_doc_text(result)
        if not doc_text.strip():
            return False

        embedding = _gemini_embed(doc_text, api_key, task_type="RETRIEVAL_DOCUMENT")
        if not embedding:
            return False

        sections = result.get("html_sections", {})
        metadata = {
            "relative_path": relative_path,
            "language": result.get("language", "Unknown"),
            "purpose": sections.get("file_overview", {}).get("purpose", "")[:500],
            "system_role": sections.get("system_role", "")[:500],
            "risk_count": len(sections.get("risks_and_warnings", [])),
            "algo_count": len(sections.get("algorithms", [])),
            "lines": sections.get("file_overview", {}).get("size_lines", 0),
        }

        try:
            self._code_col.upsert(
                ids=[relative_path],
                embeddings=[embedding],
                documents=[doc_text],
                metadatas=[metadata],
            )
            return True
        except Exception as exc:
            console.print(f"[yellow]ChromaDB upsert failed: {exc}[/yellow]")
            return False

    def store_insight(self, insight_id: str, text: str, api_key: str) -> bool:
        """Store a cross-file synthesis insight in the project_insights collection."""
        if not self._available:
            return False
        embedding = _gemini_embed(text, api_key, task_type="RETRIEVAL_DOCUMENT")
        if not embedding:
            return False
        try:
            self._insights_col.upsert(
                ids=[insight_id],
                embeddings=[embedding],
                documents=[text],
            )
            return True
        except Exception as exc:
            console.print(f"[yellow]ChromaDB insight store failed: {exc}[/yellow]")
            return False

    # ------------------------------------------------------------------
    # Read / RAG
    # ------------------------------------------------------------------

    def retrieve_relevant_context(
        self,
        query_text: str,
        api_key: str,
        n_results: int = 5,
        exclude_path: Optional[str] = None,
    ) -> str:
        """
        Embed *query_text* and return the top-N most semantically similar
        prior file analyses as a formatted string (for injection into prompts).

        *exclude_path* prevents a file from matching itself.
        """
        if not self._available or self._code_col.count() == 0:
            return ""

        embedding = _gemini_embed(query_text, api_key, task_type="RETRIEVAL_QUERY")
        if not embedding:
            return ""

        try:
            # Fetch n+1 so we can drop the excluded path if present
            fetch_n = min(n_results + 1, self._code_col.count())
            res = self._code_col.query(
                query_embeddings=[embedding],
                n_results=fetch_n,
                include=["documents", "metadatas", "distances"],
            )
        except Exception as exc:
            console.print(f"[yellow]ChromaDB query failed: {exc}[/yellow]")
            return ""

        docs = res.get("documents", [[]])[0]
        metas = res.get("metadatas", [[]])[0]
        distances = res.get("distances", [[]])[0]

        lines: List[str] = []
        count = 0
        for doc, meta, dist in zip(docs, metas, distances):
            if exclude_path and meta.get("relative_path") == exclude_path:
                continue
            if count >= n_results:
                break
            similarity = round(1.0 - dist, 3)  # cosine: distance → similarity
            lines.append(
                f"--- RELATED FILE (similarity={similarity}) ---\n"
                f"PATH: {meta.get('relative_path', '?')}\n"
                f"LANGUAGE: {meta.get('language', '?')}\n"
                f"{doc[:600]}\n"
            )
            count += 1

        return "\n".join(lines) if lines else ""

    def query(
        self,
        question_embedding: List[float],
        n_results: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Low-level query by pre-computed embedding. Returns list of
        {path, language, purpose, document, distance} dicts.
        Used by the CLI `query` subcommand.
        """
        if not self._available or self._code_col.count() == 0:
            return []
        try:
            fetch_n = min(n_results, self._code_col.count())
            res = self._code_col.query(
                query_embeddings=[question_embedding],
                n_results=fetch_n,
                include=["documents", "metadatas", "distances"],
            )
            results = []
            for doc, meta, dist in zip(
                res["documents"][0], res["metadatas"][0], res["distances"][0]
            ):
                results.append({
                    "path": meta.get("relative_path", ""),
                    "language": meta.get("language", ""),
                    "purpose": meta.get("purpose", ""),
                    "document": doc,
                    "similarity": round(1.0 - dist, 3),
                })
            return results
        except Exception as exc:
            console.print(f"[yellow]ChromaDB query error: {exc}[/yellow]")
            return []

    # ------------------------------------------------------------------
    # Bulk retrieval (for Synthesis Agent)
    # ------------------------------------------------------------------

    def get_all_summaries(self) -> List[Dict[str, Any]]:
        """
        Return all stored file summaries (documents + metadata).
        Used by SynthesisAgent to build a global codebase picture.
        """
        if not self._available or self._code_col.count() == 0:
            return []
        try:
            res = self._code_col.get(include=["documents", "metadatas"])
            out = []
            for doc, meta in zip(res.get("documents", []), res.get("metadatas", [])):
                out.append({"document": doc, "metadata": meta})
            return out
        except Exception as exc:
            console.print(f"[yellow]ChromaDB get_all failed: {exc}[/yellow]")
            return []

    def count(self) -> int:
        """Return the number of stored file analyses."""
        if not self._available:
            return 0
        try:
            return self._code_col.count()
        except Exception:
            return 0
