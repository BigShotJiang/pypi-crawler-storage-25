"""
html_renderer.py — Renders Jinja2 templates into final HTML reports.

Updated: render_index now accepts an optional `synthesis` dict from
SynthesisAgent and passes it to the index template.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional
from jinja2 import Environment, FileSystemLoader, select_autoescape

_TEMPLATES_DIR = Path(__file__).parent / "templates"
_TEMPLATE_NAME = "report.html.j2"


def render_report(result: Dict[str, Any]) -> str:
    """
    Take the dictionary from worker.py and render it using Jinja2.
    """
    sections = result.get("html_sections", {})
    error = result.get("error")
    relative_path = result["relative_path"]

    # Pre-compute values so the template doesn't need Jinja2 string manipulation
    norm_path = relative_path.replace("\\", "/")
    filename = norm_path.split("/")[-1]
    depth = len(norm_path.split("/")) - 1
    back_url = "../" * depth + "codereportai.html"

    template_data = {
        "relative_path":          relative_path,
        "filename":               filename,
        "back_url":               back_url,
        "language":               result.get("language", "Unknown"),

        # Parsed sections (with safe defaults)
        "file_overview":          sections.get("file_overview", {}),
        "function_breakdown":     sections.get("function_breakdown", []),
        "execution_flow":         sections.get("execution_flow", []),
        "design_decisions":       sections.get("design_decisions", []),
        "alternative_approaches": sections.get("alternative_approaches", []),
        "algorithms":             sections.get("algorithms", []),
        "error_handling":         sections.get("error_handling", []),
        "performance_notes":      sections.get("performance_notes", []),
        "usage_examples":         sections.get("usage_examples", []),
        "sample_output":          sections.get("sample_output", []),
        "dependency_graph":       sections.get("dependency_graph", []),
        "notable_patterns":       sections.get("notable_patterns", []),
        "potential_improvements": sections.get("potential_improvements", []),
        "system_role":            sections.get("system_role", ""),
        "cross_file_context":     sections.get("cross_file_context", []),
        "concurrency_and_state_risks": sections.get("concurrency_and_state_risks", []),
        "risks_and_warnings":     sections.get("risks_and_warnings", []),

        "error": error,
    }

    try:
        env = _get_env()
        template = env.get_template(_TEMPLATE_NAME)
        return template.render(**template_data)
    except Exception as exc:
        return f"<html><body><h1>Template Error</h1><p>{exc}</p></body></html>"


def render_index(
    results: List[Dict[str, Any]],
    root: Path,
    stats: Dict[str, Any],
    synthesis: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Render a central dashboard index reflecting the project structure and smart metrics.

    Args:
        results:   List of worker result dicts.
        root:      Project root path.
        stats:     Run statistics (processed, skipped, errors, etc.).
        synthesis: Optional dict from SynthesisAgent — injected into the dashboard.
    """
    tree: Dict[str, Any] = {}
    high_risk_files = []
    complex_files = []
    error_prone_files = []
    error_files = []

    # Global Insight Aggregation
    all_patterns: Dict[str, int] = {}
    all_risks_count = {"high": 0, "medium": 0, "low": 0}
    all_langs: Dict[str, int] = {}

    for res in results:
        f = res["file_path"]
        sections = res.get("html_sections", {})
        err = res.get("error")
        # Extract metadata
        risks = sections.get("risks_and_warnings", [])
        algos = sections.get("algorithms", [])
        lines = sections.get("file_overview", {}).get("size_lines", 0)
        err_notes = sections.get("error_handling", [])
        lang = res.get("language", "Unknown")
        patterns = sections.get("notable_patterns", [])

        # Aggregate insights
        all_langs[lang] = all_langs.get(lang, 0) + 1
        for p in patterns:
            all_patterns[p] = all_patterns.get(p, 0) + 1
        for r in risks:
            sev = str(r.get("severity", "")).lower()
            if sev in all_risks_count:
                all_risks_count[sev] += 1

        try:
            rel = f.relative_to(root)
        except ValueError:
            rel = f

        parts = rel.parts
        current = tree
        rel_html_posix = rel.with_suffix(".html").as_posix()

        # Analyze Smart Metrics
        if err:
            error_files.append({"path": str(rel), "url": rel_html_posix, "error": err})
        else:
            # High Risk
            high_risks = [r for r in risks if str(r.get("severity", "")).lower() == "high"]
            if high_risks:
                high_risk_files.append(
                    {"path": str(rel), "url": rel_html_posix, "count": len(high_risks)}
                )

            # Complex
            if len(algos) > 2 or lines > 400:
                complex_files.append(
                    {"path": str(rel), "url": rel_html_posix, "algos": len(algos), "lines": lines}
                )

            # Error Prone (many error handling notes or risks)
            if len(err_notes) > 5 or len(risks) > 4:
                error_prone_files.append(
                    {"path": str(rel), "url": rel_html_posix, "notes": len(err_notes)}
                )

        for i, part in enumerate(parts):
            if i == len(parts) - 1:
                current[part] = {"__type__": "file", "url": rel_html_posix}
            else:
                if part not in current:
                    current[part] = {}
                current = current[part]

    # Finalize Global Insights
    project_summary = {
        "top_langs": sorted(all_langs.items(), key=lambda x: x[1], reverse=True)[:3],
        "top_patterns": sorted(all_patterns.items(), key=lambda x: x[1], reverse=True)[:5],
        "risk_tally": all_risks_count,
    }

    try:
        env = _get_env()
        template = env.get_template("index.html.j2")
        return template.render(
            tree=tree,
            project_name=root.name,
            stats=stats,
            project_summary=project_summary,
            high_risk_files=high_risk_files,
            complex_files=complex_files,
            error_prone_files=error_prone_files,
            error_files=error_files,
            synthesis=synthesis or {},
        )
    except Exception as exc:
        return f"<html><body><h1>Error rendering index</h1><p>{exc}</p></body></html>"


def _get_env():
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATES_DIR)),
        autoescape=select_autoescape(["html", "xml"]),
    )
    # Jinja2 doesn't include a split filter — add it
    env.filters["split"] = lambda value, sep="/": value.split(sep)
    return env
