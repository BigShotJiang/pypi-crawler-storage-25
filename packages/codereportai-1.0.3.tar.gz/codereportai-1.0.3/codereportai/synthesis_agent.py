"""
synthesis_agent.py — Post-run project-wide analysis agent.

After all per-file Workers complete, the SynthesisAgent pulls every stored
analysis from ChromaDB, sends them in a single "principal architect" prompt,
and produces a comprehensive project intelligence report covering:

  • project_narrative         — what the project is, why it exists, how it works
  • architecture_overview     — layer/module breakdown, data flow, boundaries
  • algorithm_catalog         — every significant algorithm found, with complexity
  • critical_paths            — files whose failure breaks the system
  • tech_debt_hotspots        — concrete issues with severity + file reference
  • improvement_roadmap       — ordered action list with impact estimates
  • security_surface          — cross-file security risks
  • integration_guide         — how to add new features / hook into the system
  • algorithm_recommendations — new algorithms that would improve the project
  • dependency_clusters       — logical module groupings

Output is saved to {output_root}/synthesis.json.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Synthesis Agent
# ---------------------------------------------------------------------------

class SynthesisAgent:
    """Generates a project-wide intelligence report using all file analyses."""

    def __init__(
        self,
        output_root: Path,
        api_key: str,
        model_name: str = "gemma-4-31b-it",
        chroma_store=None,
    ) -> None:
        self.output_root = output_root
        self.api_key = api_key
        self.model_name = model_name
        self.chroma_store = chroma_store

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(self, all_results: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        Collect all analysis summaries, call Gemini once, and save synthesis.json.

        Returns the synthesis dict on success, None on failure.
        """
        summaries = self._collect_summaries(all_results)
        if not summaries:
            logger.warning("SynthesisAgent: no summaries to synthesise.")
            return None

        logger.info(f"SynthesisAgent: synthesising {len(summaries)} file analyses…")

        prompt = self._build_prompt(summaries)
        raw    = self._call_gemini(prompt)
        if not raw:
            return None

        synthesis = self._parse_response(raw)
        if synthesis:
            out_path = self.output_root / "synthesis.json"
            out_path.write_text(json.dumps(synthesis, indent=2, ensure_ascii=False), encoding="utf-8")
            logger.info(f"SynthesisAgent: saved → {out_path}")

        return synthesis

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _collect_summaries(self, all_results: List[Dict[str, Any]]) -> List[str]:
        """
        Prefer ChromaDB stored summaries (they include embedding metadata).
        Fall back to building compact summaries from raw Worker results.
        """
        # ChromaDB path
        if self.chroma_store and getattr(self.chroma_store, "available", False):
            try:
                stored = self.chroma_store.get_all_summaries()  # list[str]
                if stored:
                    return stored
            except Exception as exc:
                logger.debug(f"ChromaDB summary fetch failed: {exc}")

        # Fallback: build from raw results
        summaries: List[str] = []
        for res in all_results:
            if res.get("error"):
                continue
            sec = res.get("html_sections", {})
            ov  = sec.get("file_overview", {})
            algos = sec.get("algorithms", [])
            algo_text = ""
            if algos:
                algo_text = "  Algorithms: " + ", ".join(
                    f"{a.get('name','?')} [{a.get('time_complexity','?')}]" for a in algos
                )
            patterns = sec.get("notable_patterns", [])
            risks    = sec.get("risks_and_warnings", [])
            funcs    = [f.get("signature","") for f in sec.get("function_breakdown", [])]

            summary = (
                f"FILE: {res.get('relative_path','?')}\n"
                f"  Language: {res.get('language','?')}\n"
                f"  Purpose: {ov.get('purpose','?')}\n"
                f"  Lines: {ov.get('size_lines','?')}\n"
                f"  Functions: {', '.join(funcs[:6])}\n"
                f"{algo_text}\n"
                f"  Patterns: {', '.join(patterns[:4])}\n"
                f"  Risks: {len(risks)} ({', '.join(r.get('severity','?') for r in risks[:3])})\n"
                f"  System role: {sec.get('system_role','?')[:180]}"
            )
            summaries.append(summary)

        return summaries

    def _build_prompt(self, summaries: List[str]) -> str:
        # Limit total token budget: 200 summaries × ~400 chars ≈ 80k chars
        combined = "\n\n---\n\n".join(summaries[:200])

        return f"""You are a PRINCIPAL SOFTWARE ARCHITECT performing a full technical audit of a codebase.

Below are AI-generated analysis summaries for every file in the project.
Your task is to synthesise them into a **comprehensive, expert-level intelligence report**.

FILE ANALYSES:
{combined}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REQUIRED OUTPUT — reply with ONLY valid JSON matching this EXACT schema:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{{
  "summary_one_liner": "One punchy sentence describing the project.",

  "project_narrative": "3–5 paragraph detailed explanation: what the project does, why it was built, the architectural philosophy, how the major components interact, and what engineering problem it solves. This should read like a well-written technical blog post intro.",

  "language_stack": ["Python", "JavaScript"],

  "architecture_overview": "2–3 paragraph description of the system architecture: layers, data flow, entry points, module boundaries, key abstractions.",

  "algorithm_catalog": [
    {{
      "name": "Algorithm name (e.g. BFS, Trie lookup, Round-robin, SHA-256 hashing)",
      "category": "one of: graph, sorting, search, hashing, scheduling, ML, string, compression, concurrency, other",
      "file": "path/to/file.py",
      "function": "function_name_where_it_lives",
      "description": "Detailed explanation of how this algorithm works in this specific context.",
      "purpose": "Why this algorithm was chosen for this task.",
      "time_complexity": "O(N log N)",
      "space_complexity": "O(N)",
      "why_chosen": "Why this is better than the alternatives for this use case.",
      "alternatives_considered": ["Alternative A — reason rejected", "Alternative B — reason rejected"]
    }}
  ],

  "critical_paths": [
    {{"path": "relative/path.py", "reason": "Why failure here breaks the system."}}
  ],

  "tech_debt_hotspots": [
    {{"file": "relative/path.py", "issue": "Specific technical debt issue.", "severity": "high|medium|low", "effort": "hours|days|weeks"}}
  ],

  "improvement_roadmap": [
    {{
      "priority": 1,
      "action": "Concrete improvement action.",
      "impact": "What this unlocks or fixes.",
      "files_affected": ["file1.py", "file2.py"],
      "effort": "1–2 days"
    }}
  ],

  "security_surface": [
    {{"risk": "Specific security concern.", "severity": "high|medium|low", "files": ["file.py"]}}
  ],

  "integration_guide": {{
    "overview": "2–3 sentences on how the system is designed for extension.",
    "steps_to_add_new_feature": [
      "Step 1: ...",
      "Step 2: ...",
      "Step 3: ..."
    ],
    "extension_points": [
      {{"name": "ClassName or interface", "file": "path.py", "how": "Subclass / implement / register to add new behaviour."}}
    ],
    "key_abstractions": [
      {{"name": "AbstractName", "file": "path.py", "purpose": "What it provides."}}
    ]
  }},

  "algorithm_recommendations": [
    {{
      "name": "Recommended algorithm (e.g. Bloom filter for deduplication)",
      "problem_it_solves": "Current limitation or bottleneck it addresses.",
      "implementation_hint": "Concrete advice on how and where to add it.",
      "files_to_modify": ["file.py"],
      "expected_improvement": "e.g. 10× faster lookup, 50% memory reduction",
      "priority": "high|medium|low"
    }}
  ],

  "dependency_clusters": [
    {{"name": "Cluster name (e.g. API Layer)", "files": ["file1.py", "file2.py"], "purpose": "What this cluster does."}}
  ]
}}

RULES:
- Output ONLY the JSON object. No markdown fences, no preamble, no commentary.
- Be highly specific — cite actual file names, function names, and algorithm names from the analyses.
- algorithm_catalog must include EVERY significant algorithm found, not just obvious ones.
- integration_guide must give genuinely actionable, file-specific guidance.
- algorithm_recommendations must be realistic and specific to THIS codebase's needs.
"""

    def _call_gemini(self, prompt: str) -> Optional[str]:
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model_name}:generateContent?key={self.api_key}"
        )
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": 0.1,
                "maxOutputTokens": 8192,
            },
        }
        try:
            resp = requests.post(url, json=payload, timeout=120)
            resp.raise_for_status()
            data = resp.json()
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as exc:
            logger.error(f"SynthesisAgent Gemini call failed: {exc}")
            return None

    def _parse_response(self, raw: str) -> Optional[Dict[str, Any]]:
        """Extract and parse JSON from Gemini response."""
        text = raw.strip()

        # Strip markdown code fences if model added them
        if text.startswith("```"):
            lines = text.split("\n")
            # drop first and last fence lines
            text = "\n".join(
                line for line in lines
                if not line.strip().startswith("```")
            ).strip()

        # Find first { and last } for robustness
        start = text.find("{")
        end   = text.rfind("}") + 1
        if start == -1 or end == 0:
            logger.error("SynthesisAgent: no JSON object found in response.")
            logger.debug(f"Raw response: {raw[:500]}")
            return None

        json_str = text[start:end]
        try:
            return json.loads(json_str)
        except json.JSONDecodeError as exc:
            logger.error(f"SynthesisAgent JSON parse error: {exc}")
            logger.debug(f"JSON attempted: {json_str[:500]}")
            return None
