"""
scanner.py — Recursively discovers source files to analyze.

Skips: binary files, images, lock files, compiled outputs, and
the CodeReportAi/ output directory itself.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import List

import io
import sys

from rich.console import Console

# Force UTF-8 output on Windows so paths with non-ASCII characters don't crash.
# Falls back to a safe replacement character ('?') if the terminal truly can't handle it.
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass

console = Console(stderr=False, highlight=False)


def _safe(path: Path, root: Path | None = None) -> str:
    """Return a path string that is safe to print on any Windows terminal."""
    try:
        s = str(path.relative_to(root)) if root else str(path)
    except ValueError:
        s = str(path)
    return s.encode("ascii", errors="replace").decode("ascii")

# ---------------------------------------------------------------------------
# Skip-lists
# ---------------------------------------------------------------------------

SKIP_DIRS: set[str] = {
    "CodeReportAi",
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "dist",
    "build",
    ".venv",
    "venv",
    "env",
    ".tox",
    "coverage",
    ".next",
    ".nuxt",
    "out",
    ".output",
    "target",          # Rust / Maven
    "vendor",          # Go / PHP
    "Pods",            # iOS CocoaPods
    ".gradle",
    ".idea",
    ".vscode",
    "__MACOSX",
}

SKIP_EXTENSIONS: set[str] = {
    # Compiled / binary
    ".pyc", ".pyo", ".pyd",
    ".class", ".jar", ".war", ".ear",
    ".o", ".a", ".so", ".dll", ".lib", ".exe",
    ".wasm",
    # Archives
    ".zip", ".tar", ".gz", ".bz2", ".xz", ".7z", ".rar",
    # Images
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg", ".webp",
    ".tiff", ".tif", ".avif", ".heic",
    # Fonts
    ".ttf", ".otf", ".woff", ".woff2", ".eot",
    # Audio / video
    ".mp3", ".mp4", ".wav", ".ogg", ".flac", ".avi", ".mov", ".mkv", ".webm",
    # Documents / data blobs
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".db", ".sqlite", ".sqlite3",
    # Lock files (large, machine-generated)
    ".lock",
    # Maps
    ".map",
}

SKIP_FILENAMES: set[str] = {
    "package-lock.json",
    "yarn.lock",
    "poetry.lock",
    "Pipfile.lock",
    "composer.lock",
    "Gemfile.lock",
    "pnpm-lock.yaml",
    "bun.lockb",
    ".DS_Store",
    "Thumbs.db",
    ".gitignore",
    ".gitattributes",
    ".editorconfig",
    ".npmrc",
    ".yarnrc",
    ".prettierignore",
    ".eslintignore",
    "CNAME",
    "LICENSE",
    "LICENCE",
}

# Max file size: ~120 KB (proxy for ~30,000 tokens)
MAX_FILE_BYTES: int = 120_000


def _is_binary(path: Path) -> bool:
    """
    Quick binary detection by reading the first 8 KB.

    Strategy (in order):
      1. NULL bytes  -> definitely binary
      2. UTF-8 decode succeeds -> text
      3. latin-1 / cp1252 passthrough -> treat as text (covers many Windows files)
      4. Anything else  -> binary
    """
    try:
        with open(path, "rb") as f:
            chunk = f.read(8192)
        # NULL bytes are the most reliable binary marker
        if b"\x00" in chunk:
            return True
        # Try UTF-8 first
        try:
            chunk.decode("utf-8")
            return False
        except UnicodeDecodeError:
            pass
        # Fall back to latin-1 (covers most Windows / legacy source files)
        try:
            chunk.decode("latin-1")
            return False
        except UnicodeDecodeError:
            pass
        return True
    except OSError:
        return True


def scan_files(root: Path, verbose: bool = True) -> List[Path]:
    """
    Walk *root* recursively and return a sorted list of source files to analyse.

    Sorting strategy:
      1. Shallower paths first (entry points tend to live at the root)
      2. Priority filenames (main.*, index.*, app.*, __init__.*) within each depth
    """
    results: List[Path] = []
    root = root.resolve()
    dir_count = 0
    skipped_binary = 0
    skipped_size = 0
    skipped_ext = 0

    console.print(f"[dim]Scanning root...[/dim]")

    for dirpath_str, dirnames, filenames in os.walk(root, topdown=True):
        dirpath = Path(dirpath_str)
        rel_dir = dirpath.relative_to(root)

        # Show which directory we are entering
        if verbose and str(rel_dir) != ".":
            console.print(f"[dim]  -> {_safe(rel_dir)}[/dim]")

        dir_count += 1

        # Prune directories in-place so os.walk won't descend into them.
        # NOTE: we only skip well-known tool/artifact dirs — NOT all hidden dirs.
        # Hidden source dirs (e.g. .github) are intentionally kept.
        before = list(dirnames)
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        pruned = set(before) - set(dirnames)
        if pruned and verbose:
            for p in sorted(pruned):
                console.print(f"[dim]     [skip dir] {p}[/dim]")

        for fname in filenames:
            fpath = dirpath / fname

            # Skip by exact filename
            if fname in SKIP_FILENAMES:
                skipped_ext += 1
                continue

            # Skip by extension
            ext = fpath.suffix.lower()
            name_lower = fname.lower()
            if ext in SKIP_EXTENSIONS:
                skipped_ext += 1
                continue
            # Compound extensions: .min.js  .min.css
            if name_lower.endswith(".min.js") or name_lower.endswith(".min.css"):
                skipped_ext += 1
                continue

            # Skip oversized files
            try:
                size = fpath.stat().st_size
            except OSError:
                continue

            if size > MAX_FILE_BYTES:
                console.print(
                    f"[yellow]SKIP (too large {size // 1024} KB): "
                    f"{_safe(fpath, root)}[/yellow]"
                )
                skipped_size += 1
                continue

            if size == 0:
                continue

            # Skip binary files
            if _is_binary(fpath):
                skipped_binary += 1
                continue

            results.append(fpath)

    # ---------------------------------------------------------------
    # Summary
    # ---------------------------------------------------------------
    console.print(
        f"[bold green]Scan complete:[/bold green] "
        f"{len(results)} file(s) found across {dir_count} director(ies). "
        f"[dim]Skipped: {skipped_ext} by type, "
        f"{skipped_size} oversized, "
        f"{skipped_binary} binary.[/dim]"
    )

    # Sort: (depth, not-priority, name)
    priority_stems = {"main", "index", "app", "server", "cli", "__init__", "__main__"}

    def sort_key(p: Path) -> tuple:
        depth = len(p.relative_to(root).parts)
        is_priority = 0 if p.stem.lower() in priority_stems else 1
        return (depth, is_priority, p.name.lower())

    results.sort(key=sort_key)
    return results
