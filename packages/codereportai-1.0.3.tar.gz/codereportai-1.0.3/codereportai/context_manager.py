"""
context_manager.py — Global shared codebase context.

Accumulates cross-file intelligence as worker agents complete.
Persisted to CodeReportAi/context.json after each update.

ChromaDB integration: when a ChromaStore is attached, summary_for_prompt()
performs RAG retrieval — returning the *semantically closest* prior analyses
instead of an arbitrary last-20 truncated JSON blob.
"""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, TYPE_CHECKING

if TYPE_CHECKING:
    from .embedder import ChromaStore


# ---------------------------------------------------------------------------
# Default schema
# ---------------------------------------------------------------------------

def _empty_context() -> Dict[str, Any]:
    return {
        "project_language_stack": [],
        "processed_files": [],
        "common_patterns": [],
        "shared_utilities": [],
        "entry_points": [],
        "dependency_graph": {},
        "cross_file_insights": [],
    }


class ContextManager:
    """
    Thread-safe store for the global codebase context.

    Two modes:
      • RAG mode (ChromaStore attached): summary_for_prompt() does a
        semantic similarity query against ChromaDB, giving each file the
        most *relevant* prior context rather than the last-N arbitrary entries.

      • Flat mode (no ChromaStore): falls back to truncated JSON snapshot
        (legacy behaviour, still works without chromadb installed).
    """

    def __init__(self) -> None:
        self._ctx: Dict[str, Any] = _empty_context()
        self._lock = threading.Lock()
        self._processed_set: Set[str] = set()
        self._chroma: Optional["ChromaStore"] = None

    # ------------------------------------------------------------------
    # ChromaDB attachment (called by Supervisor after init)
    # ------------------------------------------------------------------

    def attach_chroma(self, chroma: "ChromaStore") -> None:
        """Wire in a ChromaStore for RAG-based context retrieval."""
        self._chroma = chroma

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def load(self, context_path: Path) -> None:
        """Load an existing context.json (resume mode)."""
        if not context_path.exists():
            return
        try:
            with open(context_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            with self._lock:
                self._ctx.update(data)
                self._processed_set = set(self._ctx.get("processed_files", []))
        except (json.JSONDecodeError, OSError) as exc:
            print(f"[warning] Could not load context.json: {exc}. Starting fresh.")

    def save(self, context_path: Path) -> None:
        """Atomically write the current context to disk."""
        context_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = context_path.with_suffix(".json.tmp")
        with self._lock:
            snapshot = json.dumps(self._ctx, indent=2, ensure_ascii=False)
        try:
            tmp.write_text(snapshot, encoding="utf-8")
            tmp.replace(context_path)
        except OSError:
            pass  # non-fatal

    # ------------------------------------------------------------------
    # State queries
    # ------------------------------------------------------------------

    def is_processed(self, file_path: Path | str) -> bool:
        """Return True if this file has already been analysed."""
        key = str(file_path)
        with self._lock:
            return key in self._processed_set

    def snapshot(self) -> Dict[str, Any]:
        """Return a deep copy of the current context (safe to serialise)."""
        with self._lock:
            return json.loads(json.dumps(self._ctx))

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def mark_processed(self, file_path: Path | str) -> None:
        """Record that a file has been successfully processed."""
        key = str(file_path)
        with self._lock:
            if key not in self._processed_set:
                self._processed_set.add(key)
                self._ctx["processed_files"].append(key)

    def update(self, context_update: Dict[str, Any], file_path: Path | str) -> None:
        """
        Merge a Worker's context_update payload into the global context.

        Expected keys in *context_update* (all optional):
          language_stack_additions: list[str]
          patterns_found:           list[str]
          shared_utilities:         list[str]
          entry_point:              bool
          dependencies:             dict  (stored in dependency_graph)
          cross_file_insight:       str   (free-text insight)
        """
        if not context_update:
            return

        with self._lock:
            # Language stack
            for lang in context_update.get("language_stack_additions", []):
                if lang and lang not in self._ctx["project_language_stack"]:
                    self._ctx["project_language_stack"].append(lang)

            # Common patterns
            for pat in context_update.get("patterns_found", []):
                if pat and pat not in self._ctx["common_patterns"]:
                    self._ctx["common_patterns"].append(pat)

            # Shared utilities
            for util in context_update.get("shared_utilities", []):
                if util and util not in self._ctx["shared_utilities"]:
                    self._ctx["shared_utilities"].append(util)

            # Entry points
            if context_update.get("entry_point"):
                fp = str(file_path)
                if fp not in self._ctx["entry_points"]:
                    self._ctx["entry_points"].append(fp)

            # Dependency graph
            deps = context_update.get("dependencies")
            if deps:
                self._ctx["dependency_graph"][str(file_path)] = deps

            # Free-text cross-file insight
            insight = context_update.get("cross_file_insight")
            if insight:
                self._ctx["cross_file_insights"].append(
                    {"file": str(file_path), "insight": insight}
                )

    # ------------------------------------------------------------------
    # Context for prompts — RAG-aware
    # ------------------------------------------------------------------

    def summary_for_prompt(
        self,
        file_path: Optional[str] = None,
        language: Optional[str] = None,
        content_snippet: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> str:
        """
        Return context suitable for injection into a Gemini prompt.

        RAG mode (ChromaStore available + api_key provided):
          Embeds a query built from the current file's path/language/snippet
          and retrieves the most semantically similar prior analyses.

        Flat mode (fallback):
          Returns a compact JSON snapshot (last 20 insights, last 30 dep entries).
        """
        # ── RAG mode ──────────────────────────────────────────────────
        if self._chroma and self._chroma.available and api_key and self._chroma.count() > 0:
            query_parts = []
            if file_path:
                query_parts.append(f"FILE: {file_path}")
            if language:
                query_parts.append(f"LANGUAGE: {language}")
            if content_snippet:
                # Use first 400 chars as the semantic anchor
                query_parts.append(f"CONTENT PREVIEW:\n{content_snippet[:400]}")

            query_text = "\n".join(query_parts) if query_parts else "general codebase context"

            rag_context = self._chroma.retrieve_relevant_context(
                query_text=query_text,
                api_key=api_key,
                n_results=5,
                exclude_path=file_path,
            )
            if rag_context:
                # Also prepend a brief global summary (language stack, entry points)
                with self._lock:
                    stack = self._ctx.get("project_language_stack", [])
                    entries = self._ctx.get("entry_points", [])
                    patterns = self._ctx.get("common_patterns", [])[:5]

                global_header = (
                    f"GLOBAL CONTEXT:\n"
                    f"  Language stack: {', '.join(stack) or 'not yet determined'}\n"
                    f"  Entry points: {', '.join(entries) or 'none identified yet'}\n"
                    f"  Common patterns: {', '.join(patterns) or 'none yet'}\n\n"
                    f"SEMANTICALLY RELEVANT PRIOR ANALYSES (via ChromaDB RAG):\n"
                )
                return global_header + rag_context

        # ── Flat mode (fallback) ───────────────────────────────────────
        return self._flat_summary()

    def _flat_summary(self) -> str:
        """Legacy compact JSON snapshot — capped to avoid huge prompts."""
        snap = self.snapshot()
        snap["cross_file_insights"] = snap["cross_file_insights"][-20:]
        if len(snap["dependency_graph"]) > 30:
            keys = list(snap["dependency_graph"])[-30:]
            snap["dependency_graph"] = {k: snap["dependency_graph"][k] for k in keys}
        return json.dumps(snap, indent=2, ensure_ascii=False)
