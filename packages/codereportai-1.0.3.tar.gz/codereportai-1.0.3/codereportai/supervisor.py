"""
supervisor.py — Supervisor Agent (Orchestrator).

Upgraded with:
  - ChromaStore initialisation and attachment to ContextManager
  - Async (thread-pool) embedding after each successful Worker run
  - SynthesisAgent call at the end of the pipeline
  - RAG-based context retrieval passed into each Worker
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from pathlib import Path
from typing import List, Optional, Any, Dict

from rich.console import Console
from rich.progress import (
    Progress, SpinnerColumn, BarColumn,
    TaskProgressColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn,
)
from rich.panel import Panel

from .api_manager import APIManager, NoKeysAvailableError
from .context_manager import ContextManager
from .embedder import ChromaStore
from .html_renderer import render_report
from .synthesis_agent import SynthesisAgent
from .worker import Worker, RateLimitError

console = Console()

MAX_RETRIES = 3
RETRY_DELAY = 2.0


class Supervisor:
    def __init__(
        self,
        root: Path,
        output_root: Path,
        api_manager: APIManager,
        ctx_manager: ContextManager,
        model_name: str = "gemma-4-31b-it",
        concurrency: int = 4,
        resume: bool = False,
        use_chroma: bool = True,
    ) -> None:
        self.root = root
        self.output_root = output_root
        self.api_manager = api_manager
        self.ctx_manager = ctx_manager
        self.model_name = model_name
        self.concurrency = concurrency
        self.resume = resume
        self.context_path = output_root / "context.json"

        self._worker = Worker(model_name=model_name)
        self._stats = {
            "processed": 0,
            "skipped": 0,
            "errors": 0,
            "total_lines": 0,
            "complexity_score": 0,
        }
        self._parsed_results: List[Dict[str, Any]] = []

        # ── ChromaStore ────────────────────────────────────────────────
        self._chroma: Optional[ChromaStore] = None
        if use_chroma:
            chroma_dir = output_root / "chroma_store"
            self._chroma = ChromaStore(db_dir=chroma_dir)
            # Wire ChromaStore into ContextManager so RAG works
            self.ctx_manager.attach_chroma(self._chroma)

        # Dedicated thread pool for async embedding (non-blocking)
        self._embed_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="embed")

    # ------------------------------------------------------------------
    # Main run loop
    # ------------------------------------------------------------------

    def run(self, file_list: List[Path]) -> None:
        to_process: List[Path] = []
        for fp in file_list:
            if self.resume and self.ctx_manager.is_processed(fp):
                self._stats["skipped"] += 1
            else:
                to_process.append(fp)

        total = len(to_process)
        skipped = self._stats["skipped"]
        chroma_indicator = (
            "[green]ChromaDB ON[/green]" if (self._chroma and self._chroma.available)
            else "[yellow]ChromaDB OFF[/yellow]"
        )
        console.print(
            Panel(
                f"[bold cyan]Files to analyse:[/bold cyan] {total}  "
                f"[dim](skipped {skipped} already processed)[/dim]  "
                f"{chroma_indicator}",
                title="[bold]CodeReportAI — Starting Analysis[/bold]",
                border_style="cyan",
            )
        )

        if total == 0:
            console.print("[green]All files already processed. Use --no-resume to reprocess.[/green]")
            return

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
            transient=False,
        ) as progress:
            task_id = progress.add_task("Analysing files...", total=total)
            with ThreadPoolExecutor(max_workers=self.concurrency) as executor:
                future_map: dict[Future, Path] = {
                    executor.submit(self._process_file_with_retry, fp): fp
                    for fp in to_process
                }
                for future in as_completed(future_map):
                    fp = future_map[future]
                    try:
                        result = future.result()
                    except Exception as exc:
                        console.print(f"[red]Unhandled error for {fp.name}: {exc}[/red]")
                        self._stats["errors"] += 1
                        result = None

                    if result and not result.get("error"):
                        self._on_success(result)
                    elif result and result.get("error"):
                        console.print(
                            f"[red]FAIL {result['relative_path']}: {result['error']}[/red]"
                        )
                        self._stats["errors"] += 1

                    self.api_manager.advance()
                    progress.advance(task_id)

        # Wait for all pending embed jobs to settle
        self._embed_executor.shutdown(wait=True)

        # ── Synthesis Agent ────────────────────────────────────────────
        if self._parsed_results:
            api_key = self._safe_get_key()
            if api_key:
                agent = SynthesisAgent(
                    model_name=self.model_name,
                    output_root=self.output_root,
                )
                synthesis = agent.run(
                    chroma_store=self._chroma,
                    api_key=api_key,
                    fallback_results=self._parsed_results,
                )
            else:
                synthesis = {}
                console.print("[yellow]No API key available for Synthesis Agent.[/yellow]")
        else:
            synthesis = {}

        # ── Generate INDEX DASHBOARD ───────────────────────────────────
        from .html_renderer import render_index
        index_html = render_index(
            self._parsed_results,
            self.root,
            self._stats,
            synthesis=synthesis,
        )
        (self.output_root / "codereportai.html").write_text(index_html, encoding="utf-8")

        self._print_summary()

    # ------------------------------------------------------------------
    # Per-file processing with retry
    # ------------------------------------------------------------------

    def _process_file_with_retry(self, file_path: Path) -> dict:
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                api_key = self.api_manager.get_key()

                # Build RAG-aware context (or flat JSON fallback)
                relative_path = str(file_path.relative_to(self.root))
                language = None
                snippet = None
                try:
                    snippet = file_path.read_text(encoding="utf-8", errors="replace")[:600]
                    from .worker import LANG_MAP
                    language = LANG_MAP.get(file_path.suffix.lower())
                except OSError:
                    pass

                context_summary = self.ctx_manager.summary_for_prompt(
                    file_path=relative_path,
                    language=language,
                    content_snippet=snippet,
                    api_key=api_key,
                )

                # chroma_context is already embedded inside context_summary when
                # RAG mode is active; we pass empty string to avoid duplication.
                # (For non-RAG mode, both are JSON text anyway.)
                return self._worker.process(
                    file_path=file_path,
                    root=self.root,
                    api_key=api_key,
                    context_summary=context_summary,
                    chroma_context="",  # RAG context is baked into context_summary
                )
            except RateLimitError:
                self.api_manager.mark_rate_limited(api_key)
                continue
            except NoKeysAvailableError as exc:
                return {
                    "file_path": file_path,
                    "relative_path": str(file_path.relative_to(self.root)),
                    "error": str(exc),
                    "html_sections": {},
                    "context_update": {},
                }
            except Exception as exc:
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_DELAY * attempt)
                else:
                    return {
                        "file_path": file_path,
                        "relative_path": str(file_path.relative_to(self.root)),
                        "error": f"Failed after {MAX_RETRIES} attempts: {exc}",
                        "html_sections": {},
                        "context_update": {},
                    }
        return {
            "file_path": file_path,
            "relative_path": str(file_path.relative_to(self.root)),
            "error": "All retries exhausted (rate limits).",
            "html_sections": {},
            "context_update": {},
        }

    # ------------------------------------------------------------------
    # Success handler
    # ------------------------------------------------------------------

    def _on_success(self, result: dict) -> None:
        fp: Path = result["file_path"]

        # Update flat JSON context
        self.ctx_manager.update(result.get("context_update", {}), fp)
        self.ctx_manager.mark_processed(fp)
        self.ctx_manager.save(self.context_path)

        # Async embed into ChromaDB — non-blocking, best-effort
        if self._chroma and self._chroma.available:
            api_key = self._safe_get_key()
            if api_key:
                # Submit embed job to background thread pool
                self._embed_executor.submit(
                    self._chroma.embed_and_store, result, api_key
                )

        # Render HTML report
        html = render_report(result)
        out_path = self._html_output_path(fp)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html, encoding="utf-8")

        # Stats
        self._stats["processed"] += 1
        sections = result.get("html_sections", {})
        lines = sections.get("file_overview", {}).get("size_lines", 0)
        algos = len(sections.get("algorithms", []))
        funcs = len(sections.get("function_breakdown", []))
        risks = len(sections.get("risks_and_warnings", []))

        file_complexity = (lines / 100) + (algos * 5) + (funcs * 0.5) + (risks * 3)
        self._stats["total_lines"] += lines
        self._stats["complexity_score"] += round(file_complexity, 1)

        self._parsed_results.append(result)

        rel_safe = (
            str(out_path.relative_to(self.output_root.parent))
            .encode("ascii", errors="replace")
            .decode("ascii")
        )
        console.print(f"[green]OK[/green] {result['relative_path']} → {rel_safe}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _html_output_path(self, file_path: Path) -> Path:
        rel = file_path.relative_to(self.root)
        return self.output_root / rel.with_suffix(".html")

    def _safe_get_key(self) -> Optional[str]:
        """Get an API key without raising — returns None if none available."""
        try:
            return self.api_manager.get_key(timeout=5.0)
        except Exception:
            return None

    def _print_summary(self) -> None:
        s = self._stats
        chroma_count = self._chroma.count() if self._chroma else 0
        console.print(
            Panel(
                f"[bold green]Done:[/bold green] {s['processed']}   "
                f"[bold yellow]Skipped:[/bold yellow] {s['skipped']}   "
                f"[bold red]Errors:[/bold red] {s['errors']}\n"
                f"[dim]ChromaDB entries:[/dim] {chroma_count}   "
                f"[dim]Reports written to:[/dim] {self.output_root}",
                title="[bold]CodeReportAI — Run Complete[/bold]",
                border_style="green",
            )
        )
