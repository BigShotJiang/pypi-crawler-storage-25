# CodeReportAI

> 🧠 Terminal-based codebase analysis tool powered by **Google Gemini** + **ChromaDB**

CodeReportAI recursively scans any codebase, sends each source file to Gemini for deep analysis, and generates a mirrored folder of **beautiful, self-contained HTML reports** — plus a **project-wide architecture synthesis** powered by semantic memory.

---

## Features

- 🔍 **Deep AI Analysis** — Algorithms, design decisions, patterns, risks, and improvements per file
- 🧠 **ChromaDB Semantic Memory** — Embeddings stored in a local vector DB; each file gets the *most relevant* prior context (not random-last-20)
- 🔗 **RAG Cross-File Intelligence** — Semantically-retrieved similar files enrich every Gemini prompt
- 🏛️ **Synthesis Agent** — After all files are processed, a second Gemini pass produces architecture overview, critical paths, tech debt hotspots, improvement roadmap, and security surface
- ❓ **Query Mode** — Ask natural language questions about any previously analysed codebase
- ⚡ **Concurrent Processing** — Configurable multi-threaded workers
- 🔑 **Multi-Key Load Balancing** — Round-robin across multiple Gemini API keys with automatic cooldown on `429` errors
- ⏸ **Resume Support** — Interrupted runs resume from where they left off
- 📊 **Rich Progress UI** — Live terminal progress bar with per-file status
- 🎨 **Beautiful Reports** — Dark-mode, self-contained HTML (no CDN needed, offline-capable)

---

## Installation

```bash
# 1. Clone or navigate to the CodeReportAi directory
cd /path/to/CodeReportAi

# 2. Install (creates the `codereportai` CLI command globally)
pip install -e .
```

Once installed, the `codereportai` command is available **from any folder in your terminal**.

---

## Setup

Create a `.env` file in your **project folder** (optional — built-in keys are included as fallback):

```env
GEMINI_API_KEY_1=your_first_key_here
GEMINI_API_KEY_2=your_second_key_here   # optional, enables rotation
GEMINI_API_KEY_3=your_third_key_here    # optional
```

Copy `.env.example` to get started:

```bash
cp .env.example /path/to/your/project/.env
# then edit with your actual keys
```

---

## Usage

### Scan Current Directory (simplest)

```bash
cd /path/to/your/project
codereportai
```

### Scan Any Folder

```bash
codereportai --path ./my-project
codereportai --path C:\Users\kumar\Projects\backend-api
```

### Common Options

```bash
# Use more workers for faster processing
codereportai --workers 4

# Resume an interrupted run (skips already-processed files)
codereportai --resume

# Run without ChromaDB (lightweight mode, no semantic memory)
codereportai --no-chroma

# Combine options
codereportai --path ./my-project --workers 4 --resume

# Use a specific Gemini model
codereportai --model gemini-2.0-flash
```

### Query Mode — Ask Questions About Your Codebase

After a codebase has been analysed, you can query it in natural language:

```bash
codereportai query "where is rate limiting handled?"
codereportai query "what design patterns are used?"
codereportai query "which files have the highest security risk?" --top 8
codereportai query "how does authentication work?" --path ./my-project
```

The query command:
1. Embeds your question using Gemini Embeddings
2. Searches the local ChromaDB store for the most relevant file analyses
3. Feeds the results to Gemini and prints a formatted Markdown answer with file citations

---

## CLI Reference

### `codereportai` (scan)

| Flag | Default | Description |
| --- | --- | --- |
| `--path` / `-p` | CWD | Root directory to scan |
| `--resume` | off | Skip already-processed files |
| `--workers` / `-w` | `1` | Number of parallel workers (1–16) |
| `--model` / `-m` | `gemma-4-31b-it` | Gemini model name |
| `--env` | `.env` | Path to env file |
| `--chroma` / `--no-chroma` | on | Enable/disable ChromaDB semantic memory |

### `codereportai query`

| Flag | Default | Description |
| --- | --- | --- |
| `QUESTION` | *(required)* | Natural language question about the codebase |
| `--path` / `-p` | CWD | Project root that was previously analysed |
| `--top` / `-n` | `5` | Number of relevant files to retrieve |
| `--model` / `-m` | `gemma-4-31b-it` | Gemini model to use for answering |
| `--env` | `.env` | Path to env file |

---

## Output Structure

Given:

```
ProjectFolder/
  ├── src/
  │     └── main.py
  └── utils/
        └── helpers.ts
```

CodeReportAI produces:

```
ProjectFolder/
  ├── src/
  │     └── main.py
  ├── utils/
  │     └── helpers.ts
  └── CodeReportAi/                  ← created automatically
        ├── src/
        │     └── main.html          ← full AI analysis report
        ├── utils/
        │     └── helpers.html
        ├── codereportai.html         ← project dashboard (with Synthesis)
        ├── synthesis.json            ← AI architecture summary
        ├── context.json              ← global context (enables --resume)
        └── chroma_store/             ← ChromaDB semantic vector store
```

---

## What Each File Report Contains

| Section | Description |
| --- | --- |
| **File Overview** | Language, purpose, line count, key imports |
| **Function Breakdown** | Each function's role, interactions, complexity |
| **Execution Flow** | Step-by-step lifecycle trace including branch/failure paths |
| **Algorithms Used** | Named algorithms with time/space complexity |
| **Key Design Decisions** | Architectural choices and rationale |
| **Alternative Approaches** | What else could have been done (and why it wasn't) |
| **Notable Code Patterns** | Design patterns, idioms, and anti-patterns |
| **Potential Improvements** | Concrete refactor and upgrade suggestions |
| **Cross-File Context** | Relationships to semantically similar files (via ChromaDB RAG) |
| **Concurrency & State Risks** | Thread-safety, shared mutable state, race conditions |
| **Risks & Warnings** | Security issues, performance bottlenecks, deprecated usage |

## What the Dashboard (`codereportai.html`) Contains

| Section | Description |
| --- | --- |
| **Project Metadata** | Files analysed, total LoC, global complexity score |
| **Global Risk Registry** | Critical, medium, and low risk counts across all files |
| **Architecture & Patterns** | Top languages, emergent design patterns |
| **🧠 AI Architecture Overview** | Synthesis Agent: system description, data flow, boundaries |
| **⚡ Critical Paths** | Files whose failure breaks the system |
| **🧹 Tech Debt Hotspots** | Specific files and issues with severity ratings |
| **📋 Improvement Roadmap** | Prioritised action list with expected impact |
| **🔒 Security Surface** | Cross-file security risks identified by the Synthesis Agent |
| **Mirrored File Tree** | Searchable hierarchy of all report links |

---

## How ChromaDB Semantic Memory Works

```
File 1 analysed → embedding stored in ChromaDB
File 2 analysed → ChromaDB queried for most similar prior analyses
                   → top 5 results injected into File 2's Gemini prompt
                   → richer, more specific cross-file context in report
...
All files done  → Synthesis Agent reads all ChromaDB entries
                   → single Gemini call with architect-level prompt
                   → produces synthesis.json + dashboard section
```

This means **later files get better analysis** — the model can reference actual related files by name instead of guessing.

---

## Files Skipped

- Binary files, images, audio, video, archives
- `node_modules/`, `.git/`, `__pycache__/`, `dist/`, `build/`, `.venv/`
- Lock files (`package-lock.json`, `yarn.lock`, etc.)
- Minified files (`*.min.js`, `*.min.css`)
- Files larger than ~120 KB
- The `CodeReportAi/` output directory itself

---

## Requirements

- Python ≥ 3.9
- A valid Google Gemini API key ([Get one free](https://aistudio.google.com/app/apikey))
- `chromadb` (installed automatically via `pip install -e .`)

---

## License

MIT
