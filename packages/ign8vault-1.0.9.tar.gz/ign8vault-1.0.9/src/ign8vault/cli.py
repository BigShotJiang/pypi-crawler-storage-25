"""CLI entry point: `ign8vault up` provisions Vault + Consul on Hetzner."""

import json
import secrets
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

import urllib.request

from ign8vault.config import Config
from ign8vault.dns.cloudflare import CloudflareDNS
from ign8vault.infra import hetzner
from ign8vault.keys import ensure_ed25519_keypair, save_keypair
from ign8vault.setup.server import VaultSetup

app = typer.Typer(name="ign8vault", help="Ignite a production Vault + Consul stack in minutes.", invoke_without_command=True)
console = Console()


@app.callback(invoke_without_command=True)
def _main(
    ctx: typer.Context,
    env_file: Path = typer.Option(Path(".env"), "--env-file", hidden=True),
) -> None:
    # Load .env into os.environ so all envvar= options pick it up
    if env_file.exists():
        import os
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())
        # Bridge IGN8_ prefixed Vault vars to the native Vault env var names
        for bare, prefixed in (("VAULT_ADDR", "IGN8_VAULT_ADDR"), ("VAULT_TOKEN", "IGN8_VAULT_TOKEN")):
            if bare not in os.environ and prefixed in os.environ:
                os.environ[bare] = os.environ[prefixed]
    if ctx.invoked_subcommand is None:
        _print_intro()


@app.command()
def up(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN", help="Base domain (e.g. example.com)"),
    admin_email: str = typer.Option("", envvar="IGN8_ADMIN_EMAIL", help="Admin / certbot email"),
    hetzner_token: str = typer.Option(..., envvar="IGN8_HETZNER_TOKEN", help="Hetzner Cloud API token"),
    cloudflare_token: str = typer.Option(..., envvar="IGN8_CLOUDFLARE_TOKEN", help="Cloudflare API token"),
    cloudflare_zone_id: str = typer.Option(..., envvar="IGN8_CLOUDFLARE_ZONE_ID", help="Cloudflare Zone ID"),
    cloudflare_email: str = typer.Option("", envvar="IGN8_CLOUDFLARE_EMAIL", help="Cloudflare account email (Global API Key only)"),
    storagebox_host: str = typer.Option("", envvar="IGN8_STORAGEBOX_HOST", help="Hetzner StorageBox hostname"),
    storagebox_user: str = typer.Option("", envvar="IGN8_STORAGEBOX_USER", help="StorageBox username (defaults to first part of host)"),
    storagebox_password: str = typer.Option("", envvar="IGN8_STORAGEBOX_PASSWORD", help="StorageBox password"),
    backup_password: str = typer.Option("", envvar="IGN8_BACKUP_PASSWORD", help="Restic encryption password (auto-generated if empty)"),
    work_dir: Path = typer.Option(Path(".ign8vault"), help="Directory for keys and state"),
) -> None:
    """Provision Vault + Consul: Hetzner VM + Cloudflare DNS + TLS + backups."""

    cfg = Config(
        domain=domain,
        admin_email=admin_email,  # type: ignore[arg-type]
        hetzner_token=hetzner_token,
        cloudflare_token=cloudflare_token,
        cloudflare_zone_id=cloudflare_zone_id,
        cloudflare_email=cloudflare_email,
        storagebox_host=storagebox_host,
        storagebox_user=storagebox_user,
        storagebox_password=storagebox_password,
        backup_password=backup_password,
    )

    # Auto-generate backup password if not supplied
    effective_backup_password = cfg.backup_password or secrets.token_hex(24)

    console.print(Panel(f"[bold]ign8vault[/bold] — igniting [cyan]{cfg.domain}[/cyan]"))

    # 1. SSH keypair
    console.print("[1/5] Generating SSH keypair...")
    keys_dir = work_dir / "keys"
    priv_path, pub_path = save_keypair(keys_dir)
    public_key_openssh = pub_path.read_text().strip()

    # 2. Hetzner server
    console.print("[2/5] Provisioning Hetzner server...")
    outputs = hetzner.provision(cfg, public_key_openssh, work_dir / "state.json")
    ipv4: str = outputs["ipv4"]
    ipv6: str = outputs["ipv6"]
    console.print(f"    Server IPv4: [green]{ipv4}[/green]")
    if ipv6:
        console.print(f"    Server IPv6: [green]{ipv6}[/green]")

    # 3. Cloudflare DNS
    console.print("[3/5] Creating Cloudflare DNS records...")
    dns = CloudflareDNS(cfg.cloudflare_token, cfg.cloudflare_zone_id, cfg.domain, cfg.cloudflare_email)
    dns.provision(ipv4, ipv6)
    console.print(f"    vault.{cfg.domain}  → {ipv4}")
    console.print(f"    consul.{cfg.domain} → {ipv4}")

    # 4. Server setup
    console.print("[4/5] Setting up server (Consul + Vault + nginx + TLS)...")
    console.print("    Connecting via SSH (may take up to 5 minutes for boot)...")
    setup = VaultSetup(cfg, ipv4, str(priv_path))
    setup.connect(retries=30, delay=10)
    try:
        init_data = setup.run(effective_backup_password)
    finally:
        setup.disconnect()

    # 5. Save credentials locally
    console.print("[5/5] Saving credentials...")
    init_path = work_dir / "vault-init.json"
    saved: dict[str, object] = {
        "vault_url": f"https://vault.{cfg.domain}",
        "consul_url": f"https://consul.{cfg.domain}",
        "backup_password": effective_backup_password,
    }
    if init_data:
        saved.update(init_data)

    init_path.write_text(json.dumps(saved, indent=2))
    init_path.chmod(0o600)

    _print_summary(cfg, saved, init_data)


@app.command()
def destroy(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN", help="Base domain"),
    hetzner_token: str = typer.Option(..., envvar="IGN8_HETZNER_TOKEN", help="Hetzner Cloud API token"),
    cloudflare_token: str = typer.Option("", envvar="IGN8_CLOUDFLARE_TOKEN", help="Cloudflare API token"),
    cloudflare_zone_id: str = typer.Option("", envvar="IGN8_CLOUDFLARE_ZONE_ID", help="Cloudflare Zone ID"),
    cloudflare_email: str = typer.Option("", envvar="IGN8_CLOUDFLARE_EMAIL"),
    work_dir: Path = typer.Option(Path(".ign8vault"), help="Directory for keys and state"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Tear down the Vault + Consul server and DNS records."""
    if not yes:
        typer.confirm(f"Destroy all ign8vault resources for {domain}?", abort=True)

    console.print(Panel(f"[bold red]ign8vault destroy[/bold red] — tearing down [cyan]{domain}[/cyan]"))

    console.print("[1/2] Deleting Hetzner server...")
    hetzner.destroy(work_dir / "state.json", hetzner_token)

    if cloudflare_token and cloudflare_zone_id:
        console.print("[2/2] Removing DNS records...")
        dns = CloudflareDNS(cloudflare_token, cloudflare_zone_id, domain, cloudflare_email)
        dns.destroy()
    else:
        console.print("[2/2] Skipping DNS cleanup (no Cloudflare credentials)")

    console.print("[green]Done.[/green] DNS may take a few minutes to propagate removal.")


def _print_summary(cfg: Config, saved: dict[str, object], init_data: dict[str, object]) -> None:
    console.print()
    console.print(Panel("[bold green]Vault stack is live![/bold green]"))

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]Vault UI[/dim]",  f"[cyan]https://vault.{cfg.domain}[/cyan]")
    table.add_row("[dim]Consul UI[/dim]", f"[cyan]https://consul.{cfg.domain}[/cyan]")

    if init_data:
        root_token = str(init_data.get("root_token", ""))
        table.add_row("[dim]Root token[/dim]", f"[yellow]{root_token}[/yellow]")
        keys = init_data.get("unseal_keys_b64", [])
        for i, k in enumerate(keys, 1):  # type: ignore[union-attr]
            table.add_row(f"[dim]Unseal key {i}[/dim]", str(k))

    backup_pw = str(saved.get("backup_password", ""))
    if backup_pw:
        table.add_row("[dim]Backup password[/dim]", f"[yellow]{backup_pw}[/yellow]")

    console.print(table)
    console.print()
    console.print(
        f"[dim]Credentials saved to[/dim] [bold].ign8vault/vault-init.json[/bold]\n"
        f"[dim]Keep unseal keys safe — you need 3 of 5 to unseal after a reboot.[/dim]"
    )


@app.command()
def sign(
    vault_addr: str = typer.Option(..., envvar="IGN8_VAULT_ADDR", help="Vault address"),
    vault_token: str = typer.Option(..., envvar="IGN8_VAULT_TOKEN", help="Vault token"),
    principals: str = typer.Option("root", help="Comma-separated list of valid principals"),
    role: str = typer.Option("signer", help="Vault SSH signing role"),
    work_dir: Path = typer.Option(Path(".ign8vault"), help="Directory for keys and state"),
) -> None:
    """Create (if absent) the signssh keypair and sign it, saving the cert as signedssh."""
    keys_dir = work_dir / "keys"

    # 1. Create keypair if it doesn't exist yet
    priv_path, pub_path = ensure_ed25519_keypair(keys_dir, "signssh")
    public_key = pub_path.read_text().strip()
    console.print(f"[dim]Key:[/dim] {pub_path}")

    # 2. Sign via Vault SSH API
    payload = json.dumps({
        "public_key": public_key,
        "valid_principals": principals,
        "cert_type": "user",
    }).encode()

    req = urllib.request.Request(
        f"{vault_addr.rstrip('/')}/v1/ssh/sign/{role}",
        data=payload,
        headers={"X-Vault-Token": vault_token, "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())

    signed_key: str = data["data"]["signed_key"]

    # 3. Save certificate as signedssh
    cert_path = keys_dir / "signedssh"
    cert_path.write_text(signed_key + "\n")
    cert_path.chmod(0o600)

    console.print(f"[green]Signed certificate saved to[/green] {cert_path}")
    console.print(f"[dim]Serial:[/dim] {data['data']['serial_number']}")

    # Print usage hint
    console.print(
        f"\n[dim]Use it:[/dim]\n"
        f"  ssh -i {priv_path} -i {cert_path} <host>"
    )


@app.command()
def setenv(
    profile: Optional[Path] = typer.Option(None, help="Shell profile to update (auto-detected from $SHELL)"),
) -> None:
    """Set VAULT_ADDR, VAULT_TOKEN, VAULT_FORMAT in the shell profile and test the connection."""
    import os, re

    if profile is None:
        shell = os.environ.get("SHELL", "")
        if "bash" in shell:
            profile = Path("~/.bashrc").expanduser()
        elif "zsh" in shell:
            profile = Path("~/.zshrc").expanduser()
        else:
            profile = Path("~/.profile").expanduser()

    vars_to_set = [
        ("VAULT_ADDR",   os.environ.get("VAULT_ADDR",   "https://vault.ign8.it")),
        ("VAULT_TOKEN",  os.environ.get("VAULT_TOKEN",  "")),
        ("VAULT_FORMAT", os.environ.get("VAULT_FORMAT", "json")),
    ]

    results: list[tuple[str, str]] = []
    for name, default in vars_to_set:
        value = typer.prompt(name, default=default)
        results.append((name, value))

    # Upsert each var in the profile
    text = profile.read_text() if profile.exists() else ""
    for name, value in results:
        line = f'export {name}="{value}"'
        if name in text:
            text = re.sub(rf'^export {name}=.*$', line, text, flags=re.MULTILINE)
        else:
            text = text.rstrip("\n") + f"\n{line}\n"
    profile.write_text(text)

    console.print(f"\n[green]Written to {profile}:[/green]")
    for name, value in results:
        masked = value if name != "VAULT_TOKEN" else value[:10] + "…"
        console.print(f"  export {name}=\"{masked}\"")

    # Test connection
    addr = dict(results)["VAULT_ADDR"]
    token = dict(results)["VAULT_TOKEN"]
    console.print(f"\n[dim]Testing connection to {addr} …[/dim]")
    try:
        req = urllib.request.Request(
            f"{addr.rstrip('/')}/v1/sys/health",
            headers={"X-Vault-Token": token},
        )
        with urllib.request.urlopen(req) as resp:
            health = json.loads(resp.read())
        initialized = health.get("initialized", False)
        sealed = health.get("sealed", True)
        version = health.get("version", "?")
        status = "[green]unsealed[/green]" if not sealed else "[yellow]sealed[/yellow]"
        console.print(f"  Vault {version} — initialized={initialized}, {status}")
    except Exception as exc:
        console.print(f"  [red]Connection failed:[/red] {exc}")


@app.command()
def adduser(
    vault_addr: str = typer.Option(..., envvar="VAULT_ADDR", help="Vault address"),
    vault_token: str = typer.Option(..., envvar="VAULT_TOKEN", help="Vault admin token"),
    username: str = typer.Argument(..., help="Username to create"),
    role: str = typer.Option("signer", help="SSH signing role"),
) -> None:
    """Create a Vault user with a password and a dedicated SSH-signing token."""
    import os

    password = secrets.token_urlsafe(16)

    def api(method: str, path: str, body: Optional[dict] = None) -> dict:
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            f"{vault_addr.rstrip('/')}/v1/{path}",
            data=data,
            headers={"X-Vault-Token": vault_token, "Content-Type": "application/json"},
            method=method,
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read()) if resp.length != 0 else {}  # type: ignore[attr-defined]
        except urllib.error.HTTPError as exc:
            body_bytes = exc.read()
            err = json.loads(body_bytes).get("errors", [str(exc)]) if body_bytes else [str(exc)]
            # Ignore "already enabled/exists" errors
            if any("already" in e for e in err):
                return {}
            raise RuntimeError("; ".join(err)) from exc

    # 1. Enable userpass auth (idempotent)
    console.print("[1/4] Enabling userpass auth method...")
    api("POST", "sys/auth/userpass", {"type": "userpass"})

    # 2. Create SSH-signer policy (idempotent)
    console.print("[2/4] Writing ssh-signer policy...")
    policy_hcl = f'path "ssh/sign/{role}" {{\n  capabilities = ["create", "update"]\n}}\n'
    api("PUT", "sys/policies/acl/ssh-signer", {"policy": policy_hcl})

    # 3. Create the userpass user
    console.print(f"[3/4] Creating user [cyan]{username}[/cyan]...")
    api("POST", f"auth/userpass/users/{username}", {
        "password": password,
        "policies": "ssh-signer",
    })

    # 4. Create an orphan token tied to the ssh-signer policy
    console.print("[4/4] Creating SSH-signing token...")
    resp = api("POST", "auth/token/create", {
        "policies": ["ssh-signer"],
        "display_name": f"{username}-ssh-sign",
        "no_parent": True,
        "renewable": True,
        "ttl": "8760h",  # 1 year
    })
    sign_token: str = resp["auth"]["client_token"]

    # Display
    console.print()
    console.print(Panel(f"[bold green]User [cyan]{username}[/cyan] created[/bold green]"))
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]Username[/dim]",    f"[cyan]{username}[/cyan]")
    table.add_row("[dim]Password[/dim]",    f"[yellow]{password}[/yellow]")
    table.add_row("[dim]Sign token[/dim]",  f"[yellow]{sign_token}[/yellow]", no_wrap=True)
    table.add_row("[dim]Vault login[/dim]", f"vault login -method=userpass username={username}")
    console.print(table)
    console.print()
    console.print("[dim]The sign token can be used as VAULT_TOKEN for[/dim] [cyan]ign8vault sign[/cyan]")


def _print_intro() -> None:
    console.print(Panel(
        "[bold]ign8vault[/bold] — HashiCorp Vault + Consul on Hetzner\n\n"
        "  [cyan]ign8vault up[/cyan]       provision a complete stack\n"
        "  [cyan]ign8vault adduser[/cyan]  create a Vault user + SSH-sign token\n"
        "  [cyan]ign8vault sign[/cyan]     create/sign the signssh keypair\n"
        "  [cyan]ign8vault setenv[/cyan]   set Vault env vars in ~/.profile\n"
        "  [cyan]ign8vault destroy[/cyan]  tear it all down",
        title="ign8vault",
    ))
