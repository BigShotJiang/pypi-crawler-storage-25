from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, rsa


def generate_rsa_keypair(bits: int = 4096) -> tuple[str, str]:
    """Return (private_key_pem, public_key_openssh)."""
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=bits)
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.OpenSSH,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode()
    public_openssh = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    ).decode()
    return private_pem, public_openssh


def generate_ed25519_keypair() -> tuple[str, str]:
    """Return (private_key_pem_openssh, public_key_openssh)."""
    private_key = ed25519.Ed25519PrivateKey.generate()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.OpenSSH,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode()
    public_openssh = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    ).decode()
    return private_pem, public_openssh


def save_keypair(directory: Path, name: str = "ign8vault") -> tuple[Path, Path]:
    """Generate RSA keypair if absent, return (private_path, public_path)."""
    directory.mkdir(parents=True, exist_ok=True)
    priv_path = directory / name
    pub_path = directory / f"{name}.pub"

    if not priv_path.exists():
        private_pem, public_openssh = generate_rsa_keypair()
        priv_path.write_text(private_pem)
        priv_path.chmod(0o600)
        pub_path.write_text(public_openssh)
    return priv_path, pub_path


def ensure_ed25519_keypair(directory: Path, name: str) -> tuple[Path, Path]:
    """Create ed25519 keypair if absent, return (private_path, public_path)."""
    directory.mkdir(parents=True, exist_ok=True)
    priv_path = directory / name
    pub_path = directory / f"{name}.pub"

    if not priv_path.exists():
        private_pem, public_openssh = generate_ed25519_keypair()
        priv_path.write_text(private_pem)
        priv_path.chmod(0o600)
        pub_path.write_text(public_openssh)
    return priv_path, pub_path
