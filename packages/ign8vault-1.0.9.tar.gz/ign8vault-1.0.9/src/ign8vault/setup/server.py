"""SSH into the provisioned server and install Consul + Vault + nginx + backup."""

import json
import time
from pathlib import Path
from typing import Optional

import paramiko

from ign8vault.config import Config

_PACKAGES = "curl gnupg nginx certbot python3-certbot-nginx restic sshpass lsb-release"

_CONSUL_CONFIG = """\
datacenter = "dc1"
data_dir   = "/opt/consul/data"
server     = true
bootstrap_expect = 1
bind_addr  = "127.0.0.1"
client_addr = "127.0.0.1"
log_level  = "INFO"

ui_config {
  enabled = true
}
"""

_VAULT_CONFIG_TMPL = """\
storage "consul" {{
  address = "127.0.0.1:8500"
  path    = "vault/"
}}

listener "tcp" {{
  address     = "127.0.0.1:8200"
  tls_disable = true
}}

api_addr = "https://vault.{domain}"
ui       = true
log_level = "INFO"
"""

_NGINX_ACME_TMPL = """\
server {{
    listen 80;
    server_name vault.{domain} consul.{domain};
    root /var/www/html;
    location /.well-known/acme-challenge/ {{ try_files $uri =404; }}
    location / {{ return 200 'ok'; add_header Content-Type text/plain; }}
}}
"""

_NGINX_FINAL_TMPL = """\
server {{
    listen 80;
    server_name vault.{domain} consul.{domain};
    location /.well-known/acme-challenge/ {{ root /var/www/html; }}
    location / {{ return 301 https://$host$request_uri; }}
}}

server {{
    listen 443 ssl http2;
    server_name vault.{domain};

    ssl_certificate     /etc/letsencrypt/live/vault.{domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/vault.{domain}/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;

    # Allow Vault's large request headers
    proxy_buffer_size   128k;
    proxy_buffers       4 256k;
    proxy_busy_buffers_size 256k;

    location / {{
        proxy_pass         http://127.0.0.1:8200;
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto https;
        proxy_read_timeout 300s;
    }}
}}

server {{
    listen 443 ssl http2;
    server_name consul.{domain};

    ssl_certificate     /etc/letsencrypt/live/vault.{domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/vault.{domain}/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;

    location / {{
        proxy_pass       http://127.0.0.1:8500;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
    }}
}}
"""

_BACKUP_SERVICE_TMPL = """\
[Unit]
Description=Vault/Consul backup via restic
After=network.target

[Service]
Type=oneshot
Environment="RESTIC_PASSWORD={restic_password}"
ExecStart=/usr/bin/restic -r sftp:storagebox:/vault-backup backup /opt/consul/data
ExecStart=/usr/bin/restic -r sftp:storagebox:/vault-backup forget --keep-daily 7 --keep-weekly 4 --prune
"""

_BACKUP_TIMER = """\
[Unit]
Description=Daily Vault/Consul backup

[Timer]
OnCalendar=daily
RandomizedDelaySec=1800
Persistent=true

[Install]
WantedBy=timers.target
"""


class VaultSetup:
    def __init__(self, cfg: Config, host: str, private_key_path: str) -> None:
        self._cfg = cfg
        self._host = host
        self._key_path = private_key_path
        self._ssh: Optional[paramiko.SSHClient] = None
        self._known_hosts_path = Path(private_key_path).parent.parent / "known_hosts"

    def connect(self, retries: int = 30, delay: int = 10) -> None:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        key = paramiko.RSAKey.from_private_key_file(self._key_path)

        for attempt in range(retries):
            try:
                client.connect(self._host, username="root", pkey=key, timeout=15)
                self._ssh = client
                return
            except Exception:
                if attempt == retries - 1:
                    raise
                time.sleep(delay)

    def disconnect(self) -> None:
        if self._ssh:
            self._ssh.close()
            self._ssh = None

    def run(self, backup_password: str) -> dict[str, object]:
        """Full server setup. Returns vault init data (unseal keys + root token)."""
        assert self._ssh, "Call connect() first"

        self._install_packages()
        self._install_hashicorp()
        self._setup_consul()
        self._setup_vault()
        self._setup_nginx_acme()
        self._get_tls_certs()
        self._setup_nginx_final()

        init_data = self._init_vault()

        if self._cfg.storagebox_host:
            self._setup_backup(backup_password)

        return init_data

    # ------------------------------------------------------------------
    # Installation

    def _install_packages(self) -> None:
        self._exec("apt-get update -qq")
        self._exec(f"DEBIAN_FRONTEND=noninteractive apt-get install -y -qq {_PACKAGES}")

    def _install_hashicorp(self) -> None:
        already = self._exec("dpkg -l consul 2>/dev/null | grep -c '^ii' || true").strip()
        if already == "1":
            return
        self._exec(
            "curl -fsSL https://apt.releases.hashicorp.com/gpg"
            " | gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg"
        )
        self._exec(
            'echo "deb [arch=$(dpkg --print-architecture)'
            " signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg]"
            ' https://apt.releases.hashicorp.com $(lsb_release -cs) main"'
            " > /etc/apt/sources.list.d/hashicorp.list"
        )
        self._exec("apt-get update -qq")
        self._exec("DEBIAN_FRONTEND=noninteractive apt-get install -y -qq consul vault")

    # ------------------------------------------------------------------
    # Consul

    def _setup_consul(self) -> None:
        self._exec("mkdir -p /opt/consul/data && chown -R consul:consul /opt/consul/data")
        self._write_remote("/etc/consul.d/consul.hcl", _CONSUL_CONFIG)
        self._exec("systemctl enable consul")
        # restart may time out waiting for sd_notify even though consul is healthy
        try:
            self._exec("systemctl restart consul")
        except RuntimeError as e:
            if "timeout" not in str(e).lower() and "timed out" not in str(e).lower():
                raise
        # Wait until Consul API returns a leader
        for _ in range(30):
            try:
                out = self._exec("curl -sf http://127.0.0.1:8500/v1/status/leader || true").strip()
                if out and out != '""':
                    return
            except RuntimeError:
                pass
            time.sleep(2)
        raise RuntimeError("Consul API did not become healthy within 60s")

    # ------------------------------------------------------------------
    # Vault

    def _setup_vault(self) -> None:
        self._exec("mkdir -p /opt/vault/data && chown -R vault:vault /opt/vault/data")
        vault_cfg = _VAULT_CONFIG_TMPL.format(domain=self._cfg.domain)
        self._write_remote("/etc/vault.d/vault.hcl", vault_cfg)
        self._exec("systemctl enable vault")
        try:
            self._exec("systemctl restart vault")
        except RuntimeError as e:
            if "timeout" not in str(e).lower() and "timed out" not in str(e).lower():
                raise
        # Wait until Vault API responds (501=not init, 429=sealed, 200=ok)
        for _ in range(30):
            code = self._exec(
                "curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8200/v1/sys/health || true"
            ).strip()
            if code in ("200", "429", "472", "473", "501"):
                return
            time.sleep(2)
        raise RuntimeError("Vault API did not become healthy within 60s")

    # ------------------------------------------------------------------
    # nginx

    def _setup_nginx_acme(self) -> None:
        self._exec("mkdir -p /var/www/html")
        self._exec("rm -f /etc/nginx/sites-enabled/default")
        acme_cfg = _NGINX_ACME_TMPL.format(domain=self._cfg.domain)
        self._write_remote("/etc/nginx/sites-available/ign8vault", acme_cfg)
        self._exec("ln -sf /etc/nginx/sites-available/ign8vault /etc/nginx/sites-enabled/ign8vault")
        self._exec("nginx -t && systemctl reload nginx")

    def _get_tls_certs(self) -> None:
        domain = self._cfg.domain
        self._exec(
            f"certbot certonly --webroot -w /var/www/html"
            f" -d vault.{domain} -d consul.{domain}"
            f" --non-interactive --agree-tos -m {self._cfg.admin_email}"
        )

    def _setup_nginx_final(self) -> None:
        final_cfg = _NGINX_FINAL_TMPL.format(domain=self._cfg.domain)
        self._write_remote("/etc/nginx/sites-available/ign8vault", final_cfg)
        self._exec("nginx -t && systemctl reload nginx")

    # ------------------------------------------------------------------
    # Vault init & unseal

    def _init_vault(self) -> dict[str, object]:
        """Initialize Vault if needed, unseal it, return init data."""
        status_raw = self._exec(
            "VAULT_ADDR=http://127.0.0.1:8200 vault status -format=json 2>&1 || true"
        ).strip()

        try:
            status = json.loads(status_raw)
            already_initialized = status.get("initialized", False)
        except (json.JSONDecodeError, ValueError):
            already_initialized = False

        if already_initialized:
            # Vault already initialized — unseal if sealed
            if status.get("sealed", True):
                raise RuntimeError(
                    "Vault is already initialized but sealed. "
                    "Retrieve your unseal keys from .ign8vault/vault-init.json and unseal manually."
                )
            return {}

        init_raw = self._exec(
            "VAULT_ADDR=http://127.0.0.1:8200"
            " vault operator init -key-shares=5 -key-threshold=3 -format=json"
        ).strip()

        init_data: dict[str, object] = json.loads(init_raw)

        # Save on the server (root-only)
        self._write_remote("/root/vault-init.json", init_raw)
        self._exec("chmod 600 /root/vault-init.json")

        # Unseal using the first 3 keys (threshold=3)
        keys = init_data.get("unseal_keys_b64", [])
        for key in keys[:3]:
            self._exec(
                f"VAULT_ADDR=http://127.0.0.1:8200 vault operator unseal {key}"
            )

        return init_data

    # ------------------------------------------------------------------
    # Backup

    def _setup_backup(self, restic_password: str) -> None:
        cfg = self._cfg

        # Generate dedicated backup SSH key on the server (idempotent)
        self._exec(
            "test -f /root/.ssh/backup_key"
            " || ssh-keygen -t ed25519 -f /root/.ssh/backup_key -N '' -C 'vault-backup'"
        )

        # Authorise the key on the storage box via sshpass (port 23)
        self._exec(
            f"sshpass -p '{cfg.storagebox_password}'"
            f" ssh-copy-id -p 23 -i /root/.ssh/backup_key.pub"
            f" -o StrictHostKeyChecking=no"
            f" {cfg.storagebox_user}@{cfg.storagebox_host}"
        )

        # SSH client config for the storagebox alias
        ssh_snippet = (
            f"Host storagebox\n"
            f"    HostName {cfg.storagebox_host}\n"
            f"    User {cfg.storagebox_user}\n"
            f"    Port 23\n"
            f"    IdentityFile /root/.ssh/backup_key\n"
            f"    StrictHostKeyChecking no\n"
        )
        self._exec(
            f"grep -q 'Host storagebox' /root/.ssh/config 2>/dev/null"
            f" || printf '{ssh_snippet}' >> /root/.ssh/config"
        )
        self._exec("chmod 600 /root/.ssh/config")

        # Init restic repo (idempotent — fails gracefully if already initialised)
        self._exec(
            f"RESTIC_PASSWORD='{restic_password}'"
            " restic -r sftp:storagebox:/vault-backup init 2>&1"
            " | grep -v 'already initialized' || true"
        )

        # Systemd service + timer
        svc = _BACKUP_SERVICE_TMPL.format(restic_password=restic_password)
        self._write_remote("/etc/systemd/system/vault-backup.service", svc)
        self._write_remote("/etc/systemd/system/vault-backup.timer", _BACKUP_TIMER)
        self._exec(
            "systemctl daemon-reload"
            " && systemctl enable vault-backup.timer"
            " && systemctl start vault-backup.timer"
        )

    # ------------------------------------------------------------------
    # Helpers

    def _write_remote(self, remote_path: str, content: str) -> None:
        assert self._ssh
        sftp = self._ssh.open_sftp()
        try:
            import io
            sftp.putfo(io.BytesIO(content.encode()), remote_path)
        finally:
            sftp.close()

    def _exec(self, cmd: str) -> str:
        assert self._ssh
        _, stdout, stderr = self._ssh.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()
        output = stdout.read().decode()
        if exit_code != 0:
            raise RuntimeError(f"Command failed ({exit_code}): {cmd}\n{stderr.read().decode()}")
        return output
