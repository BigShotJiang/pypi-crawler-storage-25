from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="IGN8_", env_file=".env", extra="ignore")

    # Required
    domain: str
    admin_email: str
    hetzner_token: str
    cloudflare_token: str
    cloudflare_zone_id: str
    cloudflare_email: str = ""

    # Server
    server_location: str = "nbg1"
    server_type: str = "cpx22"
    server_image: str = "ubuntu-24.04"

    # StorageBox backup
    storagebox_host: str = ""
    storagebox_user: str = ""
    storagebox_password: str = ""
    backup_password: str = ""  # auto-generated if empty

    # Vault (for sign command)
    vault_addr: str = ""
    vault_token: str = ""

    @field_validator("domain")
    @classmethod
    def strip_trailing_dot(cls, v: str) -> str:
        return v.rstrip(".")

    @model_validator(mode="after")
    def _derive_storagebox_user(self) -> "Config":
        if self.storagebox_host and not self.storagebox_user:
            self.storagebox_user = self.storagebox_host.split(".")[0]
        return self
