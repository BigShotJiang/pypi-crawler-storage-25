# ign8vault

Spin up HashiCorp Vault + Consul on Hetzner Cloud in one command.

```bash
pip install -e .
cp .env.example .env  # fill in credentials
ign8vault up
```
