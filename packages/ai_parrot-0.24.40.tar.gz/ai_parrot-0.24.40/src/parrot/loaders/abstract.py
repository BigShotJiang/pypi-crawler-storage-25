from __future__ import annotations
from typing import Generator, Union, List, Any, Optional, TypeVar, TYPE_CHECKING
from collections.abc import Callable
from abc import ABC, abstractmethod
from datetime import datetime
import uuid
from pathlib import Path, PosixPath, PurePath
from urllib.parse import urlparse, unquote
import asyncio
if TYPE_CHECKING:
    import pandas as pd
from navconfig.logging import logging
from datamodel.parsers.json import JSONContent  # pylint: disable=E0611 # noqa
from ..stores.models import Document
## AI Models:
from ..models.google import GoogleModel
from ..models.groq import GroqModel
from ..clients.factory import LLMFactory
from parrot_loaders.splitters import (
    TokenTextSplitter,
    MarkdownTextSplitter,
    SemanticTextSplitter,
)
from ..stores.utils.chunking import LateChunkingProcessor
from ..conf import (
    DEFAULT_LLM_MODEL,
    DEFAULT_LLM_TEMPERATURE,
    DEFAULT_GROQ_MODEL,
    CUDA_DEFAULT_DEVICE,
    CUDA_DEFAULT_DEVICE_NUMBER
)


T = TypeVar('T')


class AbstractLoader(ABC):
    """
    Base class for all loaders.
    Loaders are responsible for loading data from various sources.
    """
    extensions: List[str] = ['.*']
    skip_directories: List[str] = []

    def __init__(
        self,
        source: Optional[Union[str, Path, List[Union[str, Path]]]] = None,
        *,
        tokenizer: Union[str, Callable] = None,
        text_splitter: Union[str, Callable] = None,
        source_type: str = 'file',
        language: str = 'en',
        **kwargs
    ):
        """
        Initialize the AbstractLoader.

        Args:
            source: Path, URL, or list of paths/URLs to load from
            tokenizer: Tokenizer to use (string model name or callable)
            text_splitter: Text splitter to use
            source_type: Type of source ('file', 'url', etc.)
            language: Default document language ISO code (e.g. ``"en"``,
                ``"es"``).  Propagated to every ``document_meta`` produced
                by this loader unless overridden per call.
            **kwargs: Additional keyword arguments for configuration
        """
        self.chunk_size: int = kwargs.get('chunk_size', 512)
        self.chunk_overlap: int = kwargs.get('chunk_overlap', 50)
        self.min_chunk_size: int = kwargs.get('min_chunk_size', 30)
        self.full_document: bool = kwargs.get('full_document', True)
        self.semaphore = asyncio.Semaphore(kwargs.get('semaphore', 10))
        self.extensions = kwargs.get('extensions', self.extensions)
        self.skip_directories = kwargs.get(
            'skip_directories',
            self.skip_directories
        )
        self.encoding = kwargs.get('encoding', 'utf-8')
        self._source_type = source_type
        self._recursive: bool = kwargs.get('recursive', False)
        self.category: str = kwargs.get('category', 'document')
        self.doctype: str = kwargs.get('doctype', 'text')
        self.language: str = language
        # Chunking configuration
        self._use_markdown_splitter: bool = kwargs.get('use_markdown_splitter', True)
        self._use_huggingface_splitter: bool = kwargs.get('use_huggingface_splitter', False)
        self._auto_detect_content_type: bool = kwargs.get('auto_detect_content_type', True)

        # Advanced features
        self._summarization = kwargs.get('summarization', False)
        self._summary_model: Optional[Any] = kwargs.get('summary_model', None)
        self._use_summary_pipeline: bool = kwargs.get('use_summary_pipeline', False)
        self._use_translation_pipeline: bool = kwargs.get('use_translation_pipeline', False)
        self._translation = kwargs.get('translation', False)

        # Handle source/path initialization
        self.path = None
        if source is not None:
            self.path = source
        elif 'path' in kwargs:
            self.path = kwargs['path']

        # Normalize path if it's a string. URL-like strings must be kept
        # verbatim: ``Path("https://example.com").resolve()`` corrupts the
        # scheme to ``/cwd/https:/example.com`` and makes ``load()`` dispatch
        # to ``from_path`` instead of ``from_url``, yielding zero documents
        # from loaders that expect URL sources (e.g. WebScrapingLoader).
        # Lists of URLs are also preserved as-is.
        def _is_url(value: Any) -> bool:
            return isinstance(value, str) and (
                value.startswith('http://') or value.startswith('https://')
            )

        if self.path is not None:
            if isinstance(self.path, list):
                # Don't resolve any element that looks like a URL.
                if any(_is_url(item) for item in self.path):
                    # Heterogeneous lists (mix of URLs and paths) are left
                    # untouched — the caller is responsible for them.
                    pass
                else:
                    # All-path list: leave as-is (downstream handles it).
                    pass
            elif _is_url(self.path):
                # Keep URL string untouched.
                pass
            elif isinstance(self.path, str):
                self.path = Path(self.path).resolve()
            elif isinstance(self.path, (Path, PurePath)):
                self.path = Path(self.path).resolve()

        # Tokenizer
        self.tokenizer = tokenizer
        # Text Splitter
        self.text_splitter = kwargs.get('text_splitter', None)
        self.markdown_splitter = kwargs.get('markdown_splitter', None)

        # Initialize text splitter based on configuration
        self._setup_text_splitters(tokenizer, text_splitter, kwargs)

        # Summarization Model:
        self.summarization_model = kwargs.get('summarizer', None)
        # LLM (if required)
        self._setup_llm(kwargs)
        # Logger
        self.logger = logging.getLogger(
            f"Parrot.Loaders.{self.__class__.__name__}"
        )
        # JSON encoder:
        self._encoder = JSONContent()
        # Use CUDA if available:
        self._setup_device(kwargs)

    def _get_token_splitter(
        self,
        model_name: str = "gpt-4.1-mini",
        chunk_size: int = 4000,
        chunk_overlap: int = 200
    ) -> TokenTextSplitter:
        """Create a TokenTextSplitter with common settings"""
        if self.text_splitter:
            return self.text_splitter
        return TokenTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            model_name=model_name
        )

    def _get_markdown_splitter(
        self,
        chunk_size: int = 4000,
        chunk_overlap: int = 200,
        strip_headers: bool = False
    ) -> MarkdownTextSplitter:
        """Create a MarkdownTextSplitter with common settings"""
        if self.text_splitter:
            return self.text_splitter
        return MarkdownTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            strip_headers=strip_headers
        )

    def _create_hf_token_splitter(
        self,
        model_name: str,
        chunk_size: int = 4000,
        chunk_overlap: int = 200
    ) -> TokenTextSplitter:
        """Create a TokenTextSplitter using a HuggingFace Tokenizer"""
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        return TokenTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            tokenizer=tokenizer
        )

    def _setup_text_splitters(self, tokenizer, text_splitter, kwargs):
        """Initialize text splitters based on configuration.

        Uses SemanticTextSplitter as the default splitter for both
        markdown and general text content. Falls back to TokenTextSplitter
        or HuggingFace splitters when explicitly configured.
        """
        # Always create a markdown splitter (for explicit markdown use)
        self.markdown_splitter = self._get_markdown_splitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap
        )

        # If user provided an explicit text_splitter, use it
        if text_splitter is not None:
            self.text_splitter = text_splitter
            return

        # Choose primary text splitter based on configuration
        if self._use_huggingface_splitter:
            self.text_splitter = self._create_hf_token_splitter(
                model_name=kwargs.get('model_name', 'gpt-4.1-mini'),
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap
            )
        elif not self._use_markdown_splitter:
            # Explicitly disabled markdown splitter — use TokenTextSplitter
            if isinstance(tokenizer, str):
                self.text_splitter = self._get_token_splitter(
                    model_name=tokenizer,
                    chunk_size=self.chunk_size,
                    chunk_overlap=self.chunk_overlap
                )
            elif callable(tokenizer):
                self.text_splitter = TokenTextSplitter(
                    chunk_size=self.chunk_size,
                    chunk_overlap=self.chunk_overlap,
                    tokenizer_function=tokenizer
                )
            else:
                self.text_splitter = TokenTextSplitter(
                    chunk_size=self.chunk_size,
                    chunk_overlap=self.chunk_overlap,
                    model_name=kwargs.get('model_name', 'gpt-4.1-mini')
                )
        else:
            # Default: SemanticTextSplitter (replaces MarkdownTextSplitter)
            self.text_splitter = SemanticTextSplitter(
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
                min_chunk_size=self.min_chunk_size,
                model_name=kwargs.get('model_name', 'gpt-4'),
            )

    def _setup_llm(self, kwargs):
        """Initialize LLM if required."""
        self._use_llm = kwargs.get('use_llm', False)
        self._llm_model = kwargs.get('llm_model', None)
        self._llm_model_kwargs = kwargs.get('model_kwargs', {})
        self._llm = kwargs.get('llm', None)
        if self._use_llm:
            self._llm = self.get_default_llm(
                model=self._llm_model,
                model_kwargs=self._llm_model_kwargs,
            )

    def get_default_llm(
        self,
        model: str = None,
        model_kwargs: dict = None,
        use_groq: bool = False,
        use_openai: bool = False
    ) -> Any:
        """Return a AI Client instance."""
        if not model_kwargs:
            model_kwargs = {
                "temperature": DEFAULT_LLM_TEMPERATURE,
                "top_k": 30,
                "top_p": 0.5,
            }
        if use_groq:
            return LLMFactory.create(
                llm=f"groq:{model or DEFAULT_GROQ_MODEL}" if model else "groq",
                model_kwargs=model_kwargs
            )
        elif use_openai:
            return LLMFactory.create(
                llm=f"openai:{model}" if model else "openai",
                model_kwargs=model_kwargs
            )
        return LLMFactory.create(
            llm=model or DEFAULT_LLM_MODEL,
            model_kwargs=model_kwargs
        )

    def _setup_device(self, kwargs):
        """Initialize device configuration."""
        self.device_name = kwargs.get('device', CUDA_DEFAULT_DEVICE)
        self.cuda_number = kwargs.get('cuda_number', CUDA_DEFAULT_DEVICE_NUMBER)
        self._device = None

    def _get_device(
        self,
        device_type: str = None,
        cuda_number: int = 0
    ):
        """
        Get device configuration for Torch and transformers.

        Returns:
            tuple: (pipeline_device_idx, torch_device, dtype)
            - pipeline_device_idx: int for HuggingFace pipeline (-1 for CPU, 0+ for GPU)
            - torch_device: torch.device object for model loading
            - dtype: torch data type for model weights
        """
        import torch
        # Default values for CPU usage
        pipeline_idx = -1  # This is what HuggingFace pipeline expects for CPU
        torch_dev = torch.device("cpu")
        dtype = torch.float32

        # Check if we're forcing CPU usage globally
        if CUDA_DEFAULT_DEVICE == 'cpu' or device_type == 'cpu':
            # CPU is explicitly requested
            return -1, torch.device('cpu'), torch.float32

        # Check for CUDA availability and use it if possible
        if torch.cuda.is_available():
            # For GPU, pipeline wants an integer index
            pipeline_idx = cuda_number  # 0 for first GPU, 1 for second, etc.
            torch_dev = torch.device(f"cuda:{cuda_number}")

            # Choose the best dtype for this GPU
            if torch.cuda.is_bf16_supported():
                dtype = torch.bfloat16
            else:
                dtype = torch.float16

            return pipeline_idx, torch_dev, dtype

        # Check for Apple Silicon GPU (MPS)
        if torch.backends.mps.is_available():
            # MPS is tricky - HuggingFace pipelines don't always support it well
            # We return "mps" as a string for pipeline, and torch.device for model
            # Note: You might need to handle this specially in your pipeline code
            return "mps", torch.device("mps"), torch.float32

        # Fallback to CPU if nothing else is available
        return -1, torch.device("cpu"), torch.float32

    def clear_cuda(self):
        self.tokenizer = None  # Reset the tokenizer
        self.text_splitter = None  # Reset the text splitter
        try:
            import torch
            torch.cuda.synchronize()  # Wait for all kernels to finish
            torch.cuda.empty_cache()  # Clear unused memory
        except Exception as e:
            self.logger.warning(f"Error clearing CUDA memory: {e}")

    async def __aenter__(self):
        """Open the loader if it has an open method."""
        # Check if the loader has an open method and call it
        if hasattr(self, "open"):
            await self.open()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Close the loader if it has a close method."""
        if hasattr(self, "close"):
            await self.close()
        return True

    def supported_extensions(self):
        """Get the supported file extensions."""
        return self.extensions

    def _detect_content_type(self, document: Document) -> str:
        """
        Auto-detect content type based on document metadata and content.

        Args:
            document: Document to analyze

        Returns:
            Content type string ('markdown', 'code', 'text', etc.)
        """
        if not self._auto_detect_content_type:
            return 'text'

        # Check metadata for hints
        metadata = document.metadata or {}
        filename = metadata.get('filename', '').lower()
        source_type = metadata.get('source_type', '').lower()

        # File extension based detection
        if filename.endswith(('.md', '.markdown')):
            return 'markdown'
        elif filename.endswith(('.py', '.pyx', '.js', '.java', '.cpp', '.c', '.go', '.rs')):
            return 'code'
        elif filename.endswith(('.html', '.htm', '.xml')):
            return 'html'
        elif source_type in ['markdown', 'md']:
            return 'markdown'

        # Content based detection
        content = document.page_content[:1000].lower()  # Check first 1000 chars

        # Simple heuristics for markdown
        markdown_indicators = ['#', '```', '**', '*', '[', '](', '|', '---']
        markdown_score = sum(1 for indicator in markdown_indicators if indicator in content)

        if markdown_score >= 3:  # If multiple markdown indicators found
            return 'markdown'

        # Default to text
        return 'text'

    def _select_splitter_for_content(self, content_type: str):
        """Select the appropriate text splitter based on content type.

        Both 'markdown' and 'text' content types route to the configured
        text_splitter (SemanticTextSplitter by default). Only 'code'
        content uses TokenTextSplitter for precise token-based splitting.

        Args:
            content_type: Detected or specified content type.

        Returns:
            Appropriate text splitter.
        """
        if content_type == 'code':
            # Use token splitter with smaller chunks for code
            return TokenTextSplitter(
                chunk_size=min(self.chunk_size, 2048),
                chunk_overlap=self.chunk_overlap,
                model_name='gpt-4'
            )
        else:
            # Both 'markdown' and 'text' use semantic splitter
            return self.text_splitter

    def is_valid_path(self, path: Union[str, Path]) -> bool:
        """Check if a path is valid."""
        if self.extensions == '*':
            return True
        if isinstance(path, str):
            path = Path(path)
        if not path.exists():
            return False
        if path.is_dir() and path.name in self.skip_directories:
            return False
        if path.is_file():
            if path.suffix not in self.extensions:
                return False
            if path.name.startswith("."):
                return False
            # check if file is empty
            if path.stat().st_size == 0:
                return False
            # check if file is inside of skip directories:
            for skip_dir in self.skip_directories:
                if path.is_relative_to(skip_dir):
                    return False
        return True

    @abstractmethod
    async def _load(self, source: Union[str, PurePath], **kwargs) -> List[Document]:
        """Load a single data/url/file from a source and return it as a Parrot Document.

        Args:
            source (str): The source of the data.

        Returns:
            List[Document]: A list of Parrot Documents.
        """
        pass

    async def from_path(
        self,
        path: Union[str, Path],
        recursive: bool = False,
        **kwargs
    ) -> List[asyncio.Task]:
        """
        Load data from a path.
        """
        tasks = []
        if isinstance(path, str):
            path = PurePath(path)
        if path.is_dir():
            for ext in self.extensions:
                glob_method = path.rglob if recursive else path.glob
                # Use glob to find all files with the specified extension
                for item in glob_method(f'*{ext}'):
                    # Check if the item is a directory and if it should be skipped
                    if set(item.parts).isdisjoint(self.skip_directories):
                        if self.is_valid_path(item):
                            tasks.append(
                                asyncio.create_task(self._load(item, **kwargs))
                            )
        elif path.is_file():
            if self.is_valid_path(path):
                tasks.append(
                    asyncio.create_task(self._load(path, **kwargs))
                )
        else:
            self.logger.warning(
                f"Path {path} is not valid."
            )
        return tasks

    async def from_url(
        self,
        url: Union[str, List[str]],
        **kwargs
    ) -> List[asyncio.Task]:
        """
        Load data from a URL.
        """
        tasks = []
        if isinstance(url, str):
            url = [url]
        for item in url:
            tasks.append(
                asyncio.create_task(self._load(item, **kwargs))
            )
        return tasks

    async def from_dataframe(
        self,
        source: pd.DataFrame,
        **kwargs
    ) -> List[asyncio.Task]:
        """
        Load data from a pandas DataFrame.
        """
        tasks = []
        try:
            import pandas as pd
            if isinstance(source, pd.DataFrame):
                tasks.append(
                    asyncio.create_task(self._load(source, **kwargs))
                )
            else:
                self.logger.warning(
                    f"Source {source} is not a valid pandas DataFrame."
                )
        except ImportError:
            self.logger.warning("Pandas not installed, cannot load from DataFrame")
        return tasks

    def chunkify(self, lst: List[T], n: int = 50) -> Generator[List[T], None, None]:
        """Split a List of objects into chunks of size n.

        Args:
            lst: The list to split into chunks
            n: The maximum size of each chunk

        Yields:
            List[T]: Chunks of the original list, each of size at most n
        """
        for i in range(0, len(lst), n):
            yield lst[i:i + n]

    async def _async_map(self, func: Callable, iterable: list) -> list:
        """Run a function on a list of items asynchronously."""
        async def async_func(item):
            async with self.semaphore:
                return await func(item)

        tasks = [async_func(item) for item in iterable]
        return await asyncio.gather(*tasks)

    async def _load_tasks(self, tasks: list) -> list:
        """Load a list of tasks asynchronously."""
        results = []

        if not tasks:
            return results

        # Create a controlled task function to limit concurrency
        async def controlled_task(task):
            async with self.semaphore:
                try:
                    return await task
                except Exception as e:
                    self.logger.error(f"Task error: {e}")
                    return e

        for chunk in self.chunkify(tasks, self.chunk_size):
            # Wrap each task with semaphore control
            controlled_tasks = [controlled_task(task) for task in chunk]
            result = await asyncio.gather(*controlled_tasks, return_exceptions=True)
            if result:
                for res in result:
                    if isinstance(res, Exception):
                        # Handle the exception
                        self.logger.error(f"Error loading {res}")
                    else:
                        # Handle both single documents and lists of documents
                        if isinstance(res, list):
                            results.extend(res)
                        else:
                            results.append(res)

        # Validate canonical metadata on every returned Document once.
        # Do NOT call _validate_metadata inside chunk_documents — it would
        # run on every chunk and duplicate the per-document work.
        for doc in results:
            if isinstance(doc, Document):
                doc.metadata = self._validate_metadata(doc.metadata)

        return results

    async def load(
        self,
        source: Optional[Any] = None,
        split_documents: bool = True,
        late_chunking: bool = False,
        vector_store=None,
        store_full_document: bool = True,
        auto_detect_content_type: bool = None,
        **kwargs
    ) -> List[Document]:
        """
        Load data from a source and return it as a list of Documents.

        The source can be:
        - None: Uses self.path attribute if available
        - Path or str: Treated as file path or directory
        - List[str/Path]: Treated as list of file paths
        - URL string: Treated as a URL
        - List of URLs: Treated as list of URLs

        Args:
            source (Optional[Any]): The source of the data.
            split_documents (bool): Whether to split documents into chunks, defaults to True
            late_chunking (bool): Whether to use late chunking strategy
            vector_store: Vector store instance (required for late chunking)
            store_full_document (bool): Whether to store full documents alongside chunks
            auto_detect_content_type (bool): Override auto-detection setting
            **kwargs: Additional keyword arguments

        Returns:
            List[Document]: A list of Documents (chunked if requested).
        """
        tasks = []
        # If no source is provided, use self.path
        if source is None:
            if self.path is None:
                raise ValueError(
                    "No source provided and self.path is not set. "
                    "Please provide a source parameter or set path during initialization."
                )
            source = self.path

        if isinstance(source, (str, Path, PosixPath, PurePath)):
            # Check if it's a URL
            if isinstance(source, str) and (
                source.startswith('http://') or source.startswith('https://')
            ):
                tasks = await self.from_url(source, **kwargs)
            else:
                # Assume it's a file path or directory
                tasks = await self.from_path(
                    source,
                    recursive=self._recursive,
                    **kwargs
                )
        elif isinstance(source, list):
            # Check if it's a list of URLs or paths
            if all(
                isinstance(item, str) and (
                    item.startswith('http://') or item.startswith('https://')
                ) for item in source
            ):
                tasks = await self.from_url(source, **kwargs)
            else:
                # Assume it's a list of file paths
                path_tasks = []
                for path in source:
                    path_tasks.extend(
                        await self.from_path(path, recursive=self._recursive, **kwargs)
                    )
                tasks = path_tasks
        else:
            # Check for DataFrame lazily
            is_dataframe = False
            try:
                import pandas as pd
                if isinstance(source, pd.DataFrame):
                    is_dataframe = True
                    tasks = await self.from_dataframe(source, **kwargs)
            except ImportError:
                pass
            
            if not is_dataframe:
                raise ValueError(
                    f"Unsupported source type: {type(source)}"
                )
        # Load tasks and get raw documents
        documents = []
        if tasks:
            results = await self._load_tasks(tasks)
            documents = results

        # Apply chunking if requested
        if split_documents and documents:
            self.logger.debug(
                f"Splitting {len(documents)} documents into chunks..."
            )

            if late_chunking and vector_store is None:
                raise ValueError(
                    "Vector store is required when using late_chunking=True"
                )

            documents = await self.chunk_documents(
                documents=documents,
                use_late_chunking=late_chunking,
                vector_store=vector_store,
                store_full_document=store_full_document,
                auto_detect_content_type=auto_detect_content_type
            )

            self.logger.debug(
                f"Document chunking complete: {len(documents)} final documents"
            )

        return documents

    # ------------------------------------------------------------------
    # Canonical keys for the closed-shape document_meta sub-dict.
    # Loaders MUST NOT add extra keys inside document_meta.
    # ------------------------------------------------------------------
    _CANONICAL_DOC_META_KEYS: frozenset = frozenset(
        {"source_type", "category", "type", "language", "title"}
    )
    _CANONICAL_TOP_LEVEL_KEYS: frozenset = frozenset(
        {"url", "source", "filename", "type", "source_type", "created_at",
         "category", "document_meta"}
    )

    def _derive_title(self, path: Union[str, PurePath]) -> str:
        """Derive a human-readable title from a path or URL.

        Rules (in order):
        1. ``pathlib.Path`` / ``PurePath`` → ``path.stem`` with underscores
           and hyphens replaced by spaces, title-cased.
        2. ``http(s)://...`` URL → last non-empty decoded path segment,
           stripped of common file extensions.
        3. Fallback → ``str(path)``.

        Args:
            path: A filesystem path or URL string.

        Returns:
            A non-empty title string (may still be ugly for edge cases).
        """
        if isinstance(path, PurePath):
            stem = path.stem or str(path)
            return stem.replace("_", " ").replace("-", " ").title()

        if isinstance(path, str):
            # URL detection
            if path.startswith("http://") or path.startswith("https://"):
                parsed = urlparse(path)
                segments = [
                    seg for seg in parsed.path.split("/") if seg
                ]
                if segments:
                    last = unquote(segments[-1])
                    # Strip common file extensions
                    for ext in (
                        ".html", ".htm", ".pdf", ".txt", ".md",
                        ".json", ".xml", ".csv"
                    ):
                        if last.lower().endswith(ext):
                            last = last[: -len(ext)]
                            break
                    return last.replace("_", " ").replace("-", " ").title()
                # Fallback for bare domain URLs
                return parsed.netloc or str(path)

            # Looks like a file path string — try to derive stem
            if "/" in path or "\\" in path:
                try:
                    stem = Path(path).stem
                    if stem:
                        return stem.replace("_", " ").replace("-", " ").title()
                except Exception:  # noqa: BLE001
                    pass

        return str(path)

    def _validate_metadata(self, metadata: dict) -> dict:
        """Non-fatal canonical metadata validator.

        Checks that *metadata* contains all required top-level keys and that
        ``metadata["document_meta"]`` holds exactly the five canonical keys.
        Any missing field is auto-filled with a sensible default and a
        ``WARNING`` is logged — this method **never raises**.

        Args:
            metadata: The metadata dict to validate (mutated in place).

        Returns:
            The (possibly patched) metadata dict.
        """
        # --- top-level canonical fields ---
        defaults = {
            "url": "",
            "source": "",
            "filename": "",
            "type": self.doctype,
            "source_type": self._source_type,
            "created_at": datetime.now().strftime("%Y-%m-%d, %H:%M:%S"),
            "category": self.category,
            "document_meta": {},
        }
        for key, default in defaults.items():
            if key not in metadata:
                self.logger.warning(
                    "Metadata missing canonical field '%s'; auto-filling "
                    "with default value. Loader: %s",
                    key,
                    self.__class__.__name__,
                )
                metadata[key] = default

        # --- document_meta closed-shape ---
        doc_meta = metadata.get("document_meta", {})
        if not isinstance(doc_meta, dict):
            self.logger.warning(
                "document_meta is not a dict (got %s); resetting. Loader: %s",
                type(doc_meta).__name__,
                self.__class__.__name__,
            )
            doc_meta = {}
            metadata["document_meta"] = doc_meta

        doc_meta_defaults = {
            "source_type": metadata.get("source_type", self._source_type),
            "category": metadata.get("category", self.category),
            "type": metadata.get("type", self.doctype),
            "language": self.language,
            "title": self._derive_title(metadata.get("url", "") or ""),
        }
        for key, default in doc_meta_defaults.items():
            if key not in doc_meta:
                self.logger.warning(
                    "document_meta missing canonical key '%s'; auto-filling. "
                    "Loader: %s",
                    key,
                    self.__class__.__name__,
                )
                doc_meta[key] = default

        # Strip any non-canonical keys from document_meta (move to top level)
        extra_keys = set(doc_meta.keys()) - self._CANONICAL_DOC_META_KEYS
        for key in extra_keys:
            self.logger.warning(
                "document_meta contains non-canonical key '%s'; hoisting to "
                "top level. Loader: %s",
                key,
                self.__class__.__name__,
            )
            metadata.setdefault(key, doc_meta.pop(key))

        return metadata

    def create_metadata(
        self,
        path: Union[str, PurePath],
        doctype: str = 'document',
        source_type: str = 'source',
        doc_metadata: Optional[dict] = None,
        *,
        language: Optional[str] = None,
        title: Optional[str] = None,
        **kwargs
    ) -> dict:
        """Build a canonical ``Document.metadata`` dict.

        The returned dict always contains:

        * Top-level: ``url``, ``source``, ``filename``, ``type``,
          ``source_type``, ``created_at``, ``category``, ``document_meta``,
          plus any extra ``**kwargs`` (loader-specific extras).
        * ``document_meta`` (closed shape): exactly
          ``{source_type, category, type, language, title}``.

        Legacy callers that pass ``doc_metadata`` continue to work:
        canonical keys in that dict are folded into ``document_meta``;
        non-canonical keys are hoisted to the top-level metadata.

        Args:
            path: Filesystem path or URL of the source document.
            doctype: Document type identifier (e.g. ``"pdf"``,
                ``"audio_transcript"``).
            source_type: High-level source kind (e.g. ``"file"``,
                ``"url"``, ``"video"``).
            doc_metadata: Legacy dict of additional metadata.  Canonical
                keys (``source_type``, ``category``, ``type``,
                ``language``, ``title``) are merged into ``document_meta``;
                all others become top-level metadata keys.
            language: Document language ISO code.  Defaults to
                ``self.language`` when ``None``.
            title: Human-readable title.  Defaults to
                ``self._derive_title(path)`` when ``None``.
            **kwargs: Loader-specific extras — become top-level keys in
                the returned metadata dict.  Must **not** be canonical
                ``document_meta`` keys.

        Returns:
            A metadata dict with canonical top-level keys and a
            closed-shape ``document_meta`` sub-dict.
        """
        if not doc_metadata:
            doc_metadata = {}

        # Resolve path-derived fields
        if isinstance(path, PurePath):
            origin = path.name
            url = f'file://{path}'
            filename = str(path)
        else:
            origin = path
            url = path
            filename = f'file://{path}'

        # Resolve language and title
        resolved_language = language if language is not None else self.language
        resolved_title = title if title is not None else self._derive_title(path)

        # Separate canonical keys in legacy doc_metadata from extras
        canonical_from_legacy: dict = {}
        extra_from_legacy: dict = {}
        for key, val in doc_metadata.items():
            if key in self._CANONICAL_DOC_META_KEYS:
                canonical_from_legacy[key] = val
            else:
                extra_from_legacy[key] = val

        # Canonical doc_metadata keys override derived values when present
        resolved_language = canonical_from_legacy.get("language", resolved_language)
        resolved_title = canonical_from_legacy.get("title", resolved_title)
        resolved_doctype = canonical_from_legacy.get("type", doctype)
        resolved_source_type = canonical_from_legacy.get(
            "source_type", source_type or self._source_type
        )
        resolved_category = canonical_from_legacy.get("category", self.category)

        document_meta = {
            "source_type": resolved_source_type,
            "category": resolved_category,
            "type": resolved_doctype,
            "language": resolved_language,
            "title": resolved_title,
        }

        metadata = {
            "url": url,
            "source": origin,
            "filename": filename,
            "type": resolved_doctype,
            "source_type": resolved_source_type,
            "created_at": datetime.now().strftime("%Y-%m-%d, %H:%M:%S"),
            "category": resolved_category,
            "document_meta": document_meta,
            # Extras from legacy doc_metadata — top level
            **extra_from_legacy,
            # Caller-supplied extras — top level
            **kwargs,
        }
        return metadata

    def create_document(
        self,
        content: Any,
        path: Union[str, PurePath],
        metadata: Optional[dict] = None,
        **kwargs
    ) -> Document:
        """Create a Parrot Document from content.

        If *metadata* is ``None``, ``create_metadata`` is called with
        *path*, ``self.doctype``, and ``self._source_type`` (plus any
        ``**kwargs``).  The resulting metadata is validated via
        ``_validate_metadata`` before the ``Document`` is constructed.

        Args:
            content: The text content of the document.
            path: Source path or URL (used when *metadata* is ``None``).
            metadata: Pre-built metadata dict.  When provided it is still
                passed through ``_validate_metadata`` so canonical fields
                are auto-filled if missing.
            **kwargs: Forwarded to ``create_metadata`` when *metadata* is
                ``None``.

        Returns:
            A ``Document`` with validated canonical metadata.
        """
        if metadata:
            _meta = metadata
        else:
            _meta = self.create_metadata(
                path=path,
                doctype=self.doctype,
                source_type=self._source_type,
                **kwargs
            )
        _meta = self._validate_metadata(_meta)
        return Document(
            page_content=content,
            metadata=_meta
        )

    async def summary_from_text(
        self,
        text: str,
        max_length: int = 500,
        min_length: int = 50
    ) -> str:
        """
        Get a summary of a text.
        """
        if not text:
            return ''
        try:
            summarizer = self.get_summarization_model()
            if self._use_summary_pipeline:
                # Use Huggingface pipeline
                content = summarizer(
                    text,
                    max_length=max_length,
                    min_length=min_length,
                    do_sample=False,
                    truncation=True
                )
                return content[0].get('summary_text', '')
            # Use Summarize Method from GroqClient
            system_prompt = f"""
Your job is to produce a final summary from the following text and identify the main theme.
- The summary should be concise and to the point.
- The summary should be no longer than {max_length} characters and no less than {min_length} characters.
- The summary should be in a single paragraph.
"""
            # Ensure the LLM client is initialized
            if not summarizer.client:
                summarizer.client = await summarizer.get_client()
            summary = await summarizer.summarize_text(
                text=text,
                model=GroqModel.LLAMA_3_3_70B_VERSATILE,
                system_prompt=system_prompt,
                temperature=0.1,
                max_tokens=1000,
                top_p=0.5
            )
            return summary.output
        except Exception as e:
            self.logger.error(
                f'ERROR on summary_from_text: {e}'
            )
            return ""

    def get_summarization_model(
        self,
        model_name: str = 'facebook/bart-large-cnn'
    ):
        if not self._summary_model:
            if self._use_summary_pipeline:
                from transformers import (
                    AutoModelForSeq2SeqLM,
                    AutoTokenizer,
                    pipeline
                )
                _, pipe_dev, torch_dtype = self._get_device()
                summarize_model = AutoModelForSeq2SeqLM.from_pretrained(
                    model_name,
                )
                summarize_tokenizer = AutoTokenizer.from_pretrained(
                    model_name,
                    padding_side="left"
                )
                self._summary_model = pipeline(
                    "summarization",
                    model=summarize_model,
                    tokenizer=summarize_tokenizer,
                    device=pipe_dev,             # 0 for CUDA, mps device, or -1
                    torch_dtype=torch_dtype if pipe_dev != -1 else None,
                )
            else:
                # Use Groq for Summarization:
                self._summary_model = LLMFactory.create(
                    llm=f"groq:{GroqModel.LLAMA_3_3_70B_VERSATILE}",
                    model_kwargs={
                        "temperature": 0.1,
                        "top_p": 0.5,
                    }
                )
        return self._summary_model

    def translate_text(
        self,
        text: str,
        source_lang: str = None,
        target_lang: str = "es"
    ) -> str:
        """
        Translate text from source language to target language.

        Args:
            text: Text to translate
            source_lang: Source language code (default: 'en')
            target_lang: Target language code (default: 'es')

        Returns:
            Translated text
        """
        if not text:
            return ''
        try:
            translator = self.get_translation_model(source_lang, target_lang)
            if self._use_translation_pipeline:
                # Use Huggingface pipeline
                content = translator(
                    text,
                    max_length=len(text) * 2,  # Allow for expansion in target language
                    truncation=True
                )
                return content[0].get('translation_text', '')
            else:
                # Use LLM for translation
                translation = translator.translate_text(
                    text=text,
                    source_lang=source_lang,
                    target_lang=target_lang,
                    model=GoogleModel.GEMINI_2_5_FLASH_LITE_PREVIEW,
                    temperature=0.1,
                    max_tokens=1000
                )
                return translation.output if hasattr(translation, 'output') else str(translation)
        except Exception as e:
            self.logger.error(f'ERROR on translate_text: {e}')
            return ""

    def get_translation_model(
        self,
        source_lang: str = "en",
        target_lang: str = "es",
        model_name: str = None
    ):
        """
        Get or create a translation model.

        Args:
            source_lang: Source language code
            target_lang: Target language code
            model_name: Optional model name override

        Returns:
            Translation model/chain
        """
        # Create a cache key for the language pair
        cache_key = f"{source_lang}_{target_lang}"

        # Check if we already have a model for this language pair
        if not hasattr(self, '_translation_models'):
            self._translation_models = {}

        if cache_key not in self._translation_models:
            if self._use_translation_pipeline:
                from transformers import (
                    AutoModelForSeq2SeqLM,
                    AutoTokenizer,
                    pipeline
                )
                # Select appropriate model based on language pair if not specified
                if model_name is None:
                    if source_lang == "en" and target_lang in ["es", "fr", "de", "it", "pt", "ru"]:
                        model_name = "Helsinki-NLP/opus-mt-en-ROMANCE"
                    elif source_lang in ["es", "fr", "de", "it", "pt"] and target_lang == "en":
                        model_name = "Helsinki-NLP/opus-mt-ROMANCE-en"
                    else:
                        # Default to a specific model for the language pair
                        model_name = f"Helsinki-NLP/opus-mt-{source_lang}-{target_lang}"

                try:
                    translate_model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
                    translate_tokenizer = AutoTokenizer.from_pretrained(model_name)

                    self._translation_models[cache_key] = pipeline(
                        "translation",
                        model=translate_model,
                        tokenizer=translate_tokenizer
                    )
                except Exception as e:
                    self.logger.error(
                        f"Error loading translation model {model_name}: {e}"
                    )
                    # Fallback to using LLM for translation
                    self._use_translation_pipeline = False

            if not self._use_translation_pipeline:
                # Use LLM for translation
                translation_model = self.get_default_llm(
                    model=GoogleModel.GEMINI_2_5_FLASH_LITE_PREVIEW
                )
                self._translation_models[cache_key] = translation_model

        return self._translation_models[cache_key]

    def create_translated_document(
        self,
        content: str,
        metadata: dict,
        source_lang: str = "en",
        target_lang: str = "es"
    ) -> Document:
        """
        Create a document with translated content.

        Args:
            content: Original content
            metadata: Document metadata
            source_lang: Source language code
            target_lang: Target language code

        Returns:
            Document with translated content
        """
        translated_content = self.translate_text(content, source_lang, target_lang)

        # Clone the metadata and add translation info
        translation_metadata = metadata.copy()
        translation_metadata.update({
            "original_language": source_lang,
            "language": target_lang,
            "is_translation": True
        })

        return Document(
            page_content=translated_content,
            metadata=translation_metadata
        )

    def saving_file(self, filename: PurePath, data: Any):
        """Save data to a file.

        Args:
            filename (PurePath): The path to the file.
            data (Any): The data to save.
        """
        with open(filename, 'wb') as f:
            f.write(data)
            f.flush()
        print(f':: Saved File on {filename}')

    async def chunk_documents(
        self,
        documents: List[Document],
        use_late_chunking: bool = False,
        vector_store=None,
        store_full_document: bool = True,
        auto_detect_content_type: bool = None
    ) -> List[Document]:
        """
        Chunk documents using the configured text splitter or late chunking strategy.

        Args:
            documents: List of documents to chunk
            use_late_chunking: Whether to use late chunking strategy
            vector_store: Vector store instance (required for late chunking)
            store_full_document: Whether to store full documents alongside chunks (late chunking only)
            auto_detect_content_type: Override auto-detection setting

        Returns:
            List of chunked documents
        """
        if use_late_chunking:
            return await self._chunk_with_late_chunking(
                documents, vector_store, store_full_document
            )
        else:
            return self._chunk_with_text_splitter(
                documents, auto_detect_content_type
            )

    def _chunk_with_text_splitter(
        self,
        documents: List[Document],
        auto_detect_content_type: bool = None
    ) -> List[Document]:
        """
        Chunk documents using regular text splitters.

        Args:
            documents: List of documents to chunk
            auto_detect_content_type: Override auto-detection setting

        Returns:
            List of chunked documents
        """
        chunked_docs = []
        detect_content = auto_detect_content_type if auto_detect_content_type is not None else self._auto_detect_content_type  # noqa

        # Content kinds that are ATOMIC-by-design — loaders emit them as
        # already-final units (e.g. a single HTML tag, a named selector hit,
        # a single video URL). Re-splitting them pollutes the vector store
        # with sub-min_chunk_size chunks because the splitter has no sibling
        # content inside the same Document to merge them with.
        _ATOMIC_CONTENT_KINDS = frozenset({
            'fragment',
            'video_link',
            'navigation',
            'selector',
            'faq',
            'table',
            'video_dialog',
            'video_transcript',
            'jsonld-product',
            'jsonld-event',
            'jsonld-person',
            'jsonld-place',
            'jsonld-recipe',
            'jsonld-article',
            'jsonld-organization',
            'jsonld-howto',
            'jsonld-breadcrumb',
        })

        for doc in documents:
            try:
                # Skip atomic/pre-chunked documents: pass them through as-is.
                content_kind = doc.metadata.get('content_kind')
                if content_kind in _ATOMIC_CONTENT_KINDS:
                    self.logger.debug(
                        "Skipping split for atomic content_kind=%s (len=%d)",
                        content_kind, len(doc.page_content or ''),
                    )
                    # Mark as a chunk so downstream stores keep a consistent
                    # schema, but don't re-split it.
                    passthrough_meta = {
                        **doc.metadata,
                        'is_chunk': True,
                        'chunk_index': 0,
                        'total_chunks': 1,
                        'splitter_type': 'passthrough',
                    }
                    chunked_docs.append(Document(
                        page_content=doc.page_content,
                        metadata=passthrough_meta,
                    ))
                    continue

                # Detect content type and select appropriate splitter
                if detect_content:
                    content_type = self._detect_content_type(doc)
                    splitter = self._select_splitter_for_content(content_type)
                    # self.logger.debug(f"Detected content type: {content_type} for document")
                else:
                    content_type = 'text'
                    splitter = self.text_splitter

                # Create chunks using the selected splitter
                chunks = splitter.create_chunks(
                    text=doc.page_content,
                    metadata=doc.metadata
                )

                # Convert chunks to Document objects
                for chunk in chunks:
                    chunked_doc = Document(
                        page_content=chunk.text,
                        metadata={
                            **chunk.metadata,
                            'chunk_id': chunk.chunk_id,
                            'token_count': chunk.token_count,
                            'start_position': chunk.start_position,
                            'end_position': chunk.end_position,
                            'content_type': content_type,
                            'splitter_type': splitter.__class__.__name__,
                            'is_chunk': True,
                            'parent_document_id': doc.metadata.get('document_id', f"doc_{uuid.uuid4().hex[:8]}")
                        }
                    )
                    chunked_docs.append(chunked_doc)

            except Exception as e:
                self.logger.error(f"Error chunking document: {e}")
                # Fall back to adding the original document
                chunked_docs.append(doc)

        self.logger.info(f"Chunked {len(documents)} documents into {len(chunked_docs)} chunks")
        return chunked_docs

    async def _chunk_with_late_chunking(
        self,
        documents: List[Document],
        vector_store=None,
        store_full_document: bool = True,
        parent_chunk_threshold_tokens: int = 16000,
        parent_chunk_size_tokens: int = 4000,
        parent_chunk_overlap_tokens: int = 200,
    ) -> List[Document]:
        """Chunk documents using the late chunking strategy.

        Routing logic (FEAT-128):
        - Documents whose length exceeds ``parent_chunk_threshold_tokens``
          are routed through the **3-level path**:
          ``document → parent_chunks → child_chunks``.
          The original document is NOT stored as a parent row; only
          parent_chunks and their children are persisted.
        - Documents at or below the threshold use the existing **2-level
          path** (``document → child_chunks``, with the original document
          stored as the parent row when ``store_full_document=True``).
          Behaviour on this path is byte-equal to the pre-FEAT-128 code.

        Args:
            documents: List of documents to chunk.
            vector_store: Vector store instance (required for embedding).
            store_full_document: When True and using the 2-level path, store
                the original document as a parent row.  Ignored on the
                3-level path (original document is never stored there).
            parent_chunk_threshold_tokens: Documents longer than this
                threshold (in characters) are split via the 3-level path.
                Default 16000 (per spec §8 final decision).
            parent_chunk_size_tokens: Target size of each parent_chunk on
                the 3-level path (in characters).  Default 4000.
            parent_chunk_overlap_tokens: Overlap between adjacent
                parent_chunks on the 3-level path (in characters).
                Default 200.  Must be < ``parent_chunk_size_tokens``.

        Returns:
            List of :class:`Document` objects ready for vector store
            insertion.  Includes parent_chunk docs (with
            ``document_type='parent_chunk'``) and child docs (with
            ``is_chunk=True``) for 3-level documents, or full-doc parent
            plus child docs for 2-level documents.
        """
        if LateChunkingProcessor is None:
            self.logger.warning(
                "LateChunkingProcessor not available, falling back to regular chunking"
            )
            return self._chunk_with_text_splitter(documents)

        if vector_store is None:
            raise ValueError("Vector store is required for late chunking strategy")

        chunked_docs = []

        # Initialize late chunking processor
        chunking_processor = LateChunkingProcessor(
            vector_store=vector_store,
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap
        )

        for doc_idx, document in enumerate(documents):
            try:
                document_id = document.metadata.get(
                    'document_id',
                    f"doc_{doc_idx:06d}_{uuid.uuid4().hex[:8]}"
                )

                # FEAT-128: Route by document size.
                token_count = chunking_processor._count_tokens(document.page_content)

                if token_count > parent_chunk_threshold_tokens:
                    # ── 3-level path ────────────────────────────────────────
                    # Oversized doc: split into parent_chunks first, then
                    # child chunks per parent_chunk.  Original doc NOT stored.
                    self.logger.info(
                        "Document %s (%d chars) exceeds threshold %d — "
                        "using 3-level chunking path.",
                        document_id, token_count, parent_chunk_threshold_tokens,
                    )
                    parent_chunks, child_infos = (
                        await chunking_processor.process_document_three_level(
                            document_text=document.page_content,
                            document_id=document_id,
                            metadata=document.metadata,
                            parent_chunk_size_tokens=parent_chunk_size_tokens,
                            parent_chunk_overlap_tokens=parent_chunk_overlap_tokens,
                        )
                    )
                    # Emit parent_chunk docs first, then child docs.
                    chunked_docs.extend(parent_chunks)
                    for child_info in child_infos:
                        chunked_docs.append(
                            Document(
                                page_content=child_info.chunk_text,
                                metadata=child_info.metadata,
                            )
                        )

                else:
                    # ── 2-level path (unchanged behaviour) ──────────────────
                    _, chunk_infos = await chunking_processor.process_document_late_chunking(
                        document_text=document.page_content,
                        document_id=document_id,
                        metadata=document.metadata
                    )

                    # Store full document if requested
                    if store_full_document:
                        full_doc_metadata = {
                            **(document.metadata or {}),
                            'document_id': document_id,
                            'is_full_document': True,
                            'total_chunks': len(chunk_infos),
                            'document_type': 'parent',
                            'chunking_strategy': 'late_chunking'
                        }
                        chunked_docs.append(
                            Document(
                                page_content=document.page_content,
                                metadata=full_doc_metadata,
                            )
                        )

                    # Add all chunks as documents
                    for chunk_info in chunk_infos:
                        chunked_docs.append(
                            Document(
                                page_content=chunk_info.chunk_text,
                                metadata=chunk_info.metadata,
                            )
                        )

            except Exception as e:
                self.logger.error(f"Error in late chunking for document {doc_idx}: {e}")
                # Fall back to adding the original document
                chunked_docs.append(document)

        self.logger.info(
            f"Late chunking processed {len(documents)} documents into {len(chunked_docs)} items"
        )
        return chunked_docs
