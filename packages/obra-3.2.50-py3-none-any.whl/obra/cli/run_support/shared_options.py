"""Shared Typer Option definitions for `obra run` and `obra derive`.

Eliminates duplication by defining common CLI options as Annotated type
aliases. Each command function uses these aliases in its signature,
ensuring consistent help text and flag names.

Convention: Annotated aliases carry only the Option/Argument *metadata*
(flag names, help text, etc.). The **default value** is set via ``=``
in each function signature, keeping Python parameter ordering valid.

The CommonRunOptions dataclass collects the resolved values after Typer
has parsed them, for convenient forwarding to prepare_*_invocation().
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import typer

from obra.review.config import ALLOWED_AGENTS

# ---------------------------------------------------------------------------
# Annotated type aliases for shared Typer Options
#
# Defaults are omitted from the Annotated metadata. Each call site sets
# the default via ``= None``, ``= False``, or ``= 0`` in its signature.
# ---------------------------------------------------------------------------

OptObjective = Annotated[
    str | None,
    typer.Argument(help="What you want Obra to accomplish"),
]

OptWorkingDir = Annotated[
    str | None,
    typer.Option(
        "--dir",
        "-d",
        help="Working directory (defaults to current directory). WSL UNC paths are auto-converted.",
        rich_help_panel="Session",
    ),
]

OptProjectId = Annotated[
    str | None,
    typer.Option("--project", help="Project ID override (optional)", rich_help_panel="Session"),
]

OptDomain = Annotated[
    str | None,
    typer.Option(
        "--domain",
        help="Domain module name (e.g., software, business)",
        rich_help_panel="Session",
    ),
]

OptResumeSession = Annotated[
    str | None,
    typer.Option(
        "--resume", "-r", help="Resume an existing session by ID", rich_help_panel="Session"
    ),
]

OptContinueFrom = Annotated[
    str | None,
    typer.Option(
        "--continue-from",
        "-c",
        help=(
            "Continue from a failed/escalated session (creates new session, skips completed tasks; "
            "uses original objective unless overridden)"
        ),
        rich_help_panel="Session",
    ),
]

OptPlanId = Annotated[
    str | None,
    typer.Option(
        "--plan-id",
        help=(
            "Use an uploaded plan by ID (from 'obra plans upload'). "
            "Requires local YAML at docs/development/{PLAN_ID}_MACHINE_PLAN.json."
        ),
        rich_help_panel="Session",
    ),
]

OptPlanFile = Annotated[
    Path | None,
    typer.Option(
        "--plan-file", help="Upload and use a plan file in one step", rich_help_panel="Session"
    ),
]

OptModel = Annotated[
    str | None,
    typer.Option(
        "--model",
        "-m",
        help="Implementation model (e.g., opus, gpt-5.2, gemini-2.5-flash)",
        rich_help_panel="Model & Provider",
    ),
]

OptFastModel = Annotated[
    str | None,
    typer.Option(
        "--fast-model",
        help="Fast tier model override (used for extraction and quick validation)",
        rich_help_panel="Model & Provider",
    ),
]

OptHighModel = Annotated[
    str | None,
    typer.Option(
        "--high-model",
        help="High tier model override (used for complex reasoning)",
        rich_help_panel="Model & Provider",
    ),
]

OptImplProvider = Annotated[
    str | None,
    typer.Option(
        "--impl-provider",
        "-p",
        help="Implementation provider (anthropic, openai, google). Requires provider CLI (claude/codex/gemini).",
        rich_help_panel="Model & Provider",
    ),
]

OptReasoningLevel = Annotated[
    str | None,
    typer.Option(
        "--reasoning-level",
        "-t",
        help="Thinking/reasoning level (off, low, medium, high, maximum)",
        rich_help_panel="Model & Provider",
    ),
]

OptNoExtendedThinking = Annotated[
    bool,
    typer.Option(
        "--no-extended-thinking",
        help="Disable extended thinking for derivation (equivalent to --reasoning-level off)",
        rich_help_panel="Model & Provider",
    ),
]

OptVerbose = Annotated[
    int,
    typer.Option(
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
        rich_help_panel="Output",
    ),
]

OptInteractive = Annotated[
    bool,
    typer.Option(
        "--interactive",
        help="Enable interactive prompts (stdin-driven approvals). Default is headless.",
        rich_help_panel="Output",
    ),
]

OptNonInteractive = Annotated[
    bool,
    typer.Option(
        "--non-interactive",
        help="Explicit alias for headless mode (the default). Redundant but readable.",
        rich_help_panel="Output",
    ),
]

OptStream = Annotated[
    bool,
    typer.Option(
        "--stream", "-s", help="Enable real-time LLM output streaming", rich_help_panel="Output"
    ),
]

OptPlanOnly = Annotated[
    bool,
    typer.Option(
        "--plan-only",
        help="Create plan without executing (client-side exit after planning)",
        rich_help_panel="Planning & Execution",
    ),
]

OptPermissive = Annotated[
    bool,
    typer.Option(
        "--permissive",
        help="Bypass P1 planning blockers (proceed with warnings)",
        rich_help_panel="Planning & Execution",
    ),
]

OptDefaultsJson = Annotated[
    bool,
    typer.Option(
        "--defaults-json",
        help="Print proposed defaults as JSON and exit when refinement is blocked",
        rich_help_panel="Planning & Execution",
    ),
]

OptNoCloseout = Annotated[
    bool,
    typer.Option(
        "--no-closeout",
        help="Skip close-out story injection",
        rich_help_panel="Planning & Execution",
    ),
]

OptSkipIntent = Annotated[
    bool,
    typer.Option(
        "--skip-intent",
        help="Skip intent generation for vague objectives",
        rich_help_panel="Planning & Execution",
    ),
]

OptReviewIntent = Annotated[
    bool,
    typer.Option(
        "--review-intent",
        help="Display generated intent and prompt for approval (requires --interactive)",
        rich_help_panel="Planning & Execution",
    ),
]

OptIsolated = Annotated[
    bool | None,
    typer.Option(
        "--isolated",
        help="Run agent in isolated environment (prevents reading host CLI config)",
        rich_help_panel="Planning & Execution",
    ),
]

OptNoIsolated = Annotated[
    bool | None,
    typer.Option(
        "--no-isolated",
        help="Disable isolation (use host CLI config, even in CI)",
        rich_help_panel="Planning & Execution",
    ),
]

OptFullReview = Annotated[
    bool,
    typer.Option(
        "--full-review",
        help="Run all review agents (overrides auto-detection)",
        rich_help_panel="Review (software domain)",
    ),
]

OptSkipReview = Annotated[
    bool,
    typer.Option(
        "--skip-review",
        help="Skip the review phase entirely",
        rich_help_panel="Review (software domain)",
    ),
]

OptReviewAgents = Annotated[
    str | None,
    typer.Option(
        "--review-agents",
        help=f"Comma-separated review agents to run ({', '.join(ALLOWED_AGENTS)})",
        rich_help_panel="Review (software domain)",
    ),
]

OptWithSecurity = Annotated[
    bool,
    typer.Option(
        "--with-security",
        help="Add the security review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptWithTesting = Annotated[
    bool,
    typer.Option(
        "--with-testing",
        help="Add the testing review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptWithDocs = Annotated[
    bool,
    typer.Option(
        "--with-docs",
        help="Add the docs review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptWithCodeQuality = Annotated[
    bool,
    typer.Option(
        "--with-code-quality",
        help="Add the code_quality review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptNoSecurity = Annotated[
    bool,
    typer.Option(
        "--no-security",
        help="Remove the security review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptNoTesting = Annotated[
    bool,
    typer.Option(
        "--no-testing",
        help="Remove the testing review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptNoDocs = Annotated[
    bool,
    typer.Option(
        "--no-docs",
        help="Remove the docs review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptNoCodeQuality = Annotated[
    bool,
    typer.Option(
        "--no-code-quality",
        help="Remove the code_quality review agent",
        rich_help_panel="Review (software domain)",
    ),
]

OptReviewFormat = Annotated[
    str | None,
    typer.Option(
        "--review-format",
        help="Review output format (text or json)",
        show_choices=True,
        rich_help_panel="Review (software domain)",
    ),
]

OptReviewQuiet = Annotated[
    bool,
    typer.Option(
        "--review-quiet",
        help="Suppress review output",
        rich_help_panel="Review (software domain)",
    ),
]

OptReviewSummaryOnly = Annotated[
    bool,
    typer.Option(
        "--review-summary-only",
        help="Show only review summary counts",
        rich_help_panel="Review (software domain)",
    ),
]

OptFailOnP1 = Annotated[
    bool,
    typer.Option(
        "--fail-on-p1",
        help="Exit with status 1 when P1 findings are present",
        rich_help_panel="Review (software domain)",
    ),
]

OptFailOnP2 = Annotated[
    bool,
    typer.Option(
        "--fail-on-p2",
        help="Exit with status 1 when P1 or P2 findings are present",
        rich_help_panel="Review (software domain)",
    ),
]

OptReviewTimeout = Annotated[
    int | None,
    typer.Option(
        "--review-timeout",
        min=1,
        help="Per-agent review timeout in seconds",
        rich_help_panel="Review (software domain)",
    ),
]

OptAutoReport = Annotated[
    bool,
    typer.Option(
        "--auto-report",
        help="Automatically submit bug reports on failure (no prompt, for CI/CD)",
        rich_help_panel="Review (software domain)",
    ),
]

OptSkipGitCheck = Annotated[
    bool,
    typer.Option(
        "--skip-git-check",
        help="Skip git repository validation (GIT-HARD-001)",
        rich_help_panel="Advanced",
    ),
]

OptAutoInitGit = Annotated[
    bool,
    typer.Option(
        "--auto-init-git",
        help="Auto-initialize git repository if not present (GIT-HARD-001)",
        rich_help_panel="Advanced",
    ),
]

OptSkipQualityCheck = Annotated[
    bool,
    typer.Option(
        "--skip-quality-check",
        help="Skip UserPlan quality assessment (for debugging, testing, or high-confidence plans)",
        rich_help_panel="Advanced",
    ),
]

OptSkipComplexityCheck = Annotated[
    bool,
    typer.Option(
        "--skip-complexity-check",
        help="Skip complexity estimation for derived plan items (for faster derivation)",
        rich_help_panel="Advanced",
    ),
]

OptSkipExplore = Annotated[
    bool,
    typer.Option(
        "--skip-explore",
        help="Skip automatic codebase exploration before derivation (FEAT-AUTO-EXPLORE-001)",
        rich_help_panel="Advanced",
    ),
]

OptForceExplore = Annotated[
    bool,
    typer.Option(
        "--force-explore",
        help="Force codebase exploration even for simple objectives (FEAT-AUTO-EXPLORE-001)",
        rich_help_panel="Advanced",
    ),
]

OptLocal = Annotated[
    bool,
    typer.Option(
        "--local",
        help="Use local Firebase emulator instead of production (requires emulators running)",
        rich_help_panel="Advanced",
    ),
]


# ---------------------------------------------------------------------------
# Dataclass to collect resolved common option values
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CommonRunOptions:
    """Collected common CLI options shared between ``obra run`` and ``obra derive``.

    Populated after Typer has parsed the CLI arguments. Passed to
    ``prepare_run_invocation`` / ``prepare_derive_invocation`` to avoid
    repeating every keyword argument.
    """

    objective: str | None = None
    working_dir: str | None = None
    project_id: str | None = None
    domain: str | None = None
    resume_session: str | None = None
    continue_from: str | None = None
    plan_id: str | None = None
    plan_file: Path | None = None
    model: str | None = None
    fast_model: str | None = None
    high_model: str | None = None
    impl_provider: str | None = None
    reasoning_level: str | None = None
    no_extended_thinking: bool = False
    verbose: int = 0
    interactive: bool = False
    non_interactive: bool = False
    stream: bool = False
    plan_only: bool = False
    permissive: bool = False
    defaults_json: bool = False
    no_closeout: bool = False
    skip_intent: bool = False
    review_intent: bool = False
    isolated: bool | None = None
    no_isolated: bool | None = None
    full_review: bool = False
    skip_review: bool = False
    review_agents: str | None = None
    with_security: bool = False
    with_testing: bool = False
    with_docs: bool = False
    with_code_quality: bool = False
    no_security: bool = False
    no_testing: bool = False
    no_docs: bool = False
    no_code_quality: bool = False
    review_format: str | None = None
    review_quiet: bool = False
    review_summary_only: bool = False
    fail_on_p1: bool = False
    fail_on_p2: bool = False
    review_timeout: int | None = None
    auto_report: bool = False
    skip_git_check: bool = False
    auto_init_git: bool = False
    skip_quality_check: bool = False
    skip_complexity_check: bool = False
    skip_explore: bool = False
    force_explore: bool = False
    local: bool = False

    def to_dict(self) -> dict[str, object]:
        """Return a plain dict of all fields (for kwarg-spreading)."""
        from dataclasses import fields as dc_fields

        return {f.name: getattr(self, f.name) for f in dc_fields(self)}
