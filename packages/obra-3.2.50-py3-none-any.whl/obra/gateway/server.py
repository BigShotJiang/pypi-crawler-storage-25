"""Gateway server — FastAPI application bridging HTTP/WebSocket clients to HybridOrchestrator."""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import subprocess
import threading
from contextlib import asynccontextmanager
from math import ceil
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from obra import __version__
from obra.config.loaders import (
    get_gateway_assistant_config,
    get_gateway_config,
    get_timeout,
    get_gateway_transcription_config,
)
from obra.gateway.auth import get_auth_dependency, resolve_gateway_auth_token
from obra.gateway.automation.profile import (
    GATEWAY_PROFILE_PRIVATE_TAILNET,
    resolve_gateway_automation_profile,
)
from obra.gateway.errors import (
    GatewayAPIError,
    gateway_error_handler,
    gateway_http_exception_handler,
)
from obra.gateway.pipeline_session import PipelineSessionManager
from obra.gateway.security.client_ip import extract_client_ip_from_request
from obra.gateway.security.rate_limit import TokenBucketRateLimiter
from obra.gateway.security.scopes import GatewayScope, require_scope
from obra.gateway.output_delivery import OutputDeliveryService
from obra.gateway.session_manager import SessionManager
from obra.gateway.webhook.cleanup import WebhookCleanupService
from obra.gateway.webhook.delivery import WebhookDeliveryService
from obra.gateway.webhook.dispatcher import WebhookDispatcher
from obra.gateway.webhook.store import InMemoryWebhookStore
from obra.gateway.workflow_studio.local_project_store import LocalProjectStore
from obra.gateway.workflow_studio.local_workflow_store import LocalWorkflowStore

logger = logging.getLogger(__name__)


def _resolve_webhook_config(config: dict[str, Any]) -> dict[str, Any]:
    return {
        "max_per_owner": int(config["webhooks_max_per_owner"]),
        "failure_threshold_failing": int(config["webhooks_failure_threshold_failing"]),
        "failure_threshold_disabled": int(config["webhooks_failure_threshold_disabled"]),
        "delivery_timeout_s": float(config["webhooks_delivery_timeout_s"]),
        "retry_backoff_schedule_s": tuple(
            float(item) for item in config["webhooks_retry_backoff_schedule"]
        ),
        "retention_seconds": int(config["webhooks_retention_seconds"]),
        "cleanup_interval_s": float(config["webhooks_cleanup_interval_s"]),
    }


def _resolve_output_delivery_config(config: dict[str, Any]) -> dict[str, Any]:
    return {
        "timeout_s": float(config["output_delivery_timeout_s"]),
        "retry_backoff_schedule_s": tuple(
            float(item) for item in config["output_delivery_retry_backoff_schedule"]
        ),
    }


async def _webhook_cleanup_loop(
    cleanup_service: WebhookCleanupService,
    interval_s: float,
) -> None:
    try:
        while True:
            await asyncio.sleep(interval_s)
            await cleanup_service.cleanup_expired()
    except asyncio.CancelledError:
        raise


async def _session_timeout_watchdog_loop(
    session_manager: SessionManager,
    interval_s: float,
) -> None:
    """Periodically cancel sessions that exceed the configured runtime cap."""
    try:
        while True:
            await asyncio.sleep(interval_s)
            session_manager._check_session_timeouts()
    except asyncio.CancelledError:
        raise


def _is_loopback_host(host: str) -> bool:
    """Return True when the provided host resolves to loopback."""
    normalized = host.strip().lower()
    if normalized in {"localhost", "::1"}:
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def _is_private_or_tailscale_host(host: str) -> bool:
    """Return True for loopback, RFC1918 private, or Tailscale CGNAT addresses."""

    normalized = host.strip().lower()
    if normalized in {"localhost", "::1"}:
        return True
    try:
        ip = ipaddress.ip_address(normalized)
    except ValueError:
        return False
    if ip.is_loopback or ip.is_private:
        return True
    return ip in ipaddress.ip_network("100.64.0.0/10")


def _print_startup_banner(
    host: str,
    port: int,
    token: str,
    *,
    profile_name: str,
    auth_source: str,
    auth_mode: str,
    token_count: int,
    tls_acknowledged: bool,
    rate_limit_enabled: bool,
) -> None:
    """Print Rich-formatted startup banner."""
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    token_hint = token[:4] + "***" if len(token) > 4 else "***"

    lines = [
        f"[bold]Obra Gateway[/bold] v{__version__}",
        "",
        f"  Profile:    [cyan]{profile_name}[/cyan]",
        f"  Listening:  [cyan]http://{host}:{port}[/cyan]",
        f"  Auth token: [yellow]{token_hint}[/yellow] ({auth_source})",
        f"  Auth mode:  [cyan]{auth_mode}[/cyan]",
        f"  TLS ack:    [cyan]{'yes' if tls_acknowledged else 'no'}[/cyan]",
        f"  Rate limit: [cyan]{'enabled' if rate_limit_enabled else 'disabled'}[/cyan]",
        f"  Tokens:     [cyan]{token_count}[/cyan]",
        "",
        "[dim]Endpoints:[/dim]",
        "  POST   /api/automation/runs       Automation launch for workflow runs",
        "  POST   /api/automation/derivations Automation launch for derivations",
        "  GET    /api/workflows             Workflow inspection",
        "  GET    /api/artifacts             Artifact inspection",
        "  GET    /api/runners               Runner lookup",
        "  POST   /api/workflow-derivations  Guided derivation control plane",
        "  GET    /api/workflow-runs         Workflow-run control plane",
        "  GET    /api/health/details        Authenticated diagnostics",
        "  WS     /api/events/stream         Workflow Studio event stream",
        "  GET    /health                   Health check",
        "  GET    /logs/                    Log viewer UI",
        "  GET    /logs/api/stream          Log viewer stream (SSE)",
    ]

    console.print()
    console.print(Panel("\n".join(lines), border_style="green"))
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    console.print()


class GatewayServer:
    """FastAPI-based gateway server for HTTP/SSE and WebSocket access to Obra sessions.

    Args:
        config: Gateway configuration dict from get_gateway_config().
    """

    def __init__(self, config: dict[str, Any]) -> None:
        merged_config = get_gateway_config()
        merged_config.update(config)
        self._config = merged_config
        self._profile = resolve_gateway_automation_profile(self._config)
        self._webhook_config = _resolve_webhook_config(self._config)
        self._output_delivery_config = _resolve_output_delivery_config(self._config)
        self._token_registry = list(self._config["auth_tokens"])
        assistant_config = get_gateway_assistant_config()

        # Resolve auth token
        self._token, self._auth_source = resolve_gateway_auth_token(
            self._config,
            profile=self._profile,
        )

        # Session manager (created early so lifespan can reference it)
        self._session_manager = SessionManager(
            max_sessions=self._config.get("max_sessions", 5),
            escalation_timeout_s=self._config.get("escalation_timeout_s", 300.0),
            gateway_config=self._config,
        )
        pipelines_config = assistant_config["pipelines"]
        self._pipeline_session_manager = PipelineSessionManager(
            max_pipeline_sessions=pipelines_config["max_pipeline_sessions"],
            eviction_ttl_seconds=pipelines_config["pipeline_session_eviction_ttl_seconds"],
            gateway_config=self._config,
        )
        self._webhook_store = InMemoryWebhookStore()
        self._webhook_delivery_service = WebhookDeliveryService(
            timeout_s=self._webhook_config["delivery_timeout_s"],
            retry_backoff_schedule_s=self._webhook_config["retry_backoff_schedule_s"],
        )
        self._webhook_dispatcher = WebhookDispatcher(
            store=self._webhook_store,
            delivery_service=self._webhook_delivery_service,
            failure_threshold_failing=self._webhook_config["failure_threshold_failing"],
            failure_threshold_disabled=self._webhook_config["failure_threshold_disabled"],
        )
        self._output_delivery_service = OutputDeliveryService(
            timeout_s=self._output_delivery_config["timeout_s"],
            retry_backoff_schedule_s=self._output_delivery_config["retry_backoff_schedule_s"],
        )
        self._session_manager.set_webhook_dispatcher(self._webhook_dispatcher)
        self._session_manager.set_output_delivery_service(self._output_delivery_service)

        # Lifespan with shutdown cleanup
        session_mgr = self._session_manager

        @asynccontextmanager
        async def _lifespan(app: FastAPI):  # type: ignore[type-arg]
            from obra.gateway.startup_tracker import StartupTracker
            from obra.gateway.studio_browser import initialize_studio_browser_state
            from obra.gateway.workflow_studio.assistant_provider import (
                configure_assistant_runtime,
            )
            from obra.observability.log_viewer.server import (
                _load_ui_html,
                build_session_index,
                default_hybrid_log_path,
                default_production_log_path,
            )

            # ── Startup tracker (exposed via /ready) ─────────────────
            tracker = StartupTracker()
            tracker.register("log_index", "Building log index")
            tracker.register("model_catalog", "Warming model catalog")
            tracker.register("workflow_store", "Syncing workflows")
            tracker.register("project_store", "Syncing projects")
            app.state.startup_tracker = tracker

            # ── Fast, essential init (keeps /health reachable quickly) ──
            app.state.log_hybrid_path = default_hybrid_log_path()
            app.state.log_production_path = default_production_log_path()
            app.state.log_ui_bytes = _load_ui_html()
            app.state.log_session_index = {}  # populated by background task
            app.state.logs_auth_sessions = {}
            app.state.logs_auth_lock = threading.Lock()
            app.state.logs_stream_lock = threading.Lock()
            app.state.logs_stream_clients_total = 0
            app.state.logs_stream_clients_by_ip = {}
            initialize_studio_browser_state(app.state)
            # Bootstrap provider state (fast) but defer model-catalog warming
            configure_assistant_runtime(app.state, warm_model_cache=False)
            loop = asyncio.get_running_loop()
            background_tasks: set[asyncio.Task[Any]] = set()
            process_tasks: set[asyncio.Task[Any]] = set()

            def _track_background_task(task: asyncio.Task[Any]) -> asyncio.Task[Any]:
                background_tasks.add(task)
                task.add_done_callback(background_tasks.discard)
                return task

            def _spawn_webhook_task(coro: Any) -> asyncio.Task[Any]:
                return _track_background_task(loop.create_task(coro))

            def _track_process_task(task: asyncio.Task[Any]) -> asyncio.Task[Any]:
                process_tasks.add(task)
                task.add_done_callback(process_tasks.discard)
                return task

            def schedule_process_coro(coro: Any) -> asyncio.Task[Any]:
                return _track_process_task(loop.create_task(coro))

            def schedule_webhook_coro(coro: Any) -> None:
                def _schedule() -> None:
                    _spawn_webhook_task(coro)

                try:
                    loop.call_soon_threadsafe(_schedule)
                except RuntimeError:
                    if hasattr(coro, "close"):
                        coro.close()
                    raise

            cleanup_service = WebhookCleanupService(
                self._webhook_store,
                retention_seconds=self._webhook_config["retention_seconds"],
            )
            self._webhook_dispatcher.cleanup_service = cleanup_service
            self._webhook_dispatcher.set_task_spawner(_spawn_webhook_task)
            session_mgr.set_webhook_scheduler(schedule_webhook_coro)
            session_mgr.set_output_delivery_scheduler(schedule_webhook_coro)
            session_mgr.set_process_task_scheduler(schedule_process_coro)
            app.state.webhook_background_tasks = background_tasks
            app.state.schedule_webhook_coro = schedule_webhook_coro
            app.state.webhook_cleanup_service = cleanup_service
            app.state.webhook_cleanup_task = _spawn_webhook_task(
                _webhook_cleanup_loop(
                    cleanup_service,
                    self._webhook_config["cleanup_interval_s"],
                )
            )
            app.state.session_timeout_watchdog_task = _spawn_webhook_task(
                _session_timeout_watchdog_loop(session_mgr, 60.0)
            )

            # ── Deferred init (runs after server accepts connections) ──
            async def _deferred_log_index() -> None:
                try:
                    index = await asyncio.to_thread(
                        build_session_index,
                        app.state.log_hybrid_path,
                        app.state.log_production_path,
                    )
                    app.state.log_session_index = index
                    tracker.mark_ready("log_index", detail=f"{len(index)} sessions indexed")
                except Exception:
                    logger.warning("Deferred log session index build failed", exc_info=True)
                    tracker.mark_failed("log_index", detail="index build failed")

            async def _deferred_model_catalog() -> None:
                try:
                    import time

                    from obra.gateway.workflow_studio.assistant_provider import (
                        AssistantModelHealthCache,
                        build_assistant_model_catalog,
                    )

                    assistant_config = get_gateway_assistant_config()
                    if not assistant_config.get("model_health_check_on_startup", True):
                        tracker.mark_ready("model_catalog", detail="startup check disabled")
                        return
                    state = app.state.assistant_llm_provider_state
                    catalog = await asyncio.to_thread(build_assistant_model_catalog, state)
                    ttl_s = int(assistant_config.get("model_health_check_cache_ttl_s", 300))
                    app.state.assistant_model_health_cache = AssistantModelHealthCache(
                        models=catalog,
                        expires_at=time.time() + ttl_s,
                    )
                    tracker.mark_ready("model_catalog", detail=f"{len(catalog)} models")
                except Exception:
                    logger.warning("Deferred model catalog warming failed", exc_info=True)
                    tracker.mark_failed("model_catalog", detail="catalog build failed")

            async def _deferred_workflow_hydration() -> None:
                try:
                    await self._hydrate_local_workflow_store()
                    tracker.mark_ready("workflow_store")
                except Exception:
                    logger.warning("Deferred workflow hydration failed", exc_info=True)
                    tracker.mark_failed("workflow_store", detail="hydration failed")

            async def _deferred_project_hydration() -> None:
                try:
                    await self._hydrate_local_project_store()
                    tracker.mark_ready("project_store")
                except Exception:
                    logger.warning("Deferred project hydration failed", exc_info=True)
                    tracker.mark_failed("project_store", detail="hydration failed")

            _track_background_task(loop.create_task(_deferred_log_index()))
            _track_background_task(loop.create_task(_deferred_model_catalog()))
            _track_background_task(loop.create_task(_deferred_workflow_hydration()))
            _track_background_task(loop.create_task(_deferred_project_hydration()))

            yield

            async def _drain_gateway_session(record: Any) -> None:
                thread_join_timeout_s = float(get_timeout("handler", "thread_join_s"))
                process_wait_timeout_s = float(get_timeout("subprocess_runner", "process_wait_s"))
                monitor_task = getattr(record, "monitor_task", None)
                proc = getattr(record, "proc", None)
                thread = getattr(record, "thread", None)
                if monitor_task is not None:
                    try:
                        await asyncio.wait_for(
                            asyncio.shield(monitor_task),
                            timeout=process_wait_timeout_s,
                        )
                    except asyncio.TimeoutError:
                        logger.warning(
                            "Process monitor did not finish for session %s during shutdown",
                            record.session_id,
                        )
                    except Exception:
                        logger.warning(
                            "Process monitor failed during shutdown for session %s",
                            record.session_id,
                            exc_info=True,
                        )
                if proc is not None and proc.poll() is None:
                    try:
                        proc.terminate()
                        await asyncio.to_thread(proc.wait, timeout=process_wait_timeout_s)
                    except subprocess.TimeoutExpired:
                        logger.warning(
                            "Force killing subprocess session %s after shutdown timeout",
                            record.session_id,
                        )
                        proc.kill()
                        await asyncio.to_thread(proc.wait, timeout=process_wait_timeout_s)
                if thread is not None and thread.is_alive():
                    await asyncio.to_thread(thread.join, timeout=thread_join_timeout_s)
                    if thread.is_alive():
                        logger.warning(
                            "Session thread %s still alive after shutdown drain timeout",
                            record.session_id,
                        )

            async def _drain_pipeline_session(record: Any) -> None:
                thread_join_timeout_s = float(get_timeout("handler", "thread_join_s"))
                thread = getattr(record, "thread", None)
                if thread is None or not thread.is_alive():
                    return
                await asyncio.to_thread(thread.join, timeout=thread_join_timeout_s)
                if thread.is_alive():
                    logger.warning(
                        "Pipeline session thread %s still alive after shutdown drain timeout",
                        record.id,
                    )

            # Shutdown: cancel all running sessions
            for record in session_mgr.list_sessions():
                if record.status == "running":
                    try:
                        session_mgr.cancel_session(record.session_id)
                    except Exception:
                        logger.warning("Failed to cancel session %s on shutdown", record.session_id)
            for record in self._pipeline_session_manager.list_active():
                if record["status"] == "running":
                    try:
                        self._pipeline_session_manager.cancel_session(str(record["id"]))
                    except Exception:
                        logger.warning(
                            "Failed to cancel pipeline session %s on shutdown",
                            record["id"],
                        )
            await asyncio.gather(
                *[
                    _drain_gateway_session(record)
                    for record in session_mgr.list_sessions()
                    if record.status == "running"
                    or getattr(record, "proc", None) is not None
                    or (getattr(record, "thread", None) is not None and record.thread.is_alive())
                ],
                return_exceptions=True,
            )
            await asyncio.gather(
                *[
                    _drain_pipeline_session(record)
                    for record in self._pipeline_session_manager.list_records()
                    if record.status == "running"
                    or (record.thread is not None and record.thread.is_alive())
                ],
                return_exceptions=True,
            )
            session_mgr.set_process_task_scheduler(None)
            session_mgr.set_webhook_scheduler(None)
            session_mgr.set_output_delivery_scheduler(None)
            self._webhook_dispatcher.set_task_spawner(None)
            self._webhook_dispatcher.cleanup_service = None
            if process_tasks:
                await asyncio.gather(*list(process_tasks), return_exceptions=True)
            if background_tasks:
                for task in list(background_tasks):
                    task.cancel()
                await asyncio.gather(*list(background_tasks), return_exceptions=True)

        # Build FastAPI app (auth added per-router, not globally, so /health stays open)
        self._effective_token_count = len(self._token_registry) + 1
        self._auth_dep = get_auth_dependency(
            self._token,
            token_registry=self._token_registry,
        )
        self._app = FastAPI(
            title="Obra Gateway",
            version=__version__,
            lifespan=_lifespan,
        )
        self._app.add_exception_handler(GatewayAPIError, gateway_error_handler)
        self._app.add_exception_handler(HTTPException, gateway_http_exception_handler)

        # CORS middleware
        if self._config.get("enable_cors", False):
            origins = self._config.get("cors_origins", ["*"])
            credentials = self._config.get("cors_allow_credentials", True)
            if credentials and "*" in origins:
                logger.warning(
                    "CORS: credentials=True with wildcard origin is insecure; forcing credentials=False"
                )
                credentials = False
            self._app.add_middleware(
                CORSMiddleware,
                allow_origins=origins,
                allow_credentials=credentials,
                allow_methods=["*"],
                allow_headers=["*"],
            )

        # Attach session manager to app state
        self._app.state.session_manager = self._session_manager
        self._app.state.pipeline_session_manager = self._pipeline_session_manager
        self._app.state.assistant_repository = None
        self._app.state.assistant_llm_provider = None
        self._app.state.assistant_llm_provider_state = None
        self._app.state.assistant_model_health_cache = None
        self._app.state.gateway_token = self._token
        self._app.state.gateway_token_registry = list(self._token_registry)
        self._app.state.gateway_profile = self._profile
        self._app.state.gateway_config = dict(self._config)
        self._app.state.workflow_storage = str(self._config.get("workflow_storage", "cloud"))
        self._app.state.webhook_config = dict(self._webhook_config)
        self._app.state.gateway_transcription_config = get_gateway_transcription_config()
        self._app.state.trusted_proxy_cidrs = list(self._config.get("trusted_proxy_cidrs", []))
        self._app.state.webhook_store = self._webhook_store
        self._app.state.webhook_delivery_service = self._webhook_delivery_service
        self._app.state.output_delivery_service = self._output_delivery_service
        self._app.state.webhook_dispatcher = self._webhook_dispatcher
        self._app.state.webhook_cleanup_service = None
        self._app.state.webhook_cleanup_task = None
        self._app.state.webhook_background_tasks = set()
        self._app.state.schedule_webhook_coro = None
        self._app.state._oauth_pending_flows = {}

        # Shared APIClient singleton — avoids per-request from_config() file I/O.
        # Only set if no external factory is already wired (e.g. browser-rig).
        self._app.state.local_workflow_store = LocalWorkflowStore()
        self._app.state.local_project_store = LocalProjectStore()
        self._app.state.workflow_studio_client_factory = None
        self._init_shared_api_client()
        self._app.state.enable_app_rate_limit = bool(
            self._config.get("enable_app_rate_limit", True)
        )

        if self._app.state.enable_app_rate_limit:
            self._app.state.rest_rate_limiter = TokenBucketRateLimiter(
                rate_per_minute=int(self._config.get("rest_rate_limit_per_minute", 120)),
                burst=int(self._config.get("rest_rate_limit_burst", 60)),
            )
            self._app.state.ws_rate_limiter = TokenBucketRateLimiter(
                rate_per_minute=int(self._config.get("ws_rate_limit_per_minute", 240)),
                burst=int(self._config.get("ws_rate_limit_burst", 120)),
            )
        else:
            self._app.state.rest_rate_limiter = None
            self._app.state.ws_rate_limiter = None

        # Register routes
        self._register_routes()

        @self._app.middleware("http")
        async def _rest_rate_limit_middleware(request: Request, call_next: Any) -> Any:
            limiter = request.app.state.rest_rate_limiter
            if limiter is None or not request.url.path.startswith("/api/"):
                return await call_next(request)

            client_ip = extract_client_ip_from_request(
                request,
                request.app.state.trusted_proxy_cidrs,
            )
            limit = int(request.app.state.gateway_config["rest_rate_limit_burst"])
            if not limiter.allow(client_ip):
                remaining, reset_seconds = limiter.remaining(client_ip)
                response = JSONResponse(
                    status_code=429,
                    content={"detail": "Rate limit exceeded"},
                )
                _attach_rate_limit_headers(
                    response,
                    limit=limit,
                    remaining=remaining,
                    reset_seconds=reset_seconds,
                    include_retry_after=True,
                )
                return response

            response = await call_next(request)
            remaining, reset_seconds = limiter.remaining(client_ip)
            _attach_rate_limit_headers(
                response,
                limit=limit,
                remaining=remaining,
                reset_seconds=reset_seconds,
                include_retry_after=False,
            )
            return response

        # Health endpoint (no auth required)
        @self._app.get("/health", include_in_schema=True)
        async def health() -> dict[str, Any]:
            return {"status": "ok"}

        # Readiness endpoint — subsystem initialization progress (no auth)
        @self._app.get("/ready", include_in_schema=True)
        async def ready() -> dict[str, Any]:
            from obra.gateway.startup_tracker import StartupTracker

            tracker: StartupTracker | None = getattr(self._app.state, "startup_tracker", None)
            if tracker is None:
                return {"ready": True, "subsystems": {}}
            return tracker.snapshot

        @self._app.get(
            "/api/health/details",
            include_in_schema=True,
            dependencies=[Depends(self._auth_dep)],
        )
        async def health_details() -> dict[str, Any]:
            running = sum(1 for s in self._session_manager.list_sessions() if s.status == "running")
            return {
                "active_sessions": running,
                "version": __version__,
            }

    def _init_shared_api_client(self) -> None:
        """Cache API auth config at startup so per-request clients skip file I/O.

        Each request still gets its own APIClient (with its own requests.Session)
        because requests.Session is not thread-safe. The expensive part —
        reading ~/.obra/auth.yaml and parsing tokens — happens once here.

        Skipped when an external factory is already set (e.g. browser-rig demo).
        """
        if self._app.state.workflow_studio_client_factory is not None:
            return
        try:
            from obra.api import APIClient

            # Read config once to validate and warm the token.
            seed_client = APIClient.from_config()
            cached_kwargs = {
                "base_url": seed_client.base_url,
                "auth_token": seed_client.auth_token,
                "refresh_token": seed_client.refresh_token,
                "firebase_api_key": seed_client.firebase_api_key,
                "auto_refresh": True,
                "pool_retries": True,
            }
            cached_expires_at = seed_client.token_expires_at

            def _cached_client_factory() -> APIClient:
                client = APIClient(**cached_kwargs)
                client.token_expires_at = cached_expires_at
                return client

            self._app.state.workflow_studio_client_factory = _cached_client_factory
            logger.info("Cached API config for workflow-studio routes")
        except Exception as exc:
            logger.debug("Shared API config not available (expected in dev/demo): %s", exc)

    async def _hydrate_local_workflow_store(self) -> None:
        """Hydrate the local workflow cache in cloud mode without blocking availability."""
        if str(self._app.state.workflow_storage or "").strip().lower() == "local":
            logger.info("Workflow storage mode is local; skipping startup cloud hydration")
            return
        store = getattr(self._app.state, "local_workflow_store", None)
        client_factory = getattr(self._app.state, "workflow_studio_client_factory", None)
        if not callable(getattr(store, "sync_from_remote", None)):
            logger.warning("Local workflow store unavailable; startup hydration skipped")
            return
        if not callable(client_factory):
            logger.info("Workflow API client unavailable; startup hydration skipped")
            return
        try:
            client = client_factory()
            result = await asyncio.to_thread(store.sync_from_remote, client)
            logger.info(
                "Hydrated local workflow store from remote at startup (%s workflows)",
                result.get("synced_count", 0),
            )
        except Exception as exc:
            logger.warning(
                "Workflow startup hydration failed; continuing with remote/session fallback: %s",
                exc,
            )
            raise

    async def _hydrate_local_project_store(self) -> None:
        """Hydrate the local project cache without blocking gateway availability."""
        store = getattr(self._app.state, "local_project_store", None)
        client_factory = getattr(self._app.state, "workflow_studio_client_factory", None)
        if not callable(getattr(store, "sync_from_remote", None)):
            logger.warning("Local project store unavailable; startup hydration skipped")
            return
        if not callable(client_factory):
            logger.info("Workflow API client unavailable; project hydration skipped")
            return
        try:
            client = client_factory()
            result = await asyncio.to_thread(store.sync_from_remote, client)
            logger.info(
                "Hydrated local project store from remote at startup (%s projects)",
                result.get("synced_count", 0),
            )
        except Exception as exc:
            logger.warning(
                "Project startup hydration failed; continuing with remote fallback: %s",
                exc,
            )
            raise

    def _register_routes(self) -> None:
        """Register all route modules."""
        from obra.gateway.routes.api_root import router as api_root_router
        from obra.gateway.routes.artifacts import router as artifacts_router
        from obra.gateway.routes.assistant import router as assistant_router
        from obra.gateway.routes.automation import router as automation_router
        from obra.gateway.routes.callbacks import router as callbacks_router
        from obra.gateway.routes.connectors import (
            oauth_callback_router,
            router as connectors_router,
        )
        from obra.gateway.routes.domains import router as domains_router
        from obra.gateway.routes.filesystem import router as filesystem_router
        from obra.gateway.routes.interpolation import router as interpolation_router
        from obra.gateway.routes.knowledge import router as knowledge_router
        from obra.gateway.routes.logs import router as logs_router
        from obra.gateway.routes.onboarding import router as onboarding_router
        from obra.gateway.routes.projects import router as projects_router
        from obra.gateway.routes.runners import router as runners_router
        from obra.gateway.routes.sessions import router as sessions_router
        from obra.gateway.routes.settings import router as settings_router
        from obra.gateway.routes.studio import router as studio_router
        from obra.gateway.routes.template_assets import router as template_assets_router
        from obra.gateway.routes.transcription import router as transcription_router
        from obra.gateway.routes.webhooks import router as webhooks_router
        from obra.gateway.routes.workflow_derivations import (
            router as workflow_derivations_router,
        )
        from obra.gateway.routes.workflow_events import router as workflow_events_router
        from obra.gateway.routes.workflow_replay import router as workflow_replay_router
        from obra.gateway.routes.workflow_runs import router as workflow_runs_router
        from obra.gateway.routes.workflows import router as workflows_router

        auth = [Depends(self._auth_dep)]
        scope_read = [Depends(self._auth_dep), Depends(require_scope(GatewayScope.READ))]
        scope_admin = [Depends(self._auth_dep), Depends(require_scope(GatewayScope.ADMIN))]

        self._app.include_router(api_root_router, dependencies=scope_read)
        self._app.include_router(automation_router, dependencies=auth)
        self._app.include_router(assistant_router, dependencies=auth)
        self._app.include_router(callbacks_router, dependencies=scope_read)
        self._app.include_router(connectors_router, dependencies=auth)
        self._app.include_router(domains_router, dependencies=scope_read)
        self._app.include_router(filesystem_router, dependencies=auth)
        self._app.include_router(interpolation_router, dependencies=scope_read)
        self._app.include_router(knowledge_router, dependencies=auth)
        self._app.include_router(projects_router, dependencies=auth)
        self._app.include_router(sessions_router, dependencies=auth)
        self._app.include_router(settings_router, dependencies=scope_admin)
        self._app.include_router(transcription_router, dependencies=scope_read)
        self._app.include_router(workflows_router, dependencies=auth)
        self._app.include_router(artifacts_router, dependencies=scope_read)
        self._app.include_router(template_assets_router, dependencies=auth)
        self._app.include_router(runners_router, dependencies=scope_read)
        self._app.include_router(webhooks_router, dependencies=scope_admin)
        self._app.include_router(workflow_derivations_router, dependencies=auth)
        self._app.include_router(workflow_runs_router, dependencies=auth)
        self._app.include_router(workflow_events_router)
        self._app.include_router(workflow_replay_router, dependencies=scope_read)
        self._app.include_router(logs_router)
        self._app.include_router(oauth_callback_router)
        self._app.include_router(onboarding_router)
        self._app.include_router(studio_router)

    @property
    def app(self) -> FastAPI:
        """The FastAPI application instance."""
        return self._app

    @property
    def token(self) -> str:
        """The auth token (for display/logging)."""
        return self._token

    def run(self, host: str | None = None, port: int | None = None) -> None:
        """Start the gateway server.

        Args:
            host: Override bind address.
            port: Override port number.
        """
        import uvicorn

        bind_host = host or self._config.get("host", "127.0.0.1")
        bind_port = port or self._config.get("port", 18790)
        allow_public_bind = bool(self._config.get("allow_public_bind", False))
        public_bind_tls_terminated = bool(self._config.get("public_bind_tls_terminated", False))
        rate_limit_enabled = bool(self._config.get("enable_app_rate_limit", True))
        auth_mode = "multi-token" if self._token_registry else "single-token"

        if not _is_loopback_host(bind_host):
            if self._profile.name == GATEWAY_PROFILE_PRIVATE_TAILNET:
                if not _is_private_or_tailscale_host(bind_host):
                    raise RuntimeError(
                        "private_tailnet profile refuses public bind addresses. "
                        "Use a private or Tailscale address."
                    )
            elif self._profile.private_only:
                raise RuntimeError(
                    "Private automation profile refuses non-loopback bind hosts. "
                    "Keep the gateway on loopback and use SSH tunnels or private overlays "
                    "for remote operator access."
                )
            else:
                if not allow_public_bind:
                    msg = (
                        f"Refusing non-loopback bind host '{bind_host}'. "
                        "Set gateway.allow_public_bind=true and "
                        "gateway.public_bind_tls_terminated=true only when running behind "
                        "TLS-terminating edge infrastructure."
                    )
                    raise RuntimeError(msg)
                if not public_bind_tls_terminated:
                    msg = (
                        "Refusing public bind without TLS termination acknowledgement. "
                        "Set gateway.public_bind_tls_terminated=true only when a trusted "
                        "reverse proxy/WAF terminates TLS."
                    )
                    raise RuntimeError(msg)
            logger.warning(
                "Gateway started on non-loopback bind %s; run `obra gateway security-audit` before exposure.",
                bind_host,
            )

        logger.info(
            "Gateway startup posture: profile=%s bind=%s:%s auth_source=%s auth_mode=%s "
            "tls_acknowledged=%s rate_limit_enabled=%s token_count=%s",
            self._profile.name,
            bind_host,
            bind_port,
            self._auth_source,
            auth_mode,
            public_bind_tls_terminated,
            rate_limit_enabled,
            self._effective_token_count,
        )

        _print_startup_banner(
            bind_host,
            bind_port,
            self._token,
            profile_name=self._profile.name,
            auth_source=self._auth_source,
            auth_mode=auth_mode,
            token_count=self._effective_token_count,
            tls_acknowledged=public_bind_tls_terminated,
            rate_limit_enabled=rate_limit_enabled,
        )
        uvicorn.run(
            self._app,
            host=bind_host,
            port=bind_port,
            ws_max_size=int(self._config.get("ws_max_message_bytes", 1_048_576)),
        )


def _attach_rate_limit_headers(
    response: Any,
    *,
    limit: int,
    remaining: float,
    reset_seconds: float,
    include_retry_after: bool,
) -> None:
    response.headers["X-RateLimit-Limit"] = str(limit)
    response.headers["X-RateLimit-Remaining"] = str(max(0, int(remaining)))
    response.headers["X-RateLimit-Reset"] = str(max(0, ceil(reset_seconds)))
    if include_retry_after:
        response.headers["Retry-After"] = str(max(1, ceil(reset_seconds)))
