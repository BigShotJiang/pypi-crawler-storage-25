"""Canonical Workflow Studio event-stream routes."""

from __future__ import annotations

import asyncio
import contextlib
import json
from typing import Any, AsyncIterator

from fastapi import APIRouter, HTTPException, Query, Request, WebSocket, WebSocketDisconnect, status
from starlette.responses import StreamingResponse
from websockets.exceptions import ConnectionClosed

from obra.gateway.auth import (
    authenticate_request,
    authenticate_websocket_credentials,
    build_studio_websocket_principal,
)
from obra.gateway.security.client_ip import extract_client_ip_from_websocket
from obra.gateway.security.scopes import GatewayScope, insufficient_scope_detail
from obra.gateway.studio_browser import (
    is_studio_browser_authenticated_websocket,
)
from obra.gateway.workflow_studio.events import build_event_envelope

_SSE_KEEPALIVE_INTERVAL_S = 15.0

router = APIRouter(tags=["workflow-studio"])


class EventStreamConnectionManager:
    """Track canonical event-stream connections and per-IP admission limits."""

    def __init__(self) -> None:
        self.connections: set[WebSocket] = set()
        self._connection_ips: dict[int, str] = {}
        self._connections_per_ip: dict[str, int] = {}

    def connect(
        self,
        ws: WebSocket,
        client_ip: str,
        *,
        max_total: int,
        max_per_ip: int,
    ) -> tuple[bool, str | None]:
        if len(self.connections) >= max_total:
            return False, "Too many WebSocket connections"
        if self._connections_per_ip.get(client_ip, 0) >= max_per_ip:
            return False, "Too many WebSocket connections from this IP"

        self.connections.add(ws)
        key = id(ws)
        self._connection_ips[key] = client_ip
        self._connections_per_ip[client_ip] = self._connections_per_ip.get(client_ip, 0) + 1
        return True, None

    def disconnect(self, ws: WebSocket) -> None:
        self.connections.discard(ws)
        key = id(ws)
        client_ip = self._connection_ips.pop(key, None)
        if client_ip is None:
            return
        remaining = self._connections_per_ip.get(client_ip, 0) - 1
        if remaining > 0:
            self._connections_per_ip[client_ip] = remaining
        else:
            self._connections_per_ip.pop(client_ip, None)


def _event_stream_transport_state(app: Any) -> dict[str, Any] | None:
    state = getattr(app.state, "workflow_event_stream_transport_state", None)
    return state if isinstance(state, dict) else None


def _event_stream_connection_manager(app: Any) -> EventStreamConnectionManager:
    manager = getattr(app.state, "workflow_event_stream_connection_manager", None)
    if isinstance(manager, EventStreamConnectionManager):
        return manager
    manager = EventStreamConnectionManager()
    app.state.workflow_event_stream_connection_manager = manager
    return manager


def _register_event_stream_socket(ws: WebSocket) -> None:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return
    connections = state.get("connections")
    if isinstance(connections, set):
        connections.add(ws)


def _unregister_event_stream_socket(ws: WebSocket) -> None:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return
    connections = state.get("connections")
    if isinstance(connections, set):
        connections.discard(ws)


def _event_stream_transport_enabled(ws: WebSocket) -> bool:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return True
    return bool(state.get("enabled", True))


def _event_stream_send_delay_s(ws: WebSocket) -> float:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return 0.0
    delay_ms = max(0, int(state.get("ws_send_delay_ms", 0) or 0))
    return delay_ms / 1000


def _event_stream_auth_timeout_s(ws: WebSocket) -> float:
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    return float(gateway_config.get("ws_auth_timeout_s", 5.0))


def _event_stream_connection_limits(ws: WebSocket) -> tuple[int, int]:
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    return (
        int(gateway_config.get("max_ws_connections_total", 200)),
        int(gateway_config.get("max_ws_connections_per_ip", 20)),
    )


def _allow_event_stream_control_message(ws: WebSocket) -> bool:
    limiter = getattr(ws.app.state, "ws_rate_limiter", None)
    if limiter is None:
        return True
    client_ip = str(ws.scope.get("gateway_client_ip", "0.0.0.0"))
    return limiter.allow(client_ip)


async def _ensure_http_auth(request: Request) -> None:
    principal = await authenticate_request(
        request,
        token=str(request.app.state.gateway_token),
        token_registry=list(getattr(request.app.state, "gateway_token_registry", [])),
    )
    if GatewayScope.READ.value not in principal.scopes:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=insufficient_scope_detail(GatewayScope.READ),
        )


async def _event_generator(
    event_bus: Any,
    record: Any | None,
    resource_id: str,
    filter_names: set[str] | None = None,
    after_sequence: int | None = None,
    *,
    resource_type: str = "workflow_run",
) -> AsyncIterator[str]:
    subscription = event_bus.subscribe(after_sequence=after_sequence).__aiter__()
    while True:
        try:
            event = await asyncio.wait_for(
                subscription.__anext__(),
                timeout=_SSE_KEEPALIVE_INTERVAL_S,
            )
        except asyncio.TimeoutError:
            yield ":keepalive\n\n"
            continue
        except StopAsyncIteration:
            break
        payload = build_event_envelope(
            event,
            run_id=(record.workflow_run_id if record is not None else resource_id),
            record=record,
            resource_type=resource_type,
        )
        if filter_names and str(payload.get("event_name")) not in filter_names:
            continue
        yield f"data: {json.dumps(payload)}\n\n"

    yield "data: [DONE]\n\n"


def _resolve_http_event_source(
    request: Request,
    resource_id: str,
    *,
    resource_type: str,
) -> tuple[Any | None, Any]:
    session_manager = request.app.state.session_manager
    try:
        if resource_type == "workflow_derivation":
            record = session_manager.get_session_by_derivation_id(resource_id)
            return record, record.event_bus
        if resource_type == "workflow":
            return None, session_manager.get_workflow_event_bus(resource_id)
        record = session_manager.get_session(resource_id)
        return record, record.event_bus
    except Exception as exc:
        detail = (
            "Workflow derivation not found"
            if resource_type == "workflow_derivation"
            else ("Workflow not found" if resource_type == "workflow" else "Workflow run not found")
        )
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=detail) from exc


@router.get("/api/workflow-runs/{run_id}/events")
async def stream_workflow_run_events(
    run_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    await _ensure_http_auth(request)
    record, event_bus = _resolve_http_event_source(
        request,
        run_id,
        resource_type="workflow_run",
    )
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    return StreamingResponse(
        _event_generator(event_bus, record, run_id, filter_names, after_sequence),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.get("/api/workflow-derivations/{derivation_id}/events")
async def stream_workflow_derivation_events(
    derivation_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    await _ensure_http_auth(request)
    record, event_bus = _resolve_http_event_source(
        request,
        derivation_id,
        resource_type="workflow_derivation",
    )
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    return StreamingResponse(
        _event_generator(
            event_bus,
            record,
            derivation_id,
            filter_names,
            after_sequence,
            resource_type="workflow_derivation",
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.get("/api/workflows/{workflow_id}/events")
async def stream_workflow_events(
    workflow_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    await _ensure_http_auth(request)
    record, event_bus = _resolve_http_event_source(
        request,
        workflow_id,
        resource_type="workflow",
    )
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    return StreamingResponse(
        _event_generator(
            event_bus,
            record,
            workflow_id,
            filter_names,
            after_sequence,
            resource_type="workflow",
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.websocket("/api/events/stream")
async def workflow_event_stream(ws: WebSocket) -> None:
    await ws.accept()
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    trusted_proxy_cidrs = list(gateway_config.get("trusted_proxy_cidrs", []))
    client_ip = extract_client_ip_from_websocket(ws, trusted_proxy_cidrs)
    ws.scope["gateway_client_ip"] = client_ip
    max_total_connections, max_connections_per_ip = _event_stream_connection_limits(ws)
    manager = _event_stream_connection_manager(ws.app)
    accepted, error = manager.connect(
        ws,
        client_ip,
        max_total=max_total_connections,
        max_per_ip=max_connections_per_ip,
    )
    if not accepted:
        await _close_with_error(ws, error or "Too many WebSocket connections", 4003)
        return

    _register_event_stream_socket(ws)
    subscription_tasks: dict[str, asyncio.Task[None]] = {}

    try:
        if not _event_stream_transport_enabled(ws):
            await ws.close(code=1013, reason="Workflow event stream temporarily unavailable")
            return

        browser_session_authenticated = is_studio_browser_authenticated_websocket(ws)
        first_control_message: str | None = None
        if browser_session_authenticated:
            try:
                first_control_message = await asyncio.wait_for(
                    ws.receive_text(),
                    timeout=_event_stream_auth_timeout_s(ws),
                )
            except asyncio.TimeoutError:
                await _close_with_error(ws, "Subscription timeout", 4001)
                return
            except WebSocketDisconnect:
                return
            if _is_auth_frame(first_control_message):
                try:
                    authenticate_websocket_credentials(
                        ws,
                        first_control_message,
                        token=str(ws.app.state.gateway_token),
                        token_registry=list(getattr(ws.app.state, "gateway_token_registry", [])),
                    )
                    first_control_message = None
                except HTTPException as exc:
                    await _close_with_error(ws, str(exc.detail), 4001)
                    return
            else:
                build_studio_websocket_principal(ws)
        else:
            try:
                auth_raw = await asyncio.wait_for(
                    ws.receive_text(),
                    timeout=_event_stream_auth_timeout_s(ws),
                )
            except asyncio.TimeoutError:
                await _close_with_error(ws, "Authentication timeout", 4001)
                return
            except WebSocketDisconnect:
                return
            try:
                authenticate_websocket_credentials(
                    ws,
                    auth_raw,
                    token=str(ws.app.state.gateway_token),
                    token_registry=list(getattr(ws.app.state, "gateway_token_registry", [])),
                )
            except HTTPException as exc:
                await _close_with_error(ws, str(exc.detail), 4001)
                return

        if not _websocket_has_scope(ws, GatewayScope.READ):
            await _close_with_error(ws, f"Required scope: {GatewayScope.READ.value}", 4403)
            return

        send_lock = asyncio.Lock()

        async def _replace_subscription(subscription: dict[str, Any]) -> None:
            key = _subscription_key(subscription)
            existing = subscription_tasks.pop(key, None)
            if existing is not None:
                await _cancel_subscription(existing)

            session_manager = ws.app.state.session_manager
            record, event_bus, run_ref = _resolve_event_bus(
                session_manager,
                subscription["resource_type"],
                subscription["resource_id"],
            )
            subscription_tasks[key] = asyncio.create_task(
                _stream_subscription(
                    ws,
                    subscription=subscription,
                    send_lock=send_lock,
                    event_bus=event_bus,
                    record=record,
                    run_ref=run_ref,
                )
            )

        async def _remove_subscription(subscription: dict[str, Any]) -> None:
            task = subscription_tasks.pop(_subscription_key(subscription), None)
            if task is not None:
                await _cancel_subscription(task)

        if first_control_message is None:
            subscribe_raw = await ws.receive_text()
        else:
            subscribe_raw = first_control_message
        if not _allow_event_stream_control_message(ws):
            await _close_with_error(ws, "Rate limit exceeded", 4008)
            return
        try:
            control_type, subscriptions = _parse_subscription_message(
                subscribe_raw,
                query_params=ws.query_params,
            )
        except ValueError as exc:
            await _close_with_error(ws, str(exc), 4400)
            return
        if control_type != "subscribe" or not subscriptions:
            await _close_with_error(
                ws,
                "run_id, derivation_id, or workflow_id is required",
                4400,
            )
            return

        try:
            for subscription in subscriptions:
                await _replace_subscription(subscription)
        except Exception as exc:
            await _close_with_error(ws, str(exc), 4400)
            return

        if _message_declares_type(subscribe_raw):
            await _send_control_message(
                ws,
                send_lock,
                {
                    "type": "subscribed",
                    "subscriptions": [_subscription_payload(item) for item in subscriptions],
                },
            )

        while True:
            control_raw = await ws.receive_text()
            if not _allow_event_stream_control_message(ws):
                await _send_control_message(
                    ws,
                    send_lock,
                    {"type": "error", "detail": "Rate limit exceeded"},
                )
                continue
            try:
                control_type, subscriptions = _parse_subscription_message(control_raw)
            except ValueError as exc:
                await _send_control_message(
                    ws,
                    send_lock,
                    {"type": "error", "detail": str(exc)},
                )
                continue
            if control_type == "ping":
                await _send_control_message(ws, send_lock, {"type": "pong"})
                continue
            if not subscriptions:
                await _send_control_message(
                    ws,
                    send_lock,
                    {"type": "error", "detail": "No subscriptions supplied"},
                )
                continue
            try:
                if control_type == "subscribe":
                    for subscription in subscriptions:
                        await _replace_subscription(subscription)
                    await _send_control_message(
                        ws,
                        send_lock,
                        {
                            "type": "subscribed",
                            "subscriptions": [
                                _subscription_payload(item) for item in subscriptions
                            ],
                        },
                    )
                elif control_type == "unsubscribe":
                    for subscription in subscriptions:
                        await _remove_subscription(subscription)
                    await _send_control_message(
                        ws,
                        send_lock,
                        {
                            "type": "unsubscribed",
                            "subscriptions": [
                                _subscription_payload(item) for item in subscriptions
                            ],
                        },
                    )
            except Exception as exc:
                await _send_control_message(
                    ws,
                    send_lock,
                    {"type": "error", "detail": str(exc)},
                )
    except (WebSocketDisconnect, ConnectionClosed):
        pass
    finally:
        _unregister_event_stream_socket(ws)
        manager.disconnect(ws)
        for task in subscription_tasks.values():
            await _cancel_subscription(task)


def _message_declares_type(raw_message: str) -> bool:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError:
        return False
    return isinstance(payload, dict) and isinstance(payload.get("type"), str)


def _is_auth_frame(raw_message: str) -> bool:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError:
        return False
    return isinstance(payload, dict) and str(payload.get("type") or "").strip().lower() == "auth"


def _websocket_has_scope(ws: WebSocket, scope: GatewayScope) -> bool:
    configured_scopes = getattr(ws.state, "gateway_scopes", frozenset())
    if not isinstance(configured_scopes, frozenset):
        configured_scopes = frozenset(configured_scopes or [])
    return scope.value in configured_scopes


def _parse_subscription_message(
    raw_message: str,
    *,
    query_params: Any | None = None,
) -> tuple[str, list[dict[str, Any]]]:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError as exc:
        raise ValueError("Invalid event-stream control message") from exc

    if not isinstance(payload, dict):
        raise ValueError("Control message must be a JSON object")

    control_type = str(payload.get("type") or "subscribe").strip().lower()
    if control_type == "ping":
        return "ping", []
    if control_type not in {"subscribe", "unsubscribe"}:
        raise ValueError(f"Unsupported control message type: {control_type}")

    subscriptions = _normalize_subscriptions(payload, query_params=query_params)
    return control_type, subscriptions


def _normalize_subscriptions(
    payload: dict[str, Any],
    *,
    query_params: Any | None = None,
) -> list[dict[str, Any]]:
    if isinstance(payload.get("subscriptions"), list):
        subscriptions = [
            _parse_subscription_payload(item)
            for item in payload["subscriptions"]
            if isinstance(item, dict)
        ]
    else:
        subscriptions = [_parse_subscription_payload(payload, query_params=query_params)]
    return [item for item in subscriptions if item is not None]


def _parse_subscription_payload(
    payload: dict[str, Any],
    *,
    query_params: Any | None = None,
) -> dict[str, Any] | None:
    run_id = str(payload.get("run_id") or _query_value(query_params, "run_id") or "").strip()
    derivation_id = str(
        payload.get("derivation_id") or _query_value(query_params, "derivation_id") or ""
    ).strip()
    workflow_id = str(
        payload.get("workflow_id") or _query_value(query_params, "workflow_id") or ""
    ).strip()
    provided = [
        ("workflow_run", run_id),
        ("workflow_derivation", derivation_id),
        ("workflow", workflow_id),
    ]
    selected = [
        (resource_type, resource_id) for resource_type, resource_id in provided if resource_id
    ]
    if not selected:
        return None
    if len(selected) > 1:
        raise ValueError("Exactly one of run_id, derivation_id, or workflow_id is allowed")

    resource_type, resource_id = selected[0]
    return {
        "resource_type": resource_type,
        "resource_id": resource_id,
        "after_sequence": _normalize_after_sequence(payload.get("after_sequence")),
        "filter_names": _normalize_filter_names(payload.get("filter")),
    }


def _normalize_after_sequence(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip():
        return int(value)
    return None


def _normalize_filter_names(value: Any) -> set[str] | None:
    if isinstance(value, str):
        items = [item.strip() for item in value.split(",")]
    elif isinstance(value, list):
        items = [str(item).strip() for item in value]
    else:
        return None
    normalized = {item for item in items if item}
    return normalized or None


def _query_value(query_params: Any | None, key: str) -> str | None:
    if query_params is None:
        return None
    getter = getattr(query_params, "get", None)
    if callable(getter):
        value = getter(key)
        if value is not None:
            return str(value)
    return None


def _resolve_event_bus(
    session_manager: Any,
    resource_type: str,
    resource_id: str,
) -> tuple[Any | None, Any, str]:
    if resource_type == "workflow_derivation":
        record = session_manager.get_session_by_derivation_id(resource_id)
        return record, record.event_bus, record.workflow_run_id
    if resource_type == "workflow":
        return None, session_manager.get_workflow_event_bus(resource_id), resource_id
    record = session_manager.get_session(resource_id)
    return record, record.event_bus, record.workflow_run_id


async def _stream_subscription(
    ws: WebSocket,
    *,
    subscription: dict[str, Any],
    send_lock: asyncio.Lock,
    event_bus: Any,
    record: Any,
    run_ref: str,
) -> None:
    async for event in event_bus.subscribe(after_sequence=subscription.get("after_sequence")):
        payload = build_event_envelope(
            event,
            run_id=run_ref,
            record=record,
            resource_type=subscription["resource_type"],
        )
        filter_names = subscription.get("filter_names")
        if filter_names and str(payload.get("event_name")) not in filter_names:
            continue
        payload.update(
            {
                "stream_resource_type": subscription["resource_type"],
                "stream_resource_id": subscription["resource_id"],
                "subscription_id": _subscription_key(subscription),
            }
        )
        await _send_control_message(ws, send_lock, payload)


def _subscription_key(subscription: dict[str, Any]) -> str:
    return f"{subscription['resource_type']}:{subscription['resource_id']}"


def _subscription_payload(subscription: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "subscription_id": _subscription_key(subscription),
        "resource_type": subscription["resource_type"],
        "resource_id": subscription["resource_id"],
    }
    if subscription.get("after_sequence") is not None:
        payload["after_sequence"] = subscription["after_sequence"]
    if subscription.get("filter_names"):
        payload["filter"] = sorted(subscription["filter_names"])
    return payload


async def _send_control_message(
    ws: WebSocket,
    send_lock: asyncio.Lock,
    payload: dict[str, Any],
) -> None:
    async with send_lock:
        delay_s = _event_stream_send_delay_s(ws)
        if delay_s > 0:
            await asyncio.sleep(delay_s)
        await ws.send_text(json.dumps(payload))


async def _cancel_subscription(task: asyncio.Task[None]) -> None:
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task


async def _close_with_error(ws: WebSocket, detail: str, code: int) -> None:
    try:
        await ws.send_text(json.dumps({"type": "error", "detail": detail}))
        await ws.close(code=code)
    except Exception:
        pass
