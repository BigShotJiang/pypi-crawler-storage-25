"""
fmg tools cloud asset
"""
