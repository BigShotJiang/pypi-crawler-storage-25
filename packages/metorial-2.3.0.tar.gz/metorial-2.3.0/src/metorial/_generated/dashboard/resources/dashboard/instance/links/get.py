from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union
from datetime import datetime
from metorial.utils import parse_iso_datetime
import dataclasses


@dataclass
class DashboardInstanceLinksGetOutput:
  object: str
  id: str
  file_id: str
  url: str
  created_at: datetime
  expires_at: Optional[datetime] = None


class mapDashboardInstanceLinksGetOutput:
  @staticmethod
  def from_dict(data: Dict[str, Any]) -> DashboardInstanceLinksGetOutput:
    return DashboardInstanceLinksGetOutput(
      object=data.get("object"),
      id=data.get("id"),
      file_id=data.get("file_id"),
      url=data.get("url"),
      created_at=parse_iso_datetime(data.get("created_at"))
      if data.get("created_at")
      else None,
      expires_at=parse_iso_datetime(data.get("expires_at"))
      if data.get("expires_at")
      else None,
    )

  @staticmethod
  def to_dict(
    value: Union[DashboardInstanceLinksGetOutput, Dict[str, Any], None]
  ) -> Optional[Dict[str, Any]]:
    if value is None:
      return None
    if isinstance(value, dict):
      return value
    # assume dataclass for generated models
    return dataclasses.asdict(value)
