"""
旅行智能规划 MCP Server
数据源：官方旅行商品库（FlyAI MCP API）
能力：自然语言旅行规划
"""
import json
import hashlib
import hmac
import secrets
import time
import gzip
import base64
import os

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("travel-smart-plan")

# ============ 配置 ============
MCP_URL = "https://flyai.open.fliggy.com/mcp"
MCP_TIMEOUT = 60


def _get_api_key() -> str:
    """从环境变量获取接口密钥，未配置时使用内置Key"""
    key = os.environ.get("HOTEL_API_KEY", "").strip()
    if key:
        return key
    # 兼容扣子平台注入的变量名
    for k, v in os.environ.items():
        if k.startswith("COZE_") and k.endswith("_HOTEL_API_KEY"):
            return v
    return "sk-7TAfc5I7XSwVC0Z2WGEETXl1ATTHrKhE"


def _get_sign_secret() -> str:
    """从环境变量获取签名密钥，未配置时使用内置Key"""
    key = os.environ.get("HOTEL_SIGN_SECRET", "").strip()
    if key:
        return key
    return "XSbdYnucPARDc9knhD8+X6hxdD1Nh6ZGI6Hadg25kBw="


API_KEY = _get_api_key()
SIGN_SECRET = _get_sign_secret()

# ============ MCP通信层 ============

def sha256_hex(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()

def normalize_auth(auth: str) -> str:
    auth = (auth or "").strip()
    return f"Bearer {auth}" if auth and not auth.startswith("Bearer ") else auth

def generate_ff_ctx(sign_secret: str) -> str:
    ctx_obj = {
        "os": "linux", "arch": "x64", "nodeVersion": "v22.22.2",
        "cpuCount": os.cpu_count() or 4, "deviceMemory": 8,
        "clientSurface": "cli", "timezoneOffset": -480,
        "deviceId": secrets.token_hex(8)
    }
    ctx_json = json.dumps(ctx_obj, separators=(",", ":"))
    compressed = gzip.compress(ctx_json.encode("utf-8"))
    if sign_secret:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aes_key = hashlib.sha256(sign_secret.encode("utf-8")).digest()
        iv = secrets.token_bytes(12)
        encrypted = AESGCM(aes_key).encrypt(iv, compressed, None)
        payload = b"\x01" + iv + encrypted
        return base64.b64encode(payload).decode("ascii")
    return base64.b64encode(compressed).decode("ascii")

def generate_sign_headers(body: str, auth: str, sign_secret: str) -> dict:
    ts = str(int(time.time() * 1000))
    nonce = secrets.token_hex(16)
    body_hash = sha256_hex(body)
    auth_hash = sha256_hex(normalize_auth(auth))
    signing_string = f"POST\n/mcp\n{ts}\n{nonce}\n{body_hash}\n{auth_hash}"
    sig = base64.urlsafe_b64encode(
        hmac.new(sign_secret.encode("utf-8"), signing_string.encode("utf-8"), hashlib.sha256).digest()
    ).rstrip(b"=").decode("ascii")
    return {
        "x-flyai-sign-ver": "7", "x-flyai-sign-alg": "hmac-sha256",
        "x-flyai-ts": ts, "x-flyai-nonce": nonce, "x-flyai-sign": sig
    }

def call_mcp(tool_name: str, arguments: dict) -> dict:
    body = json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments}
    }, ensure_ascii=False, separators=(",", ":"))
    auth = f"Bearer {API_KEY}"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
        "Authorization": auth,
        "x-ff-ctx": generate_ff_ctx(SIGN_SECRET),
        "x-ttid": "ai2c(sk.clawhub)",
        "User-Agent": "flyai-cli/1.0.6 (Python/3.x)"
    }
    headers.update(generate_sign_headers(body, auth, SIGN_SECRET))
    try:
        resp = httpx.post(MCP_URL, headers=headers, content=body, timeout=MCP_TIMEOUT)
        ct = resp.headers.get("content-type", "")
        if "text/event-stream" in ct:
            for line in resp.text.split("\n"):
                if line.startswith("data:"):
                    try:
                        return json.loads(line[5:].strip())
                    except json.JSONDecodeError:
                        continue
            return {"error": "SSE解析失败"}
        return resp.json()
    except httpx.TimeoutException:
        return {"error": "请求超时，请稍后重试"}
    except Exception as e:
        return {"error": f"请求异常: {str(e)}"}

def parse_mcp_result(result: dict):
    if "error" in result:
        err = result["error"]
        if isinstance(err, dict):
            code = err.get("code", 0)
            msg = err.get("message", "未知错误")
            if code == -32601:
                return {"error": f"该功能当前不可用: {msg}"}
            if code == -32600:
                return {"error": f"认证失败: {msg}"}
            return {"error": f"API错误({code}): {msg}"}
        return {"error": str(err)}
    res = result.get("result", {})
    # result可能是字符串（fliggy_ai_search返回Markdown内容）
    if isinstance(res, str):
        return res
    if not isinstance(res, dict):
        return str(res)
    content = res.get("content", [])
    if content and isinstance(content, list) and len(content) > 0:
        first = content[0]
        if isinstance(first, dict) and first.get("type") == "text":
            try:
                return json.loads(first["text"])
            except json.JSONDecodeError:
                return first["text"]
    return result

# ============ MCP工具定义 ============

@mcp.tool()
def plan_travel(query: str) -> str:
    """根据自然语言需求智能规划旅行方案，涵盖酒店、景点、度假套餐和行程安排。

    适用于用户需求模糊或复杂的场景，如"不知道怎么安排""帮我规划""去哪玩"等。
    返回AI生成的完整推荐方案，包含分区/分类推荐、亮点、推荐理由和预订链接。

    Args:
        query: 用户的自然语言旅行需求（必填），如："三亚度蜜月预算1万怎么安排""国庆7天去云南路线""周末广州亲子游预算2000"
    """
    if not API_KEY or not SIGN_SECRET:
        return "错误：服务接口密钥未配置，请在环境变量中设置HOTEL_API_KEY和HOTEL_SIGN_SECRET"
    raw = call_mcp("fliggy_ai_search", {"query": query})
    data = parse_mcp_result(raw)
    if isinstance(data, dict) and "error" in data:
        return f"规划失败: {data['error']}"
    # parse_mcp_result已处理所有格式
    if isinstance(data, str):
        output = data
    elif isinstance(data, dict) and "data" in data and isinstance(data["data"], str):
        # fliggy_ai_search返回 {"data": "Markdown内容"}
        output = data["data"]
    else:
        output = str(data)
    return output + "\n\n> 数据来源：官方旅行商品库，价格实时更新，点击链接可直接预订"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
