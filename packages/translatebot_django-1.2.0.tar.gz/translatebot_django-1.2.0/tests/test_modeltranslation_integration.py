"""Integration tests for modeltranslation backend with actual models."""

from io import StringIO

import pytest

from django.core.management import call_command
from django.core.management.base import CommandError

from tests.models import Article
from translatebot_django.backends.modeltranslation import ModeltranslationBackend


@pytest.fixture
def article_with_translation(db):
    """Create an article instance for testing."""
    article = Article.objects.create(
        title="Hello World", content="This is test content"
    )
    return article


def test_modeltranslation_backend_parse_model_names_error():
    """Test backend parse_model_names with invalid model."""
    backend = ModeltranslationBackend(target_lang="nl")

    with pytest.raises(ValueError, match="not found"):
        backend.parse_model_names(["InvalidModel"])


def test_modeltranslation_backend_gather_translatable_content_empty():
    """Test gather_translatable_content with no registered models."""
    backend = ModeltranslationBackend(target_lang="nl")

    # With no models registered, should return empty list
    items = backend.gather_translatable_content()
    assert items == []


def test_translate_command_with_models_no_content(settings, mock_env_api_key, mocker):
    """Test --models flag when no translatable content found."""
    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()
    mock_backend.gather_translatable_content.return_value = []  # No items
    mock_backend_class.return_value = mock_backend

    out = StringIO()
    call_command("translate", target_lang="nl", models=[], stdout=out)

    output = out.getvalue()
    assert "No untranslated model fields found" in output


def test_translate_command_with_specific_models(settings, mock_env_api_key, mocker):
    """Test --models flag with specific model names."""
    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()

    # Simulate parse_model_names being called
    mock_backend.parse_model_names.return_value = [Article]
    mock_backend.gather_translatable_content.return_value = []
    mock_backend_class.return_value = mock_backend

    out = StringIO()
    call_command("translate", target_lang="nl", models=["Article"], stdout=out)

    # Verify parse_model_names was called with the model names
    mock_backend.parse_model_names.assert_called_once_with(["Article"])


def test_translate_command_models_with_items(settings, mock_env_api_key, mocker):
    """Test --models flag with items to translate."""
    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()

    # Create fake translatable items
    fake_item = {
        "model": Article,
        "instance": mocker.MagicMock(),
        "field": "title",
        "target_field": "title_nl",
        "source_text": "Hello World",
    }
    mock_backend.gather_translatable_content.return_value = [fake_item]
    mock_backend.apply_translations.return_value = 1
    mock_backend_class.return_value = mock_backend

    # Mock translate_text
    mocker.patch(
        "translatebot_django.management.commands.translate.translate_text",
        return_value=["Hallo Wereld"],
    )

    out = StringIO()
    call_command("translate", target_lang="nl", models=[], stdout=out)

    output = out.getvalue()
    assert "Found 1 model fields to translate" in output
    assert "Article" in output
    assert "Successfully translated 1 model field(s)" in output


def test_translate_command_models_dry_run(settings, mock_env_api_key, mocker):
    """Test --models flag with dry-run."""
    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()

    # Create fake translatable items
    fake_item = {
        "model": Article,
        "instance": mocker.MagicMock(),
        "field": "title",
        "target_field": "title_nl",
        "source_text": "Hello World",
    }
    mock_backend.gather_translatable_content.return_value = [fake_item]
    mock_backend.apply_translations.return_value = 1
    mock_backend_class.return_value = mock_backend

    # Mock translate_text
    mocker.patch(
        "translatebot_django.management.commands.translate.translate_text",
        return_value=["Hallo Wereld"],
    )

    out = StringIO()
    call_command("translate", target_lang="nl", models=[], dry_run=True, stdout=out)

    output = out.getvalue()
    assert "Dry run" in output

    # In dry-run mode, apply_translations should not be called
    mock_backend.apply_translations.assert_not_called()


def test_translate_command_models_parse_error(settings, mock_env_api_key, mocker):
    """Test --models flag with invalid model name."""
    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend to raise ValueError
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()
    mock_backend.parse_model_names.side_effect = ValueError("Model not found")
    mock_backend_class.return_value = mock_backend

    with pytest.raises(CommandError, match="Model not found"):
        call_command("translate", target_lang="nl", models=["InvalidModel"])


def test_translate_command_models_batching(settings, mock_env_api_key, mocker):
    """Test --models flag with batching when content exceeds token limits."""
    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()

    # Create many fake translatable items that would exceed token limits
    fake_items = []
    for i in range(100):
        # Create very long content to trigger batching
        fake_item = {
            "model": Article,
            "instance": mocker.MagicMock(),
            "field": "content",
            "target_field": "content_nl",
            "source_text": f"Very long content string {i} " * 100,  # Make it long
        }
        fake_items.append(fake_item)

    mock_backend.gather_translatable_content.return_value = fake_items
    mock_backend.apply_translations.return_value = len(fake_items)
    mock_backend_class.return_value = mock_backend

    # Mock translate_text to return translations for each batch
    translate_mock = mocker.patch(
        "translatebot_django.management.commands.translate.translate_text",
        side_effect=lambda text, **_kwargs: [
            f"Translated {i}" for i in range(len(text))
        ],
    )

    # Mock get_max_tokens to force batching with a low limit
    mocker.patch(
        "translatebot_django.management.commands.translate.get_max_tokens",
        return_value=1000,  # Low limit to force batching
    )

    out = StringIO()
    call_command("translate", target_lang="nl", models=[], stdout=out)

    output = out.getvalue()
    assert f"Found {len(fake_items)} model fields to translate" in output
    assert "batches" in output  # Should mention batches

    # Verify translate_text was called multiple times (batching occurred)
    assert translate_mock.call_count > 1


def test_translate_command_models_authentication_error(
    settings, mock_env_api_key, mocker
):
    """Test --models flag with authentication error."""
    from litellm.exceptions import AuthenticationError

    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()

    # Create fake translatable items
    fake_item = {
        "model": Article,
        "instance": mocker.MagicMock(),
        "field": "title",
        "target_field": "title_nl",
        "source_text": "Hello World",
    }
    mock_backend.gather_translatable_content.return_value = [fake_item]
    mock_backend_class.return_value = mock_backend

    # Mock translate_text to raise AuthenticationError
    mocker.patch(
        "translatebot_django.management.commands.translate.translate_text",
        side_effect=AuthenticationError(
            message="Invalid API key",
            llm_provider="openai",
            model="gpt-4o-mini",
        ),
    )

    with pytest.raises(CommandError, match="Authentication failed"):
        call_command("translate", target_lang="nl", models=[])


def test_translate_command_models_saves_after_each_batch(
    settings, mock_env_api_key, mocker
):
    """Test that completed batch translations are saved even if a later batch fails."""
    from litellm.exceptions import BadRequestError

    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    # Mock the backend
    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()

    # Create fake translatable items (enough for 2+ batches)
    fake_items = []
    for i in range(100):
        fake_items.append(
            {
                "model": Article,
                "instance": mocker.MagicMock(),
                "field": "content",
                "target_field": "content_nl",
                "source_text": f"Long content {i} " * 100,
            }
        )

    mock_backend.gather_translatable_content.return_value = fake_items
    mock_backend.apply_translations.return_value = 1
    mock_backend_class.return_value = mock_backend

    # First call succeeds, second raises an error
    call_count = {"n": 0}

    def translate_side_effect(text, **_kwargs):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return [f"Translated {i}" for i in range(len(text))]
        raise BadRequestError(
            message="credit balance is too low",
            model="gpt-4o-mini",
            llm_provider="openai",
        )

    mocker.patch(
        "translatebot_django.management.commands.translate.translate_text",
        side_effect=translate_side_effect,
    )

    # Mock get_max_tokens to force batching
    mocker.patch(
        "translatebot_django.management.commands.translate.get_max_tokens",
        return_value=1000,
    )

    with pytest.raises(CommandError, match="Insufficient API credits"):
        call_command("translate", target_lang="nl", models=[])

    # The first batch should have been saved before the second batch failed
    assert mock_backend.apply_translations.call_count == 1


def test_translate_command_models_sets_stats(settings, mock_env_api_key, mocker):
    """_translate_stats includes model field counts after --models translation."""
    from translatebot_django.management.commands.translate import Command

    settings.TRANSLATEBOT_MODEL = "gpt-4o-mini"

    mock_backend_class = mocker.patch(
        "translatebot_django.backends.modeltranslation.ModeltranslationBackend"
    )
    mock_backend = mocker.MagicMock()

    fake_items = [
        {
            "model": Article,
            "instance": mocker.MagicMock(),
            "field": "title",
            "target_field": "title_nl",
            "source_text": "Hello World",
        },
        {
            "model": Article,
            "instance": mocker.MagicMock(),
            "field": "content",
            "target_field": "content_nl",
            "source_text": "Some content",
        },
    ]
    mock_backend.gather_translatable_content.return_value = fake_items
    mock_backend.apply_translations.return_value = 2
    mock_backend_class.return_value = mock_backend

    mocker.patch(
        "translatebot_django.management.commands.translate.translate_text",
        return_value=["Hallo Wereld", "Wat inhoud"],
    )

    cmd = Command(stdout=StringIO(), stderr=StringIO())
    call_command(cmd, target_lang="nl", models=[])

    stats = cmd._translate_stats
    assert stats["model_fields_found"] == 2
    assert stats["model_fields_translated"] == 2
    assert stats["strings_found"] == 0
    assert stats["target_langs"] == ["nl"]
