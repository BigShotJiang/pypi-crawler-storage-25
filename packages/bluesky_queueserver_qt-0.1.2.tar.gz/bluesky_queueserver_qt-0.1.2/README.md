# Bluesky Queue Server Client (Qt)

[![PyPI version](https://badge.fury.io/py/bluesky-queueserver-qt.svg)](https://badge.fury.io/py/bluesky-queueserver-qt)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://opensource.org/licenses/BSD-3-Clause)

A PyQt5-based graphical interface for the [Bluesky Queue Server](https://github.com/bluesky/bluesky-queueserver). This client provides a user-friendly way to manage experimental queues, control the Run Engine (RE) environment, and monitor status in real-time.

## Features

- **Multi-Protocol Support**: Connect via ZMQ or HTTP/HTTPS to your Queue Server.
- **Queue Management**: Add, remove, edit, and reorder items in the queue.
- **Plan Browser**: Explore allowed plans and devices with drag-and-drop support for adding plans to the queue.
- **Batch Operations**: Create and submit batches of plans efficiently.
- **RE Control**: Start, stop, pause, resume, abort, and halt the Run Engine.
- **Environment Management**: Open, close, and destroy the worker environment.
- **Real-time Monitoring**: Live status updates and log monitoring.
- **History Tracking**: View previously executed plans and clear history.
- **Modern UI**: Dark-themed interface using the Fusion style.

## Installation

### Using pip

```bash
pip install bluesky-queueserver-qt
```

### Using pixi

If you have [pixi](https://pixi.sh) installed, you can clone the repository and run:

```bash
pixi run start
```

## Usage

Once installed, you can start the application using the command:

```bash
bluesky-queueserver-qt
```

### Connecting to a Server

1. Click on the **Connect** button (or go to `File -> Connect`).
2. Choose the protocol (**ZMQ** or **HTTP**).
3. Enter the server address (e.g., `localhost:60615` for ZMQ or `http://localhost:8080` for HTTP).
4. (Optional) Provide API keys or credentials if required by your server configuration.

## Development

This project uses `pixi` for development environment management.

```bash
# Install dependencies and set up environment
pixi install

# Run the application in development mode
pixi run start

# Run linting
pixi run -e dev ruff check .
```

## License

This project is licensed under the [BSD-3-Clause License](LICENSE).
