#!/usr/bin/env python3
"""
Bluesky Queue Server Client
A PyQt5 application for managing the Bluesky Queue Server.
"""

import sys
from PyQt5.QtWidgets import QApplication
from bluesky_queueserver_qt.ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Bluesky Queue Client")
    app.setOrganizationName("Bluesky")
    app.setStyle("Fusion")

    # Dark-ish stylesheet
    app.setStyleSheet("""
        QMainWindow {
            background-color: #1e1e2e;
        }
        QWidget {
            background-color: #1e1e2e;
            color: #cdd6f4;
            font-family: 'Segoe UI', 'DejaVu Sans', sans-serif;
            font-size: 13px;
        }
        QGroupBox {
            border: 1px solid #45475a;
            border-radius: 6px;
            margin-top: 8px;
            padding-top: 8px;
            font-weight: bold;
            color: #89b4fa;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 4px;
        }
        QPushButton {
            background-color: #313244;
            border: 1px solid #45475a;
            border-radius: 5px;
            padding: 5px 12px;
            color: #cdd6f4;
            font-weight: 500;
        }
        QPushButton:hover {
            background-color: #45475a;
            border-color: #89b4fa;
        }
        QPushButton:pressed {
            background-color: #585b70;
        }
        QPushButton:disabled {
            color: #585b70;
            border-color: #313244;
        }
        QPushButton#btn_start {
            background-color: #40a02b;
            border-color: #40a02b;
            color: white;
            font-weight: bold;
        }
        QPushButton#btn_start:hover { background-color: #4ec93a; }
        QPushButton#btn_stop {
            background-color: #e64553;
            border-color: #e64553;
            color: white;
            font-weight: bold;
        }
        QPushButton#btn_stop:hover { background-color: #f05a66; }
        QPushButton#btn_abort {
            background-color: #d20f39;
            border-color: #d20f39;
            color: white;
            font-weight: bold;
        }
        QPushButton#btn_abort:hover { background-color: #e6234e; }
        QPushButton#btn_pause {
            background-color: #df8e1d;
            border-color: #df8e1d;
            color: white;
            font-weight: bold;
        }
        QPushButton#btn_pause:hover { background-color: #f0a031; }
        QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
            background-color: #313244;
            border: 1px solid #45475a;
            border-radius: 4px;
            padding: 4px 8px;
            color: #cdd6f4;
        }
        QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {
            border-color: #89b4fa;
        }
        QComboBox::drop-down {
            border: none;
            padding-right: 8px;
        }
        QComboBox QAbstractItemView {
            background-color: #313244;
            border: 1px solid #45475a;
            selection-background-color: #45475a;
        }
        QListWidget, QTreeWidget, QTableWidget {
            background-color: #181825;
            border: 1px solid #45475a;
            border-radius: 4px;
            alternate-background-color: #1e1e2e;
        }
        QListWidget::item, QTreeWidget::item {
            padding: 4px 6px;
            border-radius: 3px;
        }
        QListWidget::item:selected, QTreeWidget::item:selected {
            background-color: #45475a;
            color: #cdd6f4;
        }
        QListWidget::item:hover, QTreeWidget::item:hover {
            background-color: #313244;
        }
        QHeaderView::section {
            background-color: #313244;
            color: #89b4fa;
            padding: 5px 8px;
            border: none;
            border-right: 1px solid #45475a;
            font-weight: 600;
        }
        QSplitter::handle {
            background-color: #45475a;
        }
        QTabWidget::pane {
            border: 1px solid #45475a;
            border-radius: 4px;
        }
        QTabBar::tab {
            background-color: #313244;
            color: #a6adc8;
            padding: 6px 16px;
            border-radius: 4px 4px 0 0;
            margin-right: 2px;
        }
        QTabBar::tab:selected {
            background-color: #45475a;
            color: #cdd6f4;
        }
        QTabBar::tab:hover {
            background-color: #45475a;
        }
        QScrollBar:vertical {
            background: #1e1e2e;
            width: 10px;
        }
        QScrollBar::handle:vertical {
            background: #45475a;
            border-radius: 5px;
            min-height: 20px;
        }
        QScrollBar::handle:vertical:hover { background: #585b70; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        QScrollBar:horizontal {
            background: #1e1e2e;
            height: 10px;
        }
        QScrollBar::handle:horizontal {
            background: #45475a;
            border-radius: 5px;
        }
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }
        QProgressBar {
            background-color: #313244;
            border: 1px solid #45475a;
            border-radius: 4px;
            text-align: center;
            color: #cdd6f4;
        }
        QProgressBar::chunk {
            background-color: #89b4fa;
            border-radius: 3px;
        }
        QToolBar {
            background-color: #181825;
            border-bottom: 1px solid #45475a;
            spacing: 4px;
            padding: 4px;
        }
        QMenuBar {
            background-color: #181825;
            border-bottom: 1px solid #45475a;
        }
        QMenuBar::item:selected {
            background-color: #313244;
            border-radius: 3px;
        }
        QMenu {
            background-color: #313244;
            border: 1px solid #45475a;
            border-radius: 4px;
            padding: 4px;
        }
        QMenu::item {
            padding: 5px 24px 5px 12px;
            border-radius: 3px;
        }
        QMenu::item:selected {
            background-color: #45475a;
        }
        QLabel#status_indicator {
            font-weight: bold;
            padding: 2px 8px;
            border-radius: 3px;
        }
        QTextEdit {
            background-color: #181825;
            border: 1px solid #45475a;
            border-radius: 4px;
            color: #a6e3a1;
            font-family: monospace;
            font-size: 12px;
        }
        QDialog {
            background-color: #1e1e2e;
        }
        QCheckBox::indicator {
            width: 14px;
            height: 14px;
            border: 1px solid #45475a;
            border-radius: 3px;
            background: #313244;
        }
        QCheckBox::indicator:checked {
            background: #89b4fa;
        }
        QToolTip {
            background-color: #313244;
            color: #cdd6f4;
            border: 1px solid #45475a;
            border-radius: 4px;
            padding: 4px;
        }
    """)

    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
