"""
Queue display widget.
Shows current queue items, supports drag-and-drop reordering, and
accepts drops from the plan browser.
"""

import json
from typing import List, Optional

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QLabel, QPushButton, QAbstractItemView, QMenu, QAction
)
from PyQt5.QtCore import Qt, pyqtSignal, QPoint
from PyQt5.QtGui import QColor, QFont, QBrush

from bluesky_queueserver_qt.core.models import QueueItem
from bluesky_queueserver_qt.widgets.plan_browser import PLAN_MIME


STATUS_COLORS = {
    "completed": "#a6e3a1",
    "failed": "#f38ba8",
    "running": "#fab387",
    "unknown": "#a6adc8",
}


class QueueListItem(QListWidgetItem):
    """A list widget item wrapping a QueueItem."""

    def __init__(self, queue_item: QueueItem, index: int):
        super().__init__()
        self.queue_item = queue_item
        self.update_display(index)

    def update_display(self, index: int):
        itype = self.queue_item.item_type
        status = (self.queue_item.result or {}).get("exit_status", "")
        icon = {"plan": "📋", "instruction": "⚙", "function": "ƒ"}.get(itype, "?")
        text = f"  {index + 1:>3}.  {icon} {self.queue_item.display_name()}"
        self.setText(text)
        self.setToolTip(json.dumps(self.queue_item.to_dict(), indent=2))

        color = STATUS_COLORS.get(status, STATUS_COLORS["unknown"])
        self.setForeground(QBrush(QColor(color)))

        uid = self.queue_item.item_uid
        if uid:
            self.setData(Qt.UserRole, uid)


class QueueListWidget(QListWidget):
    """
    List widget for the queue.
    Supports internal drag-drop for reordering and
    accepts drops from the plan browser.
    """
    item_move_requested = pyqtSignal(str, int)   # uid, new_pos
    plan_drop_received = pyqtSignal(dict)         # plan info from browser

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragDropMode(QAbstractItemView.DragDrop)
        self.setDefaultDropAction(Qt.MoveAction)
        self.setAcceptDrops(True)
        self.setAlternatingRowColors(True)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSpacing(1)

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat(PLAN_MIME):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat(PLAN_MIME):
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasFormat(PLAN_MIME):
            raw = event.mimeData().data(PLAN_MIME).data()
            plan_info = json.loads(raw.decode())
            self.plan_drop_received.emit(plan_info)
            event.acceptProposedAction()
        else:
            super().dropEvent(event)


class QueuePanel(QWidget):
    """Panel showing the current queue with controls."""

    # Emitted when user requests queue actions
    start_requested = pyqtSignal()
    stop_requested = pyqtSignal()
    pause_requested = pyqtSignal()
    resume_requested = pyqtSignal()
    abort_requested = pyqtSignal()
    halt_requested = pyqtSignal()
    clear_requested = pyqtSignal()
    remove_items_requested = pyqtSignal(list)    # list of uids
    move_item_requested = pyqtSignal(str, int)   # uid, new_pos
    edit_item_requested = pyqtSignal(QueueItem)
    add_plan_requested = pyqtSignal(dict)        # plan_info (from drop)
    execute_item_requested = pyqtSignal(str)     # uid

    def __init__(self, parent=None):
        super().__init__(parent)
        self._items: List[QueueItem] = []
        self._running_uid: Optional[str] = None
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # --- Toolbar ---
        tb = QHBoxLayout()
        tb.setSpacing(4)

        self.btn_start = QPushButton("▶ Start")
        self.btn_start.setObjectName("btn_start")
        self.btn_start.setToolTip("Start the queue")
        self.btn_start.clicked.connect(self.start_requested)

        self.btn_stop = QPushButton("⏹ Stop")
        self.btn_stop.setObjectName("btn_stop")
        self.btn_stop.setToolTip("Stop queue after current item")
        self.btn_stop.clicked.connect(self.stop_requested)

        self.btn_pause = QPushButton("⏸ Pause")
        self.btn_pause.setObjectName("btn_pause")
        self.btn_pause.setToolTip("Pause current plan")
        self.btn_pause.clicked.connect(self.pause_requested)

        self.btn_resume = QPushButton("⏯ Resume")
        self.btn_resume.setToolTip("Resume paused plan")
        self.btn_resume.clicked.connect(self.resume_requested)

        self.btn_abort = QPushButton("🚫 Abort")
        self.btn_abort.setObjectName("btn_abort")
        self.btn_abort.setToolTip("Abort current plan immediately")
        self.btn_abort.clicked.connect(self.abort_requested)

        self.btn_clear = QPushButton("🗑 Clear")
        self.btn_clear.setToolTip("Clear entire queue")
        self.btn_clear.clicked.connect(self.clear_requested)

        for btn in [self.btn_start, self.btn_stop, self.btn_pause,
                    self.btn_resume, self.btn_abort, self.btn_clear]:
            tb.addWidget(btn)
        tb.addStretch()

        self.queue_count_label = QLabel("0 items")
        self.queue_count_label.setStyleSheet("color: #a6adc8;")
        tb.addWidget(self.queue_count_label)

        layout.addLayout(tb)

        # --- Progress bar area ---
        self.progress_label = QLabel("Queue progress")
        self.progress_label.setStyleSheet("color: #a6adc8; font-size: 11px;")
        layout.addWidget(self.progress_label)

        from PyQt5.QtWidgets import QProgressBar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setMaximumHeight(12)
        self.progress_bar.setTextVisible(False)
        layout.addWidget(self.progress_bar)

        # --- Queue list ---
        self.list_widget = QueueListWidget()
        self.list_widget.plan_drop_received.connect(self.add_plan_requested)
        self.list_widget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list_widget.customContextMenuRequested.connect(self._context_menu)
        self.list_widget.itemDoubleClicked.connect(self._on_double_click)
        layout.addWidget(self.list_widget)

    def set_queue(self, items: List[QueueItem], running_uid: Optional[str] = None):
        self._items = items
        self._running_uid = running_uid
        self._rebuild()

    def _rebuild(self):
        self.list_widget.clear()
        for i, item in enumerate(self._items):
            wi = QueueListItem(item, i)
            if item.item_uid == self._running_uid:
                wi.setBackground(QBrush(QColor("#2a2a3e")))
                font = QFont()
                font.setBold(True)
                wi.setFont(font)
                wi.setText("  ▶ " + wi.text().strip())
            self.list_widget.addItem(wi)

        total = len(self._items)
        self.queue_count_label.setText(f"{total} item{'s' if total != 1 else ''}")

    def update_progress(self, completed: int, total: int):
        if total > 0:
            pct = int(100 * completed / total)
            self.progress_bar.setRange(0, total)
            self.progress_bar.setValue(completed)
            self.progress_label.setText(
                f"Queue progress: {completed}/{total} completed ({pct}%)"
            )
        else:
            self.progress_bar.setValue(0)
            self.progress_label.setText("Queue is empty")
            self.progress_bar.setRange(0, 100)

    def set_controls_state(self, manager_state: str, re_state: str):
        """Enable/disable buttons based on server state."""
        running = manager_state == "executing_queue"
        paused = re_state in ("paused",)
        idle = manager_state == "idle"
        env_exists = manager_state not in ("creating_environment", "destroying_environment",
                                            "initializing", "")

        self.btn_start.setEnabled(idle and env_exists)
        self.btn_stop.setEnabled(running)
        self.btn_pause.setEnabled(running and not paused)
        self.btn_resume.setEnabled(paused)
        self.btn_abort.setEnabled(running or paused)

    def _context_menu(self, pos: QPoint):
        items = self.list_widget.selectedItems()
        if not items:
            return
        menu = QMenu(self)

        if len(items) == 1:
            wi = items[0]
            if isinstance(wi, QueueListItem):
                edit_action = QAction("✏️ Edit", self)
                edit_action.triggered.connect(lambda: self.edit_item_requested.emit(wi.queue_item))
                menu.addAction(edit_action)

                exec_action = QAction("▶ Execute Now", self)
                uid = wi.queue_item.item_uid
                if uid:
                    exec_action.triggered.connect(lambda: self.execute_item_requested.emit(uid))
                menu.addAction(exec_action)
                menu.addSeparator()

        remove_action = QAction(f"🗑 Remove {len(items)} item(s)", self)
        uids = [i.data(Qt.UserRole) for i in items if i.data(Qt.UserRole)]
        remove_action.triggered.connect(lambda: self.remove_items_requested.emit(uids))
        menu.addAction(remove_action)

        menu.exec_(self.list_widget.viewport().mapToGlobal(pos))

    def _on_double_click(self, item: QListWidgetItem):
        if isinstance(item, QueueListItem):
            self.edit_item_requested.emit(item.queue_item)
