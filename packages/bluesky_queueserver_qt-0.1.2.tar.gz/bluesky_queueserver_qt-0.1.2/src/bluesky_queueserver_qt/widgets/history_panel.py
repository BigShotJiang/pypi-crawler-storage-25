"""
History panel: shows completed queue items.
"""

import json
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLabel, QHeaderView, QAbstractItemView, QTextEdit,
    QSplitter
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor, QBrush


EXIT_COLORS = {
    "completed": "#a6e3a1",
    "failed": "#f38ba8",
    "stopped": "#f9e2af",
    "aborted": "#fab387",
    "halted": "#cba6f7",
}


class HistoryPanel(QWidget):
    rerun_requested = pyqtSignal(dict)   # item dict to re-add

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        splitter = QSplitter(Qt.Vertical)

        # Table
        top = QWidget()
        tl = QVBoxLayout(top)
        tl.setContentsMargins(0, 0, 0, 0)

        hdr = QHBoxLayout()
        hdr.addWidget(QLabel("Run History"))
        hdr.addStretch()
        self.clear_btn = QPushButton("🗑 Clear History")
        hdr.addWidget(self.clear_btn)
        tl.addLayout(hdr)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["#", "Name", "Type", "Status", "Exit Status"])
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemSelectionChanged.connect(self._on_selection)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)
        tl.addWidget(self.table)
        splitter.addWidget(top)

        # Detail view
        bot = QWidget()
        bl = QVBoxLayout(bot)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.addWidget(QLabel("Item Detail:"))
        self.detail_view = QTextEdit()
        self.detail_view.setReadOnly(True)
        self.detail_view.setMaximumHeight(120)
        bl.addWidget(self.detail_view)
        splitter.addWidget(bot)

        layout.addWidget(splitter)

    def set_history(self, items: list):
        if self.table.rowCount() == len(items):
            # Check if we actually need to update.
            # Usually history only grows, so we can do a simple optimization.
            # If length is the same, we assume nothing changed unless we want to be more thorough.
            return
        self.table.setRowCount(0)
        # Reversed so newest is at top
        for i, item in enumerate(reversed(items)):
            row = self.table.rowCount()
            self.table.insertRow(row)
            result = item.get("result", {}) or {}
            exit_status = result.get("exit_status", "unknown")

            cells = [
                str(len(items) - i),
                item.get("name", ""),
                item.get("item_type", ""),
                result.get("msg", ""),
                exit_status,
            ]
            for col, val in enumerate(cells):
                cell = QTableWidgetItem(val)
                cell.setData(Qt.UserRole, item)
                color = EXIT_COLORS.get(exit_status, "#a6adc8")
                cell.setForeground(QBrush(QColor(color)))
                self.table.setItem(row, col, cell)

    def _on_selection(self):
        rows = self.table.selectedItems()
        if rows:
            item = rows[0].data(Qt.UserRole)
            if item:
                self.detail_view.setPlainText(json.dumps(item, indent=2))

    def _context_menu(self, pos):
        from PyQt5.QtWidgets import QMenu, QAction
        rows = self.table.selectedItems()
        if not rows:
            return
        item = rows[0].data(Qt.UserRole)
        if not item:
            return
        menu = QMenu(self)
        rerun_action = QAction("♻️ Re-add to Queue", self)
        rerun_action.triggered.connect(lambda: self.rerun_requested.emit(item))
        menu.addAction(rerun_action)
        menu.exec_(self.table.viewport().mapToGlobal(pos))
