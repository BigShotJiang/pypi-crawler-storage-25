"""
Batch queue editor: build, save, and load batch queues.
"""

import json
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QPushButton, QLabel, QFileDialog, QInputDialog, QMessageBox,
    QAbstractItemView, QMenu, QAction
)
from PyQt5.QtCore import Qt, pyqtSignal

from bluesky_queueserver_qt.core.models import QueueItem, BatchQueue


class BatchQueuePanel(QWidget):
    """Panel for building, loading, saving, and submitting batch queues."""

    submit_batch_requested = pyqtSignal(list)   # list of QueueItem
    edit_item_requested = pyqtSignal(QueueItem, int)  # item, index in batch

    def __init__(self, plans: dict = None, devices: dict = None, parent=None):
        super().__init__(parent)
        self._plans = plans or {}
        self._devices = devices or {}
        self._batch = BatchQueue()
        self._build_ui()

    def set_plans(self, plans: dict):
        self._plans = plans

    def set_devices(self, devices: dict):
        self._devices = devices

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # Header
        header = QHBoxLayout()
        self.batch_name_label = QLabel(f"Batch: {self._batch.name}")
        self.batch_name_label.setStyleSheet("color: #89b4fa; font-weight: bold;")
        header.addWidget(self.batch_name_label)
        header.addStretch()
        layout.addLayout(header)

        # Toolbar
        tb = QHBoxLayout()
        tb.setSpacing(4)

        self.btn_new = QPushButton("📄 New")
        self.btn_new.setToolTip("Create new empty batch")
        self.btn_new.clicked.connect(self._new_batch)

        self.btn_load = QPushButton("📂 Load")
        self.btn_load.setToolTip("Load batch from JSON file")
        self.btn_load.clicked.connect(self._load_batch)

        self.btn_save = QPushButton("💾 Save")
        self.btn_save.setToolTip("Save batch to JSON file")
        self.btn_save.clicked.connect(self._save_batch)

        self.btn_submit = QPushButton("🚀 Submit to Queue")
        self.btn_submit.setToolTip("Add all batch items to server queue")
        self.btn_submit.clicked.connect(self._submit)

        self.btn_add_plan = QPushButton("➕ Add Plan")
        self.btn_add_plan.setToolTip("Add a plan to the batch")
        self.btn_add_plan.clicked.connect(self._add_plan)

        self.btn_duplicate = QPushButton("⧉ Duplicate")
        self.btn_duplicate.clicked.connect(self._duplicate_selected)

        self.btn_remove = QPushButton("🗑 Remove")
        self.btn_remove.clicked.connect(self._remove_selected)

        for btn in [self.btn_new, self.btn_load, self.btn_save, self.btn_submit,
                    self.btn_add_plan, self.btn_duplicate, self.btn_remove]:
            tb.addWidget(btn)
        tb.addStretch()
        layout.addLayout(tb)

        # List
        self.list_widget = QListWidget()
        self.list_widget.setDragDropMode(QAbstractItemView.InternalMove)
        self.list_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list_widget.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list_widget.customContextMenuRequested.connect(self._context_menu)
        self.list_widget.itemDoubleClicked.connect(self._on_double_click)
        layout.addWidget(self.list_widget)

        # Item count
        self.count_label = QLabel("0 items in batch")
        self.count_label.setStyleSheet("color: #a6adc8; font-size: 11px;")
        layout.addWidget(self.count_label)

    def _refresh_list(self):
        self.list_widget.clear()
        for i, item in enumerate(self._batch.items):
            wi = QListWidgetItem(f"  {i+1:>3}.  {item.summary()}")
            wi.setData(Qt.UserRole, item)
            wi.setToolTip(json.dumps(item.to_dict(), indent=2))
            self.list_widget.addItem(wi)
        n = len(self._batch)
        self.count_label.setText(f"{n} item{'s' if n != 1 else ''} in batch")
        self.batch_name_label.setText(f"Batch: {self._batch.name}")

    def add_item(self, item: QueueItem):
        self._batch.items.append(item)
        self._refresh_list()

    def add_items(self, items: list):
        self._batch.items.extend(items)
        self._refresh_list()

    def _new_batch(self):
        name, ok = QInputDialog.getText(self, "New Batch", "Batch name:", text="Untitled Batch")
        if ok:
            self._batch = BatchQueue(name=name)
            self._refresh_list()

    def _load_batch(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Batch Queue", "", "Batch Queue Files (*.json);;All Files (*)"
        )
        if path:
            try:
                self._batch = BatchQueue.load(path)
                self._refresh_list()
            except Exception as e:
                QMessageBox.critical(self, "Load Error", f"Failed to load batch:\n{e}")

    def _save_batch(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Batch Queue", f"{self._batch.name}.json",
            "Batch Queue Files (*.json);;All Files (*)"
        )
        if path:
            try:
                self._batch.save(path)
                QMessageBox.information(self, "Saved", f"Batch saved to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Save Error", f"Failed to save batch:\n{e}")

    def _submit(self):
        if not self._batch.items:
            QMessageBox.information(self, "Empty Batch", "No items in batch.")
            return
        reply = QMessageBox.question(
            self, "Submit Batch",
            f"Submit {len(self._batch)} item(s) to the server queue?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.submit_batch_requested.emit(list(self._batch.items))

    def _add_plan(self):
        if not self._plans:
            QMessageBox.information(self, "No Plans", "No plans loaded yet. Connect to server first.")
            return
        plan_names = sorted(self._plans.keys())
        name, ok = QInputDialog.getItem(self, "Select Plan", "Plan:", plan_names, 0, False)
        if ok and name:
            plan_info = {"name": name, "info": self._plans[name]}
            self._open_edit_dialog(plan_info)

    def _open_edit_dialog(self, plan_info: dict, existing_item=None, index=-1):
        from queueserver_qt.ui.plan_edit_dialog import PlanEditDialog
        dlg = PlanEditDialog(plan_info, existing_item=existing_item,
                             devices=self._devices, parent=self)
        if dlg.exec_():
            new_items = dlg.get_items()
            if index >= 0:
                self._batch.items[index:index+1] = new_items
            else:
                self._batch.items.extend(new_items)
            self._refresh_list()

    def _duplicate_selected(self):
        import copy
        selected = self.list_widget.selectedItems()
        for wi in selected:
            item = wi.data(Qt.UserRole)
            if item:
                dup = QueueItem(copy.deepcopy(item.to_dict()))
                idx = self.list_widget.row(wi)
                self._batch.items.insert(idx + 1, dup)
        self._refresh_list()

    def _remove_selected(self):
        rows = sorted(set(self.list_widget.row(wi)
                          for wi in self.list_widget.selectedItems()), reverse=True)
        for r in rows:
            del self._batch.items[r]
        self._refresh_list()

    def _context_menu(self, pos):
        items = self.list_widget.selectedItems()
        if not items:
            return
        menu = QMenu(self)
        if len(items) == 1:
            edit_action = QAction("✏️ Edit", self)
            wi = items[0]
            idx = self.list_widget.row(wi)
            item = wi.data(Qt.UserRole)
            plan_info = {"name": item.name, "info": self._plans.get(item.name, {})}
            edit_action.triggered.connect(lambda: self._open_edit_dialog(plan_info, item, idx))
            menu.addAction(edit_action)

            dup_action = QAction("⧉ Duplicate", self)
            dup_action.triggered.connect(self._duplicate_selected)
            menu.addAction(dup_action)
            menu.addSeparator()

        remove_action = QAction(f"🗑 Remove {len(items)} item(s)", self)
        remove_action.triggered.connect(self._remove_selected)
        menu.addAction(remove_action)
        menu.exec_(self.list_widget.viewport().mapToGlobal(pos))

    def _on_double_click(self, wi: QListWidgetItem):
        item = wi.data(Qt.UserRole)
        if item:
            idx = self.list_widget.row(wi)
            plan_info = {"name": item.name, "info": self._plans.get(item.name, {})}
            self._open_edit_dialog(plan_info, item, idx)
