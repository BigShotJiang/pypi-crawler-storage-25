"""
Plan/Device browser panel.
Shows allowed plans (and devices) from the queue server.
Supports drag-and-drop onto the queue.
"""

import json
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem, QLineEdit, QTabWidget,
    QAbstractItemView, QMenu, QAction
)
from PyQt5.QtCore import Qt, QMimeData, pyqtSignal
from PyQt5.QtGui import QDrag, QFont, QColor


PLAN_MIME = "application/x-bsqs-plan"


class DraggablePlanTree(QTreeWidget):
    """TreeWidget that supports dragging plan items."""

    plan_double_clicked = pyqtSignal(dict)  # plan info dict

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setDragDropMode(QAbstractItemView.DragOnly)
        self.setSelectionMode(QAbstractItemView.SingleSelection)
        self.setHeaderHidden(True)
        self.setAlternatingRowColors(True)
        self.itemDoubleClicked.connect(self._on_double_click)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._context_menu)

    def startDrag(self, actions):
        item = self.currentItem()
        if not item or not item.data(0, Qt.UserRole):
            return
        plan_data = item.data(0, Qt.UserRole)
        mime = QMimeData()
        mime.setData(PLAN_MIME, json.dumps(plan_data).encode())
        drag = QDrag(self)
        drag.setMimeData(mime)
        drag.exec_(Qt.CopyAction)

    def _on_double_click(self, item, column):
        data = item.data(0, Qt.UserRole)
        if data:
            self.plan_double_clicked.emit(data)

    def _context_menu(self, pos):
        item = self.itemAt(pos)
        if not item or not item.data(0, Qt.UserRole):
            return
        menu = QMenu(self)
        add_action = QAction("Add to Queue", self)
        add_action.triggered.connect(lambda: self.plan_double_clicked.emit(item.data(0, Qt.UserRole)))
        menu.addAction(add_action)
        menu.exec_(self.viewport().mapToGlobal(pos))


class PlanBrowserPanel(QWidget):
    """Left panel: lists allowed plans and devices."""

    add_plan_requested = pyqtSignal(dict)   # plan info dict -> open add dialog

    def __init__(self, parent=None):
        super().__init__(parent)
        self._plans: dict = {}
        self._devices: dict = {}
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # Search bar
        search_layout = QHBoxLayout()
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Filter plans/devices...")
        self.search_box.textChanged.connect(self._apply_filter)
        search_layout.addWidget(self.search_box)
        layout.addLayout(search_layout)

        self.tabs = QTabWidget()

        # Plans tab
        plans_tab = QWidget()
        ptl = QVBoxLayout(plans_tab)
        ptl.setContentsMargins(0, 4, 0, 0)
        self.plan_tree = DraggablePlanTree()
        self.plan_tree.plan_double_clicked.connect(self.add_plan_requested)
        ptl.addWidget(QLabel("Drag onto queue or double-click to add:"))
        ptl.addWidget(self.plan_tree)
        self.tabs.addTab(plans_tab, "📋 Plans")

        # Devices tab
        devices_tab = QWidget()
        dtl = QVBoxLayout(devices_tab)
        dtl.setContentsMargins(0, 4, 0, 0)
        self.device_tree = QTreeWidget()
        self.device_tree.setHeaderLabels(["Name", "Type"])
        self.device_tree.setAlternatingRowColors(True)
        dtl.addWidget(self.device_tree)
        self.tabs.addTab(devices_tab, "🔧 Devices")

        layout.addWidget(self.tabs)

        # Refresh button
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.setToolTip("Reload allowed plans and devices from server")
        layout.addWidget(self.refresh_btn)

    def set_plans(self, plans: dict):
        self._plans = plans
        self._rebuild_plan_tree(plans)

    def set_devices(self, devices: dict):
        self._devices = devices
        self._rebuild_device_tree(devices)

    def _rebuild_plan_tree(self, plans: dict):
        self.plan_tree.clear()
        for name, info in sorted(plans.items()):
            item = QTreeWidgetItem([name])
            item.setData(0, Qt.UserRole, {"name": name, "info": info})
            desc = (info.get("description") or "").strip()
            if desc:
                item.setToolTip(0, desc[:300])
            # Add parameter children
            params = info.get("parameters", [])
            if params:
                for p in params:
                    pname = p.get("name", "?")
                    pkind = p.get("kind", {}).get("name", "")
                    ann = p.get("annotation", {})
                    ann_str = ann.get("type", "") if isinstance(ann, dict) else str(ann)
                    default = p.get("default")
                    child_text = pname
                    if ann_str:
                        child_text += f" : {ann_str}"
                    if default is not None and default != "REQUIRED":
                        child_text += f" = {default}"
                    child = QTreeWidgetItem([child_text])
                    child.setForeground(0, QColor("#a6adc8"))
                    font = QFont()
                    font.setItalic(True)
                    child.setFont(0, font)
                    item.addChild(child)
            self.plan_tree.addTopLevelItem(item)

    def _rebuild_device_tree(self, devices: dict):
        self.device_tree.clear()
        for name, info in sorted(devices.items()):
            kind = info.get("classname", info.get("kind", "device"))
            item = QTreeWidgetItem([name, kind])
            item.setToolTip(0, str(info))
            self.device_tree.addTopLevelItem(item)

    def _apply_filter(self, text: str):
        text = text.lower()
        for i in range(self.plan_tree.topLevelItemCount()):
            item = self.plan_tree.topLevelItem(i)
            visible = text in item.text(0).lower()
            item.setHidden(not visible)
        for i in range(self.device_tree.topLevelItemCount()):
            item = self.device_tree.topLevelItem(i)
            visible = text in item.text(0).lower()
            item.setHidden(not visible)
