"""
Bottom status panel: RE Manager status indicators + console output.
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QTextEdit, QPushButton
)
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtGui import QTextCursor, QFont


STATE_COLORS = {
    "idle": ("#a6e3a1", "#1e3a2f"),
    "executing_queue": ("#fab387", "#3a2a1e"),
    "paused": ("#f9e2af", "#3a361e"),
    "executing_task": ("#89dceb", "#1e323a"),
    "starting_device_server": ("#cba6f7", "#2a1e3a"),
    "creating_environment": ("#cba6f7", "#2a1e3a"),
    "destroying_environment": ("#f38ba8", "#3a1e1e"),
    "closing_environment": ("#f38ba8", "#3a1e1e"),
    "error": ("#f38ba8", "#3a1e1e"),
    "": ("#585b70", "#1e1e2e"),
}


def _state_style(state: str):
    fg, bg = STATE_COLORS.get(state, ("#a6adc8", "#1e1e2e"))
    return f"color: {fg}; background-color: {bg}; border-radius: 4px; padding: 2px 8px; font-weight: bold;"


class StatusIndicator(QLabel):
    def __init__(self, label: str, parent=None):
        super().__init__(parent)
        self._label = label
        self.set_value("—")

    def set_value(self, value: str):
        self.setText(f"{self._label}: {value}")
        style = _state_style(value)
        self.setStyleSheet(style)


class StatusPanel(QWidget):
    """Bottom panel showing server status and console output."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMaximumHeight(260)
        self.setMinimumHeight(140)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # === Status bar row ===
        status_row = QHBoxLayout()
        status_row.setSpacing(8)

        self.conn_indicator = QLabel("● Disconnected")
        self.conn_indicator.setStyleSheet("color: #f38ba8; font-weight: bold;")

        self.manager_state = StatusIndicator("Manager")
        self.re_state = StatusIndicator("RE")
        self.env_state = StatusIndicator("Env")
        self.workers_label = QLabel("")
        self.workers_label.setStyleSheet("color: #a6adc8;")

        self.queue_pos_label = QLabel("")
        self.queue_pos_label.setStyleSheet("color: #89dceb;")

        status_row.addWidget(self.conn_indicator)

        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet("color: #45475a;")
        status_row.addWidget(sep)

        status_row.addWidget(self.manager_state)
        status_row.addWidget(self.re_state)
        status_row.addWidget(self.env_state)

        sep2 = QFrame()
        sep2.setFrameShape(QFrame.VLine)
        sep2.setStyleSheet("color: #45475a;")
        status_row.addWidget(sep2)

        status_row.addWidget(self.workers_label)
        status_row.addWidget(self.queue_pos_label)
        status_row.addStretch()

        # Environment control buttons
        self.btn_open_env = QPushButton("Open Env")
        self.btn_open_env.setFixedWidth(80)
        self.btn_close_env = QPushButton("Close Env")
        self.btn_close_env.setFixedWidth(80)
        status_row.addWidget(self.btn_open_env)
        status_row.addWidget(self.btn_close_env)

        layout.addLayout(status_row)

        # === Console output ===
        console_row = QHBoxLayout()
        console_label = QLabel("Console Output")
        console_label.setStyleSheet("color: #89b4fa; font-weight: bold; font-size: 11px;")
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setFixedWidth(50)
        self.clear_btn.setFixedHeight(18)
        self.clear_btn.setStyleSheet("font-size: 10px; padding: 0 4px;")
        self.clear_btn.clicked.connect(self._clear_console)
        console_row.addWidget(console_label)
        console_row.addStretch()
        console_row.addWidget(self.clear_btn)
        layout.addLayout(console_row)

        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Monospace", 10))
        self.console.setMaximumHeight(150)
        layout.addWidget(self.console)

    def set_connected(self, connected: bool, label: str = ""):
        if connected:
            self.conn_indicator.setText(f"● {label or 'Connected'}")
            self.conn_indicator.setStyleSheet("color: #a6e3a1; font-weight: bold;")
        else:
            self.conn_indicator.setText("● Disconnected")
            self.conn_indicator.setStyleSheet("color: #f38ba8; font-weight: bold;")

    @pyqtSlot(dict)
    def update_status(self, status: dict):
        mgr = status.get("manager_state", "")
        re = status.get("re_state", "")
        env = "open" if status.get("worker_environment_exists") else "closed"

        self.manager_state.set_value(mgr)
        self.re_state.set_value(re)
        self.env_state.set_value(env)

        items_in_queue = status.get("items_in_queue", 0)
        items_done = status.get("items_in_history", 0)
        pos = status.get("running_item_uid", "")

        self.queue_pos_label.setText(
            f"Queue: {items_in_queue} pending  |  History: {items_done}"
        )

        n_workers = status.get("n_completed_runs", "")
        self.workers_label.setText(f"Completed: {n_workers}" if n_workers != "" else "")

        # Enable/disable env buttons
        env_exists = status.get("worker_environment_exists", False)
        env_state = status.get("worker_environment_state", "")
        busy = mgr not in ("idle", "")
        self.btn_open_env.setEnabled(not env_exists and not busy)
        self.btn_close_env.setEnabled(env_exists and not busy)

    @pyqtSlot(str)
    def append_console(self, text: str):
        # append() handles its own cursor; avoids the QTextCursor
        # metatype issue that causes a segfault on cross-thread calls.
        self.console.moveCursor(QTextCursor.End)
        self.console.insertPlainText(text)
        self.console.moveCursor(QTextCursor.End)

    @pyqtSlot(str)
    def append_log(self, msg: str):
        self.console.append(f"[LOG] {msg}")

    def _clear_console(self):
        self.console.clear()