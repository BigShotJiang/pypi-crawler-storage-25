"""
Queue item data models and serialization.
"""

import json
import copy
from typing import List, Optional


ITEM_TYPES = ("plan", "instruction", "function")


class QueueItem:
    """Represents a single item in the RE queue."""

    def __init__(self, item_dict: dict):
        self._data = copy.deepcopy(item_dict)

    @classmethod
    def new_plan(cls, name: str, args=None, kwargs=None, meta=None) -> "QueueItem":
        d = {
            "item_type": "plan",
            "name": name,
            "args": args or [],
            "kwargs": kwargs or {},
            "meta": meta or {},
        }
        return cls(d)

    @classmethod
    def new_instruction(cls, name: str, kwargs=None) -> "QueueItem":
        d = {
            "item_type": "instruction",
            "name": name,
            "kwargs": kwargs or {},
        }
        return cls(d)

    @property
    def item_type(self) -> str:
        return self._data.get("item_type", "plan")

    @property
    def name(self) -> str:
        return self._data.get("name", "")

    @property
    def args(self) -> list:
        return self._data.get("args", [])

    @property
    def kwargs(self) -> dict:
        return self._data.get("kwargs", {})

    @property
    def meta(self) -> dict:
        return self._data.get("meta", {})

    @property
    def item_uid(self) -> Optional[str]:
        return self._data.get("item_uid")

    @property
    def result(self) -> Optional[dict]:
        return self._data.get("result")

    def to_dict(self) -> dict:
        return copy.deepcopy(self._data)

    def to_bitem(self):
        """Convert to bluesky_queueserver_api BItem/BPlan/BInst."""
        from bluesky_queueserver_api import BPlan, BInst, BFunc, BItem
        itype = self.item_type
        if itype == "plan":
            item = BPlan(self.name, *self.args, **self.kwargs)
        elif itype == "instruction":
            item = BInst(self.name, **self.kwargs)
        elif itype == "function":
            item = BFunc(self.name, *self.args, **self.kwargs)
        else:
            item = BItem(itype, self.name, *self.args, **self.kwargs)
        if self.meta:
            item.meta.update(self.meta)
        return item

    def display_name(self) -> str:
        parts = [self.name]
        if self.args:
            parts.append(f"args={self.args}")
        if self.kwargs:
            kw_str = ", ".join(f"{k}={v}" for k, v in self.kwargs.items())
            parts.append(kw_str)
        return "  ".join(parts)

    def summary(self) -> str:
        """One-line human-readable summary."""
        tag = {"plan": "📋", "instruction": "⚙", "function": "ƒ"}.get(self.item_type, "?")
        return f"{tag} {self.display_name()}"

    def __repr__(self):
        return f"QueueItem({self.item_type}:{self.name})"


class BatchQueue:
    """A list of QueueItems that can be saved/loaded."""

    def __init__(self, name: str = "Untitled Batch", items: List[QueueItem] = None):
        self.name = name
        self.items: List[QueueItem] = items or []

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "items": [item.to_dict() for item in self.items],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "BatchQueue":
        items = [QueueItem(i) for i in d.get("items", [])]
        return cls(name=d.get("name", "Batch"), items=items)

    def save(self, filepath: str):
        with open(filepath, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, filepath: str) -> "BatchQueue":
        with open(filepath, "r") as f:
            return cls.from_dict(json.load(f))

    def __len__(self):
        return len(self.items)
