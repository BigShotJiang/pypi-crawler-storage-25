"""
Connection manager for Bluesky Queue Server.
Supports both ZMQ and HTTP connections with various auth types.

Threading model
---------------
* All QTimer objects are created on (and owned by) the main GUI thread.
* Timer slots (_poll_status, _poll_console) run on the main thread but
  immediately spawn daemon threads for the actual network I/O.
* _start_polling() / _stop_polling() must NOT be called from worker
  threads.  Instead they are triggered via a dedicated signal so Qt's
  queued-connection mechanism delivers them on the correct thread.
* on_success / on_error callbacks from run_async() also run in worker
  threads.  Callers must only emit signals from those callbacks – never
  touch Qt widgets or call QTimer directly.
"""

import threading
from enum import Enum
from typing import Dict, Any

from PyQt5.QtCore import QObject, pyqtSignal, QTimer, Qt


class ConnectionType(Enum):
    ZMQ = "zmq"
    HTTP = "http"


class AuthType(Enum):
    NONE = "none"
    API_KEY = "api_key"
    TOKEN = "token"
    BASIC = "basic"


class ConnectionState(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


class ConnectionManager(QObject):
    """Manages connection to Bluesky Queue Server via ZMQ or HTTP."""

    # Public signals – all safe to emit from any thread
    connection_state_changed = pyqtSignal(str)   # ConnectionState.value
    status_updated = pyqtSignal(dict)             # RE Manager status dict
    error_occurred = pyqtSignal(str)              # error message
    console_output = pyqtSignal(str)              # console text

    # Internal signal used to trigger timer start/stop on the GUI thread
    _start_poll_signal = pyqtSignal()
    _stop_poll_signal = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rm = None
        self._connection_type = ConnectionType.ZMQ
        self._state = ConnectionState.DISCONNECTED
        self._config: Dict[str, Any] = {}
        self._poll_active = False   # guards against redundant starts

        # Timers – created here so they belong to the main thread
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(2000)
        self._poll_timer.timeout.connect(self._poll_status)

        self._console_timer = QTimer(self)
        self._console_timer.setInterval(500)
        self._console_timer.timeout.connect(self._poll_console)

        # Wire internal signals with Qt.QueuedConnection so they are
        # always delivered on the thread that owns self (main thread)
        self._start_poll_signal.connect(self._start_polling,
                                        Qt.QueuedConnection)
        self._stop_poll_signal.connect(self._stop_polling,
                                       Qt.QueuedConnection)

    # ------------------------------------------------------------------ #
    # Properties
    # ------------------------------------------------------------------ #

    @property
    def rm(self):
        return self._rm

    @property
    def state(self) -> ConnectionState:
        return self._state

    @property
    def is_connected(self) -> bool:
        return self._state == ConnectionState.CONNECTED

    # ------------------------------------------------------------------ #
    # Connect / Disconnect
    # ------------------------------------------------------------------ #

    def connect(self, conn_type: ConnectionType, config: dict):
        """Establish connection to queue server (non-blocking)."""
        self._config = config
        self._connection_type = conn_type
        self._set_state(ConnectionState.CONNECTING)

        def _do_connect():
            try:
                if conn_type == ConnectionType.ZMQ:
                    self._connect_zmq(config)
                else:
                    self._connect_http(config)
                # Verify with a ping
                self._rm.ping()
                self._set_state(ConnectionState.CONNECTED)
                # Schedule timer start on the GUI thread via queued signal
                self._start_poll_signal.emit()
            except Exception as e:
                self._set_state(ConnectionState.ERROR)
                self.error_occurred.emit(f"Connection failed: {e}")

        threading.Thread(target=_do_connect, daemon=True).start()

    def _connect_zmq(self, config: dict):
        from bluesky_queueserver_api.zmq import REManagerAPI
        address = config.get("zmq_address", "tcp://localhost:60615")
        kwargs = {"zmq_control_addr": address}
        console_addr = config.get("zmq_console_address", "").strip()
        if console_addr:
            kwargs["zmq_info_addr"] = console_addr
        self._rm = REManagerAPI(**kwargs)
        if config.get("user"):
            self._rm.user = config["user"]
        if config.get("user_group"):
            self._rm.user_group = config["user_group"]

    def _connect_http(self, config: dict):
        from bluesky_queueserver_api.http import REManagerAPI
        url = config.get("http_url", "http://localhost:60610")
        auth_type = config.get("auth_type", AuthType.NONE)

        # Initialize without auth keys
        self._rm = REManagerAPI(http_server_uri=url)

        if auth_type == AuthType.API_KEY:
            api_key = config.get("api_key", "")
            self._rm.set_authorization_key(api_key=api_key)
        elif auth_type == AuthType.TOKEN:
            # Temporary instance for login
            rm_tmp = REManagerAPI(http_server_uri=url)
            login_resp = rm_tmp.login(
                username=config.get("username", ""),
                password=config.get("password", ""),
            )
            token = login_resp.get("access_token", "")
            self._rm.set_authorization_key(token=token)

        if config.get("user"):
            self._rm.user = config["user"]
        if config.get("user_group"):
            self._rm.user_group = config["user_group"]

    def disconnect(self):
        """Disconnect – safe to call from any thread."""
        # Use queued signal so timer stop happens on GUI thread
        self._stop_poll_signal.emit()
        # Close the RM object in a worker thread (may block briefly)
        rm = self._rm
        self._rm = None
        self._set_state(ConnectionState.DISCONNECTED)
        if rm:
            def _close():
                try:
                    rm.close()
                except Exception:
                    pass
            threading.Thread(target=_close, daemon=True).start()

    # ------------------------------------------------------------------ #
    # Polling – these slots run on the GUI thread
    # ------------------------------------------------------------------ #

    def _start_polling(self):
        """Called on GUI thread via queued signal."""
        if self._poll_active:
            return
        self._poll_active = True
        # Enable ZMQ console monitor (non-blocking – just sets a flag)
        if self._connection_type == ConnectionType.ZMQ and self._rm:
            try:
                self._rm.console_monitor.enable()
            except Exception:
                pass
        self._poll_timer.start()
        self._console_timer.start()

    def _stop_polling(self):
        """Called on GUI thread via queued signal."""
        self._poll_active = False
        self._poll_timer.stop()
        self._console_timer.stop()
        if self._rm:
            try:
                self._rm.console_monitor.disable()
            except Exception:
                pass

    def _poll_status(self):
        """Timer slot – GUI thread.  Dispatches network call to worker."""
        if not self._rm:
            return

        def _fetch():
            try:
                status = self._rm.status()
                self.status_updated.emit(status)
            except Exception as e:
                self.error_occurred.emit(f"Poll error: {e}")
                self._set_state(ConnectionState.ERROR)

        threading.Thread(target=_fetch, daemon=True).start()

    def _poll_console(self):
        """Timer slot – GUI thread.  Reads console buffer and emits text."""
        if not self._rm:
            return
        # cm.text just reads from an in-memory buffer – safe on GUI thread
        try:
            cm = self._rm.console_monitor
            if not cm.enabled:
                return
            text = cm.text
            if text:
                self.console_output.emit(text)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # API wrappers
    # ------------------------------------------------------------------ #

    def run_async(self, func, *args, on_success=None, on_error=None, **kwargs):
        """
        Run an RM API call in a background thread.

        IMPORTANT: on_success and on_error callbacks execute in that
        worker thread.  They must only emit signals – never manipulate
        Qt widgets or call QTimer directly.
        """
        def _run():
            try:
                result = func(*args, **kwargs)
                if on_success:
                    on_success(result)
            except Exception as e:
                msg = f"{type(e).__name__}: {e}"
                self.error_occurred.emit(msg)
                if on_error:
                    on_error(msg)

        threading.Thread(target=_run, daemon=True).start()

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def _set_state(self, state: ConnectionState):
        """Thread-safe: signals use queued connections automatically."""
        self._state = state
        self.connection_state_changed.emit(state.value)