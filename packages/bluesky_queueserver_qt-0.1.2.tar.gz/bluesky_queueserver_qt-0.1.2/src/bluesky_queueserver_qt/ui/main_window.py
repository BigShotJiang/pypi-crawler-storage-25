"""
Main application window for the Bluesky Queue Server Client.
"""

import json
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QSplitter,
    QTabWidget, QAction, QLabel, QMessageBox
)
from PyQt5.QtCore import Qt, pyqtSlot, QSettings, pyqtSignal
from PyQt5.QtGui import QKeySequence

from bluesky_queueserver_qt.core.connection import ConnectionManager
from bluesky_queueserver_qt.core.models import QueueItem
from bluesky_queueserver_qt.ui.connection_dialog import ConnectionDialog
from bluesky_queueserver_qt.ui.plan_edit_dialog import PlanEditDialog
from bluesky_queueserver_qt.widgets.plan_browser import PlanBrowserPanel
from bluesky_queueserver_qt.widgets.queue_panel import QueuePanel
from bluesky_queueserver_qt.widgets.status_panel import StatusPanel
from bluesky_queueserver_qt.widgets.history_panel import HistoryPanel
from bluesky_queueserver_qt.widgets.batch_panel import BatchQueuePanel


class MainWindow(QMainWindow):
    # ------------------------------------------------------------------ #
    # Internal signals – used so worker-thread callbacks can safely
    # trigger GUI updates via Qt's queued-connection mechanism.
    # Never call widget methods directly from a worker thread.
    # ------------------------------------------------------------------ #
    _sig_log = pyqtSignal(str)
    _sig_refresh_queue = pyqtSignal()
    _sig_refresh_history = pyqtSignal()
    _sig_plans_loaded = pyqtSignal(dict)
    _sig_devices_loaded = pyqtSignal(dict)
    _sig_queue_data = pyqtSignal(dict)       # raw queue_get response
    _sig_history_data = pyqtSignal(list)     # raw history items

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Bluesky Queue Server Client")
        self.setMinimumSize(1100, 700)
        self.resize(1400, 850)

        self._conn = ConnectionManager(self)
        self._plans: dict = {}
        self._devices: dict = {}
        self._last_status: dict = {}
        self._history_offset: int = 0
        self._settings = QSettings("Bluesky", "QueueClient")

        self._build_ui()
        self._connect_signals()
        self._load_settings()
        self._update_connection_state("disconnected")

    # ------------------------------------------------------------------ #
    # UI Construction
    # ------------------------------------------------------------------ #

    def _build_ui(self):
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(6, 6, 6, 0)
        main_layout.setSpacing(4)

        # Main splitter: left panel | right tabs
        main_splitter = QSplitter(Qt.Horizontal)

        # ---- Left: Plan Browser ----
        self.plan_browser = PlanBrowserPanel()
        self.plan_browser.setMinimumWidth(220)
        self.plan_browser.setMaximumWidth(380)
        main_splitter.addWidget(self.plan_browser)

        # ---- Right: tabbed content ----
        right_tabs = QTabWidget()

        # Queue tab
        self.queue_panel = QueuePanel()
        right_tabs.addTab(self.queue_panel, "📋 Queue")

        # Batch tab
        self.batch_panel = BatchQueuePanel()
        right_tabs.addTab(self.batch_panel, "📦 Batch Builder")

        # History tab
        self.history_panel = HistoryPanel()
        right_tabs.addTab(self.history_panel, "🕑 History")

        main_splitter.addWidget(right_tabs)
        main_splitter.setStretchFactor(0, 0)
        main_splitter.setStretchFactor(1, 1)
        main_splitter.setSizes([260, 900])

        main_layout.addWidget(main_splitter, 1)

        # ---- Bottom: Status Panel ----
        self.status_panel = StatusPanel()
        main_layout.addWidget(self.status_panel)

        # ---- Toolbar ----
        self._build_toolbar()

        # ---- Menu ----
        self._build_menu()

    def _build_toolbar(self):
        tb = self.addToolBar("Main")
        tb.setMovable(False)
        tb.setObjectName("main_toolbar")

        self.act_connect = QAction("🔌 Connect", self)
        self.act_connect.setToolTip("Connect to Queue Server")
        self.act_connect.triggered.connect(self._on_connect)

        self.act_disconnect = QAction("⏏ Disconnect", self)
        self.act_disconnect.setEnabled(False)
        self.act_disconnect.triggered.connect(self._on_disconnect)

        self.act_refresh = QAction("🔄 Refresh", self)
        self.act_refresh.setToolTip("Refresh queue, plans, devices")
        self.act_refresh.setEnabled(False)
        self.act_refresh.triggered.connect(self._on_refresh_all)

        self.conn_status_label = QLabel("  Not connected  ")
        self.conn_status_label.setStyleSheet("color: #f38ba8;")

        tb.addAction(self.act_connect)
        tb.addAction(self.act_disconnect)
        tb.addSeparator()
        tb.addAction(self.act_refresh)
        tb.addSeparator()
        tb.addWidget(self.conn_status_label)

    def _build_menu(self):
        mb = self.menuBar()

        # File
        file_menu = mb.addMenu("File")
        file_menu.addAction("Connect...", self._on_connect, QKeySequence("Ctrl+K"))
        file_menu.addAction("Disconnect", self._on_disconnect)
        file_menu.addSeparator()
        file_menu.addAction("Save Batch...", self.batch_panel._save_batch)
        file_menu.addAction("Load Batch...", self.batch_panel._load_batch)
        file_menu.addSeparator()
        file_menu.addAction("Quit", self.close, QKeySequence.Quit)

        # Queue
        queue_menu = mb.addMenu("Queue")
        queue_menu.addAction("Start Queue", self.queue_panel.start_requested)
        queue_menu.addAction("Stop Queue", self.queue_panel.stop_requested)
        queue_menu.addAction("Pause RE", self.queue_panel.pause_requested)
        queue_menu.addAction("Resume RE", self.queue_panel.resume_requested)
        queue_menu.addAction("Abort RE", self.queue_panel.abort_requested)
        queue_menu.addSeparator()
        queue_menu.addAction("Clear Queue", self.queue_panel.clear_requested)
        queue_menu.addAction("Clear History", self._on_clear_history)

        # Environment
        env_menu = mb.addMenu("Environment")
        env_menu.addAction("Open Environment", self._on_open_env)
        env_menu.addAction("Close Environment", self._on_close_env)
        env_menu.addAction("Destroy Environment", self._on_destroy_env)
        env_menu.addSeparator()
        env_menu.addAction("Reload Plans/Devices", self._on_refresh_plans)

        # Help
        help_menu = mb.addMenu("Help")
        help_menu.addAction("About", self._on_about)

    # ------------------------------------------------------------------ #
    # Signal Connections
    # ------------------------------------------------------------------ #

    def _connect_signals(self):
        cm = self._conn

        # Connection state
        cm.connection_state_changed.connect(self._update_connection_state)
        cm.status_updated.connect(self._on_status_updated)
        cm.error_occurred.connect(self._on_error)
        cm.console_output.connect(self.status_panel.append_console)

        # Internal worker→GUI signals (all queued automatically)
        self._sig_log.connect(self.status_panel.append_log)
        self._sig_refresh_queue.connect(self._refresh_queue)
        self._sig_refresh_history.connect(self._refresh_history)
        self._sig_plans_loaded.connect(self._apply_plans)
        self._sig_devices_loaded.connect(self._apply_devices)
        self._sig_queue_data.connect(self._apply_queue_data)
        self._sig_history_data.connect(self.history_panel.set_history)

        # Plan browser
        self.plan_browser.add_plan_requested.connect(self._on_add_plan_from_browser)
        self.plan_browser.refresh_btn.clicked.connect(self._on_refresh_plans)

        # Queue panel controls
        self.queue_panel.start_requested.connect(self._on_queue_start)
        self.queue_panel.stop_requested.connect(self._on_queue_stop)
        self.queue_panel.pause_requested.connect(self._on_re_pause)
        self.queue_panel.resume_requested.connect(self._on_re_resume)
        self.queue_panel.abort_requested.connect(self._on_re_abort)
        self.queue_panel.halt_requested.connect(self._on_re_halt)
        self.queue_panel.clear_requested.connect(self._on_queue_clear)
        self.queue_panel.remove_items_requested.connect(self._on_remove_items)
        self.queue_panel.edit_item_requested.connect(self._on_edit_item)
        self.queue_panel.add_plan_requested.connect(self._on_add_plan_from_browser)
        self.queue_panel.execute_item_requested.connect(self._on_execute_item)

        # Status panel env buttons
        self.status_panel.btn_open_env.clicked.connect(self._on_open_env)
        self.status_panel.btn_close_env.clicked.connect(self._on_close_env)

        # History
        self.history_panel.clear_btn.clicked.connect(self._on_clear_history)
        self.history_panel.rerun_requested.connect(self._on_rerun_item)

        # Batch panel
        self.batch_panel.submit_batch_requested.connect(self._on_submit_batch)

    # ------------------------------------------------------------------ #
    # Connection
    # ------------------------------------------------------------------ #

    def _on_connect(self):
        dlg = ConnectionDialog(self, self._last_conn_config())
        if dlg.exec_():
            config = dlg.get_config()
            self._save_conn_config(config)
            conn_type = config["conn_type"]
            self._conn.connect(conn_type, config)

    def _on_disconnect(self):
        self._conn.disconnect()

    def _last_conn_config(self):
        raw = self._settings.value("conn_config")
        if raw:
            try:
                return json.loads(raw)
            except Exception:
                pass
        return None

    def _save_conn_config(self, config: dict):
        # Don't save passwords
        safe = {k: v for k, v in config.items()
                if k not in ("password", "basic_password", "api_key")}
        self._settings.setValue("conn_config", json.dumps({
            k: v.value if hasattr(v, 'value') else v
            for k, v in safe.items()
        }))

    @pyqtSlot(str)
    def _update_connection_state(self, state_str: str):
        connected = state_str == "connected"
        connecting = state_str == "connecting"

        self.act_connect.setEnabled(not connected and not connecting)
        self.act_disconnect.setEnabled(connected)
        self.act_refresh.setEnabled(connected)

        if connected:
            self.conn_status_label.setText("  ● Connected  ")
            self.conn_status_label.setStyleSheet("color: #a6e3a1;")
            self.status_panel.set_connected(True, "Connected")
            self._on_refresh_all()
        elif connecting:
            self.conn_status_label.setText("  ⟳ Connecting…  ")
            self.conn_status_label.setStyleSheet("color: #f9e2af;")
        else:
            self.conn_status_label.setText("  ○ Disconnected  ")
            self.conn_status_label.setStyleSheet("color: #f38ba8;")
            self.status_panel.set_connected(False)

    # ------------------------------------------------------------------ #
    # Status Updates
    # ------------------------------------------------------------------ #

    @pyqtSlot(dict)
    def _on_status_updated(self, status: dict):
        # This slot runs on the GUI thread (queued connection from poll signal).
        self._last_status = status
        self.status_panel.update_status(status)
        mgr_state = status.get("manager_state", "")
        re_state = status.get("re_state", "")
        self.queue_panel.set_controls_state(mgr_state, re_state)
        # Trigger queue and history refresh – runs on GUI thread, spawns worker inside
        self._refresh_queue()
        self._refresh_history()

    def _refresh_queue(self):
        """GUI-thread method – safe to call directly."""
        if not self._conn.is_connected:
            return
        def _cb(resp):
            # Worker thread: only emit a signal
            self._sig_queue_data.emit(resp)
        self._conn.run_async(self._conn.rm.queue_get, on_success=_cb)

    @pyqtSlot(dict)
    def _apply_queue_data(self, resp: dict):
        """GUI-thread slot receiving queue_get response."""
        items_data = resp.get("items", [])
        items = [QueueItem(d) for d in items_data]
        running_uid = self._last_status.get("running_item_uid")
        self.queue_panel.set_queue(items, running_uid)

        items_in_history = self._last_status.get("items_in_history", 0)
        if not items and not running_uid:
            # Queue is empty and nothing is running: reset the progress baseline
            self._history_offset = items_in_history

        completed = max(0, items_in_history - self._history_offset)
        total = len(items) + completed
        if running_uid:
            total += 1

        self.queue_panel.update_progress(completed, total)

    @pyqtSlot(dict)
    def _apply_plans(self, plans: dict):
        """GUI-thread slot."""
        self._plans = plans
        self.plan_browser.set_plans(plans)
        self.batch_panel.set_plans(plans)

    @pyqtSlot(dict)
    def _apply_devices(self, devices: dict):
        """GUI-thread slot."""
        self._devices = devices
        self.plan_browser.set_devices(devices)
        self.batch_panel.set_devices(devices)

    # ------------------------------------------------------------------ #
    # Queue Operations
    # ------------------------------------------------------------------ #

    def _on_queue_start(self):
        def _cb(r): self._sig_log.emit("Queue started.")
        self._conn.run_async(self._conn.rm.queue_start, on_success=_cb)

    def _on_queue_stop(self):
        def _cb(r): self._sig_log.emit("Queue stop requested.")
        self._conn.run_async(self._conn.rm.queue_stop, on_success=_cb)

    def _on_re_pause(self):
        def _cb(r): self._sig_log.emit("RE pause requested.")
        self._conn.run_async(self._conn.rm.re_pause, on_success=_cb)

    def _on_re_resume(self):
        def _cb(r): self._sig_log.emit("RE resume requested.")
        self._conn.run_async(self._conn.rm.re_resume, on_success=_cb)

    def _on_re_abort(self):
        reply = QMessageBox.question(self, "Abort", "Abort current plan?",
                                      QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            def _cb(r): self._sig_log.emit("RE abort requested.")
            self._conn.run_async(self._conn.rm.re_abort, on_success=_cb)

    def _on_re_halt(self):
        reply = QMessageBox.question(self, "Halt", "Halt current plan immediately?",
                                      QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            def _cb(r): self._sig_log.emit("RE halt requested.")
            self._conn.run_async(self._conn.rm.re_halt, on_success=_cb)

    def _on_queue_clear(self):
        reply = QMessageBox.question(self, "Clear Queue",
                                      "Remove all items from the queue?",
                                      QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            def _cb(r):
                self._sig_log.emit("Queue cleared.")
                self._sig_refresh_queue.emit()
            self._conn.run_async(self._conn.rm.queue_clear, on_success=_cb)

    def _on_remove_items(self, uids: list):
        if not uids:
            return
        def _cb(r):
            self._sig_log.emit(f"Removed {len(uids)} item(s).")
            self._sig_refresh_queue.emit()
        self._conn.run_async(self._conn.rm.item_remove_batch,
                             uids=uids, on_success=_cb)

    def _on_execute_item(self, uid: str):
        def _cb(r):
            self._sig_log.emit(f"Executing item: {uid[:8]}...")
            self._sig_refresh_queue.emit()
        self._conn.run_async(self._conn.rm.item_execute,
                             item={"item_uid": uid}, on_success=_cb)

    def _on_edit_item(self, item: QueueItem):
        name = item.name
        plan_info = {"name": name, "info": self._plans.get(name, {}),
                     "parameters": self._plans.get(name, {}).get("parameters", [])}
        dlg = PlanEditDialog(plan_info, existing_item=item,
                             devices=self._devices, parent=self)
        if dlg.exec_():
            new_items = dlg.get_items()
            if new_items:
                new_item = new_items[0]
                d = new_item.to_dict()
                if item.item_uid:
                    d["item_uid"] = item.item_uid
                def _cb(r):
                    self._sig_log.emit(f"Item updated: {name}")
                    self._sig_refresh_queue.emit()
                self._conn.run_async(self._conn.rm.item_update,
                                     item=d, on_success=_cb)

    def _on_rerun_item(self, item_dict: dict):
        clean = {k: v for k, v in item_dict.items() if k != "item_uid"}
        def _cb(r):
            self._sig_log.emit(f"Re-added: {item_dict.get('name', '?')}")
            self._sig_refresh_queue.emit()
        self._conn.run_async(self._conn.rm.item_add,
                             item=clean, on_success=_cb)

    # ------------------------------------------------------------------ #
    # Plan/Device Browser
    # ------------------------------------------------------------------ #

    def _on_add_plan_from_browser(self, plan_info: dict):
        if not self._conn.is_connected:
            QMessageBox.warning(self, "Not Connected",
                                "Please connect to a queue server first.")
            return
        name = plan_info.get("name", "")
        full_info = {"name": name, "info": self._plans.get(name, plan_info.get("info", {})),
                     "parameters": self._plans.get(name, {}).get("parameters", [])}
        dlg = PlanEditDialog(full_info, devices=self._devices, parent=self)
        if dlg.exec_():
            items = dlg.get_items()
            if not items:
                return
            if len(items) == 1:
                def _cb(r):
                    self._sig_log.emit(f"Added: {name}")
                    self._sig_refresh_queue.emit()
                self._conn.run_async(
                    self._conn.rm.item_add,
                    item=items[0].to_bitem(),
                    on_success=_cb
                )
            else:
                def _cb(r):
                    self._sig_log.emit(f"Added {len(items)} items: {name}")
                    self._sig_refresh_queue.emit()
                self._conn.run_async(
                    self._conn.rm.item_add_batch,
                    items=[i.to_bitem() for i in items],
                    on_success=_cb
                )

    def _on_submit_batch(self, items: list):
        if not self._conn.is_connected:
            QMessageBox.warning(self, "Not Connected", "Please connect to a server first.")
            return
        def _cb(r):
            self._sig_log.emit(f"Submitted batch: {len(items)} item(s) added.")
            self._sig_refresh_queue.emit()
        self._conn.run_async(
            self._conn.rm.item_add_batch,
            items=[i.to_bitem() for i in items],
            on_success=_cb
        )

    # ------------------------------------------------------------------ #
    # Refresh
    # ------------------------------------------------------------------ #

    def _on_refresh_all(self):
        self._on_refresh_plans()
        self._refresh_queue()
        self._refresh_history()

    def _on_refresh_plans(self):
        if not self._conn.is_connected:
            return
        def _cb_plans(resp):
            plans = resp.get("plans_allowed", {})
            self._sig_log.emit(f"Loaded {len(plans)} plans.")
            self._sig_plans_loaded.emit(plans)
        def _cb_devices(resp):
            devices = resp.get("devices_allowed", {})
            self._sig_devices_loaded.emit(devices)
        self._conn.run_async(self._conn.rm.plans_allowed, on_success=_cb_plans)
        self._conn.run_async(self._conn.rm.devices_allowed, on_success=_cb_devices)

    def _refresh_history(self):
        """GUI-thread method."""
        if not self._conn.is_connected:
            return
        def _cb(resp):
            items = resp.get("items", [])
            self._sig_history_data.emit(items)
        self._conn.run_async(self._conn.rm.history_get, on_success=_cb)

    # ------------------------------------------------------------------ #
    # Environment
    # ------------------------------------------------------------------ #

    def _on_open_env(self):
        def _cb(r): self._sig_log.emit("Opening environment…")
        self._conn.run_async(self._conn.rm.environment_open, on_success=_cb)

    def _on_close_env(self):
        def _cb(r): self._sig_log.emit("Closing environment…")
        self._conn.run_async(self._conn.rm.environment_close, on_success=_cb)

    def _on_destroy_env(self):
        reply = QMessageBox.question(self, "Destroy Environment",
                                      "Force-destroy the RE environment?",
                                      QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            def _cb(r): self._sig_log.emit("Destroying environment…")
            self._conn.run_async(self._conn.rm.environment_destroy, on_success=_cb)

    def _on_clear_history(self):
        def _cb(r):
            self._sig_log.emit("History cleared.")
            self._sig_refresh_history.emit()
        self._conn.run_async(self._conn.rm.history_clear, on_success=_cb)

    # ------------------------------------------------------------------ #
    # Error handling
    # ------------------------------------------------------------------ #

    @pyqtSlot(str)
    def _on_error(self, msg: str):
        self.status_panel.append_log(f"ERROR: {msg}")

    # ------------------------------------------------------------------ #
    # Settings persistence
    # ------------------------------------------------------------------ #

    def _load_settings(self):
        geom = self._settings.value("geometry")
        if geom:
            self.restoreGeometry(geom)
        state = self._settings.value("windowState")
        if state:
            self.restoreState(state)

    def closeEvent(self, event):
        self._settings.setValue("geometry", self.saveGeometry())
        self._settings.setValue("windowState", self.saveState())
        self._conn.disconnect()
        event.accept()

    # ------------------------------------------------------------------ #
    # About
    # ------------------------------------------------------------------ #

    def _on_about(self):
        QMessageBox.about(
            self, "About Bluesky Queue Client",
            "<b>Bluesky Queue Server Client</b><br><br>"
            "A PyQt5 application for managing the Bluesky Queue Server.<br><br>"
            "Supports ZMQ and HTTP connections, drag-and-drop queue building,<br>"
            "batch queue creation, and RE control.<br><br>"
            "Uses <code>bluesky-queueserver-api</code>."
        )