"""
Dialog for creating / editing a queue item (plan, instruction, or function).
Dynamically builds form fields based on plan parameter schema.
"""

import json
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel,
    QLineEdit, QSpinBox, QDoubleSpinBox, QDialogButtonBox, QScrollArea, QWidget, QGroupBox,
    QCheckBox, QTabWidget, QPlainTextEdit
)
from PyQt5.QtCore import Qt

from bluesky_queueserver_qt.core.models import QueueItem


class PlanEditDialog(QDialog):
    """Dialog for adding/editing a plan in the queue."""

    def __init__(self, plan_info: dict, existing_item: QueueItem = None,
                 devices: dict = None, parent=None):
        super().__init__(parent)
        self._plan_info = plan_info
        self._existing = existing_item
        self._devices = devices or {}
        self._param_widgets = {}  # param_name -> widget

        name = plan_info.get("name", "plan")
        self.setWindowTitle(f"{'Edit' if existing_item else 'Add'}: {name}")
        self.setMinimumWidth(520)
        self.setMinimumHeight(400)
        self._build_ui()
        if existing_item:
            self._populate(existing_item)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # Description
        desc = (self._plan_info.get("info", {}).get("description") or
                self._plan_info.get("description") or "").strip()
        if desc:
            desc_label = QLabel(desc[:400])
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #a6adc8; font-style: italic;")
            layout.addWidget(desc_label)

        tabs = QTabWidget()

        # --- Parameters tab ---
        params_tab = QWidget()
        params_layout = QVBoxLayout(params_tab)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        inner = QWidget()
        self.form = QFormLayout(inner)
        self.form.setLabelAlignment(Qt.AlignRight)
        self.form.setSpacing(8)

        params = (self._plan_info.get("info", {}).get("parameters") or
                  self._plan_info.get("parameters") or [])
        if params:
            self._build_param_widgets(params)
        else:
            self.form.addRow(QLabel("No parameters defined."))

        scroll.setWidget(inner)
        params_layout.addWidget(scroll)
        tabs.addTab(params_tab, "Parameters")

        # --- Raw JSON tab ---
        raw_tab = QWidget()
        raw_layout = QVBoxLayout(raw_tab)
        raw_layout.addWidget(QLabel("Edit kwargs as JSON (overrides form above):"))
        self.raw_kwargs = QPlainTextEdit()
        self.raw_kwargs.setPlaceholderText('{"num": 10, "delay": 1.0}')
        self.raw_kwargs.setMaximumHeight(200)
        raw_layout.addWidget(self.raw_kwargs)

        raw_layout.addWidget(QLabel("Args (JSON array):"))
        self.raw_args = QPlainTextEdit()
        self.raw_args.setPlaceholderText('["det1", "det2"]')
        self.raw_args.setMaximumHeight(80)
        raw_layout.addWidget(self.raw_args)

        raw_layout.addWidget(QLabel("Metadata (JSON dict):"))
        self.raw_meta = QPlainTextEdit()
        self.raw_meta.setPlaceholderText('{"sample": "test"}')
        self.raw_meta.setMaximumHeight(80)
        raw_layout.addWidget(self.raw_meta)
        raw_layout.addStretch()
        tabs.addTab(raw_tab, "Raw JSON")

        layout.addWidget(tabs)

        # Batch repeat option
        batch_group = QGroupBox("Batch / Repeat")
        bl = QHBoxLayout(batch_group)
        bl.addWidget(QLabel("Repeat:"))
        self.repeat_spin = QSpinBox()
        self.repeat_spin.setRange(1, 10000)
        self.repeat_spin.setValue(1)
        bl.addWidget(self.repeat_spin)
        bl.addWidget(QLabel("times"))
        bl.addStretch()
        layout.addWidget(batch_group)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _build_param_widgets(self, params: list):
        device_names = sorted(self._devices.keys())

        for p in params:
            pname = p.get("name", "?")
            default = p.get("default")
            required = (default == "REQUIRED" or default is None)
            ann = p.get("annotation", {})
            ann_type = ann.get("type", "") if isinstance(ann, dict) else str(ann)
            desc = p.get("description", "")

            # Choose widget
            widget = self._make_widget(pname, ann_type, default, device_names)
            widget.setToolTip(desc or ann_type)

            label_text = pname
            if required:
                label_text += " *"
            label = QLabel(label_text)
            if required:
                label.setStyleSheet("color: #f38ba8;")
            self.form.addRow(label, widget)
            self._param_widgets[pname] = widget

    def _make_widget(self, name, ann_type, default, device_names):
        ann_lower = ann_type.lower()

        # Bool
        if "bool" in ann_lower:
            w = QCheckBox()
            if default not in (None, "REQUIRED"):
                w.setChecked(bool(default))
            return w

        # Int
        if "int" in ann_lower:
            w = QSpinBox()
            w.setRange(-1000000, 1000000)
            if default not in (None, "REQUIRED"):
                try:
                    w.setValue(int(default))
                except Exception:
                    pass
            return w

        # Float
        if "float" in ann_lower:
            w = QDoubleSpinBox()
            w.setRange(-1e9, 1e9)
            w.setDecimals(6)
            if default not in (None, "REQUIRED"):
                try:
                    w.setValue(float(default))
                except Exception:
                    pass
            return w

        # List of devices / detectors
        if device_names and ("detector" in ann_lower or "readable" in ann_lower or
                             "device" in name.lower() or "det" in name.lower()):
            w = QLineEdit()
            w.setPlaceholderText("e.g. det1, det2")
            if default not in (None, "REQUIRED"):
                w.setText(str(default))
            return w

        # Default: text field
        w = QLineEdit()
        if default not in (None, "REQUIRED"):
            w.setText(str(default))
        else:
            w.setPlaceholderText("required" if default == "REQUIRED" else "")
        return w

    def _populate(self, item: QueueItem):
        """Fill widgets from an existing item."""
        for pname, widget in self._param_widgets.items():
            val = item.kwargs.get(pname)
            if val is None:
                continue
            if isinstance(widget, QCheckBox):
                widget.setChecked(bool(val))
            elif isinstance(widget, (QSpinBox, QDoubleSpinBox)):
                try:
                    widget.setValue(float(val))
                except Exception:
                    pass
            else:
                widget.setText(str(val) if not isinstance(val, str) else val)

        if item.args:
            self.raw_args.setPlainText(json.dumps(item.args))
        if item.meta:
            self.raw_meta.setPlainText(json.dumps(item.meta, indent=2))

    def _get_kwargs_from_form(self) -> dict:
        result = {}
        for pname, widget in self._param_widgets.items():
            if isinstance(widget, QCheckBox):
                result[pname] = widget.isChecked()
            elif isinstance(widget, QSpinBox):
                result[pname] = widget.value()
            elif isinstance(widget, QDoubleSpinBox):
                result[pname] = widget.value()
            elif isinstance(widget, QLineEdit):
                txt = widget.text().strip()
                if txt:
                    result[pname] = txt
        return result

    def get_items(self) -> list:
        """Return list of QueueItems (handles repeat)."""
        plan_name = (self._plan_info.get("name") or
                     self._plan_info.get("info", {}).get("name", "unknown"))

        # Try raw JSON first
        raw_kw_txt = self.raw_kwargs.toPlainText().strip()
        raw_args_txt = self.raw_args.toPlainText().strip()
        raw_meta_txt = self.raw_meta.toPlainText().strip()

        if raw_kw_txt:
            try:
                kwargs = json.loads(raw_kw_txt)
            except json.JSONDecodeError:
                kwargs = self._get_kwargs_from_form()
        else:
            kwargs = self._get_kwargs_from_form()

        args = []
        if raw_args_txt:
            try:
                args = json.loads(raw_args_txt)
            except json.JSONDecodeError:
                pass

        meta = {}
        if raw_meta_txt:
            try:
                meta = json.loads(raw_meta_txt)
            except json.JSONDecodeError:
                pass

        item = QueueItem.new_plan(plan_name, args=args, kwargs=kwargs, meta=meta)
        count = self.repeat_spin.value()
        return [item] * count if count == 1 else [
            QueueItem.new_plan(plan_name, args=args[:], kwargs=dict(kwargs), meta=dict(meta))
            for _ in range(count)
        ]
