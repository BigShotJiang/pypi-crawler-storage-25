"""
Connection dialog for configuring ZMQ or HTTP server connections.
"""

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel,
    QLineEdit, QComboBox, QPushButton, QWidget,
    QGroupBox, QDialogButtonBox, QStackedWidget
)

from bluesky_queueserver_qt.core.connection import ConnectionType, AuthType


class ConnectionDialog(QDialog):
    """Dialog for configuring server connection."""

    def __init__(self, parent=None, current_config=None):
        super().__init__(parent)
        self.setWindowTitle("Connect to Queue Server")
        self.setMinimumWidth(460)
        self._build_ui()
        if current_config:
            self._load_config(current_config)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(12)

        # --- Transport type ---
        transport_group = QGroupBox("Transport")
        tl = QHBoxLayout(transport_group)
        self.rb_zmq = QPushButton("ZMQ (Direct)")
        self.rb_zmq.setCheckable(True)
        self.rb_zmq.setChecked(True)
        self.rb_http = QPushButton("HTTP Server")
        self.rb_http.setCheckable(True)
        self.rb_zmq.clicked.connect(lambda: self._switch_transport(0))
        self.rb_http.clicked.connect(lambda: self._switch_transport(1))
        tl.addWidget(self.rb_zmq)
        tl.addWidget(self.rb_http)
        layout.addWidget(transport_group)

        # --- Stacked pages ---
        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_zmq_page())
        self.stack.addWidget(self._build_http_page())
        layout.addWidget(self.stack)

        # --- User info ---
        user_group = QGroupBox("User Identity")
        fl = QFormLayout(user_group)
        self.user_edit = QLineEdit()
        self.user_edit.setPlaceholderText("Default (system login)")
        self.user_group_edit = QLineEdit()
        self.user_group_edit.setPlaceholderText("Default user group")
        fl.addRow("Username:", self.user_edit)
        fl.addRow("User Group:", self.user_group_edit)
        layout.addWidget(user_group)

        # --- Buttons ---
        btns = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _build_zmq_page(self):
        page = QWidget()
        fl = QFormLayout(page)
        fl.setContentsMargins(0, 8, 0, 0)
        self.zmq_address = QLineEdit("tcp://localhost:60615")
        self.zmq_console_address = QLineEdit()
        self.zmq_console_address.setPlaceholderText("tcp://localhost:60625 (optional)")
        fl.addRow("Control Address:", self.zmq_address)
        fl.addRow("Console Address:", self.zmq_console_address)
        return page

    def _build_http_page(self):
        page = QWidget()
        vl = QVBoxLayout(page)
        vl.setContentsMargins(0, 8, 0, 0)
        vl.setSpacing(8)

        fl = QFormLayout()
        self.http_url = QLineEdit("http://localhost:60610")
        fl.addRow("Server URL:", self.http_url)
        vl.addLayout(fl)

        auth_group = QGroupBox("Authentication")
        al = QVBoxLayout(auth_group)

        self.auth_combo = QComboBox()
        self.auth_combo.addItems([
            "None", "API Key", "Username/Password (Token)", "Basic Auth"
        ])
        self.auth_combo.currentIndexChanged.connect(self._on_auth_changed)
        al.addWidget(self.auth_combo)

        self.auth_stack = QStackedWidget()

        # None
        self.auth_stack.addWidget(QLabel("No authentication required."))

        # API Key
        api_key_page = QWidget()
        akl = QFormLayout(api_key_page)
        self.api_key_edit = QLineEdit()
        self.api_key_edit.setEchoMode(QLineEdit.Password)
        self.api_key_edit.setPlaceholderText("Enter API key")
        akl.addRow("API Key:", self.api_key_edit)
        self.auth_stack.addWidget(api_key_page)

        # Token (username+password)
        token_page = QWidget()
        tpl = QFormLayout(token_page)
        self.http_username = QLineEdit()
        self.http_password = QLineEdit()
        self.http_password.setEchoMode(QLineEdit.Password)
        tpl.addRow("Username:", self.http_username)
        tpl.addRow("Password:", self.http_password)
        self.auth_stack.addWidget(token_page)

        # Basic auth
        basic_page = QWidget()
        bpl = QFormLayout(basic_page)
        self.basic_username = QLineEdit()
        self.basic_password = QLineEdit()
        self.basic_password.setEchoMode(QLineEdit.Password)
        bpl.addRow("Username:", self.basic_username)
        bpl.addRow("Password:", self.basic_password)
        self.auth_stack.addWidget(basic_page)

        al.addWidget(self.auth_stack)
        vl.addWidget(auth_group)

        return page

    def _switch_transport(self, idx):
        self.stack.setCurrentIndex(idx)
        self.rb_zmq.setChecked(idx == 0)
        self.rb_http.setChecked(idx == 1)

    def _on_auth_changed(self, idx):
        self.auth_stack.setCurrentIndex(idx)

    def _load_config(self, config: dict):
        conn_type = config.get("conn_type", ConnectionType.ZMQ)
        if conn_type == ConnectionType.HTTP:
            self._switch_transport(1)
        self.zmq_address.setText(config.get("zmq_address", "tcp://localhost:60615"))
        self.zmq_console_address.setText(config.get("zmq_console_address", ""))
        self.http_url.setText(config.get("http_url", "http://localhost:60610"))
        self.user_edit.setText(config.get("user", ""))
        self.user_group_edit.setText(config.get("user_group", ""))

    def get_config(self) -> dict:
        is_http = self.stack.currentIndex() == 1
        cfg = {
            "conn_type": ConnectionType.HTTP if is_http else ConnectionType.ZMQ,
            "zmq_address": self.zmq_address.text().strip(),
            "zmq_console_address": self.zmq_console_address.text().strip(),
            "http_url": self.http_url.text().strip(),
            "user": self.user_edit.text().strip() or None,
            "user_group": self.user_group_edit.text().strip() or None,
        }
        if is_http:
            auth_idx = self.auth_combo.currentIndex()
            auth_types = [AuthType.NONE, AuthType.API_KEY, AuthType.TOKEN, AuthType.BASIC]
            cfg["auth_type"] = auth_types[auth_idx]
            cfg["api_key"] = self.api_key_edit.text().strip()
            cfg["username"] = self.http_username.text().strip()
            cfg["password"] = self.http_password.text()
            cfg["basic_username"] = self.basic_username.text().strip()
            cfg["basic_password"] = self.basic_password.text()
        return cfg
