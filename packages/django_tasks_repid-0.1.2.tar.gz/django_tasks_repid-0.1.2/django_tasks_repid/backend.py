from __future__ import annotations

import json
from datetime import datetime
from typing import TypeVar

from asgiref.sync import async_to_sync
from django.utils import timezone as django_timezone
from django.utils.module_loading import import_string
from typing_extensions import ParamSpec

from django_tasks.backends.base import BaseTaskBackend
from django_tasks.base import Task, TaskError, TaskResult, TaskResultStatus
from django_tasks.exceptions import TaskResultDoesNotExist
from django_tasks.utils import get_random_id, normalize_json

from repid import Connection, Job, Queue, Repid
from repid.data import ResultBucketT

T = TypeVar("T")
P = ParamSpec("P")


def _job_name(module_path: str) -> str:
    """Convert a Python module path to a valid repid job name (dots → double underscores)."""
    return module_path.replace(".", "__")


class RepidBackend(BaseTaskBackend):
    supports_async_task = True
    supports_defer = True

    def __init__(self, alias: str, params: dict) -> None:
        super().__init__(alias, params)
        self._repid: Repid = self._build_repid()

    @property
    def supports_get_result(self) -> bool:  # type: ignore[override]
        return bool(self.options.get("RESULT_BACKEND"))

    def _build_repid(self) -> Repid:
        broker_dsn: str = self.options.get("BROKER", "")
        result_dsn: str = self.options.get("RESULT_BACKEND", "")

        if broker_dsn.startswith("amqp"):
            from repid.connections import RabbitMessageBroker

            message_broker = RabbitMessageBroker(broker_dsn)
        elif broker_dsn.startswith("redis") or broker_dsn.startswith("valkey"):
            from repid.connections import RedisMessageBroker

            # The redis client only understands redis:// — valkey is protocol-compatible.
            message_broker = RedisMessageBroker(
                broker_dsn.replace("valkey://", "redis://", 1)
            )
        else:
            from repid.connections import InMemoryMessageBroker

            message_broker = InMemoryMessageBroker()

        if result_dsn:
            from repid.connections import RedisBucketBroker

            args_broker = RedisBucketBroker(result_dsn)
            results_broker = RedisBucketBroker(result_dsn, use_result_bucket=True)
        else:
            args_broker = None
            results_broker = None

        return Repid(
            Connection(
                message_broker=message_broker,
                args_bucket_broker=args_broker,
                results_bucket_broker=results_broker,
            )
        )

    async def _aenqueue(
        self,
        task: Task[P, T],
        args: tuple,
        kwargs: dict,
    ) -> TaskResult[T]:
        self.validate_task(task)

        async with self._repid.magic():
            await Queue(task.queue_name).declare()
            enqueued_at = django_timezone.now()
            result_id = get_random_id()

            task_args = normalize_json(list(args))
            task_kwargs = normalize_json(dict(kwargs))

            payload = {
                "module_path": task.module_path,
                "args": task_args,
                "kwargs": task_kwargs,
                "enqueued_at": enqueued_at.isoformat(),
            }

            job = Job(
                name=_job_name(task.module_path),
                queue=task.queue_name,
                args=payload,
                args_id=result_id,
                result_id=result_id,
                deferred_until=task.run_after,
            )

            await job.enqueue()

        return TaskResult(
            task=task,
            id=result_id,
            status=TaskResultStatus.READY,
            enqueued_at=enqueued_at,
            started_at=None,
            last_attempted_at=None,
            finished_at=None,
            args=task_args,
            kwargs=task_kwargs,
            backend=self.alias,
            errors=[],
            worker_ids=[],
        )

    def enqueue(
        self,
        task: Task[P, T],
        args: P.args,  # type: ignore[valid-type]
        kwargs: P.kwargs,  # type: ignore[valid-type]
    ) -> TaskResult[T]:
        return async_to_sync(self._aenqueue)(task, args, kwargs)

    async def aenqueue(
        self,
        task: Task[P, T],
        args: P.args,  # type: ignore[valid-type]
        kwargs: P.kwargs,  # type: ignore[valid-type]
    ) -> TaskResult[T]:
        return await self._aenqueue(task, args, kwargs)

    async def _aget_result(self, result_id: str) -> TaskResult:
        async with self._repid.magic() as conn:
            args_broker = conn.args_bucket_broker
            results_broker = conn.results_bucket_broker
            assert args_broker is not None and results_broker is not None

            args_bucket = await args_broker.get_bucket(result_id)
            if args_bucket is None:
                raise TaskResultDoesNotExist(result_id)

            payload = json.loads(args_bucket.data)
            module_path: str = payload["module_path"]
            task_args: list = payload["args"]
            task_kwargs: dict = payload["kwargs"]
            enqueued_at: datetime = datetime.fromisoformat(payload["enqueued_at"])

            task_obj: Task = import_string(module_path)

            raw_result = await results_broker.get_bucket(result_id)
            result_bucket: ResultBucketT | None = raw_result  # type: ignore[assignment]

        if result_bucket is None:
            status = TaskResultStatus.READY
            errors: list[TaskError] = []
        elif result_bucket.success:
            status = TaskResultStatus.SUCCESSFUL
            errors = []
        else:
            status = TaskResultStatus.FAILED
            errors = (
                [
                    TaskError(
                        exception_class_path="builtins.Exception",
                        traceback=result_bucket.exception,
                    )
                ]
                if result_bucket.exception
                else []
            )

        task_result: TaskResult = TaskResult(
            task=task_obj,
            id=result_id,
            status=status,
            enqueued_at=enqueued_at,
            started_at=None,
            last_attempted_at=None,
            finished_at=None,
            args=task_args,
            kwargs=task_kwargs,
            backend=self.alias,
            errors=errors,
            worker_ids=[],
        )

        if result_bucket is not None and result_bucket.success and result_bucket.data:
            object.__setattr__(
                task_result, "_return_value", json.loads(result_bucket.data)
            )

        return task_result

    def get_result(self, result_id: str) -> TaskResult:
        return async_to_sync(self._aget_result)(result_id)

    async def aget_result(self, result_id: str) -> TaskResult:
        return await self._aget_result(result_id)
