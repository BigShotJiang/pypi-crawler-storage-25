import django_stubs_ext

django_stubs_ext.monkeypatch()

import importlib.metadata

__version__ = importlib.metadata.version(__name__)
