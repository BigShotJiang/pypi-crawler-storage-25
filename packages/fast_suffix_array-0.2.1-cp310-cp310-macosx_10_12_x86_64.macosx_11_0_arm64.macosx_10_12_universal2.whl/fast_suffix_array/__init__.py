"""fast-suffix-array: O(n) suffix array construction and duplicate phrase detection."""

from fast_suffix_array._native import (
    suffix_array_fn as suffix_array,
    lcp_array,
    count,
    locate,
    search_range,
    find_duplicates,
    find_duplicates_normalized,
    bwt,
    inverse_bwt_fn as inverse_bwt,
    longest_common_substring,
    distinct_substring_count,
    inverse_suffix_array,
    sa_to_bytes,
    sa_from_bytes,
)

try:
    from fast_suffix_array._native import FMIndex
except ImportError:
    pass  # fm-index feature not enabled

__all__ = [
    "suffix_array",
    "lcp_array",
    "count",
    "locate",
    "search_range",
    "find_duplicates",
    "find_duplicates_normalized",
    "bwt",
    "inverse_bwt",
    "longest_common_substring",
    "distinct_substring_count",
    "inverse_suffix_array",
    "sa_to_bytes",
    "sa_from_bytes",
    "FMIndex",
]
