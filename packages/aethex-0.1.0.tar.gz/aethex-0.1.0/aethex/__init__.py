"""
Aethex Python SDK.

Quick start:

    from aethex import AethexClient

    client = AethexClient(api_key="aex_live_...")

    verdict = client.cyber.analyze(events=[
        {"type": "failed_login"},
        {"type": "successful_login", "suspicious": True},
        {"type": "privilege_escalation", "suspicious": True},
    ])

    print(verdict["final_severity"])

Three product domains: cyber, finance, llm.
Account operations on client.account.

Full docs: https://github.com/aethexa1/aethexai
"""

from ._version import __version__

from .client import AethexClient

from .exceptions import (
    AethexError,
    AethexAuthError,
    AethexConnectionError,
    AethexNotFoundError,
    AethexPermissionError,
    AethexRateLimitError,
    AethexServerError,
    AethexValidationError,
)


__all__ = [
    "__version__",
    "AethexClient",
    "AethexError",
    "AethexAuthError",
    "AethexConnectionError",
    "AethexNotFoundError",
    "AethexPermissionError",
    "AethexRateLimitError",
    "AethexServerError",
    "AethexValidationError",
]
