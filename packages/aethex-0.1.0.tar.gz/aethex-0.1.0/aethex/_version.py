"""
Aethex Python SDK — single source of truth for version number.

Imported by setup.py / pyproject.toml at build time, and by
aethex/__init__.py at runtime so customers can introspect the
SDK version they have installed (`aethex.__version__`).

Bump on every PyPI release. Pre-1.0 follows 0.x.y where:
  - x bumps for breaking changes (rare pre-1.0)
  - y bumps for new features and bug fixes

Post-1.0 we'll switch to strict semver.
"""

__version__ = "0.1.0"
