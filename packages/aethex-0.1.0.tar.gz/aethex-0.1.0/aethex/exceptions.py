"""
Aethex SDK — exception hierarchy.

Customers catch these in their integration code. The hierarchy
lets them either catch broadly (every Aethex error) or narrowly
(only auth, only rate-limit, etc).

  AethexError                       -- root; catch this for any SDK error
    AethexAuthError                 -- 401: bad / missing / revoked API key
    AethexPermissionError           -- 403: key not scoped for this product
    AethexNotFoundError             -- 404: resource doesn't exist
    AethexRateLimitError            -- 429: over rate limit
    AethexValidationError           -- 400: malformed request
    AethexServerError               -- 5xx: Aethex side broke
    AethexConnectionError           -- network failure, timeout, DNS, SSL
"""

from typing import Optional


class AethexError(Exception):
    """
    Base class for every error this SDK raises.
    Carries the HTTP status code (if applicable) and the response
    body returned by the Aethex API for debugging.
    """

    def __init__(
        self,
        message:     str,
        status_code: Optional[int]  = None,
        response:    Optional[str]  = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response    = response

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"message={str(self)!r}, "
            f"status_code={self.status_code!r})"
        )


class AethexAuthError(AethexError):
    """401 — API key missing, malformed, or revoked."""


class AethexPermissionError(AethexError):
    """403 — API key valid but not scoped for the requested product."""


class AethexNotFoundError(AethexError):
    """404 — resource (webhook, audit entry, etc) does not exist."""


class AethexRateLimitError(AethexError):
    """429 — over the per-key rate limit. Customer should back off."""


class AethexValidationError(AethexError):
    """400 — request body malformed (bad event types, missing fields)."""


class AethexServerError(AethexError):
    """5xx — Aethex side broke. Retry may help."""


class AethexConnectionError(AethexError):
    """Network-layer failure: timeout, DNS error, SSL error, connection refused."""
