# Aethex Python SDK

Official Python client for [Aethex](https://github.com/aethexa1/aethexai) —
a multi-domain AI threat verification API with explainable reasoning chains.

Aethex runs threat events through 10 deterministic reasoning engines and
returns a verdict with severity, confidence, and a traceable reasoning
chain. Same engines work across three product domains:

- **Cyber** — SOC alerts, intrusion patterns, insider threats
- **Finance** — AML, sanctions screening, FATF typologies
- **LLM safety** — agent failure modes, prompt injection, tool-use exfiltration

Verdicts are deterministic. Same input produces the same output every
time, with the same audit trail. This is the core differentiator vs
LLM-only detection systems.

## Install

```bash
pip install aethex
```

No external dependencies. Pure stdlib (urllib, json).

## Quick start

```python
from aethex import AethexClient

client = AethexClient(api_key="aex_live_...")

# Cyber threat analysis
verdict = client.cyber.analyze(events=[
    {"type": "failed_login"},
    {"type": "failed_login"},
    {"type": "successful_login", "suspicious": True},
    {"type": "privilege_escalation", "suspicious": True},
    {"type": "lateral_movement", "suspicious": True},
])

print(verdict["final_severity"])    # CRITICAL
print(verdict["final_confidence"])  # 0.92
print(verdict["verdict"])           # human-readable summary
```

## Three product domains

```python
# Cyber
client.cyber.analyze(events=[...])

# Finance (AML / sanctions / fraud)
client.finance.analyze(events=[
    {"type": "ofac_full_match", "suspicious": True},
    {"type": "sanctioned_geography_routing", "suspicious": True},
])

# LLM safety
client.llm.analyze(events=[
    {"type": "external_document_retrieval"},
    {"type": "instruction_override_detected", "suspicious": True},
    {"type": "tool_use_data_exfiltration", "suspicious": True},
])

# Discover the canonical LLM event vocabulary
mapping = client.llm.vocabulary()
```

## Account operations

```python
# Audit log export (compliance)
audit = client.account.export_audit(format="json", from_="2026-01-01")

# Customer-tunable severity weighting
client.account.replace_loss_matrix({
    "failed_login":      0.5,   # downweight noisy events
    "external_transfer": 5.0,   # upweight critical events
})

# Webhooks for real-time alerts
webhook = client.account.create_webhook(
    url="https://your-app.com/aethex-webhook",
    threshold="CRITICAL",
)
# Save webhook["secret"] now -- it's shown only once.

deliveries = client.account.list_deliveries(webhook["id"])
```

## Error handling

```python
from aethex import (
    AethexAuthError,
    AethexRateLimitError,
    AethexValidationError,
    AethexConnectionError,
    AethexError,
)

try:
    verdict = client.cyber.analyze(events=[...])
except AethexAuthError:
    # 401 — bad / missing / revoked API key
    ...
except AethexRateLimitError:
    # 429 — back off and retry
    ...
except AethexValidationError as e:
    # 400 — request body malformed
    print(e.response)
except AethexConnectionError:
    # network / timeout / DNS / SSL
    ...
except AethexError:
    # catch-all for anything Aethex-related
    ...
```

## What you get back

Every `analyze` call returns a verdict dict with:

- `final_severity` — `LOW` / `MEDIUM` / `HIGH` / `CRITICAL`
- `final_confidence` — 0.0 to 1.0
- `verdict` — human-readable summary
- `action` — recommended operational response
- `engines` — per-engine outputs from all 10 reasoning engines
- `nyaya` — the formal reasoning chain that produced the verdict
- `chakravyuha` — defense-in-depth layers breached
- `disagreement` — when engines disagree, the system surfaces uncertainty
  rather than producing false confidence

See the [API documentation](https://github.com/aethexa1/aethexai)
for the full verdict shape.

## Configuration

```python
client = AethexClient(
    api_key="aex_live_...",
    base_url="https://aethex-api-1yqe.onrender.com",  # default
    timeout=30,                                       # seconds
)
```

## Status

Alpha. APIs are stabilizing. Breaking changes possible until 1.0.

## License

MIT. See LICENSE for details.

---

Built by Aethex. Questions: open an issue at the
[GitHub repo](https://github.com/aethexa1/aethexai/issues).
