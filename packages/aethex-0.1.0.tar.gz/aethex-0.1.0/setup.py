"""
Aethex Python SDK — setup.py

Modern packaging metadata lives in pyproject.toml. This file exists
for legacy compatibility with build tools that still expect a
setup.py to be present in the package root. setuptools will read
the pyproject.toml automatically.
"""

from setuptools import setup

setup()
