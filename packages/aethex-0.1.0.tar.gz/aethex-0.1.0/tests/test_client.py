"""
Aethex SDK — basic tests.

Run with:
    cd sdk && pip install -e .[dev] && pytest tests/

These are unit tests that don't hit the live API. They verify:
  - Client construction validates inputs
  - Exception mapping is correct for each HTTP status code
  - The repr doesn't leak the API key

Integration tests (which actually call the live API) live separately
and require AETHEX_API_KEY to be set. See test_integration.py if it
exists.
"""

import pytest

from aethex import (
    AethexClient,
    AethexAuthError,
    AethexConnectionError,
    AethexError,
    AethexNotFoundError,
    AethexPermissionError,
    AethexRateLimitError,
    AethexServerError,
    AethexValidationError,
)
from aethex.client import _raise_for_status


# ─── client construction ──────────────────────────────────

class TestClientConstruction:

    def test_valid_key(self):
        client = AethexClient(api_key="aex_live_test123")
        assert client._api_key == "aex_live_test123"

    def test_default_base_url(self):
        client = AethexClient(api_key="aex_live_test123")
        assert client._base_url == "https://aethex-api-1yqe.onrender.com"

    def test_custom_base_url(self):
        client = AethexClient(
            api_key="aex_live_test123",
            base_url="http://localhost:8000",
        )
        assert client._base_url == "http://localhost:8000"

    def test_base_url_trailing_slash_stripped(self):
        client = AethexClient(
            api_key="aex_live_test123",
            base_url="http://localhost:8000/",
        )
        assert client._base_url == "http://localhost:8000"

    def test_empty_key_rejected(self):
        with pytest.raises(ValueError, match="non-empty string"):
            AethexClient(api_key="")

    def test_none_key_rejected(self):
        with pytest.raises(ValueError, match="non-empty string"):
            AethexClient(api_key=None)

    def test_non_string_key_rejected(self):
        with pytest.raises(ValueError, match="non-empty string"):
            AethexClient(api_key=12345)

    def test_bad_format_key_rejected(self):
        with pytest.raises(ValueError, match="invalid format"):
            AethexClient(api_key="not_aethex_key")

    def test_subclients_present(self):
        client = AethexClient(api_key="aex_live_test123")
        assert client.cyber   is not None
        assert client.finance is not None
        assert client.llm     is not None
        assert client.account is not None


class TestClientRepr:

    def test_repr_does_not_leak_key(self):
        """The repr must never include the full API key."""
        client = AethexClient(api_key="aex_live_supersecret_dontleakme_abcdef")
        r = repr(client)
        assert "supersecret" not in r
        assert "dontleakme"   not in r
        # But the suffix is fine for debugging
        assert "cdef" in r

    def test_repr_includes_base_url(self):
        client = AethexClient(
            api_key="aex_live_test123",
            base_url="http://localhost:8000",
        )
        assert "localhost:8000" in repr(client)


# ─── exception mapping ────────────────────────────────────

class TestExceptionMapping:

    def test_401_raises_auth(self):
        with pytest.raises(AethexAuthError) as exc:
            _raise_for_status(401, '{"detail":"Invalid key"}')
        assert exc.value.status_code == 401

    def test_403_raises_permission(self):
        with pytest.raises(AethexPermissionError):
            _raise_for_status(403, '{"detail":"Wrong product"}')

    def test_404_raises_not_found(self):
        with pytest.raises(AethexNotFoundError):
            _raise_for_status(404, '{"detail":"Webhook not found"}')

    def test_429_raises_rate_limit(self):
        with pytest.raises(AethexRateLimitError):
            _raise_for_status(429, '{"detail":"Slow down"}')

    def test_400_raises_validation(self):
        with pytest.raises(AethexValidationError):
            _raise_for_status(400, '{"detail":"Bad event"}')

    def test_422_raises_validation(self):
        """FastAPI returns 422 for Pydantic validation errors."""
        with pytest.raises(AethexValidationError):
            _raise_for_status(422, '{"detail":[{"msg":"field required"}]}')

    def test_500_raises_server(self):
        with pytest.raises(AethexServerError):
            _raise_for_status(500, "Internal Server Error")

    def test_502_raises_server(self):
        with pytest.raises(AethexServerError):
            _raise_for_status(502, "Bad Gateway")

    def test_503_raises_server(self):
        with pytest.raises(AethexServerError):
            _raise_for_status(503, "Service Unavailable")


# ─── exception class behavior ─────────────────────────────

class TestExceptionClasses:

    def test_all_inherit_from_aethex_error(self):
        """Customers should be able to catch AethexError to catch any SDK error."""
        for exc_cls in (
            AethexAuthError,
            AethexPermissionError,
            AethexNotFoundError,
            AethexRateLimitError,
            AethexValidationError,
            AethexServerError,
            AethexConnectionError,
        ):
            assert issubclass(exc_cls, AethexError)

    def test_carries_status_code(self):
        e = AethexAuthError("test", status_code=401, response="body")
        assert e.status_code == 401
        assert e.response    == "body"

    def test_repr_includes_class_name_and_status(self):
        e = AethexAuthError("auth failed", status_code=401)
        r = repr(e)
        assert "AethexAuthError" in r
        assert "401"             in r
