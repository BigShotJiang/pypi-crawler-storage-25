# Note: this is an automatically generated file. Do not edit.
r"""Functions for deep term rewriting operations involving hoisting subterms or bindings into enclosing let terms."""
from __future__ import annotations
from collections.abc import Callable
from functools import lru_cache
from hydra.dsl.python import Just, Maybe, Nothing, frozenlist
from typing import TypeVar, cast
import hydra.core
import hydra.environment
import hydra.graph
import hydra.lexical
import hydra.lib.equality
import hydra.lib.lists
import hydra.lib.literals
import hydra.lib.logic
import hydra.lib.maps
import hydra.lib.math
import hydra.lib.maybes
import hydra.lib.pairs
import hydra.lib.sets
import hydra.lib.strings
import hydra.paths
import hydra.resolution
import hydra.rewriting
import hydra.scoping
import hydra.sorting
import hydra.strip
import hydra.substitution
import hydra.typing
import hydra.variables
T0 = TypeVar("T0")
T1 = TypeVar("T1")
T2 = TypeVar("T2")
T3 = TypeVar("T3")
def augment_bindings_with_new_free_vars(cx: hydra.graph.Graph, bound_vars: frozenset[hydra.core.Name], bindings: frozenlist[hydra.core.Binding]) -> tuple[frozenlist[hydra.core.Binding], hydra.typing.TermSubst]:
    r"""Augment bindings with new free variables introduced by substitution, wrapping with lambdas after any type lambdas."""
    @lru_cache(1)
    def types() -> FrozenDict[hydra.core.Name, hydra.core.Type]:
        return hydra.lib.maps.map((lambda x1: hydra.scoping.type_scheme_to_f_type(x1)), cx.bound_types)
    def wrap_after_type_lambdas(vars: frozenlist[tuple[hydra.core.Name, Maybe[hydra.core.Type]]], term: hydra.core.Term) -> hydra.core.Term:
        match term:
            case hydra.core.TermTypeLambda(value=tl):
                return cast(hydra.core.Term, hydra.core.TermTypeLambda(hydra.core.TypeLambda(tl.parameter, wrap_after_type_lambdas(vars, tl.body))))
            case _:
                return hydra.lib.lists.foldl((lambda t, p: cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.lib.pairs.first(p), hydra.lib.pairs.second(p), t)))), term, hydra.lib.lists.reverse(vars))
    def augment(b: hydra.core.Binding) -> tuple[hydra.core.Binding, Maybe[tuple[hydra.core.Name, hydra.core.Term]]]:
        @lru_cache(1)
        def free_vars() -> frozenlist[hydra.core.Name]:
            return hydra.lib.sets.to_list(hydra.lib.sets.intersection(bound_vars, hydra.variables.free_variables_in_term(b.term)))
        @lru_cache(1)
        def var_type_pairs() -> frozenlist[tuple[hydra.core.Name, Maybe[hydra.core.Type]]]:
            return hydra.lib.lists.map((lambda v: (v, hydra.lib.maps.lookup(v, types()))), free_vars())
        @lru_cache(1)
        def var_types() -> frozenlist[hydra.core.Type]:
            return hydra.lib.maybes.cat(hydra.lib.lists.map((lambda x1: hydra.lib.pairs.second(x1)), var_type_pairs()))
        return hydra.lib.logic.if_else(hydra.lib.logic.or_(hydra.lib.lists.null(free_vars()), hydra.lib.logic.not_(hydra.lib.equality.equal(hydra.lib.lists.length(var_types()), hydra.lib.lists.length(var_type_pairs())))), (lambda : (b, Nothing())), (lambda : (hydra.core.Binding(b.name, wrap_after_type_lambdas(var_type_pairs(), b.term), hydra.lib.maybes.map((lambda ts: hydra.core.TypeScheme(ts.variables, hydra.lib.lists.foldl((lambda acc, t: cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(t, acc)))), ts.body, hydra.lib.lists.reverse(var_types())), ts.constraints)), b.type_scheme)), Just((b.name, hydra.lib.lists.foldl((lambda t, v: cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(t, cast(hydra.core.Term, hydra.core.TermVariable(v)))))), cast(hydra.core.Term, hydra.core.TermVariable(b.name)), free_vars()))))))
    @lru_cache(1)
    def results() -> frozenlist[tuple[hydra.core.Binding, Maybe[tuple[hydra.core.Name, hydra.core.Term]]]]:
        return hydra.lib.lists.map((lambda x1: augment(x1)), bindings)
    return (hydra.lib.lists.map((lambda x1: hydra.lib.pairs.first(x1)), results()), hydra.typing.TermSubst(hydra.lib.maps.from_list(hydra.lib.maybes.cat(hydra.lib.lists.map((lambda x1: hydra.lib.pairs.second(x1)), results())))))
def binding_is_polymorphic(binding: hydra.core.Binding) -> bool:
    r"""Check if a binding has a polymorphic type (non-empty list of type scheme variables)."""
    return hydra.lib.maybes.maybe((lambda : False), (lambda ts: hydra.lib.logic.not_(hydra.lib.lists.null(ts.variables))), binding.type_scheme)
def binding_uses_context_type_vars(cx: hydra.graph.Graph, binding: hydra.core.Binding) -> bool:
    r"""Check if a binding's type uses any type variables from the given Graph. Returns True if the free type variables in the binding's type intersect with the type variables in scope (graphTypeVariables)."""
    return hydra.lib.maybes.maybe((lambda : False), (lambda ts: (free_in_type := hydra.variables.free_variables_in_type(ts.body), context_type_vars := cx.type_variables, hydra.lib.logic.not_(hydra.lib.sets.null(hydra.lib.sets.intersection(free_in_type, context_type_vars))))[2]), binding.type_scheme)
def count_var_occurrences(name: hydra.core.Name, term: hydra.core.Term) -> int:
    r"""Count the number of occurrences of a variable name in a term. Assumes no variable shadowing."""
    @lru_cache(1)
    def child_count() -> int:
        return hydra.lib.lists.foldl((lambda acc, t: hydra.lib.math.add(acc, count_var_occurrences(name, t))), 0, hydra.rewriting.subterms(term))
    match term:
        case hydra.core.TermVariable(value=v):
            return hydra.lib.logic.if_else(hydra.lib.equality.equal(v, name), (lambda : hydra.lib.math.add(1, child_count())), (lambda : child_count()))
        case _:
            return child_count()
def hoist_let_bindings_with_predicate(is_parent_binding: Callable[[hydra.core.Binding], bool], should_hoist_binding: Callable[[hydra.graph.Graph, hydra.core.Binding], bool], cx0: hydra.graph.Graph, let0: hydra.core.Let) -> hydra.core.Let:
    r"""Transform a let-term by pulling let bindings to the top level. The isParentBinding predicate applies to top-level bindings and determines whether their subterm bindings are eligible for hoisting. The shouldHoistBinding predicate takes the Graph and a subterm binding, and returns True if the binding should be hoisted. This is useful for targets like Java that cannot have polymorphic definitions in arbitrary positions. The Graph provides information about type variables and lambda variables in scope. If a hoisted binding captures let-bound or lambda-bound variables from an enclosing scope, the binding is wrapped in lambdas for those variables, and references are replaced with applications. If a hoisted binding captures type variables from an enclosing type lambda scope, those type variables are added to the binding's type scheme, and references are replaced with type applications. Note: we assume that there is no variable shadowing; use hydra.rewriting.unshadowVariables first."""
    def hoist_one(prefix: str, cx: hydra.graph.Graph, pair: tuple[frozenlist[tuple[hydra.core.Binding, hydra.core.Term]], frozenset[hydra.core.Name]], binding_with_captured_vars: tuple[hydra.core.Binding, frozenlist[hydra.core.Name]]) -> tuple[frozenlist[tuple[hydra.core.Binding, hydra.core.Term]], frozenset[hydra.core.Name]]:
        @lru_cache(1)
        def binding_and_replacement_pairs() -> frozenlist[tuple[hydra.core.Binding, hydra.core.Term]]:
            return hydra.lib.pairs.first(pair)
        @lru_cache(1)
        def already_used_names() -> frozenset[hydra.core.Name]:
            return hydra.lib.pairs.second(pair)
        @lru_cache(1)
        def b() -> hydra.core.Binding:
            return hydra.lib.pairs.first(binding_with_captured_vars)
        @lru_cache(1)
        def captured_term_vars() -> frozenlist[hydra.core.Name]:
            return hydra.lib.pairs.second(binding_with_captured_vars)
        @lru_cache(1)
        def types() -> FrozenDict[hydra.core.Name, hydra.core.Type]:
            return hydra.lib.maps.map((lambda x1: hydra.scoping.type_scheme_to_f_type(x1)), cx.bound_types)
        @lru_cache(1)
        def captured_term_var_type_pairs() -> frozenlist[tuple[hydra.core.Name, Maybe[hydra.core.Type]]]:
            return hydra.lib.lists.map((lambda v: (v, hydra.lib.maps.lookup(v, types()))), captured_term_vars())
        @lru_cache(1)
        def captured_term_var_types() -> frozenlist[hydra.core.Type]:
            return hydra.lib.lists.map((lambda typ: hydra.strip.deannotate_type_parameters(typ)), hydra.lib.maybes.cat(hydra.lib.lists.map((lambda x1: hydra.lib.pairs.second(x1)), captured_term_var_type_pairs())))
        @lru_cache(1)
        def free_in_binding_type() -> frozenset[hydra.core.Name]:
            return hydra.lib.maybes.maybe((lambda : hydra.lib.sets.empty()), (lambda ts: hydra.variables.free_variables_in_type(ts.body)), b().type_scheme)
        @lru_cache(1)
        def free_in_captured_var_types() -> frozenset[hydra.core.Name]:
            return hydra.lib.sets.unions(hydra.lib.lists.map((lambda t: hydra.variables.free_variables_in_type(t)), captured_term_var_types()))
        @lru_cache(1)
        def captured_type_vars() -> frozenlist[hydra.core.Name]:
            return hydra.lib.sets.to_list(hydra.lib.sets.intersection(cx.type_variables, hydra.lib.sets.union(free_in_binding_type(), free_in_captured_var_types())))
        @lru_cache(1)
        def global_binding_name() -> hydra.core.Name:
            return hydra.lexical.choose_unique_name(already_used_names(), hydra.core.Name(hydra.lib.strings.cat2(prefix, b().name.value)))
        @lru_cache(1)
        def new_used_names() -> frozenset[hydra.core.Name]:
            return hydra.lib.sets.insert(global_binding_name(), already_used_names())
        @lru_cache(1)
        def new_type_scheme() -> Maybe[hydra.core.TypeScheme]:
            return hydra.lib.logic.if_else(hydra.lib.equality.equal(hydra.lib.lists.length(captured_term_var_types()), hydra.lib.lists.length(captured_term_var_type_pairs())), (lambda : hydra.lib.maybes.map((lambda ts: hydra.core.TypeScheme(hydra.lib.lists.nub(hydra.lib.lists.concat2(captured_type_vars(), ts.variables)), hydra.lib.lists.foldl((lambda t, a: cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(a, t)))), ts.body, hydra.lib.lists.reverse(captured_term_var_types())), ts.constraints)), b().type_scheme)), (lambda : Nothing()))
        @lru_cache(1)
        def stripped_term() -> hydra.core.Term:
            return hydra.strip.strip_type_lambdas(b().term)
        @lru_cache(1)
        def term_with_lambdas() -> hydra.core.Term:
            return hydra.lib.lists.foldl((lambda t, p: cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.lib.pairs.first(p), hydra.lib.maybes.map((lambda dom: hydra.strip.deannotate_type_parameters(dom)), hydra.lib.pairs.second(p)), t)))), stripped_term(), hydra.lib.lists.reverse(captured_term_var_type_pairs()))
        @lru_cache(1)
        def term_with_type_lambdas() -> hydra.core.Term:
            return hydra.lib.lists.foldl((lambda t, v: cast(hydra.core.Term, hydra.core.TermTypeLambda(hydra.core.TypeLambda(v, t)))), term_with_lambdas(), hydra.lib.lists.reverse(hydra.lib.maybes.maybe((lambda : ()), (lambda v1: v1.variables), new_type_scheme())))
        @lru_cache(1)
        def with_type_apps() -> hydra.core.Term:
            return hydra.lib.lists.foldl((lambda t, v: cast(hydra.core.Term, hydra.core.TermTypeApplication(hydra.core.TypeApplicationTerm(t, cast(hydra.core.Type, hydra.core.TypeVariable(v)))))), cast(hydra.core.Term, hydra.core.TermVariable(global_binding_name())), captured_type_vars())
        @lru_cache(1)
        def replacement() -> hydra.core.Term:
            return hydra.lib.lists.foldl((lambda t, v: cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(t, cast(hydra.core.Term, hydra.core.TermVariable(v)))))), with_type_apps(), captured_term_vars())
        @lru_cache(1)
        def new_binding_and_replacement() -> tuple[hydra.core.Binding, hydra.core.Term]:
            return (hydra.core.Binding(global_binding_name(), term_with_type_lambdas(), new_type_scheme()), replacement())
        @lru_cache(1)
        def new_pairs() -> frozenlist[tuple[hydra.core.Binding, hydra.core.Term]]:
            return hydra.lib.lists.cons(new_binding_and_replacement(), binding_and_replacement_pairs())
        return (new_pairs(), new_used_names())
    def rewrite(prefix: str, recurse: Callable[[tuple[frozenlist[T0], T1], T2], tuple[tuple[frozenlist[hydra.core.Binding], frozenset[hydra.core.Name]], hydra.core.Term]], cx: hydra.graph.Graph, bindings_and_names: tuple[frozenlist[hydra.core.Binding], T1], term: T2):
        @lru_cache(1)
        def previously_finished_bindings() -> frozenlist[hydra.core.Binding]:
            return hydra.lib.pairs.first(bindings_and_names)
        @lru_cache(1)
        def empty_bindings_and_names() -> tuple[frozenlist[T3], T1]:
            return ((), hydra.lib.pairs.second(bindings_and_names))
        @lru_cache(1)
        def result() -> tuple[tuple[frozenlist[hydra.core.Binding], frozenset[hydra.core.Name]], hydra.core.Term]:
            return recurse(empty_bindings_and_names(), term)
        @lru_cache(1)
        def new_bindings_and_names() -> tuple[frozenlist[hydra.core.Binding], frozenset[hydra.core.Name]]:
            return hydra.lib.pairs.first(result())
        @lru_cache(1)
        def bindings_so_far() -> frozenlist[hydra.core.Binding]:
            return hydra.lib.pairs.first(new_bindings_and_names())
        @lru_cache(1)
        def already_used_names() -> frozenset[hydra.core.Name]:
            return hydra.lib.pairs.second(new_bindings_and_names())
        @lru_cache(1)
        def new_term() -> hydra.core.Term:
            return hydra.lib.pairs.second(result())
        def _hoist_new_term_body_1(v1):
            match v1:
                case hydra.core.TermLet(value=l):
                    body = l.body
                    @lru_cache(1)
                    def partition_pair() -> tuple[frozenlist[hydra.core.Binding], frozenlist[hydra.core.Binding]]:
                        return hydra.lib.lists.partition((lambda v12: should_hoist_binding(cx, v12)), l.bindings)
                    @lru_cache(1)
                    def hoist_us() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.pairs.first(partition_pair())
                    @lru_cache(1)
                    def keep_us() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.pairs.second(partition_pair())
                    @lru_cache(1)
                    def hoisted_binding_names() -> frozenlist[hydra.core.Name]:
                        return hydra.lib.lists.map((lambda v1: v1.name), hoist_us())
                    @lru_cache(1)
                    def poly_let_variables() -> frozenset[hydra.core.Name]:
                        return hydra.lib.sets.from_list(hydra.lib.lists.filter((lambda v: hydra.lib.maybes.maybe((lambda : False), (lambda x1: hydra.resolution.f_type_is_polymorphic(x1)), hydra.lib.maybes.map((lambda x1: hydra.scoping.type_scheme_to_f_type(x1)), hydra.lib.maps.lookup(v, cx.bound_types)))), hydra.lib.sets.to_list(hydra.lib.sets.difference(hydra.lib.sets.from_list(hydra.lib.maps.keys(cx.bound_terms)), cx.lambda_variables))))
                    @lru_cache(1)
                    def bound_term_variables() -> frozenset[hydra.core.Name]:
                        return hydra.lib.sets.union(cx.lambda_variables, hydra.lib.sets.difference(hydra.lib.sets.from_list(hydra.lib.maps.keys(cx.bound_terms)), cx.lambda_variables))
                    @lru_cache(1)
                    def free_variables_in_each_binding() -> frozenlist[frozenlist[hydra.core.Name]]:
                        return hydra.lib.lists.map((lambda b: hydra.lib.sets.to_list(hydra.lib.sets.intersection(bound_term_variables(), hydra.variables.free_variables_in_term(b.term)))), hoist_us())
                    @lru_cache(1)
                    def binding_dependencies() -> frozenlist[tuple[frozenlist[hydra.core.Name], frozenlist[hydra.core.Name]]]:
                        return hydra.lib.lists.map((lambda vars: hydra.lib.lists.partition((lambda v: hydra.lib.sets.member(v, hydra.lib.sets.from_list(hoisted_binding_names()))), vars)), free_variables_in_each_binding())
                    @lru_cache(1)
                    def binding_edges() -> frozenlist[tuple[hydra.core.Name, frozenlist[hydra.core.Name]]]:
                        return hydra.lib.lists.zip(hoisted_binding_names(), hydra.lib.lists.map((lambda x1: hydra.lib.pairs.first(x1)), binding_dependencies()))
                    @lru_cache(1)
                    def binding_immediate_captured_vars() -> frozenlist[tuple[hydra.core.Name, frozenlist[hydra.core.Name]]]:
                        return hydra.lib.lists.zip(hoisted_binding_names(), hydra.lib.lists.map((lambda x1: hydra.lib.pairs.second(x1)), binding_dependencies()))
                    @lru_cache(1)
                    def captured_vars_map() -> FrozenDict[hydra.core.Name, frozenset[hydra.core.Name]]:
                        return hydra.lib.maps.from_list(hydra.sorting.propagate_tags(binding_edges(), binding_immediate_captured_vars()))
                    @lru_cache(1)
                    def bindings_with_captured_vars() -> frozenlist[tuple[hydra.core.Binding, frozenlist[hydra.core.Name]]]:
                        return hydra.lib.lists.map((lambda b: (b, hydra.lib.maybes.maybe((lambda : ()), (lambda vars: hydra.lib.sets.to_list(hydra.lib.sets.difference(vars, poly_let_variables()))), hydra.lib.maps.lookup(b.name, captured_vars_map())))), hoist_us())
                    @lru_cache(1)
                    def hoist_pairs_and_names() -> tuple[frozenlist[tuple[hydra.core.Binding, hydra.core.Term]], frozenset[hydra.core.Name]]:
                        return hydra.lib.lists.foldl((lambda v12, v2: hoist_one(prefix, cx, v12, v2)), ((), already_used_names()), bindings_with_captured_vars())
                    @lru_cache(1)
                    def hoist_pairs() -> frozenlist[tuple[hydra.core.Binding, hydra.core.Term]]:
                        return hydra.lib.lists.reverse(hydra.lib.pairs.first(hoist_pairs_and_names()))
                    @lru_cache(1)
                    def hoisted_bindings() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda x1: hydra.lib.pairs.first(x1)), hoist_pairs())
                    @lru_cache(1)
                    def replacements() -> frozenlist[hydra.core.Term]:
                        return hydra.lib.lists.map((lambda x1: hydra.lib.pairs.second(x1)), hoist_pairs())
                    @lru_cache(1)
                    def final_used_names() -> frozenset[hydra.core.Name]:
                        return hydra.lib.pairs.second(hoist_pairs_and_names())
                    @lru_cache(1)
                    def hoist_name_replacement_pairs() -> frozenlist[tuple[hydra.core.Name, hydra.core.Term]]:
                        return hydra.lib.lists.zip(hydra.lib.lists.map((lambda v1: v1.name), hoist_us()), replacements())
                    @lru_cache(1)
                    def hoist_binding_map() -> FrozenDict[hydra.core.Name, hydra.core.Binding]:
                        return hydra.lib.maps.from_list(hydra.lib.lists.map((lambda b: (b.name, b)), hoist_us()))
                    def is_cacheable(name: hydra.core.Name) -> bool:
                        @lru_cache(1)
                        def multi_ref() -> bool:
                            return hydra.lib.equality.gte(count_var_occurrences(name, body), 2)
                        @lru_cache(1)
                        def is_poly() -> bool:
                            return hydra.lib.maybes.maybe((lambda : False), (lambda b: binding_is_polymorphic(b)), hydra.lib.maps.lookup(name, hoist_binding_map()))
                        return hydra.lib.logic.and_(multi_ref(), hydra.lib.logic.not_(is_poly()))
                    @lru_cache(1)
                    def single_ref_pairs() -> frozenlist[tuple[hydra.core.Name, hydra.core.Term]]:
                        return hydra.lib.lists.filter((lambda p: hydra.lib.logic.not_(is_cacheable(hydra.lib.pairs.first(p)))), hoist_name_replacement_pairs())
                    @lru_cache(1)
                    def multi_ref_pairs() -> frozenlist[tuple[hydra.core.Name, hydra.core.Term]]:
                        return hydra.lib.lists.filter((lambda p: is_cacheable(hydra.lib.pairs.first(p))), hoist_name_replacement_pairs())
                    @lru_cache(1)
                    def full_subst() -> hydra.typing.TermSubst:
                        return hydra.typing.TermSubst(hydra.lib.maps.from_list(hoist_name_replacement_pairs()))
                    @lru_cache(1)
                    def body_only_subst() -> hydra.typing.TermSubst:
                        return hydra.typing.TermSubst(hydra.lib.maps.from_list(single_ref_pairs()))
                    @lru_cache(1)
                    def body_subst() -> hydra.core.Term:
                        return hydra.substitution.substitute_in_term(body_only_subst(), body)
                    @lru_cache(1)
                    def cache_bindings() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda p: (orig_type := hydra.lib.maybes.maybe((lambda : Nothing()), (lambda b: b.type_scheme), hydra.lib.maps.lookup(hydra.lib.pairs.first(p), hoist_binding_map())), hydra.core.Binding(hydra.lib.pairs.first(p), hydra.lib.pairs.second(p), orig_type))[1]), multi_ref_pairs())
                    @lru_cache(1)
                    def body_with_cache() -> hydra.core.Term:
                        return hydra.lib.logic.if_else(hydra.lib.lists.null(cache_bindings()), (lambda : body_subst()), (lambda : cast(hydra.core.Term, hydra.core.TermLet(hydra.core.Let(cache_bindings(), body_subst())))))
                    @lru_cache(1)
                    def keep_us_subst() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda v12: hydra.substitution.substitute_in_binding(full_subst(), v12)), keep_us())
                    @lru_cache(1)
                    def hoisted_bindings_subst() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda v12: hydra.substitution.substitute_in_binding(full_subst(), v12)), hoisted_bindings())
                    @lru_cache(1)
                    def bindings_so_far_subst() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda v12: hydra.substitution.substitute_in_binding(full_subst(), v12)), bindings_so_far())
                    @lru_cache(1)
                    def augment_result() -> tuple[frozenlist[hydra.core.Binding], hydra.typing.TermSubst]:
                        return augment_bindings_with_new_free_vars(cx, hydra.lib.sets.difference(bound_term_variables(), poly_let_variables()), bindings_so_far_subst())
                    @lru_cache(1)
                    def bindings_so_far_augmented() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.pairs.first(augment_result())
                    @lru_cache(1)
                    def augment_subst() -> hydra.typing.TermSubst:
                        return hydra.lib.pairs.second(augment_result())
                    @lru_cache(1)
                    def hoisted_bindings_final() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda v12: hydra.substitution.substitute_in_binding(augment_subst(), v12)), hoisted_bindings_subst())
                    @lru_cache(1)
                    def bindings_so_far_final() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda v12: hydra.substitution.substitute_in_binding(augment_subst(), v12)), bindings_so_far_augmented())
                    @lru_cache(1)
                    def body_final() -> hydra.core.Term:
                        return hydra.substitution.substitute_in_term(augment_subst(), body_with_cache())
                    @lru_cache(1)
                    def keep_us_final() -> frozenlist[hydra.core.Binding]:
                        return hydra.lib.lists.map((lambda v12: hydra.substitution.substitute_in_binding(augment_subst(), v12)), keep_us_subst())
                    @lru_cache(1)
                    def final_term() -> hydra.core.Term:
                        return hydra.lib.logic.if_else(hydra.lib.lists.null(keep_us_final()), (lambda : body_final()), (lambda : cast(hydra.core.Term, hydra.core.TermLet(hydra.core.Let(keep_us_final(), body_final())))))
                    return ((hydra.lib.lists.concat((previously_finished_bindings(), hoisted_bindings_final(), bindings_so_far_final())), final_used_names()), final_term())
                case _:
                    return ((hydra.lib.lists.concat2(previously_finished_bindings(), bindings_so_far()), already_used_names()), new_term())
        return _hoist_new_term_body_1(new_term())
    @lru_cache(1)
    def cx1() -> hydra.graph.Graph:
        return hydra.scoping.extend_graph_for_let((lambda c, b: Nothing()), cx0, let0)
    def for_active_binding(b: hydra.core.Binding) -> frozenlist[hydra.core.Binding]:
        @lru_cache(1)
        def prefix() -> str:
            return hydra.lib.strings.cat2(b.name.value, "_")
        @lru_cache(1)
        def init() -> tuple[frozenlist[T0], frozenset[hydra.core.Name]]:
            return ((), hydra.lib.sets.singleton(b.name))
        @lru_cache(1)
        def result_pair() -> tuple[tuple[frozenlist[hydra.core.Binding], frozenset[hydra.core.Name]], hydra.core.Term]:
            return hydra.rewriting.rewrite_and_fold_term_with_graph((lambda v1, v2, v3, v4: rewrite(prefix(), v1, v2, v3, v4)), cx1(), init(), b.term)
        @lru_cache(1)
        def result_bindings() -> frozenlist[hydra.core.Binding]:
            return hydra.lib.pairs.first(hydra.lib.pairs.first(result_pair()))
        @lru_cache(1)
        def result_term() -> hydra.core.Term:
            return hydra.lib.pairs.second(result_pair())
        return hydra.lib.lists.cons(hydra.core.Binding(b.name, result_term(), b.type_scheme), result_bindings())
    def for_binding(b: hydra.core.Binding) -> frozenlist[hydra.core.Binding]:
        return hydra.lib.logic.if_else(is_parent_binding(b), (lambda : for_active_binding(b)), (lambda : (b,)))
    return hydra.core.Let(hydra.lib.lists.concat(hydra.lib.lists.map((lambda x1: for_binding(x1)), let0.bindings)), let0.body)
def should_hoist_all(_: T0, _2: T1) -> bool:
    r"""Predicate that always returns True, for hoisting all bindings unconditionally."""
    return True
def hoist_all_let_bindings(let0: hydra.core.Let) -> hydra.core.Let:
    r"""Transform a let-term by pulling ALL let bindings to the top level. This is useful for targets like Java that don't support nested let expressions at all. If a hoisted binding captures lambda-bound variables from an enclosing scope, the binding is wrapped in lambdas for those variables, and references are replaced with applications. Note: Assumes no variable shadowing; use hydra.rewriting.unshadowVariables first."""
    @lru_cache(1)
    def empty_cx() -> hydra.graph.Graph:
        return hydra.graph.Graph(hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.sets.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.sets.empty())
    return hoist_let_bindings_with_predicate((lambda _: True), (lambda x1, x2: should_hoist_all(x1, x2)), empty_cx(), let0)
def hoist_subterms(should_hoist: Callable[[tuple[frozenlist[hydra.paths.SubtermStep], hydra.core.Term]], bool], cx0: hydra.graph.Graph, term0: hydra.core.Term) -> hydra.core.Term:
    r"""Hoist subterms into local let bindings based on a path-aware predicate. The predicate receives a pair of (path, term) where path is the list of SubtermSteps from the root to the current term, and returns True if the term should be hoisted. For each let term found, the immediate subterms (binding values and body) are processed: matching subterms within each immediate subterm are collected and hoisted into a local let that wraps that immediate subterm. If a hoisted term contains free variables that are lambda-bound at an enclosing scope, the hoisted binding is wrapped in lambdas for those variables, and the reference is replaced with an application of those variables."""
    def process_immediate_subterm(cx: hydra.graph.Graph, counter: int, name_prefix: str, path_prefix: frozenlist[hydra.paths.SubtermStep], subterm: hydra.core.Term) -> tuple[int, hydra.core.Term]:
        baseline_lambda_vars = cx.lambda_variables
        def collect_and_replace(recurse: Callable[[tuple[int, frozenlist[hydra.core.Binding]], hydra.core.Term], tuple[tuple[int, frozenlist[hydra.core.Binding]], hydra.core.Term]], path: frozenlist[hydra.paths.SubtermStep], cx_inner: hydra.graph.Graph, acc: tuple[int, frozenlist[hydra.core.Binding]], term: hydra.core.Term) -> tuple[tuple[int, frozenlist[hydra.core.Binding]], hydra.core.Term]:
            @lru_cache(1)
            def current_counter() -> int:
                return hydra.lib.pairs.first(acc)
            @lru_cache(1)
            def collected_bindings() -> frozenlist[hydra.core.Binding]:
                return hydra.lib.pairs.second(acc)
            match term:
                case hydra.core.TermLet():
                    return (acc, term)
                case hydra.core.TermTypeLambda():
                    return (acc, term)
                case _:
                    return (result := recurse(acc, term), (new_acc := hydra.lib.pairs.first(result), (processed_term := hydra.lib.pairs.second(result), (new_counter := hydra.lib.pairs.first(new_acc), (new_bindings := hydra.lib.pairs.second(new_acc), (full_path := hydra.lib.lists.concat2(path_prefix, path), hydra.lib.logic.if_else(should_hoist((full_path, processed_term)), (lambda : (proposed_name := hydra.core.Name(hydra.lib.strings.cat(("_hoist_", name_prefix, "_", hydra.lib.literals.show_int32(new_counter)))), (existing_names := hydra.lib.sets.from_list(hydra.lib.lists.map((lambda b: b.name), new_bindings)), (free_vars_in_subterm := hydra.variables.free_variables_in_term(subterm), (all_reserved := hydra.lib.sets.union(existing_names, free_vars_in_subterm), (binding_name := hydra.lexical.choose_unique_name(all_reserved, proposed_name), (all_lambda_vars := cx_inner.lambda_variables, (new_lambda_vars := hydra.lib.sets.difference(all_lambda_vars, baseline_lambda_vars), (free_vars := hydra.variables.free_variables_in_term(processed_term), (captured_vars := hydra.lib.sets.to_list(hydra.lib.sets.intersection(new_lambda_vars, free_vars)), (type_map := hydra.lib.maps.map((lambda x1: hydra.scoping.type_scheme_to_f_type(x1)), cx_inner.bound_types), (wrapped_term := hydra.lib.lists.foldl((lambda body, var_name: cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(var_name, hydra.lib.maps.lookup(var_name, type_map), body)))), processed_term, hydra.lib.lists.reverse(captured_vars)), (reference := hydra.lib.lists.foldl((lambda fn, var_name: cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(fn, cast(hydra.core.Term, hydra.core.TermVariable(var_name)))))), cast(hydra.core.Term, hydra.core.TermVariable(binding_name)), captured_vars), (new_binding := hydra.core.Binding(binding_name, wrapped_term, Nothing()), ((hydra.lib.math.add(new_counter, 1), hydra.lib.lists.cons(new_binding, new_bindings)), reference))[1])[1])[1])[1])[1])[1])[1])[1])[1])[1])[1])[1])[1]), (lambda : (new_acc, processed_term))))[1])[1])[1])[1])[1])[1]
        @lru_cache(1)
        def result() -> tuple[tuple[int, frozenlist[hydra.core.Binding]], hydra.core.Term]:
            return hydra.rewriting.rewrite_and_fold_term_with_graph_and_path((lambda x1, x2, x3, x4, x5: collect_and_replace(x1, x2, x3, x4, x5)), cx, (counter, ()), subterm)
        @lru_cache(1)
        def final_acc() -> tuple[int, frozenlist[hydra.core.Binding]]:
            return hydra.lib.pairs.first(result())
        @lru_cache(1)
        def transformed_subterm() -> hydra.core.Term:
            return hydra.lib.pairs.second(result())
        @lru_cache(1)
        def final_counter() -> int:
            return hydra.lib.pairs.first(final_acc())
        @lru_cache(1)
        def bindings() -> frozenlist[hydra.core.Binding]:
            return hydra.lib.pairs.second(final_acc())
        return hydra.lib.logic.if_else(hydra.lib.lists.null(bindings()), (lambda : (final_counter(), transformed_subterm())), (lambda : (local_let := cast(hydra.core.Term, hydra.core.TermLet(hydra.core.Let(hydra.lib.lists.reverse(bindings()), transformed_subterm()))), (final_counter(), local_let))[1]))
    def process_let_term(cx: hydra.graph.Graph, counter: T0, path: frozenlist[hydra.paths.SubtermStep], lt: hydra.core.Let) -> tuple[T0, hydra.core.Term]:
        bindings = lt.bindings
        body = lt.body
        def process_binding(acc: frozenlist[hydra.core.Binding], binding: hydra.core.Binding) -> frozenlist[hydra.core.Binding]:
            @lru_cache(1)
            def name_prefix() -> str:
                return hydra.lib.strings.intercalate("_", hydra.lib.strings.split_on(".", binding.name.value))
            @lru_cache(1)
            def binding_path_prefix() -> frozenlist[hydra.paths.SubtermStep]:
                return hydra.lib.lists.concat2(path, (cast(hydra.paths.SubtermStep, hydra.paths.SubtermStepLetBinding(binding.name)),))
            @lru_cache(1)
            def result() -> tuple[int, hydra.core.Term]:
                return process_immediate_subterm(cx, 1, name_prefix(), binding_path_prefix(), binding.term)
            @lru_cache(1)
            def new_value() -> hydra.core.Term:
                return hydra.lib.pairs.second(result())
            new_binding = hydra.core.Binding(binding.name, new_value(), binding.type_scheme)
            return hydra.lib.lists.cons(new_binding, acc)
        @lru_cache(1)
        def new_bindings_reversed() -> frozenlist[hydra.core.Binding]:
            return hydra.lib.lists.foldl((lambda x1, x2: process_binding(x1, x2)), (), bindings)
        @lru_cache(1)
        def new_bindings() -> frozenlist[hydra.core.Binding]:
            return hydra.lib.lists.reverse(new_bindings_reversed())
        @lru_cache(1)
        def body_path_prefix() -> frozenlist[hydra.paths.SubtermStep]:
            return hydra.lib.lists.concat2(path, (cast(hydra.paths.SubtermStep, hydra.paths.SubtermStepLetBody()),))
        @lru_cache(1)
        def first_binding_name() -> str:
            return hydra.lib.maybes.maybe((lambda : "body"), (lambda b: hydra.lib.strings.intercalate("_", hydra.lib.strings.split_on(".", b.name.value))), hydra.lib.lists.maybe_head(bindings))
        @lru_cache(1)
        def body_prefix() -> str:
            return hydra.lib.strings.cat2(first_binding_name(), "_body")
        @lru_cache(1)
        def body_result() -> tuple[int, hydra.core.Term]:
            return process_immediate_subterm(cx, 1, body_prefix(), body_path_prefix(), body)
        @lru_cache(1)
        def new_body() -> hydra.core.Term:
            return hydra.lib.pairs.second(body_result())
        return (counter, cast(hydra.core.Term, hydra.core.TermLet(hydra.core.Let(new_bindings(), new_body()))))
    def rewrite(recurse: Callable[[T0, hydra.core.Term], tuple[T1, hydra.core.Term]], path: frozenlist[hydra.paths.SubtermStep], cx: hydra.graph.Graph, counter: T0, term: hydra.core.Term):
        match term:
            case hydra.core.TermLet():
                @lru_cache(1)
                def recursed() -> tuple[T1, hydra.core.Term]:
                    return recurse(counter, term)
                @lru_cache(1)
                def new_counter() -> T1:
                    return hydra.lib.pairs.first(recursed())
                @lru_cache(1)
                def recursed_term() -> hydra.core.Term:
                    return hydra.lib.pairs.second(recursed())
                def _hoist_recursed_term_body_1(v1):
                    match v1:
                        case hydra.core.TermLet(value=lt2):
                            return process_let_term(cx, new_counter(), path, lt2)
                        case _:
                            return (new_counter(), recursed_term())
                return _hoist_recursed_term_body_1(recursed_term())
            case _:
                return recurse(counter, term)
    return hydra.lib.pairs.second(hydra.rewriting.rewrite_and_fold_term_with_graph_and_path((lambda x1, x2, x3, x4, x5: rewrite(x1, x2, x3, x4, x5)), cx0, 1, term0))
def is_union_elimination(term: hydra.core.Term) -> bool:
    r"""Check if a term is a union elimination (case statement)."""
    match term:
        case hydra.core.TermCases():
            return True
        case _:
            return False
def is_union_elimination_application(term: hydra.core.Term) -> bool:
    r"""Check if a term is an application of a union elimination (case statement applied to an argument)."""
    match term:
        case hydra.core.TermApplication(value=app):
            return is_union_elimination(hydra.strip.deannotate_and_detype_term(app.function))
        case _:
            return False
def update_hoist_state(accessor: hydra.paths.SubtermStep, state: tuple[bool, bool]):
    r"""Update hoisting state when traversing an accessor. State is (atTopLevel, usedAppLHS). Returns updated state."""
    @lru_cache(1)
    def at_top() -> bool:
        return hydra.lib.pairs.first(state)
    @lru_cache(1)
    def used_app() -> bool:
        return hydra.lib.pairs.second(state)
    def _hoist_used_app_body_1(v1):
        match v1:
            case hydra.paths.SubtermStepAnnotatedBody():
                return (True, used_app())
            case hydra.paths.SubtermStepLetBody():
                return (True, used_app())
            case hydra.paths.SubtermStepLetBinding():
                return (True, used_app())
            case hydra.paths.SubtermStepLambdaBody():
                return hydra.lib.logic.if_else(used_app(), (lambda : (False, True)), (lambda : (True, False)))
            case hydra.paths.SubtermStepUnionCasesBranch():
                return hydra.lib.logic.if_else(used_app(), (lambda : (False, True)), (lambda : (True, False)))
            case hydra.paths.SubtermStepUnionCasesDefault():
                return hydra.lib.logic.if_else(used_app(), (lambda : (False, True)), (lambda : (True, False)))
            case hydra.paths.SubtermStepApplicationFunction():
                return hydra.lib.logic.if_else(used_app(), (lambda : (False, True)), (lambda : (True, True)))
            case hydra.paths.SubtermStepApplicationArgument():
                return (False, used_app())
            case _:
                return (False, used_app())
    return hydra.lib.logic.if_else(hydra.lib.logic.not_(at_top()), (lambda : (False, used_app())), (lambda : _hoist_used_app_body_1(accessor)))
def should_hoist_case_statement(path_and_term: tuple[frozenlist[hydra.paths.SubtermStep], hydra.core.Term]) -> bool:
    r"""Predicate for case statement hoisting. Returns True if term is a union elimination (bare case function) or a case statement application (union elimination applied to an argument) AND not at top level. Top level = reachable through annotations, let body/binding, lambda bodies, or ONE app LHS. Once through an app LHS, lambda bodies no longer pass through."""
    @lru_cache(1)
    def path() -> frozenlist[hydra.paths.SubtermStep]:
        return hydra.lib.pairs.first(path_and_term)
    @lru_cache(1)
    def term() -> hydra.core.Term:
        return hydra.lib.pairs.second(path_and_term)
    return hydra.lib.logic.if_else(hydra.lib.logic.not_(hydra.lib.logic.or_(is_union_elimination(term()), is_union_elimination_application(term()))), (lambda : False), (lambda : (final_state := hydra.lib.lists.foldl((lambda st, acc: update_hoist_state(acc, st)), (True, False), path()), hydra.lib.logic.not_(hydra.lib.pairs.first(final_state)))[1]))
def hoist_case_statements(v1: hydra.graph.Graph, v2: hydra.core.Term) -> hydra.core.Term:
    r"""Hoist case statements into local let bindings. This is useful for targets such as Python which only support case statements (match) at the top level. Case statements are hoisted only when they appear at non-top-level positions. Top level = root, or reachable through annotations, let body/binding, lambda bodies, or ONE application LHS. Once through an application LHS, lambda bodies no longer count as pass-through."""
    return hoist_subterms((lambda x1: should_hoist_case_statement(x1)), v1, v2)
def hoist_case_statements_in_graph(bindings: frozenlist[hydra.core.Binding]) -> frozenlist[hydra.core.Binding]:
    r"""Hoist case statements into local let bindings for a list of bindings. This version operates prior to inference and uses an empty type context. It hoists case statements and their applied arguments into let bindings."""
    @lru_cache(1)
    def empty_tx() -> hydra.graph.Graph:
        return hydra.graph.Graph(hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.sets.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.sets.empty())
    @lru_cache(1)
    def term0() -> hydra.core.Term:
        return cast(hydra.core.Term, hydra.core.TermLet(hydra.core.Let(bindings, cast(hydra.core.Term, hydra.core.TermUnit()))))
    @lru_cache(1)
    def term1() -> hydra.core.Term:
        return hoist_case_statements(empty_tx(), term0())
    return hydra.environment.term_as_bindings(term1())
def should_hoist_polymorphic(cx: hydra.graph.Graph, binding: hydra.core.Binding) -> bool:
    r"""Predicate for hoisting polymorphic bindings. Returns True if the binding is polymorphic (has type scheme variables) or if its type uses any type variables from the Graph."""
    return hydra.lib.logic.or_(binding_is_polymorphic(binding), binding_uses_context_type_vars(cx, binding))
def hoist_let_bindings_with_context(is_parent_binding: Callable[[hydra.core.Binding], bool], cx: hydra.graph.Graph, let0: hydra.core.Let) -> hydra.core.Let:
    r"""Transform a let-term by pulling polymorphic let bindings to the top level, using Graph. A binding is hoisted if: (1) It is polymorphic (has non-empty typeSchemeVariables), OR (2) Its type uses type variables from the Graph (i.e., from enclosing type lambdas). Bindings which are already at the top level are not hoisted. If a hoisted binding captures lambda-bound or let-bound variables from an enclosing scope, the binding is wrapped in lambdas for those variables, and references are replaced with applications. If a hoisted binding uses type variables from the context, those type variables are added to the binding's type scheme. Note: we assume that there is no variable shadowing; use hydra.rewriting.unshadowVariables first."""
    return hoist_let_bindings_with_predicate(is_parent_binding, (lambda x1, x2: should_hoist_polymorphic(x1, x2)), cx, let0)
def hoist_polymorphic_let_bindings(is_parent_binding: Callable[[hydra.core.Binding], bool], let0: hydra.core.Let) -> hydra.core.Let:
    r"""Transform a let-term by pulling all polymorphic let bindings to the top level. This is useful to ensure that polymorphic bindings are not nested within other terms, which is unsupported by certain targets such as Java. Polymorphic bindings are those with a non-empty list of type scheme variables. If a hoisted binding captures lambda-bound variables from an enclosing scope, the binding is wrapped in lambdas for those variables, and references are replaced with applications. Note: Assumes no variable shadowing; use hydra.rewriting.unshadowVariables first."""
    @lru_cache(1)
    def empty_cx() -> hydra.graph.Graph:
        return hydra.graph.Graph(hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.sets.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.maps.empty(), hydra.lib.sets.empty())
    return hoist_let_bindings_with_predicate(is_parent_binding, (lambda x1, x2: should_hoist_polymorphic(x1, x2)), empty_cx(), let0)
def is_application_function(acc: hydra.paths.SubtermStep) -> bool:
    match acc:
        case hydra.paths.SubtermStepApplicationFunction():
            return True
        case _:
            return False
def is_lambda_body(acc: hydra.paths.SubtermStep) -> bool:
    match acc:
        case hydra.paths.SubtermStepLambdaBody():
            return True
        case _:
            return False
def normalize_path_for_hoisting(path: frozenlist[hydra.paths.SubtermStep]) -> frozenlist[hydra.paths.SubtermStep]:
    r"""Normalize a path for hoisting by treating immediately-applied lambdas as let bindings. Replaces [applicationFunction, lambdaBody, ...] with [letBody, ...]."""
    def go(remaining: frozenlist[hydra.paths.SubtermStep]) -> frozenlist[hydra.paths.SubtermStep]:
        return hydra.lib.maybes.maybe((lambda : remaining), (lambda uc1: (first := hydra.lib.pairs.first(uc1), after_first := hydra.lib.pairs.second(uc1), hydra.lib.maybes.maybe((lambda : remaining), (lambda uc2: (second := hydra.lib.pairs.first(uc2), rest := hydra.lib.pairs.second(uc2), hydra.lib.logic.if_else(hydra.lib.logic.and_(is_application_function(first), is_lambda_body(second)), (lambda : hydra.lib.lists.cons(cast(hydra.paths.SubtermStep, hydra.paths.SubtermStepLetBody()), go(rest))), (lambda : hydra.lib.lists.cons(first, go(after_first)))))[2]), hydra.lib.lists.uncons(after_first)))[2]), hydra.lib.lists.uncons(remaining))
    return go(path)
