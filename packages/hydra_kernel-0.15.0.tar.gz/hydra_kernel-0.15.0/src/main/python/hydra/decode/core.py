# Note: this is an automatically generated file. Do not edit.
r"""Term decoders for hydra.core."""
from __future__ import annotations
from collections.abc import Callable
from decimal import Decimal
from functools import lru_cache
from hydra.dsl.python import Either, FrozenDict, Left, Maybe, Right, frozenlist
from typing import cast
import hydra.core
import hydra.errors
import hydra.extract.core
import hydra.lib.eithers
import hydra.lib.maps
import hydra.lib.maybes
import hydra.lib.strings
def name(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_name_1(v1):
        match v1:
            case hydra.core.LiteralString(value=s):
                return Right(s)
            case _:
                return Left(hydra.errors.DecodingError("expected string literal"))
    def _hoist_hydra_decode_core_name_2(v1):
        match v1:
            case hydra.core.TermLiteral(value=v):
                return _hoist_hydra_decode_core_name_1(v)
            case _:
                return Left(hydra.errors.DecodingError("expected literal"))
    def _hoist_hydra_decode_core_name_3(cx, v1):
        match v1:
            case hydra.core.TermWrap(value=wrapped_term):
                return hydra.lib.eithers.map((lambda b: hydra.core.Name(b)), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_hydra_decode_core_name_2(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, wrapped_term.body)))
            case _:
                return Left(hydra.errors.DecodingError("expected wrapped type"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_name_3(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def float_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_float_type_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.core.FloatType]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("bigfloat"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.FloatType.BIGFLOAT), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("float32"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.FloatType.FLOAT32), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("float64"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.FloatType.FLOAT64), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_float_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def integer_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_integer_type_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.core.IntegerType]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("bigint"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.BIGINT), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("int8"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.INT8), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("int16"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.INT16), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("int32"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.INT32), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("int64"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.INT64), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("uint8"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.UINT8), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("uint16"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.UINT16), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("uint32"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.UINT32), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("uint64"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.core.IntegerType.UINT64), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_integer_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def literal_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_literal_type_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.core.LiteralType]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("binary"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.LiteralType, hydra.core.LiteralTypeBinary())), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("boolean"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.LiteralType, hydra.core.LiteralTypeBoolean())), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("decimal"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.LiteralType, hydra.core.LiteralTypeDecimal())), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("float"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.LiteralType, hydra.core.LiteralTypeFloat(t))), float_type(cx, input)))), (hydra.core.Name("integer"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.LiteralType, hydra.core.LiteralTypeInteger(t))), integer_type(cx, input)))), (hydra.core.Name("string"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.LiteralType, hydra.core.LiteralTypeString())), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_literal_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type_variable_metadata(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_type_variable_metadata_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("classes", (lambda v12, v2: hydra.extract.core.decode_set((lambda x1, x2: name(x1, x2)), v12, v2)), field_map(), cx), (lambda field_classes: Right(hydra.core.TypeVariableMetadata(field_classes))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_type_variable_metadata_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def float_value(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_float_value_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map():
                    def _hoist_variant_map_1(v12):
                        match v12:
                            case hydra.core.FloatValueBigfloat(value=f):
                                return Right(f)
                            case _:
                                return Left(hydra.errors.DecodingError("expected bigfloat value"))
                    def _hoist_variant_map_2(v12):
                        match v12:
                            case hydra.core.LiteralFloat(value=_match_value):
                                return _hoist_variant_map_1(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected bigfloat literal"))
                    def _hoist_variant_map_3(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_2(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_4(v12):
                        match v12:
                            case hydra.core.FloatValueFloat32(value=f):
                                return Right(f)
                            case _:
                                return Left(hydra.errors.DecodingError("expected float32 value"))
                    def _hoist_variant_map_5(v12):
                        match v12:
                            case hydra.core.LiteralFloat(value=_match_value):
                                return _hoist_variant_map_4(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected float32 literal"))
                    def _hoist_variant_map_6(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_5(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_7(v12):
                        match v12:
                            case hydra.core.FloatValueFloat64(value=f):
                                return Right(f)
                            case _:
                                return Left(hydra.errors.DecodingError("expected float64 value"))
                    def _hoist_variant_map_8(v12):
                        match v12:
                            case hydra.core.LiteralFloat(value=_match_value):
                                return _hoist_variant_map_7(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected float64 literal"))
                    def _hoist_variant_map_9(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_8(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    return hydra.lib.maps.from_list(((hydra.core.Name("bigfloat"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.FloatValue, hydra.core.FloatValueBigfloat(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_3(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("float32"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.FloatValue, hydra.core.FloatValueFloat32(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_6(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("float64"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.FloatValue, hydra.core.FloatValueFloat64(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_9(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input)))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_float_value_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def integer_value(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_integer_value_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map():
                    def _hoist_variant_map_1(v12):
                        match v12:
                            case hydra.core.IntegerValueBigint(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected bigint value"))
                    def _hoist_variant_map_2(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_1(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected bigint literal"))
                    def _hoist_variant_map_3(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_2(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_4(v12):
                        match v12:
                            case hydra.core.IntegerValueInt8(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int8 value"))
                    def _hoist_variant_map_5(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_4(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int8 literal"))
                    def _hoist_variant_map_6(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_5(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_7(v12):
                        match v12:
                            case hydra.core.IntegerValueInt16(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int16 value"))
                    def _hoist_variant_map_8(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_7(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int16 literal"))
                    def _hoist_variant_map_9(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_8(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_10(v12):
                        match v12:
                            case hydra.core.IntegerValueInt32(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int32 value"))
                    def _hoist_variant_map_11(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_10(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int32 literal"))
                    def _hoist_variant_map_12(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_11(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_13(v12):
                        match v12:
                            case hydra.core.IntegerValueInt64(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int64 value"))
                    def _hoist_variant_map_14(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_13(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected int64 literal"))
                    def _hoist_variant_map_15(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_14(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_16(v12):
                        match v12:
                            case hydra.core.IntegerValueUint8(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint8 value"))
                    def _hoist_variant_map_17(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_16(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint8 literal"))
                    def _hoist_variant_map_18(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_17(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_19(v12):
                        match v12:
                            case hydra.core.IntegerValueUint16(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint16 value"))
                    def _hoist_variant_map_20(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_19(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint16 literal"))
                    def _hoist_variant_map_21(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_20(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_22(v12):
                        match v12:
                            case hydra.core.IntegerValueUint32(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint32 value"))
                    def _hoist_variant_map_23(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_22(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint32 literal"))
                    def _hoist_variant_map_24(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_23(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_25(v12):
                        match v12:
                            case hydra.core.IntegerValueUint64(value=i):
                                return Right(i)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint64 value"))
                    def _hoist_variant_map_26(v12):
                        match v12:
                            case hydra.core.LiteralInteger(value=_match_value):
                                return _hoist_variant_map_25(_match_value)
                            case _:
                                return Left(hydra.errors.DecodingError("expected uint64 literal"))
                    def _hoist_variant_map_27(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_26(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    return hydra.lib.maps.from_list(((hydra.core.Name("bigint"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueBigint(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_3(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("int8"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt8(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_6(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("int16"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt16(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_9(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("int32"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt32(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_12(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("int64"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt64(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_15(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("uint8"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint8(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_18(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("uint16"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint16(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_21(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("uint32"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint32(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_24(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("uint64"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint64(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_27(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input)))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_integer_value_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def literal(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_literal_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map():
                    def _hoist_variant_map_1(v12):
                        match v12:
                            case hydra.core.LiteralBinary(value=b):
                                return Right(b)
                            case _:
                                return Left(hydra.errors.DecodingError("expected binary literal"))
                    def _hoist_variant_map_2(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_1(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_3(v12):
                        match v12:
                            case hydra.core.LiteralBoolean(value=b):
                                return Right(b)
                            case _:
                                return Left(hydra.errors.DecodingError("expected boolean literal"))
                    def _hoist_variant_map_4(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_3(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_5(v12):
                        match v12:
                            case hydra.core.LiteralDecimal(value=d):
                                return Right(d)
                            case _:
                                return Left(hydra.errors.DecodingError("expected decimal literal"))
                    def _hoist_variant_map_6(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_5(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_7(v12):
                        match v12:
                            case hydra.core.LiteralString(value=s):
                                return Right(s)
                            case _:
                                return Left(hydra.errors.DecodingError("expected string literal"))
                    def _hoist_variant_map_8(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_7(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    return hydra.lib.maps.from_list(((hydra.core.Name("binary"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Literal, hydra.core.LiteralBinary(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_2(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("boolean"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Literal, hydra.core.LiteralBoolean(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_4(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("decimal"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Literal, hydra.core.LiteralDecimal(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_6(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("float"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Literal, hydra.core.LiteralFloat(t))), float_value(cx, input)))), (hydra.core.Name("integer"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Literal, hydra.core.LiteralInteger(t))), integer_value(cx, input)))), (hydra.core.Name("string"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Literal, hydra.core.LiteralString(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_8(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input)))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_literal_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def projection(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_projection_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("typeName", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_type_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("field", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_field: Right(hydra.core.Projection(field_type_name, field_field))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_projection_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def annotated_term(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_annotated_term_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_body: hydra.lib.eithers.bind(hydra.extract.core.require_field("annotation", (lambda v12, v2: hydra.extract.core.decode_map((lambda x1, x2: name(x1, x2)), (lambda x1, x2: term(x1, x2)), v12, v2)), field_map(), cx), (lambda field_annotation: Right(hydra.core.AnnotatedTerm(field_body, field_annotation))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_annotated_term_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def annotated_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_annotated_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_body: hydra.lib.eithers.bind(hydra.extract.core.require_field("annotation", (lambda v12, v2: hydra.extract.core.decode_map((lambda x1, x2: name(x1, x2)), (lambda x1, x2: term(x1, x2)), v12, v2)), field_map(), cx), (lambda field_annotation: Right(hydra.core.AnnotatedType(field_body, field_annotation))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_annotated_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def application(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_application_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("function", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_function: hydra.lib.eithers.bind(hydra.extract.core.require_field("argument", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_argument: Right(hydra.core.Application(field_function, field_argument))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_application_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def application_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_application_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("function", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_function: hydra.lib.eithers.bind(hydra.extract.core.require_field("argument", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_argument: Right(hydra.core.ApplicationType(field_function, field_argument))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_application_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def binding(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_binding_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("name", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("term", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_term: hydra.lib.eithers.bind(hydra.extract.core.require_field("typeScheme", (lambda v12, v2: hydra.extract.core.decode_maybe((lambda x1, x2: type_scheme(x1, x2)), v12, v2)), field_map(), cx), (lambda field_type_scheme: Right(hydra.core.Binding(field_name, field_term, field_type_scheme))))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_binding_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def case_statement(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_case_statement_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("typeName", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_type_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("default", (lambda v12, v2: hydra.extract.core.decode_maybe((lambda x1, x2: term(x1, x2)), v12, v2)), field_map(), cx), (lambda field_default: hydra.lib.eithers.bind(hydra.extract.core.require_field("cases", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: field(x1, x2)), v12, v2)), field_map(), cx), (lambda field_cases: Right(hydra.core.CaseStatement(field_type_name, field_default, field_cases))))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_case_statement_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def either_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_either_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("left", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_left: hydra.lib.eithers.bind(hydra.extract.core.require_field("right", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_right: Right(hydra.core.EitherType(field_left, field_right))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_either_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def field(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_field_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("name", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("term", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_term: Right(hydra.core.Field(field_name, field_term))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_field_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def field_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_field_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("name", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("type", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_type: Right(hydra.core.FieldType(field_name, field_type))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_field_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def forall_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_forall_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("parameter", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_parameter: hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_body: Right(hydra.core.ForallType(field_parameter, field_body))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_forall_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def function_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_function_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("domain", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_domain: hydra.lib.eithers.bind(hydra.extract.core.require_field("codomain", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_codomain: Right(hydra.core.FunctionType(field_domain, field_codomain))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_function_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def injection(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_injection_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("typeName", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_type_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("field", (lambda x1, x2: field(x1, x2)), field_map(), cx), (lambda field_field: Right(hydra.core.Injection(field_type_name, field_field))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_injection_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def lambda_(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_lambda_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("parameter", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_parameter: hydra.lib.eithers.bind(hydra.extract.core.require_field("domain", (lambda v12, v2: hydra.extract.core.decode_maybe((lambda x1, x2: type(x1, x2)), v12, v2)), field_map(), cx), (lambda field_domain: hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_body: Right(hydra.core.Lambda(field_parameter, field_domain, field_body))))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_lambda_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def let(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_let_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("bindings", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: binding(x1, x2)), v12, v2)), field_map(), cx), (lambda field_bindings: hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_body: Right(hydra.core.Let(field_bindings, field_body))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_let_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def map_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_map_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("keys", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_keys: hydra.lib.eithers.bind(hydra.extract.core.require_field("values", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_values: Right(hydra.core.MapType(field_keys, field_values))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_map_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def pair_type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_pair_type_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("first", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_first: hydra.lib.eithers.bind(hydra.extract.core.require_field("second", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_second: Right(hydra.core.PairType(field_first, field_second))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_pair_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def record(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_record_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("typeName", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_type_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("fields", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: field(x1, x2)), v12, v2)), field_map(), cx), (lambda field_fields: Right(hydra.core.Record(field_type_name, field_fields))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_record_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def term(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_term_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.core.Term]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("annotated"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermAnnotated(t))), annotated_term(cx, input)))), (hydra.core.Name("application"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermApplication(t))), application(cx, input)))), (hydra.core.Name("cases"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermCases(t))), case_statement(cx, input)))), (hydra.core.Name("either"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermEither(t))), hydra.extract.core.decode_either((lambda x1, x2: term(x1, x2)), (lambda x1, x2: term(x1, x2)), cx, input)))), (hydra.core.Name("inject"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermInject(t))), injection(cx, input)))), (hydra.core.Name("lambda"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermLambda(t))), lambda_(cx, input)))), (hydra.core.Name("let"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermLet(t))), let(cx, input)))), (hydra.core.Name("list"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermList(t))), hydra.extract.core.decode_list((lambda x1, x2: term(x1, x2)), cx, input)))), (hydra.core.Name("literal"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermLiteral(t))), literal(cx, input)))), (hydra.core.Name("map"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermMap(t))), hydra.extract.core.decode_map((lambda x1, x2: term(x1, x2)), (lambda x1, x2: term(x1, x2)), cx, input)))), (hydra.core.Name("maybe"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermMaybe(t))), hydra.extract.core.decode_maybe((lambda x1, x2: term(x1, x2)), cx, input)))), (hydra.core.Name("pair"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermPair(t))), hydra.extract.core.decode_pair((lambda x1, x2: term(x1, x2)), (lambda x1, x2: term(x1, x2)), cx, input)))), (hydra.core.Name("project"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermProject(t))), projection(cx, input)))), (hydra.core.Name("record"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermRecord(t))), record(cx, input)))), (hydra.core.Name("set"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermSet(t))), hydra.extract.core.decode_set((lambda x1, x2: term(x1, x2)), cx, input)))), (hydra.core.Name("typeApplication"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermTypeApplication(t))), type_application_term(cx, input)))), (hydra.core.Name("typeLambda"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermTypeLambda(t))), type_lambda(cx, input)))), (hydra.core.Name("unit"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermUnit())), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("unwrap"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermUnwrap(t))), name(cx, input)))), (hydra.core.Name("variable"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermVariable(t))), name(cx, input)))), (hydra.core.Name("wrap"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Term, hydra.core.TermWrap(t))), wrapped_term(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_term_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_type_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.core.Type]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("annotated"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeAnnotated(t))), annotated_type(cx, input)))), (hydra.core.Name("application"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeApplication(t))), application_type(cx, input)))), (hydra.core.Name("either"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeEither(t))), either_type(cx, input)))), (hydra.core.Name("forall"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeForall(t))), forall_type(cx, input)))), (hydra.core.Name("function"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeFunction(t))), function_type(cx, input)))), (hydra.core.Name("list"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeList(t))), type(cx, input)))), (hydra.core.Name("literal"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeLiteral(t))), literal_type(cx, input)))), (hydra.core.Name("map"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeMap(t))), map_type(cx, input)))), (hydra.core.Name("maybe"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeMaybe(t))), type(cx, input)))), (hydra.core.Name("pair"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypePair(t))), pair_type(cx, input)))), (hydra.core.Name("record"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeRecord(t))), hydra.extract.core.decode_list((lambda x1, x2: field_type(x1, x2)), cx, input)))), (hydra.core.Name("set"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeSet(t))), type(cx, input)))), (hydra.core.Name("union"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeUnion(t))), hydra.extract.core.decode_list((lambda x1, x2: field_type(x1, x2)), cx, input)))), (hydra.core.Name("unit"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeUnit())), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("variable"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeVariable(t))), name(cx, input)))), (hydra.core.Name("void"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeVoid())), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("wrap"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.core.Type, hydra.core.TypeWrap(t))), type(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_type_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type_application_term(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_type_application_term_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_body: hydra.lib.eithers.bind(hydra.extract.core.require_field("type", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_type: Right(hydra.core.TypeApplicationTerm(field_body, field_type))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_type_application_term_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type_lambda(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_type_lambda_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("parameter", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_parameter: hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_body: Right(hydra.core.TypeLambda(field_parameter, field_body))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_type_lambda_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type_scheme(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_type_scheme_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("variables", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: name(x1, x2)), v12, v2)), field_map(), cx), (lambda field_variables: hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: type(x1, x2)), field_map(), cx), (lambda field_body: hydra.lib.eithers.bind(hydra.extract.core.require_field("constraints", (lambda v12, v2: hydra.extract.core.decode_maybe((lambda v13, v22: hydra.extract.core.decode_map((lambda x1, x2: name(x1, x2)), (lambda x1, x2: type_variable_metadata(x1, x2)), v13, v22)), v12, v2)), field_map(), cx), (lambda field_constraints: Right(hydra.core.TypeScheme(field_variables, field_body, field_constraints))))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_type_scheme_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def wrapped_term(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_core_wrapped_term_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("typeName", (lambda x1, x2: name(x1, x2)), field_map(), cx), (lambda field_type_name: hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: term(x1, x2)), field_map(), cx), (lambda field_body: Right(hydra.core.WrappedTerm(field_type_name, field_body))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_core_wrapped_term_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
