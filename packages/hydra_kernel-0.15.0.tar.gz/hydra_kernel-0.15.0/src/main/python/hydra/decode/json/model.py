# Note: this is an automatically generated file. Do not edit.
r"""Term decoders for hydra.json.model."""
from __future__ import annotations
from collections.abc import Callable
from decimal import Decimal
from functools import lru_cache
from hydra.dsl.python import Either, FrozenDict, Left, Right, frozenlist
from typing import cast
import hydra.core
import hydra.errors
import hydra.extract.core
import hydra.json.model
import hydra.lib.eithers
import hydra.lib.maps
import hydra.lib.maybes
import hydra.lib.strings
def value(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_json_model_value_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map():
                    def _hoist_variant_map_1(v12):
                        match v12:
                            case hydra.core.LiteralBoolean(value=b):
                                return Right(b)
                            case _:
                                return Left(hydra.errors.DecodingError("expected boolean literal"))
                    def _hoist_variant_map_2(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_1(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_3(v12):
                        match v12:
                            case hydra.core.LiteralDecimal(value=d):
                                return Right(d)
                            case _:
                                return Left(hydra.errors.DecodingError("expected decimal literal"))
                    def _hoist_variant_map_4(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_3(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_5(v12):
                        match v12:
                            case hydra.core.LiteralString(value=s):
                                return Right(s)
                            case _:
                                return Left(hydra.errors.DecodingError("expected string literal"))
                    def _hoist_variant_map_6(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_5(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    def _hoist_variant_map_7(v12):
                        match v12:
                            case hydra.core.LiteralString(value=s):
                                return Right(s)
                            case _:
                                return Left(hydra.errors.DecodingError("expected string literal"))
                    def _hoist_variant_map_8(v12):
                        match v12:
                            case hydra.core.TermLiteral(value=v):
                                return _hoist_variant_map_7(v)
                            case _:
                                return Left(hydra.errors.DecodingError("expected literal"))
                    return hydra.lib.maps.from_list(((hydra.core.Name("array"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.json.model.Value, hydra.json.model.ValueArray(t))), hydra.extract.core.decode_list((lambda x1, x2: value(x1, x2)), cx, input)))), (hydra.core.Name("boolean"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.json.model.Value, hydra.json.model.ValueBoolean(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_2(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("null"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.json.model.Value, hydra.json.model.ValueNull())), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("number"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.json.model.Value, hydra.json.model.ValueNumber(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_4(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input))))), (hydra.core.Name("object"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.json.model.Value, hydra.json.model.ValueObject(t))), hydra.extract.core.decode_map((lambda cx2, raw2: hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_6(stripped2)), hydra.extract.core.strip_with_decoding_error(cx2, raw2))), (lambda x1, x2: value(x1, x2)), cx, input)))), (hydra.core.Name("string"), (lambda input: hydra.lib.eithers.map((lambda t: cast(hydra.json.model.Value, hydra.json.model.ValueString(t))), hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_variant_map_8(stripped2)), hydra.extract.core.strip_with_decoding_error(cx, input)))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_json_model_value_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
