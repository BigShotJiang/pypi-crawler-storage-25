# Note: this is an automatically generated file. Do not edit.
r"""Term decoders for hydra.typing."""
from __future__ import annotations
from collections.abc import Callable
from functools import lru_cache
from hydra.dsl.python import Either, FrozenDict, Left, Maybe, Right, frozenlist
from typing import TypeVar, cast
import hydra.core
import hydra.decode.context
import hydra.decode.core
import hydra.errors
import hydra.extract.core
import hydra.lib.eithers
import hydra.typing
T0 = TypeVar("T0")
def function_structure(env: Callable[[hydra.graph.Graph, hydra.core.Term], Either[hydra.errors.DecodingError, T0]], cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_typing_function_structure_1(cx, env, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("typeParams", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: hydra.decode.core.name(x1, x2)), v12, v2)), field_map(), cx), (lambda field_type_params: hydra.lib.eithers.bind(hydra.extract.core.require_field("params", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: hydra.decode.core.name(x1, x2)), v12, v2)), field_map(), cx), (lambda field_params: hydra.lib.eithers.bind(hydra.extract.core.require_field("bindings", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: hydra.decode.core.binding(x1, x2)), v12, v2)), field_map(), cx), (lambda field_bindings: hydra.lib.eithers.bind(hydra.extract.core.require_field("body", (lambda x1, x2: hydra.decode.core.term(x1, x2)), field_map(), cx), (lambda field_body: hydra.lib.eithers.bind(hydra.extract.core.require_field("domains", (lambda v12, v2: hydra.extract.core.decode_list((lambda x1, x2: hydra.decode.core.type(x1, x2)), v12, v2)), field_map(), cx), (lambda field_domains: hydra.lib.eithers.bind(hydra.extract.core.require_field("codomain", (lambda v12, v2: hydra.extract.core.decode_maybe((lambda x1, x2: hydra.decode.core.type(x1, x2)), v12, v2)), field_map(), cx), (lambda field_codomain: hydra.lib.eithers.bind(hydra.extract.core.require_field("environment", env, field_map(), cx), (lambda field_environment: Right(hydra.typing.FunctionStructure(field_type_params, field_params, field_bindings, field_body, field_domains, field_codomain, field_environment))))))))))))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_typing_function_structure_1(cx, env, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type_subst(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_typing_type_subst_1(cx, v1):
        match v1:
            case hydra.core.TermWrap(value=wrapped_term):
                return hydra.lib.eithers.map((lambda b: hydra.typing.TypeSubst(b)), hydra.extract.core.decode_map((lambda x1, x2: hydra.decode.core.name(x1, x2)), (lambda x1, x2: hydra.decode.core.type(x1, x2)), cx, wrapped_term.body))
            case _:
                return Left(hydra.errors.DecodingError("expected wrapped type"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_typing_type_subst_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def inference_result(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_typing_inference_result_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("term", (lambda x1, x2: hydra.decode.core.term(x1, x2)), field_map(), cx), (lambda field_term: hydra.lib.eithers.bind(hydra.extract.core.require_field("type", (lambda x1, x2: hydra.decode.core.type(x1, x2)), field_map(), cx), (lambda field_type: hydra.lib.eithers.bind(hydra.extract.core.require_field("subst", (lambda x1, x2: type_subst(x1, x2)), field_map(), cx), (lambda field_subst: hydra.lib.eithers.bind(hydra.extract.core.require_field("classConstraints", (lambda v12, v2: hydra.extract.core.decode_map((lambda x1, x2: hydra.decode.core.name(x1, x2)), (lambda x1, x2: hydra.decode.core.type_variable_metadata(x1, x2)), v12, v2)), field_map(), cx), (lambda field_class_constraints: hydra.lib.eithers.bind(hydra.extract.core.require_field("context", (lambda x1, x2: hydra.decode.context.context(x1, x2)), field_map(), cx), (lambda field_context: Right(hydra.typing.InferenceResult(field_term, field_type, field_subst, field_class_constraints, field_context))))))))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_typing_inference_result_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def term_subst(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_typing_term_subst_1(cx, v1):
        match v1:
            case hydra.core.TermWrap(value=wrapped_term):
                return hydra.lib.eithers.map((lambda b: hydra.typing.TermSubst(b)), hydra.extract.core.decode_map((lambda x1, x2: hydra.decode.core.name(x1, x2)), (lambda x1, x2: hydra.decode.core.term(x1, x2)), cx, wrapped_term.body))
            case _:
                return Left(hydra.errors.DecodingError("expected wrapped type"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_typing_term_subst_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type_constraint(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_typing_type_constraint_1(cx, v1):
        match v1:
            case hydra.core.TermRecord(value=record):
                @lru_cache(1)
                def field_map() -> FrozenDict[hydra.core.Name, hydra.core.Term]:
                    return hydra.extract.core.to_field_map(record)
                def _hoist_field_map_body_1(v12):
                    match v12:
                        case hydra.core.LiteralString(value=s):
                            return Right(s)
                        case _:
                            return Left(hydra.errors.DecodingError("expected string literal"))
                def _hoist_field_map_body_2(v12):
                    match v12:
                        case hydra.core.TermLiteral(value=v):
                            return _hoist_field_map_body_1(v)
                        case _:
                            return Left(hydra.errors.DecodingError("expected literal"))
                return hydra.lib.eithers.bind(hydra.extract.core.require_field("left", (lambda x1, x2: hydra.decode.core.type(x1, x2)), field_map(), cx), (lambda field_left: hydra.lib.eithers.bind(hydra.extract.core.require_field("right", (lambda x1, x2: hydra.decode.core.type(x1, x2)), field_map(), cx), (lambda field_right: hydra.lib.eithers.bind(hydra.extract.core.require_field("comment", (lambda cx2, raw2: hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped2: _hoist_field_map_body_2(stripped2)), hydra.extract.core.strip_with_decoding_error(cx2, raw2))), field_map(), cx), (lambda field_comment: Right(hydra.typing.TypeConstraint(field_left, field_right, field_comment))))))))
            case _:
                return Left(hydra.errors.DecodingError("expected record"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_typing_type_constraint_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
