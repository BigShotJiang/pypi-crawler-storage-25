# Note: this is an automatically generated file. Do not edit.
r"""Term decoders for hydra.variants."""
from __future__ import annotations
from collections.abc import Callable
from functools import lru_cache
from hydra.dsl.python import Either, Left
from typing import cast
import hydra.core
import hydra.errors
import hydra.extract.core
import hydra.lib.eithers
import hydra.lib.maps
import hydra.lib.maybes
import hydra.lib.strings
import hydra.variants
def elimination_variant(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_variants_elimination_variant_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.variants.EliminationVariant]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("record"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.EliminationVariant.RECORD), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("union"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.EliminationVariant.UNION), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("wrap"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.EliminationVariant.WRAP), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_variants_elimination_variant_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def function_variant(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_variants_function_variant_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.variants.FunctionVariant]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("elimination"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.FunctionVariant.ELIMINATION), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("lambda"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.FunctionVariant.LAMBDA), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_variants_function_variant_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def literal_variant(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_variants_literal_variant_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.variants.LiteralVariant]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("binary"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.LiteralVariant.BINARY), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("boolean"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.LiteralVariant.BOOLEAN), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("decimal"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.LiteralVariant.DECIMAL), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("float"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.LiteralVariant.FLOAT), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("integer"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.LiteralVariant.INTEGER), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("string"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.LiteralVariant.STRING), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_variants_literal_variant_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def term_variant(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_variants_term_variant_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.variants.TermVariant]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("annotated"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.ANNOTATED), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("application"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.APPLICATION), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("cases"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.CASES), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("either"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.EITHER), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("inject"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.INJECT), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("lambda"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.LAMBDA), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("let"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.LET), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("list"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.LIST), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("literal"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.LITERAL), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("map"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.MAP), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("maybe"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.MAYBE), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("pair"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.PAIR), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("project"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.PROJECT), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("record"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.RECORD), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("set"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.SET), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("typeApplication"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.TYPE_APPLICATION), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("typeLambda"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.TYPE_LAMBDA), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("unit"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.UNIT), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("unwrap"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.UNWRAP), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("variable"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.VARIABLE), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("wrap"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TermVariant.WRAP), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_variants_term_variant_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
def type_variant(cx: hydra.graph.Graph, raw: hydra.core.Term):
    def _hoist_hydra_decode_variants_type_variant_1(cx, v1):
        match v1:
            case hydra.core.TermInject(value=inj):
                field = inj.field
                fname = field.name
                fterm = field.term
                @lru_cache(1)
                def variant_map() -> FrozenDict[hydra.core.Name, Callable[[hydra.core.Term], Either[hydra.errors.DecodingError, hydra.variants.TypeVariant]]]:
                    return hydra.lib.maps.from_list(((hydra.core.Name("annotated"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.ANNOTATED), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("application"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.APPLICATION), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("either"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.EITHER), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("forall"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.FORALL), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("function"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.FUNCTION), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("list"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.LIST), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("literal"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.LITERAL), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("map"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.MAP), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("maybe"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.MAYBE), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("pair"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.PAIR), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("record"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.RECORD), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("set"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.SET), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("union"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.UNION), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("unit"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.UNIT), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("variable"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.VARIABLE), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("void"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.VOID), hydra.extract.core.decode_unit(cx, input)))), (hydra.core.Name("wrap"), (lambda input: hydra.lib.eithers.map((lambda t: hydra.variants.TypeVariant.WRAP), hydra.extract.core.decode_unit(cx, input))))))
                return hydra.lib.maybes.maybe((lambda : Left(hydra.errors.DecodingError(hydra.lib.strings.cat(("no such field ", fname.value, " in union"))))), (lambda f: f(fterm)), hydra.lib.maps.lookup(fname, variant_map()))
            case _:
                return Left(hydra.errors.DecodingError("expected union"))
    return hydra.lib.eithers.either((lambda err: Left(err)), (lambda stripped: _hoist_hydra_decode_variants_type_variant_1(cx, stripped)), hydra.extract.core.strip_with_decoding_error(cx, raw))
