# Note: this is an automatically generated file. Do not edit.
r"""Evaluation-level implementations of Map functions for the Hydra interpreter."""
from __future__ import annotations
from collections.abc import Callable
from functools import lru_cache
from hydra.dsl.python import Either, FrozenDict, Left, Nothing, Right
from typing import TypeVar, cast
import hydra.core
import hydra.errors
import hydra.lib.lists
import hydra.lib.maps
import hydra.lib.pairs
import hydra.show.core
T0 = TypeVar("T0")
T1 = TypeVar("T1")
T2 = TypeVar("T2")
def alter(cx: T0, g: T1, fun_term: hydra.core.Term, key_term: hydra.core.Term, map_term: hydra.core.Term) -> Either[hydra.errors.Error, hydra.core.Term]:
    r"""Interpreter-friendly alter for Map terms."""
    match map_term:
        case hydra.core.TermMap(value=m):
            @lru_cache(1)
            def current_val() -> Maybe[hydra.core.Term]:
                return hydra.lib.maps.lookup(key_term, m)
            @lru_cache(1)
            def new_val() -> hydra.core.Term:
                return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(fun_term, cast(hydra.core.Term, hydra.core.TermMaybe(current_val())))))
            return Right(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maybes.maybe"))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maps.delete"))), key_term))), map_term)))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("newV"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maps.insert"))), key_term))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("newV")))))), map_term))))))))), new_val()))))
        case _:
            return Left(cast(hydra.errors.Error, hydra.errors.ErrorExtraction(cast(hydra.errors.ExtractionError, hydra.errors.ExtractionErrorUnexpectedShape(hydra.errors.UnexpectedShapeError("map value", hydra.show.core.term(map_term)))))))
def bimap(cx: T0, g: T1, key_fun: hydra.core.Term, val_fun: hydra.core.Term, map_term: hydra.core.Term) -> Either[hydra.errors.Error, hydra.core.Term]:
    r"""Interpreter-friendly bimap for Map terms."""
    match map_term:
        case hydra.core.TermMap(value=m):
            @lru_cache(1)
            def pairs() -> frozenlist[tuple[hydra.core.Term, hydra.core.Term]]:
                return hydra.lib.maps.to_list(m)
            return Right(cast(hydra.core.Term, hydra.core.TermMap(hydra.lib.maps.from_list(hydra.lib.lists.map((lambda p: (k := hydra.lib.pairs.first(p), v := hydra.lib.pairs.second(p), (cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(key_fun, k))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(val_fun, v)))))[2]), pairs())))))
        case _:
            return Left(cast(hydra.errors.Error, hydra.errors.ErrorExtraction(cast(hydra.errors.ExtractionError, hydra.errors.ExtractionErrorUnexpectedShape(hydra.errors.UnexpectedShapeError("map value", hydra.show.core.term(map_term)))))))
def filter(cx: T0, g: T1, val_pred: hydra.core.Term, map_term: hydra.core.Term) -> Either[hydra.errors.Error, hydra.core.Term]:
    r"""Interpreter-friendly filter for Map terms."""
    match map_term:
        case hydra.core.TermMap(value=m):
            @lru_cache(1)
            def pairs() -> frozenlist[tuple[hydra.core.Term, hydra.core.Term]]:
                return hydra.lib.maps.to_list(m)
            return Right(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maps.fromList"))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.lists.concat"))), cast(hydra.core.Term, hydra.core.TermList(hydra.lib.lists.map((lambda p: (v := hydra.lib.pairs.second(p), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.logic.ifElse"))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(val_pred, v)))))), cast(hydra.core.Term, hydra.core.TermList(hydra.lib.lists.pure(cast(hydra.core.Term, hydra.core.TermPair((hydra.lib.pairs.first(p), v))))))))), cast(hydra.core.Term, hydra.core.TermList(()))))))[1]), pairs()))))))))))
        case _:
            return Left(cast(hydra.errors.Error, hydra.errors.ErrorExtraction(cast(hydra.errors.ExtractionError, hydra.errors.ExtractionErrorUnexpectedShape(hydra.errors.UnexpectedShapeError("map value", hydra.show.core.term(map_term)))))))
def filter_with_key(cx: T0, g: T1, pred: hydra.core.Term, map_term: hydra.core.Term) -> Either[hydra.errors.Error, hydra.core.Term]:
    r"""Interpreter-friendly filterWithKey for Map terms."""
    match map_term:
        case hydra.core.TermMap(value=m):
            @lru_cache(1)
            def pairs() -> frozenlist[tuple[hydra.core.Term, hydra.core.Term]]:
                return hydra.lib.maps.to_list(m)
            return Right(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maps.fromList"))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.lists.concat"))), cast(hydra.core.Term, hydra.core.TermList(hydra.lib.lists.map((lambda p: (k := hydra.lib.pairs.first(p), v := hydra.lib.pairs.second(p), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.logic.ifElse"))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(pred, k))), v)))))), cast(hydra.core.Term, hydra.core.TermList(hydra.lib.lists.pure(cast(hydra.core.Term, hydra.core.TermPair((k, v))))))))), cast(hydra.core.Term, hydra.core.TermList(()))))))[2]), pairs()))))))))))
        case _:
            return Left(cast(hydra.errors.Error, hydra.errors.ErrorExtraction(cast(hydra.errors.ExtractionError, hydra.errors.ExtractionErrorUnexpectedShape(hydra.errors.UnexpectedShapeError("map value", hydra.show.core.term(map_term)))))))
def find_with_default(cx: T0, g: T1, default_term: hydra.core.Term, key_term: hydra.core.Term, map_term: hydra.core.Term) -> Either[T2, hydra.core.Term]:
    r"""Interpreter-friendly findWithDefault for Map terms."""
    return Right(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maybes.fromMaybe"))), default_term))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maps.lookup"))), key_term))), map_term)))))))
def map(cx: T0, g: T1, val_fun: hydra.core.Term, map_term: hydra.core.Term) -> Either[hydra.errors.Error, hydra.core.Term]:
    r"""Interpreter-friendly map for Map terms."""
    match map_term:
        case hydra.core.TermMap(value=m):
            @lru_cache(1)
            def pairs() -> frozenlist[tuple[hydra.core.Term, hydra.core.Term]]:
                return hydra.lib.maps.to_list(m)
            return Right(cast(hydra.core.Term, hydra.core.TermMap(hydra.lib.maps.from_list(hydra.lib.lists.map((lambda p: (k := hydra.lib.pairs.first(p), v := hydra.lib.pairs.second(p), (k, cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(val_fun, v)))))[2]), pairs())))))
        case _:
            return Left(cast(hydra.errors.Error, hydra.errors.ErrorExtraction(cast(hydra.errors.ExtractionError, hydra.errors.ExtractionErrorUnexpectedShape(hydra.errors.UnexpectedShapeError("map value", hydra.show.core.term(map_term)))))))
def map_keys(cx: T0, g: T1, key_fun: hydra.core.Term, map_term: hydra.core.Term) -> Either[hydra.errors.Error, hydra.core.Term]:
    r"""Interpreter-friendly mapKeys for Map terms."""
    match map_term:
        case hydra.core.TermMap(value=m):
            @lru_cache(1)
            def pairs() -> frozenlist[tuple[hydra.core.Term, hydra.core.Term]]:
                return hydra.lib.maps.to_list(m)
            return Right(cast(hydra.core.Term, hydra.core.TermMap(hydra.lib.maps.from_list(hydra.lib.lists.map((lambda p: (k := hydra.lib.pairs.first(p), v := hydra.lib.pairs.second(p), (cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(key_fun, k))), v))[2]), pairs())))))
        case _:
            return Left(cast(hydra.errors.Error, hydra.errors.ErrorExtraction(cast(hydra.errors.ExtractionError, hydra.errors.ExtractionErrorUnexpectedShape(hydra.errors.UnexpectedShapeError("map value", hydra.show.core.term(map_term)))))))
