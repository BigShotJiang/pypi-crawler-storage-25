# Note: this is an automatically generated file. Do not edit.
r"""Functions dealing with arguments and arity."""
from __future__ import annotations
from functools import lru_cache
from hydra.dsl.python import frozenlist
from typing import cast
import hydra.core
import hydra.graph
import hydra.lib.lists
import hydra.lib.math
def type_arity(v1: hydra.core.Type) -> int:
    r"""Find the arity (expected number of arguments) of a type."""
    match v1:
        case hydra.core.TypeAnnotated(value=arg_):
            return type_arity(arg_.body)
        case hydra.core.TypeApplication(value=arg_2):
            return type_arity(arg_2.function)
        case hydra.core.TypeForall(value=arg_3):
            return type_arity(arg_3.body)
        case hydra.core.TypeFunction(value=f):
            return hydra.lib.math.add(1, type_arity(f.codomain))
        case _:
            return 0
def primitive_arity(arg_: hydra.graph.Primitive) -> int:
    r"""Find the arity (expected number of arguments) of a primitive constant or function."""
    return type_arity(arg_.type_scheme.body)
def term_arity(v1: hydra.core.Term) -> int:
    r"""Find the arity (expected number of arguments) of a term."""
    match v1:
        case hydra.core.TermApplication(value=arg_):
            return hydra.lib.math.sub(term_arity(arg_.function), 1)
        case hydra.core.TermCases():
            return 1
        case hydra.core.TermLambda(value=arg_2):
            return hydra.lib.math.add(1, term_arity(arg_2.body))
        case hydra.core.TermProject():
            return 1
        case hydra.core.TermUnwrap():
            return 1
        case _:
            return 0
def type_scheme_arity(arg_: hydra.core.TypeScheme) -> int:
    r"""Find the arity (expected number of arguments) of a type scheme."""
    return type_arity(arg_.body)
def uncurry_type(t: hydra.core.Type) -> frozenlist[hydra.core.Type]:
    r"""Uncurry a type expression into a list of types, turning a function type a -> b into cons a (uncurryType b)."""
    match t:
        case hydra.core.TypeAnnotated(value=arg_):
            return uncurry_type(arg_.body)
        case hydra.core.TypeApplication(value=arg_2):
            return uncurry_type(arg_2.function)
        case hydra.core.TypeForall(value=arg_3):
            return uncurry_type(arg_3.body)
        case hydra.core.TypeFunction(value=ft):
            return hydra.lib.lists.cons(ft.domain, uncurry_type(ft.codomain))
        case _:
            return (t,)
