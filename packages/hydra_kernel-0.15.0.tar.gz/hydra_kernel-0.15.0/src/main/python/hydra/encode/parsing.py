# Note: this is an automatically generated file. Do not edit.
r"""Term encoders for hydra.parsing."""
from __future__ import annotations
from collections.abc import Callable
from functools import lru_cache
from typing import TypeVar, cast
import hydra.core
import hydra.parsing
T0 = TypeVar("T0")
def parse_error(x: hydra.parsing.ParseError) -> hydra.core.Term:
    return cast(hydra.core.Term, hydra.core.TermRecord(hydra.core.Record(hydra.core.Name("hydra.parsing.ParseError"), (hydra.core.Field(hydra.core.Name("message"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(x.message))))), hydra.core.Field(hydra.core.Name("remainder"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(x.remainder)))))))))
def parse_success(a: Callable[[T0], hydra.core.Term], x: hydra.parsing.ParseSuccess[T0]) -> hydra.core.Term:
    return cast(hydra.core.Term, hydra.core.TermRecord(hydra.core.Record(hydra.core.Name("hydra.parsing.ParseSuccess"), (hydra.core.Field(hydra.core.Name("value"), a(x.value)), hydra.core.Field(hydra.core.Name("remainder"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(x.remainder)))))))))
def parse_result(a: Callable[[T0], hydra.core.Term]):
    def _hoist_hydra_encode_parsing_parse_result_1(a, v1):
        match v1:
            case hydra.parsing.ParseResultSuccess(value=y):
                return cast(hydra.core.Term, hydra.core.TermInject(hydra.core.Injection(hydra.core.Name("hydra.parsing.ParseResult"), hydra.core.Field(hydra.core.Name("success"), parse_success(a, y)))))
            case hydra.parsing.ParseResultFailure(value=y):
                return cast(hydra.core.Term, hydra.core.TermInject(hydra.core.Injection(hydra.core.Name("hydra.parsing.ParseResult"), hydra.core.Field(hydra.core.Name("failure"), parse_error(y)))))
            case _:
                raise AssertionError("Unreachable: all variants handled")
    return _hoist_hydra_encode_parsing_parse_result_1(a)
