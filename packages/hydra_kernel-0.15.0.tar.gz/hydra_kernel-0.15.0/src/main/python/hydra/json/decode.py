# Note: this is an automatically generated file. Do not edit.
r"""JSON decoding for Hydra terms. Converts JSON Values to Terms using Either for error handling."""
from __future__ import annotations
from collections.abc import Callable
from decimal import Decimal
from functools import lru_cache
from hydra.dsl.python import Either, FrozenDict, Just, Left, Maybe, Nothing, Right, frozenlist
from typing import cast
import hydra.core
import hydra.json.model
import hydra.lib.eithers
import hydra.lib.equality
import hydra.lib.lists
import hydra.lib.literals
import hydra.lib.logic
import hydra.lib.maps
import hydra.lib.maybes
import hydra.lib.sets
import hydra.lib.strings
import hydra.show.core
import hydra.strip
def parse_special_float(s: str) -> Maybe[float]:
    r"""Parse an IEEE sentinel string (NaN, Infinity, -Infinity, -0.0) to a float64. Returns Nothing for unrecognized strings."""
    return hydra.lib.logic.if_else(hydra.lib.logic.or_(hydra.lib.equality.equal(s, "NaN"), hydra.lib.logic.or_(hydra.lib.equality.equal(s, "Infinity"), hydra.lib.logic.or_(hydra.lib.equality.equal(s, "-Infinity"), hydra.lib.equality.equal(s, "-0.0")))), (lambda : hydra.lib.literals.read_float64(s)), (lambda : Nothing()))
def parse_special_float32(s: str) -> Maybe[float]:
    r"""Parse an IEEE sentinel string (NaN, Infinity, -Infinity, -0.0) to a float32. Returns Nothing for unrecognized strings."""
    return hydra.lib.logic.if_else(hydra.lib.logic.or_(hydra.lib.equality.equal(s, "NaN"), hydra.lib.logic.or_(hydra.lib.equality.equal(s, "Infinity"), hydra.lib.logic.or_(hydra.lib.equality.equal(s, "-Infinity"), hydra.lib.equality.equal(s, "-0.0")))), (lambda : hydra.lib.literals.read_float32(s)), (lambda : Nothing()))
def decode_float(ft: hydra.core.FloatType, value: hydra.json.model.Value):
    def _hoist_hydra_json_decode_decode_float_1(v1):
        match v1:
            case hydra.json.model.ValueNumber(value=n):
                return Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralFloat(cast(hydra.core.FloatValue, hydra.core.FloatValueBigfloat(hydra.lib.literals.float64_to_bigfloat(hydra.lib.literals.decimal_to_float64(n)))))))))
            case hydra.json.model.ValueString(value=s):
                return hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("invalid bigfloat sentinel: ", s)))), (lambda v: Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralFloat(cast(hydra.core.FloatValue, hydra.core.FloatValueBigfloat(hydra.lib.literals.float64_to_bigfloat(v))))))))), parse_special_float(s))
            case _:
                return Left("expected number or special float string for bigfloat")
    def _hoist_hydra_json_decode_decode_float_2(v1):
        match v1:
            case hydra.json.model.ValueNumber(value=n):
                return Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralFloat(cast(hydra.core.FloatValue, hydra.core.FloatValueFloat32(hydra.lib.literals.decimal_to_float32(n))))))))
            case hydra.json.model.ValueString(value=s):
                return hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("invalid float32 sentinel: ", s)))), (lambda v: Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralFloat(cast(hydra.core.FloatValue, hydra.core.FloatValueFloat32(v)))))))), parse_special_float32(s))
            case _:
                return Left("expected number or special float string for float32")
    def _hoist_hydra_json_decode_decode_float_3(v1):
        match v1:
            case hydra.json.model.ValueNumber(value=n):
                return Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralFloat(cast(hydra.core.FloatValue, hydra.core.FloatValueFloat64(hydra.lib.literals.decimal_to_float64(n))))))))
            case hydra.json.model.ValueString(value=s):
                return hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("invalid float64 sentinel: ", s)))), (lambda v: Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralFloat(cast(hydra.core.FloatValue, hydra.core.FloatValueFloat64(v)))))))), parse_special_float(s))
            case _:
                return Left("expected number or special float string for float64")
    match ft:
        case hydra.core.FloatType.BIGFLOAT:
            return _hoist_hydra_json_decode_decode_float_1(value)
        case hydra.core.FloatType.FLOAT32:
            return _hoist_hydra_json_decode_decode_float_2(value)
        case hydra.core.FloatType.FLOAT64:
            return _hoist_hydra_json_decode_decode_float_3(value)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def expect_number(value: hydra.json.model.Value) -> Either[str, Decimal]:
    r"""Extract a number from a JSON value."""
    match value:
        case hydra.json.model.ValueNumber(value=n):
            return Right(n)
        case _:
            return Left("expected number")
def expect_string(value: hydra.json.model.Value) -> Either[str, str]:
    r"""Extract a string from a JSON value."""
    match value:
        case hydra.json.model.ValueString(value=s):
            return Right(s)
        case _:
            return Left("expected string")
def decode_integer(it: hydra.core.IntegerType, value: hydra.json.model.Value) -> Either[str, hydra.core.Term]:
    r"""Decode a JSON value to an integer term. Small ints from numbers; large ints from strings."""
    match it:
        case hydra.core.IntegerType.BIGINT:
            @lru_cache(1)
            def str_result() -> Either[str, str]:
                return expect_string(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda s: (parsed := hydra.lib.literals.read_bigint(s), hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("invalid bigint: ", s)))), (lambda v: Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueBigint(v)))))))), parsed))[1]), str_result())
        case hydra.core.IntegerType.INT64:
            @lru_cache(1)
            def str_result() -> Either[str, str]:
                return expect_string(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda s: (parsed := hydra.lib.literals.read_int64(s), hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("invalid int64: ", s)))), (lambda v: Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt64(v)))))))), parsed))[1]), str_result())
        case hydra.core.IntegerType.UINT32:
            @lru_cache(1)
            def str_result() -> Either[str, str]:
                return expect_string(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda s: (parsed := hydra.lib.literals.read_uint32(s), hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("invalid uint32: ", s)))), (lambda v: Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint32(v)))))))), parsed))[1]), str_result())
        case hydra.core.IntegerType.UINT64:
            @lru_cache(1)
            def str_result() -> Either[str, str]:
                return expect_string(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda s: (parsed := hydra.lib.literals.read_uint64(s), hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("invalid uint64: ", s)))), (lambda v: Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint64(v)))))))), parsed))[1]), str_result())
        case hydra.core.IntegerType.INT8:
            @lru_cache(1)
            def num_result() -> Either[str, Decimal]:
                return expect_number(value)
            return hydra.lib.eithers.map((lambda n: cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt8(hydra.lib.literals.bigint_to_int8(hydra.lib.literals.decimal_to_bigint(n))))))))), num_result())
        case hydra.core.IntegerType.INT16:
            @lru_cache(1)
            def num_result() -> Either[str, Decimal]:
                return expect_number(value)
            return hydra.lib.eithers.map((lambda n: cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt16(hydra.lib.literals.bigint_to_int16(hydra.lib.literals.decimal_to_bigint(n))))))))), num_result())
        case hydra.core.IntegerType.INT32:
            @lru_cache(1)
            def num_result() -> Either[str, Decimal]:
                return expect_number(value)
            return hydra.lib.eithers.map((lambda n: cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueInt32(hydra.lib.literals.bigint_to_int32(hydra.lib.literals.decimal_to_bigint(n))))))))), num_result())
        case hydra.core.IntegerType.UINT8:
            @lru_cache(1)
            def num_result() -> Either[str, Decimal]:
                return expect_number(value)
            return hydra.lib.eithers.map((lambda n: cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint8(hydra.lib.literals.bigint_to_uint8(hydra.lib.literals.decimal_to_bigint(n))))))))), num_result())
        case hydra.core.IntegerType.UINT16:
            @lru_cache(1)
            def num_result() -> Either[str, Decimal]:
                return expect_number(value)
            return hydra.lib.eithers.map((lambda n: cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralInteger(cast(hydra.core.IntegerValue, hydra.core.IntegerValueUint16(hydra.lib.literals.bigint_to_uint16(hydra.lib.literals.decimal_to_bigint(n))))))))), num_result())
        case _:
            raise AssertionError("Unreachable: all variants handled")
def decode_literal(lt: hydra.core.LiteralType, value: hydra.json.model.Value):
    def _hoist_hydra_json_decode_decode_literal_1(v1):
        match v1:
            case hydra.json.model.ValueBoolean(value=b):
                return Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralBoolean(b)))))
            case _:
                return Left("expected boolean")
    def _hoist_hydra_json_decode_decode_literal_2(v1):
        match v1:
            case hydra.json.model.ValueNumber(value=n):
                return Right(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralDecimal(n)))))
            case _:
                return Left("expected number for decimal")
    match lt:
        case hydra.core.LiteralTypeBinary():
            @lru_cache(1)
            def str_result() -> Either[str, str]:
                return expect_string(value)
            return hydra.lib.eithers.map((lambda s: cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralBinary(hydra.lib.literals.string_to_binary(s)))))), str_result())
        case hydra.core.LiteralTypeBoolean():
            return _hoist_hydra_json_decode_decode_literal_1(value)
        case hydra.core.LiteralTypeDecimal():
            return _hoist_hydra_json_decode_decode_literal_2(value)
        case hydra.core.LiteralTypeFloat(value=ft):
            return decode_float(ft, value)
        case hydra.core.LiteralTypeInteger(value=it):
            return decode_integer(it, value)
        case hydra.core.LiteralTypeString():
            @lru_cache(1)
            def str_result() -> Either[str, str]:
                return expect_string(value)
            return hydra.lib.eithers.map((lambda s: cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(s))))), str_result())
        case _:
            raise AssertionError("Unreachable: all variants handled")
def expect_array(value: hydra.json.model.Value) -> Either[str, frozenlist[hydra.json.model.Value]]:
    r"""Extract an array from a JSON value."""
    match value:
        case hydra.json.model.ValueArray(value=arr):
            return Right(arr)
        case _:
            return Left("expected array")
def expect_object(value: hydra.json.model.Value) -> Either[str, FrozenDict[str, hydra.json.model.Value]]:
    r"""Extract an object from a JSON value."""
    match value:
        case hydra.json.model.ValueObject(value=obj):
            return Right(obj)
        case _:
            return Left("expected object")
def from_json(types: FrozenDict[hydra.core.Name, hydra.core.Type], tname: hydra.core.Name, typ: hydra.core.Type, value: hydra.json.model.Value):
    r"""Decode a JSON value to a Hydra term given a type and type name. Returns Left for type mismatches."""
    @lru_cache(1)
    def stripped() -> hydra.core.Type:
        return hydra.strip.deannotate_type(typ)
    match stripped():
        case hydra.core.TypeLiteral(value=lt):
            return decode_literal(lt, value)
        case hydra.core.TypeList(value=elem_type):
            def decode_elem(v: hydra.json.model.Value) -> Either[str, hydra.core.Term]:
                return from_json(types, tname, elem_type, v)
            @lru_cache(1)
            def arr_result() -> Either[str, frozenlist[hydra.json.model.Value]]:
                return expect_array(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda arr: (decoded := hydra.lib.eithers.map_list((lambda x1: decode_elem(x1)), arr), hydra.lib.eithers.map((lambda ts: cast(hydra.core.Term, hydra.core.TermList(ts))), decoded))[1]), arr_result())
        case hydra.core.TypeSet(value=elem_type2):
            def decode_elem(v: hydra.json.model.Value) -> Either[str, hydra.core.Term]:
                return from_json(types, tname, elem_type2, v)
            @lru_cache(1)
            def arr_result() -> Either[str, frozenlist[hydra.json.model.Value]]:
                return expect_array(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda arr: (decoded := hydra.lib.eithers.map_list((lambda x1: decode_elem(x1)), arr), hydra.lib.eithers.map((lambda elems: cast(hydra.core.Term, hydra.core.TermSet(hydra.lib.sets.from_list(elems)))), decoded))[1]), arr_result())
        case hydra.core.TypeMaybe(value=inner_type):
            @lru_cache(1)
            def inner_stripped() -> hydra.core.Type:
                return hydra.strip.deannotate_type(inner_type)
            @lru_cache(1)
            def is_nested_maybe():
                def _hoist_is_nested_maybe_1(v1):
                    match v1:
                        case hydra.core.TypeMaybe():
                            return True
                        case _:
                            return False
                return _hoist_is_nested_maybe_1(inner_stripped())
            def _hoist_is_nested_maybe_body_1(v1):
                match v1:
                    case hydra.json.model.ValueNull():
                        return Right(cast(hydra.core.Term, hydra.core.TermMaybe(Nothing())))
                    case _:
                        return hydra.lib.eithers.map((lambda v: cast(hydra.core.Term, hydra.core.TermMaybe(Just(v)))), from_json(types, tname, inner_type, value))
            return hydra.lib.logic.if_else(is_nested_maybe(), (lambda : (decode_just := (lambda arr: hydra.lib.maybes.maybe((lambda : Left("expected single-element array for Just")), (lambda first_val: hydra.lib.eithers.map((lambda v: cast(hydra.core.Term, hydra.core.TermMaybe(Just(v)))), from_json(types, tname, inner_type, first_val))), hydra.lib.lists.maybe_head(arr))), (decode_maybe_array := (lambda arr: (len := hydra.lib.lists.length(arr), hydra.lib.logic.if_else(hydra.lib.equality.equal(len, 0), (lambda : Right(cast(hydra.core.Term, hydra.core.TermMaybe(Nothing())))), (lambda : hydra.lib.logic.if_else(hydra.lib.equality.equal(len, 1), (lambda : decode_just(arr)), (lambda : Left("expected single-element array for Just"))))))[1]), (_hoist_decode_maybe_array_body_1 := (lambda v1: (lambda _: Right(cast(hydra.core.Term, hydra.core.TermMaybe(Nothing()))))(v1) if isinstance(v1, hydra.json.model.ValueNull) else (lambda arr: decode_maybe_array(arr))(v1.value) if isinstance(v1, hydra.json.model.ValueArray) else Left("expected null or single-element array for nested Maybe")), _hoist_decode_maybe_array_body_1(value))[1])[1])[1]), (lambda : _hoist_is_nested_maybe_body_1(value)))
        case hydra.core.TypeRecord(value=rt):
            @lru_cache(1)
            def obj_result() -> Either[str, FrozenDict[str, hydra.json.model.Value]]:
                return expect_object(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda obj: (decode_field := (lambda ft: (fname := ft.name, ftype := ft.type, mval := hydra.lib.maps.lookup(fname.value, obj), default_val := cast(hydra.json.model.Value, hydra.json.model.ValueNull()), json_val := hydra.lib.maybes.from_maybe((lambda : default_val), mval), decoded := from_json(types, tname, ftype, json_val), hydra.lib.eithers.map((lambda v: hydra.core.Field(fname, v)), decoded))[6]), decoded_fields := hydra.lib.eithers.map_list((lambda x1: decode_field(x1)), rt), hydra.lib.eithers.map((lambda fs: cast(hydra.core.Term, hydra.core.TermRecord(hydra.core.Record(tname, fs)))), decoded_fields))[2]), obj_result())
        case hydra.core.TypeUnion(value=rt2):
            def decode_variant(key: str, val: Maybe[hydra.json.model.Value], ftype: hydra.core.Type) -> Either[str, hydra.core.Term]:
                @lru_cache(1)
                def json_val() -> hydra.json.model.Value:
                    return hydra.lib.maybes.from_maybe((lambda : cast(hydra.json.model.Value, hydra.json.model.ValueNull())), val)
                @lru_cache(1)
                def decoded() -> Either[str, hydra.core.Term]:
                    return from_json(types, tname, ftype, json_val())
                return hydra.lib.eithers.map((lambda v: cast(hydra.core.Term, hydra.core.TermInject(hydra.core.Injection(tname, hydra.core.Field(hydra.core.Name(key), v))))), decoded())
            def find_and_decode(key: str, val: Maybe[hydra.json.model.Value], fts: frozenlist[hydra.core.FieldType]) -> Either[str, hydra.core.Term]:
                return hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("unknown variant: ", key)))), (lambda ft: decode_variant(key, val, ft.type)), hydra.lib.lists.find((lambda ft: hydra.lib.equality.equal(ft.name.value, key)), fts))
            def decode_single_key(obj: FrozenDict[str, hydra.json.model.Value]) -> Either[str, hydra.core.Term]:
                return hydra.lib.maybes.maybe((lambda : Left("expected single-key object for union")), (lambda k: find_and_decode(k, hydra.lib.maps.lookup(k, obj), rt2)), hydra.lib.lists.maybe_head(hydra.lib.maps.keys(obj)))
            def process_union(obj: FrozenDict[str, hydra.json.model.Value]) -> Either[str, hydra.core.Term]:
                return hydra.lib.logic.if_else(hydra.lib.equality.equal(hydra.lib.lists.length(hydra.lib.maps.keys(obj)), 1), (lambda : decode_single_key(obj)), (lambda : Left("expected single-key object for union")))
            @lru_cache(1)
            def obj_result() -> Either[str, FrozenDict[str, hydra.json.model.Value]]:
                return expect_object(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda obj: process_union(obj)), obj_result())
        case hydra.core.TypeUnit():
            @lru_cache(1)
            def obj_result() -> Either[str, FrozenDict[str, hydra.json.model.Value]]:
                return expect_object(value)
            return hydra.lib.eithers.map((lambda _2: cast(hydra.core.Term, hydra.core.TermUnit())), obj_result())
        case hydra.core.TypeWrap(value=wn):
            @lru_cache(1)
            def decoded() -> Either[str, hydra.core.Term]:
                return from_json(types, tname, wn, value)
            return hydra.lib.eithers.map((lambda v: cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(tname, v)))), decoded())
        case hydra.core.TypeMap(value=mt):
            key_type = mt.keys
            val_type = mt.values
            @lru_cache(1)
            def arr_result() -> Either[str, frozenlist[hydra.json.model.Value]]:
                return expect_array(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda arr: (decode_entry := (lambda entry_json: (obj_result := expect_object(entry_json), hydra.lib.eithers.either((lambda err: Left(err)), (lambda entry_obj: (key_json := hydra.lib.maps.lookup("key", entry_obj), val_json := hydra.lib.maps.lookup("value", entry_obj), hydra.lib.maybes.maybe((lambda : Left("missing key in map entry")), (lambda kj: hydra.lib.maybes.maybe((lambda : Left("missing value in map entry")), (lambda vj: (decoded_key := from_json(types, tname, key_type, kj), decoded_val := from_json(types, tname, val_type, vj), hydra.lib.eithers.either((lambda err: Left(err)), (lambda k: hydra.lib.eithers.map((lambda v: (k, v)), decoded_val)), decoded_key))[2]), val_json)), key_json))[2]), obj_result))[1]), entries := hydra.lib.eithers.map_list((lambda x1: decode_entry(x1)), arr), hydra.lib.eithers.map((lambda es: cast(hydra.core.Term, hydra.core.TermMap(hydra.lib.maps.from_list(es)))), entries))[2]), arr_result())
        case hydra.core.TypePair(value=pt):
            first_type = pt.first
            second_type = pt.second
            @lru_cache(1)
            def obj_result() -> Either[str, FrozenDict[str, hydra.json.model.Value]]:
                return expect_object(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda obj: (first_json := hydra.lib.maps.lookup("first", obj), second_json := hydra.lib.maps.lookup("second", obj), hydra.lib.maybes.maybe((lambda : Left("missing first in pair")), (lambda fj: hydra.lib.maybes.maybe((lambda : Left("missing second in pair")), (lambda sj: (decoded_first := from_json(types, tname, first_type, fj), decoded_second := from_json(types, tname, second_type, sj), hydra.lib.eithers.either((lambda err: Left(err)), (lambda f: hydra.lib.eithers.map((lambda s: cast(hydra.core.Term, hydra.core.TermPair((f, s)))), decoded_second)), decoded_first))[2]), second_json)), first_json))[2]), obj_result())
        case hydra.core.TypeEither(value=et):
            left_type = et.left
            right_type = et.right
            @lru_cache(1)
            def obj_result() -> Either[str, FrozenDict[str, hydra.json.model.Value]]:
                return expect_object(value)
            return hydra.lib.eithers.either((lambda err: Left(err)), (lambda obj: (left_json := hydra.lib.maps.lookup("left", obj), right_json := hydra.lib.maps.lookup("right", obj), hydra.lib.maybes.maybe((lambda : hydra.lib.maybes.maybe((lambda : Left("expected left or right in Either")), (lambda rj: (decoded := from_json(types, tname, right_type, rj), hydra.lib.eithers.map((lambda v: cast(hydra.core.Term, hydra.core.TermEither(Right(v)))), decoded))[1]), right_json)), (lambda lj: (decoded := from_json(types, tname, left_type, lj), hydra.lib.eithers.map((lambda v: cast(hydra.core.Term, hydra.core.TermEither(Left(v)))), decoded))[1]), left_json))[2]), obj_result())
        case hydra.core.TypeVariable(value=name):
            @lru_cache(1)
            def looked_up() -> Maybe[hydra.core.Type]:
                return hydra.lib.maps.lookup(name, types)
            return hydra.lib.maybes.maybe((lambda : Left(hydra.lib.strings.cat(("unknown type variable: ", name.value)))), (lambda resolved_type: from_json(types, name, resolved_type, value)), looked_up())
        case _:
            return Left(hydra.lib.strings.cat(("unsupported type for JSON decoding: ", hydra.show.core.type(typ))))
