# Note: this is an automatically generated file. Do not edit.
r"""String representations of hydra.core types."""
from __future__ import annotations
from collections.abc import Callable
from decimal import Decimal
from functools import lru_cache
from hydra.dsl.python import Either, FrozenDict, Just, Maybe, frozenlist
from typing import TypeVar, cast
import hydra.core
import hydra.lib.eithers
import hydra.lib.lists
import hydra.lib.literals
import hydra.lib.logic
import hydra.lib.maps
import hydra.lib.maybes
import hydra.lib.pairs
import hydra.lib.sets
import hydra.lib.strings
T0 = TypeVar("T0")
T1 = TypeVar("T1")
def float_type(ft: hydra.core.FloatType) -> str:
    r"""Show a float type as a string."""
    match ft:
        case hydra.core.FloatType.BIGFLOAT:
            return "bigfloat"
        case hydra.core.FloatType.FLOAT32:
            return "float32"
        case hydra.core.FloatType.FLOAT64:
            return "float64"
        case _:
            raise AssertionError("Unreachable: all variants handled")
def integer_type(it: hydra.core.IntegerType) -> str:
    r"""Show an integer type as a string."""
    match it:
        case hydra.core.IntegerType.BIGINT:
            return "bigint"
        case hydra.core.IntegerType.INT8:
            return "int8"
        case hydra.core.IntegerType.INT16:
            return "int16"
        case hydra.core.IntegerType.INT32:
            return "int32"
        case hydra.core.IntegerType.INT64:
            return "int64"
        case hydra.core.IntegerType.UINT8:
            return "uint8"
        case hydra.core.IntegerType.UINT16:
            return "uint16"
        case hydra.core.IntegerType.UINT32:
            return "uint32"
        case hydra.core.IntegerType.UINT64:
            return "uint64"
        case _:
            raise AssertionError("Unreachable: all variants handled")
def literal_type(lt: hydra.core.LiteralType) -> str:
    r"""Show a literal type as a string."""
    match lt:
        case hydra.core.LiteralTypeBinary():
            return "binary"
        case hydra.core.LiteralTypeBoolean():
            return "boolean"
        case hydra.core.LiteralTypeDecimal():
            return "decimal"
        case hydra.core.LiteralTypeFloat(value=ft):
            return float_type(ft)
        case hydra.core.LiteralTypeInteger(value=it):
            return integer_type(it)
        case hydra.core.LiteralTypeString():
            return "string"
        case _:
            raise AssertionError("Unreachable: all variants handled")
def field_type(ft: hydra.core.FieldType) -> str:
    fname = ft.name.value
    ftyp = ft.type
    return hydra.lib.strings.cat((fname, ":", type(ftyp)))
def type(typ: hydra.core.Type) -> str:
    r"""Show a type as a string."""
    def show_row_type(flds: frozenlist[hydra.core.FieldType]) -> str:
        @lru_cache(1)
        def field_strs() -> frozenlist[str]:
            return hydra.lib.lists.map((lambda x1: field_type(x1)), flds)
        return hydra.lib.strings.cat(("{", hydra.lib.strings.intercalate(", ", field_strs()), "}"))
    def gather_types(prev: frozenlist[hydra.core.Type], app: hydra.core.ApplicationType) -> frozenlist[hydra.core.Type]:
        while True:
            lhs = app.function
            rhs = app.argument
            match lhs:
                case hydra.core.TypeApplication(value=app2):
                    prev = hydra.lib.lists.cons(rhs, prev)
                    app = app2
                    continue
                case _:
                    return hydra.lib.lists.cons(lhs, hydra.lib.lists.cons(rhs, prev))
    def gather_function_types(prev: frozenlist[hydra.core.Type], t: hydra.core.Type) -> frozenlist[hydra.core.Type]:
        while True:
            match t:
                case hydra.core.TypeFunction(value=ft):
                    return (dom := ft.domain, (cod := ft.codomain, gather_function_types(hydra.lib.lists.cons(dom, prev), cod))[1])[1]
                case _:
                    return hydra.lib.lists.reverse(hydra.lib.lists.cons(t, prev))
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return type(at.body)
        case hydra.core.TypeApplication(value=app):
            @lru_cache(1)
            def types() -> frozenlist[hydra.core.Type]:
                return gather_types((), app)
            @lru_cache(1)
            def type_strs() -> frozenlist[str]:
                return hydra.lib.lists.map((lambda x1: type(x1)), types())
            return hydra.lib.strings.cat(("(", hydra.lib.strings.intercalate(" @ ", type_strs()), ")"))
        case hydra.core.TypeEither(value=et):
            left_typ = et.left
            right_typ = et.right
            return hydra.lib.strings.cat(("either<", type(left_typ), ", ", type(right_typ), ">"))
        case hydra.core.TypeForall(value=ft):
            var = ft.parameter.value
            body = ft.body
            return hydra.lib.strings.cat(("(∀", var, ".", type(body), ")"))
        case hydra.core.TypeFunction():
            @lru_cache(1)
            def types() -> frozenlist[hydra.core.Type]:
                return gather_function_types((), typ)
            @lru_cache(1)
            def type_strs() -> frozenlist[str]:
                return hydra.lib.lists.map((lambda x1: type(x1)), types())
            return hydra.lib.strings.cat(("(", hydra.lib.strings.intercalate(" → ", type_strs()), ")"))
        case hydra.core.TypeList(value=etyp):
            return hydra.lib.strings.cat(("list<", type(etyp), ">"))
        case hydra.core.TypeLiteral(value=lt):
            return literal_type(lt)
        case hydra.core.TypeMap(value=mt):
            key_typ = mt.keys
            val_typ = mt.values
            return hydra.lib.strings.cat(("map<", type(key_typ), ", ", type(val_typ), ">"))
        case hydra.core.TypeMaybe(value=etyp2):
            return hydra.lib.strings.cat(("maybe<", type(etyp2), ">"))
        case hydra.core.TypePair(value=pt):
            first_typ = pt.first
            second_typ = pt.second
            return hydra.lib.strings.cat(("(", type(first_typ), ", ", type(second_typ), ")"))
        case hydra.core.TypeRecord(value=rt):
            return hydra.lib.strings.cat2("record", show_row_type(rt))
        case hydra.core.TypeSet(value=etyp3):
            return hydra.lib.strings.cat(("set<", type(etyp3), ">"))
        case hydra.core.TypeUnion(value=rt2):
            return hydra.lib.strings.cat2("union", show_row_type(rt2))
        case hydra.core.TypeUnit():
            return "unit"
        case hydra.core.TypeVariable(value=name):
            return name.value
        case hydra.core.TypeVoid():
            return "void"
        case hydra.core.TypeWrap(value=wt):
            return hydra.lib.strings.cat(("wrap(", type(wt), ")"))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def float(fv: hydra.core.FloatValue) -> str:
    r"""Show a float value as a string."""
    match fv:
        case hydra.core.FloatValueBigfloat(value=v):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_bigfloat(v), ":bigfloat")
        case hydra.core.FloatValueFloat32(value=v2):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_float32(v2), ":float32")
        case hydra.core.FloatValueFloat64(value=v3):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_float64(v3), ":float64")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def integer(iv: hydra.core.IntegerValue) -> str:
    r"""Show an integer value as a string."""
    match iv:
        case hydra.core.IntegerValueBigint(value=v):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_bigint(v), ":bigint")
        case hydra.core.IntegerValueInt8(value=v2):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_int8(v2), ":int8")
        case hydra.core.IntegerValueInt16(value=v3):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_int16(v3), ":int16")
        case hydra.core.IntegerValueInt32(value=v4):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_int32(v4), ":int32")
        case hydra.core.IntegerValueInt64(value=v5):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_int64(v5), ":int64")
        case hydra.core.IntegerValueUint8(value=v6):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_uint8(v6), ":uint8")
        case hydra.core.IntegerValueUint16(value=v7):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_uint16(v7), ":uint16")
        case hydra.core.IntegerValueUint32(value=v8):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_uint32(v8), ":uint32")
        case hydra.core.IntegerValueUint64(value=v9):
            return hydra.lib.strings.cat2(hydra.lib.literals.show_uint64(v9), ":uint64")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def literal(l: hydra.core.Literal) -> str:
    r"""Show a literal as a string."""
    match l:
        case hydra.core.LiteralBinary():
            return "[binary]"
        case hydra.core.LiteralBoolean(value=b):
            return hydra.lib.logic.if_else(b, (lambda : "true"), (lambda : "false"))
        case hydra.core.LiteralDecimal(value=d):
            return hydra.lib.literals.show_decimal(d)
        case hydra.core.LiteralFloat(value=fv):
            return float(fv)
        case hydra.core.LiteralInteger(value=iv):
            return integer(iv)
        case hydra.core.LiteralString(value=s):
            return hydra.lib.literals.show_string(s)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def projection(proj: hydra.core.Projection) -> str:
    r"""Show a projection as a string."""
    tname = proj.type_name.value
    fname = proj.field.value
    return hydra.lib.strings.cat(("project(", tname, "){", fname, "}"))
def type_scheme(ts: hydra.core.TypeScheme) -> str:
    r"""Show a type scheme as a string."""
    vars = ts.variables
    body = ts.body
    @lru_cache(1)
    def var_names() -> frozenlist[str]:
        return hydra.lib.lists.map((lambda v1: v1.value), vars)
    @lru_cache(1)
    def fa() -> str:
        return hydra.lib.logic.if_else(hydra.lib.lists.null(vars), (lambda : ""), (lambda : hydra.lib.strings.cat(("forall ", hydra.lib.strings.intercalate(",", var_names()), ". "))))
    def to_constraint_pair(v: hydra.core.Name, c: hydra.core.Name) -> str:
        return hydra.lib.strings.cat((c.value, " ", v.value))
    def to_constraint_pairs(p: tuple[hydra.core.Name, hydra.core.TypeVariableMetadata]) -> frozenlist[str]:
        return hydra.lib.lists.map((lambda v1: to_constraint_pair(hydra.lib.pairs.first(p), v1)), hydra.lib.sets.to_list(hydra.lib.pairs.second(p).classes))
    @lru_cache(1)
    def tc() -> frozenlist[str]:
        return hydra.lib.maybes.maybe((lambda : ()), (lambda m: hydra.lib.lists.concat(hydra.lib.lists.map((lambda x1: to_constraint_pairs(x1)), hydra.lib.maps.to_list(m)))), ts.constraints)
    return hydra.lib.strings.cat(("(", fa(), hydra.lib.logic.if_else(hydra.lib.lists.null(tc()), (lambda : ""), (lambda : hydra.lib.strings.cat(("(", hydra.lib.strings.intercalate(", ", tc()), ") => ")))), type(body), ")"))
def binding(el: hydra.core.Binding) -> str:
    r"""Show a binding as a string."""
    name = el.name.value
    t = el.term
    @lru_cache(1)
    def type_str() -> str:
        return hydra.lib.maybes.maybe((lambda : ""), (lambda ts: hydra.lib.strings.cat((":(", type_scheme(ts), ")"))), el.type_scheme)
    return hydra.lib.strings.cat((name, type_str(), " = ", term(t)))
def case_statement(cs: hydra.core.CaseStatement) -> str:
    r"""Show a case statement as a string."""
    tname = cs.type_name.value
    mdef = cs.default
    cs_cases = cs.cases
    @lru_cache(1)
    def default_field() -> frozenlist[hydra.core.Field]:
        return hydra.lib.maybes.maybe((lambda : ()), (lambda d: (hydra.core.Field(hydra.core.Name("[default]"), d),)), mdef)
    @lru_cache(1)
    def all_fields() -> frozenlist[hydra.core.Field]:
        return hydra.lib.lists.concat((cs_cases, default_field()))
    return hydra.lib.strings.cat(("case(", tname, ")", fields(all_fields())))
def field(field: hydra.core.Field) -> str:
    fname = field.name.value
    fterm = field.term
    return hydra.lib.strings.cat((fname, "=", term(fterm)))
def fields(flds: frozenlist[hydra.core.Field]) -> str:
    r"""Show a list of fields as a string."""
    @lru_cache(1)
    def field_strs() -> frozenlist[str]:
        return hydra.lib.lists.map((lambda x1: field(x1)), flds)
    return hydra.lib.strings.cat(("{", hydra.lib.strings.intercalate(", ", field_strs()), "}"))
def injection(inj: hydra.core.Injection) -> str:
    r"""Show an injection as a string."""
    tname = inj.type_name
    f = inj.field
    return hydra.lib.strings.cat(("inject(", tname.value, ")", fields((f,))))
def lambda_(l: hydra.core.Lambda) -> str:
    r"""Show a lambda as a string."""
    v = l.parameter.value
    mt = l.domain
    body = l.body
    @lru_cache(1)
    def type_str() -> str:
        return hydra.lib.maybes.maybe((lambda : ""), (lambda t: hydra.lib.strings.cat2(":", type(t))), mt)
    return hydra.lib.strings.cat(("λ", v, type_str(), ".", term(body)))
def let(l: hydra.core.Let) -> str:
    r"""Show a let expression as a string."""
    bindings = l.bindings
    env = l.body
    @lru_cache(1)
    def binding_strs() -> frozenlist[str]:
        return hydra.lib.lists.map((lambda x1: binding(x1)), bindings)
    return hydra.lib.strings.cat(("let ", hydra.lib.strings.intercalate(", ", binding_strs()), " in ", term(env)))
def term(t: hydra.core.Term) -> str:
    r"""Show a term as a string."""
    def gather_terms(prev: frozenlist[hydra.core.Term], app: hydra.core.Application) -> frozenlist[hydra.core.Term]:
        while True:
            lhs = app.function
            rhs = app.argument
            match lhs:
                case hydra.core.TermApplication(value=app2):
                    prev = hydra.lib.lists.cons(rhs, prev)
                    app = app2
                    continue
                case _:
                    return hydra.lib.lists.cons(lhs, hydra.lib.lists.cons(rhs, prev))
    match t:
        case hydra.core.TermAnnotated(value=at):
            return term(at.body)
        case hydra.core.TermApplication(value=app):
            @lru_cache(1)
            def terms() -> frozenlist[hydra.core.Term]:
                return gather_terms((), app)
            @lru_cache(1)
            def term_strs() -> frozenlist[str]:
                return hydra.lib.lists.map((lambda x1: term(x1)), terms())
            return hydra.lib.strings.cat(("(", hydra.lib.strings.intercalate(" @ ", term_strs()), ")"))
        case hydra.core.TermCases(value=v1):
            return case_statement(v1)
        case hydra.core.TermEither(value=e):
            return hydra.lib.eithers.either((lambda l: hydra.lib.strings.cat(("left(", term(l), ")"))), (lambda r: hydra.lib.strings.cat(("right(", term(r), ")"))), e)
        case hydra.core.TermLambda(value=v12):
            return lambda_(v12)
        case hydra.core.TermLet(value=l):
            return let(l)
        case hydra.core.TermList(value=els):
            @lru_cache(1)
            def term_strs() -> frozenlist[str]:
                return hydra.lib.lists.map((lambda x1: term(x1)), els)
            return hydra.lib.strings.cat(("[", hydra.lib.strings.intercalate(", ", term_strs()), "]"))
        case hydra.core.TermLiteral(value=lit):
            return literal(lit)
        case hydra.core.TermMap(value=m):
            def entry(p: tuple[hydra.core.Term, hydra.core.Term]) -> str:
                return hydra.lib.strings.cat((term(hydra.lib.pairs.first(p)), "=", term(hydra.lib.pairs.second(p))))
            return hydra.lib.strings.cat(("{", hydra.lib.strings.intercalate(", ", hydra.lib.lists.map((lambda x1: entry(x1)), hydra.lib.maps.to_list(m))), "}"))
        case hydra.core.TermMaybe(value=mt):
            return hydra.lib.maybes.maybe((lambda : "nothing"), (lambda t2: hydra.lib.strings.cat(("just(", term(t2), ")"))), mt)
        case hydra.core.TermPair(value=p):
            return hydra.lib.strings.cat(("(", term(hydra.lib.pairs.first(p)), ", ", term(hydra.lib.pairs.second(p)), ")"))
        case hydra.core.TermProject(value=v13):
            return projection(v13)
        case hydra.core.TermRecord(value=rec):
            tname = rec.type_name.value
            flds = rec.fields
            return hydra.lib.strings.cat(("record(", tname, ")", fields(flds)))
        case hydra.core.TermSet(value=s):
            return hydra.lib.strings.cat(("{", hydra.lib.strings.intercalate(", ", hydra.lib.lists.map((lambda x1: term(x1)), hydra.lib.sets.to_list(s))), "}"))
        case hydra.core.TermTypeLambda(value=ta):
            param = ta.parameter.value
            body = ta.body
            return hydra.lib.strings.cat(("Λ", param, ".", term(body)))
        case hydra.core.TermTypeApplication(value=tt):
            t2 = tt.body
            typ = tt.type
            return hydra.lib.strings.cat((term(t2), "⟨", type(typ), "⟩"))
        case hydra.core.TermInject(value=v14):
            return injection(v14)
        case hydra.core.TermUnit():
            return "unit"
        case hydra.core.TermUnwrap(value=tname):
            return hydra.lib.strings.cat(("unwrap(", tname.value, ")"))
        case hydra.core.TermVariable(value=name):
            return name.value
        case hydra.core.TermWrap(value=wt):
            tname = wt.type_name.value
            term1 = wt.body
            return hydra.lib.strings.cat(("wrap(", tname, "){", term(term1), "}"))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def either(show_a: Callable[[T0], str], show_b: Callable[[T1], str], e: Either[T0, T1]) -> str:
    r"""Show an Either value using given functions for left and right."""
    return hydra.lib.eithers.either((lambda a: hydra.lib.strings.cat2("left(", hydra.lib.strings.cat2(show_a(a), ")"))), (lambda b: hydra.lib.strings.cat2("right(", hydra.lib.strings.cat2(show_b(b), ")"))), e)
def list(f: Callable[[T0], str], xs: frozenlist[T0]) -> str:
    r"""Show a list using a given function to show each element."""
    @lru_cache(1)
    def element_strs() -> frozenlist[str]:
        return hydra.lib.lists.map(f, xs)
    return hydra.lib.strings.cat(("[", hydra.lib.strings.intercalate(", ", element_strs()), "]"))
def map(show_k: Callable[[T0], str], show_v: Callable[[T1], str], m: FrozenDict[T0, T1]) -> str:
    r"""Show a map using given functions to show keys and values."""
    @lru_cache(1)
    def pair_strs() -> frozenlist[str]:
        return hydra.lib.lists.map((lambda p: hydra.lib.strings.cat((show_k(hydra.lib.pairs.first(p)), ": ", show_v(hydra.lib.pairs.second(p))))), hydra.lib.maps.to_list(m))
    return hydra.lib.strings.cat(("{", hydra.lib.strings.intercalate(", ", pair_strs()), "}"))
def maybe(f: Callable[[T0], str], mx: Maybe[T0]) -> str:
    r"""Show a Maybe value using a given function to show the element."""
    return hydra.lib.maybes.maybe((lambda : "nothing"), (lambda x: hydra.lib.strings.cat2("just(", hydra.lib.strings.cat2(f(x), ")"))), mx)
def pair(show_a: Callable[[T0], str], show_b: Callable[[T1], str], p: tuple[T0, T1]) -> str:
    r"""Show a pair using given functions to show each element."""
    return hydra.lib.strings.cat(("(", show_a(hydra.lib.pairs.first(p)), ", ", show_b(hydra.lib.pairs.second(p)), ")"))
def read_term(s: str) -> Maybe[hydra.core.Term]:
    r"""A placeholder for reading terms from their serialized form. Not implemented."""
    return Just(cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(s)))))
def set(f: Callable[[T0], str], xs: frozenset[T0]) -> str:
    r"""Show a set using a given function to show each element."""
    @lru_cache(1)
    def element_strs() -> frozenlist[str]:
        return hydra.lib.lists.map(f, hydra.lib.sets.to_list(xs))
    return hydra.lib.strings.cat(("{", hydra.lib.strings.intercalate(", ", element_strs()), "}"))
