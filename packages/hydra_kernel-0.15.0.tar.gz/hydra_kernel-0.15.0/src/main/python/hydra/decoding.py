# Note: this is an automatically generated file. Do not edit.
r"""Functions for generating term decoders from type modules."""
from __future__ import annotations
from collections.abc import Callable
from functools import lru_cache
from hydra.dsl.python import Either, Just, Left, Maybe, Nothing, Right, frozenlist
from typing import TypeVar, cast
import hydra.annotations
import hydra.constants
import hydra.core
import hydra.decode.core
import hydra.encode.core
import hydra.errors
import hydra.formatting
import hydra.lib.eithers
import hydra.lib.lists
import hydra.lib.logic
import hydra.lib.maps
import hydra.lib.maybes
import hydra.lib.pairs
import hydra.lib.sets
import hydra.lib.strings
import hydra.names
import hydra.packaging
import hydra.predicates
T0 = TypeVar("T0")
def collect_forall_variables(typ: hydra.core.Type) -> frozenlist[hydra.core.Name]:
    r"""Collect forall type variable names from a type."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return collect_forall_variables(at.body)
        case hydra.core.TypeForall(value=ft):
            return hydra.lib.lists.cons(ft.parameter, collect_forall_variables(ft.body))
        case _:
            return ()
def collect_type_variables_from_type(typ: hydra.core.Type) -> frozenlist[hydra.core.Name]:
    r"""Collect all type variable names from a type expression."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return collect_type_variables_from_type(at.body)
        case hydra.core.TypeApplication(value=app_type):
            return hydra.lib.lists.concat2(collect_type_variables_from_type(app_type.function), collect_type_variables_from_type(app_type.argument))
        case hydra.core.TypeEither(value=et):
            return hydra.lib.lists.concat2(collect_type_variables_from_type(et.left), collect_type_variables_from_type(et.right))
        case hydra.core.TypeForall(value=ft):
            return collect_type_variables_from_type(ft.body)
        case hydra.core.TypeList(value=elem_type):
            return collect_type_variables_from_type(elem_type)
        case hydra.core.TypeMap(value=mt):
            return hydra.lib.lists.concat2(collect_type_variables_from_type(mt.keys), collect_type_variables_from_type(mt.values))
        case hydra.core.TypeMaybe(value=elem_type2):
            return collect_type_variables_from_type(elem_type2)
        case hydra.core.TypePair(value=pt):
            return hydra.lib.lists.concat2(collect_type_variables_from_type(pt.first), collect_type_variables_from_type(pt.second))
        case hydra.core.TypeRecord(value=rt):
            return hydra.lib.lists.concat(hydra.lib.lists.map((lambda ft: collect_type_variables_from_type(ft.type)), rt))
        case hydra.core.TypeSet(value=elem_type3):
            return collect_type_variables_from_type(elem_type3)
        case hydra.core.TypeUnion(value=rt2):
            return hydra.lib.lists.concat(hydra.lib.lists.map((lambda ft: collect_type_variables_from_type(ft.type)), rt2))
        case hydra.core.TypeVariable(value=name):
            return (name,)
        case hydra.core.TypeWrap(value=wt):
            return collect_type_variables_from_type(wt)
        case _:
            return ()
def collect_ord_constrained_variables(typ: hydra.core.Type) -> frozenlist[hydra.core.Name]:
    r"""Collect type variables needing Ord constraints (from Map key and Set element types)."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return collect_ord_constrained_variables(at.body)
        case hydra.core.TypeApplication(value=app_type):
            return hydra.lib.lists.concat2(collect_ord_constrained_variables(app_type.function), collect_ord_constrained_variables(app_type.argument))
        case hydra.core.TypeEither(value=et):
            return hydra.lib.lists.concat2(collect_ord_constrained_variables(et.left), collect_ord_constrained_variables(et.right))
        case hydra.core.TypeForall(value=ft):
            return collect_ord_constrained_variables(ft.body)
        case hydra.core.TypeList(value=elem_type):
            return collect_ord_constrained_variables(elem_type)
        case hydra.core.TypeMap(value=mt):
            return hydra.lib.lists.concat((collect_type_variables_from_type(mt.keys), collect_ord_constrained_variables(mt.keys), collect_ord_constrained_variables(mt.values)))
        case hydra.core.TypeMaybe(value=elem_type2):
            return collect_ord_constrained_variables(elem_type2)
        case hydra.core.TypePair(value=pt):
            return hydra.lib.lists.concat2(collect_ord_constrained_variables(pt.first), collect_ord_constrained_variables(pt.second))
        case hydra.core.TypeRecord(value=rt):
            return hydra.lib.lists.concat(hydra.lib.lists.map((lambda ft: collect_ord_constrained_variables(ft.type)), rt))
        case hydra.core.TypeSet(value=elem_type3):
            return hydra.lib.lists.concat2(collect_type_variables_from_type(elem_type3), collect_ord_constrained_variables(elem_type3))
        case hydra.core.TypeUnion(value=rt2):
            return hydra.lib.lists.concat(hydra.lib.lists.map((lambda ft: collect_ord_constrained_variables(ft.type)), rt2))
        case hydra.core.TypeWrap(value=wt):
            return collect_ord_constrained_variables(wt)
        case _:
            return ()
def collect_type_variables(typ: hydra.core.Type) -> frozenlist[hydra.core.Name]:
    r"""Collect type variable names from a type (forall parameters only)."""
    return collect_forall_variables(typ)
def decode_binding_name(n: hydra.core.Name) -> hydra.core.Name:
    r"""Generate a binding name for a decoder function from a type name."""
    @lru_cache(1)
    def parts() -> frozenlist[str]:
        return hydra.lib.strings.split_on(".", n.value)
    @lru_cache(1)
    def local_part() -> str:
        return hydra.formatting.decapitalize(hydra.names.local_name_of(n))
    local_result = hydra.core.Name(local_part())
    return hydra.lib.maybes.maybe((lambda : local_result), (lambda ns_parts: hydra.lib.maybes.maybe((lambda : local_result), (lambda ns_uc: (tail := hydra.lib.pairs.second(ns_uc), hydra.core.Name(hydra.lib.strings.intercalate(".", hydra.lib.lists.concat2(("hydra", "decode"), hydra.lib.lists.concat2(tail, (local_part(),))))))[1]), hydra.lib.lists.uncons(ns_parts))), hydra.lib.lists.maybe_init(parts()))
def decode_literal_type(lt: hydra.core.LiteralType):
    def _hoist_hydra_decoding_decode_literal_type_1(v1):
        match v1:
            case hydra.core.FloatType.BIGFLOAT:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "bigfloat", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("float"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.FloatValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "bigfloat", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("bigfloat"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("f"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("f")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.FloatType.FLOAT32:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "float32", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("float"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.FloatValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "float32", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("float32"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("f"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("f")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.FloatType.FLOAT64:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "float64", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("float"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.FloatValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "float64", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("float64"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("f"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("f")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case _:
                raise AssertionError("Unreachable: all variants handled")
    def _hoist_hydra_decoding_decode_literal_type_2(v1):
        match v1:
            case hydra.core.IntegerType.BIGINT:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "bigint", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "bigint", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("bigint"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.INT8:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int8", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int8", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("int8"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.INT16:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int16", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int16", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("int16"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.INT32:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int32", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int32", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("int32"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.INT64:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int64", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "int64", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("int64"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.UINT8:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint8", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint8", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("uint8"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.UINT16:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint16", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint16", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("uint16"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.UINT32:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint32", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint32", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("uint32"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case hydra.core.IntegerType.UINT64:
                return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint64", " literal"))))))))))))), (hydra.core.Field(hydra.core.Name("integer"), cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.IntegerValue"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(hydra.lib.strings.cat(("expected ", "uint64", " value"))))))))))))), (hydra.core.Field(hydra.core.Name("uint64"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("i"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("i")))))))))),))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
            case _:
                raise AssertionError("Unreachable: all variants handled")
    match lt:
        case hydra.core.LiteralTypeBinary():
            return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected binary literal"))))))))))), (hydra.core.Field(hydra.core.Name("binary"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("b"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("b")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
        case hydra.core.LiteralTypeBoolean():
            return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected boolean literal"))))))))))), (hydra.core.Field(hydra.core.Name("boolean"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("b"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("b")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
        case hydra.core.LiteralTypeDecimal():
            return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected decimal literal"))))))))))), (hydra.core.Field(hydra.core.Name("decimal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("d"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("d")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
        case hydra.core.LiteralTypeFloat(value=ft):
            return _hoist_hydra_decoding_decode_literal_type_1(ft)
        case hydra.core.LiteralTypeInteger(value=it):
            return _hoist_hydra_decoding_decode_literal_type_2(it)
        case hydra.core.LiteralTypeString():
            return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected literal"))))))))))), (hydra.core.Field(hydra.core.Name("literal"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("v"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Literal"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected string literal"))))))))))), (hydra.core.Field(hydra.core.Name("string"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("s"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("s")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("v")))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
        case _:
            raise AssertionError("Unreachable: all variants handled")
@lru_cache(1)
def decode_unit_type() -> hydra.core.Term:
    r"""Generate a decoder for the unit type."""
    return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("t"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.decodeUnit"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("t"))))))))))))
def decode_either_type(et: hydra.core.EitherType) -> hydra.core.Term:
    r"""Generate a decoder for an Either type."""
    @lru_cache(1)
    def left_decoder() -> hydra.core.Term:
        return decode_type(et.left)
    @lru_cache(1)
    def right_decoder() -> hydra.core.Term:
        return decode_type(et.right)
    return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.decodeEither"))), left_decoder()))), right_decoder())))
def decode_forall_type(ft: hydra.core.ForallType) -> hydra.core.Term:
    r"""Generate a decoder for a polymorphic (forall) type."""
    return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(decode_binding_name(ft.parameter), Nothing(), decode_type(ft.body))))
def decode_list_type(elem_type: hydra.core.Type) -> hydra.core.Term:
    r"""Generate a decoder for a list type."""
    @lru_cache(1)
    def elem_decoder() -> hydra.core.Term:
        return decode_type(elem_type)
    return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.decodeList"))), elem_decoder())))
def decode_map_type(mt: hydra.core.MapType) -> hydra.core.Term:
    r"""Generate a decoder for a map type."""
    @lru_cache(1)
    def key_decoder() -> hydra.core.Term:
        return decode_type(mt.keys)
    @lru_cache(1)
    def val_decoder() -> hydra.core.Term:
        return decode_type(mt.values)
    return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.decodeMap"))), key_decoder()))), val_decoder())))
def decode_maybe_type(elem_type: hydra.core.Type) -> hydra.core.Term:
    r"""Generate a decoder for an optional type."""
    @lru_cache(1)
    def elem_decoder() -> hydra.core.Term:
        return decode_type(elem_type)
    return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.decodeMaybe"))), elem_decoder())))
def decode_pair_type(pt: hydra.core.PairType) -> hydra.core.Term:
    r"""Generate a decoder for a pair type."""
    @lru_cache(1)
    def first_decoder() -> hydra.core.Term:
        return decode_type(pt.first)
    @lru_cache(1)
    def second_decoder() -> hydra.core.Term:
        return decode_type(pt.second)
    return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.decodePair"))), first_decoder()))), second_decoder())))
def decode_record_type(rt: frozenlist[hydra.core.FieldType]) -> hydra.core.Term:
    r"""Generate a decoder for a record type."""
    return decode_record_type_impl(hydra.core.Name("unknown"), rt)
def decode_record_type_impl(tname: hydra.core.Name, rt: frozenlist[hydra.core.FieldType]) -> hydra.core.Term:
    r"""Generate a decoder for a record type with a type name."""
    def decode_field_term(ft: hydra.core.FieldType) -> hydra.core.Term:
        return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.requireField"))), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(ft.name.value))))))), decode_type(ft.type)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("fieldMap")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx"))))))
    def local_var_name(ft: hydra.core.FieldType) -> hydra.core.Name:
        return hydra.core.Name(hydra.lib.strings.cat(("field_", ft.name.value)))
    def to_field_lambda(ft: hydra.core.FieldType, body: hydra.core.Term) -> hydra.core.Term:
        return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(local_var_name(ft), Nothing(), body)))
    @lru_cache(1)
    def decode_body() -> hydra.core.Term:
        return hydra.lib.lists.foldl((lambda acc, ft: cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.bind"))), decode_field_term(ft)))), to_field_lambda(ft, acc))))), cast(hydra.core.Term, hydra.core.TermEither(Right(cast(hydra.core.Term, hydra.core.TermRecord(hydra.core.Record(tname, hydra.lib.lists.map((lambda ft: hydra.core.Field(ft.name, cast(hydra.core.Term, hydra.core.TermVariable(local_var_name(ft))))), rt))))))), hydra.lib.lists.reverse(rt))
    return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected record"))))))))))), (hydra.core.Field(hydra.core.Name("record"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("record"), Nothing(), cast(hydra.core.Term, hydra.core.TermLet(hydra.core.Let((hydra.core.Binding(hydra.core.Name("fieldMap"), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.toFieldMap"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("record")))))), Nothing()),), decode_body()))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
def decode_set_type(elem_type: hydra.core.Type) -> hydra.core.Term:
    r"""Generate a decoder for a set type."""
    @lru_cache(1)
    def elem_decoder() -> hydra.core.Term:
        return decode_type(elem_type)
    return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.decodeSet"))), elem_decoder())))
def decode_type(typ: hydra.core.Type) -> hydra.core.Term:
    r"""Generate a decoder term for a Type."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return decode_type(at.body)
        case hydra.core.TypeApplication(value=app_type):
            return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(decode_type(app_type.function), decode_type(app_type.argument))))
        case hydra.core.TypeEither(value=et):
            return decode_either_type(et)
        case hydra.core.TypeForall(value=ft):
            return decode_forall_type(ft)
        case hydra.core.TypeList(value=elem_type):
            return decode_list_type(elem_type)
        case hydra.core.TypeLiteral(value=lt):
            return decode_literal_type(lt)
        case hydra.core.TypeMap(value=mt):
            return decode_map_type(mt)
        case hydra.core.TypeMaybe(value=elem_type2):
            return decode_maybe_type(elem_type2)
        case hydra.core.TypePair(value=pt):
            return decode_pair_type(pt)
        case hydra.core.TypeRecord(value=rt):
            return decode_record_type(rt)
        case hydra.core.TypeSet(value=elem_type3):
            return decode_set_type(elem_type3)
        case hydra.core.TypeUnion(value=rt2):
            return decode_union_type(rt2)
        case hydra.core.TypeUnit():
            return decode_unit_type()
        case hydra.core.TypeVoid():
            return decode_unit_type()
        case hydra.core.TypeWrap(value=wt):
            return decode_wrapped_type(wt)
        case hydra.core.TypeVariable(value=type_name):
            return cast(hydra.core.Term, hydra.core.TermVariable(decode_binding_name(type_name)))
        case _:
            return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("t"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("unsupported type variant"))))))))))))))))
def decode_union_type(rt: frozenlist[hydra.core.FieldType]) -> hydra.core.Term:
    r"""Generate a decoder for a union type."""
    return decode_union_type_named(hydra.core.Name("unknown"), rt)
def decode_union_type_named(ename: hydra.core.Name, rt: frozenlist[hydra.core.FieldType]) -> hydra.core.Term:
    r"""Generate a decoder for a union type with the given element name."""
    def to_variant_pair(ft: hydra.core.FieldType) -> hydra.core.Term:
        return cast(hydra.core.Term, hydra.core.TermPair((cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.core.Name"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(ft.name.value))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("input"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.map"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("t"), Nothing(), cast(hydra.core.Term, hydra.core.TermInject(hydra.core.Injection(ename, hydra.core.Field(ft.name, cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("t"))))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(decode_type(ft.type), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("input")))))))))))))))
    return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected union"))))))))))), (hydra.core.Field(hydra.core.Name("inject"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("inj"), Nothing(), cast(hydra.core.Term, hydra.core.TermLet(hydra.core.Let((hydra.core.Binding(hydra.core.Name("field"), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermProject(hydra.core.Projection(hydra.core.Name("hydra.core.Injection"), hydra.core.Name("field")))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("inj")))))), Nothing()), hydra.core.Binding(hydra.core.Name("fname"), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermProject(hydra.core.Projection(hydra.core.Name("hydra.core.Field"), hydra.core.Name("name")))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("field")))))), Nothing()), hydra.core.Binding(hydra.core.Name("fterm"), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermProject(hydra.core.Projection(hydra.core.Name("hydra.core.Field"), hydra.core.Name("term")))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("field")))))), Nothing()), hydra.core.Binding(hydra.core.Name("variantMap"), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maps.fromList"))), cast(hydra.core.Term, hydra.core.TermList(hydra.lib.lists.map((lambda x1: to_variant_pair(x1)), rt)))))), Nothing())), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maybes.maybe"))), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.strings.cat"))), cast(hydra.core.Term, hydra.core.TermList((cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("no such field ")))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermUnwrap(hydra.core.Name("hydra.core.Name"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("fname")))))), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString(" in union"))))))))))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("f"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("f"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("fterm")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.maps.lookup"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("fname")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("variantMap")))))))))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
def decode_wrapped_type(wt: hydra.core.Type) -> hydra.core.Term:
    r"""Generate a decoder for a wrapped type."""
    return decode_wrapped_type_named(hydra.core.Name("unknown"), wt)
def decode_wrapped_type_named(ename: hydra.core.Name, wt: hydra.core.Type) -> hydra.core.Term:
    r"""Generate a decoder for a wrapped type with the given element name."""
    @lru_cache(1)
    def body_decoder() -> hydra.core.Term:
        return decode_type(wt)
    return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("raw"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.either"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("err"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("err")))))))))))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("stripped"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermCases(hydra.core.CaseStatement(hydra.core.Name("hydra.core.Term"), Just(cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("expected wrapped type"))))))))))), (hydra.core.Field(hydra.core.Name("wrap"), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("wrappedTerm"), Nothing(), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.lib.eithers.map"))), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("b"), Nothing(), cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(ename, cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("b")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(body_decoder(), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermProject(hydra.core.Projection(hydra.core.Name("hydra.core.WrappedTerm"), hydra.core.Name("body")))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("wrappedTerm")))))))))))))))),)))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("stripped")))))))))))), cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.extract.core.stripWithDecodingError"))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("cx")))))), cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("raw")))))))))))))))
def decode_record_type_named(ename: hydra.core.Name, rt: frozenlist[hydra.core.FieldType]) -> hydra.core.Term:
    r"""Generate a decoder for a record type with element name."""
    return decode_record_type_impl(ename, rt)
def decode_type_named(ename: hydra.core.Name, typ: hydra.core.Type) -> hydra.core.Term:
    r"""Generate a decoder term for a Type, with element name for nominal types."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return decode_type_named(ename, at.body)
        case hydra.core.TypeApplication(value=app_type):
            return cast(hydra.core.Term, hydra.core.TermApplication(hydra.core.Application(decode_type(app_type.function), decode_type(app_type.argument))))
        case hydra.core.TypeEither(value=et):
            return decode_either_type(et)
        case hydra.core.TypeForall(value=ft):
            return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(decode_binding_name(ft.parameter), Nothing(), decode_type_named(ename, ft.body))))
        case hydra.core.TypeList(value=elem_type):
            return decode_list_type(elem_type)
        case hydra.core.TypeLiteral(value=lt):
            return decode_literal_type(lt)
        case hydra.core.TypeMap(value=mt):
            return decode_map_type(mt)
        case hydra.core.TypeMaybe(value=elem_type2):
            return decode_maybe_type(elem_type2)
        case hydra.core.TypePair(value=pt):
            return decode_pair_type(pt)
        case hydra.core.TypeRecord(value=rt):
            return decode_record_type_named(ename, rt)
        case hydra.core.TypeSet(value=elem_type3):
            return decode_set_type(elem_type3)
        case hydra.core.TypeUnion(value=rt2):
            return decode_union_type_named(ename, rt2)
        case hydra.core.TypeUnit():
            return decode_unit_type()
        case hydra.core.TypeVoid():
            return decode_unit_type()
        case hydra.core.TypeWrap(value=wt):
            return decode_wrapped_type_named(ename, wt)
        case hydra.core.TypeVariable(value=type_name):
            return cast(hydra.core.Term, hydra.core.TermVariable(decode_binding_name(type_name)))
        case _:
            return cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("cx"), Nothing(), cast(hydra.core.Term, hydra.core.TermLambda(hydra.core.Lambda(hydra.core.Name("t"), Nothing(), cast(hydra.core.Term, hydra.core.TermEither(Left(cast(hydra.core.Term, hydra.core.TermWrap(hydra.core.WrappedTerm(hydra.core.Name("hydra.errors.DecodingError"), cast(hydra.core.Term, hydra.core.TermLiteral(cast(hydra.core.Literal, hydra.core.LiteralString("unsupported type variant"))))))))))))))))
def decoder_full_result_type(typ: hydra.core.Type) -> hydra.core.Type:
    r"""Get full result type for decoder."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return decoder_full_result_type(at.body)
        case hydra.core.TypeApplication(value=app_type):
            return cast(hydra.core.Type, hydra.core.TypeApplication(hydra.core.ApplicationType(decoder_full_result_type(app_type.function), app_type.argument)))
        case hydra.core.TypeEither(value=et):
            return cast(hydra.core.Type, hydra.core.TypeEither(hydra.core.EitherType(decoder_full_result_type(et.left), decoder_full_result_type(et.right))))
        case hydra.core.TypeForall(value=ft):
            return cast(hydra.core.Type, hydra.core.TypeApplication(hydra.core.ApplicationType(decoder_full_result_type(ft.body), cast(hydra.core.Type, hydra.core.TypeVariable(ft.parameter)))))
        case hydra.core.TypeList(value=elem_type):
            return cast(hydra.core.Type, hydra.core.TypeList(decoder_full_result_type(elem_type)))
        case hydra.core.TypeLiteral():
            return cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Literal")))
        case hydra.core.TypeMap(value=mt):
            return cast(hydra.core.Type, hydra.core.TypeMap(hydra.core.MapType(decoder_full_result_type(mt.keys), decoder_full_result_type(mt.values))))
        case hydra.core.TypeMaybe(value=elem_type2):
            return cast(hydra.core.Type, hydra.core.TypeMaybe(decoder_full_result_type(elem_type2)))
        case hydra.core.TypePair(value=pt):
            return cast(hydra.core.Type, hydra.core.TypePair(hydra.core.PairType(decoder_full_result_type(pt.first), decoder_full_result_type(pt.second))))
        case hydra.core.TypeRecord():
            return cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term")))
        case hydra.core.TypeSet(value=elem_type3):
            return cast(hydra.core.Type, hydra.core.TypeSet(decoder_full_result_type(elem_type3)))
        case hydra.core.TypeUnion():
            return cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term")))
        case hydra.core.TypeUnit():
            return cast(hydra.core.Type, hydra.core.TypeUnit())
        case hydra.core.TypeVariable(value=name):
            return cast(hydra.core.Type, hydra.core.TypeVariable(name))
        case hydra.core.TypeVoid():
            return cast(hydra.core.Type, hydra.core.TypeVoid())
        case hydra.core.TypeWrap():
            return cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term")))
        case _:
            return cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term")))
def decoder_full_result_type_named(ename: hydra.core.Name, typ: hydra.core.Type) -> hydra.core.Type:
    r"""Get full result type for decoder with element name."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return decoder_full_result_type_named(ename, at.body)
        case hydra.core.TypeForall(value=ft):
            return cast(hydra.core.Type, hydra.core.TypeApplication(hydra.core.ApplicationType(decoder_full_result_type_named(ename, ft.body), cast(hydra.core.Type, hydra.core.TypeVariable(ft.parameter)))))
        case hydra.core.TypeRecord():
            return cast(hydra.core.Type, hydra.core.TypeVariable(ename))
        case hydra.core.TypeUnion():
            return cast(hydra.core.Type, hydra.core.TypeVariable(ename))
        case hydra.core.TypeWrap():
            return cast(hydra.core.Type, hydra.core.TypeVariable(ename))
        case hydra.core.TypeApplication(value=app_type):
            return cast(hydra.core.Type, hydra.core.TypeApplication(hydra.core.ApplicationType(decoder_full_result_type(app_type.function), app_type.argument)))
        case hydra.core.TypeEither(value=et):
            return cast(hydra.core.Type, hydra.core.TypeEither(hydra.core.EitherType(decoder_full_result_type(et.left), decoder_full_result_type(et.right))))
        case hydra.core.TypeList(value=elem_type):
            return cast(hydra.core.Type, hydra.core.TypeList(decoder_full_result_type(elem_type)))
        case hydra.core.TypeLiteral():
            return cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Literal")))
        case hydra.core.TypeMap(value=mt):
            return cast(hydra.core.Type, hydra.core.TypeMap(hydra.core.MapType(decoder_full_result_type(mt.keys), decoder_full_result_type(mt.values))))
        case hydra.core.TypeMaybe(value=elem_type2):
            return cast(hydra.core.Type, hydra.core.TypeMaybe(decoder_full_result_type(elem_type2)))
        case hydra.core.TypePair(value=pt):
            return cast(hydra.core.Type, hydra.core.TypePair(hydra.core.PairType(decoder_full_result_type(pt.first), decoder_full_result_type(pt.second))))
        case hydra.core.TypeSet(value=elem_type3):
            return cast(hydra.core.Type, hydra.core.TypeSet(decoder_full_result_type(elem_type3)))
        case hydra.core.TypeUnit():
            return cast(hydra.core.Type, hydra.core.TypeUnit())
        case hydra.core.TypeVariable(value=name):
            return cast(hydra.core.Type, hydra.core.TypeVariable(name))
        case hydra.core.TypeVoid():
            return cast(hydra.core.Type, hydra.core.TypeVoid())
        case _:
            return cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term")))
def prepend_forall_decoders(base_type: hydra.core.Type, typ: hydra.core.Type) -> hydra.core.Type:
    r"""Prepend decoder types for forall parameters to base type."""
    match typ:
        case hydra.core.TypeAnnotated(value=at):
            return prepend_forall_decoders(base_type, at.body)
        case hydra.core.TypeForall(value=ft):
            return cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.graph.Graph"))), cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term"))), cast(hydra.core.Type, hydra.core.TypeEither(hydra.core.EitherType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.errors.DecodingError"))), cast(hydra.core.Type, hydra.core.TypeVariable(ft.parameter))))))))))), prepend_forall_decoders(base_type, ft.body))))
        case _:
            return base_type
def decoder_type_named(ename: hydra.core.Name, typ: hydra.core.Type) -> hydra.core.Type:
    r"""Build decoder function type with element name."""
    @lru_cache(1)
    def result_type() -> hydra.core.Type:
        return decoder_full_result_type_named(ename, typ)
    @lru_cache(1)
    def base_type() -> hydra.core.Type:
        return cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.graph.Graph"))), cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term"))), cast(hydra.core.Type, hydra.core.TypeEither(hydra.core.EitherType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.errors.DecodingError"))), result_type())))))))))
    return prepend_forall_decoders(base_type(), typ)
def decoder_type_scheme_named(ename: hydra.core.Name, typ: hydra.core.Type) -> hydra.core.TypeScheme:
    r"""Build type scheme for a decoder function with element name."""
    @lru_cache(1)
    def type_vars() -> frozenlist[hydra.core.Name]:
        return collect_type_variables(typ)
    @lru_cache(1)
    def all_ord_vars() -> frozenlist[hydra.core.Name]:
        return collect_ord_constrained_variables(typ)
    @lru_cache(1)
    def ord_vars() -> frozenlist[hydra.core.Name]:
        return hydra.lib.lists.filter((lambda v: hydra.lib.lists.elem(v, type_vars())), all_ord_vars())
    @lru_cache(1)
    def constraints() -> Maybe[FrozenDict[hydra.core.Name, hydra.core.TypeVariableMetadata]]:
        return hydra.lib.logic.if_else(hydra.lib.lists.null(ord_vars()), (lambda : Nothing()), (lambda : Just(hydra.lib.maps.from_list(hydra.lib.lists.map((lambda v: (v, hydra.core.TypeVariableMetadata(hydra.lib.sets.singleton(hydra.core.Name("ordering"))))), ord_vars())))))
    return hydra.core.TypeScheme(type_vars(), decoder_type_named(ename, typ), constraints())
def decode_binding(cx: T0, graph: hydra.graph.Graph, b: hydra.core.Binding) -> Either[hydra.errors.DecodingError, hydra.core.Binding]:
    r"""Transform a type binding into a decoder binding."""
    return hydra.lib.eithers.bind(hydra.decode.core.type(graph, b.term), (lambda typ: Right(hydra.core.Binding(decode_binding_name(b.name), decode_type_named(b.name, typ), Just(decoder_type_scheme_named(b.name, typ))))))
def decode_namespace(ns: hydra.packaging.Namespace) -> hydra.packaging.Namespace:
    r"""Generate a decoder module namespace from a source module namespace."""
    @lru_cache(1)
    def parts() -> frozenlist[str]:
        return hydra.lib.strings.split_on(".", ns.value)
    fallback = hydra.packaging.Namespace(ns.value)
    return hydra.lib.maybes.maybe((lambda : fallback), (lambda uc: hydra.packaging.Namespace(hydra.lib.strings.cat(("hydra.decode.", hydra.lib.strings.intercalate(".", hydra.lib.pairs.second(uc)))))), hydra.lib.lists.uncons(parts()))
def is_decodable_binding(cx: hydra.context.Context, graph: hydra.graph.Graph, b: hydra.core.Binding) -> Either[hydra.errors.Error, Maybe[hydra.core.Binding]]:
    r"""Check if a binding is decodable (serializable type)."""
    return hydra.lib.eithers.bind(hydra.predicates.is_serializable_by_name(cx, graph, b.name), (lambda serializable: Right(hydra.lib.logic.if_else(serializable, (lambda : Just(b)), (lambda : Nothing())))))
def filter_type_bindings(cx: hydra.context.Context, graph: hydra.graph.Graph, bindings: frozenlist[hydra.core.Binding]) -> Either[hydra.errors.Error, frozenlist[hydra.core.Binding]]:
    r"""Filter bindings to only decodable type definitions."""
    return hydra.lib.eithers.map((lambda x1: hydra.lib.maybes.cat(x1)), hydra.lib.eithers.map_list((lambda v1: is_decodable_binding(cx, graph, v1)), hydra.lib.lists.filter((lambda x1: hydra.annotations.is_native_type(x1)), bindings)))
def decode_module(cx: hydra.context.Context, graph: hydra.graph.Graph, mod: hydra.packaging.Module):
    def _hoist_hydra_decoding_decode_module_1(v1):
        match v1:
            case hydra.packaging.DefinitionType(value=td):
                return Just((schema_term := cast(hydra.core.Term, hydra.core.TermVariable(hydra.core.Name("hydra.core.Type"))), (data_term := hydra.annotations.normalize_term_annotations(cast(hydra.core.Term, hydra.core.TermAnnotated(hydra.core.AnnotatedTerm(hydra.encode.core.type(td.type_scheme.body), hydra.lib.maps.from_list(((hydra.constants.key_type, schema_term),)))))), hydra.core.Binding(td.name, data_term, Just(hydra.core.TypeScheme((), cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Type"))), Nothing()))))[1])[1])
            case _:
                return Nothing()
    return hydra.lib.eithers.bind(filter_type_bindings(cx, graph, hydra.lib.maybes.cat(hydra.lib.lists.map((lambda d: _hoist_hydra_decoding_decode_module_1(d)), mod.definitions))), (lambda type_bindings: hydra.lib.logic.if_else(hydra.lib.lists.null(type_bindings), (lambda : Right(Nothing())), (lambda : hydra.lib.eithers.bind(hydra.lib.eithers.map_list((lambda b: hydra.lib.eithers.bimap((lambda _e: cast(hydra.errors.Error, hydra.errors.ErrorDecoding(_e))), (lambda x: x), decode_binding(cx, graph, b))), type_bindings), (lambda decoded_bindings: (decoded_type_deps := hydra.lib.lists.map((lambda x1: decode_namespace(x1)), mod.type_dependencies), decoded_term_deps := hydra.lib.lists.map((lambda x1: decode_namespace(x1)), mod.term_dependencies), all_decoded_deps := hydra.lib.lists.nub(hydra.lib.lists.concat2(decoded_type_deps, decoded_term_deps)), Right(Just(hydra.packaging.Module(Just(hydra.lib.strings.cat(("Term decoders for ", mod.namespace.value))), decode_namespace(mod.namespace), hydra.lib.lists.concat2((hydra.packaging.Namespace("hydra.extract.core"), hydra.packaging.Namespace("hydra.lexical"), hydra.packaging.Namespace("hydra.rewriting")), all_decoded_deps), (mod.namespace, hydra.packaging.Namespace("hydra.util")), hydra.lib.lists.map((lambda b: cast(hydra.packaging.Definition, hydra.packaging.DefinitionTerm(hydra.packaging.TermDefinition(b.name, b.term, b.type_scheme)))), decoded_bindings)))))[3]))))))
def decoder_result_type(typ: hydra.core.Type) -> hydra.core.Name:
    r"""Compute the result type name for a decoder."""
    while True:
        match typ:
            case hydra.core.TypeAnnotated(value=at):
                typ = at.body
                continue
            case hydra.core.TypeApplication(value=app_type):
                typ = app_type.function
                continue
            case hydra.core.TypeForall(value=ft):
                typ = ft.body
                continue
            case hydra.core.TypeLiteral():
                return hydra.core.Name("hydra.core.Literal")
            case hydra.core.TypeRecord():
                return hydra.core.Name("hydra.core.Term")
            case hydra.core.TypeUnion():
                return hydra.core.Name("hydra.core.Term")
            case hydra.core.TypeWrap():
                return hydra.core.Name("hydra.core.Term")
            case _:
                return hydra.core.Name("hydra.core.Term")
def decoder_type(typ: hydra.core.Type) -> hydra.core.Type:
    r"""Build decoder function type."""
    @lru_cache(1)
    def result_type() -> hydra.core.Type:
        return decoder_full_result_type(typ)
    @lru_cache(1)
    def base_type() -> hydra.core.Type:
        return cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.graph.Graph"))), cast(hydra.core.Type, hydra.core.TypeFunction(hydra.core.FunctionType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.core.Term"))), cast(hydra.core.Type, hydra.core.TypeEither(hydra.core.EitherType(cast(hydra.core.Type, hydra.core.TypeVariable(hydra.core.Name("hydra.errors.DecodingError"))), result_type())))))))))
    return prepend_forall_decoders(base_type(), typ)
def decoder_type_scheme(typ: hydra.core.Type) -> hydra.core.TypeScheme:
    r"""Build type scheme for a decoder function."""
    @lru_cache(1)
    def type_vars() -> frozenlist[hydra.core.Name]:
        return collect_type_variables(typ)
    @lru_cache(1)
    def all_ord_vars() -> frozenlist[hydra.core.Name]:
        return collect_ord_constrained_variables(typ)
    @lru_cache(1)
    def ord_vars() -> frozenlist[hydra.core.Name]:
        return hydra.lib.lists.filter((lambda v: hydra.lib.lists.elem(v, type_vars())), all_ord_vars())
    @lru_cache(1)
    def constraints() -> Maybe[FrozenDict[hydra.core.Name, hydra.core.TypeVariableMetadata]]:
        return hydra.lib.logic.if_else(hydra.lib.lists.null(ord_vars()), (lambda : Nothing()), (lambda : Just(hydra.lib.maps.from_list(hydra.lib.lists.map((lambda v: (v, hydra.core.TypeVariableMetadata(hydra.lib.sets.singleton(hydra.core.Name("ordering"))))), ord_vars())))))
    return hydra.core.TypeScheme(type_vars(), decoder_type(typ), constraints())
