from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

REASONING_EFFORTS = {"none", "minimal", "low", "medium", "high", "xhigh"}
DEFAULT_PROVIDER = "chump_cloud"
DEFAULT_CHUMP_CLOUD_BASE_URL = "https://chump-cloud.yaqeen.me/v1"
DEFAULT_ALLOWED_ORIGINS: tuple[str, ...] = (
    "https://chump.yaqeen.me",
    # Local dev for the Svelte web client (Vite default port).
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    # SvelteKit preview / build (`vite preview` / `wrangler dev`) defaults.
    "http://localhost:4173",
    "http://127.0.0.1:4173",
)
DEFAULT_MODELS = {
    "codex": "gpt-5.4",
    "openai": "gpt-5.4",
    "chump_cloud": "deepseek-v4-flash",
    "google": "gemini-2.5-flash",
    "anthropic": "claude-sonnet-4-20250514",
    "workers_ai": "@cf/moonshotai/kimi-k2.5",
    "deepseek": "deepseek-v4-pro",
}

PROVIDER_MODELS = {
    "codex": {
        "gpt-5.5",
        "gpt-5.4",
        "gpt-5.4-mini",
        "gpt-5.3-codex",
        "gpt-5.2",
        "gpt-5.2-codex",
        "gpt-5.1-codex",
        "gpt-5.1-codex-max",
        "gpt-5.1-codex-mini",
        "gpt-5-codex",
    },
    "openai": {
        "gpt-5.5",
        "gpt-5.4-pro",
        "gpt-5.4",
        "gpt-5.4-mini",
        "gpt-5.4-nano",
        "gpt-5.3-codex",
        "gpt-5.2",
        "gpt-5.2-pro",
        "gpt-5.2-chat-latest",
        "gpt-5.1",
        "gpt-5",
        "gpt-5-mini",
        "gpt-5-nano",
        "gpt-5-codex",
    },
    "chump_cloud": {
        "deepseek-v4-pro",
        "deepseek-v4-flash",
    },
    "google": {
        "gemini-3.1-pro-preview",
        "gemini-3-pro-preview",
        "gemini-3-flash-preview",
        "gemini-2.5-flash",
        "gemini-2.5-pro",
        "gemini-2.5-flash-lite",
    },
    "anthropic": {
        "claude-sonnet-4-20250514",
    },
    "workers_ai": {
        "@cf/zai-org/glm-4.7-flash",
        "@cf/nvidia/nemotron-3-120b-a12b",
        "@cf/moonshotai/kimi-k2.5",
        "@cf/moonshotai/kimi-k2.6",
    },
    "deepseek": {
        "deepseek-v4-pro",
        "deepseek-v4-flash",
    },
}


@dataclass(frozen=True)
class ChumpConfig:
    host: str
    port: int
    workspace_root: Path
    data_dir: Path
    provider: str
    model: str
    max_steps: int
    retry_max_attempts: int
    retry_initial_delay: float
    retry_max_delay: float
    retry_backoff: float
    retry_jitter: bool
    command_timeout: int
    managed_idle_timeout: int | None
    reasoning: dict[str, Any] | None
    verbose: bool
    allowed_origins: tuple[str, ...]
    available_providers: tuple[str, ...]


def load_config() -> ChumpConfig:
    server_dir = Path(__file__).resolve().parents[1]
    project_root = server_dir.parent
    workspace_root = Path(
        os.environ.get("CHUMP_WORKSPACE_ROOT", str(project_root))
    ).resolve()
    data_dir = workspace_state_dir(workspace_root)
    migrate_legacy_workspace_state(workspace_root, data_dir)
    auth_config = load_auth_config()
    apply_auth_environment(auth_config)

    provider = normalize_provider_name(
        os.environ.get("CHUMP_PROVIDER")
        or string_value(auth_config.get("provider"))
        or DEFAULT_PROVIDER
    )

    env_model = os.environ.get("CHUMP_MODEL")
    auth_model = string_value(auth_config.get("model"))
    model = normalize_model_name(
        provider,
        env_model or auth_model or DEFAULT_MODELS[provider],
        strict=env_model is not None,
    )

    return ChumpConfig(
        host=os.environ.get("CHUMP_HOST", "127.0.0.1"),
        port=int(os.environ.get("CHUMP_PORT", "8080")),
        workspace_root=workspace_root,
        data_dir=data_dir,
        provider=provider,
        model=model,
        max_steps=int(os.environ.get("CHUMP_MAX_STEPS", "64")),
        retry_max_attempts=int(os.environ.get("CHUMP_RETRY_MAX_ATTEMPTS", "3")),
        retry_initial_delay=float(os.environ.get("CHUMP_RETRY_INITIAL_DELAY", "0.5")),
        retry_max_delay=float(os.environ.get("CHUMP_RETRY_MAX_DELAY", "8")),
        retry_backoff=float(os.environ.get("CHUMP_RETRY_BACKOFF", "2")),
        retry_jitter=bool_value(os.environ.get("CHUMP_RETRY_JITTER"), default=True),
        command_timeout=int(os.environ.get("CHUMP_COMMAND_TIMEOUT", "120")),
        managed_idle_timeout=int_value(
            os.environ.get("CHUMP_MANAGED_SERVER_IDLE_TIMEOUT")
        ),
        reasoning=load_reasoning_config(auth_config, provider),
        verbose=os.environ.get("CHUMP_VERBOSE", "1").lower()
        not in {"0", "false", "no"},
        allowed_origins=load_allowed_origins(),
        available_providers=load_available_providers(auth_config),
    )


def load_available_providers(auth_config: dict[str, Any]) -> tuple[str, ...]:
    credentials = auth_config.get("credentials")
    if not isinstance(credentials, dict):
        return ("chump_cloud",)
    providers = {"chump_cloud"} | set(credentials.keys())
    return tuple(sorted(providers))


def load_allowed_origins() -> tuple[str, ...]:
    raw = os.environ.get("CHUMP_ALLOWED_ORIGINS")
    if raw is None:
        return DEFAULT_ALLOWED_ORIGINS
    items = tuple(origin.strip() for origin in raw.split(",") if origin.strip())
    return items


def load_auth_config() -> dict[str, Any]:
    auth_path = auth_file_path()
    if not auth_path.exists():
        return {}
    try:
        data = json.loads(auth_path.read_text())
    except json.JSONDecodeError as error:
        raise ValueError(f"invalid auth config at {auth_path}: {error}") from error
    if not isinstance(data, dict):
        raise ValueError(f"invalid auth config at {auth_path}: expected object")
    return data


def auth_file_path() -> Path:
    configured = os.environ.get("CHUMP_AUTH_FILE")
    if configured:
        return Path(configured).expanduser().resolve()
    if xdg_data_home := os.environ.get("XDG_DATA_HOME"):
        return Path(xdg_data_home).expanduser() / "chump" / "auth.json"
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        base = Path(appdata) if appdata else Path.home() / "AppData" / "Roaming"
        return base / "chump" / "auth.json"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "chump" / "auth.json"
    return Path.home() / ".local" / "share" / "chump" / "auth.json"


def workspace_state_dir(workspace_root: Path) -> Path:
    configured = os.environ.get("CHUMP_STATE_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    return (_state_base_dir() / "workspaces" / _workspace_state_slug(workspace_root)).resolve()


def _state_base_dir() -> Path:
    if xdg_state_home := os.environ.get("XDG_STATE_HOME"):
        return Path(xdg_state_home).expanduser() / "chump"
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        base = Path(appdata) if appdata else Path.home() / "AppData" / "Roaming"
        return base / "chump"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "chump"
    return Path.home() / ".local" / "state" / "chump"


def _workspace_state_slug(workspace_root: Path) -> str:
    name = re.sub(r"[^a-z0-9_-]+", "-", workspace_root.name.lower()).strip("-")
    if not name:
        name = "workspace"
    digest = hashlib.sha256(str(workspace_root).encode("utf-8")).hexdigest()[:16]
    return f"{name}-{digest}"


def migrate_legacy_workspace_state(workspace_root: Path, data_dir: Path) -> None:
    data_dir.mkdir(parents=True, exist_ok=True)
    legacy_dir = workspace_root / ".chump"
    legacy_paths = [
        workspace_root / ".chump.sqlite3",
        legacy_dir / "chump.sqlite3",
        legacy_dir / "server.json",
        legacy_dir / "server.log",
        legacy_dir / "server.lock",
        legacy_dir / "client.log",
    ]

    for source in legacy_paths:
        _move_legacy_path(source, data_dir / source.name)


def _move_legacy_path(source: Path, destination: Path) -> None:
    if not source.exists():
        return
    if source.resolve() == destination.resolve():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        return
    shutil.move(str(source), str(destination))


def apply_auth_environment(
    auth_config: dict[str, Any],
    provider_name: str | None = None,
) -> None:
    provider = provider_name or normalize_provider_name(
        string_value(auth_config.get("provider"))
        or os.environ.get("CHUMP_PROVIDER", DEFAULT_PROVIDER)
    )
    credentials = auth_config.get("credentials")
    if not isinstance(credentials, dict):
        return
    provider_credentials = credentials.get(provider)
    if not isinstance(provider_credentials, dict):
        return
    for key, value in provider_credentials.items():
        if isinstance(key, str) and isinstance(value, str) and key not in os.environ:
            os.environ[key] = value


def string_value(value: Any) -> str | None:
    return value if isinstance(value, str) and value.strip() else None


def int_value(value: str | None) -> int | None:
    if value is None or not value.strip():
        return None
    parsed = int(value)
    return parsed if parsed > 0 else None


def bool_value(value: str | None, *, default: bool) -> bool:
    if value is None:
        return default
    return value.lower() not in {"0", "false", "no"}


def load_reasoning_config(
    auth_config: dict[str, Any] | None = None,
    provider: str | None = None,
) -> dict[str, Any] | None:
    reasoning: dict[str, Any] = {}
    effort = os.environ.get("CHUMP_REASONING_EFFORT")
    budget = os.environ.get("CHUMP_REASONING_BUDGET")
    configured = auth_config.get("reasoning") if auth_config else None

    if effort:
        if effort not in REASONING_EFFORTS:
            valid = ", ".join(sorted(REASONING_EFFORTS))
            raise ValueError(
                f"invalid CHUMP_REASONING_EFFORT={effort!r}; expected one of: {valid}"
            )
        reasoning["effort"] = effort
    if budget:
        reasoning["budget"] = int(budget)
    if not reasoning and isinstance(configured, dict):
        reasoning = normalize_reasoning_config(configured, provider)

    return reasoning or None


def normalize_reasoning_config(
    value: dict[str, Any] | None,
    provider: str | None,
) -> dict[str, Any] | None:
    if not value:
        return None
    mode = string_value(value.get("mode"))
    if mode == "none":
        return None
    normalized_provider = normalize_provider_name(provider or DEFAULT_PROVIDER)
    if normalized_provider == "chump_cloud":
        return None
    if normalized_provider == "google":
        budget = value.get("budget")
        if isinstance(budget, int):
            return {"budget": budget}
        if mode:
            return {"budget": reasoning_budget_for_mode(mode)}
        return None
    effort = string_value(value.get("effort")) or mode
    if not effort:
        return None
    if effort not in REASONING_EFFORTS:
        valid = ", ".join(sorted(REASONING_EFFORTS))
        raise ValueError(
            f"invalid reasoning effort={effort!r}; expected one of: {valid}"
        )
    return {"effort": effort}


def reasoning_budget_for_mode(mode: str) -> int:
    budgets = {
        "low": 1024,
        "high": 8192,
        "xhigh": 16384,
        "minimal": 512,
        "medium": 4096,
    }
    if mode not in budgets:
        valid = ", ".join(["none", *budgets])
        raise ValueError(f"invalid reasoning mode={mode!r}; expected one of: {valid}")
    return budgets[mode]


def normalize_provider_name(value: str) -> str:
    normalized = value.strip().lower().replace("-", "_")
    if normalized in {"workersai", "workers_ai"}:
        return "workers_ai"
    if normalized in {"chatgpt", "openai_codex"}:
        return "codex"
    if normalized in {"deepseek"}:
        return "deepseek"
    if normalized in {"chumpcloud", "chump_cloud"}:
        return "chump_cloud"
    if normalized not in DEFAULT_MODELS:
        valid = ", ".join(sorted(DEFAULT_MODELS))
        raise ValueError(f"invalid CHUMP_PROVIDER={value!r}; expected one of: {valid}")
    return normalized


def normalize_model_name(
    provider: str,
    model: str,
    *,
    strict: bool = True,
) -> str:
    normalized_provider = normalize_provider_name(provider)
    normalized_model = model.strip()
    allowed = PROVIDER_MODELS[normalized_provider]
    if normalized_model in allowed:
        return normalized_model
    if not strict:
        return DEFAULT_MODELS[normalized_provider]
    valid = ", ".join(sorted(allowed))
    raise ValueError(
        f"invalid model={model!r} for provider={normalized_provider!r}; expected one of: {valid}"
    )
