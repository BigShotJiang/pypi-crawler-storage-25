import requests
import json
import time
import sys
import os
import argparse
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
    TimeElapsedColumn,
)
from rich.syntax import Syntax
from rich.table import Table
from rich import box
from rich.align import Align
from rich.rule import Rule
from rich.text import Text
from rich.columns import Columns


def _enable_utf8_stdio_on_windows():
    if os.name != "nt":
        return
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


_enable_utf8_stdio_on_windows()

console = Console()

# ── Logging Configuration ──────────────────────────────
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILENAME = f"bg_{time.strftime('%Y%m%d_%H%M%S')}.log"
LOG_PATH = os.path.join(PACKAGE_DIR, LOG_FILENAME)

log_formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("uni_watch")
logger.setLevel(logging.DEBUG)

# File handler for background logging
file_handler = logging.FileHandler(LOG_PATH, "w", encoding="utf-8")
file_handler.setFormatter(log_formatter)
logger.addHandler(file_handler)

# Ensure no console handler is added to keep it "hidden"
# (Only rich console output will be visible to the user)

BASE_URL_V2 = "https://online.vtu.ac.in/api/v1"
BASE_URL_V1 = "https://online.vtu.ac.in/v1"

# ── Color Palette ─────────────────────────────────────
P = "#c084fc"       # purple  — primary brand
I = "#818cf8"       # indigo  — secondary
C = "#22d3ee"       # cyan    — accent
G = "#4ade80"       # green   — success
A = "#fbbf24"       # amber   — warning
R = "#f87171"       # red     — error
S = "#94a3b8"       # slate   — muted / rules
DIM = "#64748b"     # dim slate

LOGO = f"""\
[bold {P}]██████╗ ██████╗  ██████╗  ██████╗ ██████╗ ███████╗███████╗███████╗[/]
[bold {P}]██╔══██╗██╔══██╗██╔═══██╗██╔════╝ ██╔══██╗██╔════╝██╔════╝██╔════╝[/]
[bold {I}]██████╔╝██████╔╝██║   ██║██║  ███╗██████╔╝█████╗  ███████╗███████╗[/]
[bold {I}]██╔═══╝ ██╔══██╗██║   ██║██║   ██║██╔══██╗██╔══╝  ╚════██║╚════██║[/]
[bold {C}]██║     ██║  ██║╚██████╔╝╚██████╔╝██║  ██║███████╗███████║███████║[/]
[bold {C}]╚═╝     ╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝[/]"""

SUBTITLE = (
    f"[bold {P}]Uni Watch Auto-Progress[/]  "
    f"[{DIM}]v0.2.5  •  Fast  •  Parallel  •  Smart[/]"
)


def phase_rule(icon, title, color=S):
    """Print a styled section divider."""
    console.print()
    console.print(Rule(f"[bold {P}]{icon}  {title}[/]", style=color, align="left"))
    console.print()


class UniWatchBypasser:
    def __init__(self, email, password, version=2):
        self.email = email
        self.password = password
        self.version = version
        self.base_url = BASE_URL_V2 if version == 2 else BASE_URL_V1
        self.session = requests.Session()
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Origin": "https://online.vtu.ac.in",
            "Referer": "https://online.vtu.ac.in/",
        }
        
        if version == 2:
            headers.update({
                "Accept": "application/json",
                "Content-Type": "application/json",
            })
        else:
            headers.update({
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            })
            
        self.session.headers.update(headers)
        self._network_lock = threading.Lock()
        self._csrf_token = None

    def _wait_for_network(self):
        """Wait until network is available if it goes down."""
        with self._network_lock:
            # Check if we can still reach the base url
            while True:
                try:
                    requests.get(self.base_url, timeout=5)
                    break
                except:
                    logger.warning("Network down? Waiting 10 seconds before retry...")
                    time.sleep(10)

    def login(self):
        if self.version == 2:
            return self._login_v2()
        else:
            return self._login_v1()

    def _login_v2(self):
        login_url = f"{self.base_url}/auth/login"
        payload = {"email": self.email, "password": self.password}

        try:
            response = self.session.post(login_url, json=payload)
            data = response.json()
            logger.info(
                f"V2 Login Response: HTTP {response.status_code} | Body: {json.dumps(data)}"
            )

            if response.status_code == 200 and data.get("success"):
                user_name = data.get("data", {}).get("name", "User")
                return True, user_name
            else:
                msg = data.get("message", "Unknown Error")
                return False, msg
        except Exception as e:
            logger.error(f"V2 Login Error: {e}", exc_info=True)
            return False, str(e)

    def _login_v1(self):
        import re
        login_page_url = f"{self.base_url}/login"
        try:
            # 1. Get login page to extract CSRF token
            resp = self.session.get(login_page_url)
            token_match = re.search(r'name="_token"\s+value="([^"]+)"', resp.text)
            if not token_match:
                # Try meta tag if hidden input fails
                token_match = re.search(r'content="([^"]+)"\s+name="csrf-token"', resp.text)
            
            if not token_match:
                return False, "Could not find CSRF token on v1 login page"
            
            self._csrf_token = token_match.group(1)
            
            # 2. POST login credentials
            payload = {
                "_token": self._csrf_token,
                "email": self.email,
                "password": self.password
            }
            
            # v1 uses form-urlencoded
            login_resp = self.session.post(
                login_page_url, 
                data=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )
            
            logger.info(f"V1 Login Response: HTTP {login_resp.status_code}")
            
            # Check if we were redirected to dashboard or if dashboard content is present
            if "/student/student-dashboard" in login_resp.url or "student-dashboard" in login_resp.text:
                return True, self.email.split('@')[0] # v1 doesn't easily return name in JSON
            
            if "These credentials do not match our records" in login_resp.text:
                return False, "Invalid credentials"
                
            return False, "V1 Login failed (redirected back or error page)"
            
        except Exception as e:
            logger.error(f"V1 Login Error: {e}", exc_info=True)
            return False, str(e)

    def get_enrolled_courses(self):
        if self.version == 2:
            return self._get_enrolled_courses_v2()
        else:
            return self._get_enrolled_courses_v1()

    def _get_enrolled_courses_v2(self):
        enrollments_url = f"{self.base_url}/student/my-enrollments"
        try:
            response = self.session.get(enrollments_url, timeout=60)
            data = response.json()
            if response.status_code == 200 and data.get("success"):
                return data.get("data", [])
        except Exception as e:
            logger.error(f"V2 Enrollments Error: {e}", exc_info=True)
        return []

    def _get_enrolled_courses_v1(self):
        import re
        url = f"{self.base_url}/student/my-learning"
        try:
            response = self.session.get(url, timeout=60)
            if response.status_code != 200:
                logger.error(f"V1 Discovery: Failed to load my-learning page. Status: {response.status_code}")
                return []

            # Find course sections
            # Relaxed pattern to find course links and titles
            courses = []
            seen_slugs = set()
            
            # Find all my-course URLs first
            url_matches = re.finditer(r'href=[\'"]([^\'"]*?my-course/([^\'"]+))[\'"]', response.text)
            
            for m in url_matches:
                full_href = m.group(1)
                slug_with_qs = m.group(2)
                clean_slug = slug_with_qs.split('?')[0]
                
                if clean_slug.lower() in ['in-progress', 'completed', 'my-learning', 'all']:
                    continue
                    
                if clean_slug in seen_slugs:
                    continue
                    
                start_idx = m.start()
                end_idx = response.text.find('</a>', start_idx)
                if end_idx != -1:
                    inner_html = response.text[start_idx:end_idx]
                    title_match = re.search(r'<h[1-6][^>]*>(.*?)</h[1-6]>', inner_html, re.DOTALL)
                    if title_match:
                        title = title_match.group(1).strip()
                    else:
                        title = re.sub(r'<[^>]+>', '', inner_html).strip()
                else:
                    title = ""
                
                title = title.replace("&amp;", "&").replace("&nbsp;", " ")
                
                if not title or len(title) > 100 or "javascript" in title.lower():
                    title = clean_slug.replace("-", " ").title()

                # Search locally for progress percentage
                prog = "0"
                # Search up to next course link to avoid grabbing next course's progress
                next_idx = response.text.find('my-course/', end_idx if end_idx != -1 else start_idx + 50)
                if next_idx == -1:
                    next_idx = min(len(response.text), start_idx + 2000)
                local_block = response.text[start_idx:next_idx]
                
                # Look for digits before a % sign
                prog_match = re.search(r'(\d+)\s*%', local_block)
                if prog_match:
                    prog = prog_match.group(1)

                courses.append({
                    "details": {
                        "slug": slug_with_qs,
                        "title": title
                    },
                    "progress_percent": prog
                })
                seen_slugs.add(clean_slug)
            
            if not courses:
                logger.warning(f"V1 Discovery: Found 0 courses. Page length: {len(response.text)} bytes. Snippet: {response.text[:200]}...")
            else:
                logger.info(f"V1 Discovery: Found {len(courses)} courses")
            
            return courses
        except Exception as e:
            logger.error(f"V1 Enrollments Error: {e}", exc_info=True)
        return []

    def get_course_details(self, course_slug):
        if self.version == 2:
            return self._get_course_details_v2(course_slug)
        else:
            return self._get_course_details_v1(course_slug)

    def _get_course_details_v2(self, course_slug):
        course_url = f"{self.base_url}/student/my-courses/{course_slug}"
        try:
            response = self.session.get(course_url, timeout=60)
            data = response.json()
            if response.status_code == 200 and data.get("success"):
                return data.get("data", {})
        except Exception as e:
            logger.error(f"V2 Course Details Error for {course_slug}: {e}", exc_info=True)
        return None

    def _get_course_details_v1(self, course_slug):
        import re
        url = f"{self.base_url}/student/my-course/{course_slug}"
        try:
            resp = self.session.get(url)
            html = resp.text
            
            # 1. Extract enrollment_id and course_id from hidden inputs or scripts
            course_id_match = re.search(r'var\s+course_id\s*=\s*(\d+)', html)
            # 1. Extract session parameters
            csrf_match = re.search(r'name="csrf-token"\s+content="([^"]+)"', html)
            if not csrf_match:
                csrf_match = re.search(r'content="([^"]+)"\s+name="csrf-token"', html)
            
            self._csrf_token = csrf_match.group(1) if csrf_match else getattr(self, "_csrf_token", None)

            course_id_match = re.search(r'class="course_id"\s+value="(\d+)"', html)
            if not course_id_match:
                # Try generic name attribute if class fails
                course_id_match = re.search(r'name="course_id"\s+value="(\d+)"', html)
            
            enrollment_id_match = re.search(r'class="enrollment_id"\s+value="(\d+)"', html)
            if not enrollment_id_match:
                # Try script-based variable if hidden input fails
                enrollment_id_match = re.search(r'var\s+enrollment_id\s*=\s*[\'"]?(\d+)[\'"]?', html)

            course_id = course_id_match.group(1) if course_id_match else None
            enrollment_id = enrollment_id_match.group(1) if enrollment_id_match else None
            
            logger.debug(f"V1 Scraped: course_id={course_id}, enrollment_id={enrollment_id}, has_token={bool(self._csrf_token)}")
            
            # 2. Extract lectures
            # Using multiple strategies for maximum robustness
            lectures = []
            
            # Strategy A: Block-based parsing (find each lecture container)
            # We look for the play-list-item class and capture everything until the next one or a container end
            blocks = re.findall(r'<div[^>]+class="[^"]*?play-list-item[^"]*".*?(?=<div[^>]+class="[^"]*?play-list-item|$)', html, re.DOTALL)

            for block in blocks:
                # Extract UUID with flexible quotes/delimiters
                uuid_match = re.search(r'lecture_uuid\s*=\s*[\'"]?([a-f0-9-]+)', block)
                # Extract Lecture ID
                id_match = re.search(r'data-course_lecture\s*=\s*[\'"]?(\d+)', block)
                # Extract Title (try various common tags)
                title_match = re.search(r'<(?:p|span|h[1-6])[^>]*>(.*?)</(?:p|span|h[1-6])>', block, re.DOTALL)
                
                if uuid_match and id_match:
                    uuid = uuid_match.group(1)
                    lecture_id = id_match.group(1)
                    title = title_match.group(1).strip() if title_match else f"Lecture {lecture_id}"
                    title = re.sub(r'<[^>]+>', '', title)
                    
                    is_finished = any(c in block for c in ["watchFinishedCourse", "completed", "check-circle"])
                    
                    lectures.append({
                        "id": lecture_id,
                        "lecture_uuid": uuid,
                        "title": title,
                        "is_completed": is_finished
                    })

            # Strategy B: Loose Discovery (fallback)
            if not lectures:
                logger.debug("V1: Block parsing yielded 0 lectures, trying loose correlation...")
                all_uuids = re.findall(r'lecture_uuid\s*=\s*[\'"]?([a-f0-9-]+)', html)
                all_ids = re.findall(r'data-course_lecture\s*=\s*[\'"]?(\d+)', html)
                
                if all_uuids and all_ids and len(all_uuids) == len(all_ids):
                    for i in range(len(all_uuids)):
                        lectures.append({
                            "id": all_ids[i],
                            "lecture_uuid": all_uuids[i],
                            "title": f"Lecture {all_ids[i]}",
                            "is_completed": False
                        })

            # Strategy C: Find anchor tags containing lecture_uuid
            if not lectures:
                logger.debug("V1: Trying anchor tag parsing for lectures...")
                anchor_matches = re.finditer(r'<a[^>]+href=[\'"]([^\'"]*?lecture_uuid=([a-f0-9-]+)[^\'"]*)[\'"][^>]*>(.*?)</a>', html, re.DOTALL)
                seen_uuids = set()
                for m in anchor_matches:
                    full_href = m.group(1)
                    uuid = m.group(2)
                    inner_html = m.group(3)
                    
                    if uuid in seen_uuids:
                        continue
                    seen_uuids.add(uuid)
                    
                    title_match = re.search(r'<h[1-6][^>]*>(.*?)</h[1-6]>', inner_html, re.DOTALL)
                    if title_match:
                        title = title_match.group(1).strip()
                    else:
                        title = re.sub(r'<[^>]+>', '', inner_html).strip()
                    title = title.replace("&amp;", "&").replace("&nbsp;", " ")
                    if not title or len(title) > 100:
                        title = f"Lecture {uuid[:8]}"
                        
                    is_finished = any(c in inner_html for c in ["watchFinishedCourse", "completed", "check-circle", "is-completed", "done", "fa-check"])
                    
                    # Extract numeric ID if possible
                    id_match = re.search(r'data-course_lecture\s*=\s*[\'"]?(\d+)', inner_html)
                    lecture_id = id_match.group(1) if id_match else uuid
                    
                    lectures.append({
                        "id": lecture_id,
                        "lecture_uuid": uuid,
                        "title": title,
                        "is_completed": is_finished
                    })

            # Debug Capture: if still 0, save the page for analysis
            if not lectures:
                debug_file = "v1_course_details_debug.html"
                try:
                    with open(debug_file, "w", encoding="utf-8") as f:
                        f.write(html)
                    logger.warning(f"V1: 0 lectures found for {course_slug}. Saved page to {debug_file} for analysis.")
                except Exception as e:
                    logger.error(f"Failed to save debug HTML: {e}")
                    
                # Strategy D: If the slug itself contains the lecture_uuid, use it as a 1-item lecture list
                if "?lecture_uuid=" in course_slug:
                    uuid = course_slug.split("lecture_uuid=")[-1].split("&")[0]
                    logger.debug(f"V1 Strategy D: Extracted lecture from URL query string: {uuid}")
                    lectures.append({
                        "id": uuid,
                        "lecture_uuid": uuid,
                        "title": "Current Module (From Dashboard URL)",
                        "is_completed": False
                    })

            return {
                "id": course_id,
                "course_id": course_id,
                "enrollment_id": enrollment_id,
                "lessons": [
                    {
                        "name": "Course Content",
                        "lectures": lectures
                    }
                ]
            }
        except Exception as e:
            logger.error(f"V1 Course Details Error: {e}", exc_info=True)
        return None

    def _wait_for_network(self):
        """Block until network connectivity is restored. Thread-safe."""
        with self._network_lock:
            # Quick re-check — another thread may have already recovered
            try:
                requests.head("https://online.vtu.ac.in", timeout=5)
                return
            except (requests.ConnectionError, requests.Timeout):
                pass

            console.print(
                Panel(
                    Align.center(
                        f"[bold {R}]⚠  Network connection lost[/]\n\n"
                        f"[{DIM}]Polling every 3 seconds until it's back…[/]"
                    ),
                    border_style=R,
                    box=box.ROUNDED,
                    padding=(1, 4),
                )
            )

            while True:
                time.sleep(3)
                try:
                    requests.head("https://online.vtu.ac.in", timeout=5)
                    console.print(
                        f"  [{G}]✔  Network restored — resuming automatically[/]\n"
                    )
                    return
                except (requests.ConnectionError, requests.Timeout):
                    continue

    def mark_video_complete(self, course_slug, lecture_id, progress_ctx, task_id, extra_ids=None):
        if self.version == 2:
            return self._mark_video_complete_v2(course_slug, lecture_id, progress_ctx, task_id)
        else:
            return self._mark_video_complete_v1(course_slug, lecture_id, progress_ctx, task_id, extra_ids)

    def _mark_video_complete_v2(self, course_slug, lecture_id, progress_ctx, task_id):
        progress_url = (
            f"{self.base_url}/student/my-courses/{course_slug}"
            f"/lectures/{lecture_id}/progress"
        )

        max_attempts = 150
        current_time = 0

        for attempt in range(1, max_attempts + 1):
            current_time += 120
            payload = {
                "current_time_seconds": current_time,
                "total_duration_seconds": 3600,
                "seconds_just_watched": 120,
            }

            try:
                response = self.session.post(progress_url, json=payload, timeout=60)
                
                try:
                    res_data = response.json()
                except (requests.exceptions.JSONDecodeError, ValueError) as e:
                    logger.error(f"V2 JSON Decode Error ({lecture_id}): {e} | Status: {response.status_code} | Text: {repr(response.text)[:500]}")
                    return False, -1

                data_dict = res_data.get("data", {})
                is_completed = data_dict.get("is_completed", False)
                percent = data_dict.get("percent", 0)

                logger.info(
                    f"V2 Progress Ping ({lecture_id}) Att {attempt}: "
                    f"HTTP {response.status_code} | Body: {json.dumps(res_data)}"
                )

                progress_ctx.update(task_id, completed=percent)

                if is_completed or percent >= 98:
                    progress_ctx.update(task_id, completed=100)
                    return True, percent

                if attempt == max_attempts:
                    return False, percent

                time.sleep(0.5)

            except (requests.ConnectionError, requests.Timeout):
                logger.error(f"Network error on V2 lecture {lecture_id}, attempt {attempt}")
                self._wait_for_network()
                current_time -= 120
                continue
            except Exception as e:
                logger.error(f"V2 Progress Ping Error ({lecture_id}): {e}", exc_info=True)
                return False, -1
        
    def _mark_video_complete_v1(self, course_slug, lecture_id_num, progress_ctx, task_id, extra_ids):
        # extra_ids contains course_id and enrollment_id for v1
        progress_url = f"{self.base_url}/student/my-learning-video-inprogress"
        
        course_id = extra_ids.get("course_id")
        enrollment_id = extra_ids.get("enrollment_id")
        lecture_uuid = extra_ids.get("lecture_uuid", "")
        
        max_attempts = 150
        current_time_seconds = 0
        total_duration_seconds = 3600 # Assuming an hour if not known

        for attempt in range(1, max_attempts + 1):
            current_time_seconds += 120
            
            # v1 uses form-urlencoded POST
            payload = {
                "_token": self._csrf_token,
                "course_id": course_id,
                "lecture_id": lecture_id_num,
                "lecture_uuid": lecture_uuid,
                "enrollment_id": enrollment_id,
                "video_current_time": current_time_seconds,
                "video_end_time": total_duration_seconds
            }

            try:
                clean_slug = course_slug.split('?')[0] if course_slug else ""
                referer_url = f"{self.base_url}/student/my-course/{clean_slug}?lecture_uuid={lecture_uuid}" if clean_slug else f"{self.base_url}/student/my-course/{course_id if course_id else ''}"

                response = self.session.post(
                    progress_url, 
                    data=payload,
                    headers={
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Referer": referer_url,
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    timeout=60
                )
                
                try:
                    res_data = response.json()
                    logger.info(f"V1 Progress Ping Att {attempt}: HTTP {response.status_code} | Body: {json.dumps(res_data)}")
                except:
                    logger.info(f"V1 Progress Ping Att {attempt}: HTTP {response.status_code} | Body: (Non-JSON)")
                    res_data = {}

                # Calculate progress percent manually for display
                percent = min(round((current_time_seconds / total_duration_seconds) * 100), 100)
                progress_ctx.update(task_id, completed=percent)

                # Threshold to trigger completion
                if percent >= 98 or attempt >= 10: # Allow early completion if pings are working
                    # Step 2: Send completion trigger (GET)
                    complete_url = f"{self.base_url}/student/my-learning-video-completed"
                    params = {
                        "course_id": course_id,
                        "lecture_id": lecture_id_num,
                        "enrollment_id": enrollment_id
                    }
                    try:
                        c_resp = self.session.get(complete_url, params=params, timeout=20)
                        logger.info(f"V1 Completion Trigger Sent: {lecture_id_num} | Status: {c_resp.status_code}")
                    except Exception as e:
                        logger.warning(f"V1 Completion Trigger Failed: {e}")

                    progress_ctx.update(task_id, completed=100)
                    return True, 100

                if attempt == max_attempts:
                    return False, percent

                time.sleep(0.5)

            except (requests.ConnectionError, requests.Timeout):
                logger.error(f"Network error on V1 lecture {lecture_id_num}, attempt {attempt}")
                self._wait_for_network()
                current_time_seconds -= 120
                continue
            except Exception as e:
                logger.error(f"V1 Progress Ping Error ({lecture_id_num}): {e}", exc_info=True)
                return False, -1

        return False, 0


def _process_lecture(bypasser, course_slug, lecture_id, lecture_title, progress, task_id, extra_ids=None):
    """Worker function for parallel lecture processing."""
    success, percent = bypasser.mark_video_complete(
        course_slug, lecture_id, progress, task_id, extra_ids=extra_ids
    )

    if success:
        progress.update(
            task_id,
            description=f"[bold {G}]✔  {lecture_title}[/]",
        )
    elif percent == -1:
        progress.update(
            task_id,
            description=f"[bold {R}]✖  {lecture_title}  [dim](error)[/dim][/]",
        )
    else:
        progress.update(
            task_id,
            description=f"[bold {A}]⚠  {lecture_title}  [dim](capped {percent}%)[/dim][/]",
        )

    return {
        "course_slug": course_slug,
        "lecture_id": lecture_id,
        "lecture_title": lecture_title,
        "success": success,
        "percent": percent,
        "extra_ids": extra_ids,
    }


def select_courses(courses):
    """Prompt user to choose auto-run or manual course selection."""
    console.print(
        f"  [{C}]❶[/]  Auto-run all courses\n"
        f"  [{C}]❷[/]  Select specific courses\n"
    )

    mode = Prompt.ask(
        f"  [bold {C}]›[/] [bold]Choice[/]",
        choices=["1", "2"],
        default="1",
    )

    if mode == "1":
        return courses

    # Manual selection
    console.print()
    for i, enrollment in enumerate(courses, 1):
        details = enrollment.get("details", {})
        prog = enrollment.get("progress_percent", "0")
        console.print(
            f"    [{C}]{i}[/]  {details.get('title', 'Unknown')} "
            f"[{DIM}]· {prog}% done[/]"
        )

    console.print()
    selection = Prompt.ask(
        f"  [bold {C}]›[/] [bold]Enter course numbers[/] [{DIM}]comma-separated[/]"
    )

    try:
        indices = [int(x.strip()) - 1 for x in selection.split(",")]
        selected = [courses[i] for i in indices if 0 <= i < len(courses)]
        if not selected:
            console.print(f"  [{A}]No valid selection — running all courses.[/]")
            return courses
        return selected
    except (ValueError, IndexError):
        console.print(f"  [{A}]Invalid input — running all courses.[/]")
        return courses


def select_workers():
    """Prompt user to choose the number of parallel workers."""
    console.print()
    console.print(
        f"  [bold {A}]⚠  Risk Warning:[/]\n"
        f"  [{DIM}]Workers process videos simultaneously. More workers = faster completion.\n"
        f"  However, using many workers might look unnatural to the portal servers.\n"
        f"  You can choose a maximum of 3 workers for account safety.[/]\n"
    )
    worker_str = Prompt.ask(
        f"  [bold {C}]›[/] [bold]Number of workers[/] [{DIM}]1-3, default 1[/]",
        default="1",
    )
    try:
        workers = int(worker_str)
        if workers < 1:
            workers = 1
        elif workers > 3:
            workers = 3
    except ValueError:
        workers = 1
    return workers


def print_summary(stats, elapsed_secs=None):
    """Print a beautiful summary dashboard."""
    total = stats["total"]
    skipped = stats["skipped"]
    completed = stats["completed"]
    failed = stats["failed"]

    # Build percentage bar
    done_pct = ((skipped + completed) / total * 100) if total else 0

    # Stats grid
    grid = Table.grid(padding=(0, 3))
    grid.add_column(justify="right", style="bold")
    grid.add_column(justify="left")

    grid.add_row(f"[{DIM}]Total Lectures[/]", f"[bold]{total}[/]")
    grid.add_row(f"[{DIM}]Skipped[/] [{DIM}](already done)[/]", f"[{S}]{skipped}[/]")
    grid.add_row(f"[{DIM}]Newly Completed[/]", f"[bold {G}]{completed}[/]")
    grid.add_row(f"[{DIM}]Failed[/]", f"[bold {R}]{failed}[/]" if failed else f"[{G}]0[/]")

    if elapsed_secs is not None:
        mins = int(elapsed_secs // 60)
        secs = int(elapsed_secs % 60)
        grid.add_row(f"[{DIM}]Elapsed Time[/]", f"[{C}]{mins}m {secs}s[/]")

    grid.add_row("", "")
    grid.add_row(
        f"[{DIM}]Coverage[/]",
        f"[bold {G}]{done_pct:.1f}%[/]" if done_pct >= 90 else f"[bold {A}]{done_pct:.1f}%[/]",
    )

    console.print(
        Panel(
            Align.center(grid),
            title=f"[bold {C}]📊  Run Summary[/]",
            border_style=I,
            box=box.ROUNDED,
            padding=(1, 4),
        )
    )


def view_logs():
    if not os.path.exists(LOG_PATH):
        console.print(f"  [{A}]⚠  Log file not found at: {LOG_PATH}[/]")
        return

    console.print(
        Panel(
            Align.center(f"[bold {C}]◷  Recent Background Logs[/]\n[{DIM}]{LOG_PATH}[/]"),
            border_style=C,
            padding=(1, 2),
        )
    )

    try:
        with open(LOG_PATH, "r", encoding="utf-8") as f:
            lines = f.readlines()
            recent = "".join(lines[-100:]) # Show more lines for full view if needed
            
        syntax = Syntax(recent, "log", theme="monokai", word_wrap=True, line_numbers=True)
        console.print(syntax)
        console.print(f"\n  [{DIM}]Full log available at:[/] [bold]{LOG_PATH}[/]")
    except Exception as e:
        console.print(f"  [{R}]✖  Error reading log file: {e}[/]")


def main():
    parser = argparse.ArgumentParser(description="Online Video Automation CLI")
    parser.add_argument(
        "--log", action="store_true", help="Log all activities to a background file"
    )
    parser.add_argument(
        "--view", action="store_true", help="Used with --log to view the logs"
    )
    args = parser.parse_args()

    # Handle log viewing: uni-watch --view --log
    if args.view and args.log:
        view_logs()
        sys.exit(0)

    os.system("cls" if os.name == "nt" else "clear")

    # ── Header ────────────────────────────────────────
    console.print(
        Panel(
            Align.center(f"{LOGO}\n{SUBTITLE}"),
            border_style=P,
            box=box.DOUBLE,
            padding=(1, 4),
        )
    )

    # Old --log behavior (compatibility or standalone view)
    if args.log and not args.view:
        # User just typed --log, we can either show logs or just proceed with logging enabled
        # The requirement says --log should log to bg.log and be hidden.
        # So we just proceed.
        pass

    start_time = time.time()

    # ── Phase 1: Authentication ───────────────────────
    phase_rule("🔐", "Authentication")
    
    console.print(f"  [{DIM}]* Login constitutes agreement to LICENSE & T&C (Zero liability)[/]\n")

    email = Prompt.ask(f"  [bold {C}]✉[/]  [bold]Email[/]")
    password = Prompt.ask(f"  [bold {C}]🔑[/] [bold]Password[/]", password=True)

    console.print()
    console.print(f"  [{C}]❶[/]  New Version (v2)")
    console.print(f"  [{C}]❷[/]  Old Version (v1)")
    console.print()
    version_choice = Prompt.ask(
        f"  [bold {C}]›[/] [bold]Select Portal Version[/]",
        choices=["1", "2"],
        default="1"
    )
    version = 2 if version_choice == "1" else 1

    bypasser = UniWatchBypasser(email, password, version=version)

    with console.status(
        f"  [{A}]Authenticating securely…[/]", spinner="dots12"
    ):
        success, msg_or_name = bypasser.login()

    if not success:
        console.print(
            Panel(
                f"[bold {R}]✖  Authentication Failed[/]\n[{DIM}]{msg_or_name}[/]",
                border_style=R,
                box=box.ROUNDED,
                padding=(1, 3),
            )
        )
        sys.exit(1)

    console.print(
        f"  [{G}]✔[/]  Authenticated as [bold {C}]{msg_or_name}[/]\n"
    )

    # ── Phase 2: Course Discovery ─────────────────────
    phase_rule("📚", "Course Discovery")

    with console.status(
        f"  [{A}]Fetching enrolled courses…[/]", spinner="dots12"
    ):
        courses = bypasser.get_enrolled_courses()

    if not courses:
        console.print(
            Panel(
                f"[bold {R}]✖  No enrolled courses found on this account.[/]",
                border_style=R,
            )
        )
        sys.exit(0)

    # Courses table
    table = Table(
        box=box.SIMPLE_HEAVY,
        border_style=I,
        header_style=f"bold {P}",
        row_styles=[f"{DIM}", ""],
        padding=(0, 2),
        show_edge=False,
    )
    table.add_column("#", justify="center", style=C, no_wrap=True, width=4)
    table.add_column("Course", style="bold white", ratio=3)
    table.add_column("Progress", justify="right", style=G, width=12)

    for i, enrollment in enumerate(courses, 1):
        details = enrollment.get("details", {})
        prog = enrollment.get("progress_percent", "0")
        prog_float = float(prog) if prog else 0

        # Color-code progress
        if prog_float >= 90:
            prog_display = f"[bold {G}]{prog}%  ✓[/]"
        elif prog_float >= 50:
            prog_display = f"[{A}]{prog}%[/]"
        else:
            prog_display = f"[{S}]{prog}%[/]"

        table.add_row(str(i), details.get("title", "Unknown"), prog_display)

    console.print(Panel(table, border_style=I, box=box.ROUNDED, padding=(1, 2)))

    # Course selection
    console.print()
    selected_courses = select_courses(courses)

    num_workers = select_workers()

    console.print(
        f"\n  [{DIM}]▸ {len(selected_courses)} course(s) queued  "
        f"·  {num_workers} parallel workers[/]\n"
    )

    # ── Phase 3: Processing ───────────────────────────
    phase_rule("⚡", "Processing")

    stats = {"total": 0, "skipped": 0, "completed": 0, "failed": 0}
    failed_lectures = []

    for enrollment in selected_courses:
        details = enrollment.get("details", {})
        course_slug = details.get("slug")
        course_title = details.get("title")

        if not course_slug:
            continue

        console.print(
            Panel(
                f"  [bold white]{course_title}[/]",
                border_style=P,
                box=box.HEAVY,
                padding=(0, 2),
            )
        )

        with console.status(
            f"  [{DIM}]Loading course contents…[/]", spinner="dots12"
        ):
            course_data = bypasser.get_course_details(course_slug)

        if not course_data:
            console.print(
                f"  [bold {R}]✖  Could not load details for {course_title}[/]"
            )
            continue

        lessons = course_data.get("lessons", [])

        for week in lessons:
            week_name = week.get("name", "Unknown Week")
            lectures = week.get("lectures", [])

            # Split into already-done vs pending
            pending = []
            for lec in lectures:
                stats["total"] += 1
                if lec.get("is_completed", False):
                    stats["skipped"] += 1
                else:
                    pending.append(lec)

            skipped = len(lectures) - len(pending)

            # Week header
            console.print(
                f"\n  [{I}]┌─[/] [bold {I}]{week_name}[/]  "
                f"[{DIM}]{len(lectures)} lectures[/]"
                + (f"  [{G}]·  {skipped} done[/]" if skipped else "")
            )

            if not pending:
                console.print(
                    f"  [{I}]└─[/] [{G}]All lectures already completed  ✓[/]"
                )
                continue

            if skipped > 0:
                console.print(
                    f"  [{I}]│[/]  [{DIM}]↳ {skipped} skipped (already done)[/]"
                )

            # Process pending lectures in parallel
            with Progress(
                SpinnerColumn(style=C),
                TextColumn("  {task.description}"),
                BarColumn(
                    bar_width=30,
                    complete_style=G,
                    finished_style=f"bold {G}",
                    pulse_style=I,
                ),
                TaskProgressColumn(),
                TimeElapsedColumn(),
                console=console,
                transient=False,
            ) as progress:
                futures = {}

                with ThreadPoolExecutor(max_workers=num_workers) as executor:
                    for lec in pending:
                        lid = lec.get("id")
                        ltitle = lec.get("title", f"Lecture {lid}")
                        task_id = progress.add_task(
                            f"[{C}]{ltitle}[/]", total=100, completed=0
                        )

                        # For v1, we gather extra IDs needed for progress pings
                        extra_ids = None
                        if bypasser.version == 1:
                            extra_ids = {
                                "course_id": course_data.get("course_id"),
                                "enrollment_id": course_data.get("enrollment_id"),
                                "lecture_uuid": lec.get("lecture_uuid")
                            }

                        future = executor.submit(
                            _process_lecture,
                            bypasser,
                            course_slug,
                            lid,
                            ltitle,
                            progress,
                            task_id,
                            extra_ids
                        )
                        futures[future] = (lid, ltitle)

                    for future in as_completed(futures):
                        try:
                            result = future.result()
                            if result["success"]:
                                stats["completed"] += 1
                            else:
                                stats["failed"] += 1
                                failed_lectures.append(result)
                        except Exception as e:
                            logger.error(f"Worker Error: {e}", exc_info=True)
                            stats["failed"] += 1
                            # Create a dummy result for the failed_lectures list
                            failed_lectures.append({
                                "lecture_title": "Unknown (Worker Error)",
                                "success": False,
                                "percent": -1
                            })

            console.print(f"  [{I}]└─[/] [{DIM}]Week complete[/]")

        console.print()

    # ── Phase 4: Results ──────────────────────────────
    elapsed = time.time() - start_time
    phase_rule("📊", "Results")
    print_summary(stats, elapsed)

    # ── Retry failed lectures ─────────────────────────
    if failed_lectures:
        console.print()
        console.print(
            Panel(
                Align.center(
                    f"[bold {A}]⚠  {len(failed_lectures)} lecture(s) failed[/]\n"
                    f"[{DIM}]You can retry them now before exiting.[/]"
                ),
                border_style=A,
                box=box.ROUNDED,
                padding=(1, 3),
            )
        )

        retry = Confirm.ask(
            f"\n  [bold {C}]›[/] [bold]Retry failed lectures?[/]", default=True
        )

        if retry:
            phase_rule("🔄", "Retrying")
            retry_recovered = 0

            with Progress(
                SpinnerColumn(style=C),
                TextColumn("  {task.description}"),
                BarColumn(
                    bar_width=30,
                    complete_style=G,
                    finished_style=f"bold {G}",
                    pulse_style=I,
                ),
                TaskProgressColumn(),
                TimeElapsedColumn(),
                console=console,
                transient=False,
            ) as progress:
                for item in failed_lectures:
                    task_id = progress.add_task(
                        f"[{C}]{item['lecture_title']}[/]", total=100, completed=0
                    )
                    result = _process_lecture(
                        bypasser,
                        item["course_slug"],
                        item["lecture_id"],
                        item["lecture_title"],
                        progress,
                        task_id,
                        extra_ids=item.get("extra_ids")
                    )
                    if result["success"]:
                        retry_recovered += 1
                        stats["completed"] += 1
                        stats["failed"] -= 1

            console.print(
                f"\n  [{G}]✔  Recovered {retry_recovered}/{len(failed_lectures)} lectures[/]"
            )

            elapsed = time.time() - start_time
            console.print()
            print_summary(stats, elapsed)

    # ── Done ──────────────────────────────────────────
    console.print()
    console.print(
        Panel(
            Align.center(
                f"[bold {G}]🎉  All done![/]\n"
                f"[{DIM}]Check the online portal to verify your progress.[/]"
            ),
            border_style=G,
            box=box.DOUBLE,
            padding=(1, 4),
        )
    )
    console.print()


if __name__ == "__main__":
    main()
