# -*- coding: utf-8 -*-
"""
ConfigServer-based dynamic configuration handler.
Replaces ACM configuration management with SLS ConfigServer.

This implementation is aligned with the Java version:
io.opentelemetry.javaagent.tooling.config.ConfigServerConfigHandler
"""

import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from typing import Any, Callable, Dict, List, Optional, Set

from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)

# Dummy credentials for ConfigServer (uses anonymous auth)
DUMMY_AK = "DUMMY_AK"
DUMMY_SK = "DUMMY_SK"

# Agent constants
AGENT_TYPE_APM_PYTHON = "apm_python"
AGENT_STATUS_RUNNING = "running"
AGENT_ATTRIBUTE_SERVICE = "service"
AGENT_ATTRIBUTE_WORKSPACE = "workspace"

# Config type constants
CONFIG_TYPE_APM_GLOBAL = "apm_global"
CONFIG_TYPE_APM_TRACE = "apm_trace"
CONFIG_TYPE_APM_CONVERGENCE = "apm_convergence"
CONFIG_TYPE_APM_INTACHEAP = "apm_intacheap"
CONFIG_TYPE_APM_CUSTOM_EXTRACT = "apm_custom_extract"
CONFIG_TYPE_APM_USER_METHOD = "apm_user_method"
CONFIG_TYPE_APM_SELF_PROTECT = "apm_self_protect"
CONFIG_TYPE_APM_BIZ_TRACE = "apm_biz_trace"
CONFIG_TYPE_APM_BIZ_TRACE_GLOBAL = "apm_biz_trace_global"

# All config types that need to be fetched
ALL_CONFIG_TYPES = [
    CONFIG_TYPE_APM_GLOBAL,
    CONFIG_TYPE_APM_TRACE,
    CONFIG_TYPE_APM_CONVERGENCE,
    CONFIG_TYPE_APM_INTACHEAP,
    CONFIG_TYPE_APM_CUSTOM_EXTRACT,
    CONFIG_TYPE_APM_USER_METHOD,
]

# Configuration poll interval in seconds
DEFAULT_POLL_INTERVAL = int(os.getenv("APSARA_APM_CONFIG_POLL_INTERVAL", "30"))


class ConfigInfo:
    """Holds configuration content and version."""

    def __init__(self, config: str = "", version: int = -1):
        self.config = config
        self.version = version


class GlobalConfigState:
    """
    Manages global configuration state with thread-safe access.
    
    Aligned with Java's GlobalConfigState inner class in ConfigServerConfigHandler.
    """

    def __init__(self):
        self._lock = Lock()
        self._config_map: Dict[str, ConfigInfo] = {}
        self._config_set_hash: int = -1
        self._attributes_hash: int = -1
        self._sequence: int = 0
        self._last_poll_timestamp: float = -1

    def update_config(self, config_type: str, config: str, version: int) -> None:
        """
        Update configuration for a specific type.
        
        For apm_user_method and apm_trace types, the new config is merged with
        the existing apm_trace config (new config takes priority).
        This follows the Java implementation's merging logic.
        """
        with self._lock:
            try:
                # Handle apm_user_method and apm_trace config merging
                # Similar to Java's updateConfig logic
                if config_type in (CONFIG_TYPE_APM_USER_METHOD, CONFIG_TYPE_APM_TRACE):
                    # Merge with existing apm_trace config if present
                    if CONFIG_TYPE_APM_TRACE in self._config_map:
                        old_config = self._config_map[CONFIG_TYPE_APM_TRACE].config
                        if old_config:
                            try:
                                # Merge new config with old config (new config takes priority)
                                config = self._merge_json(old_config, config)
                                _logger.debug(f"[ConfigServerConfigHandler] Merged config for {config_type}")
                            except Exception as e:
                                _logger.warning(f"[ConfigServerConfigHandler] Failed to merge config: {e}")
                    
                    # Both apm_user_method and apm_trace are stored under apm_trace
                    config_type = CONFIG_TYPE_APM_TRACE
                    
            except Exception as e:
                _logger.error(f"[ConfigServerConfigHandler] update config fail, content={config}, error={e}")
            
            self._config_map[config_type] = ConfigInfo(config, version)
    
    def _merge_json(self, old_config: str, new_config: str) -> str:
        """
        Merge new config into old config. New config values take priority.
        
        This is similar to Java's JsonUtil2.mergeJson method.
        """
        try:
            old_json: Dict[str, Any] = json.loads(old_config) if old_config else {}
            new_json: Dict[str, Any] = json.loads(new_config) if new_config else {}
            
            # Merge: start with old, update with new (new takes priority)
            merged: Dict[str, Any] = old_json.copy()
            self._deep_merge(merged, new_json)
            
            return json.dumps(merged)
        except json.JSONDecodeError:
            # If parsing fails, return new config as-is
            return new_config
    
    def _deep_merge(self, base: Dict[str, Any], override: Dict[str, Any]) -> None:
        """Recursively merge override into base dict. Override values take priority."""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value

    def get_config_version(self, config_type: str) -> int:
        """Get the version of a specific config type."""
        config_info = self._config_map.get(config_type)
        return config_info.version if config_info else -1

    def get_config(self, config_type: str) -> Optional[ConfigInfo]:
        """Get config info for a specific type."""
        return self._config_map.get(config_type)

    def update_hashes(self, config_set_hash: int, attributes_hash: int) -> None:
        """Update hash values for config set and attributes."""
        self._config_set_hash = config_set_hash
        self._attributes_hash = attributes_hash

    @property
    def config_set_hash(self) -> int:
        return self._config_set_hash

    @property
    def attributes_hash(self) -> int:
        return self._attributes_hash

    def get_and_increment_sequence(self) -> int:
        """Get current sequence and increment it."""
        with self._lock:
            seq = self._sequence
            self._sequence += 1
            return seq

    @property
    def last_poll_timestamp(self) -> float:
        return self._last_poll_timestamp

    @last_poll_timestamp.setter
    def last_poll_timestamp(self, value: float) -> None:
        self._last_poll_timestamp = value


class ListenerInfo:
    """
    Listener information class, containing the listener callback and its associated config type.
    
    Aligned with Java's ListenerInfo inner class in ConfigServerConfigHandler.
    """
    
    def __init__(self, callback: Callable[[str], None], config_type: str):
        """
        Initialize ListenerInfo.
        
        Args:
            callback: Callback function that receives the config content as parameter
            config_type: The config type this listener is interested in (e.g., apm_trace, apm_global)
        """
        self.callback = callback
        self.config_type = config_type


class ConfigServerConfigHandler:
    """
    SLS ConfigServer-based dynamic configuration handler.
    Manages configuration fetching and callback notifications.
    
    Aligned with Java's ConfigServerConfigHandler class.
    """

    def __init__(self):
        self._sls_client = None
        self._global_config_state = GlobalConfigState()
        # Legacy callbacks (without config type, called for any change)
        self._callback_funcs: List[Callable[[], None]] = []
        # Per-config-type listeners (aligned with Java's listenerInfos)
        self._listener_infos: List[ListenerInfo] = []
        self._poll_executor: Optional[ThreadPoolExecutor] = None
        self._is_init = False
        self._region_id = ""
        self._app_id = ""
        self._poll_interval = DEFAULT_POLL_INTERVAL
        self._stop_polling = False

    def init_config_client(self, region_id: str, app_id: str) -> None:
        """
        Initialize the ConfigServer client.

        Args:
            region_id: The region ID for the application
            app_id: The application ID
        """
        try:
            self._region_id = region_id
            self._app_id = app_id.replace('@', '-')

            # Detect reachable endpoint and initialize SLS client
            endpoint = self._detect_endpoint()
            if not endpoint:
                _logger.error("Failed to detect ConfigServer endpoint, dynamic config will not be supported")
                return

            self._init_sls_client(endpoint)

            if self._sls_client:
                # Start polling for configuration
                self._start_config_polling()
                self._is_init = True
                _logger.info(f"ConfigServer client initialized successfully with endpoint: {endpoint}")
        except Exception as e:
            _logger.error(f"Failed to init ConfigServer client: {e}")

    def _detect_endpoint(self) -> str:
        """Detect and return a reachable SLS endpoint."""
        from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state

        try:
            one_endpoint = global_arms_endpoints_state.get_one_endpoint()
            if one_endpoint:
                # Extract the base endpoint (remove project prefix if present)
                idx = one_endpoint.find(".")
                if idx > 0:
                    return one_endpoint[idx + 1:]
                return one_endpoint
        except Exception as e:
            _logger.warning(f"Failed to detect endpoint: {e}")

        # Fallback to region-based endpoint
        return f"{self._region_id}.log.aliyuncs.com"

    def _init_sls_client(self, endpoint: str) -> None:
        """Initialize the SLS client with the given endpoint."""
        try:
            from aliyun.configserver.client.client import Client
            from aliyun.configserver.pkg.apsara.apm.alibabacloud_tea_openapi.models import Config

            config = Config(
                access_key_id=DUMMY_AK,
                access_key_secret=DUMMY_SK,
                endpoint=endpoint,
                protocol="http",  # Use HTTP to avoid certificate issues
                connect_timeout=5000,
                read_timeout=10000,
            )
            self._sls_client = Client(config)
        except Exception as e:
            _logger.error(f"Failed to initialize SLS client: {e}")
            self._sls_client = None

    def _start_config_polling(self) -> None:
        """Start the configuration polling thread."""
        self._stop_polling = False

        def poll_config_loop():
            # Fetch initial configuration
            self._fetch_and_update_config()

            while not self._stop_polling:
                try:
                    time.sleep(self._poll_interval)
                    if not self._stop_polling:
                        self._fetch_and_update_config()
                except Exception as e:
                    _logger.error(f"Error in config polling loop: {e}")
                    time.sleep(self._poll_interval)
        # fetch config first
        self._fetch_and_update_config()
        poll_thread = threading.Thread(target=poll_config_loop, daemon=True)
        poll_thread.start()
        _logger.info("ConfigServer polling thread started")

    def _fetch_and_update_config(self) -> bool:
        """
        Fetch configuration from ConfigServer and update local state.
        
        Aligned with Java's getConfig method logic in ConfigServerConfigHandler.
        """
        if not self._sls_client:
            return False

        current_time = time.time()
        last_poll = self._global_config_state.last_poll_timestamp

        # Check polling cooldown
        if last_poll != -1 and (current_time - last_poll) < self._poll_interval:
            _logger.debug("[ConfigServerConfigHandler] Pulling configuration cooling down")
            return False

        self._global_config_state.last_poll_timestamp = current_time

        try:
            from aliyun.configserver.pb import (
                GetAgentConfigPB,
                AgentAttributes,
                AgentAttribute,
                ConfigInfo as PBConfigInfo,
                EnterpriseRequestExtension,
                GetAgentConfigResponsePB,
                EnterpriseResponseExtension,
            )
            from aliyun.configserver.client.models import GetAgentConfigRequest
            from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv

            arms_env = ArmsEnv.instance()

            # Build request
            request_builder = GetAgentConfigPB()
            request_builder.agent_type = AGENT_TYPE_APM_PYTHON
            request_builder.capabilities = 2  # AcceptsInstanceConfig
            request_builder.sequence_num = self._global_config_state.get_and_increment_sequence()
            request_builder.startup_time = int(time.time() * 1000)
            request_builder.running_status = AGENT_STATUS_RUNNING

            # Build enterprise extension
            enterprise_ext = EnterpriseRequestExtension()
            if arms_env.user_id:
                enterprise_ext.aliuid.append(arms_env.user_id.encode('utf-8'))
            if self._global_config_state.attributes_hash != -1:
                enterprise_ext.attributes_hash = self._global_config_state.attributes_hash
            if self._global_config_state.config_set_hash != -1:
                enterprise_ext.instance_configs_hash = self._global_config_state.config_set_hash
            request_builder.opaque = enterprise_ext.SerializeToString()

            # Set instance ID
            if hasattr(arms_env, 'uuid') and arms_env.uuid:
                request_builder.instance_id = str(arms_env.uuid).encode('utf-8')

            # Set agent attributes
            attributes = AgentAttributes()
            if arms_env.service_id:
                service_attr = AgentAttribute()
                service_attr.name = AGENT_ATTRIBUTE_SERVICE
                service_attr.value = arms_env.service_id.encode('utf-8')
                attributes.extras.append(service_attr)

            if arms_env.workspace:
                workspace_attr = AgentAttribute()
                workspace_attr.name = AGENT_ATTRIBUTE_WORKSPACE
                workspace_attr.value = arms_env.workspace.encode('utf-8')
                attributes.extras.append(workspace_attr)
            else:
                # Generate default workspace
                from aliyun.sdk.extension.arms.common.utils.arms_utils import get_default_workspace
                default_workspace = get_default_workspace(arms_env.user_id, arms_env.regionId)
                workspace_attr = AgentAttribute()
                workspace_attr.name = AGENT_ATTRIBUTE_WORKSPACE
                workspace_attr.value = default_workspace.encode('utf-8')
                attributes.extras.append(workspace_attr)

            if arms_env.address:
                attributes.ip = arms_env.address.encode('utf-8')
            if arms_env.hostname:
                attributes.hostname = arms_env.hostname.encode('utf-8')

            # Set agent version
            try:
                from aliyun.opentelemetry.instrumentation.version import __agent_version__
                attributes.version = __agent_version__.encode('utf-8')
            except Exception:
                pass

            request_builder.attributes.CopyFrom(attributes)

            # Add instance configs with their versions
            for config_type in ALL_CONFIG_TYPES:
                config_info = PBConfigInfo()
                config_info.name = config_type
                config_info.version = self._global_config_state.get_config_version(config_type)
                request_builder.instance_configs.append(config_info)

            # Serialize and send request
            request_data = request_builder.SerializeToString()
            get_config_request = GetAgentConfigRequest(body=request_data)

            response = self._sls_client.get_agent_config(get_config_request)

            if response and response.body:
                response_pb = GetAgentConfigResponsePB()
                response_pb.ParseFromString(response.body)

                # Parse enterprise response extension
                if response_pb.opaque:
                    response_ext = EnterpriseResponseExtension()
                    response_ext.ParseFromString(response_pb.opaque)
                    self._global_config_state.update_hashes(
                        response_ext.instance_configs_hash,
                        response_ext.attributes_hash
                    )

                # Process config updates - track which config types were updated
                # Aligned with Java's anyUpdate logic
                updated_config_types: Set[str] = set()
                config_details = response_pb.instance_config_updates
                
                if config_details:
                    for config_detail in config_details:
                        if config_detail.version == -1:
                            continue

                        config_name = config_detail.name
                        config_content = config_detail.detail.decode('utf-8') if config_detail.detail else ""
                        
                        # Track which config types were updated
                        updated_config_types.add(config_name)
                        
                        # Update the config in global state
                        self._global_config_state.update_config(
                            config_name,
                            config_content,
                            config_detail.version
                        )
                        _logger.debug(f"[ConfigServerConfigHandler] Updated config {config_name} to version {config_detail.version}")

                    # Notify listeners for updated config types
                    # This follows Java's notifyMatchingListeners pattern
                    for config_type in updated_config_types:
                        # Map apm_user_method to apm_trace for listener notification
                        effective_config_type = CONFIG_TYPE_APM_TRACE if config_type == CONFIG_TYPE_APM_USER_METHOD else config_type
                        config_info = self._global_config_state.get_config(effective_config_type)
                        if config_info:
                            self._notify_matching_listeners(effective_config_type, config_info.config)
                    
                    # Execute legacy callbacks (for backward compatibility)
                    if updated_config_types:
                        self._exec_callbacks()

                return len(updated_config_types) > 0

        except Exception as e:
            _logger.error(f"[ConfigServerConfigHandler] Failed to get config: {e}")

        return False

    def get_config(self, config_type: Optional[str] = None) -> Optional[str]:
        """
        Get the current configuration for a specific type.
        
        Aligned with Java's getConfig method.
        
        Args:
            config_type: The config type to retrieve (e.g., apm_trace, apm_global).
                        If None, returns apm_trace config for backward compatibility.
        
        Returns:
            The config content as a string, or None if not found.
        """
        if config_type is None:
            config_type = CONFIG_TYPE_APM_TRACE
            
        config_info = self._global_config_state.get_config(config_type)
        return config_info.config if config_info else None

    def get_config_as_json(self, config_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Get the current configuration as a parsed JSON object.
        
        Args:
            config_type: The config type to retrieve. If None, returns apm_trace config.
        
        Returns:
            The config as a dict, or None if not found or invalid JSON.
        """
        config_str = self.get_config(config_type)
        if config_str:
            try:
                return json.loads(config_str)
            except json.JSONDecodeError as e:
                _logger.warning(f"[ConfigServerConfigHandler] Failed to parse config JSON: {e}")
        return None

    def add_listener(self, config_type: str, callback: Callable[[str], None]) -> None:
        """
        Add a listener for a specific config type.
        
        Aligned with Java's addListener method.
        
        Args:
            config_type: The config type to listen for (e.g., apm_trace, apm_global)
            callback: Callback function that receives the config content when updated
        """
        listener_info = ListenerInfo(callback, config_type)
        self._listener_infos.append(listener_info)
        _logger.info(f"[ConfigServerConfigHandler] Added listener for config type: {config_type}")

    def register_callback(self, callback: Callable[[], None]) -> None:
        """
        Register a legacy callback to be called when any configuration changes.
        
        For new code, prefer using add_listener() with a specific config type.
        """
        self._callback_funcs.append(callback)

    def _notify_matching_listeners(self, config_type: str, config: str) -> None:
        """
        Notify listeners that match the given config type.
        
        Aligned with Java's notifyMatchingListeners method.
        """
        if not self._listener_infos:
            return
            
        for listener_info in self._listener_infos:
            if listener_info.config_type == config_type:
                try:
                    _logger.info(f"[ConfigServerConfigHandler] Notifying listener for config type: {config_type}")
                    listener_info.callback(config)
                except Exception as e:
                    _logger.error(f"[ConfigServerConfigHandler] Error notifying listener for config type {config_type}: {e}")

    def _exec_callbacks(self) -> None:
        """Execute all registered legacy callbacks."""
        for callback in self._callback_funcs:
            try:
                callback()
            except Exception as e:
                _logger.error(f"[ConfigServerConfigHandler] Error executing config callback: {e}")

    def stop(self) -> None:
        """Stop the configuration polling."""
        self._stop_polling = True
        if self._poll_executor:
            self._poll_executor.shutdown(wait=False)

    def is_enabled(self) -> bool:
        """Check if configuration fetching is enabled."""
        flag = os.getenv("ENABLE_CONFIG_SERVER", "true")
        if flag.lower() == "false":
            _logger.info("ConfigServer client disabled by environment variable")
            return False
        return True

    @property
    def is_init(self) -> bool:
        """Check if the handler is initialized."""
        return self._is_init


# Global singleton instance
_config_handler_instance: Optional[ConfigServerConfigHandler] = None
_config_handler_lock = Lock()


def get_config_handler() -> ConfigServerConfigHandler:
    """Get the global ConfigServerConfigHandler instance."""
    global _config_handler_instance
    if _config_handler_instance is None:
        with _config_handler_lock:
            if _config_handler_instance is None:
                _config_handler_instance = ConfigServerConfigHandler()
    return _config_handler_instance

