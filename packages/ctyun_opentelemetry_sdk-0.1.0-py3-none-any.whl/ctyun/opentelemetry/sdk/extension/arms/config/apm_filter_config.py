# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
APM Filter Configuration for controlling trace/metric reporting and filtering.
"""

import threading
from typing import Set, Optional

from aliyun.sdk.extension.arms.config.constant import (
    APSARA_APM_TRACE_REPORT_ENABLED,
    APSARA_APM_METRIC_REPORT_ENABLED,
    APSARA_APM_METRIC_FILTER_EXCLUDE_CALLKIND_LIST,
    APSARA_APM_METRIC_FILTER_EXCLUDE_CALLTYPE_LIST,
)


class ApmFilterConfig:
    """
    Singleton class to manage APM filter configuration for trace/metric reporting and filtering.
    
    This class provides:
    - Control over trace reporting (enabled/disabled)
    - Control over metric reporting (enabled/disabled)
    - Metric filtering based on callKind and callType exclusion lists
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._trace_report_enabled: bool = True
        self._metric_report_enabled: bool = True
        self._exclude_callkind_set: Set[str] = set()
        self._exclude_calltype_set: Set[str] = set()
        self._initialized = True
    
    @classmethod
    def instance(cls) -> 'ApmFilterConfig':
        """Get the singleton instance of ApmFilterConfig."""
        return cls()
    
    @property
    def trace_report_enabled(self) -> bool:
        """Check if trace reporting is enabled."""
        return self._trace_report_enabled
    
    @trace_report_enabled.setter
    def trace_report_enabled(self, value: bool):
        """Set trace reporting enabled state."""
        self._trace_report_enabled = value
    
    @property
    def metric_report_enabled(self) -> bool:
        """Check if metric reporting is enabled."""
        return self._metric_report_enabled
    
    @metric_report_enabled.setter
    def metric_report_enabled(self, value: bool):
        """Set metric reporting enabled state."""
        self._metric_report_enabled = value
    
    @property
    def exclude_callkind_set(self) -> Set[str]:
        """Get the set of excluded callKind values."""
        return self._exclude_callkind_set.copy()
    
    @property
    def exclude_calltype_set(self) -> Set[str]:
        """Get the set of excluded callType values."""
        return self._exclude_calltype_set.copy()
    
    def set_exclude_callkind_list(self, value: Optional[str]):
        """
        Set the callKind exclusion list from a comma-separated string.
        
        Args:
            value: Comma-separated string of callKind values to exclude, or None to clear.
        """
        if value is None or value.strip() == "":
            self._exclude_callkind_set = set()
        else:
            self._exclude_callkind_set = {
                item.strip() for item in value.split(",") if item.strip()
            }
    
    def set_exclude_calltype_list(self, value: Optional[str]):
        """
        Set the callType exclusion list from a comma-separated string.
        
        Args:
            value: Comma-separated string of callType values to exclude, or None to clear.
        """
        if value is None or value.strip() == "":
            self._exclude_calltype_set = set()
        else:
            self._exclude_calltype_set = {
                item.strip() for item in value.split(",") if item.strip()
            }
    
    def should_filter_metric(self, call_kind: Optional[str] = None, call_type: Optional[str] = None) -> bool:
        """
        Check if a metric should be filtered based on callKind and callType.
        
        Args:
            call_kind: The callKind attribute value of the metric.
            call_type: The callType attribute value of the metric.
            
        Returns:
            True if the metric should be filtered (excluded), False otherwise.
        """
        # Early return if no exclusion rules configured
        if not self._exclude_callkind_set and not self._exclude_calltype_set:
            return False
        
        if call_kind and call_kind in self._exclude_callkind_set:
            return True
        if call_type and call_type in self._exclude_calltype_set:
            return True
        return False
    
    def update_from_config(self, config):
        """
        Update configuration from a ConfigProperties object.
        
        Args:
            config: A ConfigProperties object with get_property method.
        """
        if config is None:
            return
        
        # Update trace report enabled
        trace_enabled = config.get_property(APSARA_APM_TRACE_REPORT_ENABLED)
        if trace_enabled is not None:
            self.trace_report_enabled = trace_enabled if isinstance(trace_enabled, bool) else str(trace_enabled).lower() == "true"
        
        # Update metric report enabled
        metric_enabled = config.get_property(APSARA_APM_METRIC_REPORT_ENABLED)
        if metric_enabled is not None:
            self.metric_report_enabled = metric_enabled if isinstance(metric_enabled, bool) else str(metric_enabled).lower() == "true"
        
        # Update callKind exclusion list
        exclude_callkind = config.get_property(APSARA_APM_METRIC_FILTER_EXCLUDE_CALLKIND_LIST)
        if exclude_callkind is not None:
            self.set_exclude_callkind_list(str(exclude_callkind))
        
        # Update callType exclusion list
        exclude_calltype = config.get_property(APSARA_APM_METRIC_FILTER_EXCLUDE_CALLTYPE_LIST)
        if exclude_calltype is not None:
            self.set_exclude_calltype_list(str(exclude_calltype))


# Global instance for easy access
global_apm_filter_config = ApmFilterConfig.instance()


def should_filter_metric_by_attrs(metric_attrs: dict) -> bool:
    """
    Convenience function to check if metrics should be filtered based on metric attributes.
    
    This function extracts callKind and callType from the metric attributes dictionary
    and checks against the exclude lists.
    
    Args:
        metric_attrs: Dictionary containing metric attributes with possible 'callKind' and 'callType' keys.
        
    Returns:
        True if the metric should be filtered (excluded), False otherwise.
    """
    if metric_attrs is None:
        return False
    
    call_kind = metric_attrs.get("callKind")
    call_type = metric_attrs.get("callType")
    
    return global_apm_filter_config.should_filter_metric(call_kind, call_type)
