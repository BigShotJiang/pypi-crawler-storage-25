# -*- coding: utf-8 -*-
"""
Configuration properties management for ARMS.
Uses ConfigServer-based configuration fetching.
"""

import os
from typing import Any, Optional

import jsonpath

from aliyun.sdk.extension.arms.config.configserver_handler import (
    ConfigServerConfigHandler,
    get_config_handler,
)

arms_enable = True

config_properties = None


class ConfigProperties:
    """Base class for configuration properties."""

    def get_property(self, property_name: str) -> Optional[Any]:
        """Get a property value by name."""
        pass

    def get_property_or_default(self, property_name: str, default: Any = None) -> Any:
        """Get a property value with a default fallback."""
        p = self.get_property(property_name)
        if p is None:
            return default
        return p


class ConfigServerConfigProperties(ConfigProperties):
    """Configuration properties backed by ConfigServer."""

    def __init__(self, handler: ConfigServerConfigHandler):
        self._handler = handler

    def get_property(self, property_name: str) -> Optional[Any]:
        """Get a property value from ConfigServer configuration."""
        if self._handler is None:
            return None
        try:
            config = self._handler.get_config()
            if config is None:
                return None
            import json
            config_dict = json.loads(config)
            result = jsonpath.jsonpath(config_dict, "$." + property_name)
            if result and len(result) > 0:
                return result[0]
            return None
        except Exception:
            return None


class StaticConfigProperties(ConfigProperties):
    """Configuration properties backed by environment variables."""

    def get_property(self, property_name: str) -> Optional[str]:
        """Get a property value from environment variables."""
        norm_property_name = property_name.replace(".", "_").upper()
        return os.environ.get(norm_property_name)


class ArmsConfigProperties(ConfigProperties):
    """Combined configuration properties from ConfigServer and environment."""

    def __init__(
        self,
        config_server_config: ConfigServerConfigProperties,
        static_config: StaticConfigProperties,
    ):
        self._config_server_config = config_server_config
        self._static_config = static_config

    def get_property(self, property_name: str) -> Optional[Any]:
        """Get property, preferring ConfigServer config over static config."""
        p = self._config_server_config.get_property(property_name)
        if p is None:
            p = self._static_config.get_property(property_name)
        return p


def get_config_properties(handler: Optional[ConfigServerConfigHandler] = None) -> ArmsConfigProperties:
    """
    Get the global configuration properties instance.

    Args:
        handler: Optional ConfigServerConfigHandler instance. If not provided,
                uses the global singleton handler.

    Returns:
        ArmsConfigProperties instance combining ConfigServer and static configs.
    """
    global config_properties
    if handler is None:
        handler = get_config_handler()
    config_properties = ArmsConfigProperties(
        ConfigServerConfigProperties(handler),
        StaticConfigProperties(),
    )
    return config_properties
