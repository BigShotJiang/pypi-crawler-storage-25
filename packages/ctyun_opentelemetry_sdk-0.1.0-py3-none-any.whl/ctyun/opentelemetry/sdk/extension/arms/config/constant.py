ARMS_AGENT_ENABLE_KEY = "apsara.apm.enabled"
PROFILER_SAMPLING_ENABLE_KEY = "apsara.apm.sampler.enabled"
PROFILER_SAMPLING_RATE_KEY = "apsara.apm.sampler.rate"

PROFILER_SELF_MONITOR_KEY = "apsara.apm.self_monitor.enabled"
RESOURCE_MONITOR_ENABLE_KEY = "apsara.apm.self_monitor.agent_resource_monitor.enabled"
APSARA_COMPRESS_ENABLE_KEY = "apsara.apm.instrumenter.span_compress_enabled"

HOST_TAGS = "apsara.apm.tag.instance_tags"
PROFILER_APP_TAGS = "apsara.apm.tag.service_tags"
PROFILER_NETWORK_STRATEGY = "apsara.apm.collector.network_strategy"
OLD_PROFILER_NETWORK_STRATEGY = "profiler.network.strategy"
PROFILER_COLLECTOR_ENDPOINT = "apsara.apm.collector.one_endpoint"
CMS_WORKSPACE = "x-cms-workspace"
SLS_PROJECT = "x-arms-project"
MAX_TAG_SIZE = 200

PROFILER_FASTAPI_KEY = "otel.instrumentation.fastapi.enabled"
PROFILER_FLASK_KEY = "otel.instrumentation.flask.enabled"
PROFILER_DJANGO_KEY = "otel.instrumentation.django.enabled"
PROFILER_REQUESTS_KEY = "otel.instrumentation.requests.enabled"
PROFILER_AIO_HTTP_CLIENT_KEY = "otel.instrumentation.aiohttp-client.enabled"
PROFILER_DIFY_KEY = "otel.instrumentation.dify.enabled"
PROFILER_DASHSCOPE_KEY = "otel.instrumentation.dashscope.enabled"
PROFILER_LANGCHAIN_KEY = "otel.instrumentation.langchain.enabled"
PROFILER_OPENAI_KEY = "otel.instrumentation.openai.enabled"
PROFILER_LLAMA_INDEX_KEY = "otel.instrumentation.llamaindex.enabled"


CMS_WORKSPACE_KEY_IN_SPAN = "acs.cms.workspace"
ARMS_SERVICE_ID_KEY_IN_SPAN = "acs.arms.service.id"
CMS_WORKSPACE_KEY_IN_METRIC = "acs_cms_workspace"
ARMS_SERVICE_ID_KEY_IN_METRIC = "acs_arms_service_id"
ARMS_P_SERVICE_ID_KEY_IN_METRIC = "acs_arms_p_service_id"

PROFILER_GENAI_SPLITAPP_KEY = "profiler.genai.splitApp.enable"

APSARA_APM_METASERVER_ADDRESS = "APSARA_APM_METASERVER_ADDRESS"

# 应用的类型
# 1. 微服务应用(microservice)
# 2. 大语言模型应用(app)，包括langchain，dashscope，openai等
# 3. 大语言模型服务(model)，包括vllm，sglang等
APSARA_APM_APP_TYPE = "APSARA_APM_APP_TYPE"
APSARA_APM_MODEL_SERVICE_FRAMEWORK = "APSARA_APM_MODEL_SERVICE_FRAMEWORK"

SERVICE_MODEL_VLLM_V0 = "vLLM-v0"
SERVICE_MODEL_VLLM_V1 = "vLLM-v1"
SERVICE_MODEL_SGLANG = "SGLang"

APSARA_APM_INSTRUMENTATION_CHILD_PROCESS = "APSARA_APM_INSTRUMENTATION_CHILD_PROCESS"

# APM report enabled switches
APSARA_APM_TRACE_REPORT_ENABLED = "apsara.apm.trace.report.enabled"
APSARA_APM_METRIC_REPORT_ENABLED = "apsara.apm.metric.report.enabled"

# APM metric filter configuration
APSARA_APM_METRIC_FILTER_EXCLUDE_CALLKIND_LIST = "apsara.apm.metric.filter.exclude_callkind_list"
APSARA_APM_METRIC_FILTER_EXCLUDE_CALLTYPE_LIST = "apsara.apm.metric.filter.exclude_calltype_list"

COMPONENT_LIST = {
    "fastApi": PROFILER_FASTAPI_KEY,
    "flask": PROFILER_FLASK_KEY,
    "django": PROFILER_DJANGO_KEY,
    "requests": PROFILER_REQUESTS_KEY,
    "aiohttpclient": PROFILER_AIO_HTTP_CLIENT_KEY,
    "dify": PROFILER_DIFY_KEY,
    "langchain": PROFILER_LANGCHAIN_KEY,
    "openai": PROFILER_OPENAI_KEY,
    "dashscope": PROFILER_DASHSCOPE_KEY,
    "llamaIndex": PROFILER_LLAMA_INDEX_KEY,
}
# agent
# profiling
PROFILER_ENABLED_KEY = "apsara.apm.profile.enabled"