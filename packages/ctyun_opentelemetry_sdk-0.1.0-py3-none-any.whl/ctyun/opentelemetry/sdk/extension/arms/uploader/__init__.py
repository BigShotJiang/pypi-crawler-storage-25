# ARMS uploader package
#
# 提供 ARMS 环境下的多模态数据上传支持。
# 全局单例管理由 aliyun.opentelemetry.util.genai._multimodal_upload 负责，
# 本模块仅做转发/重新导出以保持向后兼容。

from __future__ import annotations

# ARMS 特有实现
from aliyun.sdk.extension.arms.uploader.arms_uploader import ArmsUploader
# 从 _multimodal_upload 转发接口和单例管理函数
from aliyun.opentelemetry.util.genai._multimodal_upload import (PreUploader,
                                                         PreUploadItem,
                                                         Uploader, UploadItem,
                                                         get_pre_uploader,
                                                         get_uploader,
                                                         set_pre_uploader,
                                                         set_uploader)

__all__ = [
    "UploadItem",
    "PreUploadItem",
    "Uploader",
    "PreUploader",
    "ArmsUploader",
    "set_uploader",
    "get_uploader",
    "set_pre_uploader",
    "get_pre_uploader",
]

try:
    from aliyun.opentelemetry.util.genai._multimodal_upload.fs_uploader import MultimodalPreUploader
    __all__.append("MultimodalPreUploader")
except ImportError:
    pass