"""ArmsUploader - 轻量级 SLS 上传器

直接使用 aliyun-log-python-sdk 的 LogClient，无需 fsspec 依赖。
支持超时控制、Token 刷新、重试等功能。
"""
from __future__ import annotations

import io
import logging
import os
import threading
import time
import weakref
from collections import OrderedDict, deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Deque, Dict, Optional, Tuple, Union

import httpx
from aliyun.store import LogClient
from aliyun.store.logexception import LogException
from aliyun.opentelemetry.instrumentation.utils import suppress_http_instrumentation
from aliyun.opentelemetry.util.genai._multimodal_upload import Uploader, UploadItem
from aliyun.opentelemetry.util.genai.extended_environment_variables import \
    OTEL_INSTRUMENTATION_GENAI_MULTIMODAL_DOWNLOAD_SSL_VERIFY

_logger = logging.getLogger(__name__)

# Token 刷新相关常量
MIN_REFRESH_INTERVAL = 300  # 最小刷新间隔（秒）
TOKEN_REFRESH_THRESHOLD = 120  # 过期前多少秒开始刷新


@dataclass
class _Task:
    """内部上传任务"""
    object_name: str
    content: Optional[bytes]
    skip_if_exists: bool
    meta: Optional[dict[str, str]]
    content_type: Optional[str]
    source_uri: Optional[str] = None
    expected_size: int = 0


class ArmsUploader(Uploader):
    """轻量级 SLS 上传器，直接使用 aliyun-log-python-sdk。
    
    特点：
    - 无需 fsspec 依赖，只依赖 aliyun-log-python-sdk
    - 支持超时控制
    - 异步队列 + 后台线程池上传
    - LRU 缓存避免重复上传
    
    Example:
        uploader = ArmsUploader(
            base_path="sls://project/logstore",
            endpoint="https://cn-hangzhou.log.aliyuncs.com",
            access_key="xxx",
            access_secret_key="xxx",
        )
        uploader.upload(UploadItem(url="path/to/file.bin", data=b"content", ...))
        uploader.shutdown()
    """

    def __init__(
        self,
        base_path: str,
        *,
        endpoint: str = "",
        access_key: str = "",
        access_secret_key: str = "",
        security_token: Optional[str] = None,
        token_expire_time: Optional[Union[datetime, float, int]] = None,
        token_refresh_callback: Optional[Callable[[], Tuple[str, str, Optional[str], Optional[Union[datetime, float, int]]]]] = None,
        timeout: float = 30.0,
        max_workers: int = 4,
        max_queue_size: int = 1024,
        max_queue_bytes: int = 0,
        lru_cache_max_size: int = 2048,
        max_upload_retries: int = 10,
        upload_retry_delay: float = 1.0,
    ) -> None:
        """初始化 ArmsUploader。
        
        Args:
            base_path: SLS 路径，格式为 sls://project/logstore
            endpoint: SLS endpoint，如 https://cn-hangzhou.log.aliyuncs.com
            access_key: AccessKey ID
            access_secret_key: AccessKey Secret
            security_token: STS Token（可选）
            token_expire_time: Token 过期时间（可选，用于主动刷新）
            token_refresh_callback: Token 刷新回调函数（可选）
            timeout: 上传超时时间（秒），默认 30
            max_workers: 后台上传线程数
            max_queue_size: 队列最大任务数
            max_queue_bytes: 队列最大字节数（0 表示不限制）
            lru_cache_max_size: LRU 缓存大小
            max_upload_retries: 最大重试次数（0 表示无限重试）
            upload_retry_delay: 重试间隔（秒）
        """
        # 解析 base_path
        self._project, self._logstore = self._parse_base_path(base_path)
        self._base_path = base_path
        
        # 保存认证信息
        self._endpoint = endpoint
        self._access_key = access_key
        self._access_secret_key = access_secret_key
        self._security_token = security_token
        self._token_expire_time = token_expire_time
        self._token_refresh_callback = token_refresh_callback
        self._timeout = timeout
        self._last_refresh = 0.0
        
        # LogClient（延迟创建）
        self._client: Optional[LogClient] = None
        self._client_lock = threading.Lock()
        
        # 队列和线程池
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._queue_capacity = max_queue_size
        self._max_queue_bytes = max_queue_bytes
        self._current_queue_bytes = 0
        self._queue_count = 0
        self._queue: Deque[_Task] = deque()
        self._lock = threading.Lock()
        self._queue_cond = threading.Condition(self._lock)
        self._shutdown_event = threading.Event()
        
        # LRU 缓存
        self._lru_uploaded: OrderedDict[str, bool] = OrderedDict()
        self._lru_lock = threading.Lock()
        self._lru_capacity = lru_cache_max_size
        
        # 重试配置
        self._max_upload_retries = max_upload_retries
        self._upload_retry_delay = upload_retry_delay
        self._max_workers = max_workers
        self._shutdown_called = False
        self._ssl_verify = os.environ.get(
            OTEL_INSTRUMENTATION_GENAI_MULTIMODAL_DOWNLOAD_SSL_VERIFY, "true"
        ).lower() not in ("false", "0", "no")

        # 启动后台 dispatcher
        self._dispatcher_thread = threading.Thread(
            target=self._dispatcher_loop, name="ArmsUploader-Dispatcher", daemon=True
        )
        self._dispatcher_thread.start()
        
        # Fork 安全
        if hasattr(os, "register_at_fork"):
            weak_reinit = weakref.WeakMethod(self._at_fork_reinit)
            os.register_at_fork(
                after_in_child=lambda: (ref := weak_reinit()) and ref()
            )
        self._pid = os.getpid()

    @staticmethod
    def _parse_base_path(base_path: str) -> Tuple[str, str]:
        """解析 base_path 获取 project 和 logstore。
        
        Args:
            base_path: 格式为 sls://project/logstore 或 project/logstore
            
        Returns:
            (project, logstore) 元组
            
        Raises:
            ValueError: 如果格式无效
        """
        path = base_path
        if path.startswith("sls://"):
            path = path[6:]  # 移除 sls://
        
        # 移除开头的 /
        path = path.lstrip("/")
        
        parts = path.split("/", 2)
        if len(parts) < 2:
            raise ValueError(
                f"Invalid base_path format: {base_path}. "
                "Expected format: sls://project/logstore"
            )
        
        project, logstore = parts[0], parts[1]
        if not project or not logstore:
            raise ValueError(
                f"Invalid base_path: project or logstore is empty. "
                f"Got project='{project}', logstore='{logstore}'"
            )
        
        return project, logstore

    @property
    def base_path(self) -> str:
        """返回 base_path。"""
        return self._base_path

    def _get_client(self) -> LogClient:
        """获取或创建 LogClient 实例。"""
        with self._client_lock:
            if self._client is None:
                if not self._endpoint or not self._access_key or not self._access_secret_key:
                    raise ValueError(
                        "SLS config incomplete. Provide endpoint, access_key, and access_secret_key."
                    )
                self._client = LogClient(
                    self._endpoint,
                    accessKeyId=self._access_key,
                    accessKey=self._access_secret_key,
                    securityToken=self._security_token,
                )
                self._client.timeout = self._timeout
            return self._client

    def _refresh_client(self) -> LogClient:
        """刷新 LogClient 实例。"""
        with self._client_lock:
            self._client = None
        return self._get_client()

    def _normalize_expire_time(self, expire_time: Union[datetime, float, int, None]) -> Optional[float]:
        """将过期时间转换为 Unix 时间戳。"""
        if expire_time is None:
            return None
        if isinstance(expire_time, datetime):
            return expire_time.timestamp()
        if isinstance(expire_time, (int, float)):
            return float(expire_time)
        return None

    def _should_refresh_token_proactively(self) -> bool:
        """检查是否需要主动刷新 Token。"""
        if self._token_expire_time is None or self._token_refresh_callback is None:
            return False
        if self._security_token is None:
            return False
        
        expire_timestamp = self._normalize_expire_time(self._token_expire_time)
        if expire_timestamp is None:
            return False
        
        refresh_threshold = expire_timestamp - TOKEN_REFRESH_THRESHOLD
        current_time = datetime.now().timestamp()
        
        return current_time >= refresh_threshold

    def _refresh_token(self, proactive: bool = True) -> bool:
        """刷新 Token。"""
        if self._token_refresh_callback is None:
            return False
        
        # 检查刷新间隔
        delta = time.time() - self._last_refresh
        if delta < MIN_REFRESH_INTERVAL:
            _logger.warning("Token refresh too frequent, skipping")
            return False
        
        try:
            refresh_type = "proactively" if proactive else "reactively"
            _logger.info("Refreshing token %s", refresh_type)
            self._last_refresh = time.time()
            
            result = self._token_refresh_callback()
            
            if len(result) == 3:
                new_access_key, new_secret_key, new_token = result
                new_expire_time = None
            elif len(result) == 4:
                new_access_key, new_secret_key, new_token, new_expire_time = result
            else:
                raise ValueError(
                    "token_refresh_callback must return a tuple of "
                    "(access_key, access_secret_key, security_token) or "
                    "(access_key, access_secret_key, security_token, token_expire_time)"
                )
            
            self._access_key = new_access_key
            self._access_secret_key = new_secret_key
            self._security_token = new_token
            if new_expire_time is not None:
                self._token_expire_time = new_expire_time
            
            self._refresh_client()
            _logger.info("Token refreshed successfully")
            return True
        except Exception as err:
            _logger.error("Failed to refresh token: %s", err)
            return False

    def _is_token_expired_error(self, error: LogException) -> bool:
        """检查是否为 Token 过期错误。"""
        error_code = error.get_error_code()
        return (
            error_code in ("Unauthorized", "AccessDenied", "SecurityTokenExpired")
            and self._security_token is not None
            and self._token_refresh_callback is not None
        )

    def upload(
        self,
        item: UploadItem,
        *,
        skip_if_exists: bool = True,
    ) -> bool:
        """将上传任务入队。
        
        Args:
            item: 上传任务项
            skip_if_exists: 如果文件已存在则跳过
            
        Returns:
            True 表示成功入队，False 表示队列满或正在关闭
        """
        if self._shutdown_event.is_set():
            return False
        
        # 验证参数
        if item.data is None and item.source_uri is None:
            _logger.error("Either data or source_uri must be provided in UploadItem")
            return False
        
        data = item.data
        if isinstance(data, str):
            data = data.encode("utf-8")

        object_name = self._build_object_name(item.url)
        full_path = f"sls://{self._project}/{self._logstore}/{object_name}"
        
        # LRU 缓存快速路径
        if skip_if_exists and self._uploaded_cached(full_path):
            return True

        content_size = len(data) if data else item.expected_size

        with self._lock:
            if self._queue_count >= self._queue_capacity:
                _logger.warning("upload queue full, dropping: %s", full_path)
                return False
            if self._max_queue_bytes > 0 and content_size > 0:
                if self._current_queue_bytes + content_size > self._max_queue_bytes:
                    _logger.warning(
                        "upload queue bytes limit exceeded (current=%d, incoming=%d, max=%d), dropping: %s",
                        self._current_queue_bytes,
                        content_size,
                        self._max_queue_bytes,
                        full_path,
                    )
                    return False
            self._queue_count += 1
            self._current_queue_bytes += content_size
            self._queue.append(
                _Task(object_name, data, skip_if_exists, item.meta, item.content_type, item.source_uri, item.expected_size)
            )
        return True

    def _build_object_name(self, url: str) -> str:
        """构建 object_name。"""
        # 如果是完整的 sls:// URL，提取 object_name
        if url.startswith("sls://"):
            parts = url[6:].split("/", 2)
            if len(parts) >= 3:
                return parts[2]
        # 移除开头的 /
        return url.lstrip("/")

    def shutdown(self, timeout: float = 10.0) -> None:
        """优雅关闭上传器。"""
        if self._shutdown_called:
            return
        self._shutdown_called = True
        
        if self._shutdown_event.is_set():
            _logger.warning("Uploader already shutdown")
            return
            
        deadline = time.time() + timeout

        # 阶段 1: 等待队列清空
        with self._queue_cond:
            while self._queue_count > 0:
                remaining = deadline - time.time()
                if remaining <= 0:
                    _logger.warning(
                        "shutdown timeout, %d tasks remaining in queue",
                        self._queue_count
                    )
                    break
                self._queue_cond.wait(timeout=remaining)

        # 阶段 2: 设置 shutdown 标志
        self._shutdown_event.set()
        
        # 阶段 3: 等待 dispatcher 退出
        remaining = max(0.0, deadline - time.time())
        self._dispatcher_thread.join(timeout=remaining)
        
        # 阶段 4: 关闭线程池
        self._executor.shutdown(wait=False)

    def _at_fork_reinit(self) -> None:
        """Fork 后重新初始化。"""
        _logger.debug("[_at_fork_reinit] ArmsUploader reinitializing after fork")
        self._lock = threading.Lock()
        self._queue_cond = threading.Condition(self._lock)
        self._lru_lock = threading.Lock()
        self._client_lock = threading.Lock()
        self._shutdown_event = threading.Event()
        self._shutdown_called = False
        self._queue.clear()
        self._queue_count = 0
        self._current_queue_bytes = 0
        self._lru_uploaded.clear()
        self._client = None
        
        self._executor = ThreadPoolExecutor(max_workers=self._max_workers)
        
        self._dispatcher_thread = threading.Thread(
            target=self._dispatcher_loop,
            name="ArmsUploader-Dispatcher",
            daemon=True
        )
        self._dispatcher_thread.start()
        self._pid = os.getpid()

    def _dispatcher_loop(self) -> None:
        """后台任务分发循环。"""
        while not self._shutdown_event.is_set():
            task: Optional[_Task] = None
            with self._lock:
                if self._queue:
                    task = self._queue.popleft()
            if task is None:
                self._shutdown_event.wait(0.01)
                continue
            try:
                self._executor.submit(self._do_upload, task)
            except RuntimeError:
                self._release_task(task)

    def _do_upload(self, task: _Task) -> None:
        """执行上传任务。"""
        attempt = 0
        max_retries = self._max_upload_retries
        retry_delay = self._upload_retry_delay
        full_path = f"sls://{self._project}/{self._logstore}/{task.object_name}"

        try:
            # 检查缓存
            if task.skip_if_exists and self._uploaded_cached(full_path):
                return

            # 下载内容（如果是 source_uri 任务）
            if task.source_uri and task.content is None:
                content = self._download_content(task.source_uri, max_size=30 * 1024 * 1024)
                if content is None:
                    _logger.warning(f"Failed to download, skip: {task.source_uri}")
                    return
                task.content = content
                
                size_diff = len(content) - task.expected_size
                if size_diff != 0:
                    with self._lock:
                        self._current_queue_bytes += size_diff

            # 主动刷新 Token
            if self._should_refresh_token_proactively():
                self._refresh_token(proactive=True)

            # 上传重试循环
            while True:
                attempt += 1
                try:
                    self._put_object(task)
                    self._mark_uploaded(full_path)
                    return
                except LogException as exc:
                    # Token 过期，尝试刷新后重试
                    if self._is_token_expired_error(exc):
                        _logger.info("Token expired, attempting to refresh")
                        if self._refresh_token(proactive=False):
                            continue  # 重试
                    
                    if max_retries > 0 and attempt >= max_retries:
                        _logger.exception(
                            "upload failed after %d attempts: %s", attempt, full_path
                        )
                        return
                    _logger.warning(
                        "upload attempt %d failed for %s: %s, retrying in %.1fs...",
                        attempt,
                        full_path,
                        str(exc),
                        retry_delay,
                    )
                    time.sleep(retry_delay)
                except Exception as exc:
                    if max_retries > 0 and attempt >= max_retries:
                        _logger.exception(
                            "upload failed after %d attempts: %s", attempt, full_path
                        )
                        return
                    _logger.warning(
                        "upload attempt %d failed for %s: %s, retrying in %.1fs...",
                        attempt,
                        full_path,
                        str(exc),
                        retry_delay,
                    )
                    time.sleep(retry_delay)
        finally:
            self._release_task(task)

    def _put_object(self, task: _Task) -> None:
        """调用 LogClient.put_object 上传文件。"""
        client = self._get_client()
        
        headers: Dict[str, str] = {}
        if task.content_type:
            headers["Content-Type"] = task.content_type
        if task.meta:
            for k, v in task.meta.items():
                headers[f"x-log-meta-{k}"] = str(v)
        
        client.put_object(
            self._project,
            self._logstore,
            task.object_name,
            task.content or b"",
            headers if headers else None,
        )

    def _release_task(self, task: _Task) -> None:
        """释放任务资源。"""
        with self._queue_cond:
            self._queue_count -= 1
            size_to_release = len(task.content) if task.content else task.expected_size
            self._current_queue_bytes -= size_to_release
            self._queue_cond.notify_all()

    def _download_content(self, uri: str, max_size: int, timeout: float = 30.0) -> Optional[bytes]:
        """下载 URI 内容。"""
        with suppress_http_instrumentation():
            try:
                with httpx.Client(timeout=timeout, verify=self._ssl_verify) as client:
                    with client.stream("GET", uri) as response:
                        # Explicitly reject 3xx redirects, to prevent old httpx versions from silently getting incorrect body
                        if 300 <= response.status_code < 400:
                            raise httpx.HTTPStatusError("Redirect not allowed", request=response.request, response=response)
                        response.raise_for_status()
                        buffer = io.BytesIO()
                        try:
                            for chunk in response.iter_bytes(chunk_size=64 * 1024):
                                if buffer.tell() + len(chunk) > max_size:
                                    _logger.warning(f"Download exceeds max size {max_size}, abort: {uri}")
                                    return None
                                buffer.write(chunk)
                            return buffer.getvalue()
                        finally:
                            buffer.close()
            except Exception as e:
                _logger.warning(f"Failed to download: {uri}, error: {e}")
                return None

    def _uploaded_cached(self, path: str) -> bool:
        """检查 LRU 缓存。"""
        with self._lru_lock:
            if path in self._lru_uploaded:
                self._lru_uploaded.move_to_end(path)
                return True
            return False

    def _mark_uploaded(self, path: str) -> None:
        """标记为已上传。"""
        with self._lru_lock:
            self._lru_uploaded[path] = True
            if len(self._lru_uploaded) > self._lru_capacity:
                self._lru_uploaded.popitem(last=False)

