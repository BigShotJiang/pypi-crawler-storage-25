"""Uploader storage 工厂模块

提供创建 ArmsUploader 和 MultimodalPreUploader 的工厂函数。
直接从环境变量读取配置，减少对 ArmsEnv 的依赖。
"""
from __future__ import annotations

import os
from typing import Optional

from aliyun.sdk.extension.arms.common.constant import (
    APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_KEY,
    APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_SECRET_KEY,
    APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ENDPOINT,
    APSARA_APM_COLLECTOR_MULTIMODAL_SLS_LOGSTORE,
    APSARA_APM_COLLECTOR_MULTIMODAL_SLS_PROJECT,
    APSARA_APM_COLLECTOR_MULTIMODAL_SLS_STS_TOKEN)
from aliyun.sdk.extension.arms.endpoints.sls_endpoints_state import \
    global_sls_endpoint_state
from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import \
    global_arms_endpoints_state
from aliyun.sdk.extension.arms.logger import getLogger

from aliyun.opentelemetry.util.genai._multimodal_upload import PreUploader
from aliyun.opentelemetry.util.genai.extended_environment_variables import \
    OTEL_INSTRUMENTATION_GENAI_MULTIMODAL_STORAGE_BASE_PATH

from .arms_uploader import ArmsUploader

_logger = getLogger(__name__)

# SLS 多模态数据上传默认 logstore
DEFAULT_SLS_UPLOAD_LOGSTORE = "logstore-tracing"


def _get_storage_protocol(base_path: str) -> str:
    """根据 base_path 判断协议"""
    if "://" in base_path:
        return base_path.split("://", 1)[0].strip().lower()
    return ""


def _get_sls_endpoint() -> str:
    """获取 SLS endpoint，优先环境变量，否则健康检查"""
    endpoint = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ENDPOINT, "")
    if not endpoint:
        endpoint = global_sls_endpoint_state.get_sls_endpoint()
    # 确保有 https:// 前缀
    if endpoint and not endpoint.startswith("http"):
        endpoint = f"https://{endpoint}"
    return endpoint


def get_uploader(
    *,
    max_workers: int = 4,
    max_queue_size: int = 1024,
    max_queue_bytes: int = 1024 * 1024 * 1024,
    lru_cache_max_size: int = 2048,
) -> Optional[ArmsUploader]:
    """返回按环境配置好的 ArmsUploader。"""
    base_path = os.getenv(OTEL_INSTRUMENTATION_GENAI_MULTIMODAL_STORAGE_BASE_PATH, "sls://")
    protocol = _get_storage_protocol(base_path)
    
    if protocol != "sls":
        return None
    
    # 构建完整 SLS 路径
    project = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_PROJECT, "") or global_arms_endpoints_state.sls_project
    logstore = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_LOGSTORE, "") or DEFAULT_SLS_UPLOAD_LOGSTORE
    base_path = f"sls://{project}/{logstore}"
    
    # 读取 SLS 配置
    endpoint = _get_sls_endpoint()
    access_key = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_KEY, "")
    access_secret_key = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_SECRET_KEY, "")
    security_token = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_STS_TOKEN)
    
    return ArmsUploader(
        base_path=base_path,
        endpoint=endpoint,
        access_key=access_key,
        access_secret_key=access_secret_key,
        security_token=security_token,
        max_workers=max_workers,
        max_queue_size=max_queue_size,
        max_queue_bytes=max_queue_bytes,
        lru_cache_max_size=lru_cache_max_size,
    )


def get_pre_uploader() -> Optional[PreUploader]:
    """
    返回按环境配置好的 PreUploader（用于多模态数据上传）。
    
    - 使用与 ArmsUploader 相同的 base_path，保持一致性
    - SLS 场景下，构建完整路径并添加 ARMS 特有的 extra_meta
    """
    try:
        from aliyun.opentelemetry.util.genai._multimodal_upload.pre_uploader import MultimodalPreUploader
    except ImportError:
        _logger.warning("MultimodalPreUploader not available")
        return None

    base_path = os.getenv(OTEL_INSTRUMENTATION_GENAI_MULTIMODAL_STORAGE_BASE_PATH, "sls://")
    protocol = _get_storage_protocol(base_path)
    
    # 目前只支持 SLS 协议
    if protocol != "sls":
        return None
    
    # SLS 场景：构建完整路径（包含 project/logstore）
    project = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_PROJECT, "") or global_arms_endpoints_state.sls_project
    logstore = os.getenv(APSARA_APM_COLLECTOR_MULTIMODAL_SLS_LOGSTORE, "") or DEFAULT_SLS_UPLOAD_LOGSTORE
    base_path = f"sls://{project}/{logstore}"
    
    # ARMS 特有的 extra_meta 仍需从 ArmsEnv 获取
    # 延迟导入避免循环依赖
    from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
    env = ArmsEnv.instance()
    extra_meta = {
        "workspaceId": env.workspace,
        "serviceId": env.service_id,
    }
    
    return MultimodalPreUploader(base_path=base_path, extra_meta=extra_meta)
