import cProfile
import pstats
import tracemalloc
import os
import io
import threading
from datetime import datetime
from typing import Optional

from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.logger import getLogger, get_log_dir

arms_profile: Optional[cProfile.Profile] = None
_auto_stop_timer: Optional[threading.Timer] = None
_logger = getLogger(__name__)

def start_resource_monitor():
    """启动资源监控，包括CPU和内存分析"""
    global arms_profile, _auto_stop_timer
    try:
        if not arms_profile:
            arms_profile = cProfile.Profile()
        arms_profile.enable()
        tracemalloc.start()
        
        # 设置15分钟后自动停止监控
        _auto_stop_timer = threading.Timer(900.0, stop_resource_monitor)  # 900秒 = 15分钟
        _auto_stop_timer.start()
        _logger.warning("Resource monitoring started successfully, will auto-stop in 15 minutes")
    except Exception as e:
        _logger.error(f"Failed to start resource monitoring: {e}")

def stop_resource_monitor():
    """停止资源监控并输出分析结果到日志文件"""
    # 取消自动停止定时器
    global arms_profile, _auto_stop_timer
    if _auto_stop_timer and _auto_stop_timer.is_alive():
        _auto_stop_timer.cancel()
        _auto_stop_timer = None
    log_dir = get_log_dir()
    if not log_dir:
        _logger.error("Cannot get log directory, skipping profiling output")
        return
    
    try:
        # 输出CPU profiling信息
        if arms_profile:
            arms_profile.disable()
            cpu_profiling_file = os.path.join(log_dir, f"cpu_profiling-{ArmsEnv.instance().appId}-{ArmsEnv.instance().get_agent_ip()}.log")
            _write_cpu_profiling(arms_profile, cpu_profiling_file)
            _logger.warning(f"CPU profiling data written to {cpu_profiling_file}")
        
        # 输出内存profiling信息
        if tracemalloc.is_tracing():
            mem_profiling_file = os.path.join(log_dir, f"mem_profiling-{ArmsEnv.instance().appId}-{ArmsEnv.instance().get_agent_ip()}.log")
            _write_memory_profiling(mem_profiling_file)
            tracemalloc.stop()
            _logger.warning(f"Memory profiling data written to {mem_profiling_file}")
            
    except Exception as e:
        _logger.error(f"Failed to write profiling data: {e}")
    finally:
        # 确保清理资源
        if arms_profile:
            arms_profile = None
        if tracemalloc.is_tracing():
            tracemalloc.stop()
        if _auto_stop_timer:
            _auto_stop_timer = None

def _write_cpu_profiling(profiler: cProfile.Profile, output_file: str):
    """将CPU profiling信息写入文件"""
    try:
        # 创建pstats对象并排序
        stream = io.StringIO()
        ps = pstats.Stats(profiler, stream=stream).sort_stats("tottime")
        ps.print_stats(20)
        # 输出到output_file中
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(stream.getvalue())
    except Exception as e:
        _logger.error(f"Failed to write CPU profiling data: {e}")

def _write_memory_profiling(output_file: str):
    """将内存profiling信息写入文件"""
    try:
        # 获取当前内存快照
        snapshot = tracemalloc.take_snapshot()
        top_stats = snapshot.statistics('lineno')
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"=== Memory Profiling Report - {datetime.now().isoformat()} ===\n")
            f.write(f"Total memory blocks: {len(snapshot.traces)}\n")
            f.write("=" * 80 + "\n\n")
            
            # 输出前20个内存使用最多的位置
            f.write("Top 20 memory allocations:\n")
            for index, stat in enumerate(top_stats[:20], 1):
                f.write(f"{index:2d}. {stat}\n")
            
            f.write("\n" + "=" * 80 + "\n")
            f.write("Memory usage by traceback:\n")
            
            # 按traceback分组显示
            for stat in top_stats[:10]:
                f.write(f"\n{stat}\n")
                for line in stat.traceback.format():
                    f.write(f"  {line}")
                    
    except Exception as e:
        _logger.error(f"Failed to write memory profiling data: {e}")


