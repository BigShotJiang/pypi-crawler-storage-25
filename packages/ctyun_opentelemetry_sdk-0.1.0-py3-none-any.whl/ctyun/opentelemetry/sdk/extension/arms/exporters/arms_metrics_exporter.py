import json
from typing import Dict

from aliyun.sdk.extension.arms.config.constant import CMS_WORKSPACE, SLS_PROJECT
from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state
from aliyun.sdk.extension.arms.self_monitor.self_monitor import _self_monitor_metrics
from aliyun.sdk.extension.arms.proto.arms_measures_pb2 import (
    MeasureBatches,
    MeasureBatch,
    Measures,
    Measure,
    EnumUnit
)
from aliyun.sdk.extension.arms.converter.arms_metric_data_converter import ArmsMetricDataConverter
from aliyun.sdk.extension.arms.controller.controller import metricExporterController

from aliyun.opentelemetry.sdk.metrics.export import (
    AggregationTemporality,
    Gauge,
    Histogram,
    Metric,
    MetricExporter,
    MetricExportResult,
    MetricsData,
    Sum,
)
from aliyun.opentelemetry.sdk.metrics import (
    Counter,
    Histogram,
    ObservableCounter,
    ObservableGauge,
    ObservableUpDownCounter,
    UpDownCounter,
)
from aliyun.sdk.extension.arms.utils import (
    _create_exp_backoff_generator
)
from aliyun.sdk.extension.arms.common.constant import Compression
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from io import BytesIO
import gzip
import zlib
SNAPPY_ENABLED = True
try:
    import snappy
except ImportError:
    SNAPPY_ENABLED = False
import requests
import asyncio
from time import sleep
import os

from aliyun.sdk.extension.arms.logger import getLogger, diagnose_logger

_logger = getLogger(__name__)
_diag_logger = diagnose_logger("metrics_exporter")


class ArmsMetricsExporter(MetricExporter):
    _MAX_RETRY_TIMEOUT = 64

    # TODO @zaiyun
    def __init__(self, preferred_temporality: Dict[type, AggregationTemporality] = None, preferred_aggregation: Dict[
        type, "aliyun.opentelemetry.sdk.metrics.view.Aggregation"
    ] = None) -> None:
        instrument_class_temporality = {
            Counter: AggregationTemporality.DELTA,
            UpDownCounter: AggregationTemporality.DELTA,
            Histogram: AggregationTemporality.DELTA,
            ObservableCounter: AggregationTemporality.DELTA,
            ObservableUpDownCounter: AggregationTemporality.DELTA,
            ObservableGauge: AggregationTemporality.DELTA,
        }
        super().__init__(instrument_class_temporality, preferred_aggregation)
        self._metric_convertor = ArmsMetricDataConverter()
        self._endpoint = f"{global_arms_endpoints_state.get_full_metric_url()}"
        self._timeout = 10
        self._compression = Compression.Snappy
        self._session = requests.Session()

    # TODO @zaiyun complete this function to export `measureBatchers` to ArmsMetricsEndpoint
    #   1. Export interval need to be configurable, default interval is 15s
    #   2. Don't enable keep-alive, make sure that the connection between agent and server will be reset after some certain time
    def export_internel(self, measureBatches: MeasureBatches):
        pass

    def export(self, metrics_data: MetricsData, timeout_millis: float = 10, **kwargs) -> MetricExportResult:
        if not metricExporterController.is_open():
            _logger.warning("[arms_metrics_exporter] metricExporterController is not open")
            return MetricExportResult.FAILURE
        # arms batch metric data which should be sent to prometheus
        metric_batches = self._metric_convertor.convert_to_arms_metric(metrics_data)
        app_serialized_data, self_monitor_serialized_data = metric_batches.app_measure_batches, metric_batches.self_monitor_measure_batches

        for delay in _create_exp_backoff_generator(
                max_value=self._MAX_RETRY_TIMEOUT
        ):
            if delay == self._MAX_RETRY_TIMEOUT:
                return MetricExportResult.FAILURE

            app_serialized_data_str = app_serialized_data.SerializeToString()
            try:
                from urllib3.connectionpool import log
                log.disabled = True
            except Exception:
                pass
            resp = self._export(app_serialized_data_str, )

            self._export(self_monitor_serialized_data.SerializeToString(), True)

            # pylint: disable=no-else-return
            if resp.ok:
                del app_serialized_data
                _self_monitor_metrics.record_agent_metric_report(len(app_serialized_data_str),
                                                                      {"status": resp.status_code, "result": "success"})
                return MetricExportResult.SUCCESS
            elif self._retryable(resp):
                _logger.warning(
                    "Transient error %s encountered while exporting metric batch, retrying in %ss.",
                    resp.reason,
                    delay,
                )
                # 记录到诊断日志
                _diag_logger.warning("----------- METRICS EXPORTER RETRY -----------")
                _diag_logger.warning(f"Metrics export retry - Status: {resp.status_code}")
                _diag_logger.warning(f"Reason: {resp.reason}")
                _diag_logger.warning(f"Retrying in {delay}s")
                _diag_logger.warning(f"Endpoint: {self._endpoint}")
                _diag_logger.warning("----------- END METRICS EXPORTER RETRY -----------")
                sleep(delay)
                continue
            else:
                _self_monitor_metrics.record_agent_metric_report(
                    len(app_serialized_data_str),
                    {"status": resp.status_code, "result": "fail"})
                _logger.error(
                    "Failed to export batch code: %s, reason: %s",
                    resp.status_code,
                    resp.text,
                )
                # 记录到诊断日志
                _diag_logger.error("----------- METRICS EXPORTER FAILURE -----------")
                _diag_logger.error(f"Metrics export failed - Status: {resp.status_code}")
                _diag_logger.error(f"Reason: {resp.text}")
                _diag_logger.error(f"Endpoint: {self._endpoint}")
                _diag_logger.error(f"Data size: {len(app_serialized_data_str)} bytes")
                _diag_logger.error("----------- END METRICS EXPORTER FAILURE -----------")
                del app_serialized_data
                return MetricExportResult.FAILURE
        _self_monitor_metrics.record_agent_metric_report(
            len(app_serialized_data_str),
            {"status": "NULL", "result": "timeout"})
        del app_serialized_data
        return MetricExportResult.FAILURE

    def _export(self, serialized_data: bytes, is_self_monitor: bool = False):
        data = serialized_data
        if self._compression == Compression.Gzip:
            gzip_data = BytesIO()
            with gzip.GzipFile(fileobj=gzip_data, mode="w") as gzip_stream:
                gzip_stream.write(serialized_data)
            data = gzip_data.getvalue()
        elif self._compression == Compression.Deflate:
            data = zlib.compress(serialized_data)
        elif SNAPPY_ENABLED and self._compression == Compression.Snappy:
            data = snappy.compress(serialized_data)
        self._endpoint = f"{global_arms_endpoints_state.get_full_metric_url()}"
        if SNAPPY_ENABLED:
            headers = {"Content-Type": "text/plain", "content.encoding": "snappy", "X-ARMS-Encoding": "snappy"}
        else:
            headers = {"Content-Type": "text/plain", "content.encoding": "", "X-ARMS-Encoding": ""}
        if is_self_monitor:
            headers.update({"X-ARMS-DataType": "self-monitor"})
            # cms workspace needed
        if global_arms_endpoints_state.use_one_endpoints:
            headers.update(
                {CMS_WORKSPACE: ArmsEnv.instance().workspace, SLS_PROJECT: global_arms_endpoints_state.sls_project})
        resp = self._session.post(
            url=self._endpoint,
            data=data,
            timeout=self._timeout,
            headers=headers
        )
        if resp.status_code != 200:
            _logger.warning(
                f"[arms_metrics_exporter] Sending metric to endpoints: {self._endpoint}, response code is: {resp.status_code}")
            # 记录到诊断日志
            _diag_logger.warning("----------- METRICS EXPORTER HTTP ERROR -----------")
            _diag_logger.warning(f"Metrics HTTP error - Status: {resp.status_code}")
            _diag_logger.warning(f"Endpoint: {self._endpoint}")
            _diag_logger.warning(f"Response text: {resp.text}")
            _diag_logger.warning(f"Data size: {len(data)} bytes")
            _diag_logger.warning(f"Is self-monitor: {is_self_monitor}")
            _diag_logger.warning("----------- END METRICS EXPORTER HTTP ERROR -----------")
        del data
        return resp

    # convert metric to arms measure
    def _convert_metric(self, metrics_data: MetricsData) -> MetricExportResult:
        md_json = metrics_data.to_json()
        for rms in metrics_data.resource_metrics:
            for scm in rms.scope_metrics:
                for metric in scm.metrics:
                    measure = Measure(
                        valueType=self._get_measure_vaule_type(metric.unit),
                        unit=self._get_measure_unit(metric.unit),
                        name=metric.name,
                        desc=metric.description,
                    )
                    metric.data.data_points

    def _get_measure_vaule_type(self, value_type: str):
        pass

    def _get_measure_unit(self, unit_str: str) -> EnumUnit:
        '''
        get measure unit
        '''
        unit = EnumUnit.UNKNOWN
        if str == "s":
            unit = EnumUnit.SECOND
        elif str == "ms":
            unit = EnumUnit.MILLISECONDS
        elif str == "count":
            unit = EnumUnit.COUNT
        elif str == "b":
            unit = EnumUnit.BYTE
        else:
            unit = EnumUnit.UNKNOWN
        return unit

    def force_flush(self, timeout_millis: float = 10) -> bool:
        _logger.warning(f"[force_flush]")

    def shutdown(self, timeout_millis: float = 30, **kwargs) -> None:
        pass

    @staticmethod
    def _retryable(resp: requests.Response) -> bool:
        if resp.status_code == 408:
            return True
        if resp.status_code >= 500 and resp.status_code <= 599:
            return True
        return False
