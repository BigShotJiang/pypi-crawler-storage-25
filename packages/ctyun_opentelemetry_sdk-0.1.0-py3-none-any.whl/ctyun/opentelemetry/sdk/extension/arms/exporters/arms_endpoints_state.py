import os

from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.common.utils.arms_utils import (
    get_md5_string_for_xtrace_project, is_default_cms_workspace)
from aliyun.sdk.extension.arms.endpoints.health_check import (
    CHECK_INTERNAL_INTRANET_PUBLIC, CHECK_INTRANET_PUBLIC,
    get_current_reachable_endpoint, start_health_check_thread)
from aliyun.sdk.extension.arms.endpoints.sls_endpoints_state import \
    global_sls_endpoint_state
from aliyun.sdk.extension.arms.exporters.arms_endpoints import ArmsEndpoints
from aliyun.sdk.extension.arms.utils import network_utils

REGION_ID_LENGTH_THRESHOLD = 18

PROFILER_COLLECTOR_ONEENDPOINT_KEY = "PROFILER_COLLECTOR_ONEENDPOINT"
PROFILER_NETWORK_STRATEGY_KEY = "PROFILER_NETWORK_STRATEGY"

APSARA_APM_COLLECTOR_USE_TLS = "APSARA_APM_COLLECTOR_USE_TLS"
APSARA_APM_COLLECTOR_FORCE_USE_ONE_ENDPOINT = "APSARA_APM_COLLECTOR_FORCE_USE_ONE_ENDPOINT"

NETWORK_STRATEGY_INTERNAL = "internal"
NETWORK_STRATEGY_PUBLIC = "public"
NETWORK_STRATEGY_AUTO = "auto"
NETWORK_STRATEGY_INTRANET = "intranet"
NETWORK_STRATEGY_SHARE = "share"

class ArmsEndpointState:
    def __init__(self):
        self.trace_endpoints = ArmsEndpoints(ArmsEnv.instance().getTraceEndpoint(), ".aliyuncs", "/api/checkHealth")
        self.metric_endpoints = ArmsEndpoints(ArmsEnv.instance().getMetricsEndpoint(), ".arms", "/health/readiness")
        self.meta_endpoints = ArmsEndpoints(ArmsEnv.instance().getMetaEndpoint(), ".aliyuncs", "/api/checkHealth")
        # one_endpoints已移除，改为复用global_sls_endpoint_state的健康检查结果
        # 因为one_endpoints只是在sls_endpoint前加上project子域名，联通性等价
        self.one_endpoint = ""
        self.use_one_endpoints = False
        self.sls_project = ""
        self.force_one_endpoint = os.getenv(PROFILER_COLLECTOR_ONEENDPOINT_KEY, "")
        self.force_use_one_endpoint = bool(os.getenv(APSARA_APM_COLLECTOR_FORCE_USE_ONE_ENDPOINT, False))
        self.use_tls = bool(os.getenv(APSARA_APM_COLLECTOR_USE_TLS, False))
        self.network_strategy = os.getenv(PROFILER_NETWORK_STRATEGY_KEY, "auto")
        # 兼容老逻辑
        if bool(os.getenv("ARMS_IS_PUBLIC", False)):
            self.network_strategy = NETWORK_STRATEGY_PUBLIC
        self.init_one_endpoint()
        self.start_health_check_task()

    def init_one_endpoint(self):
        """
        初始化SLS one endpoint配置
        注意：不再创建独立的one_endpoints对象，而是复用global_sls_endpoint_state的健康检查结果
        """
        cms_workspace = ArmsEnv.instance().workspace
        user_id = ArmsEnv.instance().user_id
        region_id = ArmsEnv.instance().regionId
        is_default_workspace = is_default_cms_workspace(user_id, region_id, cms_workspace)
        is_finance_or_long_name_region = ("finance" in region_id or len(region_id) > REGION_ID_LENGTH_THRESHOLD)
        project = ""
        if is_default_workspace:
            if is_finance_or_long_name_region:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id + ArmsEnv.instance().regionId)
            else:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id) + "-" + ArmsEnv.instance().regionId
        else:
            if is_finance_or_long_name_region:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id + cms_workspace + ArmsEnv.instance().regionId)
            else:
                project = "proj-xtrace-" + get_md5_string_for_xtrace_project(
                    ArmsEnv.instance().user_id + cms_workspace) + "-" + ArmsEnv.instance().regionId
        # 保存配置，实际的endpoint通过global_sls_endpoint_state获取
        self.use_one_endpoints = (not is_default_workspace) or self.force_use_one_endpoint
        self.cms_workspace = cms_workspace
        self.sls_project = project

    def get_one_endpoint(self):
        """
        获取one endpoint（基于SLS endpoint构建）
        复用global_sls_endpoint_state的健康检查结果，在其前面加上project子域名
        保持network_strategy的动态选择能力
        """
        # 如果设置了强制endpoint（环境变量PROFILER_COLLECTOR_ONEENDPOINT），直接使用
        if self.one_endpoint:
            return self.one_endpoint

        # 根据network_strategy选择合适的SLS endpoint变体
        sls_endpoints = global_sls_endpoint_state.sls_endpoints

        if self.network_strategy == NETWORK_STRATEGY_INTERNAL:
            base_endpoint = sls_endpoints.internal_endpoint
        elif self.network_strategy == NETWORK_STRATEGY_INTRANET:
            base_endpoint = sls_endpoints.intranet_endpoint
        elif self.network_strategy == NETWORK_STRATEGY_PUBLIC:
            base_endpoint = sls_endpoints.public_endpoint
        elif self.network_strategy == NETWORK_STRATEGY_SHARE:
            base_endpoint = sls_endpoints.share_endpoint
        else:
            # auto模式：动态选择当前可达的endpoint
            base_endpoint = get_current_reachable_endpoint(sls_endpoints)
            if not base_endpoint:
                # 如果都不可达，fallback到intranet
                base_endpoint = sls_endpoints.intranet_endpoint

        # 在选定的SLS endpoint前加上project子域名
        # 例如: proj-xtrace-xxx.cn-shanghai-internal.log.aliyuncs.com
        return f"{self.sls_project}.{base_endpoint}"

    def get_current_reachable_endpoint(self, endpoints):
        """获取当前可达的endpoint（复用公共函数）"""
        return get_current_reachable_endpoint(endpoints)

    def get_full_trace_url(self):
        if self.use_one_endpoints:
            if self.force_one_endpoint and len(self.force_one_endpoint) > 0:
                return self.concat_full_url(self.force_one_endpoint + "/apm/trace/api/v1/arms/otel/")
            else:
                return self.concat_full_url(self.get_one_endpoint() + "/apm/trace/api/v1/arms/otel/")

        endpoint = self.get_endpoint_by_strategy_or_auto(self.trace_endpoints,
                                                         lambda: self.trace_endpoints.internal_endpoint)
        return self.concat_full_url(endpoint + "/api/v1/arms/otel/")

    def get_full_metric_url(self):
        if self.use_one_endpoints:
            if self.force_one_endpoint and len(self.force_one_endpoint) > 0:
                return self.concat_full_url(self.force_one_endpoint + "/apm/metric/collector/arms/ot/")
            else:
                return self.concat_full_url(self.get_one_endpoint() + "/apm/metric/collector/arms/ot/")
        endpoint = self.get_endpoint_by_strategy_or_auto(self.metric_endpoints,
                                                         lambda: self.metric_endpoints.intranet_endpoint)
        return self.concat_full_url(endpoint + "/collector/arms/ot/")

    def get_full_meta_url(self):
        if self.use_one_endpoints:
            if self.force_one_endpoint and len(self.force_one_endpoint) > 0:
                return self.concat_full_url(self.force_one_endpoint + "/apm/meta/api/v2/arms/metadata/")
            else:
                return self.concat_full_url(self.get_one_endpoint() + "/apm/meta/api/v2/arms/metadata/")
        endpoint = self.get_endpoint_by_strategy_or_auto(self.meta_endpoints,
                                                         lambda: self.meta_endpoints.internal_endpoint)
        return self.concat_full_url(endpoint + "/api/v2/arms/metadata/")

    def concat_full_url(self, endpoint):
        if self.use_tls:
            return "https://" + endpoint + ArmsEnv.instance().licenseKey + "/" + ArmsEnv.instance().appId
        return "http://" + endpoint + ArmsEnv.instance().licenseKey + "/" + ArmsEnv.instance().appId

    def get_endpoint_by_strategy_or_auto(self, endpoints, internal_endpoint_supplier):
        endpoint = None
        if self.network_strategy == NETWORK_STRATEGY_INTERNAL:
            endpoint = internal_endpoint_supplier()
        elif self.network_strategy == NETWORK_STRATEGY_PUBLIC:
            endpoint = endpoints.public_endpoint
        else:
            endpoint = self.get_current_reachable_endpoint(endpoints)
        return endpoint if endpoint else global_sls_endpoint_state.sls_endpoints.intranet_endpoint

    def start_health_check_task(self):
        """
        启动健康检查任务（复用公共健康检查函数）
        注意：one_endpoints的健康检查由global_sls_endpoint_state负责，这里不再重复检查
        """
        def is_endpoint_reachable(endpoint: str, health_path: str) -> bool:
            """检查endpoint是否可达"""
            return network_utils.is_url_reachable(endpoint + health_path)

        # 使用公共的健康检查启动函数
        # 只检查trace/metric/meta endpoints
        # one_endpoints的健康检查已由global_sls_endpoint_state处理（联通性等价）
        endpoints_list = [
            (self.trace_endpoints, CHECK_INTERNAL_INTRANET_PUBLIC, is_endpoint_reachable),  # trace
            (self.metric_endpoints, CHECK_INTRANET_PUBLIC, is_endpoint_reachable),          # metric
            (self.meta_endpoints, CHECK_INTERNAL_INTRANET_PUBLIC, is_endpoint_reachable)    # meta
        ]

        start_health_check_thread(
            name="ARMS-HealthCheck",
            endpoints_list=endpoints_list,
            check_interval=60
        )



global_arms_endpoints_state = ArmsEndpointState()

