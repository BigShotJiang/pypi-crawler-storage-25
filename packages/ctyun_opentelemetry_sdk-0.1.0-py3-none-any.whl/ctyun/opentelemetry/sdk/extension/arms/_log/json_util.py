"""
JSON 序列化工具

这个模块提供了将 OpenTelemetry 对象序列化为 JSON 的功能，
包括 LogRecord、Resource 和 InstrumentationScopeInfo。
"""

import json
from typing import List, Union, Sequence
from aliyun.opentelemetry.sdk._logs import LogData
from aliyun.opentelemetry.util.types import AttributeValue
from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)


class JsonUtil:
    """JSON serialization tool class"""
    
    
    @staticmethod
    def serialize_log(log_data: LogData) -> str:
        """
        Serialize LogRecord object to JSON string

        May throw exceptions
        """
        log_record = log_data.log_record
        resource_obj = None
        if hasattr(log_record, "resource") and log_record.resource is not None:
            resource_obj = {
                "attributes": {}
            }
            if hasattr(log_record.resource, "attributes") and log_record.resource.attributes is not None:
                resource_attributes = log_record.resource.attributes
                for key, value in resource_attributes.items():
                    resource_obj["attributes"][key] = JsonUtil._serialize_attribute_value(value)

        scope_obj = None
        if hasattr(log_data, "instrumentation_scope") and log_data.instrumentation_scope is not None:
            scope_obj = {
                "name": log_data.instrumentation_scope.name or "",
                "version": log_data.instrumentation_scope.version or "",
            }

        result = {
            "resource": resource_obj,
            "scope": scope_obj,
            "timeUnixNano": log_record.timestamp,
        }

        if hasattr(log_record, "severity_number") and log_record.severity_number is not None:
            severity = log_record.severity_number
            result["severity"] = severity.name

        if hasattr(log_record, "severity_text") and log_record.severity_text is not None:
            severity_text = log_record.severity_text
            result["severityText"] = severity_text

        # Body
        if hasattr(log_record, "body") and log_record.body is not None:
            body = log_record.body
            result["body"] = str(body)

        # Attributes
        result["attributes"] = {}
        if hasattr(log_record, "attributes") and log_record.attributes is not None:
            attributes = log_record.attributes
            for key, value in attributes.items():
                result["attributes"][key] = JsonUtil._serialize_attribute_value(value)

        # Span context
        result["traceId"] = log_record.trace_id
        result["spanId"] = log_record.span_id

        return json.dumps(result, ensure_ascii=False)
    
    @staticmethod
    def _serialize_attribute_value(value: AttributeValue) -> Union[str, int, float, bool, List[str], List[int], List[float], List[bool], None]:
        """Serialize attribute value based on OpenTelemetry AttributeValue type
        
        Optimized implementation that leverages the known AttributeValue type definition:
        AttributeValue = Union[str, bool, int, float, Sequence[str], Sequence[bool], Sequence[int], Sequence[float]]
        """
        if value is None:
            return None
        
        if isinstance(value, str):
            return value
        elif isinstance(value, bool):
            return value
        elif isinstance(value, int):
            return value
        elif isinstance(value, float):
            return value
        
        if isinstance(value, Sequence):
            if not value:
                return []
            
            first_element = value[0]
            
            if isinstance(first_element, str):
                return list(value)
            elif isinstance(first_element, bool):
                return list(value)
            elif isinstance(first_element, int):
                return list(value)
            elif isinstance(first_element, float):
                return list(value)
            else:
                return [str(item) for item in value]
        
        # Shouldn't reach here
        return str(value)
