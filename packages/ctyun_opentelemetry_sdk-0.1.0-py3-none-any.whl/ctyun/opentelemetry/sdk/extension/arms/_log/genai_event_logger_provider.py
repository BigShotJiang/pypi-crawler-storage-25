import os
from typing import Optional, Any

from aliyun.opentelemetry._logs import Logger, LoggerProvider
from aliyun.opentelemetry.sdk._logs import LoggerProvider as SdkLoggerProvider
from aliyun.opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from aliyun.opentelemetry.sdk.resources import Resource

from .local_file_log_exporter import LocalFileLogRecordExporter
from aliyun.sdk.extension.arms.logger import get_log_dir, getLogger

logger = getLogger(__name__, add_sls_log_handler=False)

class GenAiEventLoggerProvider(LoggerProvider):
    """GenAI Event LoggerProvider
    
    This LoggerProvider creates a Logger for recording GenAI events,
    with independent log files and isolated from the global LoggerProvider.
    
    Note: We cannot reuse the global LoggerProvider and bridge it in instrumentations,
    because application logs will be captured by default, and logs we don't want will also be exported.
    """
    
    def __init__(self, 
                 resource: Optional[Resource] = None,
                 log_directory: Optional[str] = None,
                 log_file_prefix: Optional[str] = None,
                 max_file_size: Optional[int] = None,
                 host_ip: Optional[str] = None):
        """
        Args:
            resource: resource, default is None
            log_directory: log directory, default is the logs directory in the agent workspace
            log_file_prefix: log file prefix, default is "genai_messages"
            max_file_size: maximum size of a log file, default is 256MB
        """
        # get the agent workspace directory as default
        if log_directory is None:
            default_log_dir = get_log_dir()
            if default_log_dir is None:
                print("Agent Workspace error detected. Please set the environment variable APSARA_APM_AGENT_WORKSPACE_DIR.")
                logger.warning("Agent Workspace error detected. Please set the environment variable APSARA_APM_AGENT_WORKSPACE_DIR.")
                return
            self.log_directory: str = default_log_dir
        else:
            self.log_directory: str = log_directory
        
        pid = os.getpid()
        if host_ip:
            self.log_file_prefix: str = log_file_prefix or f"genai_messages_{host_ip}_{pid}"
        else:
            self.log_file_prefix: str = log_file_prefix or f"genai_messages_null_{pid}"
        
        self._exporter: LocalFileLogRecordExporter = LocalFileLogRecordExporter(
            package_type="genai-event",
            log_directory=self.log_directory,
            log_file_prefix=self.log_file_prefix,
            max_file_size=max_file_size
        )
        
        self._processor: BatchLogRecordProcessor = BatchLogRecordProcessor(self._exporter)
        
        self._delegate: SdkLoggerProvider = SdkLoggerProvider(
            resource=resource,
        )
        self._delegate.add_log_record_processor(self._processor)
    
    def get_logger(self, 
                   name: str, 
                   version: Optional[str] = None, 
                   schema_url: Optional[str] = None,
                   **kwargs: Any) -> Logger:
        """get the GenAI Logger"""
        return self._delegate.get_logger(name, version, schema_url, **kwargs)


_instance: Optional[GenAiEventLoggerProvider] = None


def get_genai_logger_provider() -> Optional[GenAiEventLoggerProvider]:
    """get the global GenAI logger provider instance"""
    return _instance


def set_genai_logger_provider(instance: GenAiEventLoggerProvider) -> None:
    """set the global GenAI logger provider instance"""
    global _instance
    _instance = instance

