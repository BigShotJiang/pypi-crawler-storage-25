"""
本地文件日志记录导出器

这个模块实现了将 OpenTelemetry 日志记录导出到本地文件的功能，
支持日志轮转、JSON 格式输出和高性能写入。
"""
from __future__ import annotations
import os
import threading
from pathlib import Path
from typing import Collection, Optional, TextIO

from aliyun.opentelemetry.sdk._logs.export import LogExporter, LogExportResult
from aliyun.opentelemetry.sdk._logs import LogData
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.self_monitor.self_monitor import _self_monitor_metrics
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from .json_util import JsonUtil

_logger = getLogger(__name__)


class LocalFileLogRecordExporter(LogExporter):
    """Local file log record exporter
    
    Supports exporting OpenTelemetry log records to local files, with the following features:
    - Synchronous writing
    - Automatic log rotation
    - JSON format output
    - Thread safe
    """
    
    # Configuration constants
    DEFAULT_LOG_DIR = "logs"
    DEFAULT_LOG_FILE_PREFIX = "instrumentation-logs"
    LOG_FILE_EXTENSION = ".log"
    DEFAULT_MAX_FILE_SIZE = 256 * 1024 * 1024  # 256MB
    DEFAULT_MAX_LOG_ENTRY_SIZE = 5 * 1024 * 1024  # 5MB
    BUFFER_SIZE = 32 * 1024  # 32KB buffer
    
    def __init__(self,
                 package_type: str = "log",
                 log_directory: Optional[str] = None,
                 log_file_prefix: Optional[str] = None,
                 max_file_size: Optional[int] = None):
        """
        Args:
            log_directory: log directory, default is "logs"
            log_file_prefix: log file prefix, default is "genai_messages"
            max_file_size: maximum size of a log file, default is 256MB
        """
        self.package_type = package_type
        self.log_directory = log_directory or self.DEFAULT_LOG_DIR
        self.log_file_prefix = log_file_prefix or self.DEFAULT_LOG_FILE_PREFIX
        self.max_file_size = max_file_size or self.DEFAULT_MAX_FILE_SIZE
        
        # Runtime fields
        self._is_shutdown: bool = False
        self._write_lock: threading.RLock = threading.RLock()
        self._current_writer: Optional[TextIO] = None
        self._current_log_file: Optional[str] = None
        self._current_log_file_name: Optional[str] = None
        self._current_file_size: int = 0
        
        # Initialize log directory and first log file
        self._initialize_log_directory()
    
    def _initialize_log_directory(self) -> None:
        """Initialize log directory and create first log file"""
        try:
            log_dir_path = Path(self.log_directory)
            if not log_dir_path.exists():
                log_dir_path.mkdir(parents=True, exist_ok=True)
                _logger.info(f"GenAI Logger: Created log directory: {self.log_directory}")
            
            # Initialize first log file
            self._rotate_log_file()
        except Exception as e:
            _logger.error(f"GenAI Logger: Failed to initialize log directory: {self.log_directory}, error: {e}")
    
    def _rotate_log_file(self) -> None:
        """Rotate current log file and create new file"""
        with self._write_lock:
            try:
                # Close current writer
                if self._current_writer is not None:
                    try:
                        self._current_writer.close()
                    except Exception as e:
                        _logger.error(f"GenAI Logger: Failed to close current log writer: {e}")
                
                main_log_file_name = f"{self.log_file_prefix}{self.LOG_FILE_EXTENSION}"
                main_log_file_path = Path(self.log_directory) / main_log_file_name
                
                # If main log file exists, rename it to .1
                rotate_success = True
                if main_log_file_path.exists():
                    rotated_log_file_path = Path(self.log_directory) / f"{main_log_file_name}.1"
                    try:
                        # If .1 file exists, delete it first (it's the oldest)
                        if rotated_log_file_path.exists():
                            rotated_log_file_path.unlink()
                            _logger.info(f"GenAI Logger: Deleted oldest log file: {rotated_log_file_path}")
                        
                        main_log_file_path.rename(rotated_log_file_path)
                        _logger.info(f"GenAI Logger: Rotated log file: {main_log_file_path} -> {rotated_log_file_path}")
                    except Exception as e:
                        _logger.error(f"GenAI Logger: Failed to rotate log file: {main_log_file_path}, error: {e}")
                        rotate_success = False
                
                # Create new main log file
                self._current_log_file_name = main_log_file_name
                self._current_log_file = str(main_log_file_path)

                # If rotate failed, use 'w' mode to start fresh and avoid size limit issues
                open_mode = 'w' if not rotate_success else 'a'
                self._current_writer = open(main_log_file_path, open_mode, encoding='utf-8', buffering=self.BUFFER_SIZE)
                self._current_file_size = 0
                
                _logger.info(f"GenAI Logger: Created new log file: {main_log_file_path}")
                _self_monitor_metrics.record_agent_event_log_file_rotate_count(1, self._build_arms_arributes())
            except Exception as e:
                _logger.error(f"GenAI Logger: Failed to rotate log file: {e}")
                raise
    
    def _write_log_entry(self, log_entry: str) -> None:
        """Write log entry to current log file"""
        with self._write_lock:
            try:
                if self._current_writer is None:
                    self._rotate_log_file()
                
                # Check if we need to rotate due to file size
                entry_size = len(log_entry.encode('utf-8'))
                if self._current_file_size + entry_size > self.max_file_size:
                    self._rotate_log_file()
                
                # Write log entry
                self._current_writer.write(log_entry)
                self._current_writer.write('\n')
                self._current_writer.flush()
                
                self._current_file_size += entry_size + 1  # +1 for newline character
            except Exception as e:
                _logger.error(f"GenAI Logger: Failed to write log entry: {e}")
    
    
    def export(self, log_records: Collection[LogData]) -> LogExportResult:
        """Export log records"""
        if self._is_shutdown:
            return LogExportResult.FAILURE
        
        if not log_records:
            return LogExportResult.SUCCESS
        
        success_length = 0
        success_count = 0
        try:
            for log in log_records:
                log_entry = JsonUtil.serialize_log(log)
                if log_entry is not None and len(log_entry) > self.DEFAULT_MAX_LOG_ENTRY_SIZE:
                    _logger.warning(f"GenAI Logger: Log entry is too large, skipped. Log entry size: {len(log_entry)}")
                    continue
                self._write_log_entry(log_entry)
                success_length += len(log_entry)
                success_count += 1
            
            attributes =self._build_arms_arributes()
            attributes.update({"result": "success"})
            _self_monitor_metrics.record_agent_event_log_report(success_count, success_length, attributes)
            return LogExportResult.SUCCESS
        except Exception as e:
            _logger.error(f"GenAI Logger: Unexpected error during log export: {e}")
            attributes = self._build_arms_arributes()
            attributes.update({"result": "error"})
            _self_monitor_metrics.record_agent_event_log_report(len(log_records) - success_count, 0, attributes)
            return LogExportResult.FAILURE
    
    def shutdown(self) -> LogExportResult:
        """Close exporter"""
        if self._is_shutdown:
            _logger.warning("GenAI Logger: Calling shutdown() multiple times.")
            return LogExportResult.SUCCESS
        
        self._is_shutdown = True
        
        with self._write_lock:
            try:
                if self._current_writer is not None:
                    self._current_writer.close()
                    _logger.info("GenAI Logger: Closed log writer during shutdown")
                self._current_writer = None
                return LogExportResult.SUCCESS
            except Exception as e:
                _logger.error(f"GenAI Logger: Failed to close log writer during shutdown: {e}")
                return LogExportResult.FAILURE

    def _build_arms_arributes(self) -> dict[str, str]:
        return {
            "type": self.package_type,
            "host_ip": ArmsEnv.instance().get_agent_ip(),
            "file": self._current_log_file_name,
            "directory": self.log_directory,
        }
