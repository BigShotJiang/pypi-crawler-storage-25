import os
from abc import ABC, abstractmethod
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.controller.env import InstrumentorEnum, ComponentEnum
from enum import Enum

_logger = getLogger(__name__)


class BaseController(ABC):

    def __init__(self):
        self._enable = True

    def is_open(self) -> bool:
        """
        check is open this instrumentation
        """
        return self._enable

    def open(self):
        """
        open instrument
        """
        self._enable = True

    def close(self):
        """
        close instrument
        """
        self._enable = False

    @abstractmethod
    def start(self):
        """
        start controller
        """
        pass


class SampleController(BaseController):
    """
    sample controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass


class EnvironInstrumentorEnum(Enum):
    Dashscope = "Dashscope"
    OpenAI = "OpenAI"
    OpenAIAgents = "OpenAIAgents"
    LlamaIndex = "LlamaIndex"
    Langchain = "Langchain"
    Runtime = "Runtime"
    MCP = "MCP"
    RAGFlow = "RAGFlow"
    # 新增的插件枚举
    Pymssql = "Pymssql"
    Urllib3 = "Urllib3"
    Dbapi = "Dbapi"
    Asyncpg = "Asyncpg"
    Aiopg = "Aiopg"
    Sqlite3 = "Sqlite3"
    Pymysql = "Pymysql"
    Remoulade = "Remoulade"
    Celery = "Celery"
    Jinja2 = "Jinja2"
    Psycopg = "Psycopg"
    Grpc = "Grpc"
    Tortoiseorm = "Tortoiseorm"
    ConfluentKafka = "ConfluentKafka"
    Mysql = "Mysql"
    Falcon = "Falcon"
    Click = "Click"
    Urllib = "Urllib"
    AiohttpServer = "AiohttpServer"
    Cassandra = "Cassandra"
    Pymemcache = "Pymemcache"
    Pyramid = "Pyramid"
    Elasticsearch = "Elasticsearch"
    Mysqlclient = "Mysqlclient"
    Psycopg2 = "Psycopg2"
    Pymongo = "Pymongo"
    Starlette = "Starlette"
    Pika = "Pika"
    AioPika = "AioPika"
    KafkaPython = "KafkaPython"
    Aiokafka = "Aiokafka"
    Asyncio = "Asyncio"
    Threading = "Threading"
    Milvus = "Milvus"
    CrewAI = "CrewAI"
    LiteLLM = "LiteLLM"
    Mem0 = "Mem0"
    ClaudeAgentSDK = "ClaudeAgentSDK"


class EnvironController(BaseController):

    def __init__(self, environ_instrumentor: EnvironInstrumentorEnum):
        super().__init__()
        self._enable_instrumentor = ""
        if environ_instrumentor == EnvironInstrumentorEnum.Dashscope:
            self._enable_instrumentor = "ENABLE_DASHSCOPE_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.OpenAI:
            self._enable_instrumentor = "ENABLE_OPENAI_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.OpenAIAgents:
            self._enable_instrumentor = "ENABLE_OPENAI_AGENTS_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.LlamaIndex:
            self._enable_instrumentor = "ENABLE_LLAMA_INDEX_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Langchain:
            self._enable_instrumentor = "ENABLE_LANGCHAIN_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Runtime:
            self._enable_instrumentor = "ENABLE_GC_TOTAL_TIME_CALLBACK"
        elif environ_instrumentor == EnvironInstrumentorEnum.MCP:
            self._enable_instrumentor = "ENABLE_MCP_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.RAGFlow:
            self._enable_instrumentor = "ENABLE_RAGFLOW_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.LiteLLM:
            self._enable_instrumentor = "ENABLE_LITELLM_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.CrewAI:
            self._enable_instrumentor = "ENABLE_CREWAI_INSTRUMENTOR"
        # 新增插件的环境变量处理
        elif environ_instrumentor == EnvironInstrumentorEnum.Pymssql:
            self._enable_instrumentor = "ENABLE_PYMSSQL_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Urllib3:
            self._enable_instrumentor = "ENABLE_URLLIB3_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Dbapi:
            self._enable_instrumentor = "ENABLE_DBAPI_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Asyncpg:
            self._enable_instrumentor = "ENABLE_ASYNCPG_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Aiopg:
            self._enable_instrumentor = "ENABLE_AIOPG_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Sqlite3:
            self._enable_instrumentor = "ENABLE_SQLITE3_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Pymysql:
            self._enable_instrumentor = "ENABLE_PYMYSQL_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Remoulade:
            self._enable_instrumentor = "ENABLE_REMOULADE_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Celery:
            self._enable_instrumentor = "ENABLE_CELERY_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Jinja2:
            self._enable_instrumentor = "ENABLE_JINJA2_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Psycopg:
            self._enable_instrumentor = "ENABLE_PSYCOPG_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Grpc:
            self._enable_instrumentor = "ENABLE_GRPC_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Tortoiseorm:
            self._enable_instrumentor = "ENABLE_TORTOISEORM_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.ConfluentKafka:
            self._enable_instrumentor = "ENABLE_CONFLUENT_KAFKA_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Mysql:
            self._enable_instrumentor = "ENABLE_MYSQL_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Falcon:
            self._enable_instrumentor = "ENABLE_FALCON_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Click:
            self._enable_instrumentor = "ENABLE_CLICK_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Urllib:
            self._enable_instrumentor = "ENABLE_URLLIB_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.AiohttpServer:
            self._enable_instrumentor = "ENABLE_AIOHTTP_SERVER_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Cassandra:
            self._enable_instrumentor = "ENABLE_CASSANDRA_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Pymemcache:
            self._enable_instrumentor = "ENABLE_PYMEMCACHE_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Pyramid:
            self._enable_instrumentor = "ENABLE_PYRAMID_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Elasticsearch:
            self._enable_instrumentor = "ENABLE_ELASTICSEARCH_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Mysqlclient:
            self._enable_instrumentor = "ENABLE_MYSQLCLIENT_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Psycopg2:
            self._enable_instrumentor = "ENABLE_PSYCOPG2_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Pymongo:
            self._enable_instrumentor = "ENABLE_PYMONGO_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Starlette:
            self._enable_instrumentor = "ENABLE_STARLETTE_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Pika:
            self._enable_instrumentor = "ENABLE_PIKA_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.AioPika:
            self._enable_instrumentor = "ENABLE_AIO_PIKA_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.KafkaPython:
            self._enable_instrumentor = "ENABLE_KAFKA_PYTHON_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Aiokafka:
            self._enable_instrumentor = "ENABLE_AIOKAFKA_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Asyncio:
            self._enable_instrumentor = "ENABLE_ASYNCIO_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Threading:
            self._enable_instrumentor = "ENABLE_THREADING_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Milvus:
            self._enable_instrumentor = "ENABLE_MILVUS_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.Mem0:
            self._enable_instrumentor = "ENABLE_MEM0_INSTRUMENTOR"
        elif environ_instrumentor == EnvironInstrumentorEnum.ClaudeAgentSDK:
            self._enable_instrumentor = "ENABLE_CLAUDE_AGENT_SDK_INSTRUMENTOR"

    def start(self):
        pass

    def is_open(self) -> bool:
        return self._enable_instrumentor not in os.environ or not os.environ[self._enable_instrumentor] == "false"

    def close(self):
        os.environ[self._enable_instrumentor] = "false"
        _logger.warning(f"[close] close: {self._enable_instrumentor}")

    def open(self):
        os.environ[self._enable_instrumentor] = "true"
        _logger.warning(f"[open] open: {self._enable_instrumentor}")


class FastApiController(BaseController):
    """
    fastapi instrumentor controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass


class AioHttpClientController(BaseController):
    """
    aiohttp client instrumentor controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass


class RequestsClientController(BaseController):
    """
    requests client instrumentor controller
    """

    def __init__(self):
        super().__init__()

    def start(self):
        pass

defaultController = SampleController()

fastApiController = FastApiController()
requestsController = RequestsClientController()
aiohttpClientController = AioHttpClientController()
djangoController = SampleController()
httpxController = SampleController()
openAIAgentsController = EnvironController(EnvironInstrumentorEnum.OpenAIAgents)
flaskController = SampleController()
difyController = SampleController()
redisController = SampleController()
sqlalchemyController = SampleController()
sglangController = SampleController()
vllmController = SampleController()

agentInfoController = SampleController()
traceExporterController = SampleController()
metricExporterController = SampleController()

dashscopeController = EnvironController(EnvironInstrumentorEnum.Dashscope)
openApiController = EnvironController(EnvironInstrumentorEnum.OpenAI)
llamaIndexController = EnvironController(EnvironInstrumentorEnum.LlamaIndex)
langchainController = EnvironController(EnvironInstrumentorEnum.Langchain)
runtimeController = EnvironController(EnvironInstrumentorEnum.Runtime)
mcpController = EnvironController(EnvironInstrumentorEnum.MCP)
ragflowController = EnvironController(EnvironInstrumentorEnum.RAGFlow)
claudeAgentSDKController = EnvironController(EnvironInstrumentorEnum.ClaudeAgentSDK)

# 新增插件的控制器实例
pymssqlController = EnvironController(EnvironInstrumentorEnum.Pymssql)
urllib3Controller = EnvironController(EnvironInstrumentorEnum.Urllib3)
dbapiController = EnvironController(EnvironInstrumentorEnum.Dbapi)
asyncpgController = EnvironController(EnvironInstrumentorEnum.Asyncpg)
aiopgController = EnvironController(EnvironInstrumentorEnum.Aiopg)
sqlite3Controller = EnvironController(EnvironInstrumentorEnum.Sqlite3)
pymysqlController = EnvironController(EnvironInstrumentorEnum.Pymysql)
remouladeController = EnvironController(EnvironInstrumentorEnum.Remoulade)
celeryController = EnvironController(EnvironInstrumentorEnum.Celery)
jinja2Controller = EnvironController(EnvironInstrumentorEnum.Jinja2)
psycopgController = EnvironController(EnvironInstrumentorEnum.Psycopg)
grpcController = EnvironController(EnvironInstrumentorEnum.Grpc)
tortoiseormController = EnvironController(EnvironInstrumentorEnum.Tortoiseorm)
confluentKafkaController = EnvironController(EnvironInstrumentorEnum.ConfluentKafka)
mysqlController = EnvironController(EnvironInstrumentorEnum.Mysql)
falconController = EnvironController(EnvironInstrumentorEnum.Falcon)
clickController = EnvironController(EnvironInstrumentorEnum.Click)
urllibController = EnvironController(EnvironInstrumentorEnum.Urllib)
aiohttpServerController = EnvironController(EnvironInstrumentorEnum.AiohttpServer)
cassandraController = EnvironController(EnvironInstrumentorEnum.Cassandra)
pymemcacheController = EnvironController(EnvironInstrumentorEnum.Pymemcache)
pyramidController = EnvironController(EnvironInstrumentorEnum.Pyramid)
elasticsearchController = EnvironController(EnvironInstrumentorEnum.Elasticsearch)
mysqlclientController = EnvironController(EnvironInstrumentorEnum.Mysqlclient)
psycopg2Controller = EnvironController(EnvironInstrumentorEnum.Psycopg2)
pymongoController = EnvironController(EnvironInstrumentorEnum.Pymongo)
starletteController = EnvironController(EnvironInstrumentorEnum.Starlette)
pikaController = EnvironController(EnvironInstrumentorEnum.Pika)
aioPikaController = EnvironController(EnvironInstrumentorEnum.AioPika)
kafkaPythonController = EnvironController(EnvironInstrumentorEnum.KafkaPython)
aiokafkaController = EnvironController(EnvironInstrumentorEnum.Aiokafka)
asyncioController = EnvironController(EnvironInstrumentorEnum.Asyncio)
threadingController = EnvironController(EnvironInstrumentorEnum.Threading)
milvusController = EnvironController(EnvironInstrumentorEnum.Milvus)
mem0Controller = EnvironController(EnvironInstrumentorEnum.Mem0)


class ControllerManager:

    def __init__(self):
        self._controllers = {
            InstrumentorEnum.FAST_API.value: fastApiController,
            InstrumentorEnum.REQUESTS.value: requestsController,
            InstrumentorEnum.HTTPX.value: httpxController,
            InstrumentorEnum.DJANGO.value: djangoController,
            InstrumentorEnum.FLASK.value: flaskController,
            InstrumentorEnum.DIFY.value: difyController,
            InstrumentorEnum.REDIS.value: redisController,
            InstrumentorEnum.SQLALCHEMY.value: sqlalchemyController,
            InstrumentorEnum.AIOHTTP_CLIENT: aiohttpClientController,
            InstrumentorEnum.OPENAI_AGENTS.value: openAIAgentsController,
            InstrumentorEnum.SGLANG.value: sglangController,
            InstrumentorEnum.VLLM.value: vllmController,
            # InstrumentorEnum.REDIS.value: redisController,
            # InstrumentorEnum.SQLALCHEMY.value: sqlalchemyController,
            InstrumentorEnum.AIOHTTP_CLIENT.value: aiohttpClientController,
            InstrumentorEnum.REDIS.value: redisController,
            InstrumentorEnum.SQLALCHEMY.value: sqlalchemyController,
            InstrumentorEnum.AIOHTTP_CLIENT: aiohttpClientController,
            InstrumentorEnum.DASHSCOPE.value: dashscopeController,
            InstrumentorEnum.OPENAI.value: openApiController,
            InstrumentorEnum.LLAMA_INDEX.value: llamaIndexController,
            InstrumentorEnum.LANGCHAIN.value: langchainController,
            InstrumentorEnum.MCP.value: mcpController,
            InstrumentorEnum.RAGFLOW.value: ragflowController,
            # 新增插件的控制器映射
            InstrumentorEnum.PYMSSQL.value: pymssqlController,
            InstrumentorEnum.URLLIB3.value: urllib3Controller,
            InstrumentorEnum.DBAPI.value: dbapiController,
            InstrumentorEnum.ASYNCPG.value: asyncpgController,
            InstrumentorEnum.AIOPG.value: aiopgController,
            InstrumentorEnum.SQLITE3.value: sqlite3Controller,
            InstrumentorEnum.PYMYSQL.value: pymysqlController,
            InstrumentorEnum.REMOULADE.value: remouladeController,
            InstrumentorEnum.CELERY.value: celeryController,
            InstrumentorEnum.JINJA2.value: jinja2Controller,
            InstrumentorEnum.PSYCOPG.value: psycopgController,
            InstrumentorEnum.GRPC.value: grpcController,
            InstrumentorEnum.TORTOISEORM.value: tortoiseormController,
            InstrumentorEnum.CONFLUENT_KAFKA.value: confluentKafkaController,
            InstrumentorEnum.MYSQL.value: mysqlController,
            InstrumentorEnum.FALCON.value: falconController,
            InstrumentorEnum.CLICK.value: clickController,
            InstrumentorEnum.URLLIB.value: urllibController,
            InstrumentorEnum.AIOHTTP_SERVER.value: aiohttpServerController,
            InstrumentorEnum.CASSANDRA.value: cassandraController,
            InstrumentorEnum.PYMEMCACHE.value: pymemcacheController,
            InstrumentorEnum.PYRAMID.value: pyramidController,
            InstrumentorEnum.ELASTICSEARCH.value: elasticsearchController,
            InstrumentorEnum.MYSQLCLIENT.value: mysqlclientController,
            InstrumentorEnum.PSYCOPG2.value: psycopg2Controller,
            InstrumentorEnum.PYMONGO.value: pymongoController,
            InstrumentorEnum.STARLETTE.value: starletteController,
            InstrumentorEnum.PIKA.value: pikaController,
            InstrumentorEnum.AIO_PIKA.value: aioPikaController,
            InstrumentorEnum.KAFKA_PYTHON.value: kafkaPythonController,
            InstrumentorEnum.AIOKAFKA.value: aiokafkaController,
            InstrumentorEnum.ASYNCIO.value: asyncioController,
            InstrumentorEnum.THREADING.value: threadingController,
            InstrumentorEnum.MILVUS.value: milvusController,
            InstrumentorEnum.MEM0.value: mem0Controller,
            InstrumentorEnum.CLAUDE_AGENT_SDK.value: claudeAgentSDKController,
            ComponentEnum.AGENT_INFO.value: agentInfoController,
            ComponentEnum.TRACE_EXPORTER.value: traceExporterController,
            ComponentEnum.METRIC_EXPORTER.value: metricExporterController,
            ComponentEnum.RUNTIME.value: runtimeController,
        }

    def start(self):
        """
        start all controller
        """
        for name in self._controllers:
            controller = self.get_controller_by_name(name)
            if controller is not None:
                controller.start()

    def open(self, name):
        if name in self._controllers:
            controller = self._controllers[name]
            controller.open()
            _logger.warning(f"===>open {name}")

    def close(self, name):

        if name in self._controllers:
            controller = self._controllers[name]
            controller.close()
            _logger.warning(f"===> close {name}")

    def open_all(self):
        """
        open all
        """
        for name in self._controllers:
            controller = self.get_controller_by_name(name)
            if controller is not None:
                controller.open()

    def get_controller_by_name(self, name: str):
        if name in self._controllers:
            return self._controllers[name]
        return defaultController

    def close_all(self):
        """
        close all
        """
        for name in self._controllers:
            controller = self.get_controller_by_name(name)
            if controller is not None:
                controller.close()


controllerManager = ControllerManager()
