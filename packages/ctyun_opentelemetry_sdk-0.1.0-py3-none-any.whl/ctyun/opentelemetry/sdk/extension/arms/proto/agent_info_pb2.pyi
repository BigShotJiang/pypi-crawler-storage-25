from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class JvmGcType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNKNOWN: _ClassVar[JvmGcType]
    SERIAL: _ClassVar[JvmGcType]
    PARALLEL: _ClassVar[JvmGcType]
    CMS: _ClassVar[JvmGcType]
    G1: _ClassVar[JvmGcType]
UNKNOWN: JvmGcType
SERIAL: JvmGcType
PARALLEL: JvmGcType
CMS: JvmGcType
G1: JvmGcType

class JvmInfo(_message.Message):
    __slots__ = ("version", "vmVersion", "gcType")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    VMVERSION_FIELD_NUMBER: _ClassVar[int]
    GCTYPE_FIELD_NUMBER: _ClassVar[int]
    version: int
    vmVersion: str
    gcType: JvmGcType
    def __init__(self, version: _Optional[int] = ..., vmVersion: _Optional[str] = ..., gcType: _Optional[_Union[JvmGcType, str]] = ...) -> None: ...

class ServiceInfo(_message.Message):
    __slots__ = ("serviceName", "serviceLibs")
    SERVICENAME_FIELD_NUMBER: _ClassVar[int]
    SERVICELIBS_FIELD_NUMBER: _ClassVar[int]
    serviceName: str
    serviceLibs: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, serviceName: _Optional[str] = ..., serviceLibs: _Optional[_Iterable[str]] = ...) -> None: ...

class ServerMetaData(_message.Message):
    __slots__ = ("serverInfo", "vmArgs", "serviceInfos")
    SERVERINFO_FIELD_NUMBER: _ClassVar[int]
    VMARGS_FIELD_NUMBER: _ClassVar[int]
    SERVICEINFOS_FIELD_NUMBER: _ClassVar[int]
    serverInfo: str
    vmArgs: _containers.RepeatedScalarFieldContainer[str]
    serviceInfos: _containers.RepeatedCompositeFieldContainer[ServiceInfo]
    def __init__(self, serverInfo: _Optional[str] = ..., vmArgs: _Optional[_Iterable[str]] = ..., serviceInfos: _Optional[_Iterable[_Union[ServiceInfo, _Mapping]]] = ...) -> None: ...

class AgentInfo(_message.Message):
    __slots__ = ("hostname", "ip", "ports", "agentId", "applicationName", "serviceType", "pid", "agentVersion", "vmVersion", "startTimestamp", "endTimestamp", "endStatus", "licenseKey", "timestamp", "agentEnv", "agentArgs", "serverMetaData", "uuId", "processorNum", "memTotalSize", "jvmInfo", "appName", "mseLicenseKey", "mseAppId", "mseNamespace", "mseAppName", "mscLicenseKey", "mscApplicationName", "k8sMetadata", "hostMetadata", "extInfo", "hostEnvTags", "hostVersionTags", "appEnvTags", "appVersionTags", "appClusterIdTag", "appClusterNameTag", "hostNamespaceTag", "hostTags", "appTags", "agentTags", "cp", "garbageCollectors", "pilotVersion", "language", "acsCmsWorkspace", "acsArmsServiceId")
    class AgentTagsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    HOSTNAME_FIELD_NUMBER: _ClassVar[int]
    IP_FIELD_NUMBER: _ClassVar[int]
    PORTS_FIELD_NUMBER: _ClassVar[int]
    AGENTID_FIELD_NUMBER: _ClassVar[int]
    APPLICATIONNAME_FIELD_NUMBER: _ClassVar[int]
    SERVICETYPE_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    AGENTVERSION_FIELD_NUMBER: _ClassVar[int]
    VMVERSION_FIELD_NUMBER: _ClassVar[int]
    STARTTIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ENDTIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ENDSTATUS_FIELD_NUMBER: _ClassVar[int]
    LICENSEKEY_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    AGENTENV_FIELD_NUMBER: _ClassVar[int]
    AGENTARGS_FIELD_NUMBER: _ClassVar[int]
    SERVERMETADATA_FIELD_NUMBER: _ClassVar[int]
    UUID_FIELD_NUMBER: _ClassVar[int]
    PROCESSORNUM_FIELD_NUMBER: _ClassVar[int]
    MEMTOTALSIZE_FIELD_NUMBER: _ClassVar[int]
    JVMINFO_FIELD_NUMBER: _ClassVar[int]
    APPNAME_FIELD_NUMBER: _ClassVar[int]
    MSELICENSEKEY_FIELD_NUMBER: _ClassVar[int]
    MSEAPPID_FIELD_NUMBER: _ClassVar[int]
    MSENAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MSEAPPNAME_FIELD_NUMBER: _ClassVar[int]
    MSCLICENSEKEY_FIELD_NUMBER: _ClassVar[int]
    MSCAPPLICATIONNAME_FIELD_NUMBER: _ClassVar[int]
    K8SMETADATA_FIELD_NUMBER: _ClassVar[int]
    HOSTMETADATA_FIELD_NUMBER: _ClassVar[int]
    EXTINFO_FIELD_NUMBER: _ClassVar[int]
    HOSTENVTAGS_FIELD_NUMBER: _ClassVar[int]
    HOSTVERSIONTAGS_FIELD_NUMBER: _ClassVar[int]
    APPENVTAGS_FIELD_NUMBER: _ClassVar[int]
    APPVERSIONTAGS_FIELD_NUMBER: _ClassVar[int]
    APPCLUSTERIDTAG_FIELD_NUMBER: _ClassVar[int]
    APPCLUSTERNAMETAG_FIELD_NUMBER: _ClassVar[int]
    HOSTNAMESPACETAG_FIELD_NUMBER: _ClassVar[int]
    HOSTTAGS_FIELD_NUMBER: _ClassVar[int]
    APPTAGS_FIELD_NUMBER: _ClassVar[int]
    AGENTTAGS_FIELD_NUMBER: _ClassVar[int]
    CP_FIELD_NUMBER: _ClassVar[int]
    GARBAGECOLLECTORS_FIELD_NUMBER: _ClassVar[int]
    PILOTVERSION_FIELD_NUMBER: _ClassVar[int]
    LANGUAGE_FIELD_NUMBER: _ClassVar[int]
    ACSCMSWORKSPACE_FIELD_NUMBER: _ClassVar[int]
    ACSARMSSERVICEID_FIELD_NUMBER: _ClassVar[int]
    hostname: str
    ip: str
    ports: str
    agentId: str
    applicationName: str
    serviceType: int
    pid: int
    agentVersion: str
    vmVersion: str
    startTimestamp: int
    endTimestamp: int
    endStatus: int
    licenseKey: str
    timestamp: int
    agentEnv: str
    agentArgs: str
    serverMetaData: ServerMetaData
    uuId: str
    processorNum: str
    memTotalSize: str
    jvmInfo: JvmInfo
    appName: str
    mseLicenseKey: str
    mseAppId: str
    mseNamespace: str
    mseAppName: str
    mscLicenseKey: str
    mscApplicationName: str
    k8sMetadata: str
    hostMetadata: str
    extInfo: str
    hostEnvTags: str
    hostVersionTags: str
    appEnvTags: str
    appVersionTags: str
    appClusterIdTag: str
    appClusterNameTag: str
    hostNamespaceTag: str
    hostTags: str
    appTags: str
    agentTags: _containers.ScalarMap[str, str]
    cp: CP
    garbageCollectors: str
    pilotVersion: str
    language: str
    acsCmsWorkspace: str
    acsArmsServiceId: str
    def __init__(self, hostname: _Optional[str] = ..., ip: _Optional[str] = ..., ports: _Optional[str] = ..., agentId: _Optional[str] = ..., applicationName: _Optional[str] = ..., serviceType: _Optional[int] = ..., pid: _Optional[int] = ..., agentVersion: _Optional[str] = ..., vmVersion: _Optional[str] = ..., startTimestamp: _Optional[int] = ..., endTimestamp: _Optional[int] = ..., endStatus: _Optional[int] = ..., licenseKey: _Optional[str] = ..., timestamp: _Optional[int] = ..., agentEnv: _Optional[str] = ..., agentArgs: _Optional[str] = ..., serverMetaData: _Optional[_Union[ServerMetaData, _Mapping]] = ..., uuId: _Optional[str] = ..., processorNum: _Optional[str] = ..., memTotalSize: _Optional[str] = ..., jvmInfo: _Optional[_Union[JvmInfo, _Mapping]] = ..., appName: _Optional[str] = ..., mseLicenseKey: _Optional[str] = ..., mseAppId: _Optional[str] = ..., mseNamespace: _Optional[str] = ..., mseAppName: _Optional[str] = ..., mscLicenseKey: _Optional[str] = ..., mscApplicationName: _Optional[str] = ..., k8sMetadata: _Optional[str] = ..., hostMetadata: _Optional[str] = ..., extInfo: _Optional[str] = ..., hostEnvTags: _Optional[str] = ..., hostVersionTags: _Optional[str] = ..., appEnvTags: _Optional[str] = ..., appVersionTags: _Optional[str] = ..., appClusterIdTag: _Optional[str] = ..., appClusterNameTag: _Optional[str] = ..., hostNamespaceTag: _Optional[str] = ..., hostTags: _Optional[str] = ..., appTags: _Optional[str] = ..., agentTags: _Optional[_Mapping[str, str]] = ..., cp: _Optional[_Union[CP, _Mapping]] = ..., garbageCollectors: _Optional[str] = ..., pilotVersion: _Optional[str] = ..., language: _Optional[str] = ..., acsCmsWorkspace: _Optional[str] = ..., acsArmsServiceId: _Optional[str] = ...) -> None: ...

class CP(_message.Message):
    __slots__ = ("jvmVersion", "vendor", "enable", "cpu", "alloc", "size")
    JVMVERSION_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    ENABLE_FIELD_NUMBER: _ClassVar[int]
    CPU_FIELD_NUMBER: _ClassVar[int]
    ALLOC_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    jvmVersion: str
    vendor: str
    enable: bool
    cpu: bool
    alloc: bool
    size: int
    def __init__(self, jvmVersion: _Optional[str] = ..., vendor: _Optional[str] = ..., enable: bool = ..., cpu: bool = ..., alloc: bool = ..., size: _Optional[int] = ...) -> None: ...
