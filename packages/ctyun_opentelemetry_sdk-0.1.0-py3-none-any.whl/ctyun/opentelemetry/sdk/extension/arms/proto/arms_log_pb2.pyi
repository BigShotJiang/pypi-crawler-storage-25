from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Log(_message.Message):
    __slots__ = ["Contents", "Time", "Time_ns"]
    class Content(_message.Message):
        __slots__ = ["Key", "Value"]
        KEY_FIELD_NUMBER: _ClassVar[int]
        Key: str
        VALUE_FIELD_NUMBER: _ClassVar[int]
        Value: str
        def __init__(self, Key: _Optional[str] = ..., Value: _Optional[str] = ...) -> None: ...
    CONTENTS_FIELD_NUMBER: _ClassVar[int]
    Contents: _containers.RepeatedCompositeFieldContainer[Log.Content]
    TIME_FIELD_NUMBER: _ClassVar[int]
    TIME_NS_FIELD_NUMBER: _ClassVar[int]
    Time: int
    Time_ns: int
    def __init__(self, Time: _Optional[int] = ..., Contents: _Optional[_Iterable[_Union[Log.Content, _Mapping]]] = ..., Time_ns: _Optional[int] = ...) -> None: ...

class LogGroup(_message.Message):
    __slots__ = ["LogTags", "Logs", "MachineUUID", "Reserved", "Source", "Topic"]
    LOGS_FIELD_NUMBER: _ClassVar[int]
    LOGTAGS_FIELD_NUMBER: _ClassVar[int]
    LogTags: _containers.RepeatedCompositeFieldContainer[LogTag]
    Logs: _containers.RepeatedCompositeFieldContainer[Log]
    MACHINEUUID_FIELD_NUMBER: _ClassVar[int]
    MachineUUID: str
    RESERVED_FIELD_NUMBER: _ClassVar[int]
    Reserved: str
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    Source: str
    TOPIC_FIELD_NUMBER: _ClassVar[int]
    Topic: str
    def __init__(self, Logs: _Optional[_Iterable[_Union[Log, _Mapping]]] = ..., Reserved: _Optional[str] = ..., Topic: _Optional[str] = ..., Source: _Optional[str] = ..., MachineUUID: _Optional[str] = ..., LogTags: _Optional[_Iterable[_Union[LogTag, _Mapping]]] = ...) -> None: ...

class LogGroupList(_message.Message):
    __slots__ = ["LogGroups"]
    LOGGROUPS_FIELD_NUMBER: _ClassVar[int]
    LogGroups: _containers.RepeatedCompositeFieldContainer[LogGroup]
    def __init__(self, LogGroups: _Optional[_Iterable[_Union[LogGroup, _Mapping]]] = ...) -> None: ...

class LogTag(_message.Message):
    __slots__ = ["Key", "Value"]
    KEY_FIELD_NUMBER: _ClassVar[int]
    Key: str
    VALUE_FIELD_NUMBER: _ClassVar[int]
    Value: str
    def __init__(self, Key: _Optional[str] = ..., Value: _Optional[str] = ...) -> None: ...
