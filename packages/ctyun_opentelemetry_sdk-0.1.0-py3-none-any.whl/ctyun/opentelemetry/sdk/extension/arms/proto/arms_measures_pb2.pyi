from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EnumUnit(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UNKNOWN: _ClassVar[EnumUnit]
    COUNT: _ClassVar[EnumUnit]
    RATIO: _ClassVar[EnumUnit]
    PERCENT: _ClassVar[EnumUnit]
    BYTE: _ClassVar[EnumUnit]
    SECOND: _ClassVar[EnumUnit]
    MILLISECONDS: _ClassVar[EnumUnit]
UNKNOWN: EnumUnit
COUNT: EnumUnit
RATIO: EnumUnit
PERCENT: EnumUnit
BYTE: EnumUnit
SECOND: EnumUnit
MILLISECONDS: EnumUnit

class MeasureBatches(_message.Message):
    __slots__ = ("measureBatches", "headers")
    class HeadersEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    MEASUREBATCHES_FIELD_NUMBER: _ClassVar[int]
    HEADERS_FIELD_NUMBER: _ClassVar[int]
    measureBatches: _containers.RepeatedCompositeFieldContainer[MeasureBatch]
    headers: _containers.ScalarMap[str, str]
    def __init__(self, measureBatches: _Optional[_Iterable[_Union[MeasureBatch, _Mapping]]] = ..., headers: _Optional[_Mapping[str, str]] = ...) -> None: ...

class MeasureBatch(_message.Message):
    __slots__ = ("version", "type", "time", "pid", "ip", "commonTags", "measures")
    class CommonTagsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    VERSION_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TIME_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    IP_FIELD_NUMBER: _ClassVar[int]
    COMMONTAGS_FIELD_NUMBER: _ClassVar[int]
    MEASURES_FIELD_NUMBER: _ClassVar[int]
    version: str
    type: str
    time: int
    pid: str
    ip: str
    commonTags: _containers.ScalarMap[str, str]
    measures: _containers.RepeatedCompositeFieldContainer[Measures]
    def __init__(self, version: _Optional[str] = ..., type: _Optional[str] = ..., time: _Optional[int] = ..., pid: _Optional[str] = ..., ip: _Optional[str] = ..., commonTags: _Optional[_Mapping[str, str]] = ..., measures: _Optional[_Iterable[_Union[Measures, _Mapping]]] = ...) -> None: ...

class Measures(_message.Message):
    __slots__ = ("labels", "measures")
    class LabelsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    LABELS_FIELD_NUMBER: _ClassVar[int]
    MEASURES_FIELD_NUMBER: _ClassVar[int]
    labels: _containers.ScalarMap[str, str]
    measures: _containers.RepeatedCompositeFieldContainer[Measure]
    def __init__(self, labels: _Optional[_Mapping[str, str]] = ..., measures: _Optional[_Iterable[_Union[Measure, _Mapping]]] = ...) -> None: ...

class Measure(_message.Message):
    __slots__ = ("valueType", "name", "value", "unit", "desc")
    VALUETYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    DESC_FIELD_NUMBER: _ClassVar[int]
    valueType: str
    name: str
    value: float
    unit: EnumUnit
    desc: str
    def __init__(self, valueType: _Optional[str] = ..., name: _Optional[str] = ..., value: _Optional[float] = ..., unit: _Optional[_Union[EnumUnit, str]] = ..., desc: _Optional[str] = ...) -> None: ...
