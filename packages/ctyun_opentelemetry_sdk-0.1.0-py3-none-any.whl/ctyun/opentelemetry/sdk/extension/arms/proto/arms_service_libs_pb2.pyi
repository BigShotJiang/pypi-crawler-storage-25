from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ArmsServiceLibsData(_message.Message):
    __slots__ = ("pid", "vmVersion", "agentVersion", "serviceLibs")
    PID_FIELD_NUMBER: _ClassVar[int]
    VMVERSION_FIELD_NUMBER: _ClassVar[int]
    AGENTVERSION_FIELD_NUMBER: _ClassVar[int]
    SERVICELIBS_FIELD_NUMBER: _ClassVar[int]
    pid: str
    vmVersion: str
    agentVersion: str
    serviceLibs: _containers.RepeatedCompositeFieldContainer[ArmsDependencyInfo]
    def __init__(self, pid: _Optional[str] = ..., vmVersion: _Optional[str] = ..., agentVersion: _Optional[str] = ..., serviceLibs: _Optional[_Iterable[_Union[ArmsDependencyInfo, _Mapping]]] = ...) -> None: ...

class MseServiceLibsData(_message.Message):
    __slots__ = ("serviceLibs",)
    SERVICELIBS_FIELD_NUMBER: _ClassVar[int]
    serviceLibs: _containers.RepeatedCompositeFieldContainer[ArmsDependencyInfo]
    def __init__(self, serviceLibs: _Optional[_Iterable[_Union[ArmsDependencyInfo, _Mapping]]] = ...) -> None: ...

class ArmsDependencyInfo(_message.Message):
    __slots__ = ("groupId", "artifactId", "version", "path", "dataSource")
    GROUPID_FIELD_NUMBER: _ClassVar[int]
    ARTIFACTID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    DATASOURCE_FIELD_NUMBER: _ClassVar[int]
    groupId: str
    artifactId: str
    version: str
    path: str
    dataSource: str
    def __init__(self, groupId: _Optional[str] = ..., artifactId: _Optional[str] = ..., version: _Optional[str] = ..., path: _Optional[str] = ..., dataSource: _Optional[str] = ...) -> None: ...
