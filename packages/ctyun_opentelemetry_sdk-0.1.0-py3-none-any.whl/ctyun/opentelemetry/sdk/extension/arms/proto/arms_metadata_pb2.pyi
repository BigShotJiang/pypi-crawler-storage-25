from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ArmsStringMetaDataBatch(_message.Message):
    __slots__ = ("licenseKey", "agentId", "armsStringMetaData", "acsCmsWorkspace", "acsArmsServiceId")
    LICENSEKEY_FIELD_NUMBER: _ClassVar[int]
    AGENTID_FIELD_NUMBER: _ClassVar[int]
    ARMSSTRINGMETADATA_FIELD_NUMBER: _ClassVar[int]
    ACSCMSWORKSPACE_FIELD_NUMBER: _ClassVar[int]
    ACSARMSSERVICEID_FIELD_NUMBER: _ClassVar[int]
    licenseKey: str
    agentId: str
    armsStringMetaData: _containers.RepeatedCompositeFieldContainer[ArmsStringMetaData]
    acsCmsWorkspace: str
    acsArmsServiceId: str
    def __init__(self, licenseKey: _Optional[str] = ..., agentId: _Optional[str] = ..., armsStringMetaData: _Optional[_Iterable[_Union[ArmsStringMetaData, _Mapping]]] = ..., acsCmsWorkspace: _Optional[str] = ..., acsArmsServiceId: _Optional[str] = ...) -> None: ...

class ArmsStringMetaData(_message.Message):
    __slots__ = ("stringId", "stringValue")
    STRINGID_FIELD_NUMBER: _ClassVar[int]
    STRINGVALUE_FIELD_NUMBER: _ClassVar[int]
    stringId: str
    stringValue: str
    def __init__(self, stringId: _Optional[str] = ..., stringValue: _Optional[str] = ...) -> None: ...

class ArmsSqlMetaDataBatch(_message.Message):
    __slots__ = ("licenseKey", "agentId", "armsSqlMetaData", "acsCmsWorkspace", "acsArmsServiceId")
    LICENSEKEY_FIELD_NUMBER: _ClassVar[int]
    AGENTID_FIELD_NUMBER: _ClassVar[int]
    ARMSSQLMETADATA_FIELD_NUMBER: _ClassVar[int]
    ACSCMSWORKSPACE_FIELD_NUMBER: _ClassVar[int]
    ACSARMSSERVICEID_FIELD_NUMBER: _ClassVar[int]
    licenseKey: str
    agentId: str
    armsSqlMetaData: _containers.RepeatedCompositeFieldContainer[ArmsSqlMetaData]
    acsCmsWorkspace: str
    acsArmsServiceId: str
    def __init__(self, licenseKey: _Optional[str] = ..., agentId: _Optional[str] = ..., armsSqlMetaData: _Optional[_Iterable[_Union[ArmsSqlMetaData, _Mapping]]] = ..., acsCmsWorkspace: _Optional[str] = ..., acsArmsServiceId: _Optional[str] = ...) -> None: ...

class ArmsSqlMetaData(_message.Message):
    __slots__ = ("sqlId", "sql")
    SQLID_FIELD_NUMBER: _ClassVar[int]
    SQL_FIELD_NUMBER: _ClassVar[int]
    sqlId: str
    sql: str
    def __init__(self, sqlId: _Optional[str] = ..., sql: _Optional[str] = ...) -> None: ...
