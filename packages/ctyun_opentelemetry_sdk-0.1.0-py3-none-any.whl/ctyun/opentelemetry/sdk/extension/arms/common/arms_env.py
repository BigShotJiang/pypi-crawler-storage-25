import os
from uuid import uuid4

from aliyun.sdk.extension.arms.common.endpoints import (
    GetMetricsEndpointByRegion, GetOssEndpointByRegion,
    GetTraceEndpointByRegion, GetTraceMetaEndpointByRegion)
from aliyun.sdk.extension.arms.common.utils import arms_utils as MetadataUtils
from aliyun.sdk.extension.arms.common.utils.arms_utils import \
    is_default_cms_workspace
from aliyun.sdk.extension.arms.utils.env_utils import (get_hostname,
                                                       get_ip_address)
from aliyun.opentelemetry.instrumentation.arms_multiprocess_utils import (is_gunicorn,
                                                                   is_uvicorn,
                                                                   is_uwsgi)


class ArmsEnv(object):
    def __init__(self):
        # environments
        self.licenseKey = os.getenv("ARMS_LICENSE_KEY", "")
        self.appName = os.getenv("ARMS_APP_NAME", "")
        self.appId = os.getenv("ARMS_APP_ID", "")
        user_id = MetadataUtils.get_user_id(self.licenseKey)
        self.user_id = user_id
        if self.appName and len(self.appName) > 0:
            self.agentId = MetadataUtils.generate_app_id(user_id, self.appName)
            self.appId = self.agentId
        self.agentId = self.appId
        hostname = get_hostname()
        self.hostname = os.getenv("HOSTNAME", hostname)
        self.clusterId = os.getenv("ARMS_CLUSTER_ID", "")
        self.clusterName = os.getenv("ARMS_CLUSTER_NAME", "")
        self.workloadKind = os.getenv("ARMS_WORKLOAD_KIND", "")
        self.workloadName = os.getenv("ARMS_WORKLOAD_NAME", "")
        self.namespace = os.getenv("ARMS_NAMESPACE", "")
        self.agentEnv = os.getenv("ARMS_AGENT_ENV", "DEFAULT")
        self.uuid = uuid4()
        self.regionId = os.getenv("ARMS_REGION_ID", "cn-zhangjiakou")
        
        # 处理 OXS 区域逻辑
        self.oxs_enabled = os.getenv("APSARA_APM_OXS_ENABLED", "false").lower() in ("true", "1", "yes")
        
        # SLS 自监控日志配置（用于 python-agent 诊断日志上报）
        self.sls_self_monitor_project_name = f"end-side-logs-{self.regionId}"
        self.sls_self_monitor_logstore_name = "python-agent-log"
        

        # params
        self.timeoutSec = int(os.getenv("DEFAULT_HTTPTIMEOUT_KEY", 30))
        self.initialIntervalSec = int(os.getenv("DEFAULT_INITIAL_INTERVAL_KEY", 5))
        self.maxIntervalSec = int(os.getenv("DEFAULT_MAX_INTERVAL_KEY", 30))
        self.maxElapsedTimeSec = int(os.getenv("DEFAULT_MAX_ELASPED_TIME_KEY", 60))
        self.maxQueueSize = int(os.getenv("ARMS_MAX_QUEUE_SIZE_KEY", 256))
        self.maxExporterBatchSize = int(os.getenv("ARMS_MAX_EXPORTER_BATCH_SIZE_KEY", 1024))
        self.maxExporterTimeoutSec = int(os.getenv("ARMS_MAX_EXPORTER_TIMEOUT_KEY", 15))
        # endpoints
        self.traceGatewayEndpoint = GetTraceEndpointByRegion(self.regionId, self.oxs_enabled)
        self.metaGatewayEndpoint = GetTraceMetaEndpointByRegion(self.regionId, self.oxs_enabled)
        self.metricsGatewayEndpoint = GetMetricsEndpointByRegion(self.regionId, self.oxs_enabled)
        # auto detect here
        self.ossEndpoint = GetOssEndpointByRegion(self.regionId)
        self.slsSelfMonitorUri = f'/logstores/{self.sls_self_monitor_logstore_name}'
        # metadata send config
        self.sendMaxSize = int(os.getenv("DEFAULT_SEND_MAX_SIZE_KEY", 512))
        self.sendTimeInterval = int(os.getenv("DEFAULT_SEND_TIME_INTERVAL_KEY", 15))
        self.ringBufferSize = int(os.getenv("DEFAULT_RING_BUFFER_SIZE_KEY", 1024))
        self.hostTags = os.getenv("ARMS_HOST_TAGS", "")
        self.address = get_ip_address()
        # 云监控2.0 workspace相关字段
        self.workspace = os.getenv("ARMS_WORKSPACE", "")
        if not self.workspace:
            self.workspace = MetadataUtils.get_default_workspace(self.user_id, self.regionId)
        self.service_id = MetadataUtils.get_service_id(self.workspace, self.user_id, self.regionId, self.appId)
        self.is_default_workspace = is_default_cms_workspace(self.user_id, self.regionId, self.workspace)
        if not self.is_default_workspace:
            self.appId = self.service_id
            self.agentId = self.service_id

    def get_agent_ip(self):
        # 在常见的多进程场景下，上报的agent info需要区分进程ID
        # 目前常用的python多进程服务器包括uwsgi/gunicorn/uvicorn
        if is_uwsgi() or is_gunicorn() or is_uvicorn():
            return f'{self.address}-{os.getpid()}'
        else:
            return self.address

    def getTraceEndpoint(self):
        return self.traceGatewayEndpoint

    def getMetaEndpoint(self):
        return self.metaGatewayEndpoint

    def getSlsSelfMonitorProjectLogstoreEndpoint(self):
        return self.slsSelfMonitorProjectLogstoreEndpoint

    def getAppId(self):
        return self.appId

    def getMetricsEndpoint(self):
        return self.metricsGatewayEndpoint

    def getOssEndpoint(self):
        return self.ossEndpoint

    def getRegionId(self):
        return self.regionId

    @property
    def slsSelfMonitorHost(self) -> str:
        """SLS Host（自监控日志），格式为：{project}.{endpoint}"""
                # 延迟导入避免循环依赖
        from aliyun.sdk.extension.arms.endpoints.sls_endpoints_state import \
            global_sls_endpoint_state
        slsEndpoint = global_sls_endpoint_state.get_sls_internal_endpoint()
        return f"{self.sls_self_monitor_project_name}.{slsEndpoint}"

    @property
    def slsSelfMonitorProjectLogstoreEndpoint(self) -> str:
        """SLS完整的Project+Logstore endpoint（自监控日志），格式为：https://{project}.{endpoint}/logstores/{logstore}"""
        return f"https://{self.slsSelfMonitorHost}{self.slsSelfMonitorUri}"

    @classmethod
    def instance(cls):
        if not hasattr(ArmsEnv, "_instance"):
            ArmsEnv._instance = ArmsEnv()
        return ArmsEnv._instance
