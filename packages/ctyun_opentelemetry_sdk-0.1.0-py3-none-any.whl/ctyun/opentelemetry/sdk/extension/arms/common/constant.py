import enum


class Compression(enum.Enum):
    NoCompression = "none"
    Deflate = "deflate"
    Gzip = "gzip"
    Snappy = "snappy"


# ============================================================================
# Multimodal Upload Environment Variables (SLS/OSS 存储相关)
# ============================================================================

APSARA_APM_COLLECTOR_MULTIMODAL_SLS_PROJECT = (
    "APSARA_APM_COLLECTOR_MULTIMODAL_SLS_PROJECT"
)
"""SLS Project name for multimodal data storage."""

APSARA_APM_COLLECTOR_MULTIMODAL_SLS_LOGSTORE = (
    "APSARA_APM_COLLECTOR_MULTIMODAL_SLS_LOGSTORE"
)
"""SLS Logstore name for multimodal data storage."""

APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ENDPOINT = (
    "APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ENDPOINT"
)
"""SLS endpoint for multimodal data upload, e.g. ``cn-hangzhou.log.aliyuncs.com``."""

APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_KEY = (
    "APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_KEY"
)
"""AccessKey ID for SLS multimodal data upload."""

APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_SECRET_KEY = (
    "APSARA_APM_COLLECTOR_MULTIMODAL_SLS_ACCESS_SECRET_KEY"
)
"""AccessKey Secret for SLS multimodal data upload."""

APSARA_APM_COLLECTOR_MULTIMODAL_SLS_STS_TOKEN = (
    "APSARA_APM_COLLECTOR_MULTIMODAL_SLS_STS_TOKEN"
)
"""STS Token for SLS multimodal data upload (optional)."""