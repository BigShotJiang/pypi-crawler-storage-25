import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Mapping, Any, Tuple

from aliyun.opentelemetry.instrumentation.version import __agent_version__, __agent_commit__
from aliyun.opentelemetry.instrumentation.arms_gevent_state import global_gevent_state

# 环境变量名称
APSARA_APM_AGENT_WORKSPACE_DIR = "APSARA_APM_AGENT_WORKSPACE_DIR"
LOG_MAX_BYTES = "LOG_MAX_BYTES"
LOG_BACKUP_COUNT = "LOG_BACKUP_COUNT"

# 获取进程ID
PROCESS_ID = os.getpid()
has_detected = False
actual_workspace_dir = None
log_dir = None
log_file_name = None
log_system_no_perm = False


def concat_log_path(actual_workspace_dir: str):
    return os.path.join(actual_workspace_dir, "logs")


def concat_workspace_path(workspace_dir: str, is_home_dir: bool = False):
    if is_home_dir:
        return os.path.join(workspace_dir, ".apsara-apm", "python", f"{__agent_version__}_{__agent_commit__}")
    else:
        return os.path.join(workspace_dir, ".apsara-apm", "python")


# 获取日志目录，按优先级顺序
def detect_log_dir() -> Tuple[str, str]:
    f"""获取日志目录，按优先级顺序：
    1. APSARA_APM_AGENT_WORKSPACE_DIR 环境变量指定的目录（优先级最高）
    2. ack-onepilot的volume目录
    3. 用户家目录下的 {__agent_version__}_{__agent_commit__}/logs 目录
    4. 主文件同级的logs目录
    """
    # 优先级1: 环境变量指定的目录
    try:
        env_log_dir = os.getenv(APSARA_APM_AGENT_WORKSPACE_DIR)
        if env_log_dir:
            env_workspace_dir = concat_workspace_path(env_log_dir)
            env_log_dir = concat_log_path(env_workspace_dir)
            os.makedirs(env_log_dir, exist_ok=True)
            return env_workspace_dir, env_log_dir
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to ${APSARA_APM_AGENT_WORKSPACE_DIR} directory")

    try:
        # 优先级2: ack-onepilot的volume目录
        pilot_workspace_dir = concat_workspace_path("/home/admin/.opt")
        pilot_log_dir = concat_log_path(pilot_workspace_dir)
        os.makedirs(pilot_log_dir, exist_ok=True)
        return pilot_workspace_dir, pilot_log_dir
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to /home/admin/.opt directory")

    try:
        # 优先级3: 用户家目录下的 logs 目录
        home_workspace_dir = concat_workspace_path(os.path.join(os.path.expanduser("~")), is_home_dir=True)
        home_log_dir = concat_log_path(home_workspace_dir)
        os.makedirs(home_log_dir, exist_ok=True)
        return home_workspace_dir, home_log_dir
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to $HOME directory")

    try:
        # 优先级4: 主文件同级的logs目录
        current_workspace_dir = concat_workspace_path("")
        current_log_dir = concat_log_path(current_workspace_dir)
        os.makedirs(current_log_dir, exist_ok=True)
        return current_workspace_dir, current_log_dir
    except IOError as e:
        print(e)
        print(f"WARN: Aliyun Python Agent could not write logs to current directory")
    return "", ""


def get_log_dir():
    global actual_workspace_dir, log_dir, has_detected
    if not has_detected:
        tmp_actual_workspace_dir, tmp_log_dir = detect_log_dir()
        if tmp_actual_workspace_dir != "":
            actual_workspace_dir = tmp_actual_workspace_dir
        if tmp_log_dir != "":
            log_dir = tmp_log_dir
        has_detected = True
    return log_dir


def get_log_file():
    """获取日志文件路径"""
    global actual_workspace_dir, log_file_name, log_system_no_perm
    if log_system_no_perm:
        return None
    if log_file_name:
        return log_file_name
    tmp_log_dir = get_log_dir()
    if tmp_log_dir:
        log_dir = tmp_log_dir
        log_file_name = f"{log_dir}/aliyun-python-agent-{os.getpid()}.log"
        print(f"Picked up [{actual_workspace_dir}] as Agent Workspace.")
    else:
        log_system_no_perm = True
    return log_file_name

_logger_list: Mapping[str, Any] = {}
_sls_log_handler = None

def getLogger(logger_name: str, level=logging.WARN, add_sls_log_handler=True):
    """Function to setup a logger; can be called from any module in the code."""
    if logger := _get_logger(logger_name):
        return logger
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    logger.propagate = False
    log_file = get_log_file()
    if not log_file:
        return logger
    handler = RotatingFileHandler(log_file, maxBytes=getMaxBytes(), backupCount=getBackupCount())
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    _logger_list[logger_name] = logger
    if add_sls_log_handler and global_gevent_state.inited:
        try:
            set_sls_log_handler(logger)
        except Exception:
            return logger
    return logger


def diagnose_logger(logger_name: str = "diagnose", level=logging.INFO):
    """Function to setup a diagnose logger; logs will be written to diagnose.log file."""
    # 使用独立的logger名称以避免冲突
    diagnose_logger_name = f"diagnose.{logger_name}"
    
    if logger := _get_logger(diagnose_logger_name):
        return logger
    
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(diagnose_logger_name)
    logger.setLevel(level)
    logger.propagate = False
    
    # 获取日志目录
    tmp_log_dir = get_log_dir()
    if not tmp_log_dir:
        return logger
    
    # 创建diagnose.log文件路径，拼接进程ID
    diagnose_log_file = os.path.join(tmp_log_dir, f"diagnose-{os.getpid()}.log")
    
    try:
        handler = RotatingFileHandler(diagnose_log_file, maxBytes=getMaxBytes(), backupCount=getBackupCount())
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        _logger_list[diagnose_logger_name] = logger
    except Exception as e:
        print(f"Failed to create diagnose logger: {e}")
    
    return logger


def set_all_logger_level(level=logging.INFO):
    for logger_name, logger in _logger_list.items():
        logger.setLevel(level)


def set_sls_log_handler(logger):
    if logger is None:
        return
    sls_log_handler = _get_global_sls_log_handler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    sls_log_handler.setFormatter(formatter)
    logger.addHandler(sls_log_handler)


def _get_global_sls_log_handler():
    from aliyun.sdk.extension.arms.logger.sls_log_handler import SlsLogHandler
    global _sls_log_handler
    if _sls_log_handler is None:
        _sls_log_handler = SlsLogHandler()
    return _sls_log_handler


def init_self_logger():
    for logger_name, logger in _logger_list.items():
        set_sls_log_handler(logger)


def _get_logger(logger_name: str):
    logger = _logger_list.get(logger_name)
    return logger

def getMaxBytes() -> int:
    max_m_bytes = 300
    size_str = os.getenv(LOG_MAX_BYTES, "300")
    if size_str is not None and size_str.isnumeric():
        max_m_bytes = int(size_str)

    return max_m_bytes * 1024 * 1024


def getBackupCount() -> int:
    backup_cnt = 2
    cnt_str = os.getenv(LOG_BACKUP_COUNT, "2")
    if cnt_str is not None and cnt_str.isnumeric():
        backup_cnt = int(cnt_str)

    return backup_cnt

get_log_file()

__all__ = [
    "getLogger",
    "diagnose_logger",
    "set_all_logger_level", 
    "set_sls_log_handler",
    "init_self_logger",
    "get_log_file",
]