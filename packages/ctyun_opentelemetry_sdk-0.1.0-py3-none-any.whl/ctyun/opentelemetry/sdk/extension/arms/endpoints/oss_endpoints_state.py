import os
import threading

from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.exporters.arms_endpoints import ArmsEndpoints
from aliyun.sdk.extension.arms.utils import network_utils
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.endpoints.health_check import (
    get_current_reachable_endpoint,
    start_health_check_thread,
    CHECK_ALL
)

_logger = getLogger(__name__)

PROFILER_NETWORK_STRATEGY_KEY = "PROFILER_NETWORK_STRATEGY"

NETWORK_STRATEGY_INTERNAL = "internal"
NETWORK_STRATEGY_PUBLIC = "public"
NETWORK_STRATEGY_AUTO = "auto"


class OssEndpointState:
    """OSS Endpoint状态管理，负责选择最优的OSS endpoint并进行健康检查
    
    采用延迟初始化机制：只有在首次调用get_oss_endpoint()时才会启动健康检查线程
    """

    def __init__(self):
        region_id = ArmsEnv.instance().regionId
        # OSS的基础endpoint格式: oss-{region}.aliyuncs.com
        base_endpoint = f"oss-{region_id}.aliyuncs.com"
        
        # OSS健康检查路径为空，访问根路径即可，返回403表示网络通
        # 使用ArmsEndpoints来管理不同的endpoint变体
        # OSS的分隔符是".aliyuncs"
        self.oss_endpoints = ArmsEndpoints(base_endpoint, ".aliyuncs", "")
        
        self.network_strategy = os.getenv(PROFILER_NETWORK_STRATEGY_KEY, "auto")
        
        # 兼容老逻辑
        if bool(os.getenv("ARMS_IS_PUBLIC", False)):
            self.network_strategy = NETWORK_STRATEGY_PUBLIC
        
        # 延迟初始化标志
        self._health_check_started = False
        self._init_lock = threading.Lock()

    def get_oss_endpoint(self):
        """
        根据网络策略获取OSS endpoint
        首次调用时会启动健康检查线程（延迟初始化）
        
        Returns:
            str: OSS endpoint (不包含协议，如: oss-cn-shanghai-internal.aliyuncs.com)
        """
        # 延迟启动健康检查（只有实际需要OSS时才启动）
        if not self._health_check_started:
            with self._init_lock:
                if not self._health_check_started:
                    _logger.info("OSS endpoint first access, starting health check thread")
                    self._start_health_check()
                    self._health_check_started = True
        
        if self.network_strategy == NETWORK_STRATEGY_INTERNAL:
            return self.oss_endpoints.internal_endpoint
        elif self.network_strategy == NETWORK_STRATEGY_PUBLIC:
            return self.oss_endpoints.public_endpoint
        else:
            # auto模式：根据健康检查结果选择可达的endpoint
            current_reachable = get_current_reachable_endpoint(self.oss_endpoints)
            # 默认返回internal endpoint（内网VPC）
            return current_reachable if current_reachable else self.oss_endpoints.internal_endpoint

    def _start_health_check(self):
        """启动后台健康检查任务（私有方法，通过get_oss_endpoint延迟调用）"""
        def is_oss_reachable(endpoint: str, health_path: str) -> bool:
            """
            检查OSS endpoint是否可达
            OSS的健康检查：访问根路径，返回403表示网络通（因为没有提供凭证）
            """
            if not endpoint:
                return False
            url = f"https://{endpoint}/"
            try:
                # OSS访问根路径会返回403（AccessDenied），这表示网络通
                return network_utils.is_oss_url_reachable(url)
            except Exception as e:
                _logger.warning(f"Failed to check OSS endpoint {endpoint}: {str(e)}")
                return False
        
        # 使用公共的健康检查启动函数
        start_health_check_thread(
            name="OSS-HealthCheck",
            endpoints_list=[(self.oss_endpoints, CHECK_ALL, is_oss_reachable)],
            check_interval=60
        )


# 全局单例
global_oss_endpoint_state = OssEndpointState()

