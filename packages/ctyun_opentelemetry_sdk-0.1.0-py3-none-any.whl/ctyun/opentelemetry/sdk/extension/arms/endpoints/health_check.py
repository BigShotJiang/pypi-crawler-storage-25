"""
Endpoint健康检查公共模块
提供统一的健康检查逻辑，避免重复代码
"""
import threading
import time
from typing import Callable, List, Optional, Tuple

from aliyun.sdk.extension.arms.exporters.arms_endpoints import ArmsEndpoints
from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)

# Endpoint检查标志位常量
CHECK_INTERNAL = 1   # VPC内网
CHECK_INTRANET = 2   # 经典网络内网
CHECK_SHARE = 4      # 共享网络
CHECK_PUBLIC = 8     # 公网

# 常用的检查组合
CHECK_ALL = CHECK_INTERNAL | CHECK_INTRANET | CHECK_SHARE | CHECK_PUBLIC  # 15: 检查所有类型
CHECK_INTERNAL_INTRANET_PUBLIC = CHECK_INTERNAL | CHECK_INTRANET | CHECK_PUBLIC  # 11: 检查internal+intranet+public
CHECK_INTRANET_PUBLIC = CHECK_INTRANET | CHECK_PUBLIC  # 10: 检查intranet+public
CHECK_INTRANET_SHARE_PUBLIC = CHECK_INTRANET | CHECK_SHARE | CHECK_PUBLIC  # 14: 检查intranet+share+public


def detect_reachable_endpoint(
    endpoints: ArmsEndpoints,
    check_flag: int,
    is_reachable_fn: Callable[[str, str], bool]
) -> Optional[str]:
    """
    检测endpoint的可达性
    
    Args:
        endpoints: ArmsEndpoints对象
        check_flag: 位标志，使用CHECK_*常量组合
                   例如: CHECK_ALL, CHECK_INTERNAL_INTRANET_PUBLIC等
        is_reachable_fn: 检查可达性的函数，接受(endpoint, health_check_path)，返回bool
    
    Returns:
        str: 第一个可达的endpoint，如果都不可达则返回None
    """
    reached_endpoint = None

    # 检查internal endpoint（VPC内网）
    if (check_flag & CHECK_INTERNAL) and not endpoints.internal_reachable:
        if is_reachable_fn(endpoints.internal_endpoint, endpoints.health_check_path):
            endpoints.internal_reachable = True
            reached_endpoint = endpoints.internal_endpoint
    
    if endpoints.internal_reachable:
        return reached_endpoint

    # 检查intranet endpoint（经典网络内网）
    if (check_flag & CHECK_INTRANET) and not endpoints.intranet_reachable:
        if is_reachable_fn(endpoints.intranet_endpoint, endpoints.health_check_path):
            endpoints.intranet_reachable = True
            reached_endpoint = endpoints.intranet_endpoint

    if endpoints.intranet_reachable:
        return reached_endpoint

    # 检查share endpoint
    if (check_flag & CHECK_SHARE) and not endpoints.share_reachable:
        if is_reachable_fn(endpoints.share_endpoint, endpoints.health_check_path):
            endpoints.share_reachable = True
            reached_endpoint = endpoints.share_endpoint

    if endpoints.share_reachable:
        return reached_endpoint

    # 检查public endpoint（公网）
    if (check_flag & CHECK_PUBLIC) and not endpoints.public_reachable:
        if is_reachable_fn(endpoints.public_endpoint, endpoints.health_check_path):
            endpoints.public_reachable = True
            reached_endpoint = endpoints.public_endpoint

    return reached_endpoint


def start_health_check_thread(
    name: str,
    endpoints_list: List[Tuple[ArmsEndpoints, int, Callable[[str, str], bool]]],
    check_interval: int = 60,
    run_once_immediately: bool = False
) -> threading.Thread:
    """
    启动健康检查后台线程
    
    Args:
        name: 线程名称
        endpoints_list: endpoint列表，每项为(endpoints对象, check_flag, is_reachable_fn)
        check_interval: 检查间隔（秒）
        run_once_immediately: 是否在启动后立即同步运行一次健康检查（确保首次调用有结果）
    
    Returns:
        threading.Thread: 已启动的守护线程
    """
    # 首次启动时同步运行一次健康检查，确保有初始结果
    if run_once_immediately:
        try:
            _logger.info(f"{name}: Running initial health check synchronously")
            for endpoints, check_flag, is_reachable_fn in endpoints_list:
                detect_reachable_endpoint(endpoints, check_flag, is_reachable_fn)
        except Exception as e:
            _logger.warning(f"{name} initial health check error: {str(e)}")
    
    def health_check_task_func():
        """健康检查任务函数"""
        while True:
            # 定期检查
            time.sleep(check_interval)
            
            try:
                for endpoints, check_flag, is_reachable_fn in endpoints_list:
                    detect_reachable_endpoint(endpoints, check_flag, is_reachable_fn)
            except Exception as e:
                _logger.warning(f"{name} health check error: {str(e)}")

    # 启动守护线程
    thread = threading.Thread(target=health_check_task_func, name=name)
    thread.daemon = True
    thread.start()
    return thread


def get_current_reachable_endpoint(endpoints: ArmsEndpoints) -> Optional[str]:
    """
    获取当前可达的endpoint，按优先级顺序：internal > intranet > share > public
    
    Args:
        endpoints: ArmsEndpoints对象
    
    Returns:
        str: 可达的endpoint，如果都不可达则返回None
    """
    if endpoints.internal_reachable:
        return endpoints.internal_endpoint
    elif endpoints.intranet_reachable:
        return endpoints.intranet_endpoint
    elif endpoints.share_reachable:
        return endpoints.share_endpoint
    elif endpoints.public_reachable:
        return endpoints.public_endpoint
    return None

