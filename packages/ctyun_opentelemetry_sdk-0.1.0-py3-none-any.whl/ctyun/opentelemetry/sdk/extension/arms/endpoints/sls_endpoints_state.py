import os

from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.exporters.arms_endpoints import ArmsEndpoints
from aliyun.sdk.extension.arms.utils import network_utils
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.endpoints.health_check import (
    get_current_reachable_endpoint,
    start_health_check_thread,
    CHECK_ALL
)

_logger = getLogger(__name__)

PROFILER_NETWORK_STRATEGY_KEY = "PROFILER_NETWORK_STRATEGY"

NETWORK_STRATEGY_INTERNAL = "internal"
NETWORK_STRATEGY_PUBLIC = "public"
NETWORK_STRATEGY_AUTO = "auto"


class SlsEndpointState:
    """SLS Endpoint状态管理，负责选择最优的SLS endpoint并进行健康检查"""

    def __init__(self):
        region_id = ArmsEnv.instance().regionId
        # SLS的基础endpoint格式: {region}.log.aliyuncs.com
        base_endpoint = f"{region_id}.log.aliyuncs.com"
        
        # SLS健康检查路径为/health，返回200表示正常
        # 使用ArmsEndpoints来管理不同的endpoint变体
        # SLS的分隔符是".log"
        self.sls_endpoints = ArmsEndpoints(base_endpoint, ".log", "/health")
        
        self.network_strategy = os.getenv(PROFILER_NETWORK_STRATEGY_KEY, "auto")
        
        # 兼容老逻辑
        if bool(os.getenv("ARMS_IS_PUBLIC", False)):
            self.network_strategy = NETWORK_STRATEGY_PUBLIC
        
        self._start_health_check()

    def get_sls_endpoint(self):
        """
        根据网络策略获取SLS endpoint
        
        Returns:
            str: SLS endpoint (不包含协议，如: cn-shanghai-internal.log.aliyuncs.com)
        """
        if self.network_strategy == NETWORK_STRATEGY_INTERNAL:
            return self.sls_endpoints.internal_endpoint
        elif self.network_strategy == NETWORK_STRATEGY_PUBLIC:
            return self.sls_endpoints.public_endpoint
        else:
            # auto模式：根据健康检查结果选择可达的endpoint
            current_reachable = get_current_reachable_endpoint(self.sls_endpoints)
            # 默认返回internal endpoint（VPC内网）
            return current_reachable if current_reachable else self.sls_endpoints.internal_endpoint

    def get_sls_internal_endpoint(self):
        return self.sls_endpoints.internal_endpoint

    def _start_health_check(self):
        """启动后台健康检查任务"""
        def is_sls_reachable(endpoint: str, health_path: str) -> bool:
            """检查SLS endpoint是否可达（使用HTTPS）"""
            if not endpoint:
                return False
            url = f"https://{endpoint}{health_path}"
            return network_utils.is_url_reachable(url)
        
        # 使用公共的健康检查启动函数
        start_health_check_thread(
            name="SLS-HealthCheck",
            endpoints_list=[(self.sls_endpoints, CHECK_ALL, is_sls_reachable)],
            check_interval=60
        )


# 全局单例
global_sls_endpoint_state = SlsEndpointState()

