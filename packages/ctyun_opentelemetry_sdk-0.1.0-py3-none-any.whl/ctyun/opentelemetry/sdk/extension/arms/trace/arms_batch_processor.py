# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ARMS Batch Span Processor - A custom span processor with span compression and merging capabilities.
"""

import collections
import os
import threading
import typing
import weakref
from dataclasses import dataclass, field
from os import environ
from time import time_ns
from typing import Dict, Optional, Tuple

from aliyun.opentelemetry import trace as trace_api
from aliyun.opentelemetry.context import (
    _SUPPRESS_INSTRUMENTATION_KEY,
    Context,
    attach,
    detach,
    set_value,
)
from aliyun.opentelemetry.sdk.environment_variables import (
    OTEL_BSP_EXPORT_TIMEOUT,
    OTEL_BSP_MAX_EXPORT_BATCH_SIZE,
    OTEL_BSP_MAX_QUEUE_SIZE,
    OTEL_BSP_SCHEDULE_DELAY,
)
from aliyun.opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor
from aliyun.opentelemetry.trace import TraceFlags
from aliyun.opentelemetry.util._once import Once

from aliyun.sdk.extension.arms.logger import getLogger

# Default configuration values
_DEFAULT_SCHEDULE_DELAY_MILLIS = 5000
_DEFAULT_MAX_EXPORT_BATCH_SIZE = 512
_DEFAULT_EXPORT_TIMEOUT_MILLIS = 30000
_DEFAULT_MAX_QUEUE_SIZE = 2048
_MAX_OPEN_SPANS_LIMIT = 2000
_MAX_CHILD_SPANS_LIMIT = 200

_ENV_VAR_INT_VALUE_ERROR_MESSAGE = (
    "Unable to parse value for %s as integer. Defaulting to %s."
)

COMPRESS_INSTRUMENTATIONS = {
    # SQL
    "aliyun.opentelemetry.instrumentation.aiopg",
    "aliyun.opentelemetry.instrumentation.asyncpg",
    "aliyun.opentelemetry.instrumentation.dbapi",
    "aliyun.opentelemetry.instrumentation.mysql",
    "aliyun.opentelemetry.instrumentation.mysqlclient",
    "aliyun.opentelemetry.instrumentation.psycopg",
    "aliyun.opentelemetry.instrumentation.psycopg2",
    "aliyun.opentelemetry.instrumentation.pymssql",
    "aliyun.opentelemetry.instrumentation.pymysql",
    "aliyun.opentelemetry.instrumentation.sqlalchemy",
    "aliyun.opentelemetry.instrumentation.sqlite3",
    "aliyun.opentelemetry.instrumentation.tortoiseorm",
    # NoSQL
    "aliyun.opentelemetry.instrumentation.cassandra",
    "aliyun.opentelemetry.instrumentation.elasticsearch",
    "aliyun.opentelemetry.instrumentation.milvus",
    "aliyun.opentelemetry.instrumentation.pymemcache",
    "aliyun.opentelemetry.instrumentation.pymongo",
    "aliyun.opentelemetry.instrumentation.redis",
}

logger = getLogger(__name__)


@dataclass
class ArmsSpanContext:
    """Context for tracking span statistics for merging."""
    read_span: ReadableSpan
    count: int = 1
    total: int = 0  # Total duration in milliseconds
    min: int = 0  # Min duration in milliseconds
    max: int = 0  # Max duration in milliseconds
    should_sample: bool = False


@dataclass
class ArmsSpan:
    """Represents a local root span and its child spans."""
    child_spans: Dict[int, ArmsSpanContext] = field(default_factory=dict)
    is_local_root_span: bool = False
    should_sample: bool = False


class _FlushRequest:
    """Represents a request for the ArmsBatchSpanProcessor to flush spans."""

    __slots__ = ["event", "num_spans"]

    def __init__(self):
        self.event = threading.Event()
        self.num_spans = 0


_ARMS_BSP_RESET_ONCE = Once()


class ArmsBatchSpanProcessor(SpanProcessor):
    """
    ARMS Batch Span Processor with span compression and merging capabilities.

    This processor extends the standard batch span processing with:
    - Span merging: Combines repeated spans with the same name
    - Local root span tracking: Tracks spans and their children for better sampling decisions
    - Statistics collection: Records count, min, max, and total duration for merged spans
    """

    def __init__(
            self,
            span_exporter,
            max_queue_size: Optional[int] = None,
            schedule_delay_millis: Optional[float] = None,
            max_export_batch_size: Optional[int] = None,
            export_timeout_millis: Optional[float] = None,
            arms_agent_span_error_sample_enable: bool = True,
    ):
        """
        Initialize the ARMS Batch Span Processor.

        Args:
            span_exporter: The span exporter to use
            max_queue_size: Maximum queue size for buffering spans
            schedule_delay_millis: Maximum duration for constructing a batch
            max_export_batch_size: Maximum number of spans to process in a single batch
            export_timeout_millis: Maximum duration for exporting spans
            arms_agent_span_error_sample_enable: Enable error sampling for spans
        """
        if max_queue_size is None:
            max_queue_size = self._default_max_queue_size()

        if schedule_delay_millis is None:
            schedule_delay_millis = self._default_schedule_delay_millis()

        if max_export_batch_size is None:
            max_export_batch_size = self._default_max_export_batch_size()

        if export_timeout_millis is None:
            export_timeout_millis = self._default_export_timeout_millis()

        self._validate_arguments(
            max_queue_size, schedule_delay_millis, max_export_batch_size
        )

        self.span_exporter = span_exporter
        self.queue = collections.deque([], max_queue_size)  # type: typing.Deque[ReadableSpan]
        self.schedule_delay_millis = schedule_delay_millis
        self.max_export_batch_size = max_export_batch_size
        self.max_queue_size = max_queue_size
        self.export_timeout_millis = export_timeout_millis
        self.done = False

        # Flag that indicates that spans are being dropped
        self._spans_dropped = False

        # Precallocated list to send spans to exporter
        self.spans_list = [None] * self.max_export_batch_size  # type: typing.List[typing.Optional[ReadableSpan]]

        # Synchronization
        self.condition = threading.Condition(threading.Lock())
        self.batch_mutex = threading.Lock()
        self._flush_request = None  # type: typing.Optional[_FlushRequest]

        # ARMS-specific: Track open spans for compression
        self.open_spans_to_arms_trace: Dict[int, ArmsSpan] = {}
        self.arms_agent_span_error_sample_enable = arms_agent_span_error_sample_enable

        # Worker thread
        self.worker_thread = threading.Thread(
            name="ArmsOtelBatchSpanProcessor",
            target=self.worker,
            daemon=True,
        )
        self.worker_thread.start()

        # Fork handling
        if hasattr(os, "register_at_fork"):
            weak_reinit = weakref.WeakMethod(self._at_fork_reinit)
            os.register_at_fork(after_in_child=lambda: weak_reinit()())  # pylint: disable=unnecessary-lambda
        self._pid = os.getpid()

    def on_pre_process(self, parent: Context, span: Span) -> None:
        """
        Called before span processing begins.
        Identifies local root spans (spans with remote parents).
        """
        with self.batch_mutex:
            span_context = trace_api.get_current_span(parent).get_span_context()

            # Check if this is a local root span (parent is remote or invalid)
            if not span_context.is_valid or span_context.is_remote:
                # Limit the number of tracked open spans
                if len(self.open_spans_to_arms_trace) >= _MAX_OPEN_SPANS_LIMIT:
                    return

                span_id = span.context.span_id
                self.open_spans_to_arms_trace[span_id] = ArmsSpan(
                    child_spans={},
                    is_local_root_span=True,
                    should_sample=False,
                )
            else:
                # Handle non-remote parent spans
                # Get or create ArmsSpan for the parent span
                parent_span_id = span_context.span_id
                arms_span = self.open_spans_to_arms_trace.get(parent_span_id)

                if not arms_span:
                    # Create a new ArmsSpan for this parent if it doesn't exist
                    arms_span = ArmsSpan(
                        child_spans={},
                        is_local_root_span=False,
                        should_sample=False,
                    )
                    self.open_spans_to_arms_trace[parent_span_id] = arms_span

                # Add current span as a child span
                # Note: We don't add the span here yet because we don't have the ReadableSpan
                # This will be done in on_pre_end when the span is ending

    def on_start(
            self, span: Span, parent_context: Optional[Context] = None
    ) -> None:
        """Called when a span is started. Currently no-op for ARMS processor."""
        self.on_pre_process(parent_context, span)

    def on_pre_end(self, span: ReadableSpan, should_sample: bool = False) -> bool:
        """
        Called before a span ends. Handles span merging and compression logic.

        Args:
            span: The span about to end
            should_sample: Whether this span should be force-sampled

        Returns:
            bool: True if the span was handled (merged or queued), False otherwise
        """
        # Early exit if tracking is disabled and no open spans
        span_id = span.context.span_id

        with self.batch_mutex:
            if (
                    not self.arms_agent_span_error_sample_enable
                    and len(self.open_spans_to_arms_trace) == 0
            ) or len(self.open_spans_to_arms_trace) > _MAX_OPEN_SPANS_LIMIT:
                return False
            arms_span = self.open_spans_to_arms_trace.get(span_id)

            # Case 1: This is a local root span
            if arms_span and arms_span.is_local_root_span:
                self.open_spans_to_arms_trace.pop(span_id)

                # Determine if we should export this span and its children
                is_sampled = bool(span.context.trace_flags & TraceFlags.SAMPLED)
                if is_sampled or arms_span.should_sample:
                    # Export all child spans
                    for son_context in arms_span.child_spans.values():
                        if son_context.count > 1:
                            # Create a merged span with statistics
                            merged_span = self._create_merged_span(son_context)
                            self._enqueue_span(merged_span, True)
                        else:
                            self._enqueue_span(son_context.read_span, True)

                    # Export the root span itself
                    if span.end_time is not None:
                        self._enqueue_span(span, True)
                else:
                    # Not sampled, just enqueue children without sampling
                    for son_context in arms_span.child_spans.values():
                        self._enqueue_span(son_context.read_span, False)

                return True

            # Case 2: This is a child span
            parent_span_id = span.parent.span_id if span.parent else None
            if parent_span_id:
                parent_arms_span = self.open_spans_to_arms_trace.get(parent_span_id)

                if parent_arms_span:
                    # Try to merge this span with existing child spans
                    can_merge = self._can_compress_span(span)

                    if can_merge:
                        merge_result, merge_id = self._find_mergeable_span(
                            span, parent_arms_span.child_spans
                        )

                        if merge_result:
                            # Update statistics for merged span
                            existing_context = parent_arms_span.child_spans[merge_id]
                            existing_context.count += 1

                            duration = self._get_span_duration_ms(span)
                            existing_context.total += duration
                            existing_context.min = min(existing_context.min, duration)
                            existing_context.max = max(existing_context.max, duration)

                            return True

                    # Cannot merge or limit reached, add as new child span
                    if len(parent_arms_span.child_spans) >= _MAX_CHILD_SPANS_LIMIT:
                        logger.debug(
                            f"Exceeded max child spans limit {_MAX_CHILD_SPANS_LIMIT}, bypassing compression for span {span.name}")
                        return False

                    duration = self._get_span_duration_ms(span)
                    parent_arms_span.child_spans[span_id] = ArmsSpanContext(
                        read_span=span,
                        count=1,
                        total=duration,
                        min=duration,
                        max=duration,
                        should_sample=should_sample,
                    )
                    self.open_spans_to_arms_trace[parent_span_id] = parent_arms_span

                    return True

            return False

    def on_end(self, span: ReadableSpan) -> None:
        """
        Called when a span ends. Enqueues the span for export.

        Args:
            span: The span that just ended
        """
        if self.done:
            logger.warning("Already shutdown, dropping span.")
            return

        # Try to handle span with compression logic first
        handled = self.on_pre_end(span, False)
        if handled:
            # Span was handled by compression logic
            return

        # If not handled by compression, try to enqueue with normal sampling
        self._try_enqueue_span(span, force_sample=False)

    def _enqueue_span(self, span: ReadableSpan, force_sample: bool) -> None:
        """
        Enqueue a span for export (legacy method for compatibility).

        Args:
            span: The span to enqueue
            force_sample: Whether to force sampling for this span
        """
        self._try_enqueue_span(span, force_sample)

    def _try_enqueue_span(self, span: ReadableSpan, force_sample: bool = False) -> None:
        """
        Try to enqueue a span for export with sampling check.

        Args:
            span: The span to enqueue
            force_sample: Whether to force sampling for this span (bypass sampling check)
        """
        # Check if span should be sampled
        is_sampled = bool(span.context.trace_flags & TraceFlags.SAMPLED)
        if not force_sample and not is_sampled:
            return

        # Handle fork scenario
        if self._pid != os.getpid():
            _ARMS_BSP_RESET_ONCE.do_once(self._at_fork_reinit)

        if len(self.queue) == self.max_queue_size:
            if not self._spans_dropped:
                logger.warning("Queue is full, likely spans will be dropped.")
                self._spans_dropped = True

        self.queue.appendleft(span)

        if len(self.queue) >= self.max_export_batch_size:
            with self.condition:
                self.condition.notify()

    def _create_merged_span(self, span_context: ArmsSpanContext) -> ReadableSpan:
        """
        Create a new ReadableSpan with merged statistics.

        Args:
            span_context: The span context with merge statistics

        Returns:
            ReadableSpan: A new span with added merge statistics
        """
        original_span = span_context.read_span

        # Copy original attributes and add merge statistics
        merged_attributes = dict(original_span.attributes) if original_span.attributes else {}
        merged_attributes.update({
            "repeated.span.count": span_context.count,
            "repeated.span.duration.min": span_context.min,
            "repeated.span.duration.max": span_context.max,
            "repeated.span.duration.total": span_context.total,
        })

        return ReadableSpan(
            name=original_span.name,
            context=original_span.context,
            parent=original_span.parent,
            resource=original_span.resource,
            attributes=merged_attributes,
            events=original_span.events,
            links=original_span.links,
            kind=original_span.kind,
            instrumentation_scope=original_span.instrumentation_scope,
            status=original_span.status,
            start_time=original_span.start_time,
            end_time=original_span.end_time,
        )

    def _find_mergeable_span(
            self, span: ReadableSpan, child_spans: Dict[int, ArmsSpanContext]
    ) -> Tuple[bool, Optional[int]]:
        """
        Find if a span can be merged with existing child spans.

        Args:
            span: The span to check for merging
            child_spans: Dictionary of existing child spans

        Returns:
            Tuple: (can_merge: bool, span_id: Optional[int])
        """
        if child_spans is None:
            return False, None

        span_name = span.name
        current_span_id = span.context.span_id

        for span_id, son_context in child_spans.items():
            # Skip if already sampled
            if son_context.should_sample:
                continue

            # Check if names match
            if son_context.read_span.name != span_name:
                continue

            # Check if span has ended and is different from current
            if son_context.read_span.end_time is not None and current_span_id != span_id:
                return True, span_id

        return False, None

    def _can_compress_span(self, span: ReadableSpan) -> bool:
        """
        Determine if a span can be compressed/merged.

        This is a placeholder - in the Go code this checks a canCompress field.
        For now, we'll return True for all spans.

        Args:
            span: The span to check

        Returns:
            bool: True if span can be compressed
        """
        # 只压缩internal的span
        # 或者sql/nosql的span
        if span.instrumentation_scope and span.instrumentation_scope.name:
            return span.instrumentation_scope.name in COMPRESS_INSTRUMENTATIONS
        return False

    def _get_span_duration_ms(self, span: ReadableSpan) -> int:
        """
        Calculate span duration in milliseconds.

        Args:
            span: The span to calculate duration for

        Returns:
            int: Duration in milliseconds

        OpenTelemetry guarantees end_time is set when on_end is called assert span.start_time is not None and span.end_time is not None return (span.end_time - span.start_time) // 1_000_000
        """
        if span.start_time and span.end_time:
            # Convert from nanoseconds to milliseconds
            return (span.end_time - span.start_time) // 1_000_000
        return 0

    def worker(self):
        """Background worker thread that processes the span queue."""
        timeout = self.schedule_delay_millis / 1e3
        flush_request = None  # type: typing.Optional[_FlushRequest]
        while not self.done:
            with self.condition:
                if self.done:
                    # done flag may have changed, avoid waiting
                    break
                flush_request = self._get_and_unset_flush_request()
                if (
                        len(self.queue) < self.max_export_batch_size
                        and flush_request is None
                ):

                    self.condition.wait(timeout)
                    flush_request = self._get_and_unset_flush_request()
                    if not self.queue:
                        # spurious notification, let's wait again, reset timeout
                        timeout = self.schedule_delay_millis / 1e3
                        self._notify_flush_request_finished(flush_request)
                        flush_request = None
                        continue
                    if self.done:
                        # missing spans will be sent when calling flush
                        break

            # subtract the duration of this export call to the next timeout
            start = time_ns()
            self._export(flush_request)
            end = time_ns()
            duration = (end - start) / 1e9
            timeout = self.schedule_delay_millis / 1e3 - duration

            self._notify_flush_request_finished(flush_request)
            flush_request = None

        # there might have been a new flush request while export was running
        # and before the done flag switched to true
        with self.condition:
            shutdown_flush_request = self._get_and_unset_flush_request()

        # be sure that all spans are sent
        self._drain_queue()
        self._notify_flush_request_finished(flush_request)
        self._notify_flush_request_finished(shutdown_flush_request)

    def _export(self, flush_request: typing.Optional[_FlushRequest]):
        """Exports spans considering the given flush_request.

        In case of a given flush_requests spans are exported in batches until
        the number of exported spans reached or exceeded the number of spans in
        the flush request.
        In no flush_request was given at most max_export_batch_size spans are
        exported.
        """
        if not flush_request:
            self._export_batch()
            return

        num_spans = flush_request.num_spans
        while self.queue:
            num_exported = self._export_batch()
            num_spans -= num_exported

            if num_spans <= 0:
                break

    def _export_batch(self) -> int:
        """Exports at most max_export_batch_size spans and returns the number of
        exported spans.
        """
        idx = 0
        # currently only a single thread acts as consumer, so queue.pop() will
        # not raise an exception
        while idx < self.max_export_batch_size and self.queue:
            self.spans_list[idx] = self.queue.pop()
            idx += 1
        token = attach(set_value(_SUPPRESS_INSTRUMENTATION_KEY, True))
        try:
            # Ignore type b/c the Optional[None]+slicing is too "clever"
            # for mypy
            self.span_exporter.export(self.spans_list[:idx])  # type: ignore
        except Exception:  # pylint: disable=broad-exception-caught
            logger.exception("Exception while exporting Span batch.")
        detach(token)

        # clean up list
        for index in range(idx):
            self.spans_list[index] = None
        return idx

    def _drain_queue(self):
        """Export all elements until queue is empty.

        Can only be called from the worker thread context because it invokes
        `export` that is not thread safe.
        """
        while self.queue:
            self._export_batch()

    def _get_and_unset_flush_request(
            self,
    ) -> typing.Optional[_FlushRequest]:
        """Returns the current flush request and makes it invisible to the
        worker thread for subsequent calls.
        """
        flush_request = self._flush_request
        self._flush_request = None
        if flush_request is not None:
            flush_request.num_spans = len(self.queue)
        return flush_request

    @staticmethod
    def _notify_flush_request_finished(
            flush_request: typing.Optional[_FlushRequest],
    ):
        """Notifies the flush initiator(s) waiting on the given request/event
        that the flush operation was finished.
        """
        if flush_request is not None:
            flush_request.event.set()

    def _get_or_create_flush_request(self) -> _FlushRequest:
        """Either returns the current active flush event or creates a new one.

        The flush event will be visible and read by the worker thread before an
        export operation starts. Callers of a flush operation may wait on the
        returned event to be notified when the flush/export operation was
        finished.

        This method is not thread-safe, i.e. callers need to take care about
        synchronization/locking.
        """
        if self._flush_request is None:
            self._flush_request = _FlushRequest()
        return self._flush_request

    def force_flush(self, timeout_millis: int = None) -> bool:
        """
        Force flush all pending spans.

        Args:
            timeout_millis: Timeout in milliseconds

        Returns:
            bool: True if flush succeeded, False if timeout
        """
        if timeout_millis is None:
            timeout_millis = self.export_timeout_millis

        if self.done:
            logger.warning("Already shutdown, ignoring call to force_flush().")
            return True

        with self.condition:
            flush_request = self._get_or_create_flush_request()
            # signal the worker thread to flush and wait for it to finish
            self.condition.notify_all()

        # wait for token to be processed
        ret = flush_request.event.wait(timeout_millis / 1e3)
        if not ret:
            logger.warning("Timeout was exceeded in force_flush().")
        return ret

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the span processor and exporter.
        
        Args:
            timeout_millis: Maximum time to wait for shutdown in milliseconds.
        """
        if self.done:
            logger.warning("Already shutdown")
            return
        
        timeout_s = timeout_millis / 1000.0
        deadline = time_ns() / 1e9 + timeout_s
        
        # 阶段 1: 设置 done 标志，通知 worker
        self.done = True
        with self.condition:
            self.condition.notify_all()
        
        # 阶段 2: 等待 worker 完成（有限时间）
        remaining = max(0.0, deadline - time_ns() / 1e9)
        self.worker_thread.join(timeout=remaining)
        
        if self.worker_thread.is_alive():
            logger.warning(
                "Shutdown timeout, worker thread still alive, %d spans may be lost",
                len(self.queue)
            )
        
        # 阶段 3: 关闭 exporter
        remaining = max(0.0, deadline - time_ns() / 1e9)
        try:
            self.span_exporter.shutdown(timeout_millis=int(remaining * 1000))
        except TypeError:
            # exporter 可能不支持 timeout 参数
            self.span_exporter.shutdown()

    def _at_fork_reinit(self):
        """Reinitialize after fork."""
        logger.warning("[_at_fork_reinit] ARMS batch span processor reinitializing after fork")

        self.condition = threading.Condition(threading.Lock())
        self.queue.clear()
        self.open_spans_to_arms_trace.clear()

        # worker_thread is local to a process, only the thread that issued fork continues
        # to exist. A new worker thread must be started in child process.
        self.worker_thread = threading.Thread(
            name="ArmsOtelBatchSpanProcessor",
            target=self.worker,
            daemon=True,
        )
        self.worker_thread.start()
        self._pid = os.getpid()

    @staticmethod
    def _default_max_queue_size():
        """Get default max queue size from environment."""
        try:
            return int(environ.get(OTEL_BSP_MAX_QUEUE_SIZE, _DEFAULT_MAX_QUEUE_SIZE))
        except ValueError:
            logger.exception(
                _ENV_VAR_INT_VALUE_ERROR_MESSAGE,
                OTEL_BSP_MAX_QUEUE_SIZE,
                _DEFAULT_MAX_QUEUE_SIZE,
            )
            return _DEFAULT_MAX_QUEUE_SIZE

    @staticmethod
    def _default_schedule_delay_millis():
        """Get default schedule delay from environment."""
        try:
            return int(
                environ.get(OTEL_BSP_SCHEDULE_DELAY, _DEFAULT_SCHEDULE_DELAY_MILLIS)
            )
        except ValueError:
            logger.exception(
                _ENV_VAR_INT_VALUE_ERROR_MESSAGE,
                OTEL_BSP_SCHEDULE_DELAY,
                _DEFAULT_SCHEDULE_DELAY_MILLIS,
            )
            return _DEFAULT_SCHEDULE_DELAY_MILLIS

    @staticmethod
    def _default_max_export_batch_size():
        """Get default max export batch size from environment."""
        try:
            return int(
                environ.get(
                    OTEL_BSP_MAX_EXPORT_BATCH_SIZE,
                    _DEFAULT_MAX_EXPORT_BATCH_SIZE,
                )
            )
        except ValueError:
            logger.exception(
                _ENV_VAR_INT_VALUE_ERROR_MESSAGE,
                OTEL_BSP_MAX_EXPORT_BATCH_SIZE,
                _DEFAULT_MAX_EXPORT_BATCH_SIZE,
            )
            return _DEFAULT_MAX_EXPORT_BATCH_SIZE

    @staticmethod
    def _default_export_timeout_millis():
        """Get default export timeout from environment."""
        try:
            return int(
                environ.get(
                    OTEL_BSP_EXPORT_TIMEOUT, _DEFAULT_EXPORT_TIMEOUT_MILLIS
                )
            )
        except ValueError:
            logger.exception(
                _ENV_VAR_INT_VALUE_ERROR_MESSAGE,
                OTEL_BSP_EXPORT_TIMEOUT,
                _DEFAULT_EXPORT_TIMEOUT_MILLIS,
            )
            return _DEFAULT_EXPORT_TIMEOUT_MILLIS

    @staticmethod
    def _validate_arguments(
            max_queue_size, schedule_delay_millis, max_export_batch_size
    ):
        """Validate configuration arguments."""
        if max_queue_size <= 0:
            raise ValueError("max_queue_size must be a positive integer.")

        if schedule_delay_millis <= 0:
            raise ValueError("schedule_delay_millis must be positive.")

        if max_export_batch_size <= 0:
            raise ValueError(
                "max_export_batch_size must be a positive integer."
            )

        if max_export_batch_size > max_queue_size:
            raise ValueError(
                "max_export_batch_size must be less than or equal to max_queue_size."
            )

