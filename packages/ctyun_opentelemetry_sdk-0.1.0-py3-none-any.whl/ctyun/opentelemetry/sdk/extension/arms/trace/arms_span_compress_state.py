class ArmsSpanCompressState(object):
    def __init__(self):
        self.enable_span_compress = False
global_arms_span_compress_state = ArmsSpanCompressState()