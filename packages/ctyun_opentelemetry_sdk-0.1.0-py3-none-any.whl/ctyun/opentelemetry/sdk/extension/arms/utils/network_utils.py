from urllib.error import HTTPError
from urllib.request import urlopen

from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)


def is_url_reachable(url_str):
    if not url_str:
        _logger.warning("URL is empty.")
        return False
    if not url_str.startswith(("http://", "https://")):
        url_str = f"http://{url_str}"
    try:
        return _is_url_reachable(url_str)
    except Exception as e:
        _logger.warning(f"Try to connect address {url_str} fail!, reason {str(e)}")
        return False


def _is_url_reachable(url):
    _logger.info(f"Try to connect to url {url}")
    ssl_context = None
    if url.startswith("https://"):
        import ssl
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
    try:
        if ssl_context:
            req = urlopen(url, timeout=1, context=ssl_context)
        else:
            req = urlopen(url, timeout=1)
        if req.getcode() < 500:
            _logger.info(f"Connect to address {url} success!")
            return True
    except HTTPError as e:
        if e.code < 500:
            _logger.info(f"Connect to address {url} success!")
            return True
    except Exception as e:
        _logger.warning(f"Unexpected error connecting to {url}: {str(e)}")
        return False
    return False


def is_oss_url_reachable(url_str):
    """
    检查OSS URL是否可达
    OSS的特殊性：访问根路径会返回403（AccessDenied），这表示网络是通的
    
    Args:
        url_str: OSS URL地址
        
    Returns:
        bool: 是否可达
    """
    if not url_str:
        _logger.warning("URL is empty.")
        return False
    if not url_str.startswith(("http://", "https://")):
        url_str = f"https://{url_str}"
    try:
        return _is_oss_url_reachable(url_str)
    except Exception as e:
        _logger.warning(f"Try to connect address {url_str} fail!, reason {str(e)}")
        return False


def _is_oss_url_reachable(url):
    """
    内部方法：检查OSS URL是否可达
    对于OSS，返回403表示网络通（因为没有提供正确的凭证）
    
    Args:
        url: OSS URL地址
        
    Returns:
        bool: 是否可达
    """
    _logger.info(f"Try to connect to OSS url {url}")
    try:
        req = urlopen(url, timeout=1)
        # 如果能正常获取响应（虽然不太可能），且状态码<500，表示可达
        if req.getcode() < 500:
            _logger.info(f"Connect to OSS address {url} success!")
            return True
    except HTTPError as e:
        # OSS在没有凭证时返回403，这表示网络是通的
        # 只要不是5xx服务器错误，就认为网络是通的
        if e.code < 500:
            _logger.info(f"Connect to OSS address {url} success! (HTTP {e.code})")
            return True
    except Exception as e:
        _logger.warning(f"Unexpected error connecting to OSS {url}: {str(e)}")
        return False
    return False
