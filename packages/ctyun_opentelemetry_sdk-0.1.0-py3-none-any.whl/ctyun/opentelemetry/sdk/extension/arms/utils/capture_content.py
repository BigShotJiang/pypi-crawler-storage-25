import os
from typing import Optional

from aliyun.sdk.extension.arms.utils.env_utils import is_capture_content_enabled
from aliyun.semconv.trace import SpanAttributes
from aliyun.opentelemetry import trace as trace_api

content_key = [
    SpanAttributes.INPUT_VALUE,
    SpanAttributes.OUTPUT_VALUE,
    'gen_ai.request.tool_calls',
    'gen_ai.request.stop_sequences',
    'tool.parameters',
    'vector_search.query',
    'full_text_search.query'
    ]

content_prefixes_key = [
    "gen_ai.prompts",
    "gen_ai.completions",
    "retrieval.documents",
    "vector_search.document",
    "embedding.embeddings",
    "reranker.input_documents",
    "reranker.output_documents",
    "reranker.query",
    ]

max_content_length = int(os.getenv("OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_MAX_LENGTH", 8 * 1024))

def set_dict_value(attr:dict, key:str, value:str) -> None:
    if is_capture_content_enabled():
        attr[key] = value
    elif not is_content_key(key):
        attr[key] = value
    else:
        attr[key] = to_size(value)

def set_span_value(span: trace_api.Span, key:str, value:str) -> None:
    if is_capture_content_enabled():
        span.set_attribute(key, value)
    elif not is_content_key(key):
        span.set_attribute(key, value)
    else:
        span.set_attribute(key, to_size(value))

def is_content_key(key:str) -> bool:
    return (key in content_key) or any(key.startswith(prefix) for prefix in content_prefixes_key)

def process_content(content: Optional[str] = None) -> str:
    if is_capture_content_enabled():
        if content is not None and len(content) > max_content_length:
            content = content[:max_content_length] + "...[truncated]"
        return content
    elif content is None:
        return "<0size>"
    else:
        return to_size(content)

def to_size(content:str) -> str:
    size = len(content)
    return f"<{size}size>"