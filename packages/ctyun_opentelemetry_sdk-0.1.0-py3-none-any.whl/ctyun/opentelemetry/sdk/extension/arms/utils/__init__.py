from itertools import count
from typing import Iterator
import socket
from importlib import util as importlib_util
import os
from aliyun.sdk.extension.arms.config import constant

_llm_packages = [
    "openai",
    "dashscope",
    "llama_index",
    "langchain",
    "claude_agent_sdk",
]

_llm_service_packages = [
    "vllm",
    "sglang"
]

is_vllm_v0, is_vllm_v1, is_sglang = False, False, False

def _create_exp_backoff_generator(max_value: int = 0) -> Iterator[int]:
    """
    Generates an infinite sequence of exponential backoff values. The sequence starts
    from 1 (2^0) and doubles each time (2^1, 2^2, 2^3, ...). If a max_value is specified
    and non-zero, the generated values will not exceed this maximum, capping at max_value
    instead of growing indefinitely.

    Parameters:
    - max_value (int, optional): The maximum value to yield. If 0 or not provided, the
      sequence grows without bound.

    Returns:
    Iterator[int]: An iterator that yields the exponential backoff values, either uncapped or
    capped at max_value.

    Example:
    ```
    gen = _create_exp_backoff_generator(max_value=10)
    for _ in range(5):
        print(next(gen))
    ```
    This will print:
    1
    2
    4
    8
    10

    Note: this functionality used to be handled by the 'backoff' package.
    """
    for i in count(0):
        out = 2 ** i
        yield min(out, max_value) if max_value else out


check_flag = 0
apsara_check_flag = 0
is_llm = False
app_type = None

def is_llm_app():
    global check_flag, is_llm
    if check_flag == 1:
        return is_llm
    # 普通Python应用
    is_llm = 0
    check_flag = 1
    for item in _llm_packages:
        if importlib_util.find_spec(item):
            # 标识是模型应用
            is_llm = 1
    return is_llm

def llm_model_service_framework():
    model_service_framework = os.getenv(constant.APSARA_APM_MODEL_SERVICE_FRAMEWORK)
    if model_service_framework:
        return model_service_framework
    if is_vllm_v1:
        return constant.SERVICE_MODEL_VLLM_V1
    if is_vllm_v0:
        return constant.SERVICE_MODEL_VLLM_V0
    if is_sglang:
        return constant.SERVICE_MODEL_SGLANG
    return "UNKNOWN"


def llm_app_type():
    global apsara_check_flag, app_type
    env_llm_app_type = os.getenv(constant.APSARA_APM_APP_TYPE, None)
    if env_llm_app_type:
        return env_llm_app_type
    if apsara_check_flag == 1:
        return app_type
    # 微服务应用
    app_type = "microservice"
    apsara_check_flag = 1
    for item in _llm_packages:
        if importlib_util.find_spec(item):
            # 标识是模型应用
            app_type = "app"
    return app_type

def get_hostname() -> str:
    hostname = socket.gethostname()
    return hostname