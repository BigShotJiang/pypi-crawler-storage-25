# aliyun/sdk/extension/arms/semconv/extractors/grpc_extractor.py

from urllib.parse import urlparse

from aliyun.sdk.extension.arms.semconv.attributes.arms_attributes import (
    RpcTypeValue,
    CallTypeValue,
    categorize_http_status,  # 可复用逻辑？但 gRPC 不同
)
from aliyun.opentelemetry.semconv.trace import SpanAttributes
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.semconv.attributes import arms_attributes as ArmsAttributes
from aliyun.sdk.extension.arms.semconv.extractors.extractor import BaseExtractor


_logger = getLogger(__name__)


class GrpcExtractor(BaseExtractor):
    def __init__(self, component_name="", call_type="", call_kind="", rpc_type=-1):
        """
        初始化 extractor。

        推荐传参：
          - server: call_type=CallTypeValue.GRPC.value, call_kind="SERVER", rpc_type=RpcTypeValue.GRPC.value
          - client: call_type=CallTypeValue.GRPC_CLIENT.value, call_kind="CLIENT", rpc_type=RpcTypeValue.GRPC_CLIENT.value
        """
        self._component_name = component_name or "grpc"
        self._call_type = call_type
        self._call_kind = call_kind
        self._rpc_type = rpc_type

    def extract_plugin_info(self, attr: dict) -> (str, str, str, int):
        """
        提取插件元信息：(call_kind, call_type, component_name, rpc_type)
        """
        return self._call_kind, self._call_type, self._component_name, self._rpc_type

    def extract_endpoint(self, attr: dict) -> str:
        """
        提取 endpoint —— 即 RPC 方法路径，如 /helloworld.Greeter/SayHello
        对 server 和 client 一视同仁。
        """
        return self.extract_rpc(attr)

    def _is_server(self) -> bool:
        """
        判断是否为 Server 端。
        根据配置的 rpc_type 是否等于 GRPC Provider 的类型。
        """
        return self._rpc_type == RpcTypeValue.GRPC.value

    def extract_dest_id(self, attr: dict) -> str:
        """
        提取目标地址（远端主机）。
        优先顺序：net.peer.name > net.peer.ip:port > fallback UNKNOWN
        """
        if not attr:
            return "UNKNOWN"
        try:
            host = attr.get(SpanAttributes.NET_PEER_NAME)
            if host:
                return host

            ip = attr.get(SpanAttributes.NET_PEER_IP)
            if ip:
                port = attr.get(SpanAttributes.NET_PEER_PORT, "")
                return f"{ip}:{port}" if port else ip
            service = attr.get(SpanAttributes.RPC_SERVICE)
            if service:
                return service
            # Fallback
            return "UNKNOWN"
        except Exception as e:
            _logger.warning("Failed to extract dest_id from attributes", exc_info=e)
            return "UNKNOWN"

    def extract_rpc(self, attr: dict) -> str:
        """
        提取 RPC 名称：service/method
        """
        if not attr:
            return "UNKNOWN"
        try:
            service = attr.get(SpanAttributes.RPC_SERVICE)
            method = attr.get(SpanAttributes.RPC_METHOD)

            if service and method:
                return f"{service}/{method}"

            # Fallbacks
            full_name = attr.get(SpanAttributes.RPC_NAME)
            if full_name:
                return full_name.lstrip("/")

            span_name = attr.get("span.name")
            if span_name and span_name.startswith("/"):
                return span_name.lstrip("/")

            return "UNKNOWN"
        except Exception as e:
            _logger.warning("Failed to extract RPC from attributes", exc_info=e)
            return "UNKNOWN"

    def extract_status_code(self, status_code: int) -> str:
        """
        将 gRPC status code 映射为分组字符串。

        参考 gRPC 定义：
          OK(0), CANCELLED(1), UNKNOWN(2), INVALID_ARGUMENT(3), ...
          UNIMPLEMENTED(12), INTERNAL(13), UNAVAILABLE(14), DATA_LOSS(15), UNAUTHENTICATED(16)

        分类策略参考 HTTP：
          - OK -> "2xx"
          - CLIENT_ERROR (3~11, 16) -> "4xx"
          - SERVER_ERROR (13,14,15) -> "5xx"
          - UNIMPLEMENTED(12) -> 特殊处理？也可归为 "5xx"
        """
        if status_code == 0:  # OK
            return "2xx"
        elif status_code in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 16):  # Client errors + Unauthenticated
            return "4xx"
        elif status_code in (12, 13, 14, 15):  # Unimplemented, Internal, Unavailable, DataLoss
            return "5xx"
        else:
            return "5xx"
