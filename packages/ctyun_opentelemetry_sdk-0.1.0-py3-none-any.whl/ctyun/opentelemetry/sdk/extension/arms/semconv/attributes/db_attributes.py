


DB_STATEMENT_ID = "db.statement.id"

SQL_ID = "sqlId"

OP_TYPE = "opType"

DB_SYSTEM = "db.system"

DB_NAME = "db.name"

SQL_KEY = "sql"

SQL_IDS = "sql.ids"

# Trace attributes for DB operations
DB_SYSTEM_NAME = "db.system.name"

DB_OPERATION_NAME = "db.operation.name"

DB_COLLECTION_NAME = "db.collection.name"

DB_QUERY_SUMMARY = "db.query.summary"

DB_QUERY_TEXT = "db.query.text"

DB_RESPONSE_STATUS_CODE = "db.response.status_code"

DB_RESPONSE_RETURNED_ROWS = "db.response.returned_rows"

# Network and server attributes
NET_PEER_NAME = "net.peer.name"

SERVER_ADDRESS = "server.address"

SERVER_PORT = "server.port"

# Error attributes
ERROR_TYPE = "error.type"