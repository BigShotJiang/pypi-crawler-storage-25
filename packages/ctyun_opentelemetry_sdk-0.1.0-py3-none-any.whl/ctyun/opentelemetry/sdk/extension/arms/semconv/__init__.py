from aliyun.opentelemetry.context import create_key

_SUPPRESS_LLM_SDK_KEY = create_key("suppress_llm_sdk")


