from abc import ABC, abstractmethod
from aliyun.sdk.extension.arms.convergence import converge, TargetType
from aliyun.sdk.extension.arms.semconv.attributes.arms_attributes import (
    DEST_ID,
    ENDPOINT,
    RPC,
    CALL_KIND,
    CALL_TYPE,
    COMPONENT_NAME,
    OUT_IDS,
    RPC_TYPE
)

class BaseExtractor(ABC):
    def __init__(self):
        pass
    # 第一个dict: metric attribute合集
    # 第二个dict: span attribute合集
    def extract(self, attr: dict, rpc : str = "") -> (dict, dict):
        """
        公共属性
        1. destId
        2. endpoint
        3. rpc
        4. callKind
        5. callType
        """
        call_kind, call_type, component_name, rpc_type = self.extract_plugin_info(attr)
        dest_id = self.extract_dest_id(attr)
        if dest_id:
            dest_id = converge(TargetType.dest_id, dest_id)
        endpoint = self.extract_endpoint(attr)
        if endpoint:
            endpoint = converge(TargetType.endpoint, endpoint)
        rpc = converge(TargetType.other_rpc, rpc)
        return {
            DEST_ID: dest_id,
            ENDPOINT: endpoint,
            RPC: rpc,
            CALL_KIND: call_kind,
            CALL_TYPE: call_type,
            RPC_TYPE: rpc_type,
        }, {
            DEST_ID: dest_id,
            ENDPOINT: endpoint,
            OUT_IDS: dest_id,
            COMPONENT_NAME: component_name,
        }
    @abstractmethod
    def extract_plugin_info(self, attr: dict) -> (str, str, str, int):
        pass
    @abstractmethod
    def extract_endpoint(self, attr: dict) -> str:
        pass
    @abstractmethod
    def extract_dest_id(self, attr: dict) -> str:
        pass
    @abstractmethod
    def extract_rpc(self, attr: dict) -> str:
        pass