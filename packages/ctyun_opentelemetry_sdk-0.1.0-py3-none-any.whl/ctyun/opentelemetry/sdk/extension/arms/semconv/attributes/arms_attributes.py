from enum import Enum

from aliyun.opentelemetry.context import create_key

APP = "app"

VERSION = "version"

SOURCE = "source"

STATUS = "status"

ENDPOINT = "endpoint"

DEST_ID = "destId"

RPC = "rpc"

HOST = "host"

OUT_IDS = "out.ids"

EagleEye_pAppName = "EagleEye-pAppName"

EagleEye_pRpc = "EagleEye-pRpc"

NET_PROTOCOL_NAME = "net.protocol.name"

COMPONENT_NAME = "component.name"

RPC_TYPE = "rpcType"

TRACE_PROTOCOL_TYPE = "trace.protocol.type"

EXCEP_TYPE = "excepType"

EXCEP_INFO = "excepInfo"

EXCEP_NAME = "excepName"

EXCEP_IDS = "excep.ids"

# Trace-specific exception attributes (dot notation for trace)
EXCEP_NAME_TRACE = "excep.name"

EXCEP_MESSAGE = "excep.message"

EXCEP_STACK = "excep.stack"

CALL_TYPE = "callType"

CALL_KIND = "callKind"

SERVICE_TYPE = "serviceType"

PID = "pid"

CLUSTER_ID = "clusterId"

PPID = "ppid"

PRPC = "prpc"

# Database-specific attribute keys
OP_TYPE = "opType"

SQL_ID = "sqlId"


class RpcTypeValue(Enum):
    HTTP = 0

    HTTP_CLIENT = 25

    MYSQL = 60

    POSTGRESQL = 61

    REDIS = 70

    GRPC = 9

    GRPC_CLIENT = 10

    MONGODB = 64


class CallTypeValue(Enum):
    HTTP = "http"

    HTTP_CLIENT = "http_client"

    MYSQL = "mysql"

    POSTGRESQL = "postgresql"

    REDIS = "redis"

    GRPC = "grpc"

    GRPC_CLIENT = "grpc_client"

    MONGODB = "mongodb"


class CallKindValue(Enum):
    SQL = "sql"

    HTTP = "http"

    GRPC = "grpc"

    NOSQL = "nosql"


# Database ARMS extension constants
SLOW_THRESHOLD_SECONDS = 500

EXCEP_INFO_CONSTANT = "c4"


class ComponentNameValue(Enum):
    HTTP_SERVER = "http_server"

    HTTP_CLIENT = "http_client"

    HTTPX = "httpx"

    DIFY = "dify"

    DIFY_PLUGIN = "dify_plugin"

    DASHSCOPE = "dashscope"

    OPENAI = "openai"

    LLAMA_INDEX = "llama_index"

    LANGCHAIN = "langchain"

    REDIS = "redis"

    SQLALCHEMY = "sqlalchemy"

# TODO
class ServiceTypeValue(Enum):
    HTTP = "9152"
    HTTP_CLIENT = "9055"
    DUBBO_CONSUMER = "9110"
    DUBBO_PROVIDER = "1110"
    GRPC_CONSUMER = "9101"
    GRPC_PROVIDER = "1101"
    DB = "2250"


def categorize_http_status(status_code):
    category = status_code // 100
    if category == 2:
        return "2xx"
    elif category == 3:
        return "3xx"
    elif category == 4:
        return "4xx"
    elif category == 5:
        return "5xx"
    else:
        return "Unknown"
