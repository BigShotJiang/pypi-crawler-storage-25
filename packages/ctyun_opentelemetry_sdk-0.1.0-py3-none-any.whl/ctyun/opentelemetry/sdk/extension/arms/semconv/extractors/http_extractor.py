from urllib.parse import urlparse

from aliyun.sdk.extension.arms.semconv.attributes.arms_attributes import RpcTypeValue
from aliyun.opentelemetry.semconv.trace import SpanAttributes
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.semconv.attributes import arms_attributes as ArmsAttributes
from aliyun.sdk.extension.arms.semconv.extractors.extractor import BaseExtractor
_http_attrs = {
    ArmsAttributes.RPC,
    ArmsAttributes.RPC_TYPE,
    ArmsAttributes.CALL_KIND,
    ArmsAttributes.CALL_TYPE,
    ArmsAttributes.DEST_ID,
    ArmsAttributes.ENDPOINT,
    ArmsAttributes.PRPC,
    ArmsAttributes.PPID,
}
_logger = getLogger(__name__)
class HttpExtractor(BaseExtractor):
    def __init__(self, component_name="", call_type="", call_kind="", rpc_type=-1):
        self._component_name = component_name
        self._call_type = call_type
        self._call_kind = call_kind
        self._rpc_type = rpc_type
    def extract_plugin_info(self, attr: dict) -> (str, str, str, int):
        return self._call_kind, self._call_type, self._component_name, self._rpc_type
    def extract_endpoint(self, attr: dict) -> str:
        if self._is_server():
            return self.extract_rpc(attr)
        if not attr:
            return "UNKNOWN"
        url = attr.get(SpanAttributes.HTTP_URL, "")
        request_url = urlparse(url)
        # TODO: 存在重复计算，可以优化
        return request_url.path if len(request_url.path) > 0 else "/"

    def _is_server(self):
        return self._rpc_type == 0 or self._rpc_type == RpcTypeValue.HTTP

    def extract_dest_id(self, attr: dict) -> str:
        if not attr:
            return "UNKNOWN"
        try:
            dest_id = attr.get(SpanAttributes.HTTP_HOST, None)
            if not dest_id:
                url = attr.get(SpanAttributes.HTTP_URL, "")
                request_url = urlparse(url)
                return request_url.hostname if request_url.hostname else "UNKNOWN"
            else:
                return dest_id
        except Exception:
            return "UNKNOWN"

    def extract_rpc(self, attr: dict) -> str:
        if not attr:
            return "UNKNOWN"
        return attr.get(SpanAttributes.HTTP_ROUTE, attr.get(SpanAttributes.URL_PATH, "UNKNOWN"))
    def extract_status_code(self, status_code: int) -> str:
        if status_code == 200:
            return "200"
        elif 200 < status_code < 300:
            return "2xx"
        elif 300 <= status_code < 400:
            return "3xx"
        elif 400 <= status_code < 500:
            return "4xx"
        elif 100 <= status_code < 200:
            return "1xx"
        else:
            return "5xx"