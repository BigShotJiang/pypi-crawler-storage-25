# Copyright Alibaba Cloud ARMS Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ArmsShutdownProcessor - 虚拟 Processor，用于协调 ARMS 组件的优雅退出。

必须注册在 TracerProvider 的最前面，确保其 shutdown() 最先被调用。

Usage:
    tracer_provider = TracerProvider()
    # 第一个注册，确保 shutdown 最先调用
    tracer_provider.add_span_processor(ArmsShutdownProcessor())
    # 然后注册其他 processor
    tracer_provider.add_span_processor(ArmsBatchSpanProcessor(...))
"""

import time
from typing import Optional

from aliyun.opentelemetry.context import Context
from aliyun.opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor

from aliyun.sdk.extension.arms.logger import getLogger

_logger = getLogger(__name__)


class ArmsShutdownProcessor(SpanProcessor):
    """
    虚拟 Processor，仅用于协调 ARMS 组件的优雅退出。
    
    必须注册在 TracerProvider 的最前面，确保其 shutdown() 最先被调用。
    
    退出顺序（上游先于下游）：
    1. ExtendedTelemetryHandler - 停止接收新请求，处理完异步队列
    2. ArmsUploader - 完成所有上传任务
    3. ArmsPreUploader - 关闭事件循环
    """
    
    def __init__(
        self,
        handler_timeout: float = 5.0,
        uploader_timeout: float = 5.0,
        pre_uploader_timeout: float = 2.0,
    ):
        """
        初始化 ArmsShutdownProcessor。
        
        Args:
            handler_timeout: ExtendedTelemetryHandler shutdown 超时时间（秒）
            uploader_timeout: ArmsUploader shutdown 超时时间（秒）
            pre_uploader_timeout: ArmsPreUploader shutdown 超时时间（秒）
        """
        self._handler_timeout = handler_timeout
        self._uploader_timeout = uploader_timeout
        self._pre_uploader_timeout = pre_uploader_timeout
        self._shutdown_called = False
    
    def on_start(
        self, span: Span, parent_context: Optional[Context] = None
    ) -> None:
        """空实现，不处理 span"""
        pass
    
    def on_end(self, span: ReadableSpan) -> None:
        """空实现，不处理 span"""
        pass
    
    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """空实现，无需 flush"""
        return True
    
    def shutdown(self) -> None:
        """
        按顺序关闭所有 ARMS 组件（上游先于下游）
        
        顺序：
        1. ExtendedTelemetryHandler - 停止接收新请求，处理完异步队列
        2. ArmsUploader - 完成所有上传任务
        3. ArmsPreUploader - 关闭事件循环
        """
        if self._shutdown_called:
            return
        self._shutdown_called = True
        
        _logger.debug("ArmsShutdownProcessor: starting graceful shutdown...")
        start_time = time.time()
        
        # 1. 关闭 ExtendedTelemetryHandler（上游）
        self._shutdown_handler()
        
        # 2. 关闭 ArmsUploader（中游）
        self._shutdown_uploader()
        
        # 3. 关闭 ArmsPreUploader（辅助组件）
        self._shutdown_pre_uploader()
        
        elapsed = time.time() - start_time
        _logger.debug(
            f"ArmsShutdownProcessor: graceful shutdown completed in {elapsed:.2f}s"
        )
    
    def _shutdown_handler(self) -> None:
        """关闭 ExtendedTelemetryHandler"""
        try:
            from aliyun.opentelemetry.util.genai.extended_handler import (
                ExtendedTelemetryHandler,
            )
            _logger.debug("Shutting down ExtendedTelemetryHandler...")
            ExtendedTelemetryHandler.shutdown_async_worker(
                timeout=self._handler_timeout
            )
        except ImportError:
            _logger.debug("ExtendedTelemetryHandler not available, skipping")
        except Exception as e:
            _logger.warning(f"Error shutting down ExtendedTelemetryHandler: {e}")
    
    def _shutdown_uploader(self) -> None:
        """关闭 ArmsUploader"""
        try:
            from aliyun.sdk.extension.arms.uploader import get_uploader
            uploader = get_uploader()
            if uploader is not None and hasattr(uploader, 'shutdown'):
                _logger.debug("Shutting down ArmsUploader...")
                uploader.shutdown(timeout=self._uploader_timeout)
        except ImportError:
            _logger.debug("ArmsUploader not available, skipping")
        except Exception as e:
            _logger.warning(f"Error shutting down ArmsUploader: {e}")
    
    def _shutdown_pre_uploader(self) -> None:
        """关闭 ArmsPreUploader"""
        try:
            from aliyun.sdk.extension.arms.uploader.pre_uploader import (
                ArmsPreUploader,
            )
            _logger.debug("Shutting down ArmsPreUploader...")
            ArmsPreUploader.shutdown(timeout=self._pre_uploader_timeout)
        except ImportError:
            _logger.debug("ArmsPreUploader not available, skipping")
        except Exception as e:
            _logger.warning(f"Error shutting down ArmsPreUploader: {e}")

