# -*- coding: utf-8 -*-
"""
Simplified OSS file upload tool
Contains only the basic put_object_from_file functionality with minimal dependencies
"""
import sys
import hmac
import time
import random
import datetime
import platform
import requests

from math import log2
from hashlib import sha256
from email.utils import format_datetime
from urllib.parse import quote
from typing import Optional, Set
from requests.structures import CaseInsensitiveDict

__version__ = "1.0.0"

DEFAULT_CONNECT_TIMEOUT = 10
DEFAULT_READWRITE_TIMEOUT = 20

# Retry configuration
DEFAULT_MAX_RETRY_ATTEMPTS = 3
DEFAULT_BASE_DELAY = 0.2  # 200ms
DEFAULT_MAX_BACKOFF = 20.0  # 20s


class FullJitterBackoff:
    """FullJitterBackoff implements capped exponential backoff with jitter.
    [0.0, 1.0) * min(2 ^ attempts * baseDelay, maxBackoff)
    """

    def __init__(self, base_delay: float, max_backoff: float) -> None:
        """
        Args:
            base_delay (float): the base delay duration in second
            max_backoff (float): the max duration in second
        """
        self._base_delay = base_delay
        self._max_backoff = max_backoff
        self._attempt_celling = int(log2(float(sys.maxsize) / base_delay))

    def backoff_delay(self, attempt: int) -> float:
        """Returns the delay that should be used before retrying the attempt.

        Args:
            attempt (int): current retry attempt

        Returns:
            float: delay duration in second.
        """
        attempt = min(attempt, self._attempt_celling)
        delay = min((self._base_delay * (1 << attempt)), self._max_backoff)
        rand = random.uniform(0, 1)
        return rand * delay

    def __repr__(self) -> str:
        return f"<FullJitterBackoff, base delay: '{self._base_delay}', max backoff: '{self._max_backoff}'>"


class PutObjectResult:
    def __init__(self, status_code: int, headers):
        self.status_code = status_code
        self.headers: CaseInsensitiveDict = headers


def _exception_from_packed_args(exception_cls, args=None, kwargs=None):
    if args is None:
        args = ()
    if kwargs is None:
        kwargs = {}
    return exception_cls(*args, **kwargs)


class BaseError(Exception):
    """
    The base exception class for oss sdk exceptions.

    :ivar msg: The descriptive message associated with the error.
    """

    fmt = "An unspecified error occurred"

    def __init__(self, **kwargs):
        msg = self.fmt.format(**kwargs)
        Exception.__init__(self, msg)
        self.kwargs = kwargs

    def __reduce__(self):
        return _exception_from_packed_args, (self.__class__, None, self.kwargs)


class ServiceError(BaseError):
    """
    The exception class for error from oss service.
    """

    fmt = "Error returned by Service.\n\
        Http Status Code: {status_code}.\n\
        Request Id: {request_id}.\n\
        EC: {ec}.\n\
        Timestamp: {timestamp}.\n\
        Response Body: {response_body}."

    def __init__(self, **kwargs):
        BaseError.__init__(self, **kwargs)
        self.status_code = kwargs.get("status_code", 0)
        self.ec = kwargs.get("ec", None)
        self.request_id = kwargs.get("request_id", None)
        self.timestamp = kwargs.get("timestamp", None)
        self.response_body = kwargs.get("response_body", None)
        self.headers = kwargs.get("headers", None)


class ParamNullOrEmptyError(BaseError):
    """
    Param Null or Empty Error.
    """

    fmt = "null or empty field, {field}."


def get_user_agent() -> str:
    """Returns the default user agent string"""
    sysinfo = f"{platform.system()}/{platform.release()}/{platform.machine()};{platform.python_version()}"
    return f"alibabacloud-python-sdk-v2-arms/{__version__} ({sysinfo})"


class OSSUploader:
    """Aliyun OSS Simplified Uploader"""

    def __init__(
        self,
        endpoint: str,
        access_key_id: str,
        access_key_secret: str,
        bucket: str,
        region_id: str,
        disable_ssl: bool = False,
        security_token: Optional[str] = None,
        max_retries: int = DEFAULT_MAX_RETRY_ATTEMPTS,
        base_delay: float = DEFAULT_BASE_DELAY,
        max_backoff: float = DEFAULT_MAX_BACKOFF,
    ):
        """
        Initialize OSS Uploader

        Args:
            access_key_id: AccessKey ID
            access_key_secret: AccessKey Secret
            endpoint: OSS endpoint, e.g. 'oss-cn-hangzhou.aliyuncs.com' or 'https://oss-cn-hangzhou.aliyuncs.com'
            bucket: Bucket name
            region_id: OSS region, e.g. 'cn-hangzhou'
            disable_ssl: Whether to disable SSL, default False (use HTTPS)
            security_token: STS security token (optional, for temporary credentials)
            max_retries: Maximum number of retry attempts (default: 3)
            base_delay: Base delay for backoff in seconds (default: 0.2)
            max_backoff: Maximum backoff delay in seconds (default: 20.0)
        """
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.bucket = bucket
        self.region_id = region_id
        self.security_token = security_token
        self.max_retries = max_retries
        self.scheme, self.endpoint = self._parse_endpoint(
            endpoint, disable_ssl)
        self._backoff_delayer = FullJitterBackoff(base_delay, max_backoff)
        self.user_agent = get_user_agent()

        if max_retries < 1:
            raise ValueError("max_retries must be at least 1")
        if not self.endpoint:
            raise ParamNullOrEmptyError(field="endpoint")
        if not self.bucket:
            raise ParamNullOrEmptyError(field="bucket")

    def put_object_from_file(self, object_key: str, file_path: str) -> PutObjectResult:
        """
        Upload file to OSS

        Args:
            object_key: OSS object key (file path in OSS)
            file_path: Local file path to upload

        Returns:
            PutObjectResult: Result object containing status code and response headers

        Raises:
            ParamNullOrEmptyError: Required parameter is null or empty
            FileNotFoundError: Local file does not exist
            ServiceError: Server returns error response (4xx or 5xx)
            RequestException: Network error or timeout
        """
        # Read file content
        with open(file_path, "rb") as f:
            file_content = f.read()

        return self.put_object(object_key, file_content)

    def put_object(self, object_key: str, content: bytes) -> PutObjectResult:
        """
        Upload content to OSS with automatic retry on retriable errors

        Args:
            object_key: OSS object key (file path in OSS)
            content: File content in bytes

        Returns:
            PutObjectResult: Result object containing status code and response headers

        Raises:
            ParamNullOrEmptyError: Required parameter is null or empty
            ServiceError: Server returns error response (non-retriable 4xx errors)
            RequestException: Network error after all retry attempts exhausted
        """
        if not object_key:
            raise ParamNullOrEmptyError(field="object_key")

        url = self._build_url(object_key)

        last_error: Optional[Exception] = None

        for attempt in range(self.max_retries):
            if attempt > 0:
                delay = self._backoff_delayer.backoff_delay(attempt)
                time.sleep(delay)

            try:
                return self._send_request_once(url, content, object_key)
            except Exception as e:
                last_error = e

            if not self._is_retryable(last_error):
                break

        if last_error is not None:
            raise last_error
        else:
            raise RuntimeError("Unexpected error: no error captured after retry loop")

    def _send_request_once(
        self, url: str, content: bytes, object_key: str
    ) -> PutObjectResult:
        headers = self._prepare_common_headers()
        self._sign_request("PUT", object_key, headers)

        response = requests.put(
            url,
            data=content,
            headers=headers,
            timeout=(DEFAULT_CONNECT_TIMEOUT, DEFAULT_READWRITE_TIMEOUT),
        )

        if response.status_code // 100 == 2:
            return PutObjectResult(
                status_code=response.status_code,
                headers=response.headers,
            )
        raise self._to_service_error(response)

    def _to_service_error(self, response: requests.Response) -> ServiceError:
        content = response.content or b""
        return ServiceError(
            status_code=response.status_code,
            request_id=response.headers.get("x-oss-request-id", ""),
            ec=response.headers.get("x-oss-ec", ""),
            timestamp=response.headers.get("Date"),
            response_body=content,
            headers=response.headers,
        )

    def _is_retryable(self, error: Exception) -> bool:
        # Retry on http status code
        if isinstance(error, ServiceError):
            status_code = error.status_code
            if status_code >= 500:
                return True
            if status_code in [401, 403, 408, 429]:
                return True
            return False

        # client error or network error
        return True

    def _parse_endpoint(self, endpoint: str, disable_ssl: bool) -> tuple:
        if endpoint.startswith("https://"):
            return "https", endpoint[8:]
        elif endpoint.startswith("http://"):
            return "http", endpoint[7:]
        else:
            scheme = "http" if disable_ssl else "https"
            return scheme, endpoint

    def _build_url(self, object_key: str) -> str:
        host = f"{self.bucket}.{self.endpoint}"
        encoded_key = quote(object_key, safe="/")
        return f"{self.scheme}://{host}/{encoded_key}"

    def _prepare_common_headers(self) -> CaseInsensitiveDict:
        headers = CaseInsensitiveDict()
        headers["Content-Type"] = "application/octet-stream"
        headers["User-Agent"] = self.user_agent
        return headers

    def _sign_request(
        self,
        method: str,
        object_key: str,
        headers: CaseInsensitiveDict,
        date: Optional[datetime.datetime] = None
    ) -> None:

        if not self.access_key_id or not self.access_key_secret:
            raise ParamNullOrEmptyError(
                field="access_key_id or access_key_secret")

        if date is not None:
            datetime_now = date
        else:
            datetime_now = datetime.datetime.now(datetime.timezone.utc)

        datetime_now_iso8601 = datetime_now.strftime("%Y%m%dT%H%M%SZ")
        datetime_now_rfc2822 = format_datetime(datetime_now, True)
        date_now_iso8601 = datetime_now_iso8601[:8]
        headers.update({"x-oss-date": datetime_now_iso8601})
        headers.update({"Date": datetime_now_rfc2822})

        if self.security_token is not None and self.security_token != "":
            headers.update({"x-oss-security-token": self.security_token})

        # Other Headers
        headers.update({"x-oss-content-sha256": "UNSIGNED-PAYLOAD"})

        # scope
        region = self.region_id or ""
        product = "oss"
        scope = self._build_scope(
            date=date_now_iso8601, region=region, product=product)

        additional_headers = set()

        # Canonical request
        canonical_request = self._calc_canonical_request(
            method, object_key, headers, additional_headers
        )

        string_to_sign = self._calc_string_to_sign(
            datetime_now_iso8601, scope, canonical_request
        )

        signature = self._calc_signature(
            date=date_now_iso8601,
            region=region,
            product=product,
            string_to_sign=string_to_sign,
        )

        credential_header = f"OSS4-HMAC-SHA256 Credential={self.access_key_id}/{scope}"
        if len(additional_headers) > 0:
            credential_header = (
                f'{credential_header},AdditionalHeaders={";".join(additional_headers)}'
            )
        credential_header = f"{credential_header},Signature={signature}"

        headers.update({"Authorization": credential_header})

    def _build_scope(self, date: str, region: str, product: str) -> str:
        return f"{date}/{region}/{product}/aliyun_v4_request"

    def _calc_canonical_request(
        self,
        method: str,
        object_key: str,
        headers: CaseInsensitiveDict,
        additional_headers: Set[str],
    ) -> str:
        """
        Canonical Request
            HTTP Verb + "\n" +
            Canonical URI + "\n" +
            Canonical Query String + "\n" +
            Canonical Headers + "\n" +
            Additional Headers + "\n" +
            Hashed PayLoad
        """
        uri = "/"
        if self.bucket is not None:
            uri = uri + self.bucket + "/"
        if object_key is not None:
            uri = uri + object_key
        canonical_uri = quote(uri, safe="/")

        canonical_query = ""

        canon_headers = []
        for k, v in headers.items():
            lower_key = k.lower()
            if self._is_sign_header(lower_key, additional_headers):
                canon_headers.append((lower_key, v))
        canon_headers.sort(key=lambda x: x[0])
        canonical_headers = "".join(
            v[0] + ":" + v[1] + "\n" for v in canon_headers)

        canonical_additional_headers = ";".join(additional_headers)

        hash_payload = headers.get("x-oss-content-sha256", "UNSIGNED-PAYLOAD")

        return f"{method}\n{canonical_uri}\n{canonical_query}\n{canonical_headers}\n{canonical_additional_headers}\n{hash_payload}"

    def _calc_string_to_sign(
        self, datetime_: str, scope: str, canonical_request: str
    ) -> str:
        """
        StringToSign
            "OSS4-HMAC-SHA256" + "\n" +
            TimeStamp + "\n" +
            Scope + "\n" +
            Hex(SHA256Hash(Canonical Request))
        """
        values = ["OSS4-HMAC-SHA256"]
        values.append(datetime_)
        values.append(scope)
        values.append(sha256(canonical_request.encode("utf-8")).hexdigest())
        return "\n".join(values)

    def _calc_signature(
        self, date: str, region: str, product: str, string_to_sign: str
    ) -> str:
        key_secret = ("aliyun_v4" + self.access_key_secret).encode("utf-8")
        signing_date = hmac.new(
            key_secret, date.encode("utf-8"), sha256).digest()
        signing_region = hmac.new(
            signing_date, region.encode("utf-8"), sha256).digest()
        signing_product = hmac.new(
            signing_region, product.encode("utf-8"), sha256
        ).digest()
        signing_key = hmac.new(
            signing_product, "aliyun_v4_request".encode("utf-8"), sha256
        ).digest()
        signature = hmac.new(
            signing_key, string_to_sign.encode(), sha256).hexdigest()
        return signature

    @staticmethod
    def _is_sign_header(key: str, additional_headers) -> bool:
        if key is not None:
            if key.startswith("x-oss-"):
                return True

            if key in ["content-type", "content-md5"]:
                return True

            if additional_headers is not None and key in additional_headers:
                return True

        return False
