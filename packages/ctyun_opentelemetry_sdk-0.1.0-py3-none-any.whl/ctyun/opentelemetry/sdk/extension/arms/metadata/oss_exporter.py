import logging

from logging import Logger
from aliyun.sdk.extension.arms.logger import getLogger
from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from typing import Union, Optional
from aliyun.sdk.extension.arms.metadata.oss_uploader import OSSUploader


logger: Logger = getLogger(__name__, level=logging.INFO)

class OssCredentials(object):
    def __init__(self, access_key_id: str, access_key_secret: str, security_token: Optional[str] = None):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.security_token = security_token

    def get_access_key_id(self):
        return self.access_key_id

    def get_access_key_secret(self):
        return self.access_key_secret

    def get_security_token(self):
        return self.security_token


class OssExporter(object):
    def __init__(self, credential: Optional[OssCredentials] = None):
        super().__init__()
        self.credential = credential
        arms_instance = ArmsEnv.instance()
        self.endpoint = arms_instance.getOssEndpoint()
        self.region_id = arms_instance.getRegionId()
        self.bucket_name = f"arms-profiling-{self.region_id}"
        self.oss_client : Optional[OSSUploader] = self._create_oss_client(credential)
        self.uid = arms_instance.user_id
        self.agentId = arms_instance.agentId
        # use get_agent_ip to get the ip of the agent
        # todo: check if server can recognize the format of ip-pid
        self.ip = arms_instance.get_agent_ip()
        self.workspace = arms_instance.workspace
        self.default_workspace = arms_instance.is_default_workspace

    def export_file(self, profile_type: str, start_time_ms: int, file_path: str):
        logger.debug(
            "------------endpoints: %s   file_path:%s bucket: %s",
            self.endpoint,
            file_path,
            self.bucket_name,
        )
        if self.oss_client is None:
            logger.warning(f"OssExporter oss_client is None, skip export file: {file_path}")
            return
        object_name = self._get_object_name(profile_type, start_time_ms)
        self.oss_client.put_object_from_file(object_name, file_path)
        logger.info(
            "------------export oss data success: %s, file_path: %s",
            object_name,
            file_path,
        )

    # todo: add thread lock
    def set_credential(self, credential: OssCredentials):
        if credential is not None:
            self.credential = credential
            try:
                self.oss_client = self._create_oss_client(credential)
            except Exception:
                logger.error(f"Init ossClient failed", exc_info=True)

    def _create_oss_client(self, credential: Union[OssCredentials, None]) -> Optional[OSSUploader]:
        if credential is None:
            return None

        return OSSUploader(
            endpoint=self.endpoint,
            access_key_id=credential.get_access_key_id(),
            access_key_secret=credential.get_access_key_secret(),
            bucket=self.bucket_name,
            region_id=self.region_id,
            security_token=credential.get_security_token(),
        )

    def _get_object_name(self, profile_type: str, start_time_ms: int) -> str:
        base_path = self._get_base_path()
        if profile_type == "cpu":
            return f"{base_path}/{self.agentId}/{self.ip}/profile{start_time_ms}.pprof.gz"
        return f"{base_path}/{self.agentId}/{self.ip}/profile-{profile_type}-{start_time_ms}.pprof.gz"

    def _get_base_path(self) -> str:
        workspace = self._get_workspace()
        if workspace and self.uid:
            return f"{self.uid}@@{workspace}"
        return self.uid

    def _get_workspace(self) -> Union[str, None]:
        return self.workspace if self.workspace and not self.default_workspace else None
