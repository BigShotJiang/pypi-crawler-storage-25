import logging
from functools import lru_cache

from aliyun.sdk.extension.arms.config import config
from aliyun.sdk.extension.arms.metadata.module.metadata import SqlMetadata
from aliyun.sdk.extension.arms.utils.encode_utils import crc_encode
from aliyun.sdk.extension.arms.proto.arms_metadata_pb2 import ArmsSqlMetaData
from aliyun.sdk.extension.arms.metadata import add_sql_metadata


class ArmsProcessedSql:
    """Represents a processed SQL statement with its ID and normalized form."""
    
    def __init__(self, sql_id: str = "", normalized_sql: str = ""):
        self.sql_id = sql_id
        self.normalized_sql = normalized_sql
    
    def get_sql_id(self) -> str:
        return self.sql_id
    
    def set_sql_id(self, sql_id: str):
        self.sql_id = sql_id
    
    def get_normalized_sql(self) -> str:
        return self.normalized_sql
    
    def set_normalized_sql(self, normalized_sql: str):
        self.normalized_sql = normalized_sql


# Create the INVALID instance
INVALID_SQL = ArmsProcessedSql()

@lru_cache(1024)
def get_sql_id(sql: str) -> str:
    return crc_encode(sql)


class ArmsSqlRecordHandler:
    """Handler for recording SQL statements with caching and metadata sending."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def record_sql(self, sql: str) -> ArmsProcessedSql:
        """Record a SQL statement and return processed result."""
        if not sql or not sql.strip():
            return INVALID_SQL
        
        arms_processed_sql = ArmsProcessedSql()
        sql_id = self._cache_sql(sql)
        arms_processed_sql.set_sql_id(sql_id)
        arms_processed_sql.set_normalized_sql(sql)
        return arms_processed_sql
    
    def _cache_sql(self, sql: str) -> str:
        """Cache SQL and return its ID."""
        if not sql:
            return ""
        
        # Use the cached encode function
        sql_id = get_sql_id(sql)
        
        # Send to remote immediately (only for new SQL statements)
        # Note: lru_cache doesn't tell us if it was a hit or miss,
        # so we'll send every time for now
        self._send_sql_metadata(sql, sql_id)
        return sql_id
    
    def _send_sql_metadata(self, sql: str, sql_id: str):
        """Send SQL metadata to remote service."""
        try:
            if not config.arms_enable:
                return
            add_sql_metadata(SqlMetadata(ArmsSqlMetaData(sqlId=sql_id, sql=sql)))
        except Exception as e:
            self.logger.warning(f"[ArmsSqlRecordHandler] sendSqlMetaData data:, error: {e}")


# Create singleton instance
sql_recorder = ArmsSqlRecordHandler()
