from aliyun.sdk.extension.arms.self_monitor.self_monitor import _self_monitor_metrics

from aliyun.sdk.extension.arms.common.arms_env import ArmsEnv
from aliyun.sdk.extension.arms.config.constant import CMS_WORKSPACE, SLS_PROJECT
from aliyun.sdk.extension.arms.exporters.arms_endpoints_state import global_arms_endpoints_state
#
# from logging import getLogger
from aliyun.sdk.extension.arms.metadata.base_exporter import BaseExporter
import requests
from typing import Any, Callable
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from aliyun.sdk.extension.arms.logger import diagnose_logger


class MetadataExporter(BaseExporter):

    def __init__(self, headers, handler: Callable[..., Any] = None):
        from aliyun.sdk.extension.arms.logger import getLogger
        self.is_running = False
        self._logger = getLogger(__name__)
        self._diag_logger = diagnose_logger("metadata_exporter")
        self.licenseKey = ArmsEnv.instance().licenseKey
        self.agentId = ArmsEnv.instance().agentId
        self.appId = ArmsEnv.instance().appId
        self.appName = ArmsEnv.instance().appName
        self.headers = headers
        if global_arms_endpoints_state.use_one_endpoints:
            self.headers.update({CMS_WORKSPACE: ArmsEnv.instance().workspace, SLS_PROJECT: global_arms_endpoints_state.sls_project})
        self.endpoint = global_arms_endpoints_state.get_full_meta_url()
        self.SEND_MAX_SIZE = ArmsEnv.instance().sendMaxSize
        self.SEND_TIME_INTERVAL = ArmsEnv.instance().sendTimeInterval
        self._logger.info(f"init over ....")
        self.handler = handler
        self._timeout = 10
        self._connect_timeout = 5  # 连接超时
        self._read_timeout = 10  # 读取超时

        # 配置重试策略
        retry_strategy = Retry(
            total=3,  # 最多重试3次
            backoff_factor=0.5,  # 重试间隔时间
            status_forcelist=[500, 502, 503, 504],  # 需要重试的HTTP状态码
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self._session = requests.Session()
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)

    def export(self, data: str):
        """
        export metadata to server
        """
        try:
            self._logger.debug(f"Endpoints: {self.endpoint}  Data:{data} Header: {self.headers}")
            self.endpoint = global_arms_endpoints_state.get_full_meta_url()
            try:
                from urllib3.connectionpool import log
                log.disabled = True
            except Exception:
                pass
            response = self._session.post(
                self.endpoint,
                data=data,
                headers=self.headers,
                timeout=(self._connect_timeout, self._read_timeout)
            )
            if response and response.status_code != 200:
                self._logger.warning(
                    f"[arms_metadata_exporter] Sending metadata to endpoints: {self.endpoint}, response code is: {response.status_code}")
                # 记录到诊断日志
                self._diag_logger.error("----------- METADATA EXPORTER FAILURE -----------")
                self._diag_logger.error(f"Metadata export failed - Endpoint: {self.endpoint}")
                self._diag_logger.error(f"Response code: {response.status_code}")
                self._diag_logger.error(f"Response text: {response.text}")
                self._diag_logger.error(f"Data size: {len(data)} bytes")
                self._diag_logger.error("----------- END METADATA EXPORTER FAILURE -----------")
            result = "success" if response.ok else "fail"
            if _self_monitor_metrics is not None:
                _self_monitor_metrics.record_agent_meta_report(len(data),
                                                                    {"status": response.status_code, "result": result})
            self._logger.debug(f"response info:{response.text}")
            if self.handler is not None:
                self.handler(response)
            return True  # 表示发送成功
        except requests.exceptions.ConnectionError as e:
            _self_monitor_metrics.record_agent_meta_report(len(data),
                                                                {"status": "connection error", "result": "fail"})
            self._logger.error(f"Connection error when exporting data: {e}")
            # 记录到诊断日志
            self._diag_logger.error("----------- METADATA EXPORTER CONNECTION ERROR -----------")
            self._diag_logger.error(f"Connection error when exporting metadata: {e}")
            self._diag_logger.error(f"Endpoint: {self.endpoint}")
            self._diag_logger.error(f"Data size: {len(data)} bytes")
            self._diag_logger.error("----------- END METADATA EXPORTER CONNECTION ERROR -----------")
            return False
        except Exception as e:
            _self_monitor_metrics.record_agent_meta_report(len(data), {"status": "other error", "result": "fail"})
            self._logger.error(f"Unexpected error when exporting data: {e}")
            # 记录到诊断日志
            self._diag_logger.error("----------- METADATA EXPORTER UNEXPECTED ERROR -----------")
            self._diag_logger.error(f"Unexpected error when exporting metadata: {e}")
            self._diag_logger.error(f"Endpoint: {self.endpoint}")
            self._diag_logger.error(f"Data size: {len(data)} bytes")
            self._diag_logger.error("----------- END METADATA EXPORTER UNEXPECTED ERROR -----------")
            return False
