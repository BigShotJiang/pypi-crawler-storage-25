# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
GenAI 数据类型定义

定义了用于生成式 AI 应用的标准化数据结构，包括消息、工具调用、评估等类型。
这些数据类型遵循阿里云扩展的语义约定。
"""

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

from sdk.semconv.trace_v2 import (
    LLMAttributes,
    EmbeddingAttributes,
    RerankerAttributes,
    ToolAttributes,
    CommonAttributes,
    GenAiOutputType,
    GenAiOperationName,
    GenAiSpanKind,
    GenAiToolType,
)
from sdk.common.types import AttributeValue

@dataclass
class ExtendableAttributes:
    """可扩展的请求属性基类"""
    extended_span_attributes: Dict[str, Any] = field(default_factory=dict)
    extended_event_attributes: Dict[str, Any] = field(default_factory=dict)

    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        return self.extended_span_attributes
    
    def get_event_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于事件的属性"""
        return self.extended_event_attributes


@dataclass
class LLMRequestAttributes(ExtendableAttributes):
    """LLM 请求属性类"""
    provider_name: Optional[str] = None
    operation_name: Optional[Union[GenAiOperationName, str]] = None
    request_model: Optional[str] = None
    request_choice_count: Optional[int] = None
    request_seed: Optional[int] = None
    request_frequency_penalty: Optional[float] = None
    request_presence_penalty: Optional[float] = None
    request_max_tokens: Optional[int] = None
    request_top_p: Optional[float] = None
    request_top_k: Optional[float] = None
    request_temperature: Optional[float] = None
    request_stop_sequences: Optional[List[str]] = None
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()
        attributes.update(self._get_base_attributes())
        return attributes
    
    def get_event_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于事件的属性"""
        attributes = super().get_event_attributes()
        attributes.update(self._get_base_attributes())
        return attributes

    def _get_base_attributes(self) -> Dict[str, AttributeValue]:
        attributes = {}
        attributes[CommonAttributes.GEN_AI_SPAN_KIND] = GenAiSpanKind.LLM.value
        if self.provider_name is not None:
            attributes[LLMAttributes.GEN_AI_PROVIDER_NAME] = self.provider_name
        if self.operation_name is not None:
            attributes[CommonAttributes.GEN_AI_OPERATION_NAME] = self.operation_name.value if isinstance(self.operation_name, GenAiOperationName) else self.operation_name
        if self.request_model is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_MODEL] = self.request_model
        if self.request_choice_count is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_CHOICE_COUNT] = self.request_choice_count
        if self.request_seed is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_SEED] = self.request_seed
        if self.request_frequency_penalty is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_FREQUENCY_PENALTY] = self.request_frequency_penalty
        if self.request_presence_penalty is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_PRESENCE_PENALTY] = self.request_presence_penalty
        if self.request_max_tokens is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_MAX_TOKENS] = self.request_max_tokens
        if self.request_top_p is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_TOP_P] = self.request_top_p
        if self.request_top_k is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_TOP_K] = self.request_top_k
        if self.request_temperature is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_TEMPERATURE] = self.request_temperature
        if self.request_stop_sequences is not None:
            attributes[LLMAttributes.GEN_AI_REQUEST_STOP_SEQUENCES] = self.request_stop_sequences
        return attributes


@dataclass
class LLMResponseAttributes(ExtendableAttributes):
    """LLM 响应属性类"""
    response_id: Optional[str] = None
    response_model: Optional[str] = None
    output_type: Optional[Union[GenAiOutputType, str]] = None
    response_finish_reasons: Optional[List[str]] = None
    usage_input_tokens: Optional[int] = None
    usage_output_tokens: Optional[int] = None
    response_time_to_first_token: Optional[int] = None
    response_time_per_output_token: Optional[int] = None
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()
        attributes.update(self._get_base_attributes())
        return attributes
    
    def get_event_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于事件的属性"""
        attributes = super().get_event_attributes()
        attributes.update(self._get_base_attributes())
        return attributes
    
    def _get_base_attributes(self) -> Dict[str, AttributeValue]:
        attributes = {}
        total_tokens: Optional[int] = None
        if self.response_id is not None:
            attributes[LLMAttributes.GEN_AI_RESPONSE_ID] = self.response_id
        if self.response_model is not None:
            attributes[LLMAttributes.GEN_AI_RESPONSE_MODEL] = self.response_model
        if self.output_type is not None:
            attributes[LLMAttributes.GEN_AI_OUTPUT_TYPE] = self.output_type.value if isinstance(self.output_type, GenAiOutputType) else self.output_type
        if self.response_finish_reasons is not None:
            attributes[LLMAttributes.GEN_AI_RESPONSE_FINISH_REASONS] = self.response_finish_reasons
        if self.usage_input_tokens is not None:
            attributes[LLMAttributes.GEN_AI_USAGE_INPUT_TOKENS] = self.usage_input_tokens
            total_tokens = 0
            total_tokens += self.usage_input_tokens
        if self.usage_output_tokens is not None:
            attributes[LLMAttributes.GEN_AI_USAGE_OUTPUT_TOKENS] = self.usage_output_tokens
            total_tokens = 0 if total_tokens is None else total_tokens
            total_tokens += self.usage_output_tokens
        if self.response_time_to_first_token is not None:
            attributes[LLMAttributes.GEN_AI_RESPONSE_TIME_TO_FIRST_TOKEN] = self.response_time_to_first_token
        if self.response_time_per_output_token is not None:
            attributes[LLMAttributes.GEN_AI_RESPONSE_TIME_PER_OUTPUT_TOKEN] = self.response_time_per_output_token
        if total_tokens is not None:
            attributes[LLMAttributes.GEN_AI_USAGE_TOTAL_TOKENS] = total_tokens
        return attributes


@dataclass
class EmbeddingRequestAttributes(ExtendableAttributes):
    """Embedding 请求属性类"""
    operation_name: Optional[Union[GenAiOperationName, str]] = None
    request_model: Optional[str] = None
    request_encoding_formats: Optional[List[str]] = None
    request_dimension_count: Optional[int] = None
    request_temperature: Optional[float] = None
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()
        
        attributes[CommonAttributes.GEN_AI_SPAN_KIND] = GenAiSpanKind.EMBEDDING.value
        if self.operation_name is not None:
            attributes[CommonAttributes.GEN_AI_OPERATION_NAME] = self.operation_name.value if isinstance(self.operation_name, GenAiOperationName) else self.operation_name
        if self.request_model is not None:
            attributes[EmbeddingAttributes.GEN_AI_REQUEST_MODEL] = self.request_model
        if self.request_encoding_formats is not None:
            attributes[EmbeddingAttributes.GEN_AI_REQUEST_ENCODING_FORMATS] = self.request_encoding_formats
        if self.request_dimension_count is not None:
            attributes[EmbeddingAttributes.GEN_AI_EMBEDDINGS_DIMENSION_COUNT] = self.request_dimension_count
        if self.request_temperature is not None:
            attributes[EmbeddingAttributes.GEN_AI_REQUEST_TEMPERATURE] = self.request_temperature

        return attributes


@dataclass
class EmbeddingResponseAttributes(ExtendableAttributes):
    """Embedding 响应属性类"""
    usage_input_tokens: Optional[int] = None
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()

        if self.usage_input_tokens is not None:
            attributes[EmbeddingAttributes.GEN_AI_USAGE_INPUT_TOKENS] = self.usage_input_tokens

        return attributes


@dataclass
class ToolRequestAttributes(ExtendableAttributes):
    """Tool 请求属性类"""
    tool_name: Optional[str] = None
    tool_description: Optional[str] = None
    tool_type: Optional[Union[GenAiToolType, str]] = None
    tool_arguments: Optional[Dict[str, Any]] = None
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()

        if self.tool_name is not None:
            attributes[ToolAttributes.GEN_AI_TOOL_NAME] = self.tool_name
        if self.tool_description is not None:
            attributes[ToolAttributes.GEN_AI_TOOL_DESCRIPTION] = self.tool_description
        if self.tool_type is not None:
            attributes[ToolAttributes.GEN_AI_TOOL_TYPE] = self.tool_type
        
        # 兼容旧版本语义规范
        if self.tool_name is not None:
            attributes[ToolAttributes.TOOL_NAME] = self.tool_name
        if self.tool_description is not None:
            attributes[ToolAttributes.TOOL_DESCRIPTION] = self.tool_description
        if self.tool_arguments is not None:
            attributes[ToolAttributes.TOOL_PARAMETERS] = json.dumps(self.tool_arguments)
            
        return attributes


@dataclass
class ToolResponseAttributes(ExtendableAttributes):
    """Tool 响应属性类"""
    tool_call_id: Optional[str] = None
    tool_result: Optional[Dict[str, Any]] = None
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()
        
        if self.tool_call_id is not None:
            attributes[ToolAttributes.GEN_AI_TOOL_CALL_ID] = self.tool_call_id
        
        if self.tool_result is not None:
            attributes[CommonAttributes.OUTPUT_VALUE] = json.dumps(self.tool_result)
            
        return attributes


@dataclass
class RerankerRequestAttributes(ExtendableAttributes):
    """Reranker 请求属性类"""
    query: Optional[str] = None
    model_name: Optional[str] = None
    top_k: Optional[int] = None
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()
        
        attributes[CommonAttributes.GEN_AI_SPAN_KIND] = GenAiSpanKind.RERANKER.value
        
        if self.query is not None:
            attributes[RerankerAttributes.RERANKER_QUERY] = self.query
        if self.model_name is not None:
            attributes[RerankerAttributes.RERANKER_MODEL_NAME] = self.model_name
        if self.top_k is not None:
            attributes[RerankerAttributes.RERANKER_TOP_K] = self.top_k
        
        return attributes


@dataclass
class RerankerResponseAttributes(ExtendableAttributes):
    """Reranker 响应属性类"""
    
    def get_span_attributes(self) -> Dict[str, AttributeValue]:
        """获取用于 span 的属性"""
        attributes = super().get_span_attributes()
        return attributes