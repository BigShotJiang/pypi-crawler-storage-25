# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
GenAI Telemetry Options

定义了 GenAI Telemetry 的配置项
"""

from dataclasses import dataclass
import os

OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT = "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"
OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_MAX_LENGTH = "OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_MAX_LENGTH"
OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_CAPTURE_STRATEGY = "OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_CAPTURE_STRATEGY"

DEFAULT_OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT = "true"
DEFAULT_OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_MAX_LENGTH = "8192"
DEFAULT_OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_CAPTURE_STRATEGY = "span-attributes"

class _CommonTruncateTool:
    """通用截断工具"""
    capture_message_content_max_length: int = None

    def __init__(
            self,
            capture_message_content_max_length: int
    ):
        self.capture_message_content_max_length = capture_message_content_max_length

    def truncate_content(self, content: str) -> str:
        return content[:self.capture_message_content_max_length] + "...[truncated]"

    def should_truncate(self, content: str) -> bool:
        return ((content is not None)
                and (len(content) > self.capture_message_content_max_length)
                and (not content.endswith("...[truncated]")))

@dataclass
class GenAITelemetryOptions:
    """遥测配置选项"""
    capture_message_content: bool = None
    capture_message_content_max_length: int = None
    message_mode: str = None
    truncate_tool: _CommonTruncateTool = None
    
    def __post_init__(self):
        """初始化后处理，设置默认值"""
        if self.capture_message_content is None:
            self.capture_message_content = os.getenv(OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT, DEFAULT_OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT).lower() == "true"
        
        if self.capture_message_content_max_length is None:
            self.capture_message_content_max_length = int(os.getenv(OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_MAX_LENGTH, DEFAULT_OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_MAX_LENGTH))
        
        if self.message_mode is None:
            env_value = os.getenv(OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_CAPTURE_STRATEGY, DEFAULT_OTEL_INSTRUMENTATION_GENAI_MESSAGE_CONTENT_CAPTURE_STRATEGY)
            # 将 "span" 映射到 "span-attributes" 以保持向后兼容性
            if env_value == "span":
                self.message_mode = "span-attributes"
            else:
                self.message_mode = env_value
        else:
            # 如果构造函数参数是 "span"，也映射到 "span-attributes"
            if self.message_mode == "span":
                self.message_mode = "span-attributes"

        self.truncate_tool = _CommonTruncateTool(self.capture_message_content_max_length)
    
    def should_capture_content(self) -> bool:
        """是否应该捕获内容"""
        return self.capture_message_content

    def truncate_content(self, content: str) -> str:
        """截断内容到指定长度"""
        if not content:
            return content
        if len(content) > self.capture_message_content_max_length:
            return content[:self.capture_message_content_max_length] + "...[truncated]"
        return content
    
    def should_use_events(self) -> bool:
        """是否应该使用事件模式"""
        return self.message_mode.lower() == "event"