import time
from contextlib import contextmanager
from typing import Any, Iterable, Iterator, Mapping, Optional, Dict

from opentelemetry.trace import Span

from .messages import (
    InputMessages,
    ChatMessage,
    TextPart,
    ToolCallRequestPart,
    ToolCallResponsePart,
    GenericPart
)

from sdk.semconv.trace import (
    SpanAttributes,
    VSpanAttributes,
)

from ctyun.opentelemetry.sdk.util.genai.data import (
    LLMRequestAttributes,
)

from sdk.util.genai.constants import CastTo
from opentelemetry import trace as trace_api
from sdk.util.genai.with_span import WithSpan
from sdk.util.genai.response import HasAttributes
from sdk.semconv.trace_v2 import (
    LLMAttributes,
)

from sdk.extension.arms.logger import getLogger
logger = getLogger(__name__)

def _get_llm_request_attributes(
    operation_name: str,
    span_attributes: dict[str, Any],
) -> LLMRequestAttributes:
    remaining_span_attrs = span_attributes.copy()
    if SpanAttributes.GEN_AI_REQUEST_MODEL_NAME in span_attributes:
        model = span_attributes.get(SpanAttributes.GEN_AI_REQUEST_MODEL_NAME)
        del remaining_span_attrs[SpanAttributes.GEN_AI_REQUEST_MODEL_NAME]
    else:
        model = "unknown"

    if VSpanAttributes.GEN_AI_REQUEST_N in span_attributes:
        request_choice_count = span_attributes.get(VSpanAttributes.GEN_AI_REQUEST_N)
        del remaining_span_attrs[VSpanAttributes.GEN_AI_REQUEST_N]
    else:
        request_choice_count = None

    if VSpanAttributes.GEN_AI_REQUEST_MAX_TOKENS in span_attributes:
        max_tokens = span_attributes.get(VSpanAttributes.GEN_AI_REQUEST_MAX_TOKENS)
        del remaining_span_attrs[VSpanAttributes.GEN_AI_REQUEST_MAX_TOKENS]
    elif SpanAttributes.GEN_AI_REQUEST_MAX_TOKENS in span_attributes:
        max_tokens = span_attributes.get(SpanAttributes.GEN_AI_REQUEST_MAX_TOKENS)
        del remaining_span_attrs[SpanAttributes.GEN_AI_REQUEST_MAX_TOKENS]
    else:
        max_tokens = None

    if VSpanAttributes.GEN_AI_REQUEST_TOP_P in span_attributes:
        top_p = span_attributes.get(VSpanAttributes.GEN_AI_REQUEST_TOP_P)
        del remaining_span_attrs[VSpanAttributes.GEN_AI_REQUEST_TOP_P]
    elif SpanAttributes.GEN_AI_REQUEST_TOP_P in span_attributes:
        top_p = span_attributes.get(SpanAttributes.GEN_AI_REQUEST_TOP_P)
        del remaining_span_attrs[SpanAttributes.GEN_AI_REQUEST_TOP_P]
    else:
        top_p = None

    if LLMAttributes.GEN_AI_REQUEST_TOP_K in span_attributes:
        top_k = span_attributes.get(LLMAttributes.GEN_AI_REQUEST_TOP_K)
        del remaining_span_attrs[LLMAttributes.GEN_AI_REQUEST_TOP_K]
    else:
        top_k = None

    if VSpanAttributes.GEN_AI_REQUEST_TEMPERATURE in span_attributes:
        temperature = span_attributes.get(VSpanAttributes.GEN_AI_REQUEST_TEMPERATURE)
        del remaining_span_attrs[VSpanAttributes.GEN_AI_REQUEST_TEMPERATURE]
    elif SpanAttributes.GEN_AI_REQUEST_TEMPERATURE in span_attributes:
        temperature = span_attributes.get(SpanAttributes.GEN_AI_REQUEST_TEMPERATURE)
        del remaining_span_attrs[SpanAttributes.GEN_AI_REQUEST_TEMPERATURE]
    else:
        temperature = None

    llm_request_attributes = LLMRequestAttributes(
        operation_name=operation_name,
        provider_name=None, # TODO
        request_model=model,
        request_choice_count=request_choice_count,
        request_seed=None, # TODO
        request_frequency_penalty=None, # TODO
        request_presence_penalty=None, # TODO
        request_max_tokens=max_tokens,
        request_top_p=top_p,
        request_top_k=top_k,
        request_temperature=temperature,
        request_stop_sequences=None, # TODO
    )
    return llm_request_attributes, remaining_span_attrs

def _get_input_messages(
        cast_to: CastTo,
        raw_input_messages
) -> InputMessages:
    """从请求参数获取 InputMessages"""
    input_messages = InputMessages()
    if raw_input_messages is None:
        return input_messages

    if cast_to is CastTo.ChatCompletion:
        if isinstance(raw_input_messages, Iterable):
            for raw_message in raw_input_messages:
                for chat_message in get_attributes_from_chat_completion_message_param(raw_message):
                    input_messages.add_message(chat_message)
    elif cast_to is CastTo.Completion:
        if isinstance(raw_input_messages, str):
            for chat_message in get_attributes_from_completion_message_param(raw_input_messages):
                input_messages.add_message(chat_message)
        elif isinstance(raw_input_messages, Iterable):
            for raw_message in raw_input_messages:
                for chat_message in get_attributes_from_completion_message_param(raw_message):
                    input_messages.add_message(chat_message)

    return input_messages

def get_attributes_from_completion_message_param(
    raw_message: Any,
) -> Iterator[ChatMessage]:
    if isinstance(raw_message, str):
        yield ChatMessage(role="user", parts=[TextPart(content=raw_message)])
    elif all(isinstance(item, str) for item in raw_message):
        for content_item in raw_message:
            yield ChatMessage(role="user", parts=[TextPart(content=content_item)])
    else:
        logger.info("Unsupported completion message type: %s", type(raw_message))

def get_attributes_from_chat_completion_message_param(
    raw_message: Mapping[str, Any],
) -> Iterator[ChatMessage]:
    # openai.types.chat.ChatCompletionMessageParam
    # See https://github.com/openai/openai-python/blob/f1c7d714914e3321ca2e72839fe2d132a8646e7f/src/openai/types/chat/chat_completion_message_param.py#L15  # noqa: E501
    if not hasattr(raw_message, "get"):
        return

    role = raw_message.get("role", "")
    content = raw_message.get("content", "")

    if role == "tool" or role == "function":
        tool_response_part = ToolCallResponsePart(
            id=raw_message.get("tool_call_id"),
            response=content
        )
        if isinstance(content, str):
            tool_response_part.response = content
        elif isinstance(content, list):
            response_list = []
            for content_item in content:
                response_list.append((content_item.get("text", ""), content_item.get("type", "text")))
            tool_response_part.response = response_list

        tool_message = ChatMessage(role=role, parts=[tool_response_part])
        yield tool_message

    else:
        parts = []
        # append function parts(deprecated)
        if "function_call" in raw_message and raw_message.get("function_call"):
            parts.append(ToolCallRequestPart(
                name=raw_message.get("function_call").get("name", ""),
                arguments=raw_message.get("function_call").get("arguments", "")
            ))

        # append tool parts
        if "tool_calls" in raw_message and raw_message.get("tool_calls"):
            for tool_call in raw_message.get("tool_calls"):
                if isinstance(tool_call, dict) and tool_call.get("function"):
                    parts.append(ToolCallRequestPart(
                        name=tool_call.get("function").get("name", ""),
                        id=tool_call.get("id"),
                        arguments=tool_call.get("function").get("arguments", "")
                    ))
                elif isinstance(tool_call, dict) and tool_call.get("custom"):
                    parts.append(ToolCallRequestPart(
                        name=tool_call.get("custom").get("name", ""),
                        id=tool_call.get("id"),
                        arguments=tool_call.get("custom").get("input", "")
                    ))

        # append content parts
        if isinstance(content, str):
            parts.append(TextPart(content=content))
        elif isinstance(content, list):
            for content_item in content:
                if isinstance(content_item, dict):
                    content_type = content_item.get("type", "text")
                    if content_type == "text":
                        parts.append(TextPart(content=content_item.get("text", "")))
                    elif content_type == "image_url":
                        image_part = GenericPart(type=content_type)
                        if (content_item.get("image_url") is not None
                                and isinstance(content_item.get("image_url"), dict)):
                            image_part.image_url = {
                                "url": content_item.get("image_url").get("url"),
                                "detail": content_item.get("image_url").get("detail"),
                            }
                        parts.append(image_part)
                    else:
                        # TODO support the collection of multimodal content
                        multimodal_part = GenericPart(type=content_type)
                        multimodal_part.hint = "unsupported content type"
                        parts.append(multimodal_part)
                elif isinstance(content_item, str):
                    parts.append(TextPart(content=content_item))

            if not parts:
                parts.append(TextPart(content=""))

        complex_message = ChatMessage(role=role, parts=parts)
        yield complex_message

def finish_tracing(
        cast_to: CastTo,
        with_span: WithSpan,
        has_attributes: Optional[HasAttributes] = None,
        status: Optional[trace_api.Status] = None,
        extra_response_attrs: Mapping[str, Any] = None,
) -> None:
    if has_attributes is None:
        try:
            with_span.finish_tracing(
                status=status,
                response_attributes=None,
                output_messages=None,
            )
        except Exception as e:
            logger.info(f"Failed to finish tracing: {e}")
        return

    try:
        response_attributes = has_attributes.get_response_attributes()
    except Exception as e:
        logger.info(f"Failed to get response attributes: {e}")
        response_attributes = None

    try:
        messages = has_attributes.get_output_messages(cast_to)
    except Exception as e:
        logger.info(f"Failed to get output messages: {e}")
        messages = None

    try:
        with_span.finish_tracing(
            status=status,
            response_attributes=response_attributes,
            output_messages=messages,
            extra_response_attrs=extra_response_attrs
        )
    except Exception as e:
        logger.info(f"Failed to finish tracing: {e}")

@contextmanager
def start_as_current_span(genai_telemetry, cast_to: CastTo, operation_name: str, span_attributes: Dict[str, Any]) -> Iterator[WithSpan]:
    start_time_utc_nano = time.time_ns()
    request_attrs, remaining_span_attrs = _get_llm_request_attributes(operation_name, span_attributes)
    if SpanAttributes.INPUT_VALUE in remaining_span_attrs:
        raw_input = remaining_span_attrs[SpanAttributes.INPUT_VALUE]
    else:
        raw_input = None
    input_messages = _get_input_messages(cast_to, raw_input)
    span = genai_telemetry.create_llm_span(request_attrs)
    with trace_api.use_span(span, end_on_exit=False) as span:
        genai_telemetry.set_llm_start_attributes(span, request_attrs, input_messages, tool_definitions=None)
        _set_extra_span_attributes(span, remaining_span_attrs)
        yield WithSpan(
            span=span,
            extra_attributes={},
            start_time_utc_nano=start_time_utc_nano,
            genai_telemetry=genai_telemetry,
            request_attributes=request_attrs,
            input_messages=input_messages,
            tool_definitions=None,
        )

def _set_extra_span_attributes(span: Span, span_attributes: dict[str, Any]):
    if len(span_attributes) > 0 and hasattr(span, 'set_attribute'):
        for key, value in span_attributes.items():
            if key != SpanAttributes.INPUT_VALUE and key != SpanAttributes.GEN_AI_PROMPT:
                span.set_attribute(key, value)