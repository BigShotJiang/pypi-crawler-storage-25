# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
GenAI 消息结构定义

定义了用于生成式 AI 应用的标准化输入输出数据结构。
这些数据类型遵循阿里云扩展的语义约定。
"""

import dataclasses
import json
from dataclasses import dataclass, is_dataclass
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Protocol, Union

# 从 types.py 导入统一的多模态类型
from .types import Blob, Uri, Base64Blob


class _ContentTruncateTool(Protocol):
    """内容截断工具协议"""

    def truncate_content(self, content: str) -> str: ...
    def should_truncate(self, content: str) -> bool: ...


class Role(Enum):
    """消息角色枚举"""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"

class FinishReason(Enum):
    """生成结束原因枚举"""
    STOP = "stop"
    LENGTH = "length"
    CONTENT_FILTER = "content_filter"
    TOOL_CALL = "tool_call"
    ERROR = "error"


@dataclass
class TextPart:
    """文本内容部分"""
    type: str = "text"
    content: str = ""
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        content = self.content
        if truncate_tool and truncate_tool.should_truncate(content):
            content = truncate_tool.truncate_content(content)
        return {
            "type": self.type,
            "content": content
        }

@dataclass
class ToolCallRequestPart:
    """工具调用请求部分"""
    type: str = "tool_call"
    name: str = ""
    id: Optional[str] = None
    arguments: Optional[Union[Any, str]] = None
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        result = {
            "type": self.type,
            "name": self.name
        }
        if self.id is not None:
            result["id"] = self.id
        if self.arguments is not None:
            if isinstance(self.arguments, str):
                arguments = self.arguments
                if truncate_tool and truncate_tool.should_truncate(arguments):
                    result["arguments"] = truncate_tool.truncate_content(arguments)
                else:
                    try:
                        result["arguments"] = json.loads(arguments)
                    except (json.JSONDecodeError, ValueError):
                        result["arguments"] = arguments
            else:
                # 不支持 truncate
                result["arguments"] = self.arguments
        return result

@dataclass
class ToolCallResponsePart:
    """工具调用响应部分"""
    type: str = "tool_call_response"
    response: Optional[Union[Any, str]] = None
    id: Optional[str] = None
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        result = {"type": self.type}
        if self.response is not None:
            if isinstance(self.response, str):
                response = self.response
                if truncate_tool and truncate_tool.should_truncate(response):
                    result["response"] = truncate_tool.truncate_content(response)
                else:
                    try:
                        result["response"] = json.loads(response)
                    except (json.JSONDecodeError, ValueError):
                        result["response"] = response
            else:
                # 不支持 truncate
                result["response"] = self.response
        if self.id is not None:
            result["id"] = self.id
        return result

@dataclass
class GenericPart:
    """通用消息部分，用于扩展"""
    type: str = ""
    
    def __init__(self, type: str, **kwargs):
        self.type = type
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        result = {"type": self.type}
        for key, value in self.__dict__.items():
            if key != "type":
                result[key] = value
        return result




MessagePart = Union[TextPart, ToolCallRequestPart, ToolCallResponsePart, GenericPart, Blob, Uri, Base64Blob]

def to_serializable_object(message: MessagePart, truncate_tool: Optional[_ContentTruncateTool] = None) -> Dict[str, Any]:
    if hasattr(message, "to_serializable_object"):
        return message.to_serializable_object(truncate_tool)
    elif dataclasses.is_dataclass(message):
        dict = dataclasses.asdict(message)
        if truncate_tool:
            for key, value in dict.items():
                if truncate_tool.should_truncate(value):
                    if key in ("content", "uri"):
                        dict[key] = "[truncated]"
                    else:
                        dict[key] = value
        return dict
    else:
        return {"type": type(message).__name__, "content": "[unsupported]"}

@dataclass
class ChatMessage:
    """聊天消息"""
    role: Union[Role, str]
    parts: List[MessagePart]
    
    def __post_init__(self):
        # 确保 role 是字符串类型
        if isinstance(self.role, Role):
            self.role = self.role.value
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        return {
            "role": isinstance(self.role, Role) and self.role.value or self.role,
            "parts": [to_serializable_object(part, truncate_tool) for part in self.parts]
        }

@dataclass
class OutputMessage:
    """输出消息"""
    role: Union[Role, str]
    parts: List[MessagePart]
    finish_reason: Union[FinishReason, str]
    
    def __post_init__(self):
        if isinstance(self.role, Role):
            self.role = self.role.value
        if isinstance(self.finish_reason, FinishReason):
            self.finish_reason = self.finish_reason.value
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        return {
            "role": isinstance(self.role, Role) and self.role.value or self.role,
            "parts": [to_serializable_object(part, truncate_tool) for part in self.parts],
            "finish_reason": isinstance(self.finish_reason, FinishReason) and self.finish_reason.value or self.finish_reason
        }

class InputMessages:
    """输入消息列表"""
    
    def __init__(self, messages: Optional[List[ChatMessage]] = None):
        self.messages = messages or []
    
    def add_message(self, message: ChatMessage):
        """添加消息"""
        self.messages.append(message)
    
    def add_text_message(self, role: Union[Role, str], content: str):
        """添加文本消息"""
        text_part = TextPart(content=content)
        message = ChatMessage(role=role, parts=[text_part])
        self.add_message(message)
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> List[Dict[str, Any]]:
        """转换为可序列化的对象"""
        return [to_serializable_object(message, truncate_tool) for message in self.messages]

class OutputMessages:
    """输出消息列表"""
    
    def __init__(self, messages: Optional[List[OutputMessage]] = None):
        self.messages = messages or []
    
    def add_message(self, message: OutputMessage):
        """添加消息"""
        self.messages.append(message)
    
    def add_text_message(self, role: Union[Role, str], content: str, 
                        finish_reason: Union[FinishReason, str] = FinishReason.STOP):
        """添加文本消息"""
        text_part = TextPart(content=content)
        message = OutputMessage(role=role, parts=[text_part], finish_reason=finish_reason)
        self.add_message(message)
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> List[Dict[str, Any]]:
        """转换为可序列化的对象"""
        return [message.to_serializable_object(truncate_tool) for message in self.messages]

class SystemInstructions:
    """系统指令列表"""
    
    def __init__(self, parts: Optional[List[MessagePart]] = None):
        self.parts = parts or []
    
    def add_part(self, part: MessagePart):
        """添加部分"""
        self.parts.append(part)
    
    def add_text_instruction(self, content: str):
        """添加文本指令"""
        text_part = TextPart(content=content)
        self.add_part(text_part)
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> List[Dict[str, Any]]:
        """转换为可序列化的对象"""
        return [part.to_serializable_object(truncate_tool) for part in self.parts]

class ToolType(Enum):
    """工具类型枚举"""
    FUNCTION = "function"
    CUSTOM = "custom"

@dataclass
class ToolDefinition:
    """工具定义"""
    type: Union[ToolType, str]
    name: str
    description: str
    
    def __post_init__(self):
        # 确保 type 是字符串类型
        if isinstance(self.type, ToolType):
            self.type = self.type.value
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        description = self.description
        if truncate_tool and truncate_tool.should_truncate(description):
            description = truncate_tool.truncate_content(description)
        return {
            "type": isinstance(self.type, ToolType) and self.type.value or self.type,
            "name": self.name,
            "description": description
        }

class ToolDefinitions:
    """工具定义列表"""
    
    def __init__(self, definitions: Optional[List[ToolDefinition]] = None):
        self.definitions = definitions or []
    
    def add_definition(self, definition: ToolDefinition):
        """添加工具定义"""
        self.definitions.append(definition)
    
    def to_serializable_object(
            self,
            truncate_tool: Optional[_ContentTruncateTool] = None
    ) -> List[Dict[str, Any]]:
        """转换为可序列化的对象"""
        return [definition.to_serializable_object(truncate_tool) for definition in self.definitions]

@dataclass
class Document:
    """文档"""
    content: str
    metadata: Optional[Dict[str, Any]] = None

    def to_serializable_object(self, truncate_content_func=None) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        result = {
            "content": truncate_content_func(self.content) if truncate_content_func else self.content
        }
        if self.metadata:
            result["metadata"] = self.metadata
        return result

@dataclass
class RankedDocument:
    """带排序信息的文档"""
    content: str
    score: Optional[float] = None
    rank: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None

    def to_serializable_object(self, truncate_content_func=None) -> Dict[str, Any]:
        """转换为可序列化的对象"""
        result = {
            "content": truncate_content_func(self.content) if truncate_content_func else self.content
        }
        if self.score is not None:
            result["score"] = self.score
        if self.rank is not None:
            result["rank"] = self.rank
        if self.metadata:
            result["metadata"] = self.metadata
        return result

class InputDocuments:
    """输入文档列表"""

    def __init__(self, documents: Optional[List[Document]] = None):
        self.documents = documents or []

    def add_document(self, document: Document):
        """添加文档"""
        self.documents.append(document)

    def add_text_document(self, content: str, metadata: Optional[Dict[str, Any]] = None):
        """添加文本文档"""
        document = Document(content=content, metadata=metadata)
        self.add_document(document)

    def to_serializable_object(self, truncate_content_func=None) -> List[Dict[str, Any]]:
        """转换为可序列化的对象"""
        return [doc.to_serializable_object(truncate_content_func) for doc in self.documents]

class OutputDocuments:
    """输出文档列表（带排序信息）"""

    def __init__(self, documents: Optional[List[RankedDocument]] = None):
        self.documents = documents or []

    def add_document(self, document: RankedDocument):
        """添加文档"""
        self.documents.append(document)

    def add_ranked_document(
        self,
        content: str,
        score: Optional[float] = None,
        rank: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """添加排序文档"""
        document = RankedDocument(content=content, score=score, rank=rank, metadata=metadata)
        self.add_document(document)

    def to_serializable_object(self, truncate_content_func=None) -> List[Dict[str, Any]]:
        """转换为可序列化的对象"""
        return [doc.to_serializable_object(truncate_content_func) for doc in self.documents]
