from typing import Protocol, Optional, Any, Mapping, Iterable
from .data import (
    LLMResponseAttributes,
)
from .constants import CastTo
from .messages import OutputMessages

from sdk.extension.arms.logger import getLogger
logger = getLogger(__name__)

class HasAttributes(Protocol):
    def get_response_attributes(self) -> Optional[LLMResponseAttributes]: ...
    def get_output_messages(self, cast_to: CastTo) -> Optional[OutputMessages]: ...

class SimpleChoice:
    def __init__(self, index, text, finish_reason, role=None):
        self.index = index
        self.text = text
        self.finish_reason = finish_reason
        self.role = role

class SimpleUsage:
    def __init__(self, prompt_tokens, completion_tokens):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens

class SimpleResponse:
    def __init__(self):
        self.choices = []
        self.usage = None
        self.id = None
        self.model = None

    def add_choice(self, choice: SimpleChoice):
        self.choices.append(choice)

    def set_usages(self, usage: SimpleUsage):
        self.usage = usage

    def set_id(self, id: str):
        self.id = id

    def set_model(self, model):
        self.model = model

class ResponseAttributes:
    def __init__(
            self,
            response: Any,
            span_attributes: Mapping[str, Any],
    ) -> None:
        if hasattr(response, "parse") and callable(response.parse):
            # E.g. see https://github.com/openai/openai-python/blob/f1c7d714914e3321ca2e72839fe2d132a8646e7f/src/openai/_base_client.py#L518  # noqa: E501
            try:
                response = response.parse()
            except Exception as e:
                logger.info(f"Failed to parse response of type {type(response)}: {e}")
        self._span_attributes = span_attributes
        self._response = response

    def get_response_attributes(self) -> Optional[LLMResponseAttributes]:
        """返回响应属性（根据 span 类型返回相应的类型）"""
        response_id = getattr(self._response, "id", None)

        response_model = getattr(self._response, "model", None)

        response_finish_reasons = []
        if hasattr(self._response, "choices") and isinstance(self._response.choices, Iterable):
            for choice in self._response.choices:
                if hasattr(choice, "finish_reason") and choice.finish_reason:
                    response_finish_reasons.append(choice.finish_reason)

        usage_input_tokens = None
        usage_output_tokens = None
        if hasattr(self._response, "usage") and self._response.usage:
            usage_input_tokens = getattr(self._response.usage, "prompt_tokens", None)
            usage_output_tokens = getattr(self._response.usage, "completion_tokens", None)

        return LLMResponseAttributes(
            response_id=response_id,
            response_model=response_model,
            response_finish_reasons=response_finish_reasons if response_finish_reasons else None,
            usage_input_tokens=usage_input_tokens,
            usage_output_tokens=usage_output_tokens,
        )

    def get_output_messages(self, cast_to: CastTo) -> Optional[OutputMessages]:
        """从响应对象获取 OutputMessages"""
        output_messages = OutputMessages()

        if cast_to == CastTo.ChatCompletion:
            if hasattr(self._response, "choices") and isinstance(self._response.choices, Iterable):
                for choice in self._response.choices:
                    if hasattr(choice, "message") and choice.message:
                        message = choice.message
                        role = getattr(message, "role", "assistant")
                        content = getattr(message, "content", "")
                        finish_reason = getattr(choice, "finish_reason", None)
                        output_messages.add_text_message(role, content, finish_reason)
                    elif hasattr(choice, "text"):
                        text = choice.text
                        finish_reason = getattr(choice, "finish_reason", None)
                        output_messages.add_text_message("assistant", text, finish_reason)

        elif cast_to == CastTo.Completion:
            if hasattr(self._response, "choices") and isinstance(self._response.choices, Iterable):
                for choice in self._response.choices:
                    if hasattr(choice, "text"):
                        text = choice.text
                        finish_reason = getattr(choice, "finish_reason", None)
                        output_messages.add_text_message("assistant", text, finish_reason)

        return output_messages
