from enum import Enum

class CastTo(Enum):
    Completion = 1
    ChatCompletion = 2
