from opentelemetry.trace import Span
from sdk.extension.arms.logger import getLogger
from typing import Optional, Union, Mapping, Any
from sdk.semconv.trace_v2 import CommonAttributes, LLMAttributes

from opentelemetry import trace as trace_api
from opentelemetry.util.types import Attributes
from sdk.semconv.trace import SpanAttributes, LLMSpanKindValues
from sdk.util.genai.api import LLMResponseAttributes, EmbeddingResponseAttributes, OutputMessages
from opentelemetry.trace import Status

logger = getLogger(__name__)

class WithSpan:
    __slots__ = (
        "_span",
        "_extra_attributes",
        "_is_finished",
        "_start_time_utc_nano",
        "_genai_telemetry",
        "_request_attributes",
        "_input_messages",
        "_tool_definitions",
    )

    def __init__(
        self,
        span: trace_api.Span,
        extra_attributes: Attributes = None,
        start_time_utc_nano: int = None,
        genai_telemetry=None,
        request_attributes=None,
        input_messages=None,
        tool_definitions=None,
    ) -> None:
        self._span = span
        self._extra_attributes = extra_attributes
        self._start_time_utc_nano = start_time_utc_nano
        self._genai_telemetry = genai_telemetry
        self._request_attributes = request_attributes
        self._input_messages = input_messages
        self._tool_definitions = tool_definitions
        try:
            self._is_finished = not self._span.is_recording()
        except Exception as e:
            logger.info(f"Failed to check if span is recording: {e}")
            self._is_finished = True

    @property
    def is_finished(self) -> bool:
        return self._is_finished

    @property
    def span(self) -> Span:
        return self._span

    def set_status(self, status: Status) -> None:
        if self._is_finished:
            return
        try:
            self._span.set_status(status)
        except Exception as e:
            logger.info(f"Failed to set status for span: {e}")

    def record_exception(self, exception: Exception) -> None:
        if self._is_finished:
            return
        try:
            self._span.record_exception(exception)
        except Exception as e:
            logger.info(f"Failed to record exception on span: {e}")

    def add_event(self, name: str) -> None:
        if self._is_finished:
            return
        try:
            if hasattr(self._span, 'add_event'):
                self._span.add_event(name)
        except Exception as e:
            logger.info(f"Failed to add event to span: {e}")

    def get_span_attribute(self, attribute_name, default_value=""):
        if hasattr(self._span, 'get_attribute'):
            return self._span.get_attribute(attribute_name) or default_value
        return default_value

    def finish_tracing(
        self,
        status: Optional[trace_api.Status] = None,
        response_attributes: Optional[Union[LLMResponseAttributes, EmbeddingResponseAttributes]] = None,
        output_messages: Optional[OutputMessages] = None,
        extra_response_attrs: Mapping[str, Any] = None
    ) -> None:
        if self._is_finished:
            return

        if response_attributes is not None:
            try:
                if isinstance(response_attributes, LLMResponseAttributes):
                    self._genai_telemetry.set_llm_end_attributes(
                                self._span,
                                self._request_attributes,
                                self._input_messages,
                                response_attributes,
                                output_messages,
                                tool_definitions=self._tool_definitions,
                            )
                elif isinstance(response_attributes, EmbeddingResponseAttributes):
                    self._genai_telemetry.set_embedding_end_attributes(
                        self._span,
                        self._request_attributes,
                        response_attributes
                    )
            except Exception as e:
                logger.info(f"Failed to set end attributes with GenAITelemetry: {e}")

        if extra_response_attrs is not None and hasattr(self._span, 'set_attribute'):
            for key, value in extra_response_attrs.items():
                self._span.set_attribute(key, value)

        if status is not None:
            try:
                self._span.set_status(status=status)
            except Exception as e:
                logger.info(f"Failed to set status code on span: {e}")
        try:
            self._span.end()
        except Exception as e:
            logger.info(f"Failed to end span: {e}")
        self._is_finished = True
