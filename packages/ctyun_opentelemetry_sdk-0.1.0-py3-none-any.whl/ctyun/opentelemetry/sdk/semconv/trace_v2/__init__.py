from enum import Enum

"""
阿里云语义约定 - Trace V2

这是新版本的 trace 语义约定定义，包含了完整的 GenAI 相关属性。
"""

class GenAiSpanKind(Enum):
    """大模型 span kind 枚举"""
    # ARMS 扩展属性
    CHAIN = "CHAIN"
    RETRIEVER = "RETRIEVER"
    RERANKER = "RERANKER"
    LLM = "LLM"
    EMBEDDING = "EMBEDDING"
    TOOL = "TOOL"
    AGENT = "AGENT"
    TASK = "TASK"

class GenAiOperationName(Enum):
    """操作二级类型枚举"""
    CHAT = "chat"
    CREATE_AGENT = "create_agent"
    EMBEDDINGS = "embeddings"
    EXECUTE_TOOL = "execute_tool"
    GENERATE_CONTENT = "generate_content"
    INVOKE_AGENT = "invoke_agent"
    TEXT_COMPLETION = "text_completion"

class GenAiOutputType(Enum):
    """LLM 输出类型枚举"""
    TEXT = "text"
    JSON = "json"
    IMAGE = "image"
    SPEECH = "speech"

class GenAiToolType(Enum):
    """工具类型枚举"""
    FUNCTION = "function"
    EXTENSION = "extension"
    DATASTORE = "datastore"

class CommonAttributes:
    """公共属性字段"""
    # 操作相关
    GEN_AI_OPERATION_NAME = "gen_ai.operation.name"

    # ARMS 扩展属性
    # 会话相关
    GEN_AI_SESSION_ID = "gen_ai.session.id"
    GEN_AI_USER_ID = "gen_ai.user.id"
    GEN_AI_USER_NAME = "gen_ai.user.name"
    GEN_AI_SPAN_KIND = "gen_ai.span.kind"
    GEN_AI_FRAMEWORK = "gen_ai.framework"
    
    # ARMS 扩展属性
    # 输入输出
    INPUT_VALUE = "input.value"
    OUTPUT_VALUE = "output.value"
    INPUT_MIME_TYPE = "input.mime_type"
    OUTPUT_MIME_TYPE = "output.mime_type"
    
    # ARMS 扩展属性
    # 时间相关
    GEN_AI_USER_TIME_TO_FIRST_TOKEN = "gen_ai.user.time_to_first_token"
    GEN_AI_RESPONSE_REASONING_TIME = "gen_ai.response.reasoning_time"
    
class LLMAttributes:
    """LLM 相关属性字段"""
    # 模型相关
    GEN_AI_PROVIDER_NAME = "gen_ai.provider.name"
    GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
    GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"
    # ARMS 扩展属性
    GEN_AI_MODEL_NAME = "gen_ai.model_name"  # 考虑废弃
    
    # 对话相关
    GEN_AI_CONVERSATION_ID = "gen_ai.conversation.id"
    GEN_AI_OUTPUT_TYPE = "gen_ai.output.type"
    
    # 请求参数
    GEN_AI_REQUEST_CHOICE_COUNT = "gen_ai.request.choice.count"
    GEN_AI_REQUEST_SEED = "gen_ai.request.seed"
    GEN_AI_REQUEST_FREQUENCY_PENALTY = "gen_ai.request.frequency_penalty"
    GEN_AI_REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
    GEN_AI_REQUEST_PRESENCE_PENALTY = "gen_ai.request.presence_penalty"
    GEN_AI_REQUEST_TEMPERATURE = "gen_ai.request.temperature"
    GEN_AI_REQUEST_TOP_P = "gen_ai.request.top_p"
    GEN_AI_REQUEST_TOP_K = "gen_ai.request.top_k"
    GEN_AI_REQUEST_STOP_SEQUENCES = "gen_ai.request.stop_sequences"
    # ARMS 扩展属性
    GEN_AI_REQUEST_IS_STREAM = "gen_ai.request.is_stream"
    GEN_AI_REQUEST_PARAMETERS = "gen_ai.request.parameters"  # 考虑废弃
    
    # 响应相关
    GEN_AI_RESPONSE_ID = "gen_ai.response.id"
    GEN_AI_RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"
    # ARMS 扩展属性
    GEN_AI_RESPONSE_TIME_TO_FIRST_TOKEN = "gen_ai.response.time_to_first_token"
    GEN_AI_RESPONSE_TIME_PER_OUTPUT_TOKEN = "gen_ai.response.time_per_output_token"
    GEN_AI_RESPONSE_REASONING_CONTENT = "gen_ai.response.reasoning_content" # 考虑废弃
    
    # Token 使用统计
    GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    # ARMS 扩展属性
    GEN_AI_USAGE_TOTAL_TOKENS = "gen_ai.usage.total_tokens"
    
    # 消息内容
    GEN_AI_INPUT_MESSAGES = "gen_ai.input.messages"
    GEN_AI_OUTPUT_MESSAGES = "gen_ai.output.messages"
    GEN_AI_SYSTEM_INSTRUCTIONS = "gen_ai.system_instructions"
    GEN_AI_TOOL_DEFINITIONS = "gen_ai.tool.definitions"
    # OTel 暂未透出属性
    GEN_AI_INPUT_MESSAGES_REF = "gen_ai.input.messages_ref"
    GEN_AI_OUTPUT_MESSAGES_REF = "gen_ai.output.messages_ref"
    GEN_AI_SYSTEM_INSTRUCTIONS_REF = "gen_ai.system_instructions_ref"
    
    # 多模态资源（ARMS 扩展属性，用于 SLS 向量索引）
    GEN_AI_INPUT_MULTIMODAL_METADATA = "gen_ai.input.multimodal_metadata"
    GEN_AI_OUTPUT_MULTIMODAL_METADATA = "gen_ai.output.multimodal_metadata"
    
    # 延迟相关（扩展规范）
    # ARMS 扩展属性
    GEN_AI_LATENCY_TIME_IN_MODEL_PREFILL = "gen_ai.latency.time_in_model_prefill"
    GEN_AI_LATENCY_TIME_IN_MODEL_DECODE = "gen_ai.latency.time_in_model_decode"
    GEN_AI_LATENCY_TIME_IN_MODEL_INFERENCE = "gen_ai.latency.time_in_model_inference"

    # ARMS 扩展属性
    # 提示词模板相关（考虑废弃）
    GEN_AI_PROMPT_TEMPLATE_TEMPLATE = "gen_ai.prompt_template.template"
    GEN_AI_PROMPT_TEMPLATE_VARIABLES = "gen_ai.prompt_template.variables"
    GEN_AI_PROMPT_TEMPLATE_VERSION = "gen_ai.prompt_template.version"

class RetrieverAttributes:
    """Retriever 相关属性字段"""
    # ARMS 扩展属性
    RETRIEVAL_QUERY = "retrieval.query"
    RETRIEVAL_DOCUMENT = "retrieval.document"

class RerankerAttributes:
    """Reranker 相关属性字段"""
    # ARMS 扩展属性
    RERANKER_QUERY = "reranker.query"
    RERANKER_MODEL_NAME = "reranker.model_name"
    RERANKER_TOP_K = "reranker.top_k"
    RERANKER_INPUT_DOCUMENT = "reranker.input_document"
    RERANKER_OUTPUT_DOCUMENT = "reranker.output_document"

class EmbeddingAttributes:
    """Embedding 相关属性字段"""
    GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
    GEN_AI_EMBEDDINGS_DIMENSION_COUNT = "gen_ai.embeddings.dimension.count"
    GEN_AI_REQUEST_ENCODING_FORMATS = "gen_ai.request.encoding_formats"

    GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"

    # GenAI 中尚不存在该规范，但比较重要
    GEN_AI_REQUEST_TEMPERATURE = "gen_ai.request.temperature"

    # ARMS 扩展属性
    EMBEDDING_MODEL_NAME = "embedding.model_name" # 考虑废弃
    EMBEDDING_EMBEDDING_OUTPUT = "embedding.embedding_output" # 考虑废弃

class ToolAttributes:
    """Tool 相关属性字段"""
    GEN_AI_TOOL_CALL_ID = "gen_ai.tool.call.id"
    GEN_AI_TOOL_DESCRIPTION = "gen_ai.tool.description"
    GEN_AI_TOOL_NAME = "gen_ai.tool.name"
    GEN_AI_TOOL_TYPE = "gen_ai.tool.type"
    
    # 旧版本字段（计划废弃）
    # ARMS 扩展属性
    TOOL_NAME = "tool.name"
    TOOL_DESCRIPTION = "tool.description"
    TOOL_PARAMETERS = "tool.parameters"

class ResourceAttributes:
    """Resource 相关属性字段"""
    # 以下均为 ARMS 扩展属性
    # 主机相关
    HOST_NAME = "host.name"
    
    # 服务相关
    SERVICE_NAME = "service.name"
    SERVICE_ID = "service.id"
    SERVICE_VERSION = "service.version"
    SERVICE_OWNER_ID = "service.owner.id"
    SERVICE_OWNER_SUB_ID = "service.owner.sub_id"
    SERVICE_APP_NAME = "service.app.name"
    SERVICE_APP_ID = "service.app.id"
    SERVICE_APP_OWNER_ID = "service.app.owner_id"
    
    # 阿里云相关
    ACS_CMS_WORKSPACE = "acs.cms.workspace"
    ACS_ARMS_SERVICE_ID = "acs.arms.service.id"
    ALI_TRACE_SOURCE = "ali.trace.source"
