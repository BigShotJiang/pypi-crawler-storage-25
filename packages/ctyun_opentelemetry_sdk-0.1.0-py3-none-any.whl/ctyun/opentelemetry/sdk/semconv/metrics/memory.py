"""
GenAI Memory related metric names / dimensions used by LoongSuite instrumentations.

These are intentionally **low-cardinality** strings to be used as metric names and
dimension keys (underscore format), plus a few Mem0-specific default values.
"""

# ========== Metric Names ==========
# Memory main operation metrics (4)
METRIC_OPERATION_DURATION = "gen_ai_memory_operation_duration"
METRIC_OPERATION_COUNT = "gen_ai_memory_operation_count"
METRIC_OPERATION_ERROR_COUNT = "gen_ai_memory_operation_error_count"
METRIC_OPERATION_SLOW_COUNT = "gen_ai_memory_operation_slow_count"

# Memory inner operation metrics (4 - unified for vector/graph/rerank)
METRIC_INNER_OPERATION_DURATION = "gen_ai_memory_inner_operation_duration"
METRIC_INNER_OPERATION_COUNT = "gen_ai_memory_inner_operation_count"
METRIC_INNER_OPERATION_ERROR_COUNT = "gen_ai_memory_inner_operation_error_count"
METRIC_INNER_OPERATION_SLOW_COUNT = "gen_ai_memory_inner_operation_slow_count"

# ========== Metric Dimension Attributes (underscore format) ==========
METRIC_GEN_AI_OPERATION_NAME = "gen_ai_operation_name"
METRIC_GEN_AI_MEMORY_OPERATION = "gen_ai_memory_operation"
# Unified inner phase dimensions
METRIC_GEN_AI_MEMORY_INNER_NAME = "gen_ai_memory_inner_name"
METRIC_GEN_AI_PROVIDER_NAME = "gen_ai_provider_name"
METRIC_GEN_AI_PROVIDER_URL = "gen_ai_provider_url"
METRIC_ERROR_TYPE = "error_type"
METRIC_SERVER_ADDRESS = "server_address"
METRIC_SERVER_PORT = "server_port"

# ========== Inner Phase Names ==========
INNER_PHASE_VECTOR = "vector"
INNER_PHASE_GRAPH = "graph"
INNER_PHASE_RERANK = "rerank"

# ========== ARMS Defaults for Mem0 ==========
ARMS_CALL_TYPE = "mem0"
ARMS_CALL_KIND = "mem0"
ARMS_DEFAULT_ENDPOINT = "<localhost>"


__all__ = [
    "METRIC_OPERATION_DURATION",
    "METRIC_OPERATION_COUNT",
    "METRIC_OPERATION_ERROR_COUNT",
    "METRIC_OPERATION_SLOW_COUNT",
    "METRIC_INNER_OPERATION_DURATION",
    "METRIC_INNER_OPERATION_COUNT",
    "METRIC_INNER_OPERATION_ERROR_COUNT",
    "METRIC_INNER_OPERATION_SLOW_COUNT",
    "METRIC_GEN_AI_OPERATION_NAME",
    "METRIC_GEN_AI_MEMORY_OPERATION",
    "METRIC_GEN_AI_MEMORY_INNER_NAME",
    "METRIC_GEN_AI_PROVIDER_NAME",
    "METRIC_GEN_AI_PROVIDER_URL",
    "METRIC_ERROR_TYPE",
    "METRIC_SERVER_ADDRESS",
    "METRIC_SERVER_PORT",
    "INNER_PHASE_VECTOR",
    "INNER_PHASE_GRAPH",
    "INNER_PHASE_RERANK",
    "ARMS_CALL_TYPE",
    "ARMS_CALL_KIND",
    "ARMS_DEFAULT_ENDPOINT",
]


