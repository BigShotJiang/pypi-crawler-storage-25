"""Contains all the data models used in inputs/outputs"""

from .accounting_integration_type import AccountingIntegrationType
from .additional_cost import AdditionalCost
from .additional_cost_list_response import AdditionalCostListResponse
from .address_entity_type import AddressEntityType
from .archivable_deletable_entity import ArchivableDeletableEntity
from .archivable_entity import ArchivableEntity
from .assigned_operator import AssignedOperator
from .base_entity import BaseEntity
from .base_validation_error import BaseValidationError
from .batch import Batch
from .batch_create_bom_rows_request import BatchCreateBomRowsRequest
from .batch_response import BatchResponse
from .batch_stock import BatchStock
from .batch_stock_list_response import BatchStockListResponse
from .batch_stock_update import BatchStockUpdate
from .batch_transaction import BatchTransaction
from .batch_transaction_request import BatchTransactionRequest
from .bom_row import BomRow
from .bom_row_list_response import BomRowListResponse
from .clear_demand_forecast_request import ClearDemandForecastRequest
from .clear_demand_forecast_request_periods_item import (
    ClearDemandForecastRequestPeriodsItem,
)
from .coded_error_response import CodedErrorResponse
from .cost_distribution_method import CostDistributionMethod
from .create_bom_row_request import CreateBomRowRequest
from .create_custom_field_definition_request import CreateCustomFieldDefinitionRequest
from .create_custom_field_definition_request_options_type_0 import (
    CreateCustomFieldDefinitionRequestOptionsType0,
)
from .create_customer_address_request import CreateCustomerAddressRequest
from .create_customer_request import CreateCustomerRequest
from .create_customer_request_addresses_item import CreateCustomerRequestAddressesItem
from .create_demand_forecast_request import CreateDemandForecastRequest
from .create_demand_forecast_request_periods_item import (
    CreateDemandForecastRequestPeriodsItem,
)
from .create_inventory_reorder_point_request import CreateInventoryReorderPointRequest
from .create_manufacturing_order_operation_row_request import (
    CreateManufacturingOrderOperationRowRequest,
)
from .create_manufacturing_order_operation_row_request_status import (
    CreateManufacturingOrderOperationRowRequestStatus,
)
from .create_manufacturing_order_production_request import (
    CreateManufacturingOrderProductionRequest,
)
from .create_manufacturing_order_recipe_row_request import (
    CreateManufacturingOrderRecipeRowRequest,
)
from .create_manufacturing_order_recipe_row_request_batch_transactions_item import (
    CreateManufacturingOrderRecipeRowRequestBatchTransactionsItem,
)
from .create_manufacturing_order_request import CreateManufacturingOrderRequest
from .create_manufacturing_order_request_status import (
    CreateManufacturingOrderRequestStatus,
)
from .create_material_request import CreateMaterialRequest
from .create_outsourced_purchase_order_recipe_row_request import (
    CreateOutsourcedPurchaseOrderRecipeRowRequest,
)
from .create_price_list_customer_request import CreatePriceListCustomerRequest
from .create_price_list_customer_request_price_list_customers_item import (
    CreatePriceListCustomerRequestPriceListCustomersItem,
)
from .create_price_list_request import CreatePriceListRequest
from .create_price_list_row_request import CreatePriceListRowRequest
from .create_price_list_row_request_price_list_rows_item import (
    CreatePriceListRowRequestPriceListRowsItem,
)
from .create_product_operation_row_item import CreateProductOperationRowItem
from .create_product_operation_rows_request import CreateProductOperationRowsRequest
from .create_product_request import CreateProductRequest
from .create_product_request_configs_item import CreateProductRequestConfigsItem
from .create_purchase_order_additional_cost_row_request import (
    CreatePurchaseOrderAdditionalCostRowRequest,
)
from .create_purchase_order_initial_status import CreatePurchaseOrderInitialStatus
from .create_purchase_order_request import CreatePurchaseOrderRequest
from .create_purchase_order_row_request import CreatePurchaseOrderRowRequest
from .create_recipes_request import CreateRecipesRequest
from .create_recipes_request_rows_item import CreateRecipesRequestRowsItem
from .create_sales_order_address_request import CreateSalesOrderAddressRequest
from .create_sales_order_fulfillment_request import CreateSalesOrderFulfillmentRequest
from .create_sales_order_request import CreateSalesOrderRequest
from .create_sales_order_request_sales_order_rows_item import (
    CreateSalesOrderRequestSalesOrderRowsItem,
)
from .create_sales_order_request_sales_order_rows_item_attributes_item import (
    CreateSalesOrderRequestSalesOrderRowsItemAttributesItem,
)
from .create_sales_order_row_request import CreateSalesOrderRowRequest
from .create_sales_order_row_request_attributes_item import (
    CreateSalesOrderRowRequestAttributesItem,
)
from .create_sales_order_shipping_fee_request import CreateSalesOrderShippingFeeRequest
from .create_sales_order_status import CreateSalesOrderStatus
from .create_sales_return_request import CreateSalesReturnRequest
from .create_sales_return_row_request import CreateSalesReturnRowRequest
from .create_serial_number_resource_type import CreateSerialNumberResourceType
from .create_serial_numbers_request import CreateSerialNumbersRequest
from .create_service_request import CreateServiceRequest
from .create_service_variant_request import CreateServiceVariantRequest
from .create_service_variant_request_custom_fields_item import (
    CreateServiceVariantRequestCustomFieldsItem,
)
from .create_stock_adjustment_request import CreateStockAdjustmentRequest
from .create_stock_adjustment_request_stock_adjustment_rows_item import (
    CreateStockAdjustmentRequestStockAdjustmentRowsItem,
)
from .create_stock_transfer_request import CreateStockTransferRequest
from .create_stocktake_request import CreateStocktakeRequest
from .create_stocktake_request_stocktake_rows_item import (
    CreateStocktakeRequestStocktakeRowsItem,
)
from .create_stocktake_row_request import CreateStocktakeRowRequest
from .create_stocktake_row_request_stocktake_rows_item import (
    CreateStocktakeRowRequestStocktakeRowsItem,
)
from .create_supplier_address_request import CreateSupplierAddressRequest
from .create_supplier_request import CreateSupplierRequest
from .create_tax_rate_request import CreateTaxRateRequest
from .create_variant_request import CreateVariantRequest
from .create_variant_request_config_attributes_item import (
    CreateVariantRequestConfigAttributesItem,
)
from .create_variant_request_custom_fields_item import (
    CreateVariantRequestCustomFieldsItem,
)
from .create_webhook_request import CreateWebhookRequest
from .custom_field import CustomField
from .custom_field_collection_resource_type import CustomFieldCollectionResourceType
from .custom_field_definition import CustomFieldDefinition
from .custom_field_definition_list_response import CustomFieldDefinitionListResponse
from .custom_field_definition_options_type_0 import CustomFieldDefinitionOptionsType0
from .custom_field_value import CustomFieldValue
from .custom_fields_collection import CustomFieldsCollection
from .custom_fields_collection_list_response import CustomFieldsCollectionListResponse
from .customer import Customer
from .customer_address import CustomerAddress
from .customer_address_list_response import CustomerAddressListResponse
from .customer_list_response import CustomerListResponse
from .deletable_entity import DeletableEntity
from .delete_serial_numbers_request import DeleteSerialNumbersRequest
from .demand_forecast_period import DemandForecastPeriod
from .demand_forecast_response import DemandForecastResponse
from .detailed_error_response import DetailedErrorResponse
from .document_send_status import DocumentSendStatus
from .enum_validation_error import EnumValidationError
from .enum_validation_error_code import EnumValidationErrorCode
from .error_response import ErrorResponse
from .factory import Factory
from .factory_legal_address import FactoryLegalAddress
from .find_purchase_orders_billing_status import FindPurchaseOrdersBillingStatus
from .find_purchase_orders_extend_item import FindPurchaseOrdersExtendItem
from .find_purchase_orders_status import FindPurchaseOrdersStatus
from .generic_validation_error import GenericValidationError
from .get_all_inventory_movements_resource_type import (
    GetAllInventoryMovementsResourceType,
)
from .get_all_inventory_point_extend_item import GetAllInventoryPointExtendItem
from .get_all_manufacturing_order_operation_rows_status import (
    GetAllManufacturingOrderOperationRowsStatus,
)
from .get_all_manufacturing_orders_status import GetAllManufacturingOrdersStatus
from .get_all_materials_extend_item import GetAllMaterialsExtendItem
from .get_all_products_extend_item import GetAllProductsExtendItem
from .get_all_sales_order_rows_extend_item import GetAllSalesOrderRowsExtendItem
from .get_all_sales_order_rows_product_availability import (
    GetAllSalesOrderRowsProductAvailability,
)
from .get_all_sales_orders_product_availability import (
    GetAllSalesOrdersProductAvailability,
)
from .get_all_serial_numbers_resource_type import GetAllSerialNumbersResourceType
from .get_all_variants_extend_item import GetAllVariantsExtendItem
from .get_material_extend_item import GetMaterialExtendItem
from .get_product_extend_item import GetProductExtendItem
from .get_purchase_order_extend_item import GetPurchaseOrderExtendItem
from .get_sales_order_row_extend_item import GetSalesOrderRowExtendItem
from .get_variant_extend_item import GetVariantExtendItem
from .ingredient_availability import IngredientAvailability
from .invalid_type_validation_error import InvalidTypeValidationError
from .invalid_type_validation_error_code import InvalidTypeValidationErrorCode
from .inventory import Inventory
from .inventory_item import InventoryItem
from .inventory_item_type import InventoryItemType
from .inventory_list_response import InventoryListResponse
from .inventory_movement import InventoryMovement
from .inventory_movement_list_response import InventoryMovementListResponse
from .inventory_movement_resource_type import InventoryMovementResourceType
from .inventory_reorder_point import InventoryReorderPoint
from .inventory_reorder_point_response import InventoryReorderPointResponse
from .inventory_safety_stock_level import InventorySafetyStockLevel
from .inventory_safety_stock_level_response import InventorySafetyStockLevelResponse
from .item_config import ItemConfig
from .location_address import LocationAddress
from .location_list_response import LocationListResponse
from .location_type_0 import LocationType0
from .make_to_order_manufacturing_order_request import (
    MakeToOrderManufacturingOrderRequest,
)
from .manufacturing_operation_status import ManufacturingOperationStatus
from .manufacturing_operation_type import ManufacturingOperationType
from .manufacturing_order import ManufacturingOrder
from .manufacturing_order_list_response import ManufacturingOrderListResponse
from .manufacturing_order_operation_production import (
    ManufacturingOrderOperationProduction,
)
from .manufacturing_order_operation_row import ManufacturingOrderOperationRow
from .manufacturing_order_operation_row_list_response import (
    ManufacturingOrderOperationRowListResponse,
)
from .manufacturing_order_production import ManufacturingOrderProduction
from .manufacturing_order_production_ingredient import (
    ManufacturingOrderProductionIngredient,
)
from .manufacturing_order_production_ingredient_response import (
    ManufacturingOrderProductionIngredientResponse,
)
from .manufacturing_order_production_list_response import (
    ManufacturingOrderProductionListResponse,
)
from .manufacturing_order_recipe_row import ManufacturingOrderRecipeRow
from .manufacturing_order_recipe_row_batch_transactions_item import (
    ManufacturingOrderRecipeRowBatchTransactionsItem,
)
from .manufacturing_order_recipe_row_list_response import (
    ManufacturingOrderRecipeRowListResponse,
)
from .manufacturing_order_status import ManufacturingOrderStatus
from .material import Material
from .material_config import MaterialConfig
from .material_list_response import MaterialListResponse
from .material_type import MaterialType
from .max_validation_error import MaxValidationError
from .max_validation_error_code import MaxValidationErrorCode
from .min_validation_error import MinValidationError
from .min_validation_error_code import MinValidationErrorCode
from .negative_stock import NegativeStock
from .negative_stock_list_response import NegativeStockListResponse
from .operator import Operator
from .operator_list_response import OperatorListResponse
from .operator_working_area import OperatorWorkingArea
from .outsourced_purchase_order import OutsourcedPurchaseOrder
from .outsourced_purchase_order_entity_type import OutsourcedPurchaseOrderEntityType
from .outsourced_purchase_order_ingredient_availability import (
    OutsourcedPurchaseOrderIngredientAvailability,
)
from .outsourced_purchase_order_recipe_row import OutsourcedPurchaseOrderRecipeRow
from .outsourced_purchase_order_recipe_row_batch_transactions_item import (
    OutsourcedPurchaseOrderRecipeRowBatchTransactionsItem,
)
from .outsourced_purchase_order_recipe_row_list_response import (
    OutsourcedPurchaseOrderRecipeRowListResponse,
)
from .outsourced_recipe_ingredient_availability import (
    OutsourcedRecipeIngredientAvailability,
)
from .pattern_validation_error import PatternValidationError
from .pattern_validation_error_code import PatternValidationErrorCode
from .price_adjustment_method import PriceAdjustmentMethod
from .price_list import PriceList
from .price_list_adjustment_method import PriceListAdjustmentMethod
from .price_list_customer import PriceListCustomer
from .price_list_customer_list_response import PriceListCustomerListResponse
from .price_list_list_response import PriceListListResponse
from .price_list_row import PriceListRow
from .price_list_row_list_response import PriceListRowListResponse
from .product import Product
from .product_availability import ProductAvailability
from .product_list_response import ProductListResponse
from .product_operation_rerank import ProductOperationRerank
from .product_operation_rerank_request import ProductOperationRerankRequest
from .product_operation_row import ProductOperationRow
from .product_operation_row_list_response import ProductOperationRowListResponse
from .product_operation_type import ProductOperationType
from .product_type import ProductType
from .purchase_order_accounting_metadata import PurchaseOrderAccountingMetadata
from .purchase_order_accounting_metadata_list_response import (
    PurchaseOrderAccountingMetadataListResponse,
)
from .purchase_order_additional_cost_row import PurchaseOrderAdditionalCostRow
from .purchase_order_additional_cost_row_list_response import (
    PurchaseOrderAdditionalCostRowListResponse,
)
from .purchase_order_base import PurchaseOrderBase
from .purchase_order_billing_status import PurchaseOrderBillingStatus
from .purchase_order_entity_type import PurchaseOrderEntityType
from .purchase_order_list_response import PurchaseOrderListResponse
from .purchase_order_receive_row import PurchaseOrderReceiveRow
from .purchase_order_receive_row_batch_transactions_item import (
    PurchaseOrderReceiveRowBatchTransactionsItem,
)
from .purchase_order_row import PurchaseOrderRow
from .purchase_order_row_batch_transactions_item import (
    PurchaseOrderRowBatchTransactionsItem,
)
from .purchase_order_row_list_response import PurchaseOrderRowListResponse
from .purchase_order_row_request import PurchaseOrderRowRequest
from .purchase_order_status import PurchaseOrderStatus
from .recipe import Recipe
from .recipe_list_response import RecipeListResponse
from .regular_purchase_order import RegularPurchaseOrder
from .regular_purchase_order_entity_type import RegularPurchaseOrderEntityType
from .required_validation_error import RequiredValidationError
from .required_validation_error_code import RequiredValidationErrorCode
from .returnable_item import ReturnableItem
from .sales_order import SalesOrder
from .sales_order_accounting_metadata import SalesOrderAccountingMetadata
from .sales_order_accounting_metadata_list_response import (
    SalesOrderAccountingMetadataListResponse,
)
from .sales_order_address import SalesOrderAddress
from .sales_order_address_list_response import SalesOrderAddressListResponse
from .sales_order_fulfillment import SalesOrderFulfillment
from .sales_order_fulfillment_invoice_status import SalesOrderFulfillmentInvoiceStatus
from .sales_order_fulfillment_list_response import SalesOrderFulfillmentListResponse
from .sales_order_fulfillment_row_request import SalesOrderFulfillmentRowRequest
from .sales_order_fulfillment_sales_order_fulfillment_rows_item import (
    SalesOrderFulfillmentSalesOrderFulfillmentRowsItem,
)
from .sales_order_fulfillment_sales_order_fulfillment_rows_item_batch_transactions_item import (
    SalesOrderFulfillmentSalesOrderFulfillmentRowsItemBatchTransactionsItem,
)
from .sales_order_fulfillment_status import SalesOrderFulfillmentStatus
from .sales_order_list_response import SalesOrderListResponse
from .sales_order_production_status import SalesOrderProductionStatus
from .sales_order_row import SalesOrderRow
from .sales_order_row_attributes_item import SalesOrderRowAttributesItem
from .sales_order_row_batch_transactions_item import SalesOrderRowBatchTransactionsItem
from .sales_order_row_list_response import SalesOrderRowListResponse
from .sales_order_search_request import SalesOrderSearchRequest
from .sales_order_search_request_filter import SalesOrderSearchRequestFilter
from .sales_order_shipping_fee import SalesOrderShippingFee
from .sales_order_shipping_fee_list_response import SalesOrderShippingFeeListResponse
from .sales_order_status import SalesOrderStatus
from .sales_return import SalesReturn
from .sales_return_list_response import SalesReturnListResponse
from .sales_return_reason import SalesReturnReason
from .sales_return_refund_status import SalesReturnRefundStatus
from .sales_return_row import SalesReturnRow
from .sales_return_row_batch_transactions_item import (
    SalesReturnRowBatchTransactionsItem,
)
from .sales_return_row_list_response import SalesReturnRowListResponse
from .sales_return_status import SalesReturnStatus
from .serial_number import SerialNumber
from .serial_number_list_response import SerialNumberListResponse
from .serial_number_resource_type import SerialNumberResourceType
from .serial_number_stock import SerialNumberStock
from .serial_number_stock_list_response import SerialNumberStockListResponse
from .serial_number_stock_transactions_item import SerialNumberStockTransactionsItem
from .service import Service
from .service_list_response import ServiceListResponse
from .service_type import ServiceType
from .service_variant import ServiceVariant
from .service_variant_custom_fields_item import ServiceVariantCustomFieldsItem
from .stock_adjustment import StockAdjustment
from .stock_adjustment_batch_transaction import StockAdjustmentBatchTransaction
from .stock_adjustment_list_response import StockAdjustmentListResponse
from .stock_adjustment_row import StockAdjustmentRow
from .stock_transfer import StockTransfer
from .stock_transfer_list_response import StockTransferListResponse
from .stock_transfer_row import StockTransferRow
from .stock_transfer_row_batch_transactions_item import (
    StockTransferRowBatchTransactionsItem,
)
from .stock_transfer_row_request import StockTransferRowRequest
from .stock_transfer_status import StockTransferStatus
from .stocktake import Stocktake
from .stocktake_list_response import StocktakeListResponse
from .stocktake_row import StocktakeRow
from .stocktake_row_list_response import StocktakeRowListResponse
from .stocktake_status import StocktakeStatus
from .storage_bin import StorageBin
from .storage_bin_list_response import StorageBinListResponse
from .storage_bin_response import StorageBinResponse
from .storage_bin_update import StorageBinUpdate
from .supplier import Supplier
from .supplier_address import SupplierAddress
from .supplier_address_list_response import SupplierAddressListResponse
from .supplier_address_request import SupplierAddressRequest
from .supplier_list_response import SupplierListResponse
from .tax_rate import TaxRate
from .tax_rate_list_response import TaxRateListResponse
from .too_big_validation_error import TooBigValidationError
from .too_big_validation_error_code import TooBigValidationErrorCode
from .too_small_validation_error import TooSmallValidationError
from .too_small_validation_error_code import TooSmallValidationErrorCode
from .unassigned_batch_transaction import UnassignedBatchTransaction
from .unassigned_batch_transaction_list_response import (
    UnassignedBatchTransactionListResponse,
)
from .unlink_manufacturing_order_request import UnlinkManufacturingOrderRequest
from .unlink_variant_bin_location_request import UnlinkVariantBinLocationRequest
from .unrecognized_keys_validation_error import UnrecognizedKeysValidationError
from .unrecognized_keys_validation_error_code import UnrecognizedKeysValidationErrorCode
from .updatable_entity import UpdatableEntity
from .update_bom_row_request import UpdateBomRowRequest
from .update_custom_field_definition_request import UpdateCustomFieldDefinitionRequest
from .update_custom_field_definition_request_options_type_0 import (
    UpdateCustomFieldDefinitionRequestOptionsType0,
)
from .update_customer_address_request import UpdateCustomerAddressRequest
from .update_customer_request import UpdateCustomerRequest
from .update_manufacturing_order_operation_row_request import (
    UpdateManufacturingOrderOperationRowRequest,
)
from .update_manufacturing_order_production_ingredient_request import (
    UpdateManufacturingOrderProductionIngredientRequest,
)
from .update_manufacturing_order_production_request import (
    UpdateManufacturingOrderProductionRequest,
)
from .update_manufacturing_order_recipe_row_request import (
    UpdateManufacturingOrderRecipeRowRequest,
)
from .update_manufacturing_order_recipe_row_request_batch_transactions_item import (
    UpdateManufacturingOrderRecipeRowRequestBatchTransactionsItem,
)
from .update_manufacturing_order_request import UpdateManufacturingOrderRequest
from .update_material_request import UpdateMaterialRequest
from .update_material_request_configs_item import UpdateMaterialRequestConfigsItem
from .update_outsourced_purchase_order_recipe_row_request import (
    UpdateOutsourcedPurchaseOrderRecipeRowRequest,
)
from .update_price_list_customer_request import UpdatePriceListCustomerRequest
from .update_price_list_request import UpdatePriceListRequest
from .update_price_list_row_request import UpdatePriceListRowRequest
from .update_product_operation_row_request import UpdateProductOperationRowRequest
from .update_product_request import UpdateProductRequest
from .update_product_request_configs_item import UpdateProductRequestConfigsItem
from .update_purchase_order_additional_cost_row_request import (
    UpdatePurchaseOrderAdditionalCostRowRequest,
)
from .update_purchase_order_request import UpdatePurchaseOrderRequest
from .update_purchase_order_row_request import UpdatePurchaseOrderRowRequest
from .update_recipe_row_request import UpdateRecipeRowRequest
from .update_sales_order_address_request import UpdateSalesOrderAddressRequest
from .update_sales_order_fulfillment_request import UpdateSalesOrderFulfillmentRequest
from .update_sales_order_request import UpdateSalesOrderRequest
from .update_sales_order_row_request import UpdateSalesOrderRowRequest
from .update_sales_order_row_request_attributes_item import (
    UpdateSalesOrderRowRequestAttributesItem,
)
from .update_sales_order_row_request_serial_number_transactions_item import (
    UpdateSalesOrderRowRequestSerialNumberTransactionsItem,
)
from .update_sales_order_shipping_fee_request import UpdateSalesOrderShippingFeeRequest
from .update_sales_order_status import UpdateSalesOrderStatus
from .update_sales_return_request import UpdateSalesReturnRequest
from .update_sales_return_row_request import UpdateSalesReturnRowRequest
from .update_service_request import UpdateServiceRequest
from .update_stock_adjustment_request import UpdateStockAdjustmentRequest
from .update_stock_transfer_request import UpdateStockTransferRequest
from .update_stock_transfer_status_request import UpdateStockTransferStatusRequest
from .update_stocktake_request import UpdateStocktakeRequest
from .update_stocktake_row_request import UpdateStocktakeRowRequest
from .update_supplier_address_request import UpdateSupplierAddressRequest
from .update_supplier_request import UpdateSupplierRequest
from .update_variant_request import UpdateVariantRequest
from .update_variant_request_config_attributes_item import (
    UpdateVariantRequestConfigAttributesItem,
)
from .update_variant_request_custom_fields_item import (
    UpdateVariantRequestCustomFieldsItem,
)
from .update_webhook_request import UpdateWebhookRequest
from .user import User
from .user_info import UserInfo
from .user_list_response import UserListResponse
from .variant import Variant
from .variant_config_attributes_item import VariantConfigAttributesItem
from .variant_custom_fields_item import VariantCustomFieldsItem
from .variant_default_storage_bin_link import VariantDefaultStorageBinLink
from .variant_default_storage_bin_link_response import (
    VariantDefaultStorageBinLinkResponse,
)
from .variant_list_response import VariantListResponse
from .variant_response import VariantResponse
from .variant_response_config_attributes_item import VariantResponseConfigAttributesItem
from .variant_response_custom_fields_item import VariantResponseCustomFieldsItem
from .variant_type import VariantType
from .webhook import Webhook
from .webhook_event import WebhookEvent
from .webhook_event_payload import WebhookEventPayload
from .webhook_event_payload_object import WebhookEventPayloadObject
from .webhook_list_response import WebhookListResponse
from .webhook_logs_export import WebhookLogsExport
from .webhook_logs_export_request import WebhookLogsExportRequest
from .webhook_logs_export_request_event import WebhookLogsExportRequestEvent

__all__ = (
    "AccountingIntegrationType",
    "AdditionalCost",
    "AdditionalCostListResponse",
    "AddressEntityType",
    "ArchivableDeletableEntity",
    "ArchivableEntity",
    "AssignedOperator",
    "BaseEntity",
    "BaseValidationError",
    "Batch",
    "BatchCreateBomRowsRequest",
    "BatchResponse",
    "BatchStock",
    "BatchStockListResponse",
    "BatchStockUpdate",
    "BatchTransaction",
    "BatchTransactionRequest",
    "BomRow",
    "BomRowListResponse",
    "ClearDemandForecastRequest",
    "ClearDemandForecastRequestPeriodsItem",
    "CodedErrorResponse",
    "CostDistributionMethod",
    "CreateBomRowRequest",
    "CreateCustomFieldDefinitionRequest",
    "CreateCustomFieldDefinitionRequestOptionsType0",
    "CreateCustomerAddressRequest",
    "CreateCustomerRequest",
    "CreateCustomerRequestAddressesItem",
    "CreateDemandForecastRequest",
    "CreateDemandForecastRequestPeriodsItem",
    "CreateInventoryReorderPointRequest",
    "CreateManufacturingOrderOperationRowRequest",
    "CreateManufacturingOrderOperationRowRequestStatus",
    "CreateManufacturingOrderProductionRequest",
    "CreateManufacturingOrderRecipeRowRequest",
    "CreateManufacturingOrderRecipeRowRequestBatchTransactionsItem",
    "CreateManufacturingOrderRequest",
    "CreateManufacturingOrderRequestStatus",
    "CreateMaterialRequest",
    "CreateOutsourcedPurchaseOrderRecipeRowRequest",
    "CreatePriceListCustomerRequest",
    "CreatePriceListCustomerRequestPriceListCustomersItem",
    "CreatePriceListRequest",
    "CreatePriceListRowRequest",
    "CreatePriceListRowRequestPriceListRowsItem",
    "CreateProductOperationRowItem",
    "CreateProductOperationRowsRequest",
    "CreateProductRequest",
    "CreateProductRequestConfigsItem",
    "CreatePurchaseOrderAdditionalCostRowRequest",
    "CreatePurchaseOrderInitialStatus",
    "CreatePurchaseOrderRequest",
    "CreatePurchaseOrderRowRequest",
    "CreateRecipesRequest",
    "CreateRecipesRequestRowsItem",
    "CreateSalesOrderAddressRequest",
    "CreateSalesOrderFulfillmentRequest",
    "CreateSalesOrderRequest",
    "CreateSalesOrderRequestSalesOrderRowsItem",
    "CreateSalesOrderRequestSalesOrderRowsItemAttributesItem",
    "CreateSalesOrderRowRequest",
    "CreateSalesOrderRowRequestAttributesItem",
    "CreateSalesOrderShippingFeeRequest",
    "CreateSalesOrderStatus",
    "CreateSalesReturnRequest",
    "CreateSalesReturnRowRequest",
    "CreateSerialNumberResourceType",
    "CreateSerialNumbersRequest",
    "CreateServiceRequest",
    "CreateServiceVariantRequest",
    "CreateServiceVariantRequestCustomFieldsItem",
    "CreateStockAdjustmentRequest",
    "CreateStockAdjustmentRequestStockAdjustmentRowsItem",
    "CreateStockTransferRequest",
    "CreateStocktakeRequest",
    "CreateStocktakeRequestStocktakeRowsItem",
    "CreateStocktakeRowRequest",
    "CreateStocktakeRowRequestStocktakeRowsItem",
    "CreateSupplierAddressRequest",
    "CreateSupplierRequest",
    "CreateTaxRateRequest",
    "CreateVariantRequest",
    "CreateVariantRequestConfigAttributesItem",
    "CreateVariantRequestCustomFieldsItem",
    "CreateWebhookRequest",
    "CustomField",
    "CustomFieldCollectionResourceType",
    "CustomFieldDefinition",
    "CustomFieldDefinitionListResponse",
    "CustomFieldDefinitionOptionsType0",
    "CustomFieldValue",
    "CustomFieldsCollection",
    "CustomFieldsCollectionListResponse",
    "Customer",
    "CustomerAddress",
    "CustomerAddressListResponse",
    "CustomerListResponse",
    "DeletableEntity",
    "DeleteSerialNumbersRequest",
    "DemandForecastPeriod",
    "DemandForecastResponse",
    "DetailedErrorResponse",
    "DocumentSendStatus",
    "EnumValidationError",
    "EnumValidationErrorCode",
    "ErrorResponse",
    "Factory",
    "FactoryLegalAddress",
    "FindPurchaseOrdersBillingStatus",
    "FindPurchaseOrdersExtendItem",
    "FindPurchaseOrdersStatus",
    "GenericValidationError",
    "GetAllInventoryMovementsResourceType",
    "GetAllInventoryPointExtendItem",
    "GetAllManufacturingOrderOperationRowsStatus",
    "GetAllManufacturingOrdersStatus",
    "GetAllMaterialsExtendItem",
    "GetAllProductsExtendItem",
    "GetAllSalesOrderRowsExtendItem",
    "GetAllSalesOrderRowsProductAvailability",
    "GetAllSalesOrdersProductAvailability",
    "GetAllSerialNumbersResourceType",
    "GetAllVariantsExtendItem",
    "GetMaterialExtendItem",
    "GetProductExtendItem",
    "GetPurchaseOrderExtendItem",
    "GetSalesOrderRowExtendItem",
    "GetVariantExtendItem",
    "IngredientAvailability",
    "InvalidTypeValidationError",
    "InvalidTypeValidationErrorCode",
    "Inventory",
    "InventoryItem",
    "InventoryItemType",
    "InventoryListResponse",
    "InventoryMovement",
    "InventoryMovementListResponse",
    "InventoryMovementResourceType",
    "InventoryReorderPoint",
    "InventoryReorderPointResponse",
    "InventorySafetyStockLevel",
    "InventorySafetyStockLevelResponse",
    "ItemConfig",
    "LocationAddress",
    "LocationListResponse",
    "LocationType0",
    "MakeToOrderManufacturingOrderRequest",
    "ManufacturingOperationStatus",
    "ManufacturingOperationType",
    "ManufacturingOrder",
    "ManufacturingOrderListResponse",
    "ManufacturingOrderOperationProduction",
    "ManufacturingOrderOperationRow",
    "ManufacturingOrderOperationRowListResponse",
    "ManufacturingOrderProduction",
    "ManufacturingOrderProductionIngredient",
    "ManufacturingOrderProductionIngredientResponse",
    "ManufacturingOrderProductionListResponse",
    "ManufacturingOrderRecipeRow",
    "ManufacturingOrderRecipeRowBatchTransactionsItem",
    "ManufacturingOrderRecipeRowListResponse",
    "ManufacturingOrderStatus",
    "Material",
    "MaterialConfig",
    "MaterialListResponse",
    "MaterialType",
    "MaxValidationError",
    "MaxValidationErrorCode",
    "MinValidationError",
    "MinValidationErrorCode",
    "NegativeStock",
    "NegativeStockListResponse",
    "Operator",
    "OperatorListResponse",
    "OperatorWorkingArea",
    "OutsourcedPurchaseOrder",
    "OutsourcedPurchaseOrderEntityType",
    "OutsourcedPurchaseOrderIngredientAvailability",
    "OutsourcedPurchaseOrderRecipeRow",
    "OutsourcedPurchaseOrderRecipeRowBatchTransactionsItem",
    "OutsourcedPurchaseOrderRecipeRowListResponse",
    "OutsourcedRecipeIngredientAvailability",
    "PatternValidationError",
    "PatternValidationErrorCode",
    "PriceAdjustmentMethod",
    "PriceList",
    "PriceListAdjustmentMethod",
    "PriceListCustomer",
    "PriceListCustomerListResponse",
    "PriceListListResponse",
    "PriceListRow",
    "PriceListRowListResponse",
    "Product",
    "ProductAvailability",
    "ProductListResponse",
    "ProductOperationRerank",
    "ProductOperationRerankRequest",
    "ProductOperationRow",
    "ProductOperationRowListResponse",
    "ProductOperationType",
    "ProductType",
    "PurchaseOrderAccountingMetadata",
    "PurchaseOrderAccountingMetadataListResponse",
    "PurchaseOrderAdditionalCostRow",
    "PurchaseOrderAdditionalCostRowListResponse",
    "PurchaseOrderBase",
    "PurchaseOrderBillingStatus",
    "PurchaseOrderEntityType",
    "PurchaseOrderListResponse",
    "PurchaseOrderReceiveRow",
    "PurchaseOrderReceiveRowBatchTransactionsItem",
    "PurchaseOrderRow",
    "PurchaseOrderRowBatchTransactionsItem",
    "PurchaseOrderRowListResponse",
    "PurchaseOrderRowRequest",
    "PurchaseOrderStatus",
    "Recipe",
    "RecipeListResponse",
    "RegularPurchaseOrder",
    "RegularPurchaseOrderEntityType",
    "RequiredValidationError",
    "RequiredValidationErrorCode",
    "ReturnableItem",
    "SalesOrder",
    "SalesOrderAccountingMetadata",
    "SalesOrderAccountingMetadataListResponse",
    "SalesOrderAddress",
    "SalesOrderAddressListResponse",
    "SalesOrderFulfillment",
    "SalesOrderFulfillmentInvoiceStatus",
    "SalesOrderFulfillmentListResponse",
    "SalesOrderFulfillmentRowRequest",
    "SalesOrderFulfillmentSalesOrderFulfillmentRowsItem",
    "SalesOrderFulfillmentSalesOrderFulfillmentRowsItemBatchTransactionsItem",
    "SalesOrderFulfillmentStatus",
    "SalesOrderListResponse",
    "SalesOrderProductionStatus",
    "SalesOrderRow",
    "SalesOrderRowAttributesItem",
    "SalesOrderRowBatchTransactionsItem",
    "SalesOrderRowListResponse",
    "SalesOrderSearchRequest",
    "SalesOrderSearchRequestFilter",
    "SalesOrderShippingFee",
    "SalesOrderShippingFeeListResponse",
    "SalesOrderStatus",
    "SalesReturn",
    "SalesReturnListResponse",
    "SalesReturnReason",
    "SalesReturnRefundStatus",
    "SalesReturnRow",
    "SalesReturnRowBatchTransactionsItem",
    "SalesReturnRowListResponse",
    "SalesReturnStatus",
    "SerialNumber",
    "SerialNumberListResponse",
    "SerialNumberResourceType",
    "SerialNumberStock",
    "SerialNumberStockListResponse",
    "SerialNumberStockTransactionsItem",
    "Service",
    "ServiceListResponse",
    "ServiceType",
    "ServiceVariant",
    "ServiceVariantCustomFieldsItem",
    "StockAdjustment",
    "StockAdjustmentBatchTransaction",
    "StockAdjustmentListResponse",
    "StockAdjustmentRow",
    "StockTransfer",
    "StockTransferListResponse",
    "StockTransferRow",
    "StockTransferRowBatchTransactionsItem",
    "StockTransferRowRequest",
    "StockTransferStatus",
    "Stocktake",
    "StocktakeListResponse",
    "StocktakeRow",
    "StocktakeRowListResponse",
    "StocktakeStatus",
    "StorageBin",
    "StorageBinListResponse",
    "StorageBinResponse",
    "StorageBinUpdate",
    "Supplier",
    "SupplierAddress",
    "SupplierAddressListResponse",
    "SupplierAddressRequest",
    "SupplierListResponse",
    "TaxRate",
    "TaxRateListResponse",
    "TooBigValidationError",
    "TooBigValidationErrorCode",
    "TooSmallValidationError",
    "TooSmallValidationErrorCode",
    "UnassignedBatchTransaction",
    "UnassignedBatchTransactionListResponse",
    "UnlinkManufacturingOrderRequest",
    "UnlinkVariantBinLocationRequest",
    "UnrecognizedKeysValidationError",
    "UnrecognizedKeysValidationErrorCode",
    "UpdatableEntity",
    "UpdateBomRowRequest",
    "UpdateCustomFieldDefinitionRequest",
    "UpdateCustomFieldDefinitionRequestOptionsType0",
    "UpdateCustomerAddressRequest",
    "UpdateCustomerRequest",
    "UpdateManufacturingOrderOperationRowRequest",
    "UpdateManufacturingOrderProductionIngredientRequest",
    "UpdateManufacturingOrderProductionRequest",
    "UpdateManufacturingOrderRecipeRowRequest",
    "UpdateManufacturingOrderRecipeRowRequestBatchTransactionsItem",
    "UpdateManufacturingOrderRequest",
    "UpdateMaterialRequest",
    "UpdateMaterialRequestConfigsItem",
    "UpdateOutsourcedPurchaseOrderRecipeRowRequest",
    "UpdatePriceListCustomerRequest",
    "UpdatePriceListRequest",
    "UpdatePriceListRowRequest",
    "UpdateProductOperationRowRequest",
    "UpdateProductRequest",
    "UpdateProductRequestConfigsItem",
    "UpdatePurchaseOrderAdditionalCostRowRequest",
    "UpdatePurchaseOrderRequest",
    "UpdatePurchaseOrderRowRequest",
    "UpdateRecipeRowRequest",
    "UpdateSalesOrderAddressRequest",
    "UpdateSalesOrderFulfillmentRequest",
    "UpdateSalesOrderRequest",
    "UpdateSalesOrderRowRequest",
    "UpdateSalesOrderRowRequestAttributesItem",
    "UpdateSalesOrderRowRequestSerialNumberTransactionsItem",
    "UpdateSalesOrderShippingFeeRequest",
    "UpdateSalesOrderStatus",
    "UpdateSalesReturnRequest",
    "UpdateSalesReturnRowRequest",
    "UpdateServiceRequest",
    "UpdateStockAdjustmentRequest",
    "UpdateStockTransferRequest",
    "UpdateStockTransferStatusRequest",
    "UpdateStocktakeRequest",
    "UpdateStocktakeRowRequest",
    "UpdateSupplierAddressRequest",
    "UpdateSupplierRequest",
    "UpdateVariantRequest",
    "UpdateVariantRequestConfigAttributesItem",
    "UpdateVariantRequestCustomFieldsItem",
    "UpdateWebhookRequest",
    "User",
    "UserInfo",
    "UserListResponse",
    "Variant",
    "VariantConfigAttributesItem",
    "VariantCustomFieldsItem",
    "VariantDefaultStorageBinLink",
    "VariantDefaultStorageBinLinkResponse",
    "VariantListResponse",
    "VariantResponse",
    "VariantResponseConfigAttributesItem",
    "VariantResponseCustomFieldsItem",
    "VariantType",
    "Webhook",
    "WebhookEvent",
    "WebhookEventPayload",
    "WebhookEventPayloadObject",
    "WebhookListResponse",
    "WebhookLogsExport",
    "WebhookLogsExportRequest",
    "WebhookLogsExportRequestEvent",
)
