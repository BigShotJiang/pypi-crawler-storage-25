from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...client_types import UNSET, Response, Unset
from ...models.error_response import ErrorResponse
from ...models.serial_number_stock_list_response import SerialNumberStockListResponse


def _get_kwargs(
    *,
    limit: int | Unset = UNSET,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/serial_numbers/serial_numbers_stock",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorResponse | SerialNumberStockListResponse | None:
    if response.status_code == 200:
        response_200 = SerialNumberStockListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())

        return response_401

    if response.status_code == 429:
        response_429 = ErrorResponse.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | SerialNumberStockListResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    page: int | Unset = UNSET,
) -> Response[ErrorResponse | SerialNumberStockListResponse]:
    """List serial number stock (alternate path)

     Returns a list of serial number stock. This is an alternate path for the /serial_numbers_stock
    endpoint.

    Args:
        limit (int | Unset):  Default: 50.
        page (int | Unset):  Default: 1.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.


    Returns:
        Response[ErrorResponse | SerialNumberStockListResponse]
    """

    kwargs = _get_kwargs(
        limit=limit,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    page: int | Unset = UNSET,
) -> ErrorResponse | SerialNumberStockListResponse | None:
    """List serial number stock (alternate path)

     Returns a list of serial number stock. This is an alternate path for the /serial_numbers_stock
    endpoint.

    Args:
        limit (int | Unset):  Default: 50.
        page (int | Unset):  Default: 1.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.


    Returns:
        ErrorResponse | SerialNumberStockListResponse
    """

    return sync_detailed(
        client=client,
        limit=limit,
        page=page,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    page: int | Unset = UNSET,
) -> Response[ErrorResponse | SerialNumberStockListResponse]:
    """List serial number stock (alternate path)

     Returns a list of serial number stock. This is an alternate path for the /serial_numbers_stock
    endpoint.

    Args:
        limit (int | Unset):  Default: 50.
        page (int | Unset):  Default: 1.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.


    Returns:
        Response[ErrorResponse | SerialNumberStockListResponse]
    """

    kwargs = _get_kwargs(
        limit=limit,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    page: int | Unset = UNSET,
) -> ErrorResponse | SerialNumberStockListResponse | None:
    """List serial number stock (alternate path)

     Returns a list of serial number stock. This is an alternate path for the /serial_numbers_stock
    endpoint.

    Args:
        limit (int | Unset):  Default: 50.
        page (int | Unset):  Default: 1.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.


    Returns:
        ErrorResponse | SerialNumberStockListResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            page=page,
        )
    ).parsed
