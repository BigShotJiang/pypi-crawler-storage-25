"""Utility functions for working with Katana API responses.

This module provides convenient helpers for unwrapping API responses,
handling errors, extracting data, and formatting display values.
"""

from collections.abc import Callable
from http import HTTPStatus
from typing import TYPE_CHECKING, Any, overload

from .client_types import Response, Unset
from .domain.converters import unwrap_unset
from .models.detailed_error_response import DetailedErrorResponse
from .models.enum_validation_error import EnumValidationError
from .models.error_response import ErrorResponse
from .models.invalid_type_validation_error import InvalidTypeValidationError
from .models.max_validation_error import MaxValidationError
from .models.min_validation_error import MinValidationError
from .models.pattern_validation_error import PatternValidationError
from .models.required_validation_error import RequiredValidationError
from .models.too_big_validation_error import TooBigValidationError
from .models.too_small_validation_error import TooSmallValidationError
from .models.unrecognized_keys_validation_error import UnrecognizedKeysValidationError

if TYPE_CHECKING:
    from .models.variant_response import VariantResponse


class APIError(Exception):
    """Base exception for API errors."""

    def __init__(
        self,
        message: str,
        status_code: int,
        error_response: ErrorResponse | DetailedErrorResponse | None = None,
    ):
        """Initialize API error.

        Args:
            message: Human-readable error message
            status_code: HTTP status code
            error_response: The error response object from the API
        """
        super().__init__(message)
        self.status_code = status_code
        self.error_response = error_response


class AuthenticationError(APIError):
    """Raised when authentication fails (401)."""

    pass


class ValidationError(APIError):
    """Raised when request validation fails (422)."""

    def __init__(
        self,
        message: str,
        status_code: int,
        error_response: DetailedErrorResponse | None = None,
    ):
        """Initialize validation error.

        Args:
            message: Human-readable error message
            status_code: HTTP status code (should be 422)
            error_response: The detailed error response with validation details
        """
        super().__init__(message, status_code, error_response)
        self.validation_errors = unwrap_unset(
            getattr(error_response, "details", None), []
        )

    def __str__(self) -> str:
        """Format validation error with code-specific details."""
        msg = super().__str__()

        # Add code-specific details if present using type-safe isinstance checks
        if self.validation_errors:
            error_details = []
            for detail in self.validation_errors:
                field = detail.path.lstrip("/")

                # Use isinstance for type-safe error handling
                if isinstance(detail, EnumValidationError):
                    error_details.append(
                        f"  Field '{field}' must be one of: {detail.allowed_values}"
                    )

                elif isinstance(detail, MinValidationError):
                    error_details.append(
                        f"  Field '{field}' must be >= {detail.minimum}"
                    )

                elif isinstance(detail, MaxValidationError):
                    error_details.append(
                        f"  Field '{field}' must be <= {detail.maximum}"
                    )

                elif isinstance(detail, InvalidTypeValidationError):
                    error_details.append(
                        f"  Field '{field}' must be of type: {detail.expected_type}"
                    )

                elif isinstance(detail, TooSmallValidationError):
                    if not isinstance(detail.min_length, Unset):
                        error_details.append(
                            f"  Field '{field}' must have minimum length: {detail.min_length}"
                        )
                    elif not isinstance(detail.min_items, Unset):
                        error_details.append(
                            f"  Field '{field}' must have minimum items: {detail.min_items}"
                        )

                elif isinstance(detail, TooBigValidationError):
                    if not isinstance(detail.max_length, Unset):
                        error_details.append(
                            f"  Field '{field}' must have maximum length: {detail.max_length}"
                        )
                    elif not isinstance(detail.max_items, Unset):
                        error_details.append(
                            f"  Field '{field}' must have maximum items: {detail.max_items}"
                        )

                elif isinstance(detail, RequiredValidationError):
                    error_details.append(
                        f"  Missing required field: '{detail.missing_property}'"
                    )

                elif isinstance(detail, PatternValidationError):
                    error_details.append(
                        f"  Field '{field}' must match pattern: {detail.pattern}"
                    )

                elif isinstance(detail, UnrecognizedKeysValidationError):
                    error_details.append(f"  Unrecognized fields: {detail.keys}")
                    if not isinstance(detail.valid_keys, Unset):
                        error_details.append(f"  Valid fields: {detail.valid_keys}")

            if error_details:
                msg += "\n" + "\n".join(error_details)

        return msg


class RateLimitError(APIError):
    """Raised when rate limit is exceeded (429)."""

    pass


class ServerError(APIError):
    """Raised when server error occurs (5xx)."""

    pass


@overload
def unwrap[T](
    response: Response[T],
    *,
    raise_on_error: bool = True,
) -> T: ...


@overload
def unwrap[T](
    response: Response[T],
    *,
    raise_on_error: bool = False,
) -> T | None: ...


def unwrap[T](
    response: Response[T],
    *,
    raise_on_error: bool = True,
) -> T | None:
    """Unwrap a Response object and return the parsed data or raise an error.

    This is the main utility function for handling API responses. It automatically
    raises appropriate exceptions for error responses and returns the parsed data
    for successful responses.

    Args:
        response: The Response object from an API call
        raise_on_error: If True, raise exceptions on error status codes.
                        If False, return None on errors.

    Returns:
        The parsed response data

    Raises:
        AuthenticationError: When status is 401
        ValidationError: When status is 422
        RateLimitError: When status is 429
        ServerError: When status is 5xx
        APIError: For other error status codes

    Example:
        ```python
        from katana_public_api_client import KatanaClient
        from katana_public_api_client.api.product import get_all_products
        from katana_public_api_client.utils import unwrap

        async with KatanaClient() as client:
            response = await get_all_products.asyncio_detailed(client=client)
            product_list = unwrap(
                response
            )  # Raises on error, returns parsed data
            products = product_list.data  # List of Product objects
        ```
    """
    if response.parsed is None:
        if raise_on_error:
            raise APIError(
                f"No parsed response data for status {response.status_code}",
                response.status_code,
            )
        return None

    # Check if it's an error response — assign to local for type narrowing
    parsed = response.parsed
    if isinstance(parsed, ErrorResponse | DetailedErrorResponse):
        if not raise_on_error:
            return None

        parsed_error = parsed

        error_name = (
            parsed_error.name if not isinstance(parsed_error.name, Unset) else "Unknown"
        )
        error_message = (
            parsed_error.message
            if not isinstance(parsed_error.message, Unset)
            else "No error message provided"
        )

        # Handle nested error format — Katana wraps errors in {"error": {...}}
        nested = parsed_error.additional_properties
        if isinstance(nested, dict) and "error" in nested:
            nested_error = nested["error"]
            if isinstance(nested_error, dict):
                error_name = str(nested_error.get("name", error_name))
                error_message = str(nested_error.get("message", error_message))
                # Re-parse as DetailedErrorResponse to capture details
                if "details" in nested_error:
                    parsed_error = DetailedErrorResponse.from_dict(nested_error)

        message = f"{error_name}: {error_message}"

        if response.status_code == HTTPStatus.UNAUTHORIZED:
            raise AuthenticationError(message, response.status_code, parsed_error)
        elif response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
            # ValidationError expects DetailedErrorResponse, but parsed_error could be ErrorResponse
            detailed_error = (
                parsed_error
                if isinstance(parsed_error, DetailedErrorResponse)
                else None
            )
            raise ValidationError(
                message,
                response.status_code,
                detailed_error,
            )
        elif response.status_code == HTTPStatus.TOO_MANY_REQUESTS:
            raise RateLimitError(message, response.status_code, parsed_error)
        elif 500 <= response.status_code < 600:
            raise ServerError(message, response.status_code, parsed_error)
        else:
            raise APIError(message, response.status_code, parsed_error)

    return response.parsed


@overload
def unwrap_data[T](
    response: Response[T],
    *,
    raise_on_error: bool = True,
    default: None = None,
) -> Any: ...


@overload
def unwrap_data[T](
    response: Response[T],
    *,
    raise_on_error: bool = False,
    default: None = None,
) -> Any | None: ...


@overload
def unwrap_data[T, DataT](
    response: Response[T],
    *,
    raise_on_error: bool = False,
    default: list[DataT],
) -> Any: ...


def unwrap_data[T, DataT](
    response: Response[T],
    *,
    raise_on_error: bool = True,
    default: list[DataT] | None = None,
) -> Any | None:
    """Unwrap a Response and extract the data list from list responses.

    This is a convenience function that unwraps the response and extracts
    the `.data` field from list response objects (like ProductListResponse,
    WebhookListResponse, etc.).

    Args:
        response: The Response object from an API call
        raise_on_error: If True, raise exceptions on error status codes.
                        If False, return default on errors.
        default: Default value to return if data is not available

    Returns:
        List of data objects, or default if not available

    Raises:
        Same exceptions as unwrap()

    Example:
        ```python
        from katana_public_api_client import KatanaClient
        from katana_public_api_client.api.product import get_all_products
        from katana_public_api_client.utils import unwrap_data

        async with KatanaClient() as client:
            response = await get_all_products.asyncio_detailed(client=client)
            products = unwrap_data(response)  # Directly get list of Products
            for product in products:
                print(product.name)
        ```
    """
    try:
        parsed = unwrap(response, raise_on_error=raise_on_error)
    except APIError:
        if raise_on_error:
            raise
        return default

    if parsed is None:
        return default

    # Extract data field if it exists
    data = getattr(parsed, "data", None)
    if isinstance(data, Unset):
        return default if default is not None else []
    if data is not None:
        return data

    # If there's no data field and no default, wrap the object in a list
    if default is not None:
        return default

    # If it's not a list response, return it as a single-item list
    return [parsed]


def is_success(response: Response[Any]) -> bool:
    """Check if a response was successful (2xx status code).

    Args:
        response: The Response object to check

    Returns:
        True if status code is 2xx, False otherwise

    Example:
        ```python
        response = await some_api_call.asyncio_detailed(client=client)
        if is_success(response):
            data = unwrap_data(response)
        else:
            print(f"Error: {response.status_code}")
        ```
    """
    return 200 <= response.status_code < 300


def is_error(response: Response[Any]) -> bool:
    """Check if a response was an error (4xx or 5xx status code).

    Args:
        response: The Response object to check

    Returns:
        True if status code is 4xx or 5xx, False otherwise
    """
    return response.status_code >= 400


@overload
def unwrap_as[T, ExpectedT](
    response: Response[T],
    expected_type: type[ExpectedT],
    *,
    raise_on_error: bool = True,
) -> ExpectedT: ...


@overload
def unwrap_as[T, ExpectedT](
    response: Response[T],
    expected_type: type[ExpectedT],
    *,
    raise_on_error: bool = False,
) -> ExpectedT | None: ...


def unwrap_as[T, ExpectedT](
    response: Response[T],
    expected_type: type[ExpectedT],
    *,
    raise_on_error: bool = True,
) -> ExpectedT | None:
    """Unwrap a Response and validate the parsed data is of the expected type.

    This is a convenience function that combines unwrap() with type validation.
    It's useful when you expect a specific model type from an API response.

    Args:
        response: The Response object from an API call
        expected_type: The expected type of the parsed response
        raise_on_error: If True, raise exceptions on error status codes.
            If False, returns None on error instead of raising.

    Returns:
        The parsed response data, typed as ExpectedT (or ExpectedT | None if
        raise_on_error=False)

    Raises:
        Same exceptions as unwrap(), plus:
        TypeError: If the parsed response is not of the expected type

    Example:
        ```python
        from katana_public_api_client import KatanaClient
        from katana_public_api_client.api.sales_order import get_sales_order
        from katana_public_api_client.models import SalesOrder
        from katana_public_api_client.utils import unwrap_as

        async with KatanaClient() as client:
            response = await get_sales_order.asyncio_detailed(
                client=client, id=123
            )
            order = unwrap_as(response, SalesOrder)  # Type-safe SalesOrder
            print(order.order_no)
        ```
    """
    result = unwrap(response, raise_on_error=raise_on_error)
    if result is None:
        if raise_on_error:
            raise TypeError(
                f"Expected {expected_type.__name__}, got None from response"
            )
        return None

    if not isinstance(result, expected_type):
        raise TypeError(
            f"Expected {expected_type.__name__}, got {type(result).__name__}"
        )
    return result


def get_error_message[T](response: Response[T]) -> str | None:
    """Extract error message from an error response.

    Args:
        response: The Response object (typically an error response)

    Returns:
        Error message string, or None if no error message found

    Example:
        ```python
        response = await some_api_call.asyncio_detailed(client=client)
        if is_error(response):
            error_msg = get_error_message(response)
            print(f"API Error: {error_msg}")
        ```
    """
    if response.parsed is None:
        return None

    # Assign to local for type narrowing
    parsed = response.parsed
    if not isinstance(parsed, ErrorResponse | DetailedErrorResponse):
        return None

    error_message = parsed.message if not isinstance(parsed.message, Unset) else None

    # Check nested error format
    nested = parsed.additional_properties
    if isinstance(nested, dict) and "error" in nested:
        nested_error = nested["error"]
        if isinstance(nested_error, dict):
            error_message = str(nested_error.get("message", error_message))

    return error_message


def handle_response[T](
    response: Response[T],
    *,
    on_success: Callable[[T], Any] | None = None,
    on_error: Callable[[APIError], Any] | None = None,
    raise_on_error: bool = False,
) -> Any:
    """Handle a response with custom success and error handlers.

    This function provides a convenient way to handle both success and error
    cases with custom callbacks.

    Args:
        response: The Response object from an API call
        on_success: Callback function to call with parsed data on success
        on_error: Callback function to call with APIError on error
        raise_on_error: If True, raise the error even if on_error is provided

    Returns:
        Result of on_success callback, result of on_error callback, or None

    Example:
        ```python
        def handle_products(product_list):
            print(f"Got {len(product_list.data)} products")
            return product_list.data


        def handle_error(error):
            print(f"Error: {error}")
            return []


        response = await get_all_products.asyncio_detailed(client=client)
        products = handle_response(
            response, on_success=handle_products, on_error=handle_error
        )
        ```
    """
    try:
        data = unwrap(response, raise_on_error=True)
        if on_success:
            return on_success(data)
        return data
    except APIError as e:
        if raise_on_error:
            raise
        if on_error:
            return on_error(e)
        return None


def get_variant_display_name(variant: "VariantResponse") -> str:
    """Build the full variant display name matching Katana UI format.

    Format: "{Product/Material Name} / {Config Value 1} / {Config Value 2} / ..."

    Example: "Mayhem 140 / Liquid Black / Large / 5 Star"

    Takes a `VariantResponse` (the discriminated-union variant schema with
    typed `product_or_material: Material | Product | Unset`). Variants returned
    *without* `?extend=product_or_material` have `product_or_material` UNSET, in
    which case the display name falls back to empty string.

    Args:
        variant: VariantResponse fetched with `?extend=product_or_material`.

    Returns:
        Formatted variant name with config values, or empty string if no name available.

    Example:
        ```python
        from katana_public_api_client import KatanaClient
        from katana_public_api_client.api.variant import get_all_variants
        from katana_public_api_client.models.get_all_variants_extend_item import (
            GetAllVariantsExtendItem,
        )
        from katana_public_api_client.utils import (
            get_variant_display_name,
            unwrap_data,
        )

        async with KatanaClient() as client:
            response = await get_all_variants.asyncio_detailed(
                client=client,
                extend=[GetAllVariantsExtendItem.PRODUCT_OR_MATERIAL],
            )
            for variant in unwrap_data(response):
                print(get_variant_display_name(variant))
                # e.g. "Mayhem 140 / Liquid Black / Large / 5 Star"
        ```
    """
    product_or_material = unwrap_unset(variant.product_or_material, None)
    base_name = ""
    if product_or_material is not None:
        base_name = unwrap_unset(product_or_material.name, "") or ""

    if not base_name:
        return ""

    parts: list[str] = [str(base_name)]
    config_attributes = unwrap_unset(variant.config_attributes, [])
    for attr in config_attributes or []:
        config_value = unwrap_unset(attr.config_value, None)
        if config_value:
            parts.append(str(config_value))

    return " / ".join(parts)


__all__ = [
    "APIError",
    "AuthenticationError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    "get_error_message",
    "get_variant_display_name",
    "handle_response",
    "is_error",
    "is_success",
    "unwrap",
    "unwrap_data",
]
