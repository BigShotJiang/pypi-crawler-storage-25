"""Tests for certmesh.api.routes.dashboard."""

from __future__ import annotations

import time
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient

from certmesh.api.dashboard_state import DashboardStateConfig, DashboardStateStore
from certmesh.api.oauth2_flow import OAuth2FlowConfig, SessionManager
from certmesh.api.routes.dashboard import router as dashboard_router

# ── Fixtures ──────────────────────────────────────────────────────────────────

_SESSION_SECRET = "a" * 64  # must be >= 32 chars


class _FakeTemplates:
    """Fake Jinja2Templates that returns simple HTML responses for testing."""

    def TemplateResponse(self, *args: Any, **kwargs: Any) -> HTMLResponse:  # noqa: N802
        name, context, status_code = _parse_template_args(args, kwargs)
        parts = _build_html_parts(name, context)
        return HTMLResponse(content="\n".join(parts), status_code=status_code)


def _parse_template_args(
    args: tuple[Any, ...], kwargs: dict[str, Any]
) -> tuple[str, dict[str, Any], int]:
    """Extract template name, context, and status_code from mixed args/kwargs."""
    name = ""
    context: dict[str, Any] = {}
    status_code = 200

    for arg in args:
        if isinstance(arg, str) and arg.endswith(".html"):
            name = arg
        elif isinstance(arg, dict):
            context = arg

    name = kwargs.get("name", name)
    context = kwargs.get("context", context)
    status_code = kwargs.get("status_code", status_code)
    return name, context, status_code


def _build_html_parts(name: str, context: dict[str, Any]) -> list[str]:
    """Build minimal HTML body parts from template context."""
    parts = [f"<html><body><h1>{name}</h1>"]
    for key in ("error", "user", "csrf_token", "error_title", "error_message"):
        val = context.get(key)
        if val:
            parts.append(f'<div class="{key.replace("_", "-")}">{val}</div>')
    parts.append("</body></html>")
    return parts


def _make_app() -> FastAPI:
    """Create a minimal FastAPI app with dashboard routes and all required state."""
    app = FastAPI()

    # Session manager
    session_manager = SessionManager(secret=_SESSION_SECRET)
    app.state.session_manager = session_manager

    # OAuth2 flow config
    oauth2_flow_config = OAuth2FlowConfig(
        issuer_url="https://idp.example.com",
        client_id="test-client-id",
        redirect_uri="http://localhost:8000/dashboard/callback",
        session_secret=_SESSION_SECRET,
    )
    app.state.oauth2_flow_config = oauth2_flow_config

    # Dashboard state store (in-memory only, no S3)
    dashboard_state = DashboardStateStore(DashboardStateConfig())
    app.state.dashboard_state = dashboard_state

    # Fake templates (avoids Starlette version-specific TemplateResponse issues)
    app.state.dashboard_templates = _FakeTemplates()

    # Config dict
    app.state.config = {}

    app.include_router(dashboard_router)
    return app


@pytest.fixture()
def app() -> FastAPI:
    return _make_app()


@pytest.fixture()
def client(app: FastAPI) -> TestClient:
    return TestClient(app, follow_redirects=False)


def _create_session_cookie(
    app: FastAPI,
    user: dict[str, Any] | None = None,
    csrf_token: str = "test-csrf-token",
) -> str:
    """Create a signed session cookie for an authenticated user."""
    if user is None:
        user = {"sub": "user123", "name": "Test User", "email": "test@example.com"}
    session_data = {
        "user": user,
        "access_token": "fake-access-token",
        "csrf_token": csrf_token,
    }
    sm: SessionManager = app.state.session_manager
    return sm.create_session(session_data)


# ── Login page ────────────────────────────────────────────────────────────────


class TestLoginPage:
    """GET /dashboard/login"""

    def test_login_page_renders(self, client: TestClient) -> None:
        resp = client.get("/dashboard/login")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
        assert "login.html" in resp.text

    def test_login_page_shows_error_message(self, client: TestClient) -> None:
        resp = client.get("/dashboard/login?error=auth_failed")
        assert resp.status_code == 200
        assert "Authentication failed" in resp.text

    def test_login_page_shows_session_expired_error(self, client: TestClient) -> None:
        resp = client.get("/dashboard/login?error=session_expired")
        assert resp.status_code == 200
        assert "expired" in resp.text.lower()

    def test_login_page_no_error_message_for_unknown_code(self, client: TestClient) -> None:
        resp = client.get("/dashboard/login?error=nonexistent_code")
        assert resp.status_code == 200
        # Unknown error codes produce an empty error message
        assert "error" not in resp.text.lower() or 'class="error"' not in resp.text

    def test_login_page_redirects_when_authenticated(
        self, app: FastAPI, client: TestClient
    ) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/login", cookies={"cm_session": cookie})
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard"


# ── Dashboard index ──────────────────────────────────────────────────────────


class TestDashboardIndex:
    """GET /dashboard"""

    def test_redirects_to_sso_when_unauthenticated(self, client: TestClient) -> None:
        resp = client.get("/dashboard")
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard/auth/start"

    def test_renders_when_authenticated(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
        assert "dashboard.html" in resp.text

    def test_redirects_with_invalid_session(self, client: TestClient) -> None:
        resp = client.get("/dashboard", cookies={"cm_session": "bogus-token"})
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard/auth/start"

    def test_redirects_with_session_missing_user(self, app: FastAPI, client: TestClient) -> None:
        """A session without a 'user' key should redirect to SSO."""
        sm: SessionManager = app.state.session_manager
        token = sm.create_session({"some_other_key": "value"})
        resp = client.get("/dashboard", cookies={"cm_session": token})
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard/auth/start"


# ── OAuth2 auth/start ─────────────────────────────────────────────────────────


class TestAuthStart:
    """GET /dashboard/auth/start"""

    def test_redirects_to_authorization_url(self, client: TestClient) -> None:
        with (
            patch(
                "certmesh.api.oauth2_flow.generate_code_verifier",
                return_value="fake-verifier",
            ),
            patch(
                "certmesh.api.oauth2_flow.generate_code_challenge",
                return_value="fake-challenge",
            ),
            patch(
                "certmesh.api.oauth2_flow.generate_csrf_token",
                return_value="fake-csrf",
            ),
            patch(
                "certmesh.api.oauth2_flow.generate_oauth2_state",
                return_value="fake-state",
            ),
            patch(
                "certmesh.api.oauth2_flow.build_authorization_url",
                return_value="https://idp.example.com/authorize?foo=bar",
            ),
        ):
            resp = client.get("/dashboard/auth/start")
        assert resp.status_code == 302
        assert "idp.example.com/authorize" in resp.headers["location"]
        # Should set a pending login cookie
        assert "cm_pending_login" in resp.headers.get("set-cookie", "")

    def test_returns_503_when_oauth2_not_configured(self, app: FastAPI) -> None:
        app.state.oauth2_flow_config = OAuth2FlowConfig(
            issuer_url="",
            client_id="",
            session_secret=_SESSION_SECRET,
        )
        c = TestClient(app, follow_redirects=False)
        resp = c.get("/dashboard/auth/start")
        assert resp.status_code == 503
        assert "Not Configured" in resp.text


# ── OAuth2 callback ──────────────────────────────────────────────────────────


class TestCallback:
    """GET /dashboard/callback"""

    def test_missing_code_param_redirects_to_login(self, client: TestClient) -> None:
        resp = client.get("/dashboard/callback?state=some-state")
        assert resp.status_code == 302
        assert "error=callback_error" in resp.headers["location"]

    def test_missing_state_param_redirects_to_login(self, client: TestClient) -> None:
        resp = client.get("/dashboard/callback?code=some-code")
        assert resp.status_code == 302
        assert "error=callback_error" in resp.headers["location"]

    def test_missing_both_params_redirects_to_login(self, client: TestClient) -> None:
        resp = client.get("/dashboard/callback")
        assert resp.status_code == 302
        assert "error=callback_error" in resp.headers["location"]

    def test_error_param_redirects_to_login(self, client: TestClient) -> None:
        resp = client.get("/dashboard/callback?error=access_denied&error_description=User+denied")
        assert resp.status_code == 302
        assert "error=auth_failed" in resp.headers["location"]

    def test_no_pending_cookie_redirects_to_login(self, client: TestClient) -> None:
        resp = client.get("/dashboard/callback?code=abc&state=xyz")
        assert resp.status_code == 302
        assert "error=csrf_invalid" in resp.headers["location"]

    def test_invalid_pending_cookie_redirects_to_login(self, client: TestClient) -> None:
        resp = client.get(
            "/dashboard/callback?code=abc&state=xyz",
            cookies={"cm_pending_login": "invalid-token"},
        )
        assert resp.status_code == 302
        assert "error=csrf_invalid" in resp.headers["location"]

    @patch("certmesh.api.oauth2_flow.validate_oauth2_state", return_value=True)
    @patch("certmesh.api.oauth2_flow.exchange_code_for_tokens", new_callable=AsyncMock)
    @patch("certmesh.api.oauth2_flow.fetch_userinfo", new_callable=AsyncMock)
    @patch("certmesh.api.oauth2_flow.generate_csrf_token", return_value="new-csrf")
    def test_successful_callback_sets_session_cookie(
        self,
        _csrf,
        mock_userinfo,
        mock_exchange,
        _validate,
        app: FastAPI,
        client: TestClient,
    ) -> None:
        mock_exchange.return_value = {
            "access_token": "at-123",
            "refresh_token": "rt-456",
            "expires_in": 3600,
        }
        mock_userinfo.return_value = {
            "sub": "user1",
            "name": "Test User",
            "email": "test@example.com",
        }

        # Create a pending login cookie
        sm: SessionManager = app.state.session_manager
        pending_token = sm.create_session(
            {
                "code_verifier": "verifier-abc",
                "csrf_token": "csrf-xyz",
            }
        )

        resp = client.get(
            "/dashboard/callback?code=authcode&state=valid-state",
            cookies={"cm_pending_login": pending_token},
        )
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard"
        # Session cookie should be set
        assert "cm_session" in resp.headers.get("set-cookie", "")

    @patch("certmesh.api.oauth2_flow.validate_oauth2_state", return_value=True)
    @patch("certmesh.api.oauth2_flow.exchange_code_for_tokens", new_callable=AsyncMock)
    @patch("certmesh.api.oauth2_flow.generate_csrf_token", return_value="new-csrf")
    def test_callback_token_exchange_failure(
        self,
        _csrf,
        mock_exchange,
        _validate,
        app: FastAPI,
        client: TestClient,
    ) -> None:
        mock_exchange.side_effect = RuntimeError("token exchange failed")

        sm: SessionManager = app.state.session_manager
        pending_token = sm.create_session(
            {
                "code_verifier": "verifier-abc",
                "csrf_token": "csrf-xyz",
            }
        )

        resp = client.get(
            "/dashboard/callback?code=authcode&state=valid-state",
            cookies={"cm_pending_login": pending_token},
        )
        assert resp.status_code == 302
        assert "error=auth_failed" in resp.headers["location"]


# ── Logout ────────────────────────────────────────────────────────────────────


class TestLogout:
    """POST /dashboard/logout"""

    def test_logout_clears_session_and_redirects(self, app: FastAPI, client: TestClient) -> None:
        csrf = "test-csrf-token"
        cookie = _create_session_cookie(app, csrf_token=csrf)
        resp = client.post(
            "/dashboard/logout",
            cookies={"cm_session": cookie},
            data={"csrf_token": csrf},
        )
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard/login"
        # Cookie deletion sets max-age=0 or expires in the past
        set_cookie = resp.headers.get("set-cookie", "")
        assert "cm_session" in set_cookie

    def test_logout_without_session_still_redirects(self, client: TestClient) -> None:
        resp = client.post("/dashboard/logout")
        assert resp.status_code == 302
        assert resp.headers["location"] == "/dashboard/login"

    def test_logout_rejects_missing_csrf_token(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.post("/dashboard/logout", cookies={"cm_session": cookie})
        assert resp.status_code == 403

    def test_logout_rejects_wrong_csrf_token(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app, csrf_token="real-token")
        resp = client.post(
            "/dashboard/logout",
            cookies={"cm_session": cookie},
            data={"csrf_token": "wrong-token"},
        )
        assert resp.status_code == 403


# ── API: certificates ────────────────────────────────────────────────────────


class TestAPICertificates:
    """GET /dashboard/api/certificates"""

    def test_unauthenticated_returns_401(self, client: TestClient) -> None:
        resp = client.get("/dashboard/api/certificates")
        assert resp.status_code == 401

    def test_returns_empty_list_when_no_providers(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/certificates", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["certificates"] == []
        assert data["total"] == 0
        assert data["errors"] == []

    def test_returns_digicert_certificates(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {"digicert": {"base_url": "https://digicert.example.com"}}
        cookie = _create_session_cookie(app)
        with patch(
            "certmesh.providers.digicert_client.list_issued_certificates",
            return_value=[
                {"common_name": "example.com", "not_after": "2026-12-31"},
            ],
        ):
            resp = client.get("/dashboard/api/certificates", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["certificates"]) == 1
        assert data["certificates"][0]["provider"] == "digicert"
        assert data["total"] == 1

    def test_provider_error_is_captured_not_raised(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {"digicert": {"base_url": "https://digicert.example.com"}}
        cookie = _create_session_cookie(app)
        with patch(
            "certmesh.providers.digicert_client.list_issued_certificates",
            side_effect=RuntimeError("connection failed"),
        ):
            resp = client.get("/dashboard/api/certificates", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["errors"]) == 1
        assert data["errors"][0]["provider"] == "digicert"
        assert "Failed to retrieve digicert certificates" in data["errors"][0]["error"]

    def test_stores_snapshot_in_dashboard_state(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {}
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/certificates", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        snapshot = app.state.dashboard_state.get("latest_snapshot")
        assert snapshot is not None
        assert "certificates" in snapshot
        assert "timestamp" in snapshot


# ── API: timeline ─────────────────────────────────────────────────────────────


class TestAPITimeline:
    """GET /dashboard/api/timeline"""

    def test_unauthenticated_returns_401(self, client: TestClient) -> None:
        resp = client.get("/dashboard/api/timeline")
        assert resp.status_code == 401

    def test_empty_timeline(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/timeline", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert "buckets" in data
        assert "summary" in data
        for bucket_name in ("expired", "critical", "warning", "attention", "healthy", "unknown"):
            assert bucket_name in data["summary"]

    def test_timeline_buckets_certificates(self, app: FastAPI, client: TestClient) -> None:
        # Pre-populate dashboard state with a snapshot
        now = time.time()
        certs = [
            {"common_name": "expired.com", "not_after": "2020-01-01"},
            {"common_name": "healthy.com", "not_after": "2027-12-31"},
            {"common_name": "unknown.com"},  # no expiry field
        ]
        app.state.dashboard_state.put(
            "latest_snapshot",
            {
                "certificates": certs,
                "errors": [],
                "timestamp": now,
            },
        )

        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/timeline", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 3
        assert data["summary"]["expired"] >= 1
        assert data["summary"]["unknown"] >= 1
        assert data["summary"]["healthy"] >= 1

    def test_timeline_with_no_snapshot(self, app: FastAPI, client: TestClient) -> None:
        """Timeline returns empty buckets when no snapshot exists."""
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/timeline", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert all(v == 0 for v in data["summary"].values())


# ── CSRF validation ──────────────────────────────────────────────────────────


class TestCSRFValidation:
    """CSRF token enforcement on POST endpoints."""

    def test_renew_without_csrf_returns_403(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app, csrf_token="server-csrf")
        resp = client.post(
            "/dashboard/api/certificates/venafi/cert1/renew",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 403
        assert "CSRF" in resp.json()["detail"]

    def test_renew_with_wrong_csrf_returns_403(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app, csrf_token="server-csrf")
        resp = client.post(
            "/dashboard/api/certificates/venafi/cert1/renew",
            cookies={"cm_session": cookie},
            headers={"X-CSRF-Token": "wrong-csrf"},
        )
        assert resp.status_code == 403

    def test_revoke_without_csrf_returns_403(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app, csrf_token="server-csrf")
        resp = client.post(
            "/dashboard/api/certificates/venafi/cert1/revoke",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 403

    def test_renew_with_valid_csrf_passes_validation(
        self, app: FastAPI, client: TestClient
    ) -> None:
        csrf = "valid-csrf-token"
        cookie = _create_session_cookie(app, csrf_token=csrf)
        app.state.config = {"venafi": {"url": "https://venafi.example.com"}}
        with patch(
            "certmesh.providers.venafi_client.renew_certificate",
            create=True,
            return_value={"status": "renewed"},
        ):
            resp = client.post(
                "/dashboard/api/certificates/venafi/cert1/renew",
                cookies={"cm_session": cookie},
                headers={"X-CSRF-Token": csrf},
            )
        # Should pass CSRF check (200 on success)
        assert resp.status_code != 403

    def test_revoke_with_valid_csrf_passes_validation(
        self, app: FastAPI, client: TestClient
    ) -> None:
        csrf = "valid-csrf-token"
        cookie = _create_session_cookie(app, csrf_token=csrf)
        app.state.config = {"digicert": {"base_url": "https://digicert.example.com"}}
        with patch(
            "certmesh.providers.digicert_client.revoke_certificate",
            return_value=None,
        ):
            resp = client.post(
                "/dashboard/api/certificates/digicert/cert1/revoke",
                cookies={"cm_session": cookie},
                headers={"X-CSRF-Token": csrf},
            )
        assert resp.status_code != 403


# ── Renew / Revoke endpoint behaviour ────────────────────────────────────────


class TestRenewRevoke:
    """POST /dashboard/api/certificates/{provider}/{id}/renew and /revoke"""

    def _authed_post(self, client: TestClient, app: FastAPI, path: str, csrf: str = "tok") -> Any:
        cookie = _create_session_cookie(app, csrf_token=csrf)
        return client.post(
            path,
            cookies={"cm_session": cookie},
            headers={"X-CSRF-Token": csrf},
        )

    def test_renew_digicert_returns_400(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {}
        resp = self._authed_post(client, app, "/dashboard/api/certificates/digicert/cert1/renew")
        assert resp.status_code == 400
        assert "DigiCert" in resp.json()["detail"]

    def test_renew_acm_returns_400(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {}
        resp = self._authed_post(client, app, "/dashboard/api/certificates/acm/cert1/renew")
        assert resp.status_code == 400
        assert "ACM" in resp.json()["detail"]

    def test_renew_unknown_provider_returns_422(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {}
        resp = self._authed_post(client, app, "/dashboard/api/certificates/unknown/cert1/renew")
        assert resp.status_code == 422  # FastAPI Literal validation

    def test_revoke_acm_returns_400(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {}
        resp = self._authed_post(client, app, "/dashboard/api/certificates/acm/cert1/revoke")
        assert resp.status_code == 400
        assert "ACM" in resp.json()["detail"]

    def test_revoke_unknown_provider_returns_422(self, app: FastAPI, client: TestClient) -> None:
        app.state.config = {}
        resp = self._authed_post(client, app, "/dashboard/api/certificates/unknown/cert1/revoke")
        assert resp.status_code == 422  # FastAPI Literal validation

    def test_unauthenticated_renew_returns_401(self, client: TestClient) -> None:
        resp = client.post("/dashboard/api/certificates/venafi/cert1/renew")
        assert resp.status_code == 401

    def test_unauthenticated_revoke_returns_401(self, client: TestClient) -> None:
        resp = client.post("/dashboard/api/certificates/venafi/cert1/revoke")
        assert resp.status_code == 401

    def test_revoke_digicert_success(self, app: FastAPI, client: TestClient) -> None:
        csrf = "csrf-tok"
        app.state.config = {"digicert": {"base_url": "https://digicert.example.com"}}
        cookie = _create_session_cookie(app, csrf_token=csrf)
        with patch(
            "certmesh.providers.digicert_client.revoke_certificate",
            return_value=None,
        ):
            resp = client.post(
                "/dashboard/api/certificates/digicert/cert1/revoke",
                cookies={"cm_session": cookie},
                headers={"X-CSRF-Token": csrf},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "success"
        assert data["action"] == "revoke"

    def test_renew_venafi_success(self, app: FastAPI, client: TestClient) -> None:
        csrf = "csrf-tok"
        app.state.config = {"venafi": {"url": "https://venafi.example.com"}}
        cookie = _create_session_cookie(app, csrf_token=csrf)
        with patch(
            "certmesh.providers.venafi_client.renew_certificate",
            create=True,
            return_value={"certificate_id": "cert1", "status": "renewed"},
        ):
            resp = client.post(
                "/dashboard/api/certificates/venafi/cert1/renew",
                cookies={"cm_session": cookie},
                headers={"X-CSRF-Token": csrf},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "success"
        assert data["action"] == "renew"

    def test_renew_venafi_records_history(self, app: FastAPI, client: TestClient) -> None:
        csrf = "csrf-tok"
        app.state.config = {"venafi": {"url": "https://venafi.example.com"}}
        cookie = _create_session_cookie(app, csrf_token=csrf)
        with patch(
            "certmesh.providers.venafi_client.renew_certificate",
            create=True,
            return_value={"certificate_id": "cert1"},
        ):
            resp = client.post(
                "/dashboard/api/certificates/venafi/cert1/renew",
                cookies={"cm_session": cookie},
                headers={"X-CSRF-Token": csrf},
            )
        assert resp.status_code == 200
        history = app.state.dashboard_state.get("renewal_history", [])
        assert len(history) == 1
        assert history[0]["action"] == "renew"
        assert history[0]["provider"] == "venafi"

    def test_revoke_provider_exception_returns_500(self, app: FastAPI, client: TestClient) -> None:
        csrf = "csrf-tok"
        app.state.config = {"digicert": {"base_url": "https://digicert.example.com"}}
        cookie = _create_session_cookie(app, csrf_token=csrf)
        with patch(
            "certmesh.providers.digicert_client.revoke_certificate",
            side_effect=RuntimeError("API error"),
        ):
            resp = client.post(
                "/dashboard/api/certificates/digicert/cert1/revoke",
                cookies={"cm_session": cookie},
                headers={"X-CSRF-Token": csrf},
            )
        assert resp.status_code == 500
        assert resp.json()["status"] == "error"

    def test_revoke_vault_pki_success(self, app: FastAPI, client: TestClient) -> None:
        csrf = "csrf-tok"
        app.state.config = {"vault": {"pki": {"mount": "pki"}}}
        app.state.vault_client = object()  # non-None sentinel
        cookie = _create_session_cookie(app, csrf_token=csrf)
        with patch(
            "certmesh.backends.vault_client.revoke_pki_certificate",
            return_value=None,
        ):
            resp = client.post(
                "/dashboard/api/certificates/vault_pki/39:dd:2e:90/revoke",
                cookies={"cm_session": cookie},
                headers={"X-CSRF-Token": csrf},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "success"
        assert data["action"] == "revoke"

    def test_revoke_vault_pki_no_client_returns_503(
        self, app: FastAPI, client: TestClient
    ) -> None:
        csrf = "csrf-tok"
        app.state.config = {}
        app.state.vault_client = None
        cookie = _create_session_cookie(app, csrf_token=csrf)
        resp = client.post(
            "/dashboard/api/certificates/vault_pki/39:dd:2e:90/revoke",
            cookies={"cm_session": cookie},
            headers={"X-CSRF-Token": csrf},
        )
        assert resp.status_code == 503


# ── Provider validation ───────────────────────────────────────────────────────


class TestProviderValidation:
    """Validate that unknown providers are rejected in detail/API routes."""

    def test_certificate_detail_page_invalid_provider_returns_404(
        self, app: FastAPI, client: TestClient
    ) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/certificates/badprovider/cert1",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 404

    def test_certificate_detail_page_valid_provider(
        self, app: FastAPI, client: TestClient
    ) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/certificates/digicert/cert1",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200

    def test_api_certificate_detail_invalid_provider_returns_404(
        self, app: FastAPI, client: TestClient
    ) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/certificates/badprovider/cert1",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 404

    def test_api_certificate_detail_vault_pki_no_client(
        self, app: FastAPI, client: TestClient
    ) -> None:
        app.state.config = {}
        app.state.vault_client = None
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/certificates/vault_pki/39:dd:2e:90",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 503


# ── Live log endpoints ────────────────────────────────────────────────────────


class TestLogsStreamAPI:
    """GET /dashboard/api/logs/stream"""

    def test_stream_requires_auth(self, client: TestClient) -> None:
        resp = client.get("/dashboard/api/logs/stream")
        assert resp.status_code == 401

    def test_stream_returns_503_without_buffer(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/logs/stream", cookies={"cm_session": cookie})
        assert resp.status_code == 503

    def test_stream_with_buffer_does_not_return_503(self, app: FastAPI) -> None:
        """Verify SSE endpoint accepts requests when buffer is available.

        Full SSE streaming is tested at integration level; here we just
        verify the endpoint doesn't reject the request.
        """
        import threading

        from certmesh.api.log_buffer import LogBuffer, LogEntry

        buf = LogBuffer(maxlen=100)
        buf.append(LogEntry(timestamp=1.0, level="INFO", logger_name="t", message="hi"))
        app.state.log_buffer = buf

        cookie = _create_session_cookie(app)

        result: dict[str, Any] = {}

        def _fetch() -> None:
            try:
                c = TestClient(app, raise_server_exceptions=False)
                resp = c.get(
                    "/dashboard/api/logs/stream",
                    cookies={"cm_session": cookie},
                )
                result["status"] = resp.status_code
            except (ConnectionError, OSError) as exc:
                result["error"] = str(exc)

        t = threading.Thread(target=_fetch, daemon=True)
        t.start()
        t.join(timeout=3)

        if not t.is_alive():
            assert result.get("status") != 503


class TestErrorResponseSanitization:
    """Verify that provider errors don't leak internal details to clients."""

    def test_provider_error_is_generic(self):
        """When a provider fetch raises, the error message must be generic."""
        from certmesh.api.routes.dashboard.certificates import _collect_provider_certs

        all_certs: list[dict[str, Any]] = []
        errors: list[dict[str, str]] = []

        def _failing_fetch():
            raise ConnectionError(
                "Connection refused: https://vault.internal.corp:8200/v1/pki/certs"
            )

        _collect_provider_certs("vault-pki", _failing_fetch, all_certs, errors)

        assert len(errors) == 1
        err_msg = errors[0]["error"]
        # Must NOT contain internal hostnames/paths
        assert "vault.internal.corp" not in err_msg
        assert "8200" not in err_msg
        assert "/v1/pki" not in err_msg
        # Must contain generic message
        assert "Failed to retrieve vault-pki certificates" in err_msg

    def test_provider_error_preserves_provider_name(self):
        """Error entry includes the provider name for client-side routing."""
        from certmesh.api.routes.dashboard.certificates import _collect_provider_certs

        all_certs: list[dict[str, Any]] = []
        errors: list[dict[str, str]] = []

        def _failing():
            raise RuntimeError("secret/data/certs: permission denied")

        _collect_provider_certs("digicert", _failing, all_certs, errors)
        assert errors[0]["provider"] == "digicert"
        assert "permission denied" not in errors[0]["error"]


# =============================================================================
# _CERT_ID_RE regex validation
# =============================================================================


class TestCertIdRegex:
    """Verify the certificate ID regex rejects malicious inputs."""

    @pytest.fixture()
    def regex(self):
        from certmesh.api.routes.dashboard.helpers import _CERT_ID_RE

        return _CERT_ID_RE

    @pytest.mark.parametrize(
        "valid_id",
        [
            "abc-123",
            "cert.456",
            "a_b_c",
            "39:dd:2e:90",
            "A" * 256,
        ],
    )
    def test_valid_cert_ids_accepted(self, regex, valid_id: str) -> None:
        assert regex.match(valid_id) is not None

    def test_rejects_path_traversal(self, regex) -> None:
        assert regex.match("../../../etc/passwd") is None

    def test_rejects_spaces(self, regex) -> None:
        assert regex.match("cert id with spaces") is None

    def test_rejects_special_chars(self, regex) -> None:
        for char in ";!@#$%^&*()<>|{}":
            assert regex.match(f"id{char}bad") is None, f"Should reject '{char}'"

    def test_rejects_too_long(self, regex) -> None:
        assert regex.match("A" * 300) is None

    def test_rejects_empty(self, regex) -> None:
        assert regex.match("") is None


# =============================================================================
# Session cookie security attributes
# =============================================================================


class TestSessionCookieSecurity:
    """Verify session cookies have proper security attributes."""

    @patch("certmesh.api.oauth2_flow.validate_oauth2_state", return_value=True)
    @patch("certmesh.api.oauth2_flow.fetch_userinfo", new_callable=AsyncMock)
    @patch("certmesh.api.oauth2_flow.exchange_code_for_tokens", new_callable=AsyncMock)
    def test_session_cookie_has_security_flags(
        self,
        mock_exchange,
        mock_userinfo,
        _validate,
        app: FastAPI,
        client: TestClient,
    ) -> None:
        """Session cookie must include HttpOnly, SameSite=lax, and Secure."""
        mock_exchange.return_value = {
            "access_token": "at-123",
            "refresh_token": "rt-456",
            "expires_in": 3600,
        }
        mock_userinfo.return_value = {
            "sub": "user1",
            "name": "Test User",
            "email": "test@example.com",
        }

        sm: SessionManager = app.state.session_manager
        pending_token = sm.create_session(
            {
                "code_verifier": "verifier-abc",
                "csrf_token": "csrf-xyz",
            }
        )

        resp = client.get(
            "/dashboard/callback?code=authcode&state=valid-state",
            cookies={"cm_pending_login": pending_token},
        )
        assert resp.status_code == 302
        set_cookie = resp.headers.get("set-cookie", "")
        assert "httponly" in set_cookie.lower(), "Session cookie must be HttpOnly"
        assert "samesite=lax" in set_cookie.lower(), "Session cookie must be SameSite=lax"


# =============================================================================
# CSRF constant-time comparison
# =============================================================================


class TestCsrfConstantTime:
    """Verify CSRF validation uses hmac.compare_digest."""

    def test_csrf_uses_hmac_compare_digest(self, app: FastAPI, client: TestClient) -> None:
        from certmesh.api.routes.dashboard.helpers import _validate_csrf

        session = {"csrf_token": "test-csrf-token", "user": {"sub": "u"}}

        import hmac as _hmac

        with patch.object(_hmac, "compare_digest", return_value=True) as mock_cmp:
            from starlette.requests import Request

            scope = {"type": "http", "method": "POST", "path": "/test", "headers": []}
            request = Request(scope)
            _validate_csrf(request, session, "test-csrf-token")
            mock_cmp.assert_called_once()
