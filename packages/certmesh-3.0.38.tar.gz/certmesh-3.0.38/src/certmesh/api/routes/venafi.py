"""
certmesh.api.routes.venafi
============================

Venafi Trust Protection Platform (TPP) API endpoints.

Each handler extracts ``venafi_cfg``, ``vault_cfg``, and ``vault_client``
from ``request.app.state``, authenticates a Venafi session, and forwards
to the provider functions in ``certmesh.providers.venafi_client``.

Supports both TPP v23 (SDK 23.x) and v25.3 (SDK 25.3).

Spec reference:
    https://docs.venafi.com/Docs/current/TopNav/Content/SDK/WebSDK/API_reference.htm
"""

from __future__ import annotations

import dataclasses
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Query, Request

from certmesh.api.dependencies import get_auth, get_venafi_deps
from certmesh.api.metrics import track_cert_op
from certmesh.api.schemas import (
    PaginatedResponse,
    VenafiCertificateDetailResponse,
    VenafiRenewRequest,
    VenafiRenewResponse,
    VenafiRevokeRequest,
    VenafiSearchRequest,
)

router = APIRouter(prefix="/api/v1/venafi", tags=["venafi"])


@router.get("/certificates", response_model=PaginatedResponse)
async def list_certificates(
    request: Request,
    claims: Annotated[Any, Depends(get_auth)],
    limit: Annotated[int, Query(ge=1, le=1000)] = 100,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> PaginatedResponse:
    """List managed Venafi certificates.

    Calls ``vc.list_certificates`` which maps to
    ``GET /vedsdk/Certificates/`` with ``Limit`` and ``Offset`` parameters.
    """
    from certmesh.providers import venafi_client as vc

    venafi_cfg, vault_cfg, vault_cl = get_venafi_deps(request)
    session = None
    try:
        session = vc.authenticate(venafi_cfg, vault_cfg, vault_cl)
        with track_cert_op("venafi", "list"):
            certs = vc.list_certificates(session, venafi_cfg, limit=limit, offset=offset)
        items = [dataclasses.asdict(c) for c in certs]
        return PaginatedResponse(
            items=items,
            page=(offset // limit) + 1 if limit > 0 else 1,
            per_page=limit,
            total=len(items),
        )
    finally:
        if session is not None:
            session.close()


@router.post("/certificates/search", response_model=PaginatedResponse)
async def search_certificates(
    request: Request,
    body: VenafiSearchRequest,
    claims: Annotated[Any, Depends(get_auth)],
) -> PaginatedResponse:
    """Search certificates by criteria.

    Calls ``vc.search_certificates`` which forwards filters to
    ``GET /vedsdk/Certificates/`` with appropriate query parameters.
    """
    from certmesh.providers import venafi_client as vc

    venafi_cfg, vault_cfg, vault_cl = get_venafi_deps(request)
    session = None
    try:
        session = vc.authenticate(venafi_cfg, vault_cfg, vault_cl)
        with track_cert_op("venafi", "search"):
            certs = vc.search_certificates(
                session,
                venafi_cfg,
                common_name=body.common_name or None,
                san_dns=body.san_dns or None,
                thumbprint=body.thumbprint or None,
                serial_number=body.serial_number or None,
                issuer=body.issuer or None,
                key_size=body.key_size,
                stage=body.stage,
                limit=body.limit,
                offset=body.offset,
            )
        items = [dataclasses.asdict(c) for c in certs]
        return PaginatedResponse(
            items=items,
            page=(body.offset // body.limit) + 1 if body.limit > 0 else 1,
            per_page=body.limit,
            total=len(items),
        )
    finally:
        if session is not None:
            session.close()


@router.get(
    "/certificates/{guid}",
    response_model=VenafiCertificateDetailResponse,
)
async def get_certificate(
    request: Request,
    guid: str,
    claims: Annotated[Any, Depends(get_auth)],
) -> VenafiCertificateDetailResponse:
    """Get details of a specific Venafi certificate by GUID.

    Calls ``vc.describe_certificate`` which maps to
    ``GET /vedsdk/Certificates/{guid}``.
    """
    from certmesh.providers import venafi_client as vc

    venafi_cfg, vault_cfg, vault_cl = get_venafi_deps(request)
    session = None
    try:
        session = vc.authenticate(venafi_cfg, vault_cfg, vault_cl)
        with track_cert_op("venafi", "describe"):
            detail = vc.describe_certificate(session, venafi_cfg, certificate_guid=guid)
        return VenafiCertificateDetailResponse(
            guid=detail.guid,
            dn=detail.dn,
            name=detail.name,
            serial_number=detail.serial_number,
            thumbprint=detail.thumbprint,
            valid_from=detail.valid_from,
            valid_to=detail.valid_to,
            issuer=detail.issuer,
            subject=detail.subject,
            key_algorithm=detail.key_algorithm,
            key_size=detail.key_size,
            san_dns_names=detail.san_dns_names,
            stage=detail.stage,
            status=detail.status,
            in_error=detail.in_error,
        )
    finally:
        if session is not None:
            session.close()


@router.post("/certificates/{guid}/renew", response_model=VenafiRenewResponse)
async def renew_certificate(
    request: Request,
    guid: str,
    claims: Annotated[Any, Depends(get_auth)],
    body: VenafiRenewRequest | None = None,
) -> VenafiRenewResponse:
    """Trigger renewal for a Venafi certificate.

    Calls ``vc.renew_and_download_certificate`` which maps to
    ``POST /vedsdk/Certificates/Renew``, polls for completion, and
    downloads the renewed certificate material.
    """
    from certmesh.providers import venafi_client as vc

    venafi_cfg, vault_cfg, vault_cl = get_venafi_deps(request)
    session = None
    try:
        session = vc.authenticate(venafi_cfg, vault_cfg, vault_cl)
        with track_cert_op("venafi", "renew"):
            bundle = vc.renew_and_download_certificate(
                session,
                venafi_cfg,
                vault_cfg,
                vault_cl,
                certificate_guid=guid,
            )
        return VenafiRenewResponse(
            guid=guid,
            common_name=bundle.common_name,
            serial_number=bundle.serial_number,
            not_after=bundle.not_after.isoformat() if bundle.not_after else "",
        )
    finally:
        if session is not None:
            session.close()


@router.post("/certificates/{guid}/revoke")
async def revoke_certificate(
    request: Request,
    guid: str,
    body: VenafiRevokeRequest,
    claims: Annotated[Any, Depends(get_auth)],
) -> dict[str, str]:
    """Revoke a certificate in Venafi TPP.

    Calls ``vc.revoke_certificate`` which maps to
    ``POST /vedsdk/Certificates/Revoke``.
    Reason codes follow RFC 5280 CRLReason (0-5).
    """
    from certmesh.providers import venafi_client as vc

    venafi_cfg, vault_cfg, vault_cl = get_venafi_deps(request)
    session = None
    try:
        session = vc.authenticate(venafi_cfg, vault_cfg, vault_cl)
        with track_cert_op("venafi", "revoke"):
            # Resolve DN from GUID for the revocation call
            detail = vc.describe_certificate(session, venafi_cfg, certificate_guid=guid)
            vc.revoke_certificate(
                session,
                venafi_cfg,
                certificate_dn=detail.dn,
                reason=body.reason,
                comments=body.comments,
                disable=body.disable,
            )
        return {"status": "revoked", "guid": guid}
    finally:
        if session is not None:
            session.close()
