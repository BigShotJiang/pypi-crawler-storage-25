"""Dashboard certificate data API routes."""

from __future__ import annotations

import dataclasses
import logging
import time
from datetime import datetime, timezone
from typing import Annotated, Any, Literal

from fastapi import APIRouter, HTTPException, Path, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from .helpers import (
    SUPPORTED_PROVIDERS,
    _get_dashboard_state,
    _get_session,
    _get_templates,
    _require_session,
    _validate_cert_id,
    _validate_csrf,
)

logger = logging.getLogger(__name__)

router = APIRouter()

_EXPIRY_DATE_FORMATS = (
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d",
    "%Y-%m-%d %H:%M:%S",
)

_EXPIRY_FIELD_NAMES = ("not_after", "valid_till", "valid_to", "approx_not_after", "expiration")


def _collect_provider_certs(
    provider_name: str,
    fetch_fn: Any,
    all_certs: list[dict[str, Any]],
    errors: list[dict[str, str]],
) -> None:
    """Fetch certificates from a provider, appending to *all_certs* / *errors*."""
    try:
        certs = fetch_fn()
        for cert in certs:
            cert_dict = dataclasses.asdict(cert) if dataclasses.is_dataclass(cert) else cert
            cert_dict["provider"] = provider_name
            all_certs.append(cert_dict)
    except Exception as exc:  # noqa: BLE001 - dashboard aggregation; provider errors must not crash page
        logger.warning("Failed to fetch %s certificates", provider_name, extra={"error": str(exc)})
        # Return a generic message to avoid leaking internal paths/hostnames
        errors.append(
            {
                "provider": provider_name,
                "error": f"Failed to retrieve {provider_name} certificates.",
            }
        )


@router.get("/api/certificates")
async def api_certificates(request: Request) -> JSONResponse:
    """JSON API returning certificate data from all configured providers.

    Returns a consolidated list of certificates with provider, status,
    expiry date, and common name.  Used by the dashboard frontend for
    rendering the certificate table and summary cards.
    """
    _require_session(request)

    all_certs: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []

    config = request.app.state.config
    vault_cfg = config.get("vault", {})
    vault_cl = getattr(request.app.state, "vault_client", None)

    if config.get("digicert"):
        from certmesh.providers import digicert_client as dc

        _collect_provider_certs(
            "digicert",
            lambda: dc.list_issued_certificates(config["digicert"], vault_cfg, vault_cl),
            all_certs,
            errors,
        )

    if config.get("venafi"):
        from certmesh.providers import venafi_client as vc

        _collect_provider_certs(
            "venafi",
            lambda: vc.list_certificates(config["venafi"], vault_cfg, vault_cl),
            all_certs,
            errors,
        )

    if config.get("acm"):
        from certmesh.providers import acm_client

        _collect_provider_certs(
            "acm",
            lambda: acm_client.list_certificates(config["acm"]),
            all_certs,
            errors,
        )

    if config.get("vault_pki") and vault_cl:
        from certmesh.providers import vault_pki_client as vpki

        vault_pki_cfg = config.get("vault_pki", vault_cfg)
        _collect_provider_certs(
            "vault_pki",
            lambda: vpki.list_certificates(vault_pki_cfg, vault_cl),
            all_certs,
            errors,
        )

    if config.get("letsencrypt"):
        from certmesh.providers import letsencrypt_client as le

        _collect_provider_certs(
            "letsencrypt",
            lambda: le.list_certificates(config["letsencrypt"]),
            all_certs,
            errors,
        )

    # Store snapshot in dashboard state
    dashboard_state = _get_dashboard_state(request)
    dashboard_state.put(
        "latest_snapshot",
        {
            "certificates": all_certs,
            "errors": errors,
            "timestamp": time.time(),
        },
    )

    return JSONResponse(
        content={
            "certificates": all_certs,
            "errors": errors,
            "total": len(all_certs),
        }
    )


@router.post("/api/certificates/{provider}/{cert_id}/renew")
async def api_renew_certificate(
    request: Request,
    provider: Literal["digicert", "venafi", "acm"],
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> JSONResponse:
    """Trigger certificate renewal for a specific certificate.

    Validates the CSRF token from the ``X-CSRF-Token`` header before
    proceeding.

    Args:
        provider: Certificate provider (``digicert``, ``venafi``, ``acm``).
        cert_id: Provider-specific certificate identifier.
    """
    session = _require_session(request)
    csrf_token = request.headers.get("X-CSRF-Token", "")
    _validate_csrf(request, session, csrf_token)

    _validate_cert_id(cert_id)

    config = request.app.state.config
    result: dict[str, Any] = {"provider": provider, "certificate_id": cert_id, "action": "renew"}

    try:
        if provider == "venafi":
            from certmesh.providers import venafi_client as vc

            venafi_cfg = config.get("venafi", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            renewal = vc.renew_certificate(cert_id, venafi_cfg, vault_cfg, vault_cl)
            result["status"] = "success"
            result["detail"] = (
                dataclasses.asdict(renewal) if dataclasses.is_dataclass(renewal) else renewal
            )
        elif provider == "digicert":
            result["status"] = "error"
            result["detail"] = (
                "DigiCert certificates cannot be renewed directly. "
                "Please reorder the certificate through the DigiCert portal."
            )
            return JSONResponse(content=result, status_code=400)
        elif provider == "acm":
            result["status"] = "error"
            result["detail"] = (
                "ACM certificates are renewed automatically by AWS. No manual renewal is required."
            )
            return JSONResponse(content=result, status_code=400)
    except Exception:
        logger.exception(
            "Certificate renewal failed",
            extra={"provider": provider, "cert_id": cert_id},
        )
        result["status"] = "error"
        result["detail"] = "Certificate renewal failed. Check server logs for details."
        return JSONResponse(content=result, status_code=500)

    # Record in renewal history (atomic append avoids race across workers)
    dashboard_state = _get_dashboard_state(request)
    dashboard_state.append_to_list(
        "renewal_history",
        {
            "provider": provider,
            "certificate_id": cert_id,
            "action": "renew",
            "status": result["status"],
            "timestamp": time.time(),
            "user": session.get("user", {}).get("email", ""),
        },
        max_items=100,
    )

    return JSONResponse(content=result)


@router.post("/api/certificates/{provider}/{cert_id}/revoke")
async def api_revoke_certificate(
    request: Request,
    provider: Literal["digicert", "venafi", "acm", "vault_pki"],
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> JSONResponse:
    """Trigger certificate revocation for a specific certificate.

    Validates the CSRF token from the ``X-CSRF-Token`` header before
    proceeding.

    Args:
        provider: Certificate provider (``digicert``, ``venafi``, ``acm``, ``vault_pki``).
        cert_id: Provider-specific certificate identifier.
    """
    session = _require_session(request)
    csrf_token = request.headers.get("X-CSRF-Token", "")
    _validate_csrf(request, session, csrf_token)

    _validate_cert_id(cert_id)

    config = request.app.state.config
    result: dict[str, Any] = {"provider": provider, "certificate_id": cert_id, "action": "revoke"}

    try:
        if provider == "venafi":
            from certmesh.providers import venafi_client as vc

            venafi_cfg = config.get("venafi", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            revocation = vc.revoke_certificate(cert_id, venafi_cfg, vault_cfg, vault_cl)
            result["status"] = "success"
            result["detail"] = (
                dataclasses.asdict(revocation)
                if dataclasses.is_dataclass(revocation)
                else str(revocation)
            )
        elif provider == "digicert":
            from certmesh.providers import digicert_client as dc

            digicert_cfg = config.get("digicert", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            dc.revoke_certificate(cert_id, digicert_cfg, vault_cfg, vault_cl)
            result["status"] = "success"
            result["detail"] = "Certificate revocation request submitted."
        elif provider == "vault_pki":
            vault_cl = getattr(request.app.state, "vault_client", None)
            if not vault_cl:
                result["status"] = "error"
                result["detail"] = "Vault PKI client not available."
                return JSONResponse(content=result, status_code=503)
            from certmesh.backends import vault_client as vc

            vault_pki_cfg = config.get("vault_pki", config.get("vault", {})).get("pki", {})
            vc.revoke_pki_certificate(vault_cl, vault_pki_cfg, cert_id)
            result["status"] = "success"
            result["detail"] = "Certificate revocation request submitted."
        elif provider == "acm":
            result["status"] = "error"
            result["detail"] = (
                "ACM certificates cannot be revoked through this dashboard. "
                "Use the AWS Console or CLI to delete the certificate."
            )
            return JSONResponse(content=result, status_code=400)
    except Exception:
        logger.exception(
            "Certificate revocation failed",
            extra={"provider": provider, "cert_id": cert_id},
        )
        result["status"] = "error"
        result["detail"] = "Certificate revocation failed. Check server logs for details."
        return JSONResponse(content=result, status_code=500)

    # Record in renewal history (atomic append avoids race across workers)
    dashboard_state = _get_dashboard_state(request)
    dashboard_state.append_to_list(
        "renewal_history",
        {
            "provider": provider,
            "certificate_id": cert_id,
            "action": "revoke",
            "status": result["status"],
            "timestamp": time.time(),
            "user": session.get("user", {}).get("email", ""),
        },
        max_items=100,
    )

    return JSONResponse(content=result)


@router.get("/certificates/{provider}/{cert_id}", response_class=HTMLResponse)
async def certificate_detail_page(
    request: Request,
    provider: str,
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> Response:
    """Certificate detail page showing full history, logs, and attributes."""
    session = _get_session(request)
    if not session or "user" not in session:
        return RedirectResponse(url="/dashboard/auth/start", status_code=302)

    if provider not in SUPPORTED_PROVIDERS:
        raise HTTPException(status_code=404, detail="Unknown provider.")

    _validate_cert_id(cert_id)

    templates = _get_templates(request)
    return templates.TemplateResponse(
        request,
        "certificate_detail.html",
        {
            "user": session.get("user", {}),
            "csrf_token": session.get("csrf_token", ""),
            "provider": provider,
            "cert_id": cert_id,
        },
    )


def _detail_to_dict(detail: Any) -> dict[str, Any]:
    """Convert a provider detail object to a plain dict."""
    return dataclasses.asdict(detail) if dataclasses.is_dataclass(detail) else dict(detail)


def _fetch_provider_detail(
    provider: str,
    cert_id: str,
    request: Request,
) -> dict[str, Any] | JSONResponse:
    """Fetch certificate detail from the given provider.

    Returns a dict on success or a ``JSONResponse`` for error/unavailable cases.
    """
    config = request.app.state.config

    if provider == "digicert":
        from certmesh.providers import digicert_client as dc

        return _detail_to_dict(
            dc.describe_certificate(
                cert_id,
                config.get("digicert", {}),
                config.get("vault", {}),
                getattr(request.app.state, "vault_client", None),
            )
        )

    if provider == "venafi":
        from certmesh.providers import venafi_client as vc

        return _detail_to_dict(
            vc.describe_certificate(
                cert_id,
                config.get("venafi", {}),
                config.get("vault", {}),
                getattr(request.app.state, "vault_client", None),
            )
        )

    if provider == "acm":
        from certmesh.providers import acm_client

        return _detail_to_dict(acm_client.describe_certificate(cert_id, config.get("acm", {})))

    if provider == "vault_pki":
        vault_cl = getattr(request.app.state, "vault_client", None)
        if not vault_cl:
            return JSONResponse(
                content={"error": "Vault PKI client not available"},
                status_code=503,
            )
        from certmesh.providers import vault_pki_client as vpki

        vault_pki_cfg = config.get("vault_pki", config.get("vault", {}))
        return _detail_to_dict(vpki.describe_certificate(cert_id, vault_pki_cfg, vault_cl))

    return JSONResponse(
        content={"error": f"Unknown provider: {provider}"},
        status_code=400,
    )


@router.get("/api/certificates/{provider}/{cert_id}")
async def api_certificate_detail(
    request: Request,
    provider: str,
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> JSONResponse:
    """Return detailed certificate information from the provider.

    Supports all configured providers: DigiCert, Venafi, ACM, Vault PKI.
    """
    _require_session(request)

    if provider not in SUPPORTED_PROVIDERS:
        raise HTTPException(status_code=404, detail="Unknown provider.")

    _validate_cert_id(cert_id)

    try:
        result = _fetch_provider_detail(provider, cert_id, request)
    except Exception:
        logger.exception(
            "Certificate detail fetch failed",
            extra={"provider": provider, "cert_id": cert_id},
        )
        return JSONResponse(
            content={"error": "Failed to fetch certificate details. Check server logs."},
            status_code=500,
        )

    if isinstance(result, JSONResponse):
        return result

    result["provider"] = provider
    return JSONResponse(content=result)


@router.get("/api/certificates/history")
async def api_certificate_history(
    request: Request,
    provider: str = "",
    cert_id: str = "",
) -> JSONResponse:
    """Return renewal/revocation history for a specific certificate.

    Filters the global renewal_history list by provider and cert_id.
    """
    _require_session(request)

    dashboard_state = _get_dashboard_state(request)
    all_history = dashboard_state.get("renewal_history", [])

    filtered = [
        entry
        for entry in all_history
        if (not provider or entry.get("provider") == provider)
        and (not cert_id or entry.get("certificate_id") == cert_id)
    ]

    # Sort by timestamp descending (newest first)
    filtered.sort(key=lambda x: x.get("timestamp", 0), reverse=True)

    return JSONResponse(content={"history": filtered, "total": len(filtered)})


def _parse_expiry(expiry_str: str) -> datetime | None:
    """Parse a certificate expiry string into a tz-aware datetime, or ``None``."""
    for fmt in _EXPIRY_DATE_FORMATS:
        try:
            return datetime.strptime(expiry_str, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def _expiry_bucket(days_remaining: float) -> str:
    """Return the bucket name for the given number of days until expiry."""
    if days_remaining < 0:
        return "expired"
    if days_remaining < 7:
        return "critical"
    if days_remaining < 30:
        return "warning"
    if days_remaining < 60:
        return "attention"
    return "healthy"


@router.get("/api/timeline")
async def api_timeline(request: Request) -> JSONResponse:
    """Return certificate expiry timeline data.

    Returns certificates grouped by time-to-expiry buckets for
    visualisation as a timeline or progress bar chart.
    """
    _require_session(request)

    dashboard_state = _get_dashboard_state(request)
    snapshot = dashboard_state.get("latest_snapshot", {})
    certs = snapshot.get("certificates", [])

    now = time.time()
    buckets: dict[str, list[dict[str, Any]]] = {
        "expired": [],
        "critical": [],  # < 7 days
        "warning": [],  # 7-30 days
        "attention": [],  # 30-60 days
        "healthy": [],  # > 60 days
        "unknown": [],
    }

    for cert in certs:
        expiry_str = next((cert.get(f) for f in _EXPIRY_FIELD_NAMES if cert.get(f)), "")
        if not expiry_str:
            buckets["unknown"].append(cert)
            continue

        try:
            expiry_dt = _parse_expiry(expiry_str)
            if expiry_dt is None:
                buckets["unknown"].append(cert)
                continue
            days_remaining = (expiry_dt.timestamp() - now) / 86400
            buckets[_expiry_bucket(days_remaining)].append(cert)
        except Exception:  # noqa: BLE001 - timeline bucketing; malformed dates -> unknown bucket
            buckets["unknown"].append(cert)

    summary = {k: len(v) for k, v in buckets.items()}

    return JSONResponse(
        content={
            "buckets": {k: v for k, v in buckets.items()},
            "summary": summary,
            "total": len(certs),
        }
    )
