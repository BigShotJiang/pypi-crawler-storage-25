"""
certmesh.api.routes.dashboard
================================

Web UI dashboard routes for certificate lifecycle management.

Provides a browser-based dashboard with OAuth2 SSO login, certificate
inventory views, renewal/revocation actions, and expiry timeline
visualisation.

All state-changing operations are protected by CSRF tokens.
Auth endpoints are rate-limited.

Routes:
- ``GET  /dashboard``                          -- main dashboard (redirect to login if unauthenticated)
- ``GET  /dashboard/login``                    -- login page
- ``GET  /dashboard/callback``                 -- OAuth2 callback
- ``POST /dashboard/logout``                   -- logout (clear session)
- ``GET  /dashboard/api/certificates``         -- JSON certificate data
- ``POST /dashboard/api/certificates/{provider}/{id}/renew``  -- trigger renewal
- ``POST /dashboard/api/certificates/{provider}/{id}/revoke`` -- trigger revocation
- ``GET  /dashboard/api/timeline``             -- expiry timeline data
- ``GET  /dashboard/api/logs/stream``          -- live log stream (SSE)
"""

from __future__ import annotations

from fastapi import APIRouter, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse

from .auth import router as auth_router
from .certificates import router as certificates_router
from .helpers import (
    _CERT_ID_RE,
    _INVALID_CERT_ID_MSG,
    _LOGIN_AUTH_FAILED_URL,
    _LOGIN_CSRF_INVALID_URL,
    SUPPORTED_PROVIDERS,
    _get_dashboard_state,
    _get_oauth2_flow_config,
    _get_session,
    _get_session_manager,
    _get_templates,
    _require_session,
    _set_session_cookie,
    _validate_cert_id,
    _validate_csrf,
)
from .logs import router as logs_router

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("", response_class=HTMLResponse)
async def dashboard_index(request: Request) -> Response:
    """Main dashboard page.

    Redirects to the SSO provider if the user is not authenticated.
    Shows certificate inventory, status summary, and expiry timeline.
    """
    session = _get_session(request)
    if not session or "user" not in session:
        return RedirectResponse(url="/dashboard/auth/start", status_code=302)

    templates = _get_templates(request)
    user = session.get("user", {})
    csrf_token = session.get("csrf_token", "")

    return templates.TemplateResponse(
        request,
        "dashboard.html",
        {
            "user": user,
            "csrf_token": csrf_token,
        },
    )


router.include_router(auth_router)
router.include_router(certificates_router)
router.include_router(logs_router)

# Re-export public names for backward compatibility
__all__ = [
    "SUPPORTED_PROVIDERS",
    "_CERT_ID_RE",
    "_INVALID_CERT_ID_MSG",
    "_LOGIN_AUTH_FAILED_URL",
    "_LOGIN_CSRF_INVALID_URL",
    "_get_dashboard_state",
    "_get_oauth2_flow_config",
    "_get_session",
    "_get_session_manager",
    "_get_templates",
    "_require_session",
    "_set_session_cookie",
    "_validate_cert_id",
    "_validate_csrf",
    "router",
]
