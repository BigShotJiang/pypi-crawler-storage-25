"""Shared helpers, constants, and utility functions for dashboard routes."""

from __future__ import annotations

import hmac
import logging
import re
from typing import Any

from fastapi import HTTPException, Request, Response, status

logger = logging.getLogger(__name__)

# Allowed certificate ID pattern (alphanumeric, hyphens, underscores, dots, colons).
_CERT_ID_RE = re.compile(r"^[a-zA-Z0-9\-_.:]{1,256}$")

# Duplicated URL / message constants
_LOGIN_AUTH_FAILED_URL = "/dashboard/login?error=auth_failed"
_LOGIN_CSRF_INVALID_URL = "/dashboard/login?error=csrf_invalid"
_INVALID_CERT_ID_MSG = "Invalid certificate ID format."

# Supported certificate providers.
SUPPORTED_PROVIDERS = ("digicert", "venafi", "acm", "vault_pki")


# ── Helper functions ──────────────────────────────────────────────────────────


def _get_templates(request: Request) -> Any:
    """Return the Jinja2Templates instance from app state."""
    return request.app.state.dashboard_templates


def _get_session_manager(request: Request) -> Any:
    """Return the SessionManager from app state."""
    return request.app.state.session_manager


def _get_oauth2_flow_config(request: Request) -> Any:
    """Return the OAuth2FlowConfig from app state."""
    return request.app.state.oauth2_flow_config


def _get_dashboard_state(request: Request) -> Any:
    """Return the DashboardStateStore from app state."""
    return request.app.state.dashboard_state


def _get_session(request: Request) -> dict[str, Any] | None:
    """Extract and validate the session from the request cookie."""
    session_manager = _get_session_manager(request)
    cookie = request.cookies.get("cm_session")
    if not cookie:
        return None
    return session_manager.load_session(cookie)


def _require_session(request: Request) -> dict[str, Any]:
    """Require a valid session or raise 401."""
    session = _get_session(request)
    if not session or "user" not in session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated. Please log in at /dashboard/login.",
        )
    return session


def _validate_csrf(request: Request, session: dict[str, Any], form_token: str) -> None:
    """Validate a CSRF token from a form submission against the session."""
    session_csrf = session.get("csrf_token", "")
    if not session_csrf or not form_token or not hmac.compare_digest(form_token, session_csrf):
        logger.warning(
            "CSRF validation failed",
            extra={"path": request.url.path},
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token validation failed. Please reload the page and try again.",
        )


def _validate_cert_id(cert_id: str) -> None:
    """Validate a certificate ID against the allowed pattern.

    Raises ``HTTPException(400)`` if the ID contains disallowed characters
    or exceeds the maximum length.
    """
    if not _CERT_ID_RE.match(cert_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=_INVALID_CERT_ID_MSG,
        )


def _set_session_cookie(response: Response, token: str, max_age: int) -> None:
    """Set the session cookie with security attributes."""
    response.set_cookie(
        key="cm_session",
        value=token,
        max_age=max_age,
        httponly=True,
        samesite="lax",
        secure=True,
        path="/dashboard",
    )
