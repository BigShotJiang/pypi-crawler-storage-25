"""Dashboard authentication routes (login, callback, logout)."""

from __future__ import annotations

import logging
import time

from fastapi import APIRouter, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse

from .helpers import (
    _LOGIN_AUTH_FAILED_URL,
    _LOGIN_CSRF_INVALID_URL,
    _get_oauth2_flow_config,
    _get_session,
    _get_session_manager,
    _get_templates,
    _set_session_cookie,
    _validate_csrf,
)

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/login", response_class=HTMLResponse)
async def dashboard_login(request: Request) -> Response:
    """Login page with SSO redirect button.

    If already authenticated, redirects to the dashboard.
    Displays error messages passed via query parameters.
    """
    session = _get_session(request)
    if session and "user" in session:
        return RedirectResponse(url="/dashboard", status_code=302)

    templates = _get_templates(request)
    error = request.query_params.get("error", "")

    # Map error codes to user-friendly messages
    error_messages: dict[str, str] = {
        "auth_failed": (
            "Authentication failed. Please check your credentials and try again. "
            "If the problem persists, contact your administrator."
        ),
        "token_expired": ("Your session has expired. Please sign in again to continue."),
        "csrf_invalid": (
            "Security validation failed. This can happen if you used the browser's "
            "back button. Please try signing in again."
        ),
        "callback_error": (
            "An error occurred during sign-in. Please try again. "
            "If the problem persists, check the server logs for details."
        ),
        "session_expired": ("Your session has expired due to inactivity. Please sign in again."),
    }
    error_message = error_messages.get(error, "")

    return templates.TemplateResponse(
        request,
        "login.html",
        {
            "error": error_message,
        },
    )


@router.get("/callback")
async def dashboard_callback(request: Request) -> Response:
    """OAuth2 callback handler.

    Exchanges the authorization code for tokens, fetches user info,
    creates a session, and redirects to the dashboard.
    """
    from certmesh.api.oauth2_flow import (
        exchange_code_for_tokens,
        fetch_userinfo,
        generate_csrf_token,
        validate_oauth2_state,
    )

    code = request.query_params.get("code")
    state = request.query_params.get("state")
    error = request.query_params.get("error")

    if error:
        error_desc = request.query_params.get("error_description", "Unknown error")
        logger.warning(
            "OAuth2 callback received error",
            extra={"error": error, "description": error_desc},
        )
        return RedirectResponse(url=_LOGIN_AUTH_FAILED_URL, status_code=302)

    if not code or not state:
        logger.warning("OAuth2 callback missing code or state parameter")
        return RedirectResponse(url="/dashboard/login?error=callback_error", status_code=302)

    session_manager = _get_session_manager(request)
    oauth2_config = _get_oauth2_flow_config(request)

    # Validate state parameter against the pending login session
    pending_cookie = request.cookies.get("cm_pending_login")
    if not pending_cookie:
        logger.warning("OAuth2 callback: no pending login cookie found")
        return RedirectResponse(url=_LOGIN_CSRF_INVALID_URL, status_code=302)

    pending_session = session_manager.load_session(pending_cookie)
    if not pending_session:
        logger.warning("OAuth2 callback: pending login session expired or invalid")
        return RedirectResponse(url=_LOGIN_CSRF_INVALID_URL, status_code=302)

    expected_csrf = pending_session.get("csrf_token", "")
    if not validate_oauth2_state(session_manager, state, expected_csrf):
        return RedirectResponse(url=_LOGIN_CSRF_INVALID_URL, status_code=302)

    code_verifier = pending_session.get("code_verifier", "")
    if not code_verifier:
        logger.warning("OAuth2 callback: no code verifier in pending session")
        return RedirectResponse(url="/dashboard/login?error=callback_error", status_code=302)

    # Exchange code for tokens
    try:
        token_response = await exchange_code_for_tokens(oauth2_config, code, code_verifier)
    except Exception:
        logger.exception("OAuth2 token exchange failed")
        return RedirectResponse(url=_LOGIN_AUTH_FAILED_URL, status_code=302)

    access_token = token_response.get("access_token", "")
    if not access_token:
        logger.warning("OAuth2 token response missing access_token")
        return RedirectResponse(url=_LOGIN_AUTH_FAILED_URL, status_code=302)

    # Fetch user info
    try:
        userinfo = await fetch_userinfo(oauth2_config, access_token)
    except Exception:
        logger.exception("OAuth2 userinfo fetch failed")
        # Still create session with basic info from token
        userinfo = {"sub": "unknown", "name": "User", "email": ""}

    # SEC-19: Create a new session with rotated ID (session fixation protection)
    csrf_token = generate_csrf_token()
    session_data = {
        "user": {
            "sub": userinfo.get("sub", ""),
            "name": userinfo.get("name", userinfo.get("preferred_username", "User")),
            "email": userinfo.get("email", ""),
        },
        "access_token": access_token,
        "refresh_token": token_response.get("refresh_token", ""),
        "token_expires_at": time.time() + token_response.get("expires_in", 3600),
        "csrf_token": csrf_token,
    }
    session_token = session_manager.create_session(session_data)

    response = RedirectResponse(url="/dashboard", status_code=302)
    _set_session_cookie(response, session_token, session_manager.max_age)

    # Clear the pending login cookie
    response.delete_cookie("cm_pending_login", path="/dashboard")

    subject = userinfo.get("sub", "unknown")
    logger.info(
        "Dashboard login successful",
        extra={"subject": subject, "email": userinfo.get("email", "")},
    )

    return response


@router.get("/auth/start")
async def dashboard_auth_start(request: Request) -> Response:
    """Start the OAuth2 Authorization Code Flow with PKCE.

    Generates PKCE code verifier/challenge, CSRF state parameter,
    stores them in a temporary session cookie, and redirects to the
    identity provider.
    """
    from certmesh.api.oauth2_flow import (
        build_authorization_url,
        generate_code_challenge,
        generate_code_verifier,
        generate_csrf_token,
        generate_oauth2_state,
    )

    session_manager = _get_session_manager(request)
    oauth2_config = _get_oauth2_flow_config(request)

    if not oauth2_config.issuer_url or not oauth2_config.client_id:
        templates = _get_templates(request)
        return templates.TemplateResponse(
            request,
            "error.html",
            {
                "error_title": "SSO Not Configured",
                "error_message": (
                    "OAuth2 single sign-on is not configured for this dashboard. "
                    "Please set CM_OAUTH2_ISSUER_URL and CM_OAUTH2_CLIENT_ID "
                    "environment variables and restart the application."
                ),
                "error_code": 503,
            },
            status_code=503,
        )

    # Generate PKCE code verifier and challenge
    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)

    # Generate CSRF token and OAuth2 state
    csrf_token = generate_csrf_token()
    state = generate_oauth2_state(session_manager, csrf_token)

    # Store in a short-lived pending login session
    pending_data = {
        "code_verifier": code_verifier,
        "csrf_token": csrf_token,
    }
    pending_token = session_manager.create_session(pending_data)

    # Build authorization URL
    auth_url = build_authorization_url(oauth2_config, state, code_challenge)

    response = RedirectResponse(url=auth_url, status_code=302)
    response.set_cookie(
        key="cm_pending_login",
        value=pending_token,
        max_age=600,  # 10 minutes for the auth flow
        httponly=True,
        samesite="lax",
        secure=True,
        path="/dashboard",
    )

    return response


@router.post("/logout")
async def dashboard_logout(request: Request) -> Response:
    """Logout: clear the session cookie and redirect to login.

    Validates the CSRF token before proceeding.
    """
    session = _get_session(request)

    # Validate CSRF token from the form body when session is available.
    # If the session is already expired we still clear the cookies below
    # (there is nothing to protect), but an active session must prove the
    # logout was intentional.
    if session:
        form = await request.form()
        form_token = str(form.get("csrf_token", ""))
        _validate_csrf(request, session, form_token)

    response = RedirectResponse(url="/dashboard/login", status_code=302)
    response.delete_cookie("cm_session", path="/dashboard")
    response.delete_cookie("cm_pending_login", path="/dashboard")

    if session:
        subject = session.get("user", {}).get("sub", "unknown")
        logger.info("Dashboard logout", extra={"subject": subject})

    return response
