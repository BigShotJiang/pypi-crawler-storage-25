"""Dashboard live log streaming API routes."""

from __future__ import annotations

import asyncio
import json
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import StreamingResponse

from .helpers import _require_session

router = APIRouter()


def _get_log_buffer(request: Request) -> Any:
    """Return the LogBuffer from app state, or None."""
    return getattr(request.app.state, "log_buffer", None)


@router.get("/api/logs/stream")
async def api_logs_stream(request: Request) -> StreamingResponse:
    """Server-Sent Events endpoint for live log streaming.

    Streams log entries in real time as SSE ``data:`` frames.
    Sends recent history on connect, then new entries as they arrive.
    Requires an authenticated dashboard session.
    """
    _require_session(request)

    log_buffer = _get_log_buffer(request)
    if log_buffer is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Log streaming is not available.",
        )

    async def event_generator() -> Any:
        try:
            async for entry in log_buffer.subscribe():
                # Check if client disconnected.
                if await request.is_disconnected():
                    break
                data = json.dumps(entry.to_dict(), default=str)
                yield f"data: {data}\n\n"
        except (asyncio.CancelledError, GeneratorExit):
            # Normal termination when the client disconnects or the task is cancelled.
            pass

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
