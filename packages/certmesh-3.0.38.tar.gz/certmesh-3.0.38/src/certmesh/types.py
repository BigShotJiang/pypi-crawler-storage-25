"""
certmesh.types
===============

Typed dictionaries for well-known configuration sections.

These TypedDicts provide IDE autocompletion and static type-checking
for the nested config dicts extracted from ``build_config()``.  They
use ``total=False`` because every field has a default and callers
frequently pass partial dicts.

The top-level merged config remains ``JsonDict`` (``dict[str, Any]``)
because it is dynamically composed from YAML + environment variables.
"""

from __future__ import annotations

from typing import TypedDict

# ---------------------------------------------------------------------------
# Vault
# ---------------------------------------------------------------------------


class VaultApproleConfig(TypedDict, total=False):
    """Vault AppRole auth configuration."""

    role_id_env: str
    secret_id_env: str


class VaultLdapConfig(TypedDict, total=False):
    """Vault LDAP auth configuration."""

    username_env: str
    password_env: str
    mount_point: str


class VaultAwsIamConfig(TypedDict, total=False):
    """Vault AWS IAM auth configuration."""

    role: str
    mount_point: str
    region: str | None
    header_value: str | None


class VaultPkiConfig(TypedDict, total=False):
    """Vault PKI engine configuration."""

    mount_point: str
    role_name: str
    ttl: str
    max_ttl: str


class VaultConfig(TypedDict, total=False):
    """Top-level Vault configuration section."""

    url: str
    auth_method: str
    tls_verify: bool
    timeout_seconds: int
    approle: VaultApproleConfig
    ldap: VaultLdapConfig
    aws_iam: VaultAwsIamConfig
    kv_version: int
    pki: VaultPkiConfig
    paths: dict[str, str]


# ---------------------------------------------------------------------------
# Output (shared across providers)
# ---------------------------------------------------------------------------


class OutputConfig(TypedDict, total=False):
    """Certificate output / persistence configuration."""

    destination: str | list[str]
    base_path: str
    cert_filename: str
    key_filename: str
    chain_filename: str
    vault_path_template: str
    sm_secret_name_template: str
    sm_region: str


# ---------------------------------------------------------------------------
# Retry / circuit breaker (shared across providers)
# ---------------------------------------------------------------------------


class RetryConfig(TypedDict, total=False):
    """Retry policy configuration."""

    max_attempts: int
    wait_min_seconds: int | float
    wait_max_seconds: int | float
    wait_multiplier: float


class CircuitBreakerConfig(TypedDict, total=False):
    """Circuit breaker configuration."""

    failure_threshold: int
    recovery_timeout_seconds: int | float


class PollingConfig(TypedDict, total=False):
    """Polling configuration for async certificate issuance."""

    interval_seconds: int
    max_wait_seconds: int


# ---------------------------------------------------------------------------
# DigiCert
# ---------------------------------------------------------------------------


class DigiCertSubjectConfig(TypedDict, total=False):
    """DigiCert certificate subject fields."""

    country: str
    state: str
    locality: str
    organisation: str
    organisational_unit: str


class DigiCertCertificateConfig(TypedDict, total=False):
    """DigiCert certificate parameters."""

    key_size: int
    product_name_id: str
    validity_years: int
    signature_hash: str
    organization_id: int | None
    subject: DigiCertSubjectConfig


class DigiCertConfig(TypedDict, total=False):
    """Top-level DigiCert configuration section."""

    base_url: str
    timeout_seconds: int
    tls_verify: bool
    ca_bundle: str
    output: OutputConfig
    certificate: DigiCertCertificateConfig
    polling: PollingConfig
    retry: RetryConfig
    circuit_breaker: CircuitBreakerConfig


# ---------------------------------------------------------------------------
# Venafi
# ---------------------------------------------------------------------------


class VenafiCertificateConfig(TypedDict, total=False):
    """Venafi certificate parameters."""

    key_size: int
    pkcs12_export_passphrase_env: str


class VenafiApprovalConfig(TypedDict, total=False):
    """Venafi workflow approval configuration."""

    reason: str


class VenafiConfig(TypedDict, total=False):
    """Top-level Venafi configuration section."""

    base_url: str
    auth_method: str
    oauth_client_id: str
    oauth_scope: str
    tls_verify: bool
    timeout_seconds: int
    output: OutputConfig
    certificate: VenafiCertificateConfig
    approval: VenafiApprovalConfig
    polling: PollingConfig
    retry: RetryConfig
    circuit_breaker: CircuitBreakerConfig


# ---------------------------------------------------------------------------
# AWS ACM
# ---------------------------------------------------------------------------


class AcmCertificateConfig(TypedDict, total=False):
    """ACM certificate request parameters."""

    key_algorithm: str
    validation_method: str
    idempotency_token: str


class AcmPrivateCaConfig(TypedDict, total=False):
    """ACM Private CA configuration."""

    ca_arn: str
    signing_algorithm: str
    validity_days: int
    template_arn: str


class AcmConfig(TypedDict, total=False):
    """Top-level ACM configuration section."""

    region: str
    timeout_seconds: int
    output: OutputConfig
    certificate: AcmCertificateConfig
    private_ca: AcmPrivateCaConfig
    polling: PollingConfig


# ---------------------------------------------------------------------------
# Remote CLI
# ---------------------------------------------------------------------------


class RemoteConfig(TypedDict, total=False):
    """Remote certmesh API client configuration."""

    url: str
    timeout_seconds: int
    ca_cert: str
    verify_tls: bool
    retry_attempts: int
    retry_backoff_multiplier: float
    circuit_breaker_threshold: int
    circuit_breaker_recovery_seconds: int


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------


class LoggingConfig(TypedDict, total=False):
    """Logging configuration section."""

    level: str
    format: str
    datefmt: str
    log_format: str
