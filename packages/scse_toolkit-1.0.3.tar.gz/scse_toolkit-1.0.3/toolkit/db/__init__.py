"""SQLAlchemy-based database abstraction layer.

This module provides a comprehensive toolkit for building type-safe database operations
using SQLAlchemy, with support for ORM models, repositories, and query filtering.

Core Components
===============

Models (toolkit.db.models)
--------------------------
    - :class:`~toolkit.db.models.DeclarativeBase`: Base class for all mapped classes
    - :class:`~toolkit.db.models.HasTablename`: Mixin for automatic table naming conventions
    - :class:`~toolkit.db.models.HasConventionalMetadata`: Mixin for metadata configuration with naming conventions

Executors (toolkit.db.executor)
-------------------------------
    - :class:`~toolkit.db.executor.ConnectionExecutor`: Manages database operations using SQLAlchemy connections
    - :class:`~toolkit.db.executor.SessionExecutor`: Manages database operations using SQLAlchemy ORM sessions

Query Targets (toolkit.db.target)
---------------------------------
    - :class:`~toolkit.db.target.AbstractQueryTarget`: Abstract base for query generation and execution
    - :class:`~toolkit.db.target.TableTarget`: Target for direct table-level operations
    - :class:`~toolkit.db.target.ModelTarget`: Target for ORM model-based operations
    - :class:`~toolkit.db.target.ExtendedTarget`: Extends :class:`~toolkit.db.target.ModelTarget` with support for related columns

Filtering (toolkit.db.filter)
-----------------------------
    - :class:`~toolkit.db.filter.Filter`: Advanced query filtering with schema-based validation and relationship traversal

Repositories (toolkit.db.repositories)
--------------------------------------
    - :class:`~toolkit.db.repositories.BaseRepository`: Generic repository pattern implementation for CRUD operations
    - :class:`~toolkit.db.repositories.ItemRepository`: High-level interface for single-item operations
    - :class:`~toolkit.db.repositories.AbstractDataFrameRepository`: Base for dataframe-backed repositories
    - :class:`~toolkit.db.repositories.PandasRepository`: Pandas DataFrame integration for bulk operations

Special Types (toolkit.db.types)
--------------------------------
    - Annotated column types: ``DateTime``, ``Integer``, ``String``, ``Boolean``, ``Float``
    - :class:`~toolkit.db.types.IntegerId`: Auto-incrementing primary key type
    - JSON column types: ``Json``, ``JsonDict``, ``JsonList``

Example Usage
=============

.. code:: python

    from toolkit.db import (
        DeclarativeBase,
        ItemRepository,
        ModelTarget,
        SessionExecutor,
        types,
    )

    class User(DeclarativeBase):
        __tablename__ = "users"
        id: types.IntegerId
        name: types.String

    executor = SessionExecutor(session)
    target = ModelTarget(User)

    repo = ItemRepository(executor, target)
    repo.create({"name": "foo"})
    repo.create({"name": "bar"})

    repo.list()
    #> [User(id=1, name="foo"), User(id=2, name="bar")]


"""

import sqlite3
from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlalchemy import event

from .executor import ConnectionExecutor as ConnectionExecutor
from .executor import SessionExecutor as SessionExecutor
from .filter import Filter as Filter
from .models import DeclarativeBase as DeclarativeBase
from .models import HasConventionalMetadata as HasConventionalMetadata
from .models import HasTablename as HasTablename
from .repositories import AbstractDataFrameRepository as AbstractDataFrameRepository
from .repositories import BaseRepository as BaseRepository
from .repositories import ItemRepository as ItemRepository
from .repositories import PandasRepository as PandasRepository
from .target import AbstractQueryTarget as AbstractQueryTarget
from .target import ExtendedTarget as ExtendedTarget
from .target import ModelTarget as ModelTarget
from .target import TableTarget as TableTarget

if TYPE_CHECKING:
    from sqlalchemy.engine.interfaces import DBAPIConnection
    from sqlalchemy.pool import ConnectionPoolEntry


@event.listens_for(sa.Engine, "connect")
def set_sqlite_pragma(
    dbapi_connection: "DBAPIConnection", connection_record: "ConnectionPoolEntry"
) -> None:
    """Enable sqlite `foreign_keys` feature upon connecting."""
    if isinstance(dbapi_connection, sqlite3.Connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()
