from typing import Any, Sequence, cast

import sqlalchemy as sa

from toolkit.exceptions import ProgrammingError

from .base import BaseRepository, TargetT, Values


class ItemRepository(BaseRepository[TargetT]):
    """High-level repository for single-item CRUD operations.

    Provides simplified methods for creating, retrieving, updating, and deleting
    individual items by primary key. Ideal for scenarios where operations target
    single records rather than collections.

    Usage
    -----
    .. code:: python

        executor = SessionExecutor(session)
        target = ModelTarget(User)
        repo = ItemRepository(executor, target)
        repo.create({"name": "Alice"})
        repo.update_by_pk({"id": 1, "name": "Bob"})
        repo.list()
        # > [User(id=1 name="Bob")]
        repo.delete_by_pk({"id": 1})

    """

    """Query target for statement generation."""

    def create(self, values: Values) -> sa.CursorResult[Any]:
        """
        Insert a new item with the given values.

        Parameters
        ----------
        values : dict[str, Any]
            The values to insert.

        Returns
        -------
        sa.Result[Any]
            The result of the insert operation.
        """
        exc = self.target.insert_statement()
        exc = exc.values(values)

        with self.wrap_executor_exception():
            with self.executor.insert_one(exc) as result:
                return cast(sa.CursorResult[Any], result)

    def update_by_pk(self, values: Values) -> int | None:
        """
        Update an item identified by primary key with the given values.

        Parameters
        ----------
        values : dict[str, Any]
            The values to update.

        Returns
        -------
        int | None
            The number of rows updated, or None.
        """
        val_set = set(values.keys())
        pk_set = set(self.target.pk_columns().keys())
        if not val_set & pk_set == pk_set:
            raise ProgrammingError(
                f"The provided values ({val_set}) "
                f"do not satisfy the primary key ({pk_set})."
            )

        exc = self.target.update_statement()

        for column_name, value in values.items():
            if column_name in pk_set:
                exc = exc.where(self.target.column(column_name) == value)
            else:
                exc = exc.values(**{column_name: value})

        with self.wrap_executor_exception():
            with self.executor.update(exc) as rowcount:
                if rowcount == 0:
                    raise self.NotFound()

                return rowcount

    def delete_by_pk(self, values: Values) -> int | None:
        """
        Delete an item identified by primary key.

        Parameters
        ----------
        values : dict[str, Any]
            The primary key values.

        Returns
        -------
        int | None
            The number of rows deleted, or None.
        """
        val_set = set(values.keys())
        pk_set = set(self.target.pk_columns().keys())
        if not val_set == pk_set:
            raise ProgrammingError(
                f"The provided values ({val_set}) "
                f"do not match the primary key ({pk_set})."
            )

        exc = self.target.delete_statement()
        exc = self.where_values_match(exc, values)

        with self.wrap_executor_exception():
            with self.executor.delete(exc) as rowcount:
                if rowcount == 0:
                    raise self.NotFound()

                return rowcount

    def get_by_pk(self, values: Values) -> TargetT:
        """
        Retrieve an item by primary key.

        Parameters
        ----------
        values : dict[str, Any]
            The primary key values.

        Returns
        -------
        TargetT
            The item retrieved.
        """
        val_set = set(values.keys())
        pk_set = set(self.target.pk_columns().keys())
        if not val_set == pk_set:
            raise ProgrammingError(
                f"The provided values ({val_set}) "
                f"do not match the primary key ({pk_set})."
            )
        exc = self.target.select_statement()
        exc = self.where_values_match(exc, values)

        with self.executor.select(exc) as result, self.expect_one_result():
            return self.target.get_single_item(result)

    def get(self, values: Values) -> TargetT:
        """
        Retrieve an item matching the given values.

        Parameters
        ----------
        values : dict[str, Any]
            The values to match.

        Returns
        -------
        TargetT
            The item retrieved.
        """
        exc = self.select_for_values(values)
        with self.executor.select(exc) as result, self.expect_one_result():
            return self.target.get_single_item(result)

    def list(
        self,
        values: Values | None = None,
        columns: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[TargetT]:
        """
        List items matching the given values.

        Parameters
        ----------
        values : dict[str, Any], optional
            The values to match. If None no values will be matched an all rows will be returned.
        columns : Sequence[str], optional
            Specific columns to select. If None, selects all columns from root target.
        limit : int, optional
            Maximum number of rows to return. If None, returns all matching rows.
        offset : int, optional
            Number of rows to skip before returning results. If None, starts from the first row.

        Returns
        -------
        list[TargetT]
            The list of items.
        """
        exc = self.select_for_values(
            values=values, columns=columns, limit=limit, offset=offset
        )
        exc = self.default_order_by(exc)

        with self.executor.select(exc) as result:
            return self.target.get_item_list(result)
