import abc
from datetime import datetime
from typing import (
    Any,
    Collection,
    Generic,
    Hashable,
    Mapping,
    Sequence,
    TypeVar,
    cast,
)

import numpy as np
import numpy.typing as npt
import pandas as pd
import polars as pl
import sqlalchemy as sa

from toolkit.exceptions import ProgrammingError

from ..executor import SessionExecutor
from ..filter import Filter
from ..target import ModelTarget
from .base import BaseRepository, SelectR, Values

DataFrameT = TypeVar("DataFrameT", pl.DataFrame, pd.DataFrame)


class AbstractDataFrameRepository(BaseRepository[Any], Generic[DataFrameT]):
    @abc.abstractmethod
    def tabulate(self, *args: Any, **kwargs: Any) -> DataFrameT:
        """
        Return a dataframe containing rows matching the given arguments.

        Returns
        -------
        DataFrameT
            DataFrame containing the matching rows.
        """
        ...

    @abc.abstractmethod
    def insert(self, df: DataFrameT) -> Any:
        """
        Insert rows from the given dataframe into the table.

        Parameters
        ----------
        df : DataFrameT
            DataFrame containing rows to insert.

        Returns
        -------
        Any
            Result of the insert operation.
        """
        ...

    @abc.abstractmethod
    def upsert(self, df: DataFrameT) -> Any:
        """
        Insert or update rows from the dataframe based on primary/unique key.

        Parameters
        ----------
        df : DataFrameT
            DataFrame containing rows to upsert.

        Returns
        -------
        Any
            Result of the upsert operation.
        """
        ...

    @abc.abstractmethod
    def update_by_pk(self, df: DataFrameT) -> Any:
        """
        Update rows in the table using primary key values from the dataframe.

        Parameters
        ----------
        df : DataFrameT
            DataFrame containing rows to update.

        Returns
        -------
        Any
            Result of the update operation.
        """
        ...

    @abc.abstractmethod
    def delete(self, df: DataFrameT) -> Any:
        """
        Delete rows from the table matching the dataframe's key columns.

        Parameters
        ----------
        df : DataFrameT
            DataFrame containing key columns for deletion.

        Returns
        -------
        Any
            Result of the delete operation.
        """
        ...


class PandasRepository(AbstractDataFrameRepository[pd.DataFrame]):
    """Repository for working with pandas DataFrames and SQLAlchemy ORM models.
    Provides methods for tabulation, insertion, upsertion, updating, and deletion
    of rows using :class:`pandas.DataFrame`s.

    Handles ``NaN``/``NULL`` values and can create common table expressions
    for data frames enabling fast access from within the database.
    Parses datetime columns for each sqlalchemy model column where
    ``column.type.python_type`` is ``datetime``.

    Usage
    -----
    .. code:: python

        executor = SessionExecutor(session)
        target = ModelTarget(User)
        repo = PandasRepostiory(executor, target)

        import_users_csv = pd.read_csv("./users.csv")
        repo.insert(import_users_csv)
        repo.tabulate()
        #>    id  name   birthday
        # 0   1   Alice  13-12-1984
        # 1   2   Bob    ...
        # 2   3   Carina
        # ...

    """

    merge_suffix: str = "_merged"
    null_coalesce_val: str = "__NULL_COALESCED__"
    executor: SessionExecutor
    target: ModelTarget[Any]
    default_column_names: list[str]
    dtypes: Mapping[Hashable, Any]
    datettime_column_names: list[str]

    def __init__(
        self,
        executor: SessionExecutor,
        target: ModelTarget[Any] | None = None,
        filter: Filter | None = None,
    ):
        super().__init__(executor, target=target, filter=filter)
        self.dtypes = getattr(self, "dtypes", {})
        self.datettime_column_names = []
        self.default_column_names = []

        for column in sa.inspect(self.target.model_class).columns:
            if column.type.python_type is datetime:
                self.datettime_column_names.append(column.name)

            self.default_column_names.append(column.name)

    def execute_select_tabulation(
        self, exc: sa.Select[Any] | sa.CompoundSelect[Any]
    ) -> pd.DataFrame:
        conn = self.executor.session.connection()
        df = pd.read_sql(
            exc,
            con=conn,
            dtype=self.dtypes,
            parse_dates=self.datettime_column_names,
            coerce_float=False,
        )

        column_names = [col.description for col in exc.selected_columns]
        if df.empty:
            return pd.DataFrame([], columns=column_names)
        else:
            return df

    def sanitize_nan_for_sql(self, df: pd.DataFrame) -> pd.DataFrame:
        return df.replace({pd.NaT: None, np.nan: None})

    def coalesce_df(self, df: pd.DataFrame) -> pd.DataFrame:
        return df.where(pd.notnull(df), self.null_coalesce_val)

    def df_to_sql_tuples(self, df: pd.DataFrame) -> list[tuple[Any, ...]]:
        df = self.sanitize_nan_for_sql(df)
        return cast(list[tuple[Any, ...]], df.to_records(index=False))

    def df_to_sql_dicts(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        df = self.sanitize_nan_for_sql(df)
        # to_dict returns a more general list[Mapping[Hashable, Unknown]]
        return cast(list[dict[str, Any]], df.to_dict("records"))

    def values_for_df(self, df: pd.DataFrame) -> sa.Values:
        column_clauses: tuple[sa.ColumnClause[Any], ...] = tuple(
            sa.column(col, self.target.column(col).type) for col in df.columns
        )

        # literal_binds are required on sqlite due to shaky datetime handling
        use_literal_binds = self.executor.engine.dialect.name == "sqlite"
        value_expr = sa.values(*column_clauses, literal_binds=use_literal_binds).data(
            self.df_to_sql_tuples(df)
        )
        return value_expr

    def match_cte_postgresql(
        self,
        exc: sa.Select[SelectR],
        cte: sa.CTE,
        key: Sequence[str],
        nullable: Sequence[str],
    ) -> sa.Select[SelectR]:
        column_conds: list[sa.ColumnElement[Any]] = []
        for col in key:
            tcol = self.target.column(col)
            ccol = cte.c[col]
            # for some reason, sqlalchemy renders some columns as
            # varchar in the values clause... bug? misunderstanding?
            equality = tcol == sa.cast(ccol, tcol.type)

            if col in nullable:
                column_conds.append(
                    sa.or_(equality, sa.and_(tcol.is_(None), ccol.is_(None)))
                )
            else:
                column_conds.append(equality)
        cte_join_cond = sa.and_(*column_conds)
        exc = exc.join(cte, cte_join_cond)
        return exc

    def match_cte_sqlite(
        self,
        exc: sa.Select[SelectR],
        cte: sa.CTE,
        key: Sequence[str],
        nullable: Sequence[str],
    ) -> sa.Select[SelectR]:
        column_conds: list[sa.ColumnElement[Any]] = []
        for col in key:
            if col in nullable:
                column_conds.append(
                    sa.func.coalesce(self.target.column(col), self.null_coalesce_val)
                    == sa.func.coalesce(cte.c[col], self.null_coalesce_val)
                )
            else:
                column_conds.append(self.target.column(col) == cte.c[col])
        cte_join_cond = sa.and_(*column_conds)

        exc = exc.join(cte, cte_join_cond)
        return exc

    def where_df_matches(
        self, exc: sa.Select[SelectR], df: pd.DataFrame
    ) -> sa.Select[SelectR]:
        """
        Add WHERE clause to match rows in the table to those in the dataframe.
        """
        if df.empty:
            return exc.where(sa.false())

        column_names = df.columns.to_list()
        null_columns = [
            name
            for name in column_names
            if getattr(self.target.column(name), "nullable", False)
        ]

        value_cte = self.values_for_df(df).cte("df_values")
        exc = exc.add_cte(value_cte)

        dialect_name = self.executor.engine.dialect.name
        if dialect_name == "sqlite":
            exc = self.match_cte_sqlite(exc, value_cte, column_names, null_columns)
        elif dialect_name == "postgresql":
            exc = self.match_cte_postgresql(exc, value_cte, column_names, null_columns)
        else:
            raise ProgrammingError(
                f"`where_df_matches` does not support dialect '{dialect_name}'."
            )

        return exc

    def tabulate_by_df(
        self,
        df: pd.DataFrame,
        key: Collection[str] | None = None,
        columns: Sequence[str] | None = None,
    ) -> pd.DataFrame:
        """Return DataFrame rows matching the key columns from the given DataFrame.

        Queries the table to retrieve rows that match the unique key values provided
        in the input DataFrame. Useful for checking which rows already exist before
        performing upsert operations. Automatically deduplicates key combinations and
        orders results by primary key.

        Parameters
        ----------
        df : :class:`pandas.DataFrame`
            DataFrame containing key column values to match against the table.
            Only key columns are used for matching.
        key : Collection[str], optional
            Columns to use for matching existing rows. If None, attempts to infer
            a unique key from the table's indexes and constraints.
        columns : Sequence[str], optional
            Specific columns to select from matching rows. If None, selects all columns.

        Returns
        -------
        :class:`pandas.DataFrame`
            DataFrame containing rows from the table where keys match the input DataFrame.
            Results are ordered by primary key columns.

        Usage
        -----
        .. code:: python

            # Check which users exist in the database
            import_df = pd.DataFrame({
                "id": [1, 2, 3, 4, 5],
                "name": ["Alice", "Bob", "Carina", "David", "Eve"]
            })
            existing = repo.tabulate_by_df(import_df)
            print(f"Found {len(existing)} existing users")

            # Get specific columns from matching rows
            existing = repo.tabulate_by_df(
                import_df,
                key=["id"],
                columns=["id", "name", "updated_at"]
            )
        """
        if key is None:
            key = self.target.find_unique_key(df.columns.to_list())

        df = df[list(key)].drop_duplicates()
        exc = self.target.select_statement(columns=columns).order_by(
            *self.target.pk_columns()
        )
        exc = self.where_df_matches(exc, df)
        return self.execute_select_tabulation(exc)

    def tabulate(
        self,
        values: Values | None = None,
        columns: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> pd.DataFrame:
        """Return a pandas DataFrame containing rows matching the given filter criteria.

        Constructs a SELECT statement based on filter values, applies ordering and
        pagination, then executes the query and returns results as a DataFrame.
        Datetime columns are automatically parsed based on the model's column types.

        Parameters
        ----------
        values : dict[str, Any], optional
            Filter criteria mapping column names to values. Supports nested filtering
            for related entities if configured with a filter. If None, returns all rows.
        columns : Sequence[str], optional
            Specific columns to select. If None, selects all columns from the model.
        limit : int, optional
            Maximum number of rows to return. If None, returns all matching rows.
        offset : int, optional
            Number of rows to skip before returning results. If None, starts from the first row.

        Returns
        -------
        :class:`pandas.DataFrame`
            DataFrame containing the query results with proper dtypes and parsed dates.
            Datetime columns are converted from SQL to Python datetime objects.

        Usage
        -----
        .. code:: python

            executor = SessionExecutor(session)
            target = ModelTarget(User)
            filter = Filter(UserFilter, User)
            repo = PandasRepository(executor, target, filter=filter)

            # Return all users
            df = repo.tabulate()

            # Filter by department
            df = repo.tabulate(values={"department": "Engineering"})

            # Select specific columns with limit
            df = repo.tabulate(columns=["id", "name"], limit=100)

            # Pagination
            page_1 = repo.tabulate(limit=50, offset=0)
            page_2 = repo.tabulate(limit=50, offset=50)
        """
        exc = self.select_for_values(
            values=values, columns=columns, limit=limit, offset=offset
        )
        exc = self.default_order_by(exc)

        return self.execute_select_tabulation(exc)

    def insert(self, df: pd.DataFrame, values: Values | None = None) -> None:
        """Insert rows from the given DataFrame into the table.

        Converts DataFrame rows to SQL-compatible dictionaries, handling ``NaN``/``NaT``
        conversion to ``NULL`` values. Supports inserting constant values alongside
        DataFrame values for columns not present in the DataFrame.

        Parameters
        ----------
        df : :class:`pandas.DataFrame`
            DataFrame containing rows to insert. Column names must match table column names.
            Column order does not matter. Datetime columns are automatically parsed from
            the respective model type hints.
        values : dict[str, Any], optional
            Constant values to insert for columns not in the DataFrame. Useful for
            adding a default status, timestamp, or other computed value to all rows.
            Cannot overlap with DataFrame columns.

        Raises
        ------
        :class:`toolkit.exceptions.ProgrammingError`
            If ``values`` keys overlap with DataFrame columns.
        :class:`toolkit.exceptions.NotUnique`
            If a unique constraint is violated.
        :class:`toolkit.exceptions.ConstraintViolated`
            If a another constraint is violated.

        Usage
        -----
        .. code:: python

            import pandas as pd
            from datetime import datetime
            df = pd.DataFrame({
                "id": [1, 2, 3],
                "name": ["Alice", "Bob", "Carina"],
                "brownie_points": [50000, 60000, 55000]
            })
            repo.insert(df)
            # Insert with constant status
            df = pd.DataFrame({"name": ["Dave", "Eve"], "brownie_points": [70000, 3]})
            repo.insert(df, values={"status": "active"})
        """
        self.check_values_vs_cols(values, df)

        m = self.df_to_sql_dicts(df)
        exc = self.target.insert_statement().execution_options(
            synchronize_session=False
        )

        if values is not None:
            exc = exc.values(**values)

        with self.wrap_executor_exception():
            with self.executor.insert_many(exc, m):
                return None

    def update_by_pk(
        self, df: pd.DataFrame, values: Values | None = None
    ) -> int | None:
        """Update rows in the table using primary key values from the DataFrame.

        Matches rows by primary key columns and updates remaining columns with values
        from the DataFrame. Handles ``NaN``/``NaT`` to ``NULL`` conversion automatically.

        Parameters
        ----------
        df : :class:`pandas.DataFrame`
            DataFrame containing rows to update. Must include all primary key columns
            plus the columns to update. Missing columns are ignored in the update.
        values : dict[str, Any], optional
            Constant values to apply to all updated rows for columns not in the DataFrame.
            Cannot overlap with DataFrame columns.

        Returns
        -------
        int | None
            Number of rows updated, or None if the executor does not support row count
            reporting (depends on database dialect and connection type).

        Raises
        ------
        :class:`toolkit.exceptions.ProgrammingError`
            If primary key columns are missing from the DataFrame or if ``values`` overlaps
            with DataFrame columns.
        :class:`toolkit.exceptions.NotUnique`
            If a unique constraint is violated.
        :class:`toolkit.exceptions.ConstraintViolated`
            If a another constraint is violated.

        Usage
        -----
        .. code:: python

            df = pd.DataFrame({
                "id": [1, 2],
                "name": ["Alice Updated", "Bob Updated"],
                "salary": [52000, 62000]
            })
            rowcount = repo.update_by_pk(df)
            print(f"Updated {rowcount} rows")
            # Update with constant value
            df = pd.DataFrame({"id": [3, 4], "salary": [60000, 65000]})
            repo.update_by_pk(df, values={"updated_at": datetime.now()})
        """
        self.check_values_vs_cols(values, df)
        self.target.find_primary_key(df.columns.to_list())

        m = self.df_to_sql_dicts(df)
        exc = self.target.update_statement().execution_options(
            synchronize_session=False
        )

        if values is not None:
            exc = exc.values(**values)

        with self.wrap_executor_exception():
            with self.executor.update(exc, m) as rowcount:
                return rowcount

    def rowwise_exists(
        self, df: pd.DataFrame, key: Collection[str]
    ) -> npt.NDArray[np.bool_]:
        """
        Return a boolean array indicating which rows in the DataFrame exist in the table.
        """
        non_key_cols = set(df.columns) - set(key)
        merged_columns = [
            col for col in non_key_cols if col.endswith(self.merge_suffix)
        ]

        pk_names = [
            c.description for c in self.target.pk_columns() if c.description is not None
        ]

        if merged_columns:
            cond_columns = merged_columns
        elif set(key) != set(pk_names):
            cond_columns = [
                c.description
                for c in self.target.pk_columns()
                if c.description is not None
            ]
        else:
            raise ProgrammingError(
                f"Cannot determine exists condition for key {key} and dataframe columns {df.columns.to_list()}."
            )

        cond = [
            pd.notnull(df[col]) for col in cond_columns
        ]  # TODO: Check if this actually works.
        return np.where(np.logical_or.reduce(cond), True, False)

    def rowwise_difference(
        self, df: pd.DataFrame, key: Collection[str]
    ) -> npt.NDArray[np.bool_]:
        """
        Return a boolean array indicating which rows in the DataFrame differ from those in the table.
        """
        cond = []
        updateable_columns = set(df.columns) - set(key)
        for col in updateable_columns:
            updated_col = col + self.merge_suffix
            if updated_col in df.columns:
                # coerce to same type so the inequality
                # operation works with pyarrow installed
                df[updated_col] = df[updated_col].astype(df[col].dtype)
                are_not_equal = df[col] != df[updated_col]
                # extra check if both values are NA because NA == NA = NA
                # in pandas with pyarrow
                both_are_na = pd.isna(df[col]) & pd.isna(df[updated_col])
                cond.append(~both_are_na | are_not_equal)

        return np.where(np.logical_or.reduce(cond), True, False)

    def check_values_vs_cols(self, values: Values | None, df: pd.DataFrame) -> None:
        if values is None:
            return None

        keys = set(values.keys())
        cols = set(df.columns)
        overlap = keys & cols

        if overlap:
            raise ProgrammingError(
                f"Cannot supply both constant value(s) and dataframe column(s) for: {', '.join(overlap)}"
            )

    def get_constant_values(
        self, values: Values | None, extra_values: Values | None
    ) -> Values | None:
        if values is None:
            if extra_values is None:
                return None
            else:
                return dict(extra_values)
        else:
            if extra_values is None:
                return dict(values)
            else:
                return {**values, **extra_values}

    def drop_upsert_columns(
        self, df: pd.DataFrame, values: Values | None
    ) -> pd.DataFrame:
        if values is not None:
            extra = list(values.keys())
        else:
            extra = []
        return df.drop(columns=["merge_indicator", "exists", "differs"] + extra)

    def upsert(
        self,
        df: pd.DataFrame,
        key: Collection[str] | None = None,
        values: Values | None = None,
        insert_values: Values | None = None,
        update_values: Values | None = None,
    ) -> None:
        """Insert or update rows from the DataFrame based on unique/primary key.

        Performs an "upsert" operation: checks which rows exist in the table by key
        and inserts new rows or updates existing ones. Rows that exist but have changed
        values are updated; completely new rows are inserted.

        Automatically detects the key columns if not specified and handles ``NaN``/``NaT``
        conversion to ``NULL`` values.

        Parameters
        ----------
        df : :class:`pandas.DataFrame`
            The data frame containing rows to upsert. Column names must match table columns.
        key : Collection[str], optional
            Columns to use as the key for matching existing rows. If None, attempts to
            infer a unique key from the table's indexes and constraints.
        values : dict[str, Any], optional
            Constant values applied to both inserted and updated rows. Cannot overlap
            with DataFrame columns.
        insert_values : dict[str, Any], optional
            Constant values applied only to inserted rows (defaults to keys in ``values
            if not provided). Useful for default creation metadata.
        update_values : dict[str, Any], optional
            Constant values applied only to updated rows. Useful for update timestamps
            or metadata.

        Raises
        ------
        :class:`toolkit.exceptions.ProgrammingError`
            If constant values overlap with DataFrame columns or if key detection fails.
            If the database dialect is not supported (only SQLite and PostgreSQL).
        :class:`toolkit.exceptions.NotUnique`
            If a unique constraint is violated.
        :class:`toolkit.exceptions.ConstraintViolated`
            If a another constraint is violated.

        Usage
        -----
        .. code:: python

            df = pd.DataFrame({
                "id": [1, 2, 3],
                "name": ["Alice", "Bob", "Carina"],
                "salary": [52000, 62000, 57000]
            })
            # Upsert with automatic key detection
            repo.upsert(df)
            # Explicit key selection
            repo.upsert(df, key=["id"])
            # Add timestamps to all operations
            repo.upsert(
                df,
                values={"synced_at": datetime.now()},
                update_values={"updated_at": datetime.now()}
            )
        """
        if key is None:
            key = self.target.find_unique_key(df.columns.to_list())

        self.check_values_vs_cols(values, df)
        self.check_values_vs_cols(insert_values, df)
        self.check_values_vs_cols(update_values, df)

        key_df = df[list(key)].drop_duplicates()
        existing_df = self.tabulate_by_df(key_df, key=key)
        if existing_df.empty:
            self.insert(df, values=self.get_constant_values(values, insert_values))
        else:
            df = df.merge(
                existing_df,
                how="left",
                on=list(key),
                suffixes=(
                    None,
                    self.merge_suffix,
                ),
                indicator="merge_indicator",
            ).replace({np.nan: None})
            df["exists"] = df["merge_indicator"] == "both"
            differs = self.rowwise_difference(df, key)
            df["differs"] = differs

            insert_df = df[~df["exists"]]
            update_df = df[df["exists"] & df["differs"]]

            if not insert_df.empty:
                iv = self.get_constant_values(values, insert_values)
                self.insert(self.drop_upsert_columns(insert_df, iv), values=iv)
            if not update_df.empty:
                uv = self.get_constant_values(values, update_values)
                self.update_by_pk(self.drop_upsert_columns(update_df, uv), values=uv)

    def delete(
        self,
        df: pd.DataFrame,
        key: Collection[str] | None = None,
    ) -> Any:
        """Delete rows from the table matching the DataFrame's key columns.

        Identifies rows to delete by matching the key columns from the DataFrame against
        the table. Automatically infers key columns if not specified. Removes duplicate
        key combinations before executing the delete.

        Parameters
        ----------
        df : :class:`pandas.DataFrame`
            DataFrame containing key column values identifying rows to delete.
            Only key columns are used; other columns are ignored.
        key : Collection[str], optional
            Columns to use as the delete key. If None, attempts to infer a unique key
            from the table's indexes and constraints.

        Returns
        -------
        int | None
            Number of rows deleted, or None if the executor does not support row count
            reporting (depends on database dialect and connection type).

        Raises
        ------
        :class:`toolkit.exceptions.ProgrammingError`
            If key detection fails or if the database dialect is not supported.
            Supported dialects: SQLite, PostgreSQL.
        :class:`toolkit.exceptions.ConstraintViolated`
            If a foreign key constraint is violated by deleting the rows.

        Usage
        -----
        .. code:: python

            # Delete by primary key
            df = pd.DataFrame({"id": [1, 2, 3]})
            rowcount = repo.delete(df)
            print(f"Deleted {rowcount} rows")
            # Delete with explicit key
            df = pd.DataFrame({"email": ["alice@example.com", "bob@example.com"]})
            repo.delete(df, key=["email"])
        """
        if key is None:
            key = self.target.find_unique_key(df.columns.to_list())

        df = df[list(key)].drop_duplicates()
        exc = self.target.delete_statement()
        pk = self.target.pk_columns()
        pk_tuple = sa.tuple_(*pk)
        select_exc = self.target.select_statement(columns=pk.keys())
        select_exc = self.where_df_matches(select_exc, df)
        exc = exc.where(pk_tuple.in_(select_exc))

        with self.wrap_executor_exception():
            with self.executor.delete(exc) as rowcount:
                return rowcount
