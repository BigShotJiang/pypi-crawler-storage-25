import contextlib
from typing import (
    Any,
    Generator,
    Generic,
    Mapping,
    Sequence,
    TypeVar,
    cast,
    overload,
)

import sqlalchemy as sa
from sqlalchemy.exc import IntegrityError, MultipleResultsFound, NoResultFound

from toolkit.exceptions import ConstraintViolated as BaseConstraintViolated
from toolkit.exceptions import NotFound, ProgrammingError
from toolkit.exceptions import NotFound as BaseNotFound
from toolkit.exceptions import NotUnique as BaseNotUnique

from ..executor import AbstractExecutor
from ..filter import Filter
from ..target import AbstractQueryTarget

psycopg_is_installed = False

try:
    import psycopg  # noqa: F401
    import psycopg.errors  # noqa: F401

    psycopg_is_installed = True
except ImportError:
    psycopg_is_installed = False


sqlite3_is_installed = False

try:
    import sqlite3  # noqa: F401

    sqlite3_is_installed = True
except ImportError:
    pass

SelectR = TypeVar("SelectR", bound=tuple[Any, ...])
TargetT = TypeVar("TargetT", bound=Any)
Values = Mapping[str, Any]


class BaseRepository(Generic[TargetT]):
    """Generic repository pattern implementation for CRUD operations on database targets.
    Handles database-specific exception translation and can be customized
    via subclassing for domain-specific behavior.

    Parameters
    ----------
    executor : AbstractExecutor
        Database executor (ConnectionExecutor or SessionExecutor) for executing statements.
    target : AbstractQueryTarget[TargetT], optional
        Query target (TableTarget, ModelTarget, or ExtendedTarget) defining how to
        construct database statements. Can also be set as a class attribute.
    filter : Filter, optional
        Pre-configured filter for query constraints.

    Usage
    -----
    .. code:: python

        executor = SessionExecutor(session)
        target = ModelTarget(User)
        repo = BaseRepository(executor, target)

        repo.count()
        #> 42

        repo.select_for_values(values={"name": "foo"})
        #> sqlalchemy.Select("SELECT * FROM users WHERE name = 'foo';")

    """

    NotFound: type[BaseNotFound] = BaseNotFound
    """Exception raised when a query returns no results and one was expected."""
    NotUnique: type[BaseNotUnique] = BaseNotUnique
    """Exception raised when an insert query encounters a unique constraint violation."""
    ConstraintViolated: type[BaseConstraintViolated] = BaseConstraintViolated
    """Exception raised when a database constraint is violated."""

    target: AbstractQueryTarget[TargetT]
    """The query target for statement generation."""
    executor: AbstractExecutor
    """The database executor instance."""
    filter: Filter | None = None
    """Optional pre-configured filter for query constraints."""

    def __init__(
        self,
        executor: AbstractExecutor,
        target: AbstractQueryTarget[TargetT] | None = None,
        filter: Filter | None = None,
    ):
        self.executor = executor

        if target is not None:
            self.target = target

        if getattr(self, "target", None) is None:
            raise ProgrammingError(
                f"`{self.__class__.__name__}` requires a `target` to function."
            )

        if filter is not None:
            self.filter = filter

    @contextlib.contextmanager
    def wrap_executor_exception(self) -> Generator[None, None, None]:
        try:
            yield
        except IntegrityError as e:
            if self.executor.engine.dialect.name == "sqlite":
                self.reraise_sqlite3_exception(e)
            elif self.executor.engine.dialect.name == "postgresql":
                self.reraise_psycopg_exception(e)

    def reraise_sqlite3_exception(self, exception: IntegrityError) -> None:
        sqlite3_exc = cast(sqlite3.IntegrityError, exception.orig)
        msg = str(sqlite3_exc)
        if msg.startswith("UNIQUE constraint failed"):
            raise self.NotUnique()
        if msg.startswith("NOT NULL constraint failed"):
            raise self.ConstraintViolated()
        elif msg.startswith("FOREIGN KEY constraint failed"):
            raise self.ConstraintViolated()
        else:
            raise ProgrammingError("Unknown exception raised by dbapi backend.")

    def reraise_psycopg_exception(self, exception: IntegrityError) -> None:
        if isinstance(exception.orig, psycopg.errors.UniqueViolation):
            raise self.NotUnique()
        elif isinstance(exception.orig, psycopg.errors.NotNullViolation):
            raise self.ConstraintViolated()
        elif isinstance(exception.orig, psycopg.errors.ForeignKeyViolation):
            raise self.ConstraintViolated()
        else:
            raise ProgrammingError("Unknown exception raised by dbapi backend.")

    @overload
    def where_values_match(self, exc: sa.Update, values: Values) -> sa.Update: ...

    @overload
    def where_values_match(self, exc: sa.Delete, values: Values) -> sa.Delete: ...

    @overload
    def where_values_match(
        self, exc: sa.Select[SelectR], values: Values
    ) -> sa.Select[SelectR]: ...

    def where_values_match(
        self, exc: sa.Select[SelectR] | sa.Update | sa.Delete, values: Values
    ) -> sa.Select[SelectR] | sa.Update | sa.Delete:
        """
        Add WHERE clauses to the given SQLAlchemy statement to match the provided column values.

        Parameters
        ----------
        exc : sa.Select[SelectR] | sa.Update | sa.Delete
            The SQLAlchemy statement.
        values : dict[str, Any]
            The column values to match.

        Returns
        -------
        sa.Select[SelectR] | sa.Update | sa.Delete
            The statement with WHERE clauses added.
        """
        for column_name, value in values.items():
            exc = exc.where(self.target.column(column_name) == value)
        return exc

    def select_for_values(
        self,
        values: Values | None = None,
        columns: Sequence[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> sa.Select[Any]:
        """
        Build a SELECT statement for the given values.
        If the repository has as filter attached, the filter will be
        used to build the statement's WHERE clause.

        Parameters
        ----------
        values : Values | None
            The values to match.

        Returns
        -------
        sa.Select[Any]
            The SELECT statement.
        """

        exc = self.target.select_statement(columns=columns)

        if values is not None:
            if self.filter is not None:
                exc = self.filter.where_filter_matches(self, exc, values)
            else:
                exc = self.where_values_match(exc, values)

        if limit is not None:
            exc = exc.limit(limit)
        if offset is not None:
            exc = exc.offset(offset)

        return exc

    def default_order_by(self, exc: sa.Select[SelectR]) -> sa.Select[SelectR]:
        return exc.order_by(*self.target.pk_columns())

    @contextlib.contextmanager
    def expect_one_result(self) -> Generator[None, None, None]:
        """
        Context manager to ensure that only one result is returned from a query.

        Yields
        ------
        None

        Raises
        ------
        NotFound
            If no result is found.
        ProgrammingError
            If multiple results are found.
        """
        try:
            yield
        except NoResultFound:
            raise (self.NotFound or NotFound)()
        except MultipleResultsFound:
            raise ProgrammingError("Multiple results returned while one was expected.")

    def count(self, values: Values | None = None) -> int:
        """
        Count the number of rows matching the given values.

        Parameters
        ----------
        values : dict[str, Any] | None
            The values to match.

        Returns
        -------
        int
            The count of matching rows.
        """
        exc = self.select_for_values(values, columns=self.target.pk_columns().keys())

        # DISTINCT is only needed when joins can duplicate PK rows. For the
        # EXISTS-only filter path (no joins), DISTINCT adds unnecessary sort/hash
        # work and can dominate count query runtime.
        has_join = any(
            isinstance(from_clause, sa.Join) for from_clause in exc.get_final_froms()
        )
        if has_join:
            exc = exc.distinct()

        count_exc = sa.select(sa.func.count()).select_from(exc.subquery())

        with self.executor.select(count_exc) as result, self.expect_one_result():
            return result.scalar_one()
