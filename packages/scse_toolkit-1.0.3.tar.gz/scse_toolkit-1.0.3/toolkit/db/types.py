from datetime import datetime
from typing import Annotated, Any

import numpy as np
import pandas as pd
from sqlalchemy import Dialect, Identity, TypeDecorator
from sqlalchemy import types as sqlatypes
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped as Mapped
from sqlalchemy.orm import mapped_column


class PdDateTime(TypeDecorator[datetime]):
    """Sqlalchemy DateTime type with pandas handling code."""

    impl = sqlatypes.DateTime
    cache_ok = True

    def process_bind_param(self, value: Any, dialect: Dialect) -> datetime | Any:
        if isinstance(value, pd.Timestamp):
            return value.to_pydatetime(warn=True)
        elif isinstance(value, np.datetime64):
            return pd.Timestamp(value).to_pydatetime(warn=True)
        elif isinstance(value, int):
            return pd.Timestamp(value).to_pydatetime(warn=True)
        else:
            return value

    def process_result_value(self, value: Any, dialect: Dialect) -> Any:
        return value

    @property
    def python_type(self) -> type[Any]:
        return self.impl_instance.python_type


_pd_dt_column = mapped_column(PdDateTime())

DateTime = Mapped[Annotated[datetime, _pd_dt_column]]
Boolean = Mapped[bool]
Float = Mapped[float]
Integer = Mapped[int]
String = Mapped[str]


_int_id_column = mapped_column(
    server_default=Identity(always=False, on_null=True, start=1, increment=1),
    primary_key=True,
)

IntegerId = Mapped[Annotated[int, _int_id_column]]

_json_column = mapped_column(sqlatypes.JSON().with_variant(JSONB(), "postgresql"))

JsonValue = float | int | str | bool | dict[str, Any] | list[Any] | None
Json = Mapped[Annotated[JsonValue, _json_column]]
JsonList = Mapped[Annotated[list[JsonValue], _json_column]]
JsonDict = Mapped[Annotated[dict[str, JsonValue], _json_column]]
