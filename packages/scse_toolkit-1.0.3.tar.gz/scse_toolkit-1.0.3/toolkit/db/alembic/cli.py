from pathlib import Path
from typing import Any, Generator

import typer
from alembic.script import Script
from rich import print_json
from rich.console import Console
from rich.table import Table

from toolkit.exceptions import ProgrammingError

from .controller import AlembicController


class AlembicCli(typer.Typer):
    """Command line interface for alembic migrations via the `AlembicController` class."""

    controllers: list[AlembicController]
    init_controller: AlembicController | None

    def __init__(
        self,
        *args: Any,
        controllers: list[AlembicController] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        if controllers is not None:
            self.controllers = controllers

            @self.callback()
            def set_controllers(ctx: typer.Context) -> None:
                ctx.ensure_object(dict)
                ctx.obj["controllers"] = controllers

        self.console = Console()

        @self.command()
        def compare(ctx: typer.Context) -> None:
            """Compare the current metadata structure (populated by database models) against the database.
            Note: Currently there is a bug emitting some unnecessary changes when using this command."""

            # alembic types the result here once as 'object' once as 'Any',
            # but it is actually a list.
            for controller in self.yield_controllers_from_context(ctx):
                changes: Any = controller.compare_metadata(controller.get_metadata())
                if len(changes) == 0:
                    typer.secho(
                        "No changes to the database schema detected.", fg="green"
                    )
                    raise typer.Exit()
                else:
                    typer.secho(
                        f"Detected changes on '{controller.url.render_as_string()}' "
                        f"resulting in {len(changes)} operation(s):",
                        fg="green",
                    )
                    print_json(data=changes, default=lambda x: repr(x))

        @self.command()
        def revisions(ctx: typer.Context) -> None:
            """List all database revisions."""
            for controller in self.yield_controllers_from_context(ctx):
                table = Table("ID", "Branch Labels", "File Name")
                revisions = controller.list_revisions()
                for script in revisions:
                    path = Path(script.path)
                    table.add_row(
                        script.revision, ", ".join(script.branch_labels), path.name
                    )
                script_location = controller.alembic_config.get_main_option(
                    "script_location"
                )
                typer.echo(
                    f"Found {len(revisions)} revision(s) in {script_location} "
                    f"for database '{controller.url.render_as_string()}':"
                )
                self.console.print(table)

        @self.command()
        def autogenerate(
            ctx: typer.Context,
            message: str,
            override_rev_id: str | None = typer.Option(
                None, help="Override the revision id generated."
            ),
        ) -> None:
            """Autogenerate a new migration revision."""
            for controller in self.yield_controllers_from_context(ctx):
                script = controller.autogenerate_revision(
                    message, rev_id=override_rev_id
                )
                if isinstance(script, Script):
                    typer.secho(
                        f"Generated revision '{script.revision}' at {script.path}"
                        f" for '{controller.url.render_as_string()}'.",
                        fg="green",
                    )
                else:
                    typer.secho(
                        "Generated multiple revisions.",
                        fg="green",
                    )

        @self.command()
        def upgrade(
            ctx: typer.Context,
            revision: str = typer.Argument(
                "head", help="Revision ID or 'head' (default) for the newest revision."
            ),
        ) -> None:
            """Upgrade the database to the given revision ('head' per default)."""
            for controller in self.yield_controllers_from_context(ctx):
                controller.upgrade_database(revision)
                typer.secho(
                    f"Upgraded database '{controller.url.render_as_string()}' "
                    f"to revision '{revision}'.",
                    fg="green",
                )

        @self.command()
        def downgrade(
            ctx: typer.Context,
            revision: str = typer.Argument(
                "-1",
                help="Revision ID or '-<int>' (default: '-1') for the nth previous revision.",
            ),
        ) -> None:
            """Downgrade the database to the given revision (first previous revision per default)."""
            for controller in self.yield_controllers_from_context(ctx):
                controller.downgrade_database(revision)
                typer.secho(
                    f"Downgraded database '{controller.url.render_as_string()}' "
                    f"to revision '{revision}'.",
                    fg="green",
                )

        @self.command()
        def stamp(
            ctx: typer.Context,
            revision: str = typer.Argument(
                "head", help="Revision ID or 'head' (default) for the newest revision."
            ),
        ) -> None:
            """Stamp the database to the given revision !without running migrations!.
            This may break the migration logic. Use with care!"""
            for controller in self.yield_controllers_from_context(ctx):
                if typer.confirm(
                    f"Are you sure you want to stamp this database to revision '{revision}'?"
                ):
                    controller.stamp_database(revision)
                    typer.secho(
                        f"Stamped database to revision '{revision}'.", fg="green"
                    )
                else:
                    raise typer.Abort()

    def raise_invalid_controllers(self) -> None:
        raise ProgrammingError(
            f"A list of `{AlembicController.__name__}` instances is "
            f"required for `{self.__class__.__name__}` to function. "
            "Supply it to the `__init__` method via the `controllers` parameter "
            "or set `Context.obj['controllers']`."
        )

    def yield_controllers_from_context(
        self, ctx: typer.Context
    ) -> Generator[AlembicController, None, None]:
        ctx.ensure_object(dict)

        controllers = ctx.obj.get("controllers", None)
        if not isinstance(controllers, list) or len(controllers) == 0:
            self.raise_invalid_controllers()

        for ctrl in controllers:
            if isinstance(ctrl, AlembicController):
                yield ctrl
            else:
                self.raise_invalid_controllers()
