from typing import Any, ClassVar, Protocol, Sequence

import sqlalchemy as sa
from sqlalchemy import orm

from toolkit.exceptions import ProgrammingError


class ModelProtocol(Protocol):
    __table__: ClassVar[sa.FromClause]

    def __init__(self, **kw: Any) -> None: ...
    def _sa_inspect_type(self) -> Any: ...


RelationshipPath = Sequence[orm.InstrumentedAttribute[ModelProtocol]]
RelpathOrRel = RelationshipPath | orm.InstrumentedAttribute[ModelProtocol]


def get_relationship_path(in_: RelpathOrRel) -> RelationshipPath:
    if isinstance(in_, Sequence):
        last_entity = None
        for attr in in_:
            rel = get_relationship(attr)
            if last_entity is not None:
                if rel.parent is not last_entity:
                    raise ProgrammingError(
                        "Invalid relationship path. "
                        f"Expected relationship on {last_entity} got {str(attr)} instead."
                    )
            last_entity = rel.entity
        return tuple(attr for attr in in_)
    else:
        try:
            get_relationship(in_)
            return (in_,)
        except ProgrammingError:
            raise ProgrammingError(
                "Expected relationship attribute or `Collection` "
                f"got {in_.__class__.__name__} instead."
            )


def get_relationship(
    attr: orm.InstrumentedAttribute[Any],
) -> orm.Relationship[Any]:
    if isinstance(attr, orm.InstrumentedAttribute):
        if isinstance(attr.prop, orm.Relationship):
            return attr.prop
        else:
            raise ProgrammingError(f"{str(attr)} is not a relationship attribute.")
    else:
        raise ProgrammingError(
            f"Expected `InstrumentedAttribute` got `{attr.__class__.__name__}` instead."
        )


def get_remote_table(attr: orm.InstrumentedAttribute[Any]) -> sa.Table:
    rel = get_relationship(attr)
    return get_mapped_table(rel.mapper.class_)


def get_mapped_table(class_: type[ModelProtocol]) -> sa.Table:
    table = getattr(class_, "__table__", None)
    if not isinstance(table, sa.Table):
        raise ProgrammingError(
            f"Model class `{class_.__name__}` is not mapped to a table."
        )

    return table
