import abc
from typing import Any, Generic, Sequence, TypeVar

import sqlalchemy as sa
from sqlalchemy import orm

from toolkit.exceptions import ProgrammingError

from .utils import (
    ModelProtocol,
    RelationshipPath,
    RelpathOrRel,
    get_mapped_table,
    get_relationship_path,
)

DefaultT = TypeVar("DefaultT")


class AbstractQueryTarget(abc.ABC, Generic[DefaultT]):
    """Abstract base for query target implementations.

    Defines the interface for constructing SELECT, INSERT, UPDATE, and DELETE statements
    for a database table or ORM model. Subclasses implement this interface for specific
    targets (tables, models, models with extended columns).

    Parameters
    ----------
    table : sa.Table
        The SQLAlchemy table to query against.
    """

    table: sa.Table
    """The SQLAlchemy table associated with this target."""

    def __init__(self, table: sa.Table):
        self.table = table

    @abc.abstractmethod
    def select_default(self) -> sa.Select[Any]: ...

    def select_columns(self, columns: Sequence[str]) -> sa.Select[Any]:
        col_elems = (self.column(name) for name in columns)
        return sa.select(*col_elems)

    def select_statement(
        self, columns: Sequence[str] | None = None
    ) -> sa.Select[tuple[Any, ...]]:
        """
        Return a base SELECT statement for the target.

        Returns
        -------
        sa.Select[tuple[Any, ...]]
            The base SELECT statement.
        """
        if columns is None:
            exc = self.select_default()
        else:
            exc = self.select_columns(columns)

        return exc

    @abc.abstractmethod
    def insert_statement(self) -> sa.Insert:
        """
        Return a base INSERT statement for the target.

        Returns
        -------
        sa.Insert
            The base INSERT statement.
        """
        ...

    @abc.abstractmethod
    def update_statement(self) -> sa.Update:
        """
        Return a base UPDATE statement for the target.

        Returns
        -------
        sa.Update
            The base UPDATE statement.
        """
        ...

    @abc.abstractmethod
    def delete_statement(self) -> sa.Delete:
        """
        Return a base DELETE statement for the target.

        Returns
        -------
        sa.Delete
            The base DELETE statement.
        """
        ...

    @abc.abstractmethod
    def pk_columns(self) -> sa.ColumnCollection[str, sa.ColumnElement[Any]]:
        """
        Return the primary key columns for the target.

        Returns
        -------
        sa.ColumnCollection[str, sa.ColumnElement[Any]]
            The primary key columns.
        """
        ...

    @abc.abstractmethod
    def column(
        self, name: str
    ) -> sa.ColumnElement[Any] | orm.InstrumentedAttribute[Any]:
        """
        Return the column element for the given column name.

        Parameters
        ----------
        name : str
            The column name.

        Returns
        -------
        sa.ColumnElement[Any]
            The column element.
        """
        ...

    def find_primary_key(self, columns: Sequence[str]) -> set[str]:
        """
        Find the primary key columns in the target that match the supplied columns.

        Parameters
        ----------
        columns : Sequence[str]
            The columns to match.

        Returns
        -------
        set[str]
            The set of primary key columns.

        Raises
        ------
        ProgrammingError
            If no match is found.
        """
        cols = set(columns)
        pk = set(self.pk_columns().keys())
        if pk & cols == pk:
            return pk

        raise ProgrammingError(
            f"The supplied columns {columns} do not match "
            f"the primary key on the table '{self.table.name}'."
        )

    def find_unique_key(self, columns: Sequence[str]) -> set[str]:
        """
        Find a unique key (primary or unique constraint) in the target that matches the supplied columns.

        Parameters
        ----------
        columns : Sequence[str]
            The columns to match.

        Returns
        -------
        set[str]
            The set of unique key columns.

        Raises
        ------
        ProgrammingError
            If no match is found.
        """
        try:
            pk = self.find_primary_key(columns)
            return pk
        except ProgrammingError:
            pass

        cols = set(columns)
        for constraint in self.table.constraints:
            if isinstance(constraint, sa.UniqueConstraint):
                uq = set(constraint.columns.keys())
                if uq & cols == uq:
                    return uq

        raise ProgrammingError(
            f"The supplied columns {columns} do not match any "
            f"unique or primary key on the table '{self.table.name}'."
        )

    @abc.abstractmethod
    def get_single_item(self, result: sa.Result[Any]) -> DefaultT:
        """
        Extract a single item from the SQLAlchemy result.

        Returns
        -------
        ItemT
            The single item extracted from the result.
        """
        ...

    @abc.abstractmethod
    def get_item_list(self, result: sa.Result[Any]) -> list[DefaultT]:
        """
        Extract a list of items from the SQLAlchemy result.

        Returns
        -------
        list[ItemT]
            The list of items extracted from the result.
        """
        ...


DefaultTupleT = TypeVar("DefaultTupleT", bound=tuple[Any, ...])


class TableTarget(
    AbstractQueryTarget[DefaultTupleT],
):
    """Query target for direct table-level operations without ORM semantics.

    Constructs SQL statements for raw table queries, returning results as tuples.
    Useful for low-level database access and bulk operations where ORM overhead
    is not needed.

    Parameters
    ----------
    table : sa.Table
        The SQLAlchemy table to query.

    Examples
    --------
    >>> target = TableTarget(user_table)
    >>> executor = ConnectionExecutor(engine)
    >>> repo = BaseRepository(executor, target)
    """

    table: sa.Table
    """The SQLAlchemy table."""

    def __init__(self, table: sa.Table):
        self.table = table

    def select_default(self) -> sa.Select[DefaultTupleT]:
        return sa.select(self.table)

    def insert_statement(self) -> sa.Insert:
        return sa.insert(self.table)

    def update_statement(self) -> sa.Update:
        return sa.update(self.table)

    def delete_statement(self) -> sa.Delete:
        return sa.delete(self.table)

    def column(self, name: str) -> sa.ColumnElement[Any]:
        return self.table.c[name]

    def pk_columns(self) -> sa.ColumnCollection[str, sa.ColumnElement[Any]]:
        return sa.inspect(self.table).primary_key.columns

    def get_single_item(self, result: sa.Result[DefaultTupleT]) -> DefaultTupleT:
        return result.tuples().one()

    def get_item_list(self, result: sa.Result[DefaultTupleT]) -> list[DefaultTupleT]:
        return list(result.tuples().all())


DefaultModelT = TypeVar("DefaultModelT", bound=ModelProtocol)


class ModelTarget(AbstractQueryTarget[DefaultModelT]):
    """Query target for ORM model-based operations.

    Constructs SQL statements for ORM models, returning results as mapped instances.
    Leverages SQLAlchemy's ORM capabilities for type safety and relationship management.

    Parameters
    ----------
    model_class : type[DefaultModelT]
        The SQLAlchemy ORM model class to query.

    Usage
    -----
    .. code:: python

        target = ModelTarget(User)
        executor = SessionExecutor(session)
        repo = BaseRepository(executor, target)

    """

    model_class: type[DefaultModelT]
    """The ORM model class."""

    def __init__(self, model_class: type[DefaultModelT]):
        self.model_class = model_class

        table = get_mapped_table(self.model_class)

        super().__init__(table)

    def select_default(self) -> sa.Select[Any]:
        return sa.select(self.model_class)

    def insert_statement(self) -> sa.Insert:
        return sa.insert(self.model_class)

    def update_statement(self) -> sa.Update:
        return sa.update(self.model_class)

    def delete_statement(self) -> sa.Delete:
        return sa.delete(self.model_class)

    def column(self, name: str) -> sa.ColumnElement[Any]:
        return self.table.c[name]

    def pk_columns(self) -> sa.ColumnCollection[str, sa.ColumnElement[Any]]:
        return sa.inspect(self.table).primary_key.columns

    def get_single_item(self, result: sa.Result[tuple[DefaultModelT]]) -> DefaultModelT:
        return result.scalar_one()

    def get_item_list(
        self, result: sa.Result[tuple[DefaultModelT]]
    ) -> list[DefaultModelT]:
        return list(result.scalars().all())


InputRelatedColumnDict = dict[str, tuple[RelpathOrRel, orm.InstrumentedAttribute[Any]]]
RelatedColumnDict = dict[str, tuple[RelationshipPath, orm.InstrumentedAttribute[Any]]]


class ExtendedTarget(ModelTarget[DefaultModelT]):
    """Query target for ORM models with support for related entity columns.

    Extends :class:`~toolkit.db.target.ModelTarget` to include columns from related
    entities via relationships. SELECT statements include columns from related tables,
    enabling efficient data retrieval with joins.

    Parameters
    ----------
    model_class : type[DefaultModelT]
        The SQLAlchemy ORM model class to query.
    extra_columns : dict[str, tuple[RelpathOrRel, InstrumentedAttribute[Any]]]
        Mapping of column names to (relationship_path, column) tuples for related
        entity columns to include in SELECT statements.

    Usage
    -----
    .. code:: python

        target = ExtendedTarget(
            User,
            {"department_name": (User.department, Department.name)}
        )
        executor = SessionExecutor(session)
        repo = BaseRepository(executor, target)

    """

    extra_columns: RelatedColumnDict
    """Validated mapping of related entity columns."""

    def __init__(
        self, model_class: type[DefaultModelT], extra_columns: InputRelatedColumnDict
    ) -> None:
        super().__init__(model_class)
        self.extra_columns = self.validate_extra_columns(extra_columns)

    def validate_extra_columns(
        self, extra_columns: InputRelatedColumnDict
    ) -> RelatedColumnDict:
        res: RelatedColumnDict = {}
        for key, val in extra_columns.items():
            rel_or_rels, col = val
            relationships = get_relationship_path(rel_or_rels)
            res[key] = (relationships, col)
        return res

    def column(
        self, name: str
    ) -> sa.ColumnElement[Any] | orm.InstrumentedAttribute[Any]:
        if name in self.extra_columns:
            _, col = self.extra_columns[name]
            return col.label(name)
        return self.table.c[name]

    def select_columns(self, columns: Sequence[str]) -> sa.Select[Any]:
        col_elems = [self.column(name) for name in columns]
        exc = sa.select(*col_elems).select_from(self.table)
        for name in columns:
            if name in self.extra_columns:
                relationships, _ = self.extra_columns[name]

                for rel in relationships:
                    exc = exc.join(rel)
        return exc
