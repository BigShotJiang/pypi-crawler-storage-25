import functools
import operator
from types import UnionType
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    Callable,
    Iterable,
    Protocol,
    TypeVar,
    Union,
    cast,
    get_args,
    get_origin,
    get_type_hints,
    overload,
)

import sqlalchemy as sa
from sqlalchemy.exc import InvalidRequestError

from toolkit.exceptions import ProgrammingError

from .utils import (
    ModelProtocol,
    RelationshipPath,
    get_mapped_table,
    get_relationship_path,
    get_remote_table,
)

if TYPE_CHECKING:
    from .repositories.base import BaseRepository, Values

FilterSchema = type[Any]
FilterValue = (
    None
    | int
    | float
    | str
    | bool
    | dict[str, "FilterValue"]
    | list["FilterValue"]
    | tuple["FilterValue", ...]
)
AnyStatement = sa.Select[Any] | sa.Exists


class FilterFunc(Protocol):
    def __call__(
        self,
        exc: AnyStatement,
        value: Any,
        *,
        schema: type[Any],
        repo: "BaseRepository[Any]",
    ) -> AnyStatement: ...


class PartialFilterFunc(Protocol):
    def __call__(
        self,
        exc: AnyStatement,
        value: Any,
        *,
        repo: "BaseRepository[Any]",
    ) -> AnyStatement: ...


CompFunc = Callable[[sa.ColumnElement[Any], Any], sa.BinaryExpression[bool]]


RelationTarget = type[ModelProtocol] | sa.Table

SelectR = TypeVar("SelectR", bound=tuple[Any, ...])


def _is_joined(exc: sa.Select[Any], table: sa.Table) -> bool:
    """Check whether *table* already appears in the FROM clause of *exc*."""

    def _check(f: sa.FromClause) -> bool:
        if isinstance(f, sa.Join):
            return _check(f.left) or _check(f.right)
        return f == table

    return any(_check(f) for f in exc.get_final_froms())


T = TypeVar("T")


def in_(
    c: sa.ColumnElement[T], v: Iterable[T] | sa.BindParameter[T]
) -> sa.BinaryExpression[bool]:
    return c.in_(v)


def like(c: sa.ColumnElement[str], v: str) -> sa.BinaryExpression[bool]:
    return c.like(escape_wildcard(v), escape="\\")


def ilike(c: sa.ColumnElement[str], v: str) -> sa.BinaryExpression[bool]:
    return c.ilike(escape_wildcard(v), escape="\\")


def notlike(c: sa.ColumnElement[str], v: str) -> sa.BinaryExpression[bool]:
    return c.notlike(escape_wildcard(v), escape="\\")


def notilike(c: sa.ColumnElement[str], v: str) -> sa.BinaryExpression[bool]:
    return c.notilike(escape_wildcard(v), escape="\\")


def escape_wildcard(v: str) -> str:
    return v.replace("%", "\\%").replace("*", "%")


def noop_filter_func(
    exc: AnyStatement,
    value: Any,
    **kwargs: Any,
) -> AnyStatement:
    return exc


class Filter(object):
    """Advanced query filtering with schema-based validation and relationship traversal.

    Constructs type-safe WHERE clauses from filter schemas, supporting nested relationships,
    custom comparison operators (like, gt, lt, in, etc.), and type validation.

    Parameters
    ----------
    filter_schema : FilterSchema
        The annotated class to use as a filter schema. Since only the annotations are read, the
        actual type does not matter.
    model_class : type[DefaultModelT]
        The SQLAlchemy ORM model class to query.

    Usage
    -----
    .. code:: python

        from toolkit.db import (
            DeclarativeBase,
            ItemRepository,
            ModelTarget,
            Filter,
            SessionExecutor,
            types,
        )
        from .user_model import User

        class UserFilter:
            id: int
            id__in: list[int]
            name: str
            name__like: str

        class UserRepository(ItemRepository[User]):
            target = ModelTarget(User)
            filter = Filter(UserFilter, User)

        repo = UserRepository(SessionExecutor(session))
        repo.create({"name": "markus"})
        repo.create({"name": "martha"})

        repo.list(name__like="mar*")
        #> [User(id=1, name="markus"), User(id=2, name="martha")]


    """

    table: sa.Table
    """The SQLAlchemy table associated with the filter schema."""
    lookup_seperator: str = "__"
    """Delimiter for separating field names from lookup operators in filter schemas."""

    filter_schema: FilterSchema
    """The schema defining available filters and their types."""
    related_schemas: dict[tuple[str, ...], RelationshipPath]
    """Mapping of relationship paths to their schemas for nested filtering."""
    filter_functions: dict[tuple[str, ...], PartialFilterFunc]
    """Pre-built filter functions indexed by field path."""
    lookup_map: dict[type, dict[str, tuple[type, CompFunc]]] = {
        float: {
            "__root__": (float, operator.eq),
            "in": (list[float], in_),
            "gt": (float, operator.gt),
            "lt": (float, operator.lt),
            "gte": (float, operator.ge),
            "lte": (float, operator.le),
        },
        int: {
            "__root__": (int, operator.eq),
            "in": (list[int], in_),
            "gt": (int, operator.gt),
            "lt": (int, operator.lt),
            "gte": (int, operator.ge),
            "lte": (int, operator.le),
        },
        bool: {
            "__root__": (bool, operator.eq),
        },
        str: {
            "__root__": (str, operator.eq),
            "in": (list[str], in_),
            "like": (str, like),
            "ilike": (str, ilike),
            "notlike": (str, notlike),
            "notilike": (str, notilike),
        },
    }
    """Type-specific lookup operators (e.g., __root__, gt, lt, in, like)."""
    valid_lookups: set[str] = set()
    """Valid lookup operators extracted from lookup_map."""
    valid_types: set[type] = set()
    """Valid field types extracted from lookup_map."""

    def __init__(
        self,
        filter_schema: FilterSchema,
        model_class: type[ModelProtocol],
    ):
        self.filter_schema = filter_schema
        self.table = get_mapped_table(model_class)

        for lookups in self.lookup_map.values():
            self.valid_lookups |= set(lookups.keys())
            types = {t for t, _ in lookups.values()}
            self.valid_types |= types

        self.related_schemas = {}
        self.filter_functions = {}
        self.build_lookup_tables(self.filter_schema)

    def build_filter_function(
        self,
        schema: FilterSchema,
        path: tuple[str, ...],
        field: str,
        field_type: type[FilterValue],
    ) -> PartialFilterFunc:
        # split the field and check the lookup
        (*rest, lookup) = field.split(self.lookup_seperator)

        if len(rest) == 0 or (lookup not in self.valid_lookups):
            # `split()` didnt really split
            # so we assume to be filtering without a lookup
            lookup = "__root__"
            column_name = field
        else:
            column_name = self.lookup_seperator.join(rest)

        # if we are currently on a related schema
        # get the column from any of the relationships
        # else get it from our table
        relpath = self.related_schemas.get(path, None)
        column: sa.ColumnElement[Any] | None = None
        if relpath is not None and len(relpath) > 0:
            rel = tuple(relpath)[-1]
            table = get_remote_table(rel)
            column = table.c.get(column_name, None)
        else:
            table = self.table
            column = self.table.c.get(column_name, None)

        if column is None:
            raise ProgrammingError(
                f"Could not find column for name '{column_name}' on table '{table.name}'."
            )
        column_type = column.type.python_type

        # check if we have a corresponding lookup
        try:
            lookup_type, comp_func = self.lookup_map[column_type][lookup]
        except KeyError:
            raise ProgrammingError(
                f"No available lookup for type `{column_type}` and "
                f"lookup '{lookup}' for field `{schema.__name__}.{field}`."
            )

        if not (field_type == lookup_type):
            raise ProgrammingError(
                f"Type `{field_type}` of the field `{schema.__name__}.{field}`"
                f"does not match type `{lookup_type}` for '{lookup}' on column type `{column_type}`."
            )

        # build the filter function
        def filter_func(
            exc: AnyStatement,
            value: Any,
            # type checker is not picking up the `is None` check
            column: sa.ColumnElement[Any] = cast(sa.ColumnElement[Any], column),
            **kwargs: Any,
        ) -> AnyStatement:
            return exc.where(comp_func(column, value))

        return filter_func

    def is_valid_type(self, type_: type[Any]) -> bool:
        return type_ in self.valid_types

    def build_lookup_tables(
        self, schema: FilterSchema, path: tuple[str, ...] | None = None
    ) -> None:
        if path is None:
            path = tuple()

        # `include_extra` will return `Annotated` objects
        hints = get_type_hints(schema, include_extras=True)
        for field, annot in hints.items():
            subpath = (*path, field)
            origin = get_origin(annot)

            # TODO: Properly support union
            if origin is Annotated:
                annotated_origin = annot.__origin__
                relpath: RelationshipPath | None = None
                override_func: FilterFunc | None = None
                for m in annot.__metadata__:
                    if callable(m):
                        override_func = m
                        continue
                    try:
                        relpath = get_relationship_path(m)
                    except ProgrammingError:
                        continue

                if get_origin(annotated_origin) in {Union, UnionType}:
                    if override_func is None:
                        raise ProgrammingError(
                            "Union annotation requires a custom filter function."
                        )

                    if relpath is not None:
                        self.related_schemas[subpath] = relpath

                    self.filter_functions[subpath] = functools.partial(
                        override_func, schema=schema
                    )
                    for sub_type in get_args(annotated_origin):
                        if getattr(sub_type, "__annotations__", None) is not None:
                            self.build_lookup_tables(sub_type, path=subpath)

                elif getattr(annotated_origin, "__annotations__", None) is not None:
                    related_schema: FilterSchema = annotated_origin
                    if related_schema is self.filter_schema:
                        # dont follow paths back to ourselves to avoid infinite loops
                        continue  # TODO: Log/Error?

                    if relpath is None and override_func is None:
                        raise ProgrammingError(
                            "No relationship attribute, path or override filter function "
                            "found in related schemas `Annotated` annotation."
                        )

                    if relpath is None:
                        relpath = tuple()

                    self.related_schemas[subpath] = relpath

                    if override_func is not None:
                        self.filter_functions[subpath] = functools.partial(
                            override_func, schema=schema
                        )

                    self.build_lookup_tables(related_schema, path=subpath)
                else:
                    if override_func is None:
                        raise ProgrammingError(
                            "No custom filter function found in related schemas `Annotated` annotation."
                        )
                    self.filter_functions[subpath] = functools.partial(
                        override_func, schema=schema
                    )
            elif self.is_valid_type(annot):
                self.filter_functions[subpath] = self.build_filter_function(
                    schema, path, field, annot
                )
            elif getattr(annot, "__annotations__", None) is not None:
                self.related_schemas[subpath] = tuple()
                self.build_lookup_tables(annot, path=subpath)
            else:
                # annotation could not be parsed, field skipped.
                continue

    def where_related_item_matches(
        self,
        repo: "BaseRepository[Any]",
        exc: sa.Select[Any] | sa.Exists,
        path: tuple[str, ...],
        relpath: RelationshipPath,
        related_value: dict[str, "FilterValue"],
    ) -> sa.Select[Any] | sa.Exists:
        # Empty relationship path means the payload is already at the current scope,
        # so recurse directly into child keys without wrapping in has()/any().
        if len(relpath) == 0:
            for key, value in related_value.items():
                exc = self.where_filter_item_matches(repo, exc, (*path, key), value)
            return exc

        # Build all leaf predicates first, then wrap them from inside out with
        # has()/any() to keep every relation step correlated to its parent.
        leaf_select = sa.select(sa.literal(1))
        for key, value in related_value.items():
            leaf_select = self.where_filter_item_matches(
                repo, leaf_select, (*path, key), value
            )

        criterion = leaf_select.whereclause
        if criterion is None:
            criterion = sa.true()

        # Wrap from leaf to root so each relationship comparator is correlated to
        # its direct parent, avoiding cartesian FROM expansion.
        for attr in reversed(relpath):
            try:
                criterion = cast(sa.ColumnElement[bool], attr.has(criterion))
            except InvalidRequestError:
                criterion = cast(sa.ColumnElement[bool], attr.any(criterion))

        return exc.where(criterion)

    def _apply_related_group(
        self,
        repo: "BaseRepository[Any]",
        exc: "sa.Select[Any] | sa.Exists",
        attr: Any,
        entries: list[tuple[tuple[str, ...], RelationshipPath, FilterValue]],
    ) -> "sa.Select[Any] | sa.Exists":
        """Build a single grouped criterion for *entries* and wrap with has()/any().

        If the remote table for *attr* is already present in the FROM clause
        (i.e. JOINed for column projection), predicates are applied directly
        instead of wrapping in a correlated subquery.
        """
        # Fast path: table already JOINed — apply predicates directly.
        if isinstance(exc, sa.Select) and _is_joined(exc, get_remote_table(attr)):
            nested: dict[
                Any,
                list[tuple[tuple[str, ...], RelationshipPath, FilterValue]],
            ] = {}
            for path, relpath, value in entries:
                if len(relpath) == 0:
                    if not isinstance(value, dict):
                        raise ProgrammingError(
                            f"Expected dict for related filter path: {path}."
                        )
                    for key, sub_value in value.items():
                        sub_path = (*path, key)
                        sub_relpath = self.related_schemas.get(sub_path, None)
                        if (
                            isinstance(sub_value, dict)
                            and sub_relpath is not None
                            and len(sub_relpath) > 0
                        ):
                            nested.setdefault(sub_relpath[0], []).append(
                                (sub_path, sub_relpath[1:], sub_value)
                            )
                        else:
                            exc = self.where_filter_item_matches(
                                repo, exc, sub_path, sub_value
                            )
                else:
                    nested.setdefault(relpath[0], []).append((path, relpath[1:], value))
            for nested_attr, group in nested.items():
                exc = self._apply_related_group(repo, exc, nested_attr, group)
            return exc

        # Normal path: build grouped criterion and wrap with has()/any().
        criterion = self._build_related_group_criterion(repo, entries)
        try:
            return exc.where(cast(sa.ColumnElement[bool], attr.has(criterion)))
        except InvalidRequestError:
            return exc.where(cast(sa.ColumnElement[bool], attr.any(criterion)))

    def _build_related_group_criterion(
        self,
        repo: "BaseRepository[Any]",
        entries: list[tuple[tuple[str, ...], RelationshipPath, FilterValue]],
    ) -> sa.ColumnElement[bool]:
        # Build a single criterion tree for entries that share a relationship
        # prefix, so common traversal segments are emitted once.
        leaf_select = sa.select(sa.literal(1))
        nested_groups: dict[
            Any,
            list[tuple[tuple[str, ...], RelationshipPath, FilterValue]],
        ] = {}

        for path, relpath, value in entries:
            if len(relpath) == 0:
                if not isinstance(value, dict):
                    raise ProgrammingError(
                        f"Expected dict for related filter path: {path}."
                    )
                for key, sub_value in value.items():
                    leaf_select = self.where_filter_item_matches(
                        repo, leaf_select, (*path, key), sub_value
                    )
            else:
                # Group by the next relationship attribute and recurse on the
                # remaining relationship path.
                nested_groups.setdefault(relpath[0], []).append(
                    (path, relpath[1:], value)
                )

        criterion = leaf_select.whereclause
        if criterion is None:
            criterion = sa.true()

        # Combine each grouped branch under AND: all top-level filter keys must
        # match simultaneously.
        for attr, group_entries in nested_groups.items():
            nested_criterion = self._build_related_group_criterion(repo, group_entries)
            try:
                rel_criterion = cast(sa.ColumnElement[bool], attr.has(nested_criterion))
            except InvalidRequestError:
                rel_criterion = cast(sa.ColumnElement[bool], attr.any(nested_criterion))
            criterion = sa.and_(criterion, rel_criterion)

        return criterion

    @overload
    def where_filter_item_matches(
        self,
        repo: "BaseRepository[Any]",
        exc: sa.Exists,
        path: tuple[str, ...],
        value: FilterValue,
    ) -> sa.Exists: ...

    @overload
    def where_filter_item_matches(
        self,
        repo: "BaseRepository[Any]",
        exc: sa.Select[SelectR],
        path: tuple[str, ...],
        value: FilterValue,
    ) -> sa.Select[SelectR]: ...

    def where_filter_item_matches(
        self,
        repo: "BaseRepository[Any]",
        exc: sa.Select[SelectR] | sa.Exists,
        path: tuple[str, ...],
        value: FilterValue,
    ) -> sa.Select[SelectR] | sa.Exists:
        relpath = self.related_schemas.get(path, None)
        filter_function = self.filter_functions.get(path, None)
        if filter_function is None and not isinstance(value, dict):
            raise ProgrammingError(f"No filter function built for path: {path}")

        if filter_function is not None:
            exc = filter_function(exc, value, repo=repo)

        if isinstance(value, dict):
            if relpath is not None:
                exc = self.where_related_item_matches(repo, exc, path, relpath, value)
            else:
                for field_name, sub_value in value.items():
                    exc = self.where_filter_item_matches(
                        repo, exc, (*path, field_name), sub_value
                    )

        return exc

    @overload
    def where_filter_matches(
        self, repo: "BaseRepository[Any]", exc: sa.Exists, values: "Values"
    ) -> sa.Exists: ...

    @overload
    def where_filter_matches(
        self,
        repo: "BaseRepository[Any]",
        exc: sa.Select[SelectR],
        values: "Values",
    ) -> sa.Select[SelectR]: ...

    def where_filter_matches(
        self,
        repo: "BaseRepository[Any]",
        exc: sa.Select[SelectR] | sa.Exists,
        values: "Values",
    ) -> sa.Select[SelectR] | sa.Exists:
        """
        Add WHERE clauses to the given SQLAlchemy statement to match the provided
        filter values according to the filter schema.

        Parameters
        ----------
        exc : sa.Select[SelectR] | sa.Update | sa.Delete
            The SQLAlchemy statement.
        values : WhereKwargsT
            The filter values to match.

        Returns
        -------
        sa.Select[SelectR] | sa.Update | sa.Delete
            The statement with WHERE clauses added.
        """
        grouped_related: dict[
            Any,
            list[tuple[tuple[str, ...], RelationshipPath, FilterValue]],
        ] = {}

        # First pass: keep non-related keys on the normal path and group related
        # dict filters by their first relationship attribute.
        for field_name, value in values.items():
            path = (field_name,)
            relpath = self.related_schemas.get(path, None)
            if isinstance(value, dict) and relpath is not None and len(relpath) > 0:
                grouped_related.setdefault(relpath[0], []).append(
                    (path, relpath[1:], value)
                )
            else:
                exc = self.where_filter_item_matches(repo, exc, path, value)

        # Second pass: build grouped criterion and apply via has()/any().
        for attr, entries in grouped_related.items():
            exc = self._apply_related_group(repo, exc, attr, entries)

        return exc
