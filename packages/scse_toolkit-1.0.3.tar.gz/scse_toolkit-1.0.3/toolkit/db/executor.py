import abc
import contextlib
from typing import Any, Generator, Mapping, Sequence, TypeVar, cast

import sqlalchemy as sa
from sqlalchemy.orm import Session

SelectR = TypeVar("SelectR", bound=tuple[Any, ...])

SingleExecuteParams = Mapping[str, Any]
MultiExecuteParams = Sequence[SingleExecuteParams]
AnyExecuteParams = MultiExecuteParams | SingleExecuteParams


class AbstractExecutor(abc.ABC):
    engine: sa.Engine

    def rowcount_or_none(
        self, result: sa.Result[Any], expect_rowcount: int | None = None
    ) -> int | None:
        if isinstance(result, sa.CursorResult) and result.supports_sane_rowcount():
            return result.rowcount
        return None

    @abc.abstractmethod
    @contextlib.contextmanager
    def select(
        self, exc: sa.Select[SelectR]
    ) -> Generator[sa.Result[SelectR], None, None]: ...

    @abc.abstractmethod
    @contextlib.contextmanager
    def delete(self, exc: sa.Delete) -> Generator[int | None, None, None]: ...

    @abc.abstractmethod
    @contextlib.contextmanager
    def update(
        self,
        exc: sa.Update,
        parameters: AnyExecuteParams | None = None,
    ) -> Generator[int | None, None, None]: ...

    @abc.abstractmethod
    @contextlib.contextmanager
    def insert_one(
        self, exc: sa.Insert, parameters: AnyExecuteParams | None = None
    ) -> Generator[sa.CursorResult[Any], None, None]: ...

    @abc.abstractmethod
    @contextlib.contextmanager
    def insert_many(
        self, exc: sa.Insert, parameters: AnyExecuteParams | None = None
    ) -> Generator[sa.IteratorResult[Any], None, None]: ...


class ConnectionExecutor(AbstractExecutor):
    """Database executor using SQLAlchemy connection-level execution.

    Executes SQL statements using direct database connections, automatically managing
    connection lifecycle and transaction handling. Each operation opens a new connection
    and commits/rolls back transactions appropriately.

    Parameters
    ----------
    engine : sa.Engine
        SQLAlchemy engine instance.

    """

    engine: sa.Engine
    """The SQLAlchemy engine for connection management."""

    def __init__(self, engine: sa.Engine):
        self.engine = engine

    @contextlib.contextmanager
    def select(
        self, exc: sa.Select[SelectR]
    ) -> Generator[sa.Result[SelectR], None, None]:
        with self.engine.connect() as conn:
            yield conn.execute(exc)

    @contextlib.contextmanager
    def delete(self, exc: sa.Delete) -> Generator[int | None, None, None]:
        with self.engine.begin() as conn:
            result = conn.execute(exc)
            try:
                yield self.rowcount_or_none(result)
            except Exception as e:
                conn.rollback()
                raise e

            conn.commit()

    @contextlib.contextmanager
    def update(
        self,
        exc: sa.Update,
        parameters: AnyExecuteParams | None = None,
    ) -> Generator[int | None, None, None]:
        with self.engine.begin() as conn:
            result = conn.execute(exc, parameters)
            try:
                yield self.rowcount_or_none(result)
            except Exception as e:
                conn.rollback()
                raise e

            conn.commit()

    @contextlib.contextmanager
    def insert_one(
        self, exc: sa.Insert, parameters: AnyExecuteParams | None = None
    ) -> Generator[sa.CursorResult[Any], None, None]:
        with self.engine.connect() as conn:
            try:
                result = conn.execute(exc, parameters)
                is_returning = (
                    isinstance(result, sa.ChunkedIteratorResult) or result.returns_rows
                )

                if not is_returning:
                    conn.commit()
            except Exception as e:
                conn.rollback()
                raise e

            yield result

            if is_returning:
                try:
                    conn.commit()
                except Exception as e:
                    conn.rollback()
                    raise e

    @contextlib.contextmanager
    def insert_many(
        self, exc: sa.Insert, parameters: MultiExecuteParams | None = None
    ) -> Generator[sa.IteratorResult[Any], None, None]:
        with self.engine.connect() as conn:
            try:
                result = conn.execute(exc, parameters)
                conn.commit()
            except Exception as e:
                conn.rollback()
                raise e

            # The sqlalchemy type hint is wrong.
            # When inserting many rows, this is actually an IteratorResult
            yield cast(sa.IteratorResult[Any], result)


class SessionExecutor(AbstractExecutor):
    """Database executor using SQLAlchemy ORM session-level execution.

    Executes SQL statements within the context of an ORM session, leveraging
    session transaction management, identity maps, and lazy loading. All operations
    are managed by the session's lifecycle.

    Parameters
    ----------
    session : Session
        SQLAlchemy ORM session instance.
    """

    session: Session
    """The SQLAlchemy ORM session."""
    engine: sa.Engine
    """The SQLAlchemy engine extracted from the session's bind."""

    def __init__(self, session: Session):
        self.session = session

        engine_or_connection = session.get_bind()
        if isinstance(engine_or_connection, sa.Connection):
            self.engine = engine_or_connection.engine
        else:
            self.engine = engine_or_connection

    @contextlib.contextmanager
    def select(
        self, exc: sa.Select[SelectR]
    ) -> Generator[sa.Result[SelectR], None, None]:
        yield self.session.execute(exc)

    @contextlib.contextmanager
    def delete(self, exc: sa.Delete) -> Generator[int | None, None, None]:
        result = self.session.execute(exc)

        try:
            yield self.rowcount_or_none(result)
        except Exception as e:
            self.session.rollback()
            raise e

        self.session.commit()

    @contextlib.contextmanager
    def update(
        self,
        exc: sa.Update,
        parameters: AnyExecuteParams | None = None,
    ) -> Generator[int | None, None, None]:
        result = self.session.execute(exc, parameters)

        try:
            yield self.rowcount_or_none(result)
        except Exception as e:
            self.session.rollback()
            raise e

        self.session.commit()

    @contextlib.contextmanager
    def insert_one(
        self, exc: sa.Insert, parameters: AnyExecuteParams | None = None
    ) -> Generator[sa.CursorResult[Any], None, None]:
        try:
            result = self.session.execute(exc, parameters)
            is_returning = isinstance(result, sa.ChunkedIteratorResult) or (
                isinstance(result, sa.CursorResult) and result.returns_rows
            )

            if not is_returning:
                self.session.commit()

        except Exception as e:
            self.session.rollback()
            raise e

        yield cast(sa.CursorResult[Any], result)

        if is_returning:
            try:
                self.session.commit()
            except Exception as e:
                self.session.rollback()
                raise e

    @contextlib.contextmanager
    def insert_many(
        self, exc: sa.Insert, parameters: MultiExecuteParams | None = None
    ) -> Generator[sa.IteratorResult[Any], None, None]:
        try:
            result = self.session.execute(exc, parameters)
            self.session.commit()
        except Exception as e:
            self.session.rollback()
            raise e

        # The sqlalchemy type hint is wrong.
        # When inserting many rows, this is actually an IteratorResult
        yield cast(sa.IteratorResult[Any], result)
