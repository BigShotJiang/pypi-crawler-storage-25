# compatiblity import module (moved to `toolkit.auth.token`)
# TODO: Remove when migrated
from .auth.token import *  # noqa: F403
