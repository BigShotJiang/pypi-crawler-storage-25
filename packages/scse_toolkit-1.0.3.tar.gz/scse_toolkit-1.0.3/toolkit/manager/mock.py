from typing import Any, Iterable, List, cast

import httpx
import polars as pl

from toolkit.exceptions import registry as default_registry

from .client import BaseRepository, ManagerClient, ModelType, UserRepository
from .models import (
    DjangoFixtureDict,
    Ixmp4Instance,
    ModelPermission,
    User,
)

FixtureList = list[DjangoFixtureDict]


def merge_related_fixtures(
    root_fixtures: FixtureList, related_fixture: FixtureList, pointer_field: str
) -> FixtureList:
    res = []
    for related in related_fixture:
        merged = related.copy()
        pointer = cast(int, merged["fields"][pointer_field])
        [serviceinstance] = filter_fixtures(root_fixtures, pk=pointer)
        merged["fields"].update(serviceinstance["fields"])
        res.append(merged)
    return res


def simulate_django_filters(
    fixtures: FixtureList, key: str, filter_val: Any
) -> FixtureList:
    key, *lookups = key.split("__")
    if len(lookups) == 0:

        def lookup(x: Any, y: Any) -> bool:
            return bool(x == y)

    elif lookups[0] == "in":

        def lookup(x: Any, y: Any) -> bool:
            if isinstance(x, Iterable) and isinstance(y, Iterable):
                return any(sx in y for sx in x)
            return x in y
    else:

        def lookup(x: Any, y: Any) -> bool:
            return bool(x == y)

    fixtures = [
        obj for obj in fixtures if lookup(obj.get("fields", {}).get(key), filter_val)
    ]
    return fixtures


def filter_fixtures(
    fixtures: FixtureList,
    pk: int | None = None,
    pk__in: list[int] | None = None,
    model: str | None = None,
    **kwargs: object,
) -> FixtureList:
    if pk is not None:
        fixtures = [obj for obj in fixtures if obj.get("pk") == pk]

    if pk__in is not None:
        fixtures = [obj for obj in fixtures if obj.get("pk") in pk__in]

    if model is not None:
        fixtures = [obj for obj in fixtures if obj.get("model") == model]

    for key, filter_val in kwargs.items():
        fixtures = simulate_django_filters(fixtures, key, filter_val)

    return fixtures


class MockRepository(BaseRepository[ModelType]):
    fixtures: FixtureList
    client: "MockManagerClient"

    def __init__(
        self,
        client: "MockManagerClient",
        fixtures: FixtureList,
        response_model: type[ModelType],
    ):
        self.fixtures = fixtures
        self.response_model = response_model
        self.client = client
        self.cached_list = self.list
        self.cached_tabulate = self.tabulate
        self.cached_retrieve = self.retrieve

    def list(self, **kwargs: Any) -> List[ModelType]:
        filtered = filter_fixtures(self.fixtures, **kwargs)
        return [self.response_model.from_django_fixture(r) for r in filtered]

    def tabulate(self, **kwargs: Any) -> pl.DataFrame:
        filtered = filter_fixtures(self.fixtures, **kwargs)
        serialized = [
            self.response_model.from_django_fixture(r).model_dump() for r in filtered
        ]
        return pl.DataFrame(serialized)

    def retrieve(self, id: int) -> ModelType:
        items = filter_fixtures(self.fixtures, pk=id)

        if len(items) != 1:
            self.client.raise_code_or_unknown(None, httpx.Response(status_code=404))

        return self.response_model.from_django_fixture(items[0])


class MockUserRepository(UserRepository, MockRepository[User]):
    me_user: User | None

    def __init__(
        self,
        client: "MockManagerClient",
        fixtures: FixtureList,
        me_user: User | None = None,
    ):
        self.fixtures = fixtures
        self.response_model = User
        self.client = client
        self.me_user = me_user

    def impersonate(self, id: int) -> dict[str, str]:
        raise NotImplementedError(
            f"`{self.__class__.__name__}` cannot generate impersonation tokens."
        )

    def me(self) -> User:
        if self.me_user is None:
            return self.client.raise_code_or_unknown(
                None, httpx.Response(status_code=403)
            )

        return self.me_user


class MockModelPermissionsRepository(MockRepository[ModelPermission]):
    def __init__(
        self,
        client: "MockManagerClient",
        fixtures: FixtureList,
    ):
        super().__init__(client, fixtures, ModelPermission)

    def get_users(self, user_ids: List[int]) -> FixtureList:
        return filter_fixtures(self.client.user_fixtures, pk__in=user_ids)

    def get_fixtures(self, group__users: List[int] | int | None) -> FixtureList:
        if group__users is None:
            return self.fixtures

        if not isinstance(group__users, Iterable):
            group__users = [group__users]

        users = self.get_users(group__users)
        user_groups: list[Any] = [u.get("fields", {}).get("groups", []) for u in users]
        groups = [g for gs in user_groups for g in gs]
        filtered = filter_fixtures(self.fixtures, group__in=groups)
        return filtered

    def list(
        self, *, group__users: List[int] | int | None = None, **kwargs: Any
    ) -> List[ModelPermission]:
        fixtures = self.get_fixtures(group__users)
        filtered = filter_fixtures(fixtures, **kwargs)
        return [self.response_model.from_django_fixture(r) for r in filtered]

    def tabulate(
        self, *, group__users: List[int] | int | None = None, **kwargs: Any
    ) -> pl.DataFrame:
        fixtures = self.get_fixtures(group__users)
        filtered = filter_fixtures(fixtures, **kwargs)
        serialized = [
            self.response_model.from_django_fixture(r).model_dump() for r in filtered
        ]
        return pl.DataFrame(serialized)


class MockManagerClient(ManagerClient):
    fixtures: FixtureList
    user: User | None
    exception_registry = default_registry

    def __init__(self, fixtures: FixtureList, user: User | None = None) -> None:
        self.fixtures = fixtures
        self.user = user
        self.user_fixtures = filter_fixtures(fixtures, model="authentication.user")
        self.ixmp4_fixtures = merge_related_fixtures(
            filter_fixtures(fixtures, model="services.serviceinstance"),
            filter_fixtures(fixtures, model="services.ixmp4instance"),
            "serviceinstance_ptr",
        )
        self.model_permission_fixtures = filter_fixtures(
            fixtures, model="services.modelpermission"
        )

        self.model_permissions = MockModelPermissionsRepository(
            self, self.model_permission_fixtures
        )
        self.ixmp4 = MockRepository(self, self.ixmp4_fixtures, Ixmp4Instance)
        self.users = MockUserRepository(self, self.user_fixtures, me_user=user)

    def check_root(self) -> None:
        pass
