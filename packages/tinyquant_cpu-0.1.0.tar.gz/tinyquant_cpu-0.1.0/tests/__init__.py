"""TinyQuant test suite."""
