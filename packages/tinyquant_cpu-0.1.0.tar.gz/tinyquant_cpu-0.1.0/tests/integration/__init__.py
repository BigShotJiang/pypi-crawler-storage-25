"""Integration tests for TinyQuant."""
