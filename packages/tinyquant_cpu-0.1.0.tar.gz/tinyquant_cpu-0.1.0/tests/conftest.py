"""Shared pytest fixtures for TinyQuant tests."""

from __future__ import annotations

import numpy as np
import pytest
from numpy.typing import NDArray

from tinyquant_cpu.backend.brute_force import BruteForceBackend
from tinyquant_cpu.codec.codebook import Codebook
from tinyquant_cpu.codec.codec_config import CodecConfig
from tinyquant_cpu.codec.rotation_matrix import RotationMatrix
from tinyquant_cpu.corpus.compression_policy import CompressionPolicy
from tinyquant_cpu.corpus.corpus import Corpus


@pytest.fixture()
def config_4bit() -> CodecConfig:
    """Standard 4-bit codec config for tests."""
    return CodecConfig(bit_width=4, seed=42, dimension=64)


@pytest.fixture()
def config_2bit() -> CodecConfig:
    """Standard 2-bit codec config for tests."""
    return CodecConfig(bit_width=2, seed=42, dimension=64)


@pytest.fixture()
def config_8bit() -> CodecConfig:
    """Standard 8-bit codec config for tests."""
    return CodecConfig(bit_width=8, seed=42, dimension=64)


@pytest.fixture()
def sample_vectors() -> NDArray[np.float32]:
    """100 random vectors of dimension 64 for training/testing."""
    rng = np.random.default_rng(42)
    return rng.standard_normal((100, 64)).astype(np.float32)


@pytest.fixture()
def sample_vector() -> NDArray[np.float32]:
    """Single random vector of dimension 64."""
    rng = np.random.default_rng(42)
    return rng.standard_normal(64).astype(np.float32)


@pytest.fixture()
def trained_codebook(
    config_4bit: CodecConfig,
    sample_vectors: NDArray[np.float32],
) -> Codebook:
    """Codebook trained on sample vectors with 4-bit config."""
    return Codebook.train(sample_vectors, config_4bit)


@pytest.fixture()
def rotation_matrix(config_4bit: CodecConfig) -> RotationMatrix:
    """Rotation matrix generated from 4-bit config."""
    return RotationMatrix.from_config(config_4bit)


@pytest.fixture()
def corpus_compress(
    config_4bit: CodecConfig,
    trained_codebook: Codebook,
) -> Corpus:
    """Corpus with COMPRESS policy."""
    return Corpus(
        "test-corpus",
        config_4bit,
        trained_codebook,
        CompressionPolicy.COMPRESS,
    )


@pytest.fixture()
def corpus_passthrough(
    config_4bit: CodecConfig,
    trained_codebook: Codebook,
) -> Corpus:
    """Corpus with PASSTHROUGH policy."""
    return Corpus(
        "test-corpus-pt",
        config_4bit,
        trained_codebook,
        CompressionPolicy.PASSTHROUGH,
    )


@pytest.fixture()
def corpus_fp16(
    config_4bit: CodecConfig,
    trained_codebook: Codebook,
) -> Corpus:
    """Corpus with FP16 policy."""
    return Corpus(
        "test-corpus-fp16",
        config_4bit,
        trained_codebook,
        CompressionPolicy.FP16,
    )


@pytest.fixture()
def sample_corpus(
    config_4bit: CodecConfig,
    trained_codebook: Codebook,
    sample_vectors: NDArray[np.float32],
) -> Corpus:
    """Corpus pre-populated with 100 vectors under COMPRESS policy."""
    corpus = Corpus(
        "sample-corpus",
        config_4bit,
        trained_codebook,
        CompressionPolicy.COMPRESS,
    )
    for i, vec in enumerate(sample_vectors):
        corpus.insert(f"vec-{i:04d}", vec)
    return corpus


@pytest.fixture()
def brute_force_backend() -> BruteForceBackend:
    """Empty BruteForceBackend instance."""
    return BruteForceBackend()


@pytest.fixture()
def gold_corpus_vectors() -> NDArray[np.float32]:
    """200 synthetic vectors at dimension 128 for gold-standard E2E tests."""
    rng = np.random.default_rng(7777)
    return rng.standard_normal((200, 128)).astype(np.float32)
