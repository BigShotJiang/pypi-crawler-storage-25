"""Agent loop: the core processing engine."""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any, Awaitable, Callable, Coroutine, cast

from exoclaw._compat import (
    IS_MICROPYTHON,
    bind_log_contextvars,
    get_log_contextvars,
    get_logger,
    monotonic_diff_ms,
    unbind_log_contextvars,
)

# ``warnings`` isn't in MicroPython's stdlib. The deprecation
# notice lives behind the IS_MICROPYTHON guard at the call site —
# MP-deployed agents (firmware, ESP32) silently skip the notice
# rather than crash on import. CPython gets the standard behaviour.
if not IS_MICROPYTHON:  # pragma: no cover (micropython)
    import warnings as _warnings
else:  # pragma: no cover (cpython)
    _warnings = None  # type: ignore[assignment]
from exoclaw._compat import (
    monotonic_ms as _module_monotonic_ms,
)
from exoclaw.agent.conversation import Conversation
from exoclaw.agent.hooks import (
    BEFORE_FINISH,
    BEFORE_TOOL,
    BeforeFinishResult,
    BeforeToolResult,
    HookContext,
)
from exoclaw.agent.tools.protocol import Tool, ToolContext
from exoclaw.agent.tools.registry import ToolRegistry
from exoclaw.bus.events import InboundMessage, OutboundMessage
from exoclaw.bus.protocol import Bus
from exoclaw.executor import DirectExecutor, Executor, ToolResult
from exoclaw.iteration_policy import IterationPolicy
from exoclaw.providers.protocol import LLMProvider
from exoclaw.providers.types import ContextWindowExceededError, ToolCallRequest
from exoclaw.utils import create_isolated_task

_UNSET: object = object()  # sentinel: distinguishes "not provided" from explicit None


class AgentLoop:
    """
    The agent loop is the core processing engine.

    It:
    1. Receives messages from the bus
    2. Asks the Conversation for the prompt
    3. Calls the LLM
    4. Executes tool calls
    5. Records the turn and sends the response back
    """

    def __init__(
        self,
        bus: Bus,
        provider: LLMProvider,
        conversation: Conversation,
        model: str | None = None,
        max_iterations: int = 40,
        temperature: float = 0.1,
        max_tokens: int = 4096,
        reasoning_effort: str | None = None,
        tools: list[Tool] | None = None,
        registry: ToolRegistry | None = None,
        # Optional lifecycle callbacks — all default to None (backwards compatible).
        # Plugins pass these in; the loop calls them at the appropriate point.
        on_pre_context: Callable[[str, str, str, str], Awaitable[str]] | None = None,
        on_pre_tool: Callable[[str, dict[str, object], str], Awaitable[str | None]] | None = None,
        on_post_turn: Callable[[list[dict[str, object]], str, str, str], Awaitable[None]]
        | None = None,
        on_max_iterations: Callable[[str, str, str], Awaitable[None]] | None = None,
        # Called with all tool calls before execution begins (structured, for UI/observability).
        on_tool_calls: Callable[["list[ToolCallRequest]"], Awaitable[None]] | None = None,
        # Called after each tool result (tool_call, result) — for streaming previews.
        on_tool_result: Callable[["ToolCallRequest", str], Awaitable[None]] | None = None,
        # Called when the model returns a final (no-tool-call) response, just
        # before the loop ends. Receives ``(final_content, tools_used,
        # session_key)`` and returns an optional follow-up message: a non-empty
        # return is appended as a user turn and the loop continues (the model
        # gets another turn); ``None``/empty ends the turn as usual. Lets a host
        # enforce a completion condition the model can't be trusted to honour on
        # its own — e.g. a required closing tool that wasn't called — by
        # re-prompting in place rather than ending early. The host owns the
        # stopping condition (it MUST eventually return ``None``);
        # ``max_iterations`` is the hard backstop against a hook that never
        # stops. Dispatched through ``executor.run_hook`` like the other
        # callbacks, so durable executors wrap it for replay safety.
        on_before_finish: Callable[[str, list[str], str], Awaitable[str | None]] | None = None,
        # DEPRECATED — prefer ``Conversation.recover_from_overflow`` (forwarded
        # via ``Executor.recover_from_overflow``). When set, this callback is
        # tried first on ``ContextWindowExceededError`` for back-compat; new
        # consumers should leave this ``None`` and have their Conversation
        # implement the recovery method instead. Receives the current message
        # list and should return a compacted version, or ``None`` to give up.
        on_context_overflow: Callable[
            ["list[dict[str, object]]"], Awaitable["list[dict[str, object]] | None"]
        ]
        | None = None,
        # Per-turn cap on overflow recovery attempts. Without a cap, a buggy
        # callback or recovery method that returns the same too-big list on
        # every retry would loop forever. Default mirrors OpenClaw's
        # MAX_OVERFLOW_COMPACTION_ATTEMPTS.
        max_recovery_attempts: int = 3,
        iteration_policy: IterationPolicy | None = None,
        executor: Executor | None = None,
        logger: Any | None = None,
    ) -> None:
        self.bus = bus
        self._executor: Executor = executor or DirectExecutor()
        self._iteration_policy = iteration_policy
        self.provider = provider
        self.model = model or provider.get_default_model()
        self.max_iterations = max_iterations
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.reasoning_effort = reasoning_effort
        self._extra_tools = tools or []
        self._on_pre_context = on_pre_context
        self._on_pre_tool = on_pre_tool
        self._on_post_turn = on_post_turn
        self._on_max_iterations = on_max_iterations
        self._on_tool_calls = on_tool_calls
        self._on_tool_result = on_tool_result
        self._on_before_finish = on_before_finish
        self._on_context_overflow = on_context_overflow
        if on_context_overflow is not None and _warnings is not None:
            _warnings.warn(  # pragma: no cover (micropython)
                "AgentLoop(on_context_overflow=...) is deprecated; implement "
                "Executor.recover_from_overflow(conversation, session_id) "
                "instead (which typically forwards to "
                "Conversation.recover_from_overflow, wrapping in a durability "
                "primitive when the executor needs replay safety). The "
                "callback operates on raw message lists and bypasses any "
                "conversation-side state (e.g. the consolidation policy's "
                "sidecar), which can desynchronise the persisted view from "
                "what the LLM saw.",
                DeprecationWarning,
                stacklevel=2,
            )
        self._max_recovery_attempts = max(1, int(max_recovery_attempts))

        self.conversation = conversation

        self.tools = registry or ToolRegistry()
        for tool in self._extra_tools:
            self.tools.register(tool)
            if hasattr(tool, "set_bus"):
                tool.set_bus(self.bus)  # type: ignore[call-non-callable]
            if hasattr(tool, "set_registry"):
                tool.set_registry(self.tools)  # type: ignore[call-non-callable]
        self._log: Any = logger or get_logger()
        # Bound clock — executor's ``monotonic_ms`` lets durable executors
        # substitute a deterministic clock. Test mocks and any custom executor
        # that doesn't ship the method fall back to the module helper. Cached
        # once because the call sites are on the per-tool / per-turn hot path.
        self._monotonic_ms: Callable[[], int] = getattr(
            self._executor, "monotonic_ms", _module_monotonic_ms
        )
        self._running = False
        self._active_tasks: dict[str, list[asyncio.Task[None]]] = {}  # session_key -> tasks
        self._processing_lock = asyncio.Lock()
        self._current_ctx: ToolContext | None = None  # set before each _run_agent_loop call

        # When the executor opts into durable inbound handoff, wire the
        # bus so ``publish_inbound`` forwards to ``executor.enqueue_inbound``
        # synchronously. That closes the crash window between "channel
        # received the message" and "agent started processing": with a
        # durable handler the message is journaled before the channel's
        # publish call returns, so an OOM in that window doesn't lose it.
        #
        # ``enqueue_inbound`` isn't on the ``Executor`` Protocol (same
        # opt-in shape as ``set_prior_source``) — pull it off the
        # concrete executor with ``getattr``. The ``set_inbound_hook``
        # lookup is also a ``getattr`` because it lives on the
        # ``InboundHookBus`` protocol and is only implemented by buses
        # that support the capability.
        #
        # If the executor advertises the flag but either side of the
        # wiring is missing, raise instead of silently falling back.
        # A silent fallback re-opens the exact durability gap the
        # opt-in is supposed to close, so the executor would think it
        # was durable without any runtime signal that it wasn't.
        # ``is True`` rather than a truthiness check — ``MagicMock(spec=)``
        # returns a truthy mock for any spec attribute, which would
        # silently enable the durable path for any test that uses a
        # spec'd executor. The opt-in is strictly a boolean toggle, so
        # require the literal ``True``.
        if getattr(self._executor, "handles_inbound_enqueue", False) is True:
            enqueue_inbound = getattr(self._executor, "enqueue_inbound", None)
            set_hook = getattr(self.bus, "set_inbound_hook", None)
            missing: list[str] = []
            if enqueue_inbound is None:
                missing.append("executor.enqueue_inbound")
            if set_hook is None:
                missing.append("bus.set_inbound_hook")
            if missing or set_hook is None or enqueue_inbound is None:
                # The ``or`` repeats narrow the unions for ty — the
                # ``missing`` list already captured the same condition
                # but the static type checker can't infer that across
                # two independent ``getattr`` calls.
                raise TypeError(
                    "Executor opted into durable inbound enqueue via "
                    "'handles_inbound_enqueue=True', but required wiring "
                    f"is missing: {', '.join(missing)}"
                )
            set_hook(enqueue_inbound)

    def _notify_tools_inbound(self, msg: InboundMessage) -> None:
        """Let tools that care about inbound messages update their state."""
        for tool in self.tools._tools.values():
            if hasattr(tool, "on_inbound"):
                tool.on_inbound(msg)  # type: ignore[call-non-callable]

    def _collect_plugin_context(self) -> list[str]:
        """Collect system_context() strings from tools that provide them."""
        ctx = []
        for tool in self.tools._tools.values():
            if hasattr(tool, "system_context"):
                try:
                    result = tool.system_context()  # type: ignore[call-non-callable]
                    if result and isinstance(result, str):
                        ctx.append(result)
                except Exception:
                    self._log.exception(
                        "system_context_error", **{"tool.name": getattr(tool, "name", "?")}
                    )
        return ctx

    async def _invoke_tool(self, tool_call: ToolCallRequest) -> tuple[str, object]:
        """Dispatch the tool, preferring the Step-D-aware
        ``execute_tool_with_handle`` when the executor has it.

        Step D added an optional ``execute_tool_with_handle`` method to
        the ``Executor`` Protocol with a default impl. Protocols don't
        propagate default impls to external implementations though, so
        ``DBOSExecutor`` and any non-subclass executor (or test mock)
        won't have the new method until they explicitly add it. Falls
        back to ``execute_tool`` in that case — same opt-in shape as
        ``set_prior_source`` / ``handles_inbound_enqueue``.

        Returns ``(content, content_file_path_or_None)``.
        """
        new_path = getattr(self._executor, "execute_tool_with_handle", None)
        if callable(new_path):
            outcome = await new_path(
                self.tools,
                tool_call.name,
                tool_call.arguments,
                self._current_ctx,
                tool_call_id=tool_call.id,
            )
            # Strict ``isinstance`` rather than duck-typing the
            # ``.content`` access. A spec'd ``MagicMock(spec=DirectExecutor)``
            # auto-resolves ``execute_tool_with_handle`` to an ``AsyncMock``
            # whose return is a bare ``Mock``; without this guard the loop
            # would propagate ``Mock`` objects as ``result`` and downstream
            # log assertions / message-shape checks would fail in
            # surprising ways. Real implementations return ``ToolResult``;
            # mocks fall through to the legacy path which the existing
            # ``execute_tool`` mock setup handles correctly.
            if isinstance(outcome, ToolResult):
                return outcome.content, outcome.content_file
        legacy = await self._executor.execute_tool(
            self.tools,
            tool_call.name,
            tool_call.arguments,
            self._current_ctx,
            tool_call_id=tool_call.id,
        )
        return legacy, None

    @staticmethod
    def _strip_think(text: str | None) -> str | None:
        """Remove <think>…</think> blocks that some models embed in content."""
        if not text:
            return None
        return re.sub(r"<think>[\s\S]*?</think>", "", text).strip() or None

    @staticmethod
    def _tool_hint(tool_calls: list[ToolCallRequest]) -> str:
        """Format tool calls as concise hint, e.g. 'web_search("query")'."""

        def _fmt(tc: ToolCallRequest) -> str:
            args = (tc.arguments[0] if isinstance(tc.arguments, list) else tc.arguments) or {}
            val = next(iter(args.values()), None) if isinstance(args, dict) else None
            if not isinstance(val, str):
                return str(tc.name)
            return f'{tc.name}("{val[:40]}…")' if len(val) > 40 else f'{tc.name}("{val}")'

        return ", ".join(_fmt(tc) for tc in tool_calls)

    async def _call_decider(self, method: str, event: str, **fields: Any) -> Any:
        """Call an optional Conversation decider (``before_tool`` /
        ``before_finish``) with a freshly built HookContext, and return its
        decision (or None).

        Reached via ``getattr`` so a Conversation that doesn't implement the
        optional async method simply contributes nothing. Anything that goes
        wrong — a non-awaitable test double, or a decider that raises — is
        logged and treated as no-op, so a buggy consumer can't take down the
        turn. (No ``__await__`` pre-check: MicroPython coroutines don't expose
        it, so we just await and let the try/except catch a non-coroutine.)"""
        fn = getattr(self.conversation, method, None)
        if fn is None:
            return None
        try:
            return await fn(self._make_hook_context(event, **fields))
        except Exception:
            self._log.exception("hook_decider_error", **{"hook.event": event})
            return None

    def _make_hook_context(self, event: str, **fields: Any) -> HookContext:
        """Build the read-only HookContext for a seam: the per-run bag (from
        the Conversation) and a copy of the live transcript."""
        run_context: dict[str, Any] = {}
        rc = getattr(self.conversation, "run_context", None)
        if rc is not None:
            try:
                candidate = rc()
                if isinstance(candidate, dict):
                    # Shallow copy: read-only context for hooks. A decider
                    # mutating ctx.run_context must not touch the conversation's
                    # bag or leak into later seams (same posture as messages).
                    run_context = dict(candidate)
            except Exception:
                self._log.exception("run_context_error")

        return HookContext(
            event=event,
            run_context=run_context,
            # Per-dict copy: messages is a read-only transcript for hooks.
            # load_messages() returns fresh list but the SAME dict objects as
            # the executor's in-flight buffer, so a hook mutating one would
            # corrupt what the provider sees next iteration.
            messages=[dict(m) for m in self._executor.load_messages()],
            **fields,
        )

    async def _should_continue(self, iteration: int, tools_used: list[str]) -> bool:
        """Check whether the loop should keep iterating.

        If an ``IterationPolicy`` was provided, delegate to it.
        Otherwise fall back to the hard ``max_iterations`` cap.
        """
        if self._iteration_policy is not None:
            return await self._iteration_policy.should_continue(iteration, tools_used)
        return iteration < self.max_iterations

    async def _build_limit_message(self, iteration: int, tools_used: list[str]) -> str:
        """Build the message shown when the iteration limit is reached.

        If an ``IterationPolicy`` was provided, delegate to it.
        Otherwise return a default message.
        """
        if self._iteration_policy is not None:
            return await self._iteration_policy.on_limit_reached(iteration, tools_used)
        return (
            f"I reached the maximum number of tool call iterations ({self.max_iterations}) "
            "without completing the task. You can try breaking the task into smaller steps."
        )

    async def _run_agent_loop(
        self,
        initial_messages: list[dict[str, object]],
        on_progress: Callable[..., Awaitable[None]] | None = None,
        model: str | None = None,
        *,
        session_id: str | None = None,
    ) -> tuple[str | None, list[str], list[dict[str, object]]]:
        """Run the agent iteration loop. Returns (final_content, tools_used, messages).

        When the Conversation supports ``append`` and ``session_id`` is
        provided, each new assistant message and tool result is flushed
        to disk as it's produced — keeps crash recovery from losing
        mid-turn work, and keeps the in-memory buffer from having to
        be the sole holder of turn state.

        ``session_id`` is keyword-only so test stubs that replace this
        method with a narrower signature continue to work — callers
        inside exoclaw always pass it; external stubs keep their
        existing (initial_messages, on_progress, model) shape.

        Does NOT seed the executor via
        ``set_messages(initial_messages)`` — that would overwrite the
        phase-2b ``PriorSource`` that ``build_prompt`` just installed,
        defeating the RAM reduction. In the production flow
        (``_process_turn_inline`` → ``build_prompt`` → this method)
        the executor is already seeded.

        ``initial_messages`` is retained on the signature for
        backwards compatibility with test shims and any external
        caller that monkey-patches this method, but it is NOT used
        here. Callers that invoke ``_run_agent_loop`` directly
        without going through ``build_prompt`` (typically tests)
        must seed the executor themselves if they care about
        message content reaching the provider.

        See ``docs/memory-model.md`` "Step A" for the history.
        """
        iteration = 0
        final_content = None
        tools_used: list[str] = []
        effective_model = model or self.model
        # Per-turn cap on recovery attempts — prevents an always-True
        # callback / always-Some recover method from looping forever
        # when the same prompt keeps overflowing post-compaction.
        recovery_attempts = 0
        from exoclaw.executor import _supports_append as _has_append

        # Flushing decision is fully a function of what was passed in
        # — no reliance on ``self._current_ctx``, which might be stale
        # from a prior turn or unset on paths that skip _process_message
        # (e.g. system-message dispatch). Flagged by PR #26 review.
        prefer_append = session_id is not None and _has_append(self.conversation)

        async def _flush(msg: dict[str, object]) -> None:
            # ``prefer_append`` implies ``session_id is not None``;
            # the explicit ``is not None`` repeat lets the static type
            # checker narrow ``session_id`` to ``str`` for the call.
            if prefer_append and session_id is not None:
                await self._executor.append_message(self.conversation, session_id, msg)

        while await self._should_continue(iteration, tools_used):
            iteration += 1

            _include = (
                self.conversation.active_tools()
                if hasattr(self.conversation, "active_tools")
                else None
            )
            messages = self._executor.load_messages()
            try:
                response = await self._executor.chat(
                    self.provider,
                    messages=messages,
                    tools=self.tools.get_definitions(include=_include),
                    model=effective_model,
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    reasoning_effort=self.reasoning_effort,
                )
            except ContextWindowExceededError:
                if recovery_attempts >= self._max_recovery_attempts:
                    self._log.error(
                        "context_overflow_recovery_capped",
                        iteration=iteration,
                        attempts=recovery_attempts,
                        cap=self._max_recovery_attempts,
                    )
                    final_content = (
                        "The conversation exceeded the model's context window "
                        "and I couldn't recover. Try starting a new session."
                    )
                    break
                recovery_attempts += 1
                compacted: list[dict[str, object]] | None = None
                if self._on_context_overflow is not None:
                    # Deprecated callback path. Wins for back-compat when set
                    # — existing consumers keep working until they migrate to
                    # ``Conversation.recover_from_overflow``.
                    compacted = await self._on_context_overflow(messages)
                else:
                    # New path: ask the executor (which forwards to the
                    # conversation's optional ``recover_from_overflow``).
                    # Durable executors wrap the forwarded call in a step
                    # for replay safety; pass-through executors just call
                    # the conversation method directly.
                    recover = getattr(self._executor, "recover_from_overflow", None)
                    if recover is not None and session_id is not None:
                        compacted = await recover(self.conversation, session_id)
                if compacted is not None:
                    self._log.info(
                        "context_compact",
                        iteration=iteration,
                        attempt=recovery_attempts,
                    )
                    self._executor.set_messages(compacted)
                    continue
                self._log.error("context_overflow", iteration=iteration)
                final_content = (
                    "The conversation exceeded the model's context window "
                    "and I couldn't recover. Try starting a new session."
                )
                break

            if response.has_tool_calls:
                if on_progress:
                    thought = self._strip_think(response.content)
                    if thought:
                        await on_progress(thought)
                    await on_progress(self._tool_hint(response.tool_calls), tool_hint=True)
                if self._on_tool_calls:
                    await self._executor.run_hook(self._on_tool_calls, response.tool_calls)

                tool_call_dicts = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments),
                        },
                    }
                    for tc in response.tool_calls
                ]
                msg: dict[str, object] = {"role": "assistant", "content": response.content}
                if tool_call_dicts:
                    msg["tool_calls"] = tool_call_dicts
                if response.reasoning_content is not None:
                    msg["reasoning_content"] = response.reasoning_content
                if response.thinking_blocks:
                    msg["thinking_blocks"] = response.thinking_blocks
                self._executor.append_messages([msg])
                await _flush(msg)

                for tool_call in response.tool_calls:
                    tools_used.append(tool_call.name)
                    # ``ensure_ascii`` kwarg dropped: MicroPython 1.27's
                    # ``json.dumps`` doesn't accept it. The non-ASCII
                    # cost is just longer ``\uXXXX``-escaped output.
                    args_str = json.dumps(tool_call.arguments)
                    # `tool_call` + `tool_result` form a start/stop pair
                    # correlated by `tool.call_id`. On error, `.exception()`
                    # attaches the traceback via structlog's format_exc_info.
                    self._log.info(
                        "tool_call",
                        **{
                            "tool.name": tool_call.name,
                            "tool.call_id": tool_call.id,
                        },
                        args=args_str[:200],
                    )
                    t0 = self._monotonic_ms()
                    status = "ok"
                    exc: BaseException | None = None
                    result = ""
                    # When a Step-D-aware tool streamed its result to a
                    # scratch file, ``content_file`` carries the path so
                    # the provider can stream from disk into the LLM
                    # request body. Default ``None`` for tools that
                    # don't opt in (and for the rejection / exception
                    # paths that never call the tool at all).
                    content_file = None
                    try:
                        rejection = None
                        if self._on_pre_tool:
                            sk = self._current_ctx.session_key if self._current_ctx else ""
                            rejection = await self._executor.run_hook(
                                self._on_pre_tool,
                                tool_call.name,
                                tool_call.arguments,
                                sk,
                            )
                        if not rejection:
                            # before_tool decider (via the Conversation) composes
                            # with the global on_pre_tool: it may further mutate
                            # the args or veto the call. The Conversation owns
                            # how any hooks behind it collapse into this result.
                            bt = await self._call_decider(
                                "before_tool",
                                BEFORE_TOOL,
                                tool_name=tool_call.name,
                                # Copy: a decider mutating ctx.params in place
                                # must NOT change the call — only an explicit
                                # BeforeToolResult(params=...) does (applied below).
                                params=dict(tool_call.arguments),
                            )
                            if isinstance(bt, BeforeToolResult):
                                if bt.params is not None:
                                    tool_call.arguments = bt.params
                                if bt.block:
                                    rejection = bt.block_reason or "blocked"
                        if rejection:
                            status = "rejected"
                            self._log.info(
                                "tool_reject",
                                **{
                                    "tool.name": tool_call.name,
                                    "tool.call_id": tool_call.id,
                                },
                                reason=str(rejection)[:100],
                            )
                            result = str(rejection)
                            content_file = None
                        else:
                            result, content_file = await self._invoke_tool(tool_call)
                    except Exception as e:
                        exc = e
                        status = "error"
                        # str(e) can be empty for bare exceptions (e.g. a
                        # no-arg TypeError); fall back to the class name so
                        # the LLM always sees something diagnostic.
                        detail = str(e) or type(e).__name__
                        result = (
                            f"Error executing {tool_call.name}: {detail}"
                            "\n\n[Analyze the error above and try a different approach.]"
                        )
                    finally:
                        duration_ms = monotonic_diff_ms(self._monotonic_ms(), t0)
                        stop_kwargs: dict[str, object] = {
                            "tool.name": tool_call.name,
                            "tool.call_id": tool_call.id,
                            "tool.status": status,
                            "tool.duration_ms": duration_ms,
                        }
                        if exc is not None:
                            # Pass exc_info explicitly — by the time this
                            # finally runs, sys.exc_info() has been cleared
                            # by the except handler, so .exception() would
                            # drop the traceback.
                            self._log.error("tool_result", **stop_kwargs, exc_info=exc)
                        else:
                            self._log.info("tool_result", **stop_kwargs)
                    if self._on_tool_result:
                        await self._executor.run_hook(self._on_tool_result, tool_call, result)
                    tool_msg: dict[str, object] = {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "name": tool_call.name,
                        "content": result,
                    }
                    if content_file is not None:
                        # Provider reads from disk during request-body
                        # assembly. The leading underscore signals
                        # "transport metadata, not part of the LLM
                        # message".
                        tool_msg["_content_file"] = str(content_file)
                    self._executor.append_messages([tool_msg])
                    # Persistence path strips ``_``-prefixed transport
                    # metadata. Otherwise ``_content_file`` would land
                    # in the session JSONL pointing at a temp path
                    # that ``post_turn`` will unlink at end-of-turn —
                    # later reloads would see the key but the file
                    # would already be gone. The in-memory executor
                    # buffer (``append_messages`` above) keeps the
                    # full dict so the provider still has the path
                    # for this turn's outgoing requests.
                    persisted_tool_msg = {
                        k: v for k, v in tool_msg.items() if not k.startswith("_")
                    }
                    await _flush(persisted_tool_msg)
            else:
                clean = self._strip_think(response.content)
                if response.finish_reason == "error":
                    self._log.error("llm_error", **{"error.message": (clean or "")[:200]})
                    final_content = clean or "Sorry, I encountered an error calling the AI model."
                    break
                msg2: dict[str, object] = {"role": "assistant", "content": clean}
                if response.reasoning_content is not None:
                    msg2["reasoning_content"] = response.reasoning_content
                if response.thinking_blocks:
                    msg2["thinking_blocks"] = response.thinking_blocks
                self._executor.append_messages([msg2])
                await _flush(msg2)
                # Before-finish hook: the model stopped (no tool calls). A host
                # may decide the turn isn't really done — e.g. a required
                # closing tool wasn't called — and return a follow-up message to
                # re-drive the loop in place. A non-empty return is appended as a
                # user turn (same path as every other message, so it reaches
                # both the in-memory buffer the provider reads and the durable
                # store) and the loop continues; None/empty ends the turn. The
                # host owns the stopping condition; ``max_iterations`` backstops.
                followup: object = None
                if self._on_before_finish:
                    # Prefer the loop's own ``session_id`` — it's set on every
                    # real path (``_process_turn_inline`` passes it). ``_current_ctx``
                    # is only set by ``_process_message`` and is unset/stale on the
                    # system-message and durable ``run_turn`` paths, so it's the
                    # fallback, not the source of truth.
                    sk = session_id or (self._current_ctx.session_key if self._current_ctx else "")
                    followup = await self._executor.run_hook(
                        self._on_before_finish, clean or "", list(tools_used), sk
                    )
                if not followup:
                    # before_finish decider (via the Conversation) composes with
                    # the global on_before_finish.
                    bf = await self._call_decider(
                        "before_finish",
                        BEFORE_FINISH,
                        final_content=clean or "",
                        tools_used=list(tools_used),
                    )
                    if isinstance(bf, BeforeFinishResult):
                        followup = bf.continue_message
                if followup:
                    nudge: dict[str, object] = {"role": "user", "content": str(followup)}
                    self._executor.append_messages([nudge])
                    await _flush(nudge)
                    self._log.info("turn_continue", reason="before_finish")
                    continue
                final_content = clean
                break

        if final_content is None and not await self._should_continue(iteration, tools_used):
            self._log.warning("iteration_limit", **{"iteration.max": self.max_iterations})
            final_content = await self._build_limit_message(iteration, tools_used)
            if self._on_max_iterations and self._current_ctx:
                ctx = self._current_ctx
                # ``create_isolated_task`` over ``ensure_future`` —
                # MicroPython's frozen ``asyncio`` doesn't ship
                # ``ensure_future``. Same fire-and-forget semantics
                # for the no-await-needed callback case here.
                create_isolated_task(
                    cast(
                        "Coroutine[object, object, None]",
                        self._on_max_iterations(ctx.session_key, ctx.channel, ctx.chat_id),
                    )
                )

        return final_content, tools_used, self._executor.load_messages()

    async def process_turn(
        self,
        session_id: str,
        message: str,
        *,
        channel: str | None = None,
        chat_id: str | None = None,
        media: list[str] | None = None,
        plugin_context: list[str] | None = None,
        on_progress: Callable[..., Awaitable[None]] | None = None,
        model: str | None = None,
        publish_response: bool = False,
        **kwargs: list[str] | None,
    ) -> tuple[str | None, list[dict[str, object]]]:
        """Execute a single turn: build prompt, run agent loop, record.

        If the executor provides a ``run_turn`` method the call is delegated
        to it, allowing durable executors (Temporal, DBOS) to wrap the turn
        in a workflow for crash recovery. Otherwise the turn runs inline.

        ``model`` overrides ``self.model`` for this turn only; falls back to
        the loop default when ``None``.

        Returns ``(final_content, new_messages)``.
        """
        result = await self._executor.run_turn(
            self,
            session_id,
            message,
            channel=channel,
            chat_id=chat_id,
            media=media,
            plugin_context=plugin_context,
            on_progress=on_progress,
            model=model,
            publish_response=publish_response,
            **kwargs,
        )
        if result is not None:
            return result
        return await self._process_turn_inline(
            session_id,
            message,
            channel=channel,
            chat_id=chat_id,
            media=media,
            plugin_context=plugin_context,
            on_progress=on_progress,
            model=model,
            **kwargs,
        )

    async def _process_turn_inline(
        self,
        session_id: str,
        message: str,
        *,
        channel: str | None = None,
        chat_id: str | None = None,
        media: list[str] | None = None,
        plugin_context: list[str] | None = None,
        on_progress: Callable[..., Awaitable[None]] | None = None,
        model: str | None = None,
        **kwargs: list[str] | None,
    ) -> tuple[str | None, list[dict[str, object]]]:
        """The actual turn logic — called directly or from a durable wrapper.

        Binds a per-turn trace context into structlog contextvars so every
        log line emitted during the turn (LLM requests, tool calls, tool
        results, subagent spawns, etc.) carries ``turn.id``,
        ``turn.root_id``, ``turn.parent_id``, ``turn.depth`` and
        ``turn.chain``. That lets a single LogsQL query surface the full
        causal tree of a user message without joins or timestamp
        correlation.

        The fields are read from existing contextvars before binding, so
        nested ``_process_turn_inline`` calls (subagent chains that
        inherit the parent's chain via a workflow argument and re-bind
        before calling ``process_direct``) extend the ancestry correctly.
        """
        turn_id = await self._executor.mint_turn_id()
        ctx = get_log_contextvars()
        parent_chain = cast(str, ctx.get("turn.chain", "") or "")
        parent_id = ctx.get("turn.id")
        root_id = ctx.get("turn.root_id") or turn_id
        chain = f"{parent_chain}:{turn_id}" if parent_chain else turn_id
        depth = parent_chain.count(":") + 1 if parent_chain else 0

        # Save any existing ``turn.*`` values so a nested call can restore
        # the outer turn's context instead of unbinding it entirely —
        # otherwise the outer turn's subsequent logs (including
        # ``turn_end``) would fire with no trace context bound.
        _turn_keys = (
            "turn.id",
            "turn.root_id",
            "turn.parent_id",
            "turn.depth",
            "turn.chain",
        )
        _sentinel = object()
        prior_turn_ctx = {k: ctx.get(k, _sentinel) for k in _turn_keys}

        bind_log_contextvars(
            **{
                "turn.id": turn_id,
                "turn.root_id": root_id,
                "turn.parent_id": parent_id,
                "turn.depth": depth,
                "turn.chain": chain,
            }
        )
        turn_start = self._monotonic_ms()
        self._log.info("turn_start")
        try:
            initial = await self._executor.build_prompt(
                self.conversation,
                session_id,
                message,
                channel=channel,
                chat_id=chat_id,
                media=media,
                plugin_context=plugin_context,
                **kwargs,
            )
            # Per-message persistence path. When the Conversation impl
            # supports ``append``, the loop flushes each message as it's
            # produced (see _run_agent_loop); the final post_turn fires
            # end-of-turn hooks. Falls back to the legacy batched
            # ``record`` call for implementations that don't support
            # append.
            from exoclaw.executor import _supports_append as _has_append

            prefer_append = _has_append(self.conversation)
            if prefer_append:
                # build_prompt returned [prior..., user_message].
                # Persist the new user message before the loop runs so a
                # crash mid-turn still has the user's input on disk.
                if initial:
                    await self._executor.append_message(self.conversation, session_id, initial[-1])
            final_content, _, all_msgs = await self._run_agent_loop(
                initial, on_progress=on_progress, model=model, session_id=session_id
            )
            new_msgs = all_msgs[len(initial) - 1 :]
            if prefer_append:
                await self._executor.post_turn(self.conversation, session_id)
            else:
                await self._executor.record(self.conversation, session_id, new_msgs)
            return final_content, new_msgs
        finally:
            self._log.info(
                "turn_end",
                **{"turn.duration_ms": monotonic_diff_ms(self._monotonic_ms(), turn_start)},
            )
            to_rebind = {k: v for k, v in prior_turn_ctx.items() if v is not _sentinel}
            to_unbind = tuple(k for k, v in prior_turn_ctx.items() if v is _sentinel)
            if to_unbind:
                unbind_log_contextvars(*to_unbind)
            if to_rebind:
                bind_log_contextvars(**to_rebind)

    async def run(self) -> None:
        """Run the agent loop, dispatching messages as tasks to stay responsive to /stop."""
        self._running = True
        self._log.info("agent_loop_start")

        try:
            while self._running:
                try:
                    msg = await asyncio.wait_for(self.bus.consume_inbound(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                if msg.content.strip().lower() == "/stop":
                    await self._handle_stop(msg)
                else:
                    # ``_remove_task`` runs after dispatch finishes —
                    # uses CPython's ``add_done_callback`` when
                    # available (real asyncio.Task) and a finally
                    # wrapper otherwise (uasyncio Task on
                    # MicroPython, which doesn't ship the callback
                    # API). Both paths drain the per-session list
                    # so it doesn't grow unboundedly.
                    session_key = msg.session_key

                    def _remove_task(t: asyncio.Task[None], k: str = session_key) -> None:
                        tasks = self._active_tasks.get(k, [])
                        if t in tasks:
                            tasks.remove(t)

                    add_cb = getattr(asyncio.Task, "add_done_callback", None)
                    if add_cb is not None:  # pragma: no cover (micropython)
                        task = create_isolated_task(self._dispatch(msg))
                        task.add_done_callback(_remove_task)
                    else:  # pragma: no cover (cpython)

                        async def _wrapped(_msg: InboundMessage = msg) -> None:
                            try:
                                await self._dispatch(_msg)
                            finally:
                                cur = asyncio.current_task()
                                if cur is not None:
                                    _remove_task(cast("asyncio.Task[None]", cur))

                        task = create_isolated_task(_wrapped())
                    self._active_tasks.setdefault(session_key, []).append(task)
        finally:
            all_tasks = [t for ts in self._active_tasks.values() for t in ts if not t.done()]
            for t in all_tasks:
                t.cancel()
            if all_tasks:
                await asyncio.gather(*all_tasks, return_exceptions=True)
            self._log.info("agent_loop_stop")

    async def _handle_stop(self, msg: InboundMessage) -> None:
        """Cancel all active tasks and subagents for the session."""
        tasks = self._active_tasks.pop(msg.session_key, [])
        cancelled = sum(1 for t in tasks if not t.done() and t.cancel())
        for t in tasks:
            try:
                await t
            except asyncio.CancelledError:
                pass
            except Exception:
                self._log.exception("task_cancel_error", **{"session.key": msg.session_key})
        sub_cancelled = 0
        for tool in self.tools._tools.values():
            if hasattr(tool, "cancel_by_session"):
                sub_cancelled += await tool.cancel_by_session(msg.session_key)  # type: ignore[call-non-callable]
        total = cancelled + sub_cancelled
        content = f"⏹ Stopped {total} task(s)." if total else "No active task to stop."
        await self.bus.publish_outbound(
            OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content=content,
            )
        )

    async def _dispatch(self, msg: InboundMessage) -> None:
        """Process a message under the global lock."""
        async with self._processing_lock:
            try:
                # Ask ``_process_message`` to let the executor own the
                # publish if it advertises ``handles_response_send``.
                # When it does, we get ``None`` back and skip the publish
                # below; otherwise we publish the returned message as usual.
                response = await self._process_message(msg, publish_response=True)
                if response is not None:
                    await self.bus.publish_outbound(response)
                elif msg.channel == "cli":
                    await self.bus.publish_outbound(
                        OutboundMessage(
                            channel=msg.channel,
                            chat_id=msg.chat_id,
                            content="",
                            metadata=msg.metadata or {},
                        )
                    )
            except asyncio.CancelledError:
                self._log.info("task_cancel", **{"session.key": msg.session_key})
                raise
            except Exception:
                self._log.exception("message_error", **{"session.key": msg.session_key})
                await self.bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        chat_id=msg.chat_id,
                        content="Sorry, I encountered an error.",
                    )
                )

    def stop(self) -> None:
        """Stop the agent loop."""
        self._running = False

    async def _process_message(
        self,
        msg: InboundMessage,
        session_key: str | None = None,
        on_progress: Callable[[str], Awaitable[None]] | None | object = _UNSET,
        model: str | None = None,
        publish_response: bool = False,
        **kwargs: list[str] | None,
    ) -> OutboundMessage | None:
        """Process a single inbound message and return the response.

        ``publish_response`` is forwarded to ``process_turn`` so executors
        that advertise ``handles_response_send`` can take ownership of the
        send. When both flags are True this method returns ``None`` —
        callers read that as "reply already dispatched, nothing more to
        do." Callers that need the reply content back (``process_direct``
        for CLI, subagent chains, cron) pass ``publish_response=False``.
        """
        # System messages: parse origin from chat_id ("channel:chat_id")
        if msg.channel == "system":
            channel, chat_id = (
                msg.chat_id.split(":", 1) if ":" in msg.chat_id else ("cli", msg.chat_id)
            )
            sid = msg.session_key_override or f"{channel}:{chat_id}"
            # Rebind only the session-level fields we own — do NOT
            # clear_contextvars. A caller several frames up may have
            # seeded a ``turn.*`` trace context (e.g.
            # ``SubagentManager._run`` threading parent ancestry into
            # a child ``process_direct`` call) and wiping the whole
            # contextvar store would break cross-spawn trace
            # correlation without anyone noticing — the subagent's
            # ``_process_turn_inline`` would see an empty context and
            # start a fresh root. Rebinding the four keys here is
            # idempotent and leaves other bindings alone.
            bind_log_contextvars(
                **{
                    "session.key": sid,
                    "channel": channel,
                    "chat.id": chat_id,
                    "sender.id": msg.sender_id,
                }
            )
            self._log.info("system_message")
            plugin_ctx = self._collect_plugin_context()
            final_content, _ = await self.process_turn(
                sid,
                msg.content,
                channel=channel,
                chat_id=chat_id,
                plugin_context=plugin_ctx or None,
                model=model or msg.model_override,
                publish_response=publish_response,
            )
            if publish_response and getattr(self._executor, "handles_response_send", False):
                # Executor took ownership of the send — nothing to return.
                return None
            sys_meta = dict(msg.metadata or {})
            sys_meta.setdefault("session_key", sid)
            return OutboundMessage(
                channel=channel,
                chat_id=chat_id,
                content=final_content or "Background task completed.",
                metadata=sys_meta,
            )

        preview = msg.content[:80] + "..." if len(msg.content) > 80 else msg.content
        sid = session_key or msg.session_key

        # Rebind session-level fields only — see the comment above in
        # the system-message branch. Preserving outer ``turn.*``
        # contextvars is what makes subagent trace ancestry survive
        # from ``SubagentManager._run`` into the child's own
        # ``_process_turn_inline``.
        bind_log_contextvars(
            **{
                "session.key": sid,
                "channel": msg.channel,
                "chat.id": msg.chat_id,
                "sender.id": msg.sender_id,
            }
        )

        self._log.info("message_receive", preview=preview)

        # Slash commands
        cmd = msg.content.strip().lower()
        if cmd == "/new":
            success = await self._executor.clear(self.conversation, sid)
            content = (
                "New session started."
                if success
                else ("Memory archival failed, session not cleared. Please try again.")
            )
            return OutboundMessage(channel=msg.channel, chat_id=msg.chat_id, content=content)

        if cmd == "/help":
            return OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content="🦀 exoclaw commands:\n/new — Start a new conversation\n/stop — Stop the current task\n/help — Show available commands",
            )

        self._notify_tools_inbound(msg)
        self._current_ctx = ToolContext(
            session_key=sid,
            channel=msg.channel,
            chat_id=msg.chat_id,
            executor=self._executor,
        )

        plugin_ctx = self._collect_plugin_context()
        if self._on_pre_context:
            extra = await self._executor.run_hook(
                self._on_pre_context, msg.content, sid, msg.channel, msg.chat_id
            )
            if extra:
                plugin_ctx.append(str(extra))

        async def _bus_progress(content: str, *, tool_hint: bool = False) -> None:
            meta = dict(msg.metadata or {})
            meta["_progress"] = True
            meta["_tool_hint"] = tool_hint
            await self.bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=content,
                    metadata=meta,
                )
            )

        # Use _bus_progress only when no on_progress was explicitly provided.
        # An explicit None means "run silently" (e.g. cron jobs via process_direct).
        effective_progress: Callable[..., Awaitable[None]] | None = (
            _bus_progress
            if on_progress is _UNSET
            # ``cast`` evaluates its first arg at runtime — wrap in a
            # string so MicroPython doesn't try to evaluate
            # ``Callable[..., Awaitable[None]] | None`` (which fails
            # with ``unsupported types for __or__: '_Subscriptable',
            # 'NoneType'`` on MP's typing shim).
            else cast("Callable[..., Awaitable[None]] | None", on_progress)
        )

        final_content, new_msgs = await self.process_turn(
            sid,
            msg.content,
            channel=msg.channel,
            chat_id=msg.chat_id,
            media=msg.media if msg.media else None,
            plugin_context=plugin_ctx or None,
            on_progress=effective_progress,
            model=model or msg.model_override,
            publish_response=publish_response,
            **kwargs,
        )

        if final_content is None:
            final_content = "I've completed processing but have no response to give."
        if self._on_post_turn and new_msgs:
            # ``create_isolated_task`` over ``ensure_future`` —
            # MicroPython's frozen ``asyncio`` doesn't ship
            # ``ensure_future``.
            create_isolated_task(
                cast(
                    "Coroutine[object, object, None]",
                    self._on_post_turn(new_msgs, sid, msg.channel, msg.chat_id),
                )
            )

        if publish_response and getattr(self._executor, "handles_response_send", False):
            # Executor took ownership of the send — nothing to return.
            return None

        if any(getattr(t, "sent_in_turn", False) for t in self.tools._tools.values()):
            return None

        preview = final_content[:120] + "..." if len(final_content) > 120 else final_content
        self._log.info("response_send", preview=preview)
        meta = dict(msg.metadata or {})
        meta.setdefault("session_key", sid)
        return OutboundMessage(
            channel=msg.channel,
            chat_id=msg.chat_id,
            content=final_content,
            metadata=meta,
        )

    async def process_direct(
        self,
        content: str,
        session_key: str = "cli:direct",
        channel: str = "cli",
        chat_id: str = "direct",
        on_progress: Callable[[str], Awaitable[None]] | None = None,
        model: str | None = None,
        **kwargs: list[str] | None,
    ) -> str:
        """Process a message directly (for CLI or cron usage).

        ``model`` overrides the loop's default model for this turn only; pass
        ``None`` (the default) to inherit from the loop.

        Extra keyword arguments are forwarded to conversation.build_prompt,
        allowing callers to pass domain-specific context (extra kwargs the
        conversation backend understands) without the loop needing to know
        about them.
        """
        msg = InboundMessage(channel=channel, sender_id="user", chat_id=chat_id, content=content)
        # Callers of ``process_direct`` read the returned content — they
        # don't want the executor to publish on their behalf.
        response = await self._process_message(
            msg,
            session_key=session_key,
            on_progress=on_progress,
            model=model,
            publish_response=False,
            **kwargs,
        )
        return response.content if response else ""
