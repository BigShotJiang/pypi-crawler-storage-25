from .univariate import UnivariateGenerator
