////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  This file is part of NCrystal (see https://mctools.github.io/ncrystal/)   //
//                                                                            //
//  Copyright 2015-2026 NCrystal developers                                   //
//                                                                            //
//  Licensed under the Apache License, Version 2.0 (the "License");           //
//  you may not use this file except in compliance with the License.          //
//  You may obtain a copy of the License at                                   //
//                                                                            //
//      http://www.apache.org/licenses/LICENSE-2.0                            //
//                                                                            //
//  Unless required by applicable law or agreed to in writing, software       //
//  distributed under the License is distributed on an "AS IS" BASIS,         //
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  //
//  See the License for the specific language governing permissions and       //
//  limitations under the License.                                            //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include "NCrystal/internal/utils/NCHists.hh"

namespace NC = NCrystal;


namespace NCRYSTAL_NAMESPACE {
  namespace Hists {
    std::ostream& operator<<( std::ostream& os, const Binning& b )
    {
      os << "Binning(" << b.nbins << " bins from "
         << fmt(b.xmin) << " to " << fmt(b.xmax)<<')';
      return os;
    }
    void Binning::validate() const
    {
      if ( !nbins || nbins > 1000000000 || !std::isfinite(xmin)
           || !std::isfinite(xmax) || !(xmin<xmax) )
        NCRYSTAL_THROW2(BadInput,"Invalid binning : "<<*this);
    }
  }
}
void NC::Hists::RunningStats1D::merge( const RunningStats1D& o )
{
  nc_assert_always( !ncisnan(m_rms_state) );
  nc_assert_always( !ncisnan(o.m_rms_state) );
  if (!o.m_sumw) {
    //other has no data
    return;
  }
  if (!m_sumw) {
    //we don't have data yet, so simply copy over stats:
    m_rms_state = o.m_rms_state;
    m_sumw = o.m_sumw;
    m_sumwx = o.m_sumwx;
    m_minfilled = o.m_minfilled;
    m_maxfilled = o.m_maxfilled;
    return;
  }

  //Both had something, do a proper merge:
#ifdef NCRYSTAL_HIST_ROOT_STYLE_RMS
  m_rms_state += o.m_rms_state;
#else
  const double w1(m_sumw);//s1
  const double w2(o.m_sumw);//s2
  const double wx1(m_sumwx);//b1
  const double wx2(o.m_sumwx);//b2
  nc_assert(w1>0&&w2>0);
  nc_assert( !ncisnan(m_rms_state) );
  nc_assert( !ncisnan(o.m_rms_state) );
  const double sumw12 = w1 + w2;
  const double prodw12 = w1*w2;
  nc_assert(sumw12>0.0);
  const double tmp = w1*w2*sumw12;
  double delta_state;
  static_assert( 1e-300 > 0.0, "" );
  if ( tmp > 1e-280 ) {
    delta_state = ncsquare(w2*wx1-w1*wx2)/tmp;
  } else {
    //Tiny weights, try different formulation:
    delta_state = prodw12*ncsquare( wx1 / w1 - wx2 / w2 )/(w1+w2);
  }
  StableSum sum;
  sum.add( m_rms_state );
  sum.add( o.m_rms_state );
  sum.add( delta_state );
  m_rms_state = sum.sum();
  nc_assert_always( !ncisnan(m_rms_state) );
#endif
  m_sumw += o.m_sumw;
  m_sumwx += o.m_sumwx;
  m_minfilled = std::min<double>(m_minfilled,o.m_minfilled);
  m_maxfilled = std::max<double>(m_maxfilled,o.m_maxfilled);
}


void NC::Hists::RunningStats1D::registerNValues( double val, double N )
{
  if ( !(N>0) )
    return;
  nc_assert(std::isfinite(N));
  update_maxmin(val);
#ifdef NCRYSTAL_HIST_ROOT_STYLE_RMS
  m_rms_state += N * val*val;
#else
  const double d1 = m_sumw * val - m_sumwx;
  const double d2 = m_sumw * ( N + m_sumw );
  nc_assert_always( !ncisnan(m_rms_state) );
  if ( d2 )
    m_rms_state += N * ( d1 * d1  / d2 );
  nc_assert_always( !ncisnan(m_rms_state) );
#endif
  m_sumw += N;
  m_sumwx += N * val;
}

void NC::Hists::RunningStats1D::toJSON( std::ostream& os ) const
{
  streamJSONDictEntry(os, "integral", m_sumw,JSONDictPos::FIRST);
  if ( hasData() ) {
    streamJSONDictEntry(os, "rms", calcRMS() );
    streamJSONDictEntry(os, "mean", calcMean() );
    streamJSONDictEntry(os, "minfilled", m_minfilled );
    streamJSONDictEntry(os, "maxfilled", m_maxfilled , JSONDictPos::LAST);
  } else {
    auto none = json_null_t{};
    streamJSONDictEntry(os, "rms", none );
    streamJSONDictEntry(os, "mean", none );
    streamJSONDictEntry(os, "minfilled", none );
    streamJSONDictEntry(os, "maxfilled", none, JSONDictPos::LAST);
  }
}

double NC::Hists::RunningStats1D::calcRMSSq() const
{
  if (!hasData())
    NCRYSTAL_THROW(CalcError,"RMS not well defined in empty histograms");
  nc_assert( m_sumw > 0.0 );
  nc_assert_always( !ncisnan(m_rms_state) );
#ifdef NCRYSTAL_HIST_ROOT_STYLE_RMS
  //Unstable calculation:
  const double rms2 = m_rms_state / m_sumw - (m_sumwx*m_sumwx)/(m_sumw*m_sumw);
#else
  const double rms2 = m_rms_state / m_sumw;
#endif
  nc_assert_always( !ncisnan(rms2) );
  nc_assert_always( std::isfinite(rms2) && rms2 >= 0.0 );
  return rms2;
}
