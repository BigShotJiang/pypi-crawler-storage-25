////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  This file is part of NCrystal (see https://mctools.github.io/ncrystal/)   //
//                                                                            //
//  Copyright 2015-2026 NCrystal developers                                   //
//                                                                            //
//  Licensed under the Apache License, Version 2.0 (the "License");           //
//  you may not use this file except in compliance with the License.          //
//  You may obtain a copy of the License at                                   //
//                                                                            //
//      http://www.apache.org/licenses/LICENSE-2.0                            //
//                                                                            //
//  Unless required by applicable law or agreed to in writing, software       //
//  distributed under the License is distributed on an "AS IS" BASIS,         //
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  //
//  See the License for the specific language governing permissions and       //
//  limitations under the License.                                            //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include "NCrystal/internal/minimc/NCMMC_SimEngine.hh"
#include "NCrystal/internal/utils/NCRandUtils.hh"
#include "NCrystal/internal/extd_utils/NCABIUtils.hh"
#include "NCrystal/internal/minimc/NCMMC_Utils.hh"
#include "NCMMC_BasketUtils.hh"
#ifndef NCRYSTAL_DISABLE_THREADS
#  ifdef NCRYSTAL_DEBUGMMCMSG_ENABLED
#    include <thread>
#  endif
#endif
//Uncomment to work with mmcvis script:
//#define NCMMC_PRINTSTEPS
#ifdef NCMMC_PRINTSTEPS
#  include "NCrystal/internal/utils/NCString.hh"
#endif

namespace NC = NCrystal;
namespace NCMMC = NCrystal::MiniMC;

namespace NCRYSTAL_NAMESPACE {
  namespace MiniMC {
    namespace {
#ifdef NCMMC_PRINTSTEPS
      void printsteps( const char * state, const Basket& bb ) {
        nc_assert_always( bb.neutrons && bb.nscat && bb.nscat_inelas );
        const auto& b = *(bb.neutrons);
        const auto& bf = b.fields;;
        for ( auto i : ncrange( b.size() ) ) {
          std::ostringstream ss;
          streamJSONDictEntry(ss,"step_state",state,JSONDictPos::FIRST);
          streamJSONDictEntry(ss,"x",bf.x[i]);
          streamJSONDictEntry(ss,"y",bf.y[i]);
          streamJSONDictEntry(ss,"z",bf.z[i]);
          streamJSONDictEntry(ss,"ux",bf.ux[i]);
          streamJSONDictEntry(ss,"uy",bf.uy[i]);
          streamJSONDictEntry(ss,"uz",bf.uz[i]);
          streamJSONDictEntry(ss,"ekin",bf.ekin[i]);
          streamJSONDictEntry(ss,"w",bf.w[i]);
          streamJSONDictEntry(ss,"nscat",bb.nscat->data[i]);
          streamJSONDictEntry(ss,"nscat_inelas",bb.nscat_inelas->data[i],
                              JSONDictPos::LAST);
          NCRYSTAL_MSG("NCMMCPRINTSTEP:: "<<ss.str());
        }
      }
#endif

      class StdSimEngine final : public SimEngine {
        //The input:
        EngineOpts m_opt;
        GeometryPtr m_geom;
        shared_obj<BasketMgr> m_bmgr;
        MatDef m_mat;

        //Derived values and caches:
        double m_opt_roulette_survivor_boost;
        CachePtr m_sct_cacheptr;
        CachePtr m_abs_cacheptr;

        //We need a few buffers (careful with memory usage, but better here on
        //the heap than on the stack):
        BasketValBufDbl m_buf_disttoexit;
        BasketValBufDbl m_buf_xs_abs;
        BasketValBufDbl m_buf_ptransm;
        BasketValBufDbl m_buf_disttoscat;
        Basket m_basket_buffer;

        Basket allocateBasket() {
          if ( m_basket_buffer.valid() ) {
            m_basket_buffer.neutrons->nused = 0;
            return std::move(m_basket_buffer);
          } else {
            return m_bmgr->allocateBasket();
          }
        }
        void deallocateBasket( Basket&& b ) {
          if ( !b.valid() )
            return;
          if ( m_basket_buffer.valid() ) {
            m_bmgr->deallocateBasket( std::move(b) );
          } else {
            m_basket_buffer = std::move(b);
          }
        }

        static void checkBasketFields( const Basket& b )
        {
          if ( ! ( b.buf1 && b.nscat && b.nscat_inelas ) )
            NCRYSTAL_THROW(LogicError,"StdSimEngine requires a basket with"
                           " nscat, nscat_inelas, and buf1 available.");
        }

      public:

        ~StdSimEngine()
        {
          if ( m_basket_buffer.valid() ) {
            try {
              m_bmgr->deallocateBasket( std::move(m_basket_buffer) );
            } catch(...) {
              printf("NCrystal ERROR: Unexpected exception in ~StdSimEngine\n");
            }
          }
        }

        shared_obj<SimEngine> clone() const override
        {
          return makeSO<StdSimEngine>( m_opt, m_geom, m_bmgr, m_mat );
        }

        StdSimEngine( const EngineOpts& eopts,
                      GeometryPtr geom,
                      shared_obj<BasketMgr> bmgr,
                      MatDef mat )
          : m_opt( eopts ),
            m_geom( std::move(geom) ),
            m_bmgr( std::move(bmgr) ),
            m_mat( std::move(mat) )
        {
          if ( ! ( m_opt.roulette.survival_probability > 1e-20 ) )
            NCRYSTAL_THROW(BadInput,"roulette_survival_probability must be >1e-20");
          if ( ! ( m_opt.roulette.survival_probability < 1.0 ) )
            NCRYSTAL_THROW(BadInput,"roulette_survival_probability must be <1.0");
          if ( ! ( m_opt.roulette.weight_threshold > 0.0 ) )
            NCRYSTAL_THROW(BadInput,"roulette_weight_threshold must be >0.0");
          m_opt_roulette_survivor_boost
            = 1.0 / m_opt.roulette.survival_probability;
          nc_assert_always( m_opt.nScatLimit.value_or(0)
                            <= (std::numeric_limits<int>::max()-1) );
        }

        void step( Basket inbasket, RNG& rng,
                   const TallyFct& tallyfct ) override
        {
          //In this engine, each step produce 1 basket for tallying and 1
          //pending basket for further processing in a new step. In case the
          //pending basket does not need filling, we immediately process it
          //again, thus reducing the need to communicate with the global
          //thread-safe queue in the mgr.
          do {
            inbasket = processBasket( std::move(inbasket), rng, tallyfct );
          } while ( inbasket.valid()
                    && inbasket.size() >= basket_N_almost_Full );
          if ( inbasket.valid() ) {
            //transfer to global queue:
            m_bmgr->addPendingBasket( std::move(inbasket) );
          }
        }

      private:
        Basket processBasket( Basket inbasket,
                              RNG& rng,
                              const TallyFct& tallyfct )
        {
          NCRYSTAL_DEBUGMMCMSG("Thread "<<std::this_thread::get_id()
                               <<" StdSimEngine::processBasket inbasket.size()="
                               <<inbasket.size());

          const double macroxsfactor = Utils::macroXSFactor( m_mat.numDens );

          Basket result_basket;
          nc_assert(!result_basket.valid());

          checkBasketFields( inbasket );

          const int nscatlimit = ( m_opt.nScatLimit.has_value()
                                   ? static_cast<int>(m_opt.nScatLimit.value() )
                                   : -1 );
          nc_assert( tallyfct != nullptr );
          nc_assert( inbasket.valid() );
          nc_assert( !inbasket.empty() );
          const bool has_scat = ( macroxsfactor>0.0
                                  && m_mat.scatter != nullptr
                                  && !m_mat.scatter->isNull() );
          const bool has_abs = ( macroxsfactor>0.0
                                 && m_mat.absorption != nullptr
                                 && !m_mat.absorption->isNull() );
          const bool scatter_is_isotropic = !(has_scat&&m_mat.scatter->isOriented());
          const bool absorption_is_isotropic = !(has_abs&&m_mat.absorption->isOriented());
          const bool geom_is_unbounded = m_geom->hasUnboundedDistToVolExit();

#ifdef NCMMC_PRINTSTEPS
          printsteps("stepinput",inbasket);
#endif

          //Get distances out for all the particles (note, if geom_is_unbounded,
          //this might include infinities):
          m_geom->distToVolumeExit( *inbasket.neutrons, m_buf_disttoexit );

          //Get absorption cross sections:
          const double * values_abs_xs_or_nullptr = nullptr;
          if ( has_abs ) {
            if ( absorption_is_isotropic ) {
              ProcImpl::NewABI::evalManyXSIsotropic( *m_mat.absorption,
                                                     m_abs_cacheptr,
                                                     inbasket.neutrons->fields.ekin.data,
                                                     inbasket.size(),
                                                     m_buf_xs_abs.data );
            } else {
              for ( auto i : ncrange( inbasket.size() ) ) {
                m_buf_xs_abs.data[i]
                  = m_mat.absorption->crossSection( m_abs_cacheptr,
                                                    BasketUtils::ekin_obj(*inbasket.neutrons,i),
                                                    BasketUtils::dir_obj(*inbasket.neutrons,i) ).dbl();
              }
            }
            for ( auto i : ncrange( inbasket.size() ) )
              m_buf_xs_abs.data[i] *= macroxsfactor;
            values_abs_xs_or_nullptr = &m_buf_xs_abs.data[0];
          }

          if (!has_scat) {
            //Special case of no scattering, just transmit (in-place) and return
            //an empty basket (i.e. nothing needs further processing):
            MiniMC::Utils::propagateAndAttenuate( *inbasket.neutrons,
                                                  geom_is_unbounded,
                                                  m_buf_disttoexit.data,
                                                  values_abs_xs_or_nullptr );

#ifdef NCMMC_PRINTSTEPS
            printsteps("tally",inbasket);
#endif
            tallyfct( inbasket );
            deallocateBasket( std::move(inbasket) );
            return result_basket;
          }

          //Get scattering cross sections (potentially with cached
          //values). Also, if nscatlimit is enabled, anything already scattered
          //nscatlimit times will get a phony scattering cross section value of
          //0:

          auto buf_scatxsval = [](const Basket&b)
            -> BasketValBufDbl::data_t&
          {
            nc_assert(b.buf1!=nullptr);
            return b.buf1->data;
          };

          if ( nscatlimit == 0 ) {
            //special case, completely disable scattering.
            for ( auto i : ncrange( inbasket.size() ) )
              buf_scatxsval(inbasket)[i] = 0.0;
          } else {
            if ( scatter_is_isotropic ) {
              if ( nscatlimit>=0 ) {
                for ( auto i : ncrange( inbasket.size() ) )
                  if ( inbasket.nscat->data[i] >= nscatlimit )
                    buf_scatxsval(inbasket)[i] = 0.0;
              }
              for ( auto i : ncrange(nscatlimit==0?0:inbasket.size()) ) {
                if ( inbasket.nscat->data[i] <= 0
                     || buf_scatxsval(inbasket)[i] < 0.0 )
                  buf_scatxsval(inbasket)[i]
                    = ( macroxsfactor * m_mat.scatter->crossSectionIsotropic
                        ( m_sct_cacheptr,
                          BasketUtils::ekin_obj(*inbasket.neutrons,i) ).dbl() );
              }
            } else {
              //not isotropic, always recalculate all xs values (except if
              //nscatlimit is exceeded of course):
              for ( auto i : ncrange( inbasket.size() ) ) {
                if ( nscatlimit >= 0 && inbasket.nscat->data[i] >= nscatlimit )
                  buf_scatxsval(inbasket)[i] = 0.0;
                else
                  buf_scatxsval(inbasket)[i]
                    = ( macroxsfactor * m_mat.scatter->crossSection
                        ( m_sct_cacheptr,
                          BasketUtils::ekin_obj(*inbasket.neutrons,i),
                          BasketUtils::dir_obj(*inbasket.neutrons,i) ).dbl() );
              }
            }
          }

          //Transmission probability (note, as a special case this will be set
          //to 0 if disttoexit=inf):
          MiniMC::Utils::calcProbTransm( inbasket.size(),
                                         geom_is_unbounded,
                                         buf_scatxsval(inbasket),
                                         m_buf_disttoexit.data,
                                         m_buf_ptransm.data );

          //Pick scattering points (note gives dist=inf if xs=0):
          MiniMC::Utils::sampleRandDists(rng,
                                         m_buf_disttoexit.data,
                                         buf_scatxsval(inbasket),
                                         inbasket.size(),
                                         m_buf_disttoscat.data );

          {
            //Add a pending basket with scattered particles for further
            //simulations. We also implement a russian roulette particle-killing
            //scheme (otherwise the simulations would never terminate with our
            //forced-collision scheme).
            //
            //We also skip any particle with weight=0 or vanishing scattering
            //cross section.

            Basket outb = allocateBasket();
            if ( outb.valid() )
              outb.neutrons->nused = 0;
            else
              outb = allocateBasket();
            nc_assert( outb.valid() && outb.empty() );
            checkBasketFields( outb );
            auto& inb = inbasket;
            nc_assert( m_opt.roulette.survival_probability < 1.0 );

            for ( auto i : ncrange( inb.size() ) ) {
              if ( inb.neutrons->fields.w[i]==0.0 )
                continue;//no actual flux here, killed!

              if ( std::isinf(m_buf_disttoscat[i] ) ) {
                //this comes from no scattering cross section
                nc_assert( buf_scatxsval(inbasket)[i] < 1e-20 );
                continue;
              }

              const double macro_scat_xs = buf_scatxsval(inbasket)[i];

              if (!(macro_scat_xs > 0.0))
                continue;//can't scatter (all relevant weight should have been
                         //delivered already).

              //to the tally already via ptransm).
              //Implement russian-roulette:
              double roulette_weight_factor = 1.0;
              double roulette
                = ( ( inb.nscat->data[i] >= m_opt.roulette.nscat_threshold
                      && inb.neutrons->fields.w[i]
                      < m_opt.roulette.weight_threshold )
                    ? m_opt.roulette.survival_probability
                    : 1.0 );
              if ( roulette < 1.0 ) {
                if ( rng.generate() > roulette ) {
                  continue;//killed!
                } else {
                  nc_assert( m_opt.roulette.survival_probability > 0.0 );
                  nc_assert( m_opt.roulette.survival_probability <= 1.0 );
                  roulette_weight_factor = m_opt_roulette_survivor_boost;
                }
              }

              //Get macroscopic scattering cross section:
              const double macro_abs_xs = ( values_abs_xs_or_nullptr
                                            ? values_abs_xs_or_nullptr[i]
                                            : 0.0 );

              nc_assert( !NC::ncisinf(m_buf_disttoscat[i]));//dealt with above
              const double weight_reduction_factor
                = std::exp( -macro_abs_xs * m_buf_disttoscat[i] );

              if (!(weight_reduction_factor>0.0))
                continue;//did not survive to scatter point, kill!

              //We are now in the "standard" situation:
              //  macro_scat_xs > 0.0
              //  weight_reduction_factor > 0.0
              //  disttoscat < infinity
              //
              //So we process this particle further, i.e. copy it to the pending
              //basket and update the weight (and then scatter it below):
              nc_assert( outb.size() < basket_N );
              std::size_t j = outb.append1( inbasket, i );
              auto& outb_fields = outb.neutrons->fields;
              outb_fields.w.data[j] *= roulette_weight_factor;

              //Move to scattering point and attenuate. Note that we dealt with
              //disttoscat=inf above, so can use a simple propagation:
              nc_assert(!NC::ncisinf( m_buf_disttoscat[i]));//dealt with above
              outb_fields.x.data[j] += m_buf_disttoscat[i] * outb_fields.ux[j];
              outb_fields.y.data[j] += m_buf_disttoscat[i] * outb_fields.uy[j];
              outb_fields.z.data[j] += m_buf_disttoscat[i] * outb_fields.uz[j];
              outb_fields.w.data[j] *= weight_reduction_factor;

              //Scatter:
              nc_assert( has_scat );
              auto outcome = m_mat.scatter
                ->sampleScatter( m_sct_cacheptr,
                                 rng,
                                 BasketUtils::ekin_obj(*outb.neutrons,j),
                                 BasketUtils::dir_obj(*outb.neutrons,j));
              nc_assert( ncabs(outcome.direction.as<Vector>().mag()-1.0) < 1e-9 );
              outb_fields.ux.data[j] = outcome.direction[0];
              outb_fields.uy.data[j] = outcome.direction[1];
              outb_fields.uz.data[j] = outcome.direction[2];
              const bool was_elastic
                = (outb_fields.ekin[j] == outcome.ekin.dbl());
              outb_fields.ekin.data[j] = outcome.ekin.dbl();
              ++( outb.nscat->data[j] );
              if ( !was_elastic ) {
                ++( outb.nscat_inelas->data[j] );
                buf_scatxsval(outb)[j] = -1.0;//xs might have changed
              }

              //Fix weights for the forced collision. Note that when
              //disttoexit=inf, we have ptransm=0 (to avoid anything transmitted
              //cropping up in the tallies), so it is right that the final
              //factor is (1-ptransm)=1. Nothing made it to the tally, we kept
              //all for the scattering. In case scattering XS was also 0, that
              //particle was simply lost
              outb_fields.w.data[j] *= ( 1.0 - m_buf_ptransm[i] );
            }

            result_basket = std::move(outb);
          }

          {
            //Add a result basket with directly transmitted particles. For
            //efficiency, we simply reuse the input basket (in case of infinite
            //disttoexit we end up with w=0, but these will be ignored later):
            auto& outb = inbasket;
            MiniMC::Utils::propagateAndAttenuate( *outb.neutrons,
                                                  geom_is_unbounded,
                                                  m_buf_disttoexit.data,
                                                  values_abs_xs_or_nullptr );
            //We also reduce with the transmission probability
            //(i.e. scatter-process attenuation, the above propagateAndAttenuate
            //only took care of the absorption-process attenuation:
            for ( auto i : ncrange(outb.size()) )
              outb.neutrons->fields.w.data[i] *= m_buf_ptransm[i];

#ifdef NCMMC_PRINTSTEPS
            printsteps("tally",outb);
#endif
            tallyfct( outb );
            deallocateBasket( std::move(inbasket) );
          }

          return result_basket;
        }
      };
    }
  }
}

NC::shared_obj<NCMMC::SimEngine>
NCMMC::createStdSimEngine( GeometryPtr geom,
                           MatDef mat,
                           shared_obj<BasketMgr> bmgr,
                           const EngineOpts& opts )
{
  return makeSO<StdSimEngine>( opts, std::move(geom), std::move(bmgr), std::move(mat) );
}
