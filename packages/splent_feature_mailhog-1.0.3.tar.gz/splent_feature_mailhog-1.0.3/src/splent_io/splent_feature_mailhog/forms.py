# Mailhog has no forms.
