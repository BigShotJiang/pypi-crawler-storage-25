# Mailhog emits no signals.
