"""
Jidar Test Server

A simple FastAPI server that uses the Jidar SDK for security middleware.
Run this to test the SDK integration with your Jidar backend.

Usage:
    1. Install FastAPI: pip install fastapi uvicorn
    2. Run: python test_server.py
    3. Test with curl (see below)

API Key: argos_env_abe8c6e7542cf37b156cbca333c1d190f11bedd031e567aa0bbf091718d0526c
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import uvicorn

# Import Jidar SDK
from argos import create_client
from argos.middleware.fastapi import FastAPIMiddleware
from argos.middleware.base import MiddlewareConfig

# Configuration
JIDAR_API_KEY = "argos_env_abe8c6e7542cf37b156cbca333c1d190f11bedd031e567aa0bbf091718d0526c"
JIDAR_BASE_URL = "http://api.argossecops.com"

# Create Jidar client
argos_client = create_client(
    api_key=JIDAR_API_KEY,
    base_url=JIDAR_BASE_URL,
    max_retries=3,
    retry_jitter=True,
)

# Create FastAPI app
app = FastAPI(title="Jidar Test Server", version="1.0.0")

# Add Jidar middleware with blocklist checking
app.add_middleware(
    FastAPIMiddleware,
    client=argos_client,
    config=MiddlewareConfig(mode="sync", exclude_paths=["/health", "/", "/docs", "/openapi.json"]),
)


# Routes
@app.get("/")
async def root():
    return {"message": "Jidar Test Server is running!", "version": "1.0.0"}


@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "ok"}


@app.get("/test")
async def test_endpoint():
    """Test endpoint that should be allowed"""
    return {"message": "Success!", "data": {"test": "value"}}


@app.post("/login")
async def login(request: Request):
    """Login endpoint - tests policy blocking"""
    body = await request.json()

    return {"message": "Login attempted", "user": body.get("username", "unknown")}


@app.post("/payment")
async def payment(request: Request):
    """Payment endpoint - tests anomaly detection"""
    body = await request.json()

    return {"message": "Payment processed", "amount": body.get("amount", 0)}


@app.get("/admin")
async def admin():
    """Admin endpoint - tests high security"""
    return {"message": "Admin panel"}


@app.get("/argos-status")
async def argos_status():
    """Check Jidar connection status"""
    try:
        health = argos_client.health_check()

        # Test ingestion
        test_event = argos_client.ingest(
            payload={"event_type": "test", "status": "success"},
            metadata={"source": "health-check", "externalID": "health-check-test"},
        )

        # Get decision
        decision = argos_client.get_decision(test_event.id)

        return {
            "status": "connected",
            "backend_health": health,
            "test_event": {
                "id": test_event.id,
                "decision": decision.verdict,
                "reason": decision.reason,
            },
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


if __name__ == "__main__":
    print("=" * 60)
    print("Jidar Test Server")
    print("=" * 60)
    print(f"Jidar API: {JIDAR_BASE_URL}")
    print(f"API Key: {JIDAR_API_KEY[:20]}...")
    print()
    print("Server starting on http://localhost:8000")
    print()
    print("Test endpoints:")
    print("  curl http://localhost:8000/")
    print("  curl http://localhost:8000/test")
    print('  curl http://localhost:8000/login -X POST -d \'{"username":"test"}\'')
    print("  curl http://localhost:8000/argos-status")
    print()
    print("=" * 60)

    uvicorn.run(app, host="0.0.0.0", port=8000)
