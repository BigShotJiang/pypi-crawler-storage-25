"""HTTP transport layer for Argos API."""

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from urllib.parse import urljoin


logger = logging.getLogger("argos.transport")


@dataclass
class TransportConfig:
    """Configuration for HTTP transport."""

    base_url: str = "https://api.argossecops.com"
    timeout: float = 30.0
    headers: dict = field(default_factory=dict)


class TransportError(Exception):
    """Base transport error."""
    pass


class TransportResponse:
    """Wrapper for HTTP response."""

    def __init__(self, status_code: int, body: str, headers: dict):
        self.status_code = status_code
        self.body = body
        self.headers = headers
        self._json: Optional[dict] = None

    def json(self) -> dict:
        if self._json is None and self.body:
            self._json = json.loads(self.body)
        return self._json or {}


class HTTPTransport:
    """HTTP transport using urllib."""

    def __init__(self, config: TransportConfig):
        self.config = config

    def request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> TransportResponse:
        """Make HTTP request."""
        url = urljoin(self.config.base_url, endpoint)
        if params:
            query_string = "&".join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{query_string}"

        data = json.dumps(json_data).encode("utf-8") if json_data else None

        request = Request(
            url,
            data=data,
            headers=self.config.headers,
            method=method,
        )

        with urlopen(request, timeout=self.config.timeout) as response:
            response_body = response.read().decode("utf-8")
            return TransportResponse(
                status_code=response.status,
                body=response_body,
                headers=dict(response.headers),
            )

    def get(self, endpoint: str, params: Optional[dict] = None) -> TransportResponse:
        """GET request."""
        return self.request("GET", endpoint, params=params)

    def post(
        self,
        endpoint: str,
        json_data: Optional[dict] = None,
    ) -> TransportResponse:
        """POST request."""
        return self.request("POST", endpoint, json_data=json_data)

    def delete(self, endpoint: str) -> TransportResponse:
        """DELETE request."""
        return self.request("DELETE", endpoint)