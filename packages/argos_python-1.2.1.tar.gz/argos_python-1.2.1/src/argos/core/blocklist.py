import logging
import time
from dataclasses import dataclass
from threading import Lock
from typing import Optional, Dict, Tuple

from ..models import BlocklistEntry


logger = logging.getLogger("argos.blocklist")


class BlocklistManager:
    """Manager for blocklist operations."""

    def __init__(self, request_fn, cache_ttl: float = 60.0):
        """
        Initialize with a request function.
        
        Args:
            request_fn: Function that makes HTTP requests (e.g., client._request)
            cache_ttl: Time-to-live for cached results in seconds
        """
        self._request = request_fn
        self._cache_ttl = cache_ttl
        self._ip_cache: Dict[str, Tuple[bool, str, float]] = {}
        self._user_cache: Dict[str, Tuple[bool, str, float]] = {}
        self._entry_to_value: Dict[str, Tuple[str, str]] = {}
        self._lock = Lock()

    def is_blocked(self, ip: str) -> tuple[bool, str]:
        """Check if an IP is blocked."""
        with self._lock:
            if ip in self._ip_cache:
                blocked, reason, timestamp = self._ip_cache[ip]
                if time.time() - timestamp < self._cache_ttl:
                    return blocked, reason
        
        response = self._request("GET", "/api/v1/admin/blocklist/ip/check", params={"ip": ip})
        result = response.get("blocked", False), response.get("reason", "")
        
        with self._lock:
            self._ip_cache[ip] = (*result, time.time())
            
        return result

    def is_user_blocked(self, user_id: str) -> tuple[bool, str]:
        """Check if a user is blocked."""
        with self._lock:
            if user_id in self._user_cache:
                blocked, reason, timestamp = self._user_cache[user_id]
                if time.time() - timestamp < self._cache_ttl:
                    return blocked, reason

        response = self._request(
            "GET", "/api/v1/admin/blocklist/user/check", params={"user_id": user_id}
        )
        result = response.get("blocked", False), response.get("reason", "")
        
        with self._lock:
            self._user_cache[user_id] = (*result, time.time())
            
        return result

    def get_all(self) -> list[BlocklistEntry]:
        """Get all blocklist entries."""
        response = self._request("GET", "/api/v1/admin/blocklist")
        entries = []
        if isinstance(response, list):
            for item in response:
                if isinstance(item, dict):
                    entries.append(
                        BlocklistEntry(
                            id=item.get("id"),
                            type=item.get("type"),
                            value=item.get("value"),
                            reason=item.get("reason", ""),
                            blocked_at=item.get("blocked_at", ""),
                            expires_at=item.get("expires_at"),
                            environment_id=item.get("environment_id", ""),
                        )
                    )
        return entries

    def block_ip(self, ip: str, environment_id: str, reason: str = "") -> BlocklistEntry:
        """Block an IP address."""
        data = {
            "type": "ip",
            "value": ip,
            "environment_id": environment_id,
        }
        if reason:
            data["reason"] = reason

        response = self._request("POST", "/api/v1/admin/blocklist", json_data=data)
        entry = BlocklistEntry(
            id=response.get("id"),
            type=response.get("type"),
            value=response.get("value"),
            reason=response.get("reason", ""),
            blocked_at=response.get("blocked_at", ""),
            expires_at=response.get("expires_at"),
            environment_id=response.get("environment_id", ""),
        )
        
        # Update cache
        with self._lock:
            self._ip_cache[ip] = (True, reason, time.time())
            if entry.id:
                self._entry_to_value[entry.id] = ("ip", ip)
            
        return entry

    def block_user(self, user_id: str, environment_id: str, reason: str = "") -> BlocklistEntry:
        """Block a user."""
        data = {
            "type": "user",
            "value": user_id,
            "environment_id": environment_id,
        }
        if reason:
            data["reason"] = reason

        response = self._request("POST", "/api/v1/admin/blocklist", json_data=data)
        entry = BlocklistEntry(
            id=response.get("id"),
            type=response.get("type"),
            value=response.get("value"),
            reason=response.get("reason", ""),
            blocked_at=response.get("blocked_at", ""),
            expires_at=response.get("expires_at"),
            environment_id=response.get("environment_id", ""),
        )
        
        # Update cache
        with self._lock:
            self._user_cache[user_id] = (True, reason, time.time())
            if entry.id:
                self._entry_to_value[entry.id] = ("user", user_id)
            
        return entry

    def unblock(self, entry_id: str) -> None:
        """Remove an entry from the blocklist."""
        with self._lock:
            if entry_id in self._entry_to_value:
                type_val, value = self._entry_to_value[entry_id]
                if type_val == "ip":
                    self._ip_cache.pop(value, None)
                else:
                    self._user_cache.pop(value, None)
                self._entry_to_value.pop(entry_id)
            else:
                # If we don't know the entry, clear everything to be safe
                self._ip_cache.clear()
                self._user_cache.clear()
            
        self._request("DELETE", f"/api/v1/admin/blocklist/{entry_id}")