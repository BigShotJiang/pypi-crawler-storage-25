"""Circuit breaker implementation for resilient operations."""

import logging
import time
from dataclasses import dataclass, field
from threading import Lock
from typing import Optional


logger = logging.getLogger("argos.circuit")


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker behavior."""

    threshold: int = 5
    timeout: float = 60.0


class CircuitOpenError(Exception):
    """Raised when the circuit breaker is open."""
    pass


@dataclass
class CircuitBreaker:
    """
    Circuit breaker for preventing cascade failures.
    
    Monitors failures and opens the circuit after threshold is reached.
    Automatically attempts recovery after timeout.
    """

    config: CircuitBreakerConfig = field(default_factory=CircuitBreakerConfig)
    _failure_count: int = field(default=0, repr=False)
    _last_failure_time: Optional[float] = field(default=None, repr=False)
    _circuit_open: bool = field(default=False, repr=False)
    _lock: Lock = field(default_factory=Lock, repr=False)

    def is_open(self) -> bool:
        """Check if circuit breaker is open."""
        if not self._circuit_open:
            return False

        if self._last_failure_time:
            elapsed = time.time() - self._last_failure_time
            if elapsed > self.config.timeout:
                logger.info("Circuit breaker: attempting reset")
                self._circuit_open = False
                self._failure_count = 0
                return False

        return True

    def record_success(self) -> None:
        """Record a success - reset failure count."""
        with self._lock:
            self._failure_count = 0
            self._circuit_open = False

    def record_failure(self) -> None:
        """Record a failure - increment count and open circuit if threshold reached."""
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()

            if self._failure_count >= self.config.threshold:
                self._circuit_open = True
                logger.warning(f"Circuit breaker opened after {self._failure_count} failures")