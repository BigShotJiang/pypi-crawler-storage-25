"""Retry strategy module for resilient HTTP operations."""

import random
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class RetryStrategy(str, Enum):
    """Retry strategy for failed requests."""

    NONE = "none"
    EXPONENTIAL = "exponential"
    LINEAR = "linear"


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""

    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL
    base_delay: float = 0.5
    max_delay: float = 30.0
    jitter: bool = True
    max_retries: int = 3


class RetryCalculator:
    """Calculate delays for retry attempts."""

    def __init__(self, config: RetryConfig):
        self.config = config

    def calculate_delay(self, attempt: int) -> float:
        """Calculate retry delay with backoff and optional jitter."""
        if self.config.strategy == RetryStrategy.LINEAR:
            delay = self.config.base_delay * attempt
        elif self.config.strategy == RetryStrategy.EXPONENTIAL:
            delay = self.config.base_delay * (2 ** (attempt - 1))
        else:
            delay = self.config.base_delay

        delay = min(delay, self.config.max_delay)

        if self.config.jitter:
            delay = delay * (0.5 + random.random() * 0.5)

        return delay


def calculate_delay(
    attempt: int,
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL,
    base_delay: float = 0.5,
    max_delay: float = 30.0,
    jitter: bool = True,
) -> float:
    """Convenience function for calculating retry delay."""
    calc = RetryCalculator(
        RetryConfig(
            strategy=strategy,
            base_delay=base_delay,
            max_delay=max_delay,
            jitter=jitter,
        )
    )
    return calc.calculate_delay(attempt)