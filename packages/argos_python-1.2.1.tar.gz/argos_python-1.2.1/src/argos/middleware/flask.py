"""Argos SDK - Flask Middleware"""

import logging
from typing import Any, Optional

from .base import MiddlewareConfig
from ..client import ArgosClient
from ..utils import extract_client_ip, EventPayloadBuilder
from ..models import Decision

logger = logging.getLogger("argos.middleware.flask")


class FlaskMiddleware(BaseMiddleware):
    """Flask middleware for Argos security."""

    def __init__(self, app: Any, client: ArgosClient, config: Optional[MiddlewareConfig] = None):
        super().__init__(client, config)
        self.app = app
        self._register_middleware()

    def _register_middleware(self):
        """Register the middleware with Flask."""
        self.app.before_request(self._before_request)
        self.app.after_request(self._after_request)

    def get_request_data(self, request) -> dict:
        """Extract data from Flask request."""
        data = {
            "method": request.method,
            "path": request.path,
            "query": request.query_string.decode() if request.query_string else "",
            "user_agent": request.headers.get("user-agent", ""),
        }

        if request.method in ("POST", "PUT", "PATCH"):
            if request.data:
                data["body"] = request.data.decode("utf-8", errors="replace")
            elif request.form:
                data["form"] = dict(request.form)
            elif request.json:
                data["json"] = request.json

        if self.config.include_headers:
            data["headers"] = dict(request.headers)

        return data

    def get_client_ip(self, request) -> str:
        """Extract client IP from Flask request."""
        from ..utils.ip import extract_client_ip

        direct_ip = request.remote_addr or "unknown"
        return extract_client_ip(
            direct_ip,
            request.headers.get("X-Forwarded-For"),
            request.headers.get("X-Real-IP"),
            self.client.config.trusted_proxies
        )

    def get_user_id(self, request) -> Optional[str]:
        """Extract user ID from Flask request."""
        if self.config.identity_header:
            user_id = request.headers.get(self.config.identity_header)
            if user_id:
                return user_id

        for header in ["X-User-ID", "X-Auth-User-ID", "Remote-User"]:
            user_id = request.headers.get(header)
            if user_id:
                return user_id

        return None

    def _before_request(self):
        """Process request before it reaches the route handler."""
        from flask import request, g, make_response
        import asyncio

        if self.should_skip(request.path):
            return None

        # Flask is sync, so we need to run async code in a loop or use sync methods
        # ArgosClient has sync methods like ingest and queue_event
        
        client_ip = self.get_client_ip(request)
        if client_ip and client_ip != "unknown":
            try:
                blocked, reason = self.client.is_blocked(client_ip)
                if blocked:
                    response = {"error": "blocked", "reason": "IP blocked by Argos: " + reason}
                    resp = make_response(response, 403)
                    resp.headers["X-Argos-Verdict"] = "block"
                    resp.headers["X-Argos-Reason"] = "ip_blocked:" + reason
                    return resp
            except Exception as e:
                logger.error(f"Error checking blocklist: {e}")

        # Build packet using the builder (it's sync)
        packet = self.build_packet(request, source="middleware-flask")
        
        if self.config.mode == "sync":
            try:
                event = self.client.ingest(
                    payload=packet["payload"],
                    metadata=packet["metadata"],
                )
                signal = event.signal or "ALLOW"
                decision = Decision(verdict=signal, reason="ingest_response")
                g.argos_decision = decision

                if signal == "BLOCK":
                    return {"error": "blocked", "reason": decision.reason}, 403
            except Exception as e:
                logger.error(f"Error processing request: {e}")
        else:
            try:
                self.client.queue_event(
                    payload=packet["payload"],
                    metadata=packet["metadata"],
                )
            except Exception as e:
                logger.error(f"Error queueing event: {e}")

        return None

    def _after_request(self, response):
        """Add Argos headers to response."""
        from flask import g

        if hasattr(g, "argos_decision"):
            decision = g.argos_decision
            response.headers["X-Argos-Verdict"] = decision.verdict
            response.headers["X-Argos-Reason"] = decision.reason
        else:
            response.headers["X-Argos-Verdict"] = "ALLOW"
            response.headers["X-Argos-Reason"] = "async_pending"

        return response
