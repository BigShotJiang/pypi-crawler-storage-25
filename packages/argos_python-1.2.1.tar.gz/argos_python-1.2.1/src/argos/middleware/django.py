"""Argos SDK - Django Middleware"""

import logging
from typing import Any, Optional

from .base import MiddlewareConfig
from ..client import ArgosClient
from ..utils import extract_client_ip, EventPayloadBuilder
from ..models import Decision

logger = logging.getLogger("argos.middleware.django")


class DjangoMiddleware:
    """
    Django middleware for Argos security.

    Usage in settings.py:
        MIDDLEWARE = [
            ...
            'argos.middleware.django.DjangoMiddleware',
            ...
        ]

    And add to settings:
        ARGOS_API_KEY = 'your-api-key'
        ARGOS_BASE_URL = 'https://api.your-argos-deployment.com'
    """

    def __init__(self, get_response):
        self.get_response = get_response
        self._client = None
        self._config = None
        self._payload_builder = None

    @property
    def payload_builder(self):
        if self._payload_builder is None:
            self._payload_builder = EventPayloadBuilder(
                include_body=self.config.include_body,
                include_headers=self.config.include_headers,
                identity_header=self.config.identity_header or "X-User-ID",
            )
        return self._payload_builder

    @property
    def client(self):
        if self._client is None:
            from django.conf import settings

            api_key = getattr(settings, "ARGOS_API_KEY", None)
            if not api_key:
                raise ValueError("ARGOS_API_KEY not configured in Django settings")

            from ..client import create_client

            base_url = getattr(settings, "ARGOS_BASE_URL", "https://api.argossecops.com")
            self._client = create_client(api_key=api_key, base_url=base_url)
        return self._client

    @property
    def config(self):
        if self._config is None:
            from django.conf import settings

            self._config = MiddlewareConfig(
                mode=getattr(settings, "ARGOS_MODE", "async"),
                include_headers=getattr(settings, "ARGOS_INCLUDE_HEADERS", True),
                exclude_paths=getattr(settings, "ARGOS_EXCLUDE_PATHS", ["/health", "/admin"]),
            )
        return self._config

    def __call__(self, request):
        # Skip excluded paths
        if self.should_skip(request.path):
            return self.get_response(request)

        # Check if client IP is blocked before processing
        client_ip = self.get_client_ip(request)
        if client_ip and client_ip != "unknown":
            try:
                blocked, reason = self.client.is_blocked(client_ip)
                if blocked:
                    from django.http import JsonResponse

                    return JsonResponse(
                        {"error": "blocked", "reason": f"IP blocked by Argos: {reason}"},
                        status=403,
                    )
            except Exception as e:
                logger.error(f"Error checking blocklist: {e}")

        # Build payload
        payload = self.build_payload(request)

        decision = Decision(verdict="allow", reason="async_pending")

        if self.config.mode == "sync":
            try:
                client_ip = self.get_client_ip(request)
                env_id = self.client.get_environment_id()
                event = self.client.ingest(
                    payload=payload,
                    metadata={
                        "source": "middleware-django-sync",
                        "client_ip": client_ip,
                        "env_id": env_id,
                    },
                )
                # Use signal from ingest response directly
                signal = event.signal or "allow"
                decision = Decision(verdict=signal, reason="ingest_response")

                if decision.verdict.lower() == "block":
                    from django.http import JsonResponse

                    return JsonResponse(
                        {"error": "blocked", "reason": decision.reason},
                        status=403,
                    )
            except Exception as e:
                logger.error(f"Error processing request: {e}")
        else:
            try:
                client_ip = self.get_client_ip(request)
                env_id = self.client.get_environment_id()
                self.client.queue_event(
                    payload=payload,
                    metadata={
                        "source": "middleware-django-async",
                        "client_ip": client_ip,
                        "env_id": env_id,
                    },
                )
            except Exception as e:
                logger.error(f"Error queueing event: {e}")

        # Add headers to request for views to access
        request.argos_decision = decision

        response = self.get_response(request)

        # Add response headers
        response["X-Argos-Verdict"] = decision.verdict
        response["X-Argos-Reason"] = decision.reason

        return response

    def should_skip(self, path: str) -> bool:
        """Check if path should be skipped."""
        for exclude in self.config.exclude_paths:
            if path.startswith(exclude):
                return True
        return False

    def build_payload(self, request) -> dict:
        """Build the event payload from Django request."""
        if self.config.custom_payload_builder:
            return self.config.custom_payload_builder(request)

        return self.payload_builder.build(
            method=request.method,
            path=request.path,
            query=str(request.META.get("QUERY_STRING", "")),
            user_id=self.get_user_id(request),
            client_ip=self.get_client_ip(request),
            user_agent=request.META.get("HTTP_USER_AGENT", ""),
            headers=dict(request.headers) if self.config.include_headers else None,
        )

    def get_client_ip(self, request) -> str:
        """Extract client IP from Django request."""
        from ..utils.ip import extract_client_ip

        direct_ip = request.META.get("REMOTE_ADDR", "unknown")
        return extract_client_ip(
            direct_ip,
            request.META.get("HTTP_X_FORWARDED_FOR"),
            request.META.get("HTTP_X_REAL_IP"),
            self.client.config.trusted_proxies
        )

    def get_user_id(self, request) -> Optional[str]:
        """Extract user ID from Django request."""
        # Check if user is authenticated
        if hasattr(request, "user") and request.user.is_authenticated:
            return str(request.user.id)

        # Check custom header
        header = self.config.identity_header
        if header:
            user_id = request.META.get(f"HTTP_{header.upper().replace('-', '_')}")
            if user_id:
                return user_id

        return None
