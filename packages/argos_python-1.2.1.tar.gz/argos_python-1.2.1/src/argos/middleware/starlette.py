"""Argos SDK - Starlette Middleware"""

import logging
from typing import Any, Callable, Optional

from starlette.datastructures import Headers
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from .base import BaseMiddleware, MiddlewareConfig
from ..client import ArgosClient
from ..utils import extract_client_ip

logger = logging.getLogger("argos.middleware.starlette")


class StarletteMiddleware(BaseHTTPMiddleware):
    """Starlette middleware for Argos security."""

    def __init__(self, app: Any, client: ArgosClient, config: Optional[MiddlewareConfig] = None):
        super().__init__(app)
        BaseMiddleware.__init__(self, client, config)

    def get_request_data(self, request: Request) -> dict:
        """Extract data from Starlette request."""
        data = {
            "method": request.method,
            "path": request.url.path,
            "query": str(request.url.query),
        }

        if self.config.include_headers:
            data["headers"] = dict(request.headers)

        return data

    def get_client_ip(self, request: Request) -> str:
        """Extract client IP from Starlette request."""
        direct_ip = "unknown"
        if request.client:
            direct_ip = request.client.host

        return extract_client_ip(
            direct_ip,
            request.headers.get("X-Forwarded-For"),
            request.headers.get("X-Real-IP"),
            self.client.config.trusted_proxies
        )

    def get_user_id(self, request: Request) -> Optional[str]:
        """Extract user ID from Starlette request."""
        if self.config.identity_header:
            user_id = request.headers.get(self.config.identity_header)
            if user_id:
                return user_id

        for header in ["X-User-ID", "X-Auth-User-ID", "Remote-User"]:
            user_id = request.headers.get(header)
            if user_id:
                return user_id

        return None

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process the request through Argos."""
        if self.should_skip(request.url.path):
            return await call_next(request)

        decision = await self.process(request)

        if decision.verdict.lower() == "block" and self.config.mode == "sync":
            return Response(
                content='{"error": "blocked", "reason": "' + decision.reason + '"}',
                status_code=403,
                media_type="application/json",
            )

        response = await call_next(request)
        response.headers["X-Argos-Verdict"] = decision.verdict
        response.headers["X-Argos-Reason"] = decision.reason

        return response
