"""Argos SDK - FastAPI Middleware"""

import logging
from typing import Any, Optional

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from .base import MiddlewareConfig
from ..client import ArgosClient
from ..utils import extract_client_ip, EventPayloadBuilder
from ..models import Decision

logger = logging.getLogger("argos.middleware.fastapi")


class FastAPIMiddleware(BaseHTTPMiddleware, BaseMiddleware):
    """FastAPI middleware for Argos security."""

    def __init__(self, app: Any, client: ArgosClient, config: Optional[MiddlewareConfig] = None):
        BaseHTTPMiddleware.__init__(self, app)
        BaseMiddleware.__init__(self, client, config)

    async def get_request_data(self, request: Request) -> dict:
        """Extract data from FastAPI request."""
        data = {
            "method": request.method,
            "path": request.url.path,
            "query": str(request.url.query),
            "user_agent": request.headers.get("user-agent", ""),
            "headers": dict(request.headers) if self.config.include_headers else {},
        }

        if request.method in ("POST", "PUT", "PATCH"):
            try:
                body = await request.body()
                if body:
                    data["body"] = body.decode("utf-8", errors="replace")
            except Exception as e:
                logger.error(f"[Argos] Error extracting body: {e}")

        return data

    def get_client_ip(self, request: Request) -> str:
        """Extract client IP from FastAPI request."""
        direct_ip = "unknown"
        if request.client:
            direct_ip = request.client.host

        return extract_client_ip(
            direct_ip,
            request.headers.get("X-Forwarded-For"),
            request.headers.get("X-Real-IP"),
            self.client.config.trusted_proxies
        )

    def get_user_id(self, request: Request) -> Optional[str]:
        """Extract user ID from FastAPI request."""
        if self.config.identity_header:
            user_id = request.headers.get(self.config.identity_header)
            if user_id:
                return user_id

        for header in ["X-User-ID", "X-Auth-User-ID", "Remote-User"]:
            user_id = request.headers.get(header)
            if user_id:
                return user_id

        return None

    async def dispatch(self, request: Request, call_next):
        """Process the request through Argos."""
        if self.should_skip(request.url.path):
            return await call_next(request)

        blocked, reason = await self.check_blocklist(request)
        if blocked:
            return Response(
                content='{"error": "blocked", "reason": "IP blocked by Argos: ' + reason + '"}',
                status_code=403,
                media_type="application/json",
                headers={"X-Argos-Verdict": "block", "X-Argos-Reason": "ip_blocked:" + reason},
            )

        decision = await self.process(request, source="middleware-fastapi")

        if decision.verdict == "BLOCK" and self.config.mode == "sync":
            return Response(
                content='{"error": "blocked", "reason": "' + decision.reason + '"}',
                status_code=403,
                media_type="application/json",
            )

        response = await call_next(request)
        response.headers["X-Argos-Verdict"] = decision.verdict
        response.headers["X-Argos-Reason"] = decision.reason

        return response
