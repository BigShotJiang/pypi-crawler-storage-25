"""Argos SDK - Base Middleware"""

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

from ..client import ArgosClient
from ..utils import ArgosError, EventPayloadBuilder
from ..models import Decision

logger = logging.getLogger("argos.middleware")


class MiddlewareConfig:
    """Configuration for Argos middleware."""

    def __init__(
        self,
        mode: str = "async",
        include_headers: bool = True,
        include_body: bool = True,
        exclude_paths: Optional[list[str]] = None,
        identity_header: Optional[str] = "X-User-ID",
        custom_payload_builder: Optional[Callable] = None,
    ):
        self.mode = mode
        self.include_headers = include_headers
        self.include_body = include_body
        self.exclude_paths = exclude_paths or ["/health", "/metrics", "/_health"]
        self.identity_header = identity_header
        self.custom_payload_builder = custom_payload_builder


class BaseMiddleware(ABC):
    """Base class for Argos middleware."""

    def __init__(self, client: ArgosClient, config: Optional[MiddlewareConfig] = None):
        self.client = client
        self.config = config or MiddlewareConfig()
        self._payload_builder = EventPayloadBuilder(
            include_body=self.config.include_body,
            include_headers=self.config.include_headers,
            identity_header=self.config.identity_header or "X-User-ID",
            custom_builder=self.config.custom_payload_builder,
        )

    @abstractmethod
    def get_request_data(self, request: Any) -> dict:
        """Extract relevant data from the request."""
        pass

    @abstractmethod
    def get_client_ip(self, request: Any) -> str:
        """Extract client IP from request."""
        pass

    @abstractmethod
    def get_user_id(self, request: Any) -> Optional[str]:
        """Extract user ID from request."""
        pass

    def should_skip(self, path: str) -> bool:
        """Check if path should be skipped."""
        for exclude in self.config.exclude_paths:
            if path.startswith(exclude):
                return True
        return False

    def build_packet(self, request: Any, source: str) -> dict:
        """Build the full event packet from request."""
        data = self.get_request_data(request)
        user_id = self.get_user_id(request)
        client_ip = self.get_client_ip(request)
        
        return self._payload_builder.build_packet(
            method=data.get("method", "request"),
            path=data.get("path", ""),
            query=data.get("query", ""),
            user_id=user_id,
            client_ip=client_ip,
            user_agent=data.get("user_agent", ""),
            source=source,
            environment_id=self.client.get_environment_id(),
            body=data.get("body"),
            headers=data.get("headers"),
        )

    async def process_sync(self, request: Any, source: str) -> Decision:
        """Process request synchronously - wait for decision."""
        packet = self.build_packet(request, source)

        try:
            event = await self.client.aingest(
                payload=packet["payload"],
                metadata=packet["metadata"],
            )

            if event.signal == "BLOCK":
                reason = event.decision.get("reason") if event.decision else "blocked"
                return Decision(verdict="block", reason=reason)

            return Decision(verdict="allow", reason="ok")
        except Exception as e:
            logger.error(f"Error processing request: {e}")
            return Decision(verdict="allow", reason=f"error: {e}")

    async def process_async(self, request: Any, source: str) -> Decision:
        """Process request asynchronously - queue and return pending."""
        packet = self.build_packet(request, source)

        try:
            await self.client.aqueue_event(
                payload=packet["payload"],
                metadata=packet["metadata"],
            )
        except Exception as e:
            logger.error(f"Error queueing event: {e}")

        return Decision(verdict="allow", reason="async_pending")

    async def process(self, request: Any, source: str) -> Decision:
        """Process request based on mode."""
        if self.config.mode == "sync":
            return await self.process_sync(request, source)
        return await self.process_async(request, source)

    async def check_blocklist(self, request: Any) -> tuple[bool, str]:
        """Check if the client IP is blocked."""
        client_ip = self.get_client_ip(request)
        if not client_ip or client_ip == "unknown":
            return False, ""

        try:
            blocked, reason = await self.client.ais_blocked(client_ip)
            return blocked, reason
        except Exception as e:
            logger.error(f"Error checking blocklist: {e}")
            return False, ""


def create_middleware(client: ArgosClient, mode: str = "async", **kwargs):
    """Create an Argos middleware function."""
    try:
        from .fastapi import FastAPIMiddleware

        return FastAPIMiddleware(client, MiddlewareConfig(mode=mode, **kwargs))
    except ImportError:
        pass

    try:
        from .starlette import StarletteMiddleware

        return StarletteMiddleware(client, MiddlewareConfig(mode=mode, **kwargs))
    except ImportError:
        pass

    try:
        from .flask import FlaskMiddleware

        return FlaskMiddleware(client, MiddlewareConfig(mode=mode, **kwargs))
    except ImportError:
        pass

    raise ImportError(
        "No compatible framework detected. Install with: pip install argos[fastapi] or argos[flask]"
    )
