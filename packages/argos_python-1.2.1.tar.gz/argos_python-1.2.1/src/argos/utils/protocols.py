"""Protocol definitions for swappable transports."""

from typing import Protocol, Optional
from dataclasses import dataclass


@dataclass
class TransportResponse:
    """Wrapper for transport response."""

    status_code: int
    body: str
    headers: dict

    def json(self) -> dict:
        import json
        if self.body:
            return json.loads(self.body)
        return {}


class HTTPTransportProtocol(Protocol):
    """Protocol defining HTTP transport interface."""

    def request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> TransportResponse: ...
    
    def get(self, endpoint: str, params: Optional[dict] = None) -> TransportResponse: ...
    
    def post(self, endpoint: str, json_data: Optional[dict] = None) -> TransportResponse: ...


    def delete(self, endpoint: str) -> TransportResponse: ...


class BlocklistManagerProtocol(Protocol):
    """Protocol defining blocklist operations."""

    def is_blocked(self, ip: str) -> tuple[bool, str]: ...
    def is_user_blocked(self, user_id: str) -> tuple[bool, str]: ...
    def get_all(self) -> list: ...
    def block_ip(self, ip: str, environment_id: str, reason: str = "") -> object: ...
    def block_user(self, user_id: str, environment_id: str, reason: str = "") -> object: ...
    def unblock(self, entry_id: str) -> None: ...


    # For type compatibility
    @property
    def _request(self) -> callable: ...