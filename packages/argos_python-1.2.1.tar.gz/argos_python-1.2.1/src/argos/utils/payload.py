"""Event payload builder for creating consistent event payloads."""

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


logger = logging.getLogger("argos.payload")


@dataclass
class EventPayloadBuilder:
    """
    Unified event payload builder for consistent event creation.
    
    All middleware adapters should use this builder to ensure consistent
    event payload shape across different web frameworks.
    """

    include_body: bool = True
    include_headers: bool = True
    identity_header: str = "X-User-ID"
    custom_builder: Optional[Callable] = field(default=None, repr=False)

    def build_packet(
        self,
        method: str,
        path: str,
        query: str,
        user_id: Optional[str],
        client_ip: str,
        user_agent: str,
        source: str,
        environment_id: Optional[str] = None,
        body: Optional[str] = None,
        headers: Optional[dict] = None,
        extra_metadata: Optional[dict] = None,
    ) -> dict:
        """
        Build a full event packet (payload + metadata + env) for ingestion.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: Request path
            query: Query string
            user_id: User ID extracted from request
            client_ip: Client IP address
            user_agent: User-Agent header
            source: Source of the event (e.g., 'middleware-fastapi')
            environment_id: Argos environment ID
            body: Request body (optional)
            headers: Request headers (optional)
            extra_metadata: Any additional metadata to include

        Returns:
            Dict containing 'payload', 'metadata', and 'environment_id'
        """
        if self.custom_builder:
            # If custom builder is used, we assume it returns the full packet or just payload?
            # Let's assume it returns a payload and we wrap it.
            payload = self.custom_builder(
                method=method,
                path=path,
                query=query,
                user_id=user_id,
                client_ip=client_ip,
                user_agent=user_agent,
                body=body,
                headers=headers,
            )
        else:
            payload = {
                "event_type": method.lower(),
                "path": path,
                "query": query,
                "user_id": user_id or "anonymous",
                "ip_address": client_ip,
                "user_agent": user_agent,
                "status": "success",
            }

            if self.include_body and body:
                payload["body"] = body

            if self.include_headers and headers:
                payload["headers"] = headers

        metadata = {
            "source": source,
            "ipAddress": client_ip,
            "userAgent": user_agent,
            "externalID": user_id or "anonymous",
            "client_ip": client_ip,
        }
        
        if environment_id:
            metadata["env_id"] = environment_id

        if extra_metadata:
            metadata.update(extra_metadata)

        packet = {
            "payload": payload,
            "metadata": metadata,
        }
        
        if environment_id:
            packet["environment_id"] = environment_id
            
        return packet

    def build(self, **kwargs) -> dict:
        """Legacy support for building just the payload."""
        packet = self.build_packet(source="legacy-builder", **kwargs)
        return packet["payload"]