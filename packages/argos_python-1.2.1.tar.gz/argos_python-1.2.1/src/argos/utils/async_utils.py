"""Async utilities for bridging sync operations to async contexts."""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from functools import wraps
from typing import Any, Awaitable, Callable, TypeVar


_executor = ThreadPoolExecutor(max_workers=4)


T = TypeVar("T")


def run_sync(fn: Callable[..., T]) -> Callable[..., Awaitable[T]]:
    """
    Decorator to run a sync function in a thread pool.
    
    Usage:
        @run_sync
        def blocking_call():
            return expensive_operation()
        
        result = await blocking_call()
    """
    @wraps(fn)
    async def wrapper(*args, **kwargs):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(_executor, lambda: fn(*args, **kwargs))
    return wrapper


async def run_in_thread(fn: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Run a sync function in a thread pool."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(_executor, lambda: fn(*args, **kwargs))