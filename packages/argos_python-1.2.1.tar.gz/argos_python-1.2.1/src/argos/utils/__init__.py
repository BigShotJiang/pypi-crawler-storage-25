"""Argos Utils Module - Utility functions."""

from .ip import extract_client_ip
from .payload import EventPayloadBuilder
from .errors import (
    ArgosError,
    ArgosAPIError,
    ArgosAuthenticationError,
    ArgosRateLimitError,
    ArgosTimeoutError,
    ArgosCircuitOpenError,
    ArgosValidationError,
    ArgosQueueFullError,
)
from .protocols import HTTPTransportProtocol, BlocklistManagerProtocol

__all__ = [
    # IP
    "extract_client_ip",
    # Payload
    "EventPayloadBuilder",
    # Errors
    "ArgosError",
    "ArgosAPIError",
    "ArgosAuthenticationError",
    "ArgosRateLimitError",
    "ArgosTimeoutError",
    "ArgosCircuitOpenError",
    "ArgosValidationError",
    "ArgosQueueFullError",
    # Protocols
    "HTTPTransportProtocol",
    "BlocklistManagerProtocol",
]