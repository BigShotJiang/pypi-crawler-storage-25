"""
Argos Security SDK

A production-grade SDK for integrating Argos security services into your application.

Features:
- Production Ready: Circuit breaker, retry with exponential backoff
- Framework Middleware: Drop-in middleware for FastAPI, Flask, Django, Starlette
- Sync Operations: Synchronous API methods
- Offline Resilience: Local event queue for high-throughput scenarios

Example:
    from argos import create_client

    # Initialize client
    client = create_client(
        api_key="your-api-key",
        base_url="https://api.your-argos-deployment.com"
    )

    # Manual integration
    event = client.ingest({
        "event_type": "login",
        "user_id": "user123",
        "status": "success"
    })

    decision = client.get_decision(event.id)
    if decision.verdict == "block":
        # block the request
        pass
"""

from .client import ArgosClient, ArgosConfig, create_client
from .utils import (
    ArgosError,
    ArgosAPIError,
    ArgosAuthenticationError,
    ArgosRateLimitError,
    ArgosTimeoutError,
    ArgosCircuitOpenError,
)
from .models import Decision, Event, Investigation, Session

# Backwards-compatible aliases (new paths)
from .core import CircuitBreaker, CircuitBreakerConfig, CircuitOpenError
from .core import RetryStrategy, RetryCalculator, RetryConfig
from .core import HTTPTransport, TransportConfig
from .core import BlocklistManager

__version__ = "1.0.0"

__all__ = [
    # Client
    "ArgosClient",
    "ArgosConfig",
    "create_client",
    # Errors
    "ArgosError",
    "ArgosAPIError",
    "ArgosAuthenticationError",
    "ArgosRateLimitError",
    "ArgosTimeoutError",
    "ArgosCircuitOpenError",
    # Models
    "Decision",
    "Event",
    "Investigation",
    "Session",
    # Core (new paths)
    "CircuitBreaker",
    "CircuitBreakerConfig",
    "CircuitOpenError",
    "RetryStrategy",
    "RetryCalculator",
    "RetryConfig",
    "HTTPTransport",
    "TransportConfig",
    "BlocklistManager",
]


def create_middleware(client, mode="async", **kwargs):
    """
    Create an Argos middleware function.

    Args:
        client: ArgosClient instance
        mode: "sync" (wait for decision) or "async" (queue and continue)
        **kwargs: Additional options

    Returns:
        Middleware function
    """
    try:
        from .middleware.fastapi import FastAPIMiddleware
        from .middleware.base import MiddlewareConfig

        return FastAPIMiddleware
    except ImportError:
        pass

    try:
        from .middleware.flask import FlaskMiddleware

        return FlaskMiddleware
    except ImportError:
        pass

    try:
        from .middleware.django import DjangoMiddleware

        return DjangoMiddleware
    except ImportError:
        pass

    raise ImportError(
        "No compatible framework detected. Install FastAPI, Flask, or Django to use middleware."
    )


# Backwards compatibility aliases
ArgosClient = ArgosClient
ArgosConfig = ArgosConfig
create_client = create_client
ArgosError = ArgosError
ArgosAPIError = ArgosAPIError
ArgosAuthenticationError = ArgosAuthenticationError
ArgosRateLimitError = ArgosRateLimitError
ArgosTimeoutError = ArgosTimeoutError
ArgosCircuitOpenError = ArgosCircuitOpenError

# Legacy aliases (deprecated, use Argos* names)
argosClient = ArgosClient
argosConfig = ArgosConfig
argosError = ArgosError
argosAPIError = ArgosAPIError
argosAuthenticationError = ArgosAuthenticationError
argosRateLimitError = ArgosRateLimitError
argosTimeoutError = ArgosTimeoutError
argosCircuitOpenError = ArgosCircuitOpenError
