"""Event and related models."""

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class Event:
    """Represents an event sent to Argos."""

    id: Optional[str] = None
    session_id: Optional[str] = None
    environment_id: Optional[str] = None
    time: Optional[str] = None
    payload: Optional[dict[str, Any]] = None
    session: Optional[dict] = None
    environment: Optional[dict] = None
    decision: Optional[dict] = None
    investigations: Optional[list] = None
    anomaly_score: Optional[float] = None
    signal: Optional[str] = None

    @property
    def event_id(self) -> Optional[str]:
        """Alias for id for backward compatibility/consistency."""
        return self.id

    @property
    def verdict(self) -> str:
        """Alias for signal."""
        return self.signal or "unknown"

    @property
    def event_type(self) -> str:
        if self.payload and isinstance(self.payload, dict):
            return self.payload.get("event_type", "unknown")
        return "unknown"

    def __repr__(self) -> str:
        return f"Event(id={self.id}, type={self.event_type}, signal={self.signal})"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "environment_id": self.environment_id,
            "time": self.time,
            "payload": self.payload,
            "signal": self.signal,
            "anomaly_score": self.anomaly_score,
        }


@dataclass
class Investigation:
    """Represents an investigation created by Argos."""

    id: str
    event_id: str
    status: str
    created_at: str
    findings: Optional[dict] = None

    def __repr__(self) -> str:
        return f"Investigation(id={self.id}, status={self.status})"


@dataclass
class Session:
    """Represents a session from Argos."""

    id: str
    identity_id: str
    environment_id: str
    started_at: str
    ended_at: Optional[str] = None
    user_agent: Optional[str] = None
    ip_address: Optional[str] = None

    def __repr__(self) -> str:
        return f"Session(id={self.id})"


@dataclass
class BlockStatus:
    """Represents the result of an access check."""

    ip_blocked: bool = False
    ip_reason: str = ""
    user_blocked: bool = False
    user_reason: str = ""
    blocked: bool = False
    block_reason: str = ""

    def __repr__(self) -> str:
        return f"BlockStatus(blocked={self.blocked}, reason={self.block_reason})"

    def to_dict(self) -> dict:
        return {
            "ip_blocked": self.ip_blocked,
            "ip_reason": self.ip_reason,
            "user_blocked": self.user_blocked,
            "user_reason": self.user_reason,
            "blocked": self.blocked,
            "block_reason": self.block_reason,
        }


@dataclass
class BlocklistEntry:
    """Represents an entry in the blocklist."""

    id: str
    type: str
    value: str
    reason: str = ""
    blocked_at: str = ""
    expires_at: Optional[str] = None
    environment_id: str = ""

    @property
    def is_ip(self) -> bool:
        return self.type == "ip"

    @property
    def is_user(self) -> bool:
        return self.type == "user"

    def __repr__(self) -> str:
        return f"BlocklistEntry(type={self.type}, value={self.value})"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "value": self.value,
            "reason": self.reason,
            "blocked_at": self.blocked_at,
            "expires_at": self.expires_at,
            "environment_id": self.environment_id,
        }


def normalize_event_response(data: dict) -> Event:
    """Normalize event response from API to Event model."""
    if not isinstance(data, dict):
        return Event()

    # The API might return fields in different cases or names
    id_val = data.get("id") or data.get("event_id") or data.get("eventID")
    signal_val = data.get("signal") or data.get("verdict") or data.get("Verdict")
    
    # Normalize signal to uppercase if it's a string
    if isinstance(signal_val, str):
        signal_val = signal_val.upper()

    return Event(
        id=id_val,
        session_id=data.get("session_id") or data.get("sessionID"),
        environment_id=data.get("environment_id") or data.get("environmentID") or data.get("env_id"),
        time=data.get("time") or data.get("created_at") or data.get("Time"),
        payload=data.get("payload") or data.get("Payload"),
        anomaly_score=data.get("anomaly_score") or data.get("anomalyScore"),
        signal=signal_val,
    )