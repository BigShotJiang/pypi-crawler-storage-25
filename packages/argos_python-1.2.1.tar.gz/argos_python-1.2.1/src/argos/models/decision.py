"""Decision model with validation."""

from dataclasses import dataclass


class InvalidVerdictError(ValueError):
    """Raised when an invalid verdict is provided."""
    pass


@dataclass
class Decision:
    """Represents a decision/verdict from Argos."""

    VERDICT_ALLOW = "allow"
    VERDICT_BLOCK = "block"
    VERDICT_PENDING = "pending"
    _VALID_VERDICTS = frozenset({"allow", "block", "pending"})

    verdict: str
    reason: str = ""

    def __post_init__(self):
        normalized = self.verdict.lower()
        if normalized not in self._VALID_VERDICTS:
            raise InvalidVerdictError(
                f"Invalid verdict '{self.verdict}'. Must be one of: {self._VALID_VERDICTS}"
            )
        object.__setattr__(self, 'verdict', normalized)

    def __repr__(self) -> str:
        return f"Decision(verdict={self.verdict}, reason={self.reason})"

    @property
    def is_allowed(self) -> bool:
        return self.verdict == "allow"

    @property
    def is_blocked(self) -> bool:
        return self.verdict == "block"

    @property
    def is_pending(self) -> bool:
        return self.verdict == "pending"

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "reason": self.reason,
        }