"""Argos Security SDK - Core Client"""

import asyncio
import json
import logging
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from enum import Enum
from queue import Queue, Full
from threading import Lock
from typing import Any, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from urllib.parse import urljoin

from .core import CircuitBreaker, CircuitBreakerConfig, CircuitOpenError
from .core import RetryStrategy, RetryCalculator, RetryConfig
from .core import BlocklistManager
from .utils import ArgosError, ArgosAPIError, ArgosAuthenticationError, ArgosRateLimitError, ArgosTimeoutError
from .models import Decision, Event, BlockStatus, BlocklistEntry, normalize_event_response

logger = logging.getLogger("argos")


class RetryStrategy(str, Enum):
    """Retry strategy for failed requests."""

    NONE = "none"
    EXPONENTIAL = "exponential"
    LINEAR = "linear"


@dataclass
class ArgosConfig:
    """Configuration for the Argos client."""

    api_key: str
    base_url: str = "https://api.argossecops.com"
    timeout: float = 30.0
    max_retries: int = 3
    retry_strategy: RetryStrategy = RetryStrategy.EXPONENTIAL
    retry_base_delay: float = 0.5
    retry_max_delay: float = 30.0
    retry_jitter: bool = True
    circuit_breaker_threshold: int = 5
    circuit_breaker_timeout: float = 60.0
    max_connections: int = 100
    queue_size: int = 1000
    sync_mode: bool = False
    auto_block_on_block: bool = False  # Automatically block IP when ingest returns BLOCK verdict
    auto_block_ttl: float = 3600.0  # TTL in seconds for auto-blocked IPs (default 1 hour)
    trusted_proxies: Optional[list[str]] = None
    environment_id: Optional[str] = None  # Auto-detected from API key
    flush_interval: float = 1.0  # Frequency of background flushes (seconds)
    batch_size: int = 50  # Max events per batch flush
    blocklist_cache_ttl: float = 60.0  # TTL for blocklist cache (seconds)


class ArgosClient:
    """
    Main client for interacting with the Argos security API.

    Features:
    - Synchronous and asynchronous operations
    - Automatic retry with exponential backoff
    - Circuit breaker pattern
    - Request queuing for resilience

    Example:
        client = ArgosClient(
            api_key="argus_env_...",
            base_url="https://api.argos.io"
        )

        # Ingest event
        event = client.ingest({
            "event_type": "login",
            "user_id": "user123",
            "status": "success"
        })

        # Get decision
        decision = client.get_decision(event.id)
        if decision.verdict == "block":
            # block the request
            pass
    """

    def __init__(self, config: ArgosConfig | dict | str, **kwargs):
        if isinstance(config, str):
            config = {"api_key": config}
        if isinstance(config, dict):
            config = ArgosConfig(**config, **kwargs)

        self.config = config

        self._circuit = CircuitBreaker(
            config=CircuitBreakerConfig(
                threshold=config.circuit_breaker_threshold,
                timeout=config.circuit_breaker_timeout,
            )
        )

        self._retry = RetryCalculator(
            RetryConfig(
                strategy=config.retry_strategy,
                base_delay=config.retry_base_delay,
                max_delay=config.retry_max_delay,
                jitter=config.retry_jitter,
            )
        )
        
        self._blocklist = BlocklistManager(
            self._request,
            cache_ttl=config.blocklist_cache_ttl
        )

        self._event_queue: list[dict] = []
        self._queue_lock = Lock()
        self._worker_lock = Lock()
        self._stop_event = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None

        if not self.config.environment_id:
            self._detect_environment()

        if not self.config.sync_mode:
            self._start_worker()

    def _start_worker(self) -> None:
        """Start the background worker thread."""
        with self._worker_lock:
            if self._worker_thread is not None and self._worker_thread.is_alive():
                return

            self._stop_event.clear()
            self._worker_thread = threading.Thread(
                target=self._worker_loop,
                name="ArgosBackgroundWorker",
                daemon=True
            )
            self._worker_thread.start()
            logger.debug("[Argos] Background worker started")

    def _worker_loop(self) -> None:
        """Background loop to flush the event queue."""
        while not self._stop_event.is_set():
            try:
                # Sleep first to allow events to accumulate
                self._stop_event.wait(self.config.flush_interval)
                if self._stop_event.is_set():
                    break

                if self._event_queue:
                    self.flush_queue()
            except Exception as e:
                logger.error(f"[Argos] Background worker error: {e}")

    def _detect_environment(self) -> None:
        """Auto-detect environment_id from API key."""
        try:
            response = self._request("GET", "/api/v1/me")
            self.config.environment_id = response.get("environment_id", "")
            if self.config.environment_id:
                logger.info(f"[Argos] Auto-detected environment_id: {self.config.environment_id}")
        except Exception as e:
            logger.warning(f"[Argos] Could not auto-detect environment_id: {e}")

    def get_environment_id(self) -> str:
        """Get the environment_id for this client."""
        return self.config.environment_id or ""

    def _get_headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "X-API-Key": self.config.api_key,
            "User-Agent": "Argos-Python-SDK/1.0.0",
        }

    def _request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        """Make HTTP request with retry logic and circuit breaker."""
        if self._circuit.is_open():
            raise CircuitOpenError("Circuit breaker is open. Too many recent failures.")

        last_error: Exception = ArgosError("Unknown error")

        url = urljoin(self.config.base_url, endpoint)
        if params:
            query_string = "&".join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{query_string}"

        for attempt in range(self.config.max_retries + 1):
            try:
                data = json.dumps(json_data).encode("utf-8") if json_data else None

                request = Request(
                    url,
                    data=data,
                    headers=self._get_headers(),
                    method=method,
                )

                with urlopen(request, timeout=self.config.timeout) as response:
                    self._circuit.record_success()
                    response_body = response.read().decode("utf-8")
                    if response_body:
                        return json.loads(response_body)
                    return {}

            except HTTPError as e:
                body = e.read().decode("utf-8") if e.fp else ""

                # Handle 403 as a valid response (BLOCK verdict) not an error
                if e.code == 403:
                    try:
                        resp_data = json.loads(body) if body else {}
                        if "event_id" in resp_data:
                            # Valid security response with event data
                            return resp_data
                    except (json.JSONDecodeError, ValueError):
                        pass

                # Don't record success on error
                self._circuit.record_failure()

                if e.code == 401:
                    raise ArgosAuthenticationError(
                        "Invalid API key",
                        e.code,
                        body,
                    )
                elif e.code == 429:
                    retry_after = 60.0
                    try:
                        retry_after = float(e.headers.get("Retry-After", 60))
                    except (ValueError, TypeError):
                        pass
                    raise ArgosRateLimitError(
                        "Rate limit exceeded",
                        e.code,
                        body,
                        retry_after,
                    )
                elif e.code >= 500:
                    raise ArgosAPIError(
                        f"Server error: {e.code}",
                        e.code,
                        body,
                    )
                else:
                    raise ArgosAPIError(
                        f"API error: {e.code}",
                        e.code,
                        body,
                    )

            except URLError as e:
                last_error = ArgosError(f"Connection error: {e.reason}")
                if attempt < self.config.max_retries:
                    delay = self._retry.calculate_delay(attempt + 1)
                    logger.warning(f"Connection error, retrying in {delay:.2f}s")
                    time.sleep(delay)
                else:
                    self._circuit.record_failure()

            except TimeoutError as e:
                last_error = ArgosTimeoutError(f"Request timeout: {e}")
                if attempt < self.config.max_retries:
                    delay = self._retry.calculate_delay(attempt + 1)
                    logger.warning(f"Request timeout, retrying in {delay:.2f}s")
                    time.sleep(delay)
                else:
                    self._circuit.record_failure()

            except Exception as e:
                last_error = ArgosError(f"Unexpected error: {e}")
                self._circuit.record_failure()
                raise

        raise last_error

    def _prepare_packet(self, payload: dict, metadata: Optional[dict] = None) -> dict:
        """Internal helper to ensure all ingestion calls have consistent structure."""
        packet = {
            "payload": payload,
            "metadata": metadata or {}
        }
        
        # Ensure environment_id is present in both top-level and metadata
        env_id = self.config.environment_id
        if env_id:
            packet["environment_id"] = env_id
            if "env_id" not in packet["metadata"]:
                packet["metadata"]["env_id"] = env_id
                
        # Ensure externalID in metadata
        if "externalID" not in packet["metadata"] and "external_id" not in packet["metadata"]:
            packet["metadata"]["externalID"] = payload.get("user_id", "anonymous")
            
        return packet

    def ingest(self, payload: dict, metadata: Optional[dict] = None) -> Event:
        """
        Ingest a single event to the Argos API.

        Args:
            payload: Event data (event_type, user_id, status, etc.)
            metadata: Optional metadata (externalID, sessionID, source, etc.)

        Returns:
            Event: The created event with ID and details
        """
        packet = self._prepare_packet(payload, metadata)
        logger.debug(f"[Argos] Ingesting event: {payload.get('event_type', 'unknown')}")

        response = self._request("POST", "/api/v1/ingest", json_data=packet)
        event = normalize_event_response(response)
        
        # Ensure payload is attached to the event model
        event.payload = payload

        # Auto-block IP if verdict is BLOCK and auto-block is enabled
        if self.config.auto_block_on_block and event.signal == "BLOCK":
            self._handle_auto_block(packet["metadata"], event.signal)

        return event

    def _handle_auto_block(self, metadata: dict, verdict: str) -> None:
        """Handle auto-blocking of IP if enabled."""
        if not self.config.auto_block_on_block or verdict != "BLOCK":
            return
            
        client_ip = metadata.get("client_ip") or metadata.get("ipAddress")
        env_id = metadata.get("env_id") or self.config.environment_id
        
        if client_ip and env_id:
            try:
                self.block_ip(client_ip, env_id, f"auto_blocked: {verdict} verdict")
                logger.info(f"[Argos] Auto-blocked IP {client_ip} after {verdict} verdict")
            except Exception as e:
                logger.error(f"[Argos] Auto-block failed for IP {client_ip}: {e}")

    def ingest_batch(
        self,
        payloads: list[dict],
        metadata: Optional[list[dict]] = None,
    ) -> list[Event]:
        """
        Ingest multiple events in a single batch request.
        """
        packets = []
        for i, payload in enumerate(payloads):
            m = metadata[i] if metadata and i < len(metadata) else None
            packets.append(self._prepare_packet(payload, m))

        # The batch API expects a single packet with lists, or a list of packets?
        # Usually /ingest/batch expects: { "payloads": [...], "metadata": [...], "environment_id": "..." }
        # Let's align with what's expected by the backend (based on previous code)
        
        batch_data = {
            "payloads": [p["payload"] for p in packets],
            "metadata": [p["metadata"] for p in packets]
        }
        if self.config.environment_id:
            batch_data["environment_id"] = self.config.environment_id

        response = self._request("POST", "/api/v1/ingest/batch", json_data=batch_data)

        # Handle response - each item has event_id
        events = []
        if isinstance(response, list):
            for i, resp in enumerate(response):
                if isinstance(resp, dict):
                    event = normalize_event_response(resp)
                    if i < len(payloads):
                        event.payload = payloads[i]
                    events.append(event)
                    
                    # Auto-block for batch items
                    if self.config.auto_block_on_block and event.signal == "BLOCK":
                        self._handle_auto_block(packets[i]["metadata"], event.signal)
        return events

    def get_decision(self, event_id: str) -> Decision:
        """
        Get the decision/verdict for an event.
        """
        if not event_id:
            return Decision(verdict="allow", reason="no_event_id")

        try:
            response = self._request("GET", f"/api/v1/events/{event_id}/decision")
            return Decision(
                verdict=response.get("verdict", "allow"),
                reason=response.get("reason", ""),
            )
        except Exception as e:
            # If get_decision fails, return a default allow decision
            return Decision(verdict="allow", reason=f"decision_unavailable: {e}")

    def queue_event(self, payload: dict, metadata: Optional[dict] = None) -> None:
        """
        Queue an event for later processing.
        """
        with self._queue_lock:
            if len(self._event_queue) >= self.config.queue_size:
                logger.warning("Event queue full, dropping oldest event")
                self._event_queue.pop(0)

            self._event_queue.append({"payload": payload, "metadata": metadata})
            
        # Ensure worker is running if not in sync mode
        if not self.config.sync_mode:
            self._start_worker()

    def flush_queue(self) -> list[Event]:
        """
        Flush all queued events to the API.
        """
        batch_events = []
        with self._queue_lock:
            if not self._event_queue:
                return []
            
            # Take up to batch_size events
            count = min(len(self._event_queue), self.config.batch_size)
            batch_events = self._event_queue[:count]
            # Don't pop yet, wait for success
            # self._event_queue = self._event_queue[count:]

        payloads = []
        metadata = []

        for event in batch_events:
            payloads.append(event["payload"])
            metadata.append(event.get("metadata"))

        try:
            results = self.ingest_batch(payloads, metadata)
            
            # On success, remove from queue
            with self._queue_lock:
                # Need to be careful here if more events were added
                # We only remove the ones we just sent
                self._event_queue = self._event_queue[count:]
            return results
        except Exception as e:
            logger.error(f"[Argos] Failed to flush queue: {e}")
            # Keep in queue for next flush
            return []

    def health_check(self) -> dict:
        """Check the health of the Argos API."""
        return self._request("GET", "/health")

    def is_blocked(self, ip: str) -> tuple[bool, str]:
        """
        Check if an IP is blocked in Argos.

        Args:
            ip: The IP address to check

        Returns:
            Tuple of (is_blocked: bool, reason: str)
        """
        return self._blocklist.is_blocked(ip)

    def is_user_blocked(self, user_id: str) -> tuple[bool, str]:
        """
        Check if a user_id is blocked in Argos.

        Args:
            user_id: The user ID to check

        Returns:
            Tuple of (is_blocked: bool, reason: str)
        """
        return self._blocklist.is_user_blocked(user_id)

    def check_access(self, ip: Optional[str] = None, user_id: Optional[str] = None) -> BlockStatus:
        """
        Check if an IP or user_id is blocked.

        Returns:
            BlockStatus: Detailed block information
        """
        status = BlockStatus(blocked=False)

        if ip:
            blocked, reason = self.is_blocked(ip)
            status.ip_blocked = blocked
            status.ip_reason = reason
            if blocked:
                status.blocked = True
                status.block_reason = reason

        if user_id:
            blocked, reason = self.is_user_blocked(user_id)
            status.user_blocked = blocked
            status.user_reason = reason
            if blocked:
                status.blocked = True
                if not status.block_reason:
                    status.block_reason = reason
                else:
                    status.block_reason = f"{status.block_reason}; {reason}"

        return status

    def get_blocklist(self) -> list[BlocklistEntry]:
        """
        Get all blocklist entries.

        Returns:
            List of blocklist entries
        """
        return self._blocklist.get_all()

    def block_ip(self, ip: str, environment_id: str, reason: str = "") -> BlocklistEntry:
        """
        Add an IP to the blocklist.

        Args:
            ip: The IP address to block
            environment_id: The environment ID
            reason: Optional reason for blocking

        Returns:
            BlocklistEntry: The created blocklist entry
        """
        logger.info(f"[Argos.block_ip] ip={ip}, environment_id={environment_id}")
        return self._blocklist.block_ip(ip, environment_id, reason)

    def block_user(self, user_id: str, environment_id: str, reason: str = "") -> BlocklistEntry:
        """
        Add a user to the blocklist.

        Args:
            user_id: The user ID to block
            environment_id: The environment ID
            reason: Optional reason for blocking

        Returns:
            BlocklistEntry: The created blocklist entry
        """
        return self._blocklist.block_user(user_id, environment_id, reason)

    def unblock(self, entry_id: str) -> None:
        """
        Remove an entry from the blocklist.

        Args:
            entry_id: The blocklist entry ID to remove.
        """
        return self._blocklist.unblock(entry_id)

    async def ais_blocked(self, ip: str) -> tuple[bool, str]:
        """Check if an IP is blocked (async)."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.is_blocked, ip)

    async def ais_user_blocked(self, user_id: str) -> tuple[bool, str]:
        """Check if a user is blocked (async)."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.is_user_blocked, user_id)

    async def ahealth_check(self) -> dict:
        """Health check (async)."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.health_check)

    async def aqueue_event(self, payload: dict, metadata: Optional[dict] = None) -> None:
        """Queue an event (async)."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.queue_event(payload, metadata))

    async def aingest(self, payload: dict, metadata: Optional[dict] = None) -> Event:
        """Ingest an event (async)."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.ingest(payload, metadata))

    def close(self) -> None:
        """Close the client and release resources."""
        self._stop_event.set()
        if self._worker_thread:
            # Short wait for thread to finish
            self._worker_thread.join(timeout=2.0)
        
        # Final flush
        if self._event_queue:
            try:
                self.flush_queue()
            except Exception as e:
                logger.error(f"[Argos] Final flush failed: {e}")

    def __enter__(self) -> "ArgosClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"ArgosClient(base_url={self.config.base_url}, api_key=***)"


# Convenience function for quick initialization
def create_client(
    api_key: str,
    base_url: str = "https://api.argossecops.com",
    **kwargs,
) -> ArgosClient:
    """
    Create an ArgosClient with sensible defaults.

    Args:
        api_key: Your Argos API key (env or environment key)
        base_url: Base URL of the Argos API
        **kwargs: Additional configuration options

    Returns:
        ArgosClient: Configured client instance
    """
    return ArgosClient(
        {
            "api_key": api_key,
            "base_url": base_url,
            **kwargs,
        }
    )
