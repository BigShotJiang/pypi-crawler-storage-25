"""Tests for Argos Python SDK"""

import pytest
import time
import threading
from unittest.mock import Mock, patch, MagicMock

from argos import create_client, ArgosClient, ArgosConfig, Decision, Event
from argos import (
    ArgosError,
    ArgosAuthenticationError,
    ArgosRateLimitError,
    ArgosTimeoutError,
    ArgosCircuitOpenError,
)


@pytest.fixture(autouse=True)
def mock_detect_env():
    """Automatically mock _detect_environment for all tests to avoid side effects."""
    with patch("argos.client.ArgosClient._detect_environment"):
        yield


class TestArgosConfig:
    """Test ArgosConfig."""
    
    def test_config_from_string(self):
        """Test creating config from API key string."""
        config = ArgosConfig(api_key="test_key")
        assert config.api_key == "test_key"
        assert config.base_url == "https://api.argossecops.com"
    
    def test_config_from_dict(self):
        """Test creating config from dict."""
        client = ArgosClient({"api_key": "test_key", "base_url": "http://custom"})
        assert client.config.api_key == "test_key"
        assert client.config.base_url == "http://custom"


class TestDecision:
    """Test Decision model."""
    
    def test_decision_allowed(self):
        """Test allow decision."""
        decision = Decision(verdict="Allow", reason="No policy matched")
        assert decision.is_allowed
        assert not decision.is_blocked
    
    def test_decision_blocked(self):
        """Test block decision."""
        decision = Decision(verdict="Block", reason="Matched policy")
        assert decision.is_blocked
        assert not decision.is_allowed
    
    def test_decision_pending(self):
        """Test pending decision."""
        decision = Decision(verdict="Pending")
        assert decision.is_pending


class TestEvent:
    """Test Event model."""
    
    def test_event_creation(self):
        """Test creating an event."""
        event_data = {
            "id": "test_id",
            "session_id": "session_id",
            "environment_id": "env_id",
            "time": "2024-01-01T00:00:00Z",
            "payload": {"event_type": "login"},
        }
        event = Event(**event_data)
        assert event.id == "test_id"
        assert event.payload["event_type"] == "login"


class TestRetryLogic:
    """Test retry and circuit breaker logic."""
    
    def test_calculate_delay_exponential(self):
        """Test exponential backoff calculation."""
        client = create_client(
            api_key="test",
            retry_base_delay=1.0,
            retry_jitter=False,
        )
        
        delay1 = client._retry.calculate_delay(1)
        delay2 = client._retry.calculate_delay(2)
        delay3 = client._retry.calculate_delay(3)
        
        # Exponential: 1s, 2s, 4s
        assert delay1 == 1.0
        assert delay2 == 2.0
        assert delay3 == 4.0
    
    def test_circuit_breaker_opens(self):
        """Test circuit breaker opens after threshold."""
        client = create_client(
            api_key="test",
            circuit_breaker_threshold=3,
        )
        
        # Record failures
        client._circuit.record_failure()
        client._circuit.record_failure()
        assert not client._circuit.is_open()
        
        # Third failure opens circuit
        client._circuit.record_failure()
        assert client._circuit.is_open()


class TestQueueOperations:
    """Test event queue operations."""
    
    @patch("argos.client.ArgosClient._request")
    def test_background_worker_flushes(self, mock_request):
        """Test that background worker flushes queued events."""
        mock_request.return_value = [{"event_id": "1", "verdict": "allow"}]
        
        client = create_client(
            api_key="test",
            flush_interval=0.1,
            sync_mode=False
        )
        
        client.queue_event({"event": "test"})
        assert len(client._event_queue) == 1
        
        # Wait for background flush
        time.sleep(0.3)
        
        assert len(client._event_queue) == 0
        assert mock_request.called
        client.close()

    def test_queue_full(self):
        """Test queue size limit."""
        client = create_client(api_key="test", queue_size=2, sync_mode=True)
        
        client.queue_event({"event": 1})
        client.queue_event({"event": 2})
        client.queue_event({"event": 3})  # Should drop oldest
        
        assert len(client._event_queue) == 2
        # Oldest should be dropped
        assert client._event_queue[0]["payload"]["event"] == 2


class TestBlocklistCache:
    """Test blocklist caching logic."""

    @patch("argos.client.ArgosClient._request")
    def test_is_blocked_caching(self, mock_request):
        """Test that is_blocked uses cache."""
        mock_request.return_value = {"blocked": True, "reason": "test"}
        
        client = create_client(api_key="test", blocklist_cache_ttl=1.0)
        
        # Reset mock after any init calls (though _detect_environment is mocked now)
        mock_request.reset_mock()
        
        # First call - should make request
        blocked1, reason1 = client.is_blocked("1.2.3.4")
        assert blocked1 is True
        assert mock_request.call_count == 1
        
        # Second call - should use cache
        blocked2, reason2 = client.is_blocked("1.2.3.4")
        assert blocked2 is True
        assert mock_request.call_count == 1
        
        # Call for different IP - should make request
        client.is_blocked("5.6.7.8")
        assert mock_request.call_count == 2
        
        # Wait for TTL to expire
        time.sleep(1.1)
        client.is_blocked("1.2.3.4")
        assert mock_request.call_count == 3
