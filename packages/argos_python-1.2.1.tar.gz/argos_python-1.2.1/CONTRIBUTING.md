# Contributing to Argos Python SDK

First off, thank you for considering contributing to the Argos Python SDK! It's people like you who make Argos a great tool for the security community.

## Philosophy

The Argos Python SDK is designed with several core principles in mind:

1.  **Standard Library First**: To keep the SDK lightweight and easy to install, we prioritize the Python standard library over external dependencies. Dependencies should only be added if absolutely necessary (e.g., for framework-specific middleware).
2.  **Resilience by Default**: Security infrastructure must not be a single point of failure. We use patterns like Circuit Breakers and Retries with Exponential Backoff to ensure your application stays up even if the security API is having a bad day.
3.  **Performance & Locality**: Security checks should not slow down your application. We use local caching (locality) and background processing to minimize the impact on request latency.
4.  **Developer Leverage**: We provide drop-in middleware for popular frameworks so that developers can get world-class security with just a few lines of code.

## Coding Style

We follow PEP 8 and use modern Python features:

-   **Type Hints**: All function signatures and class members must have type hints.
-   **Dataclasses**: Use `dataclasses` for data models and configurations.
-   **Thread Safety**: Any state shared across threads (like the event queue or caches) must be protected by a `threading.Lock`.
-   **Docstrings**: All public methods and classes must have Google-style docstrings.
-   **Async Support**: For every synchronous method that performs I/O, provide an asynchronous counterpart (usually prefixed with `a`).

## Development Process

### 1. Environment Setup

We use `uv` for dependency management and development:

```bash
# Install dependencies
uv sync --all-extras
```

### 2. Testing

We use `pytest` for our test suite. All new features must include tests, and all existing tests must pass.

```bash
# Run tests
uv run pytest
```

When writing tests:
-   Mock all network requests using `unittest.mock.patch`.
-   Avoid side effects in `__init__` by mocking `_detect_environment`.
-   Test both success and failure paths (retries, circuit breaker opening).

### 3. Linting and Formatting

We use `ruff` for linting and formatting:

```bash
# Lint and format
uv run ruff check . --fix
uv run ruff format .
```

## Pull Request Guidelines

1.  Keep PRs focused on a single change.
2.  Ensure the test suite passes.
3.  Update the `README.md` if you're adding or changing a feature.
4.  Include a brief description of the change and the rationale behind it.

## Community

If you have questions or need help, feel free to open an issue or reach out to the team at team@tachyonix.net.
