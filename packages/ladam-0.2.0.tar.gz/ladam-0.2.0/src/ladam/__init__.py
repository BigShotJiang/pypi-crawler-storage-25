"""
LAdam — Laplacian Adam Optimizer
"""

__version__ = "0.2.0"

from .optimizer import LAdam, LAdaGrad, LRMSProp, suggest_c2

# Backward compatibility alias
WaveAdam = LAdam

__all__ = ["LAdam", "LAdaGrad", "LRMSProp", "WaveAdam", "suggest_c2"]
