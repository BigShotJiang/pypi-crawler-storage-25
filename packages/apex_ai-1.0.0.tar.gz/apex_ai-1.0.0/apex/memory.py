"""Persistent memory for APEX - key facts learned across sessions."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class Memory:
    def __init__(self):
        self._memory_file = Path.home() / ".apex" / "memory.json"
        self._facts: list[dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        if self._memory_file.exists():
            try:
                with open(self._memory_file) as f:
                    self._facts = json.load(f)
            except json.JSONDecodeError:
                self._facts = []

    def _save(self) -> None:
        self._memory_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self._memory_file, "w") as f:
            json.dump(self._facts, f, indent=2)

    def add(self, fact: str, relevance: list[str] | None = None) -> None:
        self._facts.append({
            "fact": fact,
            "added": datetime.now().isoformat(),
            "relevance": relevance or []
        })
        self._save()

    def get_all(self) -> list[dict[str, Any]]:
        return self._facts.copy()

    def get_relevant(self, keywords: list[str]) -> list[dict[str, Any]]:
        relevant = []
        for fact in self._facts:
            if any(kw in fact.get("relevance", []) for kw in keywords):
                relevant.append(fact)
        return relevant

    def get_context_for_prompt(self, project_name: str = "") -> str:
        keywords = [project_name] if project_name else []
        relevant = self.get_relevant(keywords)
        if not relevant:
            return ""
        lines = ["[MEMORY - Relevant facts from previous sessions]"]
        for fact_data in relevant[-5:]:
            lines.append(f"- {fact_data['fact']}")
        return "\n".join(lines)

    def clear(self) -> None:
        self._facts = []
        self._save()

    def remove(self, index: int) -> bool:
        if 0 <= index < len(self._facts):
            self._facts.pop(index)
            self._save()
            return True
        return False

    def list_facts(self) -> list[str]:
        return [f["fact"] for f in self._facts]

    def search(self, query: str) -> list[dict[str, Any]]:
        query_lower = query.lower()
        return [f for f in self._facts if query_lower in f["fact"].lower()]