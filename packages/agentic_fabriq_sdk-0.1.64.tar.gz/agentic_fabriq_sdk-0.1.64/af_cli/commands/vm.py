"""afctl vm — local VM management commands."""
import subprocess
import sys
from pathlib import Path

import typer

app = typer.Typer(help="Manage local VMs for computer use agents")


@app.command()
def serve(
    port: int = typer.Option(7865, "--port", "-p", help="Port for the VM management server"),
):
    """Start the local VM management server."""
    vm_dir = Path(__file__).resolve().parent.parent / "vm"
    server_js = vm_dir / "server.js"
    node_modules = vm_dir / "node_modules"

    if not server_js.exists():
        typer.echo(f"Error: server.js not found at {server_js}", err=True)
        raise typer.Exit(1)

    # Auto-install node dependencies if missing
    if not node_modules.exists():
        typer.echo("Installing VM server dependencies...")
        subprocess.run(["npm", "install"], cwd=str(vm_dir), check=True)

    typer.echo(f"Starting VM management server on port {port}...")
    try:
        proc = subprocess.run(
            ["node", str(server_js)],
            env={**__import__("os").environ, "AF_VM_PORT": str(port)},
            cwd=str(vm_dir),
        )
        raise typer.Exit(proc.returncode)
    except KeyboardInterrupt:
        typer.echo("\nServer stopped.")
