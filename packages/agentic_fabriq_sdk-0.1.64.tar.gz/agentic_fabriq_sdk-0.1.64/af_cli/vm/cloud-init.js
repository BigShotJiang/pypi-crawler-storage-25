"use strict";

/**
 * generateUserData — build a cloud-init #cloud-config YAML string.
 *
 * @param {object} opts
 * @param {string}   opts.sshPubKey      – ed25519 public key line
 * @param {Array<{hostPath:string,guestTag:string}>} opts.sharedFolders
 * @returns {string} YAML content
 */
function generateUserData({ sshPubKey, sharedFolders }) {
  // Build the fstab + mount runcmd lines for each shared folder
  const sharedFolderCmds = [];
  for (const { guestTag } of sharedFolders) {
    sharedFolderCmds.push(`  - mkdir -p /mnt/${guestTag}`);
    sharedFolderCmds.push(
      `  - echo '${guestTag} /mnt/${guestTag} 9p trans=virtio,version=9p2000.L,access=any,nofail 0 0' >> /etc/fstab`
    );
    sharedFolderCmds.push(`  - mount -a`);
  }

  const mcpJson = JSON.stringify({
    mcpServers: {
      "agentic-fabriq": {
        command: "afctl",
        args: ["broker"],
      },
    },
  });

  const yaml = `#cloud-config
users:
  - name: ubuntu
    sudo: ALL=(ALL) NOPASSWD:ALL
    shell: /bin/bash
    lock_passwd: false
    ssh_authorized_keys:
      - ${sshPubKey}

chpasswd:
  list: |
    ubuntu:ubuntu
  expire: false

ssh_pwauth: true

package_update: true

packages:
  - python3-pip
  - python3-venv
  - git
  - curl
  - build-essential

runcmd:
  - pip install agentic-fabriq-sdk
  - mkdir -p /home/ubuntu/.claude
  - echo '${mcpJson}' > /home/ubuntu/.claude/mcp.json
  - chown -R ubuntu:ubuntu /home/ubuntu/.claude
  - pip install keyrings.alt
  - mkdir -p /home/ubuntu/.config/python_keyring
  - echo '[backend]' > /home/ubuntu/.config/python_keyring/keyringrc.cfg
  - echo 'default-keyring=keyrings.alt.file.PlaintextKeyring' >> /home/ubuntu/.config/python_keyring/keyringrc.cfg
  - chown -R ubuntu:ubuntu /home/ubuntu/.config
  - mkdir -p /home/ubuntu/.ssh
  - chmod 700 /home/ubuntu/.ssh
  - chown ubuntu:ubuntu /home/ubuntu/.ssh
  - echo '${sshPubKey}' > /home/ubuntu/.ssh/authorized_keys
  - chmod 600 /home/ubuntu/.ssh/authorized_keys
  - chown ubuntu:ubuntu /home/ubuntu/.ssh/authorized_keys
${sharedFolderCmds.join("\n")}
`;

  return yaml;
}

/**
 * generateMetaData — build a cloud-init meta-data string.
 *
 * @param {string} vmId
 * @returns {string}
 */
function generateMetaData(vmId) {
  return `instance-id: ${vmId}\nlocal-hostname: af-vm-${vmId}\n`;
}

module.exports = { generateUserData, generateMetaData };
