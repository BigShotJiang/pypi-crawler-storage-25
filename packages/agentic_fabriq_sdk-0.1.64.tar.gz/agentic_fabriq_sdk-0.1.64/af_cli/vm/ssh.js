"use strict";

const os = require("os");
const path = require("path");
const fs = require("fs");
const { execSync } = require("child_process");
const net = require("net");

// Constants
const VMS_DIR = path.join(os.homedir(), ".af", "vms");
const SSH_DIR = path.join(os.homedir(), ".af", "vms", "ssh");
const SSH_KEY = path.join(os.homedir(), ".af", "vms", "ssh", "vm_ed25519");
const SSH_KEY_PUB = path.join(os.homedir(), ".af", "vms", "ssh", "vm_ed25519.pub");

/**
 * Ensure an SSH key exists, generating one if not. Returns the public key string.
 * @returns {string} Public key contents
 */
function ensureSSHKey() {
  if (!fs.existsSync(SSH_KEY)) {
    fs.mkdirSync(SSH_DIR, { recursive: true });
    execSync(
      `ssh-keygen -t ed25519 -f ${SSH_KEY} -N "" -C "af-vm"`,
      { stdio: "pipe" }
    );
    fs.chmodSync(SSH_KEY, 0o600);
  }
  return fs.readFileSync(SSH_KEY_PUB, "utf8");
}

/**
 * Return SSH connection info for a given port.
 * @param {number} sshPort
 * @returns {{ keyPath: string, pubKeyPath: string, user: string, host: string, sshPort: number, sshCommand: string }}
 */
function getSSHInfo(sshPort) {
  const keyPath = SSH_KEY;
  const pubKeyPath = SSH_KEY_PUB;
  const user = "ubuntu";
  const host = "127.0.0.1";
  const sshCommand = `ssh -i ${keyPath} -p ${sshPort} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ${user}@${host}`;
  return { keyPath, pubKeyPath, user, host, sshPort, sshCommand };
}

/**
 * Run an SSH command on the VM and return stdout, stderr, and exit code.
 * @param {string} command
 * @param {number} sshPort
 * @param {string} [user="ubuntu"]
 * @returns {{ stdout: string, stderr: string, code: number }}
 */
function runSSHCommand(command, sshPort, user = "ubuntu") {
  const host = "127.0.0.1";
  const sshArgs = [
    `ssh`,
    `-i ${SSH_KEY}`,
    `-p ${sshPort}`,
    `-o StrictHostKeyChecking=no`,
    `-o UserKnownHostsFile=/dev/null`,
    `${user}@${host}`,
    `"${command.replace(/"/g, '\\"')}"`,
  ].join(" ");

  try {
    const stdout = execSync(sshArgs, { encoding: "utf8", stdio: ["pipe", "pipe", "pipe"] });
    return { stdout: stdout || "", stderr: "", code: 0 };
  } catch (err) {
    return {
      stdout: err.stdout || "",
      stderr: err.stderr || err.message || "",
      code: err.status != null ? err.status : 1,
    };
  }
}

/**
 * Probe TCP reachability of host:port within a timeout.
 * @param {string} host
 * @param {number} port
 * @param {number} [timeoutMs=3000]
 * @returns {Promise<boolean>}
 */
function canReachSSH(host, port, timeoutMs = 3000) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port });
    let settled = false;

    const done = (result) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(result);
    };

    socket.setTimeout(timeoutMs);
    socket.on("connect", () => done(true));
    socket.on("timeout", () => done(false));
    socket.on("error", () => done(false));
  });
}

module.exports = {
  VMS_DIR,
  SSH_DIR,
  SSH_KEY,
  SSH_KEY_PUB,
  ensureSSHKey,
  getSSHInfo,
  runSSHCommand,
  canReachSSH,
};
