"use strict";

const os = require("os");
const path = require("path");
const fs = require("fs");
const https = require("https");
const http = require("http");
const { execSync } = require("child_process");

// Constants
const VMS_DIR = path.join(os.homedir(), ".af", "vms");
const IMAGES_DIR = path.join(os.homedir(), ".af", "vms", "images");

const IMAGE_CATALOG = [
  {
    id: "ubuntu-24.04-arm64",
    name: "Ubuntu 24.04 LTS (Noble)",
    arch: "aarch64",
    url: "https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-arm64.img",
    filename: "ubuntu-24.04-arm64",
    resizeTo: "20G",
    defaultMemoryGB: 8,
    defaultCpuCount: 4,
  },
];

// In-memory download state, keyed by image ID
const DOWNLOADS = {};

/**
 * Returns { qcow2: path } for a given image ID, or null if not in catalog.
 * @param {string} imageId
 * @returns {{ qcow2: string } | null}
 */
function imagePaths(imageId) {
  const entry = IMAGE_CATALOG.find((img) => img.id === imageId);
  if (!entry) return null;
  return {
    qcow2: path.join(IMAGES_DIR, entry.filename + ".qcow2"),
  };
}

/**
 * Returns current status of an image: in-flight from DOWNLOADS, filesystem check, or not-downloaded.
 * @param {string} imageId
 * @returns {{ status: string, progress: number|null, message: string|null }}
 */
function imageStatus(imageId) {
  // Check in-memory download state first
  if (DOWNLOADS[imageId]) {
    return { ...DOWNLOADS[imageId] };
  }

  // Check filesystem
  const paths = imagePaths(imageId);
  if (paths && fs.existsSync(paths.qcow2)) {
    return { status: "ready", progress: 100, message: null };
  }

  return { status: "not-downloaded", progress: null, message: null };
}

/**
 * Returns catalog with status merged in.
 * @returns {Array<object>}
 */
function listImages() {
  return IMAGE_CATALOG.map((img) => ({
    ...img,
    ...imageStatus(img.id),
  }));
}

/**
 * Downloads a file with redirect following (301/302/307/308).
 * Calls onProgress(pct, bytes, total). Returns Promise.
 * @param {string} url
 * @param {string} dest
 * @param {function} onProgress
 * @returns {Promise<void>}
 */
function downloadFile(url, dest, onProgress) {
  return new Promise((resolve, reject) => {
    function doRequest(requestUrl) {
      const parsed = new URL(requestUrl);
      const mod = parsed.protocol === "https:" ? https : http;

      mod
        .get(requestUrl, (res) => {
          // Follow redirects
          if (
            [301, 302, 307, 308].includes(res.statusCode) &&
            res.headers.location
          ) {
            const redirectUrl = new URL(res.headers.location, requestUrl).href;
            res.resume(); // drain response
            doRequest(redirectUrl);
            return;
          }

          if (res.statusCode !== 200) {
            reject(
              new Error(
                `Download failed: HTTP ${res.statusCode} for ${requestUrl}`
              )
            );
            return;
          }

          const total = parseInt(res.headers["content-length"] || "0", 10);
          let bytes = 0;

          const out = fs.createWriteStream(dest);
          res.on("data", (chunk) => {
            bytes += chunk.length;
            const pct = total > 0 ? Math.round((bytes / total) * 100) : 0;
            if (onProgress) onProgress(pct, bytes, total);
          });

          res.pipe(out);

          out.on("finish", () => {
            out.close(resolve);
          });

          out.on("error", (err) => {
            fs.unlink(dest, () => {});
            reject(err);
          });

          res.on("error", (err) => {
            out.destroy();
            fs.unlink(dest, () => {});
            reject(err);
          });
        })
        .on("error", reject);
    }

    doRequest(url);
  });
}

/**
 * Full download pipeline: set DOWNLOADS status to downloading, download file,
 * resize with qemu-img resize, set ready. On error: set error status, clean up partial files.
 * @param {string} imageId
 * @returns {Promise<void>}
 */
async function runDownloadPipeline(imageId) {
  const entry = IMAGE_CATALOG.find((img) => img.id === imageId);
  if (!entry) {
    throw new Error(`Unknown image ID: ${imageId}`);
  }

  const paths = imagePaths(imageId);
  const dest = paths.qcow2;

  // Ensure images directory exists
  fs.mkdirSync(IMAGES_DIR, { recursive: true });

  DOWNLOADS[imageId] = {
    status: "downloading",
    progress: 0,
    message: "Starting download...",
  };

  try {
    // Download the image
    await downloadFile(entry.url, dest, (pct, bytes, total) => {
      DOWNLOADS[imageId] = {
        status: "downloading",
        progress: pct,
        message: `Downloaded ${bytes} / ${total} bytes`,
      };
    });

    // Resize with qemu-img
    DOWNLOADS[imageId] = {
      status: "resizing",
      progress: 100,
      message: `Resizing image to ${entry.resizeTo}...`,
    };

    execSync(`qemu-img resize "${dest}" ${entry.resizeTo}`, { stdio: "pipe" });

    // Mark ready
    DOWNLOADS[imageId] = {
      status: "ready",
      progress: 100,
      message: null,
    };
  } catch (err) {
    // Set error status
    DOWNLOADS[imageId] = {
      status: "error",
      progress: null,
      message: err.message || String(err),
    };

    // Clean up partial file
    if (fs.existsSync(dest)) {
      fs.unlink(dest, () => {});
    }

    throw err;
  }
}

/**
 * Delete downloaded image file and clear DOWNLOADS entry.
 * @param {string} imageId
 * @returns {void}
 */
function deleteImage(imageId) {
  const paths = imagePaths(imageId);
  if (paths && fs.existsSync(paths.qcow2)) {
    fs.unlinkSync(paths.qcow2);
  }
  delete DOWNLOADS[imageId];
}

module.exports = {
  IMAGES_DIR,
  IMAGE_CATALOG,
  imagePaths,
  imageStatus,
  listImages,
  runDownloadPipeline,
  deleteImage,
};
