from pypile import EquipmentConfig
from pypile.core import SoilLayer, Borehole

rig_safety = EquipmentConfig(hammer_energy_ratio=0.60)
# 创建钻孔 BH25，地下水位 6.35m
BH25 = Borehole(water_table_depth=6.35, equipment=rig_safety)

# 0.00 - 1.50m: DARK GRAY Lean CLAY with shell (CL) - N=3 (1+2)
BH25.add_layer(SoilLayer(0.0, 1.5, 'clay', n_field=3, description="Lean CLAY with shell (CL)"))

# 1.50 - 3.00m: DARK GRAY Lean CLAY (CL) - N=2 (1+1)
BH25.add_layer(SoilLayer(1.5, 3.0, 'clay', n_field=2, description="Lean CLAY (CL)"))

# 3.00 - 4.50m: DARK GRAY Lean CLAY (CL) - N=2 (1+1)
BH25.add_layer(SoilLayer(3.0, 4.5, 'clay', n_field=2, description="Lean CLAY (CL)"))

# 4.50 - 6.00m: DARK GRAY Lean CLAY (CL) - N=3 (2+1)
BH25.add_layer(SoilLayer(4.5, 6.0, 'clay', n_field=3, description="Lean CLAY (CL)"))

# 6.00 - 7.50m: DARK GRAY Lean CLAY (CL) - N=4 (2+2)
BH25.add_layer(SoilLayer(6.0, 7.5, 'clay', n_field=4, description="Lean CLAY (CL)"))

# 7.50 - 9.00m: DARK GRAY Lean CLAY (CL) - N=3 (2+1)
BH25.add_layer(SoilLayer(7.5, 9.0, 'clay', n_field=3, description="Lean CLAY (CL)"))

# 9.00 - 10.50m: DARK GRAY Lean CLAY (CL) - N=4 (2+2)
BH25.add_layer(SoilLayer(9.0, 10.5, 'clay', n_field=4, description="Lean CLAY (CL)"))

# 10.50 - 12.00m: DARK GRAY Sandy Lean CLAY with shell (CL) - N=12 (5+7)
BH25.add_layer(SoilLayer(10.5, 12.0, 'clay', n_field=12, description="Sandy Lean CLAY with shell (CL)"))

# 12.00 - 13.50m: BROWNISH GRAY Silty SAND (SM) - N=43 (20+23)
BH25.add_layer(SoilLayer(12.0, 13.5, 'sand', n_field=43, description="Silty SAND (SM)"))

# --- 以下为 N>50 的硬土层，作为 IGM 处理 ---

# 13.50 - 15.00m: BROWNISH GRAY Silty SAND (SM) - N=51 (24+27)
BH25.add_layer(SoilLayer(13.5, 15.0, 'igm_sand', n_field=51, description="Silty SAND (SM), Very Dense"))

# 15.00 - 16.50m: BROWN Clayey SAND with gravel (SC) - N=57 (27+30)
BH25.add_layer(SoilLayer(15.0, 16.5, 'igm_sand', n_field=57, description="Clayey SAND with gravel (SC)"))

# 16.50 - 18.00m: BROWN Clayey SAND with gravel (SC) - N=61 (29+32)
BH25.add_layer(SoilLayer(16.5, 18.0, 'igm_sand', n_field=61, description="Clayey SAND with gravel (SC)"))

# 18.00 - 19.50m: DARK BROWN Silty SAND with gravel (SM) - N=64 (31+33)
BH25.add_layer(SoilLayer(18.0, 19.5, 'igm_sand', n_field=64, description="Silty SAND with gravel (SM)"))

# 19.50 - 21.00m: DARK BROWN Clayey SAND with gravel (SC) - N=67 (34+33)
BH25.add_layer(SoilLayer(19.5, 21.0, 'igm_sand', n_field=67, description="Clayey SAND with gravel (SC)"))

# 21.00 - 22.50m: DARK BROWN Clayey SAND with gravel (SC) - N=78 (39+39) -> 规范建议截断至60~80之间，保守取78
BH25.add_layer(SoilLayer(21.0, 22.5, 'igm_sand', n_field=78, description="Clayey SAND with gravel (SC)"))

# 22.50 - 24.00m: DARK BROWN Silty SAND with gravel (SM) - 击数 89/20cm，取等效 N=60
BH25.add_layer(SoilLayer(22.5, 24.0, 'igm_sand', n_field=60, description="Silty SAND with gravel (SM)"))

# 24.00 - 25.50m: DARK BROWN Silty SAND (SM) - 击数 50/12cm，取等效 N=60
BH25.add_layer(SoilLayer(24.0, 25.5, 'igm_sand', n_field=60, description="Silty SAND (SM)"))

# 25.50 - 27.00m: DARK BROWN Clayey SAND with gravel (SC) - 击数 95/20cm，取等效 N=60
BH25.add_layer(SoilLayer(25.5, 27.0, 'igm_sand', n_field=60, description="Clayey SAND with gravel (SC)"))

# 27.00 - 28.50m: DARK BROWN Silty SAND (SM) - 击数 50/10cm，取等效 N=60
BH25.add_layer(SoilLayer(27.0, 28.5, 'igm_sand', n_field=60, description="Silty SAND (SM)"))

# 28.50 - 29.78m: DARK BROWN Clayey SAND with gravel (SC) - 击数 50/8cm，孔底深度29.78m，取等效 N=60
BH25.add_layer(SoilLayer(28.5, 29.78, 'igm_sand', n_field=60, description="Clayey SAND with gravel (SC)"))