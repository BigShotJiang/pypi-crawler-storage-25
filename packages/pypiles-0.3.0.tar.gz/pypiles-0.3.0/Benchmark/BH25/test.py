from pypile.configs import EquipmentConfig, AnalysisConfig
from pypile.core import SoilLayer, Borehole, Pile
from pypile.solver import LRFDSolver

from BH25 import BH25


def run_analysis():
    # 4. 运行
    pile = Pile(diameter=2.5, length=45)
    solver = LRFDSolver(pile, BH25, config=AnalysisConfig())
    result = solver.solve()

    print(f"Capacity: {result['total_factored']:.2f} kN")


if __name__ == "__main__":
    run_analysis()
