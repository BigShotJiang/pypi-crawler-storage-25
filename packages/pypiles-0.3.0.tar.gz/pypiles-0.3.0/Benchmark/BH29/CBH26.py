from pypile.configs import AnalysisConfig
from pypile.core import SoilLayer, Borehole, Pile
import pandas as pd

def run_analysis():
    # 1. 规范版本
    rules = AnalysisConfig(ver=2024)
    # 2. 桩基配置
    pile = Pile(diameter=2.5, length=30.0, casing_length=15.0, casing_rf=0.6)
    # 3. 钻孔
    bh = Borehole(analys_config=rules, water_table_depth=0.0, hammer_energy_ratio=0.60, pile=pile)
    bh.add_layer(SoilLayer(1, 0, 1, 'sand', n_field=2, unit_weight=18))
    bh.add_layer(SoilLayer(2, 1, 2, 'sand', n_field=2, unit_weight=18))
    bh.add_layer(SoilLayer(3, 2, 3, 'clay', n_field=3, unit_weight=16, su=18))
    bh.add_layer(SoilLayer(4, 3, 4, 'sand', n_field=3, unit_weight=18))
    bh.add_layer(SoilLayer(5, 4, 5, 'sand', n_field=3, unit_weight=18))
    bh.add_layer(SoilLayer(6, 5, 6, 'clay', n_field=6, unit_weight=16, su=36))
    for tep in range(30):
        bh.add_layer(SoilLayer(7 + tep, 6 + tep, 7 + tep, 'sand', n_field=50, unit_weight=19))

    df1 = bh.report_layers()
    df2 = bh.report_compress_result()

    file_path = 'ResBH29-D2.5.xlsx'
    with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
        # 将 df1 写入名为 'Layers' 的 sheet 中
        df1.to_excel(writer, sheet_name='Layers', index=False)
        # 将 df2 写入名为 'Compress_Result' 的 sheet 中
        df2.to_excel(writer, sheet_name='Compress_Result', index=False)
    print(f"数据已成功保存至 {file_path}")


if __name__ == "__main__":
    run_analysis()
