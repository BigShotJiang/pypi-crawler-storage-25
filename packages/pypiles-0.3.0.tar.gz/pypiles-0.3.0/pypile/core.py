# pypile/core.py
import copy
import math
import warnings
from dataclasses import dataclass, field
from typing import List, Dict
import pandas as pd
import numpy as np

from .configs import AnalysisConfig, SoilType, ksf2kpa, kpa2ksf


@dataclass
class SoilLayer:
    id: int
    z_top: float
    z_bot: float
    soil_type: str
    z_top: float
    z_bot: float
    soil_type: SoilType
    n_field: int  # Raw SPT from field log
    unit_weight: float
    # --- 静态衍生属性 (在 __post_init__ 中计算) ---
    z_mid: float = field(init=False)
    depth: float = field(init=False)

    # --- 动态衍生属性 (需要外部 Borehole 上下文，后续计算) ---
    description: str = ""
    basic_paras: List[str] = field(default_factory=list, init=False)
    base_info: str = ""
    base_dict: Dict = field(default_factory=dict, init=False)
    factor_info: str = ""

    n60: float = field(init=False)
    nl60: float = field(init=False)
    nl: float = field(init=False)
    su: float = field(default=None)

    alpha: float = field(default=None)
    beta: float = field(default=None)
    ss_water: float = field(default=None)  # 孔隙水压力
    ss_mid: float = field(default=None)  # 中点总应力
    ss_bot: float = field(default=None)  # 底点总应力
    ss_mid_eff: float = field(default=None)  # 中点总有效应力
    ss_bot_eff: float = field(default=None)  # 中点总有效应力
    qs: float = field(default=None)
    qp: float = field(default=None)
    Rs: float = field(default=None)
    Rp: float = field(default=None)
    phi_s: float = field(default=None)
    phi_p: float = field(default=None)
    Rsn: float = field(default=None)
    Rpn: float = field(default=None)

    def __repr__(self):
        # 如果 description 已经生成了，就直接打印它
        if getattr(self, 'description', ""):
            return self.description
        # 如果还没调用 calculate_properties，就给个简短的备用提示
        return f"SoilLayer({self.z_top}m-{self.z_bot}m, {self.soil_type})"

    def __post_init__(self):
        self.depth = self.z_bot - self.z_top
        self.z_mid = (self.z_top + self.z_bot) / 2
        self.base_info = f"[{self.z_top:.1f}m - {self.z_bot:.1f}m] {self.soil_type.upper()}"
        self.base_dict = {'id': self.id, 'z_top': self.z_top, 'z_bot': self.z_bot, 'soil_type': self.soil_type}
        # 2. 基本合法性校验
        if self.depth <= 0:
            raise ValueError(f"层厚必须大于0！检查深度设置: {self.z_top} -> {self.z_bot}")

        # 3. 业务逻辑的“条件性必填”校验 (Fail Fast)
        if self.soil_type in ['clay', 'igm_clay']:
            if self.su is None:
                raise ValueError(
                    f"土层 [{self.z_top}m - {self.z_bot}m] 被定义为 {self.soil_type}，"
                    f"必须提供不排水抗剪强度 'su'！"
                )

        # 4. [可选的防御性编程] 如果是砂土，但用户手滑填了 su，我们可以静默清除或发出警告
        elif self.soil_type in ['sand', 'clean_sand', 'gravel']:
            if self.su is not None:
                # 可以选择抛出警告，或者直接把它设回 None 以防后续逻辑混乱
                warnings.warn(
                    f"土层 [{self.z_top}m - {self.z_bot}m] 被定义为 {self.soil_type}，"
                    f"不应设置不排水抗剪强度 'su'！"
                )
            self.su = 0.0
        self.basic_paras = ['n_field', 'n60', 'unit_weight', 'ss_mid_eff', 'su', 'alpha', 'beta', 'qs', 'qp']
        self.compression_results = ['phi_s', 'phi_p', 'Rs', 'Rp', 'Rsn', 'Rpn']

    def calculate_properties(self, borehole: 'Borehole'):
        """
        """

        sum_sigma_vertical = borehole.s_bot_sum
        code = borehole.config
        info = self.factor_info
        # 应力计算
        if self.z_mid >= borehole.gwt:
            self.ss_water = code.water_unit_weight * (self.z_mid - borehole.gwt)
        else:
            self.ss_water = 0.0
        self.ss_mid = sum_sigma_vertical + self.depth * 0.5 * self.unit_weight
        self.ss_bot = sum_sigma_vertical + self.depth * self.unit_weight
        self.ss_mid_eff = self.ss_mid - self.ss_water
        self.ss_bot_eff = self.ss_bot - code.water_unit_weight * (self.z_bot - borehole.gwt)

        # SPT修正 ---------------------------------------------------------------
        cn = max(2.0, 0.77 * math.log10(40 / kpa2ksf(self.ss_mid)))
        self.nl = cn * self.n_field
        self.n60 = (borehole.hammer_er / 0.6) * self.n_field
        self.nl60 = cn * self.n60
        casing_l = borehole.pile.casing_length
        casing_rf = borehole.pile.casing_rf
        pile_dia = borehole.pile.diameter
        # 粘性土 ---------------------------------------------------------------
        if self.soil_type in ['clay', 'igm_clay']:
            assert self.su is not None
            self.alpha = code.get_alpha(self.su)
            self.qs = code.get_qs_clay(self.alpha, self.su, self.z_mid, casing_l, casing_rf, info)
            self.qp = code.get_qp_clay(self.su, pile_dia, self.z_bot, info)
            # 端阻
        # 非粘性土 ---------------------------------------------------------------
        elif self.soil_type in ['sand']:
            self.beta = code.get_beta(self.soil_type, self.n60, self.nl60, self.ss_mid_eff, self.z_mid, info)
            self.qs = code.get_qs_sand(self.beta, self.ss_mid_eff, self.z_mid, casing_l, casing_rf, info)
            self.qp = code.get_qp_sand(self.n60, self.ss_bot_eff)
        # 侧阻 ---------------------------------------------------------------
        s_area = pile_dia * np.pi * self.depth
        p_area = np.pi * pile_dia ** 2 * 0.25
        self.Rs = self.qs * s_area
        self.Rp = self.qp * p_area
        self.phi_s = code.get_phi_s(self.soil_type)
        self.phi_p = code.get_phi_p(self.soil_type)
        self.Rsn = self.phi_s * self.Rs
        self.Rpn = self.phi_p * self.Rp
        # 端阻 ---------------------------------------------------------------

        # output
        details = []
        for para_name in self.basic_paras:
            val = getattr(self, para_name, None)
            if val is not None:
                details.append(f"{para_name}={val:.2f}")
        self.description = f"{self.base_info} | " + " | ".join(details)
        pass


@dataclass
class Pile:
    diameter: float
    length: float
    casing_length: float
    casing_rf: float = 0.6
    cutoff_level: float = 0.0

    @property
    def perimeter(self):
        import math
        return math.pi * self.diameter

    @property
    def area(self):
        import math
        return math.pi * (self.diameter / 2) ** 2


class Borehole:
    def __init__(self, analys_config: AnalysisConfig,
                 pile: Pile,
                 water_table_depth: float,
                 hammer_energy_ratio: float):
        """

        """
        self.config = analys_config
        self.gwt = water_table_depth
        self.pile = pile
        self.layers: List[SoilLayer] = []
        self.bottom_depth = 0
        self.s_bot_sum = 0
        self.hammer_er = hammer_energy_ratio

    def add_layer(self, layer: SoilLayer):
        if self.layers:
            assert layer.z_top == self.layers[-1].z_bot
        layer.calculate_properties(self)
        self.layers.append(layer)
        self.s_bot_sum = layer.ss_bot

    def get_layer_at_depth(self, z: float) -> SoilLayer | None:
        for layer in self.layers:
            if layer.z_top <= z <= layer.z_bot:
                return layer
        return None

    def report_layers(self) -> 'pd.DataFrame':
        ret = []
        paras = self.layers[0].basic_paras
        for i, ly in enumerate(self.layers):
            details = copy.deepcopy(ly.base_dict)
            for para_name in paras:
                val = getattr(ly, para_name, None)
                details[para_name] = val
            ret.append(details)
        df = pd.DataFrame(ret)
        return df

    def report_compress_result(self):
        ret = []
        paras = self.layers[0].compression_results
        for i, ly in enumerate(self.layers):
            details = copy.deepcopy(ly.base_dict)
            for para_name in paras:
                val = getattr(ly, para_name, None)
                details[para_name] = val
            ret.append(details)
        df = pd.DataFrame(ret)
        df['TotalRsn'] = df['Rsn'].cumsum()
        return df


@dataclass
class CompressiveResistanceRecord:
    pile: Pile
    layer: SoilLayer
    step: float
    qs: float
    phi_side: float
    qp: float
    phi_tip: float

    @property
    def Rsn(self) -> float:
        # 侧摩阻力标准值 (Nominal Side Resistance) = qs * 桩周长 * 穿越该土层的长度
        # 假设该记录代表桩在该土层全长范围内的摩阻力，使用 layer.depth
        return self.qs * self.pile.perimeter * self.step

    @property
    def Rsr(self) -> float:
        # 侧摩阻力设计值 (Factored Side Resistance)
        return self.Rsn * self.phi_side

    @property
    def Rpn(self) -> float:
        # 端阻力标准值 (Nominal Tip Resistance) = qp * 桩截面积
        return self.qp * self.pile.area

    @property
    def Rpr(self) -> float:
        # 端阻力设计值 (Factored Tip Resistance)
        return self.Rpn * self.phi_tip

    @property
    def description(self) -> str:
        # 每次访问 description 时，都会动态获取最新的计算结果
        details = []
        display_params = ['qs', 'phi_side', 'qp', 'phi_tip', 'Rsn', 'Rsr', 'Rpn', 'Rpr']

        for para_name in display_params:
            val = getattr(self, para_name, None)
            if val is not None and isinstance(val, (int, float)):
                details.append(f"{para_name}={val:.2f}")

        return f"{self.layer.base_info} | " + " | ".join(details)

    def __repr__(self):
        # 打印对象时直接输出动态计算的 description
        return self.description
