from .core import SoilLayer, Borehole, Pile
from .configs import AnalysisConfig
from .solver import LRFDSolver

# --- 智能版本号处理 ---
try:
    # 尝试读取 setuptools_scm 自动生成的文件
    from ._version import version as __version__
except ImportError:
    # 如果文件不存在（比如你刚 clone 下来，还没 pip install），
    # 或者你在纯源码模式下开发，
    # 我们给它一个默认的开发占位符，防止代码报错。
    __version__ = "0.0.0.dev0+unknown"

__all__ = [
    "SoilLayer",
    "Borehole",
    "Pile",
    "AnalysisConfig",
    "LRFDSolver",
    "__version__"
]