# pypile/correlations.py
import math


class Correlations:
    @staticmethod
    def correct_n60(n_field: int, energy_ratio: float = 0.8) -> float:
        """Correct field N-value to N60."""
        return (energy_ratio / 0.60) * n_field

    @staticmethod
    def estimate_unit_weight(n60: float, soil_type: str) -> float:
        """Estimate saturated unit weight (kN/m3)."""
        if n60 < 4: return 16.0
        if n60 < 10: return 17.5
        if n60 < 30: return 19.0
        if n60 < 50: return 20.0
        return 21.0

    @staticmethod
    def estimate_friction_angle(n60: float) -> float:
        """Wolff (1989) correlation for sands."""
        n_corr = min(n60, 55)
        phi = 27.1 + 0.3 * n_corr - 0.00054 * (n_corr ** 2)
        return min(phi, 40.0)

    @staticmethod
    def estimate_su(n60: float) -> float:
        """Stroud (1974) correlation for clays (kPa)."""
        return 5.0 * n60

    # @staticmethod
    # def estimate_beta(z: float) -> float:
    #     """
    #     Calculate Beta factor for side resistance in sand.
    #     Ref: AASHTO Eq. 10.8.3.5.2b-2 (Simplified O'Neill & Reese)
    #     beta = 1.5 - 0.135 * sqrt(z)
    #     Range: 0.25 <= beta <= 1.2
    #     """
    #     if z <= 0:
    #         return 1.5
    #     else:
    #         beta = 1.5 - 0.135 * math.sqrt(z)
    #     return max(0.25, min(beta, 1.2))

    @staticmethod
    def estimate_sand_tip_limit(n60: float, pa: float) -> float:
        """
        Calculate nominal unit tip resistance for sand.
        Ref: AASHTO Eq. 10.8.3.5.2c-1
        qp = 0.6 * N60 * Pa
        """
        return 0.6 * n60 * pa