# Benchmark Case 1: Stratified Soil Profile (Clay-Sand-IGM)

**Status:** ✅ Verified  
**Standard:** AASHTO LRFD 9th Edition / FHWA-NHI-10-016  
**Method:** Static Analysis ($\alpha$-Method, $\beta$-Method, IGM)

## 1. Problem Statement

This benchmark verifies the solver's ability to handle a multi-layer soil system containing:
1.  **Zone of Neglect:** A top layer of soft clay that should be ignored in resistance calculations.
2.  **Beta Method:** A standard sand layer using effective stress analysis.
3.  **IGM (Intermediate Geomaterial):** A deep hard layer ($N_{60} > 50$) utilizing high-value resistance correlations.
4.  **Limits Check:** Verification of nominal resistance caps (Side $\le$ 192 kPa, Tip $\le$ 3000 MPa).

### 1.1 Model Geometry
* **Pile Type:** Drilled Shaft (Bored Pile)
* **Diameter ($D$):** 1.0 m
* **Length ($L$):** 20.0 m
* **Groundwater Table:** At Surface (0.0 m)

### 1.2 Soil Profile
| Layer | Depth (m) | Soil Type | SPT $N_{60}$ | Unit Weight $\gamma$ (kN/m³) | $S_u$ (kPa) | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **1** | 0.0 - 6.0 | Clay | 4 | 17.0 | 30 | Soft, to be neglected |
| **2** | 6.0 - 15.0 | Sand | 20 | 19.0 | - | Medium Dense |
| **3** | 15.0 - 30.0 | IGM/Sand | 60 | 21.0 | - | Very Dense ($N>50$) |

---

## 2. Manual Calculation (Step-by-Step)

Calculations are based on AASHTO LRFD Bridge Design Specifications (9th Ed.) and FHWA guidelines.

### Step 1: Layer 1 (0.0 - 6.0m) - Soft Clay
* **Method:** $\alpha$-Method (AASHTO 10.8.3.5.1b)
* **Condition:** $N_{60} = 4 < 5$.
* **Logic:** According to AASHTO, resistance in the top 1.5m and in very soft layers should be neglected ("Zone of Neglect").
* **Nominal Side Resistance ($R_{s1}$):** **0 kN**

### Step 2: Layer 2 (6.0 - 15.0m) - Medium Sand
* **Method:** $\beta$-Method (AASHTO 10.8.3.5.2b)
* **Thickness:** 9.0 m
* **Midpoint Depth ($z$):** $6.0 + 9.0/2 = 10.5$ m
* **Effective Stress ($\sigma'_v$) at 10.5m:**
    * Overburden Layer 1: $6.0 \times (17.0 - 9.81) = 43.14$ kPa
    * Layer 2 Increment: $4.5 \times (19.0 - 9.81) = 41.36$ kPa
    * Total $\sigma'_v = 84.5$ kPa
* **Beta Factor ($\beta$):**
    $$\beta \approx 1.5 - 0.135\sqrt{z} = 1.5 - 0.135\sqrt{10.5} = 1.063$$
    *(Check limits: $0.25 \le 1.063 \le 1.2$ -> OK)*
* **Unit Side Resistance ($f_s$):**
    $$f_s = \beta \cdot \sigma'_v = 1.063 \times 84.5 = 89.8 \text{ kPa}$$
    *(Check limit: $89.8 \le 192 \text{ kPa}$ -> OK)*
* **Layer Resistance ($R_{s2}$):**
    $$R_{s2} = f_s \cdot (\pi \cdot D \cdot \Delta L) = 89.8 \cdot (\pi \cdot 1.0 \cdot 9.0) \approx \mathbf{2,539 \text{ kN}}$$

### Step 3: Layer 3 (15.0 - 20.0m) - Very Dense Sand (IGM)
* **Method:** IGM / High N Correlation (FHWA/AASHTO)
* **Segment Length:** $20.0 - 15.0 = 5.0$ m (Pile ends at 20m)
* **Midpoint Depth ($z$):** $17.5$ m
* **Unit Side Resistance ($f_s$):**
    For $N_{60}=60$, we use the direct correlation for IGMs:
    $$f_s \approx 2.0 \cdot N_{60} = 2.0 \cdot 60 = 120 \text{ kPa}$$
    *(Alternatively using Beta method would yield lower values, but IGM logic governs high N)*.
* **Layer Resistance ($R_{s3}$):**
    $$R_{s3} = 120 \cdot (\pi \cdot 1.0 \cdot 5.0) \approx \mathbf{1,885 \text{ kN}}$$

### Step 4: Tip Resistance (at 20.0m)
* **Soil:** Very Dense Sand ($N_{60}=60$)
* **Method:** AASHTO 10.8.3.5.2c
* **Unit Tip Resistance ($q_p$):**
    $$q_p = 0.6 \cdot N_{60} \cdot p_a = 0.6 \cdot 60 \cdot 100 = 3,600 \text{ kPa}$$
* **Limit Check:**
    $$q_p \le 3,000 \text{ kPa (Standard Limit)}$$
    Therefore, use $q_p = 3,000$ kPa.
* **Total Tip Resistance ($R_p$):**
    $$R_p = q_p \cdot Area = 3,000 \cdot (\pi \cdot 0.5^2) \approx \mathbf{2,356 \text{ kN}}$$

---

## 3. Results Summary

| Component | Manual Calc (kN) | PyPile Expected (kN) | Note |
| :--- | :--- | :--- | :--- |
| **Side Resistance (Clay)** | 0 | 0 | Neglected |
| **Side Resistance (Sand)** | 2,539 | ~2,539 | $\pm$ 5% due to integration steps |
| **Side Resistance (IGM)** | 1,885 | ~1,885 | $\pm$ 5% due to integration steps |
| **Tip Resistance** | 2,356 | 2,356 | Limited to 3.0 MPa |
| **TOTAL NOMINAL** | **6,780** | **~6,780** | |

---

## 4. How to Run Verification

Ensure you are in the root directory of `PyPile`.

```bash
python -m unittest tests/Benchmark-1/test_case_01.py