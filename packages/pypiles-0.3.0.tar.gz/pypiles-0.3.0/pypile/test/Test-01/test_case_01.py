import unittest
from pypile.core import SoilLayer, Borehole, Pile
from pypile.solver import LRFDSolver
# [UPDATED] 引入新的配置类
from pypile.configs import AnalysisConfig, EquipmentConfig


class TestPyPileBenchmark(unittest.TestCase):
    """
    Benchmark Test based on manual calculation.
    """

    def setUp(self):
        # --- 1. Define Equipment (The Key Fix) ---
        # 手算基准假设 N_field 直接等于 N_60。
        # 在物理上，这意味着使用的是老式的 "Safety Hammer" (效率 ~60%)。
        # 设置 hammer_energy_ratio=0.60 后，修正系数 = 0.6/0.6 = 1.0。
        # 这样我们就可以直接输入原始 N 值 (4, 20, 60)，无需人工换算。
        self.rig_safety = EquipmentConfig(hammer_energy_ratio=0.60)

        # --- 2. Setup Borehole ---
        # 将设备参数注入钻孔
        self.bh = Borehole(water_table_depth=0.0, equipment=self.rig_safety)

        # Layer 1: Soft Clay (0-6m)
        # Input N=4 -> N60=4. (Neglected < 5)
        self.bh.add_layer(SoilLayer(0.0, 6.0, 'clay', n_field=4, unit_weight=17.0, su=30.0))

        # Layer 2: Medium Sand (6-15m)
        # Input N=20 -> N60=20.
        self.bh.add_layer(SoilLayer(6.0, 15.0, 'sand', n_field=20, unit_weight=19.0))

        # Layer 3: IGM / Very Dense Sand (15-30m)
        # Input N=60 -> N60=60.
        self.bh.add_layer(SoilLayer(15.0, 30.0, 'igm_sand', n_field=60, unit_weight=21.0))

        self.pile = Pile(diameter=1.0, length=20.0)

        # --- 3. Analysis Config ---
        # 使用标准 AASHTO 规则
        self.config = AnalysisConfig()

    def test_benchmark_calculation(self):
        # Solver 现在只需要 AnalysisConfig，不需要管设备细节
        solver = LRFDSolver(self.pile, self.bh, self.config)
        result = solver.solve(step=0.1)

        # --- Expected Manual Values ---
        # Side: 0 (Clay) + 2539 (Sand) + 1885 (IGM) = 4424 kN
        expected_side = 4424.0

        # Tip: 2356 kN
        expected_tip = 2356.0

        print(f"\nBenchmark Check (Using ER=0.60 Safety Hammer):")
        print(f"Manual Side: {expected_side:.0f} kN | Software Side: {result['side_nominal']:.0f} kN")
        print(f"Manual Tip:  {expected_tip:.0f} kN | Software Tip:  {result['tip_nominal']:.0f} kN")

        # Use 2% tolerance (integration steps vs midpoint formula)
        self.assertAlmostEqual(result['side_nominal'], expected_side, delta=expected_side * 0.02)
        self.assertAlmostEqual(result['tip_nominal'], expected_tip, delta=expected_tip * 0.02)


if __name__ == '__main__':
    unittest.main()