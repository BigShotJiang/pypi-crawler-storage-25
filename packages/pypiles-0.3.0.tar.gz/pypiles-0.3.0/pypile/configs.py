# pypile/configs.py
import math
import warnings
from dataclasses import dataclass, field
from typing import List, Literal


def m2ft(val: float) -> float:
    return val / 0.3048


def ksf2kpa(val: float) -> float:
    return val * 47.8803


def kpa2ksf(val: float) -> float:
    return val / 47.8803


SoilType = Literal['sand', 'clean_sand', 'gravel', 'clay', 'igm_sand', 'igm_clay']


# @dataclass
# class EquipmentConfig:
#     """
#     Physical parameters related to the site and drilling equipment.
#     These define WHAT the soil is.
#     """
#     # Hammer Energy Efficiency (ER).
#     # Automatic Trip Hammer: 0.80 - 0.90
#     # Safety Hammer: 0.60
#     hammer_energy_ratio: float = 0.80


@dataclass
class AnalysisConfig:
    """
    Calculation rules and limits.
    These define HOW we calculate capacity.
    """
    # Ver
    ver: int = 2024
    # Site constants
    g: float = 9.81
    water_unit_weight: float = 9.8
    pa: float = 100.0
    casing_ft: float = 0.65

    phi_side_clay: float = field(default=None)
    phi_side_sand: float = field(default=None)
    phi_side_igm: float = field(default=None)
    phi_tip_clay: float = field(default=None)
    phi_tip_sand: float = field(default=None)
    phi_tip_igm: float = field(default=None)

    def __post_init__(self):
        if self.ver == 2024 or self.ver == 2012:
            # Table 10.5.5.2.4-1—Resistance Factors for Geotechnical Resistance of Drilled Shafts
            self.phi_side_clay: float = 0.45
            self.phi_tip_clay: float = 0.40
            self.phi_side_sand: float = 0.55
            self.phi_tip_sand: float = 0.50
            self.phi_side_igm: float = 0.60
            self.phi_tip_igm: float = 0.55
        else:
            raise NotImplementedError

    def get_alpha(self, su):
        if self.ver == 2024 or self.ver == 2012:
            return self._get_alpha_2024(su)
        else:
            raise NotImplementedError

    def get_beta(self, soil_type, n60, nl60, sigma_eff_mid, z0, info):
        if self.ver == 2024:
            return self._get_beta_2024(soil_type, n60, nl60, sigma_eff_mid, info)
        elif self.ver == 2012:
            return self._get_beta_2012(soil_type, n60, z0)
        else:
            raise NotImplementedError

    def get_qs_sand(self, beta, ss_mid_eff, z_mid, casing_length, casing_ft, factor_info):
        if self.ver == 2024:
            return self._get_qs_sand_2024(beta, ss_mid_eff, z_mid, casing_length, casing_ft, factor_info)
        elif self.ver == 2012:
            return self._get_qs_sand_2012(beta, ss_mid_eff, z_mid, casing_length, casing_ft, factor_info)
        else:
            raise NotImplementedError

    def get_qp_sand(self, n60, ss_bot_eff):
        if self.ver == 2024:
            return self._get_qp_sand_2024(n60)
        elif self.ver == 2012:
            return self._get_qp_sand_2012(n60, ss_bot_eff)
        else:
            raise NotImplementedError

    def get_qs_clay(self, alpha, su, z_mid, casing_length, casing_ft, factor_info):
        if self.ver == 2024 or self.ver == 2012:
            qs = alpha * su
            if z_mid <= 1.5:
                qs = 0.0
                factor_info += "0.0 (top 5ft), "
            if z_mid <= casing_length:
                qs *= casing_ft
                factor_info += "0.6 (casing reduction factor), "
        else:
            raise NotImplementedError
        return qs

    def get_qp_clay(self, su, pile_dia, z_bot, factor_info):
        if self.ver == 2024 or self.ver == 2012:
            return self._get_qp_clay_2024(su, pile_dia, z_bot, factor_info)
        else:
            raise NotImplementedError

    @staticmethod
    def _get_beta_2024(soil_type, n60, nl60, sigma_eff_mid, info):
        phi = 27.5 + 9.2 * math.log10(nl60)
        if soil_type == 'sand':
            pre_con_stress = ksf2kpa(0.47 * math.pow(n60, 0.8) * 2.12)
        elif soil_type == 'clean_sand':
            pre_con_stress = ksf2kpa(0.47 * math.pow(n60, 0.6) * 2.12)
        elif soil_type == 'gravel':
            pre_con_stress = ksf2kpa(0.15 * n60 * 2.12)
        else:
            raise NotImplementedError
        sin_phi = math.sin(math.radians(phi))
        tan_phi = math.tan(math.radians(phi))
        beta = (1 - sin_phi) * math.pow(pre_con_stress / sigma_eff_mid, sin_phi) * tan_phi
        return beta

    @staticmethod
    def _get_qs_sand_2024(beta, ss_mid_eff, z_mid, casing_length, casing_ft, factor_info):
        qs = beta * ss_mid_eff
        if z_mid <= 1.5:
            qs = 0.0
            factor_info += "0.0 (top 5ft), "
        if z_mid <= casing_length:
            qs *= casing_ft
            factor_info += "0.6 (casing reduction factor), "
        return qs

    @staticmethod
    def _get_qs_sand_2012(beta, ss_mid_eff, z_mid, casing_length, casing_ft, factor_info):
        qs = beta * ss_mid_eff
        if z_mid <= 1.5:
            qs = 0.0
            factor_info += "0.0 (top 5ft), "
        if z_mid <= casing_length:
            qs *= casing_ft
            factor_info += "0.6 (casing reduction factor), "
        return min(beta * ss_mid_eff, ksf2kpa(4.0))

    @staticmethod
    def _get_beta_2012(soil_type, n60, z0):
        if soil_type == 'sand' or soil_type == 'clean_sand':
            if n60 >= 15:
                beta = 1.5 - 0.135 * math.sqrt(m2ft(z0))
            else:
                beta = n60 / 15 * (1.5 - 0.135 * math.sqrt(m2ft(z0)))
        elif soil_type == 'gravel':
            if n60 >= 15:
                beta = 2.0 - 0.06 * math.pow(m2ft(z0), 0.75)
            else:
                beta = n60 / 15 * (1.5 - 0.135 * math.sqrt(m2ft(z0)))
        else:
            raise NotImplementedError
        if beta > 1.2:
            warnings.warn("beta > 1.2，强制调整为1.2")
            beta = 1.2
        if beta < 0.25:
            beta = 0.25
        return beta

    @staticmethod
    def _get_alpha_2024(su):
        var_b = kpa2ksf(su) / 2.12
        if var_b <= 1.5:
            alpha = 0.55
        elif var_b <= 2.5:
            alpha = 0.55 - 0.1 * (var_b - 1.5)
        else:
            raise ValueError(f"{su}, Su不应大于大气压的2.5倍！")
        return alpha

    @staticmethod
    def _get_qp_sand_2012(n60, ss_bot_eff):
        if n60 <= 50:
            qp = ksf2kpa(min(60.0, 1.2 * n60))
        else:
            warnings.warn("\n 修正后的N60>50,12版桩尖承载力公式过于保守，请核查！")
            n60 = min(100.0, n60)
            var_a = math.pow(n60 * (2.12 / kpa2ksf(ss_bot_eff)), 0.8)
            qp = 0.59 * var_a * ss_bot_eff
        return qp

    @staticmethod
    def _get_qp_sand_2024(n60):
        if n60 <= 50:
            qp = ksf2kpa(min(60.0, 1.2 * n60))
        else:
            qp = ksf2kpa(60)
            warnings.warn("沙土超过50SPT.")
        return qp

    @staticmethod
    def _get_qp_clay_2024(su, pile_dia, z_bot, factor_info):
        nc = min(6 * (1 + 0.2 * (z_bot / pile_dia)), 9)
        if kpa2ksf(su) < 0.5:
            tmp_ft = 0.67
            factor_info += "0.67 (low Su reduction factor), "
        else:
            tmp_ft = 1.0
        nc = nc * tmp_ft
        qp = min(ksf2kpa(80), nc * su)
        return qp

    @staticmethod
    def get_phi_s(soil_type):
        if soil_type == 'sand' or soil_type == 'clean_sand' or soil_type == 'gravel':
            return 0.55
        elif soil_type == 'clay':
            return 0.45
        else:
            raise NotImplementedError

    @staticmethod
    def get_phi_p(soil_type):
        if soil_type == 'sand' or soil_type == 'clean_sand' or soil_type == 'gravel':
            return 0.50
        elif soil_type == 'clay':
            return 0.40
        else:
            raise NotImplementedError
