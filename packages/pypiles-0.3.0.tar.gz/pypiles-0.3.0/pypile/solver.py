# pypile/solver.py
import math
from .core import Pile, Borehole, CompressiveResistanceRecord
from .configs import AnalysisConfig


class LRFDSolver:
    def __init__(self, pile: Pile, borehole: Borehole, config: AnalysisConfig):
        self.pile = pile
        self.borehole = borehole
        self.config = config
        self.compression_results = []

    def solve(self, step=1.0):
        current_depth = self.pile.cutoff_level
        toe_depth = self.pile.cutoff_level + self.pile.length

        total_side_n = 0.0
        total_side_r = 0.0

        while current_depth < toe_depth:
            actual_step = min(step, toe_depth - current_depth)
            z_mid = current_depth + actual_step / 2
            is_casing = z_mid <= self.pile.casing_length
            layer = self.borehole.get_layer_at_depth(z_mid)
            if not layer:
                current_depth += actual_step
                continue

            f_s = layer.qs
            if z_mid < 1.5:
                f_s = 0.0
            if layer.soil_type in ['clay', 'igm_clay']:
                phi_factor = self.config.phi_side_clay

            elif layer.soil_type in ['sand', 'clean_sand']:
                phi_factor = self.config.phi_side_sand
            elif 'igm' in layer.soil_type:
                phi_factor = self.config.phi_side_igm
            else:
                raise NotImplementedError
            # 面积积分
            area_side = self.pile.perimeter * actual_step
            if is_casing:
                # total_side_n += f_s * area_side * self.config.casing_ft
                # total_side_r += f_s * area_side * phi_factor * self.config.casing_ft
                qs_final = f_s * self.config.casing_ft
            else:
                qs_final = f_s
                # total_side_n += f_s * area_side
                # total_side_r += f_s * area_side * phi_factor
            rn = area_side * qs_final
            rr = area_side * qs_final * phi_factor
            total_side_n += rn
            total_side_r += rr
            res = CompressiveResistanceRecord(
                pile=self.pile, layer=layer, step=actual_step,
                qs=qs_final,
                phi_side=phi_factor,
                qp=0,
                phi_tip=0,
            )
            self.compression_results.append(res)
            current_depth += actual_step

        # --- 2. Tip Resistance (直接从 core 中读取) ---
        toe_layer = self.borehole.get_layer_at_depth(toe_depth)
        r_tip_n = 0.0
        r_tip_r = 0.0

        if toe_layer:
            q_p = toe_layer.qp
            if toe_layer.soil_type in ['sand', 'clean_sand']:
                phi_tip = self.config.phi_tip_sand
            elif toe_layer.soil_type in ['clay', 'igm_clay']:
                phi_tip = self.config.phi_tip_clay
            elif 'igm' in toe_layer.soil_type:
                phi_tip = self.config.phi_tip_igm
            else:
                raise NotImplementedError
            r_tip_n = q_p * self.pile.area
            r_tip_r = r_tip_n * phi_tip
            self.compression_results[-1].qp = q_p
            self.compression_results[-1].phi_tip = phi_tip
        return {
            "side_nominal": total_side_n,
            "side_factored": total_side_r,
            "tip_nominal": r_tip_n,
            "tip_factored": r_tip_r,
            "total_factored": total_side_r + r_tip_r
        }
