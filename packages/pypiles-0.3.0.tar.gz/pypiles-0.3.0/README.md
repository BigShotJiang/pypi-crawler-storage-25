# PyPile: AASHTO LRFD Drilled Shaft Analysis

![Python Version](https://img.shields.io/badge/python-3.8%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Standard](https://img.shields.io/badge/AASHTO-LRFD%209th-orange)

**PyPile** 是一个模块化、面向对象的 Python 库，专门用于按照 **AASHTO LRFD Bridge Design Specifications (9th Edition)** 和 **FHWA-NHI-10-016** 标准计算钻孔灌注桩（Drilled Shafts / Bored Piles）的轴向承载力。

该项目旨在为岩土工程师提供一个透明、可扩展且自动化的计算工具，替代繁琐且容易出错的 Excel 表格。

## 🚀 主要特性 (Key Features)

* **规范合规 (Code Compliance):** 严格遵循 AASHTO LRFD 规范，内置抗力系数 ($\varphi$) 和极限阻力限制 (Limits)。
* **多地层处理 (Multi-Layer Stratigraphy):** 支持复杂的“上软下硬”地层、夹层以及地下水位影响。
* **自动化参数关联 (Auto-Correlations):**
    * 自动将野外 SPT $N$ 值修正为 $N_{60}$。
    * 基于 $N$ 值自动估算土体重度 ($\gamma$)、内摩擦角 ($\phi'$) 和不排水抗剪强度 ($S_u$)。
* **高级算法 (Advanced Solvers):**
    * **黏土 (Clay):** $\alpha$-Method (Total Stress).
    * **砂土 (Sand):** $\beta$-Method (Effective Stress).
    * **中间岩土材料 (IGM):** 针对 $N > 50$ 的极密实土层或软岩的特殊处理逻辑。
* **模块化架构:** 易于扩展新的计算方法或集成到更大的 Web/Desktop 应用中。

## 📦 安装 (Installation)

目前 PyPile 处于开发阶段，建议通过克隆仓库进行本地安装：

```bash
git clone [https://github.com/yourusername/pypile.git](https://github.com/yourusername/pypile.git)
cd pypile

# (可选) 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安装依赖 (如果有)
pip install -r requirements.txt