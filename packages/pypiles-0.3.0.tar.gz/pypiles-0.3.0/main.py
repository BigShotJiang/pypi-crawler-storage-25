from pypile.configs import EquipmentConfig, AnalysisConfig
from pypile.core import SoilLayer, Borehole, Pile
from pypile.solver import LRFDSolver


def run_analysis():
    # 1. 定义设备 (Define Equipment)
    # 这台钻机是 Automatic Hammer (ER=90%)
    rig_alpha = EquipmentConfig(hammer_energy_ratio=0.90)

    # 2. 定义钻孔 (Define Borehole with that Equipment)
    # 当 layer 被 add 进去时，N60 就已经被算出并固定了
    bh = Borehole(water_table_depth=0.0, equipment=rig_alpha)

    bh.add_layer(SoilLayer(0, 5, 'sand', n_field=10))
    # ^ 此时 layer 内部: n60 = 10 * (0.9/0.6) = 15.0

    # 3. 定义计算规则 (Define Analysis Rules)
    # 使用标准 AASHTO 规范
    aashto_rules = AnalysisConfig()

    # 4. 运行
    pile = Pile(diameter=1.0, length=10.0)
    solver = LRFDSolver(pile, bh, config=aashto_rules)
    result = solver.solve()

    print(f"Capacity: {result['total_factored']:.2f} kN")


if __name__ == "__main__":
    run_analysis()