# pypile/constants.py

G = 9.81  # 重力加速度
WATER_UNIT_WEIGHT = 9.81  # kN/m3
PA = 100.0  # 大气压 kPa


# AASHTO LRFD Limits
# Ref: AASHTO LRFD 9th Ed, Art. 10.8.3.5.2b (Eq. 10.8.3.5.2b-1)
MAX_SIDE_RESISTANCE = 192.0  # kPa (limit for Beta method)
MAX_TIP_RESISTANCE_SAND = 3000.0  # kPa (limit for sand without load test)

# Resistance Factors (Phi) - Table 10.5.5.2.4-1
PHI_SIDE_CLAY = 0.45
PHI_SIDE_SAND = 0.55
PHI_TIP_CLAY = 0.40
PHI_TIP_SAND = 0.50
PHI_IGM = 0.60