"""Registration contracts for the cabinet registry.

This module defines the dataclasses used when feature apps register
dashboard widgets and navigation sections with the global
:data:`~codex_django.cabinet.registry.cabinet_registry`.

Types:

- :class:`DashboardWidget` — declares a widget to render on the dashboard.
- :class:`NavAction` — a generic action link in cabinet navigation areas.
- :class:`CabinetSection` — **deprecated** v1 navigation section.
  Use :class:`~codex_django.cabinet.types.nav.TopbarEntry` with the new
  ``declare(space=...)`` API instead.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .nav import Shortcut, SidebarItem, TopbarEntry


@dataclass(frozen=True)
class DashboardWidget:
    """Declaration of a dashboard widget contributed by a feature app.

    Feature apps register widgets via :func:`~codex_django.cabinet.declare`.
    The registry stores them and the dashboard view renders all widgets
    that the current user has permission to see.

    The ``template`` path is resolved relative to Django's template loaders.
    Widget templates live in ``cabinet/templates/cabinet/widgets/`` for
    built-in widgets, or in the feature app's own ``templates/`` directory
    for custom widgets.

    This class is ``frozen`` — instances are immutable after creation.

    Attributes:
        template: Django template path, e.g.
            ``"cabinet/widgets/kpi.html"`` or
            ``"booking/widgets/upcoming.html"``.
        col: Bootstrap column class controlling widget width.
            Defaults to ``"col-lg-6"`` (half-width on large screens).
            Use ``"col-lg-12"`` for full-width or ``"col-lg-4"`` for thirds.
        lazy: If ``True``, the widget is loaded asynchronously via HTMX
            after the initial page render. Useful for expensive queries.
            Defaults to ``False`` (eager render).
        nav_group: Navigation group this widget belongs to. Determines
            which dashboard tab shows the widget. Must be one of:

            - ``"admin"`` — Администрирование tab (default).
            - ``"services"`` — Сервисы tab.
            - ``"client"`` — Client portal dashboard.

        permissions: Tuple of Django permission strings. The widget is
            hidden unless the user has **at least one** listed permission.
            Empty tuple (default) means visible to all authenticated users.
        order: Sort order on the dashboard. Lower values appear first.
            Defaults to ``99``.

    Raises:
        django.core.exceptions.ImproperlyConfigured: If ``nav_group`` is
            not one of ``"admin"``, ``"services"``, or ``"client"``.

    Example::

        DashboardWidget(
            template="booking/widgets/upcoming_appointments.html",
            col="col-lg-6",
            lazy=True,
            nav_group="services",
            permissions=("booking.view_appointment",),
            order=10,
        )
    """

    template: str
    context_key: str | None = None
    col: str = "col-lg-6"
    lazy: bool = False
    nav_group: str = "admin"
    permissions: tuple[str, ...] = ()
    order: int = 99

    def __post_init__(self) -> None:
        from django.core.exceptions import ImproperlyConfigured

        if self.nav_group not in ("admin", "services", "client"):
            raise ImproperlyConfigured(
                f"DashboardWidget.nav_group must be 'admin', 'services' or 'client', got '{self.nav_group}'"
            )


@dataclass(frozen=True)
class NavAction:
    """A generic action link rendered in cabinet navigation areas.

    Used for supplementary links that do not belong to the main topbar
    or sidebar navigation — for example, footer links, context-specific
    quick actions, or legacy v1 topbar buttons.

    This class is ``frozen`` — instances are immutable after creation.

    Attributes:
        label: Display name of the action, e.g. ``"Настройки"``.
        url: Absolute URL or named URL string for the link.
        icon: Optional Bootstrap Icons class name, e.g. ``"bi-gear"``.
            Defaults to ``None`` (no icon).

    Example::

        NavAction(label="Настройки", url="/cabinet/settings/", icon="bi-gear")
    """

    label: str
    url: str
    icon: str | None = None


@dataclass(frozen=True)
class CabinetModuleConfig:
    """Read-only snapshot of a registered cabinet module.

    This is the public alternative to inspecting ``CabinetRegistry`` private
    storage. Projects can use it to build custom shells, quick access UIs, and
    module-aware views without depending on internal dict layout.
    """

    space: str
    module: str
    topbar: TopbarEntry | None = None
    sidebar: list[SidebarItem] = field(default_factory=list)
    shortcuts: list[Shortcut] = field(default_factory=list)
    settings_url: str | None = None


@dataclass(frozen=True)
class CabinetSection:
    """**Deprecated.** V1 navigation section for the cabinet topbar.

    .. deprecated::
        Use :class:`~codex_django.cabinet.types.nav.TopbarEntry` together
        with the new ``declare(space=...)`` API. ``CabinetSection`` is kept
        only for backward compatibility with projects generated by older
        versions of ``codex-django-cli``.

    In the v1 API a ``CabinetSection`` was passed directly to ``declare()``::

        # Old — do not use in new code
        from codex_django.cabinet import declare, CabinetSection

        declare(
            module="booking",
            section=CabinetSection(
                label="Booking",
                icon="bi-calendar",
                nav_group="services",
                url="/cabinet/booking/",
                order=10,
            ),
        )

    Migrate to the v2 API::

        # New
        from codex_django.cabinet import declare, TopbarEntry, SidebarItem

        declare(
            space="staff",
            module="booking",
            topbar=TopbarEntry(
                group="services",
                label="Booking",
                icon="bi-calendar",
                url="/cabinet/booking/",
                order=10,
            ),
            sidebar=[...],
        )

    This class is ``frozen`` — instances are immutable after creation.

    Attributes:
        label: Display name of the section.
        icon: Bootstrap Icons class name, e.g. ``"bi-calendar"``.
        nav_group: Dropdown group. Must be ``"admin"``, ``"services"``,
            or ``"client"``. Defaults to ``"admin"``.
        url: Optional link URL. ``None`` is valid for dropdown-only
            parent sections. Defaults to ``None``.
        permissions: Tuple of Django permission strings (OR logic).
            Empty tuple means visible to all. Defaults to ``()``.
        order: Sort order. Defaults to ``99``.

    Raises:
        django.core.exceptions.ImproperlyConfigured: If ``nav_group`` is
            not ``"admin"``, ``"services"``, or ``"client"``.
    """

    label: str
    icon: str
    nav_group: str = "admin"  # "admin" | "services" | "client"
    url: str | None = None
    permissions: tuple[str, ...] = ()
    order: int = 99

    def __post_init__(self) -> None:
        from django.core.exceptions import ImproperlyConfigured

        if self.nav_group not in ("admin", "services", "client"):
            raise ImproperlyConfigured(
                f"CabinetSection.nav_group must be 'admin', 'services' or 'client', got '{self.nav_group}'"
            )
