"""Edge scripting clients — Bunny Edge Scripting."""

from granny.edge.bunny import BunnyEdgeScriptClient

__all__ = ["BunnyEdgeScriptClient"]
