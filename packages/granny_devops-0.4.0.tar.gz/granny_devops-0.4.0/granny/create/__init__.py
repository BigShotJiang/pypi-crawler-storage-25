"""Provisioning scripts invoked by `granny create <thing>`.

Each module exposes an argparse-based ``main()`` that the CLI dispatches to.
"""
