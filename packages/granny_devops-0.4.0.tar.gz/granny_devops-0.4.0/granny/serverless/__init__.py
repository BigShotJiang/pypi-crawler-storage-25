"""Serverless / FaaS provider clients — Scaleway Functions."""

from granny.serverless.scaleway import ScalewayFunctionsClient

__all__ = ["ScalewayFunctionsClient"]
