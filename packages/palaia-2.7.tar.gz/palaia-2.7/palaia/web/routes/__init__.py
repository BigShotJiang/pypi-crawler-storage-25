"""WebUI API routes."""
