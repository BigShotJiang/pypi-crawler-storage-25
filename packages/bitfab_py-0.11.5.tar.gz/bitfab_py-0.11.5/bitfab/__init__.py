"""Bitfab client for provider-based API calls."""

from bitfab.client import (
    AllowedEnvVars,
    Bitfab,
    BitfabFunction,
    CurrentSpan,
    CurrentTrace,
    SpanType,
    flush_traces,
    get_current_span,
    get_current_trace,
)
from bitfab.replay import ReplayItem, ReplayResult

__all__ = [
    "AllowedEnvVars",
    "Bitfab",
    "BitfabFunction",
    "CurrentSpan",
    "CurrentTrace",
    "ReplayItem",
    "ReplayResult",
    "SpanType",
    "flush_traces",
    "get_current_span",
    "get_current_trace",
]

# Only export BitfabTracingProcessor if openai-agents is available
try:
    from bitfab.tracing import (
        BitfabOpenAITracingProcessor as BitfabTracingProcessor,  # noqa: F401
    )

    __all__.append("BitfabTracingProcessor")
except ImportError:
    pass

# Only export BitfabLangGraphCallbackHandler if langchain-core is available
try:
    from bitfab.langgraph import BitfabLangGraphCallbackHandler  # noqa: F401

    __all__.append("BitfabLangGraphCallbackHandler")
except ImportError:
    pass

# Only export BitfabClaudeAgentHandler if claude-agent-sdk is available
try:
    from bitfab.claude_agent_sdk import BitfabClaudeAgentHandler  # noqa: F401

    __all__.append("BitfabClaudeAgentHandler")
except ImportError:
    pass
