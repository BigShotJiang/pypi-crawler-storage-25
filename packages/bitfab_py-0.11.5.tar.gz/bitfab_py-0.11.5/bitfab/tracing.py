"""Tracing processor for OpenAI Agents SDK integration with Bitfab."""

import contextlib
import json
import logging
from typing import TYPE_CHECKING, Any, Callable, TypedDict

from bitfab.constants import DEFAULT_SERVICE_URL
from bitfab.http import HttpClient

if TYPE_CHECKING:
    from agents import Span, Trace, TracingProcessor
else:
    try:
        from agents import TracingProcessor
    except ImportError:
        TracingProcessor = object

logger = logging.getLogger(__name__)


class ActiveSpanContext(TypedDict):
    trace_id: str
    span_id: str


class BitfabOpenAITracingProcessor(TracingProcessor):
    """Tracing processor for OpenAI Agents SDK that sends traces to Bitfab.

    This processor captures traces and spans from the OpenAI Agents SDK and sends
    them to the Bitfab API for storage and analysis.

    Args:
        api_key: Bitfab API key for authentication
        service_url: Base URL for the Bitfab service (default: https://bitfab.ai)
    """

    def __init__(
        self,
        api_key: str,
        service_url: str | None = None,
        get_active_span_context: Callable[[], ActiveSpanContext | None] | None = None,
    ):
        """Initialize the Bitfab tracing processor.

        Args:
            api_key: Bitfab API key
            service_url: Base URL for Bitfab service (default: production URL)
            get_active_span_context: Optional callback that returns the active
                withSpan context or ``None``. Used to link OpenAI traces into
                an existing withSpan trace.
        """
        self._http_client = HttpClient(
            api_key=api_key,
            service_url=service_url or DEFAULT_SERVICE_URL,
        )
        self._active_traces: dict[str, Trace] = {}
        self._active_spans: dict[str, Span] = {}
        self._get_active_span_context = get_active_span_context
        self._active_span_mappings: dict[str, ActiveSpanContext] = {}

    @property
    def api_key(self) -> str:
        """Get the API key."""
        return self._http_client.api_key

    @property
    def service_url(self) -> str:
        """Get the service URL."""
        return self._http_client.service_url

    def on_trace_start(self, trace: "Trace") -> None:
        """Called when a trace starts.

        If there's an active withSpan context, the trace ID is remapped to the
        outer trace and sent to pre-create the external_traces row on the server.

        Args:
            trace: The trace that started
        """
        try:
            self._active_traces[trace.trace_id] = trace

            active_context = (
                self._get_active_span_context()
                if self._get_active_span_context is not None
                else None
            )
            if active_context is not None:
                self._active_span_mappings[trace.trace_id] = active_context

            self._send_external_trace(
                trace,
                trace_id_override=(
                    active_context["trace_id"] if active_context else None
                ),
            )
        except Exception:
            pass

    def on_trace_end(self, trace: "Trace") -> None:
        """Called when a trace ends.

        If mapped to a withSpan trace, sends with remapped ID and completed=False
        since the parent withSpan handles completion.

        Args:
            trace: The trace that ended
        """
        try:
            mapping = self._active_span_mappings.get(trace.trace_id)

            self._send_external_trace(
                trace,
                completed=mapping is None,
                trace_id_override=(mapping["trace_id"] if mapping else None),
            )

            self._active_span_mappings.pop(trace.trace_id, None)
            self._active_traces.pop(trace.trace_id, None)
        except Exception:
            pass

    def on_span_start(self, span: "Span") -> None:
        """Called when a span starts.

        Args:
            span: The span that started
        """
        with contextlib.suppress(Exception):
            self._active_spans[span.span_id] = span

    def on_span_end(self, span: "Span") -> None:
        """Called when a span ends.

        Args:
            span: The span that ended
        """
        try:
            self._active_spans.pop(span.span_id, None)
            self._send_external_span(span)
        except Exception:
            pass

    def _send_external_trace(
        self,
        trace: "Trace",
        completed: bool = False,
        trace_id_override: str | None = None,
    ) -> None:
        """Send external trace to Bitfab API (fire-and-forget).

        When trace_id_override is provided, the trace ID is remapped to link
        the OpenAI trace into an outer withSpan trace.

        Args:
            trace: The trace to send
            completed: If True, marks the trace as completed
            trace_id_override: If set, overrides the trace's ID in the payload
        """
        try:
            external_trace = trace.export()
            if trace_id_override is not None:
                external_trace["id"] = trace_id_override

            trace_data: dict[str, Any] = {
                "type": "openai",
                "source": "python-sdk-openai-tracing",
                "externalTrace": external_trace,
                "completed": completed,
            }

            # Serialize to JSON to catch any serialization errors early
            try:
                json_str = json.dumps(trace_data)
                trace_data = json.loads(json_str)  # Re-parse to ensure it's clean
            except TypeError as e:
                logger.error(f"Failed to serialize external trace data: {e}")
                return

            self._http_client.send_external_trace(trace_data)
        except Exception as e:
            logger.error(f"Failed to send external trace to Bitfab: {e}", exc_info=True)

    def _serialize_value(self, value: Any) -> Any:
        """Serialize a value to a JSON-serializable format."""
        if isinstance(value, dict):
            return value
        elif isinstance(value, list):
            return [self._serialize_value(item) for item in value]
        elif isinstance(value, (str, int, float, bool, type(None))):
            return value
        elif hasattr(value, "model_dump"):
            return value.model_dump()
        else:
            if hasattr(value, "__dict__"):
                return value.__dict__
            return str(value)

    def _export_span(
        self, span: "Span", errors: list[dict[str, str]]
    ) -> dict[str, Any]:
        """Export span to dict, collecting any errors."""
        try:
            serialized_span = span.export()
            if not isinstance(serialized_span, dict):
                errors.append(
                    {
                        "step": "span.export()",
                        "error": f"Returned non-dict type: {type(serialized_span)}",
                    }
                )
                serialized_span = {}
        except Exception as e:
            errors.append({"step": "span.export()", "error": str(e)})
            serialized_span = {}

        if "span_data" not in serialized_span:
            serialized_span["span_data"] = {}

        return serialized_span

    def _extract_span_input_response(
        self,
        span: "Span",
        serialized_span: dict[str, Any],
        errors: list[dict[str, str]],
    ) -> None:
        """Extract and serialize span input and response, updating errors list."""
        span_input = getattr(span.span_data, "input", None) or []
        span_response = getattr(span.span_data, "response", None)

        try:
            serialized_span["span_data"]["input"] = self._serialize_value(span_input)
        except Exception as e:
            errors.append({"step": "serialize_input", "error": str(e)})
            serialized_span["span_data"]["input"] = None

        try:
            serialized_span["span_data"]["response"] = (
                self._serialize_value(span_response) if span_response else None
            )
        except Exception as e:
            errors.append({"step": "serialize_response", "error": str(e)})
            serialized_span["span_data"]["response"] = None

    def _apply_span_overrides(
        self, serialized_span: dict[str, Any], trace_id: str
    ) -> None:
        """If the span's trace is mapped to a withSpan trace, rewrite trace_id and parent_id."""
        mapping = self._active_span_mappings.get(trace_id)
        if mapping is not None:
            serialized_span["trace_id"] = mapping["trace_id"]
            if not serialized_span.get("parent_id"):
                serialized_span["parent_id"] = mapping["span_id"]

    def _build_span_payload(
        self,
        serialized_span: dict[str, Any],
        errors: list[dict[str, str]],
    ) -> dict[str, Any]:
        """Build span payload and handle JSON serialization, returning payload dict."""
        span_data: dict[str, Any] = {
            "type": "openai",
            "source": "python-sdk-openai-tracing",
            "sourceTraceId": serialized_span.get("trace_id", "unknown"),
            "rawSpan": serialized_span,
        }

        if errors:
            span_data["errors"] = errors

        try:
            json_str = json.dumps(span_data)
            return json.loads(json_str)
        except (TypeError, ValueError) as e:
            errors.append({"step": "json_serialize", "error": str(e)})
            fallback_trace_id = serialized_span.get("trace_id", "unknown")
            span_data = {
                "type": "openai",
                "source": "python-sdk-openai-tracing",
                "sourceTraceId": fallback_trace_id,
                "rawSpan": {
                    "id": serialized_span.get("id", "unknown"),
                    "trace_id": fallback_trace_id,
                },
                "errors": errors,
            }
            return span_data

    def _send_external_span(self, span: "Span") -> None:
        """Send external span to Bitfab API (fire-and-forget).

        If the span belongs to a trace mapped to a withSpan trace, the trace_id
        and parent_id are rewritten to link the span into the withSpan tree.

        Args:
            span: The span to send
        """
        errors: list[dict[str, str]] = []
        serialized_span = self._export_span(span, errors)
        self._extract_span_input_response(span, serialized_span, errors)
        self._apply_span_overrides(serialized_span, span.trace_id)

        span_payload = self._build_span_payload(serialized_span, errors)

        try:
            self._http_client.send_external_span(span_payload)
        except Exception as e:
            logger.error(f"Failed to send external span to Bitfab: {e}", exc_info=True)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush any buffered traces/spans.

        Args:
            timeout_millis: Maximum time to wait for flush in milliseconds

        Returns:
            True if flush succeeded, False otherwise
        """
        return True

    def shutdown(self, timeout_millis: int = 30000) -> bool:
        """Shutdown the tracing processor.

        Args:
            timeout_millis: Maximum time to wait for shutdown in milliseconds

        Returns:
            True if shutdown succeeded, False otherwise
        """
        self.force_flush(timeout_millis)
        self._active_traces.clear()
        self._active_spans.clear()
        self._active_span_mappings.clear()
        return True

    def __enter__(self) -> "BitfabOpenAITracingProcessor":
        """Enter context manager."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit context manager and shutdown."""
        self.shutdown()
