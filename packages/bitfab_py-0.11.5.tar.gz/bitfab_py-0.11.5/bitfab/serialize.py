"""Serialization utilities for Bitfab SDK.

This module provides serialization with type metadata preservation,
similar to superjson in JavaScript. Uses jsonpickle for handling
arbitrary Python objects including datetime, Decimal, UUID, sets,
custom classes, etc.
"""

import dataclasses
import datetime as dt
from decimal import Decimal
from enum import Enum
from typing import Any, TypedDict
from uuid import UUID

import jsonpickle


class SerializedValue(TypedDict, total=False):
    """Serialized value with JSON data and optional type metadata.

    Attributes:
        json: The JSON-serializable data
        meta: Type metadata for reconstructing special types (only present if needed)
    """

    json: Any
    meta: Any


# Types jsonpickle handles well that json.dumps cannot natively serialize.
_JSONPICKLE_NATIVE_TYPES = (
    dt.datetime,
    dt.date,
    dt.time,
    UUID,
    Decimal,
    bytes,
    bytearray,
    set,
    frozenset,
)

# Module prefixes whose objects are expected to contain non-picklable runtime
# state (callbacks, thread locks, http clients, weak refs, etc.). We proactively
# convert these to plain dicts via `.model_dump()` / `asdict()` instead of
# letting jsonpickle walk their internals.
_FRAMEWORK_MODULE_PREFIXES: tuple[str, ...] = (
    "openai",
    "anthropic",
    "claude_agent_sdk",
    "httpx",
    "httpcore",
    "fastmcp",
    "mcp",
)


def _is_framework_object(value: Any) -> bool:
    """Return True if `value` appears to come from a known SDK/framework.

    Matches on the class's module name. Accepts both dotted children
    (`openai.types`) and underscore-suffixed sibling packages.
    """
    module = getattr(type(value), "__module__", "") or ""
    return any(
        module == prefix
        or module.startswith(prefix + ".")
        or module.startswith(prefix + "_")
        for prefix in _FRAMEWORK_MODULE_PREFIXES
    )


def _to_json_safe(value: Any, _depth: int = 0) -> Any:
    """Recursively convert a value to JSON-serialisable Python primitives.

    Unlike jsonpickle this does not preserve full class identity — it produces
    plain dicts/lists/scalars suitable for `json.dumps`. Used as a fallback
    when jsonpickle cannot handle an object (e.g. objects containing
    callbacks, thread locks, or httpx clients).
    """
    # Prevent runaway recursion on cyclic graphs.
    if _depth > 16:
        return f"<{type(value).__qualname__}: max depth>"

    if value is None or isinstance(value, (str, int, float, bool)):
        return value

    # Enum before model_dump since Enums can inherit from Pydantic-ish things.
    if isinstance(value, Enum):
        try:
            return _to_json_safe(value.value, _depth + 1)
        except Exception:
            return str(value)

    # Types that json.dumps can't handle but that jsonpickle-native types
    # should stringify reasonably for the safe fallback.
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (bytes, bytearray)):
        try:
            return value.decode("utf-8")
        except Exception:
            return value.hex()

    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for k, v in value.items():
            try:
                out[str(k)] = _to_json_safe(v, _depth + 1)
            except Exception:
                out[str(k)] = f"<{type(v).__qualname__}>"
        return out

    if isinstance(value, (list, tuple, set, frozenset)):
        out_list: list[Any] = []
        for item in value:
            try:
                out_list.append(_to_json_safe(item, _depth + 1))
            except Exception:
                out_list.append(f"<{type(item).__qualname__}>")
        return out_list

    # Pydantic v2
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return _to_json_safe(model_dump(mode="python"), _depth + 1)
        except Exception:
            try:
                return _to_json_safe(model_dump(), _depth + 1)
            except Exception:
                pass

    # Pydantic v1
    dict_method = getattr(value, "dict", None)
    if callable(dict_method):
        try:
            return _to_json_safe(dict_method(), _depth + 1)
        except Exception:
            pass

    # Dataclass instance (not the class itself)
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        try:
            return _to_json_safe(dataclasses.asdict(value), _depth + 1)
        except Exception:
            pass

    # Objects with a __dict__ — shallow expansion.
    if hasattr(value, "__dict__") and _depth < 4:
        try:
            attrs: dict[str, Any] = {}
            for k, v in vars(value).items():
                if k.startswith("_"):
                    continue
                try:
                    attrs[k] = _to_json_safe(v, _depth + 1)
                except Exception:
                    attrs[k] = f"<{type(v).__qualname__}>"
            class_name = type(value).__qualname__
            if attrs:
                return {"__class__": class_name, **attrs}
        except Exception:
            pass

    return f"<{type(value).__qualname__}>"


def _contains_framework_object(value: Any, _depth: int = 0) -> bool:
    """Return True if value or a nested child is a framework object."""
    if _depth > 8:
        return False
    if _is_framework_object(value):
        return True
    if isinstance(value, dict):
        return any(_contains_framework_object(v, _depth + 1) for v in value.values())
    if isinstance(value, (list, tuple, set, frozenset)):
        return any(_contains_framework_object(v, _depth + 1) for v in value)
    return False


def serialize_value(value: Any) -> SerializedValue:
    """Serialize a value using jsonpickle for type preservation.

    Handles arbitrary Python objects including:
    - datetime, date, time
    - Decimal, UUID
    - set, frozenset
    - bytes, bytearray
    - Custom classes
    - Pydantic models

    Args:
        value: Any Python value to serialize

    Returns:
        SerializedValue with 'json' field containing the data.
        If type metadata is needed for reconstruction, includes 'meta' field.

    Example:
        >>> from datetime import datetime
        >>> result = serialize_value(datetime(2024, 1, 15, 10, 30))
        >>> result["json"]  # Contains the serialized datetime
        >>> result.get("meta")  # Contains type info if present
    """
    if value is None:
        return {"json": None}

    # For simple JSON-native types, no metadata needed
    if isinstance(value, (str, int, float, bool)):
        return {"json": value}

    # For dicts and lists of simple types, try plain JSON first
    if isinstance(value, (dict, list)):
        try:
            # Check if it's already JSON-serializable without special types
            import json

            json.dumps(value)
            return {"json": value}
        except (TypeError, ValueError):
            # Contains special types, use jsonpickle
            pass

    # Use jsonpickle for everything else
    try:
        # Encode with type information (unpicklable=True preserves type markers)
        encoded = jsonpickle.encode(value, unpicklable=True)
        # Parse back to get the JSON structure
        import json

        parsed = json.loads(encoded)

        # Check if jsonpickle added type markers
        if _has_type_markers(parsed):
            # Return with metadata indicating jsonpickle encoding
            return {"json": parsed, "meta": {"encoding": "jsonpickle"}}
        else:
            # No special types, return plain JSON
            return {"json": parsed}
    except Exception:
        # Fallback: try basic serialization
        try:
            if hasattr(value, "model_dump"):  # Pydantic v2
                return {"json": value.model_dump()}
            elif hasattr(value, "dict"):  # Pydantic v1
                return {"json": value.dict()}
            else:
                return {"json": str(value)}
        except Exception:
            return {"json": str(value)}


def deserialize_value(serialized: SerializedValue) -> Any:
    """Deserialize a value that was serialized with serialize_value.

    Args:
        serialized: A SerializedValue dict with 'json' and optional 'meta'

    Returns:
        The reconstructed Python value
    """
    json_data = serialized.get("json")
    meta = serialized.get("meta")

    if meta is None:
        # No metadata, return as-is
        return json_data

    if isinstance(meta, dict) and meta.get("encoding") == "jsonpickle":
        # Decode using jsonpickle
        import json

        encoded = json.dumps(json_data)
        return jsonpickle.decode(encoded)

    # Unknown metadata format, return raw JSON
    return json_data


def _has_type_markers(obj: Any) -> bool:
    """Check if a JSON structure contains jsonpickle type markers."""
    if isinstance(obj, dict):
        # Check for jsonpickle's type marker keys
        if any(k.startswith("py/") for k in obj):
            return True
        # Check nested values
        return any(_has_type_markers(v) for v in obj.values())
    elif isinstance(obj, list):
        return any(_has_type_markers(item) for item in obj)
    return False
