"""Claude Agent SDK handler for Bitfab tracing.

Hooks into the Claude Agent SDK's lifecycle to capture LLM turns,
tool invocations, and subagent execution as Bitfab spans.

Uses two integration surfaces:
  1. SDK hooks (PreToolUse, PostToolUse, etc.) for tool/subagent lifecycle
  2. Stream wrapping for LLM turn capture from the message stream
"""

import json
import logging
import uuid
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from typing import Any, Callable, TypedDict

from bitfab.constants import DEFAULT_SERVICE_URL
from bitfab.http import HttpClient

logger = logging.getLogger(__name__)


class ActiveSpanContext(TypedDict):
    trace_id: str
    span_id: str


class _SpanInfo(TypedDict, total=False):
    span_id: str
    trace_id: str
    parent_id: str | None
    started_at: str
    ended_at: str | None
    name: str
    type: str
    input: Any
    output: Any
    error: str | None
    contexts: list[dict[str, Any]]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_serialize(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {k: _safe_serialize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe_serialize(item) for item in value]
    if hasattr(value, "model_dump"):
        return value.model_dump()
    if hasattr(value, "__dict__"):
        return {
            k: _safe_serialize(v)
            for k, v in value.__dict__.items()
            if not k.startswith("_")
        }
    return str(value)


def _extract_content_blocks(content: Any) -> list[dict[str, Any]]:
    """Extract content blocks from an AssistantMessage's content list."""
    if not content:
        return []
    blocks = []
    for block in content:
        blocks.append(_safe_serialize(block))
    return blocks


def _extract_usage(message: Any) -> dict[str, Any]:
    """Extract token usage from an AssistantMessage."""
    usage_info: dict[str, Any] = {}
    usage = getattr(message, "usage", None)
    if not usage:
        return usage_info

    if isinstance(usage, dict):
        raw = usage
    elif hasattr(usage, "__dict__"):
        raw = usage.__dict__
    else:
        return usage_info

    mapping = {
        "input_tokens": "inputTokens",
        "output_tokens": "outputTokens",
        "cache_read_input_tokens": "cacheReadTokens",
        "cache_creation_input_tokens": "cacheCreationTokens",
    }
    for src_key, dst_key in mapping.items():
        val = raw.get(src_key)
        if val is not None:
            usage_info[dst_key] = val

    return usage_info


class BitfabClaudeAgentHandler:
    """Claude Agent SDK handler that sends traces to Bitfab.

    Captures LLM turns, tool invocations, and subagent execution as
    Bitfab spans with proper parent-child hierarchy.

    Usage::

        from bitfab import Bitfab
        from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions

        bitfab = Bitfab(api_key="your-api-key")
        handler = bitfab.get_claude_agent_handler("my-agent")

        options = handler.instrument_options(
            ClaudeAgentOptions(model="claude-sonnet-4-5-...")
        )

        async with ClaudeSDKClient(options=options) as client:
            await client.query("Do something")
            async for message in handler.wrap_response(client.receive_response()):
                ...  # process messages normally

    Args:
        api_key: Bitfab API key for authentication
        trace_function_key: Groups traces under this key in Bitfab
        service_url: Base URL for the Bitfab service
        get_active_span_context: Optional callback that returns the active
            withSpan context for linking Claude Agent traces into an existing
            Bitfab trace tree.
    """

    def __init__(
        self,
        api_key: str,
        trace_function_key: str,
        service_url: str | None = None,
        get_active_span_context: Callable[[], ActiveSpanContext | None] | None = None,
    ):
        self._http_client = HttpClient(
            api_key=api_key,
            service_url=service_url or DEFAULT_SERVICE_URL,
        )
        self._trace_function_key = trace_function_key
        self._get_active_span_context = get_active_span_context

        self._run_to_span: dict[str, _SpanInfo] = {}
        self._trace_id: str | None = None
        self._root_span_id: str | None = None
        self._active_context: ActiveSpanContext | None = None
        self._trace_started_at: str | None = None

        # LLM turn tracking
        self._conversation_history: list[dict[str, Any]] = []
        self._pending_messages: list[dict[str, Any]] = []
        self._current_llm_span_id: str | None = None
        self._current_llm_message_id: str | None = None
        self._current_llm_content: list[dict[str, Any]] = []
        self._current_llm_model: str | None = None
        self._current_llm_usage: dict[str, Any] = {}
        self._current_llm_started_at: str | None = None
        self._current_llm_history_snapshot: list[dict[str, Any]] = []

        # Subagent tracking
        self._active_subagent_spans: dict[str, str] = {}

    # ── trace lifecycle ──────────────────────────────────────────

    def _ensure_trace(self) -> str:
        """Initialize the trace if not yet started. Returns trace_id."""
        if self._trace_id is not None:
            return self._trace_id

        self._active_context = (
            self._get_active_span_context()
            if self._get_active_span_context is not None
            else None
        )

        if self._active_context is not None:
            self._trace_id = self._active_context["trace_id"]
        else:
            self._trace_id = str(uuid.uuid4())

        self._trace_started_at = _now_iso()
        return self._trace_id

    def _get_parent_id(self, agent_id: str | None = None) -> str | None:
        """Determine the parent span ID for a new span."""
        if agent_id and agent_id in self._active_subagent_spans:
            return self._active_subagent_spans[agent_id]
        if self._active_context is not None:
            return self._active_context["span_id"]
        return self._root_span_id

    # ── span helpers (same pattern as langgraph.py) ──────────────

    def _start_span(
        self,
        span_id: str,
        name: str,
        span_type: str,
        input_data: Any = None,
        parent_id: str | None = None,
    ) -> _SpanInfo:
        trace_id = self._ensure_trace()

        span_info: _SpanInfo = {
            "span_id": span_id,
            "trace_id": trace_id,
            "parent_id": parent_id,
            "started_at": _now_iso(),
            "name": name,
            "type": span_type,
            "input": _safe_serialize(input_data),
            "contexts": [],
        }
        self._run_to_span[span_id] = span_info
        return span_info

    def _complete_span(
        self,
        span_id: str,
        output: Any = None,
        error: str | None = None,
        extra_contexts: dict[str, Any] | None = None,
    ) -> None:
        span_info = self._run_to_span.pop(span_id, None)
        if span_info is None:
            return

        span_info["ended_at"] = _now_iso()
        span_info["output"] = _safe_serialize(output)
        if error is not None:
            span_info["error"] = error

        if extra_contexts:
            span_info.setdefault("contexts", []).append(extra_contexts)

        self._send_span(span_info)

    def _send_span(self, span_info: _SpanInfo) -> None:
        span_data: dict[str, Any] = {
            "name": span_info.get("name", ""),
            "type": span_info.get("type", "custom"),
        }
        if span_info.get("input") is not None:
            span_data["input"] = span_info["input"]
        if span_info.get("output") is not None:
            span_data["output"] = span_info["output"]
        if span_info.get("error") is not None:
            span_data["error"] = span_info["error"]
        if span_info.get("contexts"):
            span_data["contexts"] = span_info["contexts"]

        raw_span: dict[str, Any] = {
            "id": span_info["span_id"],
            "trace_id": span_info["trace_id"],
            "started_at": span_info["started_at"],
            "ended_at": span_info.get("ended_at", _now_iso()),
            "span_data": span_data,
        }
        if span_info.get("parent_id") is not None:
            raw_span["parent_id"] = span_info["parent_id"]

        payload: dict[str, Any] = {
            "type": "sdk-function",
            "source": "python-sdk-claude-agent-sdk",
            "traceFunctionKey": self._trace_function_key,
            "sourceTraceId": span_info["trace_id"],
            "rawSpan": raw_span,
        }

        try:
            json_str = json.dumps(payload)
            payload = json.loads(json_str)
        except (TypeError, ValueError) as e:
            logger.error("Bitfab: Failed to serialize Claude Agent span: %s", e)
            return

        try:
            self._http_client.send_external_span(payload)
        except Exception as e:
            logger.error(
                "Bitfab: Failed to send Claude Agent span: %s", e, exc_info=True
            )

    def _send_trace_completion(
        self,
        ended_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        if self._trace_id is None:
            return

        completed = self._active_context is None
        trace_id = self._trace_id

        # Mark as sent so the finally block doesn't re-send
        self._trace_id = None

        trace_data: dict[str, Any] = {
            "type": "sdk-function",
            "source": "python-sdk-claude-agent-sdk",
            "traceFunctionKey": self._trace_function_key,
            "externalTrace": {
                "id": trace_id,
                "started_at": self._trace_started_at or _now_iso(),
                "ended_at": ended_at or _now_iso(),
                "workflow_name": self._trace_function_key,
            },
            "completed": completed,
        }

        if metadata:
            trace_data["externalTrace"]["metadata"] = metadata

        try:
            json_str = json.dumps(trace_data)
            trace_data = json.loads(json_str)
        except (TypeError, ValueError) as e:
            logger.error("Bitfab: Failed to serialize Claude Agent trace: %s", e)
            return

        try:
            self._http_client.send_external_trace(trace_data)
        except Exception as e:
            logger.error(
                "Bitfab: Failed to send Claude Agent trace: %s", e, exc_info=True
            )

    # ── hook callbacks ───────────────────────────────────────────

    async def _pre_tool_use_hook(
        self,
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        try:
            sid = input_data.get("tool_use_id", tool_use_id or str(uuid.uuid4()))
            tool_name = input_data.get("tool_name", "tool")
            tool_input = input_data.get("tool_input", {})
            agent_id = input_data.get("agent_id")
            parent_id = self._get_parent_id(agent_id)

            self._start_span(
                span_id=sid,
                name=tool_name,
                span_type="function",
                input_data=tool_input,
                parent_id=parent_id,
            )
        except Exception:
            logger.debug("Bitfab: Error in _pre_tool_use_hook", exc_info=True)
        return {}

    async def _post_tool_use_hook(
        self,
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        try:
            sid = input_data.get("tool_use_id", tool_use_id or "")
            tool_response = input_data.get("tool_response")
            self._complete_span(sid, output=tool_response)
        except Exception:
            logger.debug("Bitfab: Error in _post_tool_use_hook", exc_info=True)
        return {}

    async def _post_tool_use_failure_hook(
        self,
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        try:
            sid = input_data.get("tool_use_id", tool_use_id or "")
            error = input_data.get("error", "Unknown error")
            self._complete_span(sid, error=str(error))
        except Exception:
            logger.debug("Bitfab: Error in _post_tool_use_failure_hook", exc_info=True)
        return {}

    async def _subagent_start_hook(
        self,
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        try:
            agent_id = input_data.get("agent_id", str(uuid.uuid4()))
            agent_type = input_data.get("agent_type", "subagent")
            parent_id = self._get_parent_id()

            span_id = str(uuid.uuid4())
            self._active_subagent_spans[agent_id] = span_id

            self._start_span(
                span_id=span_id,
                name=f"Agent: {agent_type}",
                span_type="agent",
                parent_id=parent_id,
            )
        except Exception:
            logger.debug("Bitfab: Error in _subagent_start_hook", exc_info=True)
        return {}

    async def _subagent_stop_hook(
        self,
        input_data: dict[str, Any],
        tool_use_id: str | None,
        context: Any,
    ) -> dict[str, Any]:
        try:
            agent_id = input_data.get("agent_id", "")
            span_id = self._active_subagent_spans.pop(agent_id, None)
            if span_id:
                self._complete_span(span_id)
        except Exception:
            logger.debug("Bitfab: Error in _subagent_stop_hook", exc_info=True)
        return {}

    # ── public API ───────────────────────────────────────────────

    def instrument_options(self, options: Any) -> Any:
        """Inject Bitfab tracing hooks into ClaudeAgentOptions.

        Modifies the options in-place and returns them for convenience.

        Args:
            options: A ClaudeAgentOptions instance (or any object with a
                ``hooks`` attribute that is a dict of hook event lists).

        Returns:
            The modified options object with Bitfab hooks injected.
        """
        try:
            from claude_agent_sdk import HookMatcher
        except ImportError as e:
            raise ImportError(
                "claude-agent-sdk is required for Claude Agent SDK tracing. "
                "Install it with: pip install 'bitfab-py[claude-agent-sdk]'"
            ) from e

        hooks = getattr(options, "hooks", None)
        if hooks is None:
            hooks = {}
            options.hooks = hooks

        hook_config = [
            ("PreToolUse", self._pre_tool_use_hook),
            ("PostToolUse", self._post_tool_use_hook),
            ("PostToolUseFailure", self._post_tool_use_failure_hook),
            ("SubagentStart", self._subagent_start_hook),
            ("SubagentStop", self._subagent_stop_hook),
        ]

        for event, callback in hook_config:
            if event not in hooks:
                hooks[event] = []
            hooks[event].append(HookMatcher(matcher=None, hooks=[callback]))

        return options

    async def wrap_response(self, stream: AsyncIterator[Any]) -> AsyncIterator[Any]:
        """Wrap a ClaudeSDKClient.receive_response() stream to capture LLM turns.

        Yields every message unchanged while capturing AssistantMessage
        content as LLM turn spans.

        Args:
            stream: The async iterator from ``client.receive_response()``

        Yields:
            Each message from the stream, unmodified.
        """
        async for message in self._process_stream(stream):
            yield message

    async def wrap_query(self, stream: AsyncIterator[Any]) -> AsyncIterator[Any]:
        """Wrap a ``query()`` async iterator to capture LLM turns.

        Same as :meth:`wrap_response` but for the simpler ``query()`` API
        which does not support hooks (no tool/subagent spans).

        Args:
            stream: The async iterator from ``query(...)``

        Yields:
            Each message from the stream, unmodified.
        """
        async for message in self._process_stream(stream):
            yield message

    # ── stream processing ────────────────────────────────────────

    async def _process_stream(self, stream: AsyncIterator[Any]) -> AsyncIterator[Any]:
        """Core stream processing logic shared by wrap_response and wrap_query."""
        try:
            async for message in stream:
                try:
                    self._process_message(message)
                except Exception:
                    logger.debug("Bitfab: Error processing message", exc_info=True)
                yield message
        finally:
            try:
                self._flush_llm_turn()
                self._send_trace_completion()
            except Exception:
                logger.debug("Bitfab: Error in stream cleanup", exc_info=True)
            self._reset_state()

    def _process_message(self, message: Any) -> None:
        """Route a message to the appropriate handler based on its type."""
        type_name = type(message).__name__

        if type_name == "AssistantMessage":
            self._handle_assistant_message(message)
        elif type_name == "UserMessage":
            self._handle_user_message(message)
        elif type_name == "ResultMessage":
            self._handle_result_message(message)

    def _handle_assistant_message(self, message: Any) -> None:
        """Buffer assistant message content for LLM turn span creation."""
        self._ensure_trace()

        message_id = getattr(message, "message_id", None)

        if message_id != self._current_llm_message_id:
            self._flush_llm_turn()

            # Drain pending user/tool messages into history before snapshot
            self._conversation_history.extend(self._pending_messages)
            self._pending_messages.clear()

            self._current_llm_span_id = str(uuid.uuid4())
            self._current_llm_message_id = message_id
            self._current_llm_content = []
            self._current_llm_model = getattr(message, "model", None)
            self._current_llm_usage = {}
            self._current_llm_started_at = _now_iso()
            self._current_llm_history_snapshot = list(self._conversation_history)

        content = getattr(message, "content", None)
        if content:
            self._current_llm_content.extend(_extract_content_blocks(content))

        usage = _extract_usage(message)
        if usage:
            self._current_llm_usage.update(usage)

        model = getattr(message, "model", None)
        if model:
            self._current_llm_model = model

    def _handle_user_message(self, message: Any) -> None:
        """Buffer user message for later insertion into conversation history."""
        content = getattr(message, "content", None)
        tool_use_result = getattr(message, "tool_use_result", None)

        if tool_use_result is not None:
            self._pending_messages.append(
                {
                    "role": "tool",
                    "content": _safe_serialize(content),
                    "tool_result": _safe_serialize(tool_use_result),
                }
            )
        else:
            self._pending_messages.append(
                {
                    "role": "user",
                    "content": _safe_serialize(content),
                }
            )

    def _handle_result_message(self, message: Any) -> None:
        """Flush final LLM turn and send trace completion."""
        self._flush_llm_turn()

        metadata: dict[str, Any] = {}
        for attr in (
            "num_turns",
            "total_cost_usd",
            "duration_ms",
            "duration_api_ms",
            "session_id",
        ):
            val = getattr(message, attr, None)
            if val is not None:
                metadata[attr] = val

        result_usage = getattr(message, "usage", None)
        if result_usage:
            if isinstance(result_usage, dict):
                metadata["usage"] = result_usage
            elif hasattr(result_usage, "__dict__"):
                metadata["usage"] = {
                    k: v
                    for k, v in result_usage.__dict__.items()
                    if not k.startswith("_")
                }

        self._send_trace_completion(metadata=metadata if metadata else None)

    def _flush_llm_turn(self) -> None:
        """Flush the buffered LLM turn as a span."""
        if self._current_llm_span_id is None:
            return

        span_id = self._current_llm_span_id
        trace_id = self._ensure_trace()
        parent_id = self._get_parent_id()

        llm_context: dict[str, Any] = {}
        if self._current_llm_model:
            llm_context["model"] = self._current_llm_model
        llm_context.update(self._current_llm_usage)

        span_info: _SpanInfo = {
            "span_id": span_id,
            "trace_id": trace_id,
            "parent_id": parent_id,
            "started_at": self._current_llm_started_at or _now_iso(),
            "ended_at": _now_iso(),
            "name": self._current_llm_model or "llm",
            "type": "llm",
            "input": self._current_llm_history_snapshot,
            "output": self._current_llm_content,
            "contexts": [llm_context] if llm_context else [],
        }

        self._send_span(span_info)

        self._conversation_history.append(
            {
                "role": "assistant",
                "content": self._current_llm_content,
            }
        )

        self._current_llm_span_id = None
        self._current_llm_message_id = None
        self._current_llm_content = []
        self._current_llm_model = None
        self._current_llm_usage = {}
        self._current_llm_started_at = None
        self._current_llm_history_snapshot = []

    def _reset_state(self) -> None:
        """Reset all state after a conversation completes."""
        self._run_to_span.clear()
        self._trace_id = None
        self._root_span_id = None
        self._active_context = None
        self._trace_started_at = None
        self._conversation_history.clear()
        self._pending_messages.clear()
        self._current_llm_span_id = None
        self._current_llm_message_id = None
        self._current_llm_content = []
        self._current_llm_model = None
        self._current_llm_usage = {}
        self._current_llm_started_at = None
        self._current_llm_history_snapshot = []
        self._active_subagent_spans.clear()
