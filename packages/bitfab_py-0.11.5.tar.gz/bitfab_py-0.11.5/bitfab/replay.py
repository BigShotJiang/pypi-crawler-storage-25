"""Replay historical traces through a function and create a test run."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Callable, TypedDict

from bitfab.constants import _replay_context
from bitfab.http import flush_traces
from bitfab.serialize import deserialize_value

if TYPE_CHECKING:
    from bitfab.client import Bitfab

logger = logging.getLogger(__name__)


class TokenUsage(TypedDict):
    """Per-item token usage from the original trace."""

    input: int | None
    output: int | None
    cached: int | None
    total: int | None


class ReplayItem(TypedDict):
    """A single item from a replay execution."""

    input: list[Any]
    result: Any
    original_output: Any
    error: str | None
    duration_ms: int | None
    tokens: TokenUsage | None
    model: str | None


class ReplayResult(TypedDict):
    """Result from a replay execution."""

    items: list[ReplayItem]
    test_run_id: str
    test_run_url: str


def _find_bitfab_wrapper(fn: Callable) -> Callable | None:
    """Walk the __wrapped__ chain to find the innermost bitfab-decorated function.

    Handles nested decorators (e.g. @retry(@cache(@span(fn)))) by traversing
    through each layer's __wrapped__ attribute until it finds one with
    _bitfab_wrapped=True.
    """
    current = fn
    seen: set[int] = set()
    while current is not None:
        if id(current) in seen:
            break
        seen.add(id(current))
        if getattr(current, "_bitfab_wrapped", False):
            return current
        current = getattr(current, "__wrapped__", None)
    return None


def replay(
    client: Bitfab,
    fn: Callable,
    *,
    limit: int = 5,
    trace_ids: list[str] | None = None,
    max_concurrency: int | None = 10,
) -> ReplayResult:
    """Replay historical traces through a function and create a test run.

    Fetches the last N traces for the given trace function key, re-runs each
    through the provided function (wrapped with span decorator for tracing),
    and returns comparison data.

    The function is called through its full decorator chain (e.g. @retry,
    @cache) — replay injects test_run_id via context rather than re-wrapping.

    Args:
        client: The Bitfab client instance
        fn: The function to replay (must be decorated with @span)
        limit: Maximum number of traces to replay
        trace_ids: Optional list of trace IDs to filter which traces are replayed
        max_concurrency: Maximum number of items to process in parallel.
            Set to 1 for sequential execution, or None for unlimited. Defaults to 10.

    Returns:
        ReplayResult with items (input, result, original_output, error),
        test_run_id, and test_run_url
    """
    wrapper = _find_bitfab_wrapper(fn)
    if wrapper is None:
        raise ValueError(
            f"Function {getattr(fn, '__name__', repr(fn))} must be decorated with @span before calling replay."
        )

    trace_function_key = wrapper._bitfab_trace_function_key

    replay_data = client.http_client.start_replay(
        trace_function_key, limit, trace_ids=trace_ids
    )
    test_run_id = replay_data["testRunId"]
    test_run_url = replay_data["testRunUrl"]
    server_items = replay_data["items"]

    result_items: list[ReplayItem] = []

    if server_items:
        result_items = asyncio.run(
            _run_replay_async(client, server_items, fn, test_run_id, max_concurrency)
        )

    flush_traces()

    try:
        client.http_client.complete_replay(test_run_id)
    except Exception as e:
        logger.error(f"Failed to complete replay: {e}")

    return ReplayResult(
        items=result_items,
        test_run_id=test_run_id,
        test_run_url=f"{client.service_url}{test_run_url}",
    )


async def _run_replay_async(
    client: Bitfab,
    server_items: list[dict[str, Any]],
    fn: Callable,
    test_run_id: str,
    max_concurrency: int | None,
) -> list[ReplayItem]:
    """Process all replay items concurrently using asyncio.gather."""
    semaphore = asyncio.Semaphore(max_concurrency) if max_concurrency else None

    async def process_with_limit(
        server_item: dict[str, Any],
    ) -> tuple[ReplayItem, bool]:
        if semaphore:
            async with semaphore:
                return await _process_item_async(client, server_item, fn, test_run_id)
        return await _process_item_async(client, server_item, fn, test_run_id)

    results = await asyncio.gather(*(process_with_limit(item) for item in server_items))
    return [item for item, _ in results]


async def _process_item_async(
    client: Bitfab,
    server_item: dict[str, Any],
    fn: Callable,
    test_run_id: str,
) -> tuple[ReplayItem, bool]:
    """Fetch span data and execute a single replay item."""
    span = await asyncio.to_thread(
        client.http_client.get_external_span, server_item["externalSpanId"]
    )
    item_data = _extract_span_data(span)
    metrics = _extract_server_item_metrics(server_item)
    return await _execute_item_async(item_data, fn, test_run_id, span["id"], metrics)


def _extract_server_item_metrics(
    server_item: dict[str, Any],
) -> dict[str, Any]:
    """Pull durationMs / tokens / model from the start-replay server item.

    Normalizes missing fields to None so older servers remain compatible.
    """
    tokens = server_item.get("tokens")
    return {
        "duration_ms": server_item.get("durationMs"),
        "tokens": tokens if isinstance(tokens, dict) else None,
        "model": server_item.get("model"),
    }


def _extract_span_data(span: dict[str, Any]) -> dict[str, Any]:
    """Extract input/output data and span options from an external span's rawData."""
    raw_data = span.get("rawData") or {}
    span_data = raw_data.get("span_data") or {}

    return {
        "input": span_data.get("input"),
        "output": span_data.get("output"),
        "inputSerialized": span_data.get("input_serialized"),
        "outputSerialized": span_data.get("output_serialized"),
    }


async def _execute_item_async(
    item: dict[str, Any],
    fn: Callable,
    test_run_id: str,
    input_source_span_id: str | None = None,
    metrics: dict[str, Any] | None = None,
) -> tuple[ReplayItem, bool]:
    """Execute a single replay item: deserialize inputs, call fn with replay context.

    Sets the replay context so the existing @span decorator picks up
    test_run_id and input_source_span_id, then calls fn through its full decorator chain.

    Returns:
        Tuple of (ReplayItem, had_error)
    """
    args, kwargs = _deserialize_inputs(item)

    fn_result = None
    fn_error = None

    replay_ctx: dict[str, Any] = {"test_run_id": test_run_id}
    if input_source_span_id is not None:
        replay_ctx["input_source_span_id"] = input_source_span_id
    token = _replay_context.set(replay_ctx)
    try:
        if asyncio.iscoroutinefunction(fn):
            fn_result = await fn(*args, **kwargs)
        else:
            fn_result = await asyncio.to_thread(fn, *args, **kwargs)
    except Exception as e:
        fn_error = str(e)
    finally:
        _replay_context.reset(token)

    metrics = metrics or {}
    replay_item = ReplayItem(
        input=args,
        result=fn_result,
        original_output=item.get("output"),
        error=fn_error,
        duration_ms=metrics.get("duration_ms"),
        tokens=metrics.get("tokens"),
        model=metrics.get("model"),
    )
    return replay_item, fn_error is not None


def _deserialize_inputs(item: dict[str, Any]) -> tuple[list[Any], dict[str, Any]]:
    """Deserialize inputs from a replay item into (args, kwargs)."""
    input_serialized = item.get("inputSerialized")
    raw_input = item.get("input")

    if (
        input_serialized
        and isinstance(input_serialized, dict)
        and "meta" in input_serialized
    ):
        deserialized = deserialize_value(input_serialized)
        if isinstance(deserialized, dict):
            return deserialized.get("args", []), deserialized.get("kwargs", {})
        return [deserialized] if deserialized is not None else [], {}

    if isinstance(raw_input, list):
        return raw_input, {}
    if isinstance(raw_input, dict):
        return [], raw_input
    return [raw_input] if raw_input is not None else [], {}
