import json
import multiprocessing
import queue
import threading
import uuid
from abc import ABC, abstractmethod

from modict import modict

from .agent import Agent
from .event import Event
from .message import UserMessage, message_from_data


def jsonable(value):
    return json.loads(json.dumps(value, ensure_ascii=False, default=str))


class AgentRuntimeError(RuntimeError):
    pass


class AgentRuntime(ABC):
    """Canonical contract for exposing an agent to external applications.

    This ABC is the source of truth for every public surface that drives or
    introspects an Agent from outside the core object: HTTP server, headless CLI,
    local process adapters, remote clients and future integrations should all
    implement or target this runtime interface instead of depending on Agent
    internals directly.
    """

    @abstractmethod
    def start(self):
        return self

    @abstractmethod
    def stop(self, timeout=None):
        return self

    @abstractmethod
    def on_event(self, handler):
        return handler

    @property
    @abstractmethod
    def busy(self):
        return False

    @property
    @abstractmethod
    def current_turn_id(self):
        return None

    @property
    @abstractmethod
    def current_session_id(self):
        return None

    @abstractmethod
    def get_status(self):
        raise NotImplementedError

    @abstractmethod
    def config(self):
        raise NotImplementedError

    @abstractmethod
    def update_config(self, values=None, save=True, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def session(self):
        raise NotImplementedError

    @abstractmethod
    def sessions(self):
        raise NotImplementedError

    @abstractmethod
    def messages(self):
        raise NotImplementedError

    @abstractmethod
    def tools(self):
        raise NotImplementedError

    @abstractmethod
    def wakeups(self, include_done=True):
        raise NotImplementedError

    @abstractmethod
    def start_new_session(self):
        raise NotImplementedError

    @abstractmethod
    def load_session(self, session_id):
        raise NotImplementedError

    @abstractmethod
    def delete_session(self, session_id):
        raise NotImplementedError

    @abstractmethod
    def navigate_session(self, direction):
        raise NotImplementedError

    @abstractmethod
    def interrupt(self, reason="api"):
        raise NotImplementedError

    @abstractmethod
    def start_turn(self):
        raise NotImplementedError

    @abstractmethod
    def submit_command(self, prompt):
        raise NotImplementedError

    @abstractmethod
    def submit_message(self, message):
        raise NotImplementedError

    def submit_prompt(self, prompt):
        if not prompt or not str(prompt).strip():
            raise ValueError("prompt must not be empty")
        if str(prompt).strip().startswith("/"):
            if self.busy:
                raise RuntimeError("agent is busy")
            turn_id = self.submit_command(prompt)
            if turn_id is None:
                raise RuntimeError("agent is busy")
            return modict(command=True, queued=False, turn_id=turn_id)
        was_busy = self.busy
        result = self.submit_message(UserMessage(content=prompt))
        return modict(
            queued=was_busy,
            pending_message_id=result.message.id,
            turn_id=result.get("turn_id") or self.current_turn_id,
        )

    @abstractmethod
    def schedule_wakeup(self, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def cancel_wakeup(self, job_id):
        raise NotImplementedError

    @abstractmethod
    def delete_wakeup(self, job_id):
        raise NotImplementedError


class InProcessAgentRuntime(AgentRuntime):
    def __init__(self, agent: Agent):
        self.agent = agent

    def start(self):
        self.agent.start()
        return self

    def stop(self, timeout=None):
        self.agent.stop(timeout=timeout)
        return self

    def on_event(self, handler):
        self.agent.on("*", handler)
        return handler

    @property
    def busy(self):
        return self.agent.mainloop_manager.busy

    @property
    def current_turn_id(self):
        return self.agent.mainloop_manager.current_turn_id

    @property
    def current_session_id(self):
        return self.agent.current_session_id

    def get_status(self):
        return self.agent.status_manager.get_status()

    def config(self):
        return self.agent.config

    def update_config(self, values=None, save=True, **kwargs):
        return self.agent.config_manager.update(values, save=save, **kwargs)

    def session(self):
        return self.agent.session

    def sessions(self):
        return modict(current=self.agent.current_session_id, sessions=self.agent.get_sessions())

    def messages(self):
        return self.agent.sessions_manager.messages()

    def tools(self):
        return self.agent.tools

    def wakeups(self, include_done=True):
        return self.agent.scheduler.list(include_done=include_done)

    def start_new_session(self):
        return self.agent.start_new_session()

    def load_session(self, session_id):
        return self.agent.load_session(session_id)

    def delete_session(self, session_id):
        return modict(session_id=self.agent.delete_session(session_id))

    def navigate_session(self, direction):
        return self.agent.navigate_session(direction)

    def interrupt(self, reason="api"):
        return modict(interrupted=self.agent.interrupt(reason))

    def start_turn(self):
        if self.agent.mainloop_manager.busy:
            return None
        future = self.agent.start_turn()
        return future.id if future is not None else None

    def submit_command(self, prompt):
        future = self.agent.submit_command(prompt)
        return future.id if future is not None else None

    def submit_message(self, message):
        return self.agent.submit_message(message)

    def schedule_wakeup(self, **kwargs):
        return self.agent.scheduler.schedule(**kwargs)

    def cancel_wakeup(self, job_id):
        job = self.agent.scheduler.cancel(job_id)
        if job is None:
            raise ValueError(f"Wakeup not found: {job_id}")
        return job

    def delete_wakeup(self, job_id):
        job = self.agent.scheduler.delete(job_id)
        if job is None:
            raise ValueError(f"Wakeup not found: {job_id}")
        return job


class ProcessAgentRuntime(AgentRuntime):
    def __init__(self, agent_kwargs=None, *, command_timeout=5.0, status_timeout=0.5):
        self.agent_kwargs = dict(agent_kwargs or {})
        self.command_timeout = float(command_timeout)
        self.status_timeout = float(status_timeout)
        self.context = multiprocessing.get_context("spawn")
        self.command_queue = self.context.Queue()
        self.response_queue = self.context.Queue()
        self.event_queue = self.context.Queue()
        self.process = None
        self.event_thread = None
        self.event_handlers = []
        self.pending = {}
        self.pending_lock = threading.Lock()
        self.running = threading.Event()
        self.cache = modict(
            busy=False,
            current_turn_id=None,
            current_session_id=None,
            status=modict(),
            config=modict(),
            session=modict(),
            sessions=modict(current=None, sessions=[]),
            messages=[],
            tools=modict(),
            wakeups=[],
        )

    def start(self):
        if self.process and self.process.is_alive():
            return self
        self.running.set()
        self.process = self.context.Process(
            target=agent_worker_main,
            args=(self.command_queue, self.response_queue, self.event_queue, self.agent_kwargs),
            name="codex-agent-worker",
            daemon=True,
        )
        self.process.start()
        self.event_thread = threading.Thread(target=self._event_loop, name="agent-runtime-events", daemon=True)
        self.event_thread.start()
        try:
            self.call("start", timeout=self.command_timeout)
            self.refresh_cache()
        except Exception:
            pass
        return self

    def stop(self, timeout=None):
        timeout = timeout or 2.0
        if self.process and self.process.is_alive():
            try:
                self.call("stop", timeout=timeout)
            except Exception:
                pass
            self.running.clear()
            self.process.join(timeout)
            if self.process.is_alive():
                self.process.terminate()
                self.process.join(min(timeout, 1.0))
        else:
            self.running.clear()
        if self.event_thread and self.event_thread.is_alive() and threading.current_thread() is not self.event_thread:
            self.event_thread.join(min(timeout, 1.0))
        return self

    def on_event(self, handler):
        self.event_handlers.append(handler)
        return handler

    def refresh_cache(self):
        for key, command in (
            ("status", "get_status"),
            ("config", "config"),
            ("session", "session"),
            ("sessions", "sessions"),
            ("messages", "messages"),
            ("tools", "tools"),
            ("wakeups", "wakeups"),
        ):
            try:
                self.cache[key] = self.call(command, timeout=self.status_timeout)
            except Exception:
                pass
        status = modict(self.cache.get("status") or {})
        self.cache.busy = bool(status.get("busy", self.cache.busy))
        self.cache.current_turn_id = status.get("current_turn_id", self.cache.current_turn_id)
        self.cache.current_session_id = status.get("session_id", self.cache.current_session_id)
        return self.cache

    def call(self, name, payload=None, timeout=None):
        self.start() if not (self.process and self.process.is_alive()) else None
        command_id = str(uuid.uuid4())
        future = _RuntimeFuture(command_id)
        with self.pending_lock:
            self.pending[command_id] = future
        self.command_queue.put(modict(id=command_id, name=name, payload=payload or {}))
        try:
            return future.wait(self.command_timeout if timeout is None else timeout)
        except TimeoutError:
            with self.pending_lock:
                self.pending.pop(command_id, None)
            raise

    def _event_loop(self):
        while self.running.is_set():
            try:
                item = self.response_queue.get(timeout=0.05)
            except queue.Empty:
                item = None
            if item is not None:
                self._handle_response(modict(item))
                continue
            try:
                event = self.event_queue.get(timeout=0.1)
            except queue.Empty:
                continue
            self._handle_event(modict(event))

    def _handle_response(self, response):
        with self.pending_lock:
            future = self.pending.pop(response.get("id"), None)
        if future is None:
            return
        if response.get("ok"):
            future.set_result(modict(response.get("result")) if isinstance(response.get("result"), dict) else response.get("result"))
        else:
            future.set_error(AgentRuntimeError(response.get("error") or "agent worker command failed"))

    def _handle_event(self, event):
        event_type = event.get("type")
        if event_type == "assistant_turn_start_event":
            self.cache.busy = True
        elif event_type in ("assistant_turn_end_event", "assistant_turn_error_event"):
            self.cache.busy = False
            self.cache.current_turn_id = None
        elif event_type == "session_loaded_event":
            self.cache.current_session_id = event.get("session_id")
            self.cache.session = event.get("session") or self.cache.session
        elif event_type == "compaction_completed_event" and event.get("status"):
            status = modict(event.status)
            self.cache.status = status
            self.cache.busy = bool(status.get("busy", self.cache.busy))
            self.cache.current_turn_id = status.get("current_turn_id", self.cache.current_turn_id)
            self.cache.current_session_id = status.get("session_id", self.cache.current_session_id)
        for handler in list(self.event_handlers):
            handler(event)

    @property
    def busy(self):
        return bool(self.cache.busy)

    @property
    def current_turn_id(self):
        return self.cache.current_turn_id

    @property
    def current_session_id(self):
        return self.cache.current_session_id

    def get_status(self):
        try:
            status = modict(self.call("get_status", timeout=self.status_timeout))
            self.cache.status = status
            self.cache.busy = bool(status.get("busy", self.cache.busy))
            self.cache.current_turn_id = status.get("current_turn_id", self.cache.current_turn_id)
            self.cache.current_session_id = status.get("session_id", self.cache.current_session_id)
            return status
        except Exception:
            status = modict(self.cache.status or {})
            status.setdefault("busy", self.cache.busy)
            status.setdefault("current_turn_id", self.cache.current_turn_id)
            return status

    def config(self):
        return self._cached_call("config")

    def update_config(self, values=None, save=True, **kwargs):
        payload = dict(values or {})
        payload.update(kwargs)
        result = self.call("update_config", {"values": payload, "save": save}, timeout=self.command_timeout)
        self.cache.config = result
        return result

    def session(self):
        return self._cached_call("session")

    def sessions(self):
        return self._cached_call("sessions")

    def messages(self):
        return self._cached_call("messages")

    def tools(self):
        return self._cached_call("tools")

    def wakeups(self, include_done=True):
        return self._cached_call("wakeups", include_done=include_done)

    def start_new_session(self):
        result = self.call("start_new_session", timeout=self.command_timeout)
        self.refresh_cache()
        return result

    def load_session(self, session_id):
        result = self.call("load_session", {"session_id": session_id}, timeout=self.command_timeout)
        self.refresh_cache()
        return result

    def delete_session(self, session_id):
        result = self.call("delete_session", {"session_id": session_id}, timeout=self.command_timeout)
        self.refresh_cache()
        return result

    def navigate_session(self, direction):
        result = self.call("navigate_session", {"direction": direction}, timeout=self.command_timeout)
        self.refresh_cache()
        return result

    def interrupt(self, reason="api"):
        try:
            return self.call("interrupt", {"reason": reason}, timeout=1.0)
        except Exception as exc:
            return modict(interrupted=False, interrupt_requested=True, error=str(exc))

    def start_turn(self):
        if self.busy:
            return None
        turn_id = self.call("start_turn", timeout=1.0)
        if turn_id is not None:
            self.cache.busy = True
            self.cache.current_turn_id = turn_id
        return turn_id

    def submit_command(self, prompt):
        if self.busy:
            return None
        turn_id = self.call("submit_command", {"prompt": prompt}, timeout=1.0)
        if turn_id is not None:
            self.cache.busy = True
            self.cache.current_turn_id = turn_id
        return turn_id

    def submit_message(self, message):
        result = self.call("submit_message", {"message": message}, timeout=1.0)
        turn_id = result.get("turn_id") if isinstance(result, dict) else None
        if turn_id is not None:
            self.cache.busy = True
            self.cache.current_turn_id = turn_id
        return result

    def schedule_wakeup(self, **kwargs):
        return self.call("schedule_wakeup", kwargs, timeout=self.command_timeout)

    def cancel_wakeup(self, job_id):
        return self.call("cancel_wakeup", {"job_id": job_id}, timeout=self.command_timeout)

    def delete_wakeup(self, job_id):
        return self.call("delete_wakeup", {"job_id": job_id}, timeout=self.command_timeout)

    def _cached_call(self, name, **payload):
        try:
            result = self.call(name, payload, timeout=self.status_timeout)
            self.cache[name.replace("get_", "")] = result
            return result
        except Exception:
            return self.cache.get(name.replace("get_", ""), modict())


class _RuntimeFuture:
    def __init__(self, command_id):
        self.command_id = command_id
        self.done = threading.Event()
        self.result = None
        self.error = None

    def set_result(self, result):
        self.result = result
        self.done.set()

    def set_error(self, error):
        self.error = error
        self.done.set()

    def wait(self, timeout=None):
        if not self.done.wait(timeout):
            raise TimeoutError(f"Agent worker command {self.command_id} did not finish before timeout")
        if self.error is not None:
            raise self.error
        return self.result


def agent_worker_main(command_queue, response_queue, event_queue, agent_kwargs):
    agent = Agent(**dict(agent_kwargs or {}))

    def emit_event(event):
        event_queue.put(event_payload(event))

    agent.on("*", emit_event)

    while True:
        command = modict(command_queue.get())
        command_id = command.get("id")
        try:
            result = run_worker_command(agent, command.get("name"), modict(command.get("payload") or {}))
        except Exception as exc:
            response_queue.put(modict(id=command_id, ok=False, error=str(exc)))
            if command.get("name") == "stop":
                break
        else:
            response_queue.put(modict(id=command_id, ok=True, result=jsonable(result)))
            if command.get("name") == "stop":
                break


def event_payload(event):
    if isinstance(event, Event):
        payload = event.copy()
    elif isinstance(event, (dict, modict)):
        payload = modict(event)
    else:
        payload = modict(type=type(event).__name__, value=str(event))
    payload.setdefault("type", getattr(event, "type", type(event).__name__))
    return jsonable(payload)


def run_worker_command(agent, name, payload):
    if name == "start":
        return agent.start()
    if name == "stop":
        return agent.stop(timeout=1.0)
    if name == "get_status":
        status = agent.status_manager.get_status()
        status.busy = agent.mainloop_manager.busy
        status.current_turn_id = agent.mainloop_manager.current_turn_id
        status.session_id = agent.current_session_id
        return status
    if name == "config":
        return agent.config
    if name == "update_config":
        return agent.config_manager.update(payload.get("values") or {}, save=payload.get("save", True))
    if name == "session":
        return agent.session
    if name == "sessions":
        return modict(current=agent.current_session_id, sessions=agent.get_sessions())
    if name == "messages":
        return agent.sessions_manager.messages()
    if name == "tools":
        return agent.tools
    if name == "wakeups":
        return agent.scheduler.list(include_done=payload.get("include_done", True))
    if name == "start_new_session":
        return agent.start_new_session()
    if name == "load_session":
        return agent.load_session(payload.session_id)
    if name == "delete_session":
        return modict(session_id=agent.delete_session(payload.session_id))
    if name == "navigate_session":
        return agent.navigate_session(payload.direction)
    if name == "interrupt":
        return modict(interrupted=agent.interrupt(payload.get("reason", "api")))
    if name == "start_turn":
        if agent.mainloop_manager.busy:
            return None
        future = agent.start_turn()
        return future.id if future is not None else None
    if name == "submit_command":
        future = agent.submit_command(payload.prompt)
        return future.id if future is not None else None
    if name == "submit_message":
        message = message_from_data(payload.message)
        return agent.submit_message(message)
    if name == "schedule_wakeup":
        return agent.scheduler.schedule(**payload)
    if name == "cancel_wakeup":
        job = agent.scheduler.cancel(payload.job_id)
        if job is None:
            raise ValueError(f"Wakeup not found: {payload.job_id}")
        return job
    if name == "delete_wakeup":
        job = agent.scheduler.delete(payload.job_id)
        if job is None:
            raise ValueError(f"Wakeup not found: {payload.job_id}")
        return job
    raise ValueError(f"Unknown agent runtime command: {name}")
