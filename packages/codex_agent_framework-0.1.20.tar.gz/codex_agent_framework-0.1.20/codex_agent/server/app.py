import json

from ..agent import Agent
from ..agent_runtime import InProcessAgentRuntime, ProcessAgentRuntime
from .core import AgentServer, create_server_agent, remembered_server_session

def create_app(agent: Agent | None = None, start_agent=False, process_agent=False, **agent_kwargs):
    from contextlib import asynccontextmanager

    from fastapi import FastAPI, HTTPException, Request
    from fastapi.responses import StreamingResponse
    from pydantic import BaseModel

    if process_agent and agent is None:
        if "session" not in agent_kwargs:
            agent_kwargs["session"] = remembered_server_session() or "latest"
        runtime = ProcessAgentRuntime(agent_kwargs=agent_kwargs)
    else:
        runtime = InProcessAgentRuntime(agent or create_server_agent(**agent_kwargs))
    service = AgentServer(runtime=runtime)
    if start_agent:
        service.start()

    @asynccontextmanager
    async def lifespan(app):
        try:
            yield
        finally:
            service.stop(timeout=1.0)

    app = FastAPI(title="Codex Agent", version="0.1.20", lifespan=lifespan)
    app.state.agent_service = service

    class TurnRequest(BaseModel):
        prompt: str

    class InterruptRequest(BaseModel):
        reason: str = "api"

    class ConfigUpdateRequest(BaseModel):
        values: dict = {}
        save: bool = True

    class WakeupRequest(BaseModel):
        prompt: str
        run_at: str | None = None
        delay_seconds: float | None = None
        interval_seconds: float | None = None
        title: str = ""

    class RestartRequest(BaseModel):
        prompt: str | None = None
        title: str = "post-restart wakeup"

    def jsonable(value):
        return json.loads(json.dumps(value, ensure_ascii=False, default=str))

    def busy_guard(call):
        try:
            return call()
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/health")
    def health():
        return {"ok": True, "busy": service.busy, "session_id": service.current_session_id}

    @app.get("/status")
    def status():
        return jsonable(service.status())

    @app.get("/config")
    def config():
        return jsonable(service.config())

    @app.patch("/config")
    def update_config(request: ConfigUpdateRequest):
        return jsonable(busy_guard(lambda: service.update_config(request.values, save=request.save)))

    @app.get("/session")
    def session():
        return jsonable(service.session())

    @app.get("/sessions")
    def sessions():
        return jsonable(service.sessions())

    @app.post("/sessions/new")
    def start_new_session():
        return jsonable(busy_guard(service.start_new_session))

    @app.post("/sessions/{session_id}/load")
    def load_session(session_id: str):
        return jsonable(busy_guard(lambda: service.load_session(session_id)))

    @app.delete("/sessions/{session_id}")
    def delete_session(session_id: str):
        return jsonable(busy_guard(lambda: service.delete_session(session_id)))

    @app.post("/sessions/navigate/{direction}")
    def navigate_session(direction: str):
        return jsonable(busy_guard(lambda: service.navigate_session(direction)))

    @app.get("/messages")
    def messages():
        return jsonable(service.messages())

    @app.get("/tools")
    def tools():
        return jsonable(service.tools())

    @app.get("/tui")
    def tui():
        return jsonable(service.tui())

    @app.post("/tui/open")
    def open_tui(request: Request):
        base_url = str(request.base_url).rstrip("/")
        return jsonable(busy_guard(lambda: service.open_tui(base_url=base_url)))

    @app.post("/tui/close")
    def close_tui():
        return jsonable(service.close_tui())

    @app.post("/restart")
    @app.post("/restart/")
    def restart(request: RestartRequest):
        return jsonable(busy_guard(lambda: service.restart(**request.model_dump())))

    @app.get("/wakeups")
    def wakeups(include_done: bool = True):
        return jsonable(service.wakeups(include_done=include_done))

    @app.post("/wakeups", status_code=201)
    def schedule_wakeup(request: WakeupRequest):
        return jsonable(busy_guard(lambda: service.schedule_wakeup(**request.model_dump())))

    @app.post("/wakeups/{job_id}/cancel")
    def cancel_wakeup(job_id: str):
        return jsonable(busy_guard(lambda: service.cancel_wakeup(job_id)))

    @app.delete("/wakeups/{job_id}")
    def delete_wakeup(job_id: str):
        return jsonable(busy_guard(lambda: service.delete_wakeup(job_id)))

    @app.post("/turns", status_code=202)
    def turns(request: TurnRequest):
        result = busy_guard(lambda: service.submit_prompt(request.prompt))
        return {"accepted": True, **jsonable(result)}

    @app.post("/interrupt")
    def interrupt(request: InterruptRequest):
        return jsonable(service.interrupt(request.reason))

    @app.get("/events")
    def events(limit: int | None = None, after_sequence: int | None = None, client_pid: int | None = None):
        try:
            subscription = service.subscribe(after_sequence=after_sequence, client_pid=client_pid)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

        def stream():
            count = 0
            for payload in subscription:
                lines = []
                if payload.get("id"):
                    lines.append(f"id: {payload.id}")
                lines.append(f"event: {payload.get('type', 'message')}")
                lines.append(f"data: {json.dumps(payload, ensure_ascii=False, default=str)}")
                yield "\n".join(lines) + "\n\n"
                count += 1
                if limit is not None and count >= limit:
                    break
        return StreamingResponse(stream(), media_type="text/event-stream")

    @app.get("/events/replay")
    def replay_events(before_sequence: int | None = None, session_id: str | None = None):
        return jsonable(service.replay_events(before_sequence=before_sequence, session_id=session_id))

    return app


app = None


def main():
    import uvicorn

    global app
    app = create_app(start_agent=True, process_agent=True)
    uvicorn.run(app, host="127.0.0.1", port=8765, timeout_graceful_shutdown=2)


if __name__ == "__main__":
    main()
