import hashlib
import importlib.util
import inspect
import os
import shlex
import sys
import uuid
from threading import Event as ThreadEvent

from modict import modict

from .utils import runtime_join


COMMAND_MARKER = "__codex_agent_command__"


def command(func=None, **options):
    """Mark a function as an agent slash command for automatic discovery."""
    if func is None:
        def decorator(f):
            return command(f, **options)
        return decorator

    setattr(func, COMMAND_MARKER, modict(options))
    return func


def command_options(func):
    options = getattr(func, COMMAND_MARKER, None)
    if options is not None:
        return options
    return getattr(getattr(func, "__func__", None), COMMAND_MARKER, None)


class AgentCommand(modict):
    _config = modict.config(require_all="never")

    type = "agent_command"
    id = modict.factory(lambda: str(uuid.uuid4()))
    name = ""
    payload = modict.factory(modict)


class AgentFuture(modict):
    _config = modict.config(require_all="never")

    type = "agent_future"
    id = modict.factory(lambda: str(uuid.uuid4()))
    command_id = ""
    command = ""
    status = "pending"
    result = None
    error = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_attr("done_event", ThreadEvent())

    def set_result(self, result):
        self.result = result
        self.status = "done"
        self.done_event.set()
        return self

    def set_error(self, error):
        self.error = str(error)
        self.status = "error"
        self.set_attr("error_obj", error)
        self.done_event.set()
        return self

    def wait(self, timeout=None):
        if not self.done_event.wait(timeout):
            raise TimeoutError(f"Agent command {self.command_id} did not finish before timeout")
        if self.status == "error":
            error = self.get_attr("error_obj", None)
            if error:
                raise error
            raise RuntimeError(self.error)
        return self.result


class CommandManager:
    def __init__(self, agent):
        self.agent = agent
        self.commands = modict()

    def init_folder(self):
        commands_folder = runtime_join("commands")
        if not os.path.isdir(commands_folder):
            os.makedirs(commands_folder, exist_ok=True)
        return commands_folder

    def init_builtin(self):
        from . import builtin_commands
        self.add_from_module(builtin_commands)

    def init_runtime(self):
        commands_folder = self.init_folder()
        if commands_folder not in sys.path:
            sys.path.insert(0, commands_folder)

        for filename in sorted(os.listdir(commands_folder)):
            if not filename.endswith(".py") or filename.startswith("_"):
                continue
            module = self.load_runtime_module(os.path.join(commands_folder, filename))
            self.add_from_module(module)

    def load_runtime_module(self, path):
        digest = hashlib.sha1(os.path.abspath(path).encode()).hexdigest()[:12]
        module_name = f"codex_agent_runtime_command_{os.path.splitext(os.path.basename(path))[0]}_{digest}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            raise RuntimeError(f"Failed to load runtime command module {path}: {exc}") from exc
        return module

    def add_from_module(self, module):
        for obj in module.__dict__.values():
            self.add_object(obj)

    def add_from_object(self, obj):
        for _, member in inspect.getmembers(obj):
            self.add_object(member)

    def add_object(self, obj):
        options = command_options(obj)
        if options is not None:
            self.add(obj, **options)

    def add(self, func=None, name=None):
        """Register a slash command.

        Command arguments are parsed shell-style and mapped to the handler
        signature, including ``*args`` and ``**kwargs``.
        They can access the current agent with ``get_agent()``.
        """
        if func is None:
            def decorator(f):
                return self.add(f, name=name)
            return decorator

        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("add_command", func=func, name=name).wait()

        command_name = name or getattr(func, "__name__", None) or f"command_{len(self.commands)}"
        self.commands[command_name] = func
        return func

    def submit(self, prompt):
        if not self.is_prompt(prompt):
            raise ValueError("prompt must be a slash command")
        if self.agent.busy:
            return None
        return self.agent.submit("command", prompt=prompt)

    def is_prompt(self, prompt):
        return isinstance(prompt, str) and prompt.strip().startswith("/")

    def run_turn(self, prompt):
        from .event import AssistantTurnEndEvent, AssistantTurnErrorEvent, AssistantTurnStartEvent

        self.agent.emit(AssistantTurnStartEvent, prompt=prompt)
        try:
            result = self.run(prompt)
            self.agent.emit(AssistantTurnEndEvent, prompt=prompt, result=result)
            return result
        except Exception as exc:
            self.agent.emit(AssistantTurnErrorEvent, prompt=prompt, error=str(exc))
            raise

    def run(self, prompt):
        from .tool import reset_current_agent, set_current_agent

        text = prompt.strip()
        name, _, args = text[1:].partition(" ")
        if not name:
            return None
        command_func = self.commands.get(name)
        if command_func is None:
            raise ValueError(f"Unknown command: /{name}")

        agent_context = set_current_agent(self.agent)
        try:
            positional_args, keyword_args = self.parse_args(args)
            bound_args, bound_kwargs = self.bind_args(command_func, positional_args, keyword_args)
            return command_func(*bound_args, **bound_kwargs)
        finally:
            reset_current_agent(agent_context)

    def parse_args(self, args):
        positional = []
        keyword = {}
        for token in shlex.split(args):
            if token.startswith("--"):
                option = token[2:]
                key, separator, value = option.partition("=")
                keyword[key.replace("-", "_")] = value if separator else True
            elif "=" in token:
                key, value = token.split("=", 1)
                keyword[key.replace("-", "_")] = value
            else:
                positional.append(token)
        return positional, keyword

    def bind_args(self, command_func, positional_args, keyword_args):
        signature = inspect.signature(command_func)
        args = []
        kwargs = {}
        position = 0
        remaining_kwargs = dict(keyword_args)

        for parameter in signature.parameters.values():
            if parameter.kind == inspect.Parameter.VAR_POSITIONAL:
                args.extend(positional_args[position:])
                position = len(positional_args)
                continue
            if parameter.kind == inspect.Parameter.VAR_KEYWORD:
                kwargs.update(remaining_kwargs)
                remaining_kwargs.clear()
                continue
            if parameter.kind == inspect.Parameter.KEYWORD_ONLY:
                if parameter.name in remaining_kwargs:
                    kwargs[parameter.name] = remaining_kwargs.pop(parameter.name)
                continue

            if parameter.name in remaining_kwargs:
                kwargs[parameter.name] = remaining_kwargs.pop(parameter.name)
            elif position < len(positional_args):
                args.append(positional_args[position])
                position += 1

        args.extend(positional_args[position:])
        kwargs.update(remaining_kwargs)
        signature.bind(*args, **kwargs)
        return args, kwargs
