import json
import os
import uuid
from datetime import datetime, timedelta, timezone
from threading import Event as ThreadEvent, Thread

from modict import modict

from .event import WakeupCancelledEvent, WakeupScheduledEvent, WakeupTriggeredEvent
from .message import UserMessage

from .utils import atomic_write_json, runtime_join


class WakeupJob(modict):
    _config = modict.config(enforce_json=True, require_all="never")

    id = modict.factory(lambda: str(uuid.uuid4()))
    title = ""
    prompt = ""
    run_at = ""
    interval_seconds = None
    status = "pending"
    created_at = modict.factory(lambda: utc_now_iso())
    updated_at = ""
    last_run_at = None
    run_count = 0

    @property
    def due_at(self):
        return parse_datetime(self.get("run_at"))

    @property
    def is_periodic(self):
        interval = self.get("interval_seconds")
        return interval is not None and float(interval) > 0


def utc_now():
    return datetime.now(timezone.utc)


def utc_now_iso():
    return utc_now().isoformat()


def parse_datetime(value):
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, str):
        text = value.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
    else:
        raise TypeError(f"Expected datetime or ISO datetime string, got {type(value).__name__}")
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def next_run_at(run_at=None, delay_seconds=None):
    if run_at:
        return parse_datetime(run_at).isoformat()
    if delay_seconds is None:
        raise ValueError("Either run_at or delay_seconds must be provided")
    return (utc_now() + timedelta(seconds=float(delay_seconds))).isoformat()


class AgentScheduler:
    """Persistent wakeup scheduler that submits prompts to the Agent runtime."""

    def __init__(self, agent, file=None, poll_interval=0.5, busy_retry_seconds=30):
        self.agent = agent
        self.file = file or runtime_join("wakeups.json")
        self.poll_interval = poll_interval
        self.busy_retry_seconds = busy_retry_seconds
        self.jobs = modict()
        self.thread = None
        self._stop_requested = ThreadEvent()
        self.load()

    @property
    def running(self):
        return self.thread is not None and self.thread.is_alive()

    def load(self):
        if not os.path.isfile(self.file):
            self.jobs = modict()
            return self.jobs
        with open(self.file, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.jobs = modict({item["id"]: WakeupJob(item) for item in data})
        return self.jobs

    def save(self):
        atomic_write_json(self.file, list(self.jobs.values()))
        return self.jobs

    def start(self):
        if self.running:
            return self
        self._stop_requested.clear()
        self.thread = Thread(target=self.loop, name="agent-scheduler", daemon=True)
        self.thread.start()
        return self

    def stop(self, timeout=None):
        self._stop_requested.set()
        if self.thread:
            self.thread.join(timeout)
        return self

    def schedule(self, prompt, run_at=None, delay_seconds=None, interval_seconds=None, title=""):
        if not prompt or not str(prompt).strip():
            raise ValueError("prompt must not be empty")
        if interval_seconds is not None and float(interval_seconds) <= 0:
            raise ValueError("interval_seconds must be positive")
        job = WakeupJob(
            title=title or "scheduled wakeup",
            prompt=str(prompt),
            run_at=next_run_at(run_at=run_at, delay_seconds=delay_seconds),
            interval_seconds=float(interval_seconds) if interval_seconds is not None else None,
            updated_at=utc_now_iso(),
        )
        self.jobs[job.id] = job
        self.save()
        self.emit_wakeup_scheduled(job)
        return job

    def cancel(self, job_id):
        job = self.jobs.get(job_id)
        if job is None:
            return None
        job.status = "cancelled"
        job.updated_at = utc_now_iso()
        self.save()
        self.emit_wakeup_cancelled(job)
        return job

    def delete(self, job_id):
        job = self.jobs.pop(job_id, None)
        if job is not None:
            self.save()
        return job

    def list(self, include_done=True):
        jobs = list(self.jobs.values())
        if not include_done:
            jobs = [job for job in jobs if job.status == "pending"]
        return sorted(jobs, key=lambda job: job.run_at)

    def due_jobs(self, now=None):
        now = now or utc_now()
        return [
            job for job in self.jobs.values()
            if job.status == "pending" and job.due_at <= now
        ]

    def loop(self):
        while not self._stop_requested.is_set():
            self.tick()
            self._stop_requested.wait(self.poll_interval)

    def tick(self, now=None):
        due = self.due_jobs(now=now)
        for job in due:
            self.trigger(job)
        return due

    def trigger(self, job):
        if self.agent.busy:
            job.run_at = (utc_now() + timedelta(seconds=self.busy_retry_seconds)).isoformat()
            job.updated_at = utc_now_iso()
            self.save()
            return None

        job.last_run_at = utc_now_iso()
        job.run_count = int(job.run_count or 0) + 1
        job.updated_at = utc_now_iso()
        if job.is_periodic:
            job.run_at = (utc_now() + timedelta(seconds=float(job.interval_seconds))).isoformat()
        else:
            job.status = "completed"
        self.save()

        prompt = self.wakeup_prompt(job)
        result = self.agent.submit_message(UserMessage(content=prompt))
        turn_id = result.get("turn_id")
        self.emit_wakeup_triggered(job, turn_id=turn_id)
        return turn_id

    def emit_wakeup_scheduled(self, job):
        return self.agent.emit(WakeupScheduledEvent, job=job)

    def emit_wakeup_triggered(self, job, turn_id=None):
        return self.agent.emit(WakeupTriggeredEvent, job=job, turn_id=turn_id, future=turn_id)

    def emit_wakeup_cancelled(self, job):
        return self.agent.emit(WakeupCancelledEvent, job=job)

    def wakeup_prompt(self, job):
        title = f" ({job.title})" if job.title else ""
        return (
            f"Scheduled wakeup{title}.\n"
            f"Wakeup id: {job.id}\n"
            f"Original scheduled prompt:\n{job.prompt}"
        )
