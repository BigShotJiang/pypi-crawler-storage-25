from modict import modict
from .utils import snake_case_type, timestamp


class AssistantInterrupted(Exception):
    """Raised internally when the current assistant turn is interrupted."""


class Event(modict):
    """Base runtime event."""

    timestamp = modict.factory(lambda: timestamp())

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self['type'] = snake_case_type(type(self))


class AssistantTurnStartEvent(Event):
    prompt = None
    message = None


class AssistantTurnEndEvent(Event):
    prompt = None
    message = None
    result = None


class AssistantTurnErrorEvent(Event):
    prompt = None
    message = None
    error = ''


class AssistantStepStartEvent(Event):
    message = None


class AssistantStepEndEvent(Event):
    message = None
    called_tools = False
    require_next_step = False
    stop_agentic_loop = False


class ResponseStartEvent(Event):
    message = None


class ResponseContentDeltaEvent(Event):
    delta = ''


class ResponseReasoningDeltaEvent(Event):
    delta = ''


class ResponseToolCallsDeltaEvent(Event):
    tool_calls = None


class ResponseOutputItemEvent(Event):
    item = None
    chunk = None
    message = None


class ResponseMessageDeltaEvent(Event):
    delta = None


class ResponseDoneEvent(Event):
    message = None


class MessageAddedEvent(Event):
    message = None


class MessageSubmittedEvent(Event):
    message = None
    turn_id = None


class CompactionRequestedEvent(Event):
    compacted_message_count = 0
    compacted_token_count = 0
    context_message_count = 0
    total_session_messages = 0


class CompactionCompletedEvent(Event):
    message = None
    compacted_message_count = 0
    compacted_token_count = 0
    post_compaction_message_count = 0
    total_session_messages = 0


class SessionLoadedEvent(Event):
    session = None
    session_id = ''


class SessionDeletedEvent(Event):
    session_id = ''


class AssistantInterruptRequestedEvent(Event):
    reason = ''
    interrupted = True
    error = ''

class WakeupScheduledEvent(Event):
    job = None

class WakeupTriggeredEvent(Event):
    job = None
    turn_id = None
    future = None

class WakeupCancelledEvent(Event):
    job = None

class MemoryArchiveErrorEvent(Event):
    error = ''
    end_message_id = ''

class ToolCallStartEvent(Event):
    tool_call = None
    tool = None

class ToolCallDoneEvent(Event):
    tool_call = None
    tool = None
    content = ''

class ServerToolCallEvent(Event):
    item = None
    tool = None
    name = ''
    call_id = ''
    status = ''

class AssistantInterruptedEvent(Event):
    reason = ''

class AudioPlaybackEvent(Event):
    audio = None

class EventBus:
    """Small synchronous event bus with decorator registration."""

    def __init__(self):
        self.handlers = {}

    def event_type(self, event):
        if event == '*':
            return event
        if isinstance(event, type) and issubclass(event, Event):
            return snake_case_type(event)
        if isinstance(event, Event):
            return event.type
        raise TypeError(f"Expected Event subclass, Event instance, or '*', got {type(event).__name__}")

    def on(self, event, handler=None):
        event_type = self.event_type(event)
        if handler is None:
            def decorator(func):
                self.handlers.setdefault(event_type, []).append(func)
                return func
            return decorator

        self.handlers.setdefault(event_type, []).append(handler)
        return handler

    def off(self, event, handler):
        handlers = self.handlers.get(self.event_type(event))
        if handlers and handler in handlers:
            handlers.remove(handler)
        return handler

    def has_handlers(self, event, include_wildcard=True):
        event_type = self.event_type(event)
        return bool(self.handlers.get(event_type) or (include_wildcard and self.handlers.get('*')))

    def emit(self, event, **data):
        if isinstance(event, type) and issubclass(event, Event):
            event = event(**data)
        elif not isinstance(event, Event):
            raise TypeError(f"Expected Event subclass or Event instance, got {type(event).__name__}")

        event_type = event.type
        for handler in self.handlers.get(event_type, ()):
            handler(event)
        for handler in self.handlers.get('*', ()):
            handler(event)
        return event
