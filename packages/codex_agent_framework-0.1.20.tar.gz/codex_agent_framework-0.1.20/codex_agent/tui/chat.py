import os
import sys

from rich.text import Text

from ..client import AgentClient
from ..event import (
    AssistantStepEndEvent,
    AssistantStepStartEvent,
    AssistantTurnEndEvent,
    AssistantTurnErrorEvent,
    AssistantTurnStartEvent,
    CompactionCompletedEvent,
    MessageAddedEvent,
    ResponseContentDeltaEvent,
    ServerToolCallEvent,
    ToolCallStartEvent,
)
from .lifecycle import clear_tui, install_tui_cleanup_handlers, register_tui


class Chat:
    """Textual-based chat UI client for a codex-agent server."""

    CSS = """
    Screen {
        background: #000000;
        color: #aeb0aa;
    }
    #main {
        height: 100%;
        padding: 0 1;
        background: #000000;
    }
    #conversation {
        height: 1fr;
        padding: 1 1;
        background: #000000;
        scrollbar-background: #000000;
        scrollbar-background-hover: #000000;
        scrollbar-background-active: #000000;
        scrollbar-color: #202020;
        scrollbar-color-hover: #2a2a2a;
        scrollbar-color-active: #343434;
    }
    #status {
        height: 1;
        color: #8b949e;
        background: #161b22;
        padding: 0 1;
    }
    #input {
        height: 3;
        margin-top: 0;
        padding: 0 1;
        background: #000000;
        color: #aeb0aa;
        border: blank #000000;
        scrollbar-size-vertical: 1;
        scrollbar-size-horizontal: 0;
        scrollbar-background: #000000;
        scrollbar-background-hover: #000000;
        scrollbar-background-active: #000000;
        scrollbar-color: #202020;
        scrollbar-color-hover: #2a2a2a;
        scrollbar-color-active: #343434;
    }
    TextArea > .text-area--cursor {
        background: #6f98bd;
        color: #0d1117;
    }
    Footer {
        background: #000000;
        color: #7d8590;
    }
    """

    def __init__(self, client=None, base_url="http://127.0.0.1:8765"):
        self.client = client or AgentClient(base_url=base_url)
        self.app = None
        self._seen_tool_calls = set()
        self._agent_buffer = ""
        self._pending_tools = []
        self._transcript = []
        self._last_role = None
        self._seen_event_ids = set()
        self._server_connected = False
        self._server_error = ""
        self._replaying_events = False
        self._replay_delta_buffer = ""

    @property
    def agent(self):
        # Compatibility shim for tests/older call sites that only read config/status.
        return self.client

    def attach(self):
        self.client.on(AssistantTurnStartEvent, self._once(self._on_assistant_turn_start))
        self.client.on(AssistantStepStartEvent, self._once(self._on_assistant_step_start))
        self.client.on(AssistantStepEndEvent, self._once(self._on_assistant_step_end))
        self.client.on(AssistantTurnEndEvent, self._once(self._on_assistant_turn_end))
        self.client.on(AssistantTurnErrorEvent, self._once(self._on_assistant_turn_error))
        self.client.on(CompactionCompletedEvent, self._once(self._on_compaction_completed))
        self.client.on(MessageAddedEvent, self._once(self._on_message_added))
        self.client.on(ResponseContentDeltaEvent, self._once(self._on_content_delta))
        self.client.on(ToolCallStartEvent, self._once(self._on_tool_call_start))
        self.client.on(ServerToolCallEvent, self._once(self._on_server_tool_call))
        self.client.on("server_connected", self._on_server_connected)
        self.client.on("server_offline", self._on_server_offline)
        self.client.on("server_subscribed", self._on_server_subscribed)
        self.client.on("turn_error", self._on_turn_error)
        self.client.on("client_event_error", self._on_client_event_error)
        return self

    def _on_server_connected(self, event):
        self._mark_server_connected(announce=True)
        self._call_app("refresh_status")

    def _mark_server_connected(self, announce=False):
        was_offline = not self._server_connected
        self._server_connected = True
        self._server_error = ""
        if announce and was_offline:
            self._call_app("write_info", "server connected")

    def _on_server_offline(self, event):
        was_connected = self._server_connected
        self._server_connected = False
        self._server_error = event.get("error", "")
        if was_connected:
            self._call_app("write_info", "server offline")
        self._call_app("refresh_status")

    def _on_server_subscribed(self, event):
        self._mark_server_connected(announce=event.get("after_sequence") is not None)
        register_tui(base_url=self.client.base_url)
        self.replay_startup_events(event.get("replay_before_sequence"), session_id=event.get("session_id"))

    def replay_startup_events(self, before_sequence=None, session_id=None):
        try:
            replay = self.client.replay_events(before_sequence=before_sequence, session_id=session_id)
        except Exception as exc:
            self._call_app("write_error", f"failed to replay session events: {exc}")
            return
        self._replaying_events = True
        self._replay_delta_buffer = ""
        try:
            for event in replay.get("events") or []:
                self.client.remember_event_sequence(event)
                self.client.emit_local(event)
        finally:
            self._flush_replay_delta_buffer()
            self._replaying_events = False

    def _on_compaction_completed(self, event):
        self._mark_server_connected()
        self._call_app("refresh_status")

    def run(self):
        from textual.app import App, ComposeResult
        from textual.containers import Vertical
        from textual.widgets import Footer, RichLog, Static, TextArea

        chat = self

        class AgentTextualApp(App):
            CSS = chat.CSS
            TITLE = "Codex Agent"
            BINDINGS = [
                ("ctrl+c", "interrupt", "Interrupt"),
                ("ctrl+l", "clear", "Clear"),
                ("ctrl+q", "quit", "Quit"),
                ("ctrl+s", "submit", "Submit"),
                ("alt+enter", "submit", "Submit"),
                ("ctrl+enter", "submit", "Submit"),
                ("f2", "submit", "Submit"),
            ]

            def compose(self) -> ComposeResult:
                with Vertical(id="main"):
                    yield RichLog(id="conversation", wrap=True, highlight=False, markup=True)
                    yield Static("", id="status")
                    yield TextArea(
                        "",
                        placeholder="› message  ·  Enter = newline  ·  Ctrl+S/F2 = send  ·  Ctrl+Q = quit",
                        id="input",
                        show_line_numbers=False,
                        soft_wrap=True,
                    )
                yield Footer()

            def on_mount(self):
                chat.app = self
                install_tui_cleanup_handlers()
                chat.attach()
                chat.client.start_events()
                self.refresh_status()
                self.resize_input()
                self.query_one("#input", TextArea).focus()
                self.write_info("Codex Agent client ready.")

            def action_quit(self):
                clear_tui(pid=os.getpid())
                chat.client.stop(timeout=0.2)
                self.exit()

            def on_unmount(self):
                clear_tui(pid=os.getpid())

            def action_submit(self):
                input_widget = self.query_one("#input", TextArea)
                prompt = input_widget.text
                command = prompt.strip().lower()
                if not command:
                    return
                if command in ["exit", "quit", "/exit", "/quit"]:
                    self.exit()
                    return
                if command == "/clear":
                    input_widget.load_text("")
                    self.action_clear()
                    return
                input_widget.load_text("")
                self.refresh_status()
                self.run_worker(lambda: self._submit_prompt(prompt), thread=True)

            def on_text_area_changed(self, event: TextArea.Changed):
                if event.text_area.id == "input":
                    self.resize_input()

            def resize_input(self):
                input_widget = self.query_one("#input", TextArea)
                input_widget.styles.height = chat.composer_height(input_widget.text)

            def _submit_prompt(self, prompt):
                try:
                    chat.client.submit_prompt(prompt)
                except Exception as exc:
                    self.call_from_thread(self.write_error, str(exc))
                finally:
                    self.call_from_thread(self.refresh_status)

            def action_clear(self):
                chat._transcript.clear()
                chat._last_role = None
                self.query_one("#conversation", RichLog).clear()
                self.write_info("screen cleared · session history preserved")
                self.refresh_status()

            def action_interrupt(self):
                result = chat.client.interrupt("keyboard_interrupt")
                if result.get("error"):
                    self.write_error(f"interrupt requested · {result.error}")
                else:
                    self.write_error("interrupt requested")

            def log_width(self):
                raw_width = self.query_one("#conversation", RichLog).size.width or 80
                return max(32, raw_width - 6)

            def speaker_rule(self, name, style):
                width = self.log_width()
                label = f" {name} "
                available = max(2, width - len(label))
                left = available // 2
                right = available - left
                line = "─" * left + label + "─" * right
                return Text(line, style=style)

            def qed_marker(self, style="#6f98bd"):
                return Text(" " * max(0, self.log_width() - 1) + "▪", style=style)

            def render_transcript(self):
                log = self.query_one("#conversation", RichLog)
                log.clear()
                for entry in chat._transcript:
                    kind = entry[0]
                    if kind == "speaker":
                        _, name, style = entry
                        log.write(self.speaker_rule(name, style))
                        log.write("")
                    elif kind == "user":
                        log.write(Text(entry[1], style="#aeb0aa"))
                    elif kind == "agent":
                        log.write(Text(entry[1], style="#aeb0aa"))
                    elif kind == "tool":
                        _, name, call_id, status = entry
                        suffix = f" · {status}" if status else ""
                        call = f" · {call_id}" if call_id else ""
                        log.write(
                            Text("tool › ", style="bold #6f98bd")
                            + Text(name or "tool", style="#aeb0aa")
                            + Text(f"{call}{suffix}", style="#7d8590")
                        )
                    elif kind == "step_end":
                        log.write(self.qed_marker())
                    elif kind == "user_end":
                        log.write(self.qed_marker("#88b38a"))
                    elif kind == "info":
                        log.write(Text("info › ", style="bold #7d8590") + Text(str(entry[1]), style="#8b949e"))
                    elif kind == "error":
                        log.write(Text("error › ", style="bold #ff7b72") + Text(str(entry[1]), style="#ff7b72"))

            def write_user(self, prompt):
                chat.append_user_transcript(prompt)
                self.render_transcript()

            def ensure_agent_role(self, name=None):
                if chat.ensure_agent_transcript(name):
                    self.render_transcript()

            def write_agent_start(self, name):
                chat._agent_buffer = ""
                chat._pending_tools.clear()
                chat._seen_tool_calls.clear()

            def start_agent_step(self):
                self.render_transcript()

            def write_agent_delta(self, delta):
                self.ensure_agent_role()
                chat._agent_buffer += delta
                if chat._transcript and chat._transcript[-1][0] == "agent":
                    chat._transcript[-1] = ("agent", chat._agent_buffer)
                else:
                    chat._transcript.append(("agent", chat._agent_buffer))
                self.render_transcript()

            def write_tool(self, name, call_id=None, status=None):
                self.ensure_agent_role()
                chat._pending_tools.append(("tool", name, call_id, status))

            def end_agent_step(self):
                had_content = bool(chat._agent_buffer or chat._pending_tools)
                if chat._transcript and chat._transcript[-1][0] == "agent":
                    if chat._agent_buffer:
                        chat._transcript[-1] = ("agent", chat._agent_buffer)
                    else:
                        chat._transcript.pop()
                if chat._pending_tools:
                    chat._transcript.extend(chat._pending_tools)
                    chat._pending_tools.clear()
                if had_content and (not chat._transcript or chat._transcript[-1][0] != "step_end"):
                    chat._transcript.append(("step_end",))
                self.render_transcript()

            def write_info(self, text):
                chat._transcript.append(("info", str(text)))
                self.render_transcript()

            def write_error(self, text):
                chat._transcript.append(("error", str(text)))
                self.render_transcript()

            def refresh_status(self):
                self.query_one("#status", Static).update(chat.status_renderable())

        AgentTextualApp().run()

    def username(self):
        try:
            return self.client.config.get("username") or "You"
        except Exception:
            return "You"

    def agent_name(self):
        try:
            return self.client.config.get("name") or "Pandora"
        except Exception:
            return "Pandora"

    def append_user_transcript(self, prompt):
        self._agent_buffer = ""
        self._transcript.append(("speaker", self.username(), "#88b38a"))
        self._transcript.append(("user", prompt))
        self._transcript.append(("user_end",))
        self._last_role = "user"

    def ensure_agent_transcript(self, name=None):
        if self._last_role == "assistant":
            return False
        self._transcript.append(("speaker", name or self.agent_name(), "#789fbe"))
        self._last_role = "assistant"
        return True

    def status_renderable(self):
        if not self._server_connected:
            suffix = f" · {self._server_error}" if self._server_error else ""
            return f"server offline · reconnecting{suffix}"
        try:
            return self.format_status(self.client.get_status())
        except Exception as exc:
            self._server_error = str(exc)
            return f"status unavailable · {exc}"

    @staticmethod
    def composer_height(text):
        useful_lines = max(1, min(10, str(text or "").count("\n") + 1))
        return useful_lines + 2

    @classmethod
    def format_status(cls, status):
        percent = float(status.get("context_percent") or 0)
        context_style = cls._percent_style(percent)
        used = cls._format_ktok(status.get("context_current_tokens") or 0)
        limit = cls._format_ktok(status.get("context_limit_tokens") or 0)
        quota_5h = cls._format_percent(status.get("quota_5h_percent"))
        quota_7d = cls._format_percent(status.get("quota_7d_percent"))
        sent_messages = int(status.get("sent_session_messages") or 0)
        persistent_messages = status.get("persistent_session_messages")
        temporary_messages = status.get("temporary_session_messages")
        total_messages = int(status.get("total_session_messages") or 0)
        model = status.get("model") or "-"
        message_segments = cls._message_status_segments(sent_messages, persistent_messages, temporary_messages, total_messages)
        return Text.assemble(
            (" ctx ", "bold #c9d1d9 on #161b22"),
            (f"{used}/{limit} ktok ", "#8b949e on #161b22"),
            (f"{percent:.1f}%", f"{context_style} on #161b22"),
            ("  msg ", "#6e7681 on #161b22"),
            *message_segments,
            ("  5h ", "#6e7681 on #161b22"),
            (quota_5h, f"{cls._percent_style(status.get('quota_5h_percent'))} on #161b22"),
            ("  7d ", "#6e7681 on #161b22"),
            (quota_7d, f"{cls._percent_style(status.get('quota_7d_percent'))} on #161b22"),
            ("  model ", "#6e7681 on #161b22"),
            (str(model), "#c9d1d9 on #161b22"),
        )

    @staticmethod
    def _message_status_segments(sent_messages, persistent_messages, temporary_messages, total_messages):
        if persistent_messages is None and temporary_messages is None:
            return ((f"{sent_messages}/{total_messages}", "#c9d1d9 on #161b22"),)
        try:
            persistent = int(persistent_messages or 0)
            temporary = int(temporary_messages or 0)
        except Exception:
            return ((f"{sent_messages}/{total_messages}", "#c9d1d9 on #161b22"),)
        return (
            (str(persistent), "#c9d1d9 on #161b22"),
            (f"+{temporary}", "italic #f0883e on #161b22"),
            (f"/{total_messages}", "#c9d1d9 on #161b22"),
        )

    @staticmethod
    def _format_ktok(value):
        try:
            return f"{float(value) / 1000:.1f}"
        except Exception:
            return str(value)

    @staticmethod
    def _format_percent(value):
        if value is None:
            return "-"
        try:
            return f"{float(value):.0f}%"
        except Exception:
            return str(value)

    @staticmethod
    def _percent_style(value):
        try:
            percent = float(value)
        except Exception:
            return "#6e7681"
        if percent >= 90:
            return "bold #ff7b72"
        if percent >= 75:
            return "#f0883e"
        if percent >= 50:
            return "#d29922"
        return "#3fb950"

    def _call_app(self, method, *args):
        if self.app is None:
            return
        callback = getattr(self.app, method)
        try:
            self.app.call_from_thread(callback, *args)
        except RuntimeError:
            callback(*args)

    def _once(self, handler):
        def wrapped(event):
            event_id = event.get("id")
            if event_id:
                if event_id in self._seen_event_ids:
                    return
                self._seen_event_ids.add(event_id)
            return handler(event)
        return wrapped

    def _on_message_added(self, event):
        self._mark_server_connected()
        message = event.get("message") or {}
        if message.get("type") == "user_message":
            self._call_app("write_user", str(message.get("content") or ""))
            self._call_app("refresh_status")

    def _on_assistant_turn_start(self, event):
        self._mark_server_connected()
        self._call_app("write_agent_start", self.agent_name())
        self._call_app("refresh_status")

    def _on_assistant_step_start(self, event):
        self._mark_server_connected()
        self._agent_buffer = ""
        self._call_app("start_agent_step")

    def _on_assistant_step_end(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()
        self._call_app("end_agent_step")
        self._call_app("refresh_status")

    def _on_assistant_turn_end(self, event):
        self._mark_server_connected()
        self._flush_replay_delta_buffer()
        result = event.get("result")
        if result not in (None, True, False):
            self._call_app("write_info", result)
        self._call_app("refresh_status")

    def _on_assistant_turn_error(self, event):
        self._mark_server_connected()
        self._call_app("write_error", event.get("error", "turn error"))
        self._call_app("refresh_status")

    def _on_content_delta(self, event):
        self._mark_server_connected()
        delta = event.get("delta", "")
        if self._replaying_events:
            self._replay_delta_buffer += delta
            return
        self._call_app("write_agent_delta", delta)

    def _flush_replay_delta_buffer(self):
        if not self._replay_delta_buffer:
            return
        delta = self._replay_delta_buffer
        self._replay_delta_buffer = ""
        self._call_app("write_agent_delta", delta)

    def _on_tool_call_start(self, event):
        self._mark_server_connected()
        tool_call = event.get("tool_call") or {}
        name = tool_call.get("name") or "unknown"
        call_id = tool_call.get("call_id") or name
        self._print_tool_call(name, call_id)

    def _on_server_tool_call(self, event):
        self._mark_server_connected()
        name = event.get("name") or "unknown"
        call_id = event.get("call_id") or name
        status = event.get("status") or ""
        self._print_tool_call(name, call_id, status=status)

    def _print_tool_call(self, name, call_id, status=None):
        if call_id in self._seen_tool_calls:
            return
        self._seen_tool_calls.add(call_id)
        self._call_app("write_tool", name, call_id, status)

    def _on_turn_error(self, event):
        self._call_app("write_error", event.get("error", "turn error"))
        self._call_app("refresh_status")

    def _on_client_event_error(self, event):
        message = event.get("detail") or event.get("error", "event stream error")
        if event.get("status_code") == 409:
            print(f"warning: {message}", file=sys.stderr)
            if self.app is not None:
                self._call_app("exit")
            return
        if event.get("source") == "event_stream":
            was_connected = self._server_connected
            self._server_connected = False
            self._server_error = message
            if was_connected:
                self._call_app("write_info", "server offline")
            self._call_app("refresh_status")
            return
        self._call_app("write_error", message)

    def _on_response_done(self, event):
        pass
