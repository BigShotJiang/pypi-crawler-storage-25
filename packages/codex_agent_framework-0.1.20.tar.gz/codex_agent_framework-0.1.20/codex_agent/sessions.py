import json
import os
from datetime import datetime
from typing import List

from codex_backend_sdk import CodexClient
from modict import modict

from .event import CompactionCompletedEvent, CompactionRequestedEvent, MessageAddedEvent, SessionDeletedEvent, SessionLoadedEvent
from .message import CompactionMessage, DeveloperMessage, Message, message_from_data
from .utils import runtime_join, session_id, sort, split_history_turns, timestamp, total_tokens


class AgentSession(modict):
    session_id: str = modict.factory(session_id)
    messages: List[Message] = modict.factory(list)

    @modict.computed(deps=["session_id"])
    def session_file(self):
        return runtime_join("sessions", f"{self.session_id}.json")

    @modict.computed(deps=["session_id"])
    def api_success_backup_file(self):
        return runtime_join("sessions", f"{self.session_id}.api_success_backup")

    def as_string(self):
        return "\n\n".join(message.as_string() for message in self.messages)

    def latest_compaction_index(self):
        for index in range(len(self.messages) - 1, -1, -1):
            if isinstance(self.messages[index], CompactionMessage):
                return index
        return None

    def context_messages(self):
        index = self.latest_compaction_index()
        return self.messages[index:] if index is not None else self.messages

    def compaction_plan(self):
        compaction_index = self.latest_compaction_index()
        start = compaction_index + 1 if compaction_index is not None else 0
        anchor = self.messages[compaction_index] if compaction_index is not None else None
        messages = self.messages[start:]
        turns, remainder = split_history_turns(messages)
        compacted_messages = [message for turn in turns for message in turn]
        history_messages = ([anchor] if anchor is not None else []) + compacted_messages
        return modict(
            start=start,
            anchor=anchor,
            messages=messages,
            compacted_messages=compacted_messages,
            history_messages=history_messages,
            remainder=remainder,
            compacted_message_count=len(compacted_messages),
            compacted_token_count=total_tokens(compacted_messages),
            context_message_count=len(history_messages) + len(remainder),
        )

    def compact(self, client=None, model="gpt-5.4", instructions=""):
        plan = self.compaction_plan()
        compacted_messages = plan.compacted_messages
        if not compacted_messages:
            return None

        history = self.messages_to_response_history(plan.history_messages)
        client = client or CodexClient(model=model, instructions=instructions).authenticate()
        result = client.compact(history, model=model, instructions=instructions)
        message = CompactionMessage(
            response_id=result.response_id,
            summaries=CompactionMessage.summary_items(result.output_items),
            compacted_message_count=len(compacted_messages),
        )

        insert_at = plan.start + len(compacted_messages)
        self.messages.insert(insert_at, message)
        previous_anchor = [plan.anchor] if plan.anchor is not None else []
        self.messages = previous_anchor + self.messages[insert_at:]
        self.save()
        return message

    def messages_to_response_history(self, messages):
        history = []
        for message in messages:
            item = message.to_response_format()
            if item is None:
                continue
            if isinstance(item, list):
                for subitem in item:
                    self.append_response_history_item(history, subitem)
            else:
                self.append_response_history_item(history, item)
        self.close_orphaned_tool_calls(history)
        return history

    def prune_orphaned_tool_outputs(self):
        history = []
        kept = []
        removed = []
        for message in self.messages:
            item = message.to_response_format()
            if item is None:
                kept.append(message)
                continue

            items = item if isinstance(item, list) else [item]
            if any(self.is_orphaned_response_tool_output(history, subitem) for subitem in items):
                removed.append(message)
                continue

            for subitem in items:
                self.append_response_history_item(history, subitem)
            kept.append(message)

        if removed:
            self.messages = kept
            self.save()
        return removed

    def append_response_history_item(self, history, item):
        if self.is_orphaned_response_tool_output(history, item):
            return
        self.close_orphaned_tool_calls(history, before=item)
        history.append(item)

    def is_orphaned_response_tool_output(self, history, item):
        if not self.is_response_tool_output(item):
            return False
        call_id = item.get("call_id")
        return not call_id or call_id not in self.pending_response_tool_calls(history)

    def close_orphaned_tool_calls(self, history, before=None):
        pending = self.pending_response_tool_calls(history)
        if not pending:
            return
        if before and self.is_response_tool_boundary(before):
            return
        for call_id, tool_type in pending.items():
            if tool_type == "custom_tool_call":
                history.append({
                    "type": "custom_tool_call_output",
                    "call_id": call_id,
                    "output": "Tool call was interrupted before an output was recorded.",
                })
            else:
                history.append({
                    "type": "function_call_output",
                    "call_id": call_id,
                    "output": "Tool call was interrupted before an output was recorded.",
                })

    def pending_response_tool_calls(self, history):
        pending = {}
        for item in history:
            item_type = item.get("type")
            if item_type in ("function_call", "custom_tool_call"):
                pending[item.get("call_id")] = item_type
            elif item_type in ("function_call_output", "custom_tool_call_output"):
                pending.pop(item.get("call_id"), None)
        return pending

    def is_response_tool_output(self, item):
        return item.get("type") in ("function_call_output", "custom_tool_call_output")

    def is_response_tool_boundary(self, item):
        return item.get("type") in (
            "function_call",
            "custom_tool_call",
            "function_call_output",
            "custom_tool_call_output",
        )

    def save(self):
        session_folder = runtime_join("sessions")
        if not os.path.isdir(session_folder):
            os.makedirs(session_folder, exist_ok=True)
        tmp_path = f"{self.session_file}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(self.messages, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, self.session_file)

    def save_api_success_backup(self):
        session_folder = runtime_join("sessions")
        if not os.path.isdir(session_folder):
            os.makedirs(session_folder, exist_ok=True)
        tmp_path = f"{self.api_success_backup_file}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(self.messages, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, self.api_success_backup_file)
        return self.api_success_backup_file

    def restore_api_success_backup(self):
        if not os.path.isfile(self.api_success_backup_file):
            return False
        with open(self.api_success_backup_file, encoding="utf-8") as f:
            data = json.load(f)
        self.messages = [message_from_data(msg) for msg in data]
        self.save()
        return True

    @classmethod
    def session_path(cls, session):
        if os.path.isfile(str(session)):
            return str(session)
        return runtime_join("sessions", f"{session}.json")

    @classmethod
    def can_load(cls, session):
        path = cls.session_path(session)
        if not os.path.isfile(path):
            return False
        try:
            with open(path, "r", encoding="utf-8") as f:
                json.load(f)
        except (OSError, json.JSONDecodeError, TypeError):
            return False
        return True

    @classmethod
    def load(cls, session):
        path = cls.session_path(session)
        session_id = os.path.splitext(os.path.basename(path))[0]
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Session file is not valid JSON: {path}") from exc
            messages = [message_from_data(msg) for msg in data]
            return cls(session_id=session_id, messages=messages)
        raise ValueError(f"Session file not found: {path}")

    @classmethod
    def list_sessions(cls):
        session_folder = runtime_join("sessions")
        if not os.path.isdir(session_folder):
            return []
        session_ids = []
        for filename in os.listdir(session_folder):
            if not filename.endswith(".json"):
                continue
            session_id = filename.replace(".json", "")
            if cls.can_load(session_id):
                session_ids.append(session_id)
        return sorted(session_ids, reverse=True)

    @classmethod
    def delete(cls, session):
        if os.path.isfile(str(session)):
            path = str(session)
        else:
            path = runtime_join("sessions", f"{session}.json")
        if not os.path.isfile(path):
            raise ValueError(f"Session file not found: {path}")
        os.remove(path)
        return os.path.splitext(os.path.basename(path))[0]


class SessionsManager:
    def __init__(self, agent):
        self.agent = agent

    def init_folder(self):
        session_folder = runtime_join("sessions")
        if not os.path.isdir(session_folder):
            os.makedirs(session_folder, exist_ok=True)
        return session_folder

    def list(self):
        return AgentSession.list_sessions()

    def latest_id(self):
        sessions = self.list()
        return sessions[0] if sessions else None

    def load(self, session):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("load_session", session=session).wait()
        if session == "latest":
            session = self.latest_id()
            if session is None:
                return self.start_new()
        self.agent.session = AgentSession.load(session)
        self.agent.current_session_id = self.agent.session.session_id
        self.append_message(DeveloperMessage(content=f"Resuming chat session at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}."))
        self.agent.emit(SessionLoadedEvent, session=self.agent.session, session_id=self.agent.session.session_id)
        return self.agent.session

    def start_new(self):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("start_new_session").wait()
        self.agent.session = AgentSession()
        self.agent.current_session_id = self.agent.session.session_id
        self.append_message(DeveloperMessage(content=f"Starting a new chat session at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}."))
        self.agent.emit(SessionLoadedEvent, session=self.agent.session, session_id=self.agent.session.session_id)
        return self.agent.session

    def delete(self, session):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("delete_session", session=session).wait()
        deleted_id = AgentSession.delete(session)
        if deleted_id == self.agent.current_session_id:
            latest = self.latest_id()
            self.load(latest) if latest else self.start_new()
        self.agent.emit(SessionDeletedEvent, session_id=deleted_id)
        return deleted_id

    def navigate(self, direction):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("navigate_session", direction=direction).wait()
        sessions = self.list()
        if not sessions:
            return self.start_new()
        if self.agent.current_session_id not in sessions:
            return self.load(sessions[0])

        index = sessions.index(self.agent.current_session_id)
        if direction in ("next", "newer"):
            target_index = max(index - 1, 0)
        elif direction in ("previous", "prev", "older"):
            target_index = min(index + 1, len(sessions) - 1)
        else:
            raise ValueError(f"Unknown session navigation direction: {direction}")
        return self.load(sessions[target_index])

    def save(self):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("save_session").wait()
        if not self.agent.current_session_id:
            return None
        self.agent.session.save()
        return self.agent.session

    def save_api_success_backup(self):
        if not self.agent.session:
            return None
        return self.agent.session.save_api_success_backup()

    def restore_api_success_backup(self):
        if not self.agent.session:
            return False
        restored = self.agent.session.restore_api_success_backup()
        if restored:
            self.agent.status_manager.invalidate_context_cache()
        return restored

    def compact(self, client=None, model=None, instructions=None):
        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit(
                "compact_session",
                client=client,
                model=model,
                instructions=instructions,
            ).wait()

        model = model or self.agent.config.model
        instructions = instructions if instructions is not None else self.agent.config_manager.system_message().content
        plan = self.agent.session.compaction_plan()
        if not plan.compacted_messages:
            return None

        self.agent.emit(
            CompactionRequestedEvent,
            compacted_message_count=plan.compacted_message_count,
            compacted_token_count=plan.compacted_token_count,
            context_message_count=plan.context_message_count,
            total_session_messages=len(self.agent.session.messages),
        )
        compact_kwargs = modict(model=model, instructions=instructions)
        if client is not None:
            compact_kwargs.client = client
        message = self.agent.session.compact(**compact_kwargs)
        self.agent.status_manager.invalidate_context_cache()
        status = self.agent.status_manager.refresh_estimated_status_cache()
        self.agent.emit(
            CompactionCompletedEvent,
            message=message,
            status=status,
            compacted_message_count=plan.compacted_message_count,
            compacted_token_count=plan.compacted_token_count,
            post_compaction_message_count=len(self.agent.session.context_messages()),
            total_session_messages=len(self.agent.session.messages),
        )
        return message

    def append_message(self, msg):
        if not msg.session_id:
            msg.session_id = self.agent.current_session_id
        self.agent.session.messages.append(msg)
        msg.timestamp = msg.timestamp or timestamp()
        self.agent.status_manager.invalidate_context_cache()
        self.save()
        self.agent.emit(MessageAddedEvent, message=msg)
        return msg

    def messages(self, filter=None):
        if filter:
            return [msg for msg in self.agent.session.messages if filter(msg)]
        return sort(self.agent.session.messages)
