"""Stateful plugin primitives for agent extensions."""

import hashlib
import importlib
import importlib.util
import inspect
import os
import pkgutil
import sys

from modict import modict

from .command import command_options
from .event import Event
from .provider import provider_options
from .tool import tool_options
from .utils import runtime_join


def event_handler(event):
    """Decorate a plugin method as an Agent event handler."""
    if event != "*" and not (inspect.isclass(event) and issubclass(event, Event)):
        raise TypeError("event_handler expects an Event subclass or '*'")

    def decorator(func):
        setattr(func, "_codex_event_handler", event)
        return func

    return decorator


def event_handler_options(func):
    return getattr(func, "_codex_event_handler", getattr(getattr(func, "__func__", None), "_codex_event_handler", None))


def hook_handler(name):
    """Decorate a plugin method as a named runtime hook handler."""
    hook_name = str(name)

    def decorator(func):
        setattr(func, "_codex_hook_handler", hook_name)
        return func

    return decorator


def hook_handler_options(func):
    return getattr(func, "_codex_hook_handler", getattr(getattr(func, "__func__", None), "_codex_hook_handler", None))


class Plugin:
    """Base class for stateful agent plugins."""

    name = ""
    description = ""
    system_prompt = ""
    requires_openai = False
    prefix_tools = True

    def __init__(self, agent):
        self.agent = agent

    def start(self):
        return self

    def stop(self, timeout=None):
        return self

    def get_tools(self):
        """Return this plugin's bound methods decorated as tools."""
        return self._decorated_methods(tool_options)

    def get_providers(self):
        """Return this plugin's bound methods decorated as context providers."""
        return self._decorated_methods(provider_options)

    def get_commands(self):
        """Return this plugin's bound methods decorated as slash commands."""
        return self._decorated_methods(command_options)

    def get_event_handlers(self):
        """Return ``(event, method)`` pairs declared by this plugin."""
        return [
            (event_handler_options(method), method)
            for method in self._decorated_methods(event_handler_options)
        ]

    def get_hook_handlers(self):
        """Return ``(hook_name, method)`` pairs declared by this plugin."""
        return [
            (hook_handler_options(method), method)
            for method in self._decorated_methods(hook_handler_options)
        ]

    def get_system_prompt_sections(self):
        """Return system prompt sections contributed by this plugin."""
        section = str(self.system_prompt or "").strip()
        return [section] if section else []

    def _decorated_methods(self, options_for):
        methods = []
        for _, member in inspect.getmembers(self):
            if not inspect.ismethod(member):
                continue
            if options_for(member) is not None:
                methods.append(member)
        return methods


class PluginsManager:
    def __init__(self, agent):
        self.agent = agent
        self.plugins = modict()

    def init_folder(self):
        plugins_folder = runtime_join("plugins")
        if not os.path.isdir(plugins_folder):
            os.makedirs(plugins_folder, exist_ok=True)
        return plugins_folder

    def init_builtin(self):
        from . import builtin_plugins

        modules = sorted(pkgutil.iter_modules(builtin_plugins.__path__), key=lambda item: item.name)
        for module_info in modules:
            if module_info.name.startswith("_"):
                continue
            if not self.agent.config_manager.builtin_plugin_enabled(module_info.name):
                continue
            module = importlib.import_module(f"{builtin_plugins.__name__}.{module_info.name}")
            if self.module_requires_openai(module) and not self.agent.config_manager.has_openai_api_key():
                continue
            self.add_from_module(module)

    def init_runtime(self):
        plugins_folder = self.init_folder()
        if plugins_folder not in sys.path:
            sys.path.insert(0, plugins_folder)

        for filename in sorted(os.listdir(plugins_folder)):
            if not filename.endswith(".py") or filename.startswith("_"):
                continue
            name = os.path.splitext(filename)[0]
            if not self.agent.config_manager.custom_plugin_enabled(name):
                continue
            module = self.load_runtime_module(os.path.join(plugins_folder, filename))
            if self.module_requires_openai(module) and not self.agent.config_manager.has_openai_api_key():
                continue
            self.add_from_module(module)

    def load_runtime_module(self, path):
        hook = self.agent.run_hook("runtime_module.load.before", path=path, kind="plugin")
        path = hook.payload.path
        kind = hook.payload.kind
        digest = hashlib.sha1(os.path.abspath(path).encode()).hexdigest()[:12]
        module_name = f"codex_agent_runtime_{kind}_{os.path.splitext(os.path.basename(path))[0]}_{digest}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            raise RuntimeError(f"Failed to load runtime {kind} module {path}: {exc}") from exc
        self.agent.run_hook("runtime_module.load.after", path=path, kind=kind, module=module)
        return module

    def module_requires_openai(self, module):
        plugin_classes = self.plugin_classes_from_module(module)
        if plugin_classes:
            return any(getattr(plugin_class, "requires_openai", False) for plugin_class in plugin_classes)
        return bool(getattr(module, "requires_openai", False))

    def add_from_module(self, module):
        plugin_classes = self.plugin_classes_from_module(module)
        for plugin_class in sorted(plugin_classes, key=lambda cls: cls.__name__):
            self.add_plugin(plugin_class(self.agent))

        if not plugin_classes:
            register = getattr(module, "register", None)
            if callable(register):
                register(self.agent)
                return

            self.agent.tools_manager.add_from_module(module)
            self.agent.providers_manager.add_from_module(module)
            self.agent.command_manager.add_from_module(module)

    def plugin_classes_from_module(self, module):
        return [
            cls for cls in module.__dict__.values()
            if inspect.isclass(cls)
            and issubclass(cls, Plugin)
            and cls is not Plugin
            and cls.__module__ == module.__name__
        ]

    def add_plugin(self, plugin):
        plugin_name = getattr(plugin, "name", None) or type(plugin).__name__
        self.plugins[plugin_name] = plugin
        self.add_plugin_members(plugin)
        return plugin

    def start(self):
        for plugin in list(self.plugins.values()):
            plugin.start()
        return self

    def stop(self, timeout=None):
        for plugin in list(self.plugins.values()):
            plugin.stop(timeout=timeout)
        return self

    def add_plugin_members(self, plugin):
        for obj in plugin.get_tools():
            self.agent.tools_manager.add_object(obj, name=self.tool_name_for(plugin, obj))
        for obj in plugin.get_providers():
            self.agent.providers_manager.add_object(obj)
        for obj in plugin.get_commands():
            self.agent.command_manager.add_object(obj)
        for event, handler in plugin.get_event_handlers():
            self.agent.on(event, handler)
        for hook_name, handler in plugin.get_hook_handlers():
            self.agent.add_hook(hook_name, handler)

    def tool_name_for(self, plugin, obj):
        plugin_name = getattr(plugin, "name", None) or type(plugin).__name__
        options = tool_options(obj) or {}
        tool_name = options.get("name") or getattr(obj, "__name__", None) or obj.__class__.__name__
        if not getattr(plugin, "prefix_tools", True):
            return tool_name
        if tool_name == plugin_name or tool_name.startswith(f"{plugin_name}_"):
            return tool_name
        return f"{plugin_name}_{tool_name}"

    def get_system_prompt_sections(self):
        sections = []
        for plugin in self.plugins.values():
            sections.extend(plugin.get_system_prompt_sections())
        return sections
