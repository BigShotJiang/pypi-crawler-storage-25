import json
import os
import sys
from typing import Literal

import codex_agent.utils as utils
from modict import modict
from codex_agent import Agent, AssistantInterruptRequestedEvent, AssistantInterrupted, AssistantInterruptedEvent, AssistantTurnEndEvent, AssistantTurnStartEvent, AssistantStepEndEvent, AudioPlaybackEvent, MessageSubmittedEvent, CompactionCompletedEvent, CompactionMessage, CompactionRequestedEvent, ImageGenerationTool, ResponseContentDeltaEvent, ServerToolCallEvent, SessionDeletedEvent, SessionLoadedEvent, WebSearchTool, get_agent, get_current_call_id
from codex_agent.sessions import AgentSession
from codex_agent.image import ImageMessage
from codex_agent.message import AssistantMessage, DeveloperMessage, InterruptMessage, MessageChunk, ProviderMessage, ServerToolResponseMessage, SystemMessage, ToolResultMessage, ToolResultWrapper, UserMessage
from codex_agent.tool import Tool
from codex_agent.ai import AIBadRequestError
from codex_backend_sdk import OutputItem, ResponseCompleted, TokenUsage
import pytest


@pytest.fixture(autouse=True)
def fast_desktop_command_settle(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    monkeypatch.setattr(desktop_plugin.DesktopPlugin, "command_settle_seconds", 0)


class FakeAI:
    def __init__(self, agent):
        self.agent = agent
        self.params = None

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        chunk = MessageChunk(content="hi")
        message.add_chunk(chunk)
        self.agent.emit(
            ResponseContentDeltaEvent,
            delta="hi",
            content="hi",
            chunk=chunk,
            message=message,
        )
        return message


class SequencedAI:
    def __init__(self, messages):
        self.messages = list(messages)
        self.params = []

    def run(self, **params):
        self.params.append(params)
        return self.messages.pop(0)


class FakeImageAI:
    def __init__(self, agent, item=None):
        self.agent = agent
        self.params = None
        self.item = item or {
            "type": "image_generation_call",
            "id": "ig_123",
            "result": "Zm9v",
        }

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        message.add_chunk(MessageChunk(output_items=[self.item]))
        return message


class FakeCodexClient:
    def __init__(self, events):
        self.events = events
        self.args = None
        self.kwargs = None

    def stream(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs
        return iter(self.events)

    def usage(self):
        return {
            "rate_limit": {
                "primary_window": {"used_percent": 11},
                "secondary_window": {"used_percent": 22},
            }
        }


class InterruptingAI:
    def __init__(self, agent):
        self.agent = agent

    def run(self, **_params):
        self.agent.interrupt("test")
        raise AssistantInterrupted()

    def abort(self):
        pass


def test_response_input_payload_moves_leading_system_messages_to_instructions():
    agent = Agent(session="new", voice_enabled=False)

    payload = agent.context_manager.response_input_token_payload([
        SystemMessage(content="Base rules."),
        SystemMessage(content="Extra rules."),
        DeveloperMessage(content="visible context"),
        SystemMessage(content="ignored late rules."),
    ])

    assert payload.instructions == "Base rules.\n\nExtra rules."
    assert payload.input == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "visible context"}],
    }]


class AbortableAI:
    def __init__(self):
        self.aborted = False

    def abort(self):
        self.aborted = True


class FailingAbortAI:
    def abort(self):
        raise RuntimeError("abort failed")


class FakeCompactionResult:
    response_id = "resp_123"
    output_items = [
        {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "old"}]},
        {"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"},
    ]


class FakeCompactionClient:
    def __init__(self):
        self.history = None
        self.params = None

    def compact(self, history, **params):
        self.history = history
        self.params = params
        return FakeCompactionResult()


def test_agent_session_as_string_concatenates_message_strings():
    assistant = AssistantMessage(content="I will inspect it.")
    assistant.tool_calls = [{
        "call_id": "call_1",
        "name": "read",
        "arguments": '{"path": "codex_agent/agent.py"}',
    }]
    session = AgentSession(messages=[
        ProviderMessage(name="cwd", content="/home/baptiste/dev/codex-agent"),
        assistant,
    ])

    text = session.as_string()

    assert "<ProviderMessage " in text
    assert "/home/baptiste/dev/codex-agent" in text
    assert "\n\n<AssistantMessage " in text
    assert "I will inspect it." in text
    assert "<tool_call type='function_call' name='read' call_id='call_1'>" in text
    assert '{"path": "codex_agent/agent.py"}' in text


def test_agent_session_response_history_closes_orphaned_tool_calls_before_user_message():
    assistant = AssistantMessage()
    assistant.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "bash",
        "input": "pytest",
    }]
    user = DeveloperMessage(content="resumed")
    session = AgentSession(messages=[assistant, user])

    history = session.messages_to_response_history(session.messages)

    assert history == [
        {
            "type": "custom_tool_call",
            "call_id": "call_1",
            "name": "bash",
            "input": "pytest",
        },
        {
            "type": "custom_tool_call_output",
            "call_id": "call_1",
            "output": "Tool call was interrupted before an output was recorded.",
        },
        {
            "type": "message",
            "role": "developer",
            "content": [{"type": "input_text", "text": "resumed"}],
        },
    ]


def test_agent_session_response_history_prunes_orphaned_tool_outputs():
    output = ToolResultMessage(
        name="observe",
        call_id="call_missing",
        content="success: full output in ImageMessage id=img_1.",
    )
    user = DeveloperMessage(content="resumed")
    session = AgentSession(messages=[output, user])
    session.save()

    removed = session.prune_orphaned_tool_outputs()
    history = session.messages_to_response_history(session.messages)

    assert removed == [output]
    assert session.messages == [user]
    assert history == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "resumed"}],
    }]
    with open(session.session_file, encoding="utf-8") as f:
        persisted = json.load(f)
    assert [message["id"] for message in persisted] == [user.id]


def test_response_input_payload_skips_orphaned_tool_outputs():
    agent = Agent(session="new", voice_enabled=False)

    payload = agent.context_manager.response_input_token_payload([
        ToolResultMessage(
            name="observe",
            call_id="call_missing",
            content="success: full output in ImageMessage id=img_1.",
        ),
        DeveloperMessage(content="resumed"),
    ])

    assert payload.input == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "resumed"}],
    }]


def test_agent_get_context_repairs_persisted_orphaned_tool_outputs():
    agent = Agent(session="new", voice_enabled=False)
    output = ToolResultMessage(
        name="observe",
        call_id="call_missing",
        content="success: full output in ImageMessage id=img_1.",
    )
    user = DeveloperMessage(content="resumed")
    agent.session.messages = [output, user]
    agent.save_session()

    context = agent.context_manager.get_context()

    assert output not in agent.session.messages
    assert user in agent.session.messages
    assert user.id in [message.id for message in context]
    with open(agent.session.session_file, encoding="utf-8") as f:
        persisted = json.load(f)
    assert [message["id"] for message in persisted] == [user.id]


def test_agent_emits_session_events():
    agent = Agent(session="new", voice_enabled=False)
    seen = []

    agent.on(SessionLoadedEvent, lambda event: seen.append((event.type, event.session_id)))
    agent.on(SessionDeletedEvent, lambda event: seen.append((event.type, event.session_id)))

    session = agent.start_new_session()
    deleted_id = agent.delete_session(session.session_id)

    assert ("session_loaded_event", session.session_id) in seen
    assert ("session_deleted_event", deleted_id) in seen


def test_agent_call_emits_turn_events(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    seen = []

    agent.on(AssistantTurnStartEvent, lambda event: seen.append((event.type, event.prompt)))
    agent.on(AssistantTurnEndEvent, lambda event: seen.append((event.type, event.prompt, event.result)))
    monkeypatch.setattr(agent, "get_response", lambda: AssistantMessage(content="ok"))

    assert agent("hello") is True
    assert seen == [
        ("assistant_turn_start_event", None),
        ("assistant_turn_end_event", None, True),
    ]
    agent.stop()


def test_agent_start_turn_is_non_blocking_and_tracks_busy(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    monkeypatch.setattr(agent.mainloop_manager, "process", lambda: True)

    future = agent.start_turn()

    assert future.command == "turn"
    assert future.id
    assert agent.busy is True
    assert future.wait() is True
    assert agent.busy is False
    agent.stop()


def test_agent_state_mutations_run_through_mainloop_when_started(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    existing = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="existing")])
    existing.save()
    agent = Agent(session="new", voice_enabled=False)
    agent.start()

    loaded = agent.load_session(existing.session_id)
    config = agent.config_manager.update(name="Queued", save=False)

    assert loaded.session_id == existing.session_id
    assert agent.current_session_id == existing.session_id
    assert config.name == "Queued"
    assert agent.config.name == "Queued"
    agent.stop()


def test_agent_interrupt_emits_request_event():
    agent = Agent(session="new", voice_enabled=False)
    seen = []

    agent.on(AssistantInterruptRequestedEvent, lambda event: seen.append((event.type, event.reason, event.interrupted)))

    assert agent.interrupt("api") is True
    assert seen == [("assistant_interrupt_requested_event", "api", True)]

def test_agent_session_compact_purges_compacted_prefix_before_remainder(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    user = DeveloperMessage(content="old session marker")
    done = AssistantMessage(content="done")
    current = DeveloperMessage(content="current unfinished turn")
    session = AgentSession(messages=[user, done, current])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert isinstance(message, CompactionMessage)
    assert session.messages == [message, current]
    assert [msg.id for msg in AgentSession.load(session.session_id).messages] == [message.id, current.id]
    assert "output_items" not in message
    assert message.summaries == [FakeCompactionResult.output_items[1]]
    assert message.compacted_message_count == 2
    assert client.history == [
        {
            "type": "message",
            "role": "developer",
            "content": [{"type": "input_text", "text": "old session marker"}],
        },
        {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "done"}],
        },
    ]


def test_agent_session_compact_starts_at_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    old_user = DeveloperMessage(content="very old")
    old_done = AssistantMessage(content="very old done")
    previous = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "old"}])
    new_user = DeveloperMessage(content="new")
    new_done = AssistantMessage(content="new done")
    session = AgentSession(messages=[old_user, old_done, previous, new_user, new_done])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert session.messages == [previous, message]
    assert [msg.id for msg in AgentSession.load(session.session_id).messages] == [previous.id, message.id]
    assert client.history[0] == {"type": "compaction_summary", "id": "old"}
    assert "very old" not in json.dumps(client.history)
    assert "new done" in json.dumps(client.history)


def test_agent_session_compact_includes_only_latest_compaction_anchor(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "older"}])
    latest = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "latest"}])
    new_user = DeveloperMessage(content="new facts")
    new_done = AssistantMessage(content="new facts done")
    session = AgentSession(messages=[older, latest, new_user, new_done])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert session.messages == [latest, message]
    assert [msg.id for msg in AgentSession.load(session.session_id).messages] == [latest.id, message.id]
    assert client.history[0] == {"type": "compaction_summary", "id": "latest"}
    assert {item.get("id") for item in client.history if item.get("type") == "compaction_summary"} == {"latest"}
    assert "new facts done" in json.dumps(client.history)


def test_agent_compact_session_emits_volume_events(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    expired = DeveloperMessage(content="expired but compactable", turns_left=0)
    done = AssistantMessage(content="done")
    current = DeveloperMessage(content="current unfinished turn")
    agent.session.messages = [expired, done, current]
    agent.status_manager.cache_api_status(
        usage=modict(input_tokens=5000),
        quota={
            "rate_limit": {
                "primary_window": {"used_percent": 12},
                "secondary_window": {"used_percent": 34},
            },
        },
    )
    seen = []

    agent.on(CompactionRequestedEvent, lambda event: seen.append(event))
    agent.on(CompactionCompletedEvent, lambda event: seen.append(event))

    message = agent.compact_session(client=FakeCompactionClient())

    assert isinstance(message, CompactionMessage)
    assert [event.type for event in seen] == [
        "compaction_requested_event",
        "compaction_completed_event",
    ]
    assert seen[0].compacted_message_count == 2
    assert seen[0].context_message_count == 3
    assert seen[0].total_session_messages == 3
    assert seen[0].compacted_token_count > 0
    assert seen[1].message is message
    assert seen[1].status.source == "local_estimate"
    assert seen[1].status.context_current_tokens != 5000
    assert seen[1].compacted_message_count == 2
    assert seen[1].post_compaction_message_count == 2
    assert seen[1].total_session_messages == 2
    status = agent.get_status()
    assert status.source == "local_estimate"
    assert status.sent_session_messages == 2
    assert status.total_session_messages == 2
    assert status.context_current_tokens != 5000
    assert status.quota_5h_percent == 12
    assert status.quota_7d_percent == 34


def test_agent_add_message_invalidates_context_status_cache():
    agent = Agent(session="new", voice_enabled=False)
    first = agent.status_manager.context_status()

    agent.add_message(DeveloperMessage(content="new visible context"))
    agent.mainloop_manager.dump_pending()
    second = agent.status_manager.context_status()

    assert second.total_session_messages == first.total_session_messages + 1
    assert second.used_tokens != first.used_tokens


def test_agent_add_message_queues_pending_without_starting_turn():
    agent = Agent(session="new", voice_enabled=False)
    agent.start()

    message = agent.add_message(UserMessage(content="queued only"))

    assert message in agent.mainloop_manager.pending
    assert not any(future.command == "turn" for future in agent.mainloop_manager.futures.values())
    agent.stop(timeout=1.0)


def test_agent_submit_message_queues_pending_and_autostarts_when_idle():
    agent = Agent(session="new", voice_enabled=False)
    submitted = []
    agent.on(MessageSubmittedEvent, lambda event: submitted.append(event))

    def process_pending():
        agent.mainloop_manager.dump_pending()
        return True

    agent.mainloop_manager.process = process_pending
    agent.start()

    result = agent.submit_message(UserMessage(content="queued while idle"))
    message = result.message
    future = next(future for future in agent.mainloop_manager.futures.values() if future.command == "turn")

    assert result.turn_id == future.id
    assert len(submitted) == 1
    assert submitted[0].message is message
    assert submitted[0].turn_id == future.id
    assert message in agent.mainloop_manager.pending or message in agent.session.messages
    assert future.wait(timeout=1.0) is True
    assert message not in agent.mainloop_manager.pending
    assert agent.session.messages[-1].content == "queued while idle"
    agent.stop(timeout=1.0)


def test_agent_tool_result_messages_append_directly_without_pending():
    agent = Agent(session="new", voice_enabled=False)
    result = ToolResultMessage(name="tool", call_id="call_1", content="ok")

    agent.add_message(result)

    assert result in agent.session.messages
    assert result not in agent.mainloop_manager.pending


def test_agent_get_context_starts_at_latest_compaction():
    agent = Agent(session="new", voice_enabled=False)
    old = DeveloperMessage(content="old hidden context")
    previous = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
    current = DeveloperMessage(content="current visible context")
    agent.session.messages = [old, previous, current]

    context = agent.context_manager.get_context()
    context_text = "\n".join(str(message.get("content", "")) for message in context)

    context_ids = [message.id for message in context]
    assert previous.id in context_ids
    assert current.id in context_ids
    assert old.id not in context_ids
    assert "old hidden context" not in context_text


def test_agent_local_context_estimate_does_not_count_encrypted_compaction_payload():
    agent = Agent(session="new", voice_enabled=False)
    encrypted_content = "x" * 100_000
    agent.session.messages = [
        CompactionMessage(output_items=[{
            "type": "compaction_summary",
            "id": "cs_123",
            "encrypted_content": encrypted_content,
        }]),
        DeveloperMessage(content="small current context"),
    ]

    status = agent.status_manager.context_status()

    assert status.used_tokens < 10_000
    assert encrypted_content not in str(agent.context_manager.local_token_count_payload(
        agent.context_manager.response_input_token_payload(agent.session.context_messages(), response_tools=[])
    ))


def test_agent_get_context_filters_expired_messages():
    agent = Agent(session="new", voice_enabled=False)
    expired = DeveloperMessage(content="expired hidden context", turns_left=0)
    visible = DeveloperMessage(content="visible context", turns_left=1)
    agent.session.messages = [expired, visible]

    context = agent.context_manager.get_context()
    context_text = "\n".join(str(message.get("content", "")) for message in context)

    context_ids = [message.id for message in context]
    assert visible.id in context_ids
    assert expired.id not in context_ids
    assert "expired hidden context" not in context_text


def test_agent_get_context_uses_openai_input_token_count_when_available(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    agent.session.messages = [DeveloperMessage(content="visible context")]
    calls = []

    def count_input_tokens(**payload):
        calls.append(payload)
        return 4321

    monkeypatch.setattr(agent.ai, "count_input_tokens", count_input_tokens)

    agent.context_manager.get_context()
    status = agent.get_status()

    assert calls
    assert calls[0]["model"] == agent.config.model
    assert "input" in calls[0]
    assert "tools" in calls[0]
    assert status.context_current_tokens == 4321
    assert status.source == "openai_input_tokens"


def test_agent_ages_context_messages_once_per_process_loop():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=True)
    expiring = DeveloperMessage(content="still visible", turns_left=2)
    agent.session.messages = [expiring]

    @agent.add_tool
    def echo(value):
        return value

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "echo",
        "arguments": '{"value": "ok"}',
    }]
    final = AssistantMessage(content="done")
    agent.ai = SequencedAI([tool_call, final])

    assert agent.mainloop_manager.process() is True

    assert expiring.turns_left == 1


def test_agentic_loop_continues_from_require_next_step_flag():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_tool
    def echo(value):
        return value

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "echo",
        "arguments": '{"value": "ok"}',
    }]
    final = AssistantMessage(content="done")
    agent.ai = SequencedAI([tool_call, final])
    seen = []
    agent.on(
        AssistantStepEndEvent,
        lambda event: seen.append((event.called_tools, event.require_next_step, event.stop_agentic_loop)),
    )

    assert agent.mainloop_manager.process() is True

    assert len(agent.ai.params) == 2
    assert seen == [(True, True, False), (False, False, False)]


def test_agentic_loop_stop_flag_exits_after_current_step():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_tool
    def stop_now():
        agent.mainloop_manager.stop_loop_after_current_step()
        return "stopped"

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "stop_now",
        "arguments": "{}",
    }]
    final = AssistantMessage(content="should not run")
    agent.ai = SequencedAI([tool_call, final])

    assert agent.mainloop_manager.process() is True

    assert len(agent.ai.params) == 1
    assert agent.mainloop_manager.stop_agentic_loop is True
    assert any(message.content == "stopped" for message in agent.session.messages)


def test_agent_initializes_new_session(isolated_runtime_dir):
    agent = Agent(session="new", voice_enabled=False)

    assert agent.session is not None
    assert agent.current_session_id == agent.session.session_id
    assert " " not in agent.current_session_id
    assert agent.session.session_file.startswith(str(isolated_runtime_dir))
    assert (isolated_runtime_dir / "sessions" / f"{agent.current_session_id}.json").is_file()
    assert agent.session.messages[-1].type == "developer_message"
    assert agent.config.input_token_limit == 200000
    assert agent.config.max_images == 10
    assert agent.config.auto_compact is True
    assert "auto_archive_memory" not in agent.config
    assert agent.plugins.memory.config.auto_archive is False
    assert "token_limit" not in agent.config
    assert {tool.type for tool in agent.tools_manager.get_server_tools()} == {"web_search", "image_generation"}
    assert set(agent.plugins) >= {"browser", "desktop", "memory", "planner", "scheduler"}
    assert "browser_open" in agent.tools
    assert "browser_snapshot" not in agent.tools
    assert "browser_screenshot" not in agent.tools
    assert {method.__name__ for method in agent.plugins.browser.get_tools()} == {
        "open",
        "close",
        "select_tab",
        "previous_page",
        "goto",
        "click",
        "fill",
        "select",
        "press",
    }
    assert "desktop_start_session" in agent.tools
    assert "desktop_stop_session" in agent.tools
    assert "desktop_run_commands" in agent.tools
    assert "desktop" not in agent.tools
    assert [method.__name__ for method in agent.plugins.desktop.get_tools()] == ["run_commands", "start_session", "stop_session"]
    assert "memory_add" in agent.tools
    assert "planner_create" in agent.tools
    assert "planner_add" in agent.tools
    assert "planner_check" in agent.tools
    assert "scheduler_schedule" in agent.tools
    assert "browser_state" in agent.providers
    assert "desktop_state" in agent.providers
    assert "retrieved_memory" in agent.providers
    assert "current_todos" in agent.providers
    assert "python" in agent.plugins
    assert agent.plugins.python.shell.silent is True
    assert not hasattr(agent, "shell")


def test_agent_disables_openai_dependent_features_without_api_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    agent = Agent(session="new", voice_enabled=True)

    assert agent.config.voice_enabled is False
    assert "memory" not in agent.plugins
    assert "memory_add" not in agent.tools
    assert "retrieved_memory" not in agent.providers
    assert not hasattr(agent, "memory")


def test_agent_loads_memory_plugin_with_configured_openai_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    agent = Agent(session="new", openai_api_key="sk-test", voice_enabled=True)

    assert agent.config.voice_enabled is True
    assert "memory" in agent.plugins
    assert "memory_add" in agent.tools
    assert "retrieved_memory" in agent.providers


def test_agent_loads_all_available_builtin_plugins_by_default():
    agent = Agent(session="new", openai_api_key="sk-test", voice_enabled=False)

    assert {
        "bash",
        "browser",
        "content",
        "desktop",
        "environment",
        "files",
        "interface",
        "memory",
        "planner",
        "python",
        "scheduler",
    }.issubset(agent.plugins.keys())


def test_agent_can_disable_all_builtin_plugins():
    agent = Agent(session="new", openai_api_key="sk-test", voice_enabled=False, builtin_plugins=[])

    assert agent.plugins == {}
    assert "browser_state" not in agent.providers
    assert "current_todos" not in agent.providers
    assert "desktop_run_commands" not in agent.tools
    assert "memory_add" not in agent.tools
    assert "planner_create" not in agent.tools
    assert "scheduler_schedule" not in agent.tools
    assert "read" not in agent.tools
    assert "view" not in agent.tools
    assert "bash" not in agent.tools
    assert "python" not in agent.tools
    assert "open_tui" not in agent.tools
    assert "date_and_time" not in agent.providers


def test_agent_can_select_builtin_plugins_by_name():
    agent = Agent(
        session="new",
        openai_api_key="sk-test",
        voice_enabled=False,
        builtin_plugins=["files", "content", "bash", "python", "environment", "planner", "scheduler"],
    )

    assert set(agent.plugins.keys()) == {"files", "content", "bash", "python", "environment", "planner", "scheduler"}
    assert "read" in agent.tools
    assert "write" in agent.tools
    assert "edit" in agent.tools
    assert "view" in agent.tools
    assert "observe" in agent.tools
    assert "show" in agent.tools
    assert "bash" in agent.tools
    assert "python" in agent.tools
    assert "date_and_time" in agent.providers
    assert "cwd" in agent.providers
    assert "planner_create" in agent.tools
    assert "scheduler_schedule" in agent.tools
    assert "browser_state" not in agent.providers
    assert "desktop_run_commands" not in agent.tools
    assert "memory_add" not in agent.tools
    assert "open_tui" not in agent.tools


def test_agent_instantiates_stateful_builtin_plugin_classes():
    import types
    from codex_agent import Plugin, command, event_handler, hook_handler, provider, tool

    module = types.ModuleType("codex_agent.builtin_plugins.fake_stateful")

    class StatefulPlugin(Plugin):
        name = "stateful"

        def __init__(self, agent):
            super().__init__(agent)
            self.counter = 0
            self.events = []
            self.hooks = []

        @tool
        def stateful_tool(self):
            self.counter += 1
            return f"{self.agent.config.name}:{self.counter}"

        @tool
        def ping(self):
            return "pong"

        @provider
        def stateful_context(self):
            return f"counter={self.counter}"

        @command
        def stateful_command(self):
            self.counter += 10
            return self.counter

        @event_handler(AssistantTurnEndEvent)
        def stateful_event_handler(self, event):
            self.events.append((event.type, event.result))

        @hook_handler("stateful.sample")
        def stateful_hook_handler(self, context):
            self.hooks.append(context.payload.value)
            context.payload.value = "handled"

        def get_system_prompt_sections(self):
            return [f"# Stateful Plugin\ncounter={self.counter}"]

    StatefulPlugin.__module__ = module.__name__
    module.StatefulPlugin = StatefulPlugin

    agent = Agent(session="new", voice_enabled=False, name="PluginAgent")
    agent.plugins_manager.add_from_module(module)

    plugin = agent.plugins.stateful
    assert isinstance(plugin, StatefulPlugin)
    assert [method.__name__ for method in plugin.get_tools()] == ["ping", "stateful_tool"]
    assert [method.__name__ for method in plugin.get_providers()] == ["stateful_context"]
    assert [method.__name__ for method in plugin.get_commands()] == ["stateful_command"]
    assert plugin.get_event_handlers() == [(AssistantTurnEndEvent, plugin.stateful_event_handler)]
    assert plugin.get_hook_handlers() == [("stateful.sample", plugin.stateful_hook_handler)]
    assert plugin.get_system_prompt_sections() == ["# Stateful Plugin\ncounter=0"]
    assert "# Stateful Plugin\ncounter=0" in agent.config_manager.system_message().content
    assert "ping" not in agent.tools
    assert agent.tools.stateful_ping() == "pong"
    assert agent.tools.stateful_tool() == "PluginAgent:1"
    assert agent.providers.stateful_context() == "counter=1"
    assert agent.commands.stateful_command() == 11
    assert plugin.counter == 11
    agent.emit(AssistantTurnEndEvent, prompt=None, result=True)
    hook_context = agent.run_hook("stateful.sample", value="original")
    assert plugin.events == [("assistant_turn_end_event", True)]
    assert plugin.hooks == ["original"]
    assert hook_context.payload.value == "handled"


def test_agent_initialization_prefers_project_python_on_process_path(monkeypatch):
    monkeypatch.setenv("PATH", "/usr/bin:/bin")
    agent = Agent(session="new", voice_enabled=False)

    assert os.environ["PATH"].split(os.pathsep)[0] == os.path.dirname(sys.executable)
    assert os.environ["PYTHON"] == sys.executable
    assert agent.execution_env()["PATH"].split(os.pathsep)[0] == os.path.dirname(sys.executable)


def test_agent_can_resume_session_from_file():
    agent = Agent(session="new", voice_enabled=False)
    session_file = agent.session.session_file
    message_count = len(agent.session.messages)

    resumed = Agent(session=session_file, voice_enabled=False)

    assert resumed.current_session_id == agent.current_session_id
    assert len(resumed.session.messages) == message_count + 1
    assert resumed.session.messages[-1].type == "developer_message"


def test_agent_can_resume_latest_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="older")])
    newer = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="newer")])
    older.save()
    newer.save()

    agent = Agent(session="latest", voice_enabled=False)

    assert agent.current_session_id == newer.session_id
    assert any(message.content == "newer" for message in agent.session.messages)


def test_agent_defaults_to_latest_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="older")])
    newer = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="newer")])
    older.save()
    newer.save()

    agent = Agent(voice_enabled=False)

    assert agent.current_session_id == newer.session_id
    assert any(message.content == "newer" for message in agent.session.messages)


def test_agent_get_response_emits_events_and_persists_assistant_message():
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeAI(agent)
    seen = []
    agent.on(ResponseContentDeltaEvent, lambda event: seen.append(event.delta))

    message = agent.get_response()

    assert message.content == "hi"
    assert seen == ["hi"]
    assert agent.session.messages[-1] is message
    assert json.loads(json.dumps(message))["type"] == "assistant_message"
    assert agent.ai.params["verbosity"] == agent.config.verbosity
    assert agent.ai.params["parallel_tool_calls"] is True
    assert agent.ai.params["prompt_cache_key"] == agent.current_session_id
    assert any(tool["type"] == "custom" and tool["name"] == "python" for tool in agent.ai.params["tools"])
    assert any(tool["type"] == "custom" and tool["name"] == "bash" for tool in agent.ai.params["tools"])
    assert any(tool["type"] == "function" and tool["name"] == "read" for tool in agent.ai.params["tools"])
    assert any(tool["type"] == "function" and tool["name"] == "show" for tool in agent.ai.params["tools"])
    assert {"type": "web_search"} in agent.ai.params["tools"]
    assert {"type": "image_generation", "output_format": "png"} in agent.ai.params["tools"]


def test_agent_get_response_saves_api_success_session_backup(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeAI(agent)
    agent.add_message(UserMessage(content="hello"))

    message = agent.get_response()

    assert os.path.isfile(agent.session.api_success_backup_file)
    restored = AgentSession.load(agent.session.api_success_backup_file).messages
    assert [msg.id for msg in restored] == [msg.id for msg in agent.session.messages]
    assert restored[-1].id == message.id


def test_agent_bad_request_restores_last_api_success_backup(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    stable = UserMessage(content="stable")
    agent.sessions_manager.append_message(stable)
    stable_ids = [msg.id for msg in agent.session.messages]
    agent.sessions_manager.save_api_success_backup()
    corrupt = AssistantMessage(content="corrupt")
    corrupt.tool_calls = [{
        "index": 0,
        "type": "custom_tool_call",
        "call_id": "call_missing",
        "name": "desktop",
        "input": "{}",
    }]
    agent.session.messages.append(corrupt)
    agent.session.save()

    class BadRequestAI:
        def run(self, **params):
            raise AIBadRequestError("400 Client Error: Bad Request")

    agent.ai = BadRequestAI()

    with pytest.raises(AIBadRequestError):
        agent.get_response()

    assert [msg.id for msg in agent.session.messages] == stable_ids
    restored = AgentSession.load(agent.current_session_id).messages
    assert [msg.id for msg in restored] == stable_ids


def test_agent_should_auto_compact_uses_ninety_percent_threshold(monkeypatch):
    agent = Agent(session="new", voice_enabled=False, input_token_limit=100)
    messages = [DeveloperMessage(content="context")]

    monkeypatch.setattr(agent.context_manager, "response_input_token_count", lambda *_args, **_kwargs: 90)
    assert agent.context_manager.should_auto_compact(messages) is False

    monkeypatch.setattr(agent.context_manager, "response_input_token_count", lambda *_args, **_kwargs: 91)
    assert agent.context_manager.should_auto_compact(messages) is True

    agent.config.auto_compact = False
    assert agent.context_manager.should_auto_compact(messages) is False


def test_agent_should_auto_compact_counts_response_tool_specs(monkeypatch):
    agent = Agent(session="new", voice_enabled=False, input_token_limit=100)
    messages = [DeveloperMessage(content="context")]
    seen = []

    def count(messages_arg, response_tools=None):
        seen.append(response_tools)
        return 91

    monkeypatch.setattr(agent.context_manager, "response_input_token_count", count)
    assert agent.context_manager.should_auto_compact(messages) is True
    assert seen == [agent.tools_manager.get_response_tools()]


def test_agent_get_response_auto_compacts_before_backend_call(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeAI(agent)
    calls = []
    agent.session.messages.extend([
        DeveloperMessage(content="compact me"),
        AssistantMessage(content="done"),
    ])

    def compact(session, **params):
        calls.append(params)
        message = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
        session.messages.append(message)
        return message

    agent.context_manager.should_auto_compact = lambda _messages: True
    monkeypatch.setattr(AgentSession, "compact", compact)

    agent.get_response()

    assert calls == [{
        "model": agent.config.model,
        "instructions": agent.config_manager.system_message().content,
    }]
    assert any(isinstance(message, CompactionMessage) for message in agent.ai.params["messages"])


def test_agent_interrupt_emits_event_once():
    agent = Agent(session="new", voice_enabled=False)
    abortable = AbortableAI()
    agent.ai = abortable
    seen = []

    agent.on(AssistantInterruptedEvent, lambda event: seen.append(event.reason))

    assert agent.interrupt("test") is True
    assert agent.interrupt("again") is True
    assert agent.is_interrupted() is True
    assert abortable.aborted is True
    assert seen == ["test"]

    agent.clear_interrupt()
    assert agent.is_interrupted() is False


def test_agent_interrupt_does_not_propagate_abort_errors():
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FailingAbortAI()
    seen = []

    agent.on(AssistantInterruptRequestedEvent, lambda event: seen.append(event.error))

    assert agent.interrupt("api") is True
    assert agent.is_interrupted() is True
    assert seen == ["abort failed"]


def test_agent_process_stops_on_interruption():
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = InterruptingAI(agent)
    before = len(agent.session.messages)

    assert agent.mainloop_manager.process() is False
    assert len(agent.session.messages) == before + 1
    assert isinstance(agent.session.messages[-1], InterruptMessage)
    assert agent.session.messages[-1].content == "User interrupted the current turn."


def test_agent_interrupt_after_tool_call_persists_tool_result_before_stopping():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_tool
    def interrupting_tool():
        agent.interrupt("test")
        return "finished current tool"

    message = AssistantMessage(content="calling")
    message.tool_calls = [{
        "index": 0,
        "type": "function_call",
        "call_id": "call_1",
        "name": "interrupting_tool",
        "arguments": "{}",
    }]

    with pytest.raises(AssistantInterrupted):
        agent.mainloop_manager.call_tools(message)

    assert agent.session.messages[-1].type == "tool_result_message"
    assert agent.session.messages[-1].call_id == "call_1"
    assert "success" in agent.session.messages[-1].content
    assert agent.mainloop_manager.stop_agentic_loop is True


def test_agent_interrupt_after_tool_call_closes_remaining_tool_calls():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_tool
    def interrupting_tool():
        agent.interrupt("test")
        return "finished current tool"

    @agent.add_tool
    def later_tool():
        raise AssertionError("later tool should not start after interrupt")

    message = AssistantMessage(content="calling")
    message.tool_calls = [
        {
            "index": 0,
            "type": "function_call",
            "call_id": "call_1",
            "name": "interrupting_tool",
            "arguments": "{}",
        },
        {
            "index": 1,
            "type": "function_call",
            "call_id": "call_2",
            "name": "later_tool",
            "arguments": "{}",
        },
    ]

    with pytest.raises(AssistantInterrupted):
        agent.mainloop_manager.call_tools(message)

    results = [msg for msg in agent.session.messages if isinstance(msg, ToolResultMessage)]
    assert [result.call_id for result in results] == ["call_1", "call_2"]
    assert "success" in results[0].content
    assert "not started" in results[1].content


def test_agent_combines_local_and_server_tools_for_response():
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeAI(agent)
    agent.tools_manager.add_server_tool(WebSearchTool())
    agent.tools_manager.add_server_tool(ImageGenerationTool())

    agent.get_response()

    tools = agent.ai.params["tools"]
    assert any(tool["type"] == "function" and tool["name"] == "read" for tool in tools)
    assert any(tool["type"] == "custom" and tool["name"] == "python" for tool in tools)
    assert any(tool["type"] == "custom" and tool["name"] == "bash" for tool in tools)
    assert any(tool["type"] == "function" and tool["name"] == "show" for tool in tools)
    assert any(tool["type"] == "function" and tool["name"] == "edit" for tool in tools)
    assert {"type": "web_search"} in tools
    assert {"type": "image_generation", "output_format": "png"} in tools


def test_builtin_read_tool_survives_get_text_submodule_shadowing():

    agent = Agent(session="new", voice_enabled=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": '{"reads": {"source": "codex_agent/builtin_plugins/files/tools.py"}}',
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert isinstance(agent.mainloop_manager.pending[-1], ToolResultWrapper)
    assert "'module' object is not callable" not in agent.mainloop_manager.pending[-1].content
    assert "def read(" in agent.mainloop_manager.pending[-1].content


def test_builtin_read_tool_accepts_pattern_and_includes_context(tmp_path):
    file = tmp_path / "sample.txt"
    lines = [f"line {index}" for index in range(1, 31)]
    lines[20] = "line 21 needle"
    file.write_text("\n".join(lines), encoding="utf-8")

    agent = Agent(session="new", voice_enabled=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": f'{{"reads": {{"source": "{file}", "pattern": "needle"}}}}',
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert isinstance(agent.mainloop_manager.pending[-1], ToolResultWrapper)
    assert "11|line 11" in agent.mainloop_manager.pending[-1].content
    assert "21|line 21 needle" in agent.mainloop_manager.pending[-1].content
    assert "10|line 10" not in agent.mainloop_manager.pending[-1].content


def test_builtin_read_tool_accepts_regex_pattern(tmp_path):
    file = tmp_path / "sample.txt"
    lines = ["alpha", "ticket ABC-123", *[f"line {index}" for index in range(3, 25)], "ticket XYZ-123"]
    file.write_text("\n".join(lines), encoding="utf-8")

    agent = Agent(session="new", voice_enabled=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": f'{{"reads": {{"source": "{file}", "pattern": "ABC-\\\\d+", "regex": true}}}}',
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert isinstance(agent.mainloop_manager.pending[-1], ToolResultWrapper)
    assert "2|ticket ABC-123" in agent.mainloop_manager.pending[-1].content
    assert "3|ticket XYZ-123" not in agent.mainloop_manager.pending[-1].content


def test_builtin_read_tool_accepts_multiple_reads(tmp_path):
    file_one = tmp_path / "one.txt"
    file_two = tmp_path / "two.txt"
    file_one.write_text("alpha\nbeta", encoding="utf-8")
    file_two.write_text("gamma\ndelta", encoding="utf-8")

    agent = Agent(session="new", voice_enabled=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_batch",
        "name": "read",
        "arguments": json.dumps({
            "reads": [
                {"source": str(file_one)},
                {"source": str(file_two), "start_at_line": 2},
            ]
        }),
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_batch"
    assert "2 outputs in ToolResultWrapper ids=" in agent.session.messages[-1].content
    assert [wrapper.call_id for wrapper in agent.mainloop_manager.pending[-2:]] == ["call_batch", "call_batch"]
    assert "1|alpha" in agent.mainloop_manager.pending[-2].content
    assert "2|beta" in agent.mainloop_manager.pending[-2].content
    assert "1|gamma" not in agent.mainloop_manager.pending[-1].content
    assert "2|delta" in agent.mainloop_manager.pending[-1].content


def test_agent_applies_image_generation_tool_config():
    agent = Agent(
        session="new",
        voice_enabled=False,
        image_generation_size="1024x1024",
        image_generation_quality="low",
        image_generation_background="opaque",
        image_generation_moderation="low",
    )
    agent.ai = FakeAI(agent)

    agent.get_response()

    assert {
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
        "quality": "low",
        "background": "opaque",
        "moderation": "low",
    } in agent.ai.params["tools"]


def test_agent_create_image_generates_without_touching_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeImageAI(agent)
    before = len(agent.session.messages)

    path = agent.create_image("draw a red square", size="1024x1024")

    assert path.startswith(str(tmp_path / "images"))
    assert len(agent.session.messages) == before
    assert agent.ai.params["messages"][0].type == "system_message"
    assert "specialized image creation assistant" in agent.ai.params["messages"][0].content
    assert agent.ai.params["messages"][-1].content == [{"type": "text", "text": "draw a red square"}]
    assert agent.ai.params["model"] == "gpt-5.4"
    assert agent.ai.params["reasoning_effort"] == "medium"
    assert agent.ai.params["verbosity"] == "medium"
    assert agent.ai.params["tools"] == [{
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
    }]


def test_agent_create_image_accepts_input_images(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeImageAI(agent)
    source = b"source image bytes"

    path = agent.create_image("make a variation", input_images=[source])
    content = agent.ai.params["messages"][-1].content

    assert path.startswith(str(tmp_path / "images"))
    assert content[0] == {"type": "text", "text": "make a variation"}
    assert any(part.get("type") == "input_image" for part in content)


def test_agent_create_image_allows_llm_parameter_overrides(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeImageAI(agent)

    agent.create_image(
        "draw a red square",
        model="gpt-test",
        reasoning_effort="low",
        verbosity="high",
    )

    assert agent.ai.params["model"] == "gpt-test"
    assert agent.ai.params["reasoning_effort"] == "low"
    assert agent.ai.params["verbosity"] == "high"


def test_agent_create_image_uses_explicit_generation_parameters(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(
        session="new",
        voice_enabled=False,
        image_generation_size="should-not-leak",
        image_generation_quality="should-not-leak",
    )
    agent.ai = FakeImageAI(agent)

    agent.create_image(
        "draw a red square",
        output_format="png",
        size="1024x1024",
        quality="low",
        background="opaque",
        moderation="low",
    )

    assert agent.ai.params["tools"] == [{
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
        "quality": "low",
        "background": "opaque",
        "moderation": "low",
    }]


def test_agent_emits_server_tool_call_event_from_output_items():
    agent = Agent(session="new", voice_enabled=False)
    item = {
        "type": "web_search_call",
        "id": "ws_123",
        "status": "completed",
    }
    agent.ai._codex_client = FakeCodexClient([OutputItem.from_dict(item)])
    seen = []

    agent.on(ServerToolCallEvent, lambda event: seen.append((event.name, event.call_id, event.status)))
    agent.ai.run(
        messages=[],
        tools=agent.tools_manager.get_response_tools(),
        **agent.config.extract("model", "reasoning_effort", "verbosity"),
    )

    assert seen == [("web_search", "ws_123", "completed")]
    assert agent.ai._codex_client.kwargs["prompt_cache_key"] is None


def test_agent_caches_status_from_completed_response():
    agent = Agent(session="new", voice_enabled=False, input_token_limit=20_000)
    agent.ai._codex_client = FakeCodexClient([
        ResponseCompleted(response_id="resp_123", usage=TokenUsage(input_tokens=4000)),
    ])

    agent.ai.run(messages=[], tools=[], model="gpt-test")

    status = agent.get_status()
    assert status.context_current_tokens == 4000
    assert status.context_limit_tokens == 20_000
    assert status.context_percent == 20
    assert status.quota_5h_percent == 11
    assert status.quota_7d_percent == 22
    assert status.model == "gpt-test"


def test_agent_persists_server_tool_output_items_as_messages():
    agent = Agent(session="new", voice_enabled=False)
    item = {
        "type": "web_search_call",
        "id": "ws_123",
        "status": "completed",
    }
    agent.ai._codex_client = FakeCodexClient([OutputItem.from_dict(item)])

    message = agent.get_response()
    server_message = agent.session.messages[-1]

    assert message.output_items[0].type == "web_search_call"
    assert "output_items" not in message
    assert isinstance(server_message, ServerToolResponseMessage)
    assert server_message.item == item
    assert server_message.to_response_format() == item


def test_agent_persists_generated_images_as_observable_files(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    item = {
        "type": "image_generation_call",
        "id": "ig_123",
        "result": "Zm9v",
    }
    agent.ai._codex_client = FakeCodexClient([OutputItem.from_dict(item)])

    message = agent.get_response()
    server_message = agent.session.messages[-1]
    assistant_payload = json.loads(json.dumps(message))
    payload = json.loads(json.dumps(server_message))

    assert "output_items" not in assistant_payload
    assert "Zm9v" not in json.dumps(assistant_payload)
    assert isinstance(server_message, ServerToolResponseMessage)
    assert server_message.item == {"type": "image_generation_call", "id": "ig_123"}
    assert server_message.content.startswith(str(tmp_path / "images"))
    assert "Zm9v" not in json.dumps(payload)
    assert server_message.as_image_message().content == server_message.content


def test_agent_creates_runtime_extension_folders(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    Agent(session="new", voice_enabled=False)

    assert not (tmp_path / "tools").exists()
    assert not (tmp_path / "providers").exists()
    assert (tmp_path / "commands").is_dir()
    assert (tmp_path / "plugins").is_dir()


def test_agent_loads_stateful_runtime_plugins(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "custom_plugin.py").write_text(
        """
from codex_agent import Plugin, command, provider, tool

class CustomRuntimePlugin(Plugin):
    name = "custom_runtime"
    system_prompt = "# Custom Runtime Plugin\\nUse custom runtime helpers when useful."

    def __init__(self, agent):
        super().__init__(agent)
        self.count = 0

    @tool
    def ping(self):
        self.count += 1
        return f"{self.agent.config.name}:{self.count}"

    @provider
    def custom_context(self):
        return f"custom-count={self.count}"

    @command
    def custom_command(self):
        self.count += 10
        return self.count
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False, name="RuntimeAgent")

    assert "custom_runtime" in agent.plugins
    assert agent.tools.custom_runtime_ping() == "RuntimeAgent:1"
    assert agent.providers.custom_context() == "custom-count=1"
    assert agent.commands.custom_command() == 11
    assert "# Custom Runtime Plugin" in agent.config_manager.system_message().content


def test_agent_loads_runtime_plugin_register_modules(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "registered.py").write_text(
        """
def register(agent):
    @agent.add_tool(name="registered_plugin_tool")
    def registered_plugin_tool():
        return agent.config.name

    @agent.add_provider(name="registered_plugin_context")
    def registered_plugin_context():
        return "registered context"

    @agent.add_command(name="registered_plugin_command")
    def registered_plugin_command(args=""):
        return f"registered:{args}"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False, name="RegisteredAgent")

    assert agent.tools.registered_plugin_tool() == "RegisteredAgent"
    assert agent.providers.registered_plugin_context() == "registered context"
    assert agent("/registered_plugin_command hello") == "registered:hello"


def test_agent_can_select_runtime_plugins_by_module_name(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "enabled_plugin.py").write_text(
        """
from codex_agent import Plugin, tool

class EnabledPlugin(Plugin):
    name = "enabled_runtime"

    @tool
    def ping(self):
        return "enabled"
""",
        encoding="utf-8",
    )
    (plugins_dir / "disabled_plugin.py").write_text(
        """
from codex_agent import Plugin, tool

class DisabledPlugin(Plugin):
    name = "disabled_runtime"

    @tool
    def ping(self):
        return "disabled"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False, custom_plugins=["enabled_plugin"])

    assert "enabled_runtime" in agent.plugins
    assert agent.tools.enabled_runtime_ping() == "enabled"
    assert "disabled_runtime" not in agent.plugins
    assert "disabled_runtime_ping" not in agent.tools


def test_agent_can_disable_all_runtime_plugins(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    (plugins_dir / "custom_plugin.py").write_text(
        """
from codex_agent import Plugin, tool

class CustomPlugin(Plugin):
    name = "custom_runtime"

    @tool
    def ping(self):
        return "custom"
""",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False, custom_plugins=[])

    assert "custom_runtime" not in agent.plugins
    assert "custom_runtime_ping" not in agent.tools


def test_builtin_edit_tool_applies_single_exact_replacement(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("hello world\n", encoding="utf-8")

    result = agent.tools.edit({
        "file_path": str(path),
        "old_string": "hello",
        "new_string": "bonjour",
    })

    assert "1. success: replaced 1 match" in result
    assert path.read_text(encoding="utf-8") == "bonjour world\n"


def test_builtin_python_tool_runs_in_persistent_shell():
    agent = Agent(session="new", voice_enabled=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "python",
        "input": "x = 40\nx + 2",
    }]

    assert agent.mainloop_manager.call_tools(message) is True

    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert "result:\n42" in agent.mainloop_manager.pending[-1].content


def test_builtin_bash_tool_runs_shell_commands():
    agent = Agent(session="new", voice_enabled=False)

    result = agent.tools.bash("printf hello")

    assert result == "stdout:\nhello"


def test_builtin_bash_tool_reports_stderr_and_exit_code():
    agent = Agent(session="new", voice_enabled=False)

    result = agent.tools.bash("echo problem >&2; exit 7")

    assert "stderr:\nproblem\n" in result
    assert "exit_code: 7" in result


def test_builtin_bash_tool_prefers_agent_python_environment(monkeypatch):
    monkeypatch.setenv("PATH", "/usr/bin:/bin")
    agent = Agent(session="new", voice_enabled=False)

    result = agent.tools.bash("command -v python && python -c 'import sys; print(sys.executable)'")

    assert sys.executable in result


def test_builtin_write_tool_writes_complete_file(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "notes" / "note.txt"

    result = agent.tools.write({"file_path": str(path), "content": "hello\nworld\n"})

    assert "1. success: wrote 12 characters" in result
    assert path.read_text(encoding="utf-8") == "hello\nworld\n"


def test_builtin_write_tool_overwrites_existing_file(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("old\ncontent\n", encoding="utf-8")

    result = agent.tools.write({"file_path": str(path), "content": "new\n"})

    assert "1. success: wrote 4 characters" in result
    assert path.read_text(encoding="utf-8") == "new\n"


def test_builtin_write_tool_writes_multiple_files(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    first = tmp_path / "one.txt"
    second = tmp_path / "nested" / "two.txt"

    result = agent.tools.write(writes=[
        {"file_path": str(first), "content": "one\n"},
        {"file_path": str(second), "content": "two\n"},
    ])

    assert "1. success: wrote 4 characters" in result
    assert "2. success: wrote 4 characters" in result
    assert first.read_text(encoding="utf-8") == "one\n"
    assert second.read_text(encoding="utf-8") == "two\n"


def test_open_tui_tool_bridges_to_agent_server():
    import codex_agent.builtin_plugins.content.system as system_tools
    from codex_agent.tool import reset_current_agent, set_current_agent
    from modict import modict

    class FakeAgent:
        def open_tui(self):
            return modict(opened=True, terminal_pid=1234)

    token = set_current_agent(FakeAgent())
    try:
        result = system_tools.open_tui()
    finally:
        reset_current_agent(token)

    assert result == "Opened TUI terminal process 1234."


def test_open_and_close_tui_tools_use_server_registered_tui():
    import codex_agent.builtin_plugins.content.system as system_tools
    from codex_agent.tool import reset_current_agent, set_current_agent
    from modict import modict

    class FakeAgent:
        def open_tui(self):
            return modict(already_open=True, tui=modict(pid=1234))

        def close_tui(self):
            return modict(closed=True, pid=1234)

    token = set_current_agent(FakeAgent())
    try:
        opened = system_tools.open_tui()
        closed = system_tools.close_tui()
    finally:
        reset_current_agent(token)

    assert opened == "TUI is already open with pid 1234."
    assert closed == "Closed TUI process 1234."


def test_builtin_write_tool_schema_is_structured_function_tool():
    agent = Agent(session="new", voice_enabled=False)

    assert agent.tools.write.to_response_tool() == {
        "type": "function",
        "name": "write",
        "description": "Write or overwrite one or more complete UTF-8 text files.\nUse this when creating new text files or replacing entire files is clearer than targeted edits.\nParent directories are created automatically.\nPass either a single write object or a list of write objects.\n",
        "parameters": {
            "type": "object",
            "properties": {
                "writes": {
                    "description": "A single write object or a list of write objects.\nEach object must contain file_path and content.\n",
                    "anyOf": [
                        {
                            "type": "object",
                            "properties": {
                                "file_path": {"type": "string"},
                                "content": {"type": "string"},
                            },
                            "required": ["file_path", "content"],
                        },
                        {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "file_path": {"type": "string"},
                                    "content": {"type": "string"},
                                },
                                "required": ["file_path", "content"],
                            },
                        },
                    ],
                },
            },
            "required": ["writes"],
        },
    }


def test_builtin_edit_tool_requires_single_match_unless_replace_all(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("x x x", encoding="utf-8")

    failed = agent.tools.edit({
        "file_path": str(path),
        "old_string": "x",
        "new_string": "y",
    })
    assert "failed: old_string matched 3 times" in failed
    assert path.read_text(encoding="utf-8") == "x x x"

    succeeded = agent.tools.edit({
        "file_path": str(path),
        "old_string": "x",
        "new_string": "y",
        "replace_all": True,
    })
    assert "success: replaced 3 matches" in succeeded
    assert path.read_text(encoding="utf-8") == "y y y"


def test_builtin_edit_tool_applies_multiple_edits_in_sequence(tmp_path):
    agent = Agent(session="new", voice_enabled=False)
    path = tmp_path / "note.txt"
    path.write_text("alpha beta gamma", encoding="utf-8")

    result = agent.tools.edit([
        {
            "file_path": str(path),
            "old_string": "alpha",
            "new_string": "one",
        },
        {
            "file_path": str(path),
            "old_string": "one beta",
            "new_string": "two",
        },
        {
            "file_path": str(path),
            "old_string": "missing",
            "new_string": "nope",
        },
    ])

    assert "1. success" in result
    assert "2. success" in result
    assert "3. failed: old_string not found" in result
    assert path.read_text(encoding="utf-8") == "two gamma"


def test_agent_add_image_rejects_invalid_image_without_polluting_session():
    agent = Agent(session="new", voice_enabled=False)
    initial_count = len(agent.session.messages)
    with pytest.raises(ValueError, match="Invalid or inaccessible image source"):
        agent.add_image("/tmp/definitely-missing-image.png")
    assert len(agent.session.messages) == initial_count

def test_tool_can_describe_freeform_custom_tool():
    def code_exec(source):
        """Executes Python source code."""
        return source

    tool = Tool.from_callable(code_exec, tool_type="custom")

    assert tool.to_response_tool() == {
        "type": "custom",
        "name": "code_exec",
        "description": "Executes Python source code.",
    }


def test_tool_is_modict_payload_with_runtime_callable_attr():
    def echo(text: str):
        return text

    tool = Tool.from_callable(echo)

    assert isinstance(tool, dict)
    assert tool["name"] == "echo"
    assert tool["type"] == "tool"
    assert tool["tool_type"] == "function"
    assert tool["description"] == ""
    assert tool["parameters"] == {"text": {"type": "string"}}
    assert tool["required"] == ["text"]
    assert "schema" not in tool
    assert "mode" not in tool
    assert "format" not in tool
    assert "obj" not in tool
    assert "callable" not in tool
    assert tool("hi") == "hi"


def test_tool_parses_yaml_docstring():
    def lookup(query):
        """
        description: Finds a value.
        parameters:
          query:
            type: string
            description: Search query.
        required:
          - query
        """
        return query

    assert Tool.from_callable(lookup).to_response_tool() == {
        "type": "function",
        "name": "lookup",
        "description": "Finds a value.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query.",
                },
            },
            "required": ["query"],
        },
    }


def test_tool_infers_parameters_from_signature_annotations():
    def search(query: str, limit: int = 5, exact: bool = False):
        """Searches things."""
        return query

    assert Tool.from_callable(search).to_response_tool() == {
        "type": "function",
        "name": "search",
        "description": "Searches things.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
                "exact": {"type": "boolean", "default": False},
            },
            "required": ["query"],
        },
    }


def test_tool_infers_literal_and_array_annotations():
    def filter_items(tags: list[str], mode: Literal["all", "any"] = "all"):
        return tags

    assert Tool.from_callable(filter_items).to_response_tool()["parameters"] == {
        "type": "object",
        "properties": {
            "tags": {
                "type": "array",
                "items": {"type": "string"},
            },
            "mode": {
                "enum": ["all", "any"],
                "type": "string",
                "default": "all",
            },
        },
        "required": ["tags"],
    }


def test_tool_docstring_parameter_schema_overrides_inference():
    def lookup(query: str):
        """
        description: Finds a value.
        parameters:
          query:
            type: string
            description: Search query.
        """
        return query

    assert Tool.from_callable(lookup).to_response_tool()["parameters"]["properties"]["query"] == {
        "type": "string",
        "description": "Search query.",
    }


def test_tool_can_describe_grammar_constrained_custom_tool():
    def math_exp(source):
        return source

    tool = Tool.from_callable(
        math_exp,
        tool_type="custom",
        description="Creates a math expression.",
        format={
            "type": "grammar",
            "syntax": "lark",
            "definition": "start: /[0-9]+/",
        },
    )

    assert tool.to_response_tool() == {
        "type": "custom",
        "name": "math_exp",
        "description": "Creates a math expression.",
        "format": {
            "type": "grammar",
            "syntax": "lark",
            "definition": "start: /[0-9]+/",
        },
    }


def test_agent_calls_custom_tool_with_raw_input():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)
    seen = []

    @agent.add_tool(tool_type="custom", description="Echoes raw text.")
    def echo_raw(text):
        seen.append(text)
        return text.upper()

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "echo_raw",
        "input": "hello",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert seen == ["hello"]
    assert agent.session.messages[-1].to_response_format() == {
        "type": "custom_tool_call_output",
        "call_id": "call_1",
        "output": f"success: call_id=call_1; full output in ToolResultWrapper id={agent.mainloop_manager.pending[-1].id}.",
    }
    assert agent.mainloop_manager.pending[-1].content == "HELLO"


def test_agent_keeps_tool_outputs_contiguous_and_wrappers_pending():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)

    @agent.add_tool
    def echo(value):
        return value

    message = AssistantMessage()
    message.tool_calls = [
        {
            "type": "function_call",
            "call_id": "call_1",
            "name": "echo",
            "arguments": '{"value": "one"}',
        },
        {
            "type": "function_call",
            "call_id": "call_2",
            "name": "echo",
            "arguments": '{"value": "two"}',
        },
    ]

    assert agent.mainloop_manager.call_tools(message) is True

    outputs = agent.session.messages[-2:]
    assert [output.call_id for output in outputs] == ["call_1", "call_2"]
    assert [output.type for output in outputs] == ["tool_result_message", "tool_result_message"]
    assert [wrapper.call_id for wrapper in agent.mainloop_manager.pending[-2:]] == ["call_1", "call_2"]
    assert [wrapper.content for wrapper in agent.mainloop_manager.pending[-2:]] == ["one", "two"]
    assert [wrapper.turns_left for wrapper in agent.mainloop_manager.pending[-2:]] == [3, 3]


def test_tool_can_access_current_agent_context():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)

    @agent.add_tool
    def agent_name():
        """Gets the current agent name."""
        return get_agent().config.name

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "agent_name",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert agent.mainloop_manager.pending[-1].content == agent.config.name


def test_tool_can_access_current_call_id_context():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)

    @agent.add_tool
    def current_call_id():
        """Gets the active tool call id."""
        return get_current_call_id()

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_abc",
        "name": "current_call_id",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.mainloop_manager.pending[-1].content == "call_abc"


def test_tool_can_return_multiple_output_wrappers():
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)

    @agent.add_tool
    def many_outputs():
        """Returns multiple pending output messages."""
        return [
            "first",
            ToolResultWrapper(call_id=get_current_call_id(), tool_name="many_outputs", content="second"),
        ]

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_multi",
        "name": "many_outputs",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_multi"
    assert "2 outputs in ToolResultWrapper ids=" in agent.session.messages[-1].content
    assert [wrapper.call_id for wrapper in agent.mainloop_manager.pending[-2:]] == ["call_multi", "call_multi"]
    assert [wrapper.content for wrapper in agent.mainloop_manager.pending[-2:]] == ["first", "second"]


def test_tool_can_return_image_message_output(tmp_path):
    from PIL import Image

    image_path = tmp_path / "tool-image.png"
    Image.new("RGB", (1, 1), color="blue").save(image_path)
    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)

    @agent.add_tool
    def image_output():
        """Returns an image as a pending output message."""
        return ImageMessage(content=str(image_path), turns_left=3)

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_image",
        "name": "image_output",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_image"
    assert "full output in ImageMessage id=" in agent.session.messages[-1].content
    assert isinstance(agent.mainloop_manager.pending[-1], ImageMessage)
    assert agent.mainloop_manager.pending[-1].content == str(image_path)
    assert agent.mainloop_manager.pending[-1].turns_left == 3


def test_builtin_observe_tool_accepts_multiple_sources(tmp_path):
    from PIL import Image

    image_one = tmp_path / "one.png"
    image_two = tmp_path / "two.png"
    Image.new("RGB", (1, 1), color="red").save(image_one)
    Image.new("RGB", (1, 1), color="green").save(image_two)

    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_observe",
        "name": "observe",
        "arguments": json.dumps({"sources": [
            {"target": "path", "path": str(image_one)},
            {"target": "path", "path": str(image_two)},
        ]}),
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_observe"
    assert "2 outputs in pending messages ids=" in agent.session.messages[-1].content
    observed = agent.mainloop_manager.pending[-2:]
    assert all(isinstance(image, ImageMessage) for image in observed)
    assert [image.content for image in observed] == [str(image_one), str(image_two)]
    assert [image.turns_left for image in observed] == [3, 3]


def test_builtin_observe_url_falls_back_to_page_screenshot(tmp_path, monkeypatch):
    from PIL import Image
    import codex_agent.builtin_plugins.content.vision as vision_tools

    screenshot_path = tmp_path / "page.png"
    Image.new("RGB", (1, 1), color="purple").save(screenshot_path)
    calls = []

    def fail_image_download(url):
        raise ValueError("URL did not resolve to an image")

    class FakeBrowserController:
        def capture_page_screenshot(self, url, path, **kwargs):
            calls.append((url, path, kwargs))
            return str(screenshot_path)

    monkeypatch.setattr(vision_tools, "persist_image_url", fail_image_download)
    monkeypatch.setattr(vision_tools, "get_browser_controller", lambda: FakeBrowserController(), raising=False)

    image = vision_tools.observe_source({"target": "url", "url": "https://example.com/page"})

    assert isinstance(image, ImageMessage)
    assert image.content == str(screenshot_path)
    assert image.image_name == "Screenshot of https://example.com/page"
    assert image.turns_left == 3
    assert image.is_valid()
    assert calls
    assert calls[0][0] == "https://example.com/page"
    assert calls[0][2]["full_page"] is True


def test_builtin_observe_accepts_screen_and_window_targets(tmp_path, monkeypatch):
    from PIL import Image
    import codex_agent.builtin_plugins.content.vision as vision_tools

    screen_path = tmp_path / "screen.png"
    window_path = tmp_path / "window.png"
    Image.new("RGB", (1, 1), color="black").save(screen_path)
    Image.new("RGB", (1, 1), color="white").save(window_path)

    screen_calls = []
    window_calls = []

    class FakeDesktopController:
        def capture_screen(self, output_path=None):
            screen_calls.append(output_path)
            return str(screen_path)

        def capture_window(self, window_id, output_path=None):
            window_calls.append((window_id, output_path))
            return str(window_path)

    monkeypatch.setattr(vision_tools, "get_desktop_controller", lambda: FakeDesktopController(), raising=False)

    observed = vision_tools.observe([
        {"target": "screen", "image_name": "desktop"},
        {"target": "window", "window_id": "0x123", "image_name": "app"},
    ])

    assert all(isinstance(image, ImageMessage) for image in observed)
    assert [image.content for image in observed] == [str(screen_path), str(window_path)]
    assert [image.image_name for image in observed] == ["desktop", "app"]
    assert [image.turns_left for image in observed] == [3, 3]
    assert screen_calls == [None]
    assert window_calls == [("0x123", None)]


def test_builtin_desktop_state_provider_only_emits_when_live(tmp_path, monkeypatch):
    from PIL import Image
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    screenshot_path = tmp_path / "live.png"
    grid_path = tmp_path / "live-grid.png"
    Image.new("RGB", (1, 1), color="blue").save(screenshot_path)

    class FakeDesktop:
        live_session = False

        def capture_screen(self, output_path):
            assert output_path.endswith("live_desktop.png")
            return str(screenshot_path)

        def list_windows(self):
            return [modict(
                id="0x123",
                x=10,
                y=20,
                width=800,
                height=600,
                wm_class="app.Class",
                active=True,
                visible=True,
                title="Example window",
            )]

    fake = FakeDesktop()
    monkeypatch.setattr(desktop_plugin, "_draw_desktop_grid", lambda path: str(grid_path))
    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = fake

    assert plugin.desktop_state() is None

    fake.live_session = True
    result = plugin.desktop_state()

    assert "Desktop live session is active" in result[0]
    assert "light 100 px coordinate grid" in result[0]
    assert "0x123 800x600+10+20" in result[0]
    assert "Example window" in result[0]
    assert isinstance(result[1], ImageMessage)
    assert result[1].content == str(grid_path)
    assert result[1].image_name == "live_desktop_grid.png"


def test_builtin_desktop_run_commands_schema_exposes_actions_only():
    agent = Agent(session="new", voice_enabled=False)

    tool_schema = agent.tools.desktop_run_commands.to_response_tool()

    assert tool_schema["type"] == "custom"
    assert "activate_window" in tool_schema["description"]
    assert '"command": "click_drag_release"' in tool_schema["description"]
    assert '"command": "copy", "text": "hello"' in tool_schema["description"]
    assert '"command": "paste"' in tool_schema["description"]
    assert '"command": "press", "keys": "Return"' in tool_schema["description"]
    assert "one simultaneous key chord in xdotool key format" in tool_schema["description"]
    assert '"command": "zoom", "x": 600, "y": 300, "width": 400, "height": 250' in tool_schema["description"]
    assert "grid_step" not in tool_schema["description"]
    assert "scale" not in tool_schema["description"]
    assert "type_text" not in tool_schema["description"]
    assert "load_clipboard" not in tool_schema["description"]
    assert "paste_clipboard" not in tool_schema["description"]
    assert "desktop_start_session" in tool_schema["description"]
    assert "list_windows" not in tool_schema["description"]
    assert "mouse_location" not in tool_schema["description"]
    assert "live_session_status" not in tool_schema["description"]
    assert "capture_region_grid" not in tool_schema["description"]


def test_builtin_desktop_batch_runs_multiple_commands(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = False

        def start_live_session(self):
            self.live_session = True
            calls.append("start")

        def move_mouse(self, x, y):
            calls.append(("move", x, y))

        def press(self, keys):
            calls.append(("press", keys))

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()
    plugin.command_settle_seconds = 1
    sleeps = []
    monkeypatch.setattr(desktop_plugin.time, "sleep", lambda seconds: sleeps.append(seconds))

    start_result = plugin.start_session()
    result = plugin.run_commands("""[
        {"command": "move_mouse", "x": 10, "y": 20},
        {"command": "press", "keys": "Return"}
    ]""")

    assert "Desktop live session started" in start_result
    assert calls == ["start", ("move", 10, 20), ("press", "Return")]
    assert result == ["Moved mouse to 10,20.", "Pressed keys Return."]
    assert sleeps == [1]


def test_builtin_desktop_clipboard_commands_delegate(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = True

        def copy(self, text=None):
            calls.append(("copy", text))

        def paste(self):
            calls.append(("paste",))

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()

    result = plugin.run_commands(json.dumps([
        {"command": "copy", "text": "hello clipboard"},
        {"command": "paste"},
        {"command": "copy"},
    ]))

    assert calls == [("copy", "hello clipboard"), ("paste",), ("copy", None)]
    assert result == [
        "Copied 15 character(s) to the clipboard.",
        "Pasted clipboard at the cursor location.",
        "Copied current selection to the clipboard.",
    ]


def test_agent_calls_builtin_desktop_as_custom_tool(monkeypatch):

    class FakeDesktop:
        live_session = False

        def move_mouse(self, x, y):
            raise AssertionError("desktop action should not run while live session is inactive")

    agent = Agent(session="new", voice_enabled=False, auto_proceed=False)
    agent.plugins.desktop.desktop_controller = FakeDesktop()
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_desktop",
        "name": "desktop_run_commands",
        "input": "{\"command\":\"move_mouse\",\"x\":10,\"y\":20}",
    }]

    assert agent.tools["desktop_run_commands"].to_response_tool()["type"] == "custom"
    assert agent.mainloop_manager.call_tools(message) is True

    assert "success: call_id=call_desktop" in agent.session.messages[-1].content
    assert "failed: desktop live session is not active" in agent.mainloop_manager.pending[-1].content


def test_builtin_desktop_zoom_returns_image(tmp_path):
    from PIL import Image
    from codex_agent.image import ImageMessage
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    screenshot_path = tmp_path / "screen.png"
    Image.new("RGB", (120, 90), color="navy").save(screenshot_path)

    class FakeDesktop:
        live_session = True

        def capture_screen(self, path):
            return str(screenshot_path)

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()
    output_path = tmp_path / "zoom.png"

    result = plugin.run_commands({
        "command": "zoom",
        "x": 10,
        "y": 20,
        "width": 50,
        "height": 40,
        "output_path": str(output_path),
    })

    assert "Zoomed desktop region 50x40+10+20" in result[0]
    assert isinstance(result[1], ImageMessage)
    assert result[1].content == str(output_path)
    assert result[1].image_name == "desktop_zoom_10_20_50x40.png"
    with Image.open(output_path) as image:
        assert image.size == (800, 640)


def test_builtin_desktop_move_resize_window_delegates(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = True

        def move_resize_window(self, window_id, x, y, width, height):
            calls.append((window_id, x, y, width, height))

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()

    result = plugin.run_commands({
        "command": "move_resize_window",
        "window_id": "0xabc",
        "x": 10,
        "y": 20,
        "width": 300,
        "height": 200,
    })

    assert calls == [("0xabc", 10, 20, 300, 200)]
    assert "Moved/resized window 0xabc" in result[0]


def test_builtin_desktop_click_drag_release_delegates(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = True

        def click_drag_release(self, **kwargs):
            calls.append(kwargs)

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()

    result = plugin.run_commands({
        "command": "click_drag_release",
        "x": 10,
        "y": 20,
        "to_x": 30,
        "to_y": 40,
        "button": 1,
    })

    assert calls == [{"x": 10, "y": 20, "to_x": 30, "to_y": 40, "button": 1}]
    assert "Dragged mouse button 1 from 10,20 to 30,40" in result[0]


def test_agent_can_enable_builtin_server_tools_from_config():
    agent = Agent(
        session="new",
        voice_enabled=False,
        web_search_enabled=True,
        image_generation_enabled=True,
    )

    assert {tool.type for tool in agent.tools_manager.get_server_tools()} == {"web_search", "image_generation"}


def test_codex_stream_params_forward_verbosity_prompt_cache_key_and_parallel_tool_calls():
    agent = Agent(session="new", voice_enabled=False, verbosity="low")
    tools = [{"type": "function", "name": "noop", "parameters": {"type": "object"}}]

    params = agent.ai._to_codex_stream_params({
        "messages": agent.context_manager.get_context(),
        "tools": tools,
        "verbosity": agent.config.verbosity,
        "parallel_tool_calls": True,
        "prompt_cache_key": agent.current_session_id,
    })

    assert params["verbosity"] == "low"
    assert params["parallel_tool_calls"] is True
    assert params["prompt_cache_key"] == agent.current_session_id


def test_codex_stream_params_disable_parallel_tool_calls_without_tools():
    agent = Agent(session="new", voice_enabled=False)

    params = agent.ai._to_codex_stream_params({
        "messages": agent.context_manager.get_context(),
        "tools": [],
        "parallel_tool_calls": True,
    })

    assert params["tool_choice"] == "none"
    assert params["parallel_tool_calls"] is False


def test_agent_provider_messages_are_ephemeral():
    agent = Agent(session="new", voice_enabled=False)
    initial_count = len(agent.session.messages)

    @agent.add_provider
    def context_provider():
        return "plain"

    messages = agent.context_manager.get_providers_messages()

    assert "plain" in [message.content for message in messages]
    assert all(isinstance(message, ProviderMessage) for message in messages)
    assert len(agent.session.messages) == initial_count


def test_agent_add_command_decorator_handles_slash_command():
    agent = Agent(session="new", voice_enabled=False)
    initial_count = len(agent.session.messages)

    @agent.add_command
    def echo(args):
        return f"echo:{args}:{get_agent().config.name}"

    result = agent("/echo hello")

    assert result == f"echo:hello:{agent.config.name}"
    assert len(agent.session.messages) == initial_count


def test_agent_add_hook_decorator_runs_hook_with_agent_context():
    agent = Agent(session="new", voice_enabled=False)
    seen = []

    @agent.add_hook("sample_hook")
    def sample(value):
        seen.append((value, get_agent().config.name))
        return value.upper()

    result = agent.run_hooks("sample_hook", "hello")

    assert seen == [("hello", agent.config.name)]
    assert result == ["HELLO"]


def test_agent_audio_playback_uses_hook_when_declared(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    played = []
    hooked = []
    monkeypatch.setattr("codex_agent.voice.silent_play", lambda audio: played.append(audio))

    @agent.add_hook("audio_playback_hook")
    def audio_hook(audio):
        hooked.append(audio)

    agent.emit(AudioPlaybackEvent, audio="audio")

    assert hooked == ["audio"]
    assert played == []


def test_agent_audio_playback_falls_back_to_silent_play(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    played = []
    monkeypatch.setattr("codex_agent.voice.silent_play", lambda audio: played.append(audio))

    agent.emit(AudioPlaybackEvent, audio="audio")

    assert played == ["audio"]


def test_voice_processor_disabled_is_direct_passthrough(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)

    def fail_if_called(_stream):
        raise AssertionError("disabled voice should not enter the voice pipeline")

    monkeypatch.setattr(agent.voice.mute_tag_processor, "process", fail_if_called)

    assert list(agent.voice(iter(["a", "b"]))) == ["a", "b"]


def test_voice_processor_enabled_uses_voice_stream(monkeypatch):
    agent = Agent(session="new", voice_enabled=True)
    calls = []

    def voice_stream(stream):
        calls.append(True)
        for token in stream:
            yield token.upper()

    monkeypatch.setattr(agent.voice, "voice_stream", voice_stream)

    assert list(agent.voice(iter(["a", "b"]))) == ["A", "B"]
    assert calls == [True]


def test_agent_command_can_be_registered_without_args():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_command
    def ping():
        return "pong"

    assert agent("/ping") == "pong"


def test_agent_command_maps_parsed_arguments_to_signature():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_command
    def greet(name, greeting="hello", loud=False):
        text = f"{greeting}, {name}"
        return text.upper() if loud else text

    assert agent('/greet Ada greeting=salut --loud') == "SALUT, ADA"


def test_agent_command_supports_varargs_and_kwargs():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_command
    def collect(*items, **options):
        return f"items={list(items)!r}; options={options!r}"

    assert agent('/collect one "two words" mode=fast --dry-run') == (
        "items=['one', 'two words']; options={'mode': 'fast', 'dry_run': True}"
    )


def test_agent_loads_builtin_commands():
    agent = Agent(session="new", voice_enabled=False)

    assert {"help", "compact", "config", "model", "reasoning", "verbosity", "voice"}.issubset(agent.commands)
    assert "/help" in agent("/help")
    assert "/compact" in agent("/help")


def test_builtin_model_config_commands_update_and_persist(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)

    assert agent("/model gpt-test") == "Updated config: model='gpt-test'"
    assert agent.config.model == "gpt-test"
    assert json.loads((tmp_path / "agent_config.json").read_text())["model"] == "gpt-test"

    assert agent("/reasoning low") == "Updated config: reasoning_effort='low'"
    assert agent("/verbosity high") == "Updated config: verbosity='high'"
    assert agent.config.reasoning_effort == "low"
    assert agent.config.verbosity == "high"


def test_builtin_voice_command_shows_toggles_and_selects_voice(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False, voice="nova")

    assert agent("/voice") == "voice: off; voice='nova'"
    assert agent("/voice on") == "Updated config: voice_enabled=True"
    assert agent.config.voice_enabled is True
    assert agent("/voice off") == "Updated config: voice_enabled=False"
    assert agent.config.voice_enabled is False
    assert agent("/voice shimmer") == "Updated config: voice='shimmer', voice_enabled=True"
    assert agent.config.voice == "shimmer"
    assert agent.config.voice_enabled is True

    saved = json.loads((tmp_path / "agent_config.json").read_text())
    assert saved["voice"] == "shimmer"
    assert saved["voice_enabled"] is True


def test_builtin_config_command_shows_and_updates_multiple_model_fields(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)

    display = agent("/config")
    assert "model:" in display
    assert "reasoning_effort:" in display
    assert "verbosity:" in display

    result = agent("/config model=gpt-next input_token_limit=64000 auto_compact=false")

    assert "model='gpt-next'" in result
    assert "input_token_limit=64000" in result
    assert "auto_compact=False" in result
    assert agent.config.model == "gpt-next"
    assert agent.config.input_token_limit == 64000
    assert agent.config.auto_compact is False


def test_builtin_config_command_rejects_unknown_keys():
    agent = Agent(session="new", voice_enabled=False)

    try:
        agent("/config temperature=1")
    except ValueError as exc:
        assert "Unknown model config keys: temperature" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown config key")

    try:
        agent("/config auto_archive_memory=true")
    except ValueError as exc:
        assert "Unknown model config keys: auto_archive_memory" in str(exc)
    else:
        raise AssertionError("Expected ValueError for plugin-owned config key")


def test_builtin_session_commands_list_create_load_delete_and_navigate(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    first = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="first")])
    second = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="second")])
    first.save()
    second.save()

    agent = Agent(session="latest", voice_enabled=False)

    listing = agent("/sessions")
    assert "* 20260102_100000" in listing
    assert "  20260101_100000" in listing

    assert agent("/previous_session") == "Loaded session: 20260101_100000"
    assert agent.current_session_id == "20260101_100000"
    assert agent("/next_session") == "Loaded session: 20260102_100000"

    assert agent("/load_session 20260101_100000") == "Loaded session: 20260101_100000"
    assert agent.current_session_id == "20260101_100000"

    created = agent("/new_session")
    assert created.startswith("Created session: ")
    assert " " not in agent.current_session_id

    assert agent("/delete_session 20260101_100000") == "Deleted session: 20260101_100000"
    assert "20260101_100000" not in agent.get_sessions()


def test_agent_loads_runtime_commands(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    commands_folder = tmp_path / "commands"
    commands_folder.mkdir()
    (commands_folder / "hello.py").write_text(
        "from codex_agent import command\n"
        "from codex_agent import get_agent\n\n"
        "@command(name='hello')\n"
        "def hello(args):\n"
        "    return get_agent().config.name + ':' + args\n",
        encoding="utf-8",
    )

    agent = Agent(session="new", voice_enabled=False, name="Ada")

    assert agent("/hello world") == "Ada:world"


def test_unknown_command_raises_value_error():
    agent = Agent(session="new", voice_enabled=False)

    try:
        agent("/missing")
    except ValueError as exc:
        assert "Unknown command: /missing" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown command")


def test_provider_message_wraps_content_for_api():
    message = ProviderMessage(name="clock", content="It is noon.")

    assert message.to_response_format() == {
        "type": "message",
        "role": "developer",
        "content": [{
            "type": "input_text",
            "text": '<context_provider name="clock">\nIt is noon.\n</context_provider>',
        }],
    }


def test_provider_must_return_supported_context_items():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_provider
    def bad_provider():
        return {"not": "allowed"}

    try:
        agent.context_manager.get_providers_messages()
    except TypeError as exc:
        assert "items must be str or Message" in str(exc)
    else:
        raise AssertionError("Expected provider contract TypeError")


def test_agent_loads_builtin_date_and_time_provider():
    agent = Agent(session="new", voice_enabled=False)

    assert "date_and_time" in agent.providers
    assert any(
        message.content.startswith("Current date and time:")
        for message in agent.context_manager.get_providers_messages()
    )


def test_agent_loads_builtin_cwd_provider():
    agent = Agent(session="new", voice_enabled=False)

    assert "cwd" in agent.providers
    assert any(
        message.content.startswith("Current working directory:")
        for message in agent.context_manager.get_providers_messages()
    )


def test_agent_config_exposes_stable_system_prompt_infos():
    agent = Agent(session="new", voice_enabled=False)

    assert agent.config.runtime_dir
    assert agent.config.source_dir.endswith("codex-agent")
    assert "Python" in agent.config.platform


def test_plugin_system_prompt_sections_are_added_to_system_message():
    agent = Agent(session="new", voice_enabled=False, system="Base prompt.")

    assert agent.config_manager.system_message().content.startswith("Base prompt.")
    assert "# Long-Term Memory" in agent.config_manager.system_message().content
    assert "memory_add" in agent.config_manager.system_message().content
    assert "# Planner" in agent.config_manager.system_message().content
    assert "planner tools" in agent.config_manager.system_message().content
    assert "# Browser" in agent.config_manager.system_message().content
    assert "browser_state provider" in agent.config_manager.system_message().content
    assert "# Desktop" in agent.config_manager.system_message().content
    assert "Call desktop_start_session before any desktop action" in agent.config_manager.system_message().content
    assert "desktop_state provider" in agent.config_manager.system_message().content
    assert "Call desktop_run_commands only after desktop_state confirms the live session is active" in agent.config_manager.system_message().content
    assert "# Scheduler" in agent.config_manager.system_message().content
    assert "scheduler_restart_and_wakeup" in agent.config_manager.system_message().content


def test_agent_config_helpers_persist_in_runtime_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    agent = Agent(session="new", voice_enabled=False)
    agent.config_manager.update(name="Ada", model="gpt-test")

    config_file = tmp_path / "agent_config.json"
    assert config_file.is_file()
    assert json.loads(config_file.read_text())["name"] == "Ada"

    loaded = Agent(session="new", voice_enabled=False)
    assert loaded.config.name == "Ada"
    assert loaded.config.model == "gpt-test"

    loaded.config_manager.update({"name": "Pandora"}, save=False)
    assert json.loads(config_file.read_text())["name"] == "Ada"

    loaded.config_manager.save()
    assert json.loads(config_file.read_text())["name"] == "Pandora"


def test_restart_server_calls_server_endpoint(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    calls = []
    monkeypatch.setattr(agent.runtime, "call_server_endpoint", lambda method, path, payload=None: calls.append((method, path, payload)) or {"restarting": True})
    result = agent.runtime.restart_server(prompt="resume", title="after update")
    assert result["restarting"] is True
    assert calls == [("POST", "/restart", {"prompt": "resume", "title": "after update"})]


def test_restart_server_and_wakeup_stops_agentic_loop(monkeypatch):
    agent = Agent(session="new", voice_enabled=False)
    monkeypatch.setattr(agent.runtime, "restart_server", lambda prompt=None, title="": {"restarting": True, "wakeup_persisted": True})

    result = agent.plugins.scheduler.restart_server_and_wakeup(prompt="resume", title="after update")

    assert agent.mainloop_manager.stop_agentic_loop is True
    assert "Server restart requested" in result


def test_provider_can_return_multiple_separate_messages_without_flattening():
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_provider(name="multi")
    def multi_provider():
        return [
            "plain text",
            DeveloperMessage(content="developer text"),
            DeveloperMessage(content=["first", {"type": "text", "text": "second"}, {"type": "input_image", "image_url": "data:image/png;base64,abc"}]),
        ]

    messages = agent.context_manager.get_providers_messages()
    multi_messages = [message for message in messages if getattr(message, "name", "") == "multi" or "multi" in str(message.get("content"))]

    assert len(multi_messages) == 3
    assert isinstance(multi_messages[0], ProviderMessage)
    assert multi_messages[0].content == "plain text"
    assert isinstance(multi_messages[1], DeveloperMessage)
    assert type(multi_messages[1]) is DeveloperMessage
    assert multi_messages[1].content == '<context_provider name="multi">\ndeveloper text\n</context_provider>'
    assert isinstance(multi_messages[2], DeveloperMessage)
    assert multi_messages[2].content[0] == '<context_provider name="multi">\nfirst\n</context_provider>'
    assert multi_messages[2].content[1]["text"] == '<context_provider name="multi">\nsecond\n</context_provider>'
    assert multi_messages[2].content[2] == {"type": "input_image", "image_url": "data:image/png;base64,abc"}


def test_provider_image_message_keeps_image_message_type_and_wraps_description(tmp_path):
    from PIL import Image

    image_path = tmp_path / "provider.png"
    Image.new("RGB", (1, 1), color="red").save(image_path)
    original = ImageMessage(content=str(image_path), description="active tab screenshot")
    agent = Agent(session="new", voice_enabled=False)

    @agent.add_provider(name="browser_state")
    def image_provider():
        return original

    messages = agent.context_manager.get_providers_messages()
    image_messages = [message for message in messages if isinstance(message, ImageMessage)]

    assert len(image_messages) == 1
    provided = image_messages[0]
    assert provided is not original
    assert provided.content == str(image_path)
    assert provided.description == '<context_provider name="browser_state">\nactive tab screenshot\n</context_provider>'
    assert provided.is_valid()
