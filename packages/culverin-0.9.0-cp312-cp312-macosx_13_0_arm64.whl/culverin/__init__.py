import os
import sys
from pathlib import Path
from typing import TypedDict
import shutil


def setup_runtime_dlls():
    if sys.platform != "win32":
        return

    # Priority 1: Explicitly defined runtime directory
    # Good for dev environments where you want to point to a specific build
    env_runtime = os.environ.get("CULVERIN_ASAN_LIB_PATH")
    if env_runtime and Path(env_runtime).exists():
        os.add_dll_directory(env_runtime)
        return

    # Priority 2: Derived from LLVM_INSTALL_DIR
    llvm_root = os.environ.get("LLVM_INSTALL_DIR")

    # Priority 3: Auto-discovery via PATH (find clang, then infer lib path)
    if not llvm_root:
        clang_bin = shutil.which("clang")
        if clang_bin:
            llvm_root = Path(clang_bin).parent.parent

    if llvm_root:
        llvm_root = Path(llvm_root)
        # Check both modern and legacy LLVM layout structures
        potential_paths = [
            llvm_root / "lib" / "clang" / "23" / "lib" / "x86_64-pc-windows-msvc",
            llvm_root / "lib" / "windows",
        ]

        for p in potential_paths:
            if p.exists():
                os.add_dll_directory(str(p))
                return


setup_runtime_dlls()

from . import _culverin_c

__version__ = _culverin_c.__version__


# 1. Load Pure Python Configs
from ._culverin import (
    Automatic,
    Engine,
    Manual,
    Transmission,
    euler_to_quat,
    load_urdf,
    parse_urdf,
)


class WheelConfig(TypedDict):
    pos: tuple[float, float, float]
    radius: float


class TrackConfig(TypedDict):
    indices: list[int]
    driven_wheel: int


# 2. DEFINE HELPER FUNCTIONS
# We type-hint 'self' as the C class.
# We use a string "_culverin_c.PhysicsWorld" to avoid runtime issues.
def get_position(self: _culverin_c.PhysicsWorld, handle: int) -> tuple[float, float, float] | None:
    """Returns the world position of a body as (x, y, z), or None if the handle is invalid."""
    stats = self.get_body_stats(handle)
    # If stats is None, this returns None naturally
    return stats[0] if stats else None


def get_rotation(
    self: _culverin_c.PhysicsWorld, handle: int
) -> tuple[float, float, float, float] | None:
    """Returns the world rotation of a body as (x, y, z, w), or None if the handle is invalid."""
    stats = self.get_body_stats(handle)
    return stats[1] if stats else None


def get_velocity(self: _culverin_c.PhysicsWorld, handle: int) -> tuple[float, float, float] | None:
    """Returns the world velocity of a body as (x, y, z), or None if the handle is invalid."""
    stats = self.get_body_stats(handle)
    return stats[2] if stats else None


def world_repr(self: _culverin_c.PhysicsWorld) -> str:
    return f"<culverin.PhysicsWorld bodies={self.count} time={self.time:.2f}>"


# 3. ATTACH HELPERS
# We use 'type: ignore' here because linters often think C-extension
# classes are immutable/read-only even when MANAGED_DICT is enabled.
_culverin_c.PhysicsWorld.get_position = get_position  # type: ignore
_culverin_c.PhysicsWorld.get_rotation = get_rotation  # type: ignore
_culverin_c.PhysicsWorld.get_velocity = get_velocity  # type: ignore
_culverin_c.PhysicsWorld.__repr__ = world_repr  # type: ignore


# 4. EXPOSE THE C CLASS
PhysicsWorld = _culverin_c.PhysicsWorld

# 5. Export Constants and other classes
from ._culverin_c import (  # noqa: E402
    BEND_DIHEDRAL,
    BEND_DISTANCE,
    BEND_NONE,
    CONSTRAINT_CONE,
    CONSTRAINT_DISTANCE,
    CONSTRAINT_FIXED,
    CONSTRAINT_HINGE,
    CONSTRAINT_POINT,
    CONSTRAINT_SLIDER,
    EVENT_ADDED,
    EVENT_PERSISTED,
    EVENT_REMOVED,
    MOTION_DYNAMIC,
    MOTION_KINEMATIC,
    MOTION_STATIC,
    SHAPE_BOX,
    SHAPE_CAPSULE,
    SHAPE_CONVEX_HULL,
    SHAPE_CYLINDER,
    SHAPE_HEIGHTFIELD,
    SHAPE_MESH,
    SHAPE_PLANE,
    SHAPE_SPHERE,
    USE_DOUBLE_PRECISION,
    Character,
    Ragdoll,
    RagdollSettings,
    Skeleton,
    SoftBodySharedSettings,
    Vehicle,
    Registry,
    _dump_schema_json,  # type: ignore
    mutate_tuple,
)

__all__ = [
    "BEND_DIHEDRAL",
    "BEND_DISTANCE",
    "BEND_NONE",
    "CONSTRAINT_CONE",
    "CONSTRAINT_DISTANCE",
    "CONSTRAINT_FIXED",
    "CONSTRAINT_HINGE",
    "CONSTRAINT_POINT",
    "CONSTRAINT_SLIDER",
    "EVENT_ADDED",
    "EVENT_PERSISTED",
    "EVENT_REMOVED",
    "MOTION_DYNAMIC",
    "MOTION_KINEMATIC",
    "MOTION_STATIC",
    "SHAPE_BOX",
    "SHAPE_CAPSULE",
    "SHAPE_CONVEX_HULL",
    "SHAPE_CYLINDER",
    "SHAPE_HEIGHTFIELD",
    "SHAPE_MESH",
    "SHAPE_PLANE",
    "SHAPE_SPHERE",
    "USE_DOUBLE_PRECISION",
    "Automatic",
    "Character",
    "Engine",
    "Manual",
    "PhysicsWorld",
    "Ragdoll",
    "RagdollSettings",
    "Skeleton",
    "SoftBodySharedSettings",
    "TrackConfig",
    "Transmission",
    "Vehicle",
    "Registry",
    "WheelConfig",
    "euler_to_quat",
    "load_urdf",
    "_dump_schema_json",
    "mutate_tuple",
    "parse_urdf",
]
