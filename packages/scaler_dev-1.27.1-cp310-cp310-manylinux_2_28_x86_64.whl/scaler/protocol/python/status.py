from typing import Any, Dict, List, Optional

from scaler.protocol.capnp._python import _status  # noqa
from scaler.protocol.python.common import TaskState
from scaler.protocol.python.mixins import Message
from scaler.utility.identifiers import ClientID, WorkerID

CPU_MAXIMUM = 1000


class Resource(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def cpu(self) -> int:
        return self._msg.cpu

    @property
    def rss(self) -> int:
        return self._msg.rss

    @staticmethod
    def new_msg(cpu: int, rss: int) -> "Resource":  # type: ignore[override]
        return Resource(_status.Resource(cpu=min(cpu, CPU_MAXIMUM), rss=rss))

    def get_message(self):
        return self._msg


class ObjectManagerStatus(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def number_of_objects(self) -> int:
        return self._msg.numberOfObjects

    @staticmethod
    def new_msg(number_of_objects: int) -> "ObjectManagerStatus":  # type: ignore[override]
        return ObjectManagerStatus(_status.ObjectManagerStatus(numberOfObjects=number_of_objects))

    def get_message(self):
        return self._msg


class ClientManagerStatus(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def client_to_num_of_tasks(self) -> Dict[ClientID, int]:
        return {ClientID(p.client): p.numTask for p in self._msg.clientToNumOfTask}

    @staticmethod
    def new_msg(client_to_num_of_tasks: Dict[ClientID, int]) -> "ClientManagerStatus":  # type: ignore[override]
        return ClientManagerStatus(
            _status.ClientManagerStatus(
                clientToNumOfTask=[
                    _status.ClientManagerStatus.Pair(client=bytes(client_id), numTask=num_tasks)
                    for client_id, num_tasks in client_to_num_of_tasks.items()
                ]
            )
        )

    def get_message(self):
        return self._msg


class TaskManagerStatus(Message):
    VALUE_SIZE_LIMIT = 2**32

    def __init__(self, msg):
        super().__init__(msg)

    @property
    def state_to_count(self) -> Dict[TaskState, int]:
        return {TaskState(p.state): p.count for p in self._msg.stateToCount}

    @staticmethod
    def new_msg(state_to_count: Dict[TaskState, int]) -> "TaskManagerStatus":  # type: ignore[override]
        return TaskManagerStatus(
            _status.TaskManagerStatus(
                stateToCount=[
                    _status.TaskManagerStatus.Pair(state=p[0].value, count=p[1] % TaskManagerStatus.VALUE_SIZE_LIMIT)
                    for p in state_to_count.items()
                ]
            )
        )

    def get_message(self):
        return self._msg


class ProcessorStatus(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def pid(self) -> int:
        return self._msg.pid

    @property
    def initialized(self) -> int:
        return self._msg.initialized

    @property
    def has_task(self) -> bool:
        return self._msg.hasTask

    @property
    def suspended(self) -> bool:
        return self._msg.suspended

    @property
    def resource(self) -> Resource:
        return Resource(self._msg.resource)

    @staticmethod
    def new_msg(
        pid: int, initialized: int, has_task: bool, suspended: bool, resource: Resource  # type: ignore[override]
    ) -> "ProcessorStatus":
        return ProcessorStatus(
            _status.ProcessorStatus(
                pid=pid, initialized=initialized, hasTask=has_task, suspended=suspended, resource=resource.get_message()
            )
        )

    def get_message(self):
        return self._msg


class WorkerStatus(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def worker_id(self) -> WorkerID:
        return WorkerID(self._msg.workerId)

    @property
    def agent(self) -> Resource:
        return Resource(self._msg.agent)

    @property
    def rss_free(self) -> int:
        return self._msg.rssFree

    @property
    def free(self) -> int:
        return self._msg.free

    @property
    def sent(self) -> int:
        return self._msg.sent

    @property
    def queued(self) -> int:
        return self._msg.queued

    @property
    def suspended(self) -> bool:
        return self._msg.suspended

    @property
    def lag_us(self) -> int:
        return self._msg.lagUS

    @property
    def last_s(self) -> int:
        return self._msg.lastS

    @property
    def itl(self) -> str:
        return self._msg.itl

    @property
    def processor_statuses(self) -> List[ProcessorStatus]:
        return [ProcessorStatus(ps) for ps in self._msg.processorStatuses]

    @staticmethod
    def new_msg(  # type: ignore[override]
        worker_id: WorkerID,
        agent: Resource,
        rss_free: int,
        free: int,
        sent: int,
        queued: int,
        suspended: int,
        lag_us: int,
        last_s: int,
        itl: str,
        processor_statuses: List[ProcessorStatus],
    ) -> "WorkerStatus":
        return WorkerStatus(
            _status.WorkerStatus(
                workerId=bytes(worker_id),
                agent=agent.get_message(),
                rssFree=rss_free,
                free=free,
                sent=sent,
                queued=queued,
                suspended=suspended,
                lagUS=lag_us,
                lastS=last_s,
                itl=itl,
                processorStatuses=[ps.get_message() for ps in processor_statuses],
            )
        )

    def get_message(self):
        return self._msg


class WorkerManagerStatus(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def workers(self) -> List[WorkerStatus]:
        return [WorkerStatus(ws) for ws in self._msg.workers]

    @staticmethod
    def new_msg(workers: List[WorkerStatus]) -> "WorkerManagerStatus":  # type: ignore[override]
        return WorkerManagerStatus(_status.WorkerManagerStatus(workers=[ws.get_message() for ws in workers]))

    def get_message(self):
        return self._msg


class ScalingManagerStatus(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def managed_workers(self) -> Dict[bytes, List[WorkerID]]:
        return {pair.workerManagerID: [WorkerID(wid) for wid in pair.workerIDs] for pair in self._msg.managedWorkers}

    @property
    def worker_manager_details(self) -> List[Dict[str, Any]]:
        return [
            {
                "worker_manager_id": d.workerManagerID,
                "identity": d.identity,
                "last_seen_s": d.lastSeenS,
                "max_task_concurrency": d.maxTaskConcurrency,
                "capabilities": d.capabilities,
            }
            for d in self._msg.workerManagerDetails
        ]

    @staticmethod
    def new_msg(
        managed_workers: Dict[bytes, List[WorkerID]], worker_manager_details: Optional[List[Dict[str, Any]]] = None
    ) -> "ScalingManagerStatus":  # type: ignore[override]
        details = worker_manager_details or []
        return ScalingManagerStatus(
            _status.ScalingManagerStatus(
                managedWorkers=[
                    _status.ScalingManagerStatus.Pair(
                        workerManagerID=worker_manager_id, workerIDs=[bytes(worker_id) for worker_id in worker_ids]
                    )
                    for worker_manager_id, worker_ids in managed_workers.items()
                ],
                workerManagerDetails=[
                    _status.ScalingManagerStatus.WorkerManagerDetail(
                        workerManagerID=d["worker_manager_id"],
                        identity=d["identity"],
                        lastSeenS=d["last_seen_s"],
                        maxTaskConcurrency=d["max_task_concurrency"],
                        capabilities=d.get("capabilities", ""),
                    )
                    for d in details
                ],
            )
        )

    def get_message(self):
        return self._msg


class BinderStatus(Message):
    def __init__(self, msg):
        super().__init__(msg)

    @property
    def received(self) -> Dict[str, int]:
        return {p.client: p.number for p in self._msg.received}

    @property
    def sent(self) -> Dict[str, int]:
        return {p.client: p.number for p in self._msg.sent}

    @staticmethod
    def new_msg(received: Dict[str, int], sent: Dict[str, int]) -> "BinderStatus":  # type: ignore[override]
        return BinderStatus(
            _status.BinderStatus(
                received=[_status.BinderStatus.Pair(client=p[0], number=p[1]) for p in received.items()],
                sent=[_status.BinderStatus.Pair(client=p[0], number=p[1]) for p in sent.items()],
            )
        )

    def get_message(self):
        return self._msg
