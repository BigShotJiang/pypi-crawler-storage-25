"""Memory / retrieval-log / git-log collectors for the daily digest."""
from __future__ import annotations

import re
import sqlite3
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_KIND_PREFIXES = ("feedback_", "project_", "reference_", "user_")


def _parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---"):
        return {}
    end = text.find("---", 3)
    if end == -1:
        return {}
    fm: dict[str, str] = {}
    for line in text[3:end].splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            fm[k.strip()] = v.strip()
    return fm


def _kind_from_archive(archive_db: Path, filename: str) -> str | None:
    """Look up entries.kind for a memory by filename. Returns None on any error
    so the caller can fall through to prefix inference."""
    if not archive_db.exists():
        return None
    try:
        conn = sqlite3.connect(archive_db)
        try:
            row = conn.execute(
                "SELECT kind FROM entries WHERE source = ? LIMIT 1",
                (f"md:{filename}",),
            ).fetchone()
        finally:
            conn.close()
    except sqlite3.Error:
        return None
    return row[0] if row else None


def _kind_from_slug_prefix(slug: str) -> str | None:
    """Infer kind from the md slug when it follows the canonical
    feedback_/project_/reference_/user_ convention."""
    for prefix in _KIND_PREFIXES:
        if slug.startswith(prefix):
            return prefix[:-1]
    return None


def _resolve_kind(
    fm: dict[str, str], filename: str, slug: str, archive_db: Path,
) -> str:
    """Resolution chain: YAML frontmatter → archive DB → slug prefix → unknown."""
    fm_kind = fm.get("type") or fm.get("kind")
    if fm_kind:
        return fm_kind
    archive_kind = _kind_from_archive(archive_db, filename)
    if archive_kind:
        return archive_kind
    prefix_kind = _kind_from_slug_prefix(slug)
    if prefix_kind:
        return prefix_kind
    return "unknown"


def _scan_md_dir(base: Path, scope: str, cutoff_ts: float) -> list[dict[str, Any]]:
    if not base.exists():
        return []
    archive_db = base / "archive.db"
    out: list[dict[str, Any]] = []
    for p in sorted(base.glob("*.md")):
        if p.name == "MEMORY.md":
            continue
        st = p.stat()
        if st.st_mtime < cutoff_ts:
            continue
        fm = _parse_frontmatter(p.read_text(errors="replace"))
        out.append({
            "scope": scope,
            "slug": p.stem,
            "kind": _resolve_kind(fm, filename=p.name, slug=p.stem, archive_db=archive_db),
            "name": fm.get("name", p.stem),
            "description": fm.get("description", ""),
            "path": str(p),
            "mtime": st.st_mtime,
        })
    return out


def collect_new_memories(
    *,
    global_dir: str,
    projects_dir: str,
    cutoff_ts: float,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    results.extend(_scan_md_dir(Path(global_dir), "global", cutoff_ts))
    projects_root = Path(projects_dir)
    if projects_root.is_dir():
        for entry in sorted(projects_root.iterdir()):
            if entry.is_dir():
                results.extend(_scan_md_dir(entry, entry.name, cutoff_ts))
    return results


_KV_FIELD = re.compile(r"(\w+)=(\S+)")


def _parse_log_line(raw: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for key, val in _KV_FIELD.findall(raw):
        if val.startswith('"') and val.endswith('"'):
            val = (
                val[1:-1]
                .replace('\\"', '"')
                .replace("\\t", "\t")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\\\", "\\")
            )
        fields[key] = val
    return fields


def collect_retrievals(*, log_path: str, cutoff_iso: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    p = Path(log_path)
    if not p.exists():
        return counts
    for raw in p.read_text(errors="replace").splitlines():
        fields = _parse_log_line(raw)
        if fields.get("event") != "memory.injected":
            continue
        ts = fields.get("ts", "")
        if not ts or ts < cutoff_iso:
            continue
        sources = fields.get("sources", "")
        for src in sources.split(","):
            src = src.strip()
            if src:
                counts[src] = counts.get(src, 0) + 1
    return counts


@dataclass
class GitCommit:
    repo: str
    sha: str
    subject: str
    body: str
    author: str
    committed_at: str
    stat_files: int
    stat_insertions: int
    stat_deletions: int
    diff_snippet: str


def _git(
    repo_path: str, *args: str, timeout: int = 30,
) -> subprocess.CompletedProcess[str]:
    """Run git; on TimeoutExpired return a synthetic completed process with
    returncode=124 so callers see a failure rather than crashing the digest."""
    try:
        return subprocess.run(
            ["git", *args],
            cwd=repo_path, capture_output=True, text=True,
            timeout=timeout, check=False,
        )
    except subprocess.TimeoutExpired as e:
        return subprocess.CompletedProcess(
            args=e.cmd, returncode=124, stdout="",
            stderr=f"timed out after {timeout}s",
        )


def _is_git_repo(path: str) -> bool:
    if not Path(path).is_dir():
        return False
    out = _git(path, "rev-parse", "--git-dir")
    return out.returncode == 0


def _primary_branch(repo_path: str) -> str:
    """Resolve the primary branch.

    origin/HEAD → main → master → current HEAD. Using HEAD directly is unsafe
    because users often check out feature branches in the primary worktree.
    """
    origin = _git(repo_path, "symbolic-ref", "--short", "refs/remotes/origin/HEAD")
    if origin.returncode == 0:
        ref = origin.stdout.strip()
        branch = ref.split("/", 1)[1] if "/" in ref else ref
        if branch:
            return branch
    for candidate in ("main", "master"):
        if _git(
            repo_path, "show-ref", "--verify", "--quiet",
            f"refs/heads/{candidate}",
        ).returncode == 0:
            return candidate
    return _git(repo_path, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip() or "HEAD"


def _fetch_origin(repo_path: str) -> None:
    """Refresh `origin/*` refs. Non-fatal on network/auth/timeout errors.

    We scan `origin/<primary>` rather than the local primary so a stale clone
    still reports accurately; fetching keeps those refs current. A longer
    timeout (120s) accommodates large Klaviyo-scale repos where the
    first-fetch-of-the-day can take ~1 minute on cold VPN connections.
    """
    _git(repo_path, "fetch", "--quiet", "--no-tags", "origin", timeout=120)


def _log_ref(repo_path: str, branch: str) -> str:
    """Prefer `origin/<branch>` (authoritative for what landed remotely)
    and fall back to the local branch when no remote tracking ref exists."""
    origin_ref = f"origin/{branch}"
    exists = _git(
        repo_path, "show-ref", "--verify", "--quiet",
        f"refs/remotes/{origin_ref}",
    )
    return origin_ref if exists.returncode == 0 else branch


def _commit_stats(repo_path: str, sha: str) -> tuple[int, int, int, str]:
    show = _git(repo_path, "show", "--stat", "--format=", sha)
    files = insertions = deletions = 0
    if show.returncode == 0:
        lines_out = show.stdout.rstrip().splitlines()
        last = lines_out[-1] if lines_out else ""
        m = re.search(
            r"(\d+)\s+files?\s+changed"
            r"(?:,\s+(\d+)\s+insertions?\(\+\))?"
            r"(?:,\s+(\d+)\s+deletions?\(-\))?",
            last,
        )
        if m:
            files = int(m.group(1))
            insertions = int(m.group(2) or 0)
            deletions = int(m.group(3) or 0)
    diff = _git(repo_path, "show", "--format=", "--no-color", sha)
    snippet = diff.stdout[:2048] if diff.returncode == 0 else ""
    return files, insertions, deletions, snippet


def collect_git_activity(
    *, repo_path: str, repo_name: str, since_iso: str,
) -> list[GitCommit]:
    if not _is_git_repo(repo_path):
        return []
    _fetch_origin(repo_path)
    fmt = "%H%x1f%s%x1f%b%x1f%an%x1f%cI"
    branch = _primary_branch(repo_path)
    log = _git(
        repo_path, "log", _log_ref(repo_path, branch),
        f"--since={since_iso}",
        f"--pretty=format:{fmt}%x1e",
    )
    if log.returncode != 0 or not log.stdout:
        return []
    commits: list[GitCommit] = []
    for record in log.stdout.split("\x1e"):
        record = record.strip("\n")
        if not record:
            continue
        fields = record.split("\x1f", maxsplit=4)
        if len(fields) < 5:
            continue
        sha, subject, body, author, committed_at = fields[:5]
        stat_files, ins, dels, snippet = _commit_stats(repo_path, sha)
        commits.append(GitCommit(
            repo=repo_name, sha=sha, subject=subject, body=body,
            author=author, committed_at=committed_at,
            stat_files=stat_files, stat_insertions=ins, stat_deletions=dels,
            diff_snippet=snippet,
        ))
    return commits
