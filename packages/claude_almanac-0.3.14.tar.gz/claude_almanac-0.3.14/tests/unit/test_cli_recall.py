from unittest.mock import MagicMock

import pytest

from claude_almanac.cli import recall as cli_recall


def test_search_calls_archive(monkeypatch, capsys, tmp_path):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    fake_embedder = MagicMock()
    fake_embedder.embed.return_value = [[0.0, 1.0]]
    fake_embedder.name = "ollama"
    fake_embedder.dim = 2
    fake_embedder.distance = "l2"
    monkeypatch.setattr(
        "claude_almanac.cli.recall.make_embedder", lambda *a, **kw: fake_embedder
    )
    from claude_almanac.core.archive import Hit
    monkeypatch.setattr(
        "claude_almanac.cli.recall.archive.init", lambda *a, **kw: None
    )
    monkeypatch.setattr(
        "claude_almanac.cli.recall.archive.search",
        lambda db, **kw: [
            Hit(id=1, text="a match", kind="project", source="md:x.md",
                pinned=True, created_at=0, distance=14.0)
        ],
    )
    cli_recall.run(["search", "query"])
    out = capsys.readouterr().out
    assert "a match" in out
    assert "md:x.md" in out


def test_list_scans_md_files(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    g = tmp_path / "global"
    g.mkdir(parents=True)
    (g / "user_test.md").write_text("---\nname: test\n---\nbody")
    cli_recall.run(["list"])
    assert "user_test.md" in capsys.readouterr().out


def test_no_args_prints_usage(capsys):
    cli_recall.run([])
    assert "Usage" in capsys.readouterr().out


def _seed_project_db(tmp_path, slug: str, pinned: bool = False):
    """Seed the per-project archive with one entry at md:<slug>."""
    import os
    os.environ["CLAUDE_ALMANAC_DATA_DIR"] = str(tmp_path)
    from claude_almanac.core import archive, paths
    db = paths.project_memory_dir() / "archive.db"
    archive.init(db, embedder_name="ollama", model="bge-m3", dim=2, distance="l2")
    rowid = archive.insert_entry(
        db, text="t", kind="note", source=f"md:{slug}",
        pinned=pinned, embedding=[0.0, 1.0],
    )
    return db, rowid


def test_recall_pin_by_slug_sets_pinned_true(tmp_path, monkeypatch, capsys):
    db, _ = _seed_project_db(tmp_path, "project_foo.md", pinned=False)
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    cli_recall.run(["pin", "project_foo.md"])
    from claude_almanac.core import archive
    hits = archive.search(db, query_embedding=[0.0, 1.0], top_k=5)
    assert hits[0].pinned is True
    assert "pinned" in capsys.readouterr().out.lower()


def test_recall_pin_by_rowid_sets_pinned_true(tmp_path, monkeypatch, capsys):
    db, rowid = _seed_project_db(tmp_path, "project_foo.md", pinned=False)
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    cli_recall.run(["pin", str(rowid)])
    from claude_almanac.core import archive
    hits = archive.search(db, query_embedding=[0.0, 1.0], top_k=5)
    assert hits[0].pinned is True


def test_recall_unpin_by_slug_sets_pinned_false(tmp_path, monkeypatch, capsys):
    db, _ = _seed_project_db(tmp_path, "project_foo.md", pinned=True)
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    cli_recall.run(["unpin", "project_foo.md"])
    from claude_almanac.core import archive
    hits = archive.search(db, query_embedding=[0.0, 1.0], top_k=5)
    assert hits[0].pinned is False


def test_recall_pin_no_match_exits_nonzero(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    import pytest
    with pytest.raises(SystemExit) as exc:
        cli_recall.run(["pin", "ghost.md"])
    assert exc.value.code == 1


def test_recall_forget_moves_md_to_trash_and_deletes_archive_row(
    tmp_path, monkeypatch, capsys
):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    from claude_almanac.core import archive, paths
    scope = paths.project_memory_dir()
    scope.mkdir(parents=True)
    (scope / "project_drop.md").write_text("---\nname: drop\n---\nbody")
    db = scope / "archive.db"
    archive.init(db, embedder_name="ollama", model="bge-m3", dim=2, distance="l2")
    archive.insert_entry(
        db, text="drop", kind="note", source="md:project_drop.md",
        pinned=False, embedding=[0.0, 1.0],
    )
    cli_recall.run(["forget", "project_drop.md"])
    assert not (scope / "project_drop.md").exists()
    trash_entries = list((scope / "trash").glob("project_drop.md.*"))
    assert len(trash_entries) == 1
    hits = archive.search(db, query_embedding=[0.0, 1.0], top_k=5)
    assert hits == []


def test_recall_forget_ambiguous_slug_requires_scope(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    from claude_almanac.core import paths
    for scope in (paths.global_memory_dir(), paths.project_memory_dir()):
        scope.mkdir(parents=True)
        (scope / "user_x.md").write_text("body")
    import pytest
    with pytest.raises(SystemExit) as exc:
        cli_recall.run(["forget", "user_x.md"])
    assert exc.value.code == 2
    assert "--scope" in capsys.readouterr().err


def test_recall_forget_with_scope_flag_picks_one_scope(tmp_path, monkeypatch):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    from claude_almanac.core import paths
    for scope in (paths.global_memory_dir(), paths.project_memory_dir()):
        scope.mkdir(parents=True)
        (scope / "user_x.md").write_text("body")
    cli_recall.run(["forget", "user_x.md", "--scope", "global"])
    assert not (paths.global_memory_dir() / "user_x.md").exists()
    assert (paths.project_memory_dir() / "user_x.md").exists()


def test_recall_export_default_path_concatenates_global_and_project(
    tmp_path, monkeypatch, capsys
):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.chdir(tmp_path)
    from claude_almanac.core import paths
    g = paths.global_memory_dir()
    g.mkdir(parents=True)
    p = paths.project_memory_dir()
    p.mkdir(parents=True)
    (g / "user_profile.md").write_text("global body")
    (p / "project_state.md").write_text("project body")
    cli_recall.run(["export"])
    exports = list(tmp_path.glob("claude-almanac-export-*.md"))
    assert len(exports) == 1
    body = exports[0].read_text()
    assert "# global/user_profile.md" in body
    assert "global body" in body
    assert "# project/project_state.md" in body
    assert "project body" in body


def test_recall_export_custom_path_and_scope_flag(tmp_path, monkeypatch):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    from claude_almanac.core import paths
    g = paths.global_memory_dir()
    g.mkdir(parents=True)
    p = paths.project_memory_dir()
    p.mkdir(parents=True)
    (g / "user_a.md").write_text("A")
    (p / "project_b.md").write_text("B")
    out = tmp_path / "dump.md"
    cli_recall.run(["export", str(out), "--global"])
    text = out.read_text()
    assert "user_a.md" in text
    assert "project_b.md" not in text


def test_recall_export_all_scans_all_project_dirs(tmp_path, monkeypatch):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    from claude_almanac.core import paths
    g = paths.global_memory_dir()
    g.mkdir(parents=True)
    (g / "user_a.md").write_text("A")
    proj_root = paths.projects_memory_dir()
    (proj_root / "git-aaaa1111").mkdir(parents=True)
    (proj_root / "git-aaaa1111" / "project_p1.md").write_text("P1")
    (proj_root / "git-bbbb2222").mkdir(parents=True)
    (proj_root / "git-bbbb2222" / "project_p2.md").write_text("P2")
    out = tmp_path / "all.md"
    cli_recall.run(["export", str(out), "--all"])
    text = out.read_text()
    assert "project_p1.md" in text
    assert "project_p2.md" in text


def test_recall_history_prints_chain(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("CLAUDE_ALMANAC_CONFIG_DIR", str(tmp_path))
    from claude_almanac.core import archive, paths, versioning
    scope_dir = paths.project_memory_dir()
    scope_dir.mkdir(parents=True, exist_ok=True)
    db = scope_dir / "archive.db"
    archive.init(db, embedder_name="ollama", model="bge-m3", dim=2, distance="l2")
    versioning.snapshot_then_replace(
        db, scope_dir=scope_dir, slug="foo.md",
        new_text="body-1", new_kind="reference",
        new_embedding=[1.0, 0.0], provenance="write_md",
    )
    versioning.snapshot_then_replace(
        db, scope_dir=scope_dir, slug="foo.md",
        new_text="body-2", new_kind="reference",
        new_embedding=[0.9, 0.1], provenance="update_md",
    )
    cli_recall.run(["history", "foo.md"])
    out = capsys.readouterr().out
    assert "Version history for 'foo.md'" in out
    assert "body-1" in out
    assert "body-2" in out
    assert "update_md" in out


def test_recall_history_unknown_slug_exits_nonzero(tmp_path, monkeypatch):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("CLAUDE_ALMANAC_CONFIG_DIR", str(tmp_path))
    with pytest.raises(SystemExit) as exc:
        cli_recall.run(["history", "nonexistent.md"])
    assert exc.value.code != 0


def test_recall_correct_with_body_supersedes(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("CLAUDE_ALMANAC_CONFIG_DIR", str(tmp_path))
    from claude_almanac.core import archive, config, paths, versioning
    cfg = config.default_config()
    config.save(cfg)
    scope_dir = paths.project_memory_dir()
    scope_dir.mkdir(parents=True, exist_ok=True)
    db = scope_dir / "archive.db"
    archive.init(db, embedder_name="ollama", model="bge-m3", dim=2, distance="l2")
    versioning.snapshot_then_replace(
        db, scope_dir=scope_dir, slug="foo.md",
        new_text="original", new_kind="reference",
        new_embedding=[1.0, 0.0], provenance="write_md",
    )
    # Monkey-patch the embedder factory to avoid requiring Ollama
    class FakeEmbedder:
        name, model, dim, distance = "ollama", "bge-m3", 2, "l2"
        def embed(self, texts):
            return [[0.9, 0.1] for _ in texts]
    monkeypatch.setattr("claude_almanac.cli.recall.make_embedder",
                        lambda *a, **k: FakeEmbedder())
    cli_recall.run(["correct", "foo.md", "--body", "corrected"])
    chain = versioning.list_versions(db, slug="foo.md")
    assert chain[0].text == "corrected"
    assert chain[0].is_current is True
    assert chain[1].text == "original"
    assert chain[1].provenance == "correct"


def test_recall_correct_unknown_slug_exits_nonzero(tmp_path, monkeypatch):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("CLAUDE_ALMANAC_CONFIG_DIR", str(tmp_path))
    with pytest.raises(SystemExit) as exc:
        cli_recall.run(["correct", "nope.md", "--body", "x"])
    assert exc.value.code != 0


def test_recall_correct_opens_editor_when_no_body(tmp_path, monkeypatch):
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("CLAUDE_ALMANAC_CONFIG_DIR", str(tmp_path))
    from claude_almanac.core import archive, config, paths, versioning
    cfg = config.default_config()
    config.save(cfg)
    scope_dir = paths.project_memory_dir()
    scope_dir.mkdir(parents=True, exist_ok=True)
    db = scope_dir / "archive.db"
    archive.init(db, embedder_name="ollama", model="bge-m3", dim=2, distance="l2")
    versioning.snapshot_then_replace(
        db, scope_dir=scope_dir, slug="foo.md",
        new_text="original", new_kind="reference",
        new_embedding=[1.0, 0.0], provenance="write_md",
    )
    class FakeEmbedder:
        name, model, dim, distance = "ollama", "bge-m3", 2, "l2"
        def embed(self, texts):
            return [[0.9, 0.1] for _ in texts]
    monkeypatch.setattr("claude_almanac.cli.recall.make_embedder",
                        lambda *a, **k: FakeEmbedder())
    # Stub the editor invocation: return "edited-body" as the new content
    monkeypatch.setattr(
        "claude_almanac.cli.recall._open_editor_with_text",
        lambda initial: "edited-body",
    )
    cli_recall.run(["correct", "foo.md"])
    chain = versioning.list_versions(db, slug="foo.md")
    assert chain[0].text == "edited-body"


def test_recall_correct_editor_respects_multi_token_editor_var(tmp_path, monkeypatch):
    """$EDITOR with spaces (e.g., 'vim --clean') must tokenize via shlex,
    not crash trying to exec the full string as a single binary."""
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("CLAUDE_ALMANAC_CONFIG_DIR", str(tmp_path))
    monkeypatch.setenv("EDITOR", "echo --quiet")  # 'echo' exists; swallows args
    from claude_almanac.cli import recall
    from claude_almanac.core import archive, config, paths, versioning
    cfg = config.default_config()
    config.save(cfg)
    scope_dir = paths.project_memory_dir()
    scope_dir.mkdir(parents=True, exist_ok=True)
    db = scope_dir / "archive.db"
    archive.init(db, embedder_name="ollama", model="bge-m3", dim=2, distance="l2")
    versioning.snapshot_then_replace(
        db, scope_dir=scope_dir, slug="foo.md",
        new_text="original", new_kind="reference",
        new_embedding=[1.0, 0.0], provenance="write_md",
    )
    # `echo` returns 0 but doesn't modify the tempfile, so the saved body stays
    # "original" — matching current_text → the "already that body" no-change
    # branch fires. The point: subprocess.run must NOT raise FileNotFoundError.
    class FakeEmbedder:
        name, model, dim, distance = "ollama", "bge-m3", 2, "l2"
        def embed(self, texts):
            return [[1.0, 0.0] for _ in texts]
    monkeypatch.setattr("claude_almanac.cli.recall.make_embedder",
                        lambda *a, **k: FakeEmbedder())
    # SystemExit is NOT expected — `echo` exits 0, body unchanged, no-op branch returns cleanly.
    recall.run(["correct", "foo.md"])


def test_recall_correct_editor_missing_binary_exits_cleanly(tmp_path, monkeypatch):
    """$EDITOR pointing at a nonexistent binary must fail with sys.exit(1),
    not a raw FileNotFoundError traceback."""
    monkeypatch.setenv("CLAUDE_ALMANAC_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("CLAUDE_ALMANAC_CONFIG_DIR", str(tmp_path))
    monkeypatch.setenv("EDITOR", "this-editor-does-not-exist-xyz")
    from claude_almanac.cli import recall
    from claude_almanac.core import archive, config, paths, versioning
    cfg = config.default_config()
    config.save(cfg)
    scope_dir = paths.project_memory_dir()
    scope_dir.mkdir(parents=True, exist_ok=True)
    db = scope_dir / "archive.db"
    archive.init(db, embedder_name="ollama", model="bge-m3", dim=2, distance="l2")
    versioning.snapshot_then_replace(
        db, scope_dir=scope_dir, slug="foo.md",
        new_text="original", new_kind="reference",
        new_embedding=[1.0, 0.0], provenance="write_md",
    )
    class FakeEmbedder:
        name, model, dim, distance = "ollama", "bge-m3", 2, "l2"
        def embed(self, texts):
            return [[1.0, 0.0] for _ in texts]
    monkeypatch.setattr("claude_almanac.cli.recall.make_embedder",
                        lambda *a, **k: FakeEmbedder())
    with pytest.raises(SystemExit) as exc:
        recall.run(["correct", "foo.md"])
    assert exc.value.code == 1
