"""Regression tests: wrap_agent's existing behaviour must not change.

The new start_run/end_run are additive — wrap_agent should still POST
/runs/ingest in one shot for the simple in-process case, NOT decompose
into start+end (which would double the HTTP traffic).
"""
from __future__ import annotations

import pytest

from trodo.otel.wrap_agent import wrap_agent


def test_wrap_agent_uses_single_ingest_call(processor, http):
    with wrap_agent(
        processor=processor,
        team_site_id="site-x",
        agent_name="chat",
        distinct_id="user-1",
        conversation_id="conv-1",
    ) as run:
        run.set_input({"q": "hello"})
        run.set_output({"a": "world"})

    assert len(http.run_ingest) == 1, "wrap_agent must POST /runs/ingest exactly once"
    assert len(http.run_start) == 0, "wrap_agent must NOT call /runs/start"
    assert len(http.run_end) == 0, "wrap_agent must NOT call /runs/end"

    run_payload = http.run_ingest[0]["run"]
    assert run_payload["agent_name"] == "chat"
    assert run_payload["distinct_id"] == "user-1"
    assert run_payload["conversation_id"] == "conv-1"
    assert run_payload["status"] == "ok"


def test_wrap_agent_records_error_on_exception(processor, http):
    with pytest.raises(ValueError):
        with wrap_agent(
            processor=processor,
            team_site_id="site-x",
            agent_name="chat",
        ) as run:
            run.set_input("query")
            raise ValueError("kaboom")

    assert len(http.run_ingest) == 1
    run_payload = http.run_ingest[0]["run"]
    assert run_payload["status"] == "error"
    assert "kaboom" in run_payload["error_summary"]
