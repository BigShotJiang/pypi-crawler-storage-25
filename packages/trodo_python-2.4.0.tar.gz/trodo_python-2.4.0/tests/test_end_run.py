"""Tests for trodo.otel.wrap_agent.end_run module function."""
from __future__ import annotations

from trodo.otel.processor import TrodoSpan
from trodo.otel.wrap_agent import start_run, end_run


def _make_span(run_id: str, *, kind: str = "tool", status: str = "ok",
               input_tokens: int = 10, output_tokens: int = 20, cost: float = 0.001):
    return TrodoSpan(
        span_id="span-1",
        run_id=run_id,
        parent_span_id=None,
        kind=kind,
        name="step",
        status=status,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cost=cost,
    )


def test_posts_to_runs_end_endpoint(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    end_run(rid, processor=processor, output={"done": True}, status="ok")

    assert len(http.run_end) == 1
    sent_run_id, payload = http.run_end[0]
    assert sent_run_id == rid
    assert payload["status"] == "ok"
    assert "ended_at" in payload
    assert "done" in payload["output"]


def test_aggregates_pending_spans(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    # Inject two completed spans into the local buffer (bypass joined-flush
    # by directly populating; the real path goes through enqueue_span which
    # already flushes for joined runs).
    processor._pending[rid] = [
        _make_span(rid, kind="tool", input_tokens=5, output_tokens=10, cost=0.001),
        _make_span(rid, kind="llm", input_tokens=15, output_tokens=30, cost=0.002),
    ]
    end_run(rid, processor=processor)

    _, payload = http.run_end[0]
    assert payload["total_tokens_in"] == 20
    assert payload["total_tokens_out"] == 40
    assert round(payload["total_cost"], 6) == 0.003
    assert payload["span_count"] == 2
    assert payload["tool_count"] == 1
    assert payload["error_count"] == 0


def test_records_error_status(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    end_run(rid, processor=processor, status="error", error_summary="boom")
    _, payload = http.run_end[0]
    assert payload["status"] == "error"
    assert payload["error_summary"] == "boom"


def test_unmarks_joined(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    assert rid in processor._joined_runs
    end_run(rid, processor=processor)
    assert rid not in processor._joined_runs


def test_clears_pending_after_end(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    processor._pending[rid] = [_make_span(rid)]
    end_run(rid, processor=processor)
    # unmark_joined() drops the bucket.
    assert processor._pending.get(rid, []) == []


def test_tolerates_http_failure(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    http.fail_next = True
    end_run(rid, processor=processor)
    # No exception; but the POST didn't record.
    assert len(http.run_end) == 0


def test_metadata_in_end_payload(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    end_run(rid, processor=processor, metadata={"closed_via": "session_timeout"})
    _, payload = http.run_end[0]
    assert payload["metadata"] == {"closed_via": "session_timeout"}
