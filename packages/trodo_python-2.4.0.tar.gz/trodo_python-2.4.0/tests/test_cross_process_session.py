"""End-to-end test of the new MCP-style flow:

  1. process A calls start_run, gets back run_id, persists it (Redis in prod)
  2. process B receives a request, looks up run_id, uses join_run to add a span
  3. eventually process C (or a sweeper) calls end_run

This is the use case `start_run`/`end_run` were added to support, and is
*not* expressible with `wrap_agent` alone (it's a single-context-manager block).
"""
from __future__ import annotations

from trodo.otel.processor import TrodoSpanProcessor
from trodo.otel.wrap_agent import start_run, end_run, join_run


def test_caller_supplied_run_id_threads_through(http):
    proc_a = TrodoSpanProcessor(http_client=http)
    proc_b = TrodoSpanProcessor(http_client=http)  # different process

    # Process A: open the session run.
    rid = start_run(
        processor=proc_a,
        agent_name="external_mcp_session",
        run_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        conversation_id="mcp-sess-42",
    )
    assert rid == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

    # Process B: receive a tools/call request, look up rid from Redis (here
    # we just have it), append a tool span via join_run.
    with join_run(
        processor=proc_b,
        team_site_id="site-x",
        run_id=rid,
        name="tool.run_funnel_query",
        kind="tool",
    ) as span:
        span.set_input({"team_id": "team-1"})
        span.set_output({"status": "ok"})

    # Process C (sweeper): finalise.
    end_run(rid, processor=proc_a, output={"calls": 1}, status="ok")

    # Verify wire shape:
    assert len(http.run_start) == 1, "exactly one /runs/start"
    assert http.run_start[0]["run"]["run_id"] == rid
    assert http.run_start[0]["run"]["conversation_id"] == "mcp-sess-42"

    assert len(http.spans_append) == 1, "join_run flushes span via /runs/{id}/spans"
    sent_rid, spans = http.spans_append[0]
    assert sent_rid == rid
    assert spans[0]["name"] == "tool.run_funnel_query"
    assert spans[0]["kind"] == "tool"
    assert spans[0]["run_id"] == rid

    assert len(http.run_end) == 1, "exactly one /runs/{id}/end"
    end_rid, end_payload = http.run_end[0]
    assert end_rid == rid
    assert end_payload["status"] == "ok"
    assert "calls" in end_payload["output"]


def test_multiple_join_runs_share_run_id(http):
    proc_a = TrodoSpanProcessor(http_client=http)
    proc_b = TrodoSpanProcessor(http_client=http)

    rid = start_run(processor=proc_a, agent_name="session")

    # Three tool calls from three different worker processes.
    for i, tool in enumerate(["tool.a", "tool.b", "tool.c"]):
        with join_run(
            processor=proc_b,
            team_site_id="site-x",
            run_id=rid,
            name=tool,
            kind="tool",
        ) as span:
            span.set_attribute("call_idx", i)

    end_run(rid, processor=proc_a)

    # All three spans hit /runs/{id}/spans with the same run_id.
    assert len(http.spans_append) == 3
    for sent_rid, spans in http.spans_append:
        assert sent_rid == rid
        assert spans[0]["run_id"] == rid
