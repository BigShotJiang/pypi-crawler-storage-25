"""Direct unit tests of TrodoSpanProcessor.start_run / .end_run."""
from __future__ import annotations

from trodo.otel.processor import TrodoRun


def test_start_run_posts_to_runs_start(processor, http):
    run = TrodoRun(run_id="r1", agent_name="x", status="running")
    processor.start_run(run)
    assert len(http.run_start) == 1
    assert http.run_start[0]["run"]["run_id"] == "r1"
    assert http.run_start[0]["run"]["status"] == "running"


def test_end_run_posts_to_runs_end(processor, http):
    processor.end_run("r1", {"status": "ok", "ended_at": "2026-04-30T00:00:00Z"})
    assert len(http.run_end) == 1
    rid, payload = http.run_end[0]
    assert rid == "r1"
    assert payload["status"] == "ok"


def test_start_run_swallows_http_errors(processor, http):
    http.fail_next = True
    run = TrodoRun(run_id="r1", agent_name="x")
    # Must not raise.
    processor.start_run(run)
    assert len(http.run_start) == 0


def test_end_run_swallows_http_errors(processor, http):
    http.fail_next = True
    processor.end_run("r1", {"status": "ok"})
    assert len(http.run_end) == 0
