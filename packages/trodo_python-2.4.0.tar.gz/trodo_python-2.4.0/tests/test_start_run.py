"""Tests for trodo.otel.wrap_agent.start_run module function."""
from __future__ import annotations

import re
import uuid

from trodo.otel.wrap_agent import start_run, end_run


UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


def test_mints_run_id_when_not_supplied(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    assert UUID_RE.match(rid)
    assert len(http.run_start) == 1
    assert http.run_start[0]["run"]["run_id"] == rid


def test_accepts_caller_supplied_run_id(processor, http):
    given = "11111111-2222-3333-4444-555555555555"
    rid = start_run(processor=processor, agent_name="session", run_id=given)
    assert rid == given
    assert http.run_start[0]["run"]["run_id"] == given


def test_posts_to_runs_start_with_full_payload(processor, http):
    rid = start_run(
        processor=processor,
        agent_name="external_mcp_session",
        distinct_id="user-7",
        conversation_id="conv-abc",
        parent_run_id="parent-1",
        metadata={"mcp_client": "claude-desktop"},
        input={"hello": "world"},
    )
    assert len(http.run_start) == 1
    run = http.run_start[0]["run"]
    assert run["run_id"] == rid
    assert run["agent_name"] == "external_mcp_session"
    assert run["distinct_id"] == "user-7"
    assert run["conversation_id"] == "conv-abc"
    assert run["parent_run_id"] == "parent-1"
    assert run["status"] == "running"
    assert run["metadata"] == {"mcp_client": "claude-desktop"}
    assert "started_at" in run
    # input is JSON-stringified inside _truncate
    assert "hello" in run["input"]


def test_marks_joined_locally(processor, http):
    rid = start_run(processor=processor, agent_name="session")
    # Internal state — verify processor flips into joined mode.
    assert rid in processor._joined_runs


def test_tolerates_http_failure(processor, http):
    """start_run must not raise on backend failure — telemetry is fire-and-forget."""
    http.fail_next = True
    rid = start_run(processor=processor, agent_name="session")
    assert UUID_RE.match(rid)
    # Failed POST means nothing recorded, but no exception bubbled up.
    assert len(http.run_start) == 0
    # Local state still flipped (caller can still emit spans optimistically).
    assert rid in processor._joined_runs
