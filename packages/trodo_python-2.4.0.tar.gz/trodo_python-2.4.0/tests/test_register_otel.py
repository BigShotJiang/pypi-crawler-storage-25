"""Tests for register_otel + transport dispatch (Python parity with the TS SDK)."""
from __future__ import annotations

import pytest

from trodo.otel.register import register_otel, _reset_for_tests
from trodo.otel.transport import (
    get_transport_mode,
    get_otel_tracer,
    set_otel_transport,
    _reset_transport_for_tests,
)
from trodo.otel.processor import TrodoSpanProcessor
from trodo.otel.wrap_agent import wrap_agent


@pytest.fixture(autouse=True)
def reset_state():
    _reset_for_tests()
    yield
    _reset_for_tests()


# ---------------------------------------------------------------------------
# register_otel — argument validation + idempotency
# ---------------------------------------------------------------------------


def test_raises_when_site_id_missing(processor):
    with pytest.raises(ValueError, match="site_id"):
        register_otel(site_id="", processor=processor)


def test_raises_when_processor_missing():
    with pytest.raises(ValueError, match="processor"):
        register_otel(site_id="site_x", processor=None)  # type: ignore[arg-type]


def test_idempotency_warns_on_second_call(processor):
    first = register_otel(site_id="site_x", processor=processor, mode="trodo")
    assert first.mode == "trodo"
    assert first.fresh is True

    with pytest.warns(UserWarning, match="already called"):
        second = register_otel(site_id="site_x", processor=processor, mode="trodo")
    assert second is first


def test_unknown_mode_raises(processor):
    with pytest.raises(ValueError, match="unknown mode"):
        register_otel(site_id="site_x", processor=processor, mode="bogus")


# ---------------------------------------------------------------------------
# Mode dispatch — 'trodo' default, 'otlp' raises if peer deps missing
# ---------------------------------------------------------------------------


def test_trodo_mode_succeeds_without_otlp_peer_deps(processor):
    result = register_otel(site_id="site_x", processor=processor, mode="trodo")
    assert result.mode == "trodo"
    # active_instrumentations is best-effort; just confirm it's a list.
    assert isinstance(result.active_instrumentations, list)


def test_otlp_mode_emits_install_hint_when_peer_deps_missing(processor, monkeypatch):
    # Ensure opentelemetry imports fail to simulate a fresh install without
    # the 'otlp' extras. We do this by replacing opentelemetry.sdk.trace's
    # spec in sys.modules with None, mimicking ImportError at import time.
    import sys

    sentinel = "opentelemetry.exporter.otlp.proto.http.trace_exporter"
    monkeypatch.setitem(sys.modules, sentinel, None)

    with pytest.raises(RuntimeError, match=r"register_otel\(mode='otlp'\) requires"):
        register_otel(site_id="site_x", processor=processor, mode="otlp")


# ---------------------------------------------------------------------------
# Transport dispatch — wrap_agent in 'otlp' mode goes through the OTel tracer
# ---------------------------------------------------------------------------


class RecordedSpan:
    def __init__(self, name: str, trace_id: int, span_id: int):
        self.name = name
        self.trace_id = trace_id
        self.span_id = span_id
        self.attrs = {}
        self.ended = False
        self.exception = None
        self.status = None

    def set_attribute(self, key, value):
        self.attrs[key] = value

    def record_exception(self, e):
        self.exception = e

    def set_status(self, s):
        self.status = s

    def end(self):
        self.ended = True

    def get_span_context(self):
        class C:
            pass
        c = C()
        c.trace_id = self.trace_id
        c.span_id = self.span_id
        return c


class MockTracer:
    def __init__(self):
        self.spans: list = []
        self._next_id = 1

    def start_span(self, name):
        span = RecordedSpan(name, self._next_id, self._next_id + 1000)
        self._next_id += 1
        self.spans.append(span)
        return span


def test_wrap_agent_dispatches_to_otel_when_transport_set(processor):
    """wrap_agent in 'otlp' transport routes through tracer.start_span and
    sets Trodo attributes the backend OTLP controller understands."""
    tracer = MockTracer()

    class _NoopCM:
        def __enter__(self):
            return None

        def __exit__(self, *a):
            return None

    def fake_use_span(span, end_on_exit=False):
        return _NoopCM()

    set_otel_transport(tracer, use_span=fake_use_span)

    with wrap_agent(
        processor=processor,
        team_site_id="site-x",
        agent_name="support-bot",
        distinct_id="user-1",
        conversation_id="conv-1",
        metadata={"experimentId": "v3", "tier": "enterprise"},
    ) as run:
        run.set_input({"q": "hello"})
        run.set_output({"a": "world"})

    assert len(tracer.spans) == 1
    span = tracer.spans[0]
    assert span.name == "support-bot"
    assert span.ended is True
    assert span.attrs["trodo.agent_name"] == "support-bot"
    assert span.attrs["trodo.distinct_id"] == "user-1"
    assert span.attrs["trodo.conversation_id"] == "conv-1"
    assert span.attrs["trodo.metadata.experimentId"] == "v3"
    assert span.attrs["trodo.metadata.tier"] == "enterprise"
    assert "ai.prompt" in span.attrs
    assert "ai.response.text" in span.attrs


def test_wrap_agent_legacy_path_when_no_transport(processor, http):
    """No register_otel call → transport mode stays 'trodo' → wrap_agent
    uses TrodoSpanProcessor + HTTP API as in 2.3.x."""
    assert get_transport_mode() == "trodo"
    assert get_otel_tracer() is None

    with wrap_agent(
        processor=processor,
        team_site_id="site-x",
        agent_name="legacy-agent",
    ) as run:
        run.set_output("done")

    # Trodo HTTP API path used as in 2.3.x.
    assert len(http.run_ingest) == 1
    assert http.run_ingest[0]["run"]["agent_name"] == "legacy-agent"
