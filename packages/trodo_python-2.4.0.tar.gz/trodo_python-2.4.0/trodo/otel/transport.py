"""
Transport mode + OTel tracer registry for wrap_agent / span dispatch.

Set by register_otel() at startup. Read by wrap_agent / span to decide whether
to use the legacy TrodoSpanProcessor + Trodo HTTP API path, or to route
through an OTel tracer (so auto-instrumented children join the same OTel
trace and the backend OTLP controller groups them into one run).

Default state: 'trodo' mode + None tracer = legacy behavior, identical to
the pre-2.4.0 SDK. Existing 2.3.x users see no change.
"""
from __future__ import annotations
from typing import Any, Optional

# Transport state — module-level singletons.
_mode: str = "trodo"  # 'trodo' | 'otlp'
_tracer: Optional[Any] = None
# Optional helpers loaded once at register_otel time. Stored here so
# wrap_agent / span don't have to do `from opentelemetry import ...` inside
# the hot path (which would force opentelemetry to be installed even in tests
# that mock the tracer).
_use_span: Optional[Any] = None  # callable: (span, end_on_exit=False) -> ContextManager
_status_cls: Optional[Any] = None  # opentelemetry.trace.Status (or shim)
_status_code: Optional[Any] = None  # opentelemetry.trace.StatusCode (or shim)


def get_transport_mode() -> str:
    """Read by wrap_agent / span. Returns 'trodo' if register_otel never called."""
    return _mode


def get_otel_tracer() -> Optional[Any]:
    """Read by wrap_agent / span in 'otlp' mode. None when transport is 'trodo'."""
    return _tracer


def get_otel_helpers() -> tuple:
    """Returns (use_span, Status, StatusCode) — all callable, all may be None
    when the tracer was set without helpers (e.g. in tests)."""
    return _use_span, _status_cls, _status_code


def set_otel_transport(tracer: Any, *, use_span=None, status_cls=None, status_code=None) -> None:
    """Internal: register_otel calls this once mode='otlp' setup completes.

    Helpers are optional so tests can stub a tracer without installing the
    full opentelemetry stack.
    """
    global _mode, _tracer, _use_span, _status_cls, _status_code
    _mode = "otlp"
    _tracer = tracer
    _use_span = use_span
    _status_cls = status_cls
    _status_code = status_code


def _reset_transport_for_tests() -> None:
    """Reset for tests. Not exported from trodo/__init__.py."""
    global _mode, _tracer, _use_span, _status_cls, _status_code
    _mode = "trodo"
    _tracer = None
    _use_span = None
    _status_cls = None
    _status_code = None
