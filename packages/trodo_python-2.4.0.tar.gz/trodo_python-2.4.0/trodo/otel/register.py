"""
register_otel — one-call setup for Trodo's tracing pipeline.

Mirrors trodo-node's registerOTel. Two modes:

- 'trodo' (default) — uses the existing enable_auto_instrument bridge so spans
  from opentelemetry-instrumentation-{anthropic,openai,langchain,...} flow
  into TrodoSpanProcessor (HTTP API path). Functionally equivalent to today's
  init() with auto_instrument=True, exposed as a one-line OTel-native call.

- 'otlp' — registers an OTel TracerProvider with an OTLP/protobuf exporter
  pointed at Trodo's /v1/traces ingest. Use when you already have an OTel
  pipeline (Datadog, Jaeger, Honeycomb) or want a vanilla OTel-native setup.
  In 'otlp' mode, wrap_agent / span dispatch through the OTel tracer so
  auto-instrumented children (Anthropic, LangChain, etc.) join the same
  trace; backend OTLP controller groups them into one run.

Idempotent — second call returns the cached configuration with a warning.
"""
from __future__ import annotations
import warnings
from dataclasses import dataclass
from typing import Any, List, Optional

from .processor import TrodoSpanProcessor
from .auto_instrument import enable_auto_instrument
from .transport import set_otel_transport, _reset_transport_for_tests


@dataclass
class RegisterOtelResult:
    mode: str
    active_instrumentations: List[str]
    fresh: bool


_registered: Optional[RegisterOtelResult] = None


def register_otel(
    *,
    site_id: str,
    processor: TrodoSpanProcessor,
    mode: str = "trodo",
    endpoint: Optional[str] = None,
    service_name: str = "trodo-agent",
    disable_instrumentations: Optional[List[str]] = None,
) -> RegisterOtelResult:
    """Configure Trodo's OTel pipeline. See module doc for mode semantics."""
    global _registered
    if _registered is not None:
        warnings.warn(
            "[trodo] register_otel already called; returning existing "
            "configuration. Pass {mode} only at startup.",
            stacklevel=2,
        )
        return _registered
    if not site_id:
        raise ValueError("register_otel: site_id is required")
    if processor is None:
        raise ValueError(
            "register_otel: processor is required (typically passed "
            "automatically via init() / TrodoClient).",
        )

    endpoint = (endpoint or "https://sdkapi.trodo.ai").rstrip("/")

    if mode == "trodo":
        active = enable_auto_instrument(processor)
    elif mode == "otlp":
        active = _setup_otlp_mode(
            site_id=site_id,
            endpoint=endpoint,
            service_name=service_name,
            disable=disable_instrumentations or [],
            processor=processor,
        )
    else:
        raise ValueError(f"register_otel: unknown mode {mode!r}")

    _registered = RegisterOtelResult(
        mode=mode, active_instrumentations=active, fresh=True
    )
    return _registered


def _reset_for_tests() -> None:
    """Reset internal state — for tests only. Not exported from __init__.py."""
    global _registered
    _registered = None
    _reset_transport_for_tests()


# ---------------------------------------------------------------------------
# 'otlp' mode setup
# ---------------------------------------------------------------------------


def _setup_otlp_mode(
    *,
    site_id: str,
    endpoint: str,
    service_name: str,
    disable: List[str],
    processor: TrodoSpanProcessor,
) -> List[str]:
    """Lazy-import OTel SDK + protobuf exporter; emit friendly install hint
    if not installed (only users who pick 'otlp' mode need them)."""
    try:
        from opentelemetry import trace as otel_trace
        from opentelemetry.trace import Status, StatusCode, use_span
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter,
        )
    except ImportError as e:
        raise RuntimeError(
            "register_otel(mode='otlp') requires the OTel SDK + protobuf "
            "exporter. Install with:\n\n"
            "  pip install 'trodo-python[otlp]'\n\n"
            "or directly:\n\n"
            "  pip install opentelemetry-sdk "
            "opentelemetry-exporter-otlp-proto-http\n\n"
            f"Original error: {e}",
        ) from e

    exporter = OTLPSpanExporter(
        endpoint=f"{endpoint}/v1/traces",
        headers={"Authorization": f"Bearer {site_id}"},
    )
    batch_processor = BatchSpanProcessor(exporter)

    # Coexistence: if a non-default TracerProvider is already registered,
    # attach our exporter to it instead of replacing it.
    existing = otel_trace.get_tracer_provider()
    existing_class = type(existing).__name__
    if existing_class not in ("ProxyTracerProvider", "NoOpTracerProvider"):
        # User's pipeline owns the provider — just attach our processor.
        if hasattr(existing, "add_span_processor"):
            existing.add_span_processor(batch_processor)
        # Auto-instrumentations are presumably already wired by the existing
        # pipeline. We still set the transport so wrap_agent dispatches.
        set_otel_transport(
            otel_trace.get_tracer("trodo-agent"),
            use_span=use_span,
            status_cls=Status,
            status_code=StatusCode,
        )
        return _build_instrumentations(disable)

    # Fresh pipeline.
    resource = Resource.create({
        "service.name": service_name,
        "trodo.sdk.mode": "otlp",
    })
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(batch_processor)
    otel_trace.set_tracer_provider(provider)

    active = _build_instrumentations(disable)

    # Activate the OTel transport so wrap_agent / span dispatch via tracer.
    set_otel_transport(otel_trace.get_tracer("trodo-agent"))
    return active


def _build_instrumentations(disable: List[str]) -> List[str]:
    """Best-effort install of OTel auto-instrumentations.

    Mirrors auto_instrument.py's loader list but instruments via the OTel
    tracer (which is now configured to ship to Trodo via OTLP), not via
    TrodoSpanProcessor's adapter.
    """
    disabled = set(disable)
    active: List[str] = []
    candidates = [
        ("anthropic", "opentelemetry.instrumentation.anthropic", "AnthropicInstrumentor"),
        ("openai", "opentelemetry.instrumentation.openai", "OpenAIInstrumentor"),
        ("langchain", "opentelemetry.instrumentation.langchain", "LangChainInstrumentor"),
        ("llama-index", "opentelemetry.instrumentation.llamaindex", "LlamaIndexInstrumentor"),
        ("bedrock", "opentelemetry.instrumentation.bedrock", "BedrockInstrumentor"),
        ("cohere", "opentelemetry.instrumentation.cohere", "CohereInstrumentor"),
        ("google-generativeai", "opentelemetry.instrumentation.google_generativeai", "GoogleGenerativeAiInstrumentor"),
        ("vertexai", "opentelemetry.instrumentation.vertexai", "VertexAIInstrumentor"),
        ("requests", "opentelemetry.instrumentation.requests", "RequestsInstrumentor"),
        ("httpx", "opentelemetry.instrumentation.httpx", "HTTPXClientInstrumentor"),
    ]
    for short_id, mod_path, cls_name in candidates:
        if short_id in disabled:
            continue
        try:
            mod = __import__(mod_path, fromlist=[cls_name])
            getattr(mod, cls_name)().instrument()
            active.append(short_id)
        except Exception:
            # Package not installed or instrumentation already attached.
            pass
    return active
