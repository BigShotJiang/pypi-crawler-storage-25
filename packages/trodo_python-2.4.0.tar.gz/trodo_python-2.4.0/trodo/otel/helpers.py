"""Modular instrumentation helpers: span helpers (trace / tool / llm /
retrieval), one-shot ``track_llm_call``, and FastAPI middleware for
cross-service run joining.

These are the SDK's customer-facing surface for custom code: one dual-form
wrapper per span kind, usable either as ``helper("name", fn)`` or as a
``@helper("name")`` decorator. All forms auto-capture args/kwargs as
``input``, return value as ``output``, exception as ``error``.
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple, TypeVar

from .context import get_active_context
from .wrap_agent import SpanHandle, join_run, span as span_ctx


F = TypeVar("F", bound=Callable[..., Any])


def _make_input(fn: Callable[..., Any], args: tuple, kwargs: dict) -> Dict[str, Any]:
    """Bind positional+keyword args to their parameter names.

    Named kwargs are the common case; positional args fall back to 'args'
    if signature binding fails.
    """
    payload: Dict[str, Any] = {}
    if args:
        try:
            sig = inspect.signature(fn)
            bound = sig.bind_partial(*args, **kwargs)
            payload.update(bound.arguments)
        except Exception:
            payload["args"] = list(args)
            payload["kwargs"] = dict(kwargs)
    else:
        payload.update(kwargs)
    return payload


def _wrap_fn(
    fn: F,
    *,
    name: str,
    kind: str,
    on_result: Optional[Callable[[SpanHandle, Any], None]] = None,
    extra_set: Optional[Callable[[SpanHandle], None]] = None,
) -> F:
    """Wrap fn so each call opens a span (sync + async aware).

    ``extra_set`` runs on the span handle before the call (e.g. set_llm).
    ``on_result`` runs on the span handle with the return value (e.g.
    extracting OpenAI/Gemini usage into the LLM span).
    """
    is_async = inspect.iscoroutinefunction(fn)

    if is_async:

        @functools.wraps(fn)
        async def _async_wrapper(*args: Any, **kwargs: Any) -> Any:
            with span_ctx(name, kind=kind, input=_make_input(fn, args, kwargs)) as s:
                if kind == "tool":
                    s.set_tool(name)
                if extra_set is not None:
                    extra_set(s)
                result = await fn(*args, **kwargs)
                if on_result is not None:
                    try:
                        on_result(s, result)
                    except Exception:
                        pass
                s.set_output(result)
                return result

        return _async_wrapper  # type: ignore[return-value]

    @functools.wraps(fn)
    def _sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        with span_ctx(name, kind=kind, input=_make_input(fn, args, kwargs)) as s:
            if kind == "tool":
                s.set_tool(name)
            if extra_set is not None:
                extra_set(s)
            result = fn(*args, **kwargs)
            if on_result is not None:
                try:
                    on_result(s, result)
                except Exception:
                    pass
            s.set_output(result)
            return result

    return _sync_wrapper  # type: ignore[return-value]


def _dual_form(default_kind: str):
    """Build a dual-form helper: ``h("name", fn)`` OR ``@h("name")``."""

    def helper(
        name: Any = None,
        fn: Optional[Callable[..., Any]] = None,
        *,
        kind: str = default_kind,
        on_result: Optional[Callable[[SpanHandle, Any], None]] = None,
        extra_set: Optional[Callable[[SpanHandle], None]] = None,
    ) -> Any:
        # Case: h(fn) — bare decorator without parens; `name` is the fn.
        if callable(name) and fn is None:
            target = name
            return _wrap_fn(
                target,
                name=target.__name__,
                kind=kind,
                on_result=on_result,
                extra_set=extra_set,
            )
        # Case: h("name", fn) — helper form; wrap immediately.
        if callable(fn):
            return _wrap_fn(
                fn,
                name=name or fn.__name__,
                kind=kind,
                on_result=on_result,
                extra_set=extra_set,
            )
        # Case: h("name") / h(name="name") / h() — return decorator.
        def decorator(target: F) -> F:
            return _wrap_fn(
                target,
                name=name or target.__name__,
                kind=kind,
                on_result=on_result,
                extra_set=extra_set,
            )

        return decorator

    return helper


def tool(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
    *,
    kind: str = "tool",
) -> Any:
    """Wrap a function as a tool span — dual-form helper + decorator.

    Helper form (uselemma-compatible)::

        run_funnel_query = trodo.tool('run_funnel_query', run_funnel_query)
        result = run_funnel_query(team_id=1, preset='day7')

    Decorator form (backward-compatible)::

        @trodo.tool()
        def run_funnel_query(team_id, preset): ...

        @trodo.tool(name='custom-name')
        async def fetch(...): ...

        @trodo.tool  # bare (no parens)
        def do_thing(): ...
    """
    return _dual_form("tool")(name, fn, kind=kind)


def trace(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
) -> Any:
    """Wrap a function as a generic span — dual-form helper + decorator.

    Usage::

        trodo.trace('prepare', prepare_fn)({'q': 'hi'})

        @trodo.trace('step')
        def step(): ...
    """
    return _dual_form("generic")(name, fn, kind="generic")


def retrieval(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
) -> Any:
    """Wrap a retriever / vector search as a ``kind='retrieval'`` span."""
    return _dual_form("retrieval")(name, fn, kind="retrieval")


def _default_usage_extractor(result: Any) -> Tuple[Optional[int], Optional[int]]:
    """Auto-detect OpenAI ``usage`` and Gemini ``usageMetadata`` shapes."""
    if result is None:
        return (None, None)
    # OpenAI / OpenAI-compat: {"usage": {"prompt_tokens", "completion_tokens"}}
    usage = None
    if isinstance(result, dict):
        usage = result.get("usage")
    else:
        usage = getattr(result, "usage", None)
    if usage is not None:
        get = (lambda k: usage.get(k)) if isinstance(usage, dict) else (lambda k: getattr(usage, k, None))
        pt = get("prompt_tokens")
        ct = get("completion_tokens")
        if pt is not None or ct is not None:
            return (
                int(pt) if pt is not None else None,
                int(ct) if ct is not None else None,
            )
        # Anthropic-style nested under `usage`:
        it = get("input_tokens")
        ot = get("output_tokens")
        if it is not None or ot is not None:
            return (
                int(it) if it is not None else None,
                int(ot) if ot is not None else None,
            )
    # Gemini: {"usageMetadata": {"promptTokenCount", "candidatesTokenCount"}}
    if isinstance(result, dict):
        meta = result.get("usageMetadata")
        if isinstance(meta, dict):
            pt = meta.get("promptTokenCount")
            ct = meta.get("candidatesTokenCount")
            return (
                int(pt) if pt is not None else None,
                int(ct) if ct is not None else None,
            )
    return (None, None)


def llm(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
    *,
    model: Optional[str] = None,
    provider: Optional[str] = None,
    temperature: Optional[float] = None,
    extract_usage: Optional[Callable[[Any], Tuple[Optional[int], Optional[int]]]] = None,
) -> Any:
    """Wrap an LLM call as a ``kind='llm'`` span with auto token extraction.

    The helper records ``model``/``provider`` on entry; on return it inspects
    the response for the common usage shapes (OpenAI ``usage.prompt_tokens``,
    Anthropic ``usage.input_tokens``, Gemini ``usageMetadata.promptTokenCount``)
    and records tokens. Pass ``extract_usage=lambda r: (in, out)`` to override.

    Usage::

        answer = trodo.llm(
            'answer', call_openai, model='gpt-4o-mini', provider='openai',
        )(messages)

        @trodo.llm('plan', model='claude-haiku-4-5', provider='anthropic')
        def plan(messages): ...
    """
    extractor = extract_usage or _default_usage_extractor

    def _set_llm(s: SpanHandle) -> None:
        if model or provider or temperature is not None:
            s.set_llm(
                model=model,
                provider=provider,
                temperature=temperature,
            )

    def _on_result(s: SpanHandle, result: Any) -> None:
        try:
            pt, ct = extractor(result)
        except Exception:
            pt, ct = (None, None)
        if pt is not None or ct is not None:
            s.set_llm(
                model=model,
                provider=provider,
                input_tokens=pt,
                output_tokens=ct,
                temperature=temperature,
            )

    return _dual_form("llm")(
        name, fn, kind="llm", extra_set=_set_llm, on_result=_on_result
    )


def track_mcp(
    *,
    http: Any,
    tool: str,
    distinct_id: str,
    input: Any = None,
    output: Any = None,
    error: Optional[str] = None,
    duration_ms: Optional[int] = None,
    session_id: Optional[str] = None,
    client_label: Optional[str] = None,
    attributes: Optional[Dict[str, Any]] = None,
    agent_name: str = "MCP",
    started_at: Optional[str] = None,
    ended_at: Optional[str] = None,
) -> str:
    """Record one MCP tool call as a runless span. See ``Client.track_mcp``
    for the customer-facing docstring; this is the implementation that
    builds the span payload and posts it via the HttpClient.

    Returns the span_id.
    """
    import json as _json
    import uuid as _uuid
    from datetime import datetime, timedelta, timezone

    if not tool:
        raise ValueError("track_mcp: 'tool' is required")
    if not distinct_id:
        raise ValueError("track_mcp: 'distinct_id' is required (runless spans must attribute)")

    span_id = str(_uuid.uuid4())
    conv_id = session_id or str(_uuid.uuid4())

    now = datetime.now(timezone.utc)
    if ended_at is None:
        ended_at = now.isoformat()
    if started_at is None:
        offset_ms = duration_ms if isinstance(duration_ms, int) and duration_ms > 0 else 0
        started_at = (now - timedelta(milliseconds=offset_ms)).isoformat()
    if duration_ms is None:
        duration_ms = 0

    status = "error" if error else "ok"
    if error:
        error_payload: Any = {"error": error}
        output_to_record = output if output is not None else error_payload
    else:
        output_to_record = output

    def _stringify(value: Any) -> Any:
        if value is None or isinstance(value, str):
            return value
        try:
            return _json.dumps(value, default=str)
        except Exception:
            return str(value)

    merged_attributes: Dict[str, Any] = dict(attributes or {})
    if client_label:
        merged_attributes.setdefault("mcp_client_label", client_label)

    span_payload: Dict[str, Any] = {
        "span_id": span_id,
        "kind": "tool",
        "name": f"tool.{tool}",
        "status": status,
        "input": _stringify({"tool": tool, "params": input}) if input is not None else None,
        "output": _stringify(output_to_record),
        "tool_name": tool,
        "started_at": started_at,
        "ended_at": ended_at,
        "duration_ms": duration_ms,
        "distinct_id": distinct_id,
        "conversation_id": conv_id,
        "agent_name": agent_name,
        "error_message": error,
        "attributes": merged_attributes,
    }

    try:
        http.post_runless_spans([span_payload])
    except Exception:
        # Span loss must never break the caller's request flow. The
        # underlying HttpClient already retries; failures here mean the
        # backend rejected (rare) or the network is permanently down.
        pass
    return span_id


def track_llm_call(
    *,
    model: Optional[str] = None,
    provider: Optional[str] = None,
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
    prompt: Any = None,
    completion: Any = None,
    temperature: Optional[float] = None,
    cost: Optional[float] = None,
    name: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """Record a one-shot LLM span for a raw-HTTP caller.

    Opens and immediately closes a ``span(kind='llm')`` populated with the
    model + token counts + prompt/completion. No-op outside an active run
    context.

    Usage:
        resp = httpx.post(url, json=body).json()
        trodo.track_llm_call(
            model='gemini-2.5-flash',
            provider='google',
            input_tokens=resp['usageMetadata']['promptTokenCount'],
            output_tokens=resp['usageMetadata']['candidatesTokenCount'],
            prompt=body,
            completion=resp,
        )
    """
    if get_active_context() is None:
        return
    span_name = name or (f"llm.{provider}.{model}" if model else "llm")
    with span_ctx(span_name, kind="llm", input=prompt, attributes=metadata) as s:
        s.set_llm(
            model=model,
            provider=provider,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost=cost,
            temperature=temperature,
        )
        if completion is not None:
            s.set_output(completion)


# ---------------------------------------------------------------------------
# FastAPI / Starlette middleware
# ---------------------------------------------------------------------------

_TRODO_RUN_HEADER = "x-trodo-run-id"
_TRODO_PARENT_SPAN_HEADER = "x-trodo-parent-span-id"
_TRODO_AGENT_HEADER = "x-trodo-agent-name"


def fastapi_middleware(client: Any) -> Callable:
    """Return a FastAPI/Starlette middleware that auto-joins remote runs.

    If inbound request has X-Trodo-Run-Id, every span created while
    handling the request nests under the caller's run. Otherwise the
    handler runs with no active context (no-op tracking).

    Usage:
        from fastapi import FastAPI
        import trodo
        trodo.init(site_id='...')
        app = FastAPI()
        app.middleware('http')(trodo.fastapi_middleware(trodo._client))
    """
    processor = client._span_processor
    site_id = client.site_id

    async def _middleware(request: Any, call_next: Callable[[Any], Awaitable[Any]]):
        headers = {k.lower(): v for k, v in request.headers.items()}
        run_id = headers.get(_TRODO_RUN_HEADER)
        parent_span_id = headers.get(_TRODO_PARENT_SPAN_HEADER)
        name = (
            headers.get(_TRODO_AGENT_HEADER)
            or f"http.{request.method}.{request.url.path}"
        )
        if not run_id:
            return await call_next(request)

        input_payload = {
            "method": request.method,
            "path": request.url.path,
        }
        with join_run(
            processor=processor,
            team_site_id=site_id,
            run_id=run_id,
            parent_span_id=parent_span_id,
            name=name,
            kind="agent",
            input=input_payload,
        ) as s:
            response = await call_next(request)
            try:
                s.set_output({"status_code": getattr(response, "status_code", None)})
            except Exception:
                pass
            return response

    return _middleware


def propagation_headers() -> Dict[str, str]:
    """Return HTTP headers that carry the current run/span context.

    Use when making outbound HTTP calls to downstream services so they
    can ``join_run`` instead of creating their own runs.
    """
    ctx = get_active_context()
    if ctx is None:
        return {}
    headers: Dict[str, str] = {"X-Trodo-Run-Id": ctx.run_id}
    if ctx.span_id:
        headers["X-Trodo-Parent-Span-Id"] = ctx.span_id
    return headers
