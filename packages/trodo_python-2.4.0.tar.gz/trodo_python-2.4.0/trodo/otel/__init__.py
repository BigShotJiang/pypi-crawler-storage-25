"""OpenTelemetry-compatible run/span pipeline for trodo-python."""

from .context import ActiveSpanContext, get_active_context, run_with_context
from .processor import TrodoSpanProcessor, TrodoRun, TrodoSpan
from .wrap_agent import wrap_agent, span, SpanHandle, RunHandle
from .auto_instrument import enable_auto_instrument, otel_span_to_trodo_span

__all__ = [
    "ActiveSpanContext",
    "get_active_context",
    "run_with_context",
    "TrodoSpanProcessor",
    "TrodoRun",
    "TrodoSpan",
    "wrap_agent",
    "span",
    "SpanHandle",
    "RunHandle",
    "enable_auto_instrument",
    "otel_span_to_trodo_span",
]
