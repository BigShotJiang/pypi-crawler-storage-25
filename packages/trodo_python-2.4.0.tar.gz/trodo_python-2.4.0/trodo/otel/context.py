"""Active run/span context using contextvars — auto-propagates across awaits
and threading.local-style sync code.
"""

from __future__ import annotations

import contextvars
from dataclasses import dataclass
from typing import Optional


@dataclass
class ActiveSpanContext:
    run_id: str
    span_id: str
    parent_span_id: Optional[str]
    team_site_id: str
    processor: object  # TrodoSpanProcessor — avoid circular import


_active: contextvars.ContextVar[Optional[ActiveSpanContext]] = contextvars.ContextVar(
    "trodo_active_span", default=None,
)


def get_active_context() -> Optional[ActiveSpanContext]:
    return _active.get()


class run_with_context:
    """Context manager that sets the active span context for its duration."""

    def __init__(self, ctx: ActiveSpanContext) -> None:
        self._ctx = ctx
        self._token: Optional[contextvars.Token] = None

    def __enter__(self) -> ActiveSpanContext:
        self._token = _active.set(self._ctx)
        return self._ctx

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._token is not None:
            _active.reset(self._token)
            self._token = None
