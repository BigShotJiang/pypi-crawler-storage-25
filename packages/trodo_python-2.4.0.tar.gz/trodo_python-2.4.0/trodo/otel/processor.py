"""TrodoSpanProcessor — buffers spans and ships them to the Trodo ingest API.

Mirrors the Node SDK processor: when a run finalises we POST /runs/ingest
with the run and all pending spans for that run. Standalone spans (no run)
flush asynchronously via append_spans.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional


@dataclass
class TrodoRun:
    run_id: str
    agent_name: str
    distinct_id: Optional[str] = None
    conversation_id: Optional[str] = None
    parent_run_id: Optional[str] = None
    status: str = "ok"  # 'running' | 'ok' | 'error'
    input: Optional[str] = None
    output: Optional[str] = None
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    duration_ms: Optional[int] = None
    error_summary: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    # Aggregates summed from child spans at finalisation.
    total_tokens_in: Optional[int] = None
    total_tokens_out: Optional[int] = None
    total_cost: Optional[float] = None
    span_count: Optional[int] = None
    tool_count: Optional[int] = None
    error_count: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class TrodoSpan:
    span_id: str
    run_id: str
    parent_span_id: Optional[str]
    kind: str = "generic"  # 'llm' | 'tool' | 'agent' | 'retrieval' | 'generic'
    name: str = ""
    status: str = "ok"
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    duration_ms: Optional[int] = None
    input: Optional[str] = None
    output: Optional[str] = None
    error_type: Optional[str] = None
    error_message: Optional[str] = None
    model: Optional[str] = None
    provider: Optional[str] = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    cost: Optional[float] = None
    temperature: Optional[float] = None
    tool_name: Optional[str] = None
    attributes: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


class TrodoSpanProcessor:
    """Buffers spans per run_id; flushes to /runs/ingest when the run ends.

    Spans emitted while a ``join_run`` context is active are forwarded via
    ``append_spans`` immediately on each enqueue (because the owning service
    is remote and won't finalise the run).
    """

    def __init__(
        self,
        http_client: Any,
        flush_interval_s: float = 5.0,
        max_spans_per_run: int = 1000,
    ) -> None:
        self._http = http_client
        self._flush_interval = flush_interval_s
        self._max_spans = max_spans_per_run
        self._pending: Dict[str, List[TrodoSpan]] = {}
        self._lock = threading.Lock()
        self._shutdown = False
        # run_ids that are "joined" (owned by a remote service) — their spans
        # are flushed incrementally via append_spans, never batched for a
        # local ingest_run call.
        self._joined_runs: set[str] = set()

    def mark_joined(self, run_id: str) -> None:
        with self._lock:
            self._joined_runs.add(run_id)

    def unmark_joined(self, run_id: str) -> None:
        with self._lock:
            self._joined_runs.discard(run_id)
            self._pending.pop(run_id, None)

    def enqueue_span(self, span: TrodoSpan) -> None:
        """Buffer a completed span under its run_id.

        Joined runs flush immediately (append_spans) instead of batching.
        """
        with self._lock:
            joined = span.run_id in self._joined_runs
            if joined:
                pass
            else:
                bucket = self._pending.setdefault(span.run_id, [])
                if len(bucket) < self._max_spans:
                    bucket.append(span)
        if joined:
            try:
                self._http.post_spans_append(span.run_id, [span.to_dict()])
            except Exception:
                pass

    def get_pending(self, run_id: str) -> List[TrodoSpan]:
        with self._lock:
            return list(self._pending.get(run_id, []))

    def ingest_run(self, run: TrodoRun) -> None:
        """Flush a run + all its buffered spans in one call."""
        with self._lock:
            spans = self._pending.pop(run.run_id, [])
        payload: Dict[str, Any] = {"run": run.to_dict()}
        if spans:
            payload["spans"] = [s.to_dict() for s in spans]
        try:
            self._http.post_run_ingest(payload)
        except Exception:
            pass

    def start_run(self, run: TrodoRun) -> None:
        """Open a Run row server-side without holding a context manager.

        Pairs with ``end_run`` for sessions that span multiple processes or
        HTTP requests. Spans emitted between start_run and end_run flush
        incrementally via append_spans (callers are expected to mark_joined).
        """
        try:
            self._http.post_run_start({"run": run.to_dict()})
        except Exception:
            pass

    def end_run(self, run_id: str, payload: Dict[str, Any]) -> None:
        """Finalise a Run opened by start_run."""
        try:
            self._http.post_run_end(run_id, payload)
        except Exception:
            pass

    def append_spans(self, run_id: str, spans: List[TrodoSpan]) -> None:
        """Stream spans for a long-running or joined run without finalising."""
        if not spans:
            return
        try:
            self._http.post_spans_append(run_id, [s.to_dict() for s in spans])
        except Exception:
            pass

    def force_flush(self) -> None:
        """Flush any buffered spans that don't have a run finalise yet."""
        with self._lock:
            pending = list(self._pending.items())
            self._pending.clear()
        for run_id, spans in pending:
            if not spans:
                continue
            try:
                self._http.post_spans_append(
                    run_id, [s.to_dict() for s in spans]
                )
            except Exception:
                pass

    def shutdown(self) -> None:
        self._shutdown = True
        self.force_flush()
