"""TrodoClient — main SDK class for Python."""

from __future__ import annotations

import functools
from typing import Any, Callable, Dict, List, Optional, Union

from .api.http_client import HttpClient
from .session.session_manager import SessionManager
from .managers.group_manager import GroupProfile
from .queue.event_queue import EventQueue
from .queue.batch_flusher import BatchFlusher
from .auto.auto_event_manager import AutoEventManager
from .user_context import UserContext
from .otel.processor import TrodoSpanProcessor
from .otel.wrap_agent import (
    wrap_agent as wrap_agent_ctx,
    span as span_ctx,
    join_run as join_run_ctx,
    start_run as start_run_fn,
    end_run as end_run_fn,
    current_run_id as _current_run_id,
    current_span_id as _current_span_id,
)
from .otel.auto_instrument import enable_auto_instrument
from .otel.register import register_otel as _register_otel
from .otel.helpers import (
    tool as tool_decorator,
    track_llm_call as track_llm_call_fn,
    track_mcp as track_mcp_fn,
    fastapi_middleware as fastapi_middleware_fn,
    propagation_headers as propagation_headers_fn,
)
from .types import (
    ApiResult,
    ResetResult,
    WalletAddressResult,
    FeedbackProps,
)


class TrodoClient:
    def __init__(
        self,
        site_id: str,
        api_base: str = "https://sdkapi.trodo.ai",
        timeout: int = 10,
        retries: int = 2,
        batch_enabled: bool = False,
        batch_size: int = 50,
        batch_flush_interval: float = 5.0,
        auto_events: bool = False,
        on_error: Optional[Any] = None,
        debug: bool = False,
        auto_instrument: bool = True,
        otel_mode: str = "trodo",
    ) -> None:
        if not site_id:
            raise ValueError("trodo-python: site_id is required")

        self.site_id = site_id
        self._api_base = api_base

        self._http = HttpClient(
            api_base=api_base,
            site_id=site_id,
            timeout=timeout,
            retries=retries,
            on_error=on_error,
            debug=debug,
        )

        self._session_manager = SessionManager()

        if batch_enabled:
            self._event_queue: Optional[EventQueue] = EventQueue(batch_size)
            self._batch_flusher: Optional[BatchFlusher] = BatchFlusher(
                self._event_queue, self._http, batch_flush_interval
            )
            self._batch_flusher.start()
        else:
            self._event_queue = None
            self._batch_flusher = None

        self._auto_event_manager = AutoEventManager(
            site_id, self._http, self._session_manager
        )

        if auto_events:
            self._auto_event_manager.enable()

        self._user_context_cache: Dict[str, UserContext] = {}

        self._span_processor = TrodoSpanProcessor(http_client=self._http)
        if auto_instrument:
            import os
            if os.environ.get("TRODO_LEGACY_INIT") == "1":
                # Pre-2.4 escape hatch for one minor version.
                enable_auto_instrument(self._span_processor)
            else:
                _register_otel(
                    site_id=site_id,
                    processor=self._span_processor,
                    mode=otel_mode,
                    endpoint=api_base,
                )

    def _get_span_processor(self) -> TrodoSpanProcessor:
        """Internal: expose the span processor to register_otel. Not part of
        the public surface; subject to change between minors."""
        return self._span_processor

    # --------------------------------------------------------------------------
    # Primary pattern: for_user()
    # --------------------------------------------------------------------------

    def for_user(
        self,
        distinct_id: str,
        session_id: Optional[str] = None,
    ) -> UserContext:
        if distinct_id in self._user_context_cache:
            return self._user_context_cache[distinct_id]

        ctx = UserContext(
            distinct_id=distinct_id,
            site_id=self.site_id,
            http_client=self._http,
            session_manager=self._session_manager,
            event_queue=self._event_queue,
            batch_flusher=self._batch_flusher,
            auto_event_manager=self._auto_event_manager,
            session_id=session_id,
        )
        self._user_context_cache[distinct_id] = ctx
        return ctx

    # --------------------------------------------------------------------------
    # Direct-call pattern (distinct_id as first arg)
    # --------------------------------------------------------------------------

    def track(
        self,
        distinct_id: str,
        event_name: str,
        properties: Optional[Dict[str, Any]] = None,
        category: str = "custom",
    ) -> None:
        self.for_user(distinct_id).track(event_name, properties, category)

    def identify(self, identify_id: str, session_id: Optional[str] = None) -> "UserContext":
        if identify_id in self._user_context_cache:
            return self._user_context_cache[identify_id]
        ctx = self.for_user(identify_id, session_id)
        ctx.identify(identify_id)
        return ctx

    def wallet_address(self, distinct_id: str, wallet_addr: str) -> WalletAddressResult:
        return self.for_user(distinct_id).wallet_address(wallet_addr)

    def reset(self, distinct_id: str) -> ResetResult:
        self._user_context_cache.pop(distinct_id, None)
        return self.for_user(distinct_id).reset()

    # People (direct)
    def people_set(self, distinct_id: str, properties: Dict[str, Any]) -> ApiResult:
        return self.for_user(distinct_id).people.set(properties)

    def people_set_once(self, distinct_id: str, properties: Dict[str, Any]) -> ApiResult:
        return self.for_user(distinct_id).people.set_once(properties)

    def people_unset(self, distinct_id: str, keys: Union[str, List[str]]) -> ApiResult:
        return self.for_user(distinct_id).people.unset(keys)

    def people_increment(self, distinct_id: str, key: str, amount: float = 1) -> ApiResult:
        return self.for_user(distinct_id).people.increment(key, amount)

    def people_append(self, distinct_id: str, key: str, values: List[Any]) -> ApiResult:
        return self.for_user(distinct_id).people.append(key, values)

    def people_union(self, distinct_id: str, key: str, values: List[Any]) -> ApiResult:
        return self.for_user(distinct_id).people.union(key, values)

    def people_remove(self, distinct_id: str, key: str, values: List[Any]) -> ApiResult:
        return self.for_user(distinct_id).people.remove(key, values)

    def people_track_charge(
        self,
        distinct_id: str,
        amount: float,
        properties: Optional[Dict[str, Any]] = None,
    ) -> ApiResult:
        return self.for_user(distinct_id).people.track_charge(amount, properties)

    def people_clear_charges(self, distinct_id: str) -> ApiResult:
        return self.for_user(distinct_id).people.clear_charges()

    def people_delete_user(self, distinct_id: str) -> ApiResult:
        return self.for_user(distinct_id).people.delete_user()

    # Groups (direct)
    def set_group(
        self, distinct_id: str, group_key: str, group_id: Union[str, List[str]]
    ) -> ApiResult:
        return self.for_user(distinct_id).set_group(group_key, group_id)

    def add_group(self, distinct_id: str, group_key: str, group_id: str) -> ApiResult:
        return self.for_user(distinct_id).add_group(group_key, group_id)

    def remove_group(self, distinct_id: str, group_key: str, group_id: str) -> ApiResult:
        return self.for_user(distinct_id).remove_group(group_key, group_id)

    def get_group(
        self, distinct_id: str, group_key: str, group_id: str
    ) -> GroupProfile:
        return self.for_user(distinct_id).get_group(group_key, group_id)

    # --------------------------------------------------------------------------
    # Auto events
    # --------------------------------------------------------------------------

    def enable_auto_events(self) -> None:
        self._auto_event_manager.enable()

    def disable_auto_events(self) -> None:
        self._auto_event_manager.disable()

    # --------------------------------------------------------------------------
    # Lifecycle
    # --------------------------------------------------------------------------

    def flush(self) -> None:
        if self._batch_flusher:
            self._batch_flusher.flush()
        self._span_processor.force_flush()

    def shutdown(self) -> None:
        self._auto_event_manager.disable()
        if self._batch_flusher:
            self._batch_flusher.stop()
            self._batch_flusher.flush()
        self._span_processor.shutdown()

    # --------------------------------------------------------------------------
    # Agent Runs — Lemma-style seamless wrapping
    # --------------------------------------------------------------------------

    def wrap_agent(
        self,
        agent_name: str,
        distinct_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        parent_run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> wrap_agent_ctx:
        """Context manager that captures the wrapped block as an agent run.

        Every OTel-instrumented call (Anthropic, OpenAI, LangChain…) made
        inside the ``with`` is auto-captured as a nested span.
        """
        return wrap_agent_ctx(
            processor=self._span_processor,
            team_site_id=self.site_id,
            agent_name=agent_name,
            distinct_id=distinct_id,
            conversation_id=conversation_id,
            parent_run_id=parent_run_id,
            metadata=metadata,
        )

    def agent(
        self,
        agent_name: str,
        *,
        distinct_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator form of wrap_agent."""

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                with self.wrap_agent(
                    agent_name,
                    distinct_id=distinct_id,
                    conversation_id=conversation_id,
                    metadata=metadata,
                ) as run:
                    result = fn(*args, **kwargs)
                    run.set_output(result)
                    return result
            return wrapper

        return decorator

    def span(
        self,
        name: str,
        *,
        kind: str = "generic",
        input: Any = None,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> span_ctx:
        """Create a nested span inside the current run."""
        return span_ctx(name=name, kind=kind, input=input, attributes=attributes)

    def start_run(
        self,
        agent_name: str,
        *,
        run_id: Optional[str] = None,
        distinct_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        parent_run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        input: Any = None,
    ) -> str:
        """Open a Run record outside a context manager. Returns the run_id.

        Use ``end_run`` to finalise, ``join_run`` from any process to add spans.
        """
        return start_run_fn(
            processor=self._span_processor,
            agent_name=agent_name,
            run_id=run_id,
            distinct_id=distinct_id,
            conversation_id=conversation_id,
            parent_run_id=parent_run_id,
            metadata=metadata,
            input=input,
        )

    def end_run(
        self,
        run_id: str,
        *,
        output: Any = None,
        status: str = "ok",
        error_summary: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Finalise a Run previously opened by :meth:`start_run`."""
        end_run_fn(
            run_id,
            processor=self._span_processor,
            output=output,
            status=status,
            error_summary=error_summary,
            metadata=metadata,
        )

    def join_run(
        self,
        run_id: str,
        parent_span_id: Optional[str] = None,
        *,
        name: str = "remote.handler",
        kind: str = "agent",
        input: Any = None,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> join_run_ctx:
        """Open a span on an existing run owned by a remote service.

        Use this in downstream microservices that receive an inbound
        request carrying ``X-Trodo-Run-Id`` / ``X-Trodo-Parent-Span-Id``.
        Prefer :meth:`fastapi_middleware` to automate this.
        """
        return join_run_ctx(
            processor=self._span_processor,
            team_site_id=self.site_id,
            run_id=run_id,
            parent_span_id=parent_span_id,
            name=name,
            kind=kind,
            input=input,
            attributes=attributes,
        )

    def tool(
        self,
        name: Optional[str] = None,
        *,
        kind: str = "tool",
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Decorator that wraps a function call as a tool span."""
        return tool_decorator(name=name, kind=kind)

    def track_llm_call(
        self,
        *,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
        prompt: Any = None,
        completion: Any = None,
        temperature: Optional[float] = None,
        cost: Optional[float] = None,
        name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Record an LLM span for a raw-HTTP caller (no OTel adapter)."""
        track_llm_call_fn(
            model=model,
            provider=provider,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            prompt=prompt,
            completion=completion,
            temperature=temperature,
            cost=cost,
            name=name,
            metadata=metadata,
        )

    def track_mcp(
        self,
        *,
        tool: str,
        distinct_id: str,
        input: Any = None,
        output: Any = None,
        error: Optional[str] = None,
        duration_ms: Optional[int] = None,
        session_id: Optional[str] = None,
        client_label: Optional[str] = None,
        attributes: Optional[Dict[str, Any]] = None,
        agent_name: str = "MCP",
        started_at: Optional[str] = None,
        ended_at: Optional[str] = None,
    ) -> str:
        """Record a single MCP tool call as a runless span.

        Use this from inside an MCP server's ``tools/call`` handler — one
        call to ``track_mcp`` = one row in ``agent_spans`` with ``run_id``
        NULL. The MCP server proxies tool calls but never sees the user's
        prompt or the LLM's final answer, so a parent run carries no
        analytical value; the span is the unit of analytics.

        Required:
          tool: the tool name (becomes ``name = "tool.<tool>"``).
          distinct_id: end-user attribution (email or stable user id).

        Optional but recommended:
          input / output: the tool's args + full result. Truncated at 64KB.
          error: if set, marks ``status="error"`` and stored as
                 ``error_message``.
          duration_ms: tool wall time. If omitted, falls back to 0.
          session_id: the ``Mcp-Session-Id`` from the client; stored as
                      ``conversation_id`` for grouping. Auto-uuid'd if
                      omitted (each call becomes its own bucket).
          client_label: which MCP client (anthropic / cursor / chatgpt /
                        etc.); merged into attributes.
          attributes: any extra free-form key/values.
          agent_name: defaults to "MCP"; override only for custom tags.

        Returns the span_id (str) so the caller can correlate.
        """
        return track_mcp_fn(
            http=self._http,
            tool=tool,
            distinct_id=distinct_id,
            input=input,
            output=output,
            error=error,
            duration_ms=duration_ms,
            session_id=session_id,
            client_label=client_label,
            attributes=attributes,
            agent_name=agent_name,
            started_at=started_at,
            ended_at=ended_at,
        )

    def fastapi_middleware(self) -> Callable:
        """Return a FastAPI/Starlette middleware that auto-joins runs."""
        return fastapi_middleware_fn(self)

    def propagation_headers(self) -> Dict[str, str]:
        """Return outbound HTTP headers carrying the current run/span id."""
        return propagation_headers_fn()

    def current_run_id(self) -> Optional[str]:
        return _current_run_id()

    def current_span_id(self) -> Optional[str]:
        return _current_span_id()

    def feedback(
        self,
        run_id: str,
        satisfaction: Optional[str] = None,
        rating: Optional[float] = None,
        comment: Optional[str] = None,
        feedback: Optional[str] = None,
        distinct_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ApiResult:
        """Attach feedback to a completed run."""
        if satisfaction is None and rating is None and not (comment or feedback):
            raise ValueError(
                "At least one of 'satisfaction', 'rating', or 'comment' is required"
            )
        payload: Dict[str, Any] = {
            "satisfaction": satisfaction,
            "rating": rating,
            "comment": comment if comment is not None else feedback,
            "distinct_id": distinct_id,
            "attributes": metadata or {},
        }
        return self._http.post_run_feedback(run_id, payload)

    def feedback_props(self, run_id: str, props: FeedbackProps) -> ApiResult:
        """Convenience — pass a FeedbackProps dataclass."""
        return self.feedback(
            run_id,
            satisfaction=props.satisfaction,
            rating=props.rating,
            comment=props.comment,
            feedback=props.feedback,
            distinct_id=props.distinct_id,
            metadata=props.metadata,
        )
