"""
trodo-python — Trodo Analytics SDK for Python

Quick start (any stack):
    import trodo
    trodo.init(site_id='your-site-id')  # auto-instrument on by default

    # Anthropic / OpenAI / LangChain / LlamaIndex — nothing else to do.
    with trodo.wrap_agent('customer-support',
                          distinct_id=uid, conversation_id=conv) as run:
        result = agent.run(query)
        run.set_output(result)

    trodo.feedback(run.run_id, satisfaction='positive', rating=5)

Raw-HTTP LLM caller (no OTel integration for your client):
    resp = httpx.post(..., json=body).json()
    trodo.track_llm_call(
        model='gemini-2.5-flash', provider='google',
        input_tokens=resp['usageMetadata']['promptTokenCount'],
        output_tokens=resp['usageMetadata']['candidatesTokenCount'],
        prompt=body, completion=resp,
    )

Custom tool:
    @trodo.tool()
    def run_funnel_query(team_id, preset): ...

Downstream microservice (join the caller's run instead of making a new one):
    # In FastAPI:
    app.middleware('http')(trodo.fastapi_middleware())

    # Or manually:
    with trodo.join_run(
        run_id=headers['X-Trodo-Run-Id'],
        parent_span_id=headers['X-Trodo-Parent-Span-Id'],
    ):
        ...
"""

from __future__ import annotations

__version__ = "2.4.0"

from typing import Any, Callable, Dict, List, Optional, Union

from .client import TrodoClient
from .user_context import UserContext
from .managers.group_manager import GroupProfile
from .otel.wrap_agent import (
    wrap_agent as _wrap_agent_ctx,
    span as _span_ctx,
    join_run as _join_run_ctx,
    RunHandle,
    SpanHandle,
)
from .types import (
    ApiResult, ResetResult, WalletAddressResult,
    FeedbackProps,
)

__all__ = [
    "TrodoClient",
    "UserContext",
    "GroupProfile",
    "RunHandle",
    "SpanHandle",
    "FeedbackProps",
    "init",
    "register_otel",
    "for_user",
    "track",
    "identify",
    "wallet_address",
    "reset",
    "enable_auto_events",
    "disable_auto_events",
    "flush",
    "shutdown",
    # Agent runs
    "wrap_agent",
    "agent",
    "span",
    "tool",
    "trace",
    "llm",
    "retrieval",
    "join_run",
    "start_run",
    "end_run",
    "track_llm_call",
    "track_mcp",
    "feedback",
    "get_tracer",
    # Cross-service propagation
    "fastapi_middleware",
    "propagation_headers",
    "current_run_id",
    "current_span_id",
]

# ============================================================================
# Singleton convenience API
# ============================================================================

_client: Optional[TrodoClient] = None


def _get_client() -> TrodoClient:
    if _client is None:
        raise RuntimeError(
            "trodo-python: Call trodo.init(site_id=...) before using the SDK."
        )
    return _client


def _maybe_client() -> Optional[TrodoClient]:
    return _client


def init(
    site_id: str,
    api_base: str = "https://sdkapi.trodo.ai",
    timeout: int = 10,
    retries: int = 2,
    batch_enabled: bool = False,
    batch_size: int = 50,
    batch_flush_interval: float = 5.0,
    auto_events: bool = False,
    on_error: Optional[Any] = None,
    debug: bool = False,
    auto_instrument: bool = True,
    otel_mode: str = "trodo",
) -> TrodoClient:
    """Initialise the singleton SDK instance.

    ``auto_instrument=True`` (default) registers OTel adapters for
    Anthropic, OpenAI, LangChain, LlamaIndex, Google Generative AI and
    any other installed opentelemetry-instrumentation-* package, so
    LLM calls emit token/cost spans with no further code.
    """
    global _client
    _client = TrodoClient(
        site_id=site_id,
        api_base=api_base,
        timeout=timeout,
        retries=retries,
        batch_enabled=batch_enabled,
        batch_size=batch_size,
        batch_flush_interval=batch_flush_interval,
        auto_events=auto_events,
        on_error=on_error,
        debug=debug,
        auto_instrument=auto_instrument,
        otel_mode=otel_mode,
    )
    return _client


def register_otel(
    *,
    site_id: Optional[str] = None,
    mode: str = "trodo",
    endpoint: Optional[str] = None,
    service_name: str = "trodo-agent",
) -> Any:
    """Configure the OTel pipeline with one call.

    Auto-creates the singleton TrodoClient if init() hasn't been called yet,
    so this can replace init() for OTel-first deployments.

    Modes:
      - 'trodo' (default): bridges OTel auto-instrumentations into
        TrodoSpanProcessor (HTTP API path). Same as init() with default config.
      - 'otlp': registers an OTel TracerProvider with an OTLP/protobuf
        exporter pointed at Trodo's /v1/traces. Use alongside Datadog/Jaeger
        or for vanilla OTel-native setups.

    Example:
        import trodo
        trodo.register_otel(site_id=os.environ['TRODO_SITE_ID'], mode='otlp')
    """
    global _client
    from .otel.register import register_otel as _impl
    if _client is None:
        if not site_id:
            raise ValueError(
                "register_otel: pass site_id, or call trodo.init(site_id=...) first."
            )
        # Suppress legacy auto_instrument inside the constructor — register_otel
        # below is what wires the pipeline.
        _client = TrodoClient(site_id=site_id, auto_instrument=False)
    return _impl(
        site_id=site_id or _client.site_id,
        processor=_client._get_span_processor(),
        mode=mode,
        endpoint=endpoint,
        service_name=service_name,
    )


def for_user(
    distinct_id: str,
    session_id: Optional[str] = None,
) -> UserContext:
    return _get_client().for_user(distinct_id, session_id)


def track(
    distinct_id: str,
    event_name: str,
    properties: Optional[Dict[str, Any]] = None,
    category: str = "custom",
) -> None:
    _get_client().track(distinct_id, event_name, properties, category)


def identify(identify_id: str, session_id: Optional[str] = None) -> UserContext:
    return _get_client().identify(identify_id, session_id)


def wallet_address(distinct_id: str, wallet_addr: str) -> WalletAddressResult:
    return _get_client().wallet_address(distinct_id, wallet_addr)


def reset(distinct_id: str) -> ResetResult:
    return _get_client().reset(distinct_id)


def enable_auto_events() -> None:
    _get_client().enable_auto_events()


def disable_auto_events() -> None:
    _get_client().disable_auto_events()


def flush() -> None:
    _get_client().flush()


def shutdown() -> None:
    _get_client().shutdown()


# ----------------------------------------------------------------------------
# Agent Runs
# ----------------------------------------------------------------------------

def wrap_agent(
    agent_name: str,
    *,
    distinct_id: Optional[str] = None,
    conversation_id: Optional[str] = None,
    parent_run_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> _wrap_agent_ctx:
    """Wrap a block as an agent run — returns a context manager yielding RunHandle."""
    return _get_client().wrap_agent(
        agent_name,
        distinct_id=distinct_id,
        conversation_id=conversation_id,
        parent_run_id=parent_run_id,
        metadata=metadata,
    )


def agent(
    agent_name: str,
    *,
    distinct_id: Optional[str] = None,
    conversation_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator form of wrap_agent."""
    return _get_client().agent(
        agent_name,
        distinct_id=distinct_id,
        conversation_id=conversation_id,
        metadata=metadata,
    )


def span(
    name: str,
    *,
    kind: str = "generic",
    input: Any = None,
    attributes: Optional[Dict[str, Any]] = None,
) -> _span_ctx:
    """Nested span inside the current run."""
    return _get_client().span(name, kind=kind, input=input, attributes=attributes)


def join_run(
    run_id: str,
    parent_span_id: Optional[str] = None,
    *,
    name: str = "remote.handler",
    kind: str = "agent",
    input: Any = None,
    attributes: Optional[Dict[str, Any]] = None,
) -> _join_run_ctx:
    """Open a span on an existing run owned by a remote service."""
    return _get_client().join_run(
        run_id,
        parent_span_id,
        name=name,
        kind=kind,
        input=input,
        attributes=attributes,
    )


def start_run(
    agent_name: str,
    *,
    run_id: Optional[str] = None,
    distinct_id: Optional[str] = None,
    conversation_id: Optional[str] = None,
    parent_run_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    input: Any = None,
) -> str:
    """Open a Run record without a context manager.

    Pairs with :func:`end_run` for sessions that span multiple processes or
    HTTP requests. Returns the run_id (caller-supplied or freshly minted).
    Between start_run and end_run any process can use ``join_run(run_id, ...)``
    to add spans.
    """
    return _get_client().start_run(
        agent_name,
        run_id=run_id,
        distinct_id=distinct_id,
        conversation_id=conversation_id,
        parent_run_id=parent_run_id,
        metadata=metadata,
        input=input,
    )


def end_run(
    run_id: str,
    *,
    output: Any = None,
    status: str = "ok",
    error_summary: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """Finalise a Run opened by :func:`start_run`."""
    _get_client().end_run(
        run_id,
        output=output,
        status=status,
        error_summary=error_summary,
        metadata=metadata,
    )


def tool(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
    *,
    kind: str = "tool",
) -> Any:
    """Wrap a function as a tool span — dual-form helper and decorator.

    Helper form::

        run_funnel_query = trodo.tool('run_funnel_query', run_funnel_query)

    Decorator form (backward-compatible)::

        @trodo.tool()
        def run_funnel_query(team_id, preset): ...

        @trodo.tool(name='custom-name')
        async def fetch(...): ...
    """
    # Deferred import: allow @trodo.tool() at import-time before init().
    from .otel.helpers import tool as _tool_helper
    return _tool_helper(name, fn, kind=kind)


def trace(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
) -> Any:
    """Wrap a function as a generic span — dual-form helper and decorator."""
    from .otel.helpers import trace as _trace_helper
    return _trace_helper(name, fn)


def llm(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
    *,
    model: Optional[str] = None,
    provider: Optional[str] = None,
    temperature: Optional[float] = None,
    extract_usage: Optional[Callable[[Any], Any]] = None,
) -> Any:
    """Wrap an LLM call — auto-captures tokens from OpenAI/Anthropic/Gemini
    response shapes. Dual-form helper and decorator."""
    from .otel.helpers import llm as _llm_helper
    return _llm_helper(
        name,
        fn,
        model=model,
        provider=provider,
        temperature=temperature,
        extract_usage=extract_usage,
    )


def retrieval(
    name: Any = None,
    fn: Optional[Callable[..., Any]] = None,
) -> Any:
    """Wrap a retriever / vector search as a kind='retrieval' span."""
    from .otel.helpers import retrieval as _retrieval_helper
    return _retrieval_helper(name, fn)


def get_tracer(name: str = "trodo") -> Any:
    """Return a raw OTel tracer — the Trodo processor is already subscribed.

    Use for advanced cases where you want to emit spans with the raw OTel
    API; they'll be captured and forwarded to Trodo like any other span.

        tracer = trodo.get_tracer('my.module')
        with tracer.start_as_current_span('custom') as sp:
            sp.set_attribute('foo', 'bar')
    """
    try:
        from opentelemetry import trace as _otel_trace  # type: ignore
    except Exception as e:  # pragma: no cover
        raise RuntimeError(
            "trodo.get_tracer requires the opentelemetry-api package"
        ) from e
    return _otel_trace.get_tracer(name)


def track_llm_call(
    *,
    model: Optional[str] = None,
    provider: Optional[str] = None,
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
    prompt: Any = None,
    completion: Any = None,
    temperature: Optional[float] = None,
    cost: Optional[float] = None,
    name: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """Record a one-shot LLM span for a raw-HTTP caller."""
    from .otel.helpers import track_llm_call as _fn
    _fn(
        model=model,
        provider=provider,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        prompt=prompt,
        completion=completion,
        temperature=temperature,
        cost=cost,
        name=name,
        metadata=metadata,
    )


def track_mcp(
    *,
    tool: str,
    distinct_id: str,
    input: Any = None,
    output: Any = None,
    error: Optional[str] = None,
    duration_ms: Optional[int] = None,
    session_id: Optional[str] = None,
    client_label: Optional[str] = None,
    attributes: Optional[Dict[str, Any]] = None,
    agent_name: str = "MCP",
    started_at: Optional[str] = None,
    ended_at: Optional[str] = None,
) -> str:
    """Record one MCP tool call as a runless span (no parent run).

    Use this from inside an MCP server's ``tools/call`` handler. The MCP
    server proxies tool calls but never sees the user's prompt or the
    LLM's final answer, so a parent run carries no analytical value.
    Each call to ``track_mcp`` writes one self-contained span row tagged
    with ``agent_name='MCP'`` (overridable), ``distinct_id`` (the user),
    and ``conversation_id`` (the MCP-Session-Id, auto-uuid'd if omitted).

    Required:
      tool: the tool name. Becomes ``name='tool.<tool>'``.
      distinct_id: end-user attribution (email or stable user id).

    Optional:
      input, output: full args + result. Truncated at 64KB by the SDK.
      error: if set, marks ``status='error'``.
      duration_ms: tool wall time. Defaults to 0 if omitted.
      session_id: the ``Mcp-Session-Id`` from the client; auto-uuid'd
                  if omitted (each call becomes its own grouping bucket).
      client_label: 'anthropic' / 'cursor' / 'chatgpt' / etc.; merged
                    into attributes as ``mcp_client_label``.
      attributes: free-form extras.
      agent_name: defaults to 'MCP'; override only for custom tags.
      started_at / ended_at: ISO 8601; defaults derived from now() and
                             ``duration_ms`` so callers usually skip them.

    Returns the span_id (str) for caller-side correlation/logging.
    """
    return _get_client().track_mcp(
        tool=tool,
        distinct_id=distinct_id,
        input=input,
        output=output,
        error=error,
        duration_ms=duration_ms,
        session_id=session_id,
        client_label=client_label,
        attributes=attributes,
        agent_name=agent_name,
        started_at=started_at,
        ended_at=ended_at,
    )


def feedback(
    run_id: str,
    *,
    satisfaction: Optional[str] = None,
    rating: Optional[float] = None,
    comment: Optional[str] = None,
    feedback: Optional[str] = None,
    distinct_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> ApiResult:
    """Attach feedback to a completed run."""
    return _get_client().feedback(
        run_id,
        satisfaction=satisfaction,
        rating=rating,
        comment=comment,
        feedback=feedback,
        distinct_id=distinct_id,
        metadata=metadata,
    )


# ----------------------------------------------------------------------------
# Cross-service propagation
# ----------------------------------------------------------------------------

def fastapi_middleware() -> Callable:
    """Return a FastAPI/Starlette middleware that auto-joins inbound runs.

    Usage:
        app = FastAPI()
        trodo.init(site_id='...')
        app.middleware('http')(trodo.fastapi_middleware())
    """
    return _get_client().fastapi_middleware()


def propagation_headers() -> Dict[str, str]:
    """Return outbound HTTP headers carrying the current run/span id."""
    from .otel.helpers import propagation_headers as _fn
    return _fn()


def current_run_id() -> Optional[str]:
    from .otel.wrap_agent import current_run_id as _fn
    return _fn()


def current_span_id() -> Optional[str]:
    from .otel.wrap_agent import current_span_id as _fn
    return _fn()
