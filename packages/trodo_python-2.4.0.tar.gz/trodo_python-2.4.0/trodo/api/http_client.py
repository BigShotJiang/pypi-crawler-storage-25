"""Synchronous HTTP client using requests."""

from __future__ import annotations

import sys
import time
from typing import Any, Callable, Dict, Optional

import requests

from ..types import ApiResult, EventPayload


class HttpClient:
    def __init__(
        self,
        api_base: str,
        site_id: str,
        timeout: int = 10,
        retries: int = 2,
        on_error: Optional[Callable[[Exception], None]] = None,
        debug: bool = False,
    ) -> None:
        self.api_base = api_base.rstrip("/")
        self.site_id = site_id
        self.timeout = timeout
        self.retries = retries
        self.on_error = on_error
        self.debug = debug
        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "X-Trodo-Site-Id": self.site_id,
        })

    def _log(self, *args: Any) -> None:
        if self.debug:
            sys.stderr.write(f"[trodo-python] {' '.join(str(a) for a in args)}\n")

    def _request(self, path: str, body: Dict[str, Any], attempt: int = 0) -> ApiResult:
        url = f"{self.api_base}{path}"
        self._log(f"POST {url}")
        try:
            resp = self._session.post(url, json=body, timeout=self.timeout)
            if resp.status_code >= 500 and attempt < self.retries:
                delay = 2 ** attempt
                self._log(f"Retry {attempt + 1} after {delay}s (status {resp.status_code})")
                time.sleep(delay)
                return self._request(path, body, attempt + 1)
            try:
                return resp.json()
            except Exception:
                return {}
        except Exception as exc:
            if attempt < self.retries:
                delay = 2 ** attempt
                self._log(f"Retry {attempt + 1} after {delay}s (network error)")
                time.sleep(delay)
                return self._request(path, body, attempt + 1)
            self._log(f"Error: {exc}")
            if self.on_error:
                self.on_error(exc)
            return {}

    def post_track(self, session_data: Dict[str, Any]) -> ApiResult:
        return self._request("/api/sdk/track", {"sessionData": session_data})

    def post_event(self, event: EventPayload) -> ApiResult:
        return self._request("/api/events", event.to_dict())

    def post_bulk_events(self, events: list) -> ApiResult:
        return self._request("/api/events/bulk", {"events": [e.to_dict() for e in events]})

    def post_identify(self, payload: Dict[str, Any]) -> ApiResult:
        return self._request("/api/sdk/identify", payload)

    def post_wallet_address(self, payload: Dict[str, Any]) -> ApiResult:
        return self._request("/api/sdk/wallet-address", payload)

    def post_reset(self, payload: Dict[str, Any]) -> ApiResult:
        return self._request("/api/sdk/reset", payload)

    def post_people(self, path: str, payload: Dict[str, Any]) -> ApiResult:
        return self._request(path, payload)

    def post_group(self, path: str, payload: Dict[str, Any]) -> ApiResult:
        return self._request(path, payload)

    # ------------------------------------------------------------------
    # Agent Runs (Lemma-style)
    # ------------------------------------------------------------------

    def post_run_ingest(self, payload: Dict[str, Any]) -> ApiResult:
        return self._request("/api/sdk/runs/ingest", payload)

    def post_run_start(self, payload: Dict[str, Any]) -> ApiResult:
        return self._request("/api/sdk/runs/start", payload)

    def post_run_end(self, run_id: str, payload: Dict[str, Any]) -> ApiResult:
        from urllib.parse import quote
        return self._request(f"/api/sdk/runs/{quote(run_id, safe='')}/end", payload)

    def post_spans_append(self, run_id: str, spans: list) -> ApiResult:
        from urllib.parse import quote
        return self._request(
            f"/api/sdk/runs/{quote(run_id, safe='')}/spans",
            {"spans": spans},
        )

    def post_runless_spans(self, spans: list) -> ApiResult:
        """Ingest spans with no parent run (e.g. MCP tool calls). Each span
        MUST carry distinct_id and agent_name; the server gates on that."""
        return self._request("/api/sdk/spans/append", {"spans": spans})

    def post_run_feedback(self, run_id: str, payload: Dict[str, Any]) -> ApiResult:
        from urllib.parse import quote
        return self._request(
            f"/api/sdk/runs/{quote(run_id, safe='')}/feedback",
            payload,
        )

    def post_otlp_traces(self, payload: Dict[str, Any]) -> ApiResult:
        return self._request("/api/sdk/otel/v1/traces", payload)
