"""Chat Completions adapters for OpenAI-compatible providers."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from openai import APIError, AsyncOpenAI

from mycode.messages import assistant_message, text_block, thinking_block, tool_use_block
from mycode.providers.base import (
    DEFAULT_REQUEST_TIMEOUT,
    ProviderAdapter,
    ProviderRequest,
    ProviderStreamEvent,
    dump_model,
    get_native_meta,
    load_document_block_payload,
    load_image_block_payload,
)
from mycode.utils import omit_none, parse_tool_arguments


@dataclass
class _ChatToolCallState:
    """Accumulate one streamed tool call from chat-completions deltas."""

    index: int
    tool_id: str | None = None
    name: str = ""
    arguments_text: str = ""


class OpenAIChatAdapter(ProviderAdapter):
    """Base adapter for Chat Completions style providers."""

    provider_id = "openai_chat"
    label = "OpenAI Chat Completions"
    default_base_url = "https://api.openai.com/v1"
    env_api_key_names = ("OPENAI_API_KEY",)
    auto_discoverable = False

    async def stream_turn(self, request: ProviderRequest) -> AsyncIterator[ProviderStreamEvent]:
        api_key = self.require_api_key(request.api_key)
        client = AsyncOpenAI(
            api_key=api_key,
            base_url=self.resolve_base_url(request.api_base),
            timeout=DEFAULT_REQUEST_TIMEOUT,
        )

        # Keep the streamed turn state local to this adapter so the wire-format
        # mapping stays readable in one file.
        tool_calls: dict[int, _ChatToolCallState] = {}
        text_parts: list[str] = []
        thinking_parts: list[str] = []
        thinking_native_meta: dict[str, Any] = {}
        response_id: str | None = None
        response_model: str | None = None
        finish_reason: str | None = None
        usage: Any = None

        try:
            stream = await client.chat.completions.create(**self._build_request_payload(request), stream=True)
            async for chunk in stream:
                response_id = response_id or getattr(chunk, "id", None)
                response_model = response_model or getattr(chunk, "model", None)

                if getattr(chunk, "usage", None) is not None:
                    usage = chunk.usage

                if not chunk.choices:
                    continue

                choice = chunk.choices[0]
                if choice.finish_reason:
                    finish_reason = choice.finish_reason

                delta = choice.delta
                reasoning_delta, reasoning_meta_update = self._extract_reasoning_delta(delta)
                if reasoning_meta_update:
                    thinking_native_meta.update(reasoning_meta_update)
                if reasoning_delta:
                    thinking_parts.append(reasoning_delta)
                    yield ProviderStreamEvent("thinking_delta", {"text": reasoning_delta})

                if delta.content:
                    text_parts.append(delta.content)
                    yield ProviderStreamEvent("text_delta", {"text": delta.content})

                for tool_call in delta.tool_calls or []:
                    index = tool_call.index or 0
                    state = tool_calls.setdefault(index, _ChatToolCallState(index=index))
                    if tool_call.id:
                        state.tool_id = tool_call.id
                    function = tool_call.function
                    if function is None:
                        continue
                    if function.name:
                        state.name = function.name
                    if function.arguments:
                        state.arguments_text += function.arguments
        except APIError as exc:
            raise ValueError(str(exc)) from exc

        blocks = []
        if thinking_parts or thinking_native_meta:
            blocks.append(
                thinking_block(
                    "".join(thinking_parts),
                    meta={"native": thinking_native_meta} if thinking_native_meta else None,
                )
            )
        if text_parts:
            blocks.append(text_block("".join(text_parts)))

        for index in sorted(tool_calls):
            state = tool_calls[index]
            raw_arguments = state.arguments_text
            parsed_arguments = parse_tool_arguments(raw_arguments)
            if parsed_arguments is None:
                tool_input = {}
                meta = {"native": {"raw_arguments": raw_arguments}}
            else:
                tool_input = parsed_arguments
                meta = None

            blocks.append(
                tool_use_block(
                    tool_id=state.tool_id or f"tool_call_{index}",
                    name=state.name,
                    input=tool_input,
                    meta=meta,
                )
            )

        raw_usage = dump_model(usage) or {}
        total_tokens = raw_usage.get("total_tokens") or None

        final_message = assistant_message(
            blocks,
            provider=self.provider_id,
            model=response_model or request.model,
            provider_message_id=response_id,
            stop_reason=finish_reason,
            total_tokens=total_tokens,
        )
        yield ProviderStreamEvent("message_done", {"message": final_message})

    def _build_request_payload(self, request: ProviderRequest) -> dict[str, Any]:
        messages = []
        if request.system:
            messages.append({"role": "system", "content": request.system})
        for message in self.prepare_messages(request):
            messages.extend(self._serialize_message(message))

        payload: dict[str, Any] = {
            "model": request.model,
            "messages": messages,
            "tools": [self._serialize_tool(tool) for tool in request.tools] or None,
            "tool_choice": "auto" if request.tools else None,
            "max_tokens": request.max_tokens,
            "stream_options": {"include_usage": True},
        }
        payload.update(self._build_provider_payload_overrides(request))
        return omit_none(payload)

    def _build_provider_payload_overrides(self, request: ProviderRequest) -> dict[str, Any]:
        del request
        return {}

    def _serialize_tool(self, tool: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": tool.get("name") or "",
                "description": tool.get("description") or "",
                "parameters": tool.get("input_schema") or {"type": "object", "properties": {}},
            },
        }

    def _serialize_message(self, message: dict[str, Any]) -> list[dict[str, Any]]:
        """Convert one canonical message into Chat Completions wire messages."""

        role = str(message.get("role") or "user")
        blocks = [block for block in message.get("content") or [] if isinstance(block, dict)]

        if role == "user":
            payload_messages: list[dict[str, Any]] = []
            has_media = any(block.get("type") in {"image", "document"} for block in blocks)
            if has_media:
                user_content: str | list[dict[str, Any]] | None = []
                for block in blocks:
                    block_type = block.get("type")
                    if block_type == "text":
                        text = str(block.get("text") or "")
                        if text:
                            user_content.append({"type": "text", "text": text})
                        continue
                    if block_type == "image":
                        mime_type, data = load_image_block_payload(block)
                        user_content.append(
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:{mime_type};base64,{data}"},
                            }
                        )
                        continue
                    if block_type == "document":
                        mime_type, data, name = load_document_block_payload(block)
                        user_content.append(
                            {
                                "type": "file",
                                "file": {
                                    "filename": name or "document.pdf",
                                    "file_data": f"data:{mime_type};base64,{data}",
                                },
                            }
                        )
                if not user_content:
                    user_content = None
            else:
                text_parts = [
                    str(block.get("text") or "")
                    for block in blocks
                    if block.get("type") == "text" and block.get("text")
                ]
                text = "\n".join(text_parts)
                user_content = text or None

            if user_content:
                payload_messages.append({"role": "user", "content": user_content})

            for block in blocks:
                if block.get("type") != "tool_result":
                    continue
                payload_messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": block.get("tool_use_id") or "",
                        "content": str(block.get("output") or ""),
                    }
                )
            return payload_messages

        if role != "assistant":
            return []

        text_parts = [str(block.get("text") or "") for block in blocks if block.get("type") == "text"]
        thinking_blocks = [block for block in blocks if block.get("type") == "thinking"]
        tool_use_blocks = [block for block in blocks if block.get("type") == "tool_use"]

        payload: dict[str, Any] = {
            "role": "assistant",
            "content": "\n".join(part for part in text_parts if part),
        }

        if tool_use_blocks:
            payload["tool_calls"] = [
                {
                    "id": block.get("id") or "",
                    "type": "function",
                    "function": {
                        "name": block.get("name") or "",
                        "arguments": json.dumps(
                            block.get("input") if isinstance(block.get("input"), dict) else {},
                            ensure_ascii=False,
                        ),
                    },
                }
                for block in tool_use_blocks
            ]

        if thinking_blocks:
            payload.update(self._serialize_reasoning(thinking_blocks))

        return [payload]

    def _serialize_reasoning(self, thinking_blocks: list[dict[str, Any]]) -> dict[str, Any]:
        """Replay canonical thinking through the provider's reasoning field.

        When the source provider did not record a native field name, default to
        `reasoning_content`, which is the common reasoning slot used by the
        OpenAI-compatible thinking providers we support.
        """

        thinking_text = "\n".join(str(block.get("text") or "") for block in thinking_blocks if block.get("text"))
        native_meta = get_native_meta(thinking_blocks[0])
        reasoning_field = str(native_meta.get("reasoning_field") or "")
        if reasoning_field == "reasoning_details":
            return {"reasoning_details": native_meta.get("reasoning_details") or []}
        if reasoning_field == "reasoning":
            return {"reasoning": thinking_text or None}
        if reasoning_field == "reasoning_content":
            return {"reasoning_content": thinking_text or None}
        return {"reasoning_content": thinking_text} if thinking_text else {}

    def _extract_reasoning_delta(self, delta: Any) -> tuple[str, dict[str, Any]]:
        # Third-party providers surface reasoning through non-standard extras.
        # We check both the delta root and model_extra to cover both patterns.
        # Known fields: reasoning, reasoning_content, reasoning_details.
        for source in (delta, getattr(delta, "model_extra", None) or {}):
            for field in ("reasoning", "reasoning_content", "reasoning_details"):
                if isinstance(source, dict):
                    if field not in source:
                        continue
                    value = source[field]
                elif hasattr(source, field):
                    value = getattr(source, field, None)
                else:
                    continue

                if field == "reasoning_details":
                    if not isinstance(value, list):
                        continue
                    text = "".join(str(item.get("text") or "") for item in value if isinstance(item, dict))
                    return text, {"reasoning_field": "reasoning_details", "reasoning_details": value}

                return (value if isinstance(value, str) else "", {"reasoning_field": field})

        return "", {}


class DeepSeekAdapter(OpenAIChatAdapter):
    """DeepSeek's OpenAI-compatible chat endpoint.

    V4 supports both non-thinking and thinking modes. The shared "none" effort
    disables thinking; other explicit efforts enable thinking and map to
    DeepSeek's high/max effort levels.
    """

    provider_id = "deepseek"
    label = "DeepSeek"
    default_base_url = "https://api.deepseek.com"
    env_api_key_names = ("DEEPSEEK_API_KEY",)
    default_models = ("deepseek-v4-pro", "deepseek-v4-flash")
    auto_discoverable = True
    supports_reasoning_effort = True

    def _build_provider_payload_overrides(self, request: ProviderRequest) -> dict[str, Any]:
        if request.reasoning_effort == "none":
            return {"extra_body": {"thinking": {"type": "disabled"}}}
        if request.reasoning_effort in {"low", "medium", "high", "xhigh"}:
            effort = "max" if request.reasoning_effort == "xhigh" else "high"
            return {
                "reasoning_effort": effort,
                "extra_body": {"thinking": {"type": "enabled"}},
            }
        return {}


class ZAIAdapter(OpenAIChatAdapter):
    """Z.AI's OpenAI-compatible chat endpoint.

    GLM models think by default. We still send the explicit thinking parameter
    so that clear_thinking=False preserves reasoning across multi-turn tool loops
    instead of resetting it on each turn.
    """

    provider_id = "zai"
    label = "Z.AI"
    default_base_url = "https://api.z.ai/api/paas/v4/"
    env_api_key_names = ("ZAI_API_KEY",)
    default_models = ("glm-5.1", "glm-5-turbo")
    auto_discoverable = True

    def _build_provider_payload_overrides(self, request: ProviderRequest) -> dict[str, Any]:
        return {"extra_body": {"thinking": {"type": "enabled", "clear_thinking": False}}}


class OpenRouterAdapter(OpenAIChatAdapter):
    """OpenRouter's OpenAI-compatible chat endpoint."""

    provider_id = "openrouter"
    label = "OpenRouter"
    default_base_url = "https://openrouter.ai/api/v1"
    env_api_key_names = ("OPENROUTER_API_KEY",)
    default_models = ("openrouter/auto",)
    auto_discoverable = True
    supports_reasoning_effort = True

    def _build_provider_payload_overrides(self, request: ProviderRequest) -> dict[str, Any]:
        if not request.reasoning_effort:
            return {}
        return {"extra_body": {"reasoning": {"effort": request.reasoning_effort}}}
