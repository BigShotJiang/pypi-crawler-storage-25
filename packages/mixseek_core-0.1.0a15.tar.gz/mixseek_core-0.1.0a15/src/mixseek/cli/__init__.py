"""CLI module for MixSeek."""
