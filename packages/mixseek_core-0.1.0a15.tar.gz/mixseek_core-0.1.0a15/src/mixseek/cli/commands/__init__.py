"""CLI commands for MixSeek."""
