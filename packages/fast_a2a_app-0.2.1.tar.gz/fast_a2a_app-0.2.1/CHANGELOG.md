# Changelog

## 0.2.0 — 2026-05-05

### Changed

- **A2A protocol upgraded to v1.0** — migrated from a2a-sdk pydantic API to
  protobuf-based a2a-sdk 1.0.x. All wire types (Task, Message, Part, Artifact,
  TaskState, Role) are now protobuf messages; Redis serialisation uses
  `MessageToJson` / `Parse` from `google.protobuf.json_format`.
- **`AgentCard` construction** — `url=` removed from `AgentCard`; replaced by
  `supported_interfaces=[AgentInterface(url=..., protocol_binding="JSONRPC")]`.
- **`TaskState` enum values** now use SCREAMING_SNAKE_CASE
  (`TASK_STATE_WORKING`, `TASK_STATE_COMPLETED`, etc.).
- **`Part` construction** simplified to `Part(text=text)` (protobuf oneof field).
- **`a2a.helpers`** — history/artifact/message construction now uses
  `new_task_from_user_message`, `new_text_artifact`, `new_text_message`.
- `DefaultRequestHandler` now requires `agent_card=` argument.
- `ContextAwareRequestContextBuilder.build()` updated to new SDK signature;
  uses `request_context.attach_related_task()` to inject history.
- **UI speaks A2A v1.0** — all JSON-RPC method names (`SendStreamingMessage`,
  `SendMessage`, `CancelTask`, `SubscribeToTask`, `GetTask`), role values
  (`ROLE_USER`, `ROLE_AGENT`), and state strings (`TASK_STATE_*`) updated.
  Requests now send `A2A-Version: 1.0` header required by the SDK.
- `max_tokens` → `max_completion_tokens` in all OpenAI API calls (required by
  newer model versions).
- `openai_client=` moved from `OpenAIModel(...)` to
  `OpenAIProvider(openai_client=...)` in pydantic-ai ≥ 0.2.

### Added

- `_sdk_compat.py` — startup monkey-patch fixing protobuf C-extension
  incompatibility in a2a-sdk 1.0.2 (`field.label` → `field.is_repeated`).
  Applied automatically on import; safe no-op on future SDK versions.
- **`SendMessage` support** — non-streaming path handled alongside streaming.
- **UI stream toggle** — checkbox in the input bar switches between streaming
  (`SendStreamingMessage`) and non-streaming (`SendMessage`) mode; preference
  persisted in `localStorage`.
- `examples/joke_agent/` and `examples/echo_agent/` added alongside the
  existing holiday planner.

### Fixed

- `load_dotenv()` moved before agent import in `joke_agent/main.py` so env vars
  are populated before module-level client construction.
- Azure credential provider wrapped in `async def` to satisfy newer OpenAI SDK
  which `await`s the `api_key` callable.
- Empty `chunk.choices` guard added to streaming loops (final usage chunk has
  no choices).
- Streaming token spacing: `collectTexts` now concatenates parts within one
  artifact before returning, preserving inter-token whitespace and preventing
  `join('\n\n')` from inserting paragraph breaks between individual tokens.

### Removed

- `ensure_context_marker` — no longer needed; `contextId` is a first-class
  field on the A2A `Message` and the SDK populates `context.context_id`
  directly. The `[cid:…]` text embedding is gone from both client and server.
- `enable_v0_3_compat=True` from `create_jsonrpc_routes` — no longer needed
  once the UI speaks v1.0.

---

## 0.1.0 — 2026-05-05

Initial release.

### Added

- `fast_a2a_app.server` — A2A protocol adapter extracted and cleaned from ppt-agent
  - `build_a2a_app()` factory assembling a Starlette ASGI app
  - `build_invoke()` / `build_stream_invoke()` wrappers for any async callable
  - `report_progress()` for live tool status updates via ContextVar
  - `RedisTaskStore` with context-id indexing and cross-instance cancel signals
  - `ConfigurableAgentExecutor` with `on_task_start` / `on_task_cancel` hooks
  - `ContextAwareRequestContextBuilder` for multi-turn history injection
  - `debug` parameter for controlling error verbosity
  - `redis_url` parameter replacing hard-coded config import
- `fast_a2a_app.ui` — Self-contained browser chat UI (no build step, no npm)
  - Streaming SSE with real-time progress indicator
  - localStorage persistence (context ID, transcript, active task)
  - Page-reload recovery via `SubscribeToTask` and `GetTask` fallback
  - Markdown rendering with DOMPurify sanitisation
  - Collapsible agent card panel
- `examples/holiday_planner/` — Full example application
  - Holiday planning agent with 4 tools: destinations, itinerary, budget, essentials
  - FastAPI app wiring agent + fast_a2a_app server + fast_a2a_app UI
