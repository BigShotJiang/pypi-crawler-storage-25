"""
main.py — Joke Agent

Demonstrates wiring a plain chat-completions agent (no AI framework) to
fast_a2a_app using build_invoke / build_stream_invoke.

Run with:
    uvicorn main:app --reload --port 8000
"""
from __future__ import annotations

import os

from dotenv import load_dotenv

load_dotenv()  # must run before agent.py reads env vars at module level

from a2a.types import AgentCapabilities, AgentCard, AgentInterface, AgentSkill  # noqa: E402
from fastapi import FastAPI  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402

from fast_a2a_app import a2a_ui, build_a2a_app, build_invoke, build_stream_invoke  # noqa: E402
from agent import run_joke_agent, stream_joke_agent  # noqa: E402

APP_BASE_URL = os.getenv("APP_BASE_URL", "http://localhost:8000")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
DEBUG = os.getenv("DEBUG", "true").lower() in ("1", "true", "yes")

app = FastAPI(
    title="Joke Agent",
    description="Tells jokes via the A2A protocol — powered by the Anthropic chat completions API",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["ops"])
async def health() -> dict:
    return {"status": "ok"}


agent_card = AgentCard(
    name="Joke Agent",
    description="Your AI stand-up comedian — ask for any kind of joke.",
    version="0.1.0",
    supported_interfaces=[AgentInterface(url=f"{APP_BASE_URL}/a2a/", protocol_binding="JSONRPC")],
    capabilities=AgentCapabilities(streaming=True),
    default_input_modes=["text"],
    default_output_modes=["text"],
    skills=[
        AgentSkill(
            id="tell_joke",
            name="Tell a joke",
            description=(
                "Tells a joke on any topic with explanation and comic timing. "
                "Supports puns, dad jokes, one-liners, programming humour, and more."
            ),
            tags=[],
        ),
    ],
)

app.mount(
    "/a2a",
    build_a2a_app(
        agent_card=agent_card,
        invoke=build_invoke(run_joke_agent),
        stream_invoke=build_stream_invoke(stream_joke_agent),
        redis_url=REDIS_URL,
        debug=DEBUG,
    ),
)

app.mount("/", a2a_ui)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
