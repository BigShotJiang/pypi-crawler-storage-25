"""
agent.py — Joke agent using Azure OpenAI chat completions

This example shows how fast_a2a_app works with *any* agent implementation —
no pydantic-ai required. The only contract is:

  - A non-streaming agent is an  ``async (prompt: str) -> str`` function.
  - A streaming agent is an      ``async (prompt: str) -> AsyncIterable[str]`` generator.

Both are then wrapped with ``build_invoke`` / ``build_stream_invoke``
and passed to ``build_a2a_app``.

Authentication:
  - Set AZURE_AI_KEY for API-key auth.
  - Leave AZURE_AI_KEY empty to use AzureCliCredential (managed identity,
    CLI login, environment credentials — whatever is available in the environment).
"""
from __future__ import annotations

import os
from collections.abc import AsyncIterable

from openai import AsyncOpenAI

# ── Azure OpenAI config ───────────────────────────────────────────────────────

AZURE_AI_ENDPOINT = os.environ.get("AZURE_AI_ENDPOINT", "")
AZURE_AI_DEPLOYMENT = os.environ.get("AZURE_AI_DEPLOYMENT", "gpt-4o")
AZURE_AI_KEY = os.environ.get("AZURE_AI_KEY", "")
# Set AZURE_AI_BASE_URL explicitly to override; otherwise AZURE_AI_ENDPOINT
# is used as-is (the full OpenAI-compatible path including any /openai/v1/).
AZURE_AI_BASE_URL = os.environ.get(
    "AZURE_AI_BASE_URL",
    f"{AZURE_AI_ENDPOINT.rstrip('/')}/" if AZURE_AI_ENDPOINT else "",
)


def _build_client() -> AsyncOpenAI:
    if AZURE_AI_KEY:
        api_key: str | object = AZURE_AI_KEY
    else:
        from azure.identity import AzureCliCredential, get_bearer_token_provider
        _sync_provider = get_bearer_token_provider(
            AzureCliCredential(), "https://ai.azure.com/.default"
        )
        async def api_key():  # type: ignore[misc]
            return _sync_provider()
    return AsyncOpenAI(
        base_url=AZURE_AI_BASE_URL,
        api_key=api_key,
    )


_client = _build_client()

_SYSTEM_PROMPT = """You are a stand-up comedian AI with impeccable comic timing.
Your specialty is telling jokes in a structured, satisfying format.

For every user message:
1. Tell a joke that fits the topic or mood they mention (or a random great one if they just say "tell me a joke").
2. Briefly explain why it's funny — the punchline mechanic, the wordplay, or the twist.
3. Offer to tell another or ask what type of joke they'd prefer next.

Types you excel at: puns, one-liners, self-deprecating tech humour, dad jokes,
absurdist humour, and observational comedy.

Keep it clean, clever, and upbeat. Never be offensive. Emojis are encouraged."""


# ── Non-streaming agent ───────────────────────────────────────────────────────


async def run_joke_agent(prompt: str) -> str:
    """Complete one turn — returns the full response as a string."""
    response = await _client.chat.completions.create(
        model=AZURE_AI_DEPLOYMENT,
        max_completion_tokens=512,
        messages=[
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return (response.choices[0].message.content or "").strip()


# ── Streaming agent ───────────────────────────────────────────────────────────


async def stream_joke_agent(prompt: str) -> AsyncIterable[str]:
    """Stream one turn — yields token chunks as they arrive from the API."""
    stream = await _client.chat.completions.create(
        model=AZURE_AI_DEPLOYMENT,
        max_completion_tokens=512,
        messages=[
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        stream=True,
    )
    async for chunk in stream:
        if not chunk.choices:
            continue
        text = chunk.choices[0].delta.content or ""
        if text:
            yield text
