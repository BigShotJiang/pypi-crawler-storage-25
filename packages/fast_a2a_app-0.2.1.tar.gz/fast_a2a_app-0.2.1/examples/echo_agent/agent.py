"""
agent.py — Echo agent (no LLM, no external dependencies)

The simplest possible fast_a2a_app agent: reflects the user's message back.
Demonstrates that fast_a2a_app works with pure Python — no AI framework, no API key.

  invoke        → returns the prompt as a single string
  stream_invoke → yields the prompt word by word to demonstrate real streaming
"""
from __future__ import annotations

import asyncio
from collections.abc import AsyncIterable


async def invoke(prompt: str) -> str:
    return f"Echo: {prompt}"


async def stream_invoke(prompt: str) -> AsyncIterable[str]:
    words = f"Echo: {prompt}".split(" ")
    for i, word in enumerate(words):
        yield word if i == len(words) - 1 else word + " "
        await asyncio.sleep(0.05)   # 50 ms delay to make streaming visible
