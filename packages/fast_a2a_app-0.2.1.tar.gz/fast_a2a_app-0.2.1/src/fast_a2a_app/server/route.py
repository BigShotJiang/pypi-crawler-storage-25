"""
route.py — Framework-agnostic A2A protocol adapter

A2A (Agent-to-Agent) is a JSON-RPC protocol for agent interoperability.
Clients send tasks via HTTP POST and receive responses as a single JSON
reply or as a stream of Server-Sent Events. This module is the adapter
layer between the A2A protocol and your agent: it speaks A2A on one side
and calls your agent function on the other.

PUBLIC SURFACE
--------------
build_a2a_app               — Assembles a Starlette ASGI application that
                              handles all A2A JSON-RPC methods. Mount it
                              at any prefix in your FastAPI application.

build_invoke                — Wraps any async (str) -> str function as a
                              non-streaming A2A invoke callable.

build_stream_invoke         — Wraps any async (str) -> AsyncIterable[str]
                              generator as a streaming A2A invoke callable.
                              Also sets up the report_progress() ContextVar.

ConfigurableAgentExecutor   — AgentExecutor that calls invoke or
                              stream_invoke, handles errors, and routes
                              cancel signals. Supports optional
                              on_task_start / on_task_cancel hooks.

ContextAwareRequestContextBuilder
                            — RequestContextBuilder that enriches each
                              request with prior-task history for the same
                              context_id, enabling multi-turn continuity.

HOW STREAMING WORKS
-------------------
build_stream_invoke wraps your generator in an asyncio.Queue relay and sets
the _progress_cb ContextVar before starting the generator task. Any code
called during streaming can therefore call report_progress() to push a
non-final working-status SSE event to the chat UI.

HOW CROSS-INSTANCE CANCELLATION WORKS
--------------------------------------
A cancel request may arrive at replica B while the task runs on replica A.
cancel() either fires asyncio.Task.cancel() locally (same instance) or
writes a short-lived Redis key (different instance). A background poller
on the executing instance detects it within _CANCEL_POLL_INTERVAL seconds.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import uuid
from collections.abc import AsyncIterable, Awaitable, Callable, Iterable

from a2a.helpers import (
    new_task_from_user_message,
    new_text_artifact,
    new_text_message,
)
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.agent_execution.simple_request_context_builder import (
    SimpleRequestContextBuilder,
)
from a2a.server.context import ServerCallContext
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes
from a2a.types import (
    AgentCard,
    Artifact,
    Part,
    Role,
    SendMessageRequest,
    Task,
    TaskArtifactUpdateEvent,
    TaskState,
    TaskStatus,
    TaskStatusUpdateEvent,
)
from starlette.routing import Router
import redis.asyncio as aioredis

from .task_store import A2ATaskStore, RedisTaskStore
from .utils import _progress_cb

log = logging.getLogger(__name__)

_TRANSIENT_AGENT_TEXTS = frozenset({"processing request..."})

# Seconds between cancel-signal polls. Lower = faster cancellation, more Redis traffic.
_CANCEL_POLL_INTERVAL = 2

# Sentinel distinguishing in-band progress strings from the final response text.
# Null bytes make accidental collisions with real LLM output virtually impossible.
_PROGRESS_PREFIX = "\x00p\x00"


# ── SSE / message helpers ─────────────────────────────────────────────────────


def _part_text(part: object) -> str | None:
    if hasattr(part, 'HasField') and not part.HasField('text'):
        return None
    text = getattr(part, 'text', None)
    if not text:
        return None
    return str(text).strip()


def _message_texts(message: object) -> list[str]:
    parts = getattr(message, "parts", None) or []
    return [text for part in parts if (text := _part_text(part))]


def _history_lines(messages: Iterable[object], role: str) -> list[str]:
    lines: list[str] = []
    for message in messages:
        texts = _message_texts(message)
        for text in texts:
            if role == "Agent" and text.lower() in _TRANSIENT_AGENT_TEXTS:
                continue
            lines.append(f"{role}: {text}")
    return lines


def _task_transcript(task: object) -> list[str]:
    lines: list[str] = []
    history = getattr(task, "history", None) or []
    for message in history:
        role = getattr(message, "role", 0)
        label = "User" if role == Role.ROLE_USER else "Agent"
        lines.extend(_history_lines([message], label))
    artifacts = getattr(task, "artifacts", None) or []
    for artifact in artifacts:
        for text in _message_texts(artifact):
            lines.append(f"Agent: {text}")
    return lines


def build_conversation_prefix(context: RequestContext) -> str:
    """Return the last 12 conversation lines across all related tasks as a prompt prefix."""
    related_tasks = getattr(context, "related_tasks", None) or []
    transcript_lines: list[str] = []
    for task in related_tasks:
        transcript_lines.extend(_task_transcript(task))
    if not transcript_lines:
        return ""
    recent_lines = transcript_lines[-12:]
    return "Conversation so far:\n" + "\n".join(recent_lines) + "\n\n"


# ── Request context builder ───────────────────────────────────────────────────


class ContextAwareRequestContextBuilder(SimpleRequestContextBuilder):
    """RequestContextBuilder that enriches each request with full conversation history."""

    def __init__(self, a2a_task_store: A2ATaskStore) -> None:
        super().__init__(
            should_populate_referred_tasks=True,
            task_store=a2a_task_store,
        )
        self._a2a_task_store = a2a_task_store

    async def build(
        self,
        context: ServerCallContext,
        params: SendMessageRequest | None = None,
        task_id: str | None = None,
        context_id: str | None = None,
        task: Task | None = None,
    ) -> RequestContext:
        request_context = await super().build(
            context=context,
            params=params,
            task_id=task_id,
            context_id=context_id,
            task=task,
        )

        effective_context_id = request_context.context_id
        if not effective_context_id:
            return request_context

        context_tasks = await self._a2a_task_store.list_by_context(
            effective_context_id,
            exclude_task_id=request_context.task_id,
        )
        known_task_ids = {rt.id for rt in request_context.related_tasks}
        for rt in context_tasks:
            if rt.id not in known_task_ids:
                request_context.attach_related_task(rt)

        return request_context


# ── Agent executor ────────────────────────────────────────────────────────────


class ConfigurableAgentExecutor(AgentExecutor):
    """A2A executor wrapping a callable agent with optional lifecycle hooks.

    Cross-instance cancellation: when a cancel request arrives at a different
    replica a signal is written to the shared task store. A background poller
    on the executing instance detects it and fires asyncio.Task.cancel().

    on_task_start(context_id)  — called before the agent starts work.
    on_task_cancel(context_id) — called when a cancel request is received.
    """

    def __init__(
        self,
        invoke: Callable[[str, RequestContext], Awaitable[str]],
        prompt_builder: Callable[[RequestContext], str] | None = None,
        stream_invoke: Callable[[str, RequestContext], AsyncIterable[str]]
        | None = None,
        on_task_start: Callable[[str], Awaitable[None]] | None = None,
        on_task_cancel: Callable[[str], Awaitable[None]] | None = None,
        a2a_task_store: A2ATaskStore | None = None,
        debug: bool = False,
    ) -> None:
        self._invoke = invoke
        self._prompt_builder = prompt_builder or self._default_prompt_builder
        self._stream_invoke = stream_invoke
        self._on_task_start = on_task_start
        self._on_task_cancel = on_task_cancel
        self._a2a_task_store = a2a_task_store
        self._debug = debug
        self._running_tasks: dict[str, asyncio.Task] = {}
        self._task_contexts: dict[str, str | None] = {}

    @staticmethod
    def _default_prompt_builder(context: RequestContext) -> str:
        return context.get_user_input()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        """Run the agent for one A2A task, emitting task/status/artifact events."""
        message = context.message
        if message is None:
            raise ValueError("A2A request did not include a message")

        task = context.current_task or new_task_from_user_message(message)
        task_id = task.id
        context_id = task.context_id or context.context_id

        if self._on_task_start and context_id:
            await self._on_task_start(context_id)

        self._task_contexts[task_id] = context_id

        await event_queue.enqueue_event(task)
        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                status=TaskStatus(
                    state=TaskState.TASK_STATE_WORKING,
                    message=new_text_message(
                        "Processing request...",
                        context_id=context_id,
                        task_id=task_id,
                    ),
                ),
            )
        )

        async def _do_work() -> None:
            try:
                prompt = self._prompt_builder(context)
                if self._stream_invoke is not None:
                    streamed = await self._stream_response(
                        prompt, context, event_queue, task_id, context_id
                    )
                    if streamed:
                        await event_queue.enqueue_event(
                            TaskStatusUpdateEvent(
                                task_id=task_id,
                                context_id=context_id,
                                status=TaskStatus(state=TaskState.TASK_STATE_COMPLETED),
                            )
                        )
                        return

                response_text = (await self._invoke(prompt, context)).strip()
            except Exception as exc:
                log.exception(
                    "A2A executor failed (task=%s context=%s)", task_id, context_id
                )
                with contextlib.suppress(Exception):
                    await event_queue.enqueue_event(
                        TaskStatusUpdateEvent(
                            task_id=task_id,
                            context_id=context_id,
                            status=TaskStatus(
                                state=TaskState.TASK_STATE_FAILED,
                                message=new_text_message(
                                    f"Agent execution failed: {exc}"
                                    if self._debug
                                    else "Something went wrong. Please try again.",
                                    context_id=context_id,
                                    task_id=task_id,
                                ),
                            ),
                        )
                    )
                return

            await event_queue.enqueue_event(
                TaskArtifactUpdateEvent(
                    task_id=task_id,
                    context_id=context_id,
                    artifact=new_text_artifact(name="result", text=response_text),
                )
            )
            await event_queue.enqueue_event(
                TaskStatusUpdateEvent(
                    task_id=task_id,
                    context_id=context_id,
                    status=TaskStatus(state=TaskState.TASK_STATE_COMPLETED),
                )
            )

        asyncio_task = asyncio.create_task(_do_work())
        self._running_tasks[task_id] = asyncio_task

        poll_task: asyncio.Task | None = None
        if self._a2a_task_store and task_id:
            store = self._a2a_task_store

            async def _poll_cancel_signal() -> None:
                while not asyncio_task.done():
                    try:
                        if await store.is_cancel_signalled(task_id):
                            asyncio_task.cancel()
                            return
                    except Exception:
                        log.debug("Cancel-signal poll error (task=%s)", task_id)
                    await asyncio.sleep(_CANCEL_POLL_INTERVAL)

            poll_task = asyncio.create_task(_poll_cancel_signal())

        try:
            await asyncio_task
        except asyncio.CancelledError:
            with contextlib.suppress(Exception):
                await event_queue.enqueue_event(
                    TaskStatusUpdateEvent(
                        task_id=task_id,
                        context_id=context_id,
                        status=TaskStatus(state=TaskState.TASK_STATE_CANCELED),
                    )
                )
        finally:
            if poll_task is not None:
                poll_task.cancel()
            self._running_tasks.pop(task_id, None)
            self._task_contexts.pop(task_id, None)

    async def _stream_response(
        self,
        prompt: str,
        context: RequestContext,
        event_queue: EventQueue,
        task_id: str,
        context_id: str | None,
    ) -> bool:
        """Drain stream_invoke, routing progress to working-status events and final text to an artifact."""
        assert self._stream_invoke is not None

        artifact_id = str(uuid.uuid4())
        chunk_count = 0
        pending_chunk: str | None = None

        async for chunk in self._stream_invoke(prompt, context):
            if not chunk:
                continue

            if chunk.startswith(_PROGRESS_PREFIX):
                progress_text = chunk[len(_PROGRESS_PREFIX):]
                await event_queue.enqueue_event(
                    TaskStatusUpdateEvent(
                        task_id=task_id,
                        context_id=context_id,
                        status=TaskStatus(
                            state=TaskState.TASK_STATE_WORKING,
                            message=new_text_message(
                                progress_text,
                                context_id=context_id,
                                task_id=task_id,
                            ),
                        ),
                    )
                )
                continue

            if pending_chunk is None:
                pending_chunk = chunk
                continue

            await self._enqueue_text_chunk(
                event_queue,
                task_id,
                context_id,
                pending_chunk,
                artifact_id=artifact_id,
                append=chunk_count > 0,
                last_chunk=False,
            )
            chunk_count += 1
            pending_chunk = chunk

        if pending_chunk is None:
            return False

        await self._enqueue_text_chunk(
            event_queue,
            task_id,
            context_id,
            pending_chunk,
            artifact_id=artifact_id,
            append=chunk_count > 0,
            last_chunk=True,
        )
        return True

    async def _enqueue_text_chunk(
        self,
        event_queue: EventQueue,
        task_id: str,
        context_id: str | None,
        text: str,
        *,
        artifact_id: str,
        append: bool,
        last_chunk: bool,
    ) -> None:
        await event_queue.enqueue_event(
            TaskArtifactUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                artifact=Artifact(
                    artifact_id=artifact_id,
                    name="result",
                    parts=[Part(text=text)],
                ),
                append=append,
                last_chunk=last_chunk,
            )
        )

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        """Cancel directly if running on this instance, or via Redis signal for another replica."""
        task_id = context.task_id or ""
        context_id = (
            getattr(context, "context_id", None)
            or self._task_contexts.get(task_id)
        )

        if self._on_task_cancel and context_id:
            await self._on_task_cancel(context_id)

        running = self._running_tasks.get(task_id)
        if running and not running.done():
            running.cancel()
        elif self._a2a_task_store and task_id:
            with contextlib.suppress(Exception):
                await self._a2a_task_store.signal_cancel(task_id)

        await event_queue.enqueue_event(
            TaskStatusUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                status=TaskStatus(state=TaskState.TASK_STATE_CANCELED),
            )
        )


# ── Prompt building helpers ───────────────────────────────────────────────────


def _build_prompt_with_history(context: RequestContext) -> str:
    user_input = context.get_user_input()
    return build_conversation_prefix(context) + user_input


# ── Public factory functions ──────────────────────────────────────────────────


def build_invoke(
    run: Callable[[str], Awaitable[str]],
) -> Callable[[str, RequestContext], Awaitable[str]]:
    """Wrap any ``async (prompt: str) -> str`` function as a non-streaming A2A invoke.

    Works with any AI framework or plain API call::

        async def my_agent(prompt: str) -> str:
            resp = await client.chat.completions.create(...)
            return resp.choices[0].message.content

        invoke=build_invoke(my_agent)
    """

    async def _invoke(prompt: str, context: RequestContext) -> str:
        return await run(prompt)

    return _invoke


def build_stream_invoke(
    run: Callable[[str], AsyncIterable[str]],
) -> Callable[[str, RequestContext], AsyncIterable[str]]:
    """Wrap any ``async (prompt: str) -> AsyncIterable[str]`` generator as a streaming A2A invoke.

    Works with any AI framework or plain streaming API call::

        async def my_agent(prompt: str) -> AsyncIterable[str]:
            async with client.messages.stream(...) as stream:
                async for chunk in stream.text_stream:
                    yield chunk

        stream_invoke=build_stream_invoke(my_agent)

    The wrapper sets up the ``report_progress()`` ContextVar so any code called
    during streaming can push live status updates to the chat UI — regardless of
    which AI framework (or none) your agent uses.
    """

    async def _stream(prompt: str, context: RequestContext) -> AsyncIterable[str]:
        _DONE = object()
        queue: asyncio.Queue = asyncio.Queue()
        error_holder: list[BaseException | None] = [None]

        def _on_progress(msg: str) -> None:
            queue.put_nowait(_PROGRESS_PREFIX + msg)

        token = _progress_cb.set(_on_progress)

        async def _run() -> None:
            try:
                async for chunk in run(prompt):
                    if chunk:
                        queue.put_nowait(chunk)
            except asyncio.CancelledError as exc:
                error_holder[0] = exc
            except Exception as exc:
                error_holder[0] = exc
            finally:
                queue.put_nowait(_DONE)

        run_task = asyncio.create_task(_run())
        try:
            while True:
                item = await queue.get()
                if item is _DONE:
                    break
                yield item
        finally:
            _progress_cb.reset(token)
            if not run_task.done():
                run_task.cancel()

        exc = error_holder[0]
        if exc is not None:
            raise exc

    return _stream


def build_a2a_app(
    *,
    agent_card: AgentCard,
    invoke: Callable[[str, RequestContext], Awaitable[str]],
    stream_invoke: Callable[[str, RequestContext], AsyncIterable[str]]
    | None = None,
    prompt_builder: Callable[[RequestContext], str] = _build_prompt_with_history,
    on_task_start: Callable[[str], Awaitable[None]] | None = None,
    on_task_cancel: Callable[[str], Awaitable[None]] | None = None,
    a2a_task_store: A2ATaskStore | None = None,
    redis_client: aioredis.Redis | None = None,
    redis_url: str = "redis://localhost:6379",
    debug: bool = False,
):
    """Assemble a Starlette ASGI app handling all A2A JSON-RPC methods.

    Mount at a path prefix in FastAPI::

        from a2a.types import AgentCard, AgentCapabilities, AgentInterface, AgentSkill

        card = AgentCard(
            name="My Agent",
            description="Does cool things",
            version="1.0.0",
            supported_interfaces=[AgentInterface(url="http://localhost:8000/a2a/", protocol_binding="JSONRPC")],
            capabilities=AgentCapabilities(streaming=True),
            default_input_modes=["text"],
            default_output_modes=["text"],
            skills=[AgentSkill(id="my_skill", name="My skill", description="...", tags=[])],
        )

        app.mount("/a2a", build_a2a_app(
            agent_card=card,
            invoke=build_invoke(my_invoke_fn),
            stream_invoke=build_stream_invoke(my_stream_fn),
        ))

    Supply ``a2a_task_store`` or ``redis_client`` to use an existing store or
    Redis connection. When neither is provided a ``RedisTaskStore`` is created
    from ``redis_url``.

    Set ``debug=True`` to include exception details in failure messages.
    """
    resolved_store: A2ATaskStore = a2a_task_store or RedisTaskStore(
        redis_client or aioredis.from_url(redis_url, decode_responses=True)
    )
    executor = ConfigurableAgentExecutor(
        invoke=invoke,
        prompt_builder=prompt_builder,
        stream_invoke=stream_invoke,
        on_task_start=on_task_start,
        on_task_cancel=on_task_cancel,
        a2a_task_store=resolved_store,
        debug=debug,
    )
    request_handler = DefaultRequestHandler(
        agent_executor=executor,
        task_store=resolved_store,
        agent_card=agent_card,
        request_context_builder=ContextAwareRequestContextBuilder(resolved_store),
    )
    return Router(routes=(
        create_agent_card_routes(agent_card) +
        create_jsonrpc_routes(request_handler, rpc_url="/")
    ))
