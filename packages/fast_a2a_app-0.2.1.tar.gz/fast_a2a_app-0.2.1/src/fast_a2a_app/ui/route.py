"""Lightweight A2A chat UI — mount at "/" in your FastAPI app."""
from __future__ import annotations

from pathlib import Path

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import HTMLResponse
from starlette.routing import Route

_HTML_PATH = Path(__file__).parent / "index.html"


async def _index(_: Request) -> HTMLResponse:
    return HTMLResponse(_HTML_PATH.read_text())


a2a_ui = Starlette(routes=[Route("/", _index)])
