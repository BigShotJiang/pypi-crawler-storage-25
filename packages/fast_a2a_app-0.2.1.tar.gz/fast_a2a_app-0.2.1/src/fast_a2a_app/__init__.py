"""
fast_a2a_app — Drop-in A2A server and chat UI for any FastAPI application.

fast_a2a_app is framework-agnostic: it works with pydantic-ai, LangChain,
LlamaIndex, plain Anthropic/OpenAI API calls, or any custom logic that
can expose an ``async (str) -> str`` function or an async generator.

Typical usage::

    from fastapi import FastAPI
    from a2a.types import AgentCapabilities, AgentCard, AgentInterface
    from fast_a2a_app import a2a_ui, build_a2a_app, build_invoke, build_stream_invoke

    app = FastAPI()

    agent_card = AgentCard(
        name="My Agent",
        description="Does cool things",
        version="1.0.0",
        supported_interfaces=[AgentInterface(
            url="http://localhost:8000/a2a/",
            protocol_binding="JSONRPC",
        )],
        capabilities=AgentCapabilities(streaming=True),
        default_input_modes=["text"],
        default_output_modes=["text"],
    )

    app.mount("/a2a", build_a2a_app(
        agent_card=agent_card,
        invoke=build_invoke(my_agent_fn),
        stream_invoke=build_stream_invoke(my_streaming_agent_fn),
    ))

    app.mount("/", a2a_ui)

Call ``report_progress("step 2/5…")`` from anywhere inside your agent
(including tools) to push live status updates to the chat UI.
"""
from . import _sdk_compat as _sdk_compat
_sdk_compat.apply()

from .server import (
    A2ATaskStore,
    ConfigurableAgentExecutor,
    ContextAwareRequestContextBuilder,
    RedisTaskStore,
    build_a2a_app,
    build_invoke,
    build_stream_invoke,
    build_conversation_prefix,
    report_progress,
)
from .ui import a2a_ui

__version__ = "0.2.0"

__all__ = [
    # Server
    "build_a2a_app",
    "build_invoke",
    "build_stream_invoke",
    "build_conversation_prefix",
    "ConfigurableAgentExecutor",
    "ContextAwareRequestContextBuilder",
    "A2ATaskStore",
    "RedisTaskStore",
    "report_progress",
    # UI
    "a2a_ui",
    # Meta
    "__version__",
]
