"""FastEdit MCP server package."""
