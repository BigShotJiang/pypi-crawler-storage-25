VERSION = "0.32.1"
VENDOR = "qtoggle/qtoggleserver"
