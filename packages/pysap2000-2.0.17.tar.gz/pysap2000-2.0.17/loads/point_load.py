# -*- coding: utf-8 -*-
"""
point_load.py - Point loads

Includes:
- Dataclasses: PointLoadForceData, PointLoadDisplData
- Functions: set_point_load_force, get_point_load_force, delete_point_load_force, ...

SAP2000 API:
- PointObj.SetLoadForce / GetLoadForce / DeleteLoadForce
- PointObj.SetLoadDispl / GetLoadDispl / DeleteLoadDispl
"""

from dataclasses import dataclass, field
from typing import List, Tuple
from enum import IntEnum

from PySap2000.com_helper import com_ret, com_data


# ==================== Enums ====================

class PointLoadItemType(IntEnum):
    """Load assignment target type."""
    OBJECT = 0              # Single object
    GROUP = 1               # Group
    SELECTED_OBJECTS = 2    # Selected objects


# ==================== Dataclasses ====================

@dataclass
class PointLoadForceData:
    """Point force load data (returned by getter methods)."""
    point_name: str = ""
    load_pattern: str = ""
    f1: float = 0.0
    f2: float = 0.0
    f3: float = 0.0
    m1: float = 0.0
    m2: float = 0.0
    m3: float = 0.0
    csys: str = "Global"
    lc_step: int = 0


@dataclass
class PointLoadDisplData:
    """Point displacement load data (returned by getter methods)."""
    point_name: str = ""
    load_pattern: str = ""
    u1: float = 0.0
    u2: float = 0.0
    u3: float = 0.0
    r1: float = 0.0
    r2: float = 0.0
    r3: float = 0.0
    csys: str = "Global"
    lc_step: int = 0


# ==================== Functional API ====================

def set_point_load_force(
    model,
    point_name: str,
    load_pattern: str,
    forces: Tuple[float, float, float, float, float, float],
    replace: bool = False,
    csys: str = "Global",
    item_type: PointLoadItemType = PointLoadItemType.OBJECT
) -> int:
    """
    Set point force load.

    Args:
        model: SapModel object
        point_name: Point name
        load_pattern: Load pattern name (must already exist)
        forces: Forces and moments `(F1, F2, F3, M1, M2, M3)`
            - F1, F2, F3: Force [F]
            - M1, M2, M3: Moment [FL]
        replace: `True` replaces existing loads, `False` adds to existing loads
        csys: Coordinate system name
        item_type: Operation scope
    
    Returns:
        `0` on success
    
    Example:
        set_point_load_force(model, "1", "Dead", (0, 0, -100, 0, 0, 0))
    """
    f_list = list(forces)
    while len(f_list) < 6:
        f_list.append(0.0)
    
    result = model.PointObj.SetLoadForce(
        str(point_name), load_pattern, f_list[:6], replace, csys, int(item_type)
    )
    # Parse return value
    return com_ret(result)


def get_point_load_force(
    model,
    point_name: str,
    item_type: PointLoadItemType = PointLoadItemType.OBJECT
) -> List[PointLoadForceData]:
    """
    Get point force loads.

    Args:
        model: SapModel object
        point_name: Point name
        item_type: Operation scope
    
    Returns:
        List of `PointLoadForceData` objects
    
    Example:
        loads = get_point_load_force(model, "1")
        for load in loads:
            print(f"{load.load_pattern}: F3={load.f3}")
    """
    loads = []
    try:
        result = model.PointObj.GetLoadForce(
            str(point_name), 0, [], [], [], [], [], [], [], [], [], [], int(item_type)
        )
        num_items = com_data(result, 0, 0)
        if num_items > 0:
            point_names = com_data(result, 1)
            load_pats = com_data(result, 2)
            lc_steps = com_data(result, 3)
            csys_list = com_data(result, 4)
            f1_list = com_data(result, 5)
            f2_list = com_data(result, 6)
            f3_list = com_data(result, 7)
            m1_list = com_data(result, 8)
            m2_list = com_data(result, 9)
            m3_list = com_data(result, 10)
            
            for i in range(num_items):
                loads.append(PointLoadForceData(
                    point_name=point_names[i] if point_names else str(point_name),
                    load_pattern=load_pats[i] if load_pats else "",
                    f1=f1_list[i] if f1_list else 0.0,
                    f2=f2_list[i] if f2_list else 0.0,
                    f3=f3_list[i] if f3_list else 0.0,
                    m1=m1_list[i] if m1_list else 0.0,
                    m2=m2_list[i] if m2_list else 0.0,
                    m3=m3_list[i] if m3_list else 0.0,
                    csys=csys_list[i] if csys_list else "Global",
                    lc_step=lc_steps[i] if lc_steps else 0
                ))
    except Exception:
        pass
    return loads


def delete_point_load_force(
    model,
    point_name: str,
    load_pattern: str,
    item_type: PointLoadItemType = PointLoadItemType.OBJECT
) -> int:
    """
    Delete point force load.

    Args:
        model: SapModel object
        point_name: Point name
        load_pattern: Load pattern name
        item_type: Operation scope
    
    Returns:
        `0` on success
    """
    return model.PointObj.DeleteLoadForce(str(point_name), load_pattern, int(item_type))


def set_point_load_displ(
    model,
    point_name: str,
    load_pattern: str,
    displacements: Tuple[float, float, float, float, float, float],
    replace: bool = False,
    csys: str = "Global",
    item_type: PointLoadItemType = PointLoadItemType.OBJECT
) -> int:
    """
    Set point displacement load (ground displacement / support settlement).

    Args:
        model: SapModel object
        point_name: Point name
        load_pattern: Load pattern name
        displacements: Displacements and rotations `(U1, U2, U3, R1, R2, R3)`
            - U1, U2, U3: Displacement [L]
            - R1, R2, R3: Rotation [rad]
        replace: `True` replaces existing values, `False` accumulates
        csys: Coordinate system name
        item_type: Operation scope
    
    Returns:
        `0` on success
    
    Example:
        set_point_load_displ(model, "1", "Settlement", (0, 0, -0.01, 0, 0, 0))
    """
    d_list = list(displacements)
    while len(d_list) < 6:
        d_list.append(0.0)
    
    result = model.PointObj.SetLoadDispl(
        str(point_name), load_pattern, d_list[:6], replace, csys, int(item_type)
    )
    # Parse return value
    return com_ret(result)


def get_point_load_displ(
    model,
    point_name: str,
    item_type: PointLoadItemType = PointLoadItemType.OBJECT
) -> List[PointLoadDisplData]:
    """
    Get point displacement loads.

    Args:
        model: SapModel object
        point_name: Point name
        item_type: Operation scope
    
    Returns:
        List of `PointLoadDisplData` objects
    """
    loads = []
    try:
        result = model.PointObj.GetLoadDispl(
            str(point_name), 0, [], [], [], [], [], [], [], [], [], [], int(item_type)
        )
        num_items = com_data(result, 0, 0)
        if num_items > 0:
            point_names = com_data(result, 1)
            load_pats = com_data(result, 2)
            lc_steps = com_data(result, 3)
            csys_list = com_data(result, 4)
            u1_list = com_data(result, 5)
            u2_list = com_data(result, 6)
            u3_list = com_data(result, 7)
            r1_list = com_data(result, 8)
            r2_list = com_data(result, 9)
            r3_list = com_data(result, 10)
            
            for i in range(num_items):
                loads.append(PointLoadDisplData(
                    point_name=point_names[i] if point_names else str(point_name),
                    load_pattern=load_pats[i] if load_pats else "",
                    u1=u1_list[i] if u1_list else 0.0,
                    u2=u2_list[i] if u2_list else 0.0,
                    u3=u3_list[i] if u3_list else 0.0,
                    r1=r1_list[i] if r1_list else 0.0,
                    r2=r2_list[i] if r2_list else 0.0,
                    r3=r3_list[i] if r3_list else 0.0,
                    csys=csys_list[i] if csys_list else "Global",
                    lc_step=lc_steps[i] if lc_steps else 0
                ))
    except Exception:
        pass
    return loads


def delete_point_load_displ(
    model,
    point_name: str,
    load_pattern: str,
    item_type: PointLoadItemType = PointLoadItemType.OBJECT
) -> int:
    """
    Delete point displacement load.

    Args:
        model: SapModel object
        point_name: Point name
        load_pattern: Load pattern name
        item_type: Operation scope
    
    Returns:
        `0` on success
    """
    return model.PointObj.DeleteLoadDispl(str(point_name), load_pattern, int(item_type))
