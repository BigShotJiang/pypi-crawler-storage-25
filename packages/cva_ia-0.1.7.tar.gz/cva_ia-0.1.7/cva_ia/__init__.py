def display_code(choice):
    try:
        module = __import__(f"cva_ia.p{choice}", fromlist=["display_code"])
        return module.display_code()   # ✅ RETURN
    except Exception:
        return "Invalid choice. Use 1 to 10."