from setuptools import setup, find_packages

setup(
    name="cva-ia",
    version="0.1.7",
    packages=find_packages(),
)