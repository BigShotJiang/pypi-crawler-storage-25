import React, { useEffect, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { fetchProviders, ProviderInfo } from './api.js';

const PROVIDER_LABELS: Record<string, string> = {
  'openai':      'OpenAI  (GPT-4, o1, Codex)',
  'anthropic':   'Anthropic  (Claude)',
  'ollama':      'Ollama  (local models)',
  'openrouter':  'OpenRouter  (100+ models)',
  'claude-cli':  'Claude Code CLI  (no API key needed)',
};

interface Props {
  onSelect: (provider: ProviderInfo) => void;
  onCancel: () => void;
}

export function ProviderSelect({ onSelect, onCancel }: Props) {
  const [providers, setProviders] = useState<ProviderInfo[]>([]);
  const [idx, setIdx] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProviders()
      .then((d) => setProviders(d.providers))
      .catch((e: unknown) => setError(String(e)))
      .finally(() => setLoading(false));
  }, []);

  useInput((_ch, key) => {
    if (key.escape) { onCancel(); return; }
    if (key.upArrow)   setIdx((i) => Math.max(0, i - 1));
    if (key.downArrow) setIdx((i) => Math.min(providers.length - 1, i + 1));
    if (key.return && providers[idx]) onSelect(providers[idx]!);
  });

  if (loading) return <Box paddingX={2}><Text dimColor>Loading providers…</Text></Box>;
  if (error)   return <Box paddingX={2}><Text color="red">{error}</Text></Box>;

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> Select provider</Text>
      <Text dimColor> ──────────────────────────────</Text>

      {providers.map((p, i) => {
        const selected = i === idx;
        const authBadge = p.active
          ? <Text color="cyan"> ← active</Text>
          : p.oauth
          ? <Text color="green">  oauth</Text>
          : p.authenticated
          ? <Text color="green">  ✓</Text>
          : <Text color="yellow">  not configured</Text>;

        return (
          <Box key={p.name}>
            <Text color={selected ? 'cyan' : undefined} bold={selected}>
              {selected ? ' ❯ ' : '   '}
              {(PROVIDER_LABELS[p.name] ?? p.name).padEnd(38)}
            </Text>
            {authBadge}
          </Box>
        );
      })}

      <Box marginTop={1}>
        <Text dimColor> ↑↓ navigate  enter configure  esc cancel</Text>
      </Box>
    </Box>
  );
}
