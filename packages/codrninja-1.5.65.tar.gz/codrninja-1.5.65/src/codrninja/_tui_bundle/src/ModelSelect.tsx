import React, { useEffect, useState } from 'react';
import { Box, Text, useInput } from 'ink';
import { fetchModels, setModel, setSessionModel } from './api.js';

interface Props {
  currentModel: string;
  currentProvider: string;
  sessionName?: string;
  onSelect: (model: string, provider: string) => void;
  onCancel: () => void;
}

type Screen = 'list' | 'scope';

const SCOPE_OPTIONS = ['This session only', 'Set as global default'];

// Ollama multi-server format: "display (host)|actual_model_value"
function modelDisplay(m: string): string { const i = m.indexOf('|'); return i >= 0 ? m.slice(0, i).trim() : m; }
function modelValue(m: string): string   { const i = m.indexOf('|'); return i >= 0 ? m.slice(i + 1) : m; }

export function ModelSelect({ currentModel, currentProvider, sessionName, onSelect, onCancel }: Props) {
  const [models, setModels] = useState<string[]>([]);
  const [idx, setIdx] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('');
  const [screen, setScreen] = useState<Screen>('list');
  const [pending, setPending] = useState('');
  const [scopeIdx, setScopeIdx] = useState(1);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchModels()
      .then((data) => {
        setModels(data.models);
        // models may be "display (host)|value" for multi-server Ollama
        const cur = data.models.findIndex((m) => modelValue(m) === currentModel || m === currentModel);
        if (cur >= 0) setIdx(cur);
      })
      .catch((e: unknown) => setError(String(e)))
      .finally(() => setLoading(false));
  }, [currentModel]);

  const filtered = models.filter((m) =>
    filter ? modelDisplay(m).toLowerCase().includes(filter.toLowerCase()) : true,
  );

  function confirmModel(raw: string, asDefault: boolean) {
    const value = modelValue(raw);
    setSaving(true);
    if (sessionName) {
      setSessionModel(sessionName, value, undefined, asDefault)
        .then((res) => onSelect(res.model, res.provider))
        .catch(() => onSelect(value, currentProvider));
    } else {
      setModel(value)
        .then((res) => onSelect(res.model, res.provider))
        .catch(() => onSelect(value, currentProvider));
    }
  }

  useInput((ch, key) => {
    if (saving) return;

    if (screen === 'scope') {
      if (key.escape) { setScreen('list'); return; }
      if (key.upArrow)   setScopeIdx((i) => Math.max(0, i - 1));
      if (key.downArrow) setScopeIdx((i) => Math.min(SCOPE_OPTIONS.length - 1, i + 1));
      if (key.return) {
        confirmModel(pending, scopeIdx === 1);
      }
      return;
    }

    // list screen
    if (key.escape) { onCancel(); return; }

    if (key.upArrow) {
      setIdx((i) => Math.max(0, i - 1));
      return;
    }
    if (key.downArrow) {
      setIdx((i) => Math.min(filtered.length - 1, i + 1));
      return;
    }
    if (key.return) {
      const chosen = filtered[idx];
      if (chosen) {
        if (sessionName) {
          setPending(chosen);
          setScopeIdx(0);
          setScreen('scope');
        } else {
          confirmModel(chosen, false);
        }
      }
      return;
    }
    if (key.backspace || key.delete) {
      setFilter((f) => f.slice(0, -1));
      setIdx(0);
    } else if (ch && !key.ctrl && !key.meta) {
      setFilter((f) => f + ch);
      setIdx(0);
    }
  });

  if (loading) {
    return (
      <Box paddingX={2}><Text dimColor>Loading models…</Text></Box>
    );
  }

  if (error) {
    return (
      <Box flexDirection="column" paddingX={2}>
        <Text color="red">Could not load models: {error}</Text>
        <Text dimColor>esc to go back</Text>
      </Box>
    );
  }

  if (screen === 'scope') {
    return (
      <Box flexDirection="column" paddingX={2} paddingY={1}>
        <Text bold color="cyan"> Apply model change</Text>
        <Text dimColor> ──────────────────────────────</Text>
        <Text dimColor> Selected: <Text color="white">{modelDisplay(pending)}</Text></Text>
        <Box flexDirection="column" marginTop={1}>
          {SCOPE_OPTIONS.map((opt, i) => (
            <Box key={opt}>
              <Text color={i === scopeIdx ? 'cyan' : undefined} bold={i === scopeIdx}>
                {i === scopeIdx ? ' ❯ ' : '   '}{opt}
              </Text>
            </Box>
          ))}
        </Box>
        <Box marginTop={1}><Text dimColor> ↑↓ navigate  enter confirm  esc back</Text></Box>
      </Box>
    );
  }

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>
      <Text bold color="cyan"> Select model</Text>
      <Text dimColor> Current: {currentModel}  ({currentProvider})</Text>
      {sessionName && <Text dimColor> Session: {sessionName}</Text>}
      <Text dimColor> ──────────────────────────────</Text>

      {/* filter input */}
      <Box marginBottom={1}>
        <Text color="cyan"> Filter: </Text>
        <Text>{filter}<Text color="cyan">_</Text></Text>
      </Box>

      {filtered.length === 0 && (
        <Text dimColor> No models match.</Text>
      )}

      {filtered.slice(0, 16).map((m, i) => {
        const selected = i === idx;
        const isCurrent = modelValue(m) === currentModel || m === currentModel;
        return (
          <Box key={m}>
            <Text color={selected ? 'cyan' : undefined} bold={selected}>
              {selected ? ' ❯ ' : '   '}
              {modelDisplay(m)}
            </Text>
            {isCurrent && <Text dimColor>  ← current</Text>}
          </Box>
        );
      })}

      {filtered.length > 16 && (
        <Text dimColor>  … {filtered.length - 16} more (type to filter)</Text>
      )}

      <Box marginTop={1}>
        <Text dimColor> ↑↓ navigate  enter select  type to filter  esc cancel</Text>
      </Box>
    </Box>
  );
}
