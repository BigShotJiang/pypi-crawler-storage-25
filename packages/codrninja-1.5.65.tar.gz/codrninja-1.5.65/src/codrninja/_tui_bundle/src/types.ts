export type Screen = 'sessions' | 'chat' | 'model-select' | 'provider-select' | 'provider-config';

export interface ToolCall {
  call_id: string;
  tool: string;
  args: Record<string, unknown>;
  step: number;
  output?: string;
  success?: boolean;
  done: boolean;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'tool' | 'pre_tool';
  content: string;
  streaming?: boolean;
  toolData?: ToolCall;
  tokens?: number;
  tokensIn?: number;
  isThinkingComplete?: boolean;
  thinkingMs?: number;
  thinkingLabel?: string;
  thinkingIter?: number;
  thinkingTools?: number;
  isModelSwitch?: boolean;
  switchModel?: string;
  switchProvider?: string;
  contextData?: {
    tokIn: number;
    tokOut: number;
    maxCtx?: number;
    sessionName: string;
    provider: string;
    model: string;
    exchangeCount: number;
  };
}
