import React, { useEffect, useState } from 'react';
import { Box, Text } from 'ink';
import { ToolCall } from './types.js';

interface Props {
  call: ToolCall;
}

const SPIN = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'];

function trunc(s: string, n: number): string {
  return s.length > n ? s.slice(0, n) + '…' : s;
}

function shortPath(p: string): string {
  return p.replace(/^\/Users\/[^/]+/, '~').replace(/^\/root/, '~');
}

// ── Diff renderer for edit_file ──────────────────────────────────────────────

const MAX_DIFF_LINES = 8;

function DiffBlock({ oldText, newText }: { oldText: string; newText: string }) {
  const removed = oldText ? oldText.split('\n') : [];
  const added   = newText ? newText.split('\n') : [];
  // strip trailing empty from split
  const rem = removed[removed.length - 1] === '' ? removed.slice(0, -1) : removed;
  const add = added[added.length - 1]   === '' ? added.slice(0, -1)   : added;

  const summary = `${add.length > 0 ? `+${add.length}` : ''}${rem.length > 0 ? `  -${rem.length}` : ''}`;

  const diffLines: { sign: '-' | '+'; text: string }[] = [
    ...rem.map(l => ({ sign: '-' as const, text: l })),
    ...add.map(l => ({ sign: '+' as const, text: l })),
  ];

  const shown   = diffLines.slice(0, MAX_DIFF_LINES);
  const hidden  = diffLines.length - shown.length;

  return (
    <Box flexDirection="column" marginLeft={2}>
      <Box>
        <Text color="#555566">⎿  </Text>
        {rem.length > 0 && <Text color="red">-{rem.length} </Text>}
        {add.length > 0 && <Text color="green">+{add.length} </Text>}
        <Text dimColor>line{add.length + rem.length !== 1 ? 's' : ''}</Text>
      </Box>
      {shown.map((l, i) => (
        <Box key={i} marginLeft={3}>
          <Text color={l.sign === '-' ? 'red' : 'green'}>{l.sign} </Text>
          <Text color={l.sign === '-' ? '#cc6666' : '#66cc88'}>{trunc(l.text, 72)}</Text>
        </Box>
      ))}
      {hidden > 0 && (
        <Box marginLeft={3}>
          <Text dimColor>… +{hidden} more line{hidden !== 1 ? 's' : ''}</Text>
        </Box>
      )}
    </Box>
  );
}

// ── Output block for bash / generic tools ───────────────────────────────────

const MAX_OUTPUT_LINES = 6;

function OutputBlock({ output }: { output: string }) {
  const lines  = output.trim().split('\n').filter(l => l.trim() !== '');
  const shown  = lines.slice(0, MAX_OUTPUT_LINES);
  const hidden = lines.length - shown.length;
  return (
    <Box flexDirection="column" marginLeft={2}>
      <Box>
        <Text color="#555566">⎿  </Text>
        <Text dimColor>{trunc(shown[0] ?? '', 74)}</Text>
      </Box>
      {shown.slice(1).map((l, i) => (
        <Box key={i} marginLeft={5}>
          <Text dimColor>{trunc(l, 74)}</Text>
        </Box>
      ))}
      {hidden > 0 && (
        <Box marginLeft={5}>
          <Text dimColor>… +{hidden} more line{hidden !== 1 ? 's' : ''}</Text>
        </Box>
      )}
    </Box>
  );
}

// ── Main component ───────────────────────────────────────────────────────────

export function ToolCallLine({ call }: Props) {
  const [spinIdx, setSpinIdx] = useState(0);
  useEffect(() => {
    if (call.done) return;
    const t = setInterval(() => setSpinIdx(i => (i + 1) % SPIN.length), 80);
    return () => clearInterval(t);
  }, [call.done]);

  const a = call.args as Record<string, string>;

  // ── In-progress ────────────────────────────────────────────────────────────
  if (!call.done) {
    let label: React.ReactNode;
    switch (call.tool) {
      case 'write_file':
      case 'edit_file':
        label = (
          <>
            <Text color="yellow">Update</Text>
            <Text dimColor>(</Text>
            <Text color="yellow">{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </>
        );
        break;
      case 'execute_command':
        label = (
          <>
            <Text color="yellow">Bash</Text>
            <Text dimColor>(</Text>
            <Text color="yellow">{trunc(a.command ?? '', 60)}</Text>
            <Text dimColor>)</Text>
          </>
        );
        break;
      case 'read_file':
        label = (
          <>
            <Text color="yellow">Read</Text>
            <Text dimColor>(</Text>
            <Text color="yellow">{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </>
        );
        break;
      default: {
        const name = call.tool.startsWith('mcp_') ? call.tool.slice(4) :
                     call.tool.startsWith('lsp_') ? call.tool.slice(4) : call.tool;
        label = <Text color="yellow">{name}{trunc(JSON.stringify(call.args), 50)}</Text>;
      }
    }
    return (
      <Box marginLeft={6}>
        <Text color="yellow">{SPIN[spinIdx]}  </Text>
        <Text color="yellow">⏺ </Text>
        {label}
      </Box>
    );
  }

  // ── Completed ──────────────────────────────────────────────────────────────
  const ok    = call.success !== false;
  const icon  = ok ? '⏺' : '⏺';
  const col   = ok ? '#c0c0c0' : 'red';

  switch (call.tool) {

    case 'write_file': {
      const lines = (a.content ?? '').split('\n').length;
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Write</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </Box>
          <Box marginLeft={2}>
            <Text color="#555566">⎿  </Text>
            <Text color="green">+{lines} </Text>
            <Text dimColor>line{lines !== 1 ? 's' : ''}</Text>
          </Box>
        </Box>
      );
    }

    case 'edit_file': {
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Update</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </Box>
          {ok
            ? <DiffBlock oldText={a.old_text ?? ''} newText={a.new_text ?? ''} />
            : <Box marginLeft={2}><Text color="red">✗ {trunc(call.output ?? 'failed', 70)}</Text></Box>
          }
        </Box>
      );
    }

    case 'execute_command': {
      const out = (call.output ?? '').trim();
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Bash</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{trunc(a.command ?? '', 60)}</Text>
            <Text dimColor>)</Text>
          </Box>
          {out ? <OutputBlock output={out} /> : null}
        </Box>
      );
    }

    case 'read_file': {
      const lines = (call.output ?? '').split('\n').length;
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Read</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(a.path ?? '')}</Text>
            <Text dimColor>)</Text>
          </Box>
          <Box marginLeft={2}>
            <Text color="#555566">⎿  </Text>
            <Text dimColor>{lines} line{lines !== 1 ? 's' : ''}</Text>
          </Box>
        </Box>
      );
    }

    case 'search_files': {
      const matches = (call.output ?? '').split('\n').filter(Boolean).length;
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>Grep</Text>
            <Text dimColor>(</Text>
            <Text color={ok ? '#aaaaaa' : 'red'}>{trunc(String(a.pattern ?? ''), 55)}</Text>
            <Text dimColor>)</Text>
          </Box>
          <Box marginLeft={2}>
            <Text color="#555566">⎿  </Text>
            <Text dimColor>{matches} match{matches !== 1 ? 'es' : ''}</Text>
          </Box>
        </Box>
      );
    }

    case 'list_files': {
      const items = (call.output ?? '').split('\n').filter(Boolean).length;
      return (
        <Box marginLeft={6}>
          <Text color={col}>{icon} </Text>
          <Text color={ok ? 'white' : 'red'}>Ls</Text>
          <Text dimColor>(</Text>
          <Text color={ok ? '#aaaaaa' : 'red'}>{shortPath(String(a.path ?? '.'))}</Text>
          <Text dimColor>)  </Text>
          <Text dimColor>{items} item{items !== 1 ? 's' : ''}</Text>
        </Box>
      );
    }

    default: {
      const name = call.tool.startsWith('mcp_') ? call.tool.slice(4) :
                   call.tool.startsWith('lsp_') ? call.tool.slice(4) : call.tool;
      const out = (call.output ?? '').trim();
      return (
        <Box flexDirection="column" marginLeft={6}>
          <Box>
            <Text color={col}>{icon} </Text>
            <Text color={ok ? 'white' : 'red'}>{name}</Text>
            <Text dimColor>  {trunc(JSON.stringify(call.args), 45)}</Text>
          </Box>
          {out ? <OutputBlock output={out} /> : null}
        </Box>
      );
    }
  }
}
