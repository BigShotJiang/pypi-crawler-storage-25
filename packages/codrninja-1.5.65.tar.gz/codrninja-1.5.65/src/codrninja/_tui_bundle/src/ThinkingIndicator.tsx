import React, { useEffect, useRef, useState } from 'react';
import { Box, Text } from 'ink';

const MESSAGES: string[] = [
  'Thinking', 'Pondering', 'Calculating', 'Analyzing', 'Processing',
  'Caramelizing onions', 'Teaching a neural net to juggle', 'Brewing coffee',
  'Asking GPT for help', 'Contemplating the universe', 'Debugging reality',
  'Warming up the GPU', 'Consulting the oracle', 'Counting electric sheep',
  'Summoning AI spirits', 'Bribing the LLM with RAM', 'Reticulating splines',
  'Feeding the hamster', 'Aligning the chakras', 'Deciphering binary',
  'Teaching a cat to code', 'Charging the flux capacitor', 'Polishing the bits',
  'Summoning Stack Overflow', 'Compiling the compiler', 'Asking the rubber duck',
  'Warming up the qubits', 'Negotiating with the GPU', 'Brewing a neural blend',
  'Defragmenting consciousness', 'Synchronizing the multiverse', 'Rehearsing dad jokes',
  'Assembling IKEA instructions', 'Flossing the dataset', 'Whispering to the weights',
  'Calculating the meaning of 42', 'Downloading more RAM', 'Making a sandwich',
  'Convincing Skynet not to kill us', 'Looking for the missing semicolon',
  'Untangling the spaghetti code', 'Bribing the garbage collector',
  'Rotating the 3D donut', 'Petting the attention heads', "Sharpening Occam's razor",
  'Herding the tokens', 'Consulting the man page', 'Reversing the polarity',
  'Mining crypto on your CPU (jk)', 'Teaching gradient descent to dance',
  'Counting to infinity, twice', 'Dreaming in Python', 'Replacing tabs with spaces',
  'Rolling initiative', 'Running sudo rm -rf /doubts', 'Updating node_modules',
  'Waiting for npm install', 'Arguing with TypeScript', 'Rebooting the vibes',
  'Generating a UUID (please wait)', 'Training on your browser history',
  'Loading the loading screen', 'Building in prod', 'Pushing to main',
  'Doing the needful', 'Establishing a TCP handshake with the void',
];

// Spinning shuriken frames
const SHURIKEN    = ['✵', '❊', '✴', '❋'] as const;
const SHURIKEN_MS = 300;
const MSG_MS      = 10000;
const TICK_MS     = 80;

function fmtElapsed(ms: number): string {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}m ${r}s`;
}

function fmtTokens(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

function shuffled<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

// Silver shimmer — discrete brightness steps for reliable terminal rendering
const SHIMMER_STEPS = ['#ffffff', '#c0c0c0', '#787878', '#383838', '#181818'] as const;
const SHIMMER_RADIUS = 4;
const SWEEP_MS  = 3500;
const PAUSE_MS  = 1800;
const DIM_COL   = SHIMMER_STEPS[SHIMMER_STEPS.length - 1]!;

function shimmerColor(dist: number): string {
  const bucket = Math.min(SHIMMER_STEPS.length - 1, Math.floor(dist));
  return SHIMMER_STEPS[bucket]!;
}

interface Props {
  onCurrentPast?: (past: string) => void;
  startTime?: number;
  tokensIn?: number;
  thoughtStart?: number;  // when the current thinking phase began (after last tool)
}

export function ThinkingIndicator({ onCurrentPast, startTime, tokensIn = 0, thoughtStart }: Props) {
  const [msgs]   = useState(() => shuffled(MESSAGES));
  const [tick, setTick] = useState(0);

  const originRef        = useRef(startTime ?? Date.now());
  const prevMsgRef       = useRef('');
  const onCurrentPastRef = useRef(onCurrentPast);
  onCurrentPastRef.current = onCurrentPast;

  useEffect(() => { originRef.current = startTime ?? Date.now(); }, [startTime]);
  useEffect(() => {
    const t = setInterval(() => setTick(n => n + 1), TICK_MS);
    return () => clearInterval(t);
  }, []);

  const now         = Date.now();
  const elapsed     = now - originRef.current;
  const thoughtMs   = thoughtStart ? now - thoughtStart : elapsed;

  const msgIdx  = Math.floor(elapsed / MSG_MS) % msgs.length;
  const message = msgs[msgIdx] ?? 'Thinking';

  // Notify parent of current past-tense form (used in completion line)
  useEffect(() => {
    if (message !== prevMsgRef.current) {
      prevMsgRef.current = message;
      // derive past tense simply: append "ed" (good enough for display)
      const past = message.endsWith('e') ? message + 'd'
                 : message.endsWith('ing') ? message.slice(0, -3) + 'ed'
                 : message + 'ed';
      onCurrentPastRef.current?.(past);
    }
  });

  const shurikenFrame = Math.floor(elapsed / SHURIKEN_MS) % SHURIKEN.length;
  const shuriken      = SHURIKEN[shurikenFrame]!;

  // ── Shimmer across the message text ────────────────────────────────────────
  const msgText   = `${message}…`;
  const msgLen    = msgText.length;
  const idlePhase = elapsed % (SWEEP_MS + PAUSE_MS);
  let shimPos: number;
  if (idlePhase < SWEEP_MS) {
    const frac = idlePhase / SWEEP_MS;
    shimPos = -SHIMMER_RADIUS + frac * (msgLen + 2 * SHIMMER_RADIUS);
  } else {
    shimPos = -(SHIMMER_RADIUS * 4);
  }

  const winStart = Math.max(0, Math.floor(shimPos - SHIMMER_RADIUS));
  const winEnd   = Math.max(0, Math.min(msgLen, Math.ceil(shimPos + SHIMMER_RADIUS)));

  // ── Metadata string ─────────────────────────────────────────────────────────
  const parts: string[] = [fmtElapsed(elapsed)];
  if (tokensIn > 0) parts.push(`↑ ${fmtTokens(tokensIn)}`);
  parts.push(`thought for ${fmtElapsed(thoughtMs)}`);
  const meta = `(${parts.join(' · ')})`;

  return (
    <Box>
      {/* spinning shuriken */}
      <Text color="#c0c0c0">{shuriken} </Text>

      {/* message with shimmer */}
      {winStart > 0 && <Text color={DIM_COL}>{msgText.slice(0, winStart)}</Text>}
      {Array.from(msgText.slice(winStart, winEnd)).map((char, i) => (
        <Text key={i} color={shimmerColor(Math.abs(winStart + i - shimPos))}>{char}</Text>
      ))}
      {winEnd < msgLen && <Text color={DIM_COL}>{msgText.slice(winEnd)}</Text>}

      {/* metadata */}
      <Text color="#484848"> {meta}</Text>
    </Box>
  );
}
