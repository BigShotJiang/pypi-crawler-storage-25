import React from 'react';
import { Box, Text } from 'ink';

type Seg =
  | { t: 'text'; v: string }
  | { t: 'bold'; v: string }
  | { t: 'italic'; v: string }
  | { t: 'bold-italic'; v: string }
  | { t: 'code'; v: string };

function parseInline(line: string): Seg[] {
  const segs: Seg[] = [];
  let i = 0;
  let buf = '';

  while (i < line.length) {
    // bold-italic ***
    if (line.startsWith('***', i)) {
      const end = line.indexOf('***', i + 3);
      if (end !== -1) {
        if (buf) { segs.push({ t: 'text', v: buf }); buf = ''; }
        segs.push({ t: 'bold-italic', v: line.slice(i + 3, end) });
        i = end + 3; continue;
      }
    }
    // bold **
    if (line.startsWith('**', i)) {
      const end = line.indexOf('**', i + 2);
      if (end !== -1) {
        if (buf) { segs.push({ t: 'text', v: buf }); buf = ''; }
        segs.push({ t: 'bold', v: line.slice(i + 2, end) });
        i = end + 2; continue;
      }
    }
    // italic *
    if (line[i] === '*' && line[i + 1] !== '*') {
      const end = line.indexOf('*', i + 1);
      if (end !== -1 && end > i + 1) {
        if (buf) { segs.push({ t: 'text', v: buf }); buf = ''; }
        segs.push({ t: 'italic', v: line.slice(i + 1, end) });
        i = end + 1; continue;
      }
    }
    // inline code `
    if (line[i] === '`') {
      const end = line.indexOf('`', i + 1);
      if (end !== -1) {
        if (buf) { segs.push({ t: 'text', v: buf }); buf = ''; }
        segs.push({ t: 'code', v: line.slice(i + 1, end) });
        i = end + 1; continue;
      }
    }
    buf += line[i]; i++;
  }
  if (buf) segs.push({ t: 'text', v: buf });
  return segs;
}

function InlineLine({ text }: { text: string }) {
  const segs = parseInline(text);
  if (segs.length === 1 && segs[0]!.t === 'text') {
    return <Text wrap="wrap">{segs[0]!.v}</Text>;
  }
  return (
    <Box flexWrap="wrap">
      {segs.map((s, i) => {
        switch (s.t) {
          case 'bold':       return <Text key={i} bold>{s.v}</Text>;
          case 'italic':     return <Text key={i} italic>{s.v}</Text>;
          case 'bold-italic':return <Text key={i} bold italic>{s.v}</Text>;
          case 'code':       return <Text key={i} color="yellow">{s.v}</Text>;
          default:           return <Text key={i}>{s.v}</Text>;
        }
      })}
    </Box>
  );
}

interface Props {
  content: string;
  streaming?: boolean;
}

export function Markdown({ content, streaming }: Props) {
  const lines = content.split('\n');
  const nodes: React.ReactNode[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i]!;

    // fenced code block
    if (line.startsWith('```')) {
      const lang = line.slice(3).trim();
      const block: string[] = [];
      i++;
      while (i < lines.length && !lines[i]!.startsWith('```')) {
        block.push(lines[i]!); i++;
      }
      i++; // skip closing ```
      if (lang === 'tool') continue; // silently skip internal tool call blocks
      // Also skip json blocks that are tool calls (some models emit ```json instead of ```tool)
      if (lang === 'json' && block.some((l) => l.includes('"tool"')) && block.some((l) => l.includes('"params"'))) continue;
      nodes.push(
        <Box key={`cb-${i}`} flexDirection="column" borderStyle="single" borderColor="gray" paddingX={1} marginY={0}>
          {lang ? <Text dimColor>{lang}</Text> : null}
          {block.map((l, j) => <Text key={j} color="yellow">{l}</Text>)}
        </Box>
      );
      continue;
    }

    // heading
    const hm = line.match(/^(#{1,3})\s+(.+)/);
    if (hm) {
      const level = hm[1]!.length;
      nodes.push(
        <Text key={`h-${i}`} bold color={level === 1 ? 'cyan' : level === 2 ? 'green' : 'white'}>
          {hm[2]}
        </Text>
      );
      i++; continue;
    }

    // horizontal rule
    if (/^[-*_]{3,}$/.test(line.trim())) {
      nodes.push(<Text key={`hr-${i}`} dimColor>{'─'.repeat(50)}</Text>);
      i++; continue;
    }

    // bullet
    const bm = line.match(/^(\s*)[-*•]\s+(.+)/);
    if (bm) {
      nodes.push(
        <Box key={`b-${i}`} marginLeft={Math.floor(bm[1]!.length / 2)}>
          <Text color="cyan">• </Text>
          <InlineLine text={bm[2]!} />
        </Box>
      );
      i++; continue;
    }

    // numbered list
    const nm = line.match(/^(\s*)(\d+)\.\s+(.+)/);
    if (nm) {
      nodes.push(
        <Box key={`n-${i}`} marginLeft={Math.floor(nm[1]!.length / 2)}>
          <Text color="cyan">{nm[2]}. </Text>
          <InlineLine text={nm[3]!} />
        </Box>
      );
      i++; continue;
    }

    // empty line → small gap
    if (line.trim() === '') {
      nodes.push(<Text key={`e-${i}`}>{''}</Text>);
      i++; continue;
    }

    // regular line
    const isLast = i === lines.length - 1;
    nodes.push(
      <Box key={`l-${i}`}>
        <InlineLine text={line} />
        {isLast && streaming && <Text color="cyan">▌</Text>}
      </Box>
    );
    i++;
  }

  // cursor on trailing newline
  if (streaming && content.endsWith('\n')) {
    nodes.push(<Text key="cur">▌</Text>);
  }

  return <Box flexDirection="column">{nodes}</Box>;
}
