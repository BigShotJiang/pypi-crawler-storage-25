import React, { useState } from 'react';
import { Box, Text, useInput, useApp } from 'ink';
import { Session, ProviderInfo } from './api.js';
import { C, LOGO } from './styles.js';

interface Props {
  sessions: Session[];
  onSelect: (name: string) => void;
  onNew: (name: string) => void;
  onDelete?: (name: string) => void;
  error?: string;
  version?: string;
  providers?: ProviderInfo[];
  currentModel?: string;
  currentProvider?: string;
}

type Mode = 'list' | 'new' | 'delete';

const PROVIDER_ENV: Record<string, string> = {
  openai:       'OAuth / API Key',
  anthropic:    'OAuth / API Key',
  ollama:       'local server',
  openrouter:   'API Key',
  'claude-cli': 'Claude Code CLI',
};

function relativeTime(iso?: string): string {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export function SessionList({ sessions, onSelect, onNew, onDelete, error, version, providers, currentModel, currentProvider }: Props) {
  const { exit } = useApp();
  const [idx, setIdx] = useState(0);
  const [mode, setMode] = useState<Mode>('list');
  const [newName, setNewName] = useState('');

  const total = sessions.length;

  useInput((input, key) => {
    if (mode === 'new') {
      if (key.return && newName.trim()) {
        onNew(newName.trim());
        setNewName('');
        setMode('list');
      } else if (key.escape) {
        setNewName('');
        setMode('list');
      } else if (key.backspace || key.delete) {
        setNewName(p => p.slice(0, -1));
      } else if (input && !key.ctrl && !key.meta) {
        setNewName(p => p + input);
      }
      return;
    }

    if (mode === 'delete') {
      if (input === 'y' && sessions[idx]) {
        onDelete?.(sessions[idx]!.name);
        setIdx(i => Math.max(0, i - 1));
        setMode('list');
      } else if (key.escape) {
        setMode('list');
      }
      return;
    }

    if (key.upArrow)   setIdx(i => Math.max(0, i - 1));
    if (key.downArrow) setIdx(i => Math.min(total - 1, i + 1));
    if (key.return && sessions[idx]) onSelect(sessions[idx]!.name);
    if (input === 'n') setMode('new');
    if (input === 'd' && sessions[idx]) setMode('delete');
    if (input === 'q') exit();
  });

  return (
    <Box flexDirection="column" paddingX={2} paddingY={1}>

      {/* logo */}
      <Text color={C.acc}>{LOGO}</Text>

      {/* version */}
      {version && (
        <Box marginTop={1}>
          <Text color={C.acc}>v{version}</Text>
          <Text color={C.dim}>  codrninja</Text>
        </Box>
      )}

      <Text color={C.dim}>{'─'.repeat(70)}</Text>

      {error && <Text color={C.red}> {error}</Text>}

      {/* sessions header */}
      <Box justifyContent="space-between" marginTop={1} marginBottom={1}>
        <Text color={C.acc} bold>SESSIONS</Text>
        <Box gap={2}>
          <Text color={C.dim}>n </Text><Text color={C.acc}>new</Text>
          {onDelete && <><Text color={C.dim}>  d </Text><Text color={C.acc}>delete</Text></>}
        </Box>
      </Box>

      {/* session list */}
      <Box flexDirection="column" borderStyle="single" borderColor="#2a2a3e">
        {sessions.length === 0 ? (
          <Box paddingX={2} paddingY={1}>
            <Text color={C.dim}>No sessions — press </Text><Text color={C.acc}>n</Text><Text color={C.dim}> to create one</Text>
          </Box>
        ) : (
          sessions.map((s, i) => {
            const sel = i === idx && mode !== 'new';
            return (
              <Box key={s.name} paddingX={1}>
                <Text color={C.acc}>{sel ? '▶ ' : '  '}</Text>
                <Box minWidth={20}><Text color={sel ? C.wh : C.txt} bold={sel}>{s.name}</Text></Box>
                {s.running && <Text color={C.grn}> ⟳ </Text>}
                {!s.running && <Text>   </Text>}
                <Box minWidth={12}><Text color={C.dim}>{relativeTime(s.updated_at)}</Text></Box>
                <Box minWidth={20}><Text color={sel ? C.acc : '#4a4a68'}>{s.model || currentModel || ''}</Text></Box>
                <Text color={C.dim}>{s.provider || currentProvider || ''}</Text>
              </Box>
            );
          })
        )}
      </Box>

      {/* delete confirm */}
      {mode === 'delete' && sessions[idx] && (
        <Box borderStyle="single" borderColor={C.red} paddingX={1} marginTop={1}>
          <Text color={C.red}>Delete </Text>
          <Text color={C.acc}>'{sessions[idx]!.name}'</Text>
          <Text color={C.red}>?  </Text>
          <Text color={C.wh}>y </Text><Text color={C.dim}>confirm  </Text>
          <Text color={C.wh}>Esc </Text><Text color={C.dim}>cancel</Text>
        </Box>
      )}

      {/* new session input */}
      {mode === 'new' && (
        <Box borderStyle="single" borderColor={C.acc} paddingX={1} marginTop={1}>
          <Text color={C.dim}>session name  › </Text>
          <Text color={C.acc}>{newName}</Text>
          <Text color={C.acc} bold>▌</Text>
        </Box>
      )}

      {/* provider status */}
      {providers && providers.length > 0 && (
        <Box flexDirection="column" marginTop={1}>
          <Text color={C.acc} bold>PROVIDERS</Text>
          {providers.map(p => {
            const connected = p.authenticated || p.oauth;
            return (
              <Box key={p.name}>
                <Text color={connected ? C.grn : '#252535'}>{connected ? '● ' : '○ '}</Text>
                <Box minWidth={12}><Text color={connected ? C.txt : C.dim}>{p.name}</Text></Box>
                <Box minWidth={22}><Text color="#252535">{PROVIDER_ENV[p.name] ?? ''}</Text></Box>
                {connected ? (
                  <Text color={p.active ? C.acc : C.grn}>{p.active ? 'active' : 'connected'}</Text>
                ) : (
                  <Text color="#2a2a3e">not configured</Text>
                )}
              </Box>
            );
          })}
        </Box>
      )}

      <Text color={C.dim}>{'─'.repeat(70)}</Text>

      {/* keyboard hints */}
      <Box gap={3} marginTop={1}>
        {([['↑↓', 'navigate'], ['Enter', 'open'], ['n', 'new'], ['d', 'delete'], ['q', 'quit']] as const).map(([k, l]) => (
          <Box key={k}>
            <Text color={C.dim}>{k} </Text>
            <Text color={C.acc}>{l}</Text>
          </Box>
        ))}
      </Box>

    </Box>
  );
}
