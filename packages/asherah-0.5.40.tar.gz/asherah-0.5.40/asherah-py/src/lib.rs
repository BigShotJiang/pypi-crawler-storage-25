#![allow(unsafe_code)]
#![allow(unused_qualifications)]

use asherah as ael;
use asherah::logging::{ensure_logger, set_sink as set_log_sink, LogSink};
use asherah::metrics;
use asherah::metrics::MetricsSink;
use asherah_config as config;
use once_cell::sync::Lazy;
use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;
use pyo3::types::PyDict;
use pyo3::PyRef;

use lru::LruCache;
use parking_lot::Mutex;
use std::num::NonZeroUsize;
use std::sync::Arc;
use zeroize::Zeroizing;

type Factory = ael::session::PublicFactory<
    ael::aead::AES256GCM,
    ael::builders::DynKms,
    ael::builders::DynMetastore,
>;
type SessionHandle = ael::session::PublicSession<
    ael::aead::AES256GCM,
    ael::builders::DynKms,
    ael::builders::DynMetastore,
>;

fn anyhow_to_py(err: anyhow::Error) -> PyErr {
    // Use {:#} to show the full error chain, not just the outermost context
    PyRuntimeError::new_err(format!("{err:#}"))
}

fn json_parse_err(err: impl std::fmt::Display) -> PyErr {
    PyRuntimeError::new_err(format!("invalid DataRowRecord JSON: {err}"))
}

#[pyfunction]
fn setup(config_obj: &Bound<'_, PyAny>) -> PyResult<()> {
    let py = config_obj.py();
    let json_module = py.import("json")?;
    let json_config: String = json_module
        .call_method1("dumps", (config_obj,))?
        .extract()?;
    let cfg = config::ConfigOptions::from_json(&json_config).map_err(anyhow_to_py)?;
    let (factory, applied) = config::factory_from_config(&cfg).map_err(anyhow_to_py)?;
    // Always enable per-factory metrics so an installed metrics hook
    // actually fires for encrypt/decrypt/store/load events. The cost is
    // one Instant::now() per encrypt regardless of hook state; the
    // global metrics gate (toggled by set_metrics_hook) decides whether
    // the sink is actually invoked.
    let factory = factory.with_metrics(true);
    let mut guard = MANAGER.lock();
    if guard.is_some() {
        return Err(PyRuntimeError::new_err(
            "Asherah already configured; call shutdown() first",
        ));
    }
    *guard = Some(FactoryManager::new(factory, applied));
    Ok(())
}

#[pyfunction]
fn shutdown() -> PyResult<()> {
    let mut guard = MANAGER.lock();
    if let Some(manager) = guard.take() {
        manager.shutdown().map_err(anyhow_to_py)?;
    }
    Ok(())
}

#[pyfunction]
fn get_setup_status() -> PyResult<bool> {
    let guard = MANAGER.lock();
    Ok(guard.is_some())
}

#[pyfunction]
fn setenv(env_obj: &Bound<'_, PyAny>) -> PyResult<()> {
    let py = env_obj.py();
    let value = match env_obj.extract::<String>() {
        Ok(s) => serde_json::from_str::<serde_json::Value>(&s)
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?,
        Err(_) => {
            let json_module = py.import("json")?;
            let dumped: String = json_module.call_method1("dumps", (env_obj,))?.extract()?;
            serde_json::from_str::<serde_json::Value>(&dumped)
                .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
        }
    };

    let obj = value
        .as_object()
        .ok_or_else(|| PyRuntimeError::new_err("environment payload must be a JSON object"))?;
    let os_module = py.import("os")?;
    let environ = os_module.getattr("environ")?;
    for (key, val) in obj {
        match val {
            serde_json::Value::Null => {
                std::env::remove_var(key);
                let _removed = environ.del_item(key);
            }
            serde_json::Value::String(s) => {
                std::env::set_var(key, s);
                environ.set_item(key, s)?;
            }
            other => {
                let rendered = other.to_string();
                std::env::set_var(key, &rendered);
                environ.set_item(key, rendered)?;
            }
        }
    }
    Ok(())
}

#[pyfunction]
fn encrypt_bytes(py: Python<'_>, partition_id: &str, data: &[u8]) -> PyResult<String> {
    let session = with_manager(|mgr| Ok(mgr.get_or_create_session(partition_id)))?;
    let input = Zeroizing::new(data.to_vec());
    // Release the GIL across the encrypt — encrypt may hit MySQL/Postgres
    // and AWS KMS, both of which can block for tens of milliseconds. T5 in
    // docs/review-2026-05-05-findings.md.
    let drr = py
        .detach(|| session.encrypt(&input))
        .map_err(anyhow_to_py)?;
    let json = serde_json::to_string(&drr)
        .map_err(|e| PyRuntimeError::new_err(format!("json error: {e}")))?;
    Ok(json)
}

#[pyfunction]
fn encrypt_string(py: Python<'_>, partition_id: &str, text: &str) -> PyResult<String> {
    encrypt_bytes(py, partition_id, text.as_bytes())
}

#[pyfunction]
fn decrypt_bytes<'py>(
    py: Python<'py>,
    partition_id: &str,
    data_row_record: &str,
) -> PyResult<Bound<'py, PyBytes>> {
    let session = with_manager(|mgr| Ok(mgr.get_or_create_session(partition_id)))?;
    let drr: ael::types::DataRowRecord = serde_json::from_str(data_row_record)
        .map_err(|e| PyRuntimeError::new_err(format!("invalid DataRowRecord JSON: {e}")))?;
    // `PyBytes::new` copies into a Python-managed buffer that we can no
    // longer wipe — but we *can* wipe our own intermediate Vec the
    // moment the copy completes. Wrap in `Zeroizing` so any early
    // return (e.g., a panic in `PyBytes::new`) still wipes.
    let bytes: Zeroizing<Vec<u8>> =
        Zeroizing::new(py.detach(|| session.decrypt(drr)).map_err(anyhow_to_py)?);
    Ok(PyBytes::new(py, &bytes))
}

#[pyfunction]
fn decrypt_string(partition_id: &str, data_row_record: &str) -> PyResult<String> {
    Python::attach(|py| {
        let session = with_manager(|mgr| Ok(mgr.get_or_create_session(partition_id)))?;
        let drr: ael::types::DataRowRecord = serde_json::from_str(data_row_record)
            .map_err(|e| PyRuntimeError::new_err(format!("invalid DataRowRecord JSON: {e}")))?;
        let bytes: Zeroizing<Vec<u8>> =
            Zeroizing::new(py.detach(|| session.decrypt(drr)).map_err(anyhow_to_py)?);
        // Validate UTF-8 against the wiped-on-drop buffer; only allocate
        // the final `String` (which Python will own and we can't wipe)
        // if validation succeeds. The intermediate `Vec` from `to_vec`
        // is unavoidable because `String` requires ownership of its
        // backing buffer and we can't move out of `Zeroizing` without
        // skipping the wipe.
        std::str::from_utf8(&bytes)
            .map_err(|e| PyRuntimeError::new_err(format!("utf8 error: {e}")))?;
        String::from_utf8(bytes.to_vec())
            .map_err(|e| PyRuntimeError::new_err(format!("utf8 error: {e}")))
    })
}

/// Module-level async encrypt — runs on Rust's tokio runtime, returns a Python coroutine.
#[pyfunction]
async fn encrypt_bytes_async(partition_id: String, data: Vec<u8>) -> PyResult<String> {
    let session = with_manager(|mgr| Ok(mgr.get_or_create_session(&partition_id)))?;
    let (tx, rx) = tokio::sync::oneshot::channel();
    ASYNC_RT.spawn(async move {
        let result = session
            .encrypt_async(&data)
            .await
            .and_then(|drr| serde_json::to_string(&drr).map_err(|e| anyhow::anyhow!("json: {e}")));
        drop(tx.send(result));
    });
    rx.await
        .map_err(|_| PyRuntimeError::new_err("async encrypt cancelled"))?
        .map_err(anyhow_to_py)
}

/// Module-level async decrypt — runs on Rust's tokio runtime, returns a Python coroutine.
///
/// PyO3's `Vec<u8>` return type forces a copy into a Python `bytes`
/// before we get a chance to wipe; the wipe of our intermediate Vec
/// happens immediately after the copy. Once the plaintext lives in
/// Python's heap as `bytes` it's beyond our control.
#[pyfunction]
async fn decrypt_bytes_async(partition_id: String, data_row_record: String) -> PyResult<Vec<u8>> {
    let session = with_manager(|mgr| Ok(mgr.get_or_create_session(&partition_id)))?;
    let drr: ael::types::DataRowRecord =
        serde_json::from_str(&data_row_record).map_err(json_parse_err)?;
    let (tx, rx) = tokio::sync::oneshot::channel();
    ASYNC_RT.spawn(async move {
        let result = session.decrypt_async(drr).await;
        drop(tx.send(result));
    });
    let pt: Zeroizing<Vec<u8>> = Zeroizing::new(
        rx.await
            .map_err(|_| PyRuntimeError::new_err("async decrypt cancelled"))?
            .map_err(anyhow_to_py)?,
    );
    Ok(pt.to_vec())
}

struct FactoryManager {
    factory: Arc<Factory>,
    /// Bounded LRU. `LruCache.get` already does move-to-MRU-on-hit;
    /// `LruCache.put` evicts the LRU entry when at capacity. Honors
    /// `SessionCacheMaxSize` from config (default 1000) — previously
    /// hardcoded to 1000 with random-iteration eviction.
    sessions: Mutex<LruCache<String, Arc<SessionHandle>>>,
    enable_session_caching: bool,
}

impl FactoryManager {
    fn new(factory: Factory, applied: config::AppliedConfig) -> Self {
        let cap = NonZeroUsize::new(applied.session_cache_max_size)
            .or_else(|| NonZeroUsize::new(1000))
            .expect("1000 is non-zero");
        Self {
            factory: Arc::new(factory),
            sessions: Mutex::new(LruCache::new(cap)),
            enable_session_caching: applied.enable_session_caching,
        }
    }

    fn get_or_create_session(&self, partition: &str) -> Arc<SessionHandle> {
        if !self.enable_session_caching {
            return Arc::new(self.factory.get_session(partition));
        }

        let mut sessions = self.sessions.lock();
        if let Some(existing) = sessions.get(partition) {
            return existing.clone();
        }
        let fresh = Arc::new(self.factory.get_session(partition));
        // `put` returns the evicted (key, value) when at capacity; the
        // dropped Arc here releases our reference to the LRU session.
        // Other callers that already cloned the Arc keep it alive until
        // they're done — no use-after-free for in-flight ops.
        sessions.put(partition.to_string(), fresh.clone());
        fresh
        // Lock dropped here — crypto runs outside
    }

    fn shutdown(self) -> anyhow::Result<()> {
        let sessions = self.sessions.into_inner();
        drop(sessions); // drop all Arc<SessionHandle>
                        // Factory is in an Arc; it's dropped when the last reference goes away
        if let Some(factory) = Arc::into_inner(self.factory) {
            factory.close()?;
        }
        Ok(())
    }
}

static MANAGER: Lazy<Mutex<Option<FactoryManager>>> = Lazy::new(|| Mutex::new(None));
static PY_METRICS_CALLBACK: Lazy<Mutex<Option<Arc<Py<PyAny>>>>> = Lazy::new(|| Mutex::new(None));
static PY_LOG_CALLBACK: Lazy<Mutex<Option<Arc<Py<PyAny>>>>> = Lazy::new(|| Mutex::new(None));

fn with_manager<F, R>(f: F) -> PyResult<R>
where
    F: FnOnce(&FactoryManager) -> PyResult<R>,
{
    let guard = MANAGER.lock();
    let manager = guard
        .as_ref()
        .ok_or_else(|| PyRuntimeError::new_err("Asherah not configured; call setup()"))?;
    f(manager)
}

/// Shared tokio runtime for async Python operations.
static ASYNC_RT: Lazy<tokio::runtime::Runtime> = Lazy::new(|| {
    tokio::runtime::Builder::new_multi_thread()
        .worker_threads(2)
        .thread_name("asherah-py-async")
        .enable_all()
        .build()
        .expect("failed to create async Python tokio runtime")
});

#[pyclass(module = "asherah", frozen, name = "SessionFactory")]
#[allow(missing_debug_implementations)]
pub struct PySessionFactory {
    inner: Factory,
}

#[pymethods]
impl PySessionFactory {
    #[new]
    pub fn new() -> PyResult<Self> {
        let inner = ael::builders::factory_from_env().map_err(anyhow_to_py)?;
        let inner = inner.with_metrics(true);
        Ok(Self { inner })
    }

    #[staticmethod]
    pub fn from_env() -> PyResult<Self> {
        Self::new()
    }

    pub fn get_session(&self, partition_id: &str) -> PyResult<PySession> {
        let session = self.inner.get_session(partition_id);
        Ok(PySession {
            inner: Arc::new(session),
        })
    }

    pub fn close(&self) -> PyResult<()> {
        self.inner.close().map_err(anyhow_to_py)?;
        Ok(())
    }

    fn __enter__(slf: PyRef<'_, Self>) -> PyResult<PyRef<'_, Self>> {
        Ok(slf)
    }

    fn __exit__(
        &self,
        _ty: Option<&Bound<'_, PyAny>>,
        _value: Option<&Bound<'_, PyAny>>,
        _tb: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<()> {
        self.close()
    }
}

#[pyclass(module = "asherah", frozen, name = "Session")]
#[allow(missing_debug_implementations)]
pub struct PySession {
    inner: Arc<SessionHandle>,
}

#[pymethods]
impl PySession {
    pub fn encrypt_bytes(&self, py: Python<'_>, data: &[u8]) -> PyResult<String> {
        let input = Zeroizing::new(data.to_vec());
        // Release the GIL across the encrypt — the operation can hit
        // MySQL/Postgres and AWS KMS, both blocking. T5 in
        // docs/review-2026-05-05-findings.md.
        let drr = py
            .detach(|| self.inner.encrypt(&input))
            .map_err(anyhow_to_py)?;
        serde_json::to_string(&drr).map_err(|e| PyRuntimeError::new_err(format!("json error: {e}")))
    }

    pub fn encrypt_text(&self, py: Python<'_>, text: &str) -> PyResult<String> {
        self.encrypt_bytes(py, text.as_bytes())
    }

    pub fn decrypt_bytes<'py>(
        &self,
        py: Python<'py>,
        data_row_record: &str,
    ) -> PyResult<Bound<'py, PyBytes>> {
        let pt = self.decrypt_raw(py, data_row_record)?;
        // `pt` is `Zeroizing<Vec<u8>>` — copies into PyBytes here, then
        // wipes the Rust-side buffer when it goes out of scope.
        Ok(PyBytes::new(py, &pt))
    }

    pub fn decrypt_text(&self, py: Python<'_>, data_row_record: &str) -> PyResult<String> {
        let bytes = self.decrypt_raw(py, data_row_record)?;
        std::str::from_utf8(&bytes)
            .map_err(|e| PyRuntimeError::new_err(format!("utf8 error: {e}")))?;
        // The cloned `Vec` becomes the String's backing buffer and is
        // owned by Python from here on. We can't wipe a Python `str`,
        // so this is a documented limitation of the text path.
        String::from_utf8(bytes.to_vec())
            .map_err(|e| PyRuntimeError::new_err(format!("utf8 error: {e}")))
    }

    /// True async encrypt — runs on Rust's tokio runtime, returns a Python coroutine.
    pub async fn encrypt_bytes_async(&self, data: Vec<u8>) -> PyResult<String> {
        let session = Arc::clone(&self.inner);
        let (tx, rx) = tokio::sync::oneshot::channel();
        ASYNC_RT.spawn(async move {
            let result = session.encrypt_async(&data).await.and_then(|drr| {
                serde_json::to_string(&drr).map_err(|e| anyhow::anyhow!("json error: {e}"))
            });
            drop(tx.send(result));
        });
        rx.await
            .map_err(|_| PyRuntimeError::new_err("async encrypt cancelled"))?
            .map_err(anyhow_to_py)
    }

    /// True async decrypt — runs on Rust's tokio runtime, returns a Python coroutine.
    pub async fn decrypt_bytes_async(&self, data_row_record: String) -> PyResult<Vec<u8>> {
        let session = Arc::clone(&self.inner);
        let drr: ael::types::DataRowRecord =
            serde_json::from_str(&data_row_record).map_err(json_parse_err)?;
        let (tx, rx) = tokio::sync::oneshot::channel();
        ASYNC_RT.spawn(async move {
            let result = session.decrypt_async(drr).await;
            drop(tx.send(result));
        });
        let pt: Zeroizing<Vec<u8>> = Zeroizing::new(
            rx.await
                .map_err(|_| PyRuntimeError::new_err("async decrypt cancelled"))?
                .map_err(anyhow_to_py)?,
        );
        Ok(pt.to_vec())
    }

    pub fn close(&self) -> PyResult<()> {
        self.inner.close().map_err(anyhow_to_py)?;
        Ok(())
    }

    fn __enter__(slf: PyRef<'_, Self>) -> PyResult<PyRef<'_, Self>> {
        Ok(slf)
    }

    fn __exit__(
        &self,
        _ty: Option<&Bound<'_, PyAny>>,
        _value: Option<&Bound<'_, PyAny>>,
        _tb: Option<&Bound<'_, PyAny>>,
    ) -> PyResult<()> {
        self.close()
    }
}

// Helper impl block kept separate from `#[pymethods]` so PyO3 doesn't
// try to expose the `Zeroizing<Vec<u8>>` return type to Python.
#[allow(clippy::multiple_inherent_impl)]
impl PySession {
    fn decrypt_raw(&self, py: Python<'_>, data_row_record: &str) -> PyResult<Zeroizing<Vec<u8>>> {
        let drr: ael::types::DataRowRecord =
            serde_json::from_str(data_row_record).map_err(json_parse_err)?;
        let pt = py
            .detach(|| self.inner.decrypt(drr))
            .map_err(anyhow_to_py)?;
        Ok(Zeroizing::new(pt))
    }
}

struct PyMetricsSink {
    callback: Arc<Py<PyAny>>,
}

impl PyMetricsSink {
    fn emit(&self, builder: impl FnOnce(Python<'_>) -> PyResult<Py<PyAny>>) {
        let cb = Arc::clone(&self.callback);
        Python::attach(|py| match builder(py) {
            Ok(obj) => {
                if let Err(err) = cb.call1(py, (obj,)) {
                    err.print(py);
                }
            }
            Err(err) => err.print(py),
        });
    }
}

impl MetricsSink for PyMetricsSink {
    fn encrypt(&self, duration: std::time::Duration) {
        self.emit(|py| {
            let dict = PyDict::new(py);
            dict.set_item("type", "encrypt")?;
            dict.set_item("duration_ns", duration.as_nanos() as u64)?;
            Ok(dict.into_any().unbind())
        });
    }

    fn decrypt(&self, duration: std::time::Duration) {
        self.emit(|py| {
            let dict = PyDict::new(py);
            dict.set_item("type", "decrypt")?;
            dict.set_item("duration_ns", duration.as_nanos() as u64)?;
            Ok(dict.into_any().unbind())
        });
    }

    fn store(&self, duration: std::time::Duration) {
        self.emit(|py| {
            let dict = PyDict::new(py);
            dict.set_item("type", "store")?;
            dict.set_item("duration_ns", duration.as_nanos() as u64)?;
            Ok(dict.into_any().unbind())
        });
    }

    fn load(&self, duration: std::time::Duration) {
        self.emit(|py| {
            let dict = PyDict::new(py);
            dict.set_item("type", "load")?;
            dict.set_item("duration_ns", duration.as_nanos() as u64)?;
            Ok(dict.into_any().unbind())
        });
    }

    fn cache_hit(&self, name: &str) {
        let name = name.to_string();
        self.emit(|py| {
            let dict = PyDict::new(py);
            dict.set_item("type", "cache_hit")?;
            dict.set_item("name", &name)?;
            Ok(dict.into_any().unbind())
        });
    }

    fn cache_miss(&self, name: &str) {
        let name = name.to_string();
        self.emit(|py| {
            let dict = PyDict::new(py);
            dict.set_item("type", "cache_miss")?;
            dict.set_item("name", &name)?;
            Ok(dict.into_any().unbind())
        });
    }

    fn cache_stale(&self, name: &str) {
        let name = name.to_string();
        self.emit(|py| {
            let dict = PyDict::new(py);
            dict.set_item("type", "cache_stale")?;
            dict.set_item("name", &name)?;
            Ok(dict.into_any().unbind())
        });
    }
}

struct PyLogSink {
    callback: Arc<Py<PyAny>>,
}

impl LogSink for PyLogSink {
    fn log(&self, record: &log::Record<'_>) {
        // Normalize to lowercase ("warn" not "WARN") to match the
        // documented set of LogEvent.level values across all bindings.
        let level = match record.level() {
            log::Level::Error => "error",
            log::Level::Warn => "warn",
            log::Level::Info => "info",
            log::Level::Debug => "debug",
            log::Level::Trace => "trace",
        }
        .to_string();
        let message = record.args().to_string();
        let target = record.target().to_string();
        let cb = Arc::clone(&self.callback);
        Python::attach(|py| {
            let dict = PyDict::new(py);
            if dict.set_item("level", &level).is_err()
                || dict.set_item("message", &message).is_err()
                || dict.set_item("target", &target).is_err()
            {
                return;
            }
            if let Err(err) = cb.call1(py, (&dict,)) {
                err.print(py);
            }
        });
    }
}

#[pyfunction]
fn set_metrics_hook(callback: Option<&Bound<'_, PyAny>>) -> PyResult<()> {
    if let Some(cb) = callback {
        let obj: Py<PyAny> = cb.clone().unbind();
        let arc = Arc::new(obj);
        metrics::set_sink(PyMetricsSink {
            callback: Arc::clone(&arc),
        });
        // Metrics are gated for performance; enable them when a hook is
        // installed, disable them when cleared.
        metrics::set_enabled(true);
        *PY_METRICS_CALLBACK.lock() = Some(arc);
    } else {
        metrics::clear_sink();
        metrics::set_enabled(false);
        *PY_METRICS_CALLBACK.lock() = None;
    }
    Ok(())
}

#[pyfunction]
fn set_log_hook(callback: Option<&Bound<'_, PyAny>>) -> PyResult<()> {
    ensure_logger().map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
    if let Some(cb) = callback {
        let obj: Py<PyAny> = cb.clone().unbind();
        let arc = Arc::new(obj);
        set_log_sink(
            "python",
            Some(Arc::new(PyLogSink {
                callback: Arc::clone(&arc),
            })),
        );
        *PY_LOG_CALLBACK.lock() = Some(arc);
    } else {
        set_log_sink("python", None);
        *PY_LOG_CALLBACK.lock() = None;
    }
    Ok(())
}

#[pyfunction]
fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

#[pymodule]
fn _asherah(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(setup, m)?)?;
    m.add_function(wrap_pyfunction!(shutdown, m)?)?;
    m.add_function(wrap_pyfunction!(get_setup_status, m)?)?;
    m.add_function(wrap_pyfunction!(setenv, m)?)?;
    m.add_function(wrap_pyfunction!(encrypt_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(encrypt_string, m)?)?;
    m.add_function(wrap_pyfunction!(decrypt_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(decrypt_string, m)?)?;
    m.add_function(wrap_pyfunction!(encrypt_bytes_async, m)?)?;
    m.add_function(wrap_pyfunction!(decrypt_bytes_async, m)?)?;
    m.add_class::<PySessionFactory>()?;
    m.add_class::<PySession>()?;
    m.add_function(wrap_pyfunction!(set_metrics_hook, m)?)?;
    m.add_function(wrap_pyfunction!(set_log_hook, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;
    Ok(())
}
