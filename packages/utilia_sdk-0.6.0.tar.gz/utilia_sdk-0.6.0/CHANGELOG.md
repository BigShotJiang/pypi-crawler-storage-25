# Changelog

## 0.6.0 (2026-04-02)
- Mejoras en OAuth 2.1: nuevo flujo simplificado con gestion automatica de PKCE
- `get_authorization_url()`: genera URL y almacena el estado PKCE internamente
- `handle_callback(code)`: recupera el code_verifier automaticamente (sin parametros manuales)
- Validacion automatica del state CSRF en handle_callback
- `is_authenticated()`: verifica si hay sesion OAuth activa
- `logout()`: revoca tokens y limpia el almacenamiento
- `ErrorCode.AUTH_EXPIRED`: nuevo codigo de error para sesiones OAuth expiradas
- `build_sse_url_async()`: soporte de SSE con tokens OAuth (access_token como query param)
- Campo `token_storage` en `OAuthConfig` para almacenamiento personalizado
- Estado PKCE persistente en MemoryTokenStorage y FileTokenStorage
- Corregido bug critico: el cliente sincrono ahora comparte storage con el async (los tokens OAuth se inyectan correctamente en las peticiones HTTP)
- Metodos anteriores (`get_login_url`, `handle_callback(code, verifier)`) siguen disponibles para control manual
- Correccion de tildes en comentarios y docstrings en castellano

## 0.5.0 (2026-03-25)
- Autenticacion OAuth 2.1 con PKCE: `get_login_url()`, `handle_callback()`, `refresh_token()`
- Token storage: MemoryTokenStorage y FileTokenStorage (async y sync)
- Renovacion automatica de tokens con auto-refresh en 401
- Endpoint userinfo y revocacion de tokens
- Soporte completo async (OAuthService) y sync (OAuthSyncService)

## 0.4.0 (2026-03-15)
- Soporte de streaming SSE para sugerencias de IA y transcripcion
- Mejoras en el manejo de errores y reintentos

## 0.3.2 (2026-03-17)
- Corregido el servicio de errores para usar la clave `data` en la respuesta de `list()`, alineando con el contrato de la API
- Tests actualizados para reflejar el formato correcto de respuesta paginada

## 0.3.0 (2026-02-27)
- Nuevo servicio de errores del sistema: `report`, `list`, `stats`
- Modelos completos: `ReportErrorInput`, `ReportedError`, `SystemErrorEntry`, `ErrorFilters`, `ErrorStats`
- Deduplicacion automatica por hash con indicador `deduplicated` en respuesta
- Suite de tests para los 3 metodos (8 tests async + sync)

## 0.2.0 (2026-02-08)
- Nuevo servicio de IA: sugerencias inteligentes, transcripcion de audio
- Soporte para streaming SSE con cancelacion
- Tracking de aceptacion/rechazo de sugerencias
- Mejoras en el cliente HTTP y manejo de errores

## 0.1.0 (2026-02-06)
- Lanzamiento inicial
- Soporte asincrono (async/await) y sincrono
- Servicios: tickets, users, files, ai
- Validacion con Pydantic v2
- Reintentos con backoff exponencial
- Type hints completos (mypy strict)
