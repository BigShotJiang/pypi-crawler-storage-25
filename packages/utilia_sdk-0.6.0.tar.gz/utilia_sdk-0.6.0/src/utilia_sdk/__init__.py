"""
UTILIA OS SDK para Python.

SDK para integrar aplicaciones externas con el sistema de soporte
de UTILIA OS. Incluye versiones asíncrona y síncrona.

Ejemplo de uso asíncrono::

    from utilia_sdk import UtiliaSDK

    async with UtiliaSDK(base_url="https://os.utilia.ai/api", api_key="tu-api-key") as sdk:
        user = await sdk.users.identify(
            IdentifyUserInput(external_id="user-123", email="user@example.com")
        )
        ticket = await sdk.tickets.create(
            CreateTicketInput(
                user=CreateTicketUser(external_id="user-123"),
                title="Problema con facturación",
                description="No puedo ver mis facturas del mes pasado...",
            )
        )

Ejemplo de uso síncrono::

    from utilia_sdk import UtiliaSDKSync

    with UtiliaSDKSync(base_url="https://os.utilia.ai/api", api_key="tu-api-key") as sdk:
        user = sdk.users.identify(
            IdentifyUserInput(external_id="user-123", email="user@example.com")
        )
"""

from __future__ import annotations

from typing import Any

from utilia_sdk._client import UtiliaClient
from utilia_sdk._constants import SDK_LIMITS
from utilia_sdk._sync_client import UtiliaSyncClient
from utilia_sdk.auth import (
    FileTokenStorage,
    MemoryTokenStorage,
    OAuthService,
    OAuthSyncService,
    SyncTokenStorage,
    TokenStorage,
    generate_code_challenge,
    generate_code_verifier,
)
from utilia_sdk.errors import ErrorCode, UtiliaSDKError
from utilia_sdk.models import (
    AddMessageInput,
    AiJobResult,
    AiJobStatus,
    AiSuggestInput,
    AiSuggestions,
    CreatedMessage,
    CreatedTicket,
    CreateTicketInput,
    CreateTicketUser,
    ErrorFilters,
    ErrorStats,
    ExternalUser,
    FileQuota,
    GetSuggestionsOptions,
    IdentifyUserInput,
    ImageBase64,
    LoginUrlResult,
    MessageAuthor,
    OAuthConfig,
    OAuthTokens,
    OAuthUserInfo,
    PaginatedResponse,
    PaginationMeta,
    PendingOAuthState,
    ReportClientErrorParams,
    ReportedError,
    ReportErrorInput,
    SseEvent,
    SseStreamOptions,
    StreamSuggestionsHandle,
    StreamSuggestionsOptions,
    StreamTranscriptionOptions,
    SyncStreamSuggestionsHandle,
    SystemErrorEntry,
    TicketAttachment,
    TicketCategory,
    TicketContext,
    TicketDetail,
    TicketFilters,
    TicketListItem,
    TicketMessage,
    TicketPriority,
    TicketReporter,
    TicketStatus,
    TopError,
    TrackAiActionInput,
    TranscriptionJobStatus,
    UnreadCount,
    UploadedFile,
    UserTicketCount,
    UtiliaSDKConfig,
)
from utilia_sdk.services.ai import AiService, AiSyncService
from utilia_sdk.services.errors import ErrorsService, ErrorsSyncService
from utilia_sdk.services.files import FilesService, FilesSyncService
from utilia_sdk.services.tickets import TicketsService, TicketsSyncService
from utilia_sdk.services.users import UsersService, UsersSyncService


class UtiliaSDK:
    """Clase principal asíncrona del SDK de UTILIA OS.

    Proporciona acceso a todos los servicios disponibles:

    - ``tickets``: Operaciones con tickets de soporte.
    - ``users``: Operaciones con usuarios externos.
    - ``files``: Operaciones con archivos adjuntos.
    - ``ai``: Funcionalidades de IA (transcripción, sugerencias).
    - ``errors``: Reporte y consulta de errores del sistema.

    Soporta uso como context manager asíncrono para cerrar
    la sesión HTTP automáticamente.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str = "",
        *,
        oauth: OAuthConfig | dict[str, Any] | None = None,
        timeout: float = 30.0,
        retry_attempts: int = 3,
        debug: bool = False,
    ) -> None:
        # Aceptar dict como configuración OAuth para mayor comodidad
        oauth_config = OAuthConfig(**oauth) if isinstance(oauth, dict) else oauth

        config = UtiliaSDKConfig(
            base_url=base_url,
            api_key=api_key,
            oauth=oauth_config,
            timeout=timeout,
            retry_attempts=retry_attempts,
            debug=debug,
        )
        self._client = UtiliaClient(config)
        self.tickets = TicketsService(self._client)
        self.users = UsersService(self._client)
        self.files = FilesService(self._client)
        self.ai = AiService(self._client)
        self.errors = ErrorsService(self._client)

    @property
    def oauth(self) -> OAuthService:
        """Acceso al servicio OAuth (solo disponible en modo OAuth)."""
        return self._client.oauth

    @property
    def oauth_service(self) -> OAuthService:
        """Alias de oauth para compatibilidad."""
        return self._client.oauth

    async def close(self) -> None:
        """Cierra la sesión HTTP."""
        await self._client.close()

    async def __aenter__(self) -> UtiliaSDK:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()


class UtiliaSDKSync:
    """Clase principal síncrona del SDK de UTILIA OS.

    Proporciona la misma funcionalidad que UtiliaSDK pero
    sin necesidad de async/await.

    - ``tickets``: Operaciones con tickets de soporte.
    - ``users``: Operaciones con usuarios externos.
    - ``files``: Operaciones con archivos adjuntos.
    - ``ai``: Funcionalidades de IA (transcripción, sugerencias).
    - ``errors``: Reporte y consulta de errores del sistema.

    Soporta uso como context manager síncrono.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str = "",
        *,
        oauth: OAuthConfig | dict[str, Any] | None = None,
        timeout: float = 30.0,
        retry_attempts: int = 3,
        debug: bool = False,
    ) -> None:
        # Aceptar dict como configuración OAuth para mayor comodidad
        oauth_config = OAuthConfig(**oauth) if isinstance(oauth, dict) else oauth

        config = UtiliaSDKConfig(
            base_url=base_url,
            api_key=api_key,
            oauth=oauth_config,
            timeout=timeout,
            retry_attempts=retry_attempts,
            debug=debug,
        )
        self._client = UtiliaSyncClient(config)
        self.tickets = TicketsSyncService(self._client)
        self.users = UsersSyncService(self._client)
        self.files = FilesSyncService(self._client)
        self.ai = AiSyncService(self._client)
        self.errors = ErrorsSyncService(self._client)

    @property
    def oauth(self) -> OAuthSyncService:
        """Acceso al servicio OAuth síncrono (solo disponible en modo OAuth)."""
        return self._client.oauth

    @property
    def oauth_service(self) -> OAuthSyncService:
        """Alias de oauth para compatibilidad."""
        return self._client.oauth

    def close(self) -> None:
        """Cierra la sesión HTTP y el event loop."""
        self._client.close()

    def __enter__(self) -> UtiliaSDKSync:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


__all__ = [
    # SDK principal
    "UtiliaSDK",
    "UtiliaSDKSync",
    # Errores SDK
    "ErrorCode",
    "UtiliaSDKError",
    # Modelos - Config
    "UtiliaSDKConfig",
    "SDK_LIMITS",
    # OAuth
    "FileTokenStorage",
    "LoginUrlResult",
    "MemoryTokenStorage",
    "OAuthConfig",
    "OAuthService",
    "OAuthSyncService",
    "OAuthTokens",
    "OAuthUserInfo",
    "PendingOAuthState",
    "SyncTokenStorage",
    "TokenStorage",
    "generate_code_challenge",
    "generate_code_verifier",
    # Modelos - Comunes
    "PaginatedResponse",
    "PaginationMeta",
    "TicketCategory",
    "TicketPriority",
    "TicketStatus",
    # Modelos - Tickets
    "AddMessageInput",
    "CreatedMessage",
    "CreatedTicket",
    "CreateTicketInput",
    "CreateTicketUser",
    "MessageAuthor",
    "TicketAttachment",
    "TicketContext",
    "TicketDetail",
    "TicketFilters",
    "TicketListItem",
    "TicketMessage",
    "TicketReporter",
    "UnreadCount",
    # Modelos - Usuarios
    "ExternalUser",
    "IdentifyUserInput",
    "UserTicketCount",
    # Modelos - Archivos
    "FileQuota",
    "UploadedFile",
    # Modelos - IA
    "AiJobResult",
    "AiJobStatus",
    "AiSuggestions",
    "AiSuggestInput",
    "GetSuggestionsOptions",
    "ImageBase64",
    "ReportClientErrorParams",
    "SseEvent",
    "SseStreamOptions",
    "StreamSuggestionsHandle",
    "StreamSuggestionsOptions",
    "StreamTranscriptionOptions",
    "SyncStreamSuggestionsHandle",
    "TrackAiActionInput",
    "TranscriptionJobStatus",
    # Modelos - Errores del sistema
    "ErrorFilters",
    "ErrorStats",
    "ReportedError",
    "ReportErrorInput",
    "SystemErrorEntry",
    "TopError",
    # Servicios
    "AiService",
    "AiSyncService",
    "ErrorsService",
    "ErrorsSyncService",
    "FilesService",
    "FilesSyncService",
    "TicketsService",
    "TicketsSyncService",
    "UsersService",
    "UsersSyncService",
]
