"""Modelos de datos para autenticación OAuth 2.1 con PKCE."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


@dataclass
class OAuthConfig:
    """Configuración de OAuth para el SDK.

    Attributes:
        client_id: Identificador de la aplicación OAuth.
        redirect_uri: URI de redirección registrada.
        client_secret: Secreto de la aplicación (opcional, para apps confidenciales).
        scopes: Scopes solicitados (default: ['openid', 'profile', 'email']).
        token_storage: Almacenamiento personalizado de tokens (opcional).
    """

    client_id: str
    redirect_uri: str
    client_secret: str | None = None
    scopes: list[str] = field(default_factory=lambda: ["openid", "profile", "email"])
    token_storage: Any | None = field(default=None, repr=False, compare=False)


@dataclass
class OAuthTokens:
    """Tokens OAuth devueltos por el servidor de autorización.

    Attributes:
        access_token: Token de acceso.
        token_type: Tipo de token (normalmente 'Bearer').
        expires_in: Duración en segundos del access token.
        expires_at: Timestamp absoluto de expiración (time.time() + expires_in).
        refresh_token: Token de refresco (si fue concedido).
        scope: Scopes concedidos.
        id_token: Token de identidad OpenID Connect.
    """

    access_token: str
    token_type: str
    expires_in: int
    expires_at: float
    refresh_token: str | None = None
    scope: str | None = None
    id_token: str | None = None


@dataclass
class OAuthUserInfo:
    """Información del usuario autenticado (endpoint /oauth/userinfo).

    Attributes:
        sub: Identificador único del usuario.
        name: Nombre completo.
        email: Correo electrónico.
        email_verified: Si el correo ha sido verificado.
        picture: URL de la foto de perfil.
        given_name: Nombre de pila.
        family_name: Apellido(s).
    """

    sub: str
    name: str | None = None
    email: str | None = None
    email_verified: bool | None = None
    picture: str | None = None
    given_name: str | None = None
    family_name: str | None = None


@dataclass
class PendingOAuthState:
    """Estado PKCE pendiente almacenado entre get_authorization_url() y handle_callback().

    Attributes:
        code_verifier: Verificador PKCE generado.
        state: Valor de state para protección CSRF.
    """

    code_verifier: str
    state: str


@dataclass
class LoginUrlResult:
    """Resultado de generar la URL de inicio de sesión OAuth.

    Attributes:
        url: URL completa de autorización.
        code_verifier: Verificador PKCE (debe guardarse para el callback).
        state: Valor de state para protección CSRF.
    """

    url: str
    code_verifier: str
    state: str
