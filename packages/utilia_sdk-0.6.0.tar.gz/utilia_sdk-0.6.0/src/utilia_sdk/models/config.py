"""Configuración del SDK."""

from __future__ import annotations

from dataclasses import dataclass, field

from utilia_sdk.models.oauth import OAuthConfig


@dataclass(frozen=True)
class UtiliaSDKConfig:
    """Configuración para inicializar el SDK de UTILIA OS.

    Soporta dos modos de autenticación mutuamente excluyentes:
    - API Key: para integraciones servidor-a-servidor.
    - OAuth 2.1 con PKCE: para aplicaciones que actúan en nombre de un usuario.

    Attributes:
        base_url: URL base de la API (ej: https://os.utilia.ai/api).
        api_key: API Key para autenticación (requerida si no se usa OAuth).
        oauth: Configuración OAuth 2.1 con PKCE (alternativa a api_key).
        timeout: Timeout en segundos (default: 30).
        retry_attempts: Número de reintentos en caso de error (default: 3).
        debug: Habilitar logs de debug (default: False).
    """

    base_url: str
    api_key: str = field(default="")
    oauth: OAuthConfig | None = field(default=None)
    timeout: float = field(default=30.0)
    retry_attempts: int = field(default=3)
    debug: bool = field(default=False)

    def __post_init__(self) -> None:
        if not self.api_key and not self.oauth:
            raise ValueError(
                "Debes proporcionar api_key o configuración oauth."
            )
        if self.api_key and self.oauth:
            raise ValueError(
                "No puedes proporcionar api_key y oauth a la vez. Usa uno u otro."
            )
