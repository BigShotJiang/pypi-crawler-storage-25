"""Utilidades PKCE (Proof Key for Code Exchange) para OAuth 2.1."""

from __future__ import annotations

import base64
import hashlib
import secrets


def generate_code_verifier(length: int = 64) -> str:
    """Genera un code_verifier aleatorio compatible con RFC 7636.

    Args:
        length: Longitud del verificador (entre 43 y 128, default: 64).

    Returns:
        Cadena aleatoria URL-safe.
    """
    valid_length = max(43, min(128, length))
    return secrets.token_urlsafe(valid_length)[:valid_length]


def generate_code_challenge(verifier: str) -> str:
    """Genera el code_challenge a partir de un code_verifier usando SHA-256.

    Args:
        verifier: El code_verifier generado previamente.

    Returns:
        code_challenge en base64url sin padding.
    """
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
