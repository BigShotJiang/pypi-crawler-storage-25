"""Implementaciones de almacenamiento de tokens OAuth."""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from pathlib import Path

from utilia_sdk.models.oauth import OAuthTokens, PendingOAuthState


class TokenStorage(ABC):
    """Interfaz abstracta para almacenamiento asíncrono de tokens."""

    @abstractmethod
    async def get_tokens(self) -> OAuthTokens | None:
        """Obtiene los tokens almacenados."""
        ...

    @abstractmethod
    async def set_tokens(self, tokens: OAuthTokens) -> None:
        """Almacena los tokens."""
        ...

    @abstractmethod
    async def clear_tokens(self) -> None:
        """Elimina los tokens almacenados."""
        ...

    async def get_pending_state(self) -> PendingOAuthState | None:
        """Obtiene el estado PKCE pendiente (opcional, para flujo automático)."""
        return None

    async def set_pending_state(self, state: PendingOAuthState) -> None:
        """Almacena el estado PKCE pendiente (opcional, para flujo automático)."""

    async def clear_pending_state(self) -> None:
        """Elimina el estado PKCE pendiente (opcional, para flujo automático)."""


class SyncTokenStorage(ABC):
    """Interfaz abstracta para almacenamiento síncrono de tokens."""

    @abstractmethod
    def get_tokens_sync(self) -> OAuthTokens | None:
        """Obtiene los tokens almacenados de forma síncrona."""
        ...

    @abstractmethod
    def set_tokens_sync(self, tokens: OAuthTokens) -> None:
        """Almacena los tokens de forma síncrona."""
        ...

    @abstractmethod
    def clear_tokens_sync(self) -> None:
        """Elimina los tokens almacenados de forma síncrona."""
        ...

    def get_pending_state_sync(self) -> PendingOAuthState | None:
        """Obtiene el estado PKCE pendiente de forma síncrona."""
        return None

    def set_pending_state_sync(self, state: PendingOAuthState) -> None:
        """Almacena el estado PKCE pendiente de forma síncrona."""

    def clear_pending_state_sync(self) -> None:
        """Elimina el estado PKCE pendiente de forma síncrona."""


class MemoryTokenStorage(TokenStorage, SyncTokenStorage):
    """Almacenamiento de tokens en memoria.

    Los tokens se pierden al cerrar el proceso.
    Implementa ambas interfaces (async y sync).
    """

    def __init__(self) -> None:
        self._tokens: OAuthTokens | None = None
        self._pending_state: PendingOAuthState | None = None

    async def get_tokens(self) -> OAuthTokens | None:
        return self._tokens

    async def set_tokens(self, tokens: OAuthTokens) -> None:
        self._tokens = tokens

    async def clear_tokens(self) -> None:
        self._tokens = None

    def get_tokens_sync(self) -> OAuthTokens | None:
        return self._tokens

    def set_tokens_sync(self, tokens: OAuthTokens) -> None:
        self._tokens = tokens

    def clear_tokens_sync(self) -> None:
        self._tokens = None

    async def get_pending_state(self) -> PendingOAuthState | None:
        return self._pending_state

    async def set_pending_state(self, state: PendingOAuthState) -> None:
        self._pending_state = state

    async def clear_pending_state(self) -> None:
        self._pending_state = None

    def get_pending_state_sync(self) -> PendingOAuthState | None:
        return self._pending_state

    def set_pending_state_sync(self, state: PendingOAuthState) -> None:
        self._pending_state = state

    def clear_pending_state_sync(self) -> None:
        self._pending_state = None


class FileTokenStorage(TokenStorage, SyncTokenStorage):
    """Almacenamiento de tokens en archivo JSON.

    Persiste los tokens entre ejecuciones.
    Implementa ambas interfaces (async y sync).
    """

    def __init__(self, file_path: str) -> None:
        self._path = Path(file_path)

    def _read(self) -> OAuthTokens | None:
        """Lee los tokens del archivo."""
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            return OAuthTokens(
                access_token=data["access_token"],
                token_type=data["token_type"],
                expires_in=data["expires_in"],
                expires_at=data["expires_at"],
                refresh_token=data.get("refresh_token"),
                scope=data.get("scope"),
                id_token=data.get("id_token"),
            )
        except (FileNotFoundError, json.JSONDecodeError, KeyError):
            return None

    def _write(self, tokens: OAuthTokens) -> None:
        """Escribe los tokens en el archivo."""
        data = {
            "access_token": tokens.access_token,
            "token_type": tokens.token_type,
            "expires_in": tokens.expires_in,
            "expires_at": tokens.expires_at,
            "refresh_token": tokens.refresh_token,
            "scope": tokens.scope,
            "id_token": tokens.id_token,
        }
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        self._path.chmod(0o600)

    def _delete(self) -> None:
        """Elimina el archivo de tokens."""
        try:
            self._path.unlink()
        except FileNotFoundError:
            pass

    @property
    def _pending_path(self) -> Path:
        """Ruta del archivo para estado PKCE pendiente."""
        return self._path.with_suffix(".pending.json")

    def _read_pending(self) -> PendingOAuthState | None:
        """Lee el estado PKCE pendiente del archivo."""
        try:
            data = json.loads(self._pending_path.read_text(encoding="utf-8"))
            return PendingOAuthState(
                code_verifier=data["code_verifier"],
                state=data["state"],
            )
        except (FileNotFoundError, json.JSONDecodeError, KeyError):
            return None

    def _write_pending(self, state: PendingOAuthState) -> None:
        """Escribe el estado PKCE pendiente en archivo."""
        data = {"code_verifier": state.code_verifier, "state": state.state}
        self._pending_path.parent.mkdir(parents=True, exist_ok=True)
        self._pending_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        self._pending_path.chmod(0o600)

    def _delete_pending(self) -> None:
        """Elimina el archivo de estado PKCE pendiente."""
        try:
            self._pending_path.unlink()
        except FileNotFoundError:
            pass

    # Interfaz asincrona
    async def get_tokens(self) -> OAuthTokens | None:
        return await asyncio.to_thread(self._read)

    async def set_tokens(self, tokens: OAuthTokens) -> None:
        await asyncio.to_thread(self._write, tokens)

    async def clear_tokens(self) -> None:
        await asyncio.to_thread(self._delete)

    async def get_pending_state(self) -> PendingOAuthState | None:
        return await asyncio.to_thread(self._read_pending)

    async def set_pending_state(self, state: PendingOAuthState) -> None:
        await asyncio.to_thread(self._write_pending, state)

    async def clear_pending_state(self) -> None:
        await asyncio.to_thread(self._delete_pending)

    # Interfaz sincrona
    def get_tokens_sync(self) -> OAuthTokens | None:
        return self._read()

    def set_tokens_sync(self, tokens: OAuthTokens) -> None:
        self._write(tokens)

    def clear_tokens_sync(self) -> None:
        self._delete()

    def get_pending_state_sync(self) -> PendingOAuthState | None:
        return self._read_pending()

    def set_pending_state_sync(self, state: PendingOAuthState) -> None:
        self._write_pending(state)

    def clear_pending_state_sync(self) -> None:
        self._delete_pending()
