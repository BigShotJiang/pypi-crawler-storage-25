"""Servicio OAuth 2.1 con PKCE para el SDK de UTILIA OS."""

from __future__ import annotations

import asyncio
import secrets
import time
from urllib.parse import urlencode

import httpx

from utilia_sdk.auth.pkce import generate_code_challenge, generate_code_verifier
from utilia_sdk.auth.token_storage import MemoryTokenStorage, SyncTokenStorage, TokenStorage
from utilia_sdk.models.oauth import (
    LoginUrlResult,
    OAuthConfig,
    OAuthTokens,
    OAuthUserInfo,
    PendingOAuthState,
)


class OAuthService:
    """Servicio asíncrono que gestiona el flujo OAuth 2.1 con PKCE."""

    def __init__(self, base_url: str, config: OAuthConfig) -> None:
        self._base_url = base_url.rstrip("/")
        self._config = config
        self._storage: TokenStorage = (
            config.token_storage if config.token_storage is not None
            else MemoryTokenStorage()
        )
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=30.0,
            headers={"Content-Type": "application/json"},
        )
        self._refresh_lock = asyncio.Lock()
        self._pending_state: PendingOAuthState | None = None

    async def close(self) -> None:
        """Cierra el cliente HTTP interno."""
        await self._http.aclose()

    def set_storage(self, storage: TokenStorage) -> None:
        """Establece el almacenamiento de tokens personalizado."""
        self._storage = storage

    async def get_authorization_url(
        self,
        *,
        state: str | None = None,
        scopes: list[str] | None = None,
    ) -> str:
        """Genera la URL de autorización OAuth con PKCE y almacena el estado
        pendiente automáticamente. Usar con handle_callback(code) sin code_verifier.

        Este es el método recomendado para la mayoría de los casos.

        Args:
            state: Valor de state personalizado para protección CSRF.
            scopes: Scopes a solicitar (por defecto usa los de la configuración).

        Returns:
            URL de autorización lista para redirigir al usuario.
        """
        result = await self.get_login_url(state=state, scopes=scopes)

        pending = PendingOAuthState(
            code_verifier=result.code_verifier,
            state=result.state,
        )

        # Guardar en memoria como fallback
        self._pending_state = pending

        # Persistir en storage si soporta estado pendiente
        await self._storage.set_pending_state(pending)

        return result.url

    async def get_login_url(
        self,
        *,
        state: str | None = None,
        scopes: list[str] | None = None,
    ) -> LoginUrlResult:
        """Genera la URL de inicio de sesión OAuth con PKCE.

        Método de control manual: devuelve code_verifier y state que el
        desarrollador debe gestionar. Para un flujo automático, usar
        get_authorization_url() en su lugar.

        Args:
            state: Valor de state personalizado para protección CSRF.
            scopes: Scopes a solicitar (por defecto usa los de la configuración).

        Returns:
            URL de autorización, code_verifier y state.
        """
        code_verifier = generate_code_verifier()
        code_challenge = generate_code_challenge(code_verifier)
        actual_state = state or secrets.token_urlsafe(32)
        actual_scopes = scopes or self._config.scopes

        params = urlencode({
            "response_type": "code",
            "client_id": self._config.client_id,
            "redirect_uri": self._config.redirect_uri,
            "scope": " ".join(actual_scopes),
            "state": actual_state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        })

        return LoginUrlResult(
            url=f"{self._base_url}/oauth/authorize?{params}",
            code_verifier=code_verifier,
            state=actual_state,
        )

    async def handle_callback(
        self,
        code: str,
        code_verifier: str | None = None,
        callback_state: str | None = None,
    ) -> OAuthTokens:
        """Intercambia el código de autorización por tokens.

        Si se llama sin code_verifier, recupera automáticamente el estado PKCE
        almacenado por get_authorization_url() y valida el state CSRF.

        Args:
            code: Código de autorización recibido en el callback.
            code_verifier: Verificador PKCE (opcional si se usó get_authorization_url).
            callback_state: Valor de state recibido en el callback (para validación CSRF).

        Returns:
            Tokens OAuth.
        """
        verifier = code_verifier

        if not verifier:
            pending = await self._get_pending_state()
            if not pending:
                raise RuntimeError(
                    "No se encontró el estado PKCE pendiente. Usa get_authorization_url() "
                    "antes de handle_callback(), o proporciona el code_verifier manualmente."
                )

            verifier = pending.code_verifier

            if callback_state and callback_state != pending.state:
                await self._clear_pending_state()
                raise RuntimeError(
                    f"El valor de state no coincide. Posible ataque CSRF. "
                    f"Esperado: {pending.state}, recibido: {callback_state}"
                )

            await self._clear_pending_state()

        body: dict[str, str] = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self._config.redirect_uri,
            "code_verifier": verifier,
            "client_id": self._config.client_id,
        }

        if self._config.client_secret:
            body["client_secret"] = self._config.client_secret

        response = await self._http.post("/oauth/token", json=body)
        response.raise_for_status()
        data = response.json()

        tokens = OAuthTokens(
            access_token=data["access_token"],
            token_type=data.get("token_type", "Bearer"),
            expires_in=data["expires_in"],
            expires_at=time.time() + data["expires_in"],
            refresh_token=data.get("refresh_token"),
            scope=data.get("scope"),
            id_token=data.get("id_token"),
        )

        await self._storage.set_tokens(tokens)
        return tokens

    async def refresh_token(self) -> OAuthTokens:
        """Refresca el token de acceso usando el refresh_token.

        Returns:
            Nuevos tokens OAuth.

        Raises:
            RuntimeError: Si no hay refresh_token disponible.
        """
        current = await self._storage.get_tokens()
        if not current or not current.refresh_token:
            raise RuntimeError(
                "No hay refresh token disponible. El usuario debe volver a autenticarse."
            )

        body: dict[str, str] = {
            "grant_type": "refresh_token",
            "refresh_token": current.refresh_token,
            "client_id": self._config.client_id,
        }

        if self._config.client_secret:
            body["client_secret"] = self._config.client_secret

        response = await self._http.post("/oauth/token", json=body)
        response.raise_for_status()
        data = response.json()

        tokens = OAuthTokens(
            access_token=data["access_token"],
            token_type=data.get("token_type", "Bearer"),
            expires_in=data["expires_in"],
            expires_at=time.time() + data["expires_in"],
            refresh_token=data.get("refresh_token", current.refresh_token),
            scope=data.get("scope"),
            id_token=data.get("id_token"),
        )

        await self._storage.set_tokens(tokens)
        return tokens

    async def get_user_info(self) -> OAuthUserInfo:
        """Obtiene información del usuario autenticado.

        Returns:
            Datos del usuario desde /oauth/userinfo.
        """
        access_token = await self.get_access_token()
        response = await self._http.get(
            "/oauth/userinfo",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        response.raise_for_status()
        data = response.json()

        return OAuthUserInfo(
            sub=data["sub"],
            name=data.get("name"),
            email=data.get("email"),
            email_verified=data.get("email_verified"),
            picture=data.get("picture"),
            given_name=data.get("given_name"),
            family_name=data.get("family_name"),
        )

    async def revoke_token(
        self, token_type: str | None = None
    ) -> None:
        """Revoca el token actual.

        Args:
            token_type: Tipo de token a revocar ('access_token' o 'refresh_token').
                       Por defecto revoca el access_token.
        """
        current = await self._storage.get_tokens()
        if not current:
            return

        token = (
            current.refresh_token if token_type == "refresh_token"
            else current.access_token
        )

        if not token:
            return

        body: dict[str, str] = {
            "token": token,
            "client_id": self._config.client_id,
        }

        if token_type:
            body["token_type_hint"] = token_type

        if self._config.client_secret:
            body["client_secret"] = self._config.client_secret

        try:
            await self._http.post("/oauth/revoke", json=body)
        except Exception:
            pass  # RFC 7009: limpiamos igualmente

        await self._storage.clear_tokens()

    async def get_access_token(self) -> str:
        """Obtiene un access token válido, refrescando automáticamente si expiró.

        Returns:
            Access token valido.

        Raises:
            RuntimeError: Si no hay tokens disponibles.
        """
        tokens = await self._storage.get_tokens()
        if not tokens:
            raise RuntimeError(
                "No hay tokens OAuth. El usuario debe iniciar sesión primero."
            )

        # Margen de 30 segundos para evitar tokens a punto de expirar
        if tokens.expires_at < time.time() + 30:
            async with self._refresh_lock:
                tokens = await self._storage.get_tokens()
                if tokens and tokens.expires_at < time.time() + 30:
                    new_tokens = await self.refresh_token()
                    return new_tokens.access_token
            if tokens is None:
                raise RuntimeError(
                    "No hay tokens OAuth. El usuario debe iniciar sesión primero."
                )
            return tokens.access_token

        return tokens.access_token

    async def is_authenticated(self) -> bool:
        """Verifica si hay una sesión OAuth activa con tokens válidos.

        Returns:
            True si hay tokens almacenados y el access token no ha expirado
            (o si hay un refresh token disponible para renovarlo).
        """
        tokens = await self._storage.get_tokens()
        if not tokens:
            return False
        if tokens.expires_at > time.time() + 30:
            return True
        return tokens.refresh_token is not None

    async def logout(self) -> None:
        """Cierra la sesión OAuth: revoca los tokens y limpia el almacenamiento."""
        await self.revoke_token()

    async def _get_pending_state(self) -> PendingOAuthState | None:
        """Recupera el estado PKCE pendiente del storage o memoria."""
        stored = await self._storage.get_pending_state()
        if stored:
            return stored
        return self._pending_state

    async def _clear_pending_state(self) -> None:
        """Limpia el estado PKCE pendiente."""
        self._pending_state = None
        await self._storage.clear_pending_state()


class OAuthSyncService:
    """Servicio síncrono que gestiona el flujo OAuth 2.1 con PKCE."""

    def __init__(self, base_url: str, config: OAuthConfig) -> None:
        self._base_url = base_url.rstrip("/")
        self._config = config
        self._storage: SyncTokenStorage = (
            config.token_storage if config.token_storage is not None
            else MemoryTokenStorage()
        )
        self._http = httpx.Client(
            base_url=self._base_url,
            timeout=30.0,
            headers={"Content-Type": "application/json"},
        )
        self._pending_state: PendingOAuthState | None = None

    def close(self) -> None:
        """Cierra el cliente HTTP interno."""
        self._http.close()

    def set_storage(self, storage: SyncTokenStorage) -> None:
        """Establece el almacenamiento de tokens personalizado."""
        self._storage = storage

    def get_authorization_url(
        self,
        *,
        state: str | None = None,
        scopes: list[str] | None = None,
    ) -> str:
        """Genera la URL de autorización OAuth con PKCE y almacena el estado
        pendiente automáticamente.

        Args:
            state: Valor de state personalizado para protección CSRF.
            scopes: Scopes a solicitar.

        Returns:
            URL de autorización lista para redirigir al usuario.
        """
        result = self.get_login_url(state=state, scopes=scopes)

        pending = PendingOAuthState(
            code_verifier=result.code_verifier,
            state=result.state,
        )

        self._pending_state = pending
        self._storage.set_pending_state_sync(pending)

        return result.url

    def get_login_url(
        self,
        *,
        state: str | None = None,
        scopes: list[str] | None = None,
    ) -> LoginUrlResult:
        """Genera la URL de inicio de sesión OAuth con PKCE (control manual)."""
        code_verifier = generate_code_verifier()
        code_challenge = generate_code_challenge(code_verifier)
        actual_state = state or secrets.token_urlsafe(32)
        actual_scopes = scopes or self._config.scopes

        params = urlencode({
            "response_type": "code",
            "client_id": self._config.client_id,
            "redirect_uri": self._config.redirect_uri,
            "scope": " ".join(actual_scopes),
            "state": actual_state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        })

        return LoginUrlResult(
            url=f"{self._base_url}/oauth/authorize?{params}",
            code_verifier=code_verifier,
            state=actual_state,
        )

    def handle_callback(
        self,
        code: str,
        code_verifier: str | None = None,
        callback_state: str | None = None,
    ) -> OAuthTokens:
        """Intercambia el código de autorización por tokens.

        Si se llama sin code_verifier, recupera automáticamente el estado PKCE
        almacenado por get_authorization_url().
        """
        verifier = code_verifier

        if not verifier:
            pending = self._get_pending_state()
            if not pending:
                raise RuntimeError(
                    "No se encontró el estado PKCE pendiente. Usa get_authorization_url() "
                    "antes de handle_callback(), o proporciona el code_verifier manualmente."
                )

            verifier = pending.code_verifier

            if callback_state and callback_state != pending.state:
                self._clear_pending_state()
                raise RuntimeError(
                    f"El valor de state no coincide. Posible ataque CSRF. "
                    f"Esperado: {pending.state}, recibido: {callback_state}"
                )

            self._clear_pending_state()

        body: dict[str, str] = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self._config.redirect_uri,
            "code_verifier": verifier,
            "client_id": self._config.client_id,
        }

        if self._config.client_secret:
            body["client_secret"] = self._config.client_secret

        response = self._http.post("/oauth/token", json=body)
        response.raise_for_status()
        data = response.json()

        tokens = OAuthTokens(
            access_token=data["access_token"],
            token_type=data.get("token_type", "Bearer"),
            expires_in=data["expires_in"],
            expires_at=time.time() + data["expires_in"],
            refresh_token=data.get("refresh_token"),
            scope=data.get("scope"),
            id_token=data.get("id_token"),
        )

        self._storage.set_tokens_sync(tokens)
        return tokens

    def refresh_token(self) -> OAuthTokens:
        """Refresca el token de acceso usando el refresh_token."""
        current = self._storage.get_tokens_sync()
        if not current or not current.refresh_token:
            raise RuntimeError(
                "No hay refresh token disponible. El usuario debe volver a autenticarse."
            )

        body: dict[str, str] = {
            "grant_type": "refresh_token",
            "refresh_token": current.refresh_token,
            "client_id": self._config.client_id,
        }

        if self._config.client_secret:
            body["client_secret"] = self._config.client_secret

        response = self._http.post("/oauth/token", json=body)
        response.raise_for_status()
        data = response.json()

        tokens = OAuthTokens(
            access_token=data["access_token"],
            token_type=data.get("token_type", "Bearer"),
            expires_in=data["expires_in"],
            expires_at=time.time() + data["expires_in"],
            refresh_token=data.get("refresh_token", current.refresh_token),
            scope=data.get("scope"),
            id_token=data.get("id_token"),
        )

        self._storage.set_tokens_sync(tokens)
        return tokens

    def get_user_info(self) -> OAuthUserInfo:
        """Obtiene información del usuario autenticado."""
        access_token = self.get_access_token()
        response = self._http.get(
            "/oauth/userinfo",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        response.raise_for_status()
        data = response.json()

        return OAuthUserInfo(
            sub=data["sub"],
            name=data.get("name"),
            email=data.get("email"),
            email_verified=data.get("email_verified"),
            picture=data.get("picture"),
            given_name=data.get("given_name"),
            family_name=data.get("family_name"),
        )

    def revoke_token(self, token_type: str | None = None) -> None:
        """Revoca el token actual."""
        current = self._storage.get_tokens_sync()
        if not current:
            return

        token = (
            current.refresh_token if token_type == "refresh_token"
            else current.access_token
        )

        if not token:
            return

        body: dict[str, str] = {
            "token": token,
            "client_id": self._config.client_id,
        }

        if token_type:
            body["token_type_hint"] = token_type

        if self._config.client_secret:
            body["client_secret"] = self._config.client_secret

        try:
            self._http.post("/oauth/revoke", json=body)
        except Exception:
            pass

        self._storage.clear_tokens_sync()

    def get_access_token(self) -> str:
        """Obtiene un access token válido, refrescando automáticamente si expiró."""
        tokens = self._storage.get_tokens_sync()
        if not tokens:
            raise RuntimeError(
                "No hay tokens OAuth. El usuario debe iniciar sesión primero."
            )

        if tokens.expires_at < time.time() + 30:
            refreshed = self.refresh_token()
            return refreshed.access_token

        return tokens.access_token

    def is_authenticated(self) -> bool:
        """Verifica si hay una sesión OAuth activa con tokens válidos."""
        tokens = self._storage.get_tokens_sync()
        if not tokens:
            return False
        if tokens.expires_at > time.time() + 30:
            return True
        return tokens.refresh_token is not None

    def logout(self) -> None:
        """Cierra la sesión OAuth: revoca los tokens y limpia el almacenamiento."""
        self.revoke_token()

    def _get_pending_state(self) -> PendingOAuthState | None:
        """Recupera el estado PKCE pendiente del storage o memoria."""
        stored = self._storage.get_pending_state_sync()
        if stored:
            return stored
        return self._pending_state

    def _clear_pending_state(self) -> None:
        """Limpia el estado PKCE pendiente."""
        self._pending_state = None
        self._storage.clear_pending_state_sync()
