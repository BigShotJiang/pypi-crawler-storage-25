"""
Wrapper síncrono del cliente HTTP asíncrono.

Permite usar el SDK sin necesidad de async/await,
ejecutando las corrutinas en un event loop dedicado.
"""

from __future__ import annotations

import asyncio
import threading
from collections.abc import Generator
from typing import Any

import httpx

from utilia_sdk._client import UtiliaClient, _parse_sse_event
from utilia_sdk.auth.oauth import OAuthSyncService
from utilia_sdk.auth.token_storage import MemoryTokenStorage
from utilia_sdk.errors import ErrorCode, UtiliaSDKError
from utilia_sdk.models.config import UtiliaSDKConfig
from utilia_sdk.models.oauth import OAuthConfig


class UtiliaSyncClient:
    """Cliente HTTP síncrono que envuelve al cliente asíncrono.

    Usa un event loop interno dedicado para ejecutar las operaciones.
    Soporta autenticación por API Key u OAuth 2.1 con PKCE.
    """

    _oauth_service: OAuthSyncService | None

    def __init__(self, config: UtiliaSDKConfig) -> None:
        self._config = config
        self._loop = asyncio.new_event_loop()
        self._oauth_service = None

        if config.oauth:
            # Crear un storage compartido para que tanto el servicio síncrono
            # como el cliente asíncrono usen los mismos tokens
            shared_storage = config.oauth.token_storage or MemoryTokenStorage()

            # Crear un OAuthConfig con el storage compartido para el async client
            shared_oauth_config = OAuthConfig(
                client_id=config.oauth.client_id,
                redirect_uri=config.oauth.redirect_uri,
                client_secret=config.oauth.client_secret,
                scopes=config.oauth.scopes,
                token_storage=shared_storage,
            )

            # El async client usa el config con storage compartido
            shared_config = UtiliaSDKConfig(
                base_url=config.base_url,
                api_key=config.api_key,
                oauth=shared_oauth_config,
                timeout=config.timeout,
                retry_attempts=config.retry_attempts,
                debug=config.debug,
            )
            self._async_client = UtiliaClient(shared_config)

            # El sync service usa el mismo storage compartido
            self._oauth_service = OAuthSyncService(config.base_url, shared_oauth_config)
            self._oauth_service.set_storage(shared_storage)
        else:
            self._async_client = UtiliaClient(config)

    @property
    def oauth(self) -> OAuthSyncService:
        """Acceso al servicio OAuth síncrono (solo disponible en modo OAuth)."""
        if self._oauth_service is None:
            raise UtiliaSDKError(
                ErrorCode.VALIDATION_ERROR,
                "El servicio OAuth no está disponible. Configura oauth en el constructor.",
            )
        return self._oauth_service

    def close(self) -> None:
        """Cierra la sesión HTTP, el servicio OAuth y el event loop."""
        if self._oauth_service is not None:
            self._oauth_service.close()
        self._loop.run_until_complete(self._async_client.close())
        self._loop.close()

    def __enter__(self) -> UtiliaSyncClient:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def get(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        """Realiza una petición GET síncrona."""
        return self._loop.run_until_complete(self._async_client.get(url, params=params))

    def post(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición POST síncrona."""
        return self._loop.run_until_complete(
            self._async_client.post(url, data, params=params)
        )

    def patch(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición PATCH síncrona."""
        return self._loop.run_until_complete(
            self._async_client.patch(url, data, params=params)
        )

    def put(
        self,
        url: str,
        data: Any | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición PUT síncrona."""
        return self._loop.run_until_complete(
            self._async_client.put(url, data, params=params)
        )

    def delete(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        """Realiza una petición DELETE síncrona."""
        return self._loop.run_until_complete(
            self._async_client.delete(url, params=params)
        )

    def post_form(
        self,
        url: str,
        files: dict[str, Any],
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Realiza una petición POST con multipart/form-data síncrona."""
        return self._loop.run_until_complete(
            self._async_client.post_form(url, files, data)
        )

    def build_sse_url(self, path: str) -> str:
        """Construye URL completa para SSE con credenciales como query param."""
        base_url = self._async_client.build_sse_url(path)
        # Si estamos en modo OAuth y la URL no tiene credenciales, inyectar token
        if self._oauth_service and "apiKey=" not in base_url and "access_token=" not in base_url:
            try:
                from urllib.parse import quote
                access_token = self._oauth_service.get_access_token()
                separator = "&" if "?" in base_url else "?"
                return f"{base_url}{separator}access_token={quote(access_token, safe='')}"
            except RuntimeError:
                pass
        return base_url

    def stream_sse(
        self,
        url: str,
        *,
        timeout: float = 120.0,
        cancel_event: threading.Event | None = None,
    ) -> Generator[dict[str, Any], None, None]:
        """Abre una conexión SSE síncrona y yield de cada evento parseado.

        Args:
            url: URL completa (generada con build_sse_url).
            timeout: Timeout máximo de la conexión en segundos.
            cancel_event: Evento threading para cancelar la lectura.

        Yields:
            Diccionarios con los datos de cada evento SSE.
        """
        with httpx.Client(timeout=httpx.Timeout(timeout)) as sse_client:
            with sse_client.stream("GET", url) as response:
                response.raise_for_status()
                buffer = ""
                for chunk in response.iter_text():
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_text, buffer = buffer.split("\n\n", 1)
                        parsed = _parse_sse_event(event_text)
                        if parsed is not None:
                            yield parsed
                        if cancel_event is not None and cancel_event.is_set():
                            return
