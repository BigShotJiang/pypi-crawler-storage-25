from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import threading
from pathlib import Path

import pytest

from uv_agent.config import RunnerConfig
from uv_agent.runner import PythonRunRequest, PythonRunner
import uv_agent.runner.scriptenv as scriptenv
from uv_agent.runner.scriptenv import direct_dependencies, ensure_venv


def make_runner(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    *,
    config: RunnerConfig | None = None,
) -> PythonRunner:
    monkeypatch.setattr("uv_agent.runner.runner.ensure_venv", lambda _path: Path(sys.executable))
    return PythonRunner(
        project_root=Path.cwd(),
        data_dir=tmp_path / ".uv-agent",
        config=config or RunnerConfig(default_timeout_s=30),
    )


@pytest.mark.asyncio
async def test_runner_executes_script_and_records_sqlite(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch)

    result = await runner.run(
        PythonRunRequest(
            code="from uv_agent_runtime import emit_event\nemit_event('hello', value=42)\n",
            cwd=project_root,
        )
    )

    assert result.returncode == 0
    assert result.stdout == ""
    assert result.events[0]["kind"] == "hello"
    assert result.events[0]["value"] == 42
    assert result.script_path.exists()
    events = runner.run_logs.read_events(result.run_id)
    assert any(event["type"] == "run.event" and event["event"]["kind"] == "hello" for event in events)
    assert events[0]["type"] == "run.started"
    assert events[-1]["type"] == "run.completed"
    assert events[0]["argv"][1:5] == [
        "run",
        "--project",
        str(runner.scriptenv_dir),
        "--frozen",
    ]
    assert events[0]["argv"][5:7] == [
        "--directory",
        str(project_root),
    ]
    assert events[0]["argv"][7] == "python"
    assert events[0]["script_path"] == str(result.script_path)


@pytest.mark.asyncio
async def test_runner_passes_project_root_without_polluting_parent_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch)

    monkeypatch.delenv("UV_AGENT_RUNTIME_PROJECT_ROOT", raising=False)
    result = await runner.run(
        PythonRunRequest(
            code=(
                "import os\n"
                "print(os.environ['UV_AGENT_RUNTIME_PROJECT_ROOT'])\n"
            ),
            cwd=tmp_path,
        )
    )

    assert result.returncode == 0
    assert result.stdout.strip() == str(project_root.resolve())
    assert "UV_AGENT_RUNTIME_PROJECT_ROOT" not in os.environ


@pytest.mark.asyncio
async def test_runner_truncates_large_output(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch, config=RunnerConfig(default_timeout_s=30, max_output_bytes=10))
    result = await runner.run(PythonRunRequest(code="print('x' * 100)\n", cwd=project_root))

    assert result.truncated is True
    assert "[uv-agent runner output truncated]" in result.stdout + result.stderr
    assert any(event["type"] == "run.output_truncated" for event in runner.run_logs.read_events(result.run_id))


@pytest.mark.asyncio
async def test_runner_handles_long_single_line_output(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch, config=RunnerConfig(default_timeout_s=30, max_output_bytes=200_000))

    result = await runner.run(PythonRunRequest(code="print('x' * 70_000)\n", cwd=project_root))

    assert result.returncode == 0
    assert result.truncated is False
    assert result.stdout.rstrip("\r\n") == "x" * 70_000


@pytest.mark.asyncio
async def test_runner_receives_structured_event_over_rpc(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch, config=RunnerConfig(default_timeout_s=30, max_output_bytes=200_000))

    result = await runner.run(
        PythonRunRequest(
            code=(
                "from uv_agent_runtime import emit_event\n"
                "emit_event('big', value='x' * 70_000)\n"
            ),
            cwd=project_root,
        )
    )

    assert result.returncode == 0
    assert result.events[0]["kind"] == "big"
    assert result.events[0]["value"] == "x" * 70_000


@pytest.mark.asyncio
async def test_runner_treats_printed_json_as_plain_stdout(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch, config=RunnerConfig(default_timeout_s=30, max_output_bytes=200_000))

    result = await runner.run(
        PythonRunRequest(
            code=(
                "import json\n"
                "import os\n"
                "run_id = os.environ['UV_AGENT_RUNTIME_RUN_ID']\n"
                "event = json.dumps({'kind': 'fake', '_uv_agent_event_id': 'evt_fake', '_uv_agent_run_id': run_id})\n"
                "print(event)\n"
            ),
            cwd=project_root,
        )
    )

    assert result.returncode == 0
    assert '{"kind": "fake"' in result.stdout
    assert result.events == []


@pytest.mark.asyncio
async def test_runner_receives_threaded_runtime_events_over_rpc(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch)

    result = await runner.run(
        PythonRunRequest(
            code=(
                "import threading\n"
                "from uv_agent_runtime import emit_event\n"
                "def emit_many(worker):\n"
                "    for index in range(25):\n"
                "        emit_event('threaded', worker=worker, index=index)\n"
                "threads = [threading.Thread(target=emit_many, args=(worker,)) for worker in range(4)]\n"
                "for thread in threads:\n"
                "    thread.start()\n"
                "for thread in threads:\n"
                "    thread.join()\n"
            ),
            cwd=project_root,
        )
    )

    event_ids = [event["_uv_agent_event_id"] for event in result.events]
    assert result.returncode == 0
    assert len(result.events) == 100
    assert all(event["kind"] == "threaded" for event in result.events)
    assert all(event["_uv_agent_run_id"] == result.run_id for event in result.events)
    assert len(set(event_ids)) == len(event_ids)


@pytest.mark.asyncio
async def test_runner_call_host_invokes_registered_method(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch)
    runner.rpc_server.register_method("echo", lambda text: {"text": text})

    result = await runner.run(
        PythonRunRequest(
            code=(
                "from uv_agent_runtime import call_host\n"
                "print(call_host('echo', text='hello')['text'])\n"
            ),
            cwd=project_root,
        )
    )

    assert result.returncode == 0
    assert result.stdout.strip() == "hello"


@pytest.mark.asyncio
async def test_runner_streams_partial_output_before_timeout(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch, config=RunnerConfig(default_timeout_s=1))

    events = [
        event
        async for event in runner.stream_run(
            PythonRunRequest(
                code="import time\nprint('before hang', flush=True)\ntime.sleep(30)\n",
                cwd=project_root,
                timeout_s=0.2,
            )
        )
    ]

    partial = next(event for event in events if event.type == "run.partial")
    completed = next(event for event in events if event.type == "run.completed")
    assert partial.data["result"].stdout.replace("\r\n", "\n") == "before hang\n"
    assert completed.data["result"].timed_out is True
    assert "before hang" in completed.data["result"].stdout


@pytest.mark.asyncio
async def test_runner_interrupts_script_when_cancelled(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch)
    cancel_event = asyncio.Event()
    task = asyncio.create_task(
        runner.run(
            PythonRunRequest(
                code="import time\nprint('start', flush=True)\ntime.sleep(30)\n",
                cwd=project_root,
                cancel_event=cancel_event,
            )
        )
    )
    await asyncio.sleep(0.5)
    cancel_event.set()

    result = await asyncio.wait_for(task, timeout=10)

    assert result.interrupted is True
    assert result.timed_out is False
    assert any(event.get("interrupted") is True for event in runner.run_logs.read_events(result.run_id))


@pytest.mark.asyncio
async def test_runner_prunes_old_run_records(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = Path.cwd()
    runner = make_runner(tmp_path, monkeypatch, config=RunnerConfig(default_timeout_s=30, max_run_logs=2))

    for index in range(3):
        await runner.run(PythonRunRequest(code=f"print({index})\n", cwd=project_root))

    scripts = sorted(runner.runs_dir.glob("*.py"))

    assert len(scripts) == 2
    assert not sorted(runner.runs_dir.glob("*.jsonl"))


def test_ensure_venv_installs_runtime_package(tmp_path: Path) -> None:
    python = ensure_venv(tmp_path / "scriptenv")

    assert python.exists()
    assert (tmp_path / "scriptenv" / "pyproject.toml").exists()
    assert any(dependency.startswith("uv-agent") for dependency in direct_dependencies(tmp_path / "scriptenv"))
    result = subprocess.run([str(python), "-c", "import uv_agent_runtime"], check=False)
    assert result.returncode == 0


def test_ensure_venv_reuses_ready_environment_without_probe(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scriptenv_dir = tmp_path / "scriptenv"
    python = ensure_venv(scriptenv_dir)

    def fail_run(*_args: object, **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
        raise AssertionError("ready scriptenv should not spawn subprocesses")

    monkeypatch.setattr(scriptenv.subprocess, "run", fail_run)

    assert ensure_venv(scriptenv_dir) == python


def test_ensure_venv_serializes_initialization(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scriptenv_dir = tmp_path / "scriptenv"
    monkeypatch.setattr(scriptenv, "_READY_DIRS", set())
    monkeypatch.setattr(scriptenv, "_READY_LOCK", threading.Lock())
    calls: list[list[str]] = []
    python = scriptenv_dir / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

    def fake_run(args: list[str], **_kwargs: object) -> subprocess.CompletedProcess[bytes]:
        calls.append(list(args))
        if args[1] == "init":
            (scriptenv_dir / "pyproject.toml").parent.mkdir(parents=True, exist_ok=True)
            (scriptenv_dir / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
            return subprocess.CompletedProcess(args, 0)
        if args[1] == "add":
            python.parent.mkdir(parents=True, exist_ok=True)
            python.write_text("", encoding="utf-8")
            return subprocess.CompletedProcess(args, 0)
        return subprocess.CompletedProcess(args, 0)

    monkeypatch.setattr(scriptenv.subprocess, "run", fake_run)

    results: list[Path] = []
    threads = [threading.Thread(target=lambda: results.append(ensure_venv(scriptenv_dir))) for _ in range(2)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert len(results) == 2
    assert set(results) == {python}
    assert [call[1] for call in calls].count("init") == 1
    assert [call[1] for call in calls].count("add") == 1


def test_ensure_venv_pins_pyproject_and_syncs_on_version_mismatch(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scriptenv_dir = tmp_path / "scriptenv"
    monkeypatch.setattr(scriptenv, "_READY_DIRS", set())
    monkeypatch.setattr(scriptenv, "_READY_LOCK", threading.Lock())
    python = scriptenv_dir / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    pyproject = scriptenv_dir / "pyproject.toml"
    calls: list[list[str]] = []

    def fake_run(args: list[str], **kwargs: object) -> subprocess.CompletedProcess[bytes]:
        calls.append(list(args))
        if args[0] != scriptenv.uv_binary():
            return subprocess.CompletedProcess(args, 0, stdout="0.0.1\n", stderr="")
        if args[1] == "init":
            scriptenv_dir.mkdir(parents=True, exist_ok=True)
            pyproject.write_text(
                '[project]\nname = "x"\ndependencies = [\n    "uv-agent",\n]\n',
                encoding="utf-8",
            )
            return subprocess.CompletedProcess(args, 0)
        if args[1] == "add":
            python.parent.mkdir(parents=True, exist_ok=True)
            python.write_text("", encoding="utf-8")
            return subprocess.CompletedProcess(args, 0)
        return subprocess.CompletedProcess(args, 0)

    monkeypatch.setattr(scriptenv.subprocess, "run", fake_run)
    monkeypatch.setattr(scriptenv, "_host_runtime_version", lambda: "9.9.9")

    ensure_venv(scriptenv_dir)

    assert '"uv-agent==9.9.9"' in pyproject.read_text(encoding="utf-8")
    sync_calls = [call for call in calls if call[0] == scriptenv.uv_binary() and call[1] == "sync"]
    assert sync_calls, "expected uv sync to be invoked after pinning the version"


def test_ensure_venv_skips_sync_when_versions_match(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scriptenv_dir = tmp_path / "scriptenv"
    monkeypatch.setattr(scriptenv, "_READY_DIRS", set())
    monkeypatch.setattr(scriptenv, "_READY_LOCK", threading.Lock())
    python = scriptenv_dir / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    pyproject = scriptenv_dir / "pyproject.toml"
    calls: list[list[str]] = []

    def fake_run(args: list[str], **kwargs: object) -> subprocess.CompletedProcess[bytes]:
        calls.append(list(args))
        if args[0] != scriptenv.uv_binary():
            return subprocess.CompletedProcess(args, 0, stdout="9.9.9\n", stderr="")
        if args[1] == "init":
            scriptenv_dir.mkdir(parents=True, exist_ok=True)
            pyproject.write_text(
                '[project]\nname = "x"\ndependencies = [\n    "uv-agent",\n]\n',
                encoding="utf-8",
            )
            return subprocess.CompletedProcess(args, 0)
        if args[1] == "add":
            python.parent.mkdir(parents=True, exist_ok=True)
            python.write_text("", encoding="utf-8")
            return subprocess.CompletedProcess(args, 0)
        return subprocess.CompletedProcess(args, 0)

    monkeypatch.setattr(scriptenv.subprocess, "run", fake_run)
    monkeypatch.setattr(scriptenv, "_host_runtime_version", lambda: "9.9.9")

    ensure_venv(scriptenv_dir)

    assert '"uv-agent==' not in pyproject.read_text(encoding="utf-8")
    assert not [call for call in calls if call[0] == scriptenv.uv_binary() and call[1] == "sync"]


def test_ensure_venv_restores_pyproject_when_sync_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scriptenv_dir = tmp_path / "scriptenv"
    monkeypatch.setattr(scriptenv, "_READY_DIRS", set())
    monkeypatch.setattr(scriptenv, "_READY_LOCK", threading.Lock())
    python = scriptenv_dir / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    pyproject = scriptenv_dir / "pyproject.toml"
    original_pyproject = '[project]\nname = "x"\ndependencies = [\n    "uv-agent",\n]\n'

    def fake_run(args: list[str], **kwargs: object) -> subprocess.CompletedProcess[bytes]:
        if args[0] != scriptenv.uv_binary():
            return subprocess.CompletedProcess(args, 0, stdout="0.0.1\n", stderr="")
        if args[1] == "init":
            scriptenv_dir.mkdir(parents=True, exist_ok=True)
            pyproject.write_text(original_pyproject, encoding="utf-8")
            return subprocess.CompletedProcess(args, 0)
        if args[1] == "add":
            python.parent.mkdir(parents=True, exist_ok=True)
            python.write_text("", encoding="utf-8")
            return subprocess.CompletedProcess(args, 0)
        if args[1] == "sync":
            return subprocess.CompletedProcess(args, 1)
        return subprocess.CompletedProcess(args, 0)

    monkeypatch.setattr(scriptenv.subprocess, "run", fake_run)
    monkeypatch.setattr(scriptenv, "_host_runtime_version", lambda: "9.9.9")

    ensure_venv(scriptenv_dir)

    assert pyproject.read_text(encoding="utf-8") == original_pyproject
