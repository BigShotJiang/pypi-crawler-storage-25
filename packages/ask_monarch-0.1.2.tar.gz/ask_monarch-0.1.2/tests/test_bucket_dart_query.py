import json
import os
import sqlite3
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class BucketDartQueryTests(unittest.TestCase):
    def test_natural_query_routes_to_typed_dart_concentration_table(self):
        import serve_http

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            status_path = os.path.join(tmp, "source_status.json")
            gaps_path = os.path.join(tmp, "gaps.json")
            with open(status_path, "w", encoding="utf-8") as handle:
                json.dump({}, handle)
            with open(gaps_path, "w", encoding="utf-8") as handle:
                json.dump([], handle)
            conn = sqlite3.connect(db_path)
            conn.executescript(
                """
                CREATE TABLE dart_assay_results (
                  source_name TEXT,
                  sheet TEXT,
                  row_number INTEGER,
                  species TEXT,
                  assay_type TEXT,
                  treatment TEXT,
                  treatment_normalized TEXT,
                  dilution TEXT,
                  dilution_real REAL,
                  avg_pi_real REAL,
                  filename TEXT,
                  provenance_grain TEXT
                );
                """
            )
            conn.executemany(
                """
                INSERT INTO dart_assay_results
                (source_name, sheet, row_number, species, assay_type, treatment,
                 treatment_normalized, dilution, dilution_real, avg_pi_real, filename,
                 provenance_grain)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                [
                    ("mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx", "Assays", 10, "mosquitoes", "DART", "2PP", "2PP", "0.01", 0.01, -0.5, "a.mov", "{}"),
                    ("mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx", "Assays", 11, "mosquitoes", "DART", "2PP", "2PP", "0.01", 0.01, -0.7, "b.mov", "{}"),
                    ("mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx", "Assays", 12, "mosquitoes", "DART", "2PP", "2PP", "0.001", 0.001, -0.1, "c.mov", "{}"),
                ],
            )
            conn.commit()
            conn.close()

            source = serve_http.SourceIndex(db_path, status_path, gaps_path)
            result = source.query(
                {
                    "question": "what is the most effective concentration for 2-propylphenol in the mosquito DART assays?",
                    "limit": 5,
                    "routing_decision": {
                        "intent": "dart_best_concentration",
                        "source_lane": "bucket",
                        "retrieval_shape": "structured",
                        "adapter": "bucket_dart_best_concentration_helper",
                        "adapter_execution": "typed_helper",
                        "fallback_policy": "no_silent_prose_fallback",
                    },
                }
            )

        self.assertEqual(result["mode"], "dart_best_concentration")
        self.assertEqual(result["routing_decision"]["adapter"], "bucket_dart_best_concentration_helper")
        self.assertEqual(result["treatment"], "2PP")
        self.assertEqual(result["rows"][0]["dilution"], "0.01")
        self.assertAlmostEqual(result["rows"][0]["mean_avg_pi"], -0.6)


if __name__ == "__main__":
    unittest.main()
