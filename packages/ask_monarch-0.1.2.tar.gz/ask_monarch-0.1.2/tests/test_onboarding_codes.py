import os
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in __import__("sys").path:
    __import__("sys").path.insert(0, SCRIPTS)

from onboarding_codes import OnboardingCodeRegistry


class OnboardingCodesTest(unittest.TestCase):
    def test_create_generates_stable_code_without_storing_plaintext(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = OnboardingCodeRegistry(
                os.path.join(tmp, "codes.json"),
                now=lambda: 1000.0,
                code_generator=lambda: "MNR-ABCD-1234",
            )

            created = registry.create(email="amir@example.com")
            exchanged = registry.exchange("mnr-abcd-1234")
            reused = registry.exchange("MNR-ABCD-1234")

            self.assertEqual(created["code"], "MNR-ABCD-1234")
            self.assertTrue(created["reusable"])
            with open(os.path.join(tmp, "codes.json"), encoding="utf-8") as handle:
                self.assertNotIn("MNR-ABCD-1234", handle.read())
            self.assertTrue(exchanged["ok"])
            self.assertTrue(reused["ok"])
            self.assertEqual(reused["exchange_count"], 2)

    def test_expired_code_is_rejected(self):
        now = [1000.0]
        with tempfile.TemporaryDirectory() as tmp:
            registry = OnboardingCodeRegistry(
                os.path.join(tmp, "codes.json"),
                now=lambda: now[0],
                code_generator=lambda: "MNR-ABCD-1234",
            )

            registry.create(ttl_seconds=60, reusable=False)
            now[0] = 2000.0
            result = registry.exchange("MNR-ABCD-1234")

            self.assertFalse(result["ok"])
            self.assertEqual(result["gap"], "setup_code_expired")


if __name__ == "__main__":
    unittest.main()
