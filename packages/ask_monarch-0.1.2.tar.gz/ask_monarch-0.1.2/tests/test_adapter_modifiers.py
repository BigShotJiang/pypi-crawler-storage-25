import json
import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class AdapterModifierRegistryTests(unittest.TestCase):
    def test_modifier_registry_covers_every_declared_structured_adapter(self):
        import routing_decision

        with open(os.path.join(ROOT, "config", "query-routing.json"), "r", encoding="utf-8") as handle:
            routing = json.load(handle)
        registry = routing_decision.load_adapter_modifier_registry()
        registered = set(registry["adapters"])

        declared = set()
        for source_config in routing["sources"].values():
            declared.update(source_config.get("structured_adapters", []))

        self.assertEqual(sorted(declared - registered), [])

    def test_every_modifier_contract_declares_supported_and_must_not_ignore_lists(self):
        import routing_decision

        registry = routing_decision.load_adapter_modifier_registry()
        known_modifiers = set(registry["modifiers"])
        for adapter, contract in registry["adapters"].items():
            with self.subTest(adapter=adapter):
                self.assertTrue(contract.get("family"))
                self.assertTrue(contract.get("intent"))
                supported = contract.get("supported_modifiers")
                must_not_ignore = contract.get("must_not_ignore_modifiers")
                self.assertIsInstance(supported, list)
                self.assertIsInstance(must_not_ignore, list)
                self.assertEqual(sorted(set(supported) - known_modifiers), [])
                self.assertEqual(sorted(set(must_not_ignore) - known_modifiers), [])

    def test_fly_assay_count_supports_last_30_days_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how many fly assays were run in the last 30 days",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_inventory_count")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("count_unit", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("'last_30_days' AS date_window", payload["sql"])
        self.assertIn("FROM assay_runs", payload["sql"])

    def test_structured_adapter_refuses_unsupported_quality_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how many usable fly assays have we run",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("quality", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("coalesce(r.usable_data, '1') != '0'", payload["sql"])

    def test_repellent_ranking_supports_date_window_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what are the top mosquito repellents in the last 30 days",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("LEFT JOIN assay_runs a", payload["sql"])
        self.assertIn("'last_30_days' AS date_window", payload["sql"])

    def test_mosquito_contact_noncontact_ranking_supports_species_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what compound has been the most repellent in contact / no contact for mosquitoes",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("assay_mode", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("species", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("r.species = 'mosquitoes'", payload["sql"])
        self.assertIn("r.assay_family = 'contact_no_contact'", payload["sql"])
        self.assertIn("FROM assay_results r", payload["sql"])

    def test_fly_contact_noncontact_ranking_supports_species_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what compound has been the most repellent in contact / no contact for flies",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("assay_mode", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("species", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("r.species = 'flies'", payload["sql"])
        self.assertIn("r.assay_family = 'contact_no_contact'", payload["sql"])
        self.assertIn("FROM assay_results r", payload["sql"])

    def test_fly_contact_noncontact_ranking_supports_last_month_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what compound has been the most repellent in contact / no contact for flies in the last 1 month",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("'last_1_month' AS date_window", payload["sql"])
        self.assertIn("date(coalesce(a.run_date, r.timepoint)) >=", payload["sql"])

    def test_scientific_modifier_detection_covers_assay_design_and_methods(self):
        import routing_decision

        modifiers = routing_decision._detected_question_modifiers(
            "does tube position affect fly PI for starved flies"
        )

        self.assertIn("assay_design", modifiers)
        self.assertIn("tube_position", modifiers)
        self.assertIn("starvation_state", modifiers)
        self.assertIn("metric", modifiers)
        self.assertIn("species", modifiers)

    def test_repellent_ranking_refuses_minimum_replicates_until_supported(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "top mosquito repellents with at least 3 experiments",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "source_gap")
        self.assertEqual(payload["routing_decision"]["missing_adapter"], "bucket_top_repellents_by_species_sql_modifier_support")
        self.assertIn("minimum_replicates", payload["routing_decision"]["unsupported_modifiers"])
        self.assertIn("replicate_strength", payload["routing_decision"]["unsupported_modifiers"])

    def test_broad_repellent_ranking_supports_last_month_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what are the top repellent compounds in the last 1 month",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("'last_1_month' AS date_window", payload["sql"])
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("LEFT JOIN assay_runs a", payload["sql"])

    def test_fly_repellency_ranking_supports_last_month_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what are the top fly repellents in the last 1 month",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("'last_1_month' AS date_window", payload["sql"])
        self.assertIn("r.species = 'flies'", payload["sql"])
        self.assertIn("FROM assay_results r", payload["sql"])

    def test_contact_noncontact_refuses_late_effect_modifier_until_rankable(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what compound has been the most repellent in contact / no contact for mosquitoes by late effect",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "source_gap")
        self.assertEqual(payload["routing_decision"]["missing_adapter"], "bucket_contact_noncontact_adjusted_pi_comparison_sql_modifier_support")
        self.assertIn("metric_variant", payload["routing_decision"]["unsupported_modifiers"])
        self.assertIn("time_in_trial", payload["routing_decision"]["unsupported_modifiers"])

    def test_recency_order_is_not_metric_rank(self):
        import routing_decision

        modifiers = routing_decision._detected_question_modifiers(
            "list the most recent fly dart assays"
        )

        self.assertIn("recency_order", modifiers)
        self.assertIn("date_window", modifiers)
        self.assertNotIn("rank", modifiers)

        ranking_modifiers = routing_decision._detected_question_modifiers(
            "rank the most effective repellents in the dart assay for mosquitoes in the last 1 month"
        )
        self.assertIn("date_window", ranking_modifiers)
        self.assertIn("rank", ranking_modifiers)
        self.assertNotIn("recency_order", ranking_modifiers)

    def test_ranking_adapter_refuses_recency_order_until_supported(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "latest top fly repellents",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "source_gap")
        self.assertEqual(payload["routing_decision"]["missing_adapter"], "bucket_fly_repellency_rankings_sql_modifier_support")
        self.assertIn("recency_order", payload["routing_decision"]["unsupported_modifiers"])

    def test_dart_timepoint_ranking_uses_individual_assay_timebin_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what time point in the last 10 dart assays was the most repellent",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_individual_assay_timepoint_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("recency_order", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("time_in_trial", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("LIMIT 10", payload["sql"])
        self.assertIn("results_by_time.csv", payload["sql"])
        self.assertIn("time_mid_min", payload["sql"])

    def test_contact_timepoint_ranking_uses_shared_individual_assay_timepoint_adapter(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "what time point in the last 10 contact assays for mosquitoes was the most repellent",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_individual_assay_timepoint_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "individual_assay_timepoint_ranking")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("time_in_trial", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("frame_metrics.csv", payload["sql"])
        self.assertIn("contact_pi", payload["sql"])

    def test_phytotox_rank_supports_chlorosis_modifier_via_serving_table(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "rank phytotoxic compounds by chlorosis fraction",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("chlorosis_fraction", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("r.metric_name IN ('chlorosis_fraction')", payload["sql"])

    def test_phytotox_ranking_supports_last_month_modifier(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "list the most phytotoxic compounds in the last 1 month",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertIn("date_window", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("'last_1_month' AS date_window", payload["sql"])
        self.assertIn("r.assay_family = 'phytotoxicity'", payload["sql"])
        self.assertIn("r.metric_name IN ('damaged_fraction')", payload["sql"])

    def test_oviposition_count_supports_last_month_modifier_without_position_false_positive(self):
        import routing_decision

        payload = routing_decision.query_payload_for_question(
            "how many oviposition assays were run in the last 1 month",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["modifier_trace"]["unsupported_modifiers"], [])
        self.assertNotIn("tube_position", payload["routing_decision"]["modifier_trace"]["detected_modifiers"])
        self.assertIn("'last_1_month' AS date_window", payload["sql"])
        self.assertIn("FROM assay_runs", payload["sql"])
        self.assertIn("r.assay_family IN ('fly_oviposition')", payload["sql"])

    def test_ml_modifier_detection_covers_model_dataset_failure_metrics(self):
        import routing_decision

        modifiers = routing_decision._detected_question_modifiers(
            "which YOLO detector trained on labeled images has the highest false positive rate after retrain"
        )

        self.assertIn("model_family", modifiers)
        self.assertIn("training_dataset", modifiers)
        self.assertIn("label_type", modifiers)
        self.assertIn("evaluation_metric", modifiers)
        self.assertIn("false_positive_rate", modifiers)
        self.assertIn("before_after_pipeline_change", modifiers)


if __name__ == "__main__":
    unittest.main()
