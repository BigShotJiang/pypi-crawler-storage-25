import importlib.util
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
ROUTER_PATH = ROOT / "experiments" / "semantic-router" / "semantic_router.py"


def load_router():
    spec = importlib.util.spec_from_file_location("semantic_router", ROUTER_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules["semantic_router"] = module
    spec.loader.exec_module(module)
    return module


class SemanticRouterPlaygroundTests(unittest.TestCase):
    def test_slot_embedding_text_is_stable_and_contains_examples(self):
        router = load_router()
        slot = {
            "slot": "company_profile.organisms",
            "source": "company_profile",
            "description": "Company-level organism scope.",
            "structured_query_hint": "units.unit_id = 'insects'",
            "examples": ["insects the company researches"],
            "exclude_if_question_contains": ["meeting"],
        }

        text = router.slot_embedding_text(slot)

        self.assertIn("company_profile.organisms", text)
        self.assertIn("insects the company researches", text)
        self.assertEqual(router.stable_hash(text), router.stable_hash(text))

    def test_cosine_similarity(self):
        router = load_router()

        self.assertAlmostEqual(router.cosine([1, 0], [1, 0]), 1.0)
        self.assertAlmostEqual(router.cosine([1, 0], [0, 1]), 0.0)

    def test_exclusion_rules_are_case_insensitive(self):
        router = load_router()

        self.assertEqual(
            router.excluded(
                "What did the TEAM discuss about insects?",
                {"exclude_if_question_contains": ["team discuss"]},
            ),
            "team discuss",
        )

    def test_sqlite_schema_is_created(self):
        router = load_router()
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "semantic_router.sqlite"
            conn = router.connect(db)
            rows = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            ).fetchall()
            conn.close()

        self.assertEqual([row["name"] for row in rows], ["build_metadata", "slot_embeddings"])


if __name__ == "__main__":
    unittest.main()
