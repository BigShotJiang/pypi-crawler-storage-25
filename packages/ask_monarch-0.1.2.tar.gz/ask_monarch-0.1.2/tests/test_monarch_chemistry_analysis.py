import csv
import io
import json
import os
import sqlite3
import sys
import tempfile
import unittest
import urllib.error


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


def fake_object(name, content_type="text/plain", generation="1", updated="2026-05-12T00:00:00Z"):
    return {
        "name": name,
        "bucket": "monarch-chemistry-analysis",
        "contentType": content_type,
        "size": "1",
        "generation": generation,
        "metageneration": "1",
        "md5Hash": "hash",
        "crc32c": "crc",
        "updated": updated,
        "timeCreated": updated,
    }


class MonarchChemistryAnalysisParserTests(unittest.TestCase):
    def test_build_index_materializes_chemistry_units_with_provenance(self):
        import parse_monarch_chemistry_analysis as chemistry

        csv_body = io.StringIO()
        writer = csv.DictWriter(csv_body, fieldnames=["compound", "assay", "score"])
        writer.writeheader()
        writer.writerow({"compound": "DEET", "assay": "phytotoxicity", "score": "0.12"})

        payloads = {
            "chemical_registry/chemical_activity_registry.csv": csv_body.getvalue().encode("utf-8"),
            "protein_structures/mosquitoes/aaeg/demo_relaxed_rank_001.pdb": (
                b"HEADER    ODORANT RECEPTOR\n"
                b"ATOM      1  N   MET A   1      11.104  13.207   9.111  1.00 82.00           N\n"
                b"ATOM      2  CA  MET A   1      12.104  13.207   9.111  1.00 90.00           C\n"
            ),
            "models/demo_scores_rank_001.json": json.dumps({"plddt": [90.0, 82.0], "ranking_confidence": 0.7}).encode("utf-8"),
            "scripts/analysis.py": b"print('chemistry analysis')\n",
        }
        objects = [
            fake_object("chemical_registry/chemical_activity_registry.csv", "text/csv"),
            fake_object("protein_structures/mosquitoes/aaeg/demo_relaxed_rank_001.pdb", "chemical/x-pdb"),
            fake_object("models/demo_scores_rank_001.json", "application/json"),
            fake_object("scripts/analysis.py", "text/x-python"),
        ]

        with tempfile.TemporaryDirectory() as tmp:
            result = chemistry.build_index_from_objects(
                objects,
                fetch_bytes=lambda name: payloads[name],
                out_dir=tmp,
            )

            self.assertEqual(result["status"]["total_objects"], 4)
            self.assertTrue(result["status"]["fully_parsed"])
            conn = sqlite3.connect(os.path.join(tmp, "source_index.sqlite"))
            conn.row_factory = sqlite3.Row

            csv_row = conn.execute(
                "SELECT row_json, provenance_grain FROM csv_rows_with_provenance"
            ).fetchone()
            self.assertIn("DEET", csv_row["row_json"])
            self.assertIn("gs://monarch-chemistry-analysis/chemical_registry/chemical_activity_registry.csv#row=1", csv_row["provenance_grain"])

            structure = conn.execute("SELECT * FROM protein_structures").fetchone()
            self.assertEqual(structure["atom_count"], 2)
            self.assertAlmostEqual(structure["mean_plddt"], 86.0)
            self.assertIn("#protein_structure", structure["provenance_grain"])

            score_unit = conn.execute(
                "SELECT * FROM json_units_with_provenance WHERE path='ranking_confidence'"
            ).fetchone()
            self.assertEqual(json.loads(score_unit["value_json"]), 0.7)

            search_hit = conn.execute(
                "SELECT unit_type, name, provenance_grain FROM source_search WHERE source_search MATCH 'DEET'"
            ).fetchone()
            self.assertEqual(search_hit["unit_type"], "csv_row")
            self.assertIn("monarch-chemistry-analysis", search_hit["provenance_grain"])

    def test_source_index_reports_chemistry_analysis_lane(self):
        import parse_monarch_chemistry_analysis as chemistry
        import serve_http

        objects = [fake_object("chemical_registry/chemical_activity_registry.csv", "text/csv")]
        payload = b"compound,assay\nDEET,phytotoxicity\n"

        with tempfile.TemporaryDirectory() as tmp:
            chemistry.build_index_from_objects(objects, fetch_bytes=lambda name: payload, out_dir=tmp)
            source = serve_http.SourceIndex(
                os.path.join(tmp, "source_index.sqlite"),
                os.path.join(tmp, "source_status.json"),
                os.path.join(tmp, "gaps.json"),
                source_name="chemistry_analysis",
                bucket_uri="gs://monarch-chemistry-analysis",
            )

            result = source.query({"source": "chemistry_analysis", "q": "DEET", "limit": 5})
            self.assertEqual(result["source"], "chemistry_analysis")
            self.assertEqual(result["rows"][0]["unit_type"], "csv_row")
            self.assertEqual(source.health()["bucket"], "gs://monarch-chemistry-analysis")

    def test_cli_accepts_chemistry_analysis_as_query_source(self):
        import ask_monarch

        self.assertIn("chemistry_analysis", ask_monarch.SOURCE_CHOICES)
        self.assertIn("chemistry_analysis", ask_monarch.SQL_SOURCE_CHOICES)

    def test_bucket_metadata_is_optional_when_object_access_is_available(self):
        import parse_monarch_chemistry_analysis as chemistry

        original = chemistry.request_json

        def forbidden(url, token):
            raise urllib.error.HTTPError(url, 403, "Forbidden", hdrs=None, fp=None)

        try:
            chemistry.request_json = forbidden
            metadata = chemistry.bucket_metadata("token")
        finally:
            chemistry.request_json = original

        self.assertEqual(metadata["bucket"], "gs://monarch-chemistry-analysis")
        self.assertEqual(metadata["metadata_status"], "unavailable")


if __name__ == "__main__":
    unittest.main()
