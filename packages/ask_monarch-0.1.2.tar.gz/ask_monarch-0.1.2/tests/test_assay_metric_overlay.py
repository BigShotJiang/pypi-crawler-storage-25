import json
import os
import sqlite3
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


def make_db():
    tmp = tempfile.TemporaryDirectory()
    db_path = os.path.join(tmp.name, "source_index.sqlite")
    conn = sqlite3.connect(db_path)
    conn.execute(
        """
        create table csv_rows_with_provenance (
            name text,
            row_number integer,
            row_json text,
            provenance_grain text
        )
        """
    )
    conn.execute(
        """
        create table objects (
            name text,
            uri text,
            kind text,
            ext text,
            size integer,
            content_type text,
            updated text
        )
        """
    )
    conn.execute(
        """
        create table assay_media_links (
            media_name text,
            assay_family text,
            treatment text,
            treatment_normalized text,
            tube text,
            assay_row_number integer
        )
        """
    )
    conn.execute(
        """
        create table xlsx_cells_with_provenance (
            name text,
            sheet text,
            cell text,
            row_number integer,
            value text
        )
        """
    )
    conn.execute(
        """
        create table json_units_with_provenance (
            name text,
            path text,
            value_json text,
            value_type text,
            generation text,
            provenance_grain text
        )
        """
    )
    conn.commit()
    return tmp, db_path, conn


class AssayMetricOverlayTests(unittest.TestCase):
    def test_fly_repellency_metadata_selects_treatment_tubes(self):
        import render_assay_metric_overlay as overlay

        tmp, db_path, conn = make_db()
        self.addCleanup(tmp.cleanup)
        self.addCleanup(conn.close)

        metric_csv = "flies/processed/2026-04-22 12-12-14_results/2026-04-22 12-12-14_results/advanced_metrics.csv"
        row = {
            "time_min": "50.5",
            "time_sec": "3030.0",
            "T1_avoidance": "0.1",
            "T2_avoidance": "0.1",
            "T3_avoidance": "0.1",
            "T4_avoidance": "0.1",
            "T5_avoidance": "0.8",
            "T6_avoidance": "0.6",
            "T7_avoidance": "0.7",
            "T8_avoidance": "0.5",
        }
        conn.execute(
            "insert into csv_rows_with_provenance values (?, ?, ?, ?)",
            (metric_csv, 51, json.dumps(row), '{"locator":"csv#row=51"}'),
        )
        conn.execute(
            "insert into objects values (?, ?, ?, ?, ?, ?, ?)",
            (
                "flies/videos/2026-04-22 12-12-14.mp4",
                "gs://monarch-videos-new/flies/videos/2026-04-22 12-12-14.mp4",
                "video",
                ".mp4",
                123,
                "video/mp4",
                "2026-04-22T00:00:00Z",
            ),
        )
        for row_number, tube in [(1005, "5"), (1006, "6"), (1007, "7"), (1008, "8")]:
            for cell_prefix, value in [
                ("B", "2026-04-22 12-12-14.mp4"),
                ("I", tube),
                ("N", "2PP"),
                ("O", "10"),
                ("P", "DPG"),
                ("U", "1"),
            ]:
                conn.execute(
                    "insert into xlsx_cells_with_provenance values (?, ?, ?, ?, ?)",
                    (
                        "flies/repellency_screen_metadata_sheet.xlsx",
                        "trials",
                        f"{cell_prefix}{row_number}",
                        row_number,
                        value,
                    ),
                )
        conn.commit()

        job = overlay.resolve_overlay_job(db_path=overlay.Path(db_path), metric_csv=metric_csv)

        self.assertEqual(job["metric"]["tube_labels"], ["T5", "T6", "T7", "T8"])
        self.assertEqual(job["metric"]["peak"]["avg"], 0.65)
        self.assertEqual(job["tube_context"]["metadata_rows"], [1005, 1006, 1007, 1008])
        self.assertEqual(job["title"], "fly repellency")
        self.assertEqual(job["subtitle"], "2PP 10 DPG")

    def test_mosquito_dart_media_links_select_tubes(self):
        import render_assay_metric_overlay as overlay

        tmp, db_path, conn = make_db()
        self.addCleanup(tmp.cleanup)
        self.addCleanup(conn.close)

        metric_csv = (
            "mosquitoes/processed/_2026_04_28_14_44_46_BHomocyclo3_mov_results/"
            "_2026_04_28_14_44_46_BHomocyclo3_mov_results/advanced_metrics.csv"
        )
        row = {
            "time_min": "5.5",
            "time_sec": "330.0",
            "T1_avoidance": "0.6",
            "T2_avoidance": "0.7",
            "T3_avoidance": "0.8",
        }
        media_name = "mosquitoes/videos/_2026_04_28_14_44_46_BHomocyclo3_mov.mov"
        conn.execute(
            "insert into csv_rows_with_provenance values (?, ?, ?, ?)",
            (metric_csv, 6, json.dumps(row), '{"locator":"csv#row=6"}'),
        )
        conn.execute(
            "insert into objects values (?, ?, ?, ?, ?, ?, ?)",
            (
                media_name,
                f"gs://monarch-videos-new/{media_name}",
                "video",
                ".mov",
                456,
                "video/quicktime",
                "2026-04-28T00:00:00Z",
            ),
        )
        for tube in ["1", "2", "3"]:
            conn.execute(
                "insert into assay_media_links values (?, ?, ?, ?, ?, ?)",
                (media_name, "DART", "Bhomocyclo", "Bhomocyclo", tube, 1252 + int(tube)),
            )
        conn.commit()

        job = overlay.resolve_overlay_job(db_path=overlay.Path(db_path), metric_csv=metric_csv)

        self.assertEqual(job["metric"]["tube_labels"], ["T1", "T2", "T3"])
        self.assertAlmostEqual(job["metric"]["peak"]["avg"], 0.7)
        self.assertEqual(job["title"], "mosquito DART")
        self.assertEqual(job["subtitle"], "Bhomocyclo")

    def test_contact_non_contact_frame_metrics_use_contact_pi_schema(self):
        import render_assay_metric_overlay as overlay

        tmp, db_path, conn = make_db()
        self.addCleanup(tmp.cleanup)
        self.addCleanup(conn.close)

        metric_csv = "contact_repel_videos/flies/processed/2PP_non_contact/frame_metrics.csv"
        media_name = "contact_repel_videos/flies/2PP_non_contact.MOV"
        rows = [
            {
                "frame_idx": "0",
                "time_sec": "0.0",
                "n_total": "2",
                "n_inside": "2",
                "n_on_band": "0",
                "n_outside": "0",
                "contact_pi": "-1.0",
                "contact_pi_strict": "-1.0",
                "frac_inside": "1.0",
                "frac_on_band": "0.0",
                "frac_outside": "0.0",
                "centroid_x": "309",
                "centroid_y": "327",
                "centroid_dist_from_center": "0.0",
                "boundary_proximity_count": "0",
            },
            {
                "frame_idx": "30",
                "time_sec": "1.0",
                "n_total": "3",
                "n_inside": "0",
                "n_on_band": "1",
                "n_outside": "2",
                "contact_pi": "0.67",
                "contact_pi_strict": "0.67",
                "frac_inside": "0.0",
                "frac_on_band": "0.333",
                "frac_outside": "0.667",
                "centroid_x": "350",
                "centroid_y": "360",
                "centroid_dist_from_center": "0.4",
                "boundary_proximity_count": "1",
            },
        ]
        for row_number, row in enumerate(rows, start=1):
            conn.execute(
                "insert into csv_rows_with_provenance values (?, ?, ?, ?)",
                (metric_csv, row_number, json.dumps(row), f'{{"locator":"csv#row={row_number}"}}'),
            )
        conn.execute(
            "insert into objects values (?, ?, ?, ?, ?, ?, ?)",
            (
                media_name,
                f"gs://monarch-videos-new/{media_name}",
                "video",
                ".mov",
                789,
                "video/quicktime",
                "2026-04-01T00:00:00Z",
            ),
        )
        for path, value in [
            ("letterbox_size", "640"),
            ("cx", "309"),
            ("cy", "327"),
            ("inner_radius", "137"),
            ("outer_radius", "152"),
            ("band_width", "15"),
        ]:
            conn.execute(
                "insert into json_units_with_provenance values (?, ?, ?, ?, ?, ?)",
                (
                    "contact_repel_videos/flies/processed/2PP_non_contact/zone_coordinates.json",
                    path,
                    value,
                    "int",
                    "test",
                    f'{{"locator":"zone#{path}"}}',
                ),
            )
        conn.commit()

        job = overlay.resolve_overlay_job(db_path=overlay.Path(db_path), metric_csv=metric_csv)
        proof = overlay.proof_payload(job)

        self.assertEqual(job["metric"]["kind"], "contact_pi")
        self.assertEqual(job["metric"]["value_label"], "contact PI")
        self.assertEqual(job["metric"]["peak"]["avg"], 0.67)
        self.assertEqual(job["metric"]["peak"]["tube_values"]["outside"], 2)
        self.assertEqual(job["metric"]["peak"]["fractions"]["outside"], 0.667)
        self.assertEqual(job["metric"]["peak"]["centroid"]["x"], 350.0)
        self.assertEqual(job["contact_artifacts"]["zone"]["outer_radius"], 152)
        self.assertEqual(job["title"], "fly non-contact repellency")
        self.assertEqual(job["subtitle"], "2PP non contact")
        self.assertEqual(proof["metric_kind"], "contact_pi")
        self.assertTrue(str(overlay.default_output_path(job, overlay.Path("videos/out"))).endswith("_contact_pi_overlay.mp4"))


if __name__ == "__main__":
    unittest.main()
