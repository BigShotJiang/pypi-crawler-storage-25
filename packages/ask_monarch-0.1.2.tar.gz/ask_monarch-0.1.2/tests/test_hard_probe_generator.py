import os
import sys
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class HardProbeGeneratorTests(unittest.TestCase):
    def test_teams_recaps_generator_creates_meeting_questions(self):
        import probe_askmonarch_hard_questions as probes

        rows = [
            {
                "meeting_date": "2026-05-01",
                "speaker": "Joel K",
                "text": "Like they have a diagram with a camera overhead and a camera below.",
            }
        ]
        generated = []

        with mock.patch.object(probes, "run_sql", return_value=rows):
            probes.generate_teams_recaps_probes(generated, set(), 10)

        self.assertEqual(len(generated), 1)
        self.assertEqual(generated[0].expected_source, "teams_recaps")
        self.assertIn("R&D meeting", generated[0].question)
        self.assertIn("camera overhead", generated[0].question)
        self.assertEqual(generated[0].must_have[0]["field"], "text")
        self.assertEqual(generated[0].must_have[1], {"field": "meeting_date", "contains": "2026-05-01"})

    def test_teams_phrase_filter_rejects_vague_transcript_fragments(self):
        import probe_askmonarch_hard_questions as probes

        keywords = {"assay", "camera", "flies", "model", "mosquitoes"}

        self.assertFalse(probes.is_specific_teams_phrase("this assay", keywords))
        self.assertFalse(probes.is_specific_teams_phrase("trying model that when you", keywords))
        self.assertFalse(probes.is_specific_teams_phrase("All right then think just", keywords))
        self.assertFalse(probes.is_specific_teams_phrase("flies this mosquito-specific", keywords))
        self.assertFalse(probes.is_specific_teams_phrase("mosquitoes flies don have anything", keywords))
        self.assertTrue(probes.is_specific_teams_phrase("camera overhead camera below", keywords))

    def test_teams_phrase_builder_drops_filler_words(self):
        import probe_askmonarch_hard_questions as probes

        keywords = {"agar", "heat"}

        phrase = probes.phrase_near_keyword(
            "Yeah, we ran into questions before about like the agar and the heat. There were early conversations.",
            keywords,
        )

        self.assertEqual(phrase, "agar heat early conversations")

        phrase = probes.phrase_near_keyword(
            "If you don't know where it is and you have tracking on all of it, you can see insects.",
            {"tracking", "insects"},
        )

        self.assertEqual(phrase, "tracking insects")

    def test_technical_profile_excludes_inventory_and_people_generators(self):
        import probe_askmonarch_hard_questions as probes

        generator_names = {generator.__name__ for generator in probes.PROFILES["technical"]}

        self.assertNotIn("generate_inventory_probes", generator_names)
        self.assertNotIn("generate_people_probes", generator_names)
        self.assertIn("generate_teams_recaps_probes", generator_names)
        self.assertIn("generate_bucket_probes", generator_names)

    def test_technical_router_profile_asks_generic_monarch_questions(self):
        import probe_askmonarch_hard_questions as probes

        rows = [
            {
                "title": "monarch_update.pptx",
                "slide_number": 2,
                "text": "Train the fly contact repellency model",
            }
        ]
        generated = []

        with mock.patch.object(probes, "run_sql", return_value=rows):
            probes.generate_presentation_router_probes(generated, set(), 10)

        self.assertEqual(len(generated), 1)
        self.assertEqual(generated[0].expected_source, "presentations")
        self.assertEqual(
            generated[0].question,
            "what does Monarch say about Train fly contact repellency model?",
        )

    def test_presentation_router_generator_rejects_nontechnical_fragments(self):
        import probe_askmonarch_hard_questions as probes

        rows = [
            {
                "title": "monarch_update.pptx",
                "slide_number": 17,
                "text": "Still this tendency could be desirable",
            }
        ]
        generated = []

        with mock.patch.object(probes, "run_sql", return_value=rows):
            probes.generate_presentation_router_probes(generated, set(), 10)

        self.assertEqual(generated, [])

    def test_teams_router_generator_skips_cross_source_contact_model_phrase(self):
        import probe_askmonarch_hard_questions as probes

        rows = [
            {
                "meeting_date": "2026-04-17",
                "speaker": "Joel K",
                "text": "We talked through results from the fly contact repellency model.",
            }
        ]
        generated = []

        with mock.patch.object(probes, "run_sql", return_value=rows):
            probes.generate_teams_recaps_router_probes(generated, set(), 10)

        self.assertEqual(generated, [])

    def test_technical_router_profile_excludes_inventory_and_people_generators(self):
        import probe_askmonarch_hard_questions as probes

        generator_names = {generator.__name__ for generator in probes.PROFILES["technical_router"]}

        self.assertNotIn("generate_inventory_probes", generator_names)
        self.assertNotIn("generate_people_probes", generator_names)
        self.assertIn("generate_teams_recaps_router_probes", generator_names)
        self.assertIn("generate_presentation_router_probes", generator_names)
        self.assertIn("generate_milestone_router_probes", generator_names)


if __name__ == "__main__":
    unittest.main()
