import importlib.util
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "run_askmonarch_golden_route_soak.py"


def load_soak():
    spec = importlib.util.spec_from_file_location("run_askmonarch_golden_route_soak", SCRIPT_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules["run_askmonarch_golden_route_soak"] = module
    spec.loader.exec_module(module)
    return module


class GoldenRouteSoakTests(unittest.TestCase):
    def test_route_cards_manifest_loads_core_families(self):
        soak = load_soak()

        cards = soak.load_route_cards()
        by_id = {card["family_id"]: card for card in cards}

        self.assertIn("species_repellency_ranking", by_id)
        self.assertIn("phytotoxicity_inventory_ranking", by_id)
        self.assertIn("fly_repellency_media_proof", by_id)
        self.assertIn("assay_meeting_commentary", by_id)
        self.assertIn("fly_pi_inconsistency_metadata_correlation", by_id)
        self.assertIn("mosquito_tube_density_recommendation", by_id)
        self.assertIn("compound_pair_cross_assay_repellency", by_id)
        self.assertIn("inventory_with_tested_status", by_id)
        self.assertIn("fly_assay_count", by_id)
        self.assertIn("assay_best_result_environment_conditions", by_id)
        self.assertIn("contact_noncontact_ranked_comparison", by_id)
        self.assertIn("rank_expectation_explanation", by_id)
        self.assertIn("assay_summary_file_explanation", by_id)
        self.assertGreaterEqual(len(cards), 30)
        for card in cards:
            self.assertTrue(card["family_id"])
            self.assertIn(card["corpus_area"], {"rd", "full_corpus"})
            self.assertTrue(card["question_templates"])
            self.assertTrue(card["expected_sources"])
            self.assertTrue(card.get("expected_answer_shape") or card.get("expected_answer_shapes") or card.get("expected_gap"))
            self.assertIn("latency_target_ms", card)

    def test_generate_cases_returns_1000_unique_cto_depth_first_questions(self):
        soak = load_soak()

        cards = soak.load_route_cards()
        cases = soak.generate_cases(cards, total=1000, rd_target=600)

        self.assertEqual(len(cases), 1000)
        self.assertEqual(len({case["id"] for case in cases}), 1000)
        self.assertEqual(len({case["question"] for case in cases}), 1000)
        rd_cases = [case for case in cases if case["corpus_area"] == "rd"]
        self.assertGreaterEqual(len(rd_cases), 600)
        family_ids = {card["family_id"] for card in cards}
        generated_family_ids = {case["family_id"] for case in cases}
        self.assertTrue(family_ids.issubset(generated_family_ids))
        for case in cases:
            self.assertTrue(case["family_id"])
            self.assertTrue(case["question"])
            self.assertTrue(case["expected_sources"])
            self.assertTrue(case.get("expected_answer_shape") or case.get("expected_answer_shapes") or case.get("expected_gap"))
            self.assertIn("latency_target_ms", case)

    def test_write_cases_outputs_json_with_summary(self):
        soak = load_soak()
        cards = soak.load_route_cards()
        cases = soak.generate_cases(cards, total=25, rd_target=15)

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "cases.json"
            soak.write_cases(path, cases)
            data = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(data["summary"]["total"], 25)
        self.assertGreaterEqual(data["summary"]["rd_cases"], 15)
        self.assertEqual(len(data["cases"]), 25)

    def test_score_case_accepts_structured_golden_payload(self):
        soak = load_soak()
        case = {
            "id": "case",
            "family_id": "species_repellency_ranking",
            "expected_sources": ["bucket"],
            "expected_answer_shape": "ranked_species_repellent_compounds",
            "expected_adapters": ["bucket_top_repellents_by_species_sql"],
            "required_fields_any": ["treatment_normalized", "mean_avg_pi", "provenance_grain"],
            "require_provenance": True,
            "latency_target_ms": 5000,
        }
        run = {
            "returncode": 0,
            "elapsed_ms": 18,
            "payload": {
                "ok": True,
                "mode": "sql",
                "source": "bucket",
                "routing_decision": {
                    "source_lane": "bucket",
                    "adapter": "bucket_top_repellents_by_species_sql",
                    "answer_shape": "ranked_species_repellent_compounds",
                },
                "rows": [
                    {
                        "treatment_normalized": "2PP",
                        "mean_avg_pi": -0.3185,
                        "provenance_grain": "{\"source_id\":\"monarch_videos_new\"}",
                    }
                ],
            },
        }

        result = soak.score_case(case, run)

        self.assertTrue(result["ok"], result["errors"])
        self.assertTrue(result["route_ok"])
        self.assertTrue(result["provenance_ok"])

    def test_score_case_accepts_expected_source_gap(self):
        soak = load_soak()
        case = {
            "id": "gap",
            "family_id": "expected_source_gap",
            "expected_sources": ["bucket"],
            "expected_gap": "source_gap",
            "expected_adapters": ["bucket_experiments_by_organism_sql"],
            "required_fields_any": ["source_gap"],
            "require_provenance": False,
            "latency_target_ms": 5000,
        }
        run = {
            "returncode": 1,
            "elapsed_ms": 25,
            "payload": {
                "ok": False,
                "mode": "source_gap",
                "source": "bucket",
                "routing_decision": {
                    "source_lane": "bucket",
                    "adapter": "bucket_experiments_by_organism_sql",
                },
                "source_gap": {"missing_adapter": "bucket_experiments_by_organism_sql"},
                "rows": [],
            },
        }

        result = soak.score_case(case, run)

        self.assertTrue(result["ok"], result["errors"])
        self.assertTrue(result["fail_closed_ok"])
        self.assertTrue(result["rows_ok"])

    def test_score_case_rejects_silent_fallback(self):
        soak = load_soak()
        case = {
            "id": "bad",
            "family_id": "species_repellency_ranking",
            "expected_sources": ["bucket"],
            "expected_answer_shape": "ranked_species_repellent_compounds",
            "expected_adapters": ["bucket_top_repellents_by_species_sql"],
            "required_fields_any": ["treatment_normalized"],
            "require_provenance": True,
            "latency_target_ms": 5000,
        }
        run = {
            "returncode": 0,
            "elapsed_ms": 18,
            "payload": {
                "ok": True,
                "mode": "prose",
                "source": "bucket",
                "routing_decision": {
                    "source_lane": "bucket",
                    "adapter": "bucket_source_text_retrieval",
                },
                "rows": [{"text": "2PP seems good"}],
            },
        }

        result = soak.score_case(case, run)

        self.assertFalse(result["ok"])
        self.assertIn("wrong_adapter", result["failure_clusters"])
        self.assertIn("missing_provenance", result["failure_clusters"])

    def test_score_case_rejects_forbidden_adapter_even_when_source_shape_and_rows_pass(self):
        soak = load_soak()
        case = {
            "id": "forbidden",
            "family_id": "fly_assay_count",
            "expected_sources": ["bucket"],
            "expected_answer_shape": "fly_assay_count",
            "expected_adapters": ["bucket_fly_assay_count_sql", "bucket_dart_assay_results_sql"],
            "forbidden_adapters": ["bucket_dart_assay_results_sql"],
            "required_fields_any": ["trial_rows"],
            "require_provenance": True,
            "latency_target_ms": 5000,
        }
        run = {
            "returncode": 0,
            "elapsed_ms": 18,
            "payload": {
                "ok": True,
                "mode": "sql",
                "source": "bucket",
                "routing_decision": {
                    "source_lane": "bucket",
                    "adapter": "bucket_dart_assay_results_sql",
                    "answer_shape": "fly_assay_count",
                },
                "rows": [
                    {
                        "trial_rows": 1015,
                        "provenance_grain": "{\"source_id\":\"monarch_videos_new\"}",
                    }
                ],
            },
        }

        result = soak.score_case(case, run)

        self.assertFalse(result["ok"])
        self.assertIn("forbidden_adapter", result["failure_clusters"])

    def test_score_case_accepts_query_code_and_source_names_provenance(self):
        soak = load_soak()
        case = {
            "id": "real-route",
            "family_id": "species_repellency_ranking",
            "expected_sources": ["bucket"],
            "expected_answer_shapes": ["ranked_mosquito_dart_compounds", "ranked_fly_repellency_compounds"],
            "expected_adapters": ["bucket_dart_ranking_sql"],
            "required_fields_any": ["treatment_normalized", "mean_avg_pi"],
            "require_provenance": True,
            "latency_target_ms": 5000,
        }
        run = {
            "returncode": 0,
            "elapsed_ms": 34,
            "payload": {
                "ok": True,
                "mode": "sql",
                "source": "bucket",
                "routing_decision": {
                    "answer_shape": "ranked_mosquito_dart_compounds",
                    "query_code": "bucket_dart_ranking_sql",
                    "source_lane": "bucket",
                    "plan_steps": [
                        {
                            "query_code": "bucket_dart_ranking_sql",
                            "retrieval_type": "structured_table_sql",
                            "source_lane": "bucket",
                        }
                    ],
                },
                "rows": [
                    {
                        "treatment_normalized": "2PP",
                        "mean_avg_pi": -0.3185,
                        "source_names": "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx",
                    }
                ],
            },
        }

        result = soak.score_case(case, run)

        self.assertTrue(result["ok"], result["errors"])
        self.assertIn("bucket_dart_ranking_sql", result["actual_adapters"])
        self.assertTrue(result["provenance_ok"])

        bad_run = dict(run)
        bad_payload = dict(run["payload"])
        bad_payload["routing_decision"] = dict(bad_payload["routing_decision"], answer_shape="wrong_shape")
        bad_payload["answer_shape_validation"] = {"answer_shape": "wrong_shape", "checked": True, "ok": True}
        bad_run["payload"] = bad_payload

        bad_result = soak.score_case(case, bad_run)

        self.assertFalse(bad_result["shape_ok"])

    def test_score_case_treats_expected_sources_as_any_by_default(self):
        soak = load_soak()
        case = {
            "id": "people",
            "family_id": "people_company_fact",
            "expected_sources": ["people_directory", "company_profile"],
            "expected_answer_shapes": ["roster_list", "named_person_profile"],
            "expected_adapters": ["people_directory_structured_sql"],
            "required_fields_any": ["name"],
            "require_provenance": False,
            "latency_target_ms": 5000,
        }
        run = {
            "returncode": 0,
            "elapsed_ms": 20,
            "payload": {
                "ok": True,
                "mode": "sql",
                "source": "people_directory",
                "routing_decision": {
                    "source_lane": "people_directory",
                    "query_code": "people_directory_structured_sql",
                    "answer_shape": "roster_list",
                },
                "rows": [{"name": "Erica McAlister"}],
            },
        }

        result = soak.score_case(case, run)

        self.assertTrue(result["source_ok"], result["errors"])
        self.assertTrue(result["ok"], result["errors"])

    def test_summary_and_writers_emit_failure_clusters(self):
        soak = load_soak()
        results = [
            {
                "id": "a",
                "family_id": "species_repellency_ranking",
                "question": "q1",
                "ok": True,
                "failure_clusters": [],
                "elapsed_ms": 10,
                "row_count": 1,
                "actual_sources": ["bucket"],
                "actual_adapters": ["adapter"],
                "actual_shapes": ["shape"],
                "errors": [],
            },
            {
                "id": "b",
                "family_id": "assay_meeting_commentary",
                "question": "q2",
                "ok": False,
                "failure_clusters": ["empty_rows"],
                "elapsed_ms": 20,
                "row_count": 0,
                "actual_sources": ["bucket"],
                "actual_adapters": ["adapter"],
                "actual_shapes": ["shape"],
                "errors": ["row_count too low"],
            },
        ]

        summary = soak.summarize_results(results)

        self.assertEqual(summary["total"], 2)
        self.assertEqual(summary["failed"], 1)
        self.assertEqual(summary["by_cluster"]["empty_rows"], 1)
        with tempfile.TemporaryDirectory() as tmp:
            md = Path(tmp) / "findings.md"
            html_path = Path(tmp) / "evidence.html"
            soak.write_markdown(md, summary, results)
            soak.write_html(html_path, summary, results, sample_passing=1)
            self.assertIn("empty_rows", md.read_text(encoding="utf-8"))
            self.assertIn("assay_meeting_commentary", html_path.read_text(encoding="utf-8"))

    def test_write_cases_only_ignores_max_cases_for_durable_case_file(self):
        soak = load_soak()

        with tempfile.TemporaryDirectory() as tmp:
            cases_path = Path(tmp) / "cases.json"
            with contextlib.redirect_stdout(io.StringIO()):
                exit_code = soak.main(
                    [
                        "--cases",
                        str(cases_path),
                        "--total",
                        "30",
                        "--rd-target",
                        "15",
                        "--max-cases",
                        "5",
                        "--write-cases-only",
                    ]
                )
            data = json.loads(cases_path.read_text(encoding="utf-8"))

        self.assertEqual(exit_code, 0)
        self.assertEqual(data["summary"]["total"], 30)
        self.assertEqual(len(data["cases"]), 30)


if __name__ == "__main__":
    unittest.main()
