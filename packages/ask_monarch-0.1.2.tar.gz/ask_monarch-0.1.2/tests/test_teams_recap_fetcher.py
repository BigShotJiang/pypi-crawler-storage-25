import unittest

from scripts import fetch_monarch_r_and_d_teams_recaps as fetcher


class TeamsRecapFetcherTests(unittest.TestCase):
    def test_calendar_events_ignore_canceled_occurrences(self):
        self.assertFalse(
            fetcher.is_active_subject_match(
                {"subject": "Canceled: Monarch Team Sync", "isCancelled": False},
                "Monarch Team Sync",
            )
        )
        self.assertFalse(
            fetcher.is_active_subject_match(
                {"subject": "Monarch Team Sync", "isCancelled": True},
                "Monarch Team Sync",
            )
        )

    def test_calendar_events_match_active_subjects(self):
        self.assertTrue(
            fetcher.is_active_subject_match(
                {"subject": "Monarch Team Sync", "isCancelled": False},
                "Monarch Team Sync",
            )
        )


if __name__ == "__main__":
    unittest.main()
