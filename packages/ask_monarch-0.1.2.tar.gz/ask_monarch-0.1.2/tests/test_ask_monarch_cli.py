import inspect
import os
import sqlite3
import sys
import tempfile
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class AskMonarchCliTests(unittest.TestCase):
    def test_answer_contract_guard_converts_wrong_shape_to_source_gap(self):
        import ask_monarch

        result = ask_monarch.enforce_answer_contract_for_result(
            "list all compounds in our inventory",
            {
                "ok": True,
                "mode": "sql",
                "source": "compound_inventory",
                "routing_decision": {
                    "answer_shape": "inventory_list",
                    "source_lane": "compound_inventory",
                    "retrieval_shape": "structured",
                    "adapter": "compound_inventory_all_names_sql",
                },
                "rows": [
                    {
                        "compound_count": 905,
                        "first_50_compounds": "2PP, DEET",
                        "provenance_grain": "{}",
                    }
                ],
            },
        )

        self.assertFalse(result["ok"])
        self.assertEqual(result["mode"], "source_gap")
        self.assertEqual(result["error"], "answer_shape_gap")
        self.assertIn("answer_shape_validation", result)
        self.assertIn("inventory_list requires compound item rows", " ".join(result["source_gap"]["errors"]))

    def test_auto_source_routes_common_company_profile_questions(self):
        import ask_monarch

        cases = {
            "what does Monarch do?": "company_profile",
            "where is Monarch?": "company_profile",
            "what insects does Monarch work with?": "company_profile",
            "which insects does Monarch work with?": "company_profile",
            "list all of the insects we work with": "company_profile",
            "what organisms does Monarch work with?": "company_profile",
        }

        for question, source in cases.items():
            with self.subTest(question=question):
                self.assertEqual(ask_monarch.auto_source_for_question(question), source)

    def test_auto_source_routes_people_roster_questions(self):
        import ask_monarch

        self.assertEqual(
            ask_monarch.auto_source_for_question("who works at Monarch?"),
            "people_directory",
        )
        self.assertEqual(
            ask_monarch.auto_source_for_question("who is Erica McAlister at Monarch?"),
            "people_directory",
        )
        self.assertEqual(
            ask_monarch.auto_source_for_question("what is Erica McAlister's role?"),
            "people_directory",
        )
        self.assertEqual(
            ask_monarch.auto_source_for_question("what is Joel's background at Monarch?"),
            "people_directory",
        )
        self.assertEqual(
            ask_monarch.auto_source_for_question("what is Joel Kowalewski's education?"),
            "people_directory",
        )

    def test_people_query_normalizes_named_background_questions(self):
        import ask_monarch

        self.assertEqual(
            ask_monarch.people_query_for_question("what is Joel's background at Monarch?"),
            "Joel Kowalewski",
        )
        self.assertEqual(
            ask_monarch.people_query_for_question("what is Erica McAlister's role?"),
            "Erica McAlister",
        )
        self.assertIsNone(
            ask_monarch.people_query_for_question("who works at Monarch?"),
        )

    def test_auto_source_routes_company_context_questions(self):
        import ask_monarch

        self.assertEqual(
            ask_monarch.auto_source_for_question("what does company context say about residues?"),
            "company_context",
        )

    def test_auto_source_routes_team_discussion_questions_to_recaps(self):
        import ask_monarch

        cases = [
            "what did the team discuss on friday?",
            "what did the team discuss today?",
            "summarize the R&D meeting decisions",
            "what did the R&D meeting discuss about fly contact repellency model?",
        ]

        for question in cases:
            with self.subTest(question=question):
                self.assertEqual(ask_monarch.auto_source_for_question(question), "teams_recaps")

    def test_auto_source_routes_compound_inventory_questions(self):
        import ask_monarch

        cases = [
            "what chemicals are in inventory?",
            "what inventory do we have?",
            "show inventory by storage location",
            "what chemicals are in stock?",
            "what is in the Monarch chemical library?",
            "show the compound inventory",
            "what is the CAS for acetone in the chemical inventory?",
            "where do we store DEET?",
            "who is the vendor for (-)-Bornyl acetate?",
            "do we have DPG in inventory?",
        ]

        for question in cases:
            with self.subTest(question=question):
                self.assertEqual(ask_monarch.auto_source_for_question(question), "compound_inventory")

    def test_auto_source_routes_hard_gap_questions(self):
        import ask_monarch

        cases = {
            "what experiments were uploaded today?": "bucket",
            "what experiments were run Friday?": "bucket",
            "what assays did the team run yesterday?": "bucket",
            "what mode-of-action assays did Monarch develop?": "milestones_doc",
            "how many chemicals were strongly repellent?": "milestones_doc",
            "do we have Bornyl acetate and where is it?": "compound_inventory",
        }

        for question, source in cases.items():
            with self.subTest(question=question):
                self.assertEqual(ask_monarch.auto_source_for_question(question), source)

    def test_cli_auto_source_delegates_to_router_for_representative_routes(self):
        import ask_monarch

        cases = [
            "what assays did the team run yesterday?",
            "who works at Monarch?",
            "what did the team discuss today?",
            "what compounds are in inventory?",
            "where is Monarch based?",
            "what does Monarch say about computer vision tracking models?",
            "what does Monarch say about DPG solvents for contact purposes?",
            "what mode-of-action assays did Monarch develop?",
        ]

        for question in cases:
            with self.subTest(question=question):
                self.assertEqual(
                    ask_monarch.auto_source_for_question(question),
                    ask_monarch.routing_decision.auto_source_for_question(question),
                )

    def test_cli_entrypoints_delegate_to_routing_decision_module(self):
        import ask_monarch

        self.assertIn("ask_monarch_cli/routing_decision.py", ask_monarch.routing_decision.__file__)

        with mock.patch.object(
            ask_monarch.routing_decision,
            "auto_source_for_question",
            return_value="people_directory",
        ) as routed:
            self.assertEqual(ask_monarch.auto_source_for_question("sentinel question"), "people_directory")
            routed.assert_called_once_with("sentinel question")

        expected_payload = {"source": "bucket", "routing_decision": {"adapter": "sentinel_router"}}
        with mock.patch.object(
            ask_monarch.routing_decision,
            "query_payload_for_question",
            return_value=expected_payload,
        ) as routed_payload:
            self.assertIs(
                ask_monarch.query_payload_for_question("sentinel question", "auto", limit=3),
                expected_payload,
            )
            routed_payload.assert_called_once_with(
                "sentinel question",
                "auto",
                kind="all",
                limit=3,
                offset=0,
                include_health=False,
                deep_health=False,
            )

    def test_http_execute_query_applies_authoritative_routing_decision(self):
        import serve_http

        source = inspect.getsource(serve_http.execute_query)
        self.assertIn("routing_decision.apply_authoritative_route(payload)", source)

    def test_auto_source_routes_technical_model_and_phytotoxicity_questions(self):
        import ask_monarch

        cases = {
            "what does Monarch say about mosquito fly models contact behavior?": "presentations",
            "what does Monarch say about color shift pixel fractions phytotoxicity?": "presentations",
            "how do AI models compute severity scores for phytotoxicity concerns?": "milestones_doc",
            "what does Monarch say about rational design and physicochemical properties?": "milestones_doc",
            "what does Monarch say about computer vision tracking models?": "presentations",
            "what does Monarch say about AI models detecting mosquito behavior?": "milestones_doc",
            "what does Monarch say about optimizing pipeline detection analysis?": "presentations",
            "what does Monarch say about DPG solvents for contact purposes?": "teams_recaps",
            "what does Monarch say about odorant hot agar?": "teams_recaps",
            "what does Monarch say about Flywalk?": "teams_recaps",
            "what does Monarch say about spatial assays and odor preparation?": "teams_recaps",
            "what does Monarch say about multiple cameras for tracking insects?": "teams_recaps",
            "what does Monarch say about latest fly model?": "teams_recaps",
            "what does Monarch say about build other insect detection models?": "presentations",
            "what does Monarch say about phytotoxicity soybean leaf assay?": "presentations",
            "what does Monarch say about GCP AI pipeline?": "milestones_doc",
            "what does Monarch say about automated processing pipeline scoring behavior?": "milestones_doc",
            "what does Monarch say about solvent being too reactive?": "teams_recaps",
            "what does Monarch say about communications biology odor receptors?": "teams_recaps",
            "what does Monarch say about overhead camera below camera setup?": "teams_recaps",
            "what does Monarch say about stereoscope camera setup?": "teams_recaps",
            "what does Monarch say about mosquito-specific testing in flies?": "teams_recaps",
            "what does Monarch say about D and D reliability in mosquitoes?": "teams_recaps",
            "what does Monarch say about non-contact repellency 2PP?": "presentations",
            "what does Monarch say about soybean leaf damage metrics?": "presentations",
            "what does Monarch say about localized discoloration spotting?": "milestones_doc",
            "what does Monarch say about multiple modes of action on multiple insects?": "milestones_doc",
            "what does Monarch say about secure storage bucket results upload?": "milestones_doc",
            "what does Monarch say about agricultural relevance of assays?": "teams_recaps",
            "what does Monarch say about vapor pressure compounds in SAS setting?": "teams_recaps",
            "what does Monarch say about moving cameras for hidden insects?": "teams_recaps",
            "what does Monarch say about model performance in the latest fly model?": "teams_recaps",
            "what does Monarch say about preference index currently number flies?": "teams_recaps",
            "what does Monarch say about film everything with multiple cameras?": "teams_recaps",
            "what does Monarch say about agar heat early conversations?": "teams_recaps",
            "what does Monarch say about model will cases where tons?": "teams_recaps",
            "what does Monarch say about model training data than completely?": "teams_recaps",
            "what does Monarch say about models able detect beetles?": "teams_recaps",
            "what does Monarch say about mosquitoes want model predictions good?": "teams_recaps",
            "what does Monarch say about model probably not perform?": "teams_recaps",
            "what does Monarch say about assay better model need?": "teams_recaps",
            "what does Monarch say about fly food preparation working Avinash?": "teams_recaps",
            "what does Monarch say about odorant receptor complexes different insects?": "teams_recaps",
            "what does Monarch say about mosquito videos done fly video?": "teams_recaps",
            "what does Monarch say about camera top top leaf instead?": "teams_recaps",
            "what does Monarch say about mosquito looked mosquito seem?": "teams_recaps",
            "what does Monarch say about mosquito drosophila things?": "teams_recaps",
            "what does Monarch say about Dart open position deterrent potentially?": "teams_recaps",
            "what does Monarch say about fly contact repellency model trained?": "presentations",
            "what does Monarch say about original pipeline designed different expected?": "presentations",
            "what does Monarch say about annotating moth beetle videos DART?": "presentations",
            "what does Monarch say about finalizing phytotox pipeline ideal metrics?": "presentations",
            "what does Monarch say about YOLO26 model soybean segmentation?": "presentations",
            "what does Monarch say about Reactive thiols amines classic mode?": "presentations",
            "what does Monarch say about Implemented basic tracking analysis based?": "presentations",
            "what does Monarch say about Latest Models 100 fly images?": "presentations",
            "what does Monarch say about Tried three different tracking approaches?": "presentations",
            "what does Monarch say about Improve insect tracking capabilities?": "presentations",
            "what does Monarch say about Added oviposition images model training?": "presentations",
            "what does Monarch say about Built Soybean Leaf Segmentation Model?": "presentations",
            "what does Monarch say about Detection rebuild model new data?": "presentations",
            "what does Monarch say about Pose Estimation Build evaluate model?": "presentations",
            "what does Monarch say about Mosquito Contact Repellency Retrain?": "presentations",
            "what does Monarch say about accelerating evaluation agriculturally relevant chemicals?": "milestones_doc",
            "what does Monarch say about optimized developed phytotoxicity assay soybean?": "milestones_doc",
            "what does Monarch say about improved AI models and severity scoring?": "milestones_doc",
            "what does Monarch say about Improved models help analyze these?": "milestones_doc",
            "what does the milestones doc say about Expanding pipeline evaluate chemicals?": "milestones_doc",
        }

        for question, source in cases.items():
            with self.subTest(question=question):
                self.assertEqual(ask_monarch.auto_source_for_question(question), source)

    def test_strip_trace_metadata_removes_observability_fields(self):
        import ask_monarch

        payload = {
            "ok": True,
            "trace_id": "trace-1",
            "trace_url": "https://braintrust.example/trace-1",
            "rows": [
                {
                    "text": "keep me",
                    "trace_span_id": "span-1",
                    "provenance_grain": "{\"locator\":\"source#1\"}",
                }
            ],
        }

        stripped = ask_monarch.strip_trace_metadata(payload)

        self.assertNotIn("trace_id", stripped)
        self.assertNotIn("trace_url", stripped)
        self.assertNotIn("trace_span_id", stripped["rows"][0])
        self.assertEqual(stripped["rows"][0]["text"], "keep me")
        self.assertIn("provenance_grain", stripped["rows"][0])

    def test_presentation_locator_prefers_provenance_locator(self):
        import ask_monarch

        row = {
            "file_id": "deck-id",
            "provenance_grain": '{"locator":"https://docs.google.com/presentation/d/deck-id/edit#slide=2"}',
        }

        self.assertEqual(
            ask_monarch.presentation_locator(row),
            "https://docs.google.com/presentation/d/deck-id/edit#slide=2",
        )

    def test_presentation_locator_falls_back_to_file_id(self):
        import ask_monarch

        self.assertEqual(
            ask_monarch.presentation_locator({"file_id": "deck-id"}),
            "https://docs.google.com/presentation/d/deck-id/edit",
        )

    def test_sql_literal_escapes_quotes(self):
        import ask_monarch

        self.assertEqual(ask_monarch.sql_literal("Josh's deck"), "'Josh''s deck'")

    def test_query_payload_uses_structured_people_directory_for_rosters(self):
        import ask_monarch

        source = ask_monarch.auto_source_for_question("who works at Monarch?")
        payload = ask_monarch.query_payload_for_question(
            "who works at Monarch?",
            source,
            limit=50,
            include_health=True,
        )

        self.assertEqual(payload["source"], "people_directory")
        self.assertIn("sql", payload)
        self.assertNotIn("question", payload)
        self.assertIn("lane = 'employees'", payload["sql"])
        self.assertTrue(payload["include_health"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "people_directory_employee_roster_sql")

    def test_query_payload_uses_structured_people_directory_for_named_people(self):
        import ask_monarch

        source = ask_monarch.auto_source_for_question("what is Joel's background at Monarch?")
        payload = ask_monarch.query_payload_for_question(
            "what is Joel's background at Monarch?",
            source,
        )

        self.assertEqual(payload["source"], "people_directory")
        self.assertIn("sql", payload)
        self.assertIn("Joel Kowalewski", payload["sql"])
        self.assertNotIn("q", payload)
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "people_directory_person_lookup_sql")

    def test_query_payload_uses_structured_company_profile_for_fact_units(self):
        import ask_monarch

        source = ask_monarch.auto_source_for_question("where is Monarch based?")
        payload = ask_monarch.query_payload_for_question(
            "where is Monarch based?",
            source,
        )

        self.assertEqual(payload["source"], "company_profile")
        self.assertIn("sql", payload)
        self.assertIn("'headquarters'", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "company_profile_unit_lookup_sql")

    def test_query_payload_uses_structured_inventory_for_compound_lists(self):
        import ask_monarch

        source = ask_monarch.auto_source_for_question("what compounds are in inventory?")
        payload = ask_monarch.query_payload_for_question(
            "what compounds are in inventory?",
            source,
        )

        self.assertEqual(payload["source"], "compound_inventory")
        self.assertIn("sql", payload)
        self.assertIn("compound_count", payload["sql"])
        self.assertIn("sheet_name = 'Master'", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "compound_inventory_master_count_sql")

    def test_query_payload_uses_full_inventory_name_adapter_for_all_compounds(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "list all compounds in our inventory",
            "auto",
        )

        self.assertEqual(payload["source"], "compound_inventory")
        self.assertIn("sql", payload)
        self.assertGreaterEqual(payload["limit"], 1000)
        self.assertIn("compound_name", payload["sql"])
        self.assertIn("vendor", payload["sql"])
        self.assertIn("catalog_number", payload["sql"])
        self.assertIn("location", payload["sql"])
        self.assertIn("cas", payload["sql"])
        self.assertIn("row_number", payload["sql"])
        self.assertIn("provenance_grain", payload["sql"])
        self.assertNotIn("first_50_compounds", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "compound_inventory_all_names_sql")

        db_path = os.path.join(
            ROOT,
            "artifacts",
            "monarch-compound-chemical-inventory",
            "source_index.sqlite",
        )
        if not os.path.exists(db_path):
            self.skipTest("compound inventory source_index.sqlite is not present in this checkout")
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(payload["sql"]).fetchall()

        self.assertGreaterEqual(len(rows), 900)
        self.assertEqual(rows[0]["row_number"], 2)
        self.assertEqual(rows[0]["compound_name"], "(Z)-3,7-Dimethylocta-2,6-dien-1-yl acetate")
        self.assertEqual(rows[0]["vendor"], "Aaron Chemicals")

    def test_query_payload_uses_semantic_inventory_summary_for_existing_inventory(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what is the existing inventory?",
            "auto",
        )

        self.assertEqual(payload["source"], "compound_inventory")
        self.assertIn("sql", payload)
        self.assertNotIn("source_gap", payload)
        self.assertIn("inventory_scope", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "compound_inventory_summary_sql")
        self.assertEqual(
            payload["routing_decision"]["semantic_adapter_match"]["adapter"],
            "compound_inventory_summary_sql",
        )

    def test_priority_plan_uses_relevant_structured_source_before_text_lane(self):
        import ask_monarch

        self.assertEqual(
            ask_monarch.priority_source_plan_for_question(
                "what compounds are in inventory and are they mentioned in milestones?"
            ),
            ["compound_inventory", "milestones_doc"],
        )
        self.assertEqual(
            ask_monarch.priority_source_plan_for_question(
                "list employees and whether they are mentioned in milestones"
            ),
            ["people_directory", "milestones_doc"],
        )

    def test_priority_plan_routes_experiment_metrics_before_secondary_text(self):
        import ask_monarch

        self.assertEqual(
            ask_monarch.priority_source_plan_for_question(
                "show me the top compounds per repellency data and whether they are mentioned in our milestones"
            ),
            ["bucket", "milestones_doc"],
        )
        self.assertEqual(
            ask_monarch.priority_source_plan_for_question(
                "show me the scientific literature for 2pp and how it correlates with our experimental data"
            ),
            ["bucket", "scientific_refs"],
        )
        self.assertEqual(
            ask_monarch.priority_source_plan_for_question(
                "list the top compounds we tested on flies by repellency"
            ),
            [],
        )
        self.assertEqual(
            ask_monarch.priority_source_plan_for_question(
                "what assays team ran yesterday and what they said about them in the team meeting friday am"
            ),
            ["bucket", "teams_recaps"],
        )

    def test_answer_shape_route_plan_runs_visible_steps_in_order(self):
        import ask_monarch

        class Args:
            question = "show me the top compounds per repellency data and whether they are mentioned in our milestones"
            kind = "all"
            limit = 5
            offset = 0
            with_health = False
            deep_health = False

        route = ask_monarch.routing_decision.route_decision_for_question(Args.question, "auto")
        payloads = []

        def fake_call_json(args, path, method="GET", payload=None):
            self.assertEqual(path, "/query")
            self.assertEqual(method, "POST")
            payloads.append(payload)
            if payload["source"] == "bucket":
                return {
                    "ok": True,
                    "source": payload["source"],
                    "rows": [
                        {
                            "treatment_normalized": "2PP",
                            "mean_avg_pi": -0.31,
                            "standard_deviation": 0.07,
                            "standard_deviation_basis": "sample_stddev_of_avg_pi_real_across_dart_rows",
                            "provenance_grain": '{"locator":"assay#1"}',
                        }
                    ],
                }
            return {
                "ok": True,
                "source": payload["source"],
                "rows": [
                    {
                        "text": "2PP appears in the milestones discussion.",
                        "provenance_grain": '{"locator":"milestones#1"}',
                    }
                ],
            }

        with mock.patch("ask_monarch.call_json", side_effect=fake_call_json):
            result = ask_monarch.query_answer_shape_route_plan(Args, route)

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "answer_shape_route_plan")
        self.assertEqual(result["routing_decision"]["answer_shape"], "ranked_repellents_with_milestone_mentions")
        self.assertEqual(
            [(step["source"], step["adapter"]) for step in result["source_plan"]],
            [
                ("bucket", "bucket_cross_assay_repellent_rank_compounds_sql"),
                ("milestones_doc", "milestones_doc_source_text_retrieval"),
            ],
        )
        self.assertEqual([payload["source"] for payload in payloads], ["bucket", "milestones_doc"])
        self.assertEqual(payloads[0]["routing_decision"]["adapter"], "bucket_cross_assay_repellent_rank_compounds_sql")
        self.assertIn("sql", payloads[0])
        self.assertEqual(payloads[1]["routing_decision"]["retrieval_shape"], "prose")
        self.assertIn("question", payloads[1])

    def test_compositional_route_plan_uses_step_specific_questions(self):
        import ask_monarch

        class Args:
            question = "what are the top fly repellents, and compare against phytotoxicity"
            kind = "all"
            limit = 5
            offset = 0
            with_health = False
            deep_health = False

        route = ask_monarch.routing_decision.route_decision_for_question(Args.question, "auto")
        payloads = []

        def fake_call_json(args, path, method="GET", payload=None):
            self.assertEqual(path, "/query")
            self.assertEqual(method, "POST")
            payloads.append(payload)
            return {
                "ok": True,
                "source": payload["source"],
                "rows": [
                    {
                        "compound": "2PP",
                        "score": -0.42,
                        "standard_deviation": 0.08,
                        "standard_deviation_basis": "mock_assay_metric_spread",
                        "provenance_grain": '{"locator":"row#1"}',
                    }
                ],
            }

        with mock.patch("ask_monarch.call_json", side_effect=fake_call_json):
            result = ask_monarch.query_answer_shape_route_plan(Args, route)

        self.assertTrue(result["ok"])
        self.assertEqual(result["routing_decision"]["intent"], "compositional_answer_contract")
        self.assertEqual(
            [step["planned_adapter"] for step in result["source_plan"]],
            ["bucket_fly_repellency_rankings_sql", "bucket_phytotox_rank_compounds_sql"],
        )
        self.assertEqual(payloads[0]["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payloads[1]["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")

    def test_assay_meeting_route_plan_uses_step_specific_questions(self):
        import ask_monarch

        class Args:
            question = "what fly assays ran last week and what did the meeting say"
            kind = "all"
            limit = 5
            offset = 0
            with_health = False
            deep_health = False

        route = ask_monarch.routing_decision.route_decision_for_question(Args.question, "auto")
        payloads = []

        def fake_call_json(args, path, method="GET", payload=None):
            self.assertEqual(path, "/query")
            self.assertEqual(method, "POST")
            payloads.append(payload)
            return {
                "ok": True,
                "source": payload["source"],
                "rows": [{"provenance_grain": '{"locator":"row#1"}'}],
            }

        with mock.patch("ask_monarch.call_json", side_effect=fake_call_json):
            result = ask_monarch.query_answer_shape_route_plan(Args, route)

        self.assertTrue(result["ok"])
        self.assertEqual(
            [step["planned_adapter"] for step in result["source_plan"]],
            ["bucket_cross_assay_run_inventory_sql", "teams_recaps_topic_speaker_rollup_sql"],
        )
        self.assertEqual(payloads[0]["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payloads[1]["routing_decision"]["adapter"], "teams_recaps_topic_speaker_rollup_sql")
        self.assertEqual(payloads[0]["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payloads[1]["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payloads[0]["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertNotEqual(payloads[0]["routing_decision"]["answer_shape"], "assay_runs_with_meeting_commentary")

    def test_result_video_route_plan_uses_step_specific_questions(self):
        import ask_monarch

        class Args:
            question = "show the video for the top fly repellents"
            kind = "all"
            limit = 5
            offset = 0
            with_health = False
            deep_health = False

        route = ask_monarch.routing_decision.route_decision_for_question(Args.question, "auto")
        payloads = []

        def fake_call_json(args, path, method="GET", payload=None):
            self.assertEqual(path, "/query")
            self.assertEqual(method, "POST")
            payloads.append(payload)
            adapter = payload["routing_decision"]["adapter"]
            if adapter == "bucket_assay_serving_table_sql":
                rows = [
                    {
                        "compound": "2PP",
                        "metric_name": "composite_score",
                        "metric_value": 0.91,
                        "ranking_score": 0.91,
                        "standard_deviation_status": "source_gap",
                        "evidence_rows": 1,
                        "provenance_grain": '{"locator":"fly#1"}',
                    }
                ]
            else:
                rows = [
                    {
                        "media_uri": "gs://monarch-videos-new/flies/top-repellent-2PP.mov",
                        "provenance_grain": '{"locator":"gs://monarch-videos-new/flies/top-repellent-2PP.mov"}',
                    }
                ]
            return {
                "ok": True,
                "source": payload["source"],
                "rows": rows,
            }

        with mock.patch("ask_monarch.call_json", side_effect=fake_call_json):
            result = ask_monarch.query_answer_shape_route_plan(Args, route)

        self.assertTrue(result["ok"])
        self.assertEqual(
            [step["planned_adapter"] for step in result["source_plan"]],
            ["bucket_fly_repellency_rankings_sql", "bucket_fly_result_video_bridge_sql"],
        )
        self.assertEqual(payloads[0]["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payloads[1]["routing_decision"]["adapter"], "bucket_fly_result_video_bridge_sql")
        self.assertEqual(payloads[0]["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payloads[1]["routing_decision"]["retrieval_shape"], "structured")

    def test_source_capability_map_routes_structured_homes(self):
        import ask_monarch

        cases = {
            "what is the safety data sheet for 2PP?": "compound_inventory",
            "which storage cabinet holds Menthone?": "compound_inventory",
            "which speakers mentioned oviposition yesterday?": "teams_recaps",
            "show utterances about Menthone from Friday morning": "teams_recaps",
            "which partner organizations are in the people data?": "people_directory",
            "what docking models exist for moth assays?": "bucket",
        }

        for question, source in cases.items():
            with self.subTest(question=question):
                self.assertEqual(ask_monarch.auto_source_for_question(question), source)

    def test_source_capability_map_exposes_matching_reason(self):
        import ask_monarch

        match = ask_monarch.routing_decision.source_capability_match_for_question(
            "what is the safety data sheet for 2PP?"
        )

        self.assertEqual(match["source"], "compound_inventory")
        self.assertEqual(match["retrieval_stage"], "structured_table_sql")
        self.assertEqual(match["capability_id"], "compound_inventory_fields")
        self.assertIn("safety data sheet", match["matched_alias"])

    def test_source_capability_match_produces_structured_payload(self):
        import ask_monarch

        inventory_payload = ask_monarch.query_payload_for_question(
            "what is the safety data sheet for 2PP?",
            "auto",
        )
        self.assertEqual(inventory_payload["source"], "compound_inventory")
        self.assertEqual(
            inventory_payload["routing_decision"]["adapter"],
            "compound_inventory_master_row_lookup",
        )
        self.assertEqual(
            inventory_payload["routing_decision"]["adapter_execution"],
            "typed_helper",
        )
        self.assertEqual(inventory_payload["routing_decision"]["retrieval_shape"], "structured")

        teams_payload = ask_monarch.query_payload_for_question(
            "which speakers mentioned oviposition yesterday?",
            "auto",
        )
        self.assertEqual(teams_payload["source"], "teams_recaps")
        self.assertIn("sql", teams_payload)
        self.assertNotIn("question", teams_payload)
        self.assertIn("utterances", teams_payload["sql"])
        self.assertEqual(
            teams_payload["routing_decision"]["adapter"],
            "teams_recaps_utterance_lookup_sql",
        )
        self.assertEqual(teams_payload["routing_decision"]["retrieval_shape"], "structured")

    def test_query_payload_uses_named_compound_assay_rows_for_experimental_data(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "show me the scientific literature for 2pp and how it correlates with our experimental data",
            "bucket",
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("dart_assay_results", payload["sql"])
        self.assertIn("2PP", payload["sql"])
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_dart_assay_results_sql")

    def test_query_payload_uses_structured_assay_ledger_for_all_tested_compounds(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "list all compounds monarch has tested",
            "auto",
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertNotIn("question", payload)
        self.assertIn("FROM compound_test_events e", payload["sql"])
        self.assertIn("latest_test_date", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )

    def test_recent_tested_compounds_do_not_sort_future_dated_rows_first(self):
        import ask_monarch
        import routing_decision

        payload = ask_monarch.query_payload_for_question(
            "list the most recently tested 10 compounds",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )
        self.assertIn("ORDER BY latest_test_date DESC", payload["sql"])

        db_path = os.path.join(
            ROOT,
            "artifacts",
            "monarch-videos-new",
            "source_index.sqlite",
        )
        if not os.path.exists(db_path):
            self.skipTest("monarch-videos-new source_index.sqlite is not present in this checkout")
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            serving_count = conn.execute(
                "SELECT count(*) AS n FROM sqlite_master WHERE type='table' AND name='compound_test_events'"
            ).fetchone()["n"]
            if not serving_count:
                self.skipTest("compound_test_events serving table is not present in this checkout")
            event_count = conn.execute("SELECT count(*) AS n FROM compound_test_events").fetchone()["n"]
            if not event_count:
                self.skipTest("compound_test_events serving table has no rows in this checkout")
            rows = conn.execute(payload["sql"]).fetchmany(10)

        self.assertGreater(len(rows), 0)
        latest_dates = [row["latest_test_date"] for row in rows if row["latest_test_date"]]
        self.assertTrue(latest_dates)
        self.assertLessEqual(max(latest_dates), routing_decision._local_today().isoformat())

    def test_tested_compound_date_scope_supports_last_two_weeks(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "list the compounds we have tested in experiments in the last 2 weeks",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("last_2_weeks", payload["sql"])
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )

    def test_ranking_shape_wins_before_broad_tested_compound_list(self):
        import ask_monarch

        phyto_payload = ask_monarch.query_payload_for_question(
            "list the most phytoxic compounds we have tested, from 1-5",
            "auto",
        )
        self.assertEqual(phyto_payload["source"], "bucket")
        self.assertIn("sql", phyto_payload)
        self.assertIn("FROM assay_results r", phyto_payload["sql"])
        self.assertIn("r.assay_family = 'phytotoxicity'", phyto_payload["sql"])
        self.assertIn("damaged_fraction", phyto_payload["sql"])
        self.assertEqual(
            phyto_payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )
        self.assertEqual(phyto_payload["routing_decision"]["answer_shape"], "ranked_phytotoxicity_compounds")
        self.assertEqual(phyto_payload["routing_decision"]["selection_policy"], "answer_shape_first")
        self.assertNotEqual(
            phyto_payload["routing_decision"]["adapter"],
            "bucket_compounds_tested_all_structured_sql",
        )

        fly_payload = ask_monarch.query_payload_for_question(
            "list the top compounds we tested on flies by repellency",
            "auto",
        )
        self.assertEqual(fly_payload["source"], "bucket")
        self.assertIn("sql", fly_payload)
        self.assertIn("FROM assay_results r", fly_payload["sql"])
        self.assertIn("r.species = 'flies'", fly_payload["sql"])
        self.assertEqual(
            fly_payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )
        self.assertNotEqual(
            fly_payload["routing_decision"]["adapter"],
            "bucket_compounds_tested_all_structured_sql",
        )

    def test_phytotoxicity_metric_lists_use_reference_guide_route(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "list the phytotoxicity metrics",
            "auto",
            limit=20,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_phytotox_metric_reference_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "metric_definition")
        self.assertIn("pdf_pages", payload["sql"])
        self.assertIn("documentation/phytotoxicity_metrics_reference_guide.pdf", payload["sql"])
        self.assertIn("csv_columns_with_provenance", payload["sql"])
        self.assertIn("time_trajectories.csv", payload["sql"])

    def test_inventory_sample_with_assay_bridge_calls_inventory_then_bucket(self):
        import ask_monarch

        class Args:
            question = "list 10 compounds in our inventory and 1 assay that used 1 of them"
            kind = "all"
            limit = 10
            offset = 0
            with_health = False
            deep_health = False

        inventory_compounds = [
            {"row_number": 552, "compound_name": "DEET", "provenance_grain": "{}"},
            {"row_number": 537, "compound_name": "Clove Oil", "provenance_grain": "{}"},
            {"row_number": 907, "compound_name": "Geraniol", "provenance_grain": "{}"},
            {"row_number": 688, "compound_name": "Irone", "provenance_grain": "{}"},
            {"row_number": 865, "compound_name": "Thymol", "provenance_grain": "{}"},
            {"row_number": 781, "compound_name": "nonanal", "provenance_grain": "{}"},
            {"row_number": 1, "compound_name": "A", "provenance_grain": "{}"},
            {"row_number": 2, "compound_name": "B", "provenance_grain": "{}"},
            {"row_number": 3, "compound_name": "C", "provenance_grain": "{}"},
            {"row_number": 4, "compound_name": "D", "provenance_grain": "{}"},
        ]

        def fake_call_json(args, path, method="GET", payload=None):
            self.assertEqual(path, "/query")
            self.assertEqual(method, "POST")
            if payload["source"] == "compound_inventory":
                return {
                    "ok": True,
                    "source": "compound_inventory",
                    "rows": [{"compounds_json": ask_monarch.json.dumps(inventory_compounds)}],
                }
            self.assertEqual(payload["routing_decision"]["source_lane"], "bucket")
            if "GROUP BY treatment_normalized" in payload["sql"]:
                return {
                    "ok": True,
                    "source": "bucket",
                    "rows": [{"treatment_normalized": "DEET", "assay_rows": 21}],
                }
            return {
                "ok": True,
                "source": "bucket",
                "rows": [
                    {
                        "species": "mosquitoes",
                        "assay_type": "DART",
                        "treatment_normalized": "DEET",
                        "assay_date": "2026-02-27",
                        "filename": "example.mov",
                        "provenance_grain": "{}",
                    }
                ],
            }

        with mock.patch("ask_monarch.call_json", side_effect=fake_call_json):
            result = ask_monarch.query_inventory_sample_with_assay(Args)

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "inventory_assay_bridge")
        self.assertEqual(len(result["inventory_compounds"]), 10)
        self.assertEqual(result["assay_rows"][0]["treatment_normalized"], "DEET")
        self.assertEqual(result["source_plan"][0]["adapter"], "compound_inventory_all_names_sql")
        self.assertEqual(result["source_plan"][1]["adapter"], "bucket_assay_results_by_compound_list")

    def test_phytotox_inventory_ranking_bridge_calls_bucket_then_inventory(self):
        import ask_monarch

        class Args:
            question = "list the most phytotoxic compounds in our inventory from 1-5"
            kind = "all"
            limit = 5
            offset = 0
            with_health = False
            deep_health = False

        inventory_compounds = [
            {"row_number": 11, "compound_name": "Linalyl acetate", "provenance_grain": "{}"},
            {"row_number": 12, "compound_name": "Beta-cyclocitral", "provenance_grain": "{}"},
            {"row_number": 13, "compound_name": "Methyl octanoate", "provenance_grain": "{}"},
        ]
        bucket_rows = [
            {
                "rank": 1,
                "compound": "Linalyl acetate",
                "avg_damaged_fraction": 0.9376,
                "result_rows": 24,
                "provenance_grain": "{}",
            },
            {
                "rank": 2,
                "compound": "Missing compound",
                "avg_damaged_fraction": 0.91,
                "result_rows": 24,
                "provenance_grain": "{}",
            },
            {
                "rank": 3,
                "compound": "Beta-cyclocitral",
                "avg_damaged_fraction": 0.8993,
                "result_rows": 24,
                "provenance_grain": "{}",
            },
        ]

        def fake_call_json(args, path, method="GET", payload=None):
            self.assertEqual(path, "/query")
            self.assertEqual(method, "POST")
            if payload["source"] == "bucket":
                self.assertEqual(payload["routing_decision"]["source_lane"], "bucket")
                self.assertIn("phytotoxicity/results", payload["sql"])
                return {"ok": True, "source": "bucket", "rows": bucket_rows}
            self.assertEqual(payload["source"], "compound_inventory")
            return {
                "ok": True,
                "source": "compound_inventory",
                "rows": [{"compounds_json": ask_monarch.json.dumps(inventory_compounds)}],
            }

        with mock.patch("ask_monarch.call_json", side_effect=fake_call_json):
            result = ask_monarch.query_phytotox_inventory_ranking(Args)

        self.assertTrue(result["ok"])
        self.assertEqual(result["mode"], "phytotox_inventory_ranking")
        self.assertEqual(result["source"], "route_plan")
        self.assertEqual(result["source_plan"][0]["adapter"], "bucket_phytotox_rank_compounds_sql")
        self.assertEqual(result["source_plan"][1]["adapter"], "compound_inventory_all_names_sql")
        self.assertEqual([row["compound"] for row in result["rows"]], ["Linalyl acetate", "Beta-cyclocitral"])
        self.assertTrue(result["rows"][0]["in_inventory"])
        self.assertEqual(result["rows"][0]["inventory_row"]["row_number"], 11)

    def test_query_payload_uses_structured_dart_sql_for_metric_questions(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "which DART treatments look most repellent?",
            "bucket",
        )

        self.assertIn("sql", payload)
        self.assertIn("dart_assay_results", payload["sql"])
        self.assertIn("mean_avg_pi", payload["sql"])
        self.assertNotIn("question", payload)
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_dart_assay_results_sql")
        self.assertIn("sql_sketch", payload)
        self.assertIn("FROM dart_assay_results", payload["sql_sketch"])
        self.assertIn("provenance_grain AS provenance", payload["sql_sketch"])

    def test_query_payload_uses_dart_ledger_for_beetle_assay_listing(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "list all the beetle assays",
            "auto",
            limit=50,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("FROM assay_runs r", payload["sql"])
        self.assertIn("r.species = 'beetles'", payload["sql"])
        self.assertNotIn("source_search", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "assay_run_list")
        self.assertIn("sql_sketch", payload)
        self.assertEqual(payload["routing_decision"]["sql_sketch"], payload["sql_sketch"])
        self.assertIn("FROM assay_runs", payload["sql_sketch"])
        self.assertIn("species, assay family", payload["sql_sketch"])
        self.assertIn("provenance_grain AS provenance", payload["sql_sketch"])

    def test_query_payload_uses_species_top_repellent_adapter(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what are the top repellents in mosquito assays?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("species", payload["sql"])
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["species"], "mosquitoes")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "ranked_species_repellent_compounds")

    def test_structured_compounds_tested_payload_has_readable_sql_sketch(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what compounds were tested last week?",
            "auto",
        )

        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertIn("sql_sketch", payload)
        self.assertIn("tested_compound", payload["sql_sketch"])
        self.assertIn("FROM compound_test_events", payload["sql_sketch"])
        self.assertNotIn("avg(avg_pi_real)", payload["sql_sketch"])

    def test_query_payload_uses_fly_repellency_ranking_adapter(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what are the most repellent compoudns on flies",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("r.species = 'flies'", payload["sql"])
        self.assertEqual(payload["routing_decision"]["intent"], "assay_serving_table")
        self.assertEqual(
            payload["routing_decision"]["adapter"],
            "bucket_assay_serving_table_sql",
        )
        self.assertEqual(payload["routing_decision"]["species"], "flies")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "ranked_fly_repellent_compounds")

    def test_query_payload_uses_recent_media_object_adapter(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "show me a recent no contact video",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertNotIn("question", payload)
        self.assertIn("FROM objects", payload["sql"])
        self.assertIn("%noncontact%", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_recent_media_by_mode_sql")

    def test_query_payload_uses_teams_meeting_digest_adapter(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what did the team discuss during last Friday's R&D meeting?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "teams_recaps")
        self.assertIn("sql", payload)
        self.assertIn("meetings", payload["sql"])
        self.assertIn("utterances", payload["sql"])
        self.assertEqual(payload["routing_decision"]["adapter"], "teams_recaps_meeting_digest_by_date_sql")

    def test_query_payload_uses_teams_meeting_digest_adapter_for_dated_team_discussion(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what did the team discuss yesterday?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "teams_recaps")
        self.assertIn("sql", payload)
        self.assertNotIn("question", payload)
        self.assertIn("date('now', '-1 day')", payload["sql"])
        self.assertNotIn("lower(title) LIKE '%r&d%'", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "teams_recaps_meeting_digest_by_date_sql")
        self.assertEqual(payload["routing_decision"]["fallback_policy"], "no_silent_prose_fallback")

    def test_query_payload_filters_daily_sync_meeting_when_named(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what did the team discuss in yesterday's daily sync meeting?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "teams_recaps")
        self.assertIn("lower(m.title) LIKE '%team sync%'", payload["sql"])
        self.assertEqual(payload["routing_decision"]["adapter"], "teams_recaps_meeting_digest_by_date_sql")

    def test_query_payload_resolves_latest_daily_sync_within_team_sync_series(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what did the team discuss in the latest daily sync meeting?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "teams_recaps")
        self.assertIn("SELECT max(m2.meeting_date) FROM meetings m2 WHERE lower(m2.title) LIKE '%team sync%'", payload["sql"])
        self.assertEqual(payload["routing_decision"]["adapter"], "teams_recaps_meeting_digest_by_date_sql")

    def test_query_payload_uses_bucket_structured_anchor_before_prose(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "why might peppermint oil be working?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("structured_anchor_sql", payload)
        self.assertIn("dart_assay_results", payload["structured_anchor_sql"])
        self.assertEqual(payload["question"], "why might peppermint oil be working?")
        self.assertNotIn("sql", payload)
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_structured_anchor_probe_sql")
        self.assertEqual(
            payload["routing_decision"]["adapter_execution"],
            "structured_anchor_then_text_retrieval",
        )

    def test_query_payload_uses_meeting_structured_anchor_before_prose(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what was the team uncertain about in last Friday's R&D meeting?",
            "auto",
            limit=5,
        )

        self.assertEqual(payload["source"], "teams_recaps")
        self.assertIn("structured_anchor_sql", payload)
        self.assertIn("meetings", payload["structured_anchor_sql"])
        self.assertEqual(payload["question"], "what was the team uncertain about in last Friday's R&D meeting?")
        self.assertNotIn("sql", payload)
        self.assertEqual(payload["routing_decision"]["adapter"], "teams_recaps_meeting_anchor_sql")
        self.assertEqual(
            payload["routing_decision"]["adapter_execution"],
            "structured_anchor_then_text_retrieval",
        )

    def test_query_payload_uses_structured_bucket_experiment_listing_sql(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "list the experiments from last week",
            "auto",
            limit=10,
        )

        self.assertEqual(payload["source"], "bucket")
        self.assertIn("sql", payload)
        self.assertIn("objects", payload["sql"])
        self.assertIn("experiment_key", payload["sql"])
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_experiment_listing_sql")

    def test_query_payload_uses_structured_bucket_model_sql_for_ai_model_questions(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "Across presentations, milestones, and bucket model evidence, how does Monarch use AI/computer vision for Improving models?",
            "bucket",
        )

        self.assertIn("sql", payload)
        self.assertIn("model_metadata", payload["sql"])
        self.assertNotIn("question", payload)

    def test_query_payload_extracts_leading_dart_treatment_for_bucket_sql(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "For Bcyclo, what DART/repellency evidence appears in bucket results, presentations, and R&D meeting recaps?",
            "bucket",
        )

        self.assertIn("sql", payload)
        self.assertIn("dart_assay_results", payload["sql"])
        self.assertIn("Bcyclo", payload["sql"])
        self.assertNotIn("question", payload)

    def test_planned_all_source_payloads_use_structured_lane_specific_queries(self):
        import ask_monarch

        payloads = ask_monarch.planned_all_source_payloads(
            "Do we have Bornyl acetate, and what bucket/presentation assay evidence exists for Bcyclo?",
            kind="all",
            limit=5,
            offset=0,
        )

        by_source = {payload["source"]: payload for payload in payloads}
        self.assertIn("sql", by_source["bucket"])
        self.assertIn("dart_assay_results", by_source["bucket"]["sql"])
        self.assertIn("Bcyclo", by_source["bucket"]["sql"])
        self.assertEqual(by_source["compound_inventory"].get("q"), "Bornyl acetate")
        self.assertEqual(by_source["presentations"].get("question"), "Do we have Bornyl acetate, and what bucket/presentation assay evidence exists for Bcyclo?")

    def test_query_payload_preserves_treatment_specific_dart_natural_helper(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "what was the best DART concentration for Eugenol in mosquitoes?",
            "bucket",
        )

        self.assertNotIn("sql", payload)
        self.assertEqual(
            payload["question"],
            "what was the best DART concentration for Eugenol in mosquitoes?",
        )
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_dart_best_concentration_helper")
        self.assertEqual(payload["routing_decision"]["adapter_execution"], "typed_helper")

    def test_query_payload_uses_structured_phytotoxicity_sql_for_metric_questions(self):
        import ask_monarch

        payload = ask_monarch.query_payload_for_question(
            "which phytotoxicity treatments have the highest damaged fraction?",
            "bucket",
        )

        self.assertIn("sql", payload)
        self.assertIn("FROM assay_results r", payload["sql"])
        self.assertIn("damaged_fraction", payload["sql"])
        self.assertNotIn("question", payload)
        self.assertEqual(payload["routing_decision"]["retrieval_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "bucket_assay_serving_table_sql")
        self.assertEqual(payload["routing_decision"]["answer_shape"], "ranked_phytotoxicity_compounds")
        self.assertEqual(payload["routing_decision"]["evidence_shape"], "assay_serving_table")
        self.assertIn("standard_deviation_status", payload["sql"])
        self.assertIn("evidence_rows", payload["sql"])

    def test_provenance_locator_prefers_media_locator(self):
        import ask_monarch

        locator = ask_monarch.provenance_locator(
            '{"locator":"gs://bucket/source.csv#row=2","media_locator":"gs://bucket/video.mov"}'
        )

        self.assertEqual(locator, "gs://bucket/video.mov")

    def test_resolve_source_locator_returns_url_without_opening(self):
        import ask_monarch

        result = ask_monarch.resolve_source_locator(
            "https://docs.google.com/presentation/d/deck-id/edit#slide=2",
            "/tmp/ask-monarch-test-cache",
            open_file=False,
        )

        self.assertEqual(result["locator"], "https://docs.google.com/presentation/d/deck-id/edit#slide=2")
        self.assertFalse(result["opened"])

    def test_metric_csv_from_locator_strips_bucket_and_row_fragment(self):
        import ask_monarch

        self.assertEqual(
            ask_monarch.metric_csv_from_locator(
                "gs://monarch-videos-new/mosquitoes/processed/run_results/run_results/advanced_metrics.csv#row=6"
            ),
            "mosquitoes/processed/run_results/run_results/advanced_metrics.csv",
        )

    def test_assay_overlay_command_uses_renderer_and_metric_csv(self):
        import ask_monarch

        class Args:
            metric_csv = "gs://monarch-videos-new/flies/processed/run_results/run_results/advanced_metrics.csv#row=51"
            locator = None
            repo = ROOT
            output = "videos/out/example.mp4"
            db = None
            input = None
            cache_dir = None
            out_dir = None
            tubes = None
            speed = 30
            fps = None
            width = None
            height = None
            refresh_video = False
            dry_run = True
            open = False

        command = ask_monarch.assay_overlay_command(Args)

        self.assertTrue(command[1].endswith("scripts/render_assay_metric_overlay.py"))
        self.assertIn("--metric-csv", command)
        self.assertIn("flies/processed/run_results/run_results/advanced_metrics.csv", command)
        self.assertIn("--dry-run", command)

    def test_open_local_video_uses_browser_player(self):
        import ask_monarch

        with tempfile.TemporaryDirectory() as tmp:
            video_path = os.path.join(tmp, "example.mp4")
            with open(video_path, "wb") as handle:
                handle.write(b"not a real video, only a path test")

            with mock.patch("ask_monarch.webbrowser.open") as open_mock:
                result = ask_monarch.open_local_path(video_path)

            self.assertTrue(result["opened"])
            self.assertEqual(result["open_mode"], "browser_player")
            self.assertTrue(result["player_path"].endswith(".html"))
            self.assertTrue(os.path.exists(result["player_path"]))
            open_mock.assert_called_once()

    def test_natural_search_query_drops_stopwords(self):
        import serve_http

        self.assertEqual(
            serve_http.fts_query("do we have Bornyl acetate and where is it?"),
            "bornyl* AND acetate*",
        )
        self.assertEqual(
            serve_http.fts_query("what mode-of-action assays did Monarch develop?"),
            "mode* AND action* AND assays* AND develop*",
        )
        self.assertEqual(
            serve_http.fts_or_query("which presentation mentions Color shift Pixel fractions?"),
            "color* OR shift* OR pixel* OR fractions*",
        )

    def test_inventory_query_terms_keep_compound_name_not_intent_words(self):
        import serve_http

        self.assertEqual(
            serve_http.inventory_query_terms("where is (-)-Bornyl acetate stored?"),
            ["bornyl", "acetate"],
        )
        self.assertEqual(
            serve_http.inventory_query_terms("who is the vendor for (2E)-2-hexenoic acid methyl ester?"),
            ["2e", "hexenoic", "acid", "methyl", "ester"],
        )
        self.assertEqual(
            serve_http.inventory_query_terms("what is the inventory code for 1-Hexanol?"),
            ["hexanol"],
        )
        self.assertEqual(
            serve_http.inventory_query_terms("what quantity is recorded for 1-Hexanol in inventory?"),
            ["hexanol"],
        )
        self.assertEqual(
            serve_http.inventory_query_terms("what is the CAS for DEET?"),
            ["deet"],
        )
        self.assertEqual(
            serve_http.inventory_query_terms("where do we store DEET?"),
            ["deet"],
        )
        self.assertEqual(
            serve_http.inventory_query_phrase("do we have 1-(4-methoxyphenyl)ethan-1-ol?"),
            "1-(4-methoxyphenyl)ethan-1-ol",
        )
        self.assertEqual(
            serve_http.inventory_query_phrase("where is 1-(4-methoxyphenyl)ethan-1-ol stored?"),
            "1-(4-methoxyphenyl)ethan-1-ol",
        )
        self.assertEqual(
            serve_http.inventory_query_phrase("what is the CAS for DEET?"),
            "DEET",
        )
        self.assertEqual(
            serve_http.inventory_query_phrase("where do we store DEET?"),
            "DEET",
        )

    def test_inventory_candidate_rank_prefers_exact_compound_name(self):
        import serve_http

        phrase = "1-(4-methoxyphenyl)ethan-1-ol"
        terms = ["methoxyphenyl", "ethan", "ol"]
        candidates = [
            {
                "row_number": 29,
                "name_value": "(2-methoxyphenyl)methanol",
                "haystack": "(2-methoxyphenyl)methanol (2-methoxyphenyl)methan-1-ol",
            },
            {
                "row_number": 101,
                "name_value": "1-(4-methoxyphenyl)ethan-1-ol",
                "haystack": "1-(4-methoxyphenyl)ethan-1-ol Room Temp M5",
            },
        ]

        ranked = sorted(candidates, key=lambda row: serve_http.inventory_candidate_rank(row, phrase, terms))

        self.assertEqual(ranked[0]["row_number"], 101)

    def test_people_query_terms_keep_person_name_not_intent_words(self):
        import serve_http

        self.assertEqual(
            serve_http.people_query_terms("who is Erica McAlister at Monarch?"),
            ["erica", "mcalister"],
        )
        self.assertEqual(
            serve_http.people_query_terms("what is Erica McAlister's role?"),
            ["erica", "mcalister"],
        )
        self.assertEqual(
            serve_http.people_query_terms("what is Josh's role?"),
            ["josh"],
        )

    def test_normalize_treatment_query_extracts_dart_treatment_phrase(self):
        import serve_http

        self.assertEqual(
            serve_http.normalize_treatment_query("what was the best DART concentration for Eugenol in mosquitoes?"),
            "eugenol",
        )
        self.assertEqual(
            serve_http.normalize_treatment_query("what was the best DART concentration for Clove Oil in mosquitoes?"),
            "clove oil",
        )
        self.assertEqual(
            serve_http.normalize_treatment_query("what was the best DART concentration for nonanal in beetles?"),
            "nonanal",
        )

    def test_species_from_question_handles_dart_species(self):
        import serve_http

        self.assertEqual(serve_http.species_from_question("best DART concentration for nonanal in beetles"), "beetles")
        self.assertEqual(serve_http.species_from_question("best DART concentration for DEET in mosquitoes"), "mosquitoes")

    def test_server_planned_all_payloads_use_structured_bucket_and_inventory(self):
        import serve_http

        payloads = serve_http.planned_all_source_payloads(
            {
                "source": "all",
                "question": "Do we have Bornyl acetate, and what bucket/presentation assay evidence exists for Bcyclo?",
                "kind": "all",
                "limit": 5,
            }
        )

        by_source = {payload["source"]: payload for payload in payloads}
        self.assertIn("sql", by_source["bucket"])
        self.assertIn("dart_assay_results", by_source["bucket"]["sql"])
        self.assertIn("Bcyclo", by_source["bucket"]["sql"])
        self.assertEqual(by_source["compound_inventory"].get("q"), "Bornyl acetate")

    def test_server_planned_all_payloads_use_model_metadata_for_ai_questions(self):
        import serve_http

        payloads = serve_http.planned_all_source_payloads(
            {
                "source": "all",
                "question": "Across presentations, milestones, and bucket model evidence, how does Monarch use AI/computer vision for Improving models?",
                "kind": "all",
                "limit": 5,
            }
        )

        by_source = {payload["source"]: payload for payload in payloads}
        self.assertIn("sql", by_source["bucket"])
        self.assertIn("model_metadata", by_source["bucket"]["sql"])


if __name__ == "__main__":
    unittest.main()
