import ast
from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
ROUTING_DECISION = SCRIPTS / "routing_decision.py"

CANONICAL_ROUTER_FUNCTIONS = {
    "auto_source_for_question",
    "priority_source_plan_for_question",
    "query_payload_for_question",
    "route_decision_for_question",
    "source_capability_match_for_question",
    "structured_sql_for_question",
    "structured_table_source_for_question",
    "text_source_hint_for_question",
}

ALLOWED_DELEGATING_WRAPPERS = {
    SCRIPTS / "ask_monarch.py": {
        "auto_source_for_question",
        "priority_source_plan_for_question",
        "query_payload_for_question",
        "structured_sql_for_question",
    },
}


def _functions_in(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return [
        node
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]


def _meaningful_body(function):
    body = list(function.body)
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and isinstance(body[0].value.value, str)
    ):
        body = body[1:]
    return body


def _delegates_to_routing_decision(function):
    body = _meaningful_body(function)
    if len(body) != 1 or not isinstance(body[0], ast.Return):
        return False
    call = body[0].value
    if not isinstance(call, ast.Call):
        return False
    func = call.func
    return (
        isinstance(func, ast.Attribute)
        and func.attr == function.name
        and isinstance(func.value, ast.Name)
        and func.value.id == "routing_decision"
    )


class RoutingCentralityGuardTests(unittest.TestCase):
    def test_canonical_router_functions_live_in_routing_decision(self):
        defined = {function.name for function in _functions_in(ROUTING_DECISION)}
        missing = sorted(CANONICAL_ROUTER_FUNCTIONS - defined)
        self.assertEqual(
            missing,
            [],
            "routing_decision.py must own the canonical source and route helpers",
        )

    def test_other_modules_only_expose_thin_routing_decision_wrappers(self):
        violations = []
        for path in sorted(SCRIPTS.glob("*.py")):
            if path == ROUTING_DECISION:
                continue
            allowed_wrappers = ALLOWED_DELEGATING_WRAPPERS.get(path, set())
            try:
                functions = _functions_in(path)
            except SyntaxError:
                text = path.read_text(encoding="utf-8")
                for match in re.finditer(r"^def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", text, re.MULTILINE):
                    if match.group(1) in CANONICAL_ROUTER_FUNCTIONS:
                        violations.append(
                            f"{path.relative_to(ROOT)}:{text.count(chr(10), 0, match.start()) + 1}:{match.group(1)}"
                        )
                continue
            for function in functions:
                if function.name not in CANONICAL_ROUTER_FUNCTIONS:
                    continue
                if (
                    function.name in allowed_wrappers
                    and _delegates_to_routing_decision(function)
                ):
                    continue
                violations.append(f"{path.relative_to(ROOT)}:{function.lineno}:{function.name}")

        self.assertEqual(
            violations,
            [],
            "Do not add a second source/router brain outside routing_decision.py. "
            "Expose only thin wrappers that delegate to routing_decision.",
        )


if __name__ == "__main__":
    unittest.main()
