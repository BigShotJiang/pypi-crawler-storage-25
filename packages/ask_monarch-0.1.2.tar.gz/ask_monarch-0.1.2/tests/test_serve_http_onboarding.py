import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http
from onboarding_codes import OnboardingCodeRegistry


class FakeSource:
    def health(self, deep=False):
        return {"ok": True, "deep": deep}

    def summary(self):
        return {"bucket": {"rows": 1}}


class ServeHttpOnboardingTest(unittest.TestCase):
    def make_server(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        registry = OnboardingCodeRegistry(
            os.path.join(tmp.name, "codes.json"),
            now=lambda: 1000.0,
            code_generator=lambda: "MNR-ABCD-1234",
        )
        handler = serve_http.make_handler(FakeSource(), token="shared-token", onboarding_registry=registry)
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        return f"http://127.0.0.1:{server.server_address[1]}"

    def post_json(self, url, payload, token=None):
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=5) as response:
            return response.status, json.loads(response.read().decode("utf-8"))

    def test_admin_creates_code_and_teammate_exchanges_without_existing_token(self):
        base_url = self.make_server()

        status, created = self.post_json(
            f"{base_url}/onboarding-codes",
            {"label": "Amir setup", "ttl_hours": 24},
            token="shared-token",
        )
        exchange_status, exchanged = self.post_json(
            f"{base_url}/onboarding/exchange",
            {"code": created["code"]},
        )

        self.assertEqual(status, 201)
        self.assertEqual(created["code"], "MNR-ABCD-1234")
        self.assertEqual(created["label"], "Amir setup")
        self.assertEqual(exchange_status, 200)
        self.assertEqual(exchanged["token"], "shared-token")
        self.assertTrue(exchanged["ok"])

    def test_create_requires_authorized_token(self):
        base_url = self.make_server()

        with self.assertRaises(urllib.error.HTTPError) as raised:
            self.post_json(f"{base_url}/onboarding-codes", {"label": "Amir setup"})

        self.assertEqual(raised.exception.code, 401)
        raised.exception.close()

    def test_installer_serves_cli_dependencies_without_auth(self):
        base_url = self.make_server()

        with urllib.request.urlopen(f"{base_url}/cli/routing_decision.py", timeout=5) as response:
            body = response.read().decode("utf-8")

        self.assertEqual(response.status, 200)
        self.assertIn("def query_payload_for_question", body)

        with urllib.request.urlopen(f"{base_url}/cli/evidence_shapes.py", timeout=5) as response:
            evidence_shapes_py = response.read().decode("utf-8")

        self.assertEqual(response.status, 200)
        self.assertIn("def shape_id_for_adapter", evidence_shapes_py)

        with urllib.request.urlopen(f"{base_url}/cli/answer_shape_contracts.py", timeout=5) as response:
            answer_shape_contracts_py = response.read().decode("utf-8")

        self.assertEqual(response.status, 200)
        self.assertIn("def enforce_answer_contract", answer_shape_contracts_py)

        package_expectations = (
            ("/cli/ask_monarch_cli/cli.py", "def main"),
            ("/cli/ask_monarch_cli/agent_setup.py", "def setup_agents"),
            ("/cli/ask_monarch_cli/routing_decision.py", "auto_source_for_question"),
            ("/cli/ask_monarch_cli/answer_shape_contracts.py", "def enforce_answer_contract"),
            ("/cli/ask_monarch_cli/__init__.py", ""),
        )
        for path, expected in package_expectations:
            with urllib.request.urlopen(f"{base_url}{path}", timeout=5) as response:
                body = response.read().decode("utf-8")
            self.assertEqual(response.status, 200)
            self.assertIn(expected, body)

        with urllib.request.urlopen(f"{base_url}/cli/query-routing.json", timeout=5) as response:
            routing_config = json.loads(response.read().decode("utf-8"))

        self.assertEqual(response.status, 200)
        self.assertIn("sources", routing_config)

        with urllib.request.urlopen(f"{base_url}/cli/source-capabilities.json", timeout=5) as response:
            source_capabilities = json.loads(response.read().decode("utf-8"))

        self.assertEqual(response.status, 200)
        self.assertIn("sources", source_capabilities)

        with urllib.request.urlopen(f"{base_url}/cli/evidence-shapes.json", timeout=5) as response:
            evidence_shapes_config = json.loads(response.read().decode("utf-8"))

        self.assertEqual(response.status, 200)
        self.assertIn("shapes", evidence_shapes_config)

        with urllib.request.urlopen(f"{base_url}/cli/adapter-modifiers.json", timeout=5) as response:
            adapter_modifiers_config = json.loads(response.read().decode("utf-8"))

        self.assertEqual(response.status, 200)
        self.assertIn("adapters", adapter_modifiers_config)


if __name__ == "__main__":
    unittest.main()
