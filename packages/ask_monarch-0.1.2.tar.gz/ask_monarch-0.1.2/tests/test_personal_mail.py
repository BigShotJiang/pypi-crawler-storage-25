import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import personal_mail
import serve_http


class PersonalMailOverlayTest(unittest.TestCase):
    def test_registry_maps_bearer_token_without_storing_raw_token(self):
        token = "ask-monarch-personal-token"
        payload = {
            "users": [
                {
                    "label": "Josh",
                    "email": "josh@monarchcrops.com",
                    "mailbox": "josh@monarchcrops.com",
                    "token_sha256": personal_mail.token_sha256(token),
                    "credential_mode": "application",
                    "tenant_id_env": "TEST_GRAPH_TENANT_ID",
                    "client_id_env": "TEST_GRAPH_CLIENT_ID",
                    "client_secret_env": "TEST_GRAPH_CLIENT_SECRET",
                }
            ]
        }
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False) as handle:
            json.dump(payload, handle)
            registry_path = handle.name
        try:
            os.environ["TEST_GRAPH_TENANT_ID"] = "tenant"
            os.environ["TEST_GRAPH_CLIENT_ID"] = "client"
            os.environ["TEST_GRAPH_CLIENT_SECRET"] = "secret"
            registry = personal_mail.PersonalSourceRegistry.load(registry_path)
            principal = registry.principal_for_token(token)
            self.assertIsNotNone(principal)
            self.assertEqual(principal["kind"], "personal")
            self.assertEqual(principal["mailbox"], "josh@monarchcrops.com")
            self.assertIsNone(registry.principal_for_token("wrong-token"))

            status = registry.public_status(principal=principal)
            self.assertTrue(status["ok"])
            self.assertEqual(status["personal_source_count"], 1)
            self.assertEqual(status["rows"][0]["credential_mode"], "application")
            self.assertTrue(status["rows"][0]["has_client_secret"])
            self.assertFalse(status["rows"][0]["indexed_into_shared_sqlite"])
        finally:
            os.unlink(registry_path)
            for key in ("TEST_GRAPH_TENANT_ID", "TEST_GRAPH_CLIENT_ID", "TEST_GRAPH_CLIENT_SECRET"):
                os.environ.pop(key, None)

    def test_registry_load_permission_error_disables_overlay_without_crashing(self):
        with mock.patch("builtins.open", side_effect=PermissionError("nope")):
            registry = personal_mail.PersonalSourceRegistry.load("/etc/ask-monarch/personal-sources.json")

        self.assertEqual(registry.users, [])
        self.assertIsNone(registry.principal_for_token("token"))
        status = registry.public_status()
        self.assertTrue(status["ok"])
        self.assertEqual(status["personal_source_count"], 0)
        self.assertIn("PermissionError", status["registry_load_error"])

    def test_application_mailbox_urls_use_mapped_monarch_mailbox(self):
        entry = {
            "email": "josh@monarchcrops.com",
            "mailbox": "josh@monarchcrops.com",
            "credential_mode": "application",
        }
        self.assertEqual(
            personal_mail.mailbox_base_url(entry),
            "https://graph.microsoft.com/v1.0/users/josh%40monarchcrops.com",
        )
        self.assertIn(
            "/users/josh%40monarchcrops.com/messages/message-1",
            personal_mail.graph_message_url(entry, "message-1"),
        )

    def test_http_personal_status_requires_personal_token(self):
        personal_token = "personal-token"
        shared_token = "shared-token"
        registry = personal_mail.PersonalSourceRegistry(
            [
                {
                    "label": "Josh",
                    "email": "josh@monarchcrops.com",
                    "mailbox": "josh@monarchcrops.com",
                    "token_sha256": personal_mail.token_sha256(personal_token),
                }
            ],
            path="/tmp/personal-sources.json",
        )
        handler = serve_http.make_handler(object(), token=shared_token, personal_registry=registry)
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            request = urllib.request.Request(
                f"{base}/personal-mail/status",
                headers={"Authorization": f"Bearer {personal_token}"},
            )
            with urllib.request.urlopen(request, timeout=5) as response:
                payload = json.loads(response.read().decode("utf-8"))
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["personal_source_count"], 1)

            request = urllib.request.Request(
                f"{base}/personal-mail/status",
                headers={"Authorization": f"Bearer {shared_token}"},
            )
            with self.assertRaises(urllib.error.HTTPError) as raised:
                urllib.request.urlopen(request, timeout=5)
            self.assertEqual(raised.exception.code, 403)
            raised.exception.close()
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
