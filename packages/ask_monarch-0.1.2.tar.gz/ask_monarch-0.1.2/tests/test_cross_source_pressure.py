import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
PRESSURE_PATH = ROOT / "scripts" / "run_cross_source_pressure.py"
SIM_PATH = ROOT / "scripts" / "run_question_simulator.py"


def load_pressure():
    sim_spec = importlib.util.spec_from_file_location("run_question_simulator", SIM_PATH)
    sim_module = importlib.util.module_from_spec(sim_spec)
    sys.modules["run_question_simulator"] = sim_module
    sim_spec.loader.exec_module(sim_module)

    spec = importlib.util.spec_from_file_location("run_cross_source_pressure", PRESSURE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules["run_cross_source_pressure"] = module
    spec.loader.exec_module(module)
    return module


class CrossSourcePressureTests(unittest.TestCase):
    def test_exact_inventory_check_uses_structured_row(self):
        pressure = load_pressure()
        row = {
            "row_number": 3,
            "name": "Bornyl acetate",
            "location": "Room Temp B1",
            "vendor": "Sigma",
        }

        check = pressure.exact_inventory_check(row)

        self.assertEqual(check.source, "compound_inventory")
        self.assertIn("row_number=3", check.command[2])
        self.assertIn("Bornyl", " ".join(check.expected_terms))

    def test_run_case_grades_lanes_and_all_query(self):
        pressure = load_pressure()
        case = pressure.CrossCase(
            id="ai_case",
            family="ai_model_story",
            question="Across lanes, what is AI evidence?",
            reference_answer="Deck, milestones, and bucket model agree.",
            checks=(
                pressure.EvidenceCheck(
                    "deck",
                    "presentations",
                    ("ask-monarch", "sql", "select 'AI model' as text", "--source", "presentations", "--limit", "1"),
                    ("AI",),
                ),
                pressure.EvidenceCheck(
                    "model",
                    "bucket",
                    ("ask-monarch", "sql", "select 'model.pt' as name", "--source", "bucket", "--limit", "1"),
                    ("model",),
                ),
            ),
            all_query="AI model evidence across lanes",
            expected_all_sources=("presentations", "bucket"),
        )

        def fake_cli(args, timeout=60):
            if args[:2] == ["ask-monarch", "query"]:
                payload = {
                    "ok": True,
                    "mode": "multi",
                    "source": "all",
                    "presentations": {"source": "presentations", "rows": [{"text": "AI model"}]},
                    "bucket": {"source": "bucket", "rows": [{"name": "model.pt"}]},
                }
            else:
                source = args[args.index("--source") + 1]
                payload = {
                    "ok": True,
                    "source": source,
                    "mode": "sql",
                    "rows": [
                        {
                            "text": "AI model",
                            "provenance_grain": json.dumps({"locator": f"{source}:row"}),
                        }
                    ],
                }
            return payload, 0.1, json.dumps(payload), "", 0

        original = pressure.sim.run_cli
        pressure.sim.run_cli = fake_cli
        try:
            result = pressure.run_case(case, timeout=1)
        finally:
            pressure.sim.run_cli = original

        self.assertTrue(result["ok"])
        self.assertTrue(result["evidence_ok"])
        self.assertTrue(result["all_query_ok"])
        self.assertEqual(result["all_result"]["source_counts"], {"bucket": 1, "presentations": 1})

    def test_html_renderer_outputs_cross_source_cards(self):
        pressure = load_pressure()
        summary = {
            "total": 1,
            "passed": 1,
            "failed": 0,
            "pass_rate": 100,
            "evidence_pass_rate": 100,
            "all_query_pass_rate": 100,
            "by_family": {"ai_model_story": {"total": 1, "passed": 1, "failed": 0}},
            "latency": {"average_seconds": 0.2},
        }
        results = [
            {
                "id": "case",
                "family": "ai_model_story",
                "question": "Across lanes, what is AI evidence?",
                "reference_answer": "A deck and model file.",
                "expected_all_sources": ["presentations", "bucket"],
                "ok": True,
                "evidence_ok": True,
                "all_query_ok": True,
                "errors": [],
                "checks": [],
                "all_query": "AI model evidence",
                "all_result": {"source_counts": {"presentations": 1, "bucket": 1}, "evidence_cards": []},
                "elapsed_seconds": 0.2,
            }
        ]
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "cards.html"
            pressure.write_html(output, summary, results)
            text = output.read_text(encoding="utf-8")

        self.assertIn("Cross-Source Pressure Cards", text)
        self.assertIn("Across lanes, what is AI evidence?", text)
        self.assertIn("data-family=\"ai_model_story\"", text)


if __name__ == "__main__":
    unittest.main()
