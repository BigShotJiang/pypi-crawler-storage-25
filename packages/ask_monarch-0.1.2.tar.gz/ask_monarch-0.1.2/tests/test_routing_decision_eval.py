import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class RoutingDecisionEvalTests(unittest.TestCase):
    def test_score_case_requires_visible_structured_first_check(self):
        import evaluate_askmonarch_routing_decisions as routing_eval

        case = {
            "id": "prose_without_structured_first",
            "question": "what does the literature say about odorant receptors?",
            "expected": {
                "mode": "search",
                "source": "scientific_refs",
                "intent": "source_specific_prose",
                "source_lane": "scientific_refs",
                "retrieval_shape": "prose",
                "adapter": "scientific_refs_source_text_retrieval",
            },
        }
        payload = {
            "mode": "search",
            "source": "scientific_refs",
            "rows": [{"text": "example"}],
            "routing_decision": {
                "intent": "source_specific_prose",
                "source_lane": "scientific_refs",
                "retrieval_shape": "prose",
                "adapter": "scientific_refs_source_text_retrieval",
            },
        }

        result = routing_eval.score_case(case, payload, 0.1)

        self.assertFalse(result["ok"])
        self.assertIn("structured_first.checked", result["failures"][0])

    def test_score_case_checks_evidence_shape_and_fallback_policy(self):
        import evaluate_askmonarch_routing_decisions as routing_eval

        case = {
            "id": "shape_mismatch",
            "question": "which speakers discussed assays",
            "expected": {
                "source_lane": "teams_recaps",
                "retrieval_shape": "structured",
                "adapter": "teams_recaps_topic_speaker_rollup_sql",
                "evidence_shape": "meeting_topic_speaker_rollup",
                "fallback_policy": "structured_first_then_prose",
            },
        }
        payload = {
            "mode": "sql",
            "source": "teams_recaps",
            "rows": [{"speaker": "Example"}],
            "routing_decision": {
                "source_lane": "teams_recaps",
                "retrieval_shape": "structured",
                "adapter": "teams_recaps_topic_speaker_rollup_sql",
                "evidence_shape": "wrong_shape",
                "fallback_policy": "no_silent_prose_fallback",
                "structured_first": {"checked": True, "source_lane": "teams_recaps"},
            },
        }

        result = routing_eval.score_case(case, payload, 0.1)

        self.assertFalse(result["ok"])
        self.assertIn("evidence_shape", "; ".join(result["failures"]))
        self.assertIn("fallback_policy", "; ".join(result["failures"]))

    def test_score_case_checks_answer_shape_and_selection_policy(self):
        import evaluate_askmonarch_routing_decisions as routing_eval

        case = {
            "id": "answer_shape_mismatch",
            "question": "list the most phytoxic compounds we have tested, from 1-5",
            "expected": {
                "source_lane": "bucket",
                "retrieval_shape": "structured",
                "adapter": "bucket_phytotox_rank_compounds_sql",
                "answer_shape": "ranked_phytotoxicity_compounds",
                "selection_policy": "answer_shape_first",
            },
        }
        payload = {
            "mode": "sql",
            "source": "bucket",
            "rows": [{"compound": "example"}],
            "routing_decision": {
                "source_lane": "bucket",
                "retrieval_shape": "structured",
                "adapter": "bucket_phytotox_rank_compounds_sql",
                "answer_shape": "tested_compound_list",
                "selection_policy": "first_matching_keyword",
                "structured_first": {"checked": True, "source_lane": "bucket"},
            },
        }

        result = routing_eval.score_case(case, payload, 0.1)

        self.assertFalse(result["ok"])
        self.assertIn("answer_shape", "; ".join(result["failures"]))
        self.assertIn("selection_policy", "; ".join(result["failures"]))

    def test_local_route_check_scores_route_without_row_requirement(self):
        import evaluate_askmonarch_routing_decisions as routing_eval

        case = {
            "id": "local_route_only",
            "question": "which speakers discussed assays",
            "source": "auto",
            "expected": {
                "mode": "sql",
                "source": "teams_recaps",
                "source_lane": "teams_recaps",
                "retrieval_shape": "structured",
                "adapter": "teams_recaps_topic_speaker_rollup_sql",
                "evidence_shape": "meeting_topic_speaker_rollup",
                "fallback_policy": "no_silent_prose_fallback",
                "min_rows": 10,
            },
        }

        result = routing_eval.run_local_case(case)

        self.assertTrue(result["ok"], result["failures"])
        self.assertEqual(result["observed"]["routing_decision"]["adapter"], "teams_recaps_topic_speaker_rollup_sql")


if __name__ == "__main__":
    unittest.main()
