import json
import argparse
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
CANARIES = ROOT / "evals" / "teammate_onboarding_canaries.json"
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in __import__("sys").path:
    __import__("sys").path.insert(0, str(SCRIPTS))

import simulate_teammate_onboarding as sim


class TeammateOnboardingSimulatorTest(unittest.TestCase):
    def test_canary_fixture_shape(self):
        canaries = json.loads(CANARIES.read_text())
        ids = [canary["id"] for canary in canaries]

        self.assertEqual(len(canaries), 5)
        self.assertEqual(len(set(ids)), 5)

        for canary in canaries:
            with self.subTest(canary=canary["id"]):
                self.assertIn("question", canary)
                self.assertIn("command", canary)
                self.assertIn("expect_ok", canary)
                self.assertIn("requires_rows", canary)
                self.assertIn("requires_provenance", canary)

                if canary["expect_ok"]:
                    self.assertIn("expected_source", canary)
                else:
                    self.assertIn("expected_gap", canary)

    def test_grade_supported_answer_requires_rows_source_and_provenance(self):
        canary = {
            "id": "company_identity",
            "expect_ok": True,
            "expected_source": "company_profile",
            "requires_rows": True,
            "requires_provenance": True,
        }
        payload = {
            "ok": True,
            "source": "company_profile",
            "rows": [
                {
                    "text": "Monarch develops insect-control systems.",
                    "provenance_grain": json.dumps(
                        {
                            "source_id": "monarch_company_profile",
                            "locator": "sources/monarch-company-profile/company_profile.json#mission",
                        }
                    ),
                }
            ],
        }

        result = sim.grade_answer(canary, payload, run_date="2026-05-09")

        self.assertTrue(result["ok"])
        self.assertEqual(result["status"], "pass")
        self.assertEqual(result["source"], "company_profile")

    def test_grade_supported_answer_fails_without_provenance(self):
        canary = {
            "id": "company_identity",
            "expect_ok": True,
            "expected_source": "company_profile",
            "requires_rows": True,
            "requires_provenance": True,
        }
        payload = {
            "ok": True,
            "source": "company_profile",
            "rows": [{"text": "Monarch develops insect-control systems."}],
        }

        result = sim.grade_answer(canary, payload, run_date="2026-05-09")

        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "fail")
        self.assertIn("missing_provenance", result["gaps"])

    def test_source_id_alone_is_not_meaningful_row_provenance(self):
        self.assertFalse(sim.row_has_provenance({"source_id": "company_profile"}))
        self.assertTrue(
            sim.row_has_provenance(
                {
                    "source_id": "company_profile",
                    "locator": "sources/monarch-company-profile/company_profile.json#mission",
                }
            )
        )

    def test_grade_requires_provenance_on_every_returned_dict_row(self):
        canary = {
            "id": "company_identity",
            "expect_ok": True,
            "expected_source": "company_profile",
            "requires_rows": True,
            "requires_provenance": True,
        }
        payload = {
            "ok": True,
            "source": "company_profile",
            "rows": [
                {
                    "text": "Monarch develops insect-control systems.",
                    "provenance_grain": json.dumps(
                        {
                            "source_id": "monarch_company_profile",
                            "locator": "sources/monarch-company-profile/company_profile.json#mission",
                        }
                    ),
                },
                {"text": "This second row is missing row-level provenance."},
            ],
        }

        result = sim.grade_answer(canary, payload, run_date="2026-05-09")

        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "fail")
        self.assertIn("missing_provenance", result["gaps"])

    def test_grade_expected_source_gap_passes_only_for_gap(self):
        canary = {
            "id": "unsupported_slack_gap",
            "expect_ok": False,
            "expected_gap": "source_gap",
            "requires_rows": False,
            "requires_provenance": False,
        }

        result = sim.grade_answer(
            canary,
            {"ok": False, "source_gap": {"message": "Slack is not queryable yet"}},
            run_date="2026-05-09",
        )

        self.assertTrue(result["ok"])
        self.assertEqual(result["status"], "pass")

        wrong_result = sim.grade_answer(
            canary,
            {"ok": False, "error": "network"},
            run_date="2026-05-09",
        )

        self.assertFalse(wrong_result["ok"])

    def test_expected_source_gap_check_does_not_require_zero_exit(self):
        canary = {
            "id": "unsupported_slack_gap",
            "expect_ok": False,
            "expected_gap": "source_gap",
            "requires_rows": False,
            "requires_provenance": False,
        }
        command_result = sim.CommandResult(
            name="answer:unsupported_slack_gap",
            ok=False,
            returncode=1,
            stdout='{"ok": false, "source_gap": {"message": "Slack is not queryable yet"}}',
            stderr="",
            elapsed_seconds=0.01,
            payload={"ok": False, "source_gap": {"message": "Slack is not queryable yet"}},
        )
        grade = sim.grade_answer(canary, command_result.payload, run_date="2026-05-09")

        self.assertTrue(sim.answer_check_ok(canary, command_result, grade))

    def test_grade_relative_date_requires_absolute_date_field_or_text(self):
        canary = {
            "id": "relative_team_date",
            "expect_ok": True,
            "expected_source": "teams_recaps",
            "requires_rows": True,
            "requires_provenance": True,
            "requires_absolute_date": True,
        }
        payload = {
            "ok": True,
            "source": "teams_recaps",
            "answer": "On Friday the team discussed assay setup.",
            "rows": [{"provenance_grain": json.dumps({"source_id": "teams_recaps", "locator": "meeting#1"})}],
        }

        result = sim.grade_answer(canary, payload, run_date="2026-05-09")

        self.assertFalse(result["ok"])
        self.assertIn("missing_absolute_date", result["gaps"])

    def test_grade_relative_date_ignores_dates_in_row_locators(self):
        canary = {
            "id": "relative_team_date",
            "expect_ok": True,
            "expected_source": "teams_recaps",
            "requires_rows": True,
            "requires_provenance": True,
            "requires_absolute_date": True,
        }
        payload = {
            "ok": True,
            "source": "teams_recaps",
            "answer": "On Friday the team discussed assay setup.",
            "rows": [
                {
                    "provenance_grain": json.dumps(
                        {
                            "source_id": "teams_recaps",
                            "locator": "meeting#2026-05-08",
                        }
                    )
                }
            ],
        }

        result = sim.grade_answer(canary, payload, run_date="2026-05-09")

        self.assertFalse(result["ok"])
        self.assertIn("missing_absolute_date", result["gaps"])

    def test_grade_relative_date_accepts_absolute_date_field(self):
        canary = {
            "id": "relative_team_date",
            "expect_ok": True,
            "expected_source": "teams_recaps",
            "requires_rows": True,
            "requires_provenance": True,
            "requires_absolute_date": True,
        }
        payload = {
            "ok": True,
            "source": "teams_recaps",
            "absolute_date": "2026-05-08",
            "answer": "On Friday, May 8, 2026, the team discussed assay setup.",
            "rows": [{"provenance_grain": json.dumps({"source_id": "teams_recaps", "locator": "meeting#1"})}],
        }

        result = sim.grade_answer(canary, payload, run_date="2026-05-09")

        self.assertTrue(result["ok"])
        self.assertEqual(result["status"], "pass")

    def test_payload_absolute_date_accepts_answer_metadata(self):
        payload = {
            "answer_metadata": {"resolved_date": "2026-05-08"},
            "rows": [{"source_id": "teams_recaps", "locator": "meeting#1"}],
        }

        self.assertTrue(sim.payload_has_absolute_date(payload))

    def test_agent_config_checks_cover_codex_and_claude_setup(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            (home / ".codex" / "skills" / "askmonarch").mkdir(parents=True)
            (home / ".codex" / "AGENTS.md").write_text("ASK_MONARCH_INSTALLER_BEGIN\n", encoding="utf-8")
            (home / ".codex" / "skills" / "askmonarch" / "SKILL.md").write_text("# askmonarch\n", encoding="utf-8")
            (home / ".claude" / "skills" / "ask-monarch").mkdir(parents=True)
            (home / ".claude" / "CLAUDE.md").write_text("ASK_MONARCH_INSTALLER_BEGIN\n", encoding="utf-8")
            (home / ".claude" / "skills" / "ask-monarch" / "SKILL.md").write_text("# ask-monarch\n", encoding="utf-8")

            checks = sim.agent_config_checks(home)

        self.assertEqual(
            [(check["name"], check["ok"], check.get("gaps", [])) for check in checks],
            [
                ("Codex config", True, []),
                ("Claude config", True, []),
            ],
        )

    def test_agent_config_checks_report_missing_claude_skill(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            (home / ".codex" / "skills" / "askmonarch").mkdir(parents=True)
            (home / ".codex" / "AGENTS.md").write_text("ASK_MONARCH_INSTALLER_BEGIN\n", encoding="utf-8")
            (home / ".codex" / "skills" / "askmonarch" / "SKILL.md").write_text("# askmonarch\n", encoding="utf-8")
            (home / ".claude").mkdir()
            (home / ".claude" / "CLAUDE.md").write_text("ASK_MONARCH_INSTALLER_BEGIN\n", encoding="utf-8")

            checks = sim.agent_config_checks(home)

        claude_check = next(check for check in checks if check["name"] == "Claude config")
        self.assertFalse(claude_check["ok"])
        self.assertIn("missing_claude_ask_monarch_skill", claude_check["gaps"])

    def test_grade_handles_non_dict_routing_decision(self):
        canary = {
            "id": "company_identity",
            "expect_ok": True,
            "requires_rows": False,
            "requires_provenance": False,
        }

        result = sim.grade_answer(
            canary,
            {"ok": True, "routing_decision": "company_profile"},
            run_date="2026-05-09",
        )

        self.assertTrue(result["ok"])
        self.assertIsNone(result["source"])

    def test_overall_status_blocks_on_failed_required_check(self):
        checks = [
            {"name": "doctor", "ok": True, "required": True},
            {"name": "answer:company_identity", "ok": False, "required": True},
            {"name": "Codex app", "ok": False, "required": False, "status": "manual_required"},
        ]

        result = sim.overall_status(checks)

        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "fail")
        self.assertIn("answer:company_identity", result["blocking_checks"])

    def test_redact_removes_token_values_from_nested_payloads(self):
        payload = {"token": "secret", "nested": {"Authorization": "Bearer abc"}, "safe": "ok"}

        redacted = sim.redact(payload)

        self.assertEqual(redacted["token"], "[redacted]")
        self.assertEqual(redacted["nested"]["Authorization"], "[redacted]")
        self.assertEqual(redacted["safe"], "ok")

    def test_redact_masks_token_values_inside_strings(self):
        payload = {
            "stdout": "\n".join(
                [
                    "Authorization: Bearer abc",
                    "ASK_MONARCH_TOKEN=abc",
                    "access_token=abc",
                    "ask-monarch query --token abc",
                ]
            )
        }

        redacted = sim.redact(payload)
        text = redacted["stdout"]

        self.assertIn("Authorization: Bearer [redacted]", text)
        self.assertIn("ASK_MONARCH_TOKEN=[redacted]", text)
        self.assertIn("access_token=[redacted]", text)
        self.assertIn("--token [redacted]", text)
        self.assertNotIn("Bearer abc", text)
        self.assertNotIn("ASK_MONARCH_TOKEN=abc", text)
        self.assertNotIn("access_token=abc", text)
        self.assertNotIn("--token abc", text)

    def test_redact_masks_json_token_values_inside_strings(self):
        payload = {
            "stdout": '{"ok": true, "token": "shared-token"}',
            "stderr": '{"access_token": "shared-token"}',
        }

        redacted = sim.redact(payload)

        self.assertEqual(redacted["stdout"], '{"ok": true, "token": "[redacted]"}')
        self.assertEqual(redacted["stderr"], '{"access_token": "[redacted]"}')
        self.assertNotIn("shared-token", redacted["stdout"])
        self.assertNotIn("shared-token", redacted["stderr"])

    def test_redact_masks_bare_bearer_token_inside_strings(self):
        payload = {"stderr": "Bearer shared-token"}

        redacted = sim.redact(payload)

        self.assertEqual(redacted["stderr"], "Bearer [redacted]")
        self.assertNotIn("shared-token", redacted["stderr"])

    def test_installer_command_uses_setup_code_without_printing_it(self):
        command = sim.installer_command("MNR-ABCD-1234", "https://example.test/install.sh")

        rendered = " ".join(command)

        self.assertEqual(command, ["bash", "-c", "curl -fsSL https://example.test/install.sh | bash"])
        self.assertNotIn("MNR-ABCD-1234", rendered)

    def test_teammate_env_filters_admin_credentials_and_overrides(self):
        host_env = {
            "ASK_MONARCH_TOKEN": "admin-token",
            "ASK_MONARCH_URL": "https://admin.example.test",
            "ASK_MONARCH_CLI_SCRIPT": "/Users/josh/projects/ask-monarch/scripts/ask_monarch_remote.py",
            "ASK_MONARCH_BIN": "/Users/josh/.local/bin/ask-monarch",
            "GITHUB_TOKEN": "github-token",
            "GH_TOKEN": "gh-token",
            "PATH": os.defpath,
            "TMPDIR": "/tmp",
            "LANG": "en_US.UTF-8",
        }

        with mock.patch.dict(sim.os.environ, host_env, clear=True):
            env = sim.teammate_env(Path("/tmp/fake-home"), "MNR-ABCD-1234")

        self.assertEqual(env["HOME"], "/tmp/fake-home")
        self.assertEqual(env["CODEX_HOME"], "/tmp/fake-home/.codex")
        self.assertEqual(env["ASK_MONARCH_SETUP_CODE"], "MNR-ABCD-1234")
        self.assertTrue(env["PATH"].startswith("/tmp/fake-home/.local/bin:"))
        self.assertEqual(env["TMPDIR"], "/tmp")
        self.assertEqual(env["LANG"], "en_US.UTF-8")
        for key in (
            "ASK_MONARCH_TOKEN",
            "ASK_MONARCH_URL",
            "ASK_MONARCH_CLI_SCRIPT",
            "ASK_MONARCH_BIN",
            "GITHUB_TOKEN",
            "GH_TOKEN",
        ):
            self.assertNotIn(key, env)

    def test_redact_masks_setup_code_values_inside_strings(self):
        payload = {
            "stdout": "\n".join(
                [
                    "ASK_MONARCH_SETUP_CODE=MNR-ABCD-1234",
                    "setup code: MNR-ABCD-1234",
                    "bare MNR-ABCD-1234 value",
                ]
            )
        }

        redacted = sim.redact(payload)
        text = redacted["stdout"]

        self.assertIn("ASK_MONARCH_SETUP_CODE=[redacted]", text)
        self.assertIn("setup code: [redacted]", text)
        self.assertIn("bare [redacted] value", text)
        self.assertNotIn("MNR-ABCD-1234", text)

    def test_run_command_parses_json_stdout(self):
        completed = SimpleNamespace(
            returncode=0,
            stdout='{"ok": true, "summary": {"company_profile": {"units": 7}}}',
            stderr="",
        )
        with mock.patch.object(sim.subprocess, "run", return_value=completed):
            result = sim.run_command(
                "summary",
                ["ask-monarch", "summary"],
                env={},
                cwd=ROOT,
                timeout=3,
            )

        self.assertTrue(result.ok)
        self.assertTrue(result.payload["ok"])

    def test_run_command_parses_noisy_json_stdout(self):
        completed = SimpleNamespace(
            returncode=0,
            stdout='installed ok\n{"ok": false}\n{"ok": true, "final": true}\n',
            stderr="",
        )
        with mock.patch.object(sim.subprocess, "run", return_value=completed):
            result = sim.run_command(
                "summary",
                ["ask-monarch", "summary"],
                env={},
                cwd=ROOT,
                timeout=3,
            )

        self.assertTrue(result.ok)
        self.assertTrue(result.payload["ok"])
        self.assertTrue(result.payload["final"])

    def test_run_command_returns_failure_for_missing_binary(self):
        with mock.patch.object(sim.subprocess, "run", side_effect=FileNotFoundError("missing binary")):
            result = sim.run_command(
                "doctor",
                ["/missing/ask-monarch", "doctor"],
                env={},
                cwd=ROOT,
                timeout=3,
            )

        self.assertFalse(result.ok)
        self.assertEqual(result.returncode, 127)
        self.assertIn("missing binary", result.stderr)

    def test_run_command_returns_failure_for_timeout(self):
        timeout = subprocess.TimeoutExpired(["ask-monarch", "summary"], timeout=3, output="partial")
        with mock.patch.object(sim.subprocess, "run", side_effect=timeout):
            result = sim.run_command(
                "summary",
                ["ask-monarch", "summary"],
                env={},
                cwd=ROOT,
                timeout=3,
            )

        self.assertFalse(result.ok)
        self.assertEqual(result.returncode, 124)
        self.assertIn("timed out", result.stderr)

    def test_temp_home_simulation_removes_auto_home_by_default(self):
        args = argparse.Namespace(
            setup_code="MNR-ABCD-1234",
            ask_monarch_bin=str(ROOT / "missing"),
            ttl_hours=1.0,
            timeout=3,
            home=None,
            install_url="https://example.test/install.sh",
            keep_home=False,
            canaries=str(CANARIES),
        )

        def fake_run_command(name, command, *, env, cwd, timeout):
            if name == "install":
                bin_dir = Path(env["HOME"]) / ".local" / "bin"
                bin_dir.mkdir(parents=True, exist_ok=True)
                (bin_dir / "ask-monarch").write_text("#!/bin/sh\n", encoding="utf-8")
            return sim.CommandResult(
                name=name,
                ok=True,
                returncode=0,
                stdout='{"ok": true}',
                stderr="",
                elapsed_seconds=0.01,
                payload={"ok": True},
            )

        with mock.patch.object(sim, "run_command", side_effect=fake_run_command):
            with mock.patch.object(sim, "load_canaries", return_value=[]):
                report = sim.run_temp_home_simulation(args)

        self.assertFalse(Path(report["home"]).exists())

    def test_temp_home_simulation_keeps_auto_home_when_requested(self):
        args = argparse.Namespace(
            setup_code="MNR-ABCD-1234",
            ask_monarch_bin=str(ROOT / "missing"),
            ttl_hours=1.0,
            timeout=3,
            home=None,
            install_url="https://example.test/install.sh",
            keep_home=True,
            canaries=str(CANARIES),
        )

        def fake_run_command(name, command, *, env, cwd, timeout):
            if name == "install":
                bin_dir = Path(env["HOME"]) / ".local" / "bin"
                bin_dir.mkdir(parents=True, exist_ok=True)
                (bin_dir / "ask-monarch").write_text("#!/bin/sh\n", encoding="utf-8")
            return sim.CommandResult(
                name=name,
                ok=True,
                returncode=0,
                stdout='{"ok": true}',
                stderr="",
                elapsed_seconds=0.01,
                payload={"ok": True},
            )

        with mock.patch.object(sim, "run_command", side_effect=fake_run_command):
            with mock.patch.object(sim, "load_canaries", return_value=[]):
                report = sim.run_temp_home_simulation(args)

        home = Path(report["home"])
        self.assertTrue(home.exists())
        with tempfile.TemporaryDirectory() as cleanup_root:
            cleanup_target = Path(cleanup_root) / "kept-home"
            home.rename(cleanup_target)

    def test_temp_home_simulation_fails_install_when_binary_is_missing(self):
        args = argparse.Namespace(
            setup_code="MNR-ABCD-1234",
            ask_monarch_bin=str(ROOT / "missing"),
            ttl_hours=1.0,
            timeout=3,
            home=None,
            install_url="https://example.test/install.sh",
            keep_home=False,
            canaries=str(CANARIES),
        )

        def fake_run_command(name, command, *, env, cwd, timeout):
            return sim.CommandResult(
                name=name,
                ok=True,
                returncode=0,
                stdout='{"ok": true}',
                stderr="",
                elapsed_seconds=0.01,
                payload={"ok": True},
            )

        with mock.patch.object(sim, "run_command", side_effect=fake_run_command):
            with mock.patch.object(sim, "load_canaries", return_value=[]):
                report = sim.run_temp_home_simulation(args)

        install = next(check for check in report["checks"] if check["name"] == "install")
        self.assertFalse(install["ok"])
        self.assertIn("missing_installed_binary", install["gaps"])
        self.assertIn("install", report["blocking_checks"])
