import json
import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class RAndDProbeEvalTests(unittest.TestCase):
    def test_probe_file_has_500_questions_and_required_families(self):
        path = os.path.join(ROOT, "evals", "askmonarch_r_and_d_probe_questions.json")
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)

        self.assertEqual(payload["version"], 1)
        self.assertEqual(len(payload["questions"]), 500)
        families = {item["family"] for item in payload["questions"]}
        for family in [
            "current_inventory",
            "dart_assay_ledger",
            "fly_aggregate_repellency",
            "fly_video_result_bridge",
            "phytotox_metadata",
            "docking",
            "oviposition",
            "teams_recap",
            "scientific_literature",
            "insect_image_corpus",
        ]:
            self.assertIn(family, families)

    def test_probe_questions_include_route_expectation_fields(self):
        path = os.path.join(ROOT, "evals", "askmonarch_r_and_d_probe_questions.json")
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)

        represented = [item for item in payload["questions"] if item.get("expected")]
        self.assertGreaterEqual(len(represented), 50)
        for item in represented:
            expected = item["expected"]
            self.assertIn("source_lane", expected)
            self.assertIn("retrieval_stage", expected)
            self.assertIn("fallback_allowed", expected)
