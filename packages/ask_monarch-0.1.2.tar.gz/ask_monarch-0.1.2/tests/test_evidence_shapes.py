import json
import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class EvidenceShapeRegistryTests(unittest.TestCase):
    def test_registry_loads_first_wave_shapes(self):
        import evidence_shapes

        registry = evidence_shapes.load_evidence_shape_registry()
        shape_ids = {shape["shape_id"] for shape in registry["shapes"]}

        self.assertIn("fly_result_video_bridge", shape_ids)
        self.assertIn("assay_quality_report", shape_ids)
        self.assertIn("insect_image_taxonomy_inventory", shape_ids)
        self.assertIn("meeting_topic_speaker_rollup", shape_ids)
        self.assertIn("fly_trial_metadata_join", shape_ids)
        self.assertIn("phytotox_experiment_summary", shape_ids)
        self.assertIn("phytotox_metric_reference", shape_ids)
        self.assertIn("phytotox_compound_ranking", shape_ids)

    def test_adapter_lookup_returns_shape_id_and_latency_target(self):
        import evidence_shapes

        lookup = evidence_shapes.shape_for_adapter("bucket_fly_result_video_bridge_sql")

        self.assertEqual(lookup["shape_id"], "fly_result_video_bridge")
        self.assertEqual(lookup["source_lanes"], ["bucket"])
        self.assertEqual(lookup["fallback_policy"], "no_silent_prose_fallback")
        self.assertEqual(lookup["latency_target_ms"]["p95"], 3000)

    def test_every_shape_declares_required_contract_fields(self):
        import evidence_shapes

        required = {
            "shape_id",
            "description",
            "source_lanes",
            "grain",
            "required_fields",
            "adapter",
            "indexes",
            "answer_limit",
            "source_gap_rule",
            "fallback_policy",
            "trace_fields",
            "latency_target_ms",
            "eval_examples",
        }
        registry = evidence_shapes.load_evidence_shape_registry()
        for shape in registry["shapes"]:
            with self.subTest(shape=shape.get("shape_id")):
                self.assertTrue(required.issubset(shape.keys()))
                self.assertTrue(shape["shape_id"])
                self.assertTrue(shape["adapter"])
                self.assertGreaterEqual(shape["answer_limit"], 1)
                self.assertIn("p95", shape["latency_target_ms"])

    def test_registry_json_is_stable_and_machine_readable(self):
        path = os.path.join(ROOT, "config", "evidence-shapes.json")
        with open(path, "r", encoding="utf-8") as handle:
            parsed = json.load(handle)

        self.assertEqual(parsed["version"], 1)
        self.assertIsInstance(parsed["shapes"], list)

    def test_every_declared_structured_adapter_has_evidence_shape(self):
        import evidence_shapes

        routing_path = os.path.join(ROOT, "config", "query-routing.json")
        with open(routing_path, "r", encoding="utf-8") as handle:
            routing = json.load(handle)

        missing = []
        for source, config in routing["sources"].items():
            for adapter in config.get("structured_adapters", []):
                if evidence_shapes.shape_for_adapter(adapter) is None:
                    missing.append(f"{source}:{adapter}")

        self.assertEqual(missing, [])
