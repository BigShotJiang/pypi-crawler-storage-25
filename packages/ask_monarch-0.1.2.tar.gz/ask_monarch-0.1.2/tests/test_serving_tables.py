import json
import os
import sqlite3
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class ServingTableTests(unittest.TestCase):
    def test_builds_first_answer_ready_serving_tables_from_dart_and_media_links(self):
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            source_pipeline.init_db(conn)
            source_grain = json.dumps(
                {
                    "grain_type": "dart_assay_row",
                    "locator": "gs://monarch-videos-new/mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx#sheet=Assays&row=28",
                    "version_or_modified_time": "assay-gen",
                }
            )
            conn.execute(
                """
                INSERT INTO dart_assay_results
                (source_name, sheet, row_number, species, assay_type, assay_date,
                 filename, temp, rh, tube, slot, n_insects, n_insects_real,
                 treatment, treatment_normalized, dilution, dilution_real, solvent,
                 left_condition, right_condition, treatment_position, avg_pi_real,
                 generation, field_cells_json, provenance_grain)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx",
                    "Assays",
                    28,
                    "mosquitoes",
                    "DART",
                    "1162026",
                    "example.mov",
                    "26.8",
                    "57",
                    "3",
                    "A",
                    "15",
                    15,
                    "2PP",
                    "2PP",
                    "0.01",
                    0.01,
                    "EtOH",
                    "control",
                    "treatment",
                    "R",
                    -0.858,
                    "assay-gen",
                    "{}",
                    source_grain,
                ),
            )
            conn.execute(
                """
                INSERT INTO assay_media_links
                (link_id, assay_family, species, assay_date, assay_source_table,
                 assay_source_name, assay_sheet, assay_row_number, assay_record_id,
                 assay_filename, treatment, treatment_normalized, condition, replicate,
                 tube, slot, media_name, media_uri, media_kind, match_method,
                 confidence, provenance_grain)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    "link-1",
                    "DART",
                    "mosquitoes",
                    "1162026",
                    "dart_assay_results",
                    "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx",
                    "Assays",
                    28,
                    "record-1",
                    "example.mov",
                    "2PP",
                    "2PP",
                    "control / treatment",
                    "3",
                    "3",
                    "A",
                    "mosquitoes/videos/example.mov",
                    "gs://monarch-videos-new/mosquitoes/videos/example.mov",
                    "raw_video",
                    "exact_filename_basename",
                    "exact",
                    json.dumps({"locator": "gs://monarch-videos-new/mosquitoes/videos/example.mov"}),
                ),
            )

            counts = source_pipeline.build_serving_tables(conn)
            self.assertEqual(
                counts,
                {
                    "assay_runs": 1,
                    "assay_results": 1,
                    "compound_test_events": 1,
                    "media_links": 1,
                },
            )

            run = conn.execute("SELECT * FROM assay_runs").fetchone()
            self.assertEqual(run["run_date"], "2026-01-16")
            self.assertEqual(run["temp"], "26.8")
            self.assertEqual(run["rh"], "57")
            self.assertEqual(json.loads(run["provenance_grain"])["grain_type"], "assay_run")

            result = conn.execute("SELECT * FROM assay_results").fetchone()
            self.assertEqual(result["metric_name"], "avg_pi")
            self.assertEqual(result["metric_direction"], "more_negative_is_more_repellent")
            self.assertAlmostEqual(result["ranking_score"], 0.858)

            event = conn.execute("SELECT * FROM compound_test_events").fetchone()
            self.assertEqual(event["compound"], "2PP")
            self.assertEqual(event["test_date"], "2026-01-16")

            media = conn.execute("SELECT * FROM media_links").fetchone()
            self.assertEqual(media["run_id"], run["run_id"])
            self.assertEqual(media["media_uri"], "gs://monarch-videos-new/mosquitoes/videos/example.mov")

    def test_extends_serving_tables_to_contact_phytotox_oviposition_and_richer_metrics(self):
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            source_pipeline.init_db(conn)
            conn.execute(
                """
                INSERT INTO csv_rows (name, row_number, row_json, generation)
                VALUES (?, ?, ?, ?)
                """,
                (
                    "contact_repel_videos/flies/processed/combined_results.csv",
                    10,
                    json.dumps(
                        {
                            "video_stem": "DEET1",
                            "is_control": "False",
                            "insect_type": "fly",
                            "mean_contact_pi": "0.7985",
                            "mean_contact_pi_strict": "0.7984",
                            "frac_time_avoiding": "0.8956",
                            "mean_n_total": "2.66",
                            "confidence": "0.8",
                        }
                    ),
                    "contact-gen",
                ),
            )
            conn.execute(
                """
                INSERT INTO csv_rows (name, row_number, row_json, generation)
                VALUES (?, ?, ?, ?)
                """,
                (
                    "phytotoxicity/results/phytotoxicity_tests_4_02_26/predictions/analysis/features_all.csv",
                    7,
                    json.dumps(
                        {
                            "condition": "treatment",
                            "treatment_name": "PepOil",
                            "replicate": "1",
                            "time_point": "24h",
                            "date": "2026-04-02",
                            "image": "leaf.png",
                            "concentration": "0.01",
                            "damaged_fraction": "0.71",
                            "chlorosis_fraction": "0.2",
                            "healthy_green_fraction": "0.12",
                        }
                    ),
                    "phyto-gen",
                ),
            )
            metadata_cells = {
                "C3": "24h",
                "F3": "PepOil",
                "I3": "1",
                "J3": "23.5",
                "K3": "51",
            }
            for cell, value in metadata_cells.items():
                conn.execute(
                    """
                    INSERT INTO xlsx_cells (name, sheet, cell, row_number, value, generation)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        "phytotoxicity/images/phytotoxicity_tests_4_02_26/phytotoxicity_metadata_template.xlsx",
                        "Sheet1",
                        cell,
                        3,
                        value,
                        "phyto-meta-gen",
                    ),
                )
            conn.execute(
                """
                INSERT INTO objects
                (name, uri, kind, top_folder, ext, size, content_type, generation,
                 metageneration, md5_hash, crc32c, updated, time_created)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "flies/insect images /Oviposition/plate_001.png",
                    "gs://monarch-videos-new/flies/insect images /Oviposition/plate_001.png",
                    "image",
                    "flies",
                    ".png",
                    123,
                    "image/png",
                    "ovi-gen",
                    "1",
                    "hash",
                    "crc",
                    "2026-04-01T00:00:00Z",
                    "2026-04-01T00:00:00Z",
                ),
            )

            counts = source_pipeline.build_serving_tables(conn)
            self.assertEqual(counts["assay_runs"], 3)
            self.assertEqual(counts["compound_test_events"], 2)
            self.assertEqual(counts["media_links"], 1)
            self.assertGreaterEqual(counts["assay_results"], 8)

            contact_run = conn.execute(
                "SELECT * FROM assay_runs WHERE assay_family='contact_no_contact'"
            ).fetchone()
            self.assertEqual(contact_run["species"], "flies")
            self.assertEqual(contact_run["treatment_normalized"], "DEET1")
            self.assertIn("no indexed temperature", contact_run["source_gap_reason"])

            contact_metrics = {
                row["metric_name"]: row["metric_value"]
                for row in conn.execute(
                    "SELECT metric_name, metric_value FROM assay_results WHERE assay_family='contact_no_contact'"
                )
            }
            self.assertAlmostEqual(contact_metrics["mean_contact_pi"], 0.7985)
            self.assertAlmostEqual(contact_metrics["frac_time_avoiding"], 0.8956)

            phyto_run = conn.execute(
                "SELECT * FROM assay_runs WHERE assay_family='phytotoxicity'"
            ).fetchone()
            self.assertEqual(phyto_run["run_date"], "2026-04-02")
            self.assertEqual(phyto_run["temp"], "23.5")
            self.assertEqual(phyto_run["rh"], "51")

            phyto_metrics = {
                row["metric_name"]: row["ranking_score"]
                for row in conn.execute(
                    "SELECT metric_name, ranking_score FROM assay_results WHERE assay_family='phytotoxicity'"
                )
            }
            self.assertAlmostEqual(phyto_metrics["damaged_fraction"], 0.71)
            self.assertAlmostEqual(phyto_metrics["healthy_green_fraction"], -0.12)

            oviposition_run = conn.execute(
                "SELECT * FROM assay_runs WHERE assay_family='fly_oviposition'"
            ).fetchone()
            self.assertIn("no structured result metrics", oviposition_run["source_gap_reason"])
            oviposition_media = conn.execute(
                "SELECT * FROM media_links WHERE assay_family='fly_oviposition'"
            ).fetchone()
            self.assertEqual(oviposition_media["media_kind"], "image")

    def test_contact_stem_parser_ignores_file_extension_tokens(self):
        import source_pipeline

        self.assertEqual(source_pipeline.compound_from_contact_stem("_2propylphenol_contact_mov"), "2PP")
        self.assertEqual(source_pipeline.compound_from_contact_stem("IMG_0030_Contact_DEET"), "DEET")


if __name__ == "__main__":
    unittest.main()
