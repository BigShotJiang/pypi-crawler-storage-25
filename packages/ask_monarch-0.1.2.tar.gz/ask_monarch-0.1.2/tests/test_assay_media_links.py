import json
import os
import sqlite3
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class AssayMediaLinkTests(unittest.TestCase):
    def test_builds_queryable_video_link_from_assay_filename(self):
        import serve_http
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            status_path = os.path.join(tmp, "source_status.json")
            gaps_path = os.path.join(tmp, "gaps.json")
            with open(status_path, "w", encoding="utf-8") as handle:
                json.dump({}, handle)
            with open(gaps_path, "w", encoding="utf-8") as handle:
                json.dump([], handle)

            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            source_pipeline.init_db(conn)
            conn.execute(
                """
                INSERT INTO objects
                (name, uri, kind, top_folder, ext, size, content_type, generation,
                 metageneration, md5_hash, crc32c, updated, time_created)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "mosquitoes/videos/example_assay.mov",
                    "gs://monarch-videos-new/mosquitoes/videos/example_assay.mov",
                    "video",
                    "mosquitoes",
                    ".mov",
                    123,
                    "video/quicktime",
                    "video-gen",
                    "1",
                    "hash",
                    "crc",
                    "2026-04-28T14:44:46Z",
                    "2026-04-28T14:44:46Z",
                ),
            )
            conn.execute(
                """
                INSERT INTO media_metadata
                (name, media_type, width, height, duration_seconds, format_name,
                 metadata_json, generation)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "mosquitoes/videos/example_assay.mov",
                    "video",
                    1920,
                    1080,
                    606.1,
                    "mov,mp4,m4a,3gp,3g2,mj2",
                    "{}",
                    "video-gen",
                ),
            )
            conn.execute(
                """
                INSERT INTO dart_assay_results
                (source_name, sheet, row_number, species, assay_type, assay_date,
                 filename, treatment, treatment_normalized, left_condition,
                 right_condition, tube, slot, generation, field_cells_json,
                 provenance_grain)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx",
                    "Assays",
                    1255,
                    "mosquitoes",
                    "DART",
                    "4282026",
                    "example_assay.mov",
                    "2PP",
                    "2PP",
                    "control",
                    "treatment",
                    "tube-a",
                    "slot-1",
                    "assay-gen",
                    "{}",
                    json.dumps(
                        {
                            "locator": "gs://monarch-videos-new/mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx#sheet=Assays&row=1255"
                        }
                    ),
                ),
            )

            inserted = source_pipeline.build_assay_media_links(conn)
            self.assertEqual(inserted, 1)

            link = conn.execute("SELECT * FROM assay_media_links").fetchone()
            self.assertEqual(link["assay_source_table"], "dart_assay_results")
            self.assertEqual(link["assay_row_number"], 1255)
            self.assertEqual(link["media_uri"], "gs://monarch-videos-new/mosquitoes/videos/example_assay.mov")
            self.assertEqual(link["confidence"], "exact")
            self.assertIn("assay_locator", json.loads(link["provenance_grain"]))
            conn.commit()
            conn.close()

            source = serve_http.SourceIndex(db_path, status_path, gaps_path)
            result = source.query({"assay_media": {"row_number": 1255}, "limit": 5})

        self.assertEqual(result["mode"], "assay_media")
        self.assertEqual(result["source"], "bucket")
        self.assertEqual(len(result["rows"]), 1)
        self.assertEqual(result["rows"][0]["media_name"], "mosquitoes/videos/example_assay.mov")
        self.assertEqual(result["rows"][0]["duration_seconds"], 606.1)

    def test_builds_standalone_link_for_indexed_assay_video_without_ledger_row(self):
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            source_pipeline.init_db(conn)
            conn.execute(
                """
                INSERT INTO objects
                (name, uri, kind, top_folder, ext, size, content_type, generation,
                 metageneration, md5_hash, crc32c, updated, time_created)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "contact_repel_videos/flies/2PP_contact.MOV",
                    "gs://monarch-videos-new/contact_repel_videos/flies/2PP_contact.MOV",
                    "video",
                    "contact_repel_videos",
                    ".MOV",
                    456,
                    "video/quicktime",
                    "video-gen",
                    "1",
                    "hash",
                    "crc",
                    "2026-04-01T00:00:00Z",
                    "2026-04-01T00:00:00Z",
                ),
            )
            conn.execute(
                """
                INSERT INTO media_metadata
                (name, media_type, width, height, duration_seconds, format_name,
                 metadata_json, generation)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "contact_repel_videos/flies/2PP_contact.MOV",
                    "video",
                    1280,
                    720,
                    42.0,
                    "mov,mp4,m4a,3gp,3g2,mj2",
                    "{}",
                    "video-gen",
                ),
            )

            inserted = source_pipeline.build_assay_media_links(conn)
            self.assertEqual(inserted, 1)
            link = conn.execute("SELECT * FROM assay_media_links").fetchone()

        self.assertEqual(link["assay_source_table"], "media_metadata")
        self.assertEqual(link["assay_family"], "contact_repellency")
        self.assertEqual(link["species"], "flies")
        self.assertEqual(link["media_uri"], "gs://monarch-videos-new/contact_repel_videos/flies/2PP_contact.MOV")
        self.assertEqual(link["match_method"], "indexed_video_metadata")

    def test_missing_raw_video_returns_assay_and_processed_object_diagnostics(self):
        import serve_http
        import source_pipeline

        with tempfile.TemporaryDirectory() as tmp:
            db_path = os.path.join(tmp, "source_index.sqlite")
            status_path = os.path.join(tmp, "source_status.json")
            gaps_path = os.path.join(tmp, "gaps.json")
            with open(status_path, "w", encoding="utf-8") as handle:
                json.dump({}, handle)
            with open(gaps_path, "w", encoding="utf-8") as handle:
                json.dump([], handle)

            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            source_pipeline.init_db(conn)
            conn.execute(
                """
                INSERT INTO dart_assay_results
                (source_name, sheet, row_number, species, assay_type, assay_date,
                 filename, treatment, treatment_normalized, dilution, tube, slot,
                 generation, field_cells_json, provenance_grain)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx",
                    "Assays",
                    797,
                    "mosquitoes",
                    "DART",
                    "4022026",
                    "_2026_04_02_13_50_23_2MPB2_mov.mov",
                    "2MPB",
                    "2MPB",
                    "0.01",
                    "1",
                    "2",
                    "assay-gen",
                    "{}",
                    "{}",
                ),
            )
            conn.execute(
                """
                INSERT INTO objects
                (name, uri, kind, top_folder, ext, size, content_type, generation,
                 metageneration, md5_hash, crc32c, updated, time_created)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "mosquitoes/processed/_2026_04_02_13_50_23_2MPB2_mov_results/accuracy_report.png",
                    "gs://monarch-videos-new/mosquitoes/processed/_2026_04_02_13_50_23_2MPB2_mov_results/accuracy_report.png",
                    "image",
                    "mosquitoes",
                    ".png",
                    123,
                    "image/png",
                    "processed-gen",
                    "1",
                    "hash",
                    "crc",
                    "2026-04-03T03:08:04Z",
                    "2026-04-03T03:08:04Z",
                ),
            )
            conn.commit()
            conn.close()

            source = serve_http.SourceIndex(db_path, status_path, gaps_path)
            result = source.query(
                {
                    "assay_media": {"filename": "_2026_04_02_13_50_23_2MPB2_mov.mov"},
                    "limit": 5,
                }
            )

        self.assertEqual(result["rows"], [])
        self.assertTrue(result["diagnostics"]["raw_video_missing"])
        self.assertEqual(result["diagnostics"]["assay_rows"][0]["row_number"], 797)
        self.assertEqual(result["diagnostics"]["assay_rows"][0]["treatment"], "2MPB")
        self.assertEqual(result["diagnostics"]["related_objects"][0]["kind"], "image")
        self.assertEqual(result["diagnostics"]["raw_video_objects"], [])


if __name__ == "__main__":
    unittest.main()
