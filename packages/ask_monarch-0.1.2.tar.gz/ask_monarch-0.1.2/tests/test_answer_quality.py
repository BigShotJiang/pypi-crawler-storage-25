import unittest


class AnswerQualityTests(unittest.TestCase):
    def test_negative_answer_must_name_checked_sources_and_avoid_absolutes(self):
        import verify_askmonarch_answer_quality as quality

        case = {
            "id": "negative_no_email_source",
            "question": "Did Monarch email say anything about the latest DART run?",
            "kind": "negative",
            "checked_sources": ["bucket", "teams_recaps"],
            "answer": "I checked bucket and teams_recaps and do not see evidence in the parsed sources.",
        }

        quality.validate_answer_contract(case)

        case["answer"] = "I checked bucket and teams_recaps. Monarch never emailed about that."
        with self.assertRaisesRegex(AssertionError, "absolute negative"):
            quality.validate_answer_contract(case)

    def test_positive_answer_requires_claims_and_citations(self):
        import verify_askmonarch_answer_quality as quality

        case = {
            "id": "positive_mosquito_screening",
            "question": "How many mosquito DART chemicals were screened?",
            "kind": "composed",
            "required_claims": ["62 chemicals", "10 strongly repellent"],
            "answer": "Monarch screened 62 chemicals and found 10 strongly repellent candidates.",
            "evidence": [
                {
                    "source": "milestones_doc",
                    "rows": [{"provenance_grain": "{\"locator\":\"doc#p21\"}", "text": "62 chemicals; 10 strongly repellent"}],
                }
            ],
        }

        quality.validate_answer_contract(case)

        case["evidence"][0]["rows"][0].pop("provenance_grain")
        with self.assertRaisesRegex(AssertionError, "citation"):
            quality.validate_answer_contract(case)

    def test_cross_source_answer_requires_multiple_sources(self):
        import verify_askmonarch_answer_quality as quality

        case = {
            "id": "cross_source_ai",
            "question": "How does Monarch use AI?",
            "kind": "cross_source",
            "required_claims": ["computer vision", "model"],
            "answer": "Monarch uses computer vision and model workflows.",
            "evidence": [
                {"source": "presentations", "rows": [{"provenance_grain": "{\"locator\":\"deck#1\"}", "text": "computer vision"}]},
                {"source": "bucket", "rows": [{"provenance_grain": "{\"locator\":\"bucket#model\"}", "text": "model"}]},
            ],
        }

        quality.validate_answer_contract(case)

        case["evidence"] = case["evidence"][:1]
        with self.assertRaisesRegex(AssertionError, "multiple sources"):
            quality.validate_answer_contract(case)

    def test_case_metadata_must_explain_failure_and_correction(self):
        import verify_askmonarch_answer_quality as quality

        case = {
            "id": "explained_failure",
            "question": "What did the answer get wrong?",
            "failure": "The weak answer only returned a keyword hit.",
            "why_failed": "The answer did not prove the requested claim from source rows.",
            "correction": "Require exact claims, cited evidence rows, and the verification command.",
            "verification_command": "python3 scripts/verify_askmonarch_answer_quality.py --case-id explained_failure",
        }

        quality.validate_case_metadata(case)

        case.pop("correction")
        with self.assertRaisesRegex(AssertionError, "correction"):
            quality.validate_case_metadata(case)

    def test_evidence_highlights_keep_text_and_locator(self):
        import verify_askmonarch_answer_quality as quality

        evidence = [
            {
                "label": "deck row",
                "source": "presentations",
                "rows": [
                    {
                        "text": "Color shift: Pixel fractions falling into damage-color regions of HSV space",
                        "locator": "https://docs.example/slide=2",
                    }
                ],
            }
        ]

        highlights = quality.evidence_highlights(evidence)

        self.assertEqual(highlights[0]["label"], "deck row")
        self.assertEqual(highlights[0]["source"], "presentations")
        self.assertIn("Color shift", highlights[0]["text"])
        self.assertEqual(highlights[0]["locator"], "https://docs.example/slide=2")

    def test_evidence_highlights_prefer_required_claim_rows(self):
        import verify_askmonarch_answer_quality as quality

        evidence = [
            {
                "label": "inventory",
                "source": "compound_inventory",
                "rows": [
                    {"value": "B55203", "locator": "cell-B3"},
                    {"value": "Room Temp B1", "locator": "cell-C3"},
                    {"value": "(-)-Bornyl acetate", "locator": "cell-D3"},
                ],
            }
        ]

        highlights = quality.evidence_highlights(evidence, required_claims=["(-)-Bornyl acetate"])

        self.assertEqual(highlights[0]["text"], "(-)-Bornyl acetate")
        self.assertEqual(highlights[0]["locator"], "cell-D3")

    def test_evidence_highlights_trim_long_text(self):
        import verify_askmonarch_answer_quality as quality

        evidence = [{"label": "long", "source": "bucket", "rows": [{"text": "x" * 500, "locator": "row"}]}]

        highlights = quality.evidence_highlights(evidence)

        self.assertLessEqual(len(highlights[0]["text"]), 240)
        self.assertTrue(highlights[0]["text"].endswith("..."))

    def test_run_case_does_not_duplicate_command_errors(self):
        import verify_askmonarch_answer_quality as quality

        case = {
            "id": "bad_command_expectation",
            "question": "bad expectation",
            "failure": "x",
            "why_failed": "x",
            "correction": "x",
            "verification_command": "x",
            "answer": "x",
            "evidence_commands": [
                {
                    "label": "empty payload",
                    "command": ["python3", "-c", "print('{\"ok\": true, \"rows\": []}')"],
                    "expectations": [{"type": "payload_field_equals", "field": "source", "equals": "bucket"}],
                }
            ],
        }

        result = quality.run_case(case, timeout=5)

        self.assertFalse(result["ok"])
        self.assertEqual(len(result["errors"]), 1)
        self.assertIn("payload source expected", result["errors"][0])

    def test_validate_cases_rejects_duplicate_ids(self):
        import verify_askmonarch_answer_quality as quality

        cases = [
            {"id": "same", "verification_command": "cmd --case-id same"},
            {"id": "same", "verification_command": "cmd --case-id same"},
        ]

        with self.assertRaisesRegex(AssertionError, "duplicate case id"):
            quality.validate_cases(cases)

    def test_validate_cases_requires_matching_verification_command(self):
        import verify_askmonarch_answer_quality as quality

        cases = [{"id": "case_a", "verification_command": "cmd --case-id other"}]

        with self.assertRaisesRegex(AssertionError, "verification_command"):
            quality.validate_cases(cases)

    def test_check_only_does_not_write_outputs(self):
        import json
        import subprocess
        import sys
        import tempfile
        from pathlib import Path

        case = {
            "id": "negative_check_only",
            "kind": "negative",
            "question": "missing source",
            "failure": "x",
            "why_failed": "x",
            "correction": "x",
            "verification_command": "cmd --case-id negative_check_only",
            "checked_sources": ["bucket"],
            "answer": "I checked bucket and do not see this in the parsed source.",
        }

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            cases = tmp / "cases.json"
            json_output = tmp / "results.json"
            markdown_output = tmp / "findings.md"
            html_output = tmp / "ledger.html"
            cases.write_text(json.dumps([case]), encoding="utf-8")

            proc = subprocess.run(
                [
                    sys.executable,
                    "scripts/verify_askmonarch_answer_quality.py",
                    "--cases",
                    str(cases),
                    "--json-output",
                    str(json_output),
                    "--markdown-output",
                    str(markdown_output),
                    "--html-output",
                    str(html_output),
                    "--check-only",
                ],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )

            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertFalse(json_output.exists())
            self.assertFalse(markdown_output.exists())
            self.assertFalse(html_output.exists())


if __name__ == "__main__":
    unittest.main()
