import json
import os
import subprocess
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPT = os.path.join(ROOT, "scripts", "verify_rd_evidence_shape_goal.py")


class RDEvidenceShapeGoalVerifierTests(unittest.TestCase):
    def test_verifier_accepts_complete_probe_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            result_path = os.path.join(tmp, "results.json")
            with open(result_path, "w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "summary": {
                            "hard_ceiling_violations": 0,
                            "families": [{"family": "current_inventory", "p95_ms": 500}],
                        },
                        "results": [],
                    },
                    handle,
                )
            proc = subprocess.run(
                [sys.executable, SCRIPT, "--probe-results", result_path, "--skip-hosted"],
                cwd=ROOT,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )

        self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
        self.assertIn("completion audit passed", proc.stdout)
