import json
import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class RouteTriageLedgerTests(unittest.TestCase):
    def test_route_triage_ledger_is_machine_readable_and_prioritized(self):
        import verify_route_triage_ledger as verifier

        ledger_path = os.path.join(ROOT, "config", "route-triage-ledger.json")

        result = verifier.validate_ledger_file(ledger_path)

        self.assertEqual(result["errors"], [])
        self.assertGreaterEqual(result["route_count"], 10)
        self.assertEqual(result["next_batch"], ["assay_meeting_bridge", "result_video_bridge", "people_ownership_fast_path"])

    def test_route_triage_ledger_references_existing_probe_questions(self):
        import verify_route_triage_ledger as verifier

        ledger_path = os.path.join(ROOT, "config", "route-triage-ledger.json")
        probe_path = os.path.join(ROOT, "evals", "askmonarch_r_and_d_probe_questions.json")

        with open(ledger_path, "r", encoding="utf-8") as handle:
            ledger = json.load(handle)
        with open(probe_path, "r", encoding="utf-8") as handle:
            probes = json.load(handle)

        result = verifier.validate_probe_references(ledger, probes)

        self.assertEqual(result["errors"], [])
        self.assertGreaterEqual(result["referenced_probe_count"], 25)

    def test_route_triage_validator_rejects_missing_actionable_fields(self):
        import verify_route_triage_ledger as verifier

        bad_ledger = {
            "version": 1,
            "routes": [
                {
                    "id": "bad_route",
                    "family": "missing_fields",
                    "status": "needs_small_routing_rule",
                }
            ],
        }

        result = verifier.validate_ledger(bad_ledger)

        self.assertIn("routes[0].recurring_question_pattern is required", result["errors"])
        self.assertIn("routes[0].next_action is required", result["errors"])


if __name__ == "__main__":
    unittest.main()
