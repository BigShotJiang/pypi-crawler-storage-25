#!/usr/bin/env python3
import argparse
import getpass
import hashlib
import html
import json
import os
import re
import shutil
import shlex
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

from ask_monarch_cli import answer_shape_contracts
from ask_monarch_cli import routing_decision
from ask_monarch_cli.agent_setup import setup_agents


DEFAULT_URL = "https://ask-monarch.34.121.138.236.sslip.io"
CONFIG_PATH = os.path.expanduser("~/.config/ask-monarch/config.json")
SOURCE_CHOICES = ["auto", "bucket", "presentations", "teams_recaps", "company_profile", "people_directory", "company_context", "milestones_doc", "compound_inventory", "cross_experiment_docs", "scientific_refs", "chemistry_analysis", "all"]
SQL_SOURCE_CHOICES = ["bucket", "presentations", "teams_recaps", "company_profile", "people_directory", "company_context", "milestones_doc", "compound_inventory", "cross_experiment_docs", "scientific_refs", "chemistry_analysis"]
ALL_QUERY_SOURCES = SQL_SOURCE_CHOICES
DEFAULT_BRAINTRUST_ORG = "Andes"
DEFAULT_BRAINTRUST_PROJECT = "ask-monarch"
DEFAULT_BRAINTRUST_PROJECT_ID = "28216333-66fb-42a6-923b-622bda7a2fcc"
TRACE_FIELDS = {"trace_id", "trace_span_id", "trace_project", "trace_project_id", "trace_url", "trace_error"}
EXPECTED_CODEX_SKILLS = ("askmonarch", "monarch-source", "correction", "braintrust", "mosquitometa")
VERIFY_QUESTION = "what is Monarch?"
PARITY_REQUIRED_SOURCE_LANES = (
    "bucket",
    "presentations",
    "teams_recaps",
    "company_profile",
    "people_directory",
    "company_context",
    "milestones_doc",
    "compound_inventory",
    "scientific_refs",
)
PARITY_GLOBAL_PHRASES = (
    "ASK_MONARCH_INSTALLER_BEGIN",
    "Ask Monarch is the default answer path",
    "$HOME/.local/bin/ask-monarch",
    "Do not inspect an empty workspace",
    "Use structured sources before search",
    "Resolve relative dates to absolute dates",
    "Do not substitute upload-date object activity for run-date ledger evidence",
    "Answers must include source id and row/locator provenance",
)
PARITY_SKILL_PHRASES = (
    "Resolve the CLI before doing any source work",
    "Do not inspect an empty workspace",
    "Resolve relative dates to absolute dates",
    "Use structured sources before search",
    "Do not add `--with-health` as a default readiness ritual",
    "Use `--with-health` only when the user asks for runtime/source-plane proof or when debugging a failed, timed-out, or suspiciously empty retrieval",
    "Do not substitute upload-date object activity for run-date ledger evidence",
    "Answers must include source id and row/locator provenance",
)
VIDEO_EXTENSIONS = {".mov", ".mp4", ".m4v", ".avi", ".webm"}


def load_config():
    if not os.path.exists(CONFIG_PATH):
        return {}
    with open(CONFIG_PATH, "r", encoding="utf-8") as handle:
        return json.load(handle)


def save_config(config):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    tmp_path = f"{CONFIG_PATH}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2, sort_keys=True)
        handle.write("\n")
    os.chmod(tmp_path, 0o600)
    os.replace(tmp_path, CONFIG_PATH)
    os.chmod(CONFIG_PATH, 0o600)


def resolve_url(args, config):
    return (args.url or os.environ.get("ASK_MONARCH_URL") or config.get("url") or DEFAULT_URL).rstrip("/")


def resolve_token(args, config):
    return args.token or os.environ.get("ASK_MONARCH_TOKEN") or config.get("token")


def emit_json(payload):
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))


def enforce_answer_contract_for_result(question, result):
    return answer_shape_contracts.enforce_answer_contract(question, result)


def strip_trace_metadata(value):
    if isinstance(value, dict):
        return {
            key: strip_trace_metadata(child)
            for key, child in value.items()
            if key not in TRACE_FIELDS
        }
    if isinstance(value, list):
        return [strip_trace_metadata(item) for item in value]
    return value


def auto_source_for_question(question):
    # Keep source selection centralized in routing_decision.py. The CLI should
    # not maintain an independent keyword router that can drift from the router.
    return routing_decision.auto_source_for_question(question)


def people_query_for_question(question):
    q = question.lower()
    aliases = [
        ("Avinash Chandel", ["avinash", "chandel"]),
        ("Bryce Rogers", ["bryce", "rogers"]),
        ("Geoffrey Broadhead", ["geoffrey", "broadhead"]),
        ("Joel Kowalewski", ["joel", "kowalewski"]),
        ("Josh Tetrick", ["josh", "tetrick"]),
        ("Leila Domen", ["leila", "domen"]),
        ("Priyanka Mahadevia", ["priyanka", "mahadevia"]),
        ("Erica McAlister", ["erica", "mcalister"]),
    ]
    for canonical, terms in aliases:
        if any(re.search(rf"\b{re.escape(term)}\b", q) for term in terms):
            return canonical
    return None


def braintrust_trace_url(trace_id, project=DEFAULT_BRAINTRUST_PROJECT, project_id=DEFAULT_BRAINTRUST_PROJECT_ID, org=DEFAULT_BRAINTRUST_ORG):
    return (
        f"https://www.braintrust.dev/app/{urllib.parse.quote(org, safe='')}/p/{urllib.parse.quote(project, safe='')}/trace"
        f"?object_type=project_logs&object_id={urllib.parse.quote(project_id, safe='')}"
        f"&r={urllib.parse.quote(trace_id, safe='')}&s={urllib.parse.quote(trace_id, safe='')}"
    )


def request_json(url, token=None, method="GET", payload=None):
    headers = {"Accept": "application/json"}
    data = None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8")
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {"ok": False, "error": raw}
        payload.setdefault("ok", False)
        payload["http_status"] = exc.code
        return payload
    except urllib.error.URLError as exc:
        return {"ok": False, "error": str(exc)}


def call_json(args, path, method="GET", payload=None):
    config = load_config()
    url = resolve_url(args, config)
    token = resolve_token(args, config)
    if not token:
        raise SystemExit(
            "missing token; set ASK_MONARCH_TOKEN or run: ask-monarch configure"
        )
    if isinstance(payload, dict) and (getattr(args, "include_trace", False) or getattr(args, "open_trace", False)):
        payload = dict(payload)
        payload["trace"] = True
    result = request_json(f"{url}{path}", token, method=method, payload=payload)
    if getattr(args, "open_trace", False) and result.get("trace_url"):
        webbrowser.open(result["trace_url"])
    if not getattr(args, "include_trace", False):
        result = strip_trace_metadata(result)
    return result


def configure(args):
    config = load_config()
    url = args.url or input(f"Ask Monarch URL [{config.get('url', DEFAULT_URL)}]: ").strip() or config.get("url") or DEFAULT_URL
    token = args.token
    if not token and (getattr(args, "prompt_token", False) or sys.stdin.isatty()):
        token = getpass.getpass("Ask Monarch bearer token: ").strip()
    if not token:
        raise SystemExit("token is required")
    config.update({"url": url.rstrip("/"), "token": token})
    save_config(config)
    emit_json({"ok": True, "config_path": CONFIG_PATH, "url": config["url"]})


def onboarding_code_create(args):
    config = load_config()
    url = resolve_url(args, config)
    token = resolve_token(args, config)
    payload = {
        "email": args.email,
        "label": args.label,
        "reusable": not bool(getattr(args, "single_use", False)),
    }
    if args.ttl_hours:
        payload["ttl_hours"] = args.ttl_hours
    result = request_json(
        f"{url}/onboarding-codes",
        token=token,
        method="POST",
        payload=payload,
    )
    emit_json(result)
    return 0 if result.get("ok", False) else 1


def onboarding_code_exchange(args):
    config = load_config()
    url = resolve_url(args, config)
    result = request_json(
        f"{url}/onboarding/exchange",
        token=None,
        method="POST",
        payload={"code": args.code},
    )
    token = result.get("token")
    if result.get("ok") and token and not args.no_configure:
        config["url"] = url
        config["token"] = token
        save_config(config)
        emit_json(
            {
                "ok": True,
                "configured": True,
                "config_path": CONFIG_PATH,
                "url": url,
                "email": result.get("email", ""),
                "label": result.get("label", ""),
                "expires_at": result.get("expires_at"),
            }
        )
        return 0
    if result.get("ok"):
        sanitized = {key: value for key, value in result.items() if key != "token"}
        sanitized["configured"] = False
        emit_json(sanitized)
        return 0
    emit_json(result)
    return 1


def check_record(name, ok, severity, message, **extra):
    record = {"name": name, "ok": bool(ok), "severity": severity, "message": message}
    record.update(extra)
    return record


def path_contains(directory):
    directory = os.path.abspath(os.path.expanduser(directory))
    return directory in {
        os.path.abspath(os.path.expanduser(entry))
        for entry in os.environ.get("PATH", "").split(os.pathsep)
        if entry
    }


def skill_path(codex_home, skill_name):
    return os.path.join(codex_home, "skills", skill_name, "SKILL.md")


def codex_config_path(codex_home):
    return os.path.join(codex_home, "config.toml")


def codex_skill_config_enabled(codex_home, skill_name):
    config_path = codex_config_path(codex_home)
    if not os.path.exists(config_path):
        return False, config_path
    expected_path = skill_path(codex_home, skill_name)
    expected_path_line = f"path = {json.dumps(expected_path)}"
    in_skill_config = False
    path_matches = False
    enabled = False
    with open(config_path, "r", encoding="utf-8") as handle:
        for raw_line in list(handle) + ["["]:
            line = raw_line.strip()
            if line.startswith("["):
                if in_skill_config and path_matches:
                    return enabled, config_path
                in_skill_config = line == "[[skills.config]]"
                path_matches = False
                enabled = False
                continue
            if not in_skill_config or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if key == "path" and line == expected_path_line:
                path_matches = True
            elif key == "enabled":
                enabled = value.lower() == "true"
    return False, config_path


def global_agents_path(codex_home):
    return os.path.join(codex_home, "AGENTS.md")


def global_agents_ask_monarch_rule_present(codex_home):
    path = global_agents_path(codex_home)
    if not os.path.exists(path):
        return False, path
    with open(path, "r", encoding="utf-8") as handle:
        text = handle.read()
    return all(phrase in text for phrase in PARITY_GLOBAL_PHRASES[:4]), path


def file_contains_phrases(path, phrases):
    if not os.path.exists(path):
        return False, list(phrases)
    with open(path, "r", encoding="utf-8") as handle:
        text = handle.read()
    missing = [phrase for phrase in phrases if phrase not in text]
    return not missing, missing


def doctor(args):
    config = load_config()
    url = resolve_url(args, config)
    token = resolve_token(args, config)
    codex_home = os.environ.get("CODEX_HOME") or os.path.expanduser("~/.codex")
    expected_bin = os.environ.get("ASK_MONARCH_BIN") or os.path.expanduser("~/.local/bin/ask-monarch")
    expected_bin_dir = os.path.dirname(expected_bin)
    which_bin = shutil.which("ask-monarch")
    checks = []
    required_gaps = []

    def add_check(name, ok, severity, message, gap=None, **extra):
        checks.append(check_record(name, ok, severity, message, **extra))
        if not ok and severity == "required" and gap:
            required_gaps.append(gap)

    add_check(
        "config_file",
        os.path.exists(CONFIG_PATH),
        "required",
        "Ask Monarch config file exists.",
        gap="config_file_missing",
        config_path=CONFIG_PATH,
    )
    add_check(
        "token",
        bool(token),
        "required",
        "Ask Monarch token is configured. The token value is not printed.",
        gap="token_missing",
        has_token=bool(token),
    )
    add_check(
        "configured_url",
        bool(url),
        "required",
        "Ask Monarch URL is configured.",
        gap="url_missing",
        url=url,
        default_url=DEFAULT_URL,
    )
    add_check(
        "ask_monarch_binary",
        os.path.exists(expected_bin) and os.access(expected_bin, os.X_OK),
        "required",
        "ask-monarch binary exists and is executable at the installer target.",
        gap="ask_monarch_binary_missing",
        expected_path=expected_bin,
        discovered_path=which_bin,
    )
    add_check(
        "local_bin_on_path",
        path_contains(expected_bin_dir),
        "required",
        "The ask-monarch install directory is on PATH.",
        gap="local_bin_not_on_path",
        expected_directory=expected_bin_dir,
    )
    if which_bin:
        add_check(
            "which_ask_monarch",
            os.path.realpath(which_bin) == os.path.realpath(expected_bin),
            "required",
            "The ask-monarch command resolves to the installer target.",
            gap="ask_monarch_binary_shadowed",
            expected_path=expected_bin,
            discovered_path=which_bin,
        )
    else:
        add_check(
            "which_ask_monarch",
            False,
            "required",
            "The ask-monarch command is discoverable on PATH.",
            gap="ask_monarch_binary_not_discoverable",
            expected_path=expected_bin,
            discovered_path=None,
        )

    missing_skills = []
    installed_skills = []
    enabled_skills = []
    disabled_skills = []
    for skill_name in EXPECTED_CODEX_SKILLS:
        path = skill_path(codex_home, skill_name)
        if os.path.exists(path):
            installed_skills.append(skill_name)
            checks.append(
                check_record(
                    f"codex_skill:{skill_name}",
                    True,
                    "required",
                    f"Codex skill {skill_name} is installed.",
                    path=path,
                )
            )
            config_enabled, skill_config_path = codex_skill_config_enabled(codex_home, skill_name)
            if config_enabled:
                enabled_skills.append(skill_name)
                checks.append(
                    check_record(
                        f"codex_skill_config:{skill_name}",
                        True,
                        "required",
                        f"Codex skill {skill_name} is enabled in global skill config.",
                        path=path,
                        config_path=skill_config_path,
                    )
                )
            else:
                disabled_skills.append(skill_name)
                add_check(
                    f"codex_skill_config:{skill_name}",
                    False,
                    "required",
                    f"Codex skill {skill_name} is not enabled in global skill config.",
                    gap=f"codex_skill_disabled:{skill_name}",
                    path=path,
                    config_path=skill_config_path,
                )
        else:
            missing_skills.append(skill_name)
            add_check(
                f"codex_skill:{skill_name}",
                False,
                "required",
                f"Codex skill {skill_name} is missing.",
                gap=f"codex_skill_missing:{skill_name}",
                path=path,
            )

    agents_rule_present, agents_path = global_agents_ask_monarch_rule_present(codex_home)
    add_check(
        "global_agents_ask_monarch_rule",
        agents_rule_present,
        "required",
        "Global Codex AGENTS.md routes plain Monarch questions to Ask Monarch in new threads and all projects.",
        gap="global_agents_ask_monarch_rule_missing",
        path=agents_path,
    )

    health = request_json(f"{url}/health", token=token)
    add_check(
        "hosted_health",
        bool(health.get("ok")),
        "required",
        "Hosted Ask Monarch health endpoint returned ok.",
        gap="hosted_health_failed",
        response={key: value for key, value in health.items() if key != "trace_url"},
    )
    summary = request_json(f"{url}/summary", token=token)
    summary_payload = summary.get("summary") if isinstance(summary.get("summary"), dict) else {}
    if summary.get("http_status") in {401, 403}:
        summary_gap = "hosted_summary_unauthorized"
        summary_message = "Hosted Ask Monarch rejected the configured token for the source summary."
    elif summary.get("ok") and not summary_payload:
        summary_gap = "hosted_summary_empty"
        summary_message = "Hosted Ask Monarch source summary returned no source lanes."
    else:
        summary_gap = "hosted_summary_failed"
        summary_message = "Hosted Ask Monarch source summary returned source lanes."
    add_check(
        "hosted_summary",
        bool(summary.get("ok")) and bool(summary_payload),
        "required",
        summary_message,
        gap=summary_gap,
        http_status=summary.get("http_status"),
        error=summary.get("error"),
        source_count=len(summary_payload),
    )

    payload = {
        "ok": not required_gaps,
        "status": "ready" if not required_gaps else "needs_attention",
        "configured_url": url,
        "config_path": CONFIG_PATH,
        "codex_home": codex_home,
        "expected_binary": expected_bin,
        "discovered_binary": which_bin,
        "installed_skills": installed_skills,
        "missing_skills": missing_skills,
        "enabled_skills": enabled_skills,
        "disabled_skills": disabled_skills,
        "hosted_summary": {"source_count": len(summary_payload)},
        "required_gaps": required_gaps,
        "expected_private_differences": [
            "Josh's local repo checkouts, wiki vaults, and machine memory are not copied.",
            "Outlook, Teams, SharePoint, Google Drive, GitHub, and browser auth are separate account-specific integrations.",
        ],
        "optional_integrations": [
            "Install account-specific connectors only when the role requires them and the account owner approves access.",
            "Open a new Codex thread after setup so newly installed Ask Monarch skills are loaded.",
        ],
        "checks": checks,
    }
    emit_json(payload)
    return 0 if payload["ok"] else 1


def parity(args):
    config = load_config()
    url = resolve_url(args, config)
    token = resolve_token(args, config)
    codex_home = os.environ.get("CODEX_HOME") or os.path.expanduser("~/.codex")
    expected_bin = os.environ.get("ASK_MONARCH_BIN") or os.path.expanduser("~/.local/bin/ask-monarch")
    which_bin = shutil.which("ask-monarch")
    checks = []
    required_gaps = []

    def add_check(name, ok, message, gap=None, **extra):
        checks.append(check_record(name, ok, "required", message, **extra))
        if not ok and gap:
            required_gaps.append(gap)

    add_check(
        "cli_resolves",
        bool(which_bin) or (os.path.exists(expected_bin) and os.access(expected_bin, os.X_OK)),
        "ask-monarch resolves from PATH or the installer fallback path.",
        gap="parity_cli_missing",
        discovered_path=which_bin,
        fallback_path=expected_bin,
    )
    add_check(
        "config_token",
        bool(token),
        "Ask Monarch token is configured. The token value is not printed.",
        gap="parity_token_missing",
        has_token=bool(token),
        config_path=CONFIG_PATH,
    )

    agents_path = global_agents_path(codex_home)
    agents_ok, agents_missing = file_contains_phrases(agents_path, PARITY_GLOBAL_PHRASES)
    add_check(
        "global_agents_parity_contract",
        agents_ok,
        "Global Codex AGENTS.md carries the Ask Monarch teammate parity contract.",
        gap="parity_global_agents_contract_missing",
        path=agents_path,
        missing_phrases=agents_missing,
    )

    askmonarch_skill_path = skill_path(codex_home, "askmonarch")
    skill_ok, skill_missing = file_contains_phrases(askmonarch_skill_path, PARITY_SKILL_PHRASES)
    add_check(
        "askmonarch_skill_parity_contract",
        skill_ok,
        "Installed askmonarch skill carries source-routing and answer-shape parity rules.",
        gap="parity_skill_contract_missing",
        path=askmonarch_skill_path,
        missing_phrases=skill_missing,
    )

    disabled_skills = []
    missing_skills = []
    for skill_name in EXPECTED_CODEX_SKILLS:
        installed = os.path.exists(skill_path(codex_home, skill_name))
        enabled, _ = codex_skill_config_enabled(codex_home, skill_name)
        if not installed:
            missing_skills.append(skill_name)
        elif not enabled:
            disabled_skills.append(skill_name)
    add_check(
        "codex_skills_enabled",
        not missing_skills and not disabled_skills,
        "Ask Monarch skills are installed and enabled for new Codex threads.",
        gap="parity_codex_skills_not_enabled",
        missing_skills=missing_skills,
        disabled_skills=disabled_skills,
    )

    summary = request_json(f"{url}/summary", token=token)
    summary_payload = summary.get("summary") if isinstance(summary.get("summary"), dict) else {}
    missing_lanes = [lane for lane in PARITY_REQUIRED_SOURCE_LANES if lane not in summary_payload]
    add_check(
        "hosted_source_lanes",
        bool(summary.get("ok")) and not missing_lanes,
        "Hosted Ask Monarch exposes the expected shared source lanes.",
        gap="parity_hosted_source_lanes_missing",
        configured_url=url,
        missing_lanes=missing_lanes,
        http_status=summary.get("http_status"),
        error=summary.get("error"),
    )

    payload = {
        "ok": not required_gaps,
        "status": "parity_ready" if not required_gaps else "parity_needs_attention",
        "configured_url": url,
        "codex_home": codex_home,
        "expected_binary": expected_bin,
        "discovered_binary": which_bin,
        "required_gaps": required_gaps,
        "contract": {
            "default_answer_path": "hosted ask-monarch source plane",
            "no_fallbacks": "no web, general knowledge, empty workspace rummaging, raw files, SSH, direct SQLite, or ad hoc bucket browsing for ordinary Monarch answers",
            "relative_dates": "resolve to absolute dates in the answer",
            "source_priority": "use structured sources before search; do not substitute upload-date object activity for run-date ledger evidence",
            "provenance": "answers must include source id and row/locator provenance",
        },
        "checks": checks,
    }
    emit_json(payload)
    return 0 if payload["ok"] else 1


def call(args, path, method="GET", payload=None):
    result = call_json(args, path, method=method, payload=payload)
    emit_json(result)
    return 0 if result.get("ok", False) else 1


def query_all_sources(args):
    result = {
        "mode": "multi",
        "source": "all",
        "planned": True,
        "source_plan": [],
    }
    all_ok = True
    for payload in planned_all_source_payloads(
        args.question,
        kind=args.kind,
        limit=args.limit,
        offset=args.offset,
        include_health=False,
        deep_health=False,
    ):
        source = payload["source"]
        source_result = call_json(args, "/query", method="POST", payload=payload)
        source_result.setdefault("source", source)
        result[source] = source_result
        all_ok = all_ok and bool(source_result.get("ok", True))
        result["source_plan"].append(
            {
                "source": source,
                "mode": "sql" if "sql" in payload else "query",
                "query": payload.get("q") or payload.get("question"),
                "sql": payload.get("sql"),
            }
        )
    if args.with_health:
        result["health"] = call_json(args, "/health?deep=1" if args.deep_health else "/health")
    result["ok"] = all_ok
    return result


def priority_source_plan_for_question(question):
    return routing_decision.priority_source_plan_for_question(question)


def retrieval_stage_for_payload(source, payload):
    route = payload.get("routing_decision") if isinstance(payload.get("routing_decision"), dict) else {}
    if route.get("retrieval_shape") == "structured" and "sql" in payload:
        return "structured_table_sql"
    if route.get("retrieval_shape") == "mixed" and "structured_anchor_sql" in payload:
        return "structured_table_sql_then_fts_sql"
    if source in {"presentations", "milestones_doc", "scientific_refs", "teams_recaps", "company_context", "cross_experiment_docs"}:
        return "fts_sql"
    return "source_query"


def query_priority_sources(args, sources):
    result = {
        "mode": "priority_multi",
        "source": "priority_plan",
        "planned": True,
        "retrieval_priority": list(routing_decision.RETRIEVAL_PRIORITY),
        "stop_rules": [
            "If structured-table SQL cleanly answers the whole question, do not run FTS or document summarization.",
            "If FTS SQL cleanly answers the whole question, do not run document summarization.",
            "If a required structured step fails, stop with a source gap.",
        ],
        "source_plan": [],
    }
    all_ok = True
    for index, source in enumerate(sources, start=1):
        payload = query_payload_for_question(
            args.question,
            source,
            kind=args.kind,
            limit=args.limit,
            offset=args.offset,
            include_health=args.with_health and index == 1,
            deep_health=args.deep_health and index == 1,
        )
        source_result = call_json(args, "/query", method="POST", payload=payload)
        source_result.setdefault("source", source)
        result[source] = source_result
        ok = bool(source_result.get("ok", True))
        all_ok = all_ok and ok
        result["source_plan"].append(
            {
                "step": index,
                "source": source,
                "retrieval_stage": retrieval_stage_for_payload(source, payload),
                "retrieval_shape": payload.get("routing_decision", {}).get("retrieval_shape"),
                "adapter": payload.get("routing_decision", {}).get("adapter"),
                "query": payload.get("q") or payload.get("question"),
                "sql": payload.get("sql") or payload.get("structured_anchor_sql"),
            }
        )
        if not ok:
            result["short_circuit_fired"] = True
            result["short_circuit_after_step"] = index
            result["short_circuit_reason"] = "required_source_step_failed"
            break
    result.setdefault("short_circuit_fired", False)
    if args.with_health and sources and "health" not in result:
        result["health"] = result.get(sources[0], {}).get("health")
    result["ok"] = all_ok
    return enforce_answer_contract_for_result(args.question, result)


def query_answer_shape_route_plan(args, route):
    result = {
        "mode": "answer_shape_route_plan",
        "source": "route_plan",
        "planned": True,
        "routing_decision": route,
        "retrieval_priority": list(routing_decision.RETRIEVAL_PRIORITY),
        "stop_rules": [
            "Run structured-table SQL steps before FTS or document retrieval.",
            "If a required structured step fails, stop with a source gap.",
            "Only synthesize over retrieved evidence after planned retrieval finishes.",
        ],
        "source_plan": [],
    }
    all_ok = True
    for index, step in enumerate(route.get("route_plan") or [], start=1):
        source = step["source_lane"]
        step_question = step.get("question") or args.question
        payload = query_payload_for_question(
            step_question,
            source,
            kind=args.kind,
            limit=args.limit,
            offset=args.offset,
            include_health=args.with_health and index == 1,
            deep_health=args.deep_health and index == 1,
        )
        source_result = call_json(args, "/query", method="POST", payload=payload)
        result_key = f"{source}:{step.get('adapter') or index}"
        result[result_key] = source_result
        source_result.setdefault("source", source)
        ok = bool(source_result.get("ok", True))
        all_ok = all_ok and ok
        result["source_plan"].append(
            {
                "step": index,
                "source": source,
                "retrieval_stage": step.get("retrieval_stage") or retrieval_stage_for_payload(source, payload),
                "retrieval_shape": payload.get("routing_decision", {}).get("retrieval_shape"),
                "adapter": payload.get("routing_decision", {}).get("adapter"),
                "planned_adapter": step.get("adapter"),
                "query": payload.get("q") or payload.get("question"),
                "sql": payload.get("sql") or payload.get("structured_anchor_sql"),
            }
        )
        if not ok:
            result["short_circuit_fired"] = True
            result["short_circuit_after_step"] = index
            result["short_circuit_reason"] = "required_route_plan_step_failed"
            break
    result.setdefault("short_circuit_fired", False)
    result["ok"] = all_ok
    return enforce_answer_contract_for_result(args.question, result)


def inventory_sample_limit(question, default=10):
    match = re.search(r"\blist\s+(\d{1,3})\s+(?:compounds|chemicals)\b", str(question).lower())
    if match:
        return max(1, min(int(match.group(1)), 50))
    return default


def normalized_compound_key(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def _inventory_compound_maps(inventory_compounds):
    by_lower = {}
    by_compact = {}
    for compound in inventory_compounds:
        name = str(compound.get("compound_name") or "").strip()
        if not name:
            continue
        by_lower.setdefault(name.lower(), compound)
        compact = normalized_compound_key(name)
        if compact:
            by_compact.setdefault(compact, compound)
    return by_lower, by_compact


def inventory_compounds_from_rows(rows):
    rows = rows or []
    if len(rows) == 1 and isinstance(rows[0], dict) and rows[0].get("compounds_json"):
        try:
            parsed = json.loads(rows[0]["compounds_json"])
        except (TypeError, json.JSONDecodeError):
            return []
        return parsed if isinstance(parsed, list) else []
    return [
        row
        for row in rows
        if isinstance(row, dict) and str(row.get("compound_name") or "").strip()
    ]


def _phytotox_rank_compounds_sql(rank_direction="most"):
    return routing_decision.phytotox_rank_compounds_sql(rank_direction=rank_direction)


def query_phytotox_inventory_ranking(args):
    route = routing_decision.route_decision_for_question(args.question, "auto")
    rank_limit = int(route.get("limit") or min(max(1, int(args.limit)), 5))
    rank_direction = route.get("rank_direction") or "most"
    bucket_route = dict(route)
    bucket_route.update(
        {
            "source_lane": "bucket",
            "retrieval_shape": "structured",
            "adapter": "bucket_phytotox_rank_compounds_sql",
            "adapter_execution": "sql",
            "expected_grain_types": ["phytotox_result_row"],
        }
    )
    inventory_route = dict(route)
    inventory_route.update(
        {
            "source_lane": "compound_inventory",
            "retrieval_shape": "structured",
            "adapter": "compound_inventory_all_names_sql",
            "adapter_execution": "sql",
            "expected_grain_types": ["xlsx_cell"],
        }
    )
    inventory_route.pop("answer_shape", None)
    source_plan = [
        {
            "step": 1,
            "source": "bucket",
            "retrieval_stage": "structured_table_sql",
            "retrieval_shape": "structured",
            "adapter": "bucket_phytotox_rank_compounds_sql",
        },
        {
            "step": 2,
            "source": "compound_inventory",
            "retrieval_stage": "structured_table_sql",
            "retrieval_shape": "structured",
            "adapter": "compound_inventory_all_names_sql",
        },
    ]
    bucket_payload = {
        "source": "bucket",
        "kind": args.kind,
        "limit": max(50, min(500, rank_limit * 40)),
        "offset": 0,
        "include_health": args.with_health,
        "deep_health": args.deep_health,
        "routing_decision": bucket_route,
        "sql": routing_decision.phytotox_rank_compounds_sql(rank_direction=rank_direction),
    }
    bucket_result = call_json(args, "/query", method="POST", payload=bucket_payload)
    if not bucket_result.get("ok"):
        return {
            "ok": False,
            "mode": "phytotox_inventory_ranking",
            "source": "route_plan",
            "routing_decision": route,
            "source_plan": source_plan,
            "failed_step": "bucket_phytotox_rank_compounds_sql",
            "bucket": bucket_result,
        }

    inventory_payload = {
        "source": "compound_inventory",
        "kind": args.kind,
        "limit": 1000,
        "offset": 0,
        "routing_decision": inventory_route,
        "sql": routing_decision._compound_inventory_all_names_sql(),
    }
    inventory_result = call_json(args, "/query", method="POST", payload=inventory_payload)
    if not inventory_result.get("ok"):
        return {
            "ok": False,
            "mode": "phytotox_inventory_ranking",
            "source": "route_plan",
            "routing_decision": route,
            "source_plan": source_plan,
            "failed_step": "compound_inventory_all_names_sql",
            "bucket": bucket_result,
            "compound_inventory": inventory_result,
        }

    inventory_compounds = inventory_compounds_from_rows(inventory_result.get("rows") or [])
    inventory_by_lower, inventory_by_compact = _inventory_compound_maps(inventory_compounds)

    matched_rows = []
    rejected_rows = []
    for row in bucket_result.get("rows") or []:
        compound_name = str(row.get("compound") or row.get("treatment_name") or "").strip()
        inventory_row = inventory_by_lower.get(compound_name.lower()) or inventory_by_compact.get(normalized_compound_key(compound_name))
        if not inventory_row:
            rejected_rows.append(
                {
                    "compound": compound_name,
                    "reason": "not_found_in_inventory",
                    "rank": row.get("rank"),
                }
            )
            continue
        merged = dict(row)
        merged["in_inventory"] = True
        merged["inventory_row"] = inventory_row
        matched_rows.append(merged)
        if len(matched_rows) >= rank_limit:
            break

    ok = bool(matched_rows)
    result = {
        "ok": ok,
        "mode": "phytotox_inventory_ranking",
        "source": "route_plan",
        "planned": True,
        "routing_decision": route,
        "source_plan": source_plan,
        "rows": matched_rows,
        "rejected_rows": rejected_rows[:10],
        "bucket_row_count": len(bucket_result.get("rows") or []),
        "inventory_compound_count": len(inventory_compounds),
    }
    if not ok:
        result["source_gap"] = {
            "missing_adapter": "bucket_phytotox_inventory_ranking_plan",
            "intent": "phytotox_inventory_ranking",
            "source_lane": "route_plan",
            "message": "Ask Monarch ranked phytotoxicity compounds, but found no exact inventory matches for the ranked names.",
        }
    return result


def query_inventory_sample_with_assay(args):
    route = routing_decision.route_decision_for_question(args.question, "auto")
    bucket_route = dict(route)
    bucket_route.update(
        {
            "source_lane": "bucket",
            "retrieval_shape": "structured",
            "adapter": "bucket_assay_results_by_compound_list",
            "adapter_execution": "sql",
            "expected_grain_types": [],
        }
    )
    sample_limit = inventory_sample_limit(args.question, default=min(max(1, int(args.limit)), 10))
    inventory_payload = {
        "source": "compound_inventory",
        "kind": args.kind,
        "limit": 1000,
        "offset": 0,
        "include_health": args.with_health,
        "deep_health": args.deep_health,
        "routing_decision": route,
        "sql": routing_decision._compound_inventory_all_names_sql(),
    }
    inventory_result = call_json(args, "/query", method="POST", payload=inventory_payload)
    if not inventory_result.get("ok"):
        return {
            "ok": False,
            "mode": "inventory_assay_bridge",
            "source": "route_plan",
            "routing_decision": route,
            "source_plan": route.get("route_plan", []),
            "failed_step": "compound_inventory_all_names_sql",
            "compound_inventory": inventory_result,
        }

    inventory_compounds_all = inventory_compounds_from_rows(inventory_result.get("rows") or [])
    inventory_by_name, _inventory_by_compact = _inventory_compound_maps(inventory_compounds_all)

    treatment_payload = {
        "source": "bucket",
        "kind": args.kind,
        "limit": 200,
        "offset": 0,
        "routing_decision": bucket_route,
        "sql": """
            SELECT treatment_normalized, count(*) AS assay_rows
            FROM dart_assay_results
            WHERE treatment_normalized IS NOT NULL
              AND trim(treatment_normalized) <> ''
            GROUP BY treatment_normalized
            ORDER BY assay_rows DESC, treatment_normalized
        """,
    }
    treatment_result = call_json(args, "/query", method="POST", payload=treatment_payload)
    if not treatment_result.get("ok"):
        return {
            "ok": False,
            "mode": "inventory_assay_bridge",
            "source": "route_plan",
            "routing_decision": route,
            "source_plan": route.get("route_plan", []),
            "failed_step": "bucket_assay_results_by_compound_list",
            "compound_inventory": inventory_result,
            "bucket": treatment_result,
        }

    tested_inventory_compounds = []
    for row in treatment_result.get("rows") or []:
        treatment = str(row.get("treatment_normalized") or "").strip()
        inventory_row = inventory_by_name.get(treatment.lower())
        if not inventory_row:
            continue
        merged = dict(inventory_row)
        merged["matched_assay_treatment"] = treatment
        merged["assay_rows"] = row.get("assay_rows")
        tested_inventory_compounds.append(merged)

    selected = []
    seen = set()
    for compound in tested_inventory_compounds:
        name = str(compound.get("compound_name") or "").strip().lower()
        if name and name not in seen:
            selected.append(compound)
            seen.add(name)
        if len(selected) >= sample_limit:
            break
    for compound in inventory_compounds_all:
        name = str(compound.get("compound_name") or "").strip().lower()
        if name and name not in seen:
            selected.append(compound)
            seen.add(name)
        if len(selected) >= sample_limit:
            break

    if not tested_inventory_compounds:
        return {
            "ok": False,
            "mode": "inventory_assay_bridge",
            "source": "route_plan",
            "routing_decision": route,
            "source_plan": route.get("route_plan", []),
            "inventory_compounds": selected,
            "assay_rows": [],
            "source_gap": {
                "missing_adapter": "bucket_assay_results_by_compound_list",
                "intent": "inventory_sample_with_assay",
                "source_lane": "bucket",
                "message": "Ask Monarch listed inventory compounds, but found no exact DART assay treatment match for the checked inventory names.",
            },
        }

    assay_compound = tested_inventory_compounds[0]["matched_assay_treatment"]
    assay_literal = routing_decision.sql_literal(assay_compound)
    assay_payload = {
        "source": "bucket",
        "kind": args.kind,
        "limit": 1,
        "offset": 0,
        "routing_decision": bucket_route,
        "sql": f"""
            SELECT
              species,
              assay_type,
              treatment_normalized,
              treatment,
              dilution,
              assay_date,
              filename,
              avg_pi,
              provenance_grain
            FROM dart_assay_results
            WHERE lower(treatment_normalized) = lower({assay_literal})
               OR lower(treatment) = lower({assay_literal})
            ORDER BY assay_date DESC, filename
        """,
    }
    assay_result = call_json(args, "/query", method="POST", payload=assay_payload)
    assay_rows = assay_result.get("rows") or []
    ok = bool(assay_result.get("ok") and assay_rows)
    return {
        "ok": ok,
        "mode": "inventory_assay_bridge",
        "source": "route_plan",
        "planned": True,
        "routing_decision": route,
        "source_plan": [
            {
                "step": 1,
                "source": "compound_inventory",
                "retrieval_stage": "structured_table_sql",
                "retrieval_shape": "structured",
                "adapter": "compound_inventory_all_names_sql",
            },
            {
                "step": 2,
                "source": "bucket",
                "retrieval_stage": "structured_table_sql",
                "retrieval_shape": "structured",
                "adapter": "bucket_assay_results_by_compound_list",
            },
        ],
        "inventory_compounds": selected,
        "assay_compound": assay_compound,
        "assay_rows": assay_rows,
        "compound_inventory": inventory_result,
        "bucket": assay_result,
    }


def _media_cache_path(download_dir, media_uri):
    parsed = urllib.parse.urlparse(media_uri)
    filename = os.path.basename(parsed.path) if parsed.scheme else os.path.basename(media_uri)
    if not filename:
        filename = "assay-media"
    os.makedirs(download_dir, exist_ok=True)
    return os.path.join(download_dir, filename)


def _file_url(path):
    return urllib.parse.urljoin("file:", urllib.request.pathname2url(os.path.abspath(path)))


def is_video_path(path):
    return os.path.splitext(str(path).split("?", 1)[0].split("#", 1)[0])[1].lower() in VIDEO_EXTENSIONS


def local_video_player_path(video_path):
    video_path = os.path.abspath(video_path)
    player_dir = os.path.join(os.path.dirname(video_path), ".ask-monarch-player")
    os.makedirs(player_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(video_path))[0] or "video"
    html_path = os.path.join(player_dir, f"{stem}.html")
    title = os.path.basename(video_path)
    markup = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    :root {{ color-scheme: dark; background: #181818; color: #e4e4e4; }}
    body {{ margin: 0; min-height: 100vh; display: grid; grid-template-rows: auto 1fr; font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif; }}
    header {{ padding: 12px 16px; border-bottom: 1px solid #3a3a3a; color: #a6a6a6; font-size: 13px; }}
    main {{ display: grid; place-items: center; padding: 16px; }}
    video {{ width: min(100%, 1400px); max-height: calc(100vh - 84px); background: #000; outline: 1px solid #3a3a3a; }}
  </style>
</head>
<body>
  <header>{html.escape(title)}</header>
  <main>
    <video src="{html.escape(_file_url(video_path), quote=True)}" controls autoplay playsinline></video>
  </main>
</body>
</html>
"""
    with open(html_path, "w", encoding="utf-8") as handle:
        handle.write(markup)
    return html_path


def open_local_path(path):
    if is_video_path(path):
        player_path = local_video_player_path(path)
        webbrowser.open(_file_url(player_path))
        return {"opened": True, "open_mode": "browser_player", "player_path": player_path}
    webbrowser.open(_file_url(path))
    return {"opened": True, "open_mode": "file_url"}


def download_and_open_media(row, download_dir, open_file=False):
    media_uri = row.get("media_uri")
    if not media_uri:
        raise RuntimeError("assay media row does not include media_uri")
    if not media_uri.startswith("gs://"):
        raise RuntimeError(f"unsupported media uri for download: {media_uri}")
    local_path = _media_cache_path(download_dir, media_uri)
    if not os.path.exists(local_path) or os.path.getsize(local_path) == 0:
        subprocess.run(["gcloud", "storage", "cp", media_uri, local_path], check=True)
    opened = open_local_path(local_path) if open_file else {"opened": False}
    return {"local_path": local_path, **opened}


def provenance_locator(value):
    if isinstance(value, dict):
        provenance = value
    else:
        try:
            provenance = json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return None
    if not isinstance(provenance, dict):
        return None
    return provenance.get("media_locator") or provenance.get("locator")


def _strip_locator_fragment(locator):
    return str(locator).split("#", 1)[0]


def _source_cache_path(download_dir, locator):
    base_locator = _strip_locator_fragment(locator)
    parsed = urllib.parse.urlparse(base_locator)
    filename = os.path.basename(parsed.path) if parsed.scheme else os.path.basename(base_locator)
    if not filename:
        filename = "ask-monarch-source-artifact"
    os.makedirs(download_dir, exist_ok=True)
    return os.path.join(download_dir, filename)


def resolve_source_locator(locator, download_dir, open_file=False):
    if not locator:
        raise RuntimeError("source locator is required")
    locator = str(locator)
    base_locator = _strip_locator_fragment(locator)
    if locator.startswith("gs://"):
        local_path = _source_cache_path(download_dir, locator)
        if not os.path.exists(local_path) or os.path.getsize(local_path) == 0:
            subprocess.run(["gcloud", "storage", "cp", base_locator, local_path], check=True)
        if open_file:
            opened = open_local_path(local_path)
        else:
            opened = {"opened": False}
        return {"locator": locator, "local_path": local_path, **opened}
    if locator.startswith(("http://", "https://")):
        if open_file:
            webbrowser.open(locator)
        return {"locator": locator, "opened": bool(open_file)}
    candidates = [base_locator]
    repo_hint = os.environ.get("ASK_MONARCH_REPO")
    if repo_hint:
        candidates.append(os.path.join(repo_hint, base_locator))
    candidates.append(os.path.join(os.getcwd(), base_locator))
    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            if open_file:
                opened = open_local_path(candidate)
            else:
                opened = {"opened": False}
            return {"locator": locator, "local_path": os.path.abspath(candidate), **opened}
    return {"locator": locator, "openable": False, "reason": "no local file found for relative locator"}


def metric_csv_from_locator(value):
    if not value:
        return None
    metric_csv = str(value).split("#", 1)[0]
    prefix = "gs://monarch-videos-new/"
    if metric_csv.startswith(prefix):
        metric_csv = metric_csv[len(prefix):]
    return metric_csv


def find_assay_overlay_renderer(repo=None):
    candidates = []
    for root in [repo, os.environ.get("ASK_MONARCH_REPO")]:
        if root:
            candidates.append(os.path.join(os.path.expanduser(root), "scripts", "render_assay_metric_overlay.py"))
    script_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    candidates.append(os.path.join(script_root, "scripts", "render_assay_metric_overlay.py"))
    candidates.append(os.path.expanduser("~/.local/share/ask-monarch/scripts/render_assay_metric_overlay.py"))
    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return os.path.abspath(candidate)
    raise RuntimeError(
        "assay overlay renderer is not installed; run from the ask-monarch repo, "
        "set ASK_MONARCH_REPO, or reinstall the Ask Monarch CLI"
    )


def assay_overlay_command(args):
    metric_csv = metric_csv_from_locator(args.metric_csv or args.locator)
    if not metric_csv:
        raise RuntimeError("--metric-csv or --locator is required")
    renderer = find_assay_overlay_renderer(args.repo)
    command = [sys.executable or "python3", renderer, "--metric-csv", metric_csv]
    for flag in ["output", "db", "input", "cache_dir", "out_dir", "tubes", "speed", "fps", "width", "height"]:
        value = getattr(args, flag, None)
        if value not in (None, ""):
            command.extend([f"--{flag.replace('_', '-')}", str(value)])
    for flag in ["refresh_video", "dry_run", "open"]:
        if getattr(args, flag, False):
            command.append(f"--{flag.replace('_', '-')}")
    return command


def run_assay_overlay(args):
    try:
        command = assay_overlay_command(args)
    except Exception as exc:
        emit_json({"ok": False, "mode": "assay_overlay", "error": str(exc)})
        return 1
    if args.print_command:
        emit_json({
            "ok": True,
            "mode": "assay_overlay",
            "command": " ".join(shlex.quote(part) for part in command),
        })
        return 0
    return subprocess.run(command, check=False).returncode


def sql_literal(value):
    return "'" + str(value).replace("'", "''") + "'"


def _has_any(q, terms):
    return any(term in q for term in terms)


def _people_sql(question):
    q = question.lower()
    person_query = people_query_for_question(question)
    if person_query:
        return f"""
            SELECT lane, name, role, text, provenance_grain
            FROM units
            WHERE lower(name) = lower({sql_literal(person_query)})
            ORDER BY lane, name
        """
    if _has_any(q, ["advisor", "advisors", "advises", "advise"]):
        lane = "advisors"
    elif _has_any(q, ["partner", "partnership", "usda", "jana lee"]):
        lane = "partnerships"
    elif _has_any(q, ["co-founder", "cofounder", "co-founders", "cofounders", "founder", "founders"]):
        return """
            SELECT lane, name, role, text, provenance_grain
            FROM units
            WHERE lower(coalesce(role, '')) LIKE '%founder%'
            ORDER BY name
        """
    elif _has_any(q, ["who works", "employees", "employee", "team", "people", "lab tech", "cto", "roster"]):
        lane = "employees"
    else:
        return None
    return f"""
        SELECT lane, name, role, text, provenance_grain
        FROM units
        WHERE lane = {sql_literal(lane)}
        ORDER BY name
    """


def _company_profile_sql(question):
    q = question.lower()
    if _has_any(q, ["headquarters", "where", "based", "hq", "emeryville"]):
        unit_ids = ("headquarters",)
    elif _has_any(q, ["mission", "what does monarch do", "what is monarch", "approach", "why monarch", "replace insecticide", "replacing insecticides"]):
        unit_ids = ("mission", "approach")
    elif _has_any(q, ["insect", "organism", "mosquito", "drosophila", "moth", "worm"]):
        unit_ids = ("insects",)
    elif _has_any(q, ["crop", "leaves", "berries"]):
        unit_ids = ("crop_testing",)
    elif _has_any(q, ["problem", "status quo", "neurotoxin", "insecticide"]):
        unit_ids = ("problem", "status_quo")
    else:
        return None
    placeholders = ", ".join(sql_literal(unit_id) for unit_id in unit_ids)
    return f"""
        SELECT unit_id, lane, title, text, provenance_grain
        FROM units
        WHERE unit_id IN ({placeholders})
        ORDER BY unit_id
    """


def _compound_inventory_sql(question):
    q = question.lower()
    if not _has_any(q, ["how many compounds", "what compounds", "which compounds", "list compounds", "compound list", "inventory list"]):
        return None
    return """
        WITH compounds AS (
          SELECT trim(value) AS compound_name
          FROM cells
          WHERE sheet_name = 'Master'
            AND cell LIKE 'D%'
            AND row_number >= 2
            AND trim(coalesce(value, '')) <> ''
        )
        SELECT
          (SELECT count(*) FROM compounds) AS compound_count,
          (SELECT group_concat(compound_name, ', ')
             FROM (SELECT compound_name FROM compounds ORDER BY compound_name LIMIT 50)
          ) AS first_50_compounds
    """


def _extract_inventory_phrase(question):
    text = re.sub(r"\s+", " ", str(question)).strip().strip("?")
    patterns = [
        r"do we have\s+(.+?)(?:,\s+and\s+what\s+bucket|\s+and\s+what\s+bucket|,\s+and\s+what\s+assay|\s+and\s+what\s+assay|\?)",
        r"compare material availability for\s+(.+?)\s+with assay-program evidence",
        r"material availability for\s+(.+?)\s+with assay-program evidence",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return match.group(1).strip(" ,?.")
    return None


def _extract_dart_treatment(question):
    text = re.sub(r"\s+", " ", str(question)).strip().strip("?")
    alias_map = {
        "2-propylphenol": "2PP",
        "2 propylphenol": "2PP",
        "2pp": "2PP",
        "deet": "DEET",
        "ir3535": "IR3535",
    }
    lowered = text.lower()
    for phrase, normalized in alias_map.items():
        if phrase in lowered:
            return normalized
    patterns = [
        r"dart data .*?\bfor\s+(.+?)(?:\s+in\s+(?:mosquitoes|flies|beetles|moths|drosophila))?$",
        r"for\s+(.+?),\s+what\s+dart\b",
        r"assay evidence exists for\s+(.+?)$",
        r"assay-program evidence for\s+(.+?)\s+and\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return match.group(1).strip(" ,?.")
    return None


def species_from_question(question):
    q = question.lower()
    if "mosquito" in q:
        return "mosquitoes"
    if "flies" in q or "fly" in q:
        return "flies"
    if "beetle" in q:
        return "beetles"
    if "moth" in q:
        return "moths"
    if "drosophila" in q:
        return "drosophila"
    return None


def _bucket_model_sql(question):
    q = question.lower()
    if not _has_any(q, ["model", "models", "ai", "computer vision", "yolo", "segmentation", "detection", "training"]):
        return None
    if not _has_any(q, ["bucket", "model file", "model files", "model metadata", "computer vision", "ai", "yolo"]):
        return None
    return """
        SELECT name, metadata_json, provenance_grain
        FROM model_metadata
        ORDER BY
          CASE
            WHEN lower(name) LIKE '%yolo%' THEN 0
            WHEN lower(name) LIKE '%model%' THEN 1
            ELSE 2
          END,
          name
    """


def _dart_sql(question):
    q = question.lower()
    if "dart" not in q and not _has_any(q, ["repellency", "repellent", "preference index", "avg pi", "assay metrics", "assay evidence", "metric csv"]):
        return None
    metric_match = re.search(r"assay metrics for\s+(.+?)\??$", q)
    if metric_match:
        needle = metric_match.group(1).strip(" ?.")
        return f"""
            SELECT name, row_number, row_json, provenance_grain
            FROM csv_rows_with_provenance
            WHERE lower(name) LIKE {sql_literal('%' + needle + '%advanced_metrics.csv')}
               OR lower(name) LIKE {sql_literal('%' + needle + '%frame_metrics.csv')}
            ORDER BY name, row_number
        """
    treatment = _extract_dart_treatment(question)
    if treatment:
        species = species_from_question(question)
        species_filter = f"AND lower(species) = {sql_literal(species)}" if species else ""
        return f"""
            SELECT
              species,
              assay_type,
              treatment_normalized,
              dilution,
              dilution_real,
              count(*) AS assay_rows,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows,
              avg(avg_pi_real) AS mean_avg_pi,
              min(assay_date) AS first_assay_date,
              max(assay_date) AS latest_assay_date,
              group_concat(DISTINCT source_name) AS source_names
            FROM dart_assay_results
            WHERE (
              lower(treatment_normalized) = lower({sql_literal(treatment)})
              OR lower(treatment) = lower({sql_literal(treatment)})
            )
            {species_filter}
            GROUP BY species, assay_type, treatment_normalized, dilution_real
            ORDER BY assay_rows DESC, scored_rows DESC, treatment_normalized
        """
    if _has_any(q, ["concentration", "dilution"]) and _has_any(q, ["best", "effective"]) and " for " in q:
        return None
    if _has_any(q, ["how many", "count", "number of"]):
        return """
            SELECT
              count(*) AS assay_rows,
              count(DISTINCT species) AS species_count,
              count(DISTINCT treatment_normalized) AS treatment_count,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows,
              min(assay_date) AS first_assay_date,
              max(assay_date) AS latest_assay_date
            FROM dart_assay_results
        """
    if _has_any(q, ["best", "top", "rank", "ranking", "most", "least", "highest", "lowest", "effective", "strongest", "weakest"]):
        return """
            SELECT
              species,
              assay_type,
              treatment_normalized,
              dilution,
              dilution_real,
              count(*) AS assay_rows,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows,
              avg(avg_pi_real) AS mean_avg_pi,
              min(avg_pi_real) AS best_single_avg_pi,
              max(avg_pi_real) AS least_effective_single_avg_pi,
              group_concat(DISTINCT source_name) AS source_names
            FROM dart_assay_results
            WHERE avg_pi_real IS NOT NULL
            GROUP BY species, assay_type, treatment_normalized, dilution_real
            ORDER BY mean_avg_pi ASC, scored_rows DESC, treatment_normalized
        """
    if _has_any(q, ["list", "show", "which"]):
        return """
            SELECT
              species,
              assay_type,
              treatment_normalized,
              dilution,
              dilution_real,
              count(*) AS assay_rows,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows
            FROM dart_assay_results
            GROUP BY species, assay_type, treatment_normalized, dilution_real
            ORDER BY species, assay_type, treatment_normalized, dilution_real
        """
    return None


def _phytotoxicity_sql(question):
    q = question.lower()
    if not _has_any(q, ["phytotoxicity", "phytotox", "soybean leaf", "leaf damage", "chlorosis", "browning", "necrosis", "damaged fraction"]):
        return None
    if _has_any(q, ["best", "top", "rank", "ranking", "most", "least", "highest", "lowest", "score", "metric", "damage", "chlorosis", "browning", "necrosis", "damaged fraction"]):
        return """
            SELECT
              name,
              row_number,
              json_extract(row_json, '$.date') AS assay_date,
              json_extract(row_json, '$.treatment_name') AS treatment_name,
              json_extract(row_json, '$.condition') AS condition,
              json_extract(row_json, '$.concentration') AS concentration,
              json_extract(row_json, '$.concentration_unit') AS concentration_unit,
              CAST(json_extract(row_json, '$.damaged_fraction') AS REAL) AS damaged_fraction,
              CAST(json_extract(row_json, '$.chlorosis_fraction') AS REAL) AS chlorosis_fraction,
              CAST(json_extract(row_json, '$.browning_fraction') AS REAL) AS browning_fraction,
              CAST(json_extract(row_json, '$.necrosis_fraction') AS REAL) AS necrosis_fraction,
              json_object(
                'grain_id', name || '#row=' || row_number,
                'grain_type', 'csv_row',
                'locator', 'gs://monarch-videos-new/' || name || '#row=' || row_number,
                'source_id', 'monarch_videos_new'
              ) AS provenance_grain
            FROM csv_rows
            WHERE name IN (
              'phytotoxicity/results/phytotoxicity_tests_03_30_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_3_24_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_02_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_06_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_13_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_14_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_16_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_20_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_21_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_22_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_23_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_27_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_28_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_29_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/features_all.csv'
            )
              AND json_extract(row_json, '$.damaged_fraction') IS NOT NULL
            ORDER BY damaged_fraction DESC, chlorosis_fraction DESC, browning_fraction DESC
        """
    if _has_any(q, ["how many", "count", "number of", "what data", "which data", "what sources", "which sources", "list", "show"]):
        return """
            SELECT name, sheet,
                   count(DISTINCT row_number) AS workbook_rows,
                   count(*) AS cells
            FROM xlsx_cells
            WHERE name LIKE 'phytotoxicity/%'
               OR lower(sheet) LIKE '%phytotoxicity%'
            GROUP BY name, sheet
            ORDER BY name, sheet
        """
    return """
        SELECT name, column_name, ordinal
        FROM csv_columns_with_provenance
        WHERE lower(name) LIKE 'phytotoxicity/%'
        ORDER BY name, ordinal
    """


def structured_sql_for_question(question, source):
    return routing_decision.structured_sql_for_question(question, source)


def all_source_question_for_source(question, source):
    if source == "compound_inventory":
        return _extract_inventory_phrase(question) or question
    return question


def planned_all_source_payloads(question, kind="all", limit=20, offset=0, include_health=False, deep_health=False):
    payloads = []
    for source in ALL_QUERY_SOURCES:
        source_question = all_source_question_for_source(question, source)
        payload = query_payload_for_question(
            source_question,
            source,
            kind=kind,
            limit=limit,
            offset=offset,
            include_health=False,
            deep_health=False,
        )
        if source == "compound_inventory" and source_question != question and "question" in payload:
            payload["q"] = payload.pop("question")
        payloads.append(payload)
    if include_health or deep_health:
        payloads[0]["include_health"] = include_health
        payloads[0]["deep_health"] = deep_health
    return payloads


def query_payload_for_question(question, source, kind="all", limit=20, offset=0, include_health=False, deep_health=False):
    return routing_decision.query_payload_for_question(
        question,
        source,
        kind=kind,
        limit=limit,
        offset=offset,
        include_health=include_health,
        deep_health=deep_health,
    )


def presentation_locator(row):
    provenance = row.get("provenance_grain")
    if provenance:
        try:
            parsed = json.loads(provenance)
            locator = parsed.get("locator")
            if locator:
                return locator
        except (TypeError, json.JSONDecodeError):
            pass
    locator = row.get("locator")
    if locator:
        return locator
    file_id = row.get("file_id")
    if file_id:
        return f"https://docs.google.com/presentation/d/{file_id}/edit"
    return None


def open_presentation(row):
    locator = presentation_locator(row)
    if not locator:
        raise RuntimeError("presentation row does not include an openable locator")
    webbrowser.open(locator)
    return locator


def presentation_lookup_sql(args):
    conditions = ["deck_date >= '2026-01-02'"]
    if args.date:
        conditions.append(f"deck_date = {sql_literal(args.date)}")
    if args.title:
        conditions.append(f"lower(title) LIKE lower({sql_literal('%' + args.title + '%')})")
    where = " AND ".join(conditions)
    return f"""
        SELECT title, deck_date, created_time, modified_time, file_id,
               slide_count, text_unit_count, media_ref_count, provenance_grain
        FROM decks
        WHERE {where}
        ORDER BY deck_date DESC, modified_time DESC
    """


def setup_agent(args):
    result = setup_agents(agents=tuple(args.agent))
    emit_json(result)
    return 0 if result.get("ok") else 1


def shlex_quote(value):
    return "'" + str(value).replace("'", "'\"'\"'") + "'"


def prepend_path(directory):
    path_entries = [
        entry
        for entry in os.environ.get("PATH", "").split(os.pathsep)
        if entry and entry != directory
    ]
    os.environ["PATH"] = os.pathsep.join([directory, *path_entries])


def ensure_persistent_cli():
    expected_bin = os.environ.get("ASK_MONARCH_BIN") or os.path.expanduser("~/.local/bin/ask-monarch")
    expected_bin_dir = os.path.dirname(expected_bin)
    os.makedirs(expected_bin_dir, exist_ok=True)
    uv_bin = shutil.which("uv")
    tool_source = os.environ.get("ASK_MONARCH_TOOL_SOURCE", "ask-monarch")
    if uv_bin:
        command = [uv_bin, "tool", "install", "-U"]
        if tool_source == "ask-monarch":
            command.append("ask-monarch")
        else:
            command.extend(["--from", tool_source, "ask-monarch"])
        result = subprocess.run(command, text=True, capture_output=True, check=False)
        if result.returncode == 0:
            prepend_path(expected_bin_dir)
            return expected_bin
    with open(expected_bin, "w", encoding="utf-8") as handle:
        handle.write("#!/usr/bin/env sh\n")
        handle.write(f"exec {shlex_quote(sys.executable)} -m ask_monarch_cli.cli \"$@\"\n")
    os.chmod(expected_bin, 0o755)
    prepend_path(expected_bin_dir)
    return expected_bin


def source_id_from_query(result):
    if not isinstance(result, dict):
        return ""
    for key in ("source_id", "source"):
        if result.get(key):
            return str(result[key])
    rows = result.get("rows")
    if isinstance(rows, list) and rows:
        first = rows[0]
        if isinstance(first, dict):
            return str(first.get("source_id") or first.get("source") or "")
    return ""


def verification_query(args):
    return request_json(
        f"{resolve_url(args, load_config())}/query",
        token=resolve_token(args, load_config()),
        method="POST",
        payload={
            "q": VERIFY_QUESTION,
            "source": "auto",
            "kind": "all",
            "limit": 3,
            "offset": 0,
            "include_health": False,
            "deep_health": False,
            "trace": False,
        },
    )


def login(args):
    if args.reset and os.path.exists(CONFIG_PATH):
        os.remove(CONFIG_PATH)
    exchange_args = argparse.Namespace(
        code=args.setup_code,
        no_configure=False,
        url=args.url,
        token=None,
        open_trace=False,
        include_trace=False,
    )
    exchange_code = onboarding_code_exchange(exchange_args)
    agent_result = setup_agents(agents=tuple(args.agent))
    doctor_code = doctor(args) if args.doctor else 0
    query_result = verification_query(args) if args.verify else {"ok": True}
    source_id = source_id_from_query(query_result) if args.verify else ""
    ok = (
        exchange_code == 0
        and bool(agent_result.get("ok"))
        and doctor_code == 0
        and bool(query_result.get("ok"))
        and (not args.verify or bool(source_id))
    )
    emit_json(
        {
            "ok": bool(ok),
            "status": "ready" if ok else "needs_attention",
            "company": "Monarch",
            "login": "configured" if exchange_code == 0 else "failed",
            "agents": agent_result,
            "doctor_passed": doctor_code == 0 if args.doctor else None,
            "verify_question": VERIFY_QUESTION if args.verify else None,
            "query_passed": bool(query_result.get("ok")) if args.verify else None,
            "source_id": source_id,
        }
    )
    return 0 if ok else 1


def setup(args):
    if args.reset and os.path.exists(CONFIG_PATH):
        os.remove(CONFIG_PATH)
    persistent_bin = ensure_persistent_cli()
    exchange_args = argparse.Namespace(
        code=args.code,
        no_configure=False,
        url=args.url,
        token=None,
        open_trace=False,
        include_trace=False,
    )
    exchange_code = onboarding_code_exchange(exchange_args)
    agent_result = setup_agents(agents=tuple(args.agent))
    doctor_code = doctor(args)
    query_result = verification_query(args)
    source_id = source_id_from_query(query_result)
    ok = (
        exchange_code == 0
        and bool(agent_result.get("ok"))
        and doctor_code == 0
        and bool(query_result.get("ok"))
        and bool(source_id)
    )
    emit_json(
        {
            "ok": bool(ok),
            "status": "ready" if ok else "needs_attention",
            "company": "Monarch",
            "persistent_binary": persistent_bin,
            "setup_code": "accepted" if exchange_code == 0 else "failed",
            "agents": agent_result,
            "doctor_passed": doctor_code == 0,
            "verify_question": VERIFY_QUESTION,
            "query_passed": bool(query_result.get("ok")),
            "source_id": source_id,
        }
    )
    return 0 if ok else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description="Remote CLI for the hosted Ask Monarch source service.")
    parser.add_argument("--url", help=f"Ask Monarch endpoint. Default: {DEFAULT_URL}")
    parser.add_argument("--token", help="Bearer token. Prefer ASK_MONARCH_TOKEN or ask-monarch configure.")
    parser.add_argument("--open-trace", action="store_true", help="Open the Braintrust trace URL returned by a traced query.")
    parser.add_argument("--include-trace", action="store_true", help="Include Braintrust trace metadata in JSON output.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    setup_parser = subparsers.add_parser("setup", help="One-command Ask Monarch teammate setup.")
    setup_parser.add_argument("--code", required=True, help="Stable Ask Monarch setup code.")
    setup_parser.add_argument("--reset", action="store_true", help="Refresh CLI-owned local config before setup.")
    setup_parser.add_argument("--agent", action="append", choices=("codex", "claude"), default=["codex", "claude"])

    login_parser = subparsers.add_parser("login", help="Exchange a stable Ask Monarch setup code and refresh agent guidance.")
    login_parser.add_argument("--setup-code", required=True, help="Stable Ask Monarch setup code.")
    login_parser.add_argument("--reset", action="store_true", help="Refresh CLI-owned local config before login.")
    login_parser.add_argument("--agent", action="append", choices=("codex", "claude"), default=["codex", "claude"])
    login_parser.add_argument("--doctor", action="store_true", help="Run doctor after login.")
    login_parser.add_argument("--verify", action="store_true", help="Run the canonical verification query after login.")

    configure_parser = subparsers.add_parser("configure", help="Save endpoint and token to local user config.")
    configure_parser.add_argument("--url", default=None)
    configure_parser.add_argument("--token", default=None)
    configure_parser.add_argument("--prompt-token", action="store_true")

    health_parser = subparsers.add_parser("health", help="Check server and source-index readiness.")
    health_parser.add_argument("--deep", action="store_true", help="Recount SQLite tables instead of using cached source receipts.")
    subparsers.add_parser("doctor", help="Check local Ask Monarch install parity without printing secrets.")
    subparsers.add_parser("parity", help="Verify teammate experience parity: global rules, skills, CLI fallback, and hosted source lanes.")
    setup_agent_parser = subparsers.add_parser("setup-agent", help="Install or refresh Ask Monarch agent harness guidance.")
    setup_agent_parser.add_argument("--agent", action="append", choices=("codex", "claude"), default=["codex", "claude"])
    subparsers.add_parser("summary", help="Return source-plane summary counts.")

    onboarding_code = subparsers.add_parser("onboarding-code", help="Create, rotate, or exchange Ask Monarch setup codes.")
    onboarding_subparsers = onboarding_code.add_subparsers(dest="onboarding_code_command", required=True)
    onboarding_create = onboarding_subparsers.add_parser("create", help="Create or rotate a stable setup code for a teammate group.")
    onboarding_create.add_argument("--email", default="")
    onboarding_create.add_argument("--label", default="")
    onboarding_create.add_argument("--ttl-hours", type=float, default=None)
    onboarding_create.add_argument("--single-use", action="store_true", help="Create an expiring one-time code instead of the stable default.")
    onboarding_exchange = onboarding_subparsers.add_parser("exchange", help="Exchange a setup code for local Ask Monarch configuration.")
    onboarding_exchange.add_argument("code")
    onboarding_exchange.add_argument("--no-configure", action="store_true", help="Do not save the returned token to local config.")

    trace_url_parser = subparsers.add_parser("trace-url", help="Render the Braintrust full trace URL for an Ask Monarch trace id.")
    trace_url_parser.add_argument("trace_id")
    trace_url_parser.add_argument("--org", default=DEFAULT_BRAINTRUST_ORG)
    trace_url_parser.add_argument("--project", default=DEFAULT_BRAINTRUST_PROJECT)
    trace_url_parser.add_argument("--project-id", default=DEFAULT_BRAINTRUST_PROJECT_ID)

    token_hash_parser = subparsers.add_parser("token-hash", help="Print the SHA-256 hash for the configured or provided Ask Monarch bearer token.")
    token_hash_parser.add_argument("--token", default=None, help="Token to hash. Defaults to --token, ASK_MONARCH_TOKEN, or saved config.")

    query_parser = subparsers.add_parser("query", help="Ask a text query against the source index.")
    query_parser.add_argument("question")
    query_parser.add_argument("--source", choices=SOURCE_CHOICES, default="auto")
    query_parser.add_argument("--kind", default="all")
    query_parser.add_argument("--limit", type=int, default=20)
    query_parser.add_argument("--offset", type=int, default=0)
    query_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    query_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    search_parser = subparsers.add_parser("search", help="Keyword search over indexed source units.")
    search_parser.add_argument("query")
    search_parser.add_argument("--source", choices=SOURCE_CHOICES, default="bucket")
    search_parser.add_argument("--kind", default="all")
    search_parser.add_argument("--limit", type=int, default=20)
    search_parser.add_argument("--offset", type=int, default=0)
    search_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    search_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    presentations_parser = subparsers.add_parser("presentations-search", help="Search the parsed 2026 Monarch update decks.")
    presentations_parser.add_argument("query")
    presentations_parser.add_argument("--limit", type=int, default=20)
    presentations_parser.add_argument("--offset", type=int, default=0)
    presentations_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    presentations_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    presentation_parser = subparsers.add_parser("presentation", help="Find and optionally open a Monarch R&D presentation deck.")
    presentation_parser.add_argument("--date", help="Deck date in YYYY-MM-DD form. Indexed R&D decks start on 2026-01-02.")
    presentation_parser.add_argument("--title", help="Title substring, such as monarch_update_1_2_26.")
    presentation_parser.add_argument("--query", help="Search slide text and open the first matching deck or slide locator.")
    presentation_parser.add_argument("--latest", action="store_true", help="Return the latest indexed R&D presentation. This is the default when no selector is given.")
    presentation_parser.add_argument("--limit", type=int, default=5)
    presentation_parser.add_argument("--open", action="store_true", help="Open the first returned Google Slides locator.")
    presentation_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    presentation_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    teams_parser = subparsers.add_parser("teams-recaps-search", help="Search parsed Monarch Teams recap transcripts.")
    teams_parser.add_argument("query")
    teams_parser.add_argument("--limit", type=int, default=20)
    teams_parser.add_argument("--offset", type=int, default=0)
    teams_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    teams_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    company_parser = subparsers.add_parser("company-profile-search", help="Search Monarch mission, HQ, approach, organisms, and crop-testing profile.")
    company_parser.add_argument("query")
    company_parser.add_argument("--limit", type=int, default=20)
    company_parser.add_argument("--offset", type=int, default=0)
    company_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    company_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    people_parser = subparsers.add_parser("people-search", help="Search Monarch employees, advisors, and partnerships.")
    people_parser.add_argument("query")
    people_parser.add_argument("--kind", default="all", help="Optional lane filter such as employees, advisors, or partnerships.")
    people_parser.add_argument("--limit", type=int, default=20)
    people_parser.add_argument("--offset", type=int, default=0)
    people_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    people_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    context_parser = subparsers.add_parser("company-context-search", help="Search parsed Monarch company context from PDF intake evidence.")
    context_parser.add_argument("query")
    context_parser.add_argument("--kind", default="all", help="Optional unit filter such as pdf_page or pdf_text_block.")
    context_parser.add_argument("--limit", type=int, default=20)
    context_parser.add_argument("--offset", type=int, default=0)
    context_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    context_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    cross_docs_parser = subparsers.add_parser("cross-experiment-docs-search", help="Search cross-experiment aggregation reference docs.")
    cross_docs_parser.add_argument("query")
    cross_docs_parser.add_argument("--kind", default="all", help="Optional unit filter such as pdf_page or pdf_text_block.")
    cross_docs_parser.add_argument("--limit", type=int, default=20)
    cross_docs_parser.add_argument("--offset", type=int, default=0)
    cross_docs_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    cross_docs_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    scientific_refs_parser = subparsers.add_parser("scientific-refs-search", help="Search the parsed Monarch scientific reference library.")
    scientific_refs_parser.add_argument("query")
    scientific_refs_parser.add_argument("--kind", default="all", help="Optional unit filter such as pdf_page, pdf_text_block, workbook_sheet, or workbook_cell.")
    scientific_refs_parser.add_argument("--limit", type=int, default=20)
    scientific_refs_parser.add_argument("--offset", type=int, default=0)
    scientific_refs_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    scientific_refs_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    milestones_parser = subparsers.add_parser("milestones-search", help="Search the parsed Monarch milestones Google Doc source.")
    milestones_parser.add_argument("query")
    milestones_parser.add_argument("--limit", type=int, default=20)
    milestones_parser.add_argument("--offset", type=int, default=0)
    milestones_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    milestones_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    compound_parser = subparsers.add_parser("compound-inventory-search", help="Search the parsed Monarch compound / chemical inventory workbook.")
    compound_parser.add_argument("query")
    compound_parser.add_argument("--limit", type=int, default=20)
    compound_parser.add_argument("--offset", type=int, default=0)
    compound_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    compound_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    csv_parser = subparsers.add_parser("csv-search", help="Scan CSV row JSON and return provenance rows.")
    csv_parser.add_argument("query")
    csv_parser.add_argument("--name-like", default=None)
    csv_parser.add_argument("--limit", type=int, default=20)
    csv_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    csv_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    sql_parser = subparsers.add_parser("sql", help="Run one read-only SQL statement.")
    sql_parser.add_argument("sql")
    sql_parser.add_argument("--source", choices=SQL_SOURCE_CHOICES, default="bucket")
    sql_parser.add_argument("--limit", type=int, default=20)
    sql_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    sql_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    get_parser = subparsers.add_parser("get", help="Fetch one exact source unit.")
    get_parser.add_argument("unit_type")
    get_parser.add_argument("name")
    get_parser.add_argument("sub_id")
    get_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    get_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    resolve_parser = subparsers.add_parser("resolve-source", help="Resolve and optionally open a source locator from provenance.")
    resolve_group = resolve_parser.add_mutually_exclusive_group(required=True)
    resolve_group.add_argument("--locator", help="A provenance locator, such as gs://..., https://..., or a repo-relative path.")
    resolve_group.add_argument("--provenance-json", help="A provenance_grain JSON object containing locator or media_locator.")
    resolve_parser.add_argument("--open", action="store_true", help="Open the resolved source artifact or URL.")
    resolve_parser.add_argument(
        "--download-dir",
        default=os.path.expanduser("~/.cache/ask-monarch/source-artifacts"),
        help="Local cache directory for gs:// source artifacts.",
    )

    assay_media_parser = subparsers.add_parser("assay-media", help="Find and optionally open media linked to an exact assay record.")
    assay_media_parser.add_argument("--row", type=int, help="Assay row number, for example a dart_assay_results row.")
    assay_media_parser.add_argument("--source-name", help="Assay source file, such as mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx.")
    assay_media_parser.add_argument("--sheet", help="Assay sheet name, such as Assays.")
    assay_media_parser.add_argument("--assay", dest="assay_family", help="Assay family, such as DART, mini-DART, choice, no-choice, or cage.")
    assay_media_parser.add_argument("--species", help="Species filter.")
    assay_media_parser.add_argument("--date", dest="assay_date", help="Assay date as stored in the source row, for example 4282026.")
    assay_media_parser.add_argument("--treatment", help="Treatment or normalized treatment filter.")
    assay_media_parser.add_argument("--filename", help="Exact assay filename from the source row.")
    assay_media_parser.add_argument("--media-name", help="Exact indexed media object path or gs:// URI.")
    assay_media_parser.add_argument("--limit", type=int, default=20)
    assay_media_parser.add_argument("--open", action="store_true", help="Download/cache the first linked media object and open it locally.")
    assay_media_parser.add_argument(
        "--download-dir",
        default=os.path.expanduser("~/.cache/ask-monarch/media"),
        help="Local cache directory for --open downloads.",
    )
    assay_media_parser.add_argument("--with-health", action="store_true", help="Include cached health in the same response.")
    assay_media_parser.add_argument("--deep-health", action="store_true", help="Use deep health when --with-health is set.")

    assay_overlay_parser = subparsers.add_parser("assay-overlay", help="Render/open a raw assay video with processed avoidance metrics overlaid.")
    overlay_locator_group = assay_overlay_parser.add_mutually_exclusive_group(required=True)
    overlay_locator_group.add_argument("--metric-csv", help="Indexed metric CSV object name, such as advanced_metrics.csv or frame_metrics.csv.")
    overlay_locator_group.add_argument("--locator", help="A provenance locator such as gs://.../advanced_metrics.csv#row=6 or gs://.../frame_metrics.csv#row=10.")
    assay_overlay_parser.add_argument("--repo", help="Path to an ask-monarch repo checkout. Defaults to ASK_MONARCH_REPO when set.")
    assay_overlay_parser.add_argument("--db", help="Source SQLite path for local repo rendering.")
    assay_overlay_parser.add_argument("--input", help="Local raw assay video override.")
    assay_overlay_parser.add_argument("--cache-dir", help="Local raw-video cache directory.")
    assay_overlay_parser.add_argument("--output", help="Rendered overlay video path.")
    assay_overlay_parser.add_argument("--out-dir", help="Rendered overlay output directory.")
    assay_overlay_parser.add_argument("--tubes", help="Comma-separated tube labels to plot, for example T5,T6,T7,T8.")
    assay_overlay_parser.add_argument("--speed", type=float, help="Video speedup factor.")
    assay_overlay_parser.add_argument("--fps", type=int, help="Output frames per second.")
    assay_overlay_parser.add_argument("--width", type=int, help="Output width.")
    assay_overlay_parser.add_argument("--height", type=int, help="Output height.")
    assay_overlay_parser.add_argument("--refresh-video", action="store_true", help="Redownload the raw video before rendering.")
    assay_overlay_parser.add_argument("--dry-run", action="store_true", help="Resolve sources and print proof JSON without rendering.")
    assay_overlay_parser.add_argument("--open", action="store_true", help="Open the rendered overlay video.")
    assay_overlay_parser.add_argument("--print-command", action="store_true", help="Print the renderer command without running it.")

    subparsers.add_parser("personal-mail-status", help="Show the personal Monarch mailbox mapped to the current Ask Monarch token.")
    personal_search_parser = subparsers.add_parser("personal-mail-search", help="Search the personal Microsoft Graph mailbox mapped to the current Ask Monarch token.")
    personal_search_parser.add_argument("query")
    personal_search_parser.add_argument("--days", type=int, default=30)
    personal_search_parser.add_argument("--limit", type=int, default=10)
    personal_search_parser.add_argument("--max-scan", type=int, default=250)
    personal_read_parser = subparsers.add_parser("personal-mail-read", help="Read a full personal mailbox message by Microsoft Graph message id.")
    personal_read_parser.add_argument("message_id")
    personal_draft_parser = subparsers.add_parser("personal-mail-draft", help="Create a draft in the mapped personal Monarch mailbox.")
    personal_draft_parser.add_argument("--to", required=True)
    personal_draft_parser.add_argument("--subject", required=True)
    personal_draft_parser.add_argument("--body", required=True)
    personal_draft_parser.add_argument("--cc", default=None)
    personal_draft_parser.add_argument("--bcc", default=None)
    personal_draft_parser.add_argument("--content-type", default="Text")
    personal_reply_parser = subparsers.add_parser("personal-mail-reply-draft", help="Create a reply draft in the mapped personal Monarch mailbox.")
    personal_reply_parser.add_argument("message_id")
    personal_reply_parser.add_argument("--body", required=True)
    personal_reply_parser.add_argument("--reply-all", action="store_true")
    personal_reply_parser.add_argument("--content-type", default="Text")
    personal_send_parser = subparsers.add_parser("personal-mail-send-draft", help="Send an existing draft from the mapped personal Monarch mailbox.")
    personal_send_parser.add_argument("message_id")

    args = parser.parse_args(argv)
    if args.command == "setup":
        return setup(args)
    if args.command == "login":
        return login(args)
    if args.command == "configure":
        configure(args)
        return 0
    if args.command == "setup-agent":
        return setup_agent(args)
    if args.command == "doctor":
        return doctor(args)
    if args.command == "parity":
        return parity(args)
    if args.command == "onboarding-code":
        if args.onboarding_code_command == "create":
            return onboarding_code_create(args)
        if args.onboarding_code_command == "exchange":
            return onboarding_code_exchange(args)
        return 1
    if args.command == "token-hash":
        config = load_config()
        token = args.token or resolve_token(args, config)
        if not token:
            emit_json({"ok": False, "error": "no Ask Monarch token found in --token, ASK_MONARCH_TOKEN, or config"})
            return 1
        emit_json({"ok": True, "token_sha256": hashlib.sha256(token.encode("utf-8")).hexdigest()})
        return 0
    if args.command == "health":
        return call(args, "/health?deep=1" if args.deep else "/health")
    if args.command == "summary":
        return call(args, "/summary")
    if args.command == "trace-url":
        emit_json({
            "ok": True,
            "trace_id": args.trace_id,
            "trace_project": args.project,
            "trace_project_id": args.project_id,
            "trace_url": braintrust_trace_url(args.trace_id, project=args.project, project_id=args.project_id, org=args.org),
        })
        return 0
    if args.command == "query":
        route = routing_decision.route_decision_for_question(args.question, args.source)
        if args.source == "auto" and route.get("intent") == "phytotox_inventory_ranking":
            result = query_phytotox_inventory_ranking(args)
            emit_json(result)
            return 0 if result.get("ok", False) else 1
        if args.source == "auto" and route.get("intent") == "inventory_sample_with_assay":
            result = query_inventory_sample_with_assay(args)
            emit_json(result)
            return 0 if result.get("ok", False) else 1
        if args.source == "auto" and route.get("adapter_execution") == "route_plan":
            result = query_answer_shape_route_plan(args, route)
            emit_json(result)
            return 0 if result.get("ok", False) else 1
        priority_sources = priority_source_plan_for_question(args.question) if args.source == "auto" else []
        if priority_sources:
            result = query_priority_sources(args, priority_sources)
            emit_json(result)
            return 0 if result.get("ok", False) else 1
        source = route.get("source_lane") if args.source == "auto" else args.source
        if source == "all":
            result = query_all_sources(args)
            emit_json(result)
            return 0 if result.get("ok", False) else 1
        query_payload = query_payload_for_question(
            args.question,
            source,
            kind=args.kind,
            limit=args.limit,
            offset=args.offset,
            include_health=args.with_health,
            deep_health=args.deep_health,
        )
        result = call_json(
            args,
            "/query",
            method="POST",
            payload=query_payload,
        )
        result.setdefault("source", source)
        emit_json(result)
        return 0 if result.get("ok", False) else 1
    if args.command == "search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": args.source,
                "kind": args.kind,
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "presentations-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "presentations",
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "presentation":
        if args.query:
            payload = {
                "q": args.query,
                "source": "presentations",
                "limit": args.limit,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            }
        else:
            payload = {
                "sql": presentation_lookup_sql(args),
                "source": "presentations",
                "limit": args.limit,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            }
        result = call_json(args, "/query", method="POST", payload=payload)
        rows = result.get("rows") or []
        if args.open and result.get("ok") and rows:
            try:
                result["opened"] = {"locator": open_presentation(rows[0])}
            except Exception as exc:
                result["open_error"] = str(exc)
                emit_json(result)
                return 1
        emit_json(result)
        return 0 if result.get("ok", False) else 1
    if args.command == "teams-recaps-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "teams_recaps",
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "company-profile-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "company_profile",
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "people-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "people_directory",
                "kind": args.kind,
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "company-context-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "company_context",
                "kind": args.kind,
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "cross-experiment-docs-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "cross_experiment_docs",
                "kind": args.kind,
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "scientific-refs-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "scientific_refs",
                "kind": args.kind,
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "milestones-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "milestones_doc",
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "compound-inventory-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "q": args.query,
                "source": "compound_inventory",
                "limit": args.limit,
                "offset": args.offset,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "csv-search":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "csv_q": args.query,
                "name_like": args.name_like,
                "limit": args.limit,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "sql":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "sql": args.sql,
                "source": args.source,
                "limit": args.limit,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "get":
        return call(
            args,
            "/query",
            method="POST",
            payload={
                "get": {
                    "unit_type": args.unit_type,
                    "name": args.name,
                    "sub_id": args.sub_id,
                },
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
    if args.command == "resolve-source":
        locator = args.locator or provenance_locator(args.provenance_json)
        try:
            result = {"ok": True, "mode": "resolve_source", **resolve_source_locator(locator, args.download_dir, open_file=args.open)}
        except Exception as exc:
            result = {"ok": False, "mode": "resolve_source", "locator": locator, "error": str(exc)}
        emit_json(result)
        return 0 if result.get("ok", False) else 1
    if args.command == "assay-media":
        target = {
            "row_number": args.row,
            "source_name": args.source_name,
            "sheet": args.sheet,
            "assay_family": args.assay_family,
            "species": args.species,
            "assay_date": args.assay_date,
            "treatment": args.treatment,
            "filename": args.filename,
            "media_name": args.media_name,
        }
        target = {key: value for key, value in target.items() if value not in (None, "")}
        result = call_json(
            args,
            "/query",
            method="POST",
            payload={
                "assay_media": target,
                "source": "bucket",
                "limit": args.limit,
                "include_health": args.with_health,
                "deep_health": args.deep_health,
            },
        )
        if args.open and result.get("ok") and result.get("rows"):
            try:
                opened = download_and_open_media(result["rows"][0], args.download_dir, open_file=True)
                result["opened"] = {
                    "media_uri": result["rows"][0].get("media_uri"),
                    **opened,
                }
            except Exception as exc:
                result["open_error"] = str(exc)
                emit_json(result)
                return 1
        emit_json(result)
        return 0 if result.get("ok", False) else 1
    if args.command == "assay-overlay":
        return run_assay_overlay(args)
    if args.command == "personal-mail-status":
        return call(args, "/personal-mail/status")
    if args.command == "personal-mail-search":
        return call(
            args,
            "/personal-mail/search",
            method="POST",
            payload={"q": args.query, "days": args.days, "limit": args.limit, "max_scan": args.max_scan},
        )
    if args.command == "personal-mail-read":
        return call(args, "/personal-mail/read", method="POST", payload={"message_id": args.message_id})
    if args.command == "personal-mail-draft":
        return call(
            args,
            "/personal-mail/draft",
            method="POST",
            payload={
                "to": args.to,
                "subject": args.subject,
                "body": args.body,
                "cc": args.cc,
                "bcc": args.bcc,
                "content_type": args.content_type,
            },
        )
    if args.command == "personal-mail-reply-draft":
        return call(
            args,
            "/personal-mail/reply-draft",
            method="POST",
            payload={
                "message_id": args.message_id,
                "body": args.body,
                "reply_all": args.reply_all,
                "content_type": args.content_type,
            },
        )
    if args.command == "personal-mail-send-draft":
        return call(args, "/personal-mail/send-draft", method="POST", payload={"message_id": args.message_id})
    return 1


if __name__ == "__main__":
    sys.exit(main())
