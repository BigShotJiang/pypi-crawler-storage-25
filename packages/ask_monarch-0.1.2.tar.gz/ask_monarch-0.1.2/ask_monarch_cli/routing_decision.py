#!/usr/bin/env python3
import json
import os
import re
from datetime import datetime, timedelta

try:
    import evidence_shapes
except ImportError:  # pragma: no cover - installed script fallback.
    evidence_shapes = None

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover - fallback for older Python runtimes.
    ZoneInfo = None


PACKAGE_ROOT = os.path.abspath(os.path.dirname(__file__))
ROOT = os.path.abspath(os.path.join(PACKAGE_ROOT, ".."))
DEFAULT_QUERY_TIMEZONE = "America/Los_Angeles"


def _default_config_path(filename):
    configured_dir = os.environ.get("ASK_MONARCH_CONFIG_DIR")
    candidates = []
    if configured_dir:
        candidates.append(os.path.join(configured_dir, filename))
    candidates.extend(
        [
            os.path.join(PACKAGE_ROOT, "config", filename),
            os.path.join(os.path.expanduser("~"), ".local", "share", "ask-monarch", "config", filename),
            os.path.join(ROOT, "config", filename),
            os.path.abspath(os.path.join(ROOT, "..", "config", filename)),
        ]
    )
    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate
    return candidates[0]


DEFAULT_ROUTING_CONFIG = _default_config_path("query-routing.json")
DEFAULT_SOURCE_CAPABILITIES_CONFIG = _default_config_path("source-capabilities.json")
DEFAULT_ADAPTER_MODIFIERS_CONFIG = _default_config_path("adapter-modifiers.json")


def load_routing_config(path=DEFAULT_ROUTING_CONFIG):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def load_source_capabilities(path=DEFAULT_SOURCE_CAPABILITIES_CONFIG):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def load_adapter_modifier_registry(path=DEFAULT_ADAPTER_MODIFIERS_CONFIG):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _sources():
    return load_routing_config().get("sources", {})


def _source_capabilities():
    return load_source_capabilities().get("sources", {})


def _adapter_modifier_contracts():
    try:
        return load_adapter_modifier_registry().get("adapters", {})
    except OSError:
        return {}


def _has_any(q, terms):
    return any(term in q for term in terms)


def _has_word(q, term):
    return re.search(rf"\b{re.escape(term)}\b", q) is not None


def _has_assay_metric_reference_term(q):
    if _has_any(q, ASSAY_METRIC_REFERENCE_TERMS):
        return True
    return any(_has_word(q, term) for term in SHORT_ASSAY_METRIC_REFERENCE_TERMS)


def _is_assay_metric_reference_question(question):
    q = str(question).lower()
    if not _has_assay_metric_reference_term(q):
        return False
    if _has_any(q, ["script", "scripts", "code", "pipeline", "calculated", "computed", "method"]):
        return False
    return _has_any(q, ASSAY_METRIC_DEFINITION_TERMS)


def _is_contact_metric_reference_question(question):
    q = str(question).lower()
    if not _is_assay_metric_reference_question(question):
        return False
    return _has_any(
        q,
        [
            "contact",
            "non-contact",
            "noncontact",
            "no-contact",
            "no contact",
            "adj_contact",
            "contact_pi",
            "mean_contact_pi",
            "inside",
            "outside",
            "frac_time_avoiding",
            "confidence",
        ],
    )


def _dedupe_preserve_order(values):
    result = []
    for value in values:
        if value not in result:
            result.append(value)
    return result


def _normalized_text(value):
    return re.sub(r"\s+", " ", str(value).lower()).strip()


SEMANTIC_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "by",
    "do",
    "does",
    "for",
    "have",
    "how",
    "in",
    "is",
    "me",
    "of",
    "show",
    "the",
    "to",
    "we",
    "what",
    "which",
}


ANCHOR_STOPWORDS = SEMANTIC_STOPWORDS | {
    "about",
    "be",
    "could",
    "effect",
    "from",
    "might",
    "monarch",
    "really",
    "seem",
    "seems",
    "should",
    "that",
    "this",
    "why",
    "working",
}

BUCKET_ANCHOR_TERMS = {
    "assay",
    "assays",
    "avoidance",
    "compound",
    "compounds",
    "contact",
    "dart",
    "deet",
    "docking",
    "experiment",
    "experiments",
    "flies",
    "fly",
    "model",
    "models",
    "mosquito",
    "mosquitoes",
    "oil",
    "peppermint",
    "phytotoxicity",
    "pi",
    "preference",
    "repellent",
    "repellency",
    "swd",
    "treatment",
    "treatments",
    "video",
}

RETRIEVAL_PRIORITY = [
    "deterministic_retrieval_plan",
    "structured_table_sql",
    "fts_sql_if_needed",
    "artifact_document_extraction_if_needed",
    "model_synthesis_over_retrieved_evidence",
]

STRUCTURED_TABLE_SOURCE_PRIORITY = [
    "compound_inventory",
    "bucket",
    "teams_recaps",
    "people_directory",
    "company_profile",
]

FTS_SQL_SOURCE_PRIORITY = [
    "milestones_doc",
    "scientific_refs",
    "teams_recaps",
    "presentations",
    "company_context",
    "cross_experiment_docs",
]

COMPOUND_INVENTORY_STRUCTURED_TERMS = [
    "chemical inventory",
    "compound inventory",
    "chemical library",
    "inventory",
    "vendor",
    "sds",
    "stock",
    "do we have",
    "where do we store",
]

PEOPLE_DIRECTORY_STRUCTURED_TERMS = [
    "advisor",
    "advisors",
    "co-founder",
    "cofounder",
    "employee",
    "employees",
    "founder",
    "founders",
    "lab tech",
    "partner",
    "partnership",
    "people",
    "role",
    "who works",
]

COMPANY_PROFILE_STRUCTURED_TERMS = [
    "approach",
    "crop species",
    "emeryville",
    "headquarters",
    "hq",
    "insects does monarch",
    "insects monarch work",
    "mission",
    "organisms",
    "what does monarch do",
    "what insects",
    "what is monarch",
    "where is monarch",
    "which insects",
]

BUCKET_STRUCTURED_TABLE_TERMS = [
    "assay",
    "assays",
    "adjusted summary",
    "adjusted_contact_pi_summary",
    "avg pi",
    "contact",
    "dart",
    "docking",
    "experiment",
    "experimental data",
    "experiments",
    "image",
    "images",
    "photo",
    "photos",
    "picture",
    "pictures",
    "flies",
    "fly",
    "humidity",
    "model",
    "models",
    "mosquito",
    "mosquitoes",
    "mosquito tube",
    "moth",
    "moths",
    "noncontact",
    "no contact",
    "oviposition",
    "phytotoxicity",
    "preference index",
    "repellent",
    "repellency",
    "swd",
    "tested",
    "temperature",
    "treatment",
    "treatments",
    "video",
]

MILESTONE_TEXT_TERMS = [
    "milestone",
    "milestones",
    "mode of action",
    "mode-of-action",
]

SCIENTIFIC_REFS_TEXT_TERMS = [
    "chemical ecology",
    "literature",
    "odorant receptor",
    "olfaction receptor",
    "olfactory receptor",
    "paper",
    "papers",
    "research paper",
    "research papers",
    "scientific reference",
    "scientific refs",
    "scientific literature",
]

PRESENTATION_TEXT_TERMS = [
    "company update",
    "deck",
    "presentation",
    "slide",
    "storyboard",
]

CROSS_EXPERIMENT_TEXT_TERMS = [
    "aggregate_experiments",
    "cross-experiment aggregation",
    "csv data dictionary",
    "csv_data_dictionary",
    "figure guide",
    "figure_guide",
]

EXPECTED_GRAIN_TYPES_BY_ADAPTER = {
    "bucket_assay_serving_table_sql": ["assay_run", "assay_result", "compound_test_event", "media_link"],
    "bucket_assay_quality_report_sql": ["text_line"],
    "bucket_assay_media_candidates_sql": ["assay_media_link"],
    "bucket_assay_media_links": ["assay_media_link"],
    "bucket_assay_metric_reference_sql": ["pdf_page"],
    "bucket_compounds_tested_all_structured_sql": ["tested_compound_all"],
    "bucket_compounds_tested_by_date_window_sql": ["tested_compound_window"],
    "bucket_assay_best_result_environment_conditions_sql": ["best_result_environment_condition"],
    "bucket_assay_summary_file_explanation_sql": ["assay_summary_file"],
    "bucket_contact_noncontact_adjusted_pi_comparison_sql": ["contact_noncontact_ranked_comparison"],
    "bucket_cross_assay_repellent_rank_compounds_sql": ["cross_assay_repellent_ranking_row"],
    "bucket_cross_assay_run_inventory_sql": ["cross_assay_run_family", "assay_inventory_count"],
    "bucket_docking_pipeline_sql": ["text_line"],
    "bucket_docking_results_sql": ["gcs_object", "csv_row", "text_line", "model_file_metadata", "json_path"],
    "bucket_script_method_evidence_sql": ["script_line"],
    "chemistry_analysis_script_method_evidence_sql": ["script_line"],
    "bucket_individual_assay_timepoint_sql": ["individual_assay_timepoint", "dart_individual_assay_timepoint", "contact_individual_assay_timepoint", "phytotox_timepoint", "csv_row"],
    "bucket_dart_individual_assay_timepoint_sql": ["dart_individual_assay_timepoint", "csv_row"],
    "bucket_experiment_listing_sql": ["bucket_experiment_prefix"],
    "bucket_experiments_by_organism_sql": ["gcs_object", "csv_row", "xlsx_cell", "text_line", "model_file_metadata"],
    "bucket_experiments_by_run_date_sql": ["dart_assay_run_date_group"],
    "bucket_fly_assay_count_sql": ["fly_assay_count"],
    "bucket_fly_result_video_bridge_sql": ["fly_result_video_bridge"],
    "bucket_fly_repellency_rankings_sql": ["fly_repellency_ranking_row"],
    "bucket_fly_trial_metadata_join_sql": ["fly_trial_metadata_row"],
    "bucket_insect_image_taxonomy_inventory_sql": ["bucket_object"],
    "bucket_model_metadata_sql": ["model_file_metadata"],
    "bucket_phytotox_experiment_summary_sql": ["phytotox_result_row"],
    "bucket_phytotox_metric_reference_sql": ["pdf_page", "csv_column"],
    "bucket_phytotox_rank_compounds_by_assay_species_sql": ["phytotox_assay_constrained_rank"],
    "bucket_phytotox_rank_compounds_sql": ["phytotox_result_row"],
    "bucket_recent_contact_no_contact_assays_sql": ["bucket_object", "contact_no_contact_assay_count"],
    "bucket_recent_media_by_mode_sql": ["bucket_object"],
    "bucket_structured_anchor_probe_sql": ["dart_assay_row", "assay_media_link", "model_file_metadata"],
    "bucket_top_repellents_by_species_sql": ["dart_assay_row"],
    "company_profile_unit_lookup_sql": ["company_memory_unit"],
    "compound_inventory_all_names_sql": ["xlsx_cell"],
    "compound_inventory_master_count_sql": ["xlsx_cell"],
    "compound_inventory_master_row_lookup": ["xlsx_cell"],
    "compound_inventory_summary_sql": ["workbook", "xlsx_sheet"],
    "people_directory_advisor_roster_sql": ["company_memory_unit"],
    "people_directory_employee_roster_sql": ["company_memory_unit"],
    "people_directory_partnership_roster_sql": ["company_memory_unit"],
    "people_directory_person_lookup_sql": ["company_memory_unit"],
    "teams_recaps_meeting_anchor_sql": ["meeting_instance"],
    "teams_recaps_meeting_digest_by_date_sql": ["meeting_instance"],
    "teams_recaps_topic_speaker_rollup_sql": ["meeting_utterance"],
    "teams_recaps_utterance_lookup_sql": ["meeting_utterance"],
}


RANKING_TERMS = [
    "best",
    "from 1-",
    "highest",
    "least",
    "lowest",
    "most",
    "rank",
    "ranked",
    "ranking",
    "strongest",
    "top",
    "worst",
]

PHYTOTOX_TERMS = [
    "browning",
    "chlorosis",
    "damaged",
    "damaged fraction",
    "leaf damage",
    "necrosis",
    "phytoxic",
    "phytotox",
    "phytotoxic",
    "phytotoxicity",
    "plant damage",
]

PHYTOTOX_METRIC_REFERENCE_TERMS = [
    "metrics",
    "metric",
    "metric reference",
    "reference guide",
    "ref guide",
    "what are",
    "what does",
    "what is",
    "define",
    "definition",
    "meaning",
    "interpret",
    "explain",
    "threshold",
    "thresholds",
    "ngrdi",
    "severity score",
    "severity_score",
    "translucent_fraction",
    "damaged_fraction",
    "chlorosis_fraction",
    "browning_fraction",
    "necrosis_fraction",
]

ASSAY_METRIC_REFERENCE_TERMS = [
    "dart avg. pi",
    "dart avg pi",
    "avg_pi",
    "avg pi",
    "preference index",
    "mean_contact_pi",
    "contact pi",
    "strict contact pi",
    "adjusted contact pi",
    "zone occupancy",
    "entry rate",
    "exit rate",
    "dwell time",
    "fly composite score",
]

SHORT_ASSAY_METRIC_REFERENCE_TERMS = [
    "pi",
    "trt_pi",
    "ex_trt_pi",
    "adj_contact_pi",
    "contact_pi",
    "frac_time_avoiding",
    "confidence",
    "corrected_mean_trt_pi",
    "original_mean_trt_pi",
    "response_latency_min",
    "centroid",
    "entropy",
    "polarization",
    "flux",
]

ASSAY_METRIC_DEFINITION_TERMS = [
    "what is",
    "what are",
    "what does",
    "define",
    "definition",
    "mean",
    "meaning",
    "interpret",
    "explain",
]

COMPOUND_TERMS = [
    "chemical",
    "chemicals",
    "compound",
    "compounds",
    "treatment",
    "treatments",
]


def _is_ranking_question(question):
    q = str(question).lower()
    rank_q = re.sub(r"\bmost\s+recent\b", "", q)
    return _has_any(rank_q, RANKING_TERMS) or bool(re.search(r"\b\d{1,3}\s*[-–]\s*\d{1,3}\b", q))


def _is_phytotox_metric_reference_question(question):
    q = str(question).lower()
    if not _has_any(q, PHYTOTOX_TERMS):
        return False
    if _has_any(q, ["highest", "lowest", "most", "least", "top", "rank", "ranking", "worst", "best"]):
        return False
    return _has_any(q, PHYTOTOX_METRIC_REFERENCE_TERMS)


def _has_recency_order_modifier(question):
    q = str(question).lower()
    if _has_any(q, ["most recent", "latest", "newest", "recent first", "latest first", "newest first"]):
        return True
    if re.search(r"\b(?:last|past)\s+(?:\d+|one|two|couple)\s+(?:day|days|week|weeks|month|months)\b", q):
        return False
    if re.search(r"\b(?:last|latest|recent|newest)\s+(?:\d{1,3}|one|two|three|four|five|ten)\b", q):
        return True
    return "recent" in q and _has_any(q, ["list", "show", "video", "videos", "media", "assay", "assays", "run", "runs", "upload", "uploads"])


def _has_meeting_commentary_request(question):
    q = str(question).lower()
    has_meeting_lane_term = _has_any(q, ["team", "r&d", "rd", "meeting", "meetings", "recap", "sync"])
    has_commentary_verb = bool(
        re.search(
            r"\b(said|say|says|discuss|discussed|talk|talked|mention|mentioned|cover|covered|notes|recap|summary|summarize)\b",
            q,
        )
    )
    return has_meeting_lane_term and has_commentary_verb


def _assay_meeting_bridge_date_phrase(question):
    q = str(question).lower()
    explicit_iso = _extract_explicit_iso_date(question)
    if explicit_iso:
        return f"on {explicit_iso}"
    for phrase in ("today", "yesterday", "last friday", "last week", "this week"):
        if phrase in q:
            return phrase
    if re.search(r"\bfriday\b", q):
        return "friday"
    if _has_any(q, ["latest", "recent"]):
        return "recently"
    return ""


def _assay_meeting_bridge_assay_phrase(question):
    species = species_from_question(question)
    if species == "flies":
        return "fly assays"
    if species == "mosquitoes":
        return "mosquito assays"
    if species == "beetles":
        return "beetle assays"
    if species == "moths":
        return "moth assays"
    if species == "drosophila":
        return "drosophila assays"
    return "assays"


def _assay_meeting_bridge_step_questions(question):
    assay_phrase = _assay_meeting_bridge_assay_phrase(question)
    date_phrase = _assay_meeting_bridge_date_phrase(question)
    assay_question = f"what {assay_phrase} ran"
    meeting_question = f"what did the team say about {assay_phrase}"
    if date_phrase:
        assay_question = f"{assay_question} {date_phrase}"
        meeting_question = f"{meeting_question} {date_phrase}"
    return assay_question, meeting_question


def _assay_species_constraints_from_question(question):
    q = str(question).lower()
    species = []
    if _has_any(q, ["fly", "flies", "swd", "drosophila"]):
        species.append("flies")
    if _has_any(q, ["mosquito", "mosquitoes"]):
        species.append("mosquitoes")
    if _has_any(q, ["beetle", "beetles"]):
        species.append("beetles")
    if _has_any(q, ["diamondback", "diamond back", "dbm", "plutella", "moth", "moths"]):
        species.append("moths")
    return species


def _is_broad_repellent_ranking(question):
    q = str(question).lower()
    if "dart" in q or species_from_question(question):
        return False
    if _has_any(q, ["video", "videos", "media", "movie", "recording", "pull up"]):
        return False
    has_repellency_target = _has_any(q, ["repellent", "repellents", "repellency", "preference index", "pi"])
    has_compound_target = _has_any(q, COMPOUND_TERMS) or "repellents" in q
    return has_repellency_target and has_compound_target and _is_ranking_question(question)


def _bucket_fly_assay_count_applies(question):
    q = str(question).lower()
    return (
        species_from_question(question) == "flies"
        and _has_any(q, ["assay", "assays", "trial", "trials", "run", "runs"])
        and _has_count_request(question)
    )


def _dart_assay_ledger_listing_applies(question):
    q = str(question).lower()
    species = species_from_question(question)
    if species != "beetles":
        return False
    if _is_ranking_question(question):
        return False
    if _has_any(q, ["contact", "non-contact", "noncontact", "no contact", "phytotoxicity", "oviposition"]):
        return False
    return _has_any(q, ["assay", "assays", "trial", "trials", "dart"]) and (
        _has_any(q, ["list", "show", "which", "all"]) or _has_count_request(question)
    )


def _has_count_request(question):
    q = str(question).lower()
    return bool(_has_any(q, ["how many", "count", "total"]) or re.search(r"\bnumber of\b", q))


def _known_contact_compound_case_sql(video_expr):
    lower_expr = f"lower(coalesce({video_expr}, ''))"
    return f"""
            CASE
              WHEN {lower_expr} LIKE '%1c4eb%' THEN '1C4EB'
              WHEN {lower_expr} LIKE '%2pp%' OR {lower_expr} LIKE '%2propylphenol%' THEN '2PP'
              WHEN {lower_expr} LIKE '%3pp%' THEN '3PP'
              WHEN {lower_expr} LIKE '%bcaryo%' THEN 'Bcaryo'
              WHEN {lower_expr} LIKE '%bhomocyclo%' OR {lower_expr} LIKE '%bhcyclo%' THEN 'Bhomocyclo'
              WHEN {lower_expr} LIKE '%bcyclo%' THEN 'Bcyclo'
              WHEN {lower_expr} LIKE '%butacet%' THEN 'ButAcet'
              WHEN {lower_expr} LIKE '%deet%' THEN 'DEET'
              WHEN {lower_expr} LIKE '%eugenol%' THEN 'Eugenol'
              WHEN {lower_expr} LIKE '%i3pp%' THEN 'I3PP'
              WHEN {lower_expr} LIKE '%ir3535%' THEN 'IR3535'
              WHEN {lower_expr} LIKE '%menthol%' THEN 'Menthol'
              WHEN {lower_expr} LIKE '%menthone%' THEN 'Menthone'
              WHEN {lower_expr} LIKE '%mnda%' OR {lower_expr} LIKE '%mndanthra%' THEN 'MNDA'
              WHEN {lower_expr} LIKE '%pea%' THEN 'PEA'
              WHEN {lower_expr} LIKE '%pepoil%' THEN 'PepOil'
              WHEN {lower_expr} LIKE '%phpramide%' THEN 'PhPrAmide'
              WHEN {lower_expr} LIKE '%picaridin%' THEN 'Picaridin'
              WHEN {lower_expr} LIKE '%thymol%' THEN 'Thymol'
              ELSE trim(coalesce({video_expr}, ''))
            END
    """


def _contact_object_compound_from_marker_sql(marker):
    extracted = (
        f"replace(replace(replace(replace(substr(name, instr(lower(name), '{marker}') + length('{marker}')), "
        "'.mov', ''), '.mp4', ''), '.MOV', ''), '.MP4', '')"
    )
    return f"""
              CASE
                WHEN lower({extracted}) LIKE '%_mov' THEN substr({extracted}, 1, length({extracted}) - length('_mov'))
                WHEN lower({extracted}) LIKE '%_mp4' THEN substr({extracted}, 1, length({extracted}) - length('_mp4'))
                ELSE {extracted}
              END
    """


def _bucket_contact_noncontact_adjusted_pi_comparison_applies(question):
    q = str(question).lower()
    if _has_any(q, ["temp", "temperature", "humidity", "rh"]):
        return False
    asks_contact = re.search(r"\bcontact\b", q) is not None
    asks_noncontact = _has_any(q, ["noncontact", "non-contact", "non contact", "no-contact", "no contact"])
    asks_compare = bool(re.search(r"\bmost\s+(?!recent\b)", q)) or _has_any(
        q,
        ["compare", "comparison", "versus", " vs ", "against", "top", "rank", "lead", "best", "strongest"],
    )
    return bool(asks_contact and asks_noncontact and asks_compare)


def _extract_named_compound_for_rank(question):
    q = str(question).lower()
    for compound in ["PhPrAmide", "Picaridin", "IR3535", "PepOil", "Menthol", "Thymol", "DEET", "2PP", "PEA"]:
        if compound.lower() in q:
            return compound
    return None


def _bucket_rank_expectation_explanation_applies(question):
    q = str(question).lower()
    return (
        re.search(r"\bcontact\b", q) is not None
        and _has_any(q, ["why", "should", "shouldn't", "not in the top", "ranked higher", "missing"])
        and _extract_named_compound_for_rank(question) is not None
    )


def _bucket_assay_summary_file_explanation_applies(question):
    q = str(question).lower()
    return _has_any(q, ["adjusted summary", "adjusted_contact_pi_summary", "newer adjust summary", "newer adjusted summary"])


def _script_method_question_applies(question):
    q = str(question).lower()
    asks_source_claim = (
        q.startswith("what does monarch say about")
        or q.startswith("what do presentations say about")
        or q.startswith("what does the milestones doc say about")
        or q.startswith("what do meeting recaps say about")
        or q.startswith("what did the team say about")
    )
    if asks_source_claim and not _has_any(q, ["script", "scripts", "code", "source code"]):
        return False
    if (
        _has_any(q, ["ai model", "ai models", "computer vision"])
        and not _has_any(q, ["script", "scripts", "code", "source code", "implementation"])
    ):
        return False
    asks_method = (
        _has_any(
            q,
            [
                "script",
                "scripts",
                "code",
                "pipeline",
                "implementation",
                "algorithm",
                "calculated",
                "calculate",
                "computed",
                "compute",
                "generated",
                "produced",
                "made",
                "method",
                "provenance",
            ],
        )
        or q.startswith("how is ")
        or q.startswith("how are ")
        or q.startswith("how does ")
        or q.startswith("how do ")
        or q.startswith("what script ")
        or q.startswith("which script ")
    )
    has_target = _has_any(
        q,
        [
            "adjusted contact pi",
            "contact pi",
            "preference index",
            " pi",
            "metric",
            "metrics",
            "entropy",
            "centroid",
            "dispersion",
            "flux",
            "avoidance",
            "phytotoxicity",
            "phytotox",
            "chlorosis",
            "browning",
            "necrosis",
            "feature",
            "features",
            "features_all",
            "leaf",
            "docking",
            "dock",
            "registry",
            "chemical registry",
            "receptor",
            "odorant receptor",
            "relaxation",
            "segmentation",
            "detection",
            "tracking",
            "assay",
            "fly",
            "flies",
            "mosquito",
            "mosquitoes",
            "oviposition",
        ],
    )
    result_only = _is_ranking_question(question) and not _has_any(
        q,
        ["script", "scripts", "code", "calculated", "computed", "method", "pipeline", "how is", "how does"],
    )
    return bool(asks_method and has_target and not result_only)


def _script_method_source_for_question(question):
    if not _script_method_question_applies(question):
        return None
    q = str(question).lower()
    if _has_any(
        q,
        [
            "chemical registry",
            "chemistry registry",
            "docking",
            "dock",
            "vina",
            "pdbqt",
            "receptor",
            "odorant receptor",
            "or sequence",
            "protein structure",
            "alphafold",
            "relaxation",
        ],
    ):
        return "chemistry_analysis"
    return "bucket"


def _bucket_assay_best_result_environment_conditions_applies(question):
    q = str(question).lower()
    asks_environment = _has_any(q, ["temp", "temperature", "humidity", "rh"])
    asks_best_result = _has_any(q, ["promising", "best", "strongest", "top", "ideal", "optimal"])
    asks_assay_or_effect = _has_any(
        q,
        [
            "assay",
            "assays",
            "result",
            "results",
            "repellent",
            "repellents",
            "repellency",
            "preference index",
            " pi",
            "contact",
            "noncontact",
            "non-contact",
            "no contact",
            "no-contact",
            "dart",
            "experiment",
            "experiments",
            "oviposition",
            "egg laying",
            "egg-laying",
            *PHYTOTOX_TERMS,
        ],
    )
    return (
        asks_environment
        and asks_best_result
        and asks_assay_or_effect
    )


def _answer_shape_for_question(question):
    q = str(question).lower()
    has_compound_target = _has_any(q, COMPOUND_TERMS)
    has_repellency_target = _has_any(q, ["repellent", "repellents", "repellency", "preference index", "pi"])
    has_milestone_target = _has_any(q, ["milestone", "milestones"])
    asks_milestone_mentions = has_milestone_target and _has_any(q, ["mention", "mentioned", "whether", "say", "said"])
    asks_meeting_commentary = _has_meeting_commentary_request(question)
    asks_media_proof = _has_any(q, ["video", "videos", "media", "movie", "recording", "pull up", "show"])

    if _script_method_question_applies(question):
        return "script_method_evidence"
    if _bucket_individual_assay_timepoint_applies(question):
        return "individual_assay_timepoint_ranking"
    if _is_assay_metric_reference_question(question):
        return "metric_definition"
    if (
        has_repellency_target
        and _is_ranking_question(question)
        and asks_milestone_mentions
    ):
        return "ranked_repellents_with_milestone_mentions"
    if (
        species_from_question(question) == "flies"
        and has_repellency_target
        and _is_ranking_question(question)
        and asks_media_proof
    ):
        return "ranked_repellents_with_media"
    if _is_broad_repellent_ranking(question):
        return "ranked_cross_assay_repellent_compounds"
    if _bucket_rank_expectation_explanation_applies(question):
        return "rank_expectation_explanation"
    if _bucket_contact_noncontact_adjusted_pi_comparison_applies(question):
        return "contact_noncontact_ranked_comparison"
    if _bucket_assay_summary_file_explanation_applies(question):
        return "assay_summary_file_explanation"
    if _bucket_assay_best_result_environment_conditions_applies(question):
        return "assay_best_result_environment_conditions"
    if _bucket_fly_assay_count_applies(question):
        return "fly_assay_count"
    if _bucket_cross_assay_run_inventory_applies(question) and _has_count_request(question):
        return "assay_inventory_count"
    if (
        _bucket_cross_assay_run_inventory_applies(question)
        and asks_meeting_commentary
    ):
        return "assay_runs_with_meeting_commentary"
    if (
        _bucket_cross_assay_run_inventory_applies(question)
        and _has_any(q, ["video", "videos", "media", "movie", "recording", "pull up"])
    ):
        return "assay_runs_with_media"
    if _is_phytotox_metric_reference_question(question):
        return "metric_definition"
    if _is_phytotox_inventory_ranking(question):
        return "ranked_compounds_with_inventory_status"
    if (
        _has_any(q, PHYTOTOX_TERMS)
        and has_compound_target
        and _is_ranking_question(question)
        and _assay_species_constraints_from_question(question)
        and _has_any(q, ["assay", "assays", "tested", "experiment", "experiments", "ran", "run"])
    ):
        return "ranked_phytotoxicity_compounds_with_assay_species_constraint"
    if (
        _has_any(q, PHYTOTOX_TERMS)
        and has_compound_target
        and _is_ranking_question(question)
    ):
        return "ranked_phytotoxicity_compounds"
    if (
        species_from_question(question) == "flies"
        and has_repellency_target
        and _is_ranking_question(question)
    ):
        return "ranked_fly_repellent_compounds"
    if (
        species_from_question(question)
        and has_repellency_target
        and _is_ranking_question(question)
    ):
        return "ranked_species_repellent_compounds"
    if _bucket_compounds_tested_by_date_window_applies(question):
        return "tested_compound_date_window"
    if _bucket_compounds_tested_all_structured_applies(question):
        return "tested_compound_list"
    if _dart_assay_ledger_listing_applies(question):
        return "assay_run_list"
    if _bucket_cross_assay_run_inventory_applies(question):
        return "assay_run_list"
    if _bucket_recent_contact_no_contact_assays_applies(question):
        return "recent_contact_no_contact_assays"
    if _bucket_recent_media_by_mode_parameters(question):
        return "recent_media_by_mode"
    if _is_media_proof_question(question):
        return "assay_media_proof"
    return None


def _route_candidate(
    intent,
    source_lane,
    retrieval_shape,
    adapter,
    adapter_execution,
    reason,
    *,
    answer_shapes=None,
    partial_answer_shapes=None,
    sql=None,
    **extra,
):
    candidate = {
        "intent": intent,
        "source_lane": source_lane,
        "retrieval_shape": retrieval_shape,
        "adapter": adapter,
        "adapter_execution": adapter_execution,
        "reason": reason,
        "answer_shapes": list(answer_shapes or []),
        "partial_answer_shapes": list(partial_answer_shapes or []),
    }
    if sql is not None:
        candidate["sql"] = sql
    candidate.update(extra)
    return candidate


def _candidate_trace(candidate, answer_shape=None, selected=False, rejected_reason=None):
    trace = {
        "source_lane": candidate.get("source_lane"),
        "intent": candidate.get("intent"),
        "retrieval_shape": candidate.get("retrieval_shape"),
        "adapter": candidate.get("adapter"),
        "adapter_execution": candidate.get("adapter_execution"),
        "answer_shapes": list(candidate.get("answer_shapes") or []),
        "partial_answer_shapes": list(candidate.get("partial_answer_shapes") or []),
        "sql_present": bool(candidate.get("sql")),
        "reason": candidate.get("reason"),
    }
    if answer_shape:
        trace["target_answer_shape"] = answer_shape
    if selected:
        trace["selected"] = True
    if rejected_reason:
        trace["rejected_reason"] = rejected_reason
    return trace


def _select_candidate_for_answer_shape(question, candidates):
    answer_shape = _answer_shape_for_question(question)
    if not candidates:
        return None, answer_shape, [], []
    if not answer_shape:
        return candidates[0], None, [], []

    selected = None
    first_partial = None
    for candidate in candidates:
        if answer_shape in candidate.get("answer_shapes", []):
            selected = candidate
            break
        if first_partial is None and answer_shape in candidate.get("partial_answer_shapes", []):
            first_partial = candidate
    if selected is None and first_partial is not None:
        selected = first_partial
    rejected = []
    candidate_routes = []
    for candidate in candidates:
        if candidate is selected:
            candidate_routes.append(_candidate_trace(candidate, answer_shape, selected=True))
            continue
        if answer_shape in candidate.get("answer_shapes", []):
            rejected_reason = "lower_priority_exact_answer_shape"
        elif answer_shape in candidate.get("partial_answer_shapes", []):
            rejected_reason = "partial_answer_only"
        else:
            rejected_reason = "cannot_produce_answer_shape"
        rejected_trace = _candidate_trace(candidate, answer_shape, rejected_reason=rejected_reason)
        rejected.append(rejected_trace)
        candidate_routes.append(rejected_trace)

    return selected, answer_shape, candidate_routes, rejected


def _missing_answer_shape_adapter(source, answer_shape, candidate_routes, rejected_routes):
    missing_adapter = f"{source}_{answer_shape}_query_code"
    return {
        "intent": "answer_shape_without_query_code",
        "adapter": missing_adapter,
        "adapter_execution": "none",
        "reason": "answer shape was inferred, but no structured query code can produce that shape for the selected source lane",
        "answer_shape": answer_shape,
        "selection_policy": "answer_shape_first",
        "candidate_routes": candidate_routes,
        "rejected_routes": rejected_routes,
        "missing_adapter": missing_adapter,
        "force_source_gap": True,
    }


def _adapter_from_candidate(candidate):
    if not candidate:
        return None
    adapter = {
        "intent": candidate["intent"],
        "adapter": candidate["adapter"],
        "adapter_execution": candidate["adapter_execution"],
        "reason": candidate["reason"],
    }
    if "sql" in candidate:
        adapter["sql"] = candidate["sql"]
    for key, value in candidate.items():
        if key in {
            "intent",
            "adapter",
            "adapter_execution",
            "reason",
            "sql",
            "source_lane",
            "retrieval_shape",
            "answer_shapes",
            "partial_answer_shapes",
        }:
            continue
        adapter[key] = value
    return adapter


def _attach_answer_shape_trace(adapter, answer_shape, candidate_routes, rejected_routes):
    if not adapter or not answer_shape:
        return adapter
    adapter = dict(adapter)
    adapter["answer_shape"] = answer_shape
    adapter["selection_policy"] = "answer_shape_first"
    adapter["candidate_routes"] = candidate_routes
    adapter["rejected_routes"] = rejected_routes
    return adapter


def semantic_tokens(text):
    return {
        token
        for token in re.findall(r"[a-z0-9]+", str(text).lower())
        if token not in SEMANTIC_STOPWORDS
    }


def anchor_tokens(text):
    return [
        token
        for token in re.findall(r"[a-z0-9]+", str(text).lower())
        if token not in ANCHOR_STOPWORDS and len(token) > 1
    ]


def _terms_values_sql(terms):
    unique_terms = []
    for term in terms:
        normalized = str(term).strip().lower()
        if normalized and normalized not in unique_terms:
            unique_terms.append(normalized)
    if not unique_terms:
        return None
    return ", ".join(f"({sql_literal(term)})" for term in unique_terms)


def semantic_adapter_match(question, source, threshold=0.5):
    source_config = _sources().get(source, {})
    semantic_adapters = source_config.get("semantic_adapters", {})
    question_text = str(question).lower()
    question_tokens = semantic_tokens(question_text)
    best = None
    for adapter, aliases in semantic_adapters.items():
        for alias in aliases:
            alias_text = str(alias).lower()
            alias_tokens = semantic_tokens(alias_text)
            if not alias_tokens:
                continue
            overlap = len(question_tokens & alias_tokens)
            token_score = overlap / len(alias_tokens)
            phrase_score = 1.0 if alias_text in question_text else 0.0
            if token_score < 1.0 and phrase_score < 1.0:
                continue
            if len(alias_tokens) == 1 and len(question_tokens) > 3 and phrase_score < 1.0:
                continue
            score = max(token_score, phrase_score)
            if best is None or score > best["confidence"]:
                best = {
                    "adapter": adapter,
                    "confidence": round(score, 3),
                    "matched_alias": alias,
                    "threshold": threshold,
                }
    if best and best["confidence"] >= threshold and adapter_declared(source, best["adapter"]):
        return best
    return None


def source_capability_match_for_question(question):
    q = _normalized_text(question)
    best = None
    for source, source_config in _source_capabilities().items():
        retrieval_stage = source_config.get("retrieval_stage")
        if retrieval_stage != "structured_table_sql":
            continue
        source_priority = int(source_config.get("structured_priority", 999))
        capabilities = source_config.get("capabilities", {})
        for capability_id, capability in capabilities.items():
            for alias in capability.get("aliases", []):
                alias_text = _normalized_text(alias)
                if not alias_text:
                    continue
                if re.search(rf"\b{re.escape(alias_text)}\b", q):
                    candidate = {
                        "source": source,
                        "retrieval_stage": retrieval_stage,
                        "capability_id": capability_id,
                        "matched_alias": alias,
                        "description": capability.get("description"),
                        "adapters": capability.get("adapters", []),
                        "grain_types": capability.get("grain_types", []),
                        "structured_priority": source_priority,
                    }
                    if best is None or source_priority < best["structured_priority"]:
                        best = candidate
    return best


def sql_literal(value):
    return "'" + str(value).replace("'", "''") + "'"


def people_query_for_question(question):
    q = question.lower()
    aliases = [
        ("Avinash Chandel", ["avinash", "chandel"]),
        ("Bryce Rogers", ["bryce", "rogers"]),
        ("Geoffrey Broadhead", ["geoffrey", "broadhead"]),
        ("Joel Kowalewski", ["joel", "kowalewski", "joel's"]),
        ("Josh Tetrick", ["josh", "tetrick"]),
        ("Leila Domen", ["leila", "domen"]),
        ("Priyanka Mahadevia", ["priyanka", "mahadevia"]),
        ("Erica McAlister", ["erica", "mcalister"]),
    ]
    for canonical, terms in aliases:
        if any(re.search(rf"\b{re.escape(term)}\b", q) for term in terms):
            return canonical
    return None


def structured_table_source_for_question(question):
    q = str(question).lower()
    if _is_inventory_to_assay_results(question):
        return "compound_inventory"
    if _bucket_insect_image_taxonomy_inventory_sql(question):
        return "bucket"
    if (
        species_from_question(question) == "moths"
        and _has_any(q, ["assay", "assays", "experiment", "experiments", "oviposition", "egg", "eggs", "image", "images"])
    ):
        return "bucket"
    if _has_any(q, ["oviposition", "egg laying", "egg-laying"]) and _has_any(q, ["assay", "assays", "experiment", "experiments", "data", "results"]):
        return "bucket"
    if _has_any(q, COMPOUND_INVENTORY_STRUCTURED_TERMS) or re.search(r"\bcas\b", q):
        return "compound_inventory"
    if re.search(r"\b(?:what|which|show|list)\s+milestones?\s+(?:mention|mentions|discuss|say)", q):
        return None
    if _has_any(q, SCIENTIFIC_REFS_TEXT_TERMS) and not _has_any(
        q,
        [
            "assay",
            "assays",
            "experiment",
            "experimental data",
            "experiments",
            "repellency",
            "repellent",
            "tested",
        ],
    ):
        return None
    capability_match = source_capability_match_for_question(question)
    if capability_match:
        return capability_match["source"]
    if _has_any(q, BUCKET_STRUCTURED_TABLE_TERMS):
        return "bucket"
    if _is_teams_meeting_context(question) or _is_teams_discussion_digest_question(question):
        return "teams_recaps"
    if _has_any(q, PEOPLE_DIRECTORY_STRUCTURED_TERMS):
        return "people_directory"
    if _has_any(q, COMPANY_PROFILE_STRUCTURED_TERMS):
        return "company_profile"
    return None


def secondary_text_sources_for_question(question, primary_source=None):
    q = str(question).lower()
    sources = []

    def add(source):
        if source != primary_source and source not in sources:
            sources.append(source)

    if _has_any(q, MILESTONE_TEXT_TERMS):
        add("milestones_doc")
    if _has_any(q, SCIENTIFIC_REFS_TEXT_TERMS):
        add("scientific_refs")
    if _has_any(q, PRESENTATION_TEXT_TERMS):
        add("presentations")
    if _has_any(q, CROSS_EXPERIMENT_TEXT_TERMS):
        add("cross_experiment_docs")
    if _is_teams_secondary_text_request(question) and primary_source != "teams_recaps":
        add("teams_recaps")
    return sources


def priority_source_plan_for_question(question):
    primary_source = structured_table_source_for_question(question)
    if not primary_source:
        return []
    secondary_sources = secondary_text_sources_for_question(question, primary_source=primary_source)
    if not secondary_sources:
        return []
    return [primary_source] + secondary_sources


def text_source_hint_for_question(question):
    q = str(question).lower()

    def has_any(terms):
        return _has_any(q, terms)

    if has_any(["company context"]):
        return "company_context"
    if has_any(["milestones doc", "milestone doc", "milestones document"]):
        return "milestones_doc"
    if has_any(["figure guide", "figure_guide", "csv data dictionary", "csv_data_dictionary", "data dictionary pdf", "cross-experiment aggregation", "aggregate_experiments.py", "aggregate_experiments", "treatment_summary.csv", "sample_sizes.csv", "top_performing_chemicals.csv", "per_experiment_means.csv", "timecourse_summary.csv", "experiment_catalog.csv", "summary_table.csv"]):
        return "cross_experiment_docs"
    if has_any(["what does monarch do", "what is monarch", "where is monarch", "mission", "headquarters", "hq", "emeryville", "status quo", "insects monarch works", "what insects", "which insects", "insects does monarch", "insects we work with", "organisms we work with", "organisms", "crop species", "list all of the insects we work with"]):
        return "company_profile"
    if people_query_for_question(question) and has_any(["background", "education", "ph.d", "phd", "master", "patent", "focus", "role", "who is"]):
        return "people_directory"
    if has_any(["r&d meeting", "rd meeting", "meeting discuss", "meeting discussed", "what did the team discuss"]):
        return "teams_recaps"
    if has_any(["presentation", "deck", "slide", "storyboard", "company update"]):
        return "presentations"
    if q.startswith("what does monarch say about") and has_any(["odorant receptor complexes"]):
        return "teams_recaps"
    if has_any([
        "ai models detecting mosquito behavior",
        "severity scores",
        "phytotoxicity concerns",
    ]):
        return "milestones_doc"
    if has_any(["scientific reference", "scientific refs", "scientific literature", "literature paper", "literature papers", "literature", "research paper", "research papers", "paper library", "papers folder", "chemical ecology", "important receptors", "olfactory receptor", "olfaction receptor", "odorant receptor", "modeling papers", "high throughput assay prototype", "high-throughput assay prototype", "scalability high throughput", "epa registration info", "glp labs", "ethoscope"]):
        return "scientific_refs"

    if q.startswith("what does monarch say about"):
        if has_any([
            "accelerating evaluation agriculturally relevant chemicals",
            "accelerating evaluation chemicals agriculturally relevant",
            "automated processing pipeline scoring behavior",
            "developed assays analyze mode action",
            "developed automated processing pipeline",
            "developed pipeline automatically process video",
            "developed standardized dart assay",
            "expanding pipeline evaluate chemicals",
            "extended this assay work",
            "gcp ai pipeline",
            "identified least one chemical structure",
            "improved ai models",
            "improved models help analyze",
            "in silico",
            "localized discoloration",
            "multiple modes of action on multiple insects",
            "rational design",
            "physicochemical properties",
            "optimized developed phytotoxicity assay",
            "severity scoring",
            "severity scores",
            "phytotoxicity concerns",
            "screened chemicals using mosquito dart",
            "secure storage bucket results upload",
            "strongly repellent",
        ]):
            return "milestones_doc"
        if has_any([
            "added oviposition images",
            "annotating moth",
            "badly damaged",
            "beetle videos",
            "basic tracking analysis",
            "build other insect detection models",
            "building new chemical structure models",
            "built soybean leaf segmentation model",
            "chemical structure models",
            "color shift",
            "computer vision",
            "contact repellency completed",
            "contact repellency model trained",
            "contact repellency retrain",
            "damage-color",
            "detection analysis",
            "detection rebuild model",
            "detection pipeline",
            "fewer heavy",
            "finalizing phytotox pipeline",
            "finalize phytotox pipeline",
            "fly contact repellency model",
            "h-donor",
            "hsv space",
            "implemented basic tracking",
            "improve insect tracking",
            "latest model version",
            "latest models",
            "fly images",
            "insect classification",
            "main detection pipeline",
            "model architectures",
            "mosquito contact repellency retrain",
            "mosquito fly model",
            "mosquito fly models",
            "non-contact 2pp",
            "non-contact repellency 2pp",
            "original pipeline",
            "original pipeline designed different expected",
            "optimizing pipeline",
            "phytotoxicity soybean leaf assay",
            "pixel fraction",
            "pixel fractions",
            "pose estimation",
            "pose estimation build evaluate model",
            "reactive thiols",
            "soybean leaf damage metrics",
            "soybean segmentation",
            "soybean leaf segmentation",
            "tracking approaches",
            "tracking capabilities",
            "tracking model",
            "tracking models",
            "tracking algorithm",
            "tracking algorithms",
            "tried three different tracking",
            "version latest model",
            "yolo26 model",
        ]):
            return "presentations"
        if has_any([
            "agar heat",
            "assay better model",
            "assay finalize",
            "camera",
            "communications biology odor receptors",
            "d and d reliability",
            "dart open position deterrent",
            "dpg solvent",
            "dpg solvents",
            "film everything",
            "fly food preparation",
            "flywalk",
            "latest fly model",
            "model performance",
            "model training data",
            "model will cases",
            "model probably not perform",
            "models able detect beetles",
            "mosquito drosophila",
            "mosquito looked",
            "mosquito videos",
            "mosquito-specific testing",
            "mosquitoes want model predictions",
            "moving cameras",
            "multiple cameras",
            "odorant hot agar",
            "odor preparation",
            "odorant receptor complexes",
            "overhead camera",
            "preference index currently",
            "solvent being too reactive",
            "solvents contact purposes",
            "spatial assays",
            "spatial assay",
            "stereoscope camera",
            "vapor pressure",
            "agricultural relevance of assays",
        ]):
            return "teams_recaps"
        if has_any(["mosquito", "mosquitoes", "fly", "flies", "drosophila", "model", "models", "assay", "assays"]):
            return "teams_recaps"

    if has_any(["mode of action", "mode-of-action", "62 chemicals", "performed better than deet", "strongly repellent", "colony setup"]):
        return "milestones_doc"
    if has_any(["meeting", "teams recap", "r&d recap", "transcript", "action item", "decision", "discuss", "discussed"]):
        return "teams_recaps"
    if has_any(PRESENTATION_TEXT_TERMS):
        return "presentations"
    if has_any(MILESTONE_TEXT_TERMS):
        return "milestones_doc"
    if has_any(COMPANY_PROFILE_STRUCTURED_TERMS):
        return "company_profile"
    return None


def auto_source_for_question(question):
    q = question.lower()
    if _is_inventory_to_assay_results(question):
        return "compound_inventory"
    script_source = _script_method_source_for_question(question)
    if script_source:
        return script_source
    answer_shape = _answer_shape_for_question(question)
    if answer_shape in {
        "assay_inventory_count",
        "assay_run_list",
        "assay_runs_with_media",
        "assay_runs_with_meeting_commentary",
        "cross_assay_run_inventory",
        "dart_assay_run_date_list",
        "experiment_run_list",
        "recent_contact_no_contact_assays",
    }:
        return "bucket"
    text_source = text_source_hint_for_question(question)
    if text_source:
        return text_source
    structured_source = structured_table_source_for_question(question)
    if structured_source:
        return structured_source
    if _has_any(q, ["r&d meeting", "rd meeting", "meeting discuss", "meeting discussed", "what did the team discuss", "last friday"]):
        return "teams_recaps"
    if _has_any(q, ["presentation", "deck", "slide", "storyboard", "company update"]):
        return "presentations"
    if _has_any(q, ["milestone", "milestones", "mode of action", "mode-of-action"]):
        return "milestones_doc"
    if _has_any(q, ["secure storage bucket results upload", "secure storage bucket", "bucket results upload"]):
        return "milestones_doc"
    if _has_any(q, ["scientific reference", "scientific refs", "scientific literature", "literature", "research paper", "research papers", "odorant receptor", "olfactory receptor", "olfaction receptor", "modeling papers", "chemical ecology"]):
        return "scientific_refs"
    if _has_any(q, ["what does monarch do", "what is monarch", "where is monarch", "mission", "headquarters", "hq", "emeryville", "organisms", "crop species", "what insects", "which insects", "insects does monarch", "insects monarch works", "insects monarch work"]):
        return "company_profile"
    if (_has_any(q, ["chemical inventory", "compound inventory", "chemical library", "inventory", "vendor", "sds", "stock", "do we have", "where is", "where do we store"]) or re.search(r"\bcas\b", q)):
        return "compound_inventory"
    if _has_any(q, ["advisor", "advisors", "advises", "advise", "who works", "who is", "employee", "employees", "team", "people", "role", "cto", "lab tech", "co-founder", "cofounder", "founder", "founders", "partner", "partnership"]):
        return "people_directory"
    return "bucket"


def _route_decision(intent, source, retrieval_shape, adapter, adapter_execution, reason, **extra):
    if retrieval_shape == "structured":
        fallback_policy = "no_silent_prose_fallback"
    elif retrieval_shape == "mixed":
        fallback_policy = extra.pop("fallback_policy", "structured_first_then_prose")
    elif retrieval_shape == "source_gap":
        fallback_policy = "fail_with_source_gap"
    else:
        fallback_policy = "source_specific_text_retrieval"
    structured_first = extra.pop(
        "structured_first",
        _structured_first_decision(source, retrieval_shape, adapter, adapter_execution),
    )
    expected_grain_types = extra.pop("expected_grain_types", EXPECTED_GRAIN_TYPES_BY_ADAPTER.get(adapter))
    decision = {
        "intent": intent,
        "source_lane": source,
        "retrieval_shape": retrieval_shape,
        "adapter": adapter,
        "adapter_execution": adapter_execution,
        "reason": reason,
        "fallback_policy": fallback_policy,
        "structured_first": structured_first,
    }
    if expected_grain_types:
        decision["expected_grain_types"] = list(expected_grain_types)
        if len(expected_grain_types) == 1:
            decision["expected_grain_type"] = expected_grain_types[0]
    decision.update(_shape_metadata_for_adapter(adapter))
    decision.update(extra)
    return decision


def _shape_metadata_for_adapter(adapter):
    if not adapter or evidence_shapes is None:
        return {}
    try:
        shape = evidence_shapes.shape_for_adapter(adapter)
    except (OSError, ValueError):
        shape = None
    if not shape:
        return {}
    return {
        "evidence_shape": shape["shape_id"],
        "evidence_shape_description": shape["description"],
        "latency_target_ms": shape["latency_target_ms"],
        "answer_limit": shape["answer_limit"],
    }


def _structured_first_decision(source, retrieval_shape, adapter, adapter_execution):
    if retrieval_shape == "structured":
        return {
            "checked": True,
            "source_lane": source,
            "answer_adapter": adapter,
            "anchor_adapter": "no_match",
            "result": "structured_answer",
        }
    if retrieval_shape == "mixed" and adapter_execution == "route_plan":
        return {
            "checked": True,
            "source_lane": source,
            "answer_adapter": adapter,
            "anchor_adapter": "no_match",
            "result": "structured_route_plan",
        }
    if retrieval_shape == "mixed":
        return {
            "checked": True,
            "source_lane": source,
            "answer_adapter": "no_match",
            "anchor_adapter": adapter,
            "result": "structured_anchor",
        }
    if retrieval_shape == "source_gap":
        return {
            "checked": True,
            "source_lane": source,
            "answer_adapter": "no_match",
            "anchor_adapter": "no_match",
            "result": "source_gap",
        }
    return {
        "checked": True,
        "source_lane": source,
        "answer_adapter": "no_match",
        "anchor_adapter": "no_match",
        "result": "prose_allowed",
    }


def _source_gap_decision(intent, source, reason, missing_adapter=None, route_plan=None, **extra):
    if missing_adapter:
        extra["missing_adapter"] = missing_adapter
    if route_plan:
        extra["route_plan"] = route_plan
        extra["fallback_policy"] = "fail_on_missing_structured_step"
    return _route_decision(
        intent=intent,
        source=source,
        retrieval_shape="source_gap",
        adapter=missing_adapter,
        adapter_execution="none",
        reason=reason,
        **extra,
    )


def _detected_question_modifiers(question):
    q = str(question).lower()
    modifiers = set()
    if _question_has_date_modifier(question):
        modifiers.add("date_window")
    if _extract_explicit_iso_date(q):
        modifiers.add("exact_date")
    if re.search(r"\bfrom\s+20\d{2}-\d{2}-\d{2}\s+to\s+20\d{2}-\d{2}-\d{2}\b", q):
        modifiers.add("date_range")
    if species_from_question(question):
        modifiers.add("species")
    if _has_any(q, ["contact", "non-contact", "noncontact", "no contact", "no-contact"]):
        modifiers.add("assay_mode")
    if _has_any(q, ["dart", "phytotoxicity", "docking", "oviposition", "contact/no-contact", "contact / no contact"]):
        modifiers.add("assay_family")
    known_compound_names = [
        "1o3ol",
        "2pp",
        "3pp",
        "bcaryo",
        "bcyclo",
        "bhomocyclo",
        "c3hb",
        "deet",
        "eugenol",
        "ir3535",
        "menthol",
        "menthone",
        "pepoil",
        "picaridin",
        "phpramide",
        "thymol",
    ]
    if _has_any(q, known_compound_names):
        modifiers.add("compound")
    if re.search(r"\b(?:vs\.?|versus|compare|comparison|difference|different|between)\b", q):
        modifiers.add("comparison")
    if _has_recency_order_modifier(question):
        modifiers.add("recency_order")
    rank_q = re.sub(r"\bmost\s+recent\b", "", q)
    if re.search(r"\b(?:top|bottom|rank|ranked|best|worst|most|least|strongest|weakest|effective|promising|third|3rd|\d+(?:st|nd|rd|th))\b", rank_q):
        modifiers.add("rank")
    if re.search(r"\b(?:dilution|dose|concentration|ppm|mg/ml|0\.\d+|\(\s*0\.)\b", q):
        modifiers.add("concentration")
    if _has_any(q, ["metric", "pi", "preference index", "composite", "auc", "sem", "late", "adjusted", "score", "temperature", "humidity", "rh", "temp"]):
        modifiers.add("metric")
    if _has_any(q, ["usable", "unusable", "failed", "failure", "control", "exclude controls", "qc", "quality", "minimum replicate", "min replicate"]):
        modifiers.add("quality")
    if _has_any(q, ["video", "videos", "media", "movie", "recording", "overlay", "pull up", "show me"]):
        modifiers.add("media")
    if _has_any(q, ["how many", "count", "total", "number of", "rows", "files", "runs", "experiments", "replicates"]):
        modifiers.add("count_unit")
    if _has_any(q, ["newer", "older", "latest summary", "new solvent", "new-solvent", "summary file", "file version"]):
        modifiers.add("source_version")
    if re.search(r"\b(speaker|speakers|said|say|talked|discussed|utterance|utterances)\b", q):
        modifiers.add("speaker")
    if _has_any(q, ["inventory", "stock", "in stock", "sds", "vendor", "cas", "location"]):
        modifiers.add("inventory_link")
    if re.search(r"\b(?:at least|minimum|min\.?|>=)\s+\d+\s+(?:replicates|reps|runs|experiments|trials|samples)\b", q) or _has_any(
        q,
        ["minimum replicate", "minimum replicates", "min replicate", "min replicates", "enough replicates", "one-off", "single run", "sample size"],
    ):
        modifiers.update(["replicate_strength", "minimum_replicates"])
    if _has_any(q, ["n_experiments", "number of experiments", "experiment count", "how many experiments", "across experiments"]):
        modifiers.add("experiment_count")
    if _has_any(q, ["unique compounds", "unique treatments", "unique dates", "unique runs", "distinct filenames", "distinct files", "tube rows", "assay families"]):
        modifiers.add("aggregation_level")
    if _has_any(q, ["dedupe", "deduplicate", "de-duplicate", "unique by", "group by", "per compound", "per date", "per run", "per file", "per video"]):
        modifiers.add("dedupe_basis")
    if _has_any(q, ["complete pair", "complete pairs", "complete contact and non-contact", "complete contact and no contact", "paired", "pairing", "both contact and non-contact", "both contact and no contact", "missing pair", "missing mode"]):
        modifiers.add("pairing_requirement")
    if _has_any(q, ["raw video", "raw videos", "raw media", "processed result", "processed results", "processed only", "with results", "has results", "adjusted pi exists", "frame metrics"]):
        modifiers.add("result_requirement")
    if _has_any(q, ["protocol version", "old protocol", "new protocol", "new solvent", "new-solvent", "old mosquito", "new mosquito"]):
        modifiers.add("protocol_version")
    if _has_any(q, ["usable only", "only usable", "qc-passed", "qc passed", "exclude failed", "exclude controls", "include controls", "non-control", "non control"]):
        modifiers.add("quality_filter")
    if _has_any(q, ["usable_data", "usable data", "usable flag"]):
        modifiers.add("usable_data")
    if _has_any(q, ["qc status", "qc_status", "warning", "warnings", "error", "errors", "accuracy report", "flagged issue", "flagged issues"]):
        modifiers.add("qc_status")
    if _has_any(q, ["benchmark", "baseline", "beat deet", "beats deet", "vs deet", "against deet", "better than deet", "vehicle baseline"]):
        modifiers.update(["benchmark", "baseline"])
    if _has_any(q, ["run date", "assay date", "processed date", "upload date", "uploaded", "processed on", "image date", "treatment date"]):
        modifiers.add("source_date_basis")
    if _has_any(q, ["in inventory", "have in inventory", "has stock", "in stock", "quantity", "storage", "stored", "sds", "vendor", "cas", "inchikey", "purity"]):
        modifiers.add("inventory_availability")
    if _has_any(q, ["tube count", "number of tubes", "how many tubes"]):
        modifiers.update(["assay_design", "tube_count"])
    if _has_any(q, ["insect count", "number of insects", "mosquitoes in a tube", "flies in a tube", "per tube", "n_insects"]):
        modifiers.update(["assay_design", "insect_count"])
    if _has_any(q, ["tube position", "tube number", "slot", "left side", "right side", "treatment side", "side bias"]) or re.search(r"\bposition\b", q):
        modifiers.update(["assay_design", "tube_position"])
    if _has_any(q, ["treatment_position", "treatment position", "treatment side"]):
        modifiers.add("treatment_side")
    if _has_any(q, ["starved", "unstarved", "fed", "can_feed", "can feed"]):
        modifiers.update(["assay_design", "starvation_state"])
    if re.search(r"\bage\b", q) or _has_any(q, ["life stage", "instar", "larva", "larvae", "adult", "sex"]):
        modifiers.update(["assay_design", "life_stage"])
    if _has_any(q, ["temperature", "temp ", " temp", "°c", " celsius"]):
        modifiers.update(["assay_design", "temperature"])
    if _has_any(q, ["humidity", "rh", "relative humidity"]):
        modifiers.update(["assay_design", "humidity"])
    if _has_any(q, ["solvent", "vehicle", "carrier", "oil base"]):
        modifiers.update(["assay_design", "solvent"])
    if _has_any(q, ["control type", "vehicle control", "solvent control", "control row", "controls"]):
        modifiers.update(["assay_design", "control_type"])
    if _has_any(q, ["dart pi", "avg_pi", "trt_pi", "preference index"]):
        modifiers.update(["metric_variant", "dart_pi"])
    if _has_any(q, ["contact pi", "mean_contact_pi"]):
        modifiers.update(["metric_variant", "contact_pi"])
    if _has_any(q, ["adjusted contact pi", "adj_contact_pi", "control-adjusted", "control adjusted"]):
        modifiers.update(["metric_variant", "adjusted_contact_pi"])
    if _has_any(q, ["strict contact pi", "strict pi"]):
        modifiers.update(["metric_variant", "strict_contact_pi"])
    if _has_any(q, ["zone occupancy", "zone time", "occupancy"]):
        modifiers.update(["metric_variant", "zone_occupancy"])
    if _has_any(q, ["entry rate", "exit rate", "crossing rate", "zone crossing", "zone crossings"]):
        modifiers.update(["metric_variant", "entry_exit_rate"])
    if _has_any(q, ["dwell", "dwell time"]):
        modifiers.update(["metric_variant", "dwell_time"])
    if _has_any(q, ["time point", "timepoint", "time bin", "time-bin", "time window", "within assay", "inside assay"]):
        modifiers.add("time_in_trial")
    if _has_any(q, ["latency", "response latency", "time to avoidance", "time-to-avoidance", "onset"]):
        modifiers.update(["metric_variant", "response_latency", "time_in_trial"])
    if _has_any(q, ["late effect", "late pi", "last half", "late window", "late adjusted"]):
        modifiers.update(["metric_variant", "late_effect", "time_in_trial"])
    if _has_any(q, ["early effect", "first half", "early window"]):
        modifiers.update(["metric_variant", "early_effect", "time_in_trial"])
    if _has_any(q, ["composite score", "composite"]):
        modifiers.update(["metric_variant", "composite_score"])
    if _has_any(q, ["spatial repellent", "spatial", "contact irritant", "irritant", "attractant", "toxicant", "knockdown", "locomotion", "mechanism"]):
        modifiers.add("mechanism_claim")
    if _has_any(q, ["damaged_fraction", "damaged fraction", "damage fraction"]):
        modifiers.update(["metric_variant", "damaged_fraction"])
    if _has_any(q, ["chlorosis", "chlorosis_fraction"]):
        modifiers.update(["metric_variant", "chlorosis_fraction", "phenotype"])
    if _has_any(q, ["browning", "browning_fraction"]):
        modifiers.update(["metric_variant", "browning_fraction", "phenotype"])
    if _has_any(q, ["necrosis", "necrosis_fraction"]):
        modifiers.update(["metric_variant", "necrosis_fraction", "phenotype"])
    if _has_any(q, ["leaf area", "area change", "growth", "shrinkage"]):
        modifiers.update(["metric_variant", "leaf_area_change"])
    if _has_any(q, ["segmentation quality", "mask quality", "bad mask", "leaf mask", "damage mask"]):
        modifiers.add("segmentation_quality")
    if _has_any(q, ["damage stage", "severity stage", "progression stage"]):
        modifiers.add("damage_stage")
    if _has_any(q, ["crop", "plant species", "leaf species"]):
        modifiers.add("plant_species")
    if _has_any(q, ["yellowing", "wilting", "spotting", "bleaching", "phenotype"]):
        modifiers.add("phenotype")
    if _has_any(q, ["comment", "comments", "note", "notes", "observation", "observations", "qualitative"]):
        modifiers.add("human_notes")
    if _has_any(q, ["molecular weight", " mw", "mw ", "smiles", "chemical family", "chemical class", "scaffold"]):
        modifiers.add("inventory_availability")
    if _has_any(q, ["molecular weight", " mw", "mw "]):
        modifiers.add("molecular_weight")
    if "smiles" in q:
        modifiers.add("smiles")
    if _has_any(q, ["chemical family", "chemical class", "scaffold"]):
        modifiers.add("chemical_family")
    if _has_any(q, ["detection", "segmentation", "tracking", "pose", "classification", "counting", "zone detection", "computer vision"]):
        modifiers.add("vision_task")
    if _has_any(q, ["yolo", "sam", "roboflow", "detector", "tracker", "classifier", "zone detector", "model family"]):
        modifiers.add("model_family")
    if _has_any(q, ["model version", "model file", "checkpoint", "best.pt", "run id", "retrain", "retrained"]):
        modifiers.add("model_version")
    if _has_any(q, ["training data", "training dataset", "train split", "labeled images", "training frames"]):
        modifiers.add("training_dataset")
    if _has_any(q, ["validation", "test set", "holdout", "evaluation split"]):
        modifiers.add("validation_dataset")
    if _has_any(q, ["bounding box", "bounding boxes", "oriented box", "oriented boxes", "mask", "masks", "keypoint", "keypoints", "labels", "labeled", "labelled"]):
        modifiers.add("label_type")
    if _has_any(q, ["precision", "recall", "map", "iou", "f1", "count error", "evaluation metric"]):
        modifiers.add("evaluation_metric")
    if _has_any(q, ["false positive", "false positives"]):
        modifiers.update(["evaluation_metric", "false_positive_rate"])
    if _has_any(q, ["false negative", "false negatives"]):
        modifiers.update(["evaluation_metric", "false_negative_rate"])
    if _has_any(q, ["occlusion", "overcrowding", "motion blur", "blur", "lighting", "low contrast", "bad zone", "track swap", "track swaps", "failure mode"]):
        modifiers.add("failure_mode")
    if _has_any(q, ["raw media", "frame extraction", "annotation", "inference", "metric computation", "overlay", "summary csv", "pipeline stage"]):
        modifiers.add("pipeline_stage")
    if _has_any(q, ["training config", "prediction csv", "accuracy report", "overlay image", "annotated video", "metrics file", "dataset manifest", "artifact"]):
        modifiers.add("artifact_type")
    if _has_any(q, ["before after", "before/after", "before retrain", "after retrain", "before marker", "after marker", "old pipeline", "new pipeline"]):
        modifiers.update(["before_after_pipeline_change", "method_change"])
    if _has_any(q, ["annotation coverage", "labeled frame", "labeled frames", "unlabeled"]):
        modifiers.add("annotation_coverage")
    if _has_any(q, ["confidence", "probability"]):
        modifiers.add("confidence")
    if _has_any(q, ["track continuity", "identity switch", "identity switches", "lost tracks", "tracking quality"]):
        modifiers.add("tracking_quality")
    if _has_any(q, ["pipeline version", "analysis version", "processing version"]):
        modifiers.add("pipeline_version")
    if _has_any(q, ["evidence strength", "robust", "robustness", "weight of evidence"]):
        modifiers.add("evidence_strength")
    if _has_any(q, ["confidence interval", "p-value", "p value", "significance", "standard deviation", "variance", "statistical"]):
        modifiers.add("statistical_confidence")
    if _has_any(q, ["reproducible", "reproducibility", "consistent", "consistency", "repeatability"]):
        modifiers.add("reproducibility")
    if _has_any(q, ["decision threshold", "threshold", "cutoff", "cut-off", "go/no-go", "go no go"]):
        modifiers.add("decision_threshold")
    if _has_any(q, ["advance", "kill", "prioritize", "deprioritize", "go/no-go", "go no go"]):
        modifiers.add("advance_or_kill")
    return sorted(modifiers)


def _adapter_modifier_contract(adapter):
    return _adapter_modifier_contracts().get(adapter, {})


def _modifier_contract_gap_for_adapter(question, source, adapter_payload):
    adapter = adapter_payload.get("adapter")
    if not adapter:
        return None
    contract = _adapter_modifier_contract(adapter)
    if not contract:
        return None
    detected = set(_detected_question_modifiers(question))
    supported = set(contract.get("supported_modifiers", []))
    must_not_ignore = set(contract.get("must_not_ignore_modifiers", []))
    unsupported = sorted((detected & must_not_ignore) - supported)
    if not unsupported:
        if detected:
            adapter_payload["modifier_trace"] = {
                "detected_modifiers": sorted(detected),
                "supported_modifiers": sorted(supported),
                "unsupported_modifiers": [],
            }
        return None
    return _source_gap_decision(
        intent=f"{adapter_payload.get('intent', adapter)}_unsupported_modifier",
        source=source,
        reason="structured adapter matched the question intent but cannot safely honor one or more binding modifiers",
        missing_adapter=f"{adapter}_modifier_support",
        answer_shape=adapter_payload.get("answer_shape"),
        selection_policy=adapter_payload.get("selection_policy"),
        detected_modifiers=sorted(detected),
        unsupported_modifiers=unsupported,
        adapter_modifier_contract=contract,
        message=(
            "Ask Monarch found the structured route, but refused to answer because the adapter "
            f"does not declare support for these binding modifiers: {', '.join(unsupported)}"
        ),
    )


def adapter_declared(source, adapter):
    if not adapter:
        return True
    source_config = _sources().get(source, {})
    return adapter in set(source_config.get("structured_adapters", []))


def _people_sql(question):
    q = question.lower()
    person_query = people_query_for_question(question)
    if person_query:
        return f"""
            SELECT lane, name, role, text, provenance_grain
            FROM units
            WHERE lower(name) = lower({sql_literal(person_query)})
            ORDER BY lane, name
        """
    if _has_any(q, ["advisor", "advisors", "advises", "advise"]):
        lane = "advisors"
    elif _has_any(q, ["partner", "partnership", "usda", "jana lee"]):
        lane = "partnerships"
    elif _has_any(q, ["co-founder", "cofounder", "co-founders", "cofounders", "founder", "founders"]):
        return """
            SELECT lane, name, role, text, provenance_grain
            FROM units
            WHERE lower(coalesce(role, '')) LIKE '%founder%'
            ORDER BY name
        """
    elif _has_any(q, ["who works", "employees", "employee", "team", "people", "lab tech", "cto", "roster"]):
        lane = "employees"
    else:
        return None
    return f"""
        SELECT lane, name, role, text, provenance_grain
        FROM units
        WHERE lane = {sql_literal(lane)}
        ORDER BY name
    """


def _company_profile_sql(question):
    q = question.lower()
    if _has_any(q, ["headquarters", "where", "based", "hq", "emeryville"]):
        unit_ids = ("headquarters",)
    elif _has_any(q, ["insect", "organism", "mosquito", "drosophila", "moth", "worm"]):
        unit_ids = ("insects",)
    elif _has_any(q, ["crop", "leaves", "berries"]):
        unit_ids = ("crop_testing",)
    elif _has_any(q, ["problem", "status quo", "neurotoxin", "insecticide"]):
        unit_ids = ("problem", "status_quo")
    elif _has_any(q, ["mission", "what does monarch do", "what is monarch", "approach", "why monarch"]):
        unit_ids = ("mission", "approach")
    else:
        return None
    placeholders = ", ".join(sql_literal(unit_id) for unit_id in unit_ids)
    return f"""
        SELECT unit_id, lane, title, text, provenance_grain
        FROM units
        WHERE unit_id IN ({placeholders})
        ORDER BY unit_id
    """


def _compound_inventory_sql(question):
    q = question.lower()
    if not _has_any(q, ["how many compounds", "what compounds", "which compounds", "list compounds", "compound list", "inventory list"]):
        return None
    return """
        WITH compounds AS (
          SELECT
            trim(value) AS compound_name,
            provenance_grain
          FROM cells
          WHERE sheet_name = 'Master'
            AND cell LIKE 'D%'
            AND row_number >= 2
            AND trim(coalesce(value, '')) <> ''
        )
        SELECT
          (SELECT count(*) FROM compounds) AS compound_count,
          (SELECT group_concat(compound_name, ', ')
             FROM (SELECT compound_name FROM compounds ORDER BY compound_name LIMIT 50)
          ) AS first_50_compounds,
          (SELECT provenance_grain FROM compounds ORDER BY compound_name LIMIT 1) AS provenance_grain
    """


def _compound_inventory_all_names_applies(question):
    q = question.lower()
    asks_for_names = _has_any(q, ["compound", "compounds", "chemical", "chemicals"])
    names_inventory = _has_any(q, ["inventory", "chemical library", "compound library", "stock"])
    asks_exhaustive = _has_any(q, ["all", "complete", "entire", "every", "full"])
    asks_listing = _has_any(q, ["list", "show", "what", "which"])
    return asks_for_names and names_inventory and asks_exhaustive and asks_listing


def _compound_inventory_all_names_sql():
    return """
        WITH row_inventory AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'A%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS vendor,
            max(CASE WHEN cell LIKE 'B%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS catalog_number,
            max(CASE WHEN cell LIKE 'C%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS location,
            max(CASE WHEN cell LIKE 'D%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS compound_name,
            max(CASE WHEN cell LIKE 'E%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS inchikey,
            max(CASE WHEN cell LIKE 'F%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS synonyms,
            max(CASE WHEN cell LIKE 'G%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS quantity,
            max(CASE WHEN cell LIKE 'H%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS cas,
            max(CASE WHEN cell LIKE 'I%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS purity,
            max(CASE WHEN cell LIKE 'J%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS link,
            max(CASE WHEN cell LIKE 'K%' THEN trim(value, char(9) || char(10) || char(13) || ' ') END) AS sds,
            max(CASE WHEN cell LIKE 'D%' THEN provenance_grain END) AS provenance_grain
          FROM cells
          WHERE sheet_name = 'Master'
            AND row_number >= 2
          GROUP BY row_number
        )
        SELECT
          count(*) OVER () AS compound_count,
          row_number,
          vendor,
          catalog_number,
          location,
          compound_name,
          inchikey,
          synonyms,
          quantity,
          cas,
          purity,
          link,
          sds,
          provenance_grain
        FROM row_inventory
        WHERE trim(coalesce(compound_name, ''), char(9) || char(10) || char(13) || ' ') <> ''
        ORDER BY row_number
    """


def _compound_inventory_summary_sql():
    return """
        WITH inventory_summary AS (
          SELECT
            0 AS sort_order,
            'workbook' AS inventory_scope,
            workbook_path AS label,
            NULL AS sheet_name,
            NULL AS row_count,
            NULL AS cell_count,
            modified_time,
            provenance_grain
          FROM workbook
          UNION ALL
          SELECT
            1 + sheet_index AS sort_order,
            'sheet' AS inventory_scope,
            sheet_name AS label,
            sheet_name,
            row_count,
            cell_count,
            NULL AS modified_time,
            provenance_grain
          FROM sheets
        )
        SELECT
          inventory_scope,
          label,
          sheet_name,
          row_count,
          cell_count,
          modified_time,
          provenance_grain
        FROM inventory_summary
        ORDER BY sort_order
    """


def _compound_inventory_master_lookup_applies(question):
    q = question.lower()
    return _has_any(q, [
        "cas",
        "do we have",
        "location",
        "quantity",
        "safety data sheet",
        "sds",
        "stock",
        "store",
        "stored",
        "storage",
        "supplier",
        "vendor",
        "where do we store",
        "where is",
    ])


def _dart_best_concentration_helper_applies(question):
    q = question.lower()
    return (
        "dart" in q
        and " for " in q
        and _has_any(q, ["concentration", "dilution"])
        and _has_any(q, ["best", "effective", "most"])
    )


def _extract_dart_treatment(question):
    text = re.sub(r"\s+", " ", str(question)).strip().strip("?")
    alias_map = {
        "2-propylphenol": "2PP",
        "2 propylphenol": "2PP",
        "2pp": "2PP",
        "deet": "DEET",
        "ir3535": "IR3535",
    }
    lowered = text.lower()
    for phrase, normalized in alias_map.items():
        if phrase in lowered:
            return normalized
    patterns = [
        r"dart data .*?\bfor\s+(.+?)(?:\s+in\s+(?:mosquitoes|flies|beetles|moths|drosophila))?$",
        r"for\s+(.+?),\s+what\s+dart\b",
        r"assay evidence exists for\s+(.+?)$",
        r"assay-program evidence for\s+(.+?)\s+and\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return match.group(1).strip(" ,?.")
    return None


def _extract_fly_media_treatment(question):
    text = re.sub(r"\s+", " ", str(question)).strip().strip("?")
    alias_map = {
        "2-propylphenol": "2PP",
        "2 propylphenol": "2PP",
        "2pp": "2PP",
        "deet": "DEET",
    }
    lowered = text.lower()
    for phrase, normalized in alias_map.items():
        if phrase in lowered:
            return normalized
    stopwords = {
        "show",
        "pull",
        "video",
        "videos",
        "media",
        "movie",
        "recording",
        "fly",
        "flies",
        "swd",
        "for",
        "the",
        "top",
        "repellent",
        "repellents",
    }
    for token in re.findall(r"\b[A-Za-z0-9]{3,16}\b", text):
        if token.lower() in stopwords:
            continue
        if any(ch.isdigit() for ch in token) or token.isupper():
            return token
    return None


def species_from_question(question):
    q = question.lower()
    if "mosquito" in q:
        return "mosquitoes"
    if "swd" in q or "flies" in q or "fly" in q:
        return "flies"
    if "beetle" in q:
        return "beetles"
    if "diamondback" in q or "diamond back" in q or "dbm" in q or "plutella" in q or "moth" in q:
        return "moths"
    if "drosophila" in q:
        return "drosophila"
    return None


def _relative_date_filter_sql(question, column):
    q = question.lower()
    if "today" in q:
        return f"date({column}) = date('now')", "today"
    if "yesterday" in q:
        return f"date({column}) = date('now', '-1 day')", "yesterday"
    if "last friday" in q:
        return f"date({column}) = date('now', 'weekday 5', '-7 days')", "last_friday"
    if "last week" in q:
        return (
            f"date({column}) >= date('now', 'weekday 1', '-14 days') "
            f"AND date({column}) < date('now', 'weekday 1', '-7 days')",
            "last_week",
        )
    if "this week" in q:
        return f"date({column}) >= date('now', 'weekday 1', '-7 days')", "this_week"
    if _has_any(q, ["new", "recent"]):
        return f"date({column}) >= date('now', '-14 days')", "recent_14_days"
    return f"date({column}) >= date('now', '-60 days')", "recent_60_days"


def _has_meeting_date_reference(question):
    q = str(question).lower()
    if _has_any(q, ["today", "yesterday", "last friday", "last week", "this week", "latest", "recent"]):
        return True
    if re.search(r"\b(?:last|this)\s+(monday|tuesday|wednesday|thursday|friday)\b", q):
        return True
    if re.search(r"\b\d{4}-\d{2}-\d{2}\b", q):
        return True
    return bool(
        re.search(
            r"\b(jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)\s+\d{1,2}\b",
            q,
        )
    )


def _is_teams_meeting_context(question):
    q = str(question).lower()
    return _has_any(q, ["team", "r&d", "rd", "meeting", "meetings", "recap", "sync", "we"])


def _is_teams_secondary_text_request(question):
    q = str(question).lower()
    if _is_teams_discussion_digest_question(question):
        return True
    return _has_meeting_commentary_request(question)


def _is_teams_discussion_digest_question(question):
    q = str(question).lower()
    if not _has_meeting_date_reference(question):
        return False
    if not _is_teams_meeting_context(question):
        return False
    return _has_any(
        q,
        [
            "discuss",
            "discussed",
            "cover",
            "covered",
            "digest",
            "recap",
            "summary",
            "summarize",
            "talk about",
            "talked about",
            "went over",
            "go over",
        ],
    )


def _compact_assay_date_iso_sql(column):
    return f"""
        CASE
          WHEN length(trim({column})) = 7 THEN
            substr(trim({column}), 4, 4) || '-0' || substr(trim({column}), 1, 1) || '-' || substr(trim({column}), 2, 2)
          WHEN length(trim({column})) = 8 THEN
            substr(trim({column}), 5, 4) || '-' || substr(trim({column}), 1, 2) || '-' || substr(trim({column}), 3, 2)
          ELSE date({column})
        END
    """


def _local_today():
    if ZoneInfo is not None:
        return datetime.now(ZoneInfo(DEFAULT_QUERY_TIMEZONE)).date()
    return datetime.now().date()


def _date_filter_details(filter_sql, date_window, **parameters):
    details = {
        "filter_sql": filter_sql,
        "date_window": date_window,
        "parameters": {
            "date_field": "assay_date",
            "normalized_date_field": "assay_date_iso",
            "applied_filter": filter_sql,
        },
    }
    details["parameters"].update({key: value for key, value in parameters.items() if value is not None})
    return details


def _extract_explicit_iso_date(question):
    match = re.search(r"\b(20\d{2}-\d{2}-\d{2})\b", question.lower())
    if match:
        return match.group(1)
    return None


def _assay_ledger_date_filter_details(question, iso_column):
    q = question.lower()
    explicit_iso = _extract_explicit_iso_date(question)
    if explicit_iso:
        filter_sql = f"date({iso_column}) = date({sql_literal(explicit_iso)})"
        return _date_filter_details(
            filter_sql,
            explicit_iso,
            interpreted_date=explicit_iso,
            date_source="user_explicit",
        )

    today = _local_today()
    match = re.search(r"\b(?:last|past)\s+(\d+|one|two|couple)\s+(day|days|week|weeks|month|months)\b", q)
    if match:
        raw_count = match.group(1)
        if raw_count == "one":
            count = 1
        elif raw_count in {"two", "couple"}:
            count = 2
        else:
            count = int(raw_count)
        unit = match.group(2)
        if unit.startswith("month"):
            days = count * 30
            window_unit = "month" if count == 1 else "months"
        elif unit.startswith("week"):
            days = count * 7
            window_unit = "week" if count == 1 else "weeks"
        else:
            days = count
            window_unit = "day" if count == 1 else "days"
        start_date = today - timedelta(days=days)
        filter_sql = (
            f"date({iso_column}) >= date({sql_literal(start_date.isoformat())}) "
            f"AND date({iso_column}) <= date({sql_literal(today.isoformat())})"
        )
        return _date_filter_details(
            filter_sql,
            f"last_{count}_{window_unit}",
            relative_date=f"last_{count}_{window_unit}",
            interpreted_start_date=start_date.isoformat(),
            interpreted_end_date=today.isoformat(),
            date_source="relative_date",
        )
    if "today" in q:
        filter_sql = f"date({iso_column}) = date({sql_literal(today.isoformat())})"
        return _date_filter_details(
            filter_sql,
            today.isoformat(),
            relative_date="today",
            interpreted_date=today.isoformat(),
            date_source="relative_date",
        )
    if "yesterday" in q:
        target_date = today - timedelta(days=1)
        filter_sql = f"date({iso_column}) = date({sql_literal(target_date.isoformat())})"
        return _date_filter_details(
            filter_sql,
            target_date.isoformat(),
            relative_date="yesterday",
            interpreted_date=target_date.isoformat(),
            date_source="relative_date",
        )
    if "last week" in q:
        current_monday = today - timedelta(days=today.weekday())
        start_date = current_monday - timedelta(days=7)
        end_date = current_monday
        filter_sql = (
            f"date({iso_column}) >= date({sql_literal(start_date.isoformat())}) "
            f"AND date({iso_column}) < date({sql_literal(end_date.isoformat())})"
        )
        return _date_filter_details(
            filter_sql,
            "last_week",
            relative_date="last_week",
            interpreted_start_date=start_date.isoformat(),
            interpreted_end_date=(end_date - timedelta(days=1)).isoformat(),
            date_source="relative_date",
        )
    if "this week" in q:
        start_date = today - timedelta(days=today.weekday())
        filter_sql = f"date({iso_column}) >= date({sql_literal(start_date.isoformat())})"
        return _date_filter_details(
            filter_sql,
            "this_week",
            relative_date="this_week",
            interpreted_start_date=start_date.isoformat(),
            interpreted_end_date=today.isoformat(),
            date_source="relative_date",
        )
    if _has_any(q, ["new", "recent", "lately"]):
        start_date = today - timedelta(days=14)
        filter_sql = f"date({iso_column}) >= date({sql_literal(start_date.isoformat())})"
        return _date_filter_details(
            filter_sql,
            "recent_14_days",
            relative_date="recent_14_days",
            interpreted_start_date=start_date.isoformat(),
            interpreted_end_date=today.isoformat(),
            date_source="default_recent",
        )
    start_date = today - timedelta(days=60)
    filter_sql = f"date({iso_column}) >= date({sql_literal(start_date.isoformat())})"
    return _date_filter_details(
        filter_sql,
        "recent_60_days",
        relative_date="recent_60_days",
        interpreted_start_date=start_date.isoformat(),
        interpreted_end_date=today.isoformat(),
        date_source="default_recent",
    )


def _assay_ledger_date_filter_sql(question, iso_column):
    details = _assay_ledger_date_filter_details(question, iso_column)
    return details["filter_sql"], details["date_window"]


def _question_has_date_modifier(question):
    q = str(question).lower()
    if _extract_explicit_iso_date(q):
        return True
    if _has_any(q, ["today", "yesterday", "last week", "this week", "recent", "recently", "lately"]):
        return True
    return bool(re.search(r"\b(?:last|past)\s+(\d+|one|two|couple)\s+(day|days|week|weeks|month|months)\b", q))


def _optional_assay_date_filter_details(question, iso_column):
    if _question_has_date_modifier(question):
        return _assay_ledger_date_filter_details(question, iso_column)
    return _date_filter_details(
        "1 = 1",
        "all_time",
        date_source="none",
        interpreted_start_date=None,
        interpreted_end_date=None,
    )


def _serving_table_assay_family_scope(question):
    q = str(question).lower()
    families = []
    if "dart" in q:
        families.append("DART")
    if _has_any(q, ["contact/no-contact", "contact / no contact", "contact and no contact", "contact and non-contact", "noncontact", "non-contact", "non contact", "no-contact", "no contact"]):
        families.append("contact_no_contact")
    if _has_any(q, PHYTOTOX_TERMS + ["plant", "plants", "soybean", "leaf", "leaves"]):
        families.append("phytotoxicity")
    if _has_any(q, ["oviposition", "egg laying", "egg-laying"]):
        families.append("fly_oviposition")
        families.append("moth_oviposition")
    if species_from_question(question) == "plants":
        families.append("phytotoxicity")
    return sorted(set(families))


def _serving_table_assay_mode_scope(question):
    q = str(question).lower()
    modes = []
    if _has_any(q, ["noncontact", "non-contact", "non contact", "no-contact", "no contact"]):
        modes.append("non_contact")
    if "contact" in q and not _has_any(q, ["noncontact", "non-contact", "non contact", "no-contact", "no contact"]):
        modes.append("contact")
    if _has_any(q, ["contact/no-contact", "contact / no contact", "contact and no contact", "contact and non-contact"]):
        modes.extend(["contact", "non_contact"])
    return sorted(set(modes))


def _serving_table_metric_scope(question):
    q = str(question).lower()
    if _has_any(q, ["chlorosis", "chlorosis_fraction"]):
        return ["chlorosis_fraction"]
    if _has_any(q, ["browning", "browning_fraction"]):
        return ["browning_fraction"]
    if _has_any(q, ["necrosis", "necrosis_fraction"]):
        return ["necrosis_fraction"]
    if _has_any(q, ["healthy green", "healthy_green_fraction"]):
        return ["healthy_green_fraction"]
    if _has_any(q, ["damaged", "damage", "damaged_fraction", "damaged fraction"] + PHYTOTOX_TERMS):
        return ["damaged_fraction"]
    if _has_any(q, ["adjusted contact pi", "adj_contact_pi", "control-adjusted", "control adjusted"]):
        return ["adj_contact_pi_mean"]
    if _has_any(q, ["contact pi", "mean_contact_pi"]):
        return ["mean_contact_pi", "adj_contact_pi_mean"]
    if _has_any(q, ["composite", "composite score"]):
        return ["composite_score"]
    if _has_any(q, ["dart pi", "avg_pi", "preference index"]):
        return ["avg_pi", "trt_pi", "trt_pi_grand_mean"]
    if _has_any(q, ["repellent", "repellents", "repellency", "effective", "promising"]):
        return ["composite_score", "avg_pi", "trt_pi", "trt_pi_grand_mean", "adj_contact_pi_mean", "mean_contact_pi"]
    return []


def _serving_table_filters(question, table_alias, *, date_column=None, include_metric=False):
    filters = []
    species_scope = _assay_species_constraints_from_question(question)
    if len(species_scope) > 1:
        filters.append(f"{table_alias}.species IN (" + ", ".join(sql_literal(species) for species in species_scope) + ")")
    else:
        species = species_from_question(question)
        if species:
            filters.append(f"{table_alias}.species = {sql_literal(species)}")
    families = _serving_table_assay_family_scope(question)
    if families:
        filters.append(f"{table_alias}.assay_family IN (" + ", ".join(sql_literal(family) for family in families) + ")")
    modes = _serving_table_assay_mode_scope(question)
    if modes:
        filters.append(f"{table_alias}.assay_mode IN (" + ", ".join(sql_literal(mode) for mode in modes) + ")")
    if include_metric:
        metrics = _serving_table_metric_scope(question)
        if metrics:
            filters.append(f"{table_alias}.metric_name IN (" + ", ".join(sql_literal(metric) for metric in metrics) + ")")
    q = str(question).lower()
    if table_alias == "r" and _has_any(q, ["usable", "usable only", "only usable", "qc-passed", "qc passed"]):
        filters.append(f"coalesce({table_alias}.usable_data, '1') != '0'")
    if table_alias == "r" and _has_any(q, ["unusable", "failed", "exclude usable"]):
        filters.append(f"coalesce({table_alias}.usable_data, '1') = '0'")
    if date_column:
        date_details = _optional_assay_date_filter_details(question, date_column)
        filters.append(date_details["filter_sql"])
    return filters


def _serving_table_where(filters):
    return "WHERE " + "\n            AND ".join(filters) if filters else ""


def _bucket_assay_serving_table_sql(question):
    answer_shape = _answer_shape_for_question(question)
    if answer_shape in {
        "assay_summary_file_explanation",
        "metric_definition",
        "rank_expectation_explanation",
        "individual_assay_timepoint_ranking",
        "dart_individual_assay_timepoint_ranking",
        "ranked_repellents_with_media",
    }:
        return None
    q = str(question).lower()
    if not _has_any(q, BUCKET_STRUCTURED_TABLE_TERMS + PHYTOTOX_TERMS + ["run", "ran", "screened"]):
        return None
    detected_modifiers = set(_detected_question_modifiers(question))
    if answer_shape in {
        "ranked_cross_assay_repellent_compounds",
        "ranked_fly_repellent_compounds",
        "ranked_species_repellent_compounds",
        "ranked_repellent_compounds",
        "contact_noncontact_ranked_comparison",
        "ranked_phytotoxicity_compounds",
        "ranked_phytotoxicity_compounds_with_assay_species_constraint",
    } and detected_modifiers & {
        "evidence_strength",
        "mechanism_claim",
        "minimum_replicates",
        "recency_order",
        "replicate_strength",
        "statistical_confidence",
        "time_in_trial",
    }:
        return None

    if answer_shape in {"assay_run_list", "assay_inventory_count", "fly_assay_count"}:
        date_details = _optional_assay_date_filter_details(question, "r.run_date")
        date_window = date_details["date_window"]
        filters = _serving_table_filters(question, "r", date_column="r.run_date")
        count_unit = "serving_table_assay_runs"
        if "result_requirement" in detected_modifiers:
            filters.append("EXISTS (SELECT 1 FROM assay_results ar WHERE ar.run_id = r.run_id)")
            count_unit = "processed_result_rows"
        if _has_any(q, ["raw video", "raw videos", "raw media", "per video", "video objects"]):
            filters.append("EXISTS (SELECT 1 FROM media_links ml WHERE ml.run_id = r.run_id)")
            count_unit = "raw_video_objects"
        where = _serving_table_where(filters)
        order_by = "r.run_date DESC, r.source_name, r.row_number" if _has_recency_order_modifier(question) else "r.run_date, r.species, r.assay_family, r.source_name, r.row_number"
        if answer_shape == "assay_inventory_count" or _has_count_request(question):
            if "pairing_requirement" in detected_modifiers:
                return f"""
                    WITH filtered_runs AS (
                      SELECT
                        r.*,
                        lower(trim(coalesce(r.treatment_normalized, r.treatment, r.filename, r.source_name))) AS pair_key
                      FROM assay_runs r
                      {where}
                        AND r.assay_family = 'contact_no_contact'
                        AND r.assay_mode IN ('contact', 'non_contact')
                    ),
                    complete_pairs AS (
                      SELECT
                        species,
                        assay_family,
                        pair_key,
                        min(run_date) AS first_assay_date,
                        max(run_date) AS latest_assay_date,
                        count(DISTINCT assay_mode) AS modes_present,
                        count(*) AS paired_rows,
                        count(DISTINCT filename) AS file_count,
                        group_concat(DISTINCT coalesce(treatment_normalized, treatment)) AS treatments,
                        min(source_name) AS example_source_name,
                        min(row_number) AS first_row_number,
                        min(provenance_grain) AS provenance_grain
                      FROM filtered_runs
                      GROUP BY species, assay_family, pair_key
                      HAVING modes_present = 2
                    )
                    SELECT
                      species,
                      assay_family,
                      'contact_and_non_contact' AS assay_mode,
                      {sql_literal(date_window)} AS date_window,
                      'assay_runs.run_date' AS date_basis,
                      'complete_contact_non_contact_pairs' AS count_unit,
                      count(*) AS assay_rows,
                      count(*) AS assay_count,
                      count(*) AS run_count,
                      sum(file_count) AS file_count,
                      count(*) AS treatment_count,
                      substr(group_concat(DISTINCT treatments), 1, 1000) AS treatments,
                      min(first_assay_date) AS first_assay_date,
                      max(latest_assay_date) AS latest_assay_date,
                      min(example_source_name) AS example_source_name,
                      min(first_row_number) AS first_row_number,
                      'assay_runs' AS source_table,
                      min(provenance_grain) AS provenance_grain
                    FROM complete_pairs
                    GROUP BY species, assay_family
                    ORDER BY species, assay_family
                """
            return f"""
                SELECT
                  r.species,
                  r.assay_family,
                  r.assay_type,
                  r.assay_mode,
                  {sql_literal(date_window)} AS date_window,
                  'assay_runs.run_date' AS date_basis,
                  {sql_literal(count_unit)} AS count_unit,
                  count(*) AS assay_rows,
                  count(*) AS assay_count,
                  count(DISTINCT r.run_id) AS run_count,
                  count(DISTINCT r.filename) AS file_count,
                  count(DISTINCT coalesce(r.treatment_normalized, r.treatment)) AS treatment_count,
                  substr(group_concat(DISTINCT coalesce(r.treatment_normalized, r.treatment)), 1, 1000) AS treatments,
                  min(r.run_date) AS first_assay_date,
                  max(r.run_date) AS latest_assay_date,
                  min(r.source_name) AS example_source_name,
                  min(r.row_number) AS first_row_number,
                  'assay_runs' AS source_table,
                  min(r.provenance_grain) AS provenance_grain
                FROM assay_runs r
                {where}
                GROUP BY r.species, r.assay_family, r.assay_type, r.assay_mode
                ORDER BY r.species, r.assay_family, r.assay_mode
            """
        return f"""
            SELECT
              r.run_date AS assay_date_iso,
              r.species,
              r.assay_family,
              r.assay_type,
              r.assay_mode,
              r.filename,
              r.tube,
              r.treatment,
              r.treatment_normalized,
              r.dilution,
              r.temp,
              r.rh,
              r.usable_data,
              r.source_gap_reason,
              r.source_name,
              r.row_number AS source_row_number,
              json_extract(r.provenance_grain, '$.locator') AS locator,
              r.provenance_grain
            FROM assay_runs r
            {where}
            ORDER BY {order_by}
        """

    if answer_shape in {"tested_compound_date_window", "tested_compound_list"} or _bucket_compounds_tested_by_date_window_applies(question):
        date_details = _optional_assay_date_filter_details(question, "e.test_date")
        date_window = date_details["date_window"]
        filters = _serving_table_filters(question, "e", date_column="e.test_date")
        where = _serving_table_where(filters)
        return f"""
            SELECT
              e.compound AS tested_compound,
              e.species,
              e.assay_family,
              e.assay_mode,
              {sql_literal(date_window)} AS date_window,
              'compound_test_events.test_date' AS date_basis,
              min(e.test_date) AS first_test_date,
              max(e.test_date) AS latest_test_date,
              count(*) AS evidence_rows,
              count(DISTINCT e.run_id) AS run_count,
              group_concat(DISTINCT e.dilution) AS dilutions,
              min(e.source_name) AS example_source_name,
              min(e.row_number) AS example_row_number,
              'compound_test_events' AS source_table,
              min(e.provenance_grain) AS provenance_grain
            FROM compound_test_events e
            {where}
            GROUP BY lower(trim(e.compound)), e.species, e.assay_family, e.assay_mode
            ORDER BY latest_test_date DESC, tested_compound COLLATE NOCASE
        """

    if answer_shape in {
        "ranked_cross_assay_repellent_compounds",
        "ranked_fly_repellent_compounds",
        "ranked_species_repellent_compounds",
        "ranked_repellent_compounds",
        "contact_noncontact_ranked_comparison",
        "ranked_phytotoxicity_compounds",
        "assay_best_result_environment_conditions",
    }:
        date_details = _optional_assay_date_filter_details(question, "coalesce(a.run_date, r.timepoint)")
        date_window = date_details["date_window"]
        filters = _serving_table_filters(question, "r", include_metric=True)
        filters.append("coalesce(r.usable_data, '1') != '0'")
        if _question_has_date_modifier(question):
            filters.append(date_details["filter_sql"])
        if answer_shape == "ranked_phytotoxicity_compounds":
            filters.append("r.assay_family = 'phytotoxicity'")
            if not _serving_table_metric_scope(question):
                filters.append("r.metric_name = 'damaged_fraction'")
        if answer_shape == "contact_noncontact_ranked_comparison":
            filters.append("r.assay_family = 'contact_no_contact'")
            filters.append("r.assay_mode IN ('contact', 'non_contact')")
            prefer_adjusted_contact_metric = not _has_any(q, ["mean_contact_pi", "mean contact pi", "strict contact pi"])
            if prefer_adjusted_contact_metric:
                filters.append("r.metric_name IN ('adj_contact_pi_mean', 'mean_contact_pi')")
            elif not _serving_table_metric_scope(question):
                filters.append("r.metric_name IN ('adj_contact_pi_mean', 'mean_contact_pi')")
        if answer_shape == "ranked_fly_repellent_compounds":
            filters.append("r.species = 'flies'")
        if answer_shape == "ranked_species_repellent_compounds":
            filters.append("r.assay_family = 'DART'")
        where = _serving_table_where(filters)
        rank_partition = "species, assay_family, assay_mode" if answer_shape == "contact_noncontact_ranked_comparison" else "species, assay_family"
        if answer_shape == "contact_noncontact_ranked_comparison" and prefer_adjusted_contact_metric:
            preferred_metric_filter = """
              f.metric_name = 'adj_contact_pi_mean'
              OR NOT EXISTS (
                SELECT 1
                FROM filtered f2
                WHERE f2.species = f.species
                  AND f2.assay_family = f.assay_family
                  AND f2.assay_mode = f.assay_mode
                  AND f2.metric_name = 'adj_contact_pi_mean'
              )
            """
        else:
            preferred_metric_filter = "1 = 1"
        return f"""
            WITH filtered AS (
              SELECT
                r.*,
                a.run_date,
                a.temp,
                a.rh,
                a.source_gap_reason,
                a.filename,
                a.tube
              FROM assay_results r
              LEFT JOIN assay_runs a ON a.run_id = r.run_id
              {where}
            ),
            preferred AS (
              SELECT *
              FROM filtered f
              WHERE {preferred_metric_filter}
            ),
            aggregated AS (
              SELECT
                species,
                assay_family,
                assay_mode,
                coalesce(compound, treatment_normalized, treatment) AS compound,
                metric_name,
                {sql_literal(date_window)} AS date_window,
                'assay_runs.run_date_or_result_timepoint' AS date_basis,
                avg(metric_value) AS metric_value,
                avg(ranking_score) AS ranking_score,
                count(*) AS evidence_rows,
                min(run_date) AS first_assay_date,
                max(run_date) AS latest_assay_date,
                min(timepoint) AS first_timepoint,
                max(timepoint) AS latest_timepoint,
                min(temp) AS temp,
                min(rh) AS rh,
                min(source_gap_reason) AS source_gap_reason,
                min(source_name) AS example_source_name,
                min(row_number) AS example_row_number,
                min(provenance_grain) AS example_provenance_grain
              FROM preferred
              WHERE coalesce(compound, treatment_normalized, treatment) IS NOT NULL
              GROUP BY species, assay_family, assay_mode, lower(trim(coalesce(compound, treatment_normalized, treatment))), metric_name
            ),
            ranked AS (
              SELECT
                row_number() OVER (
                  PARTITION BY {rank_partition}
                  ORDER BY ranking_score DESC, evidence_rows DESC, compound COLLATE NOCASE
                ) AS rank,
                *
              FROM aggregated
            )
            SELECT
              rank,
              species,
              assay_family,
              assay_mode,
              compound,
              metric_name,
              round(metric_value, 6) AS metric_value,
              round(ranking_score, 6) AS ranking_score,
              'source_gap: serving table does not yet carry replicate-level standard deviation' AS standard_deviation_status,
              evidence_rows,
              date_window,
              date_basis,
              first_assay_date,
              latest_assay_date,
              first_timepoint,
              latest_timepoint,
              temp,
              rh,
              source_gap_reason,
              example_source_name,
              example_row_number,
              example_provenance_grain AS provenance_grain
            FROM ranked
            WHERE rank <= 10
            ORDER BY species, assay_family, assay_mode, rank
        """

    return None


def _teams_meeting_digest_sql(question):
    q = question.lower()
    if not _is_teams_discussion_digest_question(question):
        return None
    title_filter = _teams_meeting_title_filter(question, "m")
    if "latest" in q or "recent" in q:
        subquery_title_filter = _teams_meeting_title_filter(question, "m2")
        meeting_filter = f"m.meeting_date = (SELECT max(m2.meeting_date) FROM meetings m2 WHERE {subquery_title_filter})"
        date_window = "latest"
    else:
        meeting_filter, date_window = _relative_date_filter_sql(question, "m.meeting_date")
    return f"""
        WITH target_meetings AS (
          SELECT *
          FROM meetings m
          WHERE {meeting_filter}
            AND {title_filter}
        )
        SELECT
          m.meeting_date,
          m.title,
          {sql_literal(date_window)} AS date_window,
          m.start_datetime,
          m.end_datetime,
          m.organizer,
          m.web_link,
          m.utterance_count,
          (
            SELECT group_concat(coalesce(u.speaker, 'Unknown') || ': ' || u.text, char(10))
            FROM utterances u
            WHERE u.meeting_id = m.id
              AND u.cue_index IN (
                SELECT cue_index
                FROM utterances
                WHERE meeting_id = m.id
                ORDER BY cue_index
                LIMIT 40
              )
          ) AS digest_source_excerpt,
          m.provenance_grain
        FROM target_meetings m
        ORDER BY m.meeting_date DESC, m.start_datetime DESC
    """


def _teams_meeting_title_filter(question, alias="m"):
    q = question.lower()
    column = f"lower({alias}.title)"
    if _has_any(q, ["r&d", "r and d", "rd meeting", "r d meeting"]):
        return f"{column} LIKE '%r&d%'"
    if "weekly" in q:
        return f"{column} LIKE '%weekly%'"
    if _has_any(q, ["team sync", "daily sync", "daily meeting", "sync meeting"]):
        return f"{column} LIKE '%team sync%'"
    return "1 = 1"


def _teams_utterance_lookup_sql(question):
    q = question.lower()
    if not _has_any(q, ["speaker", "speakers", "utterance", "utterances"]):
        return None
    if "friday" in q and "last friday" not in q:
        meeting_filter, date_window = "date(m.meeting_date) = date('now', 'weekday 5', '-7 days')", "last_friday"
    else:
        meeting_filter, date_window = _relative_date_filter_sql(question, "m.meeting_date")

    ignored_terms = {
        "friday",
        "last",
        "latest",
        "meeting",
        "meetings",
        "mentioned",
        "morning",
        "recap",
        "recaps",
        "speaker",
        "speakers",
        "team",
        "teams",
        "utterance",
        "utterances",
        "yesterday",
    }
    terms = []
    for token in anchor_tokens(question):
        if token in ignored_terms or token in terms:
            continue
        terms.append(token)
    term_filter = ""
    if terms:
        like_clauses = []
        for term in terms[:6]:
            literal = sql_literal(f"%{term}%")
            like_clauses.append(f"lower(u.text) LIKE {literal}")
            like_clauses.append(f"lower(coalesce(u.speaker, '')) LIKE {literal}")
            like_clauses.append(f"lower(m.title) LIKE {literal}")
        term_filter = "AND (" + " OR ".join(like_clauses) + ")"

    return f"""
        SELECT
          m.meeting_date,
          m.title,
          {sql_literal(date_window)} AS date_window,
          u.speaker,
          u.cue_index,
          u.start_time,
          u.text,
          u.provenance_grain
        FROM meetings m
        JOIN utterances u ON u.meeting_id = m.id
        WHERE {meeting_filter}
          {term_filter}
        ORDER BY m.meeting_date DESC, m.start_datetime DESC, u.cue_index
    """


def _teams_topic_speaker_rollup_sql(question):
    q = question.lower()
    if not _has_any(q, ["speaker", "speakers", "team", "discussed", "talked", "said", "say"]):
        return None
    if not _has_any(q, ["assay", "assays", "flies", "fly", "phytotoxicity", "docking", "mosquito", "mosquitoes", "video", "model", "models"]):
        return None
    ignored = {"which", "what", "speaker", "speakers", "team", "discussed", "talked", "said", "say", "about"}
    terms = [token for token in anchor_tokens(question) if token not in ignored]
    if not terms:
        return None
    term_clauses = " OR ".join(f"lower(u.text) LIKE {sql_literal('%' + term + '%')}" for term in terms[:8])
    date_filter = ""
    if _has_meeting_date_reference(question):
        meeting_filter, date_window = _relative_date_filter_sql(question, "m.meeting_date")
        date_filter = f"AND {meeting_filter}"
    else:
        date_window = "all_meetings"
    return f"""
        WITH matching AS (
          SELECT
            m.meeting_date,
            m.title,
            u.speaker,
            u.cue_index,
            u.text,
            u.provenance_grain
          FROM meetings m
          JOIN utterances u ON u.meeting_id = m.id
          WHERE ({term_clauses})
            {date_filter}
        )
        SELECT
          meeting_date,
          title,
          {sql_literal(date_window)} AS date_window,
          speaker,
          count(*) AS utterance_count,
          min(cue_index) AS first_cue_index,
          group_concat(substr(text, 1, 220), char(10)) AS representative_text,
          min(provenance_grain) AS provenance_grain
        FROM matching
        GROUP BY meeting_date, title, speaker
        ORDER BY meeting_date DESC, utterance_count DESC, speaker
    """


def _teams_meeting_anchor_sql(question):
    q = question.lower()
    if not _has_any(q, ["r&d meeting", "rd meeting", "meeting"]):
        return None
    if not _has_any(q, ["today", "yesterday", "last friday", "last week", "this week", "latest", "recent"]):
        return None
    title_filter = _teams_meeting_title_filter(question, "m")
    if "latest" in q or "recent" in q:
        subquery_title_filter = _teams_meeting_title_filter(question, "m2")
        meeting_filter = f"m.meeting_date = (SELECT max(m2.meeting_date) FROM meetings m2 WHERE {subquery_title_filter})"
        date_window = "latest"
    else:
        meeting_filter, date_window = _relative_date_filter_sql(question, "m.meeting_date")
    return f"""
        SELECT
          m.meeting_date,
          m.title,
          {sql_literal(date_window)} AS date_window,
          m.start_datetime,
          m.end_datetime,
          m.organizer,
          m.web_link,
          m.utterance_count,
          m.provenance_grain
        FROM meetings m
        WHERE {meeting_filter}
          AND {title_filter}
        ORDER BY m.meeting_date DESC, m.start_datetime DESC
    """


def _bucket_model_sql(question):
    q = question.lower()
    if not (
        re.search(r"\bmodels?\b|\bai\b|\byolo\b|\bsegmentation\b|\bdetection\b|\btraining\b", q)
        or "computer vision" in q
    ):
        return None
    if not (
        _has_any(q, ["bucket", "model file", "model files", "model metadata", "computer vision", "yolo"])
        or re.search(r"\bai\b", q)
    ):
        return None
    return """
        SELECT name, metadata_json, provenance_grain
        FROM model_metadata
        ORDER BY
          CASE
            WHEN lower(name) LIKE '%yolo%' THEN 0
            WHEN lower(name) LIKE '%model%' THEN 1
            ELSE 2
          END,
          name
    """


def _bucket_structured_anchor_probe_sql(question):
    q = question.lower()
    tokens = anchor_tokens(q)
    if "peppermint" in tokens and "oil" in tokens:
        tokens = [token for token in tokens if token != "oil"]
        tokens.append("pepoil")
    if not set(tokens) & BUCKET_ANCHOR_TERMS:
        return None
    values_sql = _terms_values_sql(tokens)
    if not values_sql:
        return None
    return f"""
        WITH anchor_terms(term) AS (
          VALUES {values_sql}
        ),
        dart_matches AS (
          SELECT
            'dart_assay_result' AS anchor_type,
            source_name AS name,
            CAST(row_number AS TEXT) AS sub_id,
            species || ' ' || assay_type || ' ' || coalesce(treatment_normalized, treatment, '') || ' ' || coalesce(dilution, '') AS evidence_text,
            provenance_grain
          FROM dart_assay_results d
          WHERE EXISTS (
            SELECT 1
            FROM anchor_terms t
            WHERE lower(
              coalesce(d.species, '') || ' ' ||
              coalesce(d.assay_type, '') || ' ' ||
              coalesce(d.treatment_normalized, '') || ' ' ||
              coalesce(d.treatment, '') || ' ' ||
              coalesce(d.filename, '') || ' ' ||
              coalesce(d.source_name, '')
            ) LIKE '%' || t.term || '%'
          )
        ),
        media_matches AS (
          SELECT
            'assay_media_link' AS anchor_type,
            media_name AS name,
            CAST(assay_row_number AS TEXT) AS sub_id,
            coalesce(species, '') || ' ' || coalesce(treatment_normalized, '') || ' ' || coalesce(condition, '') || ' ' || coalesce(media_uri, '') AS evidence_text,
            provenance_grain
          FROM assay_media_links l
          WHERE EXISTS (
            SELECT 1
            FROM anchor_terms t
            WHERE lower(
              coalesce(l.species, '') || ' ' ||
              coalesce(l.treatment_normalized, '') || ' ' ||
              coalesce(l.condition, '') || ' ' ||
              coalesce(l.media_name, '') || ' ' ||
              coalesce(l.media_uri, '') || ' ' ||
              coalesce(l.assay_source_name, '')
            ) LIKE '%' || t.term || '%'
          )
        ),
        model_matches AS (
          SELECT
            'model_metadata' AS anchor_type,
            name,
            'metadata' AS sub_id,
            metadata_json AS evidence_text,
            provenance_grain
          FROM model_metadata m
          WHERE EXISTS (
            SELECT 1
            FROM anchor_terms t
            WHERE lower(coalesce(m.name, '') || ' ' || coalesce(m.metadata_json, '')) LIKE '%' || t.term || '%'
          )
        ),
        combined_anchor_rows AS (
          SELECT anchor_type, name, sub_id, evidence_text, provenance_grain
          FROM dart_matches
          UNION ALL
          SELECT anchor_type, name, sub_id, evidence_text, provenance_grain
          FROM media_matches
          UNION ALL
          SELECT anchor_type, name, sub_id, evidence_text, provenance_grain
          FROM model_matches
        )
        SELECT anchor_type, name, sub_id, evidence_text, provenance_grain
        FROM combined_anchor_rows
        ORDER BY
          CASE anchor_type
            WHEN 'dart_assay_result' THEN 0
            WHEN 'assay_media_link' THEN 1
            ELSE 2
          END,
          name,
          sub_id
    """


def _bucket_experiment_listing_applies(question):
    q = question.lower()
    if _has_any(q, ["assay metrics", "preference index", "avg pi", "repellent", "repellency", "strongest", "top"]):
        return False
    return (
        _has_any(q, ["experiment", "experiments", "assay run", "assay runs", "run list", "uploads", "uploaded"])
        and _has_any(q, ["list", "what", "which", "show", "new", "recent", "today", "yesterday", "last week", "this week", "uploaded", "bucket"])
    )


def _bucket_experiment_date_filter(question):
    q = question.lower()
    if "today" in q:
        return "date(coalesce(updated, time_created)) = date('now')", "today"
    if "yesterday" in q:
        return "date(coalesce(updated, time_created)) = date('now', '-1 day')", "yesterday"
    if "last week" in q:
        return (
            "date(coalesce(updated, time_created)) >= date('now', 'weekday 1', '-14 days') "
            "AND date(coalesce(updated, time_created)) < date('now', 'weekday 1', '-7 days')",
            "last_week",
        )
    if "this week" in q:
        return "date(coalesce(updated, time_created)) >= date('now', 'weekday 1', '-7 days')", "this_week"
    if _has_any(q, ["new", "recent", "uploaded"]):
        return "date(coalesce(updated, time_created)) >= date('now', '-14 days')", "recent_14_days"
    return "date(coalesce(updated, time_created)) >= date('now', '-60 days')", "recent_60_days"


def _bucket_experiment_listing_sql(question):
    date_filter, date_window = _bucket_experiment_date_filter(question)
    return f"""
        WITH object_units AS (
          SELECT
            name,
            uri,
            kind,
            ext,
            top_folder,
            updated,
            time_created,
            CASE
              WHEN name LIKE 'phytotoxicity/images/%' THEN 'phytotoxicity/images/'
              WHEN name LIKE 'phytotoxicity/results/%' THEN 'phytotoxicity/results/'
              WHEN name LIKE '%/processed/%' THEN substr(name, 1, instr(name, '/processed/') + length('/processed/') - 1)
              ELSE top_folder || '/'
            END AS marker_prefix,
            CASE
              WHEN name LIKE 'phytotoxicity/images/%' THEN substr(name, length('phytotoxicity/images/') + 1)
              WHEN name LIKE 'phytotoxicity/results/%' THEN substr(name, length('phytotoxicity/results/') + 1)
              WHEN name LIKE '%/processed/%' THEN substr(name, instr(name, '/processed/') + length('/processed/'))
              ELSE substr(name, length(top_folder) + 2)
            END AS marker_tail
          FROM objects
          WHERE kind <> 'folder_marker'
            AND top_folder IN ('mosquitoes', 'flies', 'phytotoxicity', 'contact_repel_videos', 'Beetles')
            AND ({date_filter})
            AND (
              name LIKE '%/processed/%/%'
              OR name LIKE 'phytotoxicity/images/%/%'
              OR name LIKE 'phytotoxicity/results/%/%'
              OR name LIKE 'contact_repel_videos/%/processed/%/%'
            )
        ),
        experiment_objects AS (
          SELECT
            marker_prefix || substr(marker_tail, 1, instr(marker_tail || '/', '/') - 1) AS experiment_key,
            top_folder,
            kind,
            ext,
            name,
            uri,
            updated,
            time_created
          FROM object_units
          WHERE marker_tail <> ''
        )
        SELECT
          experiment_key,
          top_folder,
          CASE
            WHEN top_folder = 'mosquitoes' THEN 'mosquitoes'
            WHEN top_folder = 'flies' THEN 'flies'
            WHEN top_folder = 'phytotoxicity' THEN 'phytotoxicity'
            WHEN top_folder = 'contact_repel_videos' THEN 'contact_repel_videos'
            WHEN top_folder = 'Beetles' THEN 'beetles'
            ELSE top_folder
          END AS assay_family,
          {sql_literal(date_window)} AS date_window,
          count(*) AS object_count,
          sum(CASE WHEN kind = 'video' THEN 1 ELSE 0 END) AS video_count,
          sum(CASE WHEN kind = 'image' THEN 1 ELSE 0 END) AS image_count,
          sum(CASE WHEN kind = 'csv' THEN 1 ELSE 0 END) AS csv_count,
          sum(CASE WHEN kind = 'json' THEN 1 ELSE 0 END) AS json_count,
          min(time_created) AS first_time_created,
          max(updated) AS latest_updated,
          min(name) AS example_object,
          json_object(
            'grain_id', 'bucket_experiment:' || experiment_key,
            'grain_type', 'bucket_experiment_prefix',
            'locator', 'gs://monarch-videos-new/' || experiment_key || '/',
            'source_id', 'monarch_videos_new'
          ) AS provenance_grain
        FROM experiment_objects
        GROUP BY experiment_key, top_folder
        ORDER BY latest_updated DESC, object_count DESC, experiment_key
    """


def _bucket_experiments_by_run_date_applies(question):
    q = question.lower()
    has_run_verb = bool(re.search(r"\b(run|ran|performed)\b", q)) or "were run" in q
    return (
        _has_any(q, ["experiment", "experiments", "assay", "assays"])
        and has_run_verb
        and _has_any(q, ["list", "what", "which", "all", "today", "yesterday", "last week", "this week", "recent"])
    )


def _bucket_cross_assay_run_inventory_applies(question):
    q = question.lower()
    if _bucket_recent_contact_no_contact_assays_applies(question):
        return False
    species = species_from_question(question)
    if "dart" in q and species != "flies":
        return False
    has_run_verb = bool(re.search(r"\b(run|ran|performed)\b", q)) or "were run" in q
    asks_listing = _has_any(q, ["list", "show", "what", "which", "see", "do we have"]) or _has_count_request(question)
    has_assay_terms = _has_any(q, ["assay", "assays", "assay run", "assay runs"])
    has_experiment_terms = _has_any(q, ["experiment", "experiments"])
    has_contact_count_terms = _has_count_request(question) and _has_any(
        q,
        [
            "contact/no-contact",
            "contact / no contact",
            "contact and no contact",
            "contact and non-contact",
            "noncontact",
            "non contact",
            "no contact",
            "pair",
            "pairs",
        ],
    )
    has_assay_target = has_assay_terms or (_has_count_request(question) and has_experiment_terms) or has_contact_count_terms
    has_time_window = _has_any(q, ["today", "yesterday", "last week", "this week", "recent"]) or bool(
        re.search(r"\b(?:last|past)\s+(?:\d+|one|two|couple)\s+(?:day|days|week|weeks|month|months)\b", q)
    ) or bool(_extract_explicit_iso_date(question))
    has_family_or_species_scope = bool(species) or _has_any(
        q,
        [
            "all",
            "contact/no-contact",
            "contact / no contact",
            "contact and no contact",
            "contact and non-contact",
            "dart",
            "noncontact",
            "no contact",
            "oviposition",
            "egg laying",
            "egg-laying",
            "phytotoxicity",
        ],
    )
    return has_assay_target and (has_run_verb or asks_listing) and (has_time_window or has_family_or_species_scope)


def _bucket_fly_assay_count_sql(question):
    if not _bucket_fly_assay_count_applies(question):
        return None
    trial_date_iso = _compact_assay_date_iso_sql("trial_date")
    date_details = _optional_assay_date_filter_details(question, "trial_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    return f"""
        WITH trials AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'A%' THEN value END) AS trial_date,
            max(CASE WHEN cell LIKE 'B%' THEN value END) AS filename,
            max(CASE WHEN cell LIKE 'N%' THEN value END) AS treatment,
            max(CASE WHEN cell LIKE 'U%' THEN value END) AS usable_data
          FROM xlsx_cells_with_provenance
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet = 'trials'
            AND row_number > 1
          GROUP BY row_number
        ),
        normalized AS (
          SELECT *, {trial_date_iso} AS trial_date_iso
          FROM trials
          WHERE trim(coalesce(filename, '')) <> ''
        )
        SELECT
          'flies' AS species,
          'fly repellency screen metadata' AS assay_family,
          {sql_literal(date_window)} AS date_window,
          count(*) AS trial_rows,
          count(DISTINCT filename) AS distinct_filenames,
          count(DISTINCT trial_date) AS distinct_raw_dates,
          min(row_number) AS first_row_number,
          max(row_number) AS last_row_number,
          min(trial_date_iso) AS first_date_iso,
          max(trial_date_iso) AS last_date_iso,
          coalesce(min(trial_date_iso), min(trial_date)) || ' to ' || coalesce(max(trial_date_iso), max(trial_date)) AS date_range,
          'distinct_filenames_are_assay_runs, trial_rows_are_tube_rows' AS count_unit,
          'gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#sheet=trials&rows=' || min(row_number) || '-' || max(row_number) AS locator,
          json_object(
            'grain_id', 'fly_assay_count:trials',
            'grain_type', 'fly_assay_count',
            'locator', 'gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#sheet=trials&rows=' || min(row_number) || '-' || max(row_number),
            'source_id', 'monarch_videos_new',
            'count_unit', 'distinct_filenames_and_trial_rows'
          ) AS provenance_grain
        FROM normalized
        WHERE {date_filter}
    """


def _contact_summary_ranked_cte(question=None):
    compound_expr = _known_contact_compound_case_sql("json_extract(row_json, '$.video_stem')")
    date_details = _optional_assay_date_filter_details(question or "", "event_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    species_scope = _assay_species_constraints_from_question(question or "")
    species_filter = ""
    if species_scope:
        species_filter = "AND species IN (" + ", ".join(sql_literal(species) for species in species_scope) + ")"
    return f"""
        WITH ranked_rows AS (
          SELECT
            rows.name AS source_file,
            rows.row_number,
            json_extract(rows.row_json, '$.video_stem') AS video_stem,
            CASE
              WHEN rows.name LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN rows.name LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              ELSE 'unknown'
            END AS species,
            CASE
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%noncontact%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%non_contact%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%no_contact%' THEN 'non-contact'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%contact%' THEN 'contact'
              ELSE 'unknown'
            END AS assay_mode,
            {compound_expr} AS compound,
            coalesce(
              CAST(json_extract(rows.row_json, '$.adj_contact_pi_mean') AS REAL),
              CAST(json_extract(rows.row_json, '$.mean_contact_pi') AS REAL)
            ) AS adj_contact_pi_mean,
            CAST(json_extract(rows.row_json, '$.adj_contact_pi_late') AS REAL) AS adj_contact_pi_late,
            CAST(json_extract(rows.row_json, '$.adj_contact_pi_auc') AS REAL) AS adj_contact_pi_auc,
            CAST(json_extract(rows.row_json, '$.std_contact_pi') AS REAL) AS standard_deviation,
            NULL AS standard_error,
            CASE
              WHEN json_extract(rows.row_json, '$.std_contact_pi') IS NOT NULL THEN 'frame_level_contact_pi_within_video'
              ELSE 'standard_deviation_not_available_in_source_row'
            END AS standard_deviation_basis,
            CASE
              WHEN json_extract(rows.row_json, '$.adj_contact_pi_mean') IS NOT NULL THEN 'adj_contact_pi_mean'
              ELSE 'mean_contact_pi'
            END AS metric_name,
            CASE
              WHEN json_extract(rows.row_json, '$.adj_contact_pi_mean') IS NOT NULL THEN 'higher adj_contact_pi_mean means stronger control-adjusted avoidance'
              ELSE 'higher mean_contact_pi means stronger contact avoidance in the fly contact summary'
            END AS metric_basis,
            date(coalesce(objects.updated, objects.time_created)) AS event_date_iso,
            'bucket_object_updated_or_created_time' AS date_basis,
            {sql_literal(date_window)} AS date_window,
            json_extract(rows.row_json, '$.is_control') AS is_control,
            json_object(
              'grain_id', 'contact_noncontact_rank:' || rows.name || ':' || rows.row_number,
              'grain_type', 'contact_noncontact_ranked_comparison',
              'locator', 'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number,
              'source_id', 'monarch_videos_new',
              'metric_name', CASE
                WHEN json_extract(rows.row_json, '$.adj_contact_pi_mean') IS NOT NULL THEN 'adj_contact_pi_mean'
                ELSE 'mean_contact_pi'
              END,
              'standard_deviation_basis', CASE
                WHEN json_extract(rows.row_json, '$.std_contact_pi') IS NOT NULL THEN 'frame_level_contact_pi_within_video'
                ELSE 'standard_deviation_not_available_in_source_row'
              END,
              'date_window', {sql_literal(date_window)}
            ) AS provenance_grain
          FROM csv_rows_with_provenance rows
          LEFT JOIN objects ON objects.name = rows.name
          WHERE rows.name IN (
              'contact_repel_videos/mosquitoes_new_solvent/processed/combined_results_with_adj.csv',
              'contact_repel_videos/mosquitoes/processed/combined_results_with_adj.csv',
              'contact_repel_videos/flies/processed/combined_results.csv'
            )
            AND coalesce(
              json_extract(rows.row_json, '$.adj_contact_pi_mean'),
              json_extract(rows.row_json, '$.mean_contact_pi')
            ) IS NOT NULL
        ),
        filtered AS (
          SELECT *
          FROM ranked_rows
          WHERE assay_mode IN ('contact', 'non-contact')
            AND lower(coalesce(is_control, '')) NOT IN ('true', '1', 'yes')
            AND event_date_iso IS NOT NULL
            AND ({date_filter})
            {species_filter}
        ),
        ranked AS (
          SELECT
            row_number() OVER (PARTITION BY species, assay_mode ORDER BY adj_contact_pi_mean DESC, compound COLLATE NOCASE) AS rank,
            *
          FROM filtered
        )
    """


def _bucket_contact_noncontact_adjusted_pi_comparison_sql(question):
    if not _bucket_contact_noncontact_adjusted_pi_comparison_applies(question):
        return None
    return _contact_summary_ranked_cte(question) + """
        SELECT
          rank,
          species,
          assay_mode,
          compound,
          video_stem,
          adj_contact_pi_mean,
          adj_contact_pi_late,
          adj_contact_pi_auc,
          standard_deviation,
          standard_error,
          standard_deviation_basis,
          metric_name,
          metric_basis,
          date_window,
          date_basis,
          event_date_iso,
          source_file,
          row_number AS source_row_number,
          provenance_grain
        FROM ranked
        WHERE rank <= 10
        ORDER BY species, rank, assay_mode
    """


def _bucket_rank_expectation_explanation_sql(question):
    compound = _extract_named_compound_for_rank(question)
    if not compound or not _bucket_rank_expectation_explanation_applies(question):
        return None
    return _contact_summary_ranked_cte(question) + f"""
        SELECT
          target.compound,
          target.rank AS actual_rank,
          target.assay_mode,
          target.adj_contact_pi_mean,
          'adj_contact_pi_mean' AS ranking_metric,
          nearby.rank AS nearby_rank,
          nearby.compound AS nearby_compound,
          nearby.adj_contact_pi_mean AS nearby_adj_contact_pi_mean,
          CASE
            WHEN target.adj_contact_pi_mean > 0.3 THEN 'strong_by_metric_threshold_but_not_top_cutoff'
            ELSE 'below_strong_threshold_in_this_summary'
          END AS explanation_type,
          target.source_file,
          target.row_number AS source_row_number,
          target.provenance_grain
        FROM ranked target
        LEFT JOIN ranked nearby
          ON nearby.assay_mode = target.assay_mode
         AND nearby.rank BETWEEN max(1, target.rank - 2) AND target.rank + 2
        WHERE target.assay_mode = 'contact'
          AND lower(target.compound) = lower({sql_literal(compound)})
        ORDER BY nearby.rank
    """


def _bucket_assay_summary_file_explanation_sql(question):
    if not _bucket_assay_summary_file_explanation_applies(question):
        return None
    return """
        WITH summary_rows AS (
          SELECT name, count(*) AS row_count
          FROM csv_rows_with_provenance
          WHERE name IN (
            'contact_repel_videos/mosquitoes/processed/adjusted_contact_pi_summary.csv',
            'contact_repel_videos/mosquitoes_new_solvent/processed/adjusted_contact_pi_summary.csv'
          )
          GROUP BY name
        ),
        column_rollup AS (
          SELECT name, group_concat(column_name, ', ') AS columns
          FROM csv_columns_with_provenance
          WHERE name IN (
            'contact_repel_videos/mosquitoes/processed/adjusted_contact_pi_summary.csv',
            'contact_repel_videos/mosquitoes_new_solvent/processed/adjusted_contact_pi_summary.csv'
          )
          GROUP BY name
        )
        SELECT
          r.name AS source_file,
          r.row_count,
          o.updated,
          o.time_created,
          c.columns AS column_name,
          'adj_contact_pi_mean compares treatment behavior to time-matched controls, higher values indicate stronger adjusted contact repellency' AS metric_definition,
          CASE
            WHEN r.name LIKE '%mosquitoes_new_solvent/%' THEN 'newer_adjusted_summary'
            ELSE 'older_adjusted_summary'
          END AS file_version,
          json_object(
            'grain_id', 'assay_summary_file:' || r.name,
            'grain_type', 'assay_summary_file',
            'locator', 'gs://monarch-videos-new/' || r.name,
            'source_id', 'monarch_videos_new',
            'version_or_modified_time', coalesce(o.updated, o.time_created)
          ) AS provenance_grain
        FROM summary_rows r
        LEFT JOIN column_rollup c ON c.name = r.name
        LEFT JOIN objects o ON o.name = r.name
        ORDER BY datetime(replace(coalesce(o.updated, o.time_created), 'Z', '')) DESC, r.name
    """


def _bucket_assay_best_result_environment_conditions_sql(question):
    if not _bucket_assay_best_result_environment_conditions_applies(question):
        return None
    q = str(question).lower()
    species_scope = _assay_species_constraints_from_question(question)
    filters = []
    if species_scope:
        filters.append("species IN (" + ", ".join(sql_literal(species) for species in species_scope) + ")")
    family_scope = []
    if _has_any(q, ["contact/no-contact", "contact / no contact", "contact and no contact", "contact and non-contact", "noncontact", "non-contact", "non contact", "no-contact", "no contact"]):
        family_scope.append("contact_no_contact")
    if "dart" in q:
        family_scope.extend(["dart", "fly_repellency"])
    if _has_any(q, PHYTOTOX_TERMS + ["plant", "plants", "soybean", "leaf", "leaves"]):
        family_scope.append("phytotoxicity")
    if _has_any(q, ["oviposition", "egg laying", "egg-laying"]):
        family_scope.append("fly_oviposition")
    if family_scope:
        filters.append("assay_family IN (" + ", ".join(sql_literal(family) for family in sorted(set(family_scope))) + ")")
    scoped_where = "WHERE " + " AND ".join(filters) if filters else ""
    asks_repellency_direction = _has_any(q, ["repellent", "repellents", "repellency", "preference index", " pi"])
    dart_score = "-CAST(coalesce(avg_pi_real, avg_pi) AS REAL)" if asks_repellency_direction else "abs(CAST(coalesce(avg_pi_real, avg_pi) AS REAL))"
    dart_effect_filter = "AND CAST(coalesce(avg_pi_real, avg_pi) AS REAL) < 0" if asks_repellency_direction else ""
    fly_score = "-fr.corrected_mean_trt_pi" if asks_repellency_direction else "abs(fr.corrected_mean_trt_pi)"
    fly_effect_filter = "AND fr.corrected_mean_trt_pi < 0" if asks_repellency_direction else ""
    return f"""
        WITH mosquito_ranked AS (
          SELECT
            'ranked' AS environment_status,
            'mosquitoes' AS species,
            'dart' AS assay_family,
            'dart' AS assay_mode,
            treatment_normalized AS compound,
            CAST(temp AS REAL) AS temperature_c,
            CAST(rh AS REAL) AS relative_humidity_pct,
            'avg_pi' AS metric_name,
            CAST(coalesce(avg_pi_real, avg_pi) AS REAL) AS metric_value,
            {dart_score} AS ranking_score,
            NULL AS usable_data,
            source_name,
            row_number AS source_row_number,
            NULL AS source_gap_reason,
            json_object(
              'grain_id', 'best_result_environment:mosquitoes:' || source_name || ':' || row_number,
              'grain_type', 'best_result_environment_condition',
              'locator', 'gs://monarch-videos-new/' || source_name || '#sheet=' || sheet || '&row=' || row_number,
              'source_id', 'monarch_videos_new',
              'metric_name', 'avg_pi'
            ) AS provenance_grain
          FROM dart_assay_results
          WHERE species = 'mosquitoes'
            AND temp IS NOT NULL
            AND rh IS NOT NULL
            AND coalesce(avg_pi_real, avg_pi) IS NOT NULL
            {dart_effect_filter}
            AND lower(coalesce(treatment_normalized, treatment, '')) NOT IN ('control', 'ctrl', 'vehicle control')
        ),
        fly_result_files AS (
          SELECT DISTINCT name
          FROM csv_columns_with_provenance
          WHERE name LIKE 'flies/processed/%/corrected/pi_correction_summary.csv'
        ),
        fly_results AS (
          SELECT
            substr(rows.name, instr(rows.name, 'flies/processed/') + length('flies/processed/'), 19) AS run_token,
            json_extract(rows.row_json, '$.treatment') AS treatment,
            CAST(json_extract(rows.row_json, '$.corrected_mean_trt_pi') AS REAL) AS corrected_mean_trt_pi,
            rows.name AS source_name,
            rows.row_number AS source_row_number
          FROM fly_result_files files
          JOIN csv_rows_with_provenance rows ON rows.name = files.name
          WHERE json_extract(rows.row_json, '$.corrected_mean_trt_pi') IS NOT NULL
        ),
        fly_metadata AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'B%' THEN value END) AS filename,
            max(CASE WHEN cell LIKE 'D%' THEN value END) AS temp,
            max(CASE WHEN cell LIKE 'E%' THEN value END) AS rh,
            max(CASE WHEN cell LIKE 'N%' THEN value END) AS treatment,
            max(CASE WHEN cell LIKE 'U%' THEN value END) AS usable_data
          FROM xlsx_cells_with_provenance
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet = 'trials'
            AND row_number > 1
          GROUP BY row_number
        ),
        fly_ranked AS (
          SELECT
            'ranked' AS environment_status,
            'flies' AS species,
            'fly_repellency' AS assay_family,
            'dart' AS assay_mode,
            fr.treatment AS compound,
            CAST(fm.temp AS REAL) AS temperature_c,
            CAST(fm.rh AS REAL) AS relative_humidity_pct,
            'corrected_mean_trt_pi' AS metric_name,
            fr.corrected_mean_trt_pi AS metric_value,
            {fly_score} AS ranking_score,
            fm.usable_data,
            fr.source_name,
            fr.source_row_number,
            NULL AS source_gap_reason,
            json_object(
              'grain_id', 'best_result_environment:flies:' || fr.source_name || ':' || fr.source_row_number,
              'grain_type', 'best_result_environment_condition',
              'locator', 'gs://monarch-videos-new/' || fr.source_name || '#row=' || fr.source_row_number,
              'source_id', 'monarch_videos_new',
              'metadata_locator', 'gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#sheet=trials&row=' || fm.row_number,
              'metric_name', 'corrected_mean_trt_pi'
            ) AS provenance_grain
          FROM fly_results fr
          JOIN fly_metadata fm
            ON fm.filename LIKE '%' || fr.run_token || '%'
           AND lower(fm.treatment) = lower(fr.treatment)
          WHERE fm.temp IS NOT NULL
            AND fm.rh IS NOT NULL
            AND coalesce(fm.usable_data, '1') = '1'
            {fly_effect_filter}
        ),
        phytotox_result_files AS (
          SELECT DISTINCT name
          FROM csv_columns_with_provenance
          WHERE name LIKE 'phytotoxicity/results/%/predictions/analysis/features_all.csv'
        ),
        phytotox_results AS (
          SELECT
            replace(
              substr(rows.name, length('phytotoxicity/results/') + 1),
              '/predictions/analysis/features_all.csv',
              ''
            ) AS run_slug,
            json_extract(rows.row_json, '$.treatment_name') AS treatment_name,
            json_extract(rows.row_json, '$.replicate') AS replicate,
            json_extract(rows.row_json, '$.time_point') AS time_point,
            CAST(json_extract(rows.row_json, '$.damaged_fraction') AS REAL) AS damaged_fraction,
            rows.name AS source_name,
            rows.row_number AS source_row_number
          FROM phytotox_result_files files
          JOIN csv_rows_with_provenance rows ON rows.name = files.name
          WHERE json_extract(rows.row_json, '$.condition') = 'treatment'
            AND json_extract(rows.row_json, '$.treatment_name') IS NOT NULL
            AND json_extract(rows.row_json, '$.damaged_fraction') IS NOT NULL
        ),
        phytotox_metadata AS (
          SELECT
            replace(
              replace(name, 'phytotoxicity/images/', ''),
              '/phytotoxicity_metadata_template.xlsx',
              ''
            ) AS run_slug,
            name AS metadata_source_name,
            row_number AS metadata_row_number,
            max(CASE WHEN cell LIKE 'C%' THEN value END) AS time_point,
            max(CASE WHEN cell LIKE 'D%' THEN value END) AS condition,
            max(CASE WHEN cell LIKE 'F%' THEN value END) AS treatment_name,
            max(CASE WHEN cell LIKE 'I%' THEN value END) AS replicate,
            max(CASE WHEN cell LIKE 'J%' THEN value END) AS temp_c,
            max(CASE WHEN cell LIKE 'K%' THEN value END) AS humidity_pct
          FROM xlsx_cells_with_provenance
          WHERE name LIKE 'phytotoxicity/images/%/phytotoxicity_metadata_template.xlsx'
            AND row_number > 1
          GROUP BY name, row_number
        ),
        phytotox_ranked AS (
          SELECT
            'ranked' AS environment_status,
            'plants' AS species,
            'phytotoxicity' AS assay_family,
            'phytotoxicity' AS assay_mode,
            pr.treatment_name AS compound,
            CAST(pm.temp_c AS REAL) AS temperature_c,
            CAST(pm.humidity_pct AS REAL) AS relative_humidity_pct,
            'damaged_fraction' AS metric_name,
            pr.damaged_fraction AS metric_value,
            pr.damaged_fraction AS ranking_score,
            NULL AS usable_data,
            pr.source_name,
            pr.source_row_number,
            NULL AS source_gap_reason,
            json_object(
              'grain_id', 'best_result_environment:phytotoxicity:' || pr.source_name || ':' || pr.source_row_number,
              'grain_type', 'best_result_environment_condition',
              'locator', 'gs://monarch-videos-new/' || pr.source_name || '#row=' || pr.source_row_number,
              'source_id', 'monarch_videos_new',
              'metadata_locator', 'gs://monarch-videos-new/' || pm.metadata_source_name || '#row=' || pm.metadata_row_number,
              'metric_name', 'damaged_fraction'
            ) AS provenance_grain
          FROM phytotox_results pr
          JOIN phytotox_metadata pm
            ON pm.run_slug = pr.run_slug
           AND lower(pm.treatment_name) = lower(pr.treatment_name)
           AND coalesce(pm.replicate, '') = coalesce(pr.replicate, '')
           AND (
             coalesce(pm.time_point, '') = coalesce(pr.time_point, '')
             OR coalesce(pm.time_point, '') = ''
             OR coalesce(pr.time_point, '') = ''
           )
          WHERE pm.temp_c IS NOT NULL
            AND pm.humidity_pct IS NOT NULL
            AND lower(coalesce(pm.condition, 'treatment')) = 'treatment'
        ),
        contact_no_contact_gap AS (
          SELECT
            'source_gap' AS environment_status,
            species,
            'contact_no_contact' AS assay_family,
            'contact/no-contact' AS assay_mode,
            NULL AS compound,
            NULL AS temperature_c,
            NULL AS relative_humidity_pct,
            NULL AS metric_name,
            NULL AS metric_value,
            NULL AS ranking_score,
            NULL AS usable_data,
            source_name,
            NULL AS source_row_number,
            'contact/no-contact summaries are indexed with effect metrics, but no temperature or humidity fields are indexed for those rows' AS source_gap_reason,
            json_object(
              'grain_id', 'best_result_environment:source_gap:contact_no_contact:' || species,
              'grain_type', 'best_result_environment_condition',
              'locator', 'gs://monarch-videos-new/' || source_name,
              'source_id', 'monarch_videos_new',
              'source_gap_reason', 'no indexed temperature or humidity fields for contact/no-contact assay result rows'
            ) AS provenance_grain
          FROM (
            SELECT 'mosquitoes' AS species, 'contact_repel_videos/mosquitoes_new_solvent/processed/adjusted_contact_pi_summary.csv' AS source_name
            UNION ALL
            SELECT 'flies' AS species, 'contact_repel_videos/flies/processed/combined_results.csv' AS source_name
          )
        ),
        oviposition_gap AS (
          SELECT
            'source_gap' AS environment_status,
            'flies' AS species,
            'fly_oviposition' AS assay_family,
            'oviposition' AS assay_mode,
            NULL AS compound,
            NULL AS temperature_c,
            NULL AS relative_humidity_pct,
            NULL AS metric_name,
            NULL AS metric_value,
            NULL AS ranking_score,
            NULL AS usable_data,
            'flies/insect images /Oviposition/' AS source_name,
            NULL AS source_row_number,
            'oviposition objects are indexed as image artifacts, but no structured temperature, humidity, or result metric rows are indexed yet' AS source_gap_reason,
            json_object(
              'grain_id', 'best_result_environment:source_gap:fly_oviposition',
              'grain_type', 'best_result_environment_condition',
              'locator', 'gs://monarch-videos-new/flies/insect images /Oviposition/',
              'source_id', 'monarch_videos_new',
              'source_gap_reason', 'no indexed temperature, humidity, or result metric rows for oviposition'
            ) AS provenance_grain
        ),
        combined AS (
          SELECT * FROM mosquito_ranked
          UNION ALL SELECT * FROM fly_ranked
          UNION ALL SELECT * FROM phytotox_ranked
          UNION ALL SELECT * FROM contact_no_contact_gap
          UNION ALL SELECT * FROM oviposition_gap
        ),
        scoped AS (
          SELECT *
          FROM combined
          {scoped_where}
        ),
        ranked AS (
          SELECT
            row_number() OVER (PARTITION BY species, assay_family ORDER BY ranking_score IS NULL, ranking_score DESC, compound COLLATE NOCASE) AS species_rank,
            *
          FROM scoped
        )
        SELECT
          environment_status,
          species,
          assay_family,
          assay_mode,
          compound,
          temperature_c,
          relative_humidity_pct,
          metric_name,
          metric_value,
          ranking_score,
          usable_data,
          source_name,
          source_row_number,
          source_gap_reason,
          provenance_grain
        FROM ranked
        WHERE species_rank = 1
        ORDER BY
          CASE environment_status WHEN 'ranked' THEN 0 ELSE 1 END,
          species,
          assay_family
    """


def _bucket_cross_assay_run_inventory_sql(question):
    if _has_count_request(question):
        return _bucket_cross_assay_inventory_count_sql(question)

    dart_assay_date_iso = _compact_assay_date_iso_sql("assay_date")
    fly_trial_date_iso = _compact_assay_date_iso_sql("trial_date")
    event_details = _assay_ledger_date_filter_details(question, "event_date_iso")
    event_filter = event_details["filter_sql"]
    date_window = event_details["date_window"]
    species = species_from_question(question)
    output_filters = []
    if species:
        output_filters.append(f"species = {sql_literal(species)}")
    if "dart" in question.lower() and species == "flies":
        output_filters.append("assay_family = 'fly_repellency'")
    output_where = f"WHERE {' AND '.join(output_filters)}" if output_filters else ""
    return f"""
        WITH dart_normalized AS (
          SELECT
            species,
            assay_type,
            assay_date,
            {dart_assay_date_iso} AS event_date_iso,
            treatment_normalized,
            filename,
            source_name,
            sheet,
            row_number
          FROM dart_assay_results
          WHERE assay_date IS NOT NULL
        ),
        dart_groups AS (
          SELECT
            'dart' AS assay_family,
            species,
            assay_type,
            min(event_date_iso) AS event_date_iso,
            {sql_literal(date_window)} AS date_window,
            'assay_date' AS date_basis,
            count(*) AS assay_rows,
            count(DISTINCT treatment_normalized) AS treatment_count,
            count(DISTINCT filename) AS file_count,
            group_concat(DISTINCT treatment_normalized) AS treatments,
            min(source_name) AS example_source_name,
            min(sheet) AS example_sheet,
            min(row_number) AS first_row_number,
            'dart_assay_results table' AS evidence_home,
            'dart_assay_results#assay_date=' || coalesce(assay_date, 'unknown') AS locator,
            'dart_assay_results' AS source_table
          FROM dart_normalized
          WHERE event_date_iso IS NOT NULL
            AND ({event_filter})
          GROUP BY assay_date, species, assay_type
        ),
        fly_trial_rows AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'A%' THEN value END) AS trial_date,
            max(CASE WHEN cell LIKE 'B%' THEN value END) AS filename,
            max(CASE WHEN cell LIKE 'N%' THEN value END) AS treatment,
            max(CASE WHEN cell LIKE 'U%' THEN value END) AS usable_data
          FROM xlsx_cells_with_provenance
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet = 'trials'
            AND row_number > 1
          GROUP BY row_number
        ),
        fly_trial_normalized AS (
          SELECT
            *,
            {fly_trial_date_iso} AS event_date_iso
          FROM fly_trial_rows
        ),
        fly_groups AS (
          SELECT
            'fly_repellency' AS assay_family,
            'flies' AS species,
            'fly repellency screen' AS assay_type,
            min(event_date_iso) AS event_date_iso,
            {sql_literal(date_window)} AS date_window,
            'flies metadata trial date' AS date_basis,
            count(*) AS assay_rows,
            count(DISTINCT treatment) AS treatment_count,
            count(DISTINCT filename) AS file_count,
            group_concat(DISTINCT treatment) AS treatments,
            'flies/repellency_screen_metadata_sheet.xlsx' AS example_source_name,
            'trials' AS example_sheet,
            min(row_number) AS first_row_number,
            'flies repellency metadata workbook' AS evidence_home,
            'gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#sheet=trials' AS locator,
            'xlsx_cells_with_provenance' AS source_table
          FROM fly_trial_normalized
          WHERE event_date_iso IS NOT NULL
            AND ({event_filter})
          GROUP BY event_date_iso
        ),
        contact_media_rows AS (
          SELECT
            media_name,
            media_uri,
            media_kind,
            media_updated,
            assay_row_number,
            coalesce(species, CASE
              WHEN lower(media_name) LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN lower(media_name) LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              WHEN lower(media_name) LIKE 'contact_repel_videos/beetles/%' THEN 'beetles'
              WHEN lower(media_name) LIKE 'contact_repel_videos/moths/%' THEN 'moths'
              ELSE 'unknown'
            END) AS species,
            date(media_updated) AS event_date_iso,
            CASE
              WHEN lower(coalesce(treatment_normalized, treatment, assay_filename, media_name)) LIKE '%control%' THEN NULL
              WHEN treatment_normalized IS NOT NULL AND trim(treatment_normalized) != '' THEN treatment_normalized
              WHEN treatment IS NOT NULL AND trim(treatment) != '' THEN treatment
              WHEN lower(assay_filename) LIKE '%noncontact_%' THEN
                replace(replace(replace(replace(substr(assay_filename, instr(lower(assay_filename), 'noncontact_') + length('noncontact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              WHEN lower(assay_filename) LIKE '%non_contact_%' THEN
                replace(replace(replace(replace(substr(assay_filename, instr(lower(assay_filename), 'non_contact_') + length('non_contact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              WHEN lower(assay_filename) LIKE '%no_contact_%' THEN
                replace(replace(replace(replace(substr(assay_filename, instr(lower(assay_filename), 'no_contact_') + length('no_contact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              WHEN lower(assay_filename) LIKE '%contact_%' THEN
                replace(replace(replace(replace(substr(assay_filename, instr(lower(assay_filename), 'contact_') + length('contact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              WHEN lower(media_name) LIKE '%noncontact_%' THEN
                replace(replace(replace(replace(substr(media_name, instr(lower(media_name), 'noncontact_') + length('noncontact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              WHEN lower(media_name) LIKE '%non_contact_%' THEN
                replace(replace(replace(replace(substr(media_name, instr(lower(media_name), 'non_contact_') + length('non_contact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              WHEN lower(media_name) LIKE '%no_contact_%' THEN
                replace(replace(replace(replace(substr(media_name, instr(lower(media_name), 'no_contact_') + length('no_contact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              WHEN lower(media_name) LIKE '%contact_%' THEN
                replace(replace(replace(replace(substr(media_name, instr(lower(media_name), 'contact_') + length('contact_')), '.mov', ''), '.MOV', ''), '.mp4', ''), '.MP4', '')
              ELSE coalesce(assay_filename, media_name)
            END AS media_treatment
          FROM assay_media_links
          WHERE media_kind = 'raw_video'
            AND lower(media_name) LIKE 'contact_repel_videos/%'
            AND lower(coalesce(media_name, '')) NOT LIKE '%/processed/%'
            AND date(media_updated) IS NOT NULL
            AND (
              lower(media_name) LIKE '%noncontact%'
              OR lower(media_name) LIKE '%non_contact%'
              OR lower(media_name) LIKE '%no_contact%'
              OR lower(media_name) LIKE '%_contact_%'
              OR lower(media_name) LIKE '%_conatct_%'
              OR lower(media_name) LIKE '%control%'
            )
        ),
        contact_media_groups AS (
          SELECT
            'contact_no_contact' AS assay_family,
            species,
            'raw contact/no-contact media' AS assay_type,
            event_date_iso,
            {sql_literal(date_window)} AS date_window,
            'assay_media_links media_updated date' AS date_basis,
            count(*) AS assay_rows,
            count(DISTINCT media_treatment) AS treatment_count,
            count(DISTINCT media_name) AS file_count,
            substr(group_concat(DISTINCT media_treatment), 1, 1000) AS treatments,
            min(media_name) AS example_source_name,
            NULL AS example_sheet,
            min(assay_row_number) AS first_row_number,
            'assay_media_links raw contact/no-contact media' AS evidence_home,
            min(media_uri) AS locator,
            'assay_media_links' AS source_table
          FROM contact_media_rows
          WHERE ({event_filter})
          GROUP BY event_date_iso, species
        ),
        contact_rows AS (
          SELECT
            name,
            kind,
            CASE
              WHEN instr(name, '/processed/') > 0 THEN
                substr(
                  substr(name, instr(name, '/processed/') + length('/processed/')),
                  1,
                  instr(substr(name, instr(name, '/processed/') + length('/processed/')) || '/', '/') - 1
                )
              ELSE name
            END AS processed_run,
            date(coalesce(updated, time_created)) AS event_date_iso
          FROM objects
          WHERE name >= 'contact_repel_videos/'
            AND name < 'contact_repel_videos0'
            AND name LIKE '%/processed/%'
            AND kind <> 'folder_marker'
        ),
        contact_groups AS (
          SELECT
            'contact_no_contact' AS assay_family,
            CASE
              WHEN name LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN name LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              ELSE 'unknown'
            END AS species,
            'contact/no-contact processed assay' AS assay_type,
            event_date_iso,
            {sql_literal(date_window)} AS date_window,
            'processed object updated date' AS date_basis,
            count(*) AS assay_rows,
            count(DISTINCT CASE WHEN processed_run NOT LIKE '%.%' THEN processed_run END) AS treatment_count,
            count(DISTINCT name) AS file_count,
            substr(group_concat(DISTINCT CASE WHEN processed_run NOT LIKE '%.%' THEN processed_run END), 1, 1000) AS treatments,
            min(name) AS example_source_name,
            NULL AS example_sheet,
            NULL AS first_row_number,
            'contact_repel_videos processed objects' AS evidence_home,
            'gs://monarch-videos-new/contact_repel_videos/' AS locator,
            'objects' AS source_table
          FROM contact_rows
          WHERE event_date_iso IS NOT NULL
            AND ({event_filter})
          GROUP BY event_date_iso, species
        ),
        oviposition_rows AS (
          SELECT
            name,
            kind,
            date(coalesce(updated, time_created)) AS event_date_iso
          FROM objects
          WHERE name >= 'flies/insect images '
            AND name < 'flies/insect images!'
            AND name LIKE 'flies/insect images %/Oviposition/%'
            AND kind <> 'folder_marker'
        ),
        oviposition_groups AS (
          SELECT
            'fly_oviposition' AS assay_family,
            'flies' AS species,
            'oviposition image assay' AS assay_type,
            event_date_iso,
            {sql_literal(date_window)} AS date_window,
            'object updated date' AS date_basis,
            count(*) AS assay_rows,
            0 AS treatment_count,
            count(DISTINCT name) AS file_count,
            NULL AS treatments,
            min(name) AS example_source_name,
            NULL AS example_sheet,
            NULL AS first_row_number,
            'flies oviposition image objects' AS evidence_home,
            'gs://monarch-videos-new/flies/insect images /Oviposition/' AS locator,
            'objects' AS source_table
          FROM oviposition_rows
          WHERE event_date_iso IS NOT NULL
            AND ({event_filter})
          GROUP BY event_date_iso
        ),
        phytotox_rows AS (
          SELECT
            name,
            row_number,
            json_extract(row_json, '$.date') AS phytotox_date,
            json_extract(row_json, '$.treatment_name') AS treatment_name,
            date(json_extract(row_json, '$.date')) AS event_date_iso
          FROM csv_rows
          WHERE name >= 'phytotoxicity/results/'
            AND name < 'phytotoxicity/results0'
            AND name LIKE 'phytotoxicity/results/%/predictions/analysis/features_all.csv'
        ),
        phytotox_groups AS (
          SELECT
            'phytotoxicity' AS assay_family,
            'plants' AS species,
            'phytotoxicity' AS assay_type,
            event_date_iso,
            {sql_literal(date_window)} AS date_window,
            'phytotoxicity result date' AS date_basis,
            count(*) AS assay_rows,
            count(DISTINCT treatment_name) AS treatment_count,
            count(DISTINCT name) AS file_count,
            group_concat(DISTINCT treatment_name) AS treatments,
            min(name) AS example_source_name,
            NULL AS example_sheet,
            min(row_number) AS first_row_number,
            'phytotoxicity features_all result rows' AS evidence_home,
            'gs://monarch-videos-new/' || min(name) AS locator,
            'csv_rows' AS source_table
          FROM phytotox_rows
          WHERE phytotox_date IS NOT NULL
            AND event_date_iso IS NOT NULL
            AND ({event_filter})
          GROUP BY event_date_iso
        ),
        all_assay_families AS (
          SELECT * FROM dart_groups
          UNION ALL SELECT * FROM fly_groups
          UNION ALL SELECT * FROM contact_media_groups
          UNION ALL SELECT * FROM contact_groups
          UNION ALL SELECT * FROM oviposition_groups
          UNION ALL SELECT * FROM phytotox_groups
        )
        SELECT
          assay_family,
          species,
          assay_type,
          event_date_iso AS assay_date_iso,
          date_window,
          date_basis,
          assay_rows,
          treatment_count,
          file_count,
          treatments,
          example_source_name,
          example_sheet,
          first_row_number,
          evidence_home,
          source_table,
          json_object(
            'grain_id', 'cross_assay_run:' || assay_family || ':' || coalesce(event_date_iso, 'unknown'),
            'grain_type', 'cross_assay_run_family',
            'locator', locator,
            'source_id', 'monarch_videos_new',
            'date_basis', date_basis,
            'source_table', source_table
          ) AS provenance_grain
        FROM all_assay_families
        {output_where}
        ORDER BY assay_date_iso DESC, assay_family, species, assay_type
    """


def _bucket_cross_assay_inventory_count_sql(question):
    q = question.lower()
    dart_assay_date_iso = _compact_assay_date_iso_sql("assay_date")
    fly_trial_date_iso = _compact_assay_date_iso_sql("trial_date")
    date_details = _assay_ledger_date_filter_details(question, "event_date_iso")
    event_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    species_scope = _assay_species_constraints_from_question(question)

    family_filters = []
    if _has_any(q, ["contact/no-contact", "contact / no contact", "contact and no contact", "contact and non-contact", "noncontact", "non contact", "no contact"]):
        family_filters.append("assay_family = 'contact_no_contact'")
    elif "dart" in q and "fly" not in q and "flies" not in q:
        family_filters.append("assay_family = 'dart'")
    elif "dart" in q and ("fly" in q or "flies" in q):
        family_filters.append("assay_family = 'fly_repellency'")
    elif _has_any(q, ["phytotoxicity", "phytotoxic", "phytoxic", "phytotox", "plant", "plants", "soybean", "leaf", "leaves"]):
        family_filters.append("assay_family = 'phytotoxicity'")
    elif _has_any(q, ["oviposition", "egg laying", "egg-laying"]):
        family_filters.append("assay_family = 'fly_oviposition'")

    result_filter = "preferred_count_unit = 1"
    count_unit = "source_native_assay_units"
    if _has_any(q, ["processed result", "processed results", "processed only", "with results", "has results", "adjusted pi exists", "frame metrics"]):
        result_filter = "processed_result_flag = 1"
        count_unit = "processed_result_rows"
    elif _has_any(q, ["raw video", "raw videos", "raw media", "per video", "video objects"]):
        result_filter = "raw_video_flag = 1"
        count_unit = "raw_video_objects"
    elif "assay_family = 'contact_no_contact'" in family_filters:
        count_unit = "raw_video_objects"

    asks_contact_pair = _has_any(q, ["complete pair", "complete pairs", "complete contact and non-contact", "complete contact and no contact", "paired", "pairing", "both contact and non-contact", "both contact and no contact"])
    contact_mode_filter = ""
    if _has_any(q, ["contact/no-contact", "contact / no contact", "contact and no contact", "contact and non-contact", "both contact", "noncontact", "non contact", "no contact"]):
        contact_mode_filter = "AND assay_mode IN ('contact', 'non-contact')"

    filters = [f"({event_filter})", result_filter]
    if species_scope:
        filters.append("species IN (" + ", ".join(sql_literal(species) for species in species_scope) + ")")
    filters.extend(family_filters)
    if contact_mode_filter:
        filters.append(contact_mode_filter[4:].strip())
    where_sql = " AND ".join(filters)

    group_mode = "assay_mode"
    group_columns = "assay_family, species, assay_type, assay_mode"
    select_mode = "assay_mode"
    count_unit_sql = "group_concat(DISTINCT native_count_unit)"
    if asks_contact_pair:
        count_unit = "complete_contact_non_contact_pairs"
        group_columns = "assay_family, species"
        select_mode = "'contact_and_non_contact' AS assay_mode"
        count_unit_sql = sql_literal(count_unit)
    elif count_unit != "source_native_assay_units":
        count_unit_sql = sql_literal(count_unit)

    if asks_contact_pair:
        return f"""
            WITH raw_contact AS (
              SELECT
                CASE
                  WHEN lower(name) LIKE 'contact_repel_videos/flies/%' THEN 'flies'
                  WHEN lower(name) LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
                  ELSE 'unknown'
                END AS species,
                CASE
                  WHEN lower(name) LIKE '%noncontact%' OR lower(name) LIKE '%non_contact%' OR lower(name) LIKE '%no_contact%' THEN 'non-contact'
                  WHEN lower(name) LIKE '%contact%' OR lower(name) LIKE '%conatct%' THEN 'contact'
                  ELSE NULL
                END AS assay_mode,
                CASE
                  WHEN lower(name) LIKE '%mosquitoes_new_solvent/%' THEN 'mosquitoes_new_solvent'
                  WHEN lower(name) LIKE '%mosquitoes/%' THEN 'mosquitoes_legacy'
                  WHEN lower(name) LIKE '%flies/%' THEN 'flies_contact'
                  ELSE 'unknown'
                END AS protocol_version,
                date(coalesce(updated, time_created)) AS event_date_iso,
                coalesce(updated, time_created) AS evidence_time,
                lower(
                  replace(
                    replace(
                      replace(
                        replace(
                          replace(
                            replace(name, '_NonContact_', '_PAIR_'),
                            '_Noncontact_', '_PAIR_'
                          ),
                          '_non_contact_', '_PAIR_'
                        ),
                        '_Contact_', '_PAIR_'
                      ),
                      '_contact_', '_PAIR_'
                    ),
                    '_Conatct_', '_PAIR_'
                  )
                ) AS pair_key,
                name,
                uri
              FROM objects
              WHERE kind = 'video'
                AND name LIKE 'contact_repel_videos/%'
                AND lower(name) NOT LIKE '%/processed/%'
                AND lower(name) NOT LIKE '%control%'
                AND (
                  lower(name) LIKE '%noncontact%'
                  OR lower(name) LIKE '%non_contact%'
                  OR lower(name) LIKE '%no_contact%'
                  OR lower(name) LIKE '%_contact_%'
                  OR lower(name) LIKE '%_conatct_%'
                )
            ),
            pairs AS (
              SELECT
                'contact_no_contact' AS assay_family,
                species,
                'complete contact/no-contact pair' AS assay_type,
                {select_mode},
                {sql_literal(date_window)} AS date_window,
                'bucket_object_updated_or_created_time' AS date_basis,
                min(event_date_iso) AS event_date_iso,
                min(evidence_time) AS first_evidence_time,
                max(evidence_time) AS latest_evidence_time,
                pair_key,
                group_concat(DISTINCT protocol_version) AS protocol_versions,
                count(DISTINCT assay_mode) AS modes_present,
                count(*) AS raw_video_count,
                min(uri) AS example_locator
              FROM raw_contact
              WHERE event_date_iso IS NOT NULL
                AND ({event_filter})
                {("AND species IN (" + ", ".join(sql_literal(species) for species in species_scope) + ")") if species_scope else ""}
              GROUP BY species, pair_key
              HAVING modes_present = 2
            )
            SELECT
              assay_family,
              species,
              assay_type,
              assay_mode,
              date_window,
              date_basis,
              {sql_literal(count_unit)} AS count_unit,
              count(*) AS assay_count,
              count(*) AS complete_pair_count,
              sum(raw_video_count) AS raw_video_count,
              0 AS processed_result_count,
              count(*) AS run_count,
              count(DISTINCT pair_key) AS deduped_unit_count,
              min(first_evidence_time) AS first_evidence_time,
              max(latest_evidence_time) AS latest_evidence_time,
              group_concat(DISTINCT protocol_versions) AS protocol_versions,
              min(example_locator) AS example_locator,
              json_object(
                'grain_id', 'assay_inventory_count:contact_no_contact_pairs:' || species || ':' || {sql_literal(date_window)},
                'grain_type', 'assay_inventory_count',
                'locator', min(example_locator),
                'source_id', 'monarch_videos_new',
                'count_unit', {sql_literal(count_unit)},
                'date_window', {sql_literal(date_window)}
              ) AS provenance_grain
            FROM pairs
            GROUP BY assay_family, species
            ORDER BY species, assay_type
        """

    return f"""
        WITH dart_units AS (
          SELECT
            'dart' AS assay_family,
            species,
            assay_type,
            'dart' AS assay_mode,
            treatment_normalized AS compound,
            {dart_assay_date_iso} AS event_date_iso,
            'assay_date' AS date_basis,
            'dart_assay_results table' AS evidence_home,
            source_name || '#row=' || row_number AS unit_id,
            filename AS file_key,
            CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END AS processed_result_flag,
            0 AS raw_video_flag,
            1 AS preferred_count_unit,
            'dart_ledger_rows' AS native_count_unit,
            'dart_workbook' AS protocol_version,
            'dart_assay_results#row=' || row_number AS locator
          FROM dart_assay_results
          WHERE assay_date IS NOT NULL
        ),
        fly_trial_rows AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'A%' THEN value END) AS trial_date,
            max(CASE WHEN cell LIKE 'N%' THEN value END) AS compound,
            max(CASE WHEN cell LIKE 'B%' THEN value END) AS file_key,
            'flies/repellency_screen_metadata_sheet.xlsx#row=' || row_number AS unit_id
          FROM xlsx_cells_with_provenance
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet = 'trials'
            AND row_number > 1
          GROUP BY row_number
        ),
        fly_units AS (
          SELECT
            'fly_repellency' AS assay_family,
            'flies' AS species,
            'fly repellency screen' AS assay_type,
            'fly_repellency' AS assay_mode,
            compound,
            {fly_trial_date_iso} AS event_date_iso,
            'flies metadata trial date' AS date_basis,
            'flies repellency metadata workbook' AS evidence_home,
            unit_id,
            file_key,
            0 AS processed_result_flag,
            0 AS raw_video_flag,
            1 AS preferred_count_unit,
            'fly_metadata_trial_rows' AS native_count_unit,
            'flies_metadata_workbook' AS protocol_version,
            'gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#sheet=trials&row=' || row_number AS locator
          FROM fly_trial_rows
        ),
        contact_raw_units AS (
          SELECT
            'contact_no_contact' AS assay_family,
            CASE
              WHEN lower(name) LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN lower(name) LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              WHEN lower(name) LIKE 'contact_repel_videos/beetles/%' THEN 'beetles'
              WHEN lower(name) LIKE 'contact_repel_videos/moths/%' THEN 'moths'
              ELSE 'unknown'
            END AS species,
            'raw contact/no-contact video' AS assay_type,
            CASE
              WHEN lower(name) LIKE '%noncontact%' OR lower(name) LIKE '%non_contact%' OR lower(name) LIKE '%no_contact%' THEN 'non-contact'
              WHEN lower(name) LIKE '%contact%' OR lower(name) LIKE '%conatct%' THEN 'contact'
              ELSE 'unknown'
            END AS assay_mode,
            NULL AS compound,
            date(coalesce(updated, time_created)) AS event_date_iso,
            'bucket_object_updated_or_created_time' AS date_basis,
            'contact_repel_videos raw video objects' AS evidence_home,
            name AS unit_id,
            name AS file_key,
            0 AS processed_result_flag,
            1 AS raw_video_flag,
            1 AS preferred_count_unit,
            'raw_video_objects' AS native_count_unit,
            CASE
              WHEN lower(name) LIKE '%mosquitoes_new_solvent/%' THEN 'mosquitoes_new_solvent'
              WHEN lower(name) LIKE '%mosquitoes/%' THEN 'mosquitoes_legacy'
              WHEN lower(name) LIKE '%flies/%' THEN 'flies_contact'
              ELSE 'unknown'
            END AS protocol_version,
            coalesce(uri, 'gs://monarch-videos-new/' || name) AS locator
          FROM objects
          WHERE kind = 'video'
            AND name LIKE 'contact_repel_videos/%'
            AND lower(name) NOT LIKE '%/processed/%'
            AND lower(name) NOT LIKE '%control%'
            AND (
              lower(name) LIKE '%noncontact%'
              OR lower(name) LIKE '%non_contact%'
              OR lower(name) LIKE '%no_contact%'
              OR lower(name) LIKE '%_contact_%'
              OR lower(name) LIKE '%_conatct_%'
            )
        ),
        contact_processed_files AS (
          SELECT DISTINCT name
          FROM csv_columns_with_provenance
          WHERE name >= 'contact_repel_videos/'
            AND name < 'contact_repel_videos0'
            AND (
              name LIKE '%combined_results%.csv'
              OR name LIKE '%adjusted_contact_pi_summary.csv'
            )
        ),
        contact_processed_units AS (
          SELECT
            'contact_no_contact' AS assay_family,
            CASE
              WHEN rows.name LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN rows.name LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              ELSE 'unknown'
            END AS species,
            'contact/no-contact processed result row' AS assay_type,
            CASE
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%noncontact%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%non_contact%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%no_contact%' THEN 'non-contact'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%contact%' THEN 'contact'
              ELSE 'unknown'
            END AS assay_mode,
            json_extract(rows.row_json, '$.video_stem') AS compound,
            date(coalesce(objects.updated, objects.time_created)) AS event_date_iso,
            'processed_object_updated' AS date_basis,
            'contact_repel_videos processed result CSV rows' AS evidence_home,
            rows.name || '#row=' || rows.row_number AS unit_id,
            rows.name AS file_key,
            1 AS processed_result_flag,
            0 AS raw_video_flag,
            0 AS preferred_count_unit,
            'processed_result_rows' AS native_count_unit,
            CASE
              WHEN lower(rows.name) LIKE '%mosquitoes_new_solvent/%' THEN 'mosquitoes_new_solvent'
              WHEN lower(rows.name) LIKE '%mosquitoes/%' THEN 'mosquitoes_legacy'
              WHEN lower(rows.name) LIKE '%flies/%' THEN 'flies_contact'
              ELSE 'unknown'
            END AS protocol_version,
            'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number AS locator
          FROM contact_processed_files files
          JOIN csv_rows_with_provenance rows ON rows.name = files.name
          LEFT JOIN objects ON objects.name = rows.name
          WHERE lower(coalesce(json_extract(rows.row_json, '$.is_control'), '')) NOT IN ('true', '1', 'yes')
        ),
        fly_processed_files AS (
          SELECT DISTINCT name
          FROM csv_columns_with_provenance
          WHERE name LIKE 'flies/processed/%/corrected/pi_correction_summary.csv'
        ),
        fly_processed_units AS (
          SELECT
            'fly_repellency' AS assay_family,
            'flies' AS species,
            'fly repellency processed PI correction' AS assay_type,
            'fly_repellency' AS assay_mode,
            json_extract(rows.row_json, '$.treatment') AS compound,
            date(substr(rows.name, instr(rows.name, 'processed/') + length('processed/'), 10)) AS event_date_iso,
            'processed_result_path_date' AS date_basis,
            'flies processed PI correction summaries' AS evidence_home,
            rows.name || '#row=' || rows.row_number AS unit_id,
            rows.name AS file_key,
            1 AS processed_result_flag,
            0 AS raw_video_flag,
            0 AS preferred_count_unit,
            'processed_result_rows' AS native_count_unit,
            'flies_processed' AS protocol_version,
            'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number AS locator
          FROM fly_processed_files files
          JOIN csv_rows rows ON rows.name = files.name
        ),
        phytotox_files AS (
          SELECT DISTINCT name
          FROM csv_columns_with_provenance
          WHERE name >= 'phytotoxicity/results/'
            AND name < 'phytotoxicity/results0'
            AND name LIKE 'phytotoxicity/results/%/predictions/analysis/features_all.csv'
        ),
        oviposition_units AS (
          SELECT
            'fly_oviposition' AS assay_family,
            'flies' AS species,
            'oviposition image assay' AS assay_type,
            'oviposition' AS assay_mode,
            NULL AS compound,
            date(coalesce(updated, time_created)) AS event_date_iso,
            'object_updated_date' AS date_basis,
            'flies oviposition image objects' AS evidence_home,
            name AS unit_id,
            name AS file_key,
            0 AS processed_result_flag,
            1 AS raw_video_flag,
            1 AS preferred_count_unit,
            'image_objects' AS native_count_unit,
            'oviposition_images' AS protocol_version,
            coalesce(uri, 'gs://monarch-videos-new/' || name) AS locator
          FROM objects
          WHERE name >= 'flies/insect images '
            AND name < 'flies/insect images!'
            AND name LIKE 'flies/insect images %/Oviposition/%'
            AND kind <> 'folder_marker'
        ),
        phytotox_units AS (
          SELECT
            'phytotoxicity' AS assay_family,
            'plants' AS species,
            'phytotoxicity' AS assay_type,
            'phytotoxicity' AS assay_mode,
            json_extract(rows.row_json, '$.treatment_name') AS compound,
            date(json_extract(rows.row_json, '$.date')) AS event_date_iso,
            'phytotoxicity_result_date' AS date_basis,
            'phytotoxicity features_all result rows' AS evidence_home,
            rows.name || '#row=' || rows.row_number AS unit_id,
            rows.name AS file_key,
            1 AS processed_result_flag,
            0 AS raw_video_flag,
            1 AS preferred_count_unit,
            'phytotoxicity_result_rows' AS native_count_unit,
            'phytotoxicity_predictions' AS protocol_version,
            'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number AS locator
          FROM phytotox_files files
          JOIN csv_rows rows ON rows.name = files.name
        ),
        all_units AS (
          SELECT * FROM dart_units
          UNION ALL SELECT * FROM fly_units
          UNION ALL SELECT * FROM contact_raw_units
          UNION ALL SELECT * FROM contact_processed_units
          UNION ALL SELECT * FROM fly_processed_units
          UNION ALL SELECT * FROM oviposition_units
          UNION ALL SELECT * FROM phytotox_units
        ),
        filtered_units AS (
          SELECT *
          FROM all_units
          WHERE event_date_iso IS NOT NULL
            AND ({where_sql})
        )
        SELECT
          assay_family,
          species,
          assay_type,
          {select_mode},
          {sql_literal(date_window)} AS date_window,
          group_concat(DISTINCT date_basis) AS date_basis,
          {count_unit_sql} AS count_unit,
          count(*) AS assay_count,
          count(DISTINCT unit_id) AS unit_count,
          count(DISTINCT file_key) AS file_count,
          count(DISTINCT compound) AS treatment_count,
          count(DISTINCT compound) AS compound_count,
          count(DISTINCT event_date_iso || ':' || assay_family || ':' || species || ':' || coalesce(assay_mode, '')) AS run_count,
          sum(raw_video_flag) AS raw_video_count,
          sum(processed_result_flag) AS processed_result_count,
          min(event_date_iso) AS first_evidence_date,
          max(event_date_iso) AS latest_evidence_date,
          min(locator) AS example_locator,
          group_concat(DISTINCT native_count_unit) AS native_count_units,
          group_concat(DISTINCT protocol_version) AS protocol_versions,
          group_concat(DISTINCT evidence_home) AS evidence_homes,
          json_object(
            'grain_id', 'assay_inventory_count:' || assay_family || ':' || species || ':' || coalesce({group_mode}, 'all') || ':' || {sql_literal(date_window)},
            'grain_type', 'assay_inventory_count',
            'locator', min(locator),
            'source_id', 'monarch_videos_new',
            'count_unit', {count_unit_sql},
            'date_window', {sql_literal(date_window)}
          ) AS provenance_grain
        FROM filtered_units
        GROUP BY {group_columns}
        ORDER BY latest_evidence_date DESC, assay_family, species, assay_type, assay_mode
    """


def _bucket_experiments_by_run_date_sql(question):
    assay_date_iso = _compact_assay_date_iso_sql("assay_date")
    date_details = _assay_ledger_date_filter_details(question, "assay_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    return f"""
        WITH normalized_assays AS (
          SELECT
            *,
            {assay_date_iso} AS assay_date_iso
          FROM dart_assay_results
          WHERE assay_date IS NOT NULL
        )
        SELECT
          assay_date,
          species,
          assay_type,
          min(assay_date_iso) AS assay_date_iso,
          {sql_literal(date_window)} AS date_window,
          count(*) AS assay_rows,
          count(DISTINCT treatment_normalized) AS treatment_count,
          count(DISTINCT filename) AS filename_count,
          min(source_name) AS example_source_name,
          min(sheet) AS example_sheet,
          min(row_number) AS first_row_number,
          group_concat(DISTINCT treatment_normalized) AS treatments,
          json_object(
            'grain_id', 'bucket_run_date:' || coalesce(assay_date, 'unknown') || ':' || coalesce(species, 'unknown') || ':' || coalesce(assay_type, 'unknown'),
            'grain_type', 'dart_assay_run_date_group',
            'locator', 'dart_assay_results#assay_date=' || coalesce(assay_date, 'unknown'),
            'source_id', 'monarch_videos_new'
          ) AS provenance_grain
        FROM normalized_assays
        WHERE assay_date IS NOT NULL
          AND assay_date_iso IS NOT NULL
          AND ({date_filter})
        GROUP BY assay_date, species, assay_type
        ORDER BY assay_date_iso DESC, assay_rows DESC, species, assay_type
    """


def _bucket_compounds_tested_by_date_window_applies(question):
    q = question.lower()
    has_compound_target = _has_any(q, [
        "compound",
        "compounds",
        "chemical",
        "chemicals",
        "treatment",
        "treatments",
    ])
    has_tested_action = _has_any(q, [
        "tested",
        "test",
        "assay",
        "assayed",
        "screened",
        "screen",
        "experiment",
        "experiments",
        "run",
        "ran",
    ])
    has_time_window = (
        bool(re.search(r"\b(?:last|past)\s+(?:\d+|one|two|couple)\s+(?:day|days|week|weeks)\b", q))
        or _has_any(q, ["today", "yesterday", "last week", "this week", "recent", "lately"])
    )
    return has_compound_target and has_tested_action and has_time_window


def _bucket_compounds_tested_all_structured_applies(question):
    q = question.lower()
    if _bucket_compounds_tested_by_date_window_applies(question):
        return False
    has_compound_target = _has_any(q, [
        "compound",
        "compounds",
        "chemical",
        "chemicals",
        "treatment",
        "treatments",
    ])
    has_tested_action = _has_any(q, [
        "tested",
        "test",
        "assay",
        "assayed",
        "screened",
        "screen",
        "experiment",
        "experiments",
        "run",
        "ran",
    ])
    asks_for_list = _has_any(q, ["all", "list", "what", "which", "show"])
    return has_compound_target and has_tested_action and asks_for_list


def _bucket_compounds_tested_all_structured_sql():
    return _bucket_tested_compounds_structured_sql()


def _bucket_compounds_tested_by_date_window_sql(question):
    assay_date_iso = _compact_assay_date_iso_sql("assay_date")
    return _bucket_tested_compounds_structured_sql(question, dart_assay_date_iso=assay_date_iso)


def _bucket_tested_compounds_structured_sql(question=None, dart_assay_date_iso=None):
    q = str(question or "").lower()
    if question:
        date_filter, date_window = _assay_ledger_date_filter_sql(question, "normalized_evidence_date")
    else:
        date_filter, date_window = "1 = 1", "all_structured_assay_evidence"
    today_cutoff = sql_literal(_local_today().isoformat())
    aggregate_grain_type = "tested_compound_window" if question else "tested_compound_all"
    order_by = "tested_compound COLLATE NOCASE"
    if _has_any(q, ["recent", "recently", "latest", "most recent", "last"]):
        order_by = "normalized_latest_evidence_date DESC, tested_compound COLLATE NOCASE"
    dart_date = dart_assay_date_iso or _compact_assay_date_iso_sql("assay_date")
    return f"""
        WITH tested AS (
          SELECT
            coalesce(nullif(trim(treatment_normalized), ''), nullif(trim(treatment), '')) AS tested_compound,
            'dart_assay_results' AS source_family,
            species,
            assay_type,
            assay_date AS evidence_date,
            {dart_date} AS normalized_evidence_date,
            'assay_date' AS date_basis,
            'gs://monarch-videos-new/' || source_name || '#sheet=' || sheet || '&row=' || row_number AS locator,
            json_object(
              'grain_id', source_name || '#sheet=' || sheet || '&row=' || row_number,
              'grain_type', 'dart_assay_row',
              'locator', 'gs://monarch-videos-new/' || source_name || '#sheet=' || sheet || '&row=' || row_number,
              'source_id', 'monarch_videos_new'
            ) AS provenance_grain
          FROM dart_assay_results
          WHERE assay_date IS NOT NULL
          UNION ALL
          SELECT
            trim(value) AS tested_compound,
            'fly_repellency_trials' AS source_family,
            'flies' AS species,
            'repellency_screen' AS assay_type,
            NULL AS evidence_date,
            NULL AS normalized_evidence_date,
            'metadata_workbook_row' AS date_basis,
            'gs://monarch-videos-new/' || name || '#sheet=' || sheet || '&row=' || row_number AS locator,
            provenance_grain
          FROM xlsx_cells_with_provenance
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet = 'trials'
            AND cell LIKE 'N%'
            AND row_number >= 2
          UNION ALL
          SELECT
            trim(json_extract(row_json, '$.treatment_name')) AS tested_compound,
            'phytotoxicity_results' AS source_family,
            'plants' AS species,
            'phytotoxicity' AS assay_type,
            json_extract(row_json, '$.date') AS evidence_date,
            date(json_extract(row_json, '$.date')) AS normalized_evidence_date,
            'result_row_date' AS date_basis,
            'gs://monarch-videos-new/' || name || '#row=' || row_number AS locator,
            json_object(
              'grain_id', name || '#row=' || row_number,
              'grain_type', 'csv_row',
              'locator', 'gs://monarch-videos-new/' || name || '#row=' || row_number,
              'source_id', 'monarch_videos_new'
            ) AS provenance_grain
          FROM csv_rows
          WHERE name >= 'phytotoxicity/results/'
            AND name < 'phytotoxicity/results0'
            AND name LIKE 'phytotoxicity/results/%/predictions/analysis/features_all.csv'
            AND json_extract(row_json, '$.treatment_name') IS NOT NULL
          UNION ALL
          SELECT
            CASE
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%1c4eb%' THEN '1C4EB'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%2pp%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%2propylphenol%' THEN '2PP'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%3pp%' THEN '3PP'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%4pp%' THEN '4PP'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%bcaryo%' THEN 'Bcaryo'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%bhcyclo%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%bhomocyclo%' THEN 'BHomocyclo'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%bcyclo%' THEN 'Bcyclo'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%butacet%' THEN 'ButAcet'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%deet%' THEN 'DEET'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%eugenol%' THEN 'Eugenol'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%i3pp%' THEN 'I3PP'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%ir3535%' THEN 'IR3535'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%menthone%' THEN 'Menthone'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%menthol%' THEN 'Menthol'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%mnda%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%mndanthra%' THEN 'MNDA'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%methanth%' THEN 'MethAnth'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%oct%' THEN '1O3OL'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%pea%' THEN 'PEA'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%pepoil%' THEN 'PepOil'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%phpramide%' THEN 'PhPrAmide'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%picaridin%' THEN 'Picaridin'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%thymol%' THEN 'Thymol'
            END AS tested_compound,
            'contact_no_contact_processed_results' AS source_family,
            CASE
              WHEN rows.name LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN rows.name LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              ELSE 'unknown'
            END AS species,
            CASE
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%noncontact%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%non_contact%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%no_contact%' THEN 'contact_repellency_non_contact'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%contact%' THEN 'contact_repellency_contact'
              ELSE 'contact_repellency_processed'
            END AS assay_type,
            objects.updated AS evidence_date,
            date(objects.updated) AS normalized_evidence_date,
            'processed_object_updated' AS date_basis,
            'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number AS locator,
            rows.provenance_grain
          FROM csv_rows_with_provenance rows
          LEFT JOIN objects ON objects.name = rows.name
          WHERE rows.name >= 'contact_repel_videos/'
            AND rows.name < 'contact_repel_videos0'
            AND rows.name LIKE '%combined_results%.csv'
            AND lower(coalesce(json_extract(rows.row_json, '$.is_control'), '')) != 'true'
        )
        SELECT
          tested_compound,
          group_concat(DISTINCT source_family) AS source_families,
          group_concat(DISTINCT species) AS species,
          group_concat(DISTINCT assay_type) AS assay_types,
          {sql_literal(date_window)} AS date_window,
          group_concat(DISTINCT date_basis) AS date_bases,
          min(evidence_date) AS first_evidence_date,
          max(evidence_date) AS latest_evidence_date,
          max(normalized_evidence_date) AS normalized_latest_evidence_date,
          count(*) AS evidence_rows,
          min(locator) AS example_locator,
          min(provenance_grain) AS example_provenance,
          min(provenance_grain) AS example_provenance_grain,
          json_object(
            'grain_id', {sql_literal(aggregate_grain_type)} || ':' || lower(trim(tested_compound)) || ':' || {sql_literal(date_window)},
            'grain_type', {sql_literal(aggregate_grain_type)},
            'locator', min(locator),
            'source_id', 'monarch_videos_new',
            'date_window', {sql_literal(date_window)}
          ) AS provenance_grain
        FROM tested
        WHERE tested_compound IS NOT NULL
          AND trim(tested_compound) <> ''
          AND lower(trim(tested_compound)) NOT IN (
            'control', 'ctrl', 'vehicle control', 'water', 'solvent', 'none', 'na', 'n/a',
            'failed', 'seed'
          )
          AND (
            normalized_evidence_date IS NULL
            OR date(normalized_evidence_date) <= date({today_cutoff})
          )
          AND ({date_filter})
        GROUP BY lower(trim(tested_compound))
        ORDER BY {order_by}
    """


def _bucket_top_repellents_by_species_sql(question):
    species = species_from_question(question)
    if not species:
        return None
    q = question.lower()
    if not _has_any(q, ["repellent", "repellents", "repellency", "strongest", "top", "most"]):
        return None
    if not _has_any(q, ["assay", "assays", "compound", "compounds", "chemical", "chemicals", "treatment", "treatments", "swd", "mosquito", "flies", "fly"]):
        return None
    assay_date_iso = _compact_assay_date_iso_sql("assay_date")
    date_details = _optional_assay_date_filter_details(question, "assay_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    return f"""
        WITH species_rows AS (
          SELECT
            *,
            {assay_date_iso} AS assay_date_iso
          FROM dart_assay_results
          WHERE lower(species) = lower({sql_literal(species)})
        ),
        scored AS (
          SELECT *
          FROM species_rows
          WHERE avg_pi_real IS NOT NULL
        ),
        filtered AS (
          SELECT *
          FROM scored
          WHERE assay_date_iso IS NOT NULL
            AND ({date_filter})
        ),
        ranked AS (
          SELECT
            species,
            assay_type,
            treatment_normalized,
            {sql_literal(date_window)} AS date_window,
            count(*) AS scored_rows,
            count(DISTINCT dilution_real) AS dilution_count,
            avg(avg_pi_real) AS mean_avg_pi,
            CASE
              WHEN count(avg_pi_real) > 1 THEN sqrt(
                (sum(avg_pi_real * avg_pi_real) - (sum(avg_pi_real) * sum(avg_pi_real) / count(avg_pi_real)))
                / (count(avg_pi_real) - 1)
              )
              ELSE NULL
            END AS standard_deviation,
            CASE
              WHEN count(avg_pi_real) > 1 THEN sqrt(
                ((sum(avg_pi_real * avg_pi_real) - (sum(avg_pi_real) * sum(avg_pi_real) / count(avg_pi_real)))
                / (count(avg_pi_real) - 1))
                / count(avg_pi_real)
              )
              ELSE NULL
            END AS standard_error,
            'sample_stddev_of_avg_pi_real_across_dart_rows' AS standard_deviation_basis,
            min(avg_pi_real) AS best_single_avg_pi,
            max(avg_pi_real) AS least_repellent_single_avg_pi,
            min(assay_date_iso) AS first_assay_date,
            max(assay_date_iso) AS latest_assay_date,
            group_concat(DISTINCT dilution) AS dilutions
          FROM filtered
          GROUP BY species, assay_type, treatment_normalized
        ),
        window_summary AS (
          SELECT
            lower({sql_literal(species)}) AS species,
            'DART' AS assay_type,
            {sql_literal(date_window)} AS date_window,
            count(*) AS assay_rows_in_window,
            count(avg_pi_real) AS scored_rows_in_window,
            min(assay_date_iso) AS first_assay_date,
            max(assay_date_iso) AS latest_assay_date,
            min(source_name) AS example_source_name,
            min(sheet) AS example_sheet,
            min(row_number) AS example_row_number,
            min(filename) AS example_filename,
            min(provenance_grain) AS example_provenance_grain
          FROM species_rows
          WHERE assay_date_iso IS NOT NULL
            AND ({date_filter})
        )
        SELECT
          'ranked' AS ranking_status,
          r.species,
          r.assay_type,
          r.treatment_normalized,
          r.date_window,
          r.scored_rows,
          r.scored_rows AS scored_rows_in_window,
          r.scored_rows AS assay_rows_in_window,
          r.dilution_count,
          r.mean_avg_pi,
          r.standard_deviation,
          r.standard_error,
          r.standard_deviation_basis,
          r.best_single_avg_pi,
          r.least_repellent_single_avg_pi,
          r.first_assay_date,
          r.latest_assay_date,
          r.dilutions,
          d.source_name AS example_source_name,
          d.sheet AS example_sheet,
          d.row_number AS example_row_number,
          d.filename AS example_filename,
          d.provenance_grain AS example_provenance_grain
        FROM ranked r
        LEFT JOIN filtered d
          ON d.species = r.species
         AND d.assay_type = r.assay_type
         AND d.treatment_normalized = r.treatment_normalized
         AND d.avg_pi_real = r.best_single_avg_pi
        UNION ALL
        SELECT
          'no_rankable_rows' AS ranking_status,
          species,
          assay_type,
          NULL AS treatment_normalized,
          date_window,
          0 AS scored_rows,
          scored_rows_in_window,
          assay_rows_in_window,
          0 AS dilution_count,
          NULL AS mean_avg_pi,
          NULL AS standard_deviation,
          NULL AS standard_error,
          'no_rankable_rows' AS standard_deviation_basis,
          NULL AS best_single_avg_pi,
          NULL AS least_repellent_single_avg_pi,
          first_assay_date,
          latest_assay_date,
          NULL AS dilutions,
          example_source_name,
          example_sheet,
          example_row_number,
          example_filename,
          example_provenance_grain
        FROM window_summary
        WHERE scored_rows_in_window = 0
        ORDER BY ranking_status DESC, mean_avg_pi ASC, scored_rows DESC, treatment_normalized
    """


def _bucket_fly_repellency_rankings_sql(question):
    species = species_from_question(question)
    if species != "flies":
        return None
    q = question.lower()
    if not _has_any(q, ["repellent", "repellents", "repellency", "strongest", "top", "most"]):
        return None
    if not _has_any(q, ["assay", "assays", "compound", "compounds", "chemical", "chemicals", "treatment", "treatments", "swd", "flies", "fly"]):
        return None
    date_details = _optional_assay_date_filter_details(question, "event_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    date_required_filter = "AND coalesce(catalog.evidence_experiments, 0) > 0" if date_window != "all_time" else ""
    return f"""
        WITH catalog_rows AS (
          SELECT
            json_extract(row_json, '$.treatment_label') AS treatment_label,
            date(substr(json_extract(row_json, '$.experiment'), 1, 10)) AS event_date_iso,
            name AS catalog_source_name,
            row_number AS catalog_row_number,
            provenance_grain AS catalog_provenance_grain
          FROM csv_rows_with_provenance
          WHERE name = 'flies/summary/agg_summary/experiment_catalog.csv'
            AND json_extract(row_json, '$.treatment_label') IS NOT NULL
        ),
        catalog_filtered AS (
          SELECT *
          FROM catalog_rows
          WHERE event_date_iso IS NOT NULL
            AND ({date_filter})
        ),
        catalog AS (
          SELECT
            treatment_label,
            count(*) AS evidence_experiments,
            min(event_date_iso) AS first_assay_date,
            max(event_date_iso) AS latest_assay_date,
            min(catalog_source_name) AS catalog_source_name,
            min(catalog_row_number) AS catalog_row_number,
            min(catalog_provenance_grain) AS catalog_provenance_grain
          FROM catalog_filtered
          GROUP BY treatment_label
        ),
        ranked_rows AS (
          SELECT
            'ranked' AS ranking_status,
            'flies' AS species,
            json_extract(rows.row_json, '$.treatment_label') AS treatment_label,
            json_extract(rows.row_json, '$.direction') AS direction,
            {sql_literal(date_window)} AS date_window,
            'fly_experiment_catalog_experiment_date' AS date_basis,
            catalog.first_assay_date,
            catalog.latest_assay_date,
            CAST(json_extract(rows.row_json, '$.composite_score') AS REAL) AS composite_score,
            CAST(json_extract(rows.row_json, '$.trt_pi_grand_mean') AS REAL) AS trt_pi_grand_mean,
            CAST(json_extract(rows.row_json, '$.trt_pi_sem') AS REAL) AS trt_pi_sem,
            CASE
              WHEN CAST(json_extract(rows.row_json, '$.n_replicates') AS INTEGER) > 1
                AND json_extract(rows.row_json, '$.trt_pi_sem') IS NOT NULL
              THEN CAST(json_extract(rows.row_json, '$.trt_pi_sem') AS REAL)
                * sqrt(CAST(json_extract(rows.row_json, '$.n_replicates') AS INTEGER))
              ELSE NULL
            END AS standard_deviation,
            CAST(json_extract(rows.row_json, '$.trt_pi_sem') AS REAL) AS standard_error,
            'trt_pi_sem_times_sqrt_n_replicates' AS standard_deviation_basis,
            CAST(json_extract(rows.row_json, '$.ex_trt_pi_grand_mean') AS REAL) AS ex_trt_pi_grand_mean,
            CAST(json_extract(rows.row_json, '$.ex_trt_pi_sem') AS REAL) AS ex_trt_pi_sem,
            CAST(json_extract(rows.row_json, '$.centroid_mean') AS REAL) AS centroid_mean,
            CAST(json_extract(rows.row_json, '$.avoidance_mean') AS REAL) AS avoidance_mean,
            CAST(json_extract(rows.row_json, '$.n_experiments') AS INTEGER) AS n_experiments,
            CAST(json_extract(rows.row_json, '$.n_replicates') AS INTEGER) AS n_replicates,
            coalesce(catalog.evidence_experiments, 0) AS assay_rows_in_window,
            coalesce(catalog.evidence_experiments, 0) AS scored_rows_in_window,
            coalesce(catalog.evidence_experiments, 0) AS evidence_experiments_in_window,
            rows.name AS source_name,
            rows.row_number,
            rows.provenance_grain AS source_provenance_grain,
            json_object(
              'grain_id', 'fly_repellency_ranking:' || json_extract(rows.row_json, '$.treatment_label') || ':' || {sql_literal(date_window)},
              'grain_type', 'fly_repellency_ranking_row',
              'locator', 'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number,
              'source_id', 'monarch_videos_new',
              'source_csv', rows.name,
              'date_window', {sql_literal(date_window)},
              'date_basis', 'fly_experiment_catalog_experiment_date',
              'standard_deviation_basis', 'trt_pi_sem_times_sqrt_n_replicates',
              'catalog_locator', 'gs://monarch-videos-new/' || catalog.catalog_source_name || '#row=' || catalog.catalog_row_number
            ) AS provenance_grain
          FROM csv_rows_with_provenance rows
          LEFT JOIN catalog ON catalog.treatment_label = json_extract(rows.row_json, '$.treatment_label')
          WHERE rows.name = 'flies/summary/agg_summary/top_performing_chemicals.csv'
            AND lower(json_extract(rows.row_json, '$.direction')) = 'repellent'
            {date_required_filter}
        ),
        window_summary AS (
          SELECT
            count(*) AS assay_rows_in_window,
            count(DISTINCT treatment_label) AS scored_rows_in_window,
            min(event_date_iso) AS first_assay_date,
            max(event_date_iso) AS latest_assay_date,
            min(catalog_source_name) AS example_source_name,
            min(catalog_row_number) AS example_row_number,
            min(catalog_provenance_grain) AS example_provenance_grain
          FROM catalog_filtered
        )
        SELECT *
        FROM ranked_rows
        UNION ALL
        SELECT
          'no_rankable_rows' AS ranking_status,
          'flies' AS species,
          NULL AS treatment_label,
          NULL AS direction,
          {sql_literal(date_window)} AS date_window,
          'fly_experiment_catalog_experiment_date' AS date_basis,
          first_assay_date,
          latest_assay_date,
          NULL AS composite_score,
          NULL AS trt_pi_grand_mean,
          NULL AS trt_pi_sem,
          NULL AS standard_deviation,
          NULL AS standard_error,
          'no_rankable_rows' AS standard_deviation_basis,
          NULL AS ex_trt_pi_grand_mean,
          NULL AS ex_trt_pi_sem,
          NULL AS centroid_mean,
          NULL AS avoidance_mean,
          0 AS n_experiments,
          0 AS n_replicates,
          assay_rows_in_window,
          scored_rows_in_window,
          assay_rows_in_window AS evidence_experiments_in_window,
          example_source_name AS source_name,
          example_row_number AS row_number,
          example_provenance_grain AS source_provenance_grain,
          json_object(
            'grain_id', 'fly_repellency_ranking:no_rankable_rows:' || {sql_literal(date_window)},
            'grain_type', 'fly_repellency_ranking_row',
            'locator', 'gs://monarch-videos-new/' || example_source_name || '#row=' || example_row_number,
            'source_id', 'monarch_videos_new',
            'date_window', {sql_literal(date_window)},
            'assay_rows_in_window', assay_rows_in_window,
            'scored_rows_in_window', scored_rows_in_window
          ) AS provenance_grain
        FROM window_summary
        WHERE {sql_literal(date_window)} != 'all_time'
          AND scored_rows_in_window = 0
        ORDER BY ranking_status DESC, composite_score DESC, n_replicates DESC, treatment_label
    """


def _bucket_cross_assay_repellent_rank_compounds_sql(question):
    if not _is_broad_repellent_ranking(question):
        return None
    date_details = _optional_assay_date_filter_details(question, "event_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    return f"""
        WITH dart_ranked AS (
          SELECT
            'dart' AS assay_family,
            species,
            assay_type,
            treatment_normalized AS compound,
            {sql_literal(date_window)} AS date_window,
            'dart_assay_results.assay_date' AS date_basis,
            'mean_avg_pi' AS metric_name,
            avg(avg_pi_real) AS metric_value,
            -avg(avg_pi_real) AS ranking_score,
            'lower mean_avg_pi means stronger DART repellency, ranking_score is -mean_avg_pi' AS metric_basis,
            count(*) AS evidence_rows,
            CASE
              WHEN count(avg_pi_real) > 1 THEN sqrt(
                (sum(avg_pi_real * avg_pi_real) - (sum(avg_pi_real) * sum(avg_pi_real) / count(avg_pi_real)))
                / (count(avg_pi_real) - 1)
              )
              ELSE NULL
            END AS standard_deviation,
            CASE
              WHEN count(avg_pi_real) > 1 THEN sqrt(
                ((sum(avg_pi_real * avg_pi_real) - (sum(avg_pi_real) * sum(avg_pi_real) / count(avg_pi_real)))
                / (count(avg_pi_real) - 1))
                / count(avg_pi_real)
              )
              ELSE NULL
            END AS standard_error,
            'sample_stddev_of_avg_pi_real_across_dart_rows' AS standard_deviation_basis,
            min(avg_pi_real) AS best_single_metric_value,
            min(source_name) AS source_name,
            min(row_number) AS source_row_number,
            min(provenance_grain) AS source_provenance_grain,
            json_object(
              'grain_id', 'cross_assay_repellent:dart:' || lower(trim(treatment_normalized)),
              'grain_type', 'cross_assay_repellent_ranking_row',
              'locator', 'gs://monarch-videos-new/' || min(source_name) || '#row=' || min(row_number),
              'source_id', 'monarch_videos_new',
              'assay_family', 'dart',
              'metric_name', 'mean_avg_pi',
              'standard_deviation_basis', 'sample_stddev_of_avg_pi_real_across_dart_rows',
              'date_window', {sql_literal(date_window)}
            ) AS provenance_grain
          FROM (
            SELECT
              *,
              {_compact_assay_date_iso_sql("assay_date")} AS event_date_iso
            FROM dart_assay_results
          ) dart_source
          WHERE avg_pi_real IS NOT NULL
            AND event_date_iso IS NOT NULL
            AND ({date_filter})
            AND treatment_normalized IS NOT NULL
            AND trim(treatment_normalized) <> ''
            AND lower(trim(treatment_normalized)) NOT IN ('control', 'ctrl', 'vehicle control', 'water', 'solvent', 'none', 'na', 'n/a')
          GROUP BY species, assay_type, treatment_normalized
        ),
        fly_catalog AS (
          SELECT
            json_extract(row_json, '$.treatment_label') AS treatment_label,
            date(substr(json_extract(row_json, '$.experiment'), 1, 10)) AS event_date_iso,
            name AS catalog_source_name,
            row_number AS catalog_row_number
          FROM csv_rows_with_provenance
          WHERE name = 'flies/summary/agg_summary/experiment_catalog.csv'
            AND json_extract(row_json, '$.treatment_label') IS NOT NULL
        ),
        fly_catalog_filtered AS (
          SELECT *
          FROM fly_catalog
          WHERE event_date_iso IS NOT NULL
            AND ({date_filter})
        ),
        fly_catalog_summary AS (
          SELECT
            treatment_label,
            count(*) AS evidence_rows_in_window,
            min(catalog_source_name) AS catalog_source_name,
            min(catalog_row_number) AS catalog_row_number
          FROM fly_catalog_filtered
          GROUP BY treatment_label
        ),
        fly_ranked AS (
          SELECT
            'fly_repellency' AS assay_family,
            'flies' AS species,
            'fly repellency aggregate ranking' AS assay_type,
            json_extract(row_json, '$.treatment_label') AS compound,
            {sql_literal(date_window)} AS date_window,
            'fly_experiment_catalog_experiment_date' AS date_basis,
            'composite_score' AS metric_name,
            CAST(json_extract(row_json, '$.composite_score') AS REAL) AS metric_value,
            CAST(json_extract(row_json, '$.composite_score') AS REAL) AS ranking_score,
            'higher composite_score means stronger fly repellency in the aggregate ranking CSV' AS metric_basis,
            CASE
              WHEN {sql_literal(date_window)} = 'all_time' THEN CAST(json_extract(row_json, '$.n_replicates') AS INTEGER)
              ELSE coalesce(fly_catalog_summary.evidence_rows_in_window, 0)
            END AS evidence_rows,
            CASE
              WHEN CAST(json_extract(row_json, '$.n_replicates') AS INTEGER) > 1
                AND json_extract(row_json, '$.trt_pi_sem') IS NOT NULL
              THEN CAST(json_extract(row_json, '$.trt_pi_sem') AS REAL)
                * sqrt(CAST(json_extract(row_json, '$.n_replicates') AS INTEGER))
              ELSE NULL
            END AS standard_deviation,
            CAST(json_extract(row_json, '$.trt_pi_sem') AS REAL) AS standard_error,
            'trt_pi_sem_times_sqrt_n_replicates' AS standard_deviation_basis,
            CAST(json_extract(row_json, '$.trt_pi_grand_mean') AS REAL) AS best_single_metric_value,
            name AS source_name,
            row_number AS source_row_number,
            provenance_grain AS source_provenance_grain,
            json_object(
              'grain_id', 'cross_assay_repellent:fly:' || lower(trim(json_extract(row_json, '$.treatment_label'))),
              'grain_type', 'cross_assay_repellent_ranking_row',
              'locator', 'gs://monarch-videos-new/' || name || '#row=' || row_number,
              'source_id', 'monarch_videos_new',
              'assay_family', 'fly_repellency',
              'metric_name', 'composite_score',
              'date_window', {sql_literal(date_window)},
              'standard_deviation_basis', 'trt_pi_sem_times_sqrt_n_replicates',
              'catalog_locator', 'gs://monarch-videos-new/' || fly_catalog_summary.catalog_source_name || '#row=' || fly_catalog_summary.catalog_row_number
            ) AS provenance_grain
          FROM csv_rows_with_provenance
          LEFT JOIN fly_catalog_summary ON fly_catalog_summary.treatment_label = json_extract(row_json, '$.treatment_label')
          WHERE name = 'flies/summary/agg_summary/top_performing_chemicals.csv'
            AND lower(json_extract(row_json, '$.direction')) = 'repellent'
            AND json_extract(row_json, '$.treatment_label') IS NOT NULL
            AND json_extract(row_json, '$.composite_score') IS NOT NULL
            AND ({sql_literal(date_window)} = 'all_time' OR coalesce(fly_catalog_summary.evidence_rows_in_window, 0) > 0)
        ),
        contact_ranked AS (
          SELECT
            'contact_no_contact' AS assay_family,
            CASE
              WHEN rows.name LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN rows.name LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              ELSE 'unknown'
            END AS species,
            'contact/no-contact adjusted contact PI summary' AS assay_type,
            coalesce(
              {_known_contact_compound_case_sql("json_extract(rows.row_json, '$.video_stem')")},
              json_extract(rows.row_json, '$.treatment'),
              json_extract(rows.row_json, '$.treatment_label'),
              json_extract(rows.row_json, '$.treatment_normalized'),
              json_extract(rows.row_json, '$.compound'),
              json_extract(rows.row_json, '$.compound_name')
            ) AS compound,
            {sql_literal(date_window)} AS date_window,
            'bucket_object_updated_or_created_time' AS date_basis,
            CASE
              WHEN json_extract(rows.row_json, '$.adj_contact_pi_mean') IS NOT NULL THEN 'adj_contact_pi_mean'
              ELSE 'mean_contact_pi'
            END AS metric_name,
            coalesce(
              CAST(json_extract(rows.row_json, '$.adj_contact_pi_mean') AS REAL),
              CAST(json_extract(rows.row_json, '$.mean_contact_pi') AS REAL)
            ) AS metric_value,
            coalesce(
              CAST(json_extract(rows.row_json, '$.adj_contact_pi_mean') AS REAL),
              CAST(json_extract(rows.row_json, '$.mean_contact_pi') AS REAL)
            ) AS ranking_score,
            'higher contact PI score means stronger avoidance in that contact/no-contact summary' AS metric_basis,
            CAST(coalesce(json_extract(rows.row_json, '$.n'), json_extract(rows.row_json, '$.n_replicates'), '1') AS INTEGER) AS evidence_rows,
            CAST(json_extract(rows.row_json, '$.std_contact_pi') AS REAL) AS standard_deviation,
            NULL AS standard_error,
            CASE
              WHEN json_extract(rows.row_json, '$.std_contact_pi') IS NOT NULL THEN 'frame_level_contact_pi_within_video'
              ELSE 'standard_deviation_not_available_in_source_row'
            END AS standard_deviation_basis,
            coalesce(
              CAST(json_extract(rows.row_json, '$.adj_contact_pi_mean') AS REAL),
              CAST(json_extract(rows.row_json, '$.mean_contact_pi') AS REAL)
            ) AS best_single_metric_value,
            rows.name AS source_name,
            rows.row_number AS source_row_number,
            rows.provenance_grain AS source_provenance_grain,
            json_object(
              'grain_id', 'cross_assay_repellent:contact:' || lower(trim(coalesce(
                {_known_contact_compound_case_sql("json_extract(rows.row_json, '$.video_stem')")},
                json_extract(rows.row_json, '$.treatment'),
                json_extract(rows.row_json, '$.treatment_label'),
                json_extract(rows.row_json, '$.treatment_normalized'),
                json_extract(rows.row_json, '$.compound'),
                json_extract(rows.row_json, '$.compound_name')
              ))),
              'grain_type', 'cross_assay_repellent_ranking_row',
              'locator', 'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number,
              'source_id', 'monarch_videos_new',
              'assay_family', 'contact_no_contact',
              'metric_name', CASE
                WHEN json_extract(rows.row_json, '$.adj_contact_pi_mean') IS NOT NULL THEN 'adj_contact_pi_mean'
                ELSE 'mean_contact_pi'
              END,
              'standard_deviation_basis', CASE
                WHEN json_extract(rows.row_json, '$.std_contact_pi') IS NOT NULL THEN 'frame_level_contact_pi_within_video'
                ELSE 'standard_deviation_not_available_in_source_row'
              END,
              'date_window', {sql_literal(date_window)}
            ) AS provenance_grain
          FROM csv_rows_with_provenance rows
          LEFT JOIN objects ON objects.name = rows.name
          WHERE rows.name IN (
              'contact_repel_videos/mosquitoes_new_solvent/processed/combined_results_with_adj.csv',
              'contact_repel_videos/mosquitoes/processed/combined_results_with_adj.csv',
              'contact_repel_videos/flies/processed/combined_results.csv'
            )
            AND coalesce(
              json_extract(rows.row_json, '$.adj_contact_pi_mean'),
              json_extract(rows.row_json, '$.mean_contact_pi')
            ) IS NOT NULL
            AND date(coalesce(objects.updated, objects.time_created)) IS NOT NULL
            AND ({date_filter.replace("event_date_iso", "date(coalesce(objects.updated, objects.time_created))")})
            AND lower(coalesce(json_extract(rows.row_json, '$.is_control'), '')) NOT IN ('true', '1', 'yes')
        ),
        combined AS (
          SELECT * FROM contact_ranked
          UNION ALL SELECT * FROM fly_ranked
          UNION ALL SELECT * FROM dart_ranked
        )
        SELECT
          row_number() OVER (ORDER BY ranking_score DESC, evidence_rows DESC, compound COLLATE NOCASE) AS rank,
          assay_family,
          species,
          assay_type,
          compound,
          date_window,
          date_basis,
          metric_name,
          metric_value,
          ranking_score,
          metric_basis,
          evidence_rows,
          standard_deviation,
          standard_error,
          standard_deviation_basis,
          best_single_metric_value,
          source_name,
          source_row_number,
          source_provenance_grain,
          provenance_grain
        FROM combined
        WHERE compound IS NOT NULL
          AND trim(compound) <> ''
          AND ranking_score IS NOT NULL
        ORDER BY rank
    """


def _bucket_fly_result_video_bridge_sql(question):
    q = question.lower()
    treatment_filter = _extract_fly_media_treatment(question)
    if species_from_question(question) not in {None, "flies"}:
        return None
    if not _has_any(q, ["video", "videos", "media", "movie", "recording"]):
        return None
    if not treatment_filter and not _has_any(q, ["repellent", "repellents", "repellency", "top", "most", "best"]):
        return None
    treatment_filter_sql = ""
    if treatment_filter:
        treatment_filter_sql = f"WHERE treatment_key = lower({sql_literal(treatment_filter)})"
    return f"""
        WITH ranked_raw AS (
          SELECT
            json_extract(row_json, '$.treatment_label') AS treatment_label,
            lower(trim(
              CASE
                WHEN instr(json_extract(row_json, '$.treatment_label'), ' ') > 0
                THEN substr(json_extract(row_json, '$.treatment_label'), 1, instr(json_extract(row_json, '$.treatment_label'), ' ') - 1)
                ELSE json_extract(row_json, '$.treatment_label')
              END
            )) AS treatment_key,
            json_extract(row_json, '$.direction') AS direction,
            CAST(json_extract(row_json, '$.composite_score') AS REAL) AS composite_score,
            CAST(json_extract(row_json, '$.trt_pi_grand_mean') AS REAL) AS trt_pi_grand_mean,
            CAST(json_extract(row_json, '$.n_replicates') AS INTEGER) AS n_replicates,
            name AS result_source_name,
            row_number AS result_row_number,
            provenance_grain AS result_provenance_grain
          FROM csv_rows_with_provenance
          WHERE name = 'flies/summary/agg_summary/top_performing_chemicals.csv'
            AND lower(json_extract(row_json, '$.direction')) = 'repellent'
        ),
        ranked AS (
          SELECT *
          FROM ranked_raw
          {treatment_filter_sql}
        ),
        media AS (
          SELECT
            r.*,
            o.name AS media_name,
            o.uri AS media_uri,
            o.updated AS media_updated,
            o.time_created AS media_time_created,
            row_number() OVER (
              PARTITION BY r.treatment_label
              ORDER BY coalesce(o.updated, o.time_created) DESC, o.name
            ) AS media_rank
          FROM ranked r
          LEFT JOIN objects o
            ON o.kind = 'video'
           AND lower(o.name) LIKE '%flies%'
           AND lower(o.name) NOT LIKE '%/processed/%'
           AND length(r.treatment_key) >= 3
           AND (
             lower(o.name) LIKE '%/' || r.treatment_key || '/%'
             OR lower(o.name) LIKE '%/' || r.treatment_key || '_%'
             OR lower(o.name) LIKE '%_' || r.treatment_key || '.%'
             OR lower(o.name) LIKE '%/' || r.treatment_key || '.%'
           )
        )
        SELECT
          'flies' AS species,
          treatment_label,
          treatment_key AS treatment_normalized,
          direction,
          composite_score,
          composite_score AS score,
          trt_pi_grand_mean,
          n_replicates,
          result_source_name,
          result_row_number,
          media_name,
          media_uri,
          json_object(
            'grain_id', 'fly_result_video_bridge:' || treatment_label,
            'grain_type', 'fly_result_video_bridge',
            'locator', coalesce(media_uri, 'gs://monarch-videos-new/' || result_source_name || '#row=' || result_row_number),
            'source_id', 'monarch_videos_new',
            'result_source_name', result_source_name,
            'result_row_number', result_row_number,
            'media_name', media_name
          ) AS provenance_grain
        FROM media
        WHERE media_rank = 1 OR media_rank IS NULL
        ORDER BY composite_score DESC, n_replicates DESC, treatment_label
    """


def _bucket_fly_trial_metadata_join_sql(question):
    q = question.lower()
    if not _has_any(q, ["fly", "flies", "swd", "trial", "trials", "metadata", "solvent", "dilution", "inchikey", "side", "treatment position"]):
        return None
    if not _has_any(q, ["solvent", "dilution", "inchikey", "side", "position", "mean", "abbrev", "metadata", "trial", "trials"]):
        return None
    filename_match = re.search(r"(20\d{2}-\d{2}-\d{2}\s+\d{2}-\d{2}-\d{2})", question)
    filename_filter = ""
    if filename_match:
        filename_filter = f"AND trials.filename LIKE {sql_literal('%' + filename_match.group(1) + '%')}"
    abbrev_terms = [token for token in re.findall(r"\b[A-Z0-9]{2,}\b", question) if token not in {"DART", "SDS"}]
    abbrev_filter = ""
    if abbrev_terms:
        abbrev_filter = "AND lower(trials.treatment) IN (" + ", ".join(sql_literal(term.lower()) for term in abbrev_terms) + ")"
    return f"""
        WITH trials AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'B%' THEN value END) AS filename,
            max(CASE WHEN cell LIKE 'N%' THEN value END) AS treatment,
            max(CASE WHEN cell LIKE 'O%' THEN value END) AS dilution,
            max(CASE WHEN cell LIKE 'P%' THEN value END) AS solvent,
            max(CASE WHEN cell LIKE 'Q%' THEN value END) AS left_condition,
            max(CASE WHEN cell LIKE 'R%' THEN value END) AS right_condition,
            max(CASE WHEN cell LIKE 'S%' THEN value END) AS treatment_position,
            max(CASE WHEN cell LIKE 'T%' THEN value END) AS inchikey,
            json_object(
              'source_type', 'google_cloud_storage_object',
              'source_id', 'gs://monarch-videos-new',
              'grain_type', 'xlsx_row',
              'grain_id', name || '#sheet=' || sheet || '&row=' || row_number,
              'version_or_modified_time', max(generation),
              'locator', 'gs://monarch-videos-new/' || name || '#sheet=' || sheet || '&row=' || row_number
            ) AS source_provenance_grain
          FROM xlsx_cells
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet IN ('trials', 'Trials')
            AND (
              cell LIKE 'B%' OR cell LIKE 'N%' OR cell LIKE 'O%' OR cell LIKE 'P%'
              OR cell LIKE 'Q%' OR cell LIKE 'R%' OR cell LIKE 'S%' OR cell LIKE 'T%'
            )
          GROUP BY name, sheet, row_number
        ),
        abbrev AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'A%' THEN value END) AS abbreviation,
            max(CASE WHEN cell LIKE 'B%' THEN value END) AS full_chemical_name,
            max(CASE WHEN cell LIKE 'C%' THEN value END) AS key_inchikey
          FROM xlsx_cells
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND lower(sheet) LIKE '%abbrev%'
            AND (cell LIKE 'A%' OR cell LIKE 'B%' OR cell LIKE 'C%')
          GROUP BY row_number
        )
        SELECT
          trials.row_number,
          trials.filename,
          trials.treatment,
          abbrev.full_chemical_name,
          trials.dilution,
          trials.solvent,
          trials.left_condition,
          trials.right_condition,
          trials.treatment_position,
          coalesce(trials.inchikey, abbrev.key_inchikey) AS inchikey,
          json_object(
            'grain_id', 'fly_trial_metadata:' || coalesce(trials.filename, trials.treatment, trials.row_number),
            'grain_type', 'fly_trial_metadata_row',
            'locator', 'gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#row=' || trials.row_number,
            'source_id', 'monarch_videos_new',
            'source_provenance_grain', trials.source_provenance_grain
          ) AS provenance_grain
        FROM trials
        LEFT JOIN abbrev ON lower(abbrev.abbreviation) = lower(trials.treatment)
        WHERE coalesce(trials.filename, trials.treatment, trials.solvent, '') <> ''
          {filename_filter}
          {abbrev_filter}
        ORDER BY trials.row_number DESC
    """


def _bucket_recent_media_by_mode_sql(question):
    q = question.lower()
    if not _has_any(q, ["video", "media", "movie", "recording"]):
        return None
    asks_recent = _has_any(q, ["recent", "latest", "newest", "most recent", "new"])
    asks_mode_lookup = _has_any(q, ["noncontact", "non contact", "no contact"]) or (
        re.search(r"\bcontact\b", q)
        and not _has_any(q, ["strong", "effect", "pi contrast", "preference index", "this result"])
    )
    if not asks_recent and not asks_mode_lookup:
        return None

    mode_filter = ""
    mode_label = "any"
    if _has_any(q, ["noncontact", "non contact", "no contact"]):
        mode_label = "noncontact"
        mode_filter = "AND lower(name) LIKE '%noncontact%'"
    elif re.search(r"\bcontact\b", q):
        mode_label = "contact"
        mode_filter = """
          AND lower(name) LIKE '%_contact_%'
          AND lower(name) NOT LIKE '%noncontact%'
          AND lower(name) NOT LIKE '%control%'
        """

    species = species_from_question(question)
    species_filter = ""
    if species:
        species_filter = f"AND lower(name) LIKE {sql_literal('%' + species.lower() + '%')}"

    return f"""
        SELECT
          name,
          uri,
          kind,
          ext,
          size,
          content_type,
          updated,
          time_created,
          {sql_literal(mode_label)} AS media_mode,
          json_object(
            'grain_id', name,
            'grain_type', 'bucket_object',
            'locator', uri,
            'source_id', 'monarch_videos_new',
            'version_or_modified_time', coalesce(updated, time_created)
          ) AS provenance_grain
        FROM objects
        WHERE kind = 'video'
          AND lower(name) NOT LIKE '%/processed/%'
          {mode_filter}
          {species_filter}
        ORDER BY coalesce(updated, time_created) DESC, name
    """


def _bucket_recent_contact_no_contact_assays_applies(question):
    q = str(question).lower()
    if _has_count_request(question):
        return False
    asks_assay = _has_any(q, ["assay", "assays"])
    asks_recent = _has_any(q, ["recent", "latest", "newest", "most recent", "last"])
    asks_contact_family = _has_any(q, ["noncontact", "non contact", "no contact", "no-contact"]) or re.search(r"\bcontact\b", q)
    return bool(asks_assay and asks_recent and asks_contact_family)


def _bucket_recent_contact_no_contact_assays_parameters(question):
    if not _bucket_recent_contact_no_contact_assays_applies(question):
        return None
    q = str(question).lower()
    date_details = _optional_assay_date_filter_details(question, "event_date_iso")
    date_parameters = date_details.get("parameters") or {}
    if _has_any(q, ["noncontact", "non contact", "no contact", "no-contact"]) and re.search(r"\bcontact\b", q):
        assay_mode = "contact_and_non_contact"
    elif _has_any(q, ["noncontact", "non contact", "no contact", "no-contact"]):
        assay_mode = "non-contact"
    else:
        assay_mode = "contact"
    species_scope = _assay_species_constraints_from_question(question)
    return {
        "assay_family": "contact_no_contact",
        "assay_mode": assay_mode,
        "media_kind": "video",
        "count_unit": "raw_video_objects" if _has_count_request(question) else None,
        "date_basis": "bucket_object_updated_or_created_time",
        "date_window": date_details.get("date_window"),
        "interpreted_start_date": date_parameters.get("interpreted_start_date"),
        "interpreted_end_date": date_parameters.get("interpreted_end_date"),
        "order_by": "coalesce(updated, time_created) DESC",
        "excluded_by_default": ["processed artifacts", "control videos"],
        "species": species_scope[0] if len(species_scope) == 1 else None,
        "species_scope": species_scope,
    }


def _bucket_recent_contact_no_contact_assays_sql(question):
    if not _bucket_recent_contact_no_contact_assays_applies(question):
        return None

    q = str(question).lower()
    asks_noncontact = _has_any(q, ["noncontact", "non contact", "no contact", "no-contact"])
    asks_contact = bool(re.search(r"\bcontact\b", q))
    if asks_noncontact and asks_contact:
        requested_modes = ["contact", "non-contact"]
    elif asks_noncontact:
        requested_modes = ["non-contact"]
    else:
        requested_modes = ["contact"]

    mode_filter = "AND assay_mode IN (" + ", ".join(sql_literal(mode) for mode in requested_modes) + ")"

    species_scope = _assay_species_constraints_from_question(question)
    species_filter = ""
    if species_scope:
        species_filter = "AND species IN (" + ", ".join(sql_literal(species) for species in species_scope) + ")"

    date_details = _optional_assay_date_filter_details(question, "event_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]

    compound_expr = f"""
          CASE
            WHEN instr(lower(name), '_noncontact_') > 0 THEN
              {_contact_object_compound_from_marker_sql("_noncontact_")}
            WHEN instr(lower(name), '_non_contact_') > 0 THEN
              {_contact_object_compound_from_marker_sql("_non_contact_")}
            WHEN instr(lower(name), '_no_contact_') > 0 THEN
              {_contact_object_compound_from_marker_sql("_no_contact_")}
            WHEN instr(lower(name), '_contact_') > 0 THEN
              {_contact_object_compound_from_marker_sql("_contact_")}
            WHEN instr(lower(name), '_conatct_') > 0 THEN
              {_contact_object_compound_from_marker_sql("_conatct_")}
            ELSE NULL
          END
    """

    raw_cte = f"""
        WITH raw_contact_objects AS (
          SELECT
            CASE
              WHEN lower(name) LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN lower(name) LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              WHEN lower(name) LIKE 'contact_repel_videos/beetles/%' THEN 'beetles'
              WHEN lower(name) LIKE 'contact_repel_videos/moths/%' THEN 'moths'
              ELSE NULL
            END AS species,
            CASE
              WHEN lower(name) LIKE '%noncontact%' OR lower(name) LIKE '%non_contact%' OR lower(name) LIKE '%no_contact%' THEN 'non-contact'
              WHEN lower(name) LIKE '%contact%' OR lower(name) LIKE '%conatct%' THEN 'contact'
              ELSE NULL
            END AS assay_mode,
            {compound_expr} AS compound,
            name,
            name AS object_name,
            uri,
            uri AS locator,
            kind,
            ext,
            size,
            content_type,
            updated,
            time_created,
            coalesce(updated, time_created) AS evidence_time,
            substr(coalesce(updated, time_created), 1, 10) AS event_date_iso
          FROM objects
          WHERE kind = 'video'
            AND name LIKE 'contact_repel_videos/%'
            AND lower(name) NOT LIKE '%/processed/%'
            AND lower(name) NOT LIKE '%control%'
            AND (
              lower(name) LIKE '%noncontact%'
              OR lower(name) LIKE '%non_contact%'
              OR lower(name) LIKE '%no_contact%'
              OR lower(name) LIKE '%_contact_%'
              OR lower(name) LIKE '%_conatct_%'
            )
        ),
        filtered_contact_objects AS (
          SELECT *
          FROM raw_contact_objects
          WHERE assay_mode IS NOT NULL
            AND species IS NOT NULL
            AND ({date_filter})
            {mode_filter}
            {species_filter}
        )
    """

    if _has_count_request(question):
        if species_scope:
            species_values = " UNION ALL ".join(f"SELECT {sql_literal(species)} AS species" for species in species_scope)
            mode_values = " UNION ALL ".join(f"SELECT {sql_literal(mode)} AS assay_mode" for mode in requested_modes)
            return f"""
                {raw_cte},
                requested_species AS (
                  {species_values}
                ),
                requested_modes AS (
                  {mode_values}
                ),
                counts AS (
                  SELECT
                    species,
                    assay_mode,
                    count(*) AS assay_count,
                    count(*) AS video_count,
                    count(DISTINCT compound) AS compound_count,
                    min(evidence_time) AS first_evidence_time,
                    max(evidence_time) AS latest_evidence_time,
                    min(object_name) AS example_object_name,
                    min(locator) AS example_locator
                  FROM filtered_contact_objects
                  GROUP BY species, assay_mode
                )
                SELECT
                  requested_species.species,
                  requested_modes.assay_mode,
                  'contact_no_contact' AS assay_family,
                  {sql_literal(date_window)} AS date_window,
                  'bucket_object_updated_or_created_time' AS date_basis,
                  'raw_video_objects' AS count_unit,
                  coalesce(counts.assay_count, 0) AS assay_count,
                  coalesce(counts.video_count, 0) AS video_count,
                  coalesce(counts.compound_count, 0) AS compound_count,
                  counts.first_evidence_time,
                  counts.latest_evidence_time,
                  counts.example_object_name,
                  counts.example_locator,
                  json_object(
                    'grain_id', 'recent_contact_no_contact_assay_count:' || requested_species.species || ':' || requested_modes.assay_mode || ':' || {sql_literal(date_window)},
                    'grain_type', 'contact_no_contact_assay_count',
                    'source_id', 'monarch_videos_new',
                    'locator', CASE
                      WHEN requested_species.species = 'flies' THEN 'gs://monarch-videos-new/contact_repel_videos/flies/'
                      WHEN requested_species.species = 'mosquitoes' THEN 'gs://monarch-videos-new/contact_repel_videos/mosquitoes_new_solvent/'
                      ELSE 'gs://monarch-videos-new/contact_repel_videos/'
                    END,
                    'adapter', 'bucket_recent_contact_no_contact_assays_sql',
                    'assay_family', 'contact_no_contact',
                    'assay_mode', requested_modes.assay_mode,
                    'date_basis', 'bucket_object_updated_or_created_time',
                    'date_window', {sql_literal(date_window)}
                  ) AS provenance_grain
                FROM requested_species
                CROSS JOIN requested_modes
                LEFT JOIN counts
                  ON counts.species = requested_species.species
                 AND counts.assay_mode = requested_modes.assay_mode
                ORDER BY requested_species.species, requested_modes.assay_mode
            """

        return f"""
            {raw_cte}
            SELECT
              species,
              assay_mode,
              'contact_no_contact' AS assay_family,
              {sql_literal(date_window)} AS date_window,
              'bucket_object_updated_or_created_time' AS date_basis,
              'raw_video_objects' AS count_unit,
              count(*) AS assay_count,
              count(*) AS video_count,
              count(DISTINCT compound) AS compound_count,
              min(evidence_time) AS first_evidence_time,
              max(evidence_time) AS latest_evidence_time,
              min(object_name) AS example_object_name,
              min(locator) AS example_locator,
              json_object(
                'grain_id', 'recent_contact_no_contact_assay_count:' || species || ':' || assay_mode || ':' || {sql_literal(date_window)},
                'grain_type', 'contact_no_contact_assay_count',
                'source_id', 'monarch_videos_new',
                'locator', 'gs://monarch-videos-new/contact_repel_videos/',
                'adapter', 'bucket_recent_contact_no_contact_assays_sql',
                'assay_family', 'contact_no_contact',
                'assay_mode', assay_mode,
                'date_basis', 'bucket_object_updated_or_created_time',
                'date_window', {sql_literal(date_window)}
              ) AS provenance_grain
            FROM filtered_contact_objects
            GROUP BY species, assay_mode
            ORDER BY latest_evidence_time DESC, species, assay_mode
        """

    return f"""
        {raw_cte}
        SELECT
          species,
          assay_mode,
          compound,
          name,
          object_name,
          uri,
          locator,
          kind,
          ext,
          size,
          content_type,
          updated,
          time_created,
          evidence_time,
          json_object(
            'grain_id', 'recent_contact_no_contact_assay:' || name,
            'grain_type', 'bucket_object',
            'source_id', 'monarch_videos_new',
            'locator', coalesce(uri, 'gs://monarch-videos-new/' || name),
            'adapter', 'bucket_recent_contact_no_contact_assays_sql',
            'assay_family', 'contact_no_contact',
            'date_basis', 'bucket_object_updated_or_created_time',
            'version_or_modified_time', coalesce(updated, time_created)
          ) AS provenance_grain
        FROM filtered_contact_objects
        ORDER BY datetime(replace(coalesce(updated, time_created), 'Z', '')) DESC, name DESC
    """


def _bucket_recent_media_by_mode_parameters(question):
    q = question.lower()
    if not _has_any(q, ["video", "media", "movie", "recording"]):
        return None
    asks_recent = _has_any(q, ["recent", "latest", "newest", "most recent", "new"])
    asks_mode_lookup = _has_any(q, ["noncontact", "non contact", "no contact"]) or (
        re.search(r"\bcontact\b", q)
        and not _has_any(q, ["strong", "effect", "pi contrast", "preference index", "this result"])
    )
    if not asks_recent and not asks_mode_lookup:
        return None

    media_mode = "any"
    matched_alias = None
    for alias in ["noncontact", "non contact", "no contact"]:
        if alias in q:
            media_mode = "noncontact"
            matched_alias = alias
            break
    if matched_alias is None and re.search(r"\bcontact\b", q):
        media_mode = "contact"
        matched_alias = "contact"

    return {
        "media_kind": "video",
        "media_mode": media_mode,
        "matched_alias": matched_alias,
        "order_by": "coalesce(updated, time_created) DESC",
        "exclude": ["processed artifacts"],
    }


def _bucket_assay_quality_report_sql(question):
    q = question.lower()
    if not _has_any(q, ["warning", "warnings", "error", "errors", "flagged", "quality", "accuracy report", "usable data"]):
        return None
    if not _has_any(q, ["processed", "run", "runs", "assay", "fly", "flies", "mosquito", "mosquitoes", "tube", "tubes"]):
        return None
    issue_terms = []
    if _has_any(q, ["warning", "warnings"]):
        issue_terms.append("warning")
    if _has_any(q, ["error", "errors"]):
        issue_terms.append("error")
    if _has_any(q, ["flagged"]):
        issue_terms.append("flagged")
    term_filter = " OR ".join(f"lower(text) LIKE {sql_literal('%' + term + '%')}" for term in issue_terms) or "1=1"
    return f"""
        SELECT
          name AS report_name,
          line_number,
          text AS issue_text,
          CASE
            WHEN lower(text) LIKE '%error%' THEN 'error'
            WHEN lower(text) LIKE '%warning%' THEN 'warning'
            WHEN lower(text) LIKE '%flagged%' THEN 'flagged'
            ELSE 'quality'
          END AS issue_type,
          provenance_grain
        FROM text_lines_with_provenance
        WHERE lower(name) LIKE '%accuracy%'
          AND ({term_filter})
        ORDER BY name, line_number
    """


def _bucket_assay_media_candidates_sql(question):
    q = question.lower()
    if "video" not in q and "media" not in q:
        return None
    if not _has_any(q, ["strong", "contact", "pi contrast", "preference index", "effect"]):
        return None
    species = species_from_question(question)
    species_filter = f"AND lower(coalesce(l.species, '')) = lower({sql_literal(species)})" if species else ""
    contact_filter = ""
    if "contact" in q:
        contact_filter = """
          AND (
            lower(coalesce(l.assay_family, '')) LIKE '%contact%'
            OR lower(coalesce(d.assay_type, '')) LIKE '%contact%'
            OR lower(coalesce(l.media_name, '')) LIKE '%contact%'
            OR lower(coalesce(l.media_uri, '')) LIKE '%contact%'
          )
        """
    return f"""
        SELECT
          l.assay_family,
          l.species,
          l.assay_date,
          l.treatment_normalized,
          l.condition,
          l.assay_source_name,
          l.assay_sheet,
          l.assay_row_number,
          d.assay_type,
          d.avg_pi_real,
          d.dilution,
          d.filename AS assay_filename,
          l.media_name,
          l.media_uri,
          l.media_kind,
          l.media_ext,
          l.duration_seconds,
          l.width,
          l.height,
          l.match_method,
          l.confidence,
          l.provenance_grain
        FROM assay_media_links l
        LEFT JOIN dart_assay_results d
          ON d.source_name = l.assay_source_name
         AND coalesce(d.sheet, '') = coalesce(l.assay_sheet, '')
         AND d.row_number = l.assay_row_number
        WHERE 1=1
          {species_filter}
          {contact_filter}
        ORDER BY
          CASE WHEN d.avg_pi_real IS NULL THEN 1 ELSE 0 END,
          abs(d.avg_pi_real) DESC,
          l.media_updated DESC,
          l.media_name
    """


def _bucket_experiments_by_organism_sql(question):
    q = question.lower()
    organism_terms = []
    if "diamondback" in q or "diamond back" in q or "dbm" in q or "plutella" in q:
        organism_terms = ["diamondback", "diamond back", "dbm", "plutella", "moth"]
    elif "moth" in q:
        organism_terms = ["moth"]
    elif "beetle" in q:
        organism_terms = ["beetle"]
    else:
        return None
    match_terms = " OR ".join(f'"{term}"' if " " in term else term for term in organism_terms)
    return f"""
        SELECT
          unit_type,
          name,
          sub_id,
          snippet(source_search, 3, '[', ']', ' ... ', 24) AS evidence_text,
          provenance_grain
        FROM source_search
        WHERE source_search MATCH {sql_literal(match_terms)}
          AND unit_type IN ('object', 'csv_row', 'xlsx_cell', 'text_line', 'model_metadata')
        ORDER BY unit_type, name, sub_id
    """


def _bucket_insect_image_taxonomy_inventory_sql(question):
    q = question.lower()
    if not _has_any(q, ["image", "images", "photo", "photos", "picture", "pictures"]):
        return None
    terms = []
    prefixes = []
    if _has_any(q, ["diamondback", "diamond back", "dbm", "plutella"]):
        terms = ["diamondback", "diamond back", "dbm", "plutella", "moth"]
        prefixes = ["insect-images/Lepidoptera/Lepidoptera/Plutellidae/"]
    elif "lepidoptera" in q:
        terms = ["lepidoptera", "moth", "butterfly"]
        prefixes = ["insect-images/Lepidoptera/"]
    elif "diptera" in q:
        terms = ["diptera", "fly", "mosquito", "drosophila"]
        prefixes = ["insect-images/Diptera/"]
    elif "moth" in q:
        terms = ["moth"]
        prefixes = ["insect-images/Lepidoptera/"]
    elif "beetle" in q:
        terms = ["beetle"]
        prefixes = ["insect-images/Coleoptera/"]
    elif _has_any(q, ["fly", "flies", "drosophila", "swd"]):
        terms = ["fly", "flies", "drosophila", "swd"]
        prefixes = ["flies/insect images ", "insect-images/Diptera/"]
    elif "mosquito" in q:
        terms = ["mosquito"]
        prefixes = ["mosquitoes/", "insect-images/Diptera/"]
    else:
        return None
    joined_terms = ",".join(terms)
    if prefixes:
        range_filter = " OR ".join(
            f"(name >= {sql_literal(prefix)} AND name < {sql_literal(prefix[:-1] + chr(ord(prefix[-1]) + 1))})"
            for prefix in prefixes
        )
        return f"""
            SELECT
              {sql_literal(joined_terms)} AS matched_terms,
              CASE
                WHEN lower(name) LIKE 'insect-images/%' THEN substr(name, 1, instr(substr(name, 15), '/') + 13)
                WHEN lower(name) LIKE 'flies/insect images%' THEN 'flies/insect images'
                WHEN lower(name) LIKE 'mosquitoes/%' THEN 'mosquitoes'
                ELSE substr(name, 1, instr(name || '/', '/') - 1)
              END AS folder_prefix,
              kind,
              ext,
              count(*) AS object_count,
              min(time_created) AS first_time_created,
              max(coalesce(updated, time_created)) AS latest_updated,
              json_object(
                'grain_id', 'insect_image_taxonomy_inventory:' || {sql_literal(joined_terms)},
                'grain_type', 'bucket_object',
                'locator', 'gs://monarch-videos-new/' || min(name),
                'source_id', 'monarch_videos_new',
                'matched_terms', {sql_literal(joined_terms)}
              ) AS provenance_grain
            FROM objects INDEXED BY sqlite_autoindex_objects_1
            WHERE ({range_filter})
              AND kind IN ('image', 'object')
            GROUP BY folder_prefix, kind, ext
            HAVING object_count > 0
            ORDER BY object_count DESC, folder_prefix, ext
        """
    match_terms = " OR ".join(term.replace(" ", " NEAR ") for term in terms)
    return f"""
        WITH matched AS (
          SELECT
            name,
            provenance_grain
          FROM source_search
          WHERE source_search MATCH {sql_literal(match_terms)}
            AND unit_type = 'image'
        )
        SELECT
          {sql_literal(joined_terms)} AS matched_terms,
          CASE
            WHEN lower(o.name) LIKE 'insect-images/%' THEN 'insect-images'
            WHEN lower(o.name) LIKE 'insect images %' THEN 'insect images'
            WHEN lower(o.name) LIKE 'flies/insect images%' THEN 'flies/insect images'
            ELSE substr(o.name, 1, instr(o.name || '/', '/') - 1)
          END AS folder_prefix,
          o.kind,
          o.ext,
          count(*) AS object_count,
          min(o.time_created) AS first_time_created,
          max(coalesce(o.updated, o.time_created)) AS latest_updated,
          json_object(
            'grain_id', 'insect_image_taxonomy_inventory:' || {sql_literal(joined_terms)},
            'grain_type', 'bucket_object',
            'locator', 'gs://monarch-videos-new/' || min(o.name),
            'source_id', 'monarch_videos_new',
            'matched_terms', {sql_literal(joined_terms)}
          ) AS provenance_grain
        FROM matched m
        JOIN objects o ON o.name = m.name
        WHERE o.kind IN ('image', 'object')
        GROUP BY folder_prefix, o.kind, o.ext
        ORDER BY object_count DESC, folder_prefix, ext
    """


def _script_method_candidate_scripts(question, source_lane):
    q = str(question).lower()
    if source_lane == "chemistry_analysis":
        scripts = []
        if _has_any(q, ["chemical registry", "chemistry registry", "registry"]):
            scripts.append("scripts/chemical_registry.py")
        if _has_any(q, ["docking", "dock", "vina", "pdbqt"]):
            scripts.extend(["scripts/docking_pipeline.py", "scripts/docking_verification.py"])
        if _has_any(q, ["or sequence", "odorant receptor", "receptor", "protein structure", "alphafold"]):
            scripts.extend(
                [
                    "scripts/or_sequence_retrieval.py",
                    "scripts/receptor_annotation.py",
                    "scripts/receptor_relaxation.py",
                ]
            )
        return _dedupe_preserve_order(scripts)

    scripts = []
    if _has_any(q, ["phytotoxicity", "phytotox", "phytox", "chlorosis", "browning", "necrosis", "features_all", "leaf"]):
        scripts.extend(
            [
                "scripts/leaf_phytotoxicity_analysis.py",
                "scripts/leaf_seg_inference.py",
                "scripts/generate_leaf_configs.py",
            ]
        )
    if _has_any(q, ["entropy", "centroid", "dispersion", "flux", "avoidance", "population metric", "population metrics"]):
        scripts.append("scripts/advanced_population_metrics.py")
    if _has_any(q, ["adjusted contact pi", "contact pi", "preference index", " pi", "pi correction"]):
        scripts.extend(
            [
                "scripts/pi_correction.py",
                "scripts/advanced_population_metrics.py",
                "scripts/insect_behavior_pipeline.py",
            ]
        )
    if _has_any(q, ["fly", "flies", "drosophila"]):
        scripts.extend(["scripts/fly_assay_pipeline.py", "scripts/advanced_population_metrics.py"])
    if _has_any(q, ["mosquito", "mosquitoes", "dart", "assay", "tracking", "detection"]):
        scripts.extend(
            [
                "scripts/insect_behavior_pipeline.py",
                "scripts/detection_accuracy_report.py",
                "scripts/aggregate_by_time_final_adapted_for_mosquitoes.py",
                "scripts/aggregate_experiments.py",
            ]
        )
    if _has_any(q, ["docking", "dock", "chemical registry", "registry"]):
        scripts.extend(["scripts/docking_pipeline.py", "scripts/chemical_registry.py"])
    return _dedupe_preserve_order(scripts)


def _script_method_search_terms(question):
    q = str(question).lower()
    terms = []
    explicit_terms = [
        "adjusted_contact_pi",
        "contact_pi",
        "mean_contact_pi",
        "preference",
        "entropy",
        "centroid",
        "dispersion",
        "flux",
        "avoidance",
        "chlorosis",
        "browning",
        "necrosis",
        "feature",
        "features_all",
        "phytotoxicity",
        "docking",
        "dock",
        "registry",
        "receptor",
        "segmentation",
        "detection",
        "tracking",
        "pipeline",
        "compute",
        "calculate",
    ]
    for term in explicit_terms:
        if term.replace("_", " ") in q or term in q:
            terms.append(term)
    if "adjusted contact pi" in q:
        terms.extend(["contact", "pi"])
    if "chemical registry" in q:
        terms.extend(["registry", "chemical"])
    if not terms:
        for token in anchor_tokens(question):
            if len(token) > 2 and token not in {"what", "which", "script", "code", "made", "used", "answer"}:
                terms.append(token)
    return _dedupe_preserve_order(terms[:8])


def _script_method_evidence_sql(question, source_lane):
    if not _script_method_question_applies(question):
        return None
    scripts = _script_method_candidate_scripts(question, source_lane)
    terms = _script_method_search_terms(question)
    if not scripts and not terms:
        return None

    if scripts:
        name_filter = "t.name IN (" + ", ".join(sql_literal(script) for script in scripts) + ")"
        header_filter = "t.line_number <= 40"
        script_rank = "CASE " + " ".join(
            f"WHEN t.name = {sql_literal(script)} THEN {idx}"
            for idx, script in enumerate(scripts)
        ) + f" ELSE {len(scripts)} END"
    else:
        name_filter = "lower(t.name) LIKE 'scripts/%'"
        header_filter = "0"
        script_rank = "0"

    term_clauses = [
        f"(lower(t.text) LIKE {sql_literal('%' + term.lower() + '%')} OR lower(t.name) LIKE {sql_literal('%' + term.lower() + '%')})"
        for term in terms
    ]
    term_filter = " OR ".join(term_clauses) if term_clauses else "0"
    primary_term_filter = term_clauses[0] if term_clauses else "0"
    source_id = "gs://monarch-chemistry-analysis" if source_lane == "chemistry_analysis" else "gs://monarch-videos-new"
    adapter_name = f"{source_lane}_script_method_evidence_sql"

    return f"""
        SELECT
          'script_line' AS unit_type,
          t.name AS script_name,
          t.name AS name,
          t.line_number AS script_line,
          t.line_number AS sub_id,
          t.text AS evidence_text,
          o.uri AS script_uri,
          o.updated AS script_updated,
          {sql_literal(source_lane)} AS source_lane,
          {sql_literal(adapter_name)} AS adapter,
          json_object(
            'grain_id', 'script_line:' || t.name || ':' || t.line_number,
            'grain_type', 'script_line',
            'locator', coalesce(o.uri, {sql_literal(source_id + '/')} || t.name) || '#line=' || t.line_number,
            'source_id', {sql_literal(source_id)},
            'version_or_modified_time', coalesce(o.updated, o.time_created, t.generation)
          ) AS provenance_grain
        FROM text_lines t
        LEFT JOIN objects o ON o.name = t.name
        WHERE lower(t.name) LIKE 'scripts/%'
          AND {name_filter}
          AND ({header_filter} OR {term_filter})
        ORDER BY
          CASE
            WHEN {primary_term_filter} THEN 0
            WHEN {term_filter} THEN 1
            ELSE 2
          END,
          {script_rank},
          t.line_number
    """


def _bucket_script_method_evidence_sql(question):
    return _script_method_evidence_sql(question, "bucket")


def _chemistry_analysis_script_method_evidence_sql(question):
    return _script_method_evidence_sql(question, "chemistry_analysis")


def _bucket_docking_pipeline_sql(question):
    q = question.lower()
    if "docking" not in q or "pipeline" not in q:
        return None
    return """
        SELECT
          'text_line' AS unit_type,
          name,
          line_number AS sub_id,
          text AS evidence_text,
          provenance_grain
        FROM text_lines_with_provenance
        WHERE name = 'scripts/docking_pipeline.py'
        ORDER BY line_number
    """


def _bucket_docking_results_sql(question):
    q = question.lower()
    if "docking" not in q or not _has_any(q, ["result", "results", "affinity", "vina", "dock", "docked"]):
        return None
    return """
        SELECT
          unit_type,
          name,
          sub_id,
          snippet(source_search, 3, '[', ']', ' ... ', 24) AS evidence_text,
          provenance_grain
        FROM source_search
        WHERE source_search MATCH 'dock* OR vina OR pdbqt OR affinity OR report'
          AND unit_type IN ('object', 'csv_row', 'text_line', 'model_metadata', 'json_path')
        ORDER BY unit_type, name, sub_id
    """


def _has_within_assay_timepoint_request(question):
    q = str(question).lower()
    return _has_any(
        q,
        [
            "time point",
            "timepoint",
            "time bin",
            "time-bin",
            "time window",
            "within assay",
            "inside assay",
            "within the assay",
            "inside the assay",
            "minute",
            "minutes",
        ],
    )


def _bucket_individual_assay_timepoint_applies(question):
    q = str(question).lower()
    if not _has_within_assay_timepoint_request(question):
        return False
    asks_assay = _has_any(
        q,
        [
            "assay",
            "assays",
            "experiment",
            "experiments",
            "dart",
            "contact",
            "noncontact",
            "non-contact",
            "no contact",
            "no-contact",
            *PHYTOTOX_TERMS,
        ],
    )
    asks_metric = _has_any(
        q,
        [
            "repellent",
            "repellency",
            "avoidance",
            "preference index",
            " pi",
            "contact pi",
            "damage",
            "damaged",
            "chlorosis",
            "browning",
            "necrosis",
            "effect",
            "strongest",
            "most",
            "peak",
            "highest",
            "lowest",
        ],
    )
    return asks_assay and asks_metric


def _assay_timepoint_family_scope(question):
    q = str(question).lower()
    asks_dart = _has_any(q, ["dart", "preference index", "trt_pi", " pi"])
    asks_contact = _has_any(q, ["contact", "noncontact", "non-contact", "no contact", "no-contact", "contact pi"])
    asks_phytotox = _has_any(q, [*PHYTOTOX_TERMS, "damage", "damaged", "chlorosis", "browning", "necrosis", "plant", "plants", "leaf", "leaves"])
    asks_repellency = _has_any(q, ["repellent", "repellents", "repellency", "avoidance", "preference index", " pi"])

    if asks_dart or asks_contact or asks_phytotox:
        return {
            "dart": asks_dart,
            "contact": asks_contact,
            "phytotox": asks_phytotox,
        }
    if asks_repellency:
        return {"dart": True, "contact": True, "phytotox": False}
    return {"dart": True, "contact": True, "phytotox": True}


def _phytotox_timepoint_metric_for_question(question):
    q = str(question).lower()
    if _has_any(q, ["chlorosis", "yellow", "yellowing"]):
        return "chlorosis_fraction_delta", "chlorosis_fraction_delta", "higher chlorosis_fraction_delta means more chlorosis relative to baseline"
    if _has_any(q, ["browning", "brown"]):
        return "browning_fraction_delta", "browning_fraction_delta", "higher browning_fraction_delta means more browning relative to baseline"
    if _has_any(q, ["necrosis", "necrotic"]):
        return "necrosis_fraction_delta", "necrosis_fraction_delta", "higher necrosis_fraction_delta means more necrosis relative to baseline"
    return "damaged_fraction_delta", "damaged_fraction_delta", "higher damaged_fraction_delta means more plant damage relative to baseline"


def _contact_assay_mode_filter_for_question(question, column="assay_mode"):
    q = str(question).lower()
    asks_noncontact = _has_any(q, ["noncontact", "non contact", "non-contact", "no contact", "no-contact"])
    asks_contact = bool(re.search(r"\bcontact\b", q))
    if asks_contact and asks_noncontact:
        return f"AND {column} IN ('contact', 'non-contact')"
    if asks_noncontact:
        return f"AND {column} = 'non-contact'"
    if asks_contact:
        return f"AND {column} = 'contact'"
    return ""


def _contact_timepoint_compound_sql(stem_expr):
    lower_expr = f"lower({stem_expr})"
    return f"""
            CASE
              WHEN {lower_expr} LIKE '%control%' THEN 'control'
              WHEN {lower_expr} LIKE '%pepoil%' THEN 'PepOil'
              WHEN {lower_expr} LIKE '%2pp%' THEN '2PP'
              WHEN {lower_expr} LIKE '%3pp%' THEN '3PP'
              WHEN {lower_expr} LIKE '%deet%' THEN 'DEET'
              WHEN {lower_expr} LIKE '%ir3535%' THEN 'IR3535'
              WHEN {lower_expr} LIKE '%picaridin%' THEN 'Picaridin'
              WHEN {lower_expr} LIKE '%phpramide%' THEN 'PhPrAmide'
              WHEN {lower_expr} LIKE '%menthol%' THEN 'Menthol'
              WHEN {lower_expr} LIKE '%thymol%' THEN 'Thymol'
              WHEN {lower_expr} LIKE '%eugenol%' THEN 'Eugenol'
              ELSE trim(
                replace(
                  replace(
                    replace(
                      replace(
                        replace(
                          replace(
                            replace({stem_expr}, 'IMG_', ''),
                            'NonContact_', ''
                          ),
                          'Noncontact_', ''
                        ),
                        'non_contact_', ''
                      ),
                      'Contact_', ''
                    ),
                    'contact_', ''
                  ),
                  'Control_', ''
                )
              )
            END
    """


def _bucket_individual_assay_timepoint_sql(question):
    if not _bucket_individual_assay_timepoint_applies(question):
        return None

    species_scope = _assay_species_constraints_from_question(question)
    family_scope = _assay_timepoint_family_scope(question)
    recent_run_limit = _last_n_assay_runs_for_question(question, default=10)
    answer_limit = 1
    if _has_any(str(question).lower(), ["top ", "rank ", "ranked ", "list "]):
        answer_limit = _rank_limit_for_question(question, default=1)
    answer_limit = max(1, min(answer_limit, 25))
    today_cutoff = sql_literal(_local_today().isoformat())
    date_details = _optional_assay_date_filter_details(question, "run_date_iso")
    date_window = date_details["date_window"]
    run_date_filter = date_details["filter_sql"]

    branches = []

    if family_scope.get("dart"):
        dart_species_filter = ""
        if species_scope:
            dart_species_filter = "AND species IN (" + ", ".join(sql_literal(species) for species in species_scope if species in {"flies", "mosquitoes"}) + ")"
            if dart_species_filter == "AND species IN ()":
                dart_species_filter = "AND 1 = 0"

        metric_selects = []
        for tube in range(1, 9):
            metric_selects.append(
                f"""
                  SELECT
                    source_name,
                    source_row_number,
                    species,
                    processed_folder AS assay_run_label,
                    'DART' AS assay_family,
                    'tube' AS assay_mode,
                    run_datetime_iso,
                    run_date_iso,
                    is_control,
                    {sql_literal('T' + str(tube))} AS tube,
                    {sql_literal('T' + str(tube) + '_trt_PI')} AS metric_name,
                    CASE
                      WHEN json_extract(row_json, '$.T{tube}_trt_PI') IS NOT NULL
                       AND trim(json_extract(row_json, '$.T{tube}_trt_PI')) <> ''
                      THEN CAST(json_extract(row_json, '$.T{tube}_trt_PI') AS REAL)
                      ELSE NULL
                    END AS metric_value,
                    CASE
                      WHEN json_extract(row_json, '$.T{tube}_trt_PI') IS NOT NULL
                       AND trim(json_extract(row_json, '$.T{tube}_trt_PI')) <> ''
                      THEN -1.0 * CAST(json_extract(row_json, '$.T{tube}_trt_PI') AS REAL)
                      ELSE NULL
                    END AS effect_score,
                    json_extract(row_json, '$.time_bin') AS time_bin,
                    CAST(json_extract(row_json, '$.time_start_min') AS REAL) AS time_start_min,
                    CAST(json_extract(row_json, '$.time_mid_min') AS REAL) AS time_mid_min,
                    CAST(json_extract(row_json, '$.time_end_min') AS REAL) AS time_end_min,
                    CAST(json_extract(row_json, '$.n_frames') AS INTEGER) AS n_frames,
                    CAST(json_extract(row_json, '$.T{tube}_total') AS INTEGER) AS organism_count,
                    provenance_grain
                  FROM dart_time_rows
                """
            )
        metric_union_sql = "\nUNION ALL\n".join(metric_selects)
        branches.append(
            f"""
            dart_source_files AS (
              SELECT DISTINCT
                name AS source_name,
                CASE
                  WHEN name LIKE 'flies/processed/%/results_by_time.csv' THEN 'flies'
                  WHEN name LIKE 'mosquitoes/processed/%/results_by_time.csv' THEN 'mosquitoes'
                  ELSE NULL
                END AS species,
                substr(substr(name, instr(name, 'processed/') + 10), 1, instr(substr(name, instr(name, 'processed/') + 10), '/') - 1) AS processed_folder
              FROM csv_columns_with_provenance
              WHERE (
                  name LIKE 'flies/processed/%/results_by_time.csv'
                  OR name LIKE 'mosquitoes/processed/%/results_by_time.csv'
                )
                AND column_name = 'time_bin'
            ),
            dart_normalized_files AS (
              SELECT
                source_name,
                species,
                processed_folder,
                CASE
                  WHEN species = 'flies' THEN
                    substr(processed_folder, 1, 10) || ' ' || replace(substr(processed_folder, 12, 8), '-', ':')
                  WHEN species = 'mosquitoes' THEN
                    substr(processed_folder, 2, 4) || '-' ||
                    substr(processed_folder, 7, 2) || '-' ||
                    substr(processed_folder, 10, 2) || ' ' ||
                    substr(processed_folder, 13, 2) || ':' ||
                    substr(processed_folder, 16, 2) || ':' ||
                    substr(processed_folder, 19, 2)
                  ELSE NULL
                END AS run_datetime_iso,
                CASE
                  WHEN species = 'flies' THEN substr(processed_folder, 1, 10)
                  WHEN species = 'mosquitoes' THEN
                    substr(processed_folder, 2, 4) || '-' ||
                    substr(processed_folder, 7, 2) || '-' ||
                    substr(processed_folder, 10, 2)
                  ELSE NULL
                END AS run_date_iso,
                CASE
                  WHEN lower(processed_folder) LIKE '%control%' THEN 1
                  ELSE 0
                END AS is_control
              FROM dart_source_files
              WHERE species IS NOT NULL
              {dart_species_filter}
            ),
            dart_eligible_files AS (
              SELECT *
              FROM dart_normalized_files
              WHERE run_date_iso IS NOT NULL
                AND date(run_date_iso) <= date({today_cutoff})
                AND {run_date_filter}
            ),
            dart_recent_files AS (
              SELECT *
              FROM dart_eligible_files
              ORDER BY datetime(run_datetime_iso) DESC, source_name DESC
              LIMIT {recent_run_limit}
            ),
            dart_time_rows AS (
              SELECT
                r.source_name,
                c.row_number AS source_row_number,
                r.species,
                r.processed_folder,
                r.run_datetime_iso,
                r.run_date_iso,
                r.is_control,
                c.row_json,
                c.provenance_grain
              FROM dart_recent_files r
              JOIN csv_rows_with_provenance c
                ON c.name = r.source_name
            ),
            fly_metadata AS (
              SELECT
                max(CASE WHEN cell = 'B' || row_number THEN value END) AS filename,
                max(CASE WHEN cell = 'I' || row_number THEN value END) AS tube_number,
                max(CASE WHEN cell = 'N' || row_number THEN value END) AS treatment_label,
                max(CASE WHEN cell = 'O' || row_number THEN value END) AS dilution,
                max(CASE WHEN cell = 'P' || row_number THEN value END) AS solvent,
                max(CASE WHEN cell = 'S' || row_number THEN value END) AS treatment_position,
                max(CASE WHEN cell = 'U' || row_number THEN value END) AS usable_data
              FROM xlsx_cells_with_provenance
              WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
                AND sheet = 'trials'
                AND row_number > 1
              GROUP BY row_number
            ),
            dart_metric_rows AS (
              {metric_union_sql}
            ),
            dart_annotated_rows AS (
              SELECT
                m.source_name,
                m.source_row_number,
                m.species,
                m.assay_family,
                m.assay_mode,
                m.assay_run_label,
                coalesce(
                  fm.treatment_label,
                  CASE
                    WHEN m.species = 'mosquitoes' THEN replace(substr(m.assay_run_label, 22), '_mov_results', '')
                    ELSE NULL
                  END,
                  m.assay_run_label
                ) AS treatment_label,
                coalesce(fm.dilution, '') AS dilution,
                coalesce(fm.solvent, '') AS solvent,
                coalesce(fm.treatment_position, '') AS treatment_position,
                coalesce(fm.usable_data, '') AS usable_data,
                m.run_datetime_iso,
                m.run_date_iso,
                'processed results_by_time run datetime from source path' AS date_basis,
                m.tube,
                m.metric_name,
                m.metric_value,
                m.effect_score,
                'more negative treatment-side PI means stronger repellency/avoidance, effect_score is -PI for directional cross-family sorting' AS metric_interpretation,
                m.time_bin,
                m.time_start_min,
                m.time_mid_min,
                m.time_end_min,
                printf('%.1f-%.1f min', m.time_start_min, m.time_end_min) AS time_window,
                m.n_frames,
                m.organism_count,
                'individual_assay_timepoint' AS grain_type,
                m.provenance_grain
              FROM dart_metric_rows m
              LEFT JOIN fly_metadata fm
                ON m.species = 'flies'
               AND fm.filename = substr(m.assay_run_label, 1, 19) || '.mp4'
               AND fm.tube_number = replace(m.tube, 'T', '')
              WHERE m.is_control = 0
                AND m.metric_value IS NOT NULL
            )
            """
        )

    if family_scope.get("contact"):
        contact_species_filter = ""
        if species_scope:
            contact_species_filter = "AND species IN (" + ", ".join(sql_literal(species) for species in species_scope) + ")"
        contact_mode_filter = _contact_assay_mode_filter_for_question(question)
        contact_compound_expr = _contact_timepoint_compound_sql("f.processed_folder")
        branches.append(
            f"""
            contact_source_files AS (
              SELECT DISTINCT
                cols.name AS source_name,
                CASE
                  WHEN cols.name LIKE 'contact_repel_videos/flies/%' THEN 'flies'
                  WHEN cols.name LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
                  WHEN cols.name LIKE 'contact_repel_videos/beetles/%' THEN 'beetles'
                  WHEN cols.name LIKE 'contact_repel_videos/moths/%' THEN 'moths'
                  ELSE NULL
                END AS species,
                replace(substr(cols.name, instr(cols.name, '/processed/') + 11), '/frame_metrics.csv', '') AS processed_folder,
                coalesce(objects.updated, objects.time_created) AS run_datetime_iso,
                substr(coalesce(objects.updated, objects.time_created), 1, 10) AS run_date_iso,
                cols.provenance_grain
              FROM csv_columns_with_provenance cols
              LEFT JOIN objects
                ON objects.name = cols.name
              WHERE cols.name LIKE 'contact_repel_videos/%/processed/%/frame_metrics.csv'
                AND cols.column_name = 'time_sec'
            ),
            contact_normalized_files AS (
              SELECT
                *,
                CASE
                  WHEN lower(processed_folder) LIKE '%noncontact%' OR lower(processed_folder) LIKE '%non_contact%' OR lower(processed_folder) LIKE '%no_contact%' THEN 'non-contact'
                  WHEN lower(processed_folder) LIKE '%contact%' THEN 'contact'
                  ELSE 'unknown'
                END AS assay_mode,
                CASE
                  WHEN lower(processed_folder) LIKE '%control%' THEN 1
                  ELSE 0
                END AS is_control
              FROM contact_source_files
              WHERE species IS NOT NULL
              {contact_species_filter}
            ),
            contact_eligible_files AS (
              SELECT *
              FROM contact_normalized_files
              WHERE run_date_iso IS NOT NULL
                AND date(run_date_iso) <= date({today_cutoff})
                AND {run_date_filter}
                {contact_mode_filter}
                AND is_control = 0
            ),
            contact_recent_files AS (
              SELECT *
              FROM contact_eligible_files
              ORDER BY datetime(run_datetime_iso) DESC, source_name DESC
              LIMIT {recent_run_limit}
            ),
            contact_annotated_rows AS (
              SELECT
                f.source_name,
                c.row_number AS source_row_number,
                f.species,
                'contact/no-contact' AS assay_family,
                f.assay_mode,
                f.processed_folder AS assay_run_label,
                {contact_compound_expr} AS treatment_label,
                '' AS dilution,
                '' AS solvent,
                '' AS treatment_position,
                '' AS usable_data,
                f.run_datetime_iso,
                f.run_date_iso,
                'bucket object updated/created time for contact frame_metrics source object' AS date_basis,
                NULL AS tube,
                'contact_pi' AS metric_name,
                CAST(json_extract(c.row_json, '$.contact_pi') AS REAL) AS metric_value,
                CAST(json_extract(c.row_json, '$.contact_pi') AS REAL) AS effect_score,
                'higher contact_pi means stronger contact-zone avoidance in frame metrics' AS metric_interpretation,
                json_extract(c.row_json, '$.frame_idx') AS time_bin,
                CAST(json_extract(c.row_json, '$.time_sec') AS REAL) / 60.0 AS time_start_min,
                CAST(json_extract(c.row_json, '$.time_sec') AS REAL) / 60.0 AS time_mid_min,
                CAST(json_extract(c.row_json, '$.time_sec') AS REAL) / 60.0 AS time_end_min,
                printf('%.1f sec', CAST(json_extract(c.row_json, '$.time_sec') AS REAL)) AS time_window,
                1 AS n_frames,
                CAST(json_extract(c.row_json, '$.n_total') AS INTEGER) AS organism_count,
                'individual_assay_timepoint' AS grain_type,
                c.provenance_grain
              FROM contact_recent_files f
              JOIN csv_rows_with_provenance c
                ON c.name = f.source_name
              WHERE json_extract(c.row_json, '$.contact_pi') IS NOT NULL
                AND trim(json_extract(c.row_json, '$.contact_pi')) <> ''
            )
            """
        )

    if family_scope.get("phytotox"):
        phytotox_metric_column, phytotox_metric_name, phytotox_metric_interpretation = _phytotox_timepoint_metric_for_question(question)
        branches.append(
            f"""
            phytotox_source_files AS (
              SELECT DISTINCT
                name AS source_name,
                substr(
                  substr(name, instr(name, 'phytotoxicity_tests_') + length('phytotoxicity_tests_')),
                  1,
                  instr(substr(name, instr(name, 'phytotoxicity_tests_') + length('phytotoxicity_tests_')), '/') - 1
                ) AS date_part
              FROM csv_columns_with_provenance
              WHERE name LIKE 'phytotoxicity/results/%/predictions/analysis/features_baseline_corrected.csv'
                AND column_name = 'time_point'
            ),
            phytotox_normalized_files AS (
              SELECT
                source_name,
                'plants' AS species,
                'phytotoxicity' AS assay_family,
                'leaf_image_timecourse' AS assay_mode,
                date_part AS assay_run_label,
                CASE
                  WHEN length(date_part) = 7 THEN '20' || substr(date_part, 6, 2) || '-0' || substr(date_part, 1, 1) || '-' || substr(date_part, 3, 2)
                  WHEN length(date_part) = 8 THEN '20' || substr(date_part, 7, 2) || '-' || substr(date_part, 1, 2) || '-' || substr(date_part, 4, 2)
                  ELSE NULL
                END AS run_date_iso
              FROM phytotox_source_files
            ),
            phytotox_eligible_files AS (
              SELECT
                *,
                run_date_iso || ' 00:00:00' AS run_datetime_iso
              FROM phytotox_normalized_files
              WHERE run_date_iso IS NOT NULL
                AND date(run_date_iso) <= date({today_cutoff})
                AND {run_date_filter}
            ),
            phytotox_recent_files AS (
              SELECT *
              FROM phytotox_eligible_files
              ORDER BY date(run_date_iso) DESC, source_name DESC
              LIMIT {recent_run_limit}
            ),
            phytotox_annotated_rows AS (
              SELECT
                f.source_name,
                c.row_number AS source_row_number,
                f.species,
                f.assay_family,
                f.assay_mode,
                f.assay_run_label,
                json_extract(c.row_json, '$.treatment_name') AS treatment_label,
                '' AS dilution,
                '' AS solvent,
                '' AS treatment_position,
                '' AS usable_data,
                f.run_datetime_iso,
                f.run_date_iso,
                'phytotoxicity test date parsed from result folder name' AS date_basis,
                json_extract(c.row_json, '$.replicate') AS tube,
                {sql_literal(phytotox_metric_name)} AS metric_name,
                CAST(json_extract(c.row_json, {sql_literal('$.' + phytotox_metric_column)}) AS REAL) AS metric_value,
                CAST(json_extract(c.row_json, {sql_literal('$.' + phytotox_metric_column)}) AS REAL) AS effect_score,
                {sql_literal(phytotox_metric_interpretation)} AS metric_interpretation,
                json_extract(c.row_json, '$.time_point') AS time_bin,
                CAST(json_extract(c.row_json, '$.time_point') AS REAL) AS time_start_min,
                CAST(json_extract(c.row_json, '$.time_point') AS REAL) AS time_mid_min,
                CAST(json_extract(c.row_json, '$.time_point') AS REAL) AS time_end_min,
                'time point ' || json_extract(c.row_json, '$.time_point') AS time_window,
                NULL AS n_frames,
                NULL AS organism_count,
                'individual_assay_timepoint' AS grain_type,
                c.provenance_grain
              FROM phytotox_recent_files f
              JOIN csv_rows_with_provenance c
                ON c.name = f.source_name
              WHERE lower(coalesce(json_extract(c.row_json, '$.condition'), '')) NOT LIKE '%control%'
                AND json_extract(c.row_json, {sql_literal('$.' + phytotox_metric_column)}) IS NOT NULL
                AND trim(json_extract(c.row_json, {sql_literal('$.' + phytotox_metric_column)})) <> ''
            )
            """
        )

    if not branches:
        return None

    branch_ctes = ",\n".join(branches)
    row_sources = []
    if family_scope.get("dart"):
        row_sources.append("SELECT * FROM dart_annotated_rows")
    if family_scope.get("contact"):
        row_sources.append("SELECT * FROM contact_annotated_rows")
    if family_scope.get("phytotox"):
        row_sources.append("SELECT * FROM phytotox_annotated_rows")
    union_sql = "\nUNION ALL\n".join(row_sources)

    return f"""
        WITH {branch_ctes},
        combined_rows AS (
          {union_sql}
        ),
        summary AS (
          SELECT
            {sql_literal(date_window)} AS date_window,
            count(DISTINCT source_name) AS recent_assay_files,
            count(*) AS timepoint_rows,
            min(run_datetime_iso) AS first_run_datetime,
            max(run_datetime_iso) AS latest_run_datetime
          FROM combined_rows
        ),
        ranked AS (
          SELECT
            row_number() OVER (
              ORDER BY effect_score DESC, datetime(run_datetime_iso) DESC, source_name DESC, source_row_number DESC
            ) AS rank,
            row_number() OVER (
              PARTITION BY assay_family, species, assay_mode
              ORDER BY effect_score DESC, datetime(run_datetime_iso) DESC, source_name DESC, source_row_number DESC
            ) AS rank_within_assay_slice,
            *
          FROM combined_rows
          WHERE effect_score IS NOT NULL
        )
        SELECT
          'ranked' AS ranking_status,
          rank,
          rank_within_assay_slice,
          species,
          assay_family,
          assay_mode,
          source_name,
          assay_run_label,
          treatment_label,
          dilution,
          solvent,
          treatment_position,
          usable_data,
          run_datetime_iso,
          run_date_iso,
          date_basis,
          tube,
          metric_name,
          metric_value,
          effect_score,
          metric_interpretation,
          'effect_score normalizes direction only, compare strongest timepoints within an assay family before comparing magnitude across families' AS cross_family_caution,
          time_bin,
          time_start_min,
          time_mid_min,
          time_end_min,
          time_window,
          n_frames,
          organism_count,
          date_window,
          recent_assay_files,
          timepoint_rows,
          first_run_datetime,
          latest_run_datetime,
          source_row_number,
          provenance_grain
        FROM ranked
        CROSS JOIN summary
        WHERE rank <= {answer_limit}
        UNION ALL
        SELECT
          'no_rankable_rows' AS ranking_status,
          NULL AS rank,
          NULL AS rank_within_assay_slice,
          NULL AS species,
          'timepoint_supported_assay_families' AS assay_family,
          NULL AS assay_mode,
          NULL AS source_name,
          NULL AS assay_run_label,
          NULL AS treatment_label,
          NULL AS dilution,
          NULL AS solvent,
          NULL AS treatment_position,
          NULL AS usable_data,
          NULL AS run_datetime_iso,
          NULL AS run_date_iso,
          'structured timepoint sources checked, oviposition has no parsed timepoint source in bucket' AS date_basis,
          NULL AS tube,
          NULL AS metric_name,
          NULL AS metric_value,
          NULL AS effect_score,
          'source gap: no rankable within-assay timepoint rows matched the requested family, species, metric, or date window' AS metric_interpretation,
          'do not substitute assay start time or upload time for within-assay timepoint rows' AS cross_family_caution,
          NULL AS time_bin,
          NULL AS time_start_min,
          NULL AS time_mid_min,
          NULL AS time_end_min,
          NULL AS time_window,
          NULL AS n_frames,
          NULL AS organism_count,
          date_window,
          recent_assay_files,
          timepoint_rows,
          first_run_datetime,
          latest_run_datetime,
          NULL AS source_row_number,
          json_object(
            'grain_id', 'individual_assay_timepoint:no_rankable_rows:' || date_window,
            'grain_type', 'individual_assay_timepoint',
            'locator', 'structured_timepoint_sources#latest=' || {recent_run_limit},
            'source_id', 'monarch_videos_new',
            'source_gap_reason', 'no rankable within-assay timepoint rows matched'
          ) AS provenance_grain
        FROM summary
        WHERE coalesce(timepoint_rows, 0) = 0
        ORDER BY ranking_status DESC, rank
    """


def _bucket_dart_individual_assay_timepoint_applies(question):
    q = str(question).lower()
    asks_timepoint = _has_any(
        q,
        [
            "time point",
            "timepoint",
            "time bin",
            "time-bin",
            "time window",
            "within assay",
            "inside assay",
            "minute",
            "minutes",
        ],
    )
    asks_effect = _has_any(q, ["repellent", "repellency", "avoidance", "preference index", " pi", " dart"])
    asks_assay = _has_any(q, ["dart", "assay", "assays", "experiment", "experiments"])
    return asks_timepoint and asks_effect and asks_assay


def _last_n_assay_runs_for_question(question, default=10):
    q = str(question).lower()
    match = re.search(r"\b(?:last|latest|recent|newest)\s+(\d{1,3})\s+(?:dart\s+)?(?:assay|assays|run|runs|experiment|experiments)\b", q)
    if match:
        return max(1, min(int(match.group(1)), 100))
    return default


def _bucket_dart_individual_assay_timepoint_sql(question):
    if not _bucket_dart_individual_assay_timepoint_applies(question):
        return None
    species = species_from_question(question)
    species_filter = f"AND species = {sql_literal(species)}" if species in {"flies", "mosquitoes"} else ""
    recent_run_limit = _last_n_assay_runs_for_question(question, default=10)
    answer_limit = 1
    if _has_any(str(question).lower(), ["top ", "rank ", "ranked ", "list "]):
        answer_limit = _rank_limit_for_question(question, default=1)
    answer_limit = max(1, min(answer_limit, 25))
    today_cutoff = sql_literal(_local_today().isoformat())

    metric_selects = []
    for tube in range(1, 9):
        metric_selects.append(
            f"""
              SELECT
                source_name,
                source_row_number,
                species,
                processed_folder,
                run_datetime_iso,
                run_date_iso,
                is_control,
                {sql_literal('T' + str(tube))} AS tube,
                {sql_literal('T' + str(tube) + '_trt_PI')} AS metric_name,
                CASE
                  WHEN json_extract(row_json, '$.T{tube}_trt_PI') IS NOT NULL
                   AND trim(json_extract(row_json, '$.T{tube}_trt_PI')) <> ''
                  THEN CAST(json_extract(row_json, '$.T{tube}_trt_PI') AS REAL)
                  ELSE NULL
                END AS metric_value,
                json_extract(row_json, '$.time_bin') AS time_bin,
                CAST(json_extract(row_json, '$.time_start_min') AS REAL) AS time_start_min,
                CAST(json_extract(row_json, '$.time_mid_min') AS REAL) AS time_mid_min,
                CAST(json_extract(row_json, '$.time_end_min') AS REAL) AS time_end_min,
                CAST(json_extract(row_json, '$.n_frames') AS INTEGER) AS n_frames,
                CAST(json_extract(row_json, '$.T{tube}_total') AS INTEGER) AS tube_total_detections,
                provenance_grain
              FROM time_rows
            """
        )
    metric_union_sql = "\nUNION ALL\n".join(metric_selects)

    return f"""
        WITH source_files AS (
          SELECT DISTINCT
            name AS source_name,
            CASE
              WHEN name LIKE 'flies/processed/%/results_by_time.csv' THEN 'flies'
              WHEN name LIKE 'mosquitoes/processed/%/results_by_time.csv' THEN 'mosquitoes'
              ELSE NULL
            END AS species,
            substr(substr(name, instr(name, 'processed/') + 10), 1, instr(substr(name, instr(name, 'processed/') + 10), '/') - 1) AS processed_folder
          FROM csv_columns_with_provenance
          WHERE (
              name LIKE 'flies/processed/%/results_by_time.csv'
              OR name LIKE 'mosquitoes/processed/%/results_by_time.csv'
            )
            AND column_name = 'time_bin'
        ),
        normalized_files AS (
          SELECT
            source_name,
            species,
            processed_folder,
            CASE
              WHEN species = 'flies' THEN
                substr(processed_folder, 1, 10) || ' ' || replace(substr(processed_folder, 12, 8), '-', ':')
              WHEN species = 'mosquitoes' THEN
                substr(processed_folder, 2, 4) || '-' ||
                substr(processed_folder, 7, 2) || '-' ||
                substr(processed_folder, 10, 2) || ' ' ||
                substr(processed_folder, 13, 2) || ':' ||
                substr(processed_folder, 16, 2) || ':' ||
                substr(processed_folder, 19, 2)
              ELSE NULL
            END AS run_datetime_iso,
            CASE
              WHEN species = 'flies' THEN substr(processed_folder, 1, 10)
              WHEN species = 'mosquitoes' THEN
                substr(processed_folder, 2, 4) || '-' ||
                substr(processed_folder, 7, 2) || '-' ||
                substr(processed_folder, 10, 2)
              ELSE NULL
            END AS run_date_iso,
            CASE
              WHEN lower(processed_folder) LIKE '%control%' THEN 1
              ELSE 0
            END AS is_control
          FROM source_files
          WHERE species IS NOT NULL
          {species_filter}
        ),
        eligible_files AS (
          SELECT *
          FROM normalized_files
          WHERE run_date_iso IS NOT NULL
            AND date(run_date_iso) <= date({today_cutoff})
        ),
        recent_files AS (
          SELECT *
          FROM eligible_files
          ORDER BY datetime(run_datetime_iso) DESC, source_name DESC
          LIMIT {recent_run_limit}
        ),
        time_rows AS (
          SELECT
            r.source_name,
            c.row_number AS source_row_number,
            r.species,
            r.processed_folder,
            r.run_datetime_iso,
            r.run_date_iso,
            r.is_control,
            c.row_json,
            c.provenance_grain
          FROM recent_files r
          JOIN csv_rows_with_provenance c
            ON c.name = r.source_name
        ),
        fly_metadata AS (
          SELECT
            max(CASE WHEN cell = 'B' || row_number THEN value END) AS filename,
            max(CASE WHEN cell = 'I' || row_number THEN value END) AS tube_number,
            max(CASE WHEN cell = 'N' || row_number THEN value END) AS treatment_label,
            max(CASE WHEN cell = 'O' || row_number THEN value END) AS dilution,
            max(CASE WHEN cell = 'P' || row_number THEN value END) AS solvent,
            max(CASE WHEN cell = 'S' || row_number THEN value END) AS treatment_position,
            max(CASE WHEN cell = 'U' || row_number THEN value END) AS usable_data
          FROM xlsx_cells_with_provenance
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet = 'trials'
            AND row_number > 1
          GROUP BY row_number
        ),
        summary AS (
          SELECT
            {sql_literal('latest_' + str(recent_run_limit) + '_processed_dart_assay_files')} AS date_window,
            'processed results_by_time run datetime from source path' AS date_basis,
            count(DISTINCT source_name) AS recent_assay_files,
            count(DISTINCT CASE WHEN is_control = 0 THEN source_name END) AS recent_non_control_assay_files,
            count(*) AS time_bin_rows,
            min(run_datetime_iso) AS first_run_datetime,
            max(run_datetime_iso) AS latest_run_datetime,
            min(source_name) AS example_source_name
          FROM time_rows
        ),
        metric_rows AS (
          {metric_union_sql}
        ),
        annotated AS (
          SELECT
            m.*,
            coalesce(
              fm.treatment_label,
              CASE
                WHEN m.species = 'mosquitoes' THEN replace(substr(m.processed_folder, 22), '_mov_results', '')
                ELSE NULL
              END,
              m.processed_folder
            ) AS treatment_label,
            coalesce(fm.dilution, '') AS dilution,
            coalesce(fm.solvent, '') AS solvent,
            coalesce(fm.treatment_position, '') AS treatment_position,
            coalesce(fm.usable_data, '') AS usable_data
          FROM metric_rows m
          LEFT JOIN fly_metadata fm
            ON m.species = 'flies'
           AND fm.filename = substr(m.processed_folder, 1, 19) || '.mp4'
           AND fm.tube_number = replace(m.tube, 'T', '')
        ),
        scored AS (
          SELECT *
          FROM annotated
          WHERE is_control = 0
            AND metric_value IS NOT NULL
        ),
        ranked AS (
          SELECT
            row_number() OVER (
              ORDER BY metric_value ASC, datetime(run_datetime_iso) DESC, source_name DESC, source_row_number DESC, metric_name
            ) AS rank,
            *
          FROM scored
        )
        SELECT
          'ranked' AS ranking_status,
          rank,
          species,
          'DART' AS assay_family,
          source_name,
          processed_folder AS assay_run_label,
          treatment_label,
          dilution,
          solvent,
          treatment_position,
          usable_data,
          run_datetime_iso,
          run_date_iso,
          tube,
          metric_name,
          metric_value,
          metric_value AS best_repellency_pi,
          'more negative treatment-side PI means stronger repellency/avoidance' AS metric_interpretation,
          time_bin,
          time_start_min,
          time_mid_min,
          time_end_min,
          printf('%.1f-%.1f min', time_start_min, time_end_min) AS time_window,
          n_frames,
          tube_total_detections,
          s.date_window,
          s.date_basis,
          s.recent_assay_files,
          s.recent_non_control_assay_files,
          s.time_bin_rows,
          s.first_run_datetime,
          s.latest_run_datetime,
          source_row_number,
          provenance_grain
        FROM ranked
        CROSS JOIN summary s
        WHERE rank <= {answer_limit}
        UNION ALL
        SELECT
          'no_rankable_rows' AS ranking_status,
          NULL AS rank,
          NULL AS species,
          'DART' AS assay_family,
          NULL AS source_name,
          NULL AS assay_run_label,
          NULL AS treatment_label,
          NULL AS dilution,
          NULL AS solvent,
          NULL AS treatment_position,
          NULL AS usable_data,
          NULL AS run_datetime_iso,
          NULL AS run_date_iso,
          NULL AS tube,
          'T*_trt_PI' AS metric_name,
          NULL AS metric_value,
          NULL AS best_repellency_pi,
          'more negative treatment-side PI means stronger repellency/avoidance' AS metric_interpretation,
          NULL AS time_bin,
          NULL AS time_start_min,
          NULL AS time_mid_min,
          NULL AS time_end_min,
          NULL AS time_window,
          NULL AS n_frames,
          NULL AS tube_total_detections,
          date_window,
          date_basis,
          recent_assay_files,
          recent_non_control_assay_files,
          time_bin_rows,
          first_run_datetime,
          latest_run_datetime,
          NULL AS source_row_number,
          json_object(
            'grain_id', 'dart_individual_assay_timepoint:' || date_window,
            'grain_type', 'dart_individual_assay_timepoint',
            'locator', 'results_by_time.csv#latest=' || {recent_run_limit},
            'source_id', 'monarch_videos_new',
            'date_basis', date_basis
          ) AS provenance_grain
        FROM summary
        WHERE coalesce(recent_non_control_assay_files, 0) = 0
        ORDER BY ranking_status DESC, rank
    """


def _dart_sql(question):
    q = question.lower()
    if (
        "dart" not in q
        and not _has_any(q, ["repellency", "repellent", "repellents", "preference index", "avg pi", "assay metrics", "assay evidence", "metric csv"])
        and not (_is_ranking_question(question) and species_from_question(question) and _has_any(q, ["treatment", "treatments", "compound", "compounds", "chemical", "chemicals"]))
        and not (_has_any(q, ["experimental data", "experiment data", "assay data"]) and _extract_dart_treatment(question))
        and not _dart_assay_ledger_listing_applies(question)
    ):
        return None
    metric_match = re.search(r"assay metrics for\s+(.+?)\??$", q)
    if metric_match:
        needle = metric_match.group(1).strip(" ?.")
        return f"""
            SELECT name, row_number, row_json, provenance_grain
            FROM csv_rows_with_provenance
            WHERE lower(name) LIKE {sql_literal('%' + needle + '%advanced_metrics.csv')}
               OR lower(name) LIKE {sql_literal('%' + needle + '%frame_metrics.csv')}
            ORDER BY name, row_number
        """
    assay_date_iso = _compact_assay_date_iso_sql("assay_date")
    date_details = _optional_assay_date_filter_details(question, "assay_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    species = species_from_question(question)
    species_filter = f"AND lower(species) = {sql_literal(species)}" if species else ""
    if _dart_assay_ledger_listing_applies(question):
        return f"""
            WITH normalized AS (
              SELECT
                *,
                {assay_date_iso} AS assay_date_iso,
                CASE
                  WHEN time_started IS NOT NULL
                   AND trim(time_started) GLOB '0.*'
                  THEN printf(
                    '%02d:%02d:%02d',
                    CAST(CAST(time_started AS REAL) * 24 AS INTEGER),
                    CAST(CAST(CAST(time_started AS REAL) * 1440 AS INTEGER) % 60 AS INTEGER),
                    CAST(CAST(round(CAST(time_started AS REAL) * 86400) AS INTEGER) % 60 AS INTEGER)
                  )
                  ELSE time_started
                END AS time_started_clock
              FROM dart_assay_results
              WHERE lower(assay_type) = 'dart'
            )
            SELECT
              species,
              assay_type,
              assay_date_iso,
              {sql_literal(date_window)} AS date_window,
              'dart_assay_results.assay_date' AS date_basis,
              source_name,
              sheet,
              row_number,
              filename,
              tube,
              treatment,
              treatment_normalized,
              context,
              left_condition,
              right_condition,
              treatment_position,
              dilution,
              dilution_real,
              solvent,
              n_insects,
              n_insects_real,
              temp,
              rh,
              time_started AS time_started_raw,
              time_started_clock,
              avg_pi,
              avg_pi_real,
              'avg_pi_real' AS metric_name,
              avg_pi_real AS metric_value,
              provenance_grain
            FROM normalized
            WHERE assay_date_iso IS NOT NULL
              AND ({date_filter})
              {species_filter}
            ORDER BY date(assay_date_iso), source_name, row_number
        """
    if _has_recency_order_modifier(question) and _is_ranking_question(question):
        recency_limit = _rank_limit_for_question(question, default=10)
        today_cutoff = sql_literal(_local_today().isoformat())
        return f"""
            WITH normalized AS (
              SELECT
                *,
                {assay_date_iso} AS assay_date_iso,
                CASE
                  WHEN time_started IS NOT NULL
                   AND trim(time_started) GLOB '0.*'
                  THEN printf(
                    '%02d:%02d:%02d',
                    CAST(CAST(time_started AS REAL) * 24 AS INTEGER),
                    CAST(CAST(CAST(time_started AS REAL) * 1440 AS INTEGER) % 60 AS INTEGER),
                    CAST(CAST(round(CAST(time_started AS REAL) * 86400) AS INTEGER) % 60 AS INTEGER)
                  )
                  ELSE time_started
                END AS time_started_clock
              FROM dart_assay_results
              WHERE lower(assay_type) = 'dart'
            ),
            eligible AS (
              SELECT *
              FROM normalized
              WHERE assay_date_iso IS NOT NULL
                AND date(assay_date_iso) <= date({today_cutoff})
                {species_filter}
            ),
            recent AS (
              SELECT *
              FROM eligible
              ORDER BY date(assay_date_iso) DESC, source_name DESC, row_number DESC
              LIMIT {recency_limit}
            ),
            summary AS (
              SELECT
                {sql_literal('latest_' + str(recency_limit) + '_dart_assay_rows')} AS date_window,
                'dart_assay_results.assay_date' AS date_basis,
                count(*) AS assay_rows_in_window,
                sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows_in_window,
                sum(CASE
                  WHEN avg_pi_real IS NOT NULL
                   AND lower(coalesce(treatment_normalized, treatment, '')) NOT IN ('control', 'ctrl', 'vehicle control')
                  THEN 1 ELSE 0 END
                ) AS scored_non_control_rows,
                min(assay_date_iso) AS first_assay_date,
                max(assay_date_iso) AS latest_assay_date,
                min(source_name) AS example_source_name,
                min(row_number) AS example_row_number
              FROM recent
            ),
            scored AS (
              SELECT *
              FROM recent
              WHERE avg_pi_real IS NOT NULL
                AND lower(coalesce(treatment_normalized, treatment, '')) NOT IN ('control', 'ctrl', 'vehicle control')
            ),
            ranked AS (
              SELECT
                row_number() OVER (ORDER BY avg_pi_real ASC, date(assay_date_iso) DESC, row_number DESC) AS rank,
                *
              FROM scored
            )
            SELECT
              'ranked' AS ranking_status,
              rank,
              species,
              assay_type,
              treatment_normalized,
              dilution,
              dilution_real,
              assay_date_iso,
              time_started AS time_started_raw,
              time_started_clock,
              coalesce(time_started_clock, time_started) AS time_point,
              'avg_pi_real' AS metric_name,
              avg_pi_real AS metric_value,
              avg_pi_real AS best_single_avg_pi,
              s.date_window,
              s.date_basis,
              s.assay_rows_in_window,
              s.scored_rows_in_window,
              s.scored_non_control_rows,
              s.first_assay_date,
              s.latest_assay_date,
              source_name AS example_source_name,
              sheet AS example_sheet,
              row_number AS example_row_number,
              filename AS example_filename,
              provenance_grain
            FROM ranked
            CROSS JOIN summary s
            WHERE rank = 1
            UNION ALL
            SELECT
              'no_rankable_rows' AS ranking_status,
              NULL AS rank,
              NULL AS species,
              'DART' AS assay_type,
              NULL AS treatment_normalized,
              NULL AS dilution,
              NULL AS dilution_real,
              NULL AS assay_date_iso,
              NULL AS time_started_raw,
              NULL AS time_started_clock,
              NULL AS time_point,
              'avg_pi_real' AS metric_name,
              NULL AS metric_value,
              NULL AS best_single_avg_pi,
              date_window,
              date_basis,
              assay_rows_in_window,
              scored_rows_in_window,
              scored_non_control_rows,
              first_assay_date,
              latest_assay_date,
              example_source_name,
              NULL AS example_sheet,
              example_row_number,
              NULL AS example_filename,
              json_object(
                'grain_id', 'dart_recent_rank_window:' || date_window,
                'grain_type', 'dart_recent_rank_window',
                'locator', 'dart_assay_results#latest=' || {recency_limit},
                'source_id', 'monarch_videos_new',
                'date_basis', 'dart_assay_results.assay_date'
              ) AS provenance_grain
            FROM summary
            WHERE coalesce(scored_non_control_rows, 0) = 0
            ORDER BY ranking_status DESC, rank
        """
    treatment = _extract_dart_treatment(question)
    if treatment:
        return f"""
            WITH normalized AS (
              SELECT *, {assay_date_iso} AS assay_date_iso
              FROM dart_assay_results
            )
            SELECT
              species,
              assay_type,
              treatment_normalized,
              {sql_literal(date_window)} AS date_window,
              'dart_assay_results.assay_date' AS date_basis,
              dilution,
              dilution_real,
              count(*) AS assay_rows,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows,
              avg(avg_pi_real) AS mean_avg_pi,
              min(assay_date_iso) AS first_assay_date,
              max(assay_date_iso) AS latest_assay_date,
              group_concat(DISTINCT source_name) AS source_names
            FROM normalized
            WHERE (
              lower(treatment_normalized) = lower({sql_literal(treatment)})
              OR lower(treatment) = lower({sql_literal(treatment)})
            )
            AND assay_date_iso IS NOT NULL
            AND ({date_filter})
            {species_filter}
            GROUP BY species, assay_type, treatment_normalized, dilution_real
            ORDER BY assay_rows DESC, scored_rows DESC, treatment_normalized
        """
    if _dart_best_concentration_helper_applies(question):
        return None
    if _has_any(q, ["how many", "count", "number of"]):
        return f"""
            WITH normalized AS (
              SELECT *, {assay_date_iso} AS assay_date_iso
              FROM dart_assay_results
            )
            SELECT
              {sql_literal(date_window)} AS date_window,
              'dart_assay_results.assay_date' AS date_basis,
              count(*) AS assay_rows,
              count(DISTINCT species) AS species_count,
              count(DISTINCT treatment_normalized) AS treatment_count,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows,
              min(assay_date_iso) AS first_assay_date,
              max(assay_date_iso) AS latest_assay_date
            FROM normalized
            WHERE assay_date_iso IS NOT NULL
              AND ({date_filter})
        """
    if _is_ranking_question(question):
        return f"""
            WITH normalized AS (
              SELECT *, {assay_date_iso} AS assay_date_iso
              FROM dart_assay_results
            )
            SELECT
              species,
              assay_type,
              treatment_normalized,
              {sql_literal(date_window)} AS date_window,
              'dart_assay_results.assay_date' AS date_basis,
              dilution,
              dilution_real,
              count(*) AS assay_rows,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows,
              avg(avg_pi_real) AS mean_avg_pi,
              min(avg_pi_real) AS best_single_avg_pi,
              max(avg_pi_real) AS least_effective_single_avg_pi,
              min(assay_date_iso) AS first_assay_date,
              max(assay_date_iso) AS latest_assay_date,
              group_concat(DISTINCT source_name) AS source_names
            FROM normalized
            WHERE avg_pi_real IS NOT NULL
              AND assay_date_iso IS NOT NULL
              AND ({date_filter})
            GROUP BY species, assay_type, treatment_normalized, dilution_real
            ORDER BY mean_avg_pi ASC, scored_rows DESC, treatment_normalized
        """
    if _has_any(q, ["list", "show", "which"]):
        return """
            SELECT
              species,
              assay_type,
              treatment_normalized,
              dilution,
              dilution_real,
              count(*) AS assay_rows,
              sum(CASE WHEN avg_pi_real IS NOT NULL THEN 1 ELSE 0 END) AS scored_rows
            FROM dart_assay_results
            GROUP BY species, assay_type, treatment_normalized, dilution_real
            ORDER BY species, assay_type, treatment_normalized, dilution_real
        """
    return None


def _bucket_phytotox_metric_reference_sql(question):
    if not _is_phytotox_metric_reference_question(question):
        return None
    return """
        WITH guide_rows AS (
          SELECT
            0 AS sort_order,
            'guide_page' AS evidence_kind,
            name AS source_name,
            page_number,
            'phytotoxicity_metrics_reference_guide' AS metric_family,
            substr(text, 1, 2200) AS evidence_text,
            provenance_grain
          FROM pdf_pages
          WHERE name = 'documentation/phytotoxicity_metrics_reference_guide.pdf'
            AND page_number BETWEEN 1 AND 13
        ),
        schema_columns AS (
          SELECT
            name,
            column_name,
            ordinal,
            provenance_grain
          FROM csv_columns_with_provenance
          WHERE name IN (
            'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/features_all.csv',
            'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/features_baseline_corrected.csv',
            'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/ranked_features.csv',
            'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/stats_by_timepoint.csv',
            'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/stats_control_vs_treatment.csv',
            'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/time_trajectories.csv'
          )
          ORDER BY name, ordinal
        ),
        schema_rows AS (
          SELECT
            1 AS sort_order,
            'result_schema' AS evidence_kind,
            name AS source_name,
            NULL AS page_number,
            'phytotoxicity_result_schema' AS metric_family,
            'columns: ' || group_concat(column_name, ', ') AS evidence_text,
            min(provenance_grain) AS provenance_grain
          FROM schema_columns
          GROUP BY name
        )
        SELECT *
        FROM guide_rows
        UNION ALL
        SELECT *
        FROM schema_rows
        ORDER BY sort_order, page_number, source_name
    """


def _bucket_assay_metric_reference_sql(question):
    if not _is_assay_metric_reference_question(question):
        return None
    if _is_contact_metric_reference_question(question):
        return """
            SELECT
              name AS source_name,
              page_number,
              'contact_repellency_assay' AS metric_family,
              substr(text, 1, 2200) AS evidence_text,
              provenance_grain
            FROM pdf_pages
            WHERE name = 'documentation/contact_repellency_assay_detection_and_analysis_reference.pdf'
              AND page_number IN (1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15, 18, 19)
            ORDER BY page_number
        """
    return """
        SELECT
          name AS source_name,
          page_number,
          CASE
            WHEN name = 'documentation/insect_assay_metrics_reference.pdf' THEN 'tube_behavioral_assay'
            WHEN name = 'documentation/contact_repellency_assay_detection_and_analysis_reference.pdf' THEN 'contact_repellency_assay'
          END AS metric_family,
          substr(text, 1, 2200) AS evidence_text,
          provenance_grain
        FROM pdf_pages
        WHERE (
          name = 'documentation/insect_assay_metrics_reference.pdf'
          AND page_number IN (1, 2, 3, 4, 5, 7, 8, 9, 10)
        )
        OR (
          name = 'documentation/contact_repellency_assay_detection_and_analysis_reference.pdf'
          AND page_number IN (1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15, 18, 19)
        )
        ORDER BY
          CASE
            WHEN name = 'documentation/insect_assay_metrics_reference.pdf' THEN 0
            ELSE 1
          END,
          page_number
    """


def _phytotoxicity_sql(question):
    q = question.lower()
    if not _has_any(q, ["phytotoxicity", "phytotoxic", "phytoxic", "phytotox", "soybean leaf", "plant damage", "leaf damage", "chlorosis", "browning", "necrosis", "damaged fraction"]):
        return None
    if _has_any(q, ["best", "top", "rank", "ranking", "most", "least", "highest", "lowest", "score", "metric", "damage", "chlorosis", "browning", "necrosis", "damaged fraction"]):
        return """
            SELECT
              name,
              row_number,
              json_extract(row_json, '$.date') AS assay_date,
              json_extract(row_json, '$.treatment_name') AS treatment_name,
              json_extract(row_json, '$.condition') AS condition,
              json_extract(row_json, '$.concentration') AS concentration,
              json_extract(row_json, '$.concentration_unit') AS concentration_unit,
              CAST(json_extract(row_json, '$.damaged_fraction') AS REAL) AS damaged_fraction,
              CAST(json_extract(row_json, '$.chlorosis_fraction') AS REAL) AS chlorosis_fraction,
              CAST(json_extract(row_json, '$.browning_fraction') AS REAL) AS browning_fraction,
              CAST(json_extract(row_json, '$.necrosis_fraction') AS REAL) AS necrosis_fraction,
              json_object(
                'grain_id', name || '#row=' || row_number,
                'grain_type', 'csv_row',
                'locator', 'gs://monarch-videos-new/' || name || '#row=' || row_number,
                'source_id', 'monarch_videos_new'
              ) AS provenance_grain
            FROM csv_rows
            WHERE name IN (
              'phytotoxicity/results/phytotoxicity_tests_03_30_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_3_24_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_02_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_06_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_13_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_14_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_16_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_20_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_21_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_22_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_23_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_27_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_28_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_29_26/predictions/analysis/features_all.csv',
              'phytotoxicity/results/phytotoxicity_tests_4_30_26/predictions/analysis/features_all.csv'
            )
              AND json_extract(row_json, '$.damaged_fraction') IS NOT NULL
            ORDER BY damaged_fraction DESC, chlorosis_fraction DESC, browning_fraction DESC
        """
    if _has_any(q, ["how many", "count", "number of", "what data", "which data", "what sources", "which sources", "list", "show"]):
        return """
            SELECT name, sheet,
                   count(DISTINCT row_number) AS workbook_rows,
                   count(*) AS cells
            FROM xlsx_cells
            WHERE name LIKE 'phytotoxicity/%'
               OR lower(sheet) LIKE '%phytotoxicity%'
            GROUP BY name, sheet
            ORDER BY name, sheet
        """
    return """
        SELECT name, column_name, ordinal
        FROM csv_columns_with_provenance
        WHERE lower(name) LIKE 'phytotoxicity/%'
        ORDER BY name, ordinal
    """


def _bucket_phytotox_experiment_summary_sql(question):
    q = question.lower()
    if not _has_any(q, ["phytotoxicity", "phytotoxic", "phytoxic", "phytotox", "plant", "plants", "soybean", "leaf", "leaves", "safe", "damage", "damaged"]):
        return None
    order = "ASC" if _has_any(q, ["safe", "least", "lowest", "minimal"]) else "DESC"
    return f"""
        SELECT
          name,
          row_number,
          json_extract(row_json, '$.date') AS assay_date,
          json_extract(row_json, '$.treatment_name') AS treatment_name,
          json_extract(row_json, '$.condition') AS condition,
          json_extract(row_json, '$.concentration') AS concentration,
          json_extract(row_json, '$.concentration_unit') AS concentration_unit,
          CAST(json_extract(row_json, '$.damaged_fraction') AS REAL) AS damaged_fraction,
          CAST(json_extract(row_json, '$.chlorosis_fraction') AS REAL) AS chlorosis_fraction,
          CAST(json_extract(row_json, '$.browning_fraction') AS REAL) AS browning_fraction,
          CAST(json_extract(row_json, '$.necrosis_fraction') AS REAL) AS necrosis_fraction,
          json_object(
            'grain_id', 'phytotox_experiment_summary:' || name || ':' || row_number,
            'grain_type', 'phytotox_result_row',
            'locator', 'gs://monarch-videos-new/' || name || '#row=' || row_number,
            'source_id', 'monarch_videos_new',
            'source_provenance_grain', json_object(
              'source_type', 'google_cloud_storage_object',
              'source_id', 'gs://monarch-videos-new',
              'grain_type', 'csv_row',
              'grain_id', name || '#row=' || row_number,
              'version_or_modified_time', generation,
              'locator', 'gs://monarch-videos-new/' || name || '#row=' || row_number
            )
          ) AS provenance_grain
        FROM csv_rows
        WHERE name >= 'phytotoxicity/results/'
          AND name < 'phytotoxicity/results0'
          AND name LIKE 'phytotoxicity/results/%/predictions/analysis/features_all.csv'
          AND json_extract(row_json, '$.damaged_fraction') IS NOT NULL
        ORDER BY damaged_fraction {order}, chlorosis_fraction {order}, browning_fraction {order}, treatment_name
    """


def _bucket_structured_candidate_routes(question):
    q = question.lower()
    candidates = []

    def add(sql, intent, adapter, reason, answer_shapes=None, partial_answer_shapes=None, **extra):
        if not sql:
            return
        candidates.append(
            _route_candidate(
                intent=intent,
                source_lane="bucket",
                retrieval_shape="structured",
                adapter=adapter,
                adapter_execution="sql",
                sql=sql,
                reason=reason,
                answer_shapes=answer_shapes,
                partial_answer_shapes=partial_answer_shapes,
                **extra,
            )
        )

    add(
        _bucket_script_method_evidence_sql(question),
        "script_method_evidence",
        "bucket_script_method_evidence_sql",
        "method, metric, pipeline, and debug questions should expose the script files and line-level code evidence used",
        answer_shapes=["script_method_evidence"],
    )

    serving_table_sql = _bucket_assay_serving_table_sql(question)
    add(
        serving_table_sql,
        "assay_serving_table",
        "bucket_assay_serving_table_sql",
        "recurring assay/result questions should use answer-ready serving tables before source-specific CSV or workbook adapters",
        answer_shapes=[
            "assay_inventory_count",
            "assay_run_list",
            "contact_noncontact_ranked_comparison",
            "fly_assay_count",
            "ranked_cross_assay_repellent_compounds",
            "ranked_fly_repellent_compounds",
            "ranked_phytotoxicity_compounds",
            "ranked_repellent_compounds",
            "ranked_species_repellent_compounds",
            "tested_compound_date_window",
            "tested_compound_list",
            "assay_best_result_environment_conditions",
        ],
        serving_tables=["assay_runs", "assay_results", "compound_test_events", "media_links"],
        species=species_from_question(question),
        species_scope=_assay_species_constraints_from_question(question),
        extracted_parameters=(
            _assay_ledger_date_filter_details(question, "event_date_iso")["parameters"]
            if _question_has_date_modifier(question)
            else None
        ),
    )

    add(
        _bucket_docking_pipeline_sql(question),
        "docking_pipeline",
        "bucket_docking_pipeline_sql",
        "the docking pipeline source is indexed as bucket text lines",
        answer_shapes=["docking_pipeline"],
    )
    add(
        _bucket_docking_results_sql(question),
        "docking_results",
        "bucket_docking_results_sql",
        "docking result lookups should inspect structured bucket result artifacts before prose search",
        answer_shapes=["docking_results"],
    )
    add(
        _bucket_fly_assay_count_sql(question),
        "fly_assay_count",
        "bucket_fly_assay_count_sql",
        "fly assay count questions should count distinct fly metadata filenames and trial rows, not DART rows",
        answer_shapes=["fly_assay_count"],
        species="flies",
    )
    add(
        _bucket_assay_best_result_environment_conditions_sql(question),
        "assay_best_result_environment_conditions",
        "bucket_assay_best_result_environment_conditions_sql",
        "best-result environment questions should rank usable result rows and join them to temp/RH metadata by species",
        answer_shapes=["assay_best_result_environment_conditions"],
    )
    add(
        _bucket_individual_assay_timepoint_sql(question),
        "individual_assay_timepoint_ranking",
        "bucket_individual_assay_timepoint_sql",
        "within-assay timepoint questions should read frame, bin, or longitudinal timepoint rows across supported assay families instead of run-level timestamps",
        answer_shapes=["individual_assay_timepoint_ranking", "dart_individual_assay_timepoint_ranking"],
        species=species_from_question(question),
    )
    add(
        _bucket_contact_noncontact_adjusted_pi_comparison_sql(question),
        "contact_noncontact_ranked_comparison",
        "bucket_contact_noncontact_adjusted_pi_comparison_sql",
        "contact versus non-contact comparison questions should rank the adjusted contact PI summary by parsed assay mode",
        answer_shapes=["contact_noncontact_ranked_comparison"],
    )
    add(
        _bucket_rank_expectation_explanation_sql(question),
        "rank_expectation_explanation",
        "bucket_rank_expectation_explanation_sql",
        "benchmark pushback questions should show the compound's actual rank and nearby rows under the selected metric",
        answer_shapes=["rank_expectation_explanation"],
    )
    add(
        _bucket_assay_summary_file_explanation_sql(question),
        "assay_summary_file_explanation",
        "bucket_assay_summary_file_explanation_sql",
        "summary-file explanation questions should inspect file metadata, schema, and metric meaning before prose",
        answer_shapes=["assay_summary_file_explanation"],
    )
    add(
        _bucket_assay_metric_reference_sql(question),
        "assay_metric_reference",
        "bucket_assay_metric_reference_sql",
        "assay metric-definition questions should read the metric reference guides before similarly named result artifacts",
        answer_shapes=["metric_definition"],
    )
    add(
        _bucket_phytotox_metric_reference_sql(question),
        "phytotox_metric_reference",
        "bucket_phytotox_metric_reference_sql",
        "phytotoxicity metric-definition questions should read the metrics reference guide first, then confirm emitted result schemas",
        answer_shapes=["metric_definition"],
    )
    add(
        _bucket_fly_result_video_bridge_sql(question),
        "fly_result_video_bridge",
        "bucket_fly_result_video_bridge_sql",
        "fly result plus media questions should join ranked fly repellency rows to matching video objects",
        answer_shapes=["ranked_repellents_with_media", "fly_result_video_bridge"],
        species="flies",
    )
    add(
        _bucket_fly_trial_metadata_join_sql(question),
        "fly_trial_metadata_join",
        "bucket_fly_trial_metadata_join_sql",
        "fly trial metadata questions should join trial workbook rows to abbreviation rows",
        answer_shapes=["fly_trial_metadata"],
        species="flies",
    )
    recent_contact_assays_sql = _bucket_recent_contact_no_contact_assays_sql(question)
    recent_contact_species_scope = _assay_species_constraints_from_question(question)
    add(
        recent_contact_assays_sql,
        "recent_contact_no_contact_assays",
        "bucket_recent_contact_no_contact_assays_sql",
        "recent contact/no-contact assay questions should read raw bucket object rows before generic assay anchors or prose search",
        answer_shapes=["recent_contact_no_contact_assays", "assay_runs_with_media"],
        species=recent_contact_species_scope[0] if len(recent_contact_species_scope) == 1 else None,
        species_scope=recent_contact_species_scope,
        extracted_parameters=_bucket_recent_contact_no_contact_assays_parameters(question) if recent_contact_assays_sql else None,
    )
    recent_media_sql = _bucket_recent_media_by_mode_sql(question)
    add(
        recent_media_sql,
        "recent_media_by_mode",
        "bucket_recent_media_by_mode_sql",
        "recent media lookup questions should inspect bucket object metadata before prose search",
        answer_shapes=["recent_media_by_mode", "assay_runs_with_media"],
        species=species_from_question(question),
        extracted_parameters=_bucket_recent_media_by_mode_parameters(question) if recent_media_sql else None,
    )
    add(
        _bucket_assay_media_candidates_sql(question),
        "assay_media_candidates",
        "bucket_assay_media_candidates_sql",
        "descriptive media proof requests should first retrieve candidate assay media links with assay metrics",
        answer_shapes=["assay_media_proof", "assay_runs_with_media"],
        species=species_from_question(question),
    )
    add(
        _bucket_cross_assay_repellent_rank_compounds_sql(question),
        "cross_assay_repellent_ranking",
        "bucket_cross_assay_repellent_rank_compounds_sql",
        "broad repellent compound rankings should check cross-assay ranking evidence instead of returning DART-only rows",
        answer_shapes=["ranked_cross_assay_repellent_compounds"],
        partial_answer_shapes=["ranked_repellents_with_milestone_mentions"],
    )
    add(
        _bucket_fly_repellency_rankings_sql(question),
        "fly_repellency_rankings",
        "bucket_fly_repellency_rankings_sql",
        "fly repellent rankings live in the structured fly aggregate top-performing chemicals CSV",
        answer_shapes=["ranked_fly_repellent_compounds", "ranked_repellent_compounds"],
        partial_answer_shapes=["ranked_repellents_with_milestone_mentions"],
        species="flies",
        metric_source="flies/summary/agg_summary/top_performing_chemicals.csv",
    )
    add(
        _bucket_top_repellents_by_species_sql(question),
        "top_repellents_by_species",
        "bucket_top_repellents_by_species_sql",
        "species-specific top repellent questions live in scored DART assay rows",
        answer_shapes=["ranked_species_repellent_compounds", "ranked_repellent_compounds"],
        partial_answer_shapes=["ranked_repellents_with_milestone_mentions"],
        species=species_from_question(question),
    )
    if _answer_shape_for_question(question) == "ranked_phytotoxicity_compounds_with_assay_species_constraint":
        rank_direction = "least" if _has_any(q, ["least", "lowest", "safest", "safe"]) else "most"
        add(
            phytotox_rank_compounds_by_assay_species_sql(question, rank_direction=rank_direction),
            "phytotox_compound_ranking_with_assay_species_constraint",
            "bucket_phytotox_rank_compounds_by_assay_species_sql",
            "ranked phytotoxicity questions with fly or mosquito assay constraints must join phytotoxicity rows to matching assay evidence",
            answer_shapes=["ranked_phytotoxicity_compounds_with_assay_species_constraint"],
            rank_direction=rank_direction,
            limit=_rank_limit_for_question(question, default=10),
            extracted_parameters={
                "assay_species": _assay_species_constraints_from_question(question),
            },
        )
    if _answer_shape_for_question(question) == "ranked_phytotoxicity_compounds":
        rank_direction = "least" if _has_any(q, ["least", "lowest", "safest", "safe"]) else "most"
        add(
            phytotox_rank_compounds_sql(rank_direction=rank_direction, question=question),
            "phytotox_compound_ranking",
            "bucket_phytotox_rank_compounds_sql",
            "ranked phytotoxicity compound questions should aggregate treatment rows before broad tested-compound lists",
            answer_shapes=["ranked_phytotoxicity_compounds"],
            rank_direction=rank_direction,
            limit=_rank_limit_for_question(question, default=5),
        )
    add(
        _bucket_phytotox_experiment_summary_sql(question),
        "phytotox_experiment_summary",
        "bucket_phytotox_experiment_summary_sql",
        "phytotoxicity treatment safety questions should inspect parsed result rows before generic phytotoxicity search",
        answer_shapes=["phytotox_result_rows"],
        partial_answer_shapes=["ranked_phytotoxicity_compounds"],
    )
    add(
        _phytotoxicity_sql(question),
        "phytotoxicity_metric_or_listing",
        "bucket_phytotoxicity_sql",
        "phytotoxicity metrics live in parsed workbook/CSV tables",
        answer_shapes=["phytotoxicity_metric_rows"],
        partial_answer_shapes=["ranked_phytotoxicity_compounds"],
    )
    compounds_tested_sql = (
        _bucket_compounds_tested_by_date_window_sql(question)
        if _bucket_compounds_tested_by_date_window_applies(question)
        else None
    )
    add(
        compounds_tested_sql,
        "compounds_tested_by_date_window",
        "bucket_compounds_tested_by_date_window_sql",
        "compound-tested date-window questions live in the DART assay ledger treatment and assay_date fields",
        answer_shapes=["tested_compound_date_window"],
    )
    compounds_tested_all_sql = (
        _bucket_compounds_tested_all_structured_sql()
        if _bucket_compounds_tested_all_structured_applies(question)
        else None
    )
    add(
        compounds_tested_all_sql,
        "compounds_tested_all_structured",
        "bucket_compounds_tested_all_structured_sql",
        "broad tested-compound questions should read structured assay ledger rows instead of source text",
        answer_shapes=["tested_compound_list"],
    )
    cross_assay_sql = (
        _bucket_cross_assay_run_inventory_sql(question)
        if _bucket_cross_assay_run_inventory_applies(question)
        else None
    )
    add(
        cross_assay_sql,
        "cross_assay_run_inventory",
        "bucket_cross_assay_run_inventory_sql",
        "broad assay run questions should fan out across DART, contact/no-contact, fly, oviposition, and phytotoxicity structured evidence",
        answer_shapes=["assay_inventory_count", "assay_run_list"],
        partial_answer_shapes=["assay_runs_with_meeting_commentary", "assay_runs_with_media"],
        extracted_parameters=_assay_ledger_date_filter_details(question, "event_date_iso")["parameters"] if cross_assay_sql else None,
        species_scope=_assay_species_constraints_from_question(question) if cross_assay_sql else None,
    )
    run_date_sql = _bucket_experiments_by_run_date_sql(question) if _bucket_experiments_by_run_date_applies(question) else None
    add(
        run_date_sql,
        "experiments_by_run_date",
        "bucket_experiments_by_run_date_sql",
        "experiment run-date questions live in the DART assay ledger assay_date field",
        answer_shapes=["dart_assay_run_date_list"],
        partial_answer_shapes=["assay_runs_with_meeting_commentary", "assay_runs_with_media"],
        extracted_parameters=_assay_ledger_date_filter_details(question, "assay_date_iso")["parameters"] if run_date_sql else None,
    )
    dart_sql = _dart_sql(question)
    dart_answer_shapes = (
        ["ranked_dart_compounds", "ranked_repellent_compounds", "dart_assay_metric_rows"]
        if _is_ranking_question(question)
        else ["dart_assay_metric_rows", "ranked_repellent_compounds"]
    )
    if _dart_assay_ledger_listing_applies(question):
        dart_answer_shapes = ["assay_run_list", "dart_assay_metric_rows"]
    add(
        dart_sql,
        "assay_metric_or_ranking",
        "bucket_dart_assay_results_sql",
        "DART assay rankings and counts live in the typed dart_assay_results table",
        answer_shapes=dart_answer_shapes,
        partial_answer_shapes=["ranked_repellents_with_milestone_mentions"],
    )
    add(
        _bucket_insect_image_taxonomy_inventory_sql(question),
        "insect_image_taxonomy_inventory",
        "bucket_insect_image_taxonomy_inventory_sql",
        "insect image existence questions should inspect structured bucket object metadata before inventory or prose search",
        answer_shapes=["insect_image_taxonomy_inventory"],
    )
    organism_sql = _bucket_experiments_by_organism_sql(question)
    add(
        organism_sql if organism_sql and _has_any(q, ["experiment", "experiments", "assay", "assays"]) else None,
        "experiments_by_organism",
        "bucket_experiments_by_organism_sql",
        "organism-specific experiment existence questions should inspect structured bucket rows and objects",
        answer_shapes=["organism_experiment_list"],
        species=species_from_question(question),
    )
    add(
        _bucket_assay_quality_report_sql(question),
        "assay_quality_report",
        "bucket_assay_quality_report_sql",
        "processed-run quality questions should inspect accuracy report rows before text search",
        answer_shapes=["assay_quality_report"],
    )
    add(
        _bucket_model_sql(question),
        "bucket_model_metadata",
        "bucket_model_metadata_sql",
        "bucket model metadata questions live in the parsed model_metadata table",
        answer_shapes=["bucket_model_metadata"],
    )
    experiment_sql = _bucket_experiment_listing_sql(question) if _bucket_experiment_listing_applies(question) else None
    add(
        experiment_sql,
        "experiment_listing",
        "bucket_experiment_listing_sql",
        "bucket experiment listings are derived from parsed object prefixes and object timestamps",
        answer_shapes=["bucket_experiment_listing"],
    )
    if _dart_best_concentration_helper_applies(question):
        candidates.append(
            _route_candidate(
                intent="dart_best_concentration",
                source_lane="bucket",
                retrieval_shape="structured",
                adapter="bucket_dart_best_concentration_helper",
                adapter_execution="typed_helper",
                reason="treatment-specific DART concentration questions use the typed DART concentration helper",
                answer_shapes=["dart_best_concentration"],
            )
        )
    return candidates


def _structured_candidate_routes_for_source(question, source):
    source = auto_source_for_question(question) if source == "auto" else source
    q = question.lower()
    if source == "bucket":
        return _bucket_structured_candidate_routes(question)
    if source == "chemistry_analysis":
        script_sql = _chemistry_analysis_script_method_evidence_sql(question)
        if script_sql:
            return [
                _route_candidate(
                    intent="script_method_evidence",
                    source_lane="chemistry_analysis",
                    retrieval_shape="structured",
                    adapter="chemistry_analysis_script_method_evidence_sql",
                    adapter_execution="sql",
                    sql=script_sql,
                    reason="chemistry method and pipeline questions should expose script files and line-level code evidence",
                    answer_shapes=["script_method_evidence"],
                )
            ]
        return []
    if source == "teams_recaps":
        candidates = []
        topic_rollup_sql = _teams_topic_speaker_rollup_sql(question)
        if topic_rollup_sql:
            candidates.append(
                _route_candidate(
                    intent="meeting_topic_speaker_rollup",
                    source_lane="teams_recaps",
                    retrieval_shape="structured",
                    adapter="teams_recaps_topic_speaker_rollup_sql",
                    adapter_execution="sql",
                    sql=topic_rollup_sql,
                    reason="topic and speaker questions should group Teams recap utterances before prose search",
                    answer_shapes=["meeting_topic_speaker_rollup"],
                    partial_answer_shapes=["assay_runs_with_meeting_commentary"],
                )
            )
        utterance_sql = _teams_utterance_lookup_sql(question)
        if utterance_sql:
            candidates.append(
                _route_candidate(
                    intent="meeting_utterance_lookup",
                    source_lane="teams_recaps",
                    retrieval_shape="structured",
                    adapter="teams_recaps_utterance_lookup_sql",
                    adapter_execution="sql",
                    sql=utterance_sql,
                    reason="speaker and utterance questions live in the Teams recap utterances table",
                    answer_shapes=["meeting_utterance_lookup"],
                    partial_answer_shapes=["assay_runs_with_meeting_commentary"],
                )
            )
        digest_sql = _teams_meeting_digest_sql(question)
        if digest_sql:
            candidates.append(
                _route_candidate(
                    intent="meeting_digest_by_date",
                    source_lane="teams_recaps",
                    retrieval_shape="structured",
                    adapter="teams_recaps_meeting_digest_by_date_sql",
                    adapter_execution="sql",
                    sql=digest_sql,
                    reason="dated recurring Teams meeting digest questions live in meetings and utterances tables",
                    answer_shapes=["meeting_digest_by_date"],
                    partial_answer_shapes=["assay_runs_with_meeting_commentary"],
                )
            )
        return candidates
    if source == "people_directory":
        sql = _people_sql(question)
        if not sql:
            return []
        if people_query_for_question(question):
            adapter = "people_directory_person_lookup_sql"
            intent = "person_lookup"
            answer_shape = "person_lookup"
        elif _has_any(q, ["advisor", "advisors", "advises", "advise"]):
            adapter = "people_directory_advisor_roster_sql"
            intent = "advisor_roster"
            answer_shape = "advisor_roster"
        elif _has_any(q, ["partner", "partnership", "usda", "jana lee"]):
            adapter = "people_directory_partnership_roster_sql"
            intent = "partnership_lookup"
            answer_shape = "partnership_roster"
        else:
            adapter = "people_directory_employee_roster_sql"
            intent = "employee_roster"
            answer_shape = "employee_roster"
        return [
            _route_candidate(
                intent=intent,
                source_lane="people_directory",
                retrieval_shape="structured",
                adapter=adapter,
                adapter_execution="sql",
                sql=sql,
                reason="people facts live in the typed people_directory units table",
                answer_shapes=[answer_shape],
            )
        ]
    if source == "company_profile":
        sql = _company_profile_sql(question)
        if not sql:
            return []
        return [
            _route_candidate(
                intent="company_profile_fact",
                source_lane="company_profile",
                retrieval_shape="structured",
                adapter="company_profile_unit_lookup_sql",
                adapter_execution="sql",
                sql=sql,
                reason="company profile facts live in named company_profile units",
                answer_shapes=["company_profile_fact"],
            )
        ]
    if source == "compound_inventory":
        candidates = []
        if _compound_inventory_all_names_applies(question):
            candidates.append(
                _route_candidate(
                    intent="compound_inventory_all_names",
                    source_lane="compound_inventory",
                    retrieval_shape="structured",
                    adapter="compound_inventory_all_names_sql",
                    adapter_execution="sql",
                    sql=_compound_inventory_all_names_sql(),
                    reason="complete compound-name inventory requests live in the Master workbook Name column",
                    answer_shapes=["compound_inventory_all_names"],
                    evidence_domain="Master sheet Name column",
                )
            )
        sql = _compound_inventory_sql(question)
        if sql:
            candidates.append(
                _route_candidate(
                    intent="compound_inventory_list_or_count",
                    source_lane="compound_inventory",
                    retrieval_shape="structured",
                    adapter="compound_inventory_master_count_sql",
                    adapter_execution="sql",
                    sql=sql,
                    reason="compound inventory lists/counts live in the Master workbook table",
                    answer_shapes=["compound_inventory_count_or_sample"],
                )
            )
        semantic_match = semantic_adapter_match(question, source)
        if semantic_match and semantic_match["adapter"] == "compound_inventory_summary_sql":
            candidates.append(
                _route_candidate(
                    intent="compound_inventory_summary",
                    source_lane="compound_inventory",
                    retrieval_shape="structured",
                    adapter="compound_inventory_summary_sql",
                    adapter_execution="sql",
                    sql=_compound_inventory_summary_sql(),
                    reason="semantic adapter matching mapped broad inventory wording to the structured inventory summary",
                    answer_shapes=["compound_inventory_summary"],
                    semantic_adapter_match=semantic_match,
                )
            )
        if _compound_inventory_master_lookup_applies(question):
            candidates.append(
                _route_candidate(
                    intent="compound_inventory_fact",
                    source_lane="compound_inventory",
                    retrieval_shape="structured",
                    adapter="compound_inventory_master_row_lookup",
                    adapter_execution="typed_helper",
                    reason="compound stock, vendor, location, CAS, and SDS facts live in full Master workbook rows",
                    answer_shapes=["compound_inventory_fact"],
                )
            )
        return candidates
    return []


def _mixed_answer_shape_route(question, answer_shape):
    if answer_shape == "ranked_repellents_with_milestone_mentions":
        route_plan = [
            {
                "step": 1,
                "source_lane": "bucket",
                "retrieval_stage": "structured_table_sql",
                "adapter": "bucket_cross_assay_repellent_rank_compounds_sql",
                "output": "ranked_cross_assay_repellent_compounds",
            },
            {
                "step": 2,
                "source_lane": "milestones_doc",
                "retrieval_stage": "fts_sql",
                "adapter": "milestones_doc_source_text_retrieval",
                "input": "ranked_cross_assay_repellent_compounds",
                "output": "milestone_mentions",
            },
        ]
        plan_candidate = _route_candidate(
            intent="ranked_repellents_with_milestone_mentions",
            source_lane="bucket",
            retrieval_shape="mixed",
            adapter="bucket_repellency_milestone_mention_plan",
            adapter_execution="route_plan",
            reason="the answer needs ranked repellency evidence first, then milestone mentions checked against those ranked compounds",
            answer_shapes=[answer_shape],
            route_plan=route_plan,
        )
        bucket_candidates = _bucket_structured_candidate_routes(question)
        rejected_routes = [
            _candidate_trace(candidate, answer_shape, rejected_reason="cannot_produce_answer_shape")
            for candidate in bucket_candidates
        ]
        candidate_routes = [_candidate_trace(plan_candidate, answer_shape, selected=True)] + rejected_routes
        return _route_decision(
            intent="ranked_repellents_with_milestone_mentions",
            source="bucket",
            retrieval_shape="mixed",
            adapter="bucket_repellency_milestone_mention_plan",
            adapter_execution="route_plan",
            reason="the answer needs ranked repellency evidence first, then milestone mentions checked against those ranked compounds",
            fallback_policy="structured_first_then_fts",
            answer_shape=answer_shape,
            selection_policy="answer_shape_first",
            candidate_routes=candidate_routes,
            rejected_routes=rejected_routes,
            route_plan=route_plan,
            required_sources=["bucket", "milestones_doc"],
            expected_grain_types=["dart_assay_row"],
        )

    if answer_shape == "ranked_repellents_with_media":
        route_plan = [
            {
                "step": 1,
                "source_lane": "bucket",
                "retrieval_stage": "structured_table_sql",
                "adapter": "bucket_fly_repellency_rankings_sql",
                "output": "ranked_fly_repellents",
                "question": "what are the top fly repellents",
            },
            {
                "step": 2,
                "source_lane": "bucket",
                "retrieval_stage": "structured_table_sql",
                "adapter": "bucket_fly_result_video_bridge_sql",
                "input": "ranked_fly_repellents",
                "output": "video_evidence",
                "question": "show video evidence for the top fly repellents",
            },
        ]
        plan_candidate = _route_candidate(
            intent="ranked_repellents_with_media",
            source_lane="bucket",
            retrieval_shape="mixed",
            adapter="bucket_repellency_media_bridge_plan",
            adapter_execution="route_plan",
            reason="the answer needs ranked fly repellency rows first, then media evidence for those ranked treatments",
            answer_shapes=[answer_shape],
            route_plan=route_plan,
        )
        bucket_candidates = _bucket_structured_candidate_routes(question)
        rejected_routes = []
        for candidate in bucket_candidates:
            if answer_shape in candidate.get("partial_answer_shapes", []):
                rejected_reason = "partial_answer_only"
            else:
                rejected_reason = "cannot_produce_answer_shape"
            rejected_routes.append(_candidate_trace(candidate, answer_shape, rejected_reason=rejected_reason))
        candidate_routes = [_candidate_trace(plan_candidate, answer_shape, selected=True)] + rejected_routes
        return _route_decision(
            intent="ranked_repellents_with_media",
            source="bucket",
            retrieval_shape="mixed",
            adapter="bucket_repellency_media_bridge_plan",
            adapter_execution="route_plan",
            reason="the answer needs ranked fly repellency rows first, then media evidence for those ranked treatments",
            fallback_policy="fail_on_missing_structured_step",
            answer_shape=answer_shape,
            selection_policy="answer_shape_first",
            candidate_routes=candidate_routes,
            rejected_routes=rejected_routes,
            route_plan=route_plan,
            required_sources=["bucket"],
            expected_grain_types=["fly_result_video_bridge"],
        )

    if answer_shape == "assay_runs_with_meeting_commentary":
        assay_question, meeting_question = _assay_meeting_bridge_step_questions(question)
        route_plan = [
            {
                "step": 1,
                "source_lane": "bucket",
                "retrieval_stage": "structured_table_sql",
                "adapter": "bucket_cross_assay_run_inventory_sql",
                "output": "assay_runs",
                "question": assay_question,
            },
            {
                "step": 2,
                "source_lane": "teams_recaps",
                "retrieval_stage": "structured_table_sql",
                "adapter": "teams_recaps_topic_speaker_rollup_sql",
                "input": "assay_runs",
                "output": "meeting_commentary",
                "question": meeting_question,
            },
        ]
        plan_candidate = _route_candidate(
            intent="assay_runs_with_meeting_commentary",
            source_lane="bucket",
            retrieval_shape="mixed",
            adapter="bucket_assays_teams_commentary_plan",
            adapter_execution="route_plan",
            reason="the answer needs structured assay rows first, then Teams recap commentary about those assay topics",
            answer_shapes=[answer_shape],
            route_plan=route_plan,
        )
        bucket_candidates = _bucket_structured_candidate_routes(question)
        teams_candidates = _structured_candidate_routes_for_source(question, "teams_recaps")
        rejected_routes = []
        for candidate in bucket_candidates + teams_candidates:
            if answer_shape in candidate.get("partial_answer_shapes", []):
                rejected_reason = "partial_answer_only"
            else:
                rejected_reason = "cannot_produce_answer_shape"
            rejected_routes.append(_candidate_trace(candidate, answer_shape, rejected_reason=rejected_reason))
        candidate_routes = [_candidate_trace(plan_candidate, answer_shape, selected=True)] + rejected_routes
        return _route_decision(
            intent="assay_runs_with_meeting_commentary",
            source="bucket",
            retrieval_shape="mixed",
            adapter="bucket_assays_teams_commentary_plan",
            adapter_execution="route_plan",
            reason="the answer needs structured assay rows first, then Teams recap commentary about those assay topics",
            fallback_policy="structured_first_then_fts",
            answer_shape=answer_shape,
            selection_policy="answer_shape_first",
            candidate_routes=candidate_routes,
            rejected_routes=rejected_routes,
            route_plan=route_plan,
            required_sources=["bucket", "teams_recaps"],
            expected_grain_types=["cross_assay_run_family", "meeting_utterance"],
        )

    return None


def _dedupe_route_steps(steps):
    seen = set()
    deduped = []
    for step in steps:
        key = (step.get("source_lane"), step.get("adapter"), step.get("question"))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(dict(step, step=len(deduped) + 1))
    return deduped


def _compositional_answer_contract_route(question):
    q = str(question).lower()
    components = []

    def add(answer_shape, source_lane, adapter, output, step_question, retrieval_stage="structured_table_sql"):
        components.append(
            {
                "answer_shape": answer_shape,
                "source_lane": source_lane,
                "retrieval_stage": retrieval_stage,
                "adapter": adapter,
                "output": output,
                "question": step_question,
            }
        )

    has_fly_ranking = (
        species_from_question(question) == "flies"
        and _has_any(q, ["repellent", "repellents", "repellency"])
        and _is_ranking_question(question)
    )
    if has_fly_ranking:
        add(
            "ranked_fly_repellent_compounds",
            "bucket",
            "bucket_fly_repellency_rankings_sql",
            "ranked_fly_repellents",
            "what are the top fly repellents",
        )
    if (
        _has_any(q, PHYTOTOX_TERMS)
        and (_has_any(q, ["compare", "comparison", "against"]) or _is_ranking_question(question))
    ):
        add(
            "ranked_phytotoxicity_compounds",
            "bucket",
            "bucket_phytotox_rank_compounds_sql",
            "ranked_phytotoxicity_compounds",
            "what are the most phytotoxic compounds",
        )
    if _has_any(q, ["qc failure", "qc failures", "quality control", "show qc failures", "flagged issue", "flagged issues"]):
        add(
            "assay_quality_report",
            "bucket",
            "bucket_assay_quality_report_sql",
            "assay_quality_findings",
            "show QC failures and accuracy report warnings",
        )

    route_plan = _dedupe_route_steps(components)
    if len(route_plan) < 2:
        return None
    answer_shapes = []
    for step in route_plan:
        answer_shape = step.get("answer_shape")
        if answer_shape and answer_shape not in answer_shapes:
            answer_shapes.append(answer_shape)
    return _route_decision(
        intent="compositional_answer_contract",
        source="bucket",
        retrieval_shape="mixed",
        adapter="answer_contract_composition_plan",
        adapter_execution="route_plan",
        reason="the question contains multiple recurring answer contracts, so each contract keeps its own structured route instead of letting one keyword path replace the others",
        fallback_policy="fail_on_missing_structured_step",
        answer_shape=answer_shapes[0],
        answer_shapes=answer_shapes,
        selection_policy="answer_shape_composition",
        route_plan=route_plan,
        required_sources=sorted({step["source_lane"] for step in route_plan}),
        expected_grain_types=[
            grain_type
            for step in route_plan
            for grain_type in EXPECTED_GRAIN_TYPES_BY_ADAPTER.get(step.get("adapter"), [])
        ],
    )


def structured_adapter_for_question(question, source):
    source = auto_source_for_question(question) if source == "auto" else source
    candidates = _structured_candidate_routes_for_source(question, source)
    if candidates:
        selected, answer_shape, candidate_routes, rejected_routes = _select_candidate_for_answer_shape(question, candidates)
        if not selected and answer_shape:
            return _missing_answer_shape_adapter(source, answer_shape, candidate_routes, rejected_routes)
        return _attach_answer_shape_trace(
            _adapter_from_candidate(selected),
            answer_shape,
            candidate_routes,
            rejected_routes,
        )
    q = question.lower()
    if source == "teams_recaps":
        topic_rollup_sql = _teams_topic_speaker_rollup_sql(question)
        if topic_rollup_sql:
            return {
                "intent": "meeting_topic_speaker_rollup",
                "adapter": "teams_recaps_topic_speaker_rollup_sql",
                "adapter_execution": "sql",
                "sql": topic_rollup_sql,
                "reason": "topic and speaker questions should group Teams recap utterances before prose search",
            }
        utterance_sql = _teams_utterance_lookup_sql(question)
        if utterance_sql:
            return {
                "intent": "meeting_utterance_lookup",
                "adapter": "teams_recaps_utterance_lookup_sql",
                "adapter_execution": "sql",
                "sql": utterance_sql,
                "reason": "speaker and utterance questions live in the Teams recap utterances table",
            }
        sql = _teams_meeting_digest_sql(question)
        if sql:
            return {
                "intent": "meeting_digest_by_date",
                "adapter": "teams_recaps_meeting_digest_by_date_sql",
                "adapter_execution": "sql",
                "sql": sql,
                "reason": "dated recurring Teams meeting digest questions live in meetings and utterances tables",
            }
        return None
    if source == "people_directory":
        sql = _people_sql(question)
        if not sql:
            return None
        if people_query_for_question(question):
            adapter = "people_directory_person_lookup_sql"
            intent = "person_lookup"
        elif _has_any(q, ["advisor", "advisors", "advises", "advise"]):
            adapter = "people_directory_advisor_roster_sql"
            intent = "advisor_roster"
        elif _has_any(q, ["partner", "partnership", "usda", "jana lee"]):
            adapter = "people_directory_partnership_roster_sql"
            intent = "partnership_lookup"
        else:
            adapter = "people_directory_employee_roster_sql"
            intent = "employee_roster"
        return {
            "intent": intent,
            "adapter": adapter,
            "adapter_execution": "sql",
            "sql": sql,
            "reason": "people facts live in the typed people_directory units table",
        }
    if source == "company_profile":
        sql = _company_profile_sql(question)
        if sql:
            return {
                "intent": "company_profile_fact",
                "adapter": "company_profile_unit_lookup_sql",
                "adapter_execution": "sql",
                "sql": sql,
                "reason": "company profile facts live in named company_profile units",
            }
        return None
    if source == "compound_inventory":
        if _compound_inventory_all_names_applies(question):
            return {
                "intent": "compound_inventory_all_names",
                "adapter": "compound_inventory_all_names_sql",
                "adapter_execution": "sql",
                "sql": _compound_inventory_all_names_sql(),
                "reason": "complete compound-name inventory requests live in the Master workbook Name column",
                "evidence_domain": "Master sheet Name column",
            }
        sql = _compound_inventory_sql(question)
        if sql:
            return {
                "intent": "compound_inventory_list_or_count",
                "adapter": "compound_inventory_master_count_sql",
                "adapter_execution": "sql",
                "sql": sql,
                "reason": "compound inventory lists/counts live in the Master workbook table",
            }
        semantic_match = semantic_adapter_match(question, source)
        if semantic_match and semantic_match["adapter"] == "compound_inventory_summary_sql":
            return {
                "intent": "compound_inventory_summary",
                "adapter": "compound_inventory_summary_sql",
                "adapter_execution": "sql",
                "sql": _compound_inventory_summary_sql(),
                "reason": "semantic adapter matching mapped broad inventory wording to the structured inventory summary",
                "semantic_adapter_match": semantic_match,
            }
        if _compound_inventory_master_lookup_applies(question):
            return {
                "intent": "compound_inventory_fact",
                "adapter": "compound_inventory_master_row_lookup",
                "adapter_execution": "typed_helper",
                "reason": "compound stock, vendor, location, CAS, and SDS facts live in full Master workbook rows",
            }
        return None
    if source == "bucket":
        docking_pipeline_sql = _bucket_docking_pipeline_sql(question)
        if docking_pipeline_sql:
            return {
                "intent": "docking_pipeline",
                "adapter": "bucket_docking_pipeline_sql",
                "adapter_execution": "sql",
                "sql": docking_pipeline_sql,
                "reason": "the docking pipeline source is indexed as bucket text lines",
            }
        docking_results_sql = _bucket_docking_results_sql(question)
        if docking_results_sql:
            return {
                "intent": "docking_results",
                "adapter": "bucket_docking_results_sql",
                "adapter_execution": "sql",
                "sql": docking_results_sql,
                "reason": "docking result lookups should inspect structured bucket result artifacts before prose search",
            }
        fly_result_video_bridge_sql = _bucket_fly_result_video_bridge_sql(question)
        if fly_result_video_bridge_sql:
            return {
                "intent": "fly_result_video_bridge",
                "adapter": "bucket_fly_result_video_bridge_sql",
                "adapter_execution": "sql",
                "sql": fly_result_video_bridge_sql,
                "reason": "fly result plus media questions should join ranked fly repellency rows to matching video objects",
                "species": "flies",
            }
        fly_trial_metadata_sql = _bucket_fly_trial_metadata_join_sql(question)
        if fly_trial_metadata_sql:
            return {
                "intent": "fly_trial_metadata_join",
                "adapter": "bucket_fly_trial_metadata_join_sql",
                "adapter_execution": "sql",
                "sql": fly_trial_metadata_sql,
                "reason": "fly trial metadata questions should join trial workbook rows to abbreviation rows",
                "species": "flies",
            }
        recent_contact_assays_sql = _bucket_recent_contact_no_contact_assays_sql(question)
        if recent_contact_assays_sql:
            recent_contact_species_scope = _assay_species_constraints_from_question(question)
            return {
                "intent": "recent_contact_no_contact_assays",
                "adapter": "bucket_recent_contact_no_contact_assays_sql",
                "adapter_execution": "sql",
                "sql": recent_contact_assays_sql,
                "reason": "recent contact/no-contact assay questions should read raw bucket object rows before generic assay anchors or prose search",
                "species": recent_contact_species_scope[0] if len(recent_contact_species_scope) == 1 else None,
                "species_scope": recent_contact_species_scope,
                "extracted_parameters": _bucket_recent_contact_no_contact_assays_parameters(question),
            }
        recent_media_sql = _bucket_recent_media_by_mode_sql(question)
        if recent_media_sql:
            recent_media_parameters = _bucket_recent_media_by_mode_parameters(question)
            return {
                "intent": "recent_media_by_mode",
                "adapter": "bucket_recent_media_by_mode_sql",
                "adapter_execution": "sql",
                "sql": recent_media_sql,
                "reason": "recent media lookup questions should inspect bucket object metadata before prose search",
                "species": species_from_question(question),
                "extracted_parameters": recent_media_parameters,
            }
        media_candidate_sql = _bucket_assay_media_candidates_sql(question)
        if media_candidate_sql:
            return {
                "intent": "assay_media_candidates",
                "adapter": "bucket_assay_media_candidates_sql",
                "adapter_execution": "sql",
                "sql": media_candidate_sql,
                "reason": "descriptive media proof requests should first retrieve candidate assay media links with assay metrics",
                "species": species_from_question(question),
            }
        fly_repellency_sql = _bucket_fly_repellency_rankings_sql(question)
        if fly_repellency_sql:
            return {
                "intent": "fly_repellency_rankings",
                "adapter": "bucket_fly_repellency_rankings_sql",
                "adapter_execution": "sql",
                "sql": fly_repellency_sql,
                "reason": "fly repellent rankings live in the structured fly aggregate top-performing chemicals CSV",
                "species": "flies",
                "metric_source": "flies/summary/agg_summary/top_performing_chemicals.csv",
            }
        top_repellent_sql = _bucket_top_repellents_by_species_sql(question)
        if top_repellent_sql:
            return {
                "intent": "top_repellents_by_species",
                "adapter": "bucket_top_repellents_by_species_sql",
                "adapter_execution": "sql",
                "sql": top_repellent_sql,
                "reason": "species-specific top repellent questions live in scored DART assay rows",
                "species": species_from_question(question),
            }
        individual_timepoint_sql = _bucket_individual_assay_timepoint_sql(question)
        if individual_timepoint_sql:
            return {
                "intent": "individual_assay_timepoint_ranking",
                "adapter": "bucket_individual_assay_timepoint_sql",
                "adapter_execution": "sql",
                "sql": individual_timepoint_sql,
                "reason": "within-assay timepoint questions should read frame, bin, or longitudinal timepoint rows across supported assay families instead of run-level timestamps",
                "species": species_from_question(question),
            }
        phytotox_summary_sql = _bucket_phytotox_experiment_summary_sql(question)
        if phytotox_summary_sql:
            return {
                "intent": "phytotox_experiment_summary",
                "adapter": "bucket_phytotox_experiment_summary_sql",
                "adapter_execution": "sql",
                "sql": phytotox_summary_sql,
                "reason": "phytotoxicity treatment safety questions should inspect parsed result rows before generic phytotoxicity search",
            }
        phytotoxicity_sql = _phytotoxicity_sql(question)
        if phytotoxicity_sql:
            return {
                "intent": "phytotoxicity_metric_or_listing",
                "adapter": "bucket_phytotoxicity_sql",
                "adapter_execution": "sql",
                "sql": phytotoxicity_sql,
                "reason": "phytotoxicity metrics live in parsed workbook/CSV tables",
            }
        compounds_tested_sql = (
            _bucket_compounds_tested_by_date_window_sql(question)
            if _bucket_compounds_tested_by_date_window_applies(question)
            else None
        )
        if compounds_tested_sql:
            return {
                "intent": "compounds_tested_by_date_window",
                "adapter": "bucket_compounds_tested_by_date_window_sql",
                "adapter_execution": "sql",
                "sql": compounds_tested_sql,
                "reason": "compound-tested date-window questions live in the DART assay ledger treatment and assay_date fields",
            }
        compounds_tested_all_sql = (
            _bucket_compounds_tested_all_structured_sql()
            if _bucket_compounds_tested_all_structured_applies(question)
            else None
        )
        if compounds_tested_all_sql:
            return {
                "intent": "compounds_tested_all_structured",
                "adapter": "bucket_compounds_tested_all_structured_sql",
                "adapter_execution": "sql",
                "sql": compounds_tested_all_sql,
                "reason": "broad tested-compound questions should read structured assay ledger rows instead of source text",
            }
        cross_assay_sql = (
            _bucket_cross_assay_run_inventory_sql(question)
            if _bucket_cross_assay_run_inventory_applies(question)
            else None
        )
        if cross_assay_sql:
            cross_assay_parameters = _assay_ledger_date_filter_details(question, "event_date_iso")["parameters"]
            return {
                "intent": "cross_assay_run_inventory",
                "adapter": "bucket_cross_assay_run_inventory_sql",
                "adapter_execution": "sql",
                "sql": cross_assay_sql,
                "reason": "broad assay run questions should fan out across DART, contact/no-contact, fly, oviposition, and phytotoxicity structured evidence",
                "extracted_parameters": cross_assay_parameters,
            }
        run_date_sql = _bucket_experiments_by_run_date_sql(question) if _bucket_experiments_by_run_date_applies(question) else None
        if run_date_sql:
            run_date_parameters = _assay_ledger_date_filter_details(question, "assay_date_iso")["parameters"]
            return {
                "intent": "experiments_by_run_date",
                "adapter": "bucket_experiments_by_run_date_sql",
                "adapter_execution": "sql",
                "sql": run_date_sql,
                "reason": "experiment run-date questions live in the DART assay ledger assay_date field",
                "extracted_parameters": run_date_parameters,
            }
        dart_sql = _dart_sql(question)
        if dart_sql:
            dart_answer_shapes = ["dart_assay_metric_rows", "ranked_repellent_compounds"]
            if _is_ranking_question(question):
                dart_answer_shapes = ["ranked_dart_compounds", "ranked_repellent_compounds", "dart_assay_metric_rows"]
            if _dart_assay_ledger_listing_applies(question):
                dart_answer_shapes = ["assay_run_list", "dart_assay_metric_rows"]
            return {
                "intent": "assay_metric_or_ranking",
                "adapter": "bucket_dart_assay_results_sql",
                "adapter_execution": "sql",
                "sql": dart_sql,
                "reason": "DART assay rankings and counts live in the typed dart_assay_results table",
                "answer_shapes": dart_answer_shapes,
            }
        image_taxonomy_sql = _bucket_insect_image_taxonomy_inventory_sql(question)
        if image_taxonomy_sql:
            return {
                "intent": "insect_image_taxonomy_inventory",
                "adapter": "bucket_insect_image_taxonomy_inventory_sql",
                "adapter_execution": "sql",
                "sql": image_taxonomy_sql,
                "reason": "insect image existence questions should inspect structured bucket object metadata before inventory or prose search",
            }
        organism_sql = _bucket_experiments_by_organism_sql(question)
        if organism_sql and _has_any(q, ["experiment", "experiments", "assay", "assays"]):
            return {
                "intent": "experiments_by_organism",
                "adapter": "bucket_experiments_by_organism_sql",
                "adapter_execution": "sql",
                "sql": organism_sql,
                "reason": "organism-specific experiment existence questions should inspect structured bucket rows and objects",
                "species": species_from_question(question),
            }
        assay_quality_sql = _bucket_assay_quality_report_sql(question)
        if assay_quality_sql:
            return {
                "intent": "assay_quality_report",
                "adapter": "bucket_assay_quality_report_sql",
                "adapter_execution": "sql",
                "sql": assay_quality_sql,
                "reason": "processed-run quality questions should inspect accuracy report rows before text search",
            }
        model_sql = _bucket_model_sql(question)
        if model_sql:
            return {
                "intent": "bucket_model_metadata",
                "adapter": "bucket_model_metadata_sql",
                "adapter_execution": "sql",
                "sql": model_sql,
                "reason": "bucket model metadata questions live in the parsed model_metadata table",
            }
        experiment_sql = _bucket_experiment_listing_sql(question) if _bucket_experiment_listing_applies(question) else None
        if experiment_sql:
            return {
                "intent": "experiment_listing",
                "adapter": "bucket_experiment_listing_sql",
                "adapter_execution": "sql",
                "sql": experiment_sql,
                "reason": "bucket experiment listings are derived from parsed object prefixes and object timestamps",
            }
        if _dart_best_concentration_helper_applies(question):
            return {
                "intent": "dart_best_concentration",
                "adapter": "bucket_dart_best_concentration_helper",
                "adapter_execution": "typed_helper",
                "reason": "treatment-specific DART concentration questions use the typed DART concentration helper",
            }
        return None
    return None


def structured_anchor_for_question(question, source):
    source = auto_source_for_question(question) if source == "auto" else source
    if source == "teams_recaps":
        sql = _teams_meeting_anchor_sql(question)
        if sql:
            return {
                "intent": "meeting_anchor_by_date",
                "adapter": "teams_recaps_meeting_anchor_sql",
                "adapter_execution": "structured_anchor_then_text_retrieval",
                "sql": sql,
                "reason": "dated meeting interpretation should anchor to the exact meeting row before transcript text retrieval",
            }
        return None
    if source == "bucket":
        sql = _bucket_structured_anchor_probe_sql(question)
        if sql:
            return {
                "intent": "bucket_structured_anchor",
                "adapter": "bucket_structured_anchor_probe_sql",
                "adapter_execution": "structured_anchor_then_text_retrieval",
                "sql": sql,
                "reason": "bucket interpretation should retrieve structured assay or artifact anchors before source text retrieval",
            }
        return None
    return None


def _is_exact_fact_question(question):
    q = question.lower()
    return _has_any(q, [
        "advisor",
        "advisors",
        "best",
        "cas",
        "count",
        "do we have",
        "highest",
        "how many",
        "inventory",
        "least",
        "list",
        "location",
        "most",
        "preference index",
        "quantity",
        "rank",
        "ranking",
        "repellent",
        "repellency",
        "sds",
        "stock",
        "stored",
        "top",
        "vendor",
        "where is",
        "which",
        "who",
    ])


def _is_media_proof_question(question):
    q = question.lower()
    return _has_any(q, ["video", "media", "movie", "recording", "overlay"]) and _has_any(
        q,
        ["assay", "contact", "dart", "fly", "flies", "mosquito", "mosquitoes", "swd"],
    )


def _is_inventory_to_assay_results(question):
    q = question.lower()
    return (
        _has_any(q, ["assay result", "assay results", "results from"])
        and _has_any(q, ["last 10", "latest 10", "recent 10", "last ten", "latest ten"])
        and _has_any(q, ["ordered", "order", "inventory"])
    )


def _is_inventory_sample_with_assay(question):
    q = question.lower()
    return (
        _has_any(q, ["inventory", "chemical library", "compound inventory"])
        and _has_any(q, ["compound", "compounds", "chemical", "chemicals"])
        and _has_any(q, ["assay", "assays", "experiment", "experiments"])
        and _has_any(q, ["used", "using", "tested", "ran"])
        and _has_any(q, ["one of them", "1 of them", "one assay", "1 assay"])
    )


def _is_phytotox_inventory_ranking(question):
    q = question.lower()
    return (
        _has_any(q, ["phytotoxic", "phytotoxicity", "phytotox", "phytoxic", "plant damage", "leaf damage", "chlorosis", "browning", "necrosis"])
        and _has_any(q, ["inventory", "compound inventory", "chemical inventory", "chemical library", "in stock", "our stock"])
        and _has_any(q, ["compound", "compounds", "chemical", "chemicals", "treatment", "treatments"])
        and _has_any(q, ["most", "top", "rank", "ranked", "ranking", "highest", "worst", "list"])
    )


def _rank_limit_for_question(question, default=5):
    q = str(question).lower()
    range_match = re.search(r"\b(?:from\s+)?\d{1,3}\s*[-–]\s*(\d{1,3})\b", q)
    if range_match:
        return max(1, min(int(range_match.group(1)), 100))
    top_match = re.search(r"\b(?:top|first|last|most recent|latest)\s+(\d{1,3})\b", q)
    if top_match:
        return max(1, min(int(top_match.group(1)), 100))
    list_match = re.search(r"\blist\s+(\d{1,3})\b", q)
    if list_match:
        return max(1, min(int(list_match.group(1)), 100))
    return default


def normalized_compound_key(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def _sqlite_compound_key(expr):
    key = f"lower(coalesce({expr}, ''))"
    for char in [" ", "\t", "\n", "\r", "-", "_", "(", ")", ",", ".", "/", ":"]:
        key = f"replace({key}, {sql_literal(char)}, '')"
    return key


def inventory_compound_maps(inventory_compounds):
    by_lower = {}
    by_compact = {}
    for compound in inventory_compounds:
        name = str(compound.get("compound_name") or "").strip()
        if not name:
            continue
        by_lower.setdefault(name.lower(), compound)
        compact = normalized_compound_key(name)
        if compact:
            by_compact.setdefault(compact, compound)
    return by_lower, by_compact


def inventory_compounds_from_rows(rows):
    rows = rows or []
    if len(rows) == 1 and isinstance(rows[0], dict) and rows[0].get("compounds_json"):
        try:
            parsed = json.loads(rows[0]["compounds_json"])
        except (TypeError, ValueError, json.JSONDecodeError):
            return []
        return parsed if isinstance(parsed, list) else []
    return [
        row
        for row in rows
        if isinstance(row, dict) and str(row.get("compound_name") or "").strip()
    ]


def phytotox_rank_compounds_sql(rank_direction="most", question=None):
    order = "ASC" if rank_direction == "least" else "DESC"
    date_details = _optional_assay_date_filter_details(question or "", "result_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    phyto_date_expr = "date(json_extract(c.row_json, '$.date'))"
    phyto_date_filter = date_filter.replace("result_date_iso", phyto_date_expr)
    date_required_filter = (
        f"AND {phyto_date_expr} IS NOT NULL "
        f"AND ({phyto_date_filter})"
        if date_window != "all_time"
        else ""
    )
    return f"""
        WITH treatment_rows AS (
          SELECT
            json_extract(c.row_json, '$.treatment_name') AS compound,
            c.name AS source_name,
            c.row_number AS source_row_number,
            date(json_extract(c.row_json, '$.date')) AS result_date_iso,
            CAST(json_extract(c.row_json, '$.damaged_fraction') AS REAL) AS damaged_fraction,
            CAST(json_extract(c.row_json, '$.chlorosis_fraction') AS REAL) AS chlorosis_fraction,
            CAST(json_extract(c.row_json, '$.browning_fraction') AS REAL) AS browning_fraction,
            CAST(json_extract(c.row_json, '$.necrosis_fraction') AS REAL) AS necrosis_fraction
          FROM objects o
          JOIN csv_rows c ON c.name = o.name
          WHERE o.top_folder = 'phytotoxicity'
            AND o.name LIKE 'phytotoxicity/results/%/predictions/analysis/features_all.csv'
            AND json_extract(c.row_json, '$.treatment_name') IS NOT NULL
            AND lower(coalesce(json_extract(c.row_json, '$.condition'), '')) = 'treatment'
            AND json_extract(c.row_json, '$.damaged_fraction') IS NOT NULL
            {date_required_filter}
        ),
        ranked AS (
          SELECT
            compound,
            count(*) AS result_rows,
            {sql_literal(date_window)} AS date_window,
            'phytotoxicity_result_row_date' AS date_basis,
            min(result_date_iso) AS first_result_date,
            max(result_date_iso) AS latest_result_date,
            round(avg(damaged_fraction), 4) AS avg_damaged_fraction,
            round(max(damaged_fraction), 4) AS max_damaged_fraction,
            CASE
              WHEN count(damaged_fraction) > 1 THEN sqrt(
                (sum(damaged_fraction * damaged_fraction) - (sum(damaged_fraction) * sum(damaged_fraction) / count(damaged_fraction)))
                / (count(damaged_fraction) - 1)
              )
              ELSE NULL
            END AS standard_deviation,
            CASE
              WHEN count(damaged_fraction) > 1 THEN sqrt(
                ((sum(damaged_fraction * damaged_fraction) - (sum(damaged_fraction) * sum(damaged_fraction) / count(damaged_fraction)))
                / (count(damaged_fraction) - 1))
                / count(damaged_fraction)
              )
              ELSE NULL
            END AS standard_error,
            CASE
              WHEN count(damaged_fraction) > 1 THEN 'sample_stddev_of_damaged_fraction_across_phytotoxicity_rows'
              ELSE 'standard_deviation_not_available_single_phytotoxicity_row'
            END AS standard_deviation_basis,
            round(avg(chlorosis_fraction), 4) AS avg_chlorosis_fraction,
            round(avg(browning_fraction), 4) AS avg_browning_fraction,
            round(avg(necrosis_fraction), 4) AS avg_necrosis_fraction,
            min(source_name) AS example_file,
            min(source_row_number) AS example_row
          FROM treatment_rows
          GROUP BY compound
        )
        SELECT
          row_number() OVER (
            ORDER BY avg_damaged_fraction {order}, max_damaged_fraction {order}, avg_chlorosis_fraction {order}, compound
          ) AS rank,
          compound,
          result_rows,
          date_window,
          date_basis,
          first_result_date,
          latest_result_date,
          avg_damaged_fraction,
          max_damaged_fraction,
          standard_deviation,
          standard_error,
          standard_deviation_basis,
          avg_chlorosis_fraction,
          avg_browning_fraction,
          avg_necrosis_fraction,
          example_file,
          example_row,
          json_object(
            'grain_id', 'phytotox_inventory_ranking:' || compound,
            'grain_type', 'phytotox_result_row',
            'locator', 'gs://monarch-videos-new/' || example_file || '#row=' || example_row,
            'source_id', 'monarch_videos_new',
            'date_window', date_window,
            'date_basis', date_basis,
            'standard_deviation_basis', standard_deviation_basis
          ) AS provenance_grain
        FROM ranked
        ORDER BY avg_damaged_fraction {order}, max_damaged_fraction {order}, avg_chlorosis_fraction {order}, compound
    """


def phytotox_rank_compounds_by_assay_species_sql(question, rank_direction="most"):
    species = _assay_species_constraints_from_question(question)
    if not species:
        return None
    order = "ASC" if rank_direction == "least" else "DESC"
    date_details = _optional_assay_date_filter_details(question, "result_date_iso")
    date_filter = date_details["filter_sql"]
    date_window = date_details["date_window"]
    phyto_date_expr = "date(json_extract(c.row_json, '$.date'))"
    phyto_date_filter = date_filter.replace("result_date_iso", phyto_date_expr)
    date_required_filter = (
        f"AND {phyto_date_expr} IS NOT NULL "
        f"AND ({phyto_date_filter})"
        if date_window != "all_time"
        else ""
    )
    species_rows = ", ".join(f"({sql_literal(item)})" for item in species)
    abbrev_key = _sqlite_compound_key("abbreviation")
    full_name_key = _sqlite_compound_key("full_chemical_name")
    phytotox_key = _sqlite_compound_key("json_extract(c.row_json, '$.treatment_name')")
    dart_key = _sqlite_compound_key("coalesce(nullif(trim(treatment_normalized), ''), nullif(trim(treatment), ''))")
    fly_key = _sqlite_compound_key("treatment")
    contact_label_key = _sqlite_compound_key("assay_label")
    return f"""
        WITH species_filter(species) AS (
          VALUES {species_rows}
        ),
        abbrev AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'A%' THEN trim(value) END) AS abbreviation,
            max(CASE WHEN cell LIKE 'B%' THEN trim(value) END) AS full_chemical_name,
            max(CASE WHEN cell LIKE 'C%' THEN trim(value) END) AS inchikey
          FROM xlsx_cells
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND lower(sheet) LIKE '%abbrev%'
            AND (cell LIKE 'A%' OR cell LIKE 'B%' OR cell LIKE 'C%')
          GROUP BY row_number
        ),
        alias_keys AS (
          SELECT
            abbreviation AS alias_label,
            full_chemical_name AS canonical_compound,
            {abbrev_key} AS alias_key,
            {full_name_key} AS canonical_key
          FROM abbrev
          WHERE coalesce(trim(abbreviation), '') <> ''
            AND coalesce(trim(full_chemical_name), '') <> ''
          UNION ALL
          SELECT
            full_chemical_name AS alias_label,
            full_chemical_name AS canonical_compound,
            {full_name_key} AS alias_key,
            {full_name_key} AS canonical_key
          FROM abbrev
          WHERE coalesce(trim(full_chemical_name), '') <> ''
        ),
        phytotox_rows AS (
          SELECT
            json_extract(c.row_json, '$.treatment_name') AS compound,
            {phytotox_key} AS compound_key,
            c.name AS source_name,
            c.row_number AS source_row_number,
            date(json_extract(c.row_json, '$.date')) AS result_date_iso,
            CAST(json_extract(c.row_json, '$.damaged_fraction') AS REAL) AS damaged_fraction,
            CAST(json_extract(c.row_json, '$.chlorosis_fraction') AS REAL) AS chlorosis_fraction,
            CAST(json_extract(c.row_json, '$.browning_fraction') AS REAL) AS browning_fraction,
            CAST(json_extract(c.row_json, '$.necrosis_fraction') AS REAL) AS necrosis_fraction
          FROM objects o
          JOIN csv_rows c ON c.name = o.name
          WHERE o.top_folder = 'phytotoxicity'
            AND o.name LIKE 'phytotoxicity/results/%/predictions/analysis/features_all.csv'
            AND json_extract(c.row_json, '$.treatment_name') IS NOT NULL
            AND lower(coalesce(json_extract(c.row_json, '$.condition'), '')) = 'treatment'
            AND json_extract(c.row_json, '$.damaged_fraction') IS NOT NULL
            {date_required_filter}
        ),
        dart_assay_evidence AS (
          SELECT
            coalesce(nullif(trim(treatment_normalized), ''), nullif(trim(treatment), '')) AS assay_label,
            {dart_key} AS assay_key,
            lower(species) AS assay_species,
            'dart_assay_results' AS source_family,
            'gs://monarch-videos-new/' || source_name || '#sheet=' || sheet || '&row=' || row_number AS assay_locator
          FROM dart_assay_results
          WHERE lower(species) IN (SELECT species FROM species_filter)
        ),
        fly_trials AS (
          SELECT
            row_number,
            max(CASE WHEN cell LIKE 'B%' THEN trim(value) END) AS filename,
            max(CASE WHEN cell LIKE 'N%' THEN trim(value) END) AS treatment
          FROM xlsx_cells
          WHERE name = 'flies/repellency_screen_metadata_sheet.xlsx'
            AND sheet IN ('trials', 'Trials')
            AND (cell LIKE 'B%' OR cell LIKE 'N%')
          GROUP BY row_number
        ),
        fly_assay_evidence AS (
          SELECT
            treatment AS assay_label,
            {fly_key} AS assay_key,
            'flies' AS assay_species,
            'fly_repellency_trials' AS source_family,
            'gs://monarch-videos-new/flies/repellency_screen_metadata_sheet.xlsx#sheet=trials&row=' || row_number AS assay_locator
          FROM fly_trials
          WHERE 'flies' IN (SELECT species FROM species_filter)
        ),
        contact_labeled AS (
          SELECT
            CASE
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%1c4eb%' THEN '1C4EB'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%2pp%'
                OR lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%2propylphenol%' THEN '2PP'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%3pp%' THEN '3PP'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%4pp%' THEN '4PP'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%deet%' THEN 'DEET'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%ir3535%' THEN 'IR3535'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%menthone%' THEN 'Menthone'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%menthol%' THEN 'Menthol'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%picaridin%' THEN 'Picaridin'
              WHEN lower(json_extract(rows.row_json, '$.video_stem')) LIKE '%thymol%' THEN 'Thymol'
            END AS assay_label,
            CASE
              WHEN rows.name LIKE 'contact_repel_videos/flies/%' THEN 'flies'
              WHEN rows.name LIKE 'contact_repel_videos/mosquitoes%' THEN 'mosquitoes'
              ELSE 'unknown'
            END AS assay_species,
            'contact_no_contact_processed_results' AS source_family,
            'gs://monarch-videos-new/' || rows.name || '#row=' || rows.row_number AS assay_locator
          FROM csv_rows_with_provenance rows
          WHERE rows.name >= 'contact_repel_videos/'
            AND rows.name < 'contact_repel_videos0'
            AND rows.name LIKE '%combined_results%.csv'
            AND lower(coalesce(json_extract(rows.row_json, '$.is_control'), '')) != 'true'
        ),
        contact_assay_evidence AS (
          SELECT
            assay_label,
            {contact_label_key} AS assay_key,
            assay_species,
            source_family,
            assay_locator
          FROM contact_labeled
          WHERE assay_label IS NOT NULL
            AND assay_species IN (SELECT species FROM species_filter)
        ),
        assay_evidence_raw AS (
          SELECT * FROM dart_assay_evidence
          UNION ALL SELECT * FROM fly_assay_evidence
          UNION ALL SELECT * FROM contact_assay_evidence
        ),
        assay_evidence AS (
          SELECT
            coalesce(alias_keys.canonical_compound, assay_evidence_raw.assay_label) AS matched_compound,
            coalesce(alias_keys.canonical_key, assay_evidence_raw.assay_key) AS matched_compound_key,
            assay_evidence_raw.assay_label,
            assay_evidence_raw.assay_species,
            assay_evidence_raw.source_family,
            assay_evidence_raw.assay_locator
          FROM assay_evidence_raw
          LEFT JOIN alias_keys ON alias_keys.alias_key = assay_evidence_raw.assay_key
          WHERE assay_evidence_raw.assay_label IS NOT NULL
            AND trim(assay_evidence_raw.assay_label) <> ''
            AND assay_evidence_raw.assay_key <> ''
        ),
        assay_matches AS (
          SELECT
            phytotox_rows.*,
            assay_evidence.assay_label,
            assay_evidence.assay_species,
            assay_evidence.source_family AS assay_source_family,
            assay_evidence.assay_locator
          FROM phytotox_rows
          JOIN assay_evidence
            ON assay_evidence.matched_compound_key = phytotox_rows.compound_key
        ),
        ranked AS (
          SELECT
            compound_key,
            compound,
            count(DISTINCT source_name || ':' || source_row_number) AS result_rows,
            {sql_literal(date_window)} AS date_window,
            'phytotoxicity_result_row_date' AS date_basis,
            min(result_date_iso) AS first_result_date,
            max(result_date_iso) AS latest_result_date,
            round(avg(damaged_fraction), 4) AS avg_damaged_fraction,
            round(max(damaged_fraction), 4) AS max_damaged_fraction,
            CASE
              WHEN count(damaged_fraction) > 1 THEN sqrt(
                (sum(damaged_fraction * damaged_fraction) - (sum(damaged_fraction) * sum(damaged_fraction) / count(damaged_fraction)))
                / (count(damaged_fraction) - 1)
              )
              ELSE NULL
            END AS standard_deviation,
            CASE
              WHEN count(damaged_fraction) > 1 THEN sqrt(
                ((sum(damaged_fraction * damaged_fraction) - (sum(damaged_fraction) * sum(damaged_fraction) / count(damaged_fraction)))
                / (count(damaged_fraction) - 1))
                / count(damaged_fraction)
              )
              ELSE NULL
            END AS standard_error,
            CASE
              WHEN count(damaged_fraction) > 1 THEN 'sample_stddev_of_damaged_fraction_across_phytotoxicity_rows'
              ELSE 'standard_deviation_not_available_single_phytotoxicity_row'
            END AS standard_deviation_basis,
            round(avg(chlorosis_fraction), 4) AS avg_chlorosis_fraction,
            round(avg(browning_fraction), 4) AS avg_browning_fraction,
            round(avg(necrosis_fraction), 4) AS avg_necrosis_fraction,
            min(source_name) AS example_file,
            min(source_row_number) AS example_row,
            min(assay_locator) AS example_assay_locator,
            count(DISTINCT assay_source_family || ':' || assay_species || ':' || assay_locator) AS assay_evidence_rows
          FROM assay_matches
          GROUP BY compound_key, compound
        )
        SELECT
          row_number() OVER (
            ORDER BY avg_damaged_fraction {order}, max_damaged_fraction {order}, avg_chlorosis_fraction {order}, compound
          ) AS rank,
          compound,
          result_rows,
          date_window,
          date_basis,
          first_result_date,
          latest_result_date,
          avg_damaged_fraction,
          max_damaged_fraction,
          standard_deviation,
          standard_error,
          standard_deviation_basis,
          avg_chlorosis_fraction,
          avg_browning_fraction,
          avg_necrosis_fraction,
          (
            SELECT group_concat(assay_species)
            FROM (
              SELECT DISTINCT assay_species
              FROM assay_matches
              WHERE assay_matches.compound_key = ranked.compound_key
              ORDER BY assay_species
            )
          ) AS assay_species,
          (
            SELECT group_concat(assay_source_family)
            FROM (
              SELECT DISTINCT assay_source_family
              FROM assay_matches
              WHERE assay_matches.compound_key = ranked.compound_key
              ORDER BY assay_source_family
            )
          ) AS assay_source_families,
          assay_evidence_rows,
          example_file,
          example_row,
          example_assay_locator,
          json_object(
            'grain_id', 'phytotox_assay_constrained_rank:' || compound,
            'grain_type', 'phytotox_assay_constrained_rank',
            'locator', 'gs://monarch-videos-new/' || example_file || '#row=' || example_row,
            'source_id', 'monarch_videos_new',
            'date_window', date_window,
            'date_basis', date_basis,
            'standard_deviation_basis', standard_deviation_basis,
            'assay_species', (
              SELECT group_concat(assay_species)
              FROM (
                SELECT DISTINCT assay_species
                FROM assay_matches
                WHERE assay_matches.compound_key = ranked.compound_key
                ORDER BY assay_species
              )
            ),
            'example_assay_locator', example_assay_locator
          ) AS provenance_grain
        FROM ranked
        ORDER BY avg_damaged_fraction {order}, max_damaged_fraction {order}, avg_chlorosis_fraction {order}, compound
    """


def _unsupported_source_lane_for_question(question):
    q = str(question).lower()
    if re.search(r"\bslack\b", q):
        return {
            "source": "slack",
            "missing_adapter": "slack_source_text_retrieval",
            "reason": "Slack is not a queryable Ask Monarch source lane yet",
        }
    return None


def _phytotox_inventory_ranking_route(question):
    limit = _rank_limit_for_question(question, default=5)
    rank_direction = "least" if _has_any(question.lower(), ["least", "lowest", "safest", "safe"]) else "most"
    route_plan = [
        {
            "step": 1,
            "source_lane": "bucket",
            "adapter": "bucket_phytotox_rank_compounds_sql",
            "output": "ranked_phytotox_compounds",
        },
        {
            "step": 2,
            "source_lane": "compound_inventory",
            "adapter": "compound_inventory_all_names_sql",
            "input": "ranked_phytotox_compounds",
            "output": "inventory_matches",
        },
    ]
    return _route_decision(
        intent="phytotox_inventory_ranking",
        source="bucket",
        retrieval_shape="mixed",
        adapter="bucket_phytotox_inventory_ranking_plan",
        adapter_execution="route_plan",
        reason="the answer shape is ranked phytotoxicity compounds constrained by inventory, so bucket phytotoxicity results must run before inventory confirmation",
        route_plan=route_plan,
        answer_shape="ranked_compounds_with_inventory_status",
        rank_direction=rank_direction,
        limit=limit,
        required_sources=["bucket", "compound_inventory"],
        fallback_policy="fail_on_missing_structured_step",
        expected_grain_types=["phytotox_result_row", "xlsx_cell"],
    )


def _inventory_to_assay_route():
    route_plan = [
        {
            "step": 1,
            "source_lane": "compound_inventory",
            "adapter": "compound_inventory_latest_ordered_compounds",
            "output": "compound_list",
        },
        {
            "step": 2,
            "source_lane": "bucket",
            "adapter": "bucket_assay_results_by_compound_list",
            "input": "compound_list",
        },
    ]
    return _route_decision(
        intent="inventory_to_assay_results",
        source="compound_inventory",
        retrieval_shape="mixed",
        adapter="compound_inventory_latest_ordered_compounds",
        adapter_execution="route_plan",
        reason="this question needs inventory to identify compounds before bucket can return assay results",
        route_plan=route_plan,
        fallback_policy="fail_on_missing_structured_step",
    )


def _inventory_sample_with_assay_route():
    route_plan = [
        {
            "step": 1,
            "source_lane": "compound_inventory",
            "adapter": "compound_inventory_all_names_sql",
            "output": "inventory_compound_list",
        },
        {
            "step": 2,
            "source_lane": "bucket",
            "adapter": "bucket_assay_results_by_compound_list",
            "input": "inventory_compound_list",
        },
    ]
    return _route_decision(
        intent="inventory_sample_with_assay",
        source="compound_inventory",
        retrieval_shape="mixed",
        adapter="compound_inventory_all_names_sql",
        adapter_execution="route_plan",
        reason="this question needs an inventory compound list before bucket can find one assay using one listed compound",
        route_plan=route_plan,
        fallback_policy="fail_on_missing_structured_step",
    )


def route_decision_for_question(question, source="auto"):
    requested_source = source
    unsupported_source = _unsupported_source_lane_for_question(question)
    source = auto_source_for_question(question) if source in {"auto", "all"} else source
    if unsupported_source and (
        requested_source in {"auto", "all", "bucket", unsupported_source["source"]}
        or source == unsupported_source["source"]
    ):
        return _source_gap_decision(
            intent="unsupported_source_lane",
                source=unsupported_source["source"],
                reason=unsupported_source["reason"],
                missing_adapter=unsupported_source["missing_adapter"],
            )
    if requested_source in {"auto", "all"}:
        compositional_route = _compositional_answer_contract_route(question)
        if compositional_route:
            return compositional_route
    if requested_source in {"auto", "all", "bucket"} and source == "bucket" and _extract_fly_media_treatment(question):
        fly_result_video_bridge_sql = _bucket_fly_result_video_bridge_sql(question)
        if fly_result_video_bridge_sql:
            return _route_decision(
                intent="fly_result_video_bridge",
                source="bucket",
                retrieval_shape="structured",
                adapter="bucket_fly_result_video_bridge_sql",
                adapter_execution="sql",
                reason="exact fly treatment video requests should join fly ranking rows to matching video objects",
                sql=fly_result_video_bridge_sql,
                answer_shape="ranked_repellents_with_media",
                selection_policy="answer_shape_first",
                species="flies",
                fallback_policy="no_silent_prose_fallback",
                expected_grain_types=["fly_result_video_bridge"],
            )
    answer_shape = _answer_shape_for_question(question)
    if requested_source in {"auto", "all"} and answer_shape:
        mixed_route = _mixed_answer_shape_route(question, answer_shape)
        if mixed_route:
            return mixed_route
    if _is_phytotox_inventory_ranking(question):
        return _phytotox_inventory_ranking_route(question)
    if _is_inventory_to_assay_results(question):
        return _inventory_to_assay_route()
    if _is_inventory_sample_with_assay(question):
        return _inventory_sample_with_assay_route()
    adapter = structured_adapter_for_question(question, source)
    if adapter:
        modifier_gap = _modifier_contract_gap_for_adapter(question, source, adapter)
        if modifier_gap:
            return modifier_gap
        if adapter.get("force_source_gap"):
            return _source_gap_decision(
                intent=adapter["intent"],
                source=source,
                reason=adapter["reason"],
                missing_adapter=adapter.get("missing_adapter") or adapter.get("adapter"),
                answer_shape=adapter.get("answer_shape"),
                selection_policy=adapter.get("selection_policy"),
                candidate_routes=adapter.get("candidate_routes", []),
                rejected_routes=adapter.get("rejected_routes", []),
            )
        extra = {
            key: value
            for key, value in adapter.items()
            if key not in {"intent", "adapter", "adapter_execution", "sql", "reason"}
        }
        return _route_decision(
            intent=adapter["intent"],
            source=source,
            retrieval_shape="structured",
            adapter=adapter["adapter"],
            adapter_execution=adapter["adapter_execution"],
            reason=adapter["reason"],
            **extra,
        )
    if _is_media_proof_question(question) and source == "bucket":
        return _route_decision(
            intent="media_proof",
            source=source,
            retrieval_shape="mixed",
            adapter="bucket_assay_media_links",
            adapter_execution="structured_then_media",
            reason="media proof should identify an assay or media row before opening raw video",
        )
    anchor = structured_anchor_for_question(question, source)
    if anchor:
        extra = {
            key: value
            for key, value in anchor.items()
            if key not in {"intent", "adapter", "adapter_execution", "sql", "reason"}
        }
        return _route_decision(
            intent=anchor["intent"],
            source=source,
            retrieval_shape="mixed",
            adapter=anchor["adapter"],
            adapter_execution=anchor["adapter_execution"],
            reason=anchor["reason"],
            fallback_policy="structured_first_then_prose",
            **extra,
        )
    if source in {"teams_recaps", "presentations", "company_context", "cross_experiment_docs", "scientific_refs", "milestones_doc"}:
        return _route_decision(
            intent="source_specific_prose",
            source=source,
            retrieval_shape="prose",
            adapter=f"{source}_source_text_retrieval",
            adapter_execution="text_retrieval",
            reason=f"{source} is a source-specific text lane for this question",
        )
    if source in {"people_directory", "company_profile", "compound_inventory", "bucket"} and _is_exact_fact_question(question):
        return _source_gap_decision(
            intent="exact_fact_without_adapter",
            source=source,
            reason="exact fact question has no valid typed adapter for this source lane",
        )
    return _route_decision(
        intent="source_specific_prose",
        source=source,
        retrieval_shape="prose",
        adapter=f"{source}_source_text_retrieval",
        adapter_execution="text_retrieval",
        reason="no structured adapter matched, so this route is limited to source-specific text retrieval",
    )


def structured_sql_for_question(question, source):
    adapter = structured_adapter_for_question(question, source)
    if adapter and adapter.get("adapter_execution") == "sql":
        return adapter["sql"]
    return None


def source_gap_payload_for_route(route):
    missing_adapter = route.get("missing_adapter") or route.get("adapter")
    return {
        "missing_adapter": missing_adapter,
        "intent": route.get("intent"),
        "source_lane": route.get("source_lane"),
        "message": route.get("message")
        or f"Ask Monarch found the route, but the required adapter is not queryable yet: {missing_adapter}",
        "detected_modifiers": route.get("detected_modifiers", []),
        "unsupported_modifiers": route.get("unsupported_modifiers", []),
    }


def query_payload_for_question(question, source, kind="all", limit=20, offset=0, include_health=False, deep_health=False):
    route = route_decision_for_question(question, source)
    payload = {
        "source": route.get("source_lane", source),
        "kind": kind,
        "limit": limit,
        "offset": offset,
        "include_health": include_health,
        "deep_health": deep_health,
        "routing_decision": route,
    }
    if route.get("adapter") == "compound_inventory_all_names_sql":
        payload["limit"] = max(int(limit or 20), 1000)
    if route.get("answer_shape") == "contact_noncontact_ranked_comparison":
        payload["limit"] = max(int(limit or 20), 20)
    if route.get("answer_shape") == "individual_assay_timepoint_ranking":
        payload["limit"] = max(int(limit or 20), 20)
    if route["retrieval_shape"] == "source_gap":
        payload["source_gap"] = source_gap_payload_for_route(route)
        return payload
    anchor = structured_anchor_for_question(question, payload["source"])
    if (
        route.get("retrieval_shape") == "mixed"
        and route.get("adapter_execution") == "structured_anchor_then_text_retrieval"
        and anchor
        and anchor.get("sql")
    ):
        payload["structured_anchor_sql"] = anchor["sql"]
        payload["question"] = question
        return _attach_sql_sketch(payload)
    if route.get("adapter_execution") == "sql" and route.get("sql"):
        payload["sql"] = route["sql"]
        return _attach_sql_sketch(payload)
    adapter = structured_adapter_for_question(question, payload["source"])
    if adapter and adapter.get("adapter_execution") == "sql":
        payload["sql"] = adapter["sql"]
        return _attach_sql_sketch(payload)
    payload["question"] = question
    return payload


def _direct_bypass_reason(payload):
    if "routing_decision" in payload:
        return None
    if "sql" in payload and not (payload.get("question") or payload.get("q")):
        return "direct_sql_command"
    if "csv_q" in payload:
        return "direct_csv_search"
    if "get" in payload:
        return "direct_get_command"
    if "assay_media" in payload:
        return "direct_assay_media_command"
    return None


def _primary_table_label(payload):
    sql = str(payload.get("sql") or payload.get("structured_anchor_sql") or "").lower()
    if not sql:
        return None
    for table in [
        "objects",
        "assay_media_links",
        "dart_assay_results",
        "meetings",
        "utterances",
        "units",
        "cells",
        "csv_rows",
        "xlsx_cells",
        "source_search",
        "model_metadata",
        "pdf_pages",
        "paragraph_units",
    ]:
        if re.search(rf"\b(?:from|join)\s+{re.escape(table)}\b", sql):
            return f"{table} table"
    return None


def _sql_tables_for_sketch(sql):
    tables = []
    for match in re.finditer(r"\b(?:from|join)\s+([a-zA-Z_][\w.]*)", str(sql), flags=re.IGNORECASE):
        table = match.group(1)
        if table.lower() in {"select", "with"}:
            continue
        if table not in tables:
            tables.append(table)
    return tables


def _species_filter_from_sql(sql):
    match = re.search(r"lower\(species\)\s*=\s*'([^']+)'", str(sql), flags=re.IGNORECASE)
    if match:
        return match.group(1)
    match = re.search(r"\bspecies\s*=\s*'([^']+)'", str(sql), flags=re.IGNORECASE)
    if match:
        return match.group(1)
    return None


def _sql_sketch_lines_for_dart_assay_results(route, sql):
    answer_shape = route.get("answer_shape")
    species = route.get("species") or _species_filter_from_sql(sql)
    n_alias = "n_insects"
    if species in {"beetles", "mosquitoes", "flies"}:
        n_alias = f"n_{species}"
    if answer_shape == "assay_run_list":
        select_lines = [
            "  assay_date_iso AS date,",
            "  filename AS file,",
            "  tube,",
            "  treatment,",
            "  left_condition,",
            "  right_condition,",
            f"  n_insects_real AS {n_alias},",
            "  temp,",
            "  rh,",
            "  source_name AS source_file,",
            "  provenance_grain AS provenance",
        ]
        where_lines = ["  assay_type = 'DART'"]
        if species:
            where_lines.append(f"  AND species = '{species}'")
        parameters = route.get("extracted_parameters") if isinstance(route.get("extracted_parameters"), dict) else {}
        if parameters.get("applied_filter"):
            where_lines.append("  AND date filter from question")
        return [
            "SELECT",
            *select_lines,
            "FROM dart_assay_results",
            "WHERE",
            *where_lines,
            "ORDER BY date, source_file, row_number;",
        ]
    select_lines = [
        "  species,",
        "  treatment,",
        "  dilution,",
        "  count(*) AS assay_rows,",
        "  avg(avg_pi_real) AS mean_avg_pi,",
        "  provenance_grain AS provenance",
    ]
    where_lines = ["  assay_type = 'DART'"]
    if species:
        where_lines.append(f"  AND species = '{species}'")
    return [
        "SELECT",
        *select_lines,
        "FROM dart_assay_results",
        "WHERE",
        *where_lines,
        "GROUP BY species, treatment, dilution",
        "ORDER BY mean_avg_pi ASC;",
    ]


def _sql_sketch_for_payload(payload):
    sql = payload.get("sql") or payload.get("structured_anchor_sql")
    if not sql:
        return None
    route = payload.get("routing_decision") if isinstance(payload.get("routing_decision"), dict) else {}
    adapter = route.get("adapter")
    tables = _sql_tables_for_sketch(sql)
    table = tables[0] if tables else "structured source table"
    if table == "dart_assay_results" and adapter == "bucket_dart_assay_results_sql":
        return "\n".join(_sql_sketch_lines_for_dart_assay_results(route, sql))
    if adapter in {"bucket_compounds_tested_all_structured_sql", "bucket_compounds_tested_by_date_window_sql"}:
        return "\n".join(
            [
                "SELECT",
                "  tested_compound,",
                "  species,",
                "  assay_type,",
                "  normalized_evidence_date AS date,",
                "  locator,",
                "  provenance_grain AS provenance",
                "FROM dart_assay_results and related assay result rows",
                "WHERE date and control/seed/failure filters from question",
                "ORDER BY date DESC, tested_compound;",
            ]
        )
    if adapter == "bucket_contact_noncontact_adjusted_pi_comparison_sql":
        return "\n".join(
            [
                "SELECT",
                "  video_stem,",
                "  contact_mode,",
                "  compound,",
                "  adj_contact_pi_mean,",
                "  frac_time_avoiding,",
                "  provenance_grain AS provenance",
                "FROM adjusted_contact_pi_summary rows",
                "WHERE species, contact/non-contact, and date filters from question",
                "ORDER BY adj_contact_pi_mean DESC;",
            ]
        )
    if adapter == "bucket_cross_assay_run_inventory_sql":
        return "\n".join(
            [
                "SELECT",
                "  assay_family,",
                "  species,",
                "  run_date,",
                "  assay_count,",
                "  source_locator,",
                "  provenance_grain AS provenance",
                "FROM structured assay ledgers",
                "WHERE assay family, species, and date filters from question",
                "ORDER BY run_date DESC, assay_family, species;",
            ]
        )
    if adapter in {"bucket_script_method_evidence_sql", "chemistry_analysis_script_method_evidence_sql"}:
        return "\n".join(
            [
                "SELECT",
                "  script_name,",
                "  script_line,",
                "  evidence_text,",
                "  script_uri,",
                "  provenance_grain AS provenance",
                "FROM indexed bucket script lines",
                "WHERE script names and method terms from question match",
                "ORDER BY matched lines first, script_name, script_line;",
            ]
        )
    if adapter == "bucket_assay_serving_table_sql":
        answer_shape = route.get("answer_shape")
        if answer_shape in {"tested_compound_date_window", "tested_compound_list"}:
            return "\n".join(
                [
                    "SELECT",
                    "  tested_compound,",
                    "  species,",
                    "  assay_family,",
                    "  first_test_date,",
                    "  latest_test_date,",
                    "  provenance_grain AS provenance",
                    "FROM compound_test_events",
                    "WHERE compound, species, assay family, and date filters from question",
                    "ORDER BY latest_test_date DESC, tested_compound;",
                ]
            )
        if answer_shape in {"assay_run_list", "assay_inventory_count", "fly_assay_count"}:
            return "\n".join(
                [
                    "SELECT",
                    "  run_date AS date,",
                    "  species,",
                    "  assay_family,",
                    "  assay_mode,",
                    "  treatment,",
                    "  filename,",
                    "  provenance_grain AS provenance",
                    "FROM assay_runs",
                    "WHERE species, assay family, assay mode, and date filters from question",
                    "ORDER BY run_date DESC, source_name, row_number;",
                ]
            )
        return "\n".join(
            [
                "SELECT",
                "  rank,",
                "  species,",
                "  assay_family,",
                "  compound,",
                "  metric_name,",
                "  metric_value,",
                "  ranking_score,",
                "  provenance_grain AS provenance",
                "FROM assay_results JOIN assay_runs",
                "WHERE compound, species, assay family, metric, and date filters from question",
                "ORDER BY species, assay_family, assay_mode, rank;",
            ]
        )
    expected = _expected_grain_types(route)
    expected_label = ", ".join(expected[:2]) if expected else "source rows"
    where_label = "adapter filters from question"
    parameters = route.get("extracted_parameters") if isinstance(route.get("extracted_parameters"), dict) else {}
    if parameters.get("applied_filter"):
        where_label = parameters["applied_filter"]
    table_label = " + ".join(tables[:3]) if tables else table
    return "\n".join(
        [
            "SELECT",
            "  relevant fields,",
            "  provenance_grain AS provenance",
            f"FROM {table_label}",
            f"WHERE {where_label}",
            f"ORDER BY {expected_label} specific ordering;",
        ]
    )


def _attach_sql_sketch(payload):
    sketch = _sql_sketch_for_payload(payload)
    if not sketch:
        return payload
    enriched = dict(payload)
    enriched["sql_sketch"] = sketch
    route = enriched.get("routing_decision")
    if isinstance(route, dict):
        route = dict(route)
        route["sql_sketch"] = sketch
        enriched["routing_decision"] = route
    return enriched


def _contains_action_type(value, action_type):
    if isinstance(value, list):
        return any(_contains_action_type(item, action_type) for item in value)
    if not isinstance(value, dict):
        return False
    if value.get("type") == action_type:
        return True
    return any(_contains_action_type(child, action_type) for child in value.values())


def _result_action_label(result):
    if _contains_action_type(result, "resolve_source"):
        return "resolve-source"
    if _contains_action_type(result, "assay_overlay"):
        return "assay-overlay"
    return None


def _expected_grain_types(route):
    expected = route.get("expected_grain_types")
    if expected is None and route.get("expected_grain_type"):
        expected = [route.get("expected_grain_type")]
    if expected is None:
        expected = EXPECTED_GRAIN_TYPES_BY_ADAPTER.get(route.get("adapter"))
    if isinstance(expected, str):
        return [expected]
    if isinstance(expected, (list, tuple, set)):
        return [str(item) for item in expected if item]
    return []


def _row_list_for_result(result):
    rows = result.get("rows")
    if isinstance(rows, list):
        return rows
    row = result.get("row")
    if isinstance(row, dict):
        return [row]
    return []


def _grain_types_in_value(value, depth=0):
    if depth > 8:
        return []
    if isinstance(value, str):
        text = value.strip()
        if not text or text[0] not in "[{":
            return []
        try:
            return _grain_types_in_value(json.loads(text), depth + 1)
        except (TypeError, ValueError, json.JSONDecodeError):
            return []
    if isinstance(value, list):
        grain_types = []
        for item in value:
            grain_types.extend(_grain_types_in_value(item, depth + 1))
        return grain_types
    if isinstance(value, dict):
        grain_types = []
        grain_type = value.get("grain_type")
        if grain_type:
            grain_types.append(str(grain_type))
        for child in value.values():
            grain_types.extend(_grain_types_in_value(child, depth + 1))
        return grain_types
    return []


def grain_types_for_result(result):
    grain_types = []
    for row in _row_list_for_result(result):
        grain_types.extend(_grain_types_in_value(row))
    unique = []
    for grain_type in grain_types:
        if grain_type not in unique:
            unique.append(grain_type)
    return unique


def assess_structured_result(route, result):
    rows = _row_list_for_result(result)
    row_count = len(rows)
    has_error = bool(result.get("error")) or result.get("ok") is False or result.get("mode") == "source_gap"
    expected = _expected_grain_types(route)
    found = grain_types_for_result(result)
    matched = [grain_type for grain_type in found if not expected or grain_type in expected]
    clean = bool(not has_error and row_count > 0 and (not expected or matched))
    assessment = {
        "clean": clean,
        "error": has_error,
        "row_count": row_count,
    }
    if expected:
        assessment["expected_grain_type"] = expected[0] if len(expected) == 1 else expected
    if found:
        assessment["matched_grain_type"] = matched[0] if matched else found[0]
    return assessment


def _translation_steps(route, table_label=None, action_label=None):
    source_lane = route.get("source_lane")
    adapter = route.get("adapter")
    steps = [
        {"step": "source lane selection", "output": source_lane, "source": "system"},
    ]
    parameters = route.get("extracted_parameters")
    if isinstance(parameters, dict) and parameters.get("interpreted_date"):
        steps.append(
            {
                "step": "date interpretation",
                "input": parameters.get("relative_date") or parameters.get("interpreted_date"),
                "output": parameters.get("interpreted_date"),
                "source": "user",
            }
        )
    if isinstance(parameters, dict) and parameters.get("normalized_date_field"):
        steps.append(
            {
                "step": "field normalization",
                "input": parameters.get("date_field"),
                "output": parameters.get("normalized_date_field"),
                "source": "system",
            }
        )
    if isinstance(parameters, dict) and parameters.get("applied_filter"):
        steps.append(
            {
                "step": "applied filter",
                "output": parameters.get("applied_filter"),
                "source": "system",
            }
        )
    if isinstance(parameters, dict) and parameters.get("matched_alias"):
        steps.append(
            {
                "step": "alias matching",
                "input": parameters.get("matched_alias"),
                "output": parameters.get("media_mode"),
                "source": "user",
                "match_type": "deterministic_alias",
            }
        )
    if isinstance(parameters, dict):
        if parameters.get("media_kind"):
            steps.append(
                {
                    "step": "parameter extraction",
                    "input": parameters.get("media_kind"),
                    "output": f"media_kind={parameters.get('media_kind')}",
                    "source": "user",
                }
            )
        if parameters.get("media_mode"):
            steps.append(
                {
                    "step": "parameter extraction",
                    "input": parameters.get("matched_alias"),
                    "output": f"media_mode={parameters.get('media_mode')}",
                    "source": "user",
                }
            )
        if parameters.get("order_by"):
            steps.append(
                {
                    "step": "parameter extraction",
                    "input": "recent",
                    "output": "recent_first=true",
                    "source": "user",
                }
            )
        if parameters.get("exclude"):
            for excluded in parameters.get("exclude"):
                steps.append(
                    {
                        "step": "parameter default",
                        "output": f"exclude={excluded}",
                        "source": "default",
                    }
                )
    steps.append({"step": "adapter selection", "output": adapter, "source": "system"})
    if table_label:
        steps.append({"step": "sql target", "output": table_label, "source": "system"})
    if action_label:
        steps.append({"step": "source action", "output": action_label, "source": "system"})
    return steps


def _answer_metadata_for_route(route):
    parameters = route.get("extracted_parameters") if isinstance(route.get("extracted_parameters"), dict) else {}
    metadata_keys = [
        "interpreted_date",
        "interpreted_start_date",
        "interpreted_end_date",
        "relative_date",
        "date_source",
        "date_field",
        "normalized_date_field",
        "applied_filter",
    ]
    metadata = {key: parameters[key] for key in metadata_keys if key in parameters}
    return metadata or None


def routing_log_for_payload(payload, result=None):
    result = result or {}
    if payload.get("router_bypassed"):
        reason = payload.get("bypass_reason")
        return {
            "router_ran": False,
            "router_bypassed": True,
            "bypass_reason": reason,
            "source_lane_ran": payload.get("source"),
            "winning_lane": result.get("source") or payload.get("source"),
            "winning_adapter": None,
            "retrieval_shape": "direct",
            "adapter_execution": "direct",
            "short_circuit_fired": True,
            "short_circuit_reason": reason,
            "path": f"direct -> {reason or 'bypassed'}",
        }

    route = payload.get("routing_decision") if isinstance(payload.get("routing_decision"), dict) else {}
    if not route:
        return {
            "router_ran": False,
            "router_bypassed": False,
            "source_lane_ran": payload.get("source"),
            "winning_lane": result.get("source") or payload.get("source"),
            "winning_adapter": None,
            "retrieval_shape": result.get("mode"),
            "adapter_execution": None,
            "short_circuit_fired": False,
            "short_circuit_reason": None,
            "path": "unrouted",
        }

    source_lane = route.get("source_lane") or payload.get("source")
    winning_lane = result.get("source") or source_lane
    retrieval_shape = route.get("retrieval_shape")
    adapter = route.get("adapter")
    fallback_policy = route.get("fallback_policy")
    structured_result = payload.get("structured_result_assessment")
    if not isinstance(structured_result, dict):
        structured_result = None
    if structured_result is None and retrieval_shape in {"structured", "mixed"} and result.get("mode") != "source_gap":
        structured_result = assess_structured_result(route, result)
    short_circuit_fired = (
        retrieval_shape == "source_gap"
        or result.get("mode") == "source_gap"
        or fallback_policy in {"fail_with_source_gap", "fail_on_missing_structured_step"}
        or (retrieval_shape == "structured" and bool(structured_result and structured_result.get("clean")))
    )
    table_label = _primary_table_label(payload)
    path_parts = ["query", "router", str(winning_lane), str(retrieval_shape), str(adapter)]
    if table_label:
        path_parts.append(table_label)
    action_label = _result_action_label(result)
    if action_label:
        path_parts.append(action_label)
    return {
        "router_ran": True,
        "router_bypassed": False,
        "source_lane_ran": source_lane,
        "winning_lane": winning_lane,
        "winning_adapter": adapter,
        "retrieval_shape": retrieval_shape,
        "adapter_execution": route.get("adapter_execution"),
        "short_circuit_fired": bool(short_circuit_fired),
        "short_circuit_reason": fallback_policy if short_circuit_fired else None,
        "policy": fallback_policy,
        "structured_result": structured_result,
        "extracted_parameters": route.get("extracted_parameters"),
        "translation_steps": _translation_steps(route, table_label, action_label),
        "path": " -> ".join(path_parts),
    }


def apply_authoritative_route(payload):
    routed = dict(payload)
    bypass_reason = _direct_bypass_reason(routed)
    if bypass_reason:
        routed["router_bypassed"] = True
        routed["bypass_reason"] = bypass_reason
        return routed
    question = routed.get("question") or routed.get("q")
    if question:
        route = route_decision_for_question(str(question), str(routed.get("source", "auto")))
        routed["routing_decision"] = route
        routed["source"] = route.get("source_lane", routed.get("source", "bucket"))
        if route.get("retrieval_shape") == "source_gap":
            routed["source_gap"] = source_gap_payload_for_route(route)
            return routed
        if route.get("intent") == "media_proof" and "assay_media" not in routed:
            routed["source_gap"] = source_gap_payload_for_route(route)
            return routed
        if (
            route.get("retrieval_shape") == "mixed"
            and route.get("fallback_policy") == "fail_on_missing_structured_step"
            and route.get("intent") != "phytotox_inventory_ranking"
        ):
            routed["source_gap"] = source_gap_payload_for_route(route)
            return routed
        if route.get("adapter_execution") == "route_plan":
            routed.pop("sql", None)
            return routed
        anchor = structured_anchor_for_question(str(question), routed["source"])
        if (
            route.get("retrieval_shape") == "mixed"
            and route.get("adapter_execution") == "structured_anchor_then_text_retrieval"
            and anchor
            and anchor.get("sql")
        ):
            routed["structured_anchor_sql"] = anchor["sql"]
            routed["question"] = str(question)
            routed.pop("sql", None)
            return _attach_sql_sketch(routed)
        adapter = structured_adapter_for_question(str(question), routed["source"])
        if adapter and adapter.get("adapter_execution") == "sql":
            routed["sql"] = adapter["sql"]
        return _attach_sql_sketch(routed)
    route = routed.get("routing_decision")
    if isinstance(route, dict):
        routed["source"] = route.get("source_lane", routed.get("source", "bucket"))
    return routed


def attach_routing_decision(payload, result):
    enriched = dict(result)
    if payload.get("router_bypassed"):
        enriched["router_bypassed"] = True
        enriched["bypass_reason"] = payload.get("bypass_reason")
    route = payload.get("routing_decision")
    if isinstance(route, dict):
        enriched["routing_decision"] = route
        if route.get("sql_sketch"):
            enriched["sql_sketch"] = route["sql_sketch"]
        answer_metadata = _answer_metadata_for_route(route)
        if answer_metadata:
            enriched["answer_metadata"] = answer_metadata
    log_payload = payload
    existing_log = enriched.get("routing_log") if isinstance(enriched.get("routing_log"), dict) else {}
    if existing_log.get("structured_result") is not None and not payload.get("structured_result_assessment"):
        log_payload = dict(payload)
        log_payload["structured_result_assessment"] = existing_log["structured_result"]
    enriched["routing_log"] = routing_log_for_payload(log_payload, enriched)
    return enriched


def _route_allows_prose_fallback(route):
    return route.get("fallback_policy") in {"structured_first_then_prose"} or route.get("retrieval_shape") == "prose"


def structured_result_or_source_gap(payload, result, source=None):
    route = payload.get("routing_decision") if isinstance(payload.get("routing_decision"), dict) else {}
    if route.get("retrieval_shape") != "structured":
        return attach_routing_decision(payload, result)
    assessment = assess_structured_result(route, result)
    if assessment.get("clean"):
        return attach_routing_decision(payload, result)
    if _route_allows_prose_fallback(route):
        return attach_routing_decision(payload, result)
    expected = assessment.get("expected_grain_type") or "expected grain type"
    reason = (
        f"structured adapter {route.get('adapter')} returned no clean {expected} rows "
        "and prose fallback is not allowed"
    )
    gap_payload = dict(payload)
    gap_payload["structured_result_assessment"] = assessment
    return source_gap_result(gap_payload, source or result.get("source") or route.get("source_lane"), reason=reason)


def router_bypass_result(result, reason):
    enriched = dict(result)
    enriched["router_bypassed"] = True
    enriched["bypass_reason"] = reason
    return enriched


def source_gap_result(payload, source=None, reason=None):
    route = payload.get("routing_decision") if isinstance(payload.get("routing_decision"), dict) else {}
    source_gap = payload.get("source_gap") if isinstance(payload.get("source_gap"), dict) else {}
    result = {
        "ok": False,
        "mode": "source_gap",
        "source": source or route.get("source_lane") or source_gap.get("source_lane") or payload.get("source", "bucket"),
        "rows": [],
        "source_gap": {
            "missing_adapter": source_gap.get("missing_adapter") or route.get("missing_adapter") or route.get("adapter"),
            "intent": source_gap.get("intent") or route.get("intent"),
            "source_lane": source_gap.get("source_lane") or route.get("source_lane"),
            "message": reason or source_gap.get("message") or route.get("reason") or "no valid route",
        },
    }
    return attach_routing_decision(payload, result)


def route_blocks_text_fallback(payload):
    route = payload.get("routing_decision")
    return bool(isinstance(route, dict) and route.get("retrieval_shape") == "structured")
