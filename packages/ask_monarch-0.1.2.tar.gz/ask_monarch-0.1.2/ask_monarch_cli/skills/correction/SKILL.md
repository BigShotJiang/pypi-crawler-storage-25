---
name: correction
description: Use when the user corrects an Ask Monarch or Just-1 answer, says the answer was wrong or incomplete, says the agent missed a source, or asks to fix how the company-memory agent answered.
---

# Company Memory Correction

Use this skill when the user corrects an Ask Monarch or Just-1 answer, or
points out that the agent used the wrong source, missed evidence, overclaimed,
or framed the answer badly.

## Contract

- Treat the correction as source-routing feedback, not just chat feedback.
- Do not defend the prior answer. Find the failure mode and make the durable rule better.
- Preserve the user's correction exactly enough that another agent can understand what changed.
- Verify against the hosted source plane before changing routing rules when verification is possible.

## Surfaces

| Company | Answer skill | CLI | Durable answer rules | Source rules | Product spec |
| --- | --- | --- | --- | --- | --- |
| Monarch | `$askmonarch` | `ask-monarch` | `skills/askmonarch/SKILL.md` | `skills/monarch-source/SKILL.md` | `ASKMONARCH-SPEC.md` |
| Just | `$askjust` | `ask-just` | `skills/askjust/SKILL.md` | `skills/just-source/SKILL.md` | `SPEC.md` |

## Workflow

1. Identify the failed behavior:
   - missed verified source lane
   - wrong source lane
   - incomplete multi-source answer
   - overclaim beyond evidence
   - missing provenance grain
   - date/freshness confusion
   - source not yet queryable

2. Re-query the source plane with the corrected route.
   - Run the corrected retrieval first. Use health only if the retrieval fails, times out, or is suspiciously empty for the expected source boundary.
   - Use exact source flags when the correction names or implies a lane.
   - Monarch examples: `--source presentations`, `--source milestones_doc`, `--source teams_recaps`.
   - Just examples: `--source scorecard_monthly_data`, `--source batch_release_app`, `--source netsuite_items`.
   - If the correction is about a deck, document, meeting, or workbook, inspect the atomic units, not only top-level metadata.

3. Patch the durable rule in the right repo file:
   - Answer/routing behavior: `skills/askmonarch/SKILL.md` or `skills/askjust/SKILL.md`
   - Source onboarding/queryability behavior: `skills/monarch-source/SKILL.md` or `skills/just-source/SKILL.md`
   - Product contract or persistent source hierarchy: `ASKMONARCH-SPEC.md` or `SPEC.md`
   - User-facing setup or architecture: `README.md`
   - Trace/debug behavior: `skills/braintrust/SKILL.md`

4. If the corrected evidence lives in an artifact that is not queryable yet, do not encode it as an answer rule. Say it is a source gap and route to `monarch-source` or `just-source` work instead.

5. Install changed skills into Codex from the repo you changed:

```bash
# Ask Monarch repo
python3 scripts/install_codex_skills.py --skill askmonarch
python3 scripts/install_codex_skills.py --skill monarch-source
python3 scripts/install_codex_skills.py --skill correction

# Just-1 repo
python3 scripts/install_codex_skills.py --skill askjust
python3 scripts/install_codex_skills.py --skill just-source
python3 scripts/install_codex_skills.py --skill correction
```

6. Close with:
   - the corrected rule
   - the files changed
   - the verification command or source query used

## Guardrails

- Do not rely on the prior chat transcript as evidence for future answers. Use it only to understand the correction.
- Do not hide uncertainty. If the correction is plausible but not verified, say what still needs checking.
- Do not make a narrow one-question patch if the correction reveals a general routing rule.
- Do not change unrelated source contracts while fixing one answer behavior.
