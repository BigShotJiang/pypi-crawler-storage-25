---
name: askmonarch
description: Ask Monarch's verified company memory and answer from source-grade Monarch evidence. Use when the user invokes `@askmonarch`, `askmonarch`, `$askmonarch`, asks a Monarch source/company-memory question, or explicitly asks to force the Monarch path.
---

# Ask Monarch

Use this skill as an agent-facing front door for Monarch's verified company memory.

## Contract

- `$askmonarch` means "ask Monarch what it knows from verified source-grade artifacts."
- The user should not need to know which artifact, database, table, bucket, deck, or CLI flag to use. Routing is the agent's job, whether the host is Codex, Claude, Gemini, Pi, OpenCode, or another coding/research agent.
- All user-facing Monarch research/source/company-memory questions go through the hosted Ask Monarch source service by default.
- Ordinary Ask Monarch answers should not query raw Monarch artifacts directly unless an explicit exception was made. Raw artifacts are upstream evidence; the answer surface is `ask-monarch` calling the hosted API, which reads verified SQLite3 `source_index.sqlite` files on the `ask-monarch-server` VM under `/home/josh/ask-monarch/artifacts/.../`.
- Do not answer Monarch source questions from general model knowledge, memory summaries, screenshots, local notes outside this source plane, or ad hoc bucket browsing as a substitute.
- For ordinary Monarch questions, run the actual retrieval first. Do not add `--with-health` as a default readiness ritual. Use `--with-health` only when the user asks for runtime/source-plane proof or when debugging a failed, timed-out, or suspiciously empty retrieval:

```bash
ask-monarch search "TERM" --kind image --limit 5
ask-monarch sql "select ... from ... limit 5"
```

- Use standalone `ask-monarch health` only when diagnosing service readiness or after a failed, timed-out, or suspiciously empty retrieval. Use `ask-monarch health --deep` only for deploys, refreshes, or suspected source drift.
- If a health check fails, report the failure plainly and stop. Do not provide a fallback answer.
- Treat the VM SQLite3 `source_index.sqlite` files as the answer source of record for the active source plane. Use local SQLite only for development/rebuild verification or when the user explicitly asks for local inspection.
- Current verified company-memory sources:
  - `bucket`: parsed Monarch experiment bucket, including assays, videos, images, CSVs, spreadsheets, PDFs, model metadata, and processed source artifacts.
  - `presentations`: parsed 2026 Monarch update decks from the `Storyboards_Presentations` Google Drive folder, January 1, 2026 onward.
  - `teams_recaps`: parsed recurring Monarch R&D, Weekly, and Team Sync meeting transcripts in the combined hosted Teams recap index.
  - `company_profile`: parsed Monarch mission, problem, approach, headquarters, organisms, and crop-testing context from the repo-owned company profile source.
  - `people_directory`: parsed Monarch employees, advisors, and partnership facts from the repo-owned people directory source.
  - `company_context`: parsed company context from PDF intake evidence with page, text-block, and embedded-image-reference units.
  - `scientific_refs`: parsed scoped scientific reference library with Drive-hosted literature PDFs/support workbooks across chemical ecology, receptors/pathways, modeling, assay prototypes, scalability, EPA registration-support sub-boundaries, plus explicitly pulled public journal PDFs discussed in Monarch R&D Teams recaps.
  - `milestones_doc`: parsed Monarch milestones Google Doc revision with paragraph-level provenance.
  - `compound_inventory`: parsed Monarch compound / chemical inventory from the user-provided `Updated Chemical Inventory.xlsx` workbook attachment, with sheet/cell provenance.
- Personal Monarch mailbox access is a private live overlay, not shared verified company memory. If the current Ask Monarch token is mapped as Josh's personal token, use `ask-monarch personal-mail-*` for `josh@monarchcrops.com` read/search/draft/send requests. The shared/team token must not access personal mail, and personal mail is not indexed into shared SQLite.
- Unsourced artifacts are not part of verified company memory yet. If the user asks about Teams channels/messages outside the parsed R&D recaps, shared/company email, older decks, papers outside the scoped `scientific_refs` boundary, notebooks, dashboards, or any artifact class not yet sourced, say it is not yet Ask Monarch-queryable and record it as a source gap.
- Use the remote `ask-monarch` CLI for source retrieval. CLI syntax is internal machinery; do not make the user choose it.
- Resolve the CLI before doing any source work. Prefer `ask-monarch` when it is on `PATH`; otherwise use `$HOME/.local/bin/ask-monarch` directly. Do not inspect an empty workspace, search local project files, or fall back to web/general knowledge because the command is missing from the current shell path.
- If `$HOME/.local/bin/ask-monarch` exists but fails with a Python or developer-tools error, run the installer reset command again. The installer owns the Python-runtime wrapper, and ordinary answers should resume only after `ask-monarch doctor` is ready.

## Parity Contract

Every teammate should get the same Ask Monarch experience in a new Codex thread and in every project.

- Resolve the CLI before doing any source work.
- Do not inspect an empty workspace, search local project files, or browse around the filesystem for ordinary Monarch source answers.
- Resolve relative dates to absolute dates and name the absolute date in the answer.
- Use structured sources before search. Tables, ledgers, workbooks, directories, and exact schemas beat natural search whenever the fact has a structured home.
- Do not substitute upload-date object activity for run-date ledger evidence. Upload/update timestamps answer upload questions; assay ledgers answer run questions.
- Answers must include source id and row/locator provenance. For spreadsheet-ledger answers, cite workbook, sheet, and row range. For media, cite the `assay_media_links` row or media locator used.
- If the hosted source plane cannot answer, say it is an Ask Monarch source gap or setup problem. Do not fill the gap with web search, general knowledge, raw local files, SSH, direct SQLite, or ad hoc bucket browsing.

Internal retrieval examples:

```bash
ask-monarch summary
ask-monarch search "TERM" --kind image --limit 5
ask-monarch search "TERM" --kind pdf_page --limit 5
ask-monarch search "TERM" --source presentations --limit 5
ask-monarch search "TERM" --source teams_recaps --limit 5
ask-monarch search "TERM" --source company_profile --limit 5
ask-monarch search "TERM" --source people_directory --limit 5
ask-monarch search "TERM" --source company_context --limit 5
ask-monarch search "TERM" --source scientific_refs --limit 5
ask-monarch search "TERM" --source milestones_doc --limit 5
ask-monarch search "TERM" --source compound_inventory --limit 5
ask-monarch presentations-search "TERM" --limit 5
ask-monarch teams-recaps-search "TERM" --limit 5
ask-monarch company-profile-search "TERM" --limit 5
ask-monarch people-search "TERM" --limit 5
ask-monarch company-context-search "TERM" --limit 5
ask-monarch scientific-refs-search "TERM" --limit 5
ask-monarch milestones-search "TERM" --limit 5
ask-monarch compound-inventory-search "TERM" --limit 5
ask-monarch personal-mail-status
ask-monarch personal-mail-search "TERM" --days 30 --limit 10
ask-monarch personal-mail-read GRAPH_MESSAGE_ID
ask-monarch personal-mail-draft --to person@example.com --subject "Subject" --body "Body"
ask-monarch personal-mail-reply-draft GRAPH_MESSAGE_ID --body "Reply body"
ask-monarch personal-mail-send-draft GRAPH_DRAFT_ID
ask-monarch csv-search "TERM" --name-like "optional.csv" --limit 5
ask-monarch sql "select ... from ... where ... limit 5"
ask-monarch sql "select ... from ... limit 5" --source presentations
ask-monarch sql "select ... from ... limit 5" --source teams_recaps
ask-monarch sql "select ... from units ..." --source company_profile
ask-monarch sql "select ... from units ..." --source people_directory
ask-monarch sql "select ... from pages/text_units/image_refs ..." --source company_context
ask-monarch sql "select ... from files/pages/text_units/image_refs/workbook_sheets/workbook_cells ..." --source scientific_refs
ask-monarch sql "select ... from paragraph_units ..." --source milestones_doc
ask-monarch sql "select ... from cells ..." --source compound_inventory
ask-monarch get UNIT_TYPE OBJECT_NAME SUB_ID
```

## Routing

- Route by the user's information need, not by the first artifact that matches the keywords. Before answering, classify the ask into the truth type it needs:
  - **Human observations/comments/notes:** metadata workbook comment or notes columns, docs, deck text, or Teams recaps depending on the artifact family.
  - **Run/existence/processing status:** objects, configs, source manifests, generated result folders, and upload/update timestamps.
  - **Quantitative result/effectiveness:** typed assay tables, structured CSV summaries, workbook result ledgers, and analysis outputs.
  - **Team discussion/decision:** Teams recaps, presentations, docs, and meeting-derived sources.
  - **Inventory/material facts:** `compound_inventory`, not experiment outputs.
- Treat user wording as intent, not as a literal source path, artifact name,
  table name, column name, source lane, or internal taxonomy. When literal
  terms miss or look weak, run the verified-index source-resolution loop:
  identify the likely fact type, search nearby indexed terms/tables/paths/fields
  that could hold that fact type, inspect representative schemas or atomic
  units, prove the mapping from SQLite rows with `provenance_grain`, then state
  the mapping explicitly. This applies across Ask Monarch: assays, videos, CSVs,
  workbooks, presentations, Teams recaps, milestones, PDFs, model artifacts,
  inventory rows, people/company facts, and future verified lanes.
- After the right verified row is found, resolve provenance into the most useful
  inspection artifact when the user wants to see or understand the evidence.
  For assay metric rows with matching raw media, prefer a synced overlay over a
  bare video: `advanced_metrics.csv` rows should use `assay-overlay` for
  `T*_avoidance`, and contact/non-contact `frame_metrics.csv` rows should use
  `assay-overlay` for `contact_pi` plus inside/on-band/outside counts. The
  overlay is an inspection artifact, not the answer source; the answer source
  remains the verified SQLite row and its `provenance_grain`.
- Do not call `T*_avoidance` values a preference index. For DART
  `advanced_metrics.csv`, `T*_avoidance` is an away-from-treatment fraction
  on a 0..1 scale. If the user asks for PI and only avoidance columns are
  present, state the avoidance value separately and derive a signed
  treatment-oriented PI only when the treatment side is verified from the
  assay workbook: `signed_treatment_PI = 1 - 2 * avoidance`, where negative
  means away from treatment and positive means toward treatment. If
  `T*_trt_PI` columns are present, use those directly and label them as signed
  treatment-oriented PI.
- For any calculation over assay metrics, cross-reference the metric definition
  PDF before deriving, averaging, converting, renaming, ranking, or explaining
  values. In the bucket lane, use
  `documentation/insect_assay_metrics_reference.pdf` as the definition source
  and cite the relevant `pdf_page` provenance alongside the result row/CSV
  provenance. Values come from the assay table or metric CSV; formulas,
  ranges, sign conventions, and interpretation come from the metric definition
  PDF. If the PDF does not define the requested metric or conversion, label the
  calculation as a derived proxy rather than an official metric.
- Use structured-first retrieval for any question asking for a fact that already lives in a table, directory, workbook, parsed source index, or known schema. This includes people/org lookup, rosters, counts, lists, comparisons, metric/ranking questions, inventory facts, source-inventory questions, and known entity lookup. Start with SQL or a source's structured natural-query helper, then use full-text search only as fallback or supporting context.
- Do not treat "structured-first" as only a ranking rule. Ranking questions are one example; the broader rule is that atomic structured truth beats natural search whenever the answer has a table/directory/workbook/schema home.
- Do not let a first relevant artifact become the whole answer. If a source family has root templates plus dated experiment copies, parent and child folders, or multiple parsed representations of the same underlying artifact, check the family members that normally carry the requested truth type before making a negative claim.
- For negative answers such as "no comments", "not tested", "not discussed", "not in inventory", or "no results", use a stricter standard than for positive answers:
  - Query each source class where that fact normally lives.
  - State the checked source classes or the most important checked locators.
  - Prefer "I do not see X in the checked sources" over an absolute "there is no X" unless the source contract is complete for that fact.
- Reconstruct rows by headers or neighboring cells when workbook schemas vary. Do not assume that a comment, notes, treatment, compound, concentration, or replicate field always lives in the same column across root templates, dated copies, or different assay workbooks.
- For assay, experiment, insect, compound, repellency, DART, preference index, bucket, image, video, CSV, workbook, PDF, and model questions, query the `bucket` source unless the user clearly asks for another source.
  - `csv_rows_with_provenance`
  - `csv_columns_with_provenance`
  - `json_units_with_provenance`
  - `text_lines_with_provenance`
  - `xlsx_cells_with_provenance`
  - `media_metadata_with_provenance`
  - `image_units`
  - `pdf_pages`
  - `model_metadata`
  - `objects`
- For compound-property questions, such as molecular weight, formula, SMILES, CID, InChIKey, XLogP, TPSA, complexity, hydrogen-bond counts, rotatable bonds, heavy-atom count, or "list the MWs of these compounds", route to the bucket QSAR and chemical-feature CSVs before inventory rows.
  - For stock/location/vendor/CAS questions with natural phrasing such as "do we have X", "where is X stored", or "who is the vendor for X", expect the hosted `compound_inventory` source to use `master_row_lookup`: strip inventory intent words, rank exact compound names ahead of near chemical-name matches, and return the full Master workbook row.
  - Inventory rows answer stock/location/vendor/CAS/SDS/quantity. They may confirm that a compound exists, but they do not make a molecular-weight answer complete unless they actually contain a molecular-weight field.
  - First inspect `csv_columns_with_provenance` for property columns such as `MolecularWeight`, `MW`, `MolecularFormula`, `SMILES`, `CID`, and related structural descriptors, then query matching `csv_rows_with_provenance` rows by compound name, synonym, abbreviation, or InChIKey.
  - Treat InChIKey as the best join key when the user provides one. If the InChIKey first appears in assay workbook metadata, reconstruct that workbook row or the key/abbreviation sheet to recover the compound abbreviation and full chemical name, then query QSAR/chemical-feature rows for the property.
  - For InChIKey/property lookups, prefer constrained exact searches over broad `row_json` scans: first identify QSAR source names and relevant property columns, then query those source names for the exact InChIKey or confirmed compound name.
  - Prefer exact compound-name matches from QSAR datasets such as `flies/summary/qsar/qsar_dataset.csv`, `mosquitoes/summary/qsar/qsar_dataset.csv`, `chemical_features_cache.csv`, or contact-repel QSAR tables. If multiple Monarch QSAR rows contain the same compound property, use them as an internal consistency check and mention conflicts if values differ.
  - When the user provides a screenshot or truncated list of compound names, infer cautiously, then confirm the full compound name against returned source rows before reporting the value.
  - For table-style answers, include the property value, formula or identifier when useful, and exact CSV row provenance for each compound.
- When the user refers to a CSV as displayed in Excel, Numbers, Sheets, or a screenshot, do not assume the app's visible row number equals `csv_rows_with_provenance.row_number`. The parsed CSV row number is the data row after the header; spreadsheet apps count the header as visible row 1. Therefore visible Excel row N usually maps to `csv_rows_with_provenance.row_number = N - 1` for ordinary single-header CSVs. Verify by checking nearby rows and visible field values before answering.
  - If the user says "window 13" or another semantic row key, use the CSV's `window`, `time_bin`, `time_min`, or equivalent field rather than visible spreadsheet row numbering.
  - If the user points at a screenshot row, align using the visible values in that row, then cite the underlying CSV provenance row used.
- For accuracy-report flagged-issue questions, such as "what were the flagged issues", "which tubes were warnings", or "what issues were flagged" for an experiment, do not assume the experiment title is unique.
  - If the user has recently shown or named a processed folder/file, anchor to that exact `accuracy_report.txt` or `accuracy_report.csv` path before using the experiment title. If no path context exists, list the matching processed runs and ask or state which one you are using.
  - Read the report's summary counts (`Tubes OK`, `Tubes WARNING`, `Tubes ERROR`) and the `FLAGGED ISSUES` section directly from `text_lines_with_provenance`. Prefer the explicit final flagged section lines over reconstructing warnings only from per-tube metric blocks.
  - Return tube id, issue text, and exact report line provenance. If there are no flagged issue lines after the `FLAGGED ISSUES` header, say that the report has no explicit flagged issues and cite the header/count lines.
  - For cross-run report questions such as "which processed fly experiments have flagged issues but zero errors?", use SQL over `text_lines_with_provenance` to join/report around `FLAGGED ISSUES`, `Tubes WARNING`, and `Tubes ERROR` lines. Do not expect natural keyword search to perform this aggregation.
  - For "most", "highest", "fewest", or other cross-run report ranking questions, use SQL aggregation over the relevant report lines and parse the numeric count from the line text. Do not trust truncated natural-search result order as a maximum or minimum.
- For knockdown event questions with a bare numeric value, especially a high-precision float like `3054.83904`, treat the value as likely event geometry (`cx` or `cy`) before treating it as a frame/time/window.
  - Query `knockdown/knockdown_events.csv` rows first. These rows keep geometry (`cx`, `cy`), timing (`start_frame`, `end_frame`, `start_time_s`, `end_time_s`, `duration_s`), status, tube, zone, side, region, and treatment together.
  - Once the matching event row is found, answer timing questions such as "when did the frame end" from `end_frame` in that same row; include `end_time_s` when useful. Do not mix the coordinate match from one row with timing fields from another artifact.
  - If exact `row_json like '%VALUE%'` across all knockdown rows is slow, first discover the relevant `knockdown_events.csv` source names and columns, then use constrained filename/date context or narrower numeric-prefix searches to find candidate rows before confirming the exact value.
  - If the user names an exact source row, such as "knockdown event row 12" or "row 12 in 2026-02-19 12-19-26", query that CSV by `row_number` directly and read treatment, side, zone, status, and timing from the returned `row_json`.
  - For unit questions about `start_time_s`, `end_time_s`, or `duration_s`, do not infer real seconds from the column name alone. Verify against source video metadata, FPS, or documentation if available; if matching media metadata/source video is absent, report the field value as the source column value and state the unit ambiguity/source gap.
- For fly repellency-screen trial metadata questions, such as "what solvent was used", "what concentration/dilution", "what was the treatment", "which side was treatment", or "what InChIKey" for a processed fly run, query `flies/repellency_screen_metadata_sheet.xlsx` before processed result CSVs.
  - In the `trials` sheet, reconstruct rows by header. Important columns include `B` filename, `N` treatment, `O` dilution, `P` solvent, `Q` left_condition, `R` right_condition, `S` treatment_position, and `T` inchikey.
  - For abbreviation or full-name questions, use the `key to chem names and abbrev` sheet in the same workbook. Column `A` is abbreviation, `B` is full chemical name, and `C` is InChIKey. Join this sheet to `trials` by abbreviation or InChIKey when the user asks what a short code such as `1O3OL` or `IPPE` means.
  - For fly video or DART-style wording that says "yeast", check the Jan 30-Feb 5 yeast+raspberry fly run family in this workbook before falling back to generic `flies/videos/` media. The relevant filenames include `2026-01-30 12-40-37.mp4`, `2026-02-02 11-29-32.mp4`, `2026-02-03 12-45-03.mp4`, `2026-02-04 12-15-46.mp4`, and `2026-02-05 11-40-25.mp4`; rows should show `context` / `left_condition` / `right_condition` values such as `yeast+rasp`, `Y+R+1O3OL`, or `Y+R+2PP`.
  - Use the processed folder timestamp to match the source video filename, for example processed folder `2026-02-05 12-52-51_results` maps to trial filename `2026-02-05 12-52-51.mp4` when present.
  - If a processed folder has no matching raw video object or media metadata, call that a source gap rather than inventing FPS, duration, or video linkage.
- For assay metric-definition or interpretation questions, such as "what does X track?", "why does X matter?", "value / condition", thresholds, entropy, response latency, stability, directionality, or output column meaning, query the bucket documentation first, especially `documentation/insect_assay_metrics_reference.pdf`, before using result CSVs or similarly named experiment-specific fields.
  - Keep metric definitions distinct from experiment summary fields. In particular, `response_latency_min` is the assay metric defined as the first time `|Centroid(t)|` exceeds the threshold, with default threshold 0.15 centroid units, measured in minutes; it is not the contact-repellency CSV field `latency_to_avoidance_sec`, which is measured in seconds and belongs to that specific processed video summary.
  - For `response_latency_min`, use the metric-reference value/condition bins: `< 2 min` means fast-acting or rapid behavioral onset; `2-10 min` means moderate onset; `> 10 min` or `NaN` means slow onset or sub-threshold response.
	  - When the user asks for both the value and condition, return the measured output-column value from the relevant assay row if present, classify it with the metric-reference bins, and cite both the assay row provenance and the metric-reference page.
- For questions that explicitly name `figure_guide.pdf`, `csv_data_dictionary.pdf`, "figure guide", "CSV data dictionary", or Cross-Experiment Aggregation reference docs, say that this stale Drive-PDF lane has been removed from the hosted source plane and cannot be used as Ask Monarch evidence until it is remapped, reparsed, receipted, and promoted again. Use the bucket lane only for current experiment outputs and source data rows, not for definitions from the stale PDFs.
- For questions about scientific literature, research papers, paper folders, chemical ecology, important receptors, olfactory/odorant receptors, receptor/pathway targets, modeling papers, high-throughput assay prototypes, ethoscope, Flywalk, scalability strategies, GLP labs, EPA registration-support workbooks, or the specific Teams-discussed journal articles that have been pulled into source, route to `scientific_refs` first.
  - This lane is scoped to Drive folder `1EzqtA9ABiW_pSWXUCp8s6Ow159_AatCo` and its curated public-journal sub-boundary; do not treat it as all Monarch literature, all Drive files, or all Teams-shared links.
  - Use it for external reference/literature context. Use `bucket` for primary Monarch experiment outputs and measured result facts.
- For phytotoxicity compound questions, especially "any comments", "phytotoxicity comments", "damage notes", "yellowing", "browning", or similar qualitative observations, check metadata workbooks before processed analysis artifacts:
  - Query `xlsx_cells_with_provenance` for both the root workbook `phytotoxicity/phytotoxicity_metadata_template.xlsx` and dated copies under `phytotoxicity/images/*/phytotoxicity_metadata_template.xlsx`.
  - Reconstruct the matching compound rows and inspect the row's comment/notes column. Do not answer "no comments" just because a dated copy has blank comments or because search results point first to analysis images.
  - Root and dated workbook layouts can differ. In the root template, beta-cyclocitral comments were in `Phytotoxicity!K`; in the April 13 dated copy, the comment header was `Phytotoxicity!L1`.
  - Processed outputs such as `damage_progression`, `deviation_maps`, `leaf_overlays`, `phenotype_maps`, `spot_overlays`, and `experiment_config_*.json` prove a run or analysis exists, but they are not a substitute for human comments in metadata cells.
  - Useful starting queries:

```bash
ask-monarch sql "select name, sheet, cell, row_number, value, provenance_grain from xlsx_cells_with_provenance where name in ('phytotoxicity/phytotoxicity_metadata_template.xlsx') and lower(value) like '%COMPOUND_TERM%' order by sheet, row_number, cell" --source bucket --limit 100
ask-monarch sql "select name, sheet, cell, row_number, value, provenance_grain from xlsx_cells_with_provenance where name like 'phytotoxicity/images/%/phytotoxicity_metadata_template.xlsx' and lower(value) like '%COMPOUND_TERM%' order by name, sheet, row_number, cell" --source bucket --limit 200
ask-monarch sql "select row_number, max(case when cell like 'A%' then value end) as col_a, max(case when cell like 'B%' then value end) as col_b, max(case when cell like 'C%' then value end) as col_c, max(case when cell like 'D%' then value end) as col_d, max(case when cell like 'E%' then value end) as col_e, max(case when cell like 'F%' then value end) as col_f, max(case when cell like 'G%' then value end) as col_g, max(case when cell like 'H%' then value end) as col_h, max(case when cell like 'I%' then value end) as col_i, max(case when cell like 'J%' then value end) as col_j, max(case when cell like 'K%' then value end) as col_k, max(case when cell like 'L%' then value end) as col_l from xlsx_cells where name='phytotoxicity/phytotoxicity_metadata_template.xlsx' and sheet='Phytotoxicity' and row_number in (<MATCHING_ROWS>) group by row_number order by row_number" --source bucket --limit 100
```
- For AI, computer-vision, machine-learning, model workflow, detection, segmentation, tracking, pose-estimation, YOLO, SAM, or "how does Monarch use AI" questions, query across all verified AI-relevant lanes rather than relying on bucket model metadata alone:
  - `bucket` for concrete model files, assay documents, phytotoxicity pipeline docs, processed video/image artifacts, and model metadata.
  - `presentations` for team-facing AI/computer-vision workflow content, including Monarch update decks such as the January 2, 2026 presentation.
  - `milestones_doc` for milestone narrative about screened chemicals, phytotoxicity progress, and model/pipeline work when relevant.
  - If the answer compares "AI" broadly with specific evidence, separate claims by source lane and cite each lane's provenance. Do not conclude that Monarch's AI work is only YOLO/model files unless presentation and milestone evidence has also been checked.
  - Useful starting queries:

```bash
ask-monarch search "AI computer vision model YOLO detection segmentation tracking pose SAM" --source presentations --limit 10
ask-monarch search "AI model computer vision YOLO segmentation phytotoxicity" --source milestones_doc --limit 10
ask-monarch search "yolo" --kind model_metadata --limit 10
ask-monarch search "computer vision YOLO segmentation detection" --kind pdf_page --limit 10
```

- For "today", "yesterday", "Friday", "this week", "last 2 weeks", "new experiments", or "what experiments were run/uploaded" questions, resolve the relative date into an absolute date in the answer and distinguish three clocks:
  - `run` / `experiment date`: rows in `dart_assay_results.assay_date`.
  - `uploaded`, `processed`, or `new data`: rows in `objects.updated` / `objects.time_created`.
  - Meeting discussion: `teams_recaps`, only when the user asks what the team discussed.
  If the assay ledger has no rows dated the target day but bucket objects were updated that day, do not answer "nothing happened." Say: "I do not see assay ledger rows dated DATE, but I do see new/updated source objects on DATE," then summarize the uploads by top folder and kind with provenance.
- For presentation, deck, slide, company update, "latest presentation", "most recent presentation", storyboard, or R&D update questions, query the `presentations` source.
  - `ask-monarch presentations-search "TERM" --limit 5`
  - `ask-monarch search "TERM" --source presentations --limit 5`
  - `ask-monarch query "QUESTION" --source presentations --limit 5`
  - `ask-monarch sql "select ... from decks/slide_units/media_refs ..." --source presentations`
  - Tables: `decks`, `slide_units`, `media_refs`, `source_status`, `gaps`
  - Presentation provenance grain must include Google Drive file id, slide number when applicable, text or media unit index, locator, and modified time.
- For Monarch R&D Teams recap, meeting transcript, meeting recording, decision, action-item, discussion, or "what did R&D cover" questions, query the `teams_recaps` source.
  - `ask-monarch teams-recaps-search "TERM" --limit 5`
  - `ask-monarch search "TERM" --source teams_recaps --limit 5`
  - `ask-monarch query "QUESTION" --source teams_recaps --limit 5`
  - `ask-monarch sql "select ... from meetings/utterances ..." --source teams_recaps`
  - Tables: `meetings`, `utterances`, `gaps`, `source_metadata`, `utterances_fts`
  - Teams recap provenance grain must include meeting date, speaker, timestamp, utterance id, locator, and transcript version time.
- For mission, problem, status quo, approach, headquarters, "what does Monarch do", insects Monarch works with, crop species, crop testing, or high-level company profile questions, query the `company_profile` source.
  - `ask-monarch company-profile-search "TERM" --limit 5`
  - `ask-monarch search "TERM" --source company_profile --limit 5`
  - `ask-monarch query "QUESTION" --source company_profile --limit 5`
  - `ask-monarch sql "select ... from units ..." --source company_profile`
  - Tables: `units`, `gaps`, `source_metadata`, `units_fts`
  - Company profile provenance grain must include the JSON source path, unit id, source id, and version.
- For employees, advisors, people, CTO, lab tech, team, "who works at Monarch", or partnership questions, query the `people_directory` source.
  - For complete rosters, use natural query or exact SQL, not `people-search`.
  - `ask-monarch query "who works at Monarch?" --limit 50`
  - `ask-monarch sql "select name, role, text, provenance_grain from units where lane = 'employees' order by name" --source people_directory --limit 50`
  - `ask-monarch sql "select name, role, text, provenance_grain from units where lane = 'advisors' order by name" --source people_directory --limit 50`
  - Use `ask-monarch people-search "TERM" --limit 5` only for lookup/search, not complete roster answers.
  - Tables: `units`, `gaps`, `source_metadata`, `units_fts`
  - People directory provenance grain must include the JSON source path, unit id, source id, and version.
- For questions about company context sourced from the `Monarch_for_askmonarch.pdf` intake evidence, including residues, market context, glossary terms, product risks, SWD opportunity, or deck-derived historical claims, query the `company_context` source.
  - `ask-monarch company-context-search "TERM" --limit 5`
  - `ask-monarch search "TERM" --source company_context --limit 5`
  - `ask-monarch query "QUESTION" --source company_context --limit 5`
  - `ask-monarch sql "select ... from pages/text_units/image_refs ..." --source company_context`
  - Tables: `deck`, `pages`, `text_units`, `image_refs`, `gaps`, `source_metadata`, `deck_fts`
  - Deck provenance grain must include the PDF source path, page number when applicable, unit id, locator, and modified time.
  - This is not a deck lane. It is company context derived from PDF intake evidence and must not override `people_directory` for current employee/advisor truth.
- For questions about the `monarch_milestones` Google Doc, milestone narrative, February-April 2026 progress summary, phytotoxicity milestones, mode of action, contact versus non-contact assays, 62 screened chemicals, or colony setup milestones, query the `milestones_doc` source.
  - `ask-monarch milestones-search "TERM" --limit 5`
  - `ask-monarch search "TERM" --source milestones_doc --limit 5`
  - `ask-monarch query "QUESTION" --source milestones_doc --limit 5`
  - `ask-monarch sql "select ... from paragraph_units ..." --source milestones_doc`
  - Tables: `source_metadata`, `paragraph_units`, `paragraph_units_fts`
  - Milestones provenance grain must include document id, revision id, tab id, paragraph index, start/end indexes, and locator.
  - This is a document-revision snapshot and does not override current assay, people, or operational source lanes.
- For compound inventory, chemical inventory, stock, location, CAS, vendor, SDS, or inventory-status questions that clearly refer to the Monarch chemical inventory workbook, query `compound_inventory`.
  - `ask-monarch compound-inventory-search "TERM" --limit 5`
  - `ask-monarch search "TERM" --source compound_inventory --limit 5`
  - `ask-monarch query "QUESTION" --source compound_inventory --limit 5`
  - `ask-monarch sql "select ... from workbook/sheets/cells/tables ..." --source compound_inventory`
  - Tables: `workbook`, `sheets`, `cells`, `tables`, `gaps`, `source_metadata`, `cells_fts`
  - Truth path: `compound_chemical_inventory.xlsx`, usually the `Master` sheet. `Master!D` is compound `Name`; `Master!A:K` are Vendor, Catalog Number, Location/Bin, Name, inchikey, Synonyms, Quantity, CAS, Purity, link, SDS.
  - For "what compounds does Monarch have?", count/list from nonblank `Master!D` cells. Summarize counts and representative names unless the user asks for the full list/export.
  - For "do we have X?", search `Master!D` compound names and `Master!F` synonyms before falling back to fuzzy `compound-inventory-search`.
  - For "where is X?" or vendor/CAS/SDS/quantity questions, return the full `Master` row fields for the matched compound with cell-level provenance.
  - For location questions like fridge, freezer, room temp, flammables, acids, or bases, use the corresponding storage sheet as supporting evidence but prefer `Master` when it has the needed inventory fields.
  - Cell provenance grain must include workbook source id, sheet name, cell address, workbook modified time, and locator.
  - The current parsed source is the attached workbook copy. The original SharePoint link still needs Monarch-tenant connector access for future live refreshes.
- For broad company-memory questions where the right source is unclear, query `ask-monarch summary` first, then search the likely source(s). If a useful answer may span bucket, presentations, Teams recaps, company profile, people directory, company context, scientific refs, milestones, and compound inventory, query the relevant lanes and separate evidence by source.
- Preserve the user's business/research question. If the user asks a follow-up like "what about before that" or "show more like this", rewrite it into a standalone Monarch question using the visible prior answer as context, then query the source plane again.
- If the question is not answerable from the parsed source, say that plainly and include the closest query attempts. Do not improvise.
- The local repo path `/Users/josh/projects/ask-monarch` remains the development/admin fallback, but do not use it for ordinary user-facing answers unless the hosted service is intentionally unavailable and the user explicitly asks for the local path.

## Deep Research Max Mode

- Use Gemini Deep Research Max only when the user explicitly asks for deep research, literature comparison, external validation, market/context research, or a long-form report.
- Do not use Deep Research Max for ordinary exact source questions. For those, query the verified source indexes directly.
- Deep Research Max mode first builds a Monarch evidence bundle from verified company memory, then sends that evidence bundle to Gemini Deep Research Max. The bundle must cover every shared verified source lane, currently `bucket`, `presentations`, `teams_recaps`, `company_profile`, `people_directory`, `company_context`, `scientific_refs`, `milestones_doc`, and `compound_inventory`. Relevance affects row selection, not lane coverage:

```bash
python3 scripts/deep_research_monarch.py "RESEARCH QUESTION"
GEMINI_API_KEY=... python3 scripts/deep_research_monarch.py "RESEARCH QUESTION" --launch --wait
python3 scripts/deep_research_monarch.py --approve-plan PLAN_INTERACTION_ID --wait
python3 scripts/deep_research_monarch.py --poll-id INTERACTION_ID --out-dir reports/deep-research/RUN_DIR
```

- The default agent is `deep-research-max-preview-04-2026`.
- Visualization is enabled with `visualization=auto`.
- Collaborative planning is enabled by default. Use the returned plan interaction id with `--approve-plan` to start the final research run.
- Reports are written under `/Users/josh/projects/ask-monarch/reports/deep-research/`.
- Internal Monarch claims in Deep Research outputs still require exact provenance from the evidence bundle.
- Personal mailbox overlays are excluded unless promoted to a shared verified source lane.

## Answer Rules

- Answer only from rows returned by the Monarch query plane.
- Cite exact `provenance_grain` for every factual claim that depends on the source.
- A generic citation such as "from the bucket" is not enough. Use the exact object, row/page/cell/path/metadata grain and locator.
- Treat `source_actions` as inspectable provenance affordances, not as answer evidence. They are safe to mention when useful: "I can open the cited video/deck/slide/transcript/CSV/workbook/PDF source." The answer itself must still come from the verified SQLite3 rows and their `provenance_grain`.
- Use `ask-monarch resolve-source --locator ... --open` when the user asks to inspect or open a returned source action that is not already covered by a more specific command such as `assay-media` or `presentation`.
- If the answer requires current bucket freshness beyond the last parse timestamp, say that a source refresh is needed before answering current-state claims.
- If the answer requires current-state truth from any hosted lane, treat `config/source-enforcement.json` plus `scripts/verify_source_enforcement.py` as the freshness contract. Scheduled lanes must have their declared refresh job passing; event-driven lanes must have clean receipts and hosted health for the declared source version.
- Do not dump raw JSON or CLI syntax unless the user asks for raw output or implementation details. Summarize the value, but keep the provenance exact.
- Do not share `trace_id`, `trace_span_id`, `trace_project`, `trace_url`, Braintrust URLs, or other run/debug trace metadata unless the user explicitly asks for a trace, `/trace`, Braintrust review, or run debugging. Treat trace metadata as observability, not answer provenance.
- If source rows conflict, say so and show the conflicting provenance grains.

## Useful Query Patterns

For animal-use counts in mosquito DART assays, use the experiment ledger, not video/frame CSV summaries:

```bash
ask-monarch sql "select count(*) as assay_rows, sum(cast(value as real)) as mosquitoes from xlsx_cells_with_provenance where name='mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx' and sheet='Assays' and cell like 'J%' and row_number >= 2 and trim(value) <> ''"
```

- Column `J` in `mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx`, sheet `Assays`, is `n_mosquitoes`.
- Do not answer "how many mosquitoes have we used" from CSV frame rows, contact-repel `mean_n_total`, or detected-object summaries unless the user explicitly asks for video-derived detections.

For recent experiment/activity questions:

```bash
# Experiment rows actually dated for a target day. Convert 2026-04-28 to ledger date 4282026.
ask-monarch sql "select assay_date, species, assay_type, count(*) as assay_rows, sum(coalesce(n_insects_real,0)) as insects, group_concat(distinct treatment_normalized) as treatments from dart_assay_results where assay_date = '4282026' group by assay_date, species, assay_type order by species, assay_type" --source bucket --limit 50

# Source objects uploaded or updated on a target ISO date.
ask-monarch sql "select substr(updated,1,10) as updated_date, top_folder, kind, count(*) as objects from objects where substr(updated,1,10) = '2026-05-02' group by updated_date, top_folder, kind order by objects desc" --source bucket --limit 100

# Concrete updated source objects for that date.
ask-monarch sql "select name, kind, size, updated, uri from objects where substr(updated,1,10) = '2026-05-02' order by updated desc limit 50" --source bucket --limit 50
```

- For "what experiments were run today?", lead with the assay ledger result for the absolute date.
- If the user says new data was uploaded, or asks what was uploaded/processed today, use `objects.updated` and summarize by `top_folder` and `kind`.
- If the ledger and object-updated views disagree, explain the mismatch: experiment run date and upload/processing date are different clocks.
- Do not route date-based experiment questions to Teams recaps unless the user asks what people said or discussed.

For DART assay effectiveness or best-concentration questions, use the typed `dart_assay_results` research table before broad search or workbook-cell reconstruction:

```bash
ask-monarch query "what is the most effective concentration for 2-propylphenol in the mosquito DART assays?" --limit 5
ask-monarch sql "select treatment_normalized, dilution, count(*) as scored_rows, avg(avg_pi_real) as mean_avg_pi, min(avg_pi_real) as best_single_avg_pi from dart_assay_results where species='mosquitoes' and treatment_normalized='2PP' and avg_pi_real is not null group by treatment_normalized, dilution_real order by mean_avg_pi asc" --limit 10
```

- `dart_assay_results` is derived from `mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx`, sheet `Assays`, and preserves row-level provenance plus source-cell locators.
- For 2-propylphenol, normalize user terms like `2-propylphenol` or `2PP` to treatment `2PP`.
- Do not start DART effectiveness questions with broad `csv-search`; it can scan too much source data and add avoidable latency.

For "show me the video", "pull up the assay video", "open the raw video", or
similar requests after an assay answer, use the explicit media-link path. First
identify the exact source-grade assay row or filename from the verified index,
then resolve/open media:

```bash
ask-monarch assay-media --row 1255 --source-name mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx --sheet Assays --limit 5
ask-monarch assay-media --row 1255 --source-name mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx --sheet Assays --open
```

- `assay_media_links` is a derived bridge from source-grade assay rows, or
  indexed video metadata when no typed ledger row exists yet, to exact `gs://`
  raw assay videos.
- This is the explicit raw-artifact exception: ordinary answers still come from
  verified SQLite indexes; the raw video is opened only after the provenance
  path has identified the associated media.
- If `ask-monarch assay-media` returns no rows, do not claim the video can be
  opened. Check the returned `diagnostics` when present. If it contains
  `assay_rows` and `related_objects` but `raw_video_missing: true`, say exactly
  that the assay row and processed outputs are indexed, but the raw video object
  is not in the verified media index yet. Cite the assay row and representative
  processed object locators. Treat this as a media source gap, not as a failed
  assay lookup.
- Use it for any assay family in the derived bridge: DART, mini-DART,
  choice/no-choice, cage assays, contact/repellency, and future assay-video
  lanes.

For animal-use counts in fly repellency assays, use the fly trial ledger:

```bash
ask-monarch sql "select count(*) as assay_rows, sum(cast(value as real)) as flies from xlsx_cells_with_provenance where name='flies/repellency_screen_metadata_sheet.xlsx' and sheet='trials' and cell like 'K%' and row_number >= 2 and trim(value) <> ''"
```

- Column `K` in `flies/repellency_screen_metadata_sheet.xlsx`, sheet `trials`, is `n_flies`.
- Do not answer "how many flies have we used" from CSV frame rows, detected-object summaries, or per-frame tracking output unless the user explicitly asks for video-derived detections.

For broad indexed search:

```bash
ask-monarch search "Preference Index" --kind pdf_page --limit 5
ask-monarch search Machilidae --kind image --limit 5
ask-monarch search yolo --kind model_metadata --limit 5
```

For presentation/deck questions:

```bash
ask-monarch summary
ask-monarch sql "select title, deck_date, slide_count, text_unit_count, media_ref_count, modified_time, provenance_grain from decks order by deck_date desc limit 1" --source presentations --limit 1
ask-monarch sql "select slide_number, unit_type, unit_index, text, locator, provenance_grain from slide_units where file_id='<DECK_FILE_ID>' order by slide_number, unit_type, unit_index" --source presentations --limit 200
ask-monarch presentations-search "2PP" --limit 5
ask-monarch search "damage" --source presentations --limit 5
```

- Do not make the user know the CLI source flag. If they ask through `$askmonarch` about a presentation, route to `--source presentations` yourself.
- "Most recent presentation" means the deck with the highest `deck_date` in `decks`, unless the user asks for most recently modified.
- Distinguish "latest deck by deck date" from "latest modified file" if those differ.

For company profile questions:

```bash
ask-monarch company-profile-search mission --limit 5
ask-monarch search "what insects does Monarch work with" --source company_profile --limit 5
ask-monarch sql "select unit_id, lane, title, text, provenance_grain from units order by unit_id" --source company_profile --limit 20
```

For people, employee, advisor, and partnership questions:

```bash
ask-monarch query "who works at Monarch?" --limit 50
ask-monarch sql "select name, role, lane, text, provenance_grain from units where lane = 'employees' order by name" --source people_directory --limit 50
ask-monarch people-search Avinash --limit 5
ask-monarch sql "select name, role, lane, text, provenance_grain from units order by lane, name" --source people_directory --limit 50
```

- `people-search` is relevance search. Do not use it as the final answer for "who works at Monarch?", "list the employees", "show the team", or other complete roster questions.
- Complete roster questions require `ask-monarch query "who works at Monarch?"` or the exact `units where lane = 'employees'` SQL.

For compound inventory questions:

```bash
ask-monarch sql "select count(*) as inventory_rows, count(distinct trim(value)) as distinct_compound_names from cells where sheet_name='Master' and column_name='D' and row_number > 1 and trim(coalesce(value,'')) <> ''" --source compound_inventory --limit 5
ask-monarch sql "select value as compound, cell, provenance_grain from cells where sheet_name='Master' and column_name='D' and row_number > 1 and trim(coalesce(value,'')) <> '' order by lower(value) limit 50" --source compound_inventory --limit 50
ask-monarch sql "select row_number, max(case when column_name='A' then value end) as vendor, max(case when column_name='B' then value end) as catalog_number, max(case when column_name='C' then value end) as location_bin, max(case when column_name='D' then value end) as name, max(case when column_name='F' then value end) as synonyms, max(case when column_name='G' then value end) as quantity, max(case when column_name='H' then value end) as cas, max(case when column_name='I' then value end) as purity, max(case when column_name='J' then value end) as link, max(case when column_name='K' then value end) as sds from cells where sheet_name='Master' and row_number in (select row_number from cells where sheet_name='Master' and column_name in ('D','F') and lower(value) like '%2-propylphenol%') group by row_number order by row_number" --source compound_inventory --limit 20
```

- The inventory count answer should come from `Master!D`, not from the experiment bucket or search snippets.
- The current parsed receipt has 905 nonblank `Master!D` inventory rows and 873 distinct compound names.
- Do not dump hundreds of compound names into chat unless the user explicitly asks for the full list; offer a focused list, count, or export-shaped table.
- For exact compound lookup, cite the `Name` cell and any returned field cells used in the answer.
- If the user asks for live current inventory beyond the parsed workbook snapshot, say the source may need refresh from the Monarch SharePoint workbook.

For the Monarch_for_askmonarch PDF deck:

```bash
ask-monarch company-context-search glossary --limit 5
ask-monarch search "USDA Insecticide Residue Report" --source company_context --limit 5
ask-monarch sql "select page_number, unit_index, text, provenance_grain from text_units where text like '%USDA%' order by page_number, unit_index" --source company_context --limit 20
```

For the Monarch milestones Google Doc:

```bash
ask-monarch milestones-search "62 chemicals" --limit 5
ask-monarch query "phytotoxicity milestones" --source milestones_doc --limit 5
ask-monarch sql "select paragraph_index, text, provenance_grain from paragraph_units order by paragraph_index" --source milestones_doc --limit 30
```

For CSV row facts:

```bash
ask-monarch csv-search IR3535 --name-like combined_results.csv --limit 5
```

For exact calculations, use read-only SQL against provenance views:

```bash
ask-monarch sql "select name, row_number, row_json, provenance_grain from csv_rows_with_provenance where row_json like '%IR3535%' limit 5"
```

For exact unit retrieval:

```bash
ask-monarch get pdf_page "documentation/insect_assay_metrics_reference.pdf" 1
ask-monarch get csv_row "contact_repel_videos/mosquitoes/processed/combined_results.csv" 33
```

## Output Shape

Use this shape unless the user asks for raw rows:

```text
Answer:
...

Evidence:
- ...

Provenance:
- grain_type: ...
  locator: ...
  version_or_modified_time: ...

Limits:
...
```

## Answer Quality

- For composed factual answers, answer the user's actual question, not just the closest keyword hit. Include every requested count, role, compound field, date, or status when the evidence supports it.
- Cite source rows with provenance for each material claim. If the answer combines multiple source lanes, keep the claims separated by lane so the user can see what came from where.
- For broad questions such as "how does Monarch use AI?", check the relevant source lanes instead of letting one matching artifact dominate the answer.
- For negative answers and source gaps, name the checked queryable sources and prefer "I do not see this in the checked sources" over absolute claims. If the artifact class is not yet queryable, say it is not yet Ask Monarch-queryable.
- If an answer-quality failure is corrected, add or tighten a case in `evals/askmonarch_answer_quality_cases.json` and run `python3 scripts/verify_askmonarch_answer_quality.py` so the failure, reason, correction, and verification command appear in the HTML ledger.
