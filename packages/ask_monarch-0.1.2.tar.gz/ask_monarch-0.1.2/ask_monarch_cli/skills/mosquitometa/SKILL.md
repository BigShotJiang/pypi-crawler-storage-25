---
name: mosquitometa
description: Update the Ask Monarch mosquito DART metadata workbook for new `gs://monarch-videos-new/mosquitoes/videos/` files. Use when the user invokes `/mosquitometa`, asks to update mosquito metadata, or asks about the daily 5 PM mosquito metadata automation.
---

# Mosquito Metadata

This is an Ask Monarch operational skill. It updates the shared mosquito DART
metadata workbook:

```text
gs://monarch-videos-new/mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx
```

## Contract

- Keep one shared metadata workbook for mosquito DART videos.
- Add three `Assays` rows per new video, one for each tube.
- Read videos from:

```text
gs://monarch-videos-new/mosquitoes/videos/
```

- Preserve the workbook's existing sheet structure, headers, formatting, and row
  pattern.
- Do not create separate metadata files for individual videos.
- Use the Monarch compound inventory as the source of truth for InChIKey values.
  Specifically, resolve chemical names from the hosted Ask Monarch
  `compound_inventory` source, `Master` sheet, chemical-name column `D`, and
  InChIKey column `E`.
- If a chemical treatment cannot be resolved to an InChIKey from
  `compound_inventory`, fail closed and do not upload a guessed workbook.

## Daily Automation

The daily job is installed through macOS launchd:

```text
~/Library/LaunchAgents/com.ask-monarch.mosquitometa.daily.plist
```

It runs at 5:00 PM local machine time and calls:

```bash
mosquitometa
```

Run logs are written to:

```text
~/.codex/logs/mosquitometa/
```

On teammate machines, the current Ask Monarch setup path is:

```bash
uvx ask-monarch setup --code MNR-BUSE-U8E8
```

That setup should install both:

```text
~/.codex/skills/mosquitometa/SKILL.md
~/.local/bin/mosquitometa
```

The terminal command runs the same Ask Monarch-owned updater from:

```text
~/.local/share/ask-monarch/scripts/update_mosquito_metadata.py
```

Teammates need normal Ask Monarch access plus `gcloud` access to
`gs://monarch-videos-new`.

## Manual Commands

Dry run without uploading:

```bash
mosquitometa --dry-run --output ~/Downloads/mosquito-meta-dry-run.xlsx
```

Live update with backup and upload:

```bash
mosquitometa
```

Load or reload the schedule:

```bash
launchctl unload ~/Library/LaunchAgents/com.ask-monarch.mosquitometa.daily.plist 2>/dev/null || true
launchctl load ~/Library/LaunchAgents/com.ask-monarch.mosquitometa.daily.plist
```

Check whether launchd knows about the job:

```bash
launchctl print gui/$(id -u)/com.ask-monarch.mosquitometa.daily
```

## Current Defaults

The script uses these defaults unless overridden with environment variables or
CLI flags:

- temperature: `25.1`
- relative humidity: `49`
- dilution: `0.01`
- solvent: `DPG`

The script fills temperature and humidity on every new May/day row it creates.
It fills dilution, solvent, and InChIKey only for chemical treatment rows.
Controls keep those chemistry fields blank, matching the existing workbook
pattern.

## Known Treatment Mapping

Filename treatment tokens are mapped to chemical inventory names before
InChIKey lookup:

- `nPhform` -> `N-phenylformamide`
- `nCHform` -> `N-cyclohexylformamide`

Add new mappings only when the chemical identity is backed by Monarch source
evidence. Do not use PubChem, web search, or general chemistry knowledge as the
primary source for the workbook InChIKey.
