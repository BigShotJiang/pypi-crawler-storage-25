---
name: braintrust
description: Use when inspecting, verifying, or extending Ask Monarch Braintrust traces, spans, project logs, evals, prompts, or `bt` CLI setup.
---

# Braintrust For Ask Monarch

Use this skill for Ask Monarch observability work in Braintrust.

## Project Context

- Braintrust org/profile: `Andes`
- Braintrust project: `ask-monarch`
- Project id: `28216333-66fb-42a6-923b-622bda7a2fcc`
- Repo config: `.bt/config.json`
- Runtime tracer: `scripts/braintrust_tracing.py`
- HTTP trace wrapper: `scripts/serve_http.py`
- CLI trace helpers: `scripts/ask_monarch.py`

## Contract

- Prefer the `bt` CLI over direct API calls for project, trace, log, prompt, and setup inspection.
- Use `--json` for anything that will be parsed or cited.
- Do not print `BRAINTRUST_API_KEY`.
- A query is fully wired only when the runtime response includes `trace_id` and Braintrust can read back the trace.
- Ask Monarch tracing must fail open: missing Braintrust SDK or API key must not break source queries.

## Common Commands

```bash
bt status --json
bt setup doctor --local --json --profile Andes
bt view trace --object-ref project_logs:28216333-66fb-42a6-923b-622bda7a2fcc --trace-id TRACE_ID --json --profile Andes --prefer-profile
ask-monarch trace-url TRACE_ID
ask-monarch --open-trace query "what does Monarch do?" --source company_profile --limit 5
```

## Verification Pattern

1. Run a real Ask Monarch query through the intended surface.
2. Confirm the response includes `trace_id`, `trace_project`, `trace_project_id`, and `trace_url`.
3. Read the trace back with `bt view trace`.
4. Confirm the trace has the expected span shape:
   - `ask_monarch.query`
   - `trace.user_question`
   - `trace.tool_call.1.ask_monarch_source_query`
   - `trace.selected_evidence`
   - `trace.source_receipts`
   - `trace.final_answer`

## Local Docs

Detailed Braintrust docs fetched by `bt setup` live under `.bt/skills/docs/`.
Load only the relevant section when needed, usually:

- `.bt/skills/docs/instrument/trace-application-logic.md`
- `.bt/skills/docs/observe/examine-traces.md`
- `.bt/skills/docs/reference/sql.md`
