---
name: monarch-source
description: "Use for Ask Monarch source work: onboarding Monarch artifacts, checking whether Monarch sources are mapped, parsed, receipted, refreshed, wired to ask-monarch, or correcting source-routing gaps for Monarch company memory."
---

# Monarch Source

Use `monarch-source` for Ask Monarch source onboarding and source-status work.
This skill is intentionally separate from `just-source` so Monarch and Just
source lanes, freshness rules, and CLIs do not leak into each other.

## Ask Monarch Contract

An artifact is not Ask Monarch source-grade because it exists in Google Cloud,
Drive, Teams, SharePoint, a repo folder, or a screenshot. It becomes source-grade
only when its declared boundary is mapped, accessible, atomically queryable with
`provenance_grain`, receipted, and wired through the hosted `ask-monarch` API/CLI.

Ordinary answers should not query raw Monarch artifacts directly unless an
explicit exception was made. Raw artifacts are upstream evidence. The ask surface
is `ask-monarch` calling the hosted API, which reads verified SQLite3
`source_index.sqlite` files on the `ask-monarch-server` VM under
`/home/josh/ask-monarch/artifacts/.../`. Local SQLite is for
development/rebuild verification unless the user explicitly asks for local
inspection.

## Artifact Lanes

Classify the artifact before answering a source-status question:

| Artifact class | Source lane | Notes |
| --- | --- | --- |
| GCS experiment bucket, assay outputs, images, videos, PDFs, model files | `bucket` | Primary `gs://monarch-videos-new` lane. Freshness depends on VM daily ingest. |
| 2026 update decks / Storyboards presentations | `presentations` | Google Drive decks from January 1, 2026 onward. |
| Monarch recurring meeting recaps/transcripts | `teams_recaps` | Parsed recurring R&D, Weekly, and Team Sync recaps in the combined hosted Teams index. |
| Company profile facts | `company_profile` | Repo-owned JSON source. |
| People, advisors, partnerships | `people_directory` | Repo-owned JSON source. |
| `Monarch_for_askmonarch.pdf` intake context | `company_context` | PDF pages, text blocks, and image refs. |
| Cross-experiment aggregation Figure Guide / CSV Data Dictionary | retired source gap | Removed from hosted source plane because the mapped Drive PDFs are stale. Remap, parse, receipt, and promote again before using as evidence. |
| Scoped scientific/reference library | `scientific_refs` | Literature PDFs and support workbooks across chemical ecology, receptors/pathways, modeling, assay prototypes, scalability, EPA registration-support sub-boundaries, plus explicitly pulled public journal PDFs discussed in Monarch R&D Teams recaps. |
| Monarch milestones Google Doc | `milestones_doc` | One fetched document revision, paragraph-grain. |
| Compound / chemical inventory workbook | `compound_inventory` | Parsed workbook copy; original SharePoint live refresh still needs tenant access. |
| Josh's Monarch mailbox | private personal overlay | Live Microsoft Graph access only when a Josh-only personal token is mapped. Not shared SQLite and not shared company memory. |

If an artifact does not fit a lane, treat it as a new lane candidate or explicit
source gap. Do not silently fold it into a semantically nearby lane.

## Source Checks

Use the hosted CLI for source proof:

```bash
ask-monarch summary
ask-monarch query "real question" --source SOURCE --limit 5
ask-monarch search "TERM" --source SOURCE --limit 5
ask-monarch sql "select ... limit 20" --source SOURCE
```

For deck, document, meeting, workbook, model, image, video, or assay questions,
inspect atomic units, not only top-level metadata.

Common lane-specific tables:

- `bucket`: `objects`, `dart_assay_results`, `assay_media_links`, `csv_rows_with_provenance`, `xlsx_cells_with_provenance`, `pdf_pages`, `image_units`, `model_metadata`.
- `presentations`: `decks`, `slide_units`, `media_refs`, `source_status`, `gaps`.
- `teams_recaps`: `meetings`, `utterances`, `gaps`, `source_metadata`.
- `company_profile`, `people_directory`: `units`, `gaps`, `source_metadata`.
- `company_context`: `pages`, `text_units`, `image_refs`, `gaps`, `source_metadata`.
- `scientific_refs`: `files`, `pages`, `text_units`, `image_refs`, `workbook_sheets`, `workbook_cells`, `gaps`, `source_metadata`.
- `milestones_doc`: `paragraph_units`, `source_metadata`.
- `compound_inventory`: `workbook`, `sheets`, `cells`, `tables`, `gaps`, `source_metadata`.

## Universal Enforcement

All hosted source lanes must have the same hard enforcement loop:

- The lane is declared in `config/source-enforcement.json`.
- Local artifacts include `source_index.sqlite`, `source_status.json`, `source_receipt.json`, and `gaps.json`.
- `source_status.gap_count` is zero, `gaps.json` is clean, and hosted `ask-monarch health --deep` is ok for the lane.
- Scheduled lanes have an installed refresh job. Current scheduled jobs are VM `ask-monarch-refresh.timer` for `bucket`, launchd `com.ask-monarch.drive-refresh` for `presentations` and `scientific_refs`, and launchd `com.ask-monarch.teams-refresh` for `teams_recaps`.
- Event-driven lanes have an explicit source-change policy and must be reparsed/promoted when their repo JSON, PDF, Google Doc revision, or workbook copy changes.
- `scripts/verify_source_enforcement.py` is installed as launchd job `com.ask-monarch.enforcement-verify` and must pass after refresh windows. A failed fetch, parse gap, hosted upload failure, service restart failure, remote CLI verification failure, missing scheduled job, or nonzero verifier result means the source freshness contract was not met.

## Four Gates

When asked "is this sourced?" answer:

1. **Mapped:** present in `config/source-map.yaml`, docs, receipts, or spec.
2. **Accessible:** current service path can fetch or inspect it.
3. **Atomically queryable:** smallest useful units exist with `provenance_grain`.
4. **Ask-surface wired:** hosted API and `ask-monarch` CLI can answer using the explicit `--source` value.

Only call a Monarch source "ready" when all four gates pass.

## Daily Ingest

For `gs://monarch-videos-new`, freshness depends on the VM refresh path:

```text
ask-monarch-refresh.timer
-> ask-monarch-refresh.service
-> scripts/refresh_source_index.py --incremental --no-restart
```

The job enumerates the live bucket, detects added/changed/deleted objects,
parses invalidated objects, rebuilds derived tables and search indexes, verifies
coverage, and swaps staged artifacts into the live path only if verification
passes.

`assay_media_links` is the explicit raw-media bridge. It links source-grade assay
records, or indexed video metadata when no typed ledger row exists yet, to exact
`gs://` assay videos so a user can ask to pull up the video associated with an
answer. That is different from ordinary answering: answer from verified source
indexes first, then use the media link only when the user asks to open the
associated raw video.

If an assay row and processed outputs exist but no raw video object exists in
`assay_media_links` or `media_metadata`, do not treat that as "not sourced."
The assay is sourced; the raw media open path has a gap. The API should expose
that distinction through `assay_media` diagnostics, and agents should say the
raw video is not openable from the verified media index yet.

Failure rule:

```text
failed refresh -> no swap -> previous verified source_index.sqlite remains live
```

If the user asks about brand-new bucket uploads or current bucket state, check
freshness. Do not claim current bucket truth from stale parsed artifacts.

## Presentation Freshness

For the scoped Google Drive `presentations` lane, freshness depends on a daily
post-midnight refresh:

```text
00:25 America/Los_Angeles every day
-> enumerate Storyboards_Presentations
-> update config/storyboards-presentations-2026-files.json for new/changed in-boundary decks
-> run scripts/parse_storyboards_presentations.py
-> verify source_status.json and source_receipt.json
```

This applies only to the mapped 2026 presentation lane. It does not make all
Google Drive files source-grade. If the daily midnight refresh has been missed,
do not answer "latest presentation" or current deck-inventory questions from the
parsed presentations index until Drive has been refreshed.

## Ask Surface Wiring

For a new Monarch lane, finish all of these:

- Add/update the source map or manifest with canonical lane, boundary, parser, artifact paths, freshness rule, query plane, and helper.
- Build or refresh atomic source artifacts and receipts.
- Deploy parsed artifacts to the VM path used by the hosted service.
- Update the hosted service so `/health`, `/summary`, `/search`, `/query`, and read-only SQL reach the lane by explicit source value.
- Update the remote CLI so `ask-monarch query/search/sql ... --source SOURCE` reaches the hosted path.
- Update `skills/askmonarch/SKILL.md` with routing rules for the lane.
- Update README/spec/source docs and receipts.
- Update the Ask Monarch architecture docs and visual when the lane changes the
  answerable source plane: `README.md`, `ASKMONARCH-SPEC.md`,
  `docs/ask-monarch-architecture.svg`, and the rendered
  `docs/ask-monarch-architecture.png`.
- Verify from outside the server with the real remote CLI and, when useful, direct HTTP.

Local parser success is necessary but not sufficient.

## Post-Confirmation Doc Sync

After a Monarch lane passes the four gates, immediately update the repo-facing
docs before reporting the lane as ready or shipped. This is automatic source
work, not an optional follow-up.

Required Monarch artifacts:

- `README.md`: current source-lane inventory and operator-facing status.
- `ASKMONARCH-SPEC.md`: product/source contract, source boundary, freshness
  behavior, and exclusions or caveats.
- `docs/ask-monarch-architecture.svg`: editable architecture visual source.
- `docs/ask-monarch-architecture.png`: rendered README-facing architecture
  image.
- The lane-specific source receipt docs under `docs/`, such as
  `docs/monarch-videos-new-source.md` or the relevant new-lane receipt.

When updating the architecture image, edit the SVG/source artifact first and
then render the PNG using the repo's documented visual workflow. If the repo
uses Manim or another renderer for the architecture visual, run that renderer
and keep the rendered PNG in sync with the source file.

Do not say "ready", "shipped", "source-grade", "fully sourced", or "queryable"
until those docs are updated, the architecture image is current, and the same
change is synced to the hosted repo/runtime path when runtime promotion is part
of the work. If a doc or visual artifact is missing, create or update the
closest repo-owned architecture artifact and record any remaining gap
explicitly.

## Correction Loop

If a user correction reveals that an Ask Monarch answer missed a verified lane
or used the wrong source, use `correction`:

- If the evidence is already atomically queryable, patch `skills/askmonarch/SKILL.md` so future answers route correctly.
- If the artifact exists but is not queryable, keep it as a source gap and run `monarch-source` onboarding before encoding answer behavior.
- If the source boundary or product contract changed, update `ASKMONARCH-SPEC.md` and relevant receipts/docs.
- Reinstall changed skills with `python3 scripts/install_codex_skills.py --skill monarch-source --skill askmonarch --skill correction`.

## Useful Repo Paths

- Source map: `config/source-map.yaml`
- Daily refresh doc: `docs/daily-source-refresh.md`
- Bucket source receipt: `docs/monarch-videos-new-source.md`
- Presentation receipt: `docs/storyboards-presentations-2026-source.md`
- Teams recap receipt: `docs/monarch-r-and-d-teams-recaps-source.md`
- Company profile receipt: `docs/monarch-company-profile-source.md`
- People directory receipt: `docs/monarch-people-directory-source.md`
- Company context receipt: `docs/monarch-company-context-source.md`
- Scientific reference library receipt: `docs/monarch-scientific-reference-library-source.md`
- Milestones receipt: `docs/monarch-milestones-doc-source.md`
- Compound inventory receipt: `docs/monarch-compound-chemical-inventory-source.md`

## Answer Shape

```text
Mapped: yes/no/partial
Accessible: yes/no/partial
Atomically queryable: yes/no/partial
Ask-surface wired: yes/no/partial

What I verified:
- ...

Provenance grain:
- ...

Gaps:
- ...

Current truth:
...
```
