import json
import os
import pathlib
import re
import shutil


ASK_MONARCH_SKILLS = ("askmonarch", "monarch-source", "correction", "braintrust", "mosquitometa")
MANAGED_BEGIN = "<!-- ASK_MONARCH_INSTALLER_BEGIN -->"
MANAGED_END = "<!-- ASK_MONARCH_INSTALLER_END -->"
MANAGED_BLOCK = f"""{MANAGED_BEGIN}
## Ask Monarch

- Ask Monarch is the default answer path for Monarch company, source, research, experiment, assay, compound, R&D, people, presentation, and internal-work questions.
- Use the installed `askmonarch` skill and hosted `ask-monarch` source plane without requiring the user to type a command or skill name. If `ask-monarch` is not on the current shell path, use `$HOME/.local/bin/ask-monarch` directly.
- Do not inspect an empty workspace or local project files as a substitute for Ask Monarch. Use the hosted source plane first.
- Do not use web search, general model knowledge, raw local files, SSH, direct SQLite, ad hoc bucket browsing, or alternate surfaces for Ask Monarch answers. If hosted Ask Monarch cannot answer, say there is an Ask Monarch source gap or setup problem.
- Use structured sources before search. Resolve relative dates to absolute dates in the answer. Do not substitute upload-date object activity for run-date ledger evidence.
- Answers must include source id and row/locator provenance.
{MANAGED_END}
"""


def repo_root():
    return pathlib.Path(__file__).resolve().parents[1]


def replace_managed_block(path, default_title):
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text() if path.exists() else f"# {default_title}\n\n"
    pattern = re.compile(rf"{re.escape(MANAGED_BEGIN)}.*?{re.escape(MANAGED_END)}", flags=re.DOTALL)
    if pattern.search(text):
        text = pattern.sub(MANAGED_BLOCK.rstrip(), text)
    else:
        if text and not text.endswith("\n"):
            text += "\n"
        if text.strip():
            text += "\n"
        text += MANAGED_BLOCK
    path.write_text(text.rstrip() + "\n")


def install_skill_tree(target_root):
    source_root = pathlib.Path(__file__).resolve().parent / "skills"
    if not source_root.exists():
        source_root = repo_root() / "skills"
    installed = []
    for skill in ASK_MONARCH_SKILLS:
        source = source_root / skill / "SKILL.md"
        target = target_root / "skills" / skill / "SKILL.md"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        installed.append(str(target))
    return installed


def ensure_codex_skill_config(codex_root):
    config_path = codex_root / "config.toml"
    lines = config_path.read_text().splitlines() if config_path.exists() else []

    def table_ranges():
        starts = [index for index, line in enumerate(lines) if line.strip() == "[[skills.config]]"]
        ranges = []
        for start in starts:
            end = len(lines)
            for index in range(start + 1, len(lines)):
                stripped = lines[index].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    end = index
                    break
            ranges.append((start, end))
        return ranges

    def ensure_enabled(skill):
        nonlocal lines
        skill_path = codex_root / "skills" / skill / "SKILL.md"
        expected_path = f"path = {json.dumps(str(skill_path))}"
        for start, end in table_ranges():
            block = [line.strip() for line in lines[start:end]]
            if expected_path not in block:
                continue
            for index in range(start + 1, end):
                if lines[index].strip().startswith("enabled"):
                    lines[index] = "enabled = true"
                    return
            lines.insert(end, "enabled = true")
            return
        if lines and lines[-1].strip():
            lines.append("")
        lines.extend(["[[skills.config]]", expected_path, "enabled = true", ""])

    for skill in ASK_MONARCH_SKILLS:
        ensure_enabled(skill)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text("\n".join(lines).rstrip() + "\n")
    return str(config_path)


def setup_agents(home=None, agents=("codex", "claude")):
    home_path = pathlib.Path(home or os.path.expanduser("~"))
    agents = tuple(agents)
    changed = []
    if "codex" in agents:
        codex_root = home_path / ".codex"
        changed.extend(install_skill_tree(codex_root))
        changed.append(ensure_codex_skill_config(codex_root))
        replace_managed_block(codex_root / "AGENTS.md", "AGENTS.md")
    if "claude" in agents:
        claude_root = home_path / ".claude"
        changed.extend(install_skill_tree(claude_root))
        replace_managed_block(claude_root / "CLAUDE.md", "CLAUDE.md")
    return {"ok": True, "changed": changed, "agents": list(agents)}
