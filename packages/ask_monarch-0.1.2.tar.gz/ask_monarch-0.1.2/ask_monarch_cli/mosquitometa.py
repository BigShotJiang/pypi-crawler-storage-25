#!/usr/bin/env python3
"""Update the Monarch mosquito DART metadata workbook from GCS videos.

This is an Ask Monarch-owned operational helper. It updates the shared
`mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx` workbook with one Assays row
per tube for each new mosquito video.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from copy import copy
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import load_workbook


BUCKET_ROOT = "gs://monarch-videos-new"
WORKBOOK_OBJECT = f"{BUCKET_ROOT}/mosquitoes/Mosquito_DART_assay_Results_GCS.xlsx"
VIDEO_PREFIX = f"{BUCKET_ROOT}/mosquitoes/videos/"
BACKUP_PREFIX = f"{BUCKET_ROOT}/mosquitoes/metadata_backups/"
LOG_DIR = Path.home() / ".codex" / "logs" / "mosquitometa"

DEFAULT_TEMP = 25.1
DEFAULT_RH = 49
DEFAULT_DILUTION = 0.01
DEFAULT_SOLVENT = "DPG"

TOKEN_TO_INVENTORY_NAME = {
    "nPhform": "N-phenylformamide",
    "nCHform": "N-cyclohexylformamide",
}

VIDEO_RE = re.compile(
    r"^_?(?P<year>\d{4})_(?P<month>\d{2})_(?P<day>\d{2})_"
    r"(?P<hour>\d{2})_(?P<minute>\d{2})_(?P<second>\d{2})_"
    r"(?P<treatment>.+?)_mov\.mov$",
    re.IGNORECASE,
)


def run(cmd: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, check=check, text=True, capture_output=True)


def require_command(name: str) -> None:
    if shutil.which(name) is None:
        raise SystemExit(f"missing required command: {name}")


def parse_video_uri(uri: str) -> dict[str, Any] | None:
    filename = uri.rsplit("/", 1)[-1]
    match = VIDEO_RE.match(filename)
    if not match:
        return None
    parts = match.groupdict()
    raw_treatment = parts["treatment"]
    treatment = re.sub(r"\d+$", "", raw_treatment)
    if treatment.lower() == "control":
        treatment = "Control"
    return {
        "uri": uri,
        "filename": filename,
        "date_value": int(f"{int(parts['month'])}{int(parts['day']):02d}{parts['year']}"),
        "time_value": datetime(
            int(parts["year"]),
            int(parts["month"]),
            int(parts["day"]),
            int(parts["hour"]),
            int(parts["minute"]),
            int(parts["second"]),
        ).time(),
        "treatment": treatment,
    }


def list_video_uris() -> list[str]:
    result = run(["gcloud", "storage", "ls", f"{VIDEO_PREFIX}_*.mov"])
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def ask_monarch_sql(sql: str, source: str) -> dict[str, Any]:
    cli = shutil.which("ask-monarch") or str(Path.home() / ".local" / "bin" / "ask-monarch")
    result = run([cli, "sql", sql, "--source", source, "--limit", "200"])
    payload = json.loads(result.stdout)
    if not payload.get("ok"):
        raise RuntimeError(payload)
    return payload


def sql_quote(value: str) -> str:
    return value.replace("'", "''")


def inventory_inchikey(chemical_name: str) -> tuple[str | None, dict[str, Any] | None]:
    """Resolve an InChIKey from the compound inventory Master sheet.

    The inventory source of truth is column D for chemical name and column E for
    the InChIKey in the Master sheet.
    """

    quoted = sql_quote(chemical_name.lower())
    sql = f"""
select
  name_cell.row_number as row_number,
  name_cell.value as chemical_name,
  key_cell.value as inchikey,
  key_cell.provenance_grain as provenance_grain
from cells name_cell
left join cells key_cell
  on key_cell.sheet_name = name_cell.sheet_name
 and key_cell.row_number = name_cell.row_number
 and key_cell.column_name = 'E'
where name_cell.sheet_name = 'Master'
  and name_cell.column_name = 'D'
  and lower(name_cell.value) = '{quoted}'
limit 5
""".strip()
    payload = ask_monarch_sql(sql, "compound_inventory")
    rows = payload.get("rows", [])
    if not rows:
        return None, None
    row = rows[0]
    key = row.get("inchikey")
    if not key:
        return None, row
    return str(key), row


def copy_row_style(ws: Any, src_row: int, dst_row: int) -> None:
    for col in range(1, ws.max_column + 1):
        src = ws.cell(src_row, col)
        dst = ws.cell(dst_row, col)
        if src.has_style:
            dst._style = copy(src._style)
        dst.number_format = src.number_format
        dst.alignment = copy(src.alignment)
        dst.font = copy(src.font)
        dst.fill = copy(src.fill)
        dst.border = copy(src.border)


def append_rows(workbook_path: Path, *, temp: float, rh: float, dilution: float, solvent: str) -> dict[str, Any]:
    video_uris = list_video_uris()
    videos = []
    skipped_videos = []
    for uri in video_uris:
        try:
            parsed = parse_video_uri(uri)
        except ValueError as exc:
            skipped_videos.append({"uri": uri, "reason": str(exc)})
            continue
        if parsed:
            videos.append(parsed)

    wb = load_workbook(workbook_path)
    ws = wb["Assays"]
    headers = {ws.cell(1, c).value: c for c in range(1, ws.max_column + 1) if ws.cell(1, c).value}
    required = [
        "date",
        "filename",
        "time started",
        "temp",
        "rh",
        "class",
        "tube",
        "slot",
        "context",
        "treatment",
        "dilution",
        "solvent",
        "left_condition",
        "right_condition",
        "treatment_position",
        "inchikey",
    ]
    missing = [name for name in required if name not in headers]
    if missing:
        raise RuntimeError(f"missing Assays headers: {missing}")

    while ws.max_row > 1 and all(ws.cell(ws.max_row, c).value is None for c in range(1, ws.max_column + 1)):
        ws.delete_rows(ws.max_row, 1)

    existing = {
        str(ws.cell(row, headers["filename"]).value)
        for row in range(2, ws.max_row + 1)
        if ws.cell(row, headers["filename"]).value
    }
    missing_videos = [video for video in videos if video["filename"] not in existing]

    treatment_keys: dict[str, str] = {}
    inventory_sources: dict[str, dict[str, Any]] = {}
    source_gaps: list[dict[str, str]] = []
    for treatment in sorted({video["treatment"] for video in missing_videos if video["treatment"] != "Control"}):
        inventory_name = TOKEN_TO_INVENTORY_NAME.get(treatment, treatment)
        key, source_row = inventory_inchikey(inventory_name)
        if key:
            treatment_keys[treatment] = key
            inventory_sources[treatment] = {
                "inventory_name": inventory_name,
                "source_row": source_row,
            }
        else:
            source_gaps.append({"treatment": treatment, "inventory_name": inventory_name})

    if source_gaps:
        return {
            "ok": False,
            "reason": "missing_inchikey_source",
            "source_gaps": source_gaps,
            "videos_seen": len(videos),
            "skipped_videos": skipped_videos,
            "missing_videos": len(missing_videos),
        }

    start_row = ws.max_row + 1
    template_row = ws.max_row
    side_for_tube = {1: "R", 2: "L", 3: "R"}
    slot_for_tube = {1: 2, 2: 4, 3: 6}
    rows_added = 0
    appended: list[str] = []

    for video in missing_videos:
        treatment = video["treatment"]
        is_control = treatment == "Control"
        for tube in (1, 2, 3):
            row = start_row + rows_added
            copy_row_style(ws, template_row, row)
            ws.cell(row, headers["date"]).value = video["date_value"]
            ws.cell(row, headers["filename"]).value = video["filename"]
            ws.cell(row, headers["time started"]).value = video["time_value"]
            ws.cell(row, headers["temp"]).value = temp
            ws.cell(row, headers["rh"]).value = rh
            ws.cell(row, headers["class"]).value = "F"
            ws.cell(row, headers["tube"]).value = tube
            ws.cell(row, headers["slot"]).value = slot_for_tube[tube]
            ws.cell(row, headers["context"]).value = "Heat"
            ws.cell(row, headers["treatment"]).value = treatment
            if is_control:
                ws.cell(row, headers["left_condition"]).value = "HEAT"
                ws.cell(row, headers["right_condition"]).value = "HEAT"
            else:
                ws.cell(row, headers["dilution"]).value = dilution
                ws.cell(row, headers["solvent"]).value = solvent
                ws.cell(row, headers["inchikey"]).value = treatment_keys[treatment]
                if tube == 2:
                    ws.cell(row, headers["left_condition"]).value = f"HEAT + {treatment}"
                    ws.cell(row, headers["right_condition"]).value = f"HEAT + {solvent}"
                else:
                    ws.cell(row, headers["left_condition"]).value = f"HEAT + {solvent}"
                    ws.cell(row, headers["right_condition"]).value = f"HEAT + {treatment}"
            ws.cell(row, headers["treatment_position"]).value = side_for_tube[tube]
            rows_added += 1
        appended.append(video["filename"])

    wb.save(workbook_path)
    return {
        "ok": True,
        "videos_seen": len(videos),
        "skipped_videos": skipped_videos,
        "new_videos": len(missing_videos),
        "rows_added": rows_added,
        "row_range": [start_row, start_row + rows_added - 1] if rows_added else None,
        "appended": appended,
        "inventory_sources": inventory_sources,
    }


def upload_with_backup(workbook_path: Path) -> str:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_uri = f"{BACKUP_PREFIX}Mosquito_DART_assay_Results_GCS-{stamp}.xlsx"
    run(["gcloud", "storage", "cp", WORKBOOK_OBJECT, backup_uri])
    run(["gcloud", "storage", "cp", str(workbook_path), WORKBOOK_OBJECT])
    return backup_uri


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="write local draft but do not upload")
    parser.add_argument("--temp", type=float, default=float(os.environ.get("MOSQUITOMETA_TEMP", DEFAULT_TEMP)))
    parser.add_argument("--rh", type=float, default=float(os.environ.get("MOSQUITOMETA_RH", DEFAULT_RH)))
    parser.add_argument(
        "--dilution",
        type=float,
        default=float(os.environ.get("MOSQUITOMETA_DILUTION", DEFAULT_DILUTION)),
    )
    parser.add_argument("--solvent", default=os.environ.get("MOSQUITOMETA_SOLVENT", DEFAULT_SOLVENT))
    parser.add_argument("--output", type=Path, help="local output path for dry runs")
    args = parser.parse_args(argv)

    require_command("gcloud")
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S")

    with tempfile.TemporaryDirectory(prefix="mosquitometa-") as tmp:
        tmp_path = Path(tmp)
        workbook_path = args.output or tmp_path / "Mosquito_DART_assay_Results_GCS.xlsx"
        run(["gcloud", "storage", "cp", WORKBOOK_OBJECT, str(workbook_path)])
        summary = append_rows(
            workbook_path,
            temp=args.temp,
            rh=args.rh,
            dilution=args.dilution,
            solvent=args.solvent,
        )
        summary["dry_run"] = bool(args.dry_run)
        summary["workbook_object"] = WORKBOOK_OBJECT
        summary["run_id"] = run_id
        if summary.get("ok") and not args.dry_run and summary.get("rows_added", 0) > 0:
            summary["backup_uri"] = upload_with_backup(workbook_path)
            summary["uploaded"] = True
        else:
            summary["uploaded"] = False
        log_path = LOG_DIR / f"{run_id}.json"
        log_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
        print(json.dumps(summary, indent=2, sort_keys=True))
        return 0 if summary.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
