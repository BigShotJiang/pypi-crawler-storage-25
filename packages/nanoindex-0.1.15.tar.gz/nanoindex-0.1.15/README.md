<div align="center">

# NanoIndex

**Turn any PDF into searchable trees and visual knowledge graphs.**
**Ask questions, get answers with page citations.**

<p>
  <a href="https://github.com/nanonets/nanoindex"><img src="https://img.shields.io/badge/GitHub-NanoIndex-181717?style=for-the-badge&logo=github&logoColor=white" /></a>
  <a href="https://nanonets.com/research/nanonets-ocr-3"><img src="https://img.shields.io/badge/Built%20on-Nanonets%20OCR--3-546FFF?style=for-the-badge" /></a>
  <a href="https://www.apache.org/licenses/LICENSE-2.0"><img src="https://img.shields.io/badge/License-Apache%202.0-20C997?style=for-the-badge" /></a>
</p>

<p>
  <a href="https://docstrange.nanonets.com/app"><img src="https://img.shields.io/badge/Get%20API%20Key-Free%2010K%20Pages-FCC419?style=for-the-badge" /></a>
  <a href="https://colab.research.google.com/github/NanoNets/nanoindex/blob/main/examples/nanoindex_quickstart.ipynb"><img src="https://img.shields.io/badge/Try%20in-Google%20Colab-F9AB00?style=for-the-badge&logo=googlecolab&logoColor=white" /></a>
</p>

| Benchmark | Documents | Avg Pages | Accuracy |
|---|---|---|---|
| FinanceBench (SEC 10-K filings) | 84 | 143 | **94.5%** |
| DocBench Legal (court filings, legislation) | 51 | 54 | **96.0%** |

</div>

No vector databases. No chunk tuning. No embeddings.

NanoIndex reads your document, understands its structure (headings, sections, tables, figures), and builds a tree you can search with plain English. Built on [Nanonets OCR-3](https://nanonets.com/research/nanonets-ocr-3) for extraction. Fully open source.

---

## Quick Start

### 1. Install

```bash
pip install nanoindex
```

### 2. Get your API keys

You need two keys before anything works:

**Nanonets key** (for reading PDFs):
- Go to [docstrange.nanonets.com/app](https://docstrange.nanonets.com/app)
- Create a free API key (first 10,000 pages free, then $0.01/page)

**LLM key** (for answering questions):
- Get an API key from [OpenAI](https://platform.openai.com/api-keys), [Anthropic](https://console.anthropic.com/), [Google](https://aistudio.google.com/apikey), or any provider you prefer

Set them in your terminal:

```bash
export NANONETS_API_KEY=your_nanonets_key
export OPENAI_API_KEY=your_openai_key
```

### 3. Try it on your PDF

```python
from nanoindex import NanoIndex

ni = NanoIndex(
    nanonets_api_key="...",         # reads your PDF
    reasoning_llm_model="gpt-4o",  # answers your questions
)

# Index your document
tree = ni.index("report.pdf")

# Ask a question
answer = ni.ask("What was the revenue?", tree)
print(answer.content)     # the answer
print(answer.citations)   # pages + sections it came from
```

That's it. Three steps: install, set keys, ask questions.

### What you can do next

```python
# Save the tree so you don't re-extract every time
from nanoindex.utils.tree_ops import save_tree, load_tree
save_tree(tree, "my_tree.json")
tree = load_tree("my_tree.json")  # instant, no API call

# Explore the tree structure
from nanoindex.utils.tree_ops import iter_nodes
for node in iter_nodes(tree.structure):
    print(f"[{node.node_id}] {node.title} (pages {node.start_index}-{node.end_index})")

# Open the interactive dashboard
nanoindex.visualize(tree)
```

---

## How It Works

### Indexing: PDF to tree + graph

<p align="center">
  <img src="assets/ingestion-pipeline.gif" alt="Ingestion Pipeline" width="800"/>
</p>

### Querying: Fast Mode (default)

<p align="center">
  <img src="assets/query-fast.gif" alt="Query Pipeline - Fast Mode" width="800"/>
</p>

### Querying: Agentic Mode (highest accuracy)

<p align="center">
  <img src="assets/query-agentic.gif" alt="Query Pipeline - Agentic Mode" width="800"/>
</p>

---

## What Can You Do With It

### From the command line

```bash
# Index a PDF and save the tree
nanoindex index report.pdf -o tree.json

# Ask a question
nanoindex ask report.pdf "What was the revenue?" --llm-model gpt-4o

# Open the visual dashboard
nanoindex viz tree.json
```

### From Python

```python
from nanoindex import NanoIndex

ni = NanoIndex(
    nanonets_api_key="...",
    reasoning_llm_model="gpt-4o",
)

tree = ni.index("report.pdf")
answer = ni.ask("What was Q3 gross margin?", tree)
print(answer.content)     # "Gross margin was 42.3% in Q3..."
print(answer.citations)   # [Citation(title="Income Statement", pages=[45, 46])]
```

### Supported LLM providers

Just pass a model name. API keys are auto-detected from environment variables.

```python
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="gpt-4o")              # OpenAI
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="claude-sonnet-4-6")   # Anthropic
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="gemini-2.5-flash")    # Google
ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="llama-3.3-70b-versatile")  # Groq
```

Works with any OpenAI-compatible endpoint (Ollama, vLLM, Together, etc.) via `reasoning_llm_base_url`.

### Search across multiple documents

```python
from nanoindex import NanoIndex, DocumentStore

ni = NanoIndex(nanonets_api_key="...", reasoning_llm_model="gpt-4o")
store = DocumentStore()

for pdf in ["q1.pdf", "q2.pdf", "q3.pdf"]:
    tree = ni.index(pdf)
    store.add(tree)

answer = ni.multi_ask("Compare revenue across quarters", store)
```

---

## Query Modes

When you call `nanoindex.index()`, the tree, entity graph, and embeddings are all built automatically. Queries use the graph by default for fast, cheap retrieval.

| Mode | Retrieval | Answer | Best for |
|---|---|---|---|
| `fast` (default) | Embedding + graph pre-filter, LLM sees ~20 nodes | Text | Most queries, cheapest |
| `fast_vision` | Same | Text + page images | Charts, figures, layouts |
| `agentic` | LLM navigates full tree, multiple rounds | Text | Complex multi-step questions |
| `agentic_vision` | Same | Text + page images | Highest accuracy, most expensive |

```python
# Default — fast, uses entity graph (cheapest)
answer = ni.ask("What was revenue?", tree)

# With page images for visual content
answer = ni.ask("Describe Figure 3", tree, mode="fast_vision", pdf_path="report.pdf")

# Maximum accuracy — LLM reads the full tree
answer = ni.ask("Compare Q3 margins across segments", tree, mode="agentic_vision", pdf_path="report.pdf")
```

---

## Entity Graph

Every indexed document gets an entity graph built automatically. The graph extracts entities (companies, metrics, dates, people) and their relationships from every section.

At query time: embedding search finds candidate nodes, the graph expands to related sections, and the LLM only reads ~20 nodes instead of 300+. This makes the default `fast` mode 3x cheaper than sending the full tree.

You can visualize the graph in the dashboard under the "Entities" tab.

---

## Open-Source Mode (No API Key for Parsing)

NanoIndex can also work without Nanonets OCR-3, using PyMuPDF for extraction:

```python
ni = NanoIndex(parser="pymupdf")
tree = ni.index("report.pdf")  # no API key needed for parsing
```

PyMuPDF gives you basic text and table extraction. The tree will be simpler (no heading detection, no hierarchy), but it works for quick experiments. For production quality, use Nanonets OCR-3.

---

## Benchmarks

Tested on real-world documents with LLM-as-judge evaluation:

| Benchmark | Documents | Avg Pages | Accuracy |
|---|---|---|---|
| FinanceBench (SEC 10-K filings) | 84 | 143 | **94.5%** |
| DocBench Legal (court filings, legislation) | 51 | 54 | **96.0%** |

Evidence page retrieval accuracy: **93.3%**

### FinanceBench evaluation

<p align="center">
  <img src="assets/financebench-architecture.png" alt="FinanceBench Architecture" width="800"/>
</p>

---

## How It Compares

| | Traditional RAG | NanoIndex |
|---|---|---|
| Indexing | Chunk + embed + vector DB | Extract + build tree |
| Retrieval | Similarity search | LLM reasons over structure |
| Tables | Poorly handled | Natively extracted |
| Figures | Not supported | Vision mode |
| Scanned docs | Needs separate OCR | Built-in |
| Structure-aware | No | Yes |
| Citations | Approximate | Exact page + bounding box |

---

## Project Structure

```
nanoindex/
  __init__.py         # Public API: index(), search(), ask(), visualize()
  cli.py              # Command line interface
  models.py           # Data models (TreeNode, DocumentTree, Entity, etc.)
  config.py           # Configuration

  core/
    extractor.py      # Nanonets OCR-3 extraction
    tree_builder.py   # Deterministic tree construction
    enricher.py       # LLM summary generation
    retriever.py      # Tree search
    generator.py      # Answer generation (text + vision)
    agentic.py        # Multi-round retrieval
    fast_retriever.py # Embedding + graph retrieval
    entity_extractor.py   # Entity/relationship extraction
    graph_builder.py      # NetworkX graph operations
    embedder.py           # Node embedding + cosine search
    parsers/              # Pluggable parsers (nanonets, pymupdf)
    modal_processors/     # Image + table processing for graph

  utils/
    tree_ops.py       # Save, load, traverse trees
    tokens.py         # Token counting
    pdf.py            # PDF page rendering

viz/                  # Interactive visualization dashboard (Next.js)
examples/             # Usage examples
benchmarks/           # Evaluation scripts
```

---

## Development

```bash
git clone https://github.com/nanonets/nanoindex.git
cd nanoindex
pip install -e ".[dev]"
pytest
```

---

## License

Apache 2.0 — see [LICENSE](LICENSE).
