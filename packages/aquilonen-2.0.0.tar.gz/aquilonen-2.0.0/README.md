Note that versioning labels are incorrect prior to 1.0.0

This library is intended to streamline certain processes in machine learning workflows that seem to be missing
Currently it only contains the following components:
1. TSA - This module houses a version of ARIMA (from statsmodels) that has a built in method for cross validating the model for time series analysis, instead of relying on AIC or BIC which are tentative metrics.
2. simple_scraper - A drastically simplified version of Playwright for web scraping, which supports both sync and async playwright
3. FolderSearcher - A class that performs automatic recursive extraction of all files from a folder system, which also automatically labels each file with the folder path that it belonged to.