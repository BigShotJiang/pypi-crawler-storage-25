
from inspect import signature
from numpy import arange
from statsmodels.tsa.arima.model import ARIMA
import warnings
warnings.filterwarnings("ignore")
class ARIMAWithCV(ARIMA):
    """
    ARIMA model with integrated cross-validation support.
    
    This class inherits from statsmodels.tsa.arima.model.ARIMA and provides a specialized cross_validate() method to evaluatemodel performance.
    """

    def cross_validate(self, scoring_function, cv = 'all'):
        """
        Cross-validate the ARIMA model.

        Parameters
        ----------
        scoring_function : callable 
            A function that accepts (y_pred, y_true) and returns a numeric score.

        cv : int or 'all', default = 'all'
            The number of folds to use.
            If 'all' it will create as many partitions as possible from the dataset

        Returns
        -------
        results : dict
            A summary of results containing:
            - 'final_score' (float): Average score of successful folds.
            - 'num_folds_passed' (int): Number of folds that didn't crash.
            - 'scores' (list): List of scores from each fold.
            - 'success_flags' (list): Boolean list of pass/fail status.
            - 'error_type' (str or None): The error message if a failure occurred.
        """
        score_sum = 0
        num_folds_passed = 0
        num_total_samples = len(self.endog)
        if cv == 'all':
            cv = num_total_samples
            training_lengths = arange(1, num_total_samples)
        else:
            cv+=1
            training_lengths = arange(1, cv)*num_total_samples/cv
            training_lengths = training_lengths.astype(int)

        using_exog = self.exog is not None
        exog_test_set = None
        success_flags = []
        scores = []
        error_type = []
        args_in = {}
        for param in signature(ARIMA).parameters:
            if hasattr(self, param):
                args_in[param] = getattr(self, param)

        args_in = {'trend':'n'}

        for train_length in training_lengths:
            print("train length:", train_length)
            args_in['endog'] = self.endog[:train_length]
            test_set = self.endog[train_length:]
            if using_exog:
                args_in['exog'] = self.exog[:train_length]
                exog_test_set = self.exog[train_length:]

            print("exog:", args_in['trend'])
            model = ARIMA( **args_in)
            try:
                trained_model = model.fit()
                score = scoring_function(test_set, trained_model.forecast(steps=len(test_set), exog = exog_test_set))
                scores.append(score)
                score_sum += score
                num_folds_passed += 1
                success_flags.append(True)
                error_type.append(None)
            except Exception as e:
                success_flags.append(False)
                error_type.append(e)
                scores.append(None)
                continue

        return {
                'final_score': score_sum/(cv - 1),
                'num_folds_passed': num_folds_passed,
                'scores': scores,
                'success_flags': success_flags,
                'error_type': error_type,
                }
