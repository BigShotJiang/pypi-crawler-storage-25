import playwright_stealth


from playwright.sync_api import sync_playwright
from playwright.async_api import async_playwright

def sync_scrape(url):
    """
    Fetches the full HTML content of a webpage after executing JavaScript.

    Parameters
    ----------
    url : str
        The URL of the website to fetch.

    Returns
    -------
    page_content : The JavaScript-rendered HTML content.
    """

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        playwright_stealth.stealth_sync(page)
        page.goto(url)
        return page.content()
    
async def async_scrape(url):
    """
    Fetches the full HTML content of a webpage after executing JavaScript.

    Parameters
    ----------
    url : str
        The URL of the website to fetch.

    Returns
    -------
    page_content : The JavaScript-rendered HTML content.
    """

    async with async_playwright() as p:
        browser = await p.chromium.launch()  # set True if you don't want UI
        page = await browser.new_page()
        await playwright_stealth.stealth_async(page)
        await page.goto(url)
        return await page.content()
