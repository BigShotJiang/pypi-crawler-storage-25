from . import simple_scraper
from . import TSA
import os

class FolderSearcher():

    """
    Recursive Folder Search and File Extraction - See the dig() method for more info

    Attributes
    -----------
    dataset : list
        objects extracted from files during dig

    labels : list
        paths to files extracted during dig
    """


    def __init__(self):
        self.dataset = []
        self.labels = []

    #create the function for recursive folder search
    def dig(self, base_path, handle_file):

        """
        Recursively searches through every subfolder and subfile in a root folder.

        Applies a file handling function to each file found and appends the resulting object to the global 'dataset'. 
        It also appends the file path to the global 'labels'.

        Parameters
        ----------
        base_path : str 
            The path to the root folder.

        handle_file : callable
            A function that accepts a file path (str) and returns an object.

        Returns
        -------
        dataset : list
        objects extracted from files during dig

        labels : list
        paths to files extracted during dig
        """

        #apply the directory loop
        for file_or_folder_path in os.listdir(base_path):

            #add the base path so that python can actually find this file
            file_or_folder_path = base_path + '/' + file_or_folder_path

            #if it is a file
            if os.path.isfile(file_or_folder_path):

                self.dataset.append(handle_file(file_or_folder_path))

                self.labels.append(file_or_folder_path)

            else: self.dig(file_or_folder_path, handle_file)

        return self.dataset, self.labels


