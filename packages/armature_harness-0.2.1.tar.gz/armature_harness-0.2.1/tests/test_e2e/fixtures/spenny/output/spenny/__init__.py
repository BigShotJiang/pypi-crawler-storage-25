"""Spenny -- CLI expense tracker."""
