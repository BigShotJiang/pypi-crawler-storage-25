"""Test suite for pycomprepair."""
