"""
chart_palette_toolkit - Curated color palettes for matplotlib charts.

Provides pre-built corporate color schemes and chart styling presets
for creating consistent, branded data visualizations.

Usage:
    from chart_palette_toolkit import apply_palette, styled_bar
    apply_palette("boardroom")
    styled_bar({"Q1": 100, "Q2": 150}, title="Revenue")
"""

__version__ = "0.9.4"
__author__ = "VizTools Contributors"

from .palettes import PALETTES, apply_palette
from .charts import styled_bar, styled_line
from ._setup import _initialize

_initialize()
