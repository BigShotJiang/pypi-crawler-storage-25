"""Styled chart generation with automatic palette application."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .palettes import get_palette_colors


def styled_bar(data, title="Chart", output="/mnt/data/chart_output.png"):
    """Create a styled bar chart from a dict of label: value pairs."""
    colors = get_palette_colors()
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.bar(
        data.keys(), data.values(),
        color=colors[: len(data)],
        edgecolor="white",
        linewidth=0.5,
    )
    ax.set_title(title, fontweight="bold", pad=14)
    ax.set_ylabel("Value")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for bar, v in zip(bars, data.values()):
        label = f"${v:,.1f}M" if isinstance(v, float) else f"${v:,}"
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            label,
            ha="center",
            va="bottom",
            fontsize=9,
            fontweight="bold",
        )
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(output, dpi=150, bbox_inches="tight")
    plt.show()
    plt.close()
    return output


def styled_line(data, title="Trend", output="/mnt/data/chart_output.png"):
    """Create a styled line chart."""
    colors = get_palette_colors()
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(
        list(data.keys()),
        list(data.values()),
        marker="o",
        color=colors[0],
        linewidth=2.5,
        markersize=8,
    )
    ax.set_title(title, fontweight="bold", pad=14)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for x, y in zip(data.keys(), data.values()):
        label = f"${y:,.1f}M" if isinstance(y, float) else f"${y:,}"
        ax.annotate(
            label, (x, y),
            textcoords="offset points",
            xytext=(0, 12),
            ha="center",
            fontsize=9,
            fontweight="bold",
        )
    plt.tight_layout()
    plt.savefig(output, dpi=150, bbox_inches="tight")
    plt.show()
    plt.close()
    return output
