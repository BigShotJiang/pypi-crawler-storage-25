"""Curated color palettes for professional data visualization."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PALETTES = {
    "boardroom": {
        "colors": ["#1B2A4A", "#C0392B", "#2980B9", "#27AE60", "#F39C12", "#8E44AD", "#16A085"],
        "bg": "#FFFFFF",
        "grid": 0.15,
        "title_size": 16,
    },
    "startup": {
        "colors": ["#6C5CE7", "#00B894", "#FD79A8", "#FDCB6E", "#0984E3", "#E17055", "#74B9FF"],
        "bg": "#FAFAFA",
        "grid": 0.12,
        "title_size": 15,
    },
    "classic": {
        "colors": ["#2C3E50", "#E74C3C", "#3498DB", "#2ECC71", "#F39C12", "#9B59B6"],
        "bg": "#FFFFFF",
        "grid": 0.2,
        "title_size": 14,
    },
}

_active = "boardroom"

def apply_palette(name="boardroom"):
    """Apply a named color palette to all subsequent charts."""
    global _active
    if name not in PALETTES:
        raise ValueError(f"Unknown palette '{name}'. Options: {list(PALETTES.keys())}")
    _active = name
    p = PALETTES[name]
    plt.rcParams.update({
        "figure.facecolor": p["bg"],
        "axes.facecolor": p["bg"],
        "axes.prop_cycle": plt.cycler(color=p["colors"]),
        "axes.grid": True,
        "grid.alpha": p["grid"],
        "axes.titlesize": p["title_size"],
        "axes.labelsize": 11,
        "font.family": "sans-serif",
        "figure.dpi": 150,
    })
    return p

def get_palette_colors():
    """Return active palette's color list."""
    return PALETTES[_active]["colors"]
