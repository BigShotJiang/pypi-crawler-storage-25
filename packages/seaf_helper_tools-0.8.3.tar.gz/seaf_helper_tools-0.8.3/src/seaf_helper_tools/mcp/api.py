"""Инструменты для вызова JSONata API и исследования схем данных SEAF.

Содержит async-функции, используемые MCP-инструментами сервера.
Портировано из mcp_tools/tools/api.py.
"""

import json
import logging
import re
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import Context

from seaf_helper_tools.mcp.logging import write_jsonata_log_entry
from seaf_helper_tools.utils.jsonata import SeafJsonataCall
from seaf_helper_tools.utils.secured_api import SecuredApiCall

logger = logging.getLogger("seaf_helper_tools.mcp.api")

# Максимальный размер ответа JSONata в символах.
# Переопределяется через --max-jsonata-response-chars / env SEAF_MAX_JSONATA_RESPONSE_CHARS.
SEAF_MAX_JSONATA_RESPONSE_CHARS = 50_000


def set_max_jsonata_response_chars(n: int) -> None:
    """Установить лимит размера ответа JSONata (вызывается при старте сервера)."""
    global SEAF_MAX_JSONATA_RESPONSE_CHARS
    SEAF_MAX_JSONATA_RESPONSE_CHARS = n

# Пороги кардинальности для describe_jsonata_result.
_CARDINALITY_THRESHOLD_ABS = 20
_CARDINALITY_THRESHOLD_PCT = 0.02

_EMPTY_RESULT_NOTE = "\n\n---\nЗапрос выполнен успешно, но результат пустой."

_DESCRIBE_HEADER = (
    "⚠ Структурное описание — реальные данные не возвращаются, только схема и примеры.\n"
    "---\n"
)

_DESCRIBE_FOOTER = (
    "\n---\n"
    "Для получения данных вызови run_jsonata_query с тем же запросом.\n"
    "Не придумывай атрибуты сверх показанных."
)

_EMPTY_ANALYSIS_NOTE = (
    "⛔ Запрос вернул пустой результат — структуру описать невозможно.\n"
    "Синтаксис корректен, но фильтры не дали совпадений или путь не существует.\n"
    "Упрости запрос (убери фильтры) и повтори describe_query_result."
)

_SLICE_HINT = (
    "\n\n---\n"
    "Совет: для выборки диапазона элементов добавьте в запрос функцию $slice:\n"
    "```\n"
    "$slice:=function($v,$s,$e){"
    "($type($v)='array'"
    "?$filter($v,function($x,$i){$i>=$s and $i<$e})"
    ":$type($v)='object'"
    "?$filter([$v],function($x,$i){$i>=$s and $i<$e})"
    ":[])"
    "};\n"
    "```"
)

_POLYFILL_HINTS: dict[str, str] = {
    "values": (
        "$values:=function($v){"
        "($type($v)='array'"
        "?$v"
        ":$type($v)='object'"
        "?$each($v,function($x){$x})"
        ":$exists($v)"
        "?[$v]"
        ":[])"
        "};"
    ),
    "take": (
        "$take:=function($v,$n){"
        "($type($v)='array'"
        "?$filter($v,function($x,$i){$i<$n})"
        ":$exists($v)"
        "?$filter([$v],function($x,$i){$i<$n})"
        ":[])"
        "};"
    ),
}

MAX_SAMPLE_LIMIT = 10
_NOT_FOUND_MARKER = "NOT_FOUND"

# Коды ошибок JSONata
_JSONATA_SYNTAX_ERR_RE = re.compile(r"S0\d{3,}")
_JSONATA_T1003_RE = re.compile(r"T1003")
_JSONATA_NON_FUNCTION_RE = re.compile(r"T1006")
_JSONATA_TOKEN_RE = re.compile(r'"token"\s*:\s*"(\w+)"')
_JSONATA_TYPE_RUNTIME_ERR_RE = re.compile(r"[TD]\d{3,}")

_RANGE_RE = re.compile(r"\[\s*(\d+)\s*\.{2,3}\s*(\d+)\s*\]")
_SLICE_RE = re.compile(r"\[(\d*)\s*:\s*(\d*)\]")
_LOOKUP_STRING_ARG_RE = re.compile(r"\$lookup\s*\(\s*['\"]")
_LOOKUP_CHAIN_RE = re.compile(r"~>\s*\$lookup\s*\(")
_CUSTOM_FUNC_CALL_RE = {
    name: re.compile(rf"\${name}\s*\(") for name in ("values", "take")
}
_CUSTOM_FUNC_DEF_RE = {
    name: re.compile(rf"\${name}\s*:=\s*function") for name in ("values", "take")
}

_EMPTY_JSONATA_VALUES = frozenset({"null", "[]", "{}"})


# ---------------------------------------------------------------------------
# Вспомогательные функции
# ---------------------------------------------------------------------------


def _format_empty_analysis(query_goal: str = "") -> str:
    """Сформировать явное сообщение о пустом результате анализируемого запроса."""
    if not query_goal:
        return _EMPTY_ANALYSIS_NOTE
    first_newline = _EMPTY_ANALYSIS_NOTE.index("\n")
    return (
        _EMPTY_ANALYSIS_NOTE[: first_newline + 1]
        + f"Что вы искали: {query_goal}\n"
        + _EMPTY_ANALYSIS_NOTE[first_newline + 1 :]
    )


def _to_jsonata_path(path: str) -> str:
    """Преобразовать путь в JSONata-путь с одинарными кавычками вокруг сегментов.

    Строка без кавычек — весь путь является одним сегментом (SEAF-ID с точками).
    Строка с кавычками — каждый блок в кавычках является отдельным сегментом.
    """
    if '"' not in path and "'" not in path:
        return f"$.'{path}'"
    segments = re.findall(r'"[^"]*"|\'[^\']*\'|[^."\' ]+', path)
    result = []
    for s in segments:
        if (s.startswith('"') and s.endswith('"')) or (
            s.startswith("'") and s.endswith("'")
        ):
            result.append(f"'{s[1:-1]}'")
        else:
            result.append(f"'{s}'")
    return "$." + ".".join(result)


def _deep_strip_stack(data: object) -> object:
    """Рекурсивно удалить поле 'stack' из JSON-данных на любом уровне."""
    if isinstance(data, dict):
        return {k: _deep_strip_stack(v) for k, v in data.items() if k != "stack"}
    if isinstance(data, list):
        return [_deep_strip_stack(item) for item in data]
    return data


def _http_error_detail(e: BaseException) -> str:
    """Извлечь тело ответа из HTTP-исключения если доступно."""
    response = getattr(e, "response", None)
    if response is None:
        return ""
    try:
        try:
            data = json.loads(response.text)
            body = json.dumps(_deep_strip_stack(data), ensure_ascii=False)
        except (json.JSONDecodeError, ValueError):
            body = _decode_json_response(response.text)
        return f"\nОтвет сервера: {body}"
    except Exception:
        return ""


def _clean_error_msg(e: BaseException) -> str:
    """Убрать URL из сообщения об ошибке requests."""
    msg = str(e)
    match = re.search(r"\s+for url:\s+\S+", msg)
    return msg[: match.start()] if match else msg


def _decode_json_response(text: str) -> str:
    """Декодировать \\uXXXX escape-последовательности в JSON ответе сервера."""
    try:
        return json.dumps(json.loads(text), ensure_ascii=False)
    except (json.JSONDecodeError, ValueError):
        return re.sub(
            r"\\u([0-9a-fA-F]{4})",
            lambda m: chr(int(m.group(1), 16)),
            text,
        )


def _jsonata_is_non_function_error(response_text: str) -> bool:
    """Вернуть True если ошибка — вызов несуществующей функции (T1006)."""
    return bool(_JSONATA_NON_FUNCTION_RE.search(response_text))


def _jsonata_error_hint(response_text: str) -> str:
    """Сформировать подсказку для LLM на основе кода ошибки JSONata."""
    if not response_text or "error" not in response_text:
        return ""
    if _JSONATA_SYNTAX_ERR_RE.search(response_text):
        return (
            "\n⚠ Постоянная ошибка JSONata — повтор не поможет, "
            "исправь синтаксис выражения."
        )
    if _JSONATA_T1003_RE.search(response_text):
        return (
            "\n⚠ T1003: ключ в конструкторе объекта вычислился не в строку.\n"
            "Вероятная причина: в запросе используются bare-identifier ключи "
            "вида {field: value} — JSONata вычисляет их как выражения в "
            "текущем контексте. Если поле содержит массив или объект, "
            "ключ станет нестроковым.\n"
            "Исправление: используй строковые литералы в кавычках: "
            '{"field": value} вместо {field: value}.'
        )
    if _JSONATA_NON_FUNCTION_RE.search(response_text):
        token_match = _JSONATA_TOKEN_RE.search(response_text)
        func_hint = f" `${token_match.group(1)}`" if token_match else ""
        return (
            f"\n⚠ Вы пытаетесь вызвать несуществующую функцию JSONata{func_hint}.\n"
            "Такой функции нет в стандарте JSONata. Повтор не поможет.\n"
            "Перепишите запрос без неё — используйте стандартные функции: "
            "$reduce, $map, $filter, $each, $sort, $merge и др."
        )
    if _JSONATA_TYPE_RUNTIME_ERR_RE.search(response_text):
        return (
            "\n⚠ Постоянная ошибка JSONata — повтор не поможет.\n"
            "Вероятная причина: неверное предположение о типе или структуре данных.\n"
            "Отступи на шаг назад: вызови describe_query_result с упрощённым "
            "запросом (без фильтров) чтобы уточнить типы полей и возможные "
            "значения, затем скорректируй запрос."
        )
    return ""


def _check_unsupported_syntax(query: str) -> str | None:
    """Проверить наличие неподдерживаемого синтаксиса (range, slice) в запросе."""
    range_match = _RANGE_RE.search(query)
    if range_match:
        a, b = int(range_match.group(1)), int(range_match.group(2))
        indices = ", ".join(f"$values[{i}]" for i in range(a, b + 1))
        return (
            f"Синтаксис range `[{a}..{b}]` не поддерживается сервером.\n"
            "Перепишите запрос — явно перечислите нужные индексы:\n\n"
            f"  Было:   ...[{a}..{b}]\n"
            f"  Стало:  $values := <запрос-без-range>; $result := [{indices}]"
        )

    slice_match = _SLICE_RE.search(query)
    if slice_match and (slice_match.group(1) or slice_match.group(2)):
        raw_start = slice_match.group(1)
        raw_end = slice_match.group(2)
        slice_repr = f"{raw_start or ''}:{raw_end or ''}"
        start = int(raw_start) if raw_start else 0
        if raw_end:
            end = int(raw_end)
            indices = ", ".join(f"$values[{i}]" for i in range(start, end))
        else:
            indices = f"$values[{start}], $values[{start + 1}], ..."
        msg = (
            f"Синтаксис slice `[{slice_repr}]` не поддерживается сервером.\n"
            "Перепишите запрос — явно перечислите нужные индексы:\n\n"
            f"  Было:   ...[{slice_repr}]\n"
            f"  Стало:  $values := <запрос-без-slice>; $result := [{indices}]"
        )
        return msg + _SLICE_HINT

    return None


def _check_lookup_string_arg(query: str) -> str | None:
    """Проверить корректность первого аргумента $lookup."""
    bad_matches = list(_LOOKUP_STRING_ARG_RE.finditer(query))
    if not bad_matches:
        return None

    chain_lookup_starts = set()
    for m in _LOOKUP_CHAIN_RE.finditer(query):
        chain_lookup_starts.add(query.index("$lookup", m.start(), m.end()))

    for m in bad_matches:
        if m.start() not in chain_lookup_starts:
            return (
                "Некорректный вызов $lookup: первый аргумент является строкой, "
                "но $lookup ожидает объект (коллекцию).\n"
                "Для поиска задай контекст через путь JSONata или переменную:\n\n"
                "  Было:   $lookup('коллекция', ключ)\n"
                "  Стало:  $lookup($.'коллекция', ключ)\n"
                "    или:  ($col := $.'коллекция'; $lookup($col, ключ))\n\n"
                "Примечание: в chain-нотации ~>$lookup(...) строковый аргумент "
                "является ключом поиска — такой запрос корректен."
            )

    return None


def _check_undefined_custom_functions(query: str) -> str | None:
    """Проверить, что нестандартные функции $values/$take объявлены в запросе."""
    missing = [
        name
        for name, call_re in _CUSTOM_FUNC_CALL_RE.items()
        if call_re.search(query) and not _CUSTOM_FUNC_DEF_RE[name].search(query)
    ]
    if not missing:
        return None

    listed = ", ".join(f"${n}()" for n in missing)
    defs = "\n".join(_POLYFILL_HINTS[name] for name in missing)
    return (
        f"{listed} — не встроенные функции JSONata и не объявлены в запросе.\n"
        "Необходимо объявить каждую перед использованием:\n\n"
        f"```\n{defs}\n```\n\n"
        "либо переписать запрос без их использования."
    )


def _check_query_safety(query: str) -> str | None:
    """Проверить безопасность JSONata запроса перед выполнением."""
    if query.strip() == "$":
        return (
            "Выполнение запроса '$' вернёт весь объект целиком — это создаёт "
            "избыточную нагрузку на сервер, и результат не может быть обработан "
            "LLM из-за ограничений контекста. "
            "Для работы следует использовать техники исследования и "
            "прогрессивного раскрытия данных."
        )
    return None


def _is_empty_result(decoded: str) -> bool:
    """Проверить, является ли результат JSONata запроса пустым."""
    return decoded.strip() in _EMPTY_JSONATA_VALUES


def _is_empty_analysis(decoded: str) -> bool:
    """Проверить, указывает ли результат анализа на пустой исходный запрос."""
    try:
        parsed = json.loads(decoded)
    except (json.JSONDecodeError, ValueError):
        return False
    if not isinstance(parsed, dict):
        return False
    rt = parsed.get("type")
    if rt == "null":
        return True
    if rt == "array" and parsed.get("count") == 0:
        return True
    if rt == "object":
        schema = parsed.get("schema")
        if isinstance(schema, list) and len(schema) == 0:
            return True
    return False


def _element_type_ru(element_type: str | None) -> str:
    """Преобразовать JSONata-тип элемента массива в русское название."""
    mapping = {
        "string": "строк",
        "number": "чисел",
        "boolean": "булево",
        "object": "объектов",
    }
    return mapping.get(element_type or "", "элементов")


def _transform_schema(schema: list[dict] | dict) -> dict:  # type: ignore[type-arg]
    """Преобразовать схему из формата массива объектов в dict-формат."""
    if isinstance(schema, dict):
        schema = [schema]
    result: dict = {}  # type: ignore[type-arg]
    for field in schema:
        key = field.get("key", "")
        field_info: dict = {"type": field.get("type")}  # type: ignore[type-arg]
        if "present_in" in field:
            field_info["present_in"] = field["present_in"]
        if field.get("field_kind") == "enum":
            field_info["enum_values"] = field.get("values", [])
        result[key] = field_info
    return result


def _append_schema_and_examples(
    parts: list[str],
    schema: list[dict[str, Any]] | None,
    examples: list[Any] | None,
) -> None:
    """Добавить секции схемы и примеров в список частей вывода."""
    if schema:
        parts.append("\nСхема полей:")
        parts.append(
            json.dumps(_transform_schema(schema), ensure_ascii=False, indent=2)
        )  # noqa: E501
    if examples:
        parts.append("\nПримеры записей (выборка):")
        parts.append(json.dumps(examples, ensure_ascii=False, indent=2))


def _format_array_result(data: dict) -> str:  # type: ignore[type-arg]
    """Форматировать результат типа массив."""
    element_type = data.get("element_type")
    count = data.get("count", 0)
    elem_type_ru = _element_type_ru(element_type)

    parts: list[str] = [f"Тип: массив {elem_type_ru} ({count} элементов)"]

    if element_type == "object":
        _append_schema_and_examples(parts, data.get("schema"), data.get("examples"))
    elif data.get("examples"):
        parts.append("\nПримеры записей (выборка):")
        parts.append(json.dumps(data["examples"], ensure_ascii=False, indent=2))

    return "\n".join(parts)


def _format_collection_result(data: dict) -> str:  # type: ignore[type-arg]
    """Форматировать результат типа коллекция объектов (псевдомассив)."""
    count = data.get("count", 0)
    parts: list[str] = [
        f"Тип: коллекция объектов одинаковой структуры ({count} записей)"
    ]
    _append_schema_and_examples(parts, data.get("value_schema"), data.get("examples"))
    return "\n".join(parts)


def _format_plain_object_result(data: dict) -> str:  # type: ignore[type-arg]
    """Форматировать результат типа объект."""
    schema = data.get("schema") or []
    all_object_props = bool(schema) and all(f.get("type") == "object" for f in schema)
    example = data.get("example") or {}

    if all_object_props:
        keys = [f["key"] for f in schema]
        keys_str = ", ".join(f'"{k}"' for k in keys)
        parts: list[str] = [f"Тип: объект (ключи: {keys_str})"]
        for field in schema:
            obj_schema = field.get("object_schema")
            if obj_schema:
                parts.append(f"\nСхема полей «{field['key']}»:")
                formatted = json.dumps(
                    _transform_schema(obj_schema), ensure_ascii=False, indent=2
                )  # noqa: E501
                parts.append(formatted)
        if example:
            parts.append("\nПримеры записей (выборка):")
            sample: dict = {}  # type: ignore[type-arg]
            for field in schema:
                k = field["key"]
                v = example.get(k, {})
                if isinstance(v, dict):
                    sample[k] = dict(list(v.items())[:2])
                else:
                    sample[k] = v
            parts.append(json.dumps(sample, ensure_ascii=False, indent=2))
    else:
        parts = ["Тип: объект"]
        if example:
            parts.append("\nПримеры записей (выборка):")
            parts.append(json.dumps(example, ensure_ascii=False, indent=2))

    return "\n".join(parts)


def _format_primitive_result(data: dict) -> str:  # type: ignore[type-arg]
    """Форматировать результат примитивного типа (строка, число, булево)."""
    type_ru = {
        "string": "строка",
        "number": "число",
        "boolean": "булево",
        "null": "null",
    }
    result_type = data.get("type", "")
    type_label = type_ru.get(result_type, result_type)
    parts: list[str] = [f"Тип: {type_label}"]
    value = data.get("value")
    if value is not None:
        parts.append("\nЗначение:")
        parts.append(json.dumps(value, ensure_ascii=False, indent=2))
    return "\n".join(parts)


def _format_describe_result(data: dict) -> str:  # type: ignore[type-arg]
    """Форматировать результат анализа JSONata в читаемый формат."""
    result_type = data.get("type")
    if result_type == "array":
        body = _format_array_result(data)
    elif result_type == "object":
        if data.get("all_values_equal") and data.get("value_type") == "object":
            body = _format_collection_result(data)
        else:
            body = _format_plain_object_result(data)
    else:
        body = _format_primitive_result(data)
    return _DESCRIBE_HEADER + body + _DESCRIBE_FOOTER


def _analyze_large_response(decoded: str) -> str:
    """Сформировать информативное сообщение о слишком большом ответе."""
    base = (
        f"Результат запроса слишком велик ({len(decoded):,} символов) — "
        "попытка его обработать приведёт к переполнению контекста LLM. "
        "Для работы следует использовать техники исследования репозитория "
        "и прогрессивного раскрытия."
    )
    try:
        parsed = json.loads(decoded)
    except (json.JSONDecodeError, ValueError):
        return base + _SLICE_HINT

    if isinstance(parsed, list):
        n = len(parsed)
        mid = n // 2
        split_tip = (
            f"\n\nРезультат — массив из {n} элементов. "
            "Разделите запрос на 2 или более частей с помощью $slice:\n"
            f"  Первая половина:  $slice(<запрос>, 0, {mid})\n"
            f"  Вторая половина:  $slice(<запрос>, {mid}, {n})"
        )
        return base + split_tip + _SLICE_HINT
    if isinstance(parsed, dict):
        keys = list(parsed.keys())
        return f"{base}\n\nКлючи первого уровня объекта: {keys}" + _SLICE_HINT
    return base + _SLICE_HINT


def _build_analyze_query(user_query: str) -> str:
    """Строит meta-JSONata выражение для анализа структуры результата запроса."""
    return (
        "(\n"
        "  $r := (" + user_query + ");\n"
        "  $rt := $type($r);\n"
        '  $rt = "array" ?\n'
        "    ( $n := $count($r); $elem0 := $r[0]; $et := $type($elem0);\n"
        "      $af := function($v, $k){(\n"
        "        $ft := $type($v);\n"
        "        $cov := $count($filter($r, function($item){ $exists($lookup($item,$k)) }));\n"  # noqa: E501
        '        $cov_str := $string($cov) & "/" & $string($n);\n'
        '        ($ft = "string" or $ft = "number" or $ft = "boolean") ?\n'
        "          ( $vals := $distinct($map($r, function($item){ $lookup($item,$k) }));\n"  # noqa: E501
        "            $card := $count($vals);\n"
        "            ($card / $n <= "
        + str(_CARDINALITY_THRESHOLD_PCT)
        + " and $card <= "
        + str(_CARDINALITY_THRESHOLD_ABS)
        + ") ?\n"
        '              {"key":$k,"type":$ft,"field_kind":"enum","values":$vals,"present_in":$cov_str} :\n'  # noqa: E501
        '              {"key":$k,"type":$ft,"field_kind":"free_form","value_example":$v,"present_in":$cov_str}\n'  # noqa: E501
        "          ) :\n"
        '        $ft = "object" ?\n'
        '          {"key":$k,"type":$ft,"present_in":$cov_str,\n'
        '           "object_schema":$each($v, function($sv,$sk){{"key":$sk,"type":$type($sv)}})} :\n'  # noqa: E501
        '        $ft = "array" ?\n'
        '          {"key":$k,"type":$ft,"present_in":$cov_str,\n'
        '           "count_sample":$count($v),"element_type":$type($v[0])} :\n'
        '        {"key":$k,"type":$ft,"present_in":$cov_str}\n'
        "      )};\n"
        '      {"type":"array","count":$n,"element_type":$et,\n'
        '       "schema": $et = "object" ? $each($elem0, $af) : null,\n'
        '       "examples": $et = "object" ?\n'
        "         $filter([$r[0],$r[1],$r[2],$r[3]], function($v){$exists($v)}) :\n"
        "         $filter([$r[0],$r[1],$r[2],$r[3],$r[4],$r[5],$r[6],$r[7],$r[8],$r[9],"
        "$r[10],$r[11],$r[12],$r[13],$r[14],$r[15],$r[16],$r[17],$r[18],$r[19]],"
        "function($v){$exists($v)})}\n"
        "    ) :\n"
        '  $rt = "object" ?\n'
        "  (\n"
        "    $keys_r := $keys($r); $n := $count($keys_r);\n"
        "    $first_val := $lookup($r, $keys_r[0]);\n"
        "    $first_type := $type($first_val);\n"
        "    $check10 := $filter(\n"
        "      [$keys_r[0],$keys_r[1],$keys_r[2],$keys_r[3],$keys_r[4],\n"
        "       $keys_r[5],$keys_r[6],$keys_r[7],$keys_r[8],$keys_r[9]],\n"
        "      function($k){ $exists($k) }\n"
        "    );\n"
        "    $n_sample := $count($check10);\n"
        "    $all_same_type := $count($filter($check10,\n"
        "      function($k){ $type($lookup($r,$k)) != $first_type })) = 0;\n"
        '    $has_common_field := $first_type != "object" or (\n'
        "      $sample_vals := $map($check10, function($k){ $lookup($r,$k) });\n"
        "      $first_keys := $keys($first_val);\n"
        "      $count($first_keys) > 0 and\n"
        "      $max($map($first_keys, function($fk){\n"
        "        $count($filter($sample_vals,\n"
        "          function($obj){ $exists($lookup($obj,$fk)) })) / $n_sample\n"
        "      })) >= 0.8\n"
        "    );\n"
        '    $all_equal := $n > 1 and $all_same_type and $first_type = "object" and $has_common_field;\n'  # noqa: E501
        "    $all_equal ?\n"
        "    (\n"
        "      $vals_arr := $each($r, function($v,$k){ $v });\n"
        "      $af_map := function($sv, $sk){(\n"
        "        $ft := $type($sv);\n"
        "        $cov := $count($filter($vals_arr, function($item){ $exists($lookup($item,$sk)) }));\n"  # noqa: E501
        '        $cov_str := $string($cov) & "/" & $string($n);\n'
        '        ($ft = "string" or $ft = "number" or $ft = "boolean") ?\n'
        "          ( $vls := $distinct($map($vals_arr, function($item){ $lookup($item,$sk) }));\n"  # noqa: E501
        "            $card := $count($vls);\n"
        "            ($card / $n <= "
        + str(_CARDINALITY_THRESHOLD_PCT)
        + " and $card <= "
        + str(_CARDINALITY_THRESHOLD_ABS)
        + ") ?\n"
        '              {"key":$sk,"type":$ft,"field_kind":"enum","values":$vls,"present_in":$cov_str} :\n'  # noqa: E501
        '              {"key":$sk,"type":$ft,"field_kind":"free_form","value_example":$sv,"present_in":$cov_str}\n'  # noqa: E501
        "          ) :\n"
        '        $ft = "object" ?\n'
        '          {"key":$sk,"type":$ft,"present_in":$cov_str,\n'
        '           "object_schema":$each($sv,function($sv2,$sk2){{"key":$sk2,"type":$type($sv2)}})} :\n'  # noqa: E501
        '        $ft = "array" ?\n'
        '          {"key":$sk,"type":$ft,"present_in":$cov_str,\n'
        '           "count_sample":$count($sv),"element_type":$type($sv[0])} :\n'
        '        {"key":$sk,"type":$ft,"present_in":$cov_str}\n'
        "      )};\n"
        "      $ex_keys_ps := $filter([$keys_r[0],$keys_r[1],$keys_r[2],$keys_r[3]], function($k){$exists($k)});\n"  # noqa: E501
        '      {"type":"object","all_values_equal":true,"count":$n,\n'
        '       "key_sample":$filter([$keys_r[0],$keys_r[1],$keys_r[2]],function($k){$exists($k)}),\n'  # noqa: E501
        '       "value_type":$type($first_val),\n'
        '       "value_schema":$type($first_val) = "object" ? $each($first_val,$af_map) : null,\n'  # noqa: E501
        '       "examples": $merge($map($ex_keys_ps, function($k){ {$k: $lookup($r,$k)} }))}\n'  # noqa: E501
        "    ) :\n"
        '    {"type":"object","schema":$each($r, function($v,$k){(\n'
        "      $ft := $type($v);\n"
        '      $ft = "object" ?\n'
        '        {"key":$k,"type":$ft,\n'
        '         "object_schema":$each($v, function($sv,$sk){{"key":$sk,"type":$type($sv)}})} :\n'  # noqa: E501
        '      $ft = "array" ?\n'
        '        {"key":$k,"type":$ft,"count":$count($v),"element_type":$type($v[0])} :\n'  # noqa: E501
        '      {"key":$k,"type":$ft}\n'
        "    )}),\n"
        '    "example": $r}\n'
        "  ) :\n"
        '  {"type":$rt,"value":$r}\n'
        ")"
    )


def _format_sample_section(sample: object) -> str:
    """Форматировать секцию образцов: информация отдельно, данные отдельно."""
    if (
        not isinstance(sample, dict)
        or "_sample_info" not in sample
        or "data" not in sample
    ):  # noqa: E501
        return json.dumps(sample, ensure_ascii=False, indent=2)

    info = sample["_sample_info"]
    data = sample["data"]

    if isinstance(info, dict):
        sample_type = info.get("type")
        if sample_type == "array":
            total = info.get("total", "?")
            shown = info.get("shown", "?")
            info_text = f"Тип: массив | Всего записей: {total} | Показано: {shown}"
        elif sample_type == "object":
            total_keys = info.get("total_keys", "?")
            shown_keys = info.get("shown_keys", "?")
            info_text = (
                f"Тип: объект | Всего ключей: {total_keys} | Показано: {shown_keys}"
            )
        else:
            info_text = json.dumps(info, ensure_ascii=False)
    else:
        info_text = str(info)

    data_text = json.dumps(data, ensure_ascii=False, indent=2)
    return f"Информация:\n{info_text}\n\nПримеры данных:\n{data_text}"


def _make_api_client(
    host: str, cert_path: str | None, cert_password: str | None
) -> SecuredApiCall:
    """Создать клиент API с опциональным сертификатом."""
    return SecuredApiCall(
        host_name=host,
        cert_file_path=Path(cert_path) if cert_path else None,
        cert_password=cert_password,
    )


# ---------------------------------------------------------------------------
# Async API-функции (используются MCP-инструментами)
# ---------------------------------------------------------------------------


async def call_secured_api(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    endpoint: str,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Вызов API с опциональным клиентским сертификатом.

    Args:
        host: Имя хоста сервера (например, "seafile.example.com").
        cert_path: Путь к файлу сертификата (P12/PFX). None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        endpoint: Относительный путь API endpoint.
        ctx: Контекст MCP.

    Returns:
        str: Текст ответа от сервера.
    """
    logger.info("Запрос: call_secured_api(host=%s, endpoint=%s)", host, endpoint)
    try:
        await ctx.info(f"Подключение к https://{host}{endpoint}")
        api_client = _make_api_client(host, cert_path, cert_password)
        response = api_client.get(endpoint)
        response.raise_for_status()
        await ctx.info(f"Получен ответ: {response.status_code}")
        return _decode_json_response(response.text)
    except Exception as e:
        detail = _http_error_detail(e)
        err_msg = _clean_error_msg(e)
        logger.error("Ошибка вызова API [%s]: %s%s", type(e).__name__, err_msg, detail)
        raise ValueError(
            f"Ошибка вызова API [{type(e).__name__}]: {err_msg}{detail}"
        ) from e


async def execute_jsonata_query(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    query: str,
    purpose: str,
    expected_data: str,
    user_request: str,
    current_plan_step: str,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Выполнение JSONata запроса к Seafile серверу с валидацией и защитой.

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата (P12/PFX). None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        query: JSONata выражение для выполнения.
        purpose: Цель запроса.
        expected_data: Ожидаемые данные.
        user_request: Исходный запрос пользователя.
        current_plan_step: Текущий пункт плана.
        ctx: Контекст MCP.

    Returns:
        str: Результат выполнения JSONata запроса.
    """
    logger.info("execute_jsonata_query(host=%s, query=%s)", host, query)
    try:
        safety_warning = _check_query_safety(query)
        if safety_warning:
            return safety_warning

        syntax_warning = _check_unsupported_syntax(query)
        if syntax_warning:
            return syntax_warning

        lookup_warning = _check_lookup_string_arg(query)
        if lookup_warning:
            return lookup_warning

        custom_func_warning = _check_undefined_custom_functions(query)
        if custom_func_warning:
            return custom_func_warning

        await ctx.info(
            f"Выполнение JSONata запроса: {query}\n"
            f"Запрос пользователя: {user_request}\n"
            f"Текущий шаг плана: {current_plan_step}\n"
            f"Цель: {purpose}\n"
            f"Ожидаемые данные: {expected_data}"
        )

        api_client = _make_api_client(host, cert_path, cert_password)
        jsonata_client = SeafJsonataCall(api_client)
        result = jsonata_client.eval_jsonata(query)

        await ctx.info("JSONata запрос выполнен успешно")
        decoded = _decode_json_response(result)
        logger.info("Ответ сервера JSONata: %s", decoded)

        if len(decoded) > SEAF_MAX_JSONATA_RESPONSE_CHARS:
            logger.warning(
                "Результат запроса слишком велик: %d символов (лимит %d)",
                len(decoded),
                SEAF_MAX_JSONATA_RESPONSE_CHARS,
            )
            write_jsonata_log_entry(
                query=query,
                purpose=purpose,
                expected_data=expected_data,
                status="non_empty",
                user_request=user_request,
                current_plan_step=current_plan_step,
            )
            return _analyze_large_response(decoded)

        if _is_empty_result(decoded):
            logger.info("JSONata запрос вернул пустой результат: %r", decoded)
            write_jsonata_log_entry(
                query=query,
                purpose=purpose,
                expected_data=expected_data,
                status="empty",
                user_request=user_request,
                current_plan_step=current_plan_step,
            )
            return decoded + _EMPTY_RESULT_NOTE

        write_jsonata_log_entry(
            query=query,
            purpose=purpose,
            expected_data=expected_data,
            status="non_empty",
            user_request=user_request,
            current_plan_step=current_plan_step,
        )
        return decoded

    except Exception as e:
        detail = _http_error_detail(e)
        response_text = getattr(getattr(e, "response", None), "text", "")
        hint = _jsonata_error_hint(response_text)
        err_msg = _clean_error_msg(e)
        logger.error(
            "Ошибка выполнения JSONata запроса [%s]: %s%s",
            type(e).__name__,
            err_msg,
            detail,
        )
        write_jsonata_log_entry(
            query=query,
            purpose=purpose,
            expected_data=expected_data,
            status="error",
            user_request=user_request,
            current_plan_step=current_plan_step,
            error=f"[{type(e).__name__}]: {err_msg}{detail}",
        )
        suppress_detail = _jsonata_is_non_function_error(response_text)
        raise ValueError(
            f"Ошибка выполнения JSONata запроса [{type(e).__name__}]: "
            f"{err_msg}{'' if suppress_detail else detail}{hint}"
        ) from e


async def execute_jsonata_raw(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    query: str,
) -> str:
    """Выполнить JSONata-запрос без валидации и MCP-контекста.

    Используется только для внутренних нужд сервера (построение каталога сущностей).

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата (P12/PFX). None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        query: JSONata выражение для выполнения.

    Returns:
        str: Сырой результат от API в виде строки (JSON).
    """
    api_client = _make_api_client(host, cert_path, cert_password)
    jsonata_client = SeafJsonataCall(api_client)
    return jsonata_client.eval_jsonata(query)


async def explore_data_schema(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    path: str,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Исследование схемы данных SEAF хранилища.

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата. None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        path: Путь к объекту (пустая строка — корень хранилища).
        ctx: Контекст MCP.

    Returns:
        str: Схема данных в JSON формате.
    """
    logger.info("explore_data_schema(host=%s, path=%r)", host, path)
    try:
        api_client = _make_api_client(host, cert_path, cert_password)
        jsonata_client = SeafJsonataCall(api_client)

        if not path.strip():
            query = (
                "$each($, function($v,$k)"
                '{{"key":$k,"type":$type($v),"count":$count($v)}})'
            )
            await ctx.info("Исследование схемы: корень")
            result = jsonata_client.eval_jsonata(query)
            decoded = _decode_json_response(result)
        else:
            jp = _to_jsonata_path(path)
            jp_entities = "$.'entities'" + jp[1:]

            schema_query = jp_entities + "~>|**|{},['presentations','menu','objects']|"
            logger.info("Запрос JSONSchema: %s", schema_query)
            await ctx.info(f"Поиск JSONSchema для: {path}")
            schema_raw = jsonata_client.eval_jsonata(schema_query)
            schema_decoded = _decode_json_response(schema_raw)

            try:
                schema_value = json.loads(schema_decoded)
            except (json.JSONDecodeError, ValueError):
                schema_value = None

            if schema_value:
                decoded = json.dumps({"json_schema": schema_value}, ensure_ascii=False)
            else:
                logger.info("JSONSchema не найдена, запускаем дискавери: %r", path)
                await ctx.info(f"JSONSchema не найдена, анализ данных: {path}")
                discovery_query = (
                    "($p := "
                    + jp
                    + "; $exists($p)"
                    + ' ? ($type($p) = "array"'
                    + ' ? {"count":$count($p),"schema":$each($p[0],function($v,$k){{"key":$k,"type":$type($v)}})}'  # noqa: E501
                    + ' : {"schema":$each($p,function($v,$k){{"key":$k,"type":$type($v)}})})'  # noqa: E501
                    + " : null)"
                )
                logger.info("Запрос дискавери: %s", discovery_query)
                discovery_raw = jsonata_client.eval_jsonata(discovery_query)
                discovery_decoded = _decode_json_response(discovery_raw)
                try:
                    discovery_value = json.loads(discovery_decoded)
                except (json.JSONDecodeError, ValueError):
                    discovery_value = discovery_decoded
                if discovery_value is None:
                    logger.warning("Путь не найден при дискавери: %r", path)
                    return f"Объект '{path}' не найден или не содержит данных."
                decoded = json.dumps(
                    {"data_driven_schema": discovery_value}, ensure_ascii=False
                )

        if len(decoded) > SEAF_MAX_JSONATA_RESPONSE_CHARS:
            return _analyze_large_response(decoded)

        return decoded

    except Exception as e:
        detail = _http_error_detail(e)
        err_msg = _clean_error_msg(e)
        logger.error(
            "Ошибка explore_data_schema [%s]: %s%s", type(e).__name__, err_msg, detail
        )
        raise ValueError(
            f"Ошибка explore_data_schema [{type(e).__name__}]: {err_msg}{detail}"
        ) from e


async def describe_jsonata_result(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    query: str,
    ctx: Context,  # type: ignore[type-arg]
    query_goal: str = "",
) -> str:
    """Анализ структуры результата JSONata запроса.

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата. None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        query: JSONata выражение для анализа.
        ctx: Контекст MCP.
        query_goal: Что агент ожидал найти (на русском).

    Returns:
        str: Читаемый текст с заголовком типа, схемой полей и примером данных.
    """
    logger.info("describe_jsonata_result(host=%s, query=%s)", host, query)
    try:
        safety_warning = _check_query_safety(query)
        if safety_warning:
            return safety_warning

        meta_query = _build_analyze_query(query)
        await ctx.info(
            f"Анализ структуры результата: {query}"
            + (f"\nЦель: {query_goal}" if query_goal else "")
        )

        api_client = _make_api_client(host, cert_path, cert_password)
        jsonata_client = SeafJsonataCall(api_client)
        result = jsonata_client.eval_jsonata(meta_query)

        await ctx.info("Анализ завершён успешно")
        decoded = _decode_json_response(result)
        data = json.loads(decoded)

        if _is_empty_analysis(decoded):
            write_jsonata_log_entry(
                query=query,
                purpose=query_goal or "Анализ структуры результата запроса",
                expected_data="Структурное описание результата JSONata запроса",
                status="empty",
                tool="describe_query_result",
            )
            return _format_empty_analysis(query_goal)

        write_jsonata_log_entry(
            query=query,
            purpose=query_goal or "Анализ структуры результата запроса",
            expected_data="Структурное описание результата JSONata запроса",
            status="non_empty",
            tool="describe_query_result",
        )
        return _format_describe_result(data)

    except Exception as e:
        detail = _http_error_detail(e)
        response_text = getattr(getattr(e, "response", None), "text", "")
        hint = _jsonata_error_hint(response_text)
        err_msg = _clean_error_msg(e)
        logger.error(
            "Ошибка describe_jsonata_result [%s]: %s%s",
            type(e).__name__,
            err_msg,
            detail,
        )
        write_jsonata_log_entry(
            query=query,
            purpose=query_goal or "Анализ структуры результата запроса",
            expected_data="Структурное описание результата JSONata запроса",
            status="error",
            tool="describe_query_result",
            error=f"[{type(e).__name__}]: {err_msg}{detail}",
        )
        suppress_detail = _jsonata_is_non_function_error(response_text)
        raise ValueError(
            f"Ошибка describe_jsonata_result [{type(e).__name__}]: "
            f"{err_msg}{'' if suppress_detail else detail}{hint}"
        ) from e


async def explore_data_schema_batch(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    type_ids: list[str],
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Исследование схем нескольких типов SEAF за один вызов.

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата. None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        type_ids: Список SEAF-идентификаторов типов для проверки.
        ctx: Контекст MCP.

    Returns:
        str: JSON-объект {type_id: schema | "NOT_FOUND"}.
    """
    results: dict[str, object] = {}
    for type_id in type_ids:
        try:
            raw = await explore_data_schema(
                host, cert_path, cert_password, type_id, ctx
            )
            if "не найден" in raw and "данных" in raw:
                results[type_id] = _NOT_FOUND_MARKER
            else:
                try:
                    results[type_id] = json.loads(raw)
                except (json.JSONDecodeError, ValueError):
                    results[type_id] = raw
        except Exception as e:
            err_msg = _clean_error_msg(e)
            logger.error("Ошибка при обработке типа %r: %s", type_id, err_msg)
            results[type_id] = f"ERROR: {err_msg}"
    return json.dumps(results, ensure_ascii=False)


async def sample_jsonata_data(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    path: str,
    limit: int,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Получить образцы данных по JSONata-пути.

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата. None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        path: JSONata путь к массиву (например, "library.data").
        limit: Количество элементов (зажимается в [1, MAX_SAMPLE_LIMIT]).
        ctx: Контекст MCP.

    Returns:
        str: Первые N элементов в JSON формате.
    """
    logger.info("sample_jsonata_data(host=%s, path=%r, limit=%d)", host, path, limit)
    try:
        safe_limit = min(max(1, limit), MAX_SAMPLE_LIMIT)
        jp = _to_jsonata_path(path)
        array_items = ",".join(f"$result_to_explore[{i}]" for i in range(safe_limit))
        key_items = ",".join(f"$key_ids[{i}]" for i in range(safe_limit))
        array_branch = (
            '{"_sample_info":{"type":"array","total":$count($result_to_explore),"shown":$count(['
            + array_items
            + '])},"data":['
            + array_items
            + "]}"
        )
        object_branch = (
            "($key_ids:=$keys($result_to_explore);"
            '{"_sample_info":{"type":"object","total_keys":$count($key_ids),"shown_keys":$count(['
            + key_items
            + '])},"data":$merge($map(['
            + key_items
            + "],function($id){{$id:$lookup($result_to_explore,$id)}}))})"
        )
        query = (
            "($result_to_explore := "
            + jp
            + '; $exists($result_to_explore) ? ($type($result_to_explore) = "array" ? '
            + array_branch
            + " : "
            + object_branch
            + ") : {})"
        )

        await ctx.info(f"Получение образцов: {path} (limit={safe_limit})")
        api_client = _make_api_client(host, cert_path, cert_password)
        jsonata_client = SeafJsonataCall(api_client)
        result = jsonata_client.eval_jsonata(query)
        decoded = _decode_json_response(result)

        if len(decoded) > SEAF_MAX_JSONATA_RESPONSE_CHARS:
            return _analyze_large_response(decoded)

        return decoded

    except Exception as e:
        detail = _http_error_detail(e)
        err_msg = _clean_error_msg(e)
        logger.error(
            "Ошибка sample_jsonata_data [%s]: %s%s", type(e).__name__, err_msg, detail
        )
        raise ValueError(
            f"Ошибка sample_jsonata_data [{type(e).__name__}]: {err_msg}{detail}"
        ) from e


async def sample_jsonata_data_batch(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    type_ids: list[str],
    limit: int,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Получить образцы данных для нескольких типов SEAF за один вызов.

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата. None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        type_ids: Список SEAF-идентификаторов типов для проверки.
        limit: Количество образцов на тип (1-10).
        ctx: Контекст MCP.

    Returns:
        str: JSON-объект {type_id: [samples] | "NOT_FOUND"}.
    """
    results: dict[str, object] = {}
    for type_id in type_ids:
        try:
            raw = await sample_jsonata_data(
                host, cert_path, cert_password, type_id, limit, ctx
            )
            decoded = raw.strip()
            if decoded in ("{}", "[]", "null"):
                results[type_id] = _NOT_FOUND_MARKER
            else:
                try:
                    results[type_id] = json.loads(raw)
                except (json.JSONDecodeError, ValueError):
                    results[type_id] = raw
        except Exception as e:
            err_msg = _clean_error_msg(e)
            logger.error("Ошибка при получении образцов типа %r: %s", type_id, err_msg)
            results[type_id] = f"ERROR: {err_msg}"
    return json.dumps(results, ensure_ascii=False)


async def inspect_entities_batch(
    host: str,
    cert_path: str | None,
    cert_password: str | None,
    type_ids: list[str],
    limit: int,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Исследовать схему и получить образцы данных для нескольких типов SEAF.

    Объединяет explore_data_schema_batch и sample_jsonata_data_batch.

    Args:
        host: Имя хоста сервера.
        cert_path: Путь к файлу сертификата. None — без сертификата.
        cert_password: Пароль для расшифровки сертификата.
        type_ids: Список SEAF-идентификаторов типов.
        limit: Количество образцов на тип (1-10, по умолчанию 3).
        ctx: Контекст MCP.

    Returns:
        str: Текстовое описание для каждого типа (схема + примеры), разделённое "---".
    """
    logger.info(
        "inspect_entities_batch(host=%s, type_ids=%r, limit=%d)", host, type_ids, limit
    )
    try:
        schemas_raw = await explore_data_schema_batch(
            host, cert_path, cert_password, type_ids, ctx
        )
        samples_raw = await sample_jsonata_data_batch(
            host, cert_path, cert_password, type_ids, limit, ctx
        )
        schemas: dict[str, object] = json.loads(schemas_raw)
        samples: dict[str, object] = json.loads(samples_raw)

        sections: list[str] = []
        for type_id in type_ids:
            schema = schemas.get(type_id, _NOT_FOUND_MARKER)
            sample = samples.get(type_id, _NOT_FOUND_MARKER)
            if schema == _NOT_FOUND_MARKER and sample == _NOT_FOUND_MARKER:
                sections.append(f"Для типа: {type_id}\nТип не найден в SEAF.")
            else:
                if schema == _NOT_FOUND_MARKER:
                    schema_text = "Схема не найдена."
                elif isinstance(schema, dict) and "json_schema" in schema:
                    js = schema["json_schema"]
                    if isinstance(js, dict) and "schema" in js:
                        schema_text = json.dumps(
                            js["schema"], ensure_ascii=False, indent=2
                        )
                    else:
                        schema_text = json.dumps(js, ensure_ascii=False, indent=2)
                else:
                    schema_text = json.dumps(schema, ensure_ascii=False, indent=2)

                if sample == _NOT_FOUND_MARKER:
                    sample_section = "Примеры данных:\nПримеры не найдены."
                else:
                    sample_section = _format_sample_section(sample)

                sections.append(
                    f"Для типа: {type_id}\n"
                    f"Схема:\n{schema_text}\n\n"
                    f"{sample_section}\n\n"
                    f"Когда пишешь запрос к данным в {type_id}, "
                    f"используй только полученную структуру данных "
                    f"и только существующие поля."
                )

        type_ids_str = ", ".join(type_ids)
        status = (
            "non_empty"
            if any(s != _NOT_FOUND_MARKER for s in schemas.values())
            else "empty"
        )
        write_jsonata_log_entry(
            query=type_ids_str,
            purpose=f"Исследование схемы и образцов для типов: {type_ids_str}",
            expected_data="Схема полей и примеры записей для каждого типа",
            status=status,
            tool="inspect_entity_schema",
        )
        return "\n\n---\n\n".join(sections)

    except Exception as e:
        err_msg = _clean_error_msg(e)
        detail = _http_error_detail(e)
        write_jsonata_log_entry(
            query=", ".join(type_ids),
            purpose=f"Исследование схемы и образцов для типов: {', '.join(type_ids)}",
            expected_data="Схема полей и примеры записей для каждого типа",
            status="error",
            tool="inspect_entity_schema",
            error=f"[{type(e).__name__}]: {err_msg}{detail}",
        )
        raise ValueError(
            f"Ошибка inspect_entities_batch [{type(e).__name__}]: {err_msg}{detail}"
        ) from e
