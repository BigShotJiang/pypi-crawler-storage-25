"""
Mosesaic MCP Server implementation.

Wraps a running mosesaic-server HTTP API and exposes its agents as MCP tools.
The server process is started automatically by Claude Code (via .mcp.json) and
communicates over stdio.
"""

from __future__ import annotations

import json
import os
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

# ── Server URL ────────────────────────────────────────────────────────────────

_DEFAULT_URL = "http://localhost:8000"


def _url() -> str:
    return os.environ.get("MOSESAIC_SERVER_URL", _DEFAULT_URL).rstrip("/")


# ── FastMCP instance ──────────────────────────────────────────────────────────

mcp = FastMCP(
    name="mosesaic",
    instructions=(
        "Tools for running and inspecting Mosesaic agents. "
        "Use run_agent to execute an agent with a payload and get the result. "
        "Use list_agents to discover what agents are available. "
        "Use get_events to see the full message history for a run."
    ),
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _client() -> httpx.Client:
    return httpx.Client(base_url=_url(), timeout=60.0)


def _fmt_event(e: dict[str, Any]) -> str:
    ts = e.get("timestamp", "")[:19]  # ISO without fractional seconds
    frm = e.get("from_agent", "?")
    to = e.get("to_agent", "?")
    typ = e.get("type", "?")
    payload = e.get("payload")
    payload_str = json.dumps(payload) if payload is not None else "(none)"
    if len(payload_str) > 120:
        payload_str = payload_str[:117] + "..."
    return f"[{ts}] {frm} → {to}  ({typ})  {payload_str}"


# ── Tools ─────────────────────────────────────────────────────────────────────

@mcp.tool()
def list_agents() -> str:
    """
    List all agents registered on the Mosesaic server.

    Returns a formatted list of agent names. Use run_agent(name, payload)
    to execute any of them.
    """
    with _client() as c:
        try:
            resp = c.get("/agents")
            resp.raise_for_status()
        except httpx.ConnectError:
            return (
                f"Cannot connect to Mosesaic server at {_url()}.\n"
                "Start it first: uv run uvicorn myserver:app --port 8000 --reload\n"
                "Or set MOSESAIC_SERVER_URL to the correct address."
            )

    agents: list[str] = resp.json()
    if not agents:
        return "No agents registered. Import and register agents before starting the server."
    return "Registered agents:\n" + "\n".join(f"  • {a}" for a in agents)


@mcp.tool()
def run_agent(
    name: str,
    payload: str,
    timeout_seconds: int = 30,
) -> str:
    """
    Run a Mosesaic agent and return its result.

    Args:
        name:            Agent name (from list_agents).
        payload:         Input to the agent. Can be a plain string or JSON.
        timeout_seconds: Max seconds to wait for completion (default 30).

    Returns a summary with: status, result, run_id, and the last few events.
    Use get_events(trace_id=...) for the full message log.
    """
    # Try to parse payload as JSON; fall back to raw string
    try:
        parsed_payload: Any = json.loads(payload)
    except (json.JSONDecodeError, ValueError):
        parsed_payload = payload

    body = {
        "payload": parsed_payload,
        "wait": True,
        "timeout_seconds": timeout_seconds,
    }

    with _client() as c:
        try:
            resp = c.post(f"/agents/{name}/run", json=body, timeout=timeout_seconds + 10)
        except httpx.ConnectError:
            return (
                f"Cannot connect to Mosesaic server at {_url()}.\n"
                "Start it first: uv run uvicorn myserver:app --port 8000 --reload"
            )

    if resp.status_code == 404:
        return f"Agent '{name}' not found. Use list_agents() to see available agents."

    if not resp.is_success:
        return f"Server error {resp.status_code}: {resp.text}"

    data = resp.json()
    status = data.get("status", "unknown")
    result = data.get("result")
    error = data.get("error")
    run_id = data.get("run_id", "")
    trace_id = data.get("trace_id", "")

    lines = [f"Agent: {name}", f"Status: {status}", f"Run ID: {run_id}"]

    if error:
        lines.append(f"Error: {error}")
    elif result is not None:
        result_str = json.dumps(result) if not isinstance(result, str) else result
        if len(result_str) > 500:
            result_str = result_str[:497] + "..."
        lines.append(f"Result: {result_str}")

    # Fetch and show the last few events inline
    with _client() as c:
        evresp = c.get("/events", params={"trace_id": trace_id})
    if evresp.is_success:
        events = evresp.json()
        if events:
            lines.append(f"\nEvent log ({len(events)} messages):")
            for e in events[-8:]:  # last 8 events
                lines.append("  " + _fmt_event(e))
            if len(events) > 8:
                lines.append(f"  ... and {len(events) - 8} earlier events")
            lines.append(f"\nFull log: get_events(trace_id='{trace_id}')")

    return "\n".join(lines)


@mcp.tool()
def list_runs(limit: int = 20) -> str:
    """
    List recent agent and workflow runs on the Mosesaic server.

    Args:
        limit: Maximum number of runs to show (default 20).

    Returns run IDs, names, statuses, and timestamps.
    Use get_run(run_id) for full details including the result.
    """
    with _client() as c:
        try:
            resp = c.get("/runs")
            resp.raise_for_status()
        except httpx.ConnectError:
            return f"Cannot connect to Mosesaic server at {_url()}."

    runs: list[dict] = resp.json()
    if not runs:
        return "No runs recorded yet. Use run_agent() to execute an agent."

    # Most-recent first
    runs = runs[-limit:][::-1]

    lines = [f"Recent runs ({len(runs)} shown):"]
    for r in runs:
        created = r.get("created_at", "")[:19]
        status = r.get("status", "?")
        kind = r.get("kind", "?")
        name = r.get("name", "?")
        run_id = r.get("run_id", "?")
        icon = {"completed": "✓", "failed": "✗", "running": "…", "timed_out": "⏱"}.get(status, "?")
        lines.append(f"  {icon} [{created}] {kind}:{name}  {run_id}")

    return "\n".join(lines)


@mcp.tool()
def get_run(run_id: str) -> str:
    """
    Get full details for a single run by its run_id.

    Args:
        run_id: UUID of the run (from list_runs or run_agent output).

    Returns status, result, error, timing, and trace_id for fetching events.
    """
    with _client() as c:
        try:
            resp = c.get(f"/runs/{run_id}")
        except httpx.ConnectError:
            return f"Cannot connect to Mosesaic server at {_url()}."

    if resp.status_code == 404:
        return f"Run '{run_id}' not found."
    if not resp.is_success:
        return f"Server error {resp.status_code}: {resp.text}"

    r = resp.json()
    lines = [
        f"Run ID:     {r.get('run_id')}",
        f"Trace ID:   {r.get('trace_id')}",
        f"Kind:       {r.get('kind')}",
        f"Name:       {r.get('name')}",
        f"Status:     {r.get('status')}",
        f"Created:    {r.get('created_at', '')[:19]}",
        f"Completed:  {(r.get('completed_at') or '')[:19] or '(still running)'}",
    ]
    if r.get("error"):
        lines.append(f"Error:      {r['error']}")
    if r.get("result") is not None:
        result_str = json.dumps(r["result"]) if not isinstance(r["result"], str) else r["result"]
        lines.append(f"Result:     {result_str}")

    trace_id = r.get("trace_id")
    if trace_id:
        lines.append(f"\nTo see messages: get_events(trace_id='{trace_id}')")

    return "\n".join(lines)


@mcp.tool()
def get_events(
    trace_id: str = "",
    agent: str = "",
) -> str:
    """
    Get the raw message event log from the Mosesaic server.

    Args:
        trace_id: Filter to events from a specific run (recommended).
        agent:    Filter to events involving a specific agent name.

    Returns a chronological log of all messages between agents.
    """
    params: dict[str, str] = {}
    if trace_id:
        params["trace_id"] = trace_id
    if agent:
        params["agent"] = agent

    with _client() as c:
        try:
            resp = c.get("/events", params=params)
            resp.raise_for_status()
        except httpx.ConnectError:
            return f"Cannot connect to Mosesaic server at {_url()}."

    events: list[dict] = resp.json()
    if not events:
        hint = f" for trace_id={trace_id}" if trace_id else ""
        return f"No events found{hint}."

    lines = [f"Event log ({len(events)} messages):"]
    for e in events:
        lines.append("  " + _fmt_event(e))

    return "\n".join(lines)


@mcp.tool()
def orchestrate(
    prompt: str,
    budget_usd: float = 1.0,
    timeout_seconds: int = 120,
) -> str:
    """
    Orchestrate a full AI development lifecycle from a natural language prompt.

    Submits the prompt to a running Mosesaic server, which routes it through
    chief_director → phase directors (clarify, architect, build, verify, deploy).
    Streams events and blocks until completion or timeout.

    Args:
        prompt:          Natural language task description.
        budget_usd:      Maximum spend in USD (default 1.0).
        timeout_seconds: Max seconds to wait for completion (default 120).

    Returns a summary with run_id, phases completed, and final status.
    Use get_run(run_id) for full details and get_events(trace_id=...) for the
    complete message log.
    """
    # Start orchestration run
    with _client() as c:
        try:
            resp = c.post(
                "/orchestrate",
                json={"prompt": prompt, "budget_usd": budget_usd, "wait": False},
                timeout=30.0,
            )
        except httpx.ConnectError:
            return (
                f"Cannot connect to Mosesaic server at {_url()}.\n"
                "Start it first: uv run uvicorn mosesaic.server.app:app --port 8000\n"
                "Or set MOSESAIC_SERVER_URL to the correct address."
            )

    if not resp.is_success:
        return f"Server error {resp.status_code}: {resp.text}"

    run_id = resp.json()["run_id"]

    # Stream SSE events, collecting phase transitions
    phases_seen: list[str] = []
    final_status = "running"
    final_result: str | None = None

    try:
        with httpx.Client(base_url=_url(), timeout=timeout_seconds + 10.0) as stream_client:
            with stream_client.stream("GET", f"/orchestrate/{run_id}/stream") as stream:
                for line in stream.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str in ("[DONE]", "[TIMEOUT]"):
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    # Final status event: has "status" but no agent routing fields
                    if "status" in event and "from" not in event and "to" not in event:
                        final_status = event["status"]
                        raw_result = event.get("result")
                        if raw_result is not None:
                            final_result = str(raw_result)[:300]
                        break

                    # Track phase transitions
                    to_agent = event.get("to", "")
                    if "director" in to_agent and to_agent not in phases_seen:
                        phases_seen.append(to_agent)
    except (httpx.TimeoutException, httpx.ConnectError):
        final_status = "timed_out"

    lines = [
        f"Run ID:  {run_id}",
        f"Status:  {final_status}",
    ]

    if phases_seen:
        phase_names = [p.replace("_director", "") for p in phases_seen]
        lines.append(f"Phases:  {' → '.join(phase_names)}")

    if final_result:
        lines.append(f"Result:  {final_result}")

    lines.append(f"\nFull details: get_run(run_id='{run_id}')")

    # Fetch structured result and append run log
    try:
        with _client() as c:
            result_resp = c.get(f"/orchestrate/{run_id}", timeout=10.0)
    except httpx.ConnectError:
        return "\n".join(lines)

    if result_resp.is_success:
        data = result_resp.json()
        run_log = data.get("run_log") or []
        total_cost_usd = data.get("total_cost_usd", 0.0)
        reasoning = data.get("reasoning", "")

        if run_log:
            lines.append("\n--- Run Log ---")
            lines.append(f"{'Phase':<12} {'Summary':<40} {'Cost':>8}")
            lines.append("-" * 62)
            for entry in run_log:
                summary = entry["summary"][:38] + ".." if len(entry["summary"]) > 40 else entry["summary"]
                lines.append(f"{entry['phase']:<12} {summary:<40} ${entry['cost_usd']:.3f}")
            lines.append("-" * 62)
            lines.append(f"{'':12} {'Total':<40} ${total_cost_usd:.3f}")

        if reasoning:
            lines.append(f"\nChief Director: {reasoning}")

    return "\n".join(lines)


# ── Entry point ───────────────────────────────────────────────────────────────

def create_server() -> FastMCP:
    """Return the configured FastMCP instance (useful for testing)."""
    return mcp


def main() -> None:
    """Run the MCP server over stdio (called by Claude Code subprocess)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
