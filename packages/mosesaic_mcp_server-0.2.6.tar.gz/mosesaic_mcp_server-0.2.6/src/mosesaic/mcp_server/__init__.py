"""
Mosesaic MCP Server — exposes a running mosesaic-server as MCP tools.

Tools available to Claude Code / Cursor / any MCP client:
  • list_agents   — list registered agents
  • run_agent     — run an agent with a payload, get the result
  • list_runs     — recent run history
  • get_run       — full details for one run
  • get_events    — raw event log (optionally filtered by trace_id or agent)

Usage (stdio, auto-started by Claude Code via .mcp.json):
    python -m mosesaic.mcp_server

Environment variables:
    MOSESAIC_SERVER_URL   Base URL of running mosesaic-server
                          (default: http://localhost:8000)
"""

from mosesaic.mcp_server._server import create_server, main

__all__ = ["create_server", "main"]
