from mosesaic.mcp_server._server import main

main()
