"""Tests for mosesaic-mcp-server tools.

Uses respx to mock httpx calls, so no real server is needed.
"""
from __future__ import annotations

import json
from typing import Iterator
from unittest.mock import MagicMock, patch

import httpx
import pytest

from mosesaic.mcp_server._server import (
    list_agents,
    run_agent,
    list_runs,
    get_run,
    get_events,
    orchestrate,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _sse_iter(*events: dict | str) -> Iterator[str]:
    for event in events:
        if isinstance(event, dict):
            yield f"data: {json.dumps(event)}"
        else:
            yield f"data: {event}"


def _mock_client_cm(responses: list[MagicMock]) -> MagicMock:
    """Client context manager that returns each mock response on successive calls."""
    call_count = [-1]

    client = MagicMock()

    def _enter(*args, **kwargs):
        call_count[0] += 1
        return responses[call_count[0]] if call_count[0] < len(responses) else MagicMock()

    cm = MagicMock()
    cm.__enter__ = MagicMock(side_effect=_enter)
    cm.__exit__ = MagicMock(return_value=False)
    return cm


# ── list_agents ───────────────────────────────────────────────────────────────

def test_list_agents_success():
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    resp.json.return_value = ["alpha", "beta"]

    with patch("httpx.Client") as MockClient:
        mock = MagicMock()
        mock.__enter__ = MagicMock(return_value=mock)
        mock.__exit__ = MagicMock(return_value=False)
        mock.get.return_value = resp
        MockClient.return_value = mock

        result = list_agents()

    assert "alpha" in result
    assert "beta" in result


def test_list_agents_connect_error():
    with patch("httpx.Client") as MockClient:
        mock = MagicMock()
        mock.__enter__ = MagicMock(return_value=mock)
        mock.__exit__ = MagicMock(return_value=False)
        mock.get.side_effect = httpx.ConnectError("refused")
        MockClient.return_value = mock

        result = list_agents()

    assert "Cannot connect" in result


# ── orchestrate ───────────────────────────────────────────────────────────────

def _build_orchestrate_mocks(sse_lines: list[str], result_resp: MagicMock | None = None) -> MagicMock:
    """Build an httpx.Client mock for the orchestrate tool (POST then SSE stream then GET result).

    *result_resp* is returned by the third client's GET call (for the run log fetch).
    Defaults to a non-success response so existing tests are unaffected.
    """
    # First Client() call: POST /orchestrate
    post_resp = MagicMock()
    post_resp.is_success = True
    post_resp.json.return_value = {"run_id": "test-run-456", "status": "running"}

    post_client = MagicMock()
    post_client.__enter__ = MagicMock(return_value=post_client)
    post_client.__exit__ = MagicMock(return_value=False)
    post_client.post = MagicMock(return_value=post_resp)

    # Second Client() call: SSE stream
    stream_resp = MagicMock()
    stream_resp.__enter__ = MagicMock(return_value=stream_resp)
    stream_resp.__exit__ = MagicMock(return_value=False)
    stream_resp.iter_lines = MagicMock(return_value=iter(sse_lines))

    stream_client = MagicMock()
    stream_client.__enter__ = MagicMock(return_value=stream_client)
    stream_client.__exit__ = MagicMock(return_value=False)
    stream_client.stream = MagicMock(return_value=stream_resp)

    # Third Client() call: GET /orchestrate/{run_id}
    if result_resp is None:
        result_resp = MagicMock()
        result_resp.is_success = False

    result_client = MagicMock()
    result_client.__enter__ = MagicMock(return_value=result_client)
    result_client.__exit__ = MagicMock(return_value=False)
    result_client.get = MagicMock(return_value=result_resp)

    call_count = [-1]
    clients = [post_client, stream_client, result_client]

    def _make_client(**kwargs):
        call_count[0] += 1
        return clients[min(call_count[0], len(clients) - 1)]

    return MagicMock(side_effect=_make_client)


def test_orchestrate_success():
    lines = list(_sse_iter(
        {"from": "chief", "to": "clarify_director", "type": "task", "payload": ""},
        {"from": "chief", "to": "build_director", "type": "task", "payload": ""},
        {"status": "completed", "result": "Done!"},
        "[DONE]",
    ))
    mock_client_cls = _build_orchestrate_mocks(lines)

    with patch("httpx.Client", new=mock_client_cls):
        result = orchestrate("Add a health check")

    assert "test-run-456" in result
    assert "completed" in result
    assert "clarify" in result
    assert "build" in result


def test_orchestrate_connect_error():
    post_client = MagicMock()
    post_client.__enter__ = MagicMock(return_value=post_client)
    post_client.__exit__ = MagicMock(return_value=False)
    post_client.post = MagicMock(side_effect=httpx.ConnectError("refused"))

    with patch("httpx.Client", return_value=post_client):
        result = orchestrate("do something")

    assert "Cannot connect" in result


def test_orchestrate_server_error():
    post_resp = MagicMock()
    post_resp.is_success = False
    post_resp.status_code = 503
    post_resp.text = "service unavailable"

    post_client = MagicMock()
    post_client.__enter__ = MagicMock(return_value=post_client)
    post_client.__exit__ = MagicMock(return_value=False)
    post_client.post = MagicMock(return_value=post_resp)

    with patch("httpx.Client", return_value=post_client):
        result = orchestrate("do something")

    assert "503" in result


def test_orchestrate_timeout():
    lines = list(_sse_iter("[DONE]"))
    mock_client_cls = _build_orchestrate_mocks(lines)

    # Override stream to raise timeout
    original = mock_client_cls.side_effect
    call_count = [-1]

    def patched(**kwargs):
        call_count[0] += 1
        c = original(**kwargs)
        if call_count[0] == 1:  # stream client
            stream_resp = MagicMock()
            stream_resp.__enter__ = MagicMock(return_value=stream_resp)
            stream_resp.__exit__ = MagicMock(return_value=False)
            stream_resp.iter_lines = MagicMock(side_effect=httpx.TimeoutException("timed out"))
            c.stream = MagicMock(return_value=stream_resp)
        return c

    with patch("httpx.Client", side_effect=patched):
        result = orchestrate("slow task", timeout_seconds=1)

    assert "timed_out" in result


def test_orchestrate_no_phases():
    """Run with no phase events — just a status event."""
    lines = list(_sse_iter(
        {"status": "completed"},
        "[DONE]",
    ))
    mock_client_cls = _build_orchestrate_mocks(lines)

    with patch("httpx.Client", new=mock_client_cls):
        result = orchestrate("quick task")

    assert "test-run-456" in result
    assert "completed" in result
    # No "Phases:" line when no director transitions seen
    assert "Phases:" not in result


def test_orchestrate_appends_run_log():
    """MCP orchestrate() fetches result endpoint and appends run log text."""
    lines = list(_sse_iter(
        {"from": "wf", "to": "clarify_director", "type": "task", "payload": ""},
        {"status": "completed"},
        "[DONE]",
    ))

    result_resp = MagicMock()
    result_resp.is_success = True
    result_resp.json.return_value = {
        "run_id": "test-run-456",
        "status": "completed",
        "error": None,
        "completed_at": "2026-04-09T12:00:00",
        "request_type": "feature",
        "phases_run": ["clarify"],
        "reasoning": "Feature.",
        "total_cost_usd": 0.012,
        "run_log": [
            {"phase": "clarify", "summary": "Done.", "cost_usd": 0.012},
        ],
    }
    mock_client_cls = _build_orchestrate_mocks(lines, result_resp)

    with patch("httpx.Client", new=mock_client_cls):
        output = orchestrate("Add health check")

    assert "Run Log" in output
    assert "clarify" in output
    assert "$0.012" in output
    assert "Total" in output
