"""Smart Model Router — only uses providers with configured keys.
Automatically routes to best model for each task type.
Skips providers without keys entirely.
"""
from __future__ import annotations
import time
from typing import Optional

PROVIDERS = {
    "anthropic": {
        "name": "Anthropic",
        "env": "ANTHROPIC_API_KEY",
        "models": [
            "claude-opus-4-6",
            "claude-sonnet-4-6",
            "claude-haiku-4-5-20251001",
        ],
        "default": "claude-sonnet-4-6",
        "strengths": ["coding", "reasoning", "writing"],
        "color": "#CC785C",
    },
    "openai": {
        "name": "OpenAI",
        "env": "OPENAI_API_KEY",
        "models": [
            "gpt-5.4", "gpt-5.4-mini", "gpt-5.4-nano",
            "gpt-4o", "gpt-4.1", "gpt-4.1-mini",
            "o3", "o4-mini",
        ],
        "default": "gpt-4o",
        "strengths": ["reasoning", "math", "analysis"],
        "color": "#10A37F",
    },
    "gemini": {
        "name": "Google Gemini",
        "env": "GEMINI_API_KEY",
        "models": [
            "gemini-3.1-pro",
            "gemini-3-flash",
            "gemini-3.1-flash-lite",
            "gemini-2.5-pro",
            "gemini-2.5-flash",
            "gemini-2.5-flash-lite",
        ],
        "default": "gemini-2.5-flash",
        "strengths": ["long_context", "multimodal", "research"],
        "color": "#4285F4",
    },
    "groq": {
        "name": "Groq",
        "env": "GROQ_API_KEY",
        "models": [
            "llama-3.3-70b-versatile",
            "llama-3.1-8b-instant",
            "qwen/qwen3-32b",
        ],
        "default": "llama-3.3-70b-versatile",
        "strengths": ["speed", "simple_tasks"],
        "color": "#F55036",
    },
    "mistral": {
        "name": "Mistral",
        "env": "MISTRAL_API_KEY",
        "models": [
            "mistral-large-latest",
            "codestral-latest",
            "mistral-small-latest",
        ],
        "default": "mistral-large-latest",
        "strengths": ["coding", "european_languages"],
        "color": "#FF7000",
    },
}

# Task → best provider mapping
TASK_ROUTING = {
    "planning":    ["anthropic", "openai", "gemini"],
    "coding":      ["anthropic", "mistral", "openai"],
    "debugging":   ["anthropic", "openai", "groq"],
    "research":    ["gemini", "anthropic", "openai"],
    "speed":       ["groq", "gemini", "anthropic"],
    "reasoning":   ["openai", "anthropic", "gemini"],
    "review":      ["anthropic", "openai", "gemini"],
    "default":     ["anthropic", "openai", "gemini", "groq", "mistral"],
}


class ModelRouter:
    """Routes tasks to best available model. Skips unconfigured providers."""

    def __init__(self):
        # rate_limited: {(provider, model): retry_after_timestamp}
        self._rate_limited: dict = {}
        # failed: {(provider, model): fail_count}
        self._failed: dict = {}

    def get_available_providers(self, cfg: dict) -> list[str]:
        """Returns only providers that have at least one API key configured."""
        available = []
        for pid in PROVIDERS:
            keys = cfg.get("keys", {}).get(pid, [])
            if keys:
                available.append(pid)
        return available

    def get_best_model(self, cfg: dict, task_type: str = "default") -> tuple[str, str, str] | None:
        """
        Returns (provider, model, key) for the best available model.
        Skips rate-limited and failed models.
        Returns None if nothing available.
        """
        available_providers = self.get_available_providers(cfg)
        if not available_providers:
            return None

        # Get priority order for this task
        priority = TASK_ROUTING.get(task_type, TASK_ROUTING["default"])

        # Filter to only available providers, maintaining priority
        ordered = [p for p in priority if p in available_providers]
        # Add remaining available providers not in priority list
        for p in available_providers:
            if p not in ordered:
                ordered.append(p)

        for provider in ordered:
            pinfo = PROVIDERS[provider]
            keys = cfg.get("keys", {}).get(provider, [])
            if not keys:
                continue

            # Get preferred model
            preferred = cfg.get("model") if cfg.get("provider") == provider else pinfo["default"]
            models_to_try = [preferred] + [m for m in pinfo["models"] if m != preferred]

            for model in models_to_try:
                if self._is_available(provider, model):
                    key = keys[0]  # Use first key (round-robin handled in providers)
                    return (provider, model, key)

        return None

    def get_fallback_chain(self, cfg: dict, exclude_provider: str = None,
                           exclude_model: str = None) -> list[tuple]:
        """
        Returns full ordered fallback chain of (provider, model, key).
        Skips providers without keys, rate-limited, and failed models.
        """
        available = self.get_available_providers(cfg)
        chain = []

        for provider in available:
            if provider == exclude_provider:
                continue
            pinfo = PROVIDERS[provider]
            keys = cfg.get("keys", {}).get(provider, [])
            if not keys:
                continue

            for model in pinfo["models"]:
                if model == exclude_model and provider == exclude_provider:
                    continue
                if self._is_available(provider, model):
                    chain.append((provider, model, keys[0]))

        return chain

    def mark_rate_limited(self, provider: str, model: str, retry_after: int = 60):
        self._rate_limited[(provider, model)] = time.time() + retry_after

    def mark_failed(self, provider: str, model: str):
        key = (provider, model)
        self._failed[key] = self._failed.get(key, 0) + 1

    def mark_success(self, provider: str, model: str):
        self._failed.pop((provider, model), None)
        self._rate_limited.pop((provider, model), None)

    def _is_available(self, provider: str, model: str) -> bool:
        key = (provider, model)
        # Check rate limit
        retry_at = self._rate_limited.get(key, 0)
        if retry_at and time.time() < retry_at:
            return False
        # Check failures (skip after 3 consecutive failures)
        if self._failed.get(key, 0) >= 3:
            return False
        return True

    def get_status_table(self, cfg: dict) -> list[dict]:
        """Returns status of all models for display."""
        rows = []
        for pid, pinfo in PROVIDERS.items():
            keys = cfg.get("keys", {}).get(pid, [])
            has_key = bool(keys)
            for model in pinfo["models"]:
                status = "no_key"
                if has_key:
                    if not self._is_available(pid, model):
                        key = (pid, model)
                        if self._rate_limited.get(key, 0) > time.time():
                            status = "rate_limited"
                        else:
                            status = "failed"
                    else:
                        status = "available"
                rows.append({
                    "provider": pid,
                    "model": model,
                    "status": status,
                    "has_key": has_key,
                })
        return rows


# Global router instance
router = ModelRouter()
