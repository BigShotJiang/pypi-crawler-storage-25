"""Tools — 18 tools with PermissionMode: SAFE / MODERATE / DANGEROUS."""
from __future__ import annotations

import json
import os
import subprocess
import urllib.request
import urllib.error
import glob as glob_module
from enum import Enum
from pathlib import Path
from typing import Any

from . import memory as mem


class PermissionMode(Enum):
    SAFE = "SAFE"           # auto-run always
    MODERATE = "MODERATE"   # confirm once per session
    DANGEROUS = "DANGEROUS" # always confirm


# ── Permission map ────────────────────────────────────────────────────────────

TOOL_PERMISSIONS: dict[str, PermissionMode] = {
    "file_read":     PermissionMode.SAFE,
    "grep":          PermissionMode.SAFE,
    "glob":          PermissionMode.SAFE,
    "ls":            PermissionMode.SAFE,
    "memory_read":   PermissionMode.SAFE,
    "memory_search": PermissionMode.SAFE,
    "todo_read":     PermissionMode.SAFE,
    "git_status":    PermissionMode.SAFE,
    "git_diff":      PermissionMode.SAFE,
    "diff_view":     PermissionMode.SAFE,

    "file_write":    PermissionMode.MODERATE,
    "file_edit":     PermissionMode.MODERATE,
    "file_delete":   PermissionMode.MODERATE,
    "web_fetch":     PermissionMode.MODERATE,
    "web_search":    PermissionMode.MODERATE,
    "memory_write":  PermissionMode.MODERATE,
    "todo_write":    PermissionMode.MODERATE,
    "file_write_chunk": PermissionMode.MODERATE,
    "file_read_lines":  PermissionMode.SAFE,
    "file_insert_lines": PermissionMode.MODERATE,
    "file_delete_lines": PermissionMode.MODERATE,
    "spawn_agent":   PermissionMode.MODERATE,

    "bash":          PermissionMode.DANGEROUS,
    "git_commit":    PermissionMode.DANGEROUS,
    "git_push":      PermissionMode.DANGEROUS,
    "git_reset":     PermissionMode.DANGEROUS,
}


# ── Tool definitions ──────────────────────────────────────────────────────────

TOOL_SPECS: list[dict] = [
    # SAFE
    {
        "name": "file_read",
        "description": "Read file contents. Supports line range.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "start_line": {"type": "integer"},
                "end_line": {"type": "integer"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "grep",
        "description": "Search for pattern in files. Returns matches with file+line.",
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Regex or literal pattern"},
                "path": {"type": "string", "description": "File or directory (default: .)"},
                "recursive": {"type": "boolean", "default": True},
                "case_sensitive": {"type": "boolean", "default": True},
                "include": {"type": "string", "description": "Glob filter e.g. '*.py'"},
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "glob",
        "description": "Find files matching a glob pattern.",
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Glob pattern e.g. '**/*.py'"},
                "base": {"type": "string", "description": "Base directory (default: .)"},
                "max_results": {"type": "integer", "default": 100},
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "ls",
        "description": "List directory contents with file sizes and types.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path (default: .)"},
                "show_hidden": {"type": "boolean", "default": False},
                "recursive": {"type": "boolean", "default": False},
            },
        },
    },
    {
        "name": "memory_read",
        "description": "Read long-term memory file.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "memory_search",
        "description": "Search long-term memory for relevant entries.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "todo_read",
        "description": "Read the current TODO list.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "git_status",
        "description": "Show git status of current repository.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "git_diff",
        "description": "Show git diff (staged or unstaged).",
        "input_schema": {
            "type": "object",
            "properties": {
                "staged": {"type": "boolean", "default": False},
                "file": {"type": "string"},
            },
        },
    },
    {
        "name": "diff_view",
        "description": "Show diff between two strings or files.",
        "input_schema": {
            "type": "object",
            "properties": {
                "original": {"type": "string"},
                "modified": {"type": "string"},
                "label": {"type": "string"},
            },
            "required": ["original", "modified"],
        },
    },
    # MODERATE
    {
        "name": "file_write_chunk",
        "description": "Write large files in chunks. Use mode=append for subsequent chunks.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
                "mode": {"type": "string", "enum": ["write", "append"], "default": "write"},
                "chunk_index": {"type": "integer", "default": 0},
                "total_chunks": {"type": "integer", "default": 1},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "file_read_lines",
        "description": "Read specific line range from large files.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "start": {"type": "integer", "default": 1},
                "end": {"type": "integer", "default": 100},
            },
            "required": ["path"],
        },
    },
    {
        "name": "file_insert_lines",
        "description": "Insert content after a specific line number.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "after_line": {"type": "integer"},
                "content": {"type": "string"},
            },
            "required": ["path", "after_line", "content"],
        },
    },
    {
        "name": "file_delete_lines",
        "description": "Delete a range of lines from a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "start": {"type": "integer"},
                "end": {"type": "integer"},
            },
            "required": ["path", "start", "end"],
        },
    },
    # MODERATE
    {
        "name": "file_write",
        "description": "Write (create or overwrite) a file.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "file_edit",
        "description": "Replace exact string in file. old_str must be unique.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old_str": {"type": "string"},
                "new_str": {"type": "string"},
            },
            "required": ["path", "old_str", "new_str"],
        },
    },
    {
        "name": "file_delete",
        "description": "Delete a file.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "web_fetch",
        "description": "Fetch text content from a URL.",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string"},
                "max_chars": {"type": "integer", "default": 10000},
            },
            "required": ["url"],
        },
    },
    {
        "name": "web_search",
        "description": "Search the web using DuckDuckGo (free, no key needed).",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "max_results": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_write",
        "description": "Write an entry to long-term memory.",
        "input_schema": {
            "type": "object",
            "properties": {
                "content": {"type": "string"},
                "section": {"type": "string", "default": "Notes"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "todo_write",
        "description": "Update the TODO list.",
        "input_schema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["add", "done", "remove", "clear"]},
                "item": {"type": "string"},
            },
            "required": ["action"],
        },
    },
    # DANGEROUS
    {
        "name": "bash",
        "description": (
            "Execute a bash command. Returns stdout + stderr. "
            "Use for: running scripts, installing packages, compiling, testing, git operations."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "timeout": {"type": "integer", "default": 60},
                "working_dir": {"type": "string"},
            },
            "required": ["command"],
        },
    },
    {
        "name": "git_commit",
        "description": "Stage all changes and create a git commit.",
        "input_schema": {
            "type": "object",
            "properties": {
                "message": {"type": "string"},
                "add_all": {"type": "boolean", "default": True},
            },
            "required": ["message"],
        },
    },
    {
        "name": "git_push",
        "description": "Push commits to remote.",
        "input_schema": {
            "type": "object",
            "properties": {
                "remote": {"type": "string", "default": "origin"},
                "branch": {"type": "string", "default": ""},
            },
        },
    },
    {
        "name": "git_reset",
        "description": "Reset git changes (hard reset — destructive!).",
        "input_schema": {
            "type": "object",
            "properties": {
                "hard": {"type": "boolean", "default": False},
                "files": {"type": "string"},
            },
        },
    },
]

# OpenAI format
def _to_openai(t: dict) -> dict:
    return {
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t["description"],
            "parameters": t["input_schema"],
        },
    }

TOOL_DEFS_ANTHROPIC = TOOL_SPECS
TOOL_DEFS_OPENAI = [_to_openai(t) for t in TOOL_SPECS]

_TODO_FILE = Path.home() / ".mycode" / "todo.json"


def _load_todos() -> list[str]:
    if _TODO_FILE.exists():
        try:
            return json.loads(_TODO_FILE.read_text())
        except Exception:
            pass
    return []


def _save_todos(items: list[str]) -> None:
    _TODO_FILE.parent.mkdir(parents=True, exist_ok=True)
    _TODO_FILE.write_text(json.dumps(items, indent=2, ensure_ascii=False))


# ── Execution ─────────────────────────────────────────────────────────────────

def run_tool(name: str, inputs: dict[str, Any]) -> str:
    try:
        match name:
            case "file_read":    return _file_read(**inputs)
            case "grep":         return _grep(**inputs)
            case "glob":         return _glob(**inputs)
            case "ls":           return _ls(**inputs)
            case "memory_read":  return mem.lt_read()
            case "memory_search":return "\n\n".join(mem.lt_search(inputs.get("query", ""))) or "No results."
            case "todo_read":    return _todo_read()
            case "git_status":   return _git_status()
            case "git_diff":     return _git_diff(**inputs)
            case "diff_view":    return _diff_view(**inputs)
            case "file_write":   return _file_write(**inputs)
            case "file_edit":    return _file_edit(**inputs)
            case "file_delete":  return _file_delete(**inputs)
            case "web_fetch":    return _web_fetch(**inputs)
            case "web_search":   return _web_search(**inputs)
            case "memory_write": return _memory_write(**inputs)
            case "todo_write":   return _todo_write(**inputs)
            case "bash":         return _bash(**inputs)
            case "git_commit":   return _git_commit(**inputs)
            case "git_push":     return _git_push(**inputs)
            case "git_reset":    return _git_reset(**inputs)
            case _:              return f"❌ Unknown tool: {name}"
    except TypeError as e:
        return f"❌ Tool parameter error: {e}"
    except Exception as e:
        return f"❌ Tool error [{name}]: {e}"


# ── SAFE Tools ────────────────────────────────────────────────────────────────

def _file_read(path: str, start_line: int = None, end_line: int = None) -> str:
    p = Path(path).expanduser()
    if not p.exists():
        return f"❌ File not found: {path}"
    if p.is_dir():
        return f"❌ Path is a directory. Use 'ls' instead."
    try:
        content = p.read_text(errors="replace")
        lines = content.splitlines()
        total = len(lines)
        if start_line or end_line:
            s = max(0, (start_line or 1) - 1)
            e = end_line or total
            lines = lines[s:e]
        out = "\n".join(lines)
        if len(out) > 60_000:
            out = out[:60_000] + "\n... [TRUNCATED]"
        return f"[{p}] ({total} lines)\n{out}"
    except Exception as e:
        return f"❌ Read error: {e}"


def _grep(pattern: str, path: str = ".", recursive: bool = True,
          case_sensitive: bool = True, include: str = None) -> str:
    cmd = ["grep", "-n", "--color=never"]
    if recursive:
        cmd.append("-r")
    if not case_sensitive:
        cmd.append("-i")
    if include:
        cmd.extend(["--include", include])
    cmd.extend(["--", pattern, path])
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        out = r.stdout.strip()
        if not out:
            return "No matches found."
        lines = out.split("\n")
        if len(lines) > 150:
            lines = lines[:150] + [f"... [{len(out.splitlines())-150} more lines]"]
        return "\n".join(lines)
    except Exception as e:
        return f"❌ grep error: {e}"


def _glob(pattern: str, base: str = ".", max_results: int = 100) -> str:
    try:
        base_path = Path(base).expanduser()
        matches = list(base_path.glob(pattern))[:max_results]
        if not matches:
            return "No files matched."
        return "\n".join(str(m.relative_to(base_path)) for m in sorted(matches))
    except Exception as e:
        return f"❌ glob error: {e}"


def _ls(path: str = ".", show_hidden: bool = False, recursive: bool = False) -> str:
    p = Path(path).expanduser()
    if not p.exists():
        return f"❌ Not found: {path}"
    try:
        if recursive:
            entries = sorted(p.rglob("*"))
        else:
            entries = sorted(p.iterdir())
        lines = []
        for e in entries[:200]:
            if not show_hidden and e.name.startswith("."):
                continue
            rel = e.relative_to(p) if recursive else e.name
            if e.is_dir():
                lines.append(f"📁 {rel}/")
            else:
                size = e.stat().st_size
                sz = f"{size:,}" if size < 1024 else f"{size//1024}K"
                lines.append(f"📄 {rel}  [{sz}]")
        return "\n".join(lines) or "(empty directory)"
    except Exception as e:
        return f"❌ ls error: {e}"


def _todo_read() -> str:
    todos = _load_todos()
    if not todos:
        return "No tasks in TODO list."
    return "\n".join(f"  {i+1}. {t}" for i, t in enumerate(todos))


def _git_status() -> str:
    try:
        r = subprocess.run(["git", "status", "--short", "--branch"],
                           capture_output=True, text=True, timeout=10)
        return r.stdout or r.stderr or "Nothing to show."
    except Exception as e:
        return f"❌ git error: {e}"


def _git_diff(staged: bool = False, file: str = None) -> str:
    cmd = ["git", "diff"]
    if staged:
        cmd.append("--staged")
    if file:
        cmd.extend(["--", file])
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        out = r.stdout[:8000]
        return out or "No diff."
    except Exception as e:
        return f"❌ git diff error: {e}"


def _diff_view(original: str, modified: str, label: str = "diff") -> str:
    import difflib
    orig_lines = original.splitlines(keepends=True)
    mod_lines = modified.splitlines(keepends=True)
    diff = list(difflib.unified_diff(orig_lines, mod_lines, fromfile="original", tofile="modified"))
    if not diff:
        return "No differences."
    return "".join(diff[:200])


# ── MODERATE Tools ────────────────────────────────────────────────────────────

def _file_write(path: str, content: str) -> str:
    p = Path(path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        original = p.read_text(encoding="utf-8", errors="replace")
        from . import ui as _ui
        apply = _ui.show_diff_preview(str(path), original, content)
        if not apply:
            return f"⛔ Skipped: {path}"
        # backup for undo
        _backup_file(str(path), original)
    p.write_text(content, encoding="utf-8")
    lines = content.count("\n") + 1
    return f"✅ Written {lines} lines → {path}"


def _file_edit(path: str, old_str: str, new_str: str) -> str:
    p = Path(path).expanduser()
    if not p.exists():
        return f"❌ File not found: {path}"
    content = p.read_text(errors="replace")
    modified = content.replace(old_str, new_str, 1)
    from . import ui as _ui
    apply = _ui.show_diff_preview(str(path), content, modified)
    if not apply:
        return f"⛔ Skipped: {path}"
    _backup_file(str(path), content)
    count = content.count(old_str)
    if count == 0:
        # Try to find close match
        return f"❌ String not found in {path}. Make sure old_str matches exactly."
    if count > 1:
        return f"❌ Found {count} occurrences — old_str must be unique. Add more context."
    p.write_text(content.replace(old_str, new_str, 1), encoding="utf-8")
    return f"✅ Edited {path}"


def _file_delete(path: str) -> str:
    p = Path(path).expanduser()
    if not p.exists():
        return f"❌ Not found: {path}"
    p.unlink()
    return f"✅ Deleted {path}"


def _web_fetch(url: str, max_chars: int = 10000) -> str:
    try:
        import urllib.request
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (mycode/2.0 AI assistant)"
        })
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read()
            charset = "utf-8"
            ct = resp.headers.get("Content-Type", "")
            if "charset=" in ct:
                charset = ct.split("charset=")[-1].split(";")[0].strip()
            text = raw.decode(charset, errors="replace")
            import re
            text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
            text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL)
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()
            return text[:max_chars] + ("\n...[truncated]" if len(text) > max_chars else "")
    except urllib.error.HTTPError as e:
        return f"❌ HTTP {e.code}: {e.reason}"
    except Exception as e:
        return f"❌ Fetch error: {e}"


def _web_search(query: str, max_results: int = 5) -> str:
    """DuckDuckGo instant answers — no API key needed."""
    try:
        import urllib.parse
        encoded = urllib.parse.quote_plus(query)
        url = f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1&skip_disambig=1"
        req = urllib.request.Request(url, headers={"User-Agent": "mycode/2.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        results = []
        if data.get("AbstractText"):
            results.append(f"📌 {data['AbstractText']}")
        for r in data.get("RelatedTopics", [])[:max_results]:
            if isinstance(r, dict) and r.get("Text"):
                results.append(f"• {r['Text'][:200]}")
        if not results:
            # Fallback: HTML scrape
            url2 = f"https://html.duckduckgo.com/html/?q={encoded}"
            return _web_fetch(url2, 4000)
        return "\n".join(results) if results else "No results found."
    except Exception as e:
        return f"❌ Search error: {e}"


def _memory_write(content: str, section: str = "Notes") -> str:
    mem.lt_append(content, section)
    return f"✅ Saved to long-term memory [{section}]"


def _todo_write(action: str, item: str = "") -> str:
    todos = _load_todos()
    if action == "add":
        todos.append(f"[ ] {item}")
        _save_todos(todos)
        return f"✅ Added: {item}"
    elif action == "done":
        for i, t in enumerate(todos):
            if item.lower() in t.lower():
                todos[i] = t.replace("[ ]", "[x]")
                _save_todos(todos)
                return f"✅ Marked done: {t}"
        return f"❌ Not found: {item}"
    elif action == "remove":
        before = len(todos)
        todos = [t for t in todos if item.lower() not in t.lower()]
        _save_todos(todos)
        return f"✅ Removed {before - len(todos)} item(s)"
    elif action == "clear":
        _save_todos([])
        return "✅ TODO cleared"
    return f"❌ Unknown action: {action}"


# ── DANGEROUS Tools ───────────────────────────────────────────────────────────

def _bash(command: str, timeout: int = 60, working_dir: str = None) -> str:
    cwd = Path(working_dir).expanduser() if working_dir else None
    try:
        r = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=timeout, cwd=cwd,
            env={**os.environ, "TERM": "dumb"},
        )
        parts = []
        if r.stdout.strip():
            parts.append(r.stdout.rstrip())
        if r.stderr.strip():
            parts.append(f"[stderr]\n{r.stderr.rstrip()}")
        if not parts:
            parts.append(f"(exit {r.returncode})")
        out = "\n".join(parts)
        if len(out) > 15000:
            out = out[:15000] + "\n...[truncated]"
        return out
    except subprocess.TimeoutExpired:
        return f"❌ Timeout after {timeout}s"
    except Exception as e:
        return f"❌ bash error: {e}"


def _git_commit(message: str, add_all: bool = True) -> str:
    try:
        if add_all:
            subprocess.run(["git", "add", "-A"], capture_output=True)
        r = subprocess.run(["git", "commit", "-m", message],
                           capture_output=True, text=True, timeout=30)
        return r.stdout + r.stderr
    except Exception as e:
        return f"❌ git commit error: {e}"


def _git_push(remote: str = "origin", branch: str = "") -> str:
    cmd = ["git", "push", remote]
    if branch:
        cmd.append(branch)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return r.stdout + r.stderr
    except Exception as e:
        return f"❌ git push error: {e}"


def _git_reset(hard: bool = False, files: str = "") -> str:
    if hard:
        cmd = ["git", "reset", "--hard", "HEAD"]
    elif files:
        cmd = ["git", "checkout", "--", files]
    else:
        cmd = ["git", "reset", "HEAD"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        return r.stdout + r.stderr
    except Exception as e:
        return f"❌ git reset error: {e}"


def describe_call(name: str, inputs: dict) -> str:
    match name:
        case "bash":        return f"$ {inputs.get('command', '')[:100]}"
        case "file_read":   return f"read  {inputs.get('path', '')}"
        case "file_write":  return f"write {inputs.get('path', '')} ({inputs.get('content','').count(chr(10))+1} lines)"
        case "file_edit":   return f"edit  {inputs.get('path', '')}"
        case "file_delete": return f"del   {inputs.get('path', '')}"
        case "grep":        return f"grep  '{inputs.get('pattern','')}' in {inputs.get('path','.')}"
        case "glob":        return f"glob  {inputs.get('pattern','')}"
        case "ls":          return f"ls    {inputs.get('path', '.')}"
        case "web_fetch":   return f"fetch {inputs.get('url','')[:80]}"
        case "web_search":  return f"search '{inputs.get('query','')[:60]}'"
        case "git_commit":  return f"git commit '{inputs.get('message','')[:50]}'"
        case "git_push":    return f"git push {inputs.get('remote','origin')}"
        case "memory_write":return f"remember [{inputs.get('section','Notes')}]"
        case "todo_write":  return f"todo {inputs.get('action','')} {inputs.get('item','')}"
        case _:             return f"{name}({json.dumps(inputs)[:60]})"


def get_permission(name: str) -> PermissionMode:
    return TOOL_PERMISSIONS.get(name, PermissionMode.MODERATE)

def _file_write_chunk(path: str, content: str, mode: str = "w", chunk_index: int = 0, total_chunks: int = 1) -> str:
    """Write file in chunks — for large files."""
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        write_mode = "a" if mode == "append" else "w"
        with open(p, write_mode, encoding="utf-8") as f:
            f.write(content)
        size = p.stat().st_size
        if total_chunks > 1:
            return f"Chunk {chunk_index+1}/{total_chunks} written. File size: {size} bytes"
        return f"Written {size} bytes to {path}"
    except Exception as e:
        return f"Error: {e}"

def _file_read_lines(path: str, start: int = 1, end: int = 100) -> str:
    """Read specific line range from large files."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        total = len(lines)
        end = min(end, total)
        selected = lines[start-1:end]
        result = f"Lines {start}-{end} of {total} total:\n"
        result += "".join(f"{start+i}: {line}" for i, line in enumerate(selected))
        return result
    except Exception as e:
        return f"Error: {e}"

def _file_insert_lines(path: str, after_line: int, content: str) -> str:
    """Insert content after specific line number."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        new_lines = content if content.endswith("\n") else content + "\n"
        lines.insert(after_line, new_lines)
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        return f"Inserted after line {after_line} in {path}"
    except Exception as e:
        return f"Error: {e}"

def _file_delete_lines(path: str, start: int, end: int) -> str:
    """Delete specific line range from file."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        total = len(lines)
        del lines[start-1:end]
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        return f"Deleted lines {start}-{end} from {path}. Was {total}, now {len(lines)} lines."
    except Exception as e:
        return f"Error: {e}"


# ── Undo / Backup ─────────────────────────────────────────────────────────────

import json as _json

_UNDO_FILE = Path.home() / ".solanacy-code" / "undo_stack.json"

def _backup_file(path: str, original: str):
    """Save file content to undo stack."""
    stack = []
    if _UNDO_FILE.exists():
        try:
            stack = _json.loads(_UNDO_FILE.read_text())
        except Exception:
            stack = []
    stack.append({"path": path, "content": original})
    if len(stack) > 20:
        stack = stack[-20:]
    _UNDO_FILE.parent.mkdir(parents=True, exist_ok=True)
    _UNDO_FILE.write_text(_json.dumps(stack))

def _undo_last() -> str:
    """Restore last backed up file."""
    if not _UNDO_FILE.exists():
        return "❌ Nothing to undo."
    try:
        stack = _json.loads(_UNDO_FILE.read_text())
    except Exception:
        return "❌ Undo stack corrupted."
    if not stack:
        return "❌ Nothing to undo."
    last = stack.pop()
    _UNDO_FILE.write_text(_json.dumps(stack))
    path = last["path"]
    content = last["content"]
    Path(path).write_text(content, encoding="utf-8")
    return f"✅ Restored: {path}"
