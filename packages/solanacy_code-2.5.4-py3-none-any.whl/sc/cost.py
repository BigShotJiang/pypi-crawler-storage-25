"""Cost tracker — per-message token counting, daily/monthly budget."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path

from .config import CONFIG_DIR

COST_FILE = CONFIG_DIR / "cost_log.json"

# Cost per 1M tokens (input/output) in USD
PRICING: dict[str, dict[str, float]] = {
    # Anthropic
    "claude-opus-4-6":           {"in": 15.0,  "out": 75.0},
    "claude-sonnet-4-6":         {"in": 3.0,   "out": 15.0},
    "claude-haiku-4-5-20251001": {"in": 0.25,  "out": 1.25},
    # OpenAI
    "gpt-5.4":                   {"in": 2.50,  "out": 10.0},
    "gpt-5.4-mini":              {"in": 0.15,  "out": 0.60},
    "gpt-4o":                    {"in": 2.50,  "out": 10.0},
    "gpt-4.1":                   {"in": 2.0,   "out": 8.0},
    "o3":                        {"in": 10.0,  "out": 40.0},
    "o4-mini":                   {"in": 1.10,  "out": 4.40},
    # Gemini
    "gemini-2.5-pro":            {"in": 1.25,  "out": 10.0},
    "gemini-2.5-flash":          {"in": 0.075, "out": 0.30},
    "gemini-3.1-pro-preview":    {"in": 1.25,  "out": 10.0},
    # Groq (free tier — approximate)
    "llama-3.3-70b-versatile":   {"in": 0.0,   "out": 0.0},
    "llama-3.1-8b-instant":      {"in": 0.0,   "out": 0.0},
    # Mistral
    "mistral-large-latest":      {"in": 2.0,   "out": 6.0},
    "codestral-latest":          {"in": 1.0,   "out": 3.0},
}


@dataclass
class UsageRecord:
    ts: float
    provider: str
    model: str
    in_tokens: int
    out_tokens: int
    cost_usd: float
    session_id: str = ""


@dataclass
class CostState:
    records: list[dict] = field(default_factory=list)
    session_total_cost: float = 0.0
    session_in_tokens: int = 0
    session_out_tokens: int = 0


_state = CostState()


def _load() -> None:
    if COST_FILE.exists():
        try:
            data = json.loads(COST_FILE.read_text())
            _state.records = data.get("records", [])
        except Exception:
            pass


def _save() -> None:
    COST_FILE.write_text(json.dumps({"records": _state.records[-5000:]}, indent=2))


def calculate_cost(model: str, in_tokens: int, out_tokens: int) -> float:
    p = PRICING.get(model, {"in": 1.0, "out": 3.0})
    return (in_tokens * p["in"] + out_tokens * p["out"]) / 1_000_000


def record_usage(provider: str, model: str, in_tokens: int, out_tokens: int,
                 session_id: str = "") -> float:
    cost = calculate_cost(model, in_tokens, out_tokens)
    rec = UsageRecord(
        ts=time.time(),
        provider=provider,
        model=model,
        in_tokens=in_tokens,
        out_tokens=out_tokens,
        cost_usd=cost,
        session_id=session_id,
    )
    _state.records.append(asdict(rec))
    _state.session_total_cost += cost
    _state.session_in_tokens += in_tokens
    _state.session_out_tokens += out_tokens
    _save()
    return cost


def get_session_stats() -> dict:
    return {
        "cost": _state.session_total_cost,
        "in_tokens": _state.session_in_tokens,
        "out_tokens": _state.session_out_tokens,
        "total_tokens": _state.session_in_tokens + _state.session_out_tokens,
    }


def get_daily_cost() -> float:
    _load()
    day_start = time.time() - 86400
    return sum(r["cost_usd"] for r in _state.records if r["ts"] >= day_start)


def get_monthly_cost() -> float:
    _load()
    month_start = time.time() - 86400 * 30
    return sum(r["cost_usd"] for r in _state.records if r["ts"] >= month_start)


def check_budget(cfg: dict) -> tuple[bool, str]:
    """Returns (ok, warning_message). ok=False means over budget."""
    budget = cfg.get("budget", {})
    daily_limit = budget.get("daily_limit", 0.0)
    monthly_limit = budget.get("monthly_limit", 0.0)
    warn_at = budget.get("warn_at", 0.8)

    if daily_limit > 0:
        daily = get_daily_cost()
        if daily >= daily_limit:
            return False, f"Daily budget ${daily_limit:.2f} exceeded (${daily:.4f} used)"
        if daily >= daily_limit * warn_at:
            return True, f"⚠️  Daily budget {daily/daily_limit*100:.0f}% used (${daily:.4f}/${daily_limit:.2f})"

    if monthly_limit > 0:
        monthly = get_monthly_cost()
        if monthly >= monthly_limit:
            return False, f"Monthly budget ${monthly_limit:.2f} exceeded (${monthly:.4f} used)"
        if monthly >= monthly_limit * warn_at:
            return True, f"⚠️  Monthly budget {monthly/monthly_limit*100:.0f}% used (${monthly:.4f}/${monthly_limit:.2f})"

    return True, ""


def reset_session() -> None:
    _state.session_total_cost = 0.0
    _state.session_in_tokens = 0
    _state.session_out_tokens = 0


_load()
