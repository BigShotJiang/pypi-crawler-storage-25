"""Memory — long-term + working memory with auto-trim when too large."""
from __future__ import annotations
import json, time
from pathlib import Path
from .config import CONFIG_DIR, MEMORY_FILE

# Limits
LT_MAX_CHARS = 50000  # was 8000       # Long-term memory max size
LT_TRIM_TO = 5000         # Trim down to this when too large
COMPACT_THRESHOLD = 15000  # Message history chars before compaction
WORKING_MAX = 20           # Max working memory entries

_working: list[dict] = []

# ── Long-term memory ───────────────────────────────────────────────────────────

def _ensure():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not MEMORY_FILE.exists():
        MEMORY_FILE.write_text("# Solanacy Code Memory\n\n")

def lt_read() -> str:
    _ensure()
    return MEMORY_FILE.read_text()

def lt_append(text: str, tag: str = ""):
    _ensure()
    content = MEMORY_FILE.read_text()
    entry = f"\n[{tag or 'note'}] {text.strip()}\n" if tag else f"\n- {text.strip()}\n"
    new_content = content + entry

    # Auto-trim if too large
    if len(new_content) > LT_MAX_CHARS:
        new_content = _trim_memory(new_content)

    MEMORY_FILE.write_text(new_content)

def lt_write(content: str):
    _ensure()
    # Enforce size limit
    if len(content) > LT_MAX_CHARS:
        content = _trim_memory(content)
    MEMORY_FILE.write_text(content)

def lt_delete(keyword: str) -> int:
    _ensure()
    lines = MEMORY_FILE.read_text().splitlines()
    before = len(lines)
    lines = [l for l in lines if keyword.lower() not in l.lower()]
    MEMORY_FILE.write_text("\n".join(lines))
    return before - len(lines)

def lt_search(query: str) -> str:
    _ensure()
    lines = MEMORY_FILE.read_text().splitlines()
    matches = [l for l in lines if query.lower() in l.lower()]
    return "\n".join(matches) if matches else "No matches."

def _trim_memory(content: str) -> str:
    """
    Smart trim: keeps header + most recent entries.
    Removes oldest entries until under LT_TRIM_TO.
    """
    lines = content.splitlines()
    # Keep header (first 3 lines)
    header = lines[:3]
    body = lines[3:]

    # Remove from the start (oldest) until small enough
    while len("\n".join(header + body)) > LT_TRIM_TO and body:
        body = body[1:]

    trimmed = "\n".join(header + ["", "# [Older entries trimmed for space]", ""] + body)
    return trimmed

def get_memory_size() -> int:
    _ensure()
    return len(MEMORY_FILE.read_text())

def is_memory_full() -> bool:
    return get_memory_size() > LT_MAX_CHARS * 0.9  # 90% full

# ── Working memory (current session) ──────────────────────────────────────────

def working_add(text: str, tag: str = ""):
    global _working
    _working.append({"text": text, "tag": tag, "ts": time.time()})
    # Keep only last N entries
    if len(_working) > WORKING_MAX:
        _working = _working[-WORKING_MAX:]

def working_clear():
    global _working
    _working = []

def working_get() -> list[dict]:
    return _working

def working_search(query: str) -> list[dict]:
    return [w for w in _working if query.lower() in w["text"].lower()]

# ── Project memory ─────────────────────────────────────────────────────────────

def read_project_memory() -> str | None:
    """Read SC.md or CLAUDE.md from current directory tree."""
    p = Path.cwd()
    for _ in range(5):
        for fname in ["SC.md", "CLAUDE.md", "MYCODE.md"]:
            f = p / fname
            if f.exists():
                return f.read_text()[:3000]
        if p.parent == p: break
        p = p.parent
    return None

def init_project_memory(name: str = "", desc: str = ""):
    content = f"""# SC Project: {name or Path.cwd().name}

{desc or 'Add project description here.'}

## Architecture
- (describe your project structure)

## Key Files
- (list important files)

## Commands
- (useful commands for this project)
"""
    (Path.cwd() / "SC.md").write_text(content)

# ── Context compaction ─────────────────────────────────────────────────────────

def should_compact(messages: list, threshold: int = COMPACT_THRESHOLD) -> bool:
    """Returns True if message history is too long."""
    total = sum(
        len(str(m.get("content", "")))
        for m in messages
    )
    return total > threshold

def build_compact_prompt(messages: list) -> str:
    """Build a prompt to summarize conversation for context compaction."""
    """Build a prompt to summarize the conversation."""
    lines = []
    for m in messages[-20:]:  # Last 20 messages
        role = m.get("role", "")
        content = m.get("content", "")
        if isinstance(content, list):
            # Tool results etc
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    lines.append(f"{role}: {item['text'][:200]}")
        elif isinstance(content, str):
            lines.append(f"{role}: {content[:200]}")
    conv_text = "\n".join(lines)
    return (
        f"Summarize this conversation very concisely. "
        f"Keep: key decisions, code written, errors found, current task state.\n\n"
        f"{conv_text}"
    )

def compact_messages(messages: list, summary: str) -> list:
    """Replace old messages with summary, keep last 4."""
    kept = messages[-4:] if len(messages) > 4 else messages
    system_msg = {
        "role": "user",
        "content": f"[Previous conversation summary]: {summary}"
    }
    return [system_msg] + kept

# ── Session ────────────────────────────────────────────────────────────────────

def session_save(messages: list, name: str = "") -> str:
    from .config import SESSIONS_DIR
    import uuid
    sid = name or f"session_{int(time.time())}"
    f = SESSIONS_DIR / f"{sid}.json"
    f.write_text(json.dumps({"messages": messages, "ts": time.time()}, indent=2))
    return sid

def session_load(name: str) -> list | None:
    from .config import SESSIONS_DIR
    f = SESSIONS_DIR / f"{name}.json"
    if not f.exists(): return None
    return json.loads(f.read_text()).get("messages", [])

def session_list() -> list[str]:
    from .config import SESSIONS_DIR
    return [f.stem for f in sorted(SESSIONS_DIR.glob("*.json"))]
