"""Agent loop — self-healing, auto-test, auto-fix, smart compaction."""
from __future__ import annotations
from typing import Callable
from . import providers as prov
from . import hooks
from . import memory as mem
from .tools import run_tool, describe_call, get_permission, PermissionMode
from . import ui
from .agents.base import AGENT_ROLES, select_agent
from .memory import should_compact, build_compact_prompt, compact_messages

MAX_TOOL_TURNS = 50
MAX_SELF_HEAL = 5  # Max auto-fix attempts

def _build_system(cfg: dict, agent_role: str = "") -> str:
    """Build enhanced system prompt with context."""
    from .providers import BASE_SYSTEM
    from .providers import BASE_SYSTEM as bs
    think = cfg.get("think_mode", False)
    project = mem.read_project_memory() or ""
    lt = mem.lt_read()

    system = bs
    role_prompt = AGENT_ROLES.get(agent_role, "")
    if role_prompt:
        system += f"\n\nROLE: {role_prompt}\n"
    if think:
        system += """

THINK MODE ACTIVE:
- Before every response, think step-by-step inside <thinking> tags
- Analyze the problem fully before writing code
- Consider edge cases, error handling, and scalability
- Plan file structure before creating files
- Verify your logic before executing commands
"""
    if project:
        system += f"\n\nPROJECT CONTEXT:\n{project[:2000]}\n"
    # Only add memory if not too large
    if lt and len(lt) > 50:
        # Use first 1500 chars to avoid context bloat
        system += f"\n\nLONG-TERM MEMORY:\n{lt[:1500]}\n"
    return system

def run_agent(
    user_input: str,
    messages: list,
    cfg: dict,
    agent_role: str = "",
    auto_approve: bool = False,
    quiet: bool = False,
) -> str:
    """
    Run one turn. Returns final assistant text.
    Includes self-healing: if code fails tests, auto-fix up to MAX_SELF_HEAL times.
    """
    provider = cfg.get("provider", "anthropic")
    model = cfg.get("model", "claude-sonnet-4-6")

    # Auto-compact if needed
    if should_compact(messages) and len(messages) > 4:
        if not quiet:
            ui.show_info("📦 Compacting context...")
        _do_compact(messages, cfg)

    role = agent_role or ("developer" if not cfg.get("agents_mode") else "")
    system = _build_system(cfg, role)

    prov.add_user_message(messages, user_input)
    hooks.fire("OnMessage", role="user", content=user_input)

    final_text = ""
    turns = 0
    test_failures = 0  # For self-healing

    while turns < MAX_TOOL_TURNS:
        turns += 1
        text_chunks: list[str] = []
        streaming_started = False

        def on_chunk(chunk: str):
            nonlocal streaming_started
            if not streaming_started:
                streaming_started = True
                if not quiet:
                    ui.clear_line()
                    ui.show_response_start()
            if not quiet:
                ui.stream_response(chunk)
            text_chunks.append(chunk)

        try:
            resp = prov.chat(cfg, messages, system=system, stream_cb=on_chunk)
        except RuntimeError as e:
            ui.clear_line()
            err = str(e)
            if "No API keys" in err:
                ui.show_error("No API key found. Run /config to add one.")
                ui.show_info("Free options: Groq → console.groq.com | Gemini → aistudio.google.com")
            elif "All models failed" in err:
                ui.show_error("All providers failed. Check your keys with /keys")
            else:
                ui.show_error(err)
            messages.pop()
            return ""
        except Exception as e:
            ui.clear_line()
            err = str(e)
            if "rate_limit" in err.lower():
                ui.show_error("Rate limited. Switching to next provider automatically...")
            elif "invalid_key" in err.lower() or "auth" in err.lower():
                ui.show_error("Invalid API key. Run /config to fix.")
            elif "timeout" in err.lower():
                ui.show_error("Request timed out. Try again or switch model with /model")
            elif "connection" in err.lower():
                ui.show_error("Connection failed. Check your internet.")
            else:
                ui.show_error(f"Error: {err[:120]}")
            hooks.fire("OnError", error=err)
            messages.pop()
            return ""

        if not quiet:
            ui.clear_line()

        resp_text = "".join(text_chunks)
        resp.text = resp_text
        final_text = resp_text

        if resp_text and not streaming_started and not quiet:
            ui.show_full_response(resp_text)
        elif streaming_started and not quiet:
            ui.show_response_end(resp_text)

        if not resp.has_tools:
            prov.add_assistant_message(resp.provider, messages, resp)
            if len(resp_text) > 200:
                mem.working_add(resp_text[:500], tag="response")
            break

        # ── Tool calls ────────────────────────────────────────────────────────
        prov.add_assistant_message(resp.provider, messages, resp)
        tool_results = []
        test_failed_this_turn = False

        for tc in resp.tool_calls:
            description = describe_call(tc.name, tc.inputs)
            perm = get_permission(tc.name)
            hooks.fire("PreToolUse", name=tc.name, inputs=tc.inputs)

            allowed = True
            if not auto_approve and not cfg.get("auto_approve"):
                if perm == PermissionMode.DANGEROUS:
                    allowed = ui.ask_tool_permission(tc.name, description, force=True)
                elif perm == PermissionMode.MODERATE:
                    if hooks.is_approved_session(tc.name):
                        allowed = True
                    else:
                        allowed = ui.ask_tool_permission(tc.name, description, force=False)
                        if allowed:
                            hooks.mark_approved_session(tc.name)

            if not allowed:
                result = f"⛔ Tool '{tc.name}' denied."
                if not quiet: ui.show_tool_denied(tc.name)
            else:
                if not quiet: ui.show_tool_running(tc.name, description)
                result = run_tool(tc.name, tc.inputs)
                if not quiet: ui.show_tool_result(tc.name, result)

            hooks.fire("PostToolUse", name=tc.name, inputs=tc.inputs, result=result)
            tool_results.append((tc, result))

            # ── Self-healing: detect test failures ───────────────────────────
            if tc.name == "bash" and _is_test_failure(result):
                test_failed_this_turn = True

        prov.add_tool_results(resp.provider, messages, tool_results)

        # Auto-fix loop: if tests failed and we haven't exceeded limit
        if test_failed_this_turn and test_failures < MAX_SELF_HEAL:
            test_failures += 1
            if not quiet:
                ui.show_info(f"🔧 Test failed — auto-fixing (attempt {test_failures}/{MAX_SELF_HEAL})...")
            # Add a self-fix instruction
            fix_prompt = (
                f"Tests failed (attempt {test_failures}/{MAX_SELF_HEAL}). "
                "Do the following:\n"
                "1. Read the exact error message above carefully\n"
                "2. Identify the root cause\n"
                "3. Fix ONLY the broken part — don't rewrite everything\n"
                "4. Run tests again to verify the fix\n"
                "Be surgical. Don't introduce new bugs."
            )
            prov.add_user_message(messages, fix_prompt)
            # Continue loop (will make another AI call to fix)
            continue

    if not quiet:
        from .cost import get_session_stats
        stats = get_session_stats()
        if stats["total_tokens"] > 0:
            ui.show_cost(stats["cost"], stats["total_tokens"])

    hooks.fire("OnMessage", role="assistant", content=final_text)
    return final_text

def _is_test_failure(result: str) -> bool:
    """Detect if a bash result indicates a test failure."""
    result_lower = result.lower()
    fail_signals = [
        "failed", "error:", "assertionerror", "exit code: 1",
        "tests failed", "test failed", "failures=", "errors=",
        "traceback", "syntaxerror", "nameerror", "typeerror",
    ]
    pass_signals = ["passed", "ok", "success", "all tests"]
    if any(s in result_lower for s in pass_signals):
        return False
    return any(s in result_lower for s in fail_signals)

def _do_compact(messages: list, cfg: dict):
    """Compact conversation via AI summary."""
    prompt = build_compact_prompt(messages)
    temp_msgs = [{"role": "user", "content": prompt}]
    try:
        resp = prov.chat(cfg, temp_msgs, stream_cb=None,
                         system="You are a conversation summarizer. Be dense and specific.")
        new_msgs = compact_messages(messages, resp.text)
        messages.clear()
        messages.extend(new_msgs)
        mem.lt_append(f"Session summary: {resp.text[:300]}", "compact")
        hooks.fire("OnCompact", summary=resp.text)
    except Exception:
        pass
