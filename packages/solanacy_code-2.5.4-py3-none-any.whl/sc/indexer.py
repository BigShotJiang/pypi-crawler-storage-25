"""Codebase indexer — semantic search over your project."""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from pathlib import Path
from typing import Optional

INDEX_FILE = Path.home() / ".mycode" / "codebase_index.json"

SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv",
             "dist", "build", ".next", ".nuxt", "target", ".mycode"}
SKIP_EXTS = {".pyc", ".pyo", ".class", ".o", ".so", ".dll", ".exe",
             ".jpg", ".jpeg", ".png", ".gif", ".svg", ".ico", ".woff",
             ".ttf", ".eot", ".mp3", ".mp4", ".zip", ".tar", ".gz", ".lock"}
CODE_EXTS = {".py", ".js", ".ts", ".jsx", ".tsx", ".rs", ".go", ".java",
             ".c", ".cpp", ".h", ".hpp", ".cs", ".rb", ".php", ".swift",
             ".kt", ".dart", ".r", ".sh", ".bash", ".zsh", ".sql", ".md",
             ".html", ".css", ".scss", ".yaml", ".yml", ".toml", ".json", ".env"}


# Simple dict-based entries — no dataclass needed


def _file_hash(path: Path) -> str:
    try:
        return hashlib.md5(path.read_bytes()).hexdigest()[:8]
    except Exception:
        return "0"


def _extract_symbols(content: str, ext: str) -> list[str]:
    """Extract function/class names for better search."""
    symbols = []
    patterns = {
        ".py": [r"^def (\w+)", r"^class (\w+)", r"^    def (\w+)"],
        ".js": [r"function (\w+)", r"const (\w+)\s*=\s*(?:async\s*)?\(", r"class (\w+)"],
        ".ts": [r"function (\w+)", r"class (\w+)", r"interface (\w+)", r"type (\w+)"],
        ".rs": [r"fn (\w+)", r"struct (\w+)", r"enum (\w+)", r"trait (\w+)"],
        ".go": [r"func (\w+)", r"type (\w+)"],
    }
    for pat in patterns.get(ext, []):
        symbols.extend(re.findall(pat, content, re.MULTILINE))
    return symbols[:30]


def _chunk_file(content: str, max_chunk: int = 500) -> list[str]:
    """Split file into chunks by function/class boundaries."""
    lines = content.splitlines()
    chunks = []
    current: list[str] = []
    for line in lines:
        current.append(line)
        if len("\n".join(current)) > max_chunk:
            chunks.append("\n".join(current))
            current = []
    if current:
        chunks.append("\n".join(current))
    return chunks


class CodebaseIndex:
    def __init__(self, root: str = "."):
        self.root = Path(root).resolve()
        self.entries: list[dict] = []

    def build(self, on_progress: callable = None) -> int:
        """Scan and index the codebase. Returns file count."""
        self.entries = []
        count = 0

        for root, dirs, files in os.walk(self.root):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for fname in files:
                fpath = Path(root) / fname
                ext = fpath.suffix.lower()
                if ext not in CODE_EXTS:
                    continue
                if fpath.stat().st_size > 200_000:  # skip huge files
                    continue
                try:
                    content = fpath.read_text(errors="replace")
                except Exception:
                    continue

                rel = str(fpath.relative_to(self.root))
                symbols = _extract_symbols(content, ext)

                # Store as chunks for large files
                if len(content) > 3000:
                    for i, chunk in enumerate(_chunk_file(content)):
                        self.entries.append({
                            "path": rel,
                            "chunk": i,
                            "symbols": symbols,
                            "content": chunk[:1000],
                            "hash": _file_hash(fpath),
                        })
                else:
                    self.entries.append({
                        "path": rel,
                        "chunk": 0,
                        "symbols": symbols,
                        "content": content[:2000],
                        "hash": _file_hash(fpath),
                    })
                count += 1
                if on_progress:
                    on_progress(count, rel)

        self._save()
        return count

    def _save(self) -> None:
        INDEX_FILE.parent.mkdir(parents=True, exist_ok=True)
        INDEX_FILE.write_text(json.dumps({
            "root": str(self.root),
            "entries": self.entries,
        }, ensure_ascii=False))

    def load(self) -> bool:
        if INDEX_FILE.exists():
            try:
                data = json.loads(INDEX_FILE.read_text())
                self.root = Path(data.get("root", "."))
                self.entries = data.get("entries", [])
                return True
            except Exception:
                return False
        return False

    def search(self, query: str, top_k: int = 10) -> list[dict]:
        """BM25-like keyword search over the index."""
        query_terms = set(re.findall(r"\w+", query.lower()))
        if not query_terms:
            return []

        scored: list[tuple[float, dict]] = []
        for entry in self.entries:
            text = (entry.get("content", "") + " " + " ".join(entry.get("symbols", ""))).lower()
            # Count term matches
            score = 0.0
            for term in query_terms:
                if term in text:
                    score += text.count(term)
                # Check symbols specifically (higher weight)
                for sym in entry.get("symbols", []):
                    if term in sym.lower():
                        score += 3.0
                # Path match (high weight)
                if term in entry.get("path", "").lower():
                    score += 5.0
            if score > 0:
                scored.append((score, entry))

        scored.sort(key=lambda x: -x[0])
        return [e for _, e in scored[:top_k]]

    def search_formatted(self, query: str, top_k: int = 8) -> str:
        results = self.search(query, top_k)
        if not results:
            return "No results found. Run /index to build the codebase index."
        lines = [f"🔍 Search results for '{query}':\n"]
        seen_paths = set()
        for r in results:
            path = r["path"]
            if path not in seen_paths:
                seen_paths.add(path)
                syms = ", ".join(r["symbols"][:5]) if r.get("symbols") else ""
                lines.append(f"📄 {path}" + (f" [{syms}]" if syms else ""))
            snippet = r.get("content", "")[:200].replace("\n", " ")
            lines.append(f"   {snippet}")
        return "\n".join(lines)

    def stats(self) -> dict:
        paths = {e["path"] for e in self.entries}
        return {
            "files": len(paths),
            "chunks": len(self.entries),
            "root": str(self.root),
        }


# Global instance
_index = CodebaseIndex()


def get_index() -> CodebaseIndex:
    return _index


def load_or_build(root: str = ".", quiet: bool = False) -> CodebaseIndex:
    idx = CodebaseIndex(root)
    if not idx.load():
        if not quiet:
            pass  # caller shows progress
    return idx
