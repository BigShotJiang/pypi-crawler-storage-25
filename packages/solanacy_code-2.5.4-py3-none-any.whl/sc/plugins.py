"""Plugin system — load custom Python plugins from ~/.mycode/plugins/."""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

from .config import PLUGINS_DIR

_loaded_plugins: dict[str, Any] = {}
_plugin_tools: list[dict] = []
_plugin_commands: dict[str, callable] = {}


def load_all() -> list[str]:
    """Load all plugins from plugins directory. Returns list of loaded plugin names."""
    loaded = []
    if not PLUGINS_DIR.exists():
        return loaded

    for plugin_dir in PLUGINS_DIR.iterdir():
        if plugin_dir.is_dir():
            manifest = plugin_dir / "plugin.json"
            main_py = plugin_dir / "main.py"
            if manifest.exists() and main_py.exists():
                try:
                    name = _load_plugin(plugin_dir, manifest, main_py)
                    loaded.append(name)
                except Exception as e:
                    pass  # Silently skip broken plugins
    return loaded


def _load_plugin(plugin_dir: Path, manifest_path: Path, main_path: Path) -> str:
    manifest = json.loads(manifest_path.read_text())
    name = manifest.get("name", plugin_dir.name)

    spec = importlib.util.spec_from_file_location(f"mycode_plugin_{name}", main_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    _loaded_plugins[name] = {
        "module": module,
        "manifest": manifest,
    }

    # Register tools
    if hasattr(module, "TOOLS"):
        for tool in module.TOOLS:
            _plugin_tools.append(tool)

    # Register slash commands
    if hasattr(module, "COMMANDS"):
        for cmd_name, cmd_fn in module.COMMANDS.items():
            _plugin_commands[cmd_name] = cmd_fn

    return name


def get_plugin_tools() -> list[dict]:
    return list(_plugin_tools)


def run_plugin_command(name: str, args: str, **ctx) -> str | None:
    fn = _plugin_commands.get(name)
    if fn:
        try:
            return fn(args=args, **ctx)
        except Exception as e:
            return f"❌ Plugin command error: {e}"
    return None


def list_plugins() -> list[dict]:
    result = []
    for name, data in _loaded_plugins.items():
        m = data["manifest"]
        result.append({
            "name": name,
            "version": m.get("version", "?"),
            "description": m.get("description", ""),
            "tools": [t["name"] for t in m.get("tools", [])],
        })
    return result


def create_example_plugin() -> Path:
    """Create an example plugin in plugins directory."""
    example_dir = PLUGINS_DIR / "example"
    example_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "name": "example",
        "version": "1.0.0",
        "description": "Example plugin — shows how to add custom tools and commands",
    }
    (example_dir / "plugin.json").write_text(json.dumps(manifest, indent=2))

    code = '''\
"""Example mycode plugin."""

def hello_tool(message: str = "world") -> str:
    return f"Hello, {message}!"

# Custom tools (Anthropic format)
TOOLS = [
    {
        "name": "hello",
        "description": "Say hello",
        "input_schema": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "default": "world"}
            }
        }
    }
]

# Slash commands: /example
def _cmd_example(args="", **ctx):
    return f"Example plugin says: {args or 'hello!'}"

COMMANDS = {
    "example": _cmd_example,
}

# Tool runner (called by run_tool)
def run(name: str, inputs: dict) -> str:
    if name == "hello":
        return hello_tool(**inputs)
    return f"Unknown tool: {name}"
'''
    (example_dir / "main.py").write_text(code)
    return example_dir
