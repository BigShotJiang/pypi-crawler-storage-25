"""Hooks system — PreToolUse, PostToolUse, OnError, OnMessage."""
from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from typing import Any, Callable

_HOOKS: dict[str, list[Callable]] = {
    "PreToolUse": [],
    "PostToolUse": [],
    "OnError": [],
    "OnMessage": [],
    "OnCompact": [],
}

_session_approved: set[str] = set()  # tools approved once-per-session


def register(event: str, fn: Callable) -> None:
    if event in _HOOKS:
        _HOOKS[event].append(fn)


def clear(event: str | None = None) -> None:
    if event:
        _HOOKS[event] = []
    else:
        for k in _HOOKS:
            _HOOKS[k] = []


def fire(event: str, **kwargs) -> list[Any]:
    results = []
    for fn in _HOOKS.get(event, []):
        try:
            results.append(fn(**kwargs))
        except Exception as e:
            pass
    return results


def load_from_config(cfg: dict) -> None:
    """Load hook scripts from config."""
    hooks_cfg = cfg.get("hooks", {})
    for event, scripts in hooks_cfg.items():
        for script in scripts:
            _register_script_hook(event, script)


def _register_script_hook(event: str, script: str) -> None:
    """Register a shell script as a hook."""
    def hook_fn(**kwargs):
        env_data = json.dumps(kwargs)
        try:
            subprocess.run(
                script, shell=True,
                input=env_data, capture_output=True, text=True, timeout=5
            )
        except Exception:
            pass
    register(event, hook_fn)


# ── Built-in hooks ────────────────────────────────────────────────────────────

def auto_git_on_write(path: str = "", **kwargs):
    """Auto-stage file on write (if git repo)."""
    if path:
        try:
            subprocess.run(["git", "add", path], capture_output=True, timeout=5)
        except Exception:
            pass


def log_tool_use(name: str = "", inputs: dict = None, **kwargs):
    """Log tool calls to ~/.mycode/tool.log."""
    log_file = Path.home() / ".mycode" / "tool.log"
    try:
        with log_file.open("a") as f:
            ts = time.strftime("%H:%M:%S")
            f.write(f"{ts} {name} {json.dumps(inputs or {})[:80]}\n")
    except Exception:
        pass


# ── Session-level permission cache ────────────────────────────────────────────

def mark_approved_session(tool_name: str) -> None:
    _session_approved.add(tool_name)


def is_approved_session(tool_name: str) -> bool:
    return tool_name in _session_approved


def reset_session_approvals() -> None:
    _session_approved.clear()
