"""Session management — save/load/checkpoint/restore."""
from __future__ import annotations

import json
import time
from pathlib import Path

from .config import CONFIG_DIR, SESSIONS_DIR, CHECKPOINTS_DIR


def save_session(messages: list[dict], provider: str, model: str,
                 name: str = None, summary: str = "") -> str:
    session_id = name or f"session_{int(time.time())}"
    data = {
        "id": session_id,
        "provider": provider,
        "model": model,
        "timestamp": time.time(),
        "messages": messages,
        "summary": summary,
    }
    f = SESSIONS_DIR / f"{session_id}.json"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    return session_id


def load_session(session_id: str) -> dict | None:
    f = SESSIONS_DIR / f"{session_id}.json"
    if not f.exists():
        # Try partial match
        matches = list(SESSIONS_DIR.glob(f"*{session_id}*.json"))
        if matches:
            f = matches[0]
        else:
            return None
    try:
        return json.loads(f.read_text())
    except Exception:
        return None


def list_sessions(limit: int = 20) -> list[dict]:
    sessions = []
    for f in sorted(SESSIONS_DIR.glob("*.json"),
                    key=lambda x: x.stat().st_mtime, reverse=True)[:limit]:
        try:
            data = json.loads(f.read_text())
            sessions.append({
                "id": data.get("id", f.stem),
                "provider": data.get("provider", "?"),
                "model": data.get("model", "?"),
                "timestamp": data.get("timestamp", 0),
                "message_count": len(data.get("messages", [])),
                "summary": data.get("summary", "")[:80],
            })
        except Exception:
            pass
    return sessions


def delete_session(session_id: str) -> bool:
    f = SESSIONS_DIR / f"{session_id}.json"
    if f.exists():
        f.unlink()
        return True
    return False


# ── Checkpoints ───────────────────────────────────────────────────────────────

def save_checkpoint(messages: list[dict], cfg: dict,
                    label: str = "") -> str:
    ckpt_id = label or f"ckpt_{int(time.time())}"
    data = {
        "id": ckpt_id,
        "timestamp": time.time(),
        "label": label,
        "messages": messages,
        "cfg_snapshot": {
            "provider": cfg.get("provider"),
            "model": cfg.get("model"),
        },
    }
    f = CHECKPOINTS_DIR / f"{ckpt_id}.json"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    return ckpt_id


def load_checkpoint(ckpt_id: str) -> dict | None:
    f = CHECKPOINTS_DIR / f"{ckpt_id}.json"
    if not f.exists():
        # Partial match
        matches = list(CHECKPOINTS_DIR.glob(f"*{ckpt_id}*.json"))
        if matches:
            f = sorted(matches, key=lambda x: x.stat().st_mtime)[-1]
        else:
            return None
    try:
        return json.loads(f.read_text())
    except Exception:
        return None


def list_checkpoints(limit: int = 10) -> list[dict]:
    result = []
    for f in sorted(CHECKPOINTS_DIR.glob("*.json"),
                    key=lambda x: x.stat().st_mtime, reverse=True)[:limit]:
        try:
            data = json.loads(f.read_text())
            result.append({
                "id": data.get("id", f.stem),
                "label": data.get("label", ""),
                "timestamp": data.get("timestamp", 0),
                "message_count": len(data.get("messages", [])),
            })
        except Exception:
            pass
    return result


def export_session(messages: list[dict], fmt: str = "markdown") -> str:
    """Export session as markdown or JSON string."""
    if fmt == "json":
        return json.dumps(messages, indent=2, ensure_ascii=False)
    lines = ["# MyCode Session Export\n"]
    for m in messages:
        role = m.get("role", "?").upper()
        content = m.get("content", "")
        if isinstance(content, list):
            text_parts = [b.get("text", "") for b in content
                          if isinstance(b, dict) and b.get("type") == "text"]
            content = "\n".join(text_parts)
        lines.append(f"## {role}\n{content}\n")
    return "\n".join(lines)
