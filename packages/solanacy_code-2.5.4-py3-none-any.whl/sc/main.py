"""Solanacy Code v2.5 — Entry point + REPL."""
from __future__ import annotations
import os, sys, time

from . import ui
from .agent import run_agent
from .config import (load_config, save_config, get_next_key,
                     provider_names, get_provider_info, CONFIG_DIR)
from .session import (save_session, load_session, list_sessions,
                      save_checkpoint, load_checkpoint, list_checkpoints,
                      export_session)
from . import memory as mem
from . import hooks, plugins
from .cost import get_session_stats, get_daily_cost, get_monthly_cost, reset_session
from .indexer import CodebaseIndex


def _handle_slash(cmd: str, messages: list, cfg: dict,
                  state: dict) -> tuple[list, dict, bool]:
    parts = cmd.strip().split(None, 1)
    name = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""

    match name:

        case "/exit" | "/quit" | "/q":
            return messages, cfg, True

        case "/undo":
            from .tools import _undo_last
            ui.show_info(_undo_last())

        case "/help":
            ui.show_help()

        case "/tools":
            ui.show_tools()

        case "/models":
            ui.show_models(cfg)

        case "/status":
            ui.show_status(cfg["provider"], cfg["model"],
                cfg.get("auto_approve", False), len(messages),
                agents_mode=cfg.get("agents_mode", False),
                think_mode=cfg.get("think_mode", False))

        case "/keys":
            ui.show_keys(cfg)

        case "/clear":
            messages = []
            reset_session()
            hooks.reset_session_approvals()
            ui.show_success("Conversation cleared.")

        case "/compact":
            if len(messages) < 4:
                ui.show_info("Conversation too short to compact.")
            else:
                ui.show_info("Compacting...")
                from .agent import _do_compact
                _do_compact(messages, cfg)
                ui.show_success(f"Compacted → {len(messages)} messages.")

        case "/model":
            new_provider, new_model = ui.pick_provider_and_model(
                cfg["provider"], cfg["model"], cfg)
            cfg["provider"] = new_provider
            cfg["model"] = new_model
            save_config(cfg)
            ui.show_success(f"Switched → {new_provider}/{new_model}")

        case "/config":
            cfg = ui.configure_api_keys(cfg)
            save_config(cfg)
            ui.show_success("Config saved.")

        case "/auto":
            cfg["auto_approve"] = not cfg.get("auto_approve", False)
            ui.show_success(f"Auto-approve: {'ON' if cfg['auto_approve'] else 'OFF'}")
            save_config(cfg)

        case "/think":
            cfg["think_mode"] = not cfg.get("think_mode", False)
            ui.show_success(f"Think mode: {'ON' if cfg['think_mode'] else 'OFF'}")
            save_config(cfg)

        case "/agents":
            cfg["agents_mode"] = not cfg.get("agents_mode", False)
            ui.show_success(f"Multi-agent: {'ON' if cfg['agents_mode'] else 'OFF'}")
            save_config(cfg)

        case "/agent":
            valid = ["architect", "developer", "reviewer", "researcher", "debugger"]
            if arg in valid:
                state["force_agent"] = arg
                ui.show_success(f"Next message → {arg} agent")
            elif arg in ("reset", "off"):
                state.pop("force_agent", None)
                ui.show_success("Agent override cleared")
            else:
                ui.show_info(f"Valid: {', '.join(valid)}")

        case "/hybrid":
            cfg["hybrid_mode"] = not cfg.get("hybrid_mode", False)
            ui.show_success(f"Hybrid mode: {'ON' if cfg['hybrid_mode'] else 'OFF'}")
            save_config(cfg)

        # ── Memory ────────────────────────────────────────────────────────────
        case "/memory":
            content = mem.lt_read()
            size = mem.get_memory_size()
            ui.show_info(f"Memory size: {size} chars")
            ui.show_info(content[:3000] or "(empty)")

        case "/memstats":
            size = mem.get_memory_size()
            from .memory import LT_MAX_CHARS
            pct = size / LT_MAX_CHARS * 100
            ui.show_info(f"Memory: {size:,} / {LT_MAX_CHARS:,} chars ({pct:.0f}%)")
            if mem.is_memory_full():
                ui.show_warning("Memory is almost full — will auto-trim on next write.")
            else:
                ui.show_success("Memory has space.")

        case "/remember":
            if arg:
                mem.lt_append(arg)
                ui.show_success(f"Saved: {arg[:60]}")
            else:
                ui.show_error("Usage: /remember <text>")

        case "/forget":
            if arg:
                n = mem.lt_delete(arg)
                ui.show_success(f"Deleted {n} entries matching '{arg}'")
            else:
                ui.show_error("Usage: /forget <keyword>")

        # ── TODO ──────────────────────────────────────────────────────────────
        case "/todo":
            from .tools import _todo_read
            ui.show_info(_todo_read())

        case "/add":
            from .tools import _todo_write
            if arg:
                ui.show_success(_todo_write("add", arg))
            else:
                ui.show_error("Usage: /add <task>")

        case "/done":
            from .tools import _todo_write
            if arg:
                ui.show_success(_todo_write("done", arg))
            else:
                ui.show_error("Usage: /done <task>")

        # ── Cost ──────────────────────────────────────────────────────────────
        case "/cost":
            stats = get_session_stats()
            ui.console.print(f"\n  Session:  [bold]${stats['cost']:.4f}[/]  ({stats['total_tokens']:,} tokens)")
            ui.console.print(f"  Daily:    [bold]${get_daily_cost():.4f}[/]")
            ui.console.print(f"  Monthly:  [bold]${get_monthly_cost():.4f}[/]")

        case "/budget":
            if arg:
                try:
                    cfg["budget"]["daily_limit"] = float(arg)
                    save_config(cfg)
                    ui.show_success(f"Daily budget: ${float(arg):.2f}")
                except ValueError:
                    ui.show_error("Usage: /budget 1.00")
            else:
                b = cfg.get("budget", {})
                ui.show_info(f"Daily: ${b.get('daily_limit',0):.2f}  Monthly: ${b.get('monthly_limit',0):.2f}")

        # ── Index / Search ────────────────────────────────────────────────────
        case "/index":
            root = arg or "."
            ui.show_info(f"Indexing {os.path.abspath(root)}...")
            idx = CodebaseIndex(root)
            total = idx.build()
            state["index"] = idx
            stats = idx.stats()
            ui.show_success(f"Indexed {stats['files']} files, {stats['chunks']} chunks")

        case "/search":
            if not arg:
                ui.show_error("Usage: /search <query>")
            else:
                idx = state.get("index") or CodebaseIndex()
                if not idx.load():
                    ui.show_error("No index. Run /index first.")
                else:
                    state["index"] = idx
                    ui.show_info(idx.search_formatted(arg))

        # ── Git ───────────────────────────────────────────────────────────────
        case "/git":
            from .tools import _git_status
            ui.show_info(_git_status())

        case "/diff":
            from .tools import _git_diff
            result = _git_diff(staged=False, file=arg or None)
            from rich.syntax import Syntax
            ui.console.print(Syntax(result[:4000], "diff", theme="dracula"))

        case "/commit":
            if not arg:
                ui.show_error("Usage: /commit <message>")
            else:
                from .tools import _git_commit
                ui.show_info(_git_commit(arg))

        # ── Sessions ──────────────────────────────────────────────────────────
        case "/save":
            sid = save_session(messages, cfg["provider"], cfg["model"], name=arg or None)
            ui.show_success(f"Saved: {sid}")

        case "/load":
            if not arg:
                sessions = list_sessions()
                if not sessions:
                    ui.show_info("No saved sessions.")
                else:
                    for s in sessions[:10]:
                        ts = time.strftime("%m/%d %H:%M", time.localtime(s["timestamp"]))
                        ui.console.print(f"  [{ui.ACCENT}]{s['id']}[/]  [{ui.MUTED}]{s['provider']}/{s['model']}  {ts}[/]")
                    ui.show_info("Usage: /load <id>")
            else:
                data = load_session(arg)
                if data is None:
                    ui.show_error(f"Not found: {arg}")
                else:
                    messages = data["messages"]
                    cfg["provider"] = data.get("provider", cfg["provider"])
                    cfg["model"] = data.get("model", cfg["model"])
                    ui.show_success(f"Loaded '{arg}' ({len(messages)} msgs)")

        case "/sessions":
            sessions = list_sessions()
            if not sessions:
                ui.show_info("No saved sessions.")
            else:
                for s in sessions[:15]:
                    ts = time.strftime("%m/%d %H:%M", time.localtime(s["timestamp"]))
                    ui.console.print(f"  [{ui.ACCENT}]{s['id']:<25}[/]  [{ui.MUTED}]{s['provider']}/{s['model']:<25}  {ts}[/]")

        case "/snapshot":
            ckpt = save_checkpoint(messages, cfg, label=arg or "")
            ui.show_success(f"Checkpoint: {ckpt}")

        case "/restore":
            if not arg:
                ckpts = list_checkpoints()
                for c in ckpts:
                    ts = time.strftime("%m/%d %H:%M", time.localtime(c["timestamp"]))
                    ui.console.print(f"  [{ui.ACCENT}]{c['id']}[/]  [{ui.MUTED}]{ts}  {c['message_count']} msgs[/]")
                ui.show_info("Usage: /restore <id>")
            else:
                data = load_checkpoint(arg)
                if not data:
                    ui.show_error(f"Not found: {arg}")
                else:
                    messages = data["messages"]
                    ui.show_success(f"Restored '{arg}'")

        case "/init":
            if arg:
                parts2 = arg.split("|") if "|" in arg else [arg, ""]
                mem.init_project_memory(parts2[0].strip(), parts2[1].strip() if len(parts2) > 1 else "")
                ui.show_success(f"Created SC.md in {os.getcwd()}")
            else:
                ui.show_info("Analyzing codebase...")
                import glob as _glob
                files = _glob.glob("**/*.py", recursive=True)[:20]
                files += _glob.glob("**/*.js", recursive=True)[:10]
                files += _glob.glob("**/*.ts", recursive=True)[:10]
                files += _glob.glob("README*", recursive=False)[:1]
                file_list = "\n".join(files[:30])
                # read first file for context
                sample = ""
                for f in files[:3]:
                    try:
                        with open(f) as fh:
                            sample += f"\n--- {f} ---\n" + fh.read()[:500]
                    except Exception:
                        pass
                prompt = f"""Analyze this codebase and generate a concise SC.md project context file.

Files found:
{file_list}

Sample code:
{sample}

Generate SC.md with these sections:
# Project
One line description.

# Stack
Key technologies.

# Structure
Key files and what they do.

# Rules
Important coding conventions to follow.

Keep it under 300 words. Be specific."""
                from . import providers as prov
                msgs = []
                prov.add_user_message(msgs, prompt)
                try:
                    resp = prov.chat(cfg, msgs, system="You generate concise project context files.")
                    sc_md = resp.text.strip()
                    if not sc_md:
                        ui.show_error("Model returned empty response. Try /model to switch provider.")
                    else:
                        with open("SC.md", "w") as fh:
                            fh.write(sc_md)
                        ui.show_success(f"SC.md generated in {os.getcwd()}")
                        ui.show_info(sc_md[:300] + "...")
                except Exception as e:
                    ui.show_error(f"Failed: {e}")

        case "/share":
            if not messages:
                ui.show_info("Nothing to share.")
            else:
                fmt = "json" if arg == "json" else "markdown"
                content = export_session(messages, fmt)
                fname = f"sc_session_{int(time.time())}.{'json' if fmt=='json' else 'md'}"
                with open(fname, "w") as f:
                    f.write(content)
                ui.show_success(f"Exported → {fname}")

        case "/plugins":
            pl = plugins.list_plugins()
            if not pl:
                ui.show_info(f"No plugins. Place in: {plugins.PLUGINS_DIR}")
            else:
                for p in pl:
                    ui.console.print(f"  [{ui.ACCENT}]{p['name']}[/] v{p['version']}  [{ui.MUTED}]{p['description']}[/]")

        case "/benchmark":
            _run_benchmark(arg or "Write hello world in Python", cfg)

        case _:
            result = plugins.run_plugin_command(name.lstrip("/"), arg)
            if result:
                ui.show_info(result)
            else:
                ui.show_error(f"Unknown: {name}  (type /help)")

    return messages, cfg, False


def _run_benchmark(prompt: str, cfg: dict):
    import time
    from . import providers as prov
    from .router import PROVIDERS
    ui.show_info(f"🏁 Benchmarking: '{prompt[:60]}'")
    results = []
    for provider in provider_names():
        if not cfg["keys"].get(provider):
            continue
        test_cfg = {**cfg, "provider": provider,
                    "model": get_provider_info(provider).get("default", "")}
        if not test_cfg["model"]:
            continue
        msgs = []
        prov.add_user_message(msgs, prompt)
        t0 = time.time()
        try:
            resp = prov.chat(test_cfg, msgs)
            elapsed = time.time() - t0
            results.append({"provider": provider, "model": test_cfg["model"],
                            "tokens": resp.out_tokens or len(resp.text.split()),
                            "time": elapsed, "preview": resp.text[:80]})
        except Exception as e:
            results.append({"provider": provider, "error": str(e)[:60]})
    for r in results:
        if "error" in r:
            ui.console.print(f"  [{ui.ERROR_C}]✗ {r['provider']}: {r['error']}[/]")
        else:
            speed = r["tokens"] / max(r["time"], 0.1)
            ui.console.print(
                f"  [{ui.SUCCESS}]✓[/] [{ui.ACCENT}]{r['provider']}/{r['model']}[/]  "
                f"[{ui.MUTED}]{r['time']:.1f}s  ~{speed:.0f} tok/s[/]\n"
                f"    [{ui.MUTED}]{r['preview']}...[/]")


def _first_run_setup(cfg: dict) -> dict:
    has_key = any(cfg["keys"].get(p) for p in provider_names())
    if not has_key:
        ui.console.print(
            f"\n  [{ui.WARNING}]No API keys configured.[/]\n"
            f"  [{ui.MUTED}]Free options:[/]\n"
            f"  [{ui.ACCENT}]• Groq[/]   [{ui.MUTED}]console.groq.com (Llama 3.3 70B — free)[/]\n"
            f"  [{ui.ACCENT}]• Gemini[/] [{ui.MUTED}]aistudio.google.com (Gemini 2.5 Flash — free)[/]\n"
        )
        cfg = ui.configure_api_keys(cfg)
        save_config(cfg)
    return cfg


def main():
    cfg = load_config()
    cfg = _first_run_setup(cfg)
    hooks.load_from_config(cfg)
    loaded_plugins = plugins.load_all()

    ui.show_banner(cfg["provider"], cfg["model"])
    if loaded_plugins:
        ui.show_info(f"Plugins: {', '.join(loaded_plugins)}")

    project_ctx = mem.read_project_memory()
    if project_ctx:
        ui.show_info("📁 Project context loaded (SC.md)")

    messages: list[dict] = []
    state: dict = {}

    while True:
        try:
            cwd = os.getcwd()
            user_input = ui.prompt_input(cwd, cfg)
        except (KeyboardInterrupt, EOFError):
            ui.console.print(f"\n  [{ui.MUTED}]Bye! 👋[/]")
            break

        if not user_input.strip():
            continue

        if user_input.startswith("/"):
            messages, cfg, should_exit = _handle_slash(user_input, messages, cfg, state)
            if should_exit:
                ui.console.print(f"\n  [{ui.MUTED}]Bye! 👋[/]")
                break
            continue

        if not cfg["keys"].get(cfg["provider"]):
            # Try to auto-switch to a provider that has a key
            for pid in provider_names():
                if cfg["keys"].get(pid):
                    cfg["provider"] = pid
                    cfg["model"] = get_provider_info(pid).get("default", "")
                    ui.show_info(f"Auto-switched to {pid}/{cfg['model']} (has key)")
                    break
            else:
                ui.show_error("No API keys configured. Run /config")
                continue

        from .cost import check_budget
        ok, budget_msg = check_budget(cfg)
        if budget_msg:
            ui.show_warning(budget_msg)
        if not ok:
            ui.show_error("Budget exceeded. Use /budget to adjust.")
            continue

        agent_role = ""
        if state.get("force_agent"):
            agent_role = state.pop("force_agent")
        elif cfg.get("agents_mode"):
            from .agents.base import select_agent
            agent_role = select_agent(user_input)
            ui.show_info(f"🤖 Agent: [{ui.AGENT_C}]{agent_role}[/]")

        if cfg.get("agents_mode") and len(user_input) > 80:
            complex_kw = ["implement", "build", "create complete", "refactor",
                          "full", "entire", "whole project", "add feature"]
            if any(kw in user_input.lower() for kw in complex_kw):
                ui.show_info("🤖 Complex task → multi-agent orchestration...")
                try:
                    from .orchestrator import auto_orchestrate
                    result = auto_orchestrate(user_input, cfg)
                    ui.show_info(result[:2000])
                    continue
                except Exception as e:
                    ui.show_warning(f"Orchestration failed ({e}), using single agent...")

        try:
            run_agent(user_input=user_input, messages=messages, cfg=cfg,
                      agent_role=agent_role, auto_approve=cfg.get("auto_approve", False))
        except KeyboardInterrupt:
            ui.console.print(f"\n  [{ui.WARNING}]Interrupted.[/]")
            if messages and messages[-1]["role"] == "user":
                messages.pop()
        except Exception as e:
            ui.show_error(f"Error: {e}")
            if os.environ.get("SC_DEBUG"):
                import traceback; traceback.print_exc()


if __name__ == "__main__":
    main()
