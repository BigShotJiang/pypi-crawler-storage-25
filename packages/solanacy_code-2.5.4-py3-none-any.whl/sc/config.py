"""Config management for Solanacy Code."""
from __future__ import annotations
import json, os
from pathlib import Path
from .router import PROVIDERS

CONFIG_DIR = Path.home() / ".solanacy-code"
CONFIG_FILE = CONFIG_DIR / "config.json"
MEMORY_FILE = CONFIG_DIR / "memory.md"
SESSIONS_DIR = CONFIG_DIR / "sessions"
PLUGINS_DIR = CONFIG_DIR / "plugins"
CHECKPOINTS_DIR = CONFIG_DIR / "checkpoints"

DEFAULT_CONFIG = {
    "provider": "anthropic",
    "model": "claude-sonnet-4-6",
    "auto_approve": False,
    "think_mode": False,
    "hybrid_mode": False,
    "keys": {},
    "budget": {"daily_limit": 0.0, "monthly_limit": 0.0, "warn_at": 0.8},
    "hooks": {"PreToolUse": [], "PostToolUse": [], "OnError": [], "OnMessage": []},
    "tool_permissions": {
        "SAFE": ["file_read", "grep", "glob", "ls", "memory_read",
                 "memory_search", "todo_read", "git_status", "git_diff"],
        "MODERATE": ["file_write", "file_edit", "file_delete", "web_fetch",
                     "web_search", "memory_write", "todo_write", "spawn_agent"],
        "DANGEROUS": ["bash", "git_commit", "git_push", "git_reset"],
    },
}

def _ensure_dirs():
    for d in [CONFIG_DIR, SESSIONS_DIR, PLUGINS_DIR, CHECKPOINTS_DIR]:
        d.mkdir(parents=True, exist_ok=True)
    if not MEMORY_FILE.exists():
        MEMORY_FILE.write_text("# Solanacy Code Memory\n\n")

def load_config() -> dict:
    _ensure_dirs()
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if CONFIG_FILE.exists():
        try:
            saved = json.loads(CONFIG_FILE.read_text())
            for k, v in saved.items():
                if isinstance(v, dict) and isinstance(cfg.get(k), dict):
                    cfg[k] = {**cfg[k], **v}
                else:
                    cfg[k] = v
        except Exception:
            pass
    # Auto-load from environment
    for pid, pinfo in PROVIDERS.items():
        env_key = os.environ.get(pinfo["env"])
        if env_key:
            keys = cfg["keys"].setdefault(pid, [])
            if env_key not in keys:
                keys.insert(0, env_key)
    return cfg

def save_config(cfg: dict):
    _ensure_dirs()
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))

def get_next_key(cfg: dict, provider: str) -> str | None:
    keys = cfg["keys"].get(provider, [])
    if not keys: return None
    pool = cfg.setdefault("_key_index", {})
    idx = pool.get(provider, 0) % len(keys)
    pool[provider] = (idx + 1) % len(keys)
    return keys[idx]

def add_key(cfg: dict, provider: str, key: str):
    keys = cfg["keys"].setdefault(provider, [])
    if key not in keys: keys.append(key)

def remove_dead_key(cfg: dict, provider: str, key: str):
    keys = cfg["keys"].get(provider, [])
    if key in keys: keys.remove(key)

def provider_names() -> list[str]:
    return list(PROVIDERS.keys())

def get_provider_info(provider: str) -> dict:
    return PROVIDERS.get(provider, {})

def get_project_context() -> str | None:
    p = Path.cwd()
    for _ in range(5):
        f = p / "SC.md"
        if f.exists(): return f.read_text()
        f2 = p / "CLAUDE.md"
        if f2.exists(): return f2.read_text()
        if p.parent == p: break
        p = p.parent
    return None
