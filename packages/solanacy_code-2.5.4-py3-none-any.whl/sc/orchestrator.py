"""Multi-agent orchestrator — parallel + sequential agent execution."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from queue import Queue
from typing import Callable, Optional

from . import ui
from .agents.base import AGENT_ROLES, select_agent


class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class AgentTask:
    id: str
    agent: str
    prompt: str
    depends_on: list[str] = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    result: str = ""
    error: str = ""
    messages: list[dict] = field(default_factory=list)


class Orchestrator:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.tasks: dict[str, AgentTask] = {}
        self._results: dict[str, str] = {}
        self._lock = threading.Lock()

    def add_task(self, task_id: str, agent: str, prompt: str,
                 depends_on: list[str] = None) -> "Orchestrator":
        self.tasks[task_id] = AgentTask(
            id=task_id,
            agent=agent,
            prompt=prompt,
            depends_on=depends_on or [],
        )
        return self

    def _run_task(self, task: AgentTask) -> None:
        from .agent import run_agent
        task.status = TaskStatus.RUNNING
        ui.show_agent_start(task.agent, task.id, task.prompt)

        # Inject results of dependencies into prompt
        prompt = task.prompt
        for dep_id in task.depends_on:
            dep_result = self._results.get(dep_id, "")
            if dep_result:
                prompt += f"\n\n[Output from {dep_id} agent]:\n{dep_result}"

        try:
            result = run_agent(
                user_input=prompt,
                messages=task.messages,
                cfg=self.cfg,
                agent_role=task.agent,
                auto_approve=True,
                quiet=False,
            )
            task.result = result
            task.status = TaskStatus.DONE
            with self._lock:
                self._results[task.id] = result
            ui.show_agent_done(task.agent, task.id)
        except Exception as e:
            task.error = str(e)
            task.status = TaskStatus.FAILED
            ui.show_agent_error(task.agent, task.id, str(e))

    def _can_run(self, task: AgentTask) -> bool:
        if task.status != TaskStatus.PENDING:
            return False
        return all(
            self.tasks.get(dep, AgentTask("", "", "")).status == TaskStatus.DONE
            for dep in task.depends_on
        )

    def run_all(self, parallel: bool = True) -> dict[str, str]:
        """Run all tasks, respecting dependencies."""
        if parallel:
            return self._run_parallel()
        else:
            return self._run_sequential()

    def _run_parallel(self) -> dict[str, str]:
        """Run tasks in waves — all ready tasks in parallel."""
        max_iterations = 50
        for _ in range(max_iterations):
            ready = [t for t in self.tasks.values() if self._can_run(t)]
            if not ready:
                if all(t.status in (TaskStatus.DONE, TaskStatus.FAILED)
                       for t in self.tasks.values()):
                    break
                time.sleep(0.5)
                continue

            threads = []
            for task in ready:
                t = threading.Thread(target=self._run_task, args=(task,), daemon=True)
                threads.append(t)
                t.start()

            for t in threads:
                t.join()

        return dict(self._results)

    def _run_sequential(self) -> dict[str, str]:
        """Run tasks one by one in dependency order."""
        for task in self.tasks.values():
            if self._can_run(task):
                self._run_task(task)
        return dict(self._results)

    def summarize_results(self) -> str:
        lines = ["## Multi-Agent Results\n"]
        for tid, task in self.tasks.items():
            status_icon = {"done": "✅", "failed": "❌", "running": "⏳", "pending": "⌛"}
            icon = status_icon.get(task.status.value, "?")
            lines.append(f"### {icon} {task.agent.upper()} [{tid}]")
            if task.result:
                lines.append(task.result[:800])
            elif task.error:
                lines.append(f"Error: {task.error}")
            lines.append("")
        return "\n".join(lines)


def auto_orchestrate(user_input: str, cfg: dict) -> str:
    """Auto-decompose a complex task and run multi-agent pipeline."""
    from .agent import run_agent

    # First, use AI to plan the task breakdown
    plan_messages = []
    plan_prompt = f"""Analyze this task and break it down for a multi-agent system.
Available agents: architect, developer, reviewer, researcher, debugger

Task: {user_input}

Respond in this exact JSON format (no markdown):
{{
  "tasks": [
    {{"id": "t1", "agent": "architect", "prompt": "...", "depends_on": []}},
    {{"id": "t2", "agent": "developer", "prompt": "...", "depends_on": ["t1"]}}
  ],
  "parallel_ok": true
}}

Keep it to 3-5 tasks max. Only use agents that are truly needed."""

    try:
        from . import providers as prov
        prov.add_user_message(plan_messages, plan_prompt)
        resp = prov.chat(cfg, plan_messages,
                         system="You are a task planner. Respond only in JSON.")
        import json, re
        text = resp.text
        # Strip markdown if present
        text = re.sub(r"```json|```", "", text).strip()
        plan = json.loads(text)

        orch = Orchestrator(cfg)
        for t in plan["tasks"]:
            orch.add_task(t["id"], t["agent"], t["prompt"], t.get("depends_on", []))

        ui.show_orchestration_plan(plan["tasks"])
        results = orch.run_all(parallel=plan.get("parallel_ok", False))
        return orch.summarize_results()

    except Exception as e:
        # Fallback: just run as developer
        ui.show_info(f"Auto-orchestration planning failed ({e}), running directly...")
        msgs = []
        return run_agent(user_input, msgs, cfg, agent_role="developer")
