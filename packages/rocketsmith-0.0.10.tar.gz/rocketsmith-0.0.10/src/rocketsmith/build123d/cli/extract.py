import typer

from typing_extensions import Annotated
from rich import print as rprint
from rich.table import Table
from rich.console import Console

from wa.cli.options import WorkspaceOption
from wa.cli.utils import get_workspace


def register_build123d_extract(app: typer.Typer):
    @app.command(name="extract")
    def build123d_extract(
        step_filename: Annotated[
            str,
            typer.Argument(
                help="Filename of the STEP file in the workspace parts/ folder."
            ),
        ],
        workspace_option: WorkspaceOption = None,
        density: Annotated[
            float | None,
            typer.Option(
                "--density",
                help="Material density in kg/m³. When provided, mass is calculated from volume × density.",
            ),
        ] = None,
    ) -> None:
        """Extract and display geometric properties from a STEP file."""
        from rocketsmith.build123d.extract import extract_geometry

        workspace = get_workspace(workspace_option)
        step_path = workspace.path / "parts" / step_filename

        if not step_path.exists():
            rprint(f"⚠️  [yellow]File not found: {step_path}[/yellow]")
            raise typer.Exit(1)

        rprint(f"[dim]Analysing [cyan]{step_path.name}[/cyan]...[/dim]")

        try:
            geo = extract_geometry(step_path, material_density_kg_m3=density)
        except Exception as e:
            rprint(f"⚠️  [yellow]Failed to extract geometry: {e}[/yellow]")
            raise typer.Exit(1)

        table = Table(
            title=str(step_path.name), show_header=False, box=None, padding=(0, 2)
        )
        table.add_column("Property", style="dim")
        table.add_column("Value", style="cyan")

        table.add_row(
            "Volume", f"{geo.volume_mm3:,.2f} mm³  ({geo.volume_cm3:.3f} cm³)"
        )
        table.add_row("Surface area", f"{geo.surface_area_mm2:,.2f} mm²")
        table.add_row(
            "Bounding box",
            f"{geo.bounding_box_mm.x_mm:.2f} × {geo.bounding_box_mm.y_mm:.2f} × {geo.bounding_box_mm.z_mm:.2f} mm",
        )
        table.add_row(
            "Centre of mass",
            f"({geo.center_of_mass_mm.x_mm:.3f}, {geo.center_of_mass_mm.y_mm:.3f}, {geo.center_of_mass_mm.z_mm:.3f}) mm",
        )
        if geo.mass_g is not None:
            table.add_row("Mass", f"{geo.mass_g:.2f} g  (at {density:.0f} kg/m³)")

        Console().print(table)

    return build123d_extract
