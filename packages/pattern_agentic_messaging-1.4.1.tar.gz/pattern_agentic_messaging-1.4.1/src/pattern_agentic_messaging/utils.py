import slim_bindings


def parse_name(name_str: str) -> slim_bindings.Name:
    """Parse 'org/namespace/app' string into slim_bindings.Name."""
    return slim_bindings.Name.from_string(name_str)


def format_name(name: slim_bindings.Name) -> str:
    """Convert a slim_bindings.Name back to 'org/namespace/app' string."""
    return "/".join(name.components())
