"""Heuristic DRY / inelegance scan for duplicated Python logic hotspots."""

import ast
import copy
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

from .._lib import repo_root
from .._registry import Result, register_check

_CHECK_ID = "dry_inelegance_hotspots"
_SKIP_PARTS = {
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "node_modules",
    "build",
    "dist",
    "archive",
    "site-packages",
    "medicafe.egg-info",
}
_TARGET_TOP_LEVEL = {
    "MediCafe",
    "MediBot",
    "MediLink",
    "xp_client",
    "cloud",
    "scripts",
    "tools",
}
_MIN_BODY_LINES = 8
_MIN_BODY_NODES = 3
_MAX_DETAILS = 12


@dataclass
class FunctionRecord:
    rel_path: str
    qualname: str
    lineno: int
    body_lines: int
    fingerprint: str


class _NormalizeLogic(ast.NodeTransformer):
    """Normalize identifiers/literals enough to expose copy-paste structure."""

    def visit_Name(self, node):
        return ast.copy_location(ast.Name(id="VAR", ctx=node.ctx), node)

    def visit_arg(self, node):
        return ast.copy_location(ast.arg(arg="ARG", annotation=None, type_comment=None), node)

    def visit_Attribute(self, node):
        node = self.generic_visit(node)
        node.attr = "ATTR"
        return node

    def visit_keyword(self, node):
        node = self.generic_visit(node)
        node.arg = "KW" if node.arg is not None else None
        return node

    def visit_Constant(self, node):
        value = node.value
        if isinstance(value, bool) or value is None:
            return node
        if isinstance(value, str):
            return ast.copy_location(ast.Constant(value="STR"), node)
        if isinstance(value, bytes):
            return ast.copy_location(ast.Constant(value=b"BYTES"), node)
        if isinstance(value, (int, float, complex)):
            return ast.copy_location(ast.Constant(value=0), node)
        return ast.copy_location(ast.Constant(value="CONST"), node)


class _FunctionCollector(ast.NodeVisitor):
    def __init__(self):
        self.stack: List[str] = []
        self.records: List[Tuple[str, ast.AST]] = []

    def visit_ClassDef(self, node):
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()

    def visit_FunctionDef(self, node):
        self._push_function(node)

    def visit_AsyncFunctionDef(self, node):
        self._push_function(node)

    def _push_function(self, node):
        self.stack.append(node.name)
        self.records.append((".".join(self.stack), node))
        self.generic_visit(node)
        self.stack.pop()


def _iter_python_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*.py"):
        rel = path.relative_to(root)
        if any(part in _SKIP_PARTS for part in rel.parts):
            continue
        if not rel.parts or rel.parts[0] not in _TARGET_TOP_LEVEL:
            continue
        yield path


def _meaningful_body_lines(source_lines: Sequence[str], node: ast.AST) -> int:
    start = getattr(node, "lineno", 1) - 1
    end = getattr(node, "end_lineno", getattr(node, "lineno", 1))
    count = 0
    for raw in source_lines[start:end]:
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        count += 1
    return count


def _body_nodes(func_node):
    body = list(func_node.body)
    if body:
        first = body[0]
        if isinstance(first, ast.Expr) and isinstance(getattr(first, "value", None), ast.Constant):
            if isinstance(first.value.value, str):
                body = body[1:]
    return body


def _fingerprint_for(func_node) -> str:
    body = _body_nodes(func_node)
    normalized = []
    for stmt in body:
        cloned = copy.deepcopy(stmt)
        normalized_stmt = _NormalizeLogic().visit(cloned)
        ast.fix_missing_locations(normalized_stmt)
        normalized.append(ast.dump(normalized_stmt, include_attributes=False))
    return "\n".join(normalized)


def _format_detail(index: int, records: Sequence[FunctionRecord]) -> str:
    sample = sorted(records, key=lambda item: (item.rel_path, item.lineno, item.qualname))
    approx_lines = int(round(sum(r.body_lines for r in sample) / float(len(sample))))
    shown = []
    for rec in sample[:4]:
        shown.append("{0}:{1} {2}".format(rec.rel_path, rec.lineno, rec.qualname))
    more = len(sample) - len(shown)
    suffix = ""
    if more > 0:
        suffix = " | +{0} more".format(more)
    return "cluster {0}: {1} function(s), ~{2} body lines each, examples: {3}{4}".format(
        index,
        len(sample),
        approx_lines,
        " | ".join(shown),
        suffix,
    )


@register_check(
    _CHECK_ID,
    "weekly",
    "Heuristic scan for duplicated Python logic hotspots that may warrant DRY cleanup",
    blocking=False,
)
def run() -> Result:
    root = repo_root()
    groups: Dict[str, List[FunctionRecord]] = defaultdict(list)
    parse_failures: List[str] = []
    scanned = 0

    for path in _iter_python_files(root):
        rel_path = str(path.relative_to(root))
        try:
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            tree = ast.parse(text, filename=rel_path)
        except SyntaxError as exc:
            parse_failures.append("{0}:{1} syntax error during scan: {2}".format(rel_path, exc.lineno or 1, exc.msg))
            continue
        except OSError as exc:
            parse_failures.append("{0}: read failure during scan: {1}".format(rel_path, exc))
            continue

        scanned += 1
        source_lines = text.splitlines()
        collector = _FunctionCollector()
        collector.visit(tree)
        for qualname, func_node in collector.records:
            body = _body_nodes(func_node)
            if len(body) < _MIN_BODY_NODES:
                continue
            body_lines = _meaningful_body_lines(source_lines, func_node)
            if body_lines < _MIN_BODY_LINES:
                continue
            fingerprint = _fingerprint_for(func_node)
            if not fingerprint:
                continue
            groups[fingerprint].append(
                FunctionRecord(
                    rel_path=rel_path,
                    qualname=qualname,
                    lineno=getattr(func_node, "lineno", 1),
                    body_lines=body_lines,
                    fingerprint=fingerprint,
                )
            )

    clusters = [records for records in groups.values() if len(records) > 1]
    clusters.sort(key=lambda recs: ((len(recs) - 1) * sum(r.body_lines for r in recs), len(recs)), reverse=True)

    if not clusters and not parse_failures:
        return Result(
            check_id=_CHECK_ID,
            status="ok",
            summary="No duplicated Python logic hotspots found above heuristic thresholds",
            details=["scanned_python_files={0}".format(scanned)],
        )

    candidate_lines = sum(sum(r.body_lines for r in recs) for recs in clusters)
    duplicate_functions = sum(len(recs) for recs in clusters)
    details = [_format_detail(i + 1, recs) for i, recs in enumerate(clusters[:_MAX_DETAILS])]
    details.append(
        "note: this scan normalizes local identifiers, attributes, and most literals; review intent before refactoring across runtime boundaries"
    )
    if parse_failures:
        details.extend(parse_failures[:4])

    status = "warn" if clusters else "ok"
    summary = "{0} DRY hotspot cluster(s) across {1} function(s), ~{2} duplicated body lines".format(
        len(clusters),
        duplicate_functions,
        candidate_lines,
    )
    return Result(
        check_id=_CHECK_ID,
        status=status,
        summary=summary,
        details=details,
    )
