"""Report release reproducibility and dependency lockfile gaps."""

import re
from typing import List

from .._lib import read_text, repo_root
from .._registry import Result, register_check

_LOCKFILE_NAMES = {
    "requirements.lock",
    "requirements.lock.txt",
    "uv.lock",
    "poetry.lock",
    "Pipfile.lock",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
}


def _repo_lockfiles() -> List[str]:
    root = repo_root()
    skip_parts = {".git", ".venv", "venv", "node_modules", "__pycache__", "build", "dist"}
    found: List[str] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if set(path.parts) & skip_parts:
            continue
        if path.name in _LOCKFILE_NAMES:
            found.append(path.relative_to(root).as_posix())
    return sorted(found)


def _requirements_have_hashes(relpaths: List[str]) -> bool:
    for relpath in relpaths:
        try:
            text = read_text(relpath)
        except OSError:
            continue
        if "--hash=sha256:" in text:
            return True
    return False


def _docker_base_digest_gaps() -> List[str]:
    root = repo_root()
    details: List[str] = []
    for path in sorted(root.rglob("Dockerfile")):
        parts = set(path.parts)
        if {".git", "__pycache__", "build", "dist"} & parts:
            continue
        rel = path.relative_to(root).as_posix()
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line_no, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped.upper().startswith("FROM "):
                continue
            image = stripped.split(None, 1)[1].split()[0]
            if "@sha256:" not in image:
                details.append("{0}:{1}: Docker base image is not digest-pinned: {2}".format(rel, line_no, image))
    return details


def _release_pip_install_gaps() -> List[str]:
    details: List[str] = []
    rel = ".github/workflows/release-pypi.yml"
    try:
        text = read_text(rel)
    except OSError:
        return details
    install_re = re.compile(r"python\s+-m\s+pip\s+install\b(.+)$")
    for line_no, line in enumerate(text.splitlines(), 1):
        match = install_re.search(line.strip())
        if not match:
            continue
        args = match.group(1).strip()
        if "-r " in args or "--require-hashes" in args:
            continue
        packages = [
            token
            for token in args.split()
            if token
            and not token.startswith("-")
            and "==" not in token
            and "@" not in token
        ]
        if packages:
            details.append(
                "{0}:{1}: release pip install includes unpinned package(s): {2}".format(
                    rel, line_no, ", ".join(packages)
                )
            )
    return details


@register_check(
    "supply_chain_reproducibility",
    "monthly",
    "Dependency lockfile, hash pin, Docker digest, and release build-tool reproducibility hints",
    blocking=False,
)
def run() -> Result:
    details: List[str] = []
    lockfiles = _repo_lockfiles()
    reqs = [
        "requirements.txt",
        "cloud/orchestrator/requirements.txt",
        "tools/requirements.txt",
    ]
    if not lockfiles:
        details.append("No repository lockfiles found for Python or package-manager dependencies.")
    if not _requirements_have_hashes(reqs):
        details.append("No --hash=sha256 entries found in tracked requirements files.")
    details.extend(_docker_base_digest_gaps())
    details.extend(_release_pip_install_gaps())
    if details:
        return Result(
            check_id="supply_chain_reproducibility",
            status="warn",
            summary="{0} reproducibility gap(s)".format(len(details)),
            details=details,
        )
    return Result(
        check_id="supply_chain_reproducibility",
        status="ok",
        summary="No obvious lockfile, hash-pin, Docker digest, or release build-tool gaps",
        details=[],
    )
