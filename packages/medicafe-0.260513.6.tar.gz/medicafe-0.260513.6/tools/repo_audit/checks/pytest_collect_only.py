"""pytest --collect-only with configured ignores; fails on collection errors."""

from .._lib import python_exe, repo_root, run_subprocess
from .._registry import Result, register_check

_IGNORES = []


@register_check(
    "pytest_collect_only",
    "fast",
    "pytest --collect-only for tests/",
)
def run() -> Result:
    base_argv = [
        python_exe(),
        "-m",
        "pytest",
        "tests/",
        "--collect-only",
        "-q",
    ]
    for ign in _IGNORES:
        base_argv.extend(["--ignore", ign])

    argv = list(base_argv) + ["--timeout", "30"]
    code, out, err = run_subprocess(argv, cwd=repo_root(), timeout=180)
    blob = (out or "") + "\n" + (err or "")
    if "unrecognized arguments: --timeout" in blob:
        code, out, err = run_subprocess(base_argv, cwd=repo_root(), timeout=180)
        blob = (out or "") + "\n" + (err or "")
    lower = blob.lower()
    if code != 0 or "error during collection" in lower or "errors during collection" in lower:
        lines = [ln for ln in blob.splitlines() if ln.strip()][-40:]
        return Result(
            check_id="pytest_collect_only",
            status="fail",
            summary="pytest collection failed (exit {0})".format(code),
            details=lines or [blob[:2000]],
        )
    return Result(
        check_id="pytest_collect_only",
        status="ok",
        summary="pytest --collect-only succeeded",
        details=[],
    )
