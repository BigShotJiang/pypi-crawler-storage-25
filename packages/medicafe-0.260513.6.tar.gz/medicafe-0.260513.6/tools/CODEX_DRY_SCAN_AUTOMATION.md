# Codex DRY Scan Automation Seed

This is a starting prompt/workflow for a recurring Codex automation focused on DRY and code elegance in a large repo.

## Goal

Find concrete duplication or inelegant structure that is worth cleanup, without generating generic style advice.

## Primary Command

Run from repo root:

```powershell
py -3.11 tools/repo_audit.py --check dry_inelegance_hotspots --format text
```

For machine-readable output:

```powershell
py -3.11 tools/repo_audit.py --check dry_inelegance_hotspots --format json
```

## Suggested Automation Prompt

Use the audit result as the first filter, then inspect the cited files before making recommendations.

Suggested prompt body:

```text
Scan the repo for DRY / inelegance hotspots.

1. Run `py -3.11 tools/repo_audit.py --check dry_inelegance_hotspots --format json`.
2. Inspect the top candidate clusters in code before concluding they are real duplication.
3. Ignore intentional duplication across runtime boundaries unless the same abstraction can safely serve both tracks.
4. Return only grounded findings with file paths and a short note on the likely abstraction or cleanup path.
5. Separate findings into:
   - worth refactoring now
   - acceptable duplication
   - repeated pattern that should become a Codex skill or checklist rule
6. Prefer repo-specific patterns over generic cleanliness advice.
```

## What To Look For During Review

- Similar state propagation code copied across Cloud Readiness surfaces.
- Repeated path-resolution or artifact-discovery fallback ladders.
- Repeated queue/lock/worker lifecycle logic.
- Repeated XP-safe compatibility shims that should be centralized instead of cloned.
- Repeated test setup scaffolding that can move to helpers without obscuring intent.

## Guardrails

- Do not propose abstractions that cross the XP/local and cloud-only runtime boundary without checking compatibility constraints first.
- Do not collapse duplication that exists to preserve operator clarity or evidence-contract stability.
- Treat the audit output as candidate hotspots, not as proof.

## Intended Evolution

If the same categories keep recurring, promote them into a dedicated Codex skill or a stricter review checklist. The likely first skill candidates are:

- state/lineage contract refactoring
- path-resolution normalization
- queue/state-machine cleanup review
- XP-safe helper extraction

Current documentation split:

- Open future cleanup belongs in [`docs/FUTURE_AGENT_BACKLOG.md`](../docs/FUTURE_AGENT_BACKLOG.md), especially repeated script-local unified-model test scaffolding that is not yet worth extracting.
- The recurring-review guardrail belongs in [`docs/PR_REVIEW_CHECKLIST.md`](../docs/PR_REVIEW_CHECKLIST.md).
- A dedicated Codex skill is optional future work and should be created only if repeated DRY scans show the checklist is no longer enough.
