# preflight.py
"""
Lightweight local preflight check for XP/local workflows.
Catches common environment and config issues before runtime.
Read-only; no auto-fix. Python 3.4.4 compatible.
"""
from __future__ import print_function

import os
import sys
import time
import json
import platform

RAW_FILE_EXCEPTION_LANE = {
    'module': 'MediCafe.preflight',
    'mode': 'read_only',
    'allowed_targets': ('config.json', 'crosswalk.json', 'config.local.json', 'crosswalk.state.json'),
}


# Import core_utils for path defaults and import helpers
try:
    from MediCafe import core_utils
except ImportError:
    core_utils = None

try:
    from MediCafe import json_sidecar
except ImportError:
    json_sidecar = None


def _sidecar_paths(config_path, crosswalk_path):
    if json_sidecar is not None:
        try:
            return json_sidecar.sidecar_paths_from_baseline(config_path, crosswalk_path)
        except Exception:
            pass
    cfg_abs = os.path.abspath(config_path) if config_path else ''
    cw_abs = os.path.abspath(crosswalk_path) if crosswalk_path else ''
    return {
        'config_local_path': os.path.join(os.path.dirname(cfg_abs), 'config.local.json') if cfg_abs else '',
        'crosswalk_state_path': os.path.join(os.path.dirname(cw_abs), 'crosswalk.state.json') if cw_abs else '',
    }


def _read_json_object(path):
    if not path:
        return None, 'path not provided'
    try:
        with open(path, 'r') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None, 'top-level JSON value is not an object'
        return data, ''
    except Exception as exc:
        return None, str(exc)


def _deep_merge_effective(base, overlay):
    if not isinstance(base, dict):
        base = {}
    if not isinstance(overlay, dict):
        return dict(base)
    merged = dict(base)
    for key, value in overlay.items():
        if key == '__sidecar__':
            continue
        if isinstance(value, dict) and value.get('__tombstone__') is True:
            if key in merged:
                del merged[key]
            continue
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge_effective(merged.get(key), value)
        else:
            merged[key] = value
    return merged


def _load_effective_config_snapshot(context):
    config_path, crosswalk_path, _project_dir = _resolve_paths(context)
    config, config_err = _read_json_object(config_path)
    crosswalk, crosswalk_err = _read_json_object(crosswalk_path)
    side_paths = _sidecar_paths(config_path, crosswalk_path)
    meta = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'config_error': config_err,
        'crosswalk_error': crosswalk_err,
        'sidecar_paths': side_paths,
        'config_local': {'status': 'missing', 'exists': False, 'message': ''},
        'crosswalk_state': {'status': 'missing', 'exists': False, 'message': ''},
    }
    if config is None:
        return {}, {}, meta
    if crosswalk is None:
        crosswalk = {}
    if json_sidecar is not None:
        try:
            effective_config, effective_crosswalk, sidecar_diag = json_sidecar.build_effective_config_and_crosswalk(
                config,
                crosswalk,
                config_path,
                crosswalk_path,
            )
            if isinstance(sidecar_diag, dict):
                meta['config_local'] = sidecar_diag.get('config_local') or meta['config_local']
                meta['crosswalk_state'] = sidecar_diag.get('crosswalk_state') or meta['crosswalk_state']
            return (
                effective_config if isinstance(effective_config, dict) else {},
                effective_crosswalk if isinstance(effective_crosswalk, dict) else {},
                meta,
            )
        except Exception as exc:
            meta['sidecar_compose_error'] = str(exc)
    config_local, cfg_side_err = _read_json_object(side_paths.get('config_local_path', ''))
    crosswalk_state, cw_side_err = _read_json_object(side_paths.get('crosswalk_state_path', ''))
    if config_local is not None:
        meta['config_local'] = {'status': 'loaded', 'exists': True, 'message': ''}
    elif os.path.exists(side_paths.get('config_local_path', '')):
        meta['config_local'] = {'status': 'invalid', 'exists': True, 'message': cfg_side_err}
    if crosswalk_state is not None:
        meta['crosswalk_state'] = {'status': 'loaded', 'exists': True, 'message': ''}
    elif os.path.exists(side_paths.get('crosswalk_state_path', '')):
        meta['crosswalk_state'] = {'status': 'invalid', 'exists': True, 'message': cw_side_err}
    return _deep_merge_effective(config, config_local or {}), _deep_merge_effective(crosswalk, crosswalk_state or {}), meta


def _medi_config(config):
    if not isinstance(config, dict):
        return {}
    medi = config.get('MediLink_Config')
    return medi if isinstance(medi, dict) else {}


def _critical_config_state_sources(raw_config, effective_config):
    raw_medi = _medi_config(raw_config)
    eff_medi = _medi_config(effective_config)
    required_fields = [
        ('local_storage_path', raw_medi.get('local_storage_path'), eff_medi.get('local_storage_path')),
    ]
    optional_fields = [
        ('CSV_FILE_PATH', raw_config.get('CSV_FILE_PATH'), effective_config.get('CSV_FILE_PATH')),
    ]
    sidecar_only = []
    missing = []
    for name, raw_value, eff_value in required_fields:
        raw_present = bool(str(raw_value or '').strip())
        eff_present = bool(str(eff_value or '').strip())
        if (not raw_present) and eff_present:
            sidecar_only.append(name)
        elif not eff_present:
            missing.append(name)
    for name, raw_value, eff_value in optional_fields:
        raw_present = bool(str(raw_value or '').strip())
        eff_present = bool(str(eff_value or '').strip())
        if (not raw_present) and eff_present:
            sidecar_only.append(name)
    return sidecar_only, missing


def _check_runtime(context, previous_results):
    """Validate Python interpreter version."""
    v = sys.version_info
    if v < (3, 4):
        return {
            'id': 'runtime',
            'status': 'FAIL',
            'message': 'Python 3.4+ required',
            'hint': 'Upgrade to Python 3.4.4 or later',
            'details': '',
        }
    if v < (3, 4, 4):
        return {
            'id': 'runtime',
            'status': 'WARN',
            'message': 'Python {0}.{1}.{2} below 3.4.4'.format(v[0], v[1], v[2] if len(v) > 2 else 0),
            'hint': 'Consider upgrading for XP compatibility',
            'details': '',
        }
    return {
        'id': 'runtime',
        'status': 'PASS',
        'message': 'Python {0}.{1}.{2} OK'.format(v[0], v[1], v[2] if len(v) > 2 else 0),
        'hint': '',
        'details': '',
    }


def _resolve_paths(context):
    """Resolve config/crosswalk paths. Uses context if provided, else env/core_utils."""
    project_dir = core_utils.project_dir if core_utils else os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    if context:
        config_path = context.get('config_path', '')
        crosswalk_path = context.get('crosswalk_path', '')
        if config_path and crosswalk_path:
            return config_path, crosswalk_path, project_dir
    env_config = os.environ.get('MEDICAFE_CONFIG_FILE', '').strip()
    if env_config:
        config_path = os.path.abspath(env_config)
        env_crosswalk = os.environ.get('MEDICAFE_CROSSWALK_FILE', '').strip()
        crosswalk_path = os.path.abspath(env_crosswalk) if env_crosswalk else os.path.join(os.path.dirname(config_path), 'crosswalk.json')
        return config_path, crosswalk_path, project_dir
    if platform.system() == 'Windows' and getattr(platform, 'release', lambda: '')() == 'XP':
        config_path = r'F:\Medibot\json\config.json'
        crosswalk_path = r'F:\Medibot\json\crosswalk.json'
        return config_path, crosswalk_path, project_dir
    if core_utils:
        config_path = core_utils.DEFAULT_CONFIG_PATH
        crosswalk_path = core_utils.DEFAULT_CROSSWALK_PATH
    else:
        config_path = os.path.join(project_dir, 'json', 'config.json')
        crosswalk_path = os.path.join(project_dir, 'json', 'crosswalk.json')
    if not os.path.exists(config_path):
        current_dir = os.getcwd()
        config_path = os.path.join(current_dir, 'json', 'config.json')
        crosswalk_path = os.path.join(current_dir, 'json', 'crosswalk.json')
    return config_path, crosswalk_path, project_dir



def _record_read_diagnostic(path, artifact, phase, exc=None, extra=None):
    try:
        from MediCafe.json_io import record_json_io_read_failure

        record_json_io_read_failure(path, artifact, 'preflight', phase, exc=exc, extra=extra)
    except Exception:
        pass

def _check_config_files(context, previous_results):
    """Check config.json and crosswalk.json exist and parse. Do NOT use load_configuration()."""
    config_path, crosswalk_path, _ = _resolve_paths(context)
    if not os.path.exists(config_path):
        _record_read_diagnostic(config_path, 'config', 'read_missing', extra={'check_id': 'config_files'})
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'config.json missing',
            'hint': 'Create json/config.json from template',
            'details': config_path,
        }
    if not os.path.exists(crosswalk_path):
        _record_read_diagnostic(crosswalk_path, 'crosswalk', 'read_missing', extra={'check_id': 'config_files'})
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'crosswalk.json missing',
            'hint': 'Create json/crosswalk.json from template',
            'details': crosswalk_path,
        }
    try:
        with open(config_path, 'r') as f:
            json.load(f)
    except (ValueError, TypeError) as e:
        _record_read_diagnostic(config_path, 'config', 'json_decode_failed', exc=e, extra={'check_id': 'config_files'})
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'config.json invalid JSON',
            'hint': 'Fix JSON syntax',
            'details': str(e),
        }
    except OSError as e:
        _record_read_diagnostic(config_path, 'config', 'read_failed', exc=e, extra={'check_id': 'config_files'})
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'config.json not readable',
            'hint': 'Check file permissions and path',
            'details': str(e),
        }
    try:
        with open(crosswalk_path, 'r') as f:
            json.load(f)
    except (ValueError, TypeError) as e:
        _record_read_diagnostic(crosswalk_path, 'crosswalk', 'json_decode_failed', exc=e, extra={'check_id': 'config_files'})
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'crosswalk.json invalid JSON',
            'hint': 'Fix JSON syntax',
            'details': str(e),
        }
    except OSError as e:
        _record_read_diagnostic(crosswalk_path, 'crosswalk', 'read_failed', exc=e, extra={'check_id': 'config_files'})
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'crosswalk.json not readable',
            'hint': 'Check file permissions and path',
            'details': str(e),
        }
    return {
        'id': 'config_files',
        'status': 'PASS',
        'message': 'config.json and crosswalk.json present and parseable',
        'hint': '',
        'details': '',
    }


def _check_config_contract(context, previous_results):
    """Validate critical config keys against the effective sidecar-composed config."""
    for r in previous_results:
        if r.get('id') == 'config_files' and r.get('status') == 'FAIL':
            return {
                'id': 'config_contract',
                'status': 'WARN',
                'message': 'Skipped (config load failed)',
                'hint': '',
                'details': '',
            }
    config_path, crosswalk_path, project_dir = _resolve_paths(context)
    if not os.path.exists(config_path):
        _record_read_diagnostic(config_path, 'config', 'read_missing', extra={'check_id': 'config_files'})
        return {
            'id': 'config_contract',
            'status': 'WARN',
            'message': 'Skipped (config load failed)',
            'hint': '',
            'details': '',
        }
    raw_config, raw_error = _read_json_object(config_path)
    if raw_config is None:
        return {
            'id': 'config_contract',
            'status': 'WARN',
            'message': 'Skipped (config load failed)',
            'hint': '',
            'details': raw_error,
        }
    effective_config, _effective_crosswalk, effective_meta = _load_effective_config_snapshot(context)
    sidecar_error = str(effective_meta.get('sidecar_compose_error') or '')
    if sidecar_error:
        return {
            'id': 'config_contract',
            'status': 'FAIL',
            'message': 'Effective config composition failed',
            'hint': 'Check config.local.json and crosswalk.state.json syntax/schema before running local workflows',
            'details': sidecar_error,
        }
    if 'MediLink_Config' not in effective_config:
        return {
            'id': 'config_contract',
            'status': 'FAIL',
            'message': 'Effective MediLink_Config missing',
            'hint': 'Add MediLink_Config to config.json or config.local.json',
            'details': '',
        }
    medi = _medi_config(effective_config)
    local_storage = medi.get('local_storage_path', '')
    if not local_storage or not str(local_storage).strip():
        return {
            'id': 'config_contract',
            'status': 'FAIL',
            'message': 'Effective local_storage_path not set',
            'hint': 'Set MediLink_Config.local_storage_path in config.local.json or config.json; sidecar migration may have removed it from baseline without preserving it',
            'details': 'config_path={0}; config_local={1}'.format(
                config_path,
                (effective_meta.get('sidecar_paths') or {}).get('config_local_path', ''),
            ),
        }
    sidecar_only, _missing = _critical_config_state_sources(raw_config, effective_config)
    if sidecar_only:
        return {
            'id': 'config_contract',
            'status': 'PASS',
            'message': 'Effective config contract OK (sidecar-composed)',
            'hint': '',
            'details': 'sidecar_owned_fields={0}'.format(','.join(sidecar_only)),
        }
    return {
        'id': 'config_contract',
        'status': 'PASS',
        'message': 'Config contract OK',
        'hint': '',
        'details': '',
    }


def _check_sidecar_boundary(context, previous_results):
    """Classify baseline/sidecar workflow boundary so operators see migration state."""
    for r in previous_results:
        if r.get('id') == 'config_files' and r.get('status') == 'FAIL':
            return {
                'id': 'sidecar_boundary',
                'status': 'WARN',
                'message': 'Skipped (config/crosswalk not loadable)',
                'hint': '',
                'details': '',
            }
    config_path, _crosswalk_path, _project_dir = _resolve_paths(context)
    raw_config, raw_error = _read_json_object(config_path)
    if raw_config is None:
        return {
            'id': 'sidecar_boundary',
            'status': 'WARN',
            'message': 'Skipped (config load failed)',
            'hint': '',
            'details': raw_error,
        }
    effective_config, _effective_crosswalk, meta = _load_effective_config_snapshot(context)
    if meta.get('sidecar_compose_error'):
        return {
            'id': 'sidecar_boundary',
            'status': 'FAIL',
            'message': 'Sidecar composition failed',
            'hint': 'Fix sidecar syntax/schema or temporarily disable sidecar migration before running local workflows',
            'details': str(meta.get('sidecar_compose_error') or ''),
        }
    bad_sidecars = []
    for key in ('config_local', 'crosswalk_state'):
        diag = meta.get(key) if isinstance(meta.get(key), dict) else {}
        status = str(diag.get('status') or '')
        if status and status not in ('missing', 'loaded'):
            bad_sidecars.append('{0}:{1}'.format(key, status))
    if bad_sidecars:
        return {
            'id': 'sidecar_boundary',
            'status': 'FAIL',
            'message': 'Sidecar file present but not usable',
            'hint': 'Repair or remove the invalid sidecar before relying on local workflows',
            'details': '; '.join(bad_sidecars),
        }
    sidecar_only, missing = _critical_config_state_sources(raw_config, effective_config)
    if missing:
        return {
            'id': 'sidecar_boundary',
            'status': 'FAIL',
            'message': 'Critical config values missing from effective config',
            'hint': 'Restore missing values in config.local.json or config.json; baseline-only checks are insufficient here',
            'details': 'missing_effective_fields={0}'.format(','.join(missing)),
        }
    if sidecar_only:
        return {
            'id': 'sidecar_boundary',
            'status': 'WARN',
            'message': 'Sidecar migration boundary active',
            'hint': 'Critical runtime values are sidecar-owned; use sidecar-aware loaders and treat raw config.json as incomplete by design',
            'details': 'sidecar_only_fields={0}; config_local={1}'.format(
                ','.join(sidecar_only),
                (meta.get('sidecar_paths') or {}).get('config_local_path', ''),
            ),
        }
    return {
        'id': 'sidecar_boundary',
        'status': 'PASS',
        'message': 'Sidecar boundary OK',
        'hint': '',
        'details': '',
    }


def _check_path_access(context, previous_results):
    """Validate read/write access for required paths."""
    config_path, crosswalk_path, project_dir = _resolve_paths(context)
    config_dir = os.path.dirname(config_path)
    if context:
        local_storage = context.get('local_storage_path', '')
        source_folder = context.get('source_folder', '')
        target_folder = context.get('target_folder', '')
    else:
        local_storage = os.path.join(project_dir, 'MediBot', 'DOWNLOADS')
        source_folder = local_storage
        target_folder = os.path.join(local_storage, 'CSV')
    if not local_storage:
        try:
            effective_config, _effective_crosswalk, _meta = _load_effective_config_snapshot(context)
            medi = _medi_config(effective_config)
            if medi.get('local_storage_path'):
                local_storage = medi.get('local_storage_path')
        except Exception:
            pass
    if not source_folder:
        source_folder = local_storage
    if not target_folder:
        target_folder = os.path.join(local_storage, 'CSV') if local_storage else ''
    if not os.path.isabs(local_storage):
        local_storage = os.path.join(project_dir, local_storage)
    if not os.path.isabs(source_folder):
        source_folder = os.path.join(project_dir, source_folder)
    if not os.path.isabs(target_folder):
        target_folder = os.path.join(project_dir, target_folder)
    if not os.path.exists(config_dir):
        return {
            'id': 'path_access',
            'status': 'FAIL',
            'message': 'Config directory missing',
            'hint': 'Create json/ directory',
            'details': config_dir,
        }
    if not os.access(config_dir, os.R_OK):
        return {
            'id': 'path_access',
            'status': 'FAIL',
            'message': 'Config directory not readable',
            'hint': 'Check permissions on json/',
            'details': config_dir,
        }
    if os.path.exists(local_storage) and not os.access(local_storage, os.W_OK):
        return {
            'id': 'path_access',
            'status': 'FAIL',
            'message': 'local_storage_path not writable',
            'hint': 'Check permissions on local_storage_path',
            'details': local_storage,
        }
    if not os.path.exists(local_storage):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'local_storage_path does not exist',
            'hint': 'Directory will be created on first run',
            'details': local_storage,
        }
    if not os.path.exists(source_folder):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'source_folder does not exist',
            'hint': 'Create directory or update config',
            'details': source_folder,
        }
    if not os.path.exists(target_folder):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'target_folder does not exist',
            'hint': 'Create directory or update config',
            'details': target_folder,
        }
    if not os.access(source_folder, os.R_OK):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'source_folder not readable',
            'hint': 'Check permissions',
            'details': source_folder,
        }
    if not os.access(target_folder, os.W_OK):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'target_folder not writable',
            'hint': 'Check permissions',
            'details': target_folder,
        }
    return {
        'id': 'path_access',
        'status': 'PASS',
        'message': 'Required paths accessible',
        'hint': '',
        'details': '',
    }


def _check_json_io(context, previous_results):
    """Non-destructive JSON/file IO probes (r+ opens, temp+rename in key dirs)."""
    for r in previous_results:
        if r.get('id') == 'config_files' and r.get('status') == 'FAIL':
            return {
                'id': 'json_io',
                'status': 'WARN',
                'message': 'Skipped (config/crosswalk not loadable)',
                'hint': '',
                'details': '',
            }
    try:
        from MediCafe.json_io import collect_json_io_preflight_failures
    except Exception as exc:
        return {
            'id': 'json_io',
            'status': 'WARN',
            'message': 'JSON IO probe module unavailable',
            'hint': str(exc),
            'details': '',
        }
    failures = collect_json_io_preflight_failures(context or {})
    if failures:
        return {
            'id': 'json_io',
            'status': 'FAIL',
            'message': 'JSON IO probe failed ({0} issue(s))'.format(len(failures)),
            'hint': (
                'Check read-only attributes, directory permissions, stale .lock files beside JSON, '
                'and locks from editors/antivirus/sync. See JSON_IO_EVENT and JSON_IO_DIAGNOSTIC lines in the run log for phases/path diagnostics.'
            ),
            'details': '; '.join(failures[:12]),
        }
    return {
        'id': 'json_io',
        'status': 'PASS',
        'message': 'JSON IO probes OK (config/crosswalk r+, key dirs writable)',
        'hint': '',
        'details': '',
    }


def _check_imports(context, previous_results):
    """Verify critical MediLink_DataMgmt import."""
    if not core_utils:
        return {
            'id': 'imports',
            'status': 'FAIL',
            'message': 'core_utils import failed',
            'hint': 'Ensure MediCafe package is on PYTHONPATH',
            'details': '',
        }
    mod = core_utils.import_medilink_module('MediLink_DataMgmt')
    if mod is None:
        return {
            'id': 'imports',
            'status': 'FAIL',
            'message': 'MediLink_DataMgmt import failed',
            'hint': 'Ensure MediLink package is on PYTHONPATH',
            'details': '',
        }
    ok = core_utils.require_functions(mod, ['read_general_fixed_width_data', 'read_fixed_width_data', 'parse_fixed_width_data'])
    if not ok:
        return {
            'id': 'imports',
            'status': 'WARN',
            'message': 'MediLink_DataMgmt missing functions',
            'hint': 'Update MediLink_DataMgmt module',
            'details': '',
        }
    return {
        'id': 'imports',
        'status': 'PASS',
        'message': 'MediLink_DataMgmt OK',
        'hint': '',
        'details': '',
    }


CHECKS = [
    ('runtime', _check_runtime),
    ('config_files', _check_config_files),
    ('sidecar_boundary', _check_sidecar_boundary),
    ('config_contract', _check_config_contract),
    ('json_io', _check_json_io),
    ('path_access', _check_path_access),
    ('imports', _check_imports),
]


def run_preflight(context=None):
    """
    Run all checks. Returns (exit_code, report).
    context: optional dict with config_path, crosswalk_path, local_storage_path,
             source_folder, target_folder to override path resolution.
    """
    started = time.time()
    results = []
    for cid, check_fn in CHECKS:
        r = check_fn(context or {}, results)
        r['id'] = cid
        results.append(r)
    finished = time.time()
    counts = {'pass': 0, 'warn': 0, 'fail': 0}
    for r in results:
        s = r.get('status', 'PASS')
        if s == 'PASS':
            counts['pass'] += 1
        elif s in ('WARN', 'SKIP'):
            counts['warn'] += 1
        else:
            counts['fail'] += 1
    report = {
        'started_at': started,
        'finished_at': finished,
        'duration_ms': (finished - started) * 1000,
        'results': results,
        'counts': counts,
    }
    exit_code = 0 if counts['fail'] == 0 else 1
    return exit_code, report


def should_run_preflight(session_state, inputs):
    """
    Launcher decision. Returns True if preflight should run.
    """
    if session_state.get('first_local_workflow', True):
        return True
    if session_state.get('last_preflight_ok') is False:
        return True
    current = preflight_artifact_mtimes(inputs)
    for key in ('config_mtime', 'crosswalk_mtime', 'config_local_mtime', 'crosswalk_state_mtime'):
        if session_state.get(key) != current.get(key):
            return True
    return False


def preflight_artifact_mtimes(inputs):
    cfg_path = inputs.get('config_path', '') if isinstance(inputs, dict) else ''
    cw_path = inputs.get('crosswalk_path', '') if isinstance(inputs, dict) else ''
    side_paths = _sidecar_paths(cfg_path, cw_path)
    paths = {
        'config_mtime': cfg_path,
        'crosswalk_mtime': cw_path,
        'config_local_mtime': side_paths.get('config_local_path', ''),
        'crosswalk_state_mtime': side_paths.get('crosswalk_state_path', ''),
    }
    mtimes = {}
    for key, path in paths.items():
        try:
            mtimes[key] = os.path.getmtime(path) if path and os.path.exists(path) else None
        except (OSError, TypeError):
            mtimes[key] = None
    return mtimes


def format_preflight_report(report, compact=False):
    """Print report to stdout. compact=True for launcher."""
    counts = report.get('counts', {})
    npass = counts.get('pass', 0)
    nwarn = counts.get('warn', 0)
    nfail = counts.get('fail', 0)
    if compact:
        if nwarn == 0 and nfail == 0:
            return
        print('Preflight: {0} pass, {1} warn, {2} fail'.format(npass, nwarn, nfail))
        for r in report.get('results', []):
            if r.get('status') in ('WARN', 'SKIP', 'FAIL'):
                msg = r.get('message', '')
                hint = r.get('hint', '')
                print('[{0}] {1}: {2}'.format(r.get('status', ''), r.get('id', ''), msg))
                if hint:
                    print('  -> hint: {0}'.format(hint))
    else:
        print('MediCafe Preflight Check')
        print('-' * 23)
        for r in report.get('results', []):
            status = r.get('status', 'PASS')
            cid = r.get('id', '')
            msg = r.get('message', '')
            hint = r.get('hint', '')
            print('[{0}] {1}: {2}'.format(status, cid, msg))
            if hint:
                print('  -> hint: {0}'.format(hint))
        print('-' * 23)
        print('Pass: {0}  Warn: {1}  Fail: {2}'.format(npass, nwarn, nfail))
        dur_ms = report.get('duration_ms', 0)
        print('Duration: {0:.2f}s'.format(dur_ms / 1000.0))
