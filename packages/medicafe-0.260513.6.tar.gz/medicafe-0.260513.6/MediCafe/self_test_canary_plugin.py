#!/usr/bin/env python
"""
Standalone XP workflow-boundary canary plugin.

This module is intentionally not wired into the Troubleshooting menu yet. It is
the installable helper surface for a future active support self-test that will
exercise workflow-boundary failures with synthetic, non-PHI fixtures.

Future install checklist:

1. Import MediCafe.self_test_canary_plugin inside collect_test_support_bundle()
   or immediately before it in email_test_error_report_flow().
2. Build hooks from existing production functions:
   - classify_csv: MediBot.process_csvs.classify_medibot_intake_csv_header
   - run_csv_intake: MediBot.process_csvs.process_csv
   - update_csv_path: MediBot.update_json.update_csv_path
   - run_phase_b_discovery: scripts/unified_model/discover_artifacts.py wrapper
   - run_phase_c_ingest: scripts/unified_model/ingest_from_manifest.py wrapper
   - run_phase_d_qa: scripts/unified_model/run_qa_canonical.py or parser wrapper
   - run_shadow_pipeline: cloud-readiness shadow pipeline wrapper
3. Call run_canary(runtime_context=runtime, hooks=hooks).
4. Merge summarize_canary_report(report) into
   meta["self_test_canary_summary"].
5. Append build_bundle_extra_files(report) to the support bundle extra_files.
6. Preserve the existing read-only self_test_report.json behavior.
7. Keep production config immutable; only pass temp config via
   MEDICAFE_CONFIG_FILE and MEDICAFE_CROSSWALK_FILE.

XP compatibility:
Keep this module Python 3.4 compatible. Do not use f-strings, dataclasses,
pathlib-only APIs, subprocess.run, or tempfile.TemporaryDirectory.
"""
from __future__ import print_function

import copy
import csv
import hashlib
import io
import json
import os
import shutil
import sys
import time
import zipfile


PLUGIN_ID = "xp_workflow_boundary_canary"
PLUGIN_SCHEMA_VERSION = 1

HOOK_CLASSIFY_CSV = "classify_csv"
HOOK_RUN_CSV_INTAKE = "run_csv_intake"
HOOK_UPDATE_CSV_PATH = "update_csv_path"
HOOK_RUN_PHASE_B_DISCOVERY = "run_phase_b_discovery"
HOOK_RUN_PHASE_C_INGEST = "run_phase_c_ingest"
HOOK_RUN_PHASE_D_QA = "run_phase_d_qa"
HOOK_RUN_SHADOW_PIPELINE = "run_shadow_pipeline"

OUTPUT_REPORT_JSON = "self_test_canary_report.json"
OUTPUT_README_TXT = "SELF_TEST_CANARY_README.txt"

STATUS_PASS = "pass"
STATUS_FAIL = "fail"
STATUS_SKIPPED = "skipped"
STATUS_WARNING = "warning"

BLOCKER_HOOK_UNAVAILABLE = "hook_unavailable"
BLOCKER_EXPECTATION_NOT_MET = "expectation_not_met"
BLOCKER_EXCEPTION = "exception"

SCENARIO_POISONED_REPAIR_AVAILABLE = "csv.poisoned_path_repair_available"
SCENARIO_POISONED_REPAIR_UNAVAILABLE = "csv.poisoned_path_repair_unavailable"
SCENARIO_LOCAL_STORAGE_QUARANTINE = "csv.local_storage_quarantine"
SCENARIO_GOOD_INTAKE_PROMOTION = "csv.good_intake_promotion"
SCENARIO_UPDATE_JSON_REFUSAL = "csv.update_json_refusal"
SCENARIO_PHASE_D_SHORT_CIRCUIT = "csv.phase_d_short_circuit"

SCENARIO_IDS = [
    SCENARIO_POISONED_REPAIR_AVAILABLE,
    SCENARIO_POISONED_REPAIR_UNAVAILABLE,
    SCENARIO_LOCAL_STORAGE_QUARANTINE,
    SCENARIO_GOOD_INTAKE_PROMOTION,
    SCENARIO_UPDATE_JSON_REFUSAL,
    SCENARIO_PHASE_D_SHORT_CIRCUIT,
]

SCENARIO_WORKSPACE_TOKENS = {
    SCENARIO_POISONED_REPAIR_AVAILABLE: "s01",
    SCENARIO_POISONED_REPAIR_UNAVAILABLE: "s02",
    SCENARIO_LOCAL_STORAGE_QUARANTINE: "s03",
    SCENARIO_GOOD_INTAKE_PROMOTION: "s04",
    SCENARIO_UPDATE_JSON_REFUSAL: "s05",
    SCENARIO_PHASE_D_SHORT_CIRCUIT: "s06",
}

GOOD_INTAKE_HEADER = [
    "Surgery Date",
    "Patient ID",
    "Patient Last",
    "Patient First",
    "Ins1 Payer ID",
]

BAD_ACTION_HEADER = [
    "category",
    "patient_id",
    "dos",
    "payer_id",
    "claim_key",
    "claim_number",
    "detail",
    "next_action",
]


def describe_plugin():
    """Return the stable plugin contract for future wiring."""
    return {
        "plugin_id": PLUGIN_ID,
        "schema_version": PLUGIN_SCHEMA_VERSION,
        "scenario_ids": list(SCENARIO_IDS),
        "required_hooks": [
            HOOK_CLASSIFY_CSV,
            HOOK_RUN_CSV_INTAKE,
            HOOK_UPDATE_CSV_PATH,
            HOOK_RUN_PHASE_B_DISCOVERY,
            HOOK_RUN_PHASE_C_INGEST,
            HOOK_RUN_PHASE_D_QA,
            HOOK_RUN_SHADOW_PIPELINE,
        ],
        "default_hooks": [
            HOOK_CLASSIFY_CSV,
            HOOK_RUN_PHASE_D_QA,
        ],
        "output_files": [
            OUTPUT_REPORT_JSON,
            OUTPUT_README_TXT,
        ],
        "install_notes": [
            "Do not wire this module into Troubleshooting option 1 until hooks are supplied.",
            "Run against a temp config copy and pass it via MEDICAFE_CONFIG_FILE.",
            "Attach build_bundle_extra_files(report) to the existing bundle_kind=test support ZIP.",
            "Merge summarize_canary_report(report) into meta['self_test_canary_summary'].",
            "Keep production config immutable; only canary temp config may be edited.",
        ],
    }


def run_canary(runtime_context=None, hooks=None, scenario_ids=None, dry_run=False):
    """
    Run synthetic workflow-boundary canary scenarios.

    Returns a JSON-safe report dict. Scenario failures are captured as result
    rows instead of raising.
    """
    runtime_context = runtime_context if isinstance(runtime_context, dict) else {}
    hooks = hooks if isinstance(hooks, dict) else {}
    selected = _normalize_scenario_ids(scenario_ids)
    started = _utc_timestamp()
    report = {
        "schema_version": PLUGIN_SCHEMA_VERSION,
        "plugin_id": PLUGIN_ID,
        "canary_run_id": _new_run_id(),
        "started_at_utc": started,
        "finished_at_utc": "",
        "dry_run": bool(dry_run),
        "scenario_ids": selected,
        "paths": {},
        "production_config_validation": {},
        "fixture_manifest": [],
        "scenario_results": [],
        "summary": {},
        "cleanup": {},
        "top_level_error": "",
    }

    workspace = None
    try:
        if dry_run:
            for sid in selected:
                report["scenario_results"].append(_scenario_result(
                    sid,
                    STATUS_SKIPPED,
                    "dry_run",
                    "dry_run_requested",
                    expected="Scenario would run when dry_run is false.",
                ))
            _finalize_report(report)
            return _json_safe(report)

        workspace = _prepare_workspace(runtime_context, report["canary_run_id"])
        report["paths"] = _workspace_public_paths(workspace)
        report["production_config_validation"] = _validate_production_config(runtime_context, hooks)

        context = {
            "runtime_context": runtime_context,
            "hooks": hooks,
            "workspace": workspace,
            "report": report,
        }
        runners = _scenario_runners()
        for sid in selected:
            runner = runners.get(sid)
            if runner is None:
                report["scenario_results"].append(_scenario_result(
                    sid,
                    STATUS_SKIPPED,
                    "unknown_scenario",
                    "Scenario id is not registered.",
                ))
                continue
            try:
                result = runner(context)
            except BaseException as exc:
                result = _scenario_result(
                    sid,
                    STATUS_FAIL,
                    BLOCKER_EXCEPTION,
                    "Scenario raised {0}".format(exc.__class__.__name__),
                    observed={"exception_class": exc.__class__.__name__, "exception_message": _safe_text(exc, 240)},
                )
            report["scenario_results"].append(_json_safe(result))
    except BaseException as exc:
        report["top_level_error"] = "{0}: {1}".format(exc.__class__.__name__, _safe_text(exc, 240))
        report["scenario_results"].append(_scenario_result(
            "canary.setup",
            STATUS_FAIL,
            BLOCKER_EXCEPTION,
            "Canary setup failed.",
            observed={"exception_class": exc.__class__.__name__, "exception_message": _safe_text(exc, 240)},
        ))
    finally:
        if workspace is not None and not dry_run:
            report["cleanup"] = _quarantine_workspace(workspace)
            _finalize_report(report)
            _persist_report(report, workspace)
        else:
            _finalize_report(report)
    return _json_safe(report)


def summarize_canary_report(report):
    """Return compact support-bundle metadata for meta.json."""
    report = report if isinstance(report, dict) else {}
    summary = report.get("summary") if isinstance(report.get("summary"), dict) else {}
    return {
        "schema_version": PLUGIN_SCHEMA_VERSION,
        "plugin_id": PLUGIN_ID,
        "canary_run_id": _safe_text(report.get("canary_run_id"), 80),
        "started_at_utc": _safe_text(report.get("started_at_utc"), 32),
        "finished_at_utc": _safe_text(report.get("finished_at_utc"), 32),
        "scenario_count": _safe_int(summary.get("scenario_count"), 0),
        "pass_count": _safe_int(summary.get("pass_count"), 0),
        "fail_count": _safe_int(summary.get("fail_count"), 0),
        "warning_count": _safe_int(summary.get("warning_count"), 0),
        "skipped_count": _safe_int(summary.get("skipped_count"), 0),
        "failing_scenario_ids": list(summary.get("failing_scenario_ids") or [])[:12],
        "skipped_scenario_ids": list(summary.get("skipped_scenario_ids") or [])[:12],
        "top_level_error": _safe_text(report.get("top_level_error"), 160),
    }


def build_bundle_extra_files(report):
    """Return bundle-safe extra files for the existing support ZIP builder."""
    report = _json_safe(report if isinstance(report, dict) else {})
    return [
        (OUTPUT_REPORT_JSON, report),
        (OUTPUT_README_TXT, _build_readme(report)),
    ]


# Future install hook: satisfy this with
# MediBot.process_csvs.classify_medibot_intake_csv_header.
def _default_classify_csv(path):
    try:
        from MediBot.csv_intake_shape import classify_medibot_intake_csv_file
        return classify_medibot_intake_csv_file(path)
    except Exception as exc:
        return {
            "ok": False,
            "reason": "classifier_unavailable",
            "error": _safe_text(exc, 160),
            "raw_headers": [],
            "cleaned_headers": [],
            "canonical_headers": [],
            "header_count": 0,
        }


# Future install hook: satisfy this with MediBot.process_csvs.process_csv.
def _missing_run_csv_intake(_source_folder, _target_folder, _config_file, _local_storage_path):
    return _missing_hook_result(HOOK_RUN_CSV_INTAKE)


# Future install hook: satisfy this with MediBot.update_json.update_csv_path.
def _missing_update_csv_path(_config_file, _csv_path):
    return _missing_hook_result(HOOK_UPDATE_CSV_PATH)


# Future install hook: satisfy this with a discover_artifacts.py subprocess wrapper.
def _missing_run_phase_b_discovery(_env):
    return _missing_hook_result(HOOK_RUN_PHASE_B_DISCOVERY)


# Future install hook: satisfy this with an ingest_from_manifest.py subprocess wrapper.
def _missing_run_phase_c_ingest(_env):
    return _missing_hook_result(HOOK_RUN_PHASE_C_INGEST)


# Future install hook: eventually satisfy this with run_qa_canonical.py. The
# default is read-only and only exercises the CSV parse short-circuit.
def _default_run_phase_d_qa(env):
    env = env if isinstance(env, dict) else {}
    csv_path = env.get("csv_path") or env.get("bad_csv_path") or ""
    script_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "scripts", "unified_model"))
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)
    try:
        import parse_providers
        ok, _envelope, code = parse_providers.parse_csv(csv_path, metadata={})
        diag = {}
        try:
            diag = parse_providers.get_last_parse_diag()
        except Exception:
            diag = {}
        source_class = _safe_text(diag.get("source_exception_class"), 80)
        detail = _safe_text(diag.get("error_detail"), 240)
        operational_shape = source_class == "CsvOperationalShape"
        return {
            "ok": bool((not ok) and operational_shape),
            "parse_ok": bool(ok),
            "warning_code": _safe_text(code, 80),
            "source_exception_class": source_class,
            "error_detail": detail,
        }
    except Exception as exc:
        return {
            "ok": False,
            "exception_class": exc.__class__.__name__,
            "exception_message": _safe_text(exc, 240),
        }


# Future install hook: satisfy this with the cloud-readiness shadow pipeline wrapper.
def _missing_run_shadow_pipeline(_env):
    return _missing_hook_result(HOOK_RUN_SHADOW_PIPELINE)


def _default_hooks():
    return {
        HOOK_CLASSIFY_CSV: _default_classify_csv,
        HOOK_RUN_PHASE_D_QA: _default_run_phase_d_qa,
    }


def _missing_hook_result(name):
    return {
        "ok": False,
        "status": STATUS_SKIPPED,
        "blocker_class": BLOCKER_HOOK_UNAVAILABLE,
        "hook_name": name,
    }


def _scenario_runners():
    return {
        SCENARIO_POISONED_REPAIR_AVAILABLE: _run_poisoned_repair_available,
        SCENARIO_POISONED_REPAIR_UNAVAILABLE: _run_poisoned_repair_unavailable,
        SCENARIO_LOCAL_STORAGE_QUARANTINE: _run_local_storage_quarantine,
        SCENARIO_GOOD_INTAKE_PROMOTION: _run_good_intake_promotion,
        SCENARIO_UPDATE_JSON_REFUSAL: _run_update_json_refusal,
        SCENARIO_PHASE_D_SHORT_CIRCUIT: _run_phase_d_short_circuit,
    }


def _run_poisoned_repair_available(context):
    sid = SCENARIO_POISONED_REPAIR_AVAILABLE
    paths = _prepare_scenario_workspace(context, sid, configured_bad=True, valid_fallback=True)
    run_hook = _resolve_hook(context.get("hooks"), HOOK_RUN_CSV_INTAKE, allow_default=False)
    if run_hook is None:
        return _skipped_for_hook(sid, HOOK_RUN_CSV_INTAKE, fixtures=paths.get("fixtures"))
    before = _read_effective_csv_path(paths.get("config_file"))
    hook_result = _call_hook(
        run_hook,
        paths.get("source_folder"),
        paths.get("target_folder"),
        paths.get("config_file"),
        paths.get("storage_folder"),
    )
    after = _read_effective_csv_path(paths.get("config_file"))
    good_base = os.path.basename(paths.get("good_target_csv") or "")
    repaired = os.path.basename(after or "") == good_base
    return _scenario_result(
        sid,
        STATUS_PASS if repaired else STATUS_FAIL,
        "" if repaired else BLOCKER_EXPECTATION_NOT_MET,
        "Expected poisoned CSV_FILE_PATH to repair to the newest valid intake SX_CSV.",
        expected="configured path repaired to {0}".format(good_base),
        observed={
            "before_csv_path": before,
            "after_csv_path": after,
            "bad_shape": _classify_path(context, paths.get("bad_target_csv")),
            "hook_result": hook_result,
            "fixtures": paths.get("fixtures"),
        },
    )


def _run_poisoned_repair_unavailable(context):
    sid = SCENARIO_POISONED_REPAIR_UNAVAILABLE
    paths = _prepare_scenario_workspace(context, sid, configured_bad=True, valid_fallback=False)
    run_hook = _resolve_hook(context.get("hooks"), HOOK_RUN_CSV_INTAKE, allow_default=False)
    if run_hook is None:
        return _skipped_for_hook(sid, HOOK_RUN_CSV_INTAKE, fixtures=paths.get("fixtures"))
    before = _read_effective_csv_path(paths.get("config_file"))
    hook_result = _call_hook(
        run_hook,
        paths.get("source_folder"),
        paths.get("target_folder"),
        paths.get("config_file"),
        paths.get("storage_folder"),
    )
    after = _read_effective_csv_path(paths.get("config_file"))
    bad_base = os.path.basename(paths.get("bad_target_csv") or "")
    still_bad = os.path.basename(after or "") == bad_base
    shape = _classify_path(context, after)
    unavailable = still_bad and shape.get("reason") == "action_or_reconciliation_csv"
    return _scenario_result(
        sid,
        STATUS_PASS if unavailable else STATUS_FAIL,
        "" if unavailable else BLOCKER_EXPECTATION_NOT_MET,
        "Expected no-repair case to leave the poisoned path detectable as non-intake.",
        expected="no valid replacement; configured path remains classified action_or_reconciliation_csv",
        observed={
            "before_csv_path": before,
            "after_csv_path": after,
            "after_shape": shape,
            "hook_result": hook_result,
            "fixtures": paths.get("fixtures"),
        },
    )


def _run_local_storage_quarantine(context):
    sid = SCENARIO_LOCAL_STORAGE_QUARANTINE
    paths = _prepare_scenario_workspace(context, sid, storage_bad=True)
    run_hook = _resolve_hook(context.get("hooks"), HOOK_RUN_CSV_INTAKE, allow_default=False)
    if run_hook is None:
        return _skipped_for_hook(sid, HOOK_RUN_CSV_INTAKE, fixtures=paths.get("fixtures"))
    hook_result = _call_hook(
        run_hook,
        paths.get("source_folder"),
        paths.get("target_folder"),
        paths.get("config_file"),
        paths.get("storage_folder"),
    )
    quarantine_hits = _find_non_intake_quarantine_files(paths.get("storage_folder"))
    ok = bool(quarantine_hits)
    return _scenario_result(
        sid,
        STATUS_PASS if ok else STATUS_FAIL,
        "" if ok else BLOCKER_EXPECTATION_NOT_MET,
        "Expected bad storage CSV to be quarantined, not promoted.",
        expected="NON_INTAKE_action_or_reconciliation_csv_* file present",
        observed={
            "quarantine_basenames": [os.path.basename(p) for p in quarantine_hits],
            "hook_result": hook_result,
            "fixtures": paths.get("fixtures"),
        },
    )


def _run_good_intake_promotion(context):
    sid = SCENARIO_GOOD_INTAKE_PROMOTION
    paths = _prepare_scenario_workspace(context, sid, source_good=True)
    run_hook = _resolve_hook(context.get("hooks"), HOOK_RUN_CSV_INTAKE, allow_default=False)
    if run_hook is None:
        return _skipped_for_hook(sid, HOOK_RUN_CSV_INTAKE, fixtures=paths.get("fixtures"))
    hook_result = _call_hook(
        run_hook,
        paths.get("source_folder"),
        paths.get("target_folder"),
        paths.get("config_file"),
        paths.get("storage_folder"),
    )
    promoted = _find_sx_csv_files(paths.get("target_folder"))
    valid_promoted = []
    for path in promoted:
        shape = _classify_path(context, path)
        if shape.get("ok"):
            valid_promoted.append(path)
    ok = bool(valid_promoted)
    return _scenario_result(
        sid,
        STATUS_PASS if ok else STATUS_FAIL,
        "" if ok else BLOCKER_EXPECTATION_NOT_MET,
        "Expected good Carol intake CSV to promote into SX_CSV namespace.",
        expected="at least one promoted SX_CSV_* with valid intake shape",
        observed={
            "promoted_basenames": [os.path.basename(p) for p in promoted],
            "valid_promoted_basenames": [os.path.basename(p) for p in valid_promoted],
            "effective_csv_path": _read_effective_csv_path(paths.get("config_file")),
            "hook_result": hook_result,
            "fixtures": paths.get("fixtures"),
        },
    )


def _run_update_json_refusal(context):
    sid = SCENARIO_UPDATE_JSON_REFUSAL
    paths = _prepare_scenario_workspace(context, sid, configured_good=True, valid_fallback=True)
    update_hook = _resolve_hook(context.get("hooks"), HOOK_UPDATE_CSV_PATH, allow_default=False)
    if update_hook is None:
        return _skipped_for_hook(sid, HOOK_UPDATE_CSV_PATH, fixtures=paths.get("fixtures"))
    before = _read_effective_csv_path(paths.get("config_file"))
    hook_result = _call_hook(update_hook, paths.get("config_file"), paths.get("bad_target_csv"))
    after = _read_effective_csv_path(paths.get("config_file"))
    refused = not bool(hook_result.get("ok"))
    not_poisoned = os.path.basename(after or "") != os.path.basename(paths.get("bad_target_csv") or "")
    ok = refused and not_poisoned
    return _scenario_result(
        sid,
        STATUS_PASS if ok else STATUS_FAIL,
        "" if ok else BLOCKER_EXPECTATION_NOT_MET,
        "Expected direct CSV_FILE_PATH writer to refuse non-intake CSV.",
        expected="writer returns non-ok and temp config does not point at bad SX_CSV",
        observed={
            "before_csv_path": before,
            "after_csv_path": after,
            "bad_shape": _classify_path(context, paths.get("bad_target_csv")),
            "hook_result": hook_result,
            "fixtures": paths.get("fixtures"),
        },
    )


def _run_phase_d_short_circuit(context):
    sid = SCENARIO_PHASE_D_SHORT_CIRCUIT
    paths = _prepare_scenario_workspace(context, sid, configured_bad=True)
    qa_hook = _resolve_hook(context.get("hooks"), HOOK_RUN_PHASE_D_QA, allow_default=True)
    if qa_hook is None:
        return _skipped_for_hook(sid, HOOK_RUN_PHASE_D_QA, fixtures=paths.get("fixtures"))
    env = {
        "csv_path": paths.get("bad_target_csv"),
        "bad_csv_path": paths.get("bad_target_csv"),
        "config_file": paths.get("config_file"),
        "MEDICAFE_CONFIG_FILE": paths.get("config_file"),
        "MEDICAFE_CROSSWALK_FILE": paths.get("crosswalk_file"),
    }
    hook_result = _call_hook(qa_hook, env)
    source_class = _safe_text(hook_result.get("source_exception_class"), 80)
    ok = bool(hook_result.get("ok")) or source_class == "CsvOperationalShape"
    return _scenario_result(
        sid,
        STATUS_PASS if ok else STATUS_FAIL,
        "" if ok else BLOCKER_EXPECTATION_NOT_MET,
        "Expected Phase D CSV path to short-circuit action/report CSV before patient canonicalization.",
        expected="CsvOperationalShape or hook ok=true",
        observed={
            "bad_shape": _classify_path(context, paths.get("bad_target_csv")),
            "hook_result": hook_result,
            "fixtures": paths.get("fixtures"),
        },
    )


def _normalize_scenario_ids(scenario_ids):
    if scenario_ids is None:
        return list(SCENARIO_IDS)
    out = []
    for sid in scenario_ids:
        text = _safe_text(sid, 120)
        if text and text not in out:
            out.append(text)
    return out


def _prepare_workspace(runtime_context, run_id):
    local_storage = _resolve_local_storage(runtime_context)
    root = os.path.join(local_storage, "self_test_canary", run_id)
    work = os.path.join(root, "work")
    quarantine = os.path.join(root, "quarantine")
    reports = os.path.join(root, "reports")
    for path in (root, work, quarantine, reports):
        _ensure_dir(path)
    return {
        "root": root,
        "work": work,
        "quarantine": quarantine,
        "reports": reports,
        "runtime_context": runtime_context,
        "base_config": _runtime_config(runtime_context),
        "base_crosswalk": _runtime_crosswalk(runtime_context),
    }


def _workspace_public_paths(workspace):
    return {
        "canary_root": workspace.get("root", ""),
        "work_root": workspace.get("work", ""),
        "quarantine_root": workspace.get("quarantine", ""),
        "reports_root": workspace.get("reports", ""),
        "report_json": os.path.join(workspace.get("reports", ""), OUTPUT_REPORT_JSON),
    }


def _prepare_scenario_workspace(context, scenario_id, configured_bad=False,
                                configured_good=False, valid_fallback=False,
                                storage_bad=False, source_good=False):
    workspace = context.get("workspace") or {}
    scenario_token = SCENARIO_WORKSPACE_TOKENS.get(scenario_id) or _safe_filename_token(scenario_id)
    root = os.path.join(workspace.get("work", ""), scenario_token)
    source = os.path.join(root, "source")
    target = os.path.join(root, "target", "CSV")
    storage = os.path.join(root, "storage")
    dat_dir = os.path.join(root, "dat")
    docx_dir = os.path.join(root, "docx")
    config_dir = os.path.join(root, "config")
    for path in (root, source, target, storage, dat_dir, docx_dir, config_dir):
        _ensure_dir(path)

    good_target = os.path.join(target, "SX_CSV_20260513_010101_000001.csv")
    bad_target = os.path.join(target, "SX_CSV_20260513_010102_000002.csv")
    good_source = os.path.join(source, "carol_intake_canary.csv")
    bad_storage = os.path.join(storage, "action.csv")
    dat_path = os.path.join(dat_dir, "Z_CANARY.DAT")
    docx_path = os.path.join(docx_dir, "canary_schedule.docx")

    if source_good:
        _write_good_intake_csv(good_source)
    if valid_fallback or configured_good:
        _write_good_intake_csv(good_target)
    _write_bad_action_csv(bad_target)
    if storage_bad:
        _write_bad_action_csv(bad_storage)
    _write_minimal_dat(dat_path)
    _write_minimal_docx(docx_path)

    if configured_good:
        configured_csv = good_target
    elif configured_bad:
        configured_csv = bad_target
    else:
        configured_csv = ""
    config_file = os.path.join(config_dir, "config.json")
    crosswalk_file = os.path.join(config_dir, "crosswalk.json")
    _write_temp_config(
        workspace.get("base_config"),
        workspace.get("base_crosswalk"),
        config_file,
        crosswalk_file,
        configured_csv,
        storage,
        dat_path,
    )

    fixtures = []
    for logical_id, path in (
            ("good_target_csv", good_target),
            ("bad_target_csv", bad_target),
            ("good_source_csv", good_source),
            ("bad_storage_csv", bad_storage),
            ("dat", dat_path),
            ("docx", docx_path)):
        if os.path.isfile(path):
            fixtures.append(_fixture_record(logical_id, path))
    report = context.get("report")
    if isinstance(report, dict):
        report.setdefault("fixture_manifest", []).extend(fixtures)

    return {
        "scenario_root": root,
        "source_folder": source,
        "target_folder": target,
        "storage_folder": storage,
        "dat_dir": dat_dir,
        "docx_dir": docx_dir,
        "config_file": config_file,
        "crosswalk_file": crosswalk_file,
        "good_target_csv": good_target,
        "bad_target_csv": bad_target,
        "good_source_csv": good_source,
        "bad_storage_csv": bad_storage,
        "dat_path": dat_path,
        "docx_path": docx_path,
        "fixtures": fixtures,
    }


def _write_temp_config(base_config, base_crosswalk, config_file, crosswalk_file,
                       csv_file_path, local_storage_path, dat_path):
    config = _deep_copy_dict(base_config)
    if not isinstance(config, dict):
        config = {}
    medi = config.get("MediLink_Config")
    if not isinstance(medi, dict):
        medi = {}
    if csv_file_path:
        config["CSV_FILE_PATH"] = csv_file_path
        medi["CSV_FILE_PATH"] = csv_file_path
    medi["local_storage_path"] = local_storage_path
    medi["Z_DAT_PATH"] = dat_path
    medi["inputFilePath"] = dat_path
    config["MediLink_Config"] = medi
    _write_json(config_file, config)
    _write_json(crosswalk_file, _deep_copy_dict(base_crosswalk))


def _validate_production_config(runtime_context, hooks):
    config = _runtime_config(runtime_context)
    out = {
        "has_config": isinstance(config, dict),
        "csv_file_path_present": False,
        "csv_file_basename": "",
        "csv_file_readable": False,
        "csv_file_sha256": "",
        "csv_shape_ok": False,
        "csv_shape_reason": "",
    }
    csv_path = ""
    if isinstance(config, dict):
        csv_path = _safe_text(config.get("CSV_FILE_PATH"), 512)
        medi = config.get("MediLink_Config")
        if not csv_path and isinstance(medi, dict):
            csv_path = _safe_text(medi.get("CSV_FILE_PATH"), 512)
    out["csv_file_path_present"] = bool(csv_path)
    out["csv_file_basename"] = os.path.basename(csv_path) if csv_path else ""
    if csv_path and os.path.isfile(csv_path):
        out["csv_file_readable"] = True
        out["csv_file_sha256"] = _sha256_file(csv_path)
        shape = _classify_with_hooks(hooks, csv_path)
        out["csv_shape_ok"] = bool(shape.get("ok"))
        out["csv_shape_reason"] = _safe_text(shape.get("reason"), 80)
    return out


def _resolve_hook(hooks, name, allow_default=True):
    hooks = hooks if isinstance(hooks, dict) else {}
    candidate = hooks.get(name)
    if callable(candidate):
        return candidate
    if allow_default:
        default = _default_hooks().get(name)
        if callable(default):
            return default
    return None


def _classify_path(context, path):
    return _classify_with_hooks(context.get("hooks"), path)


def _classify_with_hooks(hooks, path):
    hook = _resolve_hook(hooks, HOOK_CLASSIFY_CSV, allow_default=True)
    if hook is None:
        return {
            "ok": False,
            "reason": BLOCKER_HOOK_UNAVAILABLE,
            "raw_headers": [],
            "cleaned_headers": [],
            "canonical_headers": [],
            "header_count": 0,
        }
    result = _call_hook(hook, path)
    if "ok" not in result and "reason" not in result:
        return {
            "ok": False,
            "reason": "classifier_invalid_result",
            "raw": result,
        }
    return result


def _call_hook(func, *args):
    started = time.time()
    try:
        raw = func(*args)
        out = _coerce_hook_result(raw)
    except BaseException as exc:
        out = {
            "ok": False,
            "exception_class": exc.__class__.__name__,
            "exception_message": _safe_text(exc, 240),
        }
        if exc.__class__.__name__ == "SystemExit":
            try:
                out["return_code"] = int(exc.code)
            except Exception:
                out["return_code"] = 1
    out["elapsed_sec"] = round(time.time() - started, 4)
    return _json_safe(out)


def _coerce_hook_result(raw):
    if isinstance(raw, dict):
        out = dict(raw)
        if "ok" not in out:
            if str(out.get("status") or "").lower() == STATUS_PASS:
                out["ok"] = True
            elif "return_code" in out:
                out["ok"] = _safe_int(out.get("return_code"), 1) == 0
        return out
    if isinstance(raw, bool):
        return {"ok": raw}
    if isinstance(raw, int):
        return {"ok": raw == 0, "return_code": raw}
    if isinstance(raw, tuple):
        out = {"ok": False, "raw_tuple_len": len(raw)}
        if len(raw) >= 1:
            first = raw[0]
            if isinstance(first, bool):
                out["ok"] = first
            elif isinstance(first, int):
                out["ok"] = first == 0
                out["return_code"] = first
        if len(raw) >= 2:
            out["message"] = _safe_text(raw[1], 240)
        if len(raw) >= 3:
            out["payload"] = _json_safe(raw[2])
        return out
    return {"ok": bool(raw), "raw_type": raw.__class__.__name__ if raw is not None else "None"}


def _scenario_result(scenario_id, status, blocker_class="", detail="", expected="", observed=None):
    return {
        "id": scenario_id,
        "status": status,
        "blocker_class": blocker_class,
        "detail": detail,
        "expected": expected,
        "observed": _json_safe(observed if observed is not None else {}),
    }


def _skipped_for_hook(scenario_id, hook_name, fixtures=None):
    return _scenario_result(
        scenario_id,
        STATUS_SKIPPED,
        BLOCKER_HOOK_UNAVAILABLE,
        "Required hook is not installed: {0}".format(hook_name),
        expected="Future integration provides hook {0}.".format(hook_name),
        observed={"missing_hook": hook_name, "fixtures": fixtures or []},
    )


def _find_non_intake_quarantine_files(storage_folder):
    hits = []
    root = os.path.join(storage_folder, "non_intake_csv")
    if not os.path.isdir(root):
        return hits
    try:
        for name in os.listdir(root):
            if name.startswith("NON_INTAKE_action_or_reconciliation_csv_") and name.lower().endswith(".csv"):
                hits.append(os.path.join(root, name))
    except Exception:
        return hits
    hits.sort()
    return hits


def _find_sx_csv_files(target_folder):
    hits = []
    if not os.path.isdir(target_folder):
        return hits
    try:
        for name in os.listdir(target_folder):
            if name.upper().startswith("SX_CSV_") and name.lower().endswith(".csv"):
                path = os.path.join(target_folder, name)
                if os.path.isfile(path):
                    hits.append(path)
    except Exception:
        return hits
    hits.sort()
    return hits


def _read_effective_csv_path(config_file):
    config = _read_json_dict(config_file)
    value = _safe_text(config.get("CSV_FILE_PATH"), 512)
    local_path = os.path.join(os.path.dirname(os.path.abspath(config_file)), "config.local.json")
    local = _read_json_dict(local_path)
    if isinstance(local, dict) and local.get("CSV_FILE_PATH"):
        value = _safe_text(local.get("CSV_FILE_PATH"), 512)
    return value


def _quarantine_workspace(workspace):
    work = workspace.get("work", "")
    quarantine = workspace.get("quarantine", "")
    out = {
        "status": "not_attempted",
        "source": work,
        "destination": "",
        "error": "",
    }
    if not work or not os.path.isdir(work):
        out["status"] = "not_needed"
        return out
    try:
        _ensure_dir(quarantine)
        dest = os.path.join(quarantine, "work")
        if os.path.exists(dest):
            dest = os.path.join(quarantine, "work_{0}".format(int(time.time())))
        shutil.move(work, dest)
        out["status"] = "quarantined"
        out["destination"] = dest
    except Exception as exc:
        out["status"] = "failed"
        out["error"] = "{0}: {1}".format(exc.__class__.__name__, _safe_text(exc, 160))
    return out


def _persist_report(report, workspace):
    reports = workspace.get("reports", "")
    if not reports:
        return
    try:
        _ensure_dir(reports)
        _write_json(os.path.join(reports, OUTPUT_REPORT_JSON), _json_safe(report))
    except Exception:
        pass


def _finalize_report(report):
    report["finished_at_utc"] = _utc_timestamp()
    pass_count = 0
    fail_count = 0
    warning_count = 0
    skipped_count = 0
    failing = []
    skipped = []
    for row in report.get("scenario_results") or []:
        status = row.get("status")
        if status == STATUS_PASS:
            pass_count += 1
        elif status == STATUS_WARNING:
            warning_count += 1
        elif status == STATUS_SKIPPED:
            skipped_count += 1
            if len(skipped) < 12:
                skipped.append(row.get("id"))
        else:
            fail_count += 1
            if len(failing) < 12:
                failing.append(row.get("id"))
    report["summary"] = {
        "scenario_count": len(report.get("scenario_results") or []),
        "pass_count": pass_count,
        "fail_count": fail_count,
        "warning_count": warning_count,
        "skipped_count": skipped_count,
        "failing_scenario_ids": failing,
        "skipped_scenario_ids": skipped,
    }


def _build_readme(report):
    summary = summarize_canary_report(report)
    lines = [
        "MediCafe XP Workflow-Boundary Canary",
        "====================================",
        "",
        "This standalone plugin report uses synthetic non-PHI fixtures.",
        "It is not wired into Troubleshooting option 1 yet.",
        "",
        "Plugin: {0}".format(PLUGIN_ID),
        "Run ID: {0}".format(summary.get("canary_run_id", "")),
        "Scenarios: {0}".format(summary.get("scenario_count", 0)),
        "Pass: {0}".format(summary.get("pass_count", 0)),
        "Fail: {0}".format(summary.get("fail_count", 0)),
        "Skipped: {0}".format(summary.get("skipped_count", 0)),
        "",
        "Future wiring should attach self_test_canary_report.json to the existing",
        "bundle_kind=test support self-test ZIP and preserve self_test_report.json.",
    ]
    return "\n".join(lines) + "\n"


def _write_good_intake_csv(path):
    rows = [
        GOOD_INTAKE_HEADER,
        ["05/13/2026", "22222", "CANARY", "CAROL", "87726"],
    ]
    _write_csv(path, rows)


def _write_bad_action_csv(path):
    rows = [
        BAD_ACTION_HEADER,
        ["needs_review", "22222", "2026-05-13", "87726", "22222|87726|20260513|canary", "CLM-CANARY", "synthetic action row", "review"],
    ]
    _write_csv(path, rows)


def _write_csv(path, rows):
    _ensure_dir(os.path.dirname(path))
    with io.open(path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        for row in rows:
            writer.writerow(row)


def _write_minimal_dat(path):
    _write_text(path, "CANARY    PAT22222             \nINSURANCE 87726                \n05/13/2026 66984               \n")


def _write_minimal_docx(path):
    _ensure_dir(os.path.dirname(path))
    content_types = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '</Types>'
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        '</Relationships>'
    )
    doc = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body>'
        '<w:p><w:r><w:t>Surgery Schedule Wednesday May 13 2026</w:t></w:r></w:p>'
        '<w:tbl>'
        '<w:tr><w:tc><w:p><w:r><w:t>#22222</w:t></w:r></w:p></w:tc>'
        '<w:tc><w:p><w:r><w:t>H25.11 RIGHT EYE FEMTO</w:t></w:r></w:p></w:tc></w:tr>'
        '</w:tbl>'
        '</w:body></w:document>'
    )
    archive = zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED)
    try:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", rels)
        archive.writestr("word/document.xml", doc)
    finally:
        archive.close()


def _fixture_record(logical_id, path):
    return {
        "logical_id": logical_id,
        "path": path,
        "basename": os.path.basename(path),
        "size_bytes": _file_size(path),
        "sha256": _sha256_file(path),
        "synthetic_non_phi": True,
        "raw_headers": _read_csv_header_if_csv(path),
    }


def _read_csv_header_if_csv(path):
    if not path or not path.lower().endswith(".csv") or not os.path.isfile(path):
        return []
    try:
        with io.open(path, "r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle)
            return next(reader, [])
    except Exception:
        return []


def _resolve_local_storage(runtime_context):
    medi = _runtime_medi(runtime_context)
    path = _safe_text(medi.get("local_storage_path"), 512)
    if not path:
        path = _safe_text(os.environ.get("MEDICAFE_LAB_DIR"), 512)
    if not path:
        path = os.path.join(os.getcwd(), "reports")
    return os.path.abspath(path)


def _runtime_medi(runtime_context):
    if isinstance(runtime_context, dict):
        medi = runtime_context.get("medi")
        if isinstance(medi, dict):
            return medi
        config = runtime_context.get("config")
        if isinstance(config, dict):
            nested = config.get("MediLink_Config")
            if isinstance(nested, dict):
                return nested
    return {}


def _runtime_config(runtime_context):
    if isinstance(runtime_context, dict):
        config = runtime_context.get("config")
        if isinstance(config, dict):
            return _deep_copy_dict(config)
    return {"MediLink_Config": _runtime_medi(runtime_context)}


def _runtime_crosswalk(runtime_context):
    if isinstance(runtime_context, dict):
        crosswalk = runtime_context.get("crosswalk")
        if isinstance(crosswalk, dict):
            return _deep_copy_dict(crosswalk)
    return {}


def _deep_copy_dict(value):
    if not isinstance(value, dict):
        return {}
    try:
        return copy.deepcopy(value)
    except Exception:
        try:
            return json.loads(json.dumps(value))
        except Exception:
            return dict(value)


def _read_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_json(path, payload):
    _ensure_dir(os.path.dirname(path))
    with io.open(path, "w", encoding="utf-8") as handle:
        json.dump(_json_safe(payload), handle, sort_keys=True, indent=2)
        handle.write("\n")


def _write_text(path, text):
    _ensure_dir(os.path.dirname(path))
    with io.open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


def _ensure_dir(path):
    if path and not os.path.isdir(path):
        os.makedirs(path)


def _sha256_file(path):
    if not path or not os.path.isfile(path):
        return ""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as handle:
            block = handle.read(65536)
            while block:
                h.update(block)
                block = handle.read(65536)
        return h.hexdigest()
    except Exception:
        return ""


def _file_size(path):
    try:
        return int(os.path.getsize(path))
    except Exception:
        return 0


def _json_safe(value):
    if isinstance(value, dict):
        out = {}
        for key, val in value.items():
            out[_safe_text(key, 120)] = _json_safe(val)
        return out
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [_json_safe(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return _safe_text(value, 240)


def _safe_text(value, max_len=160):
    try:
        if value is None:
            text = ""
        else:
            text = str(value)
    except Exception:
        text = ""
    text = text.replace("\r", " ").replace("\n", " ").strip()
    if len(text) > max_len:
        return text[:max_len]
    return text


def _safe_int(value, default_value=0):
    try:
        return int(value)
    except Exception:
        return default_value


def _safe_filename_token(value):
    text = _safe_text(value, 120)
    chars = []
    for char in text:
        if char.isalnum() or char in ("-", "_"):
            chars.append(char)
        else:
            chars.append("_")
    token = "".join(chars).strip("_")
    while "__" in token:
        token = token.replace("__", "_")
    return token or "scenario"


def _utc_timestamp():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _new_run_id():
    return "canary_{0}_{1}".format(time.strftime("%Y%m%d_%H%M%S", time.gmtime()), os.getpid())
