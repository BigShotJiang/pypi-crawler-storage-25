﻿from __future__ import print_function

import copy
import json
import os
import sys
import time
from collections import OrderedDict

TOMBSTONE = {'__tombstone__': True}
SIDECAR_META_KEY = '__sidecar__'
SIDECAR_SCHEMA_VERSION = 1
SIDECAR_BACKUP_RETENTION_COUNT = 2

CONFIG_LOCAL_FILENAME = 'config.local.json'
CROSSWALK_STATE_FILENAME = 'crosswalk.state.json'

STATE_OWNED_POINTERS = {
    'config': [
        '$/CSV_FILE_PATH',
        '$/MAPAT_MED_PATH',
        '$/MEDICARE_MAPAT_MED_PATH',
        '$/MAINS_MED_PATH',
        '$/AHK_EXECUTABLE',
        '$/medisoft_claims_directory',
        '$/MEDICARE_SHORTCUT',
        '$/PRIVATE_SHORTCUT',
        '$/MediLink_Config/crosswalkPath',
        '$/MediLink_Config/Z_DAT_PATH',
        '$/MediLink_Config/logFilePath',
        '$/MediLink_Config/outputFilePath',
        '$/MediLink_Config/inputFilePath',
        '$/MediLink_Config/local_storage_path',
        '$/MediLink_Config/local_claims_path',
        '$/MediLink_Config/winscp_path',
        '$/MediLink_Config/certificate_provider',
        '$/MediLink_Config/endpoints/*/client_secret',
        '$/MediLink_Config/endpoints/*/client_secret_last_updated',
    ],
    'crosswalk': [
        '$/optum_payer_list',
        '$/routing_overrides',
    ],
}

PRESERVE_EMPTY_BASELINE_POINTERS = {
    'config': [
        '$/MediLink_Config',
    ],
}


def _copy(value):
    try:
        return copy.deepcopy(value)
    except Exception:
        return value


def _ordered_mapping():
    try:
        return OrderedDict()
    except Exception:
        return {}


def is_tombstone(value):
    return isinstance(value, dict) and value.get('__tombstone__') is True


def strip_sidecar_meta(payload):
    if not isinstance(payload, dict):
        return payload
    out = _ordered_mapping()
    for key, value in payload.items():
        if key == SIDECAR_META_KEY:
            continue
        if isinstance(value, dict):
            out[key] = strip_sidecar_meta(value)
        elif isinstance(value, list):
            out[key] = [strip_sidecar_meta(v) if isinstance(v, dict) else v for v in value]
        else:
            out[key] = value
    return out


def strip_tombstones(payload):
    if isinstance(payload, dict):
        out = _ordered_mapping()
        for key, value in payload.items():
            if key == SIDECAR_META_KEY:
                continue
            if is_tombstone(value):
                continue
            out[key] = strip_tombstones(value)
        return out
    if isinstance(payload, list):
        return [strip_tombstones(v) for v in payload]
    return payload


def deep_merge(base, overlay):
    if overlay is None:
        return _copy(base)
    if is_tombstone(overlay):
        return _copy(overlay)
    if isinstance(base, dict) and isinstance(overlay, dict):
        merged = _ordered_mapping()
        keys = []
        for src in (base, overlay):
            for key in src.keys():
                if key not in keys:
                    keys.append(key)
        for key in keys:
            if key == SIDECAR_META_KEY:
                continue
            if key in overlay:
                over_val = overlay[key]
                if is_tombstone(over_val):
                    if key in base:
                        merged[key] = _copy(over_val)
                    continue
                if key in base:
                    merged[key] = deep_merge(base[key], over_val)
                else:
                    merged[key] = strip_tombstones(_copy(over_val))
            else:
                merged[key] = strip_tombstones(_copy(base[key]))
        return merged
    if isinstance(overlay, list):
        return strip_tombstones(_copy(overlay))
    return strip_tombstones(_copy(overlay))



def deep_merge_sidecar(base, overlay):
    """Merge two sidecar payloads without stripping tombstones.

    This is intentionally different from deep_merge(): deep_merge() is optimized for
    producing an effective runtime view (no tombstones). Sidecar persistence must
    preserve tombstones so explicit deletes survive subsequent writes.
    """
    if overlay is None:
        return _copy(base)
    if is_tombstone(overlay):
        return _copy(overlay)
    if isinstance(base, dict) and isinstance(overlay, dict):
        merged = _ordered_mapping()
        keys = []
        for src in (base, overlay):
            for key in src.keys():
                if key not in keys:
                    keys.append(key)
        for key in keys:
            if key == SIDECAR_META_KEY:
                continue
            if key in overlay:
                over_val = overlay[key]
                if is_tombstone(over_val):
                    merged[key] = _copy(over_val)
                    continue
                if key in base:
                    merged[key] = deep_merge_sidecar(base[key], over_val)
                else:
                    merged[key] = _copy(over_val)
            else:
                merged[key] = _copy(base[key])
        return merged
    if isinstance(overlay, list):
        return _copy(overlay)
    return _copy(overlay)

def _split_pointer(pointer):
    text = str(pointer or '').strip()
    if not text.startswith('$/'):
        return []
    parts = text[2:].split('/')
    return [p for p in parts if p]


def _join_pointer(parts):
    return '$/' + '/'.join(parts) if parts else '$'


def _is_pointer_prefix(pointer, candidate):
    base = _split_pointer(pointer)
    comp = _split_pointer(candidate)
    if len(comp) < len(base):
        return False
    idx = 0
    while idx < len(base):
        if base[idx] != '*' and base[idx] != comp[idx]:
            return False
        idx += 1
    return True


def pointer_owned(pointer, artifact):
    for owned in STATE_OWNED_POINTERS.get(str(artifact or ''), []):
        if _is_pointer_prefix(owned, pointer):
            return True
    return False


def sidecar_paths_from_baseline(config_path, crosswalk_path):
    cfg_abs = os.path.abspath(config_path) if config_path else ''
    cw_abs = os.path.abspath(crosswalk_path) if crosswalk_path else ''
    cfg_local = os.path.join(os.path.dirname(cfg_abs), CONFIG_LOCAL_FILENAME) if cfg_abs else ''
    cw_state = os.path.join(os.path.dirname(cw_abs), CROSSWALK_STATE_FILENAME) if cw_abs else ''
    return {
        'config_local_path': cfg_local,
        'crosswalk_state_path': cw_state,
    }


def _state_owned_pointers(payload, artifact):
    pointers = []
    try:
        for pointer, _value in walk_paths(payload if isinstance(payload, dict) else {}):
            if pointer_owned(pointer, artifact):
                pointers.append(pointer)
        try:
            pointers.sort()
        except Exception:
            pass
    except Exception:
        pass
    return pointers


def _walk_paths(payload, prefix='$'):
    if not isinstance(payload, dict):
        return
    for key, value in payload.items():
        if key == SIDECAR_META_KEY:
            continue
        pointer = prefix + '/' + str(key) if prefix != '$' else '$/' + str(key)
        yield pointer, value
        if isinstance(value, dict):
            for child in _walk_paths(value, pointer):
                yield child


def walk_paths(payload, prefix='$'):
    for item in _walk_paths(payload, prefix=prefix):
        yield item


def _set_pointer_value(root, pointer, value):
    parts = _split_pointer(pointer)
    if not parts:
        return
    cur = root
    for part in parts[:-1]:
        nxt = cur.get(part)
        if not isinstance(nxt, dict):
            nxt = _ordered_mapping()
            cur[part] = nxt
        cur = nxt
    cur[parts[-1]] = _copy(value)


def _delete_pointer(root, pointer):
    parts = _split_pointer(pointer)
    if not parts:
        return
    cur = root
    stack = []
    for part in parts[:-1]:
        nxt = cur.get(part)
        if not isinstance(nxt, dict):
            return
        stack.append((cur, part))
        cur = nxt
    cur.pop(parts[-1], None)
    while stack:
        parent, key = stack.pop()
        child = parent.get(key)
        if isinstance(child, dict) and not child:
            parent.pop(key, None)
        else:
            break


def _get_pointer_value(root, pointer):
    parts = _split_pointer(pointer)
    if not parts:
        return root
    cur = root
    for part in parts:
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur.get(part)
    return cur


def sanitize_baseline_payload(payload, artifact):
    base = strip_sidecar_meta(_copy(payload if isinstance(payload, dict) else {}))
    source = strip_sidecar_meta(_copy(payload if isinstance(payload, dict) else {}))
    dropped = []
    for pointer, _value in list(_walk_paths(base)):
        if pointer_owned(pointer, artifact):
            _delete_pointer(base, pointer)
            dropped.append(pointer)
    for keep_pointer in PRESERVE_EMPTY_BASELINE_POINTERS.get(str(artifact or ''), []):
        original_value = _get_pointer_value(source, keep_pointer)
        current_value = _get_pointer_value(base, keep_pointer)
        if isinstance(original_value, dict) and current_value is None:
            _set_pointer_value(base, keep_pointer, _ordered_mapping())
    return base, dropped


def extract_state_payload(payload, artifact):
    source = strip_sidecar_meta(_copy(payload if isinstance(payload, dict) else {}))
    out = _ordered_mapping()
    for pointer, value in _walk_paths(source):
        if pointer_owned(pointer, artifact):
            _set_pointer_value(out, pointer, value)
    return out


def merge_state_payload_preserving_existing(existing_payload, baseline_state_payload):
    """Return sidecar state with existing sidecar values winning over baseline.

    Baseline state extracted during migration/scrub is only a source of missing
    values. Existing sidecar values, including tombstones, are authoritative.
    """
    existing = strip_sidecar_meta(_copy(existing_payload if isinstance(existing_payload, dict) else {}))
    baseline = strip_sidecar_meta(_copy(baseline_state_payload if isinstance(baseline_state_payload, dict) else {}))
    return deep_merge_sidecar(baseline, existing)


def make_sidecar_document(payload, artifact, source_path=''):
    # Keep tombstones in sidecar documents; they are stripped only when
    # rendering an effective composed view.
    body = strip_sidecar_meta(_copy(payload if isinstance(payload, dict) else {}))
    doc = _ordered_mapping()
    doc[SIDECAR_META_KEY] = {
        'artifact': str(artifact or ''),
        'schema_version': SIDECAR_SCHEMA_VERSION,
        'source_path': str(source_path or ''),
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    for key, value in body.items():
        doc[key] = value
    return doc


def read_sidecar_file(path):
    if not path or not os.path.exists(path):
        return _ordered_mapping(), {
            'label': 'sidecar',
            'path': os.path.abspath(path) if path else '',
            'exists': False,
            'status': 'missing',
            'message': 'sidecar file not found',
            'schema_version': None,
        }
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle, object_pairs_hook=OrderedDict)
        if not isinstance(payload, dict):
            return _ordered_mapping(), {
                'label': 'sidecar',
                'path': os.path.abspath(path),
                'exists': True,
                'status': 'invalid_structure',
                'message': 'sidecar must contain an object',
                'schema_version': None,
            }
        meta = payload.get(SIDECAR_META_KEY) if isinstance(payload.get(SIDECAR_META_KEY), dict) else {}
        schema_version = meta.get('schema_version')
        if schema_version is None:
            schema_version = 0
        body = strip_sidecar_meta(payload)
        status = 'loaded'
        message = 'sidecar loaded successfully'
        ignored_for_composition = False
        if int(schema_version) != int(SIDECAR_SCHEMA_VERSION):
            status = 'schema_mismatch'
            message = 'sidecar schema version mismatch'
            ignored_for_composition = True
        return body, {
            'label': 'sidecar',
            'path': os.path.abspath(path),
            'exists': True,
            'status': status,
            'message': message,
            'schema_version': int(schema_version),
            'ignored_for_composition': ignored_for_composition,
        }
    except ValueError as exc:
        return _ordered_mapping(), {
            'label': 'sidecar',
            'path': os.path.abspath(path),
            'exists': True,
            'status': 'invalid_syntax',
            'message': str(exc),
            'schema_version': None,
        }
    except Exception as exc:
        return _ordered_mapping(), {
            'label': 'sidecar',
            'path': os.path.abspath(path),
            'exists': True,
            'status': 'unreadable',
            'message': str(exc),
            'schema_version': None,
        }


def build_effective_config_and_crosswalk(config, crosswalk, config_path, crosswalk_path):
    sidecar_paths = sidecar_paths_from_baseline(config_path, crosswalk_path)
    config_local, config_local_diag = read_sidecar_file(sidecar_paths.get('config_local_path'))
    crosswalk_state, crosswalk_state_diag = read_sidecar_file(sidecar_paths.get('crosswalk_state_path'))
    if str(config_local_diag.get('status')) == 'schema_mismatch':
        config_local = _ordered_mapping()
    if str(crosswalk_state_diag.get('status')) == 'schema_mismatch':
        crosswalk_state = _ordered_mapping()
    effective_config = deep_merge(config or {}, config_local or {})
    effective_crosswalk = deep_merge(crosswalk or {}, crosswalk_state or {})
    effective_config = strip_tombstones(effective_config)
    effective_crosswalk = strip_tombstones(effective_crosswalk)
    return effective_config, effective_crosswalk, {
        'paths': sidecar_paths,
        'config_local': config_local_diag,
        'crosswalk_state': crosswalk_state_diag,
    }


def _write_json(path, payload, artifact, writer, indent=4):
    from MediCafe.json_io import write_json_atomic
    return write_json_atomic(
        path,
        payload,
        artifact,
        writer,
        indent=indent,
        sort_keys=False,
        lock=True,
        ensure_ascii=False,
    )


def _write_sidecar_document(path, payload, artifact, writer):
    doc = make_sidecar_document(payload, artifact, source_path=path)
    return _write_json(path, doc, artifact, writer, indent=4)


def invalidate_loader_cache():
    try:
        from MediCafe import MediLink_ConfigLoader as loader
        loader.clear_config_cache()
    except Exception:
        pass


def write_crosswalk_state_optum(config_path, crosswalk_path, optum_payload, writer='sidecar_state'):
    payload = {
        'optum_payer_list': strip_tombstones(_copy(optum_payload if isinstance(optum_payload, dict) else {}))
    }
    ok, state_path = write_crosswalk_state_document(
        config_path,
        crosswalk_path,
        payload,
        writer=writer,
    )
    if ok:
        invalidate_loader_cache()
    return ok, state_path


def write_crosswalk_state_document(config_path, crosswalk_path, payload, writer='sidecar_state'):
    paths = sidecar_paths_from_baseline(config_path, crosswalk_path)
    state_path = paths.get('crosswalk_state_path')
    existing, _diag = read_sidecar_file(state_path)
    base = existing if isinstance(existing, dict) else _ordered_mapping()
    overlay = payload if isinstance(payload, dict) else {}
    merged = deep_merge_sidecar(base, overlay)
    ok = _write_sidecar_document(state_path, merged, 'crosswalk_state', writer)
    if ok:
        invalidate_loader_cache()
    return ok, state_path


def write_config_local_update(config_path, key_path, value, writer='config_local_writer'):
    paths = sidecar_paths_from_baseline(config_path, '')
    local_path = paths.get('config_local_path')
    existing, _diag = read_sidecar_file(local_path)
    current = existing if isinstance(existing, dict) else _ordered_mapping()
    _set_pointer_value(current, key_path, value)
    ok = _write_sidecar_document(local_path, current, 'config_local', writer)
    if ok:
        invalidate_loader_cache()
    return ok, local_path


def write_config_local_document(config_path, payload, writer='config_local_writer'):
    paths = sidecar_paths_from_baseline(config_path, '')
    local_path = paths.get('config_local_path')
    existing, _diag = read_sidecar_file(local_path)
    base = existing if isinstance(existing, dict) else _ordered_mapping()
    overlay = payload if isinstance(payload, dict) else {}
    merged = deep_merge_sidecar(base, overlay)
    ok = _write_sidecar_document(local_path, merged, 'config_local', writer)
    if ok:
        invalidate_loader_cache()
    return ok, local_path


def load_effective_config(config_path, crosswalk_path=''):
    try:
        from MediCafe import MediLink_ConfigLoader as loader
        cfg, _ = loader.load_configuration(config_path=config_path, crosswalk_path=crosswalk_path or None)
        return cfg
    except Exception:
        try:
            with open(config_path, 'r', encoding='utf-8') as handle:
                config = json.load(handle, object_pairs_hook=OrderedDict)
        except Exception:
            return {}
        crosswalk = {}
        eff, _cw, _meta = build_effective_config_and_crosswalk(config, crosswalk, config_path, crosswalk_path or '')
        return eff if isinstance(eff, dict) else {}


def _timestamped_backup_path(path):
    stamp = time.strftime('%Y%m%d_%H%M%S')
    return '{}.sidecar-bootstrap.{}'.format(path, stamp)


def _timestamped_latest_backup_paths(path, stamp):
    return '{}.backup.{}'.format(path, stamp), '{}.backup'.format(path)


def _copy_file(src, dst):
    with open(src, 'rb') as in_f:
        data = in_f.read()
    with open(dst, 'wb') as out_f:
        out_f.write(data)


def _prune_timestamped_backups_for_source(path, infix, keep_count=SIDECAR_BACKUP_RETENTION_COUNT):
    """Keep only the newest timestamped backups for one source/infix family."""
    pruned = []
    if not path:
        return pruned
    try:
        directory = os.path.dirname(os.path.abspath(path)) or '.'
        basename = os.path.basename(path)
        prefix = basename + infix
        candidates = []
        for name in os.listdir(directory):
            if not name.startswith(prefix):
                continue
            full_path = os.path.join(directory, name)
            if not os.path.isfile(full_path):
                continue
            try:
                mtime = os.path.getmtime(full_path)
            except Exception:
                mtime = 0
            candidates.append((mtime, name, full_path))
        if len(candidates) <= int(keep_count):
            return pruned
        candidates.sort()
        remove_count = len(candidates) - int(keep_count)
        for _mtime, _name, full_path in candidates[:remove_count]:
            try:
                os.remove(full_path)
                pruned.append(os.path.abspath(full_path))
            except Exception:
                pass
    except Exception:
        pass
    return pruned


def _read_json_object(path):
    with open(path, 'r', encoding='utf-8') as handle:
        payload = json.load(handle, object_pairs_hook=OrderedDict)
    if not isinstance(payload, dict):
        return _ordered_mapping()
    return payload


def _backup_config_related_files(paths, pruned_backups=None):
    stamp = time.strftime('%Y%m%d_%H%M%S')
    backups = []
    for path in paths or []:
        if not path or not os.path.exists(path):
            continue
        dated_path, latest_path = _timestamped_latest_backup_paths(path, stamp)
        _copy_file(path, dated_path)
        _copy_file(path, latest_path)
        backups.append({
            'source': os.path.abspath(path),
            'dated_backup': os.path.abspath(dated_path),
            'latest_backup': os.path.abspath(latest_path),
        })
        pruned = _prune_timestamped_backups_for_source(path, '.backup.')
        if pruned_backups is not None:
            pruned_backups.extend(pruned)
    return backups


def _json_file_equivalent(path, payload):
    if not path or not os.path.exists(path):
        return False
    try:
        current = _read_json_object(path)
    except Exception:
        return False
    return _json_equivalent(current, payload)


def _sidecar_file_body_equivalent(path, payload):
    if not path or not os.path.exists(path):
        return False
    try:
        current, diag = read_sidecar_file(path)
    except Exception:
        return False
    if str(diag.get('status') or '') != 'loaded':
        return False
    return _json_equivalent(current, strip_sidecar_meta(payload if isinstance(payload, dict) else {}))


def _append_backup_target(targets, path, should_write):
    if should_write and path and os.path.exists(path) and path not in targets:
        targets.append(path)


def _restore_backups(best_effort_backups):
    restored = []
    for item in best_effort_backups or []:
        try:
            src = item.get('dated_backup')
            dst = item.get('source')
        except Exception:
            src = ''
            dst = ''
        if not src or not dst or not os.path.exists(src):
            continue
        try:
            _copy_file(src, dst)
            restored.append(dst)
        except Exception:
            pass
    return restored


def _json_equivalent(left, right):
    try:
        return json.dumps(left, sort_keys=True, ensure_ascii=True) == json.dumps(right, sort_keys=True, ensure_ascii=True)
    except Exception:
        return left == right


def auto_scrub_baselines_if_safe(config_path, crosswalk_path, report_path=''):
    """One-shot automatic baseline scrub when valid sidecars already exist.

    This is intentionally conservative: it runs only when sidecars needed for
    the stale baseline paths are present and valid, verifies effective config
    and crosswalk views are preserved, and leaves both dated and latest .backup
    files for every touched config-related artifact.
    """
    config_abs = os.path.abspath(config_path)
    crosswalk_abs = os.path.abspath(crosswalk_path)
    sidecar_paths = sidecar_paths_from_baseline(config_abs, crosswalk_abs)
    report = {
        'schema_version': 1,
        'status': 'skipped',
        'reason': '',
        'applied': False,
        'config_path': config_abs,
        'crosswalk_path': crosswalk_abs,
        'sidecars': sidecar_paths,
        'backups': [],
        'pruned_backups': [],
        'restored_from_backups': [],
        'moved': {'config': [], 'crosswalk': []},
        'verified': False,
    }
    try:
        disabled = str(os.environ.get('MEDICAFE_JSON_SIDECAR_AUTO_SCRUB', '') or '').strip().lower()
        if disabled in ('0', 'false', 'no', 'off'):
            report['reason'] = 'disabled_by_env'
            return report

        config_payload = _read_json_object(config_abs)
        crosswalk_payload = _read_json_object(crosswalk_abs)
        config_local, config_local_diag = read_sidecar_file(sidecar_paths.get('config_local_path'))
        crosswalk_state, crosswalk_state_diag = read_sidecar_file(sidecar_paths.get('crosswalk_state_path'))

        config_state = extract_state_payload(config_payload, 'config')
        crosswalk_state_from_baseline = extract_state_payload(crosswalk_payload, 'crosswalk')
        config_baseline, config_dropped = sanitize_baseline_payload(config_payload, 'config')
        crosswalk_baseline, crosswalk_dropped = sanitize_baseline_payload(crosswalk_payload, 'crosswalk')

        config_missing_required_root = not isinstance(config_payload.get('MediLink_Config'), dict)
        if config_missing_required_root:
            config_baseline['MediLink_Config'] = _ordered_mapping()

        config_needs_scrub = bool(config_dropped) or config_missing_required_root
        crosswalk_needs_scrub = bool(crosswalk_dropped)
        report['moved']['config'] = sorted(config_dropped)
        report['moved']['crosswalk'] = sorted(crosswalk_dropped)
        report['config_missing_required_root'] = bool(config_missing_required_root)

        if not config_needs_scrub and not crosswalk_needs_scrub:
            report['reason'] = 'baseline_already_clean'
            return report
        if config_needs_scrub and str(config_local_diag.get('status')) != 'loaded':
            report['reason'] = 'config_local_not_loaded'
            report['config_local_status'] = str(config_local_diag.get('status') or '')
            return report
        if crosswalk_needs_scrub and str(crosswalk_state_diag.get('status')) != 'loaded':
            report['reason'] = 'crosswalk_state_not_loaded'
            report['crosswalk_state_status'] = str(crosswalk_state_diag.get('status') or '')
            return report

        before_config, before_crosswalk, _before_diag = build_effective_config_and_crosswalk(
            config_payload,
            crosswalk_payload,
            config_abs,
            crosswalk_abs,
        )
        merged_config_state = merge_state_payload_preserving_existing(config_local, config_state)
        merged_crosswalk_state = merge_state_payload_preserving_existing(
            crosswalk_state,
            crosswalk_state_from_baseline,
        )

        config_baseline_write = bool(config_needs_scrub and not _json_file_equivalent(config_abs, config_baseline))
        crosswalk_baseline_write = bool(crosswalk_needs_scrub and not _json_file_equivalent(crosswalk_abs, crosswalk_baseline))
        config_sidecar_write = bool(
            config_needs_scrub
            and not _sidecar_file_body_equivalent(sidecar_paths.get('config_local_path'), merged_config_state)
        )
        crosswalk_sidecar_write = bool(
            crosswalk_needs_scrub
            and not _sidecar_file_body_equivalent(sidecar_paths.get('crosswalk_state_path'), merged_crosswalk_state)
        )
        report['planned_writes'] = {
            'config': config_baseline_write,
            'crosswalk': crosswalk_baseline_write,
            'config_local': config_sidecar_write,
            'crosswalk_state': crosswalk_sidecar_write,
        }

        backup_paths = []
        _append_backup_target(backup_paths, config_abs, config_baseline_write)
        _append_backup_target(backup_paths, crosswalk_abs, crosswalk_baseline_write)
        _append_backup_target(backup_paths, sidecar_paths.get('config_local_path'), config_sidecar_write)
        _append_backup_target(backup_paths, sidecar_paths.get('crosswalk_state_path'), crosswalk_sidecar_write)
        report['backups'] = _backup_config_related_files(backup_paths, report.get('pruned_backups'))

        ok = True
        if config_baseline_write:
            ok = _write_json(config_abs, config_baseline, 'config', 'auto_sidecar_scrub_baseline', indent=4) and ok
        if config_sidecar_write:
            ok = _write_sidecar_document(
                sidecar_paths.get('config_local_path'),
                merged_config_state,
                'config_local',
                'auto_sidecar_scrub_sidecar',
            ) and ok
        if crosswalk_baseline_write:
            ok = _write_json(crosswalk_abs, crosswalk_baseline, 'crosswalk', 'auto_sidecar_scrub_baseline', indent=4) and ok
        if crosswalk_sidecar_write:
            ok = _write_sidecar_document(
                sidecar_paths.get('crosswalk_state_path'),
                merged_crosswalk_state,
                'crosswalk_state',
                'auto_sidecar_scrub_sidecar',
            ) and ok
        if not ok:
            report['status'] = 'failed'
            report['reason'] = 'write_failed'
            report['restored_from_backups'] = _restore_backups(report.get('backups'))
            return report

        after_config_payload = _read_json_object(config_abs)
        after_crosswalk_payload = _read_json_object(crosswalk_abs)
        after_config, after_crosswalk, _after_diag = build_effective_config_and_crosswalk(
            after_config_payload,
            after_crosswalk_payload,
            config_abs,
            crosswalk_abs,
        )
        remaining_config = _state_owned_pointers(after_config_payload, 'config')
        remaining_crosswalk = _state_owned_pointers(after_crosswalk_payload, 'crosswalk')
        if remaining_config or remaining_crosswalk:
            report['status'] = 'failed'
            report['reason'] = 'state_owned_still_in_baseline'
            report['remaining'] = {'config': remaining_config, 'crosswalk': remaining_crosswalk}
            report['restored_from_backups'] = _restore_backups(report.get('backups'))
            return report
        if config_needs_scrub and not isinstance(after_config_payload.get('MediLink_Config'), dict):
            report['status'] = 'failed'
            report['reason'] = 'config_required_root_missing_after_scrub'
            report['restored_from_backups'] = _restore_backups(report.get('backups'))
            return report
        if not _json_equivalent(before_config, after_config) or not _json_equivalent(before_crosswalk, after_crosswalk):
            report['status'] = 'failed'
            report['reason'] = 'effective_view_changed'
            report['restored_from_backups'] = _restore_backups(report.get('backups'))
            return report

        report['status'] = 'applied'
        report['reason'] = 'scrubbed_and_verified'
        report['applied'] = True
        report['verified'] = True
        invalidate_loader_cache()
        return report
    except Exception as exc:
        report['status'] = 'failed'
        report['reason'] = 'exception'
        report['error'] = str(exc)
        report['restored_from_backups'] = _restore_backups(report.get('backups'))
        return report
    finally:
        if report_path:
            try:
                with open(report_path, 'w', encoding='utf-8') as handle:
                    json.dump(report, handle, ensure_ascii=True, indent=2)
            except Exception:
                pass


def bootstrap_sidecars(config_path, crosswalk_path, apply=False, report_path=''):
    config_abs = os.path.abspath(config_path)
    crosswalk_abs = os.path.abspath(crosswalk_path)
    report = {
        'config_path': config_abs,
        'crosswalk_path': crosswalk_abs,
        'apply': bool(apply),
        'warnings': [],
        'moved': {'config': [], 'crosswalk': []},
        'unchanged': [],
        'backups': [],
        'pruned_backups': [],
        'planned_writes': {},
        'sidecars': sidecar_paths_from_baseline(config_abs, crosswalk_abs),
    }
    try:
        with open(config_abs, 'r', encoding='utf-8') as handle:
            config_payload = json.load(handle, object_pairs_hook=OrderedDict)
    except Exception as exc:
        report['warnings'].append('config read failed: {}'.format(exc))
        config_payload = _ordered_mapping()
    try:
        with open(crosswalk_abs, 'r', encoding='utf-8') as handle:
            crosswalk_payload = json.load(handle, object_pairs_hook=OrderedDict)
    except Exception as exc:
        report['warnings'].append('crosswalk read failed: {}'.format(exc))
        crosswalk_payload = _ordered_mapping()

    config_state = extract_state_payload(config_payload, 'config')
    crosswalk_state = extract_state_payload(crosswalk_payload, 'crosswalk')
    config_baseline, config_dropped = sanitize_baseline_payload(config_payload, 'config')
    crosswalk_baseline, crosswalk_dropped = sanitize_baseline_payload(crosswalk_payload, 'crosswalk')
    sidecar_paths = report['sidecars']
    existing_config_state, config_sidecar_diag = read_sidecar_file(sidecar_paths.get('config_local_path'))
    existing_crosswalk_state, crosswalk_sidecar_diag = read_sidecar_file(sidecar_paths.get('crosswalk_state_path'))
    if str(config_sidecar_diag.get('status')) == 'schema_mismatch':
        existing_config_state = _ordered_mapping()
    if str(crosswalk_sidecar_diag.get('status')) == 'schema_mismatch':
        existing_crosswalk_state = _ordered_mapping()
    merged_config_state = merge_state_payload_preserving_existing(existing_config_state, config_state)
    merged_crosswalk_state = merge_state_payload_preserving_existing(existing_crosswalk_state, crosswalk_state)

    report['moved']['config'] = sorted(config_dropped)
    report['moved']['crosswalk'] = sorted(crosswalk_dropped)
    report['existing_sidecars'] = {
        'config_local': {
            'exists': bool(config_sidecar_diag.get('exists')),
            'status': str(config_sidecar_diag.get('status') or ''),
        },
        'crosswalk_state': {
            'exists': bool(crosswalk_sidecar_diag.get('exists')),
            'status': str(crosswalk_sidecar_diag.get('status') or ''),
        },
    }
    report['unchanged'] = [
        'config_baseline_unchanged={}'.format(config_baseline == config_payload),
        'crosswalk_baseline_unchanged={}'.format(crosswalk_baseline == crosswalk_payload),
    ]
    config_write = not _json_equivalent(config_payload, config_baseline)
    crosswalk_write = not _json_equivalent(crosswalk_payload, crosswalk_baseline)
    config_sidecar_write = not _sidecar_file_body_equivalent(
        sidecar_paths.get('config_local_path'),
        merged_config_state,
    )
    crosswalk_sidecar_write = not _sidecar_file_body_equivalent(
        sidecar_paths.get('crosswalk_state_path'),
        merged_crosswalk_state,
    )
    report['planned_writes'] = {
        'config': bool(config_write),
        'crosswalk': bool(crosswalk_write),
        'config_local': bool(config_sidecar_write),
        'crosswalk_state': bool(crosswalk_sidecar_write),
    }

    if not apply:
        if report_path:
            with open(report_path, 'w', encoding='utf-8') as handle:
                json.dump(report, handle, ensure_ascii=True, indent=2)
        return report

    backup_targets = []
    _append_backup_target(backup_targets, config_abs, config_write)
    _append_backup_target(backup_targets, crosswalk_abs, crosswalk_write)
    _append_backup_target(backup_targets, sidecar_paths.get('config_local_path'), config_sidecar_write)
    _append_backup_target(backup_targets, sidecar_paths.get('crosswalk_state_path'), crosswalk_sidecar_write)
    for path in backup_targets:
        backup_path = _timestamped_backup_path(path)
        _copy_file(path, backup_path)
        report['backups'].append(backup_path)
        report['pruned_backups'].extend(
            _prune_timestamped_backups_for_source(path, '.sidecar-bootstrap.')
        )

    if config_write:
        _write_json(config_abs, config_baseline, 'config', 'bootstrap_baseline', indent=4)
    if crosswalk_write:
        _write_json(crosswalk_abs, crosswalk_baseline, 'crosswalk', 'bootstrap_baseline', indent=4)
    if config_sidecar_write:
        _write_sidecar_document(sidecar_paths.get('config_local_path'), merged_config_state, 'config_local', 'bootstrap_sidecar')
    if crosswalk_sidecar_write:
        _write_sidecar_document(sidecar_paths.get('crosswalk_state_path'), merged_crosswalk_state, 'crosswalk_state', 'bootstrap_sidecar')
    if report_path:
        with open(report_path, 'w', encoding='utf-8') as handle:
            json.dump(report, handle, ensure_ascii=True, indent=2)
    invalidate_loader_cache()
    return report


def main(argv=None):
    argv = list(argv if argv is not None else sys.argv[1:])
    args = {
        'config': '',
        'crosswalk': '',
        'dry_run': False,
        'apply': False,
        'report': '',
    }
    idx = 0
    while idx < len(argv):
        token = argv[idx]
        if token == '--config' and idx + 1 < len(argv):
            args['config'] = argv[idx + 1]
            idx += 2
            continue
        if token == '--crosswalk' and idx + 1 < len(argv):
            args['crosswalk'] = argv[idx + 1]
            idx += 2
            continue
        if token == '--report' and idx + 1 < len(argv):
            args['report'] = argv[idx + 1]
            idx += 2
            continue
        if token == '--dry-run':
            args['dry_run'] = True
            idx += 1
            continue
        if token == '--apply':
            args['apply'] = True
            idx += 1
            continue
        print('Unknown argument: {}'.format(token))
        return 2
    if not args['config'] or not args['crosswalk']:
        print('Usage: python -m MediCafe.json_sidecar --config <config.json> --crosswalk <crosswalk.json> [--dry-run|--apply] [--report path]')
        return 2
    if args['dry_run'] and args['apply']:
        print('Choose either --dry-run or --apply, not both.')
        return 2
    report = bootstrap_sidecars(
        args['config'],
        args['crosswalk'],
        apply=bool(args['apply']),
        report_path=args['report'],
    )
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())

