# -*- coding: utf-8 -*-
"""
Centralized JSON and sidecar file IO for Python 3.4.4 / Windows XP.

Atomic writes, optional sibling lock files, structured JSON_IO_EVENT logging,
and integration with config_write_telemetry on failures.

Append helpers accept record_failure=False so callers such as config_write_telemetry
can avoid record_json_write_failure -> append_event recursion when the JSONL sink fails.

collect_json_io_preflight_failures() is read-only: it does not create directories or
leave probe files; optional dirs are checked only when they already exist.
"""
from __future__ import print_function

import json
import logging
import os
import sys
import time
import errno
import random
from collections import OrderedDict

_LOCK_MAX_WAIT_SEC = 8.0
_LOCK_STALE_SEC = 600.0
_LOCK_BACKOFF_START = 0.03
_PROMOTE_RETRIES = 8
_PROMOTE_BACKOFF = 0.05

_WIN_ERR_ACCESS = 5
_WIN_ERR_SHARING = 32
_WIN_ERR_LOCK = 33

try:
    from MediCafe.logging_config import PERFORMANCE_LOGGING, DEBUG
except Exception:
    PERFORMANCE_LOGGING = False
    DEBUG = False

try:
    from MediCafe.log_policy import should_emit_detailed_payload
except Exception:
    def should_emit_detailed_payload(kind, level='INFO', payload=None):
        return True


def _now_ms():
    return int(time.time() * 1000)


def _json_io_log_level(phase):
    phase_s = str(phase or '').lower()
    if 'failed' in phase_s or phase_s in ('lock_failed',):
        return 'ERROR'
    if phase_s in ('promote_retry', 'lock_wait') or 'retry' in phase_s:
        return 'WARNING'
    if phase_s in (
        'success',
        'start',
        'lock_acquired',
        'lock_released',
        'promote_success',
        'append_jsonl',
        'append_text',
    ):
        return 'DEBUG'
    return 'INFO'


def _json_io_verbose():
    try:
        env = str(os.environ.get('MEDICAFE_VERBOSE_LOGGING', '') or '').strip().lower()
    except Exception:
        env = ''
    env_perf = str(os.environ.get('MEDICAFE_PERFORMANCE_LOGGING', '') or '').strip().lower() in ('1', 'true', 'yes', 'on')
    return bool(DEBUG or PERFORMANCE_LOGGING or env in ('1', 'true', 'yes', 'on') or env_perf)


def _json_io_console_enabled():
    """Explicit opt-in for raw JSON IO payloads on the XP terminal."""
    try:
        raw = str(os.environ.get('MEDICAFE_JSON_IO_CONSOLE', '') or '').strip().lower()
    except Exception:
        raw = ''
    return raw in ('1', 'true', 'yes', 'on')


def _emit_json_io_event(payload):
    """Structured JSON IO event for logs/telemetry, with console output opt-in only."""
    if not isinstance(payload, dict):
        return
    try:
        line = json.dumps(payload, ensure_ascii=True, default=str)
    except Exception:
        return
    level_name = _json_io_log_level(payload.get('phase'))
    phase = str(payload.get('phase') or '').strip().lower()
    emit_detail = should_emit_detailed_payload('json_io_event', level_name, payload)
    if not emit_detail and phase in (
        'start',
        'lock_acquired',
        'lock_released',
        'lock_wait',
        'promote_success',
        'promote_retry',
        'append_jsonl',
        'append_text',
    ):
        return
    message = 'JSON_IO_EVENT {0}'.format(line)
    if _json_io_console_enabled() and (level_name in ('WARNING', 'ERROR') or _json_io_verbose()):
        try:
            sys.stderr.write(message + '\n')
            try:
                sys.stderr.flush()
            except Exception:
                pass
        except Exception:
            pass
    try:
        level_value = getattr(logging, level_name, logging.INFO)
        root_logger = logging.getLogger()
        if getattr(root_logger, 'handlers', None):
            root_logger.log(level_value, message)
            return
    except Exception:
        pass
    try:
        from MediCafe.MediLink_ConfigLoader import log as mc_log

        mc_log(message, level=_json_io_log_level(payload.get('phase')), console_output=False)
    except Exception:
        pass



def _emit_json_io_diagnostic(payload, level='WARNING'):
    """Structured path/drive diagnostics for JSON IO failures."""
    if not isinstance(payload, dict):
        return
    try:
        line = json.dumps(payload, ensure_ascii=True, default=str)
    except Exception:
        return
    message = 'JSON_IO_DIAGNOSTIC {0}'.format(line)
    if _json_io_console_enabled():
        try:
            sys.stderr.write(message + '\n')
            try:
                sys.stderr.flush()
            except Exception:
                pass
        except Exception:
            pass
    try:
        root_logger = logging.getLogger()
        if getattr(root_logger, 'handlers', None):
            root_logger.log(getattr(logging, str(level or 'WARNING').upper(), logging.WARNING), message)
            return
    except Exception:
        pass
    try:
        from MediCafe.MediLink_ConfigLoader import log as mc_log

        mc_log(message, level=str(level or 'WARNING').upper(), console_output=False)
    except Exception:
        pass


def _oct_mode(mode_value):
    try:
        return oct(int(mode_value) & 0o7777)
    except Exception:
        return ''


def _drive_root_for_path(path):
    try:
        drive, _ = os.path.splitdrive(os.path.abspath(path))
        if drive:
            return drive + os.sep
    except Exception:
        pass
    return ''


def _drive_type_label(code):
    labels = {
        0: 'unknown',
        1: 'no_root_dir',
        2: 'removable',
        3: 'fixed',
        4: 'remote',
        5: 'cdrom',
        6: 'ramdisk',
    }
    return labels.get(code, 'type_{0}'.format(code))


def _windows_file_attributes(path):
    if os.name != 'nt' or not path:
        return {}
    try:
        import ctypes

        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
        if attrs == 0xFFFFFFFF:
            return {'error': int(ctypes.GetLastError())}
        return {
            'raw': int(attrs),
            'raw_hex': hex(int(attrs)),
            'readonly': bool(attrs & 0x1),
            'hidden': bool(attrs & 0x2),
            'system': bool(attrs & 0x4),
            'directory': bool(attrs & 0x10),
            'archive': bool(attrs & 0x20),
            'reparse_point': bool(attrs & 0x400),
            'compressed': bool(attrs & 0x800),
            'offline': bool(attrs & 0x1000),
            'not_content_indexed': bool(attrs & 0x2000),
            'encrypted': bool(attrs & 0x4000),
        }
    except Exception as exc:
        return {'error': str(exc)}



def _path_readonly(path):
    if not path:
        return None
    try:
        if not os.path.exists(path):
            return None
    except Exception:
        return None
    try:
        attrs = _windows_file_attributes(path)
        if isinstance(attrs, dict) and attrs.get('readonly') is not None:
            return bool(attrs.get('readonly'))
    except Exception:
        pass
    try:
        return not os.access(path, os.W_OK)
    except Exception:
        return None


def _readonly_summary(path):
    readonly = _path_readonly(path)
    if readonly is True:
        return 'read-only or not writable'
    if readonly is False:
        return 'writable'
    return 'unknown'
def _windows_drive_diagnostics(path):
    if os.name != 'nt':
        return {}
    root = _drive_root_for_path(path)
    if not root:
        return {}
    out = {'root': root}
    try:
        import ctypes

        k = ctypes.windll.kernel32
        dtype = int(k.GetDriveTypeW(root))
        out['drive_type'] = dtype
        out['drive_type_label'] = _drive_type_label(dtype)
        free_avail = ctypes.c_ulonglong(0)
        total = ctypes.c_ulonglong(0)
        total_free = ctypes.c_ulonglong(0)
        if k.GetDiskFreeSpaceExW(root, ctypes.byref(free_avail), ctypes.byref(total), ctypes.byref(total_free)):
            out['free_bytes_available'] = int(free_avail.value)
            out['total_bytes'] = int(total.value)
            out['total_free_bytes'] = int(total_free.value)
        else:
            out['free_space_error'] = int(ctypes.GetLastError())
        volume_name = ctypes.create_unicode_buffer(260)
        fs_name = ctypes.create_unicode_buffer(260)
        serial = ctypes.c_ulong(0)
        max_component = ctypes.c_ulong(0)
        fs_flags = ctypes.c_ulong(0)
        if k.GetVolumeInformationW(root, volume_name, 260, ctypes.byref(serial), ctypes.byref(max_component), ctypes.byref(fs_flags), fs_name, 260):
            out['volume_name'] = volume_name.value
            out['file_system'] = fs_name.value
            out['volume_serial'] = int(serial.value)
            out['max_component_length'] = int(max_component.value)
            out['fs_flags'] = int(fs_flags.value)
        else:
            out['volume_info_error'] = int(ctypes.GetLastError())
    except Exception as exc:
        out['error'] = str(exc)
    return out


def _stat_snapshot(path):
    try:
        st = os.stat(path)
        return {
            'mode': _oct_mode(st.st_mode),
            'size': int(st.st_size),
            'mtime': float(st.st_mtime),
        }
    except Exception as exc:
        return {'error': str(exc)}


def collect_path_diagnostics(path):
    """Return non-mutating diagnostics for a file or directory path."""
    out = {'path': str(path or '')}
    try:
        abs_path = os.path.abspath(path) if path else ''
    except Exception:
        abs_path = str(path or '')
    parent = os.path.dirname(abs_path) if abs_path else ''
    out.update({
        'absolute_path': abs_path,
        'path_basename': os.path.basename(abs_path) if abs_path else '',
        'parent': parent,
        'drive_root': _drive_root_for_path(abs_path) if abs_path else '',
        'cwd': os.getcwd(),
    })
    for key, p in (('target', abs_path), ('parent', parent)):
        if not p:
            continue
        try:
            out[key + '_exists'] = os.path.exists(p)
            out[key + '_isfile'] = os.path.isfile(p)
            out[key + '_isdir'] = os.path.isdir(p)
            out[key + '_access_r'] = os.access(p, os.R_OK)
            out[key + '_access_w'] = os.access(p, os.W_OK)
            out[key + '_stat'] = _stat_snapshot(p) if os.path.exists(p) else {}
            out[key + '_attributes'] = _windows_file_attributes(p)
            out[key + '_readonly'] = _path_readonly(p)
            out[key + '_readonly_summary'] = _readonly_summary(p)
        except Exception as exc:
            out[key + '_error'] = str(exc)
    try:
        lock_path = abs_path + '.lock' if abs_path else ''
        out['lock_path'] = lock_path
        out['lock_exists'] = os.path.exists(lock_path) if lock_path else False
        if out.get('lock_exists'):
            out['lock_stat'] = _stat_snapshot(lock_path)
            out['lock_owner_pid'] = _lock_owner_pid(lock_path)
            try:
                out['lock_age_sec'] = round(time.time() - os.path.getmtime(lock_path), 3)
            except Exception:
                pass
    except Exception as exc:
        out['lock_error'] = str(exc)
    try:
        if parent and os.path.isdir(parent):
            base = os.path.basename(abs_path)
            temps = []
            for name in os.listdir(parent):
                if name.startswith(base + '.tmp') or name.startswith(base + '.rotate.tmp'):
                    temps.append(name)
            out['temp_sidecar_count'] = len(temps)
            out['temp_sidecar_examples'] = temps[:5]
    except Exception as exc:
        out['sidecar_error'] = str(exc)
    out['drive'] = _windows_drive_diagnostics(abs_path or parent)
    return out


def _emit_failure_diagnostics(path, artifact, writer, phase, exc=None, extra=None):
    payload = {
        'phase': phase,
        'artifact': artifact,
        'writer': writer,
        'pid': os.getpid(),
        'path_diagnostics': collect_path_diagnostics(path),
    }
    if exc is not None:
        payload['errno'] = getattr(exc, 'errno', None)
        payload['winerror'] = getattr(exc, 'winerror', None)
        payload['exception'] = str(exc)
        payload['exception_type'] = type(exc).__name__
    if extra:
        payload['extra'] = extra
    _emit_json_io_diagnostic(payload, level='ERROR')


def record_json_io_read_failure(path, artifact, writer, phase, exc=None, extra=None):
    """Public helper for read-side preflight/config diagnostics."""
    _emit_failure_diagnostics(path, artifact, writer, phase, exc=exc, extra=extra)

def _record_failure(writer, path, phase, exc=None, errno_override=None, winerror_override=None, extra=None):
    try:
        from MediCafe.config_write_telemetry import record_json_write_failure

        kwargs = {}
        if exc is not None:
            kwargs['exc'] = exc
        if errno_override is not None:
            kwargs['errno'] = errno_override
        if winerror_override is not None:
            kwargs['winerror'] = winerror_override
        if extra:
            kwargs['extra_stderr'] = str(extra)
        record_json_write_failure(writer, path, phase, **kwargs)
    except Exception:
        pass


def _exc_meta(exc):
    return (
        getattr(exc, 'errno', None),
        getattr(exc, 'winerror', None),
        str(exc) if exc is not None else '',
    )


def _is_promote_retry_exc(exc):
    if exc is None:
        return False
    en = getattr(exc, 'errno', None)
    we = getattr(exc, 'winerror', None)
    if en in (errno.EACCES, errno.EPERM, 13):
        return True
    if we in (_WIN_ERR_ACCESS, _WIN_ERR_SHARING, _WIN_ERR_LOCK):
        return True
    return False


def _pid_alive(pid):
    if pid is None:
        return False
    try:
        pid_i = int(pid)
    except (ValueError, TypeError):
        return False
    if pid_i <= 0:
        return False
    if os.name == 'nt':
        from MediCafe.win_pid_probe import windows_process_is_alive_or_unknown
        return windows_process_is_alive_or_unknown(pid_i)
    try:
        os.kill(pid_i, 0)
    except OSError as e:
        if getattr(e, 'errno', None) == errno.ESRCH:
            return False
        return True
    except Exception:
        return False
    return True


def _read_lock_record(lock_path):
    try:
        with open(lock_path, 'r') as handle:
            raw = handle.read()
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return None


def _lock_is_stale(lock_path):
    """
    Decide whether an existing sibling lock may be deleted so the caller can retry O_EXCL create.

    A **fresh lock file whose recorded owner PID is not alive** (crash before release) must be
    treated as stale immediately. Older code gated all young locks behind ``_LOCK_STALE_SEC``, which
    falsely surfaced errno 17 / lock_acquire failures during normal contention recovery.
    """
    try:
        file_age = time.time() - os.path.getmtime(lock_path)
    except Exception:
        return True
    rec = _read_lock_record(lock_path)
    created_age = None
    if rec and rec.get('created_at') is not None:
        try:
            created_age = time.time() - float(rec['created_at'])
        except Exception:
            created_age = None
    eff_age = max(file_age, created_age if created_age is not None else 0.0)
    # Structured lock + known holder: liveness dominates age (supports stale-preflight-style reclaim).
    if rec:
        holder = rec.get('pid')
        if holder is not None:
            try:
                hi = int(holder)
            except (ValueError, TypeError):
                hi = None
            if hi is not None:
                if _pid_alive(hi):
                    return False
                return True
    try:
        with open(lock_path, 'r') as handle:
            snippet = handle.read(64)
        for token in snippet.replace(',', ' ').split():
            try:
                holder = int(token)
                if _pid_alive(holder):
                    return False
                return True
            except Exception:
                continue
    except Exception:
        pass
    if eff_age <= _LOCK_STALE_SEC:
        return False
    return True


def _lock_owner_pid(lock_path):
    rec = _read_lock_record(lock_path)
    if rec and rec.get('pid') is not None:
        try:
            return int(rec['pid'])
        except Exception:
            return None
    return None


def _lock_create_error_is_contention(exc, lock_path):
    en = getattr(exc, 'errno', None)
    we = getattr(exc, 'winerror', None)
    if en in (errno.EEXIST, 17, 183) or we == 183:
        return True
    if en == errno.EACCES or we in (_WIN_ERR_ACCESS, _WIN_ERR_SHARING, _WIN_ERR_LOCK):
        try:
            return os.path.exists(lock_path)
        except Exception:
            return False
    return False


def _acquire_lock(target_path, artifact, writer):
    lock_path = target_path + '.lock'
    deadline = time.time() + _LOCK_MAX_WAIT_SEC
    started_at = time.time()
    attempt = 0
    basename = os.path.basename(target_path)
    payload = json.dumps(
        {
            'pid': os.getpid(),
            'created_at': time.time(),
            'writer': writer,
            'artifact': artifact,
            'target_basename': basename,
        },
        ensure_ascii=True,
    )
    while True:
        attempt += 1
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, payload.encode('ascii', 'ignore'))
            finally:
                os.close(fd)
            _emit_json_io_event(
                {
                    'phase': 'lock_acquired',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'pid': os.getpid(),
                    'attempt': attempt,
                    'elapsed_ms': 0,
                }
            )
            return lock_path, None
        except (OSError, IOError) as e:
            en = getattr(e, 'errno', None)
            if not _lock_create_error_is_contention(e, lock_path):
                return None, e
            owner = _lock_owner_pid(lock_path)
            _emit_json_io_event(
                {
                    'phase': 'lock_wait',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'pid': os.getpid(),
                    'attempt': attempt,
                    'errno': en,
                    'winerror': getattr(e, 'winerror', None),
                    'lock_owner_pid': owner,
                    'elapsed_ms': int((time.time() - started_at) * 1000),
                }
            )
            if _lock_is_stale(lock_path):
                try:
                    if os.path.exists(lock_path):
                        os.remove(lock_path)
                except Exception:
                    pass
                continue
            if time.time() >= deadline:
                return None, e
            sleep_for = min(_LOCK_BACKOFF_START * attempt, 0.4)
            time.sleep(sleep_for)


def _release_lock(lock_path, target_path, artifact, writer):
    if not lock_path:
        return
    try:
        if os.path.exists(lock_path):
            os.remove(lock_path)
    except Exception:
        pass
    _emit_json_io_event(
        {
            'phase': 'lock_released',
            'artifact': artifact,
            'writer': writer,
            'path_basename': os.path.basename(target_path),
            'pid': os.getpid(),
        }
    )


def _promote_with_retries(tmp_path, dest_path, artifact, writer):
    basename = os.path.basename(dest_path)
    t0 = time.time()
    last_exc = None
    for n in range(1, _PROMOTE_RETRIES + 1):
        try:
            os.replace(tmp_path, dest_path)
            _emit_json_io_event(
                {
                    'phase': 'promote_success',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'pid': os.getpid(),
                    'attempt': n,
                    'elapsed_ms': int((time.time() - t0) * 1000),
                }
            )
            return True, None
        except (OSError, IOError) as e:
            last_exc = e
            en, we, _ = _exc_meta(e)
            _emit_json_io_event(
                {
                    'phase': 'promote_retry',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'pid': os.getpid(),
                    'attempt': n,
                    'errno': en,
                    'winerror': we,
                    'elapsed_ms': int((time.time() - t0) * 1000),
                }
            )
            if not _is_promote_retry_exc(e) and n > 2:
                break
            time.sleep(_PROMOTE_BACKOFF * n)
    return False, last_exc


def _remove_best_effort(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def load_json_file(path, default=None, object_pairs=False):
    """
    Load JSON object from path. On error returns default if set, else raises.
    """
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            if object_pairs:
                return json.load(handle, object_pairs_hook=OrderedDict)
            return json.load(handle)
    except Exception:
        if default is not None:
            return default
        raise


def write_json_atomic(path, payload, artifact, writer, indent=2, sort_keys=False, lock=True, ensure_ascii=False):
    """
    Write JSON atomically. Returns True on success.
    Never truncates destination if promotion fails (temp removed best-effort).
    """
    path = os.path.abspath(path)
    dirname = os.path.dirname(path)
    if dirname and not os.path.isdir(dirname):
        try:
            os.makedirs(dirname)
        except Exception:
            pass
    basename = os.path.basename(path)
    tmp_name = '{0}.tmp.{1}.{2}.{3}'.format(path, os.getpid(), int(time.time()), random.randint(1000, 9999))
    lock_path = None
    t0 = time.time()
    _emit_json_io_event(
        {
            'phase': 'start',
            'artifact': artifact,
            'writer': writer,
            'path_basename': basename,
            'pid': os.getpid(),
            'elapsed_ms': 0,
        }
    )
    if lock:
        lock_path, lock_exc = _acquire_lock(path, artifact, writer)
        if lock_exc is not None:
            en, we, _ = _exc_meta(lock_exc)
            _emit_json_io_event(
                {
                    'phase': 'lock_failed',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'pid': os.getpid(),
                    'errno': en,
                    'winerror': we,
                    'elapsed_ms': int((time.time() - t0) * 1000),
                }
            )
            _record_failure(writer, path, 'lock_acquire', exc=lock_exc)
            _emit_failure_diagnostics(path, artifact, writer, 'lock_failed', exc=lock_exc)
            return False
    try:
        try:
            handle = open(tmp_name, 'w', encoding='utf-8')
        except (OSError, IOError) as e:
            _emit_json_io_event(
                {
                    'phase': 'temp_open_failed',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'errno': getattr(e, 'errno', None),
                    'winerror': getattr(e, 'winerror', None),
                    'elapsed_ms': int((time.time() - t0) * 1000),
                }
            )
            _record_failure(writer, path, 'temp_open', exc=e)
            _emit_failure_diagnostics(path, artifact, writer, 'temp_open_failed', exc=e)
            return False
        try:
            json.dump(payload, handle, ensure_ascii=ensure_ascii, indent=indent, sort_keys=sort_keys)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
        except Exception as e:
            try:
                handle.close()
            except Exception:
                pass
            _remove_best_effort(tmp_name)
            _emit_json_io_event(
                {
                    'phase': 'temp_write_failed',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'errno': getattr(e, 'errno', None),
                    'elapsed_ms': int((time.time() - t0) * 1000),
                }
            )
            _record_failure(writer, path, 'temp_write', exc=e)
            _emit_failure_diagnostics(path, artifact, writer, 'temp_write_failed', exc=e)
            return False
        try:
            handle.close()
        except Exception:
            pass

        ok, exc = _promote_with_retries(tmp_name, path, artifact, writer)
        if not ok:
            _remove_best_effort(tmp_name)
            _emit_json_io_event(
                {
                    'phase': 'promote_failed',
                    'artifact': artifact,
                    'writer': writer,
                    'path_basename': basename,
                    'pid': os.getpid(),
                    'elapsed_ms': int((time.time() - t0) * 1000),
                }
            )
            _record_failure(writer, path, 'promote', exc=exc)
            _emit_failure_diagnostics(path, artifact, writer, 'promote_failed', exc=exc, extra={'tmp_path': tmp_name})
            return False
        _emit_json_io_event(
            {
                'phase': 'success',
                'artifact': artifact,
                'writer': writer,
                'path_basename': basename,
                'pid': os.getpid(),
                'elapsed_ms': int((time.time() - t0) * 1000),
            }
        )
        return True
    finally:
        if lock:
            _release_lock(lock_path, path, artifact, writer)


def append_jsonl(path, record, artifact, writer, lock=False, record_failure=True):
    """Append one JSON object as a line. record may be dict (serialized) or str (written as-is)."""
    path = os.path.abspath(path)
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        try:
            os.makedirs(parent)
        except Exception:
            pass
    if isinstance(record, dict):
        line = json.dumps(record, ensure_ascii=True, default=str) + '\n'
    else:
        line = str(record)
        if not line.endswith('\n'):
            line += '\n'
    lock_path = None
    if lock:
        lock_path, lock_exc = _acquire_lock(path, artifact, writer)
        if lock_exc is not None:
            if record_failure:
                _record_failure(writer, path, 'append_jsonl_lock', exc=lock_exc)
            return False
    try:
        _emit_json_io_event(
            {
                'phase': 'append_jsonl',
                'artifact': artifact,
                'writer': writer,
                'path_basename': os.path.basename(path),
                'pid': os.getpid(),
            }
        )
        with open(path, 'a', encoding='utf-8') as handle:
            handle.write(line)
            handle.flush()
        return True
    except Exception as e:
        if record_failure:
            _record_failure(writer, path, 'append_jsonl', exc=e)
        return False
    finally:
        if lock_path:
            _release_lock(lock_path, path, artifact, writer)


def append_text_line(path, line, artifact, writer, lock=False, record_failure=True):
    text = str(line or '')
    if not text.endswith('\n'):
        text += '\n'
    return _append_raw_line(path, text, artifact, writer, lock, record_failure)


def _append_raw_line(path, line, artifact, writer, lock=False, record_failure=True):
    path = os.path.abspath(path)
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        try:
            os.makedirs(parent)
        except Exception:
            pass
    lock_path = None
    if lock:
        lock_path, lock_exc = _acquire_lock(path, artifact, writer)
        if lock_exc is not None:
            if record_failure:
                _record_failure(writer, path, 'append_text_lock', exc=lock_exc)
            return False
    try:
        _emit_json_io_event(
            {
                'phase': 'append_text',
                'artifact': artifact,
                'writer': writer,
                'path_basename': os.path.basename(path),
                'pid': os.getpid(),
            }
        )
        with open(path, 'a', encoding='utf-8') as handle:
            handle.write(line)
            handle.flush()
        return True
    except Exception as e:
        if record_failure:
            _record_failure(writer, path, 'append_text', exc=e)
        return False
    finally:
        if lock_path:
            _release_lock(lock_path, path, artifact, writer)


def rotate_jsonl_tail(path, max_lines, artifact, writer, record_failure=True):
    """Keep only the last max_lines lines; uses atomic rewrite. Returns True on success or no-op."""
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        return True
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            lines = handle.readlines()
    except Exception:
        return False
    if len(lines) <= max_lines:
        return True
    keep = lines[-max_lines:]
    new_body = ''.join(keep)
    tmp_path = path + '.rotate.tmp.{0}'.format(os.getpid())
    try:
        with open(tmp_path, 'w', encoding='utf-8') as handle:
            handle.write(new_body)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
    except Exception as e:
        _remove_best_effort(tmp_path)
        if record_failure:
            _record_failure(writer, path, 'rotate_jsonl_temp', exc=e)
        return False
    ok, exc = _promote_with_retries(tmp_path, path, artifact, writer)
    if not ok:
        _remove_best_effort(tmp_path)
        if record_failure:
            _record_failure(writer, path, 'rotate_jsonl_promote', exc=exc)
        return False
    return True


def rewrite_jsonl_atomic(path, body, artifact='jsonl_rewrite', writer='json_health', record_failure=True):
    """
    Replace a JSONL file in one atomic promote (temp write + fsync + os.replace).
    body must be a unicode str (Py3) with embedded newlines; may be empty.
    Creates parent directory when missing. Returns True on success.
    """
    path = os.path.abspath(path)
    if not path:
        return False
    dirname = os.path.dirname(path)
    if dirname and not os.path.isdir(dirname):
        try:
            os.makedirs(dirname)
        except Exception:
            pass
    tmp_path = path + '.rewrite.tmp.{0}'.format(os.getpid())
    try:
        with open(tmp_path, 'w', encoding='utf-8') as handle:
            handle.write(body or '')
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
    except Exception as e:
        _remove_best_effort(tmp_path)
        if record_failure:
            _record_failure(writer, path, 'rewrite_jsonl_temp', exc=e)
        return False
    ok, exc = _promote_with_retries(tmp_path, path, artifact, writer)
    if not ok:
        _remove_best_effort(tmp_path)
        if record_failure:
            _record_failure(writer, path, 'rewrite_jsonl_promote', exc=exc)
        return False
    return True


def probe_file_write_handle(path, artifact):
    """
    Open existing file for read/write without truncation. Returns dict:
    ok (bool), phase, hint, errno, winerror
    """
    out = {'ok': True, 'phase': 'probe_r_plus', 'hint': '', 'path': path, 'errno': None, 'winerror': None}
    if not path or not os.path.isfile(path):
        out['ok'] = False
        out['phase'] = 'probe_missing'
        out['hint'] = 'file missing'
        return out
    try:
        handle = open(path, 'r+', encoding='utf-8')
        handle.close()
    except (OSError, IOError) as e:
        out['ok'] = False
        out['errno'] = getattr(e, 'errno', None)
        out['winerror'] = getattr(e, 'winerror', None)
        out['hint'] = _hint_for_io_failure(path, e)
    except Exception as e:
        out['ok'] = False
        out['hint'] = str(e)
    return out


def probe_directory_io(dir_path, artifact):
    """
    Create probe files in dir_path: write, rename, read, replace-existing, delete.
    Returns dict ok, phase, hint, errno, winerror, path (dir).
    The replace-existing probe catches XP/F: drive failures where temp writes work
    but atomic promotion over an existing JSON returns errno 17 or sharing errors.
    """
    out = {'ok': True, 'phase': 'dir_probe', 'hint': '', 'path': dir_path, 'errno': None, 'winerror': None}
    if not dir_path:
        out['ok'] = False
        out['hint'] = 'empty directory path'
        return out
    if not os.path.isdir(dir_path):
        out['ok'] = False
        out['phase'] = 'dir_missing'
        out['hint'] = 'directory does not exist'
        return out
    token = '{0}.{1}'.format(os.getpid(), random.randint(10000, 99999))
    base = os.path.join(dir_path, '.medicafe_json_io_probe.{0}'.format(token))
    tmp = base + '.tmp'
    final = base + '.done'
    replace_tmp = base + '.replace.tmp'
    data = 'medicafe_json_io_probe {0}\n'.format(token)
    replace_data = 'medicafe_json_io_replace_probe {0}\n'.format(token)
    try:
        try:
            with open(tmp, 'w') as handle:
                handle.write(data)
                handle.flush()
                try:
                    os.fsync(handle.fileno())
                except Exception:
                    pass
        except (OSError, IOError) as e:
            out['ok'] = False
            out['phase'] = 'dir_probe_write'
            out['errno'] = getattr(e, 'errno', None)
            out['winerror'] = getattr(e, 'winerror', None)
            out['hint'] = _hint_for_io_failure(dir_path, e)
            return out
        try:
            os.rename(tmp, final)
        except (OSError, IOError) as e:
            out['ok'] = False
            out['phase'] = 'dir_probe_rename'
            out['errno'] = getattr(e, 'errno', None)
            out['winerror'] = getattr(e, 'winerror', None)
            out['hint'] = _hint_for_io_failure(dir_path, e)
            return out
        try:
            with open(final, 'r') as handle:
                read_back = handle.read()
            if token not in read_back:
                out['ok'] = False
                out['phase'] = 'dir_probe_verify'
                out['hint'] = 'read-back mismatch'
                return out
        except (OSError, IOError) as e:
            out['ok'] = False
            out['phase'] = 'dir_probe_read'
            out['errno'] = getattr(e, 'errno', None)
            out['winerror'] = getattr(e, 'winerror', None)
            out['hint'] = _hint_for_io_failure(dir_path, e)
            return out
        try:
            with open(replace_tmp, 'w') as handle:
                handle.write(replace_data)
                handle.flush()
                try:
                    os.fsync(handle.fileno())
                except Exception:
                    pass
        except (OSError, IOError) as e:
            out['ok'] = False
            out['phase'] = 'dir_probe_replace_write'
            out['errno'] = getattr(e, 'errno', None)
            out['winerror'] = getattr(e, 'winerror', None)
            out['hint'] = _hint_for_io_failure(dir_path, e)
            return out
        try:
            os.replace(replace_tmp, final)
        except (OSError, IOError) as e:
            out['ok'] = False
            out['phase'] = 'dir_probe_replace_existing'
            out['errno'] = getattr(e, 'errno', None)
            out['winerror'] = getattr(e, 'winerror', None)
            out['hint'] = _hint_for_io_failure(dir_path, e)
            out['diagnostics'] = collect_path_diagnostics(final)
            return out
        try:
            with open(final, 'r') as handle:
                replaced_body = handle.read()
            if 'replace_probe {0}'.format(token) not in replaced_body and token not in replaced_body:
                out['ok'] = False
                out['phase'] = 'dir_probe_replace_verify'
                out['hint'] = 'replace read-back mismatch'
                return out
        except (OSError, IOError) as e:
            out['ok'] = False
            out['phase'] = 'dir_probe_replace_read'
            out['errno'] = getattr(e, 'errno', None)
            out['winerror'] = getattr(e, 'winerror', None)
            out['hint'] = _hint_for_io_failure(dir_path, e)
            return out
    finally:
        _remove_best_effort(tmp)
        _remove_best_effort(replace_tmp)
        _remove_best_effort(final)
    out['phase'] = 'dir_probe_ok'
    return out


def probe_append_only_file(path, artifact):
    """Append one line to a dedicated probe file (creates if missing)."""
    out = {'ok': True, 'phase': 'append_probe', 'hint': '', 'path': path, 'errno': None, 'winerror': None}
    line = 'medicafe_append_probe {0}\n'.format(int(time.time()))
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(path, 'a') as handle:
            handle.write(line)
            handle.flush()
    except (OSError, IOError) as e:
        out['ok'] = False
        out['errno'] = getattr(e, 'errno', None)
        out['winerror'] = getattr(e, 'winerror', None)
        out['hint'] = _hint_for_io_failure(path, e)
    return out


def probe_ephemeral_append_in_dir(dir_path, artifact):
    """
    Verify append-style I/O in an existing directory without leaving artifacts.
    Creates a unique temp file, appends one line, reads back, deletes.
    """
    out = {'ok': True, 'phase': 'ephemeral_append', 'hint': '', 'path': dir_path, 'errno': None, 'winerror': None}
    if not dir_path or not os.path.isdir(dir_path):
        out['ok'] = False
        out['phase'] = 'ephemeral_append_skip'
        out['hint'] = 'directory missing'
        return out
    token = '{0}.{1}'.format(os.getpid(), random.randint(10000, 99999))
    path = os.path.join(dir_path, '.medicafe_json_io_ephemeral_append.{0}.tmp'.format(token))
    line = 'ephemeral_append {0}\n'.format(token)
    try:
        with open(path, 'a', encoding='utf-8') as handle:
            handle.write(line)
            handle.flush()
        with open(path, 'r', encoding='utf-8') as handle:
            body = handle.read()
        if token not in body:
            out['ok'] = False
            out['phase'] = 'ephemeral_append_verify'
            out['hint'] = 'read-back mismatch'
    except (OSError, IOError) as e:
        out['ok'] = False
        out['errno'] = getattr(e, 'errno', None)
        out['winerror'] = getattr(e, 'winerror', None)
        out['hint'] = _hint_for_io_failure(dir_path, e)
    finally:
        _remove_best_effort(path)
    if out['ok']:
        out['phase'] = 'ephemeral_append_ok'
    return out


def _hint_for_io_failure(path, exc):
    msg = []
    en = getattr(exc, 'errno', None)
    we = getattr(exc, 'winerror', None)
    if en == errno.EACCES or we == _WIN_ERR_ACCESS:
        msg.append('permission denied  Echeck read-only file attribute or directory ACLs')
    if we in (_WIN_ERR_SHARING, _WIN_ERR_LOCK):
        msg.append('file may be locked by another process (editor, antivirus, sync)')
    if en == errno.EAGAIN or en == errno.EWOULDBLOCK:
        msg.append('transient lock; antivirus or indexer may hold the file')
    if not msg:
        msg.append('I/O error on path {0}'.format(path))
    if we in (_WIN_ERR_SHARING, _WIN_ERR_LOCK) or en in (errno.EACCES, 13):
        msg.append('if retries fail, suspect antivirus/sync/share lock')
    return '; '.join(msg)


def collect_json_io_preflight_failures(context):
    """
    Read-only JSON IO probes: no makedirs, no persistent probe files.
    Optional locations (payer cache, telemetry, reports) are probed only if the
    directory already exists.
    """
    failures = []
    cfg = None
    medi = {}
    try:
        from MediCafe import preflight as _preflight_mod

        config_path, crosswalk_path, project_dir = _preflight_mod._resolve_paths(context)
    except Exception:
        config_path = ''
        crosswalk_path = ''
        project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

    if config_path and os.path.isfile(config_path):
        try:
            if hasattr(_preflight_mod, '_load_effective_config_snapshot'):
                cfg, _cw, _meta = _preflight_mod._load_effective_config_snapshot(context)
            else:
                with open(config_path, 'r') as handle:
                    cfg = json.load(handle)
            medi = cfg.get('MediLink_Config', {}) if isinstance(cfg, dict) else {}
            if not isinstance(medi, dict):
                medi = {}
        except Exception:
            cfg = None
            medi = {}

    cw_seen = set()
    cw_list = []

    def _add_crosswalk_probe(path):
        if not path:
            return
        abs_path = os.path.abspath(os.path.normpath(path))
        if abs_path not in cw_seen:
            cw_seen.add(abs_path)
            cw_list.append(abs_path)

    if crosswalk_path:
        _add_crosswalk_probe(crosswalk_path)
    explicit_cw = ''
    if medi.get('crosswalkPath'):
        explicit_cw = str(medi.get('crosswalkPath')).strip()
    elif isinstance(cfg, dict) and cfg.get('crosswalkPath'):
        explicit_cw = str(cfg.get('crosswalkPath')).strip()
    if explicit_cw and config_path:
        cfg_dir = os.path.dirname(os.path.abspath(config_path))
        if os.path.isabs(explicit_cw):
            _add_crosswalk_probe(explicit_cw)
        else:
            _add_crosswalk_probe(os.path.join(cfg_dir, explicit_cw))

    if config_path:
        r = probe_file_write_handle(config_path, 'preflight_config')
        if not r['ok']:
            failures.append(
                'config.json r+ probe failed ({0}): {1}'.format(r.get('phase'), r.get('hint') or 'unknown')
            )
    for cw_abs in cw_list:
        r = probe_file_write_handle(cw_abs, 'preflight_crosswalk')
        if not r['ok']:
            failures.append(
                'crosswalk r+ probe failed ({0}) [{1}]: {2}'.format(
                    r.get('phase'), os.path.basename(cw_abs), r.get('hint') or 'unknown'
                )
            )

    local_storage = ''
    source_folder = ''
    target_folder = ''
    payer_cache = ''
    z_dat = ''

    if context:
        local_storage = context.get('local_storage_path', '') or ''
        source_folder = context.get('source_folder', '') or ''
        target_folder = context.get('target_folder', '') or ''

    if not local_storage and medi.get('local_storage_path'):
        local_storage = str(medi.get('local_storage_path')).strip()
    plu = medi.get('payer_list_updates', {}) or {}
    if isinstance(plu, dict) and plu.get('cache_dir'):
        payer_cache = str(plu.get('cache_dir')).strip()
    if medi.get('Z_DAT_PATH'):
        z_dat = str(medi.get('Z_DAT_PATH')).strip()

    if not local_storage:
        local_storage = os.path.join(project_dir, 'MediBot', 'DOWNLOADS')
    if not os.path.isabs(local_storage):
        local_storage = os.path.normpath(os.path.join(project_dir, local_storage))
    if not source_folder:
        source_folder = local_storage
    if not target_folder:
        target_folder = os.path.join(local_storage, 'CSV')
    if not os.path.isabs(source_folder):
        source_folder = os.path.normpath(os.path.join(project_dir, source_folder))
    if not os.path.isabs(target_folder):
        target_folder = os.path.normpath(os.path.join(project_dir, target_folder))

    if not payer_cache:
        payer_cache = os.path.join(project_dir, 'cache', 'payer_lists')
    if not os.path.isabs(payer_cache):
        payer_cache = os.path.normpath(os.path.join(project_dir, payer_cache))

    for label, dpath in (
        ('config_dir', os.path.dirname(config_path) if config_path else ''),
        ('local_storage', local_storage),
        ('csv_source', source_folder),
        ('csv_target', target_folder),
    ):
        if not dpath:
            continue
        r = probe_directory_io(dpath, label)
        if not r['ok']:
            failures.append(
                '{0} directory probe failed ({1}): {2}'.format(label, r.get('phase'), r.get('hint'))
            )

    if os.path.isdir(payer_cache):
        r = probe_directory_io(payer_cache, 'payer_list_cache')
        if not r['ok']:
            failures.append(
                'payer_list_cache directory probe failed ({0}): {1}'.format(
                    r.get('phase'), r.get('hint')
                )
            )

    for telem_dir in _telemetry_probe_candidates_readonly(config_path or '', local_storage):
        if telem_dir and os.path.isdir(telem_dir):
            r = probe_directory_io(telem_dir, 'telemetry_dir')
            if not r['ok']:
                failures.append(
                    'telemetry directory probe failed ({0}) [{1}]: {2}'.format(
                        r.get('phase'),
                        os.path.basename(os.path.normpath(telem_dir)),
                        r.get('hint'),
                    )
                )

    reports_dir = os.path.join(local_storage, 'reports')
    if os.path.isdir(reports_dir):
        r = probe_directory_io(reports_dir, 'support_reports_dir')
        if not r['ok']:
            failures.append(
                'support queue directory probe failed ({0}): {1}'.format(r.get('phase'), r.get('hint'))
            )
        else:
            ap = probe_ephemeral_append_in_dir(reports_dir, 'support_append')
            if not ap['ok']:
                failures.append('support append probe failed: {0}'.format(ap.get('hint')))

    env_dat = str(os.environ.get('Z_DAT_PATH', '') or '').strip()
    if env_dat:
        z_dat = env_dat
    if z_dat:
        if not os.path.isabs(z_dat):
            z_dat = os.path.normpath(os.path.join(project_dir, z_dat))
        dat_dir = z_dat if os.path.isdir(z_dat) else os.path.dirname(z_dat)
        if dat_dir and os.path.isdir(dat_dir):
            r = probe_directory_io(dat_dir, 'dat_dir')
            if not r['ok']:
                failures.append(
                    'Z_DAT_PATH directory probe failed ({0}): {1}'.format(r.get('phase'), r.get('hint'))
                )

    if os.path.isdir(local_storage):
        ap2 = probe_ephemeral_append_in_dir(local_storage, 'csv_intake_append')
        if not ap2['ok']:
            failures.append('csv intake append probe failed: {0}'.format(ap2.get('hint')))

    if failures:
        diag_paths = []
        for p in ([config_path] + cw_list + [
                os.path.dirname(config_path) if config_path else '',
                local_storage,
                source_folder,
                target_folder,
                payer_cache,
                reports_dir,
        ]):
            if p and p not in diag_paths:
                diag_paths.append(p)
        _emit_json_io_diagnostic(
            {
                'phase': 'preflight_failed',
                'artifact': 'json_io_preflight',
                'writer': 'preflight',
                'pid': os.getpid(),
                'failures': failures[:12],
                'path_diagnostics': [collect_path_diagnostics(p) for p in diag_paths[:10]],
            },
            level='WARNING',
        )

    return failures


def _telemetry_probe_candidates_readonly(config_path_hint, local_storage):
    """
    Return existing telemetry candidate paths without creating directories.
    Mirrors resolve_telemetry_dir intent but stays read-only for preflight.
    """
    out = []
    seen = set()

    def _add(path):
        if not path:
            return
        p = os.path.abspath(path)
        if p in seen:
            return
        seen.add(p)
        out.append(p)

    # Error-reporter telemetry normally lives beside reports_queue under local_storage.
    # Do not call error_reporter._resolve_queue_dir here; it creates fallback dirs.
    if local_storage:
        _add(os.path.join(local_storage, 'telemetry'))

    bootstrap = str(os.environ.get('MEDICAFE_BOOTSTRAP_LOG_DIR', '') or '').strip()
    if bootstrap:
        _add(os.path.join(bootstrap, 'telemetry'))
    if config_path_hint:
        _add(os.path.join(os.path.dirname(os.path.abspath(config_path_hint)), 'telemetry'))
    _add(os.path.join(os.getcwd(), 'telemetry'))
    return out
