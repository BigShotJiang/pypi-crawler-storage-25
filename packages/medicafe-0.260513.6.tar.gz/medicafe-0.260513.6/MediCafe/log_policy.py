from __future__ import print_function

import copy
import os
import time

try:
    from MediCafe.logging_config import DEBUG, PERFORMANCE_LOGGING
except Exception:
    DEBUG = False
    PERFORMANCE_LOGGING = False
try:
    from MediCafe.diagnostics_policy import resolve_diagnostics_policy
except Exception:
    resolve_diagnostics_policy = None


def _env_true(name, default=False):
    try:
        raw = os.environ.get(name)
    except Exception:
        raw = None
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')


def normalize_level(level, default='INFO'):
    try:
        text = str(level or '').strip().upper()
    except Exception:
        text = ''
    if text in ('CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG'):
        return text
    return str(default or 'INFO').upper()


def is_verbose_logging_enabled():
    """Return True when verbose payload emission is explicitly enabled.

    - `DEBUG` enables verbose payloads for triage sessions.
    - `MEDICAFE_VERBOSE_LOGGING=1` enables verbose payloads without config changes.

    Performance logging (timing-only) should not implicitly enable structured payload dumps.
    """
    if resolve_diagnostics_policy is not None:
        try:
            policy = resolve_diagnostics_policy({'MediLink_Config': {'DEBUG': bool(DEBUG)}})
            return bool(policy.get('verbose'))
        except Exception:
            pass
    if bool(DEBUG):
        return True
    return _env_true('MEDICAFE_VERBOSE_LOGGING', False)


def should_emit_detailed_payload(kind, level='INFO', payload=None):
    lvl = normalize_level(level)
    if lvl in ('ERROR', 'CRITICAL', 'WARNING'):
        return True
    if lvl == 'DEBUG':
        return is_verbose_logging_enabled()
    if is_verbose_logging_enabled():
        return True
    # Keep successful JSON IO events inspectable by default; suppress phase-chatter elsewhere.
    if str(kind or '').strip().lower() == 'json_io_event':
        try:
            phase = str((payload or {}).get('phase') or '').strip().lower()
        except Exception:
            phase = ''
        return phase in ('success', 'promote_failed', 'lock_failed', 'temp_open_failed', 'temp_write_failed')
    return False


_SENSITIVE_LOG_KEY_EXACT = (
    'access_token',
    'refresh_token',
    'id_token',
    'x_auth_token',
    'authorization',
    'auth_token',
    'bearer_token',
    'password',
    'passwd',
    'secret',
    'client_secret',
    'api_key',
    'apikey',
    'private_key',
    'credential',
    'credentials',
    'cookie',
    'session',
    'session_id',
    'ssn',
    'social_security_number',
    'patient_id',
    'patientid',
    'patid',
    'member_id',
    'subscriber_id',
    'medical_record_number',
    'mrn',
)

_SENSITIVE_LOG_KEY_FRAGMENTS = (
    'token',
    'password',
    'passwd',
    'secret',
    'authorization',
    'api_key',
    'apikey',
    'private_key',
    'credential',
    'cookie',
)

_SENSITIVE_LOG_KEY_SUFFIXES = (
    '_patient_id',
    '_patientid',
    '_patid',
    '_member_id',
    '_subscriber_id',
    '_ssn',
    '_mrn',
)

_LOG_POLICY_REVIEW_SURFACES = {
    'MediLink_Gmail': {
        'component': 'MediLink_Gmail',
        'default_detail': 'minimal',
        'allowed_fields': (
            'phase',
            'transferRoute',
            'transferRouteSecondary',
            'transferRouteSelectionReason',
            'transferRouteOutcome',
            'terminalTransferOutcome',
            'linksReceived',
            'filesDownloaded',
            'filesToDelete',
            'filesDeleted',
            'lastError',
            'sessionId',
            'transferRunId',
            'statusCode',
            'route',
        ),
        'required_controls': (
            'local_control_token_never_logged',
            'gmail_oauth_tokens_redacted',
            'full_request_payloads_verbose_only',
            'download_paths_reduced_to_basename_or_route_context',
        ),
    },
    'error_reporter': {
        'component': 'error_reporter',
        'default_detail': 'redacted_support_context',
        'allowed_fields': (
            'bundle_kind',
            'delivery_state',
            'delivery_issue_code',
            'auth_taxonomy',
            'reauth_required',
            'send_succeeded',
            'queue_count',
            'zip_basename',
            'email_attachment_name',
            'email_subject',
            'error_summary',
            'policy_reason',
        ),
        'required_controls': (
            'support_bundle_text_redaction',
            'support_bundle_json_key_redaction',
            'delivery_meta_extra_context_sanitized',
            'gmail_authorization_header_redacted',
        ),
    },
    'config_write_telemetry': {
        'component': 'config_write_telemetry',
        'default_detail': 'contention_diagnostics_only',
        'allowed_fields': (
            'utc_ts',
            'pid',
            'writer',
            'phase',
            'path_basename',
            'errno',
            'strerror',
            'winerror',
            'exc_type',
            'config_write_policy',
            'child_stderr_tail',
        ),
        'required_controls': (
            'path_basename_preferred_in_logs',
            'child_stderr_tail_bounded',
            'autosubmit_policy_snapshot_recorded',
            'contention_autosubmit_cooldown_enforced',
        ),
    },
}


def _decode_json_pointer_segment(segment):
    try:
        text = str(segment or '')
    except Exception:
        return ''
    return text.replace('~1', '/').replace('~0', '~')


def _normalize_log_key(key):
    raw = str(key or '')
    out = []
    prev_sep = False
    prev_alnum = False
    for idx, ch in enumerate(raw):
        if ch >= 'A' and ch <= 'Z':
            if idx > 0 and prev_alnum and not prev_sep:
                out.append('_')
            out.append(ch.lower())
            prev_sep = False
            prev_alnum = True
        elif (ch >= 'a' and ch <= 'z') or (ch >= '0' and ch <= '9'):
            out.append(ch)
            prev_sep = False
            prev_alnum = True
        else:
            if not prev_sep:
                out.append('_')
                prev_sep = True
            prev_alnum = False
    return ''.join(out).strip('_')


def is_sensitive_log_field(key):
    """Return True when a log/telemetry field name should not be emitted raw."""
    normalized = _normalize_log_key(key)
    if not normalized:
        return False
    if normalized in _SENSITIVE_LOG_KEY_EXACT:
        return True
    for fragment in _SENSITIVE_LOG_KEY_FRAGMENTS:
        if fragment in normalized:
            return True
    for suffix in _SENSITIVE_LOG_KEY_SUFFIXES:
        if normalized.endswith(suffix):
            return True
    return False


def log_field_control(key):
    """Classify a field for callers that need a stable log minimization decision."""
    sensitive = is_sensitive_log_field(key)
    return {
        'field': str(key or ''),
        'normalized_field': _normalize_log_key(key),
        'sensitive': bool(sensitive),
        'action': 'redact' if sensitive else 'allow',
        'reason': 'sensitive_log_field' if sensitive else 'log_field_allowed',
    }


def redact_sensitive_json_pointer(pointer, marker='***'):
    """Redact sensitive JSON pointer path segments while preserving structure."""
    try:
        text = str(pointer or '')
    except Exception:
        return ''
    if not text:
        return ''
    prefix = ''
    body = text
    if body.startswith('$/'):
        prefix = '$/'
        body = body[2:]
    elif body == '$':
        return '$'
    elif body.startswith('/'):
        prefix = '/'
        body = body[1:]
    parts = body.split('/') if body else []
    redacted = []
    for part in parts:
        decoded = _decode_json_pointer_segment(part)
        if is_sensitive_log_field(decoded):
            redacted.append(marker)
        else:
            redacted.append(part)
    return prefix + '/'.join(redacted)


def get_log_policy_review_surface(component=None):
    """
    Return the APP-5 review surface for audited logging/telemetry components.

    The surface is intentionally small and declarative so security reviews can
    verify the intended controls without importing runtime-heavy modules.
    """
    if component:
        key = str(component or '').strip()
        surface = _LOG_POLICY_REVIEW_SURFACES.get(key)
        if surface is None:
            return {}
        return copy.deepcopy(surface)
    return copy.deepcopy(_LOG_POLICY_REVIEW_SURFACES)


def minimize_log_record(component, record, allowlist=None, max_text_length=240):
    """
    Return a bounded, allowlisted, field-aware copy of a log/telemetry record.

    Unknown fields are omitted unless they are explicitly allowlisted. Sensitive
    field names are retained as redacted markers so reviewers can see that data
    existed without exposing the value.
    """
    if not isinstance(record, dict):
        return {}
    if allowlist is None:
        surface = get_log_policy_review_surface(component)
        allowlist = surface.get('allowed_fields') if isinstance(surface, dict) else None
    allowed = set([str(item or '') for item in (allowlist or ())])
    out = {}
    for key, value in record.items():
        key_text = str(key or '')
        if is_sensitive_log_field(key_text):
            out[key_text] = '***'
            continue
        if allowed and key_text not in allowed:
            continue
        if isinstance(value, dict):
            out[key_text] = minimize_log_record(component, value, allowlist=(), max_text_length=max_text_length)
            continue
        if isinstance(value, (list, tuple)):
            reduced = []
            for idx, item in enumerate(value):
                if idx >= 20:
                    reduced.append('...')
                    break
                if isinstance(item, dict):
                    reduced.append(minimize_log_record(component, item, allowlist=(), max_text_length=max_text_length))
                else:
                    reduced.append(_bound_log_value(item, max_text_length))
            out[key_text] = reduced
            continue
        out[key_text] = _bound_log_value(value, max_text_length)
    return out


def _bound_log_value(value, max_text_length):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value
    if isinstance(value, bool) or value is None:
        return value
    try:
        limit = int(max_text_length)
    except Exception:
        limit = 240
    if limit < 16:
        limit = 16
    text = str(value)
    if len(text) <= limit:
        return text
    return text[:limit] + '...'


def summarize_event(kind, payload):
    data = payload if isinstance(payload, dict) else {}
    name = str(kind or '').strip().lower()
    if name == 'csv_processing':
        return "event={} stage={} iteration={} cache_result={}".format(
            data.get('event', ''),
            data.get('stage', ''),
            data.get('iteration', ''),
            data.get('cache_result', ''),
        )
    if name == 'csv_preprocess':
        return "stage={} rows={} retained={} removed={}".format(
            data.get('stage', ''),
            data.get('row_count_in', data.get('total_rows', '')),
            data.get('retained_count', ''),
            data.get('removed_count', ''),
        )
    if name == 'payer_resolution':
        return "stage={} rows={} resolved={} unsupported={}".format(
            data.get('stage', ''),
            data.get('row_count', ''),
            data.get('resolved_count', ''),
            (data.get('skip_counts') or {}).get('unsupported_payer_id', ''),
        )
    if name == 'deductible_cache_csv':
        return "stage={} rows={} tuples={} dropped={}".format(
            data.get('stage', ''),
            data.get('row_count', ''),
            data.get('patient_tuple_count', ''),
            data.get('dropped_before_tuple_count', ''),
        )
    return ''


def get_cache_recency_hours(default_hours=24):
    try:
        raw = os.environ.get('MEDICAFE_DEDUCTIBLE_RECENT_CACHE_HOURS')
    except Exception:
        raw = None
    if raw is None:
        return int(default_hours)
    try:
        val = int(float(str(raw).strip()))
        if val <= 0:
            return int(default_hours)
        return val
    except Exception:
        return int(default_hours)


def get_patient_stale_days(default_days=120):
    try:
        raw = os.environ.get('MEDICAFE_DEDUCTIBLE_MAX_STALE_DAYS')
    except Exception:
        raw = None
    if raw is None:
        return int(default_days)
    try:
        val = int(float(str(raw).strip()))
        if val <= 0:
            return int(default_days)
        return val
    except Exception:
        return int(default_days)


def should_run_cache_eligibility_reconciliation(config, source_folder=None, drift_evidence=None):
    """
    Decide whether startup cache eligibility reconciliation should run.
    Returns (bool should_run, str reason).
    """
    if isinstance(drift_evidence, dict):
        flags = drift_evidence.get('drift_flags')
        if isinstance(flags, list) and flags:
            return True, 'drift_evidence:{0}'.format(str(flags[0] or '')[:80])
    if _env_true('MEDICAFE_FORCE_CACHE_RECONCILE', False):
        return True, 'forced_by_env'
    if _env_true('MEDICAFE_SKIP_CACHE_RECONCILE', False):
        return False, 'disabled_by_env'

    try:
        cfg = config if isinstance(config, dict) else {}
        csv_path = str(cfg.get('CSV_FILE_PATH') or '').strip()
    except Exception:
        csv_path = ''
    if not csv_path:
        return False, 'missing_config_csv_path'
    if not os.path.exists(csv_path):
        return False, 'config_csv_missing_on_disk'

    csv_dir = os.path.dirname(csv_path)
    cache_path = os.path.join(csv_dir, 'insurance_type_cache.json')
    if not os.path.exists(cache_path):
        return True, 'cache_file_missing'

    recency_hours = get_cache_recency_hours(24)
    threshold_seconds = float(recency_hours) * 3600.0
    now = time.time()
    try:
        cache_age = max(0.0, now - os.path.getmtime(cache_path))
    except Exception:
        return True, 'cache_mtime_unreadable'
    if cache_age > threshold_seconds:
        return True, 'cache_older_than_{}h'.format(recency_hours)

    try:
        csv_mtime = os.path.getmtime(csv_path)
    except Exception:
        csv_mtime = 0
    if csv_mtime and csv_mtime > (now - threshold_seconds):
        return True, 'csv_recently_modified'

    if source_folder and os.path.isdir(source_folder):
        try:
            for name in os.listdir(source_folder):
                if name.lower().endswith('.csv'):
                    return True, 'source_folder_contains_csv'
        except Exception:
            pass

    return False, 'cache_fresh_within_{}h'.format(recency_hours)
