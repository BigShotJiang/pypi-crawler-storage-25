#!/usr/bin/env python
"""Phase D developer-unblock evidence contract helpers.

The XP operator should not have to decide which helper report matters. Phase D
summaries declare the developer-safe evidence reports here, and bundle builders
consume the same contract.
"""
from __future__ import print_function

import os


SCHEMA_VERSION = "phase_d_developer_unblock_v1"
ACTION_RESOLVE_EXTERNAL_PATIENT_ID_CONTRACT = "resolve_external_patient_id_contract_pressure"
BLOCKER_INVALID_EXTERNAL_PATIENT_ID = "invalid_external_patient_id"


def _safe_str(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def _safe_basename(path):
    text = _safe_str(path).strip()
    if not text:
        return ""
    return os.path.basename(text)


def _report_entry(path, required=True):
    text = _safe_str(path).strip()
    if not text:
        return None
    return {
        "path": text,
        "archive_name": _safe_basename(text),
        "required": bool(required),
        "contains_pii": False,
        "safe_for_bundle": True,
    }


def build_invalid_external_patient_id_unblock(summary, report_paths):
    """Build the canonical Phase D unblock contract for invalid patient IDs."""
    data = summary if isinstance(summary, dict) else {}
    paths = report_paths if isinstance(report_paths, (list, tuple)) else []
    reports = []
    seen = {}
    for path in paths:
        entry = _report_entry(path, required=True)
        if not entry:
            continue
        key = entry.get("archive_name") or entry.get("path")
        if seen.get(key):
            continue
        seen[key] = True
        reports.append(entry)
    return {
        "schema_version": SCHEMA_VERSION,
        "status": "action_ready",
        "blocker_code": BLOCKER_INVALID_EXTERNAL_PATIENT_ID,
        "recommended_action_kind": ACTION_RESOLVE_EXTERNAL_PATIENT_ID_CONTRACT,
        "operator_manual_review_required": False,
        "safe_for_bundle": True,
        "contains_pii": False,
        "evidence_reports": reports,
        "next_predicted_stall": _safe_str(data.get("next_predicted_stall")).strip(),
        "next_predicted_stall_evidence": (
            data.get("next_predicted_stall_evidence")
            if isinstance(data.get("next_predicted_stall_evidence"), dict)
            else {}
        ),
        "developer_next_step": (
            "Use the attached redacted contract report(s) to fix the upstream "
            "patient ID contract; do not ask the XP operator to inspect local PII."
        ),
    }


def evidence_report_entries_from_summary(summary):
    """Return developer-unblock evidence report entries declared by a summary."""
    data = summary if isinstance(summary, dict) else {}
    contract = data.get("phase_d_developer_unblock")
    # Explicit contract opt-out must disable legacy fallback too; otherwise bundle
    # builders would still attach phase_d_invalid_external_id_contract_report_* paths.
    if isinstance(contract, dict) and contract.get("safe_for_bundle") is False:
        return []
    entries = []
    if isinstance(contract, dict):
        raw_entries = contract.get("evidence_reports")
        if isinstance(raw_entries, list):
            for raw in raw_entries:
                if isinstance(raw, dict):
                    path = _safe_str(raw.get("path")).strip()
                    if not path:
                        continue
                    entries.append({
                        "path": path,
                        "archive_name": _safe_str(raw.get("archive_name")).strip() or _safe_basename(path),
                        "required": bool(raw.get("required", True)),
                        "contains_pii": bool(raw.get("contains_pii", False)),
                        "safe_for_bundle": bool(raw.get("safe_for_bundle", True)),
                    })
                else:
                    entry = _report_entry(raw, required=True)
                    if entry:
                        entries.append(entry)
    if entries:
        return _dedupe_entries(entries)

    # Backward-compatible fallback for summaries produced before the contract.
    fallback = []
    for key in (
            "phase_d_invalid_external_id_contract_report_json_path",
            "phase_d_invalid_external_id_contract_report_txt_path"):
        entry = _report_entry(data.get(key), required=True)
        if entry:
            fallback.append(entry)
    return _dedupe_entries(fallback)


def evidence_report_tuples_from_summary(summary):
    """Return ``(archive_name, path)`` tuples for bundle extra_files callers."""
    out = []
    for entry in evidence_report_entries_from_summary(summary):
        if not bool(entry.get("safe_for_bundle", True)):
            continue
        if bool(entry.get("contains_pii", False)):
            continue
        out.append((entry.get("archive_name") or _safe_basename(entry.get("path")), entry.get("path")))
    return out


def _dedupe_entries(entries):
    out = []
    seen = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        path = _safe_str(entry.get("path")).strip()
        if not path:
            continue
        key = entry.get("archive_name") or path
        if seen.get(key):
            continue
        seen[key] = True
        out.append(entry)
    return out
