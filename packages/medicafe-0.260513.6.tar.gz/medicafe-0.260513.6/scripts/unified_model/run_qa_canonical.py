﻿#!/usr/bin/env python
"""
Phase D QA and canonicalization orchestrator.
Deterministic QA on ingest_artifact, replay routing for rejects, canonical extraction for passes.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import sqlite3
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import refresh_run_cursor_updated_at
from phase_d_common import (
    CANONICALIZATION_VERSION,
    QA_STAGE_PHASE_D,
    QA_POLICY_VERSION,
    PHASE_D_DB_WRITE_ERROR,
    PHASE_D_LOCK_FAIL,
    PHASE_D_REPLAY_QUEUE_ERROR,
    PHASE_D_STATE_WRITE_ERROR,
    PHASE_D_CSV_DOCX_JOIN_ZERO_MATCHES,
    PHASE_D_DAT_CSV_JOIN_ZERO_MATCHES,
    QA_ARTIFACT_CLASS_REQUIRED_FIELDS,
    QA_DAT_EMPTY_FILE,
    QA_DAT_PATIENT_ANCHOR_MISSING,
    QA_DAT_PAYER_ANCHOR_MISSING,
    QA_PARSE_ERROR,
    compute_qa_deterministic_key,
    iso_utc_now,
    run_id,
)
from lab_lock import acquire_lock, release_lock, replace_safe_write
from lab_path_utils import resolve_lab_root
from parse_providers import parse_artifact
from parse_providers import get_last_parse_diag
from dat_contract import build_dat_anchor_decision, build_dat_decision_context, resolve_dat_fields
from dat_manifest_lineage import build_dat_manifest_lineage_index, resolve_dat_artifact_manifest_lineage
from dat_parse_contract import DAT_PARSE_STATUS_EMPTY_FILE, dat_envelope_parse_metadata_dict
from dat_shape_contract import (
    append_dat_file_shape_diagnostics,
    dat_file_mtime_utc,
    dat_file_prefix_from_locator,
    dat_filename_timestamp_guess,
    dat_locator_basename,
    empty_dat_file_shape_diagnostics,
)
from qa_evaluator import evaluate_qa
from canonical_extractor import annotate_csv_docx_join, extract_canonical_records, build_domain_upserts
from failure_contract import build_failure_context
from join_contract import (
    EVENT_CSV_DOCX_JOIN_NEGOTIATION,
    EVENT_DAT_CSV_JOIN_NEGOTIATION,
    KEY_NEGOTIATION_LOG_REF,
    annotate_dat_csv_alignment,
    csv_docx_needs_negotiation_log,
    dat_csv_needs_negotiation_log,
    extend_summary_txt_lines,
    format_negotiation_log_ref,
)
import patient_field_mapper as patient_field_mapper_module
from patient_field_mapper import (
    EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN,
    classify_external_patient_id_5_digit,
    external_patient_id_contract_disposition,
    external_patient_id_source_contract,
)
from phase_d_v2_metrics import (
    CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED,
    CONSTRAINT_CLAIM_PARENT_UNRESOLVED,
    CONSTRAINT_COVERAGE_PARENT_UNRESOLVED,
    CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED,
    CONSTRAINT_PATIENT_EXTERNAL_ID_INVALID,
    CONSTRAINT_PLAN_PAYER_UNRESOLVED,
    DAT_V2_SKIP_INVALID_PATIENT_ID,
    DAT_V2_SKIP_MISSING_DOS_CLAIM_CHAIN,
    DAT_V2_SKIP_MISSING_PAYER_ANCHOR,
    build_phase_d_dat_v2_compact_flat,
    build_phase_d_v2_domain_metrics,
    empty_executor_v2_stats,
    empty_extractor_v2_stats,
    merge_extractor_v2_stats,
    v2_inc_constraint,
    v2_inc_exec,
    v2_lane_from_row,
)
try:
    from MediCafe.phase_d_developer_unblock import build_invalid_external_patient_id_unblock
except Exception:
    build_invalid_external_patient_id_unblock = None

LAYER1_JOIN_DEBUG_IMPORT_ERROR = None
try:
    from layer1_join_debug import finalize_layer1_qa_summary_fields, write_layer1_join_debug_artifacts
except ImportError as _l1_imp_err:
    LAYER1_JOIN_DEBUG_IMPORT_ERROR = str(_l1_imp_err)
    write_layer1_join_debug_artifacts = None
    finalize_layer1_qa_summary_fields = None


SUPPORTED_PHASE_D_ARTIFACT_CLASSES = ("csv", "jsonl", "837", "dat", "docx", "receipt", "xml")
PATIENT_CANONICAL_TYPES = ("patient_csv_row", "x12_member")
_PHASE_RUN_IDS_WARNING = ""
_PHASE_D_ARTIFACT_SCOPE_POLICY = {}

PHASE_D_SELECTION_SCOPE = "new_artifacts_current_qa_only"


def _layer1_flat_for_qa(bundle, csv_telemetry, dat_telemetry, phase_d_ok_flag):
    if finalize_layer1_qa_summary_fields is None or write_layer1_join_debug_artifacts is None:
        err_msg = ""
        try:
            err_msg = str(LAYER1_JOIN_DEBUG_IMPORT_ERROR or "").strip()
        except Exception:
            err_msg = ""
        if not err_msg:
            err_msg = "layer1_join_debug_import_failed"
        return {
            "layer1_join_debug_generated": False,
            "layer1_join_debug_import_error": err_msg[:512],
        }
    if not bundle:
        return {}
    try:
        return finalize_layer1_qa_summary_fields(
            bundle,
            csv_telemetry if isinstance(csv_telemetry, dict) else {},
            dat_telemetry if isinstance(dat_telemetry, dict) else {},
            phase_d_ok_flag,
        )
    except Exception:
        return {}


def _layer1_write_error_flat(error_detail):
    msg = ""
    try:
        msg = str(error_detail or "").strip()
    except Exception:
        msg = ""
    if not msg:
        msg = "layer1_join_debug_artifact_write_failed"
    return {
        "layer1_join_debug_generated": False,
        "layer1_join_debug_error": msg[:512],
    }


def _sync_phase_d_remediation_safe(lab_root, rid, summary):
    try:
        from phase_d_remediation import sync_phase_d_remediation_after_phase_d
        sync_phase_d_remediation_after_phase_d(lab_root, rid, summary)
    except Exception:
        pass


def _phase_d_entity_scope_from_env():
    """Internal scope: v1 (default) or v2; set by run_shadow_pipeline via unified_rollout_policy."""
    try:
        from scripts.unified_model.unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
    except Exception:
        try:
            from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
        except Exception:
            INTERNAL_PHASE_D_ENTITY_SCOPE_ENV = "MEDICAFE_INTERNAL_PHASE_D_ENTITY_SCOPE"
    v = str(os.environ.get(INTERNAL_PHASE_D_ENTITY_SCOPE_ENV, "") or "").strip().lower()
    if v == "v2":
        return "v2"
    return "v1"


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _normalize_artifact_class_filter(raw):
    """
    Parse artifact-class filter input.
    Accepts comma-separated string or iterable. Unknown classes are ignored.
    """
    if raw is None:
        return []
    values = []
    if isinstance(raw, str):
        values = [v.strip().lower() for v in raw.split(",")]
    elif isinstance(raw, (list, tuple, set)):
        values = [str(v).strip().lower() for v in raw]
    filtered = []
    seen = set()
    for value in values:
        if not value or value in seen:
            continue
        if value in SUPPORTED_PHASE_D_ARTIFACT_CLASSES:
            filtered.append(value)
            seen.add(value)
    return filtered


def _artifact_class_from_payload_json(payload_json):
    """Best-effort artifact_class read from ingest payload JSON."""
    try:
        payload = json.loads(payload_json) if payload_json else {}
    except (ValueError, TypeError):
        return ""
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("artifact_class") or "").strip().lower()


def _filter_rows_by_artifact_classes(rows, artifact_classes):
    """Filter eligible ingest rows by artifact class when filter is provided."""
    if not artifact_classes:
        return list(rows or [])
    allowed = set(artifact_classes)
    out = []
    for row in rows or []:
        payload_json = row[-1] if isinstance(row, (list, tuple)) and len(row) > 0 else ""
        artifact_class = _artifact_class_from_payload_json(payload_json)
        if artifact_class in allowed:
            out.append(row)
    return out


def _phase_run_ids_hint_from_env():
    global _PHASE_RUN_IDS_WARNING
    _PHASE_RUN_IDS_WARNING = ""
    raw = str(os.environ.get("MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON", "") or "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        _PHASE_RUN_IDS_WARNING = "malformed_MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON"
        return {}
    if not isinstance(data, dict):
        _PHASE_RUN_IDS_WARNING = "non_object_MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON"
        return {}
    out = {}
    for phase in ("B", "C", "D", "E"):
        rid = str(data.get(phase, "") or "").strip()
        if rid:
            out[phase] = rid
    return out


def _read_json_dict(path):
    try:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def resolve_phase_d_artifact_scope_policy(lab_root, requested_artifact_classes=None, source="argument"):
    requested = _normalize_artifact_class_filter(requested_artifact_classes)
    state = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    source_map = {"artifact_classes": str(source or "argument")}
    reason = "explicit_artifact_scope" if requested else "default_all_supported"
    classes = requested
    if not classes:
        classes = list(SUPPORTED_PHASE_D_ARTIFACT_CLASSES)
        source_map["artifact_classes"] = "state_evidence"
        reason = "default_from_supported_phase_d_classes"
        try:
            raw = state.get("last_phase_c_ingested_artifact_classes")
            if isinstance(raw, list):
                filtered = _normalize_artifact_class_filter(raw)
                if filtered:
                    classes = filtered
                    reason = "default_from_phase_c_ingest_classes"
        except Exception:
            pass
    return {
        "schema_version": 1,
        "artifact_classes": list(classes),
        "requested_artifact_classes": list(requested),
        "source": str(source or "argument"),
        "effective_policy": {"artifact_classes": list(classes)},
        "policy_source_map": source_map,
        "policy_reason": reason,
    }


def _resolve_phase_c_summary_for_zero_selection(lab_root):
    """
    Coherence-first: pipeline hint C id, then diagnostics phase map C id, else run_cursor.last_phase_c_run_id.
    Returns (run_id_used, path_used, phase_c_summary_dict_or_none, mismatch_warning_str,
             resolution_source_str, expected_phase_c_run_id_str).
    """
    reports_dir = os.path.join(lab_root, "reports")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state = {}
    cursor = {}
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    if not isinstance(state, dict):
        state = {}
    if os.path.isfile(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    if not isinstance(cursor, dict):
        cursor = {}
    run_id_used = ""
    path_used = ""
    resolution_source = ""
    hint = _phase_run_ids_hint_from_env()
    expected_phase_c_run_id = str(hint.get("C", "") or "").strip()
    if expected_phase_c_run_id:
        p = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(expected_phase_c_run_id))
        if os.path.isfile(p):
            path_used = p
            run_id_used = expected_phase_c_run_id
            resolution_source = "pipeline_phase_hint"
    if not path_used:
        pr = state.get("last_shadow_pipeline_phase_run_ids")
        rid_c = ""
        if isinstance(pr, dict):
            rid_c = str(pr.get("C", "") or "").strip()
        if rid_c:
            p = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid_c))
            if os.path.isfile(p):
                path_used = p
                run_id_used = rid_c
                resolution_source = "diagnostics_state_phase_map"
    if not path_used:
        cr = str(cursor.get("last_phase_c_run_id", "") or "").strip()
        if cr:
            p = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(cr))
            if os.path.isfile(p):
                path_used = p
                run_id_used = cr
                resolution_source = "run_cursor"
    if not resolution_source:
        resolution_source = "missing"
    mismatch_parts = []
    cursor_c = str(cursor.get("last_phase_c_run_id", "") or "").strip()
    if expected_phase_c_run_id and run_id_used and expected_phase_c_run_id != run_id_used:
        mismatch_parts.append(
            "pipeline_hint.C={0} vs resolved_phase_c={1}".format(expected_phase_c_run_id, run_id_used)
        )
    if run_id_used and cursor_c and run_id_used != cursor_c:
        mismatch_parts.append(
            "run_cursor.last_phase_c_run_id={0} vs resolved_phase_c={1}".format(cursor_c, run_id_used)
        )
    mismatch = "; ".join(mismatch_parts)
    phase_c_data = None
    if path_used:
        try:
            with open(path_used, "r", encoding="utf-8") as f:
                phase_c_data = json.load(f)
        except Exception:
            phase_c_data = None
    if phase_c_data is not None and not isinstance(phase_c_data, dict):
        phase_c_data = None
    return run_id_used, path_used, phase_c_data, mismatch, resolution_source, expected_phase_c_run_id


def _apply_zero_selection_enrichment(lab_root, summary, n_eligible_before_filter, n_after_filter, artifact_class_filter):
    """Populate zero-selection lineage fields when rows_selected == 0. Mutates summary."""
    rid_used, path_used, pc, mismatch, resolution_source, expected_phase_c_run_id = _resolve_phase_c_summary_for_zero_selection(lab_root)
    summary["phase_c_summary_run_id_used_for_zero_selection"] = rid_used or ""
    summary["phase_c_summary_path_used_for_zero_selection"] = path_used or ""
    summary["phase_c_context_mismatch_warning"] = mismatch or ""
    summary["phase_c_summary_resolution_source"] = resolution_source or ""
    summary["phase_c_expected_run_id_for_zero_selection"] = expected_phase_c_run_id or ""
    summary["phase_c_lineage_coherent"] = (not expected_phase_c_run_id) or (rid_used == expected_phase_c_run_id)
    dup_dom = False
    if isinstance(pc, dict):
        dup_dom = bool(pc.get("phase_c_duplicate_dominant"))
        try:
            ri = int(pc.get("rows_inserted") or 0)
            sk = int(pc.get("rows_skipped_duplicate") or 0)
        except (TypeError, ValueError):
            ri, sk = 0, 0
        if not dup_dom and sk >= max(1, ri):
            dup_dom = True
    snapshot = {}
    try:
        from phase_d_historical_reprocess import collect_phase_d_reject_snapshot
        snapshot = collect_phase_d_reject_snapshot(lab_root, artifact_classes=None, qa_version=None)
    except Exception:
        snapshot = {}
    if not isinstance(snapshot, dict):
        snapshot = {}
    h_by_class = snapshot.get("historical_reject_counts_by_class") if isinstance(snapshot.get("historical_reject_counts_by_class"), dict) else {}
    h_by_ver = snapshot.get("historical_reject_counts_by_version") if isinstance(snapshot.get("historical_reject_counts_by_version"), dict) else {}
    summary["historical_reject_counts_by_class"] = dict(h_by_class)
    summary["historical_reject_counts_by_version"] = dict(h_by_ver)
    tgt = snapshot.get("targeted_artifact_classes") or []
    summary["historical_reprocess_targeted_artifact_classes"] = list(tgt) if isinstance(tgt, list) else []
    hist_exist = False
    if bool(snapshot.get("ok")):
        try:
            tot = sum(int(v or 0) for v in h_by_class.values())
        except Exception:
            tot = 0
        try:
            tac = int(snapshot.get("targeted_artifact_count") or 0)
        except (TypeError, ValueError):
            tac = 0
        hist_exist = tot > 0 or tac > 0
    summary["historical_reprocess_candidate"] = bool(dup_dom) and hist_exist
    reasons = []
    if dup_dom:
        reasons.append("phase_c_duplicate_dominant")
    if n_eligible_before_filter == 0:
        reasons.append("no_unevaluated_artifacts_current_qa")
    if hist_exist:
        reasons.append("historical_rejects_exist")
    acf = list(artifact_class_filter or [])
    if n_eligible_before_filter > 0 and n_after_filter == 0 and len(acf) > 0:
        reasons.append("artifact_class_filter_excluded_all")
    summary["zero_selection_reason_codes"] = reasons
    return summary


def _sort_phase_d_eligible_rows(rows):
    """
    Stable sort: non-dat artifact classes before dat (upstream_first_insert_or_ignore).
    Tie-break by artifact_id ascending.
    """
    rows = list(rows or [])

    def _sort_key(row):
        payload_json = row[-1] if isinstance(row, (list, tuple)) and len(row) > 0 else ""
        artifact_class = _artifact_class_from_payload_json(payload_json)
        tier = 1 if artifact_class == "dat" else 0
        aid = 0
        if isinstance(row, (list, tuple)) and len(row) > 0:
            try:
                aid = int(row[0])
            except (TypeError, ValueError):
                aid = 0
        return (tier, aid)

    return sorted(rows, key=_sort_key)


_DAT_EVIDENCE_KEYS = (
    "source_ref",
    "record_index",
    "attachment_sha256",
    "resolved_patient_id",
    "resolved_date_of_service",
    "resolved_payer_id",
    "resolved_payer_id_source",
    "dat_payer_anchor_status",
    "dat_payer_anchor_keys",
    "dat_payer_anchor_diagnostic",
    "dat_payer_resolution_status",
    "dat_payer_resolution_source",
    "dat_payer_resolution_diagnostic",
    "dat_payer_resolution_insurance_id",
    "dat_payer_resolution_insurance_name_key",
    "dat_payer_resolution_candidate_payer_ids",
    "resolved_chart_number",
    "resolved_insurance_name",
    "resolved_insurance_name_source",
    "resolved_insurance_name_diagnostic_only",
    "resolved_member_id",
    "resolved_patient_name",
    "dat_anchor_decision_blocker_class",
    "dat_anchor_decision_reject_code",
    "dat_anchor_decision_patient_anchor_source",
    "dat_anchor_decision_service_date_source",
    "dat_anchor_decision_payer_anchor_source",
    "dat_anchor_decision_payer_synthetic_from_medisoft_id",
    "dat_anchor_decision_payer_synthetic_from_iname_display",
)


def _merge_dat_context(context, row):
    merged = dict(context or {})
    if not isinstance(row, dict):
        return merged
    for key in _DAT_EVIDENCE_KEYS:
        if key not in row:
            continue
        value = row.get(key)
        if value is None:
            continue
        if isinstance(value, str):
            value = value.strip()
            if not value:
                continue
        merged[key] = value
    return merged


def _merge_planning_with_join_telemetry(planning_telemetry, dat_csv_join, csv_docx_join, constraint_skip_counts):
    """Enrich Phase D planning telemetry with join + invalid-ID breakdown (summary / bundles)."""
    pt = json.loads(json.dumps(planning_telemetry)) if planning_telemetry else {}
    if not isinstance(pt, dict):
        pt = {}
    wc = pt.get("workstream_c") if isinstance(pt.get("workstream_c"), dict) else {}
    wc = dict(wc)
    dc = dat_csv_join if isinstance(dat_csv_join, dict) else {}
    cx = csv_docx_join if isinstance(csv_docx_join, dict) else {}
    wc["invalid_external_id_csv_count"] = int(dc.get("invalid_external_id_csv_count") or 0)
    wc["invalid_external_id_dat_count"] = int(dc.get("invalid_external_id_dat_count") or 0)
    wc["invalid_external_id_join_block_count"] = int(dc.get("invalid_external_id_join_block_count") or 0)
    by_family = (constraint_skip_counts or {}).get("patient_invalid_external_id_by_pattern_family") or {}
    if isinstance(by_family, dict) and by_family:
        top_families = sorted(by_family.items(), key=lambda kv: (-int(kv[1] or 0), kv[0]))[:8]
        wc["leading_invalid_id_pattern_families"] = [str(f[0]) for f in top_families if f[0]]
    by_ac = (constraint_skip_counts or {}).get("patient_invalid_external_id_by_artifact_class") or {}
    if isinstance(by_ac, dict) and by_ac:
        top_ac = sorted(by_ac.items(), key=lambda kv: (-int(kv[1] or 0), kv[0]))[:8]
        wc["leading_invalid_id_artifact_classes"] = [str(a[0]) for a in top_ac if a[0]]
    pt["workstream_c"] = wc
    pt["dat_csv_join_primary_blocker"] = str(dc.get("primary_join_blocker_class") or "")
    pt["csv_docx_join_primary_blocker"] = str(cx.get("primary_join_blocker_class") or "")
    matched_d = int(dc.get("matched_count") or 0)
    if matched_d == 0 and (int(dc.get("csv_only_count") or 0) > 0 or int(dc.get("invalid_external_id_csv_count") or 0) > 0):
        wc["phase_d_join_issue_code"] = PHASE_D_DAT_CSV_JOIN_ZERO_MATCHES
    matched_x = int(cx.get("matched_count") or 0)
    if matched_x == 0 and int(cx.get("csv_join_key_count") or 0) > 0:
        wc["phase_d_csv_docx_join_issue_code"] = PHASE_D_CSV_DOCX_JOIN_ZERO_MATCHES
    return pt


def _log_extractor_skip_events(conn, skip_events):
    for event in skip_events or []:
        if not isinstance(event, dict):
            continue
        conn.execute(
            "INSERT INTO rule_decision_log (artifact_id, decision_type, decision_context_json) VALUES (?, ?, ?)",
            (
                event.get("artifact_id") or 0,
                "extractor_skip",
                json.dumps(event, separators=(",", ":"), ensure_ascii=True),
            ),
        )


def _empty_constraint_skip_counts():
    return {
        "patient_invalid_external_id": 0,
        "patient_invalid_external_id_by_source": {},
        "patient_invalid_external_id_by_pattern_family": {},
        "patient_invalid_external_id_by_artifact_class": {},
        "patient_invalid_external_id_by_source_contract": {},
        "patient_invalid_external_id_by_contract_disposition": {},
        "patient_invalid_external_id_pattern": EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN,
    }


def _merge_invalid_id_diagnostics(context, invalid_id_diag):
    if not isinstance(context, dict) or not isinstance(invalid_id_diag, dict):
        return context
    context["invalid_external_patient_id_pattern"] = invalid_id_diag.get("pattern") or ""
    context["invalid_external_patient_id_source"] = invalid_id_diag.get("source") or ""
    context["invalid_external_patient_id_value"] = invalid_id_diag.get("value") or ""
    context["invalid_external_patient_id_raw_value"] = invalid_id_diag.get("raw_value") or ""
    context["invalid_external_patient_id_reason"] = invalid_id_diag.get("reason") or ""
    context["invalid_external_patient_id_pattern_family"] = invalid_id_diag.get("pattern_family") or ""
    context["invalid_external_patient_id_raw_shape"] = invalid_id_diag.get("raw_shape") or ""
    context["invalid_external_patient_id_length"] = int(invalid_id_diag.get("length") or 0)
    return context


def _increment_invalid_id_source_counts(constraint_skip_counts, invalid_id_diag):
    if not isinstance(constraint_skip_counts, dict):
        return
    by_source = constraint_skip_counts.setdefault("patient_invalid_external_id_by_source", {})
    if not isinstance(by_source, dict):
        by_source = {}
        constraint_skip_counts["patient_invalid_external_id_by_source"] = by_source
    source = "external_patient_id"
    pattern_family = "unknown"
    if isinstance(invalid_id_diag, dict):
        source = str(invalid_id_diag.get("source") or source)
        pattern_family = str(invalid_id_diag.get("pattern_family") or pattern_family)
    by_source[source] = int(by_source.get(source, 0) or 0) + 1
    by_family = constraint_skip_counts.setdefault("patient_invalid_external_id_by_pattern_family", {})
    if not isinstance(by_family, dict):
        by_family = {}
        constraint_skip_counts["patient_invalid_external_id_by_pattern_family"] = by_family
    by_family[pattern_family] = int(by_family.get(pattern_family, 0) or 0) + 1
    by_ac = constraint_skip_counts.setdefault("patient_invalid_external_id_by_artifact_class", {})
    if not isinstance(by_ac, dict):
        by_ac = {}
        constraint_skip_counts["patient_invalid_external_id_by_artifact_class"] = by_ac
    ac = "unknown"
    if isinstance(invalid_id_diag, dict):
        ac = str(invalid_id_diag.get("artifact_class") or invalid_id_diag.get("source_artifact_class") or "unknown")
    by_ac[ac] = int(by_ac.get(ac, 0) or 0) + 1
    by_contract = constraint_skip_counts.setdefault("patient_invalid_external_id_by_source_contract", {})
    if not isinstance(by_contract, dict):
        by_contract = {}
        constraint_skip_counts["patient_invalid_external_id_by_source_contract"] = by_contract
    source_contract = external_patient_id_source_contract(source)
    by_contract[source_contract] = int(by_contract.get(source_contract, 0) or 0) + 1
    by_disposition = constraint_skip_counts.setdefault("patient_invalid_external_id_by_contract_disposition", {})
    if not isinstance(by_disposition, dict):
        by_disposition = {}
        constraint_skip_counts["patient_invalid_external_id_by_contract_disposition"] = by_disposition
    disposition = external_patient_id_contract_disposition(invalid_id_diag)
    by_disposition[disposition] = int(by_disposition.get(disposition, 0) or 0) + 1
    constraint_skip_counts["patient_invalid_external_id_pattern"] = EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN


def _log_constraint_fail(conn, artifact_id, row, reason_code, reason, v2_exec_stats=None, invalid_id_diag=None):
    """Persist deterministic constraint-fail evidence to rule_decision_log."""
    context = _merge_dat_context({
        "entity": "patient",
        "constraint_name": "external_patient_id_5_digit",
        "reason_code": reason_code,
        "reason": reason,
        "patient_key": row.get("patient_key") or "",
        "external_patient_id": row.get("external_patient_id") or "",
        "canonical_type": row.get("canonical_type") or "",
        "source_artifact_class": row.get("canonical_type") or "",
        "source_alias": row.get("external_patient_id_source") or row.get("canonical_type") or "",
        "canonical_key": row.get("canonical_key") or "",
        "source_system": row.get("source_system") or "xp_local",
    }, row)
    if row.get("record_index") is not None:
        context["record_index"] = row.get("record_index")
    if row.get("attachment_sha256"):
        context["attachment_sha256"] = row.get("attachment_sha256")
    context = _merge_invalid_id_diagnostics(context, invalid_id_diag)
    conn.execute(
        "INSERT INTO rule_decision_log (artifact_id, decision_type, decision_context_json) VALUES (?, ?, ?)",
        (
            artifact_id,
            "constraint_fail",
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )
    if v2_exec_stats is not None:
        lane = v2_lane_from_row(context)
        if lane and reason_code:
            v2_inc_constraint(v2_exec_stats, lane, str(reason_code), 1)

def _build_planning_telemetry(canonical_records, reject_counts_by_code, reject_counts_by_artifact_code,
                             constraint_skip_counts):
    """Build telemetry snapshot used to evaluate deferred workstream need."""
    canonical_counts = {}
    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        if not ctype:
            continue
        canonical_counts[ctype] = canonical_counts.get(ctype, 0) + 1

    identity_total = int((reject_counts_by_code or {}).get("QA_IDENTITY_INCOMPLETE", 0))
    identity_837 = int((reject_counts_by_artifact_code or {}).get("837|QA_IDENTITY_INCOMPLETE", 0))
    remittance_rows = int(canonical_counts.get("remittance_row", 0))
    non_patient_total = 0
    for ctype, count in canonical_counts.items():
        if ctype not in PATIENT_CANONICAL_TYPES:
            non_patient_total += int(count or 0)

    invalid_external_id = int((constraint_skip_counts or {}).get("patient_invalid_external_id", 0))
    invalid_by_source = (constraint_skip_counts or {}).get("patient_invalid_external_id_by_source") or {}
    if not isinstance(invalid_by_source, dict):
        invalid_by_source = {}
    invalid_by_family = (constraint_skip_counts or {}).get("patient_invalid_external_id_by_pattern_family") or {}
    if not isinstance(invalid_by_family, dict):
        invalid_by_family = {}
    invalid_by_contract = (constraint_skip_counts or {}).get("patient_invalid_external_id_by_source_contract") or {}
    if not isinstance(invalid_by_contract, dict):
        invalid_by_contract = {}
    invalid_by_disposition = (constraint_skip_counts or {}).get("patient_invalid_external_id_by_contract_disposition") or {}
    if not isinstance(invalid_by_disposition, dict):
        invalid_by_disposition = {}
    return {
        "workstream_b": {
            "qa_identity_incomplete_rejects_total": identity_total,
            "qa_identity_incomplete_rejects_837": identity_837,
            "activation_recommended": bool(identity_837 > 0),
            "activation_rule": "activate_if_identity_incomplete_837_gt_0",
        },
        "workstream_c": {
            "invalid_external_patient_id_count": invalid_external_id,
            "invalid_external_patient_id_pattern": EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN,
            "invalid_external_patient_id_by_source": dict(invalid_by_source),
            "invalid_external_patient_id_by_pattern_family": dict(invalid_by_family),
            "invalid_external_patient_id_by_source_contract": dict(invalid_by_contract),
            "invalid_external_patient_id_by_contract_disposition": dict(invalid_by_disposition),
            "activation_recommended": bool(invalid_external_id > 0),
            "activation_rule": "activate_if_invalid_external_id_gt_0",
        },
        "workstream_d": {
            "canonical_count_remittance_row": remittance_rows,
            "canonical_count_non_patient_total": non_patient_total,
            "activation_recommended": bool(remittance_rows > 0),
            "activation_rule": "activate_if_remittance_row_gt_0",
        },
    }


def _build_dat_telemetry(dat_selected_count, dat_qa_pass_count, dat_qa_reject_count,
                         dat_reject_counts_by_reason, canonical_records, entity_upsert_counts,
                         entity_scope, dat_v2_compact_flat=None, dat_field_presence=None,
                         dat_parse_diagnostics=None, dat_file_prefix_counts=None,
                         dat_reject_file_prefix_counts=None, dat_candidate_count=0,
                         dat_pre_qa_skipped_count=0, dat_pre_qa_skip_counts_by_reason=None,
                         dat_pre_qa_skip_file_prefix_counts=None,
                         dat_pre_qa_terminal_result_count=0,
                         dat_anchor_diagnostics=None, dat_file_shape_diagnostics=None):
    """Build DAT-specific funnel telemetry for Phase D summaries."""
    dat_canonical_record_count = 0
    for rec in canonical_records or []:
        if rec.get("canonical_type") == "dat_record":
            dat_canonical_record_count += 1
    post_medisoft_exercised = bool(
        dat_selected_count > 0 and (dat_qa_pass_count > 0 or dat_canonical_record_count > 0)
    )
    if post_medisoft_exercised:
        blocked_stage = ""
    elif dat_qa_reject_count > 0:
        blocked_stage = "qa"
    elif int(dat_pre_qa_terminal_result_count or 0) > 0:
        blocked_stage = "pre_qa_terminal_skip"
    elif dat_selected_count > 0:
        blocked_stage = "canonicalization"
    else:
        blocked_stage = "not_exercised"
    telem = {
        "dat_selected_count": int(dat_selected_count or 0),
        "dat_candidate_count": int(dat_candidate_count or 0),
        "dat_pre_qa_skipped_count": int(dat_pre_qa_skipped_count or 0),
        "dat_pre_qa_skip_counts_by_reason": dat_pre_qa_skip_counts_by_reason or {},
        "dat_pre_qa_skip_file_prefix_counts": dat_pre_qa_skip_file_prefix_counts or {},
        "dat_pre_qa_terminal_result_count": int(dat_pre_qa_terminal_result_count or 0),
        "dat_pre_qa_terminal_result_counts_by_reason": dat_pre_qa_skip_counts_by_reason or {},
        "dat_empty_file_skipped_count": int((dat_pre_qa_skip_counts_by_reason or {}).get(QA_DAT_EMPTY_FILE, 0) or 0),
        "dat_qa_pass_count": int(dat_qa_pass_count or 0),
        "dat_qa_reject_count": int(dat_qa_reject_count or 0),
        "dat_qa_reject_counts_by_reason": dat_reject_counts_by_reason or {},
        "dat_field_presence_by_alias": dat_field_presence or {},
        "dat_parse_diagnostics": dat_parse_diagnostics or {},
        "dat_anchor_diagnostics": dat_anchor_diagnostics or {},
        "dat_file_shape_diagnostics": dat_file_shape_diagnostics or {},
        "dat_file_prefix_counts": dat_file_prefix_counts or {},
        "dat_reject_file_prefix_counts": dat_reject_file_prefix_counts or {},
        "dat_canonical_record_count": dat_canonical_record_count,
        "phase_d_entity_scope": str(entity_scope or "v1"),
        "dat_entity_upsert_counts": entity_upsert_counts or {},
        "post_medisoft_exercised": post_medisoft_exercised,
        "post_medisoft_blocked_stage": blocked_stage,
    }
    if isinstance(dat_v2_compact_flat, dict):
        for k, v in dat_v2_compact_flat.items():
            telem[k] = v
    return telem


def _dat_alias_presence_counts_from_envelope(envelope):
    """
    Record-level alias presence counters for DAT parser mismatch triage.
    """
    counters = {
        "records_seen": 0,
        "PATID": 0,
        "patid_present_count": 0,
        "patient_id": 0,
        "patient_id_present_count": 0,
        "DOS": 0,
        "dos_present_count": 0,
        "DATE1": 0,
        "date1_present_count": 0,
        "DATE": 0,
        "date_present_count": 0,
        "date_of_service": 0,
        "date_of_service_present_count": 0,
        "PAYERID": 0,
        "payerid_present_count": 0,
        "INSID": 0,
        "insid_present_count": 0,
        "payer_id": 0,
        "payer_id_present_count": 0,
        "INAME": 0,
        "iname_present_count": 0,
        "insurance_name": 0,
        "insurance_name_present_count": 0,
        "CHART": 0,
        "chart_present_count": 0,
        "chart_number": 0,
        "chart_number_present_count": 0,
    }
    records = envelope.get("records") if isinstance(envelope, dict) else None
    if not isinstance(records, list):
        return counters
    for rec in records:
        if not isinstance(rec, dict):
            continue
        counters["records_seen"] += 1
        for key in ("PATID", "patient_id", "DOS", "DATE1", "DATE", "date_of_service",
                    "PAYERID", "INSID", "payer_id", "INAME", "insurance_name", "CHART", "chart_number"):
            value = rec.get(key)
            if value is None:
                continue
            if str(value).strip():
                counters[key] += 1
    count_aliases = (
        ("PATID", "patid_present_count"),
        ("patient_id", "patient_id_present_count"),
        ("DOS", "dos_present_count"),
        ("DATE1", "date1_present_count"),
        ("DATE", "date_present_count"),
        ("date_of_service", "date_of_service_present_count"),
        ("PAYERID", "payerid_present_count"),
        ("INSID", "insid_present_count"),
        ("payer_id", "payer_id_present_count"),
        ("INAME", "iname_present_count"),
        ("insurance_name", "insurance_name_present_count"),
        ("CHART", "chart_present_count"),
        ("chart_number", "chart_number_present_count"),
    )
    for legacy_key, safe_key in count_aliases:
        counters[safe_key] = int(counters.get(legacy_key, 0) or 0)
    return counters


def _dat_anchor_diagnostics_from_envelope(envelope):
    """
    Safe aggregate DAT anchor facts. CHART is diagnostic-only; the patient
    anchor remains the 5-digit PATID/patient_id contract.
    """
    counters = {
        "records_seen": 0,
        "patient_anchor_present_count": 0,
        "patient_anchor_missing_count": 0,
        "chart_present_count": 0,
        "chart_without_patient_anchor_count": 0,
        "chart_used_as_patient_anchor_count": 0,
        "payer_anchor_present_count": 0,
        "payer_anchor_missing_count": 0,
        "patient_anchor_contract": "requires_5_digit_patid",
        "chart_role": "supplemental_not_patient_anchor",
        "chart_anchor_usable": False,
    }
    records = envelope.get("records") if isinstance(envelope, dict) else None
    if not isinstance(records, list):
        return counters
    for rec in records:
        if not isinstance(rec, dict):
            continue
        counters["records_seen"] += 1
        resolved = resolve_dat_fields(rec)
        patient_id = str(resolved.get("patient_id") or "").strip()
        chart = str(resolved.get("chart_number") or "").strip()
        payer_id = str(resolved.get("payer_id") or "").strip()
        if patient_id:
            counters["patient_anchor_present_count"] += 1
        else:
            counters["patient_anchor_missing_count"] += 1
        if chart:
            counters["chart_present_count"] += 1
            if not patient_id:
                counters["chart_without_patient_anchor_count"] += 1
        if payer_id:
            counters["payer_anchor_present_count"] += 1
        else:
            counters["payer_anchor_missing_count"] += 1
    return counters


def _merge_dat_anchor_diagnostics(base, add):
    if not isinstance(base, dict) or not isinstance(add, dict):
        return base
    for key in ("records_seen", "patient_anchor_present_count", "patient_anchor_missing_count",
                "chart_present_count", "chart_without_patient_anchor_count",
                "chart_used_as_patient_anchor_count", "payer_anchor_present_count",
                "payer_anchor_missing_count"):
        try:
            base[key] = int(base.get(key, 0) or 0) + int(add.get(key, 0) or 0)
        except Exception:
            pass
    base["patient_anchor_contract"] = "requires_5_digit_patid"
    base["chart_role"] = "supplemental_not_patient_anchor"
    base["chart_anchor_usable"] = False
    return base


def _merge_counter_dict(base, add):
    """In-place sum merge for integer-like telemetry dicts."""
    if not isinstance(base, dict) or not isinstance(add, dict):
        return base
    for key, value in add.items():
        try:
            inc = int(value or 0)
        except Exception:
            continue
        base[key] = int(base.get(key, 0) or 0) + inc
    return base


def _append_limited_sample(samples, value, limit=3):
    if not isinstance(samples, list):
        return
    text_value = str(value or '').strip()
    if not text_value or text_value in samples:
        return
    if len(samples) < int(limit or 0):
        samples.append(text_value)


def _file_prefix_from_locator(locator):
    return dat_file_prefix_from_locator(locator)


def _merge_dat_parse_diagnostics(base, envelope):
    diag = envelope.get('parser_diagnostics', {}) if isinstance(envelope, dict) else {}
    if not isinstance(base, dict) or not isinstance(diag, dict):
        return base
    base['tuple_parse_failure_count'] = int(base.get('tuple_parse_failure_count', 0) or 0) + int(diag.get('tuple_parse_failure_count', 0) or 0)
    if not str(base.get('first_failure_class', '') or '').strip() and str(diag.get('first_failure_class', '') or '').strip():
        base['first_failure_class'] = str(diag.get('first_failure_class', '') or '').strip()
    if not str(base.get('first_failure_detail', '') or '').strip() and str(diag.get('first_failure_detail', '') or '').strip():
        base['first_failure_detail'] = str(diag.get('first_failure_detail', '') or '').strip()
    _merge_counter_dict(base.get('record_shape_counts', {}), diag.get('record_shape_counts', {}))
    for item in diag.get('raw_key_sets_sample', []) if isinstance(diag.get('raw_key_sets_sample', []), list) else []:
        _append_limited_sample(base.get('raw_key_sets_sample', []), item, limit=3)
    return base


def _select_dat_sample_record(records):
    first_dict = (None, None)
    for idx, rec in enumerate(records or []):
        if not isinstance(rec, dict):
            continue
        if first_dict[0] is None:
            first_dict = (rec, idx)
        resolved = resolve_dat_fields(rec)
        if any(str(resolved.get(key, '') or '').strip() for key in ('patient_id', 'chart_number', 'date_of_service', 'payer_id', 'patient_name', 'first_name', 'last_name')):
            return (rec, idx)
    return first_dict


def _build_dat_reject_sample(artifact_id, reject_code, reject_reason, envelope, locator, source_ref, attachment_sha256, parse_diag=None):
    sample = {
        "artifact_id": artifact_id,
        "reject_code": reject_code,
        "reason": reject_reason,
        "locator": str(locator or '')[:80],
        "locator_full": str(locator or ''),
        "artifact_name": dat_locator_basename(locator),
        "dat_file_prefix": _file_prefix_from_locator(locator),
        "dat_filename_timestamp_guess": dat_filename_timestamp_guess(locator),
        "locator_mtime_utc": dat_file_mtime_utc(locator),
        "source_ref": str(source_ref or ''),
        "attachment_sha256": str(attachment_sha256 or ''),
        "manifest_row_index": None,
        "manifest_locator": "",
        "manifest_normalized_path": "",
        "manifest_match_status": "",
    }
    if isinstance(parse_diag, dict) and parse_diag:
        sample["parse_diag"] = parse_diag
    if not isinstance(envelope, dict):
        return sample
    sample["record_count"] = int(envelope.get("record_count", 0) or 0)
    meta = dat_envelope_parse_metadata_dict(envelope, str(locator or ""))
    sample["parse_status"] = meta.get("status")
    sample["parser_name"] = meta.get("parser")
    sample["parser_version"] = meta.get("parser_version")
    sample["file_size_bytes"] = int(meta.get("file_size_bytes") or 0)
    sample["dat_parse_diagnostics"] = meta
    parser_diag = envelope.get("parser_diagnostics", {}) if isinstance(envelope.get("parser_diagnostics", {}), dict) else {}
    if parser_diag.get("raw_key_sets_sample"):
        sample["raw_key_sets_sample"] = list(parser_diag.get("raw_key_sets_sample", []))[:3]
    rec, record_index = _select_dat_sample_record(envelope.get("records") if isinstance(envelope.get("records"), list) else [])
    if isinstance(rec, dict):
        context = build_dat_decision_context(rec, provenance={
            "source_ref": source_ref,
            "record_index": record_index,
            "attachment_sha256": attachment_sha256,
        })
        sample.update(context)
        decision = build_dat_anchor_decision(rec, provenance={
            "source_ref": source_ref,
            "record_index": record_index,
            "attachment_sha256": attachment_sha256,
        })
        sample["dat_anchor_decision_blocker_class"] = decision.get("blocker_class") or ""
        sample["dat_anchor_decision_reject_code"] = decision.get("reject_code") or ""
        sample["dat_anchor_decision_patient_anchor_source"] = decision.get("patient_anchor_source") or ""
        sample["dat_anchor_decision_service_date_source"] = decision.get("service_date_source") or ""
        sample["dat_anchor_decision_payer_anchor_source"] = decision.get("payer_anchor_source") or ""
        sample["dat_anchor_decision_payer_synthetic_from_medisoft_id"] = bool(
            decision.get("payer_anchor_synthetic_from_medisoft_id"))
        sample["dat_anchor_decision_payer_synthetic_from_iname_display"] = bool(
            decision.get("payer_anchor_synthetic_from_iname_display"))
        sample["dat_anchor_decision_safe_shape_evidence"] = decision.get("safe_shape_evidence") or {}
        raw_keys = sorted([str(key) for key in rec.keys() if str(key or '').strip()])
        if raw_keys:
            sample["raw_keys"] = raw_keys[:12]
            sample["raw_key_count"] = len(raw_keys)
            critical_raw_keys = []
            for key in ("PATID", "patient_id", "patid", "CHART", "DATE", "DATE1", "DOS", "PAYERID", "INSID", "payer_id"):
                if key in rec and key not in critical_raw_keys:
                    critical_raw_keys.append(key)
            if critical_raw_keys:
                sample["critical_raw_keys"] = critical_raw_keys
    return sample


def _append_layer1_relaxed_dat_candidates(out, artifact_id, envelope, locator, source_ref, attachment_sha256):
    """
    Add debug-only DAT rows that have enough identity to test Layer 1 PATID+DATE.
    This does not create canonical records or relax the strict DAT QA contract.
    """
    if not isinstance(out, list) or not isinstance(envelope, dict):
        return
    records = envelope.get("records")
    if not isinstance(records, list):
        return
    for idx, rec in enumerate(records):
        if not isinstance(rec, dict):
            continue
        resolved = resolve_dat_fields(rec)
        pid = str(resolved.get("patient_id") or "").strip()
        dos = str(resolved.get("date_of_service") or "").strip()
        if not pid or not dos:
            continue
        provenance = {
            "source_ref": source_ref,
            "locator": locator,
            "record_index": idx,
            "attachment_sha256": attachment_sha256,
            "debug_only": True,
            "debug_policy": "layer1_relaxed_dat_candidate",
        }
        out.append({
            "canonical_type": "dat_record",
            "artifact_id": artifact_id,
            "canonical_json": json.dumps(rec, separators=(",", ":"), ensure_ascii=True),
            "provenance_json": json.dumps(provenance, separators=(",", ":"), ensure_ascii=True),
        })


def _ensure_rule_decision_log_supports_extractor_skip(conn):
    """Upgrade legacy rule_decision_log CHECK constraint to allow extractor_skip."""
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='rule_decision_log'"
    ).fetchone()
    create_sql = (
        "CREATE TABLE IF NOT EXISTS rule_decision_log ("
        "decision_id INTEGER PRIMARY KEY,"
        "artifact_id INTEGER,"
        "mapping_rule_id INTEGER,"
        "constraint_rule_id INTEGER,"
        "decision_type TEXT NOT NULL CHECK (decision_type IN ('mapping_applied','constraint_pass','constraint_fail','manual_override','extractor_skip')),"
        "decision_context_json TEXT,"
        "created_at TEXT NOT NULL DEFAULT (datetime('now')),"
        "FOREIGN KEY (artifact_id) REFERENCES ingest_artifact(artifact_id) ON DELETE SET NULL,"
        "FOREIGN KEY (mapping_rule_id) REFERENCES mapping_rule(mapping_rule_id) ON DELETE SET NULL,"
        "FOREIGN KEY (constraint_rule_id) REFERENCES constraint_rule(constraint_rule_id) ON DELETE SET NULL"
        ")"
    )
    if not row or not row[0]:
        conn.execute(create_sql)
        return
    existing_sql = str(row[0] or "")
    if "extractor_skip" in existing_sql:
        return
    conn.execute("ALTER TABLE rule_decision_log RENAME TO rule_decision_log_legacy")
    conn.execute(create_sql)
    conn.execute(
        "INSERT INTO rule_decision_log (decision_id, artifact_id, mapping_rule_id, constraint_rule_id, decision_type, decision_context_json, created_at) "
        "SELECT decision_id, artifact_id, mapping_rule_id, constraint_rule_id, decision_type, decision_context_json, created_at "
        "FROM rule_decision_log_legacy"
    )
    conn.execute("DROP TABLE rule_decision_log_legacy")


def _ensure_planning_telemetry_table(conn):
    """Create planning telemetry table when missing for backward-compatible lab DBs."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS qa_planning_telemetry_log ("
        "telemetry_id INTEGER PRIMARY KEY,"
        "qa_stage TEXT NOT NULL,"
        "qa_version TEXT NOT NULL,"
        "canonicalization_version TEXT NOT NULL,"
        "telemetry_json TEXT NOT NULL,"
        "created_at TEXT NOT NULL DEFAULT (datetime('now'))"
        ")"
    )

def _log_planning_telemetry(conn, telemetry):
    """Persist planning telemetry snapshot to dedicated planning telemetry log."""
    _ensure_planning_telemetry_table(conn)
    context = {
        "event": "planning_telemetry_snapshot",
        "qa_stage": QA_STAGE_PHASE_D,
        "qa_version": QA_POLICY_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "telemetry": telemetry,
    }
    conn.execute(
        "INSERT INTO qa_planning_telemetry_log (qa_stage, qa_version, canonicalization_version, telemetry_json) "
        "VALUES (?, ?, ?, ?)",
        (
            QA_STAGE_PHASE_D,
            QA_POLICY_VERSION,
            CANONICALIZATION_VERSION,
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )


def _log_join_negotiation(conn, event_name, telemetry, run_id_param):
    """Persist join-negotiation evidence (csv_docx or dat_csv); returns telemetry_id or None."""
    telemetry = telemetry or {}
    if event_name == EVENT_CSV_DOCX_JOIN_NEGOTIATION:
        if not csv_docx_needs_negotiation_log(telemetry):
            return None
    elif event_name == EVENT_DAT_CSV_JOIN_NEGOTIATION:
        if not dat_csv_needs_negotiation_log(telemetry):
            return None
    else:
        return None
    _ensure_planning_telemetry_table(conn)
    context = {
        "event": event_name,
        "run_id": str(run_id_param or ""),
        "qa_stage": QA_STAGE_PHASE_D,
        "qa_version": QA_POLICY_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "telemetry": telemetry,
    }
    cur = conn.execute(
        "INSERT INTO qa_planning_telemetry_log (qa_stage, qa_version, canonicalization_version, telemetry_json) "
        "VALUES (?, ?, ?, ?)",
        (
            QA_STAGE_PHASE_D,
            QA_POLICY_VERSION,
            CANONICALIZATION_VERSION,
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )
    return cur.lastrowid


def _log_constraint_fail_spec(conn, artifact_id, context, row=None, v2_exec_stats=None):
    """rule_decision_log row with arbitrary JSON context (Phase D v2 spec-aligned fields)."""
    context = _merge_dat_context(context, row)
    conn.execute(
        "INSERT INTO rule_decision_log (artifact_id, decision_type, decision_context_json) VALUES (?, ?, ?)",
        (
            artifact_id,
            "constraint_fail",
            json.dumps(context, separators=(",", ":"), ensure_ascii=True),
        ),
    )
    if v2_exec_stats is not None and isinstance(context, dict):
        lane = v2_lane_from_row(context)
        rc = context.get("reason_code") or ""
        if lane and rc:
            v2_inc_constraint(v2_exec_stats, lane, str(rc), 1)

def _scalar_id(conn, sql, args):
    cur = conn.execute(sql, args)
    row = cur.fetchone()
    return row[0] if row else None


def _execute_domain_upserts_v2_chain(conn, domain_upsert_rows, counts, v2_exec_stats=None):
    """After patients: payer -> insurance_plan -> coverage -> encounter -> claim -> claim_line."""
    seen_payer = set()
    for row in domain_upsert_rows.get("payer") or []:
        pay_key = row.get("payer_key")
        if not pay_key or pay_key in seen_payer:
            continue
        seen_payer.add(pay_key)
        lane = v2_lane_from_row(row)
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "payer", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO payer (payer_key, payer_external_id, payer_name, endpoint_name) "
            "VALUES (?, ?, ?, ?)",
            (
                pay_key,
                row.get("payer_external_id"),
                row.get("payer_name"),
                row.get("endpoint_name") or "xp_local",
            ),
        )
        if cur.rowcount > 0:
            counts["payer"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "payer", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "payer", "ignored_duplicate", 1)

    seen_plan = set()
    for row in domain_upsert_rows.get("insurance_plan") or []:
        plan_key = row.get("plan_key")
        if not plan_key or plan_key in seen_plan:
            continue
        seen_plan.add(plan_key)
        pay_key = row.get("payer_key")
        lane = v2_lane_from_row(row)
        payer_id = _scalar_id(conn, "SELECT payer_id FROM payer WHERE payer_key=?", (pay_key,))
        if payer_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "insurance_plan",
                    "constraint_name": "payer_fk",
                    "reason_code": CONSTRAINT_PLAN_PAYER_UNRESOLVED,
                    "reason": "payer row missing for plan_key",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "plan_key": plan_key or "",
                    "payer_key": pay_key or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "insurance_plan", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO insurance_plan (plan_key, payer_id, medisoft_insurance_ids_json) "
            "VALUES (?, ?, ?)",
            (plan_key, payer_id, row.get("medisoft_insurance_ids_json") or "[]"),
        )
        if cur.rowcount > 0:
            counts["insurance_plan"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "insurance_plan", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "insurance_plan", "ignored_duplicate", 1)

    seen_cov = set()
    for row in domain_upsert_rows.get("coverage") or []:
        ckey = row.get("coverage_key")
        if not ckey or ckey in seen_cov:
            continue
        seen_cov.add(ckey)
        lane = v2_lane_from_row(row)
        patient_id = _scalar_id(conn, "SELECT patient_id FROM patient WHERE patient_key=?", (row.get("patient_key"),))
        plan_id = _scalar_id(conn, "SELECT plan_id FROM insurance_plan WHERE plan_key=?", (row.get("plan_key"),))
        if patient_id is None or plan_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "coverage",
                    "constraint_name": "coverage_parent_fk",
                    "reason_code": CONSTRAINT_COVERAGE_PARENT_UNRESOLVED,
                    "reason": "patient or plan missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "patient_key": row.get("patient_key") or "",
                    "plan_key": row.get("plan_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "coverage", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO coverage (coverage_key, patient_id, plan_id, effective_start, effective_end, active_flag) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                ckey,
                patient_id,
                plan_id,
                row.get("effective_start"),
                row.get("effective_end"),
                int(row.get("active_flag") or 1),
            ),
        )
        if cur.rowcount > 0:
            counts["coverage"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "coverage", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "coverage", "ignored_duplicate", 1)

    seen_enc = set()
    for row in domain_upsert_rows.get("encounter") or []:
        ekey = row.get("encounter_key")
        if not ekey or ekey in seen_enc:
            continue
        seen_enc.add(ekey)
        lane = v2_lane_from_row(row)
        patient_id = _scalar_id(conn, "SELECT patient_id FROM patient WHERE patient_key=?", (row.get("patient_key"),))
        if patient_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "encounter",
                    "constraint_name": "encounter_patient_fk",
                    "reason_code": CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED,
                    "reason": "patient missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "patient_key": row.get("patient_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "encounter", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO encounter (encounter_key, patient_id, date_of_service, source_artifact_id, diagnosis_code, eye_side) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                ekey,
                patient_id,
                row.get("date_of_service"),
                row.get("source_artifact_id"),
                row.get("diagnosis_code"),
                row.get("eye_side"),
            ),
        )
        if cur.rowcount > 0:
            counts["encounter"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "encounter", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "encounter", "ignored_duplicate", 1)

    seen_claim = set()
    for row in domain_upsert_rows.get("claim") or []:
        ck = row.get("claim_key")
        if not ck or ck in seen_claim:
            continue
        seen_claim.add(ck)
        lane = v2_lane_from_row(row)
        encounter_id = _scalar_id(
            conn, "SELECT encounter_id FROM encounter WHERE encounter_key=?", (row.get("encounter_key"),)
        )
        payer_id = _scalar_id(conn, "SELECT payer_id FROM payer WHERE payer_key=?", (row.get("payer_key"),))
        if encounter_id is None or payer_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "claim",
                    "constraint_name": "claim_parent_fk",
                    "reason_code": CONSTRAINT_CLAIM_PARENT_UNRESOLVED,
                    "reason": "encounter or payer missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "encounter_key": row.get("encounter_key") or "",
                    "payer_key": row.get("payer_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO claim (claim_key, encounter_id, payer_id, claim_number, status, "
            "charged_amount, allowed_amount, paid_amount, patient_resp_amount, source_artifact_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                ck,
                encounter_id,
                payer_id,
                row.get("claim_number"),
                row.get("status"),
                row.get("charged_amount"),
                row.get("allowed_amount"),
                row.get("paid_amount"),
                row.get("patient_resp_amount"),
                row.get("source_artifact_id"),
            ),
        )
        if cur.rowcount > 0:
            counts["claim"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "claim", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim", "ignored_duplicate", 1)

    seen_line = set()
    for row in domain_upsert_rows.get("claim_line") or []:
        lk = row.get("claim_line_key")
        if not lk or lk in seen_line:
            continue
        seen_line.add(lk)
        lane = v2_lane_from_row(row)
        claim_id = _scalar_id(conn, "SELECT claim_id FROM claim WHERE claim_key=?", (row.get("claim_key"),))
        if claim_id is None:
            _log_constraint_fail_spec(
                conn,
                row.get("artifact_id"),
                {
                    "entity": "claim_line",
                    "constraint_name": "claim_line_parent_fk",
                    "reason_code": CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED,
                    "reason": "claim missing",
                    "artifact_id": row.get("artifact_id"),
                    "canonical_type": row.get("canonical_type") or "",
                    "canonical_key": row.get("canonical_key") or "",
                    "source_system": row.get("source_system") or "xp_local",
                    "claim_key": row.get("claim_key") or "",
                },
                row=row,
                v2_exec_stats=v2_exec_stats,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim_line", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO claim_line (claim_line_key, claim_id, line_number, cpt_code, diagnosis_pointer, charged_amount, paid_amount) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                lk,
                claim_id,
                int(row.get("line_number") or 1),
                row.get("cpt_code"),
                row.get("diagnosis_pointer"),
                row.get("charged_amount"),
                row.get("paid_amount"),
            ),
        )
        if cur.rowcount > 0:
            counts["claim_line"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "claim_line", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "claim_line", "ignored_duplicate", 1)


def _execute_domain_upserts(conn, domain_upsert_rows, entity_scope="v1", v2_exec_stats=None):
    """
    Write domain entity upserts to DB. v1: patient only; v2: full chain per PHASE_D_V2_ENTITY_UPSERT_SPEC subset.
    Returns (entity_counts, constraint_skip_counts).
    """
    entity_scope = str(entity_scope or "v1").strip().lower()
    if entity_scope not in ("v1", "v2"):
        entity_scope = "v1"
    counts = {"patient": 0, "payer": 0, "insurance_plan": 0, "coverage": 0, "encounter": 0, "claim": 0, "claim_line": 0}
    constraint_skip_counts = _empty_constraint_skip_counts()
    for row in domain_upsert_rows.get("patient") or []:
        external_patient_id = row.get("external_patient_id")
        artifact_id = row.get("artifact_id")
        lane = v2_lane_from_row(row)
        invalid_id_diag = classify_external_patient_id_5_digit(
            external_patient_id,
            row.get("external_patient_id_source") or row.get("canonical_type") or "external_patient_id",
        )
        if not invalid_id_diag.get("is_valid"):
            invalid_id_diag = dict(invalid_id_diag)
            invalid_id_diag["artifact_class"] = str(row.get("canonical_type") or "patient_csv_row")
            constraint_skip_counts["patient_invalid_external_id"] += 1
            _increment_invalid_id_source_counts(constraint_skip_counts, invalid_id_diag)
            _log_constraint_fail(
                conn,
                artifact_id,
                row,
                CONSTRAINT_PATIENT_EXTERNAL_ID_INVALID,
                "external_patient_id must match ^[0-9]{5}$",
                v2_exec_stats=v2_exec_stats,
                invalid_id_diag=invalid_id_diag,
            )
            continue
        if v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "patient", "dedup_attempted", 1)
        cur = conn.execute(
            "INSERT OR IGNORE INTO patient (patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                row.get("patient_key"),
                external_patient_id,
                row.get("full_name"),
                row.get("birth_date"),
                row.get("source_system") or "xp_local",
            ),
        )
        if cur.rowcount > 0:
            counts["patient"] += cur.rowcount
            if v2_exec_stats is not None and lane:
                v2_inc_exec(v2_exec_stats, lane, "patient", "inserted", 1)
        elif v2_exec_stats is not None and lane:
            v2_inc_exec(v2_exec_stats, lane, "patient", "ignored_duplicate", 1)
    if entity_scope == "v2":
        _execute_domain_upserts_v2_chain(conn, domain_upsert_rows, counts, v2_exec_stats=v2_exec_stats)
    return counts, constraint_skip_counts


def _compute_phase_d_v2_metrics_bundle(entity_scope, v2_extractor_accum, v2_exec_stats):
    """Full phase_d_v2_domain_metrics and DAT-lane compact flat dict; empty for v1."""
    if str(entity_scope or "v1").strip().lower() != "v2":
        return {}, {}
    ext = v2_extractor_accum
    if ext is None:
        ext = empty_extractor_v2_stats()
    exe = v2_exec_stats
    if exe is None:
        exe = empty_executor_v2_stats()
    full = build_phase_d_v2_domain_metrics(ext, exe)
    return full, build_phase_d_dat_v2_compact_flat(full)


def _compute_phase_d_v2_preview_metrics(v2_preview_accum):
    """Preview v2 extractor readiness without executing v2 DB writes."""
    ext = v2_preview_accum
    if ext is None:
        ext = empty_extractor_v2_stats()
    full = build_phase_d_v2_domain_metrics(ext, empty_executor_v2_stats())
    return full, build_phase_d_dat_v2_compact_flat(full)


def _sum_int_values(mapping):
    total = 0
    if not isinstance(mapping, dict):
        return 0
    for _k, value in mapping.items():
        try:
            total += int(value or 0)
        except Exception:
            pass
    return total


def _top_count_item(mapping):
    best_key = ""
    best_count = 0
    if not isinstance(mapping, dict):
        return best_key, best_count
    for key, value in mapping.items():
        try:
            count = int(value or 0)
        except Exception:
            count = 0
        if count > best_count or (count == best_count and str(key) < str(best_key)):
            best_key = str(key)
            best_count = count
    return best_key, best_count


def _v2_reason_map(metrics, bucket):
    if not isinstance(metrics, dict):
        return {}
    by_bucket = metrics.get(bucket)
    if not isinstance(by_bucket, dict):
        return {}
    dat_map = by_bucket.get("dat_record")
    if isinstance(dat_map, dict):
        return dict(dat_map)
    all_map = by_bucket.get("all")
    if isinstance(all_map, dict):
        return dict(all_map)
    return {}


def _classify_v2_zero_insert_reason(entity_scope, execution_decision, flat_metrics, metrics):
    scope = str(entity_scope or "v1").strip().lower()
    decision = str(execution_decision or "").strip()
    flat = flat_metrics if isinstance(flat_metrics, dict) else {}
    inserted = int(flat.get("phase_d_dat_v2_inserted_total", 0) or 0)
    attempted = int(flat.get("phase_d_dat_v2_payload_attempted_total", 0) or 0)
    skipped = int(flat.get("phase_d_dat_v2_skipped_total", 0) or 0)
    constrained = int(flat.get("phase_d_dat_v2_constraint_failed_total", 0) or 0)
    duplicates = int(flat.get("phase_d_dat_v2_ignored_duplicate_total", 0) or 0)
    if inserted > 0:
        return "inserted"
    if scope != "v2" or decision == "preview_only_disabled_by_entity_scope_v1":
        return "v2_disabled"
    if attempted <= 0:
        return "no_payload_attempted"
    constraint_reasons = _v2_reason_map(metrics, "constraint_failed_by_reason")
    if constrained > 0 or _sum_int_values(constraint_reasons) > 0:
        return "constraint_blocked"
    skip_reasons = _v2_reason_map(metrics, "skipped_by_reason")
    if skipped > 0 or _sum_int_values(skip_reasons) > 0:
        if int(skip_reasons.get(DAT_V2_SKIP_INVALID_PATIENT_ID, 0) or 0) > 0:
            return "skipped_invalid_patient_id"
        if (int(skip_reasons.get(DAT_V2_SKIP_MISSING_PAYER_ANCHOR, 0) or 0) > 0
                or int(skip_reasons.get(DAT_V2_SKIP_MISSING_DOS_CLAIM_CHAIN, 0) or 0) > 0):
            return "skipped_missing_anchor"
        return "skipped_missing_anchor"
    if duplicates > 0:
        return "duplicates_only"
    return "no_payload_attempted"


def _dominant_v2_blocker(metrics):
    skip_reasons = _v2_reason_map(metrics, "skipped_by_reason")
    constraint_reasons = _v2_reason_map(metrics, "constraint_failed_by_reason")
    skip_key, skip_count = _top_count_item(skip_reasons)
    constraint_key, constraint_count = _top_count_item(constraint_reasons)
    if constraint_count > skip_count:
        return {
            "blocker_class": "constraint_blocked",
            "reason_code": constraint_key,
            "count": constraint_count,
        }
    if skip_count > 0:
        blocker_class = "skipped_missing_anchor"
        if skip_key == DAT_V2_SKIP_INVALID_PATIENT_ID:
            blocker_class = "skipped_invalid_patient_id"
        return {
            "blocker_class": blocker_class,
            "reason_code": skip_key,
            "count": skip_count,
        }
    return {"blocker_class": "", "reason_code": "", "count": 0}


def _build_phase_d_v2_readiness_preview(entity_scope, preview_metrics, actual_metrics):
    scope = str(entity_scope or "v1").strip().lower()
    if scope == "v2":
        execution_decision = "executed_v2_scope"
        metrics = actual_metrics if isinstance(actual_metrics, dict) else {}
        disabled_reason = ""
    else:
        execution_decision = "preview_only_disabled_by_entity_scope_v1"
        metrics = preview_metrics if isinstance(preview_metrics, dict) else {}
        disabled_reason = "phase_d_entity_scope_v1"
    flat = build_phase_d_dat_v2_compact_flat(metrics) if isinstance(metrics, dict) else {}
    zero_reason = _classify_v2_zero_insert_reason(scope, execution_decision, flat, metrics)
    blocker = _dominant_v2_blocker(metrics)
    return {
        "schema_version": "phase_d_v2_readiness_preview_v1",
        "phase_d_entity_scope": scope or "v1",
        "execution_decision": execution_decision,
        "disabled_reason": disabled_reason,
        "dat_v2_zero_insert_reason": zero_reason,
        "dat_record_payload_attempted_total": int(flat.get("phase_d_dat_v2_payload_attempted_total", 0) or 0),
        "dat_record_inserted_total": int(flat.get("phase_d_dat_v2_inserted_total", 0) or 0),
        "dat_record_skipped_total": int(flat.get("phase_d_dat_v2_skipped_total", 0) or 0),
        "dat_record_constraint_failed_total": int(flat.get("phase_d_dat_v2_constraint_failed_total", 0) or 0),
        "dat_record_ignored_duplicate_total": int(flat.get("phase_d_dat_v2_ignored_duplicate_total", 0) or 0),
        "dat_record_skipped_by_reason": _v2_reason_map(metrics, "skipped_by_reason"),
        "dat_record_constraint_failed_by_reason": _v2_reason_map(metrics, "constraint_failed_by_reason"),
        "dominant_blocker_class": str(blocker.get("blocker_class", "") or ""),
        "dominant_blocker_reason_code": str(blocker.get("reason_code", "") or ""),
        "dominant_blocker_count": int(blocker.get("count", 0) or 0),
    }


def _build_phase_d_closure_readiness(summary):
    dat = summary.get("dat_telemetry") if isinstance(summary.get("dat_telemetry"), dict) else {}
    constraints = summary.get("constraint_skip_counts") if isinstance(summary.get("constraint_skip_counts"), dict) else {}
    v2_preview = summary.get("phase_d_v2_readiness_preview")
    if not isinstance(v2_preview, dict):
        v2_preview = {}
    dat_selected = int(dat.get("dat_selected_count", 0) or 0)
    dat_pass = int(dat.get("dat_qa_pass_count", 0) or 0)
    dat_canonical = int(dat.get("dat_canonical_record_count", 0) or 0)
    invalid_count = int(constraints.get("patient_invalid_external_id", 0) or 0)
    entity_scope = str(summary.get("phase_d_entity_scope") or dat.get("phase_d_entity_scope") or "v1").strip().lower()
    v2_decision = str(v2_preview.get("execution_decision", "") or "").strip()
    v2_disabled_reason = str(v2_preview.get("disabled_reason", "") or "").strip()
    v2_zero_reason = str(v2_preview.get("dat_v2_zero_insert_reason", "") or "").strip()
    v2_inserted = int(v2_preview.get("dat_record_inserted_total", 0) or 0)
    v2_payload = int(v2_preview.get("dat_record_payload_attempted_total", 0) or 0)

    next_stall = ""
    evidence = {}
    if invalid_count > 0:
        stage = "data_quality_blocked"
        next_stall = "invalid_external_patient_id"
        evidence = {
            "patient_invalid_external_id_count": invalid_count,
            "by_source_contract": constraints.get("patient_invalid_external_id_by_source_contract") or {},
            "by_contract_disposition": constraints.get("patient_invalid_external_id_by_contract_disposition") or {},
        }
    elif entity_scope != "v2" and dat_pass > 0 and dat_canonical > 0:
        stage = "v2_disabled"
        next_stall = "v2_depth_not_executed"
        evidence = {
            "phase_d_entity_scope": entity_scope or "v1",
            "dat_record_payload_attempted_total_preview": v2_payload,
            "dominant_preview_blocker_class": v2_preview.get("dominant_blocker_class", ""),
            "dominant_preview_blocker_reason_code": v2_preview.get("dominant_blocker_reason_code", ""),
            "dominant_preview_blocker_count": v2_preview.get("dominant_blocker_count", 0),
        }
    elif entity_scope == "v2" and dat_pass > 0 and dat_canonical > 0 and v2_inserted <= 0:
        stage = "v2_blocked"
        next_stall = v2_zero_reason or "v2_depth_blocked"
        evidence = {
            "dat_v2_zero_insert_reason": v2_zero_reason,
            "dominant_blocker_class": v2_preview.get("dominant_blocker_class", ""),
            "dominant_blocker_reason_code": v2_preview.get("dominant_blocker_reason_code", ""),
            "dominant_blocker_count": v2_preview.get("dominant_blocker_count", 0),
        }
    elif dat_selected > 0 and dat_pass > 0 and dat_canonical > 0 and (entity_scope != "v2" or v2_inserted > 0):
        stage = "milestone_ready"
        next_stall = ""
        evidence = {
            "dat_selected_count": dat_selected,
            "dat_qa_pass_count": dat_pass,
            "dat_canonical_record_count": dat_canonical,
            "dat_v2_inserted_total": v2_inserted,
        }
    elif dat_selected > 0 and dat_pass > 0 and dat_canonical > 0:
        stage = "dat_flowing"
        next_stall = "depth_readiness_pending"
        evidence = {
            "dat_selected_count": dat_selected,
            "dat_qa_pass_count": dat_pass,
            "dat_canonical_record_count": dat_canonical,
        }
    elif dat_selected <= 0:
        stage = "data_quality_blocked"
        next_stall = "phase_d_dat_not_selected"
        evidence = {
            "dat_selected_count": dat_selected,
            "dat_qa_pass_count": dat_pass,
            "dat_canonical_record_count": dat_canonical,
            "rows_selected": int(summary.get("rows_selected", 0) or 0),
        }
    else:
        stage = "data_quality_blocked" if int(summary.get("qa_reject_count", 0) or 0) > 0 else "dat_flowing"
        next_stall = "phase_d_pass_or_canonical_missing"
        evidence = {
            "dat_selected_count": dat_selected,
            "dat_qa_pass_count": dat_pass,
            "dat_canonical_record_count": dat_canonical,
            "qa_reject_count": int(summary.get("qa_reject_count", 0) or 0),
        }
    return {
        "phase_d_data_plane_stage": stage,
        "phase_d_entity_scope": entity_scope or "v1",
        "phase_d_v2_execution_decision": v2_decision,
        "phase_d_v2_disabled_reason": v2_disabled_reason,
        "next_predicted_stall": next_stall,
        "next_predicted_stall_evidence": evidence,
    }


def _invalid_external_id_contract_rows(summary):
    constraints = summary.get("constraint_skip_counts") if isinstance(summary.get("constraint_skip_counts"), dict) else {}
    by_contract = constraints.get("patient_invalid_external_id_by_source_contract")
    if not isinstance(by_contract, dict):
        by_contract = {}
    by_disp = constraints.get("patient_invalid_external_id_by_contract_disposition")
    if not isinstance(by_disp, dict):
        by_disp = {}
    by_source = constraints.get("patient_invalid_external_id_by_source")
    if not isinstance(by_source, dict):
        by_source = {}
    by_artifact = constraints.get("patient_invalid_external_id_by_artifact_class")
    if not isinstance(by_artifact, dict):
        by_artifact = {}
    if not by_contract:
        total = int(constraints.get("patient_invalid_external_id", 0) or 0)
        if total > 0:
            by_contract = {"unknown_external_patient_id_contract": total}
    rows = []
    for contract, count in by_contract.items():
        contract_text = str(contract or "unknown_external_patient_id_contract")
        field_name = contract_text
        if "_patient_id" in contract_text:
            field_name = "patient_id"
        elif "external" in contract_text:
            field_name = "external_patient_id"
        disposition, disposition_count = _top_count_item(by_disp)
        artifact_class, artifact_count = _top_count_item(by_artifact)
        source_field, source_field_count = _top_count_item(by_source)
        row_count = int(count or 0)
        if disposition_count > row_count:
            disposition_count = row_count
        if artifact_count <= 0:
            artifact_class = "unknown"
        if source_field_count > 0:
            field_name = source_field
        rows.append({
            "source_contract": contract_text,
            "contract_disposition": disposition or "unknown",
            "artifact_class": artifact_class or "unknown",
            "field_name": field_name or "external_patient_id",
            "count": row_count,
            "shape_family": "redacted_external_patient_id_shape",
            "source_token": contract_text,
            "safe_examples": [
                {
                    "redacted_value": "<redacted>",
                    "shape_family": "redacted_external_patient_id_shape",
                    "note": "raw patient identifiers are intentionally omitted",
                }
            ],
        })
    rows.sort(key=lambda item: (-int(item.get("count", 0) or 0), str(item.get("source_contract", ""))))
    return rows


def _build_invalid_external_id_contract_report_payload(summary):
    constraints = summary.get("constraint_skip_counts") if isinstance(summary.get("constraint_skip_counts"), dict) else {}
    total = int(constraints.get("patient_invalid_external_id", 0) or 0)
    rows = _invalid_external_id_contract_rows(summary)
    return {
        "schema_version": "phase_d_invalid_external_id_contract_report_v1",
        "run_id": str(summary.get("run_id", "") or ""),
        "generated_at_utc": iso_utc_now(),
        "contains_pii": False,
        "redaction_policy": "counts_and_shape_families_only_no_raw_patient_identifiers",
        "patient_invalid_external_id_count": total,
        "rows": rows,
        "developer_next_step": (
            "Use source_contract, contract_disposition, artifact_class, field_name, and counts to fix the upstream "
            "patient ID contract; do not ask the XP operator to inspect local PII."
        ),
    }


def _write_invalid_external_id_contract_report(reports_dir, run_id_value, summary):
    constraints = summary.get("constraint_skip_counts") if isinstance(summary.get("constraint_skip_counts"), dict) else {}
    total = int(constraints.get("patient_invalid_external_id", 0) or 0)
    if total <= 0:
        return {}
    if reports_dir and not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)
    base = os.path.join(reports_dir, "phase_d_invalid_external_id_contract_report_{0}".format(run_id_value))
    json_path = base + ".json"
    txt_path = base + ".txt"
    payload = _build_invalid_external_id_contract_report_payload(summary)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=True, sort_keys=True)
    lines = [
        "Phase D Invalid External Patient ID Contract Report",
        "run_id: {0}".format(payload.get("run_id", "")),
        "generated_at_utc: {0}".format(payload.get("generated_at_utc", "")),
        "contains_pii: False",
        "patient_invalid_external_id_count: {0}".format(payload.get("patient_invalid_external_id_count", 0)),
        "redaction_policy: {0}".format(payload.get("redaction_policy", "")),
    ]
    for row in payload.get("rows") or []:
        lines.append(
            "contract={0}; disposition={1}; artifact_class={2}; field_name={3}; count={4}; shape_family={5}; source_token={6}".format(
                row.get("source_contract", ""),
                row.get("contract_disposition", ""),
                row.get("artifact_class", ""),
                row.get("field_name", ""),
                row.get("count", 0),
                row.get("shape_family", ""),
                row.get("source_token", ""),
            )
        )
    lines.append("developer_next_step: {0}".format(payload.get("developer_next_step", "")))
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return {
        "phase_d_invalid_external_id_contract_report_json_path": json_path,
        "phase_d_invalid_external_id_contract_report_txt_path": txt_path,
    }


def _patient_id_shape(value):
    text = str(value or "").strip()
    if not text:
        return "missing"
    diag = classify_external_patient_id_5_digit(text, "dat_anchor_failure_profile.patient_id")
    if diag.get("is_valid"):
        return "digits5_valid"
    family = str(diag.get("pattern_family") or "").strip()
    reason = str(diag.get("reason") or "").strip()
    if family:
        return family
    if reason:
        return reason
    return "invalid"


def _dat_sample_source_token(sample):
    sha = str((sample or {}).get("attachment_sha256") or "").strip()
    if sha:
        return "sha:{0}".format(sha[:12])
    aid = str((sample or {}).get("artifact_id") or "").strip()
    if aid:
        return "artifact:{0}".format(aid)
    return "unknown"


def _inc_nested_counter(target, outer, inner, count=1):
    if not isinstance(target, dict):
        return
    outer_key = str(outer or "unknown")
    inner_key = str(inner or "unknown")
    row = target.get(outer_key)
    if not isinstance(row, dict):
        row = {}
        target[outer_key] = row
    row[inner_key] = int(row.get(inner_key, 0) or 0) + int(count or 0)


def _has_any_raw_key(raw_keys, aliases):
    keys = set([str(k or "") for k in (raw_keys or [])])
    for alias in aliases:
        if alias in keys:
            return True
    return False


def _build_dat_anchor_failure_profile_payload(summary, reject_samples):
    dat = summary.get("dat_telemetry") if isinstance(summary.get("dat_telemetry"), dict) else {}
    reject_samples = reject_samples if isinstance(reject_samples, list) else []
    reject_counts = dat.get("dat_qa_reject_counts_by_reason")
    if not isinstance(reject_counts, dict):
        reject_counts = {}
    profile = {
        "schema_version": "dat_anchor_failure_profile_v1",
        "run_id": str(summary.get("run_id", "") or ""),
        "generated_at_utc": iso_utc_now(),
        "contains_pii": False,
        "redaction_policy": "counts_shapes_field_names_and_source_tokens_only_no_raw_patient_or_chart_values",
        "developer_next_step": (
            "Use reject-code, prefix, shape, and alias counters to distinguish DAT parser alias loss "
            "from upstream source absence; do not ask the XP operator to inspect local PII."
        ),
        "reject_counts_by_code": dict(reject_counts),
        "reject_counts_by_code_and_file_prefix": {},
        "patient_id_shape_counts_by_reject_code": {},
        "raw_key_set_counts_by_reject_code": {},
        "payer_alias_presence_by_reject_code": {},
        "patient_anchor_missing_chart_present_count": 0,
        "patient_anchor_missing_chart_date_payer_present_count": 0,
        "patient_anchor_missing_date_present_count": 0,
        "patient_anchor_missing_payer_present_count": 0,
        "payer_anchor_missing_iname_present_count": 0,
        "payer_anchor_missing_patient_date_keyable_count": 0,
        "samples": [],
    }
    for sample in reject_samples:
        if not isinstance(sample, dict):
            continue
        code = str(sample.get("reject_code") or "").strip()
        if code not in (QA_DAT_PATIENT_ANCHOR_MISSING, QA_DAT_PAYER_ANCHOR_MISSING):
            continue
        prefix = str(sample.get("dat_file_prefix") or "unknown").strip() or "unknown"
        raw_keys = sample.get("raw_keys") if isinstance(sample.get("raw_keys"), list) else []
        raw_key_set = ",".join(sorted([str(k or "") for k in raw_keys if str(k or "").strip()])) or "unknown"
        patient_shape = _patient_id_shape(sample.get("resolved_patient_id"))
        chart_present = bool(str(sample.get("resolved_chart_number") or "").strip())
        date_present = bool(str(sample.get("resolved_date_of_service") or "").strip())
        payer_present = bool(str(sample.get("resolved_payer_id") or "").strip())
        iname_present = bool(str(sample.get("resolved_insurance_name") or "").strip())
        _inc_nested_counter(profile["reject_counts_by_code_and_file_prefix"], code, prefix)
        _inc_nested_counter(profile["patient_id_shape_counts_by_reject_code"], code, patient_shape)
        _inc_nested_counter(profile["raw_key_set_counts_by_reject_code"], code, raw_key_set)
        payer_alias = "payer_anchor_present" if payer_present else "payer_anchor_missing"
        if _has_any_raw_key(raw_keys, ("PAYERID", "INSID", "payer_id", "insurance_id")):
            payer_alias = "payer_alias_present"
        elif iname_present or _has_any_raw_key(raw_keys, ("INAME", "insurance_name")):
            payer_alias = "insurance_name_present_only"
        _inc_nested_counter(profile["payer_alias_presence_by_reject_code"], code, payer_alias)
        if code == QA_DAT_PATIENT_ANCHOR_MISSING:
            if chart_present:
                profile["patient_anchor_missing_chart_present_count"] += 1
            if date_present:
                profile["patient_anchor_missing_date_present_count"] += 1
            if payer_present:
                profile["patient_anchor_missing_payer_present_count"] += 1
            if chart_present and date_present and payer_present:
                profile["patient_anchor_missing_chart_date_payer_present_count"] += 1
        if code == QA_DAT_PAYER_ANCHOR_MISSING:
            if iname_present:
                profile["payer_anchor_missing_iname_present_count"] += 1
            if patient_shape == "digits5_valid" and date_present:
                profile["payer_anchor_missing_patient_date_keyable_count"] += 1
        if len(profile["samples"]) < 20:
            profile["samples"].append({
                "reject_code": code,
                "source_file_token": _dat_sample_source_token(sample),
                "dat_file_prefix": prefix,
                "record_index": sample.get("record_index"),
                "raw_keys": sorted([str(k or "") for k in raw_keys if str(k or "").strip()])[:20],
                "patient_id_shape": patient_shape,
                "chart_present": chart_present,
                "date_alias_present": date_present,
                "payer_anchor_present": payer_present,
                "iname_present": iname_present,
                "payer_resolution_status": str(sample.get("dat_payer_resolution_status") or ""),
                "payer_resolution_source": str(sample.get("dat_payer_resolution_source") or ""),
                "payer_resolution_diagnostic": str(sample.get("dat_payer_resolution_diagnostic") or ""),
            })
    return profile


def _write_dat_anchor_failure_profile(reports_dir, run_id_value, summary, reject_samples):
    dat = summary.get("dat_telemetry") if isinstance(summary.get("dat_telemetry"), dict) else {}
    rejects = dat.get("dat_qa_reject_counts_by_reason")
    if not isinstance(rejects, dict):
        rejects = {}
    total = int(rejects.get(QA_DAT_PATIENT_ANCHOR_MISSING, 0) or 0) + int(rejects.get(QA_DAT_PAYER_ANCHOR_MISSING, 0) or 0)
    if total <= 0:
        return {}
    if reports_dir and not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)
    base = os.path.join(reports_dir, "dat_anchor_failure_profile_{0}".format(run_id_value))
    json_path = base + ".json"
    txt_path = base + ".txt"
    payload = _build_dat_anchor_failure_profile_payload(summary, reject_samples)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=True, sort_keys=True)
    lines = [
        "DAT Anchor Failure Profile",
        "run_id: {0}".format(payload.get("run_id", "")),
        "generated_at_utc: {0}".format(payload.get("generated_at_utc", "")),
        "contains_pii: False",
        "redaction_policy: {0}".format(payload.get("redaction_policy", "")),
        "reject_counts_by_code: {0}".format(json.dumps(payload.get("reject_counts_by_code") or {}, sort_keys=True)),
        "reject_counts_by_code_and_file_prefix: {0}".format(json.dumps(payload.get("reject_counts_by_code_and_file_prefix") or {}, sort_keys=True)),
        "patient_id_shape_counts_by_reject_code: {0}".format(json.dumps(payload.get("patient_id_shape_counts_by_reject_code") or {}, sort_keys=True)),
        "payer_alias_presence_by_reject_code: {0}".format(json.dumps(payload.get("payer_alias_presence_by_reject_code") or {}, sort_keys=True)),
        "patient_anchor_missing_chart_present_count: {0}".format(payload.get("patient_anchor_missing_chart_present_count", 0)),
        "patient_anchor_missing_chart_date_payer_present_count: {0}".format(payload.get("patient_anchor_missing_chart_date_payer_present_count", 0)),
        "payer_anchor_missing_iname_present_count: {0}".format(payload.get("payer_anchor_missing_iname_present_count", 0)),
        "payer_anchor_missing_patient_date_keyable_count: {0}".format(payload.get("payer_anchor_missing_patient_date_keyable_count", 0)),
        "developer_next_step: {0}".format(payload.get("developer_next_step", "")),
    ]
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return {
        "dat_anchor_failure_profile_json_path": json_path,
        "dat_anchor_failure_profile_txt_path": txt_path,
    }


def _attach_phase_d_contract_report_paths(summary, reports_dir, run_id_value, reject_samples=None):
    try:
        paths = _write_invalid_external_id_contract_report(reports_dir, run_id_value, summary)
        for key, value in paths.items():
            summary[key] = value
        if paths and build_invalid_external_patient_id_unblock is not None:
            summary["phase_d_developer_unblock"] = build_invalid_external_patient_id_unblock(
                summary,
                [
                    paths.get("phase_d_invalid_external_id_contract_report_json_path", ""),
                    paths.get("phase_d_invalid_external_id_contract_report_txt_path", ""),
                ],
            )
    except Exception as exc:
        summary["phase_d_invalid_external_id_contract_report_error"] = str(exc)[:200]
    try:
        paths = _write_dat_anchor_failure_profile(reports_dir, run_id_value, summary, reject_samples or [])
        for key, value in paths.items():
            summary[key] = value
    except Exception as exc:
        summary["dat_anchor_failure_profile_error"] = str(exc)[:200]
    return summary


def select_eligible_artifacts(conn, qa_version):
    """Select ingest_artifact rows not yet evaluated for (phase_d, qa_version)."""
    cur = conn.execute(
        "SELECT artifact_id, ingest_key, source_system, source_type, source_ref, attachment_sha256, payload_json "
        "FROM ingest_artifact WHERE artifact_id NOT IN "
        "(SELECT artifact_id FROM qa_result WHERE qa_stage=? AND qa_version=?)",
        (QA_STAGE_PHASE_D, qa_version),
    )
    return cur.fetchall()


def run_qa_canonical(lab_root, artifact_classes=None, artifact_scope_source="argument"):
    """Main flow. Returns (ok, run_id, summary, error_code)."""
    rid = run_id()
    entity_scope = _phase_d_entity_scope_from_env()
    global _PHASE_D_ARTIFACT_SCOPE_POLICY
    _PHASE_D_ARTIFACT_SCOPE_POLICY = resolve_phase_d_artifact_scope_policy(
        lab_root,
        artifact_classes,
        artifact_scope_source if artifact_classes else "default",
    )
    artifact_class_filter = list(_PHASE_D_ARTIFACT_SCOPE_POLICY.get("artifact_classes") or [])
    reports_dir = os.path.join(lab_root, "reports")
    summary_json_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(rid))
    summary_txt_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.txt".format(rid))
    reject_samples_path = os.path.join(reports_dir, "qa_reject_samples_{0}.jsonl".format(rid))
    db_path = os.path.join(lab_root, "unified_model_xp.db")

    if not os.path.exists(db_path):
        # Do not run zero-selection enrichment: eligibility was never computed.
        summary_fail = _build_summary(
            rid, ok=False, rows_selected=0, error_code=PHASE_D_DB_WRITE_ERROR, entity_scope=entity_scope,
            dat_csv_join_telemetry={},
            artifact_class_filter=artifact_class_filter,
            zero_selection_analysis_available=False,
            layer1_flat=_layer1_flat_for_qa(None, {}, {}, False),
        )
        _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir)
        return False, rid, summary_fail, summary_fail.get("error_code")

    qa_results = []
    replay_entries = []
    canonical_records = []
    domain_upsert_rows = {"patient": [], "payer": [], "insurance_plan": [], "coverage": [], "encounter": [], "claim": [], "claim_line": []}
    entity_upserts = {"patient": 0, "payer": 0, "insurance_plan": 0, "coverage": 0, "encounter": 0, "claim": 0, "claim_line": 0}
    constraint_skip_counts = _empty_constraint_skip_counts()
    reject_samples = []
    reject_counts_by_code = {}
    reject_counts_by_artifact_code = {}
    dat_candidate_count = 0
    dat_pre_qa_skipped_count = 0
    dat_pre_qa_skip_counts_by_reason = {}
    dat_pre_qa_skip_file_prefix_counts = {}
    dat_pre_qa_terminal_result_count = 0
    dat_file_shape_diagnostics = empty_dat_file_shape_diagnostics()
    dat_anchor_diagnostics = {
        "records_seen": 0,
        "patient_anchor_present_count": 0,
        "patient_anchor_missing_count": 0,
        "chart_present_count": 0,
        "chart_without_patient_anchor_count": 0,
        "chart_used_as_patient_anchor_count": 0,
        "payer_anchor_present_count": 0,
        "payer_anchor_missing_count": 0,
        "patient_anchor_contract": "requires_5_digit_patid",
        "chart_role": "supplemental_not_patient_anchor",
        "chart_anchor_usable": False,
    }
    dat_selected_count = 0
    dat_qa_pass_count = 0
    dat_qa_reject_count = 0
    dat_reject_counts_by_reason = {}
    dat_field_presence = {
        "records_seen": 0,
        "PATID": 0,
        "patid_present_count": 0,
        "patient_id": 0,
        "patient_id_present_count": 0,
        "DOS": 0,
        "dos_present_count": 0,
        "DATE1": 0,
        "date1_present_count": 0,
        "DATE": 0,
        "date_present_count": 0,
        "date_of_service": 0,
        "date_of_service_present_count": 0,
        "PAYERID": 0,
        "payerid_present_count": 0,
        "INSID": 0,
        "insid_present_count": 0,
        "payer_id": 0,
        "payer_id_present_count": 0,
        "INAME": 0,
        "iname_present_count": 0,
        "insurance_name": 0,
        "insurance_name_present_count": 0,
        "CHART": 0,
        "chart_present_count": 0,
        "chart_number": 0,
        "chart_number_present_count": 0,
    }
    dat_parse_diagnostics = {
        "tuple_parse_failure_count": 0,
        "first_failure_class": "",
        "first_failure_detail": "",
        "record_shape_counts": {},
        "raw_key_sets_sample": [],
    }
    dat_file_prefix_counts = {}
    dat_reject_file_prefix_counts = {}
    csv_docx_join_telemetry = {}
    dat_csv_join_telemetry = {}
    layer1_relaxed_dat_records = []
    ingress_stats = {
        "csv": {"artifacts_processed": 0, "parse_rejected_artifacts": 0},
        "docx": {"artifacts_processed": 0, "parse_rejected_artifacts": 0},
        "dat": {"artifacts_processed": 0, "parse_rejected_artifacts": 0},
    }
    v2_extractor_accum = empty_extractor_v2_stats() if entity_scope == "v2" else None
    v2_preview_accum = empty_extractor_v2_stats()

    try:
        conn = sqlite3.connect(db_path)
        rows_all = select_eligible_artifacts(conn, QA_POLICY_VERSION)
        n_eligible_before_filter = len(rows_all)
        rows = _filter_rows_by_artifact_classes(rows_all, artifact_class_filter)
        n_after_filter = len(rows)
        rows = _sort_phase_d_eligible_rows(rows)
        conn.close()
    except Exception as e:
        # Do not run zero-selection enrichment: eligibility query failed before counts are valid.
        summary_fail = _build_summary(
            rid, ok=False, rows_selected=0, error_code=PHASE_D_DB_WRITE_ERROR,
            error_detail=str(e)[:200], source_exception_class=e.__class__.__name__,
            entity_scope=entity_scope,
            dat_csv_join_telemetry={},
            artifact_class_filter=artifact_class_filter,
            zero_selection_analysis_available=False,
            layer1_flat=_layer1_flat_for_qa(None, {}, {}, False),
        )
        _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir)
        return False, rid, summary_fail, PHASE_D_DB_WRITE_ERROR

    if not rows:
        full_v2, flat_v2 = _compute_phase_d_v2_metrics_bundle(entity_scope, v2_extractor_accum, None)
        preview_full_v2, _preview_flat_v2 = _compute_phase_d_v2_preview_metrics(v2_preview_accum)
        v2_readiness_preview = _build_phase_d_v2_readiness_preview(
            entity_scope, preview_full_v2, full_v2)
        dat_telemetry = _build_dat_telemetry(
            0, 0, 0, {}, [], entity_upserts, entity_scope,
            dat_v2_compact_flat=flat_v2,
            dat_parse_diagnostics={},
            dat_file_prefix_counts={},
            dat_reject_file_prefix_counts={},
            dat_candidate_count=0,
            dat_pre_qa_skipped_count=0,
            dat_pre_qa_skip_counts_by_reason={},
            dat_pre_qa_skip_file_prefix_counts={},
            dat_anchor_diagnostics={},
            dat_file_shape_diagnostics=empty_dat_file_shape_diagnostics(),
        )
        summary_ok = _build_summary(rid, ok=True, rows_selected=0, qa_pass_count=0, qa_reject_count=0,
                                    replay_enqueued_count=0, canonical_record_count=0,
                                    reject_counts_by_code={}, entity_upsert_counts=entity_upserts,
                                    constraint_skip_counts=constraint_skip_counts,
                                    artifact_class_filter=artifact_class_filter,
                                    entity_scope=entity_scope,
                                    dat_telemetry=dat_telemetry,
                                    dat_csv_join_telemetry={},
                                    phase_d_v2_domain_metrics=full_v2,
                                    phase_d_v2_readiness_preview=v2_readiness_preview)
        summary_ok = _apply_zero_selection_enrichment(
            lab_root, summary_ok, n_eligible_before_filter, n_after_filter, artifact_class_filter)
        layer1_bundle = None
        layer1_write_error = ""
        if write_layer1_join_debug_artifacts is not None:
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                layer1_bundle = write_layer1_join_debug_artifacts(
                    reports_dir,
                    rid,
                    [],
                    {},
                    {},
                    patient_field_mapper_module,
                    ingress_stats=ingress_stats,
                    phase_run_ids=_phase_run_ids_hint_from_env(),
                    layer1_evaluation_blocked_reason="phase_d_no_eligible_rows",
                    zero_selection_reason_codes=list(summary_ok.get("zero_selection_reason_codes") or []),
                )
            except Exception as _l1_write_err:
                layer1_write_error = str(_l1_write_err)
                layer1_bundle = None
        l1flat = _layer1_flat_for_qa(layer1_bundle, {}, {}, True)
        if layer1_write_error and not l1flat:
            l1flat = _layer1_write_error_flat(layer1_write_error)
        for _k2, _v2 in (l1flat or {}).items():
            summary_ok[_k2] = _v2
        try:
            acquire_lock(lab_root)
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                summary_ok = _attach_phase_d_contract_report_paths(summary_ok, reports_dir, rid, reject_samples)
                _write_summary_json(summary_ok, summary_json_path)
                _write_summary_txt(summary_ok, summary_txt_path)
                persist_phase_d_state(
                    lab_root,
                    rid,
                    True,
                    None,
                    0,
                    0,
                    0,
                    0,
                    entity_upserts,
                    constraint_skip_counts=constraint_skip_counts,
                    dat_telemetry=dat_telemetry,
                    dat_csv_join_telemetry={},
                    selection_scope=summary_ok.get("selection_scope"),
                    zero_selection_reason_codes=summary_ok.get("zero_selection_reason_codes"),
                    phase_c_summary_run_id_used_for_zero_selection=summary_ok.get(
                        "phase_c_summary_run_id_used_for_zero_selection"),
                    phase_c_summary_path_used_for_zero_selection=summary_ok.get(
                        "phase_c_summary_path_used_for_zero_selection"),
                )
                _sync_phase_d_remediation_safe(lab_root, rid, summary_ok)
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
        except SystemExit:
            return False, rid, None, PHASE_D_LOCK_FAIL
        return True, rid, summary_ok, None

    dat_manifest_lineage_index = build_dat_manifest_lineage_index(lab_root)

    for row in rows:
        artifact_id, ingest_key, source_system, source_type, source_ref, attachment_sha256, payload_json = row
        payload = {}
        try:
            payload = json.loads(payload_json) if payload_json else {}
        except (ValueError, TypeError):
            pass
        locator = payload.get("locator") or ""
        artifact_class = payload.get("artifact_class") or ""
        ac_lc = str(artifact_class or "").strip().lower()
        if ac_lc in ingress_stats:
            ingress_stats[ac_lc]["artifacts_processed"] = ingress_stats[ac_lc].get("artifacts_processed", 0) + 1
        telemetry_locator = locator or payload.get("normalized_path") or payload.get("attachment_name") or ""
        dat_file_prefix = _file_prefix_from_locator(telemetry_locator) if artifact_class == "dat" else ""
        if artifact_class == "dat":
            dat_candidate_count += 1
            _merge_counter_dict(dat_file_prefix_counts, {dat_file_prefix: 1})

        ok, envelope, parse_code = parse_artifact(locator, artifact_class, payload)
        if not ok:
            reject_code = parse_code or QA_PARSE_ERROR
            if ac_lc in ingress_stats:
                ingress_stats[ac_lc]["parse_rejected_artifacts"] = ingress_stats[ac_lc].get("parse_rejected_artifacts", 0) + 1
            if artifact_class == "dat":
                dat_selected_count += 1
                dat_qa_reject_count += 1
                dat_reject_counts_by_reason[reject_code] = dat_reject_counts_by_reason.get(reject_code, 0) + 1
                _merge_counter_dict(dat_reject_file_prefix_counts, {dat_file_prefix: 1})
            parse_diag = get_last_parse_diag()
            reject_counts_by_code[reject_code] = reject_counts_by_code.get(reject_code, 0) + 1
            reject_reason = "Parse failed [{0}]".format(
                parse_diag.get("source_exception_class") or "unknown"
            ) if isinstance(parse_diag, dict) else "Parse failed"
            qa_results.append((artifact_id, "reject", reject_code, reject_reason))
            replay_entries.append((artifact_id, reject_code))
            if artifact_class == "dat":
                if len(reject_samples) < 50:
                    _ds = _build_dat_reject_sample(
                        artifact_id,
                        reject_code,
                        reject_reason,
                        None,
                        telemetry_locator,
                        source_ref,
                        attachment_sha256,
                        parse_diag=parse_diag if isinstance(parse_diag, dict) else {},
                    )
                    _ds.update(resolve_dat_artifact_manifest_lineage(
                        lab_root,
                        artifact_id,
                        attachment_sha256,
                        telemetry_locator,
                        dat_manifest_lineage_index,
                    ))
                    reject_samples.append(_ds)
            else:
                if len(reject_samples) < 50:
                    reject_samples.append({
                        "artifact_id": artifact_id,
                        "reject_code": reject_code,
                        "locator": locator[:80],
                        "locator_full": locator,
                        "parse_diag": parse_diag if isinstance(parse_diag, dict) else {},
                    })
            continue
        if artifact_class == "dat":
            _merge_counter_dict(dat_field_presence, _dat_alias_presence_counts_from_envelope(envelope))
            _merge_dat_anchor_diagnostics(dat_anchor_diagnostics, _dat_anchor_diagnostics_from_envelope(envelope))
            append_dat_file_shape_diagnostics(dat_file_shape_diagnostics, envelope, telemetry_locator)
            _merge_dat_parse_diagnostics(dat_parse_diagnostics, envelope)

        if artifact_class == "dat" and isinstance(envelope, dict):
            envelope["_qa_locator"] = telemetry_locator
            _dat_meta = dat_envelope_parse_metadata_dict(envelope, telemetry_locator)
            if _dat_meta.get("status") == DAT_PARSE_STATUS_EMPTY_FILE:
                dat_pre_qa_skipped_count += 1
                dat_pre_qa_terminal_result_count += 1
                dat_pre_qa_skip_counts_by_reason[QA_DAT_EMPTY_FILE] = (
                    dat_pre_qa_skip_counts_by_reason.get(QA_DAT_EMPTY_FILE, 0) + 1
                )
                _merge_counter_dict(dat_pre_qa_skip_file_prefix_counts, {dat_file_prefix: 1})
                reject_counts_by_code[QA_DAT_EMPTY_FILE] = reject_counts_by_code.get(QA_DAT_EMPTY_FILE, 0) + 1
                reject_key = "{0}|{1}".format(artifact_class or "unknown", QA_DAT_EMPTY_FILE)
                reject_counts_by_artifact_code[reject_key] = reject_counts_by_artifact_code.get(reject_key, 0) + 1
                qa_results.append((
                    artifact_id,
                    "reject",
                    QA_DAT_EMPTY_FILE,
                    "Terminal pre-QA skip: zero-byte DAT file; not queued for replay.",
                ))
                continue

        pass_qa, reject_code, reject_reason = evaluate_qa(artifact_class, envelope)
        if artifact_class == "dat":
            dat_selected_count += 1
        if not pass_qa:
            reject_code = reject_code or QA_ARTIFACT_CLASS_REQUIRED_FIELDS
            if artifact_class == "dat":
                dat_qa_reject_count += 1
                dat_reject_counts_by_reason[reject_code] = dat_reject_counts_by_reason.get(reject_code, 0) + 1
                _merge_counter_dict(dat_reject_file_prefix_counts, {dat_file_prefix: 1})
                _append_layer1_relaxed_dat_candidates(
                    layer1_relaxed_dat_records,
                    artifact_id,
                    envelope,
                    telemetry_locator,
                    source_ref,
                    attachment_sha256,
                )
            reject_counts_by_code[reject_code] = reject_counts_by_code.get(reject_code, 0) + 1
            reject_key = "{0}|{1}".format(artifact_class or "unknown", reject_code)
            reject_counts_by_artifact_code[reject_key] = reject_counts_by_artifact_code.get(reject_key, 0) + 1
            qa_results.append((artifact_id, "reject", reject_code, reject_reason or ""))
            replay_entries.append((artifact_id, reject_code))
            if artifact_class == "dat":
                if len(reject_samples) < 50:
                    _ds = _build_dat_reject_sample(
                        artifact_id,
                        reject_code,
                        reject_reason or "",
                        envelope,
                        telemetry_locator,
                        source_ref,
                        attachment_sha256,
                    )
                    _ds.update(resolve_dat_artifact_manifest_lineage(
                        lab_root,
                        artifact_id,
                        attachment_sha256,
                        telemetry_locator,
                        dat_manifest_lineage_index,
                    ))
                    reject_samples.append(_ds)
            else:
                if len(reject_samples) < 50:
                    reject_samples.append({"artifact_id": artifact_id, "reject_code": reject_code, "reason": reject_reason})
            continue

        qa_results.append((artifact_id, "pass", None, None))
        if artifact_class == "dat":
            dat_qa_pass_count += 1
        recs = extract_canonical_records(artifact_id, artifact_class, envelope, source_system, source_ref, attachment_sha256)
        for rec in recs:
            rec["artifact_id"] = artifact_id
            canonical_records.append(rec)
        preview_upserts, v2_preview_part = build_domain_upserts(recs, artifact_id, source_system, entity_scope="v2")
        merge_extractor_v2_stats(v2_preview_accum, v2_preview_part)
        upserts, v2_ext_part = build_domain_upserts(recs, artifact_id, source_system, entity_scope=entity_scope)
        if v2_extractor_accum is not None:
            merge_extractor_v2_stats(v2_extractor_accum, v2_ext_part)
        for k, v in upserts.items():
            if isinstance(v, list):
                domain_upsert_rows[k].extend(v)
                entity_upserts[k] += len(v)

    qa_pass_count = sum(1 for r in qa_results if r[1] == "pass")
    qa_reject_count = len(qa_results) - qa_pass_count
    replay_enqueued_count = len(replay_entries)

    try:
        acquire_lock(lab_root)
    except SystemExit:
        return False, rid, None, PHASE_D_LOCK_FAIL

    actual_entity_counts = dict(entity_upserts)
    actual_constraint_counts = dict(constraint_skip_counts)
    csv_docx_join_telemetry = annotate_csv_docx_join(canonical_records)
    dat_csv_join_telemetry = annotate_dat_csv_alignment(canonical_records, patient_field_mapper_module)

    layer1_bundle = None
    layer1_write_error = ""
    if write_layer1_join_debug_artifacts is not None:
        try:
            layer1_bundle = write_layer1_join_debug_artifacts(
                reports_dir,
                rid,
                canonical_records,
                csv_docx_join_telemetry,
                dat_csv_join_telemetry,
                patient_field_mapper_module,
                ingress_stats=ingress_stats,
                phase_run_ids=_phase_run_ids_hint_from_env(),
                layer1_evaluation_blocked_reason="",
                zero_selection_reason_codes=[],
                relaxed_dat_records=layer1_relaxed_dat_records,
            )
        except Exception as _l1_write_err:
            layer1_write_error = str(_l1_write_err)
            layer1_bundle = None

    planning_telemetry = _build_planning_telemetry(
        canonical_records,
        reject_counts_by_code,
        reject_counts_by_artifact_code,
        actual_constraint_counts,
    )
    preview_phase_d_v2_full, preview_flat_v2 = _compute_phase_d_v2_preview_metrics(v2_preview_accum)
    _, pre_flat_v2 = _compute_phase_d_v2_metrics_bundle(
        entity_scope, v2_extractor_accum, empty_executor_v2_stats()
    )
    dat_telemetry = _build_dat_telemetry(
        dat_selected_count,
        dat_qa_pass_count,
        dat_qa_reject_count,
        dat_reject_counts_by_reason,
        canonical_records,
        actual_entity_counts,
        entity_scope,
        dat_v2_compact_flat=pre_flat_v2,
        dat_field_presence=dat_field_presence,
        dat_parse_diagnostics=dat_parse_diagnostics,
        dat_file_prefix_counts=dat_file_prefix_counts,
        dat_reject_file_prefix_counts=dat_reject_file_prefix_counts,
        dat_candidate_count=dat_candidate_count,
        dat_pre_qa_skipped_count=dat_pre_qa_skipped_count,
        dat_pre_qa_skip_counts_by_reason=dat_pre_qa_skip_counts_by_reason,
        dat_pre_qa_skip_file_prefix_counts=dat_pre_qa_skip_file_prefix_counts,
        dat_pre_qa_terminal_result_count=dat_pre_qa_terminal_result_count,
        dat_anchor_diagnostics=dat_anchor_diagnostics,
        dat_file_shape_diagnostics=dat_file_shape_diagnostics,
    )
    v2_exec_stats = empty_executor_v2_stats() if entity_scope == "v2" else None
    phase_d_v2_full = {}
    dat_v2_compact_flat = {}
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("BEGIN")
        try:
            _ensure_rule_decision_log_supports_extractor_skip(conn)
            for artifact_id, status, reject_code, reject_reason in qa_results:
                det_key = compute_qa_deterministic_key(artifact_id, QA_STAGE_PHASE_D, QA_POLICY_VERSION, status, reject_code)
                conn.execute(
                    "INSERT OR REPLACE INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (artifact_id, QA_STAGE_PHASE_D, QA_POLICY_VERSION, status, reject_code, reject_reason, det_key),
                )
            try:
                for artifact_id, reason_code in replay_entries:
                    conn.execute(
                        "INSERT OR REPLACE INTO replay_queue (artifact_id, reason_code, status, attempt_count) "
                        "VALUES (?, ?, 'pending', 0)",
                        (artifact_id, reason_code),
                    )
            except Exception as replay_err:
                raise RuntimeError((PHASE_D_REPLAY_QUEUE_ERROR, str(replay_err)))
            for rec in canonical_records:
                conn.execute(
                    "INSERT OR IGNORE INTO extracted_canonical_record "
                    "(artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (rec["artifact_id"], rec["canonical_type"], rec["canonical_key"], CANONICALIZATION_VERSION,
                     rec["canonical_json"], rec["provenance_json"]),
                )
            _log_extractor_skip_events(conn, (v2_extractor_accum or {}).get("skip_events"))
            actual_entity_counts, actual_constraint_counts = _execute_domain_upserts(
                conn, domain_upsert_rows, entity_scope, v2_exec_stats=v2_exec_stats
            )
            planning_telemetry = _build_planning_telemetry(
                canonical_records,
                reject_counts_by_code,
                reject_counts_by_artifact_code,
                actual_constraint_counts,
            )
            planning_telemetry = _merge_planning_with_join_telemetry(
                planning_telemetry, dat_csv_join_telemetry, csv_docx_join_telemetry, actual_constraint_counts
            )
            phase_d_v2_full, dat_v2_compact_flat = _compute_phase_d_v2_metrics_bundle(
                entity_scope, v2_extractor_accum, v2_exec_stats
            )
            phase_d_v2_readiness_preview = _build_phase_d_v2_readiness_preview(
                entity_scope, preview_phase_d_v2_full, phase_d_v2_full)
            dat_telemetry = _build_dat_telemetry(
                dat_selected_count,
                dat_qa_pass_count,
                dat_qa_reject_count,
                dat_reject_counts_by_reason,
                canonical_records,
                actual_entity_counts,
                entity_scope,
                dat_v2_compact_flat=dat_v2_compact_flat,
                dat_field_presence=dat_field_presence,
                dat_parse_diagnostics=dat_parse_diagnostics,
                dat_file_prefix_counts=dat_file_prefix_counts,
                dat_reject_file_prefix_counts=dat_reject_file_prefix_counts,
                dat_candidate_count=dat_candidate_count,
                dat_pre_qa_skipped_count=dat_pre_qa_skipped_count,
                dat_pre_qa_skip_counts_by_reason=dat_pre_qa_skip_counts_by_reason,
                dat_pre_qa_skip_file_prefix_counts=dat_pre_qa_skip_file_prefix_counts,
                dat_pre_qa_terminal_result_count=dat_pre_qa_terminal_result_count,
                dat_anchor_diagnostics=dat_anchor_diagnostics,
                dat_file_shape_diagnostics=dat_file_shape_diagnostics,
            )
            _log_planning_telemetry(conn, planning_telemetry)
            csv_docx_join_negotiation_id = _log_join_negotiation(
                conn, EVENT_CSV_DOCX_JOIN_NEGOTIATION, csv_docx_join_telemetry, rid
            )
            dat_csv_join_negotiation_id = _log_join_negotiation(
                conn, EVENT_DAT_CSV_JOIN_NEGOTIATION, dat_csv_join_telemetry, rid
            )
            conn.commit()
            if csv_docx_join_negotiation_id is not None:
                csv_docx_join_telemetry = dict(csv_docx_join_telemetry)
                csv_docx_join_telemetry["negotiation_run_id"] = rid
                csv_docx_join_telemetry["negotiation_telemetry_id"] = csv_docx_join_negotiation_id
                csv_docx_join_telemetry[KEY_NEGOTIATION_LOG_REF] = format_negotiation_log_ref(
                    csv_docx_join_negotiation_id,
                    rid,
                    EVENT_CSV_DOCX_JOIN_NEGOTIATION,
                )
            if dat_csv_join_negotiation_id is not None:
                dat_csv_join_telemetry = dict(dat_csv_join_telemetry)
                dat_csv_join_telemetry["negotiation_run_id"] = rid
                dat_csv_join_telemetry["negotiation_telemetry_id"] = dat_csv_join_negotiation_id
                dat_csv_join_telemetry[KEY_NEGOTIATION_LOG_REF] = format_negotiation_log_ref(
                    dat_csv_join_negotiation_id,
                    rid,
                    EVENT_DAT_CSV_JOIN_NEGOTIATION,
                )
        except Exception as e:
            conn.rollback()
            actual_entity_counts = {k: 0 for k in actual_entity_counts}
            actual_constraint_counts = _empty_constraint_skip_counts()
            planning_telemetry = _build_planning_telemetry(
                canonical_records,
                reject_counts_by_code,
                reject_counts_by_artifact_code,
                actual_constraint_counts,
            )
            planning_telemetry = _merge_planning_with_join_telemetry(
                planning_telemetry, dat_csv_join_telemetry, csv_docx_join_telemetry, actual_constraint_counts
            )
            phase_d_v2_fail, flat_fail = _compute_phase_d_v2_metrics_bundle(
                entity_scope, v2_extractor_accum, empty_executor_v2_stats()
            )
            phase_d_v2_readiness_fail = _build_phase_d_v2_readiness_preview(
                entity_scope, preview_phase_d_v2_full, phase_d_v2_fail)
            dat_telemetry = _build_dat_telemetry(
                dat_selected_count,
                dat_qa_pass_count,
                dat_qa_reject_count,
                dat_reject_counts_by_reason,
                canonical_records,
                actual_entity_counts,
                entity_scope,
                dat_v2_compact_flat=flat_fail,
                dat_field_presence=dat_field_presence,
                dat_parse_diagnostics=dat_parse_diagnostics,
                dat_file_prefix_counts=dat_file_prefix_counts,
                dat_reject_file_prefix_counts=dat_reject_file_prefix_counts,
                dat_candidate_count=dat_candidate_count,
                dat_pre_qa_skipped_count=dat_pre_qa_skipped_count,
                dat_pre_qa_skip_counts_by_reason=dat_pre_qa_skip_counts_by_reason,
                dat_pre_qa_skip_file_prefix_counts=dat_pre_qa_skip_file_prefix_counts,
                dat_pre_qa_terminal_result_count=dat_pre_qa_terminal_result_count,
                dat_anchor_diagnostics=dat_anchor_diagnostics,
                dat_file_shape_diagnostics=dat_file_shape_diagnostics,
            )
            error_code = PHASE_D_DB_WRITE_ERROR
            error_detail = str(e)[:200]
            if isinstance(e, RuntimeError) and e.args and e.args[0][0] == PHASE_D_REPLAY_QUEUE_ERROR:
                error_code = PHASE_D_REPLAY_QUEUE_ERROR
                error_detail = str(e.args[0][1])[:200] if len(e.args[0]) > 1 else str(e)[:200]
            summary_fail = _build_summary(rid, ok=False, rows_selected=len(rows), qa_pass_count=qa_pass_count,
                                          qa_reject_count=qa_reject_count, reject_counts_by_code=reject_counts_by_code,
                                          replay_enqueued_count=replay_enqueued_count,
                                          canonical_record_count=len(canonical_records),
                                          entity_upsert_counts=actual_entity_counts, error_code=error_code,
                                          error_detail=error_detail, source_exception_class=e.__class__.__name__,
                                          constraint_skip_counts=actual_constraint_counts,
                                          planning_telemetry=planning_telemetry,
                                          artifact_class_filter=artifact_class_filter,
                                          entity_scope=entity_scope,
                                          dat_telemetry=dat_telemetry,
                                          csv_docx_join_telemetry=csv_docx_join_telemetry,
                                          dat_csv_join_telemetry=dat_csv_join_telemetry,
                                          phase_d_v2_domain_metrics=phase_d_v2_fail,
                                          phase_d_v2_readiness_preview=phase_d_v2_readiness_fail,
                                          layer1_flat=_layer1_flat_for_qa(
                                              layer1_bundle, csv_docx_join_telemetry, dat_csv_join_telemetry, False))
            if layer1_write_error and not summary_fail.get("layer1_join_debug_generated"):
                for __k, __v in _layer1_write_error_flat(layer1_write_error).items():
                    summary_fail[__k] = __v
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            summary_fail = _attach_phase_d_contract_report_paths(summary_fail, reports_dir, rid, reject_samples)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            try:
                persist_phase_d_state(lab_root, rid, False, error_code, qa_pass_count, qa_reject_count,
                                      replay_enqueued_count, len(canonical_records), actual_entity_counts,
                                      constraint_skip_counts=actual_constraint_counts,
                                      dat_telemetry=dat_telemetry,
                                      csv_docx_join_telemetry=csv_docx_join_telemetry,
                                      dat_csv_join_telemetry=dat_csv_join_telemetry,
                                      selection_scope=summary_fail.get("selection_scope"),
                                      zero_selection_reason_codes=summary_fail.get("zero_selection_reason_codes"),
                                      phase_c_summary_run_id_used_for_zero_selection=summary_fail.get(
                                          "phase_c_summary_run_id_used_for_zero_selection"),
                                      phase_c_summary_path_used_for_zero_selection=summary_fail.get(
                                          "phase_c_summary_path_used_for_zero_selection"))
                _sync_phase_d_remediation_safe(lab_root, rid, summary_fail)
            except Exception:
                pass
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_d_auto_report import submit_phase_d_failure_report
                submit_phase_d_failure_report(lab_root, {"error_code": error_code, "run_id": rid,
                                                         "first_failed": error_detail[:100], "lab_root": lab_root,
                                                         "report_json_path": summary_json_path,
                                                         "report_txt_path": summary_txt_path, "summary": summary_fail})
            except Exception:
                pass
            return False, rid, summary_fail, error_code
        finally:
            conn.close()

        summary = _build_summary(rid, ok=True, rows_selected=len(rows), qa_pass_count=qa_pass_count,
                                qa_reject_count=qa_reject_count, reject_counts_by_code=reject_counts_by_code,
                                replay_enqueued_count=replay_enqueued_count,
                                canonical_record_count=len(canonical_records),
                                entity_upsert_counts=actual_entity_counts,
                                constraint_skip_counts=actual_constraint_counts,
                                planning_telemetry=planning_telemetry,
                                artifact_class_filter=artifact_class_filter,
                                entity_scope=entity_scope,
                                dat_telemetry=dat_telemetry,
                                csv_docx_join_telemetry=csv_docx_join_telemetry,
                                dat_csv_join_telemetry=dat_csv_join_telemetry,
                                phase_d_v2_domain_metrics=phase_d_v2_full,
                                phase_d_v2_readiness_preview=phase_d_v2_readiness_preview,
                                layer1_flat=_layer1_flat_for_qa(
                                    layer1_bundle, csv_docx_join_telemetry, dat_csv_join_telemetry, True))
        if layer1_write_error and not summary.get("layer1_join_debug_generated"):
            for __k, __v in _layer1_write_error_flat(layer1_write_error).items():
                summary[__k] = __v
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        summary = _attach_phase_d_contract_report_paths(summary, reports_dir, rid, reject_samples)
        _write_summary_json(summary, summary_json_path)
        _write_summary_txt(summary, summary_txt_path)
        with open(reject_samples_path, "w", encoding="utf-8") as f:
            for s in reject_samples[:50]:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")
        try:
            persist_phase_d_state(lab_root, rid, True, None, qa_pass_count, qa_reject_count,
                                  replay_enqueued_count, len(canonical_records), actual_entity_counts,
                                  constraint_skip_counts=actual_constraint_counts,
                                  dat_telemetry=dat_telemetry,
                                  csv_docx_join_telemetry=csv_docx_join_telemetry,
                                  dat_csv_join_telemetry=dat_csv_join_telemetry,
                                  selection_scope=summary.get("selection_scope"),
                                  zero_selection_reason_codes=summary.get("zero_selection_reason_codes"),
                                  phase_c_summary_run_id_used_for_zero_selection=summary.get(
                                      "phase_c_summary_run_id_used_for_zero_selection"),
                                  phase_c_summary_path_used_for_zero_selection=summary.get(
                                      "phase_c_summary_path_used_for_zero_selection"))
            _sync_phase_d_remediation_safe(lab_root, rid, summary)
        except Exception as persist_err:
            summary["ok"] = False
            summary["error_code"] = PHASE_D_STATE_WRITE_ERROR
            summary["error_detail"] = str(persist_err)[:200]
            summary["source_exception_class"] = persist_err.__class__.__name__
            summary["recoverability"] = build_failure_context(
                "D", PHASE_D_STATE_WRITE_ERROR, str(persist_err)[:200], persist_err.__class__.__name__
            ).get("recoverability", "")
            summary["failure_contract"] = build_failure_context(
                "D", PHASE_D_STATE_WRITE_ERROR, str(persist_err)[:200], persist_err.__class__.__name__
            )
            _l1p = _layer1_flat_for_qa(layer1_bundle, csv_docx_join_telemetry, dat_csv_join_telemetry, False)
            for __lk, __lv in (_l1p or {}).items():
                summary[__lk] = __lv
            _write_summary_json(summary, summary_json_path)
            _write_summary_txt(summary, summary_txt_path)
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_d_auto_report import submit_phase_d_failure_report
                submit_phase_d_failure_report(lab_root, {"error_code": PHASE_D_STATE_WRITE_ERROR, "run_id": rid,
                                                         "first_failed": str(persist_err)[:100], "lab_root": lab_root,
                                                         "report_json_path": summary_json_path,
                                                         "report_txt_path": summary_txt_path, "summary": summary})
            except Exception:
                pass
            return False, rid, summary, PHASE_D_STATE_WRITE_ERROR
    finally:
        release_lock(lab_root, owner_pid=os.getpid())

    return True, rid, summary, None


def _build_summary(rid, ok, rows_selected, qa_pass_count=0, qa_reject_count=0, reject_counts_by_code=None,
                    replay_enqueued_count=0, canonical_record_count=0, entity_upsert_counts=None,
                    error_code=None, error_detail="", source_exception_class="", recoverability="",
                    constraint_skip_counts=None, artifact_class_filter=None, planning_telemetry=None,
                    entity_scope="v1", dat_telemetry=None, csv_docx_join_telemetry=None,
                    dat_csv_join_telemetry=None, phase_d_v2_domain_metrics=None,
                    phase_d_v2_readiness_preview=None,
                    selection_scope=None,
                    zero_selection_reason_codes=None,
                    phase_c_summary_run_id_used_for_zero_selection=None,
                    phase_c_summary_path_used_for_zero_selection=None,
                    phase_c_context_mismatch_warning=None,
                    historical_reject_counts_by_class=None,
                    historical_reject_counts_by_version=None,
                    historical_reprocess_candidate=None,
                    historical_reprocess_targeted_artifact_classes=None,
                    zero_selection_analysis_available=True,
                    layer1_flat=None):
    failure = build_failure_context("D", error_code, error_detail, source_exception_class) if error_code else {}
    recoverability_value = recoverability or (failure.get("recoverability", "") if failure else "")
    if selection_scope is None:
        selection_scope = PHASE_D_SELECTION_SCOPE
    if zero_selection_reason_codes is None:
        zero_selection_reason_codes = []
    if phase_c_summary_run_id_used_for_zero_selection is None:
        phase_c_summary_run_id_used_for_zero_selection = ""
    if phase_c_summary_path_used_for_zero_selection is None:
        phase_c_summary_path_used_for_zero_selection = ""
    if phase_c_context_mismatch_warning is None:
        phase_c_context_mismatch_warning = ""
    if historical_reject_counts_by_class is None:
        historical_reject_counts_by_class = {}
    if historical_reject_counts_by_version is None:
        historical_reject_counts_by_version = {}
    if historical_reprocess_candidate is None:
        historical_reprocess_candidate = False
    if historical_reprocess_targeted_artifact_classes is None:
        historical_reprocess_targeted_artifact_classes = []
    result = {
        "phase": "D",
        "ok": ok,
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "qa_policy_version": QA_POLICY_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "selection_scope": selection_scope,
        "rows_selected": rows_selected,
        "qa_pass_count": qa_pass_count,
        "qa_reject_count": qa_reject_count,
        "reject_counts_by_code": reject_counts_by_code or {},
        "replay_enqueued_count": replay_enqueued_count,
        "canonical_record_count": canonical_record_count,
        "entity_upsert_counts": entity_upsert_counts or {},
        "constraint_skip_counts": constraint_skip_counts or {},
        "planning_telemetry": planning_telemetry or {},
        "dat_telemetry": dat_telemetry or {},
        "csv_docx_join_telemetry": csv_docx_join_telemetry or {},
        "dat_csv_join_telemetry": dat_csv_join_telemetry or {},
        "artifact_class_filter": list(artifact_class_filter or []),
        "artifact_scope_policy": dict(_PHASE_D_ARTIFACT_SCOPE_POLICY),
        "phase_run_ids_warning": str(_PHASE_RUN_IDS_WARNING or ""),
        "phase_d_entity_scope": str(entity_scope or "v1"),
        "zero_selection_reason_codes": list(zero_selection_reason_codes),
        "phase_c_summary_run_id_used_for_zero_selection": str(phase_c_summary_run_id_used_for_zero_selection or ""),
        "phase_c_summary_path_used_for_zero_selection": str(phase_c_summary_path_used_for_zero_selection or ""),
        "phase_c_context_mismatch_warning": str(phase_c_context_mismatch_warning or ""),
        "historical_reject_counts_by_class": dict(historical_reject_counts_by_class),
        "historical_reject_counts_by_version": dict(historical_reject_counts_by_version),
        "historical_reprocess_candidate": bool(historical_reprocess_candidate),
        "historical_reprocess_targeted_artifact_classes": list(historical_reprocess_targeted_artifact_classes),
        "zero_selection_analysis_available": bool(zero_selection_analysis_available),
        "error_code": error_code,
        "error_detail": error_detail or "",
        "recoverability": recoverability_value,
        "source_exception_class": source_exception_class or "",
        "failure_contract": failure,
        "phase_d_v2_domain_metrics": phase_d_v2_domain_metrics if isinstance(phase_d_v2_domain_metrics, dict) else {},
        "phase_d_v2_readiness_preview": (
            phase_d_v2_readiness_preview if isinstance(phase_d_v2_readiness_preview, dict) else {}),
    }
    if isinstance(layer1_flat, dict):
        for _lk1, _lv1 in layer1_flat.items():
            result[_lk1] = _lv1
    closure = _build_phase_d_closure_readiness(result)
    result["phase_d_closure_readiness"] = dict(closure)
    for _ck, _cv in closure.items():
        result[_ck] = _cv
    return result


def _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir):
    try:
        acquire_lock(lab_root)
        try:
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            persist_phase_d_state(
                lab_root, rid, False, summary_fail.get("error_code"), 0, 0, 0, 0, {},
                dat_telemetry=summary_fail.get("dat_telemetry") or {},
                csv_docx_join_telemetry=summary_fail.get("csv_docx_join_telemetry") or {},
                dat_csv_join_telemetry=summary_fail.get("dat_csv_join_telemetry") or {},
                selection_scope=summary_fail.get("selection_scope"),
                zero_selection_reason_codes=summary_fail.get("zero_selection_reason_codes"),
                phase_c_summary_run_id_used_for_zero_selection=summary_fail.get(
                    "phase_c_summary_run_id_used_for_zero_selection"),
                phase_c_summary_path_used_for_zero_selection=summary_fail.get(
                    "phase_c_summary_path_used_for_zero_selection"),
            )
            _sync_phase_d_remediation_safe(lab_root, rid, summary_fail)
        finally:
            release_lock(lab_root, owner_pid=os.getpid())
        try:
            from phase_d_auto_report import submit_phase_d_failure_report
            submit_phase_d_failure_report(lab_root, {"error_code": summary_fail.get("error_code"),
                                                     "run_id": rid, "first_failed": "prelock",
                                                     "lab_root": lab_root, "report_json_path": summary_json_path,
                                                     "report_txt_path": summary_txt_path, "summary": summary_fail})
        except Exception:
            pass
    except SystemExit:
        pass


def _write_summary_json(summary, path):
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _write_summary_txt(summary, path):
    dat_telemetry = summary.get("dat_telemetry") or {}
    csv_docx_join = summary.get("csv_docx_join_telemetry") or {}
    dat_csv_join = summary.get("dat_csv_join_telemetry") or {}
    lines = [
        "Phase D QA and Canonicalization Summary",
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "selection_scope: {0}".format(summary.get("selection_scope", PHASE_D_SELECTION_SCOPE)),
        "rows_selected: {0}".format(summary.get("rows_selected", 0)),
        "zero_selection_analysis_available: {0}".format(summary.get("zero_selection_analysis_available", True)),
        "zero_selection_reason_codes: {0}".format(json.dumps(summary.get("zero_selection_reason_codes") or [], ensure_ascii=False)),
        "phase_c_summary_run_id_used_for_zero_selection: {0}".format(summary.get("phase_c_summary_run_id_used_for_zero_selection", "")),
        "phase_c_summary_path_used_for_zero_selection: {0}".format(summary.get("phase_c_summary_path_used_for_zero_selection", "")),
        "phase_c_context_mismatch_warning: {0}".format(summary.get("phase_c_context_mismatch_warning", "")),
        "phase_c_summary_resolution_source: {0}".format(summary.get("phase_c_summary_resolution_source", "")),
        "phase_c_expected_run_id_for_zero_selection: {0}".format(summary.get("phase_c_expected_run_id_for_zero_selection", "")),
        "phase_c_lineage_coherent: {0}".format(summary.get("phase_c_lineage_coherent", True)),
        "historical_reject_counts_by_class: {0}".format(json.dumps(summary.get("historical_reject_counts_by_class") or {}, sort_keys=True)),
        "historical_reject_counts_by_version: {0}".format(json.dumps(summary.get("historical_reject_counts_by_version") or {}, sort_keys=True)),
        "historical_reprocess_candidate: {0}".format(summary.get("historical_reprocess_candidate", False)),
        "historical_reprocess_targeted_artifact_classes: {0}".format(",".join(summary.get("historical_reprocess_targeted_artifact_classes") or [])),
        "qa_pass_count: {0}".format(summary.get("qa_pass_count", 0)),
        "qa_reject_count: {0}".format(summary.get("qa_reject_count", 0)),
        "replay_enqueued_count: {0}".format(summary.get("replay_enqueued_count", 0)),
        "canonical_record_count: {0}".format(summary.get("canonical_record_count", 0)),
        "patient_invalid_external_id_skipped: {0}".format(
            (summary.get("constraint_skip_counts") or {}).get("patient_invalid_external_id", 0)
        ),
        "patient_invalid_external_id_by_source_contract: {0}".format(json.dumps(
            (summary.get("constraint_skip_counts") or {}).get("patient_invalid_external_id_by_source_contract") or {},
            sort_keys=True)),
        "patient_invalid_external_id_by_contract_disposition: {0}".format(json.dumps(
            (summary.get("constraint_skip_counts") or {}).get("patient_invalid_external_id_by_contract_disposition") or {},
            sort_keys=True)),
        "workstream_b_activation_recommended: {0}".format(
            ((summary.get("planning_telemetry") or {}).get("workstream_b") or {}).get("activation_recommended", False)
        ),
        "workstream_c_activation_recommended: {0}".format(
            ((summary.get("planning_telemetry") or {}).get("workstream_c") or {}).get("activation_recommended", False)
        ),
        "workstream_d_activation_recommended: {0}".format(
            ((summary.get("planning_telemetry") or {}).get("workstream_d") or {}).get("activation_recommended", False)
        ),
        "dat_selected_count: {0}".format(dat_telemetry.get("dat_selected_count", 0)),
        "dat_candidate_count: {0}".format(dat_telemetry.get("dat_candidate_count", 0)),
        "dat_pre_qa_skipped_count: {0}".format(dat_telemetry.get("dat_pre_qa_skipped_count", 0)),
        "dat_pre_qa_skip_counts_by_reason: {0}".format(json.dumps(dat_telemetry.get("dat_pre_qa_skip_counts_by_reason") or {}, sort_keys=True)),
        "dat_pre_qa_terminal_result_count: {0}".format(dat_telemetry.get("dat_pre_qa_terminal_result_count", 0)),
        "dat_empty_file_skipped_count: {0}".format(dat_telemetry.get("dat_empty_file_skipped_count", 0)),
        "dat_qa_pass_count: {0}".format(dat_telemetry.get("dat_qa_pass_count", 0)),
        "dat_qa_reject_count: {0}".format(dat_telemetry.get("dat_qa_reject_count", 0)),
        "dat_canonical_record_count: {0}".format(dat_telemetry.get("dat_canonical_record_count", 0)),
        "dat_parse_failure_count: {0}".format(((dat_telemetry.get("dat_parse_diagnostics") or {}).get("tuple_parse_failure_count", 0))),
        "dat_file_prefix_mix: {0}".format(json.dumps(dat_telemetry.get("dat_file_prefix_counts") or {}, sort_keys=True)),
        "dat_pre_qa_skip_file_prefix_mix: {0}".format(json.dumps(dat_telemetry.get("dat_pre_qa_skip_file_prefix_counts") or {}, sort_keys=True)),
        "dat_anchor_diagnostics: {0}".format(json.dumps(dat_telemetry.get("dat_anchor_diagnostics") or {}, sort_keys=True)),
        "dat_file_shape_diagnostics: {0}".format(json.dumps(dat_telemetry.get("dat_file_shape_diagnostics") or {}, sort_keys=True)),
        "post_medisoft_exercised: {0}".format(dat_telemetry.get("post_medisoft_exercised", False)),
        "post_medisoft_blocked_stage: {0}".format(dat_telemetry.get("post_medisoft_blocked_stage", "")),
        "csv_docx_join_key: {0}".format(csv_docx_join.get("join_key", "")),
        "csv_docx_join_csv_candidate_count: {0}".format(csv_docx_join.get("csv_candidate_count", 0)),
        "csv_docx_join_csv_join_key_count: {0}".format(csv_docx_join.get("csv_join_key_count", 0)),
        "csv_docx_join_docx_candidate_count: {0}".format(csv_docx_join.get("docx_candidate_count", 0)),
        "csv_docx_join_docx_join_key_count: {0}".format(csv_docx_join.get("docx_join_key_count", 0)),
        "csv_docx_join_matched_count: {0}".format(csv_docx_join.get("matched_count", 0)),
        "csv_docx_join_csv_only_count: {0}".format(csv_docx_join.get("csv_only_count", 0)),
        "csv_docx_join_docx_only_count: {0}".format(csv_docx_join.get("docx_only_count", 0)),
        "csv_docx_join_ambiguous_count: {0}".format(csv_docx_join.get("ambiguous_count", 0)),
        "dat_csv_join_matched_count: {0}".format(dat_csv_join.get("matched_count", 0)),
        "dat_csv_join_csv_only_count: {0}".format(dat_csv_join.get("csv_only_count", 0)),
        "dat_csv_join_dat_only_count: {0}".format(dat_csv_join.get("dat_only_count", 0)),
        "dat_csv_join_ambiguous_multi_dat_count: {0}".format(dat_csv_join.get("ambiguous_multi_dat_count", 0)),
        "dat_csv_join_payer_mismatch_count: {0}".format(dat_csv_join.get("payer_mismatch_count", 0)),
        "dat_csv_join_dos_mismatch_count: {0}".format(dat_csv_join.get("dos_mismatch_count", 0)),
        "dat_csv_join_invalid_external_id_csv_count: {0}".format(dat_csv_join.get("invalid_external_id_csv_count", 0)),
        "artifact_class_filter: {0}".format(",".join(summary.get("artifact_class_filter") or [])),
        "phase_d_entity_scope: {0}".format(summary.get("phase_d_entity_scope", "v1")),
        "phase_d_data_plane_stage: {0}".format(summary.get("phase_d_data_plane_stage", "")),
        "phase_d_v2_execution_decision: {0}".format(summary.get("phase_d_v2_execution_decision", "")),
        "phase_d_v2_disabled_reason: {0}".format(summary.get("phase_d_v2_disabled_reason", "")),
        "phase_d_v2_zero_insert_reason: {0}".format(
            (summary.get("phase_d_v2_readiness_preview") or {}).get("dat_v2_zero_insert_reason", "")),
        "next_predicted_stall: {0}".format(summary.get("next_predicted_stall", "")),
        "next_predicted_stall_evidence: {0}".format(json.dumps(
            summary.get("next_predicted_stall_evidence") or {}, sort_keys=True)),
        "phase_d_invalid_external_id_contract_report_json_path: {0}".format(
            summary.get("phase_d_invalid_external_id_contract_report_json_path", "")),
        "dat_anchor_failure_profile_json_path: {0}".format(
            summary.get("dat_anchor_failure_profile_json_path", "")),
        "phase_d_developer_unblock: {0}".format(json.dumps(
            summary.get("phase_d_developer_unblock") or {}, sort_keys=True)),
        "error_code: {0}".format(summary.get("error_code", "")),
        "recoverability: {0}".format(summary.get("recoverability", "")),
        "source_exception_class: {0}".format(summary.get("source_exception_class", "")),
    ]
    extend_summary_txt_lines(lines, csv_docx_join, dat_csv_join)
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def persist_phase_d_state(lab_root, rid, ok, error_code, pass_count, reject_count, replay_pending, canonical_count,
                         entity_upserts, constraint_skip_counts=None, dat_telemetry=None,
                         csv_docx_join_telemetry=None, dat_csv_join_telemetry=None,
                         selection_scope=None, zero_selection_reason_codes=None,
                         phase_c_summary_run_id_used_for_zero_selection=None,
                         phase_c_summary_path_used_for_zero_selection=None):
    """Update run_cursor.json and diagnostics_state.json with Phase D outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    dat_telemetry = dat_telemetry or {}
    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_d_run_id"] = rid
    cursor["last_phase_d_ok"] = ok
    cursor["last_qa_policy_version"] = QA_POLICY_VERSION
    cursor["last_canonicalization_version"] = CANONICALIZATION_VERSION
    cursor["last_phase_d_pass_count"] = pass_count
    cursor["last_phase_d_reject_count"] = reject_count
    cursor["last_phase_d_replay_pending"] = replay_pending
    cursor["last_phase_d_constraint_skip_counts"] = constraint_skip_counts or {}
    cursor["last_phase_d_dat_telemetry"] = dat_telemetry
    cursor["last_phase_d_csv_docx_join_telemetry"] = csv_docx_join_telemetry
    cursor["last_phase_d_dat_csv_join_telemetry"] = dat_csv_join_telemetry
    cursor["last_phase_d_error_code"] = error_code
    cursor["last_phase_d_at_utc"] = now
    if selection_scope is not None:
        cursor["last_phase_d_selection_scope"] = selection_scope
    if zero_selection_reason_codes is not None:
        cursor["last_phase_d_zero_selection_reason_codes"] = list(zero_selection_reason_codes)
    if phase_c_summary_run_id_used_for_zero_selection is not None:
        cursor["last_phase_d_phase_c_summary_run_id_used_for_zero_selection"] = str(
            phase_c_summary_run_id_used_for_zero_selection or "")
    if phase_c_summary_path_used_for_zero_selection is not None:
        cursor["last_phase_d_phase_c_summary_path_used_for_zero_selection"] = str(
            phase_c_summary_path_used_for_zero_selection or "")
    refresh_run_cursor_updated_at(cursor)
    replace_safe_write(cursor_path, cursor)
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_phase_d_run_id"] = rid
    state["last_phase_d_ok"] = ok
    state["last_qa_policy_version"] = QA_POLICY_VERSION
    state["last_canonicalization_version"] = CANONICALIZATION_VERSION
    state["last_phase_d_pass_count"] = pass_count
    state["last_phase_d_reject_count"] = reject_count
    state["last_phase_d_replay_pending"] = replay_pending
    state["last_phase_d_constraint_skip_counts"] = constraint_skip_counts or {}
    state["last_phase_d_dat_telemetry"] = dat_telemetry
    state["last_phase_d_csv_docx_join_telemetry"] = csv_docx_join_telemetry
    state["last_phase_d_dat_csv_join_telemetry"] = dat_csv_join_telemetry
    state["last_phase_d_error_code"] = error_code
    state["last_phase_d_at_utc"] = now
    if selection_scope is not None:
        state["last_phase_d_selection_scope"] = selection_scope
    if zero_selection_reason_codes is not None:
        state["last_phase_d_zero_selection_reason_codes"] = list(zero_selection_reason_codes)
    if phase_c_summary_run_id_used_for_zero_selection is not None:
        state["last_phase_d_phase_c_summary_run_id_used_for_zero_selection"] = str(
            phase_c_summary_run_id_used_for_zero_selection or "")
    if phase_c_summary_path_used_for_zero_selection is not None:
        state["last_phase_d_phase_c_summary_path_used_for_zero_selection"] = str(
            phase_c_summary_path_used_for_zero_selection or "")
    replace_safe_write(state_path, state)


def main():
    parser = argparse.ArgumentParser(description="Phase D QA and canonicalization")
    parser.add_argument("--lab-dir", help="Override lab root")
    parser.add_argument(
        "--artifact-classes",
        dest="artifact_classes",
        default=None,
        help="Comma-separated artifact classes to include (default: all eligible classes)",
    )
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    env_filter = os.environ.get("MEDICAFE_PHASE_D_ARTIFACT_CLASSES", "")
    if args.artifact_classes is not None:
        raw_filter = args.artifact_classes
        source = "cli"
    elif env_filter:
        raw_filter = env_filter
        source = "env_override"
    else:
        raw_filter = ""
        source = "default"
    artifact_policy = resolve_phase_d_artifact_scope_policy(lab_root, raw_filter, source)
    artifact_filter = artifact_policy.get("artifact_classes") or []
    ok, rid, summary, error_code = run_qa_canonical(
        lab_root,
        artifact_classes=artifact_filter,
        artifact_scope_source=source,
    )
    if not ok:
        print("Phase D failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    print("Phase D ok: {0} pass, {1} reject, {2} canonical".format(
        summary.get("qa_pass_count", 0), summary.get("qa_reject_count", 0),
        summary.get("canonical_record_count", 0)))


if __name__ == "__main__":
    main()
