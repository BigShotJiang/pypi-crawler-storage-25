#!/usr/bin/env python
"""
Shared patient-field mapping helpers for Phase D and Phase E.
Deterministic, XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import re
from datetime import datetime


EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN = "^[0-9]{5}$"
_EXTERNAL_ID_PATTERN = re.compile(EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN)
_EXTERNAL_ID_DECIMAL_ARTIFACT_PATTERN = re.compile(r"^([0-9]+)\.([0-9]+)$")
_EMBEDDED_5_DIGIT_PATTERN = re.compile(r"(^|[^0-9])([0-9]{5})([^0-9]|$)")
_SURGERY_DATE_FORMATS = (
    "%m/%d/%Y",
    "%m-%d-%Y",
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%m/%d/%y",
    "%m-%d-%y",
)


def _to_text(value):
    """Normalize any value to stripped text (empty string for None)."""
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:
        return ""


def extract_external_patient_id(row):
    """Extract external patient ID from CSV-like row dict."""
    if not isinstance(row, dict):
        return ""
    value = row.get("Patient ID") or row.get("patient_id")
    diag = normalize_external_patient_id(value, "csv_row.patient_id")
    if diag.get("is_valid"):
        return diag.get("value") or ""
    return _to_text(value)


def extract_birth_date(row):
    """Extract birth date from CSV-like row dict using known aliases."""
    if not isinstance(row, dict):
        return ""
    return _to_text(
        row.get("Birth Date")
        or row.get("birth_date")
        or row.get("DOB")
        or row.get("Patient DOB")
    )


def extract_full_name(row):
    """
    Extract full name from CSV-like row dict.
    Falls back to Patient First + Patient Last when Patient Name is absent.
    """
    if not isinstance(row, dict):
        return ""
    direct = _to_text(row.get("Patient Name") or row.get("patient_name"))
    if direct:
        return direct
    first = _to_text(row.get("Patient First") or row.get("patient_first"))
    last = _to_text(row.get("Patient Last") or row.get("patient_last"))
    return _to_text((first + " " + last).strip())


def extract_surgery_date(row):
    """Extract surgery date / service date from CSV-like row dict using known aliases."""
    if not isinstance(row, dict):
        return ""
    return _to_text(
        row.get("Surgery Date")
        or row.get("surgery_date")
        or row.get("Date of Service")
        or row.get("date_of_service")
        or row.get("DOS")
        or row.get("DATE1")
    )


def normalize_surgery_date_key(value):
    """Normalize a surgery date value to MM-DD-YYYY for cross-artifact joins."""
    text = _to_text(value)
    if not text:
        return ""
    candidates = [text]
    if "T" in text:
        candidates.append(text.split("T", 1)[0].strip())
    if " " in text:
        candidates.append(text.split(" ", 1)[0].strip())
    seen = set()
    for candidate in candidates:
        candidate = _to_text(candidate)
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        for fmt in _SURGERY_DATE_FORMATS:
            try:
                return datetime.strptime(candidate, fmt).strftime("%m-%d-%Y")
            except Exception:
                pass
    return _to_text(text.replace("/", "-"))


def is_valid_external_patient_id_5_digit(value):
    """Return True only when value is exactly five numeric digits."""
    return bool(classify_external_patient_id_5_digit(value).get("is_valid"))


def _ascii_digit_count(text):
    count = 0
    for ch in text:
        if ch >= "0" and ch <= "9":
            count += 1
    return count


def _is_ascii_digits(text):
    if not text:
        return False
    return _ascii_digit_count(text) == len(text)


def _raw_shape(raw_text, text, pattern_family):
    """PHI-safe shape metadata for diagnostics; never includes source text."""
    if raw_text and not text:
        return "whitespace:length={0}".format(len(raw_text))
    if not text:
        return "empty:length=0"
    digit_count = _ascii_digit_count(text)
    return "{0}:length={1},digits={2}".format(pattern_family or "unknown", len(text), digit_count)


def _decimal_artifact_parts(text):
    match = _EXTERNAL_ID_DECIMAL_ARTIFACT_PATTERN.match(text)
    if not match:
        return None, None
    return match.group(1), match.group(2)


def _unambiguous_embedded_5_digit(text):
    if not text:
        return ""
    if _ascii_digit_count(text) != 5:
        return ""
    matches = list(_EMBEDDED_5_DIGIT_PATTERN.finditer(text))
    if len(matches) != 1:
        return ""
    return matches[0].group(2)


def normalize_external_patient_id(value, source=None, mode=None):
    """
    Normalize external patient IDs with strict five-ASCII-digit enforcement.

    Returns a diagnostics dict. Valid values expose ``value`` as the normalized
    five-digit ID. Invalid values expose only PHI-safe shape metadata.
    """
    if value is None:
        raw_text = ""
    else:
        try:
            raw_text = str(value)
        except Exception:
            raw_text = ""
    text = raw_text.strip()
    source = _to_text(source) or "external_patient_id"
    mode = _to_text(mode) or "coerce_lossless_decimal"
    allow_decimal = mode not in ("strict", "no_decimal", "reject_decimal")
    allow_embedded = mode not in ("strict", "no_embedded", "reject_embedded")

    normalized = text
    reason = ""
    pattern_family = "valid"
    decimal_coerced = False
    decimal_left, decimal_right = _decimal_artifact_parts(text)
    if decimal_left is not None:
        if allow_decimal and decimal_right and set(decimal_right) == set(["0"]):
            normalized = decimal_left
            decimal_coerced = True
            reason = "coerced_lossless_decimal"
            pattern_family = "decimal_lossless"
        else:
            normalized = text
            reason = "decimal_non_lossless"
            pattern_family = "decimal_like"
    embedded_coerced = False
    if not _EXTERNAL_ID_PATTERN.match(normalized) and decimal_left is None and allow_embedded:
        embedded_candidate = _unambiguous_embedded_5_digit(text)
        if embedded_candidate:
            normalized = embedded_candidate
            embedded_coerced = True
            reason = "coerced_unambiguous_embedded_5_digit"
            pattern_family = "embedded_5_digit"

    is_valid = bool(_EXTERNAL_ID_PATTERN.match(normalized))
    if is_valid:
        safe_value = normalized
        display = normalized
        if not reason:
            pattern_family = "valid"
    else:
        safe_value = ""
        if raw_text and not text:
            reason = "whitespace"
            pattern_family = "whitespace"
        elif not text:
            reason = "missing"
            pattern_family = "empty"
        elif reason == "decimal_non_lossless":
            pass
        elif decimal_left is not None:
            reason = "wrong_length" if decimal_coerced else "decimal_non_lossless"
            if decimal_coerced:
                if len(normalized) < 5:
                    pattern_family = "too_short"
                elif len(normalized) > 5:
                    pattern_family = "too_long"
                else:
                    pattern_family = "decimal_like"
            else:
                pattern_family = "decimal_like"
        elif any(ch >= "0" and ch <= "9" for ch in text) and "." in text:
            reason = "decimal_non_lossless"
            pattern_family = "decimal_like"
        elif not _is_ascii_digits(text):
            reason = "non_numeric"
            pattern_family = "embedded_text" if any(ch >= "0" and ch <= "9" for ch in text) else "non_digit"
        elif len(text) < 5:
            reason = "wrong_length"
            pattern_family = "too_short"
        elif len(text) > 5:
            reason = "wrong_length"
            pattern_family = "too_long"
        else:
            reason = "wrong_length"
            pattern_family = "wrong_length"
        display = "pattern_family={0},length={1},digit_count={2}".format(
            pattern_family,
            len(text),
            _ascii_digit_count(text),
        )

    leading_zero_loss_candidate = False
    if not is_valid and reason == "wrong_length" and pattern_family == "too_short":
        candidate_text = normalized if _is_ascii_digits(normalized) else text
        if _is_ascii_digits(candidate_text) and len(candidate_text) > 0 and len(candidate_text) < 5:
            leading_zero_loss_candidate = True

    return {
        "raw_value": "",
        "raw_shape": _raw_shape(raw_text, text, pattern_family),
        "value": safe_value,
        "normalized_value": safe_value,
        "normalized_display": display,
        "is_valid": is_valid,
        "pattern": EXTERNAL_PATIENT_ID_5_DIGIT_PATTERN,
        "source": source,
        "source_alias": source,
        "reason": reason if not is_valid or decimal_coerced or embedded_coerced else "",
        "pattern_family": pattern_family,
        "length": len(normalized if is_valid else text),
        "raw_length": len(text),
        "digit_count": _ascii_digit_count(text),
        "trimmed": raw_text != text,
        "decimal_coerced": bool(decimal_coerced and is_valid),
        "embedded_coerced": bool(embedded_coerced and is_valid),
        "leading_zero_loss_candidate": bool(leading_zero_loss_candidate),
        "leading_zero_loss_confirmation_required": bool(leading_zero_loss_candidate),
        "mode": mode,
    }


def classify_external_patient_id_5_digit(value, source="external_patient_id"):
    """
    Classify strict external patient ID validity with stable diagnostics.

    The contract is intentionally narrow: exactly five numeric digits.
    """
    return normalize_external_patient_id(value, source)


def external_patient_id_source_contract(source):
    """Return a stable source contract bucket for patient ID diagnostics."""
    text = _to_text(source)
    lower = text.lower()
    if lower in ("patient_csv_row.patient id", "patient_csv_row.patient_id"):
        return "medibot_csv_patient_id_field"
    if lower in ("docx_schedule.patient_id", "docx_schedule.patient id"):
        return "medibot_docx_patient_id_field"
    if lower in ("dat_record.patient_id", "dat_record.patid", "dat_record.chart"):
        return "medilink_dat_patient_id_field"
    if lower.endswith(".patient id") or lower.endswith(".patient_id"):
        return "patient_id_field"
    return "other_patient_id_source"


def external_patient_id_contract_disposition(invalid_id_diag):
    """
    Classify invalid patient ID evidence without changing the value.

    This is intentionally diagnostic-only. MediBot/MediLink already treat the
    5-digit ID as the patient identity contract; Layer 1 should not broadly
    repair values that appear to be display text or the wrong source column.
    """
    diag = invalid_id_diag if isinstance(invalid_id_diag, dict) else {}
    if bool(diag.get("is_valid")):
        return "valid_five_digit"
    family = _to_text(diag.get("pattern_family")).lower()
    reason = _to_text(diag.get("reason")).lower()
    source_contract = external_patient_id_source_contract(diag.get("source"))
    embedded_coerced = bool(diag.get("embedded_coerced"))
    decimal_coerced = bool(diag.get("decimal_coerced"))

    if not family or family in ("empty", "missing", "whitespace"):
        return "missing_or_blank"
    if decimal_coerced:
        return "lossless_decimal_normalized"
    if embedded_coerced:
        return "unambiguous_embedded_5_digit_normalized"
    if family in ("embedded_text", "non_digit", "non_numeric", "embedded_5_digit"):
        if source_contract == "medibot_csv_patient_id_field":
            return "csv_patient_id_field_contains_display_text_or_wrong_column"
        if source_contract == "medilink_dat_patient_id_field":
            return "dat_patient_id_field_contains_display_text_or_wrong_column"
        return "patient_id_field_contains_display_text_or_wrong_column"
    if family in ("too_short", "too_long", "wrong_length") or reason == "wrong_length":
        return "numeric_wrong_length"
    if family in ("decimal_like", "punctuated"):
        return "decimal_or_punctuated_not_lossless"
    return "invalid_external_patient_id_other"
