#!/usr/bin/env python
"""
Shared XP-safe JSON writer for unified-model scripts.

This stays local to the XP/unified-model runtime family so scripts can share the
same temp/remove/rename behavior without crossing runtime boundaries.
"""
from __future__ import print_function

import json
import os


def write_json(path, doc):
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        return False
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(doc, handle, sort_keys=True, indent=2)
            handle.write("\n")
        try:
            if os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass
        os.rename(tmp, path)
        return True
    except Exception:
        try:
            if os.path.isfile(tmp):
                os.remove(tmp)
        except Exception:
            pass
    return False
