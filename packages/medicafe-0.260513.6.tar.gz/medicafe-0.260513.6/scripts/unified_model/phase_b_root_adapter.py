#!/usr/bin/env python
"""
Phase B XP local filesystem adapter: resolve_roots() and iter_candidates().
Config/crosswalk parsing lives here; Layer A consumes candidates only.
Hash policy executed here; Layer A consumes sha256/hash_mode from CandidateArtifact.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import json
import os
import platform
import re
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_b_common import (
    CandidateArtifact,
    HASH_MODE_ERROR,
    HASH_MODE_FULL,
    HASH_MODE_SAMPLED,
    HASH_MODE_SKIPPED_LARGE,
    ResolvedRootSpec,
)

try:
    from MediCafe.local_index_utils import file_signature, path_key, stream_sha256
except Exception:
    def path_key(path):
        try:
            return os.path.normcase(os.path.abspath(os.path.normpath(path)))
        except Exception:
            return str(path or "")

    def file_signature(path):
        try:
            st = os.stat(path)
            return (int(st.st_size), float(st.st_mtime))
        except (OSError, IOError, TypeError):
            return None

    def stream_sha256(path, chunk_size=65536):
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

# Hash policy env defaults
DEFAULT_MAX_FULL_HASH_BYTES = 50 * 1024 * 1024  # 50MB
DEFAULT_SAMPLED_CHUNK_BYTES = 65536  # 64KB
DEFAULT_SKIP_LARGE_BYTES = 200 * 1024 * 1024  # 200MB (beyond this: skipped_large)
TRUE_ENV_VALUES = ("1", "true", "yes", "on", "y")
_LAST_DISCOVERY_SCOPE_POLICY = {}
PHASE_B_FINGERPRINT_CACHE_FILENAME = "phase_b_file_fingerprint_cache.json"
_PHASE_B_FINGERPRINT_CACHE_PATH = ""
_PHASE_B_FINGERPRINT_CACHE = {}
_PHASE_B_FINGERPRINT_CACHE_DIRTY = False


def _env_flag(name, default=False):
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in TRUE_ENV_VALUES


def _env_flag_with_source(name, default=False, default_source="default"):
    raw = os.environ.get(name)
    if raw is None or str(raw).strip() == "":
        return bool(default), str(default_source or "default")
    return str(raw).strip().lower() in TRUE_ENV_VALUES, "env_override"


def _env_int(name, default):
    try:
        raw = os.environ.get(name, str(default))
        return int(raw)
    except Exception:
        return int(default)


def _read_lab_json(lab_root, name):
    path = os.path.join(lab_root, name)
    try:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def _class_list_contains(raw, class_name):
    if not isinstance(raw, (list, tuple)):
        return False
    wanted = str(class_name or "").strip().lower()
    for item in raw:
        if str(item).strip().lower() == wanted:
            return True
    return False


def _dict_class_list_contains(payload, class_name):
    if not isinstance(payload, dict):
        return False
    if _class_list_contains(payload.get("artifact_classes"), class_name):
        return True
    effective = payload.get("effective_policy")
    if isinstance(effective, dict) and _class_list_contains(effective.get("artifact_classes"), class_name):
        return True
    return False


def _phase_b_xml_default_from_config(config, crosswalk):
    cfg = config if isinstance(config, dict) else {}
    medi = _get_medi_config(cfg)
    for payload in (medi, cfg, crosswalk if isinstance(crosswalk, dict) else {}):
        if _dict_class_list_contains(payload, "xml"):
            return True
    return False


def _phase_b_xml_default_from_state(state, cursor):
    for payload in (state, cursor):
        if not isinstance(payload, dict):
            continue
        remediation = payload.get("phase_d_remediation")
        if _dict_class_list_contains(remediation, "xml"):
            return True
        if _dict_class_list_contains(payload.get("artifact_scope_policy"), "xml"):
            return True
        for key in (
                "last_phase_d_artifact_class_filter",
                "phase_d_artifact_class_filter",
                "artifact_class_filter",
                "historical_reprocess_targeted_artifact_classes"):
            if _class_list_contains(payload.get(key), "xml"):
                return True
        counts = payload.get("last_discovery_counts_by_class")
        if isinstance(counts, dict):
            try:
                if int(counts.get("xml", 0) or 0) > 0:
                    return True
            except Exception:
                pass
    return False


def resolve_phase_b_discovery_scope_policy(lab_root, config=None, crosswalk=None):
    cfg = config if isinstance(config, dict) else {}
    state = _read_lab_json(lab_root, "diagnostics_state.json")
    cursor = _read_lab_json(lab_root, "run_cursor.json")
    include_staging_default = False
    source_folder = os.environ.get("source_folder", "").strip()
    target_folder = os.environ.get("target_folder", "").strip()
    if source_folder and target_folder and os.path.normcase(source_folder) != os.path.normcase(target_folder):
        include_staging_default = True
    include_xml_default = False
    include_xml_source = "default"
    if _phase_b_xml_default_from_config(cfg, crosswalk):
        include_xml_default = True
        include_xml_source = "config"
    elif _phase_b_xml_default_from_state(state, cursor):
        include_xml_default = True
        include_xml_source = "state_evidence"
    include_historical_default = True
    blocker = str(state.get("layer1_current_blocker") or cursor.get("layer1_current_blocker") or "").strip()
    if blocker == "dat_zero_selected":
        include_historical_default = True
    include_staging, staging_source = _env_flag_with_source("MEDICAFE_PHASE_B_INCLUDE_STAGING_SOURCE", include_staging_default)
    include_xml, xml_source = _env_flag_with_source("MEDICAFE_PHASE_B_INCLUDE_XML", include_xml_default, include_xml_source)
    include_historical, hist_source = _env_flag_with_source("MEDICAFE_PHASE_B_DAT_INCLUDE_HISTORICAL", include_historical_default)
    follow_symlinks, symlink_source = _env_flag_with_source("MEDICAFE_PHASE_B_FOLLOW_SYMLINKS", False)
    policy = {
        "schema_version": 1,
        "include_staging_source": bool(include_staging),
        "include_xml": bool(include_xml),
        "include_historical_dat": bool(include_historical),
        "follow_symlinks": bool(follow_symlinks),
        "hash_policy": {
            "max_full_hash_bytes": _env_int("MEDICAFE_PHASE_B_MAX_FULL_HASH_BYTES", DEFAULT_MAX_FULL_HASH_BYTES),
            "sampled_hash_chunk_bytes": _env_int("MEDICAFE_PHASE_B_SAMPLED_HASH_CHUNK_BYTES", DEFAULT_SAMPLED_CHUNK_BYTES),
            "skip_large_bytes": _env_int("MEDICAFE_PHASE_B_SKIP_LARGE_BYTES", DEFAULT_SKIP_LARGE_BYTES),
        },
        "effective_policy": {
            "include_staging_source": bool(include_staging),
            "include_xml": bool(include_xml),
            "include_historical_dat": bool(include_historical),
            "follow_symlinks": bool(follow_symlinks),
        },
        "policy_source_map": {
            "include_staging_source": staging_source,
            "include_xml": xml_source,
            "include_historical_dat": hist_source,
            "follow_symlinks": symlink_source,
        },
        "policy_reason": "phase_b_discovery_scope_resolved",
        "flag_disposition": {
            "MEDICAFE_PHASE_B_INCLUDE_XML": "deprecated_operator_knob_support_test_override_only",
        },
    }
    return policy


def get_last_discovery_scope_policy():
    return dict(_LAST_DISCOVERY_SCOPE_POLICY)


def _workspace_root_from_lab(lab_root):
    """Workspace root: parent of lab/ when lab_root ends with lab."""
    lab_root = os.path.abspath(lab_root)
    parent = os.path.dirname(lab_root)
    if os.path.basename(lab_root).lower() == "lab":
        return parent
    return parent


def _load_config_crosswalk(workspace_root):
    """Load config and crosswalk JSON. Returns (config, crosswalk). Uses defaults if missing."""
    config_path = os.path.join(workspace_root, "json", "config.json")
    crosswalk_path = os.path.join(workspace_root, "json", "crosswalk.json")
    env_config = os.environ.get("MEDICAFE_CONFIG_FILE", "").strip()
    if env_config:
        config_path = os.path.abspath(env_config)
        env_crosswalk = os.environ.get("MEDICAFE_CROSSWALK_FILE", "").strip()
        crosswalk_path = (
            os.path.abspath(env_crosswalk)
            if env_crosswalk
            else os.path.join(os.path.dirname(config_path), "crosswalk.json")
        )
    elif not os.path.exists(config_path):
        if platform.system() == "Windows" and platform.release() == "XP":
            config_path = "F:\\Medibot\\json\\config.json"
            crosswalk_path = "F:\\Medibot\\json\\crosswalk.json"
        elif platform.system() == "Windows":
            config_path = os.path.join(os.getcwd(), "json", "config.json")
            crosswalk_path = os.path.join(os.getcwd(), "json", "crosswalk.json")
    config = _read_json_object(config_path)
    crosswalk = _read_json_object(crosswalk_path)
    config_local = _read_json_object(os.path.join(os.path.dirname(config_path), "config.local.json"))
    crosswalk_state = _read_json_object(os.path.join(os.path.dirname(crosswalk_path), "crosswalk.state.json"))
    if config_local:
        config = _deep_merge_config(config, config_local)
    if crosswalk_state:
        crosswalk = _deep_merge_config(crosswalk, crosswalk_state)
    return config, crosswalk


def _read_json_object(path):
    if not path:
        return {}
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                payload = json.load(f)
            if isinstance(payload, dict):
                return payload
    except Exception:
        pass
    return {}


def _is_tombstone(value):
    return isinstance(value, dict) and value.get("__tombstone__") is True


def _deep_merge_config(base, overlay):
    if not isinstance(base, dict):
        base = {}
    if not isinstance(overlay, dict):
        return dict(base)
    merged = dict(base)
    for key, value in overlay.items():
        if key == "__sidecar__":
            continue
        if _is_tombstone(value):
            if key in merged:
                del merged[key]
            continue
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge_config(merged.get(key), value)
        else:
            merged[key] = value
    return merged


def _get_medi_config(config):
    """Extract MediLink_Config dict."""
    return config.get("MediLink_Config", config) if isinstance(config, dict) else {}


def _compute_config_fingerprint(config):
    """
    Hash of root-relevant values for audit. Uses same source logic as resolve_roots:
    - CSV_FILE_PATH, inputFilePath, outputFilePath: effective config
    - medisoft_claims_directory: medi or config
    - local_storage_path, local_claims_path, Z_DAT_PATH: medi
    """
    if not isinstance(config, dict):
        return ""
    medi = _get_medi_config(config)
    stable = {}
    # input/output path may be top-level or MediLink_Config (legacy variants)
    csv_val = medi.get("CSV_FILE_PATH") or config.get("CSV_FILE_PATH")
    input_val = medi.get("inputFilePath") or config.get("inputFilePath")
    output_val = medi.get("outputFilePath") or config.get("outputFilePath")
    if csv_val is not None:
        stable["CSV_FILE_PATH"] = csv_val
    if input_val is not None:
        stable["inputFilePath"] = input_val
    if output_val is not None:
        stable["outputFilePath"] = output_val
    # medi-or-config (resolver: medi.get or config.get)
    val = medi.get("medisoft_claims_directory") or config.get("medisoft_claims_directory")
    if val is not None:
        stable["medisoft_claims_directory"] = val
    # medi-only keys
    for k in ("local_storage_path", "local_claims_path", "Z_DAT_PATH"):
        val = medi.get(k)
        if val is not None:
            stable[k] = val
    stable["_top_keys"] = sorted(config.keys())
    return hashlib.sha256(str(sorted(stable.items())).encode("utf-8")).hexdigest()


def _compute_crosswalk_fingerprint(crosswalk):
    """Hash of key structure for audit."""
    if not isinstance(crosswalk, dict):
        return ""
    stable = {"_keys": sorted(crosswalk.keys())}
    return hashlib.sha256(str(sorted(stable.items())).encode("utf-8")).hexdigest()


def _fingerprint_cache_path(lab_root):
    return os.path.join(os.path.abspath(lab_root), PHASE_B_FINGERPRINT_CACHE_FILENAME)


def _load_phase_b_fingerprint_cache(lab_root):
    global _PHASE_B_FINGERPRINT_CACHE_PATH
    global _PHASE_B_FINGERPRINT_CACHE
    global _PHASE_B_FINGERPRINT_CACHE_DIRTY
    _PHASE_B_FINGERPRINT_CACHE_PATH = _fingerprint_cache_path(lab_root)
    _PHASE_B_FINGERPRINT_CACHE = {}
    _PHASE_B_FINGERPRINT_CACHE_DIRTY = False
    try:
        if os.path.isfile(_PHASE_B_FINGERPRINT_CACHE_PATH):
            with open(_PHASE_B_FINGERPRINT_CACHE_PATH, "r", encoding="utf-8") as f:
                payload = json.load(f)
            entries = payload.get("entries") if isinstance(payload, dict) else None
            if isinstance(entries, dict):
                _PHASE_B_FINGERPRINT_CACHE = entries
    except Exception:
        _PHASE_B_FINGERPRINT_CACHE = {}


def flush_phase_b_fingerprint_cache():
    global _PHASE_B_FINGERPRINT_CACHE_DIRTY
    if not _PHASE_B_FINGERPRINT_CACHE_PATH or not _PHASE_B_FINGERPRINT_CACHE_DIRTY:
        return
    payload = {
        "schema_version": 1,
        "entries": _PHASE_B_FINGERPRINT_CACHE if isinstance(_PHASE_B_FINGERPRINT_CACHE, dict) else {},
    }
    tmp_path = _PHASE_B_FINGERPRINT_CACHE_PATH + ".tmp"
    try:
        parent = os.path.dirname(_PHASE_B_FINGERPRINT_CACHE_PATH)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, sort_keys=True)
        try:
            if os.path.exists(_PHASE_B_FINGERPRINT_CACHE_PATH):
                os.remove(_PHASE_B_FINGERPRINT_CACHE_PATH)
        except Exception:
            pass
        os.rename(tmp_path, _PHASE_B_FINGERPRINT_CACHE_PATH)
        _PHASE_B_FINGERPRINT_CACHE_DIRTY = False
    except Exception:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass


def _hash_policy_key(max_full, chunk_size, skip_large):
    return "{0}|{1}|{2}".format(int(max_full), int(chunk_size), int(skip_large))


def _signature_record(signature):
    try:
        return [int(signature[0]), float(signature[1])]
    except Exception:
        return None


def _cache_lookup(path, signature, policy_key):
    if not _PHASE_B_FINGERPRINT_CACHE_PATH:
        return None
    if signature is None:
        return None
    sig_record = _signature_record(signature)
    if sig_record is None:
        return None
    try:
        entry = _PHASE_B_FINGERPRINT_CACHE.get(path_key(path))
    except Exception:
        return None
    if not isinstance(entry, dict):
        return None
    if entry.get("signature") != sig_record:
        return None
    if entry.get("policy_key") != policy_key:
        return None
    mode = entry.get("hash_mode")
    if mode not in (HASH_MODE_FULL, HASH_MODE_SAMPLED, HASH_MODE_SKIPPED_LARGE):
        return None
    return (entry.get("sha256") or "", mode, [])


def _cache_store(path, signature, policy_key, sha256_hex, hash_mode):
    global _PHASE_B_FINGERPRINT_CACHE_DIRTY
    if not _PHASE_B_FINGERPRINT_CACHE_PATH or signature is None:
        return
    sig_record = _signature_record(signature)
    if sig_record is None:
        return
    if hash_mode not in (HASH_MODE_FULL, HASH_MODE_SAMPLED, HASH_MODE_SKIPPED_LARGE):
        return
    try:
        _PHASE_B_FINGERPRINT_CACHE[path_key(path)] = {
            "signature": sig_record,
            "policy_key": policy_key,
            "sha256": sha256_hex or "",
            "hash_mode": hash_mode,
        }
        _PHASE_B_FINGERPRINT_CACHE_DIRTY = True
    except Exception:
        pass


def _resolve_path(raw, workspace_root, default=""):
    """Resolve path; if relative, join with workspace_root."""
    if not raw or not isinstance(raw, str):
        return default
    raw = raw.strip()
    if not raw:
        return default
    if os.path.isabs(raw):
        return os.path.normpath(raw)
    return os.path.normpath(os.path.join(workspace_root, raw))


def _classify_file(rel_path):
    """
    First-match wins classification. rel_path is relative to root.
    Returns artifact_class string, or None if file type is out-of-scope for discovery.
    """
    rel_lower = rel_path.lower().replace("\\", "/")
    name = os.path.basename(rel_path)
    name_lower = name.lower()
    _, ext = os.path.splitext(name_lower)
    # Ordered rules per plan 2.4
    if name_lower.endswith(".837"):
        return "837"
    if ext in (".txt", ".x12", ".edi") and _contains_837_token(name_lower):
        return "837"
    if "remittance" in rel_lower and rel_lower.endswith(".jsonl"):
        return "jsonl"
    if "posting" in rel_lower and rel_lower.endswith(".jsonl"):
        return "jsonl"
    if "submission" in rel_lower and "index" in rel_lower and rel_lower.endswith(".jsonl"):
        return "receipt"
    if name_lower in ("z.dat", "zm.dat") or name_lower.endswith(".dat"):
        return "dat"
    if name_lower.endswith(".docx"):
        return "docx"
    if name_lower.endswith(".csv"):
        return "csv"
    if name_lower.endswith(".xml"):
        return "xml"
    return None


def _contains_837_token(name_lower):
    """
    Return True when filename contains an 837 token not embedded within digits.
    Prevents false positives like timestamp suffixes (for example, ...112837.txt).
    """
    for match in re.finditer("837", name_lower):
        start = match.start()
        end = match.end()
        prev_ch = name_lower[start - 1] if start > 0 else ""
        next_ch = name_lower[end] if end < len(name_lower) else ""
        prev_ok = (not prev_ch) or (not prev_ch.isdigit())
        next_ok = (not next_ch) or (not next_ch.isdigit())
        if prev_ok and next_ok:
            return True
    return False


def _compute_hash(path, size_bytes):
    """
    Hash policy: full/sampled/skipped_large/error.
    Returns (sha256_hex, hash_mode, warnings_list).
    """
    max_full = int(
        os.environ.get("MEDICAFE_PHASE_B_MAX_FULL_HASH_BYTES", str(DEFAULT_MAX_FULL_HASH_BYTES))
    )
    chunk_size = int(
        os.environ.get(
            "MEDICAFE_PHASE_B_SAMPLED_HASH_CHUNK_BYTES", str(DEFAULT_SAMPLED_CHUNK_BYTES)
        )
    )
    skip_large = int(
        os.environ.get(
            "MEDICAFE_PHASE_B_SKIP_LARGE_BYTES", str(DEFAULT_SKIP_LARGE_BYTES)
        )
    )
    signature = file_signature(path)
    policy_key = _hash_policy_key(max_full, chunk_size, skip_large)
    cached = _cache_lookup(path, signature, policy_key)
    if cached is not None:
        return cached
    if size_bytes > skip_large:
        result = ("", HASH_MODE_SKIPPED_LARGE, [])
        _cache_store(path, signature, policy_key, result[0], result[1])
        return result
    try:
        if size_bytes <= max_full:
            result = (stream_sha256(path), HASH_MODE_FULL, [])
            _cache_store(path, signature, policy_key, result[0], result[1])
            return result
        # Sampled
        offsets = [
            0,
            max(0, size_bytes // 4 - chunk_size // 2),
            max(0, size_bytes // 2 - chunk_size // 2),
            max(0, (3 * size_bytes) // 4 - chunk_size // 2),
            max(0, size_bytes - chunk_size),
        ]
        chunks = []
        with open(path, "rb") as f:
            for off in offsets:
                off = min(off, max(0, size_bytes - chunk_size))
                f.seek(off)
                chunks.append(f.read(chunk_size))
        h = hashlib.sha256(b"".join(chunks))
        result = (h.hexdigest(), HASH_MODE_SAMPLED, [])
        _cache_store(path, signature, policy_key, result[0], result[1])
        return result
    except Exception as e:
        return ("", HASH_MODE_ERROR, [str(e)])



def _resolve_dat_candidate_root(raw_path, workspace_root):
    """Resolve a DAT candidate root without silently discarding invalid config values."""
    raw_path = _resolve_path(raw_path, workspace_root, "")
    if not raw_path:
        return ""
    if os.path.isdir(raw_path):
        return os.path.normpath(raw_path)
    if os.path.isfile(raw_path):
        parent = os.path.dirname(raw_path)
        return os.path.normpath(parent) if parent else os.path.normpath(raw_path)
    return os.path.normpath(raw_path)


def _resolve_file_parent(raw_path, workspace_root):
    """Resolve a configured file path to its containing directory."""
    path = _resolve_path(raw_path, workspace_root, "")
    if not path:
        return ""
    if os.path.isdir(path):
        return os.path.normpath(path)
    parent = os.path.dirname(path)
    return os.path.normpath(parent) if parent else os.path.normpath(path)


def _append_unique_root(roots, seen_roots, source_id, root_path, artifact_classes, scope):
    if not root_path:
        return
    abs_root = os.path.abspath(root_path)
    dedupe_key = os.path.normcase(abs_root)
    if dedupe_key in seen_roots:
        return
    seen_roots.add(dedupe_key)
    roots.append(
        ResolvedRootSpec(
            source_id=source_id,
            root_path=abs_root,
            artifact_classes=artifact_classes,
            scope=scope,
        )
    )


def resolve_roots(lab_root):
    """
    Resolve discovery roots from config + crosswalk + runtime env.
    Returns list of ResolvedRootSpec. Never generic workspace fallback.
    """
    _load_phase_b_fingerprint_cache(lab_root)
    workspace_root = _workspace_root_from_lab(lab_root)
    config, crosswalk = _load_config_crosswalk(workspace_root)
    medi = _get_medi_config(config)
    # Contract allowlist keys (from config)
    local_storage = _resolve_path(
        medi.get("local_storage_path"), workspace_root, ""
    )
    local_claims = _resolve_path(
        medi.get("local_claims_path"), workspace_root, ""
    )
    z_dat = _resolve_path(medi.get("Z_DAT_PATH"), workspace_root, "")
    csv_file_path = _resolve_path(medi.get("CSV_FILE_PATH") or config.get("CSV_FILE_PATH"), workspace_root, "")
    input_fp = _resolve_path(medi.get("inputFilePath") or config.get("inputFilePath"), workspace_root, "")
    output_fp = _resolve_path(medi.get("outputFilePath") or config.get("outputFilePath"), workspace_root, "")
    medisoft_claims = _resolve_path(
        medi.get("medisoft_claims_directory") or config.get("medisoft_claims_directory"),
        workspace_root,
        "",
    )
    # Adapter runtime roots (env); resolve relative to workspace if needed
    target_folder = os.environ.get("target_folder", "").strip() or output_fp
    source_folder = os.environ.get("source_folder", "").strip()
    if target_folder and not os.path.isabs(target_folder):
        target_folder = os.path.normpath(os.path.join(workspace_root, target_folder))
    if source_folder and not os.path.isabs(source_folder):
        source_folder = os.path.normpath(os.path.join(workspace_root, source_folder))
    global _LAST_DISCOVERY_SCOPE_POLICY
    discovery_scope_policy = resolve_phase_b_discovery_scope_policy(lab_root, config, crosswalk)
    _LAST_DISCOVERY_SCOPE_POLICY = discovery_scope_policy
    include_staging = bool(discovery_scope_policy.get("include_staging_source"))
    include_xml = bool(discovery_scope_policy.get("include_xml"))

    roots = []
    # csv: active MediBot CSV directory first; target_folder and storage CSV as fallbacks.
    seen_csv_roots = set()
    csv_configured_root = _resolve_file_parent(csv_file_path, workspace_root)
    _append_unique_root(
        roots,
        seen_csv_roots,
        "csv_configured",
        csv_configured_root,
        ["csv"],
        "operational",
    )
    csv_root = target_folder if target_folder else (local_storage and os.path.join(local_storage, "CSV"))
    if not csv_root and local_storage:
        csv_root = os.path.join(local_storage, "CSV")
    _append_unique_root(
        roots,
        seen_csv_roots,
        "csv_target",
        csv_root,
        ["csv"],
        "operational",
    )
    if include_staging and source_folder:
        _append_unique_root(
            roots,
            seen_csv_roots,
            "csv_staging",
            source_folder,
            ["csv"],
            "staging",
        )
    # docx: keep both runtime and local-storage roots visible on dev runs.
    docx_candidates = []
    if include_staging and source_folder:
        docx_candidates.append(("docx_staging", source_folder, "staging"))
    if target_folder:
        docx_candidates.append(("docx_target", target_folder, "operational"))
    if local_storage:
        docx_candidates.append(("docx_local_storage", local_storage, "operational"))
    seen_docx_roots = set()
    for source_id, docx_root, docx_scope in docx_candidates:
        if not docx_root:
            continue
        abs_docx_root = os.path.abspath(docx_root)
        dedupe_key = os.path.normcase(abs_docx_root)
        if dedupe_key in seen_docx_roots:
            continue
        seen_docx_roots.add(dedupe_key)
        roots.append(
            ResolvedRootSpec(
                source_id=source_id,
                root_path=abs_docx_root,
                artifact_classes=["docx"],
                scope=docx_scope,
            )
        )
    # dat: configured candidates + historical archive roots; fallback local_claims only when no candidates exist.
    dat_candidate_roots = []
    if z_dat:
        dat_candidate_roots.append(("dat_cfg_0", _resolve_dat_candidate_root(z_dat, workspace_root)))
    if input_fp:
        dat_candidate_roots.append(("dat_cfg_1", _resolve_dat_candidate_root(input_fp, workspace_root)))

    include_historical_dat = bool(discovery_scope_policy.get("include_historical_dat"))
    dat_historical_roots = []
    if include_historical_dat:
        if medisoft_claims:
            dat_historical_roots.append(("dat_hist_0", _resolve_dat_candidate_root(medisoft_claims, workspace_root)))

    dat_all_roots = []
    seen_dat_roots = set()
    for source_id, root_path in dat_candidate_roots + dat_historical_roots:
        if not root_path:
            continue
        abs_root = os.path.abspath(root_path)
        dedupe_key = os.path.normcase(abs_root)
        if dedupe_key in seen_dat_roots:
            continue
        seen_dat_roots.add(dedupe_key)
        dat_all_roots.append((source_id, abs_root))

    dat_existing_count = 0
    for source_id, root_path in dat_all_roots:
        if os.path.exists(root_path):
            dat_existing_count += 1
        roots.append(
            ResolvedRootSpec(
                source_id=source_id,
                root_path=root_path,
                artifact_classes=["dat"],
                scope="operational",
            )
        )
    if dat_all_roots and dat_existing_count == 0 and local_claims:
        roots.append(
            ResolvedRootSpec(
                source_id="dat_fallback",
                root_path=os.path.abspath(local_claims),
                artifact_classes=["dat"],
                scope="operational",
            )
        )
    # jsonl, receipt: local_storage; fallback local_claims
    jsonl_root = local_storage or local_claims
    if jsonl_root:
        roots.append(
            ResolvedRootSpec(
                source_id="jsonl",
                root_path=os.path.abspath(jsonl_root),
                artifact_classes=["jsonl", "receipt"],
                scope="operational",
            )
        )
    # 837: medisoft_claims_directory, outputFilePath; fallback local_claims
    e837_roots = []
    if medisoft_claims:
        e837_roots.append(medisoft_claims)
    if output_fp and os.path.isdir(output_fp):
        e837_roots.append(output_fp)
    elif output_fp:
        e837_roots.append(os.path.dirname(output_fp))
    if not e837_roots and local_claims:
        e837_roots.append(local_claims)
    for i, r in enumerate(e837_roots):
        if r and os.path.exists(r):
            classes = ["837", "receipt"]
            if include_xml:
                classes.append("xml")
            roots.append(
                ResolvedRootSpec(
                    source_id="837_{0}".format(i),
                    root_path=os.path.abspath(r),
                    artifact_classes=classes,
                    scope="operational",
                )
            )
            break
    # receipt: local_storage (if not already covered)
    if local_storage and not any(rs.source_id == "jsonl" for rs in roots):
        roots.append(
            ResolvedRootSpec(
                source_id="receipt",
                root_path=os.path.abspath(local_storage),
                artifact_classes=["receipt"],
                scope="operational",
            )
        )
    config_hash = _compute_config_fingerprint(config)
    crosswalk_hash = _compute_crosswalk_fingerprint(crosswalk)
    return roots, config_hash, crosswalk_hash


def iter_candidates(root_spec):
    """
    Yield CandidateArtifact for each file under root_spec.
    Adapter performs os.walk, stat, hash. Layer A consumes only.
    Walks each root once; classifies per file using artifact_classes as hint.
    """
    root_path = root_spec.root_path
    if not os.path.isdir(root_path):
        return
    follow_symlinks = bool(_LAST_DISCOVERY_SCOPE_POLICY.get("follow_symlinks")) if _LAST_DISCOVERY_SCOPE_POLICY else _env_flag("MEDICAFE_PHASE_B_FOLLOW_SYMLINKS", False)
    for dirpath, _dirnames, filenames in os.walk(root_path, followlinks=follow_symlinks):
        for fn in filenames:
                full_path = os.path.join(dirpath, fn)
                if not os.path.isfile(full_path):
                    continue
                try:
                    st = os.stat(full_path)
                except (OSError, IOError):
                    continue
                size_bytes = st.st_size
                mtime_epoch = int(st.st_mtime)
                rel = os.path.relpath(full_path, root_path)
                rel_norm = rel.replace("\\", "/")
                if sys.platform == "win32":
                    rel_norm = rel_norm.lower()
                artifact_class = _classify_file(rel_norm)
                if artifact_class is None:
                    continue
                if artifact_class not in root_spec.artifact_classes:
                    continue
                sha256_hex, hash_mode, warnings = _compute_hash(full_path, size_bytes)
                canonical_key = os.path.normcase(os.path.abspath(full_path))
                yield CandidateArtifact(
                    source_id=root_spec.source_id,
                    canonical_key=canonical_key,
                    normalized_path=rel_norm,
                    size_bytes=size_bytes,
                    mtime_epoch=mtime_epoch,
                    sha256=sha256_hex,
                    hash_mode=hash_mode,
                    artifact_class=artifact_class,
                    scope=root_spec.scope,
                    warnings=warnings,
                    locator=full_path,
                )
