#!/usr/bin/env python
"""
Shared DAT source-shape telemetry helpers.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import os
import time

try:
    from dat_contract import resolve_dat_fields
except Exception:
    resolve_dat_fields = None


def _to_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def _merge_counter(base, key, inc=1):
    if not isinstance(base, dict):
        return
    key = str(key or "").strip() or "unknown"
    base[key] = int(base.get(key, 0) or 0) + int(inc or 0)


def dat_locator_basename(locator):
    """
    Basename for DAT locators that may be recorded with Windows separators.

    On POSIX, os.path.basename does not treat backslashes as path separators, so
    locators like F:\\Lab\\ZM_20260420_184100.DAT would otherwise yield the full
    string and corrupt prefix / filename telemetry.
    """
    text = str(locator or "").strip()
    if not text:
        return ""
    if os.name != "nt" and "\\" in text:
        text = text.replace("\\", "/")
    return os.path.basename(text)


def dat_file_prefix_from_locator(locator):
    name = dat_locator_basename(locator)
    if not name:
        return "unknown"
    stem = name.split(".")[0]
    prefix = stem.split("_")[0].strip().upper()
    return prefix or "unknown"


def dat_filename_timestamp_guess(locator):
    name = dat_locator_basename(locator)
    stem = name.split(".")[0]
    parts = stem.split("_")
    if len(parts) < 3:
        return ""
    date_part = parts[1]
    time_part = parts[2]
    if len(date_part) != 8 or len(time_part) != 6:
        return ""
    if not (date_part.isdigit() and time_part.isdigit()):
        return ""
    return "{0}-{1}-{2}T{3}:{4}:{5}".format(
        date_part[0:4],
        date_part[4:6],
        date_part[6:8],
        time_part[0:2],
        time_part[2:4],
        time_part[4:6],
    )


def dat_file_mtime_utc(locator):
    path = str(locator or "").strip()
    if not path:
        return ""
    try:
        if not os.path.isfile(path):
            return ""
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(os.path.getmtime(path)))
    except Exception:
        return ""


def dat_record_count_bucket(record_count):
    n = _to_int(record_count, 0)
    if n <= 0:
        return "zero"
    if n <= 10:
        return "1_10"
    if n <= 50:
        return "11_50"
    if n <= 100:
        return "51_100"
    return "over_100"


def dat_size_bucket(size_bytes):
    n = _to_int(size_bytes, 0)
    if n <= 0:
        return "zero"
    if n <= 1000:
        return "1_1k"
    if n <= 5000:
        return "1k_5k"
    if n <= 20000:
        return "5k_20k"
    return "over_20k"


def _median(values):
    clean = sorted(_to_int(value, 0) for value in values if _to_int(value, 0) > 0)
    count = len(clean)
    if count <= 0:
        return None
    mid = count // 2
    if count % 2:
        return clean[mid]
    return (clean[mid - 1] + clean[mid]) / 2.0


def _kb_value(size_bytes):
    if size_bytes is None:
        return None
    try:
        return round(float(size_bytes) / 1024.0, 1)
    except Exception:
        return None


def _nonzero_size_stats(nonzero_sizes):
    sizes = sorted(_to_int(value, 0) for value in nonzero_sizes if _to_int(value, 0) > 0)
    if not sizes:
        return {
            "nonzero_file_count": 0,
            "excluded_zero_byte_count": 0,
            "min_size_bytes": None,
            "median_size_bytes": None,
            "median_size_kb": None,
            "max_size_bytes": None,
        }
    med = _median(sizes)
    return {
        "nonzero_file_count": len(sizes),
        "excluded_zero_byte_count": 0,
        "min_size_bytes": sizes[0],
        "median_size_bytes": med,
        "median_size_kb": _kb_value(med),
        "max_size_bytes": sizes[-1],
    }


def _year_month(text):
    value = str(text or "").strip()
    if len(value) >= 7 and value[4:5] == "-":
        return value[:7]
    return ""


def empty_dat_file_shape_diagnostics():
    return {
        "parsed_file_count": 0,
        "prefix_counts": {},
        "record_count_bucket_counts": {},
        "abnormal_file_count": 0,
        "abnormal_reason_counts": {},
        "samples": [],
    }


def _anchor_counts_from_envelope(envelope):
    counters = {
        "patient_anchor_present_count": 0,
        "chart_present_count": 0,
    }
    records = envelope.get("records") if isinstance(envelope, dict) else None
    if not isinstance(records, list):
        return counters
    for rec in records:
        if not isinstance(rec, dict):
            continue
        if resolve_dat_fields is not None:
            resolved = resolve_dat_fields(rec)
            patient_id = str(resolved.get("patient_id") or "").strip()
            chart = str(resolved.get("chart_number") or "").strip()
        else:
            patient_id = str(rec.get("patient_id") or rec.get("PATID") or rec.get("patid") or "").strip()
            chart = str(rec.get("chart_number") or rec.get("CHART") or rec.get("patient_chart") or "").strip()
        if patient_id:
            counters["patient_anchor_present_count"] += 1
        if chart:
            counters["chart_present_count"] += 1
    return counters


def append_dat_file_shape_diagnostics(diag, envelope, locator):
    if not isinstance(diag, dict) or not isinstance(envelope, dict):
        return diag
    records = envelope.get("records")
    if not isinstance(records, list) or len(records) <= 0:
        return diag
    prefix = dat_file_prefix_from_locator(locator)
    record_count = len(records)
    file_size = _to_int(envelope.get("file_size_bytes"), 0)
    diag["parsed_file_count"] = int(diag.get("parsed_file_count", 0) or 0) + 1
    _merge_counter(diag.setdefault("prefix_counts", {}), prefix)
    _merge_counter(diag.setdefault("record_count_bucket_counts", {}), dat_record_count_bucket(record_count))
    reasons = []
    if prefix == "ZM":
        reasons.append("zm_prefix")
    if record_count > 50:
        reasons.append("high_record_count_gt_50")
    anchors = _anchor_counts_from_envelope(envelope)
    if int(anchors.get("patient_anchor_present_count", 0) or 0) == 0:
        reasons.append("no_patid_records")
    if reasons:
        diag["abnormal_file_count"] = int(diag.get("abnormal_file_count", 0) or 0) + 1
        for reason in reasons:
            _merge_counter(diag.setdefault("abnormal_reason_counts", {}), reason)
        samples = diag.setdefault("samples", [])
        if isinstance(samples, list) and len(samples) < 12:
            samples.append({
                "artifact_name": dat_locator_basename(locator),
                "dat_file_prefix": prefix,
                "record_count": record_count,
                "file_size_bytes": file_size,
                "record_count_bucket": dat_record_count_bucket(record_count),
                "filename_timestamp_guess": dat_filename_timestamp_guess(locator),
                "locator_mtime_utc": dat_file_mtime_utc(locator),
                "abnormal_reasons": list(reasons),
                "patient_anchor_present_count": int(anchors.get("patient_anchor_present_count", 0) or 0),
                "chart_present_count": int(anchors.get("chart_present_count", 0) or 0),
            })
    return diag


def build_dat_manifest_shape_profile(rows):
    profile = {
        "manifest_dat_file_count": 0,
        "source_id_counts": {},
        "prefix_counts": {},
        "size_bucket_counts": {},
        "mtime_year_month_counts": {},
        "filename_year_month_counts": {},
        "zero_byte_count": 0,
        "duplicate_sha_row_count": 0,
        "nonzero_file_size_stats": {
            "nonzero_file_count": 0,
            "excluded_zero_byte_count": 0,
            "min_size_bytes": None,
            "median_size_bytes": None,
            "median_size_kb": None,
            "max_size_bytes": None,
        },
        "normal_looking_metadata_count": 0,
        "outlier_metadata_count": 0,
        "outlier_reason_counts": {},
        "outlier_samples": [],
    }
    sha_counts = {}
    dat_rows = []
    nonzero_sizes = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if str(row.get("artifact_class") or "").strip().lower() != "dat":
            continue
        dat_rows.append(row)
        sha = str(row.get("sha256") or "").strip().lower()
        if sha:
            sha_counts[sha] = int(sha_counts.get(sha, 0) or 0) + 1
    for row in dat_rows:
        locator = row.get("locator") or row.get("normalized_path") or ""
        prefix = dat_file_prefix_from_locator(locator)
        size = _to_int(row.get("size_bytes"), 0)
        sha = str(row.get("sha256") or "").strip().lower()
        profile["manifest_dat_file_count"] += 1
        _merge_counter(profile["source_id_counts"], row.get("source_id") or "unknown")
        _merge_counter(profile["prefix_counts"], prefix)
        _merge_counter(profile["size_bucket_counts"], dat_size_bucket(size))
        if size > 0:
            nonzero_sizes.append(size)
        mtime_month = _year_month(row.get("mtime_utc"))
        if mtime_month:
            _merge_counter(profile["mtime_year_month_counts"], mtime_month)
        filename_month = _year_month(dat_filename_timestamp_guess(locator))
        if filename_month:
            _merge_counter(profile["filename_year_month_counts"], filename_month)
        reasons = []
        if size <= 0:
            profile["zero_byte_count"] += 1
            reasons.append("zero_byte")
        if prefix == "ZM":
            reasons.append("zm_prefix")
        if size > 20000:
            reasons.append("large_size_gt_20k")
        if sha and int(sha_counts.get(sha, 0) or 0) > 1:
            profile["duplicate_sha_row_count"] += 1
            reasons.append("duplicate_sha")
        if prefix == "Z" and size > 0 and size <= 10000 and not reasons:
            profile["normal_looking_metadata_count"] += 1
        if reasons:
            profile["outlier_metadata_count"] += 1
            for reason in reasons:
                _merge_counter(profile["outlier_reason_counts"], reason)
            samples = profile["outlier_samples"]
            if len(samples) < 20:
                samples.append({
                    "artifact_name": dat_locator_basename(locator),
                    "dat_file_prefix": prefix,
                    "size_bytes": size,
                    "size_bucket": dat_size_bucket(size),
                    "mtime_utc": str(row.get("mtime_utc") or ""),
                    "filename_timestamp_guess": dat_filename_timestamp_guess(locator),
                    "source_id": str(row.get("source_id") or ""),
                    "outlier_reasons": list(reasons),
                })
    size_stats = _nonzero_size_stats(nonzero_sizes)
    size_stats["excluded_zero_byte_count"] = int(profile.get("zero_byte_count", 0) or 0)
    profile["nonzero_file_size_stats"] = size_stats
    return profile
