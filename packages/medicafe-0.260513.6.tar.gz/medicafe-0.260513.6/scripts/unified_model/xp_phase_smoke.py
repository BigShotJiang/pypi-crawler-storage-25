#!/usr/bin/env python
"""
On-prem XP phase/interface smoke report.

This is observational by default: it does not run the pipeline.  It verifies the
lab contract surfaces independently so an operator/developer can tell which
phase boundary is missing without waiting for A->F to fail at the last reached
step.
"""
from __future__ import print_function

import argparse
import json
import os
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from xp_json_write import write_json

try:
    from phase_a_common import iso_utc_now
except Exception:
    def iso_utc_now():
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

try:
    from lab_path_utils import resolve_lab_root
except Exception:
    resolve_lab_root = None


SMOKE_SCHEMA_VERSION = 1


def _read_json(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            doc = json.load(handle)
        if isinstance(doc, dict):
            return doc
    except Exception:
        pass
    return {}


def _write_json(path, doc):
    return write_json(path, doc)


def _write_txt(path, result):
    lines = [
        "XP Phase Smoke",
        "schema_version={0}".format(result.get("schema_version", "")),
        "generated_at_utc={0}".format(result.get("generated_at_utc", "")),
        "lab_root={0}".format(result.get("lab_root", "")),
        "overall_status={0}".format(result.get("overall_status", "")),
    ]
    for phase in result.get("phases", []):
        lines.append(
            "{0}: status={1} blocker={2}".format(
                phase.get("phase", ""),
                phase.get("status", ""),
                phase.get("blocker", ""),
            )
        )
    try:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")
    except Exception:
        pass


def _status(ok, blocker="", detail="", extra=None):
    row = {
        "status": "ok" if ok else "blocked",
        "blocker": "" if ok else str(blocker or "blocked"),
        "detail": str(detail or ""),
    }
    if isinstance(extra, dict):
        row.update(extra)
    return row


def _phase_a(lab_root):
    reports = os.path.join(lab_root, "reports")
    if not lab_root:
        return _status(False, "lab_root_missing")
    if not os.path.isdir(lab_root):
        return _status(False, "lab_root_not_found", lab_root)
    if not os.path.isdir(reports):
        return _status(False, "reports_dir_missing", reports)
    return _status(True, extra={"reports_dir": reports})


def _phase_b(lab_root, st, cr):
    manifest = str(st.get("last_manifest_path") or cr.get("last_manifest_path") or "").strip()
    sha = str(st.get("last_manifest_sha256") or cr.get("last_manifest_sha256") or "").strip()
    if not manifest:
        return _status(False, "phase_b_manifest_path_missing")
    if not os.path.isfile(manifest):
        return _status(False, "phase_b_manifest_file_missing", manifest, {"last_manifest_sha256": sha})
    if not sha:
        return _status(False, "phase_b_manifest_sha_missing", manifest)
    return _status(True, extra={"last_manifest_path": manifest, "last_manifest_sha256": sha})


def _phase_c(lab_root, st, cr):
    reports = os.path.join(lab_root, "reports")
    attempt_path = str(
        st.get("last_phase_c_current_attempt_path")
        or cr.get("last_phase_c_current_attempt_path")
        or os.path.join(reports, "phase_c_current_attempt_latest.json")
        or ""
    ).strip()
    attempt = _read_json(attempt_path)
    boot = os.path.isfile(os.path.join(reports, "ingest_from_manifest_bootstrap_latest.json"))
    finish = os.path.isfile(os.path.join(reports, "ingest_from_manifest_diagnostics_latest.json"))
    handoff = str(
        st.get("last_phase_c_execution_handoff_report_path")
        or cr.get("last_phase_c_execution_handoff_report_path")
        or ""
    ).strip()
    extra = {
        "current_attempt_path": attempt_path,
        "current_attempt_present": bool(attempt_path and os.path.isfile(attempt_path)),
        "current_attempt_last_reached_stage": str(attempt.get("last_reached_stage") or ""),
        "current_attempt_blocker": str(attempt.get("current_blocker") or ""),
        "bootstrap_present": bool(boot),
        "finish_diagnostics_present": bool(finish),
        "handoff_report_path": handoff,
        "handoff_report_present": bool(handoff and os.path.isfile(handoff)),
    }
    if attempt:
        blocker = str(attempt.get("current_blocker") or "")
        if blocker == "phase_c_current_attempt_ok":
            return _status(True, extra=extra)
        return _status(False, blocker or "phase_c_current_attempt_blocked", extra=extra)
    if not handoff:
        return _status(False, "phase_c_current_attempt_missing", extra=extra)
    if not os.path.isfile(handoff):
        return _status(False, "phase_c_handoff_report_missing", handoff, extra)
    return _status(False, str(st.get("last_phase_c_execution_handoff_blocker_class") or "phase_c_handoff_failed"), extra=extra)


def _phase_d(lab_root, st, cr):
    rid = str(st.get("last_phase_d_run_id") or cr.get("last_phase_d_run_id") or "").strip()
    if not rid:
        return _status(False, "phase_d_run_id_missing")
    path = os.path.join(lab_root, "reports", "qa_canonical_summary_{0}.json".format(rid))
    if not os.path.isfile(path):
        return _status(False, "phase_d_qa_summary_missing", path)
    return _status(True, extra={"qa_canonical_summary_path": path})


def _phase_e(lab_root, st, cr):
    rid = str(st.get("last_phase_e_run_id") or cr.get("last_phase_e_run_id") or "").strip()
    if not rid:
        return _status(False, "phase_e_run_id_missing")
    path = os.path.join(lab_root, "reports", "projection_parity_summary_{0}.json".format(rid))
    if not os.path.isfile(path):
        return _status(False, "phase_e_projection_summary_missing", path)
    return _status(True, extra={"projection_parity_summary_path": path})


def _interfaces(lab_root, st, cr):
    b_sha = str(st.get("last_manifest_sha256") or cr.get("last_manifest_sha256") or "").strip()
    c_sha = str(st.get("last_ingest_manifest_sha256") or cr.get("last_ingest_manifest_sha256") or "").strip()
    if b_sha and c_sha and b_sha != c_sha:
        return _status(False, "phase_b_c_manifest_sha_mismatch", "B={0} C={1}".format(b_sha, c_sha))
    return _status(True, extra={"phase_b_manifest_sha256": b_sha, "phase_c_ingest_manifest_sha256": c_sha})


def build_smoke_result(lab_root):
    lab_root = str(lab_root or "").strip()
    st = _read_json(os.path.join(lab_root, "diagnostics_state.json"))
    cr = _read_json(os.path.join(lab_root, "run_cursor.json"))
    phase_rows = []
    checks = (
        ("A", _phase_a),
        ("B", lambda lr: _phase_b(lr, st, cr)),
        ("C", lambda lr: _phase_c(lr, st, cr)),
        ("D", lambda lr: _phase_d(lr, st, cr)),
        ("E", lambda lr: _phase_e(lr, st, cr)),
        ("interfaces", lambda lr: _interfaces(lr, st, cr)),
    )
    for name, fn in checks:
        row = fn(lab_root)
        row["phase"] = name
        phase_rows.append(row)
    blocked = [row for row in phase_rows if row.get("status") != "ok"]
    return {
        "schema_version": SMOKE_SCHEMA_VERSION,
        "generated_at_utc": iso_utc_now(),
        "lab_root": lab_root,
        "overall_status": "ok" if not blocked else "blocked",
        "first_blocker": str(blocked[0].get("blocker") or "") if blocked else "",
        "phases": phase_rows,
    }


def resolve_lab_arg(value):
    if value:
        return os.path.abspath(value)
    env_lab = os.environ.get("MEDICAFE_LAB_DIR", "")
    if env_lab:
        return os.path.abspath(env_lab)
    if resolve_lab_root is not None:
        try:
            return os.path.abspath(resolve_lab_root())
        except Exception:
            pass
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", "..", "lab"))


def main(argv=None):
    parser = argparse.ArgumentParser(description="Write XP phase/interface smoke report.")
    parser.add_argument("--lab-dir", default="", help="Lab root. Defaults to MEDICAFE_LAB_DIR or repo lab.")
    args = parser.parse_args(argv)
    lab_root = resolve_lab_arg(args.lab_dir)
    result = build_smoke_result(lab_root)
    reports = os.path.join(lab_root, "reports")
    json_path = os.path.join(reports, "xp_phase_smoke_latest.json")
    txt_path = os.path.join(reports, "xp_phase_smoke_latest.txt")
    _write_json(json_path, result)
    _write_txt(txt_path, result)
    print("xp_phase_smoke_report={0}".format(json_path))
    print("overall_status={0}".format(result.get("overall_status", "")))
    return 0 if result.get("overall_status") == "ok" else 2


if __name__ == "__main__":
    sys.exit(main())
