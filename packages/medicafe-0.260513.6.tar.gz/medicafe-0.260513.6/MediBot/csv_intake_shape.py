# -*- coding: utf-8 -*-
"""XP-safe MediBot intake CSV header shape helpers."""
from __future__ import print_function

import codecs
import csv
import io
import os


CSV_INTAKE_PATIENT_ID_HEADERS = [
    'Patient ID',
    'Patient ID 2',
    'Patient ID #2',
]

CSV_INTAKE_DATE_ALIASES = [
    'Surgery Date',
    'Service Date',
    'Date of Service',
    'DOS',
    'DATE1',
    'surgery_date',
    'service_date',
    'date_of_service',
    'dos',
]

CSV_INTAKE_DEMOGRAPHIC_HEADERS = [
    'Patient Last',
    'Patient First',
]

CSV_ACTION_RECONCILIATION_STRONG_MARKERS = set([
    'claim_key',
    'next_action',
    'claim_number',
])

CSV_ACTION_RECONCILIATION_WEAK_MARKERS = set([
    'category',
    'detail',
    'payer_id',
    'patient_id',
])


def scrub_csv_header_token(header):
    text = str(header or '').strip()
    return ''.join(
        char for char in text
        if char.isalnum() or char.isspace() or char in ['-', '_', '#']
    )


def _canonicalize_header(header):
    cleaned = scrub_csv_header_token(header)
    if cleaned in CSV_INTAKE_DATE_ALIASES:
        return 'Surgery Date'
    return cleaned


def classify_medibot_intake_headers(raw_headers):
    raw_headers = list(raw_headers or [])
    cleaned_headers = [scrub_csv_header_token(h) for h in raw_headers]
    canonical_headers = [_canonicalize_header(h) for h in cleaned_headers]
    cleaned_set = set(cleaned_headers)
    canonical_set = set(canonical_headers)

    has_patient_id = bool(canonical_set.intersection(set(CSV_INTAKE_PATIENT_ID_HEADERS)))
    has_surgery_date = 'Surgery Date' in canonical_set
    has_demographics = bool(canonical_set.intersection(set(CSV_INTAKE_DEMOGRAPHIC_HEADERS)))

    strong_markers = cleaned_set.intersection(CSV_ACTION_RECONCILIATION_STRONG_MARKERS)
    weak_markers = cleaned_set.intersection(CSV_ACTION_RECONCILIATION_WEAK_MARKERS)
    has_action_shape = bool(strong_markers) or len(weak_markers) >= 3

    reason = 'ok'
    if has_action_shape:
        reason = 'action_or_reconciliation_csv'
    elif not has_patient_id:
        reason = 'missing_patient_id_header'
    elif not has_surgery_date:
        reason = 'missing_surgery_date_header'
    elif not has_demographics:
        reason = 'patient_id_without_intake_demographics'

    ok = bool(has_patient_id and has_surgery_date and has_demographics and not has_action_shape)
    return {
        'ok': ok,
        'reason': reason,
        'raw_headers': raw_headers,
        'cleaned_headers': cleaned_headers,
        'canonical_headers': canonical_headers,
        'header_count': len(cleaned_headers),
        'has_patient_id': has_patient_id,
        'has_surgery_date': has_surgery_date,
        'has_demographics': has_demographics,
        'action_markers': sorted(list(strong_markers.union(weak_markers))),
    }


def read_csv_raw_header_row(csv_path):
    """
    First row of the CSV as raw string fields.

    Prefer MediBot_Preprocessor_lib.read_csv_raw_header_row so encoding detection
    matches load_csv_data (chardet). The legacy byte-prefix cascade remains as a
    fallback only when that reader cannot be imported (e.g. minimal test doubles).

    If the aligned reader is available, its errors propagate: falling back after a
    failed decode can misread UTF-16 as Latin-1/UTF-8 and classify a valid intake CSV
    as non-intake, which triggers quarantine in local-storage moves.
    """
    _aligned_read = None
    try:
        from MediBot.MediBot_Preprocessor_lib import read_csv_raw_header_row as _aligned_read
    except Exception:
        _aligned_read = None

    if _aligned_read is not None:
        return _aligned_read(csv_path)

    with open(csv_path, 'rb') as handle:
        blob = handle.read(65536)
    if not blob:
        return []

    encodings = []
    if blob.startswith(codecs.BOM_UTF8):
        encodings.append('utf-8-sig')
    encodings.extend(['utf-8-sig', 'utf-8', 'cp1252', 'latin-1'])

    text = None
    last_error = None
    for encoding in encodings:
        try:
            text = blob.decode(encoding)
            break
        except Exception as exc:
            last_error = exc
    if text is None:
        raise last_error

    reader = csv.reader(io.StringIO(text))
    try:
        return next(reader, [])
    except StopIteration:
        return []


def classify_medibot_intake_csv_file(csv_path):
    try:
        raw_headers = read_csv_raw_header_row(csv_path)
    except Exception as exc:
        return {
            'ok': False,
            'reason': 'csv_header_read_failed',
            'error': str(exc),
            'raw_headers': [],
            'cleaned_headers': [],
            'canonical_headers': [],
            'header_count': 0,
        }
    result = classify_medibot_intake_headers(raw_headers)
    result['file_basename'] = os.path.basename(csv_path or '')
    return result
