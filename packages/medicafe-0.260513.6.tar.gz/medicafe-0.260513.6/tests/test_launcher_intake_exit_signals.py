#!/usr/bin/env python
from __future__ import print_function

import os
import sys
from unittest.mock import MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_orchestrator():
    from MediCafe.launcher import MediCafeOrchestrator, SessionConfig

    args = MagicMock()
    args.skip_csv = False
    args.direct_action = None
    args.debug_mode = False
    args.auto_choice = None
    session = SessionConfig(args)
    return MediCafeOrchestrator(session)


def test_consume_last_command_assistant_signals_intake_no_eligible_rows():
    from MediCafe.action_intent import ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS

    orch = _make_orchestrator()
    orch._last_command_exit_context = {
        "command": "medibot",
        "exit_reason": ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS,
    }
    sig = orch._consume_last_command_assistant_signals("medibot")
    assert sig.get("intake_no_eligible_rows") is True
    assert sig.get("child_exit_reason") == ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS
    assert sig.get("user_exit_requested") is False
    assert orch._last_command_exit_context == {}


def test_consume_last_command_assistant_signals_intake_csv_shape_blocked():
    from MediCafe.action_intent import ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED

    orch = _make_orchestrator()
    orch._last_command_exit_context = {
        "command": "medibot",
        "exit_reason": ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED,
    }
    sig = orch._consume_last_command_assistant_signals("medibot")
    assert sig.get("intake_csv_shape_blocked") is True
    assert sig.get("intake_no_eligible_rows") is None
    assert sig.get("child_exit_reason") == ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED
    assert sig.get("user_exit_requested") is False


def test_consume_last_command_assistant_signals_command_mismatch_returns_empty():
    from MediCafe.action_intent import ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS

    orch = _make_orchestrator()
    orch._last_command_exit_context = {
        "command": "medilink",
        "exit_reason": ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS,
    }
    assert orch._consume_last_command_assistant_signals("medibot") == {}
    # Context cleared even when command mismatches — same as launcher implementation
    assert orch._last_command_exit_context == {}


def test_consume_last_command_assistant_signals_command_case_insensitive():
    from MediCafe.action_intent import ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS

    orch = _make_orchestrator()
    orch._last_command_exit_context = {
        "command": "MediBot",
        "exit_reason": ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS,
    }
    sig = orch._consume_last_command_assistant_signals("medibot")
    assert sig.get("intake_no_eligible_rows") is True


def test_mark_user_exit_intake_reason_round_trip(tmp_path, monkeypatch):
    sentinel = tmp_path / "action_exit.flag"
    monkeypatch.setenv("MEDICAFE_ACTION_EXIT_SENTINEL", str(sentinel))
    from MediCafe.action_intent import (
        ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS,
        mark_user_exit,
        read_exit_reason,
    )

    assert mark_user_exit(ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS) is True
    assert read_exit_reason(str(sentinel)) == ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS


def test_mark_user_exit_intake_shape_reason_round_trip(tmp_path, monkeypatch):
    sentinel = tmp_path / "action_exit.flag"
    monkeypatch.setenv("MEDICAFE_ACTION_EXIT_SENTINEL", str(sentinel))
    from MediCafe.action_intent import (
        ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED,
        mark_user_exit,
        read_exit_reason,
    )

    assert mark_user_exit(ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED) is True
    assert read_exit_reason(str(sentinel)) == ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED
