import pytest

import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from workflow_boundary_contract import WorkflowBoundaryContract


def test_contract_accepts_same_target_terminal_success_before_completion_claim():
    contract = WorkflowBoundaryContract(
        "phase_d_dat_smoke",
        {"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
    )
    contract.add_surface(
        name="recommendation",
        role="intent",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        status="requested",
    )
    contract.add_surface(
        name="diagnostic_attempt",
        role="attempt",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        status="completed",
        accepted=True,
    )
    contract.add_surface(
        name="run_evidence_bundle",
        role="package",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        classification="accepted_for_anchor",
        claims_completion=True,
    )

    contract.assert_clean()


def test_contract_rejects_started_attempt_packaged_as_complete():
    contract = WorkflowBoundaryContract(
        "phase_d_dat_smoke",
        {"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
    )
    contract.add_surface(
        name="recommendation",
        role="intent",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        status="requested",
    )
    contract.add_surface(
        name="diagnostic_attempt_latest",
        role="attempt",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        status="running",
    )
    contract.add_surface(
        name="run_evidence_bundle",
        role="package",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        classification="complete",
        claims_completion=True,
    )

    violations = contract.validate()

    assert "completion_claim_without_same_target_terminal_success:package:run_evidence_bundle" in violations
    assert "open_attempt_not_classified_safely:package:run_evidence_bundle:complete" in violations


def test_contract_accepts_started_attempt_when_downstream_classifies_in_flight():
    contract = WorkflowBoundaryContract(
        "phase_d_dat_smoke",
        {"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
    )
    contract.add_surface(
        name="diagnostic_attempt_latest",
        role="attempt",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        status="running",
    )
    contract.add_surface(
        name="run_evidence_bundle",
        role="package",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        classification="in_flight",
    )

    contract.assert_clean()


def test_contract_rejects_latest_artifact_from_wrong_target_identity():
    contract = WorkflowBoundaryContract(
        "phase_d_dat_smoke",
        {"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
    )
    contract.add_surface(
        name="latest_smoke_report",
        role="artifact",
        identity={"anchor_run_id": "anchor-0", "context_run_id": "phase-d-0"},
        status="completed",
        accepted=True,
    )
    contract.add_surface(
        name="review_preview",
        role="recommendation",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        classification="accepted_for_anchor",
        claims_completion=True,
    )

    violations = contract.validate()

    assert "surface_target_mismatch:artifact:latest_smoke_report" in violations
    assert "accepted_without_same_target_terminal_success:artifact:latest_smoke_report" in violations
    assert "completion_claim_without_same_target_terminal_success:recommendation:review_preview" in violations


def test_contract_accepts_fail_closed_mismatch_when_downstream_marks_ignored():
    contract = WorkflowBoundaryContract(
        "phase_d_dat_smoke",
        {"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
    )
    contract.add_surface(
        name="smoke_attempt",
        role="attempt",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        status="failed",
        fail_closed=True,
    )
    contract.add_surface(
        name="run_evidence_smoke_anchor_mismatch",
        role="package",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        classification="ignored_mismatch",
    )

    contract.assert_clean()


def test_contract_accepts_wrong_target_artifact_only_when_explicitly_ignored():
    contract = WorkflowBoundaryContract(
        "support_bundle_attachment",
        {"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
    )
    contract.add_surface(
        name="diagnostic_attempt_latest",
        role="attachment_candidate",
        identity={"anchor_run_id": "anchor-0", "context_run_id": "phase-d-0"},
        status="completed",
        classification="ignored_mismatch",
        accepted=False,
    )
    contract.add_surface(
        name="run_evidence_bundle",
        role="package",
        identity={"anchor_run_id": "anchor-1", "context_run_id": "phase-d-1"},
        classification="review_required",
    )

    contract.assert_clean()


def test_assert_clean_reports_actionable_violation_names():
    contract = WorkflowBoundaryContract("support_send", {"job_id": "job-1"})
    contract.add_surface(
        name="queue_state",
        role="attempt",
        identity={"job_id": "job-1"},
        status="queued",
    )
    contract.add_surface(
        name="operator_banner",
        role="operator_text",
        identity={"job_id": "job-1"},
        classification="complete",
        claims_completion=True,
    )

    with pytest.raises(AssertionError) as exc:
        contract.assert_clean()

    assert "completion_claim_without_same_target_terminal_success:operator_text:operator_banner" in str(exc.value)


def test_contract_helper_is_consumed_by_feature_level_tests():
    tests_root = os.path.dirname(os.path.abspath(__file__))
    consumers = []
    for name in os.listdir(tests_root):
        if not name.endswith(".py"):
            continue
        if name in ("test_workflow_boundary_contract.py", "workflow_boundary_contract.py"):
            continue
        path = os.path.join(tests_root, name)
        with io.open(path, "r", encoding="utf-8", errors="ignore") as handle:
            text = handle.read()
        if "assert_workflow_boundary_clean" in text or "WorkflowBoundaryContract" in text:
            consumers.append(name)

    assert consumers, "workflow boundary helper exists but no feature-level test consumes it"
