# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import csv
import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _write_json(path, data):
    with open(path, 'w') as handle:
        json.dump(data, handle)


def _write_text(path, text):
    with open(path, 'w') as handle:
        handle.write(text)


def _write_csv(path):
    _write_text(path, 'Surgery Date,Patient ID,Patient Last,Patient First,Ins1 Payer ID\n05/12/2026,12345,Doe,Jane,87726\n')


def _write_action_report_csv(path):
    _write_text(
        path,
        'category,patient_id,dos,payer_id,claim_key,claim_number,detail,next_action\n'
        'reply_unblock,12345,05/12/2026,87726,k,c,missing,review\n',
    )


def _write_title_case_action_report_csv(path):
    _write_text(
        path,
        'Surgery Date,Patient ID,Patient Last,Patient First,claim_key,next_action,category\n'
        '05/12/2026,12345,Doe,Jane,k,review,reply_unblock\n',
    )


def _write_full_intake_csv(path, patient_id='12345'):
    headers = [
        'Surgery Date', 'Patient ID', 'Patient Last', 'Patient First', 'Patient Middle',
        'Patient Address1', 'Patient Address2', 'Patient City', 'Patient State', 'Patient Zip',
        'Patient Home Ph', 'Patient Cell Ph', 'Patient DOB', 'Age', 'Patient SSN', 'Gender',
        'Email', 'Guarantor Name', 'Guarantor Address1', 'Guarantor Address2',
        'Guarantor City', 'Guarantor State', 'Guarantor Zip', 'Guarantor DOB',
        'Guarantor SSN', 'Guarantor Home Ph', 'Guarantor Cell Ph', 'Guarantor Email',
        'Guarantor Relationship', 'Primary Insurance', 'Primary Address 1',
        'Primary City', 'Primary State', 'Primary Zip', 'Primary Phone',
        'Primary Insured Name', 'Primary DOB', 'Primary Policy Number', 'Group Name',
        'Group Policy 1', 'Ins1 Payer ID', 'Secondary Insurance', 'Secondary Address',
        'Secondary City', 'Secondary State', 'Secondary Zip', 'Secondary Phone',
        'Secondary Insured', 'Secondary DOB', 'Secondary Policy Number',
        'Group Policy 2', 'Ins2 Payer ID', 'Appt ID', 'Surgeon ID',
    ]
    row = [
        '05/12/2026', patient_id, 'DOE', 'JANE', 'Q',
        '1 Main St', '', 'Phoenix', 'AZ', '85001',
        '555-0100', '555-0101', '01/01/1970', '56', '', 'F',
        'jane@example.invalid', 'DOE JANE', '1 Main St', '',
        'Phoenix', 'AZ', '85001', '01/01/1970',
        '', '555-0100', '555-0101', 'guarantor@example.invalid',
        'Self', 'UNITED HEALTHCARE', 'PO Box 1',
        'Atlanta', 'GA', '30301', '555-0102',
        'DOE JANE', '01/01/1970', 'POL123', 'GRP',
        'GP1', '87726', '', '',
        '', '', '', '',
        '', '', '',
        '', '', 'APT1', 'SURG1',
    ]
    with open(path, 'w') as handle:
        writer = csv.writer(handle, lineterminator='\n')
        writer.writerow(headers)
        writer.writerow(row)


class CsvIntakeHeaderBoundaryTests(unittest.TestCase):
    def setUp(self):
        import tempfile

        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_classify_medibot_intake_csv_header_accepts_patient_id_intake_export(self):
        from MediBot import process_csvs

        path = os.path.join(self.tmp, 'SX_CSV_good.csv')
        _write_text(path, 'Surgery Date,Patient ID,Patient Last,Patient First,Ins1 Payer ID\n05/12/2026,12345,Doe,Jane,87726\n')

        result = process_csvs.classify_medibot_intake_csv_header(path)

        self.assertTrue(result.get('ok'))
        self.assertEqual(result.get('reason'), 'ok')
        self.assertIn('Patient ID', result.get('cleaned_headers'))

    def test_classify_medibot_intake_csv_header_rejects_action_report_patient_id_alias(self):
        from MediBot import process_csvs

        path = os.path.join(self.tmp, 'SX_CSV_action.csv')
        _write_text(path, 'detail,claim_key,next_action,dos,patient_id,claim_number,payer_id,category\nx,k,review,05/12/2026,12345,c,p,reply\n')

        result = process_csvs.classify_medibot_intake_csv_header(path)

        self.assertFalse(result.get('ok'))
        self.assertEqual(result.get('reason'), 'action_or_reconciliation_csv')
        self.assertIn('patient_id', result.get('cleaned_headers'))

    def test_classify_medibot_intake_csv_header_requires_surgery_date(self):
        from MediBot import process_csvs

        path = os.path.join(self.tmp, 'demographics.csv')
        _write_text(path, 'Patient ID,Patient Last,Patient First\n12345,Doe,Jane\n')

        result = process_csvs.classify_medibot_intake_csv_header(path)

        self.assertFalse(result.get('ok'))
        self.assertEqual(result.get('reason'), 'missing_surgery_date_header')

    def test_classify_medibot_intake_csv_header_rejects_title_case_action_markers(self):
        from MediBot import process_csvs

        path = os.path.join(self.tmp, 'title_case_action.csv')
        _write_title_case_action_report_csv(path)

        result = process_csvs.classify_medibot_intake_csv_header(path)

        self.assertFalse(result.get('ok'))
        self.assertEqual(result.get('reason'), 'action_or_reconciliation_csv')
        self.assertIn('claim_key', result.get('action_markers'))

    def test_move_csvs_from_storage_quarantines_non_intake_csv(self):
        from MediBot import process_csvs

        source = os.path.join(self.tmp, 'source')
        storage = os.path.join(self.tmp, 'storage')
        os.makedirs(source)
        os.makedirs(storage)
        action_path = os.path.join(storage, 'reconciliation_report.csv')
        intake_path = os.path.join(storage, 'daily.csv')
        _write_action_report_csv(action_path)
        _write_csv(intake_path)

        moved = process_csvs.move_csvs_from_storage(storage, source, silent=True)

        self.assertEqual(moved, 1)
        self.assertTrue(os.path.exists(os.path.join(source, 'daily.csv')))
        self.assertFalse(os.path.exists(os.path.join(source, 'reconciliation_report.csv')))
        quarantine_dir = os.path.join(storage, 'non_intake_csv')
        quarantined = os.listdir(quarantine_dir)
        self.assertEqual(len(quarantined), 1)
        self.assertTrue(quarantined[0].startswith('NON_INTAKE_action_or_reconciliation_csv_'))
        self.assertTrue(quarantined[0].endswith('_reconciliation_report.csv'))

    def test_find_latest_source_csv_skips_newer_non_intake_csv(self):
        from MediBot import process_csvs

        source = os.path.join(self.tmp, 'source')
        os.makedirs(source)
        action_path = os.path.join(source, 'latest_action.csv')
        intake_path = os.path.join(source, 'older_intake.csv')
        _write_action_report_csv(action_path)
        _write_csv(intake_path)
        os.utime(intake_path, (200, 200))
        os.utime(action_path, (300, 300))

        result = process_csvs.find_latest_medibot_intake_source_csv(source)

        self.assertEqual(result.get('name'), 'older_intake.csv')
        self.assertEqual(result.get('rejected_count'), 1)
        self.assertEqual(result.get('last_reject_reason'), 'action_or_reconciliation_csv')

    def test_read_csv_raw_header_row_matches_utf8_bytes_on_disk(self):
        from MediBot import MediBot_Preprocessor_lib as preprocessor_lib

        path = os.path.join(self.tmp, 'enc_probe.csv')
        with open(path, 'wb') as handle:
            handle.write('Surgery Date,Patient ID,Patient Last,Patient First\n'.encode('utf-8'))

        row = preprocessor_lib.read_csv_raw_header_row(path)
        self.assertEqual(
            row,
            ['Surgery Date', 'Patient ID', 'Patient Last', 'Patient First'],
        )

    def test_classify_medibot_intake_accepts_utf8_bom_header_row(self):
        from MediBot import process_csvs

        path = os.path.join(self.tmp, 'utf8_bom_intake.csv')
        with open(path, 'wb') as handle:
            handle.write(
                b'\xef\xbb\xbfSurgery Date,Patient ID,Patient Last,Patient First,Ins1 Payer ID\n'
                b'05/12/2026,12345,Doe,Jane,87726\n'
            )

        result = process_csvs.classify_medibot_intake_csv_header(path)
        self.assertTrue(result.get('ok'), msg=repr(result))
        self.assertEqual(result.get('reason'), 'ok')

    def test_classify_medibot_intake_accepts_utf16_le_header_row(self):
        """Header read must match load_csv_data encoding (chardet); UTF-16 was misread by the legacy cascade."""
        from MediBot import MediBot_Preprocessor_lib as preprocessor_lib
        from MediBot import csv_intake_shape
        from MediBot import process_csvs

        path = os.path.join(self.tmp, 'utf16_intake.csv')
        line = 'Surgery Date,Patient ID,Patient Last,Patient First,Ins1 Payer ID\n'
        with open(path, 'wb') as handle:
            handle.write(b'\xff\xfe')
            handle.write(line.encode('utf-16-le'))

        row_pre = preprocessor_lib.read_csv_raw_header_row(path)
        row_shape = csv_intake_shape.read_csv_raw_header_row(path)
        self.assertEqual(row_shape, row_pre)

        result = process_csvs.classify_medibot_intake_csv_header(path)
        self.assertTrue(result.get('ok'), msg=repr(result))
        self.assertEqual(result.get('reason'), 'ok')

    def test_read_csv_raw_header_row_propagates_aligned_reader_runtime_errors(self):
        """Do not fall back to legacy decoding when chardet/open fails (avoids false non-intake + quarantine)."""
        from MediBot import csv_intake_shape

        path = os.path.join(self.tmp, 'probe.csv')
        _write_text(path, 'Surgery Date,Patient ID\n')

        with patch('MediBot.MediBot_Preprocessor_lib.read_csv_raw_header_row', side_effect=ValueError('simulated decode failure')):
            with self.assertRaises(ValueError):
                csv_intake_shape.read_csv_raw_header_row(path)


class CsvIntakeHeuristicBackfillTests(unittest.TestCase):
    def setUp(self):
        import tempfile

        self.tmp = tempfile.mkdtemp()
        self.target = os.path.join(self.tmp, 'tgt')
        self.storage = os.path.join(self.tmp, 'storage')
        os.makedirs(self.target)
        os.makedirs(self.storage)

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    def _touch(self, path):
        with open(path, 'w') as handle:
            handle.write('x')

    def test_heuristic_picks_earliest_sx_strictly_after_tracker_time(self):
        from MediBot import process_csvs

        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143000_000001.csv'))
        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143500_000001.csv'))
        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key(
            'personal_68_20260114_143204_156738.csv'
        )
        idx['entries'][key] = {
            'downloaded_name': 'personal_68_20260114_143204_156738.csv',
            'current': None,
            'history': [],
        }
        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage, cold_start=True
        )
        self.assertEqual(stats.get('inferred'), 1)
        self.assertEqual(stats.get('skipped_unparsed'), 0)
        self.assertEqual(stats.get('backfill_mode'), 'full_seed')
        cur = idx['entries'][key]['current']
        self.assertEqual(cur['target_basename'], 'SX_CSV_20260114_143500_000001.csv')
        self.assertTrue(cur.get('inferred_mapping'))
        self.assertEqual(cur.get('inference_rule'), 'next_sx_after_tracker_timestamp')

    def test_heuristic_pairs_multiple_tracker_entries_and_consumes_sx_once(self):
        from MediBot import process_csvs

        for name in (
                'SX_CSV_20260114_143010_000001.csv',
                'SX_CSV_20260114_143020_000001.csv'):
            self._touch(os.path.join(self.target, name))
        idx = process_csvs._default_intake_index()
        tracker_names = [
            'personal_1_20260114_143000_000000.csv',
            'personal_2_20260114_143010_000000.csv',
            'personal_3_20260114_143015_000000.csv',
        ]
        for name in tracker_names:
            key = process_csvs._normalize_csv_intake_key(name)
            idx['entries'][key] = {
                'downloaded_name': name,
                'current': None,
                'history': [],
            }

        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage, cold_start=True
        )

        self.assertEqual(stats.get('inferred'), 2)
        self.assertEqual(stats.get('skipped_no_sx'), 1)
        assigned = []
        for name in tracker_names:
            key = process_csvs._normalize_csv_intake_key(name)
            cur = idx['entries'][key].get('current')
            if cur:
                assigned.append(cur.get('target_basename'))
        self.assertEqual(
            assigned,
            ['SX_CSV_20260114_143010_000001.csv', 'SX_CSV_20260114_143020_000001.csv'],
        )
        self.assertEqual(len(set(assigned)), len(assigned))

    def test_heuristic_skips_unparseable_tracker_basename(self):
        from MediBot import process_csvs

        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143500_000001.csv'))
        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key('nodate.csv')
        idx['entries'][key] = {
            'downloaded_name': 'nodate.csv',
            'current': None,
            'history': [],
        }
        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage, cold_start=False
        )
        self.assertEqual(stats.get('inferred'), 0)
        self.assertEqual(stats.get('skipped_unparsed'), 1)
        self.assertEqual(stats.get('backfill_mode'), 'incremental')
        self.assertIsNone(idx['entries'][key].get('current'))

    def test_heuristic_skips_when_no_sx_after_tracker_time(self):
        from MediBot import process_csvs

        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143000_000001.csv'))
        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key(
            'x_20260114_143500_000000.csv'
        )
        idx['entries'][key] = {
            'downloaded_name': 'x_20260114_143500_000000.csv',
            'current': None,
            'history': [],
        }
        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage
        )
        self.assertEqual(stats.get('inferred'), 0)
        self.assertEqual(stats.get('skipped_no_sx'), 1)
        self.assertEqual(stats.get('backfill_mode'), 'incremental')


class CsvIntakeWizardReportTests(unittest.TestCase):
    def test_format_csv_intake_wizard_report_lines(self):
        from MediBot import process_csvs

        idx = process_csvs._default_intake_index()
        idx['entries']['a.csv'] = {
            'downloaded_name': 'A.csv',
            'current': {
                'target_basename': 'SX_CSV_1.csv',
                'status': 'mapped',
            },
            'history': [{}],
        }
        st = {
            'phase': 'started',
            'started_at': 1,
            'completed_at': 2,
            'stats': {
                'mapped_current': 1,
                'no_current_mapping': 0,
                'current_present_in_source': 0,
                'current_present_in_target': 1,
                'history_records_total': 1,
                'downloaded_tracker_count': 1,
            },
        }
        lines = process_csvs.format_csv_intake_wizard_report(idx, st, max_rows=10)
        self.assertTrue(any('A.csv' in ln for ln in lines))
        self.assertTrue(any('SX_CSV_1.csv' in ln for ln in lines))

    def test_format_report_marks_inferred_status(self):
        from MediBot import process_csvs

        idx = process_csvs._default_intake_index()
        idx['entries']['z.csv'] = {
            'downloaded_name': 'z.csv',
            'current': {
                'target_basename': 'SX_CSV_x.csv',
                'status': 'mapped',
                'inferred_mapping': True,
            },
            'history': [],
        }
        lines = process_csvs.format_csv_intake_wizard_report(idx, {}, max_rows=10)
        self.assertTrue(any('inferred' in ln for ln in lines))


class CsvIntakeIndexTests(unittest.TestCase):
    def setUp(self):
        import tempfile

        self.tmp = tempfile.mkdtemp()
        self.source = os.path.join(self.tmp, 'src')
        self.target = os.path.join(self.tmp, 'tgt')
        self.storage = os.path.join(self.tmp, 'storage')
        os.makedirs(self.source)
        os.makedirs(self.target)
        os.makedirs(self.storage)
        self.config_path = os.path.join(self.tmp, 'config.json')
        _write_json(
            self.config_path,
            {
                'CSV_FILE_PATH': '',
                'MediLink_Config': {'local_storage_path': self.storage},
            },
        )

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_creates_index_and_maps_csv(self, _cache, _tracker):
        from MediBot import process_csvs

        csv_path = os.path.join(self.source, 'daily.csv')
        _write_csv(csv_path)
        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )
        self.assertEqual(rc, 0)
        idx_path = os.path.join(self.storage, process_csvs.CSV_INTAKE_INDEX_FILENAME)
        st_path = os.path.join(self.storage, process_csvs.CSV_INTAKE_STATUS_FILENAME)
        self.assertTrue(os.path.isfile(idx_path))
        self.assertTrue(os.path.isfile(st_path))
        with open(idx_path, 'r') as handle:
            data = json.load(handle)
        key = process_csvs._normalize_csv_intake_key('daily.csv')
        self.assertIn(key, data.get('entries', {}))
        cur = data['entries'][key].get('current') or {}
        self.assertTrue(cur.get('target_basename', '').startswith('SX_CSV_'))
        self.assertEqual(cur.get('source_basename'), 'daily.csv')
        self.assertFalse(os.path.exists(os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)))

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_full_intake_csv_reaches_medibot_preprocessor_after_sidecar_update(self, _cache, _tracker):
        from MediBot import MediBot_Preprocessor as preprocessor
        from MediBot import MediBot_Preprocessor_lib as preprocessor_lib
        from MediBot import process_csvs
        from MediCafe import MediLink_ConfigLoader as cfg_loader

        csv_path = os.path.join(self.source, 'daily_full.csv')
        _write_full_intake_csv(csv_path)

        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )

        self.assertEqual(rc, 0)
        cfg_loader.clear_config_cache()
        config, _crosswalk = cfg_loader.load_configuration(
            config_path=self.config_path,
            crosswalk_path=os.path.join(self.tmp, 'crosswalk.json'),
        )
        active_csv = str(config.get('CSV_FILE_PATH') or '').replace('\\\\', '\\')
        self.assertTrue(os.path.basename(active_csv).startswith('SX_CSV_'))
        self.assertTrue(os.path.isfile(active_csv))

        rows = preprocessor_lib.load_csv_data(active_csv)
        header_snapshot = preprocessor_lib.get_last_csv_header_read_snapshot()
        self.assertIn('Patient ID', header_snapshot.get('raw_headers'))
        self.assertIn('Patient ID', rows[0])
        self.assertNotIn('patient_id', rows[0])

        crosswalk = {
            'csv_replacements': {},
            'payer_id': {
                '87726': {
                    'medisoft_id': ['123'],
                    'medisoft_medicare_id': [],
                    'endpoint': 'AVAILITY',
                },
            },
        }
        preprocessor._config_cache = config
        preprocessor._crosswalk_cache = crosswalk
        preprocessor.preprocess_csv_data(rows, crosswalk)

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get('Patient ID'), '12345')
        self.assertEqual(rows[0].get('Ins1 Insurance ID'), '123')

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_no_source_csv_repairs_stale_action_report_csv_file_path(self, _cache, _tracker):
        from MediBot import process_csvs
        from MediCafe import MediLink_ConfigLoader as cfg_loader

        stale_action = os.path.join(self.target, 'SX_CSV_20260511_114249_406250.csv')
        valid_intake = os.path.join(self.target, 'SX_CSV_20260512_080000_000001.csv')
        _write_action_report_csv(stale_action)
        _write_full_intake_csv(valid_intake)
        os.utime(valid_intake, (200, 200))
        os.utime(stale_action, (300, 300))
        _write_json(
            os.path.join(self.tmp, 'config.local.json'),
            {
                '__sidecar__': {'schema_version': 1},
                'CSV_FILE_PATH': stale_action,
            },
        )
        cfg_loader.clear_config_cache()

        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )

        self.assertEqual(rc, 0)
        cfg_loader.clear_config_cache()
        config, _crosswalk = cfg_loader.load_configuration(
            config_path=self.config_path,
            crosswalk_path=os.path.join(self.tmp, 'crosswalk.json'),
        )
        repaired_path = str(config.get('CSV_FILE_PATH') or '').replace('\\\\', '\\')
        self.assertEqual(os.path.normcase(os.path.abspath(repaired_path)), os.path.normcase(os.path.abspath(valid_intake)))

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_source_folder_processes_older_intake_when_newer_csv_is_action_report(self, _cache, _tracker):
        from MediBot import process_csvs
        from MediCafe import MediLink_ConfigLoader as cfg_loader

        action_path = os.path.join(self.source, 'latest_action.csv')
        intake_path = os.path.join(self.source, 'older_intake.csv')
        _write_action_report_csv(action_path)
        _write_full_intake_csv(intake_path)
        os.utime(intake_path, (200, 200))
        os.utime(action_path, (300, 300))

        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )

        self.assertEqual(rc, 0)
        self.assertTrue(os.path.exists(action_path))
        self.assertFalse(os.path.exists(intake_path))
        cfg_loader.clear_config_cache()
        config, _crosswalk = cfg_loader.load_configuration(
            config_path=self.config_path,
            crosswalk_path=os.path.join(self.tmp, 'crosswalk.json'),
        )
        active_csv = str(config.get('CSV_FILE_PATH') or '').replace('\\\\', '\\')
        self.assertTrue(os.path.basename(active_csv).startswith('SX_CSV_'))
        self.assertTrue(os.path.exists(active_csv))

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_only_non_intake_source_csv_keeps_valid_configured_intake_csv(self, _cache, _tracker):
        from MediBot import process_csvs
        from MediCafe import MediLink_ConfigLoader as cfg_loader
        from MediBot.update_json import update_csv_path

        configured_intake = os.path.join(self.target, 'SX_CSV_20260512_080000_000001.csv')
        action_path = os.path.join(self.source, 'latest_action.csv')
        _write_full_intake_csv(configured_intake)
        _write_action_report_csv(action_path)
        update_csv_path(self.config_path, configured_intake)
        cfg_loader.clear_config_cache()

        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )

        self.assertEqual(rc, 0)
        self.assertTrue(os.path.exists(action_path))
        cfg_loader.clear_config_cache()
        config, _crosswalk = cfg_loader.load_configuration(
            config_path=self.config_path,
            crosswalk_path=os.path.join(self.tmp, 'crosswalk.json'),
        )
        active_csv = str(config.get('CSV_FILE_PATH') or '').replace('\\\\', '\\')
        self.assertEqual(
            os.path.normcase(os.path.abspath(active_csv)),
            os.path.normcase(os.path.abspath(configured_intake)),
        )

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_busy_workflow_lock_blocks_second_processor(self, _cache, _tracker):
        from MediBot import process_csvs

        csv_path = os.path.join(self.source, 'daily.csv')
        _write_csv(csv_path)
        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        _write_json(lock_path, {
            'pid': os.getpid(),
            'created_at': 1,
            'writer': 'process_csvs',
            'artifact': 'csv_processing_workflow',
        })
        old_wait = process_csvs._CSV_WORKFLOW_LOCK_WAIT_SEC
        try:
            process_csvs._CSV_WORKFLOW_LOCK_WAIT_SEC = 0
            rc = process_csvs.process_csv(
                self.source,
                self.target,
                self.config_path,
                local_storage_path=self.storage,
                silent=True,
            )
        finally:
            process_csvs._CSV_WORKFLOW_LOCK_WAIT_SEC = old_wait
            if os.path.exists(lock_path):
                os.remove(lock_path)
        self.assertEqual(rc, 1)
        self.assertTrue(os.path.exists(csv_path))

    def test_release_workflow_lock_keeps_file_without_matching_pid(self):
        from MediBot import process_csvs

        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        foreign_pid = 999999001
        _write_json(lock_path, {
            'pid': foreign_pid,
            'created_at': 1,
            'writer': 'process_csvs',
            'artifact': 'csv_processing_workflow',
        })
        process_csvs._release_csv_workflow_lock(lock_path)
        self.assertTrue(os.path.exists(lock_path))

    def test_release_workflow_lock_no_pid_key_does_not_remove(self):
        from MediBot import process_csvs

        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        _write_json(lock_path, {'writer': 'process_csvs', 'artifact': 'csv_processing_workflow'})
        process_csvs._release_csv_workflow_lock(lock_path)
        self.assertTrue(os.path.exists(lock_path))

    def test_release_workflow_lock_removes_when_pid_matches(self):
        from MediBot import process_csvs

        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        _write_json(lock_path, {
            'pid': os.getpid(),
            'created_at': 1,
            'writer': 'process_csvs',
            'artifact': 'csv_processing_workflow',
        })
        process_csvs._release_csv_workflow_lock(lock_path)
        self.assertFalse(os.path.exists(lock_path))

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_appends_history_on_second_intake_same_basename(self, _cache, _tracker):
        from MediBot import process_csvs

        _write_csv(os.path.join(self.source, 'daily.csv'))
        self.assertEqual(
            0,
            process_csvs.process_csv(
                self.source,
                self.target,
                self.config_path,
                local_storage_path=self.storage,
                silent=True,
            ),
        )
        _write_csv(os.path.join(self.source, 'daily.csv'))
        self.assertEqual(
            0,
            process_csvs.process_csv(
                self.source,
                self.target,
                self.config_path,
                local_storage_path=self.storage,
                silent=True,
            ),
        )
        idx_path = os.path.join(self.storage, process_csvs.CSV_INTAKE_INDEX_FILENAME)
        with open(idx_path, 'r') as handle:
            data = json.load(handle)
        key = process_csvs._normalize_csv_intake_key('daily.csv')
        ent = data['entries'][key]
        self.assertGreaterEqual(len(ent.get('history', [])), 1)

    def test_reconcile_marks_target_missing(self):
        from MediBot import process_csvs

        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key('x.csv')
        idx['entries'][key] = {
            'downloaded_name': 'x.csv',
            'first_seen_at_utc': 1,
            'last_seen_at_utc': 1,
            'history': [],
            'current': {
                'source_path': os.path.join(self.source, 'x.csv'),
                'target_path': os.path.join(self.target, 'SX_CSV_1.csv'),
                'source_basename': 'x.csv',
                'target_basename': 'SX_CSV_1.csv',
                'present_in_source': True,
                'present_in_target': True,
                'last_process_iteration': 1,
                'status': 'mapped',
                'updated_at_utc': 1,
            },
        }
        _write_csv(os.path.join(self.target, 'SX_CSV_1.csv'))
        process_csvs._reconcile_intake_index_entries(idx, self.source, self.target)
        self.assertEqual(idx['entries'][key]['current']['status'], 'mapped')
        os.remove(os.path.join(self.target, 'SX_CSV_1.csv'))
        process_csvs._reconcile_intake_index_entries(idx, self.source, self.target)
        self.assertEqual(idx['entries'][key]['current']['status'], 'target_only')

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    @patch('MediBot.process_csvs._save_csv_intake_index')
    def test_intake_continues_when_index_write_fails(self, mock_save, _cache, _tracker):
        from MediBot import process_csvs

        mock_save.return_value = False
        _write_csv(os.path.join(self.source, 'daily.csv'))
        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )
        self.assertEqual(rc, 0)
        self.assertGreaterEqual(mock_save.call_count, 1)


class ParseSxCsvDatetimeTests(unittest.TestCase):
    """_parse_sx_csv_datetime: variable-length fractional seconds -> microseconds."""

    def test_short_fraction_right_padded(self):
        from datetime import datetime

        from MediBot import process_csvs

        dt5 = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_5.csv')
        self.assertEqual(dt5, datetime(2026, 1, 14, 14, 30, 0, 500000))
        dt50 = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_50.csv')
        self.assertEqual(dt50, datetime(2026, 1, 14, 14, 30, 0, 500000))
        dt123 = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_123.csv')
        self.assertEqual(dt123, datetime(2026, 1, 14, 14, 30, 0, 123000))

    def test_six_digit_fraction_unchanged(self):
        from datetime import datetime

        from MediBot import process_csvs

        dt = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_000001.csv')
        self.assertEqual(dt, datetime(2026, 1, 14, 14, 30, 0, 1))

    def test_long_fraction_truncated_to_six_digits(self):
        from datetime import datetime

        from MediBot import process_csvs

        dt = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_123456789.csv')
        self.assertEqual(dt, datetime(2026, 1, 14, 14, 30, 0, 123456))


if __name__ == '__main__':
    unittest.main()
