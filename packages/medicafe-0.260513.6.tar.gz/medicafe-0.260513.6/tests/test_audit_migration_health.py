# -*- coding: utf-8 -*-
"""Canonical pytest coverage for critical audit_migration_health helpers."""

from __future__ import print_function

import calendar
import json
import os
import shutil
import sys
import tempfile
import time
import unittest


_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM_MODEL = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM_MODEL not in sys.path:
    sys.path.insert(0, _UM_MODEL)


class TestAuditMigrationHealthHelpers(unittest.TestCase):
    def test_latest_report_tie_breaker_is_deterministic(self):
        import audit_migration_health as amh

        lab = tempfile.mkdtemp(prefix="mc_audit_health_")
        reports = os.path.join(lab, "reports")
        try:
            os.makedirs(reports)
            a_path = os.path.join(reports, "qa_canonical_summary_run-a.json")
            b_path = os.path.join(reports, "qa_canonical_summary_run-b.json")
            for path in (a_path, b_path):
                with open(path, "w", encoding="utf-8") as f:
                    json.dump({"ok": True}, f)
            now = time.time()
            os.utime(a_path, (now, now))
            os.utime(b_path, (now, now))

            path, run_id = amh.latest_report(reports, "qa_canonical_summary_", (".json",))

            self.assertEqual(path, b_path)
            self.assertEqual(run_id, "run-b")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_parse_ts_uses_utc_not_local_timezone(self):
        import audit_migration_health as amh

        ts = "2026-02-18T00:00:00Z"
        expected = int(calendar.timegm(time.strptime(ts, "%Y-%m-%dT%H:%M:%SZ")))

        self.assertEqual(amh.parse_ts(ts), expected)


if __name__ == "__main__":
    unittest.main()
