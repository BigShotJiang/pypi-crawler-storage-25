import builtins


def _crosswalk_with_missing_name_and_medisoft_id():
    return {
        "payer_id": {
            "64157": {
                "name": "Unknown",
                "medisoft_id": ["A123"],
                "medisoft_medicare_id": [],
            },
            "74227": {
                "name": "Known Payer",
                "medisoft_id": [],
                "medisoft_medicare_id": [],
            },
        }
    }


def test_missing_medisoft_ids_only_is_quiet_maintenance_backlog(capsys):
    from MediBot import MediBot_Crosswalk_Utils as crosswalk_utils

    proceed, updated = crosswalk_utils.prompt_user_for_api_calls(
        {
            "payer_id": {
                "74227": {
                    "name": "Known Payer",
                    "medisoft_id": [],
                    "medisoft_medicare_id": [],
                },
            },
        },
        {"MediLink_Config": {}},
    )

    output = capsys.readouterr().out
    assert proceed is False
    assert updated["payer_id"]["74227"]["name"] == "Known Payer"
    assert "Crosswalk needs attention" not in output
    assert "Missing Medisoft insurance IDs" not in output
    assert "Claims can continue" not in output


def test_missing_payer_name_resolution_defaults_to_skip(monkeypatch, capsys):
    from MediBot import MediBot_Crosswalk_Utils as crosswalk_utils

    prompts = []

    def fake_input(prompt):
        prompts.append(prompt)
        return ""

    monkeypatch.setattr(builtins, "input", fake_input)

    proceed, updated = crosswalk_utils.prompt_user_for_api_calls(
        _crosswalk_with_missing_name_and_medisoft_id(),
        {"MediLink_Config": {}},
    )

    output = capsys.readouterr().out
    assert proceed is False
    assert updated["payer_id"]["64157"]["name"] == "Unknown"
    assert "Claims can continue. Unknown medisoft IDs are mapped during claim submission." in output
    assert any("Resolve missing payer names now? [y/N]:" in prompt for prompt in prompts)
    assert "Resolving missing payer names via API validation" not in output


def test_missing_payer_name_resolution_runs_only_after_operator_yes(monkeypatch, capsys):
    from MediBot import MediBot_Crosswalk_Utils as crosswalk_utils

    prompts = []

    def fake_input(prompt):
        prompts.append(prompt)
        return "y"

    monkeypatch.setattr(builtins, "input", fake_input)

    proceed, updated = crosswalk_utils.prompt_user_for_api_calls(
        _crosswalk_with_missing_name_and_medisoft_id(),
        {"MediLink_Config": {}},
    )

    output = capsys.readouterr().out
    assert proceed is True
    assert updated["payer_id"]["64157"]["name"] == "Unknown"
    assert any("Resolve missing payer names now? [y/N]:" in prompt for prompt in prompts)
    assert "Resolving missing payer names via API validation" in output
