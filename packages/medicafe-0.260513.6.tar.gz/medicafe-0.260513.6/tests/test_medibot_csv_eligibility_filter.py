#!/usr/bin/env python
from __future__ import print_function

import importlib.util
import os
import sys


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)
_TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from MediBot import MediBot_Preprocessor_lib as preprocessor_lib
from workflow_boundary_contract import assert_workflow_boundary_clean


def _load_medibot_script_module():
    medibot_dir = os.path.join(_PROJECT_ROOT, "MediBot")
    if medibot_dir not in sys.path:
        sys.path.insert(0, medibot_dir)
    module_path = os.path.join(medibot_dir, "MediBot.py")
    spec = importlib.util.spec_from_file_location("medibot_script_for_empty_csv_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_filter_rows_records_aggregate_eligibility_summary(monkeypatch):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    rows = [
        {"Patient ID": "", "Primary Insurance": "BCBS"},
        {"Patient ID": "123", "Primary Insurance": "AETNA"},
        {"Patient ID": "", "Primary Insurance": "HUMANA MED HMO"},
        {"Patient ID": "456", "Primary Insurance": "BCBS"},
    ]
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    preprocessor_lib.filter_rows(rows)

    assert rows == [{"Patient ID": "456", "Primary Insurance": "BCBS"}]
    summary = preprocessor_lib.get_last_filter_rows_summary()
    assert summary["input_count"] == 4
    assert summary["retained_count"] == 1
    assert summary["removed_count"] == 3
    assert summary["missing_patient_id_count"] == 1
    assert summary["excluded_insurance_count"] == 1
    assert summary["both_missing_patient_id_and_excluded_insurance_count"] == 1
    assert summary["excluded_insurance_breakdown"] == {"AETNA": 1, "HUMANA MED HMO": 1}
    assert any("CSV row eligibility filter: input=4 retained=1 removed=3" in message for level, message in logs)


def test_update_diagnosis_codes_skips_empty_csv_without_loading_config(monkeypatch):
    logs = []

    def fail_get_cached_configuration():
        raise AssertionError("empty csv_data should not require configuration")

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    monkeypatch.setattr(preprocessor_lib, "get_cached_configuration", fail_get_cached_configuration)
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    preprocessor_lib.update_diagnosis_codes([])

    assert any("No CSV rows available for diagnosis-code enrichment" in message for level, message in logs)
    assert not any(level == "ERROR" for level, message in logs)


def test_medibot_empty_preprocessed_csv_guard_logs_and_stops(monkeypatch, capsys):
    medibot_script = _load_medibot_script_module()
    logs = []

    class Logger(object):
        def log(self, message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

    monkeypatch.setattr(medibot_script, "MediLink_ConfigLoader", Logger())
    monkeypatch.setattr(medibot_script.MediBot_Preprocessor_lib, "_last_filter_rows_summary", {
        "input_count": 3,
        "retained_count": 0,
        "removed_count": 3,
        "missing_patient_id_count": 2,
        "excluded_insurance_count": 1,
        "both_missing_patient_id_and_excluded_insurance_count": 0,
        "excluded_insurance_breakdown": {"AETNA": 1},
    })

    assert medibot_script._handle_empty_preprocessed_csv([]) is True
    assert medibot_script._handle_empty_preprocessed_csv([{"Patient ID": "123"}]) is False

    output = capsys.readouterr().out
    assert "No eligible patient rows remain after CSV preprocessing" in output
    assert "Filter summary: input=3 retained=0 removed=3" in output
    assert "missing_patient_id=2" in output
    assert "excluded_insurance=1" in output
    assert any(level == "WARNING" and "Filter summary: input=3 retained=0 removed=3" in message for level, message in logs)


def test_update_insurance_ids_warns_only_for_current_csv_missing_medisoft(monkeypatch, capsys):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    rows = [
        {"Patient ID": "101", "Ins1 Payer ID": "41194"},
        {"Patient ID": "102", "Ins1 Payer ID": "41194"},
        {"Patient ID": "103", "Ins1 Payer ID": "87726"},
    ]
    crosswalk = {
        "payer_id": {
            "41194": {"name": "Known Missing", "medisoft_id": [], "medisoft_medicare_id": []},
            "87726": {"name": "Mapped", "medisoft_id": ["487"], "medisoft_medicare_id": []},
        }
    }
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    summary = preprocessor_lib.update_insurance_ids(rows, {}, crosswalk)

    output = capsys.readouterr().out
    assert "Today's CSV has payer IDs without Medisoft insurance mapping" in output
    assert "41194" in output
    assert "101, 102" in output
    assert "87726" not in output
    assert summary["affected_row_count"] == 2
    assert summary["affected_payers"]["41194"]["row_count"] == 2
    assert rows[2]["Ins1 Insurance ID"] == 487
    assert any(level == "WARNING" and "Current CSV missing Medisoft mapping" in message for level, message in logs)


def test_update_insurance_ids_stays_quiet_when_current_csv_is_mapped(monkeypatch, capsys):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    rows = [{"Patient ID": "103", "Ins1 Payer ID": "87726"}]
    crosswalk = {
        "payer_id": {
            "87726": {"name": "Mapped", "medisoft_id": ["487"], "medisoft_medicare_id": []},
            "41194": {"name": "Backlog", "medisoft_id": [], "medisoft_medicare_id": []},
        }
    }
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    summary = preprocessor_lib.update_insurance_ids(rows, {}, crosswalk)

    output = capsys.readouterr().out
    assert "Today's CSV has payer IDs without Medisoft insurance mapping" not in output
    assert summary["affected_row_count"] == 0
    assert summary["affected_payers"] == {}
    assert rows[0]["Ins1 Insurance ID"] == 487


def test_update_insurance_ids_empty_csv_has_no_scoped_warning(monkeypatch, capsys):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    crosswalk = {
        "payer_id": {
            "41194": {"name": "Backlog", "medisoft_id": [], "medisoft_medicare_id": []},
        }
    }
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    summary = preprocessor_lib.update_insurance_ids([], {}, crosswalk)

    output = capsys.readouterr().out
    assert "Today's CSV has payer IDs without Medisoft insurance mapping" not in output
    assert summary["affected_row_count"] == 0
    assert summary["affected_payers"] == {}


def test_update_insurance_ids_invalid_self_pay_does_not_pollute_crosswalk(monkeypatch, capsys):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    rows = [{"Patient ID": "201", "Ins1 Payer ID": "SELF PAY / CHARITY"}]
    crosswalk = {"payer_id": {}}
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    summary = preprocessor_lib.update_insurance_ids(rows, {}, crosswalk)

    output = capsys.readouterr().out
    assert "Today's CSV has payer IDs without Medisoft insurance mapping" not in output
    assert "SELF PAY / CHARITY" not in crosswalk["payer_id"]
    assert summary["affected_row_count"] == 0
    assert summary["affected_payers"] == {}


def test_update_insurance_ids_workflow_boundary_ignores_non_current_optum_backlog(monkeypatch, capsys):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    rows = [{"Patient ID": "301", "Ins1 Payer ID": "87726"}]
    crosswalk = {
        "payer_id": {
            "87726": {"name": "Mapped", "medisoft_id": ["487"], "medisoft_medicare_id": []},
        },
        "optum_payer_list": {
            "payer_ids": ["41194"],
            "payers": {"41194": {"eligibility": True}},
        },
    }
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    summary = preprocessor_lib.update_insurance_ids(rows, {}, crosswalk)

    output = capsys.readouterr().out
    assert "Today's CSV has payer IDs without Medisoft insurance mapping" not in output
    assert "41194" not in crosswalk["payer_id"]
    assert summary["affected_row_count"] == 0
    assert_workflow_boundary_clean("medibot_current_csv_crosswalk_scope", {
        "csv_scope": "active_csv",
        "payer_ids": "87726",
    }, [
        {
            "name": "active_csv_intake",
            "role": "intent",
            "identity": {"csv_scope": "active_csv", "payer_ids": "87726"},
            "status": "requested",
            "classification": "in_flight",
        },
        {
            "name": "update_insurance_ids",
            "role": "attempt",
            "identity": {"csv_scope": "active_csv", "payer_ids": "87726"},
            "status": "completed",
            "terminal": True,
            "classification": "ready",
        },
        {
            "name": "optum_payer_list_only",
            "role": "mutable_evidence",
            "identity": {"csv_scope": "optum_payer_list", "payer_ids": "41194"},
            "status": "ready",
            "terminal": True,
            "classification": "ignored_mismatch",
        },
        {
            "name": "operator_warning",
            "role": "consumer_wording",
            "identity": {"csv_scope": "active_csv", "payer_ids": "87726"},
            "status": "completed",
            "terminal": True,
            "classification": "ignored",
        },
    ])


def test_update_insurance_ids_workflow_boundary_scopes_new_placeholder_to_current_csv(monkeypatch, capsys):
    logs = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
        logs.append((level, message))

    rows = [{"Patient ID": "401", "Ins1 Payer ID": "81400"}]
    crosswalk = {"payer_id": {}}
    monkeypatch.setattr(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log)

    summary = preprocessor_lib.update_insurance_ids(rows, {}, crosswalk)

    output = capsys.readouterr().out
    assert "Today's CSV has payer IDs without Medisoft insurance mapping" in output
    assert "81400 (new): 1 row(s), patients: 401" in output
    assert crosswalk["payer_id"]["81400"]["medisoft_id"] == []
    assert summary["placeholder_count"] == 1
    assert summary["affected_payers"]["81400"]["created_placeholder"] is True
    assert_workflow_boundary_clean("medibot_current_csv_crosswalk_scope", {
        "csv_scope": "active_csv",
        "payer_ids": "81400",
    }, [
        {
            "name": "active_csv_intake",
            "role": "intent",
            "identity": {"csv_scope": "active_csv", "payer_ids": "81400"},
            "status": "requested",
            "classification": "in_flight",
        },
        {
            "name": "update_insurance_ids",
            "role": "attempt",
            "identity": {"csv_scope": "active_csv", "payer_ids": "81400"},
            "status": "completed",
            "terminal": True,
            "classification": "review_required",
        },
        {
            "name": "crosswalk_placeholder",
            "role": "state",
            "identity": {"csv_scope": "active_csv", "payer_ids": "81400"},
            "status": "completed",
            "terminal": True,
            "classification": "review_required",
        },
        {
            "name": "operator_warning",
            "role": "consumer_wording",
            "identity": {"csv_scope": "active_csv", "payer_ids": "81400"},
            "status": "completed",
            "terminal": True,
            "classification": "review_required",
        },
    ])
