import json
import os
import sys

from MediCafe import diagnostic_attempts

TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if TESTS_ROOT not in sys.path:
    sys.path.insert(0, TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean  # noqa: E402


def _read_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def test_begin_attempt_writes_attempt_and_latest_with_safe_tokens(tmp_path):
    lab = str(tmp_path)

    doc = diagnostic_attempts.begin_attempt(
        lab,
        "phase c/probe",
        target_anchor_run_id="anchor-1",
        target_context_run_id="ctx-1",
        issue_code="ISSUE",
        attempt_id="attempt/one",
        expected_artifacts=["a.json"],
        now_utc="2026-05-11T01:02:03Z",
    )

    assert doc["schema_version"] == diagnostic_attempts.DIAGNOSTIC_ATTEMPT_SCHEMA_VERSION
    assert doc["diagnostic_kind"] == "phase c/probe"
    assert doc["attempt_id"] == "attempt_one"
    assert doc["status"] == "started"
    assert doc["expected_artifacts"] == ["a.json"]

    attempt_path = diagnostic_attempts.attempt_path(lab, "phase c/probe", "attempt/one")
    latest_path = diagnostic_attempts.latest_attempt_path(lab, "phase c/probe")
    assert os.path.basename(attempt_path) == "diagnostic_attempt_phase_c_probe_attempt_one.json"
    assert os.path.isfile(attempt_path)
    assert os.path.isfile(latest_path)
    assert _read_json(latest_path)["attempt_id"] == "attempt_one"


def test_mark_spawned_then_finish_attempt_records_success_fields(tmp_path):
    lab = str(tmp_path)
    diagnostic_attempts.begin_attempt(lab, "qa", attempt_id="a1")

    running = diagnostic_attempts.mark_spawned(
        lab,
        "qa",
        "a1",
        child_pid="123",
        script_path="probe.py",
        cwd="C:\\dev\\MediCafe",
    )
    assert running["status"] == "running"
    assert running["child_pid"] == 123
    assert running["script_path"] == "probe.py"

    finished = diagnostic_attempts.finish_attempt(
        lab,
        "qa",
        "a1",
        returncode=0,
        stdout_tail="ok",
        stderr_tail="",
        resolved_artifacts=["report.json"],
        accepted_for_anchor=True,
        primary_report_path="report.json",
        domain_status="ready",
        domain_detail="probe passed",
        finished_at_utc="2026-05-11T02:00:00Z",
    )

    assert finished["status"] == "succeeded"
    assert finished["returncode"] == 0
    assert finished["resolved_artifacts"] == ["report.json"]
    assert finished["accepted_for_anchor"] is True
    assert finished["fail_closed"] is False
    assert finished["primary_report_path"] == "report.json"
    assert finished["domain_status"] == "ready"
    assert diagnostic_attempts.read_attempt(lab, "qa")["attempt_id"] == "a1"


def test_spawned_attempt_is_in_flight_not_anchor_acceptance(tmp_path):
    lab = str(tmp_path)
    diagnostic_attempts.begin_attempt(
        lab,
        "qa",
        attempt_id="a1",
        target_anchor_run_id="anchor-1",
        target_context_run_id="ctx-1",
        issue_code="QA_PROBE",
        now_utc="2026-05-11T01:00:00Z",
    )

    running = diagnostic_attempts.mark_spawned(
        lab,
        "qa",
        "a1",
        child_pid="123",
        script_path="probe.py",
        cwd="C:\\dev\\MediCafe",
    )
    latest = diagnostic_attempts.read_attempt(lab, "qa")

    assert running["status"] == "running"
    assert running["accepted_for_anchor"] is False
    assert latest["status"] == "running"
    assert latest["accepted_for_anchor"] is False

    assert_workflow_boundary_clean("diagnostic_attempt", {
        "anchor_run_id": "anchor-1",
        "context_run_id": "ctx-1",
        "attempt_id": "a1",
    }, [
        {
            "name": "diagnostic_attempt_qa_latest.json",
            "role": "attempt_tracker",
            "identity": {
                "anchor_run_id": latest.get("target_anchor_run_id"),
                "context_run_id": latest.get("target_context_run_id"),
                "attempt_id": latest.get("attempt_id"),
            },
            "status": latest.get("status"),
            "accepted": latest.get("accepted_for_anchor"),
            "classification": "in_flight",
            "claims_completion": False,
            "terminal": False,
        },
        {
            "name": "support_bundle_packaging_decision",
            "role": "packaging_surface",
            "identity": {
                "anchor_run_id": "anchor-1",
                "context_run_id": "ctx-1",
                "attempt_id": "a1",
            },
            "status": "running",
            "accepted": False,
            "classification": "in_flight",
            "claims_completion": False,
        },
    ])


def test_fail_attempt_records_closed_failure_without_anchor_acceptance(tmp_path):
    lab = str(tmp_path)
    diagnostic_attempts.begin_attempt(lab, "runbook", attempt_id="a2")

    failed = diagnostic_attempts.fail_attempt(
        lab,
        "runbook",
        "a2",
        returncode=7,
        stdout_tail="some output",
        stderr_tail="bad",
        resolved_artifacts=["partial.json"],
        domain_status="blocked",
        domain_detail="missing input",
        finished_at_utc="2026-05-11T03:00:00Z",
    )

    assert failed["status"] == "failed"
    assert failed["returncode"] == 7
    assert failed["accepted_for_anchor"] is False
    assert failed["fail_closed"] is True
    assert failed["stderr_tail"] == "bad"
    assert failed["domain_detail"] == "missing input"


def test_reconcile_attempt_times_out_only_stale_open_attempts(tmp_path):
    lab = str(tmp_path)
    diagnostic_attempts.begin_attempt(
        lab,
        "smoke",
        attempt_id="old",
        now_utc="2026-05-11T00:00:00Z",
    )

    fresh = diagnostic_attempts.reconcile_attempt(
        lab,
        "smoke",
        "old",
        stale_after_sec=3600,
        now_epoch=diagnostic_attempts._iso_to_epoch("2026-05-11T00:30:00Z"),
    )
    assert fresh["status"] == "started"

    stale = diagnostic_attempts.reconcile_attempt(
        lab,
        "smoke",
        "old",
        stale_after_sec=3600,
        now_epoch=diagnostic_attempts._iso_to_epoch("2026-05-11T02:00:00Z"),
        finished_at_utc="2026-05-11T02:00:00Z",
    )
    assert stale["status"] == "timeout"
    assert stale["accepted_for_anchor"] is False
    assert stale["fail_closed"] is True
    assert stale["domain_status"] == "timeout"

    again = diagnostic_attempts.reconcile_attempt(
        lab,
        "smoke",
        "old",
        stale_after_sec=1,
        now_epoch=diagnostic_attempts._iso_to_epoch("2026-05-11T03:00:00Z"),
    )
    assert again["status"] == "timeout"
    assert again["finished_at_utc"] == "2026-05-11T02:00:00Z"


def test_collect_bundle_attempt_files_filters_by_kind_and_anchor(tmp_path):
    lab = str(tmp_path)
    diagnostic_attempts.begin_attempt(
        lab,
        "kind-a",
        attempt_id="a1",
        target_anchor_run_id="anchor-1",
    )
    diagnostic_attempts.finish_attempt(lab, "kind-a", "a1", resolved_artifacts=["one"])
    diagnostic_attempts.begin_attempt(
        lab,
        "kind-a",
        attempt_id="a2",
        target_anchor_run_id="anchor-2",
    )
    diagnostic_attempts.fail_attempt(lab, "kind-a", "a2")
    diagnostic_attempts.begin_attempt(
        lab,
        "kind-b",
        attempt_id="b1",
        target_anchor_run_id="anchor-1",
    )

    kind_a_anchor_1 = diagnostic_attempts.collect_bundle_attempt_files(
        lab,
        diagnostic_kind="kind-a",
        anchor_run_id="anchor-1",
    )
    basenames = [os.path.basename(path) for path in kind_a_anchor_1]
    assert basenames == ["diagnostic_attempt_kind-a_a1.json"]

    all_anchor_1 = diagnostic_attempts.collect_bundle_attempt_files(
        lab,
        anchor_run_id="anchor-1",
        include_latest=False,
    )
    basenames = [os.path.basename(path) for path in all_anchor_1]
    assert basenames == [
        "diagnostic_attempt_kind-a_a1.json",
        "diagnostic_attempt_kind-b_b1.json",
    ]
