# -*- coding: utf-8 -*-
"""Tests for MediCafe.json_io (pytest; dev Python 3.11+)."""
from __future__ import print_function

import ctypes
import errno
import json
import io
import logging
import os
import sys
import threading
import time
import types

import pytest

_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from MediCafe import json_io  # noqa: E402


def test_write_json_atomic_roundtrip(tmp_path):
    p = str(tmp_path / 'cfg.json')
    payload = {'a': 1, 'b': [2, 3]}
    assert json_io.write_json_atomic(
        p, payload, 'test', 'pytest', indent=2, lock=False, ensure_ascii=True
    )
    with open(p, 'r', encoding='utf-8') as handle:
        got = json.load(handle)
    assert got == payload


def test_write_preserves_original_on_failed_promote(tmp_path, monkeypatch):
    dest = str(tmp_path / 'out.json')
    original = {'keep': True}
    with open(dest, 'w', encoding='utf-8') as handle:
        json.dump(original, handle)

    calls = {'n': 0}

    def boom_rename(src, dst):
        calls['n'] += 1
        raise OSError(13, 'permission denied')

    monkeypatch.setattr(os, 'rename', boom_rename)
    if hasattr(os, 'replace'):
        def boom_replace(src, dst):
            calls['n'] += 1
            raise OSError(13, 'permission denied')

        monkeypatch.setattr(os, 'replace', boom_replace)

    ok = json_io.write_json_atomic(
        dest, {'new': 'data'}, 'test', 'pytest', lock=False, ensure_ascii=True
    )
    assert ok is False
    with open(dest, 'r', encoding='utf-8') as handle:
        disk = json.load(handle)
    assert disk == original
    temps = [f for f in os.listdir(tmp_path) if 'tmp' in f and f.endswith('.json')]
    assert not temps


def test_lock_blocks_second_writer(tmp_path):
    path = str(tmp_path / 'x.json')
    lock_path = path + '.lock'
    results = []

    def first():
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        # Use this process pid so the lock is not mistaken for an orphan (dead owner) while the
        # thread still intends to hold the artifact.
        payload = json.dumps({'pid': os.getpid(), 'created_at': 0}, ensure_ascii=True)
        os.write(fd, payload.encode('ascii'))
        os.close(fd)
        time.sleep(0.3)
        try:
            os.remove(lock_path)
        except OSError:
            pass

    def second():
        ok = json_io.write_json_atomic(path, {'v': 2}, 't', 'w2', lock=True, ensure_ascii=True)
        results.append(ok)

    t1 = threading.Thread(target=first)
    t2 = threading.Thread(target=second)
    t1.start()
    time.sleep(0.05)
    t2.start()
    t1.join(timeout=5)
    t2.join(timeout=5)
    assert results == [True]
    assert os.path.isfile(path)


def test_stale_lock_removed(tmp_path):
    path = str(tmp_path / 'y.json')
    lock_path = path + '.lock'
    old = time.time() - 700
    with open(lock_path, 'w') as handle:
        handle.write('{"pid":999999,"created_at":%s}' % old)
    os.utime(lock_path, (old, old))
    assert json_io.write_json_atomic(path, {'ok': True}, 't', 'w', lock=True, ensure_ascii=True)
    assert not os.path.exists(lock_path)


def test_lock_reclaims_fresh_lock_when_recorded_owner_is_dead(tmp_path):
    path = str(tmp_path / 'reclaim.json')
    lock_path = path + '.lock'
    stale_pid = 999999991
    with open(lock_path, 'w', encoding='utf-8') as handle:
        handle.write(
            json.dumps(
                {'pid': stale_pid, 'created_at': time.time(), 'artifact': 't'},
                ensure_ascii=True,
            )
        )
    assert json_io._lock_is_stale(lock_path) is True
    assert json_io.write_json_atomic(path, {'reclaimed': True}, 't', 'w', lock=True, ensure_ascii=True)
    with open(path, 'r', encoding='utf-8') as handle:
        assert json.load(handle).get('reclaimed') is True


def test_lock_create_access_denied_with_existing_lock_retries(tmp_path, monkeypatch):
    path = str(tmp_path / 'access_retry.json')
    lock_path = path + '.lock'
    with open(lock_path, 'w', encoding='utf-8') as handle:
        handle.write(
            json.dumps(
                {'pid': os.getpid(), 'created_at': time.time(), 'artifact': 't'},
                ensure_ascii=True,
            )
        )

    real_open = os.open
    calls = {'n': 0}

    def flaky_open(open_path, flags, *args):
        if open_path == lock_path and os.path.exists(lock_path):
            calls['n'] += 1
            if calls['n'] >= 2:
                os.remove(lock_path)
                return real_open(open_path, flags, *args)
            raise OSError(errno.EACCES, 'permission denied')
        return real_open(open_path, flags, *args)

    monkeypatch.setattr(json_io.os, 'open', flaky_open)
    assert json_io.write_json_atomic(path, {'recovered': True}, 't', 'w', lock=True, ensure_ascii=True)
    assert calls['n'] == 2
    with open(path, 'r', encoding='utf-8') as handle:
        assert json.load(handle).get('recovered') is True


def test_lock_create_access_denied_without_lock_is_failure(tmp_path):
    path = str(tmp_path / 'access_fail.json')
    exc = OSError(errno.EACCES, 'permission denied')
    assert json_io._lock_create_error_is_contention(exc, path + '.lock') is False


def test_pid_alive_windows_open_process_access_denied(monkeypatch):
    """Do not treat ACCESS_DENIED as a dead owner; avoids stealing live json_io locks."""

    class FakeKernel32(object):
        def OpenProcess(self, access, inherit, pid):
            return 0

        def GetLastError(self):
            return 5

    fake_windll = types.SimpleNamespace(kernel32=FakeKernel32())
    monkeypatch.setattr(json_io.os, 'name', 'nt', raising=False)
    monkeypatch.setattr(ctypes, 'windll', fake_windll, raising=False)
    assert json_io._pid_alive(4242) is True


def test_lock_not_stale_when_windows_pid_probe_denies_open(monkeypatch, tmp_path):
    lock_path = str(tmp_path / 'z.json.lock')
    with open(lock_path, 'w', encoding='utf-8') as handle:
        handle.write(
            json.dumps(
                {'pid': 777, 'created_at': time.time(), 'artifact': 't'},
                ensure_ascii=True,
            )
        )

    class FakeKernel32(object):
        def OpenProcess(self, access, inherit, pid):
            return 0

        def GetLastError(self):
            return 5

    fake_windll = types.SimpleNamespace(kernel32=FakeKernel32())
    monkeypatch.setattr(json_io.os, 'name', 'nt', raising=False)
    monkeypatch.setattr(ctypes, 'windll', fake_windll, raising=False)
    assert json_io._lock_is_stale(lock_path) is False


def test_append_jsonl_and_rotate(tmp_path):
    jl = str(tmp_path / 'ev.jsonl')
    assert json_io.append_jsonl(jl, {'x': 1}, 'a', 'w', lock=False)
    assert json_io.append_jsonl(jl, {'x': 2}, 'a', 'w', lock=False)
    assert json_io.rotate_jsonl_tail(jl, 1, 'a', 'w')
    lines = open(jl, 'r', encoding='utf-8').read().strip().splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0])['x'] == 2


def test_update_json_uses_atomic(tmp_path, monkeypatch):
    cfg = str(tmp_path / 'config.json')
    with open(cfg, 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'old'}, handle)
    csv_path = tmp_path / 'new.csv'
    csv_path.write_text(
        'Surgery Date,Patient ID,Patient Last,Patient First\n'
        '05/12/2026,12345,Doe,Jane\n',
        encoding='utf-8',
    )

    calls = []
    real_write = json_io.write_json_atomic

    def fake_atomic(path, payload, artifact, writer, **kwargs):
        calls.append((artifact, writer, path))
        kw = dict(kwargs)
        kw['lock'] = False
        return real_write(path, payload, artifact, writer, **kw)

    monkeypatch.setattr('MediCafe.json_io.write_json_atomic', fake_atomic)
    import importlib

    import MediBot.update_json as update_json_mod

    importlib.reload(update_json_mod)

    update_json_mod.update_csv_path(cfg, str(csv_path))
    assert calls and calls[0][0] == 'config_local' and calls[0][1] == 'update_json'
    local_sidecar = tmp_path / 'config.local.json'
    with open(str(local_sidecar), 'r', encoding='utf-8') as handle:
        data = json.load(handle)
    assert 'new.csv' in str(data.get('CSV_FILE_PATH', ''))


def test_update_json_rejects_non_intake_csv_file_path(tmp_path):
    cfg = str(tmp_path / 'config.json')
    with open(cfg, 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'old'}, handle)
    action_csv = tmp_path / 'action.csv'
    action_csv.write_text(
        'category,patient_id,dos,payer_id,claim_key,claim_number,detail,next_action\n'
        'reply,12345,05/12/2026,87726,k,c,missing,review\n',
        encoding='utf-8',
    )

    import importlib
    import MediBot.update_json as update_json_mod

    importlib.reload(update_json_mod)

    with pytest.raises(SystemExit):
        update_json_mod.update_csv_path(cfg, str(action_csv))

    assert not (tmp_path / 'config.local.json').exists()


def test_bootstrap_sidecars_dry_run_and_apply(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    report_path = tmp_path / 'bootstrap-report.json'

    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'old.csv', 'MediLink_Config': {'local_storage_path': 'store'}}, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}, 'optum_payer_list': {'metadata': {'last_update': 'old'}, 'payers': {}}}, handle)

    dry_report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=False, report_path=str(report_path))
    assert '$/CSV_FILE_PATH' in dry_report['moved']['config']
    assert '$/optum_payer_list' in dry_report['moved']['crosswalk']
    assert not (tmp_path / 'config.local.json').exists()

    apply_report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True, report_path=str(report_path))
    assert (tmp_path / 'config.local.json').exists()
    assert (tmp_path / 'crosswalk.state.json').exists()
    assert apply_report['backups']

    with open(str(config_path), 'r', encoding='utf-8') as handle:
        config_disk = json.load(handle)
    with open(str(crosswalk_path), 'r', encoding='utf-8') as handle:
        crosswalk_disk = json.load(handle)
    assert 'CSV_FILE_PATH' not in config_disk
    assert 'optum_payer_list' not in crosswalk_disk

    second_report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True, report_path=str(report_path))
    assert (tmp_path / 'config.local.json').exists()
    assert (tmp_path / 'crosswalk.state.json').exists()

    with open(str(config_path), 'r', encoding='utf-8') as handle:
        config_disk_second = json.load(handle)
    with open(str(crosswalk_path), 'r', encoding='utf-8') as handle:
        crosswalk_disk_second = json.load(handle)
    assert config_disk_second == config_disk
    assert crosswalk_disk_second == crosswalk_disk
    assert second_report['backups'] == []
    assert not any(second_report.get('planned_writes', {}).values())


def test_bootstrap_sidecars_apply_preserves_existing_sidecar_values(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    config_local_path = tmp_path / 'config.local.json'
    crosswalk_state_path = tmp_path / 'crosswalk.state.json'

    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({
            'CSV_FILE_PATH': 'stale-baseline.csv',
            'MAPAT_MED_PATH': 'baseline-only-mapat',
            'MediLink_Config': {
                'local_storage_path': 'stale-store',
                'endpoints': {
                    'AVAILITY': {
                        'client_id': 'baseline-client',
                        'client_secret': 'stale-secret',
                    },
                },
            },
        }, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({
            'payer_id': {},
            'optum_payer_list': {
                'metadata': {'last_update': 'stale'},
                'payers': {'old': {'search_claim': False}},
            },
            'routing_overrides': {'payers': {'old': {'claim_submission': {'preferred_endpoint': 'OLD'}}}},
        }, handle)
    with open(str(config_local_path), 'w', encoding='utf-8') as handle:
        json.dump({
            '__sidecar__': {'schema_version': 1},
            'CSV_FILE_PATH': 'fresh-sidecar.csv',
            'MediLink_Config': {
                'endpoints': {
                    'AVAILITY': {
                        'client_secret': 'fresh-secret',
                    },
                },
            },
        }, handle)
    with open(str(crosswalk_state_path), 'w', encoding='utf-8') as handle:
        json.dump({
            '__sidecar__': {'schema_version': 1},
            'optum_payer_list': {
                'metadata': {'last_update': 'fresh'},
                'payers': {'new': {'search_claim': True}},
            },
        }, handle)

    report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True)
    assert report['existing_sidecars']['config_local']['exists'] is True
    assert report['existing_sidecars']['crosswalk_state']['exists'] is True

    config_state, _cfg_diag = sidecar.read_sidecar_file(str(config_local_path))
    crosswalk_state, _cw_diag = sidecar.read_sidecar_file(str(crosswalk_state_path))
    assert config_state['CSV_FILE_PATH'] == 'fresh-sidecar.csv'
    assert config_state['MAPAT_MED_PATH'] == 'baseline-only-mapat'
    endpoint = config_state['MediLink_Config']['endpoints']['AVAILITY']
    assert endpoint['client_secret'] == 'fresh-secret'
    assert crosswalk_state['optum_payer_list']['metadata']['last_update'] == 'fresh'
    assert 'new' in crosswalk_state['optum_payer_list']['payers']
    assert crosswalk_state['routing_overrides']['payers']['old']['claim_submission']['preferred_endpoint'] == 'OLD'

    with open(str(config_path), 'r', encoding='utf-8') as handle:
        config_baseline = json.load(handle)
    with open(str(crosswalk_path), 'r', encoding='utf-8') as handle:
        crosswalk_baseline = json.load(handle)
    assert 'CSV_FILE_PATH' not in config_baseline
    assert 'MAPAT_MED_PATH' not in config_baseline
    assert 'client_secret' not in config_baseline.get('MediLink_Config', {}).get('endpoints', {}).get('AVAILITY', {})
    assert 'optum_payer_list' not in crosswalk_baseline
    assert 'routing_overrides' not in crosswalk_baseline


def test_loader_diagnostics_clear_after_scrub_and_return_on_reintroduced_baseline_state(tmp_path, monkeypatch):
    from MediCafe import json_sidecar as sidecar
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'legacy.csv', 'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}, 'optum_payer_list': {'metadata': {'last_update': 'old'}, 'payers': {}}}, handle)

    sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True)

    loader.clear_config_cache()
    loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = loader.get_last_load_diagnostics()
    stale = diagnostics.get('stale_state_owned_in_baseline') or {}
    assert diagnostics.get('overall_status') == 'ok'
    assert stale.get('config_count') == 0
    assert stale.get('crosswalk_count') == 0

    with open(str(config_path), 'r', encoding='utf-8') as handle:
        baseline = json.load(handle)
    baseline['CSV_FILE_PATH'] = 'reintroduced.csv'
    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump(baseline, handle)

    monkeypatch.setenv('MEDICAFE_JSON_SIDECAR_AUTO_SCRUB', '0')
    loader.clear_config_cache()
    loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = loader.get_last_load_diagnostics()
    stale = diagnostics.get('stale_state_owned_in_baseline') or {}
    assert diagnostics.get('overall_status') == 'degraded'
    assert stale.get('config_count', 0) >= 1
    assert '$/CSV_FILE_PATH' in (stale.get('config_state_owned_pointers') or [])


def test_loader_auto_scrubs_state_owned_baseline_and_leaves_backups(tmp_path):
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    config_local_path = tmp_path / 'config.local.json'
    crosswalk_state_path = tmp_path / 'crosswalk.state.json'
    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({
            'CSV_FILE_PATH': 'stale-baseline.csv',
            'MediLink_Config': {'local_storage_path': 'stale-store'},
        }, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({
            'payer_id': {},
            'optum_payer_list': {'metadata': {'last_update': 'stale'}, 'payers': {}},
        }, handle)
    with open(str(config_local_path), 'w', encoding='utf-8') as handle:
        json.dump({
            '__sidecar__': {'schema_version': 1},
            'CSV_FILE_PATH': 'fresh-sidecar.csv',
            'MediLink_Config': {'local_storage_path': str(tmp_path)},
        }, handle)
    with open(str(crosswalk_state_path), 'w', encoding='utf-8') as handle:
        json.dump({
            '__sidecar__': {'schema_version': 1},
            'optum_payer_list': {
                'metadata': {'last_update': 'fresh'},
                'payers': {'87726': {'search_claim': True}},
            },
        }, handle)

    loader.clear_config_cache()
    config, crosswalk = loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = loader.get_last_load_diagnostics()
    auto_scrub = diagnostics.get('auto_sidecar_scrub') or {}
    assert auto_scrub.get('status') == 'applied'
    assert auto_scrub.get('verified') is True
    assert diagnostics.get('overall_status') == 'ok'
    assert config['CSV_FILE_PATH'] == 'fresh-sidecar.csv'
    assert crosswalk['optum_payer_list']['metadata']['last_update'] == 'fresh'

    with open(str(config_path), 'r', encoding='utf-8') as handle:
        baseline_config = json.load(handle)
    with open(str(crosswalk_path), 'r', encoding='utf-8') as handle:
        baseline_crosswalk = json.load(handle)
    assert 'CSV_FILE_PATH' not in baseline_config
    assert baseline_config.get('MediLink_Config') == {}
    assert 'optum_payer_list' not in baseline_crosswalk

    backup_sources = [item.get('source') for item in auto_scrub.get('backups') or []]
    assert os.path.abspath(str(config_path)) in backup_sources
    assert os.path.abspath(str(crosswalk_path)) in backup_sources
    assert os.path.abspath(str(config_local_path)) not in backup_sources
    assert os.path.abspath(str(crosswalk_state_path)) not in backup_sources
    for item in auto_scrub.get('backups') or []:
        assert os.path.exists(item.get('dated_backup'))
        assert os.path.exists(item.get('latest_backup'))
        assert item.get('dated_backup') != item.get('latest_backup')
        assert item.get('latest_backup').endswith('.backup')


def test_loader_auto_scrub_repairs_missing_config_root_when_sidecar_is_valid(tmp_path):
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    config_local_path = tmp_path / 'config.local.json'
    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({}, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)
    with open(str(config_local_path), 'w', encoding='utf-8') as handle:
        json.dump({
            '__sidecar__': {'schema_version': 1},
            'MediLink_Config': {'local_storage_path': str(tmp_path)},
        }, handle)

    loader.clear_config_cache()
    config, _crosswalk = loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = loader.get_last_load_diagnostics()
    assert diagnostics.get('overall_status') == 'ok'
    assert (diagnostics.get('auto_sidecar_scrub') or {}).get('status') == 'applied'
    assert config['MediLink_Config']['local_storage_path'] == str(tmp_path)
    with open(str(config_path), 'r', encoding='utf-8') as handle:
        baseline = json.load(handle)
    assert baseline.get('MediLink_Config') == {}


def test_bootstrap_sidecars_backups_are_rollback_viable(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    original_config = {'CSV_FILE_PATH': 'orig.csv', 'MediLink_Config': {'local_storage_path': 'store'}}
    original_crosswalk = {'payer_id': {}, 'optum_payer_list': {'metadata': {'last_update': 'old'}, 'payers': {}}}

    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump(original_config, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump(original_crosswalk, handle)

    report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True)
    assert report['backups']

    backup_map = {}
    for path in report['backups']:
        if 'config.json.sidecar-bootstrap.' in path:
            backup_map['config'] = path
        if 'crosswalk.json.sidecar-bootstrap.' in path:
            backup_map['crosswalk'] = path
    assert os.path.exists(backup_map['config'])
    assert os.path.exists(backup_map['crosswalk'])

    with open(backup_map['config'], 'r', encoding='utf-8') as handle:
        assert json.load(handle) == original_config
    with open(backup_map['crosswalk'], 'r', encoding='utf-8') as handle:
        assert json.load(handle) == original_crosswalk


def test_bootstrap_sidecars_prunes_old_timestamped_backups(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'orig.csv', 'MediLink_Config': {'local_storage_path': 'store'}}, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)

    old_backups = []
    for idx, stamp in enumerate(['20200101_000001', '20200101_000002', '20200101_000003']):
        backup_path = str(config_path) + '.sidecar-bootstrap.' + stamp
        with open(backup_path, 'w', encoding='utf-8') as handle:
            handle.write('old backup {}'.format(idx))
        old_time = time.time() - (300 - idx)
        os.utime(backup_path, (old_time, old_time))
        old_backups.append(backup_path)

    report = sidecar.bootstrap_sidecars(str(config_path), str(crosswalk_path), apply=True)

    remaining = [
        name for name in os.listdir(str(tmp_path))
        if name.startswith('config.json.sidecar-bootstrap.')
    ]
    assert len(remaining) == sidecar.SIDECAR_BACKUP_RETENTION_COUNT
    assert os.path.abspath(old_backups[0]) in report.get('pruned_backups', [])
    assert not os.path.exists(old_backups[0])


def test_auto_scrub_prunes_old_timestamped_backups_but_keeps_latest_copy(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    config_local_path = tmp_path / 'config.local.json'
    with open(str(config_path), 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'stale.csv', 'MediLink_Config': {'local_storage_path': 'stale'}}, handle)
    with open(str(crosswalk_path), 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)
    with open(str(config_local_path), 'w', encoding='utf-8') as handle:
        json.dump({
            '__sidecar__': {'schema_version': 1},
            'CSV_FILE_PATH': 'fresh.csv',
            'MediLink_Config': {'local_storage_path': str(tmp_path)},
        }, handle)

    old_backups = []
    for idx, stamp in enumerate(['20200101_000001', '20200101_000002', '20200101_000003']):
        backup_path = str(config_path) + '.backup.' + stamp
        with open(backup_path, 'w', encoding='utf-8') as handle:
            handle.write('old backup {}'.format(idx))
        old_time = time.time() - (300 - idx)
        os.utime(backup_path, (old_time, old_time))
        old_backups.append(backup_path)
    latest_path = str(config_path) + '.backup'
    with open(latest_path, 'w', encoding='utf-8') as handle:
        handle.write('latest copy')

    report = sidecar.auto_scrub_baselines_if_safe(str(config_path), str(crosswalk_path))

    remaining = [
        name for name in os.listdir(str(tmp_path))
        if name.startswith('config.json.backup.')
    ]
    assert report.get('status') == 'applied'
    assert len(remaining) == sidecar.SIDECAR_BACKUP_RETENTION_COUNT
    assert os.path.exists(latest_path)
    assert os.path.abspath(old_backups[0]) in report.get('pruned_backups', [])
    assert not os.path.exists(old_backups[0])


def test_save_crosswalk_drops_state_owned_subtrees(tmp_path, monkeypatch):
    from MediBot import MediBot_Crosswalk_Utils as crosswalk_utils
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    crosswalk_path = str(tmp_path / 'crosswalk.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)

    loader.clear_config_cache()
    loader.load_configuration(config_path, crosswalk_path)
    config = {'MediLink_Config': {'endpoints': {}, 'crosswalkPath': crosswalk_path}}
    crosswalk = {
        'payer_id': {'12345': {'endpoint': 'AVAILITY', 'medisoft_id': [], 'medisoft_medicare_id': []}},
        'optum_payer_list': {'metadata': {'last_update': 'today'}, 'payers': {'87726': {'search_claim': True}}},
    }
    assert crosswalk_utils.save_crosswalk(None, config, crosswalk, skip_api_operations=True) is True

    with open(crosswalk_path, 'r', encoding='utf-8') as handle:
        saved = json.load(handle)
    assert 'optum_payer_list' not in saved
    state_path = tmp_path / 'crosswalk.state.json'
    with open(str(state_path), 'r', encoding='utf-8') as handle:
        state_doc = json.load(handle)
    assert state_doc['optum_payer_list'] == crosswalk['optum_payer_list']


def test_write_crosswalk_state_optum_writes_crosswalk_state_sidecar(tmp_path):
    from MediCafe import json_sidecar as sidecar

    config_path = str(tmp_path / 'config.json')
    crosswalk_path = str(tmp_path / 'crosswalk.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)

    payload = {'metadata': {'last_update': 'today'}, 'payers': {'87726': {'search_claim': True}}}
    ok, written_path = sidecar.write_crosswalk_state_optum(
        config_path,
        crosswalk_path,
        payload,
        writer='pytest',
    )

    assert ok is True
    assert written_path.endswith('crosswalk.state.json')
    with open(written_path, 'r', encoding='utf-8') as handle:
        state_doc = json.load(handle)
    assert state_doc['__sidecar__']['artifact'] == 'crosswalk_state'
    assert state_doc['optum_payer_list'] == payload


def test_save_crosswalk_state_optum_writes_optum_payload_to_sidecar(tmp_path):
    from MediBot import MediBot_Crosswalk_Utils as crosswalk_utils
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    crosswalk_path = str(tmp_path / 'crosswalk.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w', encoding='utf-8') as handle:
        json.dump({'payer_id': {}}, handle)

    loader.clear_config_cache()
    loader.load_configuration(config_path, crosswalk_path)
    config = {'MediLink_Config': {'endpoints': {}, 'crosswalkPath': crosswalk_path}}
    crosswalk = {
        'payer_id': {},
        'optum_payer_list': {
            'metadata': {'last_update': 'today'},
            'payers': {'87726': {'search_claim': True}},
        },
    }

    ok, state_path = crosswalk_utils.save_crosswalk_state_optum(config, crosswalk)

    assert ok is True
    assert state_path.endswith('crosswalk.state.json')
    with open(state_path, 'r', encoding='utf-8') as handle:
        state_doc = json.load(handle)
    assert state_doc['optum_payer_list'] == crosswalk['optum_payer_list']


def test_client_secret_update_writes_endpoint_secret_to_config_local_sidecar(tmp_path):
    from MediBot import client_secret_update
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'endpoints': {}}}, handle)

    endpoint_payload = {
        'client_id': 'abc123',
        'client_secret': 'secret-value',
        'client_secret_last_updated': '2026-04-16T12:00:00',
    }

    ok, error = client_secret_update.save_endpoint_secret(config_path, 'AVAILITY', endpoint_payload)

    assert ok is True
    assert error is None
    sidecar_path = tmp_path / 'config.local.json'
    assert sidecar_path.exists()
    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        saved = json.load(handle)
    assert saved['MediLink_Config']['endpoints']['AVAILITY']['client_secret'] == 'secret-value'
    assert saved['MediLink_Config']['endpoints']['AVAILITY']['client_secret_last_updated'] == '2026-04-16T12:00:00'
    assert 'client_id' not in saved['MediLink_Config']['endpoints']['AVAILITY']

    loader.clear_config_cache()
    loaded_config, _ = loader.load_configuration(
        config_path=str(config_path),
        crosswalk_path=str(tmp_path / 'crosswalk.json'),
    )
    assert loaded_config['MediLink_Config']['endpoints']['AVAILITY']['client_secret'] == 'secret-value'


def test_client_secret_update_skips_missing_timestamp_leaf(tmp_path):
    from MediBot import client_secret_update

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'endpoints': {}}}, handle)

    endpoint_payload = {
        'client_secret': 'secret-no-ts',
    }

    ok, error = client_secret_update.save_endpoint_secret(config_path, 'AVAILITY', endpoint_payload)
    assert ok is True
    assert error is None

    sidecar_path = tmp_path / 'config.local.json'
    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        saved = json.load(handle)
    endpoint_saved = saved['MediLink_Config']['endpoints']['AVAILITY']
    assert endpoint_saved['client_secret'] == 'secret-no-ts'
    assert 'client_secret_last_updated' not in endpoint_saved


def test_update_certificate_provider_config_writes_config_local_sidecar(tmp_path):
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)

    success, error = loader.update_certificate_provider_config(
        {'mode': 'managed_ca', 'enabled': True},
        config_path=config_path,
    )

    assert success is True
    assert error is None
    sidecar_path = tmp_path / 'config.local.json'
    assert sidecar_path.exists()
    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        saved = json.load(handle)
    assert saved['MediLink_Config']['certificate_provider']['mode'] == 'managed_ca'
    assert saved['MediLink_Config']['certificate_provider']['enabled'] is True

    loader.clear_config_cache()
    loaded_config, _ = loader.load_configuration(
        config_path=str(config_path),
        crosswalk_path=str(tmp_path / 'crosswalk.json'),
    )
    assert loaded_config['MediLink_Config']['certificate_provider']['mode'] == 'managed_ca'
    assert loaded_config['MediLink_Config']['certificate_provider']['enabled'] is True


def test_config_editor_save_routes_state_owned_keys_to_config_local(tmp_path):
    from MediBot import config_editor_helpers

    config_path = str(tmp_path / 'config.json')
    payload = {
        'CSV_FILE_PATH': 'from-editor.csv',
        'MediLink_Config': {
            'local_storage_path': str(tmp_path),
            'endpoints': {
                'AVAILITY': {
                    'client_id': 'abc',
                    'client_secret': 'secret-value',
                }
            },
        },
    }

    ok, error = config_editor_helpers.save_config_atomic(config_path, payload)
    assert ok is True
    assert error is None

    with open(config_path, 'r', encoding='utf-8') as handle:
        baseline = json.load(handle)
    assert 'CSV_FILE_PATH' not in baseline
    assert 'client_secret' not in baseline.get('MediLink_Config', {}).get('endpoints', {}).get('AVAILITY', {})

    sidecar_path = tmp_path / 'config.local.json'
    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        sidecar = json.load(handle)
    assert sidecar.get('CSV_FILE_PATH') == 'from-editor.csv'
    assert sidecar['MediLink_Config']['endpoints']['AVAILITY']['client_secret'] == 'secret-value'


def test_config_editor_save_preserves_existing_sidecar_secrets(tmp_path):
    from MediBot import config_editor_helpers

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'legacy.csv', 'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)

    sidecar_path = tmp_path / 'config.local.json'
    with open(str(sidecar_path), 'w', encoding='utf-8') as handle:
        json.dump({
            '__sidecar__': {'schema_version': 1},
            'MediLink_Config': {
                'endpoints': {
                    'AVAILITY': {
                        'client_secret': 'kept-secret',
                        'client_secret_last_updated': '2026-01-01T00:00:00',
                    }
                }
            },
        }, handle)

    baseline_only_payload = {'MediLink_Config': {'local_storage_path': str(tmp_path), 'logging': {'level': 'INFO'}}}
    ok, error = config_editor_helpers.save_config_atomic(config_path, baseline_only_payload)
    assert ok is True
    assert error is None

    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        sidecar = json.load(handle)
    assert sidecar['MediLink_Config']['endpoints']['AVAILITY']['client_secret'] == 'kept-secret'


def test_config_editor_sidecar_failure_keeps_baseline_unchanged(tmp_path, monkeypatch):
    from MediBot import config_editor_helpers

    config_path = str(tmp_path / 'config.json')
    original = {'CSV_FILE_PATH': 'legacy.csv', 'MediLink_Config': {'local_storage_path': str(tmp_path)}}
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump(original, handle)

    def _fail_sidecar(*_args, **_kwargs):
        return False, 'simulated-sidecar-failure'

    monkeypatch.setattr(config_editor_helpers.json_sidecar, 'write_config_local_document', _fail_sidecar)
    ok, error = config_editor_helpers.save_config_atomic(config_path, {'CSV_FILE_PATH': 'new.csv', 'MediLink_Config': {'local_storage_path': str(tmp_path)}})
    assert ok is False
    assert 'simulated-sidecar-failure' in str(error)

    with open(config_path, 'r', encoding='utf-8') as handle:
        after = json.load(handle)
    assert after == original


def test_config_editor_reports_partial_apply_risk_when_baseline_write_fails(tmp_path, monkeypatch):
    from MediBot import config_editor_helpers

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'legacy.csv', 'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)

    def _ok_sidecar(*_args, **_kwargs):
        return True, str(tmp_path / 'config.local.json')

    def _fail_mkstemp(*_args, **_kwargs):
        raise OSError('simulated-baseline-write-failure')

    monkeypatch.setattr(config_editor_helpers.json_sidecar, 'write_config_local_document', _ok_sidecar)
    monkeypatch.setattr(config_editor_helpers.tempfile, 'mkstemp', _fail_mkstemp)

    ok, error = config_editor_helpers.save_config_atomic(
        config_path,
        {'CSV_FILE_PATH': 'new.csv', 'MediLink_Config': {'local_storage_path': str(tmp_path)}},
    )
    assert ok is False
    assert 'Sidecar changes may already be applied' in str(error)


def test_preflight_json_io_passes_with_writable_dirs(tmp_path):
    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)
    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': str(tmp_path),
        'source_folder': str(tmp_path),
        'target_folder': str(tmp_path),
    }
    fails = json_io.collect_json_io_preflight_failures(ctx)
    assert fails == []


def test_preflight_detects_readonly_file(tmp_path):
    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)
    os.chmod(config_path, 0o444)
    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': str(tmp_path),
        'source_folder': str(tmp_path),
        'target_folder': str(tmp_path),
    }
    try:
        fails = json_io.collect_json_io_preflight_failures(ctx)
        if hasattr(os, 'geteuid') and os.geteuid() == 0:
            # Root can bypass Unix mode-bit writability checks, so assert that the
            # probe executed rather than requiring a permission-denied failure.
            assert isinstance(fails, list)
        else:
            assert any('r+ probe' in f for f in fails)
    finally:
        os.chmod(config_path, 0o644)


def test_telemetry_probe_candidates_readonly_does_not_call_queue_resolver(tmp_path, monkeypatch):
    import MediCafe.error_reporter as error_reporter

    called = {'resolve_queue_dir': False}
    sentinel = os.path.join(str(tmp_path), 'created_by_resolver')

    def creating_resolver(medi):
        called['resolve_queue_dir'] = True
        os.makedirs(sentinel)
        return os.path.join(sentinel, 'reports_queue')

    monkeypatch.setattr(error_reporter, '_resolve_queue_dir', creating_resolver)
    local_storage = os.path.join(str(tmp_path), 'storage')
    os.makedirs(local_storage)

    candidates = json_io._telemetry_probe_candidates_readonly(
        os.path.join(str(tmp_path), 'config.json'),
        local_storage,
    )

    assert called['resolve_queue_dir'] is False
    assert os.path.join(local_storage, 'telemetry') in candidates
    assert not os.path.exists(sentinel)


def test_preflight_does_not_create_optional_telemetry_dirs(tmp_path, monkeypatch):
    import MediCafe.error_reporter as error_reporter

    def creating_resolver(medi):
        os.makedirs(os.path.join(str(tmp_path), 'reports_queue_created'))
        return os.path.join(str(tmp_path), 'reports_queue_created')

    monkeypatch.setattr(error_reporter, '_resolve_queue_dir', creating_resolver)

    config_path = os.path.join(str(tmp_path), 'config.json')
    crosswalk_path = os.path.join(str(tmp_path), 'crosswalk.json')
    local_storage = os.path.join(str(tmp_path), 'storage')
    os.makedirs(local_storage)
    with open(config_path, 'w') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': local_storage}}, handle)
    with open(crosswalk_path, 'w') as handle:
        json.dump({}, handle)

    ctx = {
        'config_path': config_path,
        'crosswalk_path': crosswalk_path,
        'local_storage_path': local_storage,
        'source_folder': local_storage,
        'target_folder': local_storage,
    }
    fails = json_io.collect_json_io_preflight_failures(ctx)

    assert fails == []
    assert not os.path.exists(os.path.join(local_storage, 'telemetry'))
    assert not os.path.exists(os.path.join(str(tmp_path), 'reports_queue_created'))


def test_json_io_event_reaches_root_logger():
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level
    try:
        for old in old_handlers:
            root.removeHandler(old)
        root.addHandler(handler)
        root.setLevel(logging.INFO)

        json_io._emit_json_io_event({'phase': 'success', 'artifact': 'test', 'writer': 'pytest'})
        handler.flush()
    finally:
        root.removeHandler(handler)
        for old in old_handlers:
            root.addHandler(old)
        root.setLevel(old_level)

    logged = stream.getvalue()
    if 'JSON_IO_EVENT' not in logged:
        # Some environments route these through fallback stderr emission only.
        assert logged == ''
    else:
        assert '"phase": "success"' in logged


def test_json_io_event_does_not_write_raw_payload_to_stderr_by_default(monkeypatch, capsys):
    monkeypatch.delenv('MEDICAFE_JSON_IO_CONSOLE', raising=False)

    json_io._emit_json_io_event({
        'phase': 'promote_failed',
        'artifact': 'support_send_queue',
        'writer': 'pytest',
        'path_basename': 'support_send_jobs.json',
    })
    json_io._emit_json_io_diagnostic({
        'phase': 'dir_probe_replace_existing',
        'path_basename': 'support_send_jobs.json',
    })

    captured = capsys.readouterr()
    assert 'JSON_IO_EVENT' not in captured.err
    assert 'JSON_IO_DIAGNOSTIC' not in captured.err


def test_json_io_console_payloads_require_explicit_opt_in(monkeypatch, capsys):
    monkeypatch.setenv('MEDICAFE_JSON_IO_CONSOLE', '1')

    json_io._emit_json_io_event({
        'phase': 'promote_failed',
        'artifact': 'support_send_queue',
        'writer': 'pytest',
        'path_basename': 'support_send_jobs.json',
    })
    json_io._emit_json_io_diagnostic({
        'phase': 'dir_probe_replace_existing',
        'path_basename': 'support_send_jobs.json',
    })

    captured = capsys.readouterr()
    assert 'JSON_IO_EVENT' in captured.err
    assert 'JSON_IO_DIAGNOSTIC' in captured.err


def test_support_send_queue_write_failure_exception_omits_full_path(tmp_path, monkeypatch):
    import MediCafe.support_send_jobs as support_send_jobs

    path = os.path.join(str(tmp_path), 'reports', 'support_send_jobs.json')

    def fail_write(*_args, **_kwargs):
        return False

    monkeypatch.setattr(json_io, 'write_json_atomic', fail_write)

    with pytest.raises(IOError) as exc_info:
        support_send_jobs._json_dump_atomic(path, {'queued_job_ids': []})

    message = str(exc_info.value)
    assert 'support_send_queue_write_failed' in message
    assert 'support_send_jobs.json' in message
    assert str(tmp_path) not in message


def test_probe_directory_io_detects_replace_existing_failure(tmp_path, monkeypatch):
    real_replace = os.replace

    def fail_probe_replace(src, dst):
        if '.medicafe_json_io_probe.' in str(dst):
            raise OSError(17, 'file exists')
        return real_replace(src, dst)

    monkeypatch.setattr(os, 'replace', fail_probe_replace)
    result = json_io.probe_directory_io(str(tmp_path), 'pytest_replace_probe')

    assert result['ok'] is False
    assert result['phase'] == 'dir_probe_replace_existing'
    assert result.get('errno') == 17
    assert 'diagnostics' in result


def test_json_io_diagnostic_reaches_root_logger(tmp_path):
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level
    try:
        for old in old_handlers:
            root.removeHandler(old)
        root.addHandler(handler)
        root.setLevel(logging.INFO)

        json_io._emit_failure_diagnostics(
            str(tmp_path / 'config.json'),
            'config',
            'pytest',
            'promote_failed',
            exc=OSError(17, 'file exists'),
        )
        handler.flush()
    finally:
        root.removeHandler(handler)
        for old in old_handlers:
            root.addHandler(old)
        root.setLevel(old_level)

    logged = stream.getvalue()
    assert 'JSON_IO_DIAGNOSTIC' in logged
    assert 'promote_failed' in logged
    assert 'path_diagnostics' in logged


def test_collect_path_diagnostics_reports_readonly_file(tmp_path):
    path = str(tmp_path / 'readonly.json')
    with open(path, 'w') as handle:
        handle.write('{}')
    os.chmod(path, 0o444)
    try:
        diag = json_io.collect_path_diagnostics(path)
        if hasattr(os, 'geteuid') and os.geteuid() == 0:
            assert 'target_readonly' in diag
        else:
            assert diag.get('target_readonly') is True
            assert diag.get('target_readonly_summary') == 'read-only or not writable'
    finally:
        os.chmod(path, 0o644)


def test_update_json_roundtrip_get_current_csv_path_reads_effective_sidecar_value(tmp_path):
    from MediBot import update_json as update_json_mod
    from MediCafe import MediLink_ConfigLoader as loader

    cfg = str(tmp_path / 'config.json')
    with open(cfg, 'w', encoding='utf-8') as handle:
        json.dump({'CSV_FILE_PATH': 'old', 'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)
    csv_path = tmp_path / 'new.csv'
    csv_path.write_text(
        'Surgery Date,Patient ID,Patient Last,Patient First\n'
        '05/12/2026,12345,Doe,Jane\n',
        encoding='utf-8',
    )

    loader.clear_config_cache()
    update_json_mod.update_csv_path(cfg, str(csv_path))
    loader.clear_config_cache()

    got = update_json_mod.get_current_csv_path(cfg)
    assert got is not None
    assert 'new.csv' in str(got)


def test_process_csvs_load_config_reads_effective_sidecar_values(tmp_path):
    from MediBot import process_csvs
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    storage_path = str(tmp_path / 'storage')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {}}, handle)
    with open(str(tmp_path / 'crosswalk.json'), 'w', encoding='utf-8') as handle:
        json.dump({}, handle)
    with open(str(tmp_path / 'config.local.json'), 'w', encoding='utf-8') as handle:
        json.dump(
            {
                '__sidecar__': {'schema_version': 1},
                'CSV_FILE_PATH': str(tmp_path / 'sidecar.csv'),
                'MediLink_Config': {'local_storage_path': storage_path},
            },
            handle,
        )

    loader.clear_config_cache()
    cfg = process_csvs.load_config(config_path)
    assert cfg.get('CSV_FILE_PATH', '').endswith('sidecar.csv')
    assert cfg['MediLink_Config']['local_storage_path'] == storage_path


def test_process_csvs_intake_storage_resolver_reads_effective_sidecar_values(tmp_path):
    from MediBot import process_csvs
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    storage_path = str(tmp_path / 'storage')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {}}, handle)
    with open(str(tmp_path / 'crosswalk.json'), 'w', encoding='utf-8') as handle:
        json.dump({}, handle)
    with open(str(tmp_path / 'config.local.json'), 'w', encoding='utf-8') as handle:
        json.dump(
            {
                '__sidecar__': {'schema_version': 1},
                'MediLink_Config': {'local_storage_path': storage_path},
            },
            handle,
        )

    loader.clear_config_cache()
    assert process_csvs.resolve_csv_intake_local_storage(config_path) == storage_path


def test_migrate_browser_downloads_load_config_reads_effective_sidecar_values(tmp_path):
    from MediBot import migrate_browser_downloads
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    storage_path = str(tmp_path / 'storage')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {}}, handle)
    with open(str(tmp_path / 'crosswalk.json'), 'w', encoding='utf-8') as handle:
        json.dump({}, handle)
    with open(str(tmp_path / 'config.local.json'), 'w', encoding='utf-8') as handle:
        json.dump(
            {
                '__sidecar__': {'schema_version': 1},
                'CSV_FILE_PATH': str(tmp_path / 'sidecar.csv'),
                'MediLink_Config': {'local_storage_path': storage_path},
            },
            handle,
        )

    loader.clear_config_cache()
    cfg = migrate_browser_downloads.load_config(config_path)
    assert cfg.get('CSV_FILE_PATH', '').endswith('sidecar.csv')
    assert cfg['MediLink_Config']['local_storage_path'] == storage_path


def test_update_downloaded_email_load_config_reads_effective_sidecar_values(tmp_path):
    from MediBot import update_downloaded_email
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    storage_path = str(tmp_path / 'storage')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {}}, handle)
    with open(str(tmp_path / 'crosswalk.json'), 'w', encoding='utf-8') as handle:
        json.dump({}, handle)
    with open(str(tmp_path / 'config.local.json'), 'w', encoding='utf-8') as handle:
        json.dump(
            {
                '__sidecar__': {'schema_version': 1},
                'CSV_FILE_PATH': str(tmp_path / 'sidecar.csv'),
                'MediLink_Config': {'local_storage_path': storage_path},
            },
            handle,
        )

    loader.clear_config_cache()
    cfg = update_downloaded_email.load_config(config_path)
    assert cfg.get('CSV_FILE_PATH', '').endswith('sidecar.csv')
    assert cfg['MediLink_Config']['local_storage_path'] == storage_path


def test_launcher_config_snapshot_reads_effective_sidecar_values(tmp_path):
    from MediCafe.launcher import MediCafeOrchestrator
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    storage_path = str(tmp_path / 'storage')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {}}, handle)
    with open(str(tmp_path / 'crosswalk.json'), 'w', encoding='utf-8') as handle:
        json.dump({}, handle)
    with open(str(tmp_path / 'config.local.json'), 'w', encoding='utf-8') as handle:
        json.dump(
            {
                '__sidecar__': {'schema_version': 1},
                'MediLink_Config': {'local_storage_path': storage_path},
            },
            handle,
        )

    loader.clear_config_cache()
    orch = MediCafeOrchestrator.__new__(MediCafeOrchestrator)
    orch.environment = {'config_file': config_path}
    orch.repo_root = str(tmp_path)
    cfg = orch._load_launcher_config_snapshot()
    assert cfg['MediLink_Config']['local_storage_path'] == storage_path


def test_config_editor_load_config_safe_reads_effective_sidecar_values(tmp_path):
    from MediBot import config_editor_helpers
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path)}}, handle)

    sidecar_path = tmp_path / 'config.local.json'
    with open(str(sidecar_path), 'w', encoding='utf-8') as handle:
        json.dump(
            {
                '__sidecar__': {'schema_version': 1},
                'CSV_FILE_PATH': 'from-sidecar.csv',
                'MediLink_Config': {
                    'endpoints': {
                        'AVAILITY': {
                            'client_secret': 'sidecar-secret',
                            'client_secret_last_updated': '2026-01-01T00:00:00',
                        }
                    }
                },
            },
            handle,
        )

    loader.clear_config_cache()
    cfg, err = config_editor_helpers.load_config_safe(config_path)
    assert err is None
    assert cfg.get('CSV_FILE_PATH') == 'from-sidecar.csv'
    assert cfg['MediLink_Config']['endpoints']['AVAILITY']['client_secret'] == 'sidecar-secret'


def test_config_editor_save_preserves_sidecar_tombstones(tmp_path):
    from MediBot import config_editor_helpers
    from MediCafe import MediLink_ConfigLoader as loader

    config_path = str(tmp_path / 'config.json')
    with open(config_path, 'w', encoding='utf-8') as handle:
        json.dump({'MediLink_Config': {'local_storage_path': str(tmp_path), 'logFilePath': 'base.log'}}, handle)

    sidecar_path = tmp_path / 'config.local.json'
    with open(str(sidecar_path), 'w', encoding='utf-8') as handle:
        json.dump(
            {
                '__sidecar__': {'schema_version': 1},
                'MediLink_Config': {
                    'logFilePath': {'__tombstone__': True}
                },
            },
            handle,
        )

    loader.clear_config_cache()
    cfg, err = config_editor_helpers.load_config_safe(config_path)
    assert err is None
    # Tombstone should delete baseline value in the effective view.
    assert 'logFilePath' not in cfg.get('MediLink_Config', {})

    ok, error = config_editor_helpers.save_config_atomic(config_path, cfg)
    assert ok is True
    assert error is None

    with open(str(sidecar_path), 'r', encoding='utf-8') as handle:
        sidecar = json.load(handle)
    assert sidecar['MediLink_Config']['logFilePath'] == {'__tombstone__': True}
