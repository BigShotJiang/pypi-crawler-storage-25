# -*- coding: utf-8 -*-
"""Phase C autonomous report bundle attachments (runs under pytest tests/)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM_MODEL = os.path.join(_REPO_ROOT, 'scripts', 'unified_model')
if _UM_MODEL not in sys.path:
    sys.path.insert(0, _UM_MODEL)


class TestPhaseCFailureReportExtraFiles(unittest.TestCase):

    def test_submit_phase_c_failure_report_embedded_summary_separate_zip_name(self):
        import phase_c_auto_report as pcr

        lab_root = tempfile.mkdtemp(prefix='mc_pc_bundle_')
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            recovery_report = os.path.join(lab_root, 'phase_c_shadow_recovery_run-a.json')
            with open(recovery_report, 'w', encoding='utf-8') as f:
                json.dump({'status': 'completed'}, f)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({'last_phase_c_shadow_recovery_report_path': recovery_report}, f)
            report_json = os.path.join(lab_root, 'ingest_write_summary_written.json')
            with open(report_json, 'w', encoding='utf-8') as f:
                json.dump({'written': True}, f)
            summary_inline = {'manifest_run_id': 'mid-1', 'manifest_sha256': 'abc'}

            captured = []

            def _collect(include_traceback=False, extra_meta=None, extra_files=None, progress_callback=None, evidence_manifest=None):
                captured.append(list(extra_files or []))
                return os.path.join(lab_root, 'out.zip')

            with patch('MediCafe.error_reporter.report_dedup_try_reserve', return_value=(True, None)):
                with patch('MediCafe.error_reporter.report_dedup_release_if_failed'):
                    with patch('MediCafe.error_reporter.collect_support_bundle', side_effect=_collect):
                        with patch('MediCafe.error_reporter.submit_support_bundle_email', return_value=True):
                            pcr.submit_phase_c_failure_report(lab_root, {
                                    'error_code': 'TEST_ERR',
                                    'first_failed': 'row_a',
                                    'run_id': 'run-a',
                                    'lab_root': lab_root,
                                    'report_json_path': report_json,
                                    'summary': summary_inline,
                                })
            self.assertTrue(captured, 'collect_support_bundle was not invoked')
            names = [item[0] for item in captured[0]]
            self.assertEqual(names.count('ingest_write_summary.json'), 1)
            self.assertIn('ingest_write_summary_embedded.json', names)
            self.assertIn('phase_c_shadow_recovery_run-a.json', names)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_f_failed_phase_c_supplementals_include_current_attempt_and_smoke(self):
        from phase_e_auto_report import build_phase_f_bundle_supplemental_files

        lab_root = tempfile.mkdtemp(prefix='mc_pf_pc_bundle_')
        reports = os.path.join(lab_root, 'reports')
        try:
            os.makedirs(reports)
            c_rid = '20260101-000000-phasec'
            ingest_path = os.path.join(reports, 'ingest_write_summary_{0}.json'.format(c_rid))
            recovery_path = os.path.join(reports, 'phase_c_shadow_recovery_shadow-z.json')
            bootstrap_path = os.path.join(reports, 'ingest_from_manifest_bootstrap_latest.json')
            timeline_path = os.path.join(reports, 'ingest_from_manifest_bootstrap_timeline_latest.jsonl')
            attempt_path = os.path.join(reports, 'phase_c_current_attempt_latest.json')
            smoke_json_path = os.path.join(reports, 'xp_phase_smoke_latest.json')
            smoke_txt_path = os.path.join(reports, 'xp_phase_smoke_latest.txt')
            with open(ingest_path, 'w', encoding='utf-8') as f:
                json.dump({'run_id': c_rid, 'manifest_sha256': 'sha9', 'ok': False}, f)
            with open(recovery_path, 'w', encoding='utf-8') as f:
                json.dump({'status': 'completed'}, f)
            with open(bootstrap_path, 'w', encoding='utf-8') as f:
                json.dump({'schema_version': 1, 'stage': 'before_run_ingest'}, f)
            with open(timeline_path, 'w', encoding='utf-8') as f:
                f.write('{"schema_version":1,"stage":"before_run_ingest","stage_seq":1}\n')
            with open(attempt_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'schema_version': 1,
                    'phase_c_attempt_id': 'shadow-z-phase-c',
                    'current_blocker': 'phase_c_script_entered_but_no_finish_diag_current_attempt',
                }, f)
            with open(smoke_json_path, 'w', encoding='utf-8') as f:
                json.dump({'schema_version': 1, 'overall_status': 'blocked'}, f)
            with open(smoke_txt_path, 'w', encoding='utf-8') as f:
                f.write('XP Phase Smoke\n')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_phase_c_run_id': c_rid,
                    'last_phase_c_shadow_recovery_report_path': recovery_path,
                    'last_shadow_pipeline_phase_run_ids': {'C': c_rid},
                }, f)

            extras = build_phase_f_bundle_supplemental_files(lab_root, {
                'run_id': 'shadow-z',
                'failed_phase': 'C',
            })

            names = [pair[0] for pair in extras]
            self.assertIn(os.path.basename(ingest_path), names)
            self.assertIn(os.path.basename(recovery_path), names)
            self.assertIn(os.path.basename(bootstrap_path), names)
            self.assertIn(os.path.basename(timeline_path), names)
            self.assertIn(os.path.basename(attempt_path), names)
            self.assertIn(os.path.basename(smoke_json_path), names)
            self.assertIn(os.path.basename(smoke_txt_path), names)
            notes = [pair[1] for pair in extras if pair[0] == 'phase_f_bc_correlation_note.txt']
            self.assertEqual(len(notes), 1)
            self.assertIn('shadow-z', notes[0])
            self.assertIn('phase_c_failure_summary_attached=yes', notes[0])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
