import importlib
import subprocess
import sys
import types
from unittest.mock import patch

from cloud.orchestrator import setup_common


def _completed(returncode, stdout="", stderr=""):
    return subprocess.CompletedProcess(args=["gcloud"], returncode=returncode, stdout=stdout, stderr=stderr)


def test_ensure_cloud_build_logs_bucket_access_success_existing_bucket():
    with patch.object(setup_common, "_get_project_number", return_value="123456789"), \
         patch.object(setup_common, "_run", return_value=_completed(0)) as mock_run, \
         patch.object(setup_common, "_ensure_bucket_role_binding", return_value=(True, "")) as mock_bind:
        ok, msg = setup_common._ensure_cloud_build_logs_bucket_access(
            "demo-project",
            "us-central1",
            "builder@demo-project.iam.gserviceaccount.com",
        )

    assert ok is True
    assert msg == "gs://123456789-us-central1-cloudbuild-logs"
    assert mock_run.call_count == 1
    assert mock_run.call_args_list[0].args[0] == [
        "gcloud", "storage", "buckets", "describe", "gs://123456789-us-central1-cloudbuild-logs", "--project", "demo-project",
    ]
    mock_bind.assert_called_once_with(
        "gs://123456789-us-central1-cloudbuild-logs",
        "demo-project",
        "builder@demo-project.iam.gserviceaccount.com",
        "roles/storage.admin",
    )


def test_ensure_cloud_build_logs_bucket_access_creates_bucket_when_missing():
    with patch.object(setup_common, "_get_project_number", return_value="123456789"), \
         patch.object(setup_common, "_run", side_effect=[_completed(1, stderr="not found"), _completed(0)]) as mock_run, \
         patch.object(setup_common, "_ensure_bucket_role_binding", return_value=(True, "")) as mock_bind:
        ok, msg = setup_common._ensure_cloud_build_logs_bucket_access(
            "demo-project",
            "us-central1",
            "builder@demo-project.iam.gserviceaccount.com",
        )

    assert ok is True
    assert msg == "gs://123456789-us-central1-cloudbuild-logs"
    assert mock_run.call_count == 2
    assert mock_run.call_args_list[1].args[0] == [
        "gcloud", "storage", "buckets", "create", "gs://123456789-us-central1-cloudbuild-logs",
        "--project", "demo-project", "--location", "us-central1", "--uniform-bucket-level-access",
    ]
    mock_bind.assert_called_once()


def test_ensure_cloud_build_logs_bucket_access_returns_role_binding_failure():
    with patch.object(setup_common, "_get_project_number", return_value="123456789"), \
         patch.object(setup_common, "_run", return_value=_completed(0)), \
         patch.object(setup_common, "_ensure_bucket_role_binding", return_value=(False, "policy denied")):
        ok, msg = setup_common._ensure_cloud_build_logs_bucket_access(
            "demo-project",
            "us-central1",
            "builder@demo-project.iam.gserviceaccount.com",
        )

    assert ok is False
    assert msg == (
        "grant roles/storage.admin on gs://123456789-us-central1-cloudbuild-logs "
        "to builder@demo-project.iam.gserviceaccount.com: policy denied"
    )


def test_setup_flow_uses_setup_common_logs_bucket_helper():
    config_module = types.ModuleType("config")
    config_module.Config = object
    services_module = types.ModuleType("services")
    with patch.dict(sys.modules, {"config": config_module, "services": services_module}):
        setup_flow = importlib.import_module("cloud.orchestrator.setup_flow")

    assert setup_flow._ensure_cloud_build_logs_bucket_access is setup_common._ensure_cloud_build_logs_bucket_access
