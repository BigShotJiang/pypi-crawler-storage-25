# -*- coding: utf-8 -*-
"""Tests for support bundle_kind labeling (ZIP meta, email subject/body helpers)."""
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import time
import unittest
import zipfile

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from MediCafe import error_reporter as er
from MediCafe import MediLink_ConfigLoader as cfg_loader


class TestBundleKindResolution(unittest.TestCase):
    def test_resolve_explicit_override(self):
        self.assertEqual(
            er.resolve_bundle_kind({'bundle_kind': 'system_health_pack'}),
            'system_health_pack',
        )

    def test_resolve_run_evidence_flag(self):
        self.assertEqual(
            er.resolve_bundle_kind({'run_evidence_bundle': True}),
            'run_evidence_bundle',
        )

    def test_resolve_phase_d_evidence(self):
        self.assertEqual(
            er.resolve_bundle_kind({'phase_d_evidence': True}),
            'phase_d_evidence',
        )

    def test_resolve_phase_f_report_maps_to_phase_f_evidence(self):
        self.assertEqual(
            er.resolve_bundle_kind({'phase_f_report': True}),
            'phase_f_evidence',
        )

    def test_resolve_phase_e_failure_before_pipeline(self):
        meta = {'phase_e_failure': True, 'pipeline_failure': True}
        self.assertEqual(er.resolve_bundle_kind(meta), 'phase_e_pipeline_report')

    def test_resolve_claim_only(self):
        self.assertEqual(er.resolve_bundle_kind(None, claim_failure_summary=True), 'claim_submission_report')

    def test_default_error_report(self):
        self.assertEqual(er.resolve_bundle_kind(None), 'error_report')
        self.assertEqual(er.resolve_bundle_kind({}), 'error_report')

    def test_compose_subject_error_uses_prefix(self):
        s = er._compose_email_subject('error_report', 'MediCafe Error Report', '20250101_120000')
        self.assertIn('MediCafe Error Report', s)
        self.assertIn('20250101_120000', s)

    def test_compose_subject_health_strips_error_report_suffix(self):
        s = er._compose_email_subject('system_health_pack', 'MediCafe Error Report', '20250101_120000')
        self.assertIn('System Health Pack', s)
        self.assertNotIn('Error Report', s)
        self.assertIn('20250101_120000', s)

    def test_compose_subject_includes_run_id_and_send_source(self):
        s = er._compose_email_subject(
            'phase_f_evidence',
            'MediCafe Error Report',
            '20250101_120000',
            run_id='20260329-171213-1ccb1c51',
            send_source='manual_phase_f_evidence',
        )
        self.assertIn('run_id=20260329-171213-1ccb1c51', s)
        self.assertIn('source=manual_phase_f_evidence', s)

    def test_bundle_timestamp_suffix_from_zip_path_uses_attachment_build_time(self):
        self.assertEqual(
            er._bundle_timestamp_suffix_from_zip_path(
                r'C:\queue\medicafe_bundle_phase_f_evidence_20260501_165758.zip',
            ),
            '20260501_165758',
        )
        self.assertEqual(
            er._bundle_timestamp_suffix_from_zip_path(
                r'C:\queue\medicafe_bundle_system_health_pack_LITE_20260502_224408.zip',
            ),
            '20260502_224408',
        )

    def test_bundle_timestamp_suffix_from_zip_path_rejects_unknown_names(self):
        self.assertEqual(er._bundle_timestamp_suffix_from_zip_path(r'C:\queue\phase_f.zip'), '')

    def test_subject_context_from_meta_uses_extra_context_aliases(self):
        ctx = er._subject_context_from_meta_dict({
            'extra_context': {
                'artifact_run_id': '20260329-171213-1ccb1c51',
                'send_source': 'Manual Phase F Evidence',
            }
        })
        self.assertEqual(ctx.get('run_id'), '20260329-171213-1ccb1c51')
        self.assertEqual(ctx.get('send_source'), 'manual_phase_f_evidence')

    def test_read_subject_context_from_zip(self):
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
            zpath = tmp.name
        try:
            with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('meta.json', json.dumps({
                    'bundle_kind': 'phase_f_evidence',
                    'extra_context': {
                        'run_id': '20260329-171213-1ccb1c51',
                        'send_source': 'auto_phase_f_evidence',
                    },
                }))
            ctx = er._read_subject_context_from_zip(zpath)
            self.assertEqual(ctx.get('run_id'), '20260329-171213-1ccb1c51')
            self.assertEqual(ctx.get('send_source'), 'auto_phase_f_evidence')
        finally:
            try:
                os.remove(zpath)
            except OSError:
                pass

    def test_read_kind_from_zip(self):
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
            zpath = tmp.name
        try:
            with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('meta.json', json.dumps({'bundle_kind': 'phase_b_evidence'}))
            self.assertEqual(er._read_bundle_kind_from_zip(zpath), 'phase_b_evidence')
        finally:
            try:
                os.remove(zpath)
            except OSError:
                pass

    def test_build_support_zip_skips_duplicate_extra_file_names(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_dups_')
        try:
            report_json = os.path.join(store, 'qa_canonical_summary.json')
            with open(report_json, 'w') as f:
                json.dump({'source': 'file'}, f)
            zip_path = os.path.join(store, 'dup_bundle.zip')
            ok = er._build_support_zip(
                zip_path,
                store,
                10,
                '',
                False,
                {'bundle_kind': 'error_report'},
                None,
                [
                    ('qa_canonical_summary.json', report_json),
                    ('qa_canonical_summary.json', {'source': 'dict'}),
                    ('qa_canonical_summary.txt', 'ok'),
                ],
            )
            self.assertTrue(ok)
            with zipfile.ZipFile(zip_path, 'r') as zf:
                names = zf.namelist()
                self.assertEqual(names.count('qa_canonical_summary.json'), 1)
                self.assertEqual(names.count('qa_canonical_summary.txt'), 1)
                payload = json.loads(zf.read('qa_canonical_summary.json').decode('utf-8'))
                self.assertEqual(payload.get('source'), 'file')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_repack_lite_from_zip_preserves_kind_and_drops_heavy_members(self):
        store = tempfile.mkdtemp()
        try:
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                rq = os.path.join(store, 'reports_queue')
                os.makedirs(rq)
                src = os.path.join(store, 'src.zip')
                big = 'x' * 5000
                with zipfile.ZipFile(src, 'w', zipfile.ZIP_DEFLATED) as zf:
                    zf.writestr('meta.json', json.dumps({
                        'bundle_kind': 'system_health_pack',
                        'selected_log_archive_name': 'Log_04162026_run023.log',
                    }))
                    zf.writestr('evidence.txt', 'ok')
                    zf.writestr('Log_04162026_run023.log', big)
                    zf.writestr('traceback.txt', 'tb')
                out = er.repack_support_bundle_lite_from_zip(src)
                self.assertTrue(out and os.path.isfile(out))
                self.assertIn('system_health_pack', os.path.basename(out))
                with zipfile.ZipFile(out, 'r') as zf:
                    names = zf.namelist()
                    self.assertNotIn('Log_04162026_run023.log', names)
                    self.assertNotIn('traceback.txt', names)
                    self.assertIn('evidence.txt', names)
                    meta = json.loads(zf.read('meta.json').decode('utf-8'))
                    self.assertEqual(meta.get('bundle_kind'), 'system_health_pack')
                    self.assertTrue(meta.get('bundle_lite'))
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_merge_extra_meta_bundle_kind_from_zip(self):
        store = tempfile.mkdtemp()
        try:
            src = os.path.join(store, 'x.zip')
            with zipfile.ZipFile(src, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('meta.json', json.dumps({'bundle_kind': 'run_evidence_bundle'}))
            merged = er._merge_extra_meta_with_bundle_kind_from_zip(src, {})
            self.assertEqual(merged.get('bundle_kind'), 'run_evidence_bundle')
            merged2 = er._merge_extra_meta_with_bundle_kind_from_zip(src, {'bundle_kind': 'error_report'})
            self.assertEqual(merged2.get('bundle_kind'), 'error_report')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_uses_manifest_bundle_kind_without_extra_meta_flag(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_manifest_kind_')
        try:
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            manifest = {
                'schema_version': 1,
                'request': {'bundle_kind': 'system_health_pack', 'send_source': 'unit_test'},
                'scope': {'bundle_kind': 'system_health_pack', 'coherence_status': 'ready'},
                'validation': {'attachment_contract_status': 'pass', 'ok_to_send': True},
                'missing_required_evidence': [],
                'operator_contract': {},
                'attachments': [],
            }
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    evidence_manifest=manifest,
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            self.assertIn('system_health_pack', os.path.basename(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                self.assertIn('evidence_manifest.json', zf.namelist())
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            self.assertEqual(meta.get('bundle_kind'), 'system_health_pack')
            self.assertEqual(
                (meta.get('extra_context') or {}).get('attachment_contract_status'),
                'pass',
            )
        finally:
            shutil.rmtree(store, ignore_errors=True)


class TestSupportBundleRunLogSelection(unittest.TestCase):
    def setUp(self):
        self._orig_run_log_id = os.environ.get('MEDICAFE_RUN_LOG_ID')
        self._orig_run_log_token = os.environ.get('MEDICAFE_RUN_LOG_TOKEN')
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None

    def tearDown(self):
        if self._orig_run_log_id is None:
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_ID'] = self._orig_run_log_id
        if self._orig_run_log_token is None:
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_TOKEN'] = self._orig_run_log_token
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath

    def _write_log(self, path, marker):
        with open(path, 'w') as f:
            f.write(marker + '\n')

    def test_collect_support_bundle_prefers_current_run_log_and_records_meta(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            newer_other = os.path.join(store, 'Log_{0}_run001.log'.format(date_token))
            self._write_log(current_log, 'CURRENT_RUN_MARKER')
            self._write_log(newer_other, 'NEWER_LOG_MARKER')
            os.utime(current_log, (100, 100))
            os.utime(newer_other, (200, 200))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(include_traceback=False, max_log_lines=20)

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                tail = zf.read(os.path.basename(current_log)).decode('utf-8')
            self.assertIn('CURRENT_RUN_MARKER', tail)
            self.assertNotIn('NEWER_LOG_MARKER', tail)
            self.assertEqual(meta.get('selected_log_selection_strategy'), 'current_process_run_log')
            self.assertEqual(meta.get('selected_log_name'), os.path.basename(current_log))
            self.assertEqual(meta.get('selected_log_archive_name'), os.path.basename(current_log))
            self.assertEqual(meta.get('app_log_run_id'), '2')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_includes_two_prior_run_log_tails(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_history_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            run001 = os.path.join(store, 'Log_{0}_run001.log'.format(date_token))
            run002 = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            current_log = os.path.join(store, 'Log_{0}_run003.log'.format(date_token))
            newer_other = os.path.join(store, 'Log_{0}_run004.log'.format(date_token))
            self._write_log(run001, 'PRE_UPDATE_SESSION_MARKER')
            self._write_log(run002, 'KILLED_POST_UPDATE_SESSION_MARKER')
            self._write_log(current_log, 'CURRENT_RECOVERY_SESSION_MARKER')
            self._write_log(newer_other, 'SHOULD_NOT_BE_SELECTED_MARKER')
            os.utime(run001, (100, 100))
            os.utime(run002, (200, 200))
            os.utime(current_log, (300, 300))
            os.utime(newer_other, (400, 400))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '3'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(include_traceback=False, max_log_lines=20)

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                names = zf.namelist()
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                selected_tail = zf.read(os.path.basename(current_log)).decode('utf-8')
                previous_1 = zf.read(os.path.basename(run002)).decode('utf-8')
                previous_2 = zf.read(os.path.basename(run001)).decode('utf-8')
            self.assertIn('CURRENT_RECOVERY_SESSION_MARKER', selected_tail)
            self.assertIn('KILLED_POST_UPDATE_SESSION_MARKER', previous_1)
            self.assertIn('PRE_UPDATE_SESSION_MARKER', previous_2)
            self.assertNotIn('SHOULD_NOT_BE_SELECTED_MARKER', selected_tail + previous_1 + previous_2)
            self.assertIn(os.path.basename(run002), names)
            self.assertIn(os.path.basename(run001), names)
            history = meta.get('historical_log_tails') or []
            self.assertEqual([row.get('selected_log_name') for row in history], [
                os.path.basename(run002),
                os.path.basename(run001),
            ])
            self.assertEqual([row.get('archive_name') for row in history], [
                os.path.basename(run002),
                os.path.basename(run001),
            ])
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_writes_evidence_manifest_json(self):
        store = tempfile.mkdtemp(prefix='mc_em_json_')
        try:
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            man = {
                'schema_version': 1,
                'request': {'bundle_kind': 'error_report'},
                'attachments': [],
                'missing_required_evidence': [],
                'scope': {'coherence_status': 'ready'},
                'operator_contract': {},
                'validation': {'attachment_contract_status': 'pass'},
            }
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=5,
                    evidence_manifest=man,
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                self.assertIn('evidence_manifest.json', zf.namelist())
                inner = json.loads(zf.read('evidence_manifest.json').decode('utf-8'))
            self.assertEqual(inner.get('schema_version'), 1)
            self.assertEqual(inner.get('validation', {}).get('attachment_contract_status'), 'pass')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_historical_selector_prioritizes_same_day_prior_runs_over_older_high_run_index(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_history_')
        try:
            run003 = os.path.join(store, 'Log_04202026_run003.log')
            run004 = os.path.join(store, 'Log_04202026_run004.log')
            current_log = os.path.join(store, 'Log_04202026_run005.log')
            older_high_run = os.path.join(store, 'Log_04162026_run023.log')
            self._write_log(run003, 'SAME_DAY_RUN003')
            self._write_log(run004, 'SAME_DAY_RUN004')
            self._write_log(current_log, 'CURRENT_RUN005')
            self._write_log(older_high_run, 'OLDER_HIGH_RUN023')
            os.utime(run003, (200, 200))
            os.utime(run004, (300, 300))
            os.utime(current_log, (400, 400))
            os.utime(older_high_run, (350, 350))

            history = er._select_historical_support_bundle_logs(store, current_log, limit=2)

            self.assertEqual([row.get('name') for row in history], [
                os.path.basename(run004),
                os.path.basename(run003),
            ])
            self.assertEqual([row.get('selection_reason') for row in history], [
                'same_day_prior_run',
                'same_day_prior_run',
            ])
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_historical_selector_fills_from_older_filename_dates_by_date_then_run(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_history_')
        try:
            current_log = os.path.join(store, 'Log_04202026_run001.log')
            older_latest_day_run001 = os.path.join(store, 'Log_04192026_run001.log')
            older_latest_day_run002 = os.path.join(store, 'Log_04192026_run002.log')
            older_high_run = os.path.join(store, 'Log_04162026_run023.log')
            self._write_log(current_log, 'CURRENT_RUN001')
            self._write_log(older_latest_day_run001, 'OLDER_LATEST_DAY_RUN001')
            self._write_log(older_latest_day_run002, 'OLDER_LATEST_DAY_RUN002')
            self._write_log(older_high_run, 'OLDER_HIGH_RUN023')
            os.utime(current_log, (400, 400))
            os.utime(older_latest_day_run001, (100, 100))
            os.utime(older_latest_day_run002, (90, 90))
            os.utime(older_high_run, (350, 350))

            history = er._select_historical_support_bundle_logs(store, current_log, limit=2)

            self.assertEqual([row.get('name') for row in history], [
                os.path.basename(older_latest_day_run002),
                os.path.basename(older_latest_day_run001),
            ])
            self.assertEqual([row.get('selection_reason') for row in history], [
                'older_filename_date',
                'older_filename_date',
            ])
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_falls_back_to_latest_when_current_missing(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_logs_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            older = os.path.join(store, 'Log_{0}_run001.log'.format(date_token))
            newer = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            self._write_log(older, 'OLDER_LOG_MARKER')
            self._write_log(newer, 'LATEST_LOG_MARKER')
            os.utime(older, (100, 100))
            os.utime(newer, (200, 200))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '9'  # expected current-run log path is absent
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(include_traceback=False, max_log_lines=20)

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                tail = zf.read(os.path.basename(newer)).decode('utf-8')
            self.assertIn('LATEST_LOG_MARKER', tail)
            self.assertNotIn('OLDER_LOG_MARKER', tail)
            self.assertEqual(meta.get('selected_log_selection_strategy'), 'latest_modified_fallback')
            self.assertEqual(meta.get('selected_log_name'), os.path.basename(newer))
            self.assertEqual(meta.get('selected_log_archive_name'), os.path.basename(newer))
            self.assertEqual(meta.get('app_log_run_id'), '9')
        finally:
            shutil.rmtree(store, ignore_errors=True)


class TestClaimSubmissionBundleEvidenceScope(unittest.TestCase):
    """claim_submission_report bundles: evidence_scope + json health attachment behavior."""

    def setUp(self):
        self._orig_run_log_id = os.environ.get('MEDICAFE_RUN_LOG_ID')
        self._orig_run_log_token = os.environ.get('MEDICAFE_RUN_LOG_TOKEN')
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None

    def tearDown(self):
        if self._orig_run_log_id is None:
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_ID'] = self._orig_run_log_id
        if self._orig_run_log_token is None:
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_TOKEN'] = self._orig_run_log_token
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath

    def _write_log(self, path, marker):
        with open(path, 'w') as f:
            f.write(marker + '\n')

    def test_claim_submission_bundle_scopes_to_app_log_run_inline_json_health(self):
        store = tempfile.mkdtemp(prefix='mc_claim_bundle_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run006.log'.format(date_token))
            self._write_log(current_log, 'RUN006_CLAIM')
            t_now = time.time()
            os.utime(current_log, (t_now, t_now))

            claims_dir = os.path.join(store, 'claims')
            os.makedirs(claims_dir)
            idx_path = os.path.join(claims_dir, 'submission_index.jsonl')
            with open(idx_path, 'w', encoding='utf-8') as handle:
                handle.write(json.dumps({'record_type': 'submission', 'claim_key': 'CK|1|20260101|x'}) + '\n')
            os.utime(idx_path, (t_now - 400, t_now - 400))

            telem = os.path.join(store, 'telemetry')
            os.makedirs(telem)
            snap_path = os.path.join(telem, 'json_health_snapshot.json')
            snapshot_payload = {
                'schema_version': 1,
                'scan_id': 'test-scan',
                'scanned_at_utc': '2026-05-08T14:30:00Z',
                'status': 'ok',
                'artifact_count': 1,
                'artifact_keys': ['submission_index'],
                'scan_scope': 'full',
                'warning_count': 0,
                'error_count': 0,
                'required_missing_count': 0,
                'optional_missing_count': 0,
                'issues': [],
                'artifact_diagnostics': [],
            }
            with open(snap_path, 'w', encoding='utf-8') as handle:
                json.dump(snapshot_payload, handle)
            os.utime(snap_path, (t_now - 200, t_now - 200))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '6'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)

            claim_summary = {
                'total_failures': 1,
                'total_successes': 0,
                'endpoints_with_failures': [],
                'failures_by_endpoint': {},
                'error_message_summary': [],
            }
            cfg = {'MediLink_Config': {'local_storage_path': store, 'local_claims_path': claims_dir}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    claim_failure_summary=claim_summary,
                )

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                escope = json.loads(zf.read('evidence_scope.json').decode('utf-8'))
                banner = zf.read('BUNDLE_README.txt').decode('utf-8')
                names = zf.namelist()
            self.assertEqual(meta.get('bundle_kind'), 'claim_submission_report')
            self.assertEqual(meta.get('app_log_run_id'), '6')
            scope = meta.get('evidence_scope') or {}
            self.assertEqual(scope.get('artifact_run_id'), '6')
            self.assertEqual(scope.get('scope_kind'), 'claim_submission_report')
            self.assertEqual(scope.get('phase_artifact_scope'), 'application_log_run')
            self.assertEqual(escope.get('phase_artifact_scope'), 'application_log_run')
            self.assertEqual(escope.get('artifact_run_id'), '6')
            fresh = meta.get('attachment_freshness') or {}
            self.assertEqual(fresh.get('freshness_status'), 'inline_timestamps_available')
            self.assertIn('json_health_snapshot.json', names)
            self.assertNotIn('operator_action=', banner)
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_claim_submission_mixed_when_pipeline_attachments_differ(self):
        store = tempfile.mkdtemp(prefix='mc_claim_mixed_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run006.log'.format(date_token))
            self._write_log(current_log, 'MIX')
            t_now = time.time()
            os.utime(current_log, (t_now, t_now))

            a_path = os.path.join(store, 'run_artifact_index_alpha.txt')
            b_path = os.path.join(store, 'run_artifact_index_beta.txt')
            with open(a_path, 'w') as f:
                f.write('a\n')
            with open(b_path, 'w') as f:
                f.write('b\n')
            claims_dir = os.path.join(store, 'claims')
            os.makedirs(claims_dir)
            idx_path = os.path.join(claims_dir, 'submission_index.jsonl')
            with open(idx_path, 'w', encoding='utf-8') as handle:
                handle.write(json.dumps({'record_type': 'submission', 'claim_key': 'k'}) + '\n')
            telem = os.path.join(store, 'telemetry')
            os.makedirs(telem)
            snap_path = os.path.join(telem, 'json_health_snapshot.json')
            with open(snap_path, 'w', encoding='utf-8') as handle:
                json.dump({
                    'schema_version': 1,
                    'scanned_at_utc': '2026-05-08T15:00:00Z',
                    'status': 'ok',
                    'artifact_count': 0,
                    'artifact_keys': [],
                    'scan_scope': 'partial',
                    'warning_count': 0,
                    'error_count': 0,
                    'issues': [],
                    'artifact_diagnostics': [],
                }, handle)
            os.utime(idx_path, (t_now - 400, t_now - 400))
            os.utime(snap_path, (t_now - 200, t_now - 200))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '6'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)

            cfg = {'MediLink_Config': {'local_storage_path': store, 'local_claims_path': claims_dir}}
            extra_files = [
                ('run_artifact_index_alpha.txt', a_path),
                ('run_artifact_index_beta.txt', b_path),
            ]
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=10,
                    claim_failure_summary={'total_failures': 1, 'total_successes': 0},
                    extra_files=extra_files,
                )

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            self.assertEqual((meta.get('evidence_scope') or {}).get('phase_artifact_scope'), 'mixed')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_claim_bundle_readme_operator_action_when_snapshot_stays_stale(self):
        store = tempfile.mkdtemp(prefix='mc_claim_stale_jh_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run006.log'.format(date_token))
            self._write_log(current_log, 'STALE_JH')
            t_now = time.time()
            os.utime(current_log, (t_now, t_now))

            claims_dir = os.path.join(store, 'claims')
            os.makedirs(claims_dir)
            idx_path = os.path.join(claims_dir, 'submission_index.jsonl')
            with open(idx_path, 'w', encoding='utf-8') as handle:
                handle.write(json.dumps({'record_type': 'submission', 'claim_key': 'k'}) + '\n')
            os.utime(idx_path, (t_now - 50, t_now - 50))

            telem = os.path.join(store, 'telemetry')
            os.makedirs(telem)
            snap_path = os.path.join(telem, 'json_health_snapshot.json')
            with open(snap_path, 'w', encoding='utf-8') as handle:
                json.dump({'schema_version': 1, 'scanned_at_utc': '2026-01-01T00:00:00Z', 'status': 'ok'}, handle)
            os.utime(snap_path, (t_now - 500, t_now - 500))

            os.environ['MEDICAFE_RUN_LOG_ID'] = '6'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)

            cfg = {'MediLink_Config': {'local_storage_path': store, 'local_claims_path': claims_dir}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                with patch('MediCafe.json_health.run_json_health_scan', side_effect=RuntimeError('scan failed')):
                    zpath = er.collect_support_bundle(
                        include_traceback=False,
                        max_log_lines=10,
                        claim_failure_summary={'total_failures': 1, 'total_successes': 0},
                    )

            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                banner = zf.read('BUNDLE_README.txt').decode('utf-8')
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            self.assertIn('operator_action=', banner)
            self.assertIn('json_health', banner.lower())
            self.assertTrue(meta.get('json_health_submission_index_stale_unresolved'))
        finally:
            shutil.rmtree(store, ignore_errors=True)


    def test_attachment_freshness_treats_inline_json_and_live_status_correctly(self):
        store = tempfile.mkdtemp(prefix='mc_freshness_live_')
        try:
            stale_path = os.path.join(store, 'support_send_stale_preflight_latest.txt')
            with open(stale_path, 'w', encoding='utf-8') as handle:
                handle.write('support_send_stale_preflight\n')
            os.utime(stale_path, (100, 100))
            smoke_mismatch_path = os.path.join(store, 'run_evidence_smoke_anchor_mismatch_anchor.txt')
            with open(smoke_mismatch_path, 'w', encoding='utf-8') as handle:
                handle.write('ignored_smoke_mismatch=true\n')
            os.utime(smoke_mismatch_path, (100, 100))
            smoke_state_path = os.path.join(store, 'phase_d_dat_smoke_state.json')
            with open(smoke_state_path, 'w', encoding='utf-8') as handle:
                json.dump({'last_status': 'succeeded', 'accepted_for_anchor': False}, handle)
            os.utime(smoke_state_path, (100, 100))
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                with patch.object(er, '_with_json_health_attachment', side_effect=lambda files, config: (list(files or []), {})):
                    with patch.object(er, '_with_medisoft_dat_boundary_attachment', side_effect=lambda files, config: list(files or [])):
                        with patch.object(er, '_with_remittance_sync_status_attachment', side_effect=lambda files, config, local_storage_path=None: list(files or [])):
                            zpath = er.collect_support_bundle(
                                include_traceback=False,
                                max_log_lines=20,
                                extra_meta={'run_evidence_bundle': True, 'anchor_run_id': 'anchor'},
                                extra_files=[
                                    ('xp_package_integrity_latest.json', '{"ok": true, "verified_count": 2}'),
                                    ('support_send_stale_preflight_latest.txt', stale_path),
                                    ('run_evidence_smoke_anchor_mismatch_anchor.txt', smoke_mismatch_path),
                                    ('phase_d_dat_smoke_state.json', smoke_state_path),
                                ],
                            )
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            fresh = meta.get('attachment_freshness') or {}
            rows = fresh.get('attachment_manifest') or []
            by_name = dict((row.get('archive_name'), row) for row in rows if isinstance(row, dict))
            self.assertEqual(fresh.get('missing_path_attachment_count'), 0)
            self.assertEqual(by_name['xp_package_integrity_latest.json'].get('freshness_status'), 'inline_content')
            self.assertEqual(by_name['support_send_stale_preflight_latest.txt'].get('freshness_status'), 'live_status')
            self.assertEqual(by_name['support_send_stale_preflight_latest.txt'].get('freshness_rollup_included'), False)
            self.assertEqual(by_name['run_evidence_smoke_anchor_mismatch_anchor.txt'].get('source_kind'), 'smoke_rejected_provenance')
            self.assertEqual(by_name['run_evidence_smoke_anchor_mismatch_anchor.txt'].get('freshness_status'), 'rejected_provenance')
            self.assertEqual(by_name['run_evidence_smoke_anchor_mismatch_anchor.txt'].get('freshness_rollup_included'), False)
            self.assertEqual(by_name['phase_d_dat_smoke_state.json'].get('freshness_status'), 'live_status')
            self.assertEqual(by_name['phase_d_dat_smoke_state.json'].get('freshness_rollup_included'), False)
            self.assertTrue(fresh.get('freshness_rollup_excluded_attachment_count', 0) >= 1)
        finally:
            shutil.rmtree(store, ignore_errors=True)


class TestSupportBundleOverlapSummary(unittest.TestCase):
    def test_collect_support_bundle_writes_review_group_hashes_and_overlap_summary(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_overlap_')
        try:
            shared_path = os.path.join(store, 'shared_evidence.txt')
            unique_path = os.path.join(store, 'unique_evidence.txt')
            with open(shared_path, 'w', encoding='utf-8') as handle:
                handle.write('same review content\n')
            with open(unique_path, 'w', encoding='utf-8') as handle:
                handle.write('second bundle only\n')
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            extra_meta = {
                'bundle_kind': 'run_evidence_bundle',
                'run_evidence_bundle': True,
                'artifact_run_id': 'RUN-42',
                'recommendation_action_kind': 'resolve_layer1_upstream_blocker',
            }
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                first = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=5,
                    extra_meta=extra_meta,
                    extra_files=[('shared_evidence.txt', shared_path)],
                )
                time.sleep(1.1)
                second = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=5,
                    extra_meta=extra_meta,
                    extra_files=[
                        ('shared_evidence.txt', shared_path),
                        ('unique_evidence.txt', unique_path),
                    ],
                )

            self.assertTrue(first and os.path.isfile(first))
            self.assertTrue(second and os.path.isfile(second))
            self.assertNotEqual(os.path.basename(first), os.path.basename(second))
            with zipfile.ZipFile(second, 'r') as zf:
                names = zf.namelist()
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                scope = json.loads(zf.read('evidence_scope.json').decode('utf-8'))
                overlap = json.loads(zf.read('bundle_overlap_summary.json').decode('utf-8'))
                readme = zf.read('BUNDLE_README.txt').decode('utf-8')
                overlap_txt = zf.read('bundle_overlap_summary.txt').decode('utf-8')

            self.assertIn('bundle_overlap_summary.json', names)
            self.assertIn('bundle_overlap_summary.txt', names)
            self.assertEqual(meta.get('bundle_review_group'), scope.get('bundle_review_group'))
            self.assertTrue(meta.get('bundle_review_group'))
            self.assertEqual(overlap.get('status'), 'compared')
            self.assertEqual(overlap.get('previous_same_group_bundle_count'), 1)
            self.assertEqual(overlap.get('overlapping_attachment_count'), 1)
            self.assertEqual(overlap.get('unique_current_attachment_count'), 1)
            self.assertIn(os.path.basename(first), overlap.get('compared_bundle_names') or [])
            self.assertIn('overlap_status=compared', readme)
            self.assertIn('overlap_summary_files=bundle_overlap_summary.json,bundle_overlap_summary.txt', readme)
            self.assertIn('Bundle Overlap Summary', overlap_txt)

            manifest_rows = ((meta.get('attachment_freshness') or {}).get('attachment_manifest') or [])
            rows = dict((row.get('archive_name'), row) for row in manifest_rows if isinstance(row, dict))
            self.assertIn('shared_evidence.txt', rows)
            self.assertEqual(rows['shared_evidence.txt'].get('hash_status'), 'ok')
            self.assertEqual(rows['shared_evidence.txt'].get('size_bytes'), os.path.getsize(shared_path))
            self.assertTrue(rows['shared_evidence.txt'].get('content_sha256'))
            self.assertEqual(rows['shared_evidence.txt'].get('review_role'), 'supporting_context')
        finally:
            shutil.rmtree(store, ignore_errors=True)


class TestMedisoftDatBoundaryAttachment(unittest.TestCase):
    """Regression: always search cwd/reports even when MEDICAFE_LAB_DIR is set."""

    def test_fallback_searches_cwd_reports_when_lab_reports_missing_artifacts(self):
        root = tempfile.mkdtemp(prefix='er_dat_boundary_')
        try:
            lab = os.path.join(root, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            work = os.path.join(root, 'work')
            wr = os.path.join(work, 'reports')
            os.makedirs(wr)
            summary_path = os.path.join(wr, 'medisoft_dat_boundary_summary_latest.json')
            with open(summary_path, 'w') as handle:
                handle.write('{}')
            detail_path = os.path.join(wr, 'medisoft_dat_boundary_detail_latest.jsonl')
            with open(detail_path, 'w') as handle:
                handle.write('\n')

            prev_lab = os.environ.get('MEDICAFE_LAB_DIR')
            prev_telem = os.environ.get('MEDICAFE_DAT_BOUNDARY_TELEMETRY_DIR')
            try:
                os.environ['MEDICAFE_LAB_DIR'] = lab
                os.environ.pop('MEDICAFE_DAT_BOUNDARY_TELEMETRY_DIR', None)
                with patch.object(er.os, 'getcwd', return_value=work):
                    out = er._with_medisoft_dat_boundary_attachment([], {})
            finally:
                if prev_lab is not None:
                    os.environ['MEDICAFE_LAB_DIR'] = prev_lab
                else:
                    os.environ.pop('MEDICAFE_LAB_DIR', None)
                if prev_telem is not None:
                    os.environ['MEDICAFE_DAT_BOUNDARY_TELEMETRY_DIR'] = prev_telem
                else:
                    os.environ.pop('MEDICAFE_DAT_BOUNDARY_TELEMETRY_DIR', None)

            names = {item[0] for item in out}
            paths = {item[1] for item in out}
            self.assertIn('medisoft_dat_boundary_summary_latest.json', names)
            self.assertIn('medisoft_dat_boundary_detail_latest.jsonl', names)
            self.assertIn(summary_path, paths)
            self.assertIn(detail_path, paths)
        finally:
            shutil.rmtree(root, ignore_errors=True)


class TestEvidenceScopeSchemaVersionCoercion(unittest.TestCase):
    """Regression: non-numeric manifest scope schema_version must not abort bundle meta."""

    def test_coerce_evidence_scope_schema_version(self):
        self.assertEqual(er._coerce_evidence_scope_schema_version(None), 1)
        self.assertEqual(er._coerce_evidence_scope_schema_version(''), 1)
        self.assertEqual(er._coerce_evidence_scope_schema_version('bogus'), 1)
        self.assertEqual(er._coerce_evidence_scope_schema_version(2), 2)
        self.assertEqual(er._coerce_evidence_scope_schema_version('3'), 3)
        self.assertEqual(er._coerce_evidence_scope_schema_version(0), 0)
        self.assertEqual(er._coerce_evidence_scope_schema_version(-1), 1)

    def test_attach_bundle_evidence_metadata_non_numeric_scope_schema_version(self):
        manifest = {'scope': {'schema_version': 'bogus', 'anchor_run_id': 'abc'}}
        meta = {'bundle_kind': 'error_report'}
        txt = er._attach_bundle_evidence_metadata(meta, [], manifest)
        self.assertIsInstance(txt, str)
        es = meta.get('evidence_scope')
        self.assertIsInstance(es, dict)
        self.assertEqual(es.get('schema_version'), 1)


if __name__ == '__main__':
    unittest.main()
