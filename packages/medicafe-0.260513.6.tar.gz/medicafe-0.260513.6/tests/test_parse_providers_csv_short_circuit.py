#!/usr/bin/env python
from __future__ import print_function

import os
import sys

import pytest

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

_UNIFIED = os.path.join(_PROJECT_ROOT, "scripts", "unified_model")
if _UNIFIED not in sys.path:
    sys.path.insert(0, _UNIFIED)

import parse_providers  # noqa: E402


def test_parse_csv_does_not_short_circuit_when_surgery_header_needs_scrub(tmp_path):
    """
    Regression: header-shape short-circuit must use the same token scrubbing as
    clean_header, or a valid surgery schedule column (e.g. 'Surgery Date\u2122')
    on a claim-shaped feed is rejected before load_csv_data runs.
    """
    csv_path = os.path.join(str(tmp_path), "mixed_headers.csv")
    header = (
        "Claim,Payer,Status,Patient,Proc,Surgery Date\u2122,"
        "Allowed,Paid,Pt Resp,Charged\n"
    )
    row = "1,a,b,c,d,01/15/2026,1,1,1,1\n"
    with open(csv_path, "w", encoding="utf-8", newline="") as handle:
        handle.write(header + row)

    ok, envelope, code = parse_providers.parse_csv(csv_path, metadata={})
    assert ok is True
    assert code is None
    assert envelope is not None
    assert int(envelope.get("row_count") or 0) >= 1
