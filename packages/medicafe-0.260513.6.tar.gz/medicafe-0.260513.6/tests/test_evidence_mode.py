# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

_TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean


def _write_json(path, payload):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)


def _archive_names(manifest):
    out = []
    for row in manifest.get("attachments", []):
        if isinstance(row, dict):
            out.append(row.get("archive_name"))
    return out


class EvidenceModeResolverTests(unittest.TestCase):
    def setUp(self):
        self.lab = tempfile.mkdtemp(prefix="mc_ev_mode_")
        self.reports = os.path.join(self.lab, "reports")
        os.makedirs(self.reports)

    def tearDown(self):
        shutil.rmtree(self.lab, ignore_errors=True)

    def test_active_run_newer_than_completed_is_live_status(self):
        from MediCafe.evidence_mode import MODE_LIVE_STATUS, resolve_evidence_mode

        state = {
            "pipeline_state": "running",
            "active_run_id": "run-active",
            "last_shadow_pipeline_run_id": "run-completed",
        }
        mode = resolve_evidence_mode(
            self.lab,
            bundle_kind="system_health_pack",
            requested_run_id="run-completed",
            diagnostics_state=state,
            run_cursor={},
        )

        self.assertEqual(mode.get("mode"), MODE_LIVE_STATUS)
        self.assertFalse(mode.get("decisive_run_evidence_current"))
        self.assertEqual(mode.get("allowed_current_artifacts"), "live_state_only")
        assert_workflow_boundary_clean("evidence_mode", {
            "anchor_run_id": "run-active",
        }, [
            {
                "name": "diagnostics_state",
                "role": "attempt",
                "identity": {"anchor_run_id": mode.get("selected_run_id")},
                "status": "running",
            },
            {
                "name": "resolve_evidence_mode",
                "role": "package",
                "identity": {"anchor_run_id": mode.get("selected_run_id")},
                "classification": "in_flight",
            },
        ])

    def test_handoff_run_mismatch_is_incoherent_state(self):
        from MediCafe.evidence_mode import MODE_INCOHERENT_STATE, resolve_evidence_mode

        handoff = os.path.join(self.reports, "phase_c_execution_handoff_run-old.json")
        _write_json(handoff, {"schema_version": 1, "pipeline_run_id": "run-old"})
        state = {
            "pipeline_state": "failed",
            "last_shadow_pipeline_run_id": "run-new",
            "last_phase_c_execution_handoff_report_path": handoff,
        }
        mode = resolve_evidence_mode(
            self.lab,
            bundle_kind="system_health_pack",
            requested_run_id="run-new",
            diagnostics_state=state,
            run_cursor={},
        )

        self.assertEqual(mode.get("mode"), MODE_INCOHERENT_STATE)
        self.assertEqual(mode.get("blocking_reason"), "phase_c_handoff_run_id_mismatch")
        self.assertEqual(mode.get("handoff_run_id"), "run-old")

    def test_phase_c_missing_summary_is_incoherent_state(self):
        from MediCafe.evidence_mode import MODE_INCOHERENT_STATE, resolve_evidence_mode

        state = {
            "pipeline_state": "failed",
            "last_shadow_pipeline_run_id": "run-new",
            "last_phase_c_ok": False,
            "last_phase_c_run_id": "phase-c-old",
        }
        mode = resolve_evidence_mode(
            self.lab,
            bundle_kind="system_health_pack",
            requested_run_id="run-new",
            diagnostics_state=state,
            run_cursor={},
        )

        self.assertEqual(mode.get("mode"), MODE_INCOHERENT_STATE)
        self.assertEqual(mode.get("blocking_reason"), "phase_c_summary_missing_for_recorded_run")
        self.assertTrue(mode.get("missing_phase_c_summary_path", "").endswith("ingest_write_summary_phase-c-old.json"))

    def test_phase_c_manifest_sha_mismatch_is_incoherent_state(self):
        from MediCafe.evidence_mode import MODE_INCOHERENT_STATE, resolve_evidence_mode

        state = {
            "pipeline_state": "failed",
            "last_shadow_pipeline_run_id": "run-new",
            "last_manifest_sha256": "phase-b-sha",
            "last_ingest_manifest_sha256": "phase-c-sha",
        }
        mode = resolve_evidence_mode(
            self.lab,
            bundle_kind="system_health_pack",
            requested_run_id="run-new",
            diagnostics_state=state,
            run_cursor={},
        )

        self.assertEqual(mode.get("mode"), MODE_INCOHERENT_STATE)
        self.assertEqual(mode.get("blocking_reason"), "phase_c_manifest_sha_mismatch")
        self.assertFalse(mode.get("decisive_run_evidence_current"))


class EvidenceModeManifestTests(unittest.TestCase):
    def setUp(self):
        self.lab = tempfile.mkdtemp(prefix="mc_ev_mode_manifest_")
        self.reports = os.path.join(self.lab, "reports")
        os.makedirs(self.reports)

    def tearDown(self):
        shutil.rmtree(self.lab, ignore_errors=True)

    def test_live_status_withholds_stale_phase_c_handoff_and_latest_aliases(self):
        from MediCafe import evidence_manifest

        handoff = os.path.join(self.reports, "phase_c_execution_handoff_run-old.json")
        _write_json(handoff, {"schema_version": 1, "pipeline_run_id": "run-old"})
        _write_json(os.path.join(self.reports, "ingest_from_manifest_bootstrap_latest.json"), {
            "schema_version": 1,
            "stage": "before_run_ingest",
        })
        _write_json(os.path.join(self.reports, "ingest_from_manifest_diagnostics_latest.json"), {
            "schema_version": 1,
            "run_id": "run-old",
        })
        _write_json(os.path.join(self.reports, "phase_c_current_attempt_latest.json"), {
            "schema_version": 1,
            "phase_c_attempt_id": "run-active-phase-c",
        })
        _write_json(os.path.join(self.lab, "diagnostics_state.json"), {
            "pipeline_state": "running",
            "active_run_id": "run-active",
            "last_shadow_pipeline_run_id": "run-old",
            "last_phase_c_ok": False,
            "last_phase_c_run_id": "phase-c-old",
            "last_phase_c_execution_handoff_report_path": handoff,
        })
        _write_json(os.path.join(self.lab, "run_cursor.json"), {})

        req = evidence_manifest.build_evidence_request(
            "system_health_pack",
            "unit",
            self.lab,
            anchor_run_id="run-old",
            active_run_id="run-active",
        )
        manifest = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(manifest)
        meta = evidence_manifest.manifest_to_extra_meta(manifest)

        self.assertEqual(meta.get("current_evidence_mode"), "live_status")
        self.assertFalse(meta.get("decisive_run_evidence_current"))
        self.assertNotIn("phase_c_execution_handoff_run-old.json", names)
        self.assertNotIn("ingest_from_manifest_bootstrap_latest.json", names)
        self.assertNotIn("ingest_from_manifest_diagnostics_latest.json", names)
        self.assertIn("phase_c_current_attempt_latest.json", names)
        self.assertIn("evidence_mode_report.txt", names)

    def test_live_status_attaches_current_attempt_referenced_phase_c_telemetry(self):
        from MediCafe import evidence_manifest

        handoff = os.path.join(self.reports, "phase_c_execution_handoff_run-current.json")
        _write_json(handoff, {"schema_version": 1, "pipeline_run_id": "run-current"})
        with open(handoff[:-5] + ".txt", "w", encoding="utf-8") as handle:
            handle.write("Phase C handoff\n")
        bootstrap = os.path.join(self.reports, "ingest_from_manifest_bootstrap_latest.json")
        _write_json(bootstrap, {
            "schema_version": 1,
            "stage": "before_run_ingest",
        })
        timeline = os.path.join(self.reports, "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
        with open(timeline, "w", encoding="utf-8") as handle:
            handle.write('{"schema_version":1,"stage":"before_run_ingest"}\n')
        _write_json(os.path.join(self.reports, "phase_c_current_attempt_latest.json"), {
            "schema_version": 1,
            "phase_c_attempt_id": "run-current-phase-c",
            "bootstrap_path": bootstrap,
            "bootstrap_timeline_path": timeline,
            "handoff_report_seen": True,
        })
        _write_json(os.path.join(self.lab, "diagnostics_state.json"), {
            "pipeline_state": "running",
            "active_run_id": "run-active",
            "last_shadow_pipeline_run_id": "run-current",
            "last_phase_c_ok": False,
            "last_phase_c_run_id": "phase-c-current",
            "last_phase_c_execution_handoff_report_path": handoff,
        })
        _write_json(os.path.join(self.lab, "run_cursor.json"), {})

        req = evidence_manifest.build_evidence_request(
            "system_health_pack",
            "unit",
            self.lab,
            anchor_run_id="run-current",
            active_run_id="run-active",
        )
        manifest = evidence_manifest.resolve_evidence_manifest(req)
        rows = {
            row.get("archive_name"): row
            for row in manifest.get("attachments", [])
            if isinstance(row, dict)
        }

        self.assertEqual(
            evidence_manifest.manifest_to_extra_meta(manifest).get("current_evidence_mode"),
            "live_status",
        )
        self.assertEqual(
            rows["ingest_from_manifest_bootstrap_latest.json"].get("scope"),
            "phase_c_current_attempt_bootstrap",
        )
        self.assertEqual(
            rows["ingest_from_manifest_bootstrap_timeline_latest.jsonl"].get("scope"),
            "phase_c_current_attempt_bootstrap_timeline",
        )
        self.assertEqual(
            rows["phase_c_execution_handoff_run-current.json"].get("scope"),
            "phase_c_current_attempt_handoff",
        )
        self.assertEqual(
            rows["phase_c_execution_handoff_run-current.txt"].get("scope"),
            "phase_c_current_attempt_handoff",
        )

    def test_incoherent_handoff_mismatch_attaches_report_not_stale_handoff(self):
        from MediCafe import evidence_manifest

        handoff = os.path.join(self.reports, "phase_c_execution_handoff_run-old.json")
        _write_json(handoff, {"schema_version": 1, "pipeline_run_id": "run-old"})
        _write_json(os.path.join(self.lab, "diagnostics_state.json"), {
            "pipeline_state": "failed",
            "last_shadow_pipeline_run_id": "run-new",
            "last_phase_c_ok": False,
            "last_phase_c_run_id": "phase-c-old",
            "last_phase_c_execution_handoff_report_path": handoff,
        })
        _write_json(os.path.join(self.lab, "run_cursor.json"), {})

        req = evidence_manifest.build_evidence_request(
            "cloud_health_escalation",
            "unit",
            self.lab,
            anchor_run_id="run-new",
            active_run_id="run-new",
            failed_phase="C",
            error_code="PHASE_C_HANDOFF_INCOHERENT",
        )
        manifest = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(manifest)
        meta = evidence_manifest.manifest_to_extra_meta(manifest)

        self.assertEqual(meta.get("current_evidence_mode"), "incoherent_state")
        self.assertIn("evidence_incoherent_state.txt", names)
        self.assertNotIn("phase_c_execution_handoff_run-old.json", names)


if __name__ == "__main__":
    unittest.main()
