import json
import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
UM_ROOT = os.path.join(REPO_ROOT, "scripts", "unified_model")
if UM_ROOT not in sys.path:
    sys.path.insert(0, UM_ROOT)
TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if TESTS_ROOT not in sys.path:
    sys.path.insert(0, TESTS_ROOT)

from phase_c_current_attempt import (  # noqa: E402
    begin_phase_c_current_attempt,
    phase_c_current_attempt_path,
    refresh_phase_c_current_attempt_from_lab,
    _write_json,
)
from workflow_boundary_contract import assert_workflow_boundary_clean  # noqa: E402


def _write_fixture_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)


def _write_timeline(path, stages):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        seq = 0
        for stage in stages:
            seq += 1
            handle.write(json.dumps({
                "schema_version": 1,
                "stage": stage,
                "stage_seq": seq,
            }, sort_keys=True) + "\n")


class PhaseCCurrentAttemptTests(unittest.TestCase):
    def test_current_attempt_writer_still_returns_false_for_non_serializable_payload(self):
        td = tempfile.mkdtemp()
        try:
            path = os.path.join(td, "reports", "bad.json")
            ok = _write_json(path, {"bad": set([1])})
            self.assertFalse(ok)
            self.assertFalse(os.path.exists(path))
            self.assertFalse(os.path.exists(path + ".tmp"))
        finally:
            shutil.rmtree(td)

    def test_current_attempt_reports_entrypoint_not_observed(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(
                td,
                "attempt-1",
                "test",
                expected_manifest_sha256="sha-1",
            )
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-1", "test")
            self.assertEqual(doc["last_reached_stage"], "not_entered")
            self.assertEqual(
                doc["current_blocker"],
                "phase_c_script_entrypoint_not_observed_current_attempt",
            )
            with open(os.path.join(td, "diagnostics_state.json"), "r", encoding="utf-8") as handle:
                st = json.load(handle)
            self.assertEqual(
                st["last_phase_c_current_attempt_blocker"],
                "phase_c_script_entrypoint_not_observed_current_attempt",
            )
        finally:
            shutil.rmtree(td)

    def test_current_attempt_tracks_bootstrap_without_finish(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(td, "attempt-2", "test")
            reports = os.path.join(td, "reports")
            _write_fixture_json(
                os.path.join(reports, "ingest_from_manifest_bootstrap_latest.json"),
                {"stage": "main_start"},
            )
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-2", "test")
            self.assertEqual(doc["last_reached_stage"], "bootstrap")
            self.assertEqual(
                doc["current_blocker"],
                "phase_c_script_entered_but_no_finish_diag_current_attempt",
            )
        finally:
            shutil.rmtree(td)

    def test_current_attempt_uses_latest_timeline_stage_without_finish(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(td, "attempt-timeline", "test")
            reports = os.path.join(td, "reports")
            _write_fixture_json(
                os.path.join(reports, "ingest_from_manifest_bootstrap_latest.json"),
                {"stage": "main_start"},
            )
            _write_timeline(
                os.path.join(reports, "ingest_from_manifest_bootstrap_timeline_latest.jsonl"),
                ["main_start", "sqlite_begin_execute_begin", "sqlite_commit_begin"],
            )
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-timeline", "test")
            self.assertEqual(doc["last_reached_stage"], "sqlite_commit_begin")
            self.assertEqual(doc["bootstrap_timeline_latest_stage"], "sqlite_commit_begin")
            self.assertEqual(
                doc["current_blocker"],
                "phase_c_script_entered_but_no_finish_diag_current_attempt",
            )
        finally:
            shutil.rmtree(td)

    def test_current_attempt_classifies_post_commit_without_summary_precisely(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(td, "attempt-post-commit", "test")
            reports = os.path.join(td, "reports")
            _write_fixture_json(
                os.path.join(reports, "ingest_from_manifest_bootstrap_latest.json"),
                {"stage": "main_start"},
            )
            _write_timeline(
                os.path.join(reports, "ingest_from_manifest_bootstrap_timeline_latest.jsonl"),
                ["main_start", "sqlite_commit_begin", "sqlite_commit_end"],
            )
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-post-commit", "test")
            self.assertEqual(doc["last_reached_stage"], "sqlite_commit_end")
            self.assertEqual(
                doc["current_blocker"],
                "phase_c_post_commit_no_summary_current_attempt",
            )
            with open(os.path.join(td, "diagnostics_state.json"), "r", encoding="utf-8") as handle:
                st = json.load(handle)
            self.assertEqual(
                st["last_phase_c_current_attempt_last_reached_stage"],
                "sqlite_commit_end",
            )
        finally:
            shutil.rmtree(td)

    def test_current_attempt_tracks_successful_handoff(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(
                td,
                "attempt-3",
                "test",
                expected_manifest_sha256="sha-3",
            )
            reports = os.path.join(td, "reports")
            _write_fixture_json(os.path.join(reports, "ingest_from_manifest_diagnostics_latest.json"), {"rid": "c-3"})
            _write_fixture_json(os.path.join(reports, "ingest_write_summary_c-3.json"), {"ok": True})
            _write_fixture_json(os.path.join(reports, "phase_c_execution_handoff_r.json"), {
                "status": "ok",
                "blocker_class": "phase_c_handoff_ok",
            })
            state = {
                "last_ingest_manifest_sha256": "sha-3",
                "last_phase_c_execution_handoff_report_path": os.path.join(
                    reports, "phase_c_execution_handoff_r.json"),
            }
            _write_fixture_json(os.path.join(td, "diagnostics_state.json"), state)
            _write_fixture_json(os.path.join(td, "run_cursor.json"), {"last_ingest_manifest_sha256": "sha-3"})
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-3", "test")
            self.assertEqual(doc["last_reached_stage"], "handoff_report")
            self.assertEqual(doc["current_blocker"], "phase_c_current_attempt_ok")
            self.assertTrue(os.path.isfile(phase_c_current_attempt_path(td)))
        finally:
            shutil.rmtree(td)

    def test_current_attempt_publish_without_handoff_is_not_accepted(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(
                td,
                "attempt-publish",
                "test",
                expected_manifest_sha256="sha-publish",
            )
            reports = os.path.join(td, "reports")
            _write_fixture_json(os.path.join(reports, "ingest_from_manifest_diagnostics_latest.json"), {"rid": "c-publish"})
            _write_fixture_json(os.path.join(reports, "ingest_write_summary_c-publish.json"), {"ok": True})
            _write_fixture_json(os.path.join(td, "diagnostics_state.json"), {"last_ingest_manifest_sha256": "sha-publish"})
            _write_fixture_json(os.path.join(td, "run_cursor.json"), {"last_ingest_manifest_sha256": "sha-publish"})
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-publish", "test")
            self.assertEqual(doc["last_reached_stage"], "state_cursor_publish")
            self.assertEqual(doc["current_blocker"], "phase_c_handoff_report_missing_current_attempt")
            assert_workflow_boundary_clean("phase_c_current_attempt", {
                "phase_c_attempt_id": "attempt-publish",
            }, [
                {
                    "name": "phase_c_current_attempt_latest.json",
                    "role": "attempt",
                    "identity": {"phase_c_attempt_id": doc.get("phase_c_attempt_id")},
                    "status": "running",
                },
                {
                    "name": "current_attempt_classifier",
                    "role": "consumer",
                    "identity": {"phase_c_attempt_id": doc.get("phase_c_attempt_id")},
                    "classification": "partial",
                },
            ])
        finally:
            shutil.rmtree(td)

    def test_current_attempt_refresh_persists_report_with_trailing_newline(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(td, "attempt-newline", "test")
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-newline", "test")
            path = phase_c_current_attempt_path(td)
            with open(path, "r", encoding="utf-8") as handle:
                text = handle.read()
            self.assertTrue(text.endswith("\n"))
            self.assertEqual(json.loads(text)["phase_c_attempt_id"], doc["phase_c_attempt_id"])
        finally:
            shutil.rmtree(td)


if __name__ == "__main__":
    unittest.main()
