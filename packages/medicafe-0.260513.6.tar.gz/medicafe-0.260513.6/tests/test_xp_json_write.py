import json
import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
UM_ROOT = os.path.join(REPO_ROOT, "scripts", "unified_model")
if UM_ROOT not in sys.path:
    sys.path.insert(0, UM_ROOT)

from xp_json_write import write_json  # noqa: E402


class XPJsonWriteTests(unittest.TestCase):
    def test_write_json_overwrites_existing_file_and_preserves_newline(self):
        td = tempfile.mkdtemp()
        try:
            path = os.path.join(td, "reports", "sample.json")
            parent = os.path.dirname(path)
            if not os.path.isdir(parent):
                os.makedirs(parent)
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("{\"stale\": true}")

            ok = write_json(path, {"fresh": True})

            self.assertTrue(ok)
            with open(path, "r", encoding="utf-8") as handle:
                text = handle.read()
            self.assertTrue(text.endswith("\n"))
            self.assertEqual(json.loads(text), {"fresh": True})
            self.assertFalse(os.path.exists(path + ".tmp"))
        finally:
            shutil.rmtree(td)

    def test_write_json_returns_false_and_cleans_tmp_when_payload_is_not_serializable(self):
        td = tempfile.mkdtemp()
        try:
            path = os.path.join(td, "reports", "sample.json")

            ok = write_json(path, {"bad": set([1])})

            self.assertFalse(ok)
            self.assertFalse(os.path.exists(path))
            self.assertFalse(os.path.exists(path + ".tmp"))
        finally:
            shutil.rmtree(td)


if __name__ == "__main__":
    unittest.main()
