import datetime as dt
import importlib
import os
import sys
import types
from types import SimpleNamespace

TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if TESTS_ROOT not in sys.path:
    sys.path.insert(0, TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean


class _FakeSnapshot(object):
    def __init__(self, doc_id, payload=None, exists=True):
        self.id = doc_id
        self._payload = payload or {}
        self.exists = exists

    def to_dict(self):
        return dict(self._payload)


class _FakeDocumentRef(object):
    def __init__(self, collection, doc_id):
        self._collection = collection
        self.id = doc_id

    def get(self):
        if self.id not in self._collection.docs:
            return _FakeSnapshot(self.id, {}, False)
        return _FakeSnapshot(self.id, self._collection.docs[self.id], True)

    def set(self, payload):
        self._collection.docs[self.id] = dict(payload)

    def update(self, payload):
        doc = dict(self._collection.docs.get(self.id, {}))
        doc.update(payload)
        self._collection.docs[self.id] = doc


class _FakeQuery(object):
    def __init__(self, collection, field=None, op=None, expected=None, limit_count=None):
        self._collection = collection
        self._field = field
        self._op = op
        self._expected = expected
        self._limit_count = limit_count

    def where(self, field, op, expected):
        return _FakeQuery(self._collection, field, op, expected, self._limit_count)

    def limit(self, count):
        return _FakeQuery(self._collection, self._field, self._op, self._expected, count)

    def stream(self):
        rows = []
        for doc_id, payload in self._collection.docs.items():
            if self._field is not None:
                value = payload.get(self._field)
                if self._op == ">=":
                    if value is None or value < self._expected:
                        continue
                elif value != self._expected:
                    continue
            rows.append(_FakeSnapshot(doc_id, payload, True))
        if self._limit_count is not None:
            rows = rows[:self._limit_count]
        return rows


class _FakeCollection(object):
    def __init__(self, name):
        self.name = name
        self.docs = {}
        self._next_id = 1

    def document(self, doc_id=None):
        if doc_id is None:
            doc_id = "auto-{0}".format(self._next_id)
            self._next_id += 1
        return _FakeDocumentRef(self, doc_id)

    def where(self, field, op, expected):
        return _FakeQuery(self, field, op, expected)

    def stream(self):
        return [_FakeSnapshot(doc_id, payload, True) for doc_id, payload in self.docs.items()]


class _FakeFirestoreClient(object):
    def __init__(self):
        self.collections = {}

    def collection(self, name):
        if name not in self.collections:
            self.collections[name] = _FakeCollection(name)
        return self.collections[name]


def _load_processor_with_stubs(monkeypatch):
    orchestrator_root = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "cloud",
        "orchestrator",
    )
    monkeypatch.syspath_prepend(orchestrator_root)

    firestore_mod = types.ModuleType("firestore")
    firestore_mod.SERVER_TIMESTAMP = object()
    firestore_mod.Client = object
    storage_mod = types.ModuleType("storage")

    google_mod = types.ModuleType("google")
    cloud_mod = types.ModuleType("google.cloud")
    cloud_mod.firestore = firestore_mod
    cloud_mod.storage = storage_mod
    google_mod.cloud = cloud_mod
    monkeypatch.setitem(sys.modules, "google", google_mod)
    monkeypatch.setitem(sys.modules, "google.cloud", cloud_mod)
    monkeypatch.setitem(sys.modules, "google.cloud.firestore", firestore_mod)
    monkeypatch.setitem(sys.modules, "google.cloud.storage", storage_mod)

    errors_mod = types.ModuleType("googleapiclient.errors")
    errors_mod.HttpError = type("HttpError", (Exception,), {})
    api_mod = types.ModuleType("googleapiclient")
    api_mod.errors = errors_mod
    monkeypatch.setitem(sys.modules, "googleapiclient", api_mod)
    monkeypatch.setitem(sys.modules, "googleapiclient.errors", errors_mod)
    monkeypatch.setitem(sys.modules, "services", types.ModuleType("services"))

    sys.modules.pop("processor", None)
    return importlib.import_module("processor")


def _config(preprocessor_mode="shadow"):
    return SimpleNamespace(
        queue_collection_path="queues",
        state_collection_path="sync_state",
        ingest_errors_collection_path="ingest_errors",
        gcs_bucket="bucket",
        preprocessor_mode=preprocessor_mode,
    )


def test_preprocessor_shadow_reject_writes_open_evidence_not_completion(monkeypatch):
    processor = _load_processor_with_stubs(monkeypatch)
    fs_client = _FakeFirestoreClient()
    config = _config("shadow")
    result = processor.preprocessor.PreprocessResult(
        ok=False,
        code="empty_files_not_otp",
        message="files must be non-empty",
        payload=None,
    )

    processor._process_preprocessor_result(
        result,
        message={"id": "msg-1", "threadId": "thread-1", "historyId": "hist-1"},
        machine_id="machine-1",
        otp_required=False,
        otp_token=None,
        attachments=[],
        fs_client=fs_client,
        storage_client=SimpleNamespace(),
        config=config,
        attempt_id="attempt-1",
        header_index={},
    )

    queue_docs = list(fs_client.collection("queues").docs.values())
    error_docs = list(fs_client.collection("ingest_errors").docs.values())
    assert len(queue_docs) == 1
    assert len(error_docs) == 1
    assert queue_docs[0]["acked"] is False
    assert queue_docs[0]["attempt_id"] == "attempt-1"
    assert queue_docs[0]["preprocessor_reject_code"] == "empty_files_not_otp"
    assert error_docs[0]["status"] == "open"

    assert_workflow_boundary_clean("cloud_orchestrator_preprocessor", {
        "message_id": "msg-1",
        "attempt_id": "attempt-1",
    }, [
        {
            "name": "queues/msg-1",
            "role": "queue_record",
            "identity": {"message_id": queue_docs[0].get("message_id"), "attempt_id": queue_docs[0].get("attempt_id")},
            "status": "queued",
            "accepted": False,
            "classification": "in_flight",
            "claims_completion": False,
        },
        {
            "name": "ingest_errors/msg-1",
            "role": "reject_record",
            "identity": {"message_id": error_docs[0].get("message_id"), "attempt_id": error_docs[0].get("attempt_id")},
            "status": error_docs[0].get("status"),
            "accepted": False,
            "classification": "in_flight",
            "claims_completion": False,
            "terminal": False,
        },
    ])


def test_preprocessor_gate_counts_current_cohort_not_stale_latest(monkeypatch):
    orchestrator_root = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "cloud",
        "orchestrator",
    )
    monkeypatch.syspath_prepend(orchestrator_root)
    gate = importlib.import_module("preprocessor_gate")

    fs_client = _FakeFirestoreClient()
    shadow_started = dt.datetime(2026, 5, 12, 1, 0, tzinfo=dt.timezone.utc)
    fs_client.collection("sync_state").docs["preprocessor"] = {
        "shadow_started_at": shadow_started,
    }
    fs_client.collection("queues").docs["old"] = {
        "message_id": "msg-old",
        "attempt_id": "attempt-old",
        "created_at": dt.datetime(2026, 5, 12, 0, 0, tzinfo=dt.timezone.utc),
    }
    fs_client.collection("queues").docs["new"] = {
        "message_id": "msg-new",
        "attempt_id": "attempt-new",
        "created_at": dt.datetime(2026, 5, 12, 1, 5, tzinfo=dt.timezone.utc),
    }
    firestore_mod = SimpleNamespace(Client=lambda project: fs_client)
    monkeypatch.setattr(gate, "FIRESTORE_AVAILABLE", True)
    monkeypatch.setattr(gate, "firestore", firestore_mod)

    metrics, err = gate._query_preprocessor_gate("project-1")

    assert err is None
    assert metrics.unique_shadow_processed_count == 1
    assert metrics.duplicate_queue_doc_count_by_message_id == 0

    assert_workflow_boundary_clean("cloud_orchestrator_preprocessor_gate", {
        "message_id": "msg-new",
        "attempt_id": "attempt-new",
    }, [
        {
            "name": "preprocessor_gate_current_cohort",
            "role": "gate_metrics",
            "identity": {"message_id": "msg-new", "attempt_id": "attempt-new"},
            "status": "running",
            "accepted": False,
            "classification": "in_flight",
            "claims_completion": False,
        },
    ])
