from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch  # type: ignore

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediCafe import deductible_utils


def _parse_prefixed_json(message, prefix):
    idx = message.find(prefix)
    if idx < 0:
        return None
    return json.loads(message[idx + len(prefix):])


class _CaptureLogger(object):
    def __init__(self):
        self.records = []

    def log(self, message, config=None, level='INFO', error_type=None, claim=None, verbose=False, console_output=False):
        self.records.append((level, message))


class DeductibleCsvDiagnosticsTests(unittest.TestCase):
    def test_normalize_reconciliation_csv_row_accepts_cleaned_patient_id_number_2(self):
        row = {'Patient ID 2': '12345', 'Patient DOB': '01/02/1980'}
        normalized = deductible_utils.normalize_reconciliation_csv_row(row)
        self.assertEqual(normalized.get('patient_id'), '12345')
        self.assertEqual(normalized.get('patient_id_source_header'), 'Patient ID 2')

    def test_backfill_enhanced_result_accepts_cleaned_patient_id_number_2(self):
        result = deductible_utils.backfill_enhanced_result({}, {'Patient ID 2': '12345'})
        self.assertEqual(result.get('patient_id'), '12345')

    def test_filter_rows_finds_payer_id_under_payer_id_header(self):
        """Regression: CSV may use 'Payer ID' / 'payer_id' instead of 'Ins1 Payer ID'."""
        rows = [
            {'Patient DOB': '01/02/1980', 'Primary Policy Number': 'M1', 'Payer ID': '87726'},
            {'Patient DOB': '01/02/1980', 'Primary Policy Number': 'M2', 'Payer ID': '99999'},
        ]
        supported = ['87726']
        valid, available = deductible_utils.filter_rows_by_supported_payer_ids(rows, supported)
        self.assertEqual(len(valid), 1)
        self.assertEqual(valid[0].get('Primary Policy Number'), 'M1')
        self.assertEqual(available, {'87726', '99999'})

    def test_filter_rows_canonicalizes_numeric_payer_id_for_header_alias(self):
        rows = [
            {'payer_id': '87726.0', 'Primary Policy Number': 'M1', 'Patient DOB': '01/02/1980'},
        ]
        valid, available = deductible_utils.filter_rows_by_supported_payer_ids(rows, ['87726'])
        self.assertEqual(len(valid), 1)
        self.assertIn('87726.0', available)

    def test_filter_rows_emits_telemetry_when_no_supported_matches(self):
        rows = [
            {
                'Patient DOB': '01/02/1980',
                'Primary Policy Number': 'M1',
                'Payer ID': '87726',
            },
        ]
        capture = _CaptureLogger()
        original_logger = deductible_utils.MediLink_ConfigLoader
        try:
            deductible_utils.MediLink_ConfigLoader = capture
            valid, available = deductible_utils.filter_rows_by_supported_payer_ids(rows, ['99999'])
        finally:
            deductible_utils.MediLink_ConfigLoader = original_logger
        self.assertEqual(valid, [])
        self.assertEqual(available, {'87726'})
        telemetry_msgs = [
            m for level, m in capture.records
            if m.startswith('DEDUCTIBLE_PAYER_FILTER_TELEMETRY ')
        ]
        self.assertEqual(len(telemetry_msgs), 1)
        payload = _parse_prefixed_json(telemetry_msgs[0], 'DEDUCTIBLE_PAYER_FILTER_TELEMETRY ')
        self.assertEqual(payload.get('row_count'), 1)
        self.assertEqual(payload.get('distinct_resolved_payer_raw_values_sample'), ['87726'])
        self.assertEqual(
            (payload.get('payer_raw_value_shape_counts') or {}).get('numeric_id_shape'),
            1,
        )
        self.assertIn('payer_field_data_lineage_note', payload)
        top_payer_like = payload.get('payer_like_column_nonempty_top') or []
        headers = [item.get('header') for item in top_payer_like]
        self.assertIn('Payer ID', headers)

    def test_payer_filter_telemetry_labels_medisoft_style_cells(self):
        rows = [{'payer_id': 'UHC MEDICARE          31362', 'patient_id': '1'}]
        capture = _CaptureLogger()
        original_logger = deductible_utils.MediLink_ConfigLoader
        try:
            deductible_utils.MediLink_ConfigLoader = capture
            deductible_utils.filter_rows_by_supported_payer_ids(rows, ['87726'])
        finally:
            deductible_utils.MediLink_ConfigLoader = original_logger
        telemetry_msgs = [
            m for level, m in capture.records
            if m.startswith('DEDUCTIBLE_PAYER_FILTER_TELEMETRY ')
        ]
        payload = _parse_prefixed_json(telemetry_msgs[0], 'DEDUCTIBLE_PAYER_FILTER_TELEMETRY ')
        self.assertEqual(
            (payload.get('payer_raw_value_shape_counts') or {}).get('textual_label'),
            1,
        )
        self.assertGreaterEqual(payload.get('distinct_values_with_trailing_5digit_id', 0), 1)

    def test_filter_rows_accepts_primary_payer_id_header(self):
        rows = [
            {
                'Patient DOB': '01/02/1980',
                'Primary Policy Number': 'M1',
                'Primary Payer ID': '87726',
            },
        ]
        valid, available = deductible_utils.filter_rows_by_supported_payer_ids(rows, ['87726'])
        self.assertEqual(len(valid), 1)
        self.assertEqual(available, {'87726'})

    def test_payer_resolution_reports_lowercase_phase_d_shape(self):
        rows = [
            {
                'category': 'denial',
                'patient_id': 'PAT-1',
                'Surgery Date': '04/09/2026',
                'payer_id': '62308',
                'claim_key': 'ck1',
                'claim_number': 'cn1',
                'detail': 'x',
                'next_action': 'review',
            },
            {
                'category': 'denial',
                'patient_id': 'PAT-2',
                'Surgery Date': '04/10/2026',
                'payer_id': '87726',
                'claim_key': 'ck2',
                'claim_number': 'cn2',
                'detail': 'y',
                'next_action': 'review',
            },
        ]
        capture = _CaptureLogger()
        original_logger = deductible_utils.MediLink_ConfigLoader
        try:
            deductible_utils.MediLink_ConfigLoader = capture
            result = deductible_utils.resolve_payer_ids_from_csv(rows, {}, {}, None)
        finally:
            deductible_utils.MediLink_ConfigLoader = original_logger

        self.assertEqual(result, {})
        payloads = [
            _parse_prefixed_json(message, 'CSV_PAYER_RESOLUTION_TELEMETRY ')
            for level, message in capture.records
            if message.startswith('CSV_PAYER_RESOLUTION_TELEMETRY ')
        ]
        self.assertEqual(len(payloads), 1)
        payload = payloads[0]
        self.assertEqual(payload.get('row_count'), 2)
        self.assertEqual(payload.get('resolved_count'), 0)
        self.assertEqual(payload.get('skip_counts', {}).get('missing_payer_id'), 0)
        self.assertEqual(payload.get('skip_counts', {}).get('missing_dob'), 2)
        self.assertEqual(payload.get('skip_counts', {}).get('missing_member_id'), 2)
        self.assertEqual(payload.get('alternate_nonempty_counts', {}).get('payer', {}).get('payer_id'), 2)
        self.assertTrue(any(item.get('value') == 'denial' and item.get('count') == 2 for item in payload.get('category_values', [])))
        self.assertTrue(any(level == 'WARNING' and 'produced 0 mappings' in message for level, message in capture.records))

    def test_payer_resolution_consumes_normalized_modern_headers(self):
        rows = [
            {
                'patient_id': 'PAT-1',
                'dob': '01/02/1980',
                'member_id': 'MEM-1',
                'payer_id': '62308',
                'dos': '2026-04-09',
            },
        ]
        capture = _CaptureLogger()
        original_logger = deductible_utils.MediLink_ConfigLoader
        try:
            deductible_utils.MediLink_ConfigLoader = capture
            result = deductible_utils.resolve_payer_ids_from_csv(rows, {}, {}, None)
        finally:
            deductible_utils.MediLink_ConfigLoader = original_logger

        self.assertEqual(result, {('1980-01-02', 'MEM-1'): '62308'})

    def test_payer_resolution_rejects_textual_iname_labels(self):
        rows = [
            {
                'patient_id': 'PAT-1',
                'dob': '01/02/1980',
                'member_id': 'MEM-1',
                'payer_id': 'UNITED HEALTHCARE',
            },
            {
                'patient_id': 'PAT-2',
                'dob': '01/03/1980',
                'member_id': 'MEM-2',
                'payer_id': '87726',
            },
        ]
        result = deductible_utils.resolve_payer_ids_from_csv(rows, {}, {}, ['87726'])
        self.assertEqual(result, {('1980-01-03', 'MEM-2'): '87726'})

    def test_get_payer_id_for_patient_returns_only_5_digit_ids(self):
        cache = {('1980-01-02', 'MEM-1'): 'UNITED'}
        out = deductible_utils.get_payer_id_for_patient('01/02/1980', 'MEM-1', cache)
        self.assertIsNone(out)

    def test_patient_tuple_diagnostics_reports_required_field_drop_reasons(self):
        from MediLink import MediLink_Deductible_v1_5 as deductible_v15
        rows = [
            {
                'category': 'denial',
                'patient_id': 'PAT-1',
                'Surgery Date': '04/09/2026',
                'payer_id': '62308',
                'claim_key': 'ck1',
                'claim_number': 'cn1',
                'detail': 'x',
                'next_action': 'review',
            },
            {
                'category': 'appeal',
                'patient_id': 'PAT-2',
                'Surgery Date': '04/10/2026',
                'payer_id': '62308',
                'claim_key': 'ck2',
                'claim_number': 'cn2',
                'detail': 'y',
                'next_action': 'hold',
            },
        ]
        records = []
        original_log = deductible_v15._log
        try:
            deductible_v15._log = lambda message, level='INFO': records.append((level, message))
            deductible_v15._emit_patient_tuple_build_diagnostics(
                rows,
                0,
                {
                    'missing_patient_id': 2,
                    'missing_dob': 2,
                    'missing_member_id': 2,
                    'invalid_dob': 0,
                    'row_exception': 0,
                },
            )
        finally:
            deductible_v15._log = original_log

        payloads = [
            _parse_prefixed_json(message, 'DEDUCTIBLE_CACHE_CSV_TELEMETRY ')
            for level, message in records
            if message.startswith('DEDUCTIBLE_CACHE_CSV_TELEMETRY ')
        ]
        self.assertEqual(len(payloads), 1)
        payload = payloads[0]
        self.assertEqual(payload.get('row_count'), 2)
        self.assertEqual(payload.get('patient_tuple_count'), 0)
        self.assertEqual(payload.get('drop_counts', {}).get('missing_dob'), 2)
        self.assertEqual(payload.get('alternate_nonempty_counts', {}).get('patient_id', {}).get('patient_id'), 2)
        self.assertEqual(payload.get('alternate_nonempty_counts', {}).get('payer', {}).get('payer_id'), 2)
        self.assertEqual(payload.get('column_nonempty_counts', {}).get('Surgery Date'), 2)
        self.assertTrue(any(level == 'WARNING' and 'produced 0 patient tuples' in message for level, message in records))

    def test_classify_marks_modern_reconciliation_csv_for_non_deductible_routing(self):
        rows = [
            {
                'category': 'denial',
                'patient_id': 'PAT-1',
                'Surgery Date': '04/09/2026',
                'payer_id': '62308',
                'claim_key': 'ck1',
                'claim_number': 'cn1',
                'detail': 'x',
                'next_action': 'review',
            },
        ]
        prof = deductible_utils.classify_csv_operational_profile(rows)
        self.assertEqual(prof.get('profile_name'), 'reconciliation_action_report')
        self.assertIn('deductible_cache_tuple_extraction_strict', prof.get('blocked_flows') or [])

    def test_run_batch_from_csv_skips_tuple_build_for_reconciliation_profile(self):
        from MediLink import MediLink_Deductible_v1_5 as dv15

        rows = [
            {
                'category': 'denial',
                'patient_id': 'PAT-1',
                'Surgery Date': '04/09/2026',
                'payer_id': '62308',
                'claim_key': 'ck1',
                'claim_number': 'cn1',
                'detail': 'x',
                'next_action': 'review',
            },
        ]

        class _Preproc(object):
            @staticmethod
            def load_csv_data(path):
                return rows

        temp = tempfile.mkdtemp()
        try:
            csv_path = os.path.join(temp, 'gate.csv')
            with open(csv_path, 'w', encoding='utf-8') as f:
                f.write('stub\n')
            cfg = {'CSV_FILE_PATH': csv_path}
            with patch.object(dv15, 'MediBot_Preprocessor_lib', _Preproc()):
                out = dv15.run_batch_from_csv(cfg, silent=True)
            self.assertEqual(out, [])
            self.assertEqual(
                dv15._last_batch_status.get('reason'),
                'csv_profile_skip_reconciliation_report',
            )
        finally:
            shutil.rmtree(temp, ignore_errors=True)

    def test_backfill_fills_service_date_when_sort_is_datetime_min(self):
        """Regression: API conversion leaves service_date_sort at datetime.min; CSV must backfill."""
        from datetime import datetime

        csv_row = {'Surgery Date': '04/09/2026'}
        result = {
            'patient_name': 'Test',
            'service_date_display': '',
            'service_date_sort': datetime.min,
            'status': 'Processed',
        }
        out = deductible_utils.backfill_enhanced_result(result, csv_row)
        self.assertEqual(out.get('service_date_display'), '04/09')
        self.assertNotEqual(out.get('service_date_sort'), datetime.min)

    def test_backfill_fills_sort_when_display_nonempty_but_sort_still_min(self):
        from datetime import datetime

        csv_row = {'Surgery Date': '12/31/2025'}
        result = {
            'patient_name': 'Test',
            'service_date_display': '12/31/2025',
            'service_date_sort': datetime.min,
            'status': 'Processed',
        }
        out = deductible_utils.backfill_enhanced_result(result, csv_row)
        self.assertNotEqual(out.get('service_date_sort'), datetime.min)

    def test_apply_report_recency_does_not_stale_when_dos_unknown(self):
        """API rows often keep datetime.min until backfill; missing CSV DOS must not force STALE."""
        from datetime import datetime

        from MediLink import MediLink_Deductible_v1_5 as dv15

        row = {
            'policy_status': 'Active',
            'service_date_sort': datetime.min,
            'service_date_display': '',
        }
        out = dv15._apply_report_recency_fields(row, None, max_age_days=90)
        self.assertEqual(out.get('policy_status'), 'Active')

    def test_apply_report_recency_marks_stale_when_dos_old(self):
        from datetime import datetime, timedelta

        from MediLink import MediLink_Deductible_v1_5 as dv15

        old = datetime.now() - timedelta(days=100)
        row = {'policy_status': 'Active'}
        out = dv15._apply_report_recency_fields(row, old, max_age_days=90)
        self.assertEqual(out.get('policy_status'), 'STALE')

    def test_apply_report_recency_parses_service_date_key_when_sort_unset(self):
        from datetime import datetime

        from MediLink import MediLink_Deductible_v1_5 as dv15

        iso = datetime.now().strftime('%Y-%m-%d')
        row = {
            'policy_status': 'Active',
            'service_date_sort': datetime.min,
            'service_date_display': '',
            # Recent ISO date vs real clock — must not label Active as STALE.
            'service_date': iso,
        }
        out = dv15._apply_report_recency_fields(row, None, max_age_days=90)
        self.assertEqual(out.get('policy_status'), 'Active')
        parsed = datetime.strptime(iso, '%Y-%m-%d')
        self.assertEqual(out.get('service_date_sort'), parsed)
        self.assertEqual(out.get('service_date_display'), parsed.strftime('%m/%d'))

    def test_apply_report_recency_stale_when_min_sort_but_old_service_date_field(self):
        """datetime.min is truthy; recency must still read service_date for staleness."""
        from datetime import datetime, timedelta

        from MediLink import MediLink_Deductible_v1_5 as dv15

        old_iso = (datetime.now() - timedelta(days=100)).strftime('%Y-%m-%d')
        row = {
            'policy_status': 'Active',
            'service_date_sort': datetime.min,
            'service_date_display': '',
            'service_date': old_iso,
        }
        out = dv15._apply_report_recency_fields(row, None, max_age_days=90)
        self.assertEqual(out.get('policy_status'), 'STALE')

    def test_try_write_eligibility_report_raises_on_writer_import_failure(self):
        """Silent import failure must not look like a successful report write to callers."""
        from MediLink import MediLink_Deductible_v1_5 as dv15

        real_import = __import__

        def _fake_import(name, globals=None, locals=None, fromlist=(), level=0):
            if name == 'MediLink.MediLink_Deductible':
                raise ImportError('simulated_missing_writer')
            return real_import(name, globals, locals, fromlist, level)

        patients = [('1', '01/01/1980', 'M1', '87726', None)]
        with patch('builtins.__import__', side_effect=_fake_import):
            with self.assertRaises(RuntimeError) as ctx:
                dv15._try_write_eligibility_report_txt({}, patients, [])
        self.assertIn('eligibility_report_dependencies_missing', str(ctx.exception))

    def test_run_menu_eligibility_report_marks_failure_when_write_raises(self):
        """API batch success must not stamp _last_batch_status ok if report write fails."""
        from MediLink import MediLink_Deductible_v1_5 as dv15

        one = [('1', '01/01/1980', 'M1', '87726', None)]
        cfg = {'CSV_FILE_PATH': __file__}
        with patch.object(dv15, 'prepare_deductible_batch_patients', return_value=(one, cfg, True)), \
                patch.object(dv15, 'filter_patients_for_menu_eligibility_report', return_value=one), \
                patch.object(dv15, 'run_batch', return_value=[]), \
                patch.object(dv15, '_try_write_eligibility_report_txt', side_effect=OSError('write failed')):
            ok = dv15.run_menu_eligibility_report(cfg, silent=True)
        self.assertFalse(ok)
        st = dv15.get_last_batch_status()
        self.assertFalse(st.get('success'))
        self.assertEqual(st.get('reason'), 'eligibility_report_write_failed')

    def test_write_eligibility_report_cache_only_marks_failure_when_write_raises(self):
        """Cache-only report path must not leave stale success in _last_batch_status."""
        from MediLink import MediLink_Deductible_v1_5 as dv15

        one = [('1', '01/01/1980', 'M1', '87726', None)]
        cfg = {'CSV_FILE_PATH': __file__}
        with patch.object(dv15, 'prepare_deductible_batch_patients', return_value=(one, cfg, True)), \
                patch.object(dv15, '_try_write_eligibility_report_txt', side_effect=OSError('write failed')):
            ok = dv15.write_eligibility_report_cache_only(cfg, silent=True)
        self.assertFalse(ok)
        st = dv15.get_last_batch_status()
        self.assertFalse(st.get('success'))
        self.assertEqual(st.get('reason'), 'eligibility_report_write_failed')

    def test_run_batch_from_csv_marks_failure_when_eligibility_report_write_raises(self):
        """Batch completion must not record ok when optional eligibility_report write fails."""
        from MediLink import MediLink_Deductible_v1_5 as dv15

        one = [('1', '01/01/1980', 'M1', '87726', None)]
        cfg = {'CSV_FILE_PATH': __file__}
        with patch.object(dv15, 'prepare_deductible_batch_patients', return_value=(one, cfg, True)), \
                patch.object(dv15, 'run_batch', return_value=['processed']), \
                patch.object(dv15, '_try_write_eligibility_report_txt', side_effect=OSError('write failed')):
            out = dv15.run_batch_from_csv(cfg, silent=True, write_eligibility_report=True)
        self.assertEqual(out, ['processed'])
        st = dv15.get_last_batch_status()
        self.assertFalse(st.get('success'))
        self.assertEqual(st.get('reason'), 'eligibility_report_write_failed')

    def test_apply_report_recency_fallback_when_display_is_datetime_min(self):
        """datetime.min in service_date_display must not block service_date (same truthiness pitfall)."""
        from datetime import datetime, timedelta

        from MediLink import MediLink_Deductible_v1_5 as dv15

        old_iso = (datetime.now() - timedelta(days=100)).strftime('%Y-%m-%d')
        row = {
            'policy_status': 'Active',
            'service_date_sort': None,
            'service_date_display': datetime.min,
            'service_date': old_iso,
        }
        out = dv15._apply_report_recency_fields(row, None, max_age_days=90)
        self.assertEqual(out.get('policy_status'), 'STALE')


if __name__ == '__main__':
    unittest.main()
