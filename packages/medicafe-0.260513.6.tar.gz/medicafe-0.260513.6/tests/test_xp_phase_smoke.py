import json
import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
UM_ROOT = os.path.join(REPO_ROOT, "scripts", "unified_model")
if UM_ROOT not in sys.path:
    sys.path.insert(0, UM_ROOT)

from xp_phase_smoke import build_smoke_result, main, _write_json  # noqa: E402
from workflow_boundary_contract import assert_workflow_boundary_clean  # noqa: E402


def _write_fixture_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)


class XPPhaseSmokeTests(unittest.TestCase):
    def test_smoke_writer_still_returns_false_for_non_serializable_payload(self):
        td = tempfile.mkdtemp()
        try:
            path = os.path.join(td, "reports", "bad.json")
            ok = _write_json(path, {"bad": set([1])})
            self.assertFalse(ok)
            self.assertFalse(os.path.exists(path))
            self.assertFalse(os.path.exists(path + ".tmp"))
        finally:
            shutil.rmtree(td)

    def test_smoke_reports_current_phase_c_attempt_blocker(self):
        td = tempfile.mkdtemp()
        try:
            reports = os.path.join(td, "reports")
            os.makedirs(reports)
            manifest = os.path.join(td, "manifest.json")
            _write_fixture_json(manifest, {"ok": True})
            _write_fixture_json(
                os.path.join(reports, "phase_c_current_attempt_latest.json"),
                {
                    "schema_version": 1,
                    "phase_c_attempt_id": "run-phase-c",
                    "last_reached_stage": "not_entered",
                    "current_blocker": "phase_c_script_entrypoint_not_observed_current_attempt",
                },
            )
            _write_fixture_json(
                os.path.join(td, "diagnostics_state.json"),
                {
                    "last_manifest_path": manifest,
                    "last_manifest_sha256": "sha-1",
                    "last_phase_c_current_attempt_path": os.path.join(
                        reports, "phase_c_current_attempt_latest.json"),
                },
            )
            _write_fixture_json(os.path.join(td, "run_cursor.json"), {})

            result = build_smoke_result(td)
            phase_c = [row for row in result["phases"] if row["phase"] == "C"][0]
            self.assertEqual(phase_c["status"], "blocked")
            self.assertEqual(
                phase_c["blocker"],
                "phase_c_script_entrypoint_not_observed_current_attempt",
            )
            self.assertEqual(result["overall_status"], "blocked")
            assert_workflow_boundary_clean("xp_phase_smoke_phase_c", {
                "phase_c_attempt_id": "run-phase-c",
            }, [
                {
                    "name": "phase_c_current_attempt_latest.json",
                    "role": "attempt",
                    "identity": {"phase_c_attempt_id": "run-phase-c"},
                    "status": "running",
                },
                {
                    "name": "xp_phase_smoke_latest.json",
                    "role": "consumer",
                    "identity": {"phase_c_attempt_id": "run-phase-c"},
                    "classification": "partial",
                    "claims_completion": False,
                },
            ])
        finally:
            shutil.rmtree(td)

    def test_smoke_marks_interface_sha_mismatch(self):
        td = tempfile.mkdtemp()
        try:
            reports = os.path.join(td, "reports")
            os.makedirs(reports)
            _write_fixture_json(
                os.path.join(td, "diagnostics_state.json"),
                {
                    "last_manifest_sha256": "sha-b",
                    "last_ingest_manifest_sha256": "sha-c",
                },
            )
            _write_fixture_json(os.path.join(td, "run_cursor.json"), {})
            result = build_smoke_result(td)
            interfaces = [row for row in result["phases"] if row["phase"] == "interfaces"][0]
            self.assertEqual(interfaces["status"], "blocked")
            self.assertEqual(interfaces["blocker"], "phase_b_c_manifest_sha_mismatch")
        finally:
            shutil.rmtree(td)

    def test_main_writes_json_report_with_trailing_newline(self):
        td = tempfile.mkdtemp()
        try:
            reports = os.path.join(td, "reports")
            os.makedirs(reports)
            manifest = os.path.join(td, "manifest.json")
            _write_fixture_json(manifest, {"ok": True})
            _write_fixture_json(
                os.path.join(td, "diagnostics_state.json"),
                {
                    "last_manifest_path": manifest,
                    "last_manifest_sha256": "sha-ok",
                    "last_ingest_manifest_sha256": "sha-ok",
                    "last_phase_d_run_id": "d-ok",
                    "last_phase_e_run_id": "e-ok",
                },
            )
            _write_fixture_json(os.path.join(td, "run_cursor.json"), {})
            _write_fixture_json(
                os.path.join(reports, "phase_c_current_attempt_latest.json"),
                {
                    "schema_version": 1,
                    "phase_c_attempt_id": "run-ok",
                    "last_reached_stage": "handoff_report",
                    "current_blocker": "phase_c_current_attempt_ok",
                },
            )
            _write_fixture_json(os.path.join(reports, "qa_canonical_summary_d-ok.json"), {"ok": True})
            _write_fixture_json(os.path.join(reports, "projection_parity_summary_e-ok.json"), {"ok": True})

            rc = main(["--lab-dir", td])

            self.assertEqual(rc, 0)
            json_path = os.path.join(reports, "xp_phase_smoke_latest.json")
            with open(json_path, "r", encoding="utf-8") as handle:
                text = handle.read()
            self.assertTrue(text.endswith("\n"))
            self.assertEqual(json.loads(text)["overall_status"], "ok")
        finally:
            shutil.rmtree(td)


if __name__ == "__main__":
    unittest.main()
