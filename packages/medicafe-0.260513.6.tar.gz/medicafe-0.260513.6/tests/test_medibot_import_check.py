import importlib.util
import os
import sys


def _load_medibot_module():
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    medibot_dir = os.path.join(repo_root, 'MediBot')
    module_path = os.path.join(medibot_dir, 'MediBot.py')
    sys.path.insert(0, medibot_dir)
    try:
        spec = importlib.util.spec_from_file_location('medibot_main_import_check_test', module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        try:
            sys.path.remove(medibot_dir)
        except ValueError:
            pass


def test_successful_critical_import_check_is_log_only(monkeypatch, capsys):
    import MediCafe.core_utils as core_utils

    medibot = _load_medibot_module()
    messages = []

    class FakeLoader(object):
        @staticmethod
        def log(message, level='INFO', *args, **kwargs):
            messages.append((level, message))

    monkeypatch.setattr(core_utils, 'import_medibot_module_with_debug', lambda name: object())
    monkeypatch.setattr(medibot, 'MediLink_ConfigLoader', FakeLoader)

    ok, modules = medibot.validate_critical_imports()

    out = capsys.readouterr().out
    assert ok is True
    assert len(modules) == 4
    assert 'Import check:' not in out
    assert ('INFO', 'Import check: 4/4 critical modules loaded') in messages
