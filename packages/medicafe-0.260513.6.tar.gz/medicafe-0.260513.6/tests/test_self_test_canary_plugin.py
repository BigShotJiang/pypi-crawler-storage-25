import json
import os
import shutil

from MediCafe import self_test_canary_plugin as plugin


def _runtime(tmp_path):
    return {
        "config": {
            "CSV_FILE_PATH": str(tmp_path / "production" / "SX_CSV_real.csv"),
            "MediLink_Config": {
                "local_storage_path": str(tmp_path),
            },
        },
        "medi": {
            "local_storage_path": str(tmp_path),
            "logging": {},
            "TestMode": False,
        },
        "crosswalk": {},
        "diagnostics": {},
    }


def _read_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _write_json(path, payload):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True)
        handle.write("\n")


def _effective_csv_path(config_file):
    data = _read_json(config_file)
    local_path = os.path.join(os.path.dirname(config_file), "config.local.json")
    if os.path.isfile(local_path):
        local = _read_json(local_path)
        if local.get("CSV_FILE_PATH"):
            return local.get("CSV_FILE_PATH")
    return data.get("CSV_FILE_PATH", "")


def _fake_run_csv_intake(source_folder, target_folder, config_file, local_storage_path):
    # Quarantine non-intake storage CSVs.
    quarantine = os.path.join(local_storage_path, "non_intake_csv")
    for name in os.listdir(local_storage_path):
        path = os.path.join(local_storage_path, name)
        if not name.lower().endswith(".csv") or not os.path.isfile(path):
            continue
        shape = plugin._default_classify_csv(path)
        if not shape.get("ok"):
            if not os.path.isdir(quarantine):
                os.makedirs(quarantine)
            dest = os.path.join(
                quarantine,
                "NON_INTAKE_{0}_fake_{1}".format(shape.get("reason", "non_intake"), name),
            )
            shutil.move(path, dest)

    # Promote the newest good source CSV.
    for name in os.listdir(source_folder):
        path = os.path.join(source_folder, name)
        if not name.lower().endswith(".csv") or not os.path.isfile(path):
            continue
        shape = plugin._default_classify_csv(path)
        if shape.get("ok"):
            dest = os.path.join(target_folder, "SX_CSV_20990101_000000_000001.csv")
            shutil.move(path, dest)
            data = _read_json(config_file)
            data["CSV_FILE_PATH"] = dest
            _write_json(config_file, data)
            return {"ok": True, "action": "promoted", "path": dest}

    # Repair poisoned configured CSV_FILE_PATH when a valid target fallback exists.
    current = _effective_csv_path(config_file)
    current_shape = plugin._default_classify_csv(current)
    if current and not current_shape.get("ok"):
        for name in sorted(os.listdir(target_folder), reverse=True):
            path = os.path.join(target_folder, name)
            if not name.upper().startswith("SX_CSV_") or not os.path.isfile(path):
                continue
            if os.path.normcase(os.path.abspath(path)) == os.path.normcase(os.path.abspath(current)):
                continue
            shape = plugin._default_classify_csv(path)
            if shape.get("ok"):
                data = _read_json(config_file)
                data["CSV_FILE_PATH"] = path
                _write_json(config_file, data)
                return {"ok": True, "action": "repaired", "path": path}
        return {"ok": True, "action": "repair_unavailable"}
    return {"ok": True, "action": "noop"}


def _fake_update_csv_path_refuses(_config_file, _csv_path):
    return {
        "ok": False,
        "return_code": 1,
        "reason": "action_or_reconciliation_csv",
    }


def _fake_phase_d_short_circuit(_env):
    return {
        "ok": True,
        "source_exception_class": "CsvOperationalShape",
        "warning_code": "QA_PARSE_ERROR",
    }


def _hooks():
    return {
        plugin.HOOK_RUN_CSV_INTAKE: _fake_run_csv_intake,
        plugin.HOOK_UPDATE_CSV_PATH: _fake_update_csv_path_refuses,
        plugin.HOOK_RUN_PHASE_D_QA: _fake_phase_d_short_circuit,
    }


def _row(report, scenario_id):
    for item in report.get("scenario_results", []):
        if item.get("id") == scenario_id:
            return item
    raise AssertionError("missing scenario: {}".format(scenario_id))


def _fixture_by_id(row, logical_id):
    observed = row.get("observed") or {}
    for item in observed.get("fixtures") or []:
        if item.get("logical_id") == logical_id:
            return item
    raise AssertionError("missing fixture: {}".format(logical_id))


def test_describe_plugin_exposes_stable_api_and_scenarios():
    desc = plugin.describe_plugin()

    assert desc["plugin_id"] == "xp_workflow_boundary_canary"
    assert desc["schema_version"] == 1
    assert plugin.SCENARIO_POISONED_REPAIR_AVAILABLE in desc["scenario_ids"]
    assert plugin.HOOK_RUN_CSV_INTAKE in desc["required_hooks"]
    assert "self_test_canary_report.json" in desc["output_files"]


def test_fixture_generation_records_good_and_bad_headers(tmp_path):
    report = plugin.run_canary(
        runtime_context=_runtime(tmp_path),
        hooks={},
        scenario_ids=[plugin.SCENARIO_POISONED_REPAIR_AVAILABLE],
    )

    row = _row(report, plugin.SCENARIO_POISONED_REPAIR_AVAILABLE)
    good = _fixture_by_id(row, "good_target_csv")
    bad = _fixture_by_id(row, "bad_target_csv")

    assert good["raw_headers"][:4] == ["Surgery Date", "Patient ID", "Patient Last", "Patient First"]
    assert bad["raw_headers"] == [
        "category",
        "patient_id",
        "dos",
        "payer_id",
        "claim_key",
        "claim_number",
        "detail",
        "next_action",
    ]


def test_bad_sx_csv_classifies_as_action_or_reconciliation(tmp_path):
    report = plugin.run_canary(
        runtime_context=_runtime(tmp_path),
        hooks={},
        scenario_ids=[plugin.SCENARIO_POISONED_REPAIR_AVAILABLE],
    )
    row = _row(report, plugin.SCENARIO_POISONED_REPAIR_AVAILABLE)
    bad = _fixture_by_id(row, "bad_target_csv")

    assert bad["basename"].startswith("SX_CSV_")
    assert bad["basename"].endswith(".csv")
    assert row["status"] == plugin.STATUS_SKIPPED

    # The generated header itself carries the workflow-boundary marker.
    assert "claim_key" in bad["raw_headers"]
    assert "next_action" in bad["raw_headers"]


def test_temp_config_uses_canary_path_without_mutating_runtime_config(tmp_path):
    runtime = _runtime(tmp_path)
    original = runtime["config"]["CSV_FILE_PATH"]

    report = plugin.run_canary(
        runtime_context=runtime,
        hooks=_hooks(),
        scenario_ids=[plugin.SCENARIO_POISONED_REPAIR_AVAILABLE],
    )

    row = _row(report, plugin.SCENARIO_POISONED_REPAIR_AVAILABLE)
    assert row["status"] == plugin.STATUS_PASS
    assert runtime["config"]["CSV_FILE_PATH"] == original
    assert row["observed"]["before_csv_path"] != original
    assert os.path.basename(row["observed"]["before_csv_path"]).startswith("SX_CSV_")


def test_missing_hooks_skip_without_crashing(tmp_path):
    report = plugin.run_canary(
        runtime_context=_runtime(tmp_path),
        hooks={},
        scenario_ids=[
            plugin.SCENARIO_POISONED_REPAIR_AVAILABLE,
            plugin.SCENARIO_LOCAL_STORAGE_QUARANTINE,
        ],
    )

    assert report["summary"]["skipped_count"] == 2
    assert _row(report, plugin.SCENARIO_POISONED_REPAIR_AVAILABLE)["blocker_class"] == "hook_unavailable"
    assert _row(report, plugin.SCENARIO_LOCAL_STORAGE_QUARANTINE)["blocker_class"] == "hook_unavailable"


def test_fake_hooks_drive_core_boundary_scenarios_to_pass(tmp_path):
    report = plugin.run_canary(runtime_context=_runtime(tmp_path), hooks=_hooks())

    expected_pass = [
        plugin.SCENARIO_POISONED_REPAIR_AVAILABLE,
        plugin.SCENARIO_POISONED_REPAIR_UNAVAILABLE,
        plugin.SCENARIO_LOCAL_STORAGE_QUARANTINE,
        plugin.SCENARIO_GOOD_INTAKE_PROMOTION,
        plugin.SCENARIO_UPDATE_JSON_REFUSAL,
        plugin.SCENARIO_PHASE_D_SHORT_CIRCUIT,
    ]
    for scenario_id in expected_pass:
        row = _row(report, scenario_id)
        assert row["status"] == plugin.STATUS_PASS, json.dumps(row, indent=2, sort_keys=True)
    assert report["summary"]["pass_count"] == len(expected_pass)
    assert report["summary"]["fail_count"] == 0


def test_build_bundle_extra_files_returns_bundle_safe_aliases(tmp_path):
    report = plugin.run_canary(
        runtime_context=_runtime(tmp_path),
        hooks={},
        scenario_ids=[plugin.SCENARIO_POISONED_REPAIR_AVAILABLE],
    )

    extra = plugin.build_bundle_extra_files(report)
    names = [item[0] for item in extra]

    assert names == ["self_test_canary_report.json", "SELF_TEST_CANARY_README.txt"]
    assert isinstance(extra[0][1], dict)
    assert "Workflow-Boundary Canary" in extra[1][1]

    summary = plugin.summarize_canary_report(report)
    assert summary["plugin_id"] == plugin.PLUGIN_ID
    assert "scenario_results" not in summary
