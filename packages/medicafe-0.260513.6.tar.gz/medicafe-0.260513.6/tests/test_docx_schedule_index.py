#!/usr/bin/env python
from __future__ import print_function

import os
import tempfile
import unittest
import zipfile

from MediBot import MediBot_docx_index as docx_index
from MediBot import MediBot_docx_decoder as docx_decoder


def _write_minimal_docx_package(path):
    with zipfile.ZipFile(path, 'w') as archive:
        archive.writestr('[Content_Types].xml', '<Types></Types>')
        archive.writestr('word/document.xml', '<w:document></w:document>')


class DocxScheduleIndexTests(unittest.TestCase):

    def test_targeted_update_records_status_and_skips_unchanged_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'sample.docx')
            _write_minimal_docx_package(docx_path)

            parse_calls = []
            original_parse = docx_index.parse_docx
            try:
                def fake_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    parse_calls.append((filepath, capture_schedule_positions))
                    return {
                        '03-19-2026': {
                            '123': {
                                'diagnosis': 'H25.9',
                                'eye': 'OD',
                                'femto': ''
                            }
                        }
                    }

                docx_index.parse_docx = fake_parse

                _, first_stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    source='gmail_download'
                )
                self.assertEqual(first_stats.get('parsed'), 1)
                self.assertEqual(len(parse_calls), 1)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'gmail_download')
                self.assertEqual(status.get('mode'), 'targeted')
                self.assertEqual(status.get('requested_file_count'), 1)
                self.assertTrue(status.get('capture_schedule_positions'))
                self.assertEqual(status.get('stats', {}).get('parsed'), 1)

                _, second_stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=True,
                    source='gmail_download'
                )
                self.assertEqual(second_stats.get('parsed'), 0)
                self.assertEqual(second_stats.get('skipped'), 1)
                self.assertEqual(len(parse_calls), 1)
            finally:
                docx_index.parse_docx = original_parse

    def test_full_scan_status_records_source(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'scan.docx')
            _write_minimal_docx_package(docx_path)

            original_parse = docx_index.parse_docx
            try:
                def fake_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    return {
                        '03-20-2026': {
                            '456': {
                                'diagnosis': 'H26.9',
                                'eye': 'OS',
                                'femto': ''
                            }
                        }
                    }

                docx_index.parse_docx = fake_parse

                _, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=None,
                    capture_schedule_positions=False,
                    source='medibot_preprocess'
                )
                self.assertEqual(stats.get('parsed'), 1)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'medibot_preprocess')
                self.assertEqual(status.get('mode'), 'full_scan')
                self.assertEqual(status.get('requested_file_count'), 1)
                self.assertFalse(status.get('capture_schedule_positions'))
                self.assertEqual(status.get('stats', {}).get('parsed'), 1)
            finally:
                docx_index.parse_docx = original_parse


    def test_parser_unavailable_full_scan_status_preserves_mode(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            original_parse = docx_index.parse_docx
            try:
                docx_index.parse_docx = None

                _, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=None,
                    capture_schedule_positions=False,
                    source='cli_rebuild'
                )
                self.assertEqual(stats.get('parsed'), 0)

                status = docx_index.load_docx_schedule_index_status(tmpdir)
                self.assertEqual(status.get('source'), 'cli_rebuild')
                self.assertEqual(status.get('mode'), 'full_scan')
                self.assertIsNone(status.get('requested_file_count'))
                self.assertFalse(status.get('parser_available'))
            finally:
                docx_index.parse_docx = original_parse

    def test_docx_index_parse_failure_logs_basename_and_demotes_repeats(self):
        captured = []
        original_log = docx_index._log
        try:
            docx_index._DOCX_INDEX_PARSE_FAILURE_COUNTS.clear()
            docx_index._DOCX_INDEX_PARSE_FAILURE_SAMPLES.clear()
            docx_index._log = lambda message, level="INFO": captured.append((level, message))
            path = 'C:\\sensitive\\clinic\\folder\\bad.docx'
            exc = ValueError('cannot parse C:\\sensitive\\clinic\\folder\\bad.docx')

            docx_index._log_parse_failure(path, 'content_error', exc)
            docx_index._log_parse_failure(path, 'content_error', exc)
        finally:
            docx_index._log = original_log

        self.assertEqual(captured[0][0], 'WARNING')
        self.assertIn('file=bad.docx', captured[0][1])
        self.assertNotIn('C:\\sensitive\\clinic\\folder', captured[0][1])
        self.assertEqual(captured[1][0], 'DEBUG')
        self.assertIn('repeat suppressed', captured[1][1])

    def test_invalid_docx_package_is_recorded_without_calling_parser(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            docx_path = os.path.join(tmpdir, 'tiny_bad.docx')
            with open(docx_path, 'wb') as handle:
                handle.write(b'not a zip')

            original_parse = docx_index.parse_docx
            try:
                def unexpected_parse(filepath, surgery_dates=None, capture_schedule_positions=False):
                    raise AssertionError('invalid package should not reach parser')

                docx_index.parse_docx = unexpected_parse
                index_data, stats = docx_index.update_docx_schedule_index(
                    tmpdir,
                    filepaths=[docx_path],
                    capture_schedule_positions=False,
                    source='invalid_package_test'
                )
            finally:
                docx_index.parse_docx = original_parse

            self.assertEqual(stats.get('parsed'), 1)
            self.assertEqual(stats.get('errors'), 1)
            self.assertEqual(stats.get('invalid_docx_package'), 1)
            rec = index_data.get('files', {}).get('tiny_bad.docx', {})
            self.assertTrue(rec.get('parse_failed'))
            self.assertEqual(rec.get('parse_error_type'), 'invalid_docx_package')
            self.assertEqual(rec.get('docx_package_reason'), 'not_zip_package')

    def test_docx_decoder_open_failure_logs_basename_and_demotes_repeats(self):
        captured = []
        original_log = docx_decoder.MediLink_ConfigLoader.log
        try:
            docx_decoder._DOCX_OPEN_FAILURE_COUNTS.clear()
            docx_decoder._DOCX_OPEN_FAILURE_SAMPLES.clear()
            docx_decoder.MediLink_ConfigLoader.log = lambda message, level="INFO": captured.append((level, message))
            path = 'C:\\sensitive\\clinic\\folder\\bad.docx'
            exc = IOError('cannot open C:\\sensitive\\clinic\\folder\\bad.docx')

            docx_decoder._log_docx_open_failure('parse_docx_document', path, exc)
            docx_decoder._log_docx_open_failure('parse_docx_document', path, exc)
        finally:
            docx_decoder.MediLink_ConfigLoader.log = original_log

        self.assertEqual(captured[0][0], 'ERROR')
        self.assertIn('file=bad.docx', captured[0][1])
        self.assertNotIn('C:\\sensitive\\clinic\\folder', captured[0][1])
        self.assertEqual(captured[1][0], 'DEBUG')
        self.assertIn('repeat suppressed', captured[1][1])

if __name__ == '__main__':
    unittest.main()

