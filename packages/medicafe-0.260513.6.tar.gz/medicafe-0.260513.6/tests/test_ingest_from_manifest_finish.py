# -*- coding: utf-8 -*-
"""main() finish-coherence and ingest diagnostics stamp coverage (pytest runs unittest)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)
_TESTS = os.path.dirname(os.path.abspath(__file__))
if _TESTS not in sys.path:
    sys.path.insert(0, _TESTS)

from phase_c_common import PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION, PHASE_C_LOCK_FAIL
from workflow_boundary_contract import assert_workflow_boundary_clean


class TestIngestFromManifestMainFinish(unittest.TestCase):
    def test_main_exits_on_missing_ingest_diagnostics(self):
        from ingest_from_manifest import main

        lab = tempfile.mkdtemp(prefix="mc_ingest_fin_")
        reports = os.path.join(lab, "reports")
        os.makedirs(reports)
        rid = "finish-miss-1"
        summary = {
            "run_id": rid,
            "manifest_sha256": "abc123",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 0,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        with open(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), "w", encoding="utf-8") as f:
            json.dump(summary, f)
        for name in ("run_cursor.json", "diagnostics_state.json"):
            with open(os.path.join(lab, name), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": rid,
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "abc123",
                        "last_ingest_from_manifest_diag_run_id": rid,
                    },
                    f,
                )
        argv_bak = sys.argv[:]
        stderr_buf = __import__("io").StringIO()
        try:
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab]
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                with patch("sys.stderr", stderr_buf):
                    with self.assertRaises(SystemExit) as ctx:
                        main()
            self.assertEqual(ctx.exception.code, 1)
            self.assertIn("finish_incoherent", stderr_buf.getvalue())
            self.assertIn("ingest_from_manifest_diagnostics", stderr_buf.getvalue())
        finally:
            sys.argv = argv_bak
            shutil.rmtree(lab, ignore_errors=True)

    def test_main_exits_on_diag_pointer_run_id_mismatch(self):
        from ingest_from_manifest import main

        lab = tempfile.mkdtemp(prefix="mc_ingest_fin_ptr_")
        reports = os.path.join(lab, "reports")
        os.makedirs(reports)
        rid = "finish-ptr-1"
        summary = {
            "run_id": rid,
            "manifest_sha256": "abc123",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 0,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        with open(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), "w", encoding="utf-8") as f:
            json.dump(summary, f)
        for fn in (
            "ingest_from_manifest_diagnostics_latest.json",
            "ingest_from_manifest_diagnostics_{0}.json".format(rid),
        ):
            with open(os.path.join(reports, fn), "w", encoding="utf-8") as f:
                json.dump({"schema_version": 1}, f)
        for name in ("run_cursor.json", "diagnostics_state.json"):
            with open(os.path.join(lab, name), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": rid,
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "abc123",
                        "last_ingest_from_manifest_diag_run_id": "other-rid",
                    },
                    f,
                )
        argv_bak = sys.argv[:]
        stderr_buf = __import__("io").StringIO()
        try:
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab]
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                with patch("sys.stderr", stderr_buf):
                    with self.assertRaises(SystemExit) as ctx:
                        main()
            self.assertEqual(ctx.exception.code, 1)
            self.assertIn("diag_run_id_mismatch", stderr_buf.getvalue())
            assert_workflow_boundary_clean("phase_c_finish_coherence", {
                "phase_c_run_id": rid,
            }, [
                {
                    "name": "ingest_write_summary",
                    "role": "artifact",
                    "identity": {"phase_c_run_id": rid},
                    "status": "failed",
                    "fail_closed": True,
                },
                {
                    "name": "main_exit",
                    "role": "consumer",
                    "identity": {"phase_c_run_id": rid},
                    "classification": "fail_closed",
                },
            ])
        finally:
            sys.argv = argv_bak
            shutil.rmtree(lab, ignore_errors=True)

    def test_main_exits_zero_when_finish_checks_pass(self):
        from ingest_from_manifest import main

        lab = tempfile.mkdtemp(prefix="mc_ingest_fin_ok_")
        reports = os.path.join(lab, "reports")
        os.makedirs(reports)
        rid = "finish-ok-1"
        summary = {
            "run_id": rid,
            "manifest_sha256": "abc123",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 1,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        with open(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), "w", encoding="utf-8") as f:
            json.dump(summary, f)
        for fn in (
            "ingest_from_manifest_diagnostics_latest.json",
            "ingest_from_manifest_diagnostics_{0}.json".format(rid),
        ):
            with open(os.path.join(reports, fn), "w", encoding="utf-8") as f:
                json.dump({"schema_version": 1}, f)
        for name in ("run_cursor.json", "diagnostics_state.json"):
            with open(os.path.join(lab, name), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": rid,
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "abc123",
                        "last_ingest_from_manifest_diag_run_id": rid,
                    },
                    f,
                )
        argv_bak = sys.argv[:]
        try:
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab]
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                main()
        finally:
            sys.argv = argv_bak
            shutil.rmtree(lab, ignore_errors=True)


class TestRunIngestLockFailCanonicalSummary(unittest.TestCase):
    def test_lock_fail_writes_schema_versioned_summary_with_lock_metadata(self):
        from ingest_from_manifest import run_ingest

        lab = tempfile.mkdtemp(prefix="mc_ingest_lock_")
        reports = os.path.join(lab, "reports")
        try:
            os.makedirs(reports)
            db_path = os.path.join(lab, "unified_model_xp.db")
            with open(db_path, "wb") as f:
                f.write(b"")
            manifest = os.path.join(reports, "artifact_manifest_lock.jsonl")
            with open(manifest, "w", encoding="utf-8") as f:
                f.write(
                    '{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv",'
                    '"mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n'
                )
            lock_meta = {
                "lock_path": os.path.join(lab, "shadow_pipeline.lock"),
                "lock_pid": "1234",
                "lock_heartbeat_at_utc": "2026-01-01T00:00:00Z",
                "lock_owner_running": True,
            }

            with patch("ingest_from_manifest.acquire_lock", side_effect=SystemExit(1)):
                with patch("ingest_from_manifest.read_lab_lock_diagnostic_metadata", return_value=lock_meta):
                    ok, rid, summary, error_code = run_ingest(lab, manifest)

            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_LOCK_FAIL)
            self.assertEqual(summary.get("error_code"), PHASE_C_LOCK_FAIL)
            self.assertEqual(summary.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertEqual(summary.get("lock_path"), lock_meta["lock_path"])
            self.assertEqual(summary.get("lock_pid"), lock_meta["lock_pid"])

            summary_path = os.path.join(reports, "ingest_write_summary_{0}.json".format(rid))
            self.assertTrue(os.path.isfile(summary_path))
            with open(summary_path, "r", encoding="utf-8") as f:
                on_disk = json.load(f)
            self.assertEqual(on_disk.get("error_code"), PHASE_C_LOCK_FAIL)
            self.assertEqual(on_disk.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertEqual(on_disk.get("lock_heartbeat_at_utc"), lock_meta["lock_heartbeat_at_utc"])
        finally:
            shutil.rmtree(lab, ignore_errors=True)


class TestBootstrapTimelineLabDirPrelude(unittest.TestCase):
    def test_timeline_and_bootstrap_latest_not_clobbered_on_wrong_lab_when_lab_dir_overrides(self):
        """MEDICAFE_LAB_DIR prelude must not reset timeline_latest or bootstrap_latest under that path when ingest targets --lab-dir."""
        import importlib

        lab_wrong = tempfile.mkdtemp(prefix="mc_ingest_tl_wrong_")
        lab_target = tempfile.mkdtemp(prefix="mc_ingest_tl_target_")
        env_bak = os.environ.get("MEDICAFE_LAB_DIR")
        argv_bak = sys.argv[:]
        rid = "tl-labdir-1"
        summary = {
            "run_id": rid,
            "manifest_sha256": "abc123",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 1,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        marker_doc = {"stage": "PRESERVE_MARKER", "stage_seq": 99, "schema_version": 1}
        try:
            os.makedirs(os.path.join(lab_wrong, "reports"), exist_ok=True)
            os.makedirs(os.path.join(lab_target, "reports"), exist_ok=True)
            wrong_tl = os.path.join(
                lab_wrong, "reports", "ingest_from_manifest_bootstrap_timeline_latest.jsonl"
            )
            wrong_boot = os.path.join(lab_wrong, "reports", "ingest_from_manifest_bootstrap_latest.json")
            with open(wrong_tl, "w", encoding="utf-8") as f:
                f.write(json.dumps(marker_doc) + "\n")
            with open(wrong_boot, "w", encoding="utf-8") as f:
                f.write(json.dumps({"stage": "PRESERVE_BOOTSTRAP_MARKER", "schema_version": 1}))
            with open(
                os.path.join(lab_target, "reports", "ingest_write_summary_{0}.json".format(rid)),
                "w",
                encoding="utf-8",
            ) as f:
                json.dump(summary, f)
            for fn in (
                "ingest_from_manifest_diagnostics_latest.json",
                "ingest_from_manifest_diagnostics_{0}.json".format(rid),
            ):
                with open(os.path.join(lab_target, "reports", fn), "w", encoding="utf-8") as f:
                    json.dump({"schema_version": 1}, f)
            for name in ("run_cursor.json", "diagnostics_state.json"):
                with open(os.path.join(lab_target, name), "w", encoding="utf-8") as f:
                    json.dump(
                        {
                            "last_phase_c_run_id": rid,
                            "last_phase_c_ok": True,
                            "last_ingest_manifest_sha256": "abc123",
                            "last_ingest_from_manifest_diag_run_id": rid,
                        },
                        f,
                    )
            os.environ["MEDICAFE_LAB_DIR"] = lab_wrong
            if "ingest_from_manifest" in sys.modules:
                importlib.reload(sys.modules["ingest_from_manifest"])
            from ingest_from_manifest import main

            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab_target]
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                main()
            with open(wrong_tl, "r", encoding="utf-8") as f:
                wrong_body = f.read()
            self.assertIn("PRESERVE_MARKER", wrong_body)
            with open(wrong_boot, "r", encoding="utf-8") as f:
                wrong_boot_body = f.read()
            self.assertIn("PRESERVE_BOOTSTRAP_MARKER", wrong_boot_body)
            right_tl = os.path.join(
                lab_target, "reports", "ingest_from_manifest_bootstrap_timeline_latest.jsonl"
            )
            self.assertTrue(os.path.isfile(right_tl))
            with open(right_tl, "r", encoding="utf-8") as f:
                lines = [ln.strip() for ln in f if ln.strip()]
            self.assertTrue(lines)
            stages = []
            for ln in lines:
                try:
                    o = json.loads(ln)
                except Exception:
                    continue
                if isinstance(o, dict):
                    stages.append(str(o.get("stage") or ""))
            self.assertNotIn("before_argparse", stages)
            self.assertIn("after_argparse", stages)
            right_boot = os.path.join(lab_target, "reports", "ingest_from_manifest_bootstrap_latest.json")
            self.assertTrue(os.path.isfile(right_boot))
            with open(right_boot, "r", encoding="utf-8") as f:
                boot_doc = json.load(f)
            self.assertNotEqual(str(boot_doc.get("stage") or "").strip(), "before_argparse")
        finally:
            sys.argv = argv_bak
            if env_bak is None:
                os.environ.pop("MEDICAFE_LAB_DIR", None)
            else:
                os.environ["MEDICAFE_LAB_DIR"] = env_bak
            if "ingest_from_manifest" in sys.modules:
                importlib.reload(sys.modules["ingest_from_manifest"])
            shutil.rmtree(lab_wrong, ignore_errors=True)
            shutil.rmtree(lab_target, ignore_errors=True)


class TestIngestDiagPointerStamp(unittest.TestCase):
    def test_stamp_skips_corrupt_state_preserves_lineage(self):
        """Corrupt JSON on disk must not be replaced by a near-empty doc (data-loss guard)."""
        from ingest_from_manifest import _write_ingest_from_manifest_diagnostics

        lab = tempfile.mkdtemp(prefix="mc_ingest_stamp_")
        reports = os.path.join(lab, "reports")
        os.makedirs(reports)
        rid = "stamp-skip-1"
        corrupt_marker = '{"last_phase_c_run_id": "KEEP_ME", NOT_JSON'
        state_path = os.path.join(lab, "diagnostics_state.json")
        cursor_path = os.path.join(lab, "run_cursor.json")
        with open(state_path, "w", encoding="utf-8") as f:
            f.write(corrupt_marker)
        with open(cursor_path, "w", encoding="utf-8") as f:
            f.write(corrupt_marker)
        summary = {
            "run_id": rid,
            "manifest_sha256": "deadbeef",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 0,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        try:
            _write_ingest_from_manifest_diagnostics(lab, True, rid, summary, "")
            with open(state_path, "r", encoding="utf-8") as f:
                after_state = f.read()
            with open(cursor_path, "r", encoding="utf-8") as f:
                after_cursor = f.read()
            self.assertIn("KEEP_ME", after_state)
            self.assertIn("KEEP_ME", after_cursor)
            self.assertIn("NOT_JSON", after_state)
        finally:
            shutil.rmtree(lab, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
