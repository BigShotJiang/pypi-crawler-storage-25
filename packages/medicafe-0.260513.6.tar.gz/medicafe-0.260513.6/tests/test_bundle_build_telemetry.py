# -*- coding: utf-8 -*-
"""Tests for support bundle build telemetry (meta.json + log line)."""
from __future__ import print_function

import json
import os
import shutil
import tempfile
import unittest
import zipfile

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

import MediCafe.MediLink_ConfigLoader as cfg_loader
import MediCafe.error_reporter as er
from MediCafe import bundle_build_telemetry as bbt


class TestBundleBuildTelemetryModule(unittest.TestCase):
    def tearDown(self):
        bbt.telemetry_session_reset()

    def test_finalize_includes_milestones_and_counts(self):
        bbt.telemetry_session_begin({'send_source': 'unit_test', 'system_health_pack': True})
        bbt.telemetry_record_milestone('stage_a')
        bbt.telemetry_record_milestone('stage_b')
        bbt.telemetry_merge_collect_counts(5, 500)
        bbt.telemetry_record_snapshot_build(1.25, 3, False)
        out = bbt.telemetry_finalize_for_meta('system_health_pack')
        self.assertEqual(out.get('schema_version'), 1)
        self.assertEqual(out.get('flow'), 'system_health_pack')
        self.assertEqual(out.get('send_source'), 'unit_test')
        self.assertTrue(out.get('total_build_sec', 0) >= 0)
        self.assertEqual(len(out.get('milestones') or []), 2)
        self.assertEqual((out.get('counts') or {}).get('extra_files'), 5)
        self.assertEqual((out.get('counts') or {}).get('max_log_lines'), 500)
        self.assertEqual(len(out.get('snapshot_events') or []), 1)
        self.assertEqual(out.get('telemetry_bundle_kind'), 'system_health_pack')
        self.assertEqual(out.get('telemetry_send_source'), 'unit_test')
        line = bbt.format_bundle_telemetry_log_line(out)
        self.assertIn('BUNDLE_TELEMETRY', line)
        self.assertIn('schema=1', line)

    def test_cloud_health_escalation_session_does_not_inherit_system_health_flow(self):
        bbt.telemetry_session_begin({'send_source': 'prior_shp', 'system_health_pack': True})
        bbt.telemetry_record_milestone('stale_shp_milestone')
        bbt.telemetry_begin_collect_session(
            {'send_source': 'cloud_health', 'cloud_health_failure': True},
            'cloud_health_escalation',
        )
        bbt.telemetry_record_milestone('zip_stage')
        out = bbt.telemetry_finalize_for_meta('cloud_health_escalation')
        self.assertEqual(out.get('flow'), 'cloud_health_escalation')
        self.assertEqual(out.get('telemetry_bundle_kind'), 'cloud_health_escalation')
        self.assertEqual(out.get('telemetry_send_source'), 'cloud_health')
        self.assertNotIn('stale_shp_milestone', [m.get('name') for m in (out.get('milestones') or [])])
        self.assertIn('zip_stage', [m.get('name') for m in (out.get('milestones') or [])])
        self.assertNotEqual(out.get('flow'), 'system_health_pack')

    def test_evidence_scope_prefers_manifest_scope_for_system_health_pack(self):
        scope = er._derive_evidence_scope({
            'bundle_kind': 'system_health_pack',
            'extra_context': {
                'system_health_pack': True,
                'anchor_run_id': 'live-latest',
                'evidence_scope': {
                    'bundle_kind': 'system_health_pack',
                    'scope_kind': 'system_health_pack',
                    'anchor_run_id': 'anchor-run',
                    'artifact_run_id': 'anchor-run',
                    'phase_artifact_scope': 'run_aligned',
                    'coherence_status': 'ready',
                    'phase_run_id_map': {'D': 'phase-d-anchor'},
                    'diagnostics_state_scope': 'lab_root_current',
                },
            },
        })
        self.assertEqual(scope.get('scope_kind'), 'system_health_pack')
        self.assertEqual(scope.get('anchor_run_id'), 'anchor-run')
        self.assertEqual(scope.get('phase_artifact_scope'), 'run_aligned')
        self.assertEqual(scope.get('coherence_status'), 'ready')
        self.assertEqual(scope.get('phase_run_id_map', {}).get('D'), 'phase-d-anchor')
        self.assertEqual(scope.get('phase_run_ids', {}).get('D'), 'phase-d-anchor')

    def test_flow_mismatch_strips_timing(self):
        bbt.telemetry_session_begin({'bundle_kind': 'system_health_pack', 'send_source': 'x'})
        bbt.telemetry_record_milestone('a')
        out = bbt.telemetry_finalize_for_meta('cloud_health_escalation')
        self.assertEqual(out.get('bundle_build_telemetry_coherence'), 'flow_mismatch')
        self.assertEqual(out.get('timing_trusted_for_current_bundle'), False)
        self.assertEqual(out.get('milestones'), [])
        self.assertEqual(out.get('total_build_sec'), 0.0)


class TestDeliveryReadinessHistoricalEmailMeta(unittest.TestCase):
    def test_get_error_reporting_delivery_readiness_exposes_historical_email_keys(self):
        with patch.object(er, 'list_queued_bundles', return_value=[]):
            with patch.object(er, 'get_last_support_email_delivery_meta', return_value={'delivery_state': 'succeeded', 'send_succeeded': True}):
                r = er.get_error_reporting_delivery_readiness(quiet_token=True, defer_token_probe_until_queue=True)
        self.assertIn('historical_last_support_email_delivery', r)
        self.assertIn('last_support_email_delivery', r)
        self.assertEqual(
            r.get('last_support_email_delivery_semantic'),
            'historical_prior_send_state_not_current_bundle_telemetry',
        )
        self.assertTrue((r.get('historical_last_support_email_delivery') or {}).get('send_succeeded'))


class TestResolveBundleTelemetryLogLevel(unittest.TestCase):
    def tearDown(self):
        os.environ.pop('MEDICAFE_BUNDLE_TELEMETRY_INFO', None)

    def test_default_debug_fast_build(self):
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 10.0}), 'DEBUG')

    def test_info_when_slow(self):
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 50.0}), 'INFO')

    def test_info_when_env_set(self):
        os.environ['MEDICAFE_BUNDLE_TELEMETRY_INFO'] = '1'
        self.assertEqual(bbt.resolve_bundle_telemetry_log_level({'total_build_sec': 0}), 'INFO')


class TestCollectSupportBundleTelemetry(unittest.TestCase):
    def setUp(self):
        self._orig_run_log_id = os.environ.get('MEDICAFE_RUN_LOG_ID')
        self._orig_run_log_token = os.environ.get('MEDICAFE_RUN_LOG_TOKEN')
        self._orig_run_log_filepath = getattr(cfg_loader, '_RUN_LOG_FILEPATH', None)
        cfg_loader._RUN_LOG_FILEPATH = None
        bbt.telemetry_session_reset()

    def tearDown(self):
        if self._orig_run_log_id is None:
            os.environ.pop('MEDICAFE_RUN_LOG_ID', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_ID'] = self._orig_run_log_id
        if self._orig_run_log_token is None:
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
        else:
            os.environ['MEDICAFE_RUN_LOG_TOKEN'] = self._orig_run_log_token
        cfg_loader._RUN_LOG_FILEPATH = self._orig_run_log_filepath
        bbt.telemetry_session_reset()

    def test_collect_support_bundle_meta_includes_bundle_build_telemetry(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_tel_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            with open(current_log, 'w') as f:
                f.write('TEL_MARKER\n')
            os.utime(current_log, (100, 100))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                with patch.object(er, '_with_json_health_attachment', side_effect=lambda files, config: (list(files or []), {})):
                    with patch.object(er, '_with_medisoft_dat_boundary_attachment', side_effect=lambda files, config: list(files or [])):
                        zpath = er.collect_support_bundle(
                            include_traceback=False,
                            max_log_lines=20,
                            extra_meta={'system_health_pack': True, 'send_source': 'test_collect'},
                        )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            tel = meta.get('bundle_build_telemetry')
            self.assertIsInstance(tel, dict)
            self.assertEqual(tel.get('schema_version'), 1)
            self.assertIn('milestones', tel)
            names = [m.get('name') for m in (tel.get('milestones') or []) if isinstance(m, dict)]
            self.assertIn('creating zip bundle', names)
            self.assertEqual(tel.get('telemetry_send_source'), 'test_collect')
            self.assertEqual(tel.get('telemetry_bundle_kind'), 'system_health_pack')
            counts = tel.get('counts') or {}
            self.assertEqual(counts.get('extra_files'), 0)
            self.assertEqual(counts.get('max_log_lines'), 20)
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_meta_includes_policy_rollup(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_policy_')
        old_offline = os.environ.get('MEDICAFE_OFFLINE_PERMISSIVE')
        try:
            os.environ['MEDICAFE_OFFLINE_PERMISSIVE'] = '1'
            phase_manifest = os.path.join(store, 'artifact_manifest_policy.jsonl')
            with open(phase_manifest, 'w') as f:
                f.write(json.dumps({
                    'discovery_scope_policy': {
                        'effective_policy': {'include_xml': True},
                        'policy_source_map': {'include_xml': 'state_evidence'},
                        'policy_reason': 'phase_b_discovery_scope_resolved',
                    },
                }) + '\n')
                f.write(json.dumps({
                    'artifact_scope_policy': {
                        'effective_policy': {'artifact_classes': ['dat']},
                        'policy_source_map': {'artifact_classes': 'state_evidence'},
                        'policy_reason': 'phase_d_artifact_scope_resolved',
                    },
                }) + '\n')
            shadow_report = os.path.join(store, 'shadow_run_report_policy.json')
            with open(shadow_report, 'w') as f:
                json.dump({
                    'phase_f_auto_report_policy': {
                        'effective_policy': {'send_health': True},
                        'policy_source_map': {'send_health': 'state_evidence'},
                        'policy_reason': 'phase_f_auto_report_policy_resolved',
                    },
                }, f)
            cfg = {'MediLink_Config': {'local_storage_path': store, 'DEBUG': True}}
            queue_policy = {
                'effective_policy': {'single_flight': True},
                'policy_source_map': {'single_flight': 'state_evidence'},
                'policy_reason': 'support_send_queue_policy_resolved',
            }
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta={
                        'system_health_pack': True,
                        'send_source': 'test_policy_rollup',
                        'evidence_scope': {
                            'bundle_kind': 'run_evidence_bundle',
                            'artifact_run_id': 'run-policy',
                            'phase_artifact_scope': 'mixed',
                            'coherence_status': 'review_required',
                            'current_decision': 'send_coherent_completed_run_evidence',
                        },
                        'phase_c_remediation_policy': {
                            'effective_policy': {'selected_tier': 1},
                            'policy_source_map': {'selected_tier': 'state_evidence'},
                            'policy_reason': 'phase_c_remediation_action_resolved',
                        },
                        'support_send_job_context': {
                            'job_id': 'job-policy',
                            'send_type': 'system_health',
                            'policy_decision': 'accepted',
                            'policy_reason': 'started_immediately',
                            'dedup_key': 'system_health|run|blocker|20260508',
                            'queue_policy_snapshot': queue_policy,
                        },
                    },
                    extra_files=[
                        ('artifact_manifest_policy.jsonl', phase_manifest),
                        ('shadow_run_report_policy.json', shadow_report),
                    ],
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            rollup = meta.get('policy_rollup')
            self.assertIsInstance(rollup, dict)
            self.assertEqual(rollup.get('schema_version'), 1)
            self.assertIsInstance(rollup.get('import_policy'), dict)
            self.assertIsInstance(rollup.get('diagnostics_policy'), dict)
            self.assertEqual(
                rollup.get('support_send_queue_policy', {}).get('policy_reason'),
                'support_send_queue_policy_resolved',
            )
            self.assertTrue(
                rollup.get('security_policy', {}).get('offline_permissive', {}).get('effective_value')
            )
            scope_policy = rollup.get('bundle_scope_policy') or {}
            self.assertEqual(
                scope_policy.get('effective_policy', {}).get('coherence_status'),
                'review_required',
            )
            self.assertEqual(scope_policy.get('policy_warning'), 'mixed_or_review_required_scope')
            refs = rollup.get('attached_policy_artifacts') or []
            keys = []
            for ref in refs:
                keys.extend(ref.get('policy_keys') or [])
            self.assertIn('discovery_scope_policy', keys)
            self.assertIn('artifact_scope_policy', keys)
            self.assertIn('phase_f_auto_report_policy', keys)
            readiness = rollup.get('promotion_readiness') or {}
            self.assertEqual(
                readiness.get('phase_policy_presence'),
                {'phase_b': True, 'phase_c': True, 'phase_d': True, 'phase_f': True},
            )
            self.assertEqual(readiness.get('missing_phase_policy_surfaces'), [])
            summary = rollup.get('policy_signal_summary') or {}
            self.assertTrue(summary.get('bundle_scope_policy_present'))
            self.assertTrue(summary.get('support_send_queue_policy_present'))
            self.assertEqual(summary.get('attached_policy_artifact_count'), 2)
            self.assertEqual(summary.get('missing_phase_policy_surface_count'), 0)
        finally:
            if old_offline is None:
                os.environ.pop('MEDICAFE_OFFLINE_PERMISSIVE', None)
            else:
                os.environ['MEDICAFE_OFFLINE_PERMISSIVE'] = old_offline
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_adds_evidence_scope_freshness_and_root_banner(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_scope_')
        try:
            attachment_path = os.path.join(store, 'run_artifact_index_rid.txt')
            with open(attachment_path, 'w') as f:
                f.write('artifact')
            os.utime(attachment_path, (100, 100))
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                with patch.object(er, '_with_json_health_attachment', side_effect=lambda files, config: (list(files or []), {})):
                    with patch.object(er, '_with_medisoft_dat_boundary_attachment', side_effect=lambda files, config: list(files or [])):
                        zpath = er.collect_support_bundle(
                            include_traceback=False,
                            max_log_lines=20,
                            extra_meta={
                                'run_evidence_bundle': True,
                                'artifact_run_id': 'rid',
                                'diagnostics_state_scope': 'lab_root_current',
                                'run_cursor_scope': 'lab_root_current',
                                'log_tail_scope': 'latest_application_log',
                            },
                            extra_files=[('run_artifact_index_rid.txt', attachment_path)],
                        )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                names = zf.namelist()
                self.assertIn('BUNDLE_README.txt', names)
                self.assertIn('evidence_scope.json', names)
                banner = zf.read('BUNDLE_README.txt').decode('utf-8')
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                escope = json.loads(zf.read('evidence_scope.json').decode('utf-8'))
            scope = meta.get('evidence_scope') or {}
            fresh = meta.get('attachment_freshness') or {}
            self.assertEqual(scope.get('scope_kind'), 'run_evidence')
            self.assertEqual(scope.get('artifact_run_id'), 'rid')
            self.assertEqual(scope.get('phase_artifact_scope'), 'run_scoped')
            self.assertEqual(fresh.get('attachment_count'), 1)
            self.assertEqual(fresh.get('file_path_attachment_count'), 1)
            self.assertIn('scope_kind=run_evidence', banner)
            self.assertIn('artifact_run_id=rid', banner)
            self.assertEqual(escope.get('artifact_run_id'), 'rid')
            self.assertEqual(escope.get('scope_kind'), scope.get('scope_kind'))
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_root_scope_prefers_evidence_manifest_scope(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_manifest_scope_')
        try:
            attachment_path = os.path.join(store, 'run_artifact_index_anchor.txt')
            with open(attachment_path, 'w') as f:
                f.write('artifact')
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            manifest = {
                'schema_version': 1,
                'scope': {
                    'scope_kind': 'run_evidence_bundle',
                    'bundle_kind': 'run_evidence_bundle',
                    'anchor_run_id': 'anchor',
                    'artifact_run_id': 'anchor',
                    'phase_artifact_scope': 'run_aligned',
                    'coherence_status': 'ready',
                    'phase_run_id_map': {'B': 'b', 'C': 'c', 'D': 'd', 'E': 'e', 'F': 'anchor'},
                },
                'validation': {'attachment_contract_status': 'pass'},
                'missing_required_evidence': [],
            }
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                with patch.object(er, '_with_json_health_attachment', side_effect=lambda files, config: (list(files or []), {})):
                    with patch.object(er, '_with_medisoft_dat_boundary_attachment', side_effect=lambda files, config: list(files or [])):
                        zpath = er.collect_support_bundle(
                            include_traceback=False,
                            max_log_lines=20,
                            extra_meta={
                                'run_evidence_bundle': True,
                                'anchor_run_id': 'anchor',
                                'phase_run_ids': {},
                                'phase_artifact_scope': 'mixed',
                            },
                            extra_files=[('run_artifact_index_anchor.txt', attachment_path)],
                            evidence_manifest=manifest,
                        )
            with zipfile.ZipFile(zpath, 'r') as zf:
                banner = zf.read('BUNDLE_README.txt').decode('utf-8')
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                escope = json.loads(zf.read('evidence_scope.json').decode('utf-8'))
            for scope in (meta.get('evidence_scope') or {}, escope):
                self.assertEqual(scope.get('phase_artifact_scope'), 'run_aligned')
                self.assertEqual(scope.get('artifact_run_id'), 'anchor')
                self.assertEqual(scope.get('phase_run_ids', {}).get('D'), 'd')
                self.assertEqual(scope.get('phase_run_id_map', {}).get('F'), 'anchor')
            self.assertIn('phase_artifact_scope=run_aligned', banner)
            self.assertIn('artifact_run_id=anchor', banner)
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_uses_manifest_source_kind_for_phase_d_followup(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_followup_meta_')
        try:
            attachment_path = os.path.join(store, 'qa_canonical_summary_d_live.json')
            with open(attachment_path, 'w') as f:
                f.write('{"run_id":"d-live"}')
            manifest = {
                'schema_version': 1,
                'scope': {
                    'scope_kind': 'run_evidence_bundle',
                    'bundle_kind': 'run_evidence_bundle',
                    'anchor_run_id': 'anchor',
                    'artifact_run_id': 'anchor',
                    'phase_artifact_scope': 'run_aligned',
                    'coherence_status': 'review_required',
                    'phase_d_followup_run_id': 'd-live',
                    'phase_d_followup_source_kind': 'followup_only',
                },
                'attachments': [
                    {
                        'archive_name': 'qa_canonical_summary_d_live.json',
                        'source_path': attachment_path,
                        'required': False,
                        'freshness': 'followup_only',
                        'scope': 'phase_d_followup',
                        'run_id': 'd-live',
                        'source_kind': 'followup_only',
                    },
                ],
                'validation': {'attachment_contract_status': 'pass'},
                'missing_required_evidence': [],
            }
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                with patch.object(er, '_with_json_health_attachment', side_effect=lambda files, config: (list(files or []), {})):
                    with patch.object(er, '_with_medisoft_dat_boundary_attachment', side_effect=lambda files, config: list(files or [])):
                        zpath = er.collect_support_bundle(
                            include_traceback=False,
                            max_log_lines=20,
                            extra_meta={'run_evidence_bundle': True, 'anchor_run_id': 'anchor'},
                            extra_files=[('qa_canonical_summary_d_live.json', attachment_path)],
                            evidence_manifest=manifest,
                        )
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            rows = meta.get('attachment_freshness', {}).get('attachment_manifest') or []
            row = [r for r in rows if r.get('archive_name') == 'qa_canonical_summary_d_live.json'][0]
            self.assertEqual(row.get('source_kind'), 'followup_only')
            self.assertEqual(row.get('freshness_status'), 'followup_only')
            self.assertEqual(row.get('freshness'), 'followup_only')
            self.assertEqual(row.get('scope'), 'phase_d_followup')
            self.assertEqual(row.get('run_id'), 'd-live')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_mixed_phase_scope_coherence_matches_evidence_scope_json(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_mixed_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            with open(current_log, 'w') as f:
                f.write('MIXED\n')
            os.utime(current_log, (100, 100))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta=None,
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
                escope = json.loads(zf.read('evidence_scope.json').decode('utf-8'))
            mscope = meta.get('evidence_scope') or {}
            self.assertEqual(escope.get('phase_artifact_scope'), 'mixed')
            self.assertEqual(mscope.get('phase_artifact_scope'), 'mixed')
            self.assertEqual(escope.get('coherence_status'), 'review_required')
            self.assertEqual(mscope.get('coherence_status'), 'review_required')
        finally:
            shutil.rmtree(store, ignore_errors=True)

    def test_collect_support_bundle_running_send_job_self_observation(self):
        store = tempfile.mkdtemp(prefix='mc_bundle_selfobs_')
        try:
            date_token = cfg_loader.datetime.now().strftime('%m%d%Y')
            current_log = os.path.join(store, 'Log_{0}_run002.log'.format(date_token))
            with open(current_log, 'w') as f:
                f.write('SELF_OBS\n')
            os.utime(current_log, (100, 100))
            os.environ['MEDICAFE_RUN_LOG_ID'] = '2'
            os.environ.pop('MEDICAFE_RUN_LOG_TOKEN', None)
            cfg_loader._RUN_LOG_FILEPATH = None
            jobs_dir = os.path.join(store, 'reports', 'support_send_jobs')
            os.makedirs(jobs_dir)
            job_path = os.path.join(jobs_dir, 'job_run1.json')
            with open(job_path, 'w') as f:
                f.write(json.dumps({'job_id': 'run1', 'status': 'running'}, ensure_ascii=True))
            cfg = {'MediLink_Config': {'local_storage_path': store}}
            with patch.object(er, 'load_configuration', return_value=(cfg, None)):
                zpath = er.collect_support_bundle(
                    include_traceback=False,
                    max_log_lines=20,
                    extra_meta={
                        'lab_root': store,
                        'support_send_job_context': {'job_id': 'run1'},
                    },
                )
            self.assertTrue(zpath and os.path.isfile(zpath))
            with zipfile.ZipFile(zpath, 'r') as zf:
                meta = json.loads(zf.read('meta.json').decode('utf-8'))
            ctx = meta.get('extra_context') or {}
            self.assertEqual(ctx.get('self_observation_status'), 'incomplete_observation')
            self.assertEqual(ctx.get('delivery_issue_code_support'), er.SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION)
        finally:
            shutil.rmtree(store, ignore_errors=True)
