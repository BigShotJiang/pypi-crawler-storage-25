#!/usr/bin/env python
from __future__ import print_function

from MediCafe import dat_utils


class FakeDataMgmt(object):
    def __init__(self, parsed_rows):
        self._parsed_rows = list(parsed_rows)
        self.parse_calls = 0

    def read_fixed_width_data(self, dat_file_path):
        return [
            ("personal1", "insurance1", "service1", "service1b", "service1c"),
            ("personal2", "insurance2", "service2", "service2b", "service2c"),
            ("personal3", "insurance3", "service3", "service3b", "service3c"),
        ]

    def parse_fixed_width_data(self, personal_info, insurance_info, service_info, service_info_2, service_info_3, config):
        row = self._parsed_rows[self.parse_calls]
        self.parse_calls += 1
        return row


def _parsed_row(chart, mintues="", minutes="", anesthesia_minutes=""):
    return {
        "CHART": chart,
        "PATID": "PAT{}".format(chart),
        "FIRST": "First{}".format(chart),
        "LAST": "Last{}".format(chart),
        "BDAY": "01/01/1980",
        "DATE": "05/01/2026",
        "INAME": "Payer",
        "PAYERID": "PAYERID",
        "MEMID": "MEM{}".format(chart),
        "CODEA": "00100",
        "DIAG": "D123",
        "AMOUNT": "100.00",
        "MINTUES": mintues,
        "MINUTES": minutes,
        "ANESTHESIA_MINUTES": anesthesia_minutes,
    }


def test_extract_member_data_uses_anesthesia_minutes_alias_precedence(monkeypatch, tmp_path):
    fake_datamgmt = FakeDataMgmt([
        _parsed_row("1", mintues="11", minutes="22", anesthesia_minutes="33"),
        _parsed_row("2", minutes="22", anesthesia_minutes="33"),
        _parsed_row("3", anesthesia_minutes="33"),
    ])
    dat_path = tmp_path / "sample.dat"
    dat_path.write_text("placeholder", encoding="ascii")

    monkeypatch.setattr(dat_utils, "MediLink_DataMgmt", fake_datamgmt)

    records = dat_utils.extract_member_data_from_dat_file(str(dat_path), config={})

    assert [record["anesthesia_minutes"] for record in records] == ["11", "22", "33"]
    assert records[0]["MINTUES"] == "11"
    assert records[0]["MINUTES"] == "22"
    assert records[1]["MINTUES"] == ""
    assert records[1]["MINUTES"] == "22"
    assert records[2]["MINTUES"] == ""
    assert records[2]["MINUTES"] == ""
    assert [record["patient_id"] for record in records] == ["1", "2", "3"]
