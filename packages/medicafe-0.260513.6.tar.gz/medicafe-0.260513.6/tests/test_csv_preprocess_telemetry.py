# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediBot import MediBot_Preprocessor_lib as preprocessor_lib
from MediBot import MediBot_Preprocessor as preprocessor


def _parse_telemetry_line(message):
    if 'CSV_PREPROCESS_TELEMETRY' not in message:
        return None
    prefix = 'CSV_PREPROCESS_TELEMETRY '
    idx = message.find(prefix)
    if idx < 0:
        return None
    return json.loads(message[idx + len(prefix):])


class CsvPreprocessTelemetryTests(unittest.TestCase):
    def test_clean_header_preserves_carol_intake_patient_id_header(self):
        raw_headers = (
            "Surgery Date\tPatient ID\tPatient Last\tPatient First\tPatient Middle\t"
            "Patient Address1\tPatient Address2\tPatient City\tPatient State\tPatient Zip\t"
            "Patient Home Ph\tPatient Cell Ph\tPatient DOB\tAge\tPatient SSN\tGender\tEmail\t"
            "Guarantor Name\tGuarantor Address1\tGuarantor Address2\tGuarantor City\t"
            "Guarantor State\tGuarantor Zip\tGuarantor DOB\tGuarantor SSN\t"
            "Guarantor Home Ph\tGuarantor Cell Ph\tGuarantor Email\tGuarantor Relationship\t"
            "Primary Insurance\tPrimary Address 1\tPrimary City\tPrimary State\tPrimary Zip\t"
            "Primary Phone\tPrimary Insured Name\tPrimary DOB\tPrimary Policy Number\t"
            "Group Name\tGroup Policy 1\tIns1 Payer ID\tSecondary Insurance\tSecondary Address\t"
            "Secondary City\tSecondary State\tSecondary Zip\tSecondary Phone\tSecondary Insured\t"
            "Secondary DOB\tSecondary Policy Number\tGroup Policy 2\tIns2 Payer ID\t"
            "Appt ID\tSurgeon ID"
        ).split("\t")

        cleaned = preprocessor_lib.clean_header(raw_headers)

        self.assertIn("Patient ID", cleaned)
        self.assertNotIn("patient_id", cleaned)
        self.assertEqual(cleaned[1], "Patient ID")

    def test_load_csv_data_records_raw_to_cleaned_header_mapping(self):
        tmpdir = tempfile.mkdtemp()
        try:
            csv_path = os.path.join(tmpdir, "sample.csv")
            with open(csv_path, "w") as handle:
                handle.write("DOS,Patient ID\n05/12/2026,12345\n")

            rows = preprocessor_lib.load_csv_data(csv_path)
            snapshot = preprocessor_lib.get_last_csv_header_read_snapshot()

            self.assertEqual(rows[0].get("Surgery Date"), "05/12/2026")
            self.assertEqual(rows[0].get("Patient ID"), "12345")
            self.assertEqual(snapshot.get("raw_headers"), ["DOS", "Patient ID"])
            self.assertEqual(snapshot.get("cleaned_headers"), ["Surgery Date", "Patient ID"])
            self.assertEqual(snapshot.get("header_pairs")[0].get("raw"), "DOS")
            self.assertEqual(snapshot.get("header_pairs")[0].get("cleaned"), "Surgery Date")
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_preflight_warns_when_rows_but_no_surgery_dates(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            {'Patient ID': '1', 'Surgery Date': ''},
            {'Patient ID': '2', 'Surgery Date': '   '},
        ]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.preflight_csv_preprocess(rows)

        warn_telemetry = [
            _parse_telemetry_line(m) for level, m in logs
            if level == 'WARNING' and 'CSV_PREPROCESS_TELEMETRY' in m
        ]
        self.assertTrue(any(p and p.get('stage') == 'preflight' and p.get('no_nonempty_surgery_dates') for p in warn_telemetry))
        self.assertTrue(any('CSV preflight WARNING' in m for level, m in logs if level == 'WARNING'))

    def test_preflight_info_when_surgery_dates_present(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [{'Patient ID': '1', 'Surgery Date': '04/06/2026'}]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.preflight_csv_preprocess(rows)

        info_messages = [m for level, m in logs if level == 'INFO']
        self.assertTrue(any('CSV_PREPROCESS_SUMMARY' in m or 'CSV_PREPROCESS_TELEMETRY' in m for m in info_messages))
        self.assertFalse(any(level == 'WARNING' and 'CSV preflight WARNING' in m for level, m in logs))

    def test_emit_and_get_last_csv_preprocess_snapshot(self):
        preprocessor_lib.emit_csv_preprocess_telemetry('test_stage', foo=1, bar='two')
        snap = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertIsNotNone(snap)
        self.assertEqual(snap.get('stage'), 'test_stage')
        self.assertEqual(snap.get('foo'), 1)
        self.assertEqual(snap.get('bar'), 'two')

    def test_emit_csv_preprocess_summary_when_detail_disabled(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        with patch.object(preprocessor_lib, 'should_emit_detailed_payload', return_value=False):
            with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
                preprocessor_lib.emit_csv_preprocess_telemetry('preflight', level='INFO', total_rows=2, nonempty_surgery_date_rows=1)

        self.assertTrue(any(m.startswith('CSV_PREPROCESS_SUMMARY ') for _level, m in logs))

    def test_filter_rows_mass_loss_emits_warning_telemetry(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [{"Patient ID": str(i), "Primary Insurance": "AETNA"} for i in range(10)]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.filter_rows(rows)

        self.assertEqual(rows, [])
        warn_payloads = [
            _parse_telemetry_line(m) for level, m in logs
            if level == 'WARNING' and 'CSV_PREPROCESS_TELEMETRY' in m
        ]
        self.assertTrue(any(p and p.get('stage') == 'filter_rows_mass_loss' for p in warn_payloads))
        self.assertTrue(any('CSV row eligibility filter mass loss' in m for level, m in logs if level == 'WARNING'))

    def test_filter_rows_accepts_cleaned_patient_id_number_2_header(self):
        rows = [
            {"Patient ID 2": "12345", "Primary Insurance": "MEDICARE"},
            {"Patient ID 2": "", "Primary Insurance": "MEDICARE"},
        ]

        preprocessor_lib.filter_rows(rows)

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get("Patient ID"), "12345")
        summary = preprocessor_lib.get_last_filter_rows_summary()
        self.assertEqual(summary.get("retained_count"), 1)
        self.assertEqual(summary.get("missing_patient_id_count"), 1)

    def test_filter_rows_accepts_raw_patient_id_number_2_header(self):
        rows = [
            {"Patient ID #2": "12345", "Primary Insurance": "MEDICARE"},
        ]

        preprocessor_lib.filter_rows(rows)

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get("Patient ID"), "12345")

    def test_intake_shape_guard_accepts_carol_intake_patient_id_header(self):
        rows = [
            {
                "Surgery Date": "05/12/2026",
                "Patient ID": "12345",
                "Patient Last": "DOE",
                "Patient First": "JANE",
                "Ins1 Payer ID": "87726",
            },
        ]

        self.assertTrue(preprocessor_lib.validate_csv_intake_shape(rows))

    def test_filter_rows_does_not_treat_dat_patid_as_csv_patient_id(self):
        rows = [
            {"PATID": "34567", "Primary Insurance": "MEDICARE"},
        ]

        preprocessor_lib.filter_rows(rows)

        self.assertEqual(rows, [])
        summary = preprocessor_lib.get_last_filter_rows_summary()
        self.assertEqual(summary.get("retained_count"), 0)
        self.assertEqual(summary.get("missing_patient_id_count"), 1)

    def test_intake_shape_guard_blocks_non_intake_patient_id_headers(self):
        tmpdir = tempfile.mkdtemp()
        try:
            csv_path = os.path.join(tmpdir, "action_report.csv")
            with open(csv_path, "w") as handle:
                handle.write("dos,patient_id,next_action,payer_id\n05/12/2026,12345,review,87726\n")
            rows = preprocessor_lib.load_csv_data(csv_path)

            ok = preprocessor_lib.validate_csv_intake_shape(rows)

            self.assertFalse(ok)
            snapshot = preprocessor_lib.get_last_csv_preprocess_snapshot()
            self.assertEqual(snapshot.get("stage"), "intake_blocked_missing_patient_id_header")
            self.assertIn("Patient ID #2", snapshot.get("expected_patient_id_headers"))
            self.assertIn("patient_id", snapshot.get("cleaned_headers"))
            self.assertEqual(snapshot.get("raw_headers"), ["dos", "patient_id", "next_action", "payer_id"])
            self.assertEqual(snapshot.get("header_pairs")[0].get("raw"), "dos")
            self.assertEqual(snapshot.get("header_pairs")[0].get("cleaned"), "Surgery Date")
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_intake_shape_guard_fails_open_when_header_scan_raises(self):
        """Scanner bugs must not masquerade as missing Patient ID (would wipe all rows)."""

        class RowThatBreaksKeys(dict):
            def keys(self):
                raise RuntimeError("simulated keys() failure")

        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            RowThatBreaksKeys([("Patient ID", "1"), ("Surgery Date", "05/12/2026")]),
        ]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log):
            ok = preprocessor_lib.validate_csv_intake_shape(rows)

        self.assertTrue(ok)
        scan_failed = [
            _parse_telemetry_line(m) for level, m in logs
            if level == "ERROR" and "CSV_PREPROCESS_TELEMETRY" in m
        ]
        self.assertTrue(any(p and p.get("stage") == "intake_header_scan_failed" for p in scan_failed))
        self.assertTrue(any("header scan failed" in m.lower() for _level, m in logs))

    def test_intake_shape_guard_fails_open_when_header_scan_raises(self):
        """Scanner bugs must not masquerade as missing Patient ID (would wipe all rows)."""

        class RowThatBreaksKeys(dict):
            def keys(self):
                raise RuntimeError("simulated keys() failure")

        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            RowThatBreaksKeys([("Patient ID", "1"), ("Surgery Date", "05/12/2026")]),
        ]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log):
            ok = preprocessor_lib.validate_csv_intake_shape(rows)

        self.assertTrue(ok)
        scan_failed = [
            _parse_telemetry_line(m) for level, m in logs
            if level == "ERROR" and "CSV_PREPROCESS_TELEMETRY" in m
        ]
        self.assertTrue(any(p and p.get("stage") == "intake_header_scan_failed" for p in scan_failed))
        self.assertTrue(any("header scan failed" in m.lower() for _level, m in logs))

    def test_preprocess_blocks_reconciliation_shape_before_row_filtering(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            {
                "category": "reply_unblock",
                "Surgery Date": "05/12/2026",
                "patient_id": "12345",
                "payer_id": "87726",
                "claim_number": "C1",
                "next_action": "review",
                "detail": "missing",
                "status": "open",
            },
        ]

        with patch.object(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log):
            with patch.object(preprocessor.MediLink_ConfigLoader, "log", capture_log):
                preprocessor.preprocess_csv_data(rows, {})

        self.assertEqual(rows, [])
        snapshot = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertEqual(snapshot.get("stage"), "intake_blocked_missing_patient_id_header")
        self.assertIn("patient_id", snapshot.get("cleaned_headers"))
        self.assertIsNone(preprocessor_lib.get_last_filter_rows_summary())
        self.assertFalse(any("CSV row eligibility filter:" in message for _level, message in logs))

    def test_preprocess_blocks_title_case_reconciliation_markers_before_row_filtering(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            {
                "Surgery Date": "05/12/2026",
                "Patient ID": "12345",
                "Patient Last": "DOE",
                "Patient First": "JANE",
                "claim_key": "k",
                "next_action": "review",
                "category": "reply_unblock",
            },
        ]

        with patch.object(preprocessor_lib.MediLink_ConfigLoader, "log", capture_log):
            with patch.object(preprocessor.MediLink_ConfigLoader, "log", capture_log):
                preprocessor.preprocess_csv_data(rows, {})

        self.assertEqual(rows, [])
        snapshot = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertEqual(snapshot.get("stage"), "intake_blocked_missing_patient_id_header")
        self.assertEqual(snapshot.get("shape_reason"), "action_or_reconciliation_csv")
        self.assertIn("claim_key", snapshot.get("action_markers"))
        self.assertIsNone(preprocessor_lib.get_last_filter_rows_summary())

    def test_historical_payer_mapping_accepts_raw_patient_id_number_2_header(self):
        tmpdir = tempfile.mkdtemp()
        try:
            csv_path = os.path.join(tmpdir, "history.csv")
            with open(csv_path, "w") as handle:
                handle.write("Patient ID #2,Ins1 Payer ID\n12345,87726\n")

            mappings = preprocessor_lib.load_historical_payer_to_patient_mappings({
                "CSV_FILE_PATH": csv_path,
            })

            self.assertEqual(mappings.get("87726"), set(["12345"]))
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_historical_payer_mapping_does_not_treat_dat_patid_as_csv_patient_id(self):
        tmpdir = tempfile.mkdtemp()
        try:
            csv_path = os.path.join(tmpdir, "history.csv")
            with open(csv_path, "w") as handle:
                handle.write("PATID,Ins1 Payer ID\n12345,87726\n")

            mappings = preprocessor_lib.load_historical_payer_to_patient_mappings({
                "CSV_FILE_PATH": csv_path,
            })

            self.assertEqual(mappings, {})
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_convert_surgery_date_telemetry_buckets(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        rows = [
            {'Surgery Date': '04/06/2026'},
            {'Surgery Date': ''},
            {'Surgery Date': '   '},
            {'Surgery Date': '2026-04-07'},
            {'Surgery Date': 'not-a-date-at-all'},
        ]
        with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
            preprocessor_lib.convert_surgery_date(rows)

        complete = None
        for level, m in logs:
            p = _parse_telemetry_line(m)
            if p and p.get('stage') == 'surgery_date_convert_complete':
                complete = p
                break
        if complete is None:
            complete = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertIsNotNone(complete)
        self.assertEqual(complete.get('row_count_in'), 5)
        self.assertEqual(complete.get('whitespace_only_values'), 1)
        self.assertEqual(complete.get('looks_mm_dd_yyyy_slash'), 1)
        self.assertEqual(complete.get('looks_iso_yyyy_mm_dd'), 1)
        # First row parses; empty + whitespace + garbage => errors/empty per implementation
        self.assertGreaterEqual(complete.get('errors', 0), 1)

    def test_update_diagnosis_codes_telemetry_when_no_valid_dates(self):
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        def fake_get_cfg():
            return ({'MediLink_Config': {'local_storage_path': 'C:\\tmp'}}, {})

        rows = [{'Patient ID': '1', 'Surgery Date': ''}]
        with patch.object(preprocessor_lib, 'get_cached_configuration', fake_get_cfg):
            with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
                preprocessor_lib.update_diagnosis_codes(rows)

        blocked = [
            _parse_telemetry_line(m) for level, m in logs
            if 'CSV_PREPROCESS_TELEMETRY' in m and level == 'ERROR'
        ]
        self.assertTrue(any(p and p.get('stage') == 'diagnosis_blocked_no_valid_dates' for p in blocked))
        snap = preprocessor_lib.get_last_csv_preprocess_snapshot()
        self.assertEqual(snap.get('stage'), 'diagnosis_blocked_no_valid_dates')
        self.assertEqual(snap.get('csv_row_count'), 1)
        self.assertEqual(snap.get('datetime_min_count'), 1)


if __name__ == '__main__':
    unittest.main()
