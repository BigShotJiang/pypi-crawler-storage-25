# -*- coding: utf-8 -*-
"""DAT locator parsing helpers (pytest)."""
from __future__ import print_function

import os
import sys

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

import dat_shape_contract as dsc  # noqa: E402


def test_dat_locator_basename_windows_style_path():
    """Windows-style locators must yield correct basenames on all platforms."""
    assert dsc.dat_locator_basename(r"F:\Z\ZM_20260420_184100.DAT") == "ZM_20260420_184100.DAT"
    assert dsc.dat_file_prefix_from_locator(r"F:\Z\ZM_20260420_184100.DAT") == "ZM"


def test_dat_locator_basename_posix_path_unchanged():
    p = os.path.join("data", "lab", "Z_20260420_172334.DAT")
    assert dsc.dat_locator_basename(p) == os.path.basename(p)
