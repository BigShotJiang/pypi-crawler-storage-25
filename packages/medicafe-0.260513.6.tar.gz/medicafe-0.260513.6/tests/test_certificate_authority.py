import os

from MediLink import certificate_authority as ca


class FakeSubprocess(object):
    PIPE = object()

    def __init__(self):
        self.calls = []

    def call(self, cmd, *args, **kwargs):
        self.calls.append(list(cmd))
        return 0


def _log(_message, level="INFO"):
    return None


def test_generate_root_ca_with_config_uses_v3_ca_extensions(tmp_path):
    fake_subprocess = FakeSubprocess()
    root_key = str(tmp_path / "root.key")
    root_cert = str(tmp_path / "root.crt")

    ok = ca._generate_root_ca_with_config(
        root_key=root_key,
        root_cert=root_cert,
        root_days=3650,
        root_subject="/CN=MediLink Managed Root CA",
        openssl_bin="openssl",
        log_fn=_log,
        subprocess_module=fake_subprocess,
    )

    assert ok is True
    assert len(fake_subprocess.calls) == 1
    cmd = fake_subprocess.calls[0]
    assert cmd[:4] == ["openssl", "req", "-x509", "-new"]
    assert "-extensions" in cmd
    assert cmd[cmd.index("-extensions") + 1] == "v3_ca"
    assert "-config" in cmd
    config_path = cmd[cmd.index("-config") + 1]
    assert not os.path.exists(config_path)


def test_has_ca_extensions_requires_ca_true_and_key_cert_sign(monkeypatch):
    def fake_check_output(_cmd, stderr=None):
        return (
            b"X509v3 Basic Constraints: critical\n"
            b"    CA:TRUE\n"
            b"X509v3 Key Usage: critical\n"
            b"    Certificate Sign, CRL Sign\n"
        )

    monkeypatch.setattr(ca.subprocess, "check_output", fake_check_output)

    assert ca._has_ca_extensions("root.crt", "openssl", _log) is True


def test_has_ca_extensions_rejects_leaf_certificate(monkeypatch):
    def fake_check_output(_cmd, stderr=None):
        return (
            b"X509v3 Basic Constraints: critical\n"
            b"    CA:FALSE\n"
            b"X509v3 Key Usage: critical\n"
            b"    Digital Signature, Key Encipherment\n"
        )

    monkeypatch.setattr(ca.subprocess, "check_output", fake_check_output)

    assert ca._has_ca_extensions("server.crt", "openssl", _log) is False


def test_describe_status_exposes_managed_ca_store_state(monkeypatch, tmp_path):
    root = str(tmp_path / "root.crt")
    server = str(tmp_path / "server.crt")
    profile = ca.create_profile(
        "default",
        str(tmp_path),
        server_cert_path=server,
        server_key_path=str(tmp_path / "server.key"),
    )
    profile["root_cert_path"] = root

    monkeypatch.setattr(ca, "_collect_cert_details", lambda path, _openssl: {"path": path})
    monkeypatch.setattr(ca, "_root_in_store", lambda path, _log, user_store=True: bool(user_store))

    status = ca.describe_status(profile, log=_log)

    assert status["mode"] == "managed_ca"
    assert status["root_cert_path"] == root
    assert status["server_cert_path"] == server
    assert status["root_installed_user"] is True
    assert status["root_installed_machine"] is False
