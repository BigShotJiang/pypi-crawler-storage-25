#!/usr/bin/env python
from __future__ import print_function

import builtins
from datetime import datetime

from MediBot import MediBot_UI


def _patient_info(count):
    rows = []
    for idx in range(count):
        rows.append((
            "05/{:02d}/2026".format(idx + 1),
            "Patient {}".format(idx + 1),
            "PID{}".format(idx + 1),
            "D{:03d}".format(idx + 1),
            {},
        ))
    return rows


def _patient_info_with_names(count):
    rows = []
    for idx in range(count):
        rows.append((
            "05/01/2026",
            "Patient {:02d}".format(idx + 1),
            "PID{}".format(idx + 1),
            "D{:03d}".format(idx + 1),
            {},
        ))
    return rows


def _patch_input(monkeypatch, values):
    pending = list(values)

    def fake_input(prompt=""):
        if not pending:
            raise AssertionError("preview requested more input than expected")
        return pending.pop(0)

    monkeypatch.setattr(builtins, "input", fake_input)
    return pending


def test_option_a_preview_records_enter_skip_and_cancel(monkeypatch, capsys):
    _patch_input(monkeypatch, ["12", "s", "0", "y", ""])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(
        _patient_info(3),
        date_of_service_label="05/01/2026",
    )

    assert summary["entered"] == 1
    assert summary["skipped"] == 1
    assert summary["cancelled"] == 1
    assert summary["rows"][0]["minutes"] == "12"
    assert summary["rows"][0]["status"] == "ENTERED"
    assert summary["rows"][1]["status"] == "SKIPPED"
    assert summary["rows"][2]["status"] == "CANCELLED"
    output = capsys.readouterr().out
    assert "Option A preview complete: entered=1, skipped=1, cancelled=1." in output
    assert "Returning to MediBot workflow..." in output


def test_option_a_preview_back_revises_previous_row_and_quit_returns(monkeypatch, capsys):
    _patch_input(monkeypatch, ["10", "b", "15", "q"])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(2))

    assert summary["entered"] == 1
    assert summary["skipped"] == 0
    assert summary["cancelled"] == 0
    assert summary["rows"][0]["minutes"] == "15"
    assert summary["rows"][0]["status"] == "ENTERED"
    assert summary["rows"][1]["minutes"] == ""
    assert summary["rows"][1]["status"] == "PENDING"
    assert "Returning to MediBot workflow..." in capsys.readouterr().out


def test_option_a_preview_zero_cancel_requires_confirmation(monkeypatch):
    _patch_input(monkeypatch, ["0", "n", "8", ""])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(1))

    assert summary["entered"] == 1
    assert summary["cancelled"] == 0
    assert summary["rows"][0]["minutes"] == "8"
    assert summary["rows"][0]["status"] == "ENTERED"


def test_option_a_preview_empty_input_quit_leaves_rows_pending(monkeypatch, capsys):
    _patch_input(monkeypatch, ["", "q"])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(1))

    assert summary["entered"] == 0
    assert summary["skipped"] == 0
    assert summary["cancelled"] == 0
    assert summary["rows"][0]["status"] == "PENDING"
    output = capsys.readouterr().out
    assert "Please enter minutes or a command." in output
    assert "Returning to MediBot workflow..." in output


def test_option_a_preview_strips_midnight_time_from_date_only_dos(monkeypatch, capsys):
    _patch_input(monkeypatch, ["q"])

    MediBot_UI.run_option_a_minutes_entry_preview(
        _patient_info(1),
        date_of_service_label=datetime(2026, 1, 20, 0, 0, 0),
    )

    output = capsys.readouterr().out
    assert "DOS: 2026-01-20" in output
    assert "DOS: 2026-01-20 00:00:00" not in output


def test_option_a_preview_clears_screen_before_each_table_redraw(monkeypatch):
    clear_commands = []
    _patch_input(monkeypatch, ["", "q"])

    def fake_system(command):
        clear_commands.append(command)
        return 0

    monkeypatch.setattr(MediBot_UI.os, "system", fake_system)

    MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(1))

    assert len(clear_commands) == 2
    assert clear_commands == ["cls" if MediBot_UI.os.name == "nt" else "clear"] * 2


def test_option_a_preview_paginates_lists_longer_than_25(monkeypatch, capsys):
    _patch_input(monkeypatch, ["q"])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    MediBot_UI.run_option_a_minutes_entry_preview(_patient_info_with_names(43))

    output = capsys.readouterr().out
    assert "Page 1 of 2 - showing patients 1-25 of 43" in output
    assert "Showing patients 1-25 of 43; pages advance automatically." in output
    assert "Patient 25" in output
    assert "Patient 26" not in output


def test_option_a_preview_does_not_show_pagination_for_25_or_fewer(monkeypatch, capsys):
    _patch_input(monkeypatch, ["q"])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    MediBot_UI.run_option_a_minutes_entry_preview(_patient_info_with_names(25))

    output = capsys.readouterr().out
    assert "Page 1 of" not in output
    assert "pages advance automatically" not in output
    assert "Patient 25" in output


def test_option_a_preview_advances_to_next_page_at_patient_26(monkeypatch, capsys):
    inputs = ["s"] * 25 + ["q"]
    _patch_input(monkeypatch, inputs)
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info_with_names(43))

    output = capsys.readouterr().out
    assert "Page 2 of 2 - showing patients 26-43 of 43" in output
    assert "Enter minutes for patient 26 of 43" in output
    assert summary["skipped"] == 25
    assert summary["rows"][24]["status"] == "SKIPPED"
    assert summary["rows"][25]["status"] == "PENDING"


def test_option_a_preview_auto_cancelled_rows_are_displayed_and_not_prompted(monkeypatch, capsys):
    _patch_input(monkeypatch, ["9", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "Unknown", {
            "_option_a_preview_status": "CANCELLED",
            "_option_a_preview_status_reason": "docx_diagnosis_unknown",
        }),
        ("05/01/2026", "Patient 02", "PID2", "D002", {}),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Patient 01" in output
    assert "CANCELLED" in output
    assert "Enter minutes for patient 2 of 2" in output
    assert "Enter minutes for patient 1 of 2" not in output
    assert summary["entered"] == 1
    assert summary["cancelled"] == 1
    assert summary["rows"][0]["status"] == "CANCELLED"
    assert summary["rows"][1]["minutes"] == "9"


def test_option_a_preview_all_auto_cancelled_rows_render_without_prompt(monkeypatch, capsys):
    _patch_input(monkeypatch, [""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "Unknown", {
            "_option_a_preview_status": "CANCELLED",
            "_option_a_preview_status_reason": "docx_diagnosis_unknown",
        }),
        ("05/01/2026", "Patient 02", "PID2", "Unknown", {
            "_option_a_preview_status": "CANCELLED",
            "_option_a_preview_status_reason": "docx_diagnosis_unknown",
        }),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Patient 01" in output
    assert "Patient 02" in output
    assert "CANCELLED" in output
    assert "No pending patients remain for this DOS." in output
    assert "Enter minutes for patient" not in output
    assert summary["entered"] == 0
    assert summary["cancelled"] == 2


def test_option_a_preview_final_entry_redraws_completed_table(monkeypatch, capsys):
    _patch_input(monkeypatch, ["5", "6", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "D001", {}),
        ("05/01/2026", "Patient 02", "PID2", "D002", {}),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Patient 01" in output
    assert "D001        5        ENTERED" in output
    assert "Patient 02" in output
    assert "D002        6        ENTERED" in output
    assert "No pending patients remain for this DOS." in output
    assert output.rfind("No pending patients remain for this DOS.") < output.rfind("Option A preview complete")
    assert summary["entered"] == 2
    assert summary["rows"][1]["minutes"] == "6"


def test_option_a_preview_completed_table_can_edit_existing_row(monkeypatch, capsys):
    _patch_input(monkeypatch, ["2", "8", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "D001", {
            "_option_a_preview_status": "ENTERED",
            "_option_a_preview_minutes": "5",
        }),
        ("05/01/2026", "Patient 02", "PID2", "D002", {
            "_option_a_preview_status": "ENTERED",
            "_option_a_preview_minutes": "6",
        }),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Press Enter to accept, enter a row number to edit, or q=quit preview." in output
    assert "Enter minutes for patient 2 of 2" in output
    assert "D002        8        ENTERED" in output
    assert summary["entered"] == 2
    assert summary["rows"][0]["minutes"] == "5"
    assert summary["rows"][1]["minutes"] == "8"
