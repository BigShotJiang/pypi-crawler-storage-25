# sutram_services/container.py
import httpx
from typing import Optional, Dict, Any
from guardianhub import get_logger
from guardianhub.config.settings import settings

logger = get_logger(__name__)


class ServiceContainer:
    _instance: Optional['ServiceContainer'] = None

    def __init__(self):
        # Core Infrastructure (Always Shared)
        self._http_client: Optional[httpx.AsyncClient] = None

        # Optional Infrastructure (Initialized on demand)
        self._db_pool: Any = None

        # Service Instances
        self.llm: Any = None
        self.tool_registry: Any = None
        self._initialized = False

    @classmethod
    def get_instance(cls) -> 'ServiceContainer':
        if not cls._instance:
            cls._instance = cls()
        return cls._instance

    async def initialize(self):
        """Standard cluster-wide initialization."""
        if self._initialized:
            return

        # 1. Start the Global HTTP Well (Required by everyone)
        self._http_client = httpx.AsyncClient(
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
            timeout=settings.endpoints.get("GLOBAL_TIMEOUT", 30.0)
        )

        # 2. Initialize the Tool Registry (Core requirement for discovery)
        from guardianhub.clients.tool_registry_client import ToolRegistryClient
        self.tool_registry = ToolRegistryClient(self._http_client)

        self._initialized = True
        logger.info("🏛️ [SOVEREIGN_WELL] Core services initialized.")

    async def get_db_pool(self):
        """
        Lazy-load Postgres only if needed and available.
        This prevents 'ModuleNotFoundError' in lightweight services.
        """
        if self._db_pool:
            return self._db_pool

        try:
            import asyncpg
            logger.info("🐘 [DATABASE] Initializing Postgres Connection Pool...")
            self._db_pool = await asyncpg.create_pool(
                dsn=settings.database.POSTGRES_URL,
                min_size=settings.database.get("POOL_MIN", 2),
                max_size=settings.database.get("POOL_MAX", 10)
            )
            return self._db_pool
        except ImportError:
            logger.error("❌ [CRITICAL] 'asyncpg' not found. Ensure 'muscle' extra is installed.")
            raise RuntimeError("Postgres requested but 'asyncpg' is not installed.")
        except Exception as e:
            logger.error(f"❌ [DATABASE_FAILURE] Could not connect to Postgres: {e}")
            raise

    async def shutdown(self):
        """Graceful teardown of whatever was opened."""
        if self._http_client:
            await self._http_client.aclose()
        if self._db_pool:
            await self._db_pool.close()
        logger.info("🔌 [SOVEREIGN_WELL] All active pools drained.")