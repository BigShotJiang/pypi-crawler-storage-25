import random
import math

class BasicIntegrat:
    def __init__(self, total_nodes_quantity, input_nodes_quantity, output_nodes_quantity, parameter_random_initialization_range=0.1):
        self.TOTAL_NODES_QUANTITY = total_nodes_quantity
        self.INPUT_NODES_QUANTITY = input_nodes_quantity
        self.OUTPUT_NODES_QUANTITY = output_nodes_quantity
        self.PARAMETER_RANDOM_INITIALIZATION_RANGE = parameter_random_initialization_range

        self.nodes = []
        self.weights = []

        self.nodes_gradients = []
        self.weights_gradients = []

        self.input_nodes_placement = []
        self.output_nodes_placement = []

        self.nodes_history = []

        self.adam_weight_decay_timestep = 0

        self.momentum_weights = []
        self.velocity_weights = []

        self.initialize()

    def initialize(self):
        for i in range(self.TOTAL_NODES_QUANTITY):
            self.nodes.append(0)

        for i in range(self.TOTAL_NODES_QUANTITY ** 2):
            self.weights.append(random.uniform(-self.PARAMETER_RANDOM_INITIALIZATION_RANGE, self.PARAMETER_RANDOM_INITIALIZATION_RANGE))

            self.weights_gradients.append(0)

            self.momentum_weights.append(0)
            self.velocity_weights.append(0)

        for i in range(self.INPUT_NODES_QUANTITY):
            self.input_nodes_placement.append(random.randint(0, self.TOTAL_NODES_QUANTITY - 1))

        for i in range(self.OUTPUT_NODES_QUANTITY):
            self.output_nodes_placement.append(random.randint(0, self.TOTAL_NODES_QUANTITY - 1))

    def forward(self, input=None):
        if input is not None:
            for i in range(self.INPUT_NODES_QUANTITY):
                self.nodes[self.input_nodes_placement[i]] = input[i]

        self.nodes_history.append(list(self.nodes))

        new_nodes = []
        for i in range(self.TOTAL_NODES_QUANTITY):
            summand = 0

            for j in range(self.TOTAL_NODES_QUANTITY):
                summand += self.nodes[j] * self.weights[j * self.TOTAL_NODES_QUANTITY + i]

            new_nodes.append(self.heaviside(value=summand))

        self.nodes = new_nodes
        self.nodes_history.append(list(self.nodes))

        output = []
        for i in range(self.OUTPUT_NODES_QUANTITY):
            output.append(self.nodes[self.output_nodes_placement[i]])

        return output

    def backward(self, loss, backward_steps):
        gradients = []
        for i in range(self.TOTAL_NODES_QUANTITY ** 2):
            gradients.append(0)

        delta_next = []
        for i in range(self.TOTAL_NODES_QUANTITY):
            delta_next.append(0)

        history_length = len(self.nodes_history)
        actual_backward_steps = backward_steps

        if history_length < 2 * backward_steps:
            actual_backward_steps = history_length // 2

            if actual_backward_steps <= 0:
                return gradients

        recent_history = self.nodes_history[-(2 * actual_backward_steps):]

        for t in range(actual_backward_steps - 1, -1, -1):
            previous_nodes = recent_history[2 * t]

            delta = []

            for i in range(self.TOTAL_NODES_QUANTITY):
                activation_gradient = delta_next[i]

                for j in range(self.OUTPUT_NODES_QUANTITY):
                    if self.output_nodes_placement[j] == i:
                        activation_gradient += loss[j]

                summand = 0
                for j in range(self.TOTAL_NODES_QUANTITY):
                    summand += previous_nodes[j] * self.weights[j * self.TOTAL_NODES_QUANTITY + i]

                delta.append(activation_gradient * self.arctan(summand))

            new_delta_next = []
            for i in range(self.TOTAL_NODES_QUANTITY):
                new_delta_next.append(0)

            for i in range(self.TOTAL_NODES_QUANTITY):
                for j in range(self.TOTAL_NODES_QUANTITY):
                    weight_index = j * self.TOTAL_NODES_QUANTITY + i

                    gradients[weight_index] += previous_nodes[j] * delta[i]

                    new_delta_next[j] += delta[i] * self.weights[weight_index]

            delta_next = new_delta_next

        return gradients

    def heaviside(self, value):
        if value > 0:
            return 1
        else:
            return 0

    def arctan(self, value):
        return (1 / math.pi) * (1 / (1 + (1 * value) ** 2))

    def apply_adam_weight_decay(self, gradients, learning_rate, weight_decay_rate, adam_weight_decay_first_beta=0.99, adam_weight_decay_second_beta=0.999, adam_weight_decay_epsilon=1e-8):
        self.adam_weight_decay_timestep += 1

        for i in range(len(self.weights)):
            self.weights[i] -= learning_rate * weight_decay_rate * self.weights[i]

            self.momentum_weights[i] = adam_weight_decay_first_beta * self.momentum_weights[i] + (1 - adam_weight_decay_first_beta) * gradients[i]
            self.velocity_weights[i] = adam_weight_decay_second_beta * self.velocity_weights[i] + (1 - adam_weight_decay_second_beta) * (gradients[i] ** 2)

            momentum_corrected = self.momentum_weights[i] / (1 - adam_weight_decay_first_beta ** self.adam_weight_decay_timestep)
            velocity_corrected = self.velocity_weights[i] / (1 - adam_weight_decay_second_beta ** self.adam_weight_decay_timestep)

            self.weights[i] -= learning_rate * (momentum_corrected / (velocity_corrected ** 0.5 + adam_weight_decay_epsilon))

    def clear_nodes_history(self):
        self.nodes_history.clear()
