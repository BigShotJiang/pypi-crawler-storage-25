module github.com/brownjosiah/fidelity-trader-api/clients/go

go 1.26.1

require (
	github.com/apapsch/go-jsonmerge/v2 v2.0.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/oapi-codegen/runtime v1.3.1 // indirect
)
