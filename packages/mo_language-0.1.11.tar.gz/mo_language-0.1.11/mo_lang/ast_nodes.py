"""
AST Nodes — the tree structure produced by the Parser.
"""
from __future__ import annotations
from dataclasses import dataclass, field


# ── Expressions ───────────────────────────────────────────────────────────────

@dataclass
class Number:
    value: float

@dataclass
class String:
    value: str

@dataclass
class Bool:
    value: bool

@dataclass
class Null:
    pass

@dataclass
class Ident:
    name: str

@dataclass
class BinOp:
    op:    str
    left:  object
    right: object

@dataclass
class UnaryOp:
    op:    str
    right: object

@dataclass
class Call:
    name: str
    args: list

@dataclass
class ListLiteral:
    elements: list

@dataclass
class DictLiteral:
    pairs: list   # list of (key_expr, value_expr)

@dataclass
class IndexGet:
    obj:   object
    index: object

@dataclass
class IndexSet:
    obj:   object
    index: object
    value: object

@dataclass
class GetAttr:
    obj:  object
    attr: str

@dataclass
class SetAttr:
    obj:   object
    attr:  str
    value: object

@dataclass
class MethodCall:
    obj:    object
    method: str
    args:   list

@dataclass
class AnonFn:
    """Anonymous function expression: fn(params) { body }"""
    params: list[str]
    body:   list

@dataclass
class CallExpr:
    """Call result of an expression: expr(args)  e.g. fns[0](x), get_fn()()"""
    callee: object
    args:   list

@dataclass
class TemplateStr:
    """Template string: `hello ${expr}`
    parts is a list of str (literal) or AST expression nodes.
    """
    parts: list


# ── Statements ────────────────────────────────────────────────────────────────

@dataclass
class LetStmt:
    name:  str
    value: object
    line:  int = 0

@dataclass
class AssignStmt:
    name:  str
    value: object
    line:  int = 0

@dataclass
class IfStmt:
    condition: object
    then_body: list
    else_body: list = field(default_factory=list)
    line:      int  = 0

@dataclass
class WhileStmt:
    condition: object
    body:      list
    line:      int = 0

@dataclass
class FnDef:
    name:   str
    params: list[str]
    body:   list
    line:   int = 0

@dataclass
class ReturnStmt:
    value: object
    line:  int = 0

@dataclass
class ForStmt:
    var:  str
    iter: object
    body: list
    line: int = 0

@dataclass
class BreakStmt:
    line: int = 0

@dataclass
class ContinueStmt:
    line: int = 0

@dataclass
class TryCatch:
    try_body:   list
    err_var:    str
    catch_body: list
    line:       int = 0

@dataclass
class ThrowStmt:
    value: object
    line:  int = 0

@dataclass
class ExprStmt:
    expr: object
    line: int = 0

@dataclass
class ImportStmt:
    path:  str
    alias: str = None   # import "std/json" as json
    line:  int = 0

@dataclass
class ClassDef:
    name:    str
    parent:  object
    methods: list
    line:    int = 0
