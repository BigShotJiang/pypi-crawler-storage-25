"""
Interpreter — walks the AST and executes it.

Uses an Environment (scope chain) to store variables.
Functions are first-class values stored in the same environment.
"""
from __future__ import annotations
from .ast_nodes import *


class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value

class ThrowSignal(Exception):
    def __init__(self, value):
        self.value = value

class BreakSignal(Exception):
    pass

class ContinueSignal(Exception):
    pass

class RuntimeError_(Exception):
    pass


class Environment:
    def __init__(self, parent: Environment | None = None):
        self.vars   = {}
        self.parent = parent

    def get(self, name: str):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        raise RuntimeError_(f"Undefined variable '{name}'")

    def set(self, name: str, value):
        if name in self.vars:
            self.vars[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise RuntimeError_(f"Undefined variable '{name}' (use 'let' to declare)")

    def define(self, name: str, value):
        self.vars[name] = value


class Function:
    def __init__(self, name: str, params: list[str], body: list, closure: Environment):
        self.name    = name
        self.params  = params
        self.body    = body
        self.closure = closure

    def __repr__(self):
        return f"<fn {self.name}({', '.join(self.params)})>"


class Klass:
    def __init__(self, name: str, methods: dict, parent=None):
        self.name    = name
        self.methods = methods
        self.parent  = parent

    def __repr__(self):
        return f"<class {self.name}>"


class BoundSuper:
    def __init__(self, klass: Klass, instance):
        self.klass    = klass
        self.instance = instance


class Instance:
    def __init__(self, klass: Klass):
        self.klass  = klass
        self.fields = {}

    def __repr__(self):
        return f"<{self.klass.name} instance>"


class Interpreter:
    def __init__(self):
        self.globals = Environment()
        self._current_line = 0
        self._register_builtins()

    def _register_builtins(self):
        self.globals.define("print",  self._builtin_print)
        self.globals.define("len",    self._builtin_len)
        self.globals.define("str",    self._builtin_str)
        self.globals.define("num",    self._builtin_num)
        self.globals.define("type",   self._builtin_type)
        self.globals.define("range",  self._builtin_range)
        self.globals.define("push",   self._builtin_push)
        self.globals.define("pop",    self._builtin_pop)
        self.globals.define("input",  self._builtin_input)
        self.globals.define("keys",   self._builtin_keys)
        self.globals.define("has",    self._builtin_has)
        self.globals.define("delete", self._builtin_delete)
        self.globals.define("floor",         self._builtin_floor)
        self.globals.define("ceil",          self._builtin_ceil)
        self.globals.define("round",         self._builtin_round)
        self.globals.define("abs",           self._builtin_abs)
        self.globals.define("__http_serve__",    self._builtin_http_serve)
        self.globals.define("__http_fetch__",    self._builtin_http_fetch)
        self.globals.define("__file_read__",     self._builtin_file_read)
        self.globals.define("__file_write__",    self._builtin_file_write)
        self.globals.define("__file_append__",   self._builtin_file_append)
        self.globals.define("__file_exists__",   self._builtin_file_exists)
        self.globals.define("__file_delete__",   self._builtin_file_delete)
        self.globals.define("__file_list__",     self._builtin_file_list)
        self.globals.define("__json_parse__",    self._builtin_json_parse)
        self.globals.define("__json_stringify__",self._builtin_json_stringify)
        self.globals.define("__os_name__",       self._builtin_os_name)
        self.globals.define("__os_cwd__",        self._builtin_os_cwd)
        self.globals.define("__os_home__",       self._builtin_os_home)
        self.globals.define("__os_env__",        self._builtin_os_env)
        self.globals.define("__os_cpus__",       self._builtin_os_cpus)
        self.globals.define("__path_join__",     self._builtin_path_join)
        self.globals.define("__path_dir__",      self._builtin_path_dir)
        self.globals.define("__path_base__",     self._builtin_path_base)
        self.globals.define("__path_ext__",      self._builtin_path_ext)
        self.globals.define("__path_abs__",      self._builtin_path_abs)
        self.globals.define("__url_parse__",     self._builtin_url_parse)
        self.globals.define("__url_encode__",    self._builtin_url_encode)
        self.globals.define("__url_decode__",    self._builtin_url_decode)
        self.globals.define("__proc_args__",     self._builtin_proc_args)
        self.globals.define("__proc_pid__",      self._builtin_proc_pid)
        self.globals.define("__proc_exit__",     self._builtin_proc_exit)
        self.globals.define("__proc_env__",      self._builtin_proc_env)
        self.globals.define("__crypto_md5__",    self._builtin_crypto_md5)
        self.globals.define("__crypto_sha1__",   self._builtin_crypto_sha1)
        self.globals.define("__crypto_sha256__", self._builtin_crypto_sha256)
        self.globals.define("__time_now__",      self._builtin_time_now)
        self.globals.define("__time_ms__",       self._builtin_time_ms)
        self.globals.define("__time_sleep__",    self._builtin_time_sleep)
        self.globals.define("__time_format__",   self._builtin_time_format)
        self.globals.define("__random_int__",    self._builtin_random_int)
        self.globals.define("__random_float__",  self._builtin_random_float)
        self.globals.define("__random_pick__",   self._builtin_random_pick)
        self.globals.define("__net_listen__",    self._builtin_net_listen)
        self.globals.define("__net_connect__",   self._builtin_net_connect)
        self.globals.define("__net_send__",      self._builtin_net_send)
        self.globals.define("__net_recv__",      self._builtin_net_recv)
        self.globals.define("__net_close__",     self._builtin_net_close)
        self.globals.define("__net_addr__",      self._builtin_net_addr)
        self.globals.define("__http_serve_bg__", self._builtin_http_serve_bg)
        self.globals.define("debug",  self._builtin_debug)

    def run(self, stmts: list, env: Environment = None):
        if env is None:
            env = Environment(parent=self.globals)
        for stmt in stmts:
            self._exec(stmt, env)

    def _exec(self, node, env: Environment):
        if node.line:
            self._current_line = node.line
        t = type(node)
        if t is LetStmt:
            env.define(node.name, self._eval(node.value, env))
        elif t is AssignStmt:
            env.set(node.name, self._eval(node.value, env))
        elif t is IfStmt:
            if self._truthy(self._eval(node.condition, env)):
                self._exec_block(node.then_body, env)
            elif node.else_body:
                self._exec_block(node.else_body, env)
        elif t is WhileStmt:
            while self._truthy(self._eval(node.condition, env)):
                try:
                    self._exec_block(node.body, env)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue
        elif t is FnDef:
            env.define(node.name, Function(node.name, node.params, node.body, env))
        elif t is ReturnStmt:
            raise ReturnSignal(self._eval(node.value, env) if node.value is not None else None)
        elif t is BreakStmt:
            raise BreakSignal()
        elif t is ContinueStmt:
            raise ContinueSignal()
        elif t is ForStmt:
            iterable = self._eval(node.iter, env)
            if isinstance(iterable, dict):
                items = list(iterable.keys())
            elif isinstance(iterable, str):
                items = list(iterable)
            elif isinstance(iterable, list):
                items = iterable
            else:
                raise RuntimeError_("'for' requires a list, dict, or string")
            for item in items:
                local = Environment(parent=env)
                local.define(node.var, item)
                try:
                    for stmt in node.body:
                        self._exec(stmt, local)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue
                except ReturnSignal:
                    raise
        elif t is TryCatch:
            try:
                self._exec_block(node.try_body, env)
            except ThrowSignal as e:
                local = Environment(parent=env)
                local.define(node.err_var, e.value)
                self._exec_block(node.catch_body, local)
            except RuntimeError_ as e:
                local = Environment(parent=env)
                local.define(node.err_var, str(e))
                self._exec_block(node.catch_body, local)
        elif t is ThrowStmt:
            raise ThrowSignal(self._eval(node.value, env))
        elif t is ImportStmt:
            self._import(node.path, node.alias, env)
        elif t is ClassDef:
            methods = {fn.name: Function(fn.name, fn.params, fn.body, env)
                       for fn in node.methods}
            parent = env.get(node.parent) if node.parent else None
            if node.parent and not isinstance(parent, Klass):
                raise RuntimeError_(f"'{node.parent}' is not a class")
            env.define(node.name, Klass(node.name, methods, parent))
        elif t is ExprStmt:
            self._eval(node.expr, env)
        else:
            raise RuntimeError_(f"Unknown statement: {node}")

    def _exec_block(self, stmts: list, parent_env: Environment):
        local = Environment(parent=parent_env)
        for stmt in stmts:
            self._exec(stmt, local)

    def _eval(self, node, env: Environment):
        t = type(node)
        if t is Number:
            return node.value
        elif t is String:
            return node.value
        elif t is Bool:
            return node.value
        elif t is Ident:
            return env.get(node.name)
        elif t is BinOp:
            if node.op == "&&":
                left = self._eval(node.left, env)
                return self._eval(node.right, env) if self._truthy(left) else left
            if node.op == "||":
                left = self._eval(node.left, env)
                return left if self._truthy(left) else self._eval(node.right, env)
            return self._binop(node.op, self._eval(node.left, env), self._eval(node.right, env))
        elif t is UnaryOp:
            val = self._eval(node.right, env)
            if node.op == "-": return -val
            if node.op == "!": return not self._truthy(val)
        elif t is Call:
            fn   = env.get(node.name)
            args = [self._eval(arg, env) for arg in node.args]
            return self._call(fn, args)
        elif t is Null:
            return None
        elif t is DictLiteral:
            return {self._eval(k, env): self._eval(v, env) for k, v in node.pairs}
        elif t is ListLiteral:
            return [self._eval(e, env) for e in node.elements]
        elif t is IndexGet:
            obj = self._eval(node.obj, env)
            idx = self._eval(node.index, env)
            return self._index_get(obj, idx)
        elif t is IndexSet:
            obj = self._eval(node.obj, env)
            idx = self._eval(node.index, env)
            val = self._eval(node.value, env)
            return self._index_set(obj, idx, val)
        elif t is GetAttr:
            obj = self._eval(node.obj, env)
            return self._get_attr(obj, node.attr)
        elif t is SetAttr:
            obj = self._eval(node.obj, env)
            val = self._eval(node.value, env)
            if not isinstance(obj, Instance):
                raise RuntimeError_("Can only set attributes on class instances")
            obj.fields[node.attr] = val
            return val
        elif t is MethodCall:
            obj  = self._eval(node.obj, env)
            args = [self._eval(a, env) for a in node.args]
            return self._call_method(obj, node.method, args)
        elif t is CallExpr:
            fn   = self._eval(node.callee, env)
            args = [self._eval(a, env) for a in node.args]
            return self._call(fn, args)
        elif t is AnonFn:
            return Function("<anon>", node.params, node.body, env)
        elif t is TemplateStr:
            parts = []
            for part in node.parts:
                if isinstance(part, str):
                    parts.append(part)
                else:
                    parts.append(self._display(self._eval(part, env)))
            return "".join(parts)
        else:
            raise RuntimeError_(f"Unknown expression: {node}")

    def _binop(self, op: str, left, right):
        if op == "+":
            if isinstance(left, str) or isinstance(right, str):
                return str(left) + str(right)
            return left + right
        if op == "-":  return left - right
        if op == "*":  return left * right
        if op == "/":
            if right == 0:
                raise RuntimeError_("Division by zero")
            return left / right
        if op == "==": return left == right
        if op == "!=": return left != right
        if op == "<":  return left < right
        if op == ">":  return left > right
        if op == "<=": return left <= right
        if op == ">=": return left >= right
        if op == "&&": return right if self._truthy(left) else left
        if op == "||": return left  if self._truthy(left) else right
        if op == "//":
            if right == 0: raise RuntimeError_("Division by zero")
            return float(int(left // right))
        if op == "%":
            if right == 0: raise RuntimeError_("Modulo by zero")
            return float(left % right)
        raise RuntimeError_(f"Unknown operator: {op}")

    def _lookup_method(self, klass: Klass, name: str):
        k = klass
        while k is not None:
            if name in k.methods:
                return k.methods[name]
            k = k.parent
        return None

    def _get_attr(self, obj, attr: str):
        if isinstance(obj, Instance):
            if attr in obj.fields:
                return obj.fields[attr]
            fn = self._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"'{obj.klass.name}' has no attribute '{attr}'")
        if isinstance(obj, BoundSuper):
            fn = self._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"super has no attribute '{attr}'")
        if isinstance(obj, str):
            return self._str_method(obj, attr)
        if isinstance(obj, dict):
            if attr in obj:
                return obj[attr]
            raise RuntimeError_(f"Key '{attr}' not found in dict")
        raise RuntimeError_(f"Cannot get attribute '{attr}' on {self._builtin_type([obj])}")

    def _call_method(self, obj, method: str, args: list):
        if isinstance(obj, Instance):
            fn = self._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"'{obj.klass.name}' has no method '{method}'")
            return self._invoke_method(fn, obj, args)
        if isinstance(obj, BoundSuper):
            fn = self._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"super has no method '{method}'")
            return self._invoke_method(fn, obj.instance, args, super_klass=obj.klass.parent)
        if isinstance(obj, str):
            return self._call_str_method(obj, method, args)
        if isinstance(obj, list):
            return self._call_list_method(obj, method, args)
        if isinstance(obj, dict):
            fn = obj.get(method)
            if fn is None:
                raise RuntimeError_(f"Module has no function '{method}'")
            return self._call(fn, args)
        raise RuntimeError_(f"Cannot call method on {self._builtin_type([obj])}")

    def _invoke_method(self, fn, instance, args: list, super_klass=None):
        if len(args) != len(fn.params):
            raise RuntimeError_(f"{fn.name}() expects {len(fn.params)} args, got {len(args)}")
        call_env = Environment(parent=fn.closure)
        call_env.define("self", instance)
        if super_klass is not None:
            call_env.define("super", BoundSuper(super_klass, instance))
        elif isinstance(instance, Instance) and instance.klass.parent:
            call_env.define("super", BoundSuper(instance.klass.parent, instance))
        for param, arg in zip(fn.params, args):
            call_env.define(param, arg)
        try:
            for stmt in fn.body:
                self._exec(stmt, call_env)
        except ReturnSignal as r:
            return r.value
        return None

    def _call(self, fn, args: list):
        if callable(fn):
            return fn(args)
        if isinstance(fn, Klass):
            instance = Instance(fn)
            init = self._lookup_method(fn, "init")
            if init:
                if len(args) != len(init.params):
                    raise RuntimeError_(f"{fn.name}.init() expects {len(init.params)} args, got {len(args)}")
                call_env = Environment(parent=init.closure)
                call_env.define("self", instance)
                if fn.parent:
                    call_env.define("super", BoundSuper(fn.parent, instance))
                for param, arg in zip(init.params, args):
                    call_env.define(param, arg)
                try:
                    for stmt in init.body:
                        self._exec(stmt, call_env)
                except ReturnSignal:
                    pass
            return instance
        if not isinstance(fn, Function):
            raise RuntimeError_(f"{fn!r} is not callable")
        if len(args) != len(fn.params):
            raise RuntimeError_(f"{fn.name}() expects {len(fn.params)} args, got {len(args)}")
        call_env = Environment(parent=fn.closure)
        for param, arg in zip(fn.params, args):
            call_env.define(param, arg)
        try:
            for stmt in fn.body:
                self._exec(stmt, call_env)
        except ReturnSignal as r:
            return r.value
        return None

    def _truthy(self, val) -> bool:
        if val is None or val is False:
            return False
        if isinstance(val, (int, float)) and val == 0:
            return False
        if isinstance(val, str) and val == "":
            return False
        return True

    def _builtin_print(self, args):
        print(*[self._display(a) for a in args])
        return None

    def _builtin_debug(self, args):
        import sys
        line = self._current_line
        loc = f"line {line}: " if line else ""
        parts = []
        for v in args:
            t = self._builtin_type([v])
            parts.append(f"{self._display(v)} ({t})")
        print(f"[debug] {loc}" + ", ".join(parts), file=sys.stderr)
        return args[0] if len(args) == 1 else args

    def _builtin_len(self, args):
        if len(args) != 1 or not isinstance(args[0], (str, list, dict)):
            raise RuntimeError_("len() takes a string, list, or dict")
        return float(len(args[0]))

    def _builtin_str(self, args):
        if len(args) != 1:
            raise RuntimeError_("str() takes 1 argument")
        return self._display(args[0])

    def _builtin_num(self, args):
        if len(args) != 1:
            raise RuntimeError_("num() takes 1 argument")
        try:
            return float(args[0])
        except (ValueError, TypeError):
            raise RuntimeError_(f"Cannot convert {args[0]!r} to number")

    def _builtin_type(self, args):
        if len(args) != 1:
            raise RuntimeError_("type() takes 1 argument")
        v = args[0]
        if isinstance(v, bool):     return "bool"
        if isinstance(v, float):    return "number"
        if isinstance(v, str):      return "string"
        if isinstance(v, list):     return "list"
        if isinstance(v, dict):     return "dict"
        if isinstance(v, Function): return "function"
        if isinstance(v, Klass):    return "class"
        if isinstance(v, Instance): return v.klass.name
        if v is None:               return "null"
        # VMFunction (from vm.py) and Python builtins
        if callable(v) or (hasattr(v, 'params') and hasattr(v, 'code')):
            return "function"
        return "unknown"

    def _index_get(self, obj, idx):
        if isinstance(obj, dict):
            key = int(idx) if isinstance(idx, float) and idx == int(idx) else idx
            if key not in obj:
                raise RuntimeError_(f"Key {key!r} not found in dict")
            return obj[key]
        if not isinstance(obj, (list, str)):
            raise RuntimeError_(f"Cannot index into {self._builtin_type([obj])}")
        i = int(idx)
        if i < 0 or i >= len(obj):
            raise RuntimeError_(f"Index {i} out of range (length {len(obj)})")
        v = obj[i]
        return float(v) if isinstance(v, int) else v

    def _index_set(self, obj, idx, val):
        if isinstance(obj, dict):
            key = int(idx) if isinstance(idx, float) and idx == int(idx) else idx
            obj[key] = val
            return val
        if not isinstance(obj, list):
            raise RuntimeError_("Can only assign to list or dict index")
        i = int(idx)
        if i < 0 or i >= len(obj):
            raise RuntimeError_(f"Index {i} out of range (length {len(obj)})")
        obj[i] = val
        return val

    def _builtin_range(self, args):
        if len(args) == 1:
            start, stop, step = 0, int(args[0]), 1
        elif len(args) == 2:
            start, stop, step = int(args[0]), int(args[1]), 1
        elif len(args) == 3:
            start, stop, step = int(args[0]), int(args[1]), int(args[2])
        else:
            raise RuntimeError_("range() takes 1-3 arguments")
        return [float(i) for i in range(start, stop, step)]

    def _builtin_push(self, args):
        if len(args) != 2:
            raise RuntimeError_("push(list, value) takes 2 arguments")
        if not isinstance(args[0], list):
            raise RuntimeError_("push() first argument must be a list")
        args[0].append(args[1])
        return float(len(args[0]))

    def _builtin_pop(self, args):
        if len(args) != 1:
            raise RuntimeError_("pop(list) takes 1 argument")
        if not isinstance(args[0], list):
            raise RuntimeError_("pop() argument must be a list")
        if not args[0]:
            raise RuntimeError_("pop() on empty list")
        return args[0].pop()

    def _builtin_keys(self, args):
        if len(args) != 1 or not isinstance(args[0], dict):
            raise RuntimeError_("keys() takes a dict")
        return list(args[0].keys())

    def _builtin_has(self, args):
        if len(args) != 2 or not isinstance(args[0], dict):
            raise RuntimeError_("has(dict, key) takes a dict and a key")
        key = int(args[1]) if isinstance(args[1], float) and args[1] == int(args[1]) else args[1]
        return key in args[0]

    def _builtin_delete(self, args):
        if len(args) != 2 or not isinstance(args[0], dict):
            raise RuntimeError_("delete(dict, key) takes a dict and a key")
        key = int(args[1]) if isinstance(args[1], float) and args[1] == int(args[1]) else args[1]
        if key not in args[0]:
            raise RuntimeError_(f"Key {key!r} not found")
        del args[0][key]
        return None

    def _str_method(self, s: str, attr: str):
        methods = {
            "upper", "lower", "trim", "split",
            "contains", "starts_with", "ends_with", "replace", "index_of",
        }
        if attr not in methods:
            raise RuntimeError_(f"string has no attribute '{attr}'")
        def _bound(args, _s=s, _attr=attr):
            return self._call_str_method(_s, _attr, args)
        return _bound

    def _call_str_method(self, s: str, method: str, args: list):
        if method == "upper":     return s.upper()
        if method == "lower":     return s.lower()
        if method == "trim":      return s.strip()
        if method == "split":
            sep = args[0] if args else None
            return s.split(sep) if sep else s.split()
        if method == "contains":
            if len(args) != 1: raise RuntimeError_("contains() takes 1 argument")
            return args[0] in s
        if method == "starts_with":
            if len(args) != 1: raise RuntimeError_("starts_with() takes 1 argument")
            return s.startswith(args[0])
        if method == "ends_with":
            if len(args) != 1: raise RuntimeError_("ends_with() takes 1 argument")
            return s.endswith(args[0])
        if method == "replace":
            if len(args) != 2: raise RuntimeError_("replace() takes 2 arguments")
            return s.replace(args[0], args[1])
        if method == "index_of":
            if len(args) != 1: raise RuntimeError_("index_of() takes 1 argument")
            return float(s.find(args[0]))
        raise RuntimeError_(f"string has no method '{method}'")

    def _call_list_method(self, lst: list, method: str, args: list):
        if method == "contains":
            if len(args) != 1: raise RuntimeError_("contains() takes 1 argument")
            return args[0] in lst
        if method == "index_of":
            if len(args) != 1: raise RuntimeError_("index_of() takes 1 argument")
            try:
                return float(lst.index(args[0]))
            except ValueError:
                return -1.0
        if method == "join":
            sep = args[0] if args else ""
            return sep.join(self._display(v) for v in lst)
        if method == "reverse":
            lst.reverse()
            return None
        if method == "slice":
            start = int(args[0]) if len(args) > 0 else 0
            stop  = int(args[1]) if len(args) > 1 else len(lst)
            return lst[start:stop]
        raise RuntimeError_(f"list has no method '{method}'")

    def _builtin_floor(self, args):
        if len(args) != 1: raise RuntimeError_("floor() takes 1 argument")
        import math
        return float(math.floor(args[0]))

    def _builtin_ceil(self, args):
        if len(args) != 1: raise RuntimeError_("ceil() takes 1 argument")
        import math
        return float(math.ceil(args[0]))

    def _builtin_round(self, args):
        if len(args) not in (1, 2): raise RuntimeError_("round() takes 1-2 arguments")
        ndigits = int(args[1]) if len(args) == 2 else 0
        return float(round(args[0], ndigits))

    def _builtin_abs(self, args):
        if len(args) != 1: raise RuntimeError_("abs() takes 1 argument")
        return float(abs(args[0]))

    def _import(self, path: str, alias: str | None, env: Environment):
        import os
        from .lexer import Lexer, LexError
        from .parser import Parser, ParseError
        mo_path = path if path.endswith('.mo') else path + '.mo'
        base = getattr(self, '_base_dir', '.')
        full = os.path.join(base, mo_path)
        if not os.path.exists(full):
            pkg_fallback = os.path.join(os.path.dirname(__file__), mo_path)
            if os.path.exists(pkg_fallback):
                full = pkg_fallback
            else:
                user_pkg = os.path.join(os.path.expanduser("~/.mo/packages"), mo_path)
                if os.path.exists(user_pkg):
                    full = user_pkg
                else:
                    raise RuntimeError_(f"Cannot find module '{path}'")
        source = open(full).read()
        try:
            tokens = Lexer(source).tokenize()
            ast    = Parser(tokens).parse()
        except (LexError, ParseError) as e:
            raise RuntimeError_(f"Error in module '{path}': {e}")
        mod_env = Environment(parent=self.globals)
        self.run(ast, mod_env)
        if alias:
            # Build namespace dict, stripping module-name prefix
            mod_name = path.split('/')[-1]   # "json" from "std/json"
            prefix   = mod_name + "_"
            ns = {}
            for name, val in mod_env.vars.items():
                short = name[len(prefix):] if name.startswith(prefix) else name
                ns[short] = val
            env.define(alias, ns)
        else:
            for name, val in mod_env.vars.items():
                env.define(name, val)

    def _builtin_input(self, args):
        prompt = self._display(args[0]) if args else ""
        try:
            return input(prompt)
        except EOFError:
            return ""

    def _display(self, val) -> str:
        if val is True:  return "true"
        if val is False: return "false"
        if val is None:  return "null"
        if isinstance(val, list):
            return "[" + ", ".join(self._display(v) for v in val) + "]"
        if isinstance(val, dict):
            pairs = ", ".join(f"{self._display(k)}: {self._display(v)}" for k, v in val.items())
            return "{" + pairs + "}"
        if isinstance(val, Instance):
            fields = ", ".join(f"{k}: {self._display(v)}" for k, v in val.fields.items())
            return f"<{val.klass.name} {{{fields}}}>"
        if isinstance(val, Klass):
            return f"<class {val.name}>"
        if isinstance(val, float):
            return str(int(val)) if val == int(val) else str(val)
        return str(val)

    # ── json ──────────────────────────────────────────────────────────────────

    def _builtin_json_parse(self, args):
        if len(args) != 1: raise RuntimeError_("json_parse(str) takes 1 argument")
        import json
        try:
            return json.loads(args[0])
        except Exception as e:
            raise RuntimeError_(f"JSON parse error: {e}")

    def _builtin_json_stringify(self, args):
        if len(args) not in (1, 2): raise RuntimeError_("json_stringify(val, indent?) takes 1-2 arguments")
        import json
        indent = int(args[1]) if len(args) == 2 else None
        def _convert(v):
            if isinstance(v, bool): return v
            if isinstance(v, float): return int(v) if v == int(v) else v
            if isinstance(v, list): return [_convert(x) for x in v]
            if isinstance(v, dict): return {k: _convert(val) for k, val in v.items()}
            return v
        return json.dumps(_convert(args[0]), indent=indent, ensure_ascii=False)

    # ── os ────────────────────────────────────────────────────────────────────

    def _builtin_os_name(self, args):
        import sys
        p = sys.platform
        if p == "darwin": return "mac"
        if p == "win32":  return "windows"
        return "linux"

    def _builtin_os_cwd(self, args):
        import os
        return os.getcwd()

    def _builtin_os_home(self, args):
        import os
        return os.path.expanduser("~")

    def _builtin_os_env(self, args):
        if len(args) != 1: raise RuntimeError_("os_env(key) takes 1 argument")
        import os
        return os.environ.get(args[0], "")

    def _builtin_os_cpus(self, args):
        import os
        return float(os.cpu_count() or 1)

    # ── path ──────────────────────────────────────────────────────────────────

    def _builtin_path_join(self, args):
        if not args: raise RuntimeError_("path_join() needs at least 1 argument")
        import os.path
        return os.path.join(*args)

    def _builtin_path_dir(self, args):
        if len(args) != 1: raise RuntimeError_("path_dir(path) takes 1 argument")
        import os.path
        return os.path.dirname(args[0])

    def _builtin_path_base(self, args):
        if len(args) != 1: raise RuntimeError_("path_base(path) takes 1 argument")
        import os.path
        return os.path.basename(args[0])

    def _builtin_path_ext(self, args):
        if len(args) != 1: raise RuntimeError_("path_ext(path) takes 1 argument")
        import os.path
        return os.path.splitext(args[0])[1]

    def _builtin_path_abs(self, args):
        if len(args) != 1: raise RuntimeError_("path_abs(path) takes 1 argument")
        import os.path
        return os.path.abspath(args[0])

    # ── url ───────────────────────────────────────────────────────────────────

    def _builtin_url_parse(self, args):
        if len(args) != 1: raise RuntimeError_("url_parse(url) takes 1 argument")
        import urllib.parse
        p = urllib.parse.urlparse(args[0])
        query = dict(urllib.parse.parse_qsl(p.query))
        return {"protocol": p.scheme, "host": p.netloc,
                "path": p.path, "query": query, "hash": p.fragment}

    def _builtin_url_encode(self, args):
        if len(args) != 1: raise RuntimeError_("url_encode(dict) takes 1 argument")
        import urllib.parse
        if not isinstance(args[0], dict):
            raise RuntimeError_("url_encode() expects a dict")
        return urllib.parse.urlencode(args[0])

    def _builtin_url_decode(self, args):
        if len(args) != 1: raise RuntimeError_("url_decode(str) takes 1 argument")
        import urllib.parse
        return dict(urllib.parse.parse_qsl(args[0]))

    # ── process ───────────────────────────────────────────────────────────────

    def _builtin_proc_args(self, args):
        import sys
        return sys.argv[1:]

    def _builtin_proc_pid(self, args):
        import os
        return float(os.getpid())

    def _builtin_proc_exit(self, args):
        import sys
        code = int(args[0]) if args else 0
        sys.exit(code)

    def _builtin_proc_env(self, args):
        if len(args) != 1: raise RuntimeError_("proc_env(key) takes 1 argument")
        import os
        return os.environ.get(args[0], "")

    # ── crypto ────────────────────────────────────────────────────────────────

    def _builtin_crypto_md5(self, args):
        if len(args) != 1: raise RuntimeError_("md5(str) takes 1 argument")
        import hashlib
        return hashlib.md5(str(args[0]).encode()).hexdigest()

    def _builtin_crypto_sha1(self, args):
        if len(args) != 1: raise RuntimeError_("sha1(str) takes 1 argument")
        import hashlib
        return hashlib.sha1(str(args[0]).encode()).hexdigest()

    def _builtin_crypto_sha256(self, args):
        if len(args) != 1: raise RuntimeError_("sha256(str) takes 1 argument")
        import hashlib
        return hashlib.sha256(str(args[0]).encode()).hexdigest()

    # ── http fetch ────────────────────────────────────────────────────────────

    def _builtin_http_fetch(self, args):
        if len(args) not in (1, 2):
            raise RuntimeError_("fetch(url, options?) takes 1-2 arguments")
        import urllib.request, urllib.error, json as _json
        url     = args[0]
        options = args[1] if len(args) == 2 else {}
        method  = options.get("method", "GET") if isinstance(options, dict) else "GET"
        body    = options.get("body", None)    if isinstance(options, dict) else None
        headers = options.get("headers", {})   if isinstance(options, dict) else {}
        body_bytes = body.encode() if isinstance(body, str) else None
        req = urllib.request.Request(url, data=body_bytes, method=method)
        for k, v in (headers.items() if isinstance(headers, dict) else {}.items()):
            req.add_header(k, v)
        try:
            with urllib.request.urlopen(req) as resp:
                text = resp.read().decode('utf-8', errors='replace')
                return {"status": float(resp.status), "body": text,
                        "ok": resp.status < 400}
        except urllib.error.HTTPError as e:
            text = e.read().decode('utf-8', errors='replace')
            return {"status": float(e.code), "body": text, "ok": False}
        except Exception as e:
            raise RuntimeError_(f"fetch error: {e}")

    # ── time ──────────────────────────────────────────────────────────────────

    def _builtin_time_now(self, args):
        import time
        return float(int(time.time()))

    def _builtin_time_ms(self, args):
        import time
        return float(int(time.time() * 1000))

    def _builtin_time_sleep(self, args):
        if len(args) != 1: raise RuntimeError_("time_sleep(seconds) takes 1 argument")
        import time
        time.sleep(args[0])
        return None

    def _builtin_time_format(self, args):
        if len(args) not in (1, 2):
            raise RuntimeError_("time_format(timestamp, fmt?) takes 1-2 arguments")
        import time
        ts  = args[0]
        fmt = args[1] if len(args) == 2 else "%Y-%m-%d %H:%M:%S"
        return time.strftime(fmt, time.localtime(int(ts)))

    # ── random ────────────────────────────────────────────────────────────────

    def _builtin_random_int(self, args):
        if len(args) != 2: raise RuntimeError_("random_int(min, max) takes 2 arguments")
        import random
        return float(random.randint(int(args[0]), int(args[1])))

    def _builtin_random_float(self, args):
        import random
        return random.random()

    def _builtin_random_pick(self, args):
        if len(args) != 1: raise RuntimeError_("random_pick(list) takes 1 argument")
        if not isinstance(args[0], list): raise RuntimeError_("random_pick() expects a list")
        if not args[0]: raise RuntimeError_("random_pick() on empty list")
        import random
        return random.choice(args[0])

    # ── file ──────────────────────────────────────────────────────────────────

    def _builtin_file_read(self, args):
        if len(args) != 1: raise RuntimeError_("read(path) takes 1 argument")
        try:
            return open(args[0], encoding='utf-8').read()
        except FileNotFoundError:
            raise RuntimeError_(f"File not found: '{args[0]}'")
        except OSError as e:
            raise RuntimeError_(str(e))

    def _builtin_file_write(self, args):
        if len(args) != 2: raise RuntimeError_("write(path, content) takes 2 arguments")
        try:
            open(args[0], 'w', encoding='utf-8').write(self._display(args[1]))
        except OSError as e:
            raise RuntimeError_(str(e))
        return None

    def _builtin_file_append(self, args):
        if len(args) != 2: raise RuntimeError_("append(path, content) takes 2 arguments")
        try:
            open(args[0], 'a', encoding='utf-8').write(self._display(args[1]))
        except OSError as e:
            raise RuntimeError_(str(e))
        return None

    def _builtin_file_exists(self, args):
        if len(args) != 1: raise RuntimeError_("exists(path) takes 1 argument")
        import os
        return os.path.exists(args[0])

    def _builtin_file_delete(self, args):
        if len(args) != 1: raise RuntimeError_("delete_file(path) takes 1 argument")
        import os
        try:
            os.remove(args[0])
        except FileNotFoundError:
            raise RuntimeError_(f"File not found: '{args[0]}'")
        except OSError as e:
            raise RuntimeError_(str(e))
        return None

    def _builtin_file_list(self, args):
        if len(args) != 1: raise RuntimeError_("list_dir(path) takes 1 argument")
        import os
        try:
            return sorted(os.listdir(args[0]))
        except FileNotFoundError:
            raise RuntimeError_(f"Directory not found: '{args[0]}'")
        except OSError as e:
            raise RuntimeError_(str(e))

    def _builtin_http_serve(self, args):
        if len(args) != 2:
            raise RuntimeError_("__http_serve__(port, handler) takes 2 arguments")
        import http.server
        import urllib.parse
        import json as _json

        port       = int(args[0])
        handler_fn = args[1]
        interp     = self
        vm         = getattr(self, '_vm', None)

        def call_handler(fn, req):
            # VMFunction has .code, .params, .closure attributes
            if vm and hasattr(fn, 'code') and hasattr(fn, 'closure'):
                return vm._invoke_vm(fn, None, [req])
            return interp._call(fn, [req])

        class MoHandler(http.server.BaseHTTPRequestHandler):
            def handle_request(self, method):
                parsed = urllib.parse.urlparse(self.path)
                query  = dict(urllib.parse.parse_qsl(parsed.query))
                length = int(self.headers.get('Content-Length', 0))
                body   = self.rfile.read(length).decode('utf-8') if length else ""
                req = {"method": method, "path": parsed.path,
                       "query": query, "body": body}
                try:
                    resp = call_handler(handler_fn, req)
                except Exception as e:
                    resp = {"status": 500.0, "body": str(e), "type": "text/plain"}

                if resp is None:
                    status, body_str, ctype = 200, "", "text/plain"
                elif isinstance(resp, dict):
                    status   = int(resp.get("status", 200.0))
                    body_val = resp.get("body", "")
                    ctype    = resp.get("type", "text/plain")
                    if isinstance(body_val, (dict, list)):
                        body_str = _json.dumps(body_val)
                        ctype    = "application/json"
                    else:
                        body_str = interp._display(body_val)
                else:
                    status, body_str, ctype = 200, interp._display(resp), "text/plain"

                raw = body_str.encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type', f'{ctype}; charset=utf-8')
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):    self.handle_request("GET")
            def do_POST(self):   self.handle_request("POST")
            def do_PUT(self):    self.handle_request("PUT")
            def do_DELETE(self): self.handle_request("DELETE")

            def log_message(self, fmt, *a):
                print(f"  {self.command} {self.path}  →  {a[1]}")

        server = http.server.HTTPServer(('', port), MoHandler)
        print(f"Mo server  http://localhost:{port}  (Ctrl+C to stop)")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")

    def _builtin_http_serve_bg(self, args):
        """Non-blocking serve: runs HTTP server in a background thread, returns immediately."""
        import threading
        t = threading.Thread(target=lambda: self._builtin_http_serve(args), daemon=True)
        t.start()
        return None

    # ── net ───────────────────────────────────────────────────────────────────

    def _builtin_net_listen(self, args):
        if len(args) != 2:
            raise RuntimeError_("net_listen(port, handler) takes 2 arguments")
        import socket, threading
        port       = int(args[0])
        handler_fn = args[1]
        interp     = self
        vm         = getattr(self, '_vm', None)

        def call_handler(conn_dict):
            if vm and hasattr(handler_fn, 'code'):
                vm._invoke_vm(handler_fn, None, [conn_dict])
            else:
                interp._call(handler_fn, [conn_dict])

        def client_thread(sock, addr):
            conn = {"_sock": sock, "addr": f"{addr[0]}:{addr[1]}"}
            try:
                call_handler(conn)
            except Exception as e:
                print(f"[net] handler error: {e}")
            finally:
                try: sock.close()
                except: pass

        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(('', port))
        srv.listen(64)
        print(f"Mo TCP server  0.0.0.0:{port}  (Ctrl+C to stop)")
        try:
            while True:
                sock, addr = srv.accept()
                threading.Thread(target=client_thread, args=(sock, addr), daemon=True).start()
        except KeyboardInterrupt:
            print("\nServer stopped.")
        finally:
            srv.close()

    def _builtin_net_connect(self, args):
        if len(args) not in (2, 3):
            raise RuntimeError_("net_connect(host, port) takes 2 arguments")
        import socket
        host    = str(args[0])
        port    = int(args[1])
        timeout = float(args[2]) if len(args) == 3 else 10.0
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        try:
            sock.connect((host, port))
        except Exception as e:
            raise RuntimeError_(f"net_connect failed: {e}")
        return {"_sock": sock, "addr": f"{host}:{port}"}

    def _builtin_net_send(self, args):
        if len(args) != 2:
            raise RuntimeError_("net_send(conn, data) takes 2 arguments")
        conn = args[0]
        if not isinstance(conn, dict) or "_sock" not in conn:
            raise RuntimeError_("net_send: invalid connection")
        data = self._display(args[1])
        try:
            conn["_sock"].sendall(data.encode("utf-8"))
        except Exception as e:
            raise RuntimeError_(f"net_send failed: {e}")
        return None

    def _builtin_net_recv(self, args):
        if len(args) not in (1, 2):
            raise RuntimeError_("net_recv(conn [, size]) takes 1-2 arguments")
        conn = args[0]
        if not isinstance(conn, dict) or "_sock" not in conn:
            raise RuntimeError_("net_recv: invalid connection")
        size = int(args[1]) if len(args) == 2 else 4096
        try:
            data = conn["_sock"].recv(size)
            return data.decode("utf-8") if data else ""
        except Exception as e:
            raise RuntimeError_(f"net_recv failed: {e}")

    def _builtin_net_close(self, args):
        if len(args) != 1:
            raise RuntimeError_("net_close(conn) takes 1 argument")
        conn = args[0]
        if isinstance(conn, dict) and "_sock" in conn:
            try: conn["_sock"].close()
            except: pass
        return None

    def _builtin_net_addr(self, args):
        if len(args) != 1:
            raise RuntimeError_("net_addr(conn) takes 1 argument")
        conn = args[0]
        if not isinstance(conn, dict):
            raise RuntimeError_("net_addr: invalid connection")
        return conn.get("addr", "")
