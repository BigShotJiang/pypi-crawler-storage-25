# std/list.my — higher-order list functions

fn map(lst, f) {
    let result = []
    for item in lst {
        push(result, f(item))
    }
    return result
}

fn filter(lst, f) {
    let result = []
    for item in lst {
        if f(item) {
            push(result, item)
        }
    }
    return result
}

fn reduce(lst, f, init) {
    let acc = init
    for item in lst {
        acc = f(acc, item)
    }
    return acc
}

fn sum(lst) {
    let acc = 0
    for item in lst {
        acc = acc + item
    }
    return acc
}

fn any(lst, f) {
    for item in lst {
        if f(item) { return true }
    }
    return false
}

fn all(lst, f) {
    for item in lst {
        if !f(item) { return false }
    }
    return true
}
