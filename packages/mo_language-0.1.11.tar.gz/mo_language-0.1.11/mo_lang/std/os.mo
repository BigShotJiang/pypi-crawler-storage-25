# std/os.mo — operating system info

fn name() {
    return __os_name__()
}

fn cwd() {
    return __os_cwd__()
}

fn home() {
    return __os_home__()
}

fn env(key) {
    return __os_env__(key)
}

fn cpus() {
    return __os_cpus__()
}
