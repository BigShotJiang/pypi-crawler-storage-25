# std/math.my — math utilities

fn pow(base, exp) {
    if exp == 0 { return 1 }
    let result = 1
    let i = 0
    while i < exp {
        result = result * base
        i = i + 1
    }
    return result
}

fn sqrt(n) {
    if n < 0 { throw "sqrt of negative number" }
    if n == 0 { return 0 }
    let guess = n / 2
    let i = 0
    while i < 50 {
        guess = (guess + n / guess) / 2
        i = i + 1
    }
    return guess
}

fn max(a, b) {
    if a > b { return a }
    return b
}

fn min(a, b) {
    if a < b { return a }
    return b
}

fn clamp(val, lo, hi) {
    if val < lo { return lo }
    if val > hi { return hi }
    return val
}
