# std/crypto.mo — hash functions

fn md5(val) {
    return __crypto_md5__(val)
}

fn sha1(val) {
    return __crypto_sha1__(val)
}

fn sha256(val) {
    return __crypto_sha256__(val)
}
