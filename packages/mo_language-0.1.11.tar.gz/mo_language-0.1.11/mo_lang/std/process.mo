# std/process.mo — current process info

fn args() {
    return __proc_args__()
}

fn pid() {
    return __proc_pid__()
}

fn exit(code) {
    __proc_exit__(code)
}

fn env(key) {
    return __proc_env__(key)
}
