# std/random.mo — random number utilities

fn int(min, max) {
    return __random_int__(min, max)
}

fn float() {
    return __random_float__()
}

fn pick(lst) {
    return __random_pick__(lst)
}
