# std/time.mo — time utilities

fn now() {
    return __time_now__()
}

fn ms() {
    return __time_ms__()
}

fn sleep(seconds) {
    __time_sleep__(seconds)
}

fn format(ts, fmt) {
    return __time_format__(ts, fmt)
}

fn str(ts) {
    return __time_format__(ts)
}
