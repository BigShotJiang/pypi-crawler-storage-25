# std/http.mo — simple HTTP server helpers

fn serve(port, handler) {
    __http_serve__(port, handler)
}

fn serve_bg(port, handler) {
    __http_serve_bg__(port, handler)
}

fn text(body) {
    return {"status": 200, "body": body, "type": "text/plain"}
}

fn html(body) {
    return {"status": 200, "body": body, "type": "text/html"}
}

fn json_resp(data) {
    return {"status": 200, "body": data, "type": "application/json"}
}

fn redirect(url) {
    return {"status": 302, "body": url, "type": "text/plain"}
}

fn not_found() {
    return {"status": 404, "body": "Not Found", "type": "text/plain"}
}

fn bad_request(msg) {
    return {"status": 400, "body": msg, "type": "text/plain"}
}

fn error(msg) {
    return {"status": 500, "body": msg, "type": "text/plain"}
}

fn fetch(url) {
    return __http_fetch__(url)
}

fn fetch_post(url, body) {
    return __http_fetch__(url, {"method": "POST", "body": body,
        "headers": {"Content-Type": "application/json"}})
}
