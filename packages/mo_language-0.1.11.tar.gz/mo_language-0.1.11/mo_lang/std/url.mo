# std/url.mo — URL parsing and encoding

fn parse(u) {
    return __url_parse__(u)
}

fn encode(params) {
    return __url_encode__(params)
}

fn decode(s) {
    return __url_decode__(s)
}
