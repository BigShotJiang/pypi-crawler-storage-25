# std/file.mo — file system utilities

fn read(path) {
    return __file_read__(path)
}

fn write(path, content) {
    __file_write__(path, content)
}

fn append(path, content) {
    __file_append__(path, content)
}

fn exists(path) {
    return __file_exists__(path)
}

fn delete_file(path) {
    __file_delete__(path)
}

fn list_dir(path) {
    return __file_list__(path)
}
