# std/net.mo — TCP networking

fn listen(port, handler) {
    __net_listen__(port, handler)
}

fn connect(host, port) {
    return __net_connect__(host, port)
}

fn send(conn, data) {
    __net_send__(conn, data)
}

fn recv(conn) {
    return __net_recv__(conn)
}

fn recv_size(conn, size) {
    return __net_recv__(conn, size)
}

fn close(conn) {
    __net_close__(conn)
}

fn addr(conn) {
    return __net_addr__(conn)
}
