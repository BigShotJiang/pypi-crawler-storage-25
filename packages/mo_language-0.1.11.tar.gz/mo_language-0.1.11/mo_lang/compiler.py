"""
compiler.py — compile Mo AST → bytecode (list of Instr).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from .ast_nodes import *


class Op(Enum):
    LOAD_CONST    = auto()   # arg: value
    LOAD_NAME     = auto()   # arg: str
    STORE_NAME    = auto()   # arg: str  (assign existing)
    DEFINE_NAME   = auto()   # arg: str  (let)
    BINARY_OP     = auto()   # arg: str
    UNARY_OP      = auto()   # arg: str
    JUMP          = auto()   # arg: int
    JUMP_IF_FALSE = auto()   # arg: int  (pops cond)
    POP           = auto()
    RETURN        = auto()
    CALL          = auto()   # arg: int (argc); stack: fn, arg0..argN
    MAKE_LIST     = auto()   # arg: int
    MAKE_DICT     = auto()   # arg: int (n pairs)
    INDEX_GET     = auto()
    INDEX_SET     = auto()   # stack: obj idx val → val
    GET_ATTR      = auto()   # arg: str
    SET_ATTR      = auto()   # arg: str; stack: obj val → val
    METHOD_CALL   = auto()   # arg: (method, argc)
    MAKE_FUNCTION = auto()   # arg: CompiledFn
    MAKE_CLASS    = auto()   # arg: (name, parent|None, {name: CompiledFn})
    THROW         = auto()
    SETUP_TRY     = auto()   # arg: (catch_ip, err_var) — patched after
    END_TRY       = auto()
    IMPORT        = auto()   # arg: str
    MAKE_ITER     = auto()   # pop list, push iterator
    FOR_ITER      = auto()   # arg: end_ip; peek iter → push next or pop+jump
    LINE          = auto()   # arg: int — source line number (debug info)
    DUP           = auto()   # duplicate top of stack (used for && / ||)


@dataclass
class Instr:
    op:  Op
    arg: object = None

    def __repr__(self):
        return f"{self.op.name}({self.arg!r})" if self.arg is not None else self.op.name


@dataclass
class CompiledFn:
    name:   str
    params: list[str]
    code:   list[Instr]


class Compiler:
    def __init__(self):
        self._code: list[Instr] = []
        self._break_patches:    list[int] = []
        self._continue_patches: list[int] = []

    def compile(self, stmts: list) -> list[Instr]:
        self._code = []
        for stmt in stmts:
            self._stmt(stmt)
        return self._code

    # ── emit helpers ──────────────────────────────────────────────────────────

    def _emit(self, op: Op, arg=None) -> int:
        self._code.append(Instr(op, arg))
        return len(self._code) - 1

    def _patch(self, idx: int, arg):
        self._code[idx] = Instr(self._code[idx].op, arg)

    def _here(self) -> int:
        return len(self._code)

    # ── statements ────────────────────────────────────────────────────────────

    def _stmt(self, node):
        if node.line:
            self._emit(Op.LINE, node.line)
        t = type(node)
        if t is LetStmt:
            self._expr(node.value)
            self._emit(Op.DEFINE_NAME, node.name)
        elif t is AssignStmt:
            self._expr(node.value)
            self._emit(Op.STORE_NAME, node.name)
        elif t is ExprStmt:
            self._expr(node.expr)
            self._emit(Op.POP)
        elif t is IfStmt:
            self._if(node)
        elif t is WhileStmt:
            self._while(node)
        elif t is ForStmt:
            self._for(node)
        elif t is FnDef:
            fn = self._compile_fn(node.name, node.params, node.body)
            self._emit(Op.MAKE_FUNCTION, fn)
            self._emit(Op.DEFINE_NAME, node.name)
        elif t is ReturnStmt:
            if node.value is not None:
                self._expr(node.value)
            else:
                self._emit(Op.LOAD_CONST, None)
            self._emit(Op.RETURN)
        elif t is TryCatch:
            self._try_catch(node)
        elif t is ThrowStmt:
            self._expr(node.value)
            self._emit(Op.THROW)
        elif t is BreakStmt:
            idx = self._emit(Op.JUMP, None)
            self._break_patches.append(idx)
        elif t is ContinueStmt:
            idx = self._emit(Op.JUMP, None)
            self._continue_patches.append(idx)
        elif t is ImportStmt:
            self._emit(Op.IMPORT, (node.path, node.alias))
        elif t is ClassDef:
            self._class(node)
        elif t is IndexSet:
            self._expr(node.obj)
            self._expr(node.index)
            self._expr(node.value)
            self._emit(Op.INDEX_SET)
            self._emit(Op.POP)
        elif t is SetAttr:
            self._expr(node.obj)
            self._expr(node.value)
            self._emit(Op.SET_ATTR, node.attr)
            self._emit(Op.POP)
        else:
            raise ValueError(f"Unknown statement node: {type(node).__name__}")

    def _if(self, node: IfStmt):
        self._expr(node.condition)
        jf = self._emit(Op.JUMP_IF_FALSE, None)
        for s in node.then_body:
            self._stmt(s)
        if node.else_body:
            j = self._emit(Op.JUMP, None)
            self._patch(jf, self._here())
            for s in node.else_body:
                self._stmt(s)
            self._patch(j, self._here())
        else:
            self._patch(jf, self._here())

    def _while(self, node: WhileStmt):
        start = self._here()
        self._expr(node.condition)
        jf = self._emit(Op.JUMP_IF_FALSE, None)
        saved_b, saved_c = self._break_patches, self._continue_patches
        self._break_patches, self._continue_patches = [], []
        for s in node.body:
            self._stmt(s)
        for ci in self._continue_patches:
            self._patch(ci, start)
        self._emit(Op.JUMP, start)
        end = self._here()
        self._patch(jf, end)
        for bi in self._break_patches:
            self._patch(bi, end)
        self._break_patches, self._continue_patches = saved_b, saved_c

    def _for(self, node: ForStmt):
        self._expr(node.iter)
        self._emit(Op.MAKE_ITER)
        start = self._here()
        fi = self._emit(Op.FOR_ITER, None)
        self._emit(Op.DEFINE_NAME, node.var)
        saved_b, saved_c = self._break_patches, self._continue_patches
        self._break_patches, self._continue_patches = [], []
        for s in node.body:
            self._stmt(s)
        for ci in self._continue_patches:
            self._patch(ci, start)
        self._emit(Op.JUMP, start)
        end = self._here()
        self._patch(fi, end)
        for bi in self._break_patches:
            self._patch(bi, end)
        self._break_patches, self._continue_patches = saved_b, saved_c

    def _try_catch(self, node: TryCatch):
        st = self._emit(Op.SETUP_TRY, None)
        for s in node.try_body:
            self._stmt(s)
        self._emit(Op.END_TRY)
        j = self._emit(Op.JUMP, None)
        catch_ip = self._here()
        self._patch(st, (catch_ip, node.err_var))
        for s in node.catch_body:
            self._stmt(s)
        self._patch(j, self._here())

    def _class(self, node: ClassDef):
        methods = {
            fn.name: self._compile_fn(fn.name, fn.params, fn.body)
            for fn in node.methods
        }
        self._emit(Op.MAKE_CLASS, (node.name, node.parent, methods))
        self._emit(Op.DEFINE_NAME, node.name)

    def _compile_fn(self, name: str, params: list, body: list) -> CompiledFn:
        sub = Compiler()
        for stmt in body:
            sub._stmt(stmt)
        sub._emit(Op.LOAD_CONST, None)
        sub._emit(Op.RETURN)
        return CompiledFn(name, params, sub._code)

    # ── expressions ───────────────────────────────────────────────────────────

    def _expr(self, node):
        t = type(node)
        if t is Number:
            self._emit(Op.LOAD_CONST, node.value)
        elif t is String:
            self._emit(Op.LOAD_CONST, node.value)
        elif t is Bool:
            self._emit(Op.LOAD_CONST, node.value)
        elif t is Null:
            self._emit(Op.LOAD_CONST, None)
        elif t is Ident:
            self._emit(Op.LOAD_NAME, node.name)
        elif t is BinOp:
            if node.op == "||":
                # a || b: evaluate a; if truthy keep it, else evaluate b
                self._expr(node.left)
                self._emit(Op.DUP)
                jf = self._emit(Op.JUMP_IF_FALSE, None)   # if falsy, go evaluate b
                j  = self._emit(Op.JUMP, None)            # truthy: skip b
                self._patch(jf, self._here())
                self._emit(Op.POP)                        # discard a, replace with b
                self._expr(node.right)
                self._patch(j, self._here())
            elif node.op == "&&":
                # a && b: evaluate a; if falsy keep it, else evaluate b
                self._expr(node.left)
                self._emit(Op.DUP)
                jf = self._emit(Op.JUMP_IF_FALSE, None)   # if falsy, keep a
                self._emit(Op.POP)                        # discard a, replace with b
                self._expr(node.right)
                self._patch(jf, self._here())
            else:
                self._expr(node.left)
                self._expr(node.right)
                self._emit(Op.BINARY_OP, node.op)
        elif t is UnaryOp:
            self._expr(node.right)
            self._emit(Op.UNARY_OP, node.op)
        elif t is Call:
            self._emit(Op.LOAD_NAME, node.name)
            for a in node.args:
                self._expr(a)
            self._emit(Op.CALL, len(node.args))
        elif t is ListLiteral:
            for e in node.elements:
                self._expr(e)
            self._emit(Op.MAKE_LIST, len(node.elements))
        elif t is DictLiteral:
            for k, v in node.pairs:
                self._expr(k)
                self._expr(v)
            self._emit(Op.MAKE_DICT, len(node.pairs))
        elif t is IndexGet:
            self._expr(node.obj)
            self._expr(node.index)
            self._emit(Op.INDEX_GET)
        elif t is IndexSet:
            self._expr(node.obj)
            self._expr(node.index)
            self._expr(node.value)
            self._emit(Op.INDEX_SET)
        elif t is GetAttr:
            self._expr(node.obj)
            self._emit(Op.GET_ATTR, node.attr)
        elif t is SetAttr:
            self._expr(node.obj)
            self._expr(node.value)
            self._emit(Op.SET_ATTR, node.attr)
        elif t is MethodCall:
            self._expr(node.obj)
            for a in node.args:
                self._expr(a)
            self._emit(Op.METHOD_CALL, (node.method, len(node.args)))
        elif t is CallExpr:
            self._expr(node.callee)
            for a in node.args:
                self._expr(a)
            self._emit(Op.CALL, len(node.args))
        elif t is AnonFn:
            fn = self._compile_fn("<anon>", node.params, node.body)
            self._emit(Op.MAKE_FUNCTION, fn)
        elif t is TemplateStr:
            # TemplateStr.parts are already resolved by parser into str/Call nodes
            # so we just evaluate them and concatenate
            if not node.parts:
                self._emit(Op.LOAD_CONST, "")
            else:
                first = True
                for part in node.parts:
                    if isinstance(part, str):
                        self._emit(Op.LOAD_CONST, part)
                    else:
                        self._expr(part)
                    if not first:
                        self._emit(Op.BINARY_OP, "+")
                    first = False
        else:
            raise ValueError(f"Unknown expression node: {type(node).__name__}")
