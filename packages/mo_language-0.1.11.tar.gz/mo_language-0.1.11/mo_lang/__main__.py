"""
mo_lang.__main__ — entry point for the Mo language.
Invoked via `mo` console script or `python -m mo_lang`.

Usage:
    mo program.mo           # compile + run (bytecode VM)
    mo                      # interactive REPL
    mo --interp file.mo     # tree-walk interpreter (fallback)
    mo --dis file.mo        # disassemble bytecode
    mo install <pkg>        # install a package
    mo remove <pkg>         # remove a package
    mo list                 # list installed packages
"""
import sys
from .lexer import Lexer, LexError
from .parser import Parser, ParseError
from .interpreter import RuntimeError_


def _parse(source: str):
    tokens = Lexer(source).tokenize()
    return Parser(tokens).parse()


# ── VM path ───────────────────────────────────────────────────────────────────

def vm_execute(source: str, vm, env=None):
    from .compiler import Compiler
    from .vm import MoThrow
    try:
        code = Compiler().compile(_parse(source))
        vm.run(code, env)
    except LexError as e:
        print(f"[Lex Error] {e}")
    except ParseError as e:
        print(f"[Parse Error] {e}")
    except MoThrow as e:
        print(f"[Uncaught throw] {e.value}")
    except RuntimeError_ as e:
        line = getattr(vm, '_current_line', 0)
        loc = f" line {line}:" if line else ""
        print(f"[Runtime Error]{loc} {e}")


def vm_repl():
    from .vm import VM
    from .interpreter import Environment
    machine = VM()
    env = Environment(parent=machine.globals)
    print("Mo REPL  (type 'exit' to quit)")
    while True:
        try:
            line = input(">>> ")
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break
        if line.strip() == "exit":
            break
        if line.strip():
            vm_execute(line, machine, env)


def _find_cvm():
    """Return path to the C VM binary if it exists and is executable."""
    import os, shutil, sys
    bin_name = "mo-vm.exe" if sys.platform == "win32" else "mo-vm"
    candidates = [
        # installed: binary compiled into the package directory
        os.path.join(os.path.dirname(__file__), bin_name),
        # dev: built in cvm/ sibling directory
        os.path.join(os.path.dirname(__file__), "..", "cvm", bin_name),
        # on PATH
        shutil.which(bin_name),
    ]
    for c in candidates:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            return os.path.abspath(c)
    return None


def _cvm_run_file(path: str, cvm_bin: str, trace: bool = False):
    import os, tempfile, subprocess
    from .compiler import Compiler
    from .bytecode import bytecode_to_json
    try:
        source = open(path).read()
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        code = Compiler().compile(_parse(source))
        json_bytes = bytecode_to_json(code).encode()
    except (LexError, ParseError) as e:
        print(f"[Parse Error] {e}")
        sys.exit(1)

    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tf:
        tf.write(json_bytes)
        tf_name = tf.name

    try:
        cmd = [cvm_bin]
        if trace:
            cmd.append("--trace")
        cmd += [tf_name, os.path.abspath(path)]
        result = subprocess.run(cmd)
        sys.exit(result.returncode)
    finally:
        os.unlink(tf_name)


def vm_run_file(path: str, trace: bool = False):
    import os
    cvm = _find_cvm()
    if cvm:
        _cvm_run_file(path, cvm, trace=trace)
        return
    # C VM not available (gcc missing at install time) — use Python VM
    from .vm import VM
    try:
        source = open(path).read()
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    machine = VM(trace=trace)
    machine._base_dir = os.path.dirname(os.path.abspath(path))
    vm_execute(source, machine)


# ── disassembler ──────────────────────────────────────────────────────────────

def disassemble(path: str):
    from .compiler import Compiler
    try:
        source = open(path).read()
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        code = Compiler().compile(_parse(source))
    except (LexError, ParseError) as e:
        print(f"[Error] {e}")
        sys.exit(1)
    _dis_code(code, "<module>")


def _dis_code(code: list, name: str, indent: int = 0):
    from .compiler import Op
    pad = "  " * indent
    print(f"{pad}=== {name} ===")
    for i, instr in enumerate(code):
        if instr.op is Op.MAKE_FUNCTION:
            print(f"{pad}{i:4d}  {instr.op.name}  {instr.arg.name}")
            _dis_code(instr.arg.code, instr.arg.name, indent + 1)
        elif instr.op is Op.MAKE_CLASS:
            cname, parent, methods = instr.arg
            print(f"{pad}{i:4d}  {instr.op.name}  {cname}"
                  + (f" extends {parent}" if parent else ""))
            for mname, cfn in methods.items():
                _dis_code(cfn.code, f"{cname}.{mname}", indent + 1)
        else:
            arg_str = "" if instr.arg is None else f"  {instr.arg!r}"
            print(f"{pad}{i:4d}  {instr.op.name}{arg_str}")


# ── interpreter fallback ──────────────────────────────────────────────────────

def interp_run_file(path: str):
    import os
    from .interpreter import Interpreter
    try:
        source = open(path).read()
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    interp = Interpreter()
    interp._base_dir = os.path.dirname(os.path.abspath(path))
    try:
        interp.run(_parse(source))
    except LexError as e:
        print(f"[Lex Error] {e}")
    except ParseError as e:
        print(f"[Parse Error] {e}")
    except RuntimeError_ as e:
        line = getattr(interp, '_current_line', 0)
        loc = f" line {line}:" if line else ""
        print(f"[Runtime Error]{loc} {e}")


# ── package manager ───────────────────────────────────────────────────────────

def _packages_dir() -> str:
    import os
    d = os.path.expanduser("~/.mo/packages")
    os.makedirs(d, exist_ok=True)
    return d


def _lock_path() -> str:
    import os
    return os.path.join(_packages_dir(), "mo.lock")


def _read_lock() -> dict:
    import json, os
    p = _lock_path()
    if os.path.exists(p):
        try:
            return json.loads(open(p).read())
        except Exception:
            pass
    return {}


def _write_lock(lock: dict):
    import json
    open(_lock_path(), "w").write(json.dumps(lock, indent=2) + "\n")


def pkg_install(spec: str):
    """Install a Mo package.

    mo install https://example.com/foo.mo      → download directly
    mo install user/repo                        → GitHub shorthand
    mo install user/repo/path/to/file.mo       → specific file on GitHub
    """
    import os, urllib.request
    pkgs = _packages_dir()

    if spec.startswith("http://") or spec.startswith("https://"):
        url = spec
        filename = url.split("/")[-1]
        if not filename.endswith(".mo"):
            filename += ".mo"
    elif "/" in spec:
        # support user/repo@v1.2.3 or user/repo@tag
        version = "main"
        if "@" in spec:
            spec, version = spec.rsplit("@", 1)
        parts = spec.split("/")
        if len(parts) == 2:
            user, repo = parts
            url = f"https://raw.githubusercontent.com/{user}/{repo}/{version}/{repo}.mo"
            filename = f"{repo}.mo"
        else:
            user, repo = parts[0], parts[1]
            file_path = "/".join(parts[2:])
            url = f"https://raw.githubusercontent.com/{user}/{repo}/{version}/{file_path}"
            filename = parts[-1] if parts[-1].endswith(".mo") else parts[-1] + ".mo"
    else:
        print(f"[mo] Unknown package spec: {spec!r}")
        print("     Usage: mo install <url> | mo install user/repo | mo install user/repo/file.mo")
        sys.exit(1)

    dest = os.path.join(pkgs, filename)
    print(f"[mo] Installing {filename} from {url} ...")
    try:
        urllib.request.urlretrieve(url, dest)
        print(f"[mo] Installed → {dest}")
        print(f"[mo] Use with: import \"{filename[:-3]}\"")
        lock = _read_lock()
        lock[filename[:-3]] = {"url": url, "file": filename}
        _write_lock(lock)
    except Exception as e:
        print(f"[mo] Install failed: {e}")
        sys.exit(1)


def pkg_remove(name: str):
    import os
    pkgs = _packages_dir()
    filename = name if name.endswith(".mo") else name + ".mo"
    path = os.path.join(pkgs, filename)
    if os.path.exists(path):
        os.remove(path)
        lock = _read_lock()
        lock.pop(name.rstrip(".mo"), None)
        _write_lock(lock)
        print(f"[mo] Removed {filename}")
    else:
        print(f"[mo] Package not found: {filename}")
        sys.exit(1)


def pkg_list():
    import os, glob
    pkgs = _packages_dir()
    files = sorted(glob.glob(os.path.join(pkgs, "**/*.mo"), recursive=True))
    if not files:
        print("[mo] No packages installed. Use: mo install <url>")
        return
    print(f"[mo] Installed packages ({pkgs}):")
    for f in files:
        name = os.path.relpath(f, pkgs)
        print(f"  {name}")


# ── entry point ───────────────────────────────────────────────────────────────

def _check_path():
    import os, shutil
    if shutil.which("mo"):
        return
    import sysconfig
    scripts_dir = sysconfig.get_path("scripts")
    if sys.platform == "win32":
        print(f"\n[Mo] 提示: 'mo' 命令未加入 PATH，请按以下步骤添加：")
        print(f"  1. 搜索「环境变量」→ 编辑系统环境变量 → 环境变量")
        print(f"  2. 在「用户变量」的 Path 里点「新建」，粘贴：")
        print(f"     {scripts_dir}")
        print(f"  3. 重新打开命令行即可使用 mo 命令")
        print(f"  (现在可继续用 'python -m mo_language' 代替 'mo')\n")
    else:
        shell_rc = "~/.zshrc" if os.environ.get("SHELL", "").endswith("zsh") else "~/.bashrc"
        print(f"\n[Mo] 提示: 'mo' 命令未加入 PATH，运行以下命令添加：")
        print(f'  echo \'export PATH="{scripts_dir}:$PATH"\' >> {shell_rc}')
        print(f"  source {shell_rc}\n")


_HELP = """\
Mo programming language  (https://github.com/qinghua/mo)

Usage:
  mo                        Start interactive REPL
  mo <file.mo>              Run a Mo source file
  mo -h, --help             Show this help message
  mo --version              Show version number
  mo --dis <file.mo>        Disassemble bytecode
  mo --trace <file.mo>      Run with instruction-level trace (debug)
  mo --interp <file.mo>     Run via tree-walk interpreter (fallback)

Package manager:
  mo install <url>                     Install package from URL
  mo install <user/repo>               Install from GitHub (main branch)
  mo install <user/repo@tag>           Install a specific tag/version
  mo install <user/repo/path/file.mo>  Install a specific file
  mo remove <package>                  Remove an installed package
  mo list                              List installed packages

Standard library modules (use: import "std/name" as name):
  std/math      sqrt, pow, abs, floor, ceil, round, sin, cos, log, pi, e
  std/list      push, pop, len, map, filter, reduce, sort, reverse, join
  std/json      stringify, parse
  std/time      now, sleep, format
  std/http      serve, get, post
  std/file      read, write, exists, delete, list
  std/path      join, basename, dirname, exists
  std/os        env, args, exit, cwd
  std/net       listen, connect, send, recv, close
  std/random    rand, randint, choice, shuffle
  std/crypto    md5, sha256, base64_encode, base64_decode
  std/url       encode, decode, parse
  std/process   run, spawn, exec

Language features:
  let x = 10                Variables
  fn add(a, b) { a + b }    Functions
  let f = fn(x) { x * 2 }  Anonymous functions
  `Hello, ${name}!`         Template strings
  import "std/json" as json Module imports with namespace
  class Foo extends Bar {}  Classes with inheritance
  try { } catch e { }       Exception handling
  throw "error"             Throw exceptions
  for x in list { }         For loops
  while cond { }            While loops
  break / continue          Loop control

Examples:
  mo hello.mo
  mo install alice/mylib
  mo install alice/mylib@v1.2.0
"""


def main():
    args = sys.argv[1:]
    if not args:
        _check_path()
        vm_repl()
    elif args[0] in ("-h", "--help"):
        print(_HELP)
    elif args[0] == "--version":
        from importlib.metadata import version as _v
        try:
            ver = _v('mo-language')
        except Exception:
            ver = "dev"
        cvm = _find_cvm()
        vm_info = f"C VM ({cvm})" if cvm else "Python VM (C VM not built)"
        print(f"mo {ver}  [{vm_info}]")
    elif args[0] == "install":
        if len(args) < 2:
            print("Usage: mo install <url | user/repo | user/repo/file.mo>")
            sys.exit(1)
        pkg_install(args[1])
    elif args[0] == "remove":
        if len(args) < 2:
            print("Usage: mo remove <package-name>")
            sys.exit(1)
        pkg_remove(args[1])
    elif args[0] == "list":
        pkg_list()
    elif args[0] == "--interp":
        if len(args) < 2:
            print("Usage: mo --interp <file.mo>")
            sys.exit(1)
        interp_run_file(args[1])
    elif args[0] == "--dis":
        if len(args) < 2:
            print("Usage: mo --dis <file.mo>")
            sys.exit(1)
        disassemble(args[1])
    elif args[0] == "--trace":
        if len(args) < 2:
            print("Usage: mo --trace <file.mo>")
            sys.exit(1)
        vm_run_file(args[1], trace=True)
    else:
        vm_run_file(args[0])


if __name__ == "__main__":
    main()
