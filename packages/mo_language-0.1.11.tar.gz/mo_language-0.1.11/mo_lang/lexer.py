"""
Lexer — turns source code into a list of tokens.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto


class TT(Enum):
    # Literals
    NUMBER   = auto()
    STRING   = auto()
    IDENT    = auto()
    TEMPLATE = auto()   # `hello ${expr}`

    # Keywords
    LET     = auto()
    IF      = auto()
    ELSE    = auto()
    WHILE   = auto()
    FOR     = auto()
    IN      = auto()
    FN      = auto()
    RETURN  = auto()
    TRUE    = auto()
    FALSE   = auto()
    NULL    = auto()
    TRY     = auto()
    CATCH   = auto()
    THROW   = auto()
    IMPORT  = auto()
    CLASS   = auto()
    EXTENDS = auto()
    DOT     = auto()
    AS      = auto()
    BREAK   = auto()
    CONTINUE = auto()

    # Operators
    PLUS    = auto()
    MINUS   = auto()
    STAR    = auto()
    SLASH   = auto()
    ASSIGN  = auto()   # =
    EQ      = auto()   # ==
    NEQ     = auto()   # !=
    LT      = auto()   # <
    GT      = auto()   # >
    LTE     = auto()   # <=
    GTE     = auto()   # >=
    AND      = auto()   # &&
    OR       = auto()   # ||
    BANG     = auto()   # !
    FLOORDIV = auto()   # //
    PERCENT  = auto()   # %

    # Delimiters
    LPAREN   = auto()
    RPAREN   = auto()
    LBRACE   = auto()
    RBRACE   = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    COMMA    = auto()
    COLON    = auto()
    NEWLINE  = auto()

    EOF = auto()


KEYWORDS = {
    "let":      TT.LET,
    "if":       TT.IF,
    "else":     TT.ELSE,
    "while":    TT.WHILE,
    "for":      TT.FOR,
    "in":       TT.IN,
    "fn":       TT.FN,
    "return":   TT.RETURN,
    "true":     TT.TRUE,
    "false":    TT.FALSE,
    "null":     TT.NULL,
    "try":      TT.TRY,
    "catch":    TT.CATCH,
    "throw":    TT.THROW,
    "import":   TT.IMPORT,
    "class":    TT.CLASS,
    "extends":  TT.EXTENDS,
    "as":       TT.AS,
    "break":    TT.BREAK,
    "continue": TT.CONTINUE,
}


@dataclass
class Token:
    type:  TT
    value: object   # str | float | list | None
    line:  int

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, line={self.line})"


class LexError(Exception):
    pass


class Lexer:
    def __init__(self, source: str):
        self.src  = source
        self.pos  = 0
        self.line = 1

    def _peek(self, offset=0) -> str:
        i = self.pos + offset
        return self.src[i] if i < len(self.src) else ""

    def _advance(self) -> str:
        ch = self.src[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
        return ch

    def _match(self, expected: str) -> bool:
        if self._peek() == expected:
            self._advance()
            return True
        return False

    def _tok(self, tt: TT, value=None) -> Token:
        return Token(tt, value, self.line)

    def tokenize(self) -> list[Token]:
        tokens = []
        while self.pos < len(self.src):
            tok = self._next()
            if tok:
                tokens.append(tok)
        tokens.append(self._tok(TT.EOF))
        return tokens

    def _next(self) -> Token | None:
        ch = self._peek()

        if ch in " \t\r":
            self._advance()
            return None

        if ch == "\n":
            self._advance()
            return self._tok(TT.NEWLINE)

        if ch == "#":
            while self._peek() and self._peek() != "\n":
                self._advance()
            return None

        if ch.isdigit() or (ch == "." and self._peek(1).isdigit()):
            return self._read_number()

        if ch in ('"', "'"):
            return self._read_string()

        if ch == "`":
            return self._read_template()

        if ch.isalpha() or ch == "_":
            return self._read_ident()

        self._advance()
        if ch == "=" and self._match("="): return self._tok(TT.EQ)
        if ch == "!" and self._match("="): return self._tok(TT.NEQ)
        if ch == "<" and self._match("="): return self._tok(TT.LTE)
        if ch == ">" and self._match("="): return self._tok(TT.GTE)
        if ch == "&" and self._match("&"): return self._tok(TT.AND)
        if ch == "|" and self._match("|"): return self._tok(TT.OR)
        if ch == "/" and self._match("/"):  return self._tok(TT.FLOORDIV)

        single = {
            "+": TT.PLUS, "-": TT.MINUS, "*": TT.STAR, "/": TT.SLASH, "%": TT.PERCENT,
            "=": TT.ASSIGN, "<": TT.LT, ">": TT.GT, "!": TT.BANG,
            "(": TT.LPAREN, ")": TT.RPAREN, "{": TT.LBRACE, "}": TT.RBRACE,
            "[": TT.LBRACKET, "]": TT.RBRACKET,
            ",": TT.COMMA, ":": TT.COLON, ".": TT.DOT,
        }
        if ch in single:
            return self._tok(single[ch])

        raise LexError(f"Unknown character {ch!r} at line {self.line}")

    def _read_number(self) -> Token:
        start = self.pos
        while self._peek().isdigit():
            self._advance()
        if self._peek() == "." and self._peek(1).isdigit():
            self._advance()
            while self._peek().isdigit():
                self._advance()
        return self._tok(TT.NUMBER, float(self.src[start:self.pos]))

    def _read_string(self) -> Token:
        quote = self._advance()
        chars = []
        while self._peek() and self._peek() != quote:
            ch = self._advance()
            if ch == "\\":
                esc = self._advance()
                ch = {"n": "\n", "t": "\t", "\\": "\\", '"': '"', "'": "'"}.get(esc, esc)
            chars.append(ch)
        if not self._peek():
            raise LexError(f"Unterminated string at line {self.line}")
        self._advance()
        return self._tok(TT.STRING, "".join(chars))

    def _read_template(self) -> Token:
        """Tokenize `hello ${expr} world` into a list of parts.
        Each part is either a str (literal) or ("expr", src_string).
        """
        self._advance()  # opening backtick
        parts = []
        buf = []
        while self._peek() and self._peek() != "`":
            ch = self._peek()
            if ch == "$" and self._peek(1) == "{":
                if buf:
                    parts.append("".join(buf))
                    buf = []
                self._advance()  # $
                self._advance()  # {
                depth = 1
                expr_chars = []
                while self._peek() and depth > 0:
                    c = self._advance()
                    if c == "{":
                        depth += 1
                        expr_chars.append(c)
                    elif c == "}":
                        depth -= 1
                        if depth > 0:
                            expr_chars.append(c)
                    else:
                        expr_chars.append(c)
                parts.append(("expr", "".join(expr_chars)))
            elif ch == "\\":
                self._advance()
                esc = self._advance()
                buf.append({"n": "\n", "t": "\t", "\\": "\\", "`": "`"}.get(esc, esc))
            else:
                buf.append(self._advance())
        if buf:
            parts.append("".join(buf))
        if not self._peek():
            raise LexError(f"Unterminated template string at line {self.line}")
        self._advance()  # closing backtick
        return self._tok(TT.TEMPLATE, parts)

    def _read_ident(self) -> Token:
        start = self.pos
        while self._peek().isalnum() or self._peek() == "_":
            self._advance()
        word = self.src[start:self.pos]
        tt = KEYWORDS.get(word, TT.IDENT)
        return self._tok(tt, word if tt == TT.IDENT else None)
