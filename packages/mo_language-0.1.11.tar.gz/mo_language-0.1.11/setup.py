"""
setup.py — builds the C VM (mo-vm) and places it inside the mo_lang package
so `mo file.mo` can find and use it automatically after `pip install`.

If a C compiler is not available the build still succeeds; Mo falls back to
the Python bytecode VM transparently.
"""
import os
import shutil
import subprocess
import sys

from setuptools import setup
from setuptools.command.build_py import build_py as _build_py


CVM_SRC = os.path.join(os.path.dirname(__file__), "cvm", "mo_vm.c")
BIN_NAME = "mo-vm.exe" if sys.platform == "win32" else "mo-vm"


def _compile_cvm(dest_dir: str) -> bool:
    """Try to compile mo_vm.c → dest_dir/mo-vm.  Return True on success."""
    out = os.path.join(dest_dir, BIN_NAME)
    cc  = os.environ.get("CC", "cl" if sys.platform == "win32" else "gcc")

    if sys.platform == "win32":
        cmd = [cc, "/O2", "/Fe" + out, CVM_SRC]
    else:
        cmd = [cc, "-O2", "-o", out, CVM_SRC, "-lm"]

    try:
        subprocess.run(cmd, check=True, capture_output=True)
        # make executable
        os.chmod(out, 0o755)
        print(f"[mo] C VM built → {out}")
        return True
    except FileNotFoundError:
        print(f"[mo] Warning: compiler '{cc}' not found — C VM not built (Python VM will be used).")
    except subprocess.CalledProcessError as e:
        print(f"[mo] Warning: C VM compile failed — {e.stderr.decode().strip()}")
    return False


class build_py(_build_py):
    def run(self):
        super().run()
        dest = os.path.join(self.build_lib, "mo_lang")
        os.makedirs(dest, exist_ok=True)
        _compile_cvm(dest)


setup(cmdclass={"build_py": build_py})
