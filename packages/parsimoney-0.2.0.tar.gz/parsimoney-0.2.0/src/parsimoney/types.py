"""parsimoney.types - Result types for parsed money values."""

from dataclasses import dataclass


@dataclass
class Money:
    amount: float
    currency: str | None = None
    iso: str | None = None
    currency_after: bool = False

    def __str__(self) -> str:
        if self.amount == int(self.amount):
            amount_str = f"{int(self.amount)}"
        else:
            amount_str = f"{self.amount:.2f}"
        label = self.currency or self.iso
        if not label:
            return amount_str
        if self.currency_after:
            return f"{amount_str} {label}"
        return f"{label}{amount_str}"
