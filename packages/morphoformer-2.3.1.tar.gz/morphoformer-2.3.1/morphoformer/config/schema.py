"""Configuration schema — dataclass hierarchy mapped to/from TOML."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict


@dataclass
class EncoderConfig:
    num_layers: int = 8
    norm: str = "rmsnorm"
    attention: str = "gqa"
    feedforward: str = "swiglu"
    conv: str = "local"
    conv_kernel: int = 7
    adapter: str = "language_conditioned"
    adapter_bottleneck: int = 128


@dataclass
class DecoderConfig:
    num_layers: int = 6
    norm: str = "rmsnorm"
    attention: str = "gqa"
    feedforward: str = "swiglu"
    adapter: str = "language_conditioned"
    adapter_bottleneck: int = 128


@dataclass
class MorphEncoderConfig:
    type: str = "pooled"
    max_features: int = 12


@dataclass
class ModelConfig:
    d_model: int = 512
    num_heads: int = 8
    num_kv_heads: int = 2
    dim_ff: int = 1376
    dropout: float = 0.15
    max_positions: int = 512
    num_languages: int = 50
    encoder: EncoderConfig = field(default_factory=EncoderConfig)
    decoder: DecoderConfig = field(default_factory=DecoderConfig)
    morph_encoder: MorphEncoderConfig = field(default_factory=MorphEncoderConfig)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DataConfig:
    train_path: str = ""
    val_path: str = ""
    max_len: int = 96
    max_out: int = 128
    pin_memory: bool = True
    prefetch_factor: int = 2

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CheckpointConfig:
    dir: str = "checkpoints"
    save_every: int = 1
    resume: str = ""


@dataclass
class TrainingConfig:
    epochs: int = 50
    batch_size: int = 64
    lr: float = 5e-4
    weight_decay: float = 0.1
    warmup_steps: int = 4000
    grad_clip: float = 1.0
    grad_accum: int = 1
    label_smoothing: float = 0.1
    device: str = "auto"
    checkpoint: CheckpointConfig = field(default_factory=CheckpointConfig)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class FullConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    data: DataConfig = field(default_factory=DataConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)

    def to_dict(self) -> dict:
        return asdict(self)
