"""MorphFormer training loop with checkpoint resume and embedding expansion."""

from __future__ import annotations

import math
import time
from pathlib import Path

import torch
import torch.nn as nn

from ..config import FullConfig
from ..data import CharVocab, FeatureVocab, MorphDataset, PAD
from ..modules import MorphFormer
from .scheduler import create_cosine_schedule
from .memory import detect_memory, plan_training, estimate_model_memory, format_bytes

LOG_INTERVALS_PER_EPOCH = 10
MATMUL_PRECISION = "high"
_GRAD_SCALER_TYPES = frozenset({"cuda", "xpu"})


class Trainer:
    def __init__(
        self,
        model: MorphFormer,
        config: FullConfig,
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        lang_to_id: dict[str, int],
        device: torch.device,
        resume_checkpoint: dict | None = None,
    ) -> None:
        self.model = model
        self.config = config
        self.char_vocab = char_vocab
        self.feature_vocab = feature_vocab
        self.lang_to_id = lang_to_id
        self.device = device
        self.start_epoch = 1
        self._resume_checkpoint = resume_checkpoint

        if resume_checkpoint is not None:
            self.start_epoch = resume_checkpoint["epoch"] + 1
            state_dict = resume_checkpoint["model"]

            self._old_char_vocab = CharVocab.from_dict(resume_checkpoint["char_vocab"])
            self._old_feat_vocab = FeatureVocab.from_dict(resume_checkpoint["feature_vocab"])
            self._old_lang_to_id = resume_checkpoint["lang_to_id"]

            state_dict = self._expand_embeddings(
                state_dict, self._old_char_vocab, char_vocab,
                self._old_feat_vocab, feature_vocab,
                self._old_lang_to_id, lang_to_id,
            )

            self.model.load_state_dict(state_dict)
            print(
                f"Resume: loaded checkpoint epoch {resume_checkpoint['epoch']}, "
                f"continuing from epoch {self.start_epoch}",
                flush=True,
            )

    def _expand_embeddings(
        self,
        state_dict: dict,
        old_char_vocab: CharVocab,
        new_char_vocab: CharVocab,
        old_feat_vocab: FeatureVocab,
        new_feat_vocab: FeatureVocab,
        old_lang_to_id: dict[str, int],
        new_lang_to_id: dict[str, int],
    ) -> dict:
        result = state_dict.copy()
        
        if "char_embedding.weight" in result:
            old_weight = result["char_embedding.weight"]
            new_size = new_char_vocab.size
            old_size = old_char_vocab.size
            
            if new_size != old_size:
                d_model = old_weight.shape[1]
                new_weight = torch.empty(new_size, d_model, dtype=old_weight.dtype)
                
                common_size = min(old_size, new_size)
                new_weight[:common_size] = old_weight[:common_size]
                
                if new_size > old_size:
                    nn.init.normal_(new_weight[old_size:], mean=0, std=d_model ** -0.5)
                
                result["char_embedding.weight"] = new_weight
                if "output_projection.weight" in result:
                    result["output_projection.weight"] = new_weight
        
        if "lang_embedding.weight" in result:
            old_weight = result["lang_embedding.weight"]
            new_num_langs = self.config.model.num_languages
            old_num_langs = old_weight.shape[0]
            
            if new_num_langs != old_num_langs:
                d_model = old_weight.shape[1]
                new_weight = torch.empty(new_num_langs, d_model, dtype=old_weight.dtype)
                
                for lang, new_id in new_lang_to_id.items():
                    if lang in old_lang_to_id:
                        old_id = old_lang_to_id[lang]
                        if old_id < old_num_langs and new_id < new_num_langs:
                            new_weight[new_id] = old_weight[old_id]
                    else:
                        if new_id < new_num_langs:
                            nn.init.normal_(new_weight[new_id:new_id+1], mean=0, std=d_model ** -0.5)
                
                for i in range(new_num_langs):
                    if i not in new_lang_to_id.values():
                        nn.init.normal_(new_weight[i:i+1], mean=0, std=d_model ** -0.5)
                
                result["lang_embedding.weight"] = new_weight
        
        morph_embed_keys = [k for k in result.keys() if "morph_encoder" in k and "embedding" in k]
        for key in morph_embed_keys:
            old_weight = result[key]
            new_size = new_feat_vocab.size
            old_size = old_feat_vocab.size
            
            if new_size != old_size:
                d_model = old_weight.shape[1]
                new_weight = torch.empty(new_size, d_model, dtype=old_weight.dtype)
                
                common_size = min(old_size, new_size)
                new_weight[:common_size] = old_weight[:common_size]
                
                if new_size > old_size:
                    nn.init.normal_(new_weight[old_size:], mean=0, std=d_model ** -0.5)
                
                result[key] = new_weight
        
        return result


    def train(self, dataset: MorphDataset) -> None:
        cfg = self.config
        tc = cfg.training
        mc = cfg.model

        memory_profile = detect_memory()
        memory_profile.print_info()

        model_bytes = estimate_model_memory(self.model)
        total_layers = mc.encoder.num_layers + mc.decoder.num_layers
        num_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)

        training_plan = plan_training(
            memory_profile, model_bytes, tc.batch_size,
            cfg.data.max_len, mc.d_model, total_layers, self.device.type,
        )

        print(
            f"Model: {format_bytes(model_bytes)}  params={num_params:,}\n"
            f"Plan: {training_plan.reason}\n"
            f"  batch={training_plan.batch_size}  "
            f"grad_checkpoint={'yes' if training_plan.use_gradient_checkpointing else 'no'}  "
            f"AMP={'yes' if training_plan.use_amp else 'no'}",
            flush=True,
        )

        batch_size = training_plan.batch_size
        if training_plan.use_gradient_checkpointing:
            self.model.enable_gradient_checkpointing()

        if self.device.type == "cuda":
            torch.backends.cudnn.benchmark = True
            torch.set_float32_matmul_precision(MATMUL_PRECISION)

        self.model = self.model.to(self.device)

        optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=tc.lr, weight_decay=tc.weight_decay,
        )
        criterion = nn.CrossEntropyLoss(
            ignore_index=PAD, label_smoothing=tc.label_smoothing,
        )

        use_scaler = training_plan.use_amp and self.device.type in _GRAD_SCALER_TYPES
        grad_scaler = torch.amp.GradScaler(self.device.type, enabled=use_scaler)

        batches_per_epoch = math.ceil(dataset.num_samples / batch_size)
        accum_per_epoch = math.ceil(batches_per_epoch / tc.grad_accum)
        total_steps = tc.epochs * accum_per_epoch
        scheduler = create_cosine_schedule(optimizer, tc.warmup_steps, total_steps)

        if self._resume_checkpoint is not None:
            # Check whether vocabulary sizes changed since the checkpoint
            vocab_changed = (
                self._old_char_vocab.size != self.char_vocab.size or
                self._old_feat_vocab.size != self.feature_vocab.size or
                len(self._old_lang_to_id) != len(self.lang_to_id)
            )
            
            if not vocab_changed:
                optimizer.load_state_dict(self._resume_checkpoint["optimizer"])
                scheduler.load_state_dict(self._resume_checkpoint["scheduler"])
                print("  Optimizer state restored", flush=True)
            else:
                print("  Vocabulary sizes changed, optimizer re-initialized", flush=True)
            
            self._resume_checkpoint = None

        checkpoint_dir = Path(tc.checkpoint.dir)
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        end_epoch = tc.epochs

        if self.start_epoch > end_epoch:
            print(
                f"Already trained {self.start_epoch - 1} epochs, "
                f"target is {end_epoch}. Nothing to do.",
                flush=True,
            )
            return

        print(
            f"d_model={mc.d_model}  heads={mc.num_heads}  kv_heads={mc.num_kv_heads}  "
            f"enc={mc.encoder.num_layers}  dec={mc.decoder.num_layers}  dim_ff={mc.dim_ff}\n"
            f"epochs={self.start_epoch}..{end_epoch}  batch={batch_size}  "
            f"samples={dataset.num_samples}  char_vocab={self.char_vocab.size}  "
            f"feat_vocab={self.feature_vocab.size}",
            flush=True,
        )

        try:
            for epoch in range(self.start_epoch, end_epoch + 1):
                self._train_epoch(
                    epoch, end_epoch, dataset, optimizer, criterion,
                    grad_scaler, scheduler, training_plan.use_amp,
                    batch_size, batches_per_epoch, checkpoint_dir,
                )
        except KeyboardInterrupt:
            print("\n[interrupted]", flush=True)

    def _train_epoch(
        self,
        epoch: int,
        end_epoch: int,
        dataset: MorphDataset,
        optimizer: torch.optim.Optimizer,
        criterion: nn.Module,
        grad_scaler: torch.amp.GradScaler,
        scheduler: torch.optim.lr_scheduler.LambdaLR,
        use_amp: bool,
        batch_size: int,
        total_batches: int,
        checkpoint_dir: Path,
    ) -> None:
        tc = self.config.training
        self.model.train()
        optimizer.zero_grad(set_to_none=True)
        total_loss = 0.0
        num_batches = 0
        epoch_start = time.perf_counter()
        log_interval = max(1, total_batches // LOG_INTERVALS_PER_EPOCH)

        for batch_idx, (source, target, lang_ids, feat_ids, feat_mask) in enumerate(
            dataset.epoch_batches(batch_size, self.device, self.config.data.prefetch_factor)
        ):
            with torch.amp.autocast(self.device.type, enabled=use_amp):
                logits = self.model(source, target, lang_ids, feat_ids, feat_mask)
                loss = criterion(
                    logits.reshape(-1, self.char_vocab.size),
                    target[:, 1:].reshape(-1),
                ) / tc.grad_accum

            grad_scaler.scale(loss).backward()
            total_loss += float(loss.item()) * tc.grad_accum
            num_batches += 1

            is_accum = (batch_idx + 1) % tc.grad_accum == 0
            is_last = (batch_idx + 1) == total_batches

            if is_accum or is_last:
                if tc.grad_clip > 0:
                    grad_scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), tc.grad_clip)
                grad_scaler.step(optimizer)
                grad_scaler.update()
                optimizer.zero_grad(set_to_none=True)
                scheduler.step()

            if (batch_idx + 1) % log_interval == 0 or batch_idx == 0:
                running_loss = total_loss / num_batches
                print(
                    f"\r  epoch {epoch}/{end_epoch}  "
                    f"batch {batch_idx + 1}/{total_batches}  "
                    f"loss={running_loss:.4f}",
                    end="", flush=True,
                )

        elapsed = time.perf_counter() - epoch_start
        avg_loss = total_loss / max(num_batches, 1)
        current_lr = scheduler.get_last_lr()[0]

        print(
            f"\repoch {epoch}/{end_epoch}  loss={avg_loss:.4f}  "
            f"lr={current_lr:.2e}  time={elapsed:.1f}s",
            flush=True,
        )

        if epoch % self.config.training.checkpoint.save_every == 0 or epoch == end_epoch:
            self._save_checkpoint(epoch, optimizer, scheduler, checkpoint_dir)

    def _save_checkpoint(
        self,
        epoch: int,
        optimizer: torch.optim.Optimizer,
        scheduler: torch.optim.lr_scheduler.LambdaLR,
        checkpoint_dir: Path,
    ) -> None:
        path = checkpoint_dir / f"morphformer_epoch{epoch}.pt"
        torch.save({
            "model": self.model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "char_vocab": self.char_vocab.to_dict(),
            "feature_vocab": self.feature_vocab.to_dict(),
            "lang_to_id": self.lang_to_id,
            "config": self.config.to_dict(),
            "epoch": epoch,
        }, path)
        print(f"  saved {path}", flush=True)
