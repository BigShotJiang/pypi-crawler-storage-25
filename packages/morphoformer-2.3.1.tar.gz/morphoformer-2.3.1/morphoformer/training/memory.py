"""VRAM profiling and automatic training plan: batch size, gradient checkpointing, AMP."""

from __future__ import annotations

import ctypes
import sys
from dataclasses import dataclass

import torch

# VRAM estimation heuristics
ACTIVATION_BYTES_FACTOR = 12       # bytes per element per layer
OPTIMIZER_STATE_MULTIPLIER = 2     # Adam: momentum + variance
MODEL_OVERHEAD_MULTIPLIER = 4      # params + grads + optimizer states + buffers
VRAM_PLAN_RATIO = 0.85             # safety margin for plan_training
VRAM_BATCH_RATIO = 0.80            # safety margin for suggest_batch_size
BATCH_ALIGNMENT = 8
MIN_BATCH_SIZE = 4
MAX_BATCH_SIZE = 512


def format_bytes(num_bytes: int) -> str:
    if num_bytes >= 1 << 30:
        return f"{num_bytes / (1 << 30):.1f} GB"
    if num_bytes >= 1 << 20:
        return f"{num_bytes / (1 << 20):.0f} MB"
    return f"{num_bytes / (1 << 10):.0f} KB"


def _get_system_ram() -> tuple[int, int]:
    if sys.platform == "win32":
        return _get_ram_windows()
    return _get_ram_unix()


def _get_ram_windows() -> tuple[int, int]:
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    stat = MEMORYSTATUSEX()
    stat.dwLength = ctypes.sizeof(stat)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
    return stat.ullTotalPhys, stat.ullAvailPhys


def _get_ram_unix() -> tuple[int, int]:
    try:
        with open("/proc/meminfo") as file:
            info = {}
            for line in file:
                parts = line.split()
                info[parts[0].rstrip(":")] = int(parts[1]) * 1024
            total = info.get("MemTotal", 0)
            available = info.get("MemAvailable", info.get("MemFree", 0))
            return total, available
    except FileNotFoundError:
        return 0, 0


def _get_accelerator_memory() -> tuple[int, int, str]:
    if torch.cuda.is_available():
        props = torch.cuda.get_device_properties(0)
        free, _ = torch.cuda.mem_get_info(0)
        return props.total_memory, free, props.name
    if hasattr(torch, "xpu") and torch.xpu.is_available():
        props = torch.xpu.get_device_properties(0)
        free, _ = torch.xpu.mem_get_info(0)
        return props.total_memory, free, props.name
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return 0, 0, "Apple MPS"
    return 0, 0, ""


def estimate_model_memory(model: torch.nn.Module) -> int:
    """Total bytes of unique parameters (accounts for weight tying)."""
    seen: set[int] = set()
    total = 0
    for param in model.parameters():
        if param.data_ptr() not in seen:
            seen.add(param.data_ptr())
            total += param.numel() * param.element_size()
    return total


def estimate_training_vram(
    model_bytes: int,
    batch_size: int,
    max_len: int,
    d_model: int,
    total_layers: int,
    use_gradient_checkpointing: bool,
) -> int:
    gradients = model_bytes
    optimizer = model_bytes * OPTIMIZER_STATE_MULTIPLIER
    overhead = model_bytes + gradients + optimizer

    # Gradient checkpointing reduces stored activations to ~sqrt(layers)
    effective = max(1, int(total_layers ** 0.5)) if use_gradient_checkpointing else total_layers
    activations = batch_size * max_len * d_model * effective * ACTIVATION_BYTES_FACTOR
    return overhead + activations


def suggest_batch_size(
    available_vram: int,
    model_bytes: int,
    max_len: int,
    d_model: int,
    total_layers: int,
    use_gradient_checkpointing: bool,
) -> int:
    usable = int(available_vram * VRAM_BATCH_RATIO)
    overhead = model_bytes * MODEL_OVERHEAD_MULTIPLIER
    remaining = usable - overhead
    if remaining <= 0:
        return MIN_BATCH_SIZE
    effective = max(1, int(total_layers ** 0.5)) if use_gradient_checkpointing else total_layers
    per_sample = max_len * d_model * effective * ACTIVATION_BYTES_FACTOR
    if per_sample <= 0:
        return MAX_BATCH_SIZE
    suggested = remaining // per_sample
    suggested = max(MIN_BATCH_SIZE, min(suggested, MAX_BATCH_SIZE))
    suggested = (suggested // BATCH_ALIGNMENT) * BATCH_ALIGNMENT
    return max(MIN_BATCH_SIZE, suggested)


@dataclass
class MemoryProfile:
    ram_total: int
    ram_available: int
    gpu_total: int
    gpu_free: int
    gpu_name: str

    @property
    def has_gpu(self) -> bool:
        return self.gpu_total > 0 or bool(self.gpu_name)

    @property
    def has_vram_info(self) -> bool:
        return self.gpu_total > 0

    def print_info(self) -> None:
        print(f"RAM: {format_bytes(self.ram_available)} free / {format_bytes(self.ram_total)} total")
        if self.has_vram_info:
            print(f"GPU: {self.gpu_name}  {format_bytes(self.gpu_free)} free / {format_bytes(self.gpu_total)} total")
        elif self.has_gpu:
            print(f"GPU: {self.gpu_name}")
        else:
            print("GPU: not detected")


@dataclass
class TrainingPlan:
    batch_size: int
    use_gradient_checkpointing: bool
    use_amp: bool
    estimated_vram: int
    reason: str


def detect_memory() -> MemoryProfile:
    ram_total, ram_available = _get_system_ram()
    gpu_total, gpu_free, gpu_name = _get_accelerator_memory()
    return MemoryProfile(ram_total, ram_available, gpu_total, gpu_free, gpu_name)


def plan_training(
    profile: MemoryProfile,
    model_bytes: int,
    requested_batch_size: int,
    max_len: int,
    d_model: int,
    total_layers: int,
    device_type: str = "cuda",
) -> TrainingPlan:
    """Select batch size / gradient checkpointing / AMP based on available VRAM."""
    if device_type == "cpu":
        return TrainingPlan(requested_batch_size, False, False, 0, "training on CPU")

    if not profile.has_gpu:
        print("No GPU detected. Use --device cpu.", flush=True)
        sys.exit(1)

    if not profile.has_vram_info:
        return TrainingPlan(
            requested_batch_size, False, True, 0,
            f"{profile.gpu_name} — VRAM info unavailable",
        )

    gpu_available = profile.gpu_free

    full_est = estimate_training_vram(
        model_bytes, requested_batch_size, max_len, d_model, total_layers, False,
    )
    if full_est < gpu_available * VRAM_PLAN_RATIO:
        return TrainingPlan(requested_batch_size, False, True, full_est, "fits in VRAM")

    ckpt_est = estimate_training_vram(
        model_bytes, requested_batch_size, max_len, d_model, total_layers, True,
    )
    if ckpt_est < gpu_available * VRAM_PLAN_RATIO:
        return TrainingPlan(requested_batch_size, True, True, ckpt_est, "gradient checkpointing enabled")

    auto_batch = suggest_batch_size(
        gpu_available, model_bytes, max_len, d_model, total_layers, True,
    )
    auto_est = estimate_training_vram(
        model_bytes, auto_batch, max_len, d_model, total_layers, True,
    )
    return TrainingPlan(
        auto_batch, True, True, auto_est,
        f"batch {requested_batch_size}→{auto_batch}, gradient checkpointing",
    )
