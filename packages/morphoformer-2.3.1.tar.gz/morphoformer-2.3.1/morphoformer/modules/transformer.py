"""MorphFormer: encoder-decoder Transformer for morphological reinflection."""

from __future__ import annotations

import math

import torch
import torch.nn as nn

from .encoder import Encoder
from .decoder import Decoder
from .position import RotaryEmbedding
from . import registry

EMBEDDING_INIT_STD = 0.02


class MorphFormer(nn.Module):
    def __init__(
        self,
        char_vocab_size: int,
        feature_vocab_size: int,
        num_languages: int,
        *,
        d_model: int = 512,
        num_heads: int = 8,
        num_kv_heads: int = 2,
        num_encoder_layers: int = 8,
        num_decoder_layers: int = 6,
        dim_ff: int = 1376,
        dropout: float = 0.15,
        max_positions: int = 512,
        conv_kernel: int = 7,
        enc_adapter_bottleneck: int = 128,
        dec_adapter_bottleneck: int = 128,
        max_features: int = 12,
        enc_norm_type: str = "rmsnorm",
        dec_norm_type: str = "rmsnorm",
        enc_attention_type: str = "gqa",
        dec_attention_type: str = "gqa",
        enc_feedforward_type: str = "swiglu",
        dec_feedforward_type: str = "swiglu",
        conv_type: str = "local",
        enc_adapter_type: str = "language_conditioned",
        dec_adapter_type: str = "language_conditioned",
        morph_encoder_type: str = "pooled",
        char_pad_id: int = 0,
        feature_pad_id: int = 0,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.max_positions = max_positions
        self.embed_scale = math.sqrt(d_model)
        self.char_pad_id = char_pad_id

        self.char_embedding = nn.Embedding(char_vocab_size, d_model, padding_idx=char_pad_id)
        self.lang_embedding = nn.Embedding(num_languages, d_model)
        self.embed_dropout = nn.Dropout(dropout)

        morph_cls = registry.get("morph_encoder", morph_encoder_type)
        self.morph_encoder = morph_cls(feature_vocab_size, d_model, max_features, feature_pad_id)

        self.rope = RotaryEmbedding(d_model // num_heads, max_positions)

        self.encoder = Encoder(
            num_encoder_layers, d_model, num_heads, num_kv_heads, dim_ff,
            dropout, conv_kernel, enc_adapter_bottleneck,
            enc_norm_type, enc_attention_type, enc_feedforward_type, conv_type, enc_adapter_type,
        )

        self.decoder = Decoder(
            num_decoder_layers, d_model, num_heads, num_kv_heads, dim_ff,
            dropout, dec_adapter_bottleneck,
            dec_norm_type, dec_attention_type, dec_feedforward_type, dec_adapter_type,
        )

        # Weight tying: output projection shares char_embedding weights
        self.output_projection = nn.Linear(d_model, char_vocab_size, bias=False)
        self.output_projection.weight = self.char_embedding.weight

        self._init_weights()

    def _init_weights(self) -> None:
        for param in self.parameters():
            if param.dim() > 1:
                nn.init.xavier_uniform_(param)
        nn.init.normal_(self.char_embedding.weight, std=EMBEDDING_INIT_STD)
        nn.init.normal_(self.lang_embedding.weight, std=EMBEDDING_INIT_STD)
        with torch.no_grad():
            self.char_embedding.weight[self.char_pad_id].zero_()

    def enable_gradient_checkpointing(self) -> None:
        self.encoder.enable_gradient_checkpointing()
        self.decoder.enable_gradient_checkpointing()

    def disable_gradient_checkpointing(self) -> None:
        self.encoder.disable_gradient_checkpointing()
        self.decoder.disable_gradient_checkpointing()

    @staticmethod
    def _pad_to_attn_mask(padding_mask: torch.Tensor) -> torch.Tensor:
        """Convert bool padding mask to float attention mask (-inf for masked positions)."""
        mask = torch.zeros_like(padding_mask, dtype=torch.float)
        mask.masked_fill_(padding_mask, float("-inf"))
        return mask.unsqueeze(1).unsqueeze(2)

    @staticmethod
    def _causal_attn_mask(size: int, device: torch.device) -> torch.Tensor:
        return torch.triu(
            torch.full((size, size), float("-inf"), device=device), diagonal=1,
        ).unsqueeze(0).unsqueeze(0)

    def encode(
        self,
        source: torch.Tensor,
        lang_ids: torch.Tensor,
        feature_ids: torch.Tensor,
        feature_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Run encoder: lemma + morph features -> memory ``(batch, src_len+1, d_model)``."""
        source_padding_mask = source == self.char_pad_id
        lang_embed = self.lang_embedding(lang_ids)

        hidden = self.embed_dropout(
            self.char_embedding(source) * self.embed_scale + lang_embed.unsqueeze(1)
        )
        rope_cos, rope_sin = self.rope(source.size(1), source.device)

        enc_attn_mask = (
            self._pad_to_attn_mask(source_padding_mask) if source_padding_mask.any() else None
        )
        encoder_out = self.encoder(hidden, rope_cos, rope_sin, lang_embed, enc_attn_mask)

        morph_vec = self.morph_encoder(feature_ids, feature_mask).unsqueeze(1)
        memory = torch.cat([morph_vec, encoder_out], dim=1)

        morph_pad = torch.zeros(source.size(0), 1, dtype=torch.bool, device=source.device)
        full_padding_mask = torch.cat([morph_pad, source_padding_mask], dim=1)

        return memory, full_padding_mask

    def forward(
        self,
        source: torch.Tensor,
        target: torch.Tensor,
        lang_ids: torch.Tensor,
        feature_ids: torch.Tensor,
        feature_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Teacher-forced forward pass -> logits ``(batch, tgt_len-1, vocab_size)``."""
        memory, source_padding_mask = self.encode(source, lang_ids, feature_ids, feature_mask)
        lang_embed = self.lang_embedding(lang_ids)

        target_input = target[:, :-1]
        if target_input.size(1) == 0:
            raise ValueError("target sequence too short")

        hidden = self.embed_dropout(
            self.char_embedding(target_input) * self.embed_scale + lang_embed.unsqueeze(1)
        )
        rope_cos, rope_sin = self.rope(target_input.size(1), target.device)

        self_attn_mask = self._causal_attn_mask(target_input.size(1), target.device)
        target_padding_mask = target_input == self.char_pad_id
        if target_padding_mask.any():
            self_attn_mask = self_attn_mask + self._pad_to_attn_mask(target_padding_mask)

        cross_attn_mask = (
            self._pad_to_attn_mask(source_padding_mask) if source_padding_mask.any() else None
        )

        decoder_out = self.decoder(
            hidden, memory, rope_cos, rope_sin, lang_embed,
            self_attn_mask, cross_attn_mask,
        )
        return self.output_projection(decoder_out)
