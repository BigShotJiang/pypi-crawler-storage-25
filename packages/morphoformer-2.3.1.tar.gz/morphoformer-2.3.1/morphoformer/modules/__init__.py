"""Importing this package triggers @register decorators in all submodules."""

from . import norm        # noqa: F401
from . import position    # noqa: F401
from . import attention   # noqa: F401
from . import feedforward # noqa: F401
from . import conv        # noqa: F401
from . import adapter     # noqa: F401
from . import morph_encoder  # noqa: F401

from .registry import get, list_modules
from .transformer import MorphFormer
from .encoder import Encoder, EncoderLayer
from .decoder import Decoder, DecoderLayer
