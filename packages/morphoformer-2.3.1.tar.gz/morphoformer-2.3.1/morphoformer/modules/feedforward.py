"""Feed-forward network variants: SwiGLU and GeLU."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .registry import register


@register("feedforward", "swiglu")
class SwiGLUFeedForward(nn.Module):
    """SwiGLU (Shazeer, 2020). Optimal ``dim_ff ≈ (8/3) * d_model``."""

    def __init__(self, d_model: int, dim_ff: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.gate_proj = nn.Linear(d_model, dim_ff, bias=False)
        self.up_proj = nn.Linear(d_model, dim_ff, bias=False)
        self.down_proj = nn.Linear(dim_ff, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x)))


@register("feedforward", "gelu")
class GeLUFeedForward(nn.Module):
    def __init__(self, d_model: int, dim_ff: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.linear1 = nn.Linear(d_model, dim_ff)
        self.linear2 = nn.Linear(dim_ff, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.linear2(F.gelu(self.linear1(x))))
