"""Pre-encoded in-memory dataset with CUDA stream prefetch."""

from __future__ import annotations

from pathlib import Path
from typing import Generator

import torch

from .vocab import CharVocab
from .feature_vocab import FeatureVocab


def load_tsv(path: str) -> list[tuple[str, list[str], str, str]]:
    """Load a TSV file (lemma\\tfeatures\\tsurface[\\tlang]) into a list of tuples."""
    rows: list[tuple[str, list[str], str, str]] = []
    with open(path, encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) < 3:
                continue
            lemma = parts[0]
            tags = parts[1].split(";")
            surface = parts[2]
            lang = parts[3] if len(parts) > 3 else "unk"
            rows.append((lemma, tags, surface, lang))
    return rows


def load_tsv_pattern(pattern: str) -> list[tuple[str, list[str], str, str]]:
    """Load multiple TSV files matching a glob pattern (e.g. ``data/*_train.tsv``)."""
    rows: list[tuple[str, list[str], str, str]] = []
    path_obj = Path(pattern)

    if path_obj.is_file():
        return load_tsv(pattern)

    if "*" in pattern or "?" in pattern or "[" in pattern:
        parent_dir = path_obj.parent if path_obj.parent != Path(".") else Path(".")
        files = sorted(parent_dir.glob(path_obj.name))
        if not files:
            raise FileNotFoundError(f"No files matched pattern: {pattern}")
        for file_path in files:
            if file_path.is_file():
                print(f"  Loading: {file_path}", flush=True)
                rows.extend(load_tsv(str(file_path)))
    else:
        rows.extend(load_tsv(pattern))

    return rows


class MorphDataset:
    """All samples pre-encoded as tensors in RAM; batches served via CUDA stream prefetch."""

    def __init__(
        self,
        rows: list[tuple[str, list[str], str, str]],
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        lang_to_id: dict[str, int],
        max_len: int = 96,
        max_features: int = 12,
        pin_memory: bool = True,
    ) -> None:
        num_samples = len(rows)
        source_ids: list[list[int]] = []
        target_ids: list[list[int]] = []
        feat_ids: list[list[int]] = []
        feat_masks: list[list[float]] = []
        lang_ids_list: list[int] = []

        for lemma, tags, surface, lang in rows:
            source_ids.append(char_vocab.encode_ids(lemma, max_len))
            target_ids.append(char_vocab.encode_ids(surface, max_len))
            fids, fmask = feature_vocab.encode(tags, max_features=max_features)
            feat_ids.append(fids)
            feat_masks.append(fmask)
            lang_ids_list.append(lang_to_id.get(lang, 0))

        self.source = torch.tensor(source_ids, dtype=torch.long)
        self.target = torch.tensor(target_ids, dtype=torch.long)
        self.feature_ids = torch.tensor(feat_ids, dtype=torch.long)
        self.feature_mask = torch.tensor(feat_masks, dtype=torch.float)
        self.lang_ids = torch.tensor(lang_ids_list, dtype=torch.long)
        self.num_samples = num_samples

        if pin_memory and torch.cuda.is_available():
            self.source = self.source.pin_memory()
            self.target = self.target.pin_memory()
            self.feature_ids = self.feature_ids.pin_memory()
            self.feature_mask = self.feature_mask.pin_memory()
            self.lang_ids = self.lang_ids.pin_memory()

    def epoch_batches(
        self, batch_size: int, device: torch.device,
        prefetch_factor: int = 2,
    ) -> Generator[
        tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor],
        None, None,
    ]:
        """Yield shuffled batches. On CUDA, upcoming batches are prefetched on a secondary stream."""
        shuffled_indices = torch.randperm(self.num_samples)
        prefetch_stream = torch.cuda.Stream(device) if device.type == "cuda" else None
        starts = list(range(0, self.num_samples, batch_size))

        prefetch_factor = max(1, min(prefetch_factor, 4))
        prefetch_queue: list[tuple] = []

        if prefetch_stream is not None:
            for i in range(min(prefetch_factor, len(starts))):
                start = starts[i]
                batch_idx = shuffled_indices[start:start + batch_size]
                with torch.cuda.stream(prefetch_stream):
                    prefetch_queue.append(self._fetch_batch(batch_idx, device))

        for batch_num, start in enumerate(starts):
            if prefetch_stream is not None and prefetch_queue:
                torch.cuda.current_stream(device).wait_stream(prefetch_stream)
                current_batch = prefetch_queue.pop(0)

                next_batch_num = batch_num + prefetch_factor
                if next_batch_num < len(starts):
                    next_start = starts[next_batch_num]
                    next_idx = shuffled_indices[next_start:next_start + batch_size]
                    with torch.cuda.stream(prefetch_stream):
                        prefetch_queue.append(self._fetch_batch(next_idx, device))
            else:
                batch_idx = shuffled_indices[start:start + batch_size]
                current_batch = self._fetch_batch(batch_idx, device)

            yield current_batch

    def _fetch_batch(
        self, indices: torch.Tensor, device: torch.device,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        non_blocking = device.type == "cuda"
        return (
            self.source[indices].to(device, non_blocking=non_blocking),
            self.target[indices].to(device, non_blocking=non_blocking),
            self.lang_ids[indices].to(device, non_blocking=non_blocking),
            self.feature_ids[indices].to(device, non_blocking=non_blocking),
            self.feature_mask[indices].to(device, non_blocking=non_blocking),
        )

    def memory_bytes(self) -> int:
        total = 0
        for tensor in (self.source, self.target, self.feature_ids, self.feature_mask, self.lang_ids):
            total += tensor.numel() * tensor.element_size()
        return total
