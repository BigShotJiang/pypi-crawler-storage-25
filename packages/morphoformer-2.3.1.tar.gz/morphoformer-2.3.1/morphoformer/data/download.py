"""SigMorphon 2021 Task 0 dataset downloader and converter."""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path
from urllib.request import urlretrieve

SIGMORPHON_BASE = "https://raw.githubusercontent.com/sigmorphon/2021Task0/main"

DATASETS: dict[str, dict[str, str]] = {
    "rus": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/rus.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/rus.dev",
    },
    "deu": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/deu.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/deu.dev",
    },
    "spa": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/spa.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/spa.dev",
    },
    "bul": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/bul.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/bul.dev",
    },
    "ces": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/ces.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/ces.dev",
    },
    "nld": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/nld.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/nld.dev",
    },
    "pol": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/pol.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/pol.dev",
    },
    "por": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/por.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/por.dev",
    },
    "ara": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/ara.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/ara.dev",
    },
    "heb": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/heb.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/heb.dev",
    },
    "ind": {
        "train": f"{SIGMORPHON_BASE}/part1/development_languages/ind.train",
        "dev": f"{SIGMORPHON_BASE}/part1/development_languages/ind.dev",
    },
}


def _progress_hook(block_num: int, block_size: int, total_size: int) -> None:
    if total_size > 0:
        downloaded = block_num * block_size
        percent = min(100, downloaded * 100 // total_size)
        print(f"\r  {percent}%", end="", flush=True)


def download_file(url: str, dest: Path) -> None:
    print(f"  {url}", flush=True)
    urlretrieve(url, dest, reporthook=_progress_hook)
    print(flush=True)


def convert_sigmorphon_tsv(src: Path, dest: Path, lang: str) -> int:
    """Convert SigMorphon TSV (lemma\\tsurface\\tfeatures) to internal format
    (lemma\\tfeatures\\tsurface\\tlang) with MD5-based deduplication."""
    count = 0
    seen: set[str] = set()
    with open(src, encoding="utf-8") as fin, open(dest, "w", encoding="utf-8") as fout:
        fout.write(f"# {lang} morphological reinflection\n")
        fout.write("# lemma\\tfeatures\\tsurface\\tlang\n")
        for line in fin:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) < 3:
                continue
            lemma, surface, features = parts[0], parts[1], parts[2]
            row_hash = hashlib.md5(f"{lemma}\t{features}\t{surface}".encode()).hexdigest()
            if row_hash in seen:
                continue
            seen.add(row_hash)
            fout.write(f"{lemma}\t{features}\t{surface}\t{lang}\n")
            count += 1
    return count


def download_language(lang: str, out_dir: Path) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    raw_dir = out_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    result: dict[str, Path] = {}

    if lang in DATASETS:
        urls = DATASETS[lang]
    else:
        urls = {
            "train": f"{SIGMORPHON_BASE}/part1/development_languages/{lang}.train",
            "dev": f"{SIGMORPHON_BASE}/part1/development_languages/{lang}.dev",
        }

    for split, url in urls.items():
        raw_file = raw_dir / f"{lang}_{split}.raw"
        out_file = out_dir / f"{lang}_{split}.tsv"

        if out_file.exists():
            print(f"  {out_file} already exists, skipping", flush=True)
            result[split] = out_file
            continue

        try:
            download_file(url, raw_file)
            count = convert_sigmorphon_tsv(raw_file, out_file, lang)
            print(f"  {out_file}: {count} rows", flush=True)
            result[split] = out_file
        except Exception as e:
            print(f"  Error downloading {lang}.{split}: {e}", file=sys.stderr)

    return result


def get_available_languages() -> list[str]:
    """Fetch available language codes from the SigMorphon 2021 GitHub repository."""
    import urllib.request
    import json

    try:
        api_url = "https://api.github.com/repos/sigmorphon/2021Task0/contents/part1/development_languages"
        req = urllib.request.Request(api_url, headers={"User-Agent": "Mozilla/5.0"})
        response = urllib.request.urlopen(req)
        data = json.load(response)

        languages = set()
        for item in data:
            if item.get("type") == "file" and item.get("name", "").endswith(".train"):
                lang_code = item["name"].replace(".train", "")
                languages.add(lang_code)

        return sorted(languages)
    except Exception:
        return list(DATASETS.keys())


def download_all(languages: list[str], out_dir: Path) -> None:
    if "all" in languages:
        languages = get_available_languages()
        print(f"Downloading all available languages ({len(languages)})", flush=True)

    for lang in languages:
        print(f"[{lang}]", flush=True)
        download_language(lang, out_dir)


def merge_tsv(files: list[Path], dest: Path) -> int:
    count = 0
    with open(dest, "w", encoding="utf-8") as fout:
        fout.write("# Merged morphological reinflection dataset\n")
        fout.write("# lemma\\tfeatures\\tsurface\\tlang\n")
        for file_path in files:
            with open(file_path, encoding="utf-8") as fin:
                for line in fin:
                    if line.startswith("#") or not line.strip():
                        continue
                    fout.write(line)
                    count += 1
    return count
