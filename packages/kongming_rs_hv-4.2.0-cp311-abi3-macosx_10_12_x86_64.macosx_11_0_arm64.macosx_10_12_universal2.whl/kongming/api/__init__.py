# kongming.api — proto-derived enum types.
#
# These IntEnums correspond to messages declared in `kongming/api/v1/hv.proto`
# (Model, Prewired, HyperBinaryProto.Hint, DomainPrefix). They are built at
# import time from the bare-int constants the Rust extension exposes on
# `kongming_rs.hv` and given a `.label` property when the proto carries
# `(kongming.api.label)` annotations on their values.
#
# Example:
#
#     from kongming import api
#     api.Prewired.TRUE.label       # '✅'
#     api.DomainPrefix.NLP.label    # '💬'
#     api.Hint.SPARKLE.label        # '✨'
#     api.Model.MODEL_64K_8BIT.label  # None — Model has no (label) annotations

from enum import IntEnum

from kongming_rs import hv as _hv
from kongming_rs import proto_label as _proto_label


def _make_labeled_enum(prefix: str, name: str, fqn: str | None) -> type[IntEnum]:
    """Build an IntEnum from `_hv.<prefix>*` constants, optionally
    attaching a `.label` property driven by the proto descriptor at `fqn`.
    """
    # Strip the prefix on member names so users get `Prewired.TRUE`
    # rather than `Prewired.PREWIRED_TRUE`. The original prefixed name
    # is preserved on `hv` (rebound by kongming/__init__.py).
    # Exception: when the stripped name would start with a digit and
    # therefore not be a valid Python identifier (e.g., `MODEL_64K_8BIT`
    # → `64K_8BIT`), keep the prefix.
    raw = {
        member_name: getattr(_hv, member_name)
        for member_name in dir(_hv)
        if member_name.startswith(prefix)
        and isinstance(getattr(_hv, member_name), int)
        and not isinstance(getattr(_hv, member_name), bool)
    }
    strip_ok = all(
        len(n) > len(prefix) and n[len(prefix)].isalpha() or n[len(prefix)] == "_"
        for n in raw
    )
    if strip_ok:
        members = {n[len(prefix):]: v for n, v in raw.items()}
    else:
        members = raw
    if not members:
        raise RuntimeError(f"no constants with prefix {prefix!r} on hv")

    cls = IntEnum(name, members)
    cls.__module__ = "kongming.api"
    # Map original `hv.<NAME>` constant -> member, so the back-compat
    # shim in kongming/__init__.py can rebind those attributes onto
    # `hv` without re-deriving the prefix logic.
    cls._hv_aliases = {  # type: ignore[attr-defined]
        original: cls(value) for original, value in raw.items()
    }

    labels: dict[int, str] = {}
    if fqn is not None:
        for member in cls:
            result = _proto_label.enum_label(fqn, int(member))
            if result is not None:
                _, label = result
                labels[int(member)] = label
    # Always attach `.label` (returns None when no annotation exists, or
    # when the enum's proto definition has no (label) annotations at all).
    cls._label_map = labels  # type: ignore[attr-defined]
    cls.label = property(lambda self: type(self)._label_map.get(int(self)))  # type: ignore[attr-defined]

    return cls


Model = _make_labeled_enum("MODEL_", "Model", None)
Prewired = _make_labeled_enum(
    "PREWIRED_", "Prewired", "kongming.api.v1.Prewired.E"
)
Hint = _make_labeled_enum(
    "HINT_", "Hint", "kongming.api.v1.HyperBinaryProto.Hint"
)
DomainPrefix = _make_labeled_enum(
    "DOMAIN_PREFIX_", "DomainPrefix", "kongming.api.v1.DomainPrefix.E"
)

__all__ = ["Model", "Prewired", "Hint", "DomainPrefix"]
