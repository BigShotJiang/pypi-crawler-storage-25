# kongming — top-level import path for kongming-rs-hv
#
# The native extension lives in kongming_rs (PyO3). This package
# re-exports everything so users can write:
#   from kongming import hv
#   from kongming import memory
#   from kongming import api

from kongming_rs import (  # noqa: F401
    REASON_NOT_FOUND,
    HvError,
    __version__,
    hv,
)

try:
    from kongming_rs import memory  # noqa: F401
except ImportError:
    pass  # memory module may not be available in minimal builds

try:
    from kongming_rs import lisp  # noqa: F401
except ImportError:
    pass

# `from kongming.proto_label import enum_labels` requires this to be
# registered as a true submodule in sys.modules — pyo3 only registers it
# under `kongming_rs.proto_label`, so alias it here.
import sys as _sys  # noqa: E402

from kongming_rs import proto_label  # noqa: F401, E402

_sys.modules["kongming.proto_label"] = proto_label
del _sys

# IntEnum classes (Model, Prewired, Hint, DomainPrefix) live in
# `kongming.api` since they're proto types declared in
# `kongming/api/v1/hv.proto`. Re-bind them onto `hv` for backward
# compatibility, and rebind every prefixed bare-int constant
# (e.g. `hv.PREWIRED_TRUE`, `hv.MODEL_64K_8BIT`) to the matching
# IntEnum member so the existing `hv.PREWIRED_*` surface keeps working
# and now also carries `.label` where applicable.
from kongming import api as _api  # noqa: E402

for _cls in (_api.Model, _api.Prewired, _api.Hint, _api.DomainPrefix):
    setattr(hv, _cls.__name__, _cls)
    # Rebind each `hv.<ORIGINAL_NAME>` constant to its IntEnum member so
    # existing code keeps working and now picks up `.label` automatically.
    for _orig_name, _member in _cls._hv_aliases.items():
        setattr(hv, _orig_name, _member)

del _api, _cls, _orig_name, _member
