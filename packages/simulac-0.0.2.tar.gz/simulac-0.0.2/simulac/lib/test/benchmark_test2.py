from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from urllib.parse import quote

import msgpack
import pytest
import requests
import zstd

import simulac.lib.gym_style as gym_style
import simulac.lib.gym_style.gym_style_environment as gym_style_environment
from simulac.base.error.error import SimulacBaseError
from simulac.lib.gym_style import get_env_list, init_bench
from simulac.lib.gym_style.gym_style_environment import BenchmarkEnvironment

os.environ.setdefault("SIMULAC_BASE_URL", "http://localhost:3000/api")

_WORKSPACE_DIR = Path(__file__).resolve().parents[4]
_FRONTEND_SCHEMA_PATH = (
    _WORKSPACE_DIR
    / "tektonian"
    / "apps"
    / "frontend"
    / "app"
    / "data-benchmark"
    / "benchmark-data.ts"
)
_BACKEND_ROUTE_PATH = (
    _WORKSPACE_DIR
    / "tektonian"
    / "apps"
    / "backend"
    / "src"
    / "routes"
    / "container"
    / "index.ts"
)
_MISSING = object()


@dataclass(frozen=True)
class _SchemaField:
    key: str
    dtype: str
    shape: tuple[int, ...] | None = None


@dataclass(frozen=True)
class _BenchmarkSpec:
    benchmark_id: str
    action: tuple[float, ...]
    benchmark_specific: dict[str, Any]


@dataclass
class _SocketState:
    name: str


class _FakeSocket:
    def __init__(self, responses: list[dict[str, Any]]) -> None:
        self._responses = [
            zstd.compress(msgpack.packb(response, use_bin_type=True))
            for response in responses
        ]
        self.sent_messages: list[str] = []
        self.state = _SocketState("OPEN")
        self.close_code: int | None = None

    def send(self, payload: str) -> None:
        self.sent_messages.append(payload)

    def recv(self, decode: bool = False) -> bytes:
        assert decode is False
        assert self._responses, "Expected queued backend response."
        return self._responses.pop(0)

    def close(self, *args: Any, **kwargs: Any) -> None:
        self.state = _SocketState("CLOSED")
        self.close_code = 1000


_BENCHMARK_SPECS = (
    _BenchmarkSpec(
        benchmark_id="Tektonian/Libero",
        action=(0.0,) * 7,
        benchmark_specific={"control_mode": "OSC_POSE"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Calvin",
        action=(0.0,) * 7,
        benchmark_specific={"control_mode": "cartesian_relative"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Metaworld",
        action=(0.0,) * 4,
        benchmark_specific={},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Robomimic",
        action=(0.0,) * 7,
        benchmark_specific={"control_mode": "OSC_POSE"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/BiGym",
        action=(0.0,) * 15,
        benchmark_specific={},
    ),
)


class _MockResponse:
    def __init__(
        self,
        payload: Any,
        *,
        status_code: int = 200,
        text: str = "",
        raised_error: Exception | None = None,
    ) -> None:
        self._payload = payload
        self.status_code = status_code
        self.text = text
        self._raised_error = raised_error

    def raise_for_status(self) -> None:
        if self._raised_error is not None:
            raise self._raised_error

    def json(self) -> Any:
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


def _runtime_for_test(
    *,
    base_url: str = "https://example.com/api",
    token: str | None = "tt_sim_test_token",
) -> SimpleNamespace:
    logger = SimpleNamespace(
        warn=lambda *args, **kwargs: None,
        error=lambda *args, **kwargs: None,
        debug=lambda *args, **kwargs: None,
    )
    return SimpleNamespace(
        environment_variable=SimpleNamespace(base_url=base_url, token=token),
        logger=logger,
        telemetry=SimpleNamespace(public_error=lambda *args, **kwargs: None),
        _log_service=SimpleNamespace(error=lambda *args, **kwargs: None),
    )


def _get_env_list(benchmark_id: str, env_group: str | None = None) -> list[str]:
    if env_group is None:
        env_list = get_env_list(benchmark_id)
    else:
        runtime = gym_style.obtain_runtime()
        if "/" not in benchmark_id:
            raise SimulacBaseError(
                "Benchmark id format should be owner_id/env_id (e.g., Tektonian/Libero)"
            )

        owner_id, env_id = benchmark_id.split("/", maxsplit=1)
        url = "/".join(
            [
                runtime.environment_variable.base_url.rstrip("/"),
                "container",
                "scene-list",
                quote(owner_id, safe=""),
                quote(env_id, safe=""),
            ]
        )
        response = gym_style.requests.get(
            url,
            params={"env_group": env_group},
            timeout=10,
        )
        response.raise_for_status()
        env_list = response.json()

    if not isinstance(env_list, list) or not all(
        isinstance(env_name, str) for env_name in env_list
    ):
        raise SimulacBaseError(
            "Scene list response should be a list of environment ids."
        )

    return env_list


def _find_matching_token(
    source: str,
    start_index: int,
    open_token: str,
    close_token: str,
) -> int:
    depth = 0
    for index in range(start_index, len(source)):
        token = source[index]
        if token == open_token:
            depth += 1
        elif token == close_token:
            depth -= 1
            if depth == 0:
                return index

    raise ValueError(
        f"Unable to find closing token {close_token!r} for offset {start_index}."
    )


def _extract_braced_blocks(source: str) -> list[str]:
    blocks: list[str] = []
    start_index: int | None = None
    depth = 0

    for index, token in enumerate(source):
        if token == "{":
            if depth == 0:
                start_index = index
            depth += 1
        elif token == "}":
            if depth == 0:
                continue
            depth -= 1
            if depth == 0 and start_index is not None:
                blocks.append(source[start_index : index + 1])
                start_index = None

    return blocks


def _extract_named_block(
    source: str,
    field_name: str,
    *,
    open_token: str,
    close_token: str,
) -> str:
    field_offset = source.index(f"{field_name}:")
    block_start = source.index(open_token, field_offset)
    block_end = _find_matching_token(source, block_start, open_token, close_token)
    return source[block_start : block_end + 1]


def _parse_shape(shape_literal: str) -> tuple[int, ...]:
    dims: list[int] = []
    for token in shape_literal.split(","):
        clean_token = token.strip().strip("'").strip('"')
        if clean_token:
            dims.append(int(clean_token))
    return tuple(dims)


def _parse_schema_fields(source: str) -> tuple[_SchemaField, ...]:
    # The frontend file keeps alternative schema rows in `//` comments.
    uncommented_source = re.sub(r"(?m)^\s*//.*$", "", source)
    fields: list[_SchemaField] = []
    for block in _extract_braced_blocks(uncommented_source):
        key_match = re.search(r"key:\s*'([^']+)'", block)
        dtype_match = re.search(r"dtype:\s*'([^']+)'", block)
        if key_match is None or dtype_match is None:
            continue

        shape_match = re.search(r"shape:\s*\[([^\]]+)\]", block)
        fields.append(
            _SchemaField(
                key=key_match.group(1),
                dtype=dtype_match.group(1),
                shape=_parse_shape(shape_match.group(1)) if shape_match else None,
            )
        )

    return tuple(fields)


@lru_cache(maxsize=None)
def _load_frontend_schema_fields(
    benchmark_id: str,
) -> tuple[tuple[_SchemaField, ...], tuple[_SchemaField, ...]]:
    if not _FRONTEND_SCHEMA_PATH.exists():
        pytest.skip(f"Missing frontend schema file: {_FRONTEND_SCHEMA_PATH}")

    source = _FRONTEND_SCHEMA_PATH.read_text(encoding="utf-8")
    schema_anchor = "const sampleBenchmarkSchemas"
    schema_start = source.index(schema_anchor)
    benchmark_anchor = f"'{benchmark_id}': {{"
    benchmark_start = source.index(benchmark_anchor, schema_start)
    block_start = source.index("{", benchmark_start)
    block_end = _find_matching_token(source, block_start, "{", "}")
    benchmark_block = source[block_start : block_end + 1]

    observation_block = _extract_named_block(
        benchmark_block,
        "observationSchema",
        open_token="[",
        close_token="]",
    )
    info_block = _extract_named_block(
        benchmark_block,
        "infoSchema",
        open_token="[",
        close_token="]",
    )

    return (
        _parse_schema_fields(observation_block),
        _parse_schema_fields(info_block),
    )


@lru_cache(maxsize=1)
def _load_demo_api_key() -> str | None:
    if not _BACKEND_ROUTE_PATH.exists():
        return None

    source = _BACKEND_ROUTE_PATH.read_text(encoding="utf-8")
    match = re.search(r"const DEMO_API_KEY = '([^']+)';", source)
    if match is None:
        return None
    return match.group(1)


def _lookup_path(payload: dict[str, Any], dotted_key: str) -> Any:
    current: Any = payload
    for token in dotted_key.split("."):
        if not isinstance(current, dict) or token not in current:
            return _MISSING
        current = current[token]
    return current


def _assert_scalar_dtype(value: Any, dtype: str, key: str) -> None:
    if dtype == "dict":
        assert isinstance(value, dict), (
            f"{key} should be dict, got {type(value).__name__}"
        )
        return

    if dtype == "boolean":
        assert isinstance(value, bool), (
            f"{key} should be boolean, got {type(value).__name__}"
        )
        return

    if dtype == "string":
        assert isinstance(value, str), (
            f"{key} should be string, got {type(value).__name__}"
        )
        return

    if dtype in {"float32", "float64"}:
        assert isinstance(value, (int, float)) and not isinstance(value, bool), (
            f"{key} should be numeric, got {type(value).__name__}"
        )
        return

    if dtype in {"int32", "int64"}:
        assert isinstance(value, int) and not isinstance(value, bool), (
            f"{key} should be integer, got {type(value).__name__}"
        )
        return

    if dtype == "uint8":
        assert isinstance(value, int) and not isinstance(value, bool), (
            f"{key} should be uint8, got {type(value).__name__}"
        )
        assert 0 <= value <= 255, f"{key} should be between 0 and 255, got {value!r}"
        return

    raise AssertionError(f"Unsupported dtype {dtype!r} for {key}.")


def _assert_array_shape_and_dtype(
    value: Any,
    shape: tuple[int, ...],
    dtype: str,
    key: str,
) -> None:
    assert isinstance(value, (list, tuple)), (
        f"{key} should be list-like for shape {shape}, got {type(value).__name__}"
    )
    assert len(value) == shape[0], (
        f"{key} expected shape {shape}, got leading dimension {len(value)}"
    )

    if len(shape) == 1:
        for item in value:
            _assert_scalar_dtype(item, dtype, key)
        return

    for item in value:
        _assert_array_shape_and_dtype(item, shape[1:], dtype, key)


def _assert_field_matches(value: Any, field: _SchemaField) -> None:
    if field.shape is not None:
        _assert_array_shape_and_dtype(value, field.shape, field.dtype, field.key)
        return

    if field.dtype.endswith("[]"):
        base_dtype = field.dtype[:-2]
        assert isinstance(value, list), (
            f"{field.key} should be list for dtype {field.dtype}, got {type(value).__name__}"
        )
        for item in value:
            _assert_scalar_dtype(item, base_dtype, field.key)
        return

    _assert_scalar_dtype(value, field.dtype, field.key)


def _assert_observation_matches_frontend_schema(
    benchmark_id: str,
    observation: dict[str, Any],
) -> None:
    observation_fields, _ = _load_frontend_schema_fields(benchmark_id)
    for field in observation_fields:
        value = _lookup_path(observation, field.key)
        assert value is not _MISSING, f"Missing observation key {field.key!r}"
        _assert_field_matches(value, field)


def _assert_info_matches_frontend_schema(
    benchmark_id: str,
    info: dict[str, Any],
) -> None:
    _, info_fields = _load_frontend_schema_fields(benchmark_id)
    for field in info_fields:
        value = _lookup_path(info, field.key)
        assert value is not _MISSING, f"Missing info key {field.key!r}"
        _assert_field_matches(value, field)


def _assert_info_union_matches_frontend_schema(
    benchmark_id: str,
    *infos: dict[str, Any],
) -> None:
    _, info_fields = _load_frontend_schema_fields(benchmark_id)
    for field in info_fields:
        value = _MISSING
        for info in infos:
            candidate = _lookup_path(info, field.key)
            if candidate is not _MISSING:
                value = candidate
                break

        assert value is not _MISSING, f"Missing info key {field.key!r}"
        _assert_field_matches(value, field)


def _assert_reset_schema(benchmark_id: str, result: Any) -> None:
    assert isinstance(result, tuple), "reset() should return a tuple"
    assert len(result) == 2, f"reset() should return 2 values, got {len(result)}"
    observation, info = result
    assert isinstance(observation, dict), "reset() observation should be dict"
    assert isinstance(info, dict), "reset() info should be dict"
    _assert_observation_matches_frontend_schema(benchmark_id, observation)


def _assert_step_schema(benchmark_id: str, result: Any) -> None:
    assert isinstance(result, tuple), "step() should return a tuple"
    assert len(result) == 4, f"step() should return 4 values, got {len(result)}"
    observation, reward, done, info = result
    assert isinstance(observation, dict), "step() observation should be dict"
    assert isinstance(reward, (int, float)) and not isinstance(reward, bool), (
        "step() reward should be numeric"
    )
    assert isinstance(done, bool), "step() done should be bool"
    assert isinstance(info, dict), "step() info should be dict"
    _assert_observation_matches_frontend_schema(benchmark_id, observation)


def _build_env(spec: _BenchmarkSpec, env_id: str) -> BenchmarkEnvironment:
    return init_bench(
        spec.benchmark_id,
        env_id,
        0,
        dict(spec.benchmark_specific),
    )


def _integration_prerequisites_ready() -> None:
    if not _BACKEND_ROUTE_PATH.exists():
        pytest.skip(f"Missing backend route file: {_BACKEND_ROUTE_PATH}")

    runtime = gym_style.obtain_runtime()
    if runtime.environment_variable.token is None:
        pytest.skip(
            "SIMULAC_API_KEY or cached token is required for integration tests."
        )


def _benchmark_is_supported_for_current_token(benchmark_id: str) -> bool:
    runtime = gym_style.obtain_runtime()
    token = runtime.environment_variable.token
    demo_key = _load_demo_api_key()

    if token is None or demo_key is None or token != demo_key:
        return True

    return benchmark_id.strip().lower() == "tektonian/metaworld"


def _env_ids_for_test(benchmark_id: str) -> list[str]:
    _integration_prerequisites_ready()

    env_ids = _get_env_list(benchmark_id)
    assert env_ids, f"Expected at least one env for {benchmark_id}"

    limit_literal = os.environ.get("SIMULAC_BENCHMARK_TEST_LIMIT")
    if limit_literal is None:
        return env_ids

    limit = int(limit_literal)
    return env_ids[:limit]


def _assert_two_envs_match(spec: _BenchmarkSpec, env_id: str) -> None:
    env_a = _build_env(spec, env_id)
    env_b = _build_env(spec, env_id)

    try:
        for cycle_index in range(2):
            reset_a = env_a.reset(0)
            reset_b = env_b.reset(0)
            assert reset_a == reset_b, (
                f"{spec.benchmark_id}/{env_id} reset mismatch on cycle {cycle_index}"
            )

            step_a = env_a.step(list(spec.action))
            step_b = env_b.step(list(spec.action))
            assert step_a == step_b, (
                f"{spec.benchmark_id}/{env_id} step mismatch on cycle {cycle_index}"
            )
    finally:
        env_a.close()
        env_b.close()


def _assert_single_env_cycle_and_close(spec: _BenchmarkSpec, env_id: str) -> None:
    env = _build_env(spec, env_id)
    socket = None

    try:
        first_reset = env.reset(0)
        _assert_reset_schema(spec.benchmark_id, first_reset)

        first_step = env.step(list(spec.action))
        _assert_step_schema(spec.benchmark_id, first_step)
        _assert_info_union_matches_frontend_schema(
            spec.benchmark_id,
            first_reset[1],
            first_step[3],
        )

        second_reset = env.reset(0)
        second_step = env.step(list(spec.action))

        assert first_reset == second_reset, (
            f"{spec.benchmark_id}/{env_id} reset->step->reset should be deterministic"
        )
        assert first_step == second_step, (
            f"{spec.benchmark_id}/{env_id} repeated step result should match"
        )

        socket = env._ensure_connected()
        assert getattr(socket.state, "name", str(socket.state)) == "OPEN"
    finally:
        env.close()

    assert env._socket is None
    if socket is not None:
        assert getattr(socket.state, "name", str(socket.state)) == "CLOSED"
        assert socket.close_code is not None


def _fake_connected_env(
    monkeypatch: pytest.MonkeyPatch,
    *,
    responses: list[dict[str, Any]],
    benchmark_id: str = "Tektonian/Libero",
    env_id: str = "env-a",
    benchmark_specific: dict[str, Any] | None = None,
) -> tuple[BenchmarkEnvironment, _FakeSocket]:
    socket = _FakeSocket(responses)

    monkeypatch.setattr(gym_style_environment, "obtain_runtime", _runtime_for_test)
    monkeypatch.setattr(gym_style_environment, "connect", lambda *args, **kwargs: socket)
    monkeypatch.setattr(
        BenchmarkEnvironment,
        "_create_ticket",
        lambda self: setattr(self, "_ticket", "test-ticket"),
    )

    env = BenchmarkEnvironment(
        "id",
        benchmark_id,
        env_id,
        0,
        benchmark_specific or {},
    )
    return env, socket


def test_get_env_list_omits_empty_env_group(monkeypatch: pytest.MonkeyPatch) -> None:
    requested: dict[str, object] = {}

    def fake_get(
        url: str,
        *,
        params: dict[str, str] | None = None,
        timeout: int,
    ) -> _MockResponse:
        requested["url"] = url
        requested["params"] = params
        requested["timeout"] = timeout
        return _MockResponse(["env-a"])

    monkeypatch.setattr(
        gym_style,
        "obtain_runtime",
        lambda: _runtime_for_test(base_url="https://example.com/api"),
    )
    monkeypatch.setattr(gym_style.requests, "get", fake_get)

    assert _get_env_list("Tektonian/Libero") == ["env-a"]
    assert requested == {
        "url": "https://example.com/api/container/scene-list/Tektonian/Libero",
        "params": None,
        "timeout": 10,
    }


def test_get_env_list_passes_env_group_as_query_param(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    requested: dict[str, object] = {}

    def fake_get(
        url: str,
        *,
        params: dict[str, str] | None = None,
        timeout: int,
    ) -> _MockResponse:
        requested["url"] = url
        requested["params"] = params
        requested["timeout"] = timeout
        return _MockResponse(["env-a"])

    monkeypatch.setattr(gym_style, "obtain_runtime", _runtime_for_test)
    monkeypatch.setattr(gym_style.requests, "get", fake_get)

    assert _get_env_list("Tektonian/Libero", "libero_goal") == ["env-a"]
    assert requested == {
        "url": "https://example.com/api/container/scene-list/Tektonian/Libero",
        "params": {"env_group": "libero_goal"},
        "timeout": 10,
    }


def test_get_env_list_rejects_non_list_or_non_string_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(gym_style, "obtain_runtime", _runtime_for_test)

    monkeypatch.setattr(
        gym_style.requests, "get", lambda *args, **kwargs: _MockResponse({})
    )
    with pytest.raises(SimulacBaseError):
        _get_env_list("Tektonian/Libero", "libero_goal")

    monkeypatch.setattr(
        gym_style.requests, "get", lambda *args, **kwargs: _MockResponse(["env-a", 1])
    )
    with pytest.raises(SimulacBaseError):
        _get_env_list("Tektonian/Libero", "libero_goal")


def test_get_env_list_raises_when_backend_returns_http_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    http_error = requests.HTTPError("backend error")
    monkeypatch.setattr(gym_style, "obtain_runtime", _runtime_for_test)
    monkeypatch.setattr(
        gym_style.requests,
        "get",
        lambda *args, **kwargs: _MockResponse([], raised_error=http_error),
    )

    with pytest.raises(requests.HTTPError):
        _get_env_list("Tektonian/Libero", "libero_goal")


def test_get_env_list_requires_benchmark_owner_and_name() -> None:
    with pytest.raises(SimulacBaseError):
        _get_env_list("Libero", "libero_goal")


def test_preflight_raises_without_matching_backend_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        gym_style_environment,
        "obtain_runtime",
        lambda: _runtime_for_test(),
    )
    monkeypatch.setattr(
        gym_style_environment.requests,
        "post",
        lambda *args, **kwargs: _MockResponse(
            {"message": {"status": "message text may change"}},
            status_code=403,
        ),
    )

    env = BenchmarkEnvironment("id", "Tektonian/Libero", "env-a", 0, {})
    with pytest.raises(SimulacBaseError):
        env._create_ticket()


def test_preflight_raises_for_non_json_error_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        gym_style_environment,
        "obtain_runtime",
        lambda: _runtime_for_test(),
    )
    monkeypatch.setattr(
        gym_style_environment.requests,
        "post",
        lambda *args, **kwargs: _MockResponse(
            ValueError("not json"),
            status_code=429,
            text="plain text response",
        ),
    )

    env = BenchmarkEnvironment("id", "Tektonian/Libero", "env-a", 0, {})
    with pytest.raises(SimulacBaseError):
        env._create_ticket()


def test_ensure_connected_sends_build_env_and_consumes_backend_ack(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    env, socket = _fake_connected_env(
        monkeypatch,
        responses=[{"message": {"phase": "ready"}}],
        benchmark_specific={"control_mode": "OSC_POSE"},
    )

    connected_socket = env._ensure_connected()

    assert connected_socket is socket
    assert socket.state.name == "OPEN"
    assert len(socket.sent_messages) == 1
    assert json.loads(socket.sent_messages[0]) == {
        "command": "build_env",
        "args": {
            "env_id": "env-a",
            "seed": 0,
            "control_mode": "OSC_POSE",
        },
    }


def test_reset_returns_backend_payload_without_comparing_message_text(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    env, socket = _fake_connected_env(
        monkeypatch,
        responses=[
            {"message": {"phase": "ready"}},
            {"obs": {"frame": 1}, "info": {"message": {"status": "ok"}}},
        ],
    )

    result = env.reset(123)

    assert result == ({"frame": 1}, {"message": {"status": "ok"}})
    assert json.loads(socket.sent_messages[1]) == {
        "command": "reset",
        "args": {"seed": 123},
    }


def test_step_returns_backend_payload_without_comparing_message_text(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    env, socket = _fake_connected_env(
        monkeypatch,
        responses=[
            {"message": {"phase": "ready"}},
            {
                "obs": {"frame": 2},
                "reward": 1.25,
                "done": False,
                "info": {"message": {"status": "ok"}},
            },
        ],
    )

    result = env.step([0.0] * 7)

    assert result == (
        {"frame": 2},
        1.25,
        False,
        {"message": {"status": "ok"}},
    )
    assert json.loads(socket.sent_messages[1]) == {
        "command": "step",
        "args": {"action": [0.0] * 7},
    }


def test_close_sends_close_command_and_closes_socket(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    env, socket = _fake_connected_env(
        monkeypatch,
        responses=[{"message": {"phase": "ready"}}],
    )
    env._ensure_connected()

    env.close()

    assert json.loads(socket.sent_messages[-1]) == {
        "command": "close",
        "args": {},
    }
    assert socket.state.name == "CLOSED"
    assert socket.close_code == 1000
    assert env._socket is None


def test_load_frontend_schema_fields_reads_sample_benchmark_schemas() -> None:
    observation_fields, info_fields = _load_frontend_schema_fields("Tektonian/Libero")

    assert any(field.key == "states.robot_0_joint_pos" for field in observation_fields)
    assert any(field.key == "task_description" for field in info_fields)


def test_load_frontend_schema_fields_ignores_commented_rows() -> None:
    observation_fields, _ = _load_frontend_schema_fields("Tektonian/Calvin")

    assert not any(field.key == "language_instruction" for field in observation_fields)


def test_info_union_schema_allows_reset_step_differences() -> None:
    reset_info = {
        "task_description": "Assembly",
        "obs_meta": {"cam_map": {}, "object_map": {}},
    }
    step_info = {
        "success": 0.0,
        "near_object": 0.0,
        "grasp_success": False,
        "grasp_reward": 0.0,
        "in_place_reward": 0.0,
        "obj_to_target": 0.0,
        "unscaled_reward": 0.0,
        "terminated": False,
        "truncated": False,
    }

    _assert_info_union_matches_frontend_schema(
        "Tektonian/Metaworld",
        reset_info,
        step_info,
    )


@pytest.mark.integration
def test_scene_list_includes_group_filtering() -> None:
    _integration_prerequisites_ready()

    libero_env_list = _get_env_list("Tektonian/Libero")
    assert libero_env_list

    libero_goal_env_list = _get_env_list("Tektonian/Libero", "libero_goal")
    assert libero_goal_env_list
    assert set(libero_goal_env_list).issubset(set(libero_env_list))
    assert all(env_id.startswith("libero_goal/") for env_id in libero_goal_env_list)


@pytest.mark.integration
@pytest.mark.parametrize(
    "spec",
    _BENCHMARK_SPECS,
    ids=lambda spec: spec.benchmark_id,
)
def test_benchmark_contracts(spec: _BenchmarkSpec) -> None:
    if not _benchmark_is_supported_for_current_token(spec.benchmark_id):
        pytest.skip(f"{spec.benchmark_id} is unavailable for the configured demo key.")

    failures: list[str] = []

    for env_id in _env_ids_for_test(spec.benchmark_id):
        try:
            _assert_two_envs_match(spec, env_id)
            _assert_single_env_cycle_and_close(spec, env_id)
        except Exception as exc:
            failures.append(f"{env_id}: {exc!r}")

    assert not failures, "Failed benchmark contracts:\n" + "\n".join(failures)
