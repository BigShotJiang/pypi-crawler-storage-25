from __future__ import annotations

import math
import os
import re
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
import requests
from websockets.exceptions import ConnectionClosedError

import simulac.lib.gym_style as gym_style
import simulac.lib.gym_style.gym_style_environment as gym_style_environment
from simulac.base.error.error import SimulacBaseError
from simulac.lib.gym_style import get_env_list, init_bench
from simulac.lib.gym_style.gym_style_environment import BenchmarkEnvironment

_WORKSPACE_DIR = Path(__file__).resolve().parents[4]
_FRONTEND_SCHEMA_PATH = (
    _WORKSPACE_DIR
    / "tektonian"
    / "apps"
    / "frontend"
    / "app"
    / "data-benchmark"
    / "benchmark-data.ts"
)
_BACKEND_ROUTE_PATH = (
    _WORKSPACE_DIR
    / "tektonian"
    / "apps"
    / "backend"
    / "src"
    / "routes"
    / "container"
    / "index.ts"
)
_LOCAL_SIMULAC_BASE_URL = "http://localhost:3000/api"
_MISSING = object()
_NUMERIC_EQ_REL_TOL = 1e-6
_NUMERIC_EQ_ABS_TOL = 5e-3


@dataclass(frozen=True)
class _SchemaField:
    key: str
    dtype: str
    shape: tuple[int, ...] | None = None


@dataclass(frozen=True)
class _BenchmarkSpec:
    benchmark_id: str
    case_id: str
    action: tuple[float, ...]
    benchmark_specific: dict[str, Any]
    frontend_selection: dict[str, Any]


_BENCHMARK_SPECS = (
    _BenchmarkSpec(
        benchmark_id="Tektonian/Libero",
        case_id="Tektonian/Libero[control_mode=OSC_POSE]",
        action=(0.0,) * 7,
        benchmark_specific={"control_mode": "OSC_POSE"},
        frontend_selection={"control_mode": "OSC_POSE"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Libero",
        case_id="Tektonian/Libero[control_mode=JOINT_POSITION]",
        action=(0.0,) * 8,
        benchmark_specific={"control_mode": "JOINT_POSITION"},
        frontend_selection={"control_mode": "JOINT_POSITION"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Calvin",
        case_id="Tektonian/Calvin[control_mode=cartesian_relative]",
        action=(0.0,) * 7,
        benchmark_specific={"control_mode": "cartesian_relative"},
        frontend_selection={"control_mode": "cartesian_relative"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Calvin",
        case_id="Tektonian/Calvin[control_mode=cartesian_absolute]",
        action=(0.0,) * 7,
        benchmark_specific={"control_mode": "cartesian_absolute"},
        frontend_selection={"control_mode": "cartesian_absolute"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Metaworld",
        case_id="Tektonian/Metaworld[default]",
        action=(0.0,) * 4,
        benchmark_specific={},
        frontend_selection={},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Robomimic",
        case_id="Tektonian/Robomimic[control_mode=OSC_POSE]",
        action=(0.0,) * 7,
        benchmark_specific={"control_mode": "OSC_POSE"},
        frontend_selection={"control_mode": "OSC_POSE"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/Robomimic",
        case_id="Tektonian/Robomimic[control_mode=JOINT_POSITION]",
        action=(0.0,) * 8,
        benchmark_specific={"control_mode": "JOINT_POSITION"},
        frontend_selection={"control_mode": "JOINT_POSITION"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/BiGym",
        case_id="Tektonian/BiGym[floating_base=True,absolute=True]",
        action=(0.0,) * 15,
        benchmark_specific={
            "control_mode": "JointPositionActionMode",
            "floating_base": True,
            "absolute": True,
        },
        frontend_selection={"floating_base": "True", "absolute": "True"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/BiGym",
        case_id="Tektonian/BiGym[floating_base=False,absolute=True]",
        action=(0.0,) * 23,
        benchmark_specific={
            "control_mode": "JointPositionActionMode",
            "floating_base": False,
            "absolute": True,
        },
        frontend_selection={"floating_base": "False", "absolute": "True"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/BiGym",
        case_id="Tektonian/BiGym[floating_base=True,absolute=False]",
        action=(0.0,) * 15,
        benchmark_specific={
            "control_mode": "JointPositionActionMode",
            "floating_base": True,
            "absolute": False,
        },
        frontend_selection={"floating_base": "True", "absolute": "False"},
    ),
    _BenchmarkSpec(
        benchmark_id="Tektonian/BiGym",
        case_id="Tektonian/BiGym[floating_base=False,absolute=False]",
        action=(0.0,) * 23,
        benchmark_specific={
            "control_mode": "JointPositionActionMode",
            "floating_base": False,
            "absolute": False,
        },
        frontend_selection={"floating_base": "False", "absolute": "False"},
    ),
)


class _MockResponse:
    def __init__(
        self,
        payload: Any,
        *,
        status_code: int = 200,
        text: str = "",
        raised_error: Exception | None = None,
    ) -> None:
        self._payload = payload
        self.status_code = status_code
        self.text = text
        self._raised_error = raised_error

    def raise_for_status(self) -> None:
        if self._raised_error is not None:
            raise self._raised_error

    def json(self) -> Any:
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


def _runtime_for_test(
    *,
    base_url: str = "https://example.com/api",
    token: str | None = "tt_sim_test_token",
) -> SimpleNamespace:
    logger = SimpleNamespace(
        warn=lambda *args, **kwargs: None,
        error=lambda *args, **kwargs: None,
        debug=lambda *args, **kwargs: None,
    )
    return SimpleNamespace(
        environment_variable=SimpleNamespace(base_url=base_url, token=token),
        logger=logger,
        telemetry=SimpleNamespace(public_error=lambda *args, **kwargs: None),
        _log_service=SimpleNamespace(error=lambda *args, **kwargs: None),
    )


def _find_matching_token(
    source: str,
    start_index: int,
    open_token: str,
    close_token: str,
) -> int:
    depth = 0
    for index in range(start_index, len(source)):
        token = source[index]
        if token == open_token:
            depth += 1
        elif token == close_token:
            depth -= 1
            if depth == 0:
                return index

    raise ValueError(
        f"Unable to find closing token {close_token!r} for offset {start_index}."
    )


def _extract_braced_blocks(source: str) -> list[str]:
    blocks: list[str] = []
    start_index: int | None = None
    depth = 0

    for index, token in enumerate(source):
        if token == "{":
            if depth == 0:
                start_index = index
            depth += 1
        elif token == "}":
            if depth == 0:
                continue
            depth -= 1
            if depth == 0 and start_index is not None:
                blocks.append(source[start_index : index + 1])
                start_index = None

    return blocks


def _extract_named_block(
    source: str,
    field_name: str,
    *,
    open_token: str,
    close_token: str,
) -> str:
    field_offset = source.index(f"{field_name}:")
    block_start = source.index(open_token, field_offset)
    block_end = _find_matching_token(source, block_start, open_token, close_token)
    return source[block_start : block_end + 1]


def _extract_function_calls(source: str, function_name: str) -> list[str]:
    calls: list[str] = []
    search_token = f"{function_name}("
    start_index = 0

    while True:
        call_start = source.find(search_token, start_index)
        if call_start == -1:
            return calls

        paren_start = source.index("(", call_start)
        paren_end = _find_matching_token(source, paren_start, "(", ")")
        calls.append(source[call_start : paren_end + 1])
        start_index = paren_end + 1


def _parse_shape(shape_literal: str) -> tuple[int, ...]:
    dims: list[int] = []
    for token in shape_literal.split(","):
        clean_token = token.strip().strip("'").strip('"')
        if clean_token:
            dims.append(int(clean_token))
    return tuple(dims)


def _parse_schema_fields(source: str) -> tuple[_SchemaField, ...]:
    source = re.sub(r"^\s*//.*$", "", source, flags=re.MULTILINE)
    fields: list[_SchemaField] = []
    for block in _extract_braced_blocks(source):
        key_match = re.search(r"key:\s*'([^']+)'", block)
        dtype_match = re.search(r"dtype:\s*'([^']+)'", block)
        if key_match is None or dtype_match is None:
            continue

        shape_match = re.search(r"shape:\s*\[([^\]]+)\]", block)
        fields.append(
            _SchemaField(
                key=key_match.group(1),
                dtype=dtype_match.group(1),
                shape=_parse_shape(shape_match.group(1)) if shape_match else None,
            )
        )

    return tuple(fields)


def _selection_cache_key(
    frontend_selection: dict[str, Any] | None,
) -> tuple[tuple[str, str], ...]:
    if frontend_selection is None:
        return ()
    return tuple(sorted((key, str(value)) for key, value in frontend_selection.items()))


def _parse_observation_table_fields(
    observation_block: str,
    selection_key: tuple[tuple[str, str], ...],
) -> tuple[_SchemaField, ...]:
    selected_table_fields: tuple[_SchemaField, ...] | None = None
    fallback_fields: tuple[_SchemaField, ...] | None = None
    selection = dict(selection_key)

    for call_source in _extract_function_calls(observation_block, "createObservationTable"):
        dep_match = re.search(
            r"dependencyPath\(\s*'benchmarkSpecificFields',\s*'([^']+)',\s*'([^']+)'\s*\)",
            call_source,
        )
        field_block_start = call_source.index("[")
        field_block_end = _find_matching_token(
            call_source,
            field_block_start,
            "[",
            "]",
        )
        field_block = call_source[field_block_start : field_block_end + 1]
        parsed_fields = _parse_schema_fields(field_block)

        if dep_match is None:
            fallback_fields = parsed_fields
            continue

        dep_key, dep_value = dep_match.groups()
        if selection.get(dep_key) == dep_value:
            selected_table_fields = parsed_fields
            break

    if selected_table_fields is not None:
        return selected_table_fields
    if fallback_fields is not None:
        return fallback_fields

    raise AssertionError("Unable to select an observation schema table.")


@lru_cache(maxsize=None)
def _load_frontend_schema_fields(
    benchmark_id: str,
    selection_key: tuple[tuple[str, str], ...] = (),
) -> tuple[tuple[_SchemaField, ...], tuple[_SchemaField, ...]]:
    if not _FRONTEND_SCHEMA_PATH.exists():
        pytest.skip(f"Missing frontend schema file: {_FRONTEND_SCHEMA_PATH}")

    source = _FRONTEND_SCHEMA_PATH.read_text(encoding="utf-8")
    schema_root = source.index("const sampleBenchmarkSchemas")
    benchmark_anchor = f"'{benchmark_id}': {{"
    benchmark_start = source.index(benchmark_anchor, schema_root)
    block_start = source.index("{", benchmark_start)
    block_end = _find_matching_token(source, block_start, "{", "}")
    benchmark_block = source[block_start : block_end + 1]

    observation_block = _extract_named_block(
        benchmark_block,
        "observationSchema",
        open_token="[",
        close_token="]",
    )
    info_block = _extract_named_block(
        benchmark_block,
        "infoSchema",
        open_token="[",
        close_token="]",
    )

    return (
        _parse_observation_table_fields(observation_block, selection_key),
        _parse_schema_fields(info_block),
    )


def _lookup_path(payload: dict[str, Any], dotted_key: str) -> Any:
    current: Any = payload
    for token in dotted_key.split("."):
        if not isinstance(current, dict) or token not in current:
            return _MISSING
        current = current[token]
    return current


def _flatten_leaf_values(payload: Any) -> dict[str, Any]:
    leaf_values: dict[str, Any] = {}

    def _walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, nested in value.items():
                if isinstance(nested, dict):
                    _walk(nested)
                else:
                    leaf_values[key] = nested

    _walk(payload)
    return leaf_values


def _normalize_observation_key(key: str) -> str:
    return re.sub(r"^robot(\d+)_", r"robot_\1_", key)


def _observation_field_value(
    observation: dict[str, Any],
    field: _SchemaField,
) -> Any:
    value = _lookup_path(observation, field.key)
    if value is not _MISSING:
        return value

    flattened_observation = {
        _normalize_observation_key(key): value
        for key, value in _flatten_leaf_values(observation).items()
    }
    normalized_leaf_key = _normalize_observation_key(field.key.split(".")[-1])
    return flattened_observation.get(normalized_leaf_key, _MISSING)


def _assert_scalar_dtype(value: Any, dtype: str, key: str) -> None:
    if dtype == "dict":
        assert isinstance(value, dict), (
            f"{key} should be dict, got {type(value).__name__}"
        )
        return

    if dtype == "boolean":
        assert isinstance(value, bool), (
            f"{key} should be boolean, got {type(value).__name__}"
        )
        return

    if dtype == "string":
        assert isinstance(value, str), (
            f"{key} should be string, got {type(value).__name__}"
        )
        return

    if dtype in {"float32", "float64"}:
        assert isinstance(value, (int, float)) and not isinstance(value, bool), (
            f"{key} should be numeric, got {type(value).__name__}"
        )
        return

    if dtype in {"int32", "int64"}:
        assert isinstance(value, int) and not isinstance(value, bool), (
            f"{key} should be integer, got {type(value).__name__}"
        )
        return

    if dtype == "uint8":
        assert isinstance(value, int) and not isinstance(value, bool), (
            f"{key} should be uint8, got {type(value).__name__}"
        )
        assert 0 <= value <= 255, f"{key} should be between 0 and 255, got {value!r}"
        return

    raise AssertionError(f"Unsupported dtype {dtype!r} for {key}.")


def _assert_array_shape_and_dtype(
    value: Any,
    shape: tuple[int, ...],
    dtype: str,
    key: str,
) -> None:
    assert isinstance(value, (list, tuple)), (
        f"{key} should be list-like for shape {shape}, got {type(value).__name__}"
    )
    assert len(value) == shape[0], (
        f"{key} expected shape {shape}, got leading dimension {len(value)}"
    )

    if len(shape) == 1:
        for item in value:
            _assert_scalar_dtype(item, dtype, key)
        return

    for item in value:
        _assert_array_shape_and_dtype(item, shape[1:], dtype, key)


def _assert_field_matches(value: Any, field: _SchemaField) -> None:
    if field.shape is not None:
        _assert_array_shape_and_dtype(value, field.shape, field.dtype, field.key)
        return

    if field.dtype.endswith("[]"):
        base_dtype = field.dtype[:-2]
        assert isinstance(value, list), (
            f"{field.key} should be list for dtype {field.dtype}, got {type(value).__name__}"
        )
        for item in value:
            _assert_scalar_dtype(item, base_dtype, field.key)
        return

    _assert_scalar_dtype(value, field.dtype, field.key)


def _assert_observation_matches_frontend_schema(
    benchmark_id: str,
    observation: dict[str, Any],
    *,
    frontend_selection: dict[str, Any] | None = None,
) -> None:
    observation_fields, _ = _load_frontend_schema_fields(
        benchmark_id,
        _selection_cache_key(frontend_selection),
    )
    for field in observation_fields:
        value = _observation_field_value(observation, field)
        assert value is not _MISSING, (
            f"Missing observation key {field.key!r}"
        )
        _assert_field_matches(value, field)


def _assert_info_matches_frontend_schema(
    benchmark_id: str,
    info: dict[str, Any],
    *,
    require_all: bool,
    frontend_selection: dict[str, Any] | None = None,
) -> None:
    _, info_fields = _load_frontend_schema_fields(
        benchmark_id,
        _selection_cache_key(frontend_selection),
    )
    for field in info_fields:
        value = _lookup_path(info, field.key)
        if value is _MISSING:
            if require_all:
                raise AssertionError(f"Missing info key {field.key!r}")
            continue
        _assert_field_matches(value, field)


def _assert_info_contract_equivalent(
    benchmark_id: str,
    left: dict[str, Any],
    right: dict[str, Any],
    path: str,
    *,
    require_all: bool,
    frontend_selection: dict[str, Any] | None = None,
) -> None:
    _, info_fields = _load_frontend_schema_fields(
        benchmark_id,
        _selection_cache_key(frontend_selection),
    )
    for field in info_fields:
        left_value = _lookup_path(left, field.key)
        right_value = _lookup_path(right, field.key)

        if left_value is _MISSING or right_value is _MISSING:
            if require_all or left_value is not right_value:
                raise AssertionError(f"{path}.{field.key} presence mismatch")
            continue

        _assert_values_equivalent(left_value, right_value, f"{path}.{field.key}")


def _assert_reset_schema(
    benchmark_id: str,
    result: Any,
    *,
    frontend_selection: dict[str, Any] | None = None,
) -> None:
    assert isinstance(result, tuple), "reset() should return a tuple"
    assert len(result) == 2, f"reset() should return 2 values, got {len(result)}"
    observation, info = result
    assert isinstance(observation, dict), "reset() observation should be dict"
    assert isinstance(info, dict), "reset() info should be dict"
    _assert_observation_matches_frontend_schema(
        benchmark_id,
        observation,
        frontend_selection=frontend_selection,
    )
    _assert_info_matches_frontend_schema(
        benchmark_id,
        info,
        require_all=False,
        frontend_selection=frontend_selection,
    )


def _assert_step_schema(
    benchmark_id: str,
    result: Any,
    *,
    frontend_selection: dict[str, Any] | None = None,
) -> None:
    assert isinstance(result, tuple), "step() should return a tuple"
    assert len(result) == 4, f"step() should return 4 values, got {len(result)}"
    observation, reward, done, info = result
    assert isinstance(observation, dict), "step() observation should be dict"
    assert isinstance(reward, (int, float)) and not isinstance(reward, bool), (
        "step() reward should be numeric"
    )
    assert isinstance(done, bool), "step() done should be bool"
    assert isinstance(info, dict), "step() info should be dict"
    _assert_observation_matches_frontend_schema(
        benchmark_id,
        observation,
        frontend_selection=frontend_selection,
    )
    _assert_info_matches_frontend_schema(
        benchmark_id,
        info,
        require_all=True,
        frontend_selection=frontend_selection,
    )


def _build_env(spec: _BenchmarkSpec, env_id: str) -> BenchmarkEnvironment:
    return init_bench(
        spec.benchmark_id,
        env_id,
        0,
        dict(spec.benchmark_specific),
    )


def _integration_prerequisites_ready() -> None:
    if not _BACKEND_ROUTE_PATH.exists():
        pytest.skip(f"Missing backend route file: {_BACKEND_ROUTE_PATH}")

    os.environ.setdefault("SIMULAC_BASE_URL", _LOCAL_SIMULAC_BASE_URL)

    runtime = gym_style.obtain_runtime()
    if runtime.environment_variable.token is None:
        pytest.skip(
            "SIMULAC_API_KEY or cached token is required for integration tests."
        )


def _env_ids_for_test(benchmark_id: str) -> list[str]:
    _integration_prerequisites_ready()

    env_ids = get_env_list(benchmark_id)
    assert env_ids, f"Expected at least one env for {benchmark_id}"

    limit = int(os.environ.get("SIMULAC_BENCHMARK_TEST_LIMIT", "1"))
    return env_ids[:limit]


def _is_known_backend_controller_issue(spec: _BenchmarkSpec, exc: Exception) -> bool:
    if spec.benchmark_id != "Tektonian/Robomimic":
        return False

    if not isinstance(exc, ConnectionClosedError):
        return False

    message = str(exc)
    return "controller is specified, but not imported or loaded" in message


def _is_connection_timeout_issue(exc: Exception) -> bool:
    return isinstance(exc, SimulacBaseError) and (
        "Unable to connect to the remote benchmark service" in str(exc)
    )


def _is_numeric_scalar(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _assert_same_keys(
    left: dict[str, Any],
    right: dict[str, Any],
    path: str,
) -> None:
    left_keys = set(left)
    right_keys = set(right)
    assert left_keys == right_keys, (
        f"{path} keys mismatch: {sorted(left_keys ^ right_keys)!r}"
    )


def _assert_values_equivalent(left: Any, right: Any, path: str) -> None:
    if isinstance(left, dict) or isinstance(right, dict):
        assert isinstance(left, dict) and isinstance(right, dict), (
            f"{path} type mismatch: {type(left).__name__} != {type(right).__name__}"
        )
        _assert_same_keys(left, right, path)
        for key in sorted(left):
            _assert_values_equivalent(left[key], right[key], f"{path}.{key}")
        return

    if isinstance(left, (list, tuple)) or isinstance(right, (list, tuple)):
        assert isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)), (
            f"{path} type mismatch: {type(left).__name__} != {type(right).__name__}"
        )
        assert len(left) == len(right), (
            f"{path} length mismatch: {len(left)} != {len(right)}"
        )
        for index, (left_item, right_item) in enumerate(zip(left, right)):
            _assert_values_equivalent(left_item, right_item, f"{path}[{index}]")
        return

    if _is_numeric_scalar(left) and _is_numeric_scalar(right):
        assert math.isclose(
            float(left),
            float(right),
            rel_tol=_NUMERIC_EQ_REL_TOL,
            abs_tol=_NUMERIC_EQ_ABS_TOL,
        ), f"{path} mismatch: {left!r} != {right!r}"
        return

    assert left == right, f"{path} mismatch: {left!r} != {right!r}"


def _assert_shape_equivalent(left: Any, right: Any, path: str) -> None:
    if isinstance(left, dict) or isinstance(right, dict):
        assert isinstance(left, dict) and isinstance(right, dict), (
            f"{path} type mismatch: {type(left).__name__} != {type(right).__name__}"
        )
        _assert_same_keys(left, right, path)
        for key in sorted(left):
            _assert_shape_equivalent(left[key], right[key], f"{path}.{key}")
        return

    if isinstance(left, (list, tuple)) or isinstance(right, (list, tuple)):
        assert isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)), (
            f"{path} type mismatch: {type(left).__name__} != {type(right).__name__}"
        )
        assert len(left) == len(right), (
            f"{path} length mismatch: {len(left)} != {len(right)}"
        )
        if left:
            _assert_shape_equivalent(left[0], right[0], f"{path}[0]")
        return

    left_kind = "number" if _is_numeric_scalar(left) else type(left).__name__
    right_kind = "number" if _is_numeric_scalar(right) else type(right).__name__
    assert left_kind == right_kind, (
        f"{path} leaf type mismatch: {left_kind} != {right_kind}"
    )


def _assert_observations_equivalent(
    left: dict[str, Any],
    right: dict[str, Any],
    path: str,
) -> None:
    _assert_same_keys(left, right, path)
    for key in sorted(left):
        if key == "images":
            _assert_shape_equivalent(left[key], right[key], f"{path}.{key}")
            continue
        _assert_values_equivalent(left[key], right[key], f"{path}.{key}")


def _assert_reset_results_equivalent(
    spec: _BenchmarkSpec,
    env_id: str,
    left: Any,
    right: Any,
    *,
    context: str,
) -> None:
    _assert_observations_equivalent(
        left[0],
        right[0],
        f"{spec.benchmark_id}/{env_id} {context} reset.obs",
    )
    _assert_info_contract_equivalent(
        spec.benchmark_id,
        left[1],
        right[1],
        f"{spec.benchmark_id}/{env_id} {context} reset.info",
        require_all=False,
        frontend_selection=spec.frontend_selection,
    )


def _assert_step_results_equivalent(
    spec: _BenchmarkSpec,
    env_id: str,
    left: Any,
    right: Any,
    *,
    context: str,
) -> None:
    _assert_observations_equivalent(
        left[0],
        right[0],
        f"{spec.benchmark_id}/{env_id} {context} step.obs",
    )
    _assert_values_equivalent(
        left[1],
        right[1],
        f"{spec.benchmark_id}/{env_id} {context} step.reward",
    )
    _assert_values_equivalent(
        left[2],
        right[2],
        f"{spec.benchmark_id}/{env_id} {context} step.done",
    )
    _assert_info_contract_equivalent(
        spec.benchmark_id,
        left[3],
        right[3],
        f"{spec.benchmark_id}/{env_id} {context} step.info",
        require_all=True,
        frontend_selection=spec.frontend_selection,
    )


def _classify_known_integration_issue(
    spec: _BenchmarkSpec,
    exc: Exception,
) -> str | None:
    if _is_connection_timeout_issue(exc):
        return (
            "Local benchmark container did not become reachable within the test "
            "timeout. Rerun after the backend finishes cold-starting."
        )

    if _is_known_backend_controller_issue(spec, exc):
        return "Local Robomimic backend cannot load a controller for the benchmark."

    message = str(exc)

    if spec.benchmark_id == "Tektonian/Calvin" and "reset-step-reset reset.obs.states." in message:
        return "Calvin reset is not fully deterministic for some state fields with seed=0."

    if spec.benchmark_id == "Tektonian/Calvin" and (
        "states.object_" in message or "images.cam_" in message
    ):
        return (
            "Calvin frontend schema in benchmark-data.ts does not match the "
            "runtime payload from the local backend."
        )

    if spec.benchmark_id == "Tektonian/Metaworld" and "goal_0_pos" in message:
        return "Metaworld reset is not deterministic for goal_0_pos with seed=0."

    return None


def _run_with_connection_retry(callback: Any, *, retries: int = 2) -> None:
    last_exc: Exception | None = None

    for attempt in range(retries):
        try:
            callback()
            return
        except Exception as exc:
            last_exc = exc
            if not _is_connection_timeout_issue(exc) or attempt == retries - 1:
                raise
            time.sleep(5)

    if last_exc is not None:
        raise last_exc


def _warm_up_env(spec: _BenchmarkSpec, env_id: str) -> None:
    def _warmup() -> None:
        env = _build_env(spec, env_id)
        try:
            _assert_reset_schema(
                spec.benchmark_id,
                env.reset(0),
                frontend_selection=spec.frontend_selection,
            )
        finally:
            env.close()

    _run_with_connection_retry(_warmup)


def _assert_two_envs_match(spec: _BenchmarkSpec, env_id: str) -> None:
    env_a = _build_env(spec, env_id)
    env_b = _build_env(spec, env_id)

    try:
        for cycle_index in range(2):
            reset_a = env_a.reset(0)
            reset_b = env_b.reset(0)
            _assert_reset_schema(
                spec.benchmark_id,
                reset_a,
                frontend_selection=spec.frontend_selection,
            )
            _assert_reset_schema(
                spec.benchmark_id,
                reset_b,
                frontend_selection=spec.frontend_selection,
            )
            _assert_reset_results_equivalent(
                spec,
                env_id,
                reset_a,
                reset_b,
                context=f"cycle {cycle_index}",
            )

            step_a = env_a.step(list(spec.action))
            step_b = env_b.step(list(spec.action))
            _assert_step_schema(
                spec.benchmark_id,
                step_a,
                frontend_selection=spec.frontend_selection,
            )
            _assert_step_schema(
                spec.benchmark_id,
                step_b,
                frontend_selection=spec.frontend_selection,
            )
            _assert_step_results_equivalent(
                spec,
                env_id,
                step_a,
                step_b,
                context=f"cycle {cycle_index}",
            )
    finally:
        env_a.close()
        env_b.close()


def _assert_single_env_cycle_and_close(spec: _BenchmarkSpec, env_id: str) -> None:
    env = _build_env(spec, env_id)
    socket = None

    try:
        first_reset = env.reset(0)
        _assert_reset_schema(
            spec.benchmark_id,
            first_reset,
            frontend_selection=spec.frontend_selection,
        )

        first_step = env.step(list(spec.action))
        _assert_step_schema(
            spec.benchmark_id,
            first_step,
            frontend_selection=spec.frontend_selection,
        )

        second_reset = env.reset(0)
        _assert_reset_schema(
            spec.benchmark_id,
            second_reset,
            frontend_selection=spec.frontend_selection,
        )
        second_step = env.step(list(spec.action))
        _assert_step_schema(
            spec.benchmark_id,
            second_step,
            frontend_selection=spec.frontend_selection,
        )

        _assert_reset_results_equivalent(
            spec,
            env_id,
            first_reset,
            second_reset,
            context="reset-step-reset",
        )
        _assert_step_results_equivalent(
            spec,
            env_id,
            first_step,
            second_step,
            context="reset-step-reset",
        )

        socket = env._ensure_connected()
        assert getattr(socket.state, "name", str(socket.state)) == "OPEN"
    finally:
        env.close()

    assert env._socket is None
    if socket is not None:
        assert getattr(socket.state, "name", str(socket.state)) == "CLOSED"
        assert socket.close_code is not None


def test_get_env_list_fetches_scene_list(monkeypatch: pytest.MonkeyPatch) -> None:
    requested: dict[str, object] = {}

    def fake_get(
        url: str,
        *,
        params: dict[str, str] | None = None,
        timeout: int,
    ) -> _MockResponse:
        requested["url"] = url
        requested["params"] = params
        requested["timeout"] = timeout
        return _MockResponse(["env-a"])

    monkeypatch.setattr(
        gym_style,
        "obtain_runtime",
        lambda: _runtime_for_test(base_url="https://example.com/api"),
    )
    monkeypatch.setattr(gym_style.requests, "get", fake_get)

    assert get_env_list("Tektonian/Libero") == ["env-a"]
    assert requested == {
        "url": "https://example.com/api/container/scene-list/Tektonian/Libero",
        "params": None,
        "timeout": 10,
    }


def test_get_env_list_rejects_non_list_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(gym_style, "obtain_runtime", _runtime_for_test)
    monkeypatch.setattr(
        gym_style.requests, "get", lambda *args, **kwargs: _MockResponse({})
    )

    with pytest.raises(SimulacBaseError):
        get_env_list("Tektonian/Libero")


def test_get_env_list_raises_when_backend_returns_http_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    http_error = requests.HTTPError("backend error")
    monkeypatch.setattr(gym_style, "obtain_runtime", _runtime_for_test)
    monkeypatch.setattr(
        gym_style.requests,
        "get",
        lambda *args, **kwargs: _MockResponse([], raised_error=http_error),
    )

    with pytest.raises(requests.HTTPError):
        get_env_list("Tektonian/Libero")


def test_get_env_list_requires_benchmark_owner_and_name() -> None:
    with pytest.raises(SimulacBaseError):
        get_env_list("Libero")


def test_preflight_raises_without_matching_backend_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        gym_style_environment,
        "obtain_runtime",
        lambda: _runtime_for_test(),
    )
    monkeypatch.setattr(
        gym_style_environment.requests,
        "post",
        lambda *args, **kwargs: _MockResponse(
            {"message": "message text may change"},
            status_code=403,
        ),
    )

    env = BenchmarkEnvironment("id", "Tektonian/Libero", "env-a", 0, {})
    with pytest.raises(SimulacBaseError):
        env._create_ticket()


def test_preflight_raises_for_non_json_error_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        gym_style_environment,
        "obtain_runtime",
        lambda: _runtime_for_test(),
    )
    monkeypatch.setattr(
        gym_style_environment.requests,
        "post",
        lambda *args, **kwargs: _MockResponse(
            ValueError("not json"),
            status_code=429,
            text="plain text response",
        ),
    )

    env = BenchmarkEnvironment("id", "Tektonian/Libero", "env-a", 0, {})
    with pytest.raises(SimulacBaseError):
        env._create_ticket()


def test_observation_field_value_prefers_dotted_path() -> None:
    observation = {
        "states": {"robot_0_joint_pos": [0.0]},
        "other": {"robot_0_joint_pos": [1.0]},
    }
    field = _SchemaField(key="states.robot_0_joint_pos", dtype="float64", shape=(1,))

    assert _observation_field_value(observation, field) == [0.0]


def test_observation_equivalence_ignores_image_pixels() -> None:
    left = {
        "images": {"cam_0_rgb": [[[0, 0, 0]]]},
        "states": {"robot_0_joint_pos": [0.0]},
    }
    right = {
        "images": {"cam_0_rgb": [[[255, 128, 64]]]},
        "states": {"robot_0_joint_pos": [0.0]},
    }

    _assert_observations_equivalent(left, right, "obs")


def test_info_contract_equivalence_ignores_extra_backend_keys() -> None:
    left = {
        "task_description": "task",
        "obs_meta": {"cam_map": {"cam_0": 0}},
        "scene_info": {"volatile": 1},
    }
    right = {
        "task_description": "task",
        "obs_meta": {"cam_map": {"cam_0": 0}},
        "scene_info": {"volatile": 2},
    }

    _assert_info_contract_equivalent(
        "Tektonian/Libero",
        left,
        right,
        "info",
        require_all=False,
    )


@pytest.mark.integration
def test_scene_list_is_available() -> None:
    _integration_prerequisites_ready()

    libero_env_list = get_env_list("Tektonian/Libero")
    assert libero_env_list


@pytest.mark.integration
@pytest.mark.parametrize(
    "spec",
    _BENCHMARK_SPECS,
    ids=lambda spec: spec.case_id,
)
def test_benchmark_contracts(spec: _BenchmarkSpec) -> None:
    failures: list[str] = []

    for env_id in _env_ids_for_test(spec.benchmark_id):
        try:
            _warm_up_env(spec, env_id)
            _run_with_connection_retry(lambda: _assert_two_envs_match(spec, env_id))
            _run_with_connection_retry(
                lambda: _assert_single_env_cycle_and_close(spec, env_id)
            )
        except Exception as exc:
            known_issue = _classify_known_integration_issue(spec, exc)
            if known_issue is not None:
                pytest.xfail(known_issue)
            failures.append(f"{env_id}: {exc!r}")

    assert not failures, "Failed benchmark contracts:\n" + "\n".join(failures)
