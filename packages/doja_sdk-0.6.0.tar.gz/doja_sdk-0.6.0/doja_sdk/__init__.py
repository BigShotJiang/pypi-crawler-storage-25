# doja_sdk/__init__.py
from .client import DojaClient, AsyncDojaClient
from .email_client import DojaEmailClient, AsyncDojaEmailClient
from .exceptions import (
    DojaSDKException,
    DojaAuthError,
    DojaQuotaExceeded,
    DojaAPIError,
    DojaLicenseNotFoundError,
    DojaLicenseNotActiveError,
    DojaMessageLimitReachedError,
    DojaValidationError
)

__version__ = "0.6.0"
__all__ = [
    "DojaClient",
    "AsyncDojaClient",
    "DojaEmailClient",
    "AsyncDojaEmailClient",
    "DojaSDKException",
    "DojaAuthError",
    "DojaQuotaExceeded",
    "DojaAPIError",
    "DojaLicenseNotFoundError",
    "DojaLicenseNotActiveError",
    "DojaMessageLimitReachedError",
    "DojaValidationError"
]
