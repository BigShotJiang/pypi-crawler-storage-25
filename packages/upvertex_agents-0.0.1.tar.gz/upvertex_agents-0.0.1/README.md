# upvertex-agents

Namespace reservation for UpVertex Inc. (www.upvertex.com)