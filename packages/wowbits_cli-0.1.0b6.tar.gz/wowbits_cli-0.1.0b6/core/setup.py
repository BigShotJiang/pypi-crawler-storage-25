"""
Setup service - create tables, ensure workspace dirs, init DB from YAML, save .env.
Non-interactive only.
"""
import os
from pathlib import Path
from typing import Any, Dict, List

import yaml

from db.schema import Agent, Base, Connector, MCPConfig, Skill
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


def ensure_workspace_dirs(workspace_path: Path) -> None:
    """Create workspace subdirs if missing."""
    for name in [
        "data",
        "agent_studio",
        "functions",
        "agent_runner",
        "agents",
        "skills",
        "tools",
        "connectors",
        "mcps",
        "logs/system",
        "logs/agents",
        "logs/mcps",
    ]:
        d = workspace_path / name
        d.mkdir(parents=True, exist_ok=True)
    init_py = workspace_path / "agent_runner" / "__init__.py"
    if not init_py.exists():
        init_py.write_text("# WowBits Agent Runner\n")


def create_database_tables(db_url: str) -> None:
    """Create all DB tables."""
    engine = create_engine(db_url)
    Base.metadata.create_all(engine)
    engine.dispose()


def load_yaml_files(data_dir: Path) -> List[Dict[str, Any]]:
    """Load all YAML documents from data_dir. Returns list of dicts."""
    if not data_dir.exists():
        return []
    files = list(data_dir.glob("*.yaml")) + list(data_dir.glob("*.yml"))
    out = []
    for f in files:
        try:
            with open(f, "r") as fp:
                data = yaml.safe_load(fp)
            if isinstance(data, list):
                out.extend(data)
            elif isinstance(data, dict):
                out.append(data)
        except Exception:
            continue
    return out


def create_object_from_yaml(session: Any, obj_data: Dict[str, Any]) -> None:
    """Create one DB row from YAML object (kind: agent, skill, tool, connector, mcp)."""
    raw_kind = (obj_data.get("kind") or "").lower()
    kind = raw_kind.removeprefix("wowbits_") if raw_kind.startswith("wowbits_") else raw_kind
    if kind == "agent":
        session.add(
            Agent(
                name=obj_data["name"],
                description=obj_data.get("description"),
                instructions=obj_data.get("instructions") or "",
                default_model=obj_data.get("default_model") or "gpt-4.1",
                temperature=obj_data.get("temperature"),
                max_output_tokens=obj_data.get("max_output_tokens"),
            )
        )
    elif kind == "skill":
        session.add(
            Skill(
                name=obj_data["name"],
                description=obj_data.get("description"),
                instructions=obj_data.get("instructions") or "",
                default_model=obj_data.get("default_model") or "gpt-4.1",
                temperature=obj_data.get("temperature"),
                max_output_tokens=obj_data.get("max_output_tokens"),
                output_key=obj_data.get("output_key"),
            )
        )
    elif kind == "tool":
        # Tool requires type (ToolType) and optional FKs; skip legacy YAML init
        pass
    elif kind == "connector":
        session.add(
            Connector(
                name=obj_data.get("name") or obj_data.get("provider", "connector"),
                provider=obj_data["provider"],
                config=obj_data.get("config", {}),
            )
        )
    elif kind in ("mcp", "mcpconfig"):
        session.add(
            MCPConfig(
                name=obj_data["name"],
                url=obj_data.get("url"),
                config=obj_data.get("config", {}),
            )
        )


def initialize_database(db_url: str, data_dir: Path) -> Dict[str, int]:
    """
    Set WOWBITS_DB_CONNECTION_STRING, create tables, load YAMLs, create objects.
    Uses a local engine/session (does not rely on global db manager).
    Returns {"loaded": N, "created": M}.
    """
    os.environ["WOWBITS_DB_CONNECTION_STRING"] = db_url
    create_database_tables(db_url)
    objects = load_yaml_files(data_dir)
    created = 0
    engine = create_engine(db_url)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    try:
        with SessionLocal() as session:
            for obj_data in objects:
                try:
                    create_object_from_yaml(session, obj_data)
                    created += 1
                except Exception:
                    continue
            session.commit()
    finally:
        engine.dispose()
    return {"loaded": len(objects), "created": created}


def save_db_config(workspace_path: Path, db_url: str) -> None:
    """Write WOWBITS_DB_CONNECTION_STRING to workspace_path/.env."""
    env_file = workspace_path / ".env"
    lines = []
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if not line.strip().startswith("WOWBITS_DB_CONNECTION_STRING="):
                lines.append(line + "\n")
    lines.append(f"WOWBITS_DB_CONNECTION_STRING={db_url}\n")
    env_file.write_text("".join(lines))


def setup_workspace_dirs(workspace_path: Path) -> Dict[str, Any]:
    """
    Create WowBits workspace directory structure (data, agent_studio, functions, agent_runner).
    Returns {"workspace": str(workspace_path)}.
    """
    ensure_workspace_dirs(workspace_path)
    return {"workspace": str(workspace_path)}


def setup_database(workspace_path: Path, db_url: str) -> Dict[str, Any]:
    """
    Create DB tables, init from data dir YAMLs, save .env.
    Returns {"db_configured": True, "loaded": N, "created": M}.
    """
    data_dir = workspace_path / "data"
    result = initialize_database(db_url, data_dir)
    save_db_config(workspace_path, db_url)
    return {"db_configured": True, **result}


def run_setup(workspace_path: Path, db_url: str) -> Dict[str, Any]:
    """
    Full setup: setup workspace dirs, then setup database.
    Returns summary dict.
    """
    setup_workspace_dirs(workspace_path)
    result = setup_database(workspace_path, db_url)
    return {
        "workspace": str(workspace_path),
        **result,
    }
