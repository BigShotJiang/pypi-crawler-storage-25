# WowBits core services - business logic only, no HTTP or CLI.
