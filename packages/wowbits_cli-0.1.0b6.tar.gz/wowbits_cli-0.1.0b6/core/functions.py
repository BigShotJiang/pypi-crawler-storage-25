"""
Functions service - list, sync from dir, pull from GitHub. Accepts workspace path.
"""
import json
import re
import subprocess
import sys
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from db.schema import PythonFunction
from pylibs.pull import GitHubPuller


def get_functions_dir(workspace_path: Path) -> Path:
    """Return workspace_path/functions."""
    return workspace_path / "functions"


def list_functions(session: Session) -> List[Dict[str, Any]]:
    """List all Python functions."""
    functions = session.query(PythonFunction).all()
    return [
        {
            "id": str(f.id),
            "name": f.name,
            "description": f.description or "",
        }
        for f in functions
    ]


def scan_and_create_functions(
    session: Session,
    functions_dir: Path,
    install_requirements: bool = True,
) -> Dict[str, int]:
    """
    Scan functions_dir for .py files and create/update PythonFunction rows.
    Returns {"created": N, "updated": M}.
    """
    if not functions_dir.exists():
        return {"created": 0, "updated": 0}
    if install_requirements:
        req_file = functions_dir / "requirements.txt"
        if req_file.exists():
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "-r", str(req_file)],
                    capture_output=True,
                    text=True,
                    check=False,
                )
            except Exception:
                pass
    python_files = [
        f
        for f in functions_dir.glob("*.py")
        if f.name not in ("__init__.py", "create_functions_in_db.py")
    ]
    created = 0
    updated = 0
    for py_file in python_files:
        name = py_file.stem
        try:
            content = py_file.read_text(encoding="utf-8")
        except Exception:
            continue
        existing = session.query(PythonFunction).filter(PythonFunction.name == name).first()
        if existing:
            existing.code = content
            session.merge(existing)
            updated += 1
        else:
            session.add(
                PythonFunction(name=name, description=name, code=content)
            )
            created += 1
    return {"created": created, "updated": updated}


def _parse_github_url(repo_url: str) -> Optional[Tuple[str, str, str]]:
    """Return (owner, repo, branch) or None."""
    url = repo_url.strip().rstrip("/")
    m = re.match(r"https?://(?:www\.)?github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$", url, re.I)
    if m:
        return (m.group(1), m.group(2), "main")
    m = re.match(r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?/?$", url)
    if m:
        return (m.group(1), m.group(2), "main")
    return None


def _fetch_raw(owner: str, repo: str, branch: str, path: str) -> Optional[str]:
    url = f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}"
    req = urllib.request.Request(url, headers={"Accept": "application/octet-stream"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            if resp.status == 200:
                return resp.read().decode("utf-8", errors="replace")
    except Exception:
        pass
    return None


def _list_github_dir(owner: str, repo: str, branch: str, path: str) -> List[dict]:
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={branch}"
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github.v3+json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            if resp.status == 200:
                return json.loads(resp.read().decode())
    except Exception:
        pass
    return []


class FunctionsPuller(GitHubPuller):
    def __init__(self):
        super().__init__(
            resource_type="functions",
            dir_name="functions",
            file_extension=".py",
            exclude_files=["__init__.py", "create_functions_in_db.py"]
        )

    def upsert_resource(self, session: Session, name: str, content: str) -> Tuple[int, int]:
        """Upsert function in DB. Returns (created, updated)."""
        existing = session.query(PythonFunction).filter(PythonFunction.name == name).first()
        if existing:
            existing.code = content
            session.merge(existing)
            return 0, 1
        else:
            session.add(PythonFunction(name=name, description=name, code=content))
            return 1, 0


def pull_functions_from_repo(
    session: Session,
    workspace_path: Path,
    repo_url: str,
    function_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Fetch .py files from GitHub, write to workspace_path/functions, upsert DB.
    function_names: None or [] or ["*"] = pull all. Else list of names.
    Returns {"created": N, "updated": M, "files": [names], "error": optional}.
    """
    puller = FunctionsPuller()
    result = puller.pull_from_repo(workspace_path, repo_url, function_names)

    # Now upsert to DB
    dest_dir = get_functions_dir(workspace_path)
    created = 0
    updated = 0

    for file_name in result["files"]:
        name = file_name[:-3]  # remove .py
        file_path = dest_dir / file_name
        if file_path.exists():
            content = file_path.read_text(encoding="utf-8")
            c, u = puller.upsert_resource(session, name, content)
            created += c
            updated += u

    # Flush so newly inserted rows are visible to follow-on queries in the same transaction
    session.flush()

    result["created"] = created
    result["updated"] = updated
    return result


def get_function(session: Session, name: str) -> Optional[Dict[str, Any]]:
    """Get function by name."""
    f = session.query(PythonFunction).filter(PythonFunction.name == name).first()
    if not f:
        return None
    return {"id": str(f.id), "name": f.name, "description": f.description or "", "code": f.code}


def create_function(
    session: Session,
    name: str,
    code: str,
    description: str = "",
) -> Dict[str, Any]:
    """Create a Python function."""
    if session.query(PythonFunction).filter(PythonFunction.name == name).first():
        raise ValueError(f"Function '{name}' already exists")
    f = PythonFunction(name=name, description=description or name, code=code)
    session.add(f)
    session.flush()
    return {"id": str(f.id), "name": f.name, "description": f.description or ""}


def update_function(
    session: Session,
    name: str,
    code: Optional[str] = None,
    description: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Update function by name."""
    f = session.query(PythonFunction).filter(PythonFunction.name == name).first()
    if not f:
        return None
    if code is not None:
        f.code = code
    if description is not None:
        f.description = description
    session.flush()
    return {"id": str(f.id), "name": f.name, "description": f.description or ""}


def delete_function(session: Session, name: str) -> bool:
    """Delete function by name."""
    f = session.query(PythonFunction).filter(PythonFunction.name == name).first()
    if not f:
        return False
    session.delete(f)
    return True
