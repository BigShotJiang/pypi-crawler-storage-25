"""
Agent service - YAML parsing, tool/skill/agent CRUD, agent code generation, run (subprocess).
Uses workspace path and session; no print, raises or returns data.
"""
import io
import logging
import os
import re
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.error import URLError
from urllib.request import Request, urlopen
from uuid import UUID, uuid4

import yaml

from pylibs.pull import GitHubPuller, parse_github_url, list_github_dir, fetch_raw_content
from core import functions as core_functions
from core import mcp as core_mcp

from db.schema import (
    Agent,
    AgentSkill,
    AgentStatus,
    MCPConfig,
    PythonFunction,
    Skill,
    SkillSkill,
    SkillTool,
    Tool,
    ToolType,
    ExecMode,
    SequentialAgentExecOrder,
    SequentialSkillExecOrder,
)
from pylibs.database_manager import get_db_manager, get_session_context

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "gpt-4.1"

# Agent code template for generated agent.py (runtime runs in agent_runner)
AGENT_CODE_TEMPLATE = '''
from uuid import UUID
import logging
from google.adk.agents import LlmAgent, SequentialAgent, ParallelAgent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset, StreamableHTTPConnectionParams, SseConnectionParams, StdioConnectionParams
from mcp import StdioServerParameters
from pylibs.database_manager import get_db_manager
from db.schema import (
    Agent, AgentSkill, Skill, SkillSkill, SkillTool, Tool, 
    PythonFunction, MCPConfig, ToolType, ExecMode,
    SequentialAgentExecOrder, SequentialSkillExecOrder
)
from google.adk.models.lite_llm import LiteLlm
from google.genai import types

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

agent_id = "{agent_id}"


def load_python_function(session, python_function_id):
    """Load and execute Python function code from database."""
    pf = session.get(PythonFunction, python_function_id)
    if not pf:
        logger.warning(f"Python function {{python_function_id}} not found")
        return None
    ns = {{}}
    try:
        exec(pf.code, ns)
    except SyntaxError as e:
        logger.exception(f"Syntax error in tool {{pf.name}} at line {{e.lineno}}: {{e.text}}")
        raise
    return ns.get(pf.name)


def _to_float(value, default):
    """Best-effort float conversion for timeout settings."""
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def load_tools_for_skill(session, skill_id):
    """Load all tools (Python functions and MCP servers) for a skill."""
    tools = []
    links = session.query(SkillTool).filter(SkillTool.skill_id == skill_id).all()
    for link in links:
        tool_ob = session.get(Tool, link.tool_id)
        if not tool_ob:
            continue
        
        if tool_ob.type == ToolType.PYTHON_FUNCTION:
            try:
                fn = load_python_function(session, tool_ob.python_function_id)
                if fn:
                    tools.append(fn)
            except Exception:
                logger.exception(f"Failed loading python function tool for skill {{skill_id}}")
        elif tool_ob.type == ToolType.MCP_SERVER:
            try:
                cfg = session.get(MCPConfig, tool_ob.mcp_config_id)
                if not cfg:
                    continue
                c = cfg.config or {{}}
                transport_mode = c.get("transport_mode")
                if not transport_mode:
                    continue
                connect_timeout = _to_float(c.get("timeout"), 60.0)
                sse_read_timeout = _to_float(c.get("sse_read_timeout"), 300.0)
                if transport_mode == "http":
                    url = cfg.url
                    tools.append(
                        MCPToolset(
                            connection_params=StreamableHTTPConnectionParams(
                                url=url,
                                timeout=connect_timeout,
                                sse_read_timeout=sse_read_timeout,
                            )
                        )
                    )
                elif transport_mode == "sse":
                    url = cfg.url
                    tools.append(
                        MCPToolset(
                            connection_params=SseConnectionParams(
                                url=url,
                                timeout=connect_timeout,
                                sse_read_timeout=sse_read_timeout,
                            )
                        )
                    )
                elif transport_mode == "stdio":
                    command = c.get("command")
                    args = c.get("args", [])
                    env = c.get("env", None)
                    if not command:
                        logger.warning(f"Stdio transport missing 'command' for skill {{skill_id}}")
                        continue
                    server_params = StdioServerParameters(command=command, args=args, env=env)
                    tools.append(
                        MCPToolset(
                            connection_params=StdioConnectionParams(
                                server_params=server_params,
                                timeout=connect_timeout,
                            )
                        )
                    )
                else:
                    logger.warning(f"Unknown transport mode: {{transport_mode}}")
                    continue
            except Exception:
                logger.exception(f"Failed loading MCP tool for skill {{skill_id}}")
    return tools


def _build_safety_settings(raw):
    """Convert stored JSON into google.genai.types.SafetySetting objects."""
    if not raw:
        return []
    out = []
    for item in raw:
        try:
            cat = item.get("category")
            thr = item.get("threshold")
            category_enum = (
                getattr(types.HarmCategory, cat)
                if isinstance(cat, str) and hasattr(types.HarmCategory, cat)
                else None
            )
            threshold_enum = (
                getattr(types.HarmBlockThreshold, thr)
                if isinstance(thr, str) and hasattr(types.HarmBlockThreshold, thr)
                else None
            )
            if category_enum and threshold_enum:
                out.append(
                    types.SafetySetting(category=category_enum, threshold=threshold_enum)
                )
        except Exception:
            continue
    return out


def _build_generate_content_config(obj):
    """Build GenerateContentConfig from agent/skill configuration."""
    conf_json = (
        (obj.default_model_config or {{}}) if hasattr(obj, "default_model_config") else {{}}
    )
    temp = (
        obj.temperature
        if getattr(obj, "temperature", None) is not None
        else conf_json.get("temperature", 0.2)
    )
    max_tokens = (
        obj.max_output_tokens
        if getattr(obj, "max_output_tokens", None)
        else conf_json.get("max_output_tokens", 32000)
    )
    raw_safety = (
        obj.safety_settings
        if getattr(obj, "safety_settings", None)
        else conf_json.get("safety_settings", [])
    )
    safety_objects = _build_safety_settings(raw_safety)
    return types.GenerateContentConfig(
        temperature=temp,
        max_output_tokens=max_tokens,
        safety_settings=safety_objects
    )


def build_skill_agent(session, skill, skill_cache, visiting_set):
    """
    Recursively build a skill agent based on its exec_mode.
    Returns an LlmAgent, SequentialAgent, or ParallelAgent.
    """
    if skill.id in skill_cache:
        logger.info(f"Reusing cached skill: {{skill.name}}")
        return skill_cache[skill.id]
    
    if skill.id in visiting_set:
        cycle_path = " -> ".join([str(sid) for sid in visiting_set]) + f" -> {{skill.id}}"
        error_msg = f"Cycle detected in skill hierarchy: {{cycle_path}}"
        logger.error(error_msg)
        raise RuntimeError(error_msg)
    
    visiting_set.add(skill.id)
    logger.info(f"Building skill: {{skill.name}} (exec_mode={{skill.exec_mode.value}})")
    
    try:
        tools = load_tools_for_skill(session, skill.id)
        child_skills = []
        
        if skill.exec_mode == ExecMode.SEQUENTIAL:
            orders = (
                session.query(SequentialSkillExecOrder)
                .filter(SequentialSkillExecOrder.parent_skill_id == skill.id)
                .order_by(SequentialSkillExecOrder.sequence_num)
                .all()
            )
            for order in orders:
                child_skill = session.get(Skill, order.child_skill_id)
                if child_skill:
                    child_agent = build_skill_agent(session, child_skill, skill_cache, visiting_set)
                    child_skills.append(child_agent)
        
        elif skill.exec_mode == ExecMode.PARALLEL:
            skill_relations = (
                session.query(SkillSkill)
                .filter(SkillSkill.parent_skill_id == skill.id)
                .all()
            )
            for relation in skill_relations:
                child_skill = session.get(Skill, relation.child_skill_id)
                if child_skill:
                    child_agent = build_skill_agent(session, child_skill, skill_cache, visiting_set)
                    child_skills.append(child_agent)
        
        else:
            skill_relations = (
                session.query(SkillSkill)
                .filter(SkillSkill.parent_skill_id == skill.id)
                .all()
            )
            for relation in skill_relations:
                child_skill = session.get(Skill, relation.child_skill_id)
                if child_skill:
                    child_agent = build_skill_agent(session, child_skill, skill_cache, visiting_set)
                    child_skills.append(child_agent)
        
        if skill.exec_mode == ExecMode.SEQUENTIAL and child_skills:
            agent = SequentialAgent(
                name=skill.name,
                sub_agents=child_skills,
                description=skill.description or "",
            )
        elif skill.exec_mode == ExecMode.PARALLEL and child_skills:
            agent = ParallelAgent(
                name=skill.name,
                sub_agents=child_skills,
                description=skill.description or "",
            )
        else:
            llm_kwargs = {{
                "name": skill.name,
                "model": LiteLlm(model=skill.default_model),
                "description": skill.description or "",
                "instruction": skill.instructions or "",
                "tools": tools,
                "generate_content_config": _build_generate_content_config(skill)
            }}
            if child_skills:
                llm_kwargs["sub_agents"] = child_skills
            if skill.output_key:
                llm_kwargs["output_key"] = skill.output_key
            agent = LlmAgent(**llm_kwargs)
        
        skill_cache[skill.id] = agent
        logger.info(f"Built skill agent: {{skill.name}} (type={{type(agent).__name__}})")
        return agent
    
    finally:
        visiting_set.discard(skill.id)


def create_agent():
    """Create hierarchical agent from database with support for sequential/parallel execution."""
    session = get_db_manager().get_session()
    try:
        agent = session.get(Agent, UUID(agent_id))
        if not agent:
            raise RuntimeError(f"Agent not found: {{agent_id}}")
        
        logger.info(f"Creating agent: {{agent.name}} (exec_mode={{agent.exec_mode.value}})")
        
        skill_cache = {{}}
        visiting_set = set()
        child_agents = []
        
        if agent.exec_mode == ExecMode.SEQUENTIAL:
            orders = (
                session.query(SequentialAgentExecOrder)
                .filter(SequentialAgentExecOrder.agent_id == agent.id)
                .order_by(SequentialAgentExecOrder.sequence_num)
                .all()
            )
            for order in orders:
                skill = session.get(Skill, order.skill_id)
                if skill:
                    skill_agent = build_skill_agent(session, skill, skill_cache, visiting_set)
                    child_agents.append(skill_agent)
        
        elif agent.exec_mode == ExecMode.PARALLEL:
            links = session.query(AgentSkill).filter(AgentSkill.agent_id == agent.id).all()
            for link in links:
                skill = session.get(Skill, link.skill_id)
                if skill:
                    skill_agent = build_skill_agent(session, skill, skill_cache, visiting_set)
                    child_agents.append(skill_agent)
        
        else:
            links = session.query(AgentSkill).filter(AgentSkill.agent_id == agent.id).all()
            for link in links:
                skill = session.get(Skill, link.skill_id)
                if skill:
                    skill_agent = build_skill_agent(session, skill, skill_cache, visiting_set)
                    child_agents.append(skill_agent)
        
        if agent.exec_mode == ExecMode.SEQUENTIAL:
            root = SequentialAgent(
                name=agent.name,
                sub_agents=child_agents,
                description=agent.description or "",
            )
        elif agent.exec_mode == ExecMode.PARALLEL:
            root = ParallelAgent(
                name=agent.name,
                sub_agents=child_agents,
                description=agent.description or "",
            )
        else:
            llm_kwargs = {{
                "name": agent.name,
                "model": LiteLlm(model=agent.default_model),
                "description": agent.description or "",
                "instruction": agent.instructions or "",
                "generate_content_config": _build_generate_content_config(agent)
            }}
            if child_agents:
                llm_kwargs["sub_agents"] = child_agents
            if agent.output_key:
                llm_kwargs["output_key"] = agent.output_key
            root = LlmAgent(**llm_kwargs)
        
        logger.info(f"Successfully created root agent: {{agent.name}} (type={{type(root).__name__}})")
        logger.info(f"Total unique skills in hierarchy: {{len(skill_cache)}}")
        return root
    
    except RuntimeError as e:
        logger.error(f"Failed to create agent due to cycle: {{e}}")
        raise
    except Exception as e:
        logger.exception(f"Error creating agent: {{e}}")
        raise
    finally:
        session.close()


root_agent = create_agent()
'''


def parse_exec_mode(mode_str: str) -> ExecMode:
    if not mode_str:
        return ExecMode.LLM
    mode_key = str(mode_str).upper()
    try:
        return ExecMode[mode_key]
    except KeyError:
        valid = ", ".join([m.name for m in ExecMode])
        raise ValueError(f"Unknown exec_mode '{mode_str}'. Valid options: {valid}")


def load_yaml_config(config_path: Path, require_agents: bool = True) -> Dict[str, Any]:
    """Parse YAML configuration file into tools, skills and agents."""
    with config_path.open("r", encoding="utf-8") as handle:
        docs = [doc for doc in yaml.safe_load_all(handle) if doc]
    return _parse_yaml_docs(docs, source_name=str(config_path), require_agents=require_agents)


def load_yaml_config_from_string(
    yaml_content: str,
    source_name: str = "yaml",
    require_agents: bool = True,
) -> Dict[str, Any]:
    """Parse YAML string into tools, skills and agents (same structure as load_yaml_config)."""
    docs = [doc for doc in yaml.safe_load_all(io.StringIO(yaml_content)) if doc]
    return _parse_yaml_docs(docs, source_name=source_name, require_agents=require_agents)


def _parse_yaml_docs(
    docs: List[Dict[str, Any]],
    source_name: str = "yaml",
    require_agents: bool = True,
) -> Dict[str, Any]:
    """Build config dict from list of YAML document dicts."""
    if not docs:
        raise ValueError(f"No YAML documents found in {source_name}")
    tools: Dict[str, Dict[str, Any]] = {}
    skills: Dict[str, Dict[str, Any]] = {}
    agents: List[Dict[str, Any]] = []
    for idx, doc in enumerate(docs, start=1):
        if not isinstance(doc, dict):
            raise ValueError(f"Document #{idx} is not a mapping: {doc}")
        raw_kind = str(doc.get("kind", "")).strip().lower()
        if not raw_kind:
            raise ValueError(f"Document #{idx} is missing 'kind'")
        if not raw_kind.startswith("wowbits_"):
            raise ValueError(
                f"Document #{idx} has invalid 'kind': '{raw_kind}'. "
                "Kind must start with 'wowbits_' prefix (e.g., wowbits_tool, wowbits_skill, wowbits_agent)"
            )
        kind = raw_kind.removeprefix("wowbits_")
        name = doc.get("name")
        if not name:
            raise ValueError(f"Document #{idx} ({raw_kind}) is missing 'name'")
        config = doc.get("config", {}) or {}
        if kind == "tool":
            tool_type = doc.get("type", "PYTHON_FUNCTION")
            tool_entry = {"description": doc.get("description", ""), "type": tool_type}
            if tool_type.upper() == "PYTHON_FUNCTION":
                tool_entry["python_function_name"] = doc.get("python_function_name", name)
            elif tool_type.upper() == "MCP_SERVER":
                tool_entry["mcp_config_name"] = doc.get("mcp_config_name")
                tool_entry["url"] = doc.get("url")
                tool_entry["mcp_config"] = doc.get("mcp_config", {})
            tools[name] = tool_entry
        elif kind == "skill":
            exec_mode_str = config.get("exec_mode", "llm")
            exec_mode = parse_exec_mode(exec_mode_str)
            skills[name] = {
                "description": doc.get("description", ""),
                "instructions": doc.get("instructions", ""),
                "default_model": config.get("default_model") or config.get("model") or DEFAULT_MODEL,
                "default_model_config": config.get("default_model_config") or config.get("model_config") or {},
                "temperature": config.get("temperature", 0.2),
                "max_output_tokens": config.get("max_output_tokens", 32000),
                "safety_settings": config.get("safety_settings", []),
                "exec_mode": exec_mode,
                "output_key": config.get("output_key"),
                "tools": doc.get("tools", []) or [],
                "skills": doc.get("skills", []) or [],
            }
        elif kind == "agent":
            exec_mode_str = config.get("exec_mode", "llm")
            exec_mode = parse_exec_mode(exec_mode_str)
            agents.append({
                "name": name,
                "description": doc.get("description", ""),
                "instructions": doc.get("instructions", ""),
                "status": doc.get("status", "ACTIVE"),
                "default_model": config.get("default_model") or config.get("model") or DEFAULT_MODEL,
                "default_model_config": config.get("default_model_config") or config.get("model_config") or {},
                "temperature": config.get("temperature", 0.2),
                "max_output_tokens": config.get("max_output_tokens", 32000),
                "safety_settings": config.get("safety_settings", []),
                "exec_mode": exec_mode,
                "output_key": config.get("output_key"),
                "skills": doc.get("skills", []) or [],
            })
        else:
            raise ValueError(
                f"Unsupported kind '{doc.get('kind')}' in document #{idx}; "
                "only 'wowbits_tool', 'wowbits_skill' and 'wowbits_agent' are supported."
            )
    if require_agents and not agents:
        raise ValueError("At least one 'agent' document is required in the YAML file.")
    return {"tools": tools, "skills": skills, "agents": agents}


def create_agent_from_config(
    session: Any,
    config: Dict[str, Any],
    workspace_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Process parsed config (tools → skills → agents) and persist. Same structure as load_yaml_config output.
    Returns summary dict with created_tools, created_skills, affected_agents.
    """
    created_tools: List[str] = []
    created_skills: List[str] = []
    affected_agents: List[str] = []
    all_tools = config.get("tools", {})
    for tool_name, tool_def in all_tools.items():
        get_or_create_tool(session, tool_name, tool_def)
        created_tools.append(tool_name)
    all_skills = config.get("skills", {})
    skill_registry: Dict[str, Skill] = {}
    for skill_name, skill_config in all_skills.items():
        if skill_name not in skill_registry:
            get_or_create_skill(
                session, skill_name, skill_config, all_skills, skill_registry,
                all_tools, 0, []
            )
            created_skills.append(skill_name)
    for agent_config in config.get("agents", []):
        a = upsert_agent(session, agent_config, skill_registry)
        affected_agents.append(a.name)
    session.commit()
    if workspace_path is not None:
        sync_workspace_from_db(session, workspace_path, affected_agents)
    return {
        "created_tools": created_tools,
        "created_skills": created_skills,
        "affected_agents": affected_agents,
    }


def _ordered_agent_skill_names(session: Any, agent: Agent) -> List[str]:
    if agent.exec_mode == ExecMode.SEQUENTIAL:
        ordered = (
            session.query(SequentialAgentExecOrder)
            .filter(SequentialAgentExecOrder.agent_id == agent.id)
            .order_by(SequentialAgentExecOrder.sequence_num.asc())
            .all()
        )
        if ordered:
            names: List[str] = []
            for row in ordered:
                skill = session.get(Skill, row.skill_id)
                if skill:
                    names.append(skill.name)
            return names
    links = session.query(AgentSkill).filter(AgentSkill.agent_id == agent.id).all()
    names: List[str] = []
    for link in links:
        skill = session.get(Skill, link.skill_id)
        if skill:
            names.append(skill.name)
    return sorted(set(names))


def _ordered_child_skill_names(session: Any, skill: Skill) -> List[str]:
    if skill.exec_mode == ExecMode.SEQUENTIAL:
        ordered = (
            session.query(SequentialSkillExecOrder)
            .filter(SequentialSkillExecOrder.parent_skill_id == skill.id)
            .order_by(SequentialSkillExecOrder.sequence_num.asc())
            .all()
        )
        if ordered:
            names: List[str] = []
            for row in ordered:
                child = session.get(Skill, row.child_skill_id)
                if child:
                    names.append(child.name)
            return names
    links = session.query(SkillSkill).filter(SkillSkill.parent_skill_id == skill.id).all()
    names: List[str] = []
    for link in links:
        child = session.get(Skill, link.child_skill_id)
        if child:
            names.append(child.name)
    return sorted(set(names))


def _ordered_tool_names_for_skill(session: Any, skill: Skill) -> List[str]:
    links = session.query(SkillTool).filter(SkillTool.skill_id == skill.id).all()
    names: List[str] = []
    for link in links:
        tool = session.get(Tool, link.tool_id)
        if tool:
            names.append(tool.name)
    return sorted(set(names))


def _collect_skill_names_for_agent(session: Any, agent: Agent) -> Set[str]:
    collected: Set[str] = set()

    def _visit_skill(skill_name: str) -> None:
        if skill_name in collected:
            return
        skill = session.query(Skill).filter(Skill.name == skill_name).first()
        if not skill:
            return
        collected.add(skill_name)
        for child_name in _ordered_child_skill_names(session, skill):
            _visit_skill(child_name)

    for skill_name in _ordered_agent_skill_names(session, agent):
        _visit_skill(skill_name)
    return collected


def _tool_doc_from_db(tool: Tool, session: Any) -> Dict[str, Any]:
    doc: Dict[str, Any] = {
        "kind": "wowbits_tool",
        "name": tool.name,
        "description": tool.description or "",
        "type": tool.type.name if tool.type else "PYTHON_FUNCTION",
    }
    if tool.type == ToolType.PYTHON_FUNCTION:
        pf = session.get(PythonFunction, tool.python_function_id) if tool.python_function_id else None
        doc["python_function_name"] = pf.name if pf else tool.name
    elif tool.type == ToolType.MCP_SERVER:
        mcp = session.get(MCPConfig, tool.mcp_config_id) if tool.mcp_config_id else None
        doc["mcp_config_name"] = mcp.name if mcp else tool.name
        if mcp and mcp.url:
            doc["url"] = mcp.url
        if mcp and mcp.config is not None:
            doc["mcp_config"] = mcp.config
    return doc


def _skill_doc_from_db(skill: Skill, session: Any) -> Dict[str, Any]:
    return {
        "kind": "wowbits_skill",
        "name": skill.name,
        "description": skill.description or "",
        "instructions": skill.instructions or "",
        "tools": _ordered_tool_names_for_skill(session, skill),
        "skills": _ordered_child_skill_names(session, skill),
        "config": {
            "default_model": skill.default_model or DEFAULT_MODEL,
            "default_model_config": skill.default_model_config or {},
            "temperature": skill.temperature if skill.temperature is not None else 0.2,
            "max_output_tokens": skill.max_output_tokens if skill.max_output_tokens is not None else 32000,
            "safety_settings": skill.safety_settings or [],
            "exec_mode": skill.exec_mode.value if skill.exec_mode else ExecMode.LLM.value,
            "output_key": skill.output_key,
        },
    }


def _agent_doc_from_db(agent: Agent, session: Any) -> Dict[str, Any]:
    return {
        "kind": "wowbits_agent",
        "name": agent.name,
        "description": agent.description or "",
        "instructions": agent.instructions or "",
        "status": agent.status.value if agent.status else AgentStatus.ACTIVE.value,
        "skills": _ordered_agent_skill_names(session, agent),
        "config": {
            "default_model": agent.default_model or DEFAULT_MODEL,
            "default_model_config": agent.default_model_config or {},
            "temperature": agent.temperature if agent.temperature is not None else 0.2,
            "max_output_tokens": agent.max_output_tokens if agent.max_output_tokens is not None else 32000,
            "safety_settings": agent.safety_settings or [],
            "exec_mode": agent.exec_mode.value if agent.exec_mode else ExecMode.LLM.value,
            "output_key": agent.output_key,
        },
    }


def _ensure_workspace_layout(workspace_path: Path) -> None:
    (workspace_path / "agent_studio").mkdir(parents=True, exist_ok=True)
    functions_dir = workspace_path / "functions"
    functions_dir.mkdir(parents=True, exist_ok=True)
    init_file = functions_dir / "__init__.py"
    if not init_file.exists():
        init_file.write_text("", encoding="utf-8")
    (workspace_path / "agent_runner").mkdir(parents=True, exist_ok=True)


def _sync_functions_to_workspace(session: Any, workspace_path: Path) -> None:
    functions_dir = workspace_path / "functions"
    functions_dir.mkdir(parents=True, exist_ok=True)
    db_functions = session.query(PythonFunction).all()
    db_names = {f.name for f in db_functions}

    for py in functions_dir.glob("*.py"):
        if py.name == "__init__.py":
            continue
        if py.stem not in db_names:
            py.unlink(missing_ok=True)

    for fn in db_functions:
        (functions_dir / f"{fn.name}.py").write_text(fn.code or "", encoding="utf-8")


def _write_agent_yaml_from_db(session: Any, workspace_path: Path, agent_name: str) -> None:
    agent = session.query(Agent).filter(Agent.name == agent_name).first()
    if not agent:
        return

    skill_names = _collect_skill_names_for_agent(session, agent)
    tool_names: Set[str] = set()
    for skill_name in skill_names:
        skill = session.query(Skill).filter(Skill.name == skill_name).first()
        if not skill:
            continue
        for tname in _ordered_tool_names_for_skill(session, skill):
            tool_names.add(tname)

    docs: List[Dict[str, Any]] = []
    for tool_name in sorted(tool_names):
        tool = session.query(Tool).filter(Tool.name == tool_name).first()
        if tool:
            docs.append(_tool_doc_from_db(tool, session))

    for skill_name in sorted(skill_names):
        skill = session.query(Skill).filter(Skill.name == skill_name).first()
        if skill:
            docs.append(_skill_doc_from_db(skill, session))

    docs.append(_agent_doc_from_db(agent, session))

    yaml_path = workspace_path / "agent_studio" / f"{agent_name}.yaml"
    yaml_path.write_text(yaml.safe_dump_all(docs, sort_keys=False, allow_unicode=True), encoding="utf-8")


def sync_workspace_from_db(session: Any, workspace_path: Path, agent_names: Optional[List[str]] = None) -> None:
    _ensure_workspace_layout(workspace_path)
    _sync_functions_to_workspace(session, workspace_path)

    if agent_names is None:
        targets = [a.name for a in session.query(Agent).all()]
    else:
        targets = agent_names

    for agent_name in targets:
        _write_agent_yaml_from_db(session, workspace_path, agent_name)


def remove_agent_yaml(workspace_path: Path, agent_name: str) -> None:
    yaml_path = workspace_path / "agent_studio" / f"{agent_name}.yaml"
    yaml_path.unlink(missing_ok=True)


def get_or_create_tool(session: Any, tool_name: str, tool_def: Dict[str, Any]) -> Tool:
    """Create or update a Tool from YAML definition. Raises ValueError if refs not found."""
    type_str = str(tool_def.get("type")).upper()
    try:
        tool_type = ToolType[type_str]
    except KeyError:
        valid = ", ".join([m.name for m in ToolType])
        raise ValueError(f"Unknown tool type '{type_str}'. Valid: {valid}")
    description = tool_def.get("description") or f"{tool_name} tool"
    python_function_id = None
    mcp_config_id = None
    if tool_type == ToolType.PYTHON_FUNCTION:
        function_name = tool_def.get("python_function_name") or tool_name
        pf = session.query(PythonFunction).filter(PythonFunction.name == function_name).first()
        if not pf:
            raise ValueError(
                f"Python function '{function_name}' not found. Run function sync first."
            )
        python_function_id = pf.id
    elif tool_type == ToolType.MCP_SERVER:
        mcp_name = tool_def.get("mcp_config_name") or tool_name
        cfg = session.query(MCPConfig).filter(MCPConfig.name == mcp_name).first()
        if not cfg:
            raise ValueError(f"MCP config '{mcp_name}' not found. Create MCP first.")
        mcp_config_id = cfg.id
    tool = session.query(Tool).filter(Tool.name == tool_name).first()
    if not tool:
        tool = Tool(
            id=uuid4(),
            name=tool_name,
            description=description,
            type=tool_type,
            python_function_id=python_function_id,
            mcp_config_id=mcp_config_id,
        )
        session.add(tool)
    else:
        tool.description = description
        tool.type = tool_type
        tool.python_function_id = python_function_id
        tool.mcp_config_id = mcp_config_id
    session.flush()
    return tool


def get_or_create_skill(
    session: Any,
    skill_name: str,
    skill_config: Dict[str, Any],
    all_skills: Dict[str, Dict[str, Any]],
    skill_registry: Dict[str, Skill],
    all_tools: Optional[Dict[str, Dict[str, Any]]] = None,
    depth: int = 0,
    visiting_path: Optional[List[str]] = None,
) -> Skill:
    """Recursively upsert a skill and children. Raises ValueError on cycle."""
    if visiting_path is None:
        visiting_path = []
    if skill_name in visiting_path:
        cycle = " -> ".join(visiting_path) + f" -> {skill_name}"
        raise ValueError(f"Cycle detected in skill hierarchy: {cycle}")
    if skill_name in skill_registry:
        return skill_registry[skill_name]
    skill = session.query(Skill).filter(Skill.name == skill_name).first()
    standard_fields = {
        "description": skill_config.get("description", ""),
        "instructions": skill_config.get("instructions", ""),
        "default_model": skill_config.get("default_model", DEFAULT_MODEL),
        "default_model_config": skill_config.get("default_model_config", {}),
        "temperature": skill_config.get("temperature", 0.2),
        "max_output_tokens": skill_config.get("max_output_tokens", 32000),
        "safety_settings": skill_config.get("safety_settings", []),
        "exec_mode": skill_config.get("exec_mode", ExecMode.LLM),
        "output_key": skill_config.get("output_key"),
    }
    if not skill:
        skill = Skill(id=uuid4(), name=skill_name, **standard_fields)
        session.add(skill)
    else:
        for k, v in standard_fields.items():
            setattr(skill, k, v)
    session.flush()
    skill_registry[skill_name] = skill
    session.query(SkillTool).filter(SkillTool.skill_id == skill.id).delete(synchronize_session=False)
    tools = skill_config.get("tools", []) or []
    all_tools = all_tools or {}
    for tname in tools:
        tdef = all_tools.get(tname)
        if tdef:
            tool = get_or_create_tool(session, tname, tdef)
        else:
            tool = session.query(Tool).filter(Tool.name == tname).first()
            if not tool:
                raise ValueError(f"Tool '{tname}' referenced by skill '{skill_name}' not found.")
        session.add(SkillTool(skill_id=skill.id, tool_id=tool.id))
    child_skill_names = skill_config.get("skills", []) or []
    if child_skill_names:
        exec_mode = skill_config.get("exec_mode", ExecMode.LLM)
        session.query(SequentialSkillExecOrder).filter(
            SequentialSkillExecOrder.parent_skill_id == skill.id
        ).delete(synchronize_session=False)
        session.query(SkillSkill).filter(SkillSkill.parent_skill_id == skill.id).delete(synchronize_session=False)
        visiting_path.append(skill_name)
        try:
            for idx, child_name in enumerate(child_skill_names, start=1):
                if child_name not in all_skills:
                    continue
                child_skill = get_or_create_skill(
                    session, child_name, all_skills[child_name], all_skills, skill_registry,
                    all_tools, depth + 1, visiting_path.copy()
                )
                session.add(SkillSkill(id=uuid4(), parent_skill_id=skill.id, child_skill_id=child_skill.id))
                if exec_mode == ExecMode.SEQUENTIAL:
                    session.add(SequentialSkillExecOrder(
                        id=uuid4(), parent_skill_id=skill.id, child_skill_id=child_skill.id, sequence_num=idx
                    ))
        finally:
            visiting_path.pop()
    session.flush()
    return skill


def coerce_agent_status(status_value: Any) -> AgentStatus:
    if isinstance(status_value, AgentStatus):
        return status_value
    if not status_value:
        return AgentStatus.ACTIVE
    try:
        return AgentStatus[str(status_value).upper()]
    except KeyError as exc:
        valid = ", ".join([m.name for m in AgentStatus])
        raise ValueError(f"Unknown agent status '{status_value}'. Valid: {valid}") from exc


def upsert_agent(session: Any, agent_config: Dict[str, Any], skill_registry: Dict[str, Skill]) -> Agent:
    """Create or update agent and skill associations."""
    agent_name = agent_config["name"]
    agent = session.query(Agent).filter(Agent.name == agent_name).first()
    standard_fields = {
        "description": agent_config.get("description", ""),
        "instructions": agent_config.get("instructions", ""),
        "status": coerce_agent_status(agent_config.get("status")),
        "default_model": agent_config.get("default_model", DEFAULT_MODEL),
        "default_model_config": agent_config.get("default_model_config", {}),
        "temperature": agent_config.get("temperature", 0.2),
        "max_output_tokens": agent_config.get("max_output_tokens", 32000),
        "safety_settings": agent_config.get("safety_settings", []),
        "exec_mode": agent_config.get("exec_mode", ExecMode.LLM),
        "output_key": agent_config.get("output_key"),
    }
    if not agent:
        agent = Agent(id=uuid4(), name=agent_name, **standard_fields)
        session.add(agent)
    else:
        for k, v in standard_fields.items():
            setattr(agent, k, v)
    session.flush()
    session.query(AgentSkill).filter(AgentSkill.agent_id == agent.id).delete(synchronize_session=False)
    session.query(SequentialAgentExecOrder).filter(
        SequentialAgentExecOrder.agent_id == agent.id
    ).delete(synchronize_session=False)
    exec_mode = agent_config.get("exec_mode", ExecMode.LLM)
    skill_names = agent_config.get("skills", [])
    for idx, skill_name in enumerate(skill_names, start=1):
        skill = skill_registry.get(skill_name) or session.query(Skill).filter(Skill.name == skill_name).first()
        if not skill:
            raise ValueError(f"Skill '{skill_name}' referenced by agent '{agent_name}' not found.")
        session.add(AgentSkill(agent_id=agent.id, skill_id=skill.id))
        if exec_mode == ExecMode.SEQUENTIAL:
            session.add(SequentialAgentExecOrder(
                id=uuid4(), agent_id=agent.id, skill_id=skill.id, sequence_num=idx
            ))
    session.flush()
    return agent


def create_agent_from_yaml(
    session: Any,
    workspace_path: Path,
    agent_name: str,
    config_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Load YAML from config_path or workspace_path/agent_studio/<agent_name>.yaml,
    process tools → skills → agents, commit. Returns summary.
    """
    yaml_path = config_path or (workspace_path / "agent_studio" / f"{agent_name}.yaml")
    if not yaml_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {yaml_path}")
    config = load_yaml_config(yaml_path)
    return create_agent_from_config(session, config, workspace_path=workspace_path)


def list_agents(session: Any) -> List[Dict[str, Any]]:
    """List all agents as dicts."""
    agents = session.query(Agent).all()
    return [
        {
            "id": str(a.id),
            "name": a.name,
            "status": a.status.value if a.status else None,
            "exec_mode": a.exec_mode.value if a.exec_mode else None,
            "description": a.description or "",
        }
        for a in agents
    ]


class AgentsPuller(GitHubPuller):
    def __init__(self):
        super().__init__(
            resource_type="agents",
            dir_name="agent_studio",
            file_extension=".yaml",
            exclude_files=[]
        )

    def upsert_resource(self, session: Any, name: str, content: str) -> Tuple[int, int]:
        """Create agent from YAML content. Returns (created, updated)."""
        try:
            config = load_yaml_config_from_string(
                content,
                source_name=name,
                require_agents=False,
            )
            if not config.get("agents"):
                return 0, 0
            existing_names = {
                row[0]
                for row in session.query(Agent.name)
                .filter(Agent.name.in_([a.get("name") for a in config.get("agents", []) if a.get("name")]))
                .all()
            }
            summary = create_agent_from_config(session, config, workspace_path=None)
            affected_agents = summary.get("affected_agents", [])
            created_count = sum(1 for name in affected_agents if name not in existing_names)
            updated_count = max(0, len(affected_agents) - created_count)
            return created_count, updated_count
        except ValueError:
            return 0, 0


def _merge_pull_config(target: Dict[str, Any], incoming: Dict[str, Any]) -> None:
    target.setdefault("tools", {}).update(incoming.get("tools", {}))
    target.setdefault("skills", {}).update(incoming.get("skills", {}))
    target.setdefault("agents", [])
    target["agents"].extend(incoming.get("agents", []))


def _collect_repo_agent_studio_config(repo_url: str) -> Dict[str, Any]:
    parsed = parse_github_url(repo_url)
    if not parsed:
        return {"tools": {}, "skills": {}, "agents": []}

    owner, repo, branch = parsed
    repo_config: Dict[str, Any] = {"tools": {}, "skills": {}, "agents": []}
    items = list_github_dir(owner, repo, branch, "agent_studio")
    if not items:
        items = list_github_dir(owner, repo, branch, "")

    for item in items:
        if item.get("type") != "file":
            continue
        filename = item.get("name", "")
        if not filename.endswith(".yaml"):
            continue
        path = item.get("path") or f"agent_studio/{filename}"
        content = fetch_raw_content(owner, repo, branch, path)
        if not content:
            continue
        try:
            parsed_cfg = load_yaml_config_from_string(
                content,
                source_name=path,
                require_agents=False,
            )
            _merge_pull_config(repo_config, parsed_cfg)
        except ValueError:
            continue
    return repo_config


def _resolve_agent_dependencies(
    base_config: Dict[str, Any],
    repo_config: Dict[str, Any],
) -> Tuple[Dict[str, Any], Dict[str, List[str]]]:
    resolved = {
        "tools": dict(base_config.get("tools", {})),
        "skills": dict(base_config.get("skills", {})),
        "agents": list(base_config.get("agents", [])),
    }

    repo_skills = repo_config.get("skills", {})
    repo_tools = repo_config.get("tools", {})

    queue: List[str] = []
    for agent in resolved.get("agents", []):
        queue.extend(agent.get("skills", []) or [])

    seen_skills: Set[str] = set()
    required_tools: Set[str] = set()
    added_skills: Set[str] = set()
    added_tools: Set[str] = set()
    missing_skills: Set[str] = set()
    missing_tools: Set[str] = set()

    while queue:
        skill_name = queue.pop(0)
        if not skill_name or skill_name in seen_skills:
            continue
        seen_skills.add(skill_name)

        skill_def = resolved["skills"].get(skill_name)
        if not skill_def:
            skill_def = repo_skills.get(skill_name)
            if skill_def:
                resolved["skills"][skill_name] = skill_def
                added_skills.add(skill_name)
            else:
                missing_skills.add(skill_name)
                continue

        for child_skill in skill_def.get("skills", []) or []:
            if child_skill not in seen_skills:
                queue.append(child_skill)
        for tool_name in skill_def.get("tools", []) or []:
            if tool_name:
                required_tools.add(tool_name)

    for tool_name in sorted(required_tools):
        if tool_name in resolved["tools"]:
            continue
        tool_def = repo_tools.get(tool_name)
        if tool_def:
            resolved["tools"][tool_name] = tool_def
            added_tools.add(tool_name)
        else:
            missing_tools.add(tool_name)

    meta = {
        "skills_added": sorted(added_skills),
        "tools_added": sorted(added_tools),
        "missing_skills": sorted(missing_skills),
        "missing_tools": sorted(missing_tools),
    }
    return resolved, meta


def _required_python_functions_from_tools(tools_config: Dict[str, Dict[str, Any]]) -> Set[str]:
    required: Set[str] = set()
    for tool_name, tool_def in (tools_config or {}).items():
        type_str = str((tool_def or {}).get("type", "")).upper()
        if type_str != ToolType.PYTHON_FUNCTION.name:
            continue
        fn_name = (tool_def or {}).get("python_function_name") or tool_name
        if fn_name:
            required.add(fn_name)
    return required


def _required_mcps_from_tools(tools_config: Dict[str, Dict[str, Any]]) -> Set[str]:
    required: Set[str] = set()
    for tool_name, tool_def in (tools_config or {}).items():
        type_str = str((tool_def or {}).get("type", "")).upper()
        if type_str != ToolType.MCP_SERVER.name:
            continue
        mcp_name = (tool_def or {}).get("mcp_config_name") or tool_name
        if mcp_name:
            required.add(mcp_name)
    return required


def pull_agents_from_repo(
    session: Any,
    workspace_path: Path,
    repo_url: str,
    agent_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Fetch .yaml files from GitHub, create agents from them.
    agent_names: None or [] or ["*"] = pull all. Else list of names.
    Returns {"created": N, "updated": M, "files": [names], "error": optional}.
    """
    puller = AgentsPuller()
    result = puller.pull_from_repo(workspace_path, repo_url, agent_names)

    # Parse pulled files first (selected agents)
    agent_studio_dir = workspace_path / "agent_studio"
    selected_config: Dict[str, Any] = {"tools": {}, "skills": {}, "agents": []}

    for file_name in result["files"]:
        file_path = agent_studio_dir / file_name
        if file_path.exists():
            content = file_path.read_text(encoding="utf-8")
            try:
                parsed_cfg = load_yaml_config_from_string(
                    content,
                    source_name=file_name,
                    require_agents=False,
                )
                _merge_pull_config(selected_config, parsed_cfg)
            except ValueError:
                continue

    if not selected_config.get("agents"):
        result["created"] = 0
        result["updated"] = 0
        result["dependencies"] = {
            "skills_added": [],
            "tools_added": [],
            "missing_skills": [],
            "missing_tools": [],
        }
        return result

    repo_config = _collect_repo_agent_studio_config(repo_url)
    final_config, dependency_meta = _resolve_agent_dependencies(selected_config, repo_config)

    # Dependency order for agent pull (bottom-up): functions -> mcps -> skills/tools -> agents
    required_functions = _required_python_functions_from_tools(final_config.get("tools", {}))
    function_pull = {"created": 0, "updated": 0, "files": []}
    missing_functions: List[str] = []
    if required_functions:
        function_pull = core_functions.pull_functions_from_repo(
            session,
            workspace_path,
            repo_url,
            function_names=sorted(required_functions),
        )
        present_functions = {
            row[0]
            for row in session.query(PythonFunction.name)
            .filter(PythonFunction.name.in_(sorted(required_functions)))
            .all()
        }
        missing_functions = sorted(required_functions - present_functions)
        if missing_functions:
            raise ValueError(
                "Missing required Python functions for pulled agent(s): "
                + ", ".join(missing_functions)
                + ". Ensure these functions exist in repo/functions or sync functions first."
            )

    required_mcps = _required_mcps_from_tools(final_config.get("tools", {}))
    mcp_pull = {"created": 0, "updated": 0, "files": []}
    missing_mcps: List[str] = []
    if required_mcps:
        mcp_pull = core_mcp.pull_mcps_from_repo(
            session,
            workspace_path,
            repo_url,
            mcp_names=sorted(required_mcps),
        )
        present_mcps = {
            row[0]
            for row in session.query(MCPConfig.name)
            .filter(MCPConfig.name.in_(sorted(required_mcps)))
            .all()
        }
        missing_mcps = sorted(required_mcps - present_mcps)
        if missing_mcps:
            raise ValueError(
                "Missing required MCP configs for pulled agent(s): "
                + ", ".join(missing_mcps)
                + ". Ensure these MCPs exist in repo/mcps or create MCP first."
            )

    target_agent_names = [a.get("name") for a in final_config.get("agents", []) if a.get("name")]
    existing_names = {
        row[0]
        for row in session.query(Agent.name)
        .filter(Agent.name.in_(target_agent_names))
        .all()
    }

    summary = create_agent_from_config(session, final_config, workspace_path=workspace_path)
    affected = summary.get("affected_agents", [])
    created = sum(1 for name in affected if name not in existing_names)
    updated = max(0, len(affected) - created)

    result["created"] = created
    result["updated"] = updated
    dependency_meta["mcps_pulled"] = sorted(
        (Path(f).parts[0] for f in mcp_pull.get("files", []) if f)
    )
    dependency_meta["missing_mcps"] = missing_mcps
    dependency_meta["functions_pulled"] = sorted(
        (Path(f).stem for f in function_pull.get("files", []))
    )
    dependency_meta["missing_functions"] = missing_functions
    result["dependencies"] = dependency_meta
    return result


def get_agent(session: Any, id_or_name: str) -> Optional[Dict[str, Any]]:
    """Get agent by id (UUID) or name. Returns dict or None."""
    try:
        uid = UUID(id_or_name)
        agent = session.query(Agent).filter(Agent.id == uid).first()
    except ValueError:
        agent = session.query(Agent).filter(Agent.name == id_or_name).first()
    if not agent:
        return None
    return _agent_to_dict(agent)


def _agent_to_dict(a: Agent) -> Dict[str, Any]:
    return {
        "id": str(a.id),
        "name": a.name,
        "description": a.description or "",
        "instructions": a.instructions or "",
        "status": a.status.value if a.status else None,
        "default_model": a.default_model or "",
        "default_model_config": a.default_model_config or {},
        "temperature": a.temperature,
        "max_output_tokens": a.max_output_tokens,
        "safety_settings": a.safety_settings or [],
        "exec_mode": a.exec_mode.value if a.exec_mode else None,
        "output_key": a.output_key,
    }


def update_agent(
    session: Any,
    id_or_name: str,
    workspace_path: Optional[Path] = None,
    name: Optional[str] = None,
    description: Optional[str] = None,
    instructions: Optional[str] = None,
    status: Optional[str] = None,
    default_model: Optional[str] = None,
    default_model_config: Optional[Dict] = None,
    temperature: Optional[float] = None,
    max_output_tokens: Optional[int] = None,
    safety_settings: Optional[List] = None,
    exec_mode: Optional[str] = None,
    output_key: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Update agent by id or name. Returns updated dict or None if not found."""
    try:
        uid = UUID(id_or_name)
        agent = session.query(Agent).filter(Agent.id == uid).first()
    except ValueError:
        agent = session.query(Agent).filter(Agent.name == id_or_name).first()
    if not agent:
        return None
    old_name = agent.name
    if name is not None:
        if name != agent.name and session.query(Agent).filter(Agent.name == name).first():
            raise ValueError(f"Agent name '{name}' already exists")
        agent.name = name
    if description is not None:
        agent.description = description
    if instructions is not None:
        agent.instructions = instructions
    if status is not None:
        agent.status = coerce_agent_status(status)
    if default_model is not None:
        agent.default_model = default_model
    if default_model_config is not None:
        agent.default_model_config = default_model_config
    if temperature is not None:
        agent.temperature = temperature
    if max_output_tokens is not None:
        agent.max_output_tokens = max_output_tokens
    if safety_settings is not None:
        agent.safety_settings = safety_settings
    if exec_mode is not None:
        agent.exec_mode = parse_exec_mode(exec_mode)
    if output_key is not None:
        agent.output_key = output_key
    session.flush()
    if workspace_path is not None:
        if old_name != agent.name:
            remove_agent_yaml(workspace_path, old_name)
        sync_workspace_from_db(session, workspace_path, [agent.name])
    return _agent_to_dict(agent)


def delete_agent(session: Any, id_or_name: str, workspace_path: Optional[Path] = None) -> bool:
    """Delete agent by id or name. Returns True if deleted."""
    try:
        uid = UUID(id_or_name)
        agent = session.query(Agent).filter(Agent.id == uid).first()
    except ValueError:
        agent = session.query(Agent).filter(Agent.name == id_or_name).first()
    if not agent:
        return False
    deleted_name = agent.name
    session.delete(agent)
    session.flush()
    if workspace_path is not None:
        remove_agent_yaml(workspace_path, deleted_name)
        sync_workspace_from_db(session, workspace_path)
    return True


def _sanitize_folder_name(name: str) -> str:
    safe = re.sub(r"[^\w\s-]", "", name)
    safe = re.sub(r"[-\s]+", "_", safe).lower().strip("_")
    return safe or "unnamed_agent"


def create_agent_code(agent_id: str, agent_name: str, agent_runner_path: Path) -> Path:
    """Write agent.py into agent_runner_path/<sanitized_name>/."""
    folder_name = _sanitize_folder_name(agent_name)
    agent_folder = agent_runner_path / folder_name
    agent_folder.mkdir(parents=True, exist_ok=True)
    (agent_folder / "agent.py").write_text(AGENT_CODE_TEMPLATE.format(agent_id=agent_id))
    return agent_folder


def _is_process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _is_port_open(host: str, port: int, timeout: float = 0.5) -> bool:
    connect_host = "127.0.0.1" if host in ("0.0.0.0", "::") else host
    family = socket.AF_INET6 if ":" in connect_host else socket.AF_INET
    try:
        with socket.socket(family, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            return sock.connect_ex((connect_host, port)) == 0
    except OSError:
        return False


def _adk_server_has_agent(host: str, port: int, agent_name: str, timeout: float = 30.0) -> bool:
    connect_host = "127.0.0.1" if host in ("0.0.0.0", "::") else host
    try:
        req = Request(f"http://{connect_host}:{port}/list-apps", method="GET")
        with urlopen(req, timeout=timeout) as resp:
            if resp.getcode() != 200:
                return False
            body = resp.read().decode("utf-8", errors="ignore")
            return agent_name in body
    except (URLError, OSError, ValueError):
        return False


def _find_next_free_port(host: str, start_port: int, max_tries: int = 100) -> Optional[int]:
    for candidate in range(start_port, start_port + max_tries):
        if not _is_port_open(host, candidate):
            return candidate
    return None


def _tail_file(path: Path, max_lines: int = 20) -> str:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-max_lines:])
    except Exception:
        return ""


def _default_adk_session_uri(workspace_path: Path, folder_name: str) -> str:
    sessions_dir = workspace_path / ".wowbits-adk-sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    session_db = sessions_dir / f"{folder_name}.db"
    return f"sqlite:///{str(session_db)}"


def run_agent(
    workspace_path: Path,
    agent_name: str,
    exec_mode: str = "web",
    host: str = "0.0.0.0",
    port: int = 5151,
) -> Dict[str, Any]:
    """
    Ensure agent exists, generate code, start adk web or api_server in background.
    Returns {"agent_folder": str, "host": str, "port": int}. Raises on error.
    Process is started in background (Popen).
    Validates startup by waiting until the requested port is reachable.
    """
    if exec_mode not in ("web", "api"):
        raise ValueError(f"exec_mode must be 'web' or 'api', got '{exec_mode}'")
    agent_runner_path = workspace_path / "agent_runner"
    agent_runner_path.mkdir(parents=True, exist_ok=True)
    with get_session_context() as session:
        agent = session.query(Agent).filter(Agent.name == agent_name).first()
        if not agent:
            raise ValueError(f"Agent '{agent_name}' not found")
        agent_folder = create_agent_code(str(agent.id), agent.name, agent_runner_path)
    folder_name = _sanitize_folder_name(agent_name)
    legacy_pid_file = workspace_path / f".wowbits-agent-{folder_name}.pid"
    legacy_log_file = workspace_path / f".wowbits-agent-{folder_name}.log"
    agent_logs_dir = workspace_path / "logs" / "agents"
    agent_logs_dir.mkdir(parents=True, exist_ok=True)
    pid_file = agent_logs_dir / f"{folder_name}.pid"
    log_file = agent_logs_dir / f"{folder_name}.log"
    if legacy_pid_file.exists() and not pid_file.exists():
        try:
            legacy_pid_file.replace(pid_file)
        except OSError:
            pass
    if legacy_log_file.exists() and not log_file.exists():
        try:
            legacy_log_file.replace(log_file)
        except OSError:
            pass
    if pid_file.exists():
        try:
            existing_pid = int(pid_file.read_text().strip())
            if _is_process_alive(existing_pid):
                if _is_port_open(host, port):
                    return {
                        "agent_folder": str(agent_folder),
                        "host": host,
                        "port": port,
                        "pid": existing_pid,
                        "log_file": str(log_file),
                        "already_running": True,
                    }
                try:
                    os.kill(existing_pid, signal.SIGTERM)
                except OSError:
                    pass
            pid_file.unlink(missing_ok=True)
        except (ValueError, OSError):
            pid_file.unlink(missing_ok=True)

    if _is_port_open(host, port):
        if _adk_server_has_agent(host, port, agent_name):
            return {
                "agent_folder": str(agent_folder),
                "host": host,
                "port": port,
                "pid": None,
                "log_file": str(log_file),
                "already_running": True,
                "external": True,
            }
        next_port = _find_next_free_port(host, port + 1)
        if next_port is None:
            raise ValueError(
                f"Port {port} is already in use on host {host}, and no free fallback port was found. "
                "Stop the existing ADK process or run with a different --port."
            )
        port = next_port

    adk_session_service_uri = os.environ.get("WOWBITS_ADK_SESSION_SERVICE_URI")
    if not adk_session_service_uri:
        adk_session_service_uri = _default_adk_session_uri(workspace_path, folder_name)
    cmd = ["adk", "web", "--host", host, "--port", str(port)] if exec_mode == "web" else ["adk", "api_server", "--host", host, "--port", str(port)]
    if adk_session_service_uri:
        cmd.extend(["--session_service_uri", adk_session_service_uri])
    with open(log_file, "a", encoding="utf-8") as log_handle:
        proc = subprocess.Popen(
            cmd,
            cwd=str(agent_runner_path),
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )

    deadline = time.monotonic() + 15.0
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            tail = _tail_file(log_file)
            raise ValueError(
                f"Agent process exited during startup. Log: {log_file}\n{tail}"
            )
        if _is_port_open(host, port):
            pid_file.write_text(str(proc.pid))
            return {
                "agent_folder": str(agent_folder),
                "host": host,
                "port": port,
                "pid": proc.pid,
                "log_file": str(log_file),
            }
        time.sleep(0.5)

    try:
        os.kill(proc.pid, signal.SIGTERM)
    except OSError:
        pass
    tail = _tail_file(log_file)
    raise ValueError(
        f"Agent server did not become reachable on {host}:{port} in time. Log: {log_file}\n{tail}"
    )


def stop_agent(workspace_path: Path, agent_name: str) -> Dict[str, Any]:
    """Stop a running agent process tracked by pid file."""
    folder_name = _sanitize_folder_name(agent_name)
    agent_logs_dir = workspace_path / "logs" / "agents"
    pid_file = agent_logs_dir / f"{folder_name}.pid"
    legacy_pid_file = workspace_path / f".wowbits-agent-{folder_name}.pid"
    if not pid_file.exists() and legacy_pid_file.exists():
        pid_file = legacy_pid_file
    if not pid_file.exists():
        raise ValueError(
            f"No running agent '{agent_name}' found for this workspace (missing {pid_file.name})."
        )

    try:
        pid = int(pid_file.read_text().strip())
    except (ValueError, OSError):
        pid_file.unlink(missing_ok=True)
        raise ValueError(f"Invalid or stale PID file removed: {pid_file}")

    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pid_file.unlink(missing_ok=True)
        return {
            "status": "not_running",
            "agent": agent_name,
            "pid": pid,
            "message": "Process already exited; stale PID file removed",
        }
    except OSError as e:
        raise ValueError(f"Could not stop agent '{agent_name}' (PID {pid}): {e}")

    pid_file.unlink(missing_ok=True)
    return {"status": "stopped", "agent": agent_name, "pid": pid}
