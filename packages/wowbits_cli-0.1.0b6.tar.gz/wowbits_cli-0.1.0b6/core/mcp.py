"""
MCP service - load config from YAML, create in DB, run subprocess. Uses workspace path.
"""
import json
import os
import signal
import subprocess
import sys
import textwrap
from pathlib import Path
from typing import Any, Dict, Optional
from uuid import UUID

import yaml

from db.schema import MCPConfig
from pylibs.pull import GitHubPuller
from sqlalchemy.orm import Session

WOWBITS_YAML_FILENAME = "config.yaml"
MCP_CONFIG_KIND = "wowbits_mcp_config"


def _default_mcp_config_yaml(mcp_name: str) -> str:
    content = {
        "kind": MCP_CONFIG_KIND,
        "config": {
            "name": mcp_name,
            "url": "http://localhost:8931",
            "config": {
                "transport_mode": "http",
            },
        },
    }
    return yaml.safe_dump(content, sort_keys=False)


def _default_mcp_config_json(mcp_name: str) -> str:
    content = {
        "name": mcp_name,
        "server": {
            "host": "localhost",
            "port": 8931,
        },
        "transport": "http",
    }
    return json.dumps(content, indent=2) + "\n"


def _default_mcp_setup_py() -> str:
    return textwrap.dedent(
        """\
        if __name__ == "__main__":
            print("MCP setup complete")
        """
    )


def _default_mcp_run_py() -> str:
    return textwrap.dedent(
        """\
        import time
        from pathlib import Path


        if __name__ == "__main__":
            config_path = Path(__file__).with_name("config.json")
            print(f"Starting MCP placeholder server using {config_path}", flush=True)
            while True:
                time.sleep(60)
        """
    )


def _write_if_missing(path: Path, content: str) -> None:
    if not path.exists():
        path.write_text(content, encoding="utf-8")


def ensure_mcp_scaffold(
    workspace_path: Path,
    mcp_name: str,
    config_yaml_content: Optional[str] = None,
    config_json_content: Optional[str] = None,
    setup_py_content: Optional[str] = None,
    run_py_content: Optional[str] = None,
) -> Path:
    """
    Ensure workspace/mcps/<mcp_name>/ exists with baseline files:
    config.yaml, config.json, setup.py, run.py.
    Existing files are preserved.
    """
    mcps_dir = get_mcps_dir(workspace_path)
    mcps_dir.mkdir(parents=True, exist_ok=True)

    mcp_dir = mcps_dir / mcp_name
    mcp_dir.mkdir(parents=True, exist_ok=True)

    _write_if_missing(
        mcp_dir / "config.yaml",
        config_yaml_content if config_yaml_content is not None else _default_mcp_config_yaml(mcp_name),
    )
    _write_if_missing(
        mcp_dir / "config.json",
        config_json_content if config_json_content is not None else _default_mcp_config_json(mcp_name),
    )
    _write_if_missing(
        mcp_dir / "setup.py",
        setup_py_content if setup_py_content is not None else _default_mcp_setup_py(),
    )
    _write_if_missing(
        mcp_dir / "run.py",
        run_py_content if run_py_content is not None else _default_mcp_run_py(),
    )

    return mcp_dir


def list_mcps(session: Session) -> list:
    """List all MCP configs."""
    mcps = session.query(MCPConfig).all()
    return [{"id": str(m.id), "name": m.name, "url": m.url, "config": m.config or {}} for m in mcps]


def get_mcp(session: Session, id_or_name: str) -> Optional[Dict[str, Any]]:
    """Get MCP config by id or name."""
    try:
        uid = UUID(id_or_name)
        mcp = session.query(MCPConfig).filter(MCPConfig.id == uid).first()
    except ValueError:
        mcp = session.query(MCPConfig).filter(MCPConfig.name == id_or_name).first()
    if not mcp:
        return None
    return {"id": str(mcp.id), "name": mcp.name, "url": mcp.url, "config": mcp.config or {}}


def get_mcps_dir(workspace_path: Path) -> Path:
    return workspace_path / "mcps"


def load_mcp_config_from_yaml(mcp_dir: Path) -> Dict[str, Any]:
    """Load MCP config from mcp_dir/config.yaml. Raises FileNotFoundError/ValueError."""
    config_path = mcp_dir / WOWBITS_YAML_FILENAME
    if not config_path.exists():
        raise FileNotFoundError(f"MCP config file not found: {config_path}")
    with open(config_path, "r") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError(f"{WOWBITS_YAML_FILENAME} must be a YAML object")
    if data.get("kind") != MCP_CONFIG_KIND:
        raise ValueError(
            f"{WOWBITS_YAML_FILENAME} must have kind: {MCP_CONFIG_KIND!r}, got {data.get('kind')!r}"
        )
    config = data.get("config")
    if not isinstance(config, dict):
        raise ValueError(f"{WOWBITS_YAML_FILENAME} must have a 'config' object")
    return config


def create_mcp(
    session: Session,
    workspace_path: Path,
    mcp_name: str,
    config_yaml_content: Optional[str] = None,
    config_json_content: Optional[str] = None,
    setup_py_content: Optional[str] = None,
    run_py_content: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Ensure workspace_path/mcps/<mcp_name>/ scaffold exists, then load config.yaml
    and insert into mcp_configs. Returns {"name": str, "id": str}.
    Existing DB records are returned unchanged (idempotent).
    """
    mcp_dir = ensure_mcp_scaffold(
        workspace_path,
        mcp_name,
        config_yaml_content=config_yaml_content,
        config_json_content=config_json_content,
        setup_py_content=setup_py_content,
        run_py_content=run_py_content,
    )
    entry = load_mcp_config_from_yaml(mcp_dir)
    name = entry.get("name")
    if not name:
        raise ValueError("MCP config has no 'name' field")
    url = entry.get("url")
    config = entry.get("config")
    if config is None:
        config = {}
    existing = session.query(MCPConfig).filter(MCPConfig.name == name).first()
    if existing:
        return {"name": name, "id": str(existing.id)}
    mcp = MCPConfig(name=name, url=url, config=config)
    session.add(mcp)
    session.flush()
    return {"name": name, "id": str(mcp.id)}


def update_mcp(
    session: Session,
    id_or_name: str,
    name: Optional[str] = None,
    url: Optional[str] = None,
    config: Optional[Dict] = None,
) -> Optional[Dict[str, Any]]:
    """Update MCP config by id or name."""
    try:
        uid = UUID(id_or_name)
        mcp = session.query(MCPConfig).filter(MCPConfig.id == uid).first()
    except ValueError:
        mcp = session.query(MCPConfig).filter(MCPConfig.name == id_or_name).first()
    if not mcp:
        return None
    if name is not None:
        if name != mcp.name and session.query(MCPConfig).filter(MCPConfig.name == name).first():
            raise ValueError(f"MCP name '{name}' already exists")
        mcp.name = name
    if url is not None:
        mcp.url = url
    if config is not None:
        mcp.config = config
    session.flush()
    return get_mcp(session, str(mcp.id))


def delete_mcp(session: Session, id_or_name: str) -> bool:
    """Delete MCP config by id or name."""
    try:
        uid = UUID(id_or_name)
        mcp = session.query(MCPConfig).filter(MCPConfig.id == uid).first()
    except ValueError:
        mcp = session.query(MCPConfig).filter(MCPConfig.name == id_or_name).first()
    if not mcp:
        return False
    session.delete(mcp)
    return True


def _is_process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def run_mcp(workspace_path: Path, mcp_name: str) -> Dict[str, Any]:
    """
    Start setup.py then run.py in workspace_path/mcps/<mcp_name>/ in background.
    Raises FileNotFoundError if dir/setup.py/run.py missing.
    """
    mcp_dir = get_mcps_dir(workspace_path) / mcp_name
    if not mcp_dir.is_dir():
        raise FileNotFoundError(f"MCP directory not found: {mcp_dir}")
    folder_name = mcp_name.replace("/", "_").replace(" ", "_")
    legacy_pid_file = workspace_path / f".wowbits-mcp-{folder_name}.pid"
    legacy_log_file = workspace_path / f".wowbits-mcp-{folder_name}.log"
    mcp_logs_dir = workspace_path / "logs" / "mcps"
    mcp_logs_dir.mkdir(parents=True, exist_ok=True)
    pid_file = mcp_logs_dir / f"{folder_name}.pid"
    log_file = mcp_logs_dir / f"{folder_name}.log"
    if legacy_pid_file.exists() and not pid_file.exists():
        try:
            legacy_pid_file.replace(pid_file)
        except OSError:
            pass
    if legacy_log_file.exists() and not log_file.exists():
        try:
            legacy_log_file.replace(log_file)
        except OSError:
            pass
    if pid_file.exists():
        try:
            existing_pid = int(pid_file.read_text().strip())
            if _is_process_alive(existing_pid):
                return {
                    "status": "already_running",
                    "mcp": mcp_name,
                    "pid": existing_pid,
                    "log_file": str(log_file),
                }
            pid_file.unlink(missing_ok=True)
        except (ValueError, OSError):
            pid_file.unlink(missing_ok=True)

    setup_py = mcp_dir / "setup.py"
    run_py = mcp_dir / "run.py"
    if not setup_py.exists():
        raise FileNotFoundError(f"setup.py not found in {mcp_dir}")
    if not run_py.exists():
        raise FileNotFoundError(f"run.py not found in {mcp_dir}")
    env = os.environ.copy()
    cwd = str(mcp_dir)
    subprocess.run(
        [sys.executable, str(setup_py)],
        cwd=cwd,
        env=env,
        check=True,
    )
    with open(log_file, "a", encoding="utf-8") as log_handle:
        proc = subprocess.Popen(
            [sys.executable, str(run_py)],
            cwd=cwd,
            env=env,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    pid_file.write_text(str(proc.pid))
    return {"status": "started", "mcp": mcp_name, "pid": proc.pid, "log_file": str(log_file)}


def stop_mcp(workspace_path: Path, mcp_name: str) -> Dict[str, Any]:
    """Stop a running MCP process tracked by pid file."""
    folder_name = mcp_name.replace("/", "_").replace(" ", "_")
    mcp_logs_dir = workspace_path / "logs" / "mcps"
    pid_file = mcp_logs_dir / f"{folder_name}.pid"
    legacy_pid_file = workspace_path / f".wowbits-mcp-{folder_name}.pid"
    if not pid_file.exists() and legacy_pid_file.exists():
        pid_file = legacy_pid_file
    if not pid_file.exists():
        raise ValueError(
            f"No running MCP '{mcp_name}' found for this workspace (missing {pid_file.name})."
        )

    try:
        pid = int(pid_file.read_text().strip())
    except (ValueError, OSError):
        pid_file.unlink(missing_ok=True)
        raise ValueError(f"Invalid or stale PID file removed: {pid_file}")

    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pid_file.unlink(missing_ok=True)
        return {
            "status": "not_running",
            "mcp": mcp_name,
            "pid": pid,
            "message": "Process already exited; stale PID file removed",
        }
    except OSError as e:
        raise ValueError(f"Could not stop MCP '{mcp_name}' (PID {pid}): {e}")

    pid_file.unlink(missing_ok=True)
    return {"status": "stopped", "mcp": mcp_name, "pid": pid}


class MCPsPuller(GitHubPuller):
    """Pull MCP configs from GitHub."""

    def __init__(self):
        super().__init__("mcps", "mcps", ".yaml")

    def pull_from_repo(self, workspace_path: Path, repo_url: str,
                      resource_names: Optional[list[str]] = None) -> Dict[str, Any]:
        """
        Pull MCP configs from GitHub repo.
        MCPs are stored as mcps/<name>/config.yaml in both repo and workspace.
        """
        from pylibs.pull import parse_github_url, list_github_dir, fetch_raw_content

        parsed = parse_github_url(repo_url)
        if not parsed:
            raise ValueError("Unsupported repo URL. Use a GitHub URL (e.g. https://github.com/owner/repo)")

        owner, repo, branch = parsed
        dest_dir = workspace_path / self.dir_name
        dest_dir.mkdir(parents=True, exist_ok=True)

        pull_all = (
            resource_names is None
            or len(resource_names) == 0
            or (len(resource_names) == 1 and resource_names[0].strip() == "*")
        )

        if pull_all:
            # List directories in mcps/
            items = list_github_dir(owner, repo, branch, self.dir_name)
            names_to_pull = []
            for item in items:
                if item.get("type") == "dir":
                    # Check if config.yaml exists in this directory
                    config_items = list_github_dir(owner, repo, branch, f"{self.dir_name}/{item['name']}")
                    if any(ci.get("name") == "config.yaml" for ci in config_items):
                        names_to_pull.append(item["name"])
        else:
            names_to_pull = [n.strip() for n in resource_names if n.strip()]

        if not names_to_pull:
            return {"created": 0, "updated": 0, "files": []}

        files = []
        for name in names_to_pull:
            content = fetch_raw_content(owner, repo, branch, f"{self.dir_name}/{name}/config.yaml")
            if content is None:
                continue

            # Create the subdirectory
            mcp_dir = dest_dir / name
            mcp_dir.mkdir(exist_ok=True)

            # Write config.yaml
            config_path = mcp_dir / "config.yaml"
            config_path.write_text(content, encoding="utf-8")
            files.append(f"{name}/config.yaml")

        return {"created": 0, "updated": 0, "files": files}

    def upsert_resource(self, session: Session, name: str, content: str) -> tuple[int, int]:
        """Create or update MCP from YAML content. Returns (created, updated)."""
        try:
            config = yaml.safe_load(content)
            if not isinstance(config, dict):
                raise ValueError("MCP config must be a YAML object")
        except Exception as e:
            raise ValueError(f"Invalid YAML in {name}/config.yaml: {e}")

        existing = session.query(MCPConfig).filter(MCPConfig.name == name).first()
        if existing:
            existing.config = config
            # Use flush, not commit — we're inside an outer transaction managed by the router
            session.flush()
            return 0, 1
        else:
            mcp = MCPConfig(
                name=name,
                url=config.get("url", ""),
                config=config
            )
            session.add(mcp)
            session.flush()
            return 1, 0


def pull_mcps_from_repo(
    session: Session,
    workspace_path: Path,
    repo_url: str,
    mcp_names: Optional[list[str]] = None,
) -> Dict[str, Any]:
    """
    Pull MCP configs from GitHub repo.

    Args:
        session: DB session
        workspace_path: Path to workspace
        repo_url: GitHub repo URL
        mcp_names: None or [] or ["*"] = pull all. Else list of names.

    Returns:
        {"created": N, "updated": M, "files": [names], "error": optional}
    """
    puller = MCPsPuller()
    result = puller.pull_from_repo(workspace_path, repo_url, mcp_names)

    # Now create MCPs from the pulled files
    mcps_dir = get_mcps_dir(workspace_path)
    created = 0
    updated = 0

    for file_path in result.get("files", []):
        if file_path.endswith("/config.yaml"):
            mcp_name = file_path.split("/")[0]  # Extract name from "name/config.yaml"
            config_path = mcps_dir / file_path
            if config_path.exists():
                try:
                    with open(config_path, "r", encoding="utf-8") as f:
                        content = f.read()
                    c, u = puller.upsert_resource(session, mcp_name, content)
                    created += c
                    updated += u
                except Exception as e:
                    result["error"] = f"Failed to create MCP '{mcp_name}': {e}"
                    break

    result["created"] = created
    result["updated"] = updated
    # Ensure all upserted rows are visible to follow-on queries in the same transaction
    session.flush()
    return result
