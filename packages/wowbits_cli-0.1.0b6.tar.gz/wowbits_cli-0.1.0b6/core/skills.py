"""
Skills service - list, get, create, update, delete, and pull from GitHub.
"""
from pathlib import Path
from typing import Any, Dict, List, Optional, Set
from uuid import UUID, uuid4

from sqlalchemy.orm import Session

from db.schema import ExecMode, Skill
from pylibs.pull import parse_github_url, list_github_dir, fetch_raw_content
from core import agents as core_agents
from core import functions as core_functions
from core import mcp as core_mcp


def list_skills(session: Session) -> List[Dict[str, Any]]:
    """List all skills."""
    skills = session.query(Skill).all()
    return [_skill_to_dict(s) for s in skills]


def get_skill(session: Session, id_or_name: str) -> Optional[Dict[str, Any]]:
    """Get skill by id or name."""
    try:
        uid = UUID(id_or_name)
        skill = session.query(Skill).filter(Skill.id == uid).first()
    except ValueError:
        skill = session.query(Skill).filter(Skill.name == id_or_name).first()
    return _skill_to_dict(skill) if skill else None


def _skill_to_dict(s: Skill) -> Dict[str, Any]:
    return {
        "id": str(s.id),
        "name": s.name,
        "description": s.description or "",
        "instructions": s.instructions or "",
        "default_model": s.default_model or "",
        "default_model_config": s.default_model_config or {},
        "temperature": s.temperature,
        "max_output_tokens": s.max_output_tokens,
        "safety_settings": s.safety_settings or [],
        "exec_mode": s.exec_mode.value if s.exec_mode else None,
        "output_key": s.output_key,
    }


def _parse_exec_mode(v: Optional[str]) -> ExecMode:
    if not v:
        return ExecMode.LLM
    try:
        return ExecMode[str(v).upper()]
    except KeyError:
        valid = ", ".join([m.name for m in ExecMode])
        raise ValueError(f"Unknown exec_mode '{v}'. Valid: {valid}")


def create_skill(
    session: Session,
    name: str,
    description: str = "",
    instructions: str = "",
    default_model: str = "gpt-4.1",
    default_model_config: Optional[Dict] = None,
    temperature: float = 0.2,
    max_output_tokens: int = 32000,
    safety_settings: Optional[List] = None,
    exec_mode: str = "llm",
    output_key: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a skill."""
    if session.query(Skill).filter(Skill.name == name).first():
        raise ValueError(f"Skill '{name}' already exists")
    skill = Skill(
        id=uuid4(),
        name=name,
        description=description,
        instructions=instructions,
        default_model=default_model,
        default_model_config=default_model_config or {},
        temperature=temperature,
        max_output_tokens=max_output_tokens,
        safety_settings=safety_settings or [],
        exec_mode=_parse_exec_mode(exec_mode),
        output_key=output_key,
    )
    session.add(skill)
    session.flush()
    return _skill_to_dict(skill)


def update_skill(
    session: Session,
    id_or_name: str,
    name: Optional[str] = None,
    description: Optional[str] = None,
    instructions: Optional[str] = None,
    default_model: Optional[str] = None,
    default_model_config: Optional[Dict] = None,
    temperature: Optional[float] = None,
    max_output_tokens: Optional[int] = None,
    safety_settings: Optional[List] = None,
    exec_mode: Optional[str] = None,
    output_key: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Update skill by id or name."""
    try:
        uid = UUID(id_or_name)
        skill = session.query(Skill).filter(Skill.id == uid).first()
    except ValueError:
        skill = session.query(Skill).filter(Skill.name == id_or_name).first()
    if not skill:
        return None
    if name is not None:
        if name != skill.name and session.query(Skill).filter(Skill.name == name).first():
            raise ValueError(f"Skill name '{name}' already exists")
        skill.name = name
    if description is not None:
        skill.description = description
    if instructions is not None:
        skill.instructions = instructions
    if default_model is not None:
        skill.default_model = default_model
    if default_model_config is not None:
        skill.default_model_config = default_model_config
    if temperature is not None:
        skill.temperature = temperature
    if max_output_tokens is not None:
        skill.max_output_tokens = max_output_tokens
    if safety_settings is not None:
        skill.safety_settings = safety_settings
    if exec_mode is not None:
        skill.exec_mode = _parse_exec_mode(exec_mode)
    if output_key is not None:
        skill.output_key = output_key
    session.flush()
    return _skill_to_dict(skill)


def delete_skill(session: Session, id_or_name: str) -> bool:
    """Delete skill by id or name."""
    try:
        uid = UUID(id_or_name)
        skill = session.query(Skill).filter(Skill.id == uid).first()
    except ValueError:
        skill = session.query(Skill).filter(Skill.name == id_or_name).first()
    if not skill:
        return False
    session.delete(skill)
    return True


def _merge_pull_config(target: Dict[str, Any], incoming: Dict[str, Any]) -> None:
    target.setdefault("tools", {}).update(incoming.get("tools", {}))
    target.setdefault("skills", {}).update(incoming.get("skills", {}))
    target.setdefault("agents", [])
    target["agents"].extend(incoming.get("agents", []))


def pull_skills_from_repo(
    session: Session,
    workspace_path: Path,
    repo_url: str,
    skill_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Pull skills from GitHub and ensure referenced tools are also pulled.
    Supports pulling all skills or selected names.
    """
    parsed = parse_github_url(repo_url)
    if not parsed:
        raise ValueError("Unsupported repo URL. Use a GitHub URL (e.g. https://github.com/owner/repo)")

    owner, repo, branch = parsed
    items = list_github_dir(owner, repo, branch, "agent_studio")
    if not items:
        items = list_github_dir(owner, repo, branch, "")

    repo_config: Dict[str, Any] = {"tools": {}, "skills": {}, "agents": []}
    file_contents: Dict[str, str] = {}
    skill_source_file: Dict[str, str] = {}
    tool_source_file: Dict[str, str] = {}

    for item in items:
        if item.get("type") != "file":
            continue
        filename = item.get("name", "")
        if not filename.endswith(".yaml"):
            continue
        path = item.get("path") or f"agent_studio/{filename}"
        content = fetch_raw_content(owner, repo, branch, path)
        if not content:
            continue
        try:
            parsed_cfg = core_agents.load_yaml_config_from_string(
                content,
                source_name=path,
                require_agents=False,
            )
        except ValueError:
            continue

        _merge_pull_config(repo_config, parsed_cfg)
        file_contents[filename] = content
        for skill_name in parsed_cfg.get("skills", {}).keys():
            skill_source_file.setdefault(skill_name, filename)
        for tool_name in parsed_cfg.get("tools", {}).keys():
            tool_source_file.setdefault(tool_name, filename)

    if (
        skill_names is None
        or len(skill_names) == 0
        or (len(skill_names) == 1 and skill_names[0].strip() == "*")
    ):
        target_skills = sorted(repo_config.get("skills", {}).keys())
    else:
        target_skills = sorted({name.strip() for name in skill_names if name and name.strip()})

    selected_skills: Dict[str, Dict[str, Any]] = {}
    selected_tools: Dict[str, Dict[str, Any]] = {}
    files_used: Set[str] = set()
    missing_skills: Set[str] = set()
    missing_tools: Set[str] = set()

    queue = list(target_skills)
    seen: Set[str] = set()
    required_tools: Set[str] = set()

    while queue:
        skill_name = queue.pop(0)
        if not skill_name or skill_name in seen:
            continue
        seen.add(skill_name)

        skill_def = repo_config.get("skills", {}).get(skill_name)
        if not skill_def:
            missing_skills.add(skill_name)
            continue

        selected_skills[skill_name] = skill_def
        if skill_name in skill_source_file:
            files_used.add(skill_source_file[skill_name])

        for child_name in skill_def.get("skills", []) or []:
            if child_name not in seen:
                queue.append(child_name)
        for tool_name in skill_def.get("tools", []) or []:
            if tool_name:
                required_tools.add(tool_name)

    for tool_name in sorted(required_tools):
        tool_def = repo_config.get("tools", {}).get(tool_name)
        if not tool_def:
            missing_tools.add(tool_name)
            continue
        selected_tools[tool_name] = tool_def
        if tool_name in tool_source_file:
            files_used.add(tool_source_file[tool_name])

    required_functions: Set[str] = set()
    required_mcps: Set[str] = set()
    for tool_name, tool_def in selected_tools.items():
        type_str = str((tool_def or {}).get("type", "")).upper()
        if type_str == "PYTHON_FUNCTION":
            fn_name = (tool_def or {}).get("python_function_name") or tool_name
            if fn_name:
                required_functions.add(fn_name)
            continue
        if type_str == "MCP_SERVER":
            mcp_name = (tool_def or {}).get("mcp_config_name") or tool_name
            if mcp_name:
                required_mcps.add(mcp_name)
            continue

    files_written: List[str] = []
    agent_studio_dir = workspace_path / "agent_studio"
    agent_studio_dir.mkdir(parents=True, exist_ok=True)
    for filename in sorted(files_used):
        content = file_contents.get(filename)
        if content is None:
            continue
        (agent_studio_dir / filename).write_text(content, encoding="utf-8")
        files_written.append(filename)

    function_pull = {"created": 0, "updated": 0, "files": []}
    mcp_pull = {"created": 0, "updated": 0, "files": []}
    missing_functions: List[str] = []
    missing_mcps: List[str] = []

    # Dependency order for skill pull (bottom-up): functions -> mcps -> skills/tools
    if required_functions:
        function_pull = core_functions.pull_functions_from_repo(
            session,
            workspace_path,
            repo_url,
            function_names=sorted(required_functions),
        )
        from db.schema import PythonFunction
        present_functions = {
            row[0]
            for row in session.query(PythonFunction.name)
            .filter(PythonFunction.name.in_(sorted(required_functions)))
            .all()
        }
        missing_functions = sorted(required_functions - present_functions)
        if missing_functions:
            raise ValueError(
                "Missing required Python functions for pulled skill(s): "
                + ", ".join(missing_functions)
                + ". Ensure these functions exist in repo/functions or sync functions first."
            )

    if required_mcps:
        mcp_pull = core_mcp.pull_mcps_from_repo(
            session,
            workspace_path,
            repo_url,
            mcp_names=sorted(required_mcps),
        )
        from db.schema import MCPConfig
        present_mcps = {
            row[0]
            for row in session.query(MCPConfig.name)
            .filter(MCPConfig.name.in_(sorted(required_mcps)))
            .all()
        }
        missing_mcps = sorted(required_mcps - present_mcps)
        if missing_mcps:
            raise ValueError(
                "Missing required MCP configs for pulled skill(s): "
                + ", ".join(missing_mcps)
                + ". Ensure these MCPs exist in repo/mcps or create MCP first."
            )

    before_skills = {row[0] for row in session.query(Skill.name).all()}
    if selected_skills:
        core_agents.create_agent_from_config(
            session,
            {"tools": selected_tools, "skills": selected_skills, "agents": []},
            workspace_path=None,
        )
    after_skills = {row[0] for row in session.query(Skill.name).all()}

    created = len(after_skills - before_skills)
    updated = max(0, len(selected_skills) - created)

    return {
        "created": created,
        "updated": updated,
        "files": files_written,
        "dependencies": {
            "skills_pulled": sorted(selected_skills.keys()),
            "tools_pulled": sorted(selected_tools.keys()),
            "mcps_pulled": sorted({Path(f).parts[0] for f in mcp_pull.get("files", []) if f}),
            "functions_pulled": sorted(Path(f).stem for f in function_pull.get("files", [])),
            "missing_skills": sorted(missing_skills),
            "missing_tools": sorted(missing_tools),
            "missing_mcps": missing_mcps,
            "missing_functions": missing_functions,
        },
    }
