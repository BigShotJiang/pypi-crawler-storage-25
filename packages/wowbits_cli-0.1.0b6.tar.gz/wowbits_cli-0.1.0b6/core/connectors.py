"""
Connector service - CRUD for connectors. No I/O beyond DB.
"""
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from db.schema import Connector, ConnectorStatus


def _providers_path() -> Path:
    return Path(__file__).parent / "data" / "providers.json"


def load_providers() -> Dict[str, Any]:
    """Load provider definitions from core data."""
    path = _providers_path()
    with open(path, "r") as f:
        return json.load(f)


def list_connectors(session: Session) -> List[Dict[str, Any]]:
    """List all connectors."""
    connectors = session.query(Connector).order_by(Connector.created_at.desc()).all()
    return [_connector_to_dict(c) for c in connectors]


def get_connector(session: Session, name: str) -> Optional[Dict[str, Any]]:
    """Get connector by name."""
    connector = session.query(Connector).filter(Connector.name == name).first()
    return _connector_to_dict(connector) if connector else None


def get_connector_by_id(session: Session, connector_id: str) -> Optional[Dict[str, Any]]:
    """Get connector by ID."""
    try:
        parsed_id = uuid.UUID(connector_id)
    except ValueError:
        return None
    connector = session.query(Connector).filter(Connector.id == parsed_id).first()
    return _connector_to_dict(connector) if connector else None


def create_connector(
    session: Session,
    name: str,
    provider: str,
    config: Optional[Dict[str, Any]] = None,
    status: str = "ACTIVE",
) -> Dict[str, Any]:
    """Create a new connector."""
    existing = session.query(Connector).filter(Connector.name == name).first()
    if existing:
        raise ValueError(f"Connector '{name}' already exists")
    connector = Connector(
        name=name,
        provider=provider,
        config=config or {},
        status=ConnectorStatus[status],
    )
    session.add(connector)
    session.flush()
    return _connector_to_dict(connector)


def update_connector(
    session: Session,
    connector_id: str,
    name: Optional[str] = None,
    provider: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    status: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Update an existing connector by ID."""
    try:
        parsed_id = uuid.UUID(connector_id)
    except ValueError:
        raise ValueError(f"Invalid ID format: '{connector_id}'")
    connector = session.query(Connector).filter(Connector.id == parsed_id).first()
    if not connector:
        return None
    if name and name != connector.name:
        if session.query(Connector).filter(Connector.name == name).first():
            raise ValueError(f"Connector '{name}' already exists")
        connector.name = name
    if provider:
        connector.provider = provider
    if config is not None:
        connector.config = config
    if status:
        connector.status = ConnectorStatus[status]
    connector.updated_at = datetime.now(timezone.utc)
    session.flush()
    return _connector_to_dict(connector)


def delete_connector(session: Session, connector_id: str) -> bool:
    """Delete connector by ID."""
    try:
        parsed_id = uuid.UUID(connector_id)
    except ValueError:
        raise ValueError(f"Invalid ID format: '{connector_id}'")
    connector = session.query(Connector).filter(Connector.id == parsed_id).first()
    if not connector:
        return False
    session.delete(connector)
    return True


def delete_connector_by_name(session: Session, name: str) -> Optional[str]:
    """Delete connector by name. Returns deleted ID or None."""
    connector = session.query(Connector).filter(Connector.name == name).first()
    if not connector:
        return None
    cid = str(connector.id)
    session.delete(connector)
    return cid


def _connector_to_dict(connector: Connector) -> Dict[str, Any]:
    return {
        "id": str(connector.id),
        "name": connector.name,
        "provider": connector.provider,
        "config": connector.config or {},
        "status": connector.status.value if connector.status else "ACTIVE",
        "created_at": connector.created_at.isoformat() if connector.created_at else None,
        "updated_at": connector.updated_at.isoformat() if connector.updated_at else None,
    }
