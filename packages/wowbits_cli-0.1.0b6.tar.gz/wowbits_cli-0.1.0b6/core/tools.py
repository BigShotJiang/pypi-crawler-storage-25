"""
Tools service - list, get, create, update, delete. Direct DB.
"""
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from sqlalchemy.orm import Session

from db.schema import MCPConfig, PythonFunction, Tool, ToolType


def list_tools(session: Session) -> List[Dict[str, Any]]:
    """List all tools."""
    tools = session.query(Tool).all()
    return [_tool_to_dict(t) for t in tools]


def get_tool(session: Session, id_or_name: str) -> Optional[Dict[str, Any]]:
    """Get tool by id or name."""
    try:
        uid = UUID(id_or_name)
        tool = session.query(Tool).filter(Tool.id == uid).first()
    except ValueError:
        tool = session.query(Tool).filter(Tool.name == id_or_name).first()
    return _tool_to_dict(tool) if tool else None


def _tool_to_dict(t: Tool) -> Dict[str, Any]:
    return {
        "id": str(t.id),
        "name": t.name,
        "description": t.description or "",
        "type": t.type.value if t.type else None,
        "python_function_id": str(t.python_function_id) if t.python_function_id else None,
        "mcp_config_id": str(t.mcp_config_id) if t.mcp_config_id else None,
    }


def create_tool(
    session: Session,
    name: str,
    type: str,
    description: str = "",
    python_function_name: Optional[str] = None,
    mcp_config_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Create a tool. type: PYTHON_FUNCTION | MCP_SERVER. For PYTHON_FUNCTION pass python_function_name; for MCP_SERVER pass mcp_config_name."""
    if session.query(Tool).filter(Tool.name == name).first():
        raise ValueError(f"Tool '{name}' already exists")
    try:
        tool_type = ToolType[type.upper()]
    except KeyError:
        valid = ", ".join([m.name for m in ToolType])
        raise ValueError(f"Unknown tool type '{type}'. Valid: {valid}")
    pf_id = None
    mcp_id = None
    if tool_type == ToolType.PYTHON_FUNCTION:
        fn_name = python_function_name or name
        pf = session.query(PythonFunction).filter(PythonFunction.name == fn_name).first()
        if not pf:
            raise ValueError(f"Python function '{fn_name}' not found")
        pf_id = pf.id
    elif tool_type == ToolType.MCP_SERVER:
        mcp_name = mcp_config_name or name
        mcp = session.query(MCPConfig).filter(MCPConfig.name == mcp_name).first()
        if not mcp:
            raise ValueError(f"MCP config '{mcp_name}' not found")
        mcp_id = mcp.id
    tool = Tool(
        id=uuid4(),
        name=name,
        description=description or f"{name} tool",
        type=tool_type,
        python_function_id=pf_id,
        mcp_config_id=mcp_id,
    )
    session.add(tool)
    session.flush()
    return _tool_to_dict(tool)


def update_tool(
    session: Session,
    id_or_name: str,
    name: Optional[str] = None,
    description: Optional[str] = None,
    type: Optional[str] = None,
    python_function_name: Optional[str] = None,
    mcp_config_name: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Update tool by id or name."""
    try:
        uid = UUID(id_or_name)
        tool = session.query(Tool).filter(Tool.id == uid).first()
    except ValueError:
        tool = session.query(Tool).filter(Tool.name == id_or_name).first()
    if not tool:
        return None
    if name is not None:
        if name != tool.name and session.query(Tool).filter(Tool.name == name).first():
            raise ValueError(f"Tool name '{name}' already exists")
        tool.name = name
    if description is not None:
        tool.description = description
    if type is not None:
        try:
            tool.type = ToolType[type.upper()]
        except KeyError:
            valid = ", ".join([m.name for m in ToolType])
            raise ValueError(f"Unknown tool type '{type}'. Valid: {valid}")
    if python_function_name is not None and tool.type == ToolType.PYTHON_FUNCTION:
        pf = session.query(PythonFunction).filter(PythonFunction.name == python_function_name).first()
        if not pf:
            raise ValueError(f"Python function '{python_function_name}' not found")
        tool.python_function_id = pf.id
    if mcp_config_name is not None and tool.type == ToolType.MCP_SERVER:
        mcp = session.query(MCPConfig).filter(MCPConfig.name == mcp_config_name).first()
        if not mcp:
            raise ValueError(f"MCP config '{mcp_config_name}' not found")
        tool.mcp_config_id = mcp.id
    session.flush()
    return _tool_to_dict(tool)


def delete_tool(session: Session, id_or_name: str) -> bool:
    """Delete tool by id or name."""
    try:
        uid = UUID(id_or_name)
        tool = session.query(Tool).filter(Tool.id == uid).first()
    except ValueError:
        tool = session.query(Tool).filter(Tool.name == id_or_name).first()
    if not tool:
        return False
    session.delete(tool)
    return True
