#!/usr/bin/env python3
"""
WowBits CLI - MCP (thin client).

All MCP operations go through the API. This module only:
- create: POST /mcps with {name} (API scaffolds workspace/mcps/<name>/ and persists config)
- start: POST /mcps/{name}/start (API runs setup.py and run.py in workspace)
- stop: POST /mcps/{name}/stop
"""

import sys
from pathlib import Path

# Ensure src is on path when run as script
import os
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cli import api_client


def create_mcp(mcp_name: str) -> None:
    """Create MCP via API (server scaffolds workspace/mcps/<mcp_name>/)."""
    r = api_client.post("/mcps", {"name": mcp_name})
    print("✅ MCP created:", r)


def start_mcp(mcp_name: str) -> None:
    """Start MCP via API (server runs setup.py then run.py in workspace/mcps/<mcp_name>/)."""
    r = api_client.post(f"/mcps/{mcp_name}/start")
    print("✅ MCP started:", r)


def stop_mcp(mcp_name: str) -> None:
    """Stop MCP via API."""
    r = api_client.post(f"/mcps/{mcp_name}/stop")
    print("✅ MCP stopped:", r)


def pull_mcps(repo_url: str, mcp_names: list = None) -> None:
    """Pull MCPs from GitHub repo via API."""
    body = {"repo_url": repo_url}
    if mcp_names:
        body["mcp_names"] = mcp_names
    r = api_client.post("/mcps/pull", body)
    print("✅ Pull complete:", r)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="MCP commands (via WowBits API)")
    sub = parser.add_subparsers(dest="action", help="Action")
    create_p = sub.add_parser("create", help="Create MCP and scaffold workspace/mcps/<name>/ files")
    create_p.add_argument("name", metavar="mcp_name", help="MCP name")
    start_p = sub.add_parser("start", help="Start MCP server")
    start_p.add_argument("name", metavar="mcp_name", help="MCP name")
    stop_p = sub.add_parser("stop", help="Stop MCP server")
    stop_p.add_argument("name", metavar="mcp_name", help="MCP name")
    run_p = sub.add_parser("run", help="(Deprecated) Alias for start")
    run_p.add_argument("name", metavar="mcp_name", help="MCP name")
    args = parser.parse_args()
    try:
        api_client.get_base_url()
    except Exception as e:
        print(f"❌ {e}")
        sys.exit(1)
    if args.action == "create":
        create_mcp(args.name)
    elif args.action in ("start", "run"):
        start_mcp(args.name)
    elif args.action == "stop":
        stop_mcp(args.name)
    else:
        parser.print_help()
