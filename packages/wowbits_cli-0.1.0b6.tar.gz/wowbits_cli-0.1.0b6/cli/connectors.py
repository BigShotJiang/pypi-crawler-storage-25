#!/usr/bin/env python3
"""
WowBits CLI - Connectors (thin client). All operations via API.
"""
import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from cli import api_client


def get_providers() -> Dict[str, Any]:
    return api_client.get("/connectors/providers") or {}


def list_connectors() -> None:
    r = api_client.get("/connectors") or []
    if not r:
        print("No connectors.")
        return
    for c in r:
        print(f"{c.get('id')}\t{c.get('name')}\t{c.get('provider')}\t{c.get('status')}")


def print_providers() -> None:
    p = get_providers()
    for pid, info in (p or {}).items():
        desc = info.get("description", "") if isinstance(info, dict) else ""
        print(f"  {pid}\t{desc}")


def create_connector(provider: str, config: str) -> None:
    config_dict = json.loads(config) if config else {}
    p = get_providers()
    name = (p.get(provider) or {}).get("name", provider) if isinstance(p, dict) else provider
    r = api_client.post("/connectors", {"name": name, "provider": provider, "config": config_dict})
    print("✅ Connector created:", r.get("id"))


def update_connector(name: str, config: str) -> None:
    r = api_client.patch(f"/connectors/{name}", {"config": json.loads(config)})
    print("✅ Connector updated:", r.get("id"))


def delete_connector(name: str) -> None:
    r = api_client.delete(f"/connectors/{name}")
    print("✅ Deleted:", r.get("deleted"))


def get_connector_config(connector_name: str) -> Optional[Dict[str, Any]]:
    try:
        r = api_client.get(f"/connectors/{connector_name}")
        return r.get("config") if r else None
    except Exception:
        return None


def get_api_key(connector_name: str) -> Optional[str]:
    c = get_connector_config(connector_name)
    return (c.get("api_key") or c.get("apiKey") or c.get("key")) if c else None


def main() -> None:
    parser = argparse.ArgumentParser(description="Connectors (via API)")
    sub = parser.add_subparsers(dest="action")
    sub.add_parser("list", help="List connectors")
    sub.add_parser("providers", help="List providers")
    c = sub.add_parser("create", help="Create connector")
    c.add_argument("--provider", "-p", required=True)
    c.add_argument("--config", required=True, help="JSON config")
    u = sub.add_parser("update", help="Update connector")
    u.add_argument("name")
    u.add_argument("--config", required=True)
    d = sub.add_parser("delete", help="Delete connector")
    d.add_argument("name")
    args = parser.parse_args()
    try:
        api_client.get_base_url()
    except Exception as e:
        print("❌", e)
        sys.exit(1)
    if args.action == "list":
        list_connectors()
    elif args.action == "providers":
        print_providers()
    elif args.action == "create":
        create_connector(args.provider, args.config)
    elif args.action == "update":
        update_connector(args.name, args.config)
    elif args.action == "delete":
        delete_connector(args.name)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
