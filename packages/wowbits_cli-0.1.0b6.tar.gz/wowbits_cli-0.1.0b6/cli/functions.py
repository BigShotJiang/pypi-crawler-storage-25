#!/usr/bin/env python3
"""
WowBits CLI - Functions (thin client).

All function operations go through the API. This module only:
- GET /functions for list
- POST /functions/sync for create (sync from workspace)
- POST /functions/pull for pull from GitHub
- POST /functions for create single (inline)
- PATCH /functions/{name} and DELETE /functions/{name} via wowbits.py
"""

import sys
from pathlib import Path
from typing import Optional

# Ensure src is on path when run as script
import os
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cli import api_client


def list_functions() -> None:
    """List all Python functions via API."""
    r = api_client.get("/functions")
    if not r:
        print("No functions.")
        return
    print(f"\n  {'Name':<35} {'Description':<40}")
    print("  " + "-" * 75)
    for f in r:
        name = (f.get("name") or "")[:33] + ".." if len(f.get("name") or "") > 35 else (f.get("name") or "")
        desc = (f.get("description") or "")[:38] + ".." if len(f.get("description") or "") > 40 else (f.get("description") or "-")
        print(f"  {name:<35} {desc:<40}")
    print()


def sync_functions() -> None:
    """Sync functions from workspace/functions via API (POST /functions/sync)."""
    r = api_client.post("/functions/sync", {"install_requirements": True})
    print("✅ Functions synced:", r)


def pull_functions(repo_url: str, function_names: Optional[list] = None) -> None:
    """Pull functions from GitHub repo via API."""
    body = {"repo_url": repo_url}
    if function_names:
        body["function_names"] = function_names
    r = api_client.post("/functions/pull", body)
    print("✅ Pull complete:", r)


def get_functions_dir() -> Optional[Path]:
    """Return workspace functions path from WOWBITS_ROOT_DIR (for local reference only)."""
    root = __import__("os").environ.get("WOWBITS_ROOT_DIR")
    if not root:
        try:
            from dotenv import load_dotenv
            load_dotenv()
            root = __import__("os").environ.get("WOWBITS_ROOT_DIR")
        except ImportError:
            pass
    return Path(root).expanduser().resolve() / "functions" if root else None


def handle_function_command(action: str) -> None:
    """Handle function CLI commands (thin: all via API)."""
    try:
        api_client.get_base_url()
    except Exception as e:
        print(f"❌ {e}")
        sys.exit(1)
    if action == "list":
        list_functions()
    elif action == "create":
        sync_functions()
    else:
        print(f"❌ Unknown function action: {action}")
        sys.exit(1)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Manage Python functions (via WowBits API)")
    parser.add_argument("action", choices=["list", "create"], help="Action to perform")
    args = parser.parse_args()
    handle_function_command(args.action)
