"""
WowBits CLI Package

Thin API client. All commands require WOWBITS_API_URL.
"""

from .wowbits import main, create_parser

__all__ = ["main", "create_parser"]
