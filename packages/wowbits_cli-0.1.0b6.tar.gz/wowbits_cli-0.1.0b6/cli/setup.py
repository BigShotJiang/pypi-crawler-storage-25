#!/usr/bin/env python3
"""
WowBits CLI setup wizard.

4-step flow:
1) Welcome + workspace root directory
2) API port selection + validation + availability check
3) DB configuration (local SQLite)
4) Final summary + confirmation + provisioning
"""
import sys
import os
import socket
from pathlib import Path
from typing import Dict, Optional
from urllib.parse import urlparse

from core import setup as core_setup
from pylibs.pull import list_github_dir, fetch_raw_content, parse_github_url


DEFAULT_API_URL = "http://localhost:8000"
DEFAULT_API_PORT = 8000
DEFAULT_STARTER_REPO = "https://github.com/wowbits-ai/wowbits-getting-started-kit"
DEFAULT_GETTING_STARTED_DOCS = "https://github.com/wowbits-ai/wowbits-getting-started-kit#readme"
SHELL_BLOCK_START = "# >>> wowbits env >>>"
SHELL_BLOCK_END = "# <<< wowbits env <<<"
REQUIRED_WORKSPACE_DIRS = [
    "data",
    "agent_studio",
    "functions",
    "agent_runner",
    "agents",
    "skills",
    "tools",
    "connectors",
    "mcps",
    "logs/system",
    "logs/agents",
    "logs/mcps",
]


def _workspace_env_path(workspace_path: Path) -> Path:
    """Path to .env file inside workspace root."""
    return workspace_path / ".env"


def _ensure_required_workspace_structure(workspace_path: Path) -> None:
    for rel in REQUIRED_WORKSPACE_DIRS:
        (workspace_path / rel).mkdir(parents=True, exist_ok=True)
    init_py = workspace_path / "agent_runner" / "__init__.py"
    if not init_py.exists():
        init_py.write_text("# WowBits Agent Runner\n")


def _prompt(prompt: str) -> str:
    print(prompt)
    return input().strip()


def _confirm(prompt: str, default_yes: bool = True) -> bool:
    suffix = "[Y/n]" if default_yes else "[y/N]"
    while True:
        value = _prompt(f"{prompt} {suffix}").strip().lower()
        if not value:
            return default_yes
        if value in {"y", "yes"}:
            return True
        if value in {"n", "no"}:
            return False
        print("❌ Please enter 'y' or 'n'.")


def _normalize_workspace_path(root_dir: str) -> Path:
    return Path(root_dir).expanduser().resolve()


def _is_valid_port(value: int) -> bool:
    return 1 <= value <= 65535


def _is_port_available(port: int, host: str = "127.0.0.1") -> bool:
    """Return True when host:port does not accept a TCP connection."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex((host, port)) != 0


def _parse_port(value: str) -> Optional[int]:
    if not value:
        return None
    if not value.isdigit():
        return None
    parsed = int(value)
    if not _is_valid_port(parsed):
        return None
    return parsed


def _port_from_api_url(api_url: str) -> Optional[int]:
    try:
        parsed = urlparse(api_url)
        if not parsed.scheme or not parsed.hostname:
            return None
        if parsed.port is not None:
            return parsed.port
        return 443 if parsed.scheme == "https" else 80
    except Exception:
        return None


def _api_url_from_port(port: int) -> str:
    return f"http://localhost:{port}"


def _read_env_excluding(env_path: Path, *keys: str) -> list:
    """Read .env lines, excluding lines that set any of the given keys."""
    path = env_path
    if not path.exists():
        return []
    excluded = {k.upper() for k in keys}
    out = []
    for line in path.read_text().splitlines():
        if "=" in line:
            key = line.split("=", 1)[0].strip()
            if key.upper() in excluded:
                continue
        out.append(line)
    return out


def _upsert_workspace_env(workspace_path: Path, values: Dict[str, str]) -> Path:
    env_path = _workspace_env_path(workspace_path)
    existing = _read_env_excluding(env_path, *values.keys())
    block = "\n".join(existing) + "\n" if existing else ""
    for key, value in values.items():
        block += f"{key}={value}\n"
    env_path.write_text(block)
    return env_path


def _welcome_message() -> None:
    print("\n🚀 Welcome to WowBits setup")
    print("This wizard will help you configure your workspace, API port, and local database.")
    print("No files are created until you confirm in the final step.\n")


def _detect_shell_rc() -> Path:
    shell = (Path(sys.argv[0]).name or "").lower()
    shell_env = (os.environ.get("SHELL", "") or "").lower()
    home = Path.home()

    if "zsh" in shell_env or "zsh" in shell:
        return home / ".zshrc"
    return home / ".bashrc"


def _persist_shell_exports(root_dir: str, api_url: str) -> Path:
    rc_path = _detect_shell_rc()
    if not rc_path.exists():
        rc_path.touch()

    content = rc_path.read_text() if rc_path.exists() else ""
    lines = content.splitlines()

    clean: list[str] = []
    inside = False
    for line in lines:
        if line.strip() == SHELL_BLOCK_START:
            inside = True
            continue
        if line.strip() == SHELL_BLOCK_END:
            inside = False
            continue
        if not inside:
            clean.append(line)

    if clean and clean[-1].strip() != "":
        clean.append("")
    clean.extend(
        [
            SHELL_BLOCK_START,
            f'export WOWBITS_ROOT_DIR="{root_dir}"',
            f'export WOWBITS_API_URL="{api_url}"',
            SHELL_BLOCK_END,
            "",
        ]
    )

    rc_path.write_text("\n".join(clean))
    return rc_path


def _pull_starter_agent_studio(workspace_path: Path, repo_url: str) -> Dict[str, object]:
    parsed = parse_github_url(repo_url)
    if not parsed:
        raise ValueError("Unsupported starter repo URL. Use a GitHub URL (e.g. https://github.com/owner/repo)")

    owner, repo, branch = parsed
    items = list_github_dir(owner, repo, branch, "agent_studio")
    yaml_items = [
        item for item in items
        if item.get("type") == "file"
        and item.get("name", "").endswith((".yaml", ".yml"))
    ]
    if not yaml_items:
        return {"pulled": 0, "files": []}

    agent_studio_path = workspace_path / "agent_studio"
    agent_studio_path.mkdir(parents=True, exist_ok=True)

    files = []
    for item in yaml_items:
        name = item["name"]
        content = fetch_raw_content(owner, repo, branch, f"agent_studio/{name}")
        if content is None:
            continue
        (agent_studio_path / name).write_text(content, encoding="utf-8")
        files.append(name)
    return {"pulled": len(files), "files": files}


def _collect_root_dir(root_dir: Optional[str]) -> Path:
    if root_dir:
        return _normalize_workspace_path(root_dir)

    default = str(Path.home() / "wowbits")
    while True:
        value = _prompt(f"1/4 Workspace root directory (default: {default}):")
        chosen = value or default
        try:
            return _normalize_workspace_path(chosen)
        except Exception as exc:
            print(f"❌ Invalid path: {exc}")


def _collect_api_port(api_port: Optional[int], api_url: Optional[str]) -> int:
    if api_port is not None:
        if not _is_valid_port(api_port):
            print(f"❌ Invalid --api-port: {api_port}. Must be 1-65535.")
            sys.exit(1)
        if not _is_port_available(api_port):
            print(f"❌ Port {api_port} is already in use. Choose a free port.")
            sys.exit(1)
        return api_port

    if api_url:
        port = _port_from_api_url(api_url)
        if port is None:
            print(f"❌ Could not parse port from --api-url: {api_url}")
            sys.exit(1)
        if not _is_port_available(port):
            print(f"❌ Port {port} from --api-url is already in use.")
            sys.exit(1)
        return port

    while True:
        value = _prompt(f"2/4 WowBits API port (default: {DEFAULT_API_PORT}):")
        if not value:
            port = DEFAULT_API_PORT
        else:
            port = _parse_port(value)
            if port is None:
                print("❌ Invalid port. Enter a numeric value from 1 to 65535.")
                continue
        if not _is_port_available(port):
            print(f"❌ Port {port} is in use. Please choose a different port.")
            continue
        return port


def _collect_db_url(root_path: Path, db_url: Optional[str], assume_yes: bool = False) -> str:
    default_db = f"sqlite:///{root_path / 'data' / 'wowbits.db'}"
    print("3/4 Database configuration")
    print("- Current supported option: local SQLite in your workspace data folder")

    if db_url:
        if not db_url.startswith("sqlite:///"):
            print("❌ Only local SQLite is currently supported. Use sqlite:///... format.")
            sys.exit(1)
        return db_url

    if assume_yes:
        return default_db

    if _confirm(f"Use local SQLite database? (default path: {root_path / 'data' / 'wowbits.db'})", default_yes=True):
        return default_db

    print("❌ Setup cancelled. SQLite is the only DB option right now.")
    sys.exit(1)


def _collect_openai_key(openai_api_key: Optional[str], assume_yes: bool = False) -> Optional[str]:
    if openai_api_key is not None:
        return openai_api_key.strip() or None
    if assume_yes:
        return None
    value = _prompt("Optional: OPENAI_API_KEY (press Enter to skip):")
    return value or None


def _collect_starter_pull(skip_starter_pull: bool, assume_yes: bool = False) -> bool:
    if skip_starter_pull or assume_yes:
        return False
    return _confirm("Pull starter agent_studio YAMLs now?", default_yes=True)


def run_setup(
    root_dir: str = None,
    db_url: str = None,
    api_url: str = None,
    api_port: Optional[int] = None,
    openai_api_key: Optional[str] = None,
    starter_repo_url: str = DEFAULT_STARTER_REPO,
    skip_starter_pull: bool = False,
    assume_yes: bool = False,
) -> None:
    """Run full WowBits setup wizard for CLI users."""
    _welcome_message()

    root_path = _collect_root_dir(root_dir)
    chosen_port = _collect_api_port(api_port=api_port, api_url=api_url)
    resolved_api_url = _api_url_from_port(chosen_port)
    chosen_db_url = _collect_db_url(root_path=root_path, db_url=db_url, assume_yes=assume_yes)
    chosen_openai_api_key = _collect_openai_key(openai_api_key, assume_yes=assume_yes)
    do_starter_pull = _collect_starter_pull(skip_starter_pull=skip_starter_pull, assume_yes=assume_yes)

    print("\n4/4 Setup summary")
    print(f"- Workspace root: {root_path}")
    print(f"- API URL: {resolved_api_url}")
    print(f"- API Port: {chosen_port}")
    print(f"- DB: {chosen_db_url}")
    print("- DB mode: local SQLite")
    print(f"- OPENAI_API_KEY: {'set' if chosen_openai_api_key else 'not set'}")
    print(f"- Pull starter YAMLs: {'yes' if do_starter_pull else 'no'}")
    if not assume_yes and not _confirm("Proceed with setup and create files/folders?", default_yes=True):
        print("⚠️ Setup cancelled. No changes were made.")
        return

    root_path.mkdir(parents=True, exist_ok=True)
    _ensure_required_workspace_structure(root_path)
    root_dir = str(root_path)

    rc_path = _persist_shell_exports(root_dir=root_dir, api_url=resolved_api_url)
    core_setup.run_setup(workspace_path=root_path, db_url=chosen_db_url)
    _ensure_required_workspace_structure(root_path)

    values = {
        "WOWBITS_ROOT_DIR": root_dir,
        "WOWBITS_API_URL": resolved_api_url,
        "WOWBITS_API_PORT": str(chosen_port),
        "WOWBITS_DB_CONNECTION_STRING": chosen_db_url,
    }
    if chosen_openai_api_key:
        values["OPENAI_API_KEY"] = chosen_openai_api_key
    env_path = _upsert_workspace_env(root_path, values)

    pull_summary = {"pulled": 0, "files": []}
    if do_starter_pull:
        pull_summary = _pull_starter_agent_studio(root_path, starter_repo_url)

    print("\n✅ Setup complete.")
    print(f"   Workspace: {root_path}")
    print(f"   Env file: {env_path}")
    print(f"   Shell exports written: {rc_path}")
    print(f"   Starter YAMLs pulled: {pull_summary.get('pulled', 0)}")
    print("\nNext steps:")
    print(f"1) source {rc_path}")
    print("2) wowbits start api")
    print("3) wowbits list agents")
    print(f"📚 Getting started docs: {DEFAULT_GETTING_STARTED_DOCS}")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Run WowBits setup")
    p.add_argument("--root-dir", help="WowBits workspace root directory")
    p.add_argument("--db-url", help="Database URL (e.g. sqlite:///./data/wowbits.db)")
    p.add_argument("--api-url", help="API URL (e.g. http://localhost:8000)")
    p.add_argument("--api-port", type=int, help="API port (must be free)")
    p.add_argument("--openai-api-key", help="OpenAI API key to store in workspace .env")
    p.add_argument("--starter-repo-url", default=DEFAULT_STARTER_REPO, help="Starter repository URL")
    p.add_argument("--skip-starter-pull", action="store_true", help="Skip pulling starter agent_studio YAMLs")
    p.add_argument("-y", "--yes", action="store_true", help="Skip final confirmation")
    a = p.parse_args()
    run_setup(
        root_dir=a.root_dir,
        db_url=a.db_url,
        api_url=a.api_url,
        api_port=a.api_port,
        openai_api_key=a.openai_api_key,
        starter_repo_url=a.starter_repo_url,
        skip_starter_pull=a.skip_starter_pull,
        assume_yes=a.yes,
    )
