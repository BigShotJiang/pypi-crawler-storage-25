"""
Generic pull logic for fetching resources from GitHub repositories.
"""
import json
import re
import urllib.request
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple


def parse_github_url(repo_url: str) -> Optional[Tuple[str, str, str]]:
    """
    Parse GitHub URL to extract owner, repo, branch.
    Supports formats like:
    - https://github.com/owner/repo
    - https://github.com/owner/repo/tree/branch
    - https://github.com/owner/repo/blob/branch/path
    """
    if not repo_url or "github.com" not in repo_url:
        return None

    url = repo_url.strip().rstrip("/")
    m = re.match(r"https?://(?:www\.)?github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$", url, re.I)
    if m:
        return (m.group(1), m.group(2), "main")
    m = re.match(r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?/?$", url)
    if m:
        return (m.group(1), m.group(2), "main")
    return None


def list_github_dir(owner: str, repo: str, branch: str, path: str = "") -> List[Dict[str, Any]]:
    """List contents of a GitHub directory."""
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={branch}"
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github.v3+json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            if resp.status == 200:
                return json.loads(resp.read().decode())
    except Exception:
        pass
    return []


def fetch_raw_content(owner: str, repo: str, branch: str, path: str) -> Optional[str]:
    """Fetch raw content from GitHub."""
    url = f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}"
    req = urllib.request.Request(url, headers={"Accept": "application/octet-stream"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            if resp.status == 200:
                return resp.read().decode("utf-8", errors="replace")
    except Exception:
        pass
    return None


class GitHubPuller:
    """Generic class for pulling resources from GitHub."""

    def __init__(self, resource_type: str, dir_name: str, file_extension: str = ".py",
                 exclude_files: Optional[List[str]] = None):
        self.resource_type = resource_type
        self.dir_name = dir_name
        self.file_extension = file_extension
        self.exclude_files = exclude_files or []

    def _candidate_dirs(self, owner: str, repo: str, branch: str) -> List[str]:
        base = self.dir_name.strip("/")
        ordered: List[str] = []

        def add(path: str) -> None:
            normalized = path.strip("/")
            if normalized and normalized not in ordered:
                ordered.append(normalized)

        add(base)

        root_items = list_github_dir(owner, repo, branch, "")
        for item in root_items:
            if item.get("type") != "dir":
                continue
            name = str(item.get("name") or "").strip("/")
            if not name:
                continue
            add(f"{name}/{base}")

        return ordered

    def pull_from_repo(self, workspace_path: Path, repo_url: str,
                      resource_names: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Pull resources from GitHub repo.
        Returns {"created": N, "updated": M, "files": [names], "error": optional}.
        """
        parsed = parse_github_url(repo_url)
        if not parsed:
            raise ValueError("Unsupported repo URL. Use a GitHub URL (e.g. https://github.com/owner/repo)")

        owner, repo, branch = parsed
        dest_dir = workspace_path / self.dir_name
        dest_dir.mkdir(parents=True, exist_ok=True)

        pull_all = (
            resource_names is None
            or len(resource_names) == 0
            or (len(resource_names) == 1 and resource_names[0].strip() == "*")
        )

        candidate_dirs = self._candidate_dirs(owner, repo, branch)

        if pull_all:
            items = []
            for candidate_dir in candidate_dirs:
                items = list_github_dir(owner, repo, branch, candidate_dir)
                if items:
                    break
            if not items:
                items = list_github_dir(owner, repo, branch, "")
            names_to_pull = [
                item["name"][:-len(self.file_extension)]
                for item in items
                if item.get("type") == "file"
                and item.get("name", "").endswith(self.file_extension)
                and item["name"] not in self.exclude_files
            ]
        else:
            names_to_pull = [n.strip() for n in resource_names if n.strip()]

        if not names_to_pull:
            return {"created": 0, "updated": 0, "files": []}

        # Handle requirements.txt if it exists
        req_content = None
        for candidate_dir in candidate_dirs:
            req_content = fetch_raw_content(owner, repo, branch, f"{candidate_dir}/requirements.txt")
            if req_content:
                break
        if req_content:
            (dest_dir / "requirements.txt").write_text(req_content, encoding="utf-8")

        created = 0
        updated = 0
        files: List[str] = []

        for name in names_to_pull:
            content = None
            for candidate_dir in candidate_dirs:
                content = fetch_raw_content(owner, repo, branch, f"{candidate_dir}/{name}{self.file_extension}")
                if content is not None:
                    break
            if content is None:
                content = fetch_raw_content(owner, repo, branch, f"{name}{self.file_extension}")
            if content is None:
                continue

            file_path = dest_dir / f"{name}{self.file_extension}"
            file_path.write_text(content, encoding="utf-8")
            files.append(f"{name}{self.file_extension}")

            # This will be overridden by specific implementations
            # created, updated = self.upsert_resource(name, content)

        return {"created": created, "updated": updated, "files": files}