"""
WowBits Product API - one workspace per instance (WOWBITS_ROOT_DIR).
"""
from contextlib import asynccontextmanager
import os

from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware

from api.routers import functions, connectors, agents, mcps, skills, tools
from pylibs.env_loader import load_env_variables


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load env on startup so WOWBITS_ROOT_DIR and DB are available."""
    try:
        load_env_variables()
    except ValueError:
        pass  # WOWBITS_ROOT_DIR may be set by process env
    yield


app = FastAPI(
    title="WowBits API",
    description="API for WowBits workspace (agents, skills, connectors, functions, MCPs). One workspace per instance.",
    version="0.1.0",
    lifespan=lifespan,
)

# Allow Tauri app (Vite dev at localhost:5173) and other localhost origins to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(functions.router)
app.include_router(connectors.router)
app.include_router(agents.router)
app.include_router(mcps.router)
app.include_router(skills.router)
app.include_router(tools.router)


@app.get("/health")
def health():
    """Basic liveness: API is up."""
    return {"status": "ok"}


@app.get("/health/ready")
def health_ready(response: Response):
    """Readiness: API is up and DB is reachable."""
    try:
        load_env_variables()
    except ValueError:
        pass
    db_url = os.environ.get("WOWBITS_DB_CONNECTION_STRING")
    if not db_url:
        response.status_code = 503
        return {"status": "degraded", "reason": "WOWBITS_DB_CONNECTION_STRING not set"}
    try:
        from sqlalchemy import create_engine, text
        engine = create_engine(db_url)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        engine.dispose()
    except Exception as e:
        response.status_code = 503
        return {"status": "unhealthy", "reason": str(e)}
    return {"status": "ok"}
