"""
API dependencies: workspace path from WOWBITS_ROOT_DIR, DB session.
"""
import os
from pathlib import Path

from pylibs.database_manager import get_session_context
from pylibs.env_loader import load_env_variables


def get_workspace_path() -> Path:
    """Workspace path from WOWBITS_ROOT_DIR (Option B: one API = one workspace)."""
    load_env_variables()
    root = os.environ.get("WOWBITS_ROOT_DIR")
    if not root:
        raise ValueError("WOWBITS_ROOT_DIR is not set. Start the API with workspace path configured.")
    return Path(root).expanduser().resolve()


def get_db_session():
    """Yield a DB session (context manager). Ensures env is loaded first."""
    load_env_variables()
    with get_session_context() as session:
        yield session
