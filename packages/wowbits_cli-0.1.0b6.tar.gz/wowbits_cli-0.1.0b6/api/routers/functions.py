"""
Functions router: GET /functions, GET /functions/{name}, POST /functions, PATCH /functions/{name}, DELETE /functions/{name}, POST /functions/sync, POST /functions/pull
"""
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from api.deps import get_workspace_path, get_db_session
from core import functions as core_functions

router = APIRouter(prefix="/functions", tags=["functions"])


class CreateFunctionRequest(BaseModel):
    name: str
    code: str
    description: str = ""


class UpdateFunctionRequest(BaseModel):
    code: Optional[str] = None
    description: Optional[str] = None


class SyncRequest(BaseModel):
    install_requirements: bool = True


class PullRequest(BaseModel):
    repo_url: str
    function_names: Optional[List[str]] = None


@router.get("", response_model=list)
def list_functions(session: Session = Depends(get_db_session)):
    return core_functions.list_functions(session)


@router.get("/{name}", response_model=dict)
def get_function(name: str, session: Session = Depends(get_db_session)):
    out = core_functions.get_function(session, name)
    if not out:
        raise HTTPException(status_code=404, detail="Function not found")
    return out


@router.post("", response_model=dict)
def create_function(body: CreateFunctionRequest, session: Session = Depends(get_db_session)):
    try:
        return core_functions.create_function(
            session, body.name, body.code, description=body.description
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{name}", response_model=dict)
def update_function(
    name: str,
    body: UpdateFunctionRequest,
    session: Session = Depends(get_db_session),
):
    out = core_functions.update_function(
        session, name, code=body.code, description=body.description
    )
    if not out:
        raise HTTPException(status_code=404, detail="Function not found")
    return out


@router.delete("/{name}")
def delete_function(name: str, session: Session = Depends(get_db_session)):
    if not core_functions.delete_function(session, name):
        raise HTTPException(status_code=404, detail="Function not found")
    return {"deleted": name}


@router.post("/sync", response_model=dict)
def sync_functions(
    body: SyncRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    functions_dir = core_functions.get_functions_dir(workspace_path)
    return core_functions.scan_and_create_functions(
        session, functions_dir, install_requirements=body.install_requirements
    )


@router.post("/pull", response_model=dict)
def pull_functions(
    body: PullRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    return core_functions.pull_functions_from_repo(
        session, workspace_path, body.repo_url, body.function_names
    )
