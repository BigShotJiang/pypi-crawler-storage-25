"""
Agents router: GET /agents, GET /agents/{id_or_name}, POST /agents, PATCH /agents/{id_or_name}, DELETE /agents/{id_or_name}, POST /agents/{name}/start, POST /agents/{name}/stop
"""
import json
import os
from pathlib import Path
from typing import List, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from api.deps import get_workspace_path, get_db_session
from core import agents as core_agents
from core import functions as core_functions
from core import mcp as core_mcp
from core import skills as core_skills

router = APIRouter(prefix="/agents", tags=["agents"])


class CreateAgentRequest(BaseModel):
    name: str
    config_path: Optional[str] = None
    yaml_content: Optional[str] = None  # When set, CLI sends YAML; API parses and core processes


class UpdateAgentRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    instructions: Optional[str] = None
    status: Optional[str] = None
    default_model: Optional[str] = None
    default_model_config: Optional[dict] = None
    temperature: Optional[float] = None
    max_output_tokens: Optional[int] = None
    safety_settings: Optional[list] = None
    exec_mode: Optional[str] = None
    output_key: Optional[str] = None


class RunAgentRequest(BaseModel):
    mode: str = "web"
    host: str = "0.0.0.0"
    port: int = 5151


class PullRequest(BaseModel):
    repo_url: str
    function_names: Optional[List[str]] = None
    mcp_names: Optional[List[str]] = None
    skill_names: Optional[List[str]] = None
    agent_names: Optional[List[str]] = None


class AdkSessionRequest(BaseModel):
    adk_base_url: Optional[str] = None
    user_id: str = "anonymous"


class AdkRunRequest(BaseModel):
    adk_base_url: Optional[str] = None
    session_id: str
    new_message: str
    user_id: str = "anonymous"


def _resolve_adk_base_url(adk_base_url: Optional[str]) -> str:
    raw = (adk_base_url or os.environ.get("ADK_API_URL") or os.environ.get("WOWBITS_ADK_API_URL") or "http://localhost:5152").strip()
    return raw.rstrip("/")


def _adk_request(
    method: str,
    url: str,
    body: Optional[dict] = None,
    headers: Optional[dict] = None,
) -> tuple[str, str]:
    data = None
    req_headers = dict(headers or {})
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        req_headers.setdefault("Content-Type", "application/json")
    req = Request(url, data=data, method=method, headers=req_headers)
    try:
        with urlopen(req) as resp:
            content_type = resp.headers.get("Content-Type", "")
            text = resp.read().decode("utf-8", errors="replace")
            return content_type, text
    except HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace") if e.fp else ""
        raise HTTPException(status_code=502, detail=f"ADK API error ({e.code}): {raw or str(e)}")
    except (URLError, OSError, ValueError) as e:
        raise HTTPException(status_code=502, detail=f"Cannot reach ADK API: {e}")


def _parse_json_or_default(text: str, default):
    if not text:
        return default
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return default


def _parse_sse_events(text: str) -> List[dict]:
    events: List[dict] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[len("data:"):].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            events.append(json.loads(payload))
        except json.JSONDecodeError:
            events.append({"raw": payload})
    return events


@router.get("", response_model=list)
def list_agents(session: Session = Depends(get_db_session)):
    return core_agents.list_agents(session)


@router.get("/{id_or_name}", response_model=dict)
def get_agent(id_or_name: str, session: Session = Depends(get_db_session)):
    out = core_agents.get_agent(session, id_or_name)
    if not out:
        raise HTTPException(status_code=404, detail="Agent not found")
    return out


@router.post("", response_model=dict)
def create_agent(
    body: CreateAgentRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    if body.yaml_content is not None:
        config = core_agents.load_yaml_config_from_string(
            body.yaml_content, source_name=body.name or "request"
        )
        return core_agents.create_agent_from_config(session, config, workspace_path=workspace_path)
    config_path = Path(body.config_path) if body.config_path else None
    try:
        return core_agents.create_agent_from_yaml(
            session, workspace_path, body.name, config_path
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{id_or_name}", response_model=dict)
def update_agent(
    id_or_name: str,
    body: UpdateAgentRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    try:
        out = core_agents.update_agent(
            session,
            id_or_name,
            workspace_path=workspace_path,
            name=body.name,
            description=body.description,
            instructions=body.instructions,
            status=body.status,
            default_model=body.default_model,
            default_model_config=body.default_model_config,
            temperature=body.temperature,
            max_output_tokens=body.max_output_tokens,
            safety_settings=body.safety_settings,
            exec_mode=body.exec_mode,
            output_key=body.output_key,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not out:
        raise HTTPException(status_code=404, detail="Agent not found")
    return out


@router.delete("/{id_or_name}")
def delete_agent(
    id_or_name: str,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    if not core_agents.delete_agent(session, id_or_name, workspace_path=workspace_path):
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"deleted": id_or_name}


@router.post("/{name}/run", response_model=dict)
def run_agent(
    name: str,
    body: RunAgentRequest,
    workspace_path: Path = Depends(get_workspace_path),
):
    # Backward-compatible alias for /start
    try:
        return core_agents.run_agent(
            workspace_path, name, body.mode, body.host, body.port
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{name}/start", response_model=dict)
def start_agent(
    name: str,
    body: RunAgentRequest,
    workspace_path: Path = Depends(get_workspace_path),
):
    try:
        return core_agents.run_agent(
            workspace_path, name, body.mode, body.host, body.port
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{name}/stop", response_model=dict)
def stop_agent(
    name: str,
    workspace_path: Path = Depends(get_workspace_path),
):
    try:
        return core_agents.stop_agent(workspace_path, name)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/pull", response_model=dict)
def pull_agents(
    body: PullRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    try:
        functions_result = core_functions.pull_functions_from_repo(
            session,
            workspace_path,
            body.repo_url,
            body.function_names,
        )
        mcps_result = core_mcp.pull_mcps_from_repo(
            session,
            workspace_path,
            body.repo_url,
            body.mcp_names,
        )
        skills_result = core_skills.pull_skills_from_repo(
            session,
            workspace_path,
            body.repo_url,
            body.skill_names,
        )
        agents_result = core_agents.pull_agents_from_repo(
            session,
            workspace_path,
            body.repo_url,
            body.agent_names,
        )
        return {
            "order": ["functions", "mcps", "skills", "agents"],
            "functions": functions_result,
            "mcps": mcps_result,
            "skills": skills_result,
            "agents": agents_result,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{name}/adk/sessions", response_model=list)
def list_adk_sessions(
    name: str,
    adk_base_url: Optional[str] = None,
    user_id: str = "anonymous",
):
    base = _resolve_adk_base_url(adk_base_url)
    url = f"{base}/apps/{name}/users/{user_id}/sessions"
    content_type, text = _adk_request("GET", url)
    parsed = _parse_json_or_default(text, [])
    return parsed if isinstance(parsed, list) else []


@router.post("/{name}/adk/sessions", response_model=dict)
def create_adk_session(name: str, body: AdkSessionRequest):
    base = _resolve_adk_base_url(body.adk_base_url)
    url = f"{base}/apps/{name}/users/{body.user_id}/sessions"
    content_type, text = _adk_request("POST", url)
    parsed = _parse_json_or_default(text, {})
    if isinstance(parsed, dict):
        return parsed
    return {"raw": text}


@router.get("/{name}/adk/sessions/{session_id}", response_model=dict)
def get_adk_session(
    name: str,
    session_id: str,
    adk_base_url: Optional[str] = None,
    user_id: str = "anonymous",
):
    base = _resolve_adk_base_url(adk_base_url)
    url = f"{base}/apps/{name}/users/{user_id}/sessions/{session_id}"
    content_type, text = _adk_request("GET", url)
    parsed = _parse_json_or_default(text, {})
    if isinstance(parsed, dict):
        return parsed
    return {"raw": text}


@router.post("/{name}/adk/run", response_model=dict)
def run_adk_agent(name: str, body: AdkRunRequest):
    base = _resolve_adk_base_url(body.adk_base_url)
    url = f"{base}/run"
    payload = {
        "appName": name,
        "userId": body.user_id,
        "sessionId": body.session_id,
        "newMessage": {
            "role": "user",
            "parts": [{"text": body.new_message}],
        },
    }
    content_type, text = _adk_request(
        "POST",
        url,
        body=payload,
        headers={"Accept": "text/event-stream"},
    )

    if "application/json" in (content_type or ""):
        parsed = _parse_json_or_default(text, [])
        if isinstance(parsed, list):
            events = parsed
        elif isinstance(parsed, dict):
            events = [parsed]
        else:
            events = []
    else:
        events = _parse_sse_events(text)

    return {"events": events}
