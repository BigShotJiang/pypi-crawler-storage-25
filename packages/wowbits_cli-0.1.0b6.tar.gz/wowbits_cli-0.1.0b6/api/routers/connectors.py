"""
Connectors router: GET /connectors, GET /connectors/providers, POST /connectors,
PATCH /connectors/{id_or_name}, DELETE /connectors/{id_or_name}
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from typing import Optional

from api.deps import get_db_session
from core import connectors as core_connectors

router = APIRouter(prefix="/connectors", tags=["connectors"])


class CreateConnectorRequest(BaseModel):
    name: str
    provider: str
    config: Optional[dict] = None
    status: str = "ACTIVE"


class UpdateConnectorRequest(BaseModel):
    name: Optional[str] = None
    provider: Optional[str] = None
    config: Optional[dict] = None
    status: Optional[str] = None


@router.get("/providers", response_model=dict)
def list_providers():
    return core_connectors.load_providers()


@router.get("", response_model=list)
def list_connectors(session: Session = Depends(get_db_session)):
    return core_connectors.list_connectors(session)


@router.get("/{id_or_name}", response_model=dict)
def get_connector(id_or_name: str, session: Session = Depends(get_db_session)):
    out = core_connectors.get_connector_by_id(session, id_or_name) or core_connectors.get_connector(
        session, id_or_name
    )
    if not out:
        raise HTTPException(status_code=404, detail="Connector not found")
    return out


@router.post("", response_model=dict)
def create_connector(body: CreateConnectorRequest, session: Session = Depends(get_db_session)):
    try:
        return core_connectors.create_connector(
            session, body.name, body.provider, body.config, body.status
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{id_or_name}", response_model=dict)
def update_connector(
    id_or_name: str,
    body: UpdateConnectorRequest,
    session: Session = Depends(get_db_session),
):
    # Resolve name to id if needed
    connector = core_connectors.get_connector(session, id_or_name) or core_connectors.get_connector_by_id(
        session, id_or_name
    )
    if not connector:
        raise HTTPException(status_code=404, detail="Connector not found")
    connector_id = connector["id"]
    try:
        out = core_connectors.update_connector(
            session,
            connector_id,
            name=body.name,
            provider=body.provider,
            config=body.config,
            status=body.status,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not out:
        raise HTTPException(status_code=404, detail="Connector not found")
    return out


@router.delete("/{id_or_name}")
def delete_connector(id_or_name: str, session: Session = Depends(get_db_session)):
    deleted_id = core_connectors.delete_connector_by_name(session, id_or_name)
    if deleted_id:
        return {"deleted": id_or_name, "id": deleted_id}
    try:
        ok = core_connectors.delete_connector(session, id_or_name)
        if ok:
            return {"deleted": id_or_name}
    except ValueError:
        pass
    raise HTTPException(status_code=404, detail="Connector not found")
