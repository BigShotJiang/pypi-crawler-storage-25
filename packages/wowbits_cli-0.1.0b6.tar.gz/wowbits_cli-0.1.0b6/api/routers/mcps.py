"""
MCPs router: GET /mcps, GET /mcps/{id_or_name}, POST /mcps, PATCH /mcps/{id_or_name}, DELETE /mcps/{id_or_name}, POST /mcps/{name}/start, POST /mcps/{name}/stop
"""
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from api.deps import get_workspace_path, get_db_session
from core import mcp as core_mcp

router = APIRouter(prefix="/mcps", tags=["mcps"])


class CreateMCPRequest(BaseModel):
    name: str
    config_yaml_content: Optional[str] = None
    config_json_content: Optional[str] = None
    setup_py_content: Optional[str] = None
    run_py_content: Optional[str] = None


class UpdateMCPRequest(BaseModel):
    name: Optional[str] = None
    url: Optional[str] = None
    config: Optional[Dict[str, Any]] = None


class PullRequest(BaseModel):
    repo_url: str
    mcp_names: Optional[list[str]] = None


@router.get("", response_model=list)
def list_mcps(session: Session = Depends(get_db_session)):
    return core_mcp.list_mcps(session)


@router.get("/{id_or_name}", response_model=dict)
def get_mcp(id_or_name: str, session: Session = Depends(get_db_session)):
    out = core_mcp.get_mcp(session, id_or_name)
    if not out:
        raise HTTPException(status_code=404, detail="MCP not found")
    return out


@router.post("", response_model=dict)
def create_mcp(
    body: CreateMCPRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    try:
        return core_mcp.create_mcp(
            session,
            workspace_path,
            body.name,
            config_yaml_content=body.config_yaml_content,
            config_json_content=body.config_json_content,
            setup_py_content=body.setup_py_content,
            run_py_content=body.run_py_content,
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{id_or_name}", response_model=dict)
def update_mcp(
    id_or_name: str,
    body: UpdateMCPRequest,
    session: Session = Depends(get_db_session),
):
    try:
        out = core_mcp.update_mcp(
            session,
            id_or_name,
            name=body.name,
            url=body.url,
            config=body.config,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not out:
        raise HTTPException(status_code=404, detail="MCP not found")
    return out


@router.post("/pull", response_model=dict)
def pull_mcps(
    body: PullRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    try:
        return core_mcp.pull_mcps_from_repo(
            session, workspace_path, body.repo_url, body.mcp_names
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{id_or_name}")
def delete_mcp(id_or_name: str, session: Session = Depends(get_db_session)):
    if not core_mcp.delete_mcp(session, id_or_name):
        raise HTTPException(status_code=404, detail="MCP not found")
    return {"deleted": id_or_name}


@router.post("/{name}/run")
def run_mcp(name: str, workspace_path: Path = Depends(get_workspace_path)):
    # Backward-compatible alias for /start
    try:
        return core_mcp.run_mcp(workspace_path, name)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{name}/start")
def start_mcp(name: str, workspace_path: Path = Depends(get_workspace_path)):
    try:
        return core_mcp.run_mcp(workspace_path, name)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{name}/stop")
def stop_mcp(name: str, workspace_path: Path = Depends(get_workspace_path)):
    try:
        return core_mcp.stop_mcp(workspace_path, name)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
