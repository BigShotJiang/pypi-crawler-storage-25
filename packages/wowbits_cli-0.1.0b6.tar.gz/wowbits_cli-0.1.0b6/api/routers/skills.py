"""
Skills router: GET /skills, GET /skills/{id_or_name}, POST /skills, PATCH /skills/{id_or_name}, DELETE /skills/{id_or_name}, POST /skills/pull
"""
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from pathlib import Path

from api.deps import get_db_session, get_workspace_path
from core import functions as core_functions
from core import mcp as core_mcp
from core import skills as core_skills

router = APIRouter(prefix="/skills", tags=["skills"])


class CreateSkillRequest(BaseModel):
    name: str
    description: str = ""
    instructions: str = ""
    default_model: str = "gpt-4.1"
    default_model_config: Optional[Dict] = None
    temperature: float = 0.2
    max_output_tokens: int = 32000
    safety_settings: Optional[List] = None
    exec_mode: str = "llm"
    output_key: Optional[str] = None


class UpdateSkillRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    instructions: Optional[str] = None
    default_model: Optional[str] = None
    default_model_config: Optional[Dict] = None
    temperature: Optional[float] = None
    max_output_tokens: Optional[int] = None
    safety_settings: Optional[List] = None
    exec_mode: Optional[str] = None
    output_key: Optional[str] = None


class PullRequest(BaseModel):
    repo_url: str
    function_names: Optional[List[str]] = None
    mcp_names: Optional[List[str]] = None
    skill_names: Optional[List[str]] = None


@router.get("", response_model=list)
def list_skills(session: Session = Depends(get_db_session)):
    return core_skills.list_skills(session)


@router.get("/{id_or_name}", response_model=dict)
def get_skill(id_or_name: str, session: Session = Depends(get_db_session)):
    out = core_skills.get_skill(session, id_or_name)
    if not out:
        raise HTTPException(status_code=404, detail="Skill not found")
    return out


@router.post("", response_model=dict)
def create_skill(body: CreateSkillRequest, session: Session = Depends(get_db_session)):
    try:
        return core_skills.create_skill(
            session,
            body.name,
            description=body.description,
            instructions=body.instructions,
            default_model=body.default_model,
            default_model_config=body.default_model_config,
            temperature=body.temperature,
            max_output_tokens=body.max_output_tokens,
            safety_settings=body.safety_settings,
            exec_mode=body.exec_mode,
            output_key=body.output_key,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{id_or_name}", response_model=dict)
def update_skill(
    id_or_name: str,
    body: UpdateSkillRequest,
    session: Session = Depends(get_db_session),
):
    try:
        out = core_skills.update_skill(
            session,
            id_or_name,
            name=body.name,
            description=body.description,
            instructions=body.instructions,
            default_model=body.default_model,
            default_model_config=body.default_model_config,
            temperature=body.temperature,
            max_output_tokens=body.max_output_tokens,
            safety_settings=body.safety_settings,
            exec_mode=body.exec_mode,
            output_key=body.output_key,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not out:
        raise HTTPException(status_code=404, detail="Skill not found")
    return out


@router.delete("/{id_or_name}")
def delete_skill(id_or_name: str, session: Session = Depends(get_db_session)):
    if not core_skills.delete_skill(session, id_or_name):
        raise HTTPException(status_code=404, detail="Skill not found")
    return {"deleted": id_or_name}


@router.post("/pull", response_model=dict)
def pull_skills(
    body: PullRequest,
    workspace_path: Path = Depends(get_workspace_path),
    session: Session = Depends(get_db_session),
):
    try:
        functions_result = core_functions.pull_functions_from_repo(
            session,
            workspace_path,
            body.repo_url,
            body.function_names,
        )
        mcps_result = core_mcp.pull_mcps_from_repo(
            session,
            workspace_path,
            body.repo_url,
            body.mcp_names,
        )
        skills_result = core_skills.pull_skills_from_repo(
            session,
            workspace_path,
            body.repo_url,
            body.skill_names,
        )
        return {
            "order": ["functions", "mcps", "skills"],
            "functions": functions_result,
            "mcps": mcps_result,
            "skills": skills_result,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
