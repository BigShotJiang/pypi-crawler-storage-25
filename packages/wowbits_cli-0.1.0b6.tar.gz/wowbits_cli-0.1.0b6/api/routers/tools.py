"""
Tools router: GET /tools, GET /tools/{id_or_name}, POST /tools, PATCH /tools/{id_or_name}, DELETE /tools/{id_or_name}
"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from api.deps import get_db_session
from core import tools as core_tools

router = APIRouter(prefix="/tools", tags=["tools"])


class CreateToolRequest(BaseModel):
    name: str
    type: str  # PYTHON_FUNCTION | MCP_SERVER
    description: str = ""
    python_function_name: Optional[str] = None
    mcp_config_name: Optional[str] = None


class UpdateToolRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    type: Optional[str] = None
    python_function_name: Optional[str] = None
    mcp_config_name: Optional[str] = None


@router.get("", response_model=list)
def list_tools(session: Session = Depends(get_db_session)):
    return core_tools.list_tools(session)


@router.get("/{id_or_name}", response_model=dict)
def get_tool(id_or_name: str, session: Session = Depends(get_db_session)):
    out = core_tools.get_tool(session, id_or_name)
    if not out:
        raise HTTPException(status_code=404, detail="Tool not found")
    return out


@router.post("", response_model=dict)
def create_tool(body: CreateToolRequest, session: Session = Depends(get_db_session)):
    try:
        return core_tools.create_tool(
            session,
            body.name,
            body.type,
            description=body.description,
            python_function_name=body.python_function_name,
            mcp_config_name=body.mcp_config_name,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{id_or_name}", response_model=dict)
def update_tool(
    id_or_name: str,
    body: UpdateToolRequest,
    session: Session = Depends(get_db_session),
):
    try:
        out = core_tools.update_tool(
            session,
            id_or_name,
            name=body.name,
            description=body.description,
            type=body.type,
            python_function_name=body.python_function_name,
            mcp_config_name=body.mcp_config_name,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not out:
        raise HTTPException(status_code=404, detail="Tool not found")
    return out


@router.delete("/{id_or_name}")
def delete_tool(id_or_name: str, session: Session = Depends(get_db_session)):
    if not core_tools.delete_tool(session, id_or_name):
        raise HTTPException(status_code=404, detail="Tool not found")
    return {"deleted": id_or_name}
