import os
import pytest
from NKit.audit import WhyLog

@pytest.fixture
def whylog(tmp_path):
    log_file = tmp_path / "test_audit.jsonl"
    return WhyLog(str(log_file))

def test_log_write_and_query(whylog):
    session = "test-session-123"
    
    whylog.log(
        session_id=session,
        event_type="agent.start",
        goal="Do math",
    )
    
    whylog.log(
        session_id=session,
        event_type="tool.after",
        goal="Do math",
        action="calc",
        result="42"
    )
    
    entries = whylog.query(session)
    assert len(entries) == 2
    assert entries[0]["event_type"] == "agent.start"
    assert entries[1]["result"] == "42"
    
def test_query_unknown_session(whylog):
    whylog.log("session-1", "agent.start", "G1")
    assert len(whylog.query("session-2")) == 0
