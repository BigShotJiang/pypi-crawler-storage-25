import pytest
from NKit.safety import SafetyGate, SafetyViolation

@pytest.fixture
def gate():
    return SafetyGate(
        allowed_dirs=["./allowed"],
        allowed_domains=["api.github.com"],
        hitl=False
    )

def test_file_write_allowed(gate):
    # Should not raise
    gate.evaluate("write_file", {"path": "./allowed/test.txt"}, "Save file", "reason")

def test_file_write_blocked(gate):
    with pytest.raises(SafetyViolation) as exc:
        gate.evaluate("write_file", {"path": "/etc/passwd"}, "Save file", "reason")
    assert "outside allowed directories" in str(exc.value)

def test_domain_allowed(gate):
    # Should not raise
    gate.evaluate("fetch_url", {"url": "https://api.github.com/users"}, "Get users", "reason")

def test_domain_blocked(gate):
    with pytest.raises(SafetyViolation) as exc:
        gate.evaluate("fetch_url", {"url": "https://evil.corp/steal"}, "Get users", "reason")
    assert "not in allowed_domains" in str(exc.value)

def test_destructive_without_goal(gate):
    with pytest.raises(SafetyViolation) as exc:
        gate.evaluate("system_exec", {"cmd": "rm -rf /"}, "List files", "reason")
    assert "Destructive action" in str(exc.value)

def test_destructive_with_goal_permission(gate):
    # If the user explicitly asks to drop a table, allow it
    gate.evaluate("db_exec", {"query": "DROP TABLE users"}, "I want to drop the users table", "reason")
