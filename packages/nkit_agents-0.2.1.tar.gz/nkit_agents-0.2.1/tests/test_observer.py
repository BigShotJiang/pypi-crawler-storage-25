import pytest
from NKit.observer import LiveObserver, Event

def test_observer_decorator():
    observer = LiveObserver()
    flag = False
    
    @observer.on("test.event")
    def handler(e: Event):
        nonlocal flag
        flag = e["flag_value"]
        
    observer.emit("test.event", flag_value=True)
    assert flag is True

def test_multiple_handlers():
    observer = LiveObserver()
    results = []
    
    @observer.on("test.event")
    def h1(e):
        results.append(1)
        
    @observer.on("test.event")
    def h2(e):
        results.append(2)
        
    observer.emit("test.event")
    assert results == [1, 2]
    
def test_handler_error_does_not_crash():
    observer = LiveObserver()
    
    @observer.on("test.event")
    def bad_handler(e):
        raise ValueError("Oops")
        
    # Should safely catch and ignore the exception so main Agent loop survives
    observer.emit("test.event")
