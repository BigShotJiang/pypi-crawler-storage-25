import pytest
from NKit.agent.core import Agent

def dummy_llm(prompt: str) -> str:
    # A mock LLM returning a valid ReAct JSON chunk to escape immediately
    return '''
```json
{
  "thought": "I know the answer.",
  "final_answer": "42"
}
```'''

def test_agent_initialization():
    agent = Agent(llm=dummy_llm)
    assert agent.max_steps == 20
    assert agent.max_retries == 3
    assert agent.is_llm_async is False
    
def test_agent_run_success():
    agent = Agent(llm=dummy_llm)
    res = agent.run("What is the meaning of life?")
    assert res == "42"
