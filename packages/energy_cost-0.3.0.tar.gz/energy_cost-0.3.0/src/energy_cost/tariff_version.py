import datetime as dt
from collections.abc import Callable
from datetime import UTC
from typing import Annotated, Any, Literal

import pandas as pd
from pydantic import BeforeValidator, Field

from energy_cost.versioning import Versioned

from .capacity_cost import CapacityComponent
from .formula import Formula, PeriodicFormula
from .meter import MeterType, PowerDirection
from .resolution import Resolution, resample_or_distribute, to_pandas_freq

_METER_KEYS = {e.value for e in MeterType}


def _coerce_named_formulas(value: Any) -> Any:
    """Allow a bare Formula dict to be shorthand for ``{total: it}``."""
    try:
        return {"total": Formula.model_validate(value)}
    except ValueError:
        return value


NamedFormulas = Annotated[
    dict[str, Formula],
    BeforeValidator(_coerce_named_formulas),
]


def _coerce_meter_formulas(value: Any) -> Any:
    """Coerce shorthand MeterFormulas values."""
    if not isinstance(value, dict):
        return value
    if not any(key in value for key in _METER_KEYS):
        # No meter keys, assume it's a shorthand for ALL meters
        return {MeterType.ALL.value: _coerce_named_formulas(value)}
    return value


MeterFormulas = Annotated[
    dict[str, NamedFormulas],
    BeforeValidator(_coerce_meter_formulas),
]


class TariffVersion(Versioned):
    injection: MeterFormulas = Field(default_factory=dict)
    consumption: MeterFormulas = Field(default_factory=dict)
    capacity: CapacityComponent | None = None
    periodic: dict[str, PeriodicFormula] = Field(default_factory=dict)

    def _resolve_energy_formulas(
        self,
        meter_type: MeterType,
        direction: PowerDirection,
    ) -> dict[str, Formula]:
        direction_formulas: MeterFormulas = getattr(self, direction)
        result: dict[str, Formula] = {}
        if MeterType.ALL in direction_formulas:
            result.update(direction_formulas[MeterType.ALL])
        if meter_type in direction_formulas:
            result.update(direction_formulas[meter_type])
        return result

    def _combine_energy_formulas(
        self,
        meter_type: MeterType,
        direction: PowerDirection,
        get_df: Callable[[Formula], pd.DataFrame],
    ) -> pd.DataFrame | None:
        resolved = self._resolve_energy_formulas(meter_type, direction)
        series: dict[str, pd.Series] = {}
        for cost_type, formula in resolved.items():
            df = get_df(formula)
            if not df.empty:
                series[cost_type] = df.set_index("timestamp")["value"]

        if not series:
            return None

        result = pd.DataFrame(series)
        result.index.name = "timestamp"
        result = result.reset_index()

        cost_columns = [col for col in result.columns if col not in ("timestamp", "total")]
        if cost_columns:
            result["total"] = result[cost_columns].sum(axis=1)
        return result

    def get_energy_cost(
        self,
        start: dt.datetime,
        end: dt.datetime,
        resolution: Resolution,
        meter_type: MeterType,
        direction: PowerDirection,
        timezone: dt.tzinfo = UTC,
    ) -> pd.DataFrame | None:
        """Get energy cost rates in €/MWh. Returns None if no formulas are configured."""
        return self._combine_energy_formulas(
            meter_type,
            direction,
            lambda formula: formula.get_values(start, end, resolution, timezone),
        )

    def apply_energy_cost(
        self,
        data: pd.DataFrame,
        meter_type: MeterType,
        direction: PowerDirection,
        start: dt.datetime,
        end: dt.datetime,
        input_resolution: Resolution,
        timezone: dt.tzinfo = UTC,
        output_resolution: Resolution | None = None,
    ) -> pd.DataFrame | None:
        """Apply energy cost formulas to quantity data in [start, end), returning costs in €."""
        data = data[(data["timestamp"] >= start) & (data["timestamp"] < end)].copy()
        if data.empty:
            return None

        result = self._combine_energy_formulas(
            meter_type,
            direction,
            lambda formula: formula.apply(data, timezone=timezone, resolution=input_resolution, start=start, end=end),
        )

        if output_resolution is not None and result is not None:
            result = resample_or_distribute(result, input_resolution, output_resolution, start, end)
        return result

    def apply_capacity_cost(
        self,
        capacity_data: pd.DataFrame,
        start: dt.datetime,
        end: dt.datetime,
        timezone: dt.tzinfo = UTC,
        unit: Literal["MW", "MWh"] = "MWh",
        output_resolution: Resolution | None = None,
    ) -> pd.DataFrame | None:
        """Apply capacity cost formula in [start, end), returning costs in €."""
        if self.capacity is None:
            return None

        result = self.capacity.apply(capacity_data, timezone=timezone, unit=unit)
        result = result[(result["timestamp"] >= start) & (result["timestamp"] < end)].copy()

        if output_resolution is not None and not result.empty:
            result = resample_or_distribute(result, self.capacity.billing_period, output_resolution, start, end)
        return result

    def apply_periodic_costs(
        self,
        start: dt.datetime,
        end: dt.datetime,
        output_resolution: Resolution,
        timezone: dt.tzinfo = UTC,
    ) -> pd.DataFrame | None:
        """Apply periodic cost formulas in [start, end), returning a DataFrame with a column per named cost."""
        if not self.periodic:
            return None

        output_ts = pd.date_range(start=start, end=end, freq=to_pandas_freq(output_resolution), inclusive="left")
        if output_ts.empty:
            return None
        sentinel = pd.DataFrame({"timestamp": output_ts})

        result: pd.DataFrame | None = None
        for name, formula in self.periodic.items():
            df = formula.apply(sentinel, resolution=output_resolution, timezone=timezone, start=start, end=end)
            df = df.rename(columns={"value": name})
            result = df if result is None else result.merge(df, on="timestamp", how="outer")
        return result
