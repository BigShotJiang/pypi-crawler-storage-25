"""Regression tests for the autogen check.

Scenario: a Model.save() method parses an auto-generated ID via
``int(<field>.split(sep)[-1])`` without try/except. A legacy row with a
non-numeric suffix crashes with ``ValueError`` — HTTP 500 on every
subsequent save. Exactly the hikimatech bug that motivated this check.
"""

import pytest

from django_doctor import Severity
from django_doctor.checks.autogen import AutogenNumeroCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(AutogenNumeroCheck().run(Project()))


def test_unsafe_int_split_is_flagged():
    findings = _run()
    matching = [
        f for f in findings
        if "UnsafeAutoNumero" in f.location
        and f.rule == "autogen.unsafe_int_split"
    ]
    assert matching, "UnsafeAutoNumero.save() should be flagged"
    f = matching[0]
    assert f.severity is Severity.ERROR
    assert "int(" in f.message
    assert "try/except" in f.message


def test_wrapped_try_except_silences_the_finding():
    findings = _run()
    matching = [
        f for f in findings
        if "SafeAutoNumero" in f.location
    ]
    assert not matching, (
        f"SafeAutoNumero wraps the parse in try/except and must not be flagged; got {matching}"
    )


def test_models_without_int_split_are_ignored():
    """Widget and SilentWidget have no auto-gen logic — neither must be flagged."""
    findings = _run()
    for name in ("Widget", "SilentWidget", "DangerousFK"):
        assert not any(
            f.location.endswith(f".{name}.save:")
            or f".{name}.save:" in f.location
            for f in findings
        ), f"{name} has no int().split() pattern and must not be flagged"
