"""Regression tests for the forms_meta coherence check.

Scenario: a ModelForm's ``clean()`` assigns to ``cleaned_data[key]`` where
``key`` is NOT in ``Meta.fields`` and the underlying model column is NOT
NULL. Django's default ``form.save()`` silently drops the value — the next
``.save()`` raises ``IntegrityError``. This happened on OperationTVAForm on
altiusone and motivated django-test-doctor v0.5.
"""

import pytest

from django_doctor import Severity
from django_doctor.checks.forms_meta import FormsMetaCoherenceCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(FormsMetaCoherenceCheck().run(Project()))


def test_orphan_cleaned_data_assignment_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if "OrphanCleanedDataForm" in f.location
        and f.rule == "forms.cleaned_data.orphan"
    ]
    assert matching, "OrphanCleanedDataForm should have been flagged"
    f = matching[0]
    assert f.severity is Severity.ERROR
    assert "'fonction'" in f.message
    assert "NOT NULL" in f.message


def test_save_override_silences_the_finding():
    """If the form has a save() override the author likely handles the orphan
    value themselves — we must not flag false positives."""
    findings = _run()
    matching = [
        f
        for f in findings
        if "OrphanCleanedDataWithSaveOverrideForm" in f.location
    ]
    assert not matching, (
        f"forms with save() override must not be flagged; got {matching}"
    )


def test_good_form_is_not_flagged():
    findings = _run()
    assert not any(
        "GoodForm" in f.location and f.rule == "forms.cleaned_data.orphan"
        for f in findings
    )
