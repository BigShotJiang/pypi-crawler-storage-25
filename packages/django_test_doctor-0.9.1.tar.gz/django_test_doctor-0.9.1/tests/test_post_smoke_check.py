"""Regression tests for the post_smoke check.

The scenario the hikimatech bug (a post_save signal raising IntegrityError
on ``/fr/mandats/nouveau/``) is exactly ``BadSaveCreateView`` below: the
view itself answers 200 on GET, renders the form, parses the POST, reaches
``form_valid`` — and only then crashes. A GET-only check doesn't see it.
"""

import pytest

from django_doctor import Severity
from django_doctor.checks.post_smoke import PostSmokeCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(PostSmokeCheck().run(Project()))


def test_healthy_create_view_is_not_flagged():
    findings = _run()
    assert not any(
        "WidgetCreateView" in f.location and f.severity >= Severity.ERROR
        for f in findings
    ), "Healthy CreateView should not surface a critical finding"


def test_bad_save_view_is_flagged_critical():
    """post_smoke must catch the same class of bug as the hikimatech 500."""
    findings = _run()
    matching = [f for f in findings if "BadSaveCreateView" in f.location]
    assert matching, "BadSaveCreateView should have been flagged"
    assert matching[0].severity is Severity.CRITICAL
    assert "intentional failure" in matching[0].message.lower() or (
        "http 5" in matching[0].message.lower()
    )


def test_silently_dropped_create_is_flagged_stale_db():
    """A CreateView that redirects 302 without actually saving the row must
    be caught by the persistence assertion — the most insidious bug shape:
    user sees 'success', the DB has nothing."""
    findings = _run()
    matching = [
        f for f in findings
        if "SilentlyDroppedCreateView" in f.location
        and f.rule == "post_smoke.stale_db.create"
    ]
    assert matching, "SilentlyDroppedCreateView should have been flagged"
    assert matching[0].severity is Severity.CRITICAL
    assert "no new Widget" in matching[0].message


def test_silently_dropped_update_is_flagged_stale_db():
    """An UpdateView that returns 302 success without persisting the POSTed
    values must be caught — exact shape of the altiusone Studio bug."""
    from tests.sample_app.models import Widget

    # Seed a target row so the URL kwargs resolver has something to point at.
    Widget.objects.create(name="seed", fonction="existing")
    findings = _run()
    matching = [
        f for f in findings
        if "SilentlyDroppedUpdateView" in f.location
        and f.rule == "post_smoke.stale_db.update"
    ]
    assert matching, "SilentlyDroppedUpdateView should have been flagged"
    assert matching[0].severity is Severity.CRITICAL
    # At least one of the form fields (name / fonction) should appear in
    # the "not persisted" list.
    assert "fields_not_persisted" in matching[0].extra
    assert matching[0].extra["fields_not_persisted"]
