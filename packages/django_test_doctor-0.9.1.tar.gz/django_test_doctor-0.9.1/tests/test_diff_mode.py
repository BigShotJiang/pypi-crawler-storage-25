"""Regression tests for --diff filtering."""

import os
import subprocess
from pathlib import Path

import pytest

from django_doctor import Severity
from django_doctor.diff import changed_files, filter_by_diff
from django_doctor.finding import Finding
from django_doctor.registry import Check


class _StubCheck(Check):
    id = "stub"


def _git(cwd, *args):
    return subprocess.run(
        ["git", "-C", str(cwd), *args],
        capture_output=True, text=True, check=True,
    )


@pytest.fixture
def tmp_repo(tmp_path):
    """Minimal git repo with one committed file + one modified file."""
    _git(tmp_path, "init", "-q", "-b", "main")
    _git(tmp_path, "config", "user.email", "doctor@example.com")
    _git(tmp_path, "config", "user.name", "doctor")
    (tmp_path / "base.py").write_text("# baseline\n")
    _git(tmp_path, "add", ".")
    _git(tmp_path, "commit", "-q", "-m", "baseline")
    (tmp_path / "changed.py").write_text("# new file\n")
    _git(tmp_path, "add", "changed.py")
    _git(tmp_path, "commit", "-q", "-m", "feature")
    return tmp_path


def test_changed_files_returns_added_file(tmp_repo):
    files = changed_files("HEAD~1", repo_root=tmp_repo)
    assert any("changed.py" in f for f in files)


def test_changed_files_returns_empty_for_missing_repo(tmp_path):
    assert changed_files("HEAD", repo_root=tmp_path) == set()


def test_filter_by_diff_keeps_findings_on_changed_files(tmp_repo):
    check = _StubCheck()
    results = [
        (check, Finding(
            severity=Severity.ERROR,
            check_id="stub",
            location=f"{tmp_repo}/changed.py:10",
            message="on changed",
        )),
        (check, Finding(
            severity=Severity.ERROR,
            check_id="stub",
            location=f"{tmp_repo}/base.py:5",
            message="on baseline",
        )),
    ]
    cwd = os.getcwd()
    try:
        os.chdir(tmp_repo)
        filtered = filter_by_diff(results, "HEAD~1", repo_root=tmp_repo)
    finally:
        os.chdir(cwd)
    messages = [f.message for _, f in filtered]
    assert "on changed" in messages
    assert "on baseline" not in messages


def test_filter_by_diff_keeps_findings_without_file_path(tmp_repo):
    check = _StubCheck()
    results = [
        (check, Finding(
            severity=Severity.ERROR,
            check_id="stub",
            location="users:login",
            message="no file path",
        )),
    ]
    filtered = filter_by_diff(results, "HEAD~1", repo_root=tmp_repo)
    assert len(filtered) == 1
