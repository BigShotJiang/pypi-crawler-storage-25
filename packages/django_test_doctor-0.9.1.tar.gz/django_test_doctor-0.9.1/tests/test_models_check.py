"""Regression tests for the models hygiene check."""

import pytest

from django_doctor import Severity
from django_doctor.checks.models import ModelHygieneCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(ModelHygieneCheck().run(Project()))


def test_model_with_custom_str_is_not_flagged_for_str():
    findings = _run()
    assert not any(
        "Widget" in f.location
        and "DangerousFK" not in f.location
        and "SilentWidget" not in f.location
        and f.rule == "models.str_missing"
        for f in findings
    )


def test_missing_str_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if "SilentWidget" in f.location and f.rule == "models.str_missing"
    ]
    assert matching, "SilentWidget without __str__ should surface a finding"
    assert matching[0].severity is Severity.WARNING


def test_set_null_on_non_null_fk_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if "DangerousFK" in f.location and f.rule == "models.set_null_on_non_null_fk"
    ]
    assert matching, "DangerousFK.parent should surface a SET_NULL finding"
    assert matching[0].severity is Severity.ERROR
