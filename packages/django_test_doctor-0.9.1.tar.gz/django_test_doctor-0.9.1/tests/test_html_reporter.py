"""Regression tests for the HTML reporter."""

from django_doctor import Severity
from django_doctor.finding import Finding
from django_doctor.registry import Check
from django_doctor.report_html import render_html


class _StubCheck(Check):
    id = "stub"


def test_empty_report_shows_all_clean_message():
    html = render_html([])
    assert "All checks passed" in html
    assert "<!doctype html>" in html
    assert "<html" in html


def test_findings_render_with_severity_classes():
    finding = Finding(
        severity=Severity.ERROR,
        check_id="stub",
        rule="stub.demo",
        location="app/views.py:42",
        message="something broke",
        fix_hint="fix it",
    )
    html = render_html([(_StubCheck(), finding)])
    assert "app/views.py:42" in html
    assert "something broke" in html
    assert "fix it" in html
    assert 'class="sev error"' in html


def test_summary_counts_by_severity():
    check = _StubCheck()
    results = [
        (check, Finding(severity=Severity.ERROR, check_id="stub", message="e")),
        (check, Finding(severity=Severity.ERROR, check_id="stub", message="e")),
        (check, Finding(severity=Severity.WARNING, check_id="stub", message="w")),
    ]
    html = render_html(results)
    assert "2 error" in html
    assert "1 warning" in html


def test_message_and_hint_are_html_escaped():
    finding = Finding(
        severity=Severity.WARNING,
        check_id="stub",
        message="<script>alert(1)</script>",
        fix_hint="<b>bold</b>",
    )
    html = render_html([(_StubCheck(), finding)])
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in html
    assert "&lt;b&gt;bold&lt;/b&gt;" in html
