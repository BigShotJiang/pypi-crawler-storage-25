from django.apps import AppConfig


class SampleAppConfig(AppConfig):
    name = "tests.sample_app"
    label = "sample_app"
