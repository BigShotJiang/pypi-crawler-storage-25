"""DRF serializer fixtures for the drf check regression tests."""

from rest_framework import serializers

from .models import Widget


class GoodWidgetSerializer(serializers.ModelSerializer):
    """Every field in Meta.fields really exists on Widget."""

    class Meta:
        model = Widget
        fields = ["id", "name", "fonction"]


class TypoSerializer(serializers.ModelSerializer):
    """Meta.fields lists `fnction` (typo) — must be flagged."""

    class Meta:
        model = Widget
        fields = ["id", "name", "fnction"]


class BrokenInitSerializer(serializers.Serializer):
    """Blank init raises — must be flagged as ERROR."""

    name = serializers.CharField()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Intentional: touching .choices on a plain CharField raises AttributeError
        _ = self.fields["name"].choices
