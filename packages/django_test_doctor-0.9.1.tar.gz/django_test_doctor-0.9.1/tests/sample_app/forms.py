from django import forms

from .models import Widget


class GoodForm(forms.ModelForm):
    """Baseline — this one instantiates cleanly."""

    class Meta:
        model = Widget
        fields = ["name", "fonction"]


class NeedsUserForm(forms.Form):
    """Reproduces Django's SetPasswordForm pattern: __init__ requires `user`.
    The doctor must downgrade this to INFO, not ERROR."""

    new_password = forms.CharField()

    def __init__(self, user, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user


class OrphanCleanedDataForm(forms.ModelForm):
    """Reproduces the OperationTVAForm bug caught on altiusone 2026-04-20:
    clean() assigns to cleaned_data['fonction'] but the key isn't in
    Meta.fields and the model column is NOT NULL. form.save() silently
    drops the value -> IntegrityError. Must be flagged by forms_meta check."""

    class Meta:
        model = Widget
        fields = ["name"]  # deliberately omits `fonction`

    def clean(self):
        cleaned_data = super().clean()
        cleaned_data["fonction"] = "computed-value"  # <-- orphan assignment
        return cleaned_data


class OrphanCleanedDataWithSaveOverrideForm(forms.ModelForm):
    """Same shape as OrphanCleanedDataForm but with a save() override that
    writes the orphan value to the instance. forms_meta check must NOT flag
    this one — the author knows what they're doing."""

    class Meta:
        model = Widget
        fields = ["name"]

    def clean(self):
        cleaned_data = super().clean()
        cleaned_data["fonction"] = "computed-value"
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.fonction = self.cleaned_data["fonction"]
        if commit:
            instance.save()
        return instance


class BrokenBlankInitForm(forms.ModelForm):
    """Reproduces the exact 0.0.9 production bug.

    ``Widget.fonction`` is a CharField with no ``choices=``, so the field
    has no ``.choices`` attribute. Instantiating this form therefore raises
    AttributeError — which is exactly what the ``forms`` check should flag.
    """

    class Meta:
        model = Widget
        fields = ["name", "fonction"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["fonction"].choices = [("", "---")] + list(
            self.fields["fonction"].choices
        )
