from django.urls import path

from . import views

urlpatterns = [
    path("healthy/", views.healthy, name="healthy"),
    path("boom/", views.boom, name="boom"),
    path("needs-login/", views.needs_login, name="needs-login"),
    # CBVs used by the post_smoke check.
    path("widgets/new/", views.WidgetCreateView.as_view(), name="widget-create"),
    path("widgets/bad/", views.BadSaveCreateView.as_view(), name="widget-bad-create"),
    # Fixtures for the views check.
    path("unguarded/", views.unguarded_view, name="unguarded"),
    path("guarded-fbv/", views.guarded_fbv, name="guarded-fbv"),
    path("guarded-cbv/", views.GuardedCBV.as_view(), name="guarded-cbv"),
    path("unguarded-cbv/", views.UnguardedCBV.as_view(), name="unguarded-cbv"),
    # Fixture for the URL kwargs generator.
    path("widgets/<int:pk>/", views.WidgetDetailView.as_view(), name="widget-detail"),
    # Fixtures for post_smoke persistence assertions (v0.9+).
    path(
        "widgets/silent-create/",
        views.SilentlyDroppedCreateView.as_view(),
        name="widget-silent-create",
    ),
    path(
        "widgets/<int:pk>/silent-update/",
        views.SilentlyDroppedUpdateView.as_view(),
        name="widget-silent-update",
    ),
]
