"""Admin registrations used by the ``admin`` check regression tests."""

from django.contrib import admin

from .models import SilentWidget, Widget


@admin.register(Widget)
class WidgetAdmin(admin.ModelAdmin):
    """Healthy admin — every field in list_display really exists."""

    list_display = ("name", "fonction")
    list_filter = ("fonction",)
    search_fields = ("name",)


@admin.register(SilentWidget)
class SilentWidgetAdmin(admin.ModelAdmin):
    """Reproduces the typical typo bug — ``fnction`` instead of ``name``."""

    list_display = ("name", "fnction")  # "fnction" does not exist
    search_fields = ("nmae",)  # typo
    ordering = ("nonexistent",)
