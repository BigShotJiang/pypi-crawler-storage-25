from django.db import models


class Widget(models.Model):
    """Intentionally simple — stands in for a project model in the suite."""

    name = models.CharField(max_length=100)
    # fonction = a free-form CharField that stores a code (no `choices=`).
    # This mirrors Contact.fonction in Altiusone and lets us reproduce the
    # production bug that motivated django-doctor in the first place.
    fonction = models.CharField(max_length=50)

    def __str__(self) -> str:
        return self.name


class SilentWidget(models.Model):
    """Missing custom __str__ and Meta.ordering — regression fixture for the
    ``models`` check. Do not add __str__ to this model."""

    name = models.CharField(max_length=100)


class DangerousFK(models.Model):
    """FK with on_delete=SET_NULL but null=False — prod IntegrityError waiting
    to happen. Regression fixture for the ``models`` check."""

    parent = models.ForeignKey(
        Widget, on_delete=models.SET_NULL, null=False, related_name="dangerous"
    )

    def __str__(self) -> str:
        return f"DangerousFK #{self.pk}"

    class Meta:
        ordering = ("pk",)


class UnsafeAutoNumero(models.Model):
    """Reproduces the altiusone hikimatech bug: ``Mandat.save()`` did
    ``int(last.numero.split('-')[-1])`` without try/except. A single row
    like ``MAN-2026-CIB`` crashed every subsequent auto-gen. Fixture for
    the ``autogen`` check — must be flagged."""

    numero = models.CharField(max_length=50, blank=True)
    name = models.CharField(max_length=50)

    class Meta:
        ordering = ("pk",)

    def __str__(self) -> str:
        return self.numero or self.name

    def save(self, *args, **kwargs):
        if not self.numero:
            last = UnsafeAutoNumero.objects.order_by("numero").last()
            if last:
                last_num = int(last.numero.split("-")[-1])  # <-- unsafe
                self.numero = f"U-{last_num + 1:03d}"
            else:
                self.numero = "U-001"
        super().save(*args, **kwargs)


class SafeAutoNumero(models.Model):
    """Same idea as UnsafeAutoNumero but with try/except around the parse —
    the autogen check must NOT flag this one."""

    numero = models.CharField(max_length=50, blank=True)
    name = models.CharField(max_length=50)

    class Meta:
        ordering = ("pk",)

    def __str__(self) -> str:
        return self.numero or self.name

    def save(self, *args, **kwargs):
        if not self.numero:
            last = SafeAutoNumero.objects.order_by("numero").last()
            max_num = 0
            if last:
                try:
                    max_num = int(last.numero.split("-")[-1])
                except (ValueError, IndexError):
                    max_num = 0
            self.numero = f"S-{max_num + 1:03d}"
        super().save(*args, **kwargs)


class ComputedTotals(models.Model):
    """Reproduces the altiusone hikimatech Studio bug (2026-04-21): save()
    unconditionally recomputes ``total_ht``/``total_tva``/``total_ttc`` from
    ``quantite`` × ``prix_unitaire``. Any caller passing
    ``update_fields=['quantite']`` writes only ``quantite`` and drops the
    three recomputed totals — DB keeps stale zeros. Fixture for the
    ``update_fields`` check."""

    from decimal import Decimal as _D

    quantite = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    prix_unitaire = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    taux_tva = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    total_ht = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_tva = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_ttc = models.DecimalField(max_digits=15, decimal_places=2, default=0)

    class Meta:
        ordering = ("pk",)

    def __str__(self) -> str:
        return f"ComputedTotals #{self.pk}"

    def save(self, *args, **kwargs):
        self.total_ht = self.quantite * self.prix_unitaire
        self.total_tva = self.total_ht * self.taux_tva / 100
        self.total_ttc = self.total_ht + self.total_tva
        super().save(*args, **kwargs)


