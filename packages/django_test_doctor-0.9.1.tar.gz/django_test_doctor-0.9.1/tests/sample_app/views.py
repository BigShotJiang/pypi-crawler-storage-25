from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse
from django.urls import reverse_lazy
from django.views import View
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView

from .forms import GoodForm
from .models import Widget


def healthy(request):
    return HttpResponse("ok")


def boom(request):
    raise RuntimeError("intentional 500 for the URL smoke check")


def needs_login(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=302)
    return HttpResponse("ok")


def unguarded_view(request):
    """FBV with no auth decorator — views check must flag this."""
    return HttpResponse("public by accident")


@login_required
def guarded_fbv(request):
    """FBV protected by @login_required — views check must NOT flag."""
    return HttpResponse("ok")


class GuardedCBV(LoginRequiredMixin, View):
    """CBV with LoginRequiredMixin — views check must NOT flag."""

    def get(self, request):
        return HttpResponse("ok")


class UnguardedCBV(View):
    """CBV with no guard — views check must flag."""

    def get(self, request):
        return HttpResponse("public by accident")


class WidgetDetailView(DetailView):
    """DetailView with <int:pk> — fixture for the URL kwargs generator."""

    model = Widget
    template_name = "widget_form.html"


# ---------------------------------------------------------------------------
# Fixtures for the update_fields check — the altiusone Studio bug shape.
# ---------------------------------------------------------------------------


def unsafe_update_quantity(pk, new_value):
    """Reproduces the altiusone Studio bug (2026-04-21) — call site that
    drops computed totals. The update_fields check must flag the save()
    call on the line below."""
    from .models import ComputedTotals

    row = ComputedTotals.objects.get(pk=pk)
    row.quantite = new_value
    # DANGEROUS: ComputedTotals.save() unconditionally recomputes
    # total_ht/tva/ttc from quantite × prix_unitaire, but update_fields
    # restricts the UPDATE to just "quantite". Recomputed values lost.
    row.save(update_fields=["quantite"])


def safe_update_quantity(pk, new_value):
    """Same scenario, safe pattern — full save. The check must NOT flag."""
    from .models import ComputedTotals

    row = ComputedTotals.objects.get(pk=pk)
    row.quantite = new_value
    row.save()  # full save, all recomputed totals persisted


def safe_update_quantity_with_all_fields(pk, new_value):
    """Same scenario, update_fields includes every recomputed field. The
    check must NOT flag — the caller knows what the model computes."""
    from .models import ComputedTotals

    row = ComputedTotals.objects.get(pk=pk)
    row.quantite = new_value
    row.save(update_fields=[
        "quantite", "total_ht", "total_tva", "total_ttc",
    ])


class WidgetCreateView(CreateView):
    """Healthy CBV — post_smoke should NOT flag it."""

    model = Widget
    form_class = GoodForm
    template_name = "widget_form.html"
    success_url = "/healthy/"


class BadSaveCreateView(CreateView):
    """CBV whose save() crashes — post_smoke must flag it as critical."""

    model = Widget
    form_class = GoodForm
    template_name = "widget_form.html"
    success_url = "/healthy/"

    def form_valid(self, form):
        # Mimics the hikimatech bug: the view itself is fine but a call
        # downstream (post_save signal, related create, …) raises.
        raise RuntimeError("intentional failure inside form_valid")


class SilentlyDroppedCreateView(CreateView):
    """CreateView that returns 302 success WITHOUT actually saving. Models
    the "form_valid forgot to call super()" bug — the user gets a green
    checkmark, the DB has no row. post_smoke must flag stale_db.create."""

    model = Widget
    form_class = GoodForm
    template_name = "widget_form.html"
    success_url = "/healthy/"

    def form_valid(self, form):
        from django.http import HttpResponseRedirect

        return HttpResponseRedirect(self.success_url)


class SilentlyDroppedUpdateView(UpdateView):
    """UpdateView that returns 302 success WITHOUT persisting the POSTed
    values. Models save(update_fields=[wrong_field]) or a form_valid that
    skips save() entirely. post_smoke must flag stale_db.update."""

    model = Widget
    form_class = GoodForm
    fields = None  # defer to form_class
    template_name = "widget_form.html"
    success_url = "/healthy/"

    def form_valid(self, form):
        from django.http import HttpResponseRedirect

        # Note: no form.save() / super().form_valid() here. The row is left
        # untouched but we still redirect as if we succeeded.
        return HttpResponseRedirect(self.success_url)
