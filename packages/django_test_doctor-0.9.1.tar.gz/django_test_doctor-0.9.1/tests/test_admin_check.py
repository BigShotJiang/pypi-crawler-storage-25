"""Prove admin check flags bogus list_display / search_fields / ordering entries."""

import pytest

from django_doctor import Severity
from django_doctor.checks.admin import AdminConsistencyCheck
from django_doctor.registry import Project

# Importing the module triggers @admin.register() decorators — they need the
# registry populated before the check runs.
from tests.sample_app import admin  # noqa: F401


pytestmark = pytest.mark.django_db


def _run():
    return list(AdminConsistencyCheck().run(Project()))


def test_healthy_admin_is_not_flagged():
    findings = _run()
    assert not any(f.location.endswith(".WidgetAdmin") for f in findings)


def test_typo_in_list_display_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if "SilentWidgetAdmin" in f.location and "list_display" in f.rule
    ]
    assert matching, "SilentWidgetAdmin's bogus list_display should have surfaced"
    assert matching[0].severity is Severity.ERROR
    assert "fnction" in matching[0].message


def test_typo_in_search_fields_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if "SilentWidgetAdmin" in f.location and "search_fields" in f.rule
    ]
    assert matching, "SilentWidgetAdmin's bogus search_fields should have surfaced"


def test_typo_in_ordering_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if "SilentWidgetAdmin" in f.location and "ordering" in f.rule
    ]
    assert matching, "SilentWidgetAdmin's bogus ordering should have surfaced"
