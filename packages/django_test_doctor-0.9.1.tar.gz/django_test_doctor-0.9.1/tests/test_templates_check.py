"""Regression tests for the templates coherence check."""

import pytest

from django_doctor import Severity
from django_doctor.checks.templates import TemplateCoherenceCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run(**cfg):
    project = Project(config={"templates": {"check_static": False, **cfg}})
    return list(TemplateCoherenceCheck().run(project))


def test_broken_url_name_is_flagged_error():
    findings = _run()
    matching = [
        f for f in findings
        if f.rule == "templates.url.unknown"
        and "does-not-exist-anywhere" in f.message
    ]
    assert matching, "broken {% url %} reference should have been flagged"
    assert matching[0].severity is Severity.ERROR


def test_valid_url_is_not_flagged():
    findings = _run()
    assert not any(
        f.rule == "templates.url.unknown" and "'healthy'" in f.message
        for f in findings
    ), "healthy URL reference must not produce a finding"


def test_missing_static_is_flagged_warning():
    # Enable static checking for this one.
    project = Project(config={"templates": {"check_static": True}})
    findings = list(TemplateCoherenceCheck().run(project))
    matching = [
        f for f in findings
        if f.rule == "templates.static.missing"
        and "nonexistent-asset.png" in f.message
    ]
    assert matching, "missing static asset should have been flagged"
    assert matching[0].severity is Severity.WARNING
