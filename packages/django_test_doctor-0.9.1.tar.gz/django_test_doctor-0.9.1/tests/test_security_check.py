"""Regression tests for the security check (SECRET_KEY + DEBUG + ALLOWED_HOSTS)."""

import pytest

from django_doctor import Severity
from django_doctor.checks.security import SecurityCheck
from django_doctor.registry import Project


def _run(config=None):
    project = Project(config={"security": config or {}})
    return list(SecurityCheck().run(project))


def test_weak_secret_key_is_flagged(settings):
    settings.SECRET_KEY = "django-insecure-abcdef1234567890" * 2
    findings = _run()
    matching = [f for f in findings if f.rule == "security.secret_key_weak"]
    assert matching, "django-insecure prefix should surface a CRITICAL finding"
    assert matching[0].severity is Severity.CRITICAL


def test_strong_secret_key_is_accepted(settings):
    # 64 random bytes, none of the forbidden substrings
    settings.SECRET_KEY = "xK9pQr2mW3nY6tZ8vL5bC1hJ4dF7sA0eU" + "B8kM3oV6rT9nE2yG5uH7qW1pX4sL0jZ"
    findings = _run()
    assert not any(f.rule.startswith("security.secret_key_") for f in findings), (
        "a strong SECRET_KEY should not trigger any key-related finding"
    )


def test_debug_true_emits_warning(settings):
    settings.DEBUG = True
    findings = _run()
    matching = [f for f in findings if f.rule == "security.debug_true"]
    assert matching, "DEBUG=True should warn"
    assert matching[0].severity is Severity.WARNING


def test_empty_allowed_hosts_in_prod_is_error(settings):
    settings.DEBUG = False
    settings.ALLOWED_HOSTS = []
    findings = _run()
    matching = [f for f in findings if f.rule == "security.allowed_hosts_empty"]
    assert matching, "empty ALLOWED_HOSTS with DEBUG=False should surface"
    assert matching[0].severity is Severity.ERROR
