"""Regression tests for the URL kwargs fixture generator."""

import re
import uuid

import pytest

from django_doctor.fixtures import make_url_kwargs
from tests.sample_app.models import Widget
from tests.sample_app.views import WidgetDetailView


pytestmark = pytest.mark.django_db


def test_empty_route_returns_empty_dict():
    assert make_url_kwargs("healthy/", None) == {}


def test_int_fallback_when_no_view_class():
    kwargs = make_url_kwargs("items/<int:pk>/", None)
    assert kwargs == {"pk": 1}


def test_uuid_fallback_is_a_valid_uuid():
    kwargs = make_url_kwargs("items/<uuid:id>/", None)
    assert "id" in kwargs
    uuid.UUID(str(kwargs["id"]))  # raises if not a valid UUID


def test_slug_fallback():
    kwargs = make_url_kwargs("items/<slug:slug>/", None)
    assert kwargs == {"slug": "x"}


def test_model_backed_view_uses_existing_instance():
    widget = Widget.objects.create(name="test", fonction="manager")
    kwargs = make_url_kwargs("widgets/<int:pk>/", WidgetDetailView)
    assert kwargs == {"pk": widget.pk}


def test_empty_queryset_falls_back_to_literal():
    # No widget in DB, model._try_create_minimal builds one automatically.
    kwargs = make_url_kwargs("widgets/<int:pk>/", WidgetDetailView)
    assert "pk" in kwargs
    assert isinstance(kwargs["pk"], int)
