"""Prove the URL smoke check fails on 5xx but not on 302 / 200."""

import pytest

from django_doctor import Severity
from django_doctor.checks.urls import UrlSmokeCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run(**urls_cfg):
    project = Project(config={"urls": {"roles": ["anonymous"], **urls_cfg}})
    return list(UrlSmokeCheck().run(project))


def test_healthy_url_is_not_flagged():
    findings = _run()
    assert not any("healthy" in f.location for f in findings)


def test_url_that_raises_is_flagged_critical():
    findings = _run()
    matching = [f for f in findings if "boom" in f.location]
    assert matching, "the boom view should have surfaced a finding"
    assert matching[0].severity is Severity.CRITICAL


def test_redirect_is_not_a_finding():
    findings = _run()
    assert not any("needs-login" in f.location for f in findings)
