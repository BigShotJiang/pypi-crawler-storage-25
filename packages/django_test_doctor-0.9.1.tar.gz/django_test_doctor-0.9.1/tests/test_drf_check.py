"""Regression tests for the DRF serializer check."""

import pytest

from django_doctor import Severity
from django_doctor.checks.drf import DrfSerializerCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(DrfSerializerCheck().run(Project()))


def test_healthy_serializer_is_not_flagged():
    findings = _run()
    assert not any(f.location.endswith(".GoodWidgetSerializer") for f in findings)


def test_typo_in_meta_fields_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if f.location.endswith(".TypoSerializer")
        and f.rule == "drf.meta_fields.missing"
    ]
    assert matching, "TypoSerializer bogus field should have surfaced"
    assert matching[0].severity is Severity.ERROR
    assert "fnction" in matching[0].message


def test_broken_init_serializer_is_flagged():
    findings = _run()
    matching = [
        f
        for f in findings
        if f.location.endswith(".BrokenInitSerializer")
        and f.rule == "drf.blank_init"
    ]
    assert matching, "BrokenInitSerializer should have surfaced"
    assert matching[0].severity is Severity.ERROR
    assert "AttributeError" in matching[0].message
