"""The regression test that would have saved Altiusone's 0.0.9 release."""

import pytest

from django_doctor import Severity
from django_doctor.checks.forms import FormInstantiationCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(FormInstantiationCheck().run(Project()))


def test_good_form_is_not_flagged():
    findings = _run()
    assert not any(
        "GoodForm" in f.location and f.severity >= Severity.WARNING for f in findings
    )


def test_broken_blank_init_form_is_flagged():
    """The bug that motivated this package: a form that crashes at init()."""
    findings = _run()
    matching = [f for f in findings if "BrokenBlankInitForm" in f.location]
    assert matching, "BrokenBlankInitForm should have been flagged but wasn't"
    finding = matching[0]
    assert finding.severity is Severity.ERROR
    assert "AttributeError" in finding.message
    assert "blank instantiation" in finding.message
    assert finding.rule == "forms.blank_init"


def test_form_needing_extra_args_is_info_not_error():
    """Forms like SetPasswordForm require `user` — not a bug, just INFO."""
    findings = _run()
    matching = [f for f in findings if "NeedsUserForm" in f.location]
    assert matching, "NeedsUserForm should surface an INFO finding"
    for f in matching:
        assert f.severity is Severity.INFO, (
            f"missing-required-arg forms must be INFO, got {f.severity.name}: {f.message}"
        )
        assert f.rule.endswith(".needs_args")
        assert "requires extra args" in f.message


def test_form_is_not_double_reported():
    """One form + two scenarios = exactly 2 findings, not 4 (no dedup regression)."""
    findings = _run()
    broken = [f for f in findings if f.location.endswith(".BrokenBlankInitForm")]
    assert len(broken) == 2, (
        f"expected 2 findings (blank + empty_data), got {len(broken)}: "
        f"{[f.rule for f in broken]}"
    )
    rules = {f.rule for f in broken}
    assert rules == {"forms.blank_init", "forms.empty_data"}
