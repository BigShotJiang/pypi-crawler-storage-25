"""Regression tests for the update_fields check.

Scenario: a model's ``save()`` unconditionally recomputes fields, but a
caller passes ``update_fields=[subset]`` that omits them — Django writes
only the subset, the DB stays stale. Exactly the altiusone hikimatech
Studio bug that motivated this check (2026-04-21).
"""

import pytest

from django_doctor import Severity
from django_doctor.checks.update_fields import UnsafeUpdateFieldsCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(UnsafeUpdateFieldsCheck().run(Project()))


def test_unsafe_caller_is_flagged():
    findings = _run()
    matching = [
        f for f in findings
        if "views.py" in f.location
        and f.rule == "update_fields.drops_computed"
        and "ComputedTotals" in f.message
    ]
    assert matching, "unsafe_update_quantity() should have been flagged"
    f = matching[0]
    assert f.severity is Severity.ERROR
    # The message should name the specific missing fields.
    for missing in ("total_ht", "total_tva", "total_ttc"):
        assert missing in f.message, (
            f"expected {missing!r} in finding message, got: {f.message}"
        )


def test_safe_full_save_is_not_flagged():
    findings = _run()
    assert not any(
        "safe_update_quantity" in (f.location or "") and "drops_computed" in f.rule
        for f in findings
    ), "safe_update_quantity() calls .save() without update_fields and must not be flagged"


def test_safe_save_with_all_computed_fields_is_not_flagged():
    """When update_fields already contains every recomputed field, the
    check must not flag — the caller explicitly knows what's recomputed."""
    findings = _run()
    for f in findings:
        if "safe_update_quantity_with_all_fields" in (f.location or ""):
            raise AssertionError(
                "Caller that already includes total_ht/tva/ttc in "
                f"update_fields must not be flagged; got: {f.message}"
            )
