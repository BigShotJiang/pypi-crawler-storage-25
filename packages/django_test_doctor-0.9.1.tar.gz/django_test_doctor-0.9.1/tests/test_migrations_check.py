"""Regression tests for migrations drift detection + third-party skip."""

import pytest

from django_doctor.checks.migrations import (
    MigrationStateCheck,
    _first_party_app_labels,
)
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def test_first_party_excludes_django_contrib():
    """Contrib apps live in site-packages and must not be considered first-party."""
    labels = _first_party_app_labels()
    for contrib in ("auth", "contenttypes", "admin", "sessions", "messages"):
        assert contrib not in labels, (
            f"{contrib} should not be first-party; found in {labels}"
        )


def test_sample_app_is_first_party():
    assert "sample_app" in _first_party_app_labels()


def test_default_run_does_not_flag_contrib_apps():
    """Without `include_third_party=True`, drift in auth/admin/... is silenced."""
    findings = list(MigrationStateCheck().run(Project()))
    contrib_labels = {"auth", "admin", "contenttypes", "sessions", "messages"}
    for f in findings:
        assert f.location.split(".", 1)[0] not in contrib_labels, (
            f"contrib drift leaked: {f.location} — {f.message}"
        )


def test_drift_detection_matches_makemigrations_verdict():
    """Our check must agree with `makemigrations --check --dry-run` on the
    first-party app set. sample_app has up-to-date migrations → zero findings."""
    from django_doctor.checks.migrations import _drifted_apps

    drifted = _drifted_apps()
    # sample_app is fully migrated; no drift should be reported there.
    assert "sample_app" not in drifted, (
        f"sample_app should not drift, got: {drifted}"
    )
