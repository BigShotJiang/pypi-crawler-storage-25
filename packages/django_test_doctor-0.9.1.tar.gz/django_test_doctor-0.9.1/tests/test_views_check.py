"""Regression tests for the views authorization check."""

import pytest

from django_doctor import Severity
from django_doctor.checks.views import ViewAuthorizationCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run(**cfg):
    project = Project(config={"views": cfg} if cfg else {})
    return list(ViewAuthorizationCheck().run(project))


def test_unguarded_fbv_is_flagged():
    findings = _run()
    matching = [f for f in findings if "unguarded_view" in f.location]
    assert matching, "FBV with no decorator should have been flagged"
    assert matching[0].severity is Severity.WARNING
    assert matching[0].rule == "views.unguarded"


def test_guarded_fbv_is_not_flagged():
    findings = _run()
    assert not any("guarded_fbv" in f.location for f in findings)


def test_guarded_cbv_is_not_flagged():
    findings = _run()
    assert not any("GuardedCBV" in f.location for f in findings)


def test_unguarded_cbv_is_flagged():
    findings = _run()
    matching = [f for f in findings if "UnguardedCBV" in f.location]
    assert matching, "CBV without LoginRequiredMixin should have been flagged"


def test_public_whitelist_silences_url():
    # 'unguarded' is flagged by default, but whitelisting the URL name silences it.
    findings = _run(public=["unguarded"])
    assert not any("unguarded_view" in f.location for f in findings)
