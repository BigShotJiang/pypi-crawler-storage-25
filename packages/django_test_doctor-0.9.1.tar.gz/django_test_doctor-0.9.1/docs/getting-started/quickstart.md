# Quick Start

## Full audit

```bash
./manage.py doctor
```

Runs every registered check and prints a rich terminal report. Example tail:

```
╭──────────── Summary ────────────╮
│ 2 critical · 20 warning · 6 info │
╰─────────────────────────────────╯
```

## Target a specific layer

Each check has a short `id`. Combine them with commas:

```bash
./manage.py doctor --section forms,post_smoke,forms_meta
```

## CI mode

Exits with a non-zero status when any finding has severity `error` or
`critical` (configurable via `fail_on`):

```bash
./manage.py doctor --ci
```

## JSON output

For piping into dashboards or artifact storage:

```bash
./manage.py doctor --json | jq '.[] | select(.severity=="critical")'
```

## Skip slow checks

`urls` and `post_smoke` walk every URL pattern and can take a minute on a
300-route project. Skip them for a fast pre-commit sanity run:

```bash
./manage.py doctor --quick
```

## HTML report

Write a standalone self-contained HTML page — useful as a CI artifact or
to email around:

```bash
./manage.py doctor --html artifacts/doctor-report.html
```

See [HTML report](../guides/html-report.md) for details.

## PR-scoped findings

Only surface findings that touch files changed since a git reference —
perfect for reviewing your own PR without drowning in existing debt:

```bash
./manage.py doctor --diff origin/main
```

See [PR-scoped findings](../guides/diff-mode.md) for the full recipe.

## Typical pre-merge CI step

=== "GitHub Actions"

    ```yaml
    - name: django-test-doctor
      run: |
        ./manage.py doctor \
          --diff origin/${{ github.base_ref }} \
          --ci \
          --html doctor-report.html
    ```

=== "GitLab CI"

    ```yaml
    doctor:
      script: ./manage.py doctor --diff origin/$CI_MERGE_REQUEST_TARGET_BRANCH_NAME --ci --html doctor-report.html
    ```

## What next

- [Tune the defaults](configuration.md)
- [Write a custom check](../guides/custom-checks.md)
