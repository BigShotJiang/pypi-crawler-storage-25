# Installation

## Requirements

- Python 3.10+
- Django 4.2+ (tested against 4.2, 5.0, 5.1, 6.0)

## Install

```bash
pip install django-test-doctor
```

Add `django_doctor` to `INSTALLED_APPS` (the dotted module path, not the
distribution name):

```python
INSTALLED_APPS = [
    ...,
    "django_doctor",
]
```

## Optional extras

```bash
pip install "django-test-doctor[drf]"       # DRF check (installs DRF)
pip install "django-test-doctor[html]"      # (future) HTML reporter
pip install "django-test-doctor[coverage]"  # (future) view test coverage
pip install "django-test-doctor[all]"       # everything above
pip install "django-test-doctor[docs]"      # mkdocs-material for building this site
```

## Dev-only install

You typically don't want `django-test-doctor` in production (it exposes a
management command that writes a transient user to run the `post_smoke`
check). Put it in a `requirements-dev.txt`:

```text
# requirements-dev.txt
-r requirements.txt
django-test-doctor>=0.5.0
```

And add a conditional import in settings so production Django boots even if
the package isn't installed:

```python
INSTALLED_APPS = MAIN_APPS + LOCAL_APPS + EXTERNAL_APPS

try:
    import django_doctor  # noqa: F401
    INSTALLED_APPS = INSTALLED_APPS + ["django_doctor"]
except ImportError:
    pass
```

## Next

- [Run your first audit](quickstart.md)
