# HTML report

`--html <path>` writes a standalone self-contained HTML page suitable for
CI artifacts, email attachments, or hosting behind a static-file server.

## Usage

```bash
./manage.py doctor --html artifacts/doctor-report.html
```

You can combine it with the usual flags. A common CI recipe:

```bash
./manage.py doctor --ci --html artifacts/doctor-report.html
```

`--ci` still exits non-zero on findings matching `fail_on`, and the HTML
report is produced regardless — so a failed build still publishes the
artifact for humans to triage.

## What's inside

- **Inline CSS**, no JS dependency, no external font. The file is
  single-origin and plays nicely with strict CSPs on CI artifact hosts.
- **Per-check sections** rendered as collapsible `<details>` blocks. A
  report with 500 findings stays scannable.
- **Summary pills** by severity at the top (`N critical`, `N error`, …)
  mirroring the terminal panel.
- **Automatic HTML escaping** for messages, rules, locations, and fix
  hints — doctor's own output can't XSS the artifact.
- **Dark / light mode** via `prefers-color-scheme`.

## Programmatic use

```python
from django_doctor.report_html import render_html, write_html

# Returns the HTML as a string you can email / POST / embed.
html = render_html(results, title="Nightly audit")

# Or write straight to disk.
write_html(results, "artifacts/report.html", title="Nightly audit")
```

Both accept a `generated_at=` keyword if you want to pin a specific
timestamp (default: omit — the CLI adds the local ISO timestamp).
