# Using `make_form_fixture`

Doctor's `post_smoke` check generates valid POST payloads from a
`ModelForm` class automatically. The helper is exported as part of the
public API — reuse it in your own tests when you don't want to hand-craft
every `{'client': 17, 'mandat': 42, …}` dict.

## Minimal example

```python
from django_doctor.fixtures import make_form_fixture
from myapp.forms import MandatForm

data = make_form_fixture(MandatForm)
# {'client': 17, 'type_mandat_ref': 4, 'regime_fiscal': 1,
#  'devise': 1, 'statut': 'BROUILLON', 'date_debut': '2026-01-01',
#  'responsable': 1}
```

## Layering overrides

```python
data = make_form_fixture(MandatForm, overrides={
    "statut": "ACTIF",
    "date_debut": "2026-06-01",
})
```

## In a Django TestCase

```python
from django.test import Client, TestCase

class MandatCreateTests(TestCase):
    def test_create_succeeds(self):
        self.client.force_login(self.user)
        data = make_form_fixture(MandatForm, overrides={"statut": "ACTIF"})
        response = self.client.post("/fr/mandats/nouveau/", data)
        self.assertEqual(response.status_code, 302)
```

## What the generator fills

| Field type                           | Sample value                  |
|--------------------------------------|-------------------------------|
| `CharField` / `SlugField`            | `"x"`                         |
| `IntegerField`                       | `field.min_value or 1`        |
| `DecimalField` / `FloatField`        | `"0"`                         |
| `BooleanField` / `NullBooleanField`  | `True`                        |
| `DateField`                          | `"2026-01-01"`                |
| `DateTimeField`                      | `"2026-01-01 00:00"`          |
| `TimeField`                          | `"00:00"`                     |
| `EmailField`                         | `"doctor@example.com"`        |
| `URLField`                           | `"https://example.com"`       |
| `ChoiceField` / `TypedChoiceField`   | First non-empty choice        |
| `MultipleChoiceField`                | `[first choice]`              |
| `ModelChoiceField`                   | `queryset.first().pk`         |
| `ModelMultipleChoiceField`           | `[queryset.first().pk]`       |

## What the generator skips

- `FileField` / `ImageField` — the test client wants a `SimpleUploadedFile`
  which isn't serializable. Pass one yourself in `overrides`.
- `ModelChoiceField` whose queryset is empty — returned as "skip", and
  `post_smoke` reports an INFO `post_smoke.partial_fixture` instead of
  submitting a broken POST.

## API reference

See [api/fixtures](../api/fixtures.md) for the full docstring-backed
reference.
