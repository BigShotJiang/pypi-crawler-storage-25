# Fixtures API

Helpers to build minimal valid POST payloads from Django forms.

## `make_form_fixture`

::: django_doctor.fixtures.make_form_fixture

## `resolve_required_fields`

::: django_doctor.fixtures.resolve_required_fields
