# Core API

Public classes re-exported from `django_doctor`.

## `Check`

::: django_doctor.registry.Check

## `Finding`

::: django_doctor.finding.Finding

## `Severity`

::: django_doctor.finding.Severity

## `Project`

::: django_doctor.registry.Project
