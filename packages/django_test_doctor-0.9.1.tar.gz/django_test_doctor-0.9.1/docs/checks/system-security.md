# system & security

Two non-intrusive checks that rely on Django's built-in introspection.

## `system`

Wraps `./manage.py check` and folds each `django.core.checks.Error` /
`Warning` into the Doctor reporter. Django level → Doctor severity:

| Django level | Doctor severity |
|--------------|-----------------|
| `DEBUG`      | INFO            |
| `INFO`       | INFO            |
| `WARNING`    | WARNING         |
| `ERROR`      | ERROR           |
| `CRITICAL`   | CRITICAL        |

Runs without `include_deployment_checks=True` — that's the `security`
layer's job.

## `security`

Runs Django's deployment checks (`--deploy` flag) plus a short list of
extra invariants:

- `SECRET_KEY` must not contain any of the substrings configured under
  `[tool.django-doctor.security].forbidden_secret_keys`
  (defaults: `django-insecure`, `changeme`, `secret`, `your-secret-key`).
- `SECRET_KEY` must be at least 32 characters.
- `DEBUG=True` → WARNING (fine in dev, fatal in prod).
- `DEBUG=False` with empty `ALLOWED_HOSTS` → ERROR (every request 400s).

Each finding carries `location="settings.<SETTING>"` so you can grep your
own overrides quickly.

### Tuning

```toml
[tool.django-doctor.security]
forbidden_secret_keys = ["django-insecure", "changeme", "secret"]
```

The substring match is case-insensitive. Drop entries to relax, add yours
to reject keys you know are leaked (e.g. `"2019-demo-key"`).
