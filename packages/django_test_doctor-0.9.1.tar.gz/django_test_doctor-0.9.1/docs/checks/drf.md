# drf

Validates every `rest_framework.serializers.Serializer` defined in
first-party apps. Conditional — if `djangorestframework` is not
installed, the check silently emits nothing.

## What it checks

### 1. Blank initialization

Same pattern as the `forms` check, adapted for DRF. Instantiates each
`Serializer` with no arguments. Any exception becomes:

- `drf.blank_init` (ERROR) — unexpected failure.
- `drf.blank_init.needs_args` (INFO) — serializer legitimately requires
  kwargs (downgrade, don't fail CI).

### 2. `Meta.fields` ↔ `Meta.model` coherence

For every `ModelSerializer` that explicitly lists `Meta.fields`, each
entry must either:

- be a real field on `Meta.model`, or
- be a declared attribute on the serializer class, or
- be a model method / property.

Typo `fields = ["nmae"]` where `"nmae"` is neither in the model nor in
the serializer → ERROR `drf.meta_fields.missing`.

## Why DRF doesn't catch this

DRF only resolves `Meta.fields` when the serializer first runs — at
render time. A unit test that never renders the serializer passes. Doctor
runs the resolution at import time.

## Coverage example

Run on altiusone 0.1.0: 202 serializers scanned, 0 violation. The check
doubles as an architectural review — every serializer with `Meta.fields =
"__all__"` is silently excluded (nothing to cross-check), so this is also
a gentle nudge away from the implicit-contract anti-pattern.
