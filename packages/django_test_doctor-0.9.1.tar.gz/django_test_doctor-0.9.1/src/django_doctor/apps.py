from django.apps import AppConfig


class DjangoDoctorConfig(AppConfig):
    name = "django_doctor"
    verbose_name = "Django Doctor"
    default_auto_field = "django.db.models.BigAutoField"
