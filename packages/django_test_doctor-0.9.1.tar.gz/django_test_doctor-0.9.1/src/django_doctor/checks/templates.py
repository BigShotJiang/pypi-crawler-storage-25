"""Template coherence: scan every first-party template for broken references.

Three silent-problem patterns caught here:

1. **`{% url 'name' arg1 ... %}` that no URL in the resolver answers to** —
   Django only raises ``NoReverseMatch`` at render time, so a typo in a
   template that lives behind an auth wall or a rarely-visited page sits
   there until a user hits it.
2. **`{% static 'path/to/asset.ext' %}` that no staticfiles finder resolves** —
   same story: broken asset references never surface at deploy time when
   ``collectstatic`` runs without ``--dry-run --verbosity 2``.
3. **Malformed template syntax** — ``TemplateSyntaxError`` at import time,
   usually introduced by a half-finished edit. ``./manage.py check`` doesn't
   crawl templates.

Deliberately skipped (for now): context variable resolution. A template's
``{{ foo.bar }}`` can only be judged against a specific view's context, and
wiring that plumbing is a can of worms that belongs in the ``views`` check
with coverage integration — not here.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable, Iterator

from django.apps import apps as django_apps
from django.conf import settings
from django.template import TemplateSyntaxError
from django.template.loader import get_template
from django.urls import get_resolver

from ..finding import Finding, Severity
from ..registry import Check, Project


_URL_TAG_RE = re.compile(
    r"""\{%\s*url\s+
        (?P<quote>['"])(?P<name>[^'"]+)(?P=quote)
        (?P<args>[^%]*)
        %\}""",
    re.VERBOSE,
)

_STATIC_TAG_RE = re.compile(
    r"""\{%\s*static\s+
        (?P<quote>['"])(?P<path>[^'"]+)(?P=quote)
        \s*(?:as\s+\w+)?\s*
        %\}""",
    re.VERBOSE,
)


class TemplateCoherenceCheck(Check):
    id = "templates"
    description = "Scan templates for broken {% url %} / {% static %} / syntax errors"
    order = 45

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_patterns = config.get("skip", [])
        check_static = config.get("check_static", True)

        resolver = get_resolver(getattr(settings, "ROOT_URLCONF", None))
        url_names = _collect_url_names(resolver)

        for template_path, rel_path in _iter_first_party_templates():
            if _is_skipped(rel_path, skip_patterns):
                continue
            source = _safe_read(template_path)
            if source is None:
                continue

            yield from self._check_syntax(template_path, rel_path)
            yield from self._check_url_tags(template_path, rel_path, source, url_names)
            if check_static:
                yield from self._check_static_tags(template_path, rel_path, source)

    def _check_syntax(self, path: Path, rel_path: str) -> Iterator[Finding]:
        try:
            get_template(rel_path)
        except TemplateSyntaxError as exc:
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule="templates.syntax",
                location=str(path),
                message=f"Template syntax error: {exc}",
                fix_hint="Render-time crash — Django will raise on any view using this template.",
            )
        except Exception:
            # Loader errors (template not found from a different path) are
            # not our concern — we're reading the file directly.
            pass

    def _check_url_tags(
        self,
        path: Path,
        rel_path: str,
        source: str,
        url_names: set[str],
    ) -> Iterator[Finding]:
        for match in _URL_TAG_RE.finditer(source):
            name = match.group("name")
            # Namespaced names (foo:bar) might not be in the flat set — we
            # collect namespaces separately. A conservative check: if neither
            # the raw name nor any namespace-suffix match, flag it.
            if not _url_name_matches(name, url_names):
                line = source.count("\n", 0, match.start()) + 1
                yield Finding(
                    severity=Severity.ERROR,
                    check_id=self.id,
                    rule="templates.url.unknown",
                    location=f"{path}:{line}",
                    message=(
                        f"{{% url {name!r} %}} — no URL pattern registered under this name."
                    ),
                    fix_hint=(
                        "Check for a typo, a missing include(), or an app whose urls.py "
                        "isn't wired in ROOT_URLCONF."
                    ),
                )

    def _check_static_tags(
        self, path: Path, rel_path: str, source: str
    ) -> Iterator[Finding]:
        try:
            from django.contrib.staticfiles import finders
        except ImportError:  # pragma: no cover
            return
        for match in _STATIC_TAG_RE.finditer(source):
            asset = match.group("path")
            # Skip obvious interpolations — only flag literal string paths.
            if "{{" in asset or "{%" in asset:
                continue
            try:
                resolved = finders.find(asset)
            except Exception:
                resolved = None
            if resolved:
                continue
            line = source.count("\n", 0, match.start()) + 1
            yield Finding(
                severity=Severity.WARNING,
                check_id=self.id,
                rule="templates.static.missing",
                location=f"{path}:{line}",
                message=(
                    f"{{% static {asset!r} %}} — no staticfiles finder resolves this path."
                ),
                fix_hint=(
                    "Either the asset doesn't exist, STATICFILES_DIRS is incomplete, "
                    "or the path is wrong."
                ),
            )


def _collect_url_names(resolver) -> set[str]:
    """Return every registered URL name, including namespaced forms."""
    names: set[str] = set()

    def walk(r, prefix: str = ""):
        for entry in r.url_patterns:
            if hasattr(entry, "url_patterns"):  # URLResolver
                ns = entry.namespace or entry.app_name or ""
                nested = f"{prefix}{ns}:" if ns else prefix
                walk(entry, nested)
            else:  # URLPattern
                if entry.name:
                    names.add(entry.name)
                    if prefix:
                        names.add(f"{prefix}{entry.name}")

    walk(resolver)
    return names


def _url_name_matches(name: str, known: set[str]) -> bool:
    if name in known:
        return True
    # Namespaced name — accept if the trailing part exists anywhere.
    if ":" in name:
        tail = name.rsplit(":", 1)[-1]
        return tail in known
    return False


def _iter_first_party_templates() -> Iterator[tuple[Path, str]]:
    """Yield (absolute_path, relative_path) for every .html template in a
    first-party app's ``templates/`` directory or a TEMPLATES.DIRS entry
    inside the project root."""
    seen: set[Path] = set()

    # App-level templates/.
    for app_config in django_apps.get_app_configs():
        mod_file = getattr(app_config.module, "__file__", "") or ""
        if "site-packages" in mod_file or "dist-packages" in mod_file:
            continue
        templates_dir = Path(app_config.path) / "templates"
        if not templates_dir.is_dir():
            continue
        for abs_path in templates_dir.rglob("*.html"):
            if abs_path in seen:
                continue
            seen.add(abs_path)
            rel = str(abs_path.relative_to(templates_dir))
            yield abs_path, rel

    # TEMPLATES.DIRS entries inside the project.
    base_dir = _project_base_dir()
    for engine in getattr(settings, "TEMPLATES", []):
        for dir_ in engine.get("DIRS", []):
            dir_path = Path(dir_)
            if not dir_path.is_dir():
                continue
            # Skip template dirs that live outside the project (third-party).
            if base_dir and not _is_inside(dir_path, base_dir):
                continue
            for abs_path in dir_path.rglob("*.html"):
                if abs_path in seen:
                    continue
                seen.add(abs_path)
                rel = str(abs_path.relative_to(dir_path))
                yield abs_path, rel


def _project_base_dir() -> Path | None:
    base = getattr(settings, "BASE_DIR", None)
    if base:
        return Path(base).resolve()
    return None


def _is_inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent)
        return True
    except ValueError:
        return False


def _safe_read(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None


def _is_skipped(rel_path: str, patterns: list[str]) -> bool:
    import fnmatch
    return any(fnmatch.fnmatch(rel_path, pat) for pat in patterns)


__all__ = ["TemplateCoherenceCheck"]
