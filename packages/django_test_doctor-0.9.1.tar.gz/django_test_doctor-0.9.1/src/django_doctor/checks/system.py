"""Wrap Django's built-in `./manage.py check` and fold findings into our stream."""

from __future__ import annotations

from typing import Iterable

from django.core import checks as django_checks

from ..finding import Finding, Severity
from ..registry import Check, Project


_DJANGO_LEVEL_TO_SEVERITY = {
    django_checks.DEBUG: Severity.INFO,
    django_checks.INFO: Severity.INFO,
    django_checks.WARNING: Severity.WARNING,
    django_checks.ERROR: Severity.ERROR,
    django_checks.CRITICAL: Severity.CRITICAL,
}


class SystemCheckWrapper(Check):
    id = "system"
    description = "Runs Django's built-in system check framework"
    order = 10

    def run(self, project: Project) -> Iterable[Finding]:
        # Use include_deployment_checks=False — the security layer owns that later.
        issues = django_checks.run_checks(
            tags=None,
            include_deployment_checks=False,
            databases=None,
        )
        for issue in issues:
            yield Finding(
                severity=_DJANGO_LEVEL_TO_SEVERITY.get(issue.level, Severity.WARNING),
                check_id=self.id,
                rule=issue.id or "django.check",
                location=str(getattr(issue, "obj", "") or ""),
                message=issue.msg,
                fix_hint=issue.hint or "",
            )
