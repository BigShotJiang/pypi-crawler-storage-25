"""Validate Django admin registrations — fields in list_display/filter actually exist.

Typical silent-but-deadly bug:

    class WidgetAdmin(admin.ModelAdmin):
        list_display = ("name", "fnction")   # typo — no FieldError until you open the page

The admin never raises at import time, so `./manage.py check` passes, tests that
don't hit the admin pass, and the crash only surfaces the first time an admin
user loads the list view. This check flags it immediately.
"""

from __future__ import annotations

from typing import Iterable, Iterator

from django.contrib import admin as django_admin
from django.core.exceptions import FieldDoesNotExist
from django.db.models import Model

from ..finding import Finding, Severity
from ..registry import Check, Project


class AdminConsistencyCheck(Check):
    id = "admin"
    description = "Check ModelAdmin list_display / list_filter / search_fields reference real fields"
    order = 35

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_apps: set[str] = set(config.get("skip_apps", []))

        for model, admin_cls in django_admin.site._registry.items():
            if model._meta.app_label in skip_apps:
                continue
            location = f"{type(admin_cls).__module__}.{type(admin_cls).__qualname__}"
            yield from self._check_list_display(model, admin_cls, location)
            yield from self._check_simple_field_tuple(
                model, admin_cls, "list_filter", location, allow_lookups=False,
            )
            yield from self._check_simple_field_tuple(
                model, admin_cls, "search_fields", location, allow_lookups=True,
            )
            yield from self._check_ordering(model, admin_cls, location)

    def _check_list_display(
        self, model: type[Model], admin_cls, location: str
    ) -> Iterator[Finding]:
        for name in getattr(admin_cls, "list_display", ()) or ():
            if callable(name):
                continue
            if name == "__str__":
                continue
            if hasattr(admin_cls, name) or hasattr(model, name):
                continue
            if _has_model_field(model, name):
                continue
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule="admin.list_display.missing_field",
                location=location,
                message=(
                    f"list_display entry {name!r} is not a field or callable on "
                    f"{model.__name__} or {type(admin_cls).__name__}."
                ),
                fix_hint="Fix the typo or add a method on the ModelAdmin with this name.",
            )

    def _check_simple_field_tuple(
        self,
        model: type[Model],
        admin_cls,
        attr: str,
        location: str,
        allow_lookups: bool,
    ) -> Iterator[Finding]:
        for entry in getattr(admin_cls, attr, ()) or ():
            if callable(entry) or not isinstance(entry, str):
                continue
            name = entry.lstrip("^=@")  # search_fields lookup prefixes
            field_name = name.split("__", 1)[0] if allow_lookups else name
            if _has_model_field(model, field_name):
                continue
            if hasattr(admin_cls, field_name) or hasattr(model, field_name):
                continue
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule=f"admin.{attr}.missing_field",
                location=location,
                message=(
                    f"{attr} entry {entry!r} does not resolve to a field on "
                    f"{model.__name__}."
                ),
                fix_hint=f"Remove or fix the entry in {attr}.",
            )

    def _check_ordering(
        self, model: type[Model], admin_cls, location: str
    ) -> Iterator[Finding]:
        for entry in getattr(admin_cls, "ordering", ()) or ():
            if not isinstance(entry, str):
                continue
            field_name = entry.lstrip("-").split("__", 1)[0]
            if _has_model_field(model, field_name):
                continue
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule="admin.ordering.missing_field",
                location=location,
                message=(
                    f"ordering entry {entry!r} references a field that is not on "
                    f"{model.__name__}."
                ),
                fix_hint="Remove or fix the entry in ordering.",
            )


def _has_model_field(model: type[Model], name: str) -> bool:
    try:
        model._meta.get_field(name)
    except FieldDoesNotExist:
        return False
    return True
