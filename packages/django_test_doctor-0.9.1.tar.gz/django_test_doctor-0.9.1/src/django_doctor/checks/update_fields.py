"""Detect ``obj.save(update_fields=[...])`` that drops computed fields.

The altiusone hikimatech Studio bug that motivated this check
(2026-04-21):

    # facturation/views_studio.py
    ligne = LigneFacture.objects.get(pk=ligne_pk, facture=facture)
    setattr(ligne, field, value)
    ligne.save(update_fields=[field])     # <-- drops computed montant_*

And in the model:

    class LigneFacture(BaseModel):
        def save(self, *args, **kwargs):
            self.montant_ht  = self.quantite * self.prix_unitaire_ht
            self.montant_tva = self.montant_ht * self.taux_tva / 100
            self.montant_ttc = self.montant_ht + self.montant_tva
            super().save(*args, **kwargs)

``LigneFacture.save()`` **recomputes** ``montant_ht / tva / ttc`` on every
call, but Django's ``update_fields`` restricts the UPDATE statement to
``[field]``. The recomputed values are thrown away and the DB keeps
whatever totals it had before — in the studio bug, 0.

The bug's signature:
- a model whose ``save()`` **unconditionally** assigns to database fields
  other than the one(s) being updated, AND
- a call site that passes ``update_fields=[subset]`` where the subset
  omits those unconditionally-recomputed fields.

Static analysis covers both halves:

1. Parse every first-party model's ``save()`` method. Collect the set of
   DB fields it assigns unconditionally (``self.<f> = <expr>`` outside a
   guarding ``if not self.<f>:``-style branch).
2. AST-walk every ``.py`` file in first-party apps, find calls shaped
   like ``<recv>.save(update_fields=[<literals>])``, resolve ``<recv>``'s
   model class via a lightweight per-scope symbol table, and flag the
   call when its ``update_fields`` omits any field the model's
   ``save()`` recomputes.

Heuristics, not proofs: we prefer false positives over missed
regressions. Tune via ``[tool.django-doctor.update_fields]`` (skip a
model, skip a path) when the analyzer is being overzealous.
"""

from __future__ import annotations

import ast
import inspect
import textwrap
from pathlib import Path
from typing import Iterable, Iterator

from django.apps import apps as django_apps
from django.db import models

from ..finding import Finding, Severity
from ..registry import Check, Project


class UnsafeUpdateFieldsCheck(Check):
    id = "update_fields"
    description = "Flag obj.save(update_fields=[...]) that drops fields the model's save() recomputes"
    order = 46

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_models: set[str] = set(config.get("skip_models", []))
        skip_paths: list[str] = list(config.get("skip_paths", []))

        # Build the "dangerous models" index: model class → set of field
        # names unconditionally assigned in its save() method.
        model_index = _build_model_index(skip_models)
        if not model_index:
            return

        for source_path in _iter_first_party_py_files(skip_paths):
            yield from _scan_file(source_path, model_index)


def _build_model_index(skip_models: set[str]) -> dict[str, dict]:
    """Return ``{ "<app_label>.<ModelName>": {"fields": {...}, "model": <class>} }``
    for every first-party model whose ``save()`` method unconditionally
    assigns to at least one DB field.

    The map also indexes the model by its bare class name so callers
    using ``ligne.save(...)`` resolve back to ``facturation.LigneFacture``.
    """
    by_name: dict[str, dict] = {}
    for model in django_apps.get_models():
        if model._meta.abstract or model._meta.proxy:
            continue
        if not _is_first_party(model):
            continue
        dotted = f"{model._meta.app_label}.{model.__name__}"
        if dotted in skip_models or model.__name__ in skip_models:
            continue
        computed = _unconditional_field_assignments(model)
        if not computed:
            continue
        entry = {"fields": computed, "model": model, "dotted": dotted}
        by_name[model.__name__] = entry
        by_name[dotted] = entry
    return by_name


def _unconditional_field_assignments(model: type[models.Model]) -> set[str]:
    """Return the set of ``self.<field>`` names the model's ``save()``
    **unconditionally** assigns before calling ``super().save()``.

    Assignments inside a guarding ``if not self.<f>:`` / ``if <f> is None:``
    branch are ignored — they only run on first save and don't fight
    ``update_fields``.
    """
    try:
        source = inspect.getsource(model)
    except (OSError, TypeError):
        return set()
    try:
        tree = ast.parse(textwrap.dedent(source))
    except SyntaxError:
        return set()

    class_def = next(
        (n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)), None
    )
    if class_def is None:
        return set()
    save_method = next(
        (
            n for n in class_def.body
            if isinstance(n, ast.FunctionDef) and n.name == "save"
        ),
        None,
    )
    if save_method is None:
        return set()

    model_field_names = {f.attname.rstrip("_id") for f in model._meta.get_fields() if hasattr(f, "attname")}
    model_field_names |= {f.name for f in model._meta.get_fields() if hasattr(f, "name")}

    unconditional: set[str] = set()
    for stmt in save_method.body:
        _collect_unconditional(stmt, model_field_names, unconditional, guarded=False)
    return unconditional


def _collect_unconditional(
    node: ast.AST,
    model_fields: set[str],
    out: set[str],
    *,
    guarded: bool,
) -> None:
    """Walk ``save()`` body statements. Record top-level ``self.<f> = …``
    assignments in ``out``. Statements nested inside an ``if``/``try`` /
    ``for`` / ``while`` block are considered guarded (``guarded=True``
    short-circuits recording) — those branches don't always run, so
    ``update_fields`` omitting them is tolerable."""
    if isinstance(node, ast.Assign) and not guarded:
        for target in node.targets:
            name = _self_attr_name(target)
            if name and name in model_fields:
                out.add(name)
    elif isinstance(node, ast.AugAssign) and not guarded:
        name = _self_attr_name(node.target)
        if name and name in model_fields:
            out.add(name)
    elif isinstance(node, (ast.If, ast.For, ast.While, ast.Try, ast.With, ast.AsyncWith)):
        for child in ast.iter_child_nodes(node):
            _collect_unconditional(child, model_fields, out, guarded=True)
    else:
        for child in ast.iter_child_nodes(node):
            _collect_unconditional(child, model_fields, out, guarded=guarded)


def _self_attr_name(target: ast.AST) -> str | None:
    """Return ``<name>`` if ``target`` is ``self.<name>``, else None."""
    if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name):
        if target.value.id == "self":
            return target.attr
    return None


def _scan_file(path: Path, model_index: dict[str, dict]) -> Iterator[Finding]:
    try:
        source = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return

    for call, scope_types, enclosing_cls in _iter_save_update_fields_calls(tree):
        receiver_cls = _resolve_receiver_class(call, scope_types, enclosing_cls, model_index)
        if receiver_cls is None:
            continue
        entry = model_index.get(receiver_cls)
        if entry is None:
            continue
        update_fields = _extract_update_fields_literal(call)
        if update_fields is None:
            continue  # kwargs coming from a variable — static analysis bails
        missing = entry["fields"] - update_fields
        if not missing:
            continue
        yield Finding(
            severity=Severity.ERROR,
            check_id="update_fields",
            rule="update_fields.drops_computed",
            location=f"{path}:{call.lineno}",
            message=(
                f"{receiver_cls}.save(update_fields={sorted(update_fields)!r}) "
                f"omits field(s) that {receiver_cls}.save() unconditionally "
                f"recomputes: {sorted(missing)!r}. Django will write the "
                "update_fields subset only — the recomputed values are "
                "silently dropped, the DB stays stale."
            ),
            fix_hint=(
                f"Include {sorted(missing)!r} in update_fields, or drop "
                "update_fields entirely (``obj.save()``) so the whole "
                "model is rewritten. The latter is safer when the method "
                "is only called from a single endpoint."
            ),
        )


def _iter_save_update_fields_calls(
    tree: ast.Module,
) -> Iterator[tuple[ast.Call, dict[str, str], str | None]]:
    """Walk every function, build a per-scope symbol table mapping variable
    names to the model class they're bound to, then yield every
    ``<recv>.save(update_fields=[...])`` call found in that scope.

    We walk the AST once, tracking enclosing ClassDef for ``self``
    resolution and per-FunctionDef locals for name → class.
    """
    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.class_stack: list[str] = []

        def visit_ClassDef(self, node):  # noqa: N802
            self.class_stack.append(node.name)
            self.generic_visit(node)
            self.class_stack.pop()

        def visit_FunctionDef(self, node):  # noqa: N802
            scope = _build_scope_types(node)
            enclosing = self.class_stack[-1] if self.class_stack else None
            for call in _find_save_calls(node):
                yield_buffer.append((call, scope, enclosing))
            self.generic_visit(node)

        visit_AsyncFunctionDef = visit_FunctionDef  # noqa: N815

    yield_buffer: list[tuple[ast.Call, dict[str, str], str | None]] = []
    Visitor().visit(tree)
    yield from yield_buffer


def _build_scope_types(func: ast.FunctionDef) -> dict[str, str]:
    """Infer which Django model class each local variable holds.

    Heuristics covered:
    - ``x = Model.objects.<manager_method>(...)``
    - ``x = Model.objects.filter(...).first/last/get/create(...)``
    - ``x = get_object_or_404(Model, ...)``
    - ``x: Model = ...`` (explicit annotation)
    - ``for x in Model.objects.<...>:``
    """
    scope: dict[str, str] = {}

    for node in ast.walk(func):
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            ann = _type_name(node.annotation)
            if ann:
                scope[node.target.id] = ann
        elif isinstance(node, ast.Assign):
            cls = _infer_class_from_rhs(node.value)
            if cls:
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        scope[target.id] = cls
        elif isinstance(node, ast.For) and isinstance(node.target, ast.Name):
            cls = _infer_class_from_rhs(node.iter)
            if cls:
                scope[node.target.id] = cls
    return scope


def _infer_class_from_rhs(rhs: ast.AST) -> str | None:
    """Best-effort resolution of the model class produced by an
    assignment RHS expression. Returns the bare class name (e.g.
    ``"LigneFacture"``); the caller normalises it against the index."""
    if rhs is None:
        return None

    # get_object_or_404(Model, ...)
    if isinstance(rhs, ast.Call):
        func = rhs.func
        if isinstance(func, ast.Name) and func.id == "get_object_or_404":
            if rhs.args and isinstance(rhs.args[0], ast.Name):
                return rhs.args[0].id
        # Unwrap chained calls like Model.objects.filter().first()
        expr = rhs
        while isinstance(expr, ast.Call) and isinstance(expr.func, ast.Attribute):
            inner = expr.func.value
            if isinstance(inner, ast.Attribute) and inner.attr in {"objects", "_default_manager"}:
                if isinstance(inner.value, ast.Name):
                    return inner.value.id
            expr = expr.func.value
    return None


def _type_name(annotation: ast.AST) -> str | None:
    if isinstance(annotation, ast.Name):
        return annotation.id
    if isinstance(annotation, ast.Attribute):
        return annotation.attr
    return None


def _find_save_calls(func: ast.FunctionDef) -> Iterator[ast.Call]:
    """Yield every ``<recv>.save(update_fields=[...])`` call inside ``func``
    — including in nested blocks but excluding nested function defs."""
    for node in ast.walk(func):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "save":
            continue
        if not any(
            isinstance(kw, ast.keyword) and kw.arg == "update_fields"
            for kw in node.keywords
        ):
            continue
        yield node


def _extract_update_fields_literal(call: ast.Call) -> set[str] | None:
    """Return the set of string literals passed as ``update_fields``, or
    ``None`` if the value isn't a literal list/tuple of strings."""
    for kw in call.keywords:
        if kw.arg != "update_fields":
            continue
        value = kw.value
        if isinstance(value, (ast.List, ast.Tuple, ast.Set)):
            names: set[str] = set()
            for elt in value.elts:
                if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                    names.add(elt.value)
                else:
                    return None
            return names
        return None
    return None


def _resolve_receiver_class(
    call: ast.Call,
    scope_types: dict[str, str],
    enclosing_cls: str | None,
    model_index: dict[str, dict],
) -> str | None:
    """Map ``call.func.value`` (the receiver) to a known model class name.

    Looks at ``self`` (from ``enclosing_cls``), simple names (via
    ``scope_types``), and attribute access of the form
    ``self.<related>.save(...)`` (the related accessor's model is
    inferred from the enclosing class, best-effort — we don't fully
    resolve FK types)."""
    recv = call.func.value

    # self.save(...)
    if isinstance(recv, ast.Name):
        if recv.id == "self" and enclosing_cls:
            return enclosing_cls if enclosing_cls in model_index else None
        cls = scope_types.get(recv.id)
        if cls and cls in model_index:
            return cls

    # self.<fk>.save(...) — check the FK's target model class from the
    # enclosing class's _meta. Kept simple: only matches when the enclosing
    # class resolves to a known model.
    if isinstance(recv, ast.Attribute) and isinstance(recv.value, ast.Name):
        if recv.value.id == "self" and enclosing_cls:
            entry = model_index.get(enclosing_cls)
            if entry:
                model = entry["model"]
                try:
                    field = model._meta.get_field(recv.attr)
                except Exception:  # noqa: BLE001
                    return None
                related = getattr(field, "related_model", None)
                if related and related.__name__ in model_index:
                    return related.__name__

    return None


def _iter_first_party_py_files(skip_paths: list[str]) -> Iterator[Path]:
    """Yield every ``.py`` file under each first-party app, excluding
    test files (``test_*.py``, ``tests.py``, ``conftest.py``) and the
    ``migrations`` directory. Both legitimately use ``update_fields`` in
    ways the check shouldn't police."""
    import fnmatch

    seen: set[Path] = set()
    for app_config in django_apps.get_app_configs():
        mod_file = getattr(app_config.module, "__file__", "") or ""
        if "site-packages" in mod_file or "dist-packages" in mod_file:
            continue
        root = Path(app_config.path)
        for py in root.rglob("*.py"):
            if py in seen:
                continue
            if "migrations" in py.parts:
                continue
            if py.name.startswith("test_") or py.name in ("tests.py", "conftest.py"):
                continue
            rel = str(py)
            if any(fnmatch.fnmatch(rel, pat) for pat in skip_paths):
                continue
            seen.add(py)
            yield py


def _is_first_party(model: type[models.Model]) -> bool:
    import sys

    module = sys.modules.get(model.__module__)
    file_ = getattr(module, "__file__", "") if module else ""
    if not file_:
        return False
    return "site-packages" not in file_ and "dist-packages" not in file_


__all__ = ["UnsafeUpdateFieldsCheck"]
