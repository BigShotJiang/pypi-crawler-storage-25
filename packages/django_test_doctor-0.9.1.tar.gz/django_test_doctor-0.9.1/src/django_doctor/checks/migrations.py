"""Detect out-of-date migrations without actually applying anything.

Wraps Django's own ``./manage.py makemigrations --check --dry-run`` so the
verdict is byte-for-byte identical to what the user sees locally. Reusing
``MigrationAutodetector`` directly diverges subtly — the questioner
defaults, ``trim_to_apps`` handling and consistency checks that
``makemigrations`` wires together are load-bearing.

By default only first-party apps are inspected — flagging drift inside
``django.contrib.admin`` or any third-party app installed in site-packages
just produces noise, because the user can't fix it anyway.
"""

from __future__ import annotations

import io
from typing import Iterable

from django.apps import apps
from django.core.management import call_command
from django.db import DEFAULT_DB_ALIAS, connections
from django.db.migrations.executor import MigrationExecutor

from ..finding import Finding, Severity
from ..registry import Check, Project


class MigrationStateCheck(Check):
    id = "migrations"
    description = "Detect unapplied migrations and model changes without a matching migration"
    order = 30

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        extra_skip = set(config.get("skip_apps", []))
        include_third_party = bool(config.get("include_third_party", False))
        first_party = _first_party_app_labels()

        def keep(app_label: str) -> bool:
            if app_label in extra_skip:
                return False
            if include_third_party:
                return True
            return app_label in first_party

        yield from self._unapplied_migrations(keep)
        yield from self._changes_without_migration(keep)

    def _unapplied_migrations(self, keep) -> Iterable[Finding]:
        connection = connections[DEFAULT_DB_ALIAS]
        executor = MigrationExecutor(connection)
        targets = executor.loader.graph.leaf_nodes()
        plan = executor.migration_plan(targets)
        for migration, _backwards in plan:
            if not keep(migration.app_label):
                continue
            yield Finding(
                severity=Severity.WARNING,
                check_id=self.id,
                rule="migrations.unapplied",
                location=f"{migration.app_label}.{migration.name}",
                message="Migration not applied to the default database.",
                fix_hint="Run ./manage.py migrate",
            )

    def _changes_without_migration(self, keep) -> Iterable[Finding]:
        """Call makemigrations --check --dry-run and translate drift apps into findings.

        We rely on Django's command because it carries every subtle default
        (questioner, consistency checks, app trimming) the raw autodetector
        does not — reimplementing them drifts over time.
        """
        app_labels = _drifted_apps()
        for app_label in sorted(app_labels):
            if not keep(app_label):
                continue
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule="migrations.missing",
                location=app_label,
                message=(
                    f"Model changes detected in {app_label!r} with no matching "
                    "migration file."
                ),
                fix_hint="Run ./manage.py makemigrations",
            )


def _drifted_apps() -> set[str]:
    """Return the set of app labels that makemigrations --check would flag.

    Works by calling the command and parsing its stdout — the exit code alone
    (1 = drift, 0 = clean) isn't enough because we need the per-app breakdown.
    We call it with ``dry_run=True, check_changes=False`` so it doesn't exit
    the process, and redirect stdout to a buffer.
    """
    buf = io.StringIO()
    err = io.StringIO()
    try:
        call_command(
            "makemigrations",
            dry_run=True,
            check_changes=False,
            interactive=False,
            verbosity=1,
            stdout=buf,
            stderr=err,
        )
    except SystemExit:  # pragma: no cover — shouldn't fire with check_changes=False
        pass

    drifted: set[str] = set()
    # makemigrations prints one line per affected app:
    #   "Migrations for 'core':"
    # followed by the file that *would* be written. We just need the label.
    for line in buf.getvalue().splitlines():
        line = line.strip()
        if line.startswith("Migrations for"):
            # Extract the app label between quotes.
            _, _, rest = line.partition("'")
            label, _, _ = rest.partition("'")
            if label:
                drifted.add(label)
    return drifted


def _first_party_app_labels() -> set[str]:
    """Return the labels of apps whose source lives outside site-packages."""
    labels: set[str] = set()
    for app_config in apps.get_app_configs():
        module = app_config.module
        file_ = getattr(module, "__file__", "") or ""
        if not file_:
            continue
        if "site-packages" in file_ or "dist-packages" in file_:
            continue
        labels.add(app_config.label)
    return labels
