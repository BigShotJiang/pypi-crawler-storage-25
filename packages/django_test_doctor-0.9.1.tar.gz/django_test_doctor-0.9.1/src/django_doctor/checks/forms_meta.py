"""Detect the "orphan cleaned_data assignment" anti-pattern.

Real-world bug that motivated this check (OperationTVAForm, altiusone 2026-04-20):

    class OperationTVAForm(forms.ModelForm):
        class Meta:
            model = OperationTVA
            fields = ["montant_ht", "taux_tva", ...]  # no montant_ttc here

        def clean(self):
            cleaned_data = super().clean()
            cleaned_data["montant_ttc"] = ...  # <-- assigned but not a form field
            return cleaned_data

``form.save()`` silently ignores keys in ``cleaned_data`` that aren't form
fields. If the underlying model column is NOT NULL without a default, the
next ``.save()`` raises ``IntegrityError``.

This check parses each ``ModelForm``'s ``clean*()`` methods with ``ast`` and
reports every ``cleaned_data[<key>]`` assignment where ``<key>`` is a
NOT-NULL model column, absent from ``Meta.fields`` and not declared on the
form — **and** the form has no ``save()`` override to persist it manually.
"""

from __future__ import annotations

import ast
import inspect
import textwrap
from typing import Iterable, Iterator

from django import forms
from django.apps import apps as django_apps
from django.core.exceptions import FieldDoesNotExist

from ..finding import Finding, Severity
from ..registry import Check, Project


class FormsMetaCoherenceCheck(Check):
    id = "forms_meta"
    description = "Detect cleaned_data[x]=... where x is NOT NULL but not in Meta.fields"
    order = 42

    def run(self, project: Project) -> Iterable[Finding]:
        seen: set[type] = set()
        for form_cls in _iter_model_forms():
            if form_cls in seen:
                continue
            seen.add(form_cls)
            yield from self._analyze(form_cls)

    def _analyze(self, form_cls: type[forms.ModelForm]) -> Iterator[Finding]:
        meta = getattr(form_cls, "Meta", None)
        if meta is None:
            return
        model = getattr(meta, "model", None)
        if model is None:
            return

        declared = set(getattr(form_cls, "declared_fields", {}).keys())
        meta_fields = _resolve_meta_fields(meta, model)
        form_fields = declared | meta_fields

        try:
            source = inspect.getsource(form_cls)
        except (OSError, TypeError):
            return  # no source available (e.g. generated via modelform_factory)
        try:
            tree = ast.parse(textwrap.dedent(source))
        except SyntaxError:
            return

        class_def = next(
            (n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)), None
        )
        if class_def is None:
            return

        assignments = _collect_cleaned_data_keys(class_def)
        has_save_override = any(
            isinstance(n, ast.FunctionDef) and n.name == "save"
            for n in class_def.body
        )
        location = f"{form_cls.__module__}.{form_cls.__qualname__}"

        for key, lineno in assignments:
            if key in form_fields:
                continue
            # If the form already overrides save(), assume the author
            # writes orphan values to the instance manually — don't flag.
            if has_save_override:
                continue
            try:
                model_field = model._meta.get_field(key)
            except FieldDoesNotExist:
                continue  # not a model attribute, unrelated noise
            if getattr(model_field, "null", True):
                continue  # nullable column, safe to leave unset
            if model_field.has_default():
                continue  # default covers for the missing value
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule="forms.cleaned_data.orphan",
                location=f"{location}:{lineno}",
                message=(
                    f"cleaned_data[{key!r}] is assigned in clean() but {key!r} is "
                    f"not in Meta.fields; {model.__name__}.{key} is NOT NULL without default. "
                    f"form.save() will silently drop the value and raise IntegrityError."
                ),
                fix_hint=(
                    f"Either add {key!r} to Meta.fields (possibly with a HiddenInput) "
                    f"or override form.save() to write instance.{key} before commit."
                ),
            )


def _resolve_meta_fields(meta, model) -> set[str]:
    fields = getattr(meta, "fields", None)
    exclude = getattr(meta, "exclude", None)
    all_model_fields = {f.name for f in model._meta.get_fields() if hasattr(f, "attname")}
    if fields in (None, "__all__"):
        if exclude:
            return all_model_fields - set(exclude)
        return all_model_fields
    if isinstance(fields, (list, tuple)):
        return set(fields)
    return set()


def _collect_cleaned_data_keys(class_def: ast.ClassDef) -> list[tuple[str, int]]:
    """Return (key, lineno) for each `cleaned_data[KEY] = ...` inside a clean* method."""
    results: list[tuple[str, int]] = []
    for method in class_def.body:
        if not isinstance(method, ast.FunctionDef):
            continue
        if not (method.name == "clean" or method.name.startswith("clean_")):
            continue
        for node in ast.walk(method):
            if not isinstance(node, ast.Assign):
                continue
            for target in node.targets:
                key = _assigned_dict_key(target)
                if key is not None:
                    results.append((key, node.lineno))
    return results


def _assigned_dict_key(target: ast.AST) -> str | None:
    """If `target` is `cleaned_data[<str>]` or `self.cleaned_data[<str>]`,
    return the string key; otherwise None."""
    if not isinstance(target, ast.Subscript):
        return None
    # Unwrap ast.Index for Python <3.9 compatibility.
    slice_node = target.slice
    if hasattr(ast, "Index") and isinstance(slice_node, ast.Index):  # pragma: no cover
        slice_node = slice_node.value
    if not (isinstance(slice_node, ast.Constant) and isinstance(slice_node.value, str)):
        return None

    container = target.value
    if isinstance(container, ast.Name) and container.id == "cleaned_data":
        return slice_node.value
    if (
        isinstance(container, ast.Attribute)
        and container.attr == "cleaned_data"
    ):
        return slice_node.value
    return None


def _iter_model_forms() -> Iterator[type[forms.ModelForm]]:
    """Yield every first-party ModelForm subclass defined in a project app."""
    import importlib
    import pkgutil

    for app_config in django_apps.get_app_configs():
        module = app_config.module
        if module is None or not hasattr(module, "__path__"):
            continue
        file_ = getattr(module, "__file__", "") or ""
        if "site-packages" in file_ or "dist-packages" in file_:
            continue
        for mod_info in pkgutil.walk_packages(
            module.__path__, prefix=f"{module.__name__}."
        ):
            try:
                m = importlib.import_module(mod_info.name)
            except Exception:  # noqa: BLE001
                continue
            for _, obj in inspect.getmembers(m, inspect.isclass):
                if (
                    issubclass(obj, forms.ModelForm)
                    and obj is not forms.ModelForm
                    and obj.__module__ == m.__name__
                    and not inspect.isabstract(obj)
                ):
                    yield obj
