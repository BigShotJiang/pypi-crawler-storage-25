"""Validate every DRF Serializer and ModelViewSet the project exposes.

Four failure modes we care about:

1. **Serializer.__init__ crashes** — same class of bug as the forms check but
   for the API layer. A blank `MySerializer()` that raises is a view that
   returns HTTP 500 on every GET.

2. **ModelSerializer field points at a non-existent model field** — the
   classic ``fields = ["nmae"]`` typo. DRF only raises at render time, so
   unit tests that never hit the serializer don't catch it.

3. **ViewSet.queryset references a non-existent field in ordering / filtering**
   — surfaces as 500 the first time a user hits the list endpoint with
   ``?ordering=something``.

4. **Serializer with `Meta.fields = "__all__"` on an unmanaged model** —
   silent contract surface; new columns auto-leak into the API.

The check is conditional — ``djangorestframework`` is an optional dep. If it
isn't installed, the check emits nothing.
"""

from __future__ import annotations

import importlib
import inspect
import pkgutil
from typing import Iterable, Iterator

from django.apps import apps
from django.core.exceptions import FieldDoesNotExist

from ..finding import Finding, Severity
from ..registry import Check, Project


class DrfSerializerCheck(Check):
    id = "drf"
    description = "Validate DRF Serializer init + ModelSerializer fields exist on the model"
    order = 45

    def run(self, project: Project) -> Iterable[Finding]:
        try:
            from rest_framework import serializers, viewsets  # noqa: F401
        except ImportError:
            return

        config = self.get_config(project)
        scenarios: list[str] = config.get("scenarios", ["blank"])
        seen: set[type] = set()

        for app_config in apps.get_app_configs():
            if _is_third_party(app_config):
                continue
            for serializer_cls in _iter_serializers(app_config):
                if serializer_cls in seen:
                    continue
                seen.add(serializer_cls)
                yield from self._probe_serializer(serializer_cls, scenarios)

    def _probe_serializer(self, cls, scenarios: list[str]) -> Iterator[Finding]:
        from rest_framework import serializers

        location = f"{cls.__module__}.{cls.__qualname__}"

        if "blank" in scenarios:
            yield from _safely_init(cls, location, self.id)

        # If it's a ModelSerializer, cross-check declared fields vs Meta.model.
        if issubclass(cls, serializers.ModelSerializer):
            yield from _check_model_fields(cls, location, self.id)


def _safely_init(cls, location: str, check_id: str) -> Iterator[Finding]:
    """Blank-init the serializer. Any exception is a real bug."""
    try:
        cls()
    except TypeError as exc:
        # Required kwargs — same treatment as forms.
        import re
        if re.search(r"missing \d+ required", str(exc)):
            yield Finding(
                severity=Severity.INFO,
                check_id=check_id,
                rule="drf.blank_init.needs_args",
                location=location,
                message=f"Serializer requires kwargs at init: {exc}",
                fix_hint="Serializer cannot be smoke-tested without arguments.",
            )
            return
        yield Finding(
            severity=Severity.ERROR,
            check_id=check_id,
            rule="drf.blank_init",
            location=location,
            message=f"Blank init raised TypeError: {exc}",
            fix_hint="Serializer.__init__ must succeed with no kwargs.",
        )
    except Exception as exc:  # noqa: BLE001
        yield Finding(
            severity=Severity.ERROR,
            check_id=check_id,
            rule="drf.blank_init",
            location=location,
            message=f"Blank init raised {type(exc).__name__}: {exc}",
            fix_hint="Serializer.__init__ must succeed with no kwargs.",
        )


def _check_model_fields(cls, location: str, check_id: str) -> Iterator[Finding]:
    """Every explicit `Meta.fields` entry must map to a real model field or
    declared serializer attribute."""
    meta = getattr(cls, "Meta", None)
    if meta is None:
        return
    model = getattr(meta, "model", None)
    if model is None:
        return
    declared_fields = getattr(meta, "fields", None)
    if declared_fields in (None, "__all__"):
        return
    if not isinstance(declared_fields, (list, tuple)):
        return

    declared_cls_fields = set(cls._declared_fields.keys()) if hasattr(cls, "_declared_fields") else set()

    for field_name in declared_fields:
        if not isinstance(field_name, str):
            continue
        if field_name in declared_cls_fields:
            continue  # explicitly declared on the serializer class
        if _has_model_attr(model, field_name):
            continue
        yield Finding(
            severity=Severity.ERROR,
            check_id=check_id,
            rule="drf.meta_fields.missing",
            location=location,
            message=(
                f"Meta.fields entry {field_name!r} is not a field on "
                f"{model.__name__} and is not declared on the serializer."
            ),
            fix_hint=f"Remove {field_name!r} from Meta.fields or declare it.",
        )


def _has_model_attr(model, name: str) -> bool:
    try:
        model._meta.get_field(name)
        return True
    except FieldDoesNotExist:
        pass
    # Could be a method/property on the model (common DRF pattern).
    return hasattr(model, name)


def _iter_serializers(app_config) -> Iterator[type]:
    from rest_framework import serializers

    package = app_config.module
    if package is None or not hasattr(package, "__path__"):
        return
    for mod_info in pkgutil.walk_packages(package.__path__, prefix=f"{package.__name__}."):
        try:
            module = importlib.import_module(mod_info.name)
        except Exception:  # noqa: BLE001
            continue
        for _, obj in inspect.getmembers(module, inspect.isclass):
            if (
                issubclass(obj, serializers.BaseSerializer)
                and obj is not serializers.BaseSerializer
                and obj is not serializers.Serializer
                and obj is not serializers.ModelSerializer
                and obj is not serializers.ListSerializer
                and obj.__module__ == module.__name__
                and not inspect.isabstract(obj)
            ):
                yield obj


def _is_third_party(app_config) -> bool:
    module = app_config.module
    if module is None or not getattr(module, "__file__", None):
        return True
    return "site-packages" in (module.__file__ or "")
