"""Detect unsafe auto-generated ID parsing in ``Model.save()``.

Real-world bug that motivated this check (Mandat, altiusone hikimatech 2026-04-20):

    class Mandat(BaseModel):
        def save(self, *args, **kwargs):
            if not self.numero:
                last = Mandat.objects.filter(
                    numero__startswith=f'MAN-{year}'
                ).order_by('numero').last()
                if last:
                    last_num = int(last.numero.split('-')[-1])  # <-- crashes
                    self.numero = f'MAN-{year}-{last_num + 1:03d}'

A single existing row with a non-numeric suffix (``MAN-2026-CIB`` — imported
from another system or entered by hand) is enough to turn every subsequent
``POST /mandats/nouveau/`` into an HTTP 500. The first crash is
``ValueError: invalid literal for int() with base 10: 'CIB'``.

Three failure modes this check flags:

1. **Unwrapped ``int(x.split(sep)[idx])``** — the canonical shape of the
   hikimatech bug. Flags any call with no surrounding ``try/except`` that
   mentions ``ValueError`` / ``TypeError`` / ``IndexError`` / bare
   ``Exception``. These calls live inside ``save()`` / ``clean()`` /
   ``_generate_numero()``-style methods on first-party models.
2. **Unwrapped ``int(x.rsplit(sep)[idx])``** — same shape, different split.
3. **``int(x)`` where ``x`` is a Django field attribute** (``self.code``,
   ``instance.numero`` etc.) and the field's model declares the attribute
   as a ``CharField`` / ``TextField`` — same hazard, less common.

Rule of thumb: if the value crosses the serializer / form / admin boundary
at any point, it can be non-numeric, and the parse must be defensive.
"""

from __future__ import annotations

import ast
import inspect
import textwrap
from typing import Iterable, Iterator

from django.apps import apps as django_apps
from django.db import models

from ..finding import Finding, Severity
from ..registry import Check, Project


# Names of exception classes that count as "I handled the parse failure".
# Catching these around an ``int(...)`` call silences the check.
_GUARDED_EXCEPTIONS = {
    "ValueError",
    "TypeError",
    "IndexError",
    "AttributeError",  # some codebases use this form for .split on None
    "Exception",  # bare catch-all still silences the check
    "BaseException",
}

# Method names we scan. These are the places auto-generation typically
# lives; scanning every method of every model would be noisy.
_SCANNED_METHODS = {"save", "clean", "full_clean"}


class AutogenNumeroCheck(Check):
    id = "autogen"
    description = "Flag int(x.split(sep)[i]) auto-gen patterns not wrapped in try/except"
    order = 44

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_apps: set[str] = set(config.get("skip_apps", []))
        scanned_methods: set[str] = set(config.get("methods", _SCANNED_METHODS))

        for model_cls in _iter_first_party_models(skip_apps):
            yield from self._analyze_model(model_cls, scanned_methods)

    def _analyze_model(
        self, model_cls: type[models.Model], scanned_methods: set[str]
    ) -> Iterator[Finding]:
        try:
            source = inspect.getsource(model_cls)
        except (OSError, TypeError):
            return
        try:
            tree = ast.parse(textwrap.dedent(source))
        except SyntaxError:
            return

        class_def = next(
            (n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)), None
        )
        if class_def is None:
            return

        location_prefix = f"{model_cls.__module__}.{model_cls.__qualname__}"

        for method in class_def.body:
            if not isinstance(method, ast.FunctionDef):
                continue
            if method.name not in scanned_methods:
                continue
            for call in _iter_unsafe_int_calls(method):
                yield Finding(
                    severity=Severity.ERROR,
                    check_id=self.id,
                    rule="autogen.unsafe_int_split",
                    location=f"{location_prefix}.{method.name}:{call.lineno}",
                    message=(
                        f"int({_render_expr(call)!r}) parses an unvalidated string "
                        "without try/except. A single row with a non-numeric suffix "
                        "crashes with ValueError -> HTTP 500 on every new save."
                    ),
                    fix_hint=(
                        "Either (a) filter the query with ``<field>__regex=r'^...-\\d+$'`` "
                        "so only conforming rows are considered, or (b) wrap the parse in "
                        "``try/except (ValueError, IndexError): continue``, or both."
                    ),
                )


def _iter_unsafe_int_calls(method: ast.FunctionDef) -> Iterator[ast.Call]:
    """Yield int(...) calls inside ``method`` whose argument looks like a
    split-based parse, and which are not wrapped in a guarding try/except."""
    for node in ast.walk(method):
        if not isinstance(node, ast.Call):
            continue
        if not _is_int_call(node):
            continue
        if not _arg_looks_like_split_parse(node):
            continue
        if _is_guarded(method, node):
            continue
        yield node


def _is_int_call(call: ast.Call) -> bool:
    func = call.func
    return isinstance(func, ast.Name) and func.id == "int"


def _arg_looks_like_split_parse(call: ast.Call) -> bool:
    """True when the first arg is `<x>.split(...)[<i>]`, `<x>.rsplit(...)[<i>]`,
    or a simple attribute access that feeds through a subscript index."""
    if not call.args:
        return False
    arg = call.args[0]

    # <x>.split(<sep>)[<i>]
    if isinstance(arg, ast.Subscript):
        value = arg.value
        if isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute):
            if value.func.attr in {"split", "rsplit"}:
                return True

    return False


def _is_guarded(method: ast.FunctionDef, target: ast.Call) -> bool:
    """True when ``target`` sits inside a ``try: ...`` body with an ``except``
    clause that catches a guarding exception type."""
    for try_node in _enclosing_try_blocks(method, target):
        if _try_catches_guarded(try_node):
            return True
    return False


def _enclosing_try_blocks(
    method: ast.FunctionDef, target: ast.Call
) -> Iterator[ast.Try]:
    """Yield every ``ast.Try`` node that syntactically wraps ``target``.

    Implemented as an explicit pre-order walk so we can maintain an ancestor
    stack of ``Try`` nodes without the recursion-with-closure gymnastics
    nested generators would need.
    """
    # Each stack entry: (node, iterator over children, enclosing try blocks)
    frames: list[tuple[ast.AST, Iterator[ast.AST], tuple[ast.Try, ...]]] = [
        (method, iter(ast.iter_child_nodes(method)), ())
    ]
    while frames:
        _node, children, trys = frames[-1]
        try:
            child = next(children)
        except StopIteration:
            frames.pop()
            continue
        if child is target:
            yield from trys
            continue
        child_trys = trys + (child,) if isinstance(child, ast.Try) else trys
        frames.append((child, iter(ast.iter_child_nodes(child)), child_trys))


def _try_catches_guarded(try_node: ast.Try) -> bool:
    for handler in try_node.handlers:
        # except:  (bare)
        if handler.type is None:
            return True
        # except Foo:
        if isinstance(handler.type, ast.Name):
            if handler.type.id in _GUARDED_EXCEPTIONS:
                return True
        # except (Foo, Bar):
        if isinstance(handler.type, ast.Tuple):
            for elt in handler.type.elts:
                if isinstance(elt, ast.Name) and elt.id in _GUARDED_EXCEPTIONS:
                    return True
    return False


def _iter_first_party_models(skip_apps: set[str]) -> Iterator[type[models.Model]]:
    for model in django_apps.get_models():
        if model._meta.app_label in skip_apps:
            continue
        if model._meta.abstract or model._meta.proxy:
            continue
        if not _is_first_party(model):
            continue
        yield model


def _is_first_party(model: type[models.Model]) -> bool:
    import sys

    module = sys.modules.get(model.__module__)
    file_ = getattr(module, "__file__", "") if module else ""
    if not file_:
        return False
    return "site-packages" not in file_ and "dist-packages" not in file_


def _render_expr(call: ast.Call) -> str:
    """Best-effort readable rendering of the flagged int(...) argument."""
    try:
        return ast.unparse(call.args[0])
    except Exception:  # pragma: no cover — py<3.9 or weird AST
        return "<expr>"


__all__ = ["AutogenNumeroCheck"]
