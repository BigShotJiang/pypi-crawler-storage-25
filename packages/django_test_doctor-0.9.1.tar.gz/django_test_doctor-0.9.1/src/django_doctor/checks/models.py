"""Hygiene checks for Django models — catch the subtle stuff `check` doesn't see.

Three silent-problem patterns:

1. **No custom ``__str__``** — admin, shell, logs, exception messages all show
   ``<MyModel: MyModel object (42)>`` which makes debugging painful.
2. **No ``Meta.ordering``** — `.all()` returns rows in whatever order the DB
   feels like, so pagination tests become flaky.
3. **``on_delete=SET_NULL`` on a FK whose column is ``NOT NULL``** — Django
   won't complain at system-check time, but the first parent deletion raises
   ``IntegrityError`` in prod.
"""

from __future__ import annotations

from typing import Iterable, Iterator

from django.apps import apps
from django.db import models as dj_models

from ..finding import Finding, Severity
from ..registry import Check, Project


class ModelHygieneCheck(Check):
    id = "models"
    description = "Catch missing __str__, missing Meta.ordering, and SET_NULL on non-null FK"
    order = 25

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_apps: set[str] = set(config.get("skip_apps", []))
        soft_checks: set[str] = set(config.get("soft_checks", []))

        for model in apps.get_models():
            if model._meta.app_label in skip_apps:
                continue
            if model._meta.abstract or model._meta.proxy:
                continue
            if not _is_first_party(model):
                continue
            location = f"{model.__module__}.{model.__qualname__}"
            yield from self._check_str(model, location)
            yield from self._check_ordering(model, location, soft_checks)
            yield from self._check_nullable_fk(model, location)

    def _check_str(self, model, location: str) -> Iterator[Finding]:
        # If __str__ isn't overridden, Python falls back to object.__str__,
        # whose bound function lives on `object`.
        if model.__str__ is dj_models.Model.__str__:
            yield Finding(
                severity=Severity.WARNING,
                check_id=self.id,
                rule="models.str_missing",
                location=location,
                message=(
                    f"{model.__name__} has no custom __str__; admin/shell/logs "
                    "will show generic repr strings."
                ),
                fix_hint="Add a __str__ method returning a human-readable identifier.",
            )

    def _check_ordering(
        self, model, location: str, soft_checks: set[str]
    ) -> Iterator[Finding]:
        meta = model._meta
        if meta.ordering:
            return
        severity = Severity.WARNING if "ordering_missing" in soft_checks else Severity.INFO
        yield Finding(
            severity=severity,
            check_id=self.id,
            rule="models.ordering_missing",
            location=location,
            message=(
                f"{model.__name__} has no Meta.ordering; pagination and listings "
                "will return rows in DB-dependent order."
            ),
            fix_hint="Set Meta.ordering = ('-created_at',) or another stable field.",
        )

    def _check_nullable_fk(self, model, location: str) -> Iterator[Finding]:
        for field in model._meta.get_fields():
            if not isinstance(field, (dj_models.ForeignKey, dj_models.OneToOneField)):
                continue
            on_delete = getattr(field.remote_field, "on_delete", None)
            if on_delete is dj_models.SET_NULL and not field.null:
                yield Finding(
                    severity=Severity.ERROR,
                    check_id=self.id,
                    rule="models.set_null_on_non_null_fk",
                    location=f"{location}.{field.name}",
                    message=(
                        f"{model.__name__}.{field.name} uses on_delete=SET_NULL "
                        "but the column is NOT NULL — deletion will raise IntegrityError."
                    ),
                    fix_hint="Add null=True on the field or change on_delete.",
                )


def _is_first_party(model) -> bool:
    path = getattr(model.__module__, "__file__", None)
    module = model.__module__
    try:
        import sys

        mod_obj = sys.modules.get(module)
        file_ = getattr(mod_obj, "__file__", "") if mod_obj else ""
    except Exception:  # pragma: no cover
        file_ = ""
    return "site-packages" not in (file_ or "") and "dist-packages" not in (file_ or "")
