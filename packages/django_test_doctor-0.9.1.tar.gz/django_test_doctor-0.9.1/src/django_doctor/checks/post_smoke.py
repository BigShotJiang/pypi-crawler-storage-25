"""POST smoke: auto-generate a fixture, POST it, fail on 5xx.

Closes the gap the ``urls`` check leaves open — it only hits GET, so a
``CreateView`` that 500s only on ``form.save()`` (IntegrityError in a
``post_save`` signal, bad ``__init__``, missing NOT NULL FK, …) flies under
the radar. This check submits each form with a minimal auto-generated
payload and catches the real failure.

Safe by construction: every request runs inside a ``transaction.atomic()`` +
``savepoint_rollback`` so the production database is **not** mutated even
if the view reaches ``.save()``. Run against a dev database anyway.
"""

from __future__ import annotations

import re
from typing import Iterable, Iterator

from django import forms
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import transaction
from django.test import Client
from django.test.utils import override_settings
from django.urls import URLPattern, URLResolver, get_resolver
from django.views.generic.edit import CreateView, UpdateView

from ..finding import Finding, Severity
from ..fixtures import make_form_fixture, make_url_kwargs, resolve_required_fields
from ..registry import Check, Project


_KWARG_PATTERN = re.compile(r"<(?:(\w+):)?(\w+)>")


class PostSmokeCheck(Check):
    id = "post_smoke"
    description = "POST to every CreateView/UpdateView with an auto fixture, fail on 5xx"
    order = 55
    slow = True

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_patterns: list[str] = config.get("skip", [])
        allowed = list(getattr(settings, "ALLOWED_HOSTS", []) or []) + ["testserver", "*"]

        with override_settings(ALLOWED_HOSTS=allowed):
            client = _build_superuser_client()
            if client is None:
                return
            resolver = get_resolver(getattr(settings, "ROOT_URLCONF", None))
            for url_name, route, view_cls in _iter_form_views(resolver):
                if _is_skipped(url_name, skip_patterns):
                    continue
                probe_route = route
                kwargs: dict = {}
                if _KWARG_PATTERN.search(route):
                    kwargs = make_url_kwargs(route, view_cls) or {}
                    if not kwargs:
                        continue
                    probe_route = _substitute_kwargs(route, kwargs)
                yield from self._probe(client, url_name, probe_route, view_cls, kwargs)

    def _probe(
        self,
        client,
        url_name,
        route,
        view_cls,
        url_kwargs: dict,
    ) -> Iterator[Finding]:
        form_cls = _extract_form_cls(view_cls)
        if form_cls is None:
            return

        try:
            payload = make_form_fixture(form_cls)
        except Exception as exc:  # noqa: BLE001
            yield Finding(
                severity=Severity.WARNING,
                check_id=self.id,
                rule="post_smoke.fixture_error",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=f"Could not build a fixture for {form_cls.__name__}: {exc}",
                fix_hint=(
                    "Simplify form.__init__ or mark the view in "
                    "[tool.django-doctor.post_smoke].skip."
                ),
            )
            return

        required = resolve_required_fields(form_cls)
        missing = [k for k in required if k not in payload]
        if missing:
            yield Finding(
                severity=Severity.INFO,
                check_id=self.id,
                rule="post_smoke.partial_fixture",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=(
                    f"Cannot auto-generate required field(s) {missing!r}; "
                    "POST not attempted."
                ),
                fix_hint=(
                    "Typically a FileField, a ModelChoice with no DB rows, "
                    "or a MultiWidget. Add a tailored fixture in your tests."
                ),
            )
            return

        model_cls = _resolve_model(view_cls, form_cls)
        is_create = _is_subclass(view_cls, CreateView)

        # Run the POST inside a savepoint and always roll back. All DB reads
        # for the persistence assertions happen BEFORE the rollback.
        sid = transaction.savepoint()
        findings: list[Finding] = []
        try:
            pre_count = model_cls._default_manager.count() if model_cls else None
            pre_instance = _snapshot_update_target(view_cls, model_cls, url_kwargs)

            response = None
            try:
                response = client.post(route, payload, follow=False)
            except Exception as exc:  # noqa: BLE001
                findings.append(Finding(
                    severity=Severity.CRITICAL,
                    check_id=self.id,
                    rule="post_smoke.exception",
                    location=f"{url_name or route} ({view_cls.__name__})",
                    message=f"POST raised {type(exc).__name__}: {exc}",
                    fix_hint=(
                        "Reproduce with the same payload in a local shell + "
                        "Client. Common causes: unguarded FK access in a "
                        "post_save signal, NOT NULL column missing from the "
                        "form."
                    ),
                    extra={"payload_keys": sorted(payload.keys())},
                ))

            if response is not None and 500 <= response.status_code < 600:
                findings.append(Finding(
                    severity=Severity.CRITICAL,
                    check_id=self.id,
                    rule="post_smoke.5xx",
                    location=f"{url_name or route} ({view_cls.__name__})",
                    message=(
                        f"POST returned HTTP {response.status_code} with "
                        f"auto-generated payload {sorted(payload.keys())!r}."
                    ),
                    fix_hint=(
                        "The view reaches .save() but something down the "
                        "stack (signal, post_save hook, constraint) raises. "
                        "Check the Django error log on the target instance."
                    ),
                    extra={"status_code": response.status_code},
                ))
            elif (
                response is not None
                and 300 <= response.status_code < 400
                and model_cls is not None
            ):
                # Response was a redirect — the universal Django signal
                # for "form.is_valid() passed, the view saved, we're
                # sending you to the success URL". A 200 after POST, by
                # contrast, is typically the form re-rendered with
                # validation errors — "nothing was saved, and that's
                # correct". We therefore only verify persistence when
                # the response is a 3xx.
                #
                # This misses views that return 200 on successful save
                # (a minority pattern, e.g. JSON APIs) — those can be
                # covered by per-endpoint tests instead. Trading a few
                # misses for a 10× false-positive reduction on a normal
                # CBV-heavy codebase.
                if is_create:
                    findings.extend(self._assert_created(
                        url_name, route, view_cls, model_cls, pre_count, payload,
                    ))
                elif pre_instance is not None:
                    findings.extend(self._assert_updated(
                        url_name, route, view_cls, model_cls, pre_instance,
                        payload, form_cls,
                    ))
        finally:
            transaction.savepoint_rollback(sid)

        yield from findings

    def _assert_created(
        self, url_name, route, view_cls, model_cls, pre_count, payload,
    ) -> Iterator[Finding]:
        """A CreateView POST returned success — did the row actually land?"""
        post_count = model_cls._default_manager.count()
        if post_count == pre_count:
            yield Finding(
                severity=Severity.CRITICAL,
                check_id=self.id,
                rule="post_smoke.stale_db.create",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=(
                    f"POST returned 2xx/3xx but no new {model_cls.__name__} "
                    "row was persisted. The view reports success while "
                    "silently dropping the user's submission."
                ),
                fix_hint=(
                    "Typical causes: a wrapping transaction rolled back "
                    "after a signal exception, form_valid() forgot to call "
                    "super() / form.save(), or an outer middleware swallowed "
                    "a post-save exception."
                ),
                extra={
                    "pre_count": pre_count,
                    "post_count": post_count,
                    "payload_keys": sorted(payload.keys()),
                },
            )

    def _assert_updated(
        self, url_name, route, view_cls, model_cls, pre_instance, payload,
        form_cls,
    ) -> Iterator[Finding]:
        """An UpdateView POST returned success — did the target row change?"""
        try:
            post_instance = model_cls._default_manager.get(pk=pre_instance.pk)
        except model_cls.DoesNotExist:
            return  # the view deleted the row — different scenario

        # We only assert on fields we can confidently link back to the POST
        # payload: ModelForm fields that were in the fixture. Everything
        # else (computed totals, timestamps, etc.) is out of scope.
        form_fields = _form_field_names(form_cls)
        drift: list[str] = []
        for name in payload.keys() & form_fields:
            pre_val = getattr(pre_instance, name, None)
            post_val = getattr(post_instance, name, None)
            expected = payload[name]
            # If the submitted value was identical to the current DB value,
            # an equal post-state tells us nothing — skip.
            if _values_equal(pre_val, expected):
                continue
            if not _values_equal(post_val, expected):
                drift.append(name)

        if drift:
            yield Finding(
                severity=Severity.CRITICAL,
                check_id=self.id,
                rule="post_smoke.stale_db.update",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=(
                    f"POST to {model_cls.__name__} returned 2xx/3xx but "
                    f"field(s) {sorted(drift)!r} were NOT updated in the DB. "
                    "The view reports success while the write silently "
                    "dropped the user's values."
                ),
                fix_hint=(
                    "Look for save(update_fields=[subset]) omitting these "
                    "fields, a form.save() call that never fires, or a "
                    "save() override that conditionally returns early."
                ),
                extra={
                    "fields_not_persisted": sorted(drift),
                    "payload_keys": sorted(payload.keys()),
                },
            )


def _build_superuser_client():
    """Spin up a transient superuser and log them in via the test client."""
    User = get_user_model()
    try:
        user, _ = User.objects.get_or_create(
            username="doctor_post_smoke",
            defaults={"email": "doctor-post@example.com", "is_staff": True, "is_superuser": True},
        )
        user.is_staff = True
        user.is_superuser = True
        # Some projects have a required `type_utilisateur` enum on their User.
        if hasattr(user, "type_utilisateur"):
            try:
                user.type_utilisateur = type(user).TypeUtilisateur.STAFF
            except (AttributeError, KeyError):
                pass
        user.save()
    except Exception:  # pragma: no cover — test DB might refuse creation
        return None
    client = Client()
    client.force_login(user)
    return client


def _iter_form_views(
    resolver: URLResolver, prefix: str = "/"
) -> Iterator[tuple[str, str, type]]:
    for entry in resolver.url_patterns:
        if isinstance(entry, URLPattern):
            cls = _view_class(entry)
            if cls is None:
                continue
            if not _is_form_view(cls):
                continue
            route = prefix + str(entry.pattern).lstrip("/")
            yield entry.name or "", route, cls
        elif isinstance(entry, URLResolver):
            nested = prefix + str(entry.pattern).lstrip("/")
            yield from _iter_form_views(entry, prefix=nested)


def _view_class(pattern: URLPattern):
    cb = getattr(pattern, "callback", None)
    if cb is None:
        return None
    for attr in ("view_class", "cls"):
        cls = getattr(cb, attr, None)
        if cls is not None:
            return cls
    return None


def _is_form_view(cls) -> bool:
    try:
        return issubclass(cls, (CreateView, UpdateView))
    except TypeError:
        return False


def _extract_form_cls(view_cls):
    """Return the ModelForm class a CBV will instantiate at dispatch time."""
    form_cls = getattr(view_cls, "form_class", None)
    if form_cls is not None:
        return form_cls
    # Fall back to model-based forms via modelform_factory.
    model = getattr(view_cls, "model", None)
    fields = getattr(view_cls, "fields", None)
    if model is None or not fields:
        return None
    from django.forms import modelform_factory

    return modelform_factory(model, fields=fields)


def _is_skipped(url_name: str, patterns: list[str]) -> bool:
    import fnmatch
    return any(fnmatch.fnmatch(url_name, pat) for pat in patterns)


def _is_subclass(cls, target) -> bool:
    try:
        return issubclass(cls, target)
    except TypeError:
        return False


def _resolve_model(view_cls, form_cls):
    """Return the model class the view operates on, or None if unresolvable."""
    model = getattr(view_cls, "model", None)
    if model is not None:
        return model
    form_meta = getattr(form_cls, "_meta", None) or getattr(form_cls, "Meta", None)
    if form_meta is not None:
        model = getattr(form_meta, "model", None)
        if model is not None:
            return model
    return None


def _snapshot_update_target(view_cls, model_cls, url_kwargs):
    """For an UpdateView-style probe, fetch the target instance so we can
    compare it against the post-POST state later. Returns None for
    CreateView or when we can't resolve the PK."""
    if model_cls is None or _is_subclass(view_cls, CreateView):
        return None
    pk_lookup = url_kwargs.get("pk") or url_kwargs.get("id")
    if pk_lookup is None:
        return None
    try:
        return model_cls._default_manager.get(pk=pk_lookup)
    except Exception:  # noqa: BLE001
        return None


def _form_field_names(form_cls) -> set[str]:
    """Names of every field a ModelForm binds, whether declared or from
    ``Meta.fields``. Empty set for plain Forms or generated factories we
    can't introspect cleanly."""
    try:
        return set(form_cls().fields.keys())
    except Exception:  # noqa: BLE001
        return set()


def _values_equal(a, b) -> bool:
    """Loose equality for comparing a raw POST string against a Django
    model attribute. Forms coerce integers / dates / decimals on the way
    in, so we stringify both sides before comparing."""
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    # Handle Model instances (FK fields) — compare pk against the raw value.
    if hasattr(a, "pk"):
        a = a.pk
    if hasattr(b, "pk"):
        b = b.pk
    return str(a) == str(b)


def _substitute_kwargs(route: str, kwargs: dict) -> str:
    def sub(match):
        name = match.group(2)
        value = kwargs.get(name, "")
        return str(value)

    return _KWARG_PATTERN.sub(sub, route)
