"""Instantiate every Form / ModelForm to catch __init__ crashes.

This is the check that catches bugs like:

    class ContactPrincipalForm(forms.ModelForm):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            # CharField has no .choices — crash at instantiation
            self.fields['fonction'].choices = [...] + list(self.fields['fonction'].choices)

Unit tests that only call `form.is_valid()` with prepared data miss it.
The empty-GET path in a Django view does this exact instantiation first.
"""

from __future__ import annotations

import importlib
import inspect
import pkgutil
import re
from typing import Iterable, Iterator

from django import forms
from django.apps import apps

from ..finding import Finding, Severity
from ..registry import Check, Project


# Matches TypeError raised when a Form requires kwargs it was not given.
# e.g. "SetPasswordForm.__init__() missing 1 required positional argument: 'user'"
#      "__init__() missing 2 required keyword-only arguments: 'a' and 'b'"
_MISSING_ARGS_RE = re.compile(
    r"missing \d+ required (?:positional|keyword-only) arguments?"
)


class FormInstantiationCheck(Check):
    id = "forms"
    description = "Instantiate every Form / ModelForm (blank + empty data) to catch __init__ crashes"
    order = 40

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        scenarios: list[str] = config.get("scenarios", ["blank", "empty_data"])

        # Dedupe: a form class can be reachable through multiple app_config
        # walks (re-exports, common __init__ shims). Probe each concrete class
        # exactly once so a single bug isn't reported N times.
        seen: set[type[forms.BaseForm]] = set()
        for app_config in apps.get_app_configs():
            if _is_third_party(app_config):
                continue
            for form_cls in _iter_forms(app_config):
                if form_cls in seen:
                    continue
                seen.add(form_cls)
                yield from self._probe_form(form_cls, scenarios)

    def _probe_form(
        self, form_cls: type[forms.BaseForm], scenarios: list[str]
    ) -> Iterator[Finding]:
        location = f"{form_cls.__module__}.{form_cls.__qualname__}"

        if "blank" in scenarios:
            yield from _safely_call(
                form_cls, kwargs={}, rule="forms.blank_init",
                scenario_label="blank instantiation",
                location=location, check_id=self.id,
            )

        if "empty_data" in scenarios:
            yield from _safely_call(
                form_cls, kwargs={"data": {}}, rule="forms.empty_data",
                scenario_label="empty POST data",
                location=location, check_id=self.id,
            )


def _safely_call(
    form_cls: type[forms.BaseForm],
    kwargs: dict,
    rule: str,
    scenario_label: str,
    location: str,
    check_id: str,
) -> Iterator[Finding]:
    try:
        form_cls(**kwargs)
    except TypeError as exc:
        msg = str(exc)
        if _MISSING_ARGS_RE.search(msg):
            # The form legitimately requires extra kwargs (Django's SetPasswordForm
            # needs `user=`, AuthenticationForm needs `request=`, ...). That is a
            # design choice, not a bug — downgrade to INFO so it doesn't block CI.
            yield Finding(
                severity=Severity.INFO,
                check_id=check_id,
                rule=f"{rule}.needs_args",
                location=location,
                message=f"{scenario_label} requires extra args: {exc}",
                fix_hint=(
                    "Form cannot be smoke-tested blank because it requires kwargs. "
                    "Add the form to [tool.django-doctor].ignore if this is intentional."
                ),
            )
            return
        # Unexpected TypeError — keep as ERROR
        yield Finding(
            severity=Severity.ERROR,
            check_id=check_id,
            rule=rule,
            location=location,
            message=f"{scenario_label} raised TypeError: {exc}",
            fix_hint=(
                "A Form.__init__ must succeed with no arguments — GET requests "
                "render forms this way. Guard or remove the failing line."
            ),
        )
    except Exception as exc:  # noqa: BLE001
        yield Finding(
            severity=Severity.ERROR,
            check_id=check_id,
            rule=rule,
            location=location,
            message=f"{scenario_label} raised {type(exc).__name__}: {exc}",
            fix_hint=(
                "A Form.__init__ must succeed with no arguments — GET requests "
                "render forms this way. Guard or remove the failing line."
            ),
        )


def _iter_forms(app_config) -> Iterator[type[forms.BaseForm]]:
    """Walk each local module under `app_config` and yield form subclasses."""
    package = app_config.module
    if package is None or not hasattr(package, "__path__"):
        return
    for mod_info in pkgutil.walk_packages(package.__path__, prefix=f"{package.__name__}."):
        try:
            module = importlib.import_module(mod_info.name)
        except Exception:  # noqa: BLE001
            continue
        for _, obj in inspect.getmembers(module, inspect.isclass):
            if (
                issubclass(obj, forms.BaseForm)
                and obj is not forms.BaseForm
                and obj is not forms.Form
                and obj is not forms.ModelForm
                and obj.__module__ == module.__name__
                and not inspect.isabstract(obj)
            ):
                yield obj


def _is_third_party(app_config) -> bool:
    """Heuristic: skip apps installed in site-packages (not our source tree)."""
    module = app_config.module
    if module is None or not getattr(module, "__file__", None):
        return True
    return "site-packages" in (module.__file__ or "")
