"""Security posture — deployment checks + secret key sanity + DEBUG flag.

Complements the ``system`` check by running the *deployment* tag set (which
``system`` intentionally skips) and by flagging well-known weak ``SECRET_KEY``
prefixes Django itself tolerates. Empty ``ALLOWED_HOSTS`` with ``DEBUG=False``
is also surfaced because it silently breaks the host in production.
"""

from __future__ import annotations

from typing import Iterable

from django.conf import settings
from django.core import checks as django_checks

from ..finding import Finding, Severity
from ..registry import Check, Project


_LEVEL_TO_SEVERITY = {
    django_checks.DEBUG: Severity.INFO,
    django_checks.INFO: Severity.INFO,
    django_checks.WARNING: Severity.WARNING,
    django_checks.ERROR: Severity.ERROR,
    django_checks.CRITICAL: Severity.CRITICAL,
}


class SecurityCheck(Check):
    id = "security"
    description = "Django deployment checks + SECRET_KEY sanity + DEBUG flag"
    order = 20

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        forbidden: list[str] = config.get(
            "forbidden_secret_keys",
            ["django-insecure", "changeme", "secret", "your-secret-key"],
        )

        yield from self._deployment_issues()
        yield from self._secret_key(forbidden)
        yield from self._debug_flag()
        yield from self._allowed_hosts()

    def _deployment_issues(self) -> Iterable[Finding]:
        issues = django_checks.run_checks(
            tags=[django_checks.Tags.security],
            include_deployment_checks=True,
            databases=None,
        )
        for issue in issues:
            yield Finding(
                severity=_LEVEL_TO_SEVERITY.get(issue.level, Severity.WARNING),
                check_id=self.id,
                rule=issue.id or "security.django.check",
                location=str(getattr(issue, "obj", "") or ""),
                message=issue.msg,
                fix_hint=issue.hint or "",
            )

    def _secret_key(self, forbidden: list[str]) -> Iterable[Finding]:
        secret_key = getattr(settings, "SECRET_KEY", "") or ""
        lowered = secret_key.lower()
        for needle in forbidden:
            if needle.lower() in lowered:
                yield Finding(
                    severity=Severity.CRITICAL,
                    check_id=self.id,
                    rule="security.secret_key_weak",
                    location="settings.SECRET_KEY",
                    message=(
                        f"SECRET_KEY contains forbidden substring {needle!r}. "
                        "This key is either the Django default, a placeholder, or otherwise compromised."
                    ),
                    fix_hint="Generate a new key with django.core.management.utils.get_random_secret_key().",
                )
                break
        if not secret_key:
            yield Finding(
                severity=Severity.CRITICAL,
                check_id=self.id,
                rule="security.secret_key_empty",
                location="settings.SECRET_KEY",
                message="SECRET_KEY is empty.",
                fix_hint="Set SECRET_KEY in settings; never ship with an empty value.",
            )
        elif len(secret_key) < 32:
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule="security.secret_key_short",
                location="settings.SECRET_KEY",
                message=f"SECRET_KEY is too short ({len(secret_key)} chars); use at least 50.",
                fix_hint="Use get_random_secret_key() to generate a proper one.",
            )

    def _debug_flag(self) -> Iterable[Finding]:
        if getattr(settings, "DEBUG", False):
            yield Finding(
                severity=Severity.WARNING,
                check_id=self.id,
                rule="security.debug_true",
                location="settings.DEBUG",
                message="DEBUG=True — acceptable for dev, fatal in production.",
                fix_hint="Ensure DEBUG=False in every production settings profile.",
            )

    def _allowed_hosts(self) -> Iterable[Finding]:
        debug = getattr(settings, "DEBUG", False)
        allowed = list(getattr(settings, "ALLOWED_HOSTS", []) or [])
        if not debug and not allowed:
            yield Finding(
                severity=Severity.ERROR,
                check_id=self.id,
                rule="security.allowed_hosts_empty",
                location="settings.ALLOWED_HOSTS",
                message="ALLOWED_HOSTS is empty with DEBUG=False; every request will 400.",
                fix_hint="Add production hostnames to ALLOWED_HOSTS.",
            )
