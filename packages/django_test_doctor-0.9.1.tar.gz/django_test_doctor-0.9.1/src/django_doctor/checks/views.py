"""Authorization audit: flag views that appear to be public by accident.

Three questions for every view in ``urlpatterns``:

1. Is the view **guarded**? For a CBV: does its MRO include ``LoginRequiredMixin``,
   ``PermissionRequiredMixin``, ``UserPassesTestMixin``, or a DRF
   ``IsAuthenticated``-flavored ``permission_classes``. For an FBV: is the
   callable wrapped by ``login_required`` / ``permission_required``
   (detected by attribute marker left by the decorator) or does the source
   mention ``request.user.is_authenticated``?
2. Is the URL name on the **public whitelist**? Auth endpoints (``login``,
   ``logout``, ``signup``, ``password_reset`` and friends), health checks,
   and anything the user explicitly whitelisted in
   ``[tool.django-doctor.views].public``.
3. Is the view part of a third-party app? We only audit first-party code.

Views failing (1) and not excused by (2) surface as ``WARNING``: opinionated
but not CI-blocking by default. Override via ``fail_on`` if you want a hard
stop.
"""

from __future__ import annotations

import inspect
from typing import Iterable, Iterator

from django.conf import settings
from django.urls import URLPattern, URLResolver, get_resolver

from ..finding import Finding, Severity
from ..registry import Check, Project


DEFAULT_PUBLIC_NAMES = {
    "login", "logout", "signup", "register",
    "password_reset", "password_reset_done",
    "password_reset_confirm", "password_reset_complete",
    "password_change", "password_change_done",
    "health", "healthcheck", "health-check", "healthz",
    "readyz", "livez", "ping", "home", "index", "schema", "swagger",
    "redoc", "api-root", "docs", "favicon",
}

# Mixin class names (string match — avoid importing every third-party auth pkg).
_GUARDING_MIXINS = {
    "LoginRequiredMixin",
    "PermissionRequiredMixin",
    "UserPassesTestMixin",
    "StaffRequiredMixin",
    "SuperuserRequiredMixin",
    "AccessMixin",
}


class ViewAuthorizationCheck(Check):
    id = "views"
    description = "Flag first-party views that appear to be public by accident"
    order = 60

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        public_names: set[str] = set(DEFAULT_PUBLIC_NAMES) | set(
            config.get("public", [])
        )
        skip_modules: list[str] = config.get("skip_modules", [])

        resolver = get_resolver(getattr(settings, "ROOT_URLCONF", None))
        seen: set[object] = set()
        for url_name, route, callback in _iter_patterns(resolver):
            view_cls = _view_class(callback)
            key = view_cls or callback
            if key in seen:
                continue
            seen.add(key)

            if _is_third_party(view_cls, callback):
                continue
            if _module_matches(view_cls, callback, skip_modules):
                continue
            if _is_public(url_name, public_names):
                continue
            if _has_guard(view_cls, callback):
                continue

            location = _describe(view_cls, callback)
            yield Finding(
                severity=Severity.WARNING,
                check_id=self.id,
                rule="views.unguarded",
                location=location,
                message=(
                    f"{url_name or route} appears to be public — no login/permission "
                    "guard was detected on the view."
                ),
                fix_hint=(
                    "Add LoginRequiredMixin (or PermissionRequiredMixin) for CBVs, "
                    "@login_required / @permission_required for FBVs, or whitelist "
                    "the URL name under [tool.django-doctor.views].public."
                ),
            )


def _iter_patterns(
    resolver, prefix: str = "/"
) -> Iterator[tuple[str, str, object]]:
    for entry in resolver.url_patterns:
        if isinstance(entry, URLPattern):
            route = prefix + str(entry.pattern).lstrip("/")
            callback = getattr(entry, "callback", None)
            if callback is None:
                continue
            yield entry.name or "", route, callback
        elif isinstance(entry, URLResolver):
            nested = prefix + str(entry.pattern).lstrip("/")
            yield from _iter_patterns(entry, prefix=nested)


def _view_class(callback):
    for attr in ("view_class", "cls"):
        cls = getattr(callback, attr, None)
        if cls is not None:
            return cls
    return None


def _is_third_party(view_cls, callback) -> bool:
    module = (view_cls or callback).__module__ or ""
    try:
        import sys

        mod = sys.modules.get(module)
        file_ = getattr(mod, "__file__", "") if mod else ""
    except Exception:  # pragma: no cover
        file_ = ""
    return "site-packages" in (file_ or "") or "dist-packages" in (file_ or "")


def _module_matches(view_cls, callback, patterns: list[str]) -> bool:
    import fnmatch

    module = (view_cls or callback).__module__ or ""
    return any(fnmatch.fnmatch(module, pat) for pat in patterns)


def _is_public(url_name: str, public_names: set[str]) -> bool:
    if not url_name:
        return False
    if url_name in public_names:
        return True
    # Namespaced URL names: check the tail.
    tail = url_name.rsplit(":", 1)[-1]
    return tail in public_names


def _has_guard(view_cls, callback) -> bool:
    # CBV path — walk the MRO for guarding mixins or DRF permission_classes.
    if view_cls is not None:
        for klass in view_cls.__mro__:
            if klass.__name__ in _GUARDING_MIXINS:
                return True
        perm_classes = getattr(view_cls, "permission_classes", None)
        if perm_classes:
            # Empty list means "unauthenticated OK" — not a guard.
            if _drf_permissions_guard(perm_classes):
                return True
        # DRF @api_view decorator stores a _view_mapping — harder to inspect,
        # so fall through to source heuristics.

    # FBV path — Django's login_required leaves attrs on the wrapped function.
    if _has_decorator_marker(callback):
        return True

    # Last-resort source heuristic — scan the raw source for canonical guards.
    return _source_mentions_guard(view_cls or callback)


def _drf_permissions_guard(perm_classes) -> bool:
    names = {getattr(p, "__name__", "") for p in perm_classes}
    # AllowAny explicitly opens the view — only flag if AllowAny is the *only*
    # permission and no other guard coexists.
    if names == {"AllowAny"}:
        return False
    return any(
        n in {"IsAuthenticated", "IsAdminUser", "DjangoModelPermissions",
              "IsAuthenticatedOrReadOnly", "DjangoObjectPermissions"}
        for n in names
    )


def _has_decorator_marker(callback) -> bool:
    # `login_required` sets `login_url` on the wrapped function via closure but
    # doesn't leave a reliable marker — instead inspect the closure cells for a
    # reference to the known decorator internals, and check common module paths.
    wrapped = getattr(callback, "__wrapped__", None)
    if wrapped is not None:
        qualname = getattr(callback, "__qualname__", "") or ""
        module = getattr(callback, "__module__", "") or ""
        if (
            "login_required" in qualname
            or "permission_required" in qualname
            or module.startswith("django.contrib.auth.decorators")
        ):
            return True
    closure = getattr(callback, "__closure__", None) or ()
    for cell in closure:
        try:
            value = cell.cell_contents
        except ValueError:
            continue
        mod = getattr(value, "__module__", "") or ""
        if mod.startswith("django.contrib.auth.decorators"):
            return True
    return False


def _source_mentions_guard(obj) -> bool:
    try:
        source = inspect.getsource(obj)
    except (OSError, TypeError):
        return False
    # Cheap but effective — the canonical idioms for manual guarding.
    markers = (
        "request.user.is_authenticated",
        "@login_required",
        "@permission_required",
        "@staff_member_required",
        "@user_passes_test",
    )
    return any(m in source for m in markers)


def _describe(view_cls, callback) -> str:
    target = view_cls or callback
    module = target.__module__ or ""
    name = getattr(target, "__qualname__", None) or getattr(target, "__name__", repr(target))
    return f"{module}.{name}"


__all__ = ["ViewAuthorizationCheck"]
