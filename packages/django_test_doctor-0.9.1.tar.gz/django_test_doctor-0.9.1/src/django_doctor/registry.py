"""Check base class + discovery mechanism (entry points)."""

from __future__ import annotations

from dataclasses import dataclass, field
from importlib.metadata import entry_points
from typing import Iterable, Iterator

from .finding import Finding


@dataclass
class Project:
    """Handle passed to each check — exposes the Django project under audit.

    Kept deliberately small so checks don't grow tangled dependencies on
    internals. Extend with lazy properties (`@cached_property`) rather than
    eager imports so each check only pays for what it uses.
    """

    base_dir: str = ""
    config: dict = field(default_factory=dict)


class Check:
    """Base class for every analyzer."""

    id: str = ""  # unique, lowercase (e.g. "urls", "forms")
    description: str = ""
    # Higher = runs later. Cheap/critical checks should be low (system=10,
    # urls=50, forms=40). UI checks that rely on others come later.
    order: int = 100
    # Set to True for checks that hit external services or take > 5s locally.
    slow: bool = False

    def run(self, project: Project) -> Iterable[Finding]:
        raise NotImplementedError

    def get_config(self, project: Project) -> dict:
        return project.config.get(self.id, {})


def discover_checks() -> list[type[Check]]:
    """Load every check registered via the `django_doctor.checks` entry point.

    Kept tolerant — if a third-party plugin fails to import we emit a warning
    instead of crashing the whole run.
    """
    checks: list[type[Check]] = []
    eps = entry_points(group="django_doctor.checks")
    for ep in eps:
        try:
            cls = ep.load()
        except Exception as exc:  # pragma: no cover
            import warnings

            warnings.warn(
                f"django-doctor: failed to load check {ep.name!r}: {exc}",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        if not isinstance(cls, type) or not issubclass(cls, Check):
            continue
        if not cls.id:
            cls.id = ep.name
        checks.append(cls)
    return sorted(checks, key=lambda c: (c.order, c.id))


def iter_findings(
    checks: list[Check], project: Project
) -> Iterator[tuple[Check, Finding]]:
    for check in checks:
        for finding in check.run(project) or ():
            yield check, finding
