"""Standalone HTML reporter — a single self-contained page you can attach to
a CI job's artifact list or email around without needing a CSS asset bundle.

Design notes:

- No external dependencies at runtime. The reporter ships its own CSS inline;
  there's no need for ``jinja2`` even though the packaging advertises it as
  an optional extra — we just use an f-string. Adding jinja later is easy if
  we want to ship richer layouts, but today "readable in Safari 2005" beats
  "needs a build step".
- Severity classes map 1:1 to finding types so you can restyle by editing
  the ``<style>`` block at the top of the output.
- Per-check sections are collapsible ``<details>`` so a 500-finding report
  stays navigable.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from html import escape
from typing import Iterable

from .finding import Finding, Severity
from .registry import Check


_STYLE = """
:root {
  color-scheme: light dark;
  --bg: #0f172a;
  --surface: #111827;
  --muted: #9ca3af;
  --text: #e5e7eb;
  --accent: #02312e;
  --info: #38bdf8;
  --warning: #f59e0b;
  --error: #ef4444;
  --critical: #b91c1c;
  --ok: #10b981;
}
@media (prefers-color-scheme: light) {
  :root {
    --bg: #fafafa;
    --surface: #ffffff;
    --muted: #6b7280;
    --text: #111827;
  }
}
* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.5;
  padding: 2rem;
  max-width: 1100px;
  margin-inline: auto;
}
header { border-bottom: 2px solid var(--accent); padding-bottom: 1rem; margin-bottom: 2rem; }
header h1 { margin: 0 0 0.25rem; font-size: 1.6rem; }
header p { margin: 0; color: var(--muted); font-size: 0.9rem; }
.summary { display: flex; gap: 1rem; flex-wrap: wrap; margin: 1.5rem 0; }
.summary .pill {
  padding: 0.5rem 1rem;
  border-radius: 999px;
  background: var(--surface);
  font-size: 0.9rem;
  font-weight: 600;
  border: 1px solid rgba(255,255,255,0.05);
}
.pill.info { color: var(--info); }
.pill.warning { color: var(--warning); }
.pill.error { color: var(--error); }
.pill.critical { color: var(--critical); }
.pill.clean { color: var(--ok); }
details {
  background: var(--surface);
  border-radius: 8px;
  padding: 1rem 1.25rem;
  margin-bottom: 1rem;
  border: 1px solid rgba(255,255,255,0.05);
}
details[open] { padding-bottom: 1.25rem; }
summary { cursor: pointer; font-weight: 600; font-size: 1.05rem; list-style: none; }
summary::-webkit-details-marker { display: none; }
summary::before { content: "▶ "; color: var(--muted); font-size: 0.8rem; }
details[open] summary::before { content: "▼ "; }
summary .count { color: var(--muted); font-weight: 400; margin-left: 0.5rem; }
table { width: 100%; border-collapse: collapse; margin-top: 1rem; font-size: 0.9rem; }
th, td { text-align: left; padding: 0.5rem 0.75rem; border-bottom: 1px solid rgba(255,255,255,0.05); vertical-align: top; }
th { color: var(--muted); font-weight: 500; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; }
td.sev { font-weight: 700; white-space: nowrap; }
td.sev.info { color: var(--info); }
td.sev.warning { color: var(--warning); }
td.sev.error { color: var(--error); }
td.sev.critical { color: var(--critical); }
code { font-family: ui-monospace, "SF Mono", monospace; background: rgba(255,255,255,0.04); padding: 0.1rem 0.35rem; border-radius: 3px; font-size: 0.85em; }
.loc { color: var(--muted); font-family: ui-monospace, "SF Mono", monospace; font-size: 0.85em; }
.hint { color: var(--muted); font-style: italic; margin-top: 0.25rem; display: block; }
.empty { text-align: center; padding: 3rem; color: var(--muted); }
.empty strong { color: var(--ok); font-size: 1.2rem; display: block; margin-bottom: 0.5rem; }
"""


def render_html(
    results: list[tuple[Check, Finding]],
    *,
    title: str = "django-test-doctor report",
    generated_at: str | None = None,
) -> str:
    """Return a standalone HTML document reporting every finding."""
    grouped: dict[str, list[Finding]] = defaultdict(list)
    for check, finding in results:
        grouped[check.id].append(finding)

    counter: Counter[Severity] = Counter(f.severity for _, f in results)
    summary_html = _render_summary(counter)
    body = _render_sections(grouped) if results else _render_empty()

    meta = []
    if generated_at:
        meta.append(f"Generated {escape(generated_at)}")
    meta.append(f"{len(results)} finding(s)")
    meta_html = " · ".join(meta)

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{escape(title)}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>{_STYLE}</style>
</head>
<body>
<header>
  <h1>{escape(title)}</h1>
  <p>{meta_html}</p>
</header>
<section class="summary">{summary_html}</section>
{body}
</body>
</html>
"""


def _render_summary(counter: Counter[Severity]) -> str:
    if not counter:
        return '<span class="pill clean">✓ clean</span>'
    order = [Severity.CRITICAL, Severity.ERROR, Severity.WARNING, Severity.INFO]
    pieces = []
    for sev in order:
        if counter[sev]:
            label = sev.label
            pieces.append(
                f'<span class="pill {label}">{counter[sev]} {label}</span>'
            )
    return "".join(pieces)


def _render_sections(grouped: dict[str, list[Finding]]) -> str:
    out = []
    for check_id, findings in grouped.items():
        findings_sorted = sorted(findings, key=lambda f: -int(f.severity))
        rows = "\n".join(_render_row(f) for f in findings_sorted)
        out.append(
            f"""<details open>
  <summary>{escape(check_id)}<span class="count">— {len(findings)} finding(s)</span></summary>
  <table>
    <thead>
      <tr><th>Severity</th><th>Rule</th><th>Location</th><th>Message</th></tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>
</details>"""
        )
    return "\n".join(out)


def _render_row(finding: Finding) -> str:
    sev = finding.severity.label
    rule = escape(finding.rule or "-")
    location = escape(finding.location or "-")
    message = escape(finding.message)
    hint = (
        f'<span class="hint">→ {escape(finding.fix_hint)}</span>'
        if finding.fix_hint
        else ""
    )
    return f"""<tr>
  <td class="sev {sev}">{sev.upper()}</td>
  <td><code>{rule}</code></td>
  <td class="loc">{location}</td>
  <td>{message}{hint}</td>
</tr>"""


def _render_empty() -> str:
    return (
        '<div class="empty"><strong>✓ All checks passed</strong>'
        "<span>Doctor sees no findings.</span></div>"
    )


__all__ = ["render_html"]


def write_html(results: Iterable[tuple[Check, Finding]], path: str, **kwargs) -> None:
    """Convenience: render + write to disk in one step."""
    html = render_html(list(results), **kwargs)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html)
