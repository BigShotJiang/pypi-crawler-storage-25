"""Result types produced by checks."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any


class Severity(IntEnum):
    """Ordered so comparisons like `severity >= Severity.ERROR` work."""

    INFO = 10
    WARNING = 20
    ERROR = 30
    CRITICAL = 40

    @property
    def label(self) -> str:
        return self.name.lower()

    @property
    def emoji(self) -> str:
        return {
            Severity.INFO: "ℹ",
            Severity.WARNING: "⚠",
            Severity.ERROR: "✗",
            Severity.CRITICAL: "☠",
        }[self]

    @classmethod
    def from_string(cls, value: str) -> "Severity":
        return cls[value.upper()]


@dataclass(slots=True)
class Finding:
    """One actionable item produced by a check.

    Keep Findings small and self-contained — they're the unit the reporter
    renders, the JSON exporter serializes, and the ignore-rules match against.
    """

    severity: Severity
    check_id: str
    message: str
    rule: str = ""  # sub-rule id inside a check, e.g. "forms.blank_init"
    location: str = ""  # "path/to/file.py:42" or a URL name
    fix_hint: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def ignore_key(self) -> str:
        """Stable key used to silence a finding via config (ignore list)."""
        if self.rule:
            return f"{self.check_id}:{self.rule}"
        return f"{self.check_id}:*"
