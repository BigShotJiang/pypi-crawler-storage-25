"""``--diff <ref>`` — only surface findings that touch files changed since
a git reference.

The idea: on a large codebase a full ``doctor`` run can produce dozens of
findings. When a dev is reviewing their own PR they almost never care about
the existing debt — they want "what did *my* change introduce?". This
module answers that question by:

1. Asking git for the list of files changed between ``<ref>`` and ``HEAD``
   (plus unstaged modifications and untracked files).
2. Filtering the findings list to those whose ``location`` points inside
   one of those files.

Findings with no file-path in ``location`` (e.g. "users:login") fall
through unchanged — we can't tell if they're relevant, so we keep them
visible. Better a false positive than a silent drop.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import Iterable

from .finding import Finding
from .registry import Check


_PATH_LIKE_RE = re.compile(r"([^\s():]+?\.py)(?::\d+)?")


def changed_files(ref: str, repo_root: str | Path | None = None) -> set[str]:
    """Return absolute paths of every file that differs from ``ref``.

    Combines ``git diff --name-only <ref>...HEAD`` (committed changes),
    ``git diff --name-only`` (unstaged), and ``git ls-files --others
    --exclude-standard`` (new files) into a single set. Empty set on error.
    """
    root = _resolve_repo_root(repo_root)
    if root is None:
        return set()

    commands = [
        ["git", "-C", root, "diff", "--name-only", f"{ref}...HEAD"],
        ["git", "-C", root, "diff", "--name-only"],
        ["git", "-C", root, "ls-files", "--others", "--exclude-standard"],
    ]
    paths: set[str] = set()
    for cmd in commands:
        try:
            out = subprocess.run(
                cmd, capture_output=True, text=True, check=False, timeout=10
            )
        except (FileNotFoundError, subprocess.SubprocessError):
            return set()
        if out.returncode != 0:
            continue
        for line in out.stdout.splitlines():
            line = line.strip()
            if line:
                paths.add(str(Path(root) / line))
    return paths


def filter_by_diff(
    results: Iterable[tuple[Check, Finding]],
    ref: str,
    *,
    repo_root: str | Path | None = None,
) -> list[tuple[Check, Finding]]:
    """Return only findings that touch files changed since ``ref``.

    Findings with no resolvable file path in ``location`` are kept — we'd
    rather over-report than silently drop them.
    """
    files = changed_files(ref, repo_root=repo_root)
    if not files:
        return list(results)

    # Normalize to sets of basenames for cheaper suffix matching.
    normalized = {os.path.abspath(p) for p in files}
    basenames = {Path(p).name for p in normalized}

    kept: list[tuple[Check, Finding]] = []
    for check, finding in results:
        paths = _extract_paths(finding.location)
        if not paths:
            kept.append((check, finding))
            continue
        if any(_path_is_changed(p, normalized, basenames) for p in paths):
            kept.append((check, finding))
    return kept


def _resolve_repo_root(repo_root: str | Path | None) -> str | None:
    if repo_root:
        return str(Path(repo_root).resolve())
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, check=False, timeout=5,
        )
    except (FileNotFoundError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    path = out.stdout.strip()
    return path or None


def _extract_paths(location: str) -> list[str]:
    """Pull file-path-looking substrings out of a finding's location string."""
    if not location:
        return []
    paths = _PATH_LIKE_RE.findall(location)
    # Sometimes location is already a bare path like "/a/b/c.py:42".
    if not paths and (".py" in location or location.endswith(".html")):
        head = location.split(":")[0]
        if head:
            paths.append(head)
    return paths


def _path_is_changed(path: str, normalized: set[str], basenames: set[str]) -> bool:
    abs_path = os.path.abspath(path)
    if abs_path in normalized:
        return True
    # Location strings from dotted module paths (e.g. "app.forms.MyForm")
    # aren't real paths — fall back to basename equality.
    return Path(path).name in basenames


__all__ = ["changed_files", "filter_by_diff"]
