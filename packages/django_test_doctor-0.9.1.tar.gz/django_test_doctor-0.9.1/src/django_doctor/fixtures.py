"""Auto-generate minimal valid POST payloads from Django forms.

Produces the kind of dict you'd paste into the Django test client:

    from django_doctor.fixtures import make_form_fixture
    data = make_form_fixture(MyModelForm)
    client.post("/my-view/", data)

The generator is deliberately conservative — it returns the *simplest* valid
value for each required field and leaves optional fields out. Callers layer
their own overrides on top when a specific combination is needed.

``make_url_kwargs(pattern, view_cls)`` extends the same idea to URL
patterns with ``<int:pk>`` / ``<uuid:id>`` / ``<slug:slug>`` converters:
given a CBV bound to a model, it grabs (or creates) an instance and
returns the kwargs dict the resolver expects. That's what unlocks the
``urls`` and ``post_smoke`` checks on detail/edit routes.
"""

from __future__ import annotations

import datetime
import re
import uuid
from typing import Any

from django import forms
from django.db import models


def make_form_fixture(form_cls: type[forms.BaseForm], overrides: dict | None = None) -> dict:
    """Return a minimal dict of form-ready values for every required field."""
    form = form_cls()
    data: dict[str, Any] = {}
    for name, field in form.fields.items():
        if not field.required:
            continue
        try:
            value = _sample_value(field)
        except Exception:
            continue
        if value is _SKIP:
            continue
        data[name] = value
    if overrides:
        data.update(overrides)
    return data


_SKIP = object()


def _sample_value(field: forms.Field) -> Any:
    """Return a value acceptable to ``field.clean()`` for a required field."""
    # ModelChoiceField / ModelMultipleChoiceField — pick real objects.
    if isinstance(field, forms.ModelMultipleChoiceField):
        obj = field.queryset.first()
        return [obj.pk] if obj else _SKIP
    if isinstance(field, forms.ModelChoiceField):
        obj = field.queryset.first()
        return obj.pk if obj else _SKIP

    # Choice fields — pick the first non-empty choice.
    if isinstance(field, (forms.ChoiceField, forms.TypedChoiceField)):
        for value, _label in _iter_choices(field):
            if value in (None, ""):
                continue
            return value
        return _SKIP
    if isinstance(field, forms.MultipleChoiceField):
        for value, _label in _iter_choices(field):
            if value in (None, ""):
                continue
            return [value]
        return _SKIP

    # Numerics.
    if isinstance(field, forms.IntegerField):
        return field.min_value if field.min_value is not None else 1
    if isinstance(field, forms.DecimalField):
        return "0"
    if isinstance(field, forms.FloatField):
        return "0"

    # Booleans.
    if isinstance(field, forms.BooleanField):
        return True
    if isinstance(field, forms.NullBooleanField):
        return True

    # Dates / times.
    if isinstance(field, forms.DateTimeField):
        return datetime.datetime(2026, 1, 1, 0, 0).isoformat(sep=" ")
    if isinstance(field, forms.DateField):
        return "2026-01-01"
    if isinstance(field, forms.TimeField):
        return "00:00"

    # Email / URL / text.
    if isinstance(field, forms.EmailField):
        return "doctor@example.com"
    if isinstance(field, forms.URLField):
        return "https://example.com"
    if isinstance(field, forms.SlugField):
        return "doctor-x"

    # Files — the test client wants a SimpleUploadedFile. Skip to keep the
    # fixture serializable; POST-smoke callers layer their own files on top.
    if isinstance(field, (forms.FileField, forms.ImageField)):
        return _SKIP

    # Fallback for CharField + friends: a short non-empty string within limits.
    max_length = getattr(field, "max_length", None)
    sample = "x"
    if max_length is not None and max_length < len(sample):
        sample = sample[:max_length]
    return sample


def _iter_choices(field):
    """Flatten grouped choices (Django allows nested tuples)."""
    choices = field.choices
    if callable(choices):
        choices = choices()
    for entry in choices:
        value, label = entry
        if isinstance(label, (list, tuple)):
            for sub_value, sub_label in label:
                yield sub_value, sub_label
        else:
            yield value, label


def resolve_required_fields(form_cls: type[forms.BaseForm]) -> list[str]:
    """Names of every required field on this form (handy for reporting)."""
    form = form_cls()
    return [name for name, field in form.fields.items() if field.required]


# ---------------------------------------------------------------------------
# URL kwargs fixture — unlocks checks on detail/edit routes.
# ---------------------------------------------------------------------------


_URL_KWARG_RE = re.compile(r"<(?:(?P<conv>\w+):)?(?P<name>\w+)>")


def make_url_kwargs(route: str, view_cls: type | None = None) -> dict | None:
    """Return kwargs that will successfully resolve ``route``.

    Strategy, in order:

    1. **Model-backed CBV** — if ``view_cls`` exposes a ``model`` / ``queryset``
       attribute, grab the first existing instance (or create a dummy) and
       return its ``pk`` / ``slug`` under the converter's kwarg name.
    2. **Converter-typed fallback** — for any remaining kwarg, return a
       plausible literal matching the converter type: ``1`` for ``int``, a
       random ``UUID`` for ``uuid``, ``'x'`` for ``slug`` / ``str`` / ``path``.

    Returns ``None`` if the route needs a model-backed kwarg we can't fulfill
    (e.g. an empty queryset that refuses creation). Callers should treat
    ``None`` as "skip this URL, can't probe it automatically".
    """
    required = list(_URL_KWARG_RE.finditer(route))
    if not required:
        return {}

    kwargs: dict = {}
    instance = _fetch_or_create_instance(view_cls) if view_cls else None

    for match in required:
        conv = match.group("conv") or "str"
        name = match.group("name")

        if instance is not None and _kwarg_binds_to_instance(name, conv, instance):
            value = _instance_value_for(name, conv, instance)
            if value is not None:
                kwargs[name] = value
                continue

        fallback = _converter_fallback(conv)
        if fallback is None:
            return None
        kwargs[name] = fallback

    return kwargs


def _fetch_or_create_instance(view_cls: type | None):
    """Return an existing model instance for ``view_cls`` or try to create one."""
    if view_cls is None:
        return None
    queryset = getattr(view_cls, "queryset", None)
    model = getattr(view_cls, "model", None)
    if queryset is None and model is None:
        return None
    if queryset is not None:
        instance = queryset.first()
        if instance is not None:
            return instance
        model = queryset.model
    else:
        instance = model._default_manager.first()
        if instance is not None:
            return instance

    # Nothing in the DB — try to build a minimal row.
    return _try_create_minimal(model)


def _try_create_minimal(model):
    """Create a row with the bare minimum required fields set to sample data.

    Best-effort — fails silently and returns None if the model has complex
    NOT NULL FKs we can't satisfy. Callers handle that gracefully.
    """
    try:
        kwargs: dict = {}
        for field in model._meta.get_fields():
            if not hasattr(field, "attname"):
                continue
            if field.auto_created or field.primary_key:
                continue
            if getattr(field, "has_default", lambda: False)():
                continue
            if getattr(field, "null", False):
                continue
            sample = _sample_for_model_field(field)
            if sample is None:
                # Can't fill this required field — bail.
                return None
            kwargs[field.attname] = sample
        return model._default_manager.create(**kwargs)
    except Exception:
        return None


def _sample_for_model_field(field):
    if isinstance(field, models.ForeignKey):
        related = field.related_model._default_manager.first()
        return related.pk if related else None
    if isinstance(field, models.BooleanField):
        return False
    if isinstance(field, (models.IntegerField, models.FloatField, models.DecimalField)):
        return 0
    if isinstance(field, models.DateTimeField):
        return datetime.datetime(2026, 1, 1, 0, 0)
    if isinstance(field, models.DateField):
        return datetime.date(2026, 1, 1)
    if isinstance(field, models.SlugField):
        return "doctor-slug"
    if isinstance(field, models.UUIDField):
        return uuid.uuid4()
    if isinstance(field, (models.CharField, models.TextField)):
        max_len = getattr(field, "max_length", 50) or 50
        return "x"[: max(1, min(max_len, 50))]
    return None


def _kwarg_binds_to_instance(name: str, converter: str, instance) -> bool:
    """Decide whether we should use ``instance`` to fill kwarg ``name``."""
    # Any reasonable naming: pk, id, <model>_id, slug — just trust the match
    # since the caller already bound view_cls → model.
    if name in {"pk", "id", "slug"}:
        return True
    if name.endswith("_id") or name.endswith("_pk"):
        return True
    # For converter uuid/int on a non-canonical name, still try the pk.
    return converter in {"uuid", "int"}


def _instance_value_for(name: str, converter: str, instance):
    if name == "slug":
        slug = getattr(instance, "slug", None)
        if slug is not None:
            return slug
    value = instance.pk
    if value is None:
        return None
    if converter == "uuid":
        return str(value)
    return value


def _converter_fallback(converter: str):
    if converter == "int":
        return 1
    if converter == "uuid":
        return str(uuid.uuid4())
    if converter in {"slug", "str", "path"}:
        return "x"
    return None
