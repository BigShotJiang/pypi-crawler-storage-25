"""Rich-based reporter. JSON/HTML reporters live next to this one later."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from typing import Iterable

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .finding import Finding, Severity
from .registry import Check


_SEVERITY_COLOR = {
    Severity.INFO: "dim cyan",
    Severity.WARNING: "yellow",
    Severity.ERROR: "red",
    Severity.CRITICAL: "bold red on white",
}


class Reporter:
    def __init__(self, console: Console | None = None) -> None:
        self.console = console or Console()

    def render(self, results: list[tuple[Check, Finding]]) -> None:
        if not results:
            self.console.print(
                Panel.fit(
                    "[bold green]✓ All checks passed[/]\n[dim]Doctor sees no findings.[/]",
                    border_style="green",
                )
            )
            return

        grouped: dict[str, list[Finding]] = defaultdict(list)
        for check, finding in results:
            grouped[check.id].append(finding)

        for check_id, findings in grouped.items():
            self._render_check(check_id, findings)

        self._render_summary(results)

    def _render_check(self, check_id: str, findings: list[Finding]) -> None:
        table = Table(
            title=f"[bold]{check_id}[/] — {len(findings)} finding(s)",
            title_justify="left",
            show_lines=False,
            expand=True,
            border_style="dim",
        )
        table.add_column("Sev", width=9, no_wrap=True)
        table.add_column("Rule", style="cyan", no_wrap=True)
        table.add_column("Location", style="magenta", overflow="fold")
        table.add_column("Message", overflow="fold")

        for f in sorted(findings, key=lambda x: -x.severity):
            color = _SEVERITY_COLOR[f.severity]
            sev = Text(f.severity.label.upper(), style=color)
            msg = Text(f.message)
            if f.fix_hint:
                msg.append(f"\n→ {f.fix_hint}", style="green dim")
            table.add_row(sev, f.rule or "-", f.location or "-", msg)

        self.console.print(table)
        self.console.print()

    def _render_summary(self, results: list[tuple[Check, Finding]]) -> None:
        counter: Counter[Severity] = Counter(f.severity for _, f in results)
        pieces = []
        for sev in [Severity.CRITICAL, Severity.ERROR, Severity.WARNING, Severity.INFO]:
            if counter[sev]:
                pieces.append(f"[{_SEVERITY_COLOR[sev]}]{counter[sev]} {sev.label}[/]")
        summary = " · ".join(pieces) if pieces else "[green]clean[/]"
        self.console.print(Panel.fit(summary, title="Summary", border_style="dim"))


def to_json(results: Iterable[tuple[Check, Finding]]) -> str:
    payload = [
        {
            "check_id": check.id,
            "severity": f.severity.label,
            "rule": f.rule,
            "location": f.location,
            "message": f.message,
            "fix_hint": f.fix_hint,
            "extra": f.extra,
        }
        for check, f in results
    ]
    return json.dumps(payload, indent=2, ensure_ascii=False)
