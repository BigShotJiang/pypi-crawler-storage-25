import asyncio
from typing import Optional, List, Dict, Any
from mcp import ClientSession
from contextlib import AsyncExitStack

from .exceptions import (
    ConnectionError,
    NotConnectedError,
    ToolNotFoundError,
    ToolExecutionError
)
from .generator import ToolFunctionGenerator

class UniClient:
    """
    A unified MCP Client that connects to an MCP server (SSE or Stdio)
    and allows execution of tools.
    """
    def __init__(self, endpoint: Optional[str] = None, command: Optional[str] = None, args: Optional[List[str]] = None):
        """
        :param endpoint: A URL (http://...) for remote SSE, or a file path (e.g., 'server.py') for local Stdio.
        :param command: Explicit command to run for Stdio (e.g., 'python'). If None, inferred from endpoint.
        :param args: Additional arguments for the Stdio command.
        """
        import os
        self.endpoint = endpoint or os.getenv("MCP_SERVER")
        self.command = command
        self.args = args or []
        self.session: Optional[ClientSession] = None
        self._exit_stack: Optional[AsyncExitStack] = None

    async def connect(self):
        """Connects to the MCP server."""
        self._exit_stack = AsyncExitStack()
        
        try:
            if self.endpoint.startswith("http://") or self.endpoint.startswith("https://"):
                from mcp.client.sse import sse_client
                read_stream, write_stream = await self._exit_stack.enter_async_context(sse_client(url=self.endpoint))
            else:
                from mcp.client.stdio import stdio_client, StdioServerParameters
                
                cmd = self.command
                arguments = self.args
                
                # Infer command if not explicitly provided
                if not cmd:
                    if self.endpoint.endswith(".py"):
                        cmd = "python"
                        arguments = [self.endpoint] + self.args
                    elif self.endpoint.endswith(".js"):
                        cmd = "node"
                        arguments = [self.endpoint] + self.args
                    else:
                        # Treat endpoint as the command executable itself
                        cmd = self.endpoint
                        
                server_params = StdioServerParameters(
                    command=cmd,
                    args=arguments
                )
                read_stream, write_stream = await self._exit_stack.enter_async_context(stdio_client(server_params))

            self.session = await self._exit_stack.enter_async_context(ClientSession(read_stream, write_stream))
            await self.session.initialize()
        except Exception as e:
            # Clean up exit stack if connection fails during initialization
            await self._exit_stack.aclose()
            self._exit_stack = None
            raise ConnectionError(f"Failed to connect to MCP server at '{self.endpoint}': {e}") from e

    async def disconnect(self):
        """Disconnects from the MCP server."""
        if self._exit_stack:
            await self._exit_stack.aclose()
            self._exit_stack = None
            self.session = None

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.disconnect()

    async def get_tools(self) -> List[Any]:
        """Lists available tools from the MCP server."""
        if not self.session:
            raise NotConnectedError("Client not connected. Call connect() first.")
        response = await self.session.list_tools()
        return response.tools

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> str:
        """Executes a tool on the MCP server and returns the text result."""
        if not self.session:
            raise NotConnectedError("Client not connected. Call connect() first.")
        
        try:
            result = await self.session.call_tool(tool_name, arguments=arguments)
            
            if result.isError:
                # Read the error text from the server
                error_msg = ""
                for content in result.content:
                    if content.type == "text":
                        error_msg += content.text
                raise ToolExecutionError(f"Server returned error for tool '{tool_name}': {error_msg}")

            # Read the response text from the server
            tool_result_str = ""
            for content in result.content:
                if content.type == "text":
                    tool_result_str += content.text
            return tool_result_str
        except Exception as e:
            raise ToolExecutionError(f"Execution of tool '{tool_name}' failed: {e}") from e

    async def explore(self) -> Dict[str, List[str]]:
        """
        Explores the connected MCP server and returns the names of available tools, 
        prompts, and resources.
        """
        if not self.session:
            raise NotConnectedError("Client not connected. Call connect() first.")
            
        exploration_data = {
            "tools": [],
            "prompts": [],
            "resources": []
        }
        
        # Get Tools
        try:
            tools_response = await self.session.list_tools()
            if tools_response and hasattr(tools_response, 'tools'):
                exploration_data["tools"] = [tool.name for tool in tools_response.tools]
        except Exception as e:
            print(f"Notice: Failed to fetch tools: {e}")
            
        # Get Prompts
        try:
            prompts_response = await self.session.list_prompts()
            if prompts_response and hasattr(prompts_response, 'prompts'):
                exploration_data["prompts"] = [prompt.name for prompt in prompts_response.prompts]
        except Exception as e:
            pass # Server might not support prompts
            
        # Get Resources
        try:
            resources_response = await self.session.list_resources()
            if resources_response and hasattr(resources_response, 'resources'):
                exploration_data["resources"] = [resource.name for resource in resources_response.resources]
        except Exception as e:
            pass # Server might not support resources
            
        return exploration_data
    async def get_tool_details(self, tool_name: str) -> Dict[str, Any]:
        """
        Retrieves the complete details (schema, description, etc.) of a specific tool.
        """
        if not self.session:
            raise NotConnectedError("Client not connected. Call connect() first.")
            
        tools_response = await self.session.list_tools()
        for tool in tools_response.tools:
            if tool.name == tool_name:
                return {
                    "name": tool.name,
                    "description": tool.description,
                    "inputSchema": tool.inputSchema
                }
        raise ToolNotFoundError(f"Tool '{tool_name}' not found on the server.")

    async def load_tools(self) -> Any:
        """
        Dynamically generates and returns a Python object where each available 
        MCP tool is a callable native Python method.
        """
        if not self.session:
            raise NotConnectedError("Client not connected. Call connect() first.")
            
        tools_response = await self.session.list_tools()
        
        # Delegate tool generation to the modular generator
        generator = ToolFunctionGenerator(self)
        toolset = await generator.generate(tools_response.tools)
        return toolset
