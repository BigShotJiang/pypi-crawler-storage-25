# Agents Assemble Hackathon — Plan

**Hackathon:** [Agents Assemble](https://agents-assemble.devpost.com/)
**Track:** Superpower (MCP Server)
**Deadline:** 11 maja 2026, 23:00 EDT
**Nagrody:** $25,000 ($7,500 / $5,000 / $2,500 / 10×$1,000)
**Sędziowie:** Mayo Clinic, Cleveland Clinic, Microsoft Research, CHOP

---

## 1. Use case

### Problem

Badacz chorób rzadkich chce zbudować kohortę pacjentów z chorobą Fabry'ego
na podstawie opublikowanych case reportów (PubMed/PMC). Ma 50 artykułów.

- Ręczna ekstrakcja: **30-60 min / artykuł** (= ~30h pracy)
- Każdy artykuł ma inną strukturę — brak standaryzacji
- Autorzy piszą "butterfly-shaped facial rash" zamiast HPO:0025300 "Malar rash"
- Wyciągnięte dane trzeba wrzucić do rejestru (FHIR) — kolejna warstwa pracy

### Rozwiązanie

Agent na Prompt Opinion wywołuje **catchfly MCP server**, który:
1. Odkrywa schemat automatycznie (jakie pola są w tekście)
2. Wyciąga ustrukturyzowane dane (demographics, fenotyp, genotyp, leczenie, outcome)
3. Normalizuje terminy do ontologii (HPO, ORPHA/MONDO, RxNorm)
4. Generuje FHIR Bundle (Patient + Condition + Observation[])
5. Push do FHIR servera → gotowa kohorta

**50 artykułów w minuty, nie dni.**

### One-liner dla sędziów

> "We turn published rare disease case reports into FHIR-compliant registry data
> in seconds, not hours."

---

## 2. Architektura

```
┌──────────────────────────────────────────────────────────────┐
│                   Prompt Opinion Platform                     │
│                                                              │
│  Użytkownik (badacz) ──→ Agent ──→ catchfly MCP Server       │
│                                    (nasz, self-hosted)       │
└──────────────────────────┬───────────────────────────────────┘
                           │ POST /mcp (JSON-RPC)
                           │ + SHARP headers (x-fhir-server-url,
                           │   x-fhir-access-token, x-patient-id)
                           ▼
┌──────────────────────────────────────────────────────────────┐
│              catchfly MCP Server (Python)                     │
│                                                              │
│  FastMCP (mcp SDK) ──→ catchfly Pipeline                     │
│                         │                                    │
│                         ├─ discover_schema()                 │
│                         ├─ extract_records()                 │
│                         ├─ normalize_terms()                 │
│                         └─ to_fhir_bundle() [NOWE]           │
│                                │                             │
│                                ▼                             │
│                         OpenAI / Claude API                  │
│                         (nasz klucz, nasz koszt)             │
└──────────────────────────┬───────────────────────────────────┘
                           │ FHIR R4 REST API
                           ▼
┌──────────────────────────────────────────────────────────────┐
│              FHIR Server (HAPI FHIR / demo)                  │
│              GET /Condition?code=ORPHA:324                    │
│              → kohorta pacjentów z chorobą Fabry'ego          │
└──────────────────────────────────────────────────────────────┘
```

### Kto płaci za LLM?

| Kontekst | Model |
|---|---|
| **Hackathon demo** | My płacimy. Kilka case reportów = ~$0.50 w API calls. Nic. |
| **Produkcja wariant A** | SaaS — subskrypcja za dostęp do MCP servera |
| **Produkcja wariant B** | BYO-key — użytkownik podaje swój klucz OpenAI w config |
| **Produkcja wariant C** | Lokalne modele (Ollama) — zero kosztów API |

Na demo **nie ma problemu** — to jest nasz serwer, nasz klucz, nasze grosze.
W opisie submission wspomnimy o BYO-key i local models jako production-ready opcjach.

### Dlaczego Python jest OK

MCP to protokół HTTP + JSON-RPC. Prompt Opinion wywołuje `POST /mcp` i dostaje JSON.
Nie obchodzi ich język. Python MCP SDK (`mcp` v1.26.0) ma pełne wsparcie
Streamable HTTP przez FastMCP:

```python
from mcp.server.fastmcp import FastMCP
from catchfly import Pipeline

mcp = FastMCP(
    "catchfly",
    host="0.0.0.0",
    port=8000,
    stateless_http=True,
    json_response=True,
)

@mcp.tool()
async def extract_records(text: str, disease_context: str = "") -> dict:
    """Extract structured patient data from a medical case report."""
    pipe = Pipeline(provider="openai/gpt-4.1")
    result = pipe.extract(text)
    return result.to_dict()
```

Deploy: Docker + Cloud Run / Fly.io. Referencyjne repo Prompt Opinion
jest w TypeScript, ale to ich wybór — nie wymóg.

---

## 3. MCP Tools do wystawienia

### Tool 1: `discover_schema`

Odkrywa jakie pola występują w tekście (demographics, symptoms, genetics, treatment...).
Przydatne gdy badacz nie wie co jest w artykule.

```
Input:  { "text": "A 34-year-old male presented with..." }
Output: { "fields": ["age", "sex", "diagnosis", "symptoms", "genetic_variant", "treatment", "outcome"],
          "suggested_schema": { ... Pydantic-compatible JSON Schema ... } }
```

### Tool 2: `extract_records`

Główne narzędzie. Wyciąga ustrukturyzowane rekordy z tekstu case reportu.

```
Input:  { "text": "...", "schema": { ... } | null, "normalize": true }
Output: { "records": [ { "age": 34, "sex": "male", "diagnosis": "Fabry disease",
                          "symptoms": ["angiokeratoma", "acroparesthesia"],
                          "genetic_variant": "GLA c.644A>G (p.N215S)", ... } ],
          "provenance": { "confidence": 0.92 } }
```

Jeśli `schema` = null, catchfly sam odkrywa schemat (pipeline z discovery).

### Tool 3: `normalize_terms`

Normalizacja terminów medycznych do standardowych ontologii.

```
Input:  { "terms": ["butterfly-shaped facial rash", "Fabry disease", "agalsidase beta"],
          "ontologies": ["HPO", "ORPHA", "RxNorm"] }
Output: { "mappings": [
            { "original": "butterfly-shaped facial rash", "code": "HP:0025300", "label": "Malar rash", "system": "HPO", "confidence": 0.95 },
            { "original": "Fabry disease", "code": "ORPHA:324", "label": "Fabry disease", "system": "Orphanet", "confidence": 0.99 },
            { "original": "agalsidase beta", "code": "RxNorm:1234567", "label": "agalsidase beta", "system": "RxNorm", "confidence": 0.91 }
          ] }
```

### Tool 4: `to_fhir_bundle`

Konwertuje wyekstrahowane dane do FHIR R4 Bundle. **Nowy komponent do zbudowania.**

```
Input:  { "records": [ ... ], "fhir_server_url": "..." }
Output: { "bundle": { "resourceType": "Bundle", "type": "transaction",
                       "entry": [
                         { "resource": { "resourceType": "Patient", ... } },
                         { "resource": { "resourceType": "Condition", "code": { "coding": [{ "system": "http://www.orpha.net", "code": "324" }] } } },
                         { "resource": { "resourceType": "Observation", "code": { "coding": [{ "system": "http://purl.obolibrary.org/obo/hp.owl", "code": "0025300" }] } } }
                       ] },
          "validation": { "errors": 0, "warnings": 1 } }
```

### Tool 5: `push_to_fhir` (opcjonalny)

Jeśli SHARP headers zawierają FHIR server URL + token, pushuje Bundle bezpośrednio.

```
Input:  { "bundle": { ... } }
Output: { "created_resources": ["Patient/123", "Condition/456", "Observation/789"],
          "fhir_server": "http://hapi.fhir.org/baseR4" }
```

Wykorzystuje `x-fhir-server-url` i `x-fhir-access-token` z request headers (SHARP spec).

---

## 4. FHIR mapping

Dane z case reportu → FHIR R4 resources:

| Wyekstrahowane pole | FHIR Resource | Coding system |
|---|---|---|
| Wiek, płeć, etnicity | `Patient` | — |
| Diagnoza | `Condition` | Orphanet (ORPHA), MONDO |
| Objawy / fenotyp | `Observation[]` | HPO |
| Wariant genetyczny | `DiagnosticReport` + `Observation` | HGVS, ClinVar |
| Leki | `MedicationStatement` | RxNorm, ATC |
| Historia rodzinna | `FamilyMemberHistory` | HPO |
| Cały case report | `Bundle` (type: transaction) | — |
| Link do źródła | `DocumentReference` (→ PubMed DOI) | — |

### Minimalny scope na hackathon

Nie musimy mapować wszystkiego. **MVP:**
- `Patient` (wiek, płeć)
- `Condition` (diagnoza → ORPHA)
- `Observation[]` (fenotypy → HPO)
- `Bundle` (wrapper)

To wystarczy na przekonujące demo. Resztę (genetyka, leki, family history)
oznaczamy jako "supported in full version".

---

## 5. Demo flow (video, max 3 min)

### 0:00-0:20 — Problem statement
Slajd: "50 case reports. 30 hours of manual work. We do it in 3 minutes."
Pokaż stos PDFów / PubMed search results.

### 0:20-0:50 — Prompt Opinion platform
Otwieramy chatwithpo.ai. Pokazujemy catchfly MCP server w marketplace.
Użytkownik pisze: "Extract patient data from this Fabry disease case report"
Wkleja tekst case reportu.

### 0:50-1:40 — Ekstrakcja w akcji
Agent wywołuje catchfly tools:
1. `discover_schema` → "Found 7 relevant fields"
2. `extract_records` → tabela z danymi pacjenta
3. `normalize_terms` → "butterfly-shaped rash" → HPO:0025300

Pokazujemy surowy output — ustrukturyzowane dane z ontology codes.

### 1:40-2:10 — FHIR output
4. `to_fhir_bundle` → pokaż wygenerowany Bundle JSON
5. `push_to_fhir` → push do HAPI FHIR servera

Przełączamy na HAPI FHIR UI: `GET /Condition?code=ORPHA:324` → 1 wynik.

### 2:10-2:40 — Drugi case report = kohorta
Wklejamy drugi case report. Ten sam flow.
`GET /Condition?code=ORPHA:324` → **2 wyniki**. Kohorta rośnie.

### 2:40-3:00 — Zamknięcie
"catchfly: From case reports to patient cohorts. Open source. FHIR-native.
Available on PyPI and Prompt Opinion Marketplace."
Logo Silene Systems + catchfly.

---

## 6. Plan implementacji

### Faza 1: MCP Server skeleton (2 dni)

- [ ] Nowy pakiet `catchfly-mcp/` (albo `mcp_server/` w monorepo)
- [ ] FastMCP server z Streamable HTTP
- [ ] Tool `extract_records` — wrapper na `Pipeline.extract()`
- [ ] Tool `discover_schema` — wrapper na `Pipeline` z discovery
- [ ] Tool `normalize_terms` — wrapper na normalizację
- [ ] Dockerfile + docker-compose
- [ ] Test: lokalne wywołanie przez MCP client SDK

### Faza 2: FHIR export (2-3 dni)

- [ ] Moduł `catchfly.export.fhir` (albo standalone w MCP serverze)
- [ ] Mapping: extracted record → FHIR Patient
- [ ] Mapping: extracted record → FHIR Condition (ORPHA coded)
- [ ] Mapping: extracted record → FHIR Observation[] (HPO coded)
- [ ] Bundle builder (transaction bundle)
- [ ] FHIR push client (POST Bundle do FHIR servera)
- [ ] SHARP headers parsing (`x-fhir-server-url`, `x-fhir-access-token`)
- [ ] Test z HAPI FHIR (Docker)

### Faza 3: Ontology normalization hardening (1-2 dni)

- [ ] HPO lookup (pronto + HPO OBO file)
- [ ] Orphanet lookup (ORPHA codes)
- [ ] Fallback: LLM-based mapping gdy exact match nie zadziała
- [ ] Confidence scores w output

### Faza 4: Deploy + Prompt Opinion integration (1-2 dni)

- [ ] Deploy na Cloud Run / Fly.io
- [ ] Publiczny HTTPS URL
- [ ] Rejestracja w Prompt Opinion Marketplace
- [ ] SHARP capabilities declaration (`fhir_context_required: true`)
- [ ] Test end-to-end na platformie

### Faza 5: Demo + submission (1-2 dni)

- [ ] Przygotować 2-3 prawdziwe case reporty (Fabry disease, public domain)
- [ ] HAPI FHIR server z seed data do demo
- [ ] Nagrać demo video (max 3 min)
- [ ] Napisać opis submission na Devpost
- [ ] Screenshots + architektura diagram

### Timeline

| Tydzień | Daty | Co robimy |
|---|---|---|
| 1 | 25-31 marca | Faza 1: MCP server skeleton |
| 2 | 1-7 kwietnia | Faza 2: FHIR export |
| 3 | 8-14 kwietnia | Faza 3: Ontology hardening |
| 4 | 15-21 kwietnia | Faza 4: Deploy + Prompt Opinion |
| 5 | 22-28 kwietnia | Faza 5: Demo + submission |
| 6-7 | 29 kwietnia - 11 maja | Buffer / polish / edge cases |

**2+ tygodnie buforu** przed deadline.

---

## 7. Ryzyka i mitygacje

| Ryzyko | Impact | Mitygacja |
|---|---|---|
| Prompt Opinion platform niestabilna / słaba dokumentacja | Wysoki | Zacząć integrację wcześnie (tydzień 1). Discord support. |
| FHIR mapping bardziej złożony niż myślimy | Średni | MVP scope: Patient + Condition + Observation. Reszta = "roadmap". |
| Sędziowie nie rozumieją MCP | Niski | Demo video pokazuje end-user experience, nie technologię pod spodem. |
| Dużo uczestników w Track 1 | Niski | Nikt inny nie ma opublikowanej na PyPI biblioteki z 311 testami. |
| API costs przy wielu demo runs | Niski | Użyć gpt-4.1-mini do demo, cache'ować wyniki. Max $5. |
| SHARP spec się zmieni | Niski | To 3 headery HTTP — adaptacja = 30 min. |

---

## 8. Dlaczego wygramy (argumenty dla sędziów)

### AI Factor (kryterium 1)
- **Schema discovery** — catchfly sam odkrywa jakie pola są w tekście, bez z góry zdefiniowanego schematu. Tradycyjny software tego nie potrafi.
- **Normalizacja** — LLM + embedding cascade mapuje swobodny tekst na kody ontologiczne. Rule-based NER tego nie ogarnia.

### Potential Impact (kryterium 2)
- **30h → 3 min** dla kohorty 50 pacjentów
- FDA/EMA akceptują real-world evidence z case reportów pod 21st Century Cures Act — ale tylko jeśli dane są ustrukturyzowane i audytowalne
- 300M+ ludzi na świecie z chorobami rzadkimi, ~6,000 chorób, większość danych jest w case reportach (nie w EHR)

### Feasibility (kryterium 3)
- Biblioteka jest **opublikowana na PyPI** (v1.0.3, 311 testów, Apache-2.0)
- Output w **FHIR R4** — standard, który już jest w każdym szpitalu
- Dane syntetyczne / de-identified w demo — compliance z rules hackatonu
- MCP = open standard — zero vendor lock-in

---

## 9. Zasoby

- **Prompt Opinion repos:** [po-community-mcp](https://github.com/prompt-opinion/po-community-mcp), [po-adk-python](https://github.com/prompt-opinion/po-adk-python)
- **SHARP-on-MCP spec:** https://www.sharponmcp.com/
- **Python MCP SDK:** `mcp` v1.26.0 na PyPI
- **HAPI FHIR (Docker):** `docker run -p 8080:8080 hapiproject/hapi:latest`
- **HPO ontology:** https://hpo.jax.org/
- **Orphanet:** https://www.orpha.net/
- **Hackathon Discord:** https://discord.gg/JS2bZVruUg
- **Prompt Opinion support:** support@promptopinion.ai
