# Catchfly -- Analiza rynku, zastosowania i strategia Go-to-Market

**Data:** 2026-03-25
**Przygotowano dla:** Silene Systems (Adrian Michalski)

---

## Spis tresci

1. [Zastosowania medyczne i kliniczne](#1-zastosowania-medyczne-i-kliniczne)
2. [Zastosowania akademickie i badawcze](#2-zastosowania-akademickie-i-badawcze)
3. [Zastosowania biznesowe i korporacyjne](#3-zastosowania-biznesowe-i-korporacyjne)
4. [Krajobraz konkurencyjny](#4-krajobraz-konkurencyjny)
5. [Rekomendacje Go-to-Market](#5-rekomendacje-go-to-market)

---

## 1. Zastosowania medyczne i kliniczne

### 1.1 Budowanie kohort pacjentow z chorobami rzadkimi (obecne zastosowanie)

**Stan rynku:** Automatyczna identyfikacja pacjentow z chorobami rzadkimi z nieustrukturyzowanych tekstow klinicznych to szybko rozwijajacy sie obszar. OHDSI Rare Diseases Working Group w 2025 r. wyznaczyla jako kluczowy cel ewaluacje i wdrozenie NLP oraz LLM do identyfikacji kohort chorob rzadkich. System DeepRare (Nature, 2025) integruje ponad 40 wyspecjalizowanych narzedzi i przetwarza heterogeniczne dane kliniczne, w tym opisy tekstowe, terminy ontologii fenotypowej i wyniki badan genetycznych.

**Narzedzia ekstrakcji fenotypow HPO:**
- **PhenoTagger** -- hybrydowa metoda laczaca dopasowywanie slownikowe z modelem BioBERT do rozpoznawania terminow HPO w tekście biomedycznym
- **PhenoBCBERT / PhenoGPT** -- modele LLM do rozszerzonego rozpoznawania fenotypow w notatkach klinicznych
- **FastHPOCR** -- pragmatyczne, szybkie rozpoznawanie konceptow HPO
- **Monarch Initiative** -- integracyjna platforma laczaca fenotypy z genotypami miedzy gatunkami

**Przewaga catchfly:** Catchfly jest jedynym narzedziem open-source, ktore laczy odkrywanie schematu (schema discovery), ekstrakcje i normalizacje wartosci z wbudowanym mapowaniem ontologii HPO (`catchfly[medical]`). Zadne z powyzszych narzedzi nie oferuje pelnego pipeline'u schema discovery -> extraction -> normalization w jednym pakiecie.

**Potencjal rynkowy:** Na swiecie jest ok. 7 000 znanych chorob rzadkich, dotykajacych 300 mln ludzi globalnie. Kazda z nich wymaga budowania kohort z rozproszonych opisow przypadkow.

---

### 1.2 Dopasowywanie do badan klinicznych (Clinical Trial Matching)

**Stan rynku:** Tempus AI (program TIME) uzywa NLP i LLM do codziennego algorytmicznego dopasowywania pacjentow do badan klinicznych. Ich narzedzie przesiewowe pomoglo zidentyfikowac odpowiednich pacjentow, odrzucajac ~72% niekwalifikujacych sie chorych z poczatkowej puli. Tempus przeanalizowal ponad 190 000 pacjentow, dopasowujac 332 pacjentow do 21 unikalnych badan interwencyjnych.

**Kluczowi gracze:**
- **Tempus AI** (TIME Trial Network, TApp) -- lider w onkologii
- **Flatiron Health** (Roche) -- baza danych EHR do emulacji badan klinicznych
- **Deep6 AI** -- NLP do precyzyjnego dopasowywania pacjentow
- **TrialTranslator** -- platforma AI do translacji kryteriow kwalifikacji

**Zastosowanie catchfly:** Catchfly moze ekstrakowac ustrukturyzowane dane pacjenta z opisow przypadkow klinicznych (case reports), kart informacyjnych i historii chorob, a nastepnie porownywac je z kryteriami wlaczenia/wylaczenia badan klinicznych. Pipeline schema discovery -> extraction umozliwia automatyczne dostosowanie sie do roznych formatow dokumentow klinicznych bez recznego definiowania schematow.

---

### 1.3 Pharmacovigilance / Ekstrakcja zdarzen niepozadanych

**Stan rynku:** NLP jest kluczowe dla bezpieczenstwa lekow -- umozliwia automatyczne rozpoznawanie i kodowanie zdarzen niepozadanych (ADE) w tekście swobodnym, nawet gdy termin nie jest dokladny. Modele takie jak GPT-4o i fine-tunowane BERT-y sa oceniane do ekstrakcji ADE z danych klinicznych.

**Kluczowi gracze i narzedzia:**
- **John Snow Labs / Spark NLP for Healthcare** -- uzywany przez 59% zespolow AI w ochronie zdrowia, identyfikuje ponad 400 typow encji, klienci: McKesson, Optum, GE Healthcare
- **IQVIA** -- zaawansowana platforma NLP do wydobywania informacji z tekstu na skale, przyspieszenie przegladow literaturowych o 30%
- **Veeva Systems** -- Vault Safety do zarzadzania danymi pharmacovigilance
- **ArisGlobal** -- LifeSphere Safety do automatyzacji przetwarzania zdarzen niepozadanych

**Zastosowanie catchfly:** Catchfly moze byc uzywany do ekstrakcji i normalizacji zdarzen niepozadanych z opisow przypadkow, raportow spontanicznych i literaturowych. Normalizacja wartosci (np. rozne opisy tego samego objawu -> forma kanoniczna) jest kluczowym wyroznikiem -- catchfly robi to natywnie przez `LLMCanonicalization` i klasteryzacje embeddingowa (`KLLMeans`).

---

### 1.4 Strukturyzacja dokumentacji medycznej

**Stan rynku:** Generatywne LLM-y osiagaja >99% dokladnosci w ekstrakcji i strukturyzacji informacji z raporow patologicznych (np. raki piersi). Narzedzia takie jak LangExtract (Google) obsluguja ponad 50 typow dokumentow medycznych.

**Typy dokumentow:**
- Karty wypisowe (discharge summaries)
- Raporty patologiczne
- Notatki kliniczne
- Raporty radiologiczne
- Notatki operacyjne

**Kluczowi gracze:**
- **John Snow Labs** -- Spark NLP Healthcare z ponad 130 mln pobran w 2024 r.
- **LangExtract** (Google) -- >95% dokladnosci dla dokumentow medycznych
- **Amazon Comprehend Medical** -- usluga AWS do ekstrakcji encji medycznych

**Zastosowanie catchfly:** Pipeline catchfly moze przetwarzac karty wypisowe i raporty patologiczne, automatycznie odkrywajac schemat (jakie pola wystepuja w dokumentach) i normalizujac wartosci. Kluczowa przewaga: schema discovery eliminuje potrzebe recznego definiowania schematow dla kazdego typu dokumentu.

---

### 1.5 Automatyzacja przegladow systematycznych

**Stan rynku:** Narzedzia do przegladow systematycznych sa szeroko uzywane w medycynie:
- **Covidence** -- platforma webowa do screeningu, wymaga platnej subskrypcji
- **ASReview** (Utrecht University) -- open-source, active learning do priorytetyzacji badan
- **SWIFT-Review** -- darmowe narzedzie do priorytetyzacji literaturowej
- **EPPI-Reviewer** -- kompleksowe wsparcie dla przegladow systematycznych
- **DistillerSR** -- komercyjne narzedzie do przegladow
- **RobotReviewer** -- automatyczna ocena ryzyka bledu (risk of bias)

**Zastosowanie catchfly:** Catchfly moze automatyzowac faze ekstrakcji danych z przegladow systematycznych -- po zidentyfikowaniu relevantnych publikacji (np. przez ASReview), catchfly moze wydobyc ustrukturyzowane dane (np. parametry badan, wyniki, charakterystyki populacji) z pelnych tekstow artykulow. To jest etap, ktorego zadne z powyzszych narzedzi nie automatyzuje w pelni.

---

### 1.6 Generowanie Real-World Evidence (RWE)

**Stan rynku:** Rynek rozwiazan RWE ma osiagnac 10,8 mld USD do 2030 r. (z 5,42 mld USD w 2025 r., CAGR 14,8%). W styczniu 2025 r. IQVIA i NVIDIA nawiazaly wspolprace w celu przyspieszenia AI w ochronie zdrowia.

**Kluczowi gracze:**
- **IQVIA** -- ponad 1,2 mld zdeidentyfikowanych rekordow pacjentow, lider rynku
- **Flatiron Health** (Roche) -- onkologiczne dane RWE
- **Optum** (UnitedHealth) -- dane z EHR i roszczen ubezpieczeniowych
- **TriNetX** -- globalna siec danych zdrowotnych
- **Aetion** -- platforma analityczna RWE
- **Merative** (dawniej IBM Watson Health) -- dane kliniczne i roszczeniowe

**Zastosowanie catchfly:** Catchfly moze generowac ustrukturyzowane dane RWE z opisow przypadkow klinicznych i literaturowych -- szczegolnie cenne dla chorob rzadkich, gdzie tradycyjne zrodla danych (EHR, rejestry) sa niewystarczajace. Pipeline checkpointow umozliwia przetwarzanie duzych zbiorow dokumentow z kontrola kosztow (`max_cost_usd`).

---

### 1.7 Drug Repurposing (repozycjonowanie lekow)

**Stan rynku:** Grafy wiedzy (knowledge graphs) sa kluczowym narzedziem do odkrywania nowych zastosowan istniejacych lekow. DRKG (Drug Repurposing Knowledge Graph) integruje dane z DrugBank, Hetionet, STRING, DisGeNET i innych zrodel, zawierajac 97 238 encji i 5 874 261 relacji.

**Podejscia:**
- Framework Extract-Define-Canonicalize (EDC) -- trojfazowe podejscie LLM do konstrukcji grafow wiedzy
- GraphRAG -- polaczenie embeddingów grafowych z generacja wspomagana wyszukiwaniem
- PharmaKG -- heterogeniczny graf wiedzy z ~7 600 wezlami i 500 958 krawedziami

**Zastosowanie catchfly:** Catchfly moze wydobywac relacje lek-choroba-gen z literaturowych opisow przypadkow i artykulow badawczych. Pipeline schema discovery moze automatycznie identyfikowac typy encji i relacji w korpusie dokumentow, co jest kluczowe dla budowania grafow wiedzy. Normalizacja wartosci zapewnia, ze rozne nazwy tego samego leku/genu/choroby sa mapowane do form kanonicznych.

---

## 2. Zastosowania akademickie i badawcze

### 2.1 Wydobywanie danych z literatury naukowej

**Stan rynku:** Automatyczna ekstrakcja danych z artykulow naukowych staje sie standardem. DELM (Data Extraction with Language Models) to nowy toolkit operujacy w fazach: ladowanie danych, preprocessing z segmentacja na chunki, i batched LLM execution z walidacja Pydantic.

**Zastosowanie catchfly:** Idealnie dopasowane -- catchfly realizuje dokladnie ten sam pipeline (discovery -> extraction -> normalization), ale z dodatkowa warstwa automatycznego odkrywania schematu. Badacz nie musi definiowac schematu z gory -- catchfly moze przeanalizowac probke artykulow i zaproponowac schemat ekstrakcji.

---

### 2.2 Konstrukcja grafow wiedzy

**Stan rynku:** W 2024-2025 r. budowanie grafow wiedzy osiagnelo dojrzalosc produkcyjna dzieki LLM-om. NLP-AKG wyekstrahowal 620 353 encje i 2 271 584 relacje z 60 826 artykulow ACL Anthology. Paper2lkg przeksztalca pojedyncze artykuly w lokalne reprezentacje grafowe.

**Kluczowe narzedzia:**
- **LKD-KGC** -- lekki framework do indukcji schematu przez klasteryzacje typow encji
- **Paper2lkg** -- pipeline KGC z LLM-ami dla artykulow akademickich
- **Neo4j + LangChain** -- popularna kombinacja do grafow wiedzy

**Zastosowanie catchfly:** Catchfly moze sluzyc jako warstwa ekstrakcji i normalizacji w pipeline'ach KGC. Kluczowa przewaga: klasteryzacja embeddingowa (`KLLMeans`) naturalnie mapuje sie na indukcje typow encji, a normalizacja zapewnia spojnosc wezlow grafu.

---

### 2.3 Analiza korpusow naukowych

**Scenariusze:**
- Ekstrakcja parametrow eksperymentalnych z artykulow (np. stezenia, dawki, temperatury)
- Wydobywanie metadanych z grantow i publikacji
- Analiza trendow badawczych w czasie
- Porownywanie metodologii miedzy badaniami

**Zastosowanie catchfly:** Semantyczne chunking (`chonkie[semantic]`) pozwala catchfly na inteligentne dzielenie dlugich artykulow naukowych na fragmenty tematyczne, co zwieksza dokladnosc ekstrakcji. Callback `on_schema_ready` pozwala badaczowi zmodyfikowac odkryty schemat przed ekstrakcja.

---

## 3. Zastosowania biznesowe i korporacyjne

### 3.1 Normalizacja katalogow produktowych (e-commerce)

**Stan rynku:** Rynek oprogramowania do ekstrakcji danych ma osiagnac 2,5 mld USD do konca 2025 r. Kluczowi gracze:
- **Zoovu** -- AI do ingestion, czyszczenia, normalizacji i wzbogacania danych produktowych
- **DataWeave** -- multimodalna AI (tekst + obraz) do tagowania i normalizacji atrybutow
- **Mirakl Catalog Transformer** -- analiza obrazow do ekstrakcji atrybutow
- **Semantico.ai** -- automatyczna klasyfikacja i normalizacja atrybutow

**Zastosowanie catchfly:** Catchfly moze normalizowac atrybuty produktowe z roznych zrodel (dostawcy, marketplace'y) do form kanonicznych. Pipeline: tekst opisu produktu -> schema discovery (jakie atrybuty wystepuja) -> extraction (wartosci atrybutow) -> normalization (np. "niebieski", "Navy", "granatowy" -> "Niebieski/Granatowy"). Modul `LLMCanonicalization` jest naturalnym dopasowaniem do tego zastosowania.

---

### 3.2 Kategoryzacja opinii klientow

**Zastosowanie catchfly:** Catchfly moze automatycznie odkrywac kategorie tematyczne z opinii klientow (schema discovery), ekstrakowac sentyment i kluczowe tematy, a nastepnie normalizowac je do spatnego taksonomii. Przykladowy pipeline:
- Discovery: identyfikacja kategorii (jakosc, obsluga, dostawa, cena, ...)
- Extraction: przypisanie kazdej opinii do kategorii z wartosciami
- Normalization: ujednolicenie terminologii

---

### 3.3 Parsing CV / resume

**Stan rynku:** Wiodacy gracze:
- **Textkernel/Sovren** -- parsuja ponad 2 mld CV i ogloszen rocznie, LLM Parser oparty na GPT-3.5
- **hireEZ** -- AI sourcing z parsowaniem CV
- **Daxtra** -- wielojezyczne parsowanie CV
- **HireAbility** -- ekstrakcja danych z CV

**Zastosowanie catchfly:** Catchfly moze sluzyc jako open-source'owa alternatywa do parsowania CV z automatycznym odkrywaniem schematu. Zamiast predefiniowanych pol, catchfly moze analizowac probke CV i automatycznie zidentyfikowac pola (doswiadczenie, wyksztalcenie, umiejetnosci, certyfikaty), a nastepnie normalizowac wartosci (np. rozne nazwy stanowisk -> kanoniczne tytuły).

---

### 3.4 Ekstrakcja z dokumentow prawnych

**Stan rynku:** Rynek narzedzi AI do analizy umow rosnie dynamicznie. Kluczowi gracze:
- **Kira Systems** (Litera) -- uzywany przez 80% z top 25 kancelarii M&A, >1 400 wytrenowanych klauzul, dokladnosc 90%+
- **Luminance** -- wlasny prawniczy LLM, unsupervised ML do wykrywania anomalii w umowach
- **Spellbook** -- AI do redagowania i analizy umow
- **LegalFly** -- automatyzacja procesow prawnych
- **Ironclad** -- zarzadzanie cyklem zycia umow

**Zastosowanie catchfly:** Catchfly moze byc uzywany do ekstrakcji kluczowych klauzul z umow (daty, strony, warunki platnosci, klauzule SLA). Schema discovery jest szczegolnie wartosciowe w due diligence M&A, gdzie trzeba szybko zidentyfikowac typy klauzul w duzym zbiorze heterogenicznych umow.

---

### 3.5 Przetwarzanie dokumentow lancucha dostaw

**Stan rynku:** Rynek IDP w logistyce ma osiagnac 3,3 mld USD w 2025 r. Narzedzia:
- **Veryfi** -- OCR wytrenowany na tysiącach formatow konosamentow (BOL)
- **Reducto** -- przetwarzanie BOL, dokumentow celnych, faktur przez jedno API
- **Affinda** -- ekstrakcja z dowolnego konosamentu z >99% dokladnoscia
- **Ondox.ai** -- AI do przetwarzania dokumentow logistycznych

**Zastosowanie catchfly:** Catchfly moze przetwarzac dokumenty logistyczne (konosamenty, listy przewozowe, dokumenty celne), automatycznie identyfikujac pola i normalizujac wartosci (np. kody HS, nazwy portow, nazwy przewoznikow). Wsparcie dla PDF (`catchfly[pdf]`, `catchfly[docling]`) umozliwia bezposrednie przetwarzanie skanow.

---

### 3.6 Przetwarzanie roszczen ubezpieczeniowych

**Stan rynku:** Rynek AI w ubezpieczeniach ma wzrosnac z 14,99 mld USD w 2025 do 246,3 mld USD do 2035 r. (CAGR 32,3%). AI osiaga 96% dokladnosci w ekstrakcji danych vs. 35% bledow przy recznym przetwarzaniu. Automatyzacja moze redukowac koszty przetwarzania o 50-65%.

**Kluczowi gracze:**
- **Infrrd** -- IDP specjalizowane dla ubezpieczen
- **Agentech** -- automatyzacja przetwarzania roszczen
- **Aptarro** -- AI do roszczen ubezpieczeniowych

**Zastosowanie catchfly:** Catchfly moze ekstrakowac dane z roznorodnych formularzy roszczen (rozne formaty, rozni ubezpieczyciele) bez koniecznosci tworzenia szablonow. Schema discovery jest kluczowe -- system moze samodzielnie zidentyfikowac pola w nowym typie formularza.

---

### 3.7 Ekstrakcja z dokumentow finansowych

**Stan rynku:** AI skraca czas analizy 10-K z 8-12 godzin do <30 minut. Narzedzia:
- **LlamaExtract** (LlamaIndex) -- ekstrakcja strukturalnych danych z SEC filings
- **V7 Go** -- przetwarzanie XBRL, sprawozdan finansowych
- **TalkToEDGAR** -- porownywanie filings rok do roku
- **Magic FinServ DeepSight** -- sledzenie ujawnien regulacyjnych

**Zastosowanie catchfly:** Catchfly moze przetwarzac raporty finansowe (10-K, 10-Q, prospekty), automatycznie identyfikujac kluczowe metryki finansowe i normalizujac wartosci (np. rozne formaty walut, dat, procent). Checkpointy pozwalaja na przetwarzanie duzych zbiorow filings z mozliwoscia wznowienia.

---

## 4. Krajobraz konkurencyjny

### 4.1 Bezposredni konkurenci (extraction + normalization)

| Narzedzie | Typ | Schema Discovery | Extraction | Normalization | Cena |
|-----------|-----|-----------------|------------|---------------|------|
| **Catchfly** | Open-source Python | Tak (LLM) | Tak (LLM) | Tak (LLM + embedding clustering) | Darmowe (+ koszty LLM) |
| **Instructor** | Open-source Python | Nie | Tak (LLM) | Nie | Darmowe |
| **LangExtract** (Google) | Open-source Python | Nie | Tak (LLM) | Nie | Darmowe |
| **DELM** | Open-source Python | Nie | Tak (LLM) | Nie | Darmowe |
| **Kor** | Open-source Python | Nie | Tak (LLM) | Nie | Darmowe |
| **Marvin** | Open-source Python | Nie | Tak (LLM, tylko OpenAI) | Nie | Darmowe |

**Kluczowy wniosek:** Zadna z open-source'owych bibliotek nie oferuje pelnego pipeline'u schema discovery + extraction + normalization. Catchfly jest jedynym narzedziem, ktore laczy wszystkie trzy etapy.

### 4.2 Platformy IDP (enterprise)

| Platforma | Focus | Cena | Kluczowa cecha |
|-----------|-------|------|----------------|
| **Unstructured.io** | ETL dla GenAI | Freemium + Enterprise | 64 typy plikow, Fortune 1000 |
| **Unstract** | LLM-powered ETL | Open-source (AGPL) | No-code, deployment jako API |
| **AWS Textract** | OCR + ekstrakcja z dokumentow | Pay-per-use | Integracja z ekosystemem AWS |
| **Google Document AI** | OCR + ekstrakcja | Pay-per-use | Custom training, 50 jezykow |
| **Azure AI Document Intelligence** | OCR + ekstrakcja + custom models | Pay-per-use | Hybrydowe wdrozenie (on-prem) |
| **Rossum** | IDP dla faktur | Enterprise ($100M Series A) | Lider IDC MarketScape 2023-24 |
| **Docugami** | AI z dokumentow biznesowych | Enterprise | Generatywna AI na dokumentach |
| **ABBYY** | IDP | Enterprise | 35+ lat doswiadczenia, 10 000+ klientow |

### 4.3 Narzedzia medyczne/kliniczne

| Narzedzie | Focus | Cena |
|-----------|-------|------|
| **John Snow Labs / Spark NLP** | Clinical NLP, 400+ typow encji | Komercyjna licencja |
| **Amazon Comprehend Medical** | Ekstrakcja encji medycznych | Pay-per-use |
| **PhenoTagger** | Rozpoznawanie terminow HPO | Open-source (badawcze) |
| **Tempus AI** | Clinical trial matching | Enterprise |
| **IQVIA NLP** | RWE, pharmacovigilance | Enterprise |

### 4.4 Unikalna propozycja wartosci catchfly (UVP)

**Catchfly wyroznia sie na tle konkurencji w nastepujacych obszarach:**

1. **Automatyczne odkrywanie schematu (Schema Discovery)** -- zadna inna open-source'owa biblioteka nie oferuje automatycznego wykrywania struktury danych z tekstu. LangExtract, Instructor, Kor wymagaja predefiniowanego schematu.

2. **Wbudowana normalizacja wartosci** -- catchfly ma natywna normalizacje z klasteryzacja embeddingowa (KLLMeans) i kanonizacja LLM-owa. Inne narzedzia wymagaja osobnych krokow post-processingu.

3. **Pipeline end-to-end z kontrola kosztow** -- `max_cost_usd`, checkpointy, estymacja kosztow przed uruchomieniem -- to unikalne cechy, ktorych nie ma Instructor, LangExtract ani Kor.

4. **Mapowanie ontologiczne (HPO)** -- jedyna biblioteka open-source z wbudowanym wsparciem dla ontologii medycznych.

5. **Modularna architektura strategii** -- kazdy etap (discovery, extraction, normalization, field selection) moze byc wymieniony na wlasna implementacje.

6. **Model-agnostic** -- dziala z dowolnym API kompatybilnym z OpenAI (OpenAI, Anthropic, lokalne modele przez Ollama/vLLM).

**Catchfly NIE konkuruje bezposrednio z:**
- Platformami OCR/IDP (Textract, Document AI) -- catchfly przetwarza tekst, nie obrazy/skany
- Enterprise IDP (Rossum, ABBYY) -- catchfly to biblioteka deweloperska, nie platforma SaaS
- Spark NLP -- catchfly nie ma wlasnych modeli NER, polega na LLM-ach

---

## 5. Rekomendacje Go-to-Market

### 5.1 Priorytetowe wertykale (ranking)

#### Tier 1 -- Natychmiastowe mozliwosci (0-6 miesiecy)

**A) Choroby rzadkie i biomedycyna badawcza**
- *Dlaczego:* Najlepsza dopasowanie produkt-rynek (product-market fit). Catchfly juz to robi. Rynek jest niszowy, ale klienci maja duze budżety (granty NIH/ERC, fundusze VC w biotech).
- *Docelowi klienci:* Grupy badawcze chorob rzadkich, fundacje pacjentow, male firmy biotech
- *Brakujace funkcje:* Lepsza integracja z PubMed/PMC API, wsparcie dla dodatkowych ontologii (OMIM, Orphanet, SNOMED CT), eksport do formatow OHDSI/OMOP
- *Strategia:* Publikacja naukowa (case study z real-world danymi), prezentacje na konferencjach (ASHG, ESHG, Orphanet conferences), wspolpraca z OHDSI Rare Diseases WG

**B) Przeglady systematyczne i meta-analizy**
- *Dlaczego:* Ogromny niezaspokojony popyt. ASReview i Covidence automatyzuja screening, ale NIE ekstrakcje danych z pelnych tekstow. Catchfly moze wypelnic te luke.
- *Docelowi klienci:* Biblioteki akademickie, grupy Cochrane, agencje HTA (NICE, IQWiG, AOTMiT)
- *Brakujace funkcje:* Integracja z Covidence/ASReview (import listy artykulow), szablony schematow dla typowych przegladow (RCT, obserwacyjne)
- *Strategia:* Partnerstwo z ASReview (Utrecht University) -- ASReview do screeningu, catchfly do ekstrakcji. Artykul metodologiczny w Journal of Clinical Epidemiology lub Systematic Reviews.

#### Tier 2 -- Sredniookresowe mozliwosci (6-18 miesiecy)

**C) Pharmacovigilance i bezpieczenstwo lekow**
- *Dlaczego:* Duzy rynek, silna potrzeba automatyzacji. Ale: wymaga certyfikacji, walidacji i compliance (GxP, 21 CFR Part 11).
- *Docelowi klienci:* Dzialy bezpieczenstwa farmaceutycznego, CRO (IQVIA, Parexel, ICON), regulator (EMA, FDA)
- *Brakujace funkcje:* Audit trail, walidacja zgodna z regulacjami, predefiniowane schematy MedDRA, integracja z bazami danych safety (np. FAERS)
- *Strategia:* Partnerstwo z CRO lub firma farmaceutyczna na pilot. POC (Proof of Concept) z danymi pharmacovigilance.

**D) Drug Repurposing i Knowledge Graph Construction**
- *Dlaczego:* Szybko rosnocy rynek, doskonale dopasowanie do pipeline'u catchfly (extract + normalize + canonicalize). Framework EDC (Extract-Define-Canonicalize) jest dokladnie tym, co catchfly robi.
- *Docelowi klienci:* Grupy badawcze drug discovery, firmy computational pharma, instytuty bioinformatyczne
- *Brakujace funkcje:* Eksport do formatow grafowych (RDF/TTL, Neo4j), ekstrakcja relacji (nie tylko encji), integracja z DrugBank/DisGeNET
- *Strategia:* Opublikowac tutorial "Building a Drug Repurposing Knowledge Graph with Catchfly" na GitHub/Medium.

#### Tier 3 -- Dlugookresowe mozliwosci (18+ miesiecy)

**E) Normalizacja katalogow produktowych (e-commerce)**
- *Dlaczego:* Duzy rynek (2,5 mld USD), ale silna konkurencja (Zoovu, DataWeave, Mirakl). Catchfly musialby dodac wsparcie dla obrazow (multimodalne LLM-y).
- *Docelowi klienci:* Marketplace'y, agregatory produktowe, firmy PIM (Product Information Management)
- *Brakujace funkcje:* Multimodalna ekstrakcja (tekst + obraz), integracja z PIM-ami (Akeneo, Pimcore), taksonomie produktowe (GPC, UNSPSC)

**F) Ekstrakcja z dokumentow prawnych**
- *Dlaczego:* Lukratywny rynek, ale zdominowany przez wyspecjalizowanych graczy (Kira, Luminance). Catchfly musialby dostosowac normalizacje do jezyka prawniczego.
- *Brakujace funkcje:* Szablony dla typow umow, terminologia prawnicza, integracja z systemami DMS

**G) Ekstrakcja z dokumentow finansowych**
- *Dlaczego:* Duzy rynek, ale wymaga specjalistycznej wiedzy (XBRL, GAAP/IFRS). LlamaExtract juz obsługuje ten przypadek.
- *Brakujace funkcje:* Parsowanie XBRL, schematy finansowe, integracja z EDGAR API

---

### 5.2 Rekomendowane funkcje wg priorytetu

| Priorytet | Funkcja | Wplywa na wertykale |
|-----------|---------|---------------------|
| P0 | Integracja z PubMed/PMC API (bezposredni import artykulow) | Choroby rzadkie, systematyczne przeglady, pharma |
| P0 | Dodatkowe ontologie medyczne (Orphanet, SNOMED CT, MedDRA) | Choroby rzadkie, pharmacovigilance, RWE |
| P1 | Eksport do OMOP CDM / OHDSI formatow | Choroby rzadkie, RWE |
| P1 | Szablony schematow dla typowych zastosowan | Przeglady systematyczne, pharmacovigilance |
| P1 | Integracja z ASReview/Covidence | Przeglady systematyczne |
| P2 | Ekstrakcja relacji (nie tylko encji/wartosci) | Knowledge graphs, drug repurposing |
| P2 | Eksport do formatow grafowych (RDF, Neo4j) | Knowledge graphs |
| P2 | Audit trail i compliance logging | Pharmacovigilance, dokumentacja medyczna |
| P3 | Multimodalna ekstrakcja (tekst + obraz) | E-commerce, dokumenty logistyczne |
| P3 | Predefiniowane taksonomie biznesowe | E-commerce, supply chain |

---

### 5.3 Mozliwosci partnerstw

| Partner | Typ | Wartosc |
|---------|-----|---------|
| **ASReview** (Utrecht University) | Integracja techniczna | ASReview screening + catchfly extraction = pelny pipeline SR |
| **OHDSI Rare Diseases WG** | Wspolpraca badawcza | Walidacja catchfly na danych OMOP, dostep do spolecznosci |
| **Monarch Initiative** | Integracja ontologiczna | Lepsze mapowanie fenotypow, dostep do danych genotyp-fenotyp |
| **Chonkie** | Partnerstwo open-source | Juz zintegrowane -- poglebic wspolprace na semantic chunking |
| **Instructor** | Ekosystem Python | Catchfly moze byc pozycjonowany jako "Instructor + schema discovery + normalization" |
| **Neo4j** | Integracja techniczna | Eksport grafow wiedzy bezposrednio do Neo4j |
| **Hugging Face** | Dystrybucja | Publikacja pre-built pipeline'ow jako Hugging Face Spaces |

---

### 5.4 Strategia open-source

**Rekomendowany model: Open Core**

- **Rdzen open-source (Apache-2.0):** Schema discovery, extraction, normalization, pipeline orchestration -- to co jest teraz. Utrzymac i rozwijac.
- **Funkcje premium (przyszlosc):** Hostowalny SaaS z GUI, audit trail dla regulated industries, pre-built schematy dla verticali, dedykowane wsparcie.

**Taktyki budowania spolecznosci:**
1. **Publikacja naukowa** -- artykul w JMIR, BMC Medical Informatics, lub Journal of Biomedical Informatics demonstrujacy catchfly na case study chorob rzadkich
2. **Tutoriale i cookbooki** -- rozbudowac istniejace notebooki o nowe wertykale (pharmacovigilance, systematic reviews)
3. **Benchmarki** -- opublikowac porownanie catchfly vs. reczna ekstrakcja na publicznym datasecie (np. n2c2/i2b2 challenges)
4. **Konferencje** -- prezentacje na PyCon, SciPy, OHDSI Symposium, AMIA
5. **GitHub Discussions / Discord** -- budowanie spolecznosci uzytkownikow

---

### 5.5 Podsumowanie strategiczne

```
Catchfly zajmuje unikalna pozycje na rynku:

1. Jedyna open-source'owa biblioteka Python laczaca schema discovery + extraction + normalization
2. Naturalnie dopasowana do biomedycyny (HPO, chunking semantyczny, case reports)
3. Niska bariera wejscia (pip install catchfly, Pipeline.quick())
4. Kontrola kosztow LLM (max_cost_usd, cost estimation)

Najlepsza sciezka wzrostu:
  Choroby rzadkie (ugruntowac pozycje)
  -> Przeglady systematyczne (pokrewny rynek, duza baza uzytkownikow)
  -> Pharmacovigilance (wysoka wartosc, wymaga compliance)
  -> Knowledge graphs / drug repurposing (rosnacy rynek)
  -> Enterprise verticals (e-commerce, prawo, finanse -- dlugoterminowo)
```

---

## Dane rynkowe -- podsumowanie

| Rynek | Wartosc 2025 | Prognoza | CAGR |
|-------|-------------|----------|------|
| Intelligent Document Processing (IDP) | 3,0-10,6 mld USD | 33-44 mld USD (2030-2034) | 25-35% |
| Real-World Evidence Solutions | 5,42 mld USD | 10,8 mld USD (2030) | 14,8% |
| AI w ubezpieczeniach | 14,99 mld USD | 246,3 mld USD (2035) | 32,3% |
| Contract Research Organizations (CRO) | ~90 mld USD | Rosnacy | 8,4% |
| Ekstrakcja danych (software) | 2,5 mld USD | Rosnacy | -- |

---

## Zrodla

### Rynek IDP i ekstrakcji dokumentow
- [Intelligent Document Processing Market Size (Precedence Research)](https://www.precedenceresearch.com/intelligent-document-processing-market)
- [50 Key Statistics in IDP for 2025 (Docsumo)](https://www.docsumo.com/blogs/intelligent-document-processing/intelligent-document-processing-market-report-2025)
- [IDP Market Report 2026 (Business Research Company)](https://www.thebusinessresearchcompany.com/report/intelligent-document-processing-global-market-report)

### Pharmacovigilance i NLP kliniczne
- [NLP for Adverse Drug Event Detection (Springer)](https://link.springer.com/article/10.1007/s40264-024-01505-6)
- [NLP Surfaces Adverse Events (Applied Clinical Trials)](https://www.appliedclinicaltrialsonline.com/view/how-nlp-surfaces-adverse-events-and-safety-insights-to-improve-drug-safety-processes)
- [LLMs for Adverse Drug Events (MDPI)](https://www.mdpi.com/2077-0383/14/15/5490)
- [John Snow Labs -- Healthcare AI](https://www.johnsnowlabs.com/)
- [John Snow Labs 2024 Record Revenue](https://www.globenewswire.com/news-release/2025/01/15/3010354/0/en/John-Snow-Labs-Closes-2024-with-Record-Revenue-Customer-Base-Growth-and-Open-Source-Adoption-Thanks-to-State-of-the-art-Healthcare-Specific-Large-Language-Models.html)

### Choroby rzadkie
- [OHDSI Rare Diseases Working Group 2025](https://www.ohdsi.org/wp-content/uploads/2025/02/RareDiseases-2025.pdf)
- [DeepRare -- Agentic System for Rare Disease Diagnosis (Nature)](https://www.nature.com/articles/s41586-025-10097-9)
- [Hybrid Framework for Rare Disease Phenotyping (BMC)](https://bmcmedinformdecismak.biomedcentral.com/articles/10.1186/s12911-024-02698-7)
- [PhenoTagger (Bioinformatics)](https://academic.oup.com/bioinformatics/article/37/13/1884/6104813)

### Clinical Trial Matching
- [Tempus TIME Trial Network](https://www.tempus.com/oncology/clinical-trial-matching/)
- [Impact of AI on Clinical Trial Design (Tempus)](https://www.tempus.com/resources/content/articles/how-ai-impacts-clinical-trial-process-design-matching/)

### Real-World Evidence
- [IQVIA Real World Evidence](https://www.iqvia.com/solutions/real-world-evidence)
- [RWE Solutions Market (Grand View Research)](https://www.grandviewresearch.com/industry-analysis/real-world-evidence-solutions-market-report)
- [36 Top RWE Platforms in 2025](https://www.mahalo.health/insights/top-real-world-evidence-rwe-platforms)

### Przeglady systematyczne
- [Digital Tools for Systematic Reviews (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC12035789/)
- [AI Tools for Systematic Reviews (Purdue)](https://library.pfw.edu/c.php?g=1475770&p=10989757)
- [AI for Systematic Literature Reviews (ScienceDirect)](https://www.sciencedirect.com/science/article/pii/S1041608025002250)

### Drug Repurposing i Knowledge Graphs
- [Knowledge Graphs for Drug Discovery (Taylor & Francis)](https://www.tandfonline.com/doi/full/10.1080/17460441.2025.2490253)
- [DRKG -- Drug Repurposing Knowledge Graph (GitHub)](https://github.com/gnn4dr/DRKG)
- [NLP in Drug Discovery (Taylor & Francis)](https://www.tandfonline.com/doi/full/10.1080/17460441.2025.2490835)
- [Extract-Define-Canonicalize Framework (arXiv)](https://arxiv.org/abs/2404.03868)

### Dokumentacja medyczna
- [NLP for EHR Cancer Data (JMIR)](https://medinform.jmir.org/2025/1/e68707)
- [LLMs for Pathology Reports (ScienceDirect)](https://www.sciencedirect.com/science/article/pii/S2153353925001075)
- [Generative AI for Pathology Reports (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC11906504/)
- [LangExtract -- AI Healthcare Text Extraction](https://langextract.pro/)

### Konkurenci -- ekstrakcja z LLM
- [Instructor -- Structured LLM Outputs](https://python.useinstructor.com/)
- [LangExtract (Google, GitHub)](https://github.com/google/langextract)
- [DELM Toolkit (arXiv)](https://arxiv.org/html/2509.20617v1)
- [Kor (GitHub)](https://github.com/eyurtsev/kor)
- [Unstract -- LLM Powered ETL](https://unstract.com/)
- [Unstructured.io (GitHub)](https://github.com/Unstructured-IO/unstructured)

### Platformy IDP
- [AWS Textract vs Azure vs Google Cloud (InfoWorld)](https://www.infoworld.com/article/2271149/review-document-parsing-in-aws-azure-and-google-cloud.html)
- [Rossum AI Alternatives (AIMultiple)](https://research.aimultiple.com/rossum-ai-competitors/)
- [Kira by Litera](https://www.litera.com/products/kira)
- [Luminance](https://www.luminance.com/)

### E-commerce i normalizacja katalogow
- [Zoovu Catalog Management](https://zoovu.com/catalog-management)
- [DataWeave Attribute Extraction](https://dataweave.com/us/attribute-extraction-norm)
- [Semantico.ai -- Product Classification](https://semantico.ai/blog/manual-product-classification-and-attribute-normalization-the-hidden-pain-for-multi-brand/)

### Dokumenty finansowe
- [LLMs for Financial Document Analysis (IntuitionLabs)](https://intuitionlabs.ai/articles/llm-financial-document-analysis)
- [SEC Filing Extraction (LlamaIndex)](https://www.llamaindex.ai/blog/mining-financial-data-from-sec-filings-with-llamaextract)

### CV Parsing
- [Textkernel/Sovren](https://www.textkernel.com/sovren/)
- [Top Resume Parsers 2025 (Airparser)](https://airparser.com/blog/top-cv-and-resume-parsers/)

### Ubezpieczenia
- [AI Claims Processing Guide 2025 (Agentech)](https://www.agentech.com/resources/articles/ai-claims-processing-guide-2025)
- [IDP for Insurance (Infrrd)](https://www.infrrd.ai/solutions/insurance-document-processing)

### Supply Chain
- [AI Supply Chain Document Automation 2025](https://www.bizdata360.com/how-ai-transforms-supply-chain-document-automation-processes-2025/)
- [Reducto for Logistics](https://reducto.ai/industries/logistics-supply-chain)

### Knowledge Graph Construction
- [LLM-empowered KG Construction Survey (arXiv)](https://arxiv.org/pdf/2510.20345)
- [NLP-AKG (arXiv)](https://arxiv.org/abs/2502.14192)
- [LLM-TEXT2KG 2025 Workshop](https://aiisc.ai/text2kg2025/)
