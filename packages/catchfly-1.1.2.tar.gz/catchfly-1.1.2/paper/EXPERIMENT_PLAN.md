# Plan eksperymentów SICI — metodyka dla EMNLP

## 1. Co jest SICI w kontekście catchfly

catchfly to pipeline: **schema discovery → extraction → normalization**.

`KLLMeansClustering` normalizuje wartości **jednego pola** — dostaje listę surowych wartości (np. `["HP", "Hewlett-Packard", "H.P."]`) i grupuje je w klastry z kanonicznymi nazwami. Robi to algorytmem k-LLMmeans (Diaz-Rodriguez 2026): k-means w embedding space z periodycznymi LLM-owymi podsumowaniami klastrów jako centroidami.

**SICI** to sposób inicjalizacji centroidów. Zamiast k-means++ (losowe, geometryczne), bierzemy opisy z `field_metadata` schematu (wygenerowane przez `SchemaOptimizer`) i embeddujemy je jako startowe centroidy.

```python
# Bez SICI — k-means++ init, LLM summaries
kllm = KLLMeansClustering(num_clusters=k, seed_from_schema=False)
result = await kllm.anormalize(values, context_field="manufacturer")

# Z SICI — schema-seeded init
kllm = KLLMeansClustering(num_clusters=k, seed_from_schema=True)
result = await kllm.anormalize(values, context_field="manufacturer",
    field_metadata={"description": "...", "examples": ["Hewlett-Packard", "Dell", ...]})
```

**Kluczowa obserwacja:** normalizacja działa per pole. `manufacturer` normalizujesz osobno od `color`. K (liczba klastrów) to liczba unikalnych kanonicznych form **tego jednego pola**, nie wszystkich pól razem.

## 2. Co chcemy udowodnić (claims)

| # | Claim | Eksperyment |
|---|-------|-------------|
| C1 | SICI-D daje lepszy NMI niż k-means++ na realnym IE normalization | Exp 2 |
| C2 | Przewaga SICI bierze się z jakości opisu, nie z byle jakiego tekstu | Exp 2 (label_name, random_text baselines) |
| C3 | Lepszy opis schematu → lepszy NMI (monotoniczna zależność) | Exp 3 |
| C4 | Zły opis może zaszkodzić, ale SICI-D degraduje gracefully | Exp 3 (misleading level) |
| C5 | Feedback loop (normalizacja → enrichment → lepsza normalizacja) działa | Exp 1 |
| C6 | SICI przyspiesza zbieżność (mniej iteracji do dobrego wyniku) | Exp 5 |
| C7 | Gdy metadata jest dostępne, SICI-D matches or improves k-LLMmeans na standardowych benchmarkach | Exp 4 (supplementary) |

## 3. Datasety

### 3a. Text clustering benchmarks (supplementary — porównywalność z k-LLMmeans paper)

Podzbiór datasetów z Diaz-Rodriguez 2026 — umożliwia porównanie z published results.
Rola: supplementary material, nie główne wyniki. SICI jest zaprojektowane dla IE normalization (gdzie schema metadata jest naturalnie dostępne), nie dla ogólnego text clustering.

| Dataset | Domena | K | N | Źródło |
|---------|--------|---|------|--------|
| Bank77 | Intencje bankowe | 77 | 3,080 | Casanueva et al. 2020 |
| CLINC | Intencje dialogowe | 150 | 4,500 | Larson et al. 2019 |

**Uwaga o fairness:** Na benchmarkach clustering SICI korzysta z dodatkowej informacji (domain metadata), której k-means++ nie ma. To odzwierciedla realny scenariusz IE pipeline (gdzie SchemaOptimizer generuje metadata), ale nie jest bezpośrednio porównywalne z "blind" clusteringiem. Claim musi to jasno komunikować.

**Uwaga o seed padding:** Przy dużym K (77-150) `_schema_seeded_init` ma mniej seedów niż centroidów — reszta jest padowana k-means++. Efekt SICI jest proporcjonalnie słabszy niż przy małym K (WDC-PAVE, 15-70).

### 3b. IE normalization (WDC-PAVE) — główny dataset

Tu task = "znormalizuj surowe extracted values do canonical forms" — dokładnie to co robi catchfly.

**WAŻNE:** Normalizacja w prawdziwym pipeline działa **per atrybut**. Nie mieszamy Brand z Color. Dlatego WDC-PAVE powinno być ewaluowane per atrybut:

| Atrybut | K (canonical forms) | N (raw values) | Przykład normalizacji |
|---------|--------------------|----|----------------------|
| Brand | ~30 | ~300 | "HP" → "Hewlett-Packard" |
| Manufacturer | ~25 | ~400 | "HP" → "Hewlett-Packard" |
| Product Type | ~50 | ~700 | "Wedding band" → "Rings/Bands" |
| Color(s) | ~15 | ~150 | "Black/Chrome" → "Black" |
| Material | ~70 | ~250 | "plastic" → "Rubber" |

Ewaluujemy każdy atrybut osobno (jak w prawdziwym pipeline), raportujemy per-attribute NMI + macro-average.

**To zmniejsza K z 511 do max ~70** i jest metodologicznie poprawne.

## 4. Eksperymenty — szczegóły

### Exp 2: SICI vs Baselines na IE Normalization (§5.2) — C1, C2

**RQ:** Czy SICI pomaga na realnej normalizacji per-attribute?

**Setup:**
- 6 strategii × 5 atrybutów WDC-PAVE × 30 seedów = 900 runów
- Ale K per atrybut to 15-70, nie 511
- Metryki: NMI, normalization accuracy (% poprawnie zmapowanych)

**Output:** Table 4 — per-attribute NMI + macro-average

### Exp 3: Schema Quality Ablation (§5.3) — C3, C4

**RQ:** Jak jakość opisu wpływa na SICI-D?

**Setup:**
- 9 levels × 30 seedów na WDC-PAVE (per-attribute, np. Product Type K~50)
- Albo na Bank77 (K=77) dla porównywalności z clustering benchmarks
- SICI-D z każdym level metadata

**Dataset:** WDC-PAVE, Product Type (K~50) — realistyczny IE scenario, PARSE optimizer ma sens. Bank77 odpada (brak dokumentów dla PARSE, nie jest głównym benchmarkiem).

**Output:** Figure 1 — NMI vs schema quality level, z k-means++ baseline jako dashed line

### Exp 1: Feedback Loop (§5.1) — C5

**RQ:** Czy schema ↔ normalization feedback loop poprawia wynik z każdą iteracją?

**Setup:**
- 3 iteracje pętli na WDC-PAVE (per-attribute)
- Każda iteracja: normalize → enrich schema → normalize again
- Mierzymy NMI per atrybut per iteracja

**Output:** Table 1 — NMI per attribute per iteration, showing improvement

### Exp 5: Convergence (§5.5) — C6

**RQ:** Czy SICI startuje wyżej i szybciej zbiega?

**Setup:**
- 2 strategie (kmeanspp vs sici_decomposed) × Bank77 × 10 seedów
- Trackuj NMI at iteration 1, 5, 10, 20, 40, 60, 80, 100, 120
- NIE 120 osobnych runów — wystarczy 9 checkpointów

**Output:** Figure 2 — convergence curves, SICI startuje wyżej

### Exp 4: Text Clustering Benchmarks (Appendix) — C7

**RQ:** Gdy domain metadata jest dostępne, czy SICI-D matches or improves k-LLMmeans?

**Rola:** Supplementary material. Porównywalność z Diaz-Rodriguez 2026, nie główny dowód na użyteczność SICI.

**Setup:**
- 3 strategie × 2 datasety (Bank77, CLINC) × 10 seedów = 60 runów
- 120 iteracji, summarize co 20 (matching k-LLMmeans paper)
- Metryki: NMI (primary), ACC, ARI

**Strategie:**
| # | Nazwa | Init | LLM summaries | Rola |
|---|-------|------|---------------|------|
| 1 | kmeanspp | k-means++ | TAK | **Baseline** (oryginalny k-LLMmeans) |
| 2 | sici_decomposed | embed schema metadata | TAK | **Nasza metoda** |
| 3 | oracle | embed true labels | TAK | Górna granica |

**Output:** Table w appendixie — porównanie z k-LLMmeans Table 1. Raportować % centroidów seeded vs padded k-means++.

**Caveat do paperu:** SICI korzysta z domain metadata niedostępnego dla kmeanspp. To odzwierciedla IE pipeline (SchemaOptimizer generuje metadata), ale reviewer musi to widzieć.

---

## 5. Korekta loadera WDC-PAVE

Obecny loader łączy wszystkie atrybuty w jedną listę → K=511. To błąd. Prawidłowo:

```python
# Per-attribute normalization (jak robi catchfly)
for attr in ["Brand", "Manufacturer", "Product Type", "Color(s)", "Material"]:
    ds = load_wdc_pave(attribute=attr)  # K=15-70, N=150-700
    result = await kllm.anormalize(ds.texts, context_field=attr, field_metadata=...)
```

Loader powinien dawać osobny BenchmarkDataset per atrybut.

## 6. Szacunek kosztów (per-attribute K)

Z K=15-70 per atrybut (zamiast K=511):

| Exp | Runów | Avg K | Calls/run | Total calls | ~Koszt (gpt-5.4-mini) |
|-----|-------|-------|-----------|-------------|----------------------|
| Exp 2 | 900 | ~38 | ~266 | ~240k | ~$144 |
| Exp 3 | 270 | ~50 | ~350 | ~95k | ~$57 |
| Exp 1 | 15 | ~38 | ~266 | ~4k | ~$2 |
| Exp 5 | 180 | 77 | ~539 | ~10k | ~$6 |
| Exp 4 | 60 | ~114 | ~798 | ~48k | ~$29 |
| **TOTAL** | | | | **~397k** | **~$238** |

Z gpt-4o-mini: **~$42 total**.

## 7. Priorytet wykonania

1. **Exp 2** (IE baselines) — główny dowód: SICI na realnym normalization task, idealnie aligned z pipeline
2. **Exp 3** (schema quality) — analiza kiedy SICI pomaga/szkodzi, kluczowa ablacja
3. **Exp 1** (feedback loop) — centralna teza paperu, tani do uruchomienia
4. **Exp 5** (convergence) — dodatkowy argument, ładny wykres
5. **Exp 4** (clustering, supplementary) — porównywalność z literaturą, appendix
