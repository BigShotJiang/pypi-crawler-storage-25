# Strategia trenowania i serwowania malych modeli dla biblioteki Catchfly

**Autor:** Analiza techniczna dla Silene Systems
**Data:** 2026-03-25
**Wersja biblioteki:** catchfly v1.0.x

---

## Streszczenie

Catchfly jest biblioteka Python do automatycznej ekstrakcji danych strukturalnych z dokumentow tekstowych. Aktualnie opiera sie na wywolaniach API duzych modeli jezykowych (LLM) na czterech etapach pipeline'u: odkrywanie schematu (schema discovery), ekstrakcja strukturalna, normalizacja wartosci i selekcja pol. Niniejszy raport analizuje mozliwosci zastapienia tych wywolan malymi, wyspecjalizowanymi modelami (< 1B parametrow) w celu redukcji kosztow, opoznien i zaleznosci od zewnetrznych API.

---

## 1. Gdzie male modele moga zastapic wywolania LLM

### 1.1 Odkrywanie schematu (Schema Discovery)

**Obecna implementacja:** `SinglePassDiscovery` i `ThreeStageDiscovery` wysylaja probki dokumentow do LLM z prosba o zaproponowanie JSON Schema. LLM analizuje tresc dokumentow i generuje strukture z polami, typami i opisami.

**Ocena mozliwosci zastapienia malym modelem:** NISKA

To zadanie wymaga zdolnosci do rozumowania na wysokim poziomie abstrakcji -- model musi zrozumiec domene dokumentow, zidentyfikowac powtarzajace sie wzorce i zaproponowac sensowna hierarchie pol. Jest to zadanie o charakterze generatywnym i otwartym, w ktorym male modele (< 1B) osiagaja wyraznie gorsze wyniki niz LLM.

**Rekomendacja:** Pozostawic LLM jako glowna strategie. Mozliwe usprawnienia:
- Uzyc malego modelu NER (GLiNER) do wstepnej identyfikacji typow encji w dokumentach, a nastepnie przekazac te informacje jako `suggested_fields` do LLM -- redukcja kosztow prompta i poprawa jakosci schematu.
- Zbuforowac odkryte schematy per-domena i uzyc klasyfikatora domenowego (SetFit) do automatycznego dopasowywania schematu z cache'u.

**Architektura wspomagajaca:** GLiNER-biomed-small (50M parametrow) + SetFit z ModernBERT-embed-base (~149M).

### 1.2 Ekstrakcja strukturalna (Structured Extraction)

**Obecna implementacja:** `LLMDirectExtraction` wysyla kazdy chunk dokumentu razem z JSON Schema do LLM, ktory zwraca JSON z wyekstrahowanymi danymi. Obslugujesz kaskade strategii structured output (tool calling -> json_schema -> json_object -> prompt-only).

**Ocena mozliwosci zastapienia malym modelem:** SREDNIA do WYSOKIEJ (po fine-tuningu)

Ekstrakcja strukturalna jest najkosztowniejszym etapem pipeline'u -- kazdy dokument (a czesto kazdy chunk) wymaga osobnego wywolania LLM. To jednoczesnie etap, w ktorym male modele moga dac najwyzszy zwrot z inwestycji.

**Proponowana architektura:**

| Model | Parametry | Przypadek uzycia |
|-------|-----------|-----------------|
| **Qwen2.5-0.5B-Instruct** | 0.5B | Proste schematy (< 10 pol), krotkie dokumenty |
| **Qwen2.5-1.5B-Instruct** | 1.5B | Sredniej zlozonosci schematy, dluzsze dokumenty |
| **Qwen2.5-3B-Instruct** | 3B | Zlozone schematy biomedyczne, pelne case reports |
| **GLiNER-biomed-small** | 50M | Szybki NER jako pre-filter przed ekstrakcja |

**Dane treningowe:**
- Distylacja z biezacych wynikow pipeline'u: zbieraj pary (dokument, JSON) z produkcyjnych uruchomien catchfly z duzym LLM
- Wymagane minimum: ~1000 par (dokument, ekstrakcja) per domena
- Augmentacja: "Distilling Step-by-Step" -- zbieraj nie tylko etykiety, ale tez rationale (uzasadnienia) z LLM, aby trenowac model w trybie multi-task

**Oczekiwana jakosc vs LLM:**
- Po fine-tuningu QLoRA: 80-90% jakosci duzego LLM (na podstawie badan nad Llama-3.1 8B w ekstrakcji klinicznej, gdzie osiagnieto 90% exact match)
- Qwen2.5-3B po fine-tuningu moze byc wystarczajacy dla wiekszosci schematow biomedycznych
- Qwen2.5-0.5B -- odpowiedni dla prostych, powtarzalnych schematow (np. produkty, adresy)

### 1.3 Normalizacja wartosci (Value Normalization)

**Obecna implementacja:**
- `LLMCanonicalization` -- LLM grupuje synonimy i nadaje nazwy kanoniczne (map-reduce dla duzych zbiorow)
- `KLLMeansClustering` -- k-means w przestrzeni embeddingowej + LLM nadaje nazwy klastrom
- `EmbeddingClustering` -- HDBSCAN/aglomeratywne klastrowanie embeddingow (bez LLM)
- `CascadeNormalization` -- kaskada: slownik -> LLM -> ontologia

**Ocena mozliwosci zastapienia malym modelem:** WYSOKA

Normalizacja wartosci jest doskonalym kandydatem do malych modeli, poniewaz:
1. Zadanie jest dobrze zdefiniowane (mapowanie variant -> canonical)
2. Istnieja gotowe dane treningowe (UMLS, SNOMED CT, HPO)
3. Male modele kontrastywne (SapBERT) juz osiagaja SOTA w tej domenie
4. Wnioskowanie jest bardzo szybkie (single forward pass encodera)

**Proponowana architektura:**

| Komponent | Model bazowy | Podejscie |
|-----------|-------------|-----------|
| **Encoder embeddingowy** | SapBERT / Clinical ModernBERT | Contrastive learning na synonimach UMLS |
| **Klasyfikator "czy normalizowac"** | SetFit + ModernBERT-embed | Few-shot fine-tuning na danych z pipeline'u |
| **Generator nazw kanonicznych** | Qwen2.5-0.5B | Fine-tuning na parach (klaster, nazwa kanoniczna) |

**Dane treningowe:**
- UMLS Metathesaurus: ~4M konceptow z synonimami w wielu jezykach
- HPO (Human Phenotype Ontology): ~18k terminow fenotypowych z synonimami
- SNOMED CT: ~350k konceptow klinicznych
- Wlasne dane: zbieraj wyniki normalizacji z produkcyjnych uruchomien catchfly

**Oczekiwana jakosc:**
- SapBERT na UMLS osiaga Accuracy@1 = 0.718 (BioNNE-L 2025) -- porownywalne z LLM przy 100x nizszym koszcie
- Po fine-tuningu na danych domenowych: mozliwe 85-95% zgodnosciach z wynikami LLM
- Hybrid SapBERT + re-ranking (cosine + Jaccard + Levenshtein) daje najlepsze wyniki

### 1.4 Selekcja pol (Field Selection)

**Obecna implementacja:**
- `LLMFieldSelector` -- LLM analizuje schemat i probki wartosci, decyduje ktore pola warto normalizowac
- `StatisticalFieldSelector` -- heurystyki (cardinality ratio, srednia dlugosc, wzorce nazw)

**Ocena mozliwosci zastapienia malym modelem:** BARDZO WYSOKA

Selekcja pol jest zadaniem klasyfikacji binarnej (normalizowac/nie normalizowac) na poziomie pola. To idealny przypadek uzycia dla SetFit.

**Proponowana architektura:**
- **SetFit + ModernBERT-embed-base** (~149M parametrow)
- Wejscie: reprezentacja pola = nazwa pola + typ + opis + probka wartosci (skonkatenowane)
- Wyjscie: binarne (0/1 -- czy normalizowac)

**Dane treningowe:**
- Zbieraj decyzje `LLMFieldSelector` z produkcyjnych uruchomien
- Wymagane minimum: 8-16 przykladow per klasa (SetFit jest efektywny juz przy 8 przykladach)
- Koszt treningu: ~30 sekund na GPU, ~$0.025

**Oczekiwana jakosc:**
- SetFit z ModernBERT osiaga do 50% poprawy vs baseline w few-shot scenariuszach
- Przy 20+ przykladach: oczekiwana zgodnosc > 95% z decyzjami LLM
- Czas wnioskowania: < 10ms vs ~500ms dla wywolania API

---

## 2. Strategie trenowania

### 2.1 Distylacja z LLM (Knowledge Distillation)

**Metoda:** Uzyj duzego LLM (GPT-4o, Claude) jako "nauczyciela" do generowania danych treningowych dla malego modelu "ucznia".

**Podejscie "Distilling Step-by-Step":**
1. Uruchom pipeline catchfly z duzym LLM na zbiorze dokumentow
2. Zbieraj nie tylko wyniki, ale tez rationale -- uzasadnienia decyzji LLM
3. Trenuj maly model w trybie multi-task: (a) przewiduj wynik, (b) generuj uzasadnienie
4. Model T5-770M wytrenowany ta metoda pokonuje 540B PaLM przy uzyciu zaledwie 80% danych

**Implementacja w catchfly:**
```
# Pseudokod zbierania danych treningowych
pipeline = Pipeline.quick(model="gpt-4o")
result = pipeline.run(documents, domain_hint="rare disease case reports")

# Zapis par treningowych z rationale
for doc, record in zip(documents, result.records):
    training_store.save({
        "input": doc.content,
        "schema": result.schema.json_schema,
        "output": record.model_dump(),
        "rationale": record._extraction_rationale  # nowe pole
    })
```

**Zalety:**
- Nie wymaga recznie etykietowanych danych
- Mozna uzyc istniejacych wynikow pipeline'u
- "Step-by-step" daje znacznie lepsza efektywnosc danych niz tradycyjna distylacja

**Wady:**
- Jakosc ograniczona jakoscia nauczyciela
- Ryzyko propagacji bledow LLM do malego modelu

### 2.2 SetFit -- Few-shot fine-tuning

**Metoda:** Kontrastywne fine-tunowanie sentence-transformera na malej liczbie przykladow, nastepnie trening glowicy klasyfikacyjnej na wygenerowanych embeddingach.

**Zastosowanie w catchfly:**
- Selekcja pol (LLMFieldSelector -> SetFit)
- Klasyfikacja domenowa dokumentow
- Decyzja "czy wartosc wymaga normalizacji"

**Najnowsze wyniki (2025-2026):**
- SetFit z ModernBERT-embed-base: 92.7% na IMDB przy 8 przykladach per klasa (vs 62.5% baseline)
- Trening: 30 sekund na V100, koszt $0.025
- 1600x mniejszy niz GPT-3, porownywalna jakosc

**Implementacja:**
```python
from setfit import SetFitModel, SetFitTrainer

model = SetFitModel.from_pretrained("lightonai/modernbert-embed-base")
trainer = SetFitTrainer(
    model=model,
    train_dataset=field_selection_data,  # 8-16 przykladow
    num_iterations=20,
)
trainer.train()
```

### 2.3 LoRA/QLoRA -- Parameter-efficient fine-tuning

**Metoda:** Zamrazasz wagi bazowego modelu, trenujesz tylko male macierze adaptacyjne (rank 4-64). QLoRA dodaje 4-bitowa kwantyzacje, umozliwiajac trening 7B modelu na 24GB GPU.

**Zastosowanie w catchfly:**
- Fine-tuning Qwen2.5-0.5B/1.5B/3B na ekstrakcji strukturalnej
- Fine-tuning na generowaniu nazw kanonicznych (normalizacja)

**Kluczowe parametry (2025-2026):**
- QLoRA osiaga 80-90% jakosci pelnego fine-tuningu
- Trening Qwen2.5-3B z QLoRA: ~4GB VRAM, ~2h na single GPU
- Narzedzia: LLaMA-Factory, Unsloth, trl (HuggingFace)
- Wazne: learning rate matters -- vanilla LoRA z dobrze dobranym lr moze byc rownowazny z zaawansowanymi wariantami

### 2.4 Fine-tuning Sentence-BERT / ModernBERT na embeddingach domenowych

**Metoda:** Kontrastywne uczenie encodera embeddingowego na parach synonimow z domeny biomedycznej.

**Zastosowanie w catchfly:**
- Poprawa jakosci `EmbeddingClustering` i `KLLMeansClustering`
- Domain-specific embeddings dla normalizacji

**Podejscie SimCSE/TSDAE:**
1. Nienadzorowane: augmentacja dropout jako pozytywne pary
2. Nadzorowane: pary synonimow z UMLS/HPO jako pozytywne pary
3. Hard negatives: podobne ale rozne koncepty jako negatywne pary

**Wyniki:**
- FinTextSim (2026): domain-specific sentence-transformer znaczaco poprawia koherentnosc tematyczna vs modele ogolne
- Fine-tuned SimCSE: konkurencyjna dokladnosc przy 10x nizszym koszcie obliczeniowym

### 2.5 Contrastive Learning -- SapBERT i warianty

**Metoda:** Trening encodera biomedycznego na synonimach z UMLS. Kazdy CUI (Concept Unique Identifier) definiuje grupe synonimow -- model uczy sie mapowac je blisko siebie w przestrzeni embeddingowej.

**Zastosowanie w catchfly:**
- Zastapienie `LLMCanonicalization` w domenie biomedycznej
- Wzbogacenie `EmbeddingClustering` o domenowy encoder

**Najnowsze warianty (2025-2026):**
- **SapBERT** -- oryginalny model na PubMedBERT + UMLS synonymy
- **SapXLMR** -- wielojezyczny wariant na XLM-RoBERTa (5 jezykow)
- **Clinical ModernBERT** -- nowy encoder z 8192 tokenow kontekstu, 2-4x szybszy od poprzednich modeli encoderowych
- **BioSyn** -- fine-tuned z generative relevance feedback, przewyzsza SapBERT

**Dane treningowe:**
- UMLS 2024AB: ~4.4M konceptow, ~16.5M nazw
- HPO: 18,000+ terminow fenotypowych
- SNOMED CT: 350,000+ konceptow
- DrugBank: 15,000+ lekow z synonimami

### 2.6 Active Learning -- iteracyjne trenowanie z pipeline'u

**Metoda:** Catchfly zbiera dane z kazdego uruchomienia pipeline'u. Uzytkownik waliduje wyniki (np. w notebooku), a poprawione dane sa dodawane do zbioru treningowego.

**Cykl active learning w catchfly:**
1. **Uruchomienie:** pipeline z LLM przetwarza dokumenty
2. **Zbieranie:** wyniki ekstrakcji i normalizacji sa zapisywane automatycznie
3. **Walidacja:** uzytkownik przeglaada i koryguje wyniki (Jupyter, CLI)
4. **Selekcja:** model wybiera najinformacyjniejsze przyklady (uncertainty sampling)
5. **Trening:** maly model jest re-trenowany na powieksaonym zbiorze
6. **Ewaluacja:** porownanie z LLM baseline na hold-out set

**Narzedzia (2025-2026):**
- **modAL** -- lekki framework active learning na scikit-learn
- **Cleanlab** -- automatyczne wykrywanie zaszumionych etykiet
- **Prodigy** -- human-in-the-loop dla NLP z szybkim feedbackiem
- **Label Studio** -- open-source platforma anotacyjna z integracja HuggingFace

---

## 3. Architektura serwowania modeli

### 3.1 Lokalne wnioskowanie (Local Inference)

**Rekomendowane frameworki:**

| Framework | Typ modelu | Zalety | Wady |
|-----------|-----------|--------|------|
| **ONNX Runtime** | Encodery (BERT, ModernBERT) | Najszybsze CPU inference, cross-platform | Wymaga konwersji modelu |
| **llama.cpp** | Generatywne (Qwen, Phi) | Minimalne zaleznosci, dziala wszedzie | Tylko GGUF format |
| **vLLM** | Generatywne (produkcja) | Najwyzszy throughput, PagedAttention | Wymaga GPU CUDA |
| **Transformers** | Wszystkie | Uniwersalny, latwa integracja | Wolniejszy niz wyspecjalizowane |

**Rekomendacja dla catchfly:**

Faza 1 (MVP):
- **ONNX Runtime** dla modeli encoderowych (SetFit, SapBERT, GLiNER)
- **llama.cpp przez llama-cpp-python** dla malych modeli generatywnych (Qwen2.5-0.5B/1.5B)

Faza 2 (produkcja):
- Opcjonalna integracja z **vLLM** dla scenariuszy serwerowych
- Opcjonalna integracja z **Ollama** jako user-friendly wrapper

### 3.2 Tryb hybrydowy (Small Model + LLM Fallback)

**Architektura:**
```
Dokument --> Maly model (lokalne wnioskowanie)
                |
                +--> confidence >= prog --> Wynik akceptowany
                |
                +--> confidence < prog  --> LLM API fallback --> Wynik
                                                |
                                                +--> Zapis do zbioru treningowego
```

**Implementacja w catchfly:**
Rozszerzenie klasy `CascadeNormalization` o mechanizm confidence-based routing:

```python
class HybridExtraction(ExtractionStrategy):
    """Maly model first, LLM fallback dla niskiej pewnosci."""

    def __init__(self, local_model, llm_fallback, confidence_threshold=0.7):
        self.local_model = local_model
        self.llm_fallback = llm_fallback
        self.threshold = confidence_threshold

    async def aextract(self, schema, documents):
        results = []
        for doc in documents:
            local_result = await self.local_model.aextract(schema, [doc])
            if local_result.confidence >= self.threshold:
                results.append(local_result)
            else:
                llm_result = await self.llm_fallback.aextract(schema, [doc])
                results.append(llm_result)
                # Zapis do active learning store
                self._store_for_training(doc, llm_result)
        return results
```

**Oczekiwane oszczednosci:**
- 60-80% redukcja wywolan API (wiekszossc dokumentow przetworzona lokalnie)
- < 5% spadek jakosci (trudne przypadki nadal trafiaja do LLM)
- Automatyczne zbieranie danych treningowych z fallbackow

### 3.3 Rejestr modeli (Model Registry)

**Architektura:**
```
catchfly/
  models/
    registry.py          # ModelRegistry -- ladowanie i cache modeli
    local_store.py       # Lokalne przechowywanie modeli (~/.catchfly/models/)
    hub_integration.py   # Integracja z HuggingFace Hub
```

**Konwencja nazewnictwa modeli na HuggingFace Hub:**
```
silene-systems/catchfly-extraction-rare-disease-qwen0.5b
silene-systems/catchfly-normalization-phenotypes-sapbert
silene-systems/catchfly-field-selector-biomedical-setfit
```

**Lokalne przechowywanie:**
```
~/.catchfly/models/
  extraction/
    rare-disease-qwen0.5b/
      model.gguf          # Skwantyzowany model
      config.json         # Konfiguracja
      metadata.json       # Metryki, wersja, schemat
  normalization/
    phenotypes-sapbert/
      model.onnx          # ONNX encoder
      tokenizer/
  field-selection/
    biomedical-setfit/
      model.safetensors
```

---

## 4. Konkretne propozycje modeli

### Propozycja 1: Biomedyczny NER pre-filter (GLiNER-biomed)

| Parametr | Wartosc |
|----------|---------|
| **Zadanie** | Wstepna identyfikacja encji biomedycznych w dokumentach |
| **Model bazowy** | GLiNER-biomed-small (50M parametrow) |
| **Podejscie treningowe** | Zero-shot (gotowy model) + opcjonalny few-shot fine-tuning |
| **Dane treningowe** | Gotowe: trenowany na distylacji z LLM na danych biomedycznych |
| **Predkosc wnioskowania** | ~5ms/dokument (CPU) vs ~500ms (API LLM) -- **100x szybciej** |
| **Punkt integracji** | Pre-filter przed `SinglePassDiscovery` i `LLMDirectExtraction` |
| **Oczekiwany wplyw** | Poprawa F1 schematu o 5-10% dzieki `suggested_fields` z NER |

### Propozycja 2: Ekstrakcja strukturalna (Qwen2.5-1.5B + QLoRA)

| Parametr | Wartosc |
|----------|---------|
| **Zadanie** | Ekstrakcja pol z dokumentow wg JSON Schema |
| **Model bazowy** | Qwen2.5-1.5B-Instruct |
| **Podejscie treningowe** | QLoRA fine-tuning na wynikach distylacji z GPT-4o/Claude |
| **Dane treningowe** | 1000-5000 par (dokument, JSON) z produkcyjnych uruchomien |
| **Predkosc wnioskowania** | ~50ms/chunk (GPU) lub ~200ms/chunk (CPU) vs ~800ms (API) -- **4-16x szybciej** |
| **Punkt integracji** | Nowa klasa `LocalModelExtraction` implementujaca `ExtractionStrategy` |
| **Oczekiwany wplyw** | 70-90% redukcja kosztow ekstrakcji, 80-90% jakosci LLM |

### Propozycja 3: Normalizacja biomedyczna (SapBERT + re-ranking)

| Parametr | Wartosc |
|----------|---------|
| **Zadanie** | Normalizacja nazw chorob, fenotypow, lekow do terminow kanonicznych |
| **Model bazowy** | SapBERT (PubMedBERT + contrastive learning na UMLS) |
| **Podejscie treningowe** | Contrastive learning na synonimach UMLS + domain-specific fine-tuning |
| **Dane treningowe** | UMLS Metathesaurus (4.4M konceptow), HPO (18k terminow) |
| **Predkosc wnioskowania** | ~2ms/wartosc (GPU), ~10ms/wartosc (CPU) vs ~300ms (API) -- **30-150x szybciej** |
| **Punkt integracji** | Nowa klasa `SapBERTNormalization` implementujaca `NormalizationStrategy` |
| **Oczekiwany wplyw** | 95%+ redukcja kosztow normalizacji, Accuracy@1 ~72% (porownywalne z LLM) |

### Propozycja 4: Selekcja pol (SetFit + ModernBERT)

| Parametr | Wartosc |
|----------|---------|
| **Zadanie** | Klasyfikacja pol schematu: czy normalizowac? |
| **Model bazowy** | ModernBERT-embed-base (~149M) z SetFit |
| **Podejscie treningowe** | Few-shot contrastive fine-tuning (8-16 przykladow) |
| **Dane treningowe** | Decyzje LLMFieldSelector z dotychczasowych uruchomien |
| **Predkosc wnioskowania** | ~5ms (CPU) vs ~400ms (API) -- **80x szybciej** |
| **Punkt integracji** | Nowa klasa `SetFitFieldSelector` implementujaca `FieldSelector` |
| **Oczekiwany wplyw** | 100% eliminacja wywolan API na etapie selekcji, >95% zgodnosc z LLM |

### Propozycja 5: Domenowe embeddingi (Clinical ModernBERT)

| Parametr | Wartosc |
|----------|---------|
| **Zadanie** | Embeddingi kliniczne do normalizacji i klastrowania |
| **Model bazowy** | Clinical ModernBERT (~150M, kontekst 8192 tokenow) |
| **Podejscie treningowe** | Contrastive fine-tuning (SimCSE) na parach synonimow biomedycznych |
| **Dane treningowe** | UMLS synonym pairs + wlasne dane z pipeline'u |
| **Predkosc wnioskowania** | ~3ms/tekst (GPU) vs ~100ms (API embedding) -- **30x szybciej** |
| **Punkt integracji** | Zastapienie `OpenAIEmbeddingClient` w `EmbeddingClustering` i `KLLMeansClustering` |
| **Oczekiwany wplyw** | Eliminacja kosztow API embeddingow, lepsza jakosc klastrow biomedycznych |

### Propozycja 6: Generator nazw kanonicznych (Qwen2.5-0.5B)

| Parametr | Wartosc |
|----------|---------|
| **Zadanie** | Generowanie nazw kanonicznych dla klastrow wartosci |
| **Model bazowy** | Qwen2.5-0.5B-Instruct |
| **Podejscie treningowe** | QLoRA fine-tuning na parach (lista wariantow, nazwa kanoniczna) |
| **Dane treningowe** | Wyniki `LLMCanonicalization` i `KLLMeansClustering` z produkcji |
| **Predkosc wnioskowania** | ~20ms/klaster (GPU) vs ~300ms (API) -- **15x szybciej** |
| **Punkt integracji** | Zastapienie wywolan LLM w `KLLMeansClustering._generate_canonical_names()` |
| **Oczekiwany wplyw** | 90%+ redukcja kosztow w etapie nadawania nazw klastrom |

---

## 5. Projekt pipeline'u treningowego

### 5.1 Komenda CLI: `catchfly train`

```bash
# Trenuj model ekstrakcji na zebranych danych
catchfly train extraction \
  --base-model qwen2.5-1.5b \
  --training-data ./training_data/extraction/ \
  --output-dir ./models/extraction-rare-disease/ \
  --method qlora \
  --epochs 3

# Trenuj model normalizacji na UMLS
catchfly train normalization \
  --base-model sapbert \
  --ontology umls \
  --domain phenotypes \
  --output-dir ./models/normalization-phenotypes/

# Trenuj selektor pol
catchfly train field-selector \
  --base-model modernbert-embed-base \
  --training-data ./training_data/field_selection/ \
  --output-dir ./models/field-selector-biomedical/
  --method setfit

# Eksport do ONNX
catchfly export --model ./models/normalization-phenotypes/ --format onnx

# Publikacja na HuggingFace Hub
catchfly push --model ./models/extraction-rare-disease/ \
  --hub-id silene-systems/catchfly-extraction-rare-disease
```

### 5.2 API Pythonowe

```python
from catchfly.training import TrainingPipeline
from catchfly.training.collectors import PipelineDataCollector

# 1. Zbieranie danych treningowych z pipeline'u
collector = PipelineDataCollector(
    output_dir="./training_data/",
    collect_extraction=True,
    collect_normalization=True,
    collect_field_selection=True,
    collect_rationales=True,  # Distilling Step-by-Step
)

pipeline = Pipeline.quick(model="gpt-4o")
pipeline.add_collector(collector)  # hook do zbierania danych
result = pipeline.run(documents)

# 2. Trening modelu
trainer = TrainingPipeline(
    task="extraction",
    base_model="Qwen/Qwen2.5-1.5B-Instruct",
    method="qlora",
    training_data="./training_data/extraction/",
)
trainer.train(epochs=3, output_dir="./models/")

# 3. Uzycie wytrenowanego modelu
from catchfly.extraction.local_model import LocalModelExtraction

pipeline = Pipeline(
    extraction=LocalModelExtraction(
        model_path="./models/extraction-rare-disease/",
        fallback=LLMDirectExtraction(model="gpt-4o"),  # LLM fallback
        confidence_threshold=0.7,
    ),
    normalization=SapBERTNormalization(
        model_path="./models/normalization-phenotypes/",
    ),
    field_selector=SetFitFieldSelector(
        model_path="./models/field-selector-biomedical/",
    ),
)
```

### 5.3 Integracja z HuggingFace Hub

```python
from catchfly.models import ModelRegistry

# Ladowanie modelu z Hub
registry = ModelRegistry()
extraction_model = registry.load(
    "silene-systems/catchfly-extraction-rare-disease-qwen0.5b",
    cache_dir="~/.catchfly/models/",
)

# Publikacja modelu
registry.push(
    model_path="./models/extraction-rare-disease/",
    hub_id="silene-systems/catchfly-extraction-rare-disease",
    tags=["catchfly", "extraction", "rare-disease", "biomedical"],
    model_card=True,  # automatyczny model card z metrykami
)

# Wyszukiwanie modeli
models = registry.search(
    task="normalization",
    domain="biomedical",
    min_accuracy=0.85,
)
```

### 5.4 Automatyczne zbieranie danych z uruchomien pipeline'u

Catchfly powinien automatycznie zbierac dane treningowe z kazdego uruchomienia:

```python
class PipelineDataCollector:
    """Automatycznie zbiera dane treningowe z uruchomien pipeline'u."""

    def on_extraction_complete(self, document, schema, record, confidence):
        """Zapis pary (dokument, ekstrakcja) do zbioru treningowego."""
        self.store.append({
            "task": "extraction",
            "input": {"content": document.content, "schema": schema.json_schema},
            "output": record.model_dump(),
            "confidence": confidence,
            "timestamp": datetime.now().isoformat(),
            "model": self.pipeline_model,
        })

    def on_normalization_complete(self, field, values, mapping, clusters):
        """Zapis wynikow normalizacji."""
        self.store.append({
            "task": "normalization",
            "input": {"field": field, "values": values},
            "output": {"mapping": mapping, "clusters": clusters},
        })

    def on_field_selection_complete(self, schema, records, selected_fields):
        """Zapis decyzji selekcji pol."""
        self.store.append({
            "task": "field_selection",
            "input": {"schema": schema.json_schema, "sample_values": ...},
            "output": {"selected": selected_fields},
        })
```

---

## 6. Konkretny plan dzialania (Roadmap)

### Faza 1: Quick Wins (1-2 miesiace)

| # | Zadanie | Wplyw | Wykonalnosc | Priorytet |
|---|---------|-------|-------------|-----------|
| 1.1 | **SetFitFieldSelector** -- zastapienie LLMFieldSelector | Eliminacja 1 wywolania API/uruchomienie | BARDZO WYSOKA (gotowe narzedzia) | **P0** |
| 1.2 | **GLiNER-biomed pre-filter** -- wstepny NER w discovery | Poprawa jakosci schematu, redukcja retries | WYSOKA (gotowy model) | **P0** |
| 1.3 | **PipelineDataCollector** -- zbieranie danych treningowych | Fundament dla dalszych faz | WYSOKA (czysta implementacja) | **P0** |
| 1.4 | **StatisticalFieldSelector ulepszenia** -- lepsze heurystyki | Zero-cost fallback | BARDZO WYSOKA | **P1** |

**Uzasadnienie:** SetFit i GLiNER sa gotowymi modelami, ktore mozna zintegrowac bez trenowania wlasnych modeli. PipelineDataCollector jest fundamentem, bez ktorego kolejne fazy nie moga dzialac.

### Faza 2: Normalizacja (2-3 miesiace)

| # | Zadanie | Wplyw | Wykonalnosc | Priorytet |
|---|---------|-------|-------------|-----------|
| 2.1 | **SapBERTNormalization** -- nowa strategia normalizacji | 95%+ redukcja kosztow normalizacji | WYSOKA (gotowy model + UMLS) | **P0** |
| 2.2 | **Clinical ModernBERT embeddingi** -- zastapienie OpenAI embeddings | Eliminacja kosztow API embeddingow | SREDNIA (wymaga fine-tuningu) | **P1** |
| 2.3 | **Qwen2.5-0.5B canonical name generator** -- nazwy klastrow | Redukcja kosztow KLLMeansClustering | SREDNIA (wymaga fine-tuningu) | **P1** |
| 2.4 | **Tryb hybrydowy w CascadeNormalization** -- local + LLM fallback | Optymalne kosztowo/jakosciowo | WYSOKA | **P1** |

**Uzasadnienie:** Normalizacja jest stosunkowo latwa do zastapienia malymi modelami, bo SapBERT jest gotowy i osiaga dobre wyniki. Clinical ModernBERT daje lokalne embeddingi bez API.

### Faza 3: Ekstrakcja (3-6 miesiecy)

| # | Zadanie | Wplyw | Wykonalnosc | Priorytet |
|---|---------|-------|-------------|-----------|
| 3.1 | **catchfly train CLI** -- pipeline treningowy | Infrastruktura dla uzytkownikow | SREDNIA (wymaga projektowania) | **P0** |
| 3.2 | **LocalModelExtraction** -- ekstrakcja lokalnym modelem | 70-90% redukcja kosztow ekstrakcji | SREDNIA (wymaga danych) | **P0** |
| 3.3 | **Distilling Step-by-Step** -- rationale collection | Lepsza efektywnosc danych | SREDNIA | **P1** |
| 3.4 | **Active learning loop** -- iteracyjne trenowanie | Ciagla poprawa jakosci | NISKA (zlozony system) | **P2** |

**Uzasadnienie:** Ekstrakcja wymaga najwiecej danych treningowych i najstaranniejszej ewaluacji. Dlatego zalezy od Fazy 1 (PipelineDataCollector) i Fazy 2 (doswiadczenia z fine-tuningiem).

### Faza 4: Ekosystem (6-12 miesiecy)

| # | Zadanie | Wplyw | Wykonalnosc | Priorytet |
|---|---------|-------|-------------|-----------|
| 4.1 | **ModelRegistry + HuggingFace Hub** -- udostepnianie modeli | Budowanie spolecznosci | SREDNIA | **P1** |
| 4.2 | **ONNX export** -- optymalizacja inferencji encoderowej | 2-3x przyspieszenie CPU | SREDNIA | **P1** |
| 4.3 | **Benchmark suite** -- porownanie local vs API | Zaufanie uzytkownikow | WYSOKA | **P0** |
| 4.4 | **Dokumentacja + cookbooki** -- przewodniki treningowe | Adopcja | WYSOKA | **P0** |

### Podsumowanie wplywu

| Metryka | Przed | Po (Faza 1-2) | Po (Faza 3-4) |
|---------|-------|---------------|---------------|
| **Koszt API per 100 dokumentow** | ~$0.50-2.00 | ~$0.15-0.60 | ~$0.02-0.10 |
| **Latencja per dokument** | ~2-5s | ~0.5-2s | ~0.1-0.5s |
| **Zaleznosc od API** | 100% | ~40% | ~5-10% |
| **Tryb offline** | Niemozliwy | Czesciowy | Pelny (z wytrenowanymi modelami) |
| **Jakosc ekstrakcji** | 100% (LLM baseline) | ~98% | ~85-95% |

---

## Podsumowanie rekomendacji

1. **Najszybszy zwrot z inwestycji:** SetFit do selekcji pol i GLiNER-biomed do NER -- obie integracje mozliwe w ciagu 1-2 tygodni, bez trenowania wlasnych modeli.

2. **Najwiekszy wplyw kosztowy:** SapBERT do normalizacji biomedycznej i lokalne embeddingi Clinical ModernBERT -- eliminacja dwoch najczestszych wywolan API.

3. **Najtrudniejsze, ale najwazniejsze:** LocalModelExtraction z Qwen2.5 + QLoRA -- wymaga zebrania danych treningowych, ale daje najwieksza redukcje kosztow (ekstrakcja stanowi 60-80% kosztow pipeline'u).

4. **Kluczowa infrastruktura:** PipelineDataCollector musi powstac jako pierwszy -- bez niego nie ma danych do trenowania wlasnych modeli. To "fundament" calej strategii.

5. **Filozofia hybrydowa:** Catchfly nie powinien wymuszac wyboru "LLM albo maly model". Architektura CascadeNormalization juz pokazuje wlasciwy wzorzec -- local first, LLM fallback. Ten wzorzec powinien byc rozszerzony na wszystkie etapy pipeline'u.

---

## Zrodla

- [Distillation: Turning Smaller Models into High-Performance Solutions (Microsoft)](https://techcommunity.microsoft.com/blog/azure-ai-foundry-blog/distillation-turning-smaller-models-into-high-performance-cost-effective-solutio/4355029)
- [Knowledge Distillation of LLMs: Emerging Trends (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC12634706/)
- [Small Language Models: Balancing Size and Performance in 2026](https://labelyourdata.com/articles/llm-fine-tuning/small-language-models)
- [Distilling Step-by-Step! (Google Research / ACL 2023)](https://arxiv.org/abs/2305.02301)
- [SetFit: Efficient Few-Shot Learning Without Prompts (HuggingFace)](https://huggingface.co/blog/setfit)
- [SetFit ModernBERT for Text Classification](https://moshewasserblat.medium.com/new-results-on-setfit-modernbert-for-text-classification-with-few-shot-training-53c154df7c0e)
- [GLiNER-biomed: Efficient Models for Open Biomedical NER](https://arxiv.org/abs/2504.00676)
- [GLiNER-biomed-small-v1.0 (HuggingFace)](https://huggingface.co/Ihor/gliner-biomed-small-v1.0)
- [Hybrid Re-ranking for Biomedical Entity Linking using SapBERT (BioNNE-L 2025)](https://www.researchgate.net/publication/395956564_Hybrid_Re-ranking_for_Biomedical_Entity_Linking_using_SapBERT_Embeddings_A_High-Performance_System_for_BioNNE-L_2025-1)
- [Clinical ModernBERT: Efficient Long-Context Encoder for Biomedical Text](https://arxiv.org/html/2504.03964v1)
- [SapBERT-Based Medical Concept Normalization Using SNOMED CT](https://www.researchgate.net/publication/370894644_SapBERT-Based_Medical_Concept_Normalization_Using_SNOMED_CT)
- [ModernBERT: A Replacement for BERT (HuggingFace)](https://huggingface.co/blog/modernbert)
- [Fine-tune Classifier with ModernBERT in 2025](https://www.philschmid.de/fine-tune-modern-bert-in-2025)
- [FinTextSim: Domain-Specific Sentence-Transformer (2026)](https://www.frontiersin.org/journals/artificial-intelligence/articles/10.3389/frai.2026.1752103/full)
- [vLLM or llama.cpp: Choosing the Right Inference Engine (Red Hat)](https://developers.redhat.com/articles/2025/09/30/vllm-or-llamacpp-choosing-right-llm-inference-engine-your-use-case)
- [Ollama vs vLLM Performance Benchmark 2026 (SitePoint)](https://www.sitepoint.com/ollama-vs-vllm-performance-benchmark-2026/)
- [Running Local LLMs with Python 2026](https://dasroot.net/posts/2026/01/running-local-llms-python-ollama-llama-cpp-transformers/)
- [Fine-Tuning LLMs: SFT, LoRA, and QLoRA Explained (2026)](https://kaifimtz.medium.com/fine-tuning-large-language-models-sft-lora-and-qlora-explained-d97bd4c1504e)
- [Fine-Tuning LLMs with LoRA: 2025 Guide](https://amirteymoori.com/fine-tuning-llms-with-lora-a-practical-guide-for-2025/)
- [Qwen2.5-LLM Technical Report](https://arxiv.org/pdf/2412.15115)
- [Small Language Models Enable Rapid Extraction of Structured Data (PMC)](https://pmc.ncbi.nlm.nih.gov/articles/PMC12451238/)
- [Human Level Information Extraction with Fine-tuned LMs (Nature, 2025)](https://www.nature.com/articles/s41598-025-28767-z)
- [Benchmarking LLMs for Biomedical NLP (Nature Comms, 2025)](https://www.nature.com/articles/s41467-025-56989-2)
- [Active Learning: The Smart Way to Build Training Datasets for LLMs](https://medium.com/@federicomoreno613/active-learning-the-smart-way-to-build-training-datasets-for-fine-tuning-llms-9431e3de4315)
- [GLiNER GitHub Repository](https://github.com/urchade/GLiNER)
