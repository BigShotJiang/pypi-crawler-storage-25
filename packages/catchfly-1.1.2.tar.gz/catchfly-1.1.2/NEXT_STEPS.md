# Catchfly — Next Steps Plan

**Status:** v1.1.1. 396 tests. Ruff clean.
**Goal:** Dominate biomedical text extraction + normalization. Stay useful for casual use cases.
**Informed by:** 5-agent research (2026-03-25) — library critic, normalization SOTA researcher, use case specialist, NLP engineer, codebase explorer.

---

## Phase 1: Core Hardening (v1.1) ✅

> Completed 2026-03-25. Fixed architectural debt, improved DX, unblocked downstream phases.

### 1.1 — Eliminate `setattr(_usage_callback)` wiring ✅

- Replaced 4x `setattr(strategy, "_usage_callback", ...)  # noqa: B010` with `_wire_tracker()` + `_inject_callback()` using direct attribute assignment
- Zero `setattr` or `# noqa: B010` remaining in codebase

### 1.2 — Client dependency injection ✅

- Added `client: Any | None = None` + `_get_client()` to 8 LLM strategies: `SinglePassDiscovery`, `ThreeStageDiscovery`, `SchemaOptimizer`, `LLMDirectExtraction`, `LLMCanonicalization`, `LLMFieldSelector`, `OntologyMapping`, `KLLMeansClustering`
- Added `embedding_client: Any | None = None` + `_get_embedding_client()` to 3 embedding strategies: `EmbeddingClustering`, `KLLMeansClustering`, `OntologyMapping`
- Zero breaking changes — `None` default preserves existing behavior
- Test compliance suite updated to use client DI instead of monkey-patching

### 1.3 — `PipelineResult.apply_normalizations()` ✅

- `apply_normalizations()` method + `normalized_records` property
- Handles Pydantic models, dicts, list fields, None values, unmapped passthrough
- Shared `_records_to_dicts()` helper reused by `to_dataframe()`
- 10 new tests

### 1.4 — Extract `strip_markdown_fences()` utility ✅

- Created `catchfly/_parsing.py` with `strip_markdown_fences()`
- Replaced inline code in 7 files: `single_pass.py`, `three_stage.py`, `optimizer.py`, `llm_direct.py`, `llm_canonical.py`, `ontology_mapping.py`, `selection/llm.py`
- 8 new tests

### 1.5 — `DEFAULT_MODEL` constant ✅

- Created `catchfly/_defaults.py` with `DEFAULT_MODEL` + `DEFAULT_EMBEDDING_MODEL`
- Updated 13 source files to use constants instead of hardcoded strings
- Exported from `catchfly.__init__`

### 1.6 — Remove `**kwargs` sink ✅

- Removed `**kwargs: Any` from `Pipeline.run()` and `arun()` — typos now raise `TypeError`

### 1.7 — Move `_Checkpoint` to own module ✅

- Extracted `_Checkpoint` class to `catchfly/checkpoint.py` (106 lines of I/O out of orchestrator)

### 1.8 — Quality fixes ✅

- Documented magic numbers in `embedding_cluster.py` and `embeddings.py`
- Improved exception messages with actionable context (`ontology_mapping.py`)
- Fixed pre-existing bug in `schema/converters.py` (`_resolve_type` crash on non-dict property)
- Replaced `assert` with `RuntimeError` in `pipeline.py`
- Fixed `Path` import location (`TYPE_CHECKING` guard) in `pipeline.py`

**Checkpoint:** 340 tests (was 315), ruff clean, zero setattr, v1.1.0.

---

## Phase 2: Biomedical Normalization SOTA (v1.1.1) ✅

> Completed 2026-03-26. Integrated benchmark findings into the library: local biomedical embeddings, smarter cascade routing, query augmentation, self-learning caches.

### 2.1 — SapBERT biomedical embeddings ✅

SapBERT outperforms all tested alternatives on biomedical entity normalization retrieval.

> **Benchmark results (2026-03-26):** BC5CDR Disease test set (4363 mentions, 13320 CTD MEDIC ontology terms). Retrieval-only Acc@1 / Acc@5 / MRR, then with gpt-4.1-mini LLM reranking on top-5 candidates:
>
> | Model | Acc@1 | Acc@5 | MRR | +Rerank Acc@1 | +Rerank MRR | Cost |
> |-------|-------|-------|-----|--------------|-------------|------|
> | **SapBERT** | **0.787** | **0.898** | **0.835** | **0.802** | **0.845** | $0 |
> | text-embedding-3-large | 0.772 | 0.863 | 0.814 | 0.793 | 0.826 | ~$1 |
> | BioLORD-2023-C | 0.771 | 0.857 | 0.813 | 0.779 | 0.819 | $0 |
> | text-embedding-3-small | 0.768 | 0.849 | 0.804 | 0.785 | 0.814 | ~$0.15 |
> | CODER++ | 0.757 | 0.866 | 0.799 | 0.791 | 0.821 | $0 |
>
> Benchmark code: `benchmarks/` directory (branch `medbench`). Dataset: BC5CDR (BioCreative V CDR), ontology: CTD MEDIC.

- Added `SentenceTransformerEmbeddingClient` to `providers/embeddings.py`
  - Implements `EmbeddingClient` protocol (duck-typed, no inheritance)
  - Default: `cambridgeltl/SapBERT-from-PubMedBERT-fulltext` (768-dim, CLS pooling)
  - Lazy model loading, GPU auto-detect (CUDA > MPS > CPU), `asyncio.to_thread()` for async
  - In-memory cache with LRU eviction, same pattern as `OpenAIEmbeddingClient`
- Fixed `OntologyIndex` type hint: `embedding_client: Any` (was `OpenAIEmbeddingClient`)
- Safe `model` access via `getattr(..., 'model', 'unknown')` in cache methods
- Exported from `catchfly.providers`
- 20 new tests

### 2.2 — RAG-augmented normalization ✅

- Added `augment_queries: bool = False` to `OntologyMapping` (progressive disclosure)
- When enabled: LLM generates alternative phrasings per value, embeds + searches them, merges candidates
- High-confidence values skip augmentation (`augmentation_skip_threshold=0.95`)
- Batched LLM calls (`augmentation_batch_size=30`)
- Graceful fallback on LLM failure
- 5 new tests

### 2.3 — Confidence-based cascade routing ✅

- `DictionaryNormalization` now emits `per_value` confidence: matched=1.0, passthrough=0.0
- `LLMCanonicalization` now emits `per_value` confidence: identity=1.0, LLM-grouped=0.85
- `OntologyMapping` already had per_value confidence
- `CascadeNormalization.confidence_thresholds: list[float] | None` — per-step routing
- `default(use_confidence=True)` computes sensible defaults: Dictionary=1.0, LLM=0.80, Ontology=0.90
- Backward compatible: `None` preserves identity-check routing
- 9 new tests

### 2.4 — Self-learning dictionary cache ✅

- `NormalizationResult.to_dictionary(min_confidence=0.0)` — export non-identity mappings
- `CascadeNormalization.learn(result, min_confidence=0.80)` — prepend/merge dictionary step
- `LearnedDictionaryCache(path, min_confidence)` — JSON persistence, upsert with higher-confidence wins
- Cache format: versioned JSON with per-field, per-value mappings + provenance
- 18 new tests

### 2.5 — Homonym disambiguation ✅

- `OntologyIndex._disambiguate_homonyms()` — detects entries with identical names but different IDs
- Appends disambiguating context (synonyms + ontology ID) to index texts
- Lightweight: only modifies `self._texts` in-place, no extra LLM or embedding calls
- Cache version bumped 1 → 2 (old caches auto-rebuild)
- 4 new tests

**Checkpoint:** 396 tests (was 340), ruff clean, v1.1.1. Zero breaking changes.

---

## Phase 3: Small Models + Offline Mode (v1.2)

> Goal: Replace expensive LLM calls with fast local models. Enable fully offline pipelines.

### 3.1 — `SentenceTransformerEmbeddingClient` (if not done in 2.1)

Local embedding inference via sentence-transformers. Foundation for all small-model work.

### 3.2 — `SetFitFieldSelector`

SetFit (HuggingFace) achieves >95% agreement with LLM field selection, 80x faster, zero API cost.

- New `selection/setfit.py` — `SetFitFieldSelector`:
  - Config: `model_path: str | None = None` (None = use LLM to generate training data, then train)
  - `aselect()`: if no model, collect labels from `LLMFieldSelector` on first run, train SetFit, save
  - Subsequent runs: pure local inference
  - Save/load: `model_path` directory with SetFit model + label mapping
- Add `setfit` optional extra: `setfit>=1.0`

### 3.3 — `SapBERTNormalization`

Contrastive learning on UMLS synonyms. 30-150x faster than LLM, offline, ~72% Accuracy@1.

- New `normalization/sapbert.py` — `SapBERTNormalization`:
  - Config: `model_name: str = "cambridgeltl/SapBERT-from-PubMedBERT-fulltext"`, `ontology: str | OntologySource`, `top_k: int = 5`, `confidence_threshold: float = 0.85`
  - Flow: embed values + ontology terms with SapBERT → cosine similarity → top-k → threshold
  - No LLM calls — pure embedding similarity
  - Ideal as first step in cascade: SapBERT → LLM fallback
- Recommended cascade for biomedical: `Dictionary → SapBERT → LLMCanonicalization → OntologyMapping(with reranking)`

### 3.4 — `PipelineDataCollector`

Automatically collect training data from pipeline runs for future model distillation.

- `catchfly/training/collector.py` — `PipelineDataCollector`:
  - Hooks into pipeline stages via `PipelineContext`
  - Records: `(document, extracted_record)` pairs for extraction training
  - Records: `(raw_value, canonical_value, field_name)` triples for normalization training
  - Records: `(schema, field_name, is_categorical)` pairs for field selection training
  - Saves to JSONL format in configurable directory
  - `Pipeline.arun(collect_training_data="./training_data/")`

### 3.5 — `GLiNER` biomedical pre-filter for discovery

Zero-shot NER to pre-identify entity types before schema discovery.

- New `discovery/gliner_prefilter.py` — `GLiNERPrefilter`:
  - Run GLiNER-biomed on sample documents → extract entity types
  - Pass as `suggested_fields` to `SinglePassDiscovery` / `ThreeStageDiscovery`
  - Improves schema quality + reduces LLM token usage
- Add `gliner` optional extra

### 3.6 — Offline demo mode

Allow exploring catchfly API without any API key.

- `Pipeline.quick(provider="mock")` — returns deterministic mock results from bundled demo data
- Uses canned LLM responses from `demo/mock_responses/`
- Zero network calls, zero cost
- Useful for: documentation, tutorials, CI, offline development

---

## Phase 4: Biomedical Ecosystem (v1.2)

> Goal: First-class support for biomedical workflows. PubMed integration, medical ontologies, OMOP export.

### 4.1 — PubMed / PMC document loader

Direct import from PubMed — the primary data source for rare disease research.

- `catchfly/loaders/pubmed.py`:
  - `load_pubmed(query: str, max_results: int = 100) -> list[Document]` — uses NCBI E-utilities API
  - `load_pmc(pmcids: list[str]) -> list[Document]` — full-text from PMC Open Access
  - `load_pubmed_ids(pmids: list[str]) -> list[Document]` — abstracts by PMID
  - Sets `Document.id = PMID`, `Document.source = "pubmed"`, `Document.metadata = {title, authors, journal, year, doi, mesh_terms}`
- Add `pubmed` optional extra: `biopython>=1.80` or pure `httpx` (prefer no heavy deps)

### 4.2 — Additional medical ontologies

HPO is implemented. Add the other critical ontologies.

- `catchfly/ontology/orphanet.py` — `OrphanetSource`: rare disease nomenclature (ORPHA codes)
  - Loader from Orphadata XML/JSON API
- `catchfly/ontology/snomed.py` — `SNOMEDSource`: clinical terms
  - Loader from RF2 release files or FHIR terminology server
- `catchfly/ontology/meddra.py` — `MedDRASource`: adverse event terminology
  - Loader from MedDRA MSSO distribution (requires license — document this)
- `catchfly/ontology/mesh.py` — `MeSHSource`: MeSH descriptors
  - Loader from NLM XML
- All implement `OntologySource` protocol — plug directly into `OntologyMapping`

### 4.3 — Schema templates

Pre-built schemas for common biomedical extraction tasks. Lower the barrier to entry.

- `catchfly/templates/` directory:
  - `case_report.py` — `CaseReportSchema`: patient demographics, symptoms, diagnosis, treatment, outcome, genetic findings
  - `clinical_trial.py` — `ClinicalTrialSchema`: study design, population, intervention, endpoints, results
  - `adverse_event.py` — `AdverseEventSchema`: drug, event, severity, outcome, causality
  - `systematic_review.py` — `SystematicReviewSchema`: PICO elements, study design, quality scores
- Each template: Pydantic BaseModel + `field_metadata` with descriptions, examples, synonyms
- Usage: `Pipeline(schema=CaseReportSchema)` — skip discovery entirely

### 4.4 — OMOP CDM export

Critical for interoperability with clinical research infrastructure (OHDSI ecosystem).

- `PipelineResult.to_omop(output_dir: str)` — exports extracted + normalized records to OMOP-compatible CSV tables
- Maps HPO → SNOMED concept_ids where possible
- Generates: `person.csv`, `condition_occurrence.csv`, `measurement.csv`, `observation.csv`
- Pragmatic: best-effort mapping, log unmapped concepts

### 4.5 — ASReview integration

Partnership opportunity: ASReview handles screening, catchfly handles extraction.

- `catchfly/loaders/asreview.py`:
  - `load_asreview_results(asreview_file: str, label: int = 1) -> list[Document]` — load included papers from ASReview project file
  - Extracts title + abstract, optionally fetches full text via PMC
- Publish as example notebook: "From Systematic Review to Structured Dataset"

---

## Phase 5: Documentation + Adoption (ongoing)

> Goal: Lower adoption barriers. Position catchfly as THE tool for text-to-structured-data.

### 5.1 — "Concepts" documentation page

Explain the architecture and decision tree:
- What is schema discovery and why you need it
- Discovery vs extraction vs normalization — why separate stages
- SinglePass vs ThreeStage vs SchemaOptimizer — when to use which
- Normalization strategy comparison: Dictionary vs LLM vs Embedding vs Ontology vs Cascade
- Diagram: full pipeline flow with decision points

### 5.2 — "Why Catchfly" comparison page

Position vs competitors:
- catchfly vs Instructor — "Instructor extracts. Catchfly discovers, extracts, AND normalizes."
- catchfly vs LangExtract — "LangExtract requires predefined schema. Catchfly discovers it."
- catchfly vs unstructured.io — "Unstructured parses documents. Catchfly understands them."
- catchfly vs Spark NLP — "Spark NLP needs trained NER models. Catchfly uses LLMs zero-shot."
- Feature comparison table

### 5.3 — Benchmark page

Publication-ready performance evidence:
- Processing speed: X documents/minute at $Y cost
- Normalization quality: F1 on standard biomedical benchmarks (n2c2, BioNNE-L)
- Schema discovery accuracy: % of correct fields discovered vs ground truth
- Cost breakdown by pipeline stage
- Comparison: catchfly vs manual extraction time/cost

### 5.4 — CHANGELOG.md

Full version history. Currently missing despite being linked in pyproject.toml.

### 5.5 — Research paper

Case study: building rare disease patient cohorts with catchfly.
- Target: Journal of Biomedical Informatics, JAMIA, or JMIR Medical Informatics
- Dataset: 100+ PubMed case reports for a specific rare disease
- Compare: catchfly pipeline vs manual extraction (time, cost, accuracy)
- Demonstrate: schema discovery, cascade normalization with HPO, OMOP export

### 5.6 — Conference presentations

- PyCon / SciPy — developer audience, casual use cases
- OHDSI Symposium — clinical informatics, rare diseases
- AMIA Annual — medical informatics, NLP in healthcare
- BioNLP Workshop (ACL/EMNLP) — research audience

---

## Phase 6: Knowledge Graphs + Relations (v2.0)

> Goal: Move from entity extraction to relationship extraction. Enable knowledge graph construction.

### 6.1 — Relation extraction

Currently catchfly extracts entities/values per document. Add relationship extraction.

- `catchfly/extraction/relation.py` — `RelationExtractor`:
  - Input: extracted records + source documents
  - Output: list of `(subject, predicate, object)` triples with provenance
  - LLM-based: prompt with extracted entities + document context
  - Schema-guided: only extract relations between discovered field types
- `PipelineResult.relations: list[Relation]`

### 6.2 — Graph export

- `PipelineResult.to_neo4j(uri, auth)` — direct push to Neo4j via bolt driver
- `PipelineResult.to_rdf(path, format="turtle")` — RDF/Turtle export via rdflib
- `PipelineResult.to_networkx()` — in-memory graph for analysis
- Node deduplication via normalization mappings

### 6.3 — Multi-document schema discovery

SQUiD-inspired: discover relational schemas across document collections.

- Detect entity types that appear across documents → nodes
- Detect co-occurrence patterns → edges
- Propose relational schema with foreign keys
- Output: multi-table schema (not flat)

---

## Phase 7: Scale + Enterprise (v2.0)

> Goal: Handle 10K+ document pipelines. Enterprise-ready features.

### 7.1 — Streaming extraction

Yield records as they're extracted, don't wait for full batch.

- `Pipeline.astream(documents) -> AsyncIterator[ExtractedRecord]`
- Enables real-time progress for large pipelines
- Compatible with async consumers (FastAPI, etc.)

### 7.2 — Record deduplication

When documents are chunked, same entity may appear in multiple chunks.

- `PipelineResult.deduplicate(strategy="merge"|"first"|"highest_confidence")`
- Merge: combine fields from overlapping records
- First: keep first occurrence
- Highest confidence: keep record with best provenance confidence

### 7.3 — `catchfly train` CLI

Train domain-specific small models from collected pipeline data.

```bash
catchfly train field-selector --data ./training_data/ --output ./models/field_selector/
catchfly train normalizer --data ./training_data/ --ontology hpo --output ./models/normalizer/
catchfly train extractor --data ./training_data/ --base-model qwen2.5-1.5b --output ./models/extractor/
```

- Uses data collected by `PipelineDataCollector` (Phase 3.4)
- Trains SetFit (field selection), SapBERT fine-tune (normalization), QLoRA (extraction)
- Export to ONNX for fast inference
- Upload to HuggingFace Hub: `catchfly push --model ./models/normalizer/ --repo silene/catchfly-hpo-normalizer`

### 7.4 — Multi-provider native support

Replace OpenAI SDK dependency with direct HTTP calls for non-OpenAI providers.

- `catchfly/providers/anthropic.py` — native Anthropic API (tool_use, no OpenAI shim)
- `catchfly/providers/google.py` — Gemini API (structured output)
- Auto-detect from model name prefix: `claude-*` → Anthropic, `gemini-*` → Google
- Remove requirement to install `openai` SDK for non-OpenAI providers

### 7.5 — Audit trail for regulated industries

Pharmacovigilance, clinical trials require full traceability.

- `Pipeline.arun(audit=True)` → saves complete audit log:
  - Every LLM prompt and response (redactable)
  - Every normalization decision with rationale
  - Schema lineage (how each field was discovered/modified)
  - Timestamps, model versions, checksums
- Export: JSON audit log, compatible with 21 CFR Part 11 requirements

### 7.6 — Pipeline serialization

Save and reload pipeline configuration for reproducibility.

- `Pipeline.to_config() -> dict` / `Pipeline.from_config(config: dict)`
- YAML/JSON serializable
- Includes all strategy parameters, model names, thresholds
- `catchfly run --config pipeline.yaml --documents ./data/`

---

## Phase 8: Ecosystem + Community (v2.0+)

> Goal: Build the community and ecosystem around catchfly.

### 8.1 — HuggingFace Hub integration

- Publish pre-trained models: `silene/catchfly-hpo-normalizer`, `silene/catchfly-field-selector`
- Publish datasets: `silene/rarearena-case-reports` (benchmark dataset)
- Publish Spaces: interactive demo

### 8.2 — Framework integrations

- `catchfly.integrations.langchain` — catchfly as LangChain tool/chain
- `catchfly.integrations.fastapi` — REST API wrapper with streaming
- `catchfly.integrations.huggingface` — dataset ↔ catchfly conversion

### 8.3 — Plugin system

Allow third-party strategies via entry points.

```toml
[project.entry-points."catchfly.normalization"]
my_strategy = "my_package:MyNormalizationStrategy"
```

- Auto-discovery of installed plugins
- `Pipeline.quick(normalization="my_strategy")` — string-based strategy lookup

---

## Execution Rules (carried forward)

1. **Every step ends with green tests.** Never move to the next step with failing tests.
2. **Every step ends with `uv run ruff check . && uv run mypy src/`** clean.
3. **Commit after each step.** Small, atomic commits. One step = one commit.
4. **Async-first.** Write the `async` method first, then add sync wrapper.
5. **Lazy imports.** Optional deps import inside the function that uses them.
6. **No `print()`.** Use `logging` everywhere.
7. **No hardcoded API keys.** Environment variables or explicit parameters.
8. **Test with mocks by default.** Real API tests tagged `@pytest.mark.llm`.
9. **Biomedical-first.** When in doubt, optimize for the rare disease / clinical use case.
10. **Casual-friendly.** Every biomedical feature should degrade gracefully for non-medical users. `Pipeline.quick()` must always work without domain knowledge.

---

## Priority Matrix

| Phase | Version | Status | Impact on Bio | Impact on Casual | Effort |
|-------|---------|--------|---------------|------------------|--------|
| 1. Core Hardening | v1.1 | **DONE** ✅ | Medium | High | Low |
| 2. Bio Normalization SOTA | v1.1.1 | **DONE** ✅ | **Critical** | Medium | Medium |
| 3. Small Models + Offline | v1.2 | — | High | High | High |
| 4. Bio Ecosystem | v1.2 | — | **Critical** | Low | Medium |
| 5. Docs + Adoption | ongoing | — | High | **Critical** | Medium |
| 6. Knowledge Graphs | v2.0 | — | High | Medium | High |
| 7. Scale + Enterprise | v2.0 | — | Medium | High | High |
| 8. Ecosystem | v2.0+ | — | Medium | High | Medium |
