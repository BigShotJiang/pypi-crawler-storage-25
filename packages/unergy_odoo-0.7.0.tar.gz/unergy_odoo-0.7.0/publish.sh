#!/usr/bin/env bash
set -euo pipefail

# ── version ────────────────────────────────────────────────────────────────
current=$(grep '^version' pyproject.toml | head -1 | sed 's/.*"\(.*\)"/\1/')
echo "Current version: $current"
read -rp "New version: " version

if [[ -z "$version" ]]; then
  echo "Aborted: no version provided."
  exit 1
fi

# ── update pyproject.toml ───────────────────────────────────────────────────
sed -i '' "s/^version = \".*\"/version = \"$version\"/" pyproject.toml
echo "Updated pyproject.toml → $version"

# ── clean dist ─────────────────────────────────────────────────────────────
rm -rf dist/
echo "Cleaned dist/"

# ── build ───────────────────────────────────────────────────────────────────
python -m build
echo "Build complete."

# ── publish ─────────────────────────────────────────────────────────────────
python -m twine upload --repository pypi dist/* --verbose
echo "Published $version."
