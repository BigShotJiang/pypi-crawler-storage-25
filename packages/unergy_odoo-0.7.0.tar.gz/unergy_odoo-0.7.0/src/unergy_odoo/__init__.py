from unergy_odoo.client import FIELD_TYPES, RELATIONAL_TYPES, Odoo, OdooCredentials, OdooExplorer, OdooManager
from unergy_odoo.novedades import (
    Attachment,
    BonoGimnasio,
    Deuda,
    EmployeeNotFound,
    NovedadBase,
    TypePayment,
    Viatico,
)

__all__ = [
    "OdooCredentials",
    "OdooManager",
    "Odoo",
    "OdooExplorer",
    "FIELD_TYPES",
    "RELATIONAL_TYPES",
    "TypePayment",
    "NovedadBase",
    "BonoGimnasio",
    "Deuda",
    "Viatico",
    "EmployeeNotFound",
    "Attachment",
]
