from django import forms
from django.contrib import admin
from django.contrib.contenttypes.admin import GenericStackedInline

from unergy_odoo.django.models import OdooCredentials


class OdooCredentialsForm(forms.ModelForm):
    class Meta:
        model = OdooCredentials
        fields = "__all__"
        widgets = {"password": forms.PasswordInput(render_value=False)}


@admin.register(OdooCredentials)
class OdooCredentialsAdmin(admin.ModelAdmin):
    form = OdooCredentialsForm
    list_display = ("__str__", "host", "db", "username")
    search_fields = ("host", "username")


class OdooCredentialsInline(GenericStackedInline):
    """
    Inline for embedding Odoo credentials directly in your Company admin.

    Usage::

        from unergy_odoo.django.admin import OdooCredentialsInline

        @admin.register(Company)
        class CompanyAdmin(admin.ModelAdmin):
            inlines = [OdooCredentialsInline]
    """

    model = OdooCredentials
    form = OdooCredentialsForm
    max_num = 1
    extra = 0
