from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models

from unergy_odoo.django.encryption import EncryptedTextField


class OdooCredentials(models.Model):
    """
    Odoo connection credentials linked to any company model via GenericForeignKey.

    The password is Fernet-encrypted at rest (UNERGY_ODOO['FERNET_KEY']).

    Linking credentials to a company::

        from django.contrib.contenttypes.models import ContentType
        from unergy_odoo.django.models import OdooCredentials

        ct = ContentType.objects.get_for_model(my_company)
        OdooCredentials.objects.create(
            content_type=ct,
            object_id=my_company.pk,
            host="https://my-instance.odoo.com",
            db="my_db",
            username="admin@company.com",
            password="api-key",
        )
    """

    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    object_id = models.PositiveIntegerField(null=True, blank=True)
    company = GenericForeignKey("content_type", "object_id")

    host = models.CharField(max_length=255)
    db = models.CharField(max_length=100)
    username = models.CharField(max_length=150)
    password = EncryptedTextField()

    class Meta:
        app_label = "unergy_odoo_django"
        verbose_name = "Odoo Credentials"
        verbose_name_plural = "Odoo Credentials"
        unique_together = [("content_type", "object_id")]

    def __str__(self) -> str:
        if self.company:
            return f"Odoo Credentials — {self.company}"
        return "Odoo Credentials (unlinked)"

    def as_client_credentials(self):
        """Returns an unergy_odoo.OdooCredentials dataclass ready to pass to Odoo/NovedadBase."""
        from unergy_odoo import OdooCredentials as _ClientCredentials

        return _ClientCredentials(
            host=self.host,
            db=self.db,
            username=self.username,
            password=self.password,
        )
