from unergy_odoo import OdooCredentials


class NoOdooCredentials(Exception):
    """
    Raised when no OdooCredentials record is found for the resolved company,
    or when the COMPANY_RESOLVER fails to find a matching company.
    """

    def __init__(self, arg):
        super().__init__(
            f"No Odoo credentials are configured for '{arg}'. "
            "Contact your administrator."
        )
        self.arg = arg


def get_odoo_credentials(arg) -> OdooCredentials:
    """
    Resolves an unergy_odoo.OdooCredentials dataclass for the given argument.

    Resolution steps:

        1. Calls ``UNERGY_ODOO['COMPANY_RESOLVER'](arg)`` → company instance.
        2. Looks up the ``OdooCredentials`` DB record linked to that company.
        3. Returns an ``unergy_odoo.OdooCredentials`` dataclass.

    Args:
        arg: Anything your COMPANY_RESOLVER accepts (e.g. email, domain, user id).

    Raises:
        NoOdooCredentials: if the resolver fails or no credentials are linked.
        ImproperlyConfigured: if UNERGY_ODOO['COMPANY_RESOLVER'] is not set.

    Example::

        # settings.py
        def _resolve(email):
            from myapp.models import Company
            domain = email.split("@")[-1].lower()
            return Company.objects.get(email_domain=domain)

        UNERGY_ODOO = {
            "FERNET_KEY": "...",
            "COMPANY_RESOLVER": _resolve,
        }

        # anywhere in your code
        from unergy_odoo.django.credentials import get_odoo_credentials

        creds = get_odoo_credentials(request.user.email)
        bono = BonoGimnasio(..., odoo_credentials=creds)
    """
    from django.contrib.contenttypes.models import ContentType
    from django.core.exceptions import ImproperlyConfigured

    from unergy_odoo.django.conf import conf
    from unergy_odoo.django.models import OdooCredentials as _OdooCredentialsModel

    resolver = conf.COMPANY_RESOLVER
    if resolver is None:
        raise ImproperlyConfigured(
            "UNERGY_ODOO['COMPANY_RESOLVER'] is not configured. "
            "Provide a callable that maps any argument to a company model instance."
        )

    try:
        company = resolver(arg)
    except Exception as exc:
        raise NoOdooCredentials(arg) from exc

    ct = ContentType.objects.get_for_model(company)
    try:
        db_creds = _OdooCredentialsModel.objects.get(content_type=ct, object_id=company.pk)
    except _OdooCredentialsModel.DoesNotExist:
        raise NoOdooCredentials(arg)

    return db_creds.as_client_credentials()
