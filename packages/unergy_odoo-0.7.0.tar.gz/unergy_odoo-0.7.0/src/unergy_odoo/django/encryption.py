from django.db import models


class EncryptedTextField(models.TextField):
    """
    TextField that transparently encrypts values at rest using Fernet symmetric encryption.

    Requires UNERGY_ODOO['FERNET_KEY'] in Django settings (or UNERGY_ODOO_FERNET_KEY env var).
    """

    def _fernet(self):
        from cryptography.fernet import Fernet
        from unergy_odoo.django.conf import conf

        key = conf.FERNET_KEY
        if isinstance(key, str):
            key = key.encode()
        return Fernet(key)

    def from_db_value(self, value, expression, connection):
        if value is None:
            return value
        return self._fernet().decrypt(value.encode()).decode()

    def get_prep_value(self, value):
        if value is None:
            return value
        return self._fernet().encrypt(value.encode()).decode()

    def formfield(self, **kwargs):
        from django import forms
        kwargs.setdefault("widget", forms.PasswordInput(render_value=False))
        return super().formfield(**kwargs)

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        path = "unergy_odoo.django.encryption.EncryptedTextField"
        return name, path, args, kwargs
