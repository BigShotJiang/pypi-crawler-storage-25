import django.db.models.deletion
from django.db import migrations, models

import unergy_odoo.django.encryption


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("contenttypes", "0002_remove_content_type_name"),
    ]

    operations = [
        migrations.CreateModel(
            name="OdooCredentials",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("object_id", models.PositiveIntegerField(blank=True, null=True)),
                ("host", models.CharField(max_length=255)),
                ("db", models.CharField(max_length=100)),
                ("username", models.CharField(max_length=150)),
                ("password", unergy_odoo.django.encryption.EncryptedTextField()),
                (
                    "content_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        to="contenttypes.contenttype",
                    ),
                ),
            ],
            options={
                "verbose_name": "Odoo Credentials",
                "verbose_name_plural": "Odoo Credentials",
                "unique_together": {("content_type", "object_id")},
            },
        ),
    ]
