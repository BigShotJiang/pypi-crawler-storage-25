import os

from django.core.exceptions import ImproperlyConfigured
from django.utils.module_loading import import_string


class _UnergyOdooConf:
    """
    Lazy accessor for UNERGY_ODOO settings dict.

    Supported keys::

        UNERGY_ODOO = {
            # Required — Fernet symmetric key for password encryption.
            # Generate: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
            # Falls back to UNERGY_ODOO_FERNET_KEY environment variable.
            "FERNET_KEY": "your-fernet-key",

            # Required for get_odoo_credentials() — callable (or dotted import path)
            # that maps any argument to a company model instance.
            # Signature: (arg: Any) -> company_instance
            "COMPANY_RESOLVER": "myapp.utils.resolve_company_from_email",
        }
    """

    @property
    def _user_settings(self) -> dict:
        from django.conf import settings
        return getattr(settings, "UNERGY_ODOO", {})

    @property
    def FERNET_KEY(self) -> str:
        val = self._user_settings.get("FERNET_KEY") or os.environ.get("UNERGY_ODOO_FERNET_KEY")
        if not val:
            raise ImproperlyConfigured(
                "UNERGY_ODOO['FERNET_KEY'] is required. "
                "Generate one with: "
                "python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
            )
        return val

    @property
    def COMPANY_RESOLVER(self):
        """
        Returns the configured COMPANY_RESOLVER callable, or None if not set.
        Accepts both a direct callable and a dotted import path string.
        """
        val = self._user_settings.get("COMPANY_RESOLVER")
        if val is None:
            return None
        if isinstance(val, str):
            return import_string(val)
        return val


conf = _UnergyOdooConf()
