from django.apps import AppConfig


class UnergyOdooDjangoConfig(AppConfig):
    name = "unergy_odoo.django"
    label = "unergy_odoo_django"
    verbose_name = "Unergy Odoo"
    default_auto_field = "django.db.models.BigAutoField"
