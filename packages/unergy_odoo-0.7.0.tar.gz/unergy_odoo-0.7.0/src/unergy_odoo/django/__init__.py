# Django integration for unergy-odoo.
# Add "unergy_odoo.django" to INSTALLED_APPS to enable the OdooCredentials model.
