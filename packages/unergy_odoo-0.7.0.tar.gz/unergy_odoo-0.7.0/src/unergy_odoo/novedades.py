import base64
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import IO

from unergy_odoo.client import Odoo, OdooCredentials

# Tipos aceptados como archivo adjunto: ruta o file-like object
Attachment = str | Path | IO[bytes]


class TypePayment:
    MONTHLY = "monthly"
    FIRST_HALF = "first_half"
    SECOND_HALF = "second_half"
    BOTH_FORTNIGHT = "both_fortnight"

    @staticmethod
    def determine_type(date_start: date) -> str:
        """Return FIRST_HALF or SECOND_HALF based on the day of the month."""
        day = date_start.day
        if (1 <= day <= 13) or (28 <= day <= 31):
            return TypePayment.FIRST_HALF
        return TypePayment.SECOND_HALF

    @staticmethod
    def determine_date(date_start: date, type_payment: str) -> date:
        """Return the actual payment date for the given period."""
        day = date_start.day
        month = date_start.month

        # February cap requested by accounting
        day_cap = 26 if month != 2 else 28
        if day <= day_cap:
            return date(
                year=date_start.year,
                month=month,
                day=15 if type_payment == TypePayment.FIRST_HALF else 30,
            )
        return date(
            year=date_start.year,
            month=month + 1,
            day=15 if type_payment == TypePayment.FIRST_HALF else 30,
        )


class EmployeeNotFound(Exception):
    pass


@dataclass
class NovedadBase:
    """
    Clase base para registrar novedades de nómina en Odoo (hr.salary.attachment).

    Las subclases deben definir:
        DEDUCTION_TYPE: str  — clave técnica del tipo de novedad
        _payload() -> dict   — campos específicos del tipo (sin employee_id ni deduction_type)

    Campos comunes (aplican a todas las novedades):
        identification  — Documento de identidad del empleado (cédula)
        description     — Descripción de la novedad
        monthly_amount  — Monto mensual (COP)
        date_start      — Fecha de inicio
        state              — Estado al crear (default: 'open')
        attachments        — Lista de archivos adjuntos (rutas o file-like objects)
        complete_previous  — Si True (default), cierra las novedades activas previas
                             del mismo empleado y concepto antes de crear la nueva
        type_payment       — Quincena de aplicación:
                            'monthly' | 'first_half' | 'second_half' | 'both_fortnight'

    Credentials:
        Resolution order:
            1. odoo_credentials (OdooCredentials instance)
            2. Individual odoo_host / odoo_db / odoo_username / odoo_password fields
            3. Environment variables ODOO_HOST, ODOO_DB, ODOO_USERNAME, ODOO_PASSWORD

    Optional fields (included in the payload only when not None):
        total_amount      — Monto total del concepto (ej. para pagos por valor fijo)
        remaining_amount  — Monto restante pendiente de pago

    Extra fields:
        extra_fields      — Diccionario con campos adicionales de Odoo. Solo los valores
                            que no sean None se incluyen en el payload. Tienen prioridad
                            sobre los campos base y los de la subclase.
    """

    DEDUCTION_TYPE: str = field(init=False)

    identification: str
    description: str
    monthly_amount: float
    date_start: date
    type_payment: str
    state: str = "open"
    attachments: list[Attachment] = field(default_factory=list)
    complete_previous: bool = True
    total_amount: float | None = None
    remaining_amount: float | None = None
    extra_fields: dict = field(default_factory=dict)

    # Optional Odoo credential overrides (fall back to env vars if not provided).
    # odoo_credentials takes priority over the individual odoo_* fields.
    odoo_credentials: OdooCredentials | None = field(default=None, repr=False)
    odoo_host: str | None = field(default=None, repr=False)
    odoo_db: str | None = field(default=None, repr=False)
    odoo_username: str | None = field(default=None, repr=False)
    odoo_password: str | None = field(default=None, repr=False)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _odoo(self, model: str) -> Odoo:
        if self.odoo_credentials is not None:
            return Odoo(model, credentials=self.odoo_credentials)
        return Odoo(
            model,
            host=self.odoo_host,
            db=self.odoo_db,
            username=self.odoo_username,
            password=self.odoo_password,
        )

    # ------------------------------------------------------------------
    # Resolución del empleado
    # ------------------------------------------------------------------

    def _resolve_employee(self) -> int:
        """
        Busca el empleado en Odoo por número de documento de identidad.
        Lanza EmployeeNotFound si no existe.
        """
        odoo_employee = self._odoo("hr.employee")
        try:
            return odoo_employee.get_id(
                filter=[["identification_id", "=", self.identification]]
            )
        except Odoo.DoesNotExist:
            raise EmployeeNotFound(
                f"No se encontró un empleado con documento '{self.identification}' en Odoo."
            )

    # ------------------------------------------------------------------
    # Construcción del payload
    # ------------------------------------------------------------------

    def _base_payload(self, employee_id: int) -> dict:
        # Campos requeridos por hr.salary.attachment para cualquier novedad
        payload = {
            "employee_id": employee_id,
            "deduction_type": self.DEDUCTION_TYPE,
            "description": self.description,
            "monthly_amount": self.monthly_amount,
            "date_start": str(self.date_start),
            "state": self.state,
            "type_payment": self.type_payment,
        }
        if self.total_amount is not None:
            payload["total_amount"] = self.total_amount
        if self.remaining_amount is not None:
            payload["remaining_amount"] = self.remaining_amount
        return payload

    def _payload(self) -> dict:
        # Las subclases sobreescriben este método para agregar campos específicos
        return {}

    # ------------------------------------------------------------------
    # Archivos adjuntos
    # ------------------------------------------------------------------

    def _upload_attachments(self, record_id: int) -> None:
        """
        Sube los archivos en self.attachments como ir.attachment
        vinculados al registro recién creado.
        Acepta rutas de archivo (str o Path) y file-like objects.
        """
        if not self.attachments:
            return

        odoo_attachment = self._odoo("ir.attachment")

        for attachment in self.attachments:
            if isinstance(attachment, (str, Path)):
                # Ruta de archivo: leer contenido y usar el nombre del archivo
                path = Path(attachment)
                content = path.read_bytes()
                name = path.name
            else:
                # File-like object: leer contenido y extraer nombre si está disponible
                content = attachment.read()
                name = Path(getattr(attachment, "name", "adjunto")).name

            odoo_attachment.create(
                {
                    "res_model": "hr.salary.attachment",
                    "res_id": record_id,
                    "type": "binary",
                    "name": name,
                    "datas": base64.b64encode(content).decode("ascii"),
                }
            )

    # ------------------------------------------------------------------
    # Novedades previas
    # ------------------------------------------------------------------

    def _complete_previous_active_novedades(self, employee_id: int) -> None:
        """
        Marca como completadas (state='close') todas las novedades activas
        (state='open') del mismo empleado y mismo concepto (deduction_type).
        Se llama antes de crear la nueva novedad para evitar doble pago.
        """
        odoo_salary = self._odoo("hr.salary.attachment")
        previous_ids = odoo_salary.get_list_value_field(
            fields=["id"],
            filter=[
                ["employee_id", "=", employee_id],
                ["deduction_type", "=", self.DEDUCTION_TYPE],
                ["state", "=", "open"],
            ],
            field="id",
        )
        if previous_ids:
            odoo_salary.update(previous_ids, {"state": "close"})

    # ------------------------------------------------------------------
    # Acción principal
    # ------------------------------------------------------------------

    def register(self) -> int:
        """
        Busca el empleado, crea el registro en hr.salary.attachment
        y sube los archivos adjuntos si se proporcionaron.

        Si complete_previous=True (default), cierra todas las novedades activas
        del mismo empleado y concepto antes de crear la nueva.

        Returns:
            ID del registro creado en Odoo.

        Raises:
            EmployeeNotFound: si el documento no corresponde a ningún empleado.
        """
        employee_id = self._resolve_employee()
        if self.complete_previous:
            self._complete_previous_active_novedades(employee_id)
        extra = {k: v for k, v in self.extra_fields.items() if v is not None}
        payload = {**self._base_payload(employee_id), **self._payload(), **extra}
        record_id = self._odoo("hr.salary.attachment").create(payload)
        self._upload_attachments(record_id)
        return record_id


# ----------------------------------------------------------------------
# Novedades concretas
# ----------------------------------------------------------------------


@dataclass
class BonoGimnasio(NovedadBase):
    """
    Registra un bono de gimnasio en Odoo.
    Tipo: Bono (EPCTV) No Salarial — deduction_type='BONO_EPCTV_NS'

    Uso:
        from unergy_odoo.novedades import BonoGimnasio

        bono = BonoGimnasio(
            identification="1234567890",
            description="GIMNASIO JOHN DOE 2026-04-15 #10",
            monthly_amount=80000,
            date_start=date(2026, 4, 1),
            type_payment="second_half",
        )
        odoo_id = bono.register()
    """

    DEDUCTION_TYPE: str = field(init=False, default="BONO_EPCTV_NS")

    def _payload(self) -> dict:
        return {}


@dataclass
class Viatico(NovedadBase):
    """
    Registra un viático en Odoo.
    Tipo: Reintegro (Entrada) — deduction_type='REINTEGRO'

    Uso:
        from unergy_odoo.novedades import Viatico

        viatico = Viatico(
            identification="1234567890",
            description="Viático viaje Bogotá",
            monthly_amount=150000,
            date_start=date(2026, 4, 1),
            attachments=["soporte.pdf"],          # opcional, uno o varios
        )
        odoo_id = viatico.register()

    Args opcionales:
        total_amount  — Monto total si el pago es por valor fijo (heredado de NovedadBase)
        date_end      — Fecha fin si el viático tiene vencimiento
        type_payment  — Quincena de aplicación:
                        'monthly' | 'first_half' | 'second_half' | 'both_fortnight'
        attachments   — Lista de rutas o file-like objects a adjuntar
    """

    DEDUCTION_TYPE: str = field(init=False, default="REINTEGRO")

    date_end: date | None = None

    def _payload(self) -> dict:
        if self.date_end is not None:
            return {"date_end": str(self.date_end)}
        return {}


@dataclass
class Deuda(NovedadBase):
    """
    Registra una deuda a descontar de nómina en Odoo.
    Tipo: Deuda — deduction_type='DEUDA'

    Uso:
        from unergy_odoo.novedades import Deuda

        deuda = Deuda(
            identification="1234567890",
            description="Comidas 2026-04-01/2026-04-15 — D:3 A:5 C:0",
            monthly_amount=45000,
            date_start=date(2026, 4, 1),
            type_payment="first_half",
        )
        odoo_id = deuda.register()

    Args opcionales:
        date_end  — Fecha fin si la deuda tiene vencimiento
    """

    DEDUCTION_TYPE: str = field(init=False, default="DEUDA")
    date_end: date | None = None

    def _payload(self) -> dict:
        if self.date_end is not None:
            return {"date_end": str(self.date_end)}
        return {}
