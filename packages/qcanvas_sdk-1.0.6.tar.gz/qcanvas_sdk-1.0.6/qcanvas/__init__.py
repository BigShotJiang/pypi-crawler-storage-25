"""
Top-level QCanvas Python API for Hybrid CPU–QPU execution.
"""

from .core import compile, compile_and_execute
from .result import SimulationResult, HybridExecutionResult

__all__ = [
    "compile",
    "compile_and_execute",
    "SimulationResult",
    "HybridExecutionResult",
]

__version__ = "1.0.5"
