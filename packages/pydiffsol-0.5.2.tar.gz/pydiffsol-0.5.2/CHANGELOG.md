# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.2]

### Added

- Method to get underlying `diffsol_c_version`.

### Changed

- Update benchmarking results using latest diffsol-c 0.4.4.

## [0.5.1]

### Fixed

- Updated diffsol-c to 0.4.2 to pick up recent indexing bug fix.

## [0.5.0]

### Added

- Switch to `diffsol-c` wrapper, directly using `diffsol` crate's runtime dispatch and conversion (#80)
- `Ode` split-adjoint methods: `solve_continuous_adjoint`, `solve_adjoint_fwd`, and `solve_adjoint_bkwd`.
- Select ODE JIT backend rather than it being determined by platform.
- Pickling support allows restoration of equivalent solver much faster than JIT compiling twice.
- Methods to get underlying `diffsol_version` and `diffsl_version`

### Fixed

- Exposed missing `is_sens_available` method.

### Changed

- `Ode` `solve`, `solve_dense`, and `solve_fwd_sens` now handle stop/reset events automatically.
- `SolverMethod` class renamed to `OdeSolverType`. Similarly, usage of `ode_solver` in `Ode` `solve` methods replaced with `ode_solver`.
- `SolverType` class renamed to `LinearSolverType`.
- VSCode `maturin develop` task moved from "Run Task" command to "Run Build Task" command.

## [0.4.0]

### Added

- Support for solution continuation by making all solve methods return common `Solution` type that may be passed back into to next solve call (#48)
- Add Pharmacokinetic (PK) and bouncing ball examples (#48)
- Contributing guide (#62)
- Docs QA and tests (#61)

### Changed

- Solution continuation (#48) changes the return type of all solve calls from a tuple to a common `Solution` class. For example instead of `ys, ts = ode.solve(...)` you now have a result `s = ode.solve(...)` and get values from `s.ys` and `s.ts`. See PK example for usage.

## [0.3.1]

### Added

- Get/set initial conditions, solver options, rhs and y0 (#30)
- Electrical circuits example (#39)
- Heat equation example (#36)
- Update to diffsol 0.10.2 (#41)

## [0.3.0]

### Added

- 32-bit float support (#27)
- Robertson_ode benchmark (#16)
- Forward sensitivity and adjoint sum of squares solves (#21)
- Generalise benchmarks for different models and add lotka-volterra benchmark (#19)

## [0.2.0]

### Added

- Wheels built using `cibuildwheel` rather than maturin for neater build matrix and resolving dylib issues.
- Config class removed. This is now rolled into Ode class for friendlier interface.
- Support for `tr_bdf2` and `tsit45` solver methods.
- Build with SuiteSparse for KLU support for Linux. Use `is_klu_available` method to check if available on running platform.
- Support for `faer_dense_f64` matrix_type if KLU available.
- `solve_dense` method to return solution at specified times.
- Runtime reflection utilities for `SolverMethod`, `MatrixType` and `MatrixType`: get all enums with `all`; `__str__` and `__hash__` dunder methods.
- `default` solver type automatically selects `lu` or `klu` based on matrix type, except for `tsit45` which does not need solver type.
- `solver_for_matrix_type` config method to check how default will be resolved at point of solve call.
- Get original `code` specified in Ode when constructed.
- Spring mass systems example from original Diffsol ported to Python.

### Fixed

- Ensure that problem is compiled when Ode is constructed, not on every call to solve.
- SuiteSparse added to build so `fear_sparse_f64` now working correctly (except for BDF on macos, known issue internal to diffsol)

## [0.1.3]

### Added

- Build wheel for macos and Linux (LLVM backend), and Windows (CraneLift backend).
- `bdf` and `esdirk34` solvers.
- `nalgebra_dense_f64` matrix type and in-progress `faer_sparse_f64` matrix type.
- Population dynamics example from original Diffsol ported to Python.
