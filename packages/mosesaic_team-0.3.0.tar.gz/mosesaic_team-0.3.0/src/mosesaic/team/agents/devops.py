"""DevOps specialist agent — assesses deployment readiness."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.team.charters.charter_loader import load_charter
from mosesaic.team.prompt.spawn_context import SpawnContext


@dataclass
class DevopsInput:
    """Input for the devops specialist."""
    goal: str
    files_changed: list[str] = field(default_factory=list)
    qa_findings: list[str] = field(default_factory=list)
    spawn_context: SpawnContext | None = None


@dataclass
class DevopsOutput:
    """Output from the devops specialist."""
    deployment_state: str   # "pending" | "staging" | "production"
    summary: str
    cost_usd: float = 0.0


def _strip_fences(content: str) -> str:
    if content.startswith("```"):
        lines = content.splitlines()
        return "\n".join(line for line in lines if not line.startswith("```")).strip()
    return content


@agent(
    name="devops_agent",
    system_prompt=load_charter("devops"),
    supervisor=SupervisorPolicy(budget_usd=0.10, on_failure="stop"),
    governance_tier=3,
)
async def devops_agent(ctx: AgentContext) -> None:
    """Assesses deployment readiness and determines deployment state."""
    msg = await ctx.receive()
    payload: DevopsInput = msg.payload

    if payload.spawn_context:
        user_message = payload.spawn_context.to_prompt() + "\n\nRespond with JSON only."
    else:
        user_message = (
            f"Goal: {payload.goal}\n\n"
            f"Files changed:\n{payload.files_changed or 'None'}\n\n"
            f"QA findings:\n{payload.qa_findings or 'None'}\n\n"
            "Respond with JSON only."
        )

    task_hint = payload.spawn_context.task_hint if payload.spawn_context else "general"
    response = await ctx.llm.chat([{"role": "user", "content": user_message}], task_hint=task_hint)
    data = json.loads(_strip_fences(response.content.strip()))

    await ctx.send(msg.from_agent, DevopsOutput(
        deployment_state=data.get("deployment_state", "pending"),
        summary=data.get("summary", ""),
        cost_usd=ctx.cost.spent_usd,
    ))
