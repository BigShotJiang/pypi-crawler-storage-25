"""ProjectContext — shared working memory written by every agent phase."""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

_VALID_REQUEST_TYPES = frozenset({"feature", "bugfix", "greenfield", "incident", "refactor"})


@dataclass
class ProjectContext:
    """Mutable shared context passed across all orchestration phases.

    Every phase director reads from and writes to this object. It acts as the
    inter-phase communication channel (Pathfinder metadata pattern).

    Args:
        goal: The original user prompt / goal.
        request_type: Classification of the request.
    """

    goal: str
    request_type: str = "feature"
    project_root: str = field(default_factory=lambda: str(Path.cwd()))
    constraints: list[str] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    adr: str | None = None                  # Architecture Decision Record
    design_spec: str | None = None          # Designer output
    file_plan: list[str] = field(default_factory=list)
    files_changed: list[str] = field(default_factory=list)
    test_results: dict = field(default_factory=dict)
    qa_findings: list[str] = field(default_factory=list)
    how_to_install: str = ""
    how_to_use: str = ""
    how_to_verify: str = ""
    phase_task_hints: dict[str, str] = field(default_factory=dict)
    # e.g. {"clarify": "cheap", "architect": "reasoning", "build": "reasoning"}
    resource_notes: str = ""
    deployment_state: str = "pending"       # pending | staging | production
    phase_history: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.request_type not in _VALID_REQUEST_TYPES:
            raise ValueError(
                f"request_type must be one of {sorted(_VALID_REQUEST_TYPES)}, "
                f"got {self.request_type!r}"
            )
