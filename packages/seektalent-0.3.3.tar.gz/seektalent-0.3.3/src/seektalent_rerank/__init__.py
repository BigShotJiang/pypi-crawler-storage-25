"""Local rerank service package."""

