"""Generate or validate changelog entries from branch context and detect_context.

Sub-commands:
    pysae-ai-tools code changelog generate [description]   # create entry
    pysae-ai-tools code changelog validate [--fix] [PATH]  # lint changelogs/
    pysae-ai-tools code changelog release TAG              # merge changelogs/* into CHANGELOG.md

Validation enforces strict conventional commits format:
    * <type>: <description>[ (#<iid>)]

Type ∈ {feat, fix, tech, refactor, docs, chore, perf, build, ci, style, test,
revert, bump}. The pattern is delegated to commitizen's
``ConventionalCommitsCz`` (with ``tech`` added for Pysae).

The ``--fix`` mode reformats non-conforming entries by extracting type/IID
hints from the filename when missing (e.g. ``feat-123-slug.md``).
"""

import json
import re
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import date
from pathlib import Path
from typing import Annotated

import typer
from commitizen.config import BaseConfig
from commitizen.cz.conventional_commits.conventional_commits import ConventionalCommitsCz

from ..internal.detect_context.detect import DetectArgs, detect


@dataclass
class ChangelogEntry:
    file: str
    content: str
    type: str
    issue_iid: str
    branch: str
    description: str
    already_exists: bool = False


# Branch prefix -> changelog type
_PREFIX_MAP: dict[str, str] = {
    "feat": "feat",
    "fix": "fix",
    "tech": "tech",
    "refactor": "refactor",
    "docs": "docs",
    "chore": "chore",
    "perf": "perf",
}

# GitLab issue type label -> changelog type
_LABEL_TYPE_MAP: dict[str, str] = {
    "type::bug": "fix",
    "type::feature": "feat",
    "type::technical": "tech",
    "type::refactoring": "refactor",
}


def _detect_type_from_labels(labels: list[str]) -> str:
    """Detect changelog type from GitLab issue type::* labels."""
    for label in labels:
        if label in _LABEL_TYPE_MAP:
            return _LABEL_TYPE_MAP[label]
    return ""


def _detect_type_from_branch(branch: str) -> str:
    """Detect changelog type from branch prefix (e.g. feat/123-slug -> feat)."""
    prefix = branch.split("/")[0] if "/" in branch else ""
    return _PREFIX_MAP.get(prefix, "")


def _detect_type_from_commits() -> str:
    """Detect changelog type from recent commit messages on the branch."""
    try:
        result = subprocess.run(
            ["git", "log", "--oneline", "--no-merges", "-10", "--format=%s"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return ""
        for line in result.stdout.strip().splitlines():
            match = re.match(r"^(\w+)[:(]", line)
            if match and match.group(1).lower() in _PREFIX_MAP:
                return _PREFIX_MAP[match.group(1).lower()]
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return ""


def _extract_issue_iid(branch: str) -> str:
    """Extract issue IID from branch name (e.g. feat/123-slug -> 123)."""
    match = re.search(r"(\d+)", branch)
    return match.group(1) if match else ""


def _description_from_branch(branch: str) -> str:
    """Build a default description from branch slug."""
    # Remove prefix/ and IID, keep the slug
    slug = branch.split("/", 1)[-1] if "/" in branch else branch
    slug = re.sub(r"^\d+-", "", slug)  # Remove leading IID
    return slug.replace("-", " ").strip()


def _description_from_commits() -> str:
    """Get description from the first commit message on the branch."""
    try:
        result = subprocess.run(
            ["git", "log", "--oneline", "--no-merges", "-1", "--format=%s"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            msg = result.stdout.strip()
            # Strip conventional commit prefix
            stripped = re.sub(r"^\w+(\(.+?\))?:\s*", "", msg)
            return stripped if stripped else msg
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return ""


def generate_entry(
    description: str = "",
    branch: str = "",
    issue_iid: str = "",
    change_type: str = "",
    issue_labels: list[str] | None = None,
) -> ChangelogEntry:
    """Generate a changelog entry from context.

    Auto-detects branch, issue IID, type, and description if not provided.
    Type priority: explicit > issue label > branch prefix > commit prefix > "feat".
    """
    # Resolve context from detect_context (gives branch, issue IID, labels, titles)
    mr_title = ""
    issue_title = ""
    try:
        ctx_args = DetectArgs()
        ctx = detect(ctx_args)
        branch = branch or ctx.mr_source_branch or ctx.git_branch
        issue_iid = issue_iid or ctx.issue_iid
        mr_title = ctx.mr_title
        issue_title = ctx.issue_title
        if issue_labels is None:
            issue_labels = ctx.issue_labels
    except Exception:
        pass

    # Fallback: branch from git
    if not branch:
        try:
            result = subprocess.run(
                ["git", "branch", "--show-current"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            branch = result.stdout.strip() if result.returncode == 0 else ""
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    # Fallback: issue IID from branch name
    if not issue_iid:
        issue_iid = _extract_issue_iid(branch)

    # Resolve type: label > branch prefix > commit prefix > "feat"
    if not change_type:
        change_type = (
            _detect_type_from_labels(issue_labels or [])
            or _detect_type_from_branch(branch)
            or _detect_type_from_commits()
            or "tech"
        )

    # Resolve description: issue title > MR title > commits > branch slug
    if not description:
        raw = issue_title or mr_title
        if raw:
            # Strip conventional commit prefix if present (e.g. "feat: add export" -> "add export")
            description = re.sub(r"^\w+(\(.+?\))?:\s*", "", raw)
        if not description:
            description = _description_from_commits() or _description_from_branch(branch)

    # Clean description
    if description:
        # Strip trailing issue ref if present (e.g. "(#123)") — the script adds it automatically
        description = re.sub(r"\s*\(#\d+\)\s*$", "", description)
        # Ensure lowercase start, no trailing period
        description = description[0].lower() + description[1:]
        description = description.rstrip(".")

    # Build content line
    issue_ref = f" (#{issue_iid})" if issue_iid else ""
    content = f"* {change_type}: {description}{issue_ref}"

    # Truncate to 100 chars
    if len(content) > 100:
        max_desc = 100 - len(f"* {change_type}: {issue_ref}")
        description = description[: max_desc - 3] + "..."
        content = f"* {change_type}: {description}{issue_ref}"

    # File path
    filename = branch.replace("/", "-") if branch else "changelog"
    filepath = f"changelogs/{filename}.md"
    already_exists = Path(filepath).exists()

    return ChangelogEntry(
        file=filepath,
        content=content,
        type=change_type,
        issue_iid=issue_iid,
        branch=branch,
        description=description,
        already_exists=already_exists,
    )


def _generate(description: str, write: bool, type_: str, as_json: bool) -> None:
    """Generate a changelog entry and emit output (human-readable by default)."""
    entry = generate_entry(description=description, change_type=type_)

    if write and not entry.already_exists:
        path = Path(entry.file)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(entry.content + "\n")

    if as_json:
        json.dump(asdict(entry), sys.stdout, indent=2)
        sys.stdout.write("\n")
        return

    if entry.already_exists:
        typer.secho(f"• {entry.file} already exists", fg=typer.colors.YELLOW)
    elif write:
        typer.secho(f"✓ wrote {entry.file}", fg=typer.colors.GREEN)
    else:
        typer.secho(f"→ would write {entry.file}", fg=typer.colors.CYAN)
    typer.echo(entry.content)


# ---------------------------------------------------------------------------
# Validation (commitizen-backed)
# ---------------------------------------------------------------------------


class _PysaeCz(ConventionalCommitsCz):
    """Conventional commits with Pysae's ``tech`` type added."""

    def schema_pattern(self) -> str:
        return (
            r"(?s)"
            r"(build|ci|docs|feat|fix|perf|refactor|style|test|chore|revert|bump|tech)"
            r"(\(\S+\))?!?:"
            r"( [^\n\r]+)"
            r"((\n\n.*)|(\s*))?$"
        )


_CZ = _PysaeCz(BaseConfig())  # type: ignore[no-untyped-call]
_CZ_PATTERN = re.compile(_CZ.schema_pattern())


def _first_bullet(content: str) -> tuple[str, int] | None:
    """Return the first non-blank line and its index, or None if file is empty."""
    for i, line in enumerate(content.splitlines()):
        if line.strip():
            return line, i
    return None


def _strip_bullet(line: str) -> str | None:
    """Strip the leading ``* `` bullet. Returns None if missing."""
    if not line.startswith("* "):
        return None
    return line[2:].strip()


def _strip_iid_ref(body: str) -> str:
    """Strip a trailing ``(#123)`` issue reference."""
    return re.sub(r"\s*\(#\d+\)\s*$", "", body).strip()


def _validate_body(body: str) -> bool:
    """Return True if ``body`` (without bullet, without trailing iid) is valid."""
    return bool(_CZ_PATTERN.match(_strip_iid_ref(body)))


def _filename_hints(filename: str) -> tuple[str, str]:
    """Extract (type, iid) hints from a filename like ``feat-123-slug.md``."""
    stem = Path(filename).stem
    parts = stem.split("-")
    type_ = ""
    iid = ""
    if parts and parts[0] in _PREFIX_MAP:
        type_ = parts[0]
        parts = parts[1:]
    if parts and parts[0].isdigit():
        iid = parts[0]
    return type_, iid


def _try_fix(line: str, filename: str) -> str | None:
    """Reformat ``line`` to the strict format using filename hints when needed."""
    file_type, file_iid = _filename_hints(filename)
    body = line.lstrip()
    if body.startswith("*"):
        body = body[1:].lstrip()

    type_ = ""
    iid = ""
    desc = ""

    # Pattern: '#iid type: desc'
    m = re.match(r"^#(\d+)\s+(\w+):\s*(.+)$", body)
    if m and m.group(2).lower() in _PREFIX_MAP:
        iid = m.group(1)
        type_ = m.group(2).lower()
        desc = m.group(3)

    if not type_:
        # Pattern: 'type: desc'
        m = re.match(r"^(\w+):\s*(.+)$", body)
        if m and m.group(1).lower() in _PREFIX_MAP:
            type_ = m.group(1).lower()
            desc = m.group(2)

    if not type_:
        # Pattern: '#iid[:] desc'
        m = re.match(r"^#(\d+)[:\s]\s*(.+)$", body)
        if m:
            iid = m.group(1)
            desc = m.group(2)

    if not desc:
        # Free text fallback
        desc = body

    if not iid:
        iid = file_iid
    if not type_:
        type_ = file_type or "tech"

    desc = _strip_iid_ref(desc)
    if not desc:
        return None
    desc = desc[0].lower() + desc[1:]
    desc = desc.rstrip(".")

    iid_ref = f" (#{iid})" if iid else ""
    return f"* {type_}: {desc}{iid_ref}"


@dataclass
class _ValidationFailure:
    file: Path
    reason: str
    line: str


def _rewrite_line(file: Path, content: str, idx: int, new_line: str) -> None:
    lines = content.splitlines()
    lines[idx] = new_line
    new_content = "\n".join(lines)
    if content.endswith("\n"):
        new_content += "\n"
    file.write_text(new_content, encoding="utf-8")


# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------

app = typer.Typer(no_args_is_help=True, add_completion=False, help=__doc__)


@app.command(name="generate", help="Generate a changelog entry from branch context.")
def generate(
    description: Annotated[list[str] | None, typer.Argument(help="Description override")] = None,
    write: Annotated[
        bool, typer.Option("--write/--no-write", help="Write the file to disk if it does not exist")
    ] = True,
    type_: Annotated[str, typer.Option("--type", help="Change type override (feat, fix, tech, ...)")] = "",
    as_json: Annotated[bool, typer.Option("--json", help="Emit JSON output instead of human-readable text")] = False,
) -> None:
    desc = " ".join(description) if description else ""
    _generate(desc, write, type_, as_json)


def _validate_files(files: list[Path], fix: bool) -> tuple[list[_ValidationFailure], int, int]:
    """Validate a list of changelog files. Returns (failures, fixed, total)."""
    failures: list[_ValidationFailure] = []
    fixed = 0

    for file in files:
        if not file.exists():
            failures.append(_ValidationFailure(file, "file not found", ""))
            continue
        content = file.read_text(encoding="utf-8")
        first = _first_bullet(content)
        if first is None:
            failures.append(_ValidationFailure(file, "empty file", ""))
            continue
        line, idx = first

        body = _strip_bullet(line)
        if body is None:
            if fix:
                fixed_line = _try_fix(line, file.name)
                if fixed_line and (b := _strip_bullet(fixed_line)) and _validate_body(b):
                    _rewrite_line(file, content, idx, fixed_line)
                    fixed += 1
                    continue
            failures.append(_ValidationFailure(file, "missing '* ' bullet", line))
            continue

        if _validate_body(body):
            continue

        if fix:
            fixed_line = _try_fix(line, file.name)
            if fixed_line and (b := _strip_bullet(fixed_line)) and _validate_body(b):
                _rewrite_line(file, content, idx, fixed_line)
                fixed += 1
                continue

        failures.append(_ValidationFailure(file, "does not match conventional commits", line))

    return failures, fixed, len(files)


# ---------------------------------------------------------------------------
# Release — merge changelogs/*.md into CHANGELOG.md
# ---------------------------------------------------------------------------

_CHANGELOG_HEADER = """# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
"""

_UNRELEASED_RE = re.compile(r"^##\s*\[?Unreleased\]?\s*$", re.MULTILINE)


def _collect_entries(changelogs_dir: Path) -> str:
    """Concatenate all ``*.md`` files in ``changelogs_dir`` (sorted), normalizing bullets."""
    if not changelogs_dir.is_dir():
        return ""
    parts: list[str] = []
    for path in sorted(changelogs_dir.glob("*.md")):
        text = path.read_text(encoding="utf-8").rstrip("\n")
        if text:
            parts.append(text)
    body = "\n".join(parts)
    # Normalize "- " bullets to "* "
    body = re.sub(r"^-\s", "* ", body, flags=re.MULTILINE)
    return body


def _build_section(tag: str, body: str, today: str) -> str:
    """Build a ``## [tag] YYYY-MM-DD`` section. ``body`` may be empty."""
    section = f"## [{tag}] {today}"
    if body:
        section += "\n\n" + body
    return section


_RELEASE_HEADING_RE = re.compile(r"^##\s", re.MULTILINE)


def _strip_unreleased(content: str) -> str:
    """Remove any ``## Unreleased`` / ``## [Unreleased]`` heading and its (empty) body."""
    match = _UNRELEASED_RE.search(content)
    if not match:
        return content
    start = match.start()
    # Find the next ## heading after Unreleased — that's where Unreleased's body ends.
    next_match = _RELEASE_HEADING_RE.search(content, match.end())
    end = next_match.start() if next_match else len(content)
    return content[:start] + content[end:]


def merge_changelog(existing: str, section: str) -> str:
    """Merge a new release ``section`` into ``existing`` CHANGELOG.md content.

    - If ``existing`` is empty (or has no ``# Changelog`` top-level header), the
      standard header is prepended.
    - Any existing ``## Unreleased`` / ``## [Unreleased]`` block is removed.
    - The new release section is inserted right after the top-level header,
      before the first ``##`` heading.

    A blank line is guaranteed before every ``##`` heading (Keep a Changelog style).
    """
    content = _strip_unreleased(existing) if existing.strip() else ""

    # Ensure the top-level ``# Changelog`` header is present.
    has_top_header = bool(re.search(r"^#\s+\S", content, re.MULTILINE))
    if not has_top_header:
        content = _CHANGELOG_HEADER + (content.lstrip("\n") if content else "")

    if not content.endswith("\n"):
        content += "\n"

    # Insert point: right before the first ``## `` heading, else at end of file.
    match = _RELEASE_HEADING_RE.search(content)
    if match:
        prefix = content[: match.start()].rstrip("\n") + "\n\n"
        suffix = content[match.start() :]
    else:
        prefix = content.rstrip("\n") + "\n\n"
        suffix = ""

    block = section.rstrip("\n") + "\n"
    if suffix:
        block += "\n"
    return prefix + block + suffix


def release(
    tag: str,
    repo_root: Path,
    today: str | None = None,
) -> tuple[str, list[Path]]:
    """Merge ``changelogs/*.md`` into ``CHANGELOG.md`` under a new release tag.

    Returns ``(new_content, consumed_files)``. The caller decides whether to
    write the result and delete the consumed files (the CLI does both).
    """
    if not re.match(r"^v\d+\.\d+\.\d+$", tag):
        raise ValueError(f"Invalid tag: {tag}. It must start with 'v' and be valid semver")

    changelogs_dir = repo_root / "changelogs"
    changelog_file = repo_root / "CHANGELOG.md"
    today = today or date.today().isoformat()

    body = _collect_entries(changelogs_dir)
    section = _build_section(tag, body, today)

    existing = changelog_file.read_text(encoding="utf-8") if changelog_file.exists() else ""
    new_content = merge_changelog(existing, section)

    consumed = sorted(changelogs_dir.glob("*.md")) if changelogs_dir.is_dir() else []
    return new_content, consumed


@app.command(name="release", help="Merge changelogs/*.md into CHANGELOG.md for a new release tag.")
def release_command(
    tag: Annotated[str, typer.Argument(help="Release tag (vMAJOR.MINOR.PATCH)")],
    root: Annotated[
        Path,
        typer.Option("--root", help="Project root (defaults to current directory)"),
    ] = Path("."),
    keep_entries: Annotated[
        bool,
        typer.Option("--keep-entries", help="Do not delete files under changelogs/ after merging"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Print the resulting CHANGELOG.md to stdout and do not write anything"),
    ] = False,
) -> None:
    try:
        new_content, consumed = release(tag=tag, repo_root=root)
    except ValueError as exc:
        typer.secho(f"✗ {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1) from exc

    if dry_run:
        sys.stdout.write(new_content)
        return

    (root / "CHANGELOG.md").write_text(new_content, encoding="utf-8")
    if not keep_entries:
        for path in consumed:
            path.unlink()

    typer.secho(
        f"✓ CHANGELOG.md updated with {tag} ({len(consumed)} entrie(s) merged)",
        fg=typer.colors.GREEN,
    )


@app.command(name="validate", help="Validate changelog files (strict conventional commits).")
def validate(
    files: Annotated[
        list[Path] | None,
        typer.Argument(help="Changelog files or directory (default: changelogs/)"),
    ] = None,
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix non-conforming entries when possible")] = False,
) -> None:
    # Resolve file list: explicit files, directory, or default
    if files:
        resolved: list[Path] = []
        for f in files:
            if f.is_dir():
                resolved.extend(sorted(f.glob("*.md")))
            elif f.suffix == ".md":
                resolved.append(f)
        if not resolved:
            typer.secho("No .md files found in arguments", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1)
    else:
        path = Path("changelogs")
        if not path.exists() or not path.is_dir():
            typer.secho(f"Directory not found: {path}", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1)
        resolved = sorted(path.glob("*.md"))

    failures, fixed, total = _validate_files(resolved, fix)

    for fail in failures:
        typer.secho(f"✗ {fail.file}: {fail.reason}", fg=typer.colors.RED, err=True)
        if fail.line:
            typer.echo(f"  → {fail.line}", err=True)

    if failures:
        suffix = f" — {fixed} auto-fixed" if fixed else ""
        typer.secho(
            f"\n{len(failures)} invalid file(s) over {total}{suffix}",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=1)

    if fixed:
        typer.secho(
            f"✎ {fixed} fixed changelog file(s) (now valid)",
            fg=typer.colors.YELLOW,
        )
        remaining = total - fixed
        if remaining > 0:
            typer.secho(
                f"✓ {remaining} valid changelog file(s)",
                fg=typer.colors.GREEN,
            )
        raise typer.Exit(code=1)

    typer.secho(f"✓ {total} valid changelog file(s)", fg=typer.colors.GREEN)
