"""Resolve env vars via MCP config or AWS Secrets Manager.

Exposed as ``pysae-ai-tools env resolve``. Values are produced by trying, in
order: the current process environment, then the auto-strategies declared in
:mod:`pysae_ai_tools.env.config` (shell command → MCP config).
"""

import contextlib
import io
import json
import os
import subprocess
import sys
import threading
from collections.abc import Iterator
from typing import Annotated

import typer

from . import cache
from .config import (
    ENV_CONFIG,
    AwsConfigResolver,
    CommandResolver,
    LiteralResolver,
    ManualResolver,
    McpResolver,
    Resolver,
    get_manual_instructions,
)

_SILENT_TRACE = False
"""When True, resolver progress lines are suppressed.

The ``env resolve --set`` flow flips this on because its stdout must contain
only shell-syntax assignment lines.
"""


@contextlib.contextmanager
def _silence_trace() -> Iterator[None]:
    """Suppress resolver progress lines for the duration of the ``with`` block."""
    global _SILENT_TRACE
    previous = _SILENT_TRACE
    _SILENT_TRACE = True
    try:
        yield
    finally:
        _SILENT_TRACE = previous


def _trace(line: str, *, color: str | None = None) -> None:
    """Print a resolver progress line on stdout (unless suppressed).

    Trace lives on stdout — same stream as the resolved value. The
    ``--set`` mode silences it entirely (``_SILENT_TRACE``) so that
    ``eval "$(pysae-ai-tools env resolve --set VAR)"`` only sees the
    shell-syntax assignment lines.
    """
    if _SILENT_TRACE:
        return
    if color is None:
        typer.echo(line)
    else:
        typer.secho(line, fg=color)
    sys.stdout.flush()


def _is_tty() -> bool:
    """True when stdout is an interactive terminal (where the trace lives)."""
    try:
        return sys.stdout.isatty()
    except (AttributeError, ValueError):
        return False


def _trace_header(var: str) -> None:
    """Print the var name as a heading before its resolver attempts.

    A blank line precedes the heading so each variable's block is visually
    separated from the previous one in the upfront install section.
    """
    _trace("")
    _trace(f"  ${var}", color=typer.colors.CYAN)


_SPINNER_FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")
_SPINNER_INTERVAL_S = 0.08


class _Spinner:
    """Background thread that redraws a braille-spinner frame next to a label.

    Single-line redraw via ``\\r`` + ``\\033[2K`` (erase to end of line); the
    main thread is expected to call :meth:`stop` before printing the final
    outcome on the same line.
    """

    def __init__(self, label: str) -> None:
        self.label = label
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        i = 0
        while not self._stop.is_set():
            frame = _SPINNER_FRAMES[i % len(_SPINNER_FRAMES)]
            sys.stdout.write("\r\033[2K")
            typer.secho(f"    {frame} {self.label}", fg=typer.colors.YELLOW, nl=False)
            sys.stdout.flush()
            i += 1
            self._stop.wait(_SPINNER_INTERVAL_S)

    def stop(self) -> None:
        if self._thread is not None:
            self._stop.set()
            self._thread.join()
            self._thread = None


_active_spinner: _Spinner | None = None


def _trace_pending(label: str) -> None:
    """Start a spinner next to ``label`` (or print a static placeholder when
    we don't have a TTY). The spinner is stopped — and its line cleared — by
    the next :func:`_trace_success` / :func:`_report_failure` call.
    """
    global _active_spinner
    if _SILENT_TRACE:
        return
    if _is_tty():
        _active_spinner = _Spinner(label)
        _active_spinner.start()
    else:
        typer.secho(f"    ⏳ {label}", fg=typer.colors.YELLOW)


def _clear_pending_line() -> None:
    """Stop the active spinner and erase its line so the final outcome can be printed."""
    global _active_spinner
    if _SILENT_TRACE:
        return
    if _active_spinner is not None:
        _active_spinner.stop()
        _active_spinner = None
    if _is_tty():
        sys.stdout.write("\r\033[2K")
        sys.stdout.flush()


def _trace_success(label: str) -> None:
    """Print an indented success line under a previously printed header."""
    _clear_pending_line()
    _trace(f"    ✓ {label}", color=typer.colors.GREEN)


def _report_failure(label: str, reason: str) -> None:
    """Print a short indented failure line under the var header."""
    _clear_pending_line()
    _trace(f"    ✗ {label} failed — {reason}", color=typer.colors.BRIGHT_BLACK)


def _run_command_resolver(resolver: CommandResolver, var: str) -> str | None:
    """Run a :class:`CommandResolver` and return the value on success.

    Dependencies listed in ``resolver.depends_on`` are resolved first (and
    injected into :data:`os.environ`), so the subprocess inherits them.
    """
    for dep in resolver.depends_on:
        if not os.environ.get(dep):
            try_auto_resolve(dep)

    label = resolver.label or "automatically"
    _trace_pending(label)
    try:
        result = subprocess.run(
            resolver.command.split(),
            capture_output=True,
            text=True,
            timeout=resolver.timeout,
        )
    except subprocess.TimeoutExpired:
        _report_failure(label, f"timed out after {resolver.timeout}s")
        return None
    except FileNotFoundError:
        _report_failure(label, f"command not found: {resolver.command.split()[0]}")
        return None
    if result.returncode != 0:
        stderr = result.stderr.strip().splitlines()
        detail = stderr[-1] if stderr else f"exit code {result.returncode}"
        _report_failure(label, detail)
        return None
    if not result.stdout.strip():
        _report_failure(label, "empty output")
        return None

    value = result.stdout.strip()
    os.environ[var] = value
    _trace_success(label)
    return value


def _run_mcp_resolver(resolver: McpResolver, var: str) -> str | None:
    """Run an :class:`McpResolver` and return the value on success."""
    from ..install.common.mcp import get_server

    label = resolver.label or f"from MCP config ({resolver.server})"
    _trace_pending(label)
    try:
        srv = get_server(resolver.server)
    except (OSError, ValueError) as exc:
        _report_failure(label, f"could not read MCP config: {exc}")
        return None
    if not srv:
        _report_failure(label, f"MCP server '{resolver.server}' not configured")
        return None

    env = srv.get("env")
    if not isinstance(env, dict):
        _report_failure(label, f"MCP server '{resolver.server}' has no env section")
        return None
    raw = env.get(resolver.env_key)
    if not isinstance(raw, str) or not raw.strip():
        _report_failure(label, f"key '{resolver.env_key}' missing in MCP env")
        return None

    value = raw.strip()
    os.environ[var] = value
    _trace_success(label)
    return value


def _run_literal_resolver(resolver: LiteralResolver, var: str) -> str | None:
    """Always-succeeds resolver — sets ``var`` to ``resolver.value``."""
    label = resolver.label or f"default {resolver.value!r}"
    _trace_pending(label)
    os.environ[var] = resolver.value
    _trace_success(label)
    return resolver.value


def _run_aws_config_resolver(resolver: AwsConfigResolver, var: str) -> str | None:
    """Read ``aws configure get`` for ``aws_key`` against the default profile.

    On miss, optionally prompt the user (when stdin is a TTY) and persist
    the entered values via ``aws configure set`` so the next call hits
    the standard AWS files.
    """
    from . import aws

    label = resolver.label or "from AWS config (profil par défaut)"
    _trace_pending(label)

    value = aws.aws_configure_get(resolver.aws_key)
    if value:
        os.environ[var] = value
        _trace_success(label)
        return value

    _report_failure(label, "absent du fichier AWS")

    if resolver.interactive_prompt == "credentials" and aws.stdin_is_tty() and not _SILENT_TRACE:
        if aws.prompt_aws_credentials():
            # Re-read the requested field from the freshly written profile.
            entered = aws.aws_configure_get(resolver.aws_key)
            if entered:
                os.environ[var] = entered
                _trace_success("saisi par l'utilisateur, écrit dans ~/.aws/credentials")
                return entered

    return None


def _run_resolver(resolver: Resolver, var: str) -> str | None:
    """Dispatch to the right runner for the resolver kind.

    :class:`ManualResolver` never produces a value — its instructions are
    surfaced to the user elsewhere (CLI error message, interactive prompt).
    """
    match resolver:
        case CommandResolver():
            return _run_command_resolver(resolver, var)
        case McpResolver():
            return _run_mcp_resolver(resolver, var)
        case LiteralResolver():
            return _run_literal_resolver(resolver, var)
        case AwsConfigResolver():
            return _run_aws_config_resolver(resolver, var)
        case ManualResolver():
            return None


def _resolver_label(resolver: Resolver) -> str:
    """Human label for a resolver — used by the skipped-fallback trace."""
    match resolver:
        case CommandResolver():
            return resolver.label or "automatically"
        case McpResolver():
            return resolver.label or f"from MCP config ({resolver.server})"
        case LiteralResolver():
            return resolver.label or f"default {resolver.value!r}"
        case AwsConfigResolver():
            return resolver.label or "from AWS config (profil par défaut)"
        case ManualResolver():
            return "saisie manuelle"


def _trace_skipped_fallback(resolver: Resolver) -> None:
    """Print a dim-grey line for an unused fallback resolver.

    Surfaces what the resolver chain *would* have tried next if the earlier
    resolver had failed — gives the user a complete picture of the chain
    without having to read ``env/config.py``.
    """
    if _SILENT_TRACE:
        return
    label = _resolver_label(resolver)
    typer.secho(f"    ↷ {label} (fallback non utilisé)", fg=typer.colors.BRIGHT_BLACK)
    sys.stdout.flush()


def try_auto_resolve(var: str, *, use_cache: bool = True) -> str | None:
    """Try each configured resolver in order — first non-empty value wins.

    When ``spec.cache`` is True and ``use_cache`` is True, the on-disk cache
    (``~/.config/ai-tools/env-cache.json``) is checked first, and a
    successful resolution is persisted back for the next call. For other
    vars, the cache is consulted only as a last-resort fallback after every
    resolver fails — this lets ``tools configure`` persist values the user
    typed manually without hiding upstream rotations from auto-resolution.
    """
    spec = ENV_CONFIG.get(var)
    if spec is None:
        return None

    _trace_header(var)

    if spec.cache and use_cache:
        if (cached := cache.read(var)) is not None:
            os.environ[var] = cached
            _trace_success("from cache")
            for unused in spec.resolvers:
                _trace_skipped_fallback(unused)
            return cached

    for idx, resolver in enumerate(spec.resolvers):
        if (value := _run_resolver(resolver, var)) is not None:
            if spec.cache:
                cache.write(var, value)
            for unused in spec.resolvers[idx + 1 :]:
                _trace_skipped_fallback(unused)
            return value

    if use_cache and not spec.cache:
        if (cached := cache.read(var)) is not None:
            os.environ[var] = cached
            _trace_success("from cache")
            return cached
    return None


def _all_known_env_vars() -> list[str]:
    """Collect the unique env vars declared by any install tool, in tier order."""
    from ..install.all import TOOLS

    seen: list[str] = []
    for tool in TOOLS:
        for var in tool.env_vars:
            if var not in seen:
                seen.append(var)
    return seen


_VALID_SHELLS = ("posix", "powershell", "cmd")


def _detect_shell() -> str:
    """Best-effort detection of the invoking shell.

    Non-Windows → posix. Windows → posix if SHELL is set (Git Bash / MSYS2 /
    Cygwin / WSL), else powershell if PSModulePath is set, else cmd.
    """
    if sys.platform != "win32":
        return "posix"
    if os.environ.get("SHELL"):
        return "posix"
    if os.environ.get("PSModulePath"):
        return "powershell"
    return "cmd"


def _format_set_line(shell: str, name: str, value: str) -> str:
    """Format a single variable assignment for the given shell."""
    import shlex

    if shell == "posix":
        return f"export {name}={shlex.quote(value)}"
    if shell == "powershell":
        escaped = value.replace("'", "''")
        return f"$env:{name} = '{escaped}'"
    if shell == "cmd":
        escaped = value.replace("%", "%%").replace('"', '""')
        return f'set "{name}={escaped}"'
    raise ValueError(f"unknown shell: {shell}")


def _set_mode_hint(shell: str) -> str:
    """Shell-compatible comment telling the user how to consume the output."""
    if shell == "posix":
        return '# Pipe into `eval "$(…)"` to apply the exports in your shell.'
    if shell == "powershell":
        return "# Pipe into `Invoke-Expression` (alias `iex`) to apply: `… | iex`."
    if shell == "cmd":
        return ":: Consume via `for /f \"delims=\" %i in ('…') do @%i` to apply."
    raise ValueError(f"unknown shell: {shell}")


def resolve(
    vars: Annotated[
        list[str] | None,
        typer.Argument(
            help=(
                "Env var name(s) to resolve. Supports aliasing via "
                "`OUT=SRC` — e.g. `DATADOG_API_KEY=DD_API_KEY` resolves "
                "DD_API_KEY and emits it under DATADOG_API_KEY."
            ),
        ),
    ] = None,
    all_vars: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Resolve every env var declared by any tool. Best-effort — unresolved vars are silently skipped.",
        ),
    ] = False,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output: {VAR: value, …}")] = False,
    set_mode: Annotated[
        bool,
        typer.Option(
            "--set",
            help=(
                "Emit shell-compatible assignment lines (auto-detected). Safe for "
                '`eval "$(…)"` (posix), `| Invoke-Expression` (powershell), or '
                "`for /f` loops (cmd). Combine with `--shell` to override the format."
            ),
        ),
    ] = False,
    shell: Annotated[
        str | None,
        typer.Option(
            "--shell",
            help="Force the output shell format: `posix`, `powershell`, or `cmd`. Implies `--set`.",
        ),
    ] = None,
    no_cache: Annotated[
        bool,
        typer.Option(
            "--no-cache",
            help="Bypass the on-disk cache — force the resolver chain to run and overwrite any cached value.",
        ),
    ] = False,
    clear_cache: Annotated[
        bool,
        typer.Option(
            "--clear-cache",
            help="Clear cached entries (for the listed VARs, or all when combined with `--all`) and exit.",
        ),
    ] = False,
) -> None:
    """Resolve env vars via MCP config or AWS Secrets Manager.

    Tries the configured auto-resolve strategies (shell / MCP config) for each
    variable. Values already present in the environment are kept as-is.

    Without `--all`, every named variable must resolve (exits 1 otherwise).
    With `--all`, the command is best-effort: unresolved vars are skipped.
    """
    emit_set_lines = set_mode or shell is not None

    if json_output and emit_set_lines:
        typer.echo("--json and --set/--shell are mutually exclusive", err=True)
        raise typer.Exit(code=2)

    if shell is not None and shell not in _VALID_SHELLS:
        typer.echo(
            f"--shell: invalid value {shell!r} (expected posix|powershell|cmd)",
            err=True,
        )
        raise typer.Exit(code=2)

    resolved_shell = shell or (_detect_shell() if emit_set_lines else None)

    if clear_cache:
        if all_vars and not vars:
            cache.clear(None)
            typer.echo("cache cleared", err=True)
            return
        if not vars:
            typer.echo("usage: --clear-cache <VAR>... | --clear-cache --all", err=True)
            raise typer.Exit(code=2)
        for spec in vars:
            target, _, _ = spec.partition("=")
            cache.clear(target)
        typer.echo(f"cache cleared for: {', '.join(v.partition('=')[0] for v in vars)}", err=True)
        return

    if all_vars:
        if vars:
            typer.echo("--all cannot be combined with positional var names", err=True)
            raise typer.Exit(code=2)
        specs = _all_known_env_vars()
    else:
        if not vars:
            typer.echo("usage: resolve <VAR>... | --all", err=True)
            raise typer.Exit(code=2)
        specs = vars

    # Parse each spec into (output_name, source_name). Plain "VAR" → both equal.
    pairs: list[tuple[str, str]] = []
    for spec in specs:
        out, sep, src = spec.partition("=")
        pairs.append((out, src if sep else out))

    # ``--set`` / ``--shell`` and ``--json`` both require pristine stdout
    # (shell-syntax assignments or a JSON payload), so the resolver's trace
    # lines are suppressed entirely. In ``--set`` mode we additionally
    # redirect stderr → /dev/null so the "Could not resolve" message does
    # not leak into ``eval`` output; ``--json`` keeps stderr free for
    # human-readable failure messages.
    quiet_stdout = emit_set_lines or json_output
    silence: contextlib.AbstractContextManager[object] = _silence_trace() if quiet_stdout else contextlib.nullcontext()
    err_silence: contextlib.AbstractContextManager[object] = (
        contextlib.redirect_stderr(io.StringIO()) if emit_set_lines else contextlib.nullcontext()
    )

    resolved: dict[str, str] = {}
    missing: list[str] = []
    with silence, err_silence:
        for out, src in pairs:
            value = os.environ.get(src) or try_auto_resolve(src, use_cache=not no_cache)
            if value:
                resolved[out] = value
            elif not all_vars:
                missing.append(src)

        if missing:
            typer.echo(f"Could not resolve: {', '.join(missing)}", err=True)
            for var_name in missing:
                if hint := get_manual_instructions(var_name):
                    typer.echo(f"  {var_name}: {hint}", err=True)
            raise typer.Exit(code=1)

    # Preserve request order; in --all mode, drop unresolved entries silently.
    emit = [(out, resolved[out]) for out, _ in pairs if out in resolved]

    if json_output:
        typer.echo(json.dumps(dict(emit)))
    elif resolved_shell is not None:
        typer.echo(_set_mode_hint(resolved_shell))
        for out, value in emit:
            typer.echo(_format_set_line(resolved_shell, out, value))
    else:
        for _, value in emit:
            typer.echo(value)


if __name__ == "__main__":
    _app = typer.Typer(add_completion=False)
    _app.command()(resolve)
    _app()
