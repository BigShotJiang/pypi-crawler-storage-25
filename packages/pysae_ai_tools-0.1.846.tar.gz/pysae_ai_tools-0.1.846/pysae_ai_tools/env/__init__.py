"""Environment variable and secret management.

Exposes two CLI surfaces under ``pysae-ai-tools env``:

- ``env resolve`` — resolve env vars from shell auto-commands or MCP config
- ``env secret`` — read/write secrets in AWS Secrets Manager
"""
