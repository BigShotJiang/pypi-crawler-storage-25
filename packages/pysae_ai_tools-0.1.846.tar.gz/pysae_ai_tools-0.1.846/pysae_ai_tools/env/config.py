"""Centralised description and resolver chains for known env vars.

Each entry declares an ordered list of :class:`Resolver` strategies that
``pysae-ai-tools env resolve`` will try to obtain a value when the variable
is missing from the current environment. Resolvers are tried in order; the
first one producing a non-empty value wins.

Resolver kinds:

- :class:`CommandResolver` — runs a shell command (timeout 15s) whose stdout
  becomes the value. Typical use: ``pysae-ai-tools env secret get …`` to pull
  from AWS Secrets Manager.
- :class:`McpResolver` — reads ``~/.claude.json`` →
  ``mcpServers[server].env[env_key]``. Useful when the value was previously
  stored there by ``tools install``.
- :class:`ManualResolver` — terminal fallback that never produces a value. Its
  ``instructions`` string is shown to the user when every automatic resolver
  has failed (and by interactive prompts as a hint). Place it last.

Each :class:`CommandResolver` / :class:`McpResolver` carries its own
``label`` (shown in the "✓ $VAR resolved …" notice). For
:class:`McpResolver`, an empty label is auto-generated as
``"from MCP config ({server})"``.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class CommandResolver:
    """Shell command resolver — stdout becomes the value.

    ``timeout`` overrides the default 15 s wait when the command is expected
    to take longer (e.g. interactive OAuth flows).

    ``depends_on`` lists env vars that must be resolved before the command
    runs. Each dependency is looked up through :func:`try_auto_resolve` and
    injected into the subprocess environment via ``os.environ``.
    """

    command: str
    label: str
    timeout: int = 15
    depends_on: tuple[str, ...] = ()


@dataclass(frozen=True)
class McpResolver:
    """MCP-config resolver — reads a key from ``~/.claude.json``."""

    server: str
    env_key: str
    label: str = ""  # "from MCP config ({server})" when empty


@dataclass(frozen=True)
class ManualResolver:
    """Terminal resolver — informational only, surfaces manual instructions."""

    instructions: str


@dataclass(frozen=True)
class LiteralResolver:
    """Static-value resolver — always returns ``value``.

    Useful for sensible defaults (e.g. ``AWS_PROFILE=pysae``) so the rest
    of the chain can rely on the variable being set.
    """

    value: str
    label: str = ""  # auto-generated as ``default '{value}'`` when empty


@dataclass(frozen=True)
class AwsConfigResolver:
    """Read AWS CLI config (``~/.aws/credentials`` / ``~/.aws/config``).

    Reads ``aws configure get <aws_key>`` against the user's default profile
    (this tool does not manage ``AWS_PROFILE``). When ``interactive_prompt``
    is set and stdin is a TTY, the resolver prompts the user on a miss and
    persists the entered values via ``aws configure set`` so the next call
    hits the standard AWS files.
    """

    aws_key: str  # field in AWS files (e.g. "aws_access_key_id")
    interactive_prompt: str = ""  # "" | "credentials"
    label: str = ""


Resolver = CommandResolver | McpResolver | ManualResolver | LiteralResolver | AwsConfigResolver


# Slack user-token scopes requested via the OAuth v2 flow — see the
# ``SLACK_USER_TOKEN`` resolver below. Kept as a tuple so the source of
# truth is a real Python list, not a stringly-typed sub-argument of a
# shell command.
SLACK_USER_SCOPES: tuple[str, ...] = (
    "channels:history",
    "groups:history",
    "im:history",
    "mpim:history",
    "chat:write",
    "users:read",
    "users:read.email",
)


@dataclass(frozen=True)
class EnvVarSpec:
    """Human description + ordered resolver chain for an env var.

    When ``cache=True``, a successful resolution is persisted to
    ``~/.config/pysae-ai-tools/env-cache.json`` (0600 perms) and read back
    on subsequent calls, skipping the resolver chain. Opt-in only — reserve
    for values that are expensive to re-obtain and whose source of truth
    is not already on disk (e.g. interactive OAuth tokens). Never enable
    caching for values that can be rotated upstream (AWS secrets, MCP
    config) — you'd hide the rotation from the caller.
    """

    description: str
    resolvers: tuple[Resolver, ...] = ()
    cache: bool = False


ENV_CONFIG: dict[str, EnvVarSpec] = {
    "AWS_DEFAULT_REGION": EnvVarSpec(
        description="Région AWS (lue dans ~/.aws/config, défaut Pysae : eu-west-3)",
        resolvers=(
            AwsConfigResolver(aws_key="region", label="from ~/.aws/config"),
            LiteralResolver(value="eu-west-3", label="default 'eu-west-3' (Paris)"),
        ),
    ),
    "AWS_ACCESS_KEY_ID": EnvVarSpec(
        description="AWS Access Key ID (lu / écrit dans ~/.aws/credentials)",
        resolvers=(
            AwsConfigResolver(
                aws_key="aws_access_key_id",
                interactive_prompt="credentials",
                label="from ~/.aws/credentials",
            ),
            ManualResolver(
                instructions=(
                    "Configure d'abord avec `aws configure` "
                    "(ou `pysae-ai-tools env resolve AWS_ACCESS_KEY_ID` en interactif)."
                ),
            ),
        ),
    ),
    "AWS_SECRET_ACCESS_KEY": EnvVarSpec(
        description="AWS Secret Access Key (lu / écrit dans ~/.aws/credentials)",
        resolvers=(
            AwsConfigResolver(
                aws_key="aws_secret_access_key",
                interactive_prompt="credentials",
                label="from ~/.aws/credentials",
            ),
            ManualResolver(
                instructions=(
                    "Configure d'abord avec `aws configure` "
                    "(ou `pysae-ai-tools env resolve AWS_ACCESS_KEY_ID` en interactif "
                    "— la commande prompt à la fois la clé et le secret)."
                ),
            ),
        ),
    ),
    "DD_API_KEY": EnvVarSpec(
        description="Datadog API Key",
        resolvers=(
            McpResolver(server="datadog", env_key="DD_API_KEY"),
            ManualResolver(instructions="Datadog → Organization Settings → API Keys → New Key"),
        ),
    ),
    "DD_APP_KEY": EnvVarSpec(
        description="Datadog Application Key",
        resolvers=(
            McpResolver(server="datadog", env_key="DD_APP_KEY"),
            ManualResolver(instructions="Datadog → Organization Settings → Application Keys → New Key"),
        ),
    ),
    "GITLAB_PERSONAL_ACCESS_TOKEN": EnvVarSpec(
        description="GitLab Personal Access Token",
        resolvers=(
            CommandResolver(
                command="glab config get token --host gitlab.com",
                label="from glab CLI",
                timeout=10,
            ),
            ManualResolver(
                instructions=(
                    "run `glab auth login --hostname gitlab.com` first "
                    "(or GitLab → Preferences → Access Tokens → New Token with api scope)"
                ),
            ),
        ),
    ),
    "POSTMAN_API_KEY": EnvVarSpec(
        description="Postman API Key",
        resolvers=(
            McpResolver(server="postman", env_key="POSTMAN_API_KEY"),
            ManualResolver(instructions="Postman → Settings → API Keys → Generate API Key"),
        ),
    ),
    "MONGO_URI_DEV": EnvVarSpec(
        description="URI de connexion à MongoDB (dev)",
        resolvers=(
            CommandResolver(
                command="pysae-ai-tools env secret get pysae/local-dev/secrets api-mongo-uri --show-value",
                label="from AWS Secrets Manager (pysae/local-dev/secrets)",
            ),
            McpResolver(server="mongodb-dev", env_key="MDB_MCP_CONNECTION_STRING"),
        ),
    ),
    "MONGO_URI_PROD": EnvVarSpec(
        description="URI de connexion à MongoDB (prod)",
        resolvers=(
            CommandResolver(
                command="pysae-ai-tools env secret get pysae/local-prod/secrets api-mongo-uri --show-value",
                label="from AWS Secrets Manager (pysae/local-prod/secrets)",
            ),
            McpResolver(server="mongodb-prod", env_key="MDB_MCP_CONNECTION_STRING"),
        ),
    ),
    "ARGOCD_DEV_TOKEN": EnvVarSpec(
        description="Token argocd (dev)",
        resolvers=(
            CommandResolver(
                command="pysae-ai-tools env secret get ai-tools/dev/secrets argocd-ai-tools-ci-token --show-value",
                label="from AWS Secrets Manager (ai-tools/dev/secrets)",
            ),
            ManualResolver(
                instructions=(
                    "Génère un token sur le serveur dev avec "
                    "`argocd account generate-token --account argocd-ai-tools-ci` "
                    "(le résultat sera mis en cache local — auto-réutilisé tant qu'AWS est inaccessible)."
                ),
            ),
        ),
    ),
    "ARGOCD_PROD_TOKEN": EnvVarSpec(
        description="Token argocd (prod)",
        resolvers=(
            CommandResolver(
                command="pysae-ai-tools env secret get ai-tools/prod/secrets argocd-ai-tools-ci-token --show-value",
                label="from AWS Secrets Manager (ai-tools/prod/secrets)",
            ),
            ManualResolver(
                instructions=(
                    "Génère un token sur le serveur prod avec "
                    "`argocd account generate-token --account argocd-ai-tools-ci` "
                    "(le résultat sera mis en cache local — auto-réutilisé tant qu'AWS est inaccessible)."
                ),
            ),
        ),
    ),
    "SLACK_USER_TOKEN": EnvVarSpec(
        description="Slack user token (OAuth v2, interactive browser flow)",
        resolvers=(
            CommandResolver(
                command=f"pysae-ai-tools slack get-token --user-only --user-scopes {','.join(SLACK_USER_SCOPES)}",
                label="from Slack OAuth (browser)",
                timeout=300,
                depends_on=("SLACK_CLIENT_ID", "SLACK_CLIENT_SECRET"),
            ),
        ),
        cache=True,
    ),
    "SLACK_BOT_TOKEN": EnvVarSpec(
        description="Slack Bot token",
        resolvers=(
            CommandResolver(
                command="pysae-ai-tools env secret get ai-tools/dev/secrets slack-app-token --show-value",
                label="from AWS Secrets Manager (ai-tools/dev/secrets)",
            ),
            CommandResolver(
                command="pysae-ai-tools slack get-token",
                label="from Slack OAuth (browser)",
                timeout=300,
                depends_on=("SLACK_CLIENT_ID", "SLACK_CLIENT_SECRET"),
            ),
            ManualResolver(
                instructions="https://api.slack.com/apps/A0B05GC22TS → OAuth & Permissions",
            ),
        ),
    ),
    "SLACK_CLIENT_ID": EnvVarSpec(
        description="Slack App Client ID",
        resolvers=(
            CommandResolver(
                command="pysae-ai-tools env secret get ai-tools/dev/secrets slack-client-id --show-value",
                label="from AWS Secrets Manager (ai-tools/dev/secrets)",
            ),
            ManualResolver(
                instructions="https://api.slack.com/apps/A0B05GC22TS → Basic Information → App Credentials",
            ),
        ),
    ),
    "SLACK_CLIENT_SECRET": EnvVarSpec(
        description="Slack App Client Secret",
        resolvers=(
            CommandResolver(
                command="pysae-ai-tools env secret get ai-tools/dev/secrets slack-client-secret --show-value",
                label="from AWS Secrets Manager (ai-tools/dev/secrets)",
            ),
            ManualResolver(
                instructions="https://api.slack.com/apps/A0B05GC22TS → Basic Information → App Credentials",
            ),
        ),
    ),
}


def get_manual_instructions(var: str) -> str | None:
    """Return the ManualResolver instructions for `var`, if any."""
    spec = ENV_CONFIG.get(var)
    if spec is None:
        return None
    for resolver in spec.resolvers:
        if isinstance(resolver, ManualResolver):
            return resolver.instructions
    return None
