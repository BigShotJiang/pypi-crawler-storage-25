"""Install the Chrome DevTools MCP server in ~/.claude.json."""

from typing import Any

from .common.base import McpTool


class ChromeMcpTool(McpTool):
    name = "chrome-mcp"
    server_name = "chrome-devtools"
    cli_help = "Install/configure the Chrome DevTools MCP server"

    def build_config(self) -> dict[str, Any]:
        return {
            "command": "npx",
            "args": ["@anthropic-ai/chrome-devtools-mcp@latest"],
        }


_tool = ChromeMcpTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
