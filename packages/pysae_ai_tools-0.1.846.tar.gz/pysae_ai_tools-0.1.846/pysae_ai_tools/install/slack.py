"""Synthetic Tool wrapper for Slack — no local install.

The Slack integration in this repo is a set of subcommands
(``pysae-ai-tools slack …``) that hit the Slack Web API directly from
our scripts. There is no MCP server to install and no binary to put on
PATH. This module exists solely so that ``tools configure`` and
``tools status`` surface the SLACK_* env vars those subcommands need.

``get_state`` reports the tool as already installed
(``needs_install=False``) so the meta-installer short-circuits to
``up-to-date``; ``do_install`` is a no-op safety net invoked only if
state reporting fails.
"""

from .common.base import InstallReport, ToolState


def get_state() -> ToolState:
    return ToolState(
        needs_install=False,
        needs_update=False,
        extra={"managed_by": "pysae-ai-tools slack subcommands (no install)"},
    )


def do_install() -> InstallReport:
    return InstallReport(
        action="noop",
        method="no install required",
        extra={"note": "Slack integration uses direct API calls from `pysae-ai-tools slack …`."},
    )
