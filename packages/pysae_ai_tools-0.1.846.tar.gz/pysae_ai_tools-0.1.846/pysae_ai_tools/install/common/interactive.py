"""Interactive env var prompting for install commands.

Env vars can be auto-resolved via shell commands (e.g. reading from AWS
Secrets Manager) or prompted interactively. Auto-resolution logic and
configuration live in :mod:`pysae_ai_tools.env`.
"""

import os

import typer

from ...env import cache
from ...env.config import ENV_CONFIG, get_manual_instructions
from ...env.resolve import try_auto_resolve


def prompt_env_var(var: str, tool_name: str = "", help_text: str = "", *, persist: bool = False) -> str | None:
    """Prompt the user for a missing env var. Returns the value or None if skipped.

    When ``persist`` is True, the value is written to the on-disk env cache
    so subsequent commands (including ``tools install``) can pick it up via
    :func:`pysae_ai_tools.env.resolve.try_auto_resolve`.
    """
    # AWS credentials are owned by ``AwsConfigResolver``: it prompts and
    # persists to ``~/.aws/credentials`` directly, bypassing the env-cache.
    # If we reach here, the resolver already ran (and either succeeded — in
    # which case ``os.environ[var]`` is set and the caller should not have
    # called us — or the user declined). Don't add a second prompt.
    if var in {"AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY"}:
        return None

    spec = ENV_CONFIG.get(var)
    resolved_help = help_text or (spec.description if spec else "")
    manual = get_manual_instructions(var)

    typer.echo("")
    typer.secho(f"  ${var} is required{f' for {tool_name}' if tool_name else ''}", fg=typer.colors.YELLOW)
    if resolved_help:
        typer.secho(f"  → {resolved_help}", fg=typer.colors.BRIGHT_BLACK)
    if manual:
        typer.secho(f"    {manual}", fg=typer.colors.BRIGHT_BLACK)

    value: str = typer.prompt(f"  ${var}", default="", show_default=False)
    if not value.strip():
        return None

    cleaned = value.strip()
    os.environ[var] = cleaned
    if persist:
        cache.write(var, cleaned)
    return cleaned


def ensure_env_vars(
    vars_required: tuple[str, ...],
    tool_name: str = "",
    env_help: dict[str, str] | None = None,
    interactive: bool = True,
) -> bool:
    """Resolve missing env vars: auto-resolve first, then prompt if interactive.

    Returns True if all vars are resolved.
    """
    for var in vars_required:
        if os.environ.get(var):
            continue

        # Try auto-resolve (works in both interactive and non-interactive mode)
        if try_auto_resolve(var) is not None:
            continue

        # Prompt only in interactive mode
        if interactive:
            help_text = (env_help or {}).get(var, "")
            if prompt_env_var(var, tool_name, help_text) is not None:
                continue

        typer.secho(f"  ✗ ${var} not set — {tool_name or 'tool'} will not be installed.", fg=typer.colors.RED)
        return False
    return True
