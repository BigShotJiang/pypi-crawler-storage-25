"""Helper for installing packages via winget on Windows.

The framework calls :func:`install` from ``BinaryTool.install_binary`` when the
tool defines ``winget_package``. Returns ``None`` on non-Windows systems or
when winget is not available — callers should then fall through to the OS
hook (``install_windows``).

A non-zero exit from winget surfaces as ``InstallReport(error=...)`` rather
than ``None``: when winget is present we treat its failure as the real error
instead of silently retrying another path.
"""

import shutil
import subprocess

from .base import InstallReport
from .platform import detect


def is_available() -> bool:
    """True when running on Windows and the ``winget`` binary is on PATH."""
    try:
        plat = detect()
    except ValueError:
        return False
    if not plat.is_windows:
        return False
    return shutil.which("winget") is not None


def install(package_id: str) -> InstallReport | None:
    """Install ``package_id`` via winget. Returns ``None`` if winget unusable.

    Always passes ``--silent``, ``--accept-package-agreements`` and
    ``--accept-source-agreements`` for non-interactive automation.
    """
    if not is_available():
        return None
    cmd = [
        "winget",
        "install",
        "--id",
        package_id,
        "-e",
        "--source",
        "winget",
        "--silent",
        "--accept-package-agreements",
        "--accept-source-agreements",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if r.returncode != 0:
        return InstallReport(error=f"winget: {r.stderr.strip() or r.stdout.strip()}")
    return InstallReport(method="winget")
