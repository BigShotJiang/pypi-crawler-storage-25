"""Install the MongoDB prod MCP server (read-only)."""

import os
from typing import Any

import typer

from .common import mcp
from .common.base import BaseTool, EnvVar, InstallReport, ToolState

SERVER_NAME = "mongodb-prod"


def _build(uri: str) -> dict[str, Any]:
    return {
        "type": "stdio",
        "command": "npx",
        "args": ["-y", "mongodb-mcp-server@latest", "--readOnly"],
        "env": {"MDB_MCP_CONNECTION_STRING": uri},
    }


class MongoMcpProdTool(BaseTool):
    name = "mongo-mcp-prod"
    cli_help = "Install/configure the MongoDB prod MCP server (read-only)"

    @property
    def env_vars(self) -> list[EnvVar]:
        return [EnvVar("MONGO_URI_PROD", help="MongoDB URI de prod")]

    def get_state(self) -> ToolState:
        srv = mcp.get_server(SERVER_NAME)
        if srv is None:
            return ToolState(
                needs_install=True,
                extra={SERVER_NAME: {"configured": False, "has_uri": False, "read_only": False}},
            )
        has_uri = bool((srv.get("env") or {}).get("MDB_MCP_CONNECTION_STRING"))
        read_only = "--readOnly" in (srv.get("args") or [])
        return ToolState(
            needs_install=not (has_uri and read_only),
            extra={SERVER_NAME: {"configured": True, "has_uri": has_uri, "read_only": read_only}},
        )

    def do_install(self) -> InstallReport:
        uri = os.environ.get("MONGO_URI_PROD", "").strip()
        if not uri:
            return InstallReport(error="MONGO_URI_PROD is required")
        changed = mcp.upsert_server(SERVER_NAME, _build(uri))
        return InstallReport(extra={SERVER_NAME: {"changed": changed}})

    def format_check(self, state: ToolState) -> None:
        info = state.extra.get(SERVER_NAME, {})
        if info.get("configured"):
            ro = " (readOnly)" if info.get("read_only") else ""
            typer.echo(f"{SERVER_NAME}: configured{ro}")
        else:
            typer.echo(f"{SERVER_NAME}: missing")

    def format_install(self, report: InstallReport) -> None:
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
            return
        info = report.extra.get(SERVER_NAME, {})
        typer.echo(f"{SERVER_NAME}: {'updated' if info.get('changed') else 'unchanged'} (--readOnly)")


_tool = MongoMcpProdTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
