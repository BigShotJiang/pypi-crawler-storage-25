---
name: support-product-ticket
description: "Create a product suggestion in the Notion Roadmap Suggestions database (which powers the Intercom Roadmap module). Use when the user says /support-product-ticket, shares an Intercom conversation containing a feature request, says 'ticket produit' or 'suggestion produit', or when a client request turns out to be a feature suggestion rather than a bug. Always checks for duplicates and waits for Patrick's validation before creating."
argument-hint: "[Intercom conversation URL or feature request description]"
allowed-tools:
  - Read
  - Bash
  - AskUserQuestion
---

Créer une suggestion produit dans la DB Notion **Roadmap Suggestions** — la même DB qui alimente le module Roadmap d'Intercom. Les suggestions arrivent via des conversations Intercom partagées par Patrick. Toujours vérifier les doublons avant de créer, toujours attendre la validation de Patrick.

**Prérequis** : MCP Notion + MCP Intercom configurés.

## Quand utiliser

- Patrick partage un **lien Intercom** avec une demande de feature
- Client demande « est-ce que c'est possible de... » ou similaire
- Patrick dit « ticket produit » ou « suggestion produit »
- Une investigation révèle une **capacité manquante** (pas un bug)

**Pas pour** :
- Bug → `/support-bug-investigate`
- Ticket support → `/support-ticket-create`
- Issue dev → `/glab-issue-create`

## Infos Notion

| Ressource | ID |
|---|---|
| Suggestions DB | `a127193468ce4da0900a8336828f4665` |
| Votes DB | `002ef76132b64184b0eea74487713b0e` |
| Vote API | `POST https://pysae-roadmap-intercom-patrick-lemos-caixas-projects.vercel.app/api/vote` |

Outils utilisés : MCP Notion `notion-create-pages`, `notion-search`.

## Workflow

### 1. Lire la conversation Intercom

Input : lien Intercom (ex : `https://app.intercom.com/a/inbox/ud2bnsix/inbox/admin/6831378/conversation/XXXXX`).

- Utiliser MCP Intercom `get_conversation` pour récupérer le contenu
- Extraire : **nom du client**, **email**, **organisation**, **la demande/suggestion**
- Reformuler en titre court et clair

### 2. Chercher les doublons

Query Notion sur la DB `a127193468ce4da0900a8336828f4665` avec des mots-clés du titre via `notion-search`.

**Si un match potentiel est trouvé → proposer à Patrick :**

> Cette suggestion ressemble à **{titre existant}** ({X} votes, statut {Y}). On rapproche ou on crée une nouvelle ?

**Attendre la réponse de Patrick.** Ne jamais rapprocher automatiquement.

### 3a. Si Patrick valide le rapprochement

1. **Upvote** la suggestion existante pour le client :
   ```
   POST /api/vote
   Body: { "suggestionId": "ID", "userEmail": "client@email.com", "userId": "", "action": "vote" }
   ```
2. **Commentaire Notion** sur la suggestion existante :
   ```
   🔗 Client X (Org Y) a aussi demandé ça le JJ/MM/YYYY — Intercom : [lien conversation]
   ```
3. Confirmer à Patrick : le client recevra les notifs de changement de statut automatiquement (puisqu'il devient votant).

### 3b. Si Patrick refuse le rapprochement ou pas de doublon

Créer via MCP Notion `notion-create-pages` dans la DB `a127193468ce4da0900a8336828f4665` :

| Champ | Type | Contenu |
|---|---|---|
| **Title** | title | Titre court, actionnable |
| **Description** | rich_text | Résumé concis de la demande client |
| **Status** | select | `En attente` (modération Lucas) |
| **Category** | select | `UX / Interface`, `Performance`, `Intégrations`, `GTFS / Transport`, `Driver`, `Autre` |
| **Author Email** | email | Email du client |
| **Author Name** | rich_text | Nom du client |
| **Votes Count** | number | `1` |
| **Created At** | date | Date du jour |

Puis :

1. **Commentaire Notion** : `"Origine : Intercom [lien] — Client X (Org Y) le JJ/MM/YYYY"`
2. Retourner le lien Notion à Patrick

> ⚠️ **Ne PAS appeler `/api/vote` après une création** — `createSuggestion()` fait déjà un auto-vote (Votes Count = 1 + record vote). L'appel `/api/vote` n'est nécessaire QUE pour l'étape 3a (rapprochement).

### 4. Pas d'investigation GitLab

Pour les suggestions Intercom, **pas de recherche code**. Le besoin client suffit. L'investigation technique, c'est le boulot de l'équipe produit après validation par Lucas.

## Catégories disponibles

`UX / Interface` — `Performance` — `Intégrations` — `GTFS / Transport` — `Driver` — `Autre`.

Si aucune ne convient, utiliser `Autre` et le mentionner à Patrick. On peut créer une nouvelle catégorie dans Notion si nécessaire.

## Checklist

- [ ] Conversation Intercom lue, infos client extraites
- [ ] Doublons vérifiés dans Notion
- [ ] Si doublon potentiel → Patrick a validé le rapprochement (ou refusé)
- [ ] Suggestion créée ou existante upvotée
- [ ] Commentaire Notion ajouté (origine + client + lien Intercom)
- [ ] Patrick informé du résultat

## Erreurs fréquentes

| Erreur | Correction |
|---|---|
| Rapprocher sans demander à Patrick | Toujours proposer, toujours attendre sa validation |
| Oublier l'auto-vote | Le vote lie le client aux notifications de statut |
| Oublier le commentaire Notion | Traçabilité = qui a demandé quoi, quand |
| Statut autre que « En attente » | C'est Lucas qui valide et change le statut |
| Faire une investigation GitLab | Pas nécessaire pour les suggestions Intercom |

$ARGUMENTS
