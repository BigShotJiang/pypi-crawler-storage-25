# Support — Vocabulaire métier ↔ technique

Table de correspondance entre les termes utilisés par le support client (Intercom, Airtable, CSM) et les concepts techniques dans le code Pysae. Utilisée par les skills `support-*` pour traduire une demande client vers du code à investiguer.

## Termes métier (FR) ↔ Technique

| Business (FR) | Technique | Localisation |
|---|---|---|
| Plan de Transport (PDT) | GTFS (ZIP) | `pysae/api` — `api/gtfs/` |
| Ligne | Route (routes.txt / gtfs_routes) | `api/gtfs/routes/` |
| Trace | Shape (shapes.txt / gtfs_shapes) | `api/gtfs/shapes/` |
| Trajet, Course | Trip (trips.txt / trips collection) | `api/gtfs/trips/`, `api/trips/` |
| Arrêt | Stop (stops.txt / gtfs_stops) | `api/gtfs/stops/` |
| Horaire | StopTime (stop_times.txt, embarqué dans trip) | `api/gtfs/stops/` |
| Vérification PAN | Validation via etalab/transport-validator | `api/gtfs/files/etalab/` |
| Publication | Activation du GTFS comme `current_file` du groupe | `api/gtfs/files/` |
| Éditeur | Interface web d'édition GTFS | `pysae/editor` |
| Service / Séquence | `block_id` GTFS | `api/gtfs/trips/` |
| Prise de service | `duty` | `api/duties/` |
| Tablette, appareil | `device` | `api/devices/` |
| Réseau | `group` | `api/groups/` |
| Conducteur | `driver` | `api/drivers/` |
| Supervision | Op / Bigmap | `pysae/op` + `pysae/bigmap` |
| Voyageurs (affichage) | Info / Screen / Display | `pysae/info` + `pysae/screen` |

## Sujet (Airtable) ↔ Repo GitLab

Mapping direct du champ **Sujet** des tickets Airtable vers le repo de destination d'une issue GitLab. Utilisé par `glab-issue-create --from-airtable` et `support-ticket-create`.

| Sujet | GitLab project | Project ID | Domaine |
|---|---|---|---|
| API | `pysae/api` | 14373578 | Backend |
| OP | `pysae/op` | 14366711 | Supervision |
| Driver | `pysae/driver` | 14372431 | Appli conducteur |
| Editor | `pysae/editor` | 14372325 | Éditeur GTFS |
| Screen | `pysae/screen` | 14373075 | Affichage voyageurs |
| Info | `pysae/info` | 10496885 | Information voyageurs |
| INFRA | `pysae/op` | 14366711 | (rattaché à Op par convention) |

Pour tout autre repo (pysae/pysae-common, pysae/gtfs-validator, etc.), voir [`pysae-projects.md`](pysae-projects.md).

## Criticité Airtable ↔ Label priority GitLab

Le projet Pysae n'a que 3 niveaux de priorité. Le CSM doit toujours aligner la priorité GitLab sur la criticité Airtable (source de vérité).

| Criticité Airtable | Label GitLab |
|---|---|
| 5 — Bloquante | `priority::P1` |
| 4 — Élevée | `priority::P1` |
| 3 — Moyenne | `priority::P2` |
| 2 — Mineure | `priority::P3` |
| 1 — Cosmétique | `priority::P3` |

## Chaîne de validation GTFS (PAN)

Flux à suivre quand un bug touche la validation d'un Plan de Transport :

1. `GtfsValidatorService.raise_if_invalid()` — `api/gtfs/files/services.py`
2. → `json_to_bytes()` — reconstruit le ZIP GTFS depuis MongoDB
3. → `validate_gtfs()`
   - Si `GTFS_VALIDATOR_DISABLED` → retourne `ValidationDisabled`
   - Sinon → `validate_standards()` : POST ZIP vers `{GTFS_VALIDATOR_URL}/validate` (service Rust)
   - + `validate_custom()` : checks Pysae (TripsWithoutShapes, TripsWithoutDistances)
4. → `get_validation_status()` — `api/gtfs/files/etalab/services.py` : `VALIDATED` ou `TO_FIX`
   - Bloque sur Error/Fatal + Warning pour `NegativeTravelTime` et `MissingCoordinates`

Service externe : `etalab/transport-validator` (Rust) — commit utilisé épinglé dans le repo `pysae/gtfs-validator`.

## Champs GTFS obligatoires (FAIL sans eux)

- `shape_dist_traveled` dans `stop_times.txt` — sinon `TripsWithoutDistances`
- `shape_id` sur chaque trip — sinon `TripsWithoutShapes`
- Les shapes doivent exister pour tous les `shape_id` référencés
