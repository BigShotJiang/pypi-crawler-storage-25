# Intercom — Conventions HTML

Conventions HTML à respecter **strictement** pour les articles Help Center et les annonces News publiés sur Intercom. Utilisé par `support-intercom-article` et `support-intercom-news`.

## Paramètres globaux

| Paramètre | Valeur |
|---|---|
| Author ID | `6831378` |
| Workspace | `ud2bnsix` |
| État initial | `draft` |

## Help Center (centre d'aide Pysae)

Articles **opérationnels**, mode d'emploi pas-à-pas. Publiés via MCP Intercom `create_article` puis enrichis en EN + IT via Composio `INTERCOM_UPDATE_AN_ARTICLE` (le MCP Intercom ne supporte pas `translated_content`).

### Balises HTML obligatoires

| Élément | HTML |
|---|---|
| Paragraphe | `<p class="no-margin">Texte</p>` |
| Paragraphe vide (espacement) | `<p class="no-margin"></p>\n` |
| Titre section | `<h1 id="h_identifiant">Titre</h1>` |
| Séparateur entre sections | `<hr>` |
| Élément UI (bouton, menu) | `"<b><i>Nom du bouton</i></b>"` (avec guillemets) |
| Image | `<div class="intercom-container"><img src="URL"></div>` |
| Placeholder image visible | `<p class="no-margin">🖼️ <i>[Insérer capture : description]</i></p>` |
| Ancre interne | `<a href="#h_identifiant" class="intercom-content-link">Texte</a>` |
| Lien externe | `<a href="URL" target="_blank" class="intercom-content-link">Texte</a>` |
| Liste | `<ul><li><p class="no-margin">Item</p></li></ul>` |
| Tip « Bon à savoir » | `<p class="no-margin">💡 <b>Bon à savoir :</b></p>` |

### Structure type

1. **Intro** (1-2 paragraphes expliquant la fonctionnalité), avec `<p class="no-margin"></p>` entre chaque paragraphe
2. **Sommaire** — `<ul>` directement après l'intro, **sans** titre H1 « Sommaire », chaque `<li>` est une ancre vers une section
3. `<hr>`
4. **Sections H1** (une par action/aspect) — `<h1>` suivi de `<p class="no-margin"></p>`, texte explicatif, placeholder image, sous-étapes
5. `<hr>` avant « Bon à savoir »
6. 💡 **Bon à savoir** — tips clés en gras dans une `<ul>`

### Règles de spacing

- Ajouter `<p class="no-margin"></p>\n` après chaque paragraphe, chaque `</ul>`, chaque `<h1>`, chaque placeholder image
- **Pas** d'espace vide juste avant un `<hr>` : le contenu colle directement au séparateur

### Ton

- Vouvoiement strict (jamais « tu »)
- Opérationnel, pas marketing, pas technique
- Phrases courtes, vocabulaire accessible
- Terminologie métier Pysae (course, conducteur, plan de transport — pas trip, chauffeur, GTFS)

### Collections connues

| Collection | `parent_id` | Exemples |
|---|---|---|
| Espace Exploitation | `2719835` | Vue Course, Déviations |
| Rapports | `2719838` | Ponctualité, Kilométrage |
| Configuration | `2719839` | Gestion des équipes |

## News (Actualités Intercom)

Annonces **courtes, engageantes, benefit-focused**. Pas d'API — Patrick copie-colle le HTML dans l'éditeur Intercom News. On produit donc un fichier HTML autonome prévisualisable dans un navigateur.

### Structure

1. **Titre** — benefit-focused, < 60 caractères
2. **Accroche** (2-3 phrases) — le problème/besoin → ce qui a changé
3. **Ce qui change** (bullets) — bénéfices concrets en langage utilisateur
4. **Star feature** (si applicable) — la nouveauté principale avec plus de détails
5. **Comment y accéder** — 1-2 lignes, chemin dans l'interface
6. **Upsell** (si option payante) — encadré discret « Contactez-nous »
7. **CTA principal** — « Rendez-vous dans votre espace Op pour découvrir... »

Longueur cible : **200-300 mots max** dans le corps.

### Ton

- Vouvoiement strict
- Professionnel + chaleureux + enthousiaste, fier sans être vendeur
- Benefit-focused — bénéfice utilisateur, pas prouesse technique
- Accentuation française systématique (é, è, ê, à, ç, ainsi que É, À, Ç)
- Jamais de prix — seulement « contactez-nous »

### Vocabulaire métier (traductions obligatoires)

| Terme technique | Terme client |
|---|---|
| `block_id` | service, séquence |
| `trip` | course |
| `GTFS` | plan de transport |
| `feature flag` | ne pas mentionner |
| `inline labels` | le nom de la course s'affiche directement sur le bloc |
| `duty` | prise de service |
| `device` | tablette, appareil |
| `endpoint`, `API`, `merge request` | ne pas mentionner |
| `Op` | votre espace Op, votre plateforme |
| `group` | votre réseau |

### Visuels

- 2-4 screenshots avec descriptions précises
- Cover image : **900x504 px minimum**
- Toujours sur **réseau démo** — jamais de données client réelles
- Privilégier les avant/après quand c'est pertinent
- Marquer les emplacements avec `<div class="image-placeholder">…</div>` visibles

### Timing recommandé

**Mardi à jeudi, 10h-14h** pour maximiser l'engagement.

## Différences Help Center vs News

| | News | Help Center |
|---|---|---|
| Objectif | Annoncer, créer de l'engouement | Expliquer, guider pas-à-pas |
| Ton | Enthousiaste, benefit-focused | Opérationnel, factuel |
| Longueur | 200-300 mots | Illimité |
| Format | HTML autonome (navigateur → Intercom) | HTML brut via MCP Intercom |
| Langues | Français seulement | FR + EN + IT |
| Publication | Patrick copie dans l'UI | MCP Intercom + Composio |
| Sommaire | Non | Oui (ancres internes) |
| Sections | H2 | H1 avec `id` |
| Conventions HTML | HTML standard | `<p class="no-margin">` partout |
