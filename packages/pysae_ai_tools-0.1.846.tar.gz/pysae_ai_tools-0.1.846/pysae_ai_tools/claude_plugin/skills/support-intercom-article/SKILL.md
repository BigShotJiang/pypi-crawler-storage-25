---
name: support-intercom-article
description: "Write an operational Intercom Help Center article for a new Pysae feature in FR + EN + IT, publish as draft via MCP Intercom. Use when the user says /support-intercom-article, 'article centre d'aide', 'article Intercom', shares feature info/screenshots to turn into an operational help article, or when a feature needs end-user documentation."
argument-hint: "[feature name, Patrick's brief, or screenshots]"
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
  - AskUserQuestion
---

Écrire un article opérationnel pour le centre d'aide Intercom de Pysae. Les articles expliquent les nouvelles features aux utilisateurs finaux (opérateurs, régulateurs) — focus sur **ce que ça fait** et **comment s'en servir**. Jamais marketing, toujours opérationnel.

**Prérequis** : MCP Intercom + Composio. Pour comprendre la feature, on lit le code via clone local (`pysae-ai-tools code ensure-repo`).

Conventions HTML complètes : voir [../references/intercom-html-conventions.md](../references/intercom-html-conventions.md).
Repos Pysae : voir [../references/pysae-projects.md](../references/pysae-projects.md).

## Quand utiliser

- Patrick partage des infos sur une nouvelle feature Pysae (texte, photos, contenu marketing)
- Demande d'écrire un article pour le centre d'aide
- Besoin de documenter une feature pour les end-users Pysae

## Workflow

### Phase 1 — Comprendre la feature

1. **Analyser le brief de Patrick** : texte, photos, contenu marketing — extraire l'essentiel fonctionnel
2. **Analyser les screenshots** fournis pour comprendre l'UI
3. **Cloner les repos pertinents** et lire le code localement :
   ```bash
   # Repos clés — voir pysae-projects.md
   pysae-ai-tools code ensure-repo pysae/op          # frontend exploitation
   pysae-ai-tools code ensure-repo pysae/api         # backend
   pysae-ai-tools code ensure-repo pysae/driver      # UI conducteur
   pysae-ai-tools code ensure-repo pysae/editor      # éditeur GTFS
   pysae-ai-tools code ensure-repo pysae/info        # affichage voyageurs
   pysae-ai-tools code ensure-repo pysae/screen      # écran embarqué
   ```
   Lecture via `Read`/`Grep`/`Glob` :
   - Composants Vue (`op/` contient routes, composants settings, i18n `fr.json`/`en.json`, store Pinia)
   - Endpoints API backend
   - Logique métier
4. **Synthèse** : qu'est-ce que ça fait ? Pour qui ? Comment ? Quelles limites ?

### Phase 2 — Structurer l'article

1. Titre (court, descriptif, ex : `Rapport "kilométrage"`)
2. Description courte (1 phrase pour SEO/preview Intercom)
3. Plan : sections H1, une par action/aspect
4. Identifier où placer les **images** → placeholders visibles `🖼️ <i>[Insérer capture : description]</i>`
5. **Demander à Patrick** :
   - La collection/section cible (voir table ci-dessous)
   - Validation du plan avant rédaction

### Phase 3 — Rédiger (FR + EN + IT)

Rédiger le body HTML en respectant **strictement** les conventions de [intercom-html-conventions.md § Help Center](../references/intercom-html-conventions.md#help-center-centre-daide-pysae). Produire les 3 versions : français (principal), anglais, italien.

### Phase 4 — Review avec Patrick

1. Présenter l'article complet (texte FR) à Patrick
2. Lister les emplacements des placeholders images
3. Demander validation / corrections
4. Itérer si nécessaire

### Phase 5 — Publier sur Intercom (2 étapes)

**Étape 1 — Créer l'article FR** via `mcp__claude_ai_Intercom__create_article` :

```
title: titre FR
author_id: 6831378
body: HTML body FR
description: description courte
state: "draft"
parent_id: [collection choisie par Patrick]
parent_type: "collection" (ou "section")
```

**Étape 2 — Ajouter traductions EN + IT via MCP Composio** :

Le MCP Intercom ne supporte pas `translated_content`. Utiliser Composio :

1. Appeler `COMPOSIO_SEARCH_TOOLS` avec `queries: [{use_case: "Update Intercom article with translated content"}]` et `session: {generate_id: true}`
2. Appeler `COMPOSIO_MULTI_EXECUTE_TOOL` avec le `session_id` retourné et l'outil `INTERCOM_UPDATE_AN_ARTICLE` :
   ```
   id: [article_id créé à l'étape 1]
   body: [HTML body FR final — permet aussi de corriger le FR]
   translated__content__en__title: titre EN
   translated__content__en__description: description EN
   translated__content__en__body: HTML body EN
   translated__content__en__state: "draft"
   translated__content__en__author__id: 6831378
   translated__content__it__title: titre IT
   translated__content__it__description: description IT
   translated__content__it__body: HTML body IT
   translated__content__it__state: "draft"
   translated__content__it__author__id: 6831378
   ```

Fournir le lien du draft à Patrick. Il ajoutera les images dans l'éditeur Intercom et publiera.

## Collections connues

| Collection | `parent_id` | Exemples |
|---|---|---|
| Espace Exploitation | `2719835` | Vue Course, Déviations |
| Rapports | `2719838` | Ponctualité, Kilométrage |
| Configuration | `2719839` | Gestion des équipes |

## Ton et style

- **Vouvoiement** (vous) — jamais de tutoiement
- **Opérationnel** : pas marketing, pas technique
- **Simple et direct** : phrases courtes, vocabulaire accessible
- **Focus** : « à quoi ça sert » + « comment faire »
- Utiliser les **termes métier Pysae** : course (pas trip), conducteur (pas chauffeur), plan de transport (pas GTFS)

## Erreurs à éviter

| Erreur | Correction |
|---|---|
| `<h2>` ou `<h3>` pour sections | Utiliser `<h1 id="h_xxx">` |
| `<p>` sans class | Toujours `<p class="no-margin">` |
| Tutoiement (« tu peux ») | Vouvoiement (« vous pouvez ») |
| `<b>Bouton</b>` pour éléments UI | `"<b><i>Bouton</i></b>"` avec guillemets |
| `<img>` sans wrapper | `<div class="intercom-container"><img></div>` |
| Ton marketing/commercial | Ton opérationnel et factuel |
| Pas de sommaire en intro | Toujours inclure la liste d'ancres |
| Oublier les traductions EN/IT | Toujours produire les 3 versions |
| Publier directement | Toujours créer en `draft` |
| Pas d'exploration du code | Toujours lire les repos pertinents en local pour comprendre la feature |
| Pas de séparateurs entre sections | Toujours `<hr>` avant chaque H1 et avant « Bon à savoir » |
| Contenu collé sans aération | `<p class="no-margin"></p>\n` entre chaque bloc |
| Espace vide avant un `<hr>` | Le contenu colle directement au `<hr>` |
| Placeholders en commentaire HTML | Utiliser texte visible `🖼️ <i>[Insérer capture : ...]</i>` |
| Traductions via MCP Intercom seul | Impossible — utiliser Composio |

$ARGUMENTS
