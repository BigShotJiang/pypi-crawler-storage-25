---
name: tools-status
description: >
  Check the state of Pysae CLIs and MCP servers — version detected,
  latest available, auth OK, env vars resolved, contexts reachable.
  Use when the user says /tools-status, 'check my tools', 'quelle
  version de ...', 'is aws installed', 'diagnose my setup', 'est-ce
  que tout est prêt', or any read-only question about the toolchain's
  state. To actually install or update, prefer the `tools-install`
  skill.
allowed-tools:
  - Bash
---

Read-only gateway over `pysae-ai-tools tools status`. Reports per-tool state without mutating anything.

## Commands at a glance

| Goal | Command |
|---|---|
| Overview (colored, all tools + env vars) | `pysae-ai-tools tools status` |
| Machine-readable snapshot | `pysae-ai-tools tools status --json` |
| One tool, human-readable | `pysae-ai-tools tools status <name>` |
| One tool, JSON | `pysae-ai-tools tools status <name> --json` |

## Output layout (human mode)

- **🔧 Tools** — one line per tool with an icon:
  - `✓ green` = installed and up to date
  - `⬆ yellow` = installed but a newer version exists (shown as `current → latest`)
  - `✗ red` = missing
  Each tool may print indented identity/context lines (AWS account, glab user, kubectl contexts, argocd servers, docker daemon/registries, prefect workspace, …). The `(required)` tag appears when the tool aborts the install chain on failure.
- **🔑 Environment variables** — only shown when a not-yet-installed MCP needs a var. Lists which vars are set (`✓`) vs missing (`✗`) and how to obtain them.
- **📊 Summary** — counts of `installed` / `needs-update` / `missing`.

## JSON mode

`--json` returns an array (all tools) or a single object (one tool). Each entry has:
- `needs_install` / `needs_update` — booleans
- `binary` — `{installed, version, path}` for CLIs
- `latest` — version string fetched from upstream (GitHub tags, npm, etc.)
- Tool-specific fields: `auth_ok`, `profiles`, `contexts`, `has_uri`, `configured`, …

Use `--json` to decide in code whether an install is actually required, or to extract a specific value (profile list, kubectl context, MCP server status…).

## When to route to `tools-install`

If the user asks to "install" or "update" anything, or the status shows missing/outdated tools they want fixed, hand off to the `tools-install` skill instead of running the install here.

$ARGUMENTS
