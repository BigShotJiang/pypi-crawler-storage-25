"""Post a message to a Slack channel via ``chat.postMessage``.

Usage:
    pysae-ai-tools slack post-message \\
        --channel C0123ABCDEF \\
        --text "Hello, world"

    # Thread reply
    pysae-ai-tools slack post-message \\
        --channel C0123ABCDEF \\
        --thread-ts 1700000000.000100 \\
        --text "follow-up"

    # Multiline text via stdin (--text -)
    pysae-ai-tools slack post-message --channel C... --text - <<EOF
    line 1
    line 2
    EOF

Uses :func:`pysae_ai_tools.slack.common.get_slack_token` for authentication:
the user token locally, the bot token in CI.

Output (JSON, one line):
    {"ok": true, "ts": "1700000000.000200", "channel": "C0123ABCDEF"}
    {"ok": false, "error": "<slack error code or message>"}
"""

import json
import sys
import urllib.error
import urllib.request
from typing import Annotated

import typer

from .common import get_slack_token

SLACK_API_BASE = "https://slack.com/api"


def _post(token: str, payload: dict[str, str]) -> dict[str, object]:
    """Call chat.postMessage (JSON body) and return the parsed response."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        f"{SLACK_API_BASE}/chat.postMessage",
        data=data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=utf-8",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        parsed: dict[str, object] = json.loads(resp.read())
    return parsed


cli = typer.Typer()


@cli.command()
def main(
    channel: Annotated[str, typer.Option("--channel", help="Slack channel ID")],
    text: Annotated[
        str,
        typer.Option(
            "--text",
            help="Message text (mrkdwn). Use '-' to read from stdin.",
        ),
    ],
    thread_ts: Annotated[
        str,
        typer.Option("--thread-ts", help="Parent message ts — post as a thread reply."),
    ] = "",
    broadcast: Annotated[
        bool,
        typer.Option(
            "--broadcast",
            help="With --thread-ts, also post the reply to the parent channel (reply_broadcast).",
        ),
    ] = False,
) -> None:
    """Post a message to a Slack channel (or thread) via chat.postMessage."""
    body = sys.stdin.read() if text == "-" else text
    if not body.strip():
        print(json.dumps({"ok": False, "error": "empty message body"}))
        raise typer.Exit(code=1)

    token = get_slack_token()
    if not token:
        print(json.dumps({"ok": False, "error": "no Slack token available"}))
        raise typer.Exit(code=1)

    payload: dict[str, str] = {"channel": channel, "text": body}
    if thread_ts:
        payload["thread_ts"] = thread_ts
        if broadcast:
            payload["reply_broadcast"] = "true"

    try:
        result = _post(token, payload)
    except urllib.error.URLError as e:
        print(json.dumps({"ok": False, "error": str(e)}))
        raise typer.Exit(code=1) from None

    if not result.get("ok"):
        print(json.dumps({"ok": False, "error": str(result.get("error", "unknown"))}))
        raise typer.Exit(code=1)

    print(json.dumps({"ok": True, "ts": result.get("ts"), "channel": result.get("channel")}))


if __name__ == "__main__":
    cli()
