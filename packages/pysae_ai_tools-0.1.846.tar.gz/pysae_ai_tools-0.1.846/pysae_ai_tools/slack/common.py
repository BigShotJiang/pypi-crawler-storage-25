"""Shared Slack helpers used by ``pysae-ai-tools slack`` subcommands."""

import os


def get_slack_token() -> str:
    """Return the Slack API token to use for chat/history calls.

    - In CI (``$CI`` set), the bot token is the only viable option — user
      tokens require an interactive OAuth flow.
    - Locally, prefer the user token so messages appear under the
      developer's identity, falling back to the bot token if only that one
      is set.
    """
    if os.environ.get("CI"):
        return os.environ.get("SLACK_BOT_TOKEN", "")
    return os.environ.get("SLACK_USER_TOKEN") or os.environ.get("SLACK_BOT_TOKEN", "")
