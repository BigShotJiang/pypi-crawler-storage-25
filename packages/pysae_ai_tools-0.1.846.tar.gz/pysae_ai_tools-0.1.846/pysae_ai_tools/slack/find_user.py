"""Find a Slack user by name or email.

Usage:
    pysae-ai-tools slack find-user "Rémi Alvergnat"
    pysae-ai-tools slack find-user remi.alvergnat@pysae.com

Matching rules (case-insensitive):
1. If the query looks like an email → ``users.lookupByEmail`` (fast, exact).
2. Otherwise → ``users.list``, paginated, matching the query as a substring
   of ``real_name``, ``display_name``, ``name`` (handle), or ``email``.

The first match wins — for multiple hits, refine the query.

Output (JSON, one line):
    {"found": true, "id": "U123", "name": "handle", "real_name": "Jane Doe", "email": "jane@…"}
    {"found": false}
"""

import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Annotated

import typer

from .common import get_slack_token

SLACK_API_BASE = "https://slack.com/api"
PAGE_LIMIT = 200


def _get(token: str, method: str, params: dict[str, str]) -> dict[str, object]:
    qs = urllib.parse.urlencode(params)
    url = f"{SLACK_API_BASE}/{method}?{qs}"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        data: dict[str, object] = json.loads(resp.read())
    if not data.get("ok"):
        raise RuntimeError(str(data.get("error", "unknown")))
    return data


def _format(user: dict[str, object]) -> dict[str, object]:
    profile = user.get("profile") if isinstance(user.get("profile"), dict) else {}
    assert isinstance(profile, dict)
    return {
        "found": True,
        "id": user.get("id"),
        "name": user.get("name"),
        "real_name": profile.get("real_name") or user.get("real_name"),
        "email": profile.get("email"),
    }


def _matches(user: dict[str, object], needle: str) -> bool:
    needle = needle.lower()
    profile = user.get("profile") if isinstance(user.get("profile"), dict) else {}
    assert isinstance(profile, dict)
    haystacks = [
        str(user.get("name", "")),
        str(user.get("real_name", "")),
        str(profile.get("real_name", "")),
        str(profile.get("display_name", "")),
        str(profile.get("email", "")),
    ]
    return any(needle in h.lower() for h in haystacks if h)


cli = typer.Typer()


@cli.command()
def main(
    query: Annotated[str, typer.Argument(help="Name, handle, or email to match.")],
) -> None:
    """Find a Slack user by name or email."""
    token = get_slack_token()
    if not token:
        print(json.dumps({"found": False, "error": "no Slack token available"}))
        raise typer.Exit(code=1)

    # 1. Email fast-path.
    if "@" in query and "." in query.split("@", 1)[1]:
        try:
            data = _get(token, "users.lookupByEmail", {"email": query})
        except (RuntimeError, urllib.error.URLError):
            data = None
        if data is not None:
            user = data.get("user")
            if isinstance(user, dict):
                print(json.dumps(_format(user)))
                return

    # 2. Paginated users.list fallback.
    cursor: str | None = None
    while True:
        params: dict[str, str] = {"limit": str(PAGE_LIMIT)}
        if cursor:
            params["cursor"] = cursor
        try:
            data = _get(token, "users.list", params)
        except (RuntimeError, urllib.error.URLError) as e:
            print(json.dumps({"found": False, "error": str(e)}))
            raise typer.Exit(code=1) from None

        members = data.get("members")
        if isinstance(members, list):
            for user in members:
                if isinstance(user, dict) and _matches(user, query):
                    print(json.dumps(_format(user)))
                    return

        meta = data.get("response_metadata")
        if isinstance(meta, dict):
            next_cursor = meta.get("next_cursor")
            if isinstance(next_cursor, str) and next_cursor:
                cursor = next_cursor
                continue
        break

    print(json.dumps({"found": False}))
    sys.exit(1)


if __name__ == "__main__":
    cli()
