# 22. SPA navigation (`live_redirect`)

> Phoenix LiveView-style in-app navigation, riding on the existing
> `/ws/_live` WebSocket. The static shell (sidebar, topbar chrome,
> theme bootstrap, scripts) renders **once** on cold load. Subsequent
> link clicks only swap named regions of the DOM — the WebSocket never
> reconnects, mounted LiveComponents keep their state, and the project
> writes **zero** custom JavaScript to make it work.

This page documents the contract between the hotframe library and a
project that opts in. The reference integration lives in
[ERPlora Hub](https://github.com/erplora/erplora) (`hub/apps/shared/templates/`),
which is what the snippets below mirror.

---

## Big picture

```
┌─────────────────────────┐                  ┌─────────────────────┐
│  Browser                │                  │  FastAPI app        │
│                         │  ws:/ws/_live    │                     │
│  live.js  ────────────▶ │ ─── navigate ──▶ │  LiveSession        │
│  (intercepts <a> clicks)│                  │   ._navigate()      │
│                         │                  │       │             │
│                         │                  │       ▼             │
│                         │                  │  fetch_partial      │
│                         │                  │   (ASGI sub-request │
│                         │                  │    HF-Partial: 1)   │
│                         │                  │       │             │
│                         │                  │       ▼             │
│                         │ ◀── live_redirect│  parse regions      │
│  morphdom               │   {title,regions}│  send envelope      │
│  pushState              │                  │                     │
└─────────────────────────┘                  └─────────────────────┘
```

1. `live.js` intercepts left-clicks on same-origin `<a href>` links.
2. It sends `{t:"navigate", url}` over the open WebSocket.
3. `LiveSession._navigate` (server) issues an **internal ASGI
   sub-request** to that URL, carrying:
   - the WS handshake cookies (so auth/session follows the user),
   - the header `HF-Partial: 1`.
4. The project's base template branches on `HF-Partial` and emits a
   **minimal HTML envelope** containing only the swappable regions,
   each wrapped in `<div data-hf-region="...">...</div>`.
5. Hotframe parses those regions out of the response and replies on
   the WS with `{t:"live_redirect", url, title, regions:{...}}`.
6. `live.js` morphs each region into `[data-hf-region="<name>"]`,
   updates `document.title`, and calls `history.pushState`.
7. Mounted LiveComponents whose `[data-hf-cid]` elements are *outside*
   any swapped region keep running. Components *inside* a swapped
   region are detached (server runs `on_unmount`) and any new ones in
   the incoming HTML are attached (server runs `on_mount`).

The sidebar, topbar chrome, and `<script>` tags are **never re-sent**
because they sit outside any `data-hf-region` block.

---

## Wire protocol

Defined in [`protocol.py`](../../src/hotframe/live/protocol.py).

### Client → Server

```jsonc
{ "t": "navigate", "url": "/billing?status=paid" }
```

### Server → Client

```jsonc
{
  "t": "live_redirect",
  "url": "/billing?status=paid",
  "title": "Billing — ERPlora Hub",
  "status": 200,
  "regions": {
    "content":   "...inner HTML of [data-hf-region='content']...",
    "title":     "Billing",
    "dock":      "...secondary tabbar HTML..."
  }
}
```

When the sub-requested endpoint returns a 3xx with a `Location` header
(authentication redirect, etc.), the envelope falls back to:

```jsonc
{ "t": "live_redirect", "redirect": "/login?next=/billing" }
```

and the client does a normal `window.location` navigation. The same
fallback fires for `4xx`/`5xx` responses, non-HTML/non-JSON content,
network failure, or responses that contain no `data-hf-region` blocks
(the endpoint is not partial-aware yet).

---

## Server contract: what a partial response looks like

Two shapes are accepted. **Pick one per project**; you do not need to
support both.

### A. HTML with region markers — recommended

Same template as your full page, but the shell collapses when the
`HF-Partial: 1` header is set. The minimal envelope only needs to
include a `<title>` and the region wrappers — everything else is
discarded by the live runtime.

```html
<!DOCTYPE html>
<html>
<head><title>Billing — ERPlora Hub</title></head>
<body>
<div data-hf-region="title">Billing</div>
<div data-hf-region="content"><!-- main body --></div>
<div data-hf-region="dock"><!-- secondary tabbar --></div>
</body>
</html>
```

The Jinja pattern used by ERPlora Hub:

```jinja
{# app_base.html #}
{% extends "shared/partial_base.html" if request.headers.get('hf-partial')
                                    else "shared/base.html" %}

{% block body %}
{% if request.headers.get('hf-partial') %}
  <div data-hf-region="title">{% block page_title %}Default{% endblock %}</div>
  <div data-hf-region="content">{% block main %}{% endblock %}</div>
  <div data-hf-region="dock">{% block secondary_tabbar %}...{% endblock %}</div>
{% else %}
  <!-- full sidebar + topbar + content + dock -->
  <h1 data-hf-region="title">{{ self.page_title() }}</h1>
  ...
  <div id="main-content-area" data-hf-region="content">{{ self.main() }}</div>
  ...
  <div data-hf-region="dock">{{ self.secondary_tabbar() }}</div>
{% endif %}
{% endblock %}
```

Putting `data-hf-region` on the same elements in **both** branches
matters: the cold-loaded page must already contain region markers so
later SPA navigations have a swap target.

### B. JSON envelope — for hand-crafted partials

For endpoints that assemble the response from multiple async sources,
return:

```jsonc
{
  "title": "Billing",
  "url": "/billing?status=paid",
  "regions": {
    "content": "<table>...</table>",
    "dock": "<nav>...</nav>"
  }
}
```

with `Content-Type: application/json`. The live runtime forwards it
unchanged.

---

## Client opt-out

`live.js` intercepts every same-origin left-click on `<a href>` unless
one of these conditions holds:

| Condition | Why |
|---|---|
| `data-hf-no-spa` on the anchor or any ancestor | explicit opt-out (downloads, external embeds, third-party iframes) |
| `target` attribute other than `_self` or empty | new tab / window |
| `download` attribute present | file download |
| Ctrl/Cmd/Shift/Alt held, or button ≠ 0 | user wants new tab / save |
| `href` is hash-only (`#foo`) | in-page anchor |
| `href` scheme not http(s) | `mailto:`, `tel:`, `javascript:` |
| `href` resolves to a different origin | cross-origin |
| `event.defaultPrevented` is already `true` | another handler took the click |

For programmatic navigation, call:

```js
window.hotframeLive.navigate("/billing?status=paid");
```

The history API is wired automatically: `popstate` re-issues a
`navigate` for the current URL, so back/forward stay on the SPA shell.

---

## What happens to LiveComponents during a swap

Each region is morphed independently. Before morphing, the client
sends `{t:"detach", cid}` for every `[data-hf-cid]` that lives inside
the region — the server runs `on_unmount` and drops the instance.
After the morph, `attachAll()` walks the new DOM and sends fresh
`{t:"attach", cid, name, props}` envelopes for any newly-arrived
components.

LiveComponents whose root sits *outside* every swapped region (typical
case: a notification bell or a global theme switcher mounted in the
sidebar) are untouched — they keep their state and their server lock.

This is the key reason the sidebar must not be a swappable region:
swapping it would tear down and re-mount every component it contains.

---

## Edge cases & gotchas

- **Forms** still submit normally. SPA navigation only kicks in on
  clicks, not on `POST` submissions. After a successful form submit,
  the page redirect (303) is followed by a full page load; if you want
  a partial swap here, return the partial envelope from the redirect
  target by setting `HF-Partial: 1` in your own server logic — or, more
  ergonomically, fire a `LiveComponent` event over the existing WS and
  let it `send_live_redirect`.
- **Hash-only links** (`#section`) are left to the browser so anchors
  scroll naturally.
- **WebSocket dropped during navigation**: the live client queues
  outbound messages and re-sends them on reconnect, so a transient
  drop just delays the swap. The user sees the old page until the WS
  is back.
- **Auth redirects**: if the partial sub-request returns 302 →
  `/login`, hotframe forwards that as `redirect: "/login"` in the
  `live_redirect` envelope and the client does a full reload. The
  user is not silently signed out without the chrome updating.

---

## File map (additions)

| File | Responsibility |
|---|---|
| [`live/partial.py`](../../src/hotframe/live/partial.py) | ASGI sub-request helper + region extractor used by `LiveSession._navigate`. |
| [`live/protocol.py`](../../src/hotframe/live/protocol.py) | `NavigateMessage` (C→S), `LiveRedirectMessage` (S→C), `make_live_redirect` helper. |
| [`live/session.py`](../../src/hotframe/live/session.py) | `_navigate(msg)` handler — see the `navigate` arm in `handle_message`. |
| [`live/static/live.js`](../../src/hotframe/live/static/live.js) | Anchor-click interception, `_applyLiveRedirect`, history wiring, `LiveClient.navigate(url)`. |
