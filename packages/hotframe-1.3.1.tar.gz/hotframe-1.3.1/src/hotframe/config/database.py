"""
SQLAlchemy async engine and session factory.

Provides a singleton engine, session factory, and FastAPI dependency.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator

from sqlalchemy import event
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from hotframe.config.settings import get_settings

_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_engine() -> AsyncEngine:
    """Return the singleton async engine, creating it on first call."""
    global _engine
    if _engine is None:
        settings = get_settings()
        kwargs: dict = {
            "echo": settings.DB_ECHO,
        }
        if not settings.is_sqlite:
            if settings.DB_POOL_SIZE and settings.DB_POOL_SIZE > 0:
                kwargs.update(
                    pool_size=settings.DB_POOL_SIZE,
                    max_overflow=settings.DB_MAX_OVERFLOW,
                    pool_recycle=settings.DB_POOL_RECYCLE,
                    pool_pre_ping=True,
                    pool_timeout=settings.DB_POOL_TIMEOUT,
                )
            else:
                # DB_POOL_SIZE=0 -> NullPool: a fresh connection per session,
                # opened in the current event loop. Required where sessions can
                # span event loops (e.g. LiveComponents whose on_mount runs in a
                # separate loop) — a pooled asyncpg connection reused across
                # loops raises "<Future> attached to a different loop".
                from sqlalchemy.pool import NullPool

                kwargs["poolclass"] = NullPool
            # Transaction-mode poolers (RDS Proxy, PgBouncer, Supavisor,
            # Cloud SQL Auth Proxy with pool) rotate the backend
            # connection between transactions, which invalidates any
            # prepared statement asyncpg caches on the client side.
            # Opt in via DB_DISABLE_PREPARED_STATEMENTS=true.
            if settings.DB_DISABLE_PREPARED_STATEMENTS and "asyncpg" in settings.DATABASE_URL:
                kwargs["connect_args"] = {
                    "prepared_statement_cache_size": 0,
                    "statement_cache_size": 0,
                }
        else:
            # SQLite doesn't support pool_size / max_overflow
            kwargs["connect_args"] = {"check_same_thread": False}

        _engine = create_async_engine(settings.DATABASE_URL, **kwargs)

        if settings.is_sqlite:

            @event.listens_for(_engine.sync_engine, "connect")
            def _set_sqlite_pragmas(dbapi_conn, _connection_record):
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA journal_mode = WAL")
                cursor.execute("PRAGMA synchronous = NORMAL")
                cursor.execute("PRAGMA busy_timeout = 5000")
                cursor.execute("PRAGMA foreign_keys = ON")
                cursor.execute("PRAGMA mmap_size = 268435456")
                cursor.execute("PRAGMA cache_size = -64000")
                cursor.close()

    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    """Return the singleton session factory."""
    global _session_factory
    if _session_factory is None:
        _session_factory = async_sessionmaker(
            bind=get_engine(),
            class_=AsyncSession,
            expire_on_commit=False,
        )
    return _session_factory


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency that yields an async session and handles cleanup."""
    factory = get_session_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def dispose_engine() -> None:
    """Dispose the engine on application shutdown."""
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
        _engine = None
        _session_factory = None
