# SPDX-License-Identifier: Apache-2.0
"""
ASGI sub-request helper for Phoenix-style ``live_redirect``.

``LiveSession._navigate`` calls :func:`fetch_partial` with the open
WebSocket and a target URL. We reuse the WS handshake cookies (so the
session/auth context follows the user) and inject an ``HF-Partial: 1``
header that the project's base template uses to switch from rendering
the full document to a minimal payload containing only the swappable
regions.

Two response shapes are accepted:

1. **HTML with region markers** (recommended) — the base template emits
   any top-level elements carrying ``data-hf-region="<name>"``, plus an
   optional ``<title>`` for ``document.title``. We extract the inner
   HTML of each marked element. This is the lowest-friction path: only
   the base template needs to know about ``HF-Partial``, not each view.

2. **JSON envelope** — the endpoint returns
   ``{"title": str, "regions": {<name>: <html>}, "url": str?}``. Useful
   when an endpoint wants to assemble the partial response by hand
   (e.g. async data streamed from multiple sources). Pass through.

Anything else — non-2xx, redirect to another origin, network failure —
is treated as "not partial-aware" and the session falls back to a full
``window.location`` navigation on the client.
"""

from __future__ import annotations

import json
import logging
import re
from html.parser import HTMLParser
from typing import TYPE_CHECKING, Any, TypedDict
from urllib.parse import urlsplit, urlunsplit

import httpx

if TYPE_CHECKING:
    from fastapi import WebSocket

logger = logging.getLogger(__name__)


class PartialResult(TypedDict, total=False):
    """Parsed envelope returned to :class:`LiveSession`."""

    url: str
    title: str
    regions: dict[str, str]
    status: int
    redirect: str


# Headers we forward from the WS handshake to the sub-request. These are
# safe (no auth tokens, those travel via cookies) and let the rendered
# response respect the user's locale / accept preferences.
_FORWARD_HEADERS = (
    "accept-language",
    "user-agent",
    "x-forwarded-for",
    "x-forwarded-proto",
    "x-real-ip",
)


def _normalise_url(ws: WebSocket, raw: str) -> tuple[str, str]:
    """Split ``raw`` into ``(base_url, path)`` suitable for httpx."""
    parts = urlsplit(raw)
    if parts.scheme and parts.netloc:
        base = f"{parts.scheme}://{parts.netloc}"
        path = urlunsplit(("", "", parts.path or "/", parts.query, parts.fragment))
        return base, path

    host = ws.headers.get("host", "live")
    scheme = ws.url.scheme.replace("ws", "http")  # ws→http, wss→https
    base = f"{scheme}://{host}"
    path = urlunsplit(("", "", parts.path or "/", parts.query, parts.fragment))
    return base, path


async def fetch_partial(ws: WebSocket, url: str) -> PartialResult | None:
    """Sub-request ``url`` through the app and return the parsed envelope.

    Returns ``None`` if the response is not a partial-aware payload, in
    which case the caller falls back to ``window.location`` navigation.
    """
    app = ws.app
    base_url, path = _normalise_url(ws, url)

    headers: dict[str, str] = {
        "hf-partial": "1",
        # Accept JSON or HTML — see module docstring for the two shapes.
        "accept": "text/html, application/json;q=0.9",
    }
    for h in _FORWARD_HEADERS:
        v = ws.headers.get(h)
        if v:
            headers[h] = v

    cookies = dict(ws.cookies)

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport,
        base_url=base_url,
        cookies=cookies,
        follow_redirects=False,
        timeout=httpx.Timeout(15.0, connect=5.0),
    ) as client:
        resp = await client.get(path, headers=headers)

    # Hard redirect — the endpoint pointed us off the SPA shell (e.g.
    # unauthenticated → /login). Hand control back via ``redirect``.
    if 300 <= resp.status_code < 400:
        location = resp.headers.get("location")
        if not location:
            return None
        return PartialResult(
            url=url,
            title="",
            regions={},
            status=resp.status_code,
            redirect=location,
        )

    if resp.status_code >= 400:
        logger.info(
            "fetch_partial: %s returned %s; falling back to hard nav",
            url,
            resp.status_code,
        )
        return None

    ctype = resp.headers.get("content-type", "")
    body = resp.text

    if "application/json" in ctype:
        return _parse_json(body, url, resp.status_code)
    if "text/html" in ctype or "text/plain" in ctype:
        return _parse_html(body, url, resp.status_code)
    return None


# ---------------------------------------------------------------------------
# JSON path
# ---------------------------------------------------------------------------


def _parse_json(body: str, url: str, status: int) -> PartialResult | None:
    try:
        data: dict[str, Any] = json.loads(body)
    except Exception:
        logger.warning("fetch_partial: %s returned malformed JSON", url)
        return None
    regions = data.get("regions") or {}
    if not isinstance(regions, dict):
        return None
    return PartialResult(
        url=str(data.get("url") or url),
        title=str(data.get("title") or ""),
        regions={str(k): str(v) for k, v in regions.items()},
        status=status,
    )


# ---------------------------------------------------------------------------
# HTML path
# ---------------------------------------------------------------------------


_TITLE_RE = re.compile(r"<title[^>]*>([\s\S]*?)</title>", re.IGNORECASE)


class _RegionExtractor(HTMLParser):
    """Walks the partial HTML and captures the inner HTML of every
    element with a ``data-hf-region="<name>"`` attribute.

    Nested ``data-hf-region`` elements are supported and stored under
    their own name — but the outer region's captured HTML still
    contains the inner one (the inner element acts as a placeholder
    until the client morphs it). This matches what the browser sees
    when both regions are present in the DOM.

    Tag/attribute serialization is intentionally minimal: we just
    re-emit what the parser feeds us. Browsers tolerate the small
    differences (lowercased tags, double-quoted attrs).
    """

    # Void elements that must self-close in the re-emitted HTML.
    _VOID = frozenset({
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "source", "track", "wbr",
    })

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self._stack: list[tuple[str, list[str], str | None]] = []  # (tag, buffer-as-list, region_name|None)
        self._region_depth = 0
        self.regions: dict[str, str] = {}

    # -- helpers ----------------------------------------------------

    def _emit(self, text: str) -> None:
        if self._stack:
            self._stack[-1][1].append(text)

    @staticmethod
    def _format_attrs(attrs: list[tuple[str, str | None]]) -> str:
        parts: list[str] = []
        for name, value in attrs:
            if value is None:
                parts.append(name)
            else:
                # Escape double quotes in the value; everything else is
                # already a literal from the parser.
                v = value.replace('"', "&quot;")
                parts.append(f'{name}="{v}"')
        return (" " + " ".join(parts)) if parts else ""

    @staticmethod
    def _region_name(attrs: list[tuple[str, str | None]]) -> str | None:
        for name, value in attrs:
            if name == "data-hf-region" and value:
                return value
        return None

    # -- parser callbacks ------------------------------------------

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        region = self._region_name(attrs)
        is_void = tag in self._VOID
        rendered = f"<{tag}{self._format_attrs(attrs)}>"

        if region is not None:
            # Outer region renders the wrapper itself as part of any
            # ancestor region's buffer, but we capture *inner HTML*, so
            # push a fresh buffer for the children.
            self._emit(rendered)
            if not is_void:
                self._stack.append((tag, [], region))
                self._region_depth += 1
            return

        if is_void:
            self._emit(rendered)
            return

        if self._region_depth > 0 or self._stack:
            # Either we're inside a region (record) or above any region
            # (we still need a stack frame so child regions can be
            # detected). Keep a buffer either way.
            self._emit(rendered)
            self._stack.append((tag, [], None))
        # If we're at the very top with no region context, ignore.

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        # Self-closing in source — treat as void.
        rendered = f"<{tag}{self._format_attrs(attrs)}/>"
        self._emit(rendered)

    def handle_endtag(self, tag: str) -> None:
        if not self._stack:
            return
        frame_tag, buffer, region = self._stack[-1]
        if frame_tag != tag:
            # Mismatched tag (browser would still close it).
            # Find the nearest matching frame and pop everything in between.
            idx = None
            for i in range(len(self._stack) - 1, -1, -1):
                if self._stack[i][0] == tag:
                    idx = i
                    break
            if idx is None:
                return
            # Collapse intermediate frames into their parents and close
            # each in order.
            while len(self._stack) - 1 > idx:
                self._close_frame()
            # Fall through to close the matching frame.
            frame_tag, buffer, region = self._stack[-1]

        self._close_frame()
        self._emit(f"</{tag}>")

    def _close_frame(self) -> None:
        frame_tag, buffer, region = self._stack.pop()
        inner = "".join(buffer)
        if region is not None:
            self.regions[region] = inner
            self._region_depth -= 1
        else:
            # Push the closed element's children back up as the parent's
            # text. The opening tag was already emitted to the parent.
            self._emit(inner)

    def handle_data(self, data: str) -> None:
        self._emit(data)

    def handle_entityref(self, name: str) -> None:
        self._emit(f"&{name};")

    def handle_charref(self, name: str) -> None:
        self._emit(f"&#{name};")

    def handle_comment(self, data: str) -> None:
        self._emit(f"<!--{data}-->")


def _parse_html(body: str, url: str, status: int) -> PartialResult | None:
    extractor = _RegionExtractor()
    try:
        extractor.feed(body)
        extractor.close()
    except Exception:
        logger.warning("fetch_partial: %s HTML parse failed", url)
        return None

    if not extractor.regions:
        # No region markers — endpoint isn't partial-aware yet.
        return None

    title = ""
    m = _TITLE_RE.search(body)
    if m:
        title = _decode_title(m.group(1).strip())

    return PartialResult(
        url=url,
        title=title,
        regions=extractor.regions,
        status=status,
    )


def _decode_title(raw: str) -> str:
    """Cheap HTML entity decode for the small set we care about."""
    return (
        raw.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", '"')
        .replace("&#39;", "'")
    )
