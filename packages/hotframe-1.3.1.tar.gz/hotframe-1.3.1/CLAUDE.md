# CLAUDE.md — hotframe

Operational guide for working in this repository. Load this on entry and
expand the relevant section before touching code.

---

## What hotframe is

A FastAPI-shaped web framework with batteries: Pydantic settings,
auto-discovery, Tortoise-style ORM thin layer over SQLAlchemy 2.0, a
LiveView-style server-side reactivity layer (`live/`), Jinja2
templating with a JinjaX bridge, a CLI, dev autoreload, observability,
testing utilities, and a module engine that lets first-party apps and
third-party modules share a single FastAPI app.

The reference deployment is **ERPlora Hub** (`../ERPlora/hub`). When
the user mentions "hub" they mean a hotframe project, and the hub's
CLAUDE.md is the canonical user of every public API documented here.

---

## Stack

| Layer | Choice |
|---|---|
| HTTP | FastAPI |
| Reactivity | `LiveComponent` over `/ws/_live` (WebSocket + morphdom) |
| Templates | Jinja2 (+ optional JinjaX bridge) |
| ORM | SQLAlchemy 2.0 async, wrapped in `models/`/`repository/` |
| DB | PostgreSQL 17 (asyncpg) or SQLite for tests |
| Settings | Pydantic Settings |
| Discovery | `discovery/` walks `apps/` and `modules/` at startup |
| Templates entry | `bootstrap.py` `create_app()` |
| Tests | pytest + httpx ASGI transport |

---

## Repository layout

```
hotframe/
├── src/hotframe/
│   ├── apps/           # First-party app loader
│   ├── auth/           # Session / auth helpers
│   ├── components/     # Component registry + JinjaX bridge
│   ├── config/         # Settings, DB engine factory
│   ├── db/             # Async engine, session factory
│   ├── dev/            # Auto-reload
│   ├── discovery/      # Filesystem walkers (apps, modules, components)
│   ├── engine/         # Module engine — runtime composition
│   ├── http/           # HTTP client (with refresh interceptors)
│   ├── live/           # LiveComponent runtime — see below
│   ├── management/     # CLI (`hf migrate`, `hf shell`, ...)
│   ├── middleware/     # ASGI middlewares (CSP, request_id, ...)
│   ├── migrations/     # Schema migration runner
│   ├── models/         # Base ORM model + mixins
│   ├── orm/            # ORM-flavoured fields/managers
│   ├── repository/     # Repository pattern helpers
│   ├── signals/        # Sync/async signal framework
│   ├── templating/     # Jinja2 environment factory
│   ├── testing/        # Test client + fixtures
│   ├── utils/          # Observability helpers
│   ├── views/          # Class-based views shim
│   ├── asgi.py         # ASGI entry shim
│   └── bootstrap.py    # `create_app()` — wires every subsystem
└── docs/
    ├── en/             # English documentation (one file per subsystem)
    └── es/             # Spanish mirror
```

---

## `live/` subsystem (you will touch this often)

This is where server-side reactivity lives. Read
[docs/en/11-live.md](docs/en/11-live.md) for the core protocol and
[docs/en/22-spa-navigation.md](docs/en/22-spa-navigation.md) for the
Phoenix-style `live_redirect` SPA layer.

| File | Purpose |
|---|---|
| `base.py` | `LiveComponent` class — Pydantic state, lifecycle, event table |
| `decorators.py` | `@event("name")` registration |
| `diff.py` | Template render + `data-hf-cid` envelope |
| `jinja_ext.py` | `{% live "name" prop=... %}` tag |
| `protocol.py` | Wire-format TypedDicts (client↔server JSON envelopes) |
| `session.py` | `LiveSession` — per-WS aggregate of component instances |
| `runtime.py` | `LiveRuntime` — per-app singleton holding all sessions |
| `ws.py` | `/ws/_live` FastAPI endpoint |
| `partial.py` | ASGI sub-request helper for SPA `live_redirect` |
| `assets.py` | `live_assets()` Jinja global → emits `<script>` tags |
| `static/live.js` | Client runtime — WS, event capture, morphdom |
| `static/morphdom.min.js` | Vendored DOM patcher |

### Wire protocol summary

Client → Server:
- `attach` — mount a component instance under a `cid`
- `event`  — invoke an `@event` handler
- `bind`   — set one state field (`data-bind` debounced inputs)
- `detach` — release a component (server runs `on_unmount`)
- `navigate` — Phoenix-style `live_redirect` (SPA navigation)

Server → Client:
- `patch` — full HTML re-render of one component, morphed in place
- `nav`   — server-initiated full page navigation (hard reload)
- `live_redirect` — SPA navigation result: named regions + title + url
- `err`   — handler raised an error
- `toast` — flash-style notification

### SPA navigation contract (`HF-Partial: 1`)

When `live.js` intercepts an anchor click it sends `{t:"navigate", url}`.
The session issues an internal ASGI sub-request to that URL with header
`HF-Partial: 1` and the WS handshake cookies. The project's base
template branches on that header and emits a **minimal envelope**
containing only `<div data-hf-region="...">` wrappers. The runtime
extracts those regions and replies with `{t:"live_redirect", regions,
title, url}`. The client morphs each region into the matching
`[data-hf-region]` element, updates `document.title`, and calls
`history.pushState`.

The static shell (sidebar, topbar chrome, scripts) is never re-sent.
LiveComponents whose root sits outside any swappable region keep state.

Full design + edge cases in [docs/en/22-spa-navigation.md](docs/en/22-spa-navigation.md).

---

## When working on this repo

- **Public APIs are stable**: changes to `protocol.py`, `LiveComponent`,
  `LiveSession` public methods, or the `live.js` wire format must keep
  the existing wire compatible or bump the version in `pyproject.toml`.
- **httpx is already a dep** — `partial.py` uses `httpx.ASGITransport`.
  Reuse instead of adding new HTTP-ish deps.
- **No client-side framework**: `live.js` is hand-written ES5 (so it
  works without a build step). Do not import npm packages into it.
- **Tests live next to code**: `src/hotframe/<subsystem>/tests/`.
  Integration tests that hit a real WS live under `tests/`.
- **Docs are part of the change**: any feature added to `live/` or any
  new wire message must update `docs/en/11-live.md` (or a dedicated
  numbered file) plus the `docs/en/00-INDEX.md` entry.

---

## When the user mentions "hub" or "ERPlora Hub"

That is the reference project at `../ERPlora/hub`. It uses every
public API documented here. Read its `CLAUDE.md` for the
project-specific conventions (themes, daisyUI, DataTable macros,
secondary tabbar pattern, etc.). Anything in the hub that touches
`{% live %}`, the WS, or SPA navigation is exercising the surfaces
documented under `docs/en/11-live.md` and `docs/en/22-spa-navigation.md`.
