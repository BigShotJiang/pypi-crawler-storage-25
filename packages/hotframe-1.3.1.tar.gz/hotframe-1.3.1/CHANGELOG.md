# Changelog

All notable changes to **hotframe** are documented here. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and
the project adheres to [Semantic Versioning](https://semver.org/).

## [1.2.0] — 2026-05-20

### Removed (breaking)

- **`htmx_redirect`, `htmx_refresh`, `htmx_trigger`, `htmx_message`,
  `htmx_view`, `is_htmx_request`** — the pre-1.0 backwards-compat
  aliases re-introduced in 1.0.0 to unblock the ERPlora Hub migration.
  Their semantics (empty 200 + `HX-Redirect` header, `?partial=true`
  detection, etc.) targeted the HTMX runtime, which is no longer in
  use anywhere. Callers must move to `reactive_redirect`,
  `reactive_refresh`, `reactive_trigger`, `reactive_message`, `view`
  respectively. `is_htmx_request` is gone entirely — its only
  in-tree behaviour was to test `?partial=true` query string, which
  nothing emits.
- **`is_reactive_request`** — the placeholder that always returned
  `False`. Callers were branching on it pointlessly; the SPA layer
  uses the `HF-Partial: 1` header directly and Live components flow
  over the WS, so neither needs HTTP-request introspection here.

Migration: the ERPlora Hub (35 files affected) is the only known
consumer; the same-day cleanup PR on the hub repo replaces every
`htmx_*` import + call site mechanically — see hub commit migrating
to `view` / `reactive_redirect`.

## [1.1.0] — 2026-05-20

### Added

- **Phoenix-style SPA navigation** (`live_redirect`) over the existing
  `/ws/_live` WebSocket. `live.js` intercepts same-origin anchor
  clicks and sends `{t:"navigate", url}`; the server issues an
  internal ASGI sub-request to that URL with header `HF-Partial: 1`,
  parses the response for `[data-hf-region="<name>"]` blocks, and
  replies with `{t:"live_redirect", url, title, regions}`. The
  client morphs each region into its existing wrapper, updates
  `document.title`, and calls `history.pushState`. The static shell
  (sidebar, topbar chrome, scripts) is never re-rendered, and
  `LiveComponent`s outside swapped regions keep their state.
  See [`docs/en/22-spa-navigation.md`](docs/en/22-spa-navigation.md)
  for the wire contract, opt-outs, and edge cases.
- **`live/partial.py`** — ASGI sub-request helper (`fetch_partial`)
  used by `LiveSession._navigate`. Accepts HTML responses with
  `data-hf-region` markers or JSON `{title, regions, url}` envelopes.
  Forwards WS handshake cookies and safe headers; treats 3xx as a
  hard redirect handed back to the client.
- **`NavigateMessage`** (client → server), **`LiveRedirectMessage`**
  (server → client) and `make_live_redirect` helper in
  `live/protocol.py`.
- **`LiveComponent.refresh()`** — re-render and push the current
  state to the client, callable from background tasks launched in
  `on_mount`. Event handlers do not need to call it.
- **Top-level `CLAUDE.md`** for agent tooling: subsystem map, wire
  protocol summary, and a "when the user mentions hub" pointer.

### Fixed

- **Static mount ordering in `bootstrap.py`** — the framework-shipped
  `/static/hotframe/` mount is now registered *before* the
  project-level `/static` so Starlette's first-match resolver hits
  the more specific prefix. Previously the broader project mount
  swallowed `/static/hotframe/*` requests and `live.js` 404'd.

### Changed

- Documentation cleanup of leftover references to the pre-1.0 `htmx_*`
  aliases in `docs/en|es/12-views.md`, `GUIDE.md` and
  `llms-full.txt`. The runtime aliases themselves stay in
  `views/responses.py` (re-introduced in 1.0 to unblock callers).

## [1.0.0] — 2026-05-10

First public release under the new `hotframe.dev` project home.

### Added

- **`hotframe.live`** — stateful, server-rendered, WebSocket-driven
  components. `LiveComponent` base class, `@event` decorator,
  `LiveSession`, `LiveRuntime`, `/ws/_live` endpoint, and the
  vendored `live.js` + `morphdom` client (~12 KB minified+gzip).
- **`{% live %}` Jinja2 tag** for cold-loading live components from
  any template.
- **`{{ live_assets() }}` Jinja2 global** that emits the script tags
  for the live runtime client.
- **JinjaX integration** for component-style template syntax.
- **Hot-mount module engine** (`ModuleRuntime`) — install, activate,
  deactivate, uninstall, and update modules at runtime.
- **`@view` decorator** with auth + permission gating + template
  auto-discovery.
- **`Component` / `ComponentRegistry`** for stateless reusable
  widgets, discovered from `apps/*/components/` and
  `modules/*/components/`.
- **Slot system** (`SlotRegistry`) for cross-module UI injection.
- **Event bus** (`AsyncEventBus`), **hooks** (`HookRegistry`), and
  **typed events** (`BaseEvent` + `@register_event`).
- **CRUD repository pattern** (`BaseRepository`) and abstract
  persistence protocols (`ISession`, `IQueryBuilder`, `IRepository`).
- **CSRF**, **CSP**, **rate limiting**, **CORS**, and **session**
  middleware out of the box.
- **CLI** (`hf`) with `startproject`, `startapp`, `startmodule`,
  `runserver`, `migrate`, `makemigrations`, `shell`, and module
  lifecycle commands.

### Project notes

- This `1.0.0` line is a clean reset. Earlier `0.x` releases on PyPI
  shipped a different reactivity layer and are not considered
  API-stable predecessors.
- Repository moved to [github.com/hotframe/hotframe](https://github.com/hotframe/hotframe).
- License: Apache 2.0.
