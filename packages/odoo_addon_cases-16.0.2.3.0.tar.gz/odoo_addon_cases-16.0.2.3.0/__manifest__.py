{
    "name": "Cases Management",
    "summary": """
        Custom Cases Management Module for ESK
    """,
    "description": """
        'Manage Cases with schedules, trials, conciliations, deadlines, and settings',
    """,
    "author": "Coopdevs",
    "website": "https://git.coopdevs.org/talaios/addons/cases#",
    "category": "Base",
    "version": "16.0.2.3.0",
    "depends": [
        "account",
        "base",
        "mail",
    ],
    "data": [
        "demo/phase_demo.xml",
        "security/ir.model.access.csv",
        "views/account_move_views.xml",
        "views/case_type_views.xml",
        "views/case_views.xml",
        "views/court_views.xml",
        "views/phase_type_views.xml",
        "views/phase_views.xml",
        "views/trial_views.xml",
        "views/schedule_views.xml",
        "views/menu_views.xml",
    ],
    "installable": True,
    "auto_install": False,
    "license": "AGPL-3"
}
