from odoo import models, fields, _


class CasePhaseType(models.Model):
    _name = 'case.phase.type'
    _description = 'Case Phase Type'
    _order = 'jurisdiction, sequence, id'

    name = fields.Char(string='Name', required=True, translate=True)
    jurisdiction = fields.Selection(
        selection=[
            ('labor', _('Labor')),
            ('litigation', _('Administrative Litigation')),
            ('social_security', _('Social security')),
            ('trade', _('Trade')),
            ('penal', _('Penal')),
        ],
        string='Jurisdiction',
        required=True,
        index=True,
    )
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    _sql_constraints = [
        (
            'name_jurisdiction_uniq',
            'unique(name, jurisdiction)',
            'Ya existe una fase con ese nombre para esta jurisdicción.',
        ),
    ]
