from odoo import models, fields, api, _

PROVINCE_PREFIX = {
    "Bizkaia": "BI",
    "Araba": "VI",
    "Gipuzkoa": "SS",
    "Nafarroa": "NA",
}


class Case(models.Model):
    _name = "case"
    _description = "Case"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char(string="Name", compute="_compute_client_info", store=True)
    case_number = fields.Char(
        string="Case Number",
        readonly=True,
        copy=False,
        index=True,
    )
    province_id = fields.Many2one(
        "res.country.state",
        string="Province",
        domain="[('name', 'in', ['Bizkaia', 'Araba', 'Gipuzkoa', 'Nafarroa'])]",
        required=True,
        tracking=True,
    )
    state = fields.Selection(
        [("open", _("Open")), ("closed", _("Closed"))],
        string="Status",
        default="open",
        tracking=True,
    )
    closed_state = fields.Selection(
        [
            ("resignation", _("The represented person resigns from representation")),
            ("withdrawn", _("Withdrawn")),
            ("settlement", _("Out-of-court settlement")),
            ("other", _("Other")),
        ],
        string="Closed status",
        default="resignation",
    )
    reason = fields.Char(string="Reason")
    verdict = fields.Selection(
        selection=[
            ("not_established", _("Not established")),
            ("won", _("Won")),
            ("in_process", _("In process")),
            ("lost", _("Lost")),
        ],
        string="Verdict",
        tracking=True,
    )
    liable = fields.Many2one("res.users", required=True, string="Liable")
    demandant = fields.Many2many(
        "res.partner",
        "case_demandant_rel",
        "case_id",
        "partner_id",
        string="Demandant",
        required=True,
    )
    defendant = fields.Many2many(
        "res.partner",
        "case_defendant_rel",
        "case_id",
        "partner_id",
        string="Defendant",
        required=True,
    )
    client = fields.Selection(
        [("demandant", _("Demandant")), ("defendant", _("Defendant"))],
    )
    case_type = fields.Many2many("case.type", string="Case type")
    jurisdiction = fields.Selection(
        [
            ("labor", _("Labor")),
            ("litigation", _("Administrative Litigation")),
            ("social_security", _("Social security")),
            ("trade", _("Trade")),
            ("penal", _("Penal")),
        ],
        required=True,
        tracking=True,
    )
    court_no = fields.Many2one(
        "court",
        string="Court No",
        domain="[('province_id', '=', province_id)]",
    )
    auto_no = fields.Char(string="Auto No")
    image_1920 = fields.Image(
        string="Image",
        compute="_compute_client_info",
        store=True,
    )
    next_activity = fields.Char(
        string="Next Activity",
        compute="_compute_next_activity",
    )
    next_activity_date = fields.Datetime(
        string="Next Activity Date",
        compute="_compute_next_activity",
    )
    invoice_ids = fields.One2many(
        "account.move",
        "case_id",
        string="Invoices",
        domain=[("move_type", "=", "out_invoice")],
    )
    invoice_count = fields.Integer(
        string="Invoice Count",
        compute="_compute_invoice_count",
    )
    phase_ids = fields.One2many(
        "case.phase",
        "case_id",
        string="Phases",
    )
    phase_count = fields.Integer(
        string="Phase count",
        compute="_compute_latest_phase",
    )
    latest_phase_id = fields.Many2one(
        "case.phase",
        string="Latest phase",
        compute="_compute_latest_phase",
        help="Fase más reciente (mayor fecha e id).",
    )
    latest_phase_name = fields.Char(
        related="latest_phase_id.name",
        readonly=True,
    )
    latest_phase_date = fields.Date(
        related="latest_phase_id.date",
        readonly=True,
    )
    latest_phase_lawyer = fields.Many2one(
        "res.users",
        related="latest_phase_id.lawyer_id",
        readonly=True,
    )
    latest_phase_notes = fields.Text(
        related="latest_phase_id.notes",
        readonly=True,
    )

    @api.depends("client", "demandant", "defendant")
    def _compute_client_info(self):
        for rec in self:
            if rec.client == "demandant" and rec.demandant:
                rec.name = rec.demandant[0].display_name
                rec.image_1920 = rec.demandant[0].image_1920
            elif rec.client == "defendant" and rec.defendant:
                rec.name = rec.defendant[0].display_name
                rec.image_1920 = rec.defendant[0].image_1920
            else:
                rec.name = False
                rec.image_1920 = False

    @api.depends(
        "activity_ids.date_deadline", "activity_ids.summary", "activity_ids.state"
    )
    def _compute_next_activity(self):
        for case in self:
            pending = case.activity_ids.filtered(
                lambda a: a.state in ("planned", "overdue")
            ).sorted(key=lambda a: a.date_deadline)
            if pending:
                case.next_activity = pending[0].summary
                case.next_activity_date = pending[0].date_deadline
            else:
                case.next_activity = False
                case.next_activity_date = False

    @api.depends("invoice_ids")
    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = len(rec.invoice_ids)

    @api.depends("phase_ids.date")
    def _compute_latest_phase(self):
        for rec in self:
            phases = rec.phase_ids.sorted(key=lambda p: p.date)
            rec.phase_count = len(phases)
            rec.latest_phase_id = phases[-1] if phases else False

    def _get_next_case_sequence(self, prefix, year):
        self.env.cr.execute(
            """
            SELECT case_number FROM "case"
            WHERE case_number LIKE %s
            ORDER BY id DESC LIMIT 1
            FOR UPDATE SKIP LOCKED
            """,
            (f"{prefix}-{year}-%",),
        )
        row = self.env.cr.fetchone()
        if row:
            try:
                return int(row[0].split("-")[-1]) + 1
            except (ValueError, IndexError):
                pass
        return 1

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("case_number") and vals.get("province_id"):
                province = self.env["res.country.state"].browse(vals["province_id"])
                prefix = PROVINCE_PREFIX.get(province.name, "XX")
                year = fields.Date.today().year
                seq = self._get_next_case_sequence(prefix, year)
                vals["case_number"] = f"{prefix}-{year}-{seq}"
        return super().create(vals_list)

    def get_involved_partners(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Involved partners"),
            "view_mode": "tree,form",
            "res_model": "res.partner",
            "domain": [("id", "in", self.demandant.ids + self.defendant.ids)],
            "context": {"create": False},
        }

    def action_create_invoice(self):
        self.ensure_one()
        partner = False
        if self.client == "demandant" and self.demandant:
            partner = self.demandant[0]
        elif self.client == "defendant" and self.defendant:
            partner = self.defendant[0]
        invoice = self.env["account.move"].create(
            {
                "move_type": "out_invoice",
                "partner_id": partner.id if partner else False,
                "case_id": self.id,
            }
        )
        return {
            "type": "ir.actions.act_window",
            "name": _("Invoice"),
            "res_model": "account.move",
            "res_id": invoice.id,
            "view_mode": "form",
        }

    def action_create_phase(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("New Phase"),
            "res_model": "case.phase",
            "view_mode": "form",
            "context": {
                "default_case_id": self.id,
                "default_jurisdiction": self.jurisdiction,
            },
        }

    def action_open_latest_phase(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Phase"),
            "res_model": "case.phase",
            "res_id": self.latest_phase_id.id,
            "view_mode": "form",
            "target": "current",
        }

    def action_view_phases(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Phases"),
            "res_model": "case.phase",
            "view_mode": "tree,form",
            "domain": [("case_id", "=", self.id)],
            "context": {
                "default_case_id": self.id,
                "default_jurisdiction": self.jurisdiction,
            },
        }

    def action_view_invoices(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Invoices"),
            "res_model": "account.move",
            "view_mode": "tree,form",
            "domain": [("case_id", "=", self.id), ("move_type", "=", "out_invoice")],
            "context": {"default_case_id": self.id, "default_move_type": "out_invoice"},
        }
