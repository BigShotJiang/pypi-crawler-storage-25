from odoo import models, fields


class CasePhase(models.Model):
    _name = "case.phase"
    _description = "Case Phase"
    _order = "date asc, id asc"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    case_id = fields.Many2one(
        "case",
        string="Case",
        required=True,
        ondelete="cascade",
        index=True,
    )
    phase_type_id = fields.Many2one(
        "case.phase.type",
        string="Phase",
        required=True,
        ondelete="restrict",
        domain="[('jurisdiction', '=', parent.jurisdiction)]",
    )
    phase_type_name = fields.Char(
        related='phase_type_id.name',
        store=True
    )
    name = fields.Char(
        string="Name",
        related="phase_type_id.name",
        store=True,
        readonly=True,
    )
    jurisdiction = fields.Selection(
        related="case_id.jurisdiction",
        store=True,
        readonly=True,
        string="Jurisdiction",
    )
    date = fields.Date(
        string="Date",
        default=fields.Date.today,
        required=True,
    )
    lawyer_id = fields.Many2one(
        "res.users",
        string="Abogad@ asignad@",
        domain="[('share', '=', False)]",
    )
    notes = fields.Text(string="Notes")
    date_notification = fields.Date(string="Notification date", tracking=True)
    date_notification_admin = fields.Date(
        string="Admin notification date",
        tracking=True,
    )
    date_deadline = fields.Date(string="Deadline", tracking=True)
    date_filing = fields.Date(string="Filing date", tracking=True)
    date_announcement = fields.Date(string="Announcement date", tracking=True)
    date_deadline_filing = fields.Date(string="Filing deadline", tracking=True)
    date_preparation = fields.Date(string="Preparation date", tracking=True)
    date_deadline_formalization = fields.Date(
        string="Formalization deadline",
        tracking=True,
    )
    date_formalization = fields.Date(
        string="Formalization date",
        tracking=True,
    )
    auto_number = fields.Char(string="Auto number", tracking=True)
    sentence_number = fields.Char(string="Sentence number", tracking=True)
    expedient_number = fields.Char(string="Expedient number", tracking=True)
    administrative_silence = fields.Boolean(
        string="Administrative silence",
        tracking=True,
    )
    sentence_final = fields.Boolean(string="Sentence is final", tracking=True)
    related_case_id = fields.Many2one(
        "case",
        string="Related case",
        help="Link to another case (e.g. ERE linked to its labour process).",
        ondelete="set null",
    )
