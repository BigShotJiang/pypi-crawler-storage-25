from odoo import models, fields

class Court(models.Model):
    _name = 'court'
    _description = 'Court'

    name = fields.Char(string='Name', required=True)
    province_id = fields.Many2one(
        "res.country.state",
        string="Province",
        domain="[('name', 'in', ['Bizkaia', 'Araba', 'Gipuzkoa', 'Nafarroa'])]",
        required=True,
        tracking=True,
    )
