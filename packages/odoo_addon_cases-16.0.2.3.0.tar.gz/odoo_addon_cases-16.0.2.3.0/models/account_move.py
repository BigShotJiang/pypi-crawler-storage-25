from odoo import fields, models


class AccountMove(models.Model):
    _name = "account.move"
    _inherit = "account.move"

    case_id = fields.Many2one("case", string="Case")
