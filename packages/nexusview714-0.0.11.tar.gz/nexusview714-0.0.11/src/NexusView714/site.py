from IPython import display
import urllib.request
import urllib.error
from NexusView714.custom_exception import InvalidException
from NexusView714.logger import logger


def is_valid(URL: str) -> bool:
    try:
        req = urllib.request.Request(
            URL,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        )
        response_status = urllib.request.urlopen(req).getcode()
        assert response_status == 200
        logger.debug(f"response_status: {response_status}")
        return True
    except urllib.error.HTTPError as e:
        if e.code == 403:
            # Server blocked the bot UA but URL is reachable — still valid
            logger.warning(f"403 Forbidden (bot-blocked) for URL: {URL}")
            return True
        logger.exception(e)
        return False
    except urllib.error.URLError as e:
        # Genuinely unreachable — wrong domain, no internet, etc.
        logger.exception(e)
        return False


def render_site(URL: str, width: str = "100%", height: str = "600") -> str:
    try:
        if is_valid(URL):
            response = display.IFrame(src=URL, width=width, height=height)
            display.display(response)
            return "success"
        else:
            raise InvalidException(f"The URL is unreachable: {URL}")
    except Exception as e:
        raise e