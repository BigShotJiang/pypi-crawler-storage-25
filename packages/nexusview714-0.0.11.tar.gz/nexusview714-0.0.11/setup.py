import setuptools

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

__version__ = "0.0.11"
REPO_NAME = "NexusView714"
AUTHOR_USER_NAME = "SheikhSohaib714"
AUTHOR_EMAIL = "eyelens714@gmail.com"
SRC_REPO = "NexusView714"

setuptools.setup(
    name=SRC_REPO,
    version=__version__,
    author=AUTHOR_USER_NAME,
    author_email=AUTHOR_EMAIL,
    description="A small python package",
    long_description=long_description,              # ✅ use the variable, not open() again
    long_description_content_type="text/markdown",  # ✅ was missing _type
    url=f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}",
    project_urls={
        "Bug Tracker": f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}/issues",
    },
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src")
)