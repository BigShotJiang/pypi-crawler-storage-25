# LeRobot Dummy Follower Arm

This is a **Virtual Follower Arm** integration designed for the [LeRobot](https://github.com/huggingface/lerobot) framework.
Its primary purpose is debugging: it does not drive any real hardware but instead prints the received control commands (Actions) directly to the terminal.

## How it Works

1.  **Action Listening**: It implements the `Robot` base class and receives position commands from the Leader via `send_action`.
2.  **Feature Alignment**: To work with a specific Leader, it declares matching joint names (motor names).
3.  **Debug Output**: Whenever the Leader sends a command, the Dummy arm outputs: `[DEBUG DUMMY] Received Action: ...` to the console.
4.  **Silent Mode**: You can disable all terminal output by setting the `silent` configuration to `True`.

## Installation

Navigate to the directory and install in editable mode:

```bash
cd lerobot-robot-dummy
pip install -e .
```

## Usage

### 1. Using with Seeed B601 Leader (Default Configuration)
The Dummy arm's default motor names are aligned with the **Seeed B601** (`shoulder_pan`, `shoulder_lift`, etc.), so you can run it directly:

```bash
lerobot-teleoperate \
    --robot.type=dummy_follower \
    --robot.id=dummy1 \
    --teleop.type=seeed_b601_dm_leader \
    --teleop.port=/dev/ttyACM0 \
    --teleop.can_adapter=damiao
```

### 2. Running in Silent Mode (Quiet Mode)
If you want to suppress the terminal output (e.g., to keep the console clean while testing other components), add the `--robot.silent=True` flag:

```bash
lerobot-teleoperate \
    --robot.type=dummy_follower \
    --robot.id=dummy_quiet \
    --robot.silent=True \
    --teleop.type=seeed_b601_dm_leader \
    ...
```

### 3. Using with Other Leaders (Dynamic Motor Names)
If you want to use it with other robots (e.g., xArm or a custom arm), you can pass the corresponding joint names via the `--robot.motor_names` command-line argument.

For example, if your Leader only has 3 joints `[joint1, joint2, gripper]`:

```bash
lerobot-teleoperate \
    --robot.type=dummy_follower \
    --robot.id=dummy_custom \
    --robot.motor_names="['joint1', 'joint2', 'gripper']" \
    --teleop.type=your_custom_leader \
    ...
```

## Notes
*   **Feedback (Observation)**: Since there is no physical hardware, the Dummy arm always returns `0.0` for the current position.
*   **Frequency Control**: It has no hardware latency; its operating frequency depends entirely on the Leader's transmission rate.
*   **Abstract Methods**: This implementation fully satisfies the `Robot` base class requirements including `calibrate`, `configure`, and `is_calibrated`.
