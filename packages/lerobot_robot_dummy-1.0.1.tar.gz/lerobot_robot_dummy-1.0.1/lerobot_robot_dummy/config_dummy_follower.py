from dataclasses import dataclass, field
from lerobot.robots.robot import RobotConfig
from lerobot.cameras import CameraConfig

@RobotConfig.register_subclass("dummy_follower")
@dataclass
class DummyFollowerConfig(RobotConfig):
    # If True, the robot will not print actions to the terminal
    silent: bool = False

    # Default motor names for B601 compatibility
    motor_names: list[str] = field(
        default_factory=lambda: [
            "shoulder_pan",
            "shoulder_lift",
            "elbow_flex",
            "wrist_flex",
            "wrist_yaw",
            "wrist_roll",
            "gripper",
        ]
    )

    cameras: dict[str, CameraConfig] = field(default_factory=dict)

    # 
