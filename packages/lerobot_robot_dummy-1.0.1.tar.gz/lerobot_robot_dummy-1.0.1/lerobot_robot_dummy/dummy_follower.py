import logging
from typing import Any
from lerobot.processor import RobotAction, RobotObservation
from lerobot.robots.robot import Robot
from lerobot.cameras.utils import make_cameras_from_configs

from .config_dummy_follower import DummyFollowerConfig

logger = logging.getLogger(__name__)

class DummyFollower(Robot):
    """
    A simple dummy robot for debugging. 
    It prints received actions instead of sending them to real hardware.
    """
    config_class = DummyFollowerConfig
    name = "dummy_follower"

    def __init__(self, config: DummyFollowerConfig):
        super().__init__(config)
        self.config = config
        self._is_connected = False
        self.cameras = make_cameras_from_configs(config.cameras)

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    @property
    def _cameras_ft(self) -> dict[str, tuple]:
        """Camera features for observation space."""
        return {
            cam: (self.config.cameras[cam].height, self.config.cameras[cam].width, 3)
            for cam in self.cameras
        }
    
    def connect(self, calibrate: bool = True) -> None:
        """Mock connection."""
        logger.info("Connecting Dummy Follower arm...")
        self._is_connected = True
        if calibrate and not self.is_calibrated:
            self.calibrate()
        logger.info("Dummy Follower connected (Debug Mode).")

    @property
    def is_calibrated(self) -> bool:
        """Dummy robot is always 'calibrated'."""
        return True

    def calibrate(self) -> None:
        """Mock calibration (no-op)."""
        logger.info("Calibrating Dummy Follower...")

    def configure(self) -> None:
        """Mock configuration (no-op)."""
        logger.info("Configuring Dummy Follower...")

    @property
    def observation_features(self) -> dict[str, Any]:
        """Define joint state features for compatibility with Leader."""
        features = {}
        for motor in self.config.motor_names:
            features[f"{motor}.pos"] = float
        return features

    @property
    def action_features(self) -> dict[str, Any]:
        """Define action space for compatibility with Leader."""
        return self.observation_features

    def get_observation(self) -> RobotObservation:
        """Return zeroed positions to keep the loop alive."""
        if not self.is_connected:
            raise RuntimeError("Dummy Follower not connected.")
        
        obs = {f"{motor}.pos": 0.0 for motor in self.config.motor_names}
        return obs

    def send_action(self, action: RobotAction) -> RobotAction:
        """The core debugging feature: print the received action (if not silent)."""
        if not self.is_connected:
            raise RuntimeError("Dummy Follower not connected.")

        # Print the action for debugging if not in silent mode
        if not self.config.silent:
            print(f"\n[DEBUG DUMMY] Received Action:")
            for key, value in action.items():
                print(f"  {key}: {value:.4f}")
                if 'torque' in key:
                    print("----")
        
        # Return the action back as standard confirmation
        return action

    def disconnect(self) -> None:
        """Mock disconnection."""
        logger.info("Disconnecting Dummy Follower...")
        self._is_connected = False
        logger.info("Dummy Follower disconnected.")
