from __future__ import annotations

import asyncio
import inspect
import json
import re
from typing import Any, Callable


OPENAI_DIRECT_ADAPTER_KIND = "openai_direct"
OPENAI_DIRECT_NATIVE_CAPABILITIES = [
    "chat_completions",
    "responses",
    "native_tool_calls",
    "runtime_loopback",
]

OPENAI_DIRECT_TRIGGER_ITEM_TYPES = {
    "apply_patch_call",
    "local_shell_call",
    "mcp_approval_request",
    "shell_call",
}

OPENAI_RESPONSES_COMMAND_TYPES = {
    "apply_patch_call",
    "code_interpreter_call",
    "computer_call",
    "custom_tool_call",
    "file_search_call",
    "function_call",
    "image_generation_call",
    "local_shell_call",
    "mcp_approval_request",
    "mcp_call",
    "mcp_list_tools",
    "shell_call",
    "tool_search_call",
    "web_search_call",
}
_CASE_HINT_PATTERN = re.compile(r"\b[A-Z]{2,}-\d+\b")

OPENAI_RESPONSES_OUTPUT_TYPES = {
    "apply_patch_call_output",
    "computer_call_output",
    "custom_tool_call_output",
    "function_call_output",
    "local_shell_call_output",
    "mcp_approval_response",
    "shell_call_output",
    "tool_search_output",
}

_RETRIEVAL_MARKERS = {"fetch", "find", "get", "inspect", "list", "load", "lookup", "query", "read", "retrieve", "search", "view"}
_MUTATION_MARKERS = {"append", "apply", "archive", "cancel", "change", "close", "confirm", "create", "credit", "delete", "disable", "edit", "enable", "exchange", "insert", "issue", "patch", "pause", "persist", "post", "reactivate", "refund", "remember", "reroute", "replace", "route", "save", "send", "set", "skip", "store", "sync", "tag", "update", "upsert", "verify", "write"}
_MEMORY_HINTS = {"memory", "memo", "note", "preference", "remember", "state"}
_RECORD_HINTS = {"account", "address", "application", "asset", "booking", "case", "claim", "contact", "contract", "customer", "delivery", "device", "email", "incident", "invoice", "issue", "lead", "opportunity", "order", "policy", "profile", "record", "reservation", "subscription", "task", "ticket", "user", "workflow"}
_INTERNAL_HINTS = {"approval", "assignment", "checkpoint", "config", "configuration", "context", "flag", "identity", "metadata", "policy", "queue", "review", "route", "routing", "rule", "setting", "settings", "specialist", "stage", "state", "status", "thread", "verification", "workflow"}
_MESSAGE_HINTS = {"alert", "body", "channel", "chat", "comment", "conversation", "dm", "email", "mail", "message", "messages", "notify", "notification", "post", "recipient", "reply", "send", "slack", "subject", "teams", "text", "thread", "to"}
_MEMORY_PROPERTY_HINTS = {"fact", "facts", "key", "memory", "memo", "namespace", "note", "notes", "preference", "preferences", "summary", "value"}
_RECORD_PROPERTY_HINTS = {"account_id", "assignee", "case_id", "contact_id", "customer_id", "fields", "id", "issue_id", "lead_id", "opportunity_id", "order_id", "owner", "patch", "priority", "profile_id", "record_id", "reservation_id", "stage", "state", "status", "subscription_id", "task_id", "ticket_id", "tier", "update", "user_id", "workflow_id"}
_INTERNAL_PROPERTY_HINTS = {"config", "configuration", "enabled", "flag", "flags", "job_id", "metadata", "mode", "policy", "route", "routing", "rule", "rules", "setting", "settings", "stage", "state", "status", "task_id", "workflow_id"}
_MESSAGE_PROPERTY_HINTS = {"address", "bcc", "body", "cc", "channel", "channel_id", "comment", "content", "conversation_id", "dm", "email", "message", "note", "recipient", "recipient_id", "reply", "subject", "text", "thread_id", "to", "user_id"}
_DIRECT_DISPATCHABLE_TYPES = {
    "apply_patch_call",
    "computer_call",
    "custom",
    "custom_tool_call",
    "function",
    "function_call",
    "local_shell_call",
    "shell_call",
}


def install(*, verifiedx=None, framework_version: str | None = None):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    report = vx.activation_report(
        OPENAI_DIRECT_ADAPTER_KIND,
        "native",
        list(OPENAI_DIRECT_NATIVE_CAPABILITIES),
        framework_version=framework_version,
        activation_source="openai_direct_install",
    )
    vx._zero_touch.report = report
    vx._otel_bridge.apply_report(report)
    vx.capture.set_default_adapter(report.to_adapter_context())
    vx.record_activation_diagnostic(report)
    return vx


def attach(client=None, *, verifiedx=None, framework_version: str | None = None):
    vx = install(verifiedx=verifiedx, framework_version=framework_version)
    return client if client is not None else vx


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except TypeError:
            return _jsonable(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _jsonable(value.dict())
    return str(value)


def _jsonish_object(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return {}
        try:
            parsed = json.loads(text)
        except Exception:
            return {"value": text}
        if isinstance(parsed, dict):
            return _jsonable(parsed)
        return {"value": _jsonable(parsed)}
    if isinstance(value, dict):
        return _jsonable(value)
    parsed = _jsonable(value)
    if isinstance(parsed, dict):
        return parsed
    return {"value": parsed}


def _sdk_result_mapping(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        return value
    for attribute in ("model_dump", "to_dict", "dict"):
        method = getattr(value, attribute, None)
        if not callable(method):
            continue
        try:
            mapped = method(mode="json")
        except TypeError:
            try:
                mapped = method()
            except TypeError:
                continue
        if isinstance(mapped, dict):
            return _jsonable(mapped)
    return None


def extract_prompt_messages(input_payload: Any) -> tuple[list[dict[str, Any]], list[str]]:
    messages: list[dict[str, Any]] = []
    tool_call_ids: list[str] = []

    if isinstance(input_payload, str):
        text = input_payload.strip()
        if text:
            messages.append({"role": "user", "content": text})
        return messages, tool_call_ids

    if isinstance(input_payload, dict):
        items = [input_payload]
    elif isinstance(input_payload, list):
        items = input_payload
    else:
        return messages, tool_call_ids

    for item in items:
        if isinstance(item, str):
            text = item.strip()
            if text:
                messages.append({"role": "user", "content": text})
            continue
        if not isinstance(item, dict):
            continue

        role = str(item.get("role") or "").strip().lower()
        if role in {"user", "system", "developer"}:
            content_text = _content_text(item.get("content"))
            if content_text:
                messages.append({"role": role, "content": content_text})
        call_id = item.get("call_id")
        if isinstance(call_id, str) and call_id.strip():
            tool_call_ids.append(call_id.strip())

    return messages, tool_call_ids


def case_thread_hint(messages: list[dict[str, Any]] | None) -> str | None:
    for message in messages or []:
        content = str(message.get("content") or "")
        match = _CASE_HINT_PATTERN.search(content)
        if not match:
            continue
        normalized = re.sub(r"[^a-z0-9]+", "_", match.group(0).lower()).strip("_")
        if normalized:
            return f"openai_direct_{normalized}"
    return None


def is_chat_continuation(messages: Any) -> bool:
    return isinstance(messages, list) and any(
        str((message or {}).get("role") or "").strip().lower() == "tool"
        for message in messages
        if isinstance(message, dict)
    )


def normalize_chat_completion_tool_calls(
    result: Any,
    *,
    result_mapping: Callable[[Any], dict[str, Any] | None],
    normalize_tool_arguments: Callable[[Any], dict[str, Any]],
) -> list[dict[str, Any]]:
    mapped = result_mapping(result) or {}
    choices = mapped.get("choices")
    if not isinstance(choices, list):
        choices = getattr(result, "choices", None) or []
    if not choices:
        return []

    choice = choices[0]
    choice_mapping = choice if isinstance(choice, dict) else (result_mapping(choice) or {})
    message = choice_mapping.get("message")
    if message is None and hasattr(choice, "message"):
        message = result_mapping(getattr(choice, "message", None)) or {}
    if not isinstance(message, dict):
        return []

    raw_tool_calls = message.get("tool_calls") or []
    legacy_function_call = message.get("function_call")
    if not raw_tool_calls and isinstance(legacy_function_call, dict):
        raw_tool_calls = [{"function": legacy_function_call, "type": "function"}]

    normalized_calls: list[dict[str, Any]] = []
    for item in raw_tool_calls:
        call = item if isinstance(item, dict) else (result_mapping(item) or {})
        call_type = str(call.get("type") or "function").strip().lower() or "function"
        function = call.get("function")
        custom = call.get("custom")
        if not isinstance(function, dict):
            function = result_mapping(function) or {}
        if not isinstance(custom, dict):
            custom = result_mapping(custom) or {}

        if call_type == "custom":
            tool_name = custom.get("name") or call.get("name")
            if not isinstance(tool_name, str) or not tool_name.strip():
                continue
            raw_args = normalize_tool_arguments(custom.get("input") if "input" in custom else call.get("input"))
        else:
            tool_name = function.get("name") or call.get("name")
            if not isinstance(tool_name, str) or not tool_name.strip():
                continue
            raw_args = normalize_tool_arguments(
                function.get("arguments") if "arguments" in function else call.get("arguments")
            )

        normalized_calls.append(
            {
                "tool_name": tool_name.strip(),
                "raw_name": tool_name.strip(),
                "tool_call_id": call.get("id") or call.get("call_id"),
                "native_call_type": call_type,
                "source": f"openai.chat.completions.message.{call_type}",
                "args": raw_args,
                "raw_args": raw_args,
            }
        )
    return normalized_calls


def normalize_responses_tool_calls(
    result: Any,
    *,
    result_mapping: Callable[[Any], dict[str, Any] | None],
    normalize_tool_arguments: Callable[[Any], dict[str, Any]],
    include_outputs: bool = False,
) -> list[dict[str, Any]]:
    mapped = result_mapping(result) or {}
    output = mapped.get("output")
    if not isinstance(output, list):
        output = getattr(result, "output", None) or []

    allowed_types = set(OPENAI_RESPONSES_COMMAND_TYPES)
    if include_outputs:
        allowed_types.update(OPENAI_RESPONSES_OUTPUT_TYPES)

    normalized_calls: list[dict[str, Any]] = []
    for item in output:
        payload = item if isinstance(item, dict) else (result_mapping(item) or {})
        if not isinstance(payload, dict):
            continue
        item_type = str(payload.get("type") or "").strip().lower()
        if not item_type or item_type not in allowed_types:
            continue

        raw_name = _responses_raw_name(payload, item_type)
        if not raw_name:
            continue
        raw_args = _responses_raw_args(payload, item_type, normalize_tool_arguments)

        record = {
            "tool_name": raw_name,
            "raw_name": raw_name,
            "tool_call_id": payload.get("call_id") or payload.get("id"),
            "native_call_type": item_type,
            "source": f"openai.responses.output.{item_type}",
            "args": raw_args,
            "raw_args": raw_args,
        }
        namespace = payload.get("namespace")
        if isinstance(namespace, str) and namespace.strip():
            record["namespace"] = namespace.strip()
        approval_request_id = _approval_request_id(payload, item_type)
        if approval_request_id:
            record["approval_request_id"] = approval_request_id
        normalized_calls.append(record)
    return normalized_calls


def describe_pending_action(
    *,
    raw_name: str,
    native_call_type: str,
    args: dict[str, Any],
    command: str,
    dispatch_target: Callable[[str, dict[str, Any]], str],
) -> dict[str, Any] | None:
    item_type = str(native_call_type or "").strip().lower()
    if item_type not in OPENAI_DIRECT_TRIGGER_ITEM_TYPES and not (
        item_type == "mcp_call" and str(args.get("approval_request_id") or "").strip()
    ):
        return None

    target = dispatch_target(raw_name or item_type, args)
    if item_type == "apply_patch_call":
        return {
            "surface": "file_write",
            "operation": raw_name or item_type,
            "target": str(args.get("path") or args.get("file") or target),
            "method": str(args.get("operation_type") or command or "write"),
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": False,
        }
    if item_type in {"shell_call", "local_shell_call"}:
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or item_type,
            "target": command or target or item_type,
            "method": "CALL",
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    if item_type == "mcp_approval_request":
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or item_type,
            "target": str(
                args.get("approval_request_id")
                or args.get("server_label")
                or args.get("server")
                or target
            ),
            "method": "CALL",
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    if item_type == "mcp_call":
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or item_type,
            "target": str(args.get("server_label") or args.get("server") or target),
            "method": "CALL",
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    return None


def _responses_raw_name(payload: dict[str, Any], item_type: str) -> str:
    if item_type in {"function_call", "custom_tool_call", "mcp_call", "mcp_approval_request"}:
        name = payload.get("name")
        if isinstance(name, str) and name.strip():
            return name.strip()
    return item_type.strip()


def _responses_raw_args(
    payload: dict[str, Any],
    item_type: str,
    normalize_tool_arguments: Callable[[Any], dict[str, Any]],
) -> dict[str, Any]:
    if item_type == "function_call":
        args = normalize_tool_arguments(payload.get("arguments"))
        return _merge_optional(args, namespace=payload.get("namespace"))
    if item_type == "custom_tool_call":
        args = normalize_tool_arguments(payload.get("input"))
        return _merge_optional(args, namespace=payload.get("namespace"))
    if item_type in {"mcp_call", "mcp_approval_request"}:
        args = normalize_tool_arguments(payload.get("arguments"))
        return _merge_optional(
            args,
            server_label=payload.get("server_label"),
            approval_request_id=_approval_request_id(payload, item_type),
            namespace=payload.get("namespace"),
        )
    if item_type == "mcp_list_tools":
        return _merge_optional({}, server_label=payload.get("server_label"))
    if item_type == "tool_search_call":
        return normalize_tool_arguments(payload.get("arguments"))
    if item_type == "tool_search_output":
        return {}
    if item_type == "file_search_call":
        queries = payload.get("queries")
        return {"queries": list(queries)} if isinstance(queries, list) else {}
    if item_type == "web_search_call":
        action = payload.get("action")
        return action if isinstance(action, dict) else {}
    if item_type == "shell_call":
        action = payload.get("action") if isinstance(payload.get("action"), dict) else {}
        if not action and isinstance(payload.get("input"), dict):
            action = payload.get("input")
        return _merge_optional(
            {"commands": list(action.get("commands") or [])},
            timeout_ms=action.get("timeout_ms"),
            max_output_length=action.get("max_output_length"),
            environment=payload.get("environment"),
        )
    if item_type == "local_shell_call":
        action = payload.get("action") if isinstance(payload.get("action"), dict) else {}
        if not action and isinstance(payload.get("input"), dict):
            action = payload.get("input")
        return _merge_optional(
            {"command": list(action.get("command") or [])},
            env=action.get("env"),
            timeout_ms=action.get("timeout_ms"),
            user=action.get("user"),
            working_directory=action.get("working_directory"),
        )
    if item_type == "apply_patch_call":
        operation = payload.get("operation") if isinstance(payload.get("operation"), dict) else {}
        return _merge_optional(
            {},
            operation_type=operation.get("type"),
            path=operation.get("path"),
            diff=operation.get("diff"),
        )
    if item_type == "computer_call":
        action = payload.get("action") if isinstance(payload.get("action"), dict) else {}
        pending_safety_checks = payload.get("pending_safety_checks")
        return _merge_optional(
            dict(action),
            pending_safety_checks=pending_safety_checks if isinstance(pending_safety_checks, list) else None,
        )
    if item_type == "code_interpreter_call":
        return _merge_optional({}, code=payload.get("code"), container_id=payload.get("container_id"))
    if item_type.startswith("mcp_approval_response") or item_type.endswith("_output"):
        return {}
    return {}


def _approval_request_id(payload: dict[str, Any], item_type: str) -> str | None:
    if item_type == "mcp_approval_request":
        value = payload.get("id")
    else:
        value = payload.get("approval_request_id")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _merge_optional(base: dict[str, Any], **values: Any) -> dict[str, Any]:
    merged = dict(base)
    for key, value in values.items():
        if value is None:
            continue
        merged[key] = value
    return merged


def _normalized_tokens(*values: Any) -> set[str]:
    tokens: set[str] = set()
    for value in values:
        normalized = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value or ""))
        normalized = re.sub(r"([A-Z]+)([A-Z][a-z0-9]+)", r"\1 \2", normalized)
        for token in normalized.lower().replace("-", "_").split():
            for nested in token.replace(".", "_").split("_"):
                nested = nested.strip()
                if nested:
                    tokens.add(nested)
    return tokens


def normalize_tool_definitions(raw_tools: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_tools, list):
        return []
    normalized: list[dict[str, Any]] = []
    for tool in raw_tools:
        if not isinstance(tool, dict):
            continue
        function_payload = tool.get("function") if isinstance(tool.get("function"), dict) else {}
        custom_payload = tool.get("custom") if isinstance(tool.get("custom"), dict) else {}
        tool_name = str(
            function_payload.get("name")
            or custom_payload.get("name")
            or tool.get("name")
            or ""
        ).strip()
        if not tool_name:
            continue
        schema = _jsonable(
            function_payload.get("parameters")
            or custom_payload.get("input_schema")
            or tool.get("parameters")
            or tool.get("input_schema")
            or {"type": "object", "additionalProperties": True}
        )
        docstring = str(
            function_payload.get("description")
            or custom_payload.get("description")
            or tool.get("description")
            or ""
        ).strip() or None
        native_tool_type = str(tool.get("type") or ("custom" if custom_payload else "function")).strip()
        property_names = list((schema.get("properties") or {}).keys()) if isinstance(schema, dict) else []
        tokens = _normalized_tokens(tool_name, docstring or "", *property_names)
        has_retrieval = any(marker in tokens for marker in _RETRIEVAL_MARKERS)
        has_mutation = any(marker in tokens for marker in _MUTATION_MARKERS)
        metadata: dict[str, Any] = {
            **(_jsonable(tool.get("metadata")) if isinstance(tool.get("metadata"), dict) else {}),
            "native_tool_type": native_tool_type,
        }
        if has_retrieval and not has_mutation:
            metadata["read_only"] = True
            metadata["retrieval_like"] = True
        normalized.append(
            {
                "tool_name": tool_name,
                "schema": schema,
                "docstring": docstring,
                "metadata": metadata,
            }
        )
    return normalized


def normalize_responses_tool_definition(tool: Any) -> Any:
    if not isinstance(tool, dict):
        return tool
    tool_type = str(tool.get("type") or "").strip().lower()
    function_payload = tool.get("function") if isinstance(tool.get("function"), dict) else None
    custom_payload = tool.get("custom") if isinstance(tool.get("custom"), dict) else None
    if tool_type == "function" and function_payload:
        normalized = {key: _jsonable(value) for key, value in tool.items() if key != "function"}
        normalized["type"] = "function"
        normalized["name"] = str(function_payload.get("name") or tool.get("name") or "").strip()
        description = function_payload.get("description") or tool.get("description")
        if description is not None:
            normalized["description"] = str(description).strip()
        parameters = function_payload.get("parameters") or tool.get("parameters")
        if parameters is not None:
            normalized["parameters"] = _jsonable(parameters)
        if function_payload.get("strict") is not None or tool.get("strict") is not None:
            normalized["strict"] = function_payload.get("strict") if function_payload.get("strict") is not None else tool.get("strict")
        return normalized
    if tool_type == "custom" and custom_payload:
        normalized = {key: _jsonable(value) for key, value in tool.items() if key != "custom"}
        normalized["type"] = "custom"
        normalized["name"] = str(custom_payload.get("name") or tool.get("name") or "").strip()
        description = custom_payload.get("description") or tool.get("description")
        if description is not None:
            normalized["description"] = str(description).strip()
        input_schema = (
            custom_payload.get("input_schema")
            or custom_payload.get("parameters")
            or tool.get("input_schema")
            or tool.get("parameters")
        )
        if input_schema is not None:
            normalized["input_schema"] = _jsonable(input_schema)
        for field in ("format", "grammar", "strict"):
            if custom_payload.get(field) is not None or tool.get(field) is not None:
                normalized[field] = _jsonable(
                    custom_payload.get(field) if custom_payload.get(field) is not None else tool.get(field)
                )
        return normalized
    return _jsonable(tool)


def normalize_responses_request(body: Any) -> Any:
    if not isinstance(body, dict):
        return body
    tools = body.get("tools")
    if not isinstance(tools, list) or not tools:
        return body
    return {
        **body,
        "tools": [normalize_responses_tool_definition(tool) for tool in tools],
    }


def _tool_definition_map(tool_definitions: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {
        str(definition.get("tool_name") or "").strip(): definition
        for definition in tool_definitions
        if isinstance(definition, dict) and str(definition.get("tool_name") or "").strip()
    }


def _direct_tool_kind(definition: dict[str, Any], args: dict[str, Any]) -> str | None:
    metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
    if bool(metadata.get("read_only")) or bool(metadata.get("retrieval_like")):
        return None
    property_names = list((definition.get("schema") or {}).get("properties", {}).keys()) if isinstance(definition.get("schema"), dict) else []
    tokens = _normalized_tokens(definition.get("tool_name"), definition.get("docstring") or "", *property_names)
    arg_tokens = _normalized_tokens(*args.keys())
    semantic_class = str(metadata.get("semantic_class") or "").strip().lower()
    has_mutation = any(marker in tokens or marker in arg_tokens for marker in _MUTATION_MARKERS)
    has_memory = any(marker in tokens for marker in _MEMORY_HINTS) or any(name in _MEMORY_PROPERTY_HINTS for name in property_names)
    has_record = any(marker in tokens or marker in arg_tokens for marker in _RECORD_HINTS) or any(name in _RECORD_PROPERTY_HINTS for name in property_names) or any(name in _RECORD_PROPERTY_HINTS for name in args.keys())
    has_internal = any(marker in tokens or marker in arg_tokens for marker in _INTERNAL_HINTS) or any(name in _INTERNAL_PROPERTY_HINTS for name in property_names) or any(name in _INTERNAL_PROPERTY_HINTS for name in args.keys())
    has_message = any(marker in tokens for marker in _MESSAGE_HINTS) or any(name in _MESSAGE_PROPERTY_HINTS for name in property_names) or any(name in _MESSAGE_PROPERTY_HINTS for name in args.keys())
    lowered_property_names = {str(name).strip().lower() for name in property_names}
    lowered_arg_names = {str(name).strip().lower() for name in args.keys()}
    has_memory_contract = {"namespace", "key", "value"}.issubset(lowered_property_names | lowered_arg_names)
    if semantic_class == "memory_mutation":
        return "memory_write"
    if semantic_class == "record_mutation":
        return "record_mutation"
    if semantic_class == "system_mutation":
        return "system_change"
    if semantic_class == "external_message_send":
        return "external_message_send"
    if has_message:
        return "external_message_send"
    if has_memory and (has_mutation or has_memory_contract):
        return "memory_write"
    if has_record and has_mutation:
        return "record_mutation"
    if has_internal and has_mutation:
        return "system_change"
    if bool(metadata.get("needs_approval")):
        return "system_change"
    return None


def _call_semantic_class(definition: dict[str, Any], args: dict[str, Any]) -> str | None:
    metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
    semantic_class = str(metadata.get("semantic_class") or "").strip().lower()
    if semantic_class:
        return semantic_class
    if bool(metadata.get("read_only")) or bool(metadata.get("retrieval_like")):
        return "internal_retrieval"
    tool_kind = _direct_tool_kind(definition, args)
    if tool_kind == "memory_write":
        return "memory_mutation"
    if tool_kind == "record_mutation":
        return "record_mutation"
    if tool_kind == "system_change":
        return "system_mutation"
    if tool_kind == "external_message_send":
        return "external_message_send"
    return None


def _emit_tool_result_capture(vx, *, tool_name: str, payload: dict[str, Any], call: dict[str, Any], definition: dict[str, Any], result_payload: Any) -> None:
    semantic_class = _call_semantic_class(definition, payload)
    if semantic_class == "memory_read":
        object_type = "memory_record"
    elif semantic_class == "internal_retrieval":
        object_type = "internal_retrieval"
    else:
        object_type = "tool_result"
    object_payload = vx.capture.build_object(
        object_type,
        {
            "raw_name": tool_name,
            "source": call.get("source"),
            "tool_call_id": call.get("tool_call_id"),
            "input": payload,
            "output": _jsonable(result_payload),
        },
        source_lineage=["openai_direct", object_type],
    )
    if object_type == "internal_retrieval":
        vx.capture.retrieve(object_payload, query=tool_name)
    elif object_type == "memory_record":
        namespace = str(payload.get("namespace") or tool_name)
        key = str(payload.get("key") or payload.get("id") or payload.get("record_id") or "value")
        vx.capture.memory_read(object_payload, namespace=namespace, key=key)
    else:
        vx.capture.tool_call(object_payload, tool_name=tool_name)
    vx.note_observation(
        object_type="external_retrieval" if semantic_class in {"internal_retrieval", "memory_read"} else object_type,
        source_hint=tool_name,
    )


def _pending_memory_write(tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "namespace": payload.get("namespace") or tool_name,
        "key": payload.get("key") or payload.get("id") or payload.get("record_id") or payload.get("name") or "value",
        "value": payload.get("value") or payload.get("patch") or payload.get("update") or payload.get("fields") or payload,
        "write_kind": payload.get("command") or payload.get("action") or payload.get("operation") or "write",
    }


def _pending_action(tool_name: str, payload: dict[str, Any], action_class: str) -> dict[str, Any]:
    target = (
        payload.get("workflow_id")
        or payload.get("record_id")
        or payload.get("customer_id")
        or payload.get("ticket_id")
        or payload.get("id")
        or payload.get("recipient")
        or payload.get("email")
        or payload.get("channel")
        or payload.get("url")
        or tool_name
    )
    return {
        "operation": tool_name,
        "target": {
            "target_class": "record" if action_class == "record_mutation" else ("message_endpoint" if action_class == "external_message_send" else "internal_state"),
            "target_identifier": str(target),
            "destination": str(target),
            "system_of_record": "tool_record" if action_class == "record_mutation" else ("tool_message" if action_class == "external_message_send" else "tool_state"),
        },
        "trust_boundary_crossing": bool(
            payload.get("url")
            or payload.get("uri")
            or payload.get("recipient")
            or payload.get("email")
            or payload.get("address")
            or payload.get("external")
            or payload.get("public")
            or payload.get("customer_visible")
        ),
        "executable_payload": _jsonable(payload),
    }


def response_tool_output_item(call: dict[str, Any] | str, payload: Any) -> dict[str, Any]:
    call_id = call if isinstance(call, str) else call.get("tool_call_id")
    native_call_type = str(call.get("native_call_type") or "") if isinstance(call, dict) else ""
    return {
        "type": _response_output_type(native_call_type),
        "call_id": call_id,
        "output": json.dumps(_jsonable(payload)),
    }


def chat_tool_result_message(call: dict[str, Any] | str, payload: Any) -> dict[str, Any]:
    tool_call_id = call if isinstance(call, str) else call.get("tool_call_id")
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": json.dumps(_jsonable(payload)),
    }


def _handler_from_registry(tool_handlers: Any, tool_name: str) -> Callable | None:
    if isinstance(tool_handlers, dict):
        handler = tool_handlers.get(tool_name)
        if callable(handler):
            return handler
    return None


def _execute_sync(value: Any):
    if inspect.isawaitable(value):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(value)
        raise RuntimeError(
            "OpenAI direct async tool handler returned an awaitable inside a running event loop. "
            "Use async_dispatch() in async contexts."
        )
    return value


def _response_output_type(native_call_type: str) -> str:
    normalized = str(native_call_type or "").strip().lower()
    if normalized == "custom":
        normalized = "custom_tool_call"
    elif normalized == "function":
        normalized = "function_call"
    if normalized in {
        "apply_patch_call",
        "computer_call",
        "custom_tool_call",
        "function_call",
        "local_shell_call",
        "shell_call",
    }:
        return f"{normalized}_output"
    return "function_call_output"


def create_tool_dispatcher(
    *,
    tool_handlers: dict[str, Callable],
    tools: list[dict[str, Any]],
    verifiedx=None,
    framework_version: str | None = None,
    mode: str = "auto",
):
    vx = install(verifiedx=verifiedx, framework_version=framework_version)
    tool_definitions = normalize_tool_definitions(tools)
    definitions_by_name = _tool_definition_map(tool_definitions)

    def _call_surface(result: Any) -> tuple[str, list[dict[str, Any]]]:
        if isinstance(getattr(result, "output", None), list) or isinstance((result if isinstance(result, dict) else {}).get("output"), list):
            return "responses", normalize_responses_tool_calls(
                result,
                result_mapping=_sdk_result_mapping,
                normalize_tool_arguments=_jsonish_object,
            )
        return "chat", normalize_chat_completion_tool_calls(
            result,
            result_mapping=_sdk_result_mapping,
            normalize_tool_arguments=_jsonish_object,
        )

    async def _invoke_handler_async(handler: Callable, payload: dict[str, Any]) -> Any:
        value = handler(payload)
        if inspect.isawaitable(value):
            return await value
        return value

    def dispatch_tool_calls(result: Any, *, surface: str | None = None) -> list[dict[str, Any]]:
        effective_surface, calls = _call_surface(result)
        effective_surface = surface or (mode if mode != "auto" else effective_surface)
        outputs: list[dict[str, Any]] = []
        for call in calls:
            native_call_type = str(call.get("native_call_type") or "").strip().lower()
            if native_call_type not in _DIRECT_DISPATCHABLE_TYPES:
                continue
            tool_name = str(call.get("raw_name") or "").strip()
            if not tool_name:
                continue
            handler = _handler_from_registry(tool_handlers, tool_name)
            if not callable(handler):
                raise KeyError(f"No OpenAI direct tool handler registered for {tool_name}")
            definition = definitions_by_name.get(tool_name) or {
                "tool_name": tool_name,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "metadata": {},
            }
            action_class = _direct_tool_kind(definition, dict(call.get("raw_args") or {}))
            payload = dict(call.get("raw_args") or {})
            tool_descriptor = {
                "tool_name": tool_name,
                "schema": definition.get("schema") or {"type": "object", "additionalProperties": True},
                "docstring": definition.get("docstring"),
                "args": payload,
                "metadata": {
                    "raw_name": tool_name,
                    "raw_args": payload,
                    "native_call_type": call.get("native_call_type"),
                    "tool_call_id": call.get("tool_call_id"),
                },
            }
            try:
                if action_class == "memory_write":
                    pending = _pending_memory_write(tool_name, payload)
                    namespace = str(pending.get("namespace") or tool_name)
                    key = str(pending.get("key") or "value")

                    def execute_memory():
                        return _execute_sync(handler(payload))

                    result_payload = vx.zero_touch.intercept_boundary(
                        surface="memory_write",
                        operation=tool_name,
                        target=f"{namespace}/{key}",
                        method="WRITE",
                        transport_args=pending,
                        boundary_kind="memory_write",
                        action_class="memory_write",
                        trust_boundary_crossing=False,
                        pending_effect=pending,
                        tool_descriptor=tool_descriptor,
                        execute=execute_memory,
                    )
                else:
                    native_pending = describe_pending_action(
                        raw_name=tool_name,
                        native_call_type=native_call_type,
                        args=payload,
                        command=str(payload.get("command") or payload.get("operation_type") or ""),
                        dispatch_target=lambda current_name, current_args: str(
                            current_args.get("server_label")
                            or current_args.get("server")
                            or current_args.get("path")
                            or current_args.get("file")
                            or current_name
                        ),
                    )
                    if action_class in {"record_mutation", "system_change", "external_message_send"}:
                        pending = _pending_action(tool_name, payload, action_class)
                    elif native_pending is not None:
                        pending = native_pending
                        action_class = str(native_pending.get("action_class") or "system_change")
                    else:
                        pending = None

                    if pending is not None:
                        def execute_action():
                            return _execute_sync(handler(payload))

                        result_payload = vx.zero_touch.intercept_boundary(
                            surface=str(pending.get("surface") or "tool_dispatch"),
                            operation=str(pending.get("operation") or tool_name),
                            target=str(pending.get("target") or tool_name),
                            method=str(pending.get("method") or "CALL"),
                            transport_args=dict(pending.get("transport_args") or payload),
                            boundary_kind=str(pending.get("boundary_kind") or "action_execute"),
                            action_class=action_class,
                            trust_boundary_crossing=bool(pending.get("trust_boundary_crossing")),
                            pending_effect=dict(pending.get("transport_args") or payload),
                            tool_descriptor=tool_descriptor,
                            execute=execute_action,
                        )
                    else:
                        result_payload = _execute_sync(handler(payload))
            except Exception as error:
                error_result = vx.handle_runtime_tool_error(error)
                if error_result is None:
                    raise
                result_payload = error_result
            _emit_tool_result_capture(
                vx,
                tool_name=tool_name,
                payload=payload,
                call=call,
                definition=definition,
                result_payload=result_payload,
            )
            if effective_surface == "chat":
                outputs.append(chat_tool_result_message(call, result_payload))
            else:
                outputs.append(response_tool_output_item(call, result_payload))
        return outputs

    async def dispatch_tool_calls_async(result: Any, *, surface: str | None = None) -> list[dict[str, Any]]:
        effective_surface, calls = _call_surface(result)
        effective_surface = surface or (mode if mode != "auto" else effective_surface)
        outputs: list[dict[str, Any]] = []
        for call in calls:
            native_call_type = str(call.get("native_call_type") or "").strip().lower()
            if native_call_type not in _DIRECT_DISPATCHABLE_TYPES:
                continue
            tool_name = str(call.get("raw_name") or "").strip()
            if not tool_name:
                continue
            handler = _handler_from_registry(tool_handlers, tool_name)
            if not callable(handler):
                raise KeyError(f"No OpenAI direct tool handler registered for {tool_name}")
            definition = definitions_by_name.get(tool_name) or {
                "tool_name": tool_name,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "metadata": {},
            }
            action_class = _direct_tool_kind(definition, dict(call.get("raw_args") or {}))
            payload = dict(call.get("raw_args") or {})
            tool_descriptor = {
                "tool_name": tool_name,
                "schema": definition.get("schema") or {"type": "object", "additionalProperties": True},
                "docstring": definition.get("docstring"),
                "args": payload,
                "metadata": {
                    "raw_name": tool_name,
                    "raw_args": payload,
                    "native_call_type": call.get("native_call_type"),
                    "tool_call_id": call.get("tool_call_id"),
                },
            }
            try:
                if action_class == "memory_write":
                    pending = _pending_memory_write(tool_name, payload)
                    namespace = str(pending.get("namespace") or tool_name)
                    key = str(pending.get("key") or "value")

                    async def execute_memory():
                        return await _invoke_handler_async(handler, payload)

                    result_payload = await vx.zero_touch.intercept_boundary_async(
                        surface="memory_write",
                        operation=tool_name,
                        target=f"{namespace}/{key}",
                        method="WRITE",
                        transport_args=pending,
                        boundary_kind="memory_write",
                        action_class="memory_write",
                        trust_boundary_crossing=False,
                        pending_effect=pending,
                        tool_descriptor=tool_descriptor,
                        execute=execute_memory,
                    )
                else:
                    native_pending = describe_pending_action(
                        raw_name=tool_name,
                        native_call_type=native_call_type,
                        args=payload,
                        command=str(payload.get("command") or payload.get("operation_type") or ""),
                        dispatch_target=lambda current_name, current_args: str(
                            current_args.get("server_label")
                            or current_args.get("server")
                            or current_args.get("path")
                            or current_args.get("file")
                            or current_name
                        ),
                    )
                    if action_class in {"record_mutation", "system_change", "external_message_send"}:
                        pending = _pending_action(tool_name, payload, action_class)
                    elif native_pending is not None:
                        pending = native_pending
                        action_class = str(native_pending.get("action_class") or "system_change")
                    else:
                        pending = None

                    if pending is not None:
                        async def execute_action():
                            return await _invoke_handler_async(handler, payload)

                        result_payload = await vx.zero_touch.intercept_boundary_async(
                            surface=str(pending.get("surface") or "tool_dispatch"),
                            operation=str(pending.get("operation") or tool_name),
                            target=str(pending.get("target") or tool_name),
                            method=str(pending.get("method") or "CALL"),
                            transport_args=dict(pending.get("transport_args") or payload),
                            boundary_kind=str(pending.get("boundary_kind") or "action_execute"),
                            action_class=action_class,
                            trust_boundary_crossing=bool(pending.get("trust_boundary_crossing")),
                            pending_effect=dict(pending.get("transport_args") or payload),
                            tool_descriptor=tool_descriptor,
                            execute=execute_action,
                        )
                    else:
                        result_payload = await _invoke_handler_async(handler, payload)
            except Exception as error:
                error_result = vx.handle_runtime_tool_error(error)
                if error_result is None:
                    raise
                result_payload = error_result
            _emit_tool_result_capture(
                vx,
                tool_name=tool_name,
                payload=payload,
                call=call,
                definition=definition,
                result_payload=result_payload,
            )
            if effective_surface == "chat":
                outputs.append(chat_tool_result_message(call, result_payload))
            else:
                outputs.append(response_tool_output_item(call, result_payload))
        return outputs

    dispatch_tool_calls.async_dispatch = dispatch_tool_calls_async  # type: ignore[attr-defined]
    return dispatch_tool_calls


def _content_text(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = [_content_text(part) for part in content]
        return " ".join(part for part in parts if part).strip()
    if isinstance(content, dict):
        text_candidates = [
            content.get("text"),
            content.get("content"),
            content.get("value"),
        ]
        for candidate in text_candidates:
            text = _content_text(candidate)
            if text:
                return text
        if content.get("type") == "output_text":
            text = _content_text(content.get("text"))
            if text:
                return text
    return ""
