from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

from .v4_loopback import hash_json

V4_GUARD_REGISTRY: list[dict[str, Any]] = [
    {
        "provider": "openai",
        "framework": "generic_python",
        "raw_name": "apply_patch_call",
        "surface": "file",
        "guard_class": "system_change",
        "match_rule": {"methods": ["write", "WRITE", "CALL"]},
    },
    {
        "provider": "openai",
        "framework": "generic_python",
        "raw_name": "computer_call",
        "surface": "browser",
        "guard_class": "system_change",
        "match_rule": {"methods": ["CALL"]},
    },
    {
        "provider": "openai",
        "framework": "generic_python",
        "raw_name": "local_shell_call",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["CALL"]},
    },
    {
        "provider": "openai",
        "framework": "generic_python",
        "raw_name": "mcp_approval_request",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["CALL"]},
    },
    {
        "provider": "openai",
        "framework": "generic_python",
        "raw_name": "mcp_call",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["CALL"]},
    },
    {
        "provider": "openai",
        "framework": "generic_python",
        "raw_name": "shell_call",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["CALL"]},
    },
    {
        "provider": "anthropic",
        "framework": "anthropic_direct",
        "raw_name": "memory_20250818",
        "surface": "memory_write",
        "guard_class": "memory_write",
        "match_rule": {"methods": ["create", "delete", "insert", "rename", "str_replace", "write"]},
    },
    {
        "provider": "anthropic",
        "framework": "anthropic_direct",
        "raw_name": "text_editor_20250124",
        "surface": "file",
        "guard_class": "system_change",
        "match_rule": {"methods": ["create", "delete", "insert", "rename", "str_replace", "write"]},
    },
    {
        "provider": "anthropic",
        "framework": "anthropic_direct",
        "raw_name": "text_editor_20250728",
        "surface": "file",
        "guard_class": "system_change",
        "match_rule": {"methods": ["create", "delete", "insert", "rename", "str_replace", "write"]},
    },
    {
        "provider": "anthropic",
        "framework": "claude_agent_sdk",
        "raw_name": "Bash",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["CALL"]},
    },
    {
        "provider": "anthropic",
        "framework": "claude_agent_sdk",
        "raw_name": "Write",
        "surface": "file",
        "guard_class": "system_change",
        "match_rule": {"methods": ["write", "CALL"]},
    },
    {
        "provider": "anthropic",
        "framework": "claude_agent_sdk",
        "raw_name": "Edit",
        "surface": "file",
        "guard_class": "system_change",
        "match_rule": {"methods": ["edit", "CALL"]},
    },
    {
        "provider": "anthropic",
        "framework": "claude_agent_sdk",
        "raw_name": "MultiEdit",
        "surface": "file",
        "guard_class": "system_change",
        "match_rule": {"methods": ["multiedit", "CALL"]},
    },
    {
        "provider": "anthropic",
        "framework": "claude_agent_sdk",
        "raw_name": "NotebookEdit",
        "surface": "file",
        "guard_class": "system_change",
        "match_rule": {"methods": ["notebookedit", "CALL"]},
    },
    {
        "provider": "generic",
        "framework": "langgraph",
        "raw_name": "langgraph.Command.update",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["update", "CALL"]},
    },
    {
        "provider": "generic",
        "framework": "langgraph",
        "raw_name": "langgraph.checkpointer.put",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["put", "CALL"]},
    },
    {
        "provider": "generic",
        "framework": "langgraph",
        "raw_name": "langgraph.checkpointer.put_writes",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["put_writes", "CALL"]},
    },
    {
        "provider": "generic",
        "framework": "langgraph",
        "raw_name": "langgraph.graph.update_state",
        "surface": "tool",
        "guard_class": "system_change",
        "match_rule": {"methods": ["update_state", "CALL"]},
    },
    {
        "provider": "generic",
        "framework": "langgraph",
        "raw_name": "langgraph.store.delete",
        "surface": "memory_write",
        "guard_class": "memory_write",
        "match_rule": {"methods": ["delete", "CALL"]},
    },
    {
        "provider": "generic",
        "framework": "langgraph",
        "raw_name": "langgraph.store.put",
        "surface": "memory_write",
        "guard_class": "memory_write",
        "match_rule": {"methods": ["put", "write", "WRITE", "CALL"]},
    },
    {
        "provider": "generic",
        "framework": "generic_python",
        "raw_name": "requests.sessions.Session.request",
        "surface": "http",
        "guard_class": "record_mutation",
        "match_rule": {"methods": ["POST", "PATCH", "PUT", "DELETE"]},
    },
    {
        "provider": "generic",
        "framework": "generic_python",
        "raw_name": "memory_write",
        "surface": "memory_write",
        "guard_class": "memory_write",
        "match_rule": {"methods": ["write", "WRITE"]},
    },
    {
        "provider": "generic",
        "framework": "generic_python",
        "raw_name": "sqlalchemy.Connection.execute",
        "surface": "db",
        "guard_class": "system_change",
        "match_rule": {"methods": ["INSERT", "UPDATE", "DELETE", "PATCH", "PUT"]},
    },
    {
        "provider": "generic",
        "framework": "generic_python",
        "raw_name": "kombu.Producer.publish",
        "surface": "queue",
        "guard_class": "outbound_send",
        "match_rule": {"methods": ["PUBLISH"]},
    },
]


def _stable_surface(surface: Any) -> str:
    normalized = str(surface or "").strip()
    if normalized == "memory_write":
        return "memory_write"
    if normalized in {"http", "browser", "db", "file", "queue", "tool"}:
        return normalized
    return "tool"


def pending_action_fingerprint_from_observed_boundary(observed_boundary: dict[str, Any] | None) -> str | None:
    if not isinstance(observed_boundary, dict):
        return None
    downstream_trace = observed_boundary.get("downstream_trace") or {}
    tool = observed_boundary.get("tool") or {}
    pending_action = {
        "raw_name": tool.get("tool_name") or downstream_trace.get("operation") or "unknown",
        "surface": _stable_surface(downstream_trace.get("surface")),
        "method": downstream_trace.get("method"),
        "target": downstream_trace.get("target") or "",
        "raw_args": downstream_trace.get("args") or {},
        "trust_boundary_crossing": bool(downstream_trace.get("trust_boundary_crossing", False)),
    }
    return hash_json(pending_action)


def build_decision_context(
    installer,
    *,
    surface: str,
    operation: str,
    target: str,
    method: str | None,
    transport_args: dict[str, Any],
    boundary_kind: str,
    trust_boundary_crossing: bool | None,
    tool_descriptor: dict[str, Any] | None,
) -> dict[str, Any]:
    conversation_window = installer.current_conversation_window(
        tool_descriptor=tool_descriptor,
        boundary_kind=boundary_kind,
        surface=surface,
        target=target,
        transport_args=transport_args,
    )
    provider, framework = infer_provider_framework(installer, conversation_window)
    pending_action = build_pending_action(
        provider=provider,
        framework=framework,
        surface=surface,
        operation=operation,
        target=target,
        method=method,
        transport_args=transport_args,
        trust_boundary_crossing=trust_boundary_crossing,
        tool_descriptor=tool_descriptor,
    )
    pending_fingerprint = hash_json(pending_action)
    system_prompt, first_user_task, latest_user_turn = extract_prompt_fields(
        installer,
        conversation_window,
    )
    decision_context = {
        "provider": provider,
        "framework": framework,
        **(
            {"pending_tool_docstring": str((tool_descriptor or {}).get("docstring")).strip()}
            if isinstance((tool_descriptor or {}).get("docstring"), str)
            and str((tool_descriptor or {}).get("docstring")).strip()
            else {}
        ),
        **({"system_prompt": system_prompt} if system_prompt else {}),
        **({"first_user_task": first_user_task} if first_user_task else {}),
        **({"latest_user_turn": latest_user_turn} if latest_user_turn else {}),
        "tool_calls_in_run": collect_tool_calls(installer, conversation_window=conversation_window),
        "memory_reads_in_run": [],
        "factual_artifacts_in_run": collect_factual_artifacts(installer, pending_action=pending_action),
        "pending_action": pending_action,
        "taint_signals": collect_taint_signals(
            installer,
            conversation_window=conversation_window,
            system_prompt=system_prompt,
            latest_user_turn=latest_user_turn,
        ),
        "context_fill_pct": estimate_context_fill_pct(conversation_window),
        "prior_same_fingerprint_denies": collect_prior_same_fingerprint_denies(
            installer,
            pending_fingerprint=pending_fingerprint,
        ),
    }
    upstream_context = getattr(getattr(installer, "verifiedx", None), "get_upstream_context", lambda **_: None)()
    if upstream_context is not None:
        decision_context["upstream_context"] = upstream_context
    return decision_context


def infer_provider_framework(installer, conversation_window: dict[str, Any]) -> tuple[str, str]:
    source = str(conversation_window.get("source") or "").strip()
    request_kind = str(conversation_window.get("request_kind") or "").strip()
    capture_sources = " ".join(
        str(item or "").strip() for item in (conversation_window.get("capture_sources") or []) if str(item or "").strip()
    )
    selected_sources = " ".join(
        str(item.get("source") or "").strip()
        for item in (conversation_window.get("selected_tools") or [])
        if isinstance(item, dict) and str(item.get("source") or "").strip()
    )
    selected_provider_hints = " ".join(
        str(item.get("provider_hint") or "").strip()
        for item in (conversation_window.get("selected_tools") or [])
        if isinstance(item, dict) and str(item.get("provider_hint") or "").strip()
    )
    adapter_kind = str(getattr(getattr(installer, "report", None), "adapter_kind", "") or "").strip()
    raw = " ".join(
        part
        for part in [source, request_kind, capture_sources, selected_sources, selected_provider_hints, adapter_kind]
        if part
    ).lower()
    adapter_kind_normalized = adapter_kind.lower()
    provider = "unknown"
    if "openai" in raw:
        provider = "openai"
    elif "anthropic" in raw or "claude" in raw:
        provider = "anthropic"
    elif "bedrock" in raw:
        provider = "bedrock"
    framework = "generic_python"
    if adapter_kind_normalized == "langgraph":
        framework = "langgraph"
    elif adapter_kind_normalized == "openai_direct":
        framework = "openai_direct"
    elif adapter_kind_normalized == "claude_agent_sdk":
        framework = "claude_agent_sdk"
    elif adapter_kind_normalized == "openai_agents":
        framework = "openai_agents"
    elif adapter_kind_normalized == "anthropic_direct":
        framework = "anthropic_direct"
    elif (
        "anthropic_direct" in raw
        or "anthropic direct" in raw
        or "anthropic-direct" in raw
        or "anthropic.messages" in raw
    ):
        framework = "anthropic_direct"
    elif (
        "openai_direct" in raw
        or "openai direct" in raw
        or "openai-direct" in raw
        or "openai.responses" in raw
        or "openai.chat.completions" in raw
    ):
        framework = "openai_direct"
    elif (
        "openai_agents" in raw
        or "openai agents" in raw
        or "openai-agents" in raw
    ):
        framework = "openai_agents"
    elif (
        "claude_agent_sdk" in raw
        or "claude agent sdk" in raw
        or "claude-agent-sdk" in raw
    ):
        framework = "claude_agent_sdk"
    elif "langgraph" in raw:
        framework = "langgraph"
    elif "langchain" in raw:
        framework = "langchain"
    elif "vercel" in raw:
        framework = "vercel_ai"
    elif not raw:
        framework = "unknown"
    return provider, framework


def _tool_call_identity(raw_name: str, raw_args: dict[str, Any], tool_call_id: str | None) -> str:
    if tool_call_id:
        return f"id:{tool_call_id}"
    return f"shape:{hash_json({'raw_name': raw_name, 'raw_args': raw_args})}"


def _tool_call_source_rank(source: str | None) -> int:
    normalized = str(source or "").strip().lower()
    if normalized.startswith("openai_agents.stream."):
        return 6
    if normalized.startswith("openai.responses.output."):
        return 5
    if normalized.startswith("openai.chat.completions"):
        return 4
    if normalized.startswith("assistant_output_fallback"):
        return 0
    if not normalized or normalized == "unknown":
        return -1
    return 1


def _tool_call_candidate_rank(item: dict[str, Any]) -> tuple[int, str]:
    return (_tool_call_source_rank(item.get("source")), str(item.get("timestamp") or ""))


def _includes_any(value: str | None, patterns: list[str]) -> bool:
    normalized = str(value or "").strip().lower()
    return any(pattern in normalized for pattern in patterns)


def _native_history_semantic_class(
    native_type: str | None,
    raw_name: str | None,
    source: str | None,
) -> str | None:
    normalized = " ".join(
        part
        for part in [
            str(native_type or "").strip().lower(),
            str(raw_name or "").strip().lower(),
            str(source or "").strip().lower(),
        ]
        if part
    )
    if not normalized:
        return None
    if _includes_any(
        normalized,
        ["tool_approval_requested", "mcp_approval_request", "mcp_approval_requested"],
    ):
        return "approval_request"
    if _includes_any(
        normalized,
        ["tool_approval_response", "mcp_approval_response"],
    ):
        return "approval_response"
    if "mcp_list_tools" in normalized:
        return "tool_discovery"
    if "tool_search_output" in normalized:
        return "tool_search_result"
    if _includes_any(normalized, ["tool_search_call", "tool_search_called"]):
        return "tool_search"
    if _includes_any(normalized, ["web_search_call", "websearchtool", "web_search"]):
        return "external_search"
    if _includes_any(normalized, ["file_search_call", "filesearchtool", "file_search"]):
        return "file_search"
    if _includes_any(normalized, ["apply_patch_call", "applypatchtool"]):
        return "file_mutation"
    if _includes_any(
        normalized,
        ["shell_call", "local_shell_call", "shelltool", "code_interpreter_call", "codextool"],
    ):
        return "system_mutation"
    if _includes_any(normalized, ["computer_call", "computertool"]):
        return "computer_action"
    return None


def _tool_definition_name(definition: dict[str, Any] | None) -> str | None:
    if not isinstance(definition, dict):
        return None
    for candidate in (definition.get("tool_name"), definition.get("name")):
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    function_payload = definition.get("function")
    if isinstance(function_payload, dict):
        candidate = function_payload.get("name")
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    custom_payload = definition.get("custom")
    if isinstance(custom_payload, dict):
        candidate = custom_payload.get("name")
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    return None


def _tool_definition_metadata(definition: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(definition, dict):
        return {}
    metadata = definition.get("metadata")
    if isinstance(metadata, dict):
        return metadata
    metadata = {}
    native_tool_type = definition.get("type")
    if isinstance(native_tool_type, str) and native_tool_type.strip():
        metadata["native_tool_type"] = native_tool_type.strip()
    if bool(definition.get("read_only")):
        metadata["read_only"] = True
    if bool(definition.get("retrieval_like")):
        metadata["retrieval_like"] = True
    return metadata


def _tool_definition_semantic_class(
    definition: dict[str, Any] | None,
    raw_name: str | None,
    source: str | None,
) -> str | None:
    if not isinstance(definition, dict):
        return _native_history_semantic_class(None, raw_name, source)
    metadata = _tool_definition_metadata(definition)
    semantic = str(metadata.get("semantic_class") or "").strip()
    if semantic:
        return semantic
    native_semantic = _native_history_semantic_class(
        str(metadata.get("native_tool_type") or definition.get("type") or "").strip() or None,
        raw_name or _tool_definition_name(definition),
        source,
    )
    if native_semantic:
        return native_semantic
    if bool(metadata.get("read_only")) or bool(metadata.get("retrieval_like")):
        normalized = " ".join(
            part
            for part in [str(raw_name or "").strip().lower(), str(source or "").strip().lower()]
            if part
        )
        if "web_search" in normalized:
            return "external_search"
        if "file_search" in normalized:
            return "file_search"
        if "tool_search" in normalized:
            return "tool_search"
        if "read" in normalized:
            return "file_read"
        return "internal_retrieval"
    return _native_history_semantic_class(None, raw_name, source)


def _tool_definitions_by_name(tool_definitions: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(tool_definitions, list):
        return {}
    normalized: dict[str, dict[str, Any]] = {}
    for definition in tool_definitions:
        if not isinstance(definition, dict):
            continue
        name = _tool_definition_name(definition)
        if not name:
            continue
        normalized[name] = definition
    return normalized


def extract_prompt_fields(
    installer,
    conversation_window: dict[str, Any],
) -> tuple[str | None, str | None, str | None]:
    scope = installer._runtime_scope()
    scope_entries = [
        entry
        for entry in installer._recent_conversation
        if str(entry.get("runtime_scope") or "") == scope
    ]
    scope_entries.sort(key=lambda entry: int(entry.get("sequence") or 0))
    first_user_task = None
    latest_user_turn = None
    system_prompt = None
    for entry in scope_entries or [conversation_window]:
        request_metadata = entry.get("request_metadata") or {}
        if system_prompt is None and isinstance(request_metadata.get("instructions"), str):
            instructions = request_metadata.get("instructions").strip()
            if instructions:
                system_prompt = instructions
        for message in entry.get("messages") or []:
            role = str(message.get("role") or "").strip().lower()
            content = message_text(message.get("content")).strip()
            if not content:
                continue
            if role in {"system", "developer"} and system_prompt is None:
                system_prompt = content
            if role == "user" and first_user_task is None:
                first_user_task = content
            if role == "user":
                latest_user_turn = content
    return system_prompt, first_user_task, latest_user_turn


def collect_tool_calls(
    installer,
    *,
    conversation_window: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    scope = str((conversation_window or {}).get("runtime_scope") or installer._runtime_scope() or "")
    records_by_identity: dict[str, dict[str, Any]] = {}
    definitions_by_name = _tool_definitions_by_name((conversation_window or {}).get("tool_definitions"))

    def consider(
        raw_name: str,
        raw_args: dict[str, Any],
        source: str,
        timestamp: str | None,
        tool_call_id: str | None,
        semantic_class: str | None,
    ) -> None:
        normalized_source = str(source or "unknown")
        normalized_name = str(raw_name or "").strip()
        if normalized_name == "assistant_message" or normalized_source.startswith("assistant_output_fallback"):
            return
        item = {
            "raw_name": normalized_name,
            "raw_args": raw_args,
            "source": normalized_source,
        }
        if timestamp:
            item["timestamp"] = str(timestamp)
        effective_semantic_class = semantic_class or _tool_definition_semantic_class(
            definitions_by_name.get(normalized_name),
            normalized_name,
            normalized_source,
        )
        if effective_semantic_class:
            item["semantic_class"] = str(effective_semantic_class)
        if tool_call_id:
            item["tool_call_id"] = str(tool_call_id)
        identity = _tool_call_identity(normalized_name, raw_args, str(tool_call_id) if tool_call_id else None)
        existing = records_by_identity.get(identity)
        if existing is None:
            records_by_identity[identity] = item
            return
        merged = dict(existing)
        existing_rank = _tool_call_source_rank(existing.get("source"))
        incoming_rank = _tool_call_source_rank(item.get("source"))
        if incoming_rank > existing_rank:
            for key, value in item.items():
                if key == "timestamp":
                    continue
                merged[key] = value
        earliest_timestamp = min(
            [
                value
                for value in (
                    str(existing.get("timestamp") or "").strip() or None,
                    str(item.get("timestamp") or "").strip() or None,
                )
                if value
            ],
            default=None,
        )
        if earliest_timestamp:
            merged["timestamp"] = earliest_timestamp
        if not merged.get("semantic_class") and item.get("semantic_class"):
            merged["semantic_class"] = item["semantic_class"]
        records_by_identity[identity] = merged

    for record in installer._recent_tool_selections:
        if scope and str(record.get("runtime_scope") or "") != scope:
            continue
        descriptor = record.get("descriptor") or {}
        selection_metadata = record.get("selection_metadata") or {}
        raw_name = str(
            selection_metadata.get("raw_name")
            or descriptor.get("tool_name")
            or ""
        ).strip()
        if not raw_name:
            continue
        raw_args = selection_metadata.get("raw_args")
        if not isinstance(raw_args, dict):
            raw_args = descriptor.get("args") or {}
        consider(
            raw_name,
            raw_args,
            str(record.get("source") or "unknown"),
            str(record.get("recorded_at")) if record.get("recorded_at") else None,
            str(record.get("tool_call_id")) if record.get("tool_call_id") else None,
            str(selection_metadata.get("semantic_class") or "").strip() or None,
        )
    if not isinstance(conversation_window, dict):
        tool_history = sorted(records_by_identity.values(), key=lambda item: str(item.get("timestamp") or ""))
        memory_history = collect_memory_reads(installer)
        return sorted(tool_history + memory_history, key=lambda item: str(item.get("timestamp") or ""))
    for selected in conversation_window.get("selected_tools") or []:
        if not isinstance(selected, dict):
            continue
        raw_name = str(selected.get("raw_name") or selected.get("tool_name") or "").strip()
        if not raw_name:
            continue
        raw_args = selected.get("raw_args")
        if not isinstance(raw_args, dict):
            raw_args = selected.get("args") if isinstance(selected.get("args"), dict) else {}
        consider(
            raw_name,
            raw_args,
            str(selected.get("source") or conversation_window.get("source") or "unknown"),
            str(selected.get("timestamp") or conversation_window.get("captured_at") or ""),
            str(selected.get("tool_call_id")) if selected.get("tool_call_id") else None,
            str(selected.get("semantic_class") or "").strip() or None,
        )
    tool_history = sorted(records_by_identity.values(), key=lambda item: str(item.get("timestamp") or ""))
    memory_history = collect_memory_reads(installer)
    return sorted(tool_history + memory_history, key=lambda item: str(item.get("timestamp") or ""))


def collect_memory_reads(installer) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for entry in installer.verifiedx.capture.recent_objects(limit=64):
        if entry.get("kind") != "memory_read":
            continue
        raw_name = str(entry.get("tool_name") or "memory_read")
        raw_args: dict[str, Any] = {}
        if entry.get("query"):
            query = str(entry["query"])
            raw_args["query"] = query
        else:
            query = None
        if entry.get("namespace"):
            namespace = str(entry["namespace"])
            raw_args["namespace"] = namespace
        else:
            namespace = None
        if entry.get("key"):
            key = str(entry["key"])
            if not key.startswith("__verifiedx_"):
                raw_args["key"] = key
            else:
                key = None
        else:
            key = None
        record = {
            "raw_name": raw_name,
            "raw_args": raw_args,
            "source": raw_name,
            "semantic_class": "memory_read",
        }
        if query:
            record["query"] = query
        if namespace:
            record["namespace"] = namespace
        if key:
            record["key"] = key
        if entry.get("recorded_at"):
            record["timestamp"] = str(entry["recorded_at"])
        records.append(record)
    return records


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except TypeError:
            return _jsonable(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _jsonable(value.dict())
    return str(value)


def _json_utf8_bytes(value: Any) -> int:
    return len(json.dumps(_jsonable(value), sort_keys=True, separators=(",", ":"), default=str).encode("utf-8"))


def _factual_artifact_anchor_value(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip().lower()
        if 2 <= len(normalized) <= 160:
            return normalized
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return f"n:{value}"
    return None


def _collect_nested_factual_artifact_anchors(
    value: Any,
    anchors: set[str],
    *,
    state: dict[str, int] | None = None,
) -> None:
    if not value or len(anchors) >= 64:
        return
    tracker = state or {"visited": 0}
    if tracker["visited"] >= 128:
        return
    tracker["visited"] += 1
    normalized = _factual_artifact_anchor_value(value)
    if normalized:
        anchors.add(normalized)
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            if len(anchors) >= 64 or tracker["visited"] >= 128:
                break
            _collect_nested_factual_artifact_anchors(item, anchors, state=tracker)
        return
    if isinstance(value, dict):
        for item in value.values():
            if len(anchors) >= 64 or tracker["visited"] >= 128:
                break
            _collect_nested_factual_artifact_anchors(item, anchors, state=tracker)


def _factual_artifact_anchors(pending_action: dict[str, Any] | None) -> set[str]:
    anchors: set[str] = set()
    if not isinstance(pending_action, dict):
        return anchors
    _collect_nested_factual_artifact_anchors(pending_action.get("target"), anchors)
    raw_args = pending_action.get("raw_args")
    if isinstance(raw_args, dict):
        for value in raw_args.values():
            if len(anchors) >= 64:
                break
            _collect_nested_factual_artifact_anchors(value, anchors)
    return anchors


_GOVERNANCE_ARTIFACT_HINTS = (
    "policy",
    "review",
    "approval",
    "identity",
    "case_state",
    "workflow_state",
    "authorization",
)


def _factual_artifact_has_governance_signal(tool_name: str, payload: dict[str, Any]) -> bool:
    haystack = " ".join(
        [
            tool_name,
            " ".join(str(key).lower() for key in payload.keys()),
            " ".join(
                str(key).lower()
                for value in payload.values()
                if isinstance(value, dict)
                for key in value.keys()
            ),
        ]
    )
    return any(hint in haystack for hint in _GOVERNANCE_ARTIFACT_HINTS)


def _has_governance_hint(value: Any) -> bool:
    text = str(value).lower()
    return any(hint in text for hint in _GOVERNANCE_ARTIFACT_HINTS)


def _compact_governance_value(value: Any, *, limit: int = 700) -> Any:
    if _json_utf8_bytes(value) <= limit:
        return value
    if not isinstance(value, dict):
        return None
    compact: dict[str, Any] = {}
    for key, child in value.items():
        child_bytes = _json_utf8_bytes(child)
        if _has_governance_hint(key) and child_bytes <= limit:
            compact[key] = child
        elif not isinstance(child, (dict, list, tuple)) and child_bytes <= 160:
            compact[key] = child
    return compact or None


def _governance_factual_artifact_payload(payload: dict[str, Any], tool_name: str) -> dict[str, Any] | None:
    if not _factual_artifact_has_governance_signal(tool_name, payload):
        return None
    if _json_utf8_bytes(payload) <= 900:
        return payload

    compact: dict[str, Any] = {}
    for key in ("raw_name", "tool_name"):
        value = payload.get(key)
        if isinstance(value, str) and value:
            compact[key] = value
    for key in ("raw_args", "tool_input", "input"):
        value = payload.get(key)
        if value is not None and _json_utf8_bytes(value) <= 250:
            compact[key] = value

    for container_key in ("tool_response", "result", "response", "output", "tool_result", "tool_output"):
        container = payload.get(container_key)
        if not isinstance(container, dict):
            continue
        selected: dict[str, Any] = {}
        for key, value in container.items():
            if not (_has_governance_hint(key) or (isinstance(value, dict) and any(_has_governance_hint(child_key) for child_key in value.keys()))):
                continue
            compact_value = _compact_governance_value(value)
            if compact_value is not None:
                selected[key] = compact_value
        if selected:
            compact[container_key] = selected

    for key, value in payload.items():
        if key in compact or key in {"raw_name", "tool_name", "raw_args", "tool_input", "input", "tool_response", "result", "response", "output", "tool_result", "tool_output"}:
            continue
        if not _has_governance_hint(key):
            continue
        compact_value = _compact_governance_value(value)
        if compact_value is not None:
            compact[key] = compact_value

    if not compact:
        return None
    for removable in ("input", "tool_input", "raw_args"):
        if _json_utf8_bytes(compact) <= 900:
            break
        compact.pop(removable, None)
    return compact if _json_utf8_bytes(compact) <= 900 else None


def _factual_artifact_projection_at_path(value: Any, path: list[Any]) -> Any:
    if not path:
        return value
    head, *rest = path
    if isinstance(value, list):
        try:
            index = int(head)
        except (TypeError, ValueError):
            return None
        if index < 0 or index >= len(value):
            return None
        child = _factual_artifact_projection_at_path(value[index], rest)
        if child is None:
            return None
        result: list[Any] = [None] * (index + 1)
        result[index] = child
        return result
    if not isinstance(value, dict) or head not in value:
        return None
    child = _factual_artifact_projection_at_path(value[head], rest)
    if child is None:
        return None
    return {head: child}


def _merge_factual_artifact_projection(left: Any, right: Any) -> Any:
    if left is None:
        return right
    if right is None:
        return left
    if isinstance(left, list) and isinstance(right, list):
        merged: list[Any] = [None] * max(len(left), len(right))
        for index in range(len(merged)):
            left_value = left[index] if index < len(left) else None
            right_value = right[index] if index < len(right) else None
            merged[index] = _merge_factual_artifact_projection(left_value, right_value)
        return merged
    if isinstance(left, dict) and isinstance(right, dict):
        merged = dict(left)
        for key, value in right.items():
            merged[key] = _merge_factual_artifact_projection(merged.get(key), value)
        return merged
    return right


def _collect_factual_artifact_paths(
    value: Any,
    anchors: set[str],
    *,
    path: list[Any] | None = None,
    matches: list[list[Any]] | None = None,
) -> list[list[Any]]:
    current_path = [] if path is None else path
    collected = [] if matches is None else matches
    if isinstance(value, list):
        for index, item in enumerate(value):
            _collect_factual_artifact_paths(item, anchors, path=[*current_path, index], matches=collected)
        return collected
    if isinstance(value, dict):
        for key, child in value.items():
            _collect_factual_artifact_paths(child, anchors, path=[*current_path, key], matches=collected)
        return collected
    normalized = _factual_artifact_anchor_value(value)
    if normalized and normalized in anchors:
        collected.append(current_path)
    return collected


def _anchored_factual_artifact_payload(payload: Any, pending_action: dict[str, Any] | None) -> Any:
    if not isinstance(payload, dict):
        return None
    if _json_utf8_bytes(payload) <= 400:
        return payload
    anchors = _factual_artifact_anchors(pending_action)
    paths = _collect_factual_artifact_paths(payload, anchors)
    if not paths:
        return None
    projections: list[tuple[int, Any]] = []
    seen_hashes: set[str] = set()
    for path in paths:
        candidate_paths: list[list[Any]] = []
        if len(path) > 1:
            candidate_paths.append(path[:-1])
        candidate_paths.append(path)
        for candidate_path in candidate_paths:
            projected = _factual_artifact_projection_at_path(payload, candidate_path)
            if projected is None:
                continue
            bytes_used = _json_utf8_bytes(projected)
            if bytes_used > 900:
                continue
            cache_key = hash_json(projected)
            if cache_key in seen_hashes:
                continue
            seen_hashes.add(cache_key)
            projections.append((bytes_used, projected))
            break
    if not projections:
        return None
    projections.sort(key=lambda item: item[0])
    merged = None
    for _, projected in projections:
        candidate = _merge_factual_artifact_projection(merged, projected)
        if _json_utf8_bytes(candidate) > 900:
            continue
        merged = candidate
    return merged


def _nested_candidates(value: Any, paths: list[tuple[str, ...]]) -> list[Any]:
    results: list[Any] = []
    for path in paths:
        current = value
        for key in path:
            if not isinstance(current, dict) or key not in current:
                current = None
                break
            current = current[key]
        if current is not None:
            results.append(current)
    return results


def _tool_result_is_evidence_bearing(payload: dict[str, Any]) -> bool:
    return any(
        candidate is not None
        for candidate in [
            payload.get("output"),
            payload.get("result"),
            payload.get("tool_response"),
            payload.get("response"),
            payload.get("tool_output"),
            payload.get("tool_result"),
            *_nested_candidates(payload, [("payload", "tool_response"), ("payload", "response"), ("payload", "tool_output"), ("payload", "tool_result")]),
        ]
    )


def _runtime_loopback_artifact_payload(entry: dict[str, Any]) -> dict[str, Any] | None:
    if not isinstance(entry, dict):
        return None
    payload: dict[str, Any] = {}
    for key in (
        "decision_id",
        "outcome",
        "boundary_kind",
        "action_class",
        "same_goal_state",
        "must_not_retry_same_action",
        "can_retry_same_action",
    ):
        value = entry.get(key)
        if value is not None:
            payload[key] = value
    pending_effect = entry.get("pending_effect")
    if isinstance(pending_effect, dict) and pending_effect:
        payload["pending_effect"] = pending_effect
    safe_next_steps = entry.get("safe_next_steps")
    if isinstance(safe_next_steps, list) and safe_next_steps:
        payload["safe_next_steps"] = safe_next_steps[:3]
    reasons = entry.get("reasons")
    if isinstance(reasons, list) and reasons:
        payload["reasons"] = reasons[:3]
    return payload or None


def collect_factual_artifacts(
    installer,
    *,
    pending_action: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    context = installer.verifiedx.capture.current_context()
    entries = list(installer.verifiedx.capture._recent_objects_by_run.get(context.run_id, []))
    across_run_entries: list[dict[str, Any]] = []
    recent_across_runs = getattr(installer.verifiedx.capture, "recent_objects_across_runs", None)
    if callable(recent_across_runs):
        try:
            across_run_entries = list(recent_across_runs(limit=96))
        except Exception:
            across_run_entries = []
    latest: list[dict[str, Any]] = []
    seen_object_ids: set[str] = set()
    current_scope = installer.verifiedx.current_runtime_scope()
    current_source = installer.verifiedx.current_conversation_source()
    runtime_entries: list[dict[str, Any]] = []
    for entry in reversed(
        installer.verifiedx.runtime_loopbacks(
            scope=current_scope or None,
            conversation_source=current_source or None,
        )
    ):
        object_id = str(entry.get("decision_id") or entry.get("retry_fingerprint") or "").strip()
        if not object_id:
            continue
        payload = _runtime_loopback_artifact_payload(entry)
        if not payload:
            continue
        synthetic_object_id = f"runtime-loopback:{object_id}"
        if synthetic_object_id in seen_object_ids:
            continue
        seen_object_ids.add(synthetic_object_id)
        runtime_entries.append(
            {
                "object_id": synthetic_object_id,
                "object_type": "runtime_loopback",
                "kind": "runtime_loopback",
                "normalized_payload": payload,
                "source_lineage": ["runtime_loopback"],
                "recorded_at": entry.get("recorded_at"),
            }
        )
        if len(runtime_entries) >= 8:
            break
    latest.extend(runtime_entries)
    for entry in reversed(entries):
        object_id = str(entry.get("object_id") or "")
        if not object_id or object_id in seen_object_ids:
            continue
        seen_object_ids.add(object_id)
        latest.append(entry)
        if len(latest) >= 64:
            break
    if len(latest) < 64 and across_run_entries:
        for entry in reversed(across_run_entries):
            object_id = str(entry.get("object_id") or "")
            if not object_id or object_id in seen_object_ids:
                continue
            seen_object_ids.add(object_id)
            latest.append(entry)
            if len(latest) >= 64:
                break

    anchors = _factual_artifact_anchors(pending_action)
    pending_tool_name = str((pending_action or {}).get("raw_name") or "").strip().lower()
    candidates: list[dict[str, Any]] = []
    for index, entry in enumerate(latest):
        object_type = str(entry.get("object_type") or "").strip().lower()
        kind = str(entry.get("kind") or "").strip().lower()
        payload = entry.get("normalized_payload")
        if not isinstance(payload, dict):
            continue
        eligible = (
            (object_type == "approval" and kind == "approval")
            or (object_type == "internal_retrieval" and kind in {"retrieve", "context_ingress", "tool_call"})
            or (object_type == "memory_record" and kind in {"memory_read", "context_ingress"})
            or (object_type == "tool_result" and kind == "tool_call")
            or (object_type == "runtime_loopback" and kind == "runtime_loopback")
        )
        if not eligible:
            continue
        tool_name = str(payload.get("tool_name") or payload.get("raw_name") or "").strip().lower()
        tool_name_match = bool(tool_name and pending_tool_name and tool_name == pending_tool_name)
        anchor_paths = _collect_factual_artifact_paths(payload, anchors)
        strong_anchor_match = bool(anchor_paths)
        governance_match = _factual_artifact_has_governance_signal(tool_name, payload)
        evidence_bearing = (
            object_type == "runtime_loopback"
            or object_type != "tool_result"
            or _tool_result_is_evidence_bearing(payload)
        )
        if not evidence_bearing:
            continue
        if object_type == "approval":
            if not tool_name_match and not strong_anchor_match:
                continue
        elif not strong_anchor_match and not governance_match:
            continue
        compact_payload = payload if object_type == "runtime_loopback" and _json_utf8_bytes(payload) <= 900 else _anchored_factual_artifact_payload(payload, pending_action)
        if compact_payload is None and governance_match:
            compact_payload = _governance_factual_artifact_payload(payload, tool_name)
        if compact_payload is None:
            continue
        bytes_used = _json_utf8_bytes(compact_payload)
        if bytes_used > 900:
            continue
        score = 0
        if object_type == "approval":
            score += 120
        if object_type == "runtime_loopback":
            score += 110
        if tool_name_match:
            score += 40
        if strong_anchor_match:
            score += 60
        if governance_match:
            score += 55
        if object_type == "memory_record":
            score += 25
        elif object_type == "internal_retrieval":
            score += 20
        elif object_type == "tool_result":
            score += 15
        elif object_type == "runtime_loopback":
            score += 18
        score += max(0, 64 - index)
        candidates.append(
            {
                "score": score,
                "bytes": bytes_used,
                "artifact": {
                    "object_type": entry.get("object_type"),
                    "source_lineage": list(entry.get("source_lineage") or []),
                    "timestamp": entry.get("recorded_at"),
                    "normalized_payload": compact_payload,
                },
            }
        )
    candidates.sort(key=lambda item: item["score"], reverse=True)
    selected: list[dict[str, Any]] = []
    selected_hashes: set[str] = set()
    total_bytes = 0
    for candidate in candidates:
        if len(selected) >= 3:
            break
        if (total_bytes + int(candidate["bytes"])) > 1800:
            continue
        artifact_hash = hash_json(candidate["artifact"].get("normalized_payload"))
        if artifact_hash in selected_hashes:
            continue
        selected.append(candidate["artifact"])
        selected_hashes.add(artifact_hash)
        total_bytes += int(candidate["bytes"])
    selected.sort(key=lambda artifact: str(artifact.get("timestamp") or ""))
    return selected


def collect_taint_signals(
    installer,
    *,
    conversation_window: dict[str, Any],
    system_prompt: str | None,
    latest_user_turn: str | None,
) -> list[dict[str, Any]]:
    signals: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str | None]] = set()

    def add(signal: str, source: str, timestamp: str | None = None, note: str | None = None) -> None:
        identity = (signal, source, timestamp)
        if identity in seen:
            return
        seen.add(identity)
        item = {"signal": signal, "source": source}
        if timestamp:
            item["timestamp"] = timestamp
        if note:
            item["note"] = note
        signals.append(item)

    def entry_source(entry: dict[str, Any]) -> str:
        kind = str(entry.get("kind") or "")
        if kind == "retrieve":
            return "retrieval"
        if kind == "memory_read":
            return "memory_read"
        if kind == "context_ingress":
            object_type = str(entry.get("object_type") or "").strip().lower()
            if object_type == "external_retrieval":
                return "retrieval"
            normalized_payload = entry.get("normalized_payload") or {}
            role = str(normalized_payload.get("role") or "").lower()
            if role in {"system", "developer"}:
                return "system_prompt"
            if role == "user":
                return "user_turn"
        return "tool_result"

    recent_entries = list(installer.verifiedx.capture.recent_objects(limit=64))
    linked_object_ids = list((conversation_window or {}).get("inserted_context_object_ids") or [])
    if linked_object_ids:
        for entry in installer.verifiedx.capture.recent_objects_by_ids(linked_object_ids):
            object_id = str(entry.get("object_id") or "")
            if not object_id:
                continue
            if any(str(existing.get("object_id") or "") == object_id for existing in recent_entries):
                continue
            recent_entries.append(entry)
    recent_entries.sort(key=lambda entry: int(entry.get("sequence") or 0))

    for entry in recent_entries:
        source = entry_source(entry)
        for label in entry.get("taint_labels") or []:
            add(
                str(label),
                source,
                timestamp=str(entry.get("recorded_at")) if entry.get("recorded_at") else None,
            )

    return signals


def estimate_context_fill_pct(conversation_window: dict[str, Any]) -> float:
    request_metadata = conversation_window.get("request_metadata") or {}
    messages = conversation_window.get("messages") or []
    used_chars = sum(len(message_text(message.get("content"))) for message in messages)
    used_chars += len(str(request_metadata.get("instructions") or ""))
    used_chars += len(json.dumps(conversation_window.get("selected_tools") or [], default=str))
    budget = None
    for key in ("max_input_tokens", "context_window", "max_prompt_tokens", "token_budget"):
        value = request_metadata.get(key)
        if isinstance(value, (int, float)) and value > 0:
            budget = int(value) * 4
            break
    if budget is None:
        for key in ("max_output_tokens", "max_tokens", "max_completion_tokens"):
            value = request_metadata.get(key)
            if isinstance(value, (int, float)) and value > 0:
                budget = max(int(value) * 8, 16000)
                break
    if budget is None:
        budget = 32000
    return round(min(max(used_chars / max(budget, 1), 0.0), 1.0), 4)


def collect_prior_same_fingerprint_denies(
    installer,
    *,
    pending_fingerprint: str,
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    seen: set[str] = set()
    scope = installer._runtime_scope()
    current_source = ""
    try:
        current_source = str(installer.verifiedx.current_conversation_source() or "").strip()
    except Exception:
        current_source = ""

    def _matches_current_lineage(entry: dict[str, Any]) -> bool:
        entry_scope = str(entry.get("runtime_scope") or "")
        if entry_scope == scope:
            return True
        if not current_source:
            return False
        return str(entry.get("conversation_source") or "").strip() == current_source

    for entry in installer.verifiedx.runtime_loopbacks(
        scope=scope,
        conversation_source=current_source or None,
    ):
        fingerprints = [
            entry.get("pending_action_fingerprint"),
            entry.get("forbidden_action_fingerprint"),
            entry.get("retry_fingerprint"),
        ]
        if pending_fingerprint not in [value for value in fingerprints if value]:
            continue
        marker = str(entry.get("decision_id") or entry.get("recorded_at") or pending_fingerprint)
        if marker in seen:
            continue
        seen.add(marker)
        records.append(
            {
                "decision_id": entry.get("decision_id"),
                "outcome": entry.get("outcome") or "replan_required",
                "reason_codes": [
                    reason.get("code")
                    for reason in entry.get("reasons") or []
                    if isinstance(reason, dict) and reason.get("code")
                ],
                **({"timestamp": entry["recorded_at"]} if entry.get("recorded_at") else {}),
            }
        )
    for entry in installer._tool_preflight_cache:
        if not _matches_current_lineage(entry):
            continue
        decision = entry.get("decision") or {}
        fingerprints = [
            entry.get("pending_action_fingerprint"),
            entry.get("forbidden_action_fingerprint"),
            decision.get("forbidden_action_fingerprint"),
            ((decision.get("retry_fingerprint") or {}).get("denied_effect_fingerprint")),
        ]
        if pending_fingerprint not in [value for value in fingerprints if value]:
            continue
        decision_id = str(decision.get("decision_id") or "")
        if decision_id and decision_id in seen:
            continue
        if decision_id:
            seen.add(decision_id)
        records.append(
            {
                **({"decision_id": decision.get("decision_id")} if decision.get("decision_id") else {}),
                "outcome": decision.get("outcome") or "replan_required",
                "reason_codes": [
                    reason.get("code")
                    for reason in decision.get("reasons") or []
                    if isinstance(reason, dict) and reason.get("code")
                ],
                **({"timestamp": entry["recorded_at"]} if entry.get("recorded_at") else {}),
            }
        )
    return records


def build_pending_action(
    *,
    provider: str,
    framework: str,
    surface: str,
    operation: str,
    target: str,
    method: str | None,
    transport_args: dict[str, Any],
    trust_boundary_crossing: bool | None,
    tool_descriptor: dict[str, Any] | None,
) -> dict[str, Any]:
    normalized_surface = normalize_surface(surface)
    raw_name = str(operation or (tool_descriptor or {}).get("tool_name") or "unknown")
    registry_entry = match_registry_entry(
        provider=provider,
        framework=framework,
        raw_name=raw_name,
        surface=normalized_surface,
        method=method,
    )
    if registry_entry is not None:
        normalized_surface = str(registry_entry.get("surface") or normalized_surface)
    return {
        "raw_name": raw_name,
        "surface": normalized_surface,
        "method": str(method or "CALL"),
        "target": str(target or ""),
        "raw_args": transport_args or {},
        "trust_boundary_crossing": bool(trust_boundary_crossing),
    }


def match_registry_entry(
    *,
    provider: str,
    framework: str,
    raw_name: str,
    surface: str,
    method: str | None,
) -> dict[str, Any] | None:
    effective_method = str(method or "").upper()
    for entry in V4_GUARD_REGISTRY:
        entry_provider = str(entry.get("provider") or "")
        entry_framework = str(entry.get("framework") or "")
        if entry_provider not in {provider, "generic"}:
            continue
        if entry_framework not in {framework, "generic_python"}:
            continue
        if str(entry.get("raw_name") or "") != raw_name:
            continue
        if str(entry.get("surface") or "") != surface:
            continue
        methods = [str(item).upper() for item in (entry.get("match_rule") or {}).get("methods") or []]
        if methods and effective_method and effective_method not in methods:
            continue
        return entry
    return None


def normalize_surface(surface: str) -> str:
    return {
        "tool_dispatch": "tool",
        "memory_write": "memory_write",
        "db_mutation": "db",
        "file_write": "file",
        "queue_publish": "queue",
        "browser": "browser",
        "http": "http",
    }.get(str(surface or "").strip().lower(), "unknown")


def message_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("text", "content", "message", "body", "value"):
            nested = value.get(key)
            if nested:
                return message_text(nested)
        return json.dumps(value, sort_keys=True, default=str)
    if isinstance(value, (list, tuple)):
        return " ".join(part for part in (message_text(item) for item in value) if part).strip()
    return str(value)
