from __future__ import annotations

from contextvars import ContextVar
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
import re
from typing import Any
import uuid

from .capture import CaptureEmitter
from .client import BoundaryClient
from .config import VerifiedXConfig
from .context import RunContext, set_run_context
from .errors import build_decision_receipt
from .generated import SDK_VERSION
from .otel_bridge import VerifiedXOtelBridge
from .v4 import V4RuntimeLane
from .zero_touch import (
    RuntimeBoundaryDeniedError,
    RuntimeExecutionFailureError,
    ZeroTouchRuntimeInstaller,
)

_CURRENT_RUNTIME_SCOPE: ContextVar[str | None] = ContextVar(
    "verifiedx_runtime_scope",
    default=None,
)
_PINNED_RUNTIME_SCOPE: ContextVar[str | None] = ContextVar(
    "verifiedx_pinned_runtime_scope",
    default=None,
)
_CURRENT_UPSTREAM_CONTEXT: ContextVar[Any | None] = ContextVar(
    "verifiedx_upstream_context",
    default=None,
)
_RUNTIME_SCOPE_STRONG_KEYS = (
    "session_id",
    "thread_id",
    "conversation_id",
)
_RUNTIME_SCOPE_KEYS = (
    "session_id",
    "thread_id",
    "conversation_id",
    "case_id",
    "ticket_id",
    "issue_id",
    "pr_id",
    "customer_id",
    "agent_id",
)
_RUNTIME_SCOPE_ID_PATTERN = re.compile(r"\b[A-Z]{1,8}-\d+\b")


def _activation_id() -> str:
    return f"act_{uuid.uuid4().hex}"


@dataclass
class ActivationReport:
    adapter_kind: str
    attachment_mode: str
    native_capabilities: list[str]
    framework_version: str | None = None
    activation_source: str = "sdk_auto_init"
    visibility_gap_signals: list[str] = field(default_factory=list)
    capture_backends: list[str] = field(default_factory=list)
    attached_instrumentors: list[str] = field(default_factory=list)
    instrumentation_started: bool = False
    wrapper_contract_present: bool = False
    wrapper_name: str | None = None
    adapter_version: str = SDK_VERSION
    activation_report_id: str = field(default_factory=_activation_id)
    sdk_language: str = "python"

    def to_adapter_context(self) -> dict:
        return {
            "adapter_kind": self.adapter_kind,
            "adapter_version": self.adapter_version,
            "wrapper_contract_present": self.wrapper_contract_present,
            "wrapper_name": self.wrapper_name,
            "visibility_gap_signals": list(self.visibility_gap_signals),
            "capture_backends": list(self.capture_backends),
            "attached_instrumentors": list(self.attached_instrumentors),
            "instrumentation_started": self.instrumentation_started,
            "framework_version": self.framework_version,
            "sdk_language": self.sdk_language,
            "attachment_mode": self.attachment_mode,
            "native_capabilities": list(self.native_capabilities),
            "activation_source": self.activation_source,
            "activation_report_id": self.activation_report_id,
        }

    def as_dict(self) -> dict:
        return asdict(self)


class VerifiedX:
    def __init__(
        self,
        config: VerifiedXConfig | None = None,
        *,
        transport=None,
        default_context: RunContext | None = None,
    ):
        self.config = config or VerifiedXConfig.from_env(require_api_key=transport is None)
        self.client = BoundaryClient(self.config, transport=transport)
        self.capture = CaptureEmitter(
            self.config,
            self.client,
            default_context=default_context or RunContext.from_config(self.config),
        )
        self._runtime_loopbacks: list[dict] = []
        self._observations: list[dict] = []
        self._observation_counter = 0
        self._scope_contexts: dict[str, RunContext] = {}
        self._upstream_contexts: dict[str, Any] = {}
        self._last_decision_receipts: dict[str, dict[str, Any]] = {}
        self._prefer_explicit_run_scope = False
        self._registered_action_classes: set[str] = set()
        self._registered_boundary_kinds: set[str] = set()
        self._zero_touch = ZeroTouchRuntimeInstaller(self)
        self._v4 = V4RuntimeLane(self)
        self._otel_bridge = VerifiedXOtelBridge(self)
        self._debug_path = (
            Path(self.config.debug_dir).expanduser() / "verifiedx_diagnostics.jsonl"
            if self.config.debug_dir
            else None
        )
        default_scope = f"context:{self.capture.default_context.thread_id}:{self.capture.default_context.run_id}"
        self._scope_contexts[default_scope] = self.capture.default_context
        _CURRENT_RUNTIME_SCOPE.set(default_scope)
        set_run_context(self.capture.default_context)

    def _normalize_runtime_scope(self, value: Any) -> str | None:
        if value is None:
            return None
        text = str(value).strip()
        if not text:
            return None
        text = re.sub(r"\s+", " ", text)
        return text[:160]

    def _runtime_scope_candidates(
        self,
        payload: Any,
        *,
        depth: int = 0,
        visited: set[int] | None = None,
    ) -> list[tuple[int, int, str]]:
        if payload is None or depth > 3:
            return []
        visited = visited or set()
        if isinstance(payload, dict):
            payload_id = id(payload)
            if payload_id in visited:
                return []
            visited.add(payload_id)
            candidates: list[tuple[int, int, str]] = []
            for index, key in enumerate(_RUNTIME_SCOPE_KEYS):
                normalized = self._normalize_runtime_scope(payload.get(key))
                if normalized:
                    priority = 0 if key in _RUNTIME_SCOPE_STRONG_KEYS else 1
                    candidates.append((priority, index, normalized))
            for nested_key in (
                "metadata",
                "plugin_data",
                "context",
                "request",
                "response",
                "data",
                "tool",
                "tool_descriptor",
                "arguments",
                "tool_args",
                "transport_args",
                "pending_effect",
                "result",
                "state",
            ):
                nested_value = payload.get(nested_key)
                if isinstance(nested_value, (dict, list, tuple)):
                    candidates.extend(
                        self._runtime_scope_candidates(
                            nested_value,
                            depth=depth + 1,
                            visited=visited,
                        )
                    )
            for key, nested_value in payload.items():
                if key in _RUNTIME_SCOPE_KEYS or key in {
                    "metadata",
                    "plugin_data",
                    "context",
                    "request",
                    "response",
                    "data",
                    "tool",
                    "tool_descriptor",
                    "arguments",
                    "tool_args",
                    "transport_args",
                    "pending_effect",
                    "result",
                    "state",
                }:
                    continue
                if isinstance(nested_value, (dict, list, tuple)):
                    candidates.extend(
                        self._runtime_scope_candidates(
                            nested_value,
                            depth=depth + 1,
                            visited=visited,
                        )
                    )
            return candidates
        if isinstance(payload, (list, tuple)):
            candidates: list[tuple[int, int, str]] = []
            for item in payload:
                candidates.extend(
                    self._runtime_scope_candidates(
                        item,
                        depth=depth + 1,
                        visited=visited,
                    )
                )
            return candidates
        return []

    def _extract_runtime_scope_from_payload(self, payload: Any) -> str | None:
        candidates = self._runtime_scope_candidates(payload)
        if not candidates:
            return None
        candidates.sort(key=lambda item: (item[0], item[1], item[2]))
        return candidates[0][2]

    def _extract_runtime_scope_from_text(self, text: str) -> str | None:
        content = str(text or "")
        matches = list(_RUNTIME_SCOPE_ID_PATTERN.finditer(content))
        if not matches:
            return None
        return matches[-1].group(0)

    def _extract_runtime_scope_from_messages(self, messages: list[dict] | None) -> str | None:
        for message in reversed(messages or []):
            scope = self._extract_runtime_scope_from_payload(message.get("metadata"))
            if scope:
                return scope
        for message in reversed(messages or []):
            scope = self._extract_runtime_scope_from_payload(message)
            if scope:
                return scope
        for message in reversed(messages or []):
            scope = self._extract_runtime_scope_from_text(message.get("content") or "")
            if scope:
                return scope
        return None

    def _default_runtime_scope(self) -> str:
        context = self.capture.current_context()
        return f"context:{context.thread_id}:{context.run_id}"

    @staticmethod
    def _scope_for_context(context: RunContext) -> str:
        return f"context:{context.thread_id}:{context.run_id}"

    def _context_for_scope(self, scope: str) -> RunContext:
        context = self._scope_contexts.get(scope)
        if context is None:
            active_context = self.capture.current_context()
            if scope == self._scope_for_context(active_context):
                self._scope_contexts[scope] = active_context
                return active_context
            default_context = self.capture.default_context
            if scope == self._scope_for_context(default_context):
                self._scope_contexts[scope] = default_context
                return default_context
            context = RunContext.from_config(self.config)
            self._scope_contexts[scope] = context
        return context

    def _activate_runtime_scope(self, scope: str) -> str:
        effective_scope = _PINNED_RUNTIME_SCOPE.get() or scope
        _CURRENT_RUNTIME_SCOPE.set(effective_scope)
        set_run_context(self._context_for_scope(effective_scope))
        return effective_scope

    def activate_runtime_scope_from_payload(self, payload: Any) -> str:
        scope = self._extract_runtime_scope_from_payload(payload)
        if scope:
            return self._activate_runtime_scope(scope)
        return self.current_runtime_scope()

    @contextmanager
    def runtime_scope_from_payload(self, payload: Any):
        pinned_scope = _PINNED_RUNTIME_SCOPE.get()
        if pinned_scope:
            yield self._activate_runtime_scope(pinned_scope)
            return
        scope = self._extract_runtime_scope_from_payload(payload)
        if not scope:
            yield self.current_runtime_scope()
            return
        previous_context = self.capture.current_context()
        token = _CURRENT_RUNTIME_SCOPE.set(scope)
        set_run_context(self._context_for_scope(scope))
        try:
            yield scope
        finally:
            _CURRENT_RUNTIME_SCOPE.reset(token)
            set_run_context(previous_context)

    def current_runtime_scope(self) -> str:
        return _PINNED_RUNTIME_SCOPE.get() or _CURRENT_RUNTIME_SCOPE.get() or self._default_runtime_scope()

    def _runtime_scope_key(self, scope: Any | None = None) -> str:
        normalized = self._normalize_runtime_scope(scope)
        return normalized or self.current_runtime_scope()

    def _upstream_scope_key(self, scope: Any | None = None) -> str:
        normalized = self._normalize_runtime_scope(scope)
        if normalized:
            return normalized
        context = self.capture.default_context
        return f"context:{context.thread_id}:{context.run_id}"

    def set_upstream_context(self, payload: Any, *, scope: str | None = None) -> str:
        target_scope = self._upstream_scope_key(scope)
        self._upstream_contexts[target_scope] = payload
        return target_scope

    def get_upstream_context(self, *, scope: str | None = None) -> Any:
        scoped = self._upstream_contexts.get(self._upstream_scope_key(scope))
        if scoped is not None:
            return scoped
        return _CURRENT_UPSTREAM_CONTEXT.get()

    def clear_upstream_context(self, *, scope: str | None = None) -> Any:
        return self._upstream_contexts.pop(self._upstream_scope_key(scope), None)

    @contextmanager
    def with_upstream_context(self, payload: Any, *, scope: str | None = None):
        target_scope = self._upstream_scope_key(scope)
        had_previous = target_scope in self._upstream_contexts
        previous = self._upstream_contexts.get(target_scope)
        self._upstream_contexts[target_scope] = payload
        token = _CURRENT_UPSTREAM_CONTEXT.set(payload)
        try:
            yield payload
        finally:
            _CURRENT_UPSTREAM_CONTEXT.reset(token)
            if had_previous:
                self._upstream_contexts[target_scope] = previous
            else:
                self._upstream_contexts.pop(target_scope, None)

    def current_conversation_source(self) -> str | None:
        try:
            source = (self.zero_touch.current_conversation_window() or {}).get("source")
        except Exception:
            source = None
        if isinstance(source, str) and source.strip():
            return source.strip()
        return None

    def export_decision_receipt(
        self,
        decision: dict[str, Any] | None,
        *,
        metadata: dict | None = None,
        scope: str | None = None,
    ) -> dict | None:
        return build_decision_receipt(
            decision,
            metadata=metadata,
            upstream_context=self.get_upstream_context(scope=scope),
            conversation_source=self.current_conversation_source(),
        )

    def note_decision_receipt(
        self,
        decision: dict[str, Any] | None,
        *,
        scope: str | None = None,
        metadata: dict | None = None,
    ) -> dict | None:
        receipt = self.export_decision_receipt(decision, metadata=metadata, scope=scope)
        if receipt is None:
            return None
        self._last_decision_receipts[self._runtime_scope_key(scope)] = receipt
        return receipt

    def last_decision_receipt(self, *, scope: str | None = None) -> dict | None:
        return self._last_decision_receipts.get(self._runtime_scope_key(scope))

    def begin_run_context(
        self,
        *,
        thread_id: str | None = None,
        run_id: str | None = None,
        step_id: str | None = None,
        source_system: str | None = None,
        preserve_history: bool = False,
    ) -> RunContext:
        previous = self.capture.default_context
        normalized_thread = self._normalize_runtime_scope(thread_id)
        next_thread_id = normalized_thread or f"thread_{uuid.uuid4().hex}"
        continue_existing = bool(
            preserve_history
            and previous is not None
            and str(previous.thread_id) == str(next_thread_id)
        )
        next_run_id = run_id or (previous.run_id if continue_existing else f"run_{uuid.uuid4().hex}")
        next_context = RunContext(
            org_id=self.config.org_id,
            project_id=self.config.project_id,
            environment=self.config.environment,
            agent_id=self.config.agent_id,
            thread_id=next_thread_id,
            run_id=next_run_id,
            step_id=step_id or f"step_{uuid.uuid4().hex}",
            source_system=source_system or previous.source_system or self.config.source_system,
        )
        self.capture.default_context = next_context
        set_run_context(next_context)
        self._activate_runtime_scope(f"context:{next_thread_id}:{next_run_id}")
        self._prefer_explicit_run_scope = True
        if not continue_existing:
            self._zero_touch._taint_checked_prompt_object_ids.clear()
        return next_context

    @contextmanager
    def pinned_runtime_scope(self, scope: str):
        normalized = self._normalize_runtime_scope(scope) or self._default_runtime_scope()
        previous_context = self.capture.current_context()
        pin_token = _PINNED_RUNTIME_SCOPE.set(normalized)
        current_token = _CURRENT_RUNTIME_SCOPE.set(normalized)
        set_run_context(self._context_for_scope(normalized))
        try:
            yield normalized
        finally:
            _CURRENT_RUNTIME_SCOPE.reset(current_token)
            _PINNED_RUNTIME_SCOPE.reset(pin_token)
            set_run_context(previous_context)

    def _update_runtime_scope_from_window(
        self,
        messages: list[dict] | None,
        request_metadata: dict[str, Any] | None,
    ) -> str:
        pinned_scope = _PINNED_RUNTIME_SCOPE.get()
        if pinned_scope:
            return self._activate_runtime_scope(pinned_scope)
        if self._prefer_explicit_run_scope:
            return self.current_runtime_scope()
        scope = self._extract_runtime_scope_from_payload(request_metadata)
        if scope is None:
            scope = self._extract_runtime_scope_from_messages(messages)
        if scope:
            return self._activate_runtime_scope(scope)
        return self.current_runtime_scope()

    def runtime_loopbacks(
        self,
        *,
        scope: str | None = None,
        conversation_source: str | None = None,
    ) -> list[dict]:
        target_scope = scope or self.current_runtime_scope()
        target_source = str(conversation_source or "").strip()
        return [
            entry
            for entry in self._runtime_loopbacks
            if (
                target_source
                and (
                    str(entry.get("conversation_source") or "").strip() == target_source
                    or (
                        not str(entry.get("conversation_source") or "").strip()
                        and entry.get("runtime_scope") == target_scope
                    )
                )
            )
            or (not target_source and entry.get("runtime_scope") == target_scope)
        ]

    def observations(self, *, scope: str | None = None) -> list[dict]:
        target_scope = scope or self.current_runtime_scope()
        return [
            observation
            for observation in self._observations
            if observation.get("runtime_scope") == target_scope
        ]

    def activation_report(
        self,
        adapter_kind: str,
        attachment_mode: str,
        native_capabilities: list[str],
        *,
        framework_version: str | None = None,
        activation_source: str = "sdk_auto_init",
        visibility_gap_signals: list[str] | None = None,
        wrapper_contract_present: bool = False,
        wrapper_name: str | None = None,
    ) -> ActivationReport:
        report = ActivationReport(
            adapter_kind=adapter_kind,
            attachment_mode=attachment_mode,
            native_capabilities=native_capabilities,
            framework_version=framework_version,
            activation_source=activation_source,
            visibility_gap_signals=visibility_gap_signals or [],
            wrapper_contract_present=wrapper_contract_present,
            wrapper_name=wrapper_name,
        )
        self._otel_bridge.apply_report(report)
        return report

    def use_context(self, run_context: RunContext):
        return self.capture.use_context(run_context)

    @property
    def zero_touch(self) -> ZeroTouchRuntimeInstaller:
        return self._zero_touch

    @property
    def otel_bridge(self) -> VerifiedXOtelBridge:
        return self._otel_bridge

    @property
    def runtime_enabled(self) -> bool:
        return self._zero_touch.active

    def install_runtime(
        self,
        target=None,
        *,
        llm: dict[str, Any] | None = None,
        tools: dict[str, Any] | None = None,
        retrievals: dict[str, Any] | None = None,
        actions: dict[str, Any] | None = None,
        memories: dict[str, Any] | None = None,
        framework_version: str | None = None,
    ) -> ActivationReport:
        report = self.activation_report(
            "python_runtime",
            "hybrid",
            [
                "openai_calls",
                "tool_dispatch",
                "http_clients",
                "memory_reads",
                "memory_writes",
                "db_mutations",
                "queue_publish",
                "browser_clients",
                "aws_runtime_clients",
            ],
            framework_version=framework_version,
            activation_source="zero_touch_runtime_install",
        )
        self._zero_touch.install(report=report)
        self._otel_bridge.start(report=report)
        self.capture.set_default_adapter(report.to_adapter_context())
        self.record_activation_diagnostic(report)
        if target is not None:
            self.bind_harness(
                target,
                llm=llm,
                tools=tools,
                retrievals=retrievals,
                actions=actions,
                memories=memories,
            )
            try:
                setattr(target, "__verifiedx_activation_report__", report.as_dict())
            except Exception:
                pass
        return report

    def record_activation_diagnostic(self, report: ActivationReport):
        if not self.config.debug_decisions:
            return
        self._write_debug_record(
            {
                "kind": "verifiedx_activation_report",
                "ts": datetime.now(timezone.utc).isoformat(),
                "activation_report": report.as_dict(),
            }
        )

    def record_conversation_window(
        self,
        messages: list[dict] | None,
        *,
        source: str,
        model_name: str | None = None,
        tool_call_id: str | None = None,
        request_kind: str = "messages",
        request_metadata: dict[str, Any] | None = None,
        tool_choice: Any = None,
        tool_definitions: list[dict[str, Any]] | None = None,
        tool_call_ids: list[str] | None = None,
        inserted_context_object_ids: list[str] | None = None,
        omission_events: list[dict[str, Any]] | None = None,
        supported_adapter: bool = True,
        capture_gap_codes: list[str] | None = None,
        weak_signals: list[str] | None = None,
        remember_messages_as_context: bool = False,
        capture_source_kind: str = "runtime_patch",
        normalized_span_count_delta: int = 0,
    ):
        self._update_runtime_scope_from_window(messages, request_metadata)
        self._zero_touch.record_conversation_window(
            messages,
            source=source,
            model_name=model_name,
            tool_call_id=tool_call_id,
            request_kind=request_kind,
            request_metadata=request_metadata,
            tool_choice=tool_choice,
            tool_definitions=tool_definitions,
            tool_call_ids=tool_call_ids,
            inserted_context_object_ids=inserted_context_object_ids,
            omission_events=omission_events,
            supported_adapter=supported_adapter,
            capture_gap_codes=capture_gap_codes,
            weak_signals=weak_signals,
            remember_messages_as_context=remember_messages_as_context,
            capture_source_kind=capture_source_kind,
            normalized_span_count_delta=normalized_span_count_delta,
        )

    def observe_runtime_ingress(
        self,
        object_payload: dict,
        *,
        source_uri: str | None = None,
        source_hint: str | None = None,
    ):
        return self._zero_touch.observe_ingress(
            object_payload,
            source_uri=source_uri,
            source_hint=source_hint,
        )

    async def observe_runtime_ingress_async(
        self,
        object_payload: dict,
        *,
        source_uri: str | None = None,
        source_hint: str | None = None,
    ):
        return await self._zero_touch.observe_ingress_async(
            object_payload,
            source_uri=source_uri,
            source_hint=source_hint,
        )

    def derive_tool_runtime_context(
        self,
        fn,
        *,
        tool_name: str,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        schema: dict[str, Any] | None = None,
        docstring: str | None = None,
        metadata: dict[str, Any] | None = None,
        source: str = "sdk_tool_wrapper",
    ):
        return self._zero_touch.derive_tool_metadata(
            fn,
            tool_name=tool_name,
            args=args,
            kwargs=kwargs,
            schema=schema,
            docstring=docstring,
            metadata=metadata,
            source=source,
        )

    def tool_runtime_scope(self, context):
        return self._zero_touch.tool_invocation(context)

    def handle_runtime_tool_error(self, error: Exception):
        if isinstance(error, RuntimeExecutionFailureError):
            return error.tool_result
        if isinstance(error, RuntimeBoundaryDeniedError):
            return error.tool_result()
        return None

    def record_boundary_diagnostic(self, phase: str, request_payload: dict, decision: dict):
        if not self.config.debug_decisions:
            return
        record = {
            "kind": "verifiedx_boundary_diagnostic",
            "ts": datetime.now(timezone.utc).isoformat(),
            "phase": phase,
            "request_payload": request_payload,
            "decision": decision,
            }
        if self.config.debug_fetch_decisions and decision.get("decision_id"):
            try:
                record["stored_decision"] = self.client.get_decision(str(decision["decision_id"]))
                record["decision_trace_summary"] = _summarize_decision_trace(
                    record["stored_decision"]
                )
            except Exception as error:  # pragma: no cover - best-effort diagnostics
                record["stored_decision_error"] = str(error)
        self._write_debug_record(record)

    async def record_boundary_diagnostic_async(self, phase: str, request_payload: dict, decision: dict):
        if not self.config.debug_decisions:
            return
        record = {
            "kind": "verifiedx_boundary_diagnostic",
            "ts": datetime.now(timezone.utc).isoformat(),
            "phase": phase,
            "request_payload": request_payload,
            "decision": decision,
        }
        if self.config.debug_fetch_decisions and decision.get("decision_id"):
            try:
                record["stored_decision"] = await self.client.get_decision_async(
                    str(decision["decision_id"])
                )
                record["decision_trace_summary"] = _summarize_decision_trace(
                    record["stored_decision"]
                )
            except Exception as error:  # pragma: no cover - best-effort diagnostics
                record["stored_decision_error"] = str(error)
        self._write_debug_record(record)

    def record_ingress_diagnostic(self, phase: str, request_payload: dict, response: dict):
        if not self.config.debug_decisions:
            return
        record = {
            "kind": "verifiedx_ingress_diagnostic",
            "ts": datetime.now(timezone.utc).isoformat(),
            "phase": phase,
            "request_payload": request_payload,
            "response": response,
            "stage_trace_summary": _summarize_stage_traces(response.get("stage_traces") or []),
        }
        self._write_debug_record(record)

    def _write_debug_record(self, record: dict):
        payload = json.dumps(record, sort_keys=True)
        if self._debug_path is not None:
            self._debug_path.parent.mkdir(parents=True, exist_ok=True)
            with self._debug_path.open("a", encoding="utf-8") as handle:
                handle.write(payload)
                handle.write("\n")
        else:
            print(payload)

    def note_runtime_loopback(
        self,
        decision: dict,
        *,
        boundary_kind: str,
        action_class: str | None = None,
        goal_state_hint: str | None = None,
        pending_effect: dict | None = None,
    ):
        from .errors import build_loopback_tool_result

        loopback = decision.get("runtime_loopback") or {}
        tool_result = build_loopback_tool_result(
            decision,
            boundary_kind=boundary_kind,
            action_class=action_class,
            goal_state_hint=goal_state_hint,
            pending_effect=pending_effect,
        )
        pending_action_fingerprint = None
        decision_id = decision.get("decision_id")
        for cached in reversed(getattr(self.zero_touch, "_tool_preflight_cache", [])):
            cached_decision = cached.get("decision") or {}
            if decision_id and cached_decision.get("decision_id") == decision_id:
                pending_action_fingerprint = cached.get("pending_action_fingerprint")
                break
        entry = {
            "decision_id": decision.get("decision_id"),
            "outcome": decision.get("outcome"),
            "retry_fingerprint": loopback.get("retry_fingerprint"),
            "forbidden_action_fingerprint": decision.get("forbidden_action_fingerprint")
            or loopback.get("forbidden_action_fingerprint"),
            "forbidden_action_equivalence_class": decision.get(
                "forbidden_action_equivalence_class"
            )
            or loopback.get("forbidden_action_equivalence_class"),
            "goal_state_hint": goal_state_hint,
            "boundary_kind": boundary_kind,
            "action_class": action_class,
            "safe_next_steps": tool_result.get("safe_next_steps", []),
            "missing_support": loopback.get("missing_support") or decision.get("missing_support", []),
            "authorization_gaps": loopback.get("authorization_gaps")
            or decision.get("authorization_gaps", []),
            "contradiction_references": loopback.get("contradiction_references", []),
            "pending_effect": pending_effect or {},
            "pending_action_fingerprint": pending_action_fingerprint,
            "same_goal_state": loopback.get(
                "same_goal_state",
                (decision.get("retry_directive") or {}).get("same_goal_state", True),
            ),
            "human_review_terminal": bool(
                loopback.get("human_review_terminal", decision.get("human_review_terminal", False))
            ),
            "must_not_retry_same_action": bool(
                decision.get(
                    "must_not_retry_same_action",
                    loopback.get("must_not_retry_same_action", False),
                )
            ),
            "can_retry_same_action": (decision.get("retry_directive") or {}).get(
                "can_retry",
                not bool(
                    decision.get(
                        "must_not_retry_same_action",
                        loopback.get("must_not_retry_same_action", False),
                    )
                )
                and decision.get("outcome") == "replan_required",
            ),
            "observation_index_at_block": self._observation_counter,
            "runtime_scope": self.current_runtime_scope(),
            "conversation_source": self.current_conversation_source(),
            "reasons": decision.get("reasons") or [],
            "recorded_at": datetime.now(timezone.utc).isoformat(),
        }
        key = entry["retry_fingerprint"] or entry["decision_id"]
        self._runtime_loopbacks = [
            existing
            for existing in self._runtime_loopbacks
            if (existing.get("retry_fingerprint") or existing.get("decision_id")) != key
        ]
        self._runtime_loopbacks.append(entry)
        if len(self._runtime_loopbacks) > 8:
            del self._runtime_loopbacks[:-8]
        if self.config.debug_decisions:
            self._write_debug_record(
                {
                    "kind": "verifiedx_runtime_loopback",
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "loopback": entry,
                }
            )

    def note_observation(self, *, object_type: str, source_hint: str | None = None):
        self._observation_counter += 1
        self._observations.append(
            {
                "index": self._observation_counter,
                "object_type": object_type,
                "source_hint": source_hint,
                "runtime_scope": self.current_runtime_scope(),
            }
        )
        if len(self._observations) > 24:
            del self._observations[:-24]

    @staticmethod
    def _observation_is_retry_ready(observation: dict) -> bool:
        return observation.get("object_type") in {
            "internal_retrieval",
            "external_retrieval",
            "memory_record",
            "approval",
        }

    def observations_since_loopback(self, entry: dict) -> list[dict]:
        return [
            observation
            for observation in self.observations(scope=entry.get("runtime_scope"))
            if observation["index"] > entry.get("observation_index_at_block", 0)
        ]

    def retry_ready_loopbacks(self) -> list[dict]:
        ready = []
        for entry in self.runtime_loopbacks():
            if not entry.get("same_goal_state", True):
                continue
            if entry.get("human_review_terminal"):
                continue
            if entry.get("must_not_retry_same_action"):
                continue
            if entry.get("can_retry_same_action") is False:
                continue
            observations = self.observations_since_loopback(entry)
            retry_ready = [
                observation
                for observation in observations
                if self._observation_is_retry_ready(observation)
            ]
            if retry_ready:
                ready.append({"entry": entry, "observations": retry_ready})
        return ready

    def forced_replan_message(self) -> str | None:
        ready = self.retry_ready_loopbacks()
        if not ready:
            return None

        lines = [
            "VerifiedX retry gate:",
            "A previously blocked action that is explicitly retryable now has newer trusted evidence in the conversation.",
            "Do not finalize, stop, or claim the blocked goal is unresolved until you have reassessed that goal with the new evidence.",
            "Retry the same action only when the decision receipt allows it and the new evidence directly clears the blocker. Before returning a completion message, either issue the next safe retry or explain specifically why the new evidence still does not clear it.",
        ]
        for index, item in enumerate(ready, start=1):
            entry = item["entry"]
            summaries = "; ".join(
                f"{observation['object_type']} via {observation.get('source_hint') or 'unknown source'}"
                for observation in item["observations"][:3]
            )
            header = (
                f"{index}. goal={entry.get('goal_state_hint') or 'unspecified'} "
                f"boundary={entry.get('boundary_kind')}"
            )
            if entry.get("action_class"):
                header += f"/{entry['action_class']}"
            lines.append(header)
            lines.append(f"new_trusted_evidence: {summaries}")
            safe_next_steps = entry.get("safe_next_steps") or []
            if safe_next_steps:
                steps = "; ".join(
                    step.get("message", "") for step in safe_next_steps if step.get("message")
                )
                if steps:
                    lines.append(f"safe_retry_path: {steps}")
        return "\n".join(lines)

    def resolve_runtime_loopback(
        self,
        *,
        goal_state_hint: str | None = None,
        boundary_kind: str | None = None,
        action_class: str | None = None,
    ):
        if not self._runtime_loopbacks:
            return
        active_scope = self.current_runtime_scope()
        active_source = self.current_conversation_source()
        remaining = []
        for entry in self._runtime_loopbacks:
            entry_source = str(entry.get("conversation_source") or "").strip()
            if active_source:
                same_lineage = entry_source == active_source or (
                    not entry_source and entry.get("runtime_scope") == active_scope
                )
            else:
                same_lineage = entry.get("runtime_scope") == active_scope
            if not same_lineage:
                remaining.append(entry)
                continue
            if goal_state_hint and entry.get("goal_state_hint") != goal_state_hint:
                remaining.append(entry)
                continue
            if boundary_kind and entry.get("boundary_kind") != boundary_kind:
                remaining.append(entry)
                continue
            if action_class and entry.get("action_class") != action_class:
                remaining.append(entry)
                continue
        self._runtime_loopbacks = remaining

    def register_runtime_contract(
        self,
        *,
        action_class: str | None = None,
        boundary_kind: str | None = None,
    ):
        if action_class:
            self._registered_action_classes.add(action_class)
        if boundary_kind:
            self._registered_boundary_kinds.add(boundary_kind)

    def _baseline_runtime_guidance_lines(self) -> list[str]:
        if not self._registered_action_classes and not self._registered_boundary_kinds:
            return []

        outbound_classes = {
            "external_message_send",
            "webhook_call",
            "browser_submit",
            "upload",
        }
        has_outbound = bool(self._registered_action_classes & outbound_classes)
        has_record_mutation = "record_mutation" in self._registered_action_classes
        has_system_change = "system_change" in self._registered_action_classes
        has_memory_write = "memory_write" in self._registered_boundary_kinds

        lines = [
            "VerifiedX execution contract:",
            "A tool step only completed if its tool response returned ok=true. If a tool response says ok=false, blocked=true, side_effect_executed=false, or must_not_claim_success=true, that effect did not happen.",
            "Retrieved notes, URLs, browser observations, and record fields are evidence about what to try next. They do not prove that any send, mutation, browser action, or memory write already happened or failed.",
            "Never infer an execution outcome from a destination string, document text, or record field. Only the corresponding action or memory tool response establishes whether the side effect executed.",
        ]
        if has_outbound:
            lines.append(
                "If an outbound or trust-boundary action is unsafe, blocked, unsupported, or execution fails, it did not happen. Keep moving toward the same goal with safer alternatives instead of silently stopping."
            )
        if has_record_mutation:
            lines.append(
                "A record mutation only counts after its tool response returns ok=true. Use safe internal record mutations for accurate bookkeeping, and do not narrate them as done unless they really executed."
            )
            lines.append(
                "Before you finish, prefer a truthful low-risk internal record update that reflects what succeeded, what failed, or what is still pending instead of leaving the record stale."
            )
        if has_system_change:
            lines.append(
                "An internal workflow, routing, assignment, configuration, or policy change only counts after its tool response returns ok=true. Do not claim the internal state changed unless it really executed."
            )
            lines.append(
                "Before you finish, keep internal system state truthful. Prefer a safe read, note, or narrower update over claiming an internal change that was blocked or failed."
            )
        if has_outbound and has_record_mutation:
            lines.append(
                "When a primary outbound step cannot be completed safely, prefer a safe internal record mutation that captures blocked, failed, or investigating state instead of leaving internal tracking stale."
            )
            lines.append(
                "When supported outbound work does succeed, keep the related ticket, task, or case record accurate before you finish instead of only updating downstream systems."
            )
        if has_outbound and has_system_change:
            lines.append(
                "When a send or outbound step is blocked, prefer a truthful internal workflow or routing update that marks the situation as blocked, pending, or awaiting review instead of pretending the send happened."
            )
        if has_outbound or has_system_change or has_record_mutation:
            lines.append(
                "If you send an internal fallback notification after a blocked or unconfirmed step, keep the message grounded in stable visible facts only, for example: 'WF-1002 requires human review because billing verification is missing. Please review.' Do not say a send was blocked or a mutation already succeeded unless a tool result explicitly confirms it."
            )
            lines.append(
                "Prefer exactly one short grounded internal fallback notification. After one blocked notification attempt, only retry if you can materially narrow the wording to stable case facts and a request for review."
            )
            lines.append(
                "Avoid phrases like 'completed', 'saved', 'updated', 'moved', or 'blocked' in a fallback notification unless the matching tool response explicitly confirmed that exact outcome."
            )
        if has_memory_write:
            lines.append(
                "A durable memory write only counts after its tool response returns ok=true. If it is unsafe or unsupported, do not claim the memory changed."
            )
        if has_outbound and has_memory_write:
            lines.append(
                "If an outbound step is blocked or fails at execution time, and a harmless note-memory path is available, prefer recording the safe next step there while keeping internal record state truthful."
            )
        lines.append(
            "Do not finish while a safe retry, safe internal bookkeeping step, or evidence-gathering step still exists for the same user goal."
        )
        return lines

    def augment_messages_with_loopback(self, messages: list[dict]) -> list[dict]:
        runtime_loopbacks = self.runtime_loopbacks()
        lines = self._baseline_runtime_guidance_lines()
        if not runtime_loopbacks and not lines:
            return list(messages)

        if runtime_loopbacks:
            if lines:
                lines.append("")
            lines.extend(
                [
                    "VerifiedX runtime boundary state:",
                    "Prior blocked or ask-human steps did NOT execute and their goal state may still be outstanding.",
                    "Do not finish while unresolved goal hints remain and safe next steps still exist.",
                    "Retry the same action only when the decision receipt explicitly allows it and newer evidence directly clears the blocker. Otherwise keep the goal moving with a different safe path.",
                    "Do not narrate a blocked notification, mutation, or memory write as if it already happened.",
                    "Do not perform downstream completion steps that semantically depend on a blocked effect until a later allowed attempt returns ok=true.",
                ]
            )
        for index, entry in enumerate(runtime_loopbacks, start=1):
            header = (
                f"{index}. goal={entry.get('goal_state_hint') or 'unspecified'} "
                f"boundary={entry.get('boundary_kind')}"
            )
            if entry.get("action_class"):
                header += f"/{entry['action_class']}"
            header += f" outcome={entry.get('outcome')} decision_id={entry.get('decision_id')}"
            lines.append(header)

            safe_next_steps = entry.get("safe_next_steps") or []
            if safe_next_steps:
                steps = "; ".join(step.get("message", "") for step in safe_next_steps if step.get("message"))
                if steps:
                    lines.append(f"safe_next_steps: {steps}")
            if entry.get("must_not_retry_same_action"):
                lines.append(
                    "retry_policy: Do NOT retry this exact action. Keep the goal moving with a different safe step, reroute, escalation, or human decision."
                )
            elif entry.get("can_retry_same_action", True) and entry.get("same_goal_state", True):
                lines.append(
                    "retry_policy: Retry this exact action only if newer evidence or approval directly clears the unblock condition."
                )

            action_class = entry.get("action_class")
            goal_state_hint = entry.get("goal_state_hint")
            if goal_state_hint and action_class == "webhook_call":
                lines.append(
                    f"blocked_goal_warning: `{goal_state_hint}` is still incomplete because the notification did not happen. "
                    "Do not mark tickets or downstream state as notified or completed until an allowed webhook call returns ok=true."
                )
            elif goal_state_hint and action_class == "record_mutation":
                lines.append(
                    f"blocked_goal_warning: `{goal_state_hint}` is still incomplete because the mutation did not happen. "
                    "Do not claim the mutation succeeded until an allowed mutation returns ok=true."
                )
            elif goal_state_hint and action_class == "system_change":
                lines.append(
                    f"blocked_goal_warning: `{goal_state_hint}` is still incomplete because the internal workflow or system change did not happen. "
                    "Do not claim the status, routing, assignment, or configuration update succeeded until an allowed update returns ok=true."
                )
            elif goal_state_hint and entry.get("boundary_kind") == "memory_write":
                lines.append(
                    f"blocked_goal_warning: `{goal_state_hint}` is still incomplete because the durable memory write did not happen. "
                    "Do not claim the memory was saved until an allowed write returns ok=true."
                )

            missing_support = entry.get("missing_support") or []
            if missing_support:
                gaps = "; ".join(item.get("message", "") for item in missing_support if item.get("message"))
                if gaps:
                    lines.append(f"missing_support: {gaps}")

            contradictions = entry.get("contradiction_references") or []
            if contradictions:
                refs = "; ".join(
                    f"{item.get('parameter_name')}: {item.get('object_id')}"
                    for item in contradictions
                    if item.get("parameter_name") and item.get("object_id")
                )
                if refs:
                    lines.append(f"contradictions: {refs}")

            new_observations = self.observations_since_loopback(entry)
            if new_observations:
                prioritized = [
                    observation
                    for observation in new_observations
                    if observation["object_type"] in {"internal_retrieval", "memory_record"}
                ] or new_observations
                summaries = "; ".join(
                    f"{observation['object_type']} via {observation.get('source_hint') or 'unknown source'}"
                    for observation in prioritized[:3]
                )
                if entry.get("must_not_retry_same_action"):
                    lines.append(
                        "new_evidence_since_block: "
                        f"{summaries}. Use this newer evidence to keep the goal moving through a different safe path. Do not retry the blocked action unless a later decision explicitly allows it."
                    )
                else:
                    lines.append(
                        "new_evidence_since_block: "
                        f"{summaries}. Before you stop or take downstream completion actions, reassess whether this newer evidence resolves the blocked goal and retry the safe path if it now clears."
                    )
                if (
                    not entry.get("must_not_retry_same_action")
                    and any(self._observation_is_retry_ready(observation) for observation in new_observations)
                ):
                    lines.append(
                        "retry_ready_hint: New trusted evidence is now available. Before you finalize, attempt the safe retry path for this blocked goal or explain specifically why the new evidence still does not clear it."
                    )

        augmented = list(messages)
        augmented.append({"role": "system", "content": "\n".join(lines)})
        return augmented

    def wrap_llm_call(self, *args, **kwargs):
        from .wrappers import wrap_llm_call

        return wrap_llm_call(self, *args, **kwargs)

    def wrap_retrieve(self, *args, **kwargs):
        from .wrappers import wrap_retrieve

        return wrap_retrieve(self, *args, **kwargs)

    def wrap_tool_call(self, *args, **kwargs):
        from .wrappers import wrap_tool_call

        return wrap_tool_call(self, *args, **kwargs)

    @staticmethod
    def _resolve_reference(target, reference, *, default=None, require_callable=False):
        resolved = reference if reference is not None else default
        if resolved is None:
            return None
        if callable(resolved):
            return resolved
        if isinstance(resolved, str):
            if target is None:
                raise ValueError(f"Cannot resolve attribute reference `{resolved}` without a target")
            resolved = getattr(target, resolved)
        if require_callable and not callable(resolved):
            raise TypeError("Resolved binding reference must be callable")
        return resolved

    def bind_harness(
        self,
        target,
        *,
        user_instructions=None,
        llm: dict[str, Any] | None = None,
        tools: dict[str, Any] | None = None,
        retrievals: dict[str, Any] | None = None,
        actions: dict[str, Any] | None = None,
        memories: dict[str, Any] | None = None,
    ):
        if user_instructions:
            raise ValueError(
                "`bind_harness()` no longer accepts `user_instructions`; "
                "the V4 runtime derives conversation context from observed LLM calls."
            )

        if (actions or memories) and not self.runtime_enabled:
            self.install_runtime()
        if (actions or memories) and not self.runtime_enabled:
            raise ValueError(
                "`install_runtime()` must succeed before binding action or memory surfaces; "
                "the legacy semantic fallback path has been removed."
            )

        removed_semantic_keys = {
            "pending_action",
            "pending_memory_write",
            "user_instructions",
            "explicit_approvals",
            "explicit_denials",
            "candidate_object_ids",
            "approval_object_ids",
            "checkpoint_ids",
            "decision_context_ids",
            "goal_state_hint",
            "run_health_hints",
        }

        def reject_removed_semantic_keys(binding_name: str, spec: dict[str, Any]):
            removed = sorted(key for key in removed_semantic_keys if key in spec)
            if removed:
                removed_list = ", ".join(f"`{key}`" for key in removed)
                raise ValueError(
                    f"Bound surface `{binding_name}` still declares removed VerifiedX "
                    f"semantic config: {removed_list}. V4 only supports zero-builder install/bind metadata."
                )

        for name, raw_spec in (llm or {}).items():
            spec = {"model_name": raw_spec} if isinstance(raw_spec, str) else dict(raw_spec)
            fn = self._resolve_reference(target, spec.pop("fn", None), default=name, require_callable=True)
            setattr(target, name, self.wrap_llm_call(fn, **spec))

        for name, raw_spec in (tools or {}).items():
            spec = {"tool_name": raw_spec} if isinstance(raw_spec, str) else dict(raw_spec)
            fn = self._resolve_reference(target, spec.pop("fn", None), default=name, require_callable=True)
            spec.setdefault("tool_name", name)
            selection_metadata = dict(spec.pop("selection_metadata", {}) or {})
            selection_metadata.setdefault("semantic_class", "tool")
            selection_metadata["capture_only"] = True
            setattr(
                target,
                name,
                self.wrap_tool_call(
                    fn,
                    selection_metadata=selection_metadata,
                    capture_only=True,
                    **spec,
                ),
            )

        for name, raw_spec in (retrievals or {}).items():
            if isinstance(raw_spec, str):
                spec = {"query": raw_spec}
            elif isinstance(raw_spec, tuple):
                query, object_type = raw_spec
                spec = {"query": query, "object_type": object_type}
            else:
                spec = dict(raw_spec)
            fn = self._resolve_reference(target, spec.pop("fn", None), default=name, require_callable=True)
            setattr(target, name, self.wrap_retrieve(fn, **spec))

        for name, raw_spec in (actions or {}).items():
            spec = {"tool_name": raw_spec} if isinstance(raw_spec, str) else dict(raw_spec)
            reject_removed_semantic_keys(name, spec)
            fn = self._resolve_reference(target, spec.pop("fn", None), default=name, require_callable=True)
            tool_name = spec.get("tool_name", name)
            action_class = spec.get("action_class") or "generic"
            selection_metadata = dict(spec.pop("selection_metadata", {}) or {})
            pending_action = dict(selection_metadata.get("pending_action") or {})
            pending_action.setdefault("surface", "tool_dispatch")
            pending_action.setdefault("operation", tool_name)
            pending_action.setdefault("method", "CALL")
            pending_action.setdefault("boundary_kind", "action_execute")
            pending_action.setdefault("action_class", action_class)
            pending_action.setdefault("trust_boundary_crossing", False)
            selection_metadata["pending_action"] = pending_action
            selection_metadata.setdefault("semantic_class", "action_execute")
            tool_spec = {
                "tool_name": tool_name,
                "schema": spec.get("schema"),
                "docstring": spec.get("docstring"),
                "activation_report": spec.get("activation_report"),
                "object_type": spec.get("object_type", "tool_result"),
                "selection_metadata": selection_metadata,
            }
            setattr(target, name, self.wrap_tool_call(fn, **tool_spec))

        for name, raw_spec in (memories or {}).items():
            spec = {"tool_name": raw_spec} if isinstance(raw_spec, str) else dict(raw_spec)
            reject_removed_semantic_keys(name, spec)
            fn = self._resolve_reference(target, spec.pop("fn", None), default=name, require_callable=True)
            spec["tool_name"] = spec.get("tool_name", name)
            setattr(target, name, self.wrap_memory_write(fn, **spec))

        return self

    def wrap_memory_read(self, *args, **kwargs):
        from .wrappers import wrap_memory_read

        return wrap_memory_read(self, *args, **kwargs)

    def wrap_memory_write(self, *args, **kwargs):
        from .wrappers import wrap_memory_write

        return wrap_memory_write(self, *args, **kwargs)

    def wrap_action_execute(self, *args, **kwargs):
        from .wrappers import wrap_action_execute

        return wrap_action_execute(self, *args, **kwargs)


def _summarize_decision_trace(decision: dict) -> dict:
    stage_traces = decision.get("stage_traces") or []
    summary, model_invocations = _summarize_stage_traces(stage_traces)

    return {
        "decision_id": decision.get("decision_id"),
        "outcome": decision.get("outcome"),
        "action_class": decision.get("action_class"),
        "tier_count": len(stage_traces),
        "model_routes": [
            invocation["model_name"]
            for invocation in model_invocations
            if invocation.get("model_name")
        ],
        "model_invocations": model_invocations,
        "stages": summary,
    }


def _summarize_stage_traces(stage_traces: list[dict]) -> tuple[list[dict], list[dict]]:
    summary = []
    model_invocations = []
    for trace in stage_traces:
        model = trace.get("model_invocation") or {}
        model_entry = {
            "stage": trace.get("stage"),
            "decided_by": trace.get("decided_by"),
            "skipped": trace.get("skipped", False),
            "skip_reason": trace.get("skip_reason"),
            "model_invoked": bool(model.get("invoked")),
            "model_name": model.get("model_name"),
            "backend": model.get("backend"),
            "prompt_version": model.get("prompt_version"),
            "route_name": model.get("route_name"),
            "request_id": ((model.get("response_json") or {}).get("id")),
        }
        summary.append(
            {
                **model_entry,
                "input_keys": sorted((trace.get("input_summary") or {}).keys()),
                "output_keys": sorted((trace.get("output_summary") or {}).keys()),
            }
        )
        if model_entry["model_invoked"]:
            model_invocations.append(model_entry)
    return summary, model_invocations


def init_verifiedx(config: VerifiedXConfig | None = None, *, transport=None) -> VerifiedX:
    return VerifiedX(config=config, transport=transport)
