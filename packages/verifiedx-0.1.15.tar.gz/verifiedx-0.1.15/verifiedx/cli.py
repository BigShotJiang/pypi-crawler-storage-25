from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys

from .config import VerifiedXConfig
from .installer import format_install_plan, init_project, verify_project
from .runtime import init_verifiedx


def _detect_frameworks() -> dict[str, bool]:
    modules = {
        "langgraph": "langgraph",
        "langchain": "langchain",
        "openai_agents": "agents",
        "claude_agent_sdk": "claude_agent_sdk",
        "mcp": "mcp",
    }
    return {name: importlib.util.find_spec(module) is not None for name, module in modules.items()}


def doctor_command() -> int:
    config = VerifiedXConfig.from_env(require_api_key=False)
    vx = init_verifiedx(config=config)
    report = {
        "config": {
            "base_url": config.base_url,
            "org_id": config.org_id,
            "project_id": config.project_id,
            "environment": config.environment,
            "agent_id": config.agent_id,
            "api_key_configured": bool(config.api_key),
        },
        "frameworks": _detect_frameworks(),
        "health": None,
    }
    if config.api_key:
        try:
            report["health"] = vx.client.health_live()
        except Exception as error:  # pragma: no cover
            report["health"] = {"status": "unreachable", "error": str(error)}
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


def verify_command(*, root_dir: str, json_output: bool) -> int:
    report = verify_project(root_dir)
    if json_output:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print(format_install_plan(report))
    return 0


def init_command(*, root_dir: str, json_output: bool, write: bool) -> int:
    report = init_project(root_dir, write=write)
    if json_output:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print(format_install_plan(report))
        if report.get("writes"):
            print(f"\nWrote: {', '.join(report['writes'])}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="verifiedx")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("doctor")
    verify_parser = subparsers.add_parser("verify")
    verify_parser.add_argument("--json", action="store_true")
    verify_parser.add_argument("--cwd", default=str(Path.cwd()))
    init_parser = subparsers.add_parser("init")
    init_parser.add_argument("--json", action="store_true")
    init_parser.add_argument("--write", action="store_true")
    init_parser.add_argument("--cwd", default=str(Path.cwd()))
    args = parser.parse_args(argv)
    if args.command == "doctor":
        return doctor_command()
    if args.command == "verify":
        return verify_command(root_dir=args.cwd, json_output=bool(args.json))
    if args.command == "init":
        return init_command(root_dir=args.cwd, json_output=bool(args.json), write=bool(args.write))
    parser.print_help()
    return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main(sys.argv[1:]))
