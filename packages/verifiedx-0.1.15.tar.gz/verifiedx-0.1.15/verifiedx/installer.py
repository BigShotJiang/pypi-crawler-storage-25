from __future__ import annotations

import json
from pathlib import Path
import re
from typing import Any


TEXT_EXTENSIONS = {
    ".cjs",
    ".cts",
    ".js",
    ".jsx",
    ".mjs",
    ".mts",
    ".py",
    ".ts",
    ".tsx",
}
SKIP_DIRS = {
    ".git",
    ".next",
    ".turbo",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "target",
    "venv",
}
ENV_FILES = (".env.local", ".env", ".env.example", ".env.sample")


def _slugify(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    return normalized or "verifiedx-app"


def _read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return None


def _read_json(path: Path) -> dict[str, Any] | None:
    text = _read_text(path)
    if not text:
        return None
    try:
        parsed = json.loads(text)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def _source_files(root: Path) -> list[dict[str, Any]]:
    indexed: list[dict[str, Any]] = []
    for path in root.rglob("*"):
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if path.suffix.lower() not in TEXT_EXTENSIONS or not path.is_file():
            continue
        text = _read_text(path)
        if not text:
            continue
        indexed.append(
            {
                "relative_path": str(path.relative_to(root)).replace("\\", "/"),
                "absolute_path": str(path),
                "text": text,
            }
        )
    return indexed


def _package_manager(root: Path) -> str:
    if (root / "pnpm-lock.yaml").exists():
        return "pnpm"
    if (root / "bun.lockb").exists() or (root / "bun.lock").exists():
        return "bun"
    if (root / "yarn.lock").exists():
        return "yarn"
    if (root / "package-lock.json").exists():
        return "npm"
    if (root / "uv.lock").exists():
        return "uv"
    return "npm"


def _python_installer(root: Path) -> str:
    return "uv" if (root / "uv.lock").exists() else "pip"


def _dependency_set(package_json: dict[str, Any] | None) -> set[str]:
    dependency_names: set[str] = set()
    for key in ("dependencies", "devDependencies", "peerDependencies"):
        value = package_json.get(key) if isinstance(package_json, dict) else None
        if isinstance(value, dict):
            dependency_names.update(str(name) for name in value.keys())
    return dependency_names


def _matches(files: list[dict[str, Any]], patterns: list[re.Pattern[str]]) -> list[str]:
    matched: list[str] = []
    for file in files:
        if any(pattern.search(str(file["text"])) for pattern in patterns):
            matched.append(str(file["relative_path"]))
    return matched[:12]


def _files_with_extensions(files: list[dict[str, Any]], extensions: set[str]) -> list[dict[str, Any]]:
    return [
        file
        for file in files
        if Path(str(file["relative_path"])).suffix.lower() in extensions
    ]


def _env_lines(repo_slug: str) -> list[str]:
    return [
        "VERIFIEDX_API_KEY=vxpk_...",
        f"VERIFIEDX_AGENT_ID={repo_slug}-agent",
        f"VERIFIEDX_SOURCE_SYSTEM={repo_slug}",
    ]


def _uniq(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _candidate(
    *,
    kind: str,
    language: str,
    layer: str,
    confidence: float,
    reason: str,
    files: list[str],
    install_command: str,
    env_lines: list[str],
    integration_pattern: str,
    patch_summary: str,
    patch_hints: list[str],
    minimum_steps: list[str] | None = None,
    auto_apply: bool = False,
) -> dict[str, Any]:
    return {
        "kind": kind,
        "language": language,
        "layer": layer,
        "confidence": confidence,
        "reason": reason,
        "files": files,
        "install_command": install_command,
        "env_lines": env_lines,
        "integration_pattern": integration_pattern,
        "patch_summary": patch_summary,
        "patch_hints": patch_hints,
        "minimum_steps": list(minimum_steps or []),
        "auto_apply_supported": auto_apply,
    }


def _typescript_candidates(root: Path, package_json: dict[str, Any] | None, files: list[dict[str, Any]], repo_slug: str) -> list[dict[str, Any]]:
    typed_files = _files_with_extensions(files, {".cjs", ".cts", ".js", ".jsx", ".mjs", ".mts", ".ts", ".tsx"})
    dependency_set = _dependency_set(package_json)
    install_command = {
        "npm": "npm install @verifiedx-core/sdk",
        "pnpm": "pnpm add @verifiedx-core/sdk",
        "yarn": "yarn add @verifiedx-core/sdk",
        "bun": "bun add @verifiedx-core/sdk",
    }.get(_package_manager(root), "npm install @verifiedx-core/sdk")
    env_lines = _env_lines(repo_slug)
    candidates: list[dict[str, Any]] = []

    openai_agents_files = _matches(
        typed_files,
        [
            re.compile(r'from\s+["\']@openai/agents["\']'),
            re.compile(r'require\(["\']@openai/agents["\']\)'),
            re.compile(r"\bnew\s+Agent\s*\("),
            re.compile(r"\bRunner\."),
        ],
    )
    if "@openai/agents" in dependency_set or openai_agents_files:
        candidates.append(
            _candidate(
                kind="openai_agents_ts",
                language="typescript",
                layer="adapter",
                confidence=0.97 if openai_agents_files else 0.86,
                reason="Detected OpenAI Agents SDK usage. VerifiedX can guard action-producing tool calls through the native OpenAI Agents adapter without redesigning the workflow.",
                files=openai_agents_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="runner_or_agent_wrapper",
                patch_summary="Add @verifiedx-core/sdk, import the OpenAI Agents adapter, and route agent runs through VerifiedX's native run helper or wrap the agent with withVerifiedXAgent().",
                patch_hints=[
                    'Import from "@verifiedx-core/sdk/openai-agents".',
                    "Prefer replacing the existing run helper rather than rewriting tool definitions.",
                    "Keep the agent graph and tools unchanged; only wrap the boundary-producing run surface.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the existing app package.",
                    "Wrap the existing Agent or Runner entrypoint with withVerifiedXAgent(), withVerifiedXRunner(), or run().",
                    "Leave tool implementations and handoff topology unchanged.",
                ],
            )
        )

    claude_agent_files = _matches(
        typed_files,
        [
            re.compile(r'from\s+["\']@anthropic-ai/claude-agent-sdk["\']'),
            re.compile(r'require\(["\']@anthropic-ai/claude-agent-sdk["\']\)'),
            re.compile(r"\bcreateSdkMcpServer\s*\("),
            re.compile(r"\bquery\s+as\s+\w+"),
            re.compile(r"\btool\s*\("),
        ],
    )
    if "@anthropic-ai/claude-agent-sdk" in dependency_set or claude_agent_files:
        candidates.append(
            _candidate(
                kind="claude_agent_ts",
                language="typescript",
                layer="adapter",
                confidence=0.96 if claude_agent_files else 0.84,
                reason="Detected Claude Agent SDK usage. VerifiedX integrates at the existing query seam, preserving hooks, MCP servers, and built-in Claude tools.",
                files=claude_agent_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="query_wrapper",
                patch_summary="Import withVerifiedXClaudeQuery(), wrap the existing Claude query callable once, and keep the existing Claude Agent workflow and hooks intact.",
                patch_hints=[
                    'Import from "@verifiedx-core/sdk/claude-agent".',
                    "Wrap the existing query callable instead of inventing a new orchestration layer.",
                    "Leave Claude hooks, MCP servers, and tool definitions unchanged.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the current package.",
                    "Create verifiedxQuery = await withVerifiedXClaudeQuery(queryFn, { verifiedx }).",
                    "Replace direct query(...) calls with the wrapped query surface.",
                ],
            )
        )

    langgraph_files = _matches(
        typed_files,
        [
            re.compile(r'from\s+["\']langgraph["\']'),
            re.compile(r'from\s+["\']@langchain/langgraph["\']'),
            re.compile(r"\bStateGraph\b"),
            re.compile(r"\.compile\s*\("),
        ],
    )
    if "langgraph" in dependency_set or "@langchain/langgraph" in dependency_set or langgraph_files:
        candidates.append(
            _candidate(
                kind="langgraph_ts",
                language="typescript",
                layer="adapter",
                confidence=0.95 if langgraph_files else 0.83,
                reason="Detected LangGraph usage. VerifiedX's LangGraph adapter patches the native graph/runtime seams directly and is the cleanest few-LOC path for this stack.",
                files=langgraph_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="patched_runtime",
                patch_summary="Install the TypeScript SDK, import the LangGraph adapter, and call install() once during startup before graph compilation or invocation.",
                patch_hints=[
                    'Import from "@verifiedx-core/sdk/langgraph".',
                    "Prefer a single startup install() call instead of wrapping every node manually.",
                    "Do not change the graph topology or add VerifiedX-specific fallback nodes.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the existing app package.",
                    "Call install({ verifiedx }) from the LangGraph adapter before graph compilation.",
                    "Keep StateGraph nodes, tools, and checkpointer/store architecture intact.",
                ],
            )
        )

    vercel_ai_files = _matches(
        typed_files,
        [
            re.compile(r'from\s+["\']ai["\']'),
            re.compile(r"\bgenerateText\s*\("),
            re.compile(r"\bstreamText\s*\("),
        ],
    )
    if "ai" in dependency_set or vercel_ai_files:
        candidates.append(
            _candidate(
                kind="vercel_ai_ts",
                language="typescript",
                layer="adapter",
                confidence=0.92 if vercel_ai_files else 0.8,
                reason="Detected Vercel AI SDK usage. VerifiedX integrates through the existing generateText/streamText/tool-loop seams with minimal code movement.",
                files=vercel_ai_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="request_wrapper",
                patch_summary="Import the Vercel AI adapter helpers and wrap the existing generateText/streamText or tool-loop entrypoint.",
                patch_hints=[
                    'Import from "@verifiedx-core/sdk/vercel-ai".',
                    "Wrap the existing text generation surface instead of creating a new orchestration layer.",
                    "Keep tool implementations unchanged.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the existing app package.",
                    "Wrap generateText(), streamText(), or ToolLoopAgent with the VerifiedX helper.",
                    "Keep existing tools and prompt flow unchanged.",
                ],
            )
        )

    anthropic_direct_files = _matches(
        typed_files,
        [
            re.compile(r'from\s+["\']@anthropic-ai/sdk["\']'),
            re.compile(r'require\(["\']@anthropic-ai/sdk["\']\)'),
            re.compile(r"\bnew\s+Anthropic\s*\("),
            re.compile(r"\.messages\.create\s*\("),
            re.compile(r"\.messages\.stream\s*\("),
        ],
    )
    if "@anthropic-ai/sdk" in dependency_set or anthropic_direct_files:
        candidates.append(
            _candidate(
                kind="anthropic_direct_ts",
                language="typescript",
                layer="adapter",
                confidence=0.91 if anthropic_direct_files else 0.79,
                reason="Detected direct Anthropic SDK usage. VerifiedX can observe request surfaces through attach(), but exact tool execution blocking still requires createToolDispatcher().",
                files=anthropic_direct_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="client_attach_and_dispatcher",
                patch_summary="Attach the Anthropic client with the Anthropic direct adapter, then route local tool execution through createToolDispatcher(...) so local handlers are guarded at execution time.",
                patch_hints=[
                    'Import attach() and createToolDispatcher() from "@verifiedx-core/sdk/anthropic-direct".',
                    "Attach the existing Anthropic client instead of replacing it.",
                    "Keep the current tool loop and only swap direct local handler dispatch for the VerifiedX dispatcher.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the existing app package.",
                    "Wrap the Anthropic client with attach(client, { verifiedx }).",
                    "Dispatch local tool uses through createToolDispatcher({ tools, handlers, verifiedx }).",
                ],
            )
        )

    openai_direct_files = _matches(
        typed_files,
        [
            re.compile(r'from\s+["\']openai["\']'),
            re.compile(r"\bnew\s+OpenAI\s*\("),
            re.compile(r"\.responses\.create\s*\("),
            re.compile(r"\.chat\.completions\.create\s*\("),
        ],
    )
    if "openai" in dependency_set or openai_direct_files:
        candidates.append(
            _candidate(
                kind="openai_direct_ts",
                language="typescript",
                layer="adapter",
                confidence=0.9 if openai_direct_files else 0.78,
                reason="Detected direct OpenAI API usage. VerifiedX can attach to the client automatically, but execution-time protection still requires routing local tool handlers through the OpenAI direct dispatcher.",
                files=openai_direct_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="client_attach_and_dispatcher",
                patch_summary="Attach the OpenAI client with the OpenAI direct adapter, then route local tool execution through createToolDispatcher(...) so the exact tool handler is guarded at execution time.",
                patch_hints=[
                    'Import attach() and createToolDispatcher() from "@verifiedx-core/sdk/openai-direct".',
                    "Keep the existing tool loop and tool definitions; only swap direct handler invocation for the VerifiedX dispatcher.",
                    "Do not add fallback lanes or fake routing to make VerifiedX look good.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the existing app package.",
                    "Wrap the OpenAI client with attach(client, { verifiedx }).",
                    "Dispatch local tool calls through createToolDispatcher({ tools, handlers, verifiedx }).",
                ],
            )
        )

    mcp_files = _matches(
        typed_files,
        [
            re.compile(r'from\s+["\']@modelcontextprotocol/sdk["\']'),
            re.compile(r'require\(["\']@modelcontextprotocol/sdk["\']\)'),
            re.compile(r"\bMcpServer\b"),
            re.compile(r"\bFastMCP\b"),
        ],
    )
    if "@modelcontextprotocol/sdk" in dependency_set or mcp_files:
        candidates.append(
            _candidate(
                kind="mcp_ts",
                language="typescript",
                layer="explicit_wrapper",
                confidence=0.82 if mcp_files else 0.7,
                reason="Detected MCP server/tool definitions. VerifiedX can guard these tools directly with wrapMcpTool() without redesigning the server or orchestration flow.",
                files=mcp_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="explicit_mcp_wrapper",
                patch_summary="Install the TypeScript SDK, import wrapMcpTool(), and wrap the existing MCP tool handlers or definitions at the point they are registered.",
                patch_hints=[
                    'Import wrapMcpTool from "@verifiedx-core/sdk/mcp".',
                    "Wrap the existing MCP tool definition or handler instead of introducing a parallel tool registry.",
                    "Keep the MCP server topology and upstream orchestrator behavior unchanged.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the existing app package.",
                    "Import wrapMcpTool() from the VerifiedX MCP surface.",
                    "Wrap the existing MCP tool registration/handler path and leave server routing unchanged.",
                ],
            )
        )

    lower_seam_signals = _uniq(
        [
            *_matches(typed_files, [re.compile(r"\bfetch\s*\(")]),
            *_matches(typed_files, [re.compile(r'from\s+["\']pg["\']'), re.compile(r'require\(["\']pg["\']\)'), re.compile(r"\bClient\s*\(")]),
            *_matches(typed_files, [re.compile(r'from\s+["\']amqplib["\']'), re.compile(r'require\(["\']amqplib["\']\)')]),
            *_matches(typed_files, [re.compile(r"\bwriteFileSync\s*\("), re.compile(r"\bappendFileSync\s*\("), re.compile(r"\bfs\.promises\.writeFile\s*\("), re.compile(r"\bwriteFile\s*\(")]),
        ]
    )
    if lower_seam_signals:
        candidates.append(
            _candidate(
                kind="lower_seam_ts",
                language="typescript",
                layer="lower_seam",
                confidence=0.58 if any(candidate["layer"] == "adapter" for candidate in candidates) else 0.74,
                reason="Detected lower-level trust-boundary seams such as fetch, DB, queue, or file-write surfaces. VerifiedX can activate these through one startup initVerifiedX() call with lower-seam fallbacks enabled.",
                files=lower_seam_signals,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="runtime_lower_seam_install",
                patch_summary="Install the TypeScript SDK, call initVerifiedX() once during app startup, and let the SDK patch supported lower seams like fetch, pg, amqplib, and file writes.",
                patch_hints=[
                    'Import initVerifiedX from "@verifiedx-core/sdk".',
                    "Keep installLowerSeamFallbacks enabled unless the repo already has a stronger adapter seam in place.",
                    "Do not rewrite business logic or add fallback orchestration just to surface VerifiedX.",
                ],
                minimum_steps=[
                    "Install @verifiedx-core/sdk into the existing app package.",
                    "Create a single startup VerifiedX instance with initVerifiedX().",
                    "Let VerifiedX patch supported lower seams and keep the existing business code unchanged.",
                ],
            )
        )

    return candidates


def _python_candidates(root: Path, pyproject_text: str | None, requirements_text: str | None, files: list[dict[str, Any]], repo_slug: str) -> list[dict[str, Any]]:
    typed_files = _files_with_extensions(files, {".py"})
    dependency_text = f"{pyproject_text or ''}\n{requirements_text or ''}".lower()
    install_command = "uv add verifiedx" if _python_installer(root) == "uv" else "pip install verifiedx"
    env_lines = _env_lines(repo_slug)
    candidates: list[dict[str, Any]] = []

    langgraph_files = _matches(
        typed_files,
        [
            re.compile(r"^\s*from\s+langgraph\b", re.MULTILINE),
            re.compile(r"^\s*import\s+langgraph\b", re.MULTILINE),
            re.compile(r"\bStateGraph\b"),
            re.compile(r"\.compile\s*\("),
        ],
    )
    if "langgraph" in dependency_text or langgraph_files:
        candidates.append(
            _candidate(
                kind="langgraph_py",
                language="python",
                layer="adapter",
                confidence=0.97 if langgraph_files else 0.85,
                reason="Detected LangGraph usage. VerifiedX's Python LangGraph adapter is a strong native seam and preserves the builder's existing graph design.",
                files=langgraph_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="patched_runtime",
                patch_summary="Install verifiedx, import install_langgraph or compile from verifiedx.langgraph, and activate it once during startup before graph compilation.",
                patch_hints=[
                    "Import install_langgraph from verifiedx.",
                    "Prefer one startup install rather than wrapping nodes by hand.",
                    "Keep the graph, store, and checkpointer architecture intact.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Call install_langgraph() before compiling the graph or import compile from verifiedx.",
                    "Keep the existing StateGraph topology, nodes, and checkpointer/store design unchanged.",
                ],
            )
        )

    langchain_files = _matches(
        typed_files,
        [
            re.compile(r"^\s*from\s+langchain\b", re.MULTILINE),
            re.compile(r"^\s*import\s+langchain\b", re.MULTILINE),
            re.compile(r"\bcreate_agent\s*\("),
        ],
    )
    if "langchain" in dependency_text or langchain_files:
        candidates.append(
            _candidate(
                kind="langchain_py",
                language="python",
                layer="adapter",
                confidence=0.95 if langchain_files else 0.82,
                reason="Detected LangChain usage. VerifiedX's Python LangChain create_agent surface is the cleanest minimal integration path for this stack.",
                files=langchain_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="factory_swap",
                patch_summary="Swap the existing LangChain create_agent import to verifiedx.langchain.create_agent so VerifiedX middleware is added without restructuring the app.",
                patch_hints=[
                    'Replace "from langchain.agents import create_agent" with "from verifiedx.langchain import create_agent".',
                    "Keep the existing tools, model, and middleware arguments unless they conflict with VerifiedX.",
                    "Do not introduce a sidecar orchestration layer.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Replace the LangChain create_agent import with verifiedx.langchain.create_agent.",
                    "Keep existing tools, model configuration, and prompt flow unchanged.",
                ],
            )
        )

    claude_agent_files = _matches(
        typed_files,
        [
            re.compile(r"^\s*from\s+claude_agent_sdk\b", re.MULTILINE),
            re.compile(r"^\s*import\s+claude_agent_sdk\b", re.MULTILINE),
            re.compile(r"\bcreate_sdk_mcp_server\s*\("),
            re.compile(r"\bClaudeAgentOptions\b"),
            re.compile(r"\btool\s*\("),
        ],
    )
    if "claude_agent_sdk" in dependency_text or claude_agent_files:
        candidates.append(
            _candidate(
                kind="claude_agent_py",
                language="python",
                layer="adapter",
                confidence=0.96 if claude_agent_files else 0.84,
                reason="Detected Claude Agent SDK usage. VerifiedX integrates at the query seam and preserves existing hooks, MCP servers, and Claude built-ins.",
                files=claude_agent_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="query_wrapper",
                patch_summary="Install verifiedx and replace direct Claude query calls with verifiedx.claude_query(...) or a wrapped query callable from attach_claude_query().",
                patch_hints=[
                    "Import claude_query or attach_claude_query from verifiedx.",
                    "Wrap the existing query surface instead of rebuilding the agent workflow.",
                    "Leave Claude hooks, MCP servers, and tool definitions unchanged.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Create a wrapped Claude query surface with attach_claude_query(query_callable, verifiedx=vx) or call claude_query(...).",
                    "Replace direct query(...) calls with the wrapped VerifiedX query surface.",
                ],
            )
        )

    openai_agents_files = _matches(
        typed_files,
        [
            re.compile(r"^\s*from\s+agents\b", re.MULTILINE),
            re.compile(r"^\s*import\s+agents\b", re.MULTILINE),
            re.compile(r"\bRunner\.(run_sync|run_streamed)\b"),
            re.compile(r"\bAgent\s*\("),
        ],
    )
    if "openai-agents" in dependency_text or re.search(r"\bagents\b", dependency_text) or openai_agents_files:
        candidates.append(
            _candidate(
                kind="openai_agents_py",
                language="python",
                layer="adapter",
                confidence=0.93 if openai_agents_files else 0.8,
                reason="Detected OpenAI Agents SDK usage. VerifiedX can attach at the native agent/runner seam without changing the workflow graph.",
                files=openai_agents_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="runner_or_agent_wrapper",
                patch_summary="Install verifiedx and route the existing run path through verifiedx.run_openai_agents_sync / run_openai_agents_streamed or attach the agent once with attach_openai_agents_agent().",
                patch_hints=[
                    "Import the OpenAI Agents helpers from verifiedx.",
                    "Prefer replacing the run surface, not the tool definitions.",
                    "Keep the existing agent topology and handoffs.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Wrap the current OpenAI Agents runner or agent entrypoint with the VerifiedX helper.",
                    "Leave agent topology, tools, and handoffs unchanged.",
                ],
            )
        )

    anthropic_direct_files = _matches(
        typed_files,
        [
            re.compile(r"^\s*from\s+anthropic\b", re.MULTILINE),
            re.compile(r"^\s*import\s+anthropic\b", re.MULTILINE),
            re.compile(r"\bAnthropic\s*\("),
            re.compile(r"\.messages\.create\s*\("),
            re.compile(r"\.messages\.stream\s*\("),
        ],
    )
    if "anthropic" in dependency_text or anthropic_direct_files:
        candidates.append(
            _candidate(
                kind="anthropic_direct_py",
                language="python",
                layer="adapter",
                confidence=0.91 if anthropic_direct_files else 0.79,
                reason="Detected direct Anthropic SDK usage. VerifiedX can observe the Anthropic client surface, but exact tool execution blocking still depends on create_anthropic_tool_dispatcher(...).",
                files=anthropic_direct_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="client_attach_and_dispatcher",
                patch_summary="Attach the Anthropic client with verifiedx.attach_anthropic and dispatch local tool uses through create_anthropic_tool_dispatcher(...).",
                patch_hints=[
                    "Import attach_anthropic and create_anthropic_tool_dispatcher from verifiedx.",
                    "Attach the existing Anthropic client instead of replacing it.",
                    "Keep the current tool loop and only swap direct local handler dispatch for the VerifiedX dispatcher.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Wrap the Anthropic client with attach_anthropic(client, verifiedx=vx).",
                    "Dispatch local tool uses through create_anthropic_tool_dispatcher(tool_handlers=..., tools=..., verifiedx=vx).",
                ],
            )
        )

    openai_direct_files = _matches(
        typed_files,
        [
            re.compile(r"^\s*from\s+openai\b", re.MULTILINE),
            re.compile(r"^\s*import\s+openai\b", re.MULTILINE),
            re.compile(r"\bOpenAI\s*\("),
            re.compile(r"\.responses\.create\s*\("),
            re.compile(r"\.chat\.completions\.create\s*\("),
        ],
    )
    if "openai" in dependency_text or openai_direct_files:
        candidates.append(
            _candidate(
                kind="openai_direct_py",
                language="python",
                layer="adapter",
                confidence=0.9 if openai_direct_files else 0.77,
                reason="Detected direct OpenAI API usage. VerifiedX can attach to the client automatically, but exact action blocking still depends on routing local tool execution through create_openai_tool_dispatcher(...).",
                files=openai_direct_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="client_attach_and_dispatcher",
                patch_summary="Attach the OpenAI client with verifiedx.attach_openai and use create_openai_tool_dispatcher(...) for local tool execution.",
                patch_hints=[
                    "Import attach_openai and create_openai_tool_dispatcher from verifiedx.",
                    "Keep the existing tool loop and handler map; only swap the direct handler dispatch.",
                    "Do not build synthetic fallback flows.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Wrap the OpenAI client with attach_openai(client, verifiedx=vx).",
                    "Dispatch local tool calls through create_openai_tool_dispatcher(tool_handlers=..., tools=..., verifiedx=vx).",
                ],
            )
        )

    mcp_files = _matches(
        typed_files,
        [
            re.compile(r"^\s*from\s+mcp\b", re.MULTILINE),
            re.compile(r"^\s*import\s+mcp\b", re.MULTILINE),
            re.compile(r"^\s*from\s+fastmcp\b", re.MULTILINE),
            re.compile(r"^\s*import\s+fastmcp\b", re.MULTILINE),
            re.compile(r"\bFastMCP\b"),
        ],
    )
    if "mcp" in dependency_text or "fastmcp" in dependency_text or mcp_files:
        candidates.append(
            _candidate(
                kind="mcp_py",
                language="python",
                layer="explicit_wrapper",
                confidence=0.82 if mcp_files else 0.7,
                reason="Detected MCP server/tool definitions. VerifiedX can guard MCP tools directly through wrap_tool_handler() or wrap_tool_definition() without changing the server topology.",
                files=mcp_files,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="explicit_mcp_wrapper",
                patch_summary="Install verifiedx and wrap the existing MCP tool handlers or definitions at registration time with the native MCP wrapper helpers.",
                patch_hints=[
                    "Import wrap_tool_handler or wrap_tool_definition from verifiedx.",
                    "Wrap the existing MCP tool registration path rather than creating a parallel server.",
                    "Keep current MCP transport and orchestration behavior unchanged.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Import wrap_tool_handler() or wrap_tool_definition() from verifiedx.",
                    "Wrap the current MCP tool registration/handler path and leave server routing intact.",
                ],
            )
        )

    lower_seam_signals = _uniq(
        [
            *_matches(typed_files, [re.compile(r"^\s*import\s+requests\b", re.MULTILINE), re.compile(r"^\s*from\s+requests\b", re.MULTILINE)]),
            *_matches(typed_files, [re.compile(r"^\s*import\s+httpx\b", re.MULTILINE), re.compile(r"^\s*from\s+httpx\b", re.MULTILINE)]),
            *_matches(typed_files, [re.compile(r"^\s*import\s+sqlalchemy\b", re.MULTILINE), re.compile(r"^\s*from\s+sqlalchemy\b", re.MULTILINE)]),
            *_matches(typed_files, [re.compile(r"^\s*import\s+psycopg\b", re.MULTILINE), re.compile(r"^\s*from\s+psycopg\b", re.MULTILINE), re.compile(r"^\s*import\s+psycopg2\b", re.MULTILINE), re.compile(r"^\s*from\s+psycopg2\b", re.MULTILINE)]),
            *_matches(typed_files, [re.compile(r"^\s*import\s+botocore\b", re.MULTILINE), re.compile(r"^\s*from\s+botocore\b", re.MULTILINE)]),
            *_matches(typed_files, [re.compile(r"^\s*import\s+kombu\b", re.MULTILINE), re.compile(r"^\s*from\s+kombu\b", re.MULTILINE)]),
            *_matches(typed_files, [re.compile(r"^\s*import\s+playwright\b", re.MULTILINE), re.compile(r"^\s*from\s+playwright\b", re.MULTILINE)]),
        ]
    )
    if lower_seam_signals:
        candidates.append(
            _candidate(
                kind="lower_seam_py",
                language="python",
                layer="lower_seam",
                confidence=0.58 if any(candidate["layer"] == "adapter" for candidate in candidates) else 0.74,
                reason="Detected lower-level trust-boundary seams such as HTTP, DB, queue, browser, or cloud SDK surfaces. VerifiedX can activate these through init_verifiedx() plus install_runtime().",
                files=lower_seam_signals,
                install_command=install_command,
                env_lines=env_lines,
                integration_pattern="runtime_zero_touch_install",
                patch_summary="Install verifiedx, create a single VerifiedX runtime with init_verifiedx(), and call install_runtime() once so the SDK patches supported lower seams like requests/httpx/sqlalchemy/botocore/kombu/playwright.",
                patch_hints=[
                    "Import init_verifiedx from verifiedx.",
                    "Call vx.install_runtime() once during startup instead of wrapping every function manually.",
                    "Keep the existing business logic and orchestration topology unchanged.",
                ],
                minimum_steps=[
                    "Install verifiedx into the current Python environment.",
                    "Create a single runtime with init_verifiedx().",
                    "Call vx.install_runtime() once during startup and keep the current business code unchanged.",
                ],
            )
        )

    return candidates


def _verifiedx_presence(files: list[dict[str, Any]], package_json: dict[str, Any] | None, python_project_text: str) -> dict[str, Any]:
    dependency_set = _dependency_set(package_json)
    import_matches = _matches(
        files,
        [
            re.compile(r"@verifiedx-core/sdk"),
            re.compile(r"\bfrom\s+verifiedx\b"),
            re.compile(r"\bimport\s+verifiedx\b"),
        ],
    )
    dependency_present = "@verifiedx-core/sdk" in dependency_set or "verifiedx" in python_project_text
    return {
        "dependency_present": dependency_present,
        "import_matches": import_matches,
        "status": "present" if dependency_present or import_matches else "missing",
    }


def _capture_trigger_layers(files: list[dict[str, Any]], candidates: list[dict[str, Any]]) -> dict[str, Any]:
    typed_ts = _files_with_extensions(files, {".cjs", ".cts", ".js", ".jsx", ".mjs", ".mts", ".ts", ".tsx"})
    typed_py = _files_with_extensions(files, {".py"})
    explicit_wrapper_signals = _uniq(
        [
            *_matches(
                typed_ts,
                [
                    re.compile(r"\bbindHarness\s*\("),
                    re.compile(r"\bwrapToolCall\s*\("),
                    re.compile(r"\bwrapMemoryWrite\s*\("),
                    re.compile(r"\bwrapActionExecute\s*\("),
                    re.compile(r"\bwrapMcpTool\s*\("),
                ],
            ),
            *_matches(
                typed_py,
                [
                    re.compile(r"\bbind_harness\s*\("),
                    re.compile(r"\bwrap_tool_call\s*\("),
                    re.compile(r"\bwrap_memory_write\s*\("),
                    re.compile(r"\bwrap_action_execute\s*\("),
                    re.compile(r"\bwrap_tool_handler\s*\("),
                    re.compile(r"\bwrap_tool_definition\s*\("),
                ],
            ),
        ]
    )
    return {
        "adapter_surfaces": {
            "detected": [candidate["kind"] for candidate in candidates if candidate["layer"] == "adapter"],
            "status": "detected" if any(candidate["layer"] == "adapter" for candidate in candidates) else "not_detected",
        },
        "lower_seam_surfaces": {
            "detected": [candidate["kind"] for candidate in candidates if candidate["layer"] == "lower_seam"],
            "status": "detected" if any(candidate["layer"] == "lower_seam" for candidate in candidates) else "not_detected",
            "supported_runtime_entrypoints": [
                "typescript:initVerifiedX()+installLowerSeamFallbacks",
                "python:init_verifiedx()+install_runtime()",
            ],
        },
        "explicit_wrapper_surfaces": {
            "detected": _uniq(
                [candidate["kind"] for candidate in candidates if candidate["layer"] == "explicit_wrapper"]
                + explicit_wrapper_signals
            ),
            "status": "detected" if explicit_wrapper_signals or any(candidate["layer"] == "explicit_wrapper" for candidate in candidates) else "not_detected",
            "supported_wrappers": [
                "typescript:bindHarness",
                "typescript:wrapToolCall",
                "typescript:wrapMemoryWrite",
                "typescript:wrapActionExecute",
                "typescript:wrapMcpTool",
                "python:bind_harness",
                "python:wrap_tool_call",
                "python:wrap_memory_write",
                "python:wrap_action_execute",
                "python:wrap_tool_handler",
                "python:wrap_tool_definition",
            ],
        },
    }


def _env_files(root: Path) -> list[str]:
    return [name for name in ENV_FILES if (root / name).exists()]


def build_install_plan(root_dir: str | Path = ".") -> dict[str, Any]:
    root = Path(root_dir).resolve()
    repo_slug = _slugify(root.name)
    package_json = _read_json(root / "package.json")
    pyproject_text = _read_text(root / "pyproject.toml")
    requirements_text = _read_text(root / "requirements.txt")
    files = _source_files(root)
    candidates = [
        *_typescript_candidates(root, package_json, files, repo_slug),
        *_python_candidates(root, pyproject_text, requirements_text, files, repo_slug),
    ]
    recommended = max(candidates, key=lambda item: float(item["confidence"]), default=None)
    verifiedx = _verifiedx_presence(files, package_json, f"{pyproject_text or ''}\n{requirements_text or ''}".lower())
    return {
        "repo_root": str(root),
        "repo_slug": repo_slug,
        "package_manager": _package_manager(root),
        "env_files_present": _env_files(root),
        "verifiedx": verifiedx,
        "capture_trigger_layers": _capture_trigger_layers(files, candidates),
        "candidates": candidates,
        "recommended": recommended,
    }


def format_install_plan(plan: dict[str, Any]) -> str:
    lines = [
        f"Repo: {plan['repo_root']}",
        f"VerifiedX status: {plan['verifiedx']['status']}",
    ]
    recommended = plan.get("recommended")
    if recommended:
        lines.append(f"Recommended integration: {recommended['kind']}")
        if recommended.get("layer"):
            lines.append(f"Capture/trigger layer: {recommended['layer']}")
        if recommended.get("integration_pattern"):
            lines.append(f"Integration pattern: {recommended['integration_pattern']}")
        lines.append(str(recommended["reason"]))
        lines.append(f"Install: {recommended['install_command']}")
        lines.append(f"Patch strategy: {recommended['patch_summary']}")
        files = recommended.get("files") or []
        if files:
            lines.append(f"Likely files: {', '.join(files)}")
        steps = recommended.get("minimum_steps") or []
        if steps:
            lines.append("Minimum steps:")
            for step in steps:
                lines.append(f"- {step}")
    else:
        lines.append("No supported integration target detected.")
    layers = plan.get("capture_trigger_layers") or {}
    adapter_surfaces = layers.get("adapter_surfaces") or {}
    lower_seam_surfaces = layers.get("lower_seam_surfaces") or {}
    explicit_wrapper_surfaces = layers.get("explicit_wrapper_surfaces") or {}
    lines.append(
        f"Adapter seams: {adapter_surfaces.get('status', 'not_detected')}"
        + (f" ({', '.join(adapter_surfaces.get('detected') or [])})" if adapter_surfaces.get("detected") else "")
    )
    lines.append(
        f"Lower seams: {lower_seam_surfaces.get('status', 'not_detected')}"
        + (f" ({', '.join(lower_seam_surfaces.get('detected') or [])})" if lower_seam_surfaces.get("detected") else "")
    )
    lines.append(
        f"Explicit wrappers: {explicit_wrapper_surfaces.get('status', 'not_detected')}"
        + (f" ({', '.join(explicit_wrapper_surfaces.get('detected') or [])})" if explicit_wrapper_surfaces.get("detected") else "")
    )
    return "\n".join(lines)


def _write_env_template(root: Path, repo_slug: str) -> str:
    target = root / ".env.example"
    existing = _read_text(target)
    lines = existing.splitlines() if existing else []
    next_lines = list(lines)
    for entry in _env_lines(repo_slug):
        key = entry.split("=", 1)[0]
        if not any(line.startswith(f"{key}=") for line in next_lines):
            next_lines.append(entry)
    target.write_text("\n".join(line for line in next_lines if line) + "\n", encoding="utf-8")
    return str(target.relative_to(root)).replace("\\", "/")


def init_project(root_dir: str | Path = ".", *, write: bool = False) -> dict[str, Any]:
    plan = build_install_plan(root_dir)
    writes: list[str] = []
    root = Path(str(plan["repo_root"]))
    if write:
        verifiedx_dir = root / ".verifiedx"
        verifiedx_dir.mkdir(parents=True, exist_ok=True)
        plan_path = verifiedx_dir / "install-plan.json"
        plan_path.write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8")
        writes.append(str(plan_path.relative_to(root)).replace("\\", "/"))
        writes.append(_write_env_template(root, str(plan["repo_slug"])))
    result = dict(plan)
    result["writes"] = writes
    return result


def verify_project(root_dir: str | Path = ".") -> dict[str, Any]:
    return build_install_plan(root_dir)
