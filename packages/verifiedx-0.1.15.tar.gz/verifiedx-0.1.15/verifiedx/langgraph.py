from __future__ import annotations

from contextlib import nullcontext
import functools
import importlib.metadata
import inspect
import json
import re
from typing import Any
import uuid

try:
    from langgraph.checkpoint.base import BaseCheckpointSaver
except Exception:  # pragma: no cover - older langgraph layouts
    BaseCheckpointSaver = object  # type: ignore[misc,assignment]

try:
    from langgraph.types import Command
except Exception:  # pragma: no cover - older langgraph layouts
    Command = None  # type: ignore[misc,assignment]

try:
    from langchain_core.tools import BaseTool
except Exception:  # pragma: no cover - optional langchain dependency layouts
    BaseTool = None  # type: ignore[misc,assignment]


LANGGRAPH_ADAPTER_KIND = "langgraph"
LANGGRAPH_NATIVE_CAPABILITIES = [
    "state_graph.compile",
    "state_graph.add_node",
    "graph.invoke",
    "graph.ainvoke",
    "graph.stream",
    "graph.astream",
    "graph.get_state",
    "graph.update_state",
    "Command.update",
    "langchain_core.tools.BaseTool.invoke",
    "langchain_core.tools.BaseTool.ainvoke",
    "AIMessage.tool_calls",
    "ToolMessage.tool_call_id",
    "checkpointer.put",
    "checkpointer.put_writes",
    "store.get",
    "store.search",
    "store.put",
    "store.delete",
]
_LANGGRAPH_INSTALL_STATE: dict[str, Any] = {
    "verifiedx": None,
    "framework_version": None,
}
_LANGGRAPH_SYNTHETIC_SEARCH_KEY = "__verifiedx_langgraph_search__"
_LANGGRAPH_SYNTHETIC_STATE_KEY = "__verifiedx_langgraph_state__"


def _langgraph_framework_version(default: str | None = None) -> str | None:
    if default:
        return default
    try:
        return importlib.metadata.version("langgraph")
    except Exception:  # pragma: no cover - metadata can be absent in local editable installs
        return None


def _current_langgraph_verifiedx():
    return _LANGGRAPH_INSTALL_STATE.get("verifiedx")


def _langgraph_report(vx, *, framework_version: str | None, activation_source: str):
    report = vx.activation_report(
        LANGGRAPH_ADAPTER_KIND,
        "native",
        list(LANGGRAPH_NATIVE_CAPABILITIES),
        framework_version=_langgraph_framework_version(framework_version),
        activation_source=activation_source,
    )
    vx._zero_touch.report = report
    vx._otel_bridge.apply_report(report)
    vx.capture.set_default_adapter(report.to_adapter_context())
    vx.record_activation_diagnostic(report)
    return report


def _langgraph_config_value(args, kwargs) -> Any:
    if "config" in kwargs:
        return kwargs.get("config")
    for candidate in args:
        if isinstance(candidate, dict) and "configurable" in candidate:
            return candidate
    return None


def _langgraph_recent_prompt_injection(verifiedx) -> bool:
    for entry in verifiedx.capture.recent_objects(limit=64):
        labels = entry.get("taint_labels") or []
        if any(str(label) == "prompt_injection" for label in labels):
            return True
    return False


def _langgraph_checkpoint_write_requires_boundary(verifiedx, payload: Any) -> bool:
    return False


def _langgraph_thread_id(config: Any) -> str | None:
    if not isinstance(config, dict):
        return None
    configurable = config.get("configurable")
    if not isinstance(configurable, dict):
        return None
    thread_id = configurable.get("thread_id")
    if thread_id is None:
        return None
    text = str(thread_id).strip()
    return text or None


def _langgraph_checkpoint_ns(config: Any) -> str | None:
    if not isinstance(config, dict):
        return None
    configurable = config.get("configurable")
    if not isinstance(configurable, dict):
        return None
    checkpoint_ns = configurable.get("checkpoint_ns")
    if checkpoint_ns is None:
        return None
    text = str(checkpoint_ns).strip()
    return text or None


def _langgraph_checkpoint_id(config: Any) -> str | None:
    if not isinstance(config, dict):
        return None
    configurable = config.get("configurable")
    if not isinstance(configurable, dict):
        return None
    checkpoint_id = configurable.get("checkpoint_id")
    if checkpoint_id is None:
        return None
    text = str(checkpoint_id).strip()
    return text or None


def _langgraph_node_name(node: Any, action: Any | None = None) -> str:
    candidate = node if isinstance(node, str) else action or node
    return str(
        getattr(candidate, "name", None)
        or getattr(candidate, "__name__", None)
        or candidate.__class__.__name__
    )


def _langgraph_message_role(value: Any) -> str:
    if isinstance(value, dict):
        role = value.get("role") or value.get("type")
    else:
        role = getattr(value, "role", None) or getattr(value, "type", None)
    normalized = str(role or "").strip().lower()
    return {
        "ai": "assistant",
        "assistant": "assistant",
        "developer": "developer",
        "human": "user",
        "system": "system",
        "tool": "tool",
        "user": "user",
    }.get(normalized, normalized or "unknown")


def _langgraph_message_content(value: Any) -> str:
    if isinstance(value, dict):
        content = value.get("content")
    else:
        content = getattr(value, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
                continue
            if isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str) and text.strip():
                    parts.append(text)
        return "\n".join(part for part in parts if part).strip()
    if isinstance(content, dict):
        for key in ("text", "content", "value", "message"):
            nested = content.get(key)
            if isinstance(nested, str) and nested.strip():
                return nested
    if content is None:
        return ""
    return str(content)


def _langgraph_message_id(value: Any, default_index: int) -> str:
    if isinstance(value, dict):
        message_id = value.get("id")
    else:
        message_id = getattr(value, "id", None)
    if message_id is None:
        return f"msg_{default_index}"
    text = str(message_id).strip()
    return text or f"msg_{default_index}"


def _langgraph_input_messages(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        return [{"role": "user", "content": text, "message_id": "msg_0"}] if text else []
    if isinstance(value, list):
        if value and all(
            isinstance(item, dict) and (item.get("role") or item.get("type")) is not None
            for item in value
        ):
            normalized: list[dict[str, Any]] = []
            for index, message in enumerate(value):
                role = _langgraph_message_role(message)
                content = _langgraph_message_content(message)
                if not content:
                    continue
                normalized.append(
                    {
                        "role": role,
                        "content": content,
                        "message_id": _langgraph_message_id(message, index),
                    }
                )
            if normalized:
                return normalized
        for item in value:
            extracted = _langgraph_input_messages(item)
            if extracted:
                return extracted

    mapping = _normalized_langgraph_mapping(value)
    if mapping is None and isinstance(value, dict):
        mapping = value

    if isinstance(mapping, dict):
        messages = mapping.get("messages")
        if isinstance(messages, list):
            normalized: list[dict[str, Any]] = []
            for index, message in enumerate(messages):
                role = _langgraph_message_role(message)
                content = _langgraph_message_content(message)
                if not content:
                    continue
                normalized.append(
                    {
                        "role": role,
                        "content": content,
                        "message_id": _langgraph_message_id(message, index),
                    }
                )
            if normalized:
                return normalized
        for key in ("input", "prompt", "question", "request", "task"):
            candidate = mapping.get(key)
            if isinstance(candidate, str) and candidate.strip():
                return [{"role": "user", "content": candidate.strip(), "message_id": "msg_0"}]
    return []


def _record_langgraph_invocation_context(
    verifiedx,
    report,
    *,
    method_name: str,
    input_value: Any,
    config_value: Any = None,
) -> None:
    messages = _langgraph_input_messages(input_value)
    request_metadata = (
        {"config": _langgraph_jsonable(config_value)}
        if config_value is not None
        else None
    )
    scope_updater = getattr(verifiedx, "_update_runtime_scope_from_window", None)
    if callable(scope_updater):
        scope_updater(messages or None, request_metadata)
    elif request_metadata is not None:
        scope_activator = getattr(verifiedx, "activate_runtime_scope_from_payload", None)
        if callable(scope_activator):
            scope_activator(request_metadata)
    if not messages:
        return
    recorder = getattr(verifiedx, "record_conversation_window", None)
    payload = [{"role": item["role"], "content": item["content"], "id": item["message_id"]} for item in messages]
    if callable(recorder):
        recorder(
            payload,
            source=f"langgraph.{method_name}",
            request_kind=f"langgraph.{method_name}",
            request_metadata=request_metadata,
            remember_messages_as_context=True,
            capture_source_kind="native_wrapper",
        )
        return
    verifiedx.zero_touch.record_conversation_window(
        payload,
        source=f"langgraph.{method_name}",
        request_kind=f"langgraph.{method_name}",
        request_metadata=request_metadata,
        remember_messages_as_context=True,
        capture_source_kind="native_wrapper",
    )


def _record_graph_state_read(
    verifiedx,
    report,
    *,
    raw_name: str,
    config: Any = None,
    result: Any = None,
) -> None:
    thread_id = _langgraph_thread_id(config)
    checkpoint_ns = _langgraph_checkpoint_ns(config)
    checkpoint_id = _langgraph_checkpoint_id(config)
    query_parts = [part for part in [thread_id, checkpoint_id] if part]
    query = "/".join(query_parts) if query_parts else (checkpoint_ns or None)
    normalized_payload: dict[str, Any] = {"raw_name": raw_name}
    if checkpoint_ns:
        normalized_payload["namespace"] = checkpoint_ns
    if thread_id:
        normalized_payload["key"] = thread_id
    if checkpoint_id:
        normalized_payload["checkpoint_id"] = checkpoint_id
    if query:
        normalized_payload["query"] = query
    normalized_result = _bounded_langgraph_capture_result(result)
    if result is not None:
        normalized_payload["result_present"] = True
    if normalized_result is not None:
        normalized_payload["result"] = normalized_result
    if isinstance(result, (list, tuple, set)):
        normalized_payload["result_count"] = len(result)
    object_payload = verifiedx.capture.build_object(
        "memory_record",
        normalized_payload,
        source_lineage=["langgraph", "graph_state_read"],
    )
    event: dict[str, Any] = {
        "kind": "memory_read",
        "object": object_payload,
        "tool_name": raw_name,
        "namespace": checkpoint_ns or "langgraph.graph",
        "key": thread_id or checkpoint_id or _LANGGRAPH_SYNTHETIC_STATE_KEY,
    }
    if query:
        event["query"] = query
    verifiedx.capture.emit_event(
        event,
        adapter=report.to_adapter_context() if report else None,
    )


def _langgraph_command_update_payload(value: Any) -> Any | None:
    if Command is None or not isinstance(value, Command):
        return None
    update = getattr(value, "update", None)
    if update is None:
        return None
    if isinstance(update, dict) and not update:
        return None
    if isinstance(update, (list, tuple, set)) and not update:
        return None
    return update


def _preflight_langgraph_command_update(
    verifiedx,
    *,
    node_name: str,
    result: Any,
    config: Any,
):
    update = _langgraph_command_update_payload(result)
    if update is None:
        return result
    thread_id = _langgraph_thread_id(config)
    transport_args: dict[str, Any] = _langgraph_jsonable({
        "node_name": node_name,
        "update": update,
    })
    if config is not None:
        transport_args["config"] = _langgraph_jsonable(config)
    goto = getattr(result, "goto", None)
    if goto not in (None, (), []):
        transport_args["goto"] = _langgraph_jsonable(goto)
    resume = getattr(result, "resume", None)
    if resume not in (None, (), []):
        transport_args["resume"] = _langgraph_jsonable(resume)
    descriptor = _langgraph_tool_descriptor(
        "langgraph.Command.update",
        transport_args,
        pending_action={
            "surface": "tool_dispatch",
            "raw_name": "langgraph.Command.update",
            "method": "update",
            "target": str(thread_id or node_name or "langgraph.graph"),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": False,
        },
    )
    return verifiedx.zero_touch.intercept_boundary(
        surface="tool_dispatch",
        operation="langgraph.Command.update",
        target=str(thread_id or node_name or "langgraph.graph"),
        method="update",
        transport_args=transport_args,
        boundary_kind="action_execute",
        action_class="system_change",
        trust_boundary_crossing=False,
        tool_descriptor=descriptor,
        execute=lambda: result,
    )


async def _preflight_langgraph_command_update_async(
    verifiedx,
    *,
    node_name: str,
    result: Any,
    config: Any,
):
    update = _langgraph_command_update_payload(result)
    if update is None:
        return result
    thread_id = _langgraph_thread_id(config)
    transport_args: dict[str, Any] = _langgraph_jsonable({
        "node_name": node_name,
        "update": update,
    })
    if config is not None:
        transport_args["config"] = _langgraph_jsonable(config)
    goto = getattr(result, "goto", None)
    if goto not in (None, (), []):
        transport_args["goto"] = _langgraph_jsonable(goto)
    resume = getattr(result, "resume", None)
    if resume not in (None, (), []):
        transport_args["resume"] = _langgraph_jsonable(resume)
    descriptor = _langgraph_tool_descriptor(
        "langgraph.Command.update",
        transport_args,
        pending_action={
            "surface": "tool_dispatch",
            "raw_name": "langgraph.Command.update",
            "method": "update",
            "target": str(thread_id or node_name or "langgraph.graph"),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": False,
        },
    )

    async def execute():
        return result

    return await verifiedx.zero_touch.intercept_boundary_async(
        surface="tool_dispatch",
        operation="langgraph.Command.update",
        target=str(thread_id or node_name or "langgraph.graph"),
        method="update",
        transport_args=transport_args,
        boundary_kind="action_execute",
        action_class="system_change",
        trust_boundary_crossing=False,
        tool_descriptor=descriptor,
        execute=execute,
    )


def _langgraph_tool_descriptor(
    raw_name: str,
    args: dict[str, Any],
    *,
    pending_action: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metadata: dict[str, Any] = {"raw_name": raw_name}
    if pending_action is not None:
        metadata["pending_action"] = pending_action
    return {
        "tool_name": raw_name,
        "schema": {"type": "object", "additionalProperties": True},
        "docstring": None,
        "args": _langgraph_jsonable(args),
        "metadata": metadata,
    }


def _langgraph_tool_schema(tool: Any) -> dict[str, Any]:
    schema = getattr(tool, "tool_call_schema", None) or getattr(tool, "args_schema", None)
    if schema is not None and hasattr(schema, "model_json_schema"):
        try:
            dumped = schema.model_json_schema()
            if isinstance(dumped, dict):
                return dumped
        except Exception:  # pragma: no cover - schema adapters vary by version
            pass
    args = getattr(tool, "args", None)
    if isinstance(args, dict):
        return {
            "type": "object",
            "properties": _langgraph_jsonable(args),
        }
    return {"type": "object", "additionalProperties": True}


def _langgraph_arg_schema(raw_args: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {str(name): {"type": "string"} for name in raw_args.keys()},
    }


def _langgraph_tool_property_names(schema: dict[str, Any]) -> set[str]:
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return set()
    return {str(name).strip().lower() for name in properties.keys() if str(name).strip()}


def _langgraph_tool_looks_retrieval_only(tool_name: str, tool: Any, schema: dict[str, Any]) -> bool:
    property_names = _langgraph_tool_property_names(schema)
    description = str(getattr(tool, "description", None) or "")
    tokens = set(
        re.split(r"[^a-z0-9]+", f"{tool_name} {description} {' '.join(sorted(property_names))}".lower())
    )
    tokens.discard("")
    retrieval_verbs = bool(
        tokens & {"fetch", "get", "inspect", "list", "load", "lookup", "query", "read", "retrieve", "search", "show", "view"}
    ) or {"look", "up"} <= tokens
    mutation_verbs = bool(
        tokens
        & {
            "append",
            "apply",
            "archive",
            "create",
            "delete",
            "disable",
            "edit",
            "enable",
            "insert",
            "notify",
            "patch",
            "persist",
            "post",
            "reply",
            "save",
            "send",
            "set",
            "store",
            "sync",
            "update",
            "upsert",
            "write",
        }
    )
    if not retrieval_verbs or mutation_verbs:
        return False
    return True


def _langgraph_tool_action_class(tool_name: str, tool: Any, schema: dict[str, Any]) -> str | None:
    if _langgraph_tool_looks_retrieval_only(tool_name, tool, schema):
        return None
    property_names = _langgraph_tool_property_names(schema)
    description = str(getattr(tool, "description", None) or "")
    tokens = f"{tool_name} {description} {' '.join(sorted(property_names))}".lower()
    has_memory = bool(re.search(r"memory|memo|note|preference|remember|state", tokens))
    has_mutation = bool(
        re.search(
            r"append|apply|archive|cancel|change|close|create|credit|delete|disable|edit|enable|exchange|insert|issue|patch|pause|persist|reactivate|refund|remember|reroute|route|save|set|skip|store|sync|tag|update|upsert|verify|write",
            tokens,
        )
    )
    has_record = bool(
        re.search(
            r"account|case|contact|customer|incident|issue|lead|opportunity|order|profile|record|subscription|task|ticket|user",
            tokens,
        )
    ) or any(
        re.search(
            r"(account|case|contact|customer|issue|lead|opportunity|order|profile|record|subscription|task|ticket|user)_id$",
            name,
        )
        or name == "record_id"
        for name in property_names
    )
    has_message = bool(
        re.search(
            r"alert|body|channel|chat|comment|conversation|dm|email|mail|message|notify|notification|post|recipient|reply|send|slack|subject|teams|text|thread",
            tokens,
        )
    )
    has_internal = bool(
        re.search(
            r"assignment|config|configuration|flag|metadata|policy|queue|route|routing|rule|setting|settings|stage|state|status|thread|workflow",
            tokens,
        )
    )
    if {"namespace", "key", "value"}.issubset(property_names) or (has_memory and has_mutation):
        return "memory_write"
    if has_message and (
        has_mutation
        or any(
            name
            in {
                "body",
                "channel",
                "channel_id",
                "comment",
                "content",
                "email",
                "message",
                "recipient",
                "recipient_id",
                "subject",
                "text",
                "thread_id",
                "to",
            }
            for name in property_names
        )
    ):
        return "external_message_send"
    if has_record and (
        has_mutation
        or any(re.search(r"patch|update|fields|status|state|tier|owner", name) for name in property_names)
    ):
        return "record_mutation"
    if has_internal and (
        has_mutation
        or any(
            re.search(r"config|flag|metadata|policy|route|routing|rule|setting|stage|state|status|workflow", name)
            for name in property_names
        )
    ):
        return "system_change"
    return None


def _langgraph_selected_tool_action_class(tool_name: str, raw_args: dict[str, Any]) -> str | None:
    class _SelectedToolShape:
        description = None

    return _langgraph_tool_action_class(
        tool_name,
        _SelectedToolShape(),
        _langgraph_arg_schema(raw_args),
    )


def _langgraph_tool_pending_action(tool_name: str, raw_args: dict[str, Any], action_class: str) -> dict[str, Any]:
    target = (
        raw_args.get("url")
        or raw_args.get("uri")
        or raw_args.get("recipient")
        or raw_args.get("email")
        or raw_args.get("address")
        or raw_args.get("channel")
        or raw_args.get("workflow_id")
        or raw_args.get("customer_id")
        or raw_args.get("account_id")
        or raw_args.get("record_id")
        or raw_args.get("id")
        or raw_args.get("key")
        or tool_name
    )
    if action_class == "memory_write":
        return {
            "surface": "memory_write",
            "raw_name": tool_name,
            "method": "write",
            "target": str(raw_args.get("namespace") or target),
            "raw_args": raw_args,
            "boundary_kind": "memory_write",
            "action_class": "memory_write",
            "trust_boundary_crossing": False,
        }
    if action_class == "record_mutation":
        return {
            "surface": "db",
            "raw_name": tool_name,
            "method": "MUTATE",
            "target": str(target),
            "raw_args": raw_args,
            "boundary_kind": "action_execute",
            "action_class": "record_mutation",
            "trust_boundary_crossing": False,
        }
    if action_class == "external_message_send":
        return {
            "surface": "http",
            "raw_name": tool_name,
            "method": "SEND",
            "target": str(target),
            "raw_args": raw_args,
            "boundary_kind": "action_execute",
            "action_class": "external_message_send",
            "trust_boundary_crossing": bool(
                raw_args.get("recipient")
                or raw_args.get("email")
                or raw_args.get("address")
                or raw_args.get("external")
                or raw_args.get("public")
                or raw_args.get("customer_visible")
            ),
        }
    return {
        "surface": "tool_dispatch",
        "raw_name": tool_name,
        "method": "UPDATE",
        "target": str(target),
        "raw_args": raw_args,
        "boundary_kind": "action_execute",
        "action_class": "system_change",
        "trust_boundary_crossing": False,
    }


def _matching_langgraph_selected_preflight(
    verifiedx,
    *,
    descriptor: dict[str, Any],
    capture: dict[str, Any],
) -> dict[str, Any] | None:
    zero_touch = getattr(verifiedx, "zero_touch", None)
    matcher = getattr(zero_touch, "_matching_tool_preflight", None)
    if zero_touch is None or not callable(matcher):
        return None
    return matcher(
        tool_descriptor=descriptor,
        tool_call_id=None,
        boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
        surface=str(capture["surface"]),
        target=str(capture["target"]),
        transport_args=dict(capture.get("transport_args") or descriptor.get("args") or {}),
        allow_cross_scope=True,
        allow_unconsumed_cross_sequence=True,
    )


def _langgraph_tool_args(input_value: Any) -> dict[str, Any]:
    mapping = _normalized_langgraph_mapping(input_value)
    if mapping is None and isinstance(input_value, dict):
        mapping = input_value
    if isinstance(mapping, dict):
        if isinstance(mapping.get("args"), dict):
            return _langgraph_jsonable(mapping.get("args"))
        if isinstance(mapping.get("arguments"), dict):
            return _langgraph_jsonable(mapping.get("arguments"))
        if isinstance(mapping.get("input"), dict):
            return _langgraph_jsonable(mapping.get("input"))
        if "type" in mapping and mapping.get("type") == "tool_call" and isinstance(mapping.get("args"), dict):
            return _langgraph_jsonable(mapping.get("args"))
        cleaned = {
            str(key): value
            for key, value in mapping.items()
            if key not in {"id", "name", "type", "tool_call_id"}
        }
        if cleaned:
            return _langgraph_jsonable(cleaned)
    if isinstance(input_value, str):
        text = input_value.strip()
        return {"input": text} if text else {}
    return {}


def _preflight_langgraph_tool_execution(
    verifiedx,
    *,
    tool: Any,
    input_value: Any,
    execute,
):
    tool_name = str(getattr(tool, "name", None) or tool.__class__.__name__).strip() or "langgraph_tool"
    raw_args = _langgraph_tool_args(input_value)
    schema = _langgraph_tool_schema(tool)
    retrieval_like = _langgraph_tool_looks_retrieval_only(tool_name, tool, schema)
    action_class = _langgraph_tool_action_class(tool_name, tool, schema)
    metadata: dict[str, Any] = {
        "raw_name": tool_name,
        "raw_args": raw_args,
        "read_only": retrieval_like,
        "retrieval_like": retrieval_like,
    }
    if action_class is not None:
        metadata["pending_action"] = _langgraph_tool_pending_action(tool_name, raw_args, action_class)
        metadata["semantic_class"] = action_class
    elif retrieval_like:
        metadata["semantic_class"] = _langgraph_retrieval_object_type(tool_name, tool)
    source = "langgraph.AIMessage.tool_calls"
    tool_call_id = _langgraph_tool_call_id(input_value)
    runtime_context = _langgraph_tool_runtime_context(
        verifiedx,
        tool_name=tool_name,
        raw_args=raw_args,
        schema=schema,
        docstring=getattr(tool, "description", None),
        metadata=metadata,
        source=source,
        tool_call_id=tool_call_id,
    )
    descriptor = runtime_context.descriptor() if runtime_context is not None else {
        "tool_name": tool_name,
        "schema": schema,
        "docstring": getattr(tool, "description", None),
        "args": raw_args,
        "metadata": metadata,
    }
    _record_langgraph_tool_selection(
        verifiedx,
        tool_name=tool_name,
        raw_args=raw_args,
        schema=schema,
        docstring=getattr(tool, "description", None),
        action_class=action_class,
        retrieval_like=retrieval_like,
        input_value=input_value,
        tool=tool,
    )
    if not verifiedx.zero_touch.requires_direct_tool_boundary(
        tool_descriptor=descriptor,
        source=source,
    ):
        with _langgraph_tool_scope(verifiedx, runtime_context):
            result = execute()
            if retrieval_like:
                _record_langgraph_retrieval_result(
                    verifiedx,
                    tool_name=tool_name,
                    raw_args=raw_args,
                    result=result,
                    tool=tool,
                )
            return result
    capture = verifiedx.zero_touch.describe_selected_tool_boundary(
        tool_descriptor=descriptor,
        source=source,
    )
    if capture is None:
        with _langgraph_tool_scope(verifiedx, runtime_context):
            result = execute()
            if retrieval_like:
                _record_langgraph_retrieval_result(
                    verifiedx,
                    tool_name=tool_name,
                    raw_args=raw_args,
                    result=result,
                    tool=tool,
                )
            return result
    reuse_scope = None
    cached_preflight = _matching_langgraph_selected_preflight(
        verifiedx,
        descriptor=descriptor,
        capture=capture,
    )
    if isinstance(cached_preflight, dict):
        reuse_scope = str(cached_preflight.get("runtime_scope") or "").strip() or None
    if reuse_scope:
        with _langgraph_tool_scope(verifiedx, runtime_context):
            with verifiedx.pinned_runtime_scope(reuse_scope):
                return verifiedx.zero_touch.intercept_boundary(
                    surface=str(capture["surface"]),
                    operation=str(capture["operation"]),
                    target=str(capture["target"]),
                    method=capture.get("method"),
                    transport_args=dict(capture.get("transport_args") or raw_args),
                    boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                    action_class=capture.get("action_class"),
                    trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                    tool_descriptor=descriptor,
                    execute=execute,
                )
    current_scope = verifiedx.current_runtime_scope()
    with _langgraph_tool_scope(verifiedx, runtime_context):
        with verifiedx.pinned_runtime_scope(current_scope):
            return verifiedx.zero_touch.intercept_boundary(
                surface=str(capture["surface"]),
                operation=str(capture["operation"]),
                target=str(capture["target"]),
                method=capture.get("method"),
                transport_args=dict(capture.get("transport_args") or raw_args),
                boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                action_class=capture.get("action_class"),
                trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                tool_descriptor=descriptor,
                execute=execute,
            )


async def _preflight_langgraph_tool_execution_async(
    verifiedx,
    *,
    tool: Any,
    input_value: Any,
    execute,
):
    tool_name = str(getattr(tool, "name", None) or tool.__class__.__name__).strip() or "langgraph_tool"
    raw_args = _langgraph_tool_args(input_value)
    schema = _langgraph_tool_schema(tool)
    retrieval_like = _langgraph_tool_looks_retrieval_only(tool_name, tool, schema)
    action_class = _langgraph_tool_action_class(tool_name, tool, schema)
    metadata: dict[str, Any] = {
        "raw_name": tool_name,
        "raw_args": raw_args,
        "read_only": retrieval_like,
        "retrieval_like": retrieval_like,
    }
    if action_class is not None:
        metadata["pending_action"] = _langgraph_tool_pending_action(tool_name, raw_args, action_class)
        metadata["semantic_class"] = action_class
    elif retrieval_like:
        metadata["semantic_class"] = _langgraph_retrieval_object_type(tool_name, tool)
    source = "langgraph.AIMessage.tool_calls"
    tool_call_id = _langgraph_tool_call_id(input_value)
    runtime_context = _langgraph_tool_runtime_context(
        verifiedx,
        tool_name=tool_name,
        raw_args=raw_args,
        schema=schema,
        docstring=getattr(tool, "description", None),
        metadata=metadata,
        source=source,
        tool_call_id=tool_call_id,
    )
    descriptor = runtime_context.descriptor() if runtime_context is not None else {
        "tool_name": tool_name,
        "schema": schema,
        "docstring": getattr(tool, "description", None),
        "args": raw_args,
        "metadata": metadata,
    }
    _record_langgraph_tool_selection(
        verifiedx,
        tool_name=tool_name,
        raw_args=raw_args,
        schema=schema,
        docstring=getattr(tool, "description", None),
        action_class=action_class,
        retrieval_like=retrieval_like,
        input_value=input_value,
        tool=tool,
    )
    if not verifiedx.zero_touch.requires_direct_tool_boundary(
        tool_descriptor=descriptor,
        source=source,
    ):
        with _langgraph_tool_scope(verifiedx, runtime_context):
            result = await execute()
            if retrieval_like:
                _record_langgraph_retrieval_result(
                    verifiedx,
                    tool_name=tool_name,
                    raw_args=raw_args,
                    result=result,
                    tool=tool,
                )
            return result
    capture = verifiedx.zero_touch.describe_selected_tool_boundary(
        tool_descriptor=descriptor,
        source=source,
    )
    if capture is None:
        with _langgraph_tool_scope(verifiedx, runtime_context):
            result = await execute()
            if retrieval_like:
                _record_langgraph_retrieval_result(
                    verifiedx,
                    tool_name=tool_name,
                    raw_args=raw_args,
                    result=result,
                    tool=tool,
                )
            return result
    reuse_scope = None
    cached_preflight = _matching_langgraph_selected_preflight(
        verifiedx,
        descriptor=descriptor,
        capture=capture,
    )
    if isinstance(cached_preflight, dict):
        reuse_scope = str(cached_preflight.get("runtime_scope") or "").strip() or None
    if reuse_scope:
        with _langgraph_tool_scope(verifiedx, runtime_context):
            with verifiedx.pinned_runtime_scope(reuse_scope):
                return await verifiedx.zero_touch.intercept_boundary_async(
                    surface=str(capture["surface"]),
                    operation=str(capture["operation"]),
                    target=str(capture["target"]),
                    method=capture.get("method"),
                    transport_args=dict(capture.get("transport_args") or raw_args),
                    boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                    action_class=capture.get("action_class"),
                    trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                    tool_descriptor=descriptor,
                    execute=execute,
                )
    current_scope = verifiedx.current_runtime_scope()
    with _langgraph_tool_scope(verifiedx, runtime_context):
        with verifiedx.pinned_runtime_scope(current_scope):
            return await verifiedx.zero_touch.intercept_boundary_async(
                surface=str(capture["surface"]),
                operation=str(capture["operation"]),
                target=str(capture["target"]),
                method=capture.get("method"),
                transport_args=dict(capture.get("transport_args") or raw_args),
                boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                action_class=capture.get("action_class"),
                trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                tool_descriptor=descriptor,
                execute=execute,
            )


def _record_checkpoint_event(
    checkpointer,
    *,
    raw_name: str,
    thread_id: str | None,
    payload: dict[str, Any],
) -> None:
    object_payload = checkpointer._verifiedx.capture.build_object(
        "checkpoint",
        {"raw_name": raw_name, **_langgraph_jsonable(payload)},
        source_lineage=["langgraph", raw_name],
    )
    checkpointer._verifiedx.capture.checkpoint(
        object_payload,
        adapter=checkpointer._report.to_adapter_context() if checkpointer._report else None,
        causality={"framework_run_id": thread_id, "framework_checkpoint_id": object_payload["object_id"]},
    )


def _langgraph_jsonable(value: Any):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _langgraph_jsonable(nested) for key, nested in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_langgraph_jsonable(item) for item in value]
    mapping = _normalized_langgraph_mapping(value)
    if mapping is not None:
        return _langgraph_jsonable(mapping)
    return str(value)


def _langgraph_json_bytes(value: Any) -> int:
    try:
        return len(json.dumps(value, default=str, separators=(",", ":")).encode("utf-8"))
    except Exception:
        return 0


def _compact_langgraph_value(
    value: Any,
    *,
    string_limit: int,
    list_limit: int,
    dict_limit: int,
    depth: int = 0,
    max_depth: int = 5,
):
    if value is None or isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, str):
        text = value.strip()
        if len(text) <= string_limit:
            return text
        return f"{text[:string_limit]}...[truncated]"
    if depth >= max_depth:
        if isinstance(value, dict):
            return {"_type": "object", "_keys": [str(key) for key in list(value.keys())[:dict_limit]]}
        if isinstance(value, (list, tuple, set)):
            return {"_type": "list", "_count": len(value)}
        return _compact_langgraph_value(str(value), string_limit=string_limit, list_limit=list_limit, dict_limit=dict_limit, depth=depth + 1)
    if isinstance(value, dict):
        compact: dict[str, Any] = {}
        omitted = 0
        for index, (key, nested) in enumerate(value.items()):
            if index >= dict_limit:
                omitted += 1
                continue
            compact[str(key)] = _compact_langgraph_value(
                nested,
                string_limit=string_limit,
                list_limit=list_limit,
                dict_limit=dict_limit,
                depth=depth + 1,
                max_depth=max_depth,
            )
        if omitted:
            compact["_truncated_keys"] = omitted
        return compact
    if isinstance(value, (list, tuple, set)):
        items = list(value)
        compact_items = [
            _compact_langgraph_value(
                item,
                string_limit=string_limit,
                list_limit=list_limit,
                dict_limit=dict_limit,
                depth=depth + 1,
                max_depth=max_depth,
            )
            for item in items[:list_limit]
        ]
        if len(items) > list_limit:
            compact_items.append({"_truncated_items": len(items) - list_limit})
        return compact_items
    mapping = _normalized_langgraph_mapping(value)
    if mapping is not None:
        return _compact_langgraph_value(
            mapping,
            string_limit=string_limit,
            list_limit=list_limit,
            dict_limit=dict_limit,
            depth=depth,
            max_depth=max_depth,
        )
    return _compact_langgraph_value(str(value), string_limit=string_limit, list_limit=list_limit, dict_limit=dict_limit, depth=depth + 1)


def _bounded_langgraph_capture_result(value: Any, *, max_bytes: int = 4096):
    normalized = _langgraph_jsonable(value)
    if normalized is None:
        return None
    if _langgraph_json_bytes(normalized) <= max_bytes:
        return normalized
    for string_limit, list_limit, dict_limit in ((320, 8, 32), (180, 6, 24), (96, 4, 16)):
        compact = _compact_langgraph_value(
            normalized,
            string_limit=string_limit,
            list_limit=list_limit,
            dict_limit=dict_limit,
        )
        if _langgraph_json_bytes(compact) <= max_bytes:
            return compact
    return None


def _langgraph_tool_call_id(input_value: Any) -> str | None:
    mapping = _normalized_langgraph_mapping(input_value)
    if mapping is None and isinstance(input_value, dict):
        mapping = input_value
    if not isinstance(mapping, dict):
        return None
    tool_call_id = mapping.get("id") or mapping.get("tool_call_id") or mapping.get("call_id")
    if tool_call_id is None:
        return None
    normalized = str(tool_call_id).strip()
    return normalized or None


def _langgraph_tool_runtime_context(
    verifiedx,
    *,
    tool_name: str,
    raw_args: dict[str, Any],
    schema: dict[str, Any],
    docstring: Any,
    metadata: dict[str, Any],
    source: str,
    tool_call_id: str | None = None,
):
    def _verifiedx_langgraph_tool_marker():
        return None

    try:
        runtime_context = verifiedx.derive_tool_runtime_context(
            _verifiedx_langgraph_tool_marker,
            tool_name=tool_name,
            args=(),
            kwargs={},
            schema=schema,
            docstring=str(docstring) if docstring is not None else None,
            metadata=metadata,
            source=source,
        )
        runtime_context.tool_args = raw_args
        runtime_context.metadata = metadata
        runtime_context.tool_call_id = tool_call_id
        return runtime_context
    except Exception:
        return None


def _langgraph_tool_scope(verifiedx, runtime_context):
    if runtime_context is None:
        return nullcontext()
    return verifiedx.tool_runtime_scope(runtime_context)


def _langgraph_scalar_fragments(value: Any, *, limit: int = 8) -> list[str]:
    fragments: list[str] = []

    def visit(current: Any) -> None:
        if len(fragments) >= limit:
            return
        if current is None:
            return
        if isinstance(current, (str, int, float, bool)):
            text = str(current).strip()
            if text:
                fragments.append(text[:160])
            return
        if isinstance(current, dict):
            for nested in current.values():
                visit(nested)
                if len(fragments) >= limit:
                    break
            return
        if isinstance(current, (list, tuple, set)):
            for nested in current:
                visit(nested)
                if len(fragments) >= limit:
                    break

    visit(value)
    return fragments


def _langgraph_retrieval_query(tool_name: str, raw_args: dict[str, Any]) -> str:
    fragments = _langgraph_scalar_fragments(raw_args, limit=1)
    if fragments:
        return f"{tool_name}:{fragments[0]}"
    return tool_name


def _langgraph_result_source_uri(result: Any) -> str | None:
    normalized = _langgraph_jsonable(result)
    if isinstance(normalized, dict):
        for key in ("source_uri", "source_url", "url", "uri", "href"):
            value = normalized.get(key)
            if value is not None and str(value).strip():
                return str(value).strip()
    return None


def _langgraph_retrieval_object_type(tool_name: str, tool: Any, result: Any = None) -> str:
    description = str(getattr(tool, "description", None) or "")
    source_uri = _langgraph_result_source_uri(result) or ""
    tokens = set(re.split(r"[^a-z0-9]+", f"{tool_name} {description} {source_uri}".lower()))
    tokens.discard("")
    if tokens & {"browser", "external", "http", "https", "internet", "public", "url", "web"}:
        return "external_retrieval"
    return "internal_retrieval"


def _record_langgraph_tool_selection(
    verifiedx,
    *,
    tool_name: str,
    raw_args: dict[str, Any],
    schema: dict[str, Any],
    docstring: Any,
    action_class: str | None,
    retrieval_like: bool,
    input_value: Any,
    tool: Any = None,
) -> None:
    metadata: dict[str, Any] = {
        "raw_name": tool_name,
        "raw_args": raw_args,
        "read_only": retrieval_like,
        "retrieval_like": retrieval_like,
    }
    if action_class is not None:
        metadata["pending_action"] = _langgraph_tool_pending_action(tool_name, raw_args, action_class)
        metadata["semantic_class"] = action_class
    elif retrieval_like:
        metadata["semantic_class"] = _langgraph_retrieval_object_type(tool_name, tool)
    try:
        verifiedx.zero_touch.ensure_tool_selection_recorded(
            tool_descriptor={
                "tool_name": tool_name,
                "schema": schema,
                "docstring": docstring,
                "args": raw_args,
                "metadata": metadata,
            },
            tool_call_id=_langgraph_tool_call_id(input_value),
            source="langgraph.AIMessage.tool_calls",
        )
    except Exception:
        return


def _record_langgraph_retrieval_result(
    verifiedx,
    *,
    tool_name: str,
    raw_args: dict[str, Any],
    result: Any,
    tool: Any = None,
) -> None:
    object_type = _langgraph_retrieval_object_type(tool_name, tool, result)
    normalized_args = _bounded_langgraph_capture_result(raw_args, max_bytes=1024)
    normalized_result = _bounded_langgraph_capture_result(result)
    payload: dict[str, Any] = {
        "raw_name": tool_name,
        "tool_name": tool_name,
        "raw_args": normalized_args if normalized_args is not None else {},
        "result_present": result is not None,
    }
    if normalized_result is not None:
        payload["result"] = normalized_result
    if isinstance(result, (list, tuple, set)):
        payload["result_count"] = len(result)
    object_payload = verifiedx.capture.build_object(
        object_type,
        payload,
        source_lineage=["langgraph", "tool_result", tool_name],
    )
    query = _langgraph_retrieval_query(tool_name, raw_args)
    try:
        diagnostic = verifiedx.observe_runtime_ingress(
            object_payload,
            source_uri=_langgraph_result_source_uri(result),
            source_hint=query,
        )
        if diagnostic is not None:
            request_payload, response = diagnostic
            verifiedx.record_ingress_diagnostic(
                "context_ingress_label",
                request_payload,
                response,
            )
    except Exception:
        if getattr(getattr(verifiedx, "config", None), "strict_direct_ingress_labeling", False):
            raise
    verifiedx.capture.retrieve(
        object_payload,
        query=query,
        adapter=verifiedx._zero_touch.report.to_adapter_context()
        if getattr(getattr(verifiedx, "_zero_touch", None), "report", None)
        else None,
    )
    verifiedx.note_observation(object_type=object_type, source_hint=query)


def _record_store_memory_read(
    store,
    *,
    raw_name: str,
    namespace: Any = None,
    key: Any = None,
    query: Any = None,
    result: Any = None,
) -> None:
    normalized_query = None
    if query is not None:
        normalized_query = str(query)
    elif namespace is not None and key is not None:
        normalized_query = f"{namespace}/{key}"
    elif namespace is not None:
        normalized_query = str(namespace)
    normalized_payload: dict[str, Any] = {"raw_name": raw_name}
    if namespace is not None:
        normalized_payload["namespace"] = str(namespace)
    if key is not None:
        normalized_payload["key"] = str(key)
    if normalized_query:
        normalized_payload["query"] = normalized_query
    normalized_result = _bounded_langgraph_capture_result(result)
    if result is not None:
        normalized_payload["result_present"] = True
    if normalized_result is not None:
        normalized_payload["result"] = normalized_result
    if isinstance(result, (list, tuple, set)):
        normalized_payload["result_count"] = len(result)
    object_payload = store._verifiedx.capture.build_object(
        "memory_record",
        normalized_payload,
        source_lineage=["langgraph", "memory_read"],
    )
    event = {
        "kind": "memory_read",
        "object": object_payload,
        "tool_name": raw_name,
        "namespace": str(namespace) if namespace is not None else "langgraph.store",
        "key": str(key) if key is not None else (normalized_query or _LANGGRAPH_SYNTHETIC_SEARCH_KEY),
    }
    if normalized_query:
        event["query"] = normalized_query
    store._verifiedx.capture.emit_event(
        event,
        adapter=store._report.to_adapter_context() if store._report else None,
    )


def _normalized_langgraph_mapping(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        return value
    if hasattr(value, "model_dump"):
        try:
            dumped = value.model_dump(mode="json")
        except TypeError:
            dumped = value.model_dump()
        return dumped if isinstance(dumped, dict) else None
    if hasattr(value, "dict") and callable(value.dict):
        dumped = value.dict()
        return dumped if isinstance(dumped, dict) else None
    return None


def _langgraph_tool_message_content_payload(content: Any) -> Any:
    if content is None:
        return None
    if isinstance(content, str):
        text = content.strip()
        if not text:
            return None
        try:
            return _bounded_langgraph_capture_result(json.loads(text))
        except Exception:
            return _bounded_langgraph_capture_result({"content": text})
    return _bounded_langgraph_capture_result(content)


def _record_langgraph_tool_message(
    verifiedx,
    report,
    *,
    tool_call_id: Any,
    raw_name: Any = None,
    content: Any = None,
) -> None:
    normalized_payload = {
        "source": "langgraph.ToolMessage.tool_call_id",
        "tool_call_id": str(tool_call_id),
        **({"raw_name": str(raw_name)} if raw_name is not None else {}),
    }
    content_payload = _langgraph_tool_message_content_payload(content)
    if content_payload is not None:
        normalized_payload["tool_response"] = content_payload
    object_payload = verifiedx.capture.build_object(
        "tool_result",
        normalized_payload,
        source_lineage=["langgraph", "ToolMessage.tool_call_id"],
    )
    verifiedx.capture.tool_call(
        object_payload,
        tool_name=str(raw_name or "ToolMessage"),
        adapter=report.to_adapter_context() if report else None,
    )


def _record_langgraph_review_signal(verifiedx, report, *, raw_name: str, payload: Any) -> None:
    verifiedx.capture.summary(
        verifiedx.capture.build_object(
            "summary",
            {"source": raw_name, "payload": payload},
            source_lineage=["langgraph", raw_name],
        ),
        adapter=report.to_adapter_context() if report else None,
    )


def _record_langgraph_tool_calls(verifiedx, tool_calls: Any) -> None:
    if not isinstance(tool_calls, list):
        return
    for tool_call in tool_calls:
        mapping = _normalized_langgraph_mapping(tool_call) or {}
        raw_name = str(
            mapping.get("name")
            or mapping.get("tool_name")
            or mapping.get("tool")
            or ""
        ).strip()
        if not raw_name:
            continue
        raw_args = mapping.get("args")
        if not isinstance(raw_args, dict):
            raw_args = mapping.get("arguments")
        if not isinstance(raw_args, dict):
            raw_args = mapping.get("input")
        if not isinstance(raw_args, dict):
            raw_args = {}
        tool_call_id = mapping.get("id") or mapping.get("tool_call_id") or mapping.get("call_id")
        if tool_call_id is not None and not verifiedx.zero_touch.mark_selected_tool_call_observed(
            str(tool_call_id)
        ):
            continue
        native_call_type = str(mapping.get("type") or "tool_call").strip() or "tool_call"
        provider_hint = _langgraph_tool_call_provider_hint(mapping, tool_call_id=tool_call_id)
        action_class = _langgraph_selected_tool_action_class(raw_name, raw_args)
        selection_metadata = {
            "raw_name": raw_name,
            "raw_args": raw_args,
            "native_call_type": native_call_type,
        }
        if provider_hint:
            selection_metadata["provider_hint"] = provider_hint
        if action_class is not None:
            selection_metadata["pending_action"] = _langgraph_tool_pending_action(
                raw_name,
                raw_args,
                action_class,
            )
            selection_metadata["semantic_class"] = action_class
        elif _langgraph_tool_looks_retrieval_only(
            raw_name,
            type("_SelectedRetrievalShape", (), {"description": None})(),
            _langgraph_arg_schema(raw_args),
        ):
            selection_metadata["read_only"] = True
            selection_metadata["retrieval_like"] = True
            selection_metadata["semantic_class"] = _langgraph_retrieval_object_type(raw_name, None)
        verifiedx.zero_touch.ensure_tool_selection_recorded(
            tool_descriptor={
                "tool_name": raw_name,
                "schema": _langgraph_arg_schema(raw_args),
                "docstring": None,
                "args": raw_args,
                "metadata": selection_metadata,
            },
            tool_call_id=str(tool_call_id) if tool_call_id is not None else None,
            source="langgraph.AIMessage.tool_calls",
        )


def _langgraph_tool_call_provider_hint(mapping: dict[str, Any], *, tool_call_id: Any = None) -> str | None:
    tool_call_id_text = str(tool_call_id or mapping.get("id") or mapping.get("tool_call_id") or "").strip()
    if tool_call_id_text.startswith("toolu_"):
        return "anthropic"
    if tool_call_id_text.startswith("call_"):
        return "openai"
    return None


def _observe_langgraph_capture_points(verifiedx, report, value: Any, *, seen: set[int] | None = None) -> None:
    if value is None or isinstance(value, (str, bytes, int, float, bool)):
        return
    if seen is None:
        seen = set()
    identity = id(value)
    if identity in seen:
        return
    seen.add(identity)
    if isinstance(value, (list, tuple, set)):
        for item in value:
            _observe_langgraph_capture_points(verifiedx, report, item, seen=seen)
        return
    mapping = _normalized_langgraph_mapping(value)
    if mapping is not None:
        if isinstance(mapping.get("tool_calls"), list):
            _record_langgraph_tool_calls(verifiedx, mapping.get("tool_calls"))
        if mapping.get("tool_call_id") is not None:
            _record_langgraph_tool_message(
                verifiedx,
                report,
                tool_call_id=mapping.get("tool_call_id"),
                raw_name=mapping.get("name"),
                content=mapping.get("content"),
            )
        for signal_name in (
            "action_requests",
            "allowed_decisions",
            "interrupt",
            "interrupt_on",
            "interrupts",
            "review_configs",
        ):
            if mapping.get(signal_name) is not None:
                _record_langgraph_review_signal(
                    verifiedx,
                    report,
                    raw_name=f"langgraph.{signal_name}",
                    payload=mapping.get(signal_name),
                )
        for nested in mapping.values():
            _observe_langgraph_capture_points(verifiedx, report, nested, seen=seen)
        return
    for attribute in (
        "action_requests",
        "allowed_decisions",
        "interrupt",
        "interrupt_on",
        "interrupts",
        "messages",
        "review_configs",
        "tool_call_id",
        "tool_calls",
        "update",
    ):
        if hasattr(value, attribute):
            nested = getattr(value, attribute)
            if attribute == "tool_calls":
                _record_langgraph_tool_calls(verifiedx, nested)
            elif attribute == "tool_call_id" and nested is not None:
                _record_langgraph_tool_message(
                    verifiedx,
                    report,
                    tool_call_id=nested,
                    raw_name=getattr(value, "name", None),
                )
            elif attribute in {
                "action_requests",
                "allowed_decisions",
                "interrupt",
                "interrupt_on",
                "interrupts",
                "review_configs",
            } and nested is not None:
                _record_langgraph_review_signal(
                    verifiedx,
                    report,
                    raw_name=f"langgraph.{attribute}",
                    payload=nested,
                )
            _observe_langgraph_capture_points(verifiedx, report, nested, seen=seen)


class VerifiedXCheckpointer(BaseCheckpointSaver):
    def __init__(self, verifiedx, delegate=None, report=None):
        super().__init__(serde=getattr(delegate, "serde", None))
        self._verifiedx = verifiedx
        self._delegate = delegate
        self._report = report

    def __getattr__(self, name):
        if self._delegate is None:
            raise AttributeError(name)
        return getattr(self._delegate, name)

    def get_tuple(self, config):
        if self._delegate is not None and hasattr(self._delegate, "get_tuple"):
            return self._delegate.get_tuple(config)
        return None

    def list(self, config, *, filter=None, before=None, limit=None):
        if self._delegate is not None and hasattr(self._delegate, "list"):
            return self._delegate.list(config, filter=filter, before=before, limit=limit)
        return iter(())

    def put(self, config, checkpoint, metadata=None, new_versions=None):
        thread_id = None
        if isinstance(config, dict):
            thread_id = config.get("configurable", {}).get("thread_id")
        transport_args = _langgraph_jsonable({
            "thread_id": thread_id,
            "checkpoint": checkpoint,
            "metadata": metadata,
            "new_versions": new_versions,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.checkpointer.put",
            transport_args,
            pending_action={
                "surface": "tool_dispatch",
                "raw_name": "langgraph.checkpointer.put",
                "method": "put",
                "target": str(thread_id or "langgraph.checkpoint"),
                "boundary_kind": "action_execute",
                "action_class": "system_change",
                "trust_boundary_crossing": False,
            },
        )
        execute = (
            lambda: self._delegate.put(config, checkpoint, metadata, new_versions)
            if self._delegate is not None and hasattr(self._delegate, "put")
            else config
        )
        if _langgraph_checkpoint_write_requires_boundary(self._verifiedx, transport_args):
            result = self._verifiedx.zero_touch.intercept_boundary(
                surface="tool_dispatch",
                operation="langgraph.checkpointer.put",
                target=str(thread_id or "langgraph.checkpoint"),
                method="put",
                transport_args=transport_args,
                boundary_kind="action_execute",
                action_class="system_change",
                trust_boundary_crossing=False,
                tool_descriptor=descriptor,
                execute=execute,
            )
        else:
            result = execute()
        _record_checkpoint_event(
            self,
            raw_name="langgraph.checkpointer.put",
            thread_id=thread_id,
            payload={
                "checkpoint": checkpoint,
                "metadata": metadata,
                "new_versions": new_versions,
            },
        )
        return result

    def put_writes(self, config, writes, task_id, task_path=""):
        thread_id = None
        if isinstance(config, dict):
            thread_id = config.get("configurable", {}).get("thread_id")
        transport_args = _langgraph_jsonable({
            "thread_id": thread_id,
            "writes": writes,
            "task_id": task_id,
            "task_path": task_path,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.checkpointer.put_writes",
            transport_args,
            pending_action={
                "surface": "tool_dispatch",
                "raw_name": "langgraph.checkpointer.put_writes",
                "method": "put_writes",
                "target": str(thread_id or task_id or "langgraph.checkpoint_writes"),
                "boundary_kind": "action_execute",
                "action_class": "system_change",
                "trust_boundary_crossing": False,
            },
        )
        execute = (
            lambda: self._delegate.put_writes(
                config,
                writes,
                task_id,
                task_path=task_path,
            )
            if self._delegate is not None and hasattr(self._delegate, "put_writes")
            else None
        )
        if _langgraph_checkpoint_write_requires_boundary(self._verifiedx, transport_args):
            result = self._verifiedx.zero_touch.intercept_boundary(
                surface="tool_dispatch",
                operation="langgraph.checkpointer.put_writes",
                target=str(thread_id or task_id or "langgraph.checkpoint_writes"),
                method="put_writes",
                transport_args=transport_args,
                boundary_kind="action_execute",
                action_class="system_change",
                trust_boundary_crossing=False,
                tool_descriptor=descriptor,
                execute=execute,
            )
        else:
            result = execute()
        _record_checkpoint_event(
            self,
            raw_name="langgraph.checkpointer.put_writes",
            thread_id=thread_id,
            payload={
                "writes": writes,
                "task_id": task_id,
                "task_path": task_path,
            },
        )
        return result

    def delete_thread(self, thread_id: str):
        if self._delegate is not None and hasattr(self._delegate, "delete_thread"):
            return self._delegate.delete_thread(thread_id)
        return None

    def delete_for_runs(self, run_ids):
        if self._delegate is not None and hasattr(self._delegate, "delete_for_runs"):
            return self._delegate.delete_for_runs(run_ids)
        return None

    def copy_thread(self, source_thread_id: str, target_thread_id: str):
        if self._delegate is not None and hasattr(self._delegate, "copy_thread"):
            return self._delegate.copy_thread(source_thread_id, target_thread_id)
        return None

    def prune(self, thread_ids, *, strategy="keep_latest"):
        if self._delegate is not None and hasattr(self._delegate, "prune"):
            return self._delegate.prune(thread_ids, strategy=strategy)
        return None

    async def aget_tuple(self, config):
        if self._delegate is not None and hasattr(self._delegate, "aget_tuple"):
            return await self._delegate.aget_tuple(config)
        return None

    async def alist(self, config, *, filter=None, before=None, limit=None):
        if self._delegate is not None and hasattr(self._delegate, "alist"):
            async for item in self._delegate.alist(
                config,
                filter=filter,
                before=before,
                limit=limit,
            ):
                yield item
            return
        if False:  # pragma: no cover
            yield None

    async def aput(self, config, checkpoint, metadata=None, new_versions=None):
        thread_id = None
        if isinstance(config, dict):
            thread_id = config.get("configurable", {}).get("thread_id")
        transport_args = _langgraph_jsonable({
            "thread_id": thread_id,
            "checkpoint": checkpoint,
            "metadata": metadata,
            "new_versions": new_versions,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.checkpointer.put",
            transport_args,
            pending_action={
                "surface": "tool_dispatch",
                "raw_name": "langgraph.checkpointer.put",
                "method": "put",
                "target": str(thread_id or "langgraph.checkpoint"),
                "boundary_kind": "action_execute",
                "action_class": "system_change",
                "trust_boundary_crossing": False,
            },
        )
        async def execute():
            if self._delegate is not None and hasattr(self._delegate, "aput"):
                return await self._delegate.aput(config, checkpoint, metadata, new_versions)
            return config

        if _langgraph_checkpoint_write_requires_boundary(self._verifiedx, transport_args):
            result = await self._verifiedx.zero_touch.intercept_boundary_async(
                surface="tool_dispatch",
                operation="langgraph.checkpointer.put",
                target=str(thread_id or "langgraph.checkpoint"),
                method="put",
                transport_args=transport_args,
                boundary_kind="action_execute",
                action_class="system_change",
                trust_boundary_crossing=False,
                tool_descriptor=descriptor,
                execute=execute,
            )
        else:
            result = await execute()
        _record_checkpoint_event(
            self,
            raw_name="langgraph.checkpointer.put",
            thread_id=thread_id,
            payload={
                "checkpoint": checkpoint,
                "metadata": metadata,
                "new_versions": new_versions,
            },
        )
        return result

    async def aput_writes(self, config, writes, task_id, task_path=""):
        thread_id = None
        if isinstance(config, dict):
            thread_id = config.get("configurable", {}).get("thread_id")
        transport_args = _langgraph_jsonable({
            "thread_id": thread_id,
            "writes": writes,
            "task_id": task_id,
            "task_path": task_path,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.checkpointer.put_writes",
            transport_args,
            pending_action={
                "surface": "tool_dispatch",
                "raw_name": "langgraph.checkpointer.put_writes",
                "method": "put_writes",
                "target": str(thread_id or task_id or "langgraph.checkpoint_writes"),
                "boundary_kind": "action_execute",
                "action_class": "system_change",
                "trust_boundary_crossing": False,
            },
        )
        async def execute():
            if self._delegate is not None and hasattr(self._delegate, "aput_writes"):
                return await self._delegate.aput_writes(
                    config,
                    writes,
                    task_id,
                    task_path=task_path,
                )
            return None

        if _langgraph_checkpoint_write_requires_boundary(self._verifiedx, transport_args):
            result = await self._verifiedx.zero_touch.intercept_boundary_async(
                surface="tool_dispatch",
                operation="langgraph.checkpointer.put_writes",
                target=str(thread_id or task_id or "langgraph.checkpoint_writes"),
                method="put_writes",
                transport_args=transport_args,
                boundary_kind="action_execute",
                action_class="system_change",
                trust_boundary_crossing=False,
                tool_descriptor=descriptor,
                execute=execute,
            )
        else:
            result = await execute()
        _record_checkpoint_event(
            self,
            raw_name="langgraph.checkpointer.put_writes",
            thread_id=thread_id,
            payload={
                "writes": writes,
                "task_id": task_id,
                "task_path": task_path,
            },
        )
        return result

    async def adelete_thread(self, thread_id: str):
        if self._delegate is not None and hasattr(self._delegate, "adelete_thread"):
            return await self._delegate.adelete_thread(thread_id)
        return None

    async def adelete_for_runs(self, run_ids):
        if self._delegate is not None and hasattr(self._delegate, "adelete_for_runs"):
            return await self._delegate.adelete_for_runs(run_ids)
        return None

    async def acopy_thread(self, source_thread_id: str, target_thread_id: str):
        if self._delegate is not None and hasattr(self._delegate, "acopy_thread"):
            return await self._delegate.acopy_thread(source_thread_id, target_thread_id)
        return None

    async def aprune(self, thread_ids, *, strategy="keep_latest"):
        if self._delegate is not None and hasattr(self._delegate, "aprune"):
            return await self._delegate.aprune(thread_ids, strategy=strategy)
        return None


class VerifiedXStore:
    def __init__(self, verifiedx, delegate=None, report=None):
        self._verifiedx = verifiedx
        self._delegate = delegate
        self._report = report

    def __getattr__(self, name):
        if self._delegate is None:
            raise AttributeError(name)
        return getattr(self._delegate, name)

    def get(self, *args, **kwargs):
        result = (
            self._delegate.get(*args, **kwargs)
            if self._delegate is not None and hasattr(self._delegate, "get")
            else None
        )
        namespace = kwargs.get("namespace") if "namespace" in kwargs else (args[0] if len(args) >= 1 else None)
        key = kwargs.get("key") if "key" in kwargs else (args[1] if len(args) >= 2 else None)
        _record_store_memory_read(
            self,
            raw_name="langgraph.store.get",
            namespace=namespace,
            key=key,
            result=result,
        )
        return result

    def search(self, *args, **kwargs):
        result = (
            self._delegate.search(*args, **kwargs)
            if self._delegate is not None and hasattr(self._delegate, "search")
            else []
        )
        namespace = kwargs.get("namespace") if "namespace" in kwargs else (args[0] if len(args) >= 1 else None)
        query = kwargs.get("query")
        if query is None and len(args) >= 2:
            query = args[1]
        _record_store_memory_read(
            self,
            raw_name="langgraph.store.search",
            namespace=namespace,
            query=query,
            result=result,
        )
        return result

    def put(self, namespace, key, value, *args, **kwargs):
        transport_args = _langgraph_jsonable({
            "namespace": namespace,
            "key": key,
            "value": value,
            "args": args,
            "kwargs": kwargs,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.store.put",
            transport_args,
            pending_action={
                "surface": "memory_write",
                "raw_name": "langgraph.store.put",
                "method": "put",
                "target": f"{namespace}/{key}",
                "boundary_kind": "memory_write",
                "action_class": "memory_write",
                "trust_boundary_crossing": False,
            },
        )
        return self._verifiedx.zero_touch.intercept_boundary(
            surface="memory_write",
            operation="langgraph.store.put",
            target=f"{namespace}/{key}",
            method="put",
            transport_args=transport_args,
            boundary_kind="memory_write",
            action_class="memory_write",
            trust_boundary_crossing=False,
            tool_descriptor=descriptor,
            execute=(
                lambda: self._delegate.put(namespace, key, value, *args, **kwargs)
                if self._delegate is not None and hasattr(self._delegate, "put")
                else None
            ),
        )

    def delete(self, namespace, key, *args, **kwargs):
        transport_args = _langgraph_jsonable({
            "namespace": namespace,
            "key": key,
            "args": args,
            "kwargs": kwargs,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.store.delete",
            transport_args,
            pending_action={
                "surface": "memory_write",
                "raw_name": "langgraph.store.delete",
                "method": "delete",
                "target": f"{namespace}/{key}",
                "boundary_kind": "memory_write",
                "action_class": "memory_write",
                "trust_boundary_crossing": False,
            },
        )
        return self._verifiedx.zero_touch.intercept_boundary(
            surface="memory_write",
            operation="langgraph.store.delete",
            target=f"{namespace}/{key}",
            method="delete",
            transport_args=transport_args,
            boundary_kind="memory_write",
            action_class="memory_write",
            trust_boundary_crossing=False,
            tool_descriptor=descriptor,
            execute=(
                lambda: self._delegate.delete(namespace, key, *args, **kwargs)
                if self._delegate is not None and hasattr(self._delegate, "delete")
                else None
            ),
        )

    async def aput(self, namespace, key, value, *args, **kwargs):
        transport_args = _langgraph_jsonable({
            "namespace": namespace,
            "key": key,
            "value": value,
            "args": args,
            "kwargs": kwargs,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.store.put",
            transport_args,
            pending_action={
                "surface": "memory_write",
                "raw_name": "langgraph.store.put",
                "method": "put",
                "target": f"{namespace}/{key}",
                "boundary_kind": "memory_write",
                "action_class": "memory_write",
                "trust_boundary_crossing": False,
            },
        )

        async def execute():
            if self._delegate is not None and hasattr(self._delegate, "aput"):
                return await self._delegate.aput(namespace, key, value, *args, **kwargs)
            return None

        return await self._verifiedx.zero_touch.intercept_boundary_async(
            surface="memory_write",
            operation="langgraph.store.put",
            target=f"{namespace}/{key}",
            method="put",
            transport_args=transport_args,
            boundary_kind="memory_write",
            action_class="memory_write",
            trust_boundary_crossing=False,
            tool_descriptor=descriptor,
            execute=execute,
        )

    async def aget(self, *args, **kwargs):
        if self._delegate is not None and hasattr(self._delegate, "aget"):
            result = await self._delegate.aget(*args, **kwargs)
        else:
            result = None
        namespace = kwargs.get("namespace") if "namespace" in kwargs else (args[0] if len(args) >= 1 else None)
        key = kwargs.get("key") if "key" in kwargs else (args[1] if len(args) >= 2 else None)
        _record_store_memory_read(
            self,
            raw_name="langgraph.store.get",
            namespace=namespace,
            key=key,
            result=result,
        )
        return result

    async def adelete(self, namespace, key, *args, **kwargs):
        transport_args = _langgraph_jsonable({
            "namespace": namespace,
            "key": key,
            "args": args,
            "kwargs": kwargs,
        })
        descriptor = _langgraph_tool_descriptor(
            "langgraph.store.delete",
            transport_args,
            pending_action={
                "surface": "memory_write",
                "raw_name": "langgraph.store.delete",
                "method": "delete",
                "target": f"{namespace}/{key}",
                "boundary_kind": "memory_write",
                "action_class": "memory_write",
                "trust_boundary_crossing": False,
            },
        )

        async def execute():
            if self._delegate is not None and hasattr(self._delegate, "adelete"):
                return await self._delegate.adelete(namespace, key, *args, **kwargs)
            return None

        return await self._verifiedx.zero_touch.intercept_boundary_async(
            surface="memory_write",
            operation="langgraph.store.delete",
            target=f"{namespace}/{key}",
            method="delete",
            transport_args=transport_args,
            boundary_kind="memory_write",
            action_class="memory_write",
            trust_boundary_crossing=False,
            tool_descriptor=descriptor,
            execute=execute,
        )

    async def asearch(self, *args, **kwargs):
        if self._delegate is not None and hasattr(self._delegate, "asearch"):
            result = await self._delegate.asearch(*args, **kwargs)
        else:
            result = []
        namespace = kwargs.get("namespace") if "namespace" in kwargs else (args[0] if len(args) >= 1 else None)
        query = kwargs.get("query")
        if query is None and len(args) >= 2:
            query = args[1]
        _record_store_memory_read(
            self,
            raw_name="langgraph.store.search",
            namespace=namespace,
            query=query,
            result=result,
        )
        return result


def _ensure_checkpoint_config(config):
    if config is None:
        config = {}
    if not isinstance(config, dict):
        return config

    configurable = config.get("configurable")
    if configurable is None:
        configurable = {}
    elif not isinstance(configurable, dict):
        return config
    else:
        configurable = dict(configurable)

    if configurable.get("thread_id") or configurable.get("checkpoint_ns") or configurable.get(
        "checkpoint_id"
    ):
        merged = dict(config)
        merged["configurable"] = configurable
        return merged

    configurable["thread_id"] = f"verifiedx-{uuid.uuid4().hex}"
    merged = dict(config)
    merged["configurable"] = configurable
    return merged


def _wrap_compiled_method(compiled, method_name):
    original = getattr(compiled, method_name, None)
    if original is None or getattr(original, "__verifiedx_config_wrapped__", False):
        return

    def _call_arguments(args, kwargs):
        try:
            parameters = inspect.signature(original).parameters
        except (TypeError, ValueError):
            parameters = {}
        if "config" not in parameters:
            return args, kwargs
        call_kwargs = dict(kwargs)
        if "config" in call_kwargs:
            call_kwargs["config"] = _ensure_checkpoint_config(call_kwargs["config"])
            return args, call_kwargs
        if len(args) >= 2:
            call_args = list(args)
            call_args[1] = _ensure_checkpoint_config(call_args[1])
            return tuple(call_args), call_kwargs
        call_kwargs["config"] = _ensure_checkpoint_config(None)
        return args, call_kwargs

    if method_name.startswith("a"):

        async def wrapped(*args, **kwargs):
            call_args, call_kwargs = _call_arguments(args, kwargs)
            return await original(*call_args, **call_kwargs)

    else:

        def wrapped(*args, **kwargs):
            call_args, call_kwargs = _call_arguments(args, kwargs)
            return original(*call_args, **call_kwargs)

    setattr(wrapped, "__verifiedx_config_wrapped__", True)
    setattr(compiled, method_name, wrapped)


def _wrap_compiled_capture_method(compiled, method_name, *, verifiedx, report):
    original = getattr(compiled, method_name, None)
    if original is None or getattr(original, "__verifiedx_capture_wrapped__", False):
        return

    def _input_value(args, kwargs):
        if "input" in kwargs:
            return kwargs.get("input")
        if args:
            return args[0]
        return None

    def _config_value(args, kwargs):
        if "config" in kwargs:
            return kwargs.get("config")
        if len(args) >= 2:
            return args[1]
        return None

    if method_name == "astream":

        async def wrapped(*args, **kwargs):
            _record_langgraph_invocation_context(
                verifiedx,
                report,
                method_name=method_name,
                input_value=_input_value(args, kwargs),
                config_value=_config_value(args, kwargs),
            )
            result = original(*args, **kwargs)
            async for item in result:
                _observe_langgraph_capture_points(verifiedx, report, item)
                yield item

    elif method_name == "stream":

        def wrapped(*args, **kwargs):
            _record_langgraph_invocation_context(
                verifiedx,
                report,
                method_name=method_name,
                input_value=_input_value(args, kwargs),
                config_value=_config_value(args, kwargs),
            )
            result = original(*args, **kwargs)
            for item in result:
                _observe_langgraph_capture_points(verifiedx, report, item)
                yield item

    elif method_name.startswith("a"):

        async def wrapped(*args, **kwargs):
            _record_langgraph_invocation_context(
                verifiedx,
                report,
                method_name=method_name,
                input_value=_input_value(args, kwargs),
                config_value=_config_value(args, kwargs),
            )
            result = await original(*args, **kwargs)
            _observe_langgraph_capture_points(verifiedx, report, result)
            return result

    else:

        def wrapped(*args, **kwargs):
            _record_langgraph_invocation_context(
                verifiedx,
                report,
                method_name=method_name,
                input_value=_input_value(args, kwargs),
                config_value=_config_value(args, kwargs),
            )
            result = original(*args, **kwargs)
            _observe_langgraph_capture_points(verifiedx, report, result)
            return result

    setattr(wrapped, "__verifiedx_capture_wrapped__", True)
    setattr(compiled, method_name, wrapped)


def _wrap_compiled_state_read_method(compiled, method_name, *, verifiedx, report):
    original = getattr(compiled, method_name, None)
    if original is None or getattr(original, "__verifiedx_state_read_wrapped__", False):
        return

    def _config_value(args, kwargs):
        if "config" in kwargs:
            return kwargs["config"]
        if args:
            return args[0]
        return None

    raw_name = f"langgraph.graph.{method_name}"

    if method_name.startswith("a"):

        async def wrapped(*args, **kwargs):
            config = _config_value(args, kwargs)
            result = await original(*args, **kwargs)
            _record_graph_state_read(
                verifiedx,
                report,
                raw_name=raw_name,
                config=config,
                result=result,
            )
            _observe_langgraph_capture_points(verifiedx, report, result)
            return result

    else:

        def wrapped(*args, **kwargs):
            config = _config_value(args, kwargs)
            result = original(*args, **kwargs)
            _record_graph_state_read(
                verifiedx,
                report,
                raw_name=raw_name,
                config=config,
                result=result,
            )
            _observe_langgraph_capture_points(verifiedx, report, result)
            return result

    setattr(wrapped, "__verifiedx_state_read_wrapped__", True)
    setattr(compiled, method_name, wrapped)


def _wrap_compiled_state_update_method(compiled, method_name, *, verifiedx):
    original = getattr(compiled, method_name, None)
    if original is None or getattr(original, "__verifiedx_state_update_wrapped__", False):
        return

    def _call_arguments(args, kwargs):
        try:
            parameters = inspect.signature(original).parameters
        except (TypeError, ValueError):
            parameters = {}
        call_kwargs = dict(kwargs)
        call_args = list(args)
        if "config" in parameters:
            if "config" in call_kwargs:
                call_kwargs["config"] = _ensure_checkpoint_config(call_kwargs["config"])
            elif len(call_args) >= 2:
                call_args[1] = _ensure_checkpoint_config(call_args[1])
        return tuple(call_args), call_kwargs

    def _config_value(call_args, call_kwargs):
        if "config" in call_kwargs:
            return call_kwargs["config"]
        if len(call_args) >= 2:
            return call_args[1]
        return None

    def _values_value(call_args, call_kwargs):
        if "values" in call_kwargs:
            return call_kwargs["values"]
        if len(call_args) >= 1:
            return call_args[-1]
        return None

    if method_name.startswith("a"):

        async def wrapped(*args, **kwargs):
            call_args, call_kwargs = _call_arguments(args, kwargs)
            config = _config_value(call_args, call_kwargs)
            values = _values_value(call_args, call_kwargs)
            thread_id = None
            if isinstance(config, dict):
                thread_id = (config.get("configurable") or {}).get("thread_id")
            transport_args = _langgraph_jsonable({
                "config": config,
                "values": values,
            })
            descriptor = _langgraph_tool_descriptor(
                "langgraph.graph.update_state",
                transport_args,
                pending_action={
                    "surface": "tool_dispatch",
                    "raw_name": "langgraph.graph.update_state",
                    "method": "update_state",
                    "target": str(thread_id or "langgraph.graph"),
                    "boundary_kind": "action_execute",
                    "action_class": "system_change",
                    "trust_boundary_crossing": False,
                },
            )

            async def execute():
                return await original(*call_args, **call_kwargs)

            return await verifiedx.zero_touch.intercept_boundary_async(
                surface="tool_dispatch",
                operation="langgraph.graph.update_state",
                target=str(thread_id or "langgraph.graph"),
                method="update_state",
                transport_args=transport_args,
                boundary_kind="action_execute",
                action_class="system_change",
                trust_boundary_crossing=False,
                tool_descriptor=descriptor,
                execute=execute,
            )

    else:

        def wrapped(*args, **kwargs):
            call_args, call_kwargs = _call_arguments(args, kwargs)
            config = _config_value(call_args, call_kwargs)
            values = _values_value(call_args, call_kwargs)
            thread_id = None
            if isinstance(config, dict):
                thread_id = (config.get("configurable") or {}).get("thread_id")
            transport_args = _langgraph_jsonable({
                "config": config,
                "values": values,
            })
            descriptor = _langgraph_tool_descriptor(
                "langgraph.graph.update_state",
                transport_args,
                pending_action={
                    "surface": "tool_dispatch",
                    "raw_name": "langgraph.graph.update_state",
                    "method": "update_state",
                    "target": str(thread_id or "langgraph.graph"),
                    "boundary_kind": "action_execute",
                    "action_class": "system_change",
                    "trust_boundary_crossing": False,
                },
            )
            return verifiedx.zero_touch.intercept_boundary(
                surface="tool_dispatch",
                operation="langgraph.graph.update_state",
                target=str(thread_id or "langgraph.graph"),
                method="update_state",
                transport_args=transport_args,
                boundary_kind="action_execute",
                action_class="system_change",
                trust_boundary_crossing=False,
                tool_descriptor=descriptor,
                execute=lambda: original(*call_args, **call_kwargs),
            )

    setattr(wrapped, "__verifiedx_state_update_wrapped__", True)
    setattr(compiled, method_name, wrapped)


def _install_default_checkpoint_config(compiled, *, verifiedx, report):
    for method_name in ("invoke", "ainvoke", "stream", "astream", "batch", "abatch"):
        _wrap_compiled_method(compiled, method_name)
    for method_name in ("invoke", "ainvoke", "stream", "astream", "batch", "abatch"):
        _wrap_compiled_capture_method(compiled, method_name, verifiedx=verifiedx, report=report)
    for method_name in ("get_state", "aget_state"):
        _wrap_compiled_state_read_method(compiled, method_name, verifiedx=verifiedx, report=report)
    return compiled


def _wrap_state_node_action(action, *, node_name: str, verifiedx, report=None):
    if action is None:
        return None
    if getattr(action, "__verifiedx_langgraph_node_wrapped__", False):
        return action

    if inspect.iscoroutinefunction(action):

        @functools.wraps(action)
        async def wrapped(*args, **kwargs):
            result = await action(*args, **kwargs)
            _observe_langgraph_capture_points(verifiedx, report, result)
            return await _preflight_langgraph_command_update_async(
                verifiedx,
                node_name=node_name,
                result=result,
                config=_langgraph_config_value(args, kwargs),
            )

    elif inspect.isfunction(action) or inspect.ismethod(action):

        @functools.wraps(action)
        def wrapped(*args, **kwargs):
            result = action(*args, **kwargs)
            _observe_langgraph_capture_points(verifiedx, report, result)
            return _preflight_langgraph_command_update(
                verifiedx,
                node_name=node_name,
                result=result,
                config=_langgraph_config_value(args, kwargs),
            )

    else:
        wrapped_any = False
        for method_name in ("invoke", "ainvoke"):
            original = getattr(action, method_name, None)
            if original is None or getattr(original, "__verifiedx_langgraph_node_wrapped__", False):
                continue
            wrapped_any = True
            if method_name.startswith("a"):

                async def method_wrapper(*args, __original=original, **kwargs):
                    result = await __original(*args, **kwargs)
                    _observe_langgraph_capture_points(verifiedx, report, result)
                    return await _preflight_langgraph_command_update_async(
                        verifiedx,
                        node_name=node_name,
                        result=result,
                        config=_langgraph_config_value(args, kwargs),
                    )

            else:

                def method_wrapper(*args, __original=original, **kwargs):
                    result = __original(*args, **kwargs)
                    _observe_langgraph_capture_points(verifiedx, report, result)
                    return _preflight_langgraph_command_update(
                        verifiedx,
                        node_name=node_name,
                        result=result,
                        config=_langgraph_config_value(args, kwargs),
                    )

            setattr(method_wrapper, "__verifiedx_langgraph_node_wrapped__", True)
            setattr(action, method_name, method_wrapper)
        if wrapped_any:
            setattr(action, "__verifiedx_langgraph_node_wrapped__", True)
        return action

    setattr(wrapped, "__verifiedx_langgraph_node_wrapped__", True)
    return wrapped


def _patch_stategraph_add_node(*, verifiedx):
    try:
        from langgraph.graph import StateGraph
    except Exception:  # pragma: no cover - optional dependency layouts
        return
    original = getattr(StateGraph, "add_node", None)
    if original is None:
        return
    if getattr(original, "__verifiedx_langgraph_patched__", False):
        return

    def wrapped(self, node, action=None, *args, **kwargs):
        current_vx = _current_langgraph_verifiedx() or verifiedx
        effective_action = action if isinstance(node, str) else node
        node_name = _langgraph_node_name(node, effective_action)
        wrapped_action = _wrap_state_node_action(
            effective_action,
            node_name=node_name,
            verifiedx=current_vx,
        )
        if isinstance(node, str):
            return original(self, node, wrapped_action, *args, **kwargs)
        return original(self, wrapped_action, None, *args, **kwargs)

    setattr(wrapped, "__verifiedx_langgraph_patched__", True)
    setattr(StateGraph, "add_node", wrapped)


def _patch_langgraph_basetool_invoke(*, verifiedx):
    if BaseTool is None:
        return

    original_invoke = getattr(BaseTool, "invoke", None)
    if original_invoke is not None and not getattr(original_invoke, "__verifiedx_langgraph_wrapped__", False):

        @functools.wraps(original_invoke)
        def wrapped_invoke(self, input, config=None, **kwargs):
            current_vx = _current_langgraph_verifiedx() or verifiedx
            if current_vx is None:
                return original_invoke(self, input, config=config, **kwargs)
            return _preflight_langgraph_tool_execution(
                current_vx,
                tool=self,
                input_value=input,
                execute=lambda: original_invoke(self, input, config=config, **kwargs),
            )

        setattr(wrapped_invoke, "__verifiedx_langgraph_wrapped__", True)
        setattr(wrapped_invoke, "__verifiedx_langgraph_original__", original_invoke)
        BaseTool.invoke = wrapped_invoke

    original_ainvoke = getattr(BaseTool, "ainvoke", None)
    if original_ainvoke is not None and not getattr(original_ainvoke, "__verifiedx_langgraph_wrapped__", False):

        @functools.wraps(original_ainvoke)
        async def wrapped_ainvoke(self, input, config=None, **kwargs):
            current_vx = _current_langgraph_verifiedx() or verifiedx
            if current_vx is None:
                return await original_ainvoke(self, input, config=config, **kwargs)
            return await _preflight_langgraph_tool_execution_async(
                current_vx,
                tool=self,
                input_value=input,
                execute=lambda: original_ainvoke(self, input, config=config, **kwargs),
            )

        setattr(wrapped_ainvoke, "__verifiedx_langgraph_wrapped__", True)
        setattr(wrapped_ainvoke, "__verifiedx_langgraph_original__", original_ainvoke)
        BaseTool.ainvoke = wrapped_ainvoke


def _patch_stategraph_compile(*, verifiedx, framework_version: str | None):
    try:
        from langgraph.graph import StateGraph
    except Exception:  # pragma: no cover - optional dependency layouts
        return
    original = getattr(StateGraph, "compile", None)
    if original is None:
        return
    if getattr(original, "__verifiedx_langgraph_compile_patched__", False):
        return

    def wrapped(self, *args, **kwargs):
        current_vx = _current_langgraph_verifiedx() or verifiedx
        current_framework_version = _LANGGRAPH_INSTALL_STATE.get("framework_version") or framework_version
        return compile(
            self,
            *args,
            verifiedx=current_vx,
            framework_version=current_framework_version,
            **kwargs,
        )

    setattr(wrapped, "__verifiedx_langgraph_compile_patched__", True)
    setattr(wrapped, "__verifiedx_langgraph_original__", original)
    setattr(StateGraph, "compile", wrapped)


def _wrap_graph_node_specs(graph, *, verifiedx, report=None):
    nodes = getattr(graph, "nodes", None)
    if not isinstance(nodes, dict):
        return
    for node_name, spec in nodes.items():
        runnable = getattr(spec, "runnable", None)
        if runnable is None:
            continue
        wrapped_runnable = _wrap_state_node_action(
            runnable,
            node_name=str(node_name),
            verifiedx=verifiedx,
            report=report,
        )
        try:
            setattr(spec, "runnable", wrapped_runnable)
        except Exception:
            object.__setattr__(spec, "runnable", wrapped_runnable)


def install(*, verifiedx=None, framework_version: str | None = None):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    framework_version = _langgraph_framework_version(framework_version)
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    _LANGGRAPH_INSTALL_STATE["verifiedx"] = vx
    _LANGGRAPH_INSTALL_STATE["framework_version"] = framework_version
    _langgraph_report(vx, framework_version=framework_version, activation_source="langgraph_install")
    _patch_stategraph_add_node(verifiedx=vx)
    _patch_langgraph_basetool_invoke(verifiedx=vx)
    _patch_stategraph_compile(verifiedx=vx, framework_version=framework_version)
    return vx


def compile(graph, *args, verifiedx=None, checkpointer=None, framework_version=None, **kwargs):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    framework_version = _langgraph_framework_version(framework_version)
    report = _langgraph_report(
        vx,
        framework_version=framework_version,
        activation_source="langgraph_compile",
    )
    _patch_langgraph_basetool_invoke(verifiedx=vx)
    _wrap_graph_node_specs(graph, verifiedx=vx, report=report)
    delegate = checkpointer if checkpointer is not None else kwargs.get("checkpointer")
    if delegate is True or delegate is False:
        kwargs["checkpointer"] = delegate
    else:
        kwargs["checkpointer"] = VerifiedXCheckpointer(vx, delegate=delegate, report=report)
    store = kwargs.get("store")
    if store is not None and store is not True and store is not False:
        kwargs["store"] = VerifiedXStore(vx, delegate=store, report=report)
    graph_compile = getattr(graph, "compile")
    original_compile = getattr(graph_compile, "__verifiedx_langgraph_original__", None)
    if original_compile is not None:
        compiled = original_compile(graph, *args, **kwargs)
    else:
        compiled = graph_compile(*args, **kwargs)
    _install_default_checkpoint_config(compiled, verifiedx=vx, report=report)
    for method_name in ("update_state", "aupdate_state"):
        _wrap_compiled_state_update_method(compiled, method_name, verifiedx=vx)
    setattr(compiled, "__verifiedx_activation_report__", report.as_dict())
    return compiled


def attach(graph=None, *, verifiedx=None, framework_version: str | None = None):
    vx = install(verifiedx=verifiedx, framework_version=framework_version)
    return graph if graph is not None else vx
