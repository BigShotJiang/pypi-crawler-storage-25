def _goal_completion_warning(
    goal_state_hint: str | None,
    action_class: str | None,
    boundary_kind: str | None,
) -> str | None:
    if not goal_state_hint:
        return None
    if action_class == "webhook_call":
        return (
            f"The goal `{goal_state_hint}` is still incomplete because notification did not happen. "
            "Do not mark any ticket, task, or downstream state as notified, completed, or sent until a later allowed webhook call returns ok=true."
        )
    if action_class == "record_mutation":
        return (
            f"The goal `{goal_state_hint}` is still incomplete because the mutation did not happen. "
            "Do not narrate the state change as completed until a later allowed mutation returns ok=true."
        )
    if action_class == "system_change":
        return (
            f"The goal `{goal_state_hint}` is still incomplete because the internal workflow or system state did not change. "
            "Do not claim the status, routing, assignment, or configuration update happened until a later allowed update returns ok=true."
        )
    if boundary_kind == "memory_write":
        return (
            f"The goal `{goal_state_hint}` is still incomplete because the durable memory write did not happen. "
            "Do not claim the memory was saved until a later allowed write returns ok=true."
        )
    return (
        f"The goal `{goal_state_hint}` is still incomplete because this side effect did not happen. "
        "Do not claim completion for any downstream step that depends on it."
    )


def _normalize_ticket_status_token(status: str | None) -> str:
    if not status:
        return ""
    return status.strip().lower().replace("-", "_")


def _decision_replan_scope(decision: dict | None) -> str | None:
    if not isinstance(decision, dict):
        return None
    retry_directive = decision.get("retry_directive") or {}
    raw_value = retry_directive.get("replan_scope", decision.get("replan_scope"))
    normalized = str(raw_value or "").strip().lower()
    return normalized if normalized in {"local", "upstream"} else None


def _receipt_mode(
    decision: dict | None,
    outcome: str | None,
    *,
    human_review_terminal: bool,
    composed: bool,
) -> str:
    normalized = str(outcome or "").strip().lower()
    if normalized in {"allow", "allow_with_warning"}:
        return "continue_downstream"
    if normalized == "replan_required":
        if not composed:
            return "local_replan"
        return "upstream_replan" if _decision_replan_scope(decision) == "upstream" else "local_replan"
    if normalized in {"goal_fail_terminal", "block"}:
        return "terminal_block"
    if human_review_terminal or normalized == "ask_human":
        return "human_review"
    return "terminal_block"


def _receipt_direction(mode: str) -> str:
    if mode == "continue_downstream":
        return "downstream"
    if mode == "local_replan":
        return "local"
    if mode == "upstream_replan":
        return "upstream"
    if mode == "human_review":
        return "human"
    return "stop"


def _resume_when(decision: dict) -> list[str]:
    explicit = [str(item).strip() for item in list(decision.get("what_would_change_this") or []) if str(item).strip()]
    if explicit:
        return explicit
    return [
        str(step.get("message") or "").strip()
        for step in list(decision.get("safe_next_steps") or [])
        if isinstance(step, dict) and str(step.get("message") or "").strip()
    ]


def _maybe_scalar_text(value):
    if isinstance(value, str):
        text = value.strip()
        return text or None
    if isinstance(value, (int, float, bool)):
        return str(value)
    return None


def _extract_upstream_routing_hints(value, *, depth: int = 0, state: dict | None = None) -> dict:
    state = state or {
        "return_to_node": None,
        "target_hint": None,
        "workflow_id": None,
        "last_source": None,
    }
    if depth > 6 or value is None:
        return state
    if isinstance(value, list):
        for item in value:
            _extract_upstream_routing_hints(item, depth=depth + 1, state=state)
        return state
    if isinstance(value, dict):
        for raw_key, nested in value.items():
            key = str(raw_key or "").strip().lower()
            scalar = _maybe_scalar_text(nested)
            if key in {"return_to_node", "return_node", "resume_target", "parent_node_id", "parent_node"} and scalar:
                state["return_to_node"] = state["return_to_node"] or scalar
            if key in {"target_hint", "target_node", "upstream_node"} and scalar:
                state["target_hint"] = state["target_hint"] or scalar
            if key in {"workflow_id", "request_id", "case_id", "ticket_id", "thread_id"} and scalar:
                state["workflow_id"] = state["workflow_id"] or scalar
            if key == "source" and scalar:
                state["last_source"] = scalar
            _extract_upstream_routing_hints(nested, depth=depth + 1, state=state)
        return state
    return state


def build_decision_receipt(
    decision: dict | None,
    *,
    metadata: dict | None = None,
    upstream_context=None,
    conversation_source: str | None = None,
) -> dict | None:
    if not isinstance(decision, dict):
        return None
    decision_id = decision.get("decision_id")
    outcome = decision.get("outcome")
    if not decision_id or not outcome:
        return None
    composed = upstream_context is not None
    normalized_outcome = str(outcome or "").strip().lower()
    human_review_terminal = (
        normalized_outcome not in {"goal_fail_terminal", "block"}
        and bool(decision.get("human_review_terminal", False))
    )
    mode = _receipt_mode(
        decision,
        outcome,
        human_review_terminal=human_review_terminal,
        composed=composed,
    )
    hints = _extract_upstream_routing_hints(upstream_context)
    must_not_retry_same_action = bool(decision.get("must_not_retry_same_action", False))
    retry_directive = decision.get("retry_directive") or {}
    if isinstance(retry_directive.get("can_retry"), bool):
        can_retry_same_action = retry_directive.get("can_retry")
    else:
        can_retry_same_action = not must_not_retry_same_action and outcome == "replan_required"
    routing = {
        "direction": _receipt_direction(mode),
        "target_hint": hints.get("target_hint") or hints.get("return_to_node") or hints.get("last_source"),
        "return_to_node": hints.get("return_to_node"),
        "workflow_id": hints.get("workflow_id"),
        "node_id": _maybe_scalar_text(conversation_source),
    }
    return {
        "receipt_type": "verifiedx_decision_receipt",
        "decision_id": decision_id,
        "outcome": outcome,
        "action_class": decision.get("action_class"),
        "safe_to_execute": outcome in {"allow", "allow_with_warning"},
        "human_review_terminal": human_review_terminal,
        "must_not_retry_same_action": must_not_retry_same_action,
        "reasons": list(decision.get("reasons") or []),
        "safe_next_steps": list(decision.get("safe_next_steps") or []),
        "viewer_guidance": list(decision.get("viewer_guidance") or []),
        "what_would_change_this": list(decision.get("what_would_change_this") or []),
        "disposition": {
            "mode": mode,
            "downstream_allowed": mode == "continue_downstream",
            "local_replan_recommended": mode == "local_replan",
            "upstream_replan_required": mode == "upstream_replan",
        },
        "routing": routing,
        "resume_contract": {
            "retry_this_node": mode in {"local_replan", "upstream_replan"} and can_retry_same_action,
            "pass_receipt_upstream": mode == "upstream_replan",
            "pass_new_upstream_context_on_retry": mode == "upstream_replan" and can_retry_same_action,
            "resume_when": _resume_when(decision),
        },
        "runtime_loopback": decision.get("runtime_loopback"),
        "metadata": metadata or {},
    }


def _is_completion_like_ticket_status(status: str | None) -> bool:
    normalized = _normalize_ticket_status_token(status)
    if not normalized:
        return False
    return any(
        token in normalized
        for token in (
            "resolved",
            "closed",
            "done",
            "complete",
            "completed",
            "notified",
            "approved",
            "handed_off",
            "escalated_external",
        )
    )


def _pending_effect_record_id(pending_effect: dict | None) -> str | None:
    if not isinstance(pending_effect, dict):
        return None
    executable_payload = pending_effect.get("executable_payload")
    if isinstance(executable_payload, dict) and isinstance(executable_payload.get("record_id"), str):
        return executable_payload["record_id"]
    for parameter in pending_effect.get("typed_material_parameters", []):
        if not isinstance(parameter, dict):
            continue
        if parameter.get("parameter_name") != "record_id":
            continue
        chosen_value = parameter.get("chosen_value")
        if isinstance(chosen_value, str):
            return chosen_value
    return None


def _pending_effect_field_patch(pending_effect: dict | None) -> dict | None:
    if not isinstance(pending_effect, dict):
        return None
    executable_payload = pending_effect.get("executable_payload")
    if isinstance(executable_payload, dict) and isinstance(executable_payload.get("field_patch"), dict):
        return executable_payload["field_patch"]
    for parameter in pending_effect.get("typed_material_parameters", []):
        if not isinstance(parameter, dict):
            continue
        if parameter.get("parameter_name") != "field_patch":
            continue
        chosen_value = parameter.get("chosen_value")
        if isinstance(chosen_value, dict):
            return chosen_value
    return None


def _pending_effect_is_ticket_case(pending_effect: dict | None) -> bool:
    record_id = (_pending_effect_record_id(pending_effect) or "").lower()
    if any(record_id.startswith(prefix) for prefix in ("sup-", "ticket-", "case-", "incident-")):
        return True
    if not isinstance(pending_effect, dict):
        return False
    target = pending_effect.get("target")
    if not isinstance(target, dict):
        return False
    return any(
        token in str(target.get(field) or "").lower()
        for field in ("target_class", "target_identifier", "destination", "system_of_record")
        for token in ("ticket", "support", "case", "incident")
    )


def _blocked_ticket_completion_step(pending_effect: dict | None) -> dict | None:
    if not _pending_effect_is_ticket_case(pending_effect):
        return None
    field_patch = _pending_effect_field_patch(pending_effect)
    if not isinstance(field_patch, dict):
        return None
    if not _is_completion_like_ticket_status(field_patch.get("status")):
        return None
    return {
        "code": "preserve_truthful_nonterminal_ticket_status",
        "message": (
            "Do not mark the ticket or case as done, resolved, notified, approved, or otherwise "
            "complete after a blocked or unsupported step. Retry only with a truthful non-terminal "
            "internal status such as open, pending, blocked, awaiting_human, or investigating, "
            "and include a note that the blocked effect did not happen."
        ),
    }


def _safe_next_steps(
    decision: dict,
    *,
    boundary_kind: str | None = None,
    action_class: str | None = None,
    pending_effect: dict | None = None,
) -> list[dict]:
    loopback = decision.get("runtime_loopback") or {}
    steps = list(loopback.get("safe_next_steps") or decision.get("safe_next_steps", []))
    if boundary_kind == "action_execute" and action_class in {
        "external_message_send",
        "webhook_call",
        "browser_submit",
        "upload",
    }:
        bookkeeping_step = {
            "code": "record_safe_internal_bookkeeping",
            "message": (
                "If the external effect cannot be completed safely, keep the same goal state moving "
                "with a safe internal note or status update that explicitly says the effect did not happen."
            ),
        }
        if not any(
            isinstance(step, dict) and step.get("code") == bookkeeping_step["code"] for step in steps
        ):
            steps.append(bookkeeping_step)
    if boundary_kind == "action_execute" and action_class == "record_mutation":
        blocked_completion_step = _blocked_ticket_completion_step(pending_effect)
        if blocked_completion_step and not any(
            isinstance(step, dict) and step.get("code") == blocked_completion_step["code"]
            for step in steps
        ):
            steps.append(blocked_completion_step)
    if boundary_kind == "action_execute" and action_class == "system_change":
        truthful_state_step = {
            "code": "preserve_truthful_internal_state",
            "message": (
                "Keep any internal workflow, routing, assignment, or configuration status truthful. "
                "Do not mark the internal change as applied until a later allowed update returns ok=true."
            ),
        }
        if not any(
            isinstance(step, dict) and step.get("code") == truthful_state_step["code"]
            for step in steps
        ):
            steps.append(truthful_state_step)
    return steps


def build_loopback_tool_result(
    decision: dict,
    *,
    boundary_kind: str | None = None,
    action_class: str | None = None,
    goal_state_hint: str | None = None,
    pending_effect: dict | None = None,
) -> dict:
    loopback = decision.get("runtime_loopback") or {}
    retry_directive = decision.get("retry_directive") or {}
    receipt = decision.get("decision_receipt") or build_decision_receipt(decision)
    disposition = receipt.get("disposition") or {}
    routing = receipt.get("routing") or {}
    resume_contract = receipt.get("resume_contract") or {}
    disposition_mode = str(disposition.get("mode") or "").strip().lower()
    upstream_replan = disposition_mode == "upstream_replan"
    same_goal_state = loopback.get("same_goal_state", retry_directive.get("same_goal_state", True))
    must_not_retry_same_action = bool(
        receipt.get("must_not_retry_same_action")
        if isinstance(receipt, dict) and "must_not_retry_same_action" in receipt
        else decision.get(
            "must_not_retry_same_action",
            loopback.get("must_not_retry_same_action", False),
        )
    )
    can_retry_same_action = bool(
        resume_contract.get("retry_this_node")
        if isinstance(resume_contract, dict) and "retry_this_node" in resume_contract
        else retry_directive.get("can_retry", (not must_not_retry_same_action and disposition_mode == "local_replan"))
    )
    safe_next_steps = _safe_next_steps(
        decision,
        boundary_kind=boundary_kind,
        action_class=action_class,
        pending_effect=pending_effect,
    )
    strategy = retry_directive.get("strategy") or (
        "Keep working toward the same goal state while avoiding the denied side effect."
        if same_goal_state
        else "The current goal cannot continue safely through this path. Stop the denied side effect and return the terminal reasons."
    )
    completion_warning = _goal_completion_warning(
        goal_state_hint,
        action_class,
        boundary_kind,
    )
    if completion_warning and same_goal_state:
        strategy = f"{strategy} {completion_warning}"
    if upstream_replan:
        strategy = (
            "Stop work on this local node and return the decision receipt to the caller, "
            "orchestrating workflow, or parent system upstream so the missing evidence or "
            "approvals can be gathered before retrying this node."
            if can_retry_same_action
            else "Stop work on this local node and return the decision receipt to the caller, "
            "orchestrating workflow, or parent system upstream. Do not retry this exact action. "
            "Keep the overall goal moving through a different upstream decision, review, reroute, "
            "or human-owned step."
        )
    elif same_goal_state and must_not_retry_same_action:
        strategy = (
            "Do not execute or retry this exact action. Keep moving toward the same goal with a "
            "different safe step, reroute, escalation, or human decision."
        )
    local_continue = same_goal_state and not upstream_replan
    agent_instruction = (
        (
            "This tool call returned ok=false and requires an upstream replan. The requested side effect did NOT "
            "execute and no state changed. Do not make another local tool call for this node, do not continue "
            "downstream, and return the decision_receipt upstream to your caller or orchestrating workflow. "
            "Retry this node only after upstream context changes to satisfy the unblock requirements."
        )
        if upstream_replan and can_retry_same_action
        else (
            "This tool call returned ok=false and requires an upstream replan. The requested side effect did NOT "
            "execute and no state changed. Do not make another local tool call for this node, do not continue "
            "downstream, and return the decision_receipt upstream to your caller or orchestrating workflow. "
            "Do NOT retry this exact action unless a later materially different attempt is explicitly allowed."
        )
        if upstream_replan
        else (
            (
                "This tool call returned ok=false. The requested side effect was NOT executed and no state changed. "
                "Do not claim this step succeeded or that any mutation was applied. Keep moving toward the same goal state, "
                "do NOT retry this exact action, and use the reasons and safe next steps below to choose a different "
                "safe path. Any downstream step that semantically depends on this blocked effect is also still "
                "incomplete until a later allowed path returns ok=true."
            )
            if same_goal_state and must_not_retry_same_action
            else "This tool call returned ok=false. The requested side effect was NOT executed and no state changed. "
            "Do not claim this step succeeded or that any mutation was applied. Keep moving toward the same goal state, "
            "and retry this exact action only if newer evidence or approval directly clears the unblock condition. "
            "Any downstream step that semantically depends on this blocked effect is also still incomplete until a later allowed attempt returns ok=true."
            if same_goal_state
            else "This tool call returned ok=false. The requested side effect was NOT executed and no state changed. Do NOT retry this exact action. The current goal cannot continue safely through this path, so stop the denied boundary path and return the terminal reasons."
        )
    )
    return {
        "ok": False,
        "blocked": True,
        "boundary_outcome": decision.get("outcome", "block"),
        "side_effect_executed": False,
        "state_changed": False,
        "step_status": "not_executed",
        "continue_toward_goal": local_continue,
        "must_replan": local_continue,
        "required_replan": local_continue,
        "must_not_claim_success": True,
        "completion_allowed": False,
        "human_review_terminal": loopback.get("human_review_terminal", False),
        "decision_id": decision.get("decision_id"),
        "ingest_id": decision.get("ingest_id"),
        "retryability": loopback.get("retryability", retry_directive.get("retryability", "replan")),
        "strategy": strategy,
        "agent_instruction": agent_instruction,
        "goal_state_hint": goal_state_hint,
        "blocked_boundary": boundary_kind,
        "blocked_action_class": action_class,
        "pending_effect": pending_effect or {},
        "keep_working_until_goal_resolved": local_continue,
        "goal_completion_warning": completion_warning,
        "must_not_mark_goal_complete": bool(completion_warning) or upstream_replan,
        "safe_next_steps": safe_next_steps,
        "reasons": decision.get("reasons", []),
        "missing_support": loopback.get("missing_support") or decision.get("missing_support", []),
        "authorization_gaps": loopback.get("authorization_gaps")
        or decision.get("authorization_gaps", []),
        "must_not_retry_same_action": decision.get("must_not_retry_same_action", False),
        "forbidden_action_fingerprint": decision.get("forbidden_action_fingerprint"),
        "forbidden_action_equivalence_class": decision.get("forbidden_action_equivalence_class"),
        "viewer_guidance": loopback.get("viewer_guidance") or decision.get("viewer_guidance", []),
        "what_would_change_this": loopback.get("what_would_change_this")
        or decision.get("what_would_change_this", []),
        "disposition": disposition,
        "routing": routing,
        "resume_contract": resume_contract,
        "upstream_replan_required": upstream_replan,
        "local_replan_recommended": disposition_mode == "local_replan",
        "downstream_allowed": bool(disposition.get("downstream_allowed", False)),
        "runtime_loopback": loopback,
        "decision_receipt": receipt,
    }


class BoundaryDeniedError(RuntimeError):
    def __init__(self, decision: dict):
        self.decision = decision
        self.loopback = decision.get("runtime_loopback")
        outcome = decision.get("outcome", "block")
        super().__init__(f"VerifiedX blocked the pending side effect with outcome={outcome}")

    def tool_result(self) -> dict:
        return build_loopback_tool_result(self.decision)


class VerifiedXApiError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        code: str | None = None,
        retryable: bool | None = None,
        body=None,
    ):
        self.status = status
        self.code = code
        self.retryable = retryable
        self.body = body
        super().__init__(message)


class SandboxLimitReachedError(VerifiedXApiError):
    def __init__(
        self,
        message: str = (
            "Free Sandbox limit reached. Upgrade to Startup in the VerifiedX dashboard "
            "to continue running protected action checks this month."
        ),
        *,
        status: int | None = None,
        retryable: bool | None = None,
        body=None,
    ):
        super().__init__(
            message,
            status=status,
            code="sandbox_limit_reached",
            retryable=False if retryable is None else retryable,
            body=body,
        )
