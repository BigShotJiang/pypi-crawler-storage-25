from __future__ import annotations

import asyncio
import inspect
import json
import re
from typing import Any, Callable


ANTHROPIC_DIRECT_ADAPTER_KIND = "anthropic_direct"
ANTHROPIC_DIRECT_NATIVE_CAPABILITIES = [
    "messages_api",
    "native_tool_use",
    "runtime_loopback",
]

ANTHROPIC_DIRECT_MUTATING_COMMANDS = {
    "append",
    "create",
    "delete",
    "insert",
    "rename",
    "replace",
    "str_replace",
    "write",
}

ANTHROPIC_DIRECT_HISTORY_SEMANTICS = {
    "code_execution": "system_mutation",
    "tool_search_tool_bm25": "tool_search",
    "tool_search_tool_regex": "tool_search",
    "web_fetch": "external_retrieval",
    "web_search": "external_search",
}

ANTHROPIC_DIRECT_RETRIEVAL_CLASSES = {
    "external_retrieval",
    "external_search",
    "file_read",
    "memory_read",
    "tool_search",
}

ANTHROPIC_DIRECT_SERVER_TOOL_TYPES = {
    "code_execution_20250522",
    "code_execution_20250825",
    "code_execution_20260120",
    "tool_search_tool_bm25_20251119",
    "tool_search_tool_regex_20251119",
    "web_fetch_20250910",
    "web_fetch_20260209",
    "web_fetch_20260309",
    "web_search_20250305",
    "web_search_20260209",
}

ANTHROPIC_DIRECT_TRIGGER_TOOL_TYPES = {
    "bash_20250124",
    "memory_20250818",
    "text_editor_20250124",
    "text_editor_20250728",
}
_MUTATION_HINTS = {
    "append",
    "apply",
    "archive",
    "cancel",
    "change",
    "close",
    "confirm",
    "create",
    "credit",
    "delete",
    "disable",
    "edit",
    "enable",
    "exchange",
    "insert",
    "issue",
    "patch",
    "pause",
    "persist",
    "reactivate",
    "refund",
    "remember",
    "reroute",
    "replace",
    "route",
    "save",
    "set",
    "skip",
    "store",
    "str_replace",
    "sync",
    "tag",
    "update",
    "upsert",
    "verify",
    "write",
}
_MEMORY_HINTS = {"memory", "memo", "note", "preference", "remember", "state"}
_RECORD_HINTS = {
    "account",
    "address",
    "application",
    "asset",
    "booking",
    "case",
    "claim",
    "contact",
    "contract",
    "customer",
    "delivery",
    "device",
    "email",
    "incident",
    "invoice",
    "issue",
    "lead",
    "opportunity",
    "order",
    "policy",
    "profile",
    "record",
    "reservation",
    "subscription",
    "task",
    "ticket",
    "user",
    "workflow",
}
_INTERNAL_HINTS = {
    "approval",
    "assignment",
    "checkpoint",
    "config",
    "configuration",
    "context",
    "flag",
    "identity",
    "metadata",
    "policy",
    "queue",
    "review",
    "route",
    "routing",
    "rule",
    "setting",
    "settings",
    "specialist",
    "stage",
    "state",
    "status",
    "thread",
    "verification",
    "workflow",
}
_MESSAGE_HINTS = {
    "alert",
    "body",
    "channel",
    "chat",
    "comment",
    "conversation",
    "dm",
    "email",
    "mail",
    "message",
    "messages",
    "notify",
    "notification",
    "post",
    "recipient",
    "reply",
    "send",
    "slack",
    "subject",
    "teams",
    "text",
    "thread",
}
_MEMORY_PROPERTY_HINTS = {
    "fact",
    "facts",
    "key",
    "memory",
    "memo",
    "namespace",
    "note",
    "notes",
    "preference",
    "preferences",
    "summary",
    "value",
}
_RECORD_PROPERTY_HINTS = {
    "account_id",
    "assignee",
    "case_id",
    "contact_id",
    "customer_id",
    "fields",
    "id",
    "issue_id",
    "lead_id",
    "opportunity_id",
    "order_id",
    "owner",
    "patch",
    "priority",
    "profile_id",
    "record_id",
    "reservation_id",
    "stage",
    "state",
    "status",
    "subscription_id",
    "task_id",
    "ticket_id",
    "tier",
    "update",
    "user_id",
    "workflow_id",
}
_INTERNAL_PROPERTY_HINTS = {
    "config",
    "configuration",
    "enabled",
    "flag",
    "flags",
    "job_id",
    "metadata",
    "mode",
    "policy",
    "route",
    "routing",
    "rule",
    "rules",
    "setting",
    "settings",
    "stage",
    "state",
    "status",
    "task_id",
    "workflow_id",
}
_MESSAGE_PROPERTY_HINTS = {
    "address",
    "bcc",
    "body",
    "cc",
    "channel",
    "channel_id",
    "comment",
    "content",
    "conversation_id",
    "dm",
    "email",
    "message",
    "note",
    "recipient",
    "recipient_id",
    "reply",
    "subject",
    "text",
    "thread_id",
    "to",
    "user_id",
}
ANTHROPIC_DIRECT_INSTALL_MARK = "_verifiedx_anthropic_direct_install_report"


def install(*, verifiedx=None, framework_version: str | None = None):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    cached = getattr(vx, ANTHROPIC_DIRECT_INSTALL_MARK, None)
    if cached is not None:
        return vx
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    report = vx.activation_report(
        ANTHROPIC_DIRECT_ADAPTER_KIND,
        "native",
        list(ANTHROPIC_DIRECT_NATIVE_CAPABILITIES),
        framework_version=framework_version,
        activation_source="anthropic_direct_install",
    )
    vx._zero_touch.report = report
    vx._otel_bridge.apply_report(report)
    vx.capture.set_default_adapter(report.to_adapter_context())
    vx.record_activation_diagnostic(report)
    setattr(vx, ANTHROPIC_DIRECT_INSTALL_MARK, report)
    return vx


def attach(client=None, *, verifiedx=None, framework_version: str | None = None):
    vx = install(verifiedx=verifiedx, framework_version=framework_version)
    return client if client is not None else vx


def extract_prompt_messages(
    *,
    messages: Any,
    system: Any = None,
) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    system_text = _system_text(system)
    if system_text:
        normalized.append({"role": "system", "content": system_text})

    if not isinstance(messages, list):
        return normalized

    for item in messages:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        if role not in {"user", "assistant"}:
            continue
        content = _message_text(item.get("content"))
        if not content:
            continue
        normalized.append(
            {
                "role": role,
                "content": content,
                **({"message_id": item.get("id")} if item.get("id") else {}),
            }
        )
    return normalized


def normalize_tool_definitions(raw_tools: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_tools, list):
        return []
    normalized: list[dict[str, Any]] = []
    for tool in raw_tools:
        if not isinstance(tool, dict):
            continue
        tool_name = str(tool.get("name") or "").strip()
        if not tool_name:
            continue
        tool_type = str(tool.get("type") or tool_name).strip()
        semantic_class = _tool_semantic_class(
            raw_name=tool_name,
            native_tool_type=tool_type,
            args={},
            provider_event_type="definition",
        )
        read_only = _tool_read_only(
            raw_name=tool_name,
            native_tool_type=tool_type,
            args={},
            provider_event_type="definition",
        )
        metadata: dict[str, Any] = {
            "native_tool_type": tool_type,
            "provider_executed": tool_type in ANTHROPIC_DIRECT_SERVER_TOOL_TYPES,
        }
        if semantic_class:
            metadata["semantic_class"] = semantic_class
        if read_only:
            metadata["read_only"] = True
        if semantic_class in ANTHROPIC_DIRECT_RETRIEVAL_CLASSES:
            metadata["retrieval_like"] = True
        normalized.append(
            {
                "tool_name": tool_name,
                "schema": tool.get("input_schema") or tool.get("inputSchema") or {"type": "object", "additionalProperties": True},
                "docstring": tool.get("description"),
                "metadata": metadata,
            }
        )
    return normalized


def normalize_message_tool_calls(
    result: Any,
    *,
    result_mapping: Callable[[Any], dict[str, Any] | None],
    normalize_tool_arguments: Callable[[Any], dict[str, Any]],
    tool_definitions: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    mapped = result_mapping(result) or {}
    content = mapped.get("content")
    if not isinstance(content, list):
        content = getattr(result, "content", None) or []
    definitions_by_name = {
        str(item.get("tool_name") or "").strip(): item
        for item in (tool_definitions or [])
        if isinstance(item, dict) and str(item.get("tool_name") or "").strip()
    }

    normalized_calls: list[dict[str, Any]] = []
    for block in content:
        payload = block if isinstance(block, dict) else (result_mapping(block) or {})
        if not isinstance(payload, dict):
            continue
        provider_event_type = str(payload.get("type") or "").strip().lower()
        if provider_event_type not in {"tool_use", "server_tool_use"}:
            continue
        tool_name = str(payload.get("name") or "").strip()
        if not tool_name:
            continue
        args = normalize_tool_arguments(payload.get("input"))
        definition = definitions_by_name.get(tool_name) or {}
        metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
        native_tool_type = str(metadata.get("native_tool_type") or tool_name).strip()
        semantic_class = _tool_semantic_class(
            raw_name=tool_name,
            native_tool_type=native_tool_type,
            args=args,
            provider_event_type=provider_event_type,
        )
        read_only = _tool_read_only(
            raw_name=tool_name,
            native_tool_type=native_tool_type,
            args=args,
            provider_event_type=provider_event_type,
        )
        pending_action = describe_pending_action(
            raw_name=tool_name,
            native_tool_type=native_tool_type,
            provider_event_type=provider_event_type,
            args=args,
            command=_tool_command(args),
            dispatch_target=lambda current_name, current_args: _dispatch_target(current_name, current_args),
        )
        record = {
            "tool_name": tool_name,
            "raw_name": tool_name,
            "tool_call_id": payload.get("id"),
            "source": f"anthropic.messages.{provider_event_type}",
            "args": args,
            "raw_args": args,
            "provider_event_type": provider_event_type,
        }
        if semantic_class:
            record["semantic_class"] = semantic_class
        if read_only:
            record["read_only"] = True
        if semantic_class in ANTHROPIC_DIRECT_RETRIEVAL_CLASSES:
            record["retrieval_like"] = True
        if provider_event_type == "server_tool_use":
            record["provider_executed"] = True
        if pending_action is not None:
            record["pending_action"] = pending_action
        normalized_calls.append(record)
    return normalized_calls


def assistant_text(
    result: Any,
    *,
    result_mapping: Callable[[Any], dict[str, Any] | None],
) -> str | None:
    mapped = result_mapping(result) or {}
    content = mapped.get("content")
    if not isinstance(content, list):
        content = getattr(result, "content", None) or []
    parts: list[str] = []
    for block in content:
        payload = block if isinstance(block, dict) else (result_mapping(block) or {})
        if not isinstance(payload, dict):
            continue
        if str(payload.get("type") or "").strip().lower() != "text":
            continue
        text = _message_text(payload.get("text"))
        if text:
            parts.append(text)
    joined = " ".join(part for part in parts if part).strip()
    return joined or None


def describe_pending_action(
    *,
    raw_name: str,
    native_tool_type: str,
    provider_event_type: str,
    args: dict[str, Any],
    command: str,
    dispatch_target: Callable[[str, dict[str, Any]], str],
) -> dict[str, Any] | None:
    if str(provider_event_type or "").strip().lower() == "server_tool_use":
        return None
    tool_type = str(native_tool_type or "").strip().lower()
    normalized_command = str(command or "").strip().lower()
    target = dispatch_target(raw_name or tool_type, args)
    if tool_type == "memory_20250818" and normalized_command in ANTHROPIC_DIRECT_MUTATING_COMMANDS:
        return {
            "surface": "memory_write",
            "operation": raw_name or tool_type,
            "target": target,
            "method": normalized_command or "write",
            "raw_args": dict(args),
            "boundary_kind": "memory_write",
            "action_class": "memory_write",
            "trust_boundary_crossing": False,
        }
    if tool_type.startswith("text_editor_") and normalized_command in ANTHROPIC_DIRECT_MUTATING_COMMANDS:
        return {
            "surface": "file_write",
            "operation": raw_name or tool_type,
            "target": str(args.get("path") or args.get("file_path") or target),
            "method": normalized_command or "write",
            "raw_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": False,
        }
    if tool_type.startswith("bash_"):
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or tool_type,
            "target": command or target or raw_name or tool_type,
            "method": "CALL",
            "raw_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    return None


def requires_direct_boundary(
    *,
    raw_name: str,
    native_tool_type: str,
    provider_event_type: str,
    args: dict[str, Any],
    provider_executed: bool = False,
) -> bool:
    if provider_executed or str(provider_event_type or "").strip().lower() == "server_tool_use":
        return False
    tool_type = str(native_tool_type or "").strip().lower()
    command = _tool_command(args).lower()
    if tool_type == "memory_20250818":
        return command in ANTHROPIC_DIRECT_MUTATING_COMMANDS
    if tool_type.startswith("text_editor_"):
        return command in ANTHROPIC_DIRECT_MUTATING_COMMANDS
    if tool_type.startswith("bash_"):
        return True
    return False


def _system_text(system: Any) -> str:
    return _message_text(system)


def _message_text(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                text = item.strip()
                if text:
                    parts.append(text)
                continue
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("type") or "").strip().lower()
            if item_type not in {"text", "text_delta"}:
                continue
            text = _message_text(item.get("text"))
            if text:
                parts.append(text)
        return " ".join(part for part in parts if part).strip()
    if isinstance(value, dict):
        return _message_text(value.get("text") or value.get("content") or value.get("value"))
    return ""


def _tool_command(args: dict[str, Any]) -> str:
    for key in ("command", "action", "operation", "mode"):
        value = args.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _normalized_tokens(*values: Any) -> set[str]:
    tokens: set[str] = set()
    for value in values:
        normalized = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value or ""))
        normalized = re.sub(r"([A-Z]+)([A-Z][a-z0-9]+)", r"\1 \2", normalized)
        for token in re.split(r"[^a-z0-9]+", normalized.lower()):
            token = token.strip()
            if token:
                tokens.add(token)
    return tokens


def _schema_property_names(definition: dict[str, Any]) -> list[str]:
    schema = definition.get("schema")
    if not isinstance(schema, dict):
        return []
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return []
    return [str(name) for name in properties.keys()]


def _direct_tool_kind(definition: dict[str, Any], args: dict[str, Any]) -> str | None:
    metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
    native_tool_type = str(metadata.get("native_tool_type") or definition.get("tool_name") or "").strip().lower()
    semantic_class = str(metadata.get("semantic_class") or "").strip().lower()
    tool_name = str(definition.get("tool_name") or "").strip()
    property_names = _schema_property_names(definition)
    arg_tokens = _normalized_tokens(*args.keys())
    property_tokens = _normalized_tokens(*property_names)
    tokens = _normalized_tokens(tool_name, definition.get("docstring") or "", *property_tokens)
    command = _tool_command(args).lower()
    has_mutation = (
        any(token in _MUTATION_HINTS for token in tokens)
        or any(token in _MUTATION_HINTS for token in arg_tokens)
        or command in ANTHROPIC_DIRECT_MUTATING_COMMANDS
    )
    has_record_identifier = (
        any(name in _RECORD_PROPERTY_HINTS for name in property_names)
        or any(str(name).strip().lower() in _RECORD_PROPERTY_HINTS for name in args.keys())
        or any(token in _RECORD_HINTS for token in arg_tokens)
    )
    has_memory_semantics = (
        any(token in _MEMORY_HINTS for token in tokens)
        or any(name in _MEMORY_PROPERTY_HINTS for name in property_names)
    )
    has_message_semantics = (
        any(token in _MESSAGE_HINTS for token in tokens)
        or any(name in _MESSAGE_PROPERTY_HINTS for name in property_names)
    )
    has_internal_semantics = (
        any(token in _INTERNAL_HINTS for token in tokens)
        or any(name in _INTERNAL_PROPERTY_HINTS for name in property_names)
    )

    if semantic_class == "memory_mutation" or (native_tool_type == "memory_20250818" and has_mutation):
        return "memory_write"
    if (
        semantic_class in {"file_mutation", "system_mutation"}
        or native_tool_type.startswith("text_editor_")
        or native_tool_type.startswith("bash_")
    ):
        return "internal_update"
    if has_message_semantics:
        return "external_message_send"
    if (any(token in _RECORD_HINTS for token in tokens) or has_record_identifier) and has_mutation:
        return "record_mutation"
    if has_memory_semantics and (
        has_mutation or any(name in _MEMORY_PROPERTY_HINTS and name not in {"namespace", "key"} for name in property_names)
    ):
        return "memory_write"
    if has_internal_semantics and (
        has_mutation or any(name in _INTERNAL_PROPERTY_HINTS for name in property_names)
    ):
        return "internal_update"
    return None


def _pending_memory_write(tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    args = payload if isinstance(payload, dict) else {}
    return {
        "namespace": args.get("namespace") or tool_name,
        "key": args.get("key") or args.get("id") or args.get("record_id") or args.get("name") or "value",
        "value": args.get("value") or args.get("patch") or args.get("update") or args.get("fields") or args,
        "write_kind": args.get("command") or args.get("action") or args.get("operation") or "write",
    }


def _pending_action(tool_name: str, payload: dict[str, Any], tool_kind: str) -> dict[str, Any]:
    args = payload if isinstance(payload, dict) else {}
    target = (
        args.get("path")
        or args.get("file_path")
        or args.get("workflow_id")
        or args.get("record_id")
        or args.get("customer_id")
        or args.get("ticket_id")
        or args.get("id")
        or args.get("recipient")
        or args.get("email")
        or args.get("channel")
        or args.get("url")
        or tool_name
    )
    return {
        "surface": "tool_dispatch",
        "operation": tool_name,
        "target": str(target),
        "method": "SEND" if tool_kind == "external_message_send" else "CALL",
        "transport_args": dict(args),
        "boundary_kind": "action_execute",
        "action_class": (
            "record_mutation"
            if tool_kind == "record_mutation"
            else "external_message_send"
            if tool_kind == "external_message_send"
            else "system_change"
        ),
        "trust_boundary_crossing": bool(
            args.get("url")
            or args.get("uri")
            or args.get("recipient")
            or args.get("email")
            or args.get("to")
        ),
    }


def _tool_semantic_class(
    *,
    raw_name: str,
    native_tool_type: str,
    args: dict[str, Any],
    provider_event_type: str,
) -> str | None:
    if str(provider_event_type or "").strip().lower() == "server_tool_use":
        mapped = ANTHROPIC_DIRECT_HISTORY_SEMANTICS.get(raw_name)
        if mapped:
            return mapped
        if raw_name == "text_editor_code_execution":
            return "file_mutation"
        if raw_name == "bash_code_execution":
            return "system_mutation"
        return None
    tool_type = str(native_tool_type or "").strip().lower()
    command = _tool_command(args).lower()
    if tool_type == "memory_20250818":
        return "memory_mutation" if command in ANTHROPIC_DIRECT_MUTATING_COMMANDS else "memory_read"
    if tool_type.startswith("text_editor_"):
        return "file_mutation" if command in ANTHROPIC_DIRECT_MUTATING_COMMANDS else "file_read"
    if tool_type.startswith("bash_"):
        return "system_mutation"
    return None


def _tool_read_only(
    *,
    raw_name: str,
    native_tool_type: str,
    args: dict[str, Any],
    provider_event_type: str,
) -> bool:
    semantic_class = _tool_semantic_class(
        raw_name=raw_name,
        native_tool_type=native_tool_type,
        args=args,
        provider_event_type=provider_event_type,
    )
    return semantic_class in ANTHROPIC_DIRECT_RETRIEVAL_CLASSES


def _dispatch_target(tool_name: str, args: dict[str, Any]) -> str:
    if isinstance(args.get("namespace"), str) and isinstance(args.get("key"), str):
        namespace = str(args.get("namespace") or "").strip()
        key = str(args.get("key") or "").strip()
        if namespace and key:
            return f"{namespace}/{key}"
    for key in (
        "path",
        "file_path",
        "url",
        "uri",
        "target",
        "recipient",
        "email",
        "channel",
        "workflow_id",
        "record_id",
        "id",
        "key",
    ):
        value = args.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return tool_name


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items() if key != "parsed_output"}
    for attr in ("model_dump", "to_dict", "dict"):
        fn = getattr(value, attr, None)
        if callable(fn):
            try:
                return _jsonable(fn())
            except TypeError:
                try:
                    return _jsonable(fn(mode="json"))
                except Exception:
                    pass
            except Exception:
                pass
    return str(value)


def _jsonish_object(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return _jsonable(value)
    if isinstance(value, str):
        normalized = value.strip()
        if not normalized:
            return {}
        try:
            parsed = json.loads(normalized)
        except Exception:
            return {"value": normalized}
        if isinstance(parsed, dict):
            return _jsonable(parsed)
        return {"value": _jsonable(parsed)}
    if value is None:
        return {}
    parsed = _jsonable(value)
    if isinstance(parsed, dict):
        return parsed
    return {"value": parsed}


def assistant_message_param(message: Any) -> dict[str, Any]:
    content = getattr(message, "content", None)
    if not isinstance(content, list):
        content = []
    return {
        "role": "assistant",
        "content": [_jsonable(block) for block in content],
    }


def tool_result_block(tool_use_id: str | None, payload: Any) -> dict[str, Any]:
    return {
        "type": "tool_result",
        "tool_use_id": tool_use_id,
        "content": json.dumps(_jsonable(payload)),
    }


def _handler_from_registry(tool_handlers: Any, tool_name: str) -> Callable:
    if isinstance(tool_handlers, dict):
        handler = tool_handlers.get(tool_name)
        if callable(handler):
            return handler
    raise KeyError(f"No Anthropic direct tool handler registered for {tool_name}")


def _execute_sync(value: Any):
    if inspect.isawaitable(value):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(value)
        raise RuntimeError(
            "Anthropic direct async tool handler returned an awaitable inside a running event loop. "
            "Use dispatch_tool_uses_async() in async contexts."
        )
    return value


def _guarded_handler(
    verifiedx,
    *,
    handler: Callable,
    tool_name: str,
    definition: dict[str, Any],
    args: dict[str, Any],
) -> Callable:
    metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
    native_tool_type = str(metadata.get("native_tool_type") or tool_name).strip().lower()
    command = _tool_command(args).lower()
    schema = definition.get("schema")
    docstring = definition.get("docstring")
    tool_kind = _direct_tool_kind(definition, args)

    if native_tool_type == "memory_20250818" and command in ANTHROPIC_DIRECT_MUTATING_COMMANDS:
        return verifiedx.wrap_memory_write(
            handler,
            namespace=lambda payload: str((payload or {}).get("namespace") or tool_name),
            key=lambda payload: str((payload or {}).get("key") or "value"),
            tool_name=tool_name,
            schema=schema,
            docstring=docstring,
        )

    if tool_kind in {"record_mutation", "internal_update", "external_message_send"}:
        return verifiedx.wrap_tool_call(
            handler,
            tool_name=tool_name,
            schema=schema,
            docstring=docstring,
            selection_metadata={
                "raw_name": tool_name,
                "raw_args": dict(args),
                "semantic_class": (
                    "record_mutation"
                    if tool_kind == "record_mutation"
                    else "external_message_send"
                    if tool_kind == "external_message_send"
                    else "system_mutation"
                ),
                "pending_action": _pending_action(tool_name, dict(args), tool_kind),
            },
        )

    if native_tool_type not in ANTHROPIC_DIRECT_TRIGGER_TOOL_TYPES:
        return verifiedx.wrap_tool_call(
            handler,
            tool_name=tool_name,
            schema=schema,
            docstring=docstring,
        )

    return handler


def _dispatch_tool_descriptor(
    *,
    tool_name: str,
    definition: dict[str, Any],
    call: dict[str, Any],
    payload: dict[str, Any],
    pending: dict[str, Any] | None = None,
    semantic_class: str | None = None,
) -> dict[str, Any]:
    definition_metadata = (
        definition.get("metadata")
        if isinstance(definition.get("metadata"), dict)
        else {}
    )
    metadata = {
        **definition_metadata,
        "raw_name": tool_name,
        "raw_args": payload,
        "tool_call_id": call.get("tool_call_id"),
        "provider_event_type": call.get("provider_event_type"),
        "native_call_type": str(definition_metadata.get("native_tool_type") or tool_name),
    }
    if pending is not None:
        metadata["pending_action"] = dict(pending)
    if semantic_class:
        metadata["semantic_class"] = semantic_class
    return {
        "tool_name": tool_name,
        "schema": definition.get("schema") or {"type": "object", "additionalProperties": True},
        "docstring": definition.get("docstring"),
        "args": payload,
        "metadata": metadata,
    }


def _remember_dispatch_tool_selection(
    verifiedx,
    *,
    tool_name: str,
    definition: dict[str, Any],
    call: dict[str, Any],
    payload: dict[str, Any],
    pending: dict[str, Any] | None = None,
    semantic_class: str | None = None,
) -> dict[str, Any]:
    descriptor = _dispatch_tool_descriptor(
        tool_name=tool_name,
        definition=definition,
        call=call,
        payload=payload,
        pending=pending,
        semantic_class=semantic_class,
    )
    try:
        verifiedx.zero_touch.ensure_tool_selection_recorded(
            tool_descriptor=descriptor,
            tool_call_id=call.get("tool_call_id"),
            source=str(call.get("source") or "anthropic.messages.tool_use"),
        )
    except Exception:
        pass
    return descriptor


def create_tool_dispatcher(
    *,
    tool_handlers: dict[str, Callable],
    tools: list[dict[str, Any]],
    verifiedx=None,
    framework_version: str | None = None,
):
    vx = install(verifiedx=verifiedx, framework_version=framework_version)
    tool_definitions = normalize_tool_definitions(tools)
    definitions_by_name = {
        str(item.get("tool_name") or "").strip(): item
        for item in tool_definitions
        if isinstance(item, dict) and str(item.get("tool_name") or "").strip()
    }
    result_mapping = _jsonish_object
    normalize_tool_arguments = _jsonish_object

    def dispatch_tool_uses(message: Any) -> list[dict[str, Any]]:
        calls = normalize_message_tool_calls(
            message,
            result_mapping=result_mapping,
            normalize_tool_arguments=normalize_tool_arguments,
            tool_definitions=tool_definitions,
        )
        results: list[dict[str, Any]] = []
        for call in calls:
            if bool(call.get("provider_executed")):
                continue
            tool_name = str(call.get("raw_name") or "").strip()
            if not tool_name:
                continue
            handler = _handler_from_registry(tool_handlers, tool_name)
            definition = definitions_by_name.get(tool_name) or {
                "tool_name": tool_name,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "metadata": {},
            }
            payload = dict(call.get("raw_args") or {})
            tool_kind = _direct_tool_kind(definition, payload)
            native_pending = describe_pending_action(
                raw_name=tool_name,
                native_tool_type=str(
                    (
                        definition.get("metadata")
                        if isinstance(definition.get("metadata"), dict)
                        else {}
                    ).get("native_tool_type")
                    or tool_name
                ),
                provider_event_type=str(call.get("provider_event_type") or ""),
                args=payload,
                command=_tool_command(payload),
                dispatch_target=lambda current_name, current_args: _dispatch_target(current_name, current_args),
            )
            try:
                if tool_kind == "memory_write":
                    pending = _pending_memory_write(tool_name, payload)
                    namespace = str(pending.get("namespace") or tool_name)
                    key = str(pending.get("key") or "value")
                    selection_pending = {
                        "surface": "memory_write",
                        "operation": tool_name,
                        "target": f"{namespace}/{key}",
                        "method": "WRITE",
                        "transport_args": pending,
                        "boundary_kind": "memory_write",
                        "action_class": "memory_write",
                        "trust_boundary_crossing": False,
                    }
                    tool_descriptor = _remember_dispatch_tool_selection(
                        vx,
                        tool_name=tool_name,
                        definition=definition,
                        call=call,
                        payload=payload,
                        pending=selection_pending,
                        semantic_class="memory_write",
                    )
                    result = vx.zero_touch.intercept_boundary(
                        surface="memory_write",
                        operation=tool_name,
                        target=f"{namespace}/{key}",
                        method="WRITE",
                        transport_args=pending,
                        boundary_kind="memory_write",
                        action_class="memory_write",
                        trust_boundary_crossing=False,
                        pending_effect=pending,
                        tool_descriptor=tool_descriptor,
                        execute=lambda: _execute_sync(handler(payload)),
                    )
                else:
                    if tool_kind in {"record_mutation", "internal_update", "external_message_send"}:
                        pending = _pending_action(tool_name, payload, tool_kind)
                        action_class = str(pending.get("action_class") or "system_change")
                    elif native_pending is not None:
                        pending = {
                            "surface": str(native_pending.get("surface") or "tool_dispatch"),
                            "operation": str(native_pending.get("operation") or tool_name),
                            "target": str(native_pending.get("target") or tool_name),
                            "method": str(native_pending.get("method") or "CALL"),
                            "transport_args": dict(
                                native_pending.get("raw_args")
                                if isinstance(native_pending.get("raw_args"), dict)
                                else native_pending.get("transport_args")
                                if isinstance(native_pending.get("transport_args"), dict)
                                else payload
                            ),
                            "boundary_kind": str(native_pending.get("boundary_kind") or "action_execute"),
                            "action_class": str(native_pending.get("action_class") or "system_change"),
                            "trust_boundary_crossing": bool(native_pending.get("trust_boundary_crossing")),
                        }
                        action_class = str(pending.get("action_class") or "system_change")
                    else:
                        pending = None
                        action_class = None

                    tool_descriptor = _remember_dispatch_tool_selection(
                        vx,
                        tool_name=tool_name,
                        definition=definition,
                        call=call,
                        payload=payload,
                        pending=pending,
                        semantic_class=action_class,
                    )
                    if pending is not None:
                        result = vx.zero_touch.intercept_boundary(
                            surface=str(pending.get("surface") or "tool_dispatch"),
                            operation=str(pending.get("operation") or tool_name),
                            target=str(pending.get("target") or tool_name),
                            method=str(pending.get("method") or "CALL"),
                            transport_args=dict(pending.get("transport_args") or payload),
                            boundary_kind=str(pending.get("boundary_kind") or "action_execute"),
                            action_class=action_class,
                            trust_boundary_crossing=bool(pending.get("trust_boundary_crossing")),
                            pending_effect=dict(pending.get("transport_args") or payload),
                            tool_descriptor=tool_descriptor,
                            execute=lambda: _execute_sync(handler(payload)),
                        )
                    else:
                        guarded = _guarded_handler(
                            vx,
                            handler=handler,
                            tool_name=tool_name,
                            definition=definition,
                            args=payload,
                        )
                        result = _execute_sync(guarded(payload))
            except Exception as error:
                handled = vx.handle_runtime_tool_error(error)
                if handled is None:
                    raise
                result = handled
            results.append(tool_result_block(call.get("tool_call_id"), result))
        return results

    async def dispatch_tool_uses_async(message: Any) -> list[dict[str, Any]]:
        calls = normalize_message_tool_calls(
            message,
            result_mapping=result_mapping,
            normalize_tool_arguments=normalize_tool_arguments,
            tool_definitions=tool_definitions,
        )
        results: list[dict[str, Any]] = []
        for call in calls:
            if bool(call.get("provider_executed")):
                continue
            tool_name = str(call.get("raw_name") or "").strip()
            if not tool_name:
                continue
            handler = _handler_from_registry(tool_handlers, tool_name)
            definition = definitions_by_name.get(tool_name) or {
                "tool_name": tool_name,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "metadata": {},
            }
            payload = dict(call.get("raw_args") or {})
            tool_kind = _direct_tool_kind(definition, payload)
            native_pending = describe_pending_action(
                raw_name=tool_name,
                native_tool_type=str(
                    (
                        definition.get("metadata")
                        if isinstance(definition.get("metadata"), dict)
                        else {}
                    ).get("native_tool_type")
                    or tool_name
                ),
                provider_event_type=str(call.get("provider_event_type") or ""),
                args=payload,
                command=_tool_command(payload),
                dispatch_target=lambda current_name, current_args: _dispatch_target(current_name, current_args),
            )
            try:
                if tool_kind == "memory_write":
                    pending = _pending_memory_write(tool_name, payload)
                    namespace = str(pending.get("namespace") or tool_name)
                    key = str(pending.get("key") or "value")
                    selection_pending = {
                        "surface": "memory_write",
                        "operation": tool_name,
                        "target": f"{namespace}/{key}",
                        "method": "WRITE",
                        "transport_args": pending,
                        "boundary_kind": "memory_write",
                        "action_class": "memory_write",
                        "trust_boundary_crossing": False,
                    }
                    tool_descriptor = _remember_dispatch_tool_selection(
                        vx,
                        tool_name=tool_name,
                        definition=definition,
                        call=call,
                        payload=payload,
                        pending=selection_pending,
                        semantic_class="memory_write",
                    )

                    async def execute_memory():
                        value = handler(payload)
                        if inspect.isawaitable(value):
                            return await value
                        return value

                    result = await vx.zero_touch.intercept_boundary_async(
                        surface="memory_write",
                        operation=tool_name,
                        target=f"{namespace}/{key}",
                        method="WRITE",
                        transport_args=pending,
                        boundary_kind="memory_write",
                        action_class="memory_write",
                        trust_boundary_crossing=False,
                        pending_effect=pending,
                        tool_descriptor=tool_descriptor,
                        execute=execute_memory,
                    )
                else:
                    if tool_kind in {"record_mutation", "internal_update", "external_message_send"}:
                        pending = _pending_action(tool_name, payload, tool_kind)
                        action_class = str(pending.get("action_class") or "system_change")
                    elif native_pending is not None:
                        pending = {
                            "surface": str(native_pending.get("surface") or "tool_dispatch"),
                            "operation": str(native_pending.get("operation") or tool_name),
                            "target": str(native_pending.get("target") or tool_name),
                            "method": str(native_pending.get("method") or "CALL"),
                            "transport_args": dict(
                                native_pending.get("raw_args")
                                if isinstance(native_pending.get("raw_args"), dict)
                                else native_pending.get("transport_args")
                                if isinstance(native_pending.get("transport_args"), dict)
                                else payload
                            ),
                            "boundary_kind": str(native_pending.get("boundary_kind") or "action_execute"),
                            "action_class": str(native_pending.get("action_class") or "system_change"),
                            "trust_boundary_crossing": bool(native_pending.get("trust_boundary_crossing")),
                        }
                        action_class = str(pending.get("action_class") or "system_change")
                    else:
                        pending = None
                        action_class = None

                    tool_descriptor = _remember_dispatch_tool_selection(
                        vx,
                        tool_name=tool_name,
                        definition=definition,
                        call=call,
                        payload=payload,
                        pending=pending,
                        semantic_class=action_class,
                    )
                    if pending is not None:
                        async def execute_action():
                            value = handler(payload)
                            if inspect.isawaitable(value):
                                return await value
                            return value

                        result = await vx.zero_touch.intercept_boundary_async(
                            surface=str(pending.get("surface") or "tool_dispatch"),
                            operation=str(pending.get("operation") or tool_name),
                            target=str(pending.get("target") or tool_name),
                            method=str(pending.get("method") or "CALL"),
                            transport_args=dict(pending.get("transport_args") or payload),
                            boundary_kind=str(pending.get("boundary_kind") or "action_execute"),
                            action_class=action_class,
                            trust_boundary_crossing=bool(pending.get("trust_boundary_crossing")),
                            pending_effect=dict(pending.get("transport_args") or payload),
                            tool_descriptor=tool_descriptor,
                            execute=execute_action,
                        )
                    else:
                        guarded = _guarded_handler(
                            vx,
                            handler=handler,
                            tool_name=tool_name,
                            definition=definition,
                            args=payload,
                        )
                        result = guarded(payload)
                        if inspect.isawaitable(result):
                            result = await result
            except Exception as error:
                handled = vx.handle_runtime_tool_error(error)
                if handled is None:
                    raise
                result = handled
            results.append(tool_result_block(call.get("tool_call_id"), result))
        return results

    dispatch_tool_uses.async_dispatch = dispatch_tool_uses_async  # type: ignore[attr-defined]
    return dispatch_tool_uses
