from __future__ import annotations

import asyncio
import builtins
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import asdict, dataclass, field, is_dataclass
from datetime import datetime, timezone
import functools
import gzip
import hashlib
import inspect
import json
import pathlib
import re
import shlex
import threading
from typing import Any
from urllib import parse as urllib_parse
from urllib import request as urllib_request

from .errors import BoundaryDeniedError
from .openai_direct import (
    OPENAI_DIRECT_TRIGGER_ITEM_TYPES,
    OPENAI_RESPONSES_COMMAND_TYPES,
    OPENAI_RESPONSES_OUTPUT_TYPES,
    case_thread_hint as _openai_direct_case_thread_hint,
    describe_pending_action as _openai_direct_pending_action,
    extract_prompt_messages as _openai_direct_prompt_messages,
    is_chat_continuation as _openai_direct_is_chat_continuation,
    normalize_chat_completion_tool_calls as _openai_direct_chat_completion_tool_calls,
    normalize_responses_request as _openai_direct_normalize_responses_request,
    normalize_responses_tool_calls as _openai_direct_responses_tool_calls,
)
from .anthropic_direct import (
    ANTHROPIC_DIRECT_ADAPTER_KIND,
    assistant_text as _anthropic_direct_assistant_text,
    describe_pending_action as _anthropic_direct_pending_action,
    extract_prompt_messages as _anthropic_direct_prompt_messages,
    normalize_message_tool_calls as _anthropic_direct_message_tool_calls,
    normalize_tool_definitions as _anthropic_direct_tool_definitions,
    requires_direct_boundary as _anthropic_direct_requires_direct_boundary,
)


_SUPPRESS_RUNTIME_CAPTURE: ContextVar[int] = ContextVar(
    "verifiedx_suppress_runtime_capture",
    default=0,
)
_CURRENT_TOOL_INVOCATION: ContextVar["ToolInvocationContext | None"] = ContextVar(
    "verifiedx_current_tool_invocation",
    default=None,
)
_DEFAULT_INSTALLER: "ZeroTouchRuntimeInstaller | None" = None
_PATCH_MARKER_PREFIX = "__verifiedx_zero_touch_patch__"
_UNCONSUMED_PREFLIGHT_REUSE_WINDOW_SECONDS = 120.0
_SQL_MUTATION_PREFIXES = {
    "alter",
    "create",
    "delete",
    "drop",
    "insert",
    "merge",
    "replace",
    "truncate",
    "update",
    "upsert",
}
_SQL_TARGET_PATTERNS = (
    re.compile(r"\bupdate\s+([a-zA-Z0-9_.\"]+)", re.IGNORECASE),
    re.compile(r"\binto\s+([a-zA-Z0-9_.\"]+)", re.IGNORECASE),
    re.compile(r"\btable\s+([a-zA-Z0-9_.\"]+)", re.IGNORECASE),
)
_SQL_BOOKKEEPING_TARGET_HINTS = {
    "checkpoint",
    "checkpoints",
    "heartbeat",
    "heartbeats",
    "metric",
    "metrics",
    "run",
    "runs",
    "step",
    "steps",
    "telemetry",
    "trace",
    "traces",
}
_MEMORY_TOOL_HINTS = {
    "context",
    "fact",
    "facts",
    "journal",
    "memory",
    "memo",
    "note",
    "notes",
    "preference",
    "preferences",
    "scratch",
    "scratchpad",
    "remember",
    "summary",
    "summaries",
    "state",
}
_TERMINAL_TOOL_HINTS = {
    "bash",
    "cmd",
    "command",
    "execute",
    "shell",
    "terminal",
}
_TERMINAL_CONTROL_INPUTS = {
    "c-c",
    "c-d",
    "c-z",
    "ctrl-c",
    "ctrl-d",
    "ctrl-z",
}
_MEMORY_SQL_PARAMETER_HINTS = {
    "bio",
    "fact",
    "facts",
    "memory",
    "memo",
    "note",
    "notes",
    "preference",
    "preferences",
    "state",
    "summary",
    "value",
    "values",
}
_RETRIEVAL_TOOL_HINTS = {
    "context",
    "describe",
    "discover",
    "fetch",
    "find",
    "get",
    "glossary",
    "inspect",
    "list",
    "load",
    "lookup",
    "query",
    "read",
    "retrieve",
    "search",
    "show",
    "view",
}
_MUTATING_TOOL_HINTS = {
    "apply",
    "append",
    "archive",
    "approve",
    "assign",
    "call",
    "cancel",
    "change",
    "close",
    "create",
    "delete",
    "disable",
    "dispatch",
    "edit",
    "email",
    "enable",
    "enqueue",
    "escalate",
    "execute",
    "merge",
    "mutate",
    "notify",
    "patch",
    "persist",
    "post",
    "publish",
    "reply",
    "remember",
    "reroute",
    "route",
    "run",
    "save",
    "send",
    "set",
    "store",
    "submit",
    "sync",
    "trigger",
    "update",
    "upsert",
    "write",
}
_INTERNAL_UPDATE_TOOL_HINTS = {
    "assignment",
    "checkpoint",
    "config",
    "configuration",
    "context",
    "draft",
    "flag",
    "instruction",
    "instructions",
    "metadata",
    "policy",
    "preference",
    "preferences",
    "queue",
    "queues",
    "route",
    "routing",
    "rule",
    "rules",
    "profile",
    "setting",
    "settings",
    "state",
    "status",
    "thread",
    "threads",
    "workflow",
    "workflows",
}
_EXTERNAL_INGRESS_HINT_TOKENS = {
    "bing",
    "browser",
    "browse",
    "external",
    "google",
    "http",
    "https",
    "internet",
    "news",
    "public",
    "site",
    "url",
    "web",
    "website",
    "wikipedia",
}
_INTERNAL_RETRIEVAL_INGRESS_HINT_TOKENS = _RETRIEVAL_TOOL_HINTS | {
    "customer",
    "customers",
    "doc",
    "docs",
    "document",
    "documents",
    "file",
    "files",
    "glob",
    "grep",
    "internal",
    "kb",
    "knowledge",
    "memory",
    "policy",
    "policies",
    "profile",
    "profiles",
    "repo",
    "repository",
    "workspace",
    "workflow",
    "workflows",
}
_OPENAI_DIRECT_TOOL_TYPES = set(OPENAI_DIRECT_TRIGGER_ITEM_TYPES)
_RETRIEVAL_ARGUMENT_HINTS = {
    "account_id",
    "case_id",
    "conversation_id",
    "customer_id",
    "email",
    "entity_id",
    "filter",
    "id",
    "issue_id",
    "issue_number",
    "key",
    "limit",
    "message_id",
    "namespace",
    "offset",
    "page",
    "pr_id",
    "pr_number",
    "query",
    "record_id",
    "reservation_id",
    "search",
    "session_id",
    "target",
    "thread_id",
    "ticket_id",
    "url",
}
_MUTATING_ARGUMENT_HINTS = {
    "assignee",
    "approval",
    "body",
    "changes",
    "comment",
    "config",
    "configuration",
    "content",
    "enabled",
    "field_value",
    "fields",
    "message",
    "metadata",
    "note",
    "operation",
    "patch",
    "payload",
    "priority",
    "reason",
    "recipient",
    "rule",
    "rules",
    "set",
    "stage",
    "state",
    "status",
    "subject",
    "tier",
    "update",
    "value",
}
_MEMORY_ARGUMENT_HINTS = {
    "fact",
    "facts",
    "key",
    "memory",
    "memo",
    "namespace",
    "note",
    "notes",
    "preference",
    "preferences",
    "summary",
    "value",
}
_RECORD_ENTITY_HINTS = {
    "account",
    "accounts",
    "application",
    "applications",
    "asset",
    "assets",
    "booking",
    "bookings",
    "case",
    "cases",
    "claim",
    "claims",
    "contact",
    "contacts",
    "contract",
    "contracts",
    "customer",
    "customers",
    "device",
    "devices",
    "entitlement",
    "entitlements",
    "incident",
    "incidents",
    "invoice",
    "invoices",
    "issue",
    "issues",
    "lead",
    "leads",
    "opportunity",
    "opportunities",
    "order",
    "orders",
    "policy",
    "policies",
    "profile",
    "profiles",
    "record",
    "records",
    "reservation",
    "reservations",
    "subscription",
    "subscriptions",
    "task",
    "tasks",
    "ticket",
    "tickets",
    "user",
    "users",
}
_RECORD_MUTATION_ARGUMENT_HINTS = {
    "assignee",
    "field_name",
    "field_value",
    "fields",
    "owner",
    "patch",
    "priority",
    "stage",
    "state",
    "status",
    "tier",
    "update",
}
_INTERNAL_UPDATE_ARGUMENT_HINTS = {
    "config",
    "configuration",
    "enabled",
    "flag",
    "flags",
    "metadata",
    "mode",
    "policy",
    "route",
    "routing",
    "rule",
    "rules",
    "setting",
    "settings",
    "stage",
    "state",
    "status",
    "value",
    "workflow_id",
}
_COMMUNICATION_TOOL_HINTS = {
    "alert",
    "body",
    "channel",
    "chat",
    "comment",
    "conversation",
    "dm",
    "email",
    "mail",
    "message",
    "messages",
    "notify",
    "notification",
    "post",
    "recipient",
    "reply",
    "send",
    "slack",
    "subject",
    "teams",
    "text",
    "thread",
}
_COMMUNICATION_ARGUMENT_HINTS = {
    "address",
    "bcc",
    "body",
    "cc",
    "channel",
    "channel_id",
    "comment",
    "content",
    "conversation_id",
    "dm",
    "email",
    "message",
    "note",
    "recipient",
    "recipient_id",
    "reply",
    "subject",
    "text",
    "thread_id",
    "to",
    "user_id",
}
_MESSAGE_HOST_HINTS = {
    "discord",
    "email",
    "gmail",
    "graph",
    "mail",
    "mailgun",
    "outlook",
    "postmark",
    "sendgrid",
    "ses",
    "slack",
    "smtp",
    "teams",
}
_INTERNAL_MESSAGE_HINTS = {
    "chat",
    "channel",
    "comment",
    "conversation",
    "dm",
    "internal",
    "note",
    "reply",
    "slack",
    "teams",
    "thread",
}
_HTTP_MEMORY_TARGET_HINTS = {
    "context",
    "memory",
    "memo",
    "note",
    "notes",
    "preference",
    "preferences",
    "state",
}
_HTTP_INTERNAL_TARGET_HINTS = {
    "assignment",
    "checkpoint",
    "config",
    "configuration",
    "flag",
    "flags",
    "metadata",
    "policy",
    "queue",
    "queues",
    "route",
    "routing",
    "rule",
    "rules",
    "setting",
    "settings",
    "stage",
    "state",
    "status",
    "workflow",
    "workflows",
}
_RETRIEVAL_RESPONSE_MAX_CHARS = 16384
_CLIENT_GZIP_MIN_BYTES = 8192
_SQL_RUNTIME_ARTIFACT_TARGET_HINTS = {
    "agent",
    "agents",
    "assistant",
    "assistants",
    "chat",
    "chats",
    "conversation",
    "conversations",
    "event",
    "events",
    "message",
    "messages",
    "response",
    "responses",
    "session",
    "sessions",
    "thread",
    "threads",
}
_SQL_ASSISTANT_MESSAGE_TARGET_HINTS = {
    "comment",
    "comments",
    "conversation",
    "conversations",
    "email",
    "emails",
    "event",
    "events",
    "log",
    "logs",
    "message",
    "messages",
    "note",
    "notes",
    "reply",
    "replies",
    "response",
    "responses",
}
_FILE_ASSISTANT_MESSAGE_TARGET_HINTS = {
    "comment",
    "comments",
    "email",
    "emails",
    "message",
    "messages",
    "outbound",
    "outbox",
    "reply",
    "replies",
    "response",
    "responses",
}
_ASSISTANT_MESSAGE_TARGET_CONTAINERS = (
    "sessions",
    "threads",
    "conversations",
    "chats",
    "tickets",
    "issues",
    "prs",
    "pull_requests",
    "events",
    "messages",
    "comments",
    "replies",
    "responses",
    "notes",
    "transcripts",
    "records",
)
_ASSISTANT_MESSAGE_TARGET_ID_KEYS = (
    "session_id",
    "thread_id",
    "conversation_id",
    "chat_id",
    "ticket_id",
    "issue_id",
    "pr_id",
    "message_id",
    "comment_id",
    "id",
)
_MEMORY_SQL_TARGET_HINTS = {
    "block",
    "blocks",
    "context",
    "memory",
    "memo",
    "note",
    "notes",
    "preference",
    "preferences",
    "profile",
    "state",
}
_EMAIL_PATTERN = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_CASE_ID_PATTERN = re.compile(r"\b[A-Z]{2,}-\d+\b")
_OMITTED_SENTINEL_NAMES = {
    "omit",
    "notgiven",
    "notprovided",
    "notset",
    "undefined",
    "unset",
    "missing",
}
_OMITTED_SENTINEL_MODULE_ROOTS = {
    "agents",
    "anthropic",
    "cerebras",
    "cohere",
    "fireworks",
    "google",
    "groq",
    "litellm",
    "mistralai",
    "ollama",
    "openai",
    "together",
    "vertexai",
}


def _is_omitted_sentinel(value: Any) -> bool:
    if value is None:
        return False
    cls = type(value)
    class_name = "".join(ch for ch in getattr(cls, "__name__", "").lower() if ch.isalnum())
    if class_name not in _OMITTED_SENTINEL_NAMES:
        return False
    module = str(getattr(cls, "__module__", "") or "").lower()
    if not module or module == "builtins":
        return False
    return module.split(".", 1)[0] in _OMITTED_SENTINEL_MODULE_ROOTS


def _jsonable(value: Any) -> Any:
    if _is_omitted_sentinel(value):
        return None
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        normalized: dict[str, Any] = {}
        for key, item in value.items():
            if _is_omitted_sentinel(item):
                continue
            normalized[str(key)] = _jsonable(item)
        return normalized
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value if not _is_omitted_sentinel(item)]
    if inspect.isclass(value):
        qualname = f"{getattr(value, '__module__', '')}.{getattr(value, '__qualname__', getattr(value, '__name__', str(value)))}".strip(
            "."
        )
        schema_fn = getattr(value, "model_json_schema", None)
        if callable(schema_fn):
            try:
                return {
                    "python_type": "class",
                    "qualname": qualname,
                    "json_schema": _jsonable(schema_fn()),
                }
            except Exception:
                pass
        schema_fn = getattr(value, "schema", None)
        if callable(schema_fn):
            try:
                return {
                    "python_type": "class",
                    "qualname": qualname,
                    "json_schema": _jsonable(schema_fn()),
                }
            except Exception:
                pass
        return {"python_type": "class", "qualname": qualname}
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except TypeError:
            return _jsonable(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _jsonable(value.dict())
    if hasattr(value, "json") and callable(value.json):
        try:
            return json.loads(value.json())
        except Exception:
            return str(value)
    return str(value)


def _hash_json(value: Any) -> str:
    encoded = json.dumps(
        _jsonable(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _stable_surface(surface: Any) -> str:
    normalized = str(surface or "").strip()
    if normalized == "memory_write":
        return "memory_write"
    if normalized in {"http", "browser", "db", "file", "queue", "tool"}:
        return normalized
    return "tool"


def _pending_action_fingerprint_from_observed_boundary(
    observed_boundary: dict[str, Any] | None,
) -> str | None:
    if not isinstance(observed_boundary, dict):
        return None
    downstream_trace = observed_boundary.get("downstream_trace") or {}
    tool_descriptor = observed_boundary.get("tool") or {}
    return _hash_json(
        {
            "raw_name": tool_descriptor.get("tool_name")
            or downstream_trace.get("operation")
            or "unknown",
            "surface": _stable_surface(downstream_trace.get("surface")),
            "method": downstream_trace.get("method"),
            "target": downstream_trace.get("target") or "",
            "raw_args": downstream_trace.get("args") or {},
            "trust_boundary_crossing": bool(
                downstream_trace.get("trust_boundary_crossing", False)
            ),
        }
    )


def _pending_action_fingerprint_from_decision_context(
    decision_context: dict[str, Any] | None,
) -> str | None:
    if not isinstance(decision_context, dict):
        return None
    pending_action = decision_context.get("pending_action")
    if not isinstance(pending_action, dict):
        return None
    return _hash_json(pending_action)


_CAPTURE_SOURCE_PRECEDENCE = {
    "assistant_output_fallback": 0,
    "otel": 1,
    "runtime_patch": 2,
    "wrapper": 3,
}
_CONVERSATION_MERGE_WINDOW_SECONDS = 5.0
_CROSS_SCOPE_ASSOCIATION_WINDOW_SECONDS = 30.0


def _capture_source_rank(source: str | None) -> int:
    return _CAPTURE_SOURCE_PRECEDENCE.get(str(source or "").strip().lower(), -1)


def _conversation_entry_rank(entry: dict[str, Any] | None) -> tuple[int, int, float]:
    if not isinstance(entry, dict):
        return (-1, -1, float("-inf"))
    supported_adapter = 1 if bool(entry.get("supported_adapter")) else 0
    source_rank = _capture_source_rank(entry.get("capture_source_kind"))
    captured_at_unix = float(entry.get("captured_at_unix") or 0.0)
    return (supported_adapter, source_rank, captured_at_unix)


def _has_capture_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def _merge_unique_list(existing: list[Any] | None, incoming: list[Any] | None) -> list[Any]:
    merged: list[Any] = []
    seen: set[str] = set()
    for candidate in [*(existing or []), *(incoming or [])]:
        marker = _hash_json(candidate)
        if marker in seen:
            continue
        seen.add(marker)
        merged.append(candidate)
    return merged


def _merge_mapping(
    existing: dict[str, Any] | None,
    incoming: dict[str, Any] | None,
    *,
    existing_rank: int,
    incoming_rank: int,
) -> dict[str, Any]:
    existing_mapping = _jsonable(existing or {})
    incoming_mapping = _jsonable(incoming or {})
    if not existing_mapping:
        return incoming_mapping
    if not incoming_mapping:
        return existing_mapping
    preferred, fallback = (
        (incoming_mapping, existing_mapping)
        if incoming_rank > existing_rank
        else (existing_mapping, incoming_mapping)
    )
    merged = dict(preferred)
    for key, value in fallback.items():
        if key not in merged or not _has_capture_value(merged.get(key)):
            merged[key] = value
    return merged


def _merge_scalar(
    existing: Any,
    incoming: Any,
    *,
    existing_rank: int,
    incoming_rank: int,
) -> Any:
    if not _has_capture_value(existing):
        return incoming
    if not _has_capture_value(incoming):
        return existing
    if incoming_rank > existing_rank:
        return incoming
    return existing


def _conversation_merge_key(
    *,
    run_id: str,
    messages: list[dict[str, Any]],
    model_name: str | None,
    request_kind: str,
    tool_choice: Any,
    tool_definitions: list[dict[str, Any]],
    tool_call_ids: list[str],
) -> str:
    prompt_frame_hash = _hash_json(
        [
            {
                "role": message.get("role"),
                "content": message.get("content"),
                "message_id": message.get("message_id"),
            }
            for message in messages[-24:]
        ]
    )
    normalized_definitions = sorted(_tool_definitions_by_name(tool_definitions).keys())
    return _hash_json(
        {
            "run_id": run_id,
            "prompt_frame_hash": prompt_frame_hash,
            "model_name": model_name,
            "request_kind": _canonical_request_kind(request_kind),
            "tool_choice": _jsonable(tool_choice),
            "tool_definitions": normalized_definitions,
            "tool_call_ids": sorted(dict.fromkeys(str(item) for item in tool_call_ids if item)),
        }
    )


def _canonical_request_kind(request_kind: str | None) -> str:
    normalized = str(request_kind or "messages").strip().lower()
    if any(token in normalized for token in ("response", "responses")):
        return "responses"
    if any(token in normalized for token in ("chat", "message", "messages", "completion", "completions")):
        return "messages"
    return normalized or "messages"


def _result_mapping(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        return value
    if is_dataclass(value):
        try:
            mapped = asdict(value)
        except Exception:
            mapped = None
        if isinstance(mapped, dict):
            return mapped
    if hasattr(value, "model_dump"):
        try:
            mapped = value.model_dump(mode="json")
        except TypeError:
            mapped = value.model_dump()
        if isinstance(mapped, dict):
            return mapped
    if hasattr(value, "dict") and callable(value.dict):
        try:
            mapped = value.dict()
        except Exception:
            mapped = None
        if isinstance(mapped, dict):
            return mapped
    return None


def _excerpt(value: Any, *, limit: int = 1200) -> str | None:
    if limit <= 0:
        return None
    if isinstance(value, str):
        return value[:limit]
    if isinstance(value, dict):
        for key in ("content", "text", "message", "body", "summary", "snippet", "note"):
            nested = _excerpt(value.get(key), limit=limit)
            if nested:
                return nested
        return _excerpt(json.dumps(_jsonable(value), sort_keys=True), limit=limit)
    if isinstance(value, list) and value:
        return _excerpt(value[0], limit=limit)
    return None


def _content_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        for key in ("text", "content", "message", "body", "value"):
            if key in content:
                nested = _content_text(content.get(key))
                if nested:
                    return nested
        return json.dumps(_jsonable(content), sort_keys=True)
    if isinstance(content, (list, tuple)):
        parts = [_content_text(item) for item in content]
        return " ".join(part for part in parts if part).strip()
    return str(content)


def _normalized_field_key(raw: str) -> str:
    return "_".join(token for token in re.split(r"[^a-z0-9]+", raw.strip().lower()) if token)


def _normalized_identifier_tokens(value: Any) -> set[str]:
    if value is None:
        return set()
    return {
        token
        for token in re.split(r"[^a-z0-9]+", str(value).strip().lower())
        if token
    }


def _extract_structured_fields(content: str) -> dict[str, Any]:
    fields: dict[str, Any] = {}
    active_key: str | None = None
    active_lines: list[str] = []
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line:
            if active_key is not None and active_lines:
                active_lines.append("")
            continue
        if ":" in line:
            key_part, value_part = line.split(":", 1)
            normalized_key = _normalized_field_key(key_part)
            if normalized_key:
                if active_key is not None:
                    fields[active_key] = "\n".join(active_lines).strip()
                active_key = normalized_key
                value = value_part.strip()
                active_lines = [value] if value else []
                continue
        if active_key is not None:
            active_lines.append(line)
    if active_key is not None:
        fields[active_key] = "\n".join(active_lines).strip()
    return {key: value for key, value in fields.items() if value}


def _prompt_context_object(installer: "ZeroTouchRuntimeInstaller", message: dict[str, Any], *, source: str, index: int) -> dict[str, Any]:
    content = _content_text(message.get("content"))
    normalized_payload: dict[str, Any] = {
        "message_id": str(message.get("message_id") or message.get("id") or f"msg_{index}"),
        "role": str(message.get("role") or "unknown"),
        "content": content,
        "source": source,
        "lines": [line.strip() for line in content.splitlines() if line.strip()][:32],
    }
    structured_fields = _extract_structured_fields(content)
    if structured_fields:
        normalized_payload["structured_fields"] = structured_fields
    emails = sorted(dict.fromkeys(match.group(0) for match in _EMAIL_PATTERN.finditer(content)))
    if emails:
        normalized_payload["emails"] = emails
    case_ids = sorted(dict.fromkeys(match.group(0) for match in _CASE_ID_PATTERN.finditer(content)))
    if case_ids:
        normalized_payload["case_ids"] = case_ids
    object_id = "obj_prompt_" + hashlib.sha256(
        json.dumps(
            {
                "source": source,
                "index": index,
                "role": normalized_payload["role"],
                "content": content,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()[:24]
    source_prefix = source.split(".", 1)[0] if source else installer.verifiedx.config.source_system
    return installer.verifiedx.capture.build_object(
        "observation",
        normalized_payload,
        object_id=object_id,
        source_lineage=[source_prefix, "prompt_frame"],
        observability_quality="complete",
    )


def _remember_prompt_context(
    installer: "ZeroTouchRuntimeInstaller",
    object_payload: dict[str, Any],
    *,
    source: str,
    role: str,
    message_id: str,
):
    if role != "user":
        installer.verifiedx.capture.remember_observed_object(object_payload, kind="context_ingress")
        return
    object_id = str(object_payload.get("object_id") or "")
    if object_id and object_id in installer._taint_checked_prompt_object_ids:
        installer.verifiedx.capture.remember_observed_object(object_payload, kind="context_ingress")
        return
    if object_id:
        installer._taint_checked_prompt_object_ids.add(object_id)
    if installer.verifiedx.config.direct_ingress_labeling:
        if _running_loop_or_none() is not None:
            installer.verifiedx.capture.remember_observed_object(object_payload, kind="context_ingress")
            installer.defer_ingress_observation(
                object_payload=object_payload,
                phase=f"{source}_prompt_context",
                source_uri=f"prompt://{source}/{message_id}",
                source_hint=f"{source}:{role}",
            )
            return
        try:
            diagnostic = installer.verifiedx.observe_runtime_ingress(
                object_payload,
                source_uri=f"prompt://{source}/{message_id}",
                source_hint=f"{source}:{role}",
            )
            if diagnostic is not None:
                request_payload, response = diagnostic
                installer.verifiedx.record_ingress_diagnostic(
                    f"{source}_prompt_context",
                    request_payload,
                    response,
                )
                return
        except Exception:
            if installer.verifiedx.config.strict_direct_ingress_labeling:
                raise
    installer.verifiedx.capture.remember_observed_object(object_payload, kind="context_ingress")


def _assistant_output_object(
    installer: "ZeroTouchRuntimeInstaller",
    *,
    content: str,
    source: str,
    target: str | None = None,
    metadata: dict[str, Any] | None = None,
    lineage_label: str = "assistant_output",
) -> dict[str, Any]:
    normalized_payload: dict[str, Any] = {
        "role": "assistant",
        "content": content,
        "message": content,
        "source": source,
        "lines": [line.strip() for line in content.splitlines() if line.strip()][:32],
    }
    if target:
        normalized_payload["target"] = target
    if metadata:
        normalized_payload["metadata"] = _jsonable(metadata)
    object_id = "obj_assistant_" + hashlib.sha256(
        json.dumps(
            {
                "source": source,
                "content": content,
                "target": target,
                "metadata": _jsonable(metadata or {}),
                "lineage_label": lineage_label,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()[:24]
    source_prefix = source.split(".", 1)[0] if source else installer.verifiedx.config.source_system
    return installer.verifiedx.capture.build_object(
        "observation",
        normalized_payload,
        object_id=object_id,
        source_lineage=[source_prefix, lineage_label],
        observability_quality="complete",
    )


def _remember_runtime_support_object(
    installer: "ZeroTouchRuntimeInstaller",
    object_payload: dict[str, Any],
) -> None:
    installer.verifiedx.capture.remember_observed_object(object_payload, kind="context_ingress")


def _scalar_text_fragments(value: Any, *, limit: int = 48) -> list[str]:
    fragments: list[str] = []

    def _walk(item: Any) -> None:
        if item is None:
            return
        if isinstance(item, str):
            normalized = item.strip()
            if normalized:
                fragments.append(normalized[:240])
            return
        if isinstance(item, dict):
            for nested in item.values():
                _walk(nested)
            return
        if isinstance(item, (list, tuple, set)):
            for nested in item:
                _walk(nested)

    _walk(value)
    deduped: list[str] = []
    seen: set[str] = set()
    for fragment in fragments:
        key = fragment.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(fragment)
        if len(deduped) >= limit:
            break
    return deduped


def _recent_object_reference(entry: dict[str, Any]) -> dict[str, Any] | None:
    object_id = entry.get("object_id")
    if not object_id:
        return None
    return {
        "object_id": object_id,
        "object_type": entry.get("object_type") or "summary",
        "summary": _excerpt(entry.get("normalized_payload")),
        "source_lineage": entry.get("source_lineage") or [],
        "freshness": entry.get("freshness") or "fresh",
        "observability_quality": entry.get("observability_quality") or "partial",
        "trust_tier": entry.get("trust_tier"),
        "taint_labels": list(entry.get("taint_labels") or []),
        "binding_status": entry.get("binding_status") or "bound_to_evidence",
        "normalized_payload": _jsonable(entry.get("normalized_payload")),
        "kind": entry.get("kind"),
        "run_id": entry.get("run_id"),
        "sequence": int(entry.get("sequence") or 0),
    }


def _recent_reference_relevance_score(
    reference: dict[str, Any],
    *,
    selected_object_ids: set[str],
    hint_strings: list[str],
    hint_tokens: set[str],
) -> int:
    object_id = str(reference.get("object_id") or "")
    if object_id and object_id in selected_object_ids:
        return 10_000
    payload = reference.get("normalized_payload")
    payload_text = ""
    try:
        payload_text = json.dumps(_jsonable(payload), sort_keys=True, separators=(",", ":"))
    except Exception:
        payload_text = str(payload or "")
    text_parts = [
        payload_text,
        str(reference.get("summary") or ""),
        str(reference.get("object_type") or ""),
        " ".join(str(item) for item in (reference.get("source_lineage") or [])),
        str(reference.get("kind") or ""),
    ]
    haystack = " ".join(part for part in text_parts if part).lower()
    if not haystack:
        return 0
    score = 0
    matched_strings = 0
    for fragment in hint_strings:
        normalized = str(fragment or "").strip().lower()
        if len(normalized) < 4:
            continue
        if normalized in haystack:
            matched_strings += 1
            score += 6 if any(ch.isdigit() for ch in normalized) or "-" in normalized or "@" in normalized else 3
    overlap = _normalized_identifier_tokens(haystack) & hint_tokens
    score += len(overlap)
    if matched_strings:
        score += 2
    if reference.get("kind") in {"retrieve", "tool_call", "context_ingress"} and score > 0:
        score += 1
    return score


def _safe_docstring(fn) -> str | None:
    doc = inspect.getdoc(fn)
    return doc if doc else None


def _patch_marker(patch_name: str) -> str:
    return f"{_PATCH_MARKER_PREFIX}{patch_name}"


def _is_patched(target: Any, patch_name: str) -> bool:
    return bool(getattr(target, _patch_marker(patch_name), False))


def _mark_patched(target: Any, patch_name: str):
    setattr(target, _patch_marker(patch_name), True)
    return target


def _normalize_tool_arguments(arguments: Any) -> dict[str, Any]:
    if arguments is None:
        return {}
    if isinstance(arguments, dict):
        return _jsonable(arguments)
    if isinstance(arguments, (list, tuple)):
        return {"items": _jsonable(arguments)}
    if isinstance(arguments, str):
        text = arguments.strip()
        if not text:
            return {}
        try:
            parsed = json.loads(text)
        except Exception:
            return {"raw": text}
        if isinstance(parsed, dict):
            return _jsonable(parsed)
        return {"value": _jsonable(parsed)}
    return {"value": _jsonable(arguments)}


def _normalize_tool_definition(definition: Any) -> dict[str, Any] | None:
    if not isinstance(definition, dict):
        return None
    if isinstance(definition.get("function"), dict):
        payload = definition["function"]
    elif isinstance(definition.get("custom"), dict):
        payload = definition["custom"]
    else:
        payload = definition
    name = payload.get("name") or definition.get("name") or definition.get("tool_name")
    if not isinstance(name, str) or not name.strip():
        return None
    schema = (
        payload.get("parameters")
        or payload.get("input_schema")
        or payload.get("inputSchema")
        or payload.get("schema")
        or definition.get("parameters")
        or definition.get("input_schema")
        or definition.get("inputSchema")
        or definition.get("schema")
        or {"type": "object", "additionalProperties": True}
    )
    existing_metadata = definition.get("metadata")
    if not isinstance(existing_metadata, dict):
        existing_metadata = {}
    return {
        "tool_name": name.strip(),
        "schema": _jsonable(schema),
        "docstring": payload.get("description") or definition.get("description") or definition.get("docstring"),
        "args": {},
        "metadata": {
            **_jsonable(existing_metadata),
            "native_call_type": definition.get("type") or payload.get("type"),
            "namespace": payload.get("namespace") or definition.get("namespace"),
            "needs_approval": _truthy_flag(
                payload.get("needsApproval")
                or definition.get("needsApproval")
                or payload.get("needs_approval")
                or definition.get("needs_approval")
                or payload.get("approval_required")
                or definition.get("approval_required")
            ),
        },
    }


def _tool_name_from_choice(choice: Any) -> str | None:
    if isinstance(choice, str):
        normalized = choice.strip()
        if normalized and normalized.lower() not in {"auto", "none", "required"}:
            return normalized
        return None
    if not isinstance(choice, dict):
        return None
    candidates = [
        choice.get("name"),
        (choice.get("function") or {}).get("name") if isinstance(choice.get("function"), dict) else None,
        (choice.get("tool") or {}).get("name") if isinstance(choice.get("tool"), dict) else None,
    ]
    for candidate in candidates:
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    return None


def _tool_definitions_by_name(tool_definitions: list[dict[str, Any]] | None) -> dict[str, dict[str, Any]]:
    normalized: dict[str, dict[str, Any]] = {}
    if isinstance(tool_definitions, dict):
        items = [tool_definitions]
    elif isinstance(tool_definitions, (list, tuple, set)):
        items = list(tool_definitions)
    else:
        items = []
    for item in items:
        descriptor = _normalize_tool_definition(item)
        if descriptor is not None:
            normalized[descriptor["tool_name"]] = descriptor
    return normalized


def _chat_completion_tool_calls(result: Any) -> list[dict[str, Any]]:
    return _openai_direct_chat_completion_tool_calls(
        result,
        result_mapping=_result_mapping,
        normalize_tool_arguments=_normalize_tool_arguments,
    )


def _responses_tool_calls(result: Any, *, include_outputs: bool = False) -> list[dict[str, Any]]:
    return _openai_direct_responses_tool_calls(
        result,
        result_mapping=_result_mapping,
        normalize_tool_arguments=_normalize_tool_arguments,
        include_outputs=include_outputs,
    )


def _chat_completion_assistant_text(result: Any) -> str | None:
    mapped = _result_mapping(result) or {}
    choices = mapped.get("choices")
    if not isinstance(choices, list):
        choices = getattr(result, "choices", None) or []
    if not choices:
        return None
    choice = choices[0]
    choice_mapping = choice if isinstance(choice, dict) else (_result_mapping(choice) or {})
    message = choice_mapping.get("message")
    if message is None and hasattr(choice, "message"):
        message = _result_mapping(getattr(choice, "message", None)) or {}
    if not isinstance(message, dict):
        return None
    if message.get("tool_calls") or message.get("function_call"):
        return None
    content = _content_text(message.get("content"))
    return _structured_assistant_text(content)


def _responses_assistant_text(result: Any) -> str | None:
    mapped = _result_mapping(result) or {}
    output = mapped.get("output")
    if not isinstance(output, list):
        output = getattr(result, "output", None) or []
    for item in output:
        payload = item if isinstance(item, dict) else (_result_mapping(item) or {})
        if not isinstance(payload, dict):
            continue
        item_type = str(payload.get("type") or "").lower()
        if item_type not in {"message", "output_text"} and payload.get("role") != "assistant":
            continue
        content = payload.get("content")
        if isinstance(content, list):
            text = " ".join(_content_text(part.get("text") or part) for part in content)
        else:
            text = _content_text(content or payload.get("text") or payload.get("output_text"))
        text = text.strip()
        if text:
            return _structured_assistant_text(text)
    return None


def _structured_assistant_text(raw_text: str) -> str | None:
    text = str(raw_text or "").strip()
    if not text:
        return None
    try:
        parsed = json.loads(text)
    except Exception:
        return text
    candidate = _find_structured_assistant_text(parsed)
    return candidate or text


def _find_structured_assistant_text(payload: Any) -> str | None:
    if isinstance(payload, dict):
        revisions = payload.get("revisions")
        if isinstance(revisions, list):
            for item in reversed(revisions):
                candidate = _find_structured_assistant_text(item)
                if candidate:
                    return candidate
        for key in (
            "assistant_message",
            "reply",
            "response",
            "final_answer",
            "answer",
            "message",
            "content",
            "text",
        ):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
            candidate = _find_structured_assistant_text(value)
            if candidate:
                return candidate
        for value in payload.values():
            candidate = _find_structured_assistant_text(value)
            if candidate:
                return candidate
        return None
    if isinstance(payload, list):
        for item in reversed(payload):
            candidate = _find_structured_assistant_text(item)
            if candidate:
                return candidate
        return None
    if isinstance(payload, str):
        text = payload.strip()
        return text or None
    return None


def _messages_from_responses_input(input_payload: Any) -> tuple[list[dict[str, Any]], list[str]]:
    return _openai_direct_prompt_messages(input_payload)


def _anthropic_tool_definitions(raw_tools: Any) -> list[dict[str, Any]]:
    return _anthropic_direct_tool_definitions(raw_tools)


def _anthropic_message_tool_calls(
    result: Any,
    *,
    tool_definitions: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    return _anthropic_direct_message_tool_calls(
        result,
        result_mapping=_result_mapping,
        normalize_tool_arguments=_normalize_tool_arguments,
        tool_definitions=tool_definitions,
    )


def _messages_from_anthropic_request(messages: Any, *, system: Any = None) -> list[dict[str, Any]]:
    return _anthropic_direct_prompt_messages(messages=messages, system=system)


def _anthropic_message_assistant_text(result: Any) -> str | None:
    return _anthropic_direct_assistant_text(
        result,
        result_mapping=_result_mapping,
    )


def _record_openai_chat_window(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    messages: list[dict[str, Any]] | None,
    source: str,
    model_name: str | None,
    request_kind: str,
    request_metadata: dict[str, Any] | None,
    tool_choice: Any = None,
    tool_definitions: list[dict[str, Any]] | None = None,
    ) -> None:
    if installer is None:
        return
    installer.record_conversation_window(
        messages or [],
        source=source,
        model_name=model_name,
        request_kind=request_kind,
        request_metadata=request_metadata,
        tool_choice=_jsonable(tool_choice),
        tool_definitions=_jsonable(tool_definitions or []),
        remember_messages_as_context=True,
    )


def _begin_openai_direct_run(
    installer: "ZeroTouchRuntimeInstaller | None",
    messages: list[dict[str, Any]] | None,
    *,
    continuation_turn: bool,
) -> None:
    if installer is None:
        return
    begin = getattr(installer.verifiedx, "begin_run_context", None)
    if callable(begin):
        begin(
            thread_id=_openai_direct_case_thread_hint(messages or []),
            preserve_history=bool(continuation_turn),
        )


def _remember_selected_tools(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    source: str,
    tool_definitions: list[dict[str, Any]] | None,
    selected_tools: list[dict[str, Any]],
) -> None:
    if installer is None or not selected_tools:
        return
    definitions_by_name = _tool_definitions_by_name(tool_definitions)
    for selected in selected_tools:
        tool_name = selected.get("tool_name")
        if not isinstance(tool_name, str) or not tool_name.strip():
            continue
        definition = definitions_by_name.get(tool_name.strip()) or {}
        selection_source = str(selected.get("source") or source)
        if "litellm" in str(source).lower():
            if selection_source.startswith("openai.responses."):
                selection_source = selection_source.replace("openai.responses.", "litellm.responses.", 1)
            elif selection_source.startswith("openai.chat.completions."):
                selection_source = selection_source.replace(
                    "openai.chat.completions.",
                    "litellm.chat.completions.",
                    1,
                )
        selection_metadata = {
            **(_tool_descriptor_metadata(definition) if isinstance(definition, dict) else {}),
            **(
                {
                    key: selected.get(key)
                    for key in (
                        "approval_request_id",
                        "key",
                        "namespace",
                        "native_call_type",
                        "pending_action",
                        "provider_event_type",
                        "provider_executed",
                        "raw_name",
                        "raw_args",
                        "read_only",
                        "retrieval_like",
                        "semantic_class",
                    )
                    if selected.get(key) is not None
                }
            ),
        }
        installer.note_tool_selection(
            tool_name=tool_name.strip(),
            arguments=selected.get("args"),
            tool_call_id=selected.get("tool_call_id"),
            schema=definition.get("schema"),
            docstring=definition.get("docstring"),
            selection_metadata=selection_metadata,
            source=selection_source,
        )


def _tool_dispatch_target(tool_name: str, args: dict[str, Any]) -> str:
    if not isinstance(args, dict):
        return tool_name
    namespace = args.get("namespace")
    key = args.get("key")
    if isinstance(namespace, str) and namespace.strip() and isinstance(key, str) and key.strip():
        return f"{namespace.strip()}/{key.strip()}"
    for candidate_key in (
        "url",
        "uri",
        "target",
        "recipient",
        "recipient_id",
        "email",
        "address",
        "channel",
        "channel_id",
        "customer_id",
        "account_id",
        "user_id",
        "profile_id",
        "contact_id",
        "lead_id",
        "opportunity_id",
        "thread_id",
        "conversation_id",
        "message_id",
        "workflow_id",
        "job_id",
        "task_id",
        "issue_id",
        "issue_number",
        "pr_id",
        "pr_number",
        "pull_request_id",
        "ticket_id",
        "case_id",
        "incident_id",
        "record_id",
        "order_id",
        "subscription_id",
        "reservation_id",
        "config_key",
        "setting_key",
        "state_key",
        "block_id",
        "label",
        "key",
        "name",
    ):
        value = args.get(candidate_key)
        if isinstance(value, str) and value.strip():
            return value.strip()
        if isinstance(value, int):
            return str(value)
    return tool_name


def _tool_dispatch_crosses_boundary(target: str, args: dict[str, Any]) -> bool:
    if isinstance(target, str) and target and not _host_is_local(target):
        parsed = urllib_parse.urlparse(target)
        if parsed.scheme and parsed.netloc:
            return True
    if not isinstance(args, dict):
        return False
    for key in ("email", "recipient", "address", "public", "external", "customer_visible"):
        value = args.get(key)
        if isinstance(value, bool) and value:
            return True
        if isinstance(value, str) and value.strip():
            return True
    return False


def _tool_descriptor_metadata(tool_descriptor: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(tool_descriptor, dict):
        return {}
    metadata = tool_descriptor.get("metadata")
    return metadata if isinstance(metadata, dict) else {}


def _tool_descriptor_arguments(tool_descriptor: dict[str, Any] | None) -> dict[str, Any]:
    metadata = _tool_descriptor_metadata(tool_descriptor)
    raw_args = metadata.get("raw_args")
    if isinstance(raw_args, dict) and raw_args:
        return raw_args
    args = (tool_descriptor or {}).get("args")
    return args if isinstance(args, dict) else {}


def _tool_descriptor_command(tool_descriptor: dict[str, Any] | None) -> str | None:
    args = _tool_descriptor_arguments(tool_descriptor)
    if not args:
        return None
    for key in ("command", "action", "mode", "operation", "op", "method"):
        value = args.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _tool_descriptor_requires_approval(tool_descriptor: dict[str, Any] | None) -> bool:
    metadata = _tool_descriptor_metadata(tool_descriptor)
    if _truthy_flag(metadata.get("needs_approval") or metadata.get("approval_required")):
        return True
    args = _tool_descriptor_arguments(tool_descriptor)
    if not args:
        return False
    if _truthy_flag(args.get("needsApproval") or args.get("needs_approval")):
        return True
    approval = args.get("approval")
    if isinstance(approval, dict):
        return True
    approval_id = args.get("approval_id") or args.get("approvalRequestId") or args.get("approval_request_id")
    return isinstance(approval_id, str) and bool(approval_id.strip())


def _truthy_flag(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _tool_descriptor_looks_terminal_like(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    tool_name = str(tool_descriptor.get("tool_name") or "").strip().lower()
    if not tool_name:
        return False
    if tool_name in {"terminal", "bash", "execute_bash", "cmd_run"}:
        return True
    return bool(_normalized_identifier_tokens(tool_name) & _TERMINAL_TOOL_HINTS)


def _terminal_tool_command(tool_descriptor: dict[str, Any] | None) -> str | None:
    if not isinstance(tool_descriptor, dict):
        return None
    args = tool_descriptor.get("args")
    if not isinstance(args, dict):
        return None
    command = args.get("command")
    if not isinstance(command, str):
        return None
    normalized = command.strip()
    return normalized or None


def _terminal_tool_is_input(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    args = tool_descriptor.get("args")
    if not isinstance(args, dict):
        return False
    return _truthy_flag(args.get("is_input"))


def _terminal_command_is_control_input(command: str | None) -> bool:
    if not isinstance(command, str):
        return False
    return command.strip().lower() in _TERMINAL_CONTROL_INPUTS


def _redacted_header_value(name: str, value: str) -> str:
    normalized = str(name or "").strip().lower()
    if normalized in {
        "authorization",
        "proxy-authorization",
        "x-api-key",
        "api-key",
        "x-auth-token",
        "x-access-token",
    }:
        return "[redacted]"
    return value


def _parse_header_line(raw_header: str) -> tuple[str, str] | None:
    if ":" not in raw_header:
        return None
    name, value = raw_header.split(":", 1)
    normalized_name = str(name).strip()
    if not normalized_name:
        return None
    return normalized_name, _redacted_header_value(normalized_name, value.strip())


def _parse_command_body_value(raw_value: str) -> Any:
    stripped = str(raw_value or "").strip()
    if not stripped:
        return ""
    if stripped.startswith(("{", "[")):
        try:
            return json.loads(stripped)
        except Exception:
            pass
    if stripped.count("=") == 1 and "&" not in stripped:
        key, value = stripped.split("=", 1)
        if key.strip():
            return {key.strip(): value}
    return stripped


def _merge_command_body_parts(parts: list[Any]) -> Any:
    if not parts:
        return None
    if len(parts) == 1:
        return parts[0]
    if all(isinstance(part, dict) for part in parts):
        merged: dict[str, Any] = {}
        for part in parts:
            merged.update(part)
        return merged
    return [_jsonable(part) for part in parts]


def _http_command_action_class(target: str, method: str, payload: Any) -> str:
    return _http_like_action_class(
        target,
        method,
        payload,
        tool_descriptor=None,
    )


def _curl_command_boundary_details(command_text: str) -> dict[str, Any] | None:
    try:
        tokens = shlex.split(command_text, posix=True)
    except Exception:
        return None
    if not tokens or tokens[0] != "curl":
        return None

    method: str | None = None
    url: str | None = None
    headers: dict[str, str] = {}
    data_parts: list[Any] = []
    form_parts: list[str] = []

    index = 1
    while index < len(tokens):
        token = tokens[index]
        if token in {"-X", "--request"} and index + 1 < len(tokens):
            index += 1
            method = str(tokens[index]).strip().upper() or method
        elif token in {"-H", "--header"} and index + 1 < len(tokens):
            index += 1
            header = _parse_header_line(tokens[index])
            if header is not None:
                headers[header[0]] = header[1]
        elif token in {"-d", "--data", "--data-raw", "--data-binary", "--data-urlencode", "--json"} and index + 1 < len(tokens):
            index += 1
            data_parts.append(_parse_command_body_value(tokens[index]))
            if method is None:
                method = "POST"
        elif token in {"-F", "--form"} and index + 1 < len(tokens):
            index += 1
            form_parts.append(tokens[index])
            if method is None:
                method = "POST"
        elif token == "--url" and index + 1 < len(tokens):
            index += 1
            url = tokens[index]
        elif token in {"-I", "--head"}:
            method = "HEAD"
        elif token == "-G" and method is None:
            method = "GET"
        elif token.startswith(("http://", "https://")):
            url = token
        index += 1

    if not isinstance(url, str) or not url.strip():
        return None
    method = (method or ("POST" if data_parts or form_parts else "GET")).upper()
    if method not in {"POST", "PUT", "PATCH", "DELETE"}:
        return None

    payload = _merge_command_body_parts(data_parts)
    if form_parts:
        form_payload = _merge_command_body_parts(
            [_parse_command_body_value(item) for item in form_parts]
        )
        if payload is None:
            payload = {"form": form_payload}
        else:
            payload = {"data": payload, "form": form_payload}

    transport_args = {
        "command": command_text,
        "argv": tokens,
        "url": url.strip(),
        "method": method,
        "headers": headers,
        "body": _jsonable(payload),
    }
    return {
        "surface": "http",
        "operation": "terminal.curl",
        "target": url.strip(),
        "method": method,
        "transport_args": transport_args,
        "boundary_kind": None,
        "action_class": _http_command_action_class(url.strip(), method, payload),
        "trust_boundary_crossing": not _host_is_local(url.strip()),
    }


def _httpx_body_payload(request: Any) -> Any:
    content = getattr(request, "content", b"") or b""
    if isinstance(content, str):
        text = content.strip()
    elif isinstance(content, (bytes, bytearray)):
        try:
            text = bytes(content).decode("utf-8", errors="ignore").strip()
        except Exception:
            return None
    else:
        return None
    if not text:
        return None
    if text.startswith(("{", "[")):
        try:
            return json.loads(text)
        except Exception:
            return text
    parsed_qs = urllib_parse.parse_qs(text, keep_blank_values=True)
    if parsed_qs:
        return {
            key: values[0] if len(values) == 1 else values
            for key, values in parsed_qs.items()
        }
    return text


def _gh_api_target(path: str) -> str:
    normalized = str(path or "").strip()
    if normalized.startswith(("http://", "https://")):
        return normalized
    return f"https://api.github.com/{normalized.lstrip('/')}"


def _gh_command_boundary_details(command_text: str) -> dict[str, Any] | None:
    try:
        tokens = shlex.split(command_text, posix=True)
    except Exception:
        return None
    if not tokens or tokens[0] != "gh" or len(tokens) < 2:
        return None

    if len(tokens) >= 4 and tokens[1] in {"issue", "pr"} and tokens[2] == "comment":
        repo = None
        body = None
        number = tokens[3] if not tokens[3].startswith("-") else None
        index = 4
        while index < len(tokens):
            token = tokens[index]
            if token in {"--repo", "-R"} and index + 1 < len(tokens):
                index += 1
                repo = tokens[index]
            elif token in {"--body", "-b"} and index + 1 < len(tokens):
                index += 1
                body = tokens[index]
            index += 1
        if not number:
            return None
        if repo:
            target = f"https://api.github.com/repos/{repo.strip()}/issues/{number}/comments"
        else:
            target = f"github://issues/{number}/comments"
        payload = {"body": body} if isinstance(body, str) and body.strip() else None
        return {
            "surface": "http",
            "operation": "terminal.gh.comment",
            "target": target,
            "method": "POST",
            "transport_args": {
                "command": command_text,
                "argv": tokens,
                "url": target,
                "method": "POST",
                "headers": {},
                "body": _jsonable(payload),
            },
            "boundary_kind": None,
            "action_class": "external_message_send",
            "trust_boundary_crossing": True,
        }

    if tokens[1] != "api":
        return None

    method: str | None = None
    path: str | None = None
    fields: dict[str, Any] = {}
    index = 2
    while index < len(tokens):
        token = tokens[index]
        if token in {"-X", "--method"} and index + 1 < len(tokens):
            index += 1
            method = tokens[index].strip().upper()
        elif token in {"-f", "-F", "--field"} and index + 1 < len(tokens):
            index += 1
            field = tokens[index]
            if "=" in field:
                key, value = field.split("=", 1)
                if key.strip():
                    fields[key.strip()] = value
        elif not token.startswith("-") and path is None:
            path = token
        index += 1

    if not path:
        return None
    target = _gh_api_target(path)
    method = (method or ("POST" if fields else "GET")).upper()
    if method not in {"POST", "PUT", "PATCH", "DELETE"}:
        return None
    payload = fields or None
    return {
        "surface": "http",
        "operation": "terminal.gh.api",
        "target": target,
        "method": method,
        "transport_args": {
            "command": command_text,
            "argv": tokens,
            "url": target,
            "method": method,
            "headers": {},
            "body": _jsonable(payload),
        },
        "boundary_kind": None,
        "action_class": _http_command_action_class(target, method, payload),
        "trust_boundary_crossing": True,
    }


def _shell_command_boundary_details(
    tool_descriptor: dict[str, Any] | None,
    *,
    command: str | None = None,
) -> dict[str, Any] | None:
    if tool_descriptor is not None and not _tool_descriptor_looks_terminal_like(tool_descriptor):
        return None
    if tool_descriptor is not None and _terminal_tool_is_input(tool_descriptor):
        return None
    command_text = str(command or _terminal_tool_command(tool_descriptor) or "").strip()
    if not command_text or _terminal_command_is_control_input(command_text):
        return None
    capture = _curl_command_boundary_details(command_text) or _gh_command_boundary_details(command_text)
    if capture is None:
        return None
    effective_tool = dict(tool_descriptor or {})
    if not effective_tool:
        effective_tool = {
            "tool_name": "terminal",
            "schema": {"type": "object", "additionalProperties": True},
            "docstring": "Execute a shell command in the terminal.",
            "args": {"command": command_text},
        }
    return {
        **capture,
        "tool_descriptor": effective_tool,
    }


def _safe_schema_from_callable(fn) -> dict[str, Any]:
    signature = None
    try:
        signature = inspect.signature(fn)
    except (TypeError, ValueError):
        return {"type": "object", "additionalProperties": True}
    properties: dict[str, Any] = {}
    required: list[str] = []
    for name, parameter in signature.parameters.items():
        if parameter.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue
        properties[name] = {"type": "string"}
        if parameter.default is inspect._empty:
            required.append(name)
    return {
        "type": "object",
        "additionalProperties": True,
        "properties": properties,
        "required": required,
    }


def _bind_arguments(fn, args, kwargs) -> dict[str, Any]:
    try:
        signature = inspect.signature(fn)
    except (TypeError, ValueError):
        return {
            "args": [_jsonable(arg) for arg in args],
            "kwargs": {key: _jsonable(value) for key, value in kwargs.items()},
        }
    try:
        bound = signature.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        return {key: _jsonable(value) for key, value in bound.arguments.items()}
    except TypeError:
        return {
            "args": [_jsonable(arg) for arg in args],
            "kwargs": {key: _jsonable(value) for key, value in kwargs.items()},
        }


def _replace_call_argument(fn, args, kwargs, name: str, value: Any) -> tuple[tuple[Any, ...], dict[str, Any]]:
    try:
        signature = inspect.signature(fn)
        bound = signature.bind_partial(*args, **kwargs)
        bound.arguments[name] = value
        return tuple(bound.args), dict(bound.kwargs)
    except (TypeError, ValueError):
        updated_kwargs = dict(kwargs)
        updated_kwargs[name] = value
        return tuple(args), updated_kwargs


def _extract_raw_tool_arguments(args, kwargs) -> dict[str, Any] | None:
    if kwargs:
        normalized_kwargs = _jsonable(kwargs)
        if isinstance(normalized_kwargs, dict) and normalized_kwargs:
            return normalized_kwargs
    if len(args) == 1:
        normalized_arg = _jsonable(args[0])
        if isinstance(normalized_arg, dict) and normalized_arg:
            return normalized_arg
    return None


def _normalized_sql_text(statement: Any) -> str:
    if statement is None:
        return ""
    if isinstance(statement, str):
        return statement
    if hasattr(statement, "string"):
        try:
            return str(statement.string)
        except Exception:
            pass
    return str(statement)


def _sql_operation(statement: Any) -> str | None:
    sql_text = _normalized_sql_text(statement).strip()
    if not sql_text:
        return None
    return sql_text.split(None, 1)[0].upper()


def _looks_like_sql_mutation(statement: Any) -> bool:
    operation = (_sql_operation(statement) or "").lower()
    return operation in _SQL_MUTATION_PREFIXES


def _sql_target(statement: Any, *, default: str | None = None) -> str:
    sql_text = _normalized_sql_text(statement)
    for pattern in _SQL_TARGET_PATTERNS:
        match = pattern.search(sql_text)
        if match:
            return match.group(1).strip('"')
    return default or "sql_mutation"


def _ambient_tool_descriptor(installer: "ZeroTouchRuntimeInstaller | None") -> dict[str, Any] | None:
    current_tool = _current_tool_invocation()
    if current_tool is not None:
        return current_tool.descriptor()
    if installer is None:
        return None
    descriptor, _ = installer.infer_ambient_tool_descriptor()
    return descriptor


def _tool_name_tokens(tool_descriptor: dict[str, Any] | None) -> set[str]:
    if not isinstance(tool_descriptor, dict):
        return set()
    return _normalized_identifier_tokens(tool_descriptor.get("tool_name"))


def _tool_descriptor_semantic_tokens(tool_descriptor: dict[str, Any] | None) -> set[str]:
    if not isinstance(tool_descriptor, dict):
        return set()
    tokens = set(_tool_name_tokens(tool_descriptor))
    metadata = _tool_descriptor_metadata(tool_descriptor)
    raw_name = metadata.get("raw_name")
    if isinstance(raw_name, str) and raw_name.strip():
        tokens |= _normalized_identifier_tokens(raw_name)
    docstring = tool_descriptor.get("docstring")
    if isinstance(docstring, str) and docstring.strip():
        tokens |= _normalized_identifier_tokens(docstring)
    command = _tool_descriptor_command(tool_descriptor)
    if isinstance(command, str) and command.strip():
        tokens |= _normalized_identifier_tokens(command)
    for value in _parameter_scalar_strings(_tool_descriptor_arguments(tool_descriptor)):
        tokens |= _normalized_identifier_tokens(value)
    return tokens


def _tool_descriptor_has_mutation_intent(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    tokens = _tool_descriptor_semantic_tokens(tool_descriptor)
    if tokens & _MUTATING_TOOL_HINTS:
        return True
    parameter_names = _parameter_key_names(_tool_descriptor_arguments(tool_descriptor))
    return bool(parameter_names & _MUTATING_ARGUMENT_HINTS)


def _tool_descriptor_looks_memory_like(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    if _tool_descriptor_looks_assistant_message(tool_descriptor):
        return False
    tokens = _tool_descriptor_semantic_tokens(tool_descriptor)
    parameter_names = _parameter_key_names(_tool_descriptor_arguments(tool_descriptor))
    memory_semantics = bool(tokens & _MEMORY_TOOL_HINTS or parameter_names & _MEMORY_ARGUMENT_HINTS)
    if not memory_semantics:
        return False
    if {"namespace", "key", "value"} <= parameter_names:
        return True
    if parameter_names & {"value", "note", "notes", "summary", "fact", "facts"}:
        return _tool_descriptor_has_mutation_intent(tool_descriptor)
    return _tool_descriptor_has_mutation_intent(tool_descriptor)


def _tool_descriptor_looks_assistant_message(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    return str(tool_descriptor.get("tool_name") or "").strip().lower() == "assistant_message"


def _tool_descriptor_looks_retrieval_like(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    if _tool_descriptor_looks_assistant_message(tool_descriptor):
        return False
    tokens = _tool_descriptor_semantic_tokens(tool_descriptor)
    parameter_names = _parameter_key_names(_tool_descriptor_arguments(tool_descriptor))
    if tokens & _MUTATING_TOOL_HINTS or parameter_names & _MUTATING_ARGUMENT_HINTS:
        return False
    strong_retrieval_tokens = tokens & (_RETRIEVAL_TOOL_HINTS - {"context"})
    if strong_retrieval_tokens:
        return True
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return False
    if tokens & _RETRIEVAL_TOOL_HINTS:
        return True
    return bool(parameter_names) and parameter_names <= _RETRIEVAL_ARGUMENT_HINTS


def _host_looks_local_or_private(host: str) -> bool:
    normalized = str(host or "").strip().lower()
    if not normalized:
        return False
    if normalized in {"localhost", "::1"}:
        return True
    if normalized.startswith("127."):
        return True
    if normalized.startswith("10."):
        return True
    if normalized.startswith("192.168."):
        return True
    if normalized.startswith("172."):
        parts = normalized.split(".")
        if len(parts) >= 2:
            try:
                second = int(parts[1])
            except Exception:
                second = -1
            if 16 <= second <= 31:
                return True
    return False


def _tool_descriptor_suggests_record_mutation(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return False
    if _tool_descriptor_looks_assistant_message(tool_descriptor):
        return False
    if _tool_descriptor_looks_retrieval_like(tool_descriptor):
        return False
    tokens = _tool_descriptor_semantic_tokens(tool_descriptor)
    parameter_names = _parameter_key_names(_tool_descriptor_arguments(tool_descriptor))
    record_identifier_names = {
        name
        for name in parameter_names
        if name == "id"
        or (
            name.endswith("_id")
            and any(entity in name for entity in _RECORD_ENTITY_HINTS)
        )
    }
    has_record_semantics = bool(
        tokens & _RECORD_ENTITY_HINTS
        or any(
            any(entity in name for entity in _RECORD_ENTITY_HINTS)
            for name in parameter_names
        )
    )
    if {"field_name", "field_value"} <= parameter_names:
        return True
    if (parameter_names & _RECORD_MUTATION_ARGUMENT_HINTS) and record_identifier_names:
        return True
    if has_record_semantics and record_identifier_names and (
        tokens & (_MUTATING_TOOL_HINTS | _RECORD_ENTITY_HINTS | {"refund"})
        or parameter_names & _RECORD_MUTATION_ARGUMENT_HINTS
    ):
        return True
    return False


def _tool_descriptor_looks_internal_update(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return False
    if _tool_descriptor_suggests_message_send(tool_descriptor):
        return False
    if _tool_descriptor_suggests_record_mutation(tool_descriptor):
        return False
    if _tool_descriptor_looks_retrieval_like(tool_descriptor):
        return False
    tokens = _tool_descriptor_semantic_tokens(tool_descriptor)
    parameter_names = _parameter_key_names(_tool_descriptor_arguments(tool_descriptor))
    if not _tool_descriptor_has_mutation_intent(tool_descriptor) and not (
        parameter_names & _INTERNAL_UPDATE_ARGUMENT_HINTS
    ):
        return False
    if tokens & _INTERNAL_UPDATE_TOOL_HINTS & _MUTATING_TOOL_HINTS:
        return True
    if tokens & _INTERNAL_UPDATE_TOOL_HINTS and (
        _tool_descriptor_has_mutation_intent(tool_descriptor)
        or parameter_names & _INTERNAL_UPDATE_ARGUMENT_HINTS
    ):
        return True
    return False


def _structured_key_names(value: Any, *, depth: int = 0) -> set[str]:
    if depth > 4:
        return set()
    if isinstance(value, dict):
        names: set[str] = set()
        for key, nested in value.items():
            normalized = str(key).strip().lower()
            if normalized:
                names.add(normalized)
            names |= _structured_key_names(nested, depth=depth + 1)
        return names
    if isinstance(value, list):
        names: set[str] = set()
        for nested in value:
            names |= _structured_key_names(nested, depth=depth + 1)
        return names
    return set()


def _structured_semantic_tokens(value: Any, *, depth: int = 0) -> set[str]:
    if depth > 4:
        return set()
    if isinstance(value, dict):
        tokens: set[str] = set()
        for key, nested in value.items():
            tokens |= _normalized_identifier_tokens(key)
            tokens |= _structured_semantic_tokens(nested, depth=depth + 1)
        return tokens
    if isinstance(value, list):
        tokens: set[str] = set()
        for nested in value:
            tokens |= _structured_semantic_tokens(nested, depth=depth + 1)
        return tokens
    if isinstance(value, (str, int, float, bool)):
        return _normalized_identifier_tokens(value)
    return set()


def _http_payload_candidate(payload: Any) -> Any:
    if not isinstance(payload, dict):
        return payload
    for key in ("json", "data", "body", "payload", "form", "params"):
        candidate = payload.get(key)
        if isinstance(candidate, (dict, list, str)) and candidate:
            return candidate
    return payload


def _http_target_tokens(target: str) -> set[str]:
    parsed = urllib_parse.urlparse(str(target or ""))
    tokens = set()
    tokens |= _normalized_identifier_tokens(parsed.hostname or "")
    tokens |= _normalized_identifier_tokens(parsed.path or "")
    tokens |= _normalized_identifier_tokens(parsed.query or "")
    return tokens


def _http_payload_key_names(payload: Any) -> set[str]:
    return _structured_key_names(_http_payload_candidate(payload))


def _http_payload_tokens(payload: Any) -> set[str]:
    return _structured_semantic_tokens(_http_payload_candidate(payload))


def _tool_descriptor_suggests_message_send(tool_descriptor: dict[str, Any] | None) -> bool:
    if not isinstance(tool_descriptor, dict):
        return False
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return False
    tokens = _tool_descriptor_semantic_tokens(tool_descriptor)
    parameter_names = _parameter_key_names(_tool_descriptor_arguments(tool_descriptor))
    has_comm_semantics = bool(
        tokens & _COMMUNICATION_TOOL_HINTS or parameter_names & _COMMUNICATION_ARGUMENT_HINTS
    )
    has_destination = bool(
        parameter_names
        & {
            "address",
            "bcc",
            "cc",
            "channel",
            "channel_id",
            "conversation_id",
            "dm",
            "email",
            "recipient",
            "recipient_id",
            "thread_id",
            "to",
            "user_id",
        }
    )
    has_message_body = bool(
        parameter_names & {"body", "comment", "content", "message", "note", "reply", "subject", "text"}
    )
    if has_destination and has_message_body:
        return True
    if has_comm_semantics and (
        has_message_body
        or has_destination
        or tokens & {"comment", "email", "mail", "message", "notify", "reply", "send", "slack", "teams"}
    ):
        return True
    return False


def _http_payload_looks_message_send(
    target: str,
    payload: Any,
    *,
    tool_descriptor: dict[str, Any] | None = None,
) -> bool:
    if _tool_descriptor_suggests_message_send(tool_descriptor):
        return True
    target_tokens = _http_target_tokens(target)
    payload_tokens = _http_payload_tokens(payload)
    key_names = _http_payload_key_names(payload)
    if "/comments" in urllib_parse.urlparse(target).path.lower() or "/replies" in urllib_parse.urlparse(target).path.lower() or "/reviews" in urllib_parse.urlparse(target).path.lower():
        return True
    has_destination = bool(
        key_names
        & {
            "address",
            "bcc",
            "cc",
            "channel",
            "channel_id",
            "conversation_id",
            "dm",
            "email",
            "recipient",
            "recipient_id",
            "thread_id",
            "to",
            "user_id",
        }
    )
    has_message_body = bool(
        key_names & {"body", "comment", "content", "message", "note", "reply", "subject", "text"}
    )
    if has_destination and has_message_body:
        return True
    if (target_tokens | payload_tokens) & _MESSAGE_HOST_HINTS and (
        has_destination or has_message_body or payload_tokens & _COMMUNICATION_TOOL_HINTS
    ):
        return True
    if payload_tokens & _INTERNAL_MESSAGE_HINTS and has_message_body:
        return True
    return False


def _http_payload_looks_memory_write(
    target: str,
    payload: Any,
    *,
    tool_descriptor: dict[str, Any] | None = None,
) -> bool:
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return True
    target_tokens = _http_target_tokens(target)
    payload_tokens = _http_payload_tokens(payload)
    key_names = _http_payload_key_names(payload)
    if {"namespace", "key", "value"} <= key_names:
        return True
    if (target_tokens | payload_tokens) & _HTTP_MEMORY_TARGET_HINTS and (
        key_names & (_MEMORY_ARGUMENT_HINTS | {"delete", "operation", "value"})
        or payload_tokens & _MUTATING_TOOL_HINTS
    ):
        return True
    return False


def _http_payload_looks_record_mutation(
    target: str,
    payload: Any,
    *,
    tool_descriptor: dict[str, Any] | None = None,
) -> bool:
    if _tool_descriptor_suggests_record_mutation(tool_descriptor):
        return True
    target_tokens = _http_target_tokens(target)
    payload_tokens = _http_payload_tokens(payload)
    key_names = _http_payload_key_names(payload)
    record_identifier_names = {
        name
        for name in key_names
        if name == "id"
        or (
            name.endswith("_id")
            and any(entity in name for entity in _RECORD_ENTITY_HINTS)
        )
    }
    has_record_semantics = bool(
        target_tokens & _RECORD_ENTITY_HINTS
        or payload_tokens & _RECORD_ENTITY_HINTS
        or any(
            any(entity in name for entity in _RECORD_ENTITY_HINTS)
            for name in key_names
        )
    )
    if record_identifier_names and (
        key_names & _RECORD_MUTATION_ARGUMENT_HINTS or payload_tokens & _MUTATING_TOOL_HINTS
    ):
        return True
    if has_record_semantics and (payload_tokens & _MUTATING_TOOL_HINTS):
        return True
    return False


def _http_payload_looks_internal_update(
    target: str,
    payload: Any,
    *,
    tool_descriptor: dict[str, Any] | None = None,
) -> bool:
    if _tool_descriptor_looks_internal_update(tool_descriptor):
        return True
    target_tokens = _http_target_tokens(target)
    payload_tokens = _http_payload_tokens(payload)
    key_names = _http_payload_key_names(payload)
    if (target_tokens | payload_tokens) & _HTTP_INTERNAL_TARGET_HINTS and (
        key_names & _INTERNAL_UPDATE_ARGUMENT_HINTS or payload_tokens & _MUTATING_TOOL_HINTS
    ):
        return True
    return False


def _http_like_action_class(
    target: str,
    method: str | None,
    payload: Any,
    *,
    tool_descriptor: dict[str, Any] | None,
) -> str:
    normalized_method = str(method or "").upper()
    parsed = urllib_parse.urlparse(str(target or ""))
    is_local = _host_looks_local_or_private(parsed.hostname or "")
    if _http_payload_looks_memory_write(target, payload, tool_descriptor=tool_descriptor):
        return "memory_write"
    if _http_payload_looks_message_send(target, payload, tool_descriptor=tool_descriptor):
        return "external_message_send"
    if _http_payload_looks_record_mutation(target, payload, tool_descriptor=tool_descriptor):
        return "record_mutation"
    if _http_payload_looks_internal_update(target, payload, tool_descriptor=tool_descriptor):
        return "system_change"
    if is_local and normalized_method in {"POST", "PUT", "PATCH", "DELETE"}:
        return "system_change"
    if normalized_method in {"POST", "PUT", "PATCH", "DELETE"}:
        return "webhook_call"
    return "generic"


def _tool_selection_pending_action(
    tool_descriptor: dict[str, Any] | None,
    *,
    source: str | None,
) -> dict[str, Any] | None:
    if not isinstance(tool_descriptor, dict):
        return None
    metadata = _tool_descriptor_metadata(tool_descriptor)
    if _truthy_flag(metadata.get("capture_only")):
        return None
    pending_action = metadata.get("pending_action")
    if isinstance(pending_action, dict):
        return {
            "surface": str(pending_action.get("surface") or "tool_dispatch"),
            "operation": str(
                pending_action.get("raw_name")
                or pending_action.get("operation")
                or tool_descriptor.get("tool_name")
                or "unknown"
            ),
            "target": str(
                pending_action.get("target")
                or _tool_dispatch_target(
                    str(tool_descriptor.get("tool_name") or ""),
                    _tool_descriptor_arguments(tool_descriptor),
                )
            ),
            "method": str(pending_action.get("method") or "CALL"),
            "transport_args": dict(
                pending_action.get("raw_args")
                if isinstance(pending_action.get("raw_args"), dict)
                else _tool_descriptor_arguments(tool_descriptor)
            ),
            "boundary_kind": str(pending_action.get("boundary_kind") or "action_execute"),
            "action_class": pending_action.get("action_class"),
            "trust_boundary_crossing": bool(pending_action.get("trust_boundary_crossing")),
        }
    raw_name = str(metadata.get("raw_name") or tool_descriptor.get("tool_name") or "").strip()
    native_call_type = str(metadata.get("native_call_type") or "").strip().lower()
    provider_event_type = str(metadata.get("provider_event_type") or "").strip().lower()
    provider_executed = _truthy_flag(metadata.get("provider_executed"))
    args = _tool_descriptor_arguments(tool_descriptor)
    command = (_tool_descriptor_command(tool_descriptor) or "").strip()
    normalized_source = str(source or "").strip().lower()
    openai_capture = _openai_direct_pending_action(
        raw_name=raw_name,
        native_call_type=native_call_type,
        args=args,
        command=command,
        dispatch_target=_tool_dispatch_target,
    )
    if openai_capture is not None:
        return openai_capture
    anthropic_capture = _anthropic_direct_pending_action(
        raw_name=raw_name or str(tool_descriptor.get("tool_name") or ""),
        native_tool_type=native_call_type or raw_name,
        provider_event_type=provider_event_type,
        args=args,
        command=command,
        dispatch_target=_tool_dispatch_target,
    )
    if anthropic_capture is not None:
        return {
            "surface": str(anthropic_capture.get("surface") or "tool_dispatch"),
            "operation": str(anthropic_capture.get("operation") or raw_name or tool_descriptor.get("tool_name") or "unknown"),
            "target": str(anthropic_capture.get("target") or _tool_dispatch_target(str(tool_descriptor.get("tool_name") or raw_name or "tool_dispatch"), args)),
            "method": anthropic_capture.get("method"),
            "transport_args": dict(
                anthropic_capture.get("raw_args")
                if isinstance(anthropic_capture.get("raw_args"), dict)
                else anthropic_capture.get("transport_args")
                if isinstance(anthropic_capture.get("transport_args"), dict)
                else args
            ),
            "boundary_kind": str(anthropic_capture.get("boundary_kind") or "action_execute"),
            "action_class": anthropic_capture.get("action_class"),
            "trust_boundary_crossing": bool(anthropic_capture.get("trust_boundary_crossing")),
        }
    if provider_executed:
        return None
    if raw_name in {
        "langgraph.Command.update",
        "langgraph.checkpointer.put",
        "langgraph.checkpointer.put_writes",
        "langgraph.graph.update_state",
        "langgraph.store.delete",
        "langgraph.store.put",
    }:
        is_memory_mutation = raw_name in {"langgraph.store.put", "langgraph.store.delete"}
        return {
            "surface": "memory_write" if is_memory_mutation else "tool_dispatch",
            "operation": raw_name,
            "target": _tool_dispatch_target(raw_name, args),
            "method": command or ("delete" if raw_name == "langgraph.store.delete" else "write" if raw_name == "langgraph.store.put" else "CALL"),
            "transport_args": dict(args),
            "boundary_kind": "memory_write" if is_memory_mutation else "action_execute",
            "action_class": "memory_write" if is_memory_mutation else "system_change",
            "trust_boundary_crossing": False,
        }
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return {
            "surface": "memory_write",
            "operation": raw_name or str(tool_descriptor.get("tool_name") or "memory_write"),
            "target": _tool_dispatch_target(str(tool_descriptor.get("tool_name") or "memory_write"), args),
            "method": command or "write",
            "transport_args": dict(args),
            "boundary_kind": "memory_write",
            "action_class": "memory_write",
            "trust_boundary_crossing": False,
        }
    if _tool_descriptor_suggests_record_mutation(tool_descriptor):
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or str(tool_descriptor.get("tool_name") or "tool_dispatch"),
            "target": _tool_dispatch_target(str(tool_descriptor.get("tool_name") or "tool_dispatch"), args),
            "method": command or "CALL",
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "record_mutation",
            "trust_boundary_crossing": _tool_dispatch_crosses_boundary(
                _tool_dispatch_target(str(tool_descriptor.get("tool_name") or "tool_dispatch"), args),
                args,
            ),
        }
    if _tool_descriptor_suggests_message_send(tool_descriptor):
        target = _tool_dispatch_target(str(tool_descriptor.get("tool_name") or "tool_dispatch"), args)
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or str(tool_descriptor.get("tool_name") or "tool_dispatch"),
            "target": target,
            "method": command or "SEND",
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "external_message_send",
            "trust_boundary_crossing": _tool_dispatch_crosses_boundary(target, args),
        }
    if _tool_descriptor_looks_internal_update(tool_descriptor) or _tool_descriptor_requires_approval(tool_descriptor):
        target = _tool_dispatch_target(str(tool_descriptor.get("tool_name") or "tool_dispatch"), args)
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or str(tool_descriptor.get("tool_name") or "tool_dispatch"),
            "target": target,
            "method": command or "CALL",
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": _tool_dispatch_crosses_boundary(target, args),
        }
    if normalized_source.startswith("vercel_ai") and _tool_descriptor_requires_approval(tool_descriptor):
        target = _tool_dispatch_target(str(tool_descriptor.get("tool_name") or "tool_dispatch"), args)
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or str(tool_descriptor.get("tool_name") or "tool_dispatch"),
            "target": target,
            "method": command or "CALL",
            "transport_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "generic",
            "trust_boundary_crossing": _tool_dispatch_crosses_boundary(target, args),
        }
    return None


def _tool_descriptor_requires_direct_boundary(tool_descriptor: dict[str, Any] | None, *, source: str | None) -> bool:
    metadata = _tool_descriptor_metadata(tool_descriptor)
    if _truthy_flag(metadata.get("capture_only")):
        return False
    if isinstance(metadata.get("pending_action"), dict):
        return True
    if _truthy_flag(metadata.get("provider_executed")):
        return False
    if _truthy_flag(metadata.get("read_only") or metadata.get("retrieval_like")):
        return False
    native_call_type = str(metadata.get("native_call_type") or "").strip().lower()
    provider_event_type = str(metadata.get("provider_event_type") or "").strip().lower()
    if native_call_type in _OPENAI_DIRECT_TOOL_TYPES:
        return False
    if _tool_descriptor_looks_terminal_like(tool_descriptor):
        return False
    args = _tool_descriptor_arguments(tool_descriptor)
    raw_name = str(metadata.get("raw_name") or (tool_descriptor or {}).get("tool_name") or "").strip()
    if _anthropic_direct_requires_direct_boundary(
        raw_name=raw_name or str((tool_descriptor or {}).get("tool_name") or ""),
        native_tool_type=native_call_type or raw_name,
        provider_event_type=provider_event_type,
        args=args,
        provider_executed=_truthy_flag(metadata.get("provider_executed")),
    ):
        return True
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return True
    if _tool_descriptor_suggests_record_mutation(tool_descriptor):
        return True
    if _tool_descriptor_suggests_message_send(tool_descriptor):
        return True
    if _tool_descriptor_looks_internal_update(tool_descriptor):
        return True
    if _tool_descriptor_requires_approval(tool_descriptor) and str(source or "").strip().lower().startswith("vercel_ai"):
        return True
    return False


def _capture_source_kind_from_source(source: str | None) -> str:
    normalized = str(source or "").strip().lower()
    if not normalized:
        return "runtime_patch"
    if normalized.startswith("otel."):
        return "otel"
    if normalized.startswith("wrap_") or normalized.startswith("wrapper"):
        return "wrapper"
    if "assistant_output" in normalized:
        return "assistant_output_fallback"
    return "runtime_patch"


def _parameter_records(parameters: Any) -> list[dict[str, Any]]:
    if isinstance(parameters, dict):
        return [parameters]
    if isinstance(parameters, list):
        return [item for item in parameters if isinstance(item, dict)]
    return []


def _parameter_key_names(parameters: Any) -> set[str]:
    names: set[str] = set()
    for record in _parameter_records(parameters):
        for key in record.keys():
            normalized = str(key).strip().lower()
            if normalized:
                names.add(normalized)
    return names


def _parameter_scalar_strings(parameters: Any) -> list[str]:
    values: list[str] = []
    for record in _parameter_records(parameters):
        for value in record.values():
            if isinstance(value, str):
                normalized = value.strip()
                if normalized:
                    values.append(normalized)
            elif isinstance(value, (int, float, bool)):
                values.append(str(value))
    return values


def _hash_jsonable(value: Any) -> str:
    encoded = json.dumps(
        _jsonable(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sql_parameter_summary(parameters: Any) -> dict[str, Any] | None:
    if parameters is None:
        return None
    records = _parameter_records(parameters)
    if records:
        keys = sorted(
            {
                str(key)
                for record in records
                for key in record.keys()
            }
        )
        return {
            "record_count": len(records),
            "keys": keys[:32],
            "hash": _hash_jsonable(records),
        }
    return {
        "type": type(parameters).__name__,
        "hash": _hash_jsonable(parameters),
    }


def _sql_mutation_looks_memory_effect(
    tool_descriptor: dict[str, Any] | None,
    *,
    target: str,
    transport_args: dict[str, Any],
) -> bool:
    if not _tool_descriptor_looks_memory_like(tool_descriptor):
        return False
    target_tokens = _normalized_identifier_tokens(target)
    if target_tokens & _MEMORY_SQL_TARGET_HINTS:
        return True
    parameters = transport_args.get("parameters")
    parameter_keys = _parameter_key_names(parameters)
    if parameter_keys & _MEMORY_SQL_PARAMETER_HINTS:
        return True
    if target_tokens & (_SQL_RUNTIME_ARTIFACT_TARGET_HINTS | _SQL_BOOKKEEPING_TARGET_HINTS):
        return False
    tool_args = (tool_descriptor or {}).get("args") or {}
    candidate_values = [
        value.strip()
        for key, value in tool_args.items()
        if isinstance(value, str)
        and value.strip()
        and len(value.strip()) >= 12
        and (
            _normalized_identifier_tokens(key) & _MEMORY_SQL_PARAMETER_HINTS
            or key.endswith("string")
            or key.endswith("value")
        )
    ]
    if not candidate_values:
        return False
    observed_values = _parameter_scalar_strings(parameters)
    for expected in candidate_values:
        if any(expected in observed or observed in expected for observed in observed_values):
            return True
    return False


def _should_skip_sql_boundary_capture(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    target: str,
    transport_args: dict[str, Any],
) -> bool:
    tool_descriptor = _ambient_tool_descriptor(installer)
    if tool_descriptor is None:
        return False
    if _tool_descriptor_looks_memory_like(tool_descriptor):
        return not _sql_mutation_looks_memory_effect(
            tool_descriptor,
            target=target,
            transport_args=transport_args,
        )
    if _tool_descriptor_looks_assistant_message(tool_descriptor):
        target_tokens = _normalized_identifier_tokens(target)
        return not bool(target_tokens & _SQL_ASSISTANT_MESSAGE_TARGET_HINTS)
    target_tokens = _normalized_identifier_tokens(target)
    if not (target_tokens & _SQL_BOOKKEEPING_TARGET_HINTS):
        return False
    tool_tokens = _tool_name_tokens(tool_descriptor)
    return not bool(tool_tokens & target_tokens)


def _sql_boundary_overrides(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    target: str,
    transport_args: dict[str, Any],
) -> tuple[str | None, str | None]:
    tool_descriptor = _ambient_tool_descriptor(installer)
    if _sql_mutation_looks_memory_effect(
        tool_descriptor,
        target=target,
        transport_args=transport_args,
    ):
        return "memory_write", "memory_write"
    if _tool_descriptor_looks_assistant_message(tool_descriptor):
        return None, "external_message_send"
    return None, "record_mutation"


def _sql_transport_args_for_boundary(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    transport_args: dict[str, Any],
) -> dict[str, Any]:
    normalized = dict(transport_args)
    if _ambient_tool_descriptor(installer) is None:
        return normalized
    parameters = normalized.pop("parameters", None)
    summary = _sql_parameter_summary(parameters)
    if summary is not None:
        normalized["parameter_summary"] = summary
    return normalized


def _file_write_text(data: Any) -> str | None:
    if isinstance(data, str):
        text = data
    elif isinstance(data, (bytes, bytearray)):
        try:
            text = bytes(data).decode("utf-8", errors="ignore")
        except Exception:
            return None
    else:
        return None
    normalized = text.strip()
    return normalized or None


def _is_mutating_file_mode(mode: Any) -> bool:
    normalized = str(mode or "").strip()
    return bool(normalized) and any(token in normalized for token in ("w", "a", "x", "+"))


def _is_verifiedx_debug_artifact_path(
    installer: "ZeroTouchRuntimeInstaller | None",
    target: str,
) -> bool:
    if installer is None:
        return False
    verifiedx = getattr(installer, "verifiedx", None)
    debug_path = getattr(verifiedx, "_debug_path", None)
    debug_dir = getattr(getattr(verifiedx, "config", None), "debug_dir", None)
    if not target:
        return False
    try:
        target_path = pathlib.Path(target).expanduser().resolve()
        if debug_path and target_path == pathlib.Path(debug_path).expanduser().resolve():
            return True
        if debug_dir:
            debug_dir_path = pathlib.Path(debug_dir).expanduser().resolve()
            return target_path == debug_dir_path or debug_dir_path in target_path.parents
    except Exception:
        return False
    return False


def _generic_file_boundary_capture(
    *,
    target: str,
    operation: str,
    transport_args: dict[str, Any],
) -> dict[str, Any]:
    capture_tool = {
        "tool_name": operation,
        "schema": {"type": "object", "additionalProperties": True},
        "docstring": "Runtime-inferred file write observed at the Python core lower seam.",
        "args": transport_args,
        "metadata": {
            "raw_name": operation,
            "semantic_class": "system_mutation",
        },
    }
    return {
        "tool_descriptor": capture_tool,
        "surface": "file_write",
        "operation": operation,
        "target": target,
        "method": "WRITE",
        "transport_args": transport_args,
        "boundary_kind": "action_execute",
        "action_class": "system_change",
        "trust_boundary_crossing": False,
    }


def _path_leaf(target: str) -> str:
    return str(target or "").replace("\\", "/").rstrip("/").split("/")[-1].strip()


def _path_stem(target: str) -> str:
    leaf = _path_leaf(target)
    if "." in leaf:
        return leaf.rsplit(".", 1)[0].strip()
    return leaf


def _assistant_message_value_matches(candidate: Any, message: str) -> bool:
    if not isinstance(candidate, str):
        return False
    normalized = candidate.strip()
    if not normalized or not message:
        return False
    return normalized == message or message in normalized or normalized in message


def _assistant_message_payload_matches(payload: dict[str, Any], message: str) -> bool:
    for key in (
        "assistant_message",
        "reply",
        "response",
        "final_answer",
        "answer",
        "message",
        "content",
        "text",
    ):
        if _assistant_message_value_matches(payload.get(key), message):
            return True
    nested = payload.get("data")
    if isinstance(nested, dict):
        return _assistant_message_payload_matches(nested, message)
    return False


def _assistant_message_context_target(
    container_contexts: list[tuple[str, Any]],
) -> str | None:
    if not container_contexts:
        return None
    for preferred in _ASSISTANT_MESSAGE_TARGET_CONTAINERS:
        for container_name, item in container_contexts:
            if container_name != preferred:
                continue
            if isinstance(item, dict):
                for id_key in _ASSISTANT_MESSAGE_TARGET_ID_KEYS:
                    value = item.get(id_key)
                    if isinstance(value, (str, int)) and str(value).strip():
                        return f"{container_name}/{value}"
            return container_name
    return None


def _assistant_message_target_from_payload(
    payload: Any,
    *,
    message: str,
    container_contexts: list[tuple[str, Any]] | None = None,
) -> str | None:
    contexts = list(container_contexts or [])
    if isinstance(payload, dict):
        if _assistant_message_payload_matches(payload, message):
            target = _assistant_message_context_target(contexts)
            if target:
                return target
        for key, value in payload.items():
            normalized_key = str(key).strip().lower()
            if isinstance(value, list):
                next_contexts = contexts
                if normalized_key in _ASSISTANT_MESSAGE_TARGET_CONTAINERS:
                    for item in value:
                        target = _assistant_message_target_from_payload(
                            item,
                            message=message,
                            container_contexts=contexts + [(normalized_key, item)],
                        )
                        if target:
                            return target
                    continue
                target = _assistant_message_target_from_payload(
                    value,
                    message=message,
                    container_contexts=next_contexts,
                )
                if target:
                    return target
                continue
            target = _assistant_message_target_from_payload(
                value,
                message=message,
                container_contexts=contexts,
            )
            if target:
                return target
        return None
    if isinstance(payload, list):
        for item in payload:
            target = _assistant_message_target_from_payload(
                item,
                message=message,
                container_contexts=contexts,
            )
            if target:
                return target
    return None


def _assistant_message_logical_target(
    *,
    target: str,
    data_text: str,
    message: str,
) -> str:
    if message:
        try:
            stripped = data_text.lstrip()
            if stripped.startswith("{") or stripped.startswith("["):
                parsed = json.loads(data_text)
                derived = _assistant_message_target_from_payload(parsed, message=message)
                if derived:
                    return derived
        except Exception:
            pass
    stem = _path_stem(target)
    if stem:
        return stem
    return "assistant_message"


def _assistant_message_file_capture(
    installer: "ZeroTouchRuntimeInstaller | None",
    tool_descriptor: dict[str, Any] | None,
    *,
    target: str,
    data_text: str,
) -> dict[str, Any] | None:
    if not _assistant_message_matches_file_write(
        tool_descriptor,
        target=target,
        data_text=data_text,
    ):
        return None
    message = str(((tool_descriptor or {}).get("args") or {}).get("message") or "").strip()
    logical_target = "assistant_message"
    if installer is not None and message:
        support_object = _assistant_output_object(
            installer,
            content=message,
            source="runtime.assistant_output.file_write",
            target=logical_target,
            metadata={
                "storage_target": target,
                "storage_surface": "file_write",
            },
            lineage_label="assistant_boundary_candidate",
        )
        _remember_runtime_support_object(installer, support_object)
        installer._take_recent_assistant_output(content=message)
    tool_args = {
        "message": message,
    }
    capture_tool = {
        "tool_name": "assistant_message",
        "schema": ((tool_descriptor or {}).get("schema") or {"type": "object", "additionalProperties": True}),
        "docstring": (
            (tool_descriptor or {}).get("docstring")
            or "Runtime-inferred assistant reply produced without an explicit tool wrapper."
        ),
        "args": tool_args,
    }
    return {
        "tool_descriptor": capture_tool,
        "surface": "tool_dispatch",
        "operation": "assistant_message",
        "target": logical_target,
        "method": "CALL",
        "transport_args": tool_args,
        "boundary_kind": None,
        "action_class": "external_message_send",
        "trust_boundary_crossing": _tool_dispatch_crosses_boundary(logical_target, tool_args),
    }


def _assistant_message_matches_file_write(
    tool_descriptor: dict[str, Any] | None,
    *,
    target: str,
    data_text: str,
) -> bool:
    if not _tool_descriptor_looks_assistant_message(tool_descriptor):
        return False
    target_tokens = _normalized_identifier_tokens(target)
    if not (target_tokens & _FILE_ASSISTANT_MESSAGE_TARGET_HINTS):
        return False
    message = str(((tool_descriptor or {}).get("args") or {}).get("message") or "").strip()
    if not message:
        return False
    return message in data_text or message[:120] in data_text


def _file_boundary_details(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    target: str,
    data_text: str,
    operation: str = "write_file",
) -> dict[str, Any] | None:
    tool_descriptor = _ambient_tool_descriptor(installer)
    capture = _assistant_message_file_capture(
        installer,
        tool_descriptor,
        target=target,
        data_text=data_text,
    )
    if capture is not None:
        return capture
    return _generic_file_boundary_capture(
        target=target,
        operation=operation,
        transport_args={
            "path": target,
            "data_preview": data_text[:4000],
            "write_kind": "write",
        },
    )


def _botocore_dynamodb_target(api_params: dict[str, Any]) -> str:
    if isinstance(api_params, dict):
        table = api_params.get("TableName")
        if isinstance(table, str) and table:
            return f"dynamodb://{table}"
        request_items = api_params.get("RequestItems")
        if isinstance(request_items, dict) and request_items:
            table_name = next(iter(request_items.keys()), None)
            if table_name:
                return f"dynamodb://{table_name}"
        transact_items = api_params.get("TransactItems")
        if isinstance(transact_items, list):
            for item in transact_items:
                if not isinstance(item, dict):
                    continue
                for operation in item.values():
                    if isinstance(operation, dict) and isinstance(operation.get("TableName"), str):
                        return f"dynamodb://{operation['TableName']}"
    return "dynamodb://mutation"


def _botocore_queue_target(service_name: str, api_params: dict[str, Any]) -> str:
    if isinstance(api_params, dict):
        if isinstance(api_params.get("QueueUrl"), str) and api_params["QueueUrl"]:
            return api_params["QueueUrl"]
        if isinstance(api_params.get("TopicArn"), str) and api_params["TopicArn"]:
            return api_params["TopicArn"]
        if isinstance(api_params.get("EventBusName"), str) and api_params["EventBusName"]:
            return f"eventbridge://{api_params['EventBusName']}"
    return f"{service_name}://publish"


def _botocore_boundary_details(
    service_name: str,
    operation_name: str,
    api_params: dict[str, Any],
) -> dict[str, Any] | None:
    normalized_service = str(service_name or "").lower()
    normalized_operation = str(operation_name or "")
    if normalized_service == "dynamodb" and normalized_operation in {
        "BatchWriteItem",
        "DeleteItem",
        "PutItem",
        "TransactWriteItems",
        "UpdateItem",
    }:
        return {
            "surface": "db_mutation",
            "target": _botocore_dynamodb_target(api_params),
            "trust_boundary_crossing": False,
            "action_class": "record_mutation",
        }
    if normalized_service in {"sqs", "sns", "events"} and normalized_operation in {
        "Publish",
        "PublishBatch",
        "PutEvents",
        "SendMessage",
        "SendMessageBatch",
    }:
        return {
            "surface": "queue_publish",
            "target": _botocore_queue_target(normalized_service, api_params),
            "trust_boundary_crossing": True,
            "action_class": "upload",
        }
    return None


def _browser_action_class(operation: str) -> str:
    return "browser_navigate" if operation == "goto" else "browser_submit"


def _browser_target(instance: Any, args: tuple[Any, ...]) -> str:
    page_url = getattr(instance, "url", None)
    selector = args[0] if args and isinstance(args[0], str) else None
    if isinstance(page_url, str) and page_url:
        if selector:
            return f"{page_url}{selector}" if selector.startswith(("#", "/", "?")) else f"{page_url}#{selector}"
        return page_url
    if selector:
        return selector
    return instance.__class__.__name__


class _DbCursorProxy:
    def __init__(self, connection_proxy: "_DbConnectionProxy", cursor: Any):
        self._connection_proxy = connection_proxy
        self._cursor = cursor

    def execute(self, statement, *args, **kwargs):
        return self._connection_proxy._intercept_sql_call(
            "dbapi.cursor.execute",
            self._cursor.execute,
            statement,
            *args,
            **kwargs,
        )

    def executemany(self, statement, *args, **kwargs):
        return self._connection_proxy._intercept_sql_call(
            "dbapi.cursor.executemany",
            self._cursor.executemany,
            statement,
            *args,
            **kwargs,
        )

    def executescript(self, statement, *args, **kwargs):
        executescript = getattr(self._cursor, "executescript", None)
        if executescript is None:
            raise AttributeError("underlying cursor does not implement executescript")
        return self._connection_proxy._intercept_sql_call(
            "dbapi.cursor.executescript",
            executescript,
            statement,
            *args,
            **kwargs,
        )

    def __iter__(self):
        return iter(self._cursor)

    def __enter__(self):
        entered = self._cursor.__enter__() if hasattr(self._cursor, "__enter__") else self._cursor
        if entered is self._cursor:
            return self
        return _DbCursorProxy(self._connection_proxy, entered)

    def __exit__(self, exc_type, exc, tb):
        if hasattr(self._cursor, "__exit__"):
            return self._cursor.__exit__(exc_type, exc, tb)
        return None

    def __getattr__(self, name: str):
        return getattr(self._cursor, name)


class _DbConnectionProxy:
    def __init__(self, connection: Any, *, dialect: str, dsn: str | None = None):
        self._connection = connection
        self._dialect = dialect
        self._dsn = dsn

    def _intercept_sql_call(self, operation: str, execute, statement, *args, **kwargs):
        if runtime_capture_suppressed():
            return execute(statement, *args, **kwargs)
        installer = _current_or_default_installer()
        if installer is None or not _looks_like_sql_mutation(statement):
            return execute(statement, *args, **kwargs)
        sql_text = _normalized_sql_text(statement)
        target = _sql_target(sql_text, default=self._dsn or self._dialect)
        transport_args = {
            "dialect": self._dialect,
            "statement": sql_text,
            "parameters": _jsonable(args[0] if args else kwargs.get("parameters")),
        }
        if _should_skip_sql_boundary_capture(installer, target=target, transport_args=transport_args):
            return execute(statement, *args, **kwargs)
        boundary_kind, action_class = _sql_boundary_overrides(
            installer,
            target=target,
            transport_args=transport_args,
        )
        boundary_transport_args = _sql_transport_args_for_boundary(
            installer,
            transport_args=transport_args,
        )
        return installer.intercept_boundary(
            surface="db_mutation",
            operation=operation,
            target=target,
            method=_sql_operation(sql_text),
            transport_args=boundary_transport_args,
            boundary_kind=boundary_kind,
            action_class=action_class,
            trust_boundary_crossing=False,
            execute=lambda: execute(statement, *args, **kwargs),
        )

    def cursor(self, *args, **kwargs):
        return _DbCursorProxy(self, self._connection.cursor(*args, **kwargs))

    def execute(self, statement, *args, **kwargs):
        return self._intercept_sql_call(
            "dbapi.connection.execute",
            self._connection.execute,
            statement,
            *args,
            **kwargs,
        )

    def executemany(self, statement, *args, **kwargs):
        return self._intercept_sql_call(
            "dbapi.connection.executemany",
            self._connection.executemany,
            statement,
            *args,
            **kwargs,
        )

    def executescript(self, statement, *args, **kwargs):
        executescript = getattr(self._connection, "executescript", None)
        if executescript is None:
            raise AttributeError("underlying connection does not implement executescript")
        return self._intercept_sql_call(
            "dbapi.connection.executescript",
            executescript,
            statement,
            *args,
            **kwargs,
        )

    def __enter__(self):
        entered = (
            self._connection.__enter__()
            if hasattr(self._connection, "__enter__")
            else self._connection
        )
        return _wrap_db_connection(entered, dialect=self._dialect, dsn=self._dsn)

    def __exit__(self, exc_type, exc, tb):
        if hasattr(self._connection, "__exit__"):
            return self._connection.__exit__(exc_type, exc, tb)
        return None

    def __getattr__(self, name: str):
        return getattr(self._connection, name)


def _wrap_db_connection(connection: Any, *, dialect: str, dsn: str | None = None):
    if isinstance(connection, _DbConnectionProxy):
        return connection
    return _DbConnectionProxy(connection, dialect=dialect, dsn=dsn)


def runtime_capture_suppressed() -> bool:
    return _SUPPRESS_RUNTIME_CAPTURE.get() > 0


@contextmanager
def suppress_runtime_capture():
    token = _SUPPRESS_RUNTIME_CAPTURE.set(_SUPPRESS_RUNTIME_CAPTURE.get() + 1)
    try:
        yield
    finally:
        _SUPPRESS_RUNTIME_CAPTURE.reset(token)


def _current_tool_invocation() -> "ToolInvocationContext | None":
    return _CURRENT_TOOL_INVOCATION.get()


def _running_loop_or_none():
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        return None


@dataclass
class ToolInvocationContext:
    installer: "ZeroTouchRuntimeInstaller"
    tool_name: str
    tool_args: dict[str, Any]
    schema: dict[str, Any]
    docstring: str | None
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str = "sdk_tool_wrapper"
    tool_call_id: str | None = None

    def descriptor(self) -> dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "schema": self.schema,
            "docstring": self.docstring,
            "args": self.tool_args,
            "metadata": _jsonable(self.metadata),
        }


class RuntimeExecutionFailureError(RuntimeError):
    def __init__(self, tool_result: dict):
        self.tool_result = tool_result
        super().__init__("VerifiedX observed an execution-time failure after an allowed attempt")


class RuntimeBoundaryDeniedError(BoundaryDeniedError):
    def __init__(
        self,
        decision: dict,
        *,
        boundary_kind: str | None = None,
        action_class: str | None = None,
        goal_state_hint: str | None = None,
        pending_effect: dict | None = None,
    ):
        super().__init__(decision)
        self.boundary_kind = boundary_kind
        self.action_class = action_class
        self.goal_state_hint = goal_state_hint
        self.pending_effect = pending_effect or {}


@dataclass
class ZeroTouchRuntimeInstaller:
    verifiedx: Any
    report: Any | None = None
    installed_surfaces: list[str] = field(default_factory=list)
    _recent_conversation: list[dict[str, Any]] = field(default_factory=list)
    _recent_tool_selections: list[dict[str, Any]] = field(default_factory=list)
    _recent_assistant_outputs: list[dict[str, Any]] = field(default_factory=list)
    _pending_async_tasks: list[Any] = field(default_factory=list)
    _tool_preflight_cache: list[dict[str, Any]] = field(default_factory=list)
    _observed_tool_call_ids_by_run: dict[str, set[str]] = field(default_factory=dict)
    _taint_checked_prompt_object_ids: set[str] = field(default_factory=set)
    _conversation_sequence: int = 0

    def set_default(self):
        global _DEFAULT_INSTALLER
        _DEFAULT_INSTALLER = self

    def install(self, *, report):
        self.report = report
        self.set_default()
        _install_global_patches()
        return report

    @property
    def active(self) -> bool:
        return self.report is not None

    def _runtime_scope(self) -> str:
        current = getattr(self.verifiedx, "current_runtime_scope", None)
        if callable(current):
            return str(current())
        return "runtime:default"

    def mark_selected_tool_call_observed(self, tool_call_id: str | None) -> bool:
        text = str(tool_call_id or "").strip()
        if not text:
            return True
        context = self.verifiedx.capture.current_context()
        run_key = str(getattr(context, "run_id", None) or self._runtime_scope())
        observed = self._observed_tool_call_ids_by_run.setdefault(run_key, set())
        if text in observed:
            return False
        observed.add(text)
        while len(self._observed_tool_call_ids_by_run) > 32:
            oldest_key = next(iter(self._observed_tool_call_ids_by_run))
            if oldest_key == run_key and len(self._observed_tool_call_ids_by_run) == 1:
                break
            self._observed_tool_call_ids_by_run.pop(oldest_key, None)
        return True

    def _current_conversation_entry(self) -> dict[str, Any] | None:
        scope = self._runtime_scope()
        best_entry = None
        best_rank = (-1, -1, float("-inf"))
        for entry in self._recent_conversation:
            if str(entry.get("runtime_scope") or "") != scope:
                continue
            rank = _conversation_entry_rank(entry)
            if rank >= best_rank:
                best_entry = entry
                best_rank = rank
        return best_entry

    def _current_conversation_index(self) -> int | None:
        scope = self._runtime_scope()
        best_index = None
        best_rank = (-1, -1, float("-inf"))
        for index, entry in enumerate(self._recent_conversation):
            if str(entry.get("runtime_scope") or "") != scope:
                continue
            rank = _conversation_entry_rank(entry)
            if rank >= best_rank:
                best_index = index
                best_rank = rank
        return best_index

    def _conversation_entry_for_scope(
        self,
        scope: str,
        *,
        sequence: int | None = None,
    ) -> dict[str, Any] | None:
        target_scope = str(scope or "")
        for entry in reversed(self._recent_conversation):
            if str(entry.get("runtime_scope") or "") != target_scope:
                continue
            if sequence is not None and entry.get("sequence") != sequence:
                continue
            return entry
        return None

    @staticmethod
    def _entry_timestamp_unix(entry: dict[str, Any] | None) -> float:
        if not isinstance(entry, dict):
            return 0.0
        for key in ("captured_at_unix", "recorded_at_unix"):
            try:
                value = float(entry.get(key) or 0.0)
            except Exception:
                value = 0.0
            if value > 0.0:
                return value
        return 0.0

    def _within_cross_scope_association_window(
        self,
        entry: dict[str, Any] | None,
        *,
        reference_ts: float | None = None,
    ) -> bool:
        entry_ts = self._entry_timestamp_unix(entry)
        if entry_ts <= 0.0:
            return False
        now_ts = datetime.now(timezone.utc).timestamp()
        if abs(now_ts - entry_ts) > _CROSS_SCOPE_ASSOCIATION_WINDOW_SECONDS:
            return False
        if reference_ts is not None and abs(reference_ts - entry_ts) > _CROSS_SCOPE_ASSOCIATION_WINDOW_SECONDS:
            return False
        return True

    def _tool_cache_entry_matches(
        self,
        entry: dict[str, Any],
        *,
        tool_name: str,
        tool_args_hash: str,
        boundary_kind: str,
        surface: str,
        target: str,
        transport_args: dict[str, Any],
    ) -> bool:
        if entry.get("boundary_kind") != boundary_kind:
            return False
        cached_descriptor = entry.get("tool_descriptor") or {}
        cached_name = str(cached_descriptor.get("tool_name") or "").strip()
        if tool_name and cached_name and tool_name != cached_name:
            return False
        if _hash_jsonable(_tool_descriptor_arguments(cached_descriptor)) == tool_args_hash:
            return True
        if boundary_kind == "memory_write" and surface == "db_mutation":
            if _sql_mutation_looks_memory_effect(
                cached_descriptor,
                target=target,
                transport_args=transport_args,
            ):
                return True
        return False

    def _recover_cross_scope_conversation_entry(
        self,
        *,
        tool_descriptor: dict[str, Any] | None,
        boundary_kind: str,
        surface: str,
        target: str,
        transport_args: dict[str, Any],
    ) -> dict[str, Any] | None:
        if not isinstance(tool_descriptor, dict):
            return None
        tool_name = str(tool_descriptor.get("tool_name") or "").strip()
        tool_args_hash = _hash_jsonable(_tool_descriptor_arguments(tool_descriptor))
        cached_preflight = self._matching_tool_preflight(
            tool_descriptor=tool_descriptor,
            boundary_kind=boundary_kind,
            surface=surface,
            target=target,
            transport_args=transport_args,
            allow_cross_scope=True,
        )
        if cached_preflight is not None:
            cached_ts = self._entry_timestamp_unix(cached_preflight)
            cached_entry = self._conversation_entry_for_scope(
                str(cached_preflight.get("runtime_scope") or ""),
                sequence=cached_preflight.get("sequence"),
            )
            if self._within_cross_scope_association_window(cached_entry, reference_ts=cached_ts):
                recovered = dict(cached_entry)
                weak_signals = list(recovered.get("weak_signals") or [])
                weak_signals.extend(
                    [
                        "cross_scope_conversation_recovered",
                        "cross_scope_preflight_match",
                    ]
                )
                recovered["weak_signals"] = sorted(dict.fromkeys(weak_signals))
                return recovered
        for selection in reversed(self._recent_tool_selections):
            if not self._within_cross_scope_association_window(selection):
                continue
            descriptor = selection.get("descriptor") or {}
            selected_name = str(descriptor.get("tool_name") or "").strip()
            if tool_name and selected_name and tool_name != selected_name:
                continue
            if _hash_jsonable(_tool_descriptor_arguments(descriptor)) != tool_args_hash:
                continue
            recovered_entry = self._conversation_entry_for_scope(
                str(selection.get("runtime_scope") or ""),
                sequence=selection.get("sequence"),
            )
            selection_ts = self._entry_timestamp_unix(selection)
            if not self._within_cross_scope_association_window(recovered_entry, reference_ts=selection_ts):
                continue
            recovered = dict(recovered_entry)
            weak_signals = list(recovered.get("weak_signals") or [])
            weak_signals.extend(
                [
                    "cross_scope_conversation_recovered",
                    "cross_scope_tool_selection_match",
                ]
            )
            recovered["weak_signals"] = sorted(dict.fromkeys(weak_signals))
            return recovered
        return None

    def _reconstruct_conversation_window_from_recent_objects(
        self,
        *,
        tool_descriptor: dict[str, Any] | None,
        boundary_kind: str,
        surface: str,
        target: str,
        transport_args: dict[str, Any],
    ) -> dict[str, Any] | None:
        hint_payload = {
            "boundary_kind": boundary_kind,
            "surface": surface,
            "target": target,
            "tool_descriptor": tool_descriptor or {},
            "transport_args": transport_args or {},
        }
        hint_strings = _scalar_text_fragments(hint_payload)
        hint_tokens: set[str] = set()
        for fragment in hint_strings:
            hint_tokens |= _normalized_identifier_tokens(fragment)

        scored_references: list[tuple[int, int, dict[str, Any]]] = []
        for entry in self.verifiedx.capture.recent_objects_across_runs(limit=128):
            reference = _recent_object_reference(entry)
            if reference is None:
                continue
            score = _recent_reference_relevance_score(
                reference,
                selected_object_ids=set(),
                hint_strings=hint_strings,
                hint_tokens=hint_tokens,
            )
            if score <= 0 and hint_strings:
                continue
            scored_references.append((score, int(reference.get("sequence") or 0), reference))
        if not scored_references:
            return None

        prompt_groups: dict[tuple[str, str], list[tuple[int, int, dict[str, Any]]]] = {}
        for score, sequence, reference in scored_references:
            payload = reference.get("normalized_payload")
            if not isinstance(payload, dict):
                continue
            role = str(payload.get("role") or "").strip().lower()
            content = _content_text(payload.get("content"))
            source_lineage = {str(item).strip().lower() for item in reference.get("source_lineage") or []}
            if "prompt_frame" not in source_lineage and not (role and content):
                continue
            source = str(payload.get("source") or "")
            group_key = (str(reference.get("run_id") or ""), source)
            prompt_groups.setdefault(group_key, []).append((score, sequence, reference))
        if not prompt_groups:
            return None

        selected_group = None
        selected_rank: tuple[int, int, int] | None = None
        for group_key, group_entries in prompt_groups.items():
            score_sum = sum(max(score, 0) for score, _, _ in group_entries)
            max_sequence = max((sequence for _, sequence, _ in group_entries), default=0)
            max_score = max((score for score, _, _ in group_entries), default=0)
            rank = (score_sum, max_score, max_sequence)
            if selected_rank is None or rank > selected_rank:
                selected_rank = rank
                selected_group = (group_key, group_entries)
        if selected_group is None:
            return None

        (_, source), group_entries = selected_group
        group_entries.sort(key=lambda item: item[1])
        messages: list[dict[str, Any]] = []
        prompt_object_ids: list[str] = []
        for _, _, reference in group_entries[-12:]:
            payload = reference.get("normalized_payload") or {}
            content = _content_text(payload.get("content"))
            if not content:
                continue
            prompt_object_ids.append(str(reference.get("object_id") or ""))
            messages.append(
                {
                    "role": str(payload.get("role") or "unknown"),
                    "content": content,
                    "message_id": str(
                        payload.get("message_id")
                        or reference.get("object_id")
                        or f"msg_{len(messages)}"
                    ),
                    "timestamp": payload.get("timestamp"),
                }
            )
        prompt_object_ids = [object_id for object_id in prompt_object_ids if object_id]
        if not messages:
            return None

        relevant_references = sorted(
            scored_references,
            key=lambda item: (-item[0], -item[1]),
        )
        inserted_context_object_ids = list(prompt_object_ids)
        seen_object_ids = set(inserted_context_object_ids)
        for score, _, reference in relevant_references:
            object_id = str(reference.get("object_id") or "")
            if not object_id or object_id in seen_object_ids:
                continue
            if score <= 0 and inserted_context_object_ids:
                continue
            inserted_context_object_ids.append(object_id)
            seen_object_ids.add(object_id)
            if len(inserted_context_object_ids) >= 12:
                break

        capture_source_kind = _capture_source_kind_from_source(source)
        weak_signals = [
            "cross_run_conversation_reconstructed",
            "cross_run_prompt_frame_join",
        ]
        if len(inserted_context_object_ids) > len(prompt_object_ids):
            weak_signals.append("cross_run_context_join")
        return {
            "sequence": None,
            "source": source or "runtime_install",
            "model_name": None,
            "tool_call_id": None,
            "request_kind": "messages",
            "request_metadata": {},
            "tool_choice": None,
            "tool_definitions": [],
            "tool_call_ids": [],
            "inserted_context_object_ids": inserted_context_object_ids,
            "omission_events": [],
            "supported_adapter": True,
            "capture_gap_codes": [],
            "weak_signals": sorted(dict.fromkeys(weak_signals)),
            "capture_source_kind": capture_source_kind,
            "capture_sources": [capture_source_kind],
            "normalized_span_count": 0,
            "invocation_merge_key": None,
            "captured_at": datetime.now(timezone.utc).isoformat(),
            "captured_at_unix": datetime.now(timezone.utc).timestamp(),
            "selected_tools": [],
            "messages": messages,
        }

    def _track_async_task(self, task) -> None:
        self._pending_async_tasks.append(task)

        def _remove(completed):
            try:
                self._pending_async_tasks.remove(completed)
            except ValueError:
                pass

        task.add_done_callback(_remove)

    def defer_ingress_observation(
        self,
        *,
        object_payload: dict[str, Any],
        phase: str,
        source_uri: str | None = None,
        source_hint: str | None = None,
    ) -> None:
        loop = _running_loop_or_none()
        if loop is None:
            return

        async def _runner():
            try:
                diagnostic = await self.observe_ingress_async(
                    object_payload,
                    source_uri=source_uri,
                    source_hint=source_hint,
                )
                if diagnostic is not None:
                    request_payload, response = diagnostic
                    self.verifiedx.record_ingress_diagnostic(phase, request_payload, response)
            except Exception:
                if self.verifiedx.config.strict_direct_ingress_labeling:
                    raise

        self._track_async_task(loop.create_task(_runner()))

    async def flush_pending_async_tasks(self) -> None:
        if not self._pending_async_tasks:
            return
        pending = list(self._pending_async_tasks)
        self._pending_async_tasks.clear()
        results = await asyncio.gather(*pending, return_exceptions=True)
        if self.verifiedx.config.strict_direct_ingress_labeling:
            for result in results:
                if isinstance(result, Exception):
                    raise result

    def _remember_tool_preflight(
        self,
        *,
        tool_descriptor: dict[str, Any],
        tool_call_id: str | None,
        boundary_kind: str,
        action_class: str | None,
        target: str,
        observed_boundary: dict[str, Any],
        candidate_hash: str,
        decision: dict[str, Any],
        pending_action_fingerprint: str | None = None,
    ) -> None:
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        conversation_source = current_entry.get("source") if current_entry else None
        recorded_at = datetime.now(timezone.utc)
        self._tool_preflight_cache.append(
            {
                "runtime_scope": self._runtime_scope(),
                "sequence": current_sequence,
                "conversation_source": conversation_source,
                "pending_action_fingerprint": pending_action_fingerprint
                or _pending_action_fingerprint_from_observed_boundary(observed_boundary),
                "tool_call_id": tool_call_id,
                "tool_descriptor": _jsonable(tool_descriptor),
                "boundary_kind": boundary_kind,
                "action_class": action_class,
                "target": target,
                "observed_boundary": observed_boundary,
                "candidate_hash": candidate_hash,
                "decision": decision,
                "recorded_at": recorded_at.isoformat(),
                "recorded_at_unix": recorded_at.timestamp(),
            }
        )
        if len(self._tool_preflight_cache) > 32:
            del self._tool_preflight_cache[:-32]

    def _matching_tool_preflight(
        self,
        *,
        tool_descriptor: dict[str, Any] | None,
        tool_call_id: str | None = None,
        boundary_kind: str,
        surface: str,
        target: str,
        transport_args: dict[str, Any],
        allow_cross_scope: bool = False,
        allow_unconsumed_cross_sequence: bool = False,
    ) -> dict[str, Any] | None:
        if not isinstance(tool_descriptor, dict):
            return None
        scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        tool_name = str(tool_descriptor.get("tool_name") or "").strip()
        tool_args_hash = _hash_jsonable(tool_descriptor.get("args") or {})
        tool_call_id_text = str(tool_call_id).strip() if tool_call_id is not None else ""
        now_ts = datetime.now(timezone.utc).timestamp()
        if tool_call_id_text:
            for entry in reversed(self._tool_preflight_cache):
                if str(entry.get("tool_call_id") or "").strip() != tool_call_id_text:
                    continue
                if entry.get("consumed_at") is not None:
                    continue
                entry_scope = str(entry.get("runtime_scope") or "")
                if entry_scope != scope:
                    recorded_at_unix = self._entry_timestamp_unix(entry)
                    if recorded_at_unix <= 0.0:
                        continue
                    if abs(now_ts - recorded_at_unix) > _UNCONSUMED_PREFLIGHT_REUSE_WINDOW_SECONDS:
                        continue
                if self._tool_cache_entry_matches(
                    entry,
                    tool_name=tool_name,
                    tool_args_hash=tool_args_hash,
                    boundary_kind=boundary_kind,
                    surface=surface,
                    target=target,
                    transport_args=transport_args,
                ):
                    return entry
        for entry in reversed(self._tool_preflight_cache):
            if str(entry.get("runtime_scope") or "") != scope:
                continue
            if current_sequence is not None and entry.get("sequence") != current_sequence:
                continue
            if entry.get("consumed_at") is not None:
                continue
            if self._tool_cache_entry_matches(
                entry,
                tool_name=tool_name,
                tool_args_hash=tool_args_hash,
                boundary_kind=boundary_kind,
                surface=surface,
                target=target,
                    transport_args=transport_args,
            ):
                return entry
        if allow_unconsumed_cross_sequence:
            for entry in reversed(self._tool_preflight_cache):
                if str(entry.get("runtime_scope") or "") != scope:
                    continue
                if current_sequence is not None and entry.get("sequence") == current_sequence:
                    continue
                if entry.get("consumed_at") is not None:
                    continue
                recorded_at_unix = self._entry_timestamp_unix(entry)
                if recorded_at_unix <= 0.0:
                    continue
                if abs(now_ts - recorded_at_unix) > _UNCONSUMED_PREFLIGHT_REUSE_WINDOW_SECONDS:
                    continue
                if self._tool_cache_entry_matches(
                    entry,
                    tool_name=tool_name,
                    tool_args_hash=tool_args_hash,
                    boundary_kind=boundary_kind,
                    surface=surface,
                    target=target,
                    transport_args=transport_args,
                ):
                    return entry
        if not allow_cross_scope:
            return None
        for entry in reversed(self._tool_preflight_cache):
            if str(entry.get("runtime_scope") or "") == scope:
                continue
            if not self._within_cross_scope_association_window(entry):
                continue
            if entry.get("consumed_at") is not None:
                continue
            if self._tool_cache_entry_matches(
                entry,
                tool_name=tool_name,
                tool_args_hash=tool_args_hash,
                boundary_kind=boundary_kind,
                surface=surface,
                target=target,
                transport_args=transport_args,
            ):
                return entry
        return None

    @staticmethod
    def _mark_tool_preflight_consumed(
        entry: dict[str, Any] | None,
        *,
        phase: str,
    ) -> None:
        if not isinstance(entry, dict):
            return
        if entry.get("consumed_at") is not None:
            return
        consumed_at = datetime.now(timezone.utc)
        entry["consumed_at"] = consumed_at.isoformat()
        entry["consumed_at_unix"] = consumed_at.timestamp()
        entry["consumed_by_phase"] = phase

    def note_assistant_output(self, *, content: str, source: str) -> None:
        text = str(content or "").strip()
        if not text:
            return
        self._remember_assistant_output(text=text, source=source)

    async def note_assistant_output_async(self, *, content: str, source: str) -> None:
        text = str(content or "").strip()
        if not text:
            return
        self._remember_assistant_output(text=text, source=source)

    def _remember_assistant_output(self, *, text: str, source: str) -> dict[str, Any]:
        object_payload = _assistant_output_object(
            self,
            content=text,
            source=source,
        )
        _remember_runtime_support_object(self, object_payload)
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        self._recent_assistant_outputs.append(
            {
                "runtime_scope": self._runtime_scope(),
                "sequence": current_sequence,
                "source": source,
                "content": text,
                "content_hash": _hash_jsonable(text),
                "object_id": object_payload.get("object_id"),
            }
        )
        if len(self._recent_assistant_outputs) > 12:
            del self._recent_assistant_outputs[:-12]
        if self.verifiedx.config.debug_decisions:
            self.verifiedx._write_debug_record(
                {
                    "kind": "verifiedx_assistant_output",
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "source": source,
                    "sequence": current_sequence,
                    "object_id": object_payload.get("object_id"),
                    "content_excerpt": text[:240],
                }
            )
        return object_payload

    def _take_recent_assistant_output(self, *, content: str) -> dict[str, Any] | None:
        text = str(content or "").strip()
        if not text:
            return None
        scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        for require_same_sequence in (True, False):
            if require_same_sequence and current_sequence is None:
                continue
            for index in range(len(self._recent_assistant_outputs) - 1, -1, -1):
                entry = self._recent_assistant_outputs[index]
                if str(entry.get("runtime_scope") or "") != scope:
                    continue
                if require_same_sequence and entry.get("sequence") != current_sequence:
                    continue
                if str(entry.get("content") or "").strip() != text:
                    continue
                return self._recent_assistant_outputs.pop(index)
        return None
    def _recent_assistant_output_descriptor(self) -> dict[str, Any] | None:
        scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        for index in range(len(self._recent_assistant_outputs) - 1, -1, -1):
            record = self._recent_assistant_outputs[index]
            if str(record.get("runtime_scope") or "") != scope:
                continue
            if current_sequence is not None and record.get("sequence") != current_sequence:
                continue
            content = str(record.get("content") or "").strip()
            if not content:
                continue
            return {
                "tool_name": "assistant_message",
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": "Runtime-inferred assistant reply produced without an explicit tool wrapper.",
                "args": {"message": content},
            }
        return None

    def match_assistant_output(self, payload_text: str) -> dict[str, Any] | None:
        scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        for index in range(len(self._recent_assistant_outputs) - 1, -1, -1):
            entry = self._recent_assistant_outputs[index]
            if str(entry.get("runtime_scope") or "") != scope:
                continue
            if current_sequence is not None and entry.get("sequence") != current_sequence:
                continue
            content = str(entry.get("content") or "")
            if not content:
                continue
            if content in payload_text or content[:120] in payload_text:
                return self._take_recent_assistant_output(content=content)
        return None

    def derive_tool_metadata(
        self,
        fn,
        *,
        tool_name: str,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        schema: dict[str, Any] | None = None,
        docstring: str | None = None,
        metadata: dict[str, Any] | None = None,
        source: str = "sdk_tool_wrapper",
    ) -> ToolInvocationContext:
        normalized_metadata = _jsonable(metadata or {})
        raw_args = _extract_raw_tool_arguments(args, kwargs)
        if isinstance(raw_args, dict) and raw_args:
            normalized_metadata.setdefault("raw_args", raw_args)
        return ToolInvocationContext(
            installer=self,
            tool_name=tool_name,
            tool_args=_bind_arguments(fn, args, kwargs),
            schema=_jsonable(schema) if schema is not None else _safe_schema_from_callable(fn),
            docstring=docstring if docstring is not None else _safe_docstring(fn),
            metadata=normalized_metadata,
            source=source,
        )

    def describe_selected_tool_boundary(
        self,
        *,
        tool_descriptor: dict[str, Any] | None,
        source: str | None,
    ) -> dict[str, Any] | None:
        capture = _shell_command_boundary_details(tool_descriptor)
        if capture is not None:
            return capture
        return _tool_selection_pending_action(tool_descriptor, source=source)

    def requires_direct_tool_boundary(
        self,
        *,
        tool_descriptor: dict[str, Any] | None,
        source: str | None,
    ) -> bool:
        return _tool_descriptor_requires_direct_boundary(tool_descriptor, source=source)

    @contextmanager
    def tool_invocation(self, context: ToolInvocationContext):
        token = _CURRENT_TOOL_INVOCATION.set(context)
        try:
            yield context
        finally:
            _CURRENT_TOOL_INVOCATION.reset(token)

    def record_conversation_window(
        self,
        messages: list[dict[str, Any]] | None,
        *,
        source: str,
        model_name: str | None = None,
        tool_call_id: str | None = None,
        request_kind: str = "messages",
        request_metadata: dict[str, Any] | None = None,
        tool_choice: Any = None,
        tool_definitions: list[dict[str, Any]] | None = None,
        tool_call_ids: list[str] | None = None,
        inserted_context_object_ids: list[str] | None = None,
        omission_events: list[dict[str, Any]] | None = None,
        supported_adapter: bool = True,
        capture_gap_codes: list[str] | None = None,
        weak_signals: list[str] | None = None,
        remember_messages_as_context: bool = False,
        capture_source_kind: str = "runtime_patch",
        normalized_span_count_delta: int = 0,
    ):
        normalized_messages = []
        for index, message in enumerate(messages or []):
            normalized_messages.append(
                {
                    "role": str(message.get("role") or "unknown"),
                    "content": _content_text(message.get("content")),
                    "message_id": str(message.get("id") or f"msg_{index}"),
                    "timestamp": message.get("timestamp"),
                }
            )
        observed_context_ids = list(inserted_context_object_ids or [])
        if remember_messages_as_context and not observed_context_ids:
            for index, message in enumerate(normalized_messages):
                object_payload = _prompt_context_object(
                    self,
                    message,
                    source=source,
                    index=index,
                )
                _remember_prompt_context(
                    self,
                    object_payload,
                    source=source,
                    role=message["role"],
                    message_id=message["message_id"],
                )
                observed_context_ids.append(object_payload["object_id"])
        capture_source_kind = str(capture_source_kind or "runtime_patch")
        current_context = self.verifiedx.capture.current_context()
        recorded_at = datetime.now(timezone.utc)
        runtime_scope = self.verifiedx.current_runtime_scope()
        merge_key = _conversation_merge_key(
            run_id=current_context.run_id,
            messages=normalized_messages,
            model_name=model_name,
            request_kind=request_kind,
            tool_choice=tool_choice,
            tool_definitions=tool_definitions or [],
            tool_call_ids=list(tool_call_ids or ([tool_call_id] if tool_call_id else [])),
        )
        incoming_rank = _capture_source_rank(capture_source_kind)
        incoming_entry = {
            "runtime_scope": runtime_scope,
            "sequence": None,
            "source": source,
            "model_name": model_name,
            "tool_call_id": tool_call_id,
            "request_kind": request_kind,
            "request_metadata": _jsonable(request_metadata or {}),
            "tool_choice": _jsonable(tool_choice),
            "tool_definitions": _jsonable(tool_definitions or []),
            "tool_call_ids": list(tool_call_ids or []),
            "inserted_context_object_ids": observed_context_ids,
            "omission_events": _jsonable(omission_events or []),
            "supported_adapter": supported_adapter,
            "capture_gap_codes": list(capture_gap_codes or []),
            "weak_signals": list(weak_signals or []),
            "selected_tools": [],
            "messages": normalized_messages[-24:],
            "capture_source_kind": capture_source_kind,
            "capture_sources": [capture_source_kind],
            "normalized_span_count": max(0, int(normalized_span_count_delta or 0)),
            "invocation_merge_key": merge_key,
            "captured_at": recorded_at.isoformat(),
            "captured_at_unix": recorded_at.timestamp(),
        }
        merge_index = None
        for index in range(len(self._recent_conversation) - 1, -1, -1):
            existing = self._recent_conversation[index]
            if str(existing.get("runtime_scope") or "") != runtime_scope:
                continue
            if existing.get("invocation_merge_key") != merge_key:
                continue
            age_seconds = abs(recorded_at.timestamp() - float(existing.get("captured_at_unix") or 0.0))
            if age_seconds <= _CONVERSATION_MERGE_WINDOW_SECONDS:
                merge_index = index
                break
        if merge_index is None:
            self._conversation_sequence += 1
            incoming_entry["sequence"] = self._conversation_sequence
            self._recent_conversation.append(incoming_entry)
        else:
            existing = self._recent_conversation.pop(merge_index)
            existing_rank = _capture_source_rank(existing.get("capture_source_kind"))
            merged = dict(existing)
            merged["source"] = _merge_scalar(
                existing.get("source"),
                incoming_entry.get("source"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["model_name"] = _merge_scalar(
                existing.get("model_name"),
                incoming_entry.get("model_name"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["tool_call_id"] = _merge_scalar(
                existing.get("tool_call_id"),
                incoming_entry.get("tool_call_id"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["request_kind"] = _merge_scalar(
                existing.get("request_kind"),
                incoming_entry.get("request_kind"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["request_metadata"] = _merge_mapping(
                existing.get("request_metadata"),
                incoming_entry.get("request_metadata"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["tool_choice"] = _merge_scalar(
                existing.get("tool_choice"),
                incoming_entry.get("tool_choice"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["tool_definitions"] = _merge_scalar(
                existing.get("tool_definitions"),
                incoming_entry.get("tool_definitions"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["tool_call_ids"] = _merge_unique_list(
                existing.get("tool_call_ids"),
                incoming_entry.get("tool_call_ids"),
            )
            merged["inserted_context_object_ids"] = _merge_unique_list(
                existing.get("inserted_context_object_ids"),
                incoming_entry.get("inserted_context_object_ids"),
            )
            merged["omission_events"] = _merge_unique_list(
                existing.get("omission_events"),
                incoming_entry.get("omission_events"),
            )
            merged["supported_adapter"] = _merge_scalar(
                existing.get("supported_adapter"),
                incoming_entry.get("supported_adapter"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["capture_gap_codes"] = _merge_unique_list(
                existing.get("capture_gap_codes"),
                incoming_entry.get("capture_gap_codes"),
            )
            merged["weak_signals"] = _merge_unique_list(
                existing.get("weak_signals"),
                incoming_entry.get("weak_signals"),
            )
            if "duplicate_capture_merged" not in merged["capture_gap_codes"]:
                merged["capture_gap_codes"].append("duplicate_capture_merged")
            merged["messages"] = _merge_scalar(
                existing.get("messages"),
                incoming_entry.get("messages"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["capture_source_kind"] = _merge_scalar(
                existing.get("capture_source_kind"),
                incoming_entry.get("capture_source_kind"),
                existing_rank=existing_rank,
                incoming_rank=incoming_rank,
            )
            merged["capture_sources"] = _merge_unique_list(
                existing.get("capture_sources"),
                incoming_entry.get("capture_sources"),
            )
            merged["normalized_span_count"] = int(existing.get("normalized_span_count") or 0) + max(
                0,
                int(normalized_span_count_delta or 0),
            )
            merged["invocation_merge_key"] = merge_key
            merged["captured_at"] = recorded_at.isoformat()
            merged["captured_at_unix"] = recorded_at.timestamp()
            if not merged.get("sequence"):
                self._conversation_sequence += 1
                merged["sequence"] = self._conversation_sequence
            self._recent_conversation.append(merged)
        if len(self._recent_conversation) > 12:
            del self._recent_conversation[:-12]

    def note_tool_selection(
        self,
        *,
        tool_name: str,
        arguments: Any = None,
        tool_call_id: str | None = None,
        schema: dict[str, Any] | None = None,
        docstring: str | None = None,
        selection_metadata: dict[str, Any] | None = None,
        source: str = "llm_selected_tool",
    ) -> None:
        metadata = _jsonable(selection_metadata or {})
        descriptor = {
            "tool_name": tool_name,
            "schema": _jsonable(schema) if schema is not None else {"type": "object", "additionalProperties": True},
            "docstring": docstring,
            "args": _normalize_tool_arguments(arguments),
            "metadata": metadata,
        }
        current_entry = self._current_conversation_entry()
        conversation_sequence = current_entry.get("sequence") if current_entry else None
        recorded_at = datetime.now(timezone.utc)
        self._recent_tool_selections.append(
            {
                "runtime_scope": self._runtime_scope(),
                "sequence": conversation_sequence,
                "source": source,
                "tool_call_id": tool_call_id,
                "descriptor": descriptor,
                "selection_metadata": metadata,
                "recorded_at": recorded_at.isoformat(),
                "recorded_at_unix": recorded_at.timestamp(),
            }
        )
        if len(self._recent_tool_selections) > 64:
            del self._recent_tool_selections[:-64]
        current_index = self._current_conversation_index()
        if current_index is not None:
            selected_tools = list(self._recent_conversation[current_index].get("selected_tools") or [])
            selected_tools.append(
                {
                    "tool_name": tool_name,
                    "tool_call_id": tool_call_id,
                    "args": descriptor["args"],
                    **({"raw_name": metadata.get("raw_name")} if metadata.get("raw_name") else {}),
                    **({"source": source} if source else {}),
                    **({"native_call_type": metadata.get("native_call_type")} if metadata.get("native_call_type") else {}),
                    **({"provider_hint": metadata.get("provider_hint")} if metadata.get("provider_hint") else {}),
                    **({"semantic_class": metadata.get("semantic_class")} if metadata.get("semantic_class") else {}),
                }
            )
            self._recent_conversation[current_index]["selected_tools"] = selected_tools[-24:]
            if tool_call_id:
                tool_call_ids = list(self._recent_conversation[current_index].get("tool_call_ids") or [])
                tool_call_ids.append(str(tool_call_id))
                self._recent_conversation[current_index]["tool_call_ids"] = sorted(dict.fromkeys(tool_call_ids))

    def ensure_tool_selection_recorded(
        self,
        *,
        tool_descriptor: dict[str, Any] | None,
        tool_call_id: str | None = None,
        source: str = "llm_selected_tool",
    ) -> None:
        if not isinstance(tool_descriptor, dict):
            return
        tool_name = str(tool_descriptor.get("tool_name") or "").strip()
        if not tool_name:
            return
        raw_args = _tool_descriptor_arguments(tool_descriptor)
        metadata = _tool_descriptor_metadata(tool_descriptor)
        current_scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        raw_name = str(metadata.get("raw_name") or tool_name).strip()
        tool_call_id_text = str(tool_call_id) if tool_call_id is not None else None
        args_hash = _hash_jsonable(raw_args)
        for record in reversed(self._recent_tool_selections):
            if str(record.get("runtime_scope") or "") != current_scope:
                continue
            if current_sequence is not None and record.get("sequence") != current_sequence:
                continue
            descriptor = record.get("descriptor") or {}
            if str(descriptor.get("tool_name") or "").strip() != tool_name:
                continue
            if tool_call_id_text is not None and str(record.get("tool_call_id") or "") != tool_call_id_text:
                continue
            if _hash_jsonable(_tool_descriptor_arguments(descriptor)) != args_hash:
                continue
            recorded_metadata = record.get("selection_metadata") or {}
            recorded_raw_name = str(
                recorded_metadata.get("raw_name")
                or descriptor.get("tool_name")
                or ""
            ).strip()
            if recorded_raw_name != raw_name:
                continue
            return
        self.note_tool_selection(
            tool_name=tool_name,
            arguments=raw_args if raw_args else tool_descriptor.get("args"),
            tool_call_id=tool_call_id,
            schema=tool_descriptor.get("schema") if isinstance(tool_descriptor.get("schema"), dict) else None,
            docstring=tool_descriptor.get("docstring"),
            selection_metadata=metadata,
            source=source,
        )

    def current_conversation_window(
        self,
        *,
        tool_descriptor: dict[str, Any] | None = None,
        boundary_kind: str = "action_execute",
        surface: str = "tool_dispatch",
        target: str = "",
        transport_args: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        current_entry = self._current_conversation_entry()
        if current_entry is not None:
            return current_entry
        recovered_entry = self._recover_cross_scope_conversation_entry(
            tool_descriptor=tool_descriptor,
            boundary_kind=boundary_kind,
            surface=surface,
            target=target,
            transport_args=transport_args or {},
        )
        if recovered_entry is not None:
            return recovered_entry
        reconstructed_entry = self._reconstruct_conversation_window_from_recent_objects(
            tool_descriptor=tool_descriptor,
            boundary_kind=boundary_kind,
            surface=surface,
            target=target,
            transport_args=transport_args or {},
        )
        if reconstructed_entry is not None:
            return reconstructed_entry
        return {
            "sequence": None,
            "source": "runtime_install",
            "model_name": None,
            "tool_call_id": None,
            "request_kind": "messages",
            "request_metadata": {},
            "tool_choice": None,
            "tool_definitions": [],
            "tool_call_ids": [],
            "inserted_context_object_ids": [],
            "omission_events": [
                {
                    "omission_id": "conversation_gap",
                    "code": "capture_blind_spot",
                    "message": "No wrapped conversation window was captured before this effect.",
                    "severity": "warning",
                    "metadata": {},
                }
            ],
            "supported_adapter": False,
            "capture_gap_codes": ["missing_prompt_frames"],
            "weak_signals": ["fallback_runtime_conversation"],
            "capture_source_kind": "assistant_output_fallback",
            "capture_sources": [],
            "normalized_span_count": 0,
            "invocation_merge_key": None,
            "captured_at": datetime.now(timezone.utc).isoformat(),
            "captured_at_unix": datetime.now(timezone.utc).timestamp(),
            "selected_tools": [],
            "messages": [
                {
                    "role": "system",
                    "content": "No wrapped conversation window was captured before this effect.",
                    "message_id": "conversation_gap",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            ],
        }

    def recent_object_refs(
        self,
        *,
        conversation_window: dict[str, Any] | None = None,
        tool_descriptor: dict[str, Any] | None = None,
        target: str | None = None,
        transport_args: dict[str, Any] | None = None,
        limit: int = 16,
    ) -> list[dict[str, Any]]:
        references: list[dict[str, Any]] = []
        seen_object_ids: set[str] = set()

        def add_reference(entry: dict[str, Any]) -> None:
            reference = _recent_object_reference(entry)
            if reference is None:
                return
            object_id = str(reference.get("object_id") or "")
            if not object_id or object_id in seen_object_ids:
                return
            seen_object_ids.add(object_id)
            references.append(reference)

        current_entries = self.verifiedx.capture.recent_objects(limit=max(limit * 2, 16))
        for entry in current_entries:
            add_reference(entry)

        conversation = conversation_window or self.current_conversation_window()
        selected_object_ids = {
            str(object_id)
            for object_id in (conversation.get("inserted_context_object_ids") or [])
            if object_id
        }
        if selected_object_ids:
            missing_selected_ids = [
                object_id for object_id in selected_object_ids if object_id not in seen_object_ids
            ]
            if missing_selected_ids:
                for entry in self.verifiedx.capture.recent_objects_by_ids(missing_selected_ids):
                    add_reference(entry)

        hint_strings = _scalar_text_fragments(
            {
                "target": target,
                "tool_args": (tool_descriptor or {}).get("args"),
                "transport_args": transport_args or {},
            }
        )
        hint_tokens: set[str] = set()
        for fragment in hint_strings:
            hint_tokens |= _normalized_identifier_tokens(fragment)

        if hint_tokens or hint_strings:
            global_entries = self.verifiedx.capture.recent_objects_across_runs(limit=max(limit * 8, 64))
            ranked_entries: list[tuple[int, int, dict[str, Any]]] = []
            for entry in global_entries:
                object_id = str(entry.get("object_id") or "")
                if not object_id or object_id in seen_object_ids:
                    continue
                reference = _recent_object_reference(entry)
                if reference is None:
                    continue
                score = _recent_reference_relevance_score(
                    reference,
                    selected_object_ids=selected_object_ids,
                    hint_strings=hint_strings,
                    hint_tokens=hint_tokens,
                )
                if score <= 0:
                    continue
                ranked_entries.append((score, int(reference.get("sequence") or 0), entry))
            ranked_entries.sort(key=lambda item: (-item[0], -item[1]))
            for _, _, entry in ranked_entries:
                if len(references) >= limit:
                    break
                add_reference(entry)

        if len(references) > limit:
            exact_selected: list[dict[str, Any]] = []
            for object_id in conversation.get("inserted_context_object_ids") or []:
                for reference in references:
                    if reference.get("object_id") == object_id:
                        exact_selected.append(reference)
                        break
            selected_ids = {ref.get("object_id") for ref in exact_selected if ref.get("object_id")}
            supplemental = [
                reference for reference in references if reference.get("object_id") not in selected_ids
            ]
            supplemental.sort(key=lambda reference: int(reference.get("sequence") or 0), reverse=True)
            references = exact_selected + supplemental[: max(0, limit - len(exact_selected))]

        return references

    def infer_ambient_tool_descriptor(self) -> tuple[dict[str, Any] | None, str | None]:
        scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        current_sequence = current_entry.get("sequence") if current_entry else None
        if current_sequence is not None:
            for record in reversed(self._recent_tool_selections):
                if str(record.get("runtime_scope") or "") != scope:
                    continue
                if record.get("sequence") != current_sequence:
                    continue
                descriptor = record.get("descriptor")
                if isinstance(descriptor, dict):
                    return dict(descriptor), str(record.get("source") or "llm_selected_tool")
        assistant_descriptor = self._recent_assistant_output_descriptor()
        if assistant_descriptor is not None:
            return assistant_descriptor, "assistant_output_fallback"
        conversation_window = self.current_conversation_window()
        explicit_tool_name = _tool_name_from_choice(conversation_window.get("tool_choice"))
        definitions_by_name = _tool_definitions_by_name(conversation_window.get("tool_definitions") or [])
        if explicit_tool_name:
            descriptor = definitions_by_name.get(explicit_tool_name)
            if descriptor is not None:
                return dict(descriptor), "llm_tool_choice"
            return {
                "tool_name": explicit_tool_name,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "args": {},
            }, "llm_tool_choice"
        if len(definitions_by_name) == 1:
            only_descriptor = next(iter(definitions_by_name.values()))
            return dict(only_descriptor), "single_tool_definition"
        return None, None

    @staticmethod
    def _apply_ingress_label(object_payload: dict[str, Any], response: dict[str, Any]):
        if not isinstance(object_payload, dict) or not isinstance(response, dict):
            return
        taint_labels = list(object_payload.get("taint_labels") or [])
        taint_labels.extend(response.get("taint_labels") or [])
        object_payload["taint_labels"] = sorted(dict.fromkeys(taint_labels))

    @staticmethod
    def _should_taint_probe_ingress(
        object_payload: dict[str, Any],
        *,
        source_uri: str | None = None,
        source_hint: str | None = None,
    ) -> bool:
        if not isinstance(object_payload, dict):
            return False
        object_type = str(object_payload.get("object_type") or "").strip().lower()
        normalized_payload = object_payload.get("normalized_payload") or {}
        source_lineage = object_payload.get("source_lineage") or []
        tokens: set[str] = set()
        for value in (source_hint, source_uri, object_type, source_lineage):
            tokens.update(_normalized_identifier_tokens(value))
        tokens.update(
            part
            for token in list(tokens)
            for part in token.split("_")
            if part
        )
        if object_type == "observation":
            role = str(normalized_payload.get("role") or "").strip().lower()
            return role == "user"
        if object_type != "external_retrieval":
            return False
        explicit_external = bool(
            object_type == "external_retrieval"
            or tokens & _EXTERNAL_INGRESS_HINT_TOKENS
        )
        internal_retrieval_like = bool(
            object_type in {"internal_retrieval", "memory_record"}
            or "memory_read" in tokens
            or "graph_state_read" in tokens
            or "workspace_search" in tokens
        )
        try:
            parsed = urllib_parse.urlparse(str(source_uri or ""))
        except Exception:
            parsed = None
        scheme = str(getattr(parsed, "scheme", "") or "").strip().lower()
        if scheme in {"memory", "file", "repo"}:
            return False
        if scheme in {"tool", "mcp"} and not explicit_external:
            if internal_retrieval_like or tokens & _INTERNAL_RETRIEVAL_INGRESS_HINT_TOKENS:
                return False
        if internal_retrieval_like and not explicit_external:
            if scheme in {"http", "https"}:
                if tokens & _INTERNAL_RETRIEVAL_INGRESS_HINT_TOKENS:
                    return False
                return _host_is_local(str(source_uri or ""))
            return False
        return explicit_external and not internal_retrieval_like

    def observe_ingress(
        self,
        object_payload: dict[str, Any],
        *,
        source_uri: str | None = None,
        source_hint: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]] | None:
        if not self.active:
            return None
        if not self._should_taint_probe_ingress(
            object_payload,
            source_uri=source_uri,
            source_hint=source_hint,
        ):
            self.verifiedx.capture.remember_observed_object(
                object_payload,
                kind="context_ingress",
            )
            return None
        excerpt = _excerpt(
            object_payload.get("normalized_payload"),
            limit=self.verifiedx.config.max_ingress_excerpt_chars,
        )
        if not excerpt:
            self.verifiedx.capture.remember_observed_object(
                object_payload,
                kind="context_ingress",
            )
            return None
        probe_payload = {
            "source_hint": source_hint,
            "excerpt": excerpt,
        }
        payload = {"taint_probe": probe_payload}
        response = self.verifiedx.client.taint_probe(probe_payload)
        self._apply_ingress_label(object_payload, response)
        self.verifiedx.capture.remember_observed_object(
            object_payload,
            kind="context_ingress",
        )
        return payload, response

    async def observe_ingress_async(
        self,
        object_payload: dict[str, Any],
        *,
        source_uri: str | None = None,
        source_hint: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]] | None:
        if not self.active:
            return None
        if not self._should_taint_probe_ingress(
            object_payload,
            source_uri=source_uri,
            source_hint=source_hint,
        ):
            self.verifiedx.capture.remember_observed_object(
                object_payload,
                kind="context_ingress",
            )
            return None
        excerpt = _excerpt(
            object_payload.get("normalized_payload"),
            limit=self.verifiedx.config.max_ingress_excerpt_chars,
        )
        if not excerpt:
            self.verifiedx.capture.remember_observed_object(
                object_payload,
                kind="context_ingress",
            )
            return None
        probe_payload = {
            "source_hint": source_hint,
            "excerpt": excerpt,
        }
        payload = {"taint_probe": probe_payload}
        response = await self.verifiedx.client.taint_probe_async(probe_payload)
        self._apply_ingress_label(object_payload, response)
        self.verifiedx.capture.remember_observed_object(
            object_payload,
            kind="context_ingress",
        )
        return payload, response

    def preflight_selected_tools(
        self,
        *,
        source: str,
        tool_definitions: list[dict[str, Any]] | None,
        selected_tools: list[dict[str, Any]],
    ) -> None:
        if not self.active or not selected_tools:
            return
        definitions_by_name = _tool_definitions_by_name(tool_definitions)
        for selected in selected_tools:
            tool_name = selected.get("tool_name")
            if not isinstance(tool_name, str) or not tool_name.strip():
                continue
            definition = definitions_by_name.get(tool_name.strip()) or {}
            selection_source = str(selected.get("source") or source)
            selection_metadata = {
                **(_tool_descriptor_metadata(definition) if isinstance(definition, dict) else {}),
                **(
                    {
                        key: selected.get(key)
                        for key in (
                            "approval_request_id",
                            "key",
                            "namespace",
                            "native_call_type",
                            "pending_action",
                            "provider_event_type",
                            "provider_executed",
                            "raw_args",
                            "raw_name",
                            "read_only",
                            "retrieval_like",
                            "semantic_class",
                        )
                        if selected.get(key) is not None
                    }
                ),
            }
            tool_descriptor = {
                "tool_name": tool_name.strip(),
                "schema": _jsonable(definition.get("schema"))
                if definition.get("schema") is not None
                else {"type": "object", "additionalProperties": True},
                "docstring": definition.get("docstring"),
                "args": _normalize_tool_arguments(selected.get("args")),
                "metadata": selection_metadata,
            }
            self.ensure_tool_selection_recorded(
                tool_descriptor=tool_descriptor,
                tool_call_id=selected.get("tool_call_id"),
                source=selection_source,
            )
            if self._selected_tool_preflight_owned_by_adapter(
                source=source,
                selection_source=selection_source,
                selected=selected,
            ):
                continue
            capture = self.describe_selected_tool_boundary(
                tool_descriptor=tool_descriptor,
                source=selection_source,
            )
            if capture is None:
                continue
            boundary_kind = str(capture.get("boundary_kind") or "action_execute")
            surface = str(capture["surface"])
            operation = str(capture["operation"])
            target = str(capture["target"])
            method = capture.get("method")
            transport_args = dict(capture.get("transport_args") or tool_descriptor["args"])
            action_class = capture.get("action_class") or self._guess_action_class(
                surface=surface,
                operation=operation,
                target=target,
                method=method,
                tool_descriptor=tool_descriptor,
            )
            trust_boundary_crossing = bool(capture.get("trust_boundary_crossing"))
            cached_preflight = self._matching_tool_preflight(
                tool_descriptor=tool_descriptor,
                tool_call_id=selected.get("tool_call_id"),
                boundary_kind=boundary_kind,
                surface=surface,
                target=target,
                transport_args=transport_args,
            )
            if cached_preflight is not None:
                continue
            phase = "v4_boundary_preflight_tool_selection"
            request_payload, observed_boundary, candidate_hash = self.verifiedx._v4.build_preflight_request(
                self,
                surface=surface,
                operation=operation,
                target=target,
                method=method,
                transport_args=transport_args,
                boundary_kind=boundary_kind,
                action_class=action_class,
                trust_boundary_crossing=trust_boundary_crossing,
                tool_descriptor=tool_descriptor,
                tool_source=selection_source,
            )
            self._record_boundary_request_debug(
                phase=phase,
                request_payload=request_payload,
                boundary_kind=boundary_kind,
                action_class=action_class,
                target=target,
                tool_descriptor=tool_descriptor,
            )
            try:
                decision = self.verifiedx._v4.submit_preflight_payload(request_payload)
            except Exception as error:
                self._record_boundary_request_debug(
                    phase=phase,
                    request_payload=request_payload,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    target=target,
                    tool_descriptor=tool_descriptor,
                    error=error,
                )
                raise
            self.verifiedx.record_boundary_diagnostic(
                phase,
                request_payload,
                decision,
            )
            self._remember_tool_preflight(
                tool_descriptor=tool_descriptor,
                tool_call_id=selected.get("tool_call_id"),
                boundary_kind=boundary_kind,
                action_class=action_class,
                target=target,
                observed_boundary=observed_boundary,
                candidate_hash=candidate_hash,
                decision=decision,
                pending_action_fingerprint=_pending_action_fingerprint_from_decision_context(
                    request_payload.get("decision_context")
                ),
            )

    async def preflight_selected_tools_async(
        self,
        *,
        source: str,
        tool_definitions: list[dict[str, Any]] | None,
        selected_tools: list[dict[str, Any]],
    ) -> None:
        if not self.active or not selected_tools:
            return
        await self.flush_pending_async_tasks()
        definitions_by_name = _tool_definitions_by_name(tool_definitions)
        for selected in selected_tools:
            tool_name = selected.get("tool_name")
            if not isinstance(tool_name, str) or not tool_name.strip():
                continue
            definition = definitions_by_name.get(tool_name.strip()) or {}
            selection_source = str(selected.get("source") or source)
            selection_metadata = {
                **(_tool_descriptor_metadata(definition) if isinstance(definition, dict) else {}),
                **(
                    {
                        key: selected.get(key)
                        for key in (
                            "approval_request_id",
                            "key",
                            "namespace",
                            "native_call_type",
                            "pending_action",
                            "provider_event_type",
                            "provider_executed",
                            "raw_args",
                            "raw_name",
                            "read_only",
                            "retrieval_like",
                            "semantic_class",
                        )
                        if selected.get(key) is not None
                    }
                ),
            }
            tool_descriptor = {
                "tool_name": tool_name.strip(),
                "schema": _jsonable(definition.get("schema"))
                if definition.get("schema") is not None
                else {"type": "object", "additionalProperties": True},
                "docstring": definition.get("docstring"),
                "args": _normalize_tool_arguments(selected.get("args")),
                "metadata": selection_metadata,
            }
            self.ensure_tool_selection_recorded(
                tool_descriptor=tool_descriptor,
                tool_call_id=selected.get("tool_call_id"),
                source=selection_source,
            )
            if self._selected_tool_preflight_owned_by_adapter(
                source=source,
                selection_source=selection_source,
                selected=selected,
            ):
                continue
            capture = self.describe_selected_tool_boundary(
                tool_descriptor=tool_descriptor,
                source=selection_source,
            )
            if capture is None:
                continue
            boundary_kind = str(capture.get("boundary_kind") or "action_execute")
            surface = str(capture["surface"])
            operation = str(capture["operation"])
            target = str(capture["target"])
            method = capture.get("method")
            transport_args = dict(capture.get("transport_args") or tool_descriptor["args"])
            action_class = capture.get("action_class") or self._guess_action_class(
                surface=surface,
                operation=operation,
                target=target,
                method=method,
                tool_descriptor=tool_descriptor,
            )
            trust_boundary_crossing = bool(capture.get("trust_boundary_crossing"))
            cached_preflight = self._matching_tool_preflight(
                tool_descriptor=tool_descriptor,
                tool_call_id=selected.get("tool_call_id"),
                boundary_kind=boundary_kind,
                surface=surface,
                target=target,
                transport_args=transport_args,
            )
            if cached_preflight is not None:
                continue
            phase = "v4_boundary_preflight_async_tool_selection"
            request_payload, observed_boundary, candidate_hash = self.verifiedx._v4.build_preflight_request(
                self,
                surface=surface,
                operation=operation,
                target=target,
                method=method,
                transport_args=transport_args,
                boundary_kind=boundary_kind,
                action_class=action_class,
                trust_boundary_crossing=trust_boundary_crossing,
                tool_descriptor=tool_descriptor,
                tool_source=selection_source,
            )
            self._record_boundary_request_debug(
                phase=phase,
                request_payload=request_payload,
                boundary_kind=boundary_kind,
                action_class=action_class,
                target=target,
                tool_descriptor=tool_descriptor,
            )
            try:
                decision = await self.verifiedx._v4.submit_preflight_payload_async(request_payload)
            except Exception as error:
                self._record_boundary_request_debug(
                    phase=phase,
                    request_payload=request_payload,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    target=target,
                    tool_descriptor=tool_descriptor,
                    error=error,
                )
                raise
            await self.verifiedx.record_boundary_diagnostic_async(
                phase,
                request_payload,
                decision,
            )
            self._remember_tool_preflight(
                tool_descriptor=tool_descriptor,
                tool_call_id=selected.get("tool_call_id"),
                boundary_kind=boundary_kind,
                action_class=action_class,
                target=target,
                observed_boundary=observed_boundary,
                candidate_hash=candidate_hash,
                decision=decision,
                pending_action_fingerprint=_pending_action_fingerprint_from_decision_context(
                    request_payload.get("decision_context")
                ),
            )

    def _selected_tool_preflight_owned_by_adapter(
        self,
        *,
        source: str,
        selection_source: str,
        selected: dict[str, Any],
    ) -> bool:
        adapter = getattr(self.verifiedx.capture, "_default_adapter", None) or {}
        adapter_kind = str(adapter.get("adapter_kind") or "").strip().lower()
        if adapter_kind != "openai_agents":
            return False
        current_entry = self._current_conversation_entry() or {}
        request_kind = str(current_entry.get("request_kind") or "").strip().lower()
        conversation_source = str(current_entry.get("source") or "").strip().lower()
        if "openai_agents" not in request_kind and "openai_agents" not in conversation_source:
            return False
        normalized_source = str(selection_source or source or "").strip().lower()
        if not (
            normalized_source.startswith("openai.responses.output.")
            or normalized_source.startswith("openai.chat.completions.message.")
        ):
            return False
        native_call_type = str(
            selected.get("native_call_type")
            or selected.get("type")
            or ""
        ).strip().lower()
        if native_call_type.endswith("_output"):
            return False
        return True

    def _guess_action_class(
        self,
        *,
        surface: str,
        operation: str,
        target: str,
        method: str | None = None,
        tool_descriptor: dict[str, Any] | None = None,
        transport_args: dict[str, Any] | None = None,
    ) -> str | None:
        normalized = f"{surface} {operation} {target}".lower()
        if "memory" in normalized:
            return "memory_write"
        if surface == "file_write":
            return "record_mutation"
        if surface == "db_mutation" or any(token in normalized for token in ("sql", "update", "insert", "delete", "mutation")):
            return "record_mutation"
        if surface == "browser" or any(token in normalized for token in ("browser", "click", "submit")):
            return "browser_submit"
        if surface == "queue_publish" or any(token in normalized for token in ("queue", "publish", "sqs", "sns")):
            return "upload"
        if target.startswith("http"):
            return _http_like_action_class(
                target,
                method,
                transport_args or {},
                tool_descriptor=tool_descriptor,
            )
        if _tool_descriptor_suggests_message_send(tool_descriptor):
            return "external_message_send"
        if _tool_descriptor_looks_internal_update(tool_descriptor):
            return "system_change"
        return "generic"

    def _guess_sensitivity(self, *, surface: str, method: str | None) -> str:
        normalized_method = (method or "").upper()
        if surface == "browser":
            return "critical"
        if surface == "queue_publish":
            return "high"
        if surface == "file_write":
            return "high"
        if surface == "memory_write":
            return "medium"
        if surface == "db_mutation":
            return "high"
        if surface == "http" and normalized_method == "DELETE":
            return "critical"
        if surface == "http":
            return "high"
        return self.verifiedx.config.default_sensitivity

    def _decision_allows(self, decision: dict[str, Any]) -> bool:
        return decision.get("outcome") in {"allow", "allow_with_warning"}

    def _result_confirms_side_effect(self, result: Any) -> bool:
        success_flag = getattr(result, "success_flag", None)
        if success_flag is False:
            return False
        normalized = _result_mapping(result)
        if normalized is None:
            return True
        if normalized.get("ok") is False:
            return False
        if normalized.get("success") is False:
            return False
        if normalized.get("success_flag") is False:
            return False
        if normalized.get("blocked") is True:
            return False
        if normalized.get("must_not_claim_success") is True:
            return False
        if normalized.get("completion_allowed") is False:
            return False
        if normalized.get("side_effect_executed") is False:
            return False
        status = str(
            normalized.get("step_status")
            or normalized.get("status")
            or getattr(result, "status", "")
        ).lower()
        return status not in {"blocked", "denied", "error", "failed", "not_executed"}

    def _execution_failure_tool_result(
        self,
        *,
        response: dict[str, Any],
        decision: dict[str, Any],
        goal_state_hint: str | None,
        boundary_kind: str,
        action_class: str | None,
        pending_effect: dict[str, Any],
        raw_result: Any,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        runtime_loopback = response.get("runtime_loopback") or {}
        return {
            **(_jsonable(raw_result) if isinstance(raw_result, dict) else {"value": _jsonable(raw_result)}),
            "ok": False,
            "blocked": False,
            "boundary_outcome": runtime_loopback.get("outcome", "allow_with_warning"),
            "execution_failure": True,
            "side_effect_executed": False,
            "state_changed": False,
            "step_status": "failed",
            "continue_toward_goal": True,
            "must_replan": True,
            "required_replan": True,
            "must_not_claim_success": True,
            "completion_allowed": False,
            "human_review_terminal": False,
            "decision_id": response.get("decision_id") or decision.get("decision_id"),
            "retryability": runtime_loopback.get("retryability", "replan"),
            "strategy": "The side effect did not happen. Replan truthfully from the same goal state.",
            "agent_instruction": (
                "This tool call returned ok=false because the allowed attempt failed at execution time. "
                "The side effect did NOT happen. Do not claim success, and replan truthfully."
            ),
            "goal_state_hint": goal_state_hint,
            "blocked_boundary": boundary_kind,
            "blocked_action_class": action_class,
            "pending_effect": pending_effect,
            "keep_working_until_goal_resolved": True,
            "goal_completion_warning": None,
            "must_not_mark_goal_complete": False,
            "safe_next_steps": runtime_loopback.get("safe_next_steps") or [
                {
                    "code": "execution_failure_replan",
                    "message": "The side effect did not happen. Replan truthfully from the same goal state.",
                }
            ],
            "reasons": [
                {
                    "code": "execution_failure",
                    "message": "The side effect was allowed but did not execute successfully.",
                    "severity": "warning",
                }
            ],
            "missing_support": [],
            "authorization_gaps": [],
            "runtime_loopback": runtime_loopback,
            "error": error_message or (raw_result or {}).get("error") if isinstance(raw_result, dict) else error_message,
        }

    def _report_execution(
        self,
        *,
        observed_boundary: dict[str, Any],
        candidate_hash: str,
        decision_id: str | None,
        boundary_kind: str,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        result: Any,
        side_effect_executed: bool,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        return self.verifiedx._v4.report_execution(
            observed_boundary=observed_boundary,
            candidate_hash=candidate_hash,
            decision_id=decision_id,
            boundary_kind=boundary_kind,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=_jsonable(transport_args),
            result=_jsonable(result),
            side_effect_executed=side_effect_executed,
            error_message=error_message,
        )

    async def _report_execution_async(
        self,
        *,
        observed_boundary: dict[str, Any],
        candidate_hash: str,
        decision_id: str | None,
        boundary_kind: str,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        result: Any,
        side_effect_executed: bool,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        return await self.verifiedx._v4.report_execution_async(
            observed_boundary=observed_boundary,
            candidate_hash=candidate_hash,
            decision_id=decision_id,
            boundary_kind=boundary_kind,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=_jsonable(transport_args),
            result=_jsonable(result),
            side_effect_executed=side_effect_executed,
            error_message=error_message,
        )

    def _report_execution_in_background(self, **kwargs) -> None:
        def _runner():
            try:
                self._report_execution(**kwargs)
            except Exception as error:  # pragma: no cover - best-effort background reporting
                if self.verifiedx.config.debug_decisions:
                    self.verifiedx._write_debug_record(
                        {
                            "kind": "verifiedx_execution_report_error",
                            "ts": datetime.now(timezone.utc).isoformat(),
                            "error": str(error),
                            "context": _jsonable(kwargs),
                        }
                    )

        threading.Thread(target=_runner, daemon=True).start()

    @staticmethod
    def _fallback_execution_report_response(
        *,
        decision: dict[str, Any],
        side_effect_executed: bool,
        report_error: Exception,
    ) -> dict[str, Any]:
        runtime_loopback = None
        if not side_effect_executed:
            runtime_loopback = (decision.get("runtime_loopback") or {}) or {
                "outcome": "allow_with_warning",
                "retryability": "replan",
                "same_goal_state": True,
                "safe_next_steps": [
                    {
                        "code": "execution_failure_replan",
                        "message": "The side effect did not happen. Replan truthfully from the same goal state.",
                    }
                ],
            }
        return {
            "execution_id": None,
            "decision_id": decision.get("decision_id"),
            "side_effect_executed": side_effect_executed,
            "must_not_claim_success": not side_effect_executed,
            "runtime_loopback": runtime_loopback,
            "report_error": str(report_error),
        }

    def _handle_execution_report_error(
        self,
        *,
        error: Exception,
        decision: dict[str, Any],
        observed_boundary: dict[str, Any],
        candidate_hash: str,
        boundary_kind: str,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        result: Any,
        side_effect_executed: bool,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        if self.verifiedx.config.debug_decisions:
            self.verifiedx._write_debug_record(
                {
                    "kind": "verifiedx_execution_report_error",
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "error": str(error),
                    "decision_id": decision.get("decision_id"),
                    "side_effect_executed": side_effect_executed,
                    "context": {
                        "boundary_kind": boundary_kind,
                        "candidate_hash": candidate_hash,
                        "target": target,
                        "surface": surface,
                        "operation": operation,
                        "method": method,
                        "transport_args": _jsonable(transport_args),
                        "result": _jsonable(result),
                        "error_message": error_message,
                        "envelope": observed_boundary.get("envelope"),
                    },
                }
            )
        return self._fallback_execution_report_response(
            decision=decision,
            side_effect_executed=side_effect_executed,
            report_error=error,
        )

    def _record_boundary_request_debug(
        self,
        *,
        phase: str,
        request_payload: dict[str, Any],
        boundary_kind: str,
        action_class: str | None,
        target: str,
        tool_descriptor: dict[str, Any] | None,
        error: Exception | None = None,
    ) -> None:
        if not self.verifiedx.config.debug_decisions:
            return
        try:
            logical_body = json.dumps(_jsonable(request_payload)).encode("utf-8")
            payload_bytes = len(logical_body)
            wire_payload_bytes = payload_bytes
            content_encoding = None
            if payload_bytes > _CLIENT_GZIP_MIN_BYTES:
                compressed = gzip.compress(logical_body)
                if len(compressed) < payload_bytes:
                    wire_payload_bytes = len(compressed)
                    content_encoding = "gzip"
        except Exception:
            payload_bytes = None
            wire_payload_bytes = None
            content_encoding = None
        record = {
            "kind": "verifiedx_boundary_request",
            "ts": datetime.now(timezone.utc).isoformat(),
            "phase": phase,
            "boundary_kind": boundary_kind,
            "action_class": action_class,
            "target": target,
            "tool_name": (tool_descriptor or {}).get("tool_name"),
            "payload_bytes": payload_bytes,
            "wire_payload_bytes": wire_payload_bytes,
            "content_encoding": content_encoding,
        }
        if error is not None:
            record["kind"] = "verifiedx_boundary_request_error"
            record["error"] = str(error)
        self.verifiedx._write_debug_record(record)

    def intercept_boundary(
        self,
        *,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        execute,
        boundary_kind: str | None = None,
        action_class: str | None = None,
        trust_boundary_crossing: bool | None = None,
        goal_state_hint: str | None = None,
        pending_effect: dict[str, Any] | None = None,
        tool_descriptor: dict[str, Any] | None = None,
    ):
        if runtime_capture_suppressed():
            return execute()
        current_tool = _current_tool_invocation()
        effective_tool = tool_descriptor
        effective_tool_source = getattr(current_tool, "source", None) if current_tool is not None else None
        if effective_tool is None and current_tool is not None:
            effective_tool = current_tool.descriptor()
        if effective_tool is None:
            effective_tool, effective_tool_source = self.infer_ambient_tool_descriptor()
        if effective_tool is None:
            return execute()
        scope_payload = {
            "target": target,
            "tool_descriptor": effective_tool,
            "transport_args": transport_args,
            "pending_effect": pending_effect or transport_args,
        }
        current_scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        scope_manager = (
            self.verifiedx.pinned_runtime_scope(current_scope)
            if current_entry is not None or current_tool is not None
            else self.verifiedx.runtime_scope_from_payload(scope_payload)
        )
        with scope_manager:
            if _should_skip_local_assistant_output_http_fallback(
                surface=surface,
                target=target,
                tool_descriptor=effective_tool,
            ):
                return execute()
            if _should_skip_local_retrieval_http_boundary(
                surface=surface,
                target=target,
                tool_descriptor=effective_tool,
            ):
                return execute()
            action_class = action_class or self._guess_action_class(
                surface=surface,
                operation=operation,
                target=target,
                method=method,
                tool_descriptor=effective_tool,
                transport_args=transport_args,
            )
            boundary_kind = boundary_kind or (
                "memory_write"
                if surface == "memory_write" or action_class == "memory_write"
                else "action_execute"
            )
            self.verifiedx.register_runtime_contract(
                action_class=action_class,
                boundary_kind=boundary_kind,
            )
            cached_preflight = self._matching_tool_preflight(
                tool_descriptor=effective_tool,
                tool_call_id=getattr(current_tool, "tool_call_id", None) if current_tool is not None else None,
                boundary_kind=boundary_kind,
                surface=surface,
                target=target,
                transport_args=transport_args,
                allow_unconsumed_cross_sequence=True,
            )
            if cached_preflight is not None:
                self._mark_tool_preflight_consumed(
                    cached_preflight,
                    phase="runtime_execution_reuse",
                )
                observed_boundary = cached_preflight["observed_boundary"]
                candidate_hash = cached_preflight["candidate_hash"]
                decision = cached_preflight["decision"]
            else:
                request_payload, observed_boundary, candidate_hash = self.verifiedx._v4.build_preflight_request(
                    self,
                    surface=surface,
                    operation=operation,
                    target=target,
                    method=method,
                    transport_args=transport_args,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    trust_boundary_crossing=trust_boundary_crossing,
                    tool_descriptor=effective_tool,
                    tool_source=effective_tool_source or "runtime_transport_inference",
                )
                self.verifiedx.capture.flush()
                phase = "v4_boundary_preflight"
                self._record_boundary_request_debug(
                    phase=phase,
                    request_payload=request_payload,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    target=target,
                    tool_descriptor=effective_tool,
                )
                try:
                    decision = self.verifiedx._v4.submit_preflight_payload(request_payload)
                except Exception as error:
                    self._record_boundary_request_debug(
                        phase=phase,
                        request_payload=request_payload,
                        boundary_kind=boundary_kind,
                        action_class=action_class,
                        target=target,
                        tool_descriptor=effective_tool,
                        error=error,
                    )
                    raise
                self.verifiedx.record_boundary_diagnostic(phase, request_payload, decision)
                self._remember_tool_preflight(
                    tool_descriptor=effective_tool,
                    tool_call_id=getattr(current_tool, "tool_call_id", None) if current_tool is not None else None,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    target=target,
                    observed_boundary=observed_boundary,
                    candidate_hash=candidate_hash,
                    decision=decision,
                    pending_action_fingerprint=_pending_action_fingerprint_from_decision_context(
                        request_payload.get("decision_context")
                    ),
                )
            if not self._decision_allows(decision):
                self.verifiedx.note_runtime_loopback(
                    decision,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    goal_state_hint=goal_state_hint,
                    pending_effect=pending_effect or transport_args,
                )
                raise RuntimeBoundaryDeniedError(
                    decision,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    goal_state_hint=goal_state_hint,
                    pending_effect=pending_effect or transport_args,
                )
            try:
                result = execute()
            except Exception as error:
                report_kwargs = {
                    "observed_boundary": observed_boundary,
                    "candidate_hash": candidate_hash,
                    "decision_id": decision.get("decision_id"),
                    "boundary_kind": boundary_kind,
                    "surface": surface,
                    "operation": operation,
                    "target": target,
                    "method": method,
                    "transport_args": transport_args,
                    "result": {"error": str(error)},
                    "side_effect_executed": False,
                    "error_message": str(error),
                }
                if cached_preflight is not None and _running_loop_or_none() is not None:
                    self._report_execution_in_background(**report_kwargs)
                    response = {
                        "decision_id": decision.get("decision_id"),
                        "runtime_loopback": decision.get("runtime_loopback") or {},
                    }
                else:
                    try:
                        response = self._report_execution(**report_kwargs)
                    except Exception as report_error:
                        response = self._handle_execution_report_error(
                            error=report_error,
                            decision=decision,
                            observed_boundary=observed_boundary,
                            candidate_hash=candidate_hash,
                            boundary_kind=boundary_kind,
                            surface=surface,
                            operation=operation,
                            target=target,
                            method=method,
                            transport_args=transport_args,
                            result={"error": str(error)},
                            side_effect_executed=False,
                            error_message=str(error),
                        )
                raise RuntimeExecutionFailureError(
                    self._execution_failure_tool_result(
                        response=response,
                        decision=decision,
                        goal_state_hint=goal_state_hint,
                        boundary_kind=boundary_kind,
                        action_class=action_class,
                        pending_effect=pending_effect or transport_args,
                        raw_result={"error": str(error)},
                        error_message=str(error),
                    )
                ) from error
            side_effect_executed = self._result_confirms_side_effect(result)
            report_kwargs = {
                "observed_boundary": observed_boundary,
                "candidate_hash": candidate_hash,
                "decision_id": decision.get("decision_id"),
                "boundary_kind": boundary_kind,
                "surface": surface,
                "operation": operation,
                "target": target,
                "method": method,
                "transport_args": transport_args,
                "result": result,
                "side_effect_executed": side_effect_executed,
                "error_message": (result or {}).get("error") if isinstance(result, dict) else None,
            }
            if cached_preflight is not None and _running_loop_or_none() is not None:
                self._report_execution_in_background(**report_kwargs)
                response = {
                    "decision_id": decision.get("decision_id"),
                    "runtime_loopback": decision.get("runtime_loopback") or {},
                }
            else:
                try:
                    response = self._report_execution(**report_kwargs)
                except Exception as report_error:
                    response = self._handle_execution_report_error(
                        error=report_error,
                        decision=decision,
                        observed_boundary=observed_boundary,
                        candidate_hash=candidate_hash,
                        boundary_kind=boundary_kind,
                        surface=surface,
                        operation=operation,
                        target=target,
                        method=method,
                        transport_args=transport_args,
                        result=result,
                        side_effect_executed=side_effect_executed,
                        error_message=(result or {}).get("error") if isinstance(result, dict) else None,
                    )
            if side_effect_executed:
                self.verifiedx.resolve_runtime_loopback(
                    goal_state_hint=goal_state_hint,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                )
                return result
            raise RuntimeExecutionFailureError(
                self._execution_failure_tool_result(
                    response=response,
                    decision=decision,
                    goal_state_hint=goal_state_hint,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    pending_effect=pending_effect or transport_args,
                    raw_result=result,
                )
            )

    async def intercept_boundary_async(
        self,
        *,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        execute,
        boundary_kind: str | None = None,
        action_class: str | None = None,
        trust_boundary_crossing: bool | None = None,
        goal_state_hint: str | None = None,
        pending_effect: dict[str, Any] | None = None,
        tool_descriptor: dict[str, Any] | None = None,
        result_observer: dict[str, Any] | None = None,
    ):
        if runtime_capture_suppressed():
            return await execute()
        current_tool = _current_tool_invocation()
        effective_tool = tool_descriptor
        effective_tool_source = getattr(current_tool, "source", None) if current_tool is not None else None
        if effective_tool is None and current_tool is not None:
            effective_tool = current_tool.descriptor()
        if effective_tool is None:
            effective_tool, effective_tool_source = self.infer_ambient_tool_descriptor()
        if effective_tool is None:
            return await execute()
        scope_payload = {
            "target": target,
            "tool_descriptor": effective_tool,
            "transport_args": transport_args,
            "pending_effect": pending_effect or transport_args,
        }
        current_scope = self._runtime_scope()
        current_entry = self._current_conversation_entry()
        scope_manager = (
            self.verifiedx.pinned_runtime_scope(current_scope)
            if current_entry is not None or current_tool is not None
            else self.verifiedx.runtime_scope_from_payload(scope_payload)
        )
        with scope_manager:
            if _should_skip_local_assistant_output_http_fallback(
                surface=surface,
                target=target,
                tool_descriptor=effective_tool,
            ):
                return await execute()
            if _should_skip_local_retrieval_http_boundary(
                surface=surface,
                target=target,
                tool_descriptor=effective_tool,
            ):
                return await execute()
            boundary_kind = boundary_kind or ("memory_write" if surface == "memory_write" else "action_execute")
            action_class = action_class or self._guess_action_class(
                surface=surface,
                operation=operation,
                target=target,
                method=method,
                tool_descriptor=effective_tool,
                transport_args=transport_args,
            )
            self.verifiedx.register_runtime_contract(
                action_class=action_class,
                boundary_kind=boundary_kind,
            )
            cached_preflight = self._matching_tool_preflight(
                tool_descriptor=effective_tool,
                tool_call_id=getattr(current_tool, "tool_call_id", None) if current_tool is not None else None,
                boundary_kind=boundary_kind,
                surface=surface,
                target=target,
                transport_args=transport_args,
                allow_unconsumed_cross_sequence=True,
            )
            if cached_preflight is not None:
                self._mark_tool_preflight_consumed(
                    cached_preflight,
                    phase="runtime_execution_reuse_async",
                )
                observed_boundary = cached_preflight["observed_boundary"]
                candidate_hash = cached_preflight["candidate_hash"]
                decision = cached_preflight["decision"]
            else:
                request_payload, observed_boundary, candidate_hash = self.verifiedx._v4.build_preflight_request(
                    self,
                    surface=surface,
                    operation=operation,
                    target=target,
                    method=method,
                    transport_args=transport_args,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    trust_boundary_crossing=trust_boundary_crossing,
                    tool_descriptor=effective_tool,
                    tool_source=effective_tool_source or "runtime_transport_inference",
                )
                self.verifiedx.capture.flush()
                phase = "v4_boundary_preflight_async"
                self._record_boundary_request_debug(
                    phase=phase,
                    request_payload=request_payload,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    target=target,
                    tool_descriptor=effective_tool,
                )
                try:
                    decision = await self.verifiedx._v4.submit_preflight_payload_async(request_payload)
                except Exception as error:
                    self._record_boundary_request_debug(
                        phase=phase,
                        request_payload=request_payload,
                        boundary_kind=boundary_kind,
                        action_class=action_class,
                        target=target,
                        tool_descriptor=effective_tool,
                        error=error,
                    )
                    raise
                await self.verifiedx.record_boundary_diagnostic_async(phase, request_payload, decision)
                self._remember_tool_preflight(
                    tool_descriptor=effective_tool,
                    tool_call_id=getattr(current_tool, "tool_call_id", None) if current_tool is not None else None,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    target=target,
                    observed_boundary=observed_boundary,
                    candidate_hash=candidate_hash,
                    decision=decision,
                    pending_action_fingerprint=_pending_action_fingerprint_from_decision_context(
                        request_payload.get("decision_context")
                    ),
                )
            if not self._decision_allows(decision):
                self.verifiedx.note_runtime_loopback(
                    decision,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    goal_state_hint=goal_state_hint,
                    pending_effect=pending_effect or transport_args,
                )
                raise RuntimeBoundaryDeniedError(
                    decision,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    goal_state_hint=goal_state_hint,
                    pending_effect=pending_effect or transport_args,
                )
            try:
                result = await execute()
            except Exception as error:
                try:
                    response = await self._report_execution_async(
                        observed_boundary=observed_boundary,
                        candidate_hash=candidate_hash,
                        decision_id=decision.get("decision_id"),
                        boundary_kind=boundary_kind,
                        surface=surface,
                        operation=operation,
                        target=target,
                        method=method,
                        transport_args=transport_args,
                        result={"error": str(error)},
                        side_effect_executed=False,
                        error_message=str(error),
                    )
                except Exception as report_error:
                    response = self._handle_execution_report_error(
                        error=report_error,
                        decision=decision,
                        observed_boundary=observed_boundary,
                        candidate_hash=candidate_hash,
                        boundary_kind=boundary_kind,
                        surface=surface,
                        operation=operation,
                        target=target,
                        method=method,
                        transport_args=transport_args,
                        result={"error": str(error)},
                        side_effect_executed=False,
                        error_message=str(error),
                    )
                raise RuntimeExecutionFailureError(
                    self._execution_failure_tool_result(
                        response=response,
                        decision=decision,
                        goal_state_hint=goal_state_hint,
                        boundary_kind=boundary_kind,
                        action_class=action_class,
                        pending_effect=pending_effect or transport_args,
                        raw_result={"error": str(error)},
                        error_message=str(error),
                    )
                ) from error
            observed_result = result_observer if isinstance(result_observer, dict) else result
            side_effect_executed = self._result_confirms_side_effect(observed_result)
            try:
                response = await self._report_execution_async(
                    observed_boundary=observed_boundary,
                    candidate_hash=candidate_hash,
                    decision_id=decision.get("decision_id"),
                    boundary_kind=boundary_kind,
                    surface=surface,
                    operation=operation,
                    target=target,
                    method=method,
                    transport_args=transport_args,
                    result=observed_result,
                    side_effect_executed=side_effect_executed,
                    error_message=(observed_result or {}).get("error")
                    if isinstance(observed_result, dict)
                    else None,
                )
            except Exception as report_error:
                response = self._handle_execution_report_error(
                    error=report_error,
                    decision=decision,
                    observed_boundary=observed_boundary,
                    candidate_hash=candidate_hash,
                    boundary_kind=boundary_kind,
                    surface=surface,
                    operation=operation,
                    target=target,
                    method=method,
                    transport_args=transport_args,
                    result=observed_result,
                    side_effect_executed=side_effect_executed,
                    error_message=(observed_result or {}).get("error")
                    if isinstance(observed_result, dict)
                    else None,
                )
            if side_effect_executed:
                self.verifiedx.resolve_runtime_loopback(
                    goal_state_hint=goal_state_hint,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                )
                return result
            raise RuntimeExecutionFailureError(
                self._execution_failure_tool_result(
                    response=response,
                    decision=decision,
                    goal_state_hint=goal_state_hint,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    pending_effect=pending_effect or transport_args,
                    raw_result=observed_result,
                )
            )


def _host_is_local(target: str) -> bool:
    try:
        parsed = urllib_parse.urlparse(target)
    except Exception:
        return False
    host = (parsed.hostname or "").lower()
    return host in {"localhost", "127.0.0.1", "::1"}


def _is_internal_tool_service_path(path: str) -> bool:
    normalized = str(path or "").strip().lower()
    if not normalized.startswith("/tools/"):
        return False
    return normalized.endswith("/calls") or normalized.endswith("/resolve")


def _is_internal_local_tool_service_url(target: str) -> bool:
    try:
        parsed = urllib_parse.urlparse(target)
    except Exception:
        return False
    host = (parsed.hostname or "").lower()
    if host not in {"localhost", "127.0.0.1", "::1"}:
        return False
    return _is_internal_tool_service_path(parsed.path or "")


def _should_skip_local_assistant_output_http_fallback(
    *,
    surface: str,
    target: str,
    tool_descriptor: dict[str, Any] | None,
) -> bool:
    if surface != "http":
        return False
    if not _host_is_local(target):
        return False
    return _tool_descriptor_looks_assistant_message(tool_descriptor)


def _should_skip_local_retrieval_http_boundary(
    *,
    surface: str,
    target: str,
    tool_descriptor: dict[str, Any] | None,
) -> bool:
    if surface != "http":
        return False
    if not _host_is_local(target):
        return False
    return _tool_descriptor_looks_retrieval_like(tool_descriptor)


def _http_response_path_looks_assistant_message_target(path: str) -> bool:
    if _is_internal_tool_service_path(path):
        return False
    target_tokens = _normalized_identifier_tokens(path)
    if not target_tokens:
        return False
    assistant_tokens = (
        _SQL_ASSISTANT_MESSAGE_TARGET_HINTS
        | _FILE_ASSISTANT_MESSAGE_TARGET_HINTS
        | set(_ASSISTANT_MESSAGE_TARGET_CONTAINERS)
    )
    return bool(target_tokens & assistant_tokens)


def _should_skip_local_assistant_message_http_request(
    installer: "ZeroTouchRuntimeInstaller | None",
    target: str,
) -> bool:
    if installer is None or not _host_is_local(target):
        return False
    return _tool_descriptor_looks_assistant_message(_ambient_tool_descriptor(installer))


def _retrieval_query_hint(tool_descriptor: dict[str, Any] | None, target: str) -> str:
    if isinstance(tool_descriptor, dict):
        tool_name = str(tool_descriptor.get("tool_name") or "").strip()
        if tool_name:
            return tool_name
    try:
        parsed = urllib_parse.urlparse(target)
    except Exception:
        return target
    return str(parsed.path or target or "runtime_http_retrieval")


def _response_headers_mapping(response: Any) -> dict[str, str]:
    headers = getattr(response, "headers", None)
    if headers is None:
        return {}
    try:
        return {str(key).strip().lower(): str(value).strip() for key, value in dict(headers).items()}
    except Exception:
        try:
            return {
                str(key).strip().lower(): str(value).strip()
                for key, value in headers.items()
            }
        except Exception:
            return {}


def _response_status_code(response: Any) -> int | None:
    for attribute in ("status_code", "status"):
        value = getattr(response, attribute, None)
        if isinstance(value, int):
            return value
    getcode = getattr(response, "getcode", None)
    if callable(getcode):
        try:
            value = getcode()
        except Exception:
            value = None
        if isinstance(value, int):
            return value
    return None


def _response_payload_for_retrieval(response: Any) -> Any | None:
    headers = _response_headers_mapping(response)
    content_type = headers.get("content-type", "").lower()
    if "json" in content_type:
        json_loader = getattr(response, "json", None)
        if callable(json_loader):
            try:
                return json_loader()
            except Exception:
                pass
        text = getattr(response, "text", None)
        if isinstance(text, str) and text.strip():
            try:
                return json.loads(text)
            except Exception:
                return {"text": text[:_RETRIEVAL_RESPONSE_MAX_CHARS]}
    text = getattr(response, "text", None)
    if isinstance(text, str) and text.strip():
        return {"text": text[:_RETRIEVAL_RESPONSE_MAX_CHARS]}
    content = getattr(response, "content", None)
    if isinstance(content, (bytes, bytearray)) and content:
        try:
            decoded = bytes(content).decode("utf-8", errors="ignore").strip()
        except Exception:
            decoded = ""
        if decoded:
            return {"text": decoded[:_RETRIEVAL_RESPONSE_MAX_CHARS]}
    return None


def _capture_local_http_retrieval_response(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    target: str,
    response: Any,
    tool_descriptor: dict[str, Any] | None,
) -> None:
    if installer is None or not installer.active:
        return
    status_code = _response_status_code(response)
    if status_code is not None and status_code >= 400:
        return
    payload = _response_payload_for_retrieval(response)
    if payload is None:
        return
    query_hint = _retrieval_query_hint(tool_descriptor, target)
    scope_payload = {
        "target": target,
        "tool_descriptor": tool_descriptor or {},
        "response": _jsonable(payload),
    }
    with installer.verifiedx.runtime_scope_from_payload(scope_payload):
        object_type = "internal_retrieval" if _host_is_local(target) else "external_retrieval"
        object_payload = installer.verifiedx.capture.build_object(
            object_type,
            {
                "tool_name": str((tool_descriptor or {}).get("tool_name") or "") or None,
                "target": target,
                "status_code": status_code,
                "result": _jsonable(payload),
            },
        )
        try:
            diagnostic = installer.observe_ingress(
                object_payload,
                source_uri=target,
                source_hint=query_hint,
            )
            if diagnostic is not None:
                request_payload, response_payload = diagnostic
                installer.verifiedx.record_ingress_diagnostic(
                    "runtime_http_retrieval_ingress",
                    request_payload,
                    response_payload,
                )
        except Exception:
            if installer.verifiedx.config.strict_direct_ingress_labeling:
                raise
        installer.verifiedx.capture.retrieve(object_payload, query=query_hint)
        installer.verifiedx.note_observation(object_type=object_type, source_hint=query_hint)


def _current_or_default_installer() -> "ZeroTouchRuntimeInstaller | None":
    tool = _current_tool_invocation()
    if tool is not None:
        return tool.installer
    return _DEFAULT_INSTALLER


def _install_global_patches():
    _patch_file_writes()
    _patch_urllib()
    _patch_requests()
    _patch_httpx()
    _patch_libtmux()
    _patch_aiofiles()
    _patch_starlette()
    _patch_anthropic()
    _patch_openai()
    _patch_litellm()
    _patch_botocore()
    _patch_dbapi_connectors()
    _patch_sqlalchemy()
    _patch_kombu()
    _patch_playwright()


def _patch_file_writes():
    original_open = getattr(builtins, "open", None)
    if original_open is not None and not _is_patched(original_open, "builtins_open"):

        @functools.wraps(original_open)
        def wrapped_open(file, *args, **kwargs):
            if runtime_capture_suppressed():
                return original_open(file, *args, **kwargs)
            installer = _current_or_default_installer()
            mode = kwargs.get("mode")
            if mode is None and args:
                mode = args[0]
            if installer is None or not installer.active or not _is_mutating_file_mode(mode):
                return original_open(file, *args, **kwargs)
            target = str(file or "").strip()
            if not target or _is_verifiedx_debug_artifact_path(installer, target):
                return original_open(file, *args, **kwargs)
            capture = _generic_file_boundary_capture(
                target=target,
                operation="builtins.open",
                transport_args={
                    "path": target,
                    "mode": str(mode or ""),
                    "write_kind": "open",
                },
            )
            return installer.intercept_boundary(
                surface=str(capture["surface"]),
                operation=str(capture["operation"]),
                target=str(capture["target"]),
                method=capture.get("method"),
                transport_args=dict(capture["transport_args"]),
                boundary_kind=capture.get("boundary_kind"),
                action_class=capture.get("action_class"),
                trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                tool_descriptor=capture.get("tool_descriptor"),
                execute=lambda: original_open(file, *args, **kwargs),
            )

        builtins.open = _mark_patched(wrapped_open, "builtins_open")

    original_path_open = getattr(pathlib.Path, "open", None)
    if original_path_open is None or _is_patched(original_path_open, "pathlib_path_open"):
        return

    @functools.wraps(original_path_open)
    def wrapped_path_open(self, *args, **kwargs):
        if runtime_capture_suppressed():
            return original_path_open(self, *args, **kwargs)
        installer = _current_or_default_installer()
        mode = kwargs.get("mode")
        if mode is None and args:
            mode = args[0]
        if installer is None or not installer.active or not _is_mutating_file_mode(mode):
            return original_path_open(self, *args, **kwargs)
        target = str(self).strip()
        if not target or _is_verifiedx_debug_artifact_path(installer, target):
            return original_path_open(self, *args, **kwargs)
        capture = _generic_file_boundary_capture(
            target=target,
            operation="pathlib.Path.open",
            transport_args={
                "path": target,
                "mode": str(mode or ""),
                "write_kind": "open",
            },
        )
        return installer.intercept_boundary(
            surface=str(capture["surface"]),
            operation=str(capture["operation"]),
            target=str(capture["target"]),
            method=capture.get("method"),
            transport_args=dict(capture["transport_args"]),
            boundary_kind=capture.get("boundary_kind"),
            action_class=capture.get("action_class"),
            trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
            tool_descriptor=capture.get("tool_descriptor"),
            execute=lambda: original_path_open(self, *args, **kwargs),
        )

    pathlib.Path.open = _mark_patched(wrapped_path_open, "pathlib_path_open")


def _patch_libtmux():
    try:
        import libtmux.pane  # type: ignore
    except Exception:
        return
    original = getattr(libtmux.pane.Pane, "send_keys", None)
    if original is None or _is_patched(original, "libtmux_pane_send_keys"):
        return

    @functools.wraps(original)
    def wrapped(self, cmd, *args, **kwargs):
        if runtime_capture_suppressed() or _current_tool_invocation() is not None:
            return original(self, cmd, *args, **kwargs)
        installer = _current_or_default_installer()
        if installer is None or not installer.active:
            return original(self, cmd, *args, **kwargs)
        tool_descriptor = _ambient_tool_descriptor(installer)
        capture = _shell_command_boundary_details(tool_descriptor, command=str(cmd))
        if capture is None:
            return original(self, cmd, *args, **kwargs)
        return installer.intercept_boundary(
            surface=str(capture["surface"]),
            operation=str(capture["operation"]),
            target=str(capture["target"]),
            method=capture.get("method"),
            transport_args=dict(capture.get("transport_args") or {}),
            boundary_kind=capture.get("boundary_kind"),
            action_class=capture.get("action_class"),
            trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
            tool_descriptor=capture.get("tool_descriptor") or tool_descriptor,
            execute=lambda: original(self, cmd, *args, **kwargs),
        )

    libtmux.pane.Pane.send_keys = _mark_patched(wrapped, "libtmux_pane_send_keys")


def _patch_aiofiles():
    try:
        import aiofiles.threadpool as aiofiles_threadpool  # type: ignore
    except Exception:
        return

    def patch_write_method(cls_name: str) -> None:
        cls = getattr(aiofiles_threadpool, cls_name, None)
        if cls is None:
            return
        original_write = getattr(cls, "write", None)
        if original_write is None or _is_patched(original_write, f"aiofiles_{cls_name}_write"):
            return

        @functools.wraps(original_write)
        async def wrapped(self, data, *args, __original=original_write, __cls_name=cls_name, **kwargs):
            if runtime_capture_suppressed() or _current_tool_invocation() is not None:
                return await __original(self, data, *args, **kwargs)
            installer = _current_or_default_installer()
            if installer is None or not installer.active:
                return await __original(self, data, *args, **kwargs)
            file_handle = getattr(self, "_file", None)
            target = str(
                getattr(file_handle, "name", None)
                or getattr(self, "name", None)
                or ""
            ).strip()
            mode = str(
                getattr(file_handle, "mode", None)
                or getattr(self, "mode", None)
                or ""
            ).strip()
            if not target or not any(token in mode for token in ("w", "a", "x", "+")):
                return await __original(self, data, *args, **kwargs)
            data_text = _file_write_text(data)
            if data_text is None:
                return await __original(self, data, *args, **kwargs)
            capture = _file_boundary_details(
                installer,
                target=target,
                data_text=data_text,
            )
            if capture is None:
                return await __original(self, data, *args, **kwargs)
            result_observer: dict[str, Any] = {
                "ok": False,
                "status": "pending",
            }

            async def execute():
                written = await __original(self, data, *args, **kwargs)
                result_observer["ok"] = written is None or (
                    isinstance(written, int) and written >= 0
                )
                result_observer["written"] = written
                result_observer["status"] = "written"
                return written

            return await installer.intercept_boundary_async(
                surface=str(capture["surface"]),
                operation=str(capture["operation"]),
                target=str(capture["target"]),
                method=capture.get("method"),
                transport_args=dict(capture["transport_args"]),
                boundary_kind=capture.get("boundary_kind"),
                action_class=capture.get("action_class"),
                trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                tool_descriptor=capture.get("tool_descriptor"),
                result_observer=result_observer,
                execute=execute,
            )

        setattr(
            cls,
            "write",
            _mark_patched(wrapped, f"aiofiles_{cls_name}_write"),
        )

    for class_name in (
        "AsyncTextIOWrapper",
        "AsyncBufferedIOBase",
        "AsyncFileIO",
        "AsyncIndirectBufferedIOBase",
    ):
        patch_write_method(class_name)


def _patch_urllib():
    original = urllib_request.urlopen
    if _is_patched(original, "urllib"):
        return

    @functools.wraps(original)
    def wrapped(request, *args, **kwargs):
        if runtime_capture_suppressed():
            return original(request, *args, **kwargs)
        installer = _current_or_default_installer()
        if installer is None:
            return original(request, *args, **kwargs)
        url = request.full_url if hasattr(request, "full_url") else str(request)
        method = request.get_method() if hasattr(request, "get_method") else kwargs.get("method", "GET")
        if str(method).upper() in {"GET", "HEAD", "OPTIONS"}:
            return original(request, *args, **kwargs)
        if _is_internal_local_tool_service_url(str(url)):
            return original(request, *args, **kwargs)
        if _should_skip_local_assistant_message_http_request(installer, str(url)):
            return original(request, *args, **kwargs)
        ambient_tool = _ambient_tool_descriptor(installer)
        if _should_skip_local_retrieval_http_boundary(
            surface="http",
            target=str(url),
            tool_descriptor=ambient_tool,
        ):
            response = original(request, *args, **kwargs)
            _capture_local_http_retrieval_response(
                installer,
                target=str(url),
                response=response,
                tool_descriptor=ambient_tool,
            )
            return response
        return installer.intercept_boundary(
            surface="http",
            operation="urllib.request.urlopen",
            target=url,
            method=str(method).upper(),
            transport_args={
                "url": url,
                "method": str(method).upper(),
                "headers": dict(getattr(request, "headers", {}) or {}),
                "body_present": bool(getattr(request, "data", None)),
            },
            trust_boundary_crossing=not _host_is_local(url),
            execute=lambda: original(request, *args, **kwargs),
        )

    urllib_request.urlopen = _mark_patched(wrapped, "urllib")


def _patch_requests():
    try:
        import requests.sessions  # type: ignore
    except Exception:
        return
    original = requests.sessions.Session.request
    if _is_patched(original, "requests"):
        return

    @functools.wraps(original)
    def wrapped(self, method, url, *args, **kwargs):
        if runtime_capture_suppressed():
            return original(self, method, url, *args, **kwargs)
        installer = _current_or_default_installer()
        if installer is None or str(method).upper() in {"GET", "HEAD", "OPTIONS"}:
            return original(self, method, url, *args, **kwargs)
        if _is_internal_local_tool_service_url(str(url)):
            return original(self, method, url, *args, **kwargs)
        if _should_skip_local_assistant_message_http_request(installer, str(url)):
            return original(self, method, url, *args, **kwargs)
        ambient_tool = _ambient_tool_descriptor(installer)
        if _should_skip_local_retrieval_http_boundary(
            surface="http",
            target=str(url),
            tool_descriptor=ambient_tool,
        ):
            response = original(self, method, url, *args, **kwargs)
            _capture_local_http_retrieval_response(
                installer,
                target=str(url),
                response=response,
                tool_descriptor=ambient_tool,
            )
            return response
        request_payload = {
            "url": str(url),
            "method": str(method).upper(),
            "params": _jsonable(kwargs.get("params")),
            "json": _jsonable(kwargs.get("json")),
            "data": _jsonable(kwargs.get("data")),
            "headers": _jsonable(kwargs.get("headers")),
        }
        return installer.intercept_boundary(
            surface="http",
            operation="requests.sessions.Session.request",
            target=str(url),
            method=str(method).upper(),
            transport_args=request_payload,
            action_class=_http_like_action_class(
                str(url),
                str(method).upper(),
                request_payload,
                tool_descriptor=ambient_tool,
            ),
            trust_boundary_crossing=not _host_is_local(str(url)),
            execute=lambda: original(self, method, url, *args, **kwargs),
        )

    requests.sessions.Session.request = _mark_patched(wrapped, "requests")


def _patch_httpx():
    try:
        import httpx  # type: ignore
    except Exception:
        return
    original = httpx.Client.send
    if not _is_patched(original, "httpx_client"):
        @functools.wraps(original)
        def wrapped(self, request, *args, **kwargs):
            if runtime_capture_suppressed():
                return original(self, request, *args, **kwargs)
            method = getattr(request, "method", "GET")
            installer = _current_or_default_installer()
            if installer is None or str(method).upper() in {"GET", "HEAD", "OPTIONS"}:
                return original(self, request, *args, **kwargs)
            if _is_internal_local_tool_service_url(str(getattr(request, "url", ""))):
                return original(self, request, *args, **kwargs)
            if _should_skip_local_assistant_message_http_request(
                installer,
                str(getattr(request, "url", "")),
            ):
                return original(self, request, *args, **kwargs)
            ambient_tool = _ambient_tool_descriptor(installer)
            if _should_skip_local_retrieval_http_boundary(
                surface="http",
                target=str(getattr(request, "url", "")),
                tool_descriptor=ambient_tool,
            ):
                response = original(self, request, *args, **kwargs)
                _capture_local_http_retrieval_response(
                    installer,
                    target=str(getattr(request, "url", "")),
                    response=response,
                    tool_descriptor=ambient_tool,
                )
                return response
            request_payload = {
                "url": str(getattr(request, "url", "")),
                "method": str(method).upper(),
                "headers": _jsonable(dict(getattr(request, "headers", {}) or {})),
                "body": _jsonable(_httpx_body_payload(request)),
            }
            return installer.intercept_boundary(
                surface="http",
                operation="httpx.Client.send",
                target=str(getattr(request, "url", "")),
                method=str(method).upper(),
                transport_args=request_payload,
                action_class=_http_like_action_class(
                    str(getattr(request, "url", "")),
                    str(method).upper(),
                    request_payload,
                    tool_descriptor=ambient_tool,
                ),
                trust_boundary_crossing=not _host_is_local(str(getattr(request, "url", ""))),
                execute=lambda: original(self, request, *args, **kwargs),
            )

        httpx.Client.send = _mark_patched(wrapped, "httpx_client")
    async_client_send = getattr(getattr(httpx, "AsyncClient", None), "send", None)
    if async_client_send is None or _is_patched(async_client_send, "httpx_async_client"):
        return

    @functools.wraps(async_client_send)
    async def wrapped_async(self, request, *args, **kwargs):
        if runtime_capture_suppressed():
            return await async_client_send(self, request, *args, **kwargs)
        method = getattr(request, "method", "GET")
        installer = _current_or_default_installer()
        if installer is None or str(method).upper() in {"GET", "HEAD", "OPTIONS"}:
            return await async_client_send(self, request, *args, **kwargs)
        if _is_internal_local_tool_service_url(str(getattr(request, "url", ""))):
            return await async_client_send(self, request, *args, **kwargs)
        if _should_skip_local_assistant_message_http_request(
            installer,
            str(getattr(request, "url", "")),
        ):
            return await async_client_send(self, request, *args, **kwargs)
        ambient_tool = _ambient_tool_descriptor(installer)
        if _should_skip_local_retrieval_http_boundary(
            surface="http",
            target=str(getattr(request, "url", "")),
            tool_descriptor=ambient_tool,
        ):
            response = await async_client_send(self, request, *args, **kwargs)
            _capture_local_http_retrieval_response(
                installer,
                target=str(getattr(request, "url", "")),
                response=response,
                tool_descriptor=ambient_tool,
            )
            return response
        observed_result = {"response_type": "httpx_async_response"}
        request_payload = {
            "url": str(getattr(request, "url", "")),
            "method": str(method).upper(),
            "headers": _jsonable(dict(getattr(request, "headers", {}) or {})),
            "body": _jsonable(_httpx_body_payload(request)),
        }

        async def execute():
            response = await async_client_send(self, request, *args, **kwargs)
            observed_result["status_code"] = getattr(response, "status_code", None)
            return response

        return await installer.intercept_boundary_async(
            surface="http",
            operation="httpx.AsyncClient.send",
            target=str(getattr(request, "url", "")),
            method=str(method).upper(),
            transport_args=request_payload,
            action_class=_http_like_action_class(
                str(getattr(request, "url", "")),
                str(method).upper(),
                request_payload,
                tool_descriptor=ambient_tool,
            ),
            trust_boundary_crossing=not _host_is_local(str(getattr(request, "url", ""))),
            result_observer=observed_result,
            execute=execute,
        )

    httpx.AsyncClient.send = _mark_patched(wrapped_async, "httpx_async_client")


def _patch_starlette():
    try:
        import starlette.responses as starlette_responses  # type: ignore
    except Exception:
        return
    original_call = getattr(starlette_responses.Response, "__call__", None)
    if original_call is None or _is_patched(original_call, "starlette_response_call"):
        return

    @functools.wraps(original_call)
    async def wrapped_call(self, scope, receive, send):
        if runtime_capture_suppressed():
            return await original_call(self, scope, receive, send)
        installer = _current_or_default_installer()
        if installer is None or not installer.active or scope.get("type") != "http":
            return await original_call(self, scope, receive, send)
        path = str(scope.get("path") or "/")
        if _is_internal_tool_service_path(path):
            return await original_call(self, scope, receive, send)
        if not _http_response_path_looks_assistant_message_target(path):
            return await original_call(self, scope, receive, send)
        method = str(scope.get("method") or "RESPONSE").upper()
        if method in {"GET", "HEAD", "OPTIONS"}:
            return await original_call(self, scope, receive, send)
        content_type = str(getattr(self, "media_type", "") or "")
        if not content_type:
            headers = getattr(self, "headers", {}) or {}
            try:
                content_type = str(headers.get("content-type", ""))
            except Exception:
                content_type = ""
        if not any(token in content_type.lower() for token in ("json", "text")):
            return await original_call(self, scope, receive, send)
        body = getattr(self, "body", b"") or b""
        if not isinstance(body, (bytes, bytearray)) or not body:
            return await original_call(self, scope, receive, send)
        try:
            payload_text = body.decode("utf-8", errors="ignore")
        except Exception:
            return await original_call(self, scope, receive, send)
        matched_output = installer.match_assistant_output(payload_text)
        if matched_output is None:
            return await original_call(self, scope, receive, send)
        pseudo_tool = {
            "tool_name": "assistant_message",
            "schema": {"type": "object", "additionalProperties": True},
            "docstring": "Runtime-detected assistant message delivered over an HTTP response.",
            "args": {
                "message": matched_output.get("content"),
                "path": path,
                "status_code": getattr(self, "status_code", None),
            },
        }

        async def execute():
            return await original_call(self, scope, receive, send)

        try:
            return await installer.intercept_boundary_async(
                surface="http",
                operation="starlette.Response.__call__",
                target=path,
                method=method,
                transport_args={
                    "path": path,
                    "direction": "response",
                    "status_code": getattr(self, "status_code", None),
                    "content_type": content_type,
                    "message": matched_output.get("content"),
                    "body_size": len(body),
                },
                boundary_kind="action_execute",
                action_class="external_message_send",
                trust_boundary_crossing=True,
                tool_descriptor=pseudo_tool,
                result_observer={
                    "ok": getattr(self, "status_code", 200) < 400,
                    "status": "sent",
                    "status_code": getattr(self, "status_code", None),
                },
                execute=execute,
            )
        except RuntimeBoundaryDeniedError:
            blocked = starlette_responses.JSONResponse(
                {"detail": "VerifiedX blocked the outbound response."},
                status_code=409,
            )
            return await blocked(scope, receive, send)

    starlette_responses.Response.__call__ = _mark_patched(
        wrapped_call,
        "starlette_response_call",
    )


def _record_anthropic_messages_window(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    messages: Any,
    system: Any,
    source: str,
    model_name: str | None,
    request_kind: str,
    request_metadata: dict[str, Any] | None,
    tool_choice: Any,
    tool_definitions: list[dict[str, Any]] | None,
) -> None:
    if installer is None:
        return
    installer.verifiedx.record_conversation_window(
        _messages_from_anthropic_request(messages, system=system),
        source=source,
        model_name=model_name,
        request_kind=request_kind,
        request_metadata=request_metadata,
        tool_choice=_jsonable(tool_choice),
        tool_definitions=tool_definitions or [],
        remember_messages_as_context=True,
        supported_adapter=True,
        capture_source_kind="native",
    )


def _remember_anthropic_result(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    source: str,
    tool_definitions: list[dict[str, Any]],
    result: Any,
) -> list[dict[str, Any]]:
    selected_tools = _anthropic_message_tool_calls(result, tool_definitions=tool_definitions)
    _remember_selected_tools(
        installer,
        source=source,
        tool_definitions=tool_definitions,
        selected_tools=selected_tools,
    )
    return selected_tools


def _anthropic_request_metadata(bound: dict[str, Any]) -> dict[str, Any]:
    return {
        "system": _jsonable(bound.get("system")),
        "metadata": _jsonable(bound.get("metadata")),
        "temperature": bound.get("temperature"),
        "max_tokens": bound.get("max_tokens"),
        "output_config": _jsonable(bound.get("output_config")),
        "output_format": _jsonable(bound.get("output_format")),
        "tool_choice": _jsonable(bound.get("tool_choice")),
        "thinking": _jsonable(bound.get("thinking")),
        "stop_sequences": _jsonable(bound.get("stop_sequences")),
        "service_tier": bound.get("service_tier"),
        "container": bound.get("container"),
        "inference_geo": bound.get("inference_geo"),
        "stream": bool(bound.get("stream")),
    }


def _process_anthropic_result_sync(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    source: str,
    tool_definitions: list[dict[str, Any]],
    result: Any,
) -> list[dict[str, Any]]:
    selected_tools = _remember_anthropic_result(
        installer,
        source=source,
        tool_definitions=tool_definitions,
        result=result,
    )
    if installer is not None and selected_tools:
        installer.preflight_selected_tools(
            source=source,
            tool_definitions=tool_definitions,
            selected_tools=selected_tools,
        )
    assistant_text = _anthropic_message_assistant_text(result)
    if installer is not None and assistant_text:
        installer.note_assistant_output(
            content=assistant_text,
            source="anthropic.messages.assistant_output",
        )
    return selected_tools


async def _process_anthropic_result_async(
    installer: "ZeroTouchRuntimeInstaller | None",
    *,
    source: str,
    tool_definitions: list[dict[str, Any]],
    result: Any,
) -> list[dict[str, Any]]:
    selected_tools = _remember_anthropic_result(
        installer,
        source=source,
        tool_definitions=tool_definitions,
        result=result,
    )
    if installer is not None and selected_tools:
        await installer.preflight_selected_tools_async(
            source=source,
            tool_definitions=tool_definitions,
            selected_tools=selected_tools,
        )
    assistant_text = _anthropic_message_assistant_text(result)
    if installer is not None and assistant_text:
        await installer.note_assistant_output_async(
            content=assistant_text,
            source="anthropic.messages.assistant_output",
        )
    return selected_tools


def _anthropic_raw_event_type(event: Any) -> str:
    if isinstance(event, dict):
        return str(event.get("type") or "").strip().lower()
    return str(getattr(event, "type", "") or "").strip().lower()


def _anthropic_event_accumulator():
    try:
        from anthropic._types import NOT_GIVEN  # type: ignore
        from anthropic.lib.streaming._messages import accumulate_event  # type: ignore
    except Exception:
        return None, None
    return accumulate_event, NOT_GIVEN


class _VerifiedXAnthropicRawEventStream:
    def __init__(
        self,
        stream,
        *,
        installer: "ZeroTouchRuntimeInstaller | None",
        source: str,
        tool_definitions: list[dict[str, Any]],
    ):
        self._stream = stream
        self._installer = installer
        self._source = source
        self._tool_definitions = tool_definitions
        self._captured = False
        self._saw_message_stop = False
        self._current_snapshot = None
        self._accumulate_event, self._not_given = _anthropic_event_accumulator()

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        for item in self._stream:
            self._note_event(item)
            yield item
        self._capture_if_complete()

    async def __aiter__(self):
        async for item in self._stream:
            self._note_event(item)
            yield item
        await self._capture_if_complete_async()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, exc_tb):
        self._capture_if_complete()
        return False

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, exc_tb):
        await self._capture_if_complete_async()
        return False

    def _note_event(self, event: Any) -> None:
        if self._captured or self._accumulate_event is None:
            return
        try:
            self._current_snapshot = self._accumulate_event(
                event=event,
                current_snapshot=self._current_snapshot,
                output_format=self._not_given,
            )
        except Exception:
            return
        if _anthropic_raw_event_type(event) == "message_stop":
            self._saw_message_stop = True
            self._capture_if_complete()

    def _capture_if_complete(self) -> None:
        if self._captured or not self._saw_message_stop or self._current_snapshot is None:
            return
        self._captured = True
        _process_anthropic_result_sync(
            self._installer,
            source=self._source,
            tool_definitions=self._tool_definitions,
            result=self._current_snapshot,
        )

    async def _capture_if_complete_async(self) -> None:
        if self._captured or not self._saw_message_stop or self._current_snapshot is None:
            return
        self._captured = True
        await _process_anthropic_result_async(
            self._installer,
            source=self._source,
            tool_definitions=self._tool_definitions,
            result=self._current_snapshot,
        )


class _VerifiedXAnthropicStream:
    def __init__(
        self,
        stream,
        *,
        installer: "ZeroTouchRuntimeInstaller | None",
        source: str,
        tool_definitions: list[dict[str, Any]],
        async_mode: bool = False,
    ):
        self._stream = stream
        self._installer = installer
        self._source = source
        self._tool_definitions = tool_definitions
        self._async_mode = async_mode
        self._captured = False

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __next__(self):
        return next(self._stream)

    async def __aiter__(self):
        async for item in self._stream:
            yield item

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, exc_tb):
        self._capture_current_message()
        return self._stream.__exit__(exc_type, exc, exc_tb)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, exc_tb):
        await self._capture_current_message_async()
        return await self._stream.__aexit__(exc_type, exc, exc_tb)

    def _capture_final_message(self, message: Any) -> None:
        if self._captured:
            return
        self._captured = True
        _process_anthropic_result_sync(
            self._installer,
            source=self._source,
            tool_definitions=self._tool_definitions,
            result=message,
        )

    async def _capture_final_message_async(self, message: Any) -> None:
        if self._captured:
            return
        self._captured = True
        await _process_anthropic_result_async(
            self._installer,
            source=self._source,
            tool_definitions=self._tool_definitions,
            result=message,
        )

    def _capture_current_message(self) -> None:
        try:
            message = getattr(self._stream, "current_message_snapshot")
        except Exception:
            return
        if message is not None:
            self._capture_final_message(message)

    async def _capture_current_message_async(self) -> None:
        try:
            message = getattr(self._stream, "current_message_snapshot")
        except Exception:
            return
        if message is not None:
            await self._capture_final_message_async(message)

    def get_final_message(self):
        message = self._stream.get_final_message()
        self._capture_final_message(message)
        return message

    def get_final_text(self):
        message = self.get_final_message()
        return self._stream.get_final_text() if message is not None else self._stream.get_final_text()

    def until_done(self):
        result = self._stream.until_done()
        self._capture_current_message()
        return result

    async def get_final_message_async(self):
        message = await self._stream.get_final_message()
        await self._capture_final_message_async(message)
        return message

    async def get_final_text_async(self):
        message = await self.get_final_message_async()
        return await self._stream.get_final_text() if message is not None else await self._stream.get_final_text()

    async def until_done_async(self):
        result = await self._stream.until_done()
        await self._capture_current_message_async()
        return result


class _VerifiedXAnthropicStreamManager:
    def __init__(
        self,
        manager,
        *,
        installer: "ZeroTouchRuntimeInstaller | None",
        source: str,
        tool_definitions: list[dict[str, Any]],
    ):
        self._manager = manager
        self._installer = installer
        self._source = source
        self._tool_definitions = tool_definitions

    def __getattr__(self, name):
        return getattr(self._manager, name)

    def __enter__(self):
        with suppress_runtime_capture():
            stream = self._manager.__enter__()
        return _VerifiedXAnthropicStream(
            stream,
            installer=self._installer,
            source=self._source,
            tool_definitions=self._tool_definitions,
        )

    def __exit__(self, exc_type, exc, exc_tb):
        return self._manager.__exit__(exc_type, exc, exc_tb)


class _VerifiedXAsyncAnthropicStreamManager:
    def __init__(
        self,
        manager,
        *,
        installer: "ZeroTouchRuntimeInstaller | None",
        source: str,
        tool_definitions: list[dict[str, Any]],
    ):
        self._manager = manager
        self._installer = installer
        self._source = source
        self._tool_definitions = tool_definitions

    def __getattr__(self, name):
        return getattr(self._manager, name)

    async def __aenter__(self):
        with suppress_runtime_capture():
            stream = await self._manager.__aenter__()
        wrapped = _VerifiedXAnthropicStream(
            stream,
            installer=self._installer,
            source=self._source,
            tool_definitions=self._tool_definitions,
            async_mode=True,
        )
        wrapped.get_final_message = wrapped.get_final_message_async
        wrapped.get_final_text = wrapped.get_final_text_async
        wrapped.until_done = wrapped.until_done_async
        return wrapped

    async def __aexit__(self, exc_type, exc, exc_tb):
        return await self._manager.__aexit__(exc_type, exc, exc_tb)


def _patch_anthropic():
    try:
        import anthropic.resources.messages.messages as anthropic_messages  # type: ignore
    except Exception:
        anthropic_messages = None
    if anthropic_messages is None:
        return

    if (
        hasattr(anthropic_messages, "Messages")
        and hasattr(anthropic_messages.Messages, "create")
        and not _is_patched(anthropic_messages.Messages.create, "anthropic_messages_create")
    ):
        original_messages_create = anthropic_messages.Messages.create

        @functools.wraps(original_messages_create)
        def wrapped_messages_create(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_messages_create, (self, *args), kwargs)
            tool_definitions = _anthropic_tool_definitions(bound.get("tools"))
            _record_anthropic_messages_window(
                installer,
                messages=bound.get("messages") or [],
                system=bound.get("system"),
                source="anthropic.messages",
                model_name=bound.get("model"),
                request_kind="anthropic.messages.create",
                request_metadata=_anthropic_request_metadata(bound),
                tool_choice=bound.get("tool_choice"),
                tool_definitions=tool_definitions,
            )
            with suppress_runtime_capture():
                result = original_messages_create(self, *args, **kwargs)
            if bool(bound.get("stream")):
                return _VerifiedXAnthropicRawEventStream(
                    result,
                    installer=installer,
                    source="anthropic.messages.tool_use",
                    tool_definitions=tool_definitions,
                )
            _process_anthropic_result_sync(
                installer,
                source="anthropic.messages.tool_use",
                tool_definitions=tool_definitions,
                result=result,
            )
            return result

        anthropic_messages.Messages.create = _mark_patched(
            wrapped_messages_create,
            "anthropic_messages_create",
        )

    if (
        hasattr(anthropic_messages, "AsyncMessages")
        and hasattr(anthropic_messages.AsyncMessages, "create")
        and not _is_patched(anthropic_messages.AsyncMessages.create, "anthropic_async_messages_create")
    ):
        original_async_messages_create = anthropic_messages.AsyncMessages.create

        @functools.wraps(original_async_messages_create)
        async def wrapped_async_messages_create(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_async_messages_create, (self, *args), kwargs)
            tool_definitions = _anthropic_tool_definitions(bound.get("tools"))
            _record_anthropic_messages_window(
                installer,
                messages=bound.get("messages") or [],
                system=bound.get("system"),
                source="anthropic.messages.async",
                model_name=bound.get("model"),
                request_kind="anthropic.messages.create",
                request_metadata=_anthropic_request_metadata(bound),
                tool_choice=bound.get("tool_choice"),
                tool_definitions=tool_definitions,
            )
            with suppress_runtime_capture():
                result = await original_async_messages_create(self, *args, **kwargs)
            if bool(bound.get("stream")):
                return _VerifiedXAnthropicRawEventStream(
                    result,
                    installer=installer,
                    source="anthropic.messages.tool_use",
                    tool_definitions=tool_definitions,
                )
            await _process_anthropic_result_async(
                installer,
                source="anthropic.messages.tool_use",
                tool_definitions=tool_definitions,
                result=result,
            )
            return result

        anthropic_messages.AsyncMessages.create = _mark_patched(
            wrapped_async_messages_create,
            "anthropic_async_messages_create",
        )

    if (
        hasattr(anthropic_messages, "Messages")
        and hasattr(anthropic_messages.Messages, "parse")
        and not _is_patched(anthropic_messages.Messages.parse, "anthropic_messages_parse")
    ):
        original_messages_parse = anthropic_messages.Messages.parse

        @functools.wraps(original_messages_parse)
        def wrapped_messages_parse(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_messages_parse, (self, *args), kwargs)
            tool_definitions = _anthropic_tool_definitions(bound.get("tools"))
            _record_anthropic_messages_window(
                installer,
                messages=bound.get("messages") or [],
                system=bound.get("system"),
                source="anthropic.messages.parse",
                model_name=bound.get("model"),
                request_kind="anthropic.messages.parse",
                request_metadata=_anthropic_request_metadata(bound),
                tool_choice=bound.get("tool_choice"),
                tool_definitions=tool_definitions,
            )
            with suppress_runtime_capture():
                result = original_messages_parse(self, *args, **kwargs)
            _process_anthropic_result_sync(
                installer,
                source="anthropic.messages.tool_use",
                tool_definitions=tool_definitions,
                result=result,
            )
            return result

        anthropic_messages.Messages.parse = _mark_patched(
            wrapped_messages_parse,
            "anthropic_messages_parse",
        )

    if (
        hasattr(anthropic_messages, "AsyncMessages")
        and hasattr(anthropic_messages.AsyncMessages, "parse")
        and not _is_patched(anthropic_messages.AsyncMessages.parse, "anthropic_async_messages_parse")
    ):
        original_async_messages_parse = anthropic_messages.AsyncMessages.parse

        @functools.wraps(original_async_messages_parse)
        async def wrapped_async_messages_parse(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_async_messages_parse, (self, *args), kwargs)
            tool_definitions = _anthropic_tool_definitions(bound.get("tools"))
            _record_anthropic_messages_window(
                installer,
                messages=bound.get("messages") or [],
                system=bound.get("system"),
                source="anthropic.messages.async_parse",
                model_name=bound.get("model"),
                request_kind="anthropic.messages.parse",
                request_metadata=_anthropic_request_metadata(bound),
                tool_choice=bound.get("tool_choice"),
                tool_definitions=tool_definitions,
            )
            with suppress_runtime_capture():
                result = await original_async_messages_parse(self, *args, **kwargs)
            await _process_anthropic_result_async(
                installer,
                source="anthropic.messages.tool_use",
                tool_definitions=tool_definitions,
                result=result,
            )
            return result

        anthropic_messages.AsyncMessages.parse = _mark_patched(
            wrapped_async_messages_parse,
            "anthropic_async_messages_parse",
        )

    if (
        hasattr(anthropic_messages, "Messages")
        and hasattr(anthropic_messages.Messages, "stream")
        and not _is_patched(anthropic_messages.Messages.stream, "anthropic_messages_stream")
    ):
        original_messages_stream = anthropic_messages.Messages.stream

        @functools.wraps(original_messages_stream)
        def wrapped_messages_stream(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_messages_stream, (self, *args), kwargs)
            tool_definitions = _anthropic_tool_definitions(bound.get("tools"))
            _record_anthropic_messages_window(
                installer,
                messages=bound.get("messages") or [],
                system=bound.get("system"),
                source="anthropic.messages.stream",
                model_name=bound.get("model"),
                request_kind="anthropic.messages.stream",
                request_metadata=_anthropic_request_metadata(bound),
                tool_choice=bound.get("tool_choice"),
                tool_definitions=tool_definitions,
            )
            with suppress_runtime_capture():
                manager = original_messages_stream(self, *args, **kwargs)
            return _VerifiedXAnthropicStreamManager(
                manager,
                installer=installer,
                source="anthropic.messages.tool_use",
                tool_definitions=tool_definitions,
            )

        anthropic_messages.Messages.stream = _mark_patched(
            wrapped_messages_stream,
            "anthropic_messages_stream",
        )

    if (
        hasattr(anthropic_messages, "AsyncMessages")
        and hasattr(anthropic_messages.AsyncMessages, "stream")
        and not _is_patched(anthropic_messages.AsyncMessages.stream, "anthropic_async_messages_stream")
    ):
        original_async_messages_stream = anthropic_messages.AsyncMessages.stream

        @functools.wraps(original_async_messages_stream)
        def wrapped_async_messages_stream(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_async_messages_stream, (self, *args), kwargs)
            tool_definitions = _anthropic_tool_definitions(bound.get("tools"))
            _record_anthropic_messages_window(
                installer,
                messages=bound.get("messages") or [],
                system=bound.get("system"),
                source="anthropic.messages.async_stream",
                model_name=bound.get("model"),
                request_kind="anthropic.messages.stream",
                request_metadata=_anthropic_request_metadata(bound),
                tool_choice=bound.get("tool_choice"),
                tool_definitions=tool_definitions,
            )
            with suppress_runtime_capture():
                manager = original_async_messages_stream(self, *args, **kwargs)
            return _VerifiedXAsyncAnthropicStreamManager(
                manager,
                installer=installer,
                source="anthropic.messages.tool_use",
                tool_definitions=tool_definitions,
            )

        anthropic_messages.AsyncMessages.stream = _mark_patched(
            wrapped_async_messages_stream,
            "anthropic_async_messages_stream",
        )


def _patch_openai():
    try:
        import openai.resources.chat.completions.completions as chat_completions  # type: ignore
    except Exception:
        chat_completions = None
    if (
        chat_completions is not None
        and hasattr(chat_completions.Completions, "create")
        and not _is_patched(chat_completions.Completions.create, "openai_chat_create")
    ):
        original_chat = chat_completions.Completions.create

        @functools.wraps(original_chat)
        def wrapped_chat(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_chat, (self, *args), kwargs)
            _begin_openai_direct_run(
                installer,
                bound.get("messages") or [],
                continuation_turn=_openai_direct_is_chat_continuation(bound.get("messages")),
            )
            _record_openai_chat_window(
                installer,
                messages=bound.get("messages") or [],
                source="openai.chat.completions",
                model_name=bound.get("model"),
                request_kind="chat.completions",
                request_metadata={
                    "temperature": bound.get("temperature"),
                    "max_tokens": bound.get("max_tokens"),
                    "response_format": _jsonable(bound.get("response_format")),
                    "parallel_tool_calls": bound.get("parallel_tool_calls"),
                },
                tool_choice=bound.get("tool_choice") or bound.get("function_call"),
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
            )
            with suppress_runtime_capture():
                result = original_chat(self, *args, **kwargs)
            _remember_selected_tools(
                installer,
                source="openai.chat.completions.tool_call",
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
                selected_tools=_chat_completion_tool_calls(result),
            )
            if installer is not None:
                installer.preflight_selected_tools(
                    source="openai.chat.completions.tool_call",
                    tool_definitions=bound.get("tools") or bound.get("functions") or [],
                    selected_tools=_chat_completion_tool_calls(result),
                )
            assistant_text = _chat_completion_assistant_text(result)
            if installer is not None and assistant_text:
                installer.note_assistant_output(
                    content=assistant_text,
                    source="openai.chat.completions.assistant_output",
                )
            return result

        chat_completions.Completions.create = _mark_patched(
            wrapped_chat,
            "openai_chat_create",
        )
    if (
        chat_completions is not None
        and hasattr(chat_completions, "AsyncCompletions")
        and hasattr(chat_completions.AsyncCompletions, "create")
        and not _is_patched(chat_completions.AsyncCompletions.create, "openai_async_chat_create")
    ):
        original_async_chat = chat_completions.AsyncCompletions.create

        @functools.wraps(original_async_chat)
        async def wrapped_async_chat(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_async_chat, (self, *args), kwargs)
            _begin_openai_direct_run(
                installer,
                bound.get("messages") or [],
                continuation_turn=_openai_direct_is_chat_continuation(bound.get("messages")),
            )
            _record_openai_chat_window(
                installer,
                messages=bound.get("messages") or [],
                source="openai.chat.completions.async",
                model_name=bound.get("model"),
                request_kind="chat.completions",
                request_metadata={
                    "temperature": bound.get("temperature"),
                    "max_tokens": bound.get("max_tokens"),
                    "response_format": _jsonable(bound.get("response_format")),
                    "parallel_tool_calls": bound.get("parallel_tool_calls"),
                },
                tool_choice=bound.get("tool_choice") or bound.get("function_call"),
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
            )
            with suppress_runtime_capture():
                result = await original_async_chat(self, *args, **kwargs)
            selected_tools = _chat_completion_tool_calls(result)
            _remember_selected_tools(
                installer,
                source="openai.chat.completions.tool_call",
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
                selected_tools=selected_tools,
            )
            if installer is not None and selected_tools:
                await installer.preflight_selected_tools_async(
                    source="openai.chat.completions.tool_call",
                    tool_definitions=bound.get("tools") or bound.get("functions") or [],
                    selected_tools=selected_tools,
                )
            assistant_text = _chat_completion_assistant_text(result)
            if installer is not None and assistant_text:
                installer.note_assistant_output(
                    content=assistant_text,
                    source="openai.chat.completions.assistant_output",
                )
            return result

        chat_completions.AsyncCompletions.create = _mark_patched(
            wrapped_async_chat,
            "openai_async_chat_create",
        )
    if (
        chat_completions is not None
        and hasattr(chat_completions.Completions, "parse")
        and not _is_patched(chat_completions.Completions.parse, "openai_chat_parse")
    ):
        original_chat_parse = chat_completions.Completions.parse

        @functools.wraps(original_chat_parse)
        def wrapped_chat_parse(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_chat_parse, (self, *args), kwargs)
            _begin_openai_direct_run(
                installer,
                bound.get("messages") or [],
                continuation_turn=_openai_direct_is_chat_continuation(bound.get("messages")),
            )
            _record_openai_chat_window(
                installer,
                messages=bound.get("messages") or [],
                source="openai.chat.completions.parse",
                model_name=bound.get("model"),
                request_kind="chat.completions.parse",
                request_metadata={
                    "temperature": bound.get("temperature"),
                    "max_tokens": bound.get("max_tokens") or bound.get("max_completion_tokens"),
                    "response_format": _jsonable(bound.get("response_format")),
                    "parallel_tool_calls": bound.get("parallel_tool_calls"),
                    "metadata": _jsonable(bound.get("metadata")),
                    "strict_parse": True,
                },
                tool_choice=bound.get("tool_choice") or bound.get("function_call"),
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
            )
            with suppress_runtime_capture():
                result = original_chat_parse(self, *args, **kwargs)
            _remember_selected_tools(
                installer,
                source="openai.chat.completions.tool_call",
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
                selected_tools=_chat_completion_tool_calls(result),
            )
            if installer is not None:
                installer.preflight_selected_tools(
                    source="openai.chat.completions.tool_call",
                    tool_definitions=bound.get("tools") or bound.get("functions") or [],
                    selected_tools=_chat_completion_tool_calls(result),
                )
            assistant_text = _chat_completion_assistant_text(result)
            if installer is not None and assistant_text:
                installer.note_assistant_output(
                    content=assistant_text,
                    source="openai.chat.completions.assistant_output",
                )
            return result

        chat_completions.Completions.parse = _mark_patched(
            wrapped_chat_parse,
            "openai_chat_parse",
        )
    if (
        chat_completions is not None
        and hasattr(chat_completions, "AsyncCompletions")
        and hasattr(chat_completions.AsyncCompletions, "parse")
        and not _is_patched(chat_completions.AsyncCompletions.parse, "openai_async_chat_parse")
    ):
        original_async_chat_parse = chat_completions.AsyncCompletions.parse

        @functools.wraps(original_async_chat_parse)
        async def wrapped_async_chat_parse(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_async_chat_parse, (self, *args), kwargs)
            _begin_openai_direct_run(
                installer,
                bound.get("messages") or [],
                continuation_turn=_openai_direct_is_chat_continuation(bound.get("messages")),
            )
            _record_openai_chat_window(
                installer,
                messages=bound.get("messages") or [],
                source="openai.chat.completions.async.parse",
                model_name=bound.get("model"),
                request_kind="chat.completions.parse",
                request_metadata={
                    "temperature": bound.get("temperature"),
                    "max_tokens": bound.get("max_tokens") or bound.get("max_completion_tokens"),
                    "response_format": _jsonable(bound.get("response_format")),
                    "parallel_tool_calls": bound.get("parallel_tool_calls"),
                    "metadata": _jsonable(bound.get("metadata")),
                    "strict_parse": True,
                },
                tool_choice=bound.get("tool_choice") or bound.get("function_call"),
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
            )
            with suppress_runtime_capture():
                result = await original_async_chat_parse(self, *args, **kwargs)
            selected_tools = _chat_completion_tool_calls(result)
            _remember_selected_tools(
                installer,
                source="openai.chat.completions.tool_call",
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
                selected_tools=selected_tools,
            )
            if installer is not None and selected_tools:
                await installer.preflight_selected_tools_async(
                    source="openai.chat.completions.tool_call",
                    tool_definitions=bound.get("tools") or bound.get("functions") or [],
                    selected_tools=selected_tools,
                )
            assistant_text = _chat_completion_assistant_text(result)
            if installer is not None and assistant_text:
                installer.note_assistant_output(
                    content=assistant_text,
                    source="openai.chat.completions.assistant_output",
                )
            return result

        chat_completions.AsyncCompletions.parse = _mark_patched(
            wrapped_async_chat_parse,
            "openai_async_chat_parse",
        )
    try:
        import openai.resources.responses.responses as responses_api  # type: ignore
    except Exception:
        responses_api = None
    if (
        responses_api is not None
        and hasattr(responses_api.Responses, "create")
        and not _is_patched(responses_api.Responses.create, "openai_responses_create")
    ):
        original_response = responses_api.Responses.create

        @functools.wraps(original_response)
        def wrapped_response(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_response, (self, *args), kwargs)
            normalized_body = _openai_direct_normalize_responses_request(
                {
                    key: value
                    for key, value in bound.items()
                    if key != "self"
                }
            )
            continuation_turn = bool(
                (normalized_body.get("previous_response_id") if isinstance(normalized_body, dict) else bound.get("previous_response_id"))
                or (
                    _messages_from_responses_input(
                        normalized_body.get("input") if isinstance(normalized_body, dict) else bound.get("input")
                    )[1]
                )
            )
            normalized_tools = (
                normalized_body.get("tools") if isinstance(normalized_body, dict) else bound.get("tools") or []
            )
            _begin_openai_direct_run(
                installer,
                _messages_from_responses_input(
                    normalized_body.get("input") if isinstance(normalized_body, dict) else bound.get("input")
                )[0],
                continuation_turn=continuation_turn,
            )
            call_args, call_kwargs = _replace_call_argument(
                original_response,
                (self, *args),
                kwargs,
                "tools",
                normalized_tools,
            )
            if installer is not None:
                messages, tool_call_ids = _messages_from_responses_input(
                    normalized_body.get("input") if isinstance(normalized_body, dict) else bound.get("input")
                )
                installer.record_conversation_window(
                    messages,
                    source="openai.responses",
                    model_name=(normalized_body.get("model") if isinstance(normalized_body, dict) else bound.get("model")),
                    request_kind="responses",
                    request_metadata={
                        "instructions": normalized_body.get("instructions") if isinstance(normalized_body, dict) else bound.get("instructions"),
                        "max_output_tokens": normalized_body.get("max_output_tokens") if isinstance(normalized_body, dict) else bound.get("max_output_tokens"),
                        "metadata": _jsonable(normalized_body.get("metadata") if isinstance(normalized_body, dict) else bound.get("metadata")),
                    },
                    tool_choice=_jsonable(normalized_body.get("tool_choice") if isinstance(normalized_body, dict) else bound.get("tool_choice")),
                    tool_definitions=_jsonable(normalized_tools),
                    tool_call_ids=tool_call_ids,
                    remember_messages_as_context=True,
                )
            with suppress_runtime_capture():
                result = original_response(*call_args, **call_kwargs)
            _remember_selected_tools(
                installer,
                source="openai.responses.output",
                tool_definitions=normalized_tools,
                selected_tools=_responses_tool_calls(result),
            )
            if installer is not None:
                installer.preflight_selected_tools(
                    source="openai.responses.output",
                    tool_definitions=normalized_tools,
                    selected_tools=_responses_tool_calls(result),
                )
            assistant_text = _responses_assistant_text(result)
            if installer is not None and assistant_text:
                installer.note_assistant_output(
                    content=assistant_text,
                    source="openai.responses.assistant_output",
                )
            return result

        responses_api.Responses.create = _mark_patched(
            wrapped_response,
            "openai_responses_create",
        )
    if (
        responses_api is not None
        and hasattr(responses_api, "AsyncResponses")
        and hasattr(responses_api.AsyncResponses, "create")
        and not _is_patched(responses_api.AsyncResponses.create, "openai_async_responses_create")
    ):
        original_async_response = responses_api.AsyncResponses.create

        @functools.wraps(original_async_response)
        async def wrapped_async_response(self, *args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_async_response, (self, *args), kwargs)
            normalized_body = _openai_direct_normalize_responses_request(
                {
                    key: value
                    for key, value in bound.items()
                    if key != "self"
                }
            )
            continuation_turn = bool(
                (normalized_body.get("previous_response_id") if isinstance(normalized_body, dict) else bound.get("previous_response_id"))
                or (
                    _messages_from_responses_input(
                        normalized_body.get("input") if isinstance(normalized_body, dict) else bound.get("input")
                    )[1]
                )
            )
            normalized_tools = (
                normalized_body.get("tools") if isinstance(normalized_body, dict) else bound.get("tools") or []
            )
            _begin_openai_direct_run(
                installer,
                _messages_from_responses_input(
                    normalized_body.get("input") if isinstance(normalized_body, dict) else bound.get("input")
                )[0],
                continuation_turn=continuation_turn,
            )
            call_args, call_kwargs = _replace_call_argument(
                original_async_response,
                (self, *args),
                kwargs,
                "tools",
                normalized_tools,
            )
            if installer is not None:
                messages, tool_call_ids = _messages_from_responses_input(
                    normalized_body.get("input") if isinstance(normalized_body, dict) else bound.get("input")
                )
                installer.record_conversation_window(
                    messages,
                    source="openai.responses.async",
                    model_name=(normalized_body.get("model") if isinstance(normalized_body, dict) else bound.get("model")),
                    request_kind="responses",
                    request_metadata={
                        "instructions": normalized_body.get("instructions") if isinstance(normalized_body, dict) else bound.get("instructions"),
                        "max_output_tokens": normalized_body.get("max_output_tokens") if isinstance(normalized_body, dict) else bound.get("max_output_tokens"),
                        "metadata": _jsonable(normalized_body.get("metadata") if isinstance(normalized_body, dict) else bound.get("metadata")),
                    },
                    tool_choice=_jsonable(normalized_body.get("tool_choice") if isinstance(normalized_body, dict) else bound.get("tool_choice")),
                    tool_definitions=_jsonable(normalized_tools),
                    tool_call_ids=tool_call_ids,
                    remember_messages_as_context=True,
                )
            with suppress_runtime_capture():
                result = await original_async_response(*call_args, **call_kwargs)
            selected_tools = _responses_tool_calls(result)
            _remember_selected_tools(
                installer,
                source="openai.responses.output",
                tool_definitions=normalized_tools,
                selected_tools=selected_tools,
            )
            if installer is not None and selected_tools:
                await installer.preflight_selected_tools_async(
                    source="openai.responses.output",
                    tool_definitions=normalized_tools,
                    selected_tools=selected_tools,
                )
            assistant_text = _responses_assistant_text(result)
            if installer is not None and assistant_text:
                await installer.note_assistant_output_async(
                    content=assistant_text,
                    source="openai.responses.assistant_output",
                )
            return result

        responses_api.AsyncResponses.create = _mark_patched(
            wrapped_async_response,
            "openai_async_responses_create",
        )


def _patch_litellm():
    try:
        import litellm  # type: ignore
    except Exception:
        return
    original_completion = getattr(litellm, "completion", None)
    if original_completion is not None and not _is_patched(original_completion, "litellm_completion"):
        @functools.wraps(original_completion)
        def wrapped_completion(*args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_completion, args, kwargs)
            if installer is not None:
                installer.record_conversation_window(
                    bound.get("messages") or [],
                    source="litellm.completion",
                    model_name=bound.get("model"),
                    request_kind="chat.completions",
                    request_metadata={
                        "temperature": bound.get("temperature"),
                        "max_tokens": bound.get("max_tokens") or bound.get("max_completion_tokens"),
                        "response_format": _jsonable(bound.get("response_format")),
                        "parallel_tool_calls": bound.get("parallel_tool_calls"),
                    },
                    tool_choice=_jsonable(bound.get("tool_choice") or bound.get("function_call")),
                    tool_definitions=_jsonable(bound.get("tools") or bound.get("functions") or []),
                    remember_messages_as_context=True,
                )
            with suppress_runtime_capture():
                result = original_completion(*args, **kwargs)
            _remember_selected_tools(
                installer,
                source="litellm.completion.tool_call",
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
                selected_tools=_chat_completion_tool_calls(result),
            )
            if installer is not None:
                installer.preflight_selected_tools(
                    source="litellm.completion.tool_call",
                    tool_definitions=bound.get("tools") or bound.get("functions") or [],
                    selected_tools=_chat_completion_tool_calls(result),
                )
            return result

        litellm.completion = _mark_patched(wrapped_completion, "litellm_completion")
    original_acompletion = getattr(litellm, "acompletion", None)
    if original_acompletion is not None and not _is_patched(original_acompletion, "litellm_acompletion"):
        @functools.wraps(original_acompletion)
        async def wrapped_acompletion(*args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_acompletion, args, kwargs)
            if installer is not None:
                installer.record_conversation_window(
                    bound.get("messages") or [],
                    source="litellm.acompletion",
                    model_name=bound.get("model"),
                    request_kind="chat.completions",
                    request_metadata={
                        "temperature": bound.get("temperature"),
                        "max_tokens": bound.get("max_tokens") or bound.get("max_completion_tokens"),
                        "response_format": _jsonable(bound.get("response_format")),
                        "parallel_tool_calls": bound.get("parallel_tool_calls"),
                    },
                    tool_choice=_jsonable(bound.get("tool_choice") or bound.get("function_call")),
                    tool_definitions=_jsonable(bound.get("tools") or bound.get("functions") or []),
                    remember_messages_as_context=True,
                )
            with suppress_runtime_capture():
                result = await original_acompletion(*args, **kwargs)
            selected_tools = _chat_completion_tool_calls(result)
            _remember_selected_tools(
                installer,
                source="litellm.acompletion.tool_call",
                tool_definitions=bound.get("tools") or bound.get("functions") or [],
                selected_tools=selected_tools,
            )
            if installer is not None and selected_tools:
                await installer.preflight_selected_tools_async(
                    source="litellm.acompletion.tool_call",
                    tool_definitions=bound.get("tools") or bound.get("functions") or [],
                    selected_tools=selected_tools,
                )
            return result

        litellm.acompletion = _mark_patched(wrapped_acompletion, "litellm_acompletion")
    original_responses = getattr(litellm, "responses", None)
    if original_responses is not None and not _is_patched(original_responses, "litellm_responses"):
        @functools.wraps(original_responses)
        def wrapped_responses(*args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_responses, args, kwargs)
            if installer is not None:
                messages, tool_call_ids = _messages_from_responses_input(bound.get("input"))
                installer.record_conversation_window(
                    messages,
                    source="litellm.responses",
                    model_name=bound.get("model"),
                    request_kind="responses",
                    request_metadata={
                        "instructions": bound.get("instructions"),
                        "max_output_tokens": bound.get("max_output_tokens"),
                        "metadata": _jsonable(bound.get("metadata")),
                    },
                    tool_choice=_jsonable(bound.get("tool_choice")),
                    tool_definitions=_jsonable(bound.get("tools") or []),
                    tool_call_ids=tool_call_ids,
                    remember_messages_as_context=True,
                )
            with suppress_runtime_capture():
                result = original_responses(*args, **kwargs)
            _remember_selected_tools(
                installer,
                source="litellm.responses.tool_call",
                tool_definitions=bound.get("tools") or [],
                selected_tools=_responses_tool_calls(result),
            )
            if installer is not None:
                installer.preflight_selected_tools(
                    source="litellm.responses.tool_call",
                    tool_definitions=bound.get("tools") or [],
                    selected_tools=_responses_tool_calls(result),
                )
            return result

        litellm.responses = _mark_patched(wrapped_responses, "litellm_responses")
    original_aresponses = getattr(litellm, "aresponses", None)
    if original_aresponses is not None and not _is_patched(original_aresponses, "litellm_aresponses"):
        @functools.wraps(original_aresponses)
        async def wrapped_aresponses(*args, **kwargs):
            installer = _DEFAULT_INSTALLER
            bound = _bind_arguments(original_aresponses, args, kwargs)
            if installer is not None:
                messages, tool_call_ids = _messages_from_responses_input(bound.get("input"))
                installer.record_conversation_window(
                    messages,
                    source="litellm.aresponses",
                    model_name=bound.get("model"),
                    request_kind="responses",
                    request_metadata={
                        "instructions": bound.get("instructions"),
                        "max_output_tokens": bound.get("max_output_tokens"),
                        "metadata": _jsonable(bound.get("metadata")),
                    },
                    tool_choice=_jsonable(bound.get("tool_choice")),
                    tool_definitions=_jsonable(bound.get("tools") or []),
                    tool_call_ids=tool_call_ids,
                    remember_messages_as_context=True,
                )
            with suppress_runtime_capture():
                result = await original_aresponses(*args, **kwargs)
            selected_tools = _responses_tool_calls(result)
            _remember_selected_tools(
                installer,
                source="litellm.responses.tool_call",
                tool_definitions=bound.get("tools") or [],
                selected_tools=selected_tools,
            )
            if installer is not None and selected_tools:
                await installer.preflight_selected_tools_async(
                    source="litellm.responses.tool_call",
                    tool_definitions=bound.get("tools") or [],
                    selected_tools=selected_tools,
                )
            return result

        litellm.aresponses = _mark_patched(wrapped_aresponses, "litellm_aresponses")


def _patch_botocore():
    try:
        import botocore.client  # type: ignore
    except Exception:
        return
    original = botocore.client.BaseClient._make_api_call
    if _is_patched(original, "botocore_api_call"):
        return

    @functools.wraps(original)
    def wrapped(self, operation_name, api_params, *args, **kwargs):
        if runtime_capture_suppressed():
            return original(self, operation_name, api_params, *args, **kwargs)
        installer = _current_or_default_installer()
        details = _botocore_boundary_details(
            getattr(getattr(self, "meta", None), "service_model", None).service_name
            if getattr(getattr(self, "meta", None), "service_model", None) is not None
            else "",
            str(operation_name),
            api_params if isinstance(api_params, dict) else {},
        )
        if installer is None or details is None:
            return original(self, operation_name, api_params, *args, **kwargs)
        return installer.intercept_boundary(
            surface=details["surface"],
            operation=f"botocore.{operation_name}",
            target=details["target"],
            method=str(operation_name),
            transport_args={
                "service": getattr(getattr(self, "meta", None), "service_model", None).service_name
                if getattr(getattr(self, "meta", None), "service_model", None) is not None
                else None,
                "operation": operation_name,
                "params": _jsonable(api_params),
            },
            action_class=details["action_class"],
            trust_boundary_crossing=details["trust_boundary_crossing"],
            execute=lambda: original(self, operation_name, api_params, *args, **kwargs),
        )

    botocore.client.BaseClient._make_api_call = _mark_patched(
        wrapped,
        "botocore_api_call",
    )


def _patch_dbapi_connector(module_name: str, *, dialect: str):
    try:
        module = __import__(module_name)
    except Exception:
        return
    connect = getattr(module, "connect", None)
    if connect is None or _is_patched(connect, f"{module_name}_connect"):
        return

    @functools.wraps(connect)
    def wrapped(*args, **kwargs):
        connection = connect(*args, **kwargs)
        dsn = None
        for candidate in (
            args[0] if args else None,
            kwargs.get("dsn"),
            kwargs.get("database"),
            kwargs.get("host"),
        ):
            if candidate is not None:
                dsn = str(candidate)
                break
        return _wrap_db_connection(connection, dialect=dialect, dsn=dsn)

    setattr(module, "connect", _mark_patched(wrapped, f"{module_name}_connect"))


def _patch_dbapi_connectors():
    _patch_dbapi_connector("sqlite3", dialect="sqlite")
    _patch_dbapi_connector("psycopg", dialect="postgres")
    _patch_dbapi_connector("psycopg2", dialect="postgres")


def _patch_sqlalchemy():
    try:
        import sqlalchemy.engine  # type: ignore
    except Exception:
        return
    connection_cls = getattr(sqlalchemy.engine, "Connection", None)
    if connection_cls is None:
        return
    original_execute = getattr(connection_cls, "execute", None)
    if original_execute is not None and not _is_patched(original_execute, "sqlalchemy_execute"):
        @functools.wraps(original_execute)
        def wrapped_execute(self, statement, *args, **kwargs):
            if runtime_capture_suppressed():
                return original_execute(self, statement, *args, **kwargs)
            installer = _current_or_default_installer()
            if installer is None or not _looks_like_sql_mutation(statement):
                return original_execute(self, statement, *args, **kwargs)
            sql_text = _normalized_sql_text(statement)
            engine_url = str(getattr(getattr(self, "engine", None), "url", "") or "")
            target = _sql_target(sql_text, default=engine_url or "sqlalchemy")
            transport_args = {
                "statement": sql_text,
                "parameters": _jsonable(args[0] if args else kwargs.get("parameters")),
            }
            if _should_skip_sql_boundary_capture(installer, target=target, transport_args=transport_args):
                return original_execute(self, statement, *args, **kwargs)
            boundary_kind, action_class = _sql_boundary_overrides(
                installer,
                target=target,
                transport_args=transport_args,
            )
            boundary_transport_args = _sql_transport_args_for_boundary(
                installer,
                transport_args=transport_args,
            )
            return installer.intercept_boundary(
                surface="db_mutation",
                operation="sqlalchemy.Connection.execute",
                target=target,
                method=_sql_operation(sql_text),
                transport_args=boundary_transport_args,
                boundary_kind=boundary_kind,
                action_class=action_class,
                trust_boundary_crossing=False,
                execute=lambda: original_execute(self, statement, *args, **kwargs),
            )

        connection_cls.execute = _mark_patched(wrapped_execute, "sqlalchemy_execute")
    original_driver_sql = getattr(connection_cls, "exec_driver_sql", None)
    if original_driver_sql is None or _is_patched(original_driver_sql, "sqlalchemy_exec_driver_sql"):
        return

    @functools.wraps(original_driver_sql)
    def wrapped_driver_sql(self, statement, *args, **kwargs):
        if runtime_capture_suppressed():
            return original_driver_sql(self, statement, *args, **kwargs)
        installer = _current_or_default_installer()
        if installer is None or not _looks_like_sql_mutation(statement):
            return original_driver_sql(self, statement, *args, **kwargs)
        sql_text = _normalized_sql_text(statement)
        engine_url = str(getattr(getattr(self, "engine", None), "url", "") or "")
        target = _sql_target(sql_text, default=engine_url or "sqlalchemy")
        transport_args = {
            "statement": sql_text,
            "parameters": _jsonable(args[0] if args else kwargs.get("parameters")),
        }
        if _should_skip_sql_boundary_capture(installer, target=target, transport_args=transport_args):
            return original_driver_sql(self, statement, *args, **kwargs)
        boundary_kind, action_class = _sql_boundary_overrides(
            installer,
            target=target,
            transport_args=transport_args,
        )
        boundary_transport_args = _sql_transport_args_for_boundary(
            installer,
            transport_args=transport_args,
        )
        return installer.intercept_boundary(
            surface="db_mutation",
            operation="sqlalchemy.Connection.exec_driver_sql",
            target=target,
            method=_sql_operation(sql_text),
            transport_args=boundary_transport_args,
            boundary_kind=boundary_kind,
            action_class=action_class,
            trust_boundary_crossing=False,
            execute=lambda: original_driver_sql(self, statement, *args, **kwargs),
        )

    connection_cls.exec_driver_sql = _mark_patched(
        wrapped_driver_sql,
        "sqlalchemy_exec_driver_sql",
    )


def _patch_kombu():
    try:
        import kombu.messaging  # type: ignore
    except Exception:
        return
    original = getattr(kombu.messaging.Producer, "publish", None)
    if original is None or _is_patched(original, "kombu_publish"):
        return

    @functools.wraps(original)
    def wrapped(self, body, *args, **kwargs):
        if runtime_capture_suppressed():
            return original(self, body, *args, **kwargs)
        installer = _current_or_default_installer()
        if installer is None:
            return original(self, body, *args, **kwargs)
        exchange = kwargs.get("exchange") or getattr(self, "exchange", None)
        routing_key = kwargs.get("routing_key")
        target = f"queue://{exchange or 'default'}/{routing_key or ''}".rstrip("/")
        return installer.intercept_boundary(
            surface="queue_publish",
            operation="kombu.Producer.publish",
            target=target,
            method="PUBLISH",
            transport_args={
                "body": _jsonable(body),
                "exchange": str(exchange) if exchange is not None else None,
                "routing_key": routing_key,
                "headers": _jsonable(kwargs.get("headers")),
            },
            action_class="upload",
            trust_boundary_crossing=True,
            execute=lambda: original(self, body, *args, **kwargs),
        )

    kombu.messaging.Producer.publish = _mark_patched(wrapped, "kombu_publish")


def _patch_browser_method(owner: Any, method_name: str, patch_name: str):
    original = getattr(owner, method_name, None)
    if original is None or _is_patched(original, patch_name):
        return

    @functools.wraps(original)
    def wrapped(self, *args, **kwargs):
        if runtime_capture_suppressed():
            return original(self, *args, **kwargs)
        installer = _current_or_default_installer()
        if installer is None:
            return original(self, *args, **kwargs)
        target = _browser_target(self, args)
        page_url = getattr(self, "url", None)
        effective_target = target if isinstance(target, str) else method_name
        trust_boundary_crossing = False
        if isinstance(page_url, str) and page_url:
            trust_boundary_crossing = not _host_is_local(page_url)
        elif isinstance(effective_target, str) and effective_target.startswith("http"):
            trust_boundary_crossing = not _host_is_local(effective_target)
        return installer.intercept_boundary(
            surface="browser",
            operation=f"{owner.__name__}.{method_name}",
            target=effective_target,
            method=method_name.upper(),
            transport_args={
                "page_url": page_url,
                "selector": args[0] if args and isinstance(args[0], str) else None,
                "args": _jsonable(args),
                "kwargs": _jsonable(kwargs),
            },
            action_class=_browser_action_class(method_name),
            trust_boundary_crossing=trust_boundary_crossing,
            execute=lambda: original(self, *args, **kwargs),
        )

    setattr(owner, method_name, _mark_patched(wrapped, patch_name))


def _patch_playwright():
    try:
        import playwright.sync_api  # type: ignore
    except Exception:
        return
    for owner_name, methods in {
        "Page": ["goto", "click", "dblclick", "fill", "press", "check", "uncheck", "select_option"],
        "Locator": ["click", "dblclick", "fill", "press", "check", "uncheck", "select_option"],
    }.items():
        owner = getattr(playwright.sync_api, owner_name, None)
        if owner is None:
            continue
        for method_name in methods:
            _patch_browser_method(
                owner,
                method_name,
                f"playwright_{owner_name.lower()}_{method_name}",
            )
