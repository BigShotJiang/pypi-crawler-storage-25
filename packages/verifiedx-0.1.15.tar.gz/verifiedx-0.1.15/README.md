# VerifiedX Python SDK

Minimal Python SDK for framework-native VerifiedX capture and boundary preflight.

## Install

```bash
pip install verifiedx
```

Protect one action free: [verifiedx.me](https://verifiedx.me/?vx_source=pypi.python-readme)

Docs: [docs.verifiedx.me/sdks/python](https://docs.verifiedx.me/sdks/python)

Doctor: `verifiedx doctor`

Create a project and runtime key in the VerifiedX dashboard, then set `VERIFIEDX_API_KEY` in the app environment. `VERIFIEDX_BASE_URL` is optional and only needed for self-hosting or non-default environments.

## Quickstart

```python
from verifiedx import init_verifiedx

vx = init_verifiedx()


class AgentHarness:
    def call_model(self, messages):
        return {"messages": messages}

    def send_email(self, to, body):
        return {"to": to, "body": body, "status": "sent"}


harness = AgentHarness()
vx.install_runtime(
    harness,
    llm={"call_model": {"model_name": "gpt-5.4-mini"}},
    tools={"send_email": {}},
)
```

`init_verifiedx()` stays stable. The default integration path is now a single `install_runtime(...)` bind that auto-instruments supported Python runtime surfaces, captures conversation windows, and routes boundary decisions through the V4 raw-capture lane without builder-authored semantic callbacks.

Minimal launch env:

```bash
export VERIFIEDX_API_KEY="vxpk_..."
```

LangGraph: `from verifiedx.langgraph import compile`

LangGraph native adapter, few LOC:

```python
from verifiedx import init_verifiedx, install_langgraph
from langgraph.graph import StateGraph

vx = init_verifiedx()
install_langgraph(verifiedx=vx)

builder = StateGraph(MyState)
# add nodes / edges as usual
graph = builder.compile(checkpointer=my_checkpointer, store=my_store)
```

That path keeps LangGraph-native capture and trigger naming for `Command(update=...)`, `graph.update_state`, `store.get/search/put/delete`, `checkpointer.put/put_writes`, LangGraph tool execution through `BaseTool.invoke/ainvoke`, `AIMessage.tool_calls`, and `ToolMessage.tool_call_id`.

LangChain: `from verifiedx.langchain import create_agent`

OpenAI direct: `from verifiedx import install_openai_direct`

OpenAI Agents: `from verifiedx import install_openai_agents`

Anthropic direct: `from verifiedx import install_anthropic_direct`

Claude Agent SDK: `from verifiedx import install_claude_agent`

Doctor: `verifiedx doctor`

Repo detection / install planning:

```bash
verifiedx verify --json
verifiedx init --write --json
```

`verify` reports the recommended VerifiedX seam plus the repo's detected capture/trigger layers:

- adapter seams
- lower seams
- explicit wrappers
