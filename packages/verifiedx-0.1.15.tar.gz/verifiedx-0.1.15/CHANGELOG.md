# Changelog

## 0.1.15 - 2026-04-24

- Captured real LangGraph retrieval tool results as compact same-run factual artifacts so V4 can allow justified support actions without noisy full context.
- Fixed runtime scope isolation across multiple VerifiedX instances and adapter-owned tool invocations.
- Recorded Anthropic direct tool dispatch generically before preflight so custom actions are guarded without guessing wild harness action names.

## 0.1.14 - 2026-04-23

- Fixed the MCP Python adapter so builder-defined high-impact MCP tools use real VerifiedX action preflight instead of falling through to lower-seam-only observation.
- Tightened MCP Python custom-tool classification with schema and docstring context so support-style actions like credits, refunds, pauses, reactivations, and account changes are recognized as true triggers.

## 0.1.13 - 2026-04-23

- Fixed the Anthropic direct Python adapter so builder-defined high-impact custom tools are preflighted as true action boundaries instead of falling back to lower-seam coincidence.
- Kept harmless Anthropic direct helper tools in capture while promoting real custom mutations like refunds, credits, pauses, and account changes into direct guarded actions.

## 0.1.12 - 2026-04-23

- Fixed Claude Agent adapter fallback behavior when a real repo ships its own `claude_agent_sdk.py`, so one-command installs do not break on local module shadowing.
- Aligned the public Python release with the one-command installer fix for repo-shaped Claude query wrapping.

## 0.1.11 - 2026-04-23

- Published the coordinated one-step agentic installer update alongside the TypeScript CLI so Python repos now participate in the same end-to-end default install flow.
- Tightened raw Python multi-agent validation and repo-owned trigger precision in the public agentic install path.
- Aligned Python release metadata with the new default agentic installer contract.

## 0.1.10 - 2026-04-23

- Added the public one-shot install path for Python repos so VerifiedX can land additively at the native seam, lower seam, or raw runtime with smoke verification.
- Expanded installer support across LangGraph, LangChain, OpenAI Agents, Claude Agent SDK, OpenAI direct, Anthropic direct, MCP, and bare Python harnesses.
- Tightened repo-aware capture vs trigger binding so harmless helpers remain capture-only while true high-impact mutations are preflighted at the action boundary.

## 0.1.2 - 2026-04-09

- Added the newer core verification workflow and tightened V4 runtime capture, loopback, and receipt behavior across the raw Python lane.
- Upgraded standalone Python MCP wrappers so high-impact MCP tool handlers preflight protected actions and return the normal blocked loopback shape.
- Hardened Python client error handling, runtime config behavior, and zero-touch capture paths after the initial 0.1.1 release.

## 0.1.1 - 2026-04-05

- Stabilized raw Python runtime capture, chronological `tool_calls_in_run`, and lower-seam fallback coverage.
- Added first-class adapters for OpenAI direct, OpenAI Agents, Anthropic direct, Claude Agent SDK, LangGraph, and MCP.
- Hardened release packaging so the published wheel/sdist ship the SDK code and runtime shim assets without test or fixture baggage.
