# hiveplot_matrix.py

"""
Visualization functions for ``HivePlotMatrix`` instances.
"""

from typing import TYPE_CHECKING, Any, Dict, Hashable, List, Optional, Tuple, Union

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.image import AxesImage

if TYPE_CHECKING:
    from hiveplotlib.hiveplot import HivePlot
    from hiveplotlib.hiveplot_matrix import HivePlotMatrix


def _plot_cell_matplotlib(
    hp: "HivePlot",
    fig: plt.Figure,
    ax: plt.Axes,
    tags: Optional[Union[Hashable, List[Hashable]]] = None,
    **kwargs: object,
) -> Tuple[plt.Figure, plt.Axes]:
    """
    Plot a single HivePlot cell using the matplotlib backend.

    :param hp: ``HivePlot`` instance to plot.
    :param fig: matplotlib figure.
    :param ax: matplotlib axes.
    :param tags: which tag(s) to plot.
    :param kwargs: additional keyword arguments for ``hive_plot_viz()``.
    :return: ``(fig, ax)`` tuple.
    """
    from hiveplotlib.viz.matplotlib import hive_plot_viz

    return hive_plot_viz(hp, fig=fig, ax=ax, tags=tags, **kwargs)  # ty:ignore[invalid-argument-type]


def _plot_cell_datashader(
    hp: "HivePlot",
    fig: plt.Figure,
    ax: plt.Axes,
    tag: Optional[Hashable] = None,
    **kwargs: object,
) -> Tuple[plt.Figure, plt.Axes, Optional[AxesImage], Optional[AxesImage]]:
    """
    Plot a single HivePlot cell using the datashader backend.

    :param hp: ``HivePlot`` instance to plot.
    :param fig: matplotlib figure.
    :param ax: matplotlib axes.
    :param tag: which tag to plot.
    :param kwargs: additional keyword arguments for ``datashade_hive_plot_mpl()``.
    :return: ``(fig, ax, im_nodes, im_edges)`` tuple.
    """
    from hiveplotlib.viz.datashader import datashade_hive_plot_mpl

    return datashade_hive_plot_mpl(hp, fig=fig, ax=ax, tag=tag, **kwargs)  # ty:ignore[invalid-argument-type]


def _unify_clim(
    im_dict: Dict[Tuple[int, int], AxesImage],
) -> None:
    """
    Unify the color limits across all ``AxesImage`` instances in a dictionary.

    Finds the maximum ``vmax`` across all images and applies it to each, so that
    all cells share a consistent color scale.

    :param im_dict: mapping of ``(row, col)`` to ``AxesImage``.
    """
    if not im_dict:
        return
    global_vmax = max(im.get_clim()[1] for im in im_dict.values())
    for im in im_dict.values():
        im.set_clim(vmax=global_vmax)


def _ensure_2d_axes(axes: object, nrows: int, ncols: int) -> np.ndarray:
    """
    Ensure axes from plt.subplots is always a 2D numpy array.

    :param axes: axes from ``plt.subplots()``.
    :param nrows: number of rows.
    :param ncols: number of columns.
    :return: 2D numpy array of axes.
    """
    if nrows == 1 and ncols == 1:
        return np.array([[axes]])
    if nrows == 1:
        return np.asarray(axes)[np.newaxis, :]
    if ncols == 1:
        return np.asarray(axes)[:, np.newaxis]
    return np.asarray(axes)


def _has_repeat_axes(matrix: "HivePlotMatrix") -> bool:
    """
    Detect whether any populated cell in the matrix has repeat axes.

    :param matrix: ``HivePlotMatrix`` instance.
    :return: ``True`` if any cell has repeat axes.
    """
    for _r, _c, hp in matrix.iter_populated_cells():
        if any(str(axis_id).endswith("_repeat") for axis_id in hp.axes):
            return True
    return False


def plot_from_partition(
    matrix: "HivePlotMatrix",
    figsize: Optional[Tuple[float, float]] = None,
    dpi: int = 150,
    diagonal_buffer: float = 0.3,
    off_diagonal_buffer: float = 0.2,
    diagonal_pixel_spread_nodes: int = 4,
    off_diagonal_pixel_spread_nodes: int = 7,
    pixel_spread_edges: int = 1,
    vmax_nodes: Optional[float] = None,
    vmax_edges: Optional[float] = None,
    show_node_colorbar: bool = True,
    show_edge_colorbar: bool = True,
    show_axes_labels: bool = True,
    axes_labels_buffer: float = 1.1,
    axes_labels_fontsize: int = 10,
    label_fontsize: int = 20,
    text_kwargs: Optional[dict] = None,
    **kwargs: object,
) -> Union[
    Tuple[plt.Figure, np.ndarray],
    Tuple[
        plt.Figure,
        np.ndarray,
        Dict[Tuple[int, int], AxesImage],
        Dict[Tuple[int, int], AxesImage],
    ],
]:
    """
    Plot a ``from_partition`` type ``HivePlotMatrix``.

    :param matrix: ``HivePlotMatrix`` instance.
    :param figsize: figure size. Default computes from grid shape (``4 * ncols``, ``4 * nrows``).
    :param dpi: figure DPI.
    :param diagonal_buffer: buffer for diagonal cells.
    :param off_diagonal_buffer: buffer for off-diagonal cells.
    :param diagonal_pixel_spread_nodes: pixel spread for nodes on diagonal (datashader).
    :param off_diagonal_pixel_spread_nodes: pixel spread for nodes off-diagonal (datashader).
    :param pixel_spread_edges: pixel spread for edges (datashader).
    :param vmax_nodes: shared vmax for node density (datashader). Default ``None`` auto-detects based on the maximum
        across all cells.
    :param vmax_edges: shared vmax for edge density (datashader). Default ``None`` auto-detects based on the maximum
        across all cells.
    :param show_node_colorbar: whether to show the node density colorbar (datashader).
    :param show_edge_colorbar: whether to show the edge density colorbar (datashader).
    :param show_axes_labels: whether to show axis labels on each cell.
    :param axes_labels_buffer: buffer for axis labels.
    :param axes_labels_fontsize: font size for axis labels.
    :param label_fontsize: font size for row/column labels.
    :param text_kwargs: additional kwargs for axis label text.
    :param kwargs: additional kwargs forwarded to per-cell hive plot viz calls.
    :return: ``(fig, axes)`` for matplotlib,
        ``(fig, axes, im_nodes_dict, im_edges_dict)`` for datashader.
    """
    text_kwargs = text_kwargs or {}
    nrows, ncols = matrix.shape

    if figsize is None:
        figsize = (4 * ncols, 4 * nrows)

    fig, axes_raw = plt.subplots(nrows, ncols, figsize=figsize, dpi=dpi)
    axes = _ensure_2d_axes(axes_raw, nrows, ncols)

    is_datashader = matrix._backend == "datashader"

    im_nodes_dict: Dict[Tuple[int, int], AxesImage] = {}
    im_edges_dict: Dict[Tuple[int, int], AxesImage] = {}

    # track a reference im_nodes and im_edges for colorbars
    ref_im_nodes: Optional[AxesImage] = None
    ref_im_edges: Optional[AxesImage] = None

    for r in range(nrows):
        for c in range(ncols):
            ax = axes[r, c]
            hp = matrix[r, c]

            if hp is None:
                # lower triangle or empty
                ax.axis("off")
                continue

            is_diagonal = r == c
            buf = diagonal_buffer if is_diagonal else off_diagonal_buffer

            if is_datashader:
                cell_kwargs: dict = {
                    "buffer": buf,
                    "show_axes_labels": show_axes_labels,
                    "axes_labels_buffer": axes_labels_buffer,
                    "axes_labels_fontsize": axes_labels_fontsize,
                    "pixel_spread_nodes": diagonal_pixel_spread_nodes
                    if is_diagonal
                    else off_diagonal_pixel_spread_nodes,
                    "pixel_spread_edges": pixel_spread_edges,
                    "text_kwargs": text_kwargs,
                }
                if vmax_nodes is not None:
                    cell_kwargs["vmax_nodes"] = vmax_nodes
                if vmax_edges is not None:
                    cell_kwargs["vmax_edges"] = vmax_edges
                if matrix._node_plot_kwargs:
                    cell_kwargs["node_kwargs"] = matrix._node_plot_kwargs
                cell_kwargs.update(kwargs)

                _, _, im_nodes, im_edges = _plot_cell_datashader(
                    hp, fig=fig, ax=ax, **cell_kwargs
                )
                if im_nodes is not None:
                    im_nodes_dict[(r, c)] = im_nodes
                    if ref_im_nodes is None:
                        ref_im_nodes = im_nodes
                if im_edges is not None:
                    im_edges_dict[(r, c)] = im_edges
                    if ref_im_edges is None:
                        ref_im_edges = im_edges
            else:
                cell_kwargs: dict[str, Any] = {
                    "buffer": buf,
                    "show_axes_labels": show_axes_labels,
                    "axes_labels_buffer": axes_labels_buffer,
                    "axes_labels_fontsize": axes_labels_fontsize,
                    "text_kwargs": text_kwargs,
                }
                if matrix._node_plot_kwargs:
                    cell_kwargs["node_kwargs"] = matrix._node_plot_kwargs
                cell_kwargs.update(kwargs)
                _plot_cell_matplotlib(hp, fig=fig, ax=ax, **cell_kwargs)

            # zoom for diagonal cells (repeat axes in upper-left quadrant)
            if is_diagonal:
                polar_end = hp.max_polar_end
                assert polar_end is not None
                # use the same 0.1 buffer fraction that _matplotlib_fig_setup
                # applies when centering the full plot
                setup_buffer = 0.1
                max_radius = polar_end + setup_buffer * polar_end
                buffer_radius = setup_buffer * polar_end
                ax.set_xlim(-max_radius, buffer_radius)
                ax.set_ylim(-buffer_radius, max_radius)

    # unify color scales across cells when user didn't supply explicit vmax
    if is_datashader:
        if vmax_nodes is None:
            _unify_clim(im_nodes_dict)
        if vmax_edges is None:
            _unify_clim(im_edges_dict)

    # labels
    col_labels = matrix.col_labels
    row_labels = matrix.row_labels

    if col_labels is not None:
        for c in range(ncols):
            # find the first populated cell in this column for the title
            for r in range(nrows):
                if matrix[r, c] is not None:
                    axes[r, c].set_title(
                        str(col_labels[c]).replace(" ", "\n"),
                        y=1.35,
                        size=label_fontsize,
                        va="top",
                    )
                    break

    if row_labels is not None:
        for r in range(nrows):
            # find the last populated cell in this row for the label
            for c in range(ncols - 1, -1, -1):
                if matrix[r, c] is not None:
                    is_diagonal = r == c
                    # different position for diagonal (zoomed) vs off-diagonal
                    if is_diagonal:
                        axes[r, c].text(
                            1.32,
                            0.5,
                            str(row_labels[r]).replace(" ", "\n"),
                            size=label_fontsize,
                            transform=axes[r, c].transAxes,
                        )
                    else:
                        axes[r, c].text(
                            1.32,
                            0.55,
                            str(row_labels[r]).replace(" ", "\n"),
                            size=label_fontsize,
                            transform=axes[r, c].transAxes,
                        )
                    break

    # colorbars for datashader
    if is_datashader:
        # use bottom-left corner of the matrix for colorbar placement
        colorbar_ax = axes[nrows - 1, 0]

        if show_edge_colorbar and ref_im_edges is not None:
            cax_edges = colorbar_ax.inset_axes(
                [0.0, 0.6, 2, 0.2], transform=colorbar_ax.transAxes
            )
            cb_edges = fig.colorbar(
                ref_im_edges,
                ax=colorbar_ax,
                cax=cax_edges,
                orientation="horizontal",
                extend="max",
            )
            cb_edges.ax.set_title("Edge Density", size=16)
            cb_edges.ax.tick_params(labelsize=16)

        if show_node_colorbar and ref_im_nodes is not None:
            cax_nodes = colorbar_ax.inset_axes(
                [0.0, 0.1, 2, 0.2], transform=colorbar_ax.transAxes
            )
            cb_nodes = fig.colorbar(
                ref_im_nodes,
                ax=colorbar_ax,
                cax=cax_nodes,
                orientation="horizontal",
                extend="max",
            )
            cb_nodes.ax.set_title("Node Density", size=16)
            cb_nodes.ax.tick_params(labelsize=16)

        return fig, axes, im_nodes_dict, im_edges_dict

    return fig, axes


def plot_non_partition(
    matrix: "HivePlotMatrix",
    figsize: Optional[Tuple[float, float]] = None,
    dpi: int = 150,
    buffer: Optional[float] = None,
    pixel_spread_nodes: int = 5,
    pixel_spread_edges: int = 1,
    row_label_rotation: float = 0,
    vmax_nodes: Optional[float] = None,
    vmax_edges: Optional[float] = None,
    show_node_colorbar: bool = True,
    show_edge_colorbar: bool = True,
    show_axes_labels: bool = True,
    axes_labels_buffer: float = 1.1,
    axes_labels_fontsize: int = 16,
    label_fontsize: int = 16,
    text_kwargs: Optional[dict] = None,
    per_tag_kwargs: Optional[Dict[Hashable, dict]] = None,
    **kwargs: object,
) -> Union[
    Tuple[plt.Figure, np.ndarray],
    Tuple[
        plt.Figure,
        np.ndarray,
        Dict[Tuple[int, int], AxesImage],
        Dict[Tuple[int, int], AxesImage],
    ],
]:
    """
    Plot a non-partition ``HivePlotMatrix`` where all cells share identical settings.

    Used for ``"from_variable_sweep"``, ``"from_tags"``, and ``"generic"`` matrix types.

    :param matrix: ``HivePlotMatrix`` instance.
    :param figsize: figure size. Default ``(cell_size * ncols, cell_size * nrows)`` where
        ``cell_size`` is ``6`` when repeat axes are detected, ``4`` otherwise.
    :param dpi: figure DPI.
    :param buffer: buffer for all cells. Default ``None`` auto-detects based on whether
        cells have repeat axes (``0.3``) or not (``0.1``).
    :param pixel_spread_nodes: pixel spread for nodes (datashader).
    :param pixel_spread_edges: pixel spread for edges (datashader).
    :param row_label_rotation: rotation angle for row labels. Default ``0`` (horizontal).
        Set to ``90`` for vertical labels when labels are long.
    :param vmax_nodes: shared vmax for node density (datashader). Default ``None`` auto-detects based on the maximum
        across all cells.
    :param vmax_edges: shared vmax for edge density (datashader). Default ``None`` auto-detects based on the maximum
        across all cells.
    :param show_node_colorbar: whether to show the node density colorbar (datashader).
    :param show_edge_colorbar: whether to show the edge density colorbar (datashader).
    :param show_axes_labels: whether to show axis labels.
    :param axes_labels_buffer: buffer for axis labels.
    :param axes_labels_fontsize: font size for axis labels.
    :param label_fontsize: font size for row/column labels.
    :param text_kwargs: additional kwargs for axis label text.
    :param per_tag_kwargs: per-tag keyword arguments merged into each cell's render call,
        keyed by tag value (e.g. ``{"Tag0": {"cmap_edges": "viridis"}}``). Takes precedence
        over any ``per_tag_plot_kwargs`` stored on the matrix instance. Only has effect for
        ``"from_tags"`` hive plot matrices where each cell has an associated tag.
    :param kwargs: additional kwargs forwarded to per-cell plot calls.
    :return: ``(fig, axes)`` for matplotlib,
        ``(fig, axes, im_nodes_dict, im_edges_dict)`` for datashader.
    """
    text_kwargs = text_kwargs or {}
    nrows, ncols = matrix.shape

    # auto-detect repeat axes for buffer and figsize defaults
    repeat_detected = _has_repeat_axes(matrix)

    if buffer is None:
        buffer = 0.4 if repeat_detected else 0.2

    if figsize is None:
        cell_size = 6 if repeat_detected else 4
        figsize = (cell_size * ncols, cell_size * nrows)

    fig, axes_raw = plt.subplots(nrows, ncols, figsize=figsize, dpi=dpi)
    axes = _ensure_2d_axes(axes_raw, nrows, ncols)

    is_datashader = matrix._backend == "datashader"

    im_nodes_dict: Dict[Tuple[int, int], AxesImage] = {}
    im_edges_dict: Dict[Tuple[int, int], AxesImage] = {}
    ref_im_nodes: Optional[AxesImage] = None
    ref_im_edges: Optional[AxesImage] = None

    # determine per-cell tag if from_tags
    tags_per_cell = matrix._tags_per_cell

    for r in range(nrows):
        for c in range(ncols):
            ax = axes[r, c]
            hp = matrix[r, c]

            if hp is None:
                ax.axis("off")
                continue

            cell_tag = tags_per_cell.get((r, c)) if tags_per_cell else None

            if is_datashader:
                cell_kwargs: dict = {
                    "buffer": buffer,
                    "show_axes_labels": show_axes_labels,
                    "axes_labels_buffer": axes_labels_buffer,
                    "axes_labels_fontsize": axes_labels_fontsize,
                    "pixel_spread_nodes": pixel_spread_nodes,
                    "pixel_spread_edges": pixel_spread_edges,
                    "text_kwargs": text_kwargs,
                }
                if vmax_nodes is not None:
                    cell_kwargs["vmax_nodes"] = vmax_nodes
                if vmax_edges is not None:
                    cell_kwargs["vmax_edges"] = vmax_edges
                if matrix._node_plot_kwargs:
                    cell_kwargs["node_kwargs"] = matrix._node_plot_kwargs
                cell_kwargs.update(kwargs)
                if cell_tag is not None:
                    for tag_kw in [
                        matrix._per_tag_plot_kwargs.get(cell_tag, {}),
                        (per_tag_kwargs or {}).get(cell_tag, {}),
                    ]:
                        cell_kwargs.update(tag_kw)

                _, _, im_nodes, im_edges = _plot_cell_datashader(
                    hp, fig=fig, ax=ax, tag=cell_tag, **cell_kwargs
                )
                if im_nodes is not None:
                    im_nodes_dict[(r, c)] = im_nodes
                    if ref_im_nodes is None:
                        ref_im_nodes = im_nodes
                if im_edges is not None:
                    im_edges_dict[(r, c)] = im_edges
                    if ref_im_edges is None:
                        ref_im_edges = im_edges
            else:
                cell_kwargs: dict[str, Any] = {
                    "buffer": buffer,
                    "show_axes_labels": show_axes_labels,
                    "axes_labels_buffer": axes_labels_buffer,
                    "axes_labels_fontsize": axes_labels_fontsize,
                    "text_kwargs": text_kwargs,
                }
                if matrix._node_plot_kwargs:
                    cell_kwargs["node_kwargs"] = matrix._node_plot_kwargs
                cell_kwargs.update(kwargs)
                if cell_tag is not None:
                    for tag_kw in [
                        matrix._per_tag_plot_kwargs.get(cell_tag, {}),
                        (per_tag_kwargs or {}).get(cell_tag, {}),
                    ]:
                        cell_kwargs.update(tag_kw)
                # for from_tags with matplotlib, pass tags parameter
                if cell_tag is not None:
                    cell_kwargs["tags"] = cell_tag
                _plot_cell_matplotlib(hp, fig=fig, ax=ax, **cell_kwargs)

    # unify color scales across cells when user didn't supply explicit vmax
    if is_datashader:
        if vmax_nodes is None:
            _unify_clim(im_nodes_dict)
        if vmax_edges is None:
            _unify_clim(im_edges_dict)

    # labels — per-cell labels take priority, then col_labels, then tags_per_cell
    cell_labels = matrix.cell_labels
    col_labels = matrix.col_labels
    row_labels = matrix.row_labels

    if cell_labels is not None:
        for (r, c), label in cell_labels.items():
            if matrix[r, c] is not None:
                axes[r, c].set_title(
                    str(label),
                    y=1.05,
                    size=label_fontsize,
                )
    elif col_labels is not None:
        for c in range(min(ncols, len(col_labels))):
            axes[0, c].set_title(
                str(col_labels[c]),
                y=1.05,
                size=label_fontsize,
            )

    if row_labels is not None:
        # auto-adjust x-offset based on rotation
        x_offset = -0.25 if abs(row_label_rotation) < 45 else -0.15
        for r in range(min(nrows, len(row_labels))):
            axes[r, 0].annotate(
                str(row_labels[r]),
                xy=(0, 0.5),
                xytext=(x_offset, 0.5),
                xycoords="axes fraction",
                textcoords="axes fraction",
                size=label_fontsize,
                ha="center",
                va="center",
                rotation=row_label_rotation,
            )

    # colorbars for datashader
    if is_datashader:
        # suppress auto colorbars when cells use distinct colormaps;
        # a single bar cannot represent multiple colormaps — callers can build
        # their own colorbars from im_edges_dict / im_nodes_dict
        if im_edges_dict:
            distinct_edge_cmaps = {im.get_cmap().name for im in im_edges_dict.values()}
            if len(distinct_edge_cmaps) > 1:
                show_edge_colorbar = False
        if im_nodes_dict:
            distinct_node_cmaps = {im.get_cmap().name for im in im_nodes_dict.values()}
            if len(distinct_node_cmaps) > 1:
                show_node_colorbar = False

        both_shown = (
            show_edge_colorbar
            and ref_im_edges is not None
            and show_node_colorbar
            and ref_im_nodes is not None
        )

        if both_shown:
            # store in locals so ty can narrow past None
            _ref_edges = ref_im_edges
            _ref_nodes = ref_im_nodes
            assert _ref_edges is not None  # narrowed by both_shown
            assert _ref_nodes is not None  # narrowed by both_shown

            # place colorbars stacked in the bottom-left, matching
            # the plot_from_partition style (title above each bar)
            fig_h = fig.get_size_inches()[1]
            bottom_margin = min(0.25, 2.0 / fig_h)
            fig.subplots_adjust(bottom=bottom_margin)

            # anchor to first subplot, ~1.5 cells wide
            cell_pos = axes[nrows - 1, 0].get_position()
            cbar_left = cell_pos.x0
            cbar_w = min(cell_pos.width * 1.5, 0.2)
            cbar_h = min(0.025, 0.15 / fig_h)

            # edge density (upper)
            y_edge = bottom_margin * 0.6
            cax_edges = fig.add_axes((cbar_left, y_edge, cbar_w, cbar_h))
            cb_edges = fig.colorbar(
                _ref_edges,
                cax=cax_edges,
                orientation="horizontal",
                extend="max",
            )
            cb_edges.ax.set_title("Edge Density", size=label_fontsize - 2)

            # node density (lower)
            y_node = bottom_margin * 0.05
            cax_nodes = fig.add_axes((cbar_left, y_node, cbar_w, cbar_h))
            cb_nodes = fig.colorbar(
                _ref_nodes,
                cax=cax_nodes,
                orientation="horizontal",
                extend="max",
            )
            cb_nodes.ax.set_title("Node Density", size=label_fontsize - 2)

        elif show_edge_colorbar and ref_im_edges is not None:
            fig.colorbar(
                ref_im_edges,
                ax=axes.ravel().tolist(),
                orientation="horizontal",
                fraction=0.03,
                pad=0.08,
                extend="max",
                label="Edge Density",
            )

        elif show_node_colorbar and ref_im_nodes is not None:
            fig.colorbar(
                ref_im_nodes,
                ax=axes.ravel().tolist(),
                orientation="horizontal",
                fraction=0.03,
                pad=0.08,
                extend="max",
                label="Node Density",
            )

        return fig, axes, im_nodes_dict, im_edges_dict

    return fig, axes


def hive_plot_matrix_viz(
    matrix: "HivePlotMatrix",
    **kwargs: object,
) -> Union[
    Tuple[plt.Figure, np.ndarray],
    Tuple[
        plt.Figure,
        np.ndarray,
        Dict[Tuple[int, int], AxesImage],
        Dict[Tuple[int, int], AxesImage],
    ],
]:
    """
    Plot a ``HivePlotMatrix`` instance.

    Dispatches to the appropriate plotting function based on the matrix type:

    - ``"from_partition"`` matrices are plotted via
      :py:func:`~hiveplotlib.viz.hiveplot_matrix.plot_from_partition`.
    - All other matrix types (``"from_variable_sweep"``, ``"from_tags"``, ``"generic"``)
      are plotted via :py:func:`~hiveplotlib.viz.hiveplot_matrix.plot_non_partition`.

    :param matrix: ``HivePlotMatrix`` instance.
    :param kwargs: keyword arguments forwarded to the plotting function.
    :return: ``(fig, axes)`` for matplotlib,
        ``(fig, axes, im_nodes_dict, im_edges_dict)`` for datashader.
    """
    if matrix._matrix_type == "from_partition":
        return plot_from_partition(matrix, **kwargs)  # ty:ignore[invalid-argument-type]
    return plot_non_partition(matrix, **kwargs)  # ty:ignore[invalid-argument-type]
