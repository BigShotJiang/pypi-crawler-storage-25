# utils.py

"""
Utility functions for hive plot curvature and coordinates.
"""

from typing import List, Tuple, Union, overload

import numpy as np

try:  # optional dependency
    from numba import njit, prange

    _NUMBA_AVAILABLE = True
except Exception:  # pragma: no cover - numba is optional
    _NUMBA_AVAILABLE = False
    prange = range  # type: ignore


def cartesian2polar(
    x: Union[np.ndarray, float], y: Union[np.ndarray, float]
) -> Tuple[Union[np.ndarray, float], Union[np.ndarray, float]]:
    """
    Convert cartesian coordinates e.g. (x, y) to polar coordinates.

    (Polar coordinates e.g. (rho, phi), where `rho` is distance from origin, and `phi` is counterclockwise angle off of
    x-axis in degrees.)

    :param x: Cartesian x coordinates.
    :param y: Cartesian y coordinates.
    :return: (rho, phi) polar coordinates.
    """
    rho = np.sqrt(x**2 + y**2)
    phi = np.degrees(np.arctan2(y, x))
    return rho, phi


@overload
def polar2cartesian(rho: float, phi: float) -> tuple[float, float]: ...


@overload
def polar2cartesian(rho: np.ndarray, phi: float) -> tuple[np.ndarray, np.ndarray]: ...


@overload
def polar2cartesian(rho: float, phi: np.ndarray) -> tuple[np.ndarray, np.ndarray]: ...


@overload
def polar2cartesian(
    rho: np.ndarray, phi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]: ...


def polar2cartesian(
    rho: Union[np.ndarray, float], phi: Union[np.ndarray, float]
) -> Tuple[Union[np.ndarray, float], Union[np.ndarray, float]]:
    """
    Convert polar coordinates to cartesian coordinates e.g. (x, y).

    (Polar coordinates e.g. (rho, phi), where `rho` is distance from origin, and `phi` is counterclockwise angle off of
    x-axis in degrees.)

    :param rho: distance from origin.
    :param phi: counterclockwise angle off of x-axis in degrees (not radians).
    :return: (x, y) cartesian coordinates.
    """
    x = rho * np.cos(np.radians(phi))
    y = rho * np.sin(np.radians(phi))
    return x, y


def bezier(
    start: float, end: float, control: float, num_steps: int = 100
) -> np.ndarray:
    """
    Calculate 1-dimensional Bézier curve values between ``start`` and ``end`` with curve based on ``control``.

    Note, this function is hardcoded for exactly 1 control point.

    :param start: starting point.
    :param end: ending point.
    :param control: "pull" point.
    :param num_steps: number of points on Bézier curve.
    :return: ``(num_steps, )`` sized ``np.ndarray`` of 1-dimensional discretized Bézier curve output.
    """
    steps = np.linspace(0, 1, num_steps)
    return (1 - steps) ** 2 * start + 2 * (1 - steps) * steps * control + steps**2 * end


def bezier_all(
    start_arr: Union[List[float], np.ndarray],
    end_arr: Union[List[float], np.ndarray],
    control_arr: Union[List[float], np.ndarray],
    num_steps: int = 100,
) -> np.ndarray:
    """
    Calculate Bézier curve between multiple start and end values.

    Note, this function is hardcoded for exactly 1 control point per curve.

    :param start_arr: starting point of each curve.
    :param end_arr: corresponding ending point of each curve.
    :param control_arr: corresponding "pull" points for each curve.
    :param num_steps: number of points on each Bézier curve.
    :return: ``(start_arr * num_steps, )`` sized ``np.ndarray`` of 1-dimensional discretized Bézier curve output.
        Note, every ``num_steps`` chunk of the output corresponds to a different Bézier curve.
    """
    assert (
        np.array(start_arr).size == np.array(end_arr).size == np.array(control_arr).size
    ), "params `start_arr`, `end_arr`, and `control_arr` must be the same size"

    # each curve will be represented by the partitioning of the result by every `num_steps` index vals
    steps = np.tile(np.linspace(0, 1, num_steps), np.array(start_arr).size)

    # repeat each start, stop, and control value to multiply point-wise in one line
    start = np.repeat(start_arr, num_steps)
    end = np.repeat(end_arr, num_steps)
    control = np.repeat(control_arr, num_steps)

    return (1 - steps) ** 2 * start + 2 * (1 - steps) * steps * control + steps**2 * end


def _bezier_xy_with_nans_numpy(
    start_x: np.ndarray,
    start_y: np.ndarray,
    end_x: np.ndarray,
    end_y: np.ndarray,
    control_x: np.ndarray,
    control_y: np.ndarray,
    num_steps: int,
    dtype: np.dtype,
) -> np.ndarray:
    n = start_x.shape[0]
    steps = np.linspace(0.0, 1.0, num_steps, dtype=dtype)
    steps_rep = np.tile(steps, n)

    sx = np.repeat(start_x, num_steps)
    ex = np.repeat(end_x, num_steps)
    cx = np.repeat(control_x, num_steps)
    x_vals = (
        (1 - steps_rep) ** 2 * sx
        + 2 * (1 - steps_rep) * steps_rep * cx
        + steps_rep**2 * ex
    )

    sy = np.repeat(start_y, num_steps)
    ey = np.repeat(end_y, num_steps)
    cy = np.repeat(control_y, num_steps)
    y_vals = (
        (1 - steps_rep) ** 2 * sy
        + 2 * (1 - steps_rep) * steps_rep * cy
        + steps_rep**2 * ey
    )

    out = np.empty((n * (num_steps + 1), 2), dtype=dtype)
    # fill per-curve blocks and insert trailing NaN row per curve
    for i in range(n):
        base = i * (num_steps + 1)
        s0 = i * num_steps
        s1 = s0 + num_steps
        out[base : base + num_steps, 0] = x_vals[s0:s1]
        out[base : base + num_steps, 1] = y_vals[s0:s1]
        out[base + num_steps, 0] = np.nan
        out[base + num_steps, 1] = np.nan
    return out


if _NUMBA_AVAILABLE:  # pragma: no cover - @njit bodies are invisible to Python coverage

    @njit(cache=True, fastmath=True)
    def _bezier_xy_with_nans_numba_serial(
        start_x: np.ndarray,
        start_y: np.ndarray,
        end_x: np.ndarray,
        end_y: np.ndarray,
        control_x: np.ndarray,
        control_y: np.ndarray,
        num_steps: int,
    ) -> np.ndarray:
        # fastmath=True permits FP reordering for speed; safe here because
        # explicit NaN writes happen outside the Bézier arithmetic loop.
        n = start_x.shape[0]
        total = n * (num_steps + 1)
        # allocate output based on input dtype (supports float32/float64)
        out = np.empty((total, 2), dtype=start_x.dtype)
        for i in range(n):
            base = i * (num_steps + 1)
            for k in range(num_steps):
                t = k / (num_steps - 1) if num_steps > 1 else 0.0
                omt = 1.0 - t
                bx = (
                    omt * omt * start_x[i]
                    + 2.0 * omt * t * control_x[i]
                    + t * t * end_x[i]
                )
                by = (
                    omt * omt * start_y[i]
                    + 2.0 * omt * t * control_y[i]
                    + t * t * end_y[i]
                )
                out[base + k, 0] = bx
                out[base + k, 1] = by
            out[base + num_steps, 0] = np.nan
            out[base + num_steps, 1] = np.nan
        return out

    @njit(parallel=True, cache=True, fastmath=True)
    def _bezier_xy_with_nans_numba(
        start_x: np.ndarray,
        start_y: np.ndarray,
        end_x: np.ndarray,
        end_y: np.ndarray,
        control_x: np.ndarray,
        control_y: np.ndarray,
        num_steps: int,
    ) -> np.ndarray:
        # fastmath=True permits FP reordering for speed; safe here because
        # explicit NaN writes happen outside the Bézier arithmetic loop.
        n = start_x.shape[0]
        total = n * (num_steps + 1)
        # allocate output based on input dtype (supports float32/float64)
        out = np.empty((total, 2), dtype=start_x.dtype)
        for i in prange(n):  # type: ignore[misc]
            base = i * (num_steps + 1)
            for k in range(num_steps):
                t = k / (num_steps - 1) if num_steps > 1 else 0.0
                omt = 1.0 - t
                bx = (
                    omt * omt * start_x[i]
                    + 2.0 * omt * t * control_x[i]
                    + t * t * end_x[i]
                )
                by = (
                    omt * omt * start_y[i]
                    + 2.0 * omt * t * control_y[i]
                    + t * t * end_y[i]
                )
                out[base + k, 0] = bx
                out[base + k, 1] = by
            out[base + num_steps, 0] = np.nan
            out[base + num_steps, 1] = np.nan
        return out
else:
    _bezier_xy_with_nans_numba = None
    _bezier_xy_with_nans_numba_serial = None


def bezier_xy_with_nans(
    start_arr: Union[List[float], np.ndarray],
    end_arr: Union[List[float], np.ndarray],
    control_xy: Tuple[Union[List[float], np.ndarray], Union[List[float], np.ndarray]],
    num_steps: int = 100,
    numba_mode: Union[str, None] = None,
    dtype: Union[np.dtype, type, str] = np.float64,
) -> np.ndarray:
    """
    Vectorized 2D quadratic Bézier sampling for multiple curves with NaN separators.

    Input arrays represent per-curve start/end points (shape (n, 2)) and control points (x,y).
    Returns an array of shape (n * (num_steps + 1), 2), where each curve contributes
    ``num_steps`` rows followed by a NaN separator row.

    :param numba_mode: selects the computation backend.

        - ``"parallel"``: use numba-parallel implementation (if available).
        - ``"serial"``: use numba single-threaded implementation (if available).
        - ``"off"`` or ``None`` (default): use pure NumPy implementation.
    :param dtype: output array dtype. Default ``numpy.float64``.
    """
    sa = np.asarray(start_arr)
    ea = np.asarray(end_arr)
    cx, cy = control_xy
    cx = np.asarray(cx)
    cy = np.asarray(cy)
    if sa.ndim != 2 or sa.shape[1] != 2:
        msg = "start_arr must be of shape (n, 2)"
        raise ValueError(msg)
    if ea.ndim != 2 or ea.shape[1] != 2:
        msg = "end_arr must be of shape (n, 2)"
        raise ValueError(msg)
    if cx.shape[0] != sa.shape[0] or cy.shape[0] != sa.shape[0]:
        msg = "control arrays must match number of curves in start/end arrays"
        raise ValueError(msg)

    # Normalize dtype
    dtype_np = np.dtype(dtype)

    # Enforce numeric dtype and contiguous layout
    sa = np.ascontiguousarray(sa, dtype=dtype_np)
    ea = np.ascontiguousarray(ea, dtype=dtype_np)
    cx = np.ascontiguousarray(cx, dtype=dtype_np)
    cy = np.ascontiguousarray(cy, dtype=dtype_np)

    # Determine mode (None defaults to pure NumPy)
    mode = numba_mode if numba_mode is not None else "off"
    if (
        mode == "parallel"
        and _NUMBA_AVAILABLE
        and _bezier_xy_with_nans_numba is not None
    ):
        return _bezier_xy_with_nans_numba(
            sa[:, 0], sa[:, 1], ea[:, 0], ea[:, 1], cx, cy, num_steps
        )
    if (
        mode == "serial"
        and _NUMBA_AVAILABLE
        and _bezier_xy_with_nans_numba_serial is not None
    ):
        return _bezier_xy_with_nans_numba_serial(
            sa[:, 0], sa[:, 1], ea[:, 0], ea[:, 1], cx, cy, num_steps
        )
    return _bezier_xy_with_nans_numpy(
        sa[:, 0], sa[:, 1], ea[:, 0], ea[:, 1], cx, cy, num_steps, dtype_np
    )
