# converters.py

"""
Converters from various data structures to ``hiveplotlib``-ready structures.
"""

import pandas as pd

from hiveplotlib import Edges, NodeCollection

try:
    import networkx as nx
except ImportError as ie:  # pragma: no cover
    msg = "`networkx` dependencies not installed, but can be installed by running `pip install hiveplotlib[networkx]`"
    raise ImportError(msg) from ie


def networkx_to_nodes_edges(
    graph: nx.Graph,
    unique_id_name: str = "unique_id",
    check_uniqueness: bool = True,
) -> tuple[NodeCollection, Edges]:
    """
    Take a ``networkx`` graph and return ``hiveplotlib``-friendly data structures.

    Specifically, returns a ``NodeCollection`` instance of node data and an ``Edges`` instance of
    edge data. These outputs can be fed directly into :py:func:`~hiveplotlib.HivePlot`.

    :param graph: ``networkx`` graph.
    :param unique_id_name: name to use for unique IDs.
    :param check_uniqueness: whether or not to check that provided ``Node`` instances have unique IDs.
    :return: ``list`` of ``Node`` instances, ``(n, 2)`` ``np.ndarray`` of edges.
    """
    node_data = []
    for node, attributes in graph.nodes(data=True):
        node_data.append({unique_id_name: node, **attributes})

    node_df = pd.DataFrame(node_data)
    edge_df = nx.to_pandas_edgelist(graph, source="from", target="to")
    return NodeCollection(
        data=node_df,
        unique_id_column=unique_id_name,
        check_uniqueness=check_uniqueness,
    ), Edges(data=edge_df)
