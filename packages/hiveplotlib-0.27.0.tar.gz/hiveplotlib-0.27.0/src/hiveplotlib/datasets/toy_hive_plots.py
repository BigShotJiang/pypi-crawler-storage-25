"""
Tools for generating toy hive plots.
"""

from typing import Dict, Hashable, List, Literal, Optional, Tuple, Union

import numpy as np
import pandas as pd

from hiveplotlib import (
    BaseHivePlot,
    Node,
    NodeCollection,
    hive_plot_n_axes,
)
from hiveplotlib.datasets.international_trade import international_trade_data
from hiveplotlib.edges import Edges
from hiveplotlib.hiveplot import HivePlot
from hiveplotlib.node import dataframe_to_node_list


def example_base_hive_plot(
    num_nodes: int = 15,
    num_edges: int = 30,
    seed: int = 0,
    **hive_plot_n_axes_kwargs,
) -> BaseHivePlot:
    """
    Generate example hive plot with ``"Low"``, ``"Medium"``, and ``"High"`` axes (plus repeat axes).

    Nodes and edges will be generated and placed randomly.

    :param num_nodes: number of nodes to generate.
    :param num_edges: number of edges to generate.
    :param seed: random seed to use when generating nodes and edges.
    :param hive_plot_n_axes_kwargs: additional keyword arguments for the underlying
        :py:func:`hiveplotlib.hive_plot_n_axes()` call.
    :return: resulting ``BaseHivePlot`` instance.
    """
    color_dict = {
        "Low": {"Low_repeat": "#006BA4", "High_repeat": "#FF800E"},
        "High": {"Medium_repeat": "#ABABAB", "High_repeat": "#595959"},
        "Medium": {"Medium_repeat": "#5F9ED1", "Low_repeat": "#C85200"},
        "Low_repeat": {"Low": "#006BA4", "Medium": "#C85200"},
        "Medium_repeat": {"Medium": "#5F9ED1", "High": "#ABABAB"},
        "High_repeat": {"High": "#595959", "Low": "#FF800E"},
    }

    rng = np.random.default_rng(seed)
    data = pd.DataFrame(
        np.c_[
            rng.uniform(low=0, high=10, size=num_nodes),
            rng.uniform(low=10, high=20, size=num_nodes),
            rng.uniform(low=20, high=30, size=num_nodes),
        ],
        columns=np.array(["low", "med", "high"]),
    )

    # make indices a column
    data = data.reset_index(names="unique_id")

    edges = rng.choice(data["unique_id"].to_numpy(), size=num_edges * 2).reshape(-1, 2)

    hp = hive_plot_n_axes(
        nodes=NodeCollection(data=data, unique_id_column="unique_id"),
        edges=edges,
        axes_assignments=[
            np.arange(num_nodes)[: num_nodes // 3],
            np.arange(num_nodes)[num_nodes // 3 : 2 * num_nodes // 3],
            np.arange(num_nodes)[2 * num_nodes // 3 :],
        ],
        sorting_variables=["low", "med", "high"],
        repeat_axes=[True, True, True],
        axes_names=["Low", "Medium", "High"],
        orient_angle=-30,
        **hive_plot_n_axes_kwargs,
    )

    # set colors according to above-defined color dictionary
    #  (so we can replicate more easily in other viz later)
    for e1 in color_dict:
        for e2 in color_dict[e1]:
            hp.add_edge_kwargs(axis_id_1=e1, axis_id_2=e2, color=color_dict[e1][e2])

    return hp


def example_node_data(num_nodes: int = 100, seed: int = 0) -> pd.DataFrame:
    """
    Generate example node dataframe.

    Each node will have a ``"low"``, ``"med"``, and ``"high"`` value, where these values are randomly generated, and as
    the names suggest, for the resulting values of each node, ``"low"`` < ``"med"`` < ``"high"``.

    Unique ID column will be given the name ``"unique_id"``.

    :param num_nodes: how many nodes to randomly generate. Node unique IDs will be the integers 0, 1, ... ,
        ``num_nodes - 1``.
    :param seed: random seed to use when randomly generating node data.
    :return: dataframe of node data.
    """
    rng = np.random.default_rng(seed)
    # example data
    data = pd.DataFrame(
        np.c_[
            rng.uniform(low=0, high=9.99, size=num_nodes),
            rng.uniform(low=10, high=19.99, size=num_nodes),
            rng.uniform(low=20, high=29.99, size=num_nodes),
        ],
        columns=np.array(["low", "med", "high"]),
    )
    # make indices a column
    return data.reset_index(names="unique_id")


def example_node_collection(
    num_nodes: int = 100,
    seed: int = 0,
    unique_id_column: str = "unique_id",
) -> NodeCollection:
    """
    Generate example ``NodeCollection``.

    Each node will have a ``"low"``, ``"med"``, and ``"high"`` value, where these values are randomly generated, and as
    the names suggest, for the resulting values of each node, ``"low"`` < ``"med"`` < ``"high"``.

    Unique ID column will be given the name ``"unique_id"``.

    :param num_nodes: how many nodes to randomly generate. Node unique IDs will be the integers 0, 1, ... ,
        ``num_nodes - 1``.
    :param seed: random seed to use when randomly generating node data.
    :param unique_id_column: name to assign to the column in the resulting ``NodeCollection.data`` attribute that
        corresponds to the unique IDs.
    :return: ``NodeCollection`` of node data.
    """
    data = example_node_data(num_nodes=num_nodes, seed=seed)
    data = data.rename(columns={"unique_id": unique_id_column})
    return NodeCollection(
        data=data,
        unique_id_column=unique_id_column,
    )


def example_edge_data(
    nodes: NodeCollection,
    num_edges: int = 100,
    from_column_name: Hashable = "from",
    to_column_name: Hashable = "to",
    seed: int = 0,
) -> pd.DataFrame:
    """
    Generate example edge data from a provided ``NodeCollection``.

    :param nodes: nodes from which to generate example edges.
    :param num_edges: how many example edges to randomly generate.
    :param from_column_name: name to assign to the edge origin column, whose values correspond to node IDs where a given
        edge starts.
    :param to_column_name: name to assign to the edge destination column, whose values correspond to node IDs where a
        given edge ends.
    :param seed: random seed to use when randomly generating edge data.
    :return: random edge data as (n, 2) DataFrame of [from, to] edges.
    """
    node_ids = nodes.data[nodes.unique_id_column].to_numpy()
    rng = np.random.default_rng(seed)
    edge_array = rng.choice(node_ids, size=num_edges * 2).reshape(-1, 2)
    return pd.DataFrame(
        edge_array, columns=np.array([from_column_name, to_column_name])
    )


def example_edges(
    nodes: NodeCollection,
    num_edges: int = 100,
    from_column_name: Hashable = "from",
    to_column_name: Hashable = "to",
    seed: int = 0,
) -> Edges:
    """
    Generate example edges from a provided ``NodeCollection``.

    :param nodes: nodes from which to generate example edges.
    :param num_edges: how many example edges to randomly generate.
    :param from_column_name: name to assign to the edge origin column, whose values correspond to node IDs where a given
        edge starts.
    :param to_column_name: name to assign to the edge destination column, whose values correspond to node IDs where a
        given edge ends.
    :param seed: random seed to use when randomly generating edge data.
    :return: random edge data.
    """
    edge_df = example_edge_data(
        nodes=nodes,
        num_edges=num_edges,
        from_column_name=from_column_name,
        to_column_name=to_column_name,
        seed=seed,
    )

    return Edges(
        data=edge_df,
        from_column_name=from_column_name,
        to_column_name=to_column_name,
    )


def example_trade_nodes_and_edges() -> Tuple[NodeCollection, Edges]:
    """
    Load the international trade nodes and edges.

    Used in the
    :doc:`Hive Plots with More Than 3 Groups </notebooks/hive_plots_more_than_three_groups>`
    notebook.

    Uses :py:func:`hiveplotlib.datasets.international_trade.international_trade_data` to load 2019 trade data for HS92
    trade group 8112 ("beryllium, chromium, germanium, vanadium, gallium, hafnium, indium, niobium
    (columbium), rhenium and thallium, articles thereof, and waste or scrap") from the
    `Harvard Growth Lab <https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi%3A10.7910%2FDVN%2FT4CHWJ>`_.

    **Node columns** (152 nodes):

    - ``"country"``: ISO 3166-1 alpha-3 country code (unique ID).
    - ``"continent"``: continent of the country (Africa, Asia, Europe, North America, Oceania, or South America).
    - ``"export_value"``: total USD exported by that country within trade group 8112 in 2019.
      Countries with no exports are assigned 0.

    **Edge columns** (1158 edges):

    Each edge represents non-zero trade from an origin country to a destination country.

    - ``"origin_country"``: ISO 3166-1 alpha-3 code of the exporting country (from column).
    - ``"destination_country"``: ISO 3166-1 alpha-3 code of the importing country (to column).
    - ``"export_value"``: USD exported from the origin to the destination.
    - ``"origin_continent"``: continent of the origin country.
    - ``"destination_continent"``: continent of the destination country.

    :return: tuple of ``(NodeCollection, Edges)`` representing the trade network.
    """
    data, _ = international_trade_data(year=2019, hs92_code=8112)

    export_totals_per_country = (
        data.loc[:, ["origin_country", "export_value"]]
        .groupby("origin_country")
        .sum()
        .reset_index()
    )

    node_data = pd.concat(
        [
            data.loc[:, ["origin_country", "origin_continent"]].rename(
                columns={
                    "origin_country": "country",
                    "origin_continent": "continent",
                }
            ),
            data.loc[:, ["destination_country", "destination_continent"]].rename(
                columns={
                    "destination_country": "country",
                    "destination_continent": "continent",
                }
            ),
        ]
    ).drop_duplicates()

    node_data = node_data.merge(
        export_totals_per_country,
        how="left",
        left_on="country",
        right_on="origin_country",
    ).drop(columns=["origin_country"])

    # fill in countries with no exports as 0, not NaN
    node_data.export_value = node_data.export_value.fillna(0)

    nodes = NodeCollection(node_data, unique_id_column="country")

    edges = Edges(
        data,
        from_column_name="origin_country",
        to_column_name="destination_country",
    )

    return nodes, edges


def example_nodes_and_edges(
    num_nodes: int = 100,
    num_edges: int = 200,
    num_axes: int = 3,
    seed: int = 0,
) -> Tuple[List[Node], List[List[Hashable]], np.ndarray]:
    """
    Generate example nodes, node splits (one list of nodes per intended axis), and edges.

    Each node will have a ``"low"``, ``"med"``, and ``"high"`` value, where these values are randomly generated, and as
    the names suggest, for the resulting values of each node, ``"low"`` < ``"med"`` < ``"high"``.

    :param num_nodes: how many nodes to randomly generate. Node unique IDs will be the integers 0, 1, ... ,
        ``num_nodes - 1``.
    :param num_edges: how many edges to randomly generate.
    :param num_axes: how many axes into which to partition the randomly generated nodes.
    :param seed: random seed to use when randomly generating node and edge data.
    :return: list of generated ``Node`` instances, a list of ``num_axes`` lists that evenly split the node IDs to be
        allocated to their own axes, and a ``(num_edges, 2)`` shaped array of random edges between nodes.
    """
    data = example_node_data(num_nodes=num_nodes, seed=seed)
    node_list = dataframe_to_node_list(data, unique_id_column="unique_id")
    node_ids = data["unique_id"].to_numpy()

    # split node allocation equally among planned axes
    node_ids_per_axis = np.split(node_ids, num_axes)
    # coax to list of lists
    node_ids_per_axis = [i.tolist() for i in node_ids_per_axis]

    rng = np.random.default_rng(seed)
    edges = rng.choice(node_ids, size=num_edges * 2).reshape(-1, 2)

    return node_list, node_ids_per_axis, edges


def example_hive_plot(
    num_nodes: int = 100,
    num_edges: int = 100,
    partition_data_column: Literal["low", "med", "high"] = "low",
    labels: Optional[List[Hashable]] = ["A", "B", "C"],  # noqa: B006
    cutoffs: Union[List[Union[int, float]], int] = 3,
    partition_variable_name: Optional[Hashable] = None,
    sorting_variables: Union[Hashable, Dict[Hashable, Hashable]] = "low",
    seed: int = 0,
    node_unique_id_column: str = "unique_id",
    **hive_plot_kwargs,
) -> HivePlot:
    """
    Generate example ``HivePlot`` instance.

    Each node will have a ``"low"``, ``"med"``, and ``"high"`` value, where these values are randomly generated, and as
    the names suggest, for the resulting values of each node, ``"low"`` < ``"med"`` < ``"high"``.

    Each edge will also have a ``"low"``, ``"med"``, and ``"high"`` value, with each value being the average "low" /
    "med" / "high" level of the two nodes composing the edge.

    .. note::
        The generated ``num_edges`` edges will be randomly generated between *all possible axes, including repeat axes*.
        Thus, calling this function without requesting *all* repeat axes (i.e. ``repeat_axes=True``) will result in less
        than ``num_edges`` edges visualized in the final hive plot. (All generated edges will be stored in the resulting
        ``hive_plot.edges``, even though some will not be plotted if excluding repeat axes in the plot.)

    :param num_nodes: how many nodes to randomly generate. Node unique IDs will be the integers 0, 1, ... ,
        ``num_nodes - 1``.
    :param num_edges: how many example edges to randomly generate.
    :param partition_data_column: which column of data in the underlying ``data`` attribute to use to partition the
        node data. Node data generated via :py:func:`hiveplotlib.datasets.toy_hive_plots.example_node_data()`.
    :param labels: labels assigned to each bin. Only referenced when ``cutoffs`` is not ``None``. ``None``
        labels each bin as a string based on its range of values. Note, when ``cutoffs`` is a list, ``len(labels)``
        must be 1 greater than ``len(cutoffs)``. When ``cutoffs`` is an ``int``, ``len(labels)`` must be equal to
        ``cutoffs``.
    :param cutoffs: cutoffs to use in binning nodes according to data under ``partition_data_column``. Default ``None``
        will bin nodes by unique values of ``partition_data_column``. When provided as a ``list``, the specified cutoffs
        will bin according to (-inf, ``cutoffs[0]``], (``cutoffs[0]``, ``cutoffs[1]``], ... , (``cutoffs[-1]``, inf).
        When provided as an ``int``, the exact numerical break points will be determined to create ``cutoffs``
        equally-sized quantiles.
    :param partition_variable_name: name of the resulting partition variable to add to the ``nodes.data`` attribute of
        the resulting ``HivePlot`` instance. Default ``None`` will name the partition column as ``"partition_0"``.
    :param sorting_variable: which node variable to use to sort / place the nodes on each axis. Providing a single
        value uses the same variable for each axis. Alternatively, providing a dictionary of keys as the unique values
        from ``partition_variable_name`` column data in the ``nodes.data`` attribute and values being the corresponding
        sorting variable to use for that axis.
    :param seed: random seed to use when randomly generating node and edge data.
    :param node_unique_id_column: name to assign to the column in the ``nodes.data`` attribute that corresponds to the
        unique IDs.
    :param hive_plot_kwargs: additional keyword arguments when creating the returned
        :py:class:`hiveplotlib.HivePlot()` instance.
    :return: randomly-generated ``HivePlot`` instance.
    """
    node_collection = example_node_collection(
        num_nodes=num_nodes,
        seed=seed,
        unique_id_column=node_unique_id_column,
    )
    edges = example_edges(
        nodes=node_collection,
        num_edges=num_edges,
        seed=seed,
    )

    temp_df = (
        edges._data[0]
        .merge(
            node_collection.data,
            left_on="from",
            right_on=node_unique_id_column,
        )
        .merge(
            node_collection.data,
            left_on="to",
            right_on=node_unique_id_column,
            suffixes=(None, "_to"),
        )
    )
    for col in ["low", "med", "high"]:
        edges._data[0][col] = (temp_df[col] + temp_df[f"{col}_to"]) / 2

    partition_variable = node_collection.create_partition_variable(
        data_column=partition_data_column,
        cutoffs=cutoffs,
        labels=labels,
        partition_variable_name=partition_variable_name,
    )
    return HivePlot(
        nodes=node_collection,
        edges=edges,
        partition_variable=partition_variable,
        sorting_variables=sorting_variables,
        **hive_plot_kwargs,
    )


def example_hpm_nodes_and_edges(
    num_groups: int = 3,
    nodes_per_group: int = 10,
    edge_tag_counts: Optional[Dict[str, int]] = None,
    edge_structure: Optional[Dict[str, str]] = None,
    seed: int = 42,
) -> Tuple["NodeCollection", "Edges"]:
    """
    Generate a shared toy dataset that works well with ``HivePlotMatrix`` examples.

    Returns a ``NodeCollection`` of ``num_groups * nodes_per_group`` nodes across
    ``num_groups`` groups (A, B, C, ...) with structured numeric columns, and a
    multi-tag ``Edges`` object.

    **Node columns**:

    - ``"unique_id"``: integers 0 to (num_groups * nodes_per_group - 1).
    - ``"group"``: group label, assigned in consecutive blocks. With ``num_groups=3``,
      nodes 0-9 are ``"A"``, 10-19 are ``"B"``, 20-29 are ``"C"``.
    - ``"value1"``: *correlated with group* - each group draws from a distinct sub-interval
      of [0, 10] in ascending order. Sorting by ``value1`` places groups at distinct,
      separated positions along each axis if setting axes ``vmin`` and ``vmax`` values to the same fixed range.
    - ``"value2"``: *uncorrelated noise* - all nodes draw from Uniform(0, 10). Sorting
      by ``value2`` produces little visible group separation.
    - ``"value3"``: *inversely correlated with group* - the mirror image of ``value1``.
      The first group draws from the highest sub-interval, the last from the lowest.

    **Default edge tags** (decreasing density):

    - ``"official"``: 40 edges.
    - ``"social"``: 30 edges.
    - ``"informal"``: 20 edges.

    :param num_groups: number of groups to generate (A, B, C, ...). Default 3.
    :param nodes_per_group: number of nodes in each group. Default 10.
    :param edge_tag_counts: dictionary mapping edge tag names to edge counts. Defaults to
        ``{"official": 40, "social": 30, "informal": 20}``.
    :param edge_structure: dictionary mapping edge tag names to structure types.
        Supported types:

        - ``"random"``: edges connect any two nodes uniformly at random (default).
        - ``"intragroup"``: edges connect nodes within the same group only.
        - ``"intergroup"``: edges connect nodes in different groups only.

        Tags not listed in this dictionary default to ``"random"``.
    :param seed: base random seed. Seeds ``seed``, ``seed+1``, ... are used for
        successive edge tags respectively.
    :return: tuple of ``(NodeCollection, Edges)``.
    """
    _valid_structures = {"random", "intragroup", "intergroup"}
    if edge_tag_counts is None:
        edge_tag_counts = {"official": 40, "social": 30, "informal": 20}
    if edge_structure is None:
        edge_structure = {}
    for tag, structure in edge_structure.items():
        if structure not in _valid_structures:
            msg = (
                f"edge_structure[{tag!r}] = {structure!r} is not valid. "
                f"Must be one of {_valid_structures}."
            )
            raise ValueError(msg)
    num_nodes = num_groups * nodes_per_group
    rng = np.random.default_rng(seed)

    # Deterministic block group assignment
    group_labels = [chr(ord("A") + i) for i in range(num_groups)]
    groups: list = []
    for label in group_labels:
        groups.extend([label] * nodes_per_group)

    # Divide [0, 10] into num_groups equal sub-intervals
    breakpoints = np.linspace(0, 10, num_groups + 1)

    # value1: correlated - group i draws from [breakpoints[i], breakpoints[i+1]]
    value1_parts = []
    for i in range(num_groups):
        lo, hi = breakpoints[i], breakpoints[i + 1]
        value1_parts.append(rng.uniform(lo, hi, size=nodes_per_group))
    value1 = np.concatenate(value1_parts)

    value2 = rng.uniform(0, 10, size=num_nodes)

    # value3: inversely correlated - group i draws from the reversed sub-interval
    value3_parts = []
    for i in range(num_groups):
        j = num_groups - 1 - i
        lo, hi = breakpoints[j], breakpoints[j + 1]
        value3_parts.append(rng.uniform(lo, hi, size=nodes_per_group))
    value3 = np.concatenate(value3_parts)

    data = pd.DataFrame(
        {
            "unique_id": np.arange(num_nodes),
            "group": groups,
            "value1": value1,
            "value2": value2,
            "value3": value3,
        }
    )
    nodes = NodeCollection(data=data, unique_id_column="unique_id")
    node_ids = data["unique_id"].to_numpy()
    groups_array = np.array(groups)

    def _make_edges(n_edges: int, edge_seed: int, structure: str) -> pd.DataFrame:
        edge_rng = np.random.default_rng(edge_seed)
        if structure == "random":
            return pd.DataFrame(
                edge_rng.choice(node_ids, size=n_edges * 2).reshape(-1, 2),
                columns=np.array(["from", "to"]),
            )

        from_nodes = edge_rng.choice(node_ids, size=n_edges)
        to_nodes = np.empty(n_edges, dtype=node_ids.dtype)
        for j in range(n_edges):
            src_group = groups_array[from_nodes[j]]
            if structure == "intragroup":
                candidates = node_ids[groups_array == src_group]
            else:  # intergroup
                candidates = node_ids[groups_array != src_group]
            to_nodes[j] = edge_rng.choice(candidates)
        return pd.DataFrame(
            {"from": from_nodes, "to": to_nodes},
        )

    edges = Edges(
        data={
            tag: _make_edges(count, seed + i, edge_structure.get(tag, "random"))
            for i, (tag, count) in enumerate(edge_tag_counts.items())
        }
    )
    return nodes, edges


def example_minimal_hive_plot() -> HivePlot:
    """
    Generate a minimal ``HivePlot`` instance with edge color styling.

    Uses :py:func:`example_hive_plot` with 6 nodes and 6 edges (seed 42) and adds
    a uniform edge color of ``"#006BA4"`` to all axis pairs that have edges.

    :return: ``HivePlot`` instance.
    """
    return example_hive_plot(
        num_nodes=6,
        num_edges=6,
        seed=42,
        all_edge_kwargs={"color": "#006BA4"},
    )


def example_multi_tag_hive_plot() -> HivePlot:
    """
    Generate a ``HivePlot`` instance with two edge tags and ``repeat_axes=True``.

    Creates 12 nodes (seed 10) with two independent sets of 15 edges (seeds 10 and 20)
    stored under tags ``"tag_red"`` and ``"tag_blue"``. Edge colors are ``"#FF0000"``
    and ``"#0000FF"`` respectively.

    :return: ``HivePlot`` instance with two edge tags.
    """
    nodes = example_node_collection(num_nodes=12, seed=10)
    edge_data_1 = example_edge_data(nodes=nodes, num_edges=15, seed=10)
    edge_data_2 = example_edge_data(nodes=nodes, num_edges=15, seed=20)
    multi_tag_edges = Edges(data={"tag_red": edge_data_1, "tag_blue": edge_data_2})
    partition_variable = nodes.create_partition_variable(
        data_column="low", labels=["A", "B", "C"]
    )
    hp = HivePlot(
        nodes=nodes,
        edges=multi_tag_edges,
        partition_variable=partition_variable,
        sorting_variables="low",
        repeat_axes=True,
    )
    hp.edges.update_edge_viz_kwargs(tag="tag_red", color="#FF0000")
    hp.edges.update_edge_viz_kwargs(tag="tag_blue", color="#0000FF")
    return hp


def example_full_kwargs_hive_plot() -> HivePlot:
    """
    Generate a ``HivePlot`` instance with data-dependent edge kwargs, colormaps, and node styling.

    Uses :py:func:`example_hive_plot` with 9 nodes, 10 edges (seed 99), and
    ``repeat_axes=True``. Scaled edge data columns are created for alpha and linewidth,
    and all edge visualization kwargs are set via
    :py:meth:`~hiveplotlib.HivePlot.update_edge_plotting_keyword_arguments` using column
    name references:

    - **color**: the ``"low"`` edge data column mapped through a ``"cividis"`` colormap.
    - **alpha**: the ``"alpha_scaled"`` column (``low / 10``, yielding values in ~0.3-1.0).
    - **linewidth**: the ``"lw_scaled"`` column (``low / 3``, yielding values in ~1.0-3.3).

    Node styling is applied via ``update_node_viz_kwargs`` with a ``"viridis"`` colormap mapped to the ``"low"``
    data column.

    :return: ``HivePlot`` instance with node and edge kwargs.
    """
    hp = example_hive_plot(num_nodes=9, num_edges=10, seed=99, repeat_axes=True)
    # create scaled edge data columns for alpha (0-1 range) and linewidth
    hp.edges.data["alpha_scaled"] = hp.edges.data["low"] / 10
    hp.edges.data["lw_scaled"] = hp.edges.data["low"] / 3
    # data-dependent edge kwargs: color, alpha, and linewidth all from edge data columns
    hp.update_edge_plotting_keyword_arguments(
        array="low",
        cmap="cividis",
        clim=(0, 10),
        alpha="alpha_scaled",
        linewidth="lw_scaled",
    )
    hp.update_node_viz_kwargs(
        c="low", s=30, alpha=0.8, edgecolor="black", cmap="viridis"
    )
    return hp
