# hiveplot_matrix.py

"""
Definition of ``HivePlotMatrix`` for generating and working with matrices of Hive Plots.

A ``HivePlotMatrix`` is a grid of ``HivePlot`` instances for comparative network visualization,
analogous to a scatter plot matrix but for hive plots.
"""

import math
from copy import deepcopy
from typing import (
    Callable,
    Dict,
    Hashable,
    Iterator,
    List,
    Literal,
    Optional,
    Tuple,
    Union,
    get_args,
)

import numpy as np

from hiveplotlib.edges import Edges
from hiveplotlib.exceptions.hive_plot import InvalidVizBackendError
from hiveplotlib.hiveplot import EDGE_KWARG_HIERARCHY, HivePlot
from hiveplotlib.node import NodeCollection


def hpm_supported_viz_backends():  # noqa: ANN201
    """
    Return the supported visualization back ends for ``HivePlotMatrix``.
    """
    return Literal[
        "matplotlib",
        "datashader",
    ]


HPM_SUPPORTED_VIZ_BACKENDS = hpm_supported_viz_backends()
"""
The visualization backends supported by ``HivePlotMatrix``.
"""


def hpm_matrix_types():  # noqa: ANN201
    """
    Return the supported matrix types for ``HivePlotMatrix``.
    """
    return Literal[
        "generic",
        "from_partition",
        "from_variable_sweep",
        "from_tags",
    ]


HPM_MATRIX_TYPES = hpm_matrix_types()
"""
The matrix types supported by ``HivePlotMatrix``.

- ``"generic"``: constructed directly via ``__init__``.
- ``"from_partition"``: built via :py:meth:`~HivePlotMatrix.from_partition`.
- ``"from_variable_sweep"``: built via :py:meth:`~HivePlotMatrix.from_variable_sweep`.
- ``"from_tags"``: built via :py:meth:`~HivePlotMatrix.from_tags`.
"""


def _noop(x, **kwargs):  # noqa: ANN001, ANN202, ARG001
    """No-op passthrough for when tqdm is not available or not desired."""
    return x


def _get_tqdm_or_noop(progress: bool) -> Callable:
    """
    Return a tqdm progress bar wrapper or a no-op passthrough.

    :param progress: whether to attempt to use tqdm.
    :return: tqdm.tqdm if available and ``progress`` is ``True``, otherwise a no-op passthrough.
    """
    if not progress:
        return _noop
    try:
        from tqdm.auto import tqdm

        return tqdm
    except ImportError:
        return _noop


def _wrap_1d_to_2d(
    hive_plots_1d: List[Optional[HivePlot]],
    ncols: Optional[int],
) -> List[List[Optional[HivePlot]]]:
    """
    Wrap a 1D list of HivePlots into a 2D grid with ``ncols`` columns.

    :param hive_plots_1d: flat list of HivePlot instances.
    :param ncols: number of columns per row. If ``None``, returns a single row.
    :return: 2D list of lists of HivePlot instances.
    """
    if ncols is None:
        return [hive_plots_1d]

    nrows = math.ceil(len(hive_plots_1d) / ncols)
    grid: List[List[Optional[HivePlot]]] = []
    for r in range(nrows):
        row = []
        for c in range(ncols):
            idx = r * ncols + c
            if idx < len(hive_plots_1d):
                row.append(hive_plots_1d[idx])
            else:
                row.append(None)
        grid.append(row)
    return grid


def _resolve_unify_axes(
    unify_axes: Union[bool, Dict[Literal["vmin", "vmax"], float]],
    axis_kwargs: Optional[dict],
    nodes: NodeCollection,
    sorting_variables: Union[Hashable, Dict[Hashable, Hashable]],
) -> Optional[dict]:
    """
    Pre-compute unified axis range and merge into ``axis_kwargs``.

    :param unify_axes: user-provided unify_axes parameter.
    :param axis_kwargs: user-provided axis_kwargs (may be ``None``).
    :param nodes: node data to compute global range from.
    :param sorting_variables: sorting variable(s) to compute range over.
    :return: updated ``axis_kwargs`` dict, or ``None`` if no unification needed and
        ``axis_kwargs`` was ``None``.
    """
    if unify_axes is False:
        return axis_kwargs

    existing = axis_kwargs or {}
    explicit = unify_axes if isinstance(unify_axes, dict) else {}
    unified: Dict[str, float] = {}

    need_vmin = "vmin" not in explicit and "vmin" not in existing
    need_vmax = "vmax" not in explicit and "vmax" not in existing

    if need_vmin or need_vmax:
        if isinstance(sorting_variables, dict):
            vals = np.concatenate(
                [nodes.data[v].to_numpy() for v in sorting_variables.values()]
            )
        else:
            vals = nodes.data[sorting_variables].to_numpy()
        if need_vmin:
            unified["vmin"] = float(np.nanmin(vals))
        if need_vmax:
            unified["vmax"] = float(np.nanmax(vals))

    # precedence: axis_kwargs > explicit dict > auto-computed
    merged = {**unified, **explicit, **existing}
    return merged if merged else None


class HivePlotMatrix:
    """
    Matrix of ``HivePlot`` instances for comparative network visualization.

    A ``HivePlotMatrix`` stores a 2D grid of ``HivePlot`` instances (or ``None`` for empty cells),
    along with optional row and column labels. This class provides both a generic constructor
    and convenience methods for common use cases.

    The generic constructor accepts a list-of-lists or dictionary of ``HivePlot`` instances.
    For common patterns, use the convenience methods:

    - :py:meth:`from_partition`: pairwise group matrix for networks with >3 groups.
    - :py:meth:`from_variable_sweep`: compare different sorting and/or partition variables.
    - :py:meth:`from_tags`: compare different edge tags side by side.

    :param hive_plots: 2D grid of ``HivePlot`` instances. Can be provided as a list of lists
        (where inner lists are rows and ``None`` represents empty cells) or as a dictionary
        mapping ``(row, col)`` tuples to ``HivePlot`` instances.
    :param row_labels: labels for each row. Length must match the number of rows.
    :param col_labels: labels for each column. Length must match the number of columns.
    :param backend: visualization backend to use. When provided, sets the backend on all
        populated cells. When ``None`` (default), the backend is inferred from the first
        populated hive plot cell.
    :param unify_axes: whether to unify axis value ranges across all cells. When ``True``,
        auto-computes global ``vmin``/``vmax`` from all axes in all hive plots and applies them
        uniformly. When a ``dict`` (e.g. ``{"vmin": 0, "vmax": 10}`` or ``{"vmin": 0}``),
        uses explicit values and auto-computes any missing ones. When ``False`` (default),
        axes keep their per-cell ranges. Triggers a rebuild of already-built HivePlot instances.

        **Priority of params**: ``axis_kwargs`` > explicit dict values > auto-computed values.
    :param axis_kwargs: keyword arguments applied uniformly to every axis in every populated
        hive plot cell (e.g. ``{"vmin": 0, "vmax": 1e9}`` to fix the display range across all axes).
        Applied post-construction via :py:meth:`~hiveplotlib.HivePlot.update_axis`, so it
        overwrites any per-axis settings already present on the supplied ``HivePlot`` instances.
    :param node_kwargs: keyword arguments forwarded to the node rendering call for every
        hive plot cell. For the ``matplotlib`` backend these are ``scatter()`` kwargs; for the
        ``datashader`` backend these are ``imshow()`` kwargs applied to the node
        rasterization. Can be overridden at plot time by passing ``node_kwargs`` directly
        to :py:meth:`~hiveplotlib.HivePlotMatrix.plot`.
    :param all_edge_kwargs: keyword arguments for all edges.
        Disregarded when using the ``"datashader"`` backend.
    :param repeat_edge_kwargs: keyword arguments for repeat edges.
        Disregarded when using the ``"datashader"`` backend.
    :param non_repeat_edge_kwargs: keyword arguments for non-repeat edges.
        Disregarded when using the ``"datashader"`` backend.
    :param clockwise_edge_kwargs: keyword arguments for edges going clockwise.
        Disregarded when using the ``"datashader"`` backend.
    :param counterclockwise_edge_kwargs: keyword arguments for edges going counterclockwise.
        Disregarded when using the ``"datashader"`` backend.
    """

    _hive_plots: List[List[Optional[HivePlot]]]
    _matrix_type: HPM_MATRIX_TYPES
    _backend: HPM_SUPPORTED_VIZ_BACKENDS
    _row_labels: Optional[List[Hashable]]
    _col_labels: Optional[List[Hashable]]
    _tags_per_cell: Optional[Dict[Tuple[int, int], Hashable]]
    _cell_labels: Optional[Dict[Tuple[int, int], Hashable]]
    _per_tag_plot_kwargs: Dict[Hashable, dict]
    _node_plot_kwargs: dict

    def __init__(
        self,
        hive_plots: Union[
            List[List[Optional[HivePlot]]],
            Dict[Tuple[int, int], HivePlot],
        ],
        row_labels: Optional[List[Hashable]] = None,
        col_labels: Optional[List[Hashable]] = None,
        backend: Optional[HPM_SUPPORTED_VIZ_BACKENDS] = None,
        unify_axes: Union[bool, Dict[str, float]] = False,
        axis_kwargs: Optional[dict] = None,
        node_kwargs: Optional[dict] = None,
        all_edge_kwargs: Optional[dict] = None,
        repeat_edge_kwargs: Optional[dict] = None,
        non_repeat_edge_kwargs: Optional[dict] = None,
        clockwise_edge_kwargs: Optional[dict] = None,
        counterclockwise_edge_kwargs: Optional[dict] = None,
    ) -> None:
        """Initialize class."""
        grid = (
            self._dict_to_grid(hive_plots)
            if isinstance(hive_plots, dict)
            else hive_plots
        )

        self._validate_grid(grid)
        self._hive_plots = grid
        nrows, ncols = self.shape

        if row_labels is not None and len(row_labels) != nrows:
            msg = (
                f"Length of `row_labels` ({len(row_labels)}) must match "
                f"the number of rows ({nrows})."
            )
            raise ValueError(msg)
        if col_labels is not None and len(col_labels) != ncols:
            msg = (
                f"Length of `col_labels` ({len(col_labels)}) must match "
                f"the number of columns ({ncols})."
            )
            raise ValueError(msg)

        self._row_labels = row_labels
        self._col_labels = col_labels
        self._matrix_type = "generic"
        self._tags_per_cell = None
        self._cell_labels = None
        self._per_tag_plot_kwargs = {}
        self._node_plot_kwargs = node_kwargs or {}

        if backend is not None:
            # validate and propagate to all cells
            self._backend = backend
            self.set_viz_backend(backend)
        else:
            # validate all cells' backends before inferring
            for _r, _c, _hp in self.iter_populated_cells():
                if _hp.backend not in get_args(HPM_SUPPORTED_VIZ_BACKENDS):
                    msg = (
                        f"At least one of your HivePlots has backend '{_hp.backend}', "
                        f"which is not supported by HivePlotMatrix. "
                        f"Supported backends are {get_args(HPM_SUPPORTED_VIZ_BACKENDS)}."
                    )
                    raise InvalidVizBackendError(msg)
            # infer backend from first populated cell
            self._backend = self._infer_backend()

        if axis_kwargs is not None:
            for _r, _c, hp in self.iter_populated_cells():
                axes = list(hp.axes.keys())
                for i, axis_id in enumerate(axes):
                    hp.update_axis(
                        axis_id=axis_id,
                        build_hive_plot=(i == len(axes) - 1),
                        **axis_kwargs,
                    )

        if unify_axes is not False:
            if isinstance(unify_axes, dict):
                self.unify_axes(**unify_axes)
            else:
                self.unify_axes()

        edge_kwargs_map = {
            "all_edge_kwargs": all_edge_kwargs,
            "repeat_edge_kwargs": repeat_edge_kwargs,
            "non_repeat_edge_kwargs": non_repeat_edge_kwargs,
            "clockwise_edge_kwargs": clockwise_edge_kwargs,
            "counterclockwise_edge_kwargs": counterclockwise_edge_kwargs,
        }
        for setting, kwargs in edge_kwargs_map.items():
            if kwargs is not None:
                self.update_all_edge_plotting_keyword_arguments(
                    edge_kwarg_setting=setting,  # ty:ignore[invalid-argument-type]
                    **kwargs,
                )

    @staticmethod
    def _dict_to_grid(
        hive_plots: Dict[Tuple[int, int], HivePlot],
    ) -> List[List[Optional[HivePlot]]]:
        """
        Convert a dictionary of ``(row, col) -> HivePlot`` to a 2D list-of-lists grid.

        :param hive_plots: dictionary mapping ``(row, col)`` tuples to ``HivePlot`` instances.
        :return: 2D list of lists.
        """
        if not hive_plots:
            msg = "Cannot create HivePlotMatrix from an empty dictionary."
            raise ValueError(msg)
        max_row = max(r for r, _ in hive_plots) + 1
        max_col = max(c for _, c in hive_plots) + 1
        grid: List[List[Optional[HivePlot]]] = [
            [None for _ in range(max_col)] for _ in range(max_row)
        ]
        for (r, c), hp in hive_plots.items():
            grid[r][c] = hp
        return grid

    @staticmethod
    def _validate_grid(grid: List[List[Optional[HivePlot]]]) -> None:
        """
        Validate a 2D grid of HivePlots.

        :param grid: 2D list of lists.
        :raises ValueError: if the grid is empty or ragged.
        """
        if not grid:
            msg = "Cannot create HivePlotMatrix from an empty grid."
            raise ValueError(msg)
        ncols = len(grid[0])
        for i, row in enumerate(grid):
            if len(row) != ncols:
                msg = f"Ragged grid: row 0 has {ncols} columns but row {i} has {len(row)} columns."
                raise ValueError(msg)
        # must have at least one populated cell
        has_any = any(cell is not None for row in grid for cell in row)
        if not has_any:
            msg = "HivePlotMatrix must contain at least one HivePlot instance."
            raise ValueError(msg)

    def _infer_backend(self) -> str:
        """
        Infer the backend from the first populated cell.

        :return: backend string.
        """
        for row in self._hive_plots:
            for cell in row:
                if cell is not None:
                    return cell.backend  # ty:ignore[invalid-return-type]
        return "matplotlib"  # pragma: no cover

    # ---- Properties ----

    @property
    def shape(self) -> Tuple[int, int]:
        """
        Return the shape ``(nrows, ncols)`` of the matrix.

        :return: tuple of (number of rows, number of columns).
        """
        nrows = len(self._hive_plots)
        ncols = len(self._hive_plots[0]) if nrows > 0 else 0
        return nrows, ncols

    @property
    def row_labels(self) -> Optional[List[Hashable]]:
        """
        Return the row labels.

        :return: list of row labels, or ``None`` if not set.
        """
        return self._row_labels

    @property
    def col_labels(self) -> Optional[List[Hashable]]:
        """
        Return the column labels.

        :return: list of column labels, or ``None`` if not set.
        """
        return self._col_labels

    @property
    def cell_labels(self) -> Optional[Dict[Tuple[int, int], Hashable]]:
        """
        Return per-cell labels for wrapped layouts.

        When ``ncols`` wrapping is used, cell labels map ``(row, col)`` to the
        label for that cell. Returns ``None`` for non-wrapped layouts.

        :return: dictionary mapping ``(row, col)`` to label, or ``None``.
        """
        return self._cell_labels

    @property
    def matrix_type(self) -> HPM_MATRIX_TYPES:
        """
        Return the matrix type.

        :return: one of ``"generic"``, ``"from_partition"``, ``"from_variable_sweep"``, or ``"from_tags"``.
        """
        return self._matrix_type

    # ---- Cell Access ----

    def __getitem__(self, key: Tuple[int, int]) -> Optional[HivePlot]:
        """
        Get a ``HivePlot`` at position ``(row, col)``.

        :param key: ``(row, col)`` tuple.
        :return: ``HivePlot`` instance or ``None``.
        """
        r, c = key
        return self._hive_plots[r][c]

    def __setitem__(self, key: Tuple[int, int], value: Optional[HivePlot]) -> None:
        """
        Set a ``HivePlot`` at position ``(row, col)``.

        :param key: ``(row, col)`` tuple.
        :param value: ``HivePlot`` instance or ``None``.
        :return: ``None``.
        """
        r, c = key
        self._hive_plots[r][c] = value

    def iter_populated_cells(self) -> Iterator[Tuple[int, int, HivePlot]]:
        """
        Iterate over populated (non-``None``) cells.

        :return: iterator yielding ``(row, col, HivePlot)`` tuples.
        """
        nrows, ncols = self.shape
        for r in range(nrows):
            for c in range(ncols):
                cell = self._hive_plots[r][c]
                if cell is not None:
                    yield r, c, cell

    # ---- Bulk Modification ----

    def set_viz_backend(self, backend: HPM_SUPPORTED_VIZ_BACKENDS) -> None:
        """
        Set the visualization backend for the matrix and all populated cells.

        :param backend: which viz backend to use for plotting.
        :raises InvalidVizBackendError: if ``backend`` is not a supported backend.
        :return: ``None``.
        """
        if backend not in get_args(HPM_SUPPORTED_VIZ_BACKENDS):
            msg = (
                f"Requested backend '{backend}' not among supported backends "
                f"{get_args(HPM_SUPPORTED_VIZ_BACKENDS)}."
            )
            raise InvalidVizBackendError(msg)
        self._backend = backend
        for _r, _c, hp in self.iter_populated_cells():
            hp.set_viz_backend(backend)

    def update_all_edge_plotting_keyword_arguments(
        self,
        edge_kwarg_setting: EDGE_KWARG_HIERARCHY = "all_edge_kwargs",
        reset_edge_kwarg_setting: bool = False,
        rebuild_edges: bool = False,
        **kwargs: object,
    ) -> None:
        """
        Update edge plotting keyword arguments for all populated cells.

        :param edge_kwarg_setting: which edge kwarg setting to modify.
        :param reset_edge_kwarg_setting: whether to overwrite existing keyword arguments for the chosen
            ``edge_kwarg_setting``.
        :param rebuild_edges: whether to only update edge kwargs or to also redraw the edges. Default ``False``
            only updates edge kwargs.
        :param kwargs: additional keyword arguments to provide to the specified edge kwarg setting.
        :return: ``None``.
        """
        for _r, _c, hp in self.iter_populated_cells():
            hp.update_edge_plotting_keyword_arguments(
                edge_kwarg_setting=edge_kwarg_setting,
                reset_edge_kwarg_setting=reset_edge_kwarg_setting,
                rebuild_edges=rebuild_edges,
                **kwargs,
            )

    def unify_axes(
        self,
        vmin: Optional[float] = None,
        vmax: Optional[float] = None,
    ) -> None:
        """
        Unify axis value ranges across all populated cells.

        Applies a single ``(vmin, vmax)`` range to every axis in every populated cell,
        ensuring honest visual comparisons across the matrix.

        When ``vmin`` or ``vmax`` is ``None``, the value is auto-computed from the
        current axis ranges across all cells (global min/max).

        .. note::
            This method causes a rebuild of all populated HivePlots. For convenience
            methods (``from_partition``, ``from_variable_sweep``, ``from_tags``), prefer
            the ``unify_axes`` constructor parameter which pre-computes the range and
            avoids a double build.

        :param vmin: minimum value for all axes. ``None`` (default) auto-computes.
        :param vmax: maximum value for all axes. ``None`` (default) auto-computes.
        :return: ``None``.
        """
        if vmin is None or vmax is None:
            all_vmins = []
            all_vmaxs = []
            for _r, _c, hp in self.iter_populated_cells():
                for axis in hp.axes.values():
                    all_vmins.append(axis.vmin)
                    all_vmaxs.append(axis.vmax)
            if vmin is None:
                vmin = float(np.nanmin(all_vmins))
            if vmax is None:
                vmax = float(np.nanmax(all_vmaxs))

        for _r, _c, hp in self.iter_populated_cells():
            axes = list(hp.axes.keys())
            for i, axis_id in enumerate(axes):
                hp.update_axis(
                    axis_id=axis_id,
                    vmin=vmin,
                    vmax=vmax,
                    build_hive_plot=(i == len(axes) - 1),  # rebuild on last axis only
                )

    # ---- Plotting ----

    def plot(self, **kwargs):  # noqa: ANN201
        """
        Plot the hive plot matrix.

        Creates a ``matplotlib`` subplot grid and renders each populated cell.
        Plotting behavior varies based on the matrix type:

        - ``"from_partition"``: diagonal cells are zoomed to the repeat-axis quadrant
          with separate buffer and pixel-spread settings; labels are positioned
          relative to diagonal vs off-diagonal placement.
        - ``"from_variable_sweep"`` / ``"from_tags"`` / ``"generic"``: all cells
          rendered with identical settings (buffer, pixel spread, zoom).

        .. note::
            When the backend is set to ``datashader``, any provided node or edge plotting
            keyword arguments will be disregarded, as attributes like color and size are
            reserved for datashading. Global ``vmax`` values for node and edge density
            are auto-computed across all cells when not explicitly provided.

        :param kwargs: keyword arguments forwarded to
            :py:func:`~hiveplotlib.viz.hiveplot_matrix.hive_plot_matrix_viz`.
        :return: viz data structures. For the ``matplotlib`` backend, ``(fig, axes)``.
            For the ``datashader`` backend,
            ``(fig, axes, im_nodes_dict, im_edges_dict)``. See
            :py:func:`~hiveplotlib.viz.hiveplot_matrix.hive_plot_matrix_viz` for details.
        """
        from hiveplotlib.viz.hiveplot_matrix import hive_plot_matrix_viz

        return hive_plot_matrix_viz(self, **kwargs)

    # ---- Convenience: from_partition ----

    @classmethod
    def from_partition(
        cls,
        nodes: NodeCollection,
        edges: Union[Edges, np.ndarray],
        partition_variable: Hashable,
        sorting_variables: Union[Hashable, Dict[Hashable, Hashable]],
        partition_values: Optional[List[Hashable]] = None,
        collapsed_group_axis_name: str = "Other",
        backend: HPM_SUPPORTED_VIZ_BACKENDS = "matplotlib",
        include_diagonal: bool = True,
        hive_plot_kwargs: Optional[Dict] = None,
        unify_axes: Union[bool, Dict[Literal["vmin", "vmax"], float]] = False,
        axis_kwargs: Optional[dict] = None,
        node_kwargs: Optional[dict] = None,
        all_edge_kwargs: Optional[dict] = None,
        repeat_edge_kwargs: Optional[dict] = None,
        non_repeat_edge_kwargs: Optional[dict] = None,
        clockwise_edge_kwargs: Optional[dict] = None,
        counterclockwise_edge_kwargs: Optional[dict] = None,
        num_steps_per_edge: int = 100,
        use_numba: bool = True,
        n_parallel: Optional[int] = None,
        progress: bool = True,
    ) -> "HivePlotMatrix":
        """
        Build a pairwise group matrix for networks with more than 3 groups.

        For N groups, creates an N x N upper-triangular matrix:

        - **Diagonal (i, i)**: repeat axes for the single group.
        - **Off-diagonal (i, j) where i < j**: two named groups + collapsed "Other" axis.
        - **Lower triangle**: empty (``None``).

        :param nodes: node data.
        :param edges: edge data.
        :param partition_variable: which column in node data to partition on. The unique values of this column define
            the groups compared in the matrix.
        :param sorting_variables: which column(s) to sort nodes on each axis.
        :param partition_values: which partition values to include and their order. Default ``None`` uses all
            unique values of ``partition_variable``.
        :param collapsed_group_axis_name: name for the collapsed "Other" axis. Default ``"Other"``.
        :param backend: visualization backend. Default ``"matplotlib"``.
        :param include_diagonal: whether to include diagonal (repeat-axis) cells. Default ``True``.
        :param hive_plot_kwargs: additional keyword arguments passed to each ``HivePlot`` constructor.
        :param unify_axes: whether to unify axis value ranges across all cells. When ``True``,
            auto-computes global ``vmin``/``vmax`` from the node data and applies
            them uniformly. When a ``dict`` (e.g. ``{"vmin": 0, "vmax": 10}`` or ``{"vmin": 0}``),
            uses explicit values and auto-computes any missing ones. When ``False`` (default),
            axes auto-scale per cell. Pre-computed from the raw data to avoid a double build.

            **Priority of params**: ``axis_kwargs`` > explicit dict values > auto-computed values.
        :param axis_kwargs: keyword arguments applied uniformly to every axis in every hive plot cell
            (e.g. ``{"vmin": 0, "vmax": 1e9}`` to fix the display range across all axes). Takes precedence over any
            ``"axis_kwargs"`` key inside ``hive_plot_kwargs``.
        :param node_kwargs: keyword arguments forwarded to the node rendering call for every
            hive plot cell. For the ``matplotlib`` backend these are ``scatter()`` kwargs; for the
            ``datashader`` backend these are ``imshow()`` kwargs applied to the node
            rasterization. Can be overridden at plot time by passing ``node_kwargs`` directly
            to :py:meth:`~hiveplotlib.HivePlotMatrix.plot`.
        :param all_edge_kwargs: keyword arguments for all edges.
            Disregarded when using the ``"datashader"`` backend.
        :param repeat_edge_kwargs: keyword arguments for repeat edges (diagonal cells).
            Disregarded when using the ``"datashader"`` backend.
        :param non_repeat_edge_kwargs: keyword arguments for non-repeat edges (off-diagonal cells).
            Disregarded when using the ``"datashader"`` backend.
        :param clockwise_edge_kwargs: keyword arguments for edges going clockwise (off-diagonal cells only).
            Disregarded when using the ``"datashader"`` backend.
        :param counterclockwise_edge_kwargs: keyword arguments for edges going counterclockwise
            (off-diagonal cells only). Disregarded when using the ``"datashader"`` backend.
        :param num_steps_per_edge: number of Bezier curve steps per edge.
        :param use_numba: whether to use numba for Bezier computation.
        :param n_parallel: number of parallel threads for Bezier computation.
        :param progress: whether to show a progress bar.
        :return: ``HivePlotMatrix`` instance.
        """
        hive_plot_kwargs = hive_plot_kwargs or {}
        all_edge_kwargs = all_edge_kwargs or {}
        repeat_edge_kwargs = repeat_edge_kwargs or {}
        non_repeat_edge_kwargs = non_repeat_edge_kwargs or {}
        clockwise_edge_kwargs = clockwise_edge_kwargs or {}
        counterclockwise_edge_kwargs = counterclockwise_edge_kwargs or {}

        # pre-compute unified axis range from raw data (avoids double-build)
        axis_kwargs = _resolve_unify_axes(
            unify_axes, axis_kwargs, nodes, sorting_variables
        )

        # auto-detect groups if not provided
        if partition_values is None:
            unique_vals = nodes.data[partition_variable].unique()
            partition_values = sorted(unique_vals)

        n = len(partition_values)
        tqdm_wrapper = _get_tqdm_or_noop(progress)

        # collect (i, j) pairs for progress tracking
        cell_pairs: List[Tuple[int, int]] = []
        for i in range(n):
            for j in range(i, n):
                if i == j and not include_diagonal:
                    continue
                cell_pairs.append((i, j))

        # build grid
        grid: List[List[Optional[HivePlot]]] = [
            [None for _ in range(n)] for _ in range(n)
        ]

        for i, j in tqdm_wrapper(cell_pairs, desc="Building HivePlots"):
            if i == j:
                # diagonal: repeat axes for single group
                cell_hp_kwargs = dict(hive_plot_kwargs)
                if axis_kwargs is not None:
                    cell_hp_kwargs["axis_kwargs"] = {partition_values[i]: axis_kwargs}
                hp = HivePlot(
                    nodes=nodes,
                    edges=edges,
                    partition_variable=partition_variable,
                    sorting_variables=sorting_variables,
                    backend=backend,
                    repeat_axes=[partition_values[i]],
                    axes_order=[partition_values[i]],
                    rotation=135,
                    collapsed_group_axis_name=collapsed_group_axis_name,
                    all_edge_kwargs=all_edge_kwargs,
                    repeat_edge_kwargs=repeat_edge_kwargs,
                    num_steps_per_edge=num_steps_per_edge,
                    use_numba=use_numba,
                    n_parallel=n_parallel,
                    **cell_hp_kwargs,
                )
                grid[i][j] = hp
            else:
                # off-diagonal: two named groups + collapsed "Other"
                cell_hp_kwargs = dict(hive_plot_kwargs)
                if axis_kwargs is not None:
                    cell_hp_kwargs["axis_kwargs"] = {
                        partition_values[i]: axis_kwargs,
                        partition_values[j]: axis_kwargs,
                        collapsed_group_axis_name: axis_kwargs,
                    }
                hp = HivePlot(
                    nodes=nodes,
                    edges=edges,
                    partition_variable=partition_variable,
                    sorting_variables=sorting_variables,
                    backend=backend,
                    repeat_axes=False,
                    axes_order=[partition_values[i], partition_values[j], None],
                    collapsed_group_axis_name=collapsed_group_axis_name,
                    all_edge_kwargs=all_edge_kwargs,
                    non_repeat_edge_kwargs=non_repeat_edge_kwargs,
                    clockwise_edge_kwargs=clockwise_edge_kwargs,
                    counterclockwise_edge_kwargs=counterclockwise_edge_kwargs,
                    num_steps_per_edge=num_steps_per_edge,
                    use_numba=use_numba,
                    n_parallel=n_parallel,
                    **cell_hp_kwargs,
                )
                grid[i][j] = hp

        # set long_name on each axis for compact display
        for _r, _c, hp in (
            (r, c, grid[r][c])
            for r in range(n)
            for c in range(n)
            if grid[r][c] is not None
        ):
            assert hp is not None  # guaranteed by generator filter above
            for axis_id in hp.axes:
                axis_name = str(axis_id)
                # strip _repeat suffix for display
                display_name = axis_name.replace("_repeat", "")
                hp.axes[axis_id].long_name = display_name.replace(" ", "\n")

        # group labels for rows/cols
        group_labels = [str(g) for g in partition_values]

        instance = cls.__new__(cls)
        instance._hive_plots = grid
        instance._row_labels = group_labels
        instance._col_labels = group_labels

        instance._matrix_type = "from_partition"
        instance._backend = backend
        instance._tags_per_cell = None
        instance._cell_labels = None
        instance._per_tag_plot_kwargs = {}
        instance._node_plot_kwargs = node_kwargs or {}

        return instance

    # ---- Convenience: from_variable_sweep ----

    @classmethod
    def from_variable_sweep(
        cls,
        nodes: NodeCollection,
        edges: Union[Edges, np.ndarray],
        partition_variable: Optional[Hashable] = None,
        sorting_variables: Optional[Union[Hashable, Dict[Hashable, Hashable]]] = None,
        sorting_variables_list: Optional[
            List[Union[Hashable, Dict[Hashable, Hashable]]]
        ] = None,
        partition_variables_list: Optional[List[Hashable]] = None,
        repeat_axes: Union[bool, Hashable, List[Hashable]] = False,
        ncols: Optional[int] = None,
        backend: HPM_SUPPORTED_VIZ_BACKENDS = "matplotlib",
        hive_plot_kwargs: Optional[Dict] = None,
        unify_axes: Union[bool, Dict[Literal["vmin", "vmax"], float]] = False,
        axis_kwargs: Optional[dict] = None,
        node_kwargs: Optional[dict] = None,
        all_edge_kwargs: Optional[dict] = None,
        repeat_edge_kwargs: Optional[dict] = None,
        non_repeat_edge_kwargs: Optional[dict] = None,
        clockwise_edge_kwargs: Optional[dict] = None,
        counterclockwise_edge_kwargs: Optional[dict] = None,
        num_steps_per_edge: int = 100,
        use_numba: bool = True,
        n_parallel: Optional[int] = None,
        progress: bool = True,
    ) -> "HivePlotMatrix":
        """
        Build a matrix comparing different sorting and/or partition variables.

        Three modes based on which list parameters are provided:

        - ``sorting_variables_list`` only: 1D row, each column uses a different sorting variable
          (requires ``partition_variable``)
        - ``partition_variables_list`` only: 1D row, each column uses a different partition variable
          (requires ``sorting_variables``)
        - Both: 2D grid with rows = partition variables, columns = sorting variables

        :param nodes: node data.
        :param edges: edge data.
        :param partition_variable: fixed partition variable
            (required when only ``partition_variables_list`` is not provided).
        :param sorting_variables: fixed sorting variable(s)
            (required when only ``sorting_variables_list`` is not provided).
        :param sorting_variables_list: list of sorting variable configurations to compare.
        :param partition_variables_list: list of partition variables to compare.
        :param repeat_axes: which partition groups to create repeat axes for.
            ``True`` creates repeat axes for all groups, ``False`` disables repeat axes.
            When ``partition_variables_list`` is provided, only ``True`` / ``False`` is
            accepted (specific axis names vary across partition variables).
        :param ncols: when result is 1D, wrap into rows of ``ncols`` width. Ignored when both lists are provided.
        :param backend: visualization backend.
        :param hive_plot_kwargs: additional keyword arguments passed to each ``HivePlot`` constructor.
        :param unify_axes: whether to unify axis value ranges across all cells. When ``True``,
            auto-computes global ``vmin``/``vmax`` from the node data across all sorting
            variables and applies them uniformly. When a ``dict``
            (e.g. ``{"vmin": 0, "vmax": 10}`` or ``{"vmin": 0}``), uses explicit values and
            auto-computes any missing ones. When ``False`` (default), axes auto-scale per cell.

            **Priority of params**: ``axis_kwargs`` > explicit dict values > auto-computed values.
        :param axis_kwargs: keyword arguments applied uniformly to every axis in every hive plot cell
            (e.g. ``{"vmin": 0, "vmax": 1e9}`` to fix the display range across all axes). Takes precedence over any
            ``"axis_kwargs"`` key inside ``hive_plot_kwargs``.
        :param node_kwargs: keyword arguments forwarded to the node rendering call for every
            hive plot cell. For the ``matplotlib`` backend these are ``scatter()`` kwargs; for the
            ``datashader`` backend these are ``imshow()`` kwargs applied to the node
            rasterization. Can be overridden at plot time by passing ``node_kwargs`` directly
            to :py:meth:`~hiveplotlib.HivePlotMatrix.plot`.
        :param all_edge_kwargs: keyword arguments for all edges.
            Disregarded when using the ``"datashader"`` backend.
        :param repeat_edge_kwargs: keyword arguments for repeat edges.
            Disregarded when using the ``"datashader"`` backend.
        :param non_repeat_edge_kwargs: keyword arguments for non-repeat edges.
            Disregarded when using the ``"datashader"`` backend.
        :param clockwise_edge_kwargs: keyword arguments for edges going clockwise.
            Disregarded when using the ``"datashader"`` backend.
        :param counterclockwise_edge_kwargs: keyword arguments for edges going counterclockwise.
            Disregarded when using the ``"datashader"`` backend.
        :param num_steps_per_edge: number of Bezier curve steps per edge.
        :param use_numba: whether to use numba for Bezier computation.
        :param n_parallel: number of parallel threads for Bezier computation.
        :param progress: whether to show a progress bar.
        :return: ``HivePlotMatrix`` instance.
        """
        hive_plot_kwargs = hive_plot_kwargs or {}
        all_edge_kwargs = all_edge_kwargs or {}
        repeat_edge_kwargs = repeat_edge_kwargs or {}
        non_repeat_edge_kwargs = non_repeat_edge_kwargs or {}
        clockwise_edge_kwargs = clockwise_edge_kwargs or {}
        counterclockwise_edge_kwargs = counterclockwise_edge_kwargs or {}

        # pre-compute unified axis range from raw data (avoids double-build)
        if unify_axes is not False:
            # collect all sorting variable columns across the sweep
            if sorting_variables_list is not None:
                all_cols: set = set()
                for sv in sorting_variables_list:
                    if isinstance(sv, dict):
                        all_cols.update(sv.values())
                    else:
                        all_cols.add(sv)
                combined_sv: Union[Hashable, Dict[Hashable, Hashable]] = {
                    col: col for col in all_cols
                }
            else:
                assert sorting_variables is not None
                combined_sv = sorting_variables
            axis_kwargs = _resolve_unify_axes(
                unify_axes, axis_kwargs, nodes, combined_sv
            )

        if sorting_variables_list is None and partition_variables_list is None:
            msg = "At least one of `sorting_variables_list` or `partition_variables_list` must be provided."
            raise ValueError(msg)

        if partition_variables_list is not None and not isinstance(repeat_axes, bool):
            msg = (
                "`repeat_axes` must be a bool (`True` or `False`) when "
                "`partition_variables_list` is provided, because each partition "
                "variable produces different axis names."
            )
            raise ValueError(msg)

        tqdm_wrapper = _get_tqdm_or_noop(progress)

        if sorting_variables_list is not None and partition_variables_list is not None:
            # 2D grid: rows = partition vars, cols = sorting vars
            row_labels = [str(p) for p in partition_variables_list]
            col_labels = [str(s) for s in sorting_variables_list]

            # collect all (pv, sv) pairs for progress tracking
            sweep_pairs = [
                (pv, sv)
                for pv in partition_variables_list
                for sv in sorting_variables_list
            ]

            grid: List[List[Optional[HivePlot]]] = []
            row: List[Optional[HivePlot]] = []
            for idx, (pv, sv) in enumerate(
                tqdm_wrapper(sweep_pairs, desc="Building HivePlots")
            ):
                cell_hp_kwargs = dict(hive_plot_kwargs)
                if axis_kwargs is not None:
                    partition_vals = nodes.data[pv].unique()
                    cell_hp_kwargs["axis_kwargs"] = dict.fromkeys(
                        partition_vals, axis_kwargs
                    )
                hp = HivePlot(
                    nodes=nodes,
                    edges=edges,
                    partition_variable=pv,
                    sorting_variables=sv,
                    backend=backend,
                    repeat_axes=repeat_axes,
                    all_edge_kwargs=all_edge_kwargs,
                    repeat_edge_kwargs=repeat_edge_kwargs,
                    non_repeat_edge_kwargs=non_repeat_edge_kwargs,
                    clockwise_edge_kwargs=clockwise_edge_kwargs,
                    counterclockwise_edge_kwargs=counterclockwise_edge_kwargs,
                    num_steps_per_edge=num_steps_per_edge,
                    use_numba=use_numba,
                    n_parallel=n_parallel,
                    **cell_hp_kwargs,
                )
                row.append(hp)
                if (idx + 1) % len(sorting_variables_list) == 0:
                    grid.append(row)
                    row = []

        elif sorting_variables_list is not None:
            # 1D: varying sorting variables
            if partition_variable is None:
                msg = (
                    "`partition_variable` is required when providing "
                    "`sorting_variables_list` without `partition_variables_list`."
                )
                raise ValueError(msg)
            col_labels = [str(s) for s in sorting_variables_list]
            row_labels = None

            # axis names are fixed (partition_variable is shared)
            if axis_kwargs is not None:
                partition_vals = nodes.data[partition_variable].unique()
                hive_plot_kwargs = dict(hive_plot_kwargs)
                hive_plot_kwargs["axis_kwargs"] = dict.fromkeys(
                    partition_vals, axis_kwargs
                )

            hive_plots_1d: List[Optional[HivePlot]] = []
            progress_iter = tqdm_wrapper(
                sorting_variables_list,
                desc="Building HivePlots",
                total=len(sorting_variables_list),
            )
            for sv in progress_iter:
                hp = HivePlot(
                    nodes=nodes,
                    edges=edges,
                    partition_variable=partition_variable,
                    sorting_variables=sv,
                    backend=backend,
                    repeat_axes=repeat_axes,
                    all_edge_kwargs=all_edge_kwargs,
                    repeat_edge_kwargs=repeat_edge_kwargs,
                    non_repeat_edge_kwargs=non_repeat_edge_kwargs,
                    clockwise_edge_kwargs=clockwise_edge_kwargs,
                    counterclockwise_edge_kwargs=counterclockwise_edge_kwargs,
                    num_steps_per_edge=num_steps_per_edge,
                    use_numba=use_numba,
                    n_parallel=n_parallel,
                    **hive_plot_kwargs,
                )
                hive_plots_1d.append(hp)

            grid = _wrap_1d_to_2d(hive_plots_1d, ncols)

        else:
            # 1D: varying partition variables
            assert partition_variables_list is not None  # for type checker
            if sorting_variables is None:
                msg = (
                    "`sorting_variables` is required when providing "
                    "`partition_variables_list` without `sorting_variables_list`."
                )
                raise ValueError(msg)
            col_labels = [str(p) for p in partition_variables_list]
            row_labels = None

            hive_plots_1d = []
            progress_iter = tqdm_wrapper(
                partition_variables_list,
                desc="Building HivePlots",
                total=len(partition_variables_list),
            )
            for pv in progress_iter:
                cell_hp_kwargs = dict(hive_plot_kwargs)
                if axis_kwargs is not None:
                    partition_vals = nodes.data[pv].unique()
                    cell_hp_kwargs["axis_kwargs"] = dict.fromkeys(
                        partition_vals, axis_kwargs
                    )
                hp = HivePlot(
                    nodes=nodes,
                    edges=edges,
                    partition_variable=pv,
                    sorting_variables=sorting_variables,
                    backend=backend,
                    repeat_axes=repeat_axes,
                    all_edge_kwargs=all_edge_kwargs,
                    repeat_edge_kwargs=repeat_edge_kwargs,
                    non_repeat_edge_kwargs=non_repeat_edge_kwargs,
                    clockwise_edge_kwargs=clockwise_edge_kwargs,
                    counterclockwise_edge_kwargs=counterclockwise_edge_kwargs,
                    num_steps_per_edge=num_steps_per_edge,
                    use_numba=use_numba,
                    n_parallel=n_parallel,
                    **cell_hp_kwargs,
                )
                hive_plots_1d.append(hp)

            grid = _wrap_1d_to_2d(hive_plots_1d, ncols)

        # build cell_labels for wrapped layouts
        cell_labels_dict: Optional[Dict[Tuple[int, int], Hashable]] = None
        if ncols is not None:
            cell_labels_dict = {}
            for idx, label in enumerate(col_labels):
                r_idx, c_idx = divmod(idx, ncols)
                cell_labels_dict[(r_idx, c_idx)] = label

        instance = cls.__new__(cls)
        instance._hive_plots = grid
        instance._row_labels = row_labels
        instance._col_labels = None if cell_labels_dict is not None else col_labels

        instance._matrix_type = "from_variable_sweep"
        instance._backend = backend
        instance._tags_per_cell = None
        instance._cell_labels = cell_labels_dict
        instance._per_tag_plot_kwargs = {}
        instance._node_plot_kwargs = node_kwargs or {}

        return instance

    # ---- Convenience: from_tags ----

    @classmethod
    def from_tags(
        cls,
        nodes: NodeCollection,
        edges: Union[Edges, np.ndarray],
        partition_variable: Hashable,
        sorting_variables: Union[Hashable, Dict[Hashable, Hashable]],
        tags: Optional[List[Hashable]] = None,
        repeat_axes: Union[bool, Hashable, List[Hashable]] = False,
        ncols: Optional[int] = None,
        backend: HPM_SUPPORTED_VIZ_BACKENDS = "matplotlib",
        hive_plot_kwargs: Optional[Dict] = None,
        unify_axes: Union[bool, Dict[Literal["vmin", "vmax"], float]] = False,
        axis_kwargs: Optional[dict] = None,
        node_kwargs: Optional[dict] = None,
        per_tag_plot_kwargs: Optional[Dict[Hashable, dict]] = None,
        all_edge_kwargs: Optional[dict] = None,
        repeat_edge_kwargs: Optional[dict] = None,
        non_repeat_edge_kwargs: Optional[dict] = None,
        clockwise_edge_kwargs: Optional[dict] = None,
        counterclockwise_edge_kwargs: Optional[dict] = None,
        num_steps_per_edge: int = 100,
        use_numba: bool = True,
        n_parallel: Optional[int] = None,
    ) -> "HivePlotMatrix":
        """
        Build a matrix comparing different edge tags side by side.

        Each cell shows the **same** nodes and axis layout rendered with a different edge tag.
        Node positions are identical across all cells — only the visible edges change.

        This method is the right choice when your tags represent **different relationship types
        on the same network** (e.g., ``"official"``, ``"social"``, ``"informal"`` edges among
        the same set of people).

        .. warning::

            **When NOT to use** ``from_tags``: if your tags correspond to fundamentally
            different network snapshots — such as different time periods where the set of
            active nodes changes, or where per-tag node attributes differ meaningfully —
            then ``from_tags`` is the wrong tool. All cells will show the full
            ``NodeCollection`` regardless of which nodes actually appear in each tag's edges,
            and node positions will be based on the pooled data, not per-tag data.

            For per-snapshot comparisons (e.g., year-by-year network evolution), build a
            separate :py:class:`~hiveplotlib.HivePlot` per snapshot and pass the resulting
            list to the generic :py:class:`~hiveplotlib.HivePlotMatrix` constructor.

        :param nodes: node data. Shared across all cells.
        :param edges: edge data.
        :param partition_variable: which column in node data to partition on.
        :param sorting_variables: which column(s) to sort nodes on each axis.
        :param tags: which edge tags to compare. Default ``None`` uses all tags from the edges.
        :param repeat_axes: which partition groups to create repeat axes for.
            ``True`` creates repeat axes for all groups, ``False`` disables repeat axes.
        :param ncols: when provided, wraps the 1D row into rows of ``ncols`` width.
        :param backend: visualization backend.
        :param hive_plot_kwargs: additional keyword arguments passed to each ``HivePlot`` constructor.
        :param unify_axes: whether to unify axis value ranges across all cells. When ``True``,
            auto-computes a single global ``vmin``/``vmax`` across all sorting variables and
            applies them uniformly to every axis. Since different axes correspond to different
            partition groups, they may naturally have different data ranges; ``True`` collapses
            these into one shared range. When a ``dict`` (e.g. ``{"vmin": 0, "vmax": 10}``),
            uses explicit values and auto-computes any missing ones. When ``False`` (default),
            each axis auto-scales to its own data range.

            **Priority of params**: ``axis_kwargs`` > explicit dict values > auto-computed values.
        :param axis_kwargs: keyword arguments applied uniformly to every axis in every hive plot cell
            (e.g. ``{"vmin": 0, "vmax": 1e9}`` to fix the display range across all axes).
            Because all hive plot cells share the same ``partition_variable``, the same kwargs are applied
            to every axis in every cell. Takes precedence over any ``"axis_kwargs"`` key inside
            ``hive_plot_kwargs``.
        :param node_kwargs: keyword arguments forwarded to the node rendering call for every
            hive plot cell. For the ``matplotlib`` backend these are ``scatter()`` kwargs; for the
            ``datashader`` backend these are ``imshow()`` kwargs applied to the node
            rasterization. Can be overridden at plot time by passing ``node_kwargs`` directly
            to :py:meth:`~hiveplotlib.HivePlotMatrix.plot`.
        :param per_tag_plot_kwargs: per-tag keyword arguments forwarded to each hive plot cell's plot call
            (e.g. ``{"Older": {"cmap_edges": "Blues"}, "Newer": {"cmap_edges": "Oranges"}}``).
            Stored on the instance; can be overridden at plot time via ``per_tag_kwargs`` on
            :py:meth:`~hiveplotlib.HivePlotMatrix.plot`. Works for both the ``matplotlib`` and
            ``datashader`` backends; any plot-time kwarg accepted by the hive plot cell renderer can be
            supplied. The primary ``datashader`` use case is per-tag ``cmap_edges``.
        :param all_edge_kwargs: keyword arguments for all edges.
            Disregarded when using the ``"datashader"`` backend.
        :param repeat_edge_kwargs: keyword arguments for repeat edges.
            Disregarded when using the ``"datashader"`` backend.
        :param non_repeat_edge_kwargs: keyword arguments for non-repeat edges.
            Disregarded when using the ``"datashader"`` backend.
        :param clockwise_edge_kwargs: keyword arguments for edges going clockwise.
            Disregarded when using the ``"datashader"`` backend.
        :param counterclockwise_edge_kwargs: keyword arguments for edges going counterclockwise.
            Disregarded when using the ``"datashader"`` backend.
        :param num_steps_per_edge: number of Bezier curve steps per edge.
        :param use_numba: whether to use numba for Bezier computation.
        :param n_parallel: number of parallel threads for Bezier computation.
        :return: ``HivePlotMatrix`` instance.
        """
        hive_plot_kwargs = hive_plot_kwargs or {}
        all_edge_kwargs = all_edge_kwargs or {}
        repeat_edge_kwargs = repeat_edge_kwargs or {}
        non_repeat_edge_kwargs = non_repeat_edge_kwargs or {}
        clockwise_edge_kwargs = clockwise_edge_kwargs or {}
        counterclockwise_edge_kwargs = counterclockwise_edge_kwargs or {}

        # pre-compute unified axis range from raw data (avoids double-build)
        axis_kwargs = _resolve_unify_axes(
            unify_axes, axis_kwargs, nodes, sorting_variables
        )

        # coerce edges if needed
        if isinstance(edges, np.ndarray):
            edges = Edges(data=edges)

        # auto-detect tags if not provided
        if tags is None:
            tags = edges.tags

        # apply axis_kwargs uniformly across all cells (axis IDs are fixed since
        # partition_variable is shared); inject into hive_plot_kwargs once before the loop
        if axis_kwargs is not None:
            partition_vals = nodes.data[partition_variable].unique()
            hive_plot_kwargs = dict(hive_plot_kwargs or {})
            hive_plot_kwargs["axis_kwargs"] = dict.fromkeys(partition_vals, axis_kwargs)

        # build one HivePlot shared across all cells — per-tag differentiation
        # is handled at render time via _tags_per_cell and per_tag_plot_kwargs
        hp = HivePlot(
            nodes=nodes,
            edges=edges,
            partition_variable=partition_variable,
            sorting_variables=sorting_variables,
            backend=backend,
            repeat_axes=repeat_axes,
            all_edge_kwargs=all_edge_kwargs,
            repeat_edge_kwargs=repeat_edge_kwargs,
            non_repeat_edge_kwargs=non_repeat_edge_kwargs,
            clockwise_edge_kwargs=clockwise_edge_kwargs,
            counterclockwise_edge_kwargs=counterclockwise_edge_kwargs,
            num_steps_per_edge=num_steps_per_edge,
            use_numba=use_numba,
            n_parallel=n_parallel,
            **hive_plot_kwargs,
        )

        hive_plots_1d: List[Optional[HivePlot]] = [hp] * len(tags)
        col_labels = [str(t) for t in tags]
        grid = _wrap_1d_to_2d(hive_plots_1d, ncols)

        # build tags_per_cell mapping and cell_labels for wrapped layouts
        tags_per_cell: Dict[Tuple[int, int], Hashable] = {}
        cell_labels_dict: Optional[Dict[Tuple[int, int], Hashable]] = None
        if ncols is not None:
            cell_labels_dict = {}
        for idx, tag in enumerate(tags):
            if ncols is None:
                r, c = 0, idx
            else:
                r, c = divmod(idx, ncols)
            tags_per_cell[(r, c)] = tag
            if cell_labels_dict is not None:
                cell_labels_dict[(r, c)] = str(tag)

        instance = cls.__new__(cls)
        instance._hive_plots = grid
        instance._row_labels = None
        instance._col_labels = col_labels if ncols is None else None

        instance._matrix_type = "from_tags"
        instance._backend = backend
        instance._tags_per_cell = tags_per_cell
        instance._cell_labels = cell_labels_dict
        instance._per_tag_plot_kwargs = per_tag_plot_kwargs or {}
        instance._node_plot_kwargs = node_kwargs or {}

        return instance

    # ---- Utilities ----

    def copy(self) -> "HivePlotMatrix":
        """
        Return a deep copy of the ``HivePlotMatrix`` instance.

        :return: copy of the ``HivePlotMatrix`` instance.
        """
        return deepcopy(self)

    def __repr__(self) -> str:
        """
        Make printable representation for ``HivePlotMatrix`` instance.
        """
        nrows, ncols = self.shape
        n_populated = sum(1 for _ in self.iter_populated_cells())
        return (
            f"hiveplotlib.HivePlotMatrix ({nrows} x {ncols}), "
            f"{n_populated} populated cells, "
            f"type='{self._matrix_type}', "
            f"backend='{self._backend}'"
        )
