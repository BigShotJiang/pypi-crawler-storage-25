"""
STRATA-SENSE: Input Layer
Converts raw OHLCV candles into semantic signals for STRATA-CORE.

Input:  raw OHLCV window (pandas DataFrame or list of dicts)
Output: {trend, vol, liquidity_above, break_structure}

All outputs are normalised to their expected ranges:
  trend            : [-1.0,  1.0]  (direction + magnitude)
  vol              : [ 0.0,  1.0]  (volatility intensity)
  liquidity_above  : [ 0.0,  1.0]  (volume anomaly flag)
  break_structure  : [ 0.0,  1.0]  (structure break strength)
"""

import math
from typing import Dict, List


def _ema(values: List[float], period: int) -> float:
    """Lightweight EMA on a list of floats (most-recent-last)."""
    if not values:
        return 0.0
    k = 2.0 / (period + 1)
    ema = values[0]
    for v in values[1:]:
        ema = v * k + ema * (1 - k)
    return ema


def _atr(candles: List[Dict], period: int = 14) -> float:
    """Average True Range over last `period` candles."""
    trs = []
    for i in range(1, len(candles)):
        h = candles[i]["high"]
        l = candles[i]["low"]
        pc = candles[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    if not trs:
        return 1e-9
    window = trs[-period:]
    return sum(window) / len(window)


def sense(candles: List[Dict], vol_period: int = 20) -> Dict[str, float]:
    """
    Convert a window of OHLCV candles into STRATA semantic signals.

    Args:
        candles: list of dicts with keys open/high/low/close/volume,
                 ordered oldest → newest. Minimum 3 candles required.
        vol_period: lookback for volume and volatility normalisation.

    Returns:
        {
            "trend":           float [-1, 1],
            "vol":             float [0,  1],
            "liquidity_above": float [0,  1],
            "break_structure": float [0,  1],
        }
    """
    if len(candles) < 3:
        return {"trend": 0.0, "vol": 0.0, "liquidity_above": 0.0, "break_structure": 0.0}

    closes  = [c["close"]  for c in candles]
    highs   = [c["high"]   for c in candles]
    lows    = [c["low"]    for c in candles]
    volumes = [c["volume"] for c in candles]

    # ── TREND ──────────────────────────────────────────────────────────────
    # Fast EMA vs Slow EMA crossover, normalised by ATR
    fast_period = max(3,  len(candles) // 4)
    slow_period = max(6,  len(candles) // 2)
    fast_ema = _ema(closes, fast_period)
    slow_ema = _ema(closes, slow_period)
    atr      = _atr(candles, min(14, len(candles) - 1))
    raw_trend = (fast_ema - slow_ema) / (atr + 1e-9)
    # Soft-clamp via tanh so extreme moves don't saturate
    trend = math.tanh(raw_trend * 0.5)

    # ── VOLATILITY ─────────────────────────────────────────────────────────
    # ATR normalised by recent median close price
    median_close = sorted(closes[-vol_period:])
    median_close = median_close[len(median_close) // 2]
    vol_ratio = atr / (median_close + 1e-9)
    vol = min(1.0, vol_ratio * 50.0)   # v2: raised from 20 → 50; large-cap stocks have small ATR/price

    # ── LIQUIDITY ABOVE ────────────────────────────────────────────────────
    # Current volume vs rolling average — spike = liquidity event
    vol_window = volumes[-vol_period:]
    avg_volume = sum(vol_window) / len(vol_window) if vol_window else 1.0
    current_vol = volumes[-1]
    liq_ratio = current_vol / (avg_volume + 1e-9)
    liquidity_above = min(1.0, max(0.0, (liq_ratio - 1.0) / 2.0))

    # ── STRUCTURE BREAK ────────────────────────────────────────────────────
    # Price closes beyond the highest high / lowest low of prior N candles
    lookback   = min(20, len(candles) - 1)
    prior_high = max(highs[-lookback - 1:-1])
    prior_low  = min(lows[-lookback - 1:-1])
    last_close = closes[-1]

    if last_close > prior_high:
        break_mag = (last_close - prior_high) / (atr + 1e-9)
        break_structure = min(1.0, break_mag * 0.3)
    elif last_close < prior_low:
        break_mag = (prior_low - last_close) / (atr + 1e-9)
        break_structure = min(1.0, break_mag * 0.3)
    else:
        break_structure = 0.0

    return {
        "trend":           round(trend, 6),
        "vol":             round(vol, 6),
        "liquidity_above": round(liquidity_above, 6),
        "break_structure": round(break_structure, 6),
    }
