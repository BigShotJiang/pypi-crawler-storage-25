"""
STRATA-DECIDE: Decision Engine
Converts current state + confidence into a structured action output.
Output is NOT a prediction — it is an actionable decision.
"""

from typing import Dict
from .core import compute_confidence, classify_regime


def decide(
    state: Dict[str, float],
    weights: Dict[str, float] = None,
) -> Dict:
    """
    Produce a decision dict from current state.

    Returns:
        {
            "action":     "LONG" | "SHORT" | "HOLD",
            "confidence": float (0..1),
            "risk":       "LOW" | "MEDIUM" | "HIGH",
            "regime":     str,
        }
    """
    confidence = compute_confidence(state, weights)
    regime     = classify_regime(state)
    bias       = state["bias"]
    trap_risk  = state["trap_risk"]

    # Action: direction driven by bias, gated by confidence
    if confidence < 0.45:
        action = "HOLD"
    elif bias > 0.15:
        action = "LONG"
    elif bias < -0.15:
        action = "SHORT"
    else:
        action = "HOLD"

    # Risk classification
    if trap_risk > 0.55 or state["uncertainty"] > 0.60:
        risk = "HIGH"
    elif trap_risk > 0.30 or state["uncertainty"] > 0.35:
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return {
        "action":     action,
        "confidence": round(confidence, 4),
        "risk":       risk,
        "regime":     regime,
    }
