"""
STRATA — Market State Framework
================================
Structured Trading Reasoning Architecture

A layered, stateful framework for market regime estimation and
decision support. STRATA does not predict prices; it maintains
a continuous internal state representing current market conditions
and produces auditable action recommendations gated by hard risk rules.

Public API
----------
sense(candles)                  OHLCV window → semantic signals
initial_state()                 zeroed state vector
update_state(state, inp, mem)   core state transition F(S, I, M) → S'
compute_confidence(state)       scalar confidence from current state
classify_regime(state)          TRENDING | RANGING | TRANSITIONING | CHOPPY
decide(state)                   state → {action, confidence, risk, regime}
StrataGUARD(asset=None)         hard-rule risk gate (regime + asset aware)
StrataMEMORY()                  3-layer pattern memory (Short/Mid/Long)
StrataLOOP()                    closed-loop weight adaptation via P&L feedback

See README.md for usage examples.
See MANIFESTO.md for architecture and design principles.
"""

__version__ = "2.3.0"   # V2 weights + V3 guard (asset profile) + V3 core (downside_pressure)

from .core   import initial_state, update_state, compute_confidence, classify_regime
from .memory import StrataMEMORY
from .guard  import StrataGUARD
from .decide import decide
from .sense  import sense
from .loop   import StrataLOOP

__all__ = [
    # Core state engine
    "initial_state",
    "update_state",
    "compute_confidence",
    "classify_regime",
    # Layers
    "sense",
    "StrataMEMORY",
    "decide",
    "StrataGUARD",
    "StrataLOOP",
    # Meta
    "__version__",
]
