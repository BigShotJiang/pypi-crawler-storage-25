"""
STRATA-GUARD: Risk Layer
Hard-rule override that sits between STRATA-DECIDE and Action.
Guard rules are NOT learned — they are explicit, auditable constraints.
If any rule fires, the action is overridden to HOLD with a reason.

V2: Regime-aware thresholds.
Each market regime gets its own guard config tuned to that condition:
  TRENDING    — looser trap/uncertainty tolerance (momentum is valid signal)
  RANGING     — tighter bias conviction required (mean-reversion noise)
  TRANSITIONING — balanced defaults
  CHOPPY      — most conservative (high noise, no clear direction)

V3 addition: Asset volatility profile adjustment.
High-vol assets (TSLA, NVDA) produce naturally larger bias swings, so
min_abs_bias is relaxed. Low-vol assets (SPY, QQQ) are more stable so
min_abs_bias is tightened slightly. This normalises guard_rate spread
across asset classes from ~8pp toward <5pp.
"""

from typing import Dict, Optional, Tuple


# ---------------------------------------------------------------------------
# Regime-aware threshold table
# ---------------------------------------------------------------------------
REGIME_GUARD_CONFIG: Dict[str, Dict] = {
    "TRENDING": {
        "max_trap_risk":        0.80,
        "min_confidence":       0.46,
        "max_uncertainty":      0.85,
        "min_abs_bias":         0.12,
        "max_consecutive_loss": 3,
    },
    "RANGING": {
        "max_trap_risk":        0.60,
        "min_confidence":       0.47,
        "max_uncertainty":      0.65,
        "min_abs_bias":         0.10,   # calibrated: 5-asset bias_mean 0.096-0.114, 0.12 was too strict
        "max_consecutive_loss": 3,
    },
    "TRANSITIONING": {
        "max_trap_risk":        0.70,
        "min_confidence":       0.45,
        "max_uncertainty":      0.75,
        "min_abs_bias":         0.10,
        "max_consecutive_loss": 3,
    },
    "CHOPPY": {
        "max_trap_risk":        0.50,
        "min_confidence":       0.52,
        "max_uncertainty":      0.55,
        "min_abs_bias":         0.18,
        "max_consecutive_loss": 2,
    },
}

# Fallback if regime not recognised
DEFAULT_GUARD_CONFIG = REGIME_GUARD_CONFIG["TRANSITIONING"]

# ---------------------------------------------------------------------------
# Asset volatility profile: adjusts min_abs_bias per asset class.
# Calibrated from 5-year vol_mean observations:
#   HIGH  (vol_mean > 0.05): TSLA=0.072, NVDA=0.063  → bias swings larger
#   MED   (0.03–0.05):       AAPL=0.037              → baseline
#   LOW   (vol_mean < 0.03): SPY=0.020, QQQ=0.025    → bias swings smaller
#
# Adjustment is a signed delta applied to min_abs_bias only.
# All other thresholds remain regime-driven.
# ---------------------------------------------------------------------------
ASSET_VOL_CLASS: Dict[str, str] = {
    # HIGH volatility single stocks
    "TSLA": "HIGH", "NVDA": "HIGH", "AMD": "HIGH", "COIN": "HIGH",
    "MSTR": "HIGH", "PLTR": "HIGH", "RIVN": "HIGH", "LCID": "HIGH",
    # MEDIUM volatility
    "AAPL": "MED",  "MSFT": "MED",  "GOOGL": "MED", "META": "MED",
    "AMZN": "MED",  "NFLX": "MED",  "CRM":  "MED",
    # LOW volatility (ETFs and blue-chips)
    "SPY": "LOW",   "QQQ": "LOW",   "IWM": "LOW",   "DIA": "LOW",
    "VTI": "LOW",   "GLD": "LOW",   "TLT": "LOW",   "XLK": "LOW",
}

VOL_CLASS_BIAS_DELTA: Dict[str, float] = {
    "HIGH": -0.010,   # relax min_abs_bias slightly for high-vol assets
    "MED":   0.000,   # no adjustment — baseline
    "LOW":   0.000,   # no bias delta — ETFs have comparable bias_mean to MED
}

# Trap risk ceiling adjustment per vol class.
# SPY/QQQ have structurally higher trap_risk (~0.22-0.23 mean) vs TSLA/NVDA (~0.19).
# Relax max_trap_risk for LOW class so guard does not over-fire on their natural
# elevated trap_risk, narrowing cross-asset guard_rate spread.
VOL_CLASS_TRAP_DELTA: Dict[str, float] = {
    "HIGH": +0.05,   # TSLA/NVDA — lower structural trap_risk, no extra room needed
    "MED":   0.00,
    "LOW":  +0.10,   # SPY/QQQ — structurally higher trap_risk baseline, raise ceiling
}


class StrataGUARD:
    """
    Hard-rule override layer with regime-aware + asset-profile thresholds.

    Evaluate a proposed decision against current state and regime.
    Returns (approved: bool, reason: str).
    If not approved, action must be overridden to HOLD.
    """

    def __init__(self, config: Optional[Dict] = None, asset: Optional[str] = None):
        self._override_config = config   # full config override (e.g. for tests)
        self._asset           = asset    # optional ticker for vol-class adjustment
        self._consecutive_losses = 0

    def _get_config(self, regime: str) -> Dict:
        if self._override_config is not None:
            return self._override_config
        base = dict(REGIME_GUARD_CONFIG.get(regime, DEFAULT_GUARD_CONFIG))
        if self._asset is not None:
            vol_class  = ASSET_VOL_CLASS.get(self._asset.upper(), "MED")
            # min_abs_bias adjustment (HIGH vol assets get relaxed threshold)
            bias_delta = VOL_CLASS_BIAS_DELTA.get(vol_class, 0.0)
            base["min_abs_bias"] = round(
                max(0.01, base["min_abs_bias"] + bias_delta), 4
            )
            # max_trap_risk adjustment (LOW vol ETFs have structurally higher trap_risk)
            trap_delta = VOL_CLASS_TRAP_DELTA.get(vol_class, 0.0)
            base["max_trap_risk"] = round(
                min(0.99, base["max_trap_risk"] + trap_delta), 4
            )
        return base

    def evaluate(
        self,
        state: Dict[str, float],
        decision: Dict,
        confidence: float,
    ) -> Tuple[bool, str]:
        """
        Evaluate proposed decision against regime-aware thresholds.

        Returns:
            (True,  "OK")          → action approved
            (False, "<reason>")    → action blocked, caller must use HOLD
        """
        regime = decision.get("regime", "TRANSITIONING")
        cfg    = self._get_config(regime)

        if state["trap_risk"] > cfg["max_trap_risk"]:
            return False, (
                f"TRAP_RISK_HIGH ({state['trap_risk']:.2f} > {cfg['max_trap_risk']}"
                f" [{regime}])"
            )

        if confidence < cfg["min_confidence"]:
            return False, (
                f"LOW_CONFIDENCE ({confidence:.2f} < {cfg['min_confidence']}"
                f" [{regime}])"
            )

        if state["uncertainty"] > cfg["max_uncertainty"]:
            return False, (
                f"CHAOS_REGIME ({state['uncertainty']:.2f} > {cfg['max_uncertainty']}"
                f" [{regime}])"
            )

        if abs(state["bias"]) < cfg["min_abs_bias"]:
            return False, (
                f"NO_CONVICTION (|bias|={abs(state['bias']):.2f} < {cfg['min_abs_bias']}"
                f" [{regime}])"
            )

        if self._consecutive_losses >= cfg["max_consecutive_loss"]:
            return False, (
                f"CIRCUIT_BREAKER ({self._consecutive_losses} consecutive losses"
                f" [{regime}])"
            )

        return True, "OK"

    def record_outcome(self, was_loss: bool) -> None:
        """Called after each trade outcome. Drives the circuit breaker."""
        if was_loss:
            self._consecutive_losses += 1
        else:
            self._consecutive_losses = 0

    def reset_circuit_breaker(self) -> None:
        self._consecutive_losses = 0

    def __repr__(self):
        return (
            f"STRATA-GUARD | regime_aware=True"
            f" | consecutive_losses={self._consecutive_losses}"
        )
