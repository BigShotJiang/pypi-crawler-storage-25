from caltech_change_form.caf import main

if __name__ == "__main__":
    main()
