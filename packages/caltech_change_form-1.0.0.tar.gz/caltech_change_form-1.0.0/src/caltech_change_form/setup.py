#!/usr/bin/env python3
"""
setup.py — Run this once to save your info and draw your signature.
Your profile is saved to ~/.caltech_profile.json
"""

import json
import os
import sys
import tkinter as tk
from PIL import Image, ImageDraw

PROFILE_PATH = os.path.expanduser("~/.caltech_profile.json")
SIG_PATH = os.path.expanduser("~/.caltech_signature.png")


def draw_signature():
    """Open a canvas for the user to draw their signature."""
    print("\nA window will open — draw your signature with your mouse, then click Save.")
    input("Press Enter to open the signature window...")

    root = tk.Tk()
    root.title("Draw Your Signature")
    root.resizable(False, False)

    canvas_w, canvas_h = 500, 150
    canvas = tk.Canvas(root, width=canvas_w, height=canvas_h, bg="white", cursor="crosshair")
    canvas.pack(pady=10, padx=10)

    # PIL image to capture drawing
    img = Image.new("RGBA", (canvas_w, canvas_h), "white")
    draw = ImageDraw.Draw(img)

    prev = {"x": None, "y": None}
    saved = {"done": False}

    def on_press(event):
        prev["x"] = event.x
        prev["y"] = event.y

    def on_drag(event):
        x, y = event.x, event.y
        if prev["x"] is not None:
            canvas.create_line(prev["x"], prev["y"], x, y, fill="black", width=2, smooth=True)
            draw.line([prev["x"], prev["y"], x, y], fill="black", width=2)
        prev["x"] = x
        prev["y"] = y

    def on_release(event):
        prev["x"] = None
        prev["y"] = None

    def clear():
        canvas.delete("all")
        draw.rectangle([0, 0, canvas_w, canvas_h], fill="white")

    def save():
        img.save(SIG_PATH)
        saved["done"] = True
        root.destroy()

    canvas.bind("<ButtonPress-1>", on_press)
    canvas.bind("<B1-Motion>", on_drag)
    canvas.bind("<ButtonRelease-1>", on_release)

    btn_frame = tk.Frame(root)
    btn_frame.pack(pady=5)
    tk.Button(btn_frame, text="Clear", command=clear, width=10).pack(side=tk.LEFT, padx=5)
    tk.Button(btn_frame, text="Save Signature", command=save, width=15, bg="#4CAF50", fg="white").pack(side=tk.LEFT, padx=5)

    tk.Label(root, text="Draw your signature above, then click Save.", fg="gray").pack()
    root.mainloop()

    return saved["done"]


def run_setup():
    print("=" * 50)
    print("  Caltech Add Form — First-Time Setup")
    print("=" * 50)
    print("Your info will be saved and auto-filled every time.\n")

    # Load existing profile if it exists (for re-setup)
    existing = {}
    if os.path.exists(PROFILE_PATH):
        with open(PROFILE_PATH) as f:
            existing = json.load(f)
        print("Found existing profile. Press Enter to keep current value.\n")

    def ask(prompt, key):
        current = existing.get(key, "")
        hint = f" [{current}]" if current else ""
        val = input(f"{prompt}{hint}: ").strip()
        return val if val else current

    profile = {
        "name":         ask("Full Name", "name"),
        "uid":          ask("UID", "uid"),
        "year_of_study": ask("Year of Study (e.g. 3)", "year_of_study"),
        "option":       ask("Option/Major (e.g. CS)", "option"),
        "advisor":      ask("Advisor Name", "advisor"),
        "email":        ask("Caltech Email", "email"),
        "phone":        ask("Phone Number", "phone"),
    }

    # Validate
    for k, v in profile.items():
        if not v:
            print(f"\n  ✗ '{k}' cannot be empty. Please re-run setup.")
            sys.exit(1)

    # Signature
    sig_exists = os.path.exists(SIG_PATH)
    if sig_exists:
        redo = input("\nSignature already exists. Redraw it? (y/N): ").strip().lower()
        if redo == "y":
            sig_exists = False

    if not sig_exists:
        ok = draw_signature()
        if not ok:
            print("Signature not saved. Re-run setup to add it.")
            sys.exit(1)
        print(f"  ✓ Signature saved to {SIG_PATH}")
    else:
        print(f"  ✓ Using existing signature at {SIG_PATH}")

    profile["signature_path"] = SIG_PATH

    with open(PROFILE_PATH, "w") as f:
        json.dump(profile, f, indent=2)

    print(f"\n  ✓ Profile saved to {PROFILE_PATH}")
    print("\nSetup complete! You can now run: python add_form.py")


if __name__ == "__main__":
    run_setup()
