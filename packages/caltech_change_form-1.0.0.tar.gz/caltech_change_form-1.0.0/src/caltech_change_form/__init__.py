"""Caltech Change Form — conversational assistant for the Caltech Registration / Course Change Form."""

__version__ = "1.0.0"
