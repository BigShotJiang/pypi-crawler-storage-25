#!/usr/bin/env python3
"""
caf.py — Caltech Add Form, conversational AI assistant.

First time:
  python caf.py --setup
  python caf.py --scrape

Every time after:
  python caf.py
"""

import argparse
import json
import os
import sys
from datetime import date

try:
    import anthropic
except ImportError:
    print("✗ Missing dependency. Run: pip install caltech-change-form")
    sys.exit(1)

PROFILE_PATH = os.path.expanduser("~/.caltech_profile.json")
DB_PATH = os.path.join(os.path.dirname(__file__), "courses.json")
FORM_DIR = os.path.expanduser("~/Desktop")
FORM_PDF = os.path.join(os.path.dirname(__file__), "Course_Registration_Form.pdf")

SYSTEM_PROMPT = """You are a friendly assistant that helps Caltech students fill out their Registration / Course Change Form.

You have access to the student's profile and a course database (provided below).
Your job is to have a natural conversation, figure out what changes they want to make, confirm with them, ask for total units, then output a JSON summary.

## The form supports these action codes:
- A  = Adding a course
- D  = Dropping a course
- U  = Unit Change
- S  = Section Change (ask for new section number)
- P/F = Change to Pass/Fail grading
- G  = Change from Pass/Fail to Letter Grade

## Term format:
Current term options: FA (Fall), WI (Winter), SP (Spring), SU (Summer) + year. e.g. "SP 2026"
If the student doesn't specify a term, assume the current/upcoming term based on today's date ({today}).

## Your flow:
1. Greet them by first name, ask what they need.
2. Understand their request naturally ("I want to add CS 1 and drop Ma 1a").
3. Map each request to an action code + course + term + section (if S) + units (if A or U).
   - For units: check the course database first. If found, suggest it. If not found, ask.
   - For section changes: always ask what the new section number is.
4. Show a clean confirmation list and ask if it looks right.
5. Ask for total units they'll be enrolled in AFTER all changes.
6. Once confirmed, output ONLY a JSON block (nothing else after it) in this exact format:

```json
{{
  "confirmed": true,
  "total_units": "45",
  "actions": [
    {{"action_code": "A", "term_year": "SP 2026", "course": "CS 1", "section": "01", "units": "9"}},
    {{"action_code": "D", "term_year": "SP 2026", "course": "Ma 1a", "section": "", "units": ""}}
  ]
}}
```

## Rules:
- Be concise and friendly. Don't be robotic.
- If something is ambiguous (which term? which section?) just ask.
- Never make up course codes. Only use codes from the database or exactly as the student typed.
- If you don't recognize a course, proceed with what the student said and note units are unknown.
- Once you output the JSON block, stop. Don't add anything after it.

## Student profile:
{profile}

## Course database (code → units):
{course_db}
"""


def load_profile():
    if not os.path.exists(PROFILE_PATH):
        print("\n✗ No profile found. Run setup first:")
        print("    python caf.py --setup\n")
        sys.exit(1)
    with open(PROFILE_PATH) as f:
        return json.load(f)


def load_course_db():
    if not os.path.exists(DB_PATH):
        return {}
    with open(DB_PATH) as f:
        courses = json.load(f)
    return {c["code"]: c.get("units", "") for c in courses}


def build_system_prompt(profile, course_db):
    # Compact course db for context window efficiency
    db_lines = [f"{code}: {units} units" for code, units in list(course_db.items())[:300]]
    db_str = "\n".join(db_lines) if db_lines else "(not available — ask user for units)"

    profile_str = (
        f"Name: {profile['name']}\n"
        f"UID: {profile['uid']}\n"
        f"Year: {profile['year_of_study']}\n"
        f"Option: {profile['option']}\n"
        f"Advisor: {profile['advisor']}\n"
        f"Email: {profile['email']}\n"
        f"Phone: {profile['phone']}"
    )

    today = date.today().strftime("%B %Y")
    return SYSTEM_PROMPT.format(profile=profile_str, course_db=db_str, today=today)


def extract_json(text):
    """Pull JSON block out of the assistant's response."""
    import re
    m = re.search(r'```json\s*(\{.*?\})\s*```', text, re.DOTALL)
    if m:
        return json.loads(m.group(1))
    # Try raw JSON
    m = re.search(r'\{.*"confirmed".*\}', text, re.DOTALL)
    if m:
        return json.loads(m.group(0))
    return None


def generate_form(profile, result, output_path):
    from caltech_change_form.fill_form import fill_form
    fill_form(profile, result["actions"], result["total_units"], output_path)


def chat(profile, course_db):
    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
    system = build_system_prompt(profile, course_db)
    history = []

    first_name = profile["name"].split()[0]
    print(f"\n  Hi {first_name}! Type your request, or 'quit' to exit.")
    print(f"  (e.g. 'I want to add CS 1 and drop Ma 1a for spring')\n")

    while True:
        try:
            user_input = input("  You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Bye!")
            sys.exit(0)

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "bye"):
            print("  Bye!")
            sys.exit(0)

        history.append({"role": "user", "content": user_input})

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            system=system,
            messages=history,
        )

        reply = response.content[0].text
        history.append({"role": "assistant", "content": reply})

        # Check if the assistant has finalized
        result = extract_json(reply)
        if result and result.get("confirmed"):
            # Print the reply up to the JSON block
            display = reply.split("```json")[0].strip()
            if display:
                print(f"\n  Assistant: {display}\n")

            # Generate the PDF
            today_str = date.today().strftime("%Y-%m-%d")
            os.makedirs(FORM_DIR, exist_ok=True)
            output_path = os.path.join(FORM_DIR, f"Caltech_Registration_Form_{today_str}.pdf")
            counter = 1
            base = output_path
            while os.path.exists(output_path):
                output_path = base.replace(".pdf", f"_{counter}.pdf")
                counter += 1

            print("  Generating your form...", end=" ", flush=True)
            try:
                generate_form(profile, result, output_path)
                print(f"done!\n")
                print(f"  ✓ Saved to: {output_path}")
                print(f"  Next: collect instructor + advisor signatures, then email to regis@caltech.edu\n")
            except Exception as e:
                print(f"\n  ✗ Error generating form: {e}")
            break
        else:
            # Strip JSON from display if partially present
            display = reply.split("```json")[0].strip()
            print(f"\n  Assistant: {display}\n")


def main():
    parser = argparse.ArgumentParser(description="Caltech Add Form Assistant")
    parser.add_argument("--setup", action="store_true", help="Run first-time setup")
    parser.add_argument("--scrape", action="store_true", help="Scrape course catalog")
    args = parser.parse_args()

    if args.setup:
        from caltech_change_form.setup import run_setup
        run_setup()
        return

    if args.scrape:
        from caltech_change_form.scrape import scrape_catalog
        scrape_catalog()
        return

    # Check for API key
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("\n✗ ANTHROPIC_API_KEY not set.")
        print("  Get a free key at https://console.anthropic.com")
        print("  Then run: export ANTHROPIC_API_KEY=your-key-here\n")
        sys.exit(1)

    profile = load_profile()
    course_db = load_course_db()

    print("=" * 50)
    print("  Caltech Add Form Assistant")
    print("=" * 50)

    chat(profile, course_db)


if __name__ == "__main__":
    main()
