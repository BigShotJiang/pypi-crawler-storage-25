#!/usr/bin/env python3
"""
scrape.py — Scrapes Caltech's course catalog and saves to courses.json.
Usage: python scrape.py
"""

import json
import os
import re
import time
import urllib.request
import urllib.error
from html.parser import HTMLParser

CATALOG_URL = "https://catalog.caltech.edu/current/2025-26/"
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "courses.json")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; CaltechFormBot/1.0)"
}


def fetch(url):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.read().decode("utf-8", errors="replace")


class LinkParser(HTMLParser):
    """Finds all <a href=...> links on a page."""
    def __init__(self, base):
        super().__init__()
        self.base = base
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            attrs_dict = dict(attrs)
            href = attrs_dict.get("href", "")
            if href and not href.startswith("#") and not href.startswith("mailto"):
                if href.startswith("/"):
                    href = "https://catalog.caltech.edu" + href
                elif not href.startswith("http"):
                    href = self.base.rstrip("/") + "/" + href
                self.links.append(href)


class CourseParser(HTMLParser):
    """Extracts course codes, names, and units from a catalog page."""
    def __init__(self):
        super().__init__()
        self.courses = []
        self._in_course = False
        self._buffer = ""
        self._capture = False

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)
        cls = attrs_dict.get("class", "")
        # Common Caltech catalog course entry class names
        if tag in ("div", "p", "h3", "h4", "td") and any(
            kw in cls for kw in ("course", "courseblocktitle", "courseblock", "sc_courselist")
        ):
            self._capture = True
            self._buffer = ""

    def handle_endtag(self, tag):
        if self._capture and tag in ("div", "p", "h3", "h4", "td"):
            text = re.sub(r"\s+", " ", self._buffer).strip()
            if text:
                self._parse_course_text(text)
            self._capture = False
            self._buffer = ""

    def handle_data(self, data):
        if self._capture:
            self._buffer += data

    def _parse_course_text(self, text):
        # Match patterns like: "CS 1" or "Ma 001A" or "Ph 1 a" with optional unit info
        # Pattern: department code + number + optional letter, then title, then units
        pattern = r'\b([A-Z][a-zA-Z]{0,3})\s+(\d{1,4}[a-zA-Z]?(?:\s+[a-z])?)\b'
        m = re.search(pattern, text)
        if m:
            dept = m.group(1)
            num = m.group(2).strip()
            code = f"{dept} {num}"

            # Extract units — look for patterns like "(9 units)" or "9-0-0" or "units: 9"
            units_match = re.search(
                r'(\d+)(?:\s*-\s*\d+\s*-\s*\d+)?\s*units?', text, re.IGNORECASE
            )
            units = units_match.group(1) if units_match else ""

            # Title: everything after the course code up to the units or end
            title_start = m.end()
            title_text = text[title_start:].strip().lstrip(".—-– ").strip()
            # Cut off at units or parenthetical
            title_text = re.split(r'\s*[\(\[]|\s*\d+\s*unit', title_text)[0].strip()
            title_text = title_text[:80]  # cap length

            if len(code) <= 12 and title_text:
                self.courses.append({
                    "code": code,
                    "title": title_text,
                    "units": units
                })


def get_department_links(catalog_html):
    """Find links to individual department / subject pages."""
    parser = LinkParser(CATALOG_URL)
    parser.feed(catalog_html)

    dept_links = []
    for link in parser.links:
        # Department pages are typically like /current/2025-26/academics/... 
        # or contain subject listings
        if "catalog.caltech.edu" in link and "2025-26" in link:
            if any(kw in link for kw in [
                "courses", "subject", "department", "option", "academics",
                "chemistry", "physics", "math", "biology", "engineering",
                "humanities", "social", "computing"
            ]):
                dept_links.append(link)

    return list(dict.fromkeys(dept_links))  # deduplicate preserving order


def scrape_page_for_courses(url):
    """Scrape a single page for course listings."""
    try:
        html = fetch(url)
        parser = CourseParser()
        parser.feed(html)
        return parser.courses
    except Exception as e:
        print(f"    ✗ Failed: {e}")
        return []


def scrape_catalog():
    print("=" * 55)
    print("  Caltech Course Catalog Scraper")
    print("=" * 55)
    print(f"Fetching catalog index: {CATALOG_URL}\n")

    try:
        index_html = fetch(CATALOG_URL)
    except Exception as e:
        print(f"✗ Could not reach catalog: {e}")
        print("  Check your internet connection and try again.")
        return

    dept_links = get_department_links(index_html)
    print(f"Found {len(dept_links)} department/subject pages to scan.\n")

    all_courses = {}
    for i, url in enumerate(dept_links):
        label = url.split("/")[-2] or url.split("/")[-1]
        print(f"  [{i+1}/{len(dept_links)}] {label} ...", end=" ", flush=True)
        courses = scrape_page_for_courses(url)
        added = 0
        for c in courses:
            if c["code"] not in all_courses:
                all_courses[c["code"]] = c
                added += 1
        print(f"{added} courses found")
        time.sleep(0.3)  # be polite

    # Also scrape main index page
    print(f"\n  Scanning main index page...")
    main_courses = scrape_page_for_courses(CATALOG_URL)
    for c in main_courses:
        if c["code"] not in all_courses:
            all_courses[c["code"]] = c

    courses_list = sorted(all_courses.values(), key=lambda x: x["code"])

    with open(DB_PATH, "w") as f:
        json.dump(courses_list, f, indent=2)

    print(f"\n✓ Saved {len(courses_list)} courses to {DB_PATH}")
    print("\nTip: Re-run scrape.py each term to refresh the course list.")


def lookup_course(code):
    """Look up a course by code (e.g. 'CS 1' or 'Ma 001A')."""
    if not os.path.exists(DB_PATH):
        return None
    with open(DB_PATH) as f:
        courses = json.load(f)
    code_upper = code.upper().strip()
    for c in courses:
        if c["code"].upper().replace(" ", "") == code_upper.replace(" ", ""):
            return c
    return None


if __name__ == "__main__":
    scrape_catalog()
