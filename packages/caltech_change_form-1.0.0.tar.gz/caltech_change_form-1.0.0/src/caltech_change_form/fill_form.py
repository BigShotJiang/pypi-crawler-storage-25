#!/usr/bin/env python3
"""
fill_form.py — Core logic for filling the Caltech Registration/Course Change Form.
Used by add_form.py; not meant to be run directly.
"""

import json
import os
from datetime import date
from PIL import Image
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.lib.pagesizes import letter
from pypdf import PdfReader, PdfWriter
import io

# PDF page dimensions (from form analysis)
PDF_W = 612.0
PDF_H = 792.0

# Field coordinates (PDF coordinate space, y=0 at TOP of page)
# Converted from structure extraction results
FIELDS = {
    # Header row 1: Name, UID
    "name":     {"x": 68, "y": 102.4, "w": 235, "h": 10, "font": 9},
    "uid":      {"x": 334, "y": 102.4, "w": 240, "h": 10, "font": 9},
    # Header row 2: Year of Study, Option, Advisor
    "year":     {"x": 102, "y": 125.9, "w": 110, "h": 10, "font": 9},
    "option":   {"x": 255, "y": 125.9, "w": 140, "h": 10, "font": 9},
    "advisor":  {"x": 442, "y": 125.9, "w": 130, "h": 10, "font": 9},
    # Header row 3: Email, Phone
    "email":    {"x": 103, "y": 149.4, "w": 200, "h": 10, "font": 9},
    "phone":    {"x": 384, "y": 149.4, "w": 190, "h": 10, "font": 9},
    # Total units at bottom of table
    "total_units": {"x": 430, "y": 589.4, "w": 140, "h": 10, "font": 9},
    # Student signature (image overlay) and date
    "student_sig_date": {"x": 180, "y": 634.0, "w": 80, "h": 9, "font": 9},
}

# Table rows: 10 data rows starting after header at y=347.8
# Each row is ~24.2px tall
TABLE_FIRST_ROW_Y = 357.0
TABLE_ROW_H = 23.2
TABLE_COLS = {
    "action_code":   {"x": 36,  "w": 42},
    "term_year":     {"x": 79,  "w": 78},
    "course":        {"x": 157, "w": 130},
    "section":       {"x": 287, "w": 50},
    "units":         {"x": 337, "w": 35},
    # instructor sig col is x=373 but we leave blank
}
NUM_TABLE_ROWS = 10

FORM_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Course_Registration_Form.pdf")


def _pdf_y(top_y):
    """Convert top-of-page y (our coord) to PDF bottom-of-page y (reportlab coord)."""
    return PDF_H - top_y


def fill_form(profile: dict, actions: list, total_units: str, output_path: str):
    """
    Fill the form PDF and save to output_path.

    profile: dict with keys name, uid, year_of_study, option, advisor, email, phone, signature_path
    actions: list of dicts with keys action_code, term_year, course, section, units
    total_units: string total unit count
    output_path: where to save the filled PDF
    """
    # Create overlay PDF with reportlab
    packet = io.BytesIO()
    c = rl_canvas.Canvas(packet, pagesize=letter)
    c.setFont("Helvetica", 9)

    def write(x, top_y, text, font_size=9):
        c.setFont("Helvetica", font_size)
        # Baseline is ~2px above bottom of field area
        c.drawString(x, _pdf_y(top_y + 2), str(text))

    # --- Header fields ---
    write(FIELDS["name"]["x"],   FIELDS["name"]["y"],   profile.get("name", ""))
    write(FIELDS["uid"]["x"],    FIELDS["uid"]["y"],    profile.get("uid", ""))
    write(FIELDS["year"]["x"],   FIELDS["year"]["y"],   profile.get("year_of_study", ""))
    write(FIELDS["option"]["x"], FIELDS["option"]["y"], profile.get("option", ""))
    write(FIELDS["advisor"]["x"],FIELDS["advisor"]["y"],profile.get("advisor", ""))
    write(FIELDS["email"]["x"],  FIELDS["email"]["y"],  profile.get("email", ""))
    write(FIELDS["phone"]["x"],  FIELDS["phone"]["y"],  profile.get("phone", ""))

    # --- Table rows ---
    for i, action in enumerate(actions[:NUM_TABLE_ROWS]):
        row_y = TABLE_FIRST_ROW_Y + i * TABLE_ROW_H
        for col, spec in TABLE_COLS.items():
            val = action.get(col, "")
            if val:
                write(spec["x"] + 2, row_y, str(val))

    # --- Total units ---
    write(FIELDS["total_units"]["x"], FIELDS["total_units"]["y"], total_units)

    # --- Date on student signature line ---
    today = date.today().strftime("%m/%d/%Y")
    write(FIELDS["student_sig_date"]["x"], FIELDS["student_sig_date"]["y"], today)

    c.save()
    packet.seek(0)

    # Merge overlay onto original PDF
    original = PdfReader(FORM_PATH)
    overlay_pdf = PdfReader(packet)
    writer = PdfWriter()

    page = original.pages[0]
    page.merge_page(overlay_pdf.pages[0])
    writer.add_page(page)

    # Stamp signature image if available
    sig_path = profile.get("signature_path", "")
    if sig_path and os.path.exists(sig_path):
        _stamp_signature(writer, sig_path)

    with open(output_path, "wb") as out:
        writer.write(out)


def _stamp_signature(writer: PdfWriter, sig_path: str):
    """Stamp the signature image onto the student signature line."""
    try:
        from reportlab.lib.utils import ImageReader

        sig_img = Image.open(sig_path).convert("RGBA")

        # Trim whitespace
        bbox = sig_img.getbbox()
        if bbox:
            sig_img = sig_img.crop(bbox)

        # Target: fit in ~170px wide, ~25px tall area on signature line
        target_w = 160
        target_h = 28
        sig_img.thumbnail((target_w, target_h), Image.LANCZOS)

        sig_io = io.BytesIO()
        sig_img.save(sig_io, format="PNG")
        sig_io.seek(0)

        # New overlay just for signature
        packet2 = io.BytesIO()
        c = rl_canvas.Canvas(packet2, pagesize=letter)

        # Signature line is at top_y=634, x starts at 36
        sig_x = 36
        sig_top_y = 621  # slightly above the line
        sig_w = sig_img.width
        sig_h = sig_img.height
        c.drawImage(
            ImageReader(sig_io),
            sig_x, _pdf_y(sig_top_y + sig_h),
            width=sig_w, height=sig_h,
            mask="auto"
        )
        c.save()
        packet2.seek(0)

        sig_overlay = PdfReader(packet2)
        # The writer already has one page — merge sig overlay onto it
        existing_page = writer.pages[0]
        existing_page.merge_page(sig_overlay.pages[0])

    except Exception as e:
        print(f"  ⚠ Could not stamp signature: {e}")
