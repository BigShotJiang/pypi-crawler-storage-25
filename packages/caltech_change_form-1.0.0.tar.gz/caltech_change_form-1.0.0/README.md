# caltech-change-form

A conversational AI assistant that auto-fills the Caltech Registration / Course Change Form.

## Install

```bash
pip install caltech-change-form
```

## Setup (one time only)

**1. Get a free Anthropic API key** at [console.anthropic.com](https://console.anthropic.com), then:

```bash
export ANTHROPIC_API_KEY=your-key-here
```

Add that line to your `~/.zshrc` or `~/.bashrc` to make it permanent.

**2. Save your info and draw your signature:**
```bash
ccf --setup
```

**3. Scrape the course catalog (once per term):**
```bash
ccf --scrape
```

## Usage

Every time you need a form, just run:

```bash
ccf
```

Then talk to it naturally:

```
  You: I want to add CS 1 and drop Ma 1a for spring
  Assistant: Got it! Just to confirm:
    ✓ Add  CS 1  — SP 2026  (9 units)
    ✓ Drop Ma 1a — SP 2026
  Does that look right?

  You: yes, and also change Ph 1a to pass/fail
  Assistant: Added! Updated list:
    ✓ Add   CS 1  — SP 2026  (9 units)
    ✓ Drop  Ma 1a — SP 2026
    ✓ P/F   Ph 1a — SP 2026
  How many total units will you have after these changes?

  You: 42
  Generating your form... done!
  ✓ Saved to ~/Desktop/Caltech_Registration_Form_2026-04-01.pdf
```

The filled PDF saves to your Desktop. Collect instructor + advisor signatures, then email to **regis@caltech.edu** or bring to CSS 125.

## Supported actions

| Say...               | Form action              |
|----------------------|--------------------------|
| add a class          | A – Add                  |
| drop a class         | D – Drop                 |
| change my units      | U – Unit Change          |
| change my section    | S – Section Change       |
| take it pass/fail    | P/F – Pass/Fail          |
| switch back to grade | G – Letter Grade         |
