# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ChangedVO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'changed': 'int',
        'total': 'int',
        'value': 'int'
    }

    attribute_map = {
        'changed': 'changed',
        'total': 'total',
        'value': 'value'
    }

    def __init__(self, changed=None, total=None, value=None):
        r"""ChangedVO

        The model defined in huaweicloud sdk

        :param changed: **参数解释**： 变化数量 **取值范围**： 不涉及
        :type changed: int
        :param total: **参数解释**： 变化数量 **取值范围**： 不涉及
        :type total: int
        :param value: **参数解释**： 数量 **取值范围**： 不涉及
        :type value: int
        """
        
        

        self._changed = None
        self._total = None
        self._value = None
        self.discriminator = None

        if changed is not None:
            self.changed = changed
        if total is not None:
            self.total = total
        if value is not None:
            self.value = value

    @property
    def changed(self):
        r"""Gets the changed of this ChangedVO.

        **参数解释**： 变化数量 **取值范围**： 不涉及

        :return: The changed of this ChangedVO.
        :rtype: int
        """
        return self._changed

    @changed.setter
    def changed(self, changed):
        r"""Sets the changed of this ChangedVO.

        **参数解释**： 变化数量 **取值范围**： 不涉及

        :param changed: The changed of this ChangedVO.
        :type changed: int
        """
        self._changed = changed

    @property
    def total(self):
        r"""Gets the total of this ChangedVO.

        **参数解释**： 变化数量 **取值范围**： 不涉及

        :return: The total of this ChangedVO.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ChangedVO.

        **参数解释**： 变化数量 **取值范围**： 不涉及

        :param total: The total of this ChangedVO.
        :type total: int
        """
        self._total = total

    @property
    def value(self):
        r"""Gets the value of this ChangedVO.

        **参数解释**： 数量 **取值范围**： 不涉及

        :return: The value of this ChangedVO.
        :rtype: int
        """
        return self._value

    @value.setter
    def value(self, value):
        r"""Sets the value of this ChangedVO.

        **参数解释**： 数量 **取值范围**： 不涉及

        :param value: The value of this ChangedVO.
        :type value: int
        """
        self._value = value

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ChangedVO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
