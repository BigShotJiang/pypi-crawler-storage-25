# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class IpsProtectDTO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'object_id': 'str',
        'mode': 'int'
    }

    attribute_map = {
        'object_id': 'object_id',
        'mode': 'mode'
    }

    def __init__(self, object_id=None, mode=None):
        r"""IpsProtectDTO

        The model defined in huaweicloud sdk

        :param object_id: 防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID。
        :type object_id: str
        :param mode: ips防护模式，0：观察模式，1：严格模式，2：中等模式，3：宽松模式
        :type mode: int
        """
        
        

        self._object_id = None
        self._mode = None
        self.discriminator = None

        self.object_id = object_id
        self.mode = mode

    @property
    def object_id(self):
        r"""Gets the object_id of this IpsProtectDTO.

        防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID。

        :return: The object_id of this IpsProtectDTO.
        :rtype: str
        """
        return self._object_id

    @object_id.setter
    def object_id(self, object_id):
        r"""Sets the object_id of this IpsProtectDTO.

        防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID。

        :param object_id: The object_id of this IpsProtectDTO.
        :type object_id: str
        """
        self._object_id = object_id

    @property
    def mode(self):
        r"""Gets the mode of this IpsProtectDTO.

        ips防护模式，0：观察模式，1：严格模式，2：中等模式，3：宽松模式

        :return: The mode of this IpsProtectDTO.
        :rtype: int
        """
        return self._mode

    @mode.setter
    def mode(self, mode):
        r"""Sets the mode of this IpsProtectDTO.

        ips防护模式，0：观察模式，1：严格模式，2：中等模式，3：宽松模式

        :param mode: The mode of this IpsProtectDTO.
        :type mode: int
        """
        self._mode = mode

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, IpsProtectDTO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
