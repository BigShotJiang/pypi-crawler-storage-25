# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DnsServersResponseDTO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'int',
        'is_applied': 'int',
        'is_customized': 'int',
        'server_ip': 'str',
        'status': 'int',
        'health_check_domain_name': 'str'
    }

    attribute_map = {
        'id': 'id',
        'is_applied': 'is_applied',
        'is_customized': 'is_customized',
        'server_ip': 'server_ip',
        'status': 'status',
        'health_check_domain_name': 'health_check_domain_name'
    }

    def __init__(self, id=None, is_applied=None, is_customized=None, server_ip=None, status=None, health_check_domain_name=None):
        r"""DnsServersResponseDTO

        The model defined in huaweicloud sdk

        :param id: **参数解释**： 域名服务器id **取值范围**： 不涉及
        :type id: int
        :param is_applied: **参数解释**： 域名服务器是否应用 **取值范围**： - 0：否 - 1：是
        :type is_applied: int
        :param is_customized: **参数解释**： 域名服务器是否是用户自定义的dns服务器 **取值范围**： - 0：否 - 1：是
        :type is_customized: int
        :param server_ip: **参数解释**： DNS服务器IP **取值范围**： 不涉及
        :type server_ip: str
        :param status: **参数解释**： dns服务器解析状态 **取值范围**： 0：解析域名的频率正常 1：解析域名的频率缓慢 2：解析域名异常 
        :type status: int
        :param health_check_domain_name: **参数解释**： 健康检查域名 **取值范围**： 不涉及
        :type health_check_domain_name: str
        """
        
        

        self._id = None
        self._is_applied = None
        self._is_customized = None
        self._server_ip = None
        self._status = None
        self._health_check_domain_name = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if is_applied is not None:
            self.is_applied = is_applied
        if is_customized is not None:
            self.is_customized = is_customized
        if server_ip is not None:
            self.server_ip = server_ip
        if status is not None:
            self.status = status
        if health_check_domain_name is not None:
            self.health_check_domain_name = health_check_domain_name

    @property
    def id(self):
        r"""Gets the id of this DnsServersResponseDTO.

        **参数解释**： 域名服务器id **取值范围**： 不涉及

        :return: The id of this DnsServersResponseDTO.
        :rtype: int
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this DnsServersResponseDTO.

        **参数解释**： 域名服务器id **取值范围**： 不涉及

        :param id: The id of this DnsServersResponseDTO.
        :type id: int
        """
        self._id = id

    @property
    def is_applied(self):
        r"""Gets the is_applied of this DnsServersResponseDTO.

        **参数解释**： 域名服务器是否应用 **取值范围**： - 0：否 - 1：是

        :return: The is_applied of this DnsServersResponseDTO.
        :rtype: int
        """
        return self._is_applied

    @is_applied.setter
    def is_applied(self, is_applied):
        r"""Sets the is_applied of this DnsServersResponseDTO.

        **参数解释**： 域名服务器是否应用 **取值范围**： - 0：否 - 1：是

        :param is_applied: The is_applied of this DnsServersResponseDTO.
        :type is_applied: int
        """
        self._is_applied = is_applied

    @property
    def is_customized(self):
        r"""Gets the is_customized of this DnsServersResponseDTO.

        **参数解释**： 域名服务器是否是用户自定义的dns服务器 **取值范围**： - 0：否 - 1：是

        :return: The is_customized of this DnsServersResponseDTO.
        :rtype: int
        """
        return self._is_customized

    @is_customized.setter
    def is_customized(self, is_customized):
        r"""Sets the is_customized of this DnsServersResponseDTO.

        **参数解释**： 域名服务器是否是用户自定义的dns服务器 **取值范围**： - 0：否 - 1：是

        :param is_customized: The is_customized of this DnsServersResponseDTO.
        :type is_customized: int
        """
        self._is_customized = is_customized

    @property
    def server_ip(self):
        r"""Gets the server_ip of this DnsServersResponseDTO.

        **参数解释**： DNS服务器IP **取值范围**： 不涉及

        :return: The server_ip of this DnsServersResponseDTO.
        :rtype: str
        """
        return self._server_ip

    @server_ip.setter
    def server_ip(self, server_ip):
        r"""Sets the server_ip of this DnsServersResponseDTO.

        **参数解释**： DNS服务器IP **取值范围**： 不涉及

        :param server_ip: The server_ip of this DnsServersResponseDTO.
        :type server_ip: str
        """
        self._server_ip = server_ip

    @property
    def status(self):
        r"""Gets the status of this DnsServersResponseDTO.

        **参数解释**： dns服务器解析状态 **取值范围**： 0：解析域名的频率正常 1：解析域名的频率缓慢 2：解析域名异常 

        :return: The status of this DnsServersResponseDTO.
        :rtype: int
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this DnsServersResponseDTO.

        **参数解释**： dns服务器解析状态 **取值范围**： 0：解析域名的频率正常 1：解析域名的频率缓慢 2：解析域名异常 

        :param status: The status of this DnsServersResponseDTO.
        :type status: int
        """
        self._status = status

    @property
    def health_check_domain_name(self):
        r"""Gets the health_check_domain_name of this DnsServersResponseDTO.

        **参数解释**： 健康检查域名 **取值范围**： 不涉及

        :return: The health_check_domain_name of this DnsServersResponseDTO.
        :rtype: str
        """
        return self._health_check_domain_name

    @health_check_domain_name.setter
    def health_check_domain_name(self, health_check_domain_name):
        r"""Sets the health_check_domain_name of this DnsServersResponseDTO.

        **参数解释**： 健康检查域名 **取值范围**： 不涉及

        :param health_check_domain_name: The health_check_domain_name of this DnsServersResponseDTO.
        :type health_check_domain_name: str
        """
        self._health_check_domain_name = health_check_domain_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DnsServersResponseDTO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
