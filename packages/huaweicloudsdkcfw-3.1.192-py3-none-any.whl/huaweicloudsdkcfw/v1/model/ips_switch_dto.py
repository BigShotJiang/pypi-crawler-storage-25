# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class IpsSwitchDTO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'object_id': 'str',
        'ips_type': 'int',
        'status': 'int'
    }

    attribute_map = {
        'object_id': 'object_id',
        'ips_type': 'ips_type',
        'status': 'status'
    }

    def __init__(self, object_id=None, ips_type=None, status=None):
        r"""IpsSwitchDTO

        The model defined in huaweicloud sdk

        :param object_id: 防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)获得，通过返回值中的data.records.protect_objects.object_id（.表示各对象之间层级的区分）获得，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID。此处仅取type为0的防护对象id，可通过data.records.protect_objects.type（.表示各对象之间层级的区分）获得。
        :type object_id: str
        :param ips_type: 补丁类型，仅支持虚拟补丁，值为2。
        :type ips_type: int
        :param status: ips特性开关状态，0表示关闭，1表示开启
        :type status: int
        """
        
        

        self._object_id = None
        self._ips_type = None
        self._status = None
        self.discriminator = None

        self.object_id = object_id
        self.ips_type = ips_type
        self.status = status

    @property
    def object_id(self):
        r"""Gets the object_id of this IpsSwitchDTO.

        防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)获得，通过返回值中的data.records.protect_objects.object_id（.表示各对象之间层级的区分）获得，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID。此处仅取type为0的防护对象id，可通过data.records.protect_objects.type（.表示各对象之间层级的区分）获得。

        :return: The object_id of this IpsSwitchDTO.
        :rtype: str
        """
        return self._object_id

    @object_id.setter
    def object_id(self, object_id):
        r"""Sets the object_id of this IpsSwitchDTO.

        防护对象id，是创建云防火墙后用于区分互联网边界防护和VPC边界防护的标志id，可通过调用[查询防火墙实例接口](ListFirewallDetail.xml)获得，通过返回值中的data.records.protect_objects.object_id（.表示各对象之间层级的区分）获得，type为0时，object_id为互联网边界防护对象ID，type为1时，object_id为VPC边界防护对象ID。此处仅取type为0的防护对象id，可通过data.records.protect_objects.type（.表示各对象之间层级的区分）获得。

        :param object_id: The object_id of this IpsSwitchDTO.
        :type object_id: str
        """
        self._object_id = object_id

    @property
    def ips_type(self):
        r"""Gets the ips_type of this IpsSwitchDTO.

        补丁类型，仅支持虚拟补丁，值为2。

        :return: The ips_type of this IpsSwitchDTO.
        :rtype: int
        """
        return self._ips_type

    @ips_type.setter
    def ips_type(self, ips_type):
        r"""Sets the ips_type of this IpsSwitchDTO.

        补丁类型，仅支持虚拟补丁，值为2。

        :param ips_type: The ips_type of this IpsSwitchDTO.
        :type ips_type: int
        """
        self._ips_type = ips_type

    @property
    def status(self):
        r"""Gets the status of this IpsSwitchDTO.

        ips特性开关状态，0表示关闭，1表示开启

        :return: The status of this IpsSwitchDTO.
        :rtype: int
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this IpsSwitchDTO.

        ips特性开关状态，0表示关闭，1表示开启

        :param status: The status of this IpsSwitchDTO.
        :type status: int
        """
        self._status = status

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, IpsSwitchDTO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
