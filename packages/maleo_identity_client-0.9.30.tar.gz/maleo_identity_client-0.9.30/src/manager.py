from nexo.client.manager import ClientManager

from .config import ClientConfig
from .services.blood_type import BloodTypeClientService
from .services.gender import GenderClientService
from .services.medical_role import MedicalRoleClientService
from .services.medical_service import MedicalServiceClientService
from .services.organization import OrganizationClientService
from .services.organization_registration_code import (
    OrganizationRegistrationCodeClientService,
)
from .services.organization_relation import OrganizationRelationClientService
from .services.organization_role import OrganizationRoleClientService
from .services.organization_type import OrganizationTypeClientService
from .services.service import ServiceClientService
from .services.system_role import SystemRoleClientService
from .services.user import UserClientService
from .services.user_profile import UserProfileClientService
from .services.user_type import UserTypeClientService


class MaleoIdentityClientManager(ClientManager[ClientConfig]):
    def initalize_services(self):
        self.blood_type = BloodTypeClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.gender = GenderClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.medical_role = MedicalRoleClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.medical_service = MedicalServiceClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.organization_registration_code = OrganizationRegistrationCodeClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.organization_relation = OrganizationRelationClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.organization_role = OrganizationRoleClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.organization_type = OrganizationTypeClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.organization = OrganizationClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.service = ServiceClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.system_role = SystemRoleClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.user_profile = UserProfileClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.user_type = UserTypeClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
        self.user = UserClientService(
            self._config,
            self._http_client_manager,
            settings=self._settings,
            logger=self._logger,
            private_key=self._private_key,
            cache=self._cache,
            publishers=self._publishers,
        )
