from copy import deepcopy
from datetime import UTC, datetime
from typing import ClassVar, Literal, overload
from uuid import UUID

import httpx
from maleo.identity.constants.system_role import SYSTEM_ROLE_RESOURCE
from maleo.identity.enums.system_role import Granularity
from maleo.identity.mixins.system_role import is_id_identifier
from maleo.identity.schemas.system_role import (
    FullSystemRoleSchema,
    ReadMultipleParameter,
    ReadSingleParameter,
    StandardSystemRoleSchema,
)
from maleo.identity.utils.system_role import get_schema_model
from nexo.client.service import ClientService
from nexo.crypto.hash.enums import Mode
from nexo.crypto.hash.sha256 import hash
from nexo.crypto.signature import sign
from nexo.database.enums import Connection
from nexo.database.utils import build_cache_key
from nexo.enums.cardinality import Cardinality
from nexo.enums.connection import Header
from nexo.schemas.connection import ConnectionContext
from nexo.schemas.exception.factory import MaleoExceptionFactory
from nexo.schemas.operation.action.resource import ReadResourceOperationAction
from nexo.schemas.operation.enums import OperationType, Target
from nexo.schemas.operation.mixins import Timestamp
from nexo.schemas.operation.resource import (
    ReadMultipleResourceOperation,
    ReadSingleResourceOperation,
)
from nexo.schemas.pagination import StrictPagination
from nexo.schemas.resource import AggregateField, Resource
from nexo.schemas.response import (
    MultipleDataResponse,
    SingleDataResponse,
)
from nexo.schemas.security.authorization import (
    AnyAuthorization,
    AuthorizationFactory,
)
from nexo.schemas.security.impersonation import OptImpersonation
from nexo.types.dict import OptStrToStrDict
from nexo.types.string import ManyStrs
from nexo.utils.merger import merge_dicts

from ..config import ClientConfig


class SystemRoleClientService(ClientService[ClientConfig]):
    _resource: ClassVar[Resource] = SYSTEM_ROLE_RESOURCE
    _resource_name: ClassVar[str] = _resource.aggregate(
        AggregateField.NAME, sep=" "
    ).lower()

    @overload
    async def read(
        self,
        cardinality: Literal[Cardinality.MULTIPLE],
        granularity: Literal[Granularity.STANDARD],
        *,
        operation_id: UUID,
        connection_context: ConnectionContext,
        authorization: AnyAuthorization,
        impersonation: OptImpersonation = None,
        parameters: ReadMultipleParameter,
        headers: OptStrToStrDict = None,
    ) -> MultipleDataResponse[StandardSystemRoleSchema, StrictPagination, None]: ...
    @overload
    async def read(
        self,
        cardinality: Literal[Cardinality.MULTIPLE],
        granularity: Literal[Granularity.FULL],
        *,
        operation_id: UUID,
        connection_context: ConnectionContext,
        authorization: AnyAuthorization,
        impersonation: OptImpersonation = None,
        parameters: ReadMultipleParameter,
        headers: OptStrToStrDict = None,
    ) -> MultipleDataResponse[FullSystemRoleSchema, StrictPagination, None]: ...
    @overload
    async def read(
        self,
        cardinality: Literal[Cardinality.SINGLE],
        granularity: Literal[Granularity.STANDARD],
        *,
        operation_id: UUID,
        connection_context: ConnectionContext,
        authorization: AnyAuthorization,
        impersonation: OptImpersonation = None,
        parameters: ReadSingleParameter,
        headers: OptStrToStrDict = None,
    ) -> SingleDataResponse[StandardSystemRoleSchema, None]: ...
    @overload
    async def read(
        self,
        cardinality: Literal[Cardinality.SINGLE],
        granularity: Literal[Granularity.FULL],
        *,
        operation_id: UUID,
        connection_context: ConnectionContext,
        authorization: AnyAuthorization,
        impersonation: OptImpersonation = None,
        parameters: ReadSingleParameter,
        headers: OptStrToStrDict = None,
    ) -> SingleDataResponse[FullSystemRoleSchema, None]: ...
    async def read(
        self,
        cardinality: Cardinality,
        granularity: Granularity,
        *,
        operation_id: UUID,
        connection_context: ConnectionContext,
        authorization: AnyAuthorization,
        impersonation: OptImpersonation = None,
        parameters: ReadMultipleParameter | ReadSingleParameter,
        headers: OptStrToStrDict = None,
    ) -> (
        MultipleDataResponse[StandardSystemRoleSchema, StrictPagination, None]
        | MultipleDataResponse[FullSystemRoleSchema, StrictPagination, None]
        | SingleDataResponse[StandardSystemRoleSchema, None]
        | SingleDataResponse[FullSystemRoleSchema, None]
    ):
        cache_client = self._cache.manager.client.get(Connection.ASYNC)
        data_model_cls = get_schema_model(granularity)

        executed_at = datetime.now(tz=UTC)

        # Calculate parameters hash
        exclude = {"use_cache"}
        if isinstance(parameters, ReadSingleParameter):
            exclude.add("identifier")
        parameters_json = parameters.model_dump_json(exclude=exclude)
        parameters_hash = hash(Mode.DIGEST, message=parameters_json)

        # Define full cache_key
        ext = [
            cardinality.value,
            granularity.value,
            authorization.credentials,
        ]
        if isinstance(parameters, ReadSingleParameter):
            ext.append(parameters.model_dump_json(include={"identifier"}))
        ext.append(parameters_hash)
        cache_key = build_cache_key(*ext, namespace=self._namespace)

        if parameters.use_cache:
            # Initialize cache operation context
            operation_context = deepcopy(self._operation_context)
            operation_context.target.type = Target.CACHE

            cache_response_str = await cache_client.get(cache_key)

            if cache_response_str is not None:
                operation_timestamp = Timestamp.completed_now(executed_at)
                if cardinality is Cardinality.MULTIPLE:
                    summary = (
                        f"Successfully read multiple {granularity} "
                        f"{self._resource_name} from cache"
                    )
                    response = MultipleDataResponse[
                        data_model_cls, StrictPagination, None
                    ].model_validate_json(cache_response_str)
                    operation = ReadMultipleResourceOperation[
                        data_model_cls, StrictPagination, None
                    ](
                        application_context=self._settings.context,
                        id=operation_id,
                        context=operation_context,
                        resource=self._resource,
                        timestamp=operation_timestamp,
                        summary=summary,
                        connection_context=connection_context,
                        authentication=None,
                        authorization=authorization,
                        impersonation=impersonation,
                        response=response,
                    )
                    operation.log_and_publish(self._logger, self._publishers)
                elif cardinality is Cardinality.SINGLE:
                    summary = (
                        f"Successfully read single {granularity} "
                        f"{self._resource_name} from cache"
                    )
                    response = SingleDataResponse[
                        data_model_cls, None
                    ].model_validate_json(cache_response_str)
                    operation = ReadSingleResourceOperation[data_model_cls, None](
                        application_context=self._settings.context,
                        id=operation_id,
                        context=operation_context,
                        resource=self._resource,
                        timestamp=operation_timestamp,
                        summary=summary,
                        connection_context=connection_context,
                        authentication=None,
                        authorization=authorization,
                        impersonation=impersonation,
                        response=response,
                    )
                    operation.log_and_publish(self._logger, self._publishers)

                return response  # type: ignore

        operation_context = deepcopy(self._operation_context)
        operation_context.target.type = Target.MICROSERVICE

        async with self._http_client_manager.get() as http_client:
            # Define URL
            base_url_path = f"/v1/{self._resource.identifiers[-1].slug}"
            if isinstance(parameters, ReadMultipleParameter):
                url_path = base_url_path
            elif isinstance(parameters, ReadSingleParameter):
                if is_id_identifier(parameters.identifier):
                    url_path = base_url_path + f"/{parameters.identifier.value}"
                else:
                    url_path = (
                        base_url_path
                        + f"/{parameters.identifier.type}/{parameters.identifier.value}"
                    )
            url = f"{self._config.url}{url_path}"

            # Define Params
            params = parameters.to_query_params()
            query_params = httpx.QueryParams(params)

            # Define Headers
            base_headers = {
                Header.CONTENT_TYPE.value: "application/json",
                Header.X_OPERATION_ID.value: str(operation_id),
                Header.X_CLIENT_ID.value: str(self._settings.CLIENT_ID),
                Header.X_EXECUTED_AT.value: executed_at.isoformat(),
            }

            # Add impersonation if given
            if impersonation is not None:
                base_headers[Header.X_PRINCIPAL_ID.value] = str(
                    impersonation.principal_id
                )

            # Add Signature
            payload_components: ManyStrs = (
                executed_at.isoformat(),
                "GET",
                url_path,
                str(query_params),
                str(self._settings.CLIENT_SECRET),
                "EMPTY-PAYLOAD",
            )
            payload = "|".join(payload_components)
            signature = sign(payload, self._private_key)
            base_headers[Header.X_SIGNATURE.value] = signature

            # Finalize Headers
            if headers is not None:
                headers = merge_dicts(base_headers, headers)
            else:
                headers = base_headers

            # Define Auth
            auth = AuthorizationFactory.httpx_auth(
                scheme=authorization.scheme, authorization=authorization.credentials
            )

            # Send request
            response = await http_client.get(
                url, params=params, headers=headers, auth=auth
            )

            operation_timestamp = Timestamp.completed_now(executed_at)

            if response.is_error:
                exc = MaleoExceptionFactory.from_httpx(
                    response,
                    operation_type=OperationType.REQUEST,
                    application_context=self._settings.context,
                    operation_id=operation_id,
                    operation_context=operation_context,
                    operation_action=ReadResourceOperationAction(),
                    operation_timestamp=operation_timestamp,
                    connection_context=connection_context,
                    authentication=None,
                    authorization=authorization,
                    impersonation=impersonation,
                    logger=self._logger,
                )
                exc.log_and_publish_operation(self._logger, self._publishers)
                raise exc

            self.validate_response(response)

            if isinstance(parameters, ReadMultipleParameter):
                summary = (
                    f"Successfully read multiple {granularity} "
                    f"{self._resource_name} from microservice"
                )
                validated_response = MultipleDataResponse[
                    data_model_cls, StrictPagination, None
                ].model_validate(response.json())
                service_response = MultipleDataResponse[
                    data_model_cls, StrictPagination, None
                ].new(
                    data=validated_response.data,
                    pagination=validated_response.pagination,
                )
                operation = ReadMultipleResourceOperation[
                    data_model_cls, StrictPagination, None
                ](
                    application_context=self._settings.context,
                    id=operation_id,
                    context=operation_context,
                    resource=self._resource,
                    timestamp=operation_timestamp,
                    summary=summary,
                    connection_context=connection_context,
                    authentication=None,
                    authorization=authorization,
                    impersonation=impersonation,
                    response=service_response,
                )
                operation.log_and_publish(self._logger, self._publishers)
            elif isinstance(parameters, ReadSingleParameter):
                summary = (
                    f"Successfully read single {granularity} "
                    f"{self._resource_name} from microservice"
                )
                validated_response = SingleDataResponse[
                    data_model_cls, None
                ].model_validate(response.json())
                service_response = SingleDataResponse[data_model_cls, None].new(
                    data=validated_response.data,
                )
                operation = ReadSingleResourceOperation[data_model_cls, None](
                    application_context=self._settings.context,
                    id=operation_id,
                    context=operation_context,
                    resource=self._resource,
                    timestamp=operation_timestamp,
                    summary=summary,
                    connection_context=connection_context,
                    authentication=None,
                    authorization=authorization,
                    impersonation=impersonation,
                    response=service_response,
                )
                operation.log_and_publish(self._logger, self._publishers)

            return service_response  # type: ignore
