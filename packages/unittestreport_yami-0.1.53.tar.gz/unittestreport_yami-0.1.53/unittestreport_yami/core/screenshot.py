import tempfile
import requests
import os
from PIL import Image
from concurrent.futures import ThreadPoolExecutor, as_completed
import io


def _is_playwright_page(driver):
    """判断 driver 是否为 Playwright Page 对象"""
    return hasattr(driver, "screenshot") and not hasattr(driver, "get_screenshot_as_base64")


def _run_async(coro):
    """同步环境下执行 async 协程"""
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


def add_screenshot_with_local(test):
    """截图并以 base64 存储到 test.images（兼容 Selenium 和 Playwright）"""
    driver = getattr(test, "driver", None)
    if driver:
        try:
            if _is_playwright_page(driver):
                import base64
                png_bytes = _run_async(driver.screenshot(full_page=False))
                test.images.append(base64.b64encode(png_bytes).decode("utf-8"))
            else:
                test.images.append(driver.get_screenshot_as_base64())
        except Exception as e:
            print(f"local screenshot error! error:{e}")
            raise e


def add_screenshot_with_s3(test):
    """截图并以 WebP 格式保存到临时文件（兼容 Selenium 和 Playwright）"""
    driver = getattr(test, "driver", None)
    if driver:
        temp_file_path = ""
        # 创建临时文件，使用.webp后缀
        with tempfile.NamedTemporaryFile(suffix=".webp", delete=False) as temp_file:
            temp_file_path = temp_file.name
            temp_dir = os.path.dirname(temp_file_path)

            # 检查目录下的图片数量
            image_count = sum(
                1 for f in os.listdir(temp_dir) if f.lower().endswith((".webp", ".png"))
            )
            if image_count >= 100000:
                print(
                    f"警告：目录 {temp_dir} 中的图片数量已达到{image_count}张，超过限制，不再保存新的截图"
                )
                return

            # 获取截图为PNG格式的二进制数据（兼容 Playwright）
            if _is_playwright_page(driver):
                png_data = _run_async(driver.screenshot(full_page=False))
            else:
                png_data = driver.get_screenshot_as_png()
            # 在内存中用PIL处理图片
            img = Image.open(io.BytesIO(png_data))
            # 转换为WebP格式并保存，quality参数范围是0-100，可以根据需要调整
            img.save(temp_file_path, format="WEBP", quality=30, method=6)
            test.images.append(temp_file_path)


def upload_img_to_s3(s3_url, file_path):
    url = ""
    with open(file_path, "rb") as f:
        files = {"file": (file_path, f, "image/jpeg")}
        data = {"type": "common", "channel": "Yamibuy", "local": "local"}
        headers = {"token": "example-token"}
        try:
            response = requests.post(s3_url, files=files, data=data, headers=headers)
            body = response.json().get("body", [])
            print(f"upload screenshot to s3 scuccess! :{file_path}")
            if body:
                url = body[0].get("url")
        except Exception as e:
            print(f"upload screenshot to s3 error! error:{e}")
    os.remove(file_path)
    return url


def batch_upload_imgs_to_s3(s3_url, file_paths, max_workers=8):
    """并发上传多张截图到 S3，返回与 file_paths 顺序一致的 URL 列表"""
    results = [None] * len(file_paths)

    def _upload(index, path):
        return index, upload_img_to_s3(s3_url, path)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(_upload, i, path)
            for i, path in enumerate(file_paths)
            if os.path.exists(path)
        ]
        for future in as_completed(futures):
            try:
                idx, url = future.result()
                results[idx] = url
            except Exception as e:
                print(f"batch upload screenshot error: {e}")
    return results


def upload_report_to_s3(s3_url, file_path):
    url = ""
    with open(file_path, "rb") as f:
        file_name = os.path.basename(file_path)
        files = {"file": (file_name, f, "text/html")}
        data = {"type": "common", "channel": "Yamibuy", "local": "local"}
        headers = {"token": "example-token"}
        try:
            response = requests.post(s3_url, files=files, data=data, headers=headers)
            body = response.json().get("body", [])
            if body:
                url = body[0].get("url") or ""
            print(f"upload report to s3 scuccess! :{url}")
        except Exception as e:
            print(f"upload report to s3 error! error:{e}")
    os.remove(file_path)
    return url


def add_screenshot(test):
    """统一截图入口，自动识别 Selenium/Appium/Playwright 并调用对应截图方法"""
    try:
        driver = getattr(test, "driver", None)
        if driver:
            # Playwright 走独立分支，不需要 context 切换
            if _is_playwright_page(driver):
                if hasattr(test, "s3_url"):
                    add_screenshot_with_s3(test)
                else:
                    add_screenshot_with_local(test)
                return

            # Selenium/Appium: iOS Flutter driver 截图需要先切到 native context
            current_context = None
            try:
                current_context = driver.current_context
                if current_context and current_context != "NATIVE_APP":
                    driver.switch_to.context("NATIVE_APP")
            except Exception:
                pass

            try:
                if hasattr(test, "s3_url"):
                    add_screenshot_with_s3(test)
                else:
                    add_screenshot_with_local(test)
            finally:
                # 切回原来的 context
                if current_context and current_context != "NATIVE_APP":
                    try:
                        driver.switch_to.context(current_context)
                    except Exception:
                        pass
    except Exception as e:
        print(f"add screenshot error! error:{e}")
