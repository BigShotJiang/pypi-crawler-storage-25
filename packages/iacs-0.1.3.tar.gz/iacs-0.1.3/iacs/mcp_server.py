"""MCP server exposing iacs registry tools."""

import os
import sys
import tempfile
import traceback
import weakref
from contextlib import asynccontextmanager
from pathlib import Path

import yaml
from mcp.server.fastmcp import Context, FastMCP

from iacs.architect import Architect

_MANIFEST_ENV_VAR = "IACS_MANIFEST"
_EXAMPLE_MANIFEST = Path(__file__).parent.parent / "examples" / "example"
_BUILTINS_DIR = Path(__file__).parent / "builtins"
_IACS_MANIFEST_DIR = Path(__file__).parent / "iacs_manifest"

_architects: weakref.WeakKeyDictionary = weakref.WeakKeyDictionary()


def _get_architect(ctx: Context) -> Architect:
    session = ctx.request_context.session
    if session not in _architects:
        manifest = os.environ.get(_MANIFEST_ENV_VAR, str(_EXAMPLE_MANIFEST))
        _architects[session] = Architect.from_manifest(manifest)
    return _architects[session]


@asynccontextmanager
async def _lifespan(mcp_server):
    manifest = os.environ.get(_MANIFEST_ENV_VAR, str(_EXAMPLE_MANIFEST))
    arch = Architect.from_manifest(manifest)
    df = arch.registry.get("invalid_field").execute()
    print(f"invalid_field component:\n{df.to_string()}", file=sys.stderr)
    yield


server = FastMCP(
    "iacs",
    instructions=(
        f"Set the {_MANIFEST_ENV_VAR} environment variable to the path of your "
        "manifest directory so it loads automatically on startup. "
        "Call `get_manifest_path` to confirm which manifest is currently loaded."
    ),
    lifespan=_lifespan,
)


# ---------------------------------------------------------------------------
# Format guide helpers
# ---------------------------------------------------------------------------

def _get_description(component_list: list) -> str:
    """Return the value of the first description component in a list."""
    for item in component_list:
        if isinstance(item, dict) and "description" in item:
            return str(item["description"]).strip()
    return ""


def _format_field_entry(field_name: str, meta: dict) -> str:
    """Format a single field definition as a readable line."""
    line = f"- {field_name}"
    ftype = meta.get("type")
    if ftype:
        line += f": {ftype}"
    extras = []
    if meta.get("nullable") is False:
        extras.append("required")
    default = meta.get("default")
    if default is not None:
        extras.append(f"default: {default}")
    frange = meta.get("range")
    if frange is not None:
        extras.append(f"range: {frange}")
    if extras:
        line += f" ({', '.join(str(e) for e in extras)})"
    fdesc = meta.get("description")
    if fdesc:
        line += f" — {str(fdesc).strip()}"
    return line


def _extract_component_spec(comp_name: str, comp_list: list) -> str:
    """Build a human-readable spec block for one iacs component type."""
    desc = _get_description(comp_list)
    lines = [f"### {comp_name}", desc]

    field_lines = []
    for item in comp_list:
        if not isinstance(item, dict) or "field" not in item:
            continue
        field_val = item["field"]
        if not isinstance(field_val, dict):
            continue
        is_schema_case = (
            all(isinstance(v, (dict, type(None))) for v in field_val.values())
            and any(isinstance(v, dict) for v in field_val.values())
        )
        if is_schema_case:
            for fname, fmeta in field_val.items():
                if isinstance(fmeta, dict):
                    field_lines.append("  " + _format_field_entry(fname, fmeta))
        else:
            fname = field_val.get("value", "value")
            meta = {k: v for k, v in field_val.items() if k != "value"}
            field_lines.append("  " + _format_field_entry(fname, meta))

    if field_lines:
        lines.append("Fields:")
        lines.extend(field_lines)

    return "\n".join(lines)


def _build_format_description() -> str:
    """Assemble the format guide string from builtins YAML files.

    Reads format rules and a canonical example from format_guide.yaml, then
    builds a component reference from the iacs_component and data_structure
    sections of components.yaml.
    """
    guide_data = yaml.safe_load(
        (_IACS_MANIFEST_DIR / "format_guide.yaml").read_text(encoding="utf-8")
    )
    comp_data = yaml.safe_load(
        (_BUILTINS_DIR / "components.yaml").read_text(encoding="utf-8")
    )

    fmt = guide_data["entity_first_yaml_format"]
    intro = _get_description(fmt.get("data", []))
    rules = _get_description(fmt.get("format_rules", []))
    example = _get_description(fmt.get("canonical_example", []))

    iacs_comp = comp_data.get("iacs_component", {})
    comp_sections = []

    def _collect_specs(mapping: dict) -> None:
        """Recursively collect component specs from a nested component mapping.

        Leaf components (list values) are extracted directly. Parent components
        (dict values with a "data" key) have their own spec extracted from
        "data", then their children are visited recursively. The "data" key
        itself is skipped as a component name since it holds the parent's own
        component list, not a child component.

        Results are appended to the outer ``comp_sections`` list.
        """
        for comp_name, comp_val in mapping.items():
            if comp_name == "data":
                continue
            if isinstance(comp_val, list):
                comp_sections.append(_extract_component_spec(comp_name, comp_val))
            elif isinstance(comp_val, dict):
                if "data" in comp_val and isinstance(comp_val["data"], list):
                    comp_sections.append(_extract_component_spec(comp_name, comp_val["data"]))
                _collect_specs({k: v for k, v in comp_val.items() if k != "data"})

    _collect_specs(iacs_comp)

    ds = comp_data.get("data_structure", {})
    if isinstance(ds.get("field"), list):
        comp_sections.append(_extract_component_spec("field", ds["field"]))

    comp_ref = "\n\n".join(comp_sections)

    return "\n\n".join([
        f"# Entity-First YAML Format\n\n{intro}",
        f"## Format Rules\n\n{rules}",
        f"## Built-in Component Types\n\n{comp_ref}",
        f"## Canonical Example\n\n{example}",
    ])


# ---------------------------------------------------------------------------
# Validation helper
# ---------------------------------------------------------------------------

def _validate_yaml_string(yaml_string: str) -> str:
    """Parse and validate entity-first YAML, returning a result message.

    Writes the YAML to a temporary file and runs it through the full
    Architect pipeline. Returns a success message listing component types
    found, or an error message describing what went wrong.
    """
    try:
        yaml.safe_load(yaml_string)
    except yaml.YAMLError as exc:
        return f"YAML syntax error:\n{exc}"

    with tempfile.TemporaryDirectory() as tmp_dir:
        yaml_file = Path(tmp_dir) / "input.yaml"
        yaml_file.write_text(yaml_string, encoding="utf-8")
        try:
            arch = Architect.from_manifest(tmp_dir)
        except Exception:
            return f"Validation error:\n{traceback.format_exc()}"

    types = arch.registry.component_types
    return f"Valid. Component types found: {types}"


# ---------------------------------------------------------------------------
# MCP tools
# ---------------------------------------------------------------------------

@server.tool()
def get_manifest_path() -> str:
    """Return the path of the currently loaded manifest.

    Also shows the environment variable name used to configure a default
    manifest path at startup.
    """
    manifest = os.environ.get(_MANIFEST_ENV_VAR)
    if manifest:
        source = f"from {_MANIFEST_ENV_VAR} environment variable"
    else:
        manifest = str(_EXAMPLE_MANIFEST)
        source = f"built-in default (set {_MANIFEST_ENV_VAR} to override)"
    return f"Manifest path: {manifest!r} ({source})"


@server.tool()
def load_manifest(manifest_path: str, ctx: Context) -> str:
    """Load an iacs manifest from a directory path, replacing the current registry.

    Args:
        manifest_path: Path to the manifest directory.
    """
    arch = Architect.from_manifest(manifest_path)
    _architects[ctx.request_context.session] = arch
    return f"Loaded manifest from {manifest_path!r}. Component types: {arch.registry.component_types}"


@server.tool()
def list_component_types(ctx: Context) -> list[str]:
    """List all component types available in the iacs registry."""
    return _get_architect(ctx).registry.component_types


@server.tool()
def view_component(component_type: str, ctx: Context, format: str = "csv") -> str:
    """Return all data for a component type.

    Args:
        component_type: The name of the component type to view.
        format: Output format — "csv" (default) or "markdown" for a
            human-readable table.
    """
    arch = _get_architect(ctx)
    df = arch.registry.view_df(component_type).reset_index()
    if format == "markdown":
        return df.to_markdown(index=False)
    return df.to_csv(index=False)


@server.tool()
def describe_format() -> str:
    """Return the entity-first YAML format specification with a canonical example.

    Use this before transcribing text into iacs YAML to understand the
    required structure, built-in component types, and formatting rules.
    Sourced from the iacs builtins directory.
    """
    return _build_format_description()


@server.tool()
def validate_yaml(yaml_string: str) -> str:
    """Validate entity-first YAML and report any errors.

    Parses the YAML string, then runs it through the full iacs pipeline
    (load → validate → derive). Returns a success message listing the
    component types found, or a detailed error message.

    Args:
        yaml_string: Raw YAML text in entity-first format.
    """
    return _validate_yaml_string(yaml_string)


def main() -> None:
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
