"""Web frontend package."""
