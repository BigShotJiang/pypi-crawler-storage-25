"""
BQF (BranchPy Quality Framework) - Policy-based validation system.

This module provides the core infrastructure for BQF policy validation including:
- Policy registry (YAML-based configuration)
- Policy runner (dynamic validator loading and execution)
- Event emission (lifecycle tracking)
- Result aggregation (JSON formatting)

Version: 0.9.1.1
Created: 2025-11-12
"""

from .registry import PolicyRegistry, PolicyResult

__all__ = ["PolicyRegistry", "PolicyResult"]
