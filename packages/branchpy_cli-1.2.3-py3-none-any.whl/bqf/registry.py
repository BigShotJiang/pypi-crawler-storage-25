"""
BQF Policy Registry - Dynamic policy loading and execution.

This module provides the PolicyRegistry class for:
- Loading policies from YAML configuration
- Dynamically importing validator modules
- Executing policies with event emission
- Aggregating results into JSON format

Version: 0.9.1.1
Created: 2025-11-12
"""

import time
from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
from typing import Literal, Optional

import yaml


@dataclass
class PolicyResult:
    """Result from a single policy validator execution."""

    policy_id: str
    status: Literal["pass", "warn", "fail"]
    messages: list[str]
    duration_ms: float
    metadata: dict


class PolicyRegistry:
    """
    BQF Policy Registry - manages policy loading and execution.

    Usage:
        registry = PolicyRegistry()
        result = registry.run_policies("analyze", analysis_result, context)
    """

    def __init__(self, registry_path: Optional[Path] = None):
        """
        Initialize policy registry.

        Args:
            registry_path: Path to policies.yaml. If None, uses default location.
        """
        if registry_path is None:
            registry_path = Path(__file__).parent / "policies.yaml"

        self.registry_path = registry_path
        self.policies = self._load_policies()

    def _load_policies(self) -> list[dict]:
        """Load policies from YAML configuration file."""
        if not self.registry_path.exists():
            raise FileNotFoundError(f"Policy registry not found: {self.registry_path}")

        with open(self.registry_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)

        return config.get("policies", [])

    def get_policies_for_module(
        self, module: str, enabled_only: bool = True
    ) -> list[dict]:
        """
        Get policies for a specific module.

        Args:
            module: Module name ("analyze", "compare", "media")
            enabled_only: If True, only return enabled policies

        Returns:
            List of policy definitions for the module
        """
        policies = [p for p in self.policies if p["module"] == module]

        if enabled_only:
            policies = [p for p in policies if p.get("enabled", True)]

        return policies

    def _import_validator(self, validator_path: str):
        """
        Dynamically import validator function from module path.

        Args:
            validator_path: Dotted path like "bqf.validators.analyze.story_structure.validate"

        Returns:
            Validator function
        """
        module_path, func_name = validator_path.rsplit(".", 1)
        validator_module = import_module(module_path)
        return getattr(validator_module, func_name)

    def run_policies(self, module: str, analysis_result: dict, context: dict) -> dict:
        """
        Run all enabled policies for a module.

        Args:
            module: Module name ("analyze", "compare", "media")
            analysis_result: Full analysis/comparison/media result dict
            context: Additional context (project_path, correlation_id, etc.)

        Returns:
            Aggregated BQF result dict with format:
            {
                "policies_run": 2,
                "policies_passed": 2,
                "policies_warned": 0,
                "policies_failed": 0,
                "duration_ms": 1.23,
                "details": [...]  # Per-policy results
            }
        """
        policies = self.get_policies_for_module(module, enabled_only=True)

        if not policies:
            return {
                "policies_run": 0,
                "policies_passed": 0,
                "policies_warned": 0,
                "policies_failed": 0,
                "duration_ms": 0.0,
                "details": [],
            }

        # Emit start event (TODO: integrate with governance.events)
        correlation_id = context.get("correlation_id", "unknown")
        self._emit_event(
            "validation.policy.start",
            {
                "module": module,
                "policy_count": len(policies),
                "correlationId": correlation_id,
            },
        )

        start_time = time.perf_counter()
        results = []

        for policy in policies:
            try:
                # Dynamically load validator
                validator_func = self._import_validator(policy["validator"])

                # Run validation
                result = validator_func(analysis_result, context)
                results.append(result)

            except Exception as e:
                # If validator fails to load or execute, treat as failure
                results.append(
                    PolicyResult(
                        policy_id=policy["id"],
                        status="fail",
                        messages=[f"Validator error: {str(e)}"],
                        duration_ms=0.0,
                        metadata={"error": str(e)},
                    )
                )

        total_duration_ms = (time.perf_counter() - start_time) * 1000

        # Aggregate results (treat "info" as "warn" for counting)
        aggregated = {
            "policies_run": len(results),
            "policies_passed": sum(1 for r in results if r.status == "pass"),
            "policies_warned": sum(1 for r in results if r.status in ("warn", "info")),
            "policies_failed": sum(1 for r in results if r.status == "fail"),
            "duration_ms": round(total_duration_ms, 4),
            "details": [
                {
                    "policy_id": r.policy_id,
                    "status": r.status,
                    "messages": r.messages,
                    "duration_ms": round(r.duration_ms, 4),
                    "metadata": r.metadata,
                }
                for r in results
            ],
        }

        # Emit complete event
        self._emit_event(
            "validation.policy.complete",
            {"module": module, "results": aggregated, "correlationId": correlation_id},
        )

        return aggregated

    def _emit_event(self, event_name: str, data: dict):
        """
        Emit governance event (placeholder for future integration).

        Args:
            event_name: Event name following domain.action.phase pattern
            data: Event data payload

        TODO: Integrate with governance.events module in v0.9.2
        """
        # For now, just log to console (will integrate with governance logger later)
        # print(f"[BQF EVENT] {event_name}: {data}")
        pass  # Silent for now, will wire to governance.events in v0.9.2
