"""
branchpy/run_context.py

Minimal run identity — created once per logical execution unit (single stage
or full prerequisite chain) and attached to every artifact written during
that run.

Spec: docs/Current Version/Analysis/ARTIFACT_FRESHNESS_SPEC.md §5
"""

from __future__ import annotations

import datetime
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


def _branchpy_version() -> str:
    try:
        from branchpy.contract import VERSION  # type: ignore[import]

        return VERSION
    except Exception:
        return "unknown"


def _iso_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


@dataclass
class RunContext:
    """Snapshot identity for a single logical analysis run.

    Fields
    ------
    run_id          UUID4 string — unique per execution.
    project_path    Resolved absolute path string.
    started_at      ISO-8601 UTC timestamp — set at construction.
    completed_at    ISO-8601 UTC timestamp — set by :meth:`complete`.
    source_revision Max mtime of .rpy files, ms epoch (0 = unknown).
    branchpy_version Package version string from branchpy.contract.VERSION.
    """

    run_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    project_path: str = ""
    started_at: str = field(default_factory=_iso_now)
    completed_at: Optional[str] = None
    source_revision: int = 0
    branchpy_version: str = field(default_factory=_branchpy_version)

    # ── Factories ──────────────────────────────────────────────────────────

    @classmethod
    def start(cls, project_path: Path, source_revision: int = 0) -> "RunContext":
        """Create a RunContext with started_at set to now."""
        return cls(
            project_path=str(project_path),
            source_revision=source_revision,
        )

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def complete(self) -> "RunContext":
        """Stamp completed_at and return self (for chaining)."""
        self.completed_at = _iso_now()
        return self

    # ── Serialisation ─────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "project_path": self.project_path,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "source_revision": self.source_revision,
            "branchpy_version": self.branchpy_version,
        }
