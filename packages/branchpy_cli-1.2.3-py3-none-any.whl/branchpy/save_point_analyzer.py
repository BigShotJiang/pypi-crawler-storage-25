"""
Save Point Analyzer
Phase 5: Story Structure & Completeness Validation - R03 Save Rules

Implements:
- R03-001: Missing Save Points
- R03-002: Poor Save Placement
"""

import re
from typing import Any, Dict, List, Optional

from branchpy.story_graph import SaveGap, SavePoint, SavePointAnalysisResult, StoryGraph


class SavePointAnalyzer:
    """
    Analyzes save point placement and distribution.

    Detects:
    - Gaps in save point coverage
    - Poor placement (during animations, in choice blocks)
    - Missing save opportunities
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.max_labels_without_save = self.config.get("max_labels_without_save", 10)

    # Patterns for detecting save points in code
    SAVE_PATTERNS = [
        re.compile(r"\$\s*renpy\.save\s*\("),
        re.compile(r"\$\s*renpy\.save_persistent\s*\("),
        re.compile(r"renpy\.save\s*\("),
    ]

    # Patterns for detecting animations (poor save placement)
    ANIMATION_PATTERNS = [
        re.compile(r"show\s+\w+.*with\s+"),
        re.compile(r"hide\s+\w+.*with\s+"),
        re.compile(r"scene\s+\w+.*with\s+"),
        re.compile(r"with\s+(dissolve|fade|pixellate)"),
    ]

    def analyze(self, graph: StoryGraph) -> SavePointAnalysisResult:
        """
        Run complete save point analysis.

        Args:
            graph: Story graph to analyze

        Returns:
            Complete save point analysis results
        """
        # Detect all save points
        save_points = self.detect_save_points(graph)

        # Classify save points
        explicit_saves = [sp for sp in save_points if sp.save_type == "explicit"]
        implicit_saves = [
            sp for sp in save_points if sp.save_type in ["implicit_menu", "checkpoint"]
        ]

        # Find gaps in save coverage
        save_gaps = self.analyze_save_gaps(graph, save_points)

        # Detect poor placements
        poor_placements = self.detect_poor_placements(graph, explicit_saves)

        result = SavePointAnalysisResult(
            total_save_points=len(save_points),
            explicit_saves=len(explicit_saves),
            implicit_saves=len(implicit_saves),
            save_gaps=save_gaps,
            poor_placements=poor_placements,
        )

        return result

    def detect_save_points(self, graph: StoryGraph) -> List[SavePoint]:
        """
        Detect all save points in the story.

        Types detected:
        1. Explicit saves: $ renpy.save()
        2. Implicit saves: menu statements
        3. Checkpoints: save action in menus

        Args:
            graph: Story graph

        Returns:
            List of detected save points
        """
        save_points = []

        # Explicit saves already detected in graph construction
        # (This would be populated by graph_builder.py)
        save_points.extend(graph.save_points)

        # Implicit saves from menus
        for menu_id, menu in graph.menus.items():
            save_point = SavePoint(
                label=menu.label, location=menu.location, save_type="implicit_menu"
            )
            save_points.append(save_point)

        return save_points

    def analyze_save_gaps(
        self, graph: StoryGraph, save_points: List[SavePoint]
    ) -> List[SaveGap]:
        """
        Identify long sequences of labels without save points.

        A gap is a sequence of labels where:
        - No save points exist
        - Sequence length > max_labels_without_save threshold

        Args:
            graph: Story graph
            save_points: List of detected save points

        Returns:
            List of save gaps
        """
        if not self.config.get("check_save_gaps", True):
            return []

        gaps = []

        # Build set of labels with save points
        labels_with_saves = {sp.label for sp in save_points}

        # Compute linear sequences through the graph
        sequences = self._compute_linear_sequences(graph)

        for sequence in sequences:
            # Count how many labels in sequence have no save
            labels_without_save = [
                label for label in sequence if label not in labels_with_saves
            ]

            # If gap is long enough, report it
            if len(labels_without_save) >= self.max_labels_without_save:
                gap = SaveGap(
                    start_label=labels_without_save[0],
                    end_label=labels_without_save[-1],
                    label_sequence=labels_without_save,
                    label_count=len(labels_without_save),
                    severity="warning" if len(labels_without_save) >= 15 else "info",
                )
                gaps.append(gap)

        return gaps

    def _compute_linear_sequences(self, graph: StoryGraph) -> List[List[str]]:
        """
        Compute linear sequences of labels (paths without branching).

        Args:
            graph: Story graph

        Returns:
            List of label sequences
        """
        sequences = []
        visited = set()

        def trace_sequence(start_label: str) -> List[str]:
            """Trace a linear sequence from start_label"""
            sequence = [start_label]
            current = start_label

            while True:
                successors = graph.get_successors(current)

                # Stop if branching or no successors
                if len(successors) != 1:
                    break

                next_label = successors[0]

                # Stop if we've visited this label (cycle detection)
                if next_label in sequence:
                    break

                sequence.append(next_label)
                current = next_label

            return sequence

        # Start from each label that hasn't been visited
        for label in graph.get_all_labels():
            if label not in visited:
                sequence = trace_sequence(label)

                # Only report sequences of meaningful length
                if len(sequence) >= 3:
                    sequences.append(sequence)

                visited.update(sequence)

        return sequences

    def detect_poor_placements(
        self, graph: StoryGraph, save_points: List[SavePoint]
    ) -> List[SavePoint]:
        """
        Detect save points with problematic placement.

        Poor placements:
        - During animations (show/hide with transitions)
        - In choice blocks (between menu and choice selection)
        - During timed events

        Args:
            graph: Story graph
            save_points: List of explicit save points

        Returns:
            List of poorly placed save points
        """
        if not self.config.get("check_poor_placement", True):
            return []

        poor_placements = []

        for save_point in save_points:
            # Skip implicit saves (they're generally fine)
            if save_point.save_type != "explicit":
                continue

            # Check context around save point
            # (This requires access to raw source code, which graph_builder should provide)

            # For now, mark saves in labels that have menus as potentially poor
            label = graph.get_label(save_point.label)
            if label and label.has_menu:
                save_point.in_choice_block = True
                poor_placements.append(save_point)

        return poor_placements

    def _matches_save_pattern(self, line: str) -> bool:
        """Check if line contains a save statement"""
        return any(pattern.search(line) for pattern in self.SAVE_PATTERNS)

    def _matches_animation_pattern(self, line: str) -> bool:
        """Check if line contains an animation"""
        return any(pattern.search(line) for pattern in self.ANIMATION_PATTERNS)

    def recommend_save_placements(
        self, graph: StoryGraph, gaps: List[SaveGap]
    ) -> Dict[str, str]:
        """
        Recommend where to place save points to fill gaps.

        Args:
            graph: Story graph
            gaps: Detected save gaps

        Returns:
            Dictionary mapping label -> reason for recommendation
        """
        recommendations = {}

        for gap in gaps:
            # Recommend save at start of gap
            recommendations[gap.start_label] = (
                f"Start of {gap.label_count}-label sequence without saves"
            )

            # If gap is very long, also recommend middle
            if gap.label_count > 20:
                mid_index = len(gap.label_sequence) // 2
                mid_label = gap.label_sequence[mid_index]
                recommendations[mid_label] = (
                    f"Middle of long sequence ({gap.label_count} labels)"
                )

        return recommendations


# Convenience function
def analyze_save_points(
    graph: StoryGraph, config: Optional[Dict[str, Any]] = None
) -> SavePointAnalysisResult:
    """Convenience function to run save point analysis"""
    analyzer = SavePointAnalyzer(config)
    return analyzer.analyze(graph)
