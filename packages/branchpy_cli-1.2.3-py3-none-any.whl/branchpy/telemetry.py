# branchpy/telemetry.py
from __future__ import annotations

import json
import os
import time
from threading import Lock, Thread
from typing import Any, Dict, Optional

from . import logs
from .config_store import ConfigStore

UPDATE_EVENTS = {
    "update_check",
    "update_available",
    "download_success",
    "verify_fail",
    "swap_success",
    "rollback",
}


class Telemetry:
    def __init__(self, cfg: Optional[ConfigStore] = None) -> None:
        self._cfg = cfg or ConfigStore()
        self._enabled = bool(self._cfg.cfg.telemetry.enabled)
        self._last_metrics_flush = 0.0
        self._metrics_interval_s = 60  # flush every 60s if enabled
        self._metrics_lock = Lock()
        if self._enabled:
            self._start_metrics_loop()

    @property
    def enabled(self) -> bool:
        return self._enabled

    def log(self, event: str, **fields: Any) -> None:
        # No-op if disabled; keep signature stable for future use
        if not self._enabled:
            return
        # Minimal local sink for now; can be replaced with HTTP later
        record = {
            "ts": int(time.time() * 1000),
            "event": event,
            "fields": fields,
        }
        try:
            path = os.path.join(self._cfg.logs_path, "telemetry.ndjson")
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass  # best-effort only

    # ---------------- Metrics Export -----------------
    def _start_metrics_loop(self) -> None:
        def loop():
            while self._enabled:
                time.sleep(5)
                now = time.time()
                if now - self._last_metrics_flush >= self._metrics_interval_s:
                    try:
                        self.export_logging_metrics()
                        self._last_metrics_flush = now
                    except Exception:
                        pass

        Thread(target=loop, daemon=True).start()

    def export_logging_metrics(self) -> None:
        """Export current logging metrics snapshot to telemetry sink (if enabled)."""
        if not self._enabled:
            return
        metrics: Dict[str, int] = logs.get_metrics()
        # Export only if there is any activity
        if sum(metrics.values()) == 0:
            return
        self.log("logging.metrics", **metrics)
        # Optional: reset high-volume TRACE counter to keep growth bounded
        if metrics.get("TRACE", 0) > 10000:
            logs.reset_metrics(["TRACE"])
