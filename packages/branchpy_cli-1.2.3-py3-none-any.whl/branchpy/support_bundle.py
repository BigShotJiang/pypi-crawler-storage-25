# branchpy/support_bundle.py
"""
Support bundle generation for BranchPy v0.7.21+
Creates a ZIP or TAR.ZSTD archive with recent logs, system info, and analysis reports.
"""
import json
import os
import pathlib
import platform
import sys
import tarfile
import time
import zipfile
from typing import Literal, Optional

from . import logs
from .contract import VERSION

DEFAULT_SINCE_H = 48
BundleFormat = Literal["zip", "tar.zst"]


def get_log_dir() -> pathlib.Path:
    """Get the BranchPy logs directory (cross-platform)."""
    if os.name == "nt":  # Windows
        base = os.getenv("LOCALAPPDATA", os.path.expanduser("~"))
        return pathlib.Path(base) / "BranchPy" / "logs"
    elif sys.platform == "darwin":  # macOS
        return pathlib.Path.home() / "Library" / "Logs" / "BranchPy"
    else:  # Linux and other Unix-like
        # Follow XDG Base Directory spec
        xdg_data = os.getenv(
            "XDG_DATA_HOME", str(pathlib.Path.home() / ".local" / "share")
        )
        return pathlib.Path(xdg_data) / "branchpy" / "logs"


def get_project_log_dir(project_path: Optional[str] = None) -> Optional[pathlib.Path]:
    """Get project-specific log directory if it exists."""
    if not project_path:
        return None
    project_logs = pathlib.Path(project_path) / ".branchpy" / "logs"
    return project_logs if project_logs.exists() else None


def gather_system_summary() -> dict:
    """Gather system information snapshot."""
    try:
        bpy_version = os.getenv(
            "BRANCHPY_VERSION", VERSION
        )  # Use VERSION from contract
    except Exception:
        bpy_version = "unknown"

    return {
        "bpy_version": bpy_version,
        "python": {
            "version": platform.python_version(),
            "implementation": platform.python_implementation(),
            "executable": sys.executable,
        },
        "os": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
        },
        "environment": {
            "cwd": os.getcwd(),
            "user": os.getenv("USER") or os.getenv("USERNAME") or "unknown",
        },
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


def build_support_bundle(
    since_hours: int = DEFAULT_SINCE_H,
    strict: bool = True,
    include_vscode: bool = True,
    project_path: Optional[str] = None,
    format: BundleFormat = "zip",
) -> str:
    """
    Build a support bundle archive with logs and system info.

    Args:
        since_hours: Include logs modified in last N hours
        strict: Use strict redaction (paths + project IDs)
        include_vscode: Include VS Code extension logs
        project_path: Optional project path for project-specific logs
        format: Archive format - "zip" (default) or "tar.zst" (compressed tarball)

    Returns:
        Path to the created archive file
    """
    ts = time.strftime("%Y%m%d_%H%M%S")
    log_dir = get_log_dir()
    ext = "tar.zst" if format == "tar.zst" else "zip"
    out_path = log_dir / f"branchpy_support_{ts}.{ext}"
    cutoff = time.time() - (since_hours * 3600)

    # Ensure output directory exists
    log_dir.mkdir(parents=True, exist_ok=True)

    # Collect files to include
    files_to_add = []
    added_count = 0

    def should_include(p: pathlib.Path) -> bool:
        """Check if file should be included based on age."""
        try:
            return p.exists() and p.stat().st_mtime >= cutoff
        except Exception as e:
            logs.warn("bundle.stat_failed", msg=str(e), file=str(p))
            return False

    # Collect global logs
    for log_file in sorted(log_dir.glob("*.jsonl*")):
        if should_include(log_file):
            files_to_add.append((log_file, f"logs/{log_file.name}"))
            added_count += 1

    # Collect project logs if available
    project_log_dir = get_project_log_dir(project_path)
    if project_log_dir:
        for log_file in sorted(project_log_dir.glob("*.jsonl*")):
            if should_include(log_file):
                files_to_add.append((log_file, f"project_logs/{log_file.name}"))
                added_count += 1

    # Collect daemon metadata if exists
    daemon_meta = pathlib.Path.home() / ".branchpy" / "ws_daemon_meta.json"
    if daemon_meta.exists():
        files_to_add.append((daemon_meta, "meta/ws_daemon_meta.json"))

    # Collect recent analysis reports if project path provided
    if project_path:
        project_root = pathlib.Path(project_path)
        analyze_dir = project_root / ".branchpy" / "analyze"
        if analyze_dir.exists():
            for report in sorted(analyze_dir.glob("*.json")):
                if should_include(report):
                    files_to_add.append((report, f"reports/{report.name}"))
                    added_count += 1

    # Create system snapshot
    snapshot = gather_system_summary()
    snapshot_json = json.dumps(
        logs.redact_obj(snapshot, strict=strict), ensure_ascii=False, indent=2
    )

    # Create manifest
    manifest = {
        "created": ts,
        "since_hours": since_hours,
        "strict_redaction": strict,
        "files_included": added_count,
        "branchpy_version": snapshot["bpy_version"],
        "format": format,
    }
    manifest_json = json.dumps(manifest, indent=2)

    # Create archive based on format
    if format == "tar.zst":
        # Try to import zstandard, fall back to tar.gz if not available
        try:
            import zstandard as zstd

            # Create compressed tar archive with zstd
            with open(out_path, "wb") as f:
                cctx = zstd.ZstdCompressor(
                    level=3, threads=-1
                )  # Level 3 = fast, use all CPU cores
                with cctx.stream_writer(f) as compressor:
                    with tarfile.open(fileobj=compressor, mode="w") as tar:
                        # Add all collected files
                        for file_path, arcname in files_to_add:
                            try:
                                tar.add(file_path, arcname=arcname)
                            except Exception as e:
                                logs.warn(
                                    "bundle.tar_add_failed",
                                    msg=str(e),
                                    file=str(file_path),
                                )

                        # Add JSON files from memory
                        import io

                        # Add system snapshot
                        snapshot_bytes = snapshot_json.encode("utf-8")
                        snapshot_info = tarfile.TarInfo(name="system/snapshot.json")
                        snapshot_info.size = len(snapshot_bytes)
                        snapshot_info.mtime = time.time()
                        tar.addfile(snapshot_info, io.BytesIO(snapshot_bytes))

                        # Add manifest
                        manifest_bytes = manifest_json.encode("utf-8")
                        manifest_info = tarfile.TarInfo(name="manifest.json")
                        manifest_info.size = len(manifest_bytes)
                        manifest_info.mtime = time.time()
                        tar.addfile(manifest_info, io.BytesIO(manifest_bytes))

        except ImportError:
            # Fall back to tar.gz if zstandard not available
            logs.warn(
                "bundle.zstd_unavailable", msg="zstandard not installed, using tar.gz"
            )
            out_path = log_dir / f"branchpy_support_{ts}.tar.gz"
            with tarfile.open(out_path, "w:gz") as tar:
                for file_path, arcname in files_to_add:
                    try:
                        tar.add(file_path, arcname=arcname)
                    except Exception as e:
                        logs.warn(
                            "bundle.tar_add_failed", msg=str(e), file=str(file_path)
                        )

                # Add JSON files
                import io

                snapshot_bytes = snapshot_json.encode("utf-8")
                snapshot_info = tarfile.TarInfo(name="system/snapshot.json")
                snapshot_info.size = len(snapshot_bytes)
                snapshot_info.mtime = time.time()
                tar.addfile(snapshot_info, io.BytesIO(snapshot_bytes))

                manifest_bytes = manifest_json.encode("utf-8")
                manifest_info = tarfile.TarInfo(name="manifest.json")
                manifest_info.size = len(manifest_bytes)
                manifest_info.mtime = time.time()
                tar.addfile(manifest_info, io.BytesIO(manifest_bytes))

    else:
        # ZIP format (original behavior)
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
            # Add all collected files
            for file_path, arcname in files_to_add:
                try:
                    z.write(file_path, arcname)
                except Exception as e:
                    logs.warn("bundle.zip_add_failed", msg=str(e), file=str(file_path))

            # Add JSON files
            z.writestr("system/snapshot.json", snapshot_json)
            z.writestr("manifest.json", manifest_json)

    return str(out_path)
