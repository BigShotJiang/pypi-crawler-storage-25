"""
Choice Impact Analyzer
Phase 5: Story Structure & Completeness Validation - R03 Choice Rules

Implements:
- R03-003: False Choices
- R03-004: Choice Impact (metric)
"""

from typing import Any, Dict, List, Optional, Set

from branchpy.story_graph import (
    ChoiceAnalysisResult,
    ChoiceImpact,
    MenuNode,
    StoryGraph,
)


class ChoiceImpactAnalyzer:
    """
    Analyzes menu choices for narrative impact.

    Evaluates whether choices meaningfully affect the story through:
    - Variable modifications
    - Path divergence
    - Ending reachability
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.min_impact_threshold = self.config.get("minimum_impact_threshold", 0.3)

    def analyze(self, graph: StoryGraph) -> ChoiceAnalysisResult:
        """
        Run complete choice impact analysis.

        Args:
            graph: Story graph to analyze

        Returns:
            Complete choice analysis results
        """
        choice_impacts: Dict[str, ChoiceImpact] = {}
        false_choices: List[str] = []
        high_impact_choices: List[str] = []

        # Analyze each menu
        for menu_id, menu in graph.menus.items():
            impact = self.analyze_menu(menu, graph)
            choice_impacts[menu_id] = impact

            # Classify choices
            if impact.is_trivial or self._is_false_choice(menu, graph):
                false_choices.append(menu_id)
                menu.is_false_choice = True

            if impact.is_high_impact:
                high_impact_choices.append(menu_id)

            # Update menu with impact score
            menu.impact_score = impact.score

        # Calculate overall metrics
        total_choices = len(graph.menus)
        impactful_count = sum(
            1
            for impact in choice_impacts.values()
            if impact.score >= self.min_impact_threshold
        )
        impact_percentage = (
            (impactful_count / total_choices * 100) if total_choices > 0 else 0.0
        )

        result = ChoiceAnalysisResult(
            total_choices=total_choices,
            impactful_choices=impactful_count,
            trivial_choices=len(false_choices),
            impact_percentage=impact_percentage,
            choice_impacts=choice_impacts,
            false_choices=false_choices,
            high_impact_choices=high_impact_choices,
        )

        return result

    def analyze_menu(self, menu: MenuNode, graph: StoryGraph) -> ChoiceImpact:
        """
        Analyze impact of a single menu.

        Evaluates three dimensions:
        1. Variable Impact: Do choices modify game state?
        2. Path Divergence: Do choices lead to different labels?
        3. Ending Impact: Do choices affect which endings are reachable?

        Args:
            menu: Menu to analyze
            graph: Story graph

        Returns:
            Choice impact analysis
        """
        impact = ChoiceImpact(menu_id=menu.menu_id)

        # 1. Variable Impact
        impact.variable_impact = self._has_variable_impact(menu)
        if impact.variable_impact:
            impact.modified_vars = self._get_modified_variables(menu)

        # 2. Path Divergence
        impact.path_divergence = self._has_path_divergence(menu)

        # 3. Ending Impact
        impact.ending_impact = self._analyze_ending_impact(menu, graph)

        # Calculate overall impact score
        impact.score = self._calculate_impact_score(impact)

        # Classify impact level
        if impact.score < self.min_impact_threshold:
            impact.is_trivial = True
        elif impact.score >= 0.7:
            impact.is_high_impact = True

        return impact

    def _has_variable_impact(self, menu: MenuNode) -> bool:
        """Check if any choice modifies variables"""
        for choice in menu.choices:
            if choice.modifies_variables:
                return True
        return False

    def _get_modified_variables(self, menu: MenuNode) -> Set[str]:
        """Get all variables modified by menu choices"""
        modified = set()
        for choice in menu.choices:
            modified.update(choice.modifies_variables)
        return modified

    def _has_path_divergence(self, menu: MenuNode) -> bool:
        """Check if choices lead to different destinations"""
        destinations = set()

        for choice in menu.choices:
            if choice.destination:
                destinations.add(choice.destination)

        # True divergence means more than one unique destination
        return len(destinations) > 1

    def _analyze_ending_impact(
        self, menu: MenuNode, graph: StoryGraph
    ) -> Dict[str, Set[str]]:
        """
        Analyze which endings are reachable from each choice.

        Args:
            menu: Menu to analyze
            graph: Story graph

        Returns:
            Dictionary mapping choice_id to set of reachable endings
        """
        from branchpy.reachability_analyzer import ReachabilityAnalyzer

        analyzer = ReachabilityAnalyzer()
        terminal_labels = graph.get_terminal_labels()
        ending_impact: Dict[str, Set[str]] = {}

        for choice in menu.choices:
            if not choice.destination:
                ending_impact[choice.choice_id] = set()
                continue

            # Compute reachability from this choice's destination
            reachable = analyzer.compute_reachability(graph, start=choice.destination)

            # Find which endings are reachable
            reachable_endings = reachable & terminal_labels
            ending_impact[choice.choice_id] = reachable_endings

            # Mark if this choice affects endings
            choice.affects_ending = len(reachable_endings) > 0

        return ending_impact

    def _calculate_impact_score(self, impact: ChoiceImpact) -> float:
        """
        Calculate overall impact score (0.0 to 1.0).

        Scoring:
        - Variable impact: +0.3
        - Path divergence: +0.3
        - Different endings reachable: +0.4

        Args:
            impact: Choice impact data

        Returns:
            Score from 0.0 (no impact) to 1.0 (high impact)
        """
        score = 0.0

        # Variable modifications
        if impact.variable_impact:
            score += 0.3

        # Path divergence
        if impact.path_divergence:
            score += 0.3

        # Ending impact (different endings reachable)
        unique_endings = len(
            set(frozenset(endings) for endings in impact.ending_impact.values())
        )

        if unique_endings > 1:
            # Different choices lead to different endings
            score += 0.4

        return min(score, 1.0)

    def _is_false_choice(self, menu: MenuNode, graph: StoryGraph) -> bool:
        """
        Detect if menu is a false choice (all options lead to same outcome).

        A false choice has:
        - All choices leading to the same destination
        - No variable modifications
        - No meaningful difference between options

        Args:
            menu: Menu to check
            graph: Story graph

        Returns:
            True if this is a false choice
        """
        if not self.config.get("check_false_choices", True):
            return False

        # Check destinations
        destinations = [
            choice.destination for choice in menu.choices if choice.destination
        ]

        if not destinations:
            return False

        # All destinations the same?
        unique_destinations = set(destinations)

        if len(unique_destinations) == 1:
            # All lead to same place - check if any variable changes
            has_var_changes = any(choice.modifies_variables for choice in menu.choices)

            if not has_var_changes:
                return True  # Definitely a false choice

        return False

    def get_trivial_choices(self, result: ChoiceAnalysisResult) -> List[str]:
        """Get list of trivial/low-impact choice IDs"""
        return [
            menu_id
            for menu_id, impact in result.choice_impacts.items()
            if impact.is_trivial
        ]

    def get_high_impact_choices(self, result: ChoiceAnalysisResult) -> List[str]:
        """Get list of high-impact choice IDs"""
        return [
            menu_id
            for menu_id, impact in result.choice_impacts.items()
            if impact.is_high_impact
        ]


# Convenience function
def analyze_choice_impact(
    graph: StoryGraph, config: Optional[Dict[str, Any]] = None
) -> ChoiceAnalysisResult:
    """Convenience function to run choice impact analysis"""
    analyzer = ChoiceImpactAnalyzer(config)
    return analyzer.analyze(graph)
