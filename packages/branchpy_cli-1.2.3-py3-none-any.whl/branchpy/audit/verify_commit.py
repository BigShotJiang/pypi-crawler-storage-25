from __future__ import annotations

import re
import subprocess
from pathlib import Path


def extract_trailer_from_commit(rev: str = "HEAD") -> str | None:
    """Extract BranchPy-Audit-Hash trailer from a commit message."""
    try:
        out = subprocess.check_output(
            ["git", "show", "-s", "--format=%B", rev],
            encoding="utf-8",
            errors="replace",
            stderr=subprocess.DEVNULL,
        )
        m = re.search(r"BranchPy-Audit-Hash:\s*([0-9a-fA-F]{64})", out)
        return m.group(1) if m else None
    except subprocess.CalledProcessError:
        return None


def verify_audit_chain(audit_log: Path, rev: str = "HEAD") -> bool:
    """
    Verify that the commit trailer matches the current audit log hash.
    Returns True if valid, False if mismatch or missing.
    """
    from branchpy.git.trailers import compute_audit_hash

    trailer_hash = extract_trailer_from_commit(rev)
    if not trailer_hash:
        return False  # No trailer found

    current_hash = compute_audit_hash(audit_log)
    return trailer_hash == current_hash
