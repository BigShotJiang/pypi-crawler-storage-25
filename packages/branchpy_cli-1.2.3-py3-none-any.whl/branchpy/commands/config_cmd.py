# branchpy/commands/config_cmd.py
"""
Project configuration management command.
Allows users to view, set, and manage .branchpy.toml project settings.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

from branchpy.project_config import (
    find_project_config_file,
    load_project_config,
    save_project_config,
)


def cmd_config(args: argparse.Namespace) -> int:
    """Handle the config subcommand."""
    project_path = Path(getattr(args, "project", ".")).resolve()

    if args.action == "show":
        return _show_config(project_path, args.format == "json")
    elif args.action == "get":
        return _get_config_value(project_path, args.key, args.format == "json")
    elif args.action == "set":
        return _set_config_value(project_path, args.key, args.value)
    elif args.action == "unset":
        return _unset_config_value(project_path, args.key)
    elif args.action == "init":
        return _init_config(project_path, args.name, args.description)
    else:
        print(f"Unknown config action: {args.action}")
        return 2


def _show_config(project_path: Path, as_json: bool = False) -> int:
    """Show current project configuration."""
    config = load_project_config(project_path)
    config_file = find_project_config_file(project_path)

    if as_json:
        result = {
            "config_file": str(config_file) if config_file else None,
            "config": config.to_dict(),
        }
        print(json.dumps(result, indent=2))
    else:
        print("BranchPy Project Configuration")
        print("=" * 35)

        if config_file:
            print(f"Config file: {config_file}")
        else:
            print("Config file: not found (using defaults)")
        print()

        data = config.to_dict()
        if not data:
            print("No configuration set (all defaults)")
        else:
            # Group settings for better readability
            _print_config_group("Project", data, ["name", "description"])
            _print_config_group(
                "Media defaults",
                data,
                ["media_exts", "media_ignore", "media_assets_root"],
            )
            _print_config_group(
                "Tests defaults", data, ["tests_save_report", "tests_format"]
            )
            _print_config_group("Compare defaults", data, ["compare_format"])
            _print_config_group(
                "Watch mode",
                data,
                [
                    "watch_debounce_ms",
                    "watch_include",
                    "watch_exclude",
                    "watch_default_command",
                ],
            )
            _print_config_group(
                "Serve mode",
                data,
                ["serve_port", "serve_auth", "serve_auto_open", "serve_headless"],
            )
            _print_config_group(
                "Logs", data, ["logs_level", "logs_max_lines", "logs_format"]
            )
            _print_config_group(
                "Control Center UI",
                data,
                [
                    "ui_auto_update",
                    "ui_renpy_path",
                    "ui_patch_directory",
                    "ui_media_scan_depth",
                    "ui_notifications_verbosity",
                ],
            )
            _print_config_group("Advanced", data, ["patch_rotation_limit", "log_level"])

            # Show any custom settings
            custom_keys = set(data.keys()) - {
                "name",
                "description",
                "media_exts",
                "media_ignore",
                "media_assets_root",
                "tests_save_report",
                "tests_format",
                "compare_format",
                "watch_debounce_ms",
                "watch_include",
                "watch_exclude",
                "watch_default_command",
                "serve_port",
                "serve_auth",
                "serve_auto_open",
                "serve_headless",
                "logs_level",
                "logs_max_lines",
                "logs_format",
                "ui_auto_update",
                "ui_renpy_path",
                "ui_patch_directory",
                "ui_media_scan_depth",
                "ui_notifications_verbosity",
                "patch_rotation_limit",
                "log_level",
            }
            if custom_keys:
                _print_config_group("Custom", data, list(custom_keys))

    return 0


def _get_config_value(project_path: Path, key: str, as_json: bool = False) -> int:
    """Get a specific configuration value."""
    config = load_project_config(project_path)
    data = config.to_dict()

    if key not in data:
        if as_json:
            print(json.dumps({"error": f"Key '{key}' not found"}))
        else:
            print(f"Key '{key}' not found in configuration")
        return 1

    value = data[key]
    if as_json:
        print(json.dumps({key: value}))
    else:
        print(f"{key} = {_format_value(value)}")

    return 0


def _set_config_value(project_path: Path, key: str, value: str) -> int:
    """Set a configuration value."""
    config = load_project_config(project_path)

    # Convert string value to appropriate type
    typed_value = _convert_value(value)

    # Update the config
    if hasattr(config, key):
        setattr(config, key, typed_value)
    else:
        config.custom[key] = typed_value

    # Save the configuration
    if save_project_config(project_path, config):
        print(f"Set {key} = {_format_value(typed_value)}")
        config_file = project_path / ".branchpy.toml"
        print(f"Updated {config_file}")
        return 0
    else:
        print("Failed to save configuration")
        return 1


def _unset_config_value(project_path: Path, key: str) -> int:
    """Remove a configuration value."""
    config = load_project_config(project_path)

    # Check if it's a known field or custom field
    if hasattr(config, key):
        # Reset to default value
        from branchpy.project_config import ProjectConfig

        default_config = ProjectConfig.default()
        default_value = getattr(default_config, key)
        setattr(config, key, default_value)
    elif key in config.custom:
        del config.custom[key]
    else:
        print(f"Key '{key}' not found in configuration")
        return 1

    # Save the configuration
    if save_project_config(project_path, config):
        print(f"Unset {key}")
        config_file = project_path / ".branchpy.toml"
        print(f"Updated {config_file}")
        return 0
    else:
        print("Failed to save configuration")
        return 1


def _init_config(
    project_path: Path, name: str | None = None, description: str | None = None
) -> int:
    """Initialize a new project configuration file at .branchpy/branchpy.toml (canonical)."""
    branchpy_dir = project_path / ".branchpy"
    config_file = branchpy_dir / "branchpy.toml"

    if config_file.exists():
        print(f"Configuration file already exists: {config_file}")
        print("Use 'branchpy config set' to modify existing settings")
        return 1

    # Create initial config
    from branchpy.project_config import ProjectConfig

    config = ProjectConfig()

    if name:
        config.name = name
    if description:
        config.description = description

    # Set some sensible defaults
    config.tests_save_report = True

    if save_project_config(project_path, config):
        print(f"Initialized configuration: {config_file}")
        print()
        print("Example usage:")
        print("  branchpy config set media_exts '.png,.jpg,.webp'")
        print("  branchpy config set tests_format 'json'")
        print("  branchpy config show")
        return 0
    else:
        print("Failed to create configuration file")
        return 1


def _print_config_group(title: str, data: Dict[str, Any], keys: list[str]) -> None:
    """Print a group of configuration settings."""
    group_data = {k: v for k, v in data.items() if k in keys}
    if not group_data:
        return

    print(f"{title}:")
    for key, value in group_data.items():
        print(f"  {key} = {_format_value(value)}")
    print()


def _format_value(value: Any) -> str:
    """Format a value for display."""
    if isinstance(value, str):
        return f'"{value}"'
    elif isinstance(value, bool):
        return str(value).lower()
    else:
        return str(value)


def _convert_value(value: str) -> Any:
    """Convert a string value to the appropriate type."""
    # Try boolean
    if value.lower() in ("true", "false"):
        return value.lower() == "true"

    # Try integer
    try:
        return int(value)
    except ValueError:
        pass

    # Try float
    try:
        return float(value)
    except ValueError:
        pass

    # Return as string
    return value


def add_parser(subparsers):
    """Add the config subcommand parser."""
    parser = subparsers.add_parser(
        "config",
        help="Manage project configuration (.branchpy.toml)",
        description="View and modify project-specific BranchPy configuration settings.",
    )

    parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    subparsers_config = parser.add_subparsers(dest="action", required=True)

    # show subcommand
    show_parser = subparsers_config.add_parser(
        "show", help="Show current configuration"
    )

    # get subcommand
    get_parser = subparsers_config.add_parser(
        "get", help="Get a specific configuration value"
    )
    get_parser.add_argument("key", help="Configuration key to retrieve")

    # set subcommand
    set_parser = subparsers_config.add_parser("set", help="Set a configuration value")
    set_parser.add_argument("key", help="Configuration key to set")
    set_parser.add_argument("value", help="Value to set")

    # unset subcommand
    unset_parser = subparsers_config.add_parser(
        "unset", help="Remove a configuration value"
    )
    unset_parser.add_argument("key", help="Configuration key to remove")

    # init subcommand
    init_parser = subparsers_config.add_parser(
        "init", help="Initialize a new project configuration file"
    )
    init_parser.add_argument("--name", help="Project name")
    init_parser.add_argument("--description", help="Project description")

    parser.set_defaults(handler=cmd_config)
