# branchpy/commands/projects_cmd.py
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ..config_store import ConfigStore


def cmd_projects(args: argparse.Namespace) -> int:
    store = ConfigStore()
    cfg = store.cfg

    if args.action == "add":
        path = Path(args.path).expanduser().resolve()
        cfg.set_project(args.name, str(path))
        store.save()
        print(f"Added '{args.name}' → {path}")
        return 0

    if args.action == "remove":
        ok = cfg.remove_project(args.name)
        store.save()
        print("Removed." if ok else "Not found.")
        return 0

    if args.action == "rename":
        ok = cfg.rename_project(args.old, args.new)
        store.save()
        print("Renamed." if ok else "Failed (exists or missing).")
        return 0

    if args.action == "list":
        out = {
            "default": cfg.default_project,
            "projects": cfg.projects,
        }
        if args.json:
            print(json.dumps(out, ensure_ascii=False, indent=2))
        else:
            print("=== Projects ===")
            if not out["projects"]:
                print("(none)")
            for name, path in out["projects"].items():
                star = " *default" if name == out["default"] else ""
                print(f"- {name}: {path}{star}")
        return 0

    if args.action == "set-default":
        name_or_path = args.name_or_path
        if name_or_path in cfg.projects:
            cfg.set_default_project(name_or_path)
            store.save()
            print(f"Default set → {cfg.projects[name_or_path]}")
            return 0
        p = Path(name_or_path).expanduser().resolve()
        if p.exists():
            # Check if this path is already registered under a different name.
            # If so, reuse that name instead of creating a duplicate entry.
            existing_name = next(
                (
                    name
                    for name, path in cfg.projects.items()
                    if Path(path).resolve() == p
                ),
                None,
            )
            if existing_name:
                cfg.set_default_project(existing_name)
                store.save()
                print(f"Default set → {p} (existing name: '{existing_name}')")
                return 0
            synth = p.name
            cfg.set_project(synth, str(p))
            cfg.set_default_project(synth)
            store.save()
            print(f"Default set → {p} (registered as '{synth}')")
            return 0
        print("Failed to set default.")
        return 1

    if args.action == "show":
        if args.name in cfg.projects:
            print(cfg.projects[args.name])
            return 0
        print("Not found.")
        return 1

    if args.action == "clean":
        import re as _re

        _HASH_SUFFIX = _re.compile(r"-[0-9a-f]{6}$")
        dry_run = args.dry_run
        to_remove: list[str] = []
        seen_resolved: dict[str, str] = {}  # resolved_path → first (best) name kept
        _default = cfg.default_project

        # Deduplication priority (lowest sort key = processed first = kept):
        #   1. The current default_project name always wins.
        #   2. Non-hash-suffixed names before hash-suffixed ones (e.g. "mygame" before "mygame-5aa897").
        #   3. Alphabetically among ties.
        def _sort_key(n: str) -> tuple:
            return (
                0 if n == _default else 1,
                1 if _HASH_SUFFIX.search(n) else 0,
                n,
            )

        for name in sorted(cfg.projects.keys(), key=_sort_key):
            raw_path = cfg.projects[name]
            resolved = (
                str(Path(raw_path).expanduser().resolve()).replace("\\", "/").lower()
            )

            # 1. Stale: path no longer exists on disk.
            if not Path(raw_path).expanduser().exists():
                to_remove.append(name)
                continue

            # 2. Temp/pytest pollution: path lives inside a system temp dir.
            norm = raw_path.replace("\\", "/").lower()
            if (
                "pytest-of-" in norm
                or "/appdata/local/temp/" in norm
                or "/tmp/" in norm
            ):
                to_remove.append(name)
                continue

            # 3. Duplicate path: same resolved path already claimed by an earlier entry.
            if resolved in seen_resolved:
                to_remove.append(name)
                continue

            seen_resolved[resolved] = name

        if not to_remove:
            print("Registry is clean — nothing to remove.")
            return 0

        for name in to_remove:
            label = (
                "(stale)"
                if not Path(cfg.projects[name]).expanduser().exists()
                else "(dup/temp)"
            )
            print(
                f"{'[dry-run] ' if dry_run else ''}remove {label}: {name!r} → {cfg.projects[name]}"
            )

        if not dry_run:
            for name in to_remove:
                cfg.remove_project(name)
            store.save()
            print(
                f"\nRemoved {len(to_remove)} entr{'y' if len(to_remove) == 1 else 'ies'}."
            )
        else:
            print(
                f"\n{len(to_remove)} entr{'y' if len(to_remove) == 1 else 'ies'} would be removed. Run without --dry-run to apply."
            )
        return 0

    return 2


def add_parser(subparsers):
    from ..cli_help import HelpFmt, fmt_examples

    p = subparsers.add_parser(
        "projects",
        help="Manage friendly project names and defaults.",
        description="Register, list, rename, and set a default project.",
        epilog=fmt_examples(
            "branchpy projects add mygame C:/VN/tests/game",
            "branchpy projects list",
            "branchpy projects set-default mygame",
            "branchpy projects rename mygame mygame2",
            "branchpy projects remove mygame2",
            "branchpy projects show mygame",
            "branchpy projects list --json",
            "branchpy projects set-default C:/VN/tests/game",
            "branchpy projects clean --dry-run",
            "branchpy projects clean",
        ),
        formatter_class=HelpFmt,  # optional if you want nice help formatting
    )

    sp = p.add_subparsers(dest="action", required=True)

    # Each sub-action (add, remove, list, etc.)
    a = sp.add_parser("add", help="Add a project mapping.")
    a.add_argument("name")
    a.add_argument("path")

    r = sp.add_parser("remove", help="Remove a project mapping.")
    r.add_argument("name")

    rn = sp.add_parser("rename", help="Rename a project mapping.")
    rn.add_argument("old")
    rn.add_argument("new")

    ls = sp.add_parser("list", help="List all projects.")
    ls.add_argument("--json", action="store_true")

    sd = sp.add_parser(
        "set-default", help="Set default project (by name or absolute path)."
    )
    sd.add_argument("name_or_path")

    sh = sp.add_parser("show", help="Show path for a project name.")
    sh.add_argument("name")

    cl = sp.add_parser(
        "clean",
        help="Remove stale, temp/pytest, and duplicate entries from the registry.",
    )
    cl.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what would be removed without writing changes.",
    )

    # Assign the handler for all project subcommands
    p.set_defaults(handler=cmd_projects)
