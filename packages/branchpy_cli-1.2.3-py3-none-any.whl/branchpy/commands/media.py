# branchpy/commands/media.py
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, Set, Tuple

from branchpy.scan_context import ScanContext

# very simple Ren'Py reference extractor (extend as needed)
REF_IMG = re.compile(r'(?m)^\s*(image|show|scene)\s+.+?"([^"]+)"')
REF_SND = re.compile(r'(?m)^\s*(play (music|sound))\s+"([^"]+)"')


def _collect_references(files: Iterable[Path]) -> Tuple[Set[str], Set[str]]:
    imgs, snds = set(), set()
    for f in files:
        try:
            t = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        for m in REF_IMG.finditer(t):
            imgs.add(m.group(2))
        for m in REF_SND.finditer(t):
            # m.group(4) because of the nested groups
            snds.add(m.group(4))
    return imgs, snds


def _normalize_disk_paths(root: Path, paths: Iterable[Path]) -> Set[str]:
    # Return forward-slash normalized relative paths as used in scripts
    out = set()
    for p in paths:
        rel = p.relative_to(root).as_posix()
        out.add(rel)
    return out


def cmd_media(
    ctx: ScanContext,
    *,
    missing: bool,
    unused: bool,
    referenced: bool,
    exts: str,
    as_json: bool,
) -> Dict[str, Any]:
    # Determine mode
    if missing:
        mode = "missing"
    elif unused:
        mode = "unused"
    elif referenced:
        mode = "referenced"
    else:
        mode = "unknown"

    result: Dict[str, Any] = {"mode": mode, "summary": {}}

    if missing:
        ref_imgs, ref_snds = _collect_references(ctx.rpy_files)
        disk_imgs = _normalize_disk_paths(ctx.assets_root, ctx.image_files)
        disk_snds = _normalize_disk_paths(ctx.assets_root, ctx.sound_files)

        miss_imgs = sorted(ref_imgs - disk_imgs)
        miss_snds = sorted(ref_snds - disk_snds)

        items = []
        # optional: augment with file/line if you have earlier parse metadata
        items += [{"kind": "img", "value": v} for v in miss_imgs]
        items += [{"kind": "snd", "value": v} for v in miss_snds]

        result["summary"]["missing"] = len(items)
        result["missing"] = items

    if unused:
        # Filter by extensions requested
        allow = {
            e.strip().lower() if e.strip().startswith(".") else f".{e.strip().lower()}"
            for e in exts.split(",")
        }
        disk = [
            p
            for p in (list(ctx.image_files) + list(ctx.sound_files))
            if p.suffix.lower() in allow
        ]

        ref_imgs, ref_snds = _collect_references(ctx.rpy_files)
        ref_set = ref_imgs | ref_snds

        on_disk_rel = _normalize_disk_paths(ctx.assets_root, disk)
        unused_rel = sorted(on_disk_rel - ref_set)

        result["summary"]["unused"] = len(unused_rel)
        result["unused"] = [{"value": v} for v in unused_rel]

    if referenced:
        # Filter by extensions requested
        allow = {
            e.strip().lower() if e.strip().startswith(".") else f".{e.strip().lower()}"
            for e in exts.split(",")
        }
        disk = [
            p
            for p in (list(ctx.image_files) + list(ctx.sound_files))
            if p.suffix.lower() in allow
        ]

        ref_imgs, ref_snds = _collect_references(ctx.rpy_files)
        ref_set = ref_imgs | ref_snds

        on_disk_rel = _normalize_disk_paths(ctx.assets_root, disk)
        referenced_rel = sorted(
            on_disk_rel & ref_set
        )  # Intersection: files on disk AND referenced

        result["summary"]["referenced"] = len(referenced_rel)
        result["referenced"] = referenced_rel  # Flat array of strings for easy parsing

    if as_json:
        print(json.dumps(result, indent=2))
    else:
        mode = result["mode"]
        print(f"[media:{mode}] summary: {result.get('summary')}")
        if missing:
            key = "missing"
        elif unused:
            key = "unused"
        elif referenced:
            key = "referenced"
        else:
            key = None
        if key:
            for it in result.get(key, []):
                print(f" - {it}")

    return result
