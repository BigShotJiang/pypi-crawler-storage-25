#!/usr/bin/env python3
"""
Semantics extraction command - automatically generate semantics.yaml
by scanning Ren'Py project files for custom functions, variables, and patterns.
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Any, Dict

import yaml

from branchpy import logs


def cmd_semantics(args: argparse.Namespace) -> int:
    """Handle the semantics subcommand."""
    project_path = Path(getattr(args, "project", ".")).resolve()

    if args.action == "generate":
        return _generate_semantics(project_path, args.output, args.force)
    elif args.action == "validate":
        return _validate_semantics(project_path)
    else:
        print(f"Unknown semantics action: {args.action}")
        return 2


def _generate_semantics(
    project_path: Path, output_path: str | None, force: bool
) -> int:
    """
    Scan Ren'Py project and auto-generate semantics.yaml.

    Extracts:
    - Custom Python functions that might be jump helpers
    - Default variables and their types
    - Stat boundaries/ranges
    - Character definitions
    - Custom control flow patterns
    """
    logs.info("semantics.generate", msg=f"Scanning {project_path} for semantics")

    # Find game directory
    game_dir = project_path / "game"
    if not game_dir.exists():
        print(f"Error: game directory not found at {game_dir}")
        return 1

    # Find all .rpy files
    rpy_files = list(game_dir.glob("**/*.rpy"))
    if not rpy_files:
        print(f"Error: No .rpy files found in {game_dir}")
        return 1

    logs.info("semantics.scan", msg=f"Found {len(rpy_files)} .rpy files")

    # Extract semantics
    semantics = {
        "variables": {},
        "functions": {},
        "characters": {},
        "stat_bounds": {},
        "jump_helpers": [],
        "metadata": {"generated_from": str(project_path), "file_count": len(rpy_files)},
    }

    for rpy_file in rpy_files:
        try:
            content = rpy_file.read_text(encoding="utf-8")
            _extract_from_file(content, rpy_file.name, semantics)
        except Exception as e:
            logs.warn(
                "semantics.file_error", msg=f"Failed to process {rpy_file.name}: {e}"
            )

    # Determine output path
    if output_path:
        output_file = Path(output_path)
    else:
        output_file = project_path / ".branchpy" / "semantics.yaml"

    # Check if file exists
    if output_file.exists() and not force:
        print(f"Error: {output_file} already exists. Use --force to overwrite.")
        return 1

    # Create directory if needed
    output_file.parent.mkdir(parents=True, exist_ok=True)

    # Write YAML
    try:
        with output_file.open("w", encoding="utf-8") as f:
            yaml.dump(
                semantics,
                f,
                default_flow_style=False,
                sort_keys=False,
                allow_unicode=True,
            )

        print(f"✓ Generated semantics.yaml: {output_file}")
        print(f"  Variables: {len(semantics['variables'])}")
        print(f"  Functions: {len(semantics['functions'])}")
        print(f"  Characters: {len(semantics['characters'])}")
        print(f"  Stat bounds: {len(semantics['stat_bounds'])}")
        print(f"  Jump helpers: {len(semantics['jump_helpers'])}")

        return 0

    except Exception as e:
        print(f"Error writing {output_file}: {e}")
        return 1


def _validate_semantics(project_path: Path) -> int:
    """Validate existing semantics.yaml file."""
    semantics_file = project_path / ".branchpy" / "semantics.yaml"

    if not semantics_file.exists():
        print(f"Error: No semantics.yaml found at {semantics_file}")
        print("Run 'branchpy semantics generate' to create one")
        return 1

    try:
        with semantics_file.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        print(f"✓ Valid semantics.yaml: {semantics_file}")
        print(f"  Variables: {len(data.get('variables', {}))}")
        print(f"  Functions: {len(data.get('functions', {}))}")
        print(f"  Characters: {len(data.get('characters', {}))}")
        print(f"  Stat bounds: {len(data.get('stat_bounds', {}))}")
        print(f"  Jump helpers: {len(data.get('jump_helpers', []))}")

        return 0

    except Exception as e:
        print(f"Error: Invalid semantics.yaml: {e}")
        return 1


def _extract_from_file(content: str, filename: str, semantics: Dict[str, Any]) -> None:
    """Extract semantics from a single .rpy file."""

    # Extract default variables
    _extract_defaults(content, filename, semantics)

    # Extract Python functions
    _extract_functions(content, filename, semantics)

    # Extract characters
    _extract_characters(content, filename, semantics)

    # Extract stat bounds (STAT_BOUNDS dictionary)
    _extract_stat_bounds(content, filename, semantics)


def _extract_defaults(content: str, filename: str, semantics: Dict[str, Any]) -> None:
    """Extract default variable definitions."""
    # Pattern: default variable_name = value
    pattern = r"^\s*default\s+(\w+)\s*=\s*(.+?)\s*(?:#|$)"

    for match in re.finditer(pattern, content, re.MULTILINE):
        var_name = match.group(1)
        value_str = match.group(2).strip()

        # Infer type from value
        var_type = _infer_type(value_str)

        if var_name not in semantics["variables"]:
            semantics["variables"][var_name] = {
                "type": var_type,
                "default": value_str,
                "source": filename,
            }


def _extract_functions(content: str, filename: str, semantics: Dict[str, Any]) -> None:
    """Extract Python function definitions."""
    # Pattern: def function_name(params):
    pattern = r"^\s*def\s+(\w+)\s*\((.*?)\)\s*:"

    for match in re.finditer(pattern, content, re.MULTILINE):
        func_name = match.group(1)
        params = match.group(2).strip()

        # Check if it looks like a jump helper
        is_jump_helper = False
        if "jump" in func_name.lower() or "call" in func_name.lower():
            is_jump_helper = True
            if func_name not in semantics["jump_helpers"]:
                semantics["jump_helpers"].append(func_name)

        if func_name not in semantics["functions"]:
            semantics["functions"][func_name] = {
                "params": params,
                "source": filename,
                "is_jump_helper": is_jump_helper,
            }


def _extract_characters(content: str, filename: str, semantics: Dict[str, Any]) -> None:
    """Extract character definitions."""
    # Pattern: define character_name = Character(...)
    pattern = r"^\s*define\s+(\w+)\s*=\s*Character\s*\("

    for match in re.finditer(pattern, content, re.MULTILINE):
        char_name = match.group(1)

        if char_name not in semantics["characters"]:
            semantics["characters"][char_name] = {"source": filename}


def _extract_stat_bounds(
    content: str, filename: str, semantics: Dict[str, Any]
) -> None:
    """Extract STAT_BOUNDS or similar stat range definitions."""
    # Pattern: STAT_BOUNDS = { ... }
    # Look for dictionary definitions with stat names

    # Simple pattern: "stat_name": (min, max)
    pattern = r'["\'](\w+)["\']\s*:\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)'

    for match in re.finditer(pattern, content):
        stat_name = match.group(1)
        min_val = int(match.group(2))
        max_val = int(match.group(3))

        if stat_name not in semantics["stat_bounds"]:
            semantics["stat_bounds"][stat_name] = {
                "min": min_val,
                "max": max_val,
                "source": filename,
            }


def _infer_type(value_str: str) -> str:
    """Infer variable type from default value string."""
    value_str = value_str.strip()

    # Boolean
    if value_str in ("True", "False"):
        return "boolean"

    # None
    if value_str == "None":
        return "unknown"

    # Number
    if re.match(r"^-?\d+(\.\d+)?$", value_str):
        return "number"

    # String
    if value_str.startswith(('"', "'", 'f"', "f'")):
        return "string"

    # List
    if value_str.startswith("["):
        return "collection"

    # Dict
    if value_str.startswith("{"):
        return "enum" if ":" in value_str else "collection"

    return "unknown"


def register_semantics_parser(subparsers) -> None:
    """Register semantics command with argparse."""
    semantics_parser = subparsers.add_parser(
        "semantics",
        help="Extract and manage project semantics (variables, functions, patterns)",
        description="Auto-generate semantics.yaml by scanning Ren'Py files",
    )

    semantics_subparsers = semantics_parser.add_subparsers(dest="action", required=True)

    # Generate subcommand
    generate_parser = semantics_subparsers.add_parser(
        "generate", help="Scan Ren'Py files and generate semantics.yaml"
    )
    generate_parser.add_argument(
        "-o",
        "--output",
        help="Output path for semantics.yaml (default: .branchpy/semantics.yaml)",
    )
    generate_parser.add_argument(
        "-f", "--force", action="store_true", help="Overwrite existing semantics.yaml"
    )
    generate_parser.add_argument(
        "--project", default=".", help="Project directory (default: current directory)"
    )

    # Validate subcommand
    validate_parser = semantics_subparsers.add_parser(
        "validate", help="Validate existing semantics.yaml"
    )
    validate_parser.add_argument(
        "--project", default=".", help="Project directory (default: current directory)"
    )

    semantics_parser.set_defaults(func=cmd_semantics)
