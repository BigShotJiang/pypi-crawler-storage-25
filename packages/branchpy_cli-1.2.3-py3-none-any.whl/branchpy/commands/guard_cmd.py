# branchpy/commands/guard_cmd.py
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Literal, Optional, Set, Tuple, cast

# Reuse scanners directly for rich details
from . import media_cmd, stats_cmd

CONFIG_PATH = ".branchpy-guard.json"

# ---------------------------- config helpers ----------------------------


def _default_config(
    project=".",
    assets="game",
    checks="missing,unused,stats",
    strict="missing,unused",
    ext: Optional[str] = ".png,.webp,.ogg,.mp3",
    integration: Literal["none", "pre-push", "pre-commit", "workflow"] = "none",
) -> Dict:
    return {
        "project": project,
        "assets": assets,
        "checks": list({c.strip() for c in checks.split(",") if c.strip()}),
        "strict": list({s.strip() for s in strict.split(",") if s.strip()}),
        "ext": ext,
        "integration": integration,  # none | pre-push | pre-commit | workflow
    }


def _load_config(path: str = CONFIG_PATH) -> Dict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(
            f"{CONFIG_PATH} not found. Run: branchpy guard init ..."
        )
    return json.loads(p.read_text(encoding="utf-8"))


def _save_config(cfg: Dict, path: str = CONFIG_PATH) -> Path:
    p = Path(path)
    p.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    return p


# ---------------------------- run checks ----------------------------


def _result_missing(project: str, assets_root: str) -> Tuple[List[Dict], List[Dict]]:
    # replicate media_cmd.run_missing but return data instead of printing
    refs, skipped, _ = media_cmd._scan_project_for_media(project)  # type: ignore[attr-defined]
    missing = [r for r in refs if not media_cmd._exists_under_assets(assets_root, r["value"])]  # type: ignore[attr-defined]
    return missing, skipped


def _result_unused(project: str, assets_root: str, ext: Optional[str]) -> List[str]:
    exts = media_cmd._parse_exts(ext)  # type: ignore[attr-defined]
    on_disk = media_cmd._walk_assets(assets_root, exts)  # type: ignore[attr-defined]
    refs, _, _ = media_cmd._scan_project_for_media(project)  # type: ignore[attr-defined]
    ref_set = {media_cmd._norm(r["value"]).lower() for r in refs}  # type: ignore[attr-defined]
    return [p for p in on_disk if media_cmd._norm(p).lower() not in ref_set]  # type: ignore[attr-defined]


def _result_stats(project: str) -> Dict:
    # mimic stats_cmd.run() but return a dict
    assigns = stats_cmd._scan_assignments(project)  # type: ignore[attr-defined]
    types: Dict[str, Set[str]] = {}
    locations: Dict[str, List[str]] = {}
    for file, var, op, t, *_ in assigns:
        types.setdefault(var, set()).add(t)
        locations.setdefault(var, []).append(f"{file} ({op} {t})")

    issues: List[Dict] = []
    for var, tset in types.items():
        if "trust" in var.lower():
            if any(tt not in ("number", "unknown") for tt in tset):
                issues.append(
                    {
                        "var": var,
                        "issue": "trust-not-numeric",
                        "types": sorted(tset),
                        "where": locations.get(var, []),
                    }
                )
        if var.lower().startswith("is_") or var.lower().endswith("_flag"):
            if any(tt not in ("bool", "unknown") for tt in tset):
                issues.append(
                    {
                        "var": var,
                        "issue": "flag-not-bool",
                        "types": sorted(tset),
                        "hint": "Use True/False (avoid 0/1 or strings).",
                        "where": locations.get(var, []),
                    }
                )
        if len({tt for tt in tset if tt != "unknown"}) > 1:
            issues.append(
                {
                    "var": var,
                    "issue": "mixed-types",
                    "types": sorted(tset),
                    "where": locations.get(var, []),
                }
            )
    return {
        "summary": {"vars_seen": len(types), "issues": len(issues)},
        "issues": issues,
    }


def _print_details(title: str, lines: List[str]) -> None:
    print(f"\n== {title} ==")
    for ln in lines:
        print(ln)


def guard_run(cfg: Dict, as_json: bool = False) -> int:
    project = cfg["project"]
    assets = cfg["assets"]
    checks = set(cfg.get("checks", []))
    strict = set(cfg.get("strict", []))
    ext = cfg.get("ext") or None  # type: Optional[str]

    results: Dict[str, object] = {}

    exit_code = 0
    if "missing" in checks:
        missing, skipped = _result_missing(project, assets)
        results["missing"] = {"missing": missing, "skipped": skipped}
        if "missing" in strict and missing:
            exit_code = max(exit_code, 1)

    if "unused" in checks:
        unused = _result_unused(project, assets, ext)
        results["unused"] = {"unused": unused}
        if "unused" in strict and unused:
            exit_code = max(exit_code, 2)

    if "stats" in checks:
        st = _result_stats(project)
        results["stats"] = st
        # stats is warn-only unless user added it to strict (allowed)
        if "stats" in strict and st["summary"]["issues"] > 0:  # type: ignore[index]
            exit_code = max(exit_code, 3)

    if as_json:
        print(
            json.dumps(
                {"config": cfg, "results": results, "exit_code": exit_code},
                indent=2,
                ensure_ascii=False,
            )
        )
    else:
        # human-friendly failure detail (what/where/why)
        if "missing" in checks:
            ms = results["missing"]["missing"] if "missing" in results else []  # type: ignore[index]
            lines = [f"- {m['kind']}: {m['value']} @ {m['file']}" for m in ms]  # type: ignore[assignment]
            _print_details("Missing media", lines or ["(none)"])
        if "unused" in checks:
            uu = results["unused"]["unused"] if "unused" in results else []  # type: ignore[index]
            _print_details("Unused media", [f"- {p}" for p in uu] or ["(none)"])
        if "stats" in checks:
            st = results["stats"] if "stats" in results else {"issues": []}  # type: ignore[assignment]
            lines = []
            for it in st["issues"]:  # type: ignore[index]
                lines.append(
                    f"- {it['var']}: {it['issue']}  types={','.join(it['types'])}"
                )
                for w in it["where"][:5]:
                    lines.append(f"    • {w}")
                if "hint" in it:
                    lines.append(f"    hint: {it['hint']}")
            _print_details("Stats issues", lines or ["(none)"])
        if exit_code:
            print(f"\nGuard result: FAIL (exit {exit_code})")
        else:
            print("\nGuard result: OK")

    return exit_code


# ---------------------------- integrations ----------------------------

WORKFLOW_YML = """name: BranchPy Checks
on:
  push:
  pull_request:
jobs:
  branchpy:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: Install BranchPy (editable)
        shell: pwsh
        run: |
          python -m pip install --upgrade pip
          pip install -e .
      - name: BranchPy guard run
        shell: pwsh
        run: |
          $out = branchpy guard run --json
          $code = $LASTEXITCODE
          $out | Out-File -Encoding utf8 branchpy_guard.json
{fail_line}
      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: branchpy-reports
          path: branchpy_guard.json
"""

PRE_HOOK_BASH = """#!/usr/bin/env bash
# BranchPy guard ({kind})
set -euo pipefail
out=$(branchpy guard run{json})
code=$?
echo "$out" > branchpy_guard.json
{fail_line}
exit 0
"""


def _write(path: Path, content: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    try:
        os.chmod(path, 0o755)
    except Exception:
        pass
    return path


def _enable(
    kind: Literal["pre-push", "pre-commit", "workflow"], strict_fail: bool
) -> Path:
    if kind == "workflow":
        yml = WORKFLOW_YML.replace(
            "{fail_line}",
            "          if ($code -ne 0) { exit $code }" if strict_fail else "",
        )
        return _write(Path(".github/workflows/branchpy.yml"), yml)
    else:
        content = PRE_HOOK_BASH.format(
            kind=kind,
            json=" --json",
            fail_line=(
                "exit $code" if strict_fail else "echo 'Guard WARN-only; continuing...'"
            ),
        )
        return _write(Path(f".git/hooks/{kind}"), content)


def _disable(kind: Literal["pre-push", "pre-commit", "workflow"]) -> None:
    p = (
        Path(".github/workflows/branchpy.yml")
        if kind == "workflow"
        else Path(f".git/hooks/{kind}")
    )
    if p.exists():
        p.unlink()


# ---------------------------- CLI entry ----------------------------


def run(
    action: Literal["init", "enable", "disable", "run"] | None,
    # shared
    project: str = ".",
    assets: str = "game",
    checks: str = "missing,unused,stats",
    strict: str = "missing,unused",
    ext: Optional[str] = ".png,.webp,.ogg,.mp3",
    # integration
    integration: Literal["none", "pre-push", "pre-commit", "workflow"] = "none",
    # output
    json_out: bool = False,
    # NEW (no-op for now)
    dot_path: Optional[str] = None,
    png_path: Optional[str] = None,
) -> int:
    if action is None:
        print("branchpy guard: choose one of init | enable | disable | run")
        return 2

    # NICE: if a user passes graph flags before we implement them, tell them gently
    if (dot_path or png_path) and action != "run":
        print(
            "Note: --dot/--png are only meaningful with `guard run` and are not yet implemented."
        )
    elif (dot_path or png_path) and action == "run":
        print(
            "Note: `guard run` graph output (--dot/--png) is not implemented yet; ignoring flags."
        )

    if action is None:
        print("branchpy guard: choose one of init | enable | disable | run")
        return 2

    if action == "init":
        cfg = _default_config(project, assets, checks, strict, ext, integration)
        _save_config(cfg)
        print(f"Created {CONFIG_PATH} (integration='{integration}')")
        if integration != "none":
            kind = cast(Literal["pre-push", "pre-commit", "workflow"], integration)
            _enable(integration, strict_fail=bool(set(cfg["strict"])))
            print(f"Enabled {integration}.")
        return 0

    if action == "run":
        cfg = _load_config()
        return guard_run(cfg, as_json=json_out)

    if action == "enable":
        cfg = _load_config()
        cfg["integration"] = integration
        _save_config(cfg)
        if integration == "none":
            print("Integration set to 'none' in config. No hook/workflow created.")
        else:
            kind = cast(Literal["pre-push", "pre-commit", "workflow"], integration)
            _enable(kind, strict_fail=bool(set(cfg["strict"])))
            print(f"Enabled {integration}.")
        return 0

    if action == "disable":
        if integration == "none":
            print("Nothing to disable: pick 'pre-push', 'pre-commit', or 'workflow'.")
        else:
            kind = cast(Literal["pre-push", "pre-commit", "workflow"], integration)
            _disable(kind)
            print(f"Disabled {integration}.")
        return 0

    return 2


def add_parser(subparsers):
    """
    Register the guard command with argparse.
    """
    parser = subparsers.add_parser(
        "guard",
        help="Configure and run project quality guards (missing media, unused assets, stats checks)",
    )

    # Subcommands
    parser.add_argument(
        "action",
        nargs="?",
        choices=["init", "run", "enable", "disable"],
        help="Action to perform: init (create config), run (execute checks), enable/disable (integration)",
    )

    # Options
    parser.add_argument(
        "--project", default=".", help="Project root path (default: current directory)"
    )
    parser.add_argument(
        "--assets",
        default="game",
        help="Assets directory relative to project (default: game)",
    )
    parser.add_argument(
        "--checks", default="missing,unused,stats", help="Comma-separated checks to run"
    )
    parser.add_argument(
        "--strict",
        default="missing,unused",
        help="Comma-separated checks that fail on violations",
    )
    parser.add_argument(
        "--ext",
        default=".png,.webp,.ogg,.mp3",
        help="File extensions to check (comma-separated)",
    )
    parser.add_argument(
        "--integration",
        choices=["none", "pre-push", "pre-commit", "workflow"],
        default="none",
        help="Integration mode for guards",
    )
    parser.add_argument(
        "--json",
        dest="json_out",
        action="store_true",
        help="Output results in JSON format",
    )
    parser.add_argument(
        "--dot",
        help="Export guard graph to DOT file (flag accepted, output not yet implemented)",
    )
    parser.add_argument(
        "--png",
        help="Export guard graph to PNG file (flag accepted, output not yet implemented)",
    )

    def guard_handler(args):
        # Enforce unimplemented flags
        if args.dot:
            raise NotImplementedError(
                "--dot flag not yet implemented (DOT graph export pending)"
            )
        if args.png:
            raise NotImplementedError(
                "--png flag not yet implemented (PNG graph export pending)"
            )

        return run(
            action=(args.action or "run"),  # Default to 'run' when action omitted
            project=args.project,
            assets=args.assets,
            checks=args.checks,
            strict=args.strict,
            ext=args.ext,
            integration=args.integration,
            json_out=args.json_out,
            dot_path=None,  # Not implemented (enforced above)
            png_path=None,  # Not implemented (enforced above)
        )

    parser.set_defaults(handler=guard_handler)
