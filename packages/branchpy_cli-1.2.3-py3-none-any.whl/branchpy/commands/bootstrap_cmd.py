"""Bootstrap command for BranchPy CLI.

**Governance ID:** AXIS5-V0.9.2-REMOTE-BQS
**Workstream:** WS-R2 (Bootstrap Doctor)
**Version:** v0.9.2

Provides automatic CLI installation and setup for remote environments.
"""

import argparse
import json

from branchpy.remote.bootstrap_doctor import UnifiedBootstrapDoctor


def cmd_bootstrap_remote(args: argparse.Namespace) -> int:
    """Bootstrap BranchPy CLI in remote environment.

    Automatic installation for:
        - GitHub Codespaces
        - Docker containers
        - SSH remote sessions
        - WSL

    Args:
        args: Parsed command-line arguments

    Returns:
        Exit code (0 = success, 1 = warnings, 2 = failures)
    """
    doctor = UnifiedBootstrapDoctor()
    result = doctor.bootstrap_remote()

    if args.json:
        # JSON output
        output = {
            "category": result.category,
            "duration_ms": result.duration_ms,
            "checks": [
                {
                    "check_id": check.check_id,
                    "name": check.name,
                    "status": check.status.value,
                    "message": check.message,
                    "details": check.details,
                    "duration_ms": check.duration_ms,
                }
                for check in result.checks
            ],
            "summary": result.get_summary(),
            "metadata": result.metadata,
        }
        print(json.dumps(output, indent=2))
    else:
        # Human-readable output
        print("\n🚀 BranchPy Remote Bootstrap")
        print("=" * 60)

        for check in result.checks:
            icon = {"pass": "✓", "warn": "⚠️", "fail": "✗", "skip": "○"}.get(
                check.status.value, "?"
            )

            print(f"{icon} {check.name}: {check.message}")
            if check.details:
                print(f"  → {check.details}")

        print("\n" + "=" * 60)
        summary = result.get_summary()
        print(f"Total: {summary['total']} checks")
        print(f"  ✓ Passed: {summary['passed']}")
        if summary["warnings"] > 0:
            print(f"  ⚠️  Warnings: {summary['warnings']}")
        if summary["failed"] > 0:
            print(f"  ✗ Failed: {summary['failed']}")

        print(f"\nDuration: {result.duration_ms / 1000.0:.1f}s")

        if result.duration_ms > 30000.0:
            print("⚠️  Bootstrap exceeded 30s target")

    # Return appropriate exit code
    if result.has_failures():
        return 2  # Critical errors
    elif result.has_warnings():
        return 1  # Warnings
    else:
        return 0  # Success


def add_parser(subparsers):
    """Add bootstrap command parser.

    Args:
        subparsers: Subparsers from main argument parser
    """
    p = subparsers.add_parser(
        "bootstrap",
        help="Bootstrap BranchPy CLI in remote environments",
        description="Automatic installation and setup for GitHub Codespaces, Docker, SSH, WSL",
    )

    # Add 'remote' subcommand
    bootstrap_subparsers = p.add_subparsers(
        dest="bootstrap_command", help="Bootstrap subcommands"
    )

    p_remote = bootstrap_subparsers.add_parser(
        "remote",
        help="Bootstrap BranchPy CLI in detected remote environment",
        description="Automatically install BranchPy CLI in remote environment (Codespaces, Docker, SSH, WSL)",
    )

    p_remote.add_argument(
        "--json", action="store_true", help="Output results in JSON format"
    )

    p_remote.set_defaults(handler=cmd_bootstrap_remote)

    # Set default handler for 'bootstrap' (no subcommand)
    p.set_defaults(handler=lambda args: p.print_help())
