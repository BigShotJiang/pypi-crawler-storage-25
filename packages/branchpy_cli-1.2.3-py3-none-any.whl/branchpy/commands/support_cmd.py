# branchpy/commands/support_cmd.py
"""Support bundle generation command for BranchPy."""
from ..cli_help import HelpFmt, fmt_examples
from ..support_bundle import build_support_bundle


def run(args):
    """Generate a support bundle archive file."""
    try:
        bundle_path = build_support_bundle(
            since_hours=args.since,
            strict=args.strict,
            include_vscode=args.include_vscode,
            project_path=args.project if hasattr(args, "project") else None,
            format=args.format if hasattr(args, "format") else "zip",
        )

        # Determine actual format from file extension (may differ if fallback occurred)
        if ".tar.zst" in bundle_path:
            format_name = "TAR.ZSTD"
        elif ".tar.gz" in bundle_path:
            format_name = "TAR.GZ (zstandard unavailable)"
        else:
            format_name = "ZIP"

        print(f"Support bundle created ({format_name}): {bundle_path}")
        print()
        print("This bundle contains:")
        print("  - Recent log files (JSONL)")
        print("  - System information snapshot")
        print("  - Daemon metadata")
        print("  - Recent analysis reports (if available)")
        print()
        if args.strict:
            print("✓ Strict redaction applied (paths, emails, tokens, project IDs)")
        else:
            print("✓ Standard redaction applied (paths, emails, tokens)")
        print()
        print("Share this bundle with support@branchpy.com or attach to GitHub issues.")
        return 0
    except Exception as e:
        print(f"Error creating support bundle: {e}")
        return 1


def add_parser(subparsers):
    """Register the support command with the CLI parser."""
    support_p = subparsers.add_parser(
        "support",
        help="Generate support bundle for troubleshooting",
        description="Generate an archive bundle with recent logs and system information.",
        epilog=fmt_examples(
            "branchpy support",
            "branchpy support --since 72",
            "branchpy support --strict",
            "branchpy support --format tar.zst",
        ),
        formatter_class=HelpFmt,
    )
    support_p.set_defaults(handler=run)
    support_p.add_argument(
        "--since",
        type=int,
        default=48,
        help="Include logs from last N hours (default: 48)",
    )
    support_p.add_argument(
        "--format",
        type=str,
        choices=["zip", "tar.zst"],
        default="zip",
        help="Archive format: 'zip' or 'tar.zst' (default: zip)",
    )
    support_p.add_argument(
        "--strict",
        action="store_true",
        default=True,
        help="Use strict redaction (default: True)",
    )
    support_p.add_argument(
        "--no-strict",
        dest="strict",
        action="store_false",
        help="Disable strict redaction",
    )
    support_p.add_argument(
        "--include-vscode",
        action="store_true",
        default=True,
        help="Include VS Code logs (default: True)",
    )
    support_p.add_argument(
        "--no-vscode",
        dest="include_vscode",
        action="store_false",
        help="Exclude VS Code logs",
    )
