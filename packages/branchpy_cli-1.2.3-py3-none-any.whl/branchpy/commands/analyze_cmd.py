from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.metadata
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

from branchpy import logs
from branchpy.attribution import maybe_show_attribution_notice
from branchpy.config import load_config
from branchpy.core.project_model import ProjectModel

# Discovery layer (v1.1.0)
from branchpy.discovery import DiscoveryStatus, ProjectDiscovery
from branchpy.engines.renpy_engine import RenpyEngine

# v1.1.0 Phase 1: Production telemetry collector

# Telemetry integration (v1.0.0 Phase 2)
try:  # Axis5 v0.9.1: Safe import with fallbacks for static analysis
    from branchpy.telemetry import LocalTelemetryWriter as _RealLocalTelemetryWriter
    from branchpy.telemetry import TelemetryEvent as _RealTelemetryEvent
    from branchpy.telemetry import TelemetryMetric as _RealTelemetryMetric
    from branchpy.telemetry import TelemetrySession as _RealTelemetrySession
    from branchpy.telemetry import create_trace_id as _real_create_trace_id

    TELEMETRY_AVAILABLE = True
    LocalTelemetryWriter = _RealLocalTelemetryWriter  # type: ignore
    TelemetrySession = _RealTelemetrySession  # type: ignore
    TelemetryEvent = _RealTelemetryEvent  # type: ignore
    TelemetryMetric = _RealTelemetryMetric  # type: ignore
    create_trace_id = _real_create_trace_id  # type: ignore
except ImportError:
    TELEMETRY_AVAILABLE = False

    def create_trace_id():  # type: ignore
        return ""

    class LocalTelemetryWriter:  # type: ignore
        def __init__(self, *a, **kw):
            self.session_id = ""
            self.privacy = "minimal"

        def iso_now(self):
            return datetime.datetime.now().isoformat()

        def write_session(self, *a, **kw):
            pass

        def write_event(self, *a, **kw):
            pass

        def write_metric(self, *a, **kw):
            pass

    class TelemetrySession:  # type: ignore
        def __init__(self, *a, **kw):
            pass

    class TelemetryEvent:  # type: ignore
        def __init__(self, *a, **kw):
            pass

    class TelemetryMetric:  # type: ignore
        def __init__(self, *a, **kw):
            pass


def _write_json_output(payload: dict, out_path: Optional[str] = None) -> None:
    """Write JSON output to file or stdout.

    Args:
        payload: Analysis result dictionary
        out_path: Output file path, or None/'-' for stdout
    """
    json_data = json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False)

    if not out_path or out_path == "-":
        # Write UTF-8 directly to stdout.buffer to avoid Windows cp1252 encoding errors.
        # Fall back to str write when stdout is a StringIO (e.g. in-process test runner).
        if hasattr(sys.stdout, "buffer"):
            sys.stdout.buffer.write(json_data.encode("utf-8"))
            sys.stdout.buffer.write(b"\n")
            sys.stdout.buffer.flush()
        else:
            sys.stdout.write(json_data + "\n")
            sys.stdout.flush()
    else:
        try:
            output_file = Path(out_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_text(json_data, encoding="utf-8")
            print(f"[bpy] Analysis results written to: {output_file}", file=sys.stderr)
        except Exception as e:
            print(f"[bpy] Error writing output file: {e}", file=sys.stderr)
            sys.exit(1)


def _write_text_output(payload: dict, out_path: Optional[str] = None) -> None:
    """Write text output to file or stdout.

    Args:
        payload: Analysis result dictionary
        out_path: Output file path, or None/'-' for stdout
    """
    # Generate human-readable text output
    lines = []
    lines.append("=" * 60)
    lines.append("  BranchPy Analysis Summary")
    lines.append("=" * 60)
    lines.append(f"Project: {payload.get('project', 'Unknown')}")
    lines.append(f"Path:    {payload.get('path', 'Unknown')}")
    lines.append("")

    result = payload.get("result", {})
    summary = result.get("summary", {})

    lines.append("Core Metrics:")
    lines.append(f"  Labels:  {summary.get('labels', 0)}")
    lines.append(f"  Files:   {summary.get('files', 0)}")
    lines.append(f"  Issues:  {len(result.get('issues', []))}")

    if summary.get("duration"):
        lines.append(f"  Duration: {summary.get('duration', 0.0):.2f}s")
    if summary.get("labels_per_sec"):
        lines.append(f"  Speed:    {summary.get('labels_per_sec', 0.0):.1f} labels/sec")

    bqf = result.get("bqf_analyze")
    if bqf:
        lines.append("")
        lines.append("BQF-Analyze:")
        lines.append(f"  Policies run:    {bqf.get('policies_run', 0)}")
        passed = bqf.get("policies_passed", 0)
        warned = bqf.get("policies_warned", 0)
        failed = bqf.get("policies_failed", 0)
        lines.append(f"  Passed / Warn / Fail: {passed} / {warned} / {failed}")
        lines.append(f"  Overhead:        {bqf.get('duration_ms', 0.0):.2f} ms")

    lines.append("=" * 60)
    lines.append("")

    text_output = "\n".join(lines)

    if not out_path or out_path == "-":
        print(text_output)
    else:
        try:
            output_file = Path(out_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            output_file.write_text(text_output, encoding="utf-8")
            print(f"[bpy] Analysis results written to: {output_file}", file=sys.stderr)
        except Exception as e:
            print(f"[bpy] Error writing output file: {e}", file=sys.stderr)
            sys.exit(1)


def _print_human_summary(payload: dict) -> None:
    """Print human-readable analysis summary including BQF metrics."""
    result = payload.get("result", {})
    summary = result.get("summary", {})

    print("\n" + "=" * 60)
    print("  BranchPy Analysis Summary")
    print("=" * 60)
    print(f"Project: {payload.get('project', 'Unknown')}")
    print(f"Path:    {payload.get('path', 'Unknown')}")
    print()

    # ── First Insight ──────────────────────────────────────────────────────
    # One paragraph that answers "why should I care?" before the full report.
    _fi_lines = []
    _fi_interpretation = None

    _labels_count = summary.get("labels", 0)
    _issues_list = result.get("issues", [])
    _total_issues = len(_issues_list)
    _unreachable = summary.get("unreachable_labels", 0) or sum(
        1 for i in _issues_list if "unreachable" in str(i.get("type", "")).lower()
    )
    _vars_total = summary.get("variables", summary.get("variable_count", 0))
    _vars_unused = summary.get("unused_variables", 0) or sum(
        1 for i in _issues_list if "unused" in str(i.get("type", "")).lower()
    )
    _files_count = summary.get("files", 0)

    # Build bullet lines for issues of note
    if _labels_count:
        _fi_lines.append(
            f"  {_labels_count:,} label{'s' if _labels_count != 1 else ''} across {_files_count} file{'s' if _files_count != 1 else ''}"
        )
    if _unreachable:
        _fi_lines.append(
            f"  {_unreachable} unreachable label{'s' if _unreachable != 1 else ''} (content players will never see)"
        )
    if _vars_total:
        if _vars_unused:
            _fi_lines.append(
                f"  {_vars_total:,} variable{'s' if _vars_total != 1 else ''} ({_vars_unused} never reused — state that has no effect on the story)"
            )
        else:
            _fi_lines.append(
                f"  {_vars_total:,} variable{'s' if _vars_total != 1 else ''} tracked"
            )
    if _total_issues and not _unreachable:
        _fi_lines.append(
            f"  {_total_issues} issue{'s' if _total_issues != 1 else ''} detected"
        )

    # Derive one-sentence interpretation
    if _unreachable and _vars_unused:
        _fi_interpretation = (
            f"Dead paths and unused state detected — "
            f"{_unreachable} label{'s' if _unreachable != 1 else ''} are unreachable "
            f"and {_vars_unused} variable{'s' if _vars_unused != 1 else ''} never feed into the story."
        )
    elif _unreachable:
        _fi_interpretation = (
            f"{_unreachable} label{'s' if _unreachable != 1 else ''} "
            f"{'are' if _unreachable != 1 else 'is'} unreachable — "
            "players can never reach this content."
        )
    elif _vars_unused:
        _fi_interpretation = (
            f"{_vars_unused} variable{'s' if _vars_unused != 1 else ''} "
            f"{'are' if _vars_unused != 1 else 'is'} defined but never read — "
            "potential dead state in your narrative logic."
        )
    elif _total_issues == 0 and _labels_count:
        _fi_interpretation = "No structural issues found. Your project looks healthy."

    if _fi_lines:
        print("  First Insight")
        print("  " + "─" * 48)
        for _line in _fi_lines:
            print(_line)
        if _fi_interpretation:
            print()
            print(f"  -> {_fi_interpretation}")
        print()

    # Core metrics
    print("Core Metrics:")
    print(f"  Labels:  {summary.get('labels', 0)}")
    print(f"  Files:   {summary.get('files', 0)}")
    print(f"  Issues:  {len(result.get('issues', []))}")

    # Performance
    if summary.get("duration"):
        print(f"  Duration: {summary.get('duration', 0.0):.2f}s")
    if summary.get("labels_per_sec"):
        print(f"  Speed:    {summary.get('labels_per_sec', 0.0):.1f} labels/sec")

    # BQF-Analyze summary
    bqf = result.get("bqf_analyze")
    if bqf:
        print()
        print("BQF-Analyze:")
        print(f"  Policies run:    {bqf.get('policies_run', 0)}")
        passed = bqf.get("policies_passed", 0)
        warned = bqf.get("policies_warned", 0)
        failed = bqf.get("policies_failed", 0)
        print(f"  Passed / Warn / Fail: {passed} / {warned} / {failed}")
        print(f"  Overhead:        {bqf.get('duration_ms', 0.0):.2f} ms")

    # Narrative Structure (D9 research metrics) — only when enabled.
    ns = (
        result.get("story_structure", {})
        .get("collapsed_graph", {})
        .get("analysis", {})
        .get("semantic_summary", {})
        .get("narrative_structure", {})
    )
    if ns.get("enabled"):
        print()
        print("Narrative Structure (research):")
        raw_n = ns.get("raw_node_count", 0)
        scr_val = ns.get("structural_complexity_ratio_raw")
        scr_band = ns.get("structural_complexity_band", "")
        corridors = ns.get("corridor_count", 0)
        branch_hubs = ns.get("major_branch_hub_count", 0)
        merge_hubs = ns.get("major_merge_hub_count", 0)
        detachable = ns.get("detachable_scene_count", 0)
        lattice = ns.get("hub_return_lattice_count", 0)
        route_count = ns.get("route_candidate_count", 0)
        rbi = ns.get("route_balance_index")
        rbi_band = ns.get("route_balance_band", "")

        scr_str = f"{scr_band} ({scr_val:.2f})" if scr_val is not None else scr_band
        print(f"  Nodes: {raw_n}   SCR: {scr_str}   Corridors: {corridors}")
        print(f"  Hubs: {branch_hubs} branch / {merge_hubs} merge", end="")
        if detachable:
            print(f"   Detachable scenes: {detachable}", end="")
        print()
        if route_count:
            rbi_str = (
                f"   Balance: {rbi_band} (RBI {rbi:.2f})" if rbi is not None else ""
            )
            print(f"  Routes: {route_count} candidate(s){rbi_str}")
        if lattice:
            print(f"  Hub-return lattice roots: {lattice}")

        # Advisory lines — only for non-benign bands.
        from branchpy.analysis.flow_graph_analysis import RBI_BAND_NOTES, SCR_BAND_NOTES

        scr_note = SCR_BAND_NOTES.get(scr_band)
        rbi_note = RBI_BAND_NOTES.get(rbi_band) if rbi_band else None
        if scr_note:
            print(f"  Note (SCR): {scr_note}")
        if rbi_note:
            print(f"  Note (RBI): {rbi_note}")

    print("=" * 60 + "\n")


def _save_baseline_snapshot(project_path: str, result: dict) -> None:
    """
    Save performance baseline snapshot to .branchpy/reports/baseline.json

    Args:
        project_path: Path to the project
        result: Analysis result dictionary containing performance metrics
    """
    project_root = Path(project_path).resolve()
    baseline_dir = project_root / ".branchpy" / "reports"
    baseline_file = baseline_dir / "baseline.json"

    # Ensure directory exists
    baseline_dir.mkdir(parents=True, exist_ok=True)

    # Extract performance metrics
    perf_data = result.get("performance", {})

    # If no performance data in result, extract from summary/metadata
    if not perf_data:
        summary = result.get("summary", {})
        perf_data = {
            "duration_seconds": summary.get("duration", 0.0),
            "labels_per_second": summary.get("labels_per_sec", 0.0),
            "memory_peak_mb": summary.get("memory_peak_mb", 0.0),
            "labels_count": summary.get("labels", 0),
            "files_count": summary.get("files", 0),
        }

    # Extract flowchart if present (include summary metrics for tracking)
    flowchart_summary = None
    if "flowchart" in result:
        fc = result["flowchart"]
        flowchart_summary = {
            "cfg_edges_count": len(fc.get("cfg_edges", [])),
            "pfi_edges_count": len(fc.get("pfi_edges", [])),
            "sae_edges_count": len(fc.get("sae_edges", [])),
            "erp_edges_count": len(fc.get("erp_edges", [])),
            "edges_by_origin": fc.get("edges_by_origin", {}),
        }

    baseline = {
        "timestamp": datetime.datetime.now().isoformat(),
        "project": str(project_root),
        "performance": perf_data,
        "summary": result.get("summary", {}),
        "version": result.get("version", "unknown"),
    }

    # Include flowchart summary if available
    if flowchart_summary:
        baseline["flowchart"] = flowchart_summary

    try:
        baseline_file.write_text(
            json.dumps(baseline, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        print(f"[bpy] Baseline snapshot saved to: {baseline_file}")
    except Exception as e:
        print(f"[bpy] Warning: Could not save baseline: {e}", file=sys.stderr)


# API client for deep analysis
API_BASE = "http://127.0.0.1:8765/api/v1"
_API_SERVER_THREAD = None  # Global thread reference for auto-started server


def _is_api_server_running() -> bool:
    """Check if API server is reachable."""
    try:
        req = urllib.request.Request(f"{API_BASE}/", method="GET")
        with urllib.request.urlopen(req, timeout=2) as r:
            # API server responds with 200 or 404 - both mean it's running
            return r.status in (200, 404)
    except urllib.error.HTTPError as e:
        # 404 or other HTTP errors mean server is responding
        return e.code in (200, 404, 401, 403)
    except (urllib.error.URLError, OSError, TimeoutError):
        return False


def _ensure_api_server() -> None:
    """Auto-start API server if not running."""
    global _API_SERVER_THREAD

    if _is_api_server_running():
        return  # Already running

    # Try to auto-start
    try:
        from branchpy.server.api import start_api

        print("[bpy] API server not running, auto-starting...")
        thread, token = start_api(port=8765)
        _API_SERVER_THREAD = thread
        os.environ["BPY_TOKEN"] = token  # Store token for requests

        # Wait for server to be ready (up to 10 seconds)
        for attempt in range(20):
            time.sleep(0.5)
            if _is_api_server_running():
                print("[bpy] API server started successfully (port 8765)")
                return

        raise RuntimeError("API server started but not responding after 10 seconds")
    except ImportError:
        raise SystemExit("[bpy] SAE not available. API server module not found.")
    except Exception as e:
        raise SystemExit(f"[bpy] Failed to auto-start API server: {e}")


def _req(
    path: str,
    method: str = "GET",
    body: Optional[dict] = None,
    token: Optional[str] = None,
) -> Dict[str, Any]:
    """Make HTTP request to BranchPy API."""
    url = f"{API_BASE}{path}"
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")

    auth_token = token or os.environ.get("BPY_TOKEN")
    if auth_token:
        req.add_header("Authorization", f"Bearer {auth_token}")

    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", "ignore")
        raise SystemExit(f"[bpy] API error {e.code}: {error_body}")
    except urllib.error.URLError as e:
        raise SystemExit(f"[bpy] Cannot reach BranchPy API at {API_BASE}: {e}")


def run_deep(args) -> int:
    """
    Execute deep analysis with SAE solver.

    Args:
        args: Namespace with project, export_cfg, out, fail_on_errors

    Returns:
        Exit code (0=success, 1=errors with --fail-on-errors, 2=failure)
    """
    project_path = args.project or os.getcwd()
    print(f"[bpy] Starting deep analysis (SAE) for: {project_path}")

    # SOP §3.3 — --export-cfg is a Class C operation (full CFG artifact).
    # Gate it behind --internal so it never runs silently in a product context.
    if getattr(args, "export_cfg", False) and not getattr(args, "internal", False):
        print(
            "[bpy] ERROR: --export-cfg produces Class C engine artifacts (full CFG).\n"
            "  Add --internal to confirm this is an internal / development use.",
            file=sys.stderr,
        )
        return 2

    # Run deep analysis using SAE components
    try:
        from branchpy.analysis.sae.cfg_builder import StatementCFGBuilder
        from branchpy.analysis.sae.indexer import Indexer
        from branchpy.analysis.sae.semantics import SemanticsCatalog
        from branchpy.sae.interpreter import run_symbolic
        from branchpy.sae.report import export_unified

        project_root = Path(project_path)

        # Build index
        print("[bpy] Building index...")
        indexer = Indexer(str(project_root))
        index = indexer.build_index()

        # Load semantics
        semantics_path = project_root / ".branchpy" / "semantics.yaml"
        if semantics_path.exists():
            catalog = SemanticsCatalog.from_yaml(semantics_path)
        else:
            catalog = SemanticsCatalog()

        # Add built-in semantics
        builtin_catalog = SemanticsCatalog.get_default_catalog()
        for func_list in builtin_catalog.functions.values():
            for func in func_list:
                catalog.add(func)

        # Build CFG
        print("[bpy] Building control flow graph...")
        builder = StatementCFGBuilder(
            index, project_root=str(project_root), semantics_catalog=catalog
        )
        cfg = builder.build()

        # Run symbolic analysis
        print("[bpy] Running SAE solver...")
        result = run_symbolic(cfg, {}, solver_backend="auto")

        # Build the report structure compatible with the dashboard
        report_data = {
            "project": project_root.name,
            "path": str(project_root),
            "result": {
                "engine": "renpy",
                "summary": {"labels": len(index.labels), "files": len(index.files)},
                "cfg": cfg.to_dict() if hasattr(cfg, "to_dict") else {},
                "issues": [],  # SAE validation issues would go here
                "rules": {},
                "assets": {},
                "story_structure": {},
                "performance": {},
                "meta": {"version": "0.8.5-sae"},
                "sae": {
                    "labels": {},
                    "edge_meta": {},
                    "solver_info": (
                        result.solver_info if hasattr(result, "solver_info") else {}
                    ),
                    "label_state_table": [],
                },
            },
        }

        # Transform CFG edges to edge_meta format for dashboard
        edge_list = []
        if hasattr(cfg, "edges"):
            for edge in cfg.edges:
                # CFGEdge has: from_node, to_node, cond, label, edge_type
                edge_list.append(
                    {
                        "label": f"{edge.from_node} → {edge.to_node}",
                        "feasible": "yes",  # All edges in CFG are considered feasible by construction
                        "reason": edge.cond or None,
                        "source": edge.from_node,
                        "target": edge.to_node,
                        "edge_type": (
                            edge.edge_type.value
                            if hasattr(edge.edge_type, "value")
                            else str(edge.edge_type)
                        ),
                    }
                )

        report_data["result"]["sae"]["edge_meta"] = {"edges": edge_list}

        # Add SAE data
        all_labels = (
            set(result.label_env.keys())
            | set(result.label_guards.keys())
            | set(result.label_state_delta.keys())
        )
        for label in all_labels:
            report_data["result"]["sae"]["labels"][label] = {
                "vars_ranges": {
                    k: v for k, v in result.label_env.get(label, {}).items()
                },
                "guards": result.label_guards.get(label, []),
                "state_delta": result.label_state_delta.get(
                    label, {"assigns": {}, "incs": {}, "toggles": []}
                ),
            }

        # Save reports
        # SOP §3.3 output contract:
        #   .branchpy/reports/.internal/analyze-{ts}.json  → Class C (full SAE payload, internal only)
        #   .branchpy/reports/analyze.json                  → Class B (thin public summary, VS Code reads)
        reports_dir = project_root / ".branchpy" / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        internal_reports_dir = reports_dir / ".internal"
        internal_reports_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = internal_reports_dir / f"analyze-{timestamp}.json"
        latest_path = reports_dir / "analyze.json"

        # Strip engine-internal SAE solver data before persisting to avoid
        # distributing engine-API-grade outputs in local build artifacts.
        _persist_data = dict(report_data)
        _persist_result = dict(_persist_data.get("result", {}))
        _sae_raw = _persist_result.get("sae", {})
        _persist_result["sae"] = {
            "label_count": len(_sae_raw.get("labels", {})),
            "edge_count": len(_sae_raw.get("edge_meta", {}).get("edges", [])),
            # solver_info kept for internal diagnostics only; stripped from public path below
            "solver_info": _sae_raw.get("solver_info", {}),
        }
        _persist_result.pop("cfg", None)
        _persist_data["result"] = _persist_result
        # Full (still stripped) payload → .internal/ timestamped archive
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(_persist_data, f, indent=2, ensure_ascii=False, default=str)

        # Public thin summary → .branchpy/reports/analyze.json
        # Strip solver_info from this one too — counts only.
        _public_result = dict(_persist_data.get("result", {}))
        _public_sae = dict(_public_result.get("sae", {}))
        _public_sae.pop("solver_info", None)
        _public_result["sae"] = _public_sae
        _public_result.pop("cfg", None)
        _public_data = dict(_persist_data)
        _public_data["result"] = _public_result
        with open(latest_path, "w", encoding="utf-8") as f:
            json.dump(_public_data, f, indent=2, ensure_ascii=False, default=str)

        # Generate Function Index if requested (v0.8.9)
        if getattr(args, "export_functions", False):
            try:
                from branchpy.analysis.pfi import (
                    CallGraph,
                    ConsistencyChecker,
                    FunctionIndexer,
                    PFIExporter,
                    StatEffectAnalyzer,
                )

                print("[bpy] Generating Project Function Index (PFI)...")

                # Phase 1: Index functions
                indexer = FunctionIndexer(project_root)
                indexer.index_project()

                # Phase 2: Analyze stat effects
                known_stats = set()
                if hasattr(result, "label_env"):
                    # Extract stats from SAE analysis
                    for label_env in result.label_env.values():
                        known_stats.update(label_env.keys())

                analyzer = StatEffectAnalyzer(known_stats=known_stats)
                for func in indexer.all_functions:
                    try:
                        file_path = project_root / func.file
                        if file_path.exists():
                            source = file_path.read_text(
                                encoding="utf-8", errors="ignore"
                            )
                            analyzer.analyze_function(func, source)
                    except Exception:
                        pass  # Skip files with errors

                # Phase 3: Build call graph
                call_graph = CallGraph()
                call_graph.build_from_functions(indexer.all_functions)

                # Phase 4: Consistency checks
                checker = ConsistencyChecker(
                    complexity_threshold=15, enable_naming_checks=True
                )
                checker.check_all(indexer.all_functions, analyzer.analyses)

                # Export
                exporter = PFIExporter(indexer, analyzer, checker, call_graph)
                pfi_format = getattr(args, "pfi_format", "compact")
                # (M-13) Write to PFI canonical path (.branchpy/cache/) so pfi_cmd.py and
                # analyze --export-functions share one directory and one reader path.
                # Legacy: .branchpy/reports/function_index.json no longer written.
                cache_dir_pfi = project_root / ".branchpy" / "cache"
                cache_dir_pfi.mkdir(parents=True, exist_ok=True)
                pfi_path = cache_dir_pfi / f"function_index_{timestamp}.json"
                pfi_latest = cache_dir_pfi / "function_index.json"

                exporter.save_to_file(pfi_path, format=pfi_format)
                exporter.save_to_file(pfi_latest, format=pfi_format)

                # Add PFI summary to main report
                report_data["result"]["function_index"] = {
                    "total_functions": len(indexer.all_functions),
                    "unique_names": len(indexer.functions),
                    "stat_modifiers": sum(
                        1 for a in analyzer.analyses.values() if a.is_stat_modifier
                    ),
                    "warnings": len(checker.warnings),
                    "export_path": str(pfi_latest),
                }

                # Re-save main report with PFI data
                with open(latest_path, "w", encoding="utf-8") as f:
                    json.dump(report_data, f, indent=2, ensure_ascii=False, default=str)

                print(f"[bpy] Function Index exported: {pfi_latest}")
                print(
                    f"[bpy]   • Functions: {len(indexer.all_functions)} ({len(indexer.functions)} unique)"
                )
                print(
                    f"[bpy]   • Stat modifiers: {sum(1 for a in analyzer.analyses.values() if a.is_stat_modifier)}"
                )
                print(f"[bpy]   • Warnings: {len(checker.warnings)}")

            except Exception as e:
                print(f"[bpy] Warning: Function Index generation failed: {e}")
                import traceback

                traceback.print_exc()

        print("[bpy] Analysis complete! Report saved to:")
        print(f"  • {report_path}")
        print(f"  • {latest_path}")

        # Funnel telemetry — first analyze succeeded (deep path)
        try:
            if _funnel is not None:
                from branchpy.onboarding.constants import (
                    EVENT_ONBOARDING_FIRST_ANALYZE_SUCCEEDED,
                )

                _funnel.append(
                    build_event(
                        event_type=EVENT_ONBOARDING_FIRST_ANALYZE_SUCCEEDED,
                        surface="cli",
                        session_id=_funnel_session_id,
                        payload={"deep": True},
                    )
                )
        except Exception:
            pass

        return 0

    except ImportError as e:
        print(f"[bpy] ERROR: SAE module not available: {e}")
        print("[bpy] Deep analysis requires the SAE solver component.")
        return 2
    except Exception as e:
        print(f"[bpy] ERROR: Analysis failed: {e}")
        import traceback

        traceback.print_exc()
        return 2


# API client for deep analysis
API_BASE = "http://127.0.0.1:8765/api/v1"


def main(argv=None, *, run_ctx=None) -> int:
    """
    Main entry point for analyze command.

    Note: Telemetry is automatically tracked at dispatch level (cli.py),
    no need for @track_command decorator here.
    """
    parser = argparse.ArgumentParser(
        prog="branchpy analyze", description="Analyze a project with BranchPy."
    )
    parser.add_argument(
        "project",
        nargs="?",
        default=".",
        help="Path to the project root (default: current directory)",
    )
    parser.add_argument(
        "--engine",
        default="renpy",
        choices=["renpy"],
        help="Engine to use (default: renpy)",
    )
    parser.add_argument(
        "--out",
        default="",
        help="Output file for analysis results (use '-' for stdout)",
    )
    parser.add_argument(
        "--format",
        dest="output_format",
        choices=["text", "json"],
        default="text",
        help="Output format for analysis results (default: text)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results in JSON format (deprecated: use --format json)",
    )
    parser.add_argument(
        "--stats", action="store_true", help="Include statistics in output"
    )
    parser.add_argument(
        "--fp-log",
        default="",
        help="Log suppressed findings to CSV for FP tracking (WS-A4)",
    )
    parser.add_argument(
        "--debug-cfg",
        metavar="DOT_FILE",
        default="",
        # SOP §3.3 — Class C flag. Suppressed from public help.
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--internal",
        action="store_true",
        # SOP §3.3 — Class C flag. Not documented in public help.
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--assets", action="store_true", help="Enable asset validation (Phase 2)"
    )
    parser.add_argument(
        "--fail-on-errors",
        action="store_true",
        help="Exit with code 1 if ERROR severity issues found",
    )
    parser.add_argument(
        "--summary",
        action="store_true",
        help="Show enhanced categorized summary report",
    )
    parser.add_argument(
        "--perf",
        dest="enable_perf",
        action="store_true",
        default=True,
        help="Enable performance profiling (default: enabled)",
    )
    parser.add_argument(
        "--no-perf",
        dest="enable_perf",
        action="store_false",
        help="Disable performance profiling",
    )
    parser.add_argument(
        "--emit-semantics",
        action="store_true",
        help="Generate semantic trace JSONL (v0.8.7)",
    )
    parser.add_argument(
        "--bqf-analyze",
        dest="bqf_analyze",
        action="store_true",
        default=True,
        help="Enable BQF-Analyze policies (default: enabled)",
    )
    parser.add_argument(
        "--no-bqf-analyze",
        dest="bqf_analyze",
        action="store_false",
        help="Disable BQF-Analyze policies",
    )
    parser.add_argument(
        "--max-nodes",
        type=int,
        default=100,
        help="Maximum nodes in story flowchart (default: 100)",
    )
    parser.add_argument(
        "--force-engine",
        default=None,
        choices=["renpy", "godot", "unity", "unreal"],
        help="Force specific engine (overrides auto-detection)",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable discovery result caching (force fresh scan)",
    )
    parser.add_argument(
        "--html",
        action="store_true",
        help="Generate a standalone HTML report artifact (saved to .branchpy/reports/).",
    )
    parser.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Generate and open an HTML report in the browser (implies --html).",
    )
    args = parser.parse_args(argv)

    # Funnel telemetry — attempted (G1: emit from CLI path, mirrors vscode-addon)
    try:
        import uuid as _uuid

        from branchpy.onboarding.activation_funnel import (
            ActivationFunnelStore,
            build_event,
        )
        from branchpy.onboarding.constants import EVENT_ONBOARDING_ANALYZE_ATTEMPTED

        _funnel = ActivationFunnelStore()
        _funnel_session_id = str(_uuid.uuid4())
        _funnel.append(
            build_event(
                event_type=EVENT_ONBOARDING_ANALYZE_ATTEMPTED,
                surface="cli",
                session_id=_funnel_session_id,
                payload={
                    "engine": getattr(args, "engine", "renpy"),
                    "deep": getattr(args, "deep", False),
                },
            )
        )
    except Exception:
        _funnel = None
        _funnel_session_id = None

    html_requested = getattr(args, "html", False) or getattr(
        args, "open_browser", False
    )
    structured_out_path = args.out if args.out else None
    html_out_path = None
    if html_requested and structured_out_path:
        candidate = Path(structured_out_path)
        if candidate.suffix.lower() in {".html", ".htm"}:
            html_out_path = candidate
            structured_out_path = None

    # Initialize telemetry (v1.0.0 Phase 2)
    telemetry_writer = None
    session_id = None
    trace_id = None

    if TELEMETRY_AVAILABLE:
        try:
            project_root = Path(args.project).resolve()
            config = load_config(project_root)
            telemetry_config = config.get("telemetry", {})

            if telemetry_config.get("enabled", False):
                log_dir = project_root / ".branchpy" / "logs" / "telemetry"
                privacy_level = telemetry_config.get("privacy", "minimal")
                telemetry_writer = LocalTelemetryWriter(log_dir, privacy_level)
                session_id = telemetry_writer.session_id
                trace_id = create_trace_id()

                # Emit session start
                session = TelemetrySession(
                    session_id=session_id,
                    app="BranchPyApp",
                    version=importlib.metadata.version("branchpy"),
                    engine=args.engine,
                    privacy=privacy_level,
                    started_at=telemetry_writer.iso_now(),
                )
                telemetry_writer.write_session(session)

                # Emit analyze.start event
                start_event = TelemetryEvent(
                    ts=telemetry_writer.iso_now(),
                    session_id=session_id,
                    trace_id=trace_id,
                    category="analyze",
                    name="analyze.start",
                    module="analyzer",
                    attrs=(
                        {
                            "engine": args.engine,
                            "assets_enabled": args.assets,
                            "bqf_enabled": args.bqf_analyze,
                        }
                        if privacy_level != "minimal"
                        else {}
                    ),
                    level="info",
                )
                telemetry_writer.write_event(start_event)
        except Exception as e:
            # Don't fail analysis if telemetry fails
            print(
                f"[bpy] Warning: Telemetry initialization failed: {e}", file=sys.stderr
            )
            telemetry_writer = None

    # Start performance timer
    analysis_start_time = time.perf_counter()

    # Determine output format (support both --format and legacy --json)
    output_format = getattr(args, "output_format", "text")
    if getattr(args, "json", False):  # Legacy --json flag
        output_format = "json"

    # Set JSON-only mode in environment for engine to detect
    if output_format == "json":
        os.environ["BPY_JSON_MODE"] = "1"

    # v1.1.0: Run project discovery before engine instantiation
    project_root = Path(args.project).resolve()
    config = load_config(project_root)

    # Get override settings (precedence: CLI > config > None)
    force_engine = args.force_engine if hasattr(args, "force_engine") else None
    if force_engine is None:
        force_engine = config.get("discovery", {}).get("force_engine")

    force_engine_always = config.get("discovery", {}).get("force_engine_always", False)
    discovery_threshold = config.get("discovery", {}).get("discovery_threshold", 0.5)

    # Cache configuration (Phase 3)
    cache_enabled = config.get("discovery", {}).get("cache_enabled", True)
    cache_ttl = config.get("discovery", {}).get("cache_ttl", 3600)
    use_cache = cache_enabled and not getattr(args, "no_cache", False)

    # Initialize discovery with cache (Phase 3)
    from branchpy.discovery.cache import DiscoveryCache

    cache = None
    if use_cache:
        cache_dir = project_root / ".branchpy" / "cache"
        cache = DiscoveryCache(cache_dir, ttl_seconds=float(cache_ttl))

    discovery = ProjectDiscovery(cache=cache)
    discovery_result = discovery.discover(
        project_root,
        threshold=discovery_threshold,
        force_engine=force_engine,
        force_engine_always=force_engine_always,
        use_cache=use_cache,
    )

    if discovery_result.status == DiscoveryStatus.NO_MATCH:
        # Early exit: no engine detected
        error_payload = {
            "project": project_root.name,
            "path": str(project_root),
            "discovery": discovery_result.to_dict(),
            "issues": [
                {
                    "severity": "error",
                    "rule": "PROJECT:NO_ENGINE_DETECTED",
                    "message": "No supported project type detected.",
                    "hint": discovery_result.reason,
                }
            ],
            "meta": {"version": "1.1.0"},
        }

        # Output error in requested format
        if output_format == "json":
            _write_json_output(error_payload, structured_out_path)
        else:
            print(f"[bpy] Error: {discovery_result.reason}", file=sys.stderr)

        # Emit telemetry if available
        if telemetry_writer:
            try:
                end_event = TelemetryEvent(
                    ts=telemetry_writer.iso_now(),
                    session_id=session_id or "",
                    trace_id=trace_id or "",
                    category="analyze",
                    name="analyze.discovery_failed",
                    module="analyzer",
                    attrs=(
                        {}
                        if telemetry_writer.privacy == "minimal"
                        else {"reason": "no_engine_detected"}
                    ),
                    level="error",
                )
                telemetry_writer.write_event(end_event)
            except Exception:
                pass  # Don't fail on telemetry errors

        sys.exit(1)

    elif discovery_result.status == DiscoveryStatus.AMBIGUOUS:
        # Warn but continue with highest-confidence engine
        logs.warning(
            "discovery.ambiguous",
            discovery_result.reason,
            matched_engine=discovery_result.matched_engine,
        )

    # Get engine from matched candidate
    matched_engine_name = discovery_result.matched_engine

    if matched_engine_name != "renpy":
        # Future: Add other engines here
        error_payload = {
            "project": project_root.name,
            "path": str(project_root),
            "discovery": discovery_result.to_dict(),
            "issues": [
                {
                    "severity": "error",
                    "rule": "ENGINE:NOT_IMPLEMENTED",
                    "message": f"Engine '{matched_engine_name}' is not yet implemented.",
                    "hint": "Currently supported engines: renpy",
                }
            ],
            "meta": {"version": "1.1.0"},
        }

        if output_format == "json":
            _write_json_output(error_payload, args.out if args.out else None)
        else:
            print(
                f"[bpy] Error: Engine '{matched_engine_name}' not implemented yet",
                file=sys.stderr,
            )

        sys.exit(1)

    # Pass resolved config to engine
    engine = RenpyEngine(config=config)  # future: map engine name -> engine instance
    model = ProjectModel(name=Path(args.project).name, path=args.project, engine=engine)
    model.load()

    # Initialize FP logger if requested
    fp_logger = None
    if args.fp_log:
        from branchpy.fp_logger import create_fp_logger

        fp_logger = create_fp_logger(args.fp_log)

    # Pass options to analyzer
    result = model.run_analysis(
        options={
            "enable_assets": args.assets,
            "export_cfg": bool(args.debug_cfg),
            "enable_perf": args.enable_perf,
            "emit_semantics": args.emit_semantics,  # v0.8.7
            "fp_logger": fp_logger,  # Pass logger to analysis
            "max_nodes": args.max_nodes,  # Phase 2: Flowchart node limit
        }
    )

    # BQF-Analyze integration (v1.0.0 Wave 4 Phase 4.2)
    if args.bqf_analyze and isinstance(result, dict):
        try:
            # Axis5 v0.9.1 import normalization: use root-level analyze package (sibling of branchpy)
            from analyze import events
            from analyze.runner import run_bqf_analyze
            from branchpy import logs

            # Build context from analysis result
            class AnalyzeContext:
                def __init__(self, result_data):
                    # Extract stats from analysis result
                    summary = result_data.get("summary", {})
                    issues = result_data.get("issues", [])

                    # Create stats object with analysis metrics
                    self.stats = type(
                        "obj",
                        (object,),
                        {
                            "unresolved_jumps": sum(
                                1 for i in issues if i.get("kind") == "missing_jump"
                            ),
                            "orphan_labels": sum(
                                1 for i in issues if i.get("kind") == "orphan_label"
                            ),
                            "total_labels": summary.get("labels", 0),
                            "total_issues": len(issues),
                        },
                    )()

                    # Extract dead labels (labels with no incoming edges or unreachable)
                    self.dead_labels = [
                        i.get("value", "")
                        for i in issues
                        if i.get("kind") in ("orphan_label", "unreachable_label")
                    ]

            ctx = AnalyzeContext(result)
            bqf_summary = run_bqf_analyze(ctx)
            result["bqf_analyze"] = {
                "policies_run": bqf_summary.policies_run,
                "policies_passed": bqf_summary.policies_passed,
                "policies_warned": bqf_summary.policies_warned,
                "policies_failed": bqf_summary.policies_failed,
                "duration_ms": bqf_summary.duration_ms,
            }
        except ImportError:
            # BQF module not available - skip silently
            pass
        except Exception as e:
            # Log warning but don't fail the analysis
            from branchpy import logs

            try:
                from analyze import events

                logs.warn(
                    events.POLICY_WARNING, "BQF-Analyze disabled (error)", error=repr(e)
                )
            except ImportError:
                # Fall back to plain logging if events module not available
                print(f"[bpy] Warning: BQF-Analyze failed: {e}", file=sys.stderr)

    payload = {
        "project": model.name,
        "path": str(Path(args.project).resolve()),
        "result": result,
        "discovery": discovery_result.to_dict(),  # v1.1.0: Include discovery metadata
    }

    # v0.8.7: Export semantic traces if requested
    if args.emit_semantics and isinstance(result, dict):
        try:
            from branchpy.core.semantics import SemanticTraceExporter

            project_root = Path(args.project).resolve()
            semantics_dir = project_root / ".branchpy" / "reports" / "semantics"

            exporter = SemanticTraceExporter(semantics_dir)

            # Export from CFG if available
            cfg_data = result.get("debug", {}).get("cfg_dict") or result.get("cfg")
            if cfg_data:
                trace_file = exporter.export_cfg_semantics(cfg_data, str(project_root))
                print(f"[bpy] Semantic trace exported to: {trace_file}")
            else:
                print(
                    "[bpy] Warning: No CFG data available for semantic export",
                    file=sys.stderr,
                )
        except Exception as e:
            print(
                f"[bpy] Warning: Failed to export semantic traces: {e}", file=sys.stderr
            )

    # Optional DOT dump — Class C (SOP §3.3): requires --internal flag.
    if args.debug_cfg and isinstance(result, dict):
        if not getattr(args, "internal", False):
            print(
                "[bpy] WARNING: --debug-cfg produces a Class C engine artifact (full CFG graph).\n"
                "  Add --internal to confirm you intend to export internal engine data.\n"
                "  This flag is for internal / development use only.",
                file=sys.stderr,
            )
        else:
            dot = result.get("debug", {}).get("dot")
            if dot:
                # Always route to .internal/ to avoid inadvertent public exposure.
                project_root = Path(args.project).resolve()
                internal_dir = project_root / ".branchpy" / "cache" / ".internal"
                internal_dir.mkdir(parents=True, exist_ok=True)
                cfg_path = internal_dir / Path(args.debug_cfg).name
                cfg_path.write_text(dot, encoding="utf-8")
                from branchpy import logs as _logs

                _logs.info(
                    "debug.internal_flag_used",
                    "--debug-cfg + --internal used",
                    path=str(cfg_path),
                )

    # Write output based on format option
    if output_format == "json":
        # Build a thinned public payload: strip engine-internal graph/solver data
        # to avoid inadvertently distributing the future Engine API locally.
        _pub_result = dict(payload.get("result", {}))
        for _k in ("sae", "cfg", "debug"):
            _pub_result.pop(_k, None)
        _pub_ss = dict(_pub_result.get("story_structure", {}))
        _pub_cg = _pub_ss.get("collapsed_graph")
        if isinstance(_pub_cg, dict):
            # SOP §3.3.1 Two-Tier Panel Contract:
            # - Internal artifact (.branchpy/internal/<run_id>/collapsed_graph.json):
            #   Full Class-B-filtered graph (nodes/edges with Class-C fields stripped).
            #   Consumed only by the VS Code extension host via internal_ref resolution.
            # - Public artifact (analyze.json collapsed_graph):
            #   Summary counts + internal_ref pointer — no node/edge lists.
            _INTERNAL_NODE_FIELDS = {
                "component_id",
                "cluster_lane",
                "entry_distance",
                "preset_x",
                "preset_y",
            }
            _pub_nodes = [
                {k: v for k, v in n.items() if k not in _INTERNAL_NODE_FIELDS}
                for n in _pub_cg.get("nodes", [])
            ]
            _run_id = _pub_cg.get("analysis_run_id") or ""

            # Write full Class-B graph to internal path (Class C artifact, extension-only).
            # Must be written BEFORE the public artifact so internal_ref is never dangling.
            _internal_cg_written = False
            if _run_id:
                try:
                    _project_root = Path(args.project).resolve()
                    _internal_dir = _project_root / ".branchpy" / "internal" / _run_id
                    _internal_dir.mkdir(parents=True, exist_ok=True)
                    _internal_cg = {
                        "nodes": _pub_nodes,
                        "edges": _pub_cg.get("edges", []),
                        "stats": _pub_cg.get("stats", {}),
                        "analysis": _pub_cg.get("analysis", {}),
                        "analysis_run_id": _run_id,
                        "analysis_timestamp": _pub_cg.get("analysis_timestamp"),
                        "analysis_sources_snapshot": _pub_cg.get(
                            "analysis_sources_snapshot"
                        ),
                    }
                    (_internal_dir / "collapsed_graph.json").write_text(
                        json.dumps(_internal_cg, indent=2, ensure_ascii=False),
                        encoding="utf-8",
                    )
                    # Ensure the .branchpy/.gitignore covers internal/
                    _gitignore = _project_root / ".branchpy" / ".gitignore"
                    if _gitignore.exists():
                        _gi_text = _gitignore.read_text(encoding="utf-8")
                        if "internal/" not in _gi_text:
                            _gitignore.write_text(
                                _gi_text.rstrip()
                                + "\n\n# Internal engine artifacts (Class C — extension-only)\ninternal/\n",
                                encoding="utf-8",
                            )
                    _internal_cg_written = True
                    print(
                        f"[bpy] Internal graph artifact: {_internal_dir / 'collapsed_graph.json'}",
                        file=sys.stderr,
                    )
                except Exception as _ie:
                    print(
                        f"[bpy] Warning: Failed to write internal collapsed_graph: {_ie}",
                        file=sys.stderr,
                    )

            # Public artifact: summary counts + internal_ref pointer (no node/edge lists).
            _stats = _pub_cg.get("stats", {})
            _pub_ss["collapsed_graph"] = {
                "node_count": len(_pub_nodes),
                "edge_count": len(_pub_cg.get("edges", [])),
                "entry_node_count": _stats.get("entry_nodes", 0),
                "unreachable_count": _stats.get("unreachable_nodes", 0),
                "terminal_end_count": _stats.get("terminal_end_nodes", 0),
                "dead_end_count": _stats.get("dead_end_nodes", 0),
                "analysis_run_id": _run_id,
                "analysis_timestamp": _pub_cg.get("analysis_timestamp"),
                "analysis_sources_snapshot": _pub_cg.get("analysis_sources_snapshot"),
                "internal_ref": {
                    "run_id": _run_id,
                    "graph_available": _internal_cg_written,
                    "collapsed_graph_path": (
                        f".branchpy/internal/{_run_id}/collapsed_graph.json"
                        if _run_id
                        else None
                    ),
                },
            }
            _pub_result["story_structure"] = _pub_ss
        _public_payload = dict(payload)
        _public_payload["result"] = _pub_result
        # JSON output - use structured output
        _write_json_output(_public_payload, structured_out_path)

        # (M-03) Canonical artifact write: always store a timestamped snapshot in
        # .branchpy/analyze/ regardless of --out. --out is an extra export copy only.
        try:
            _canonical_dir = Path(args.project).resolve() / ".branchpy" / "analyze"
            _canonical_dir.mkdir(parents=True, exist_ok=True)
            _ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            _canonical_path = _canonical_dir / f"analyze-{_ts}.json"
            _canonical_latest = _canonical_dir / "analyze.json"
            _canonical_json = json.dumps(
                _public_payload, indent=2, sort_keys=True, ensure_ascii=False
            )
            _canonical_path.write_text(_canonical_json, encoding="utf-8")
            _canonical_latest.write_text(_canonical_json, encoding="utf-8")
            print(
                f"[bpy] Canonical analyze snapshot: {_canonical_path}", file=sys.stderr
            )
        except Exception as _e:
            print(
                f"[bpy] Warning: Failed to write canonical analyze artifact: {_e}",
                file=sys.stderr,
            )

        # Phase 3B.1-A: Write unified report for Flowchart UI
        # UI expects .branchpy/reports/unified/unified_report.json
        try:
            project_root = Path(args.project).resolve()
            unified_dir = project_root / ".branchpy" / "reports" / "unified"
            unified_dir.mkdir(parents=True, exist_ok=True)
            unified_path = unified_dir / "unified_report.json"

            # Build unified payload with collapsed_graph at top level
            # UI expects: reportData.collapsed_graph.nodes
            unified_payload = {}
            if (
                "story_structure" in result
                and "collapsed_graph" in result["story_structure"]
            ):
                # Wrap collapsed_graph so UI can access reportData.collapsed_graph
                unified_payload["collapsed_graph"] = result["story_structure"][
                    "collapsed_graph"
                ]

                # Also include other useful metadata
                unified_payload["label_data"] = result.get("label_data", {})
                unified_payload["label_stats"] = result.get("label_stats", {})
                unified_payload["image_validation"] = result.get("image_validation", {})
                unified_payload["validation_data"] = result.get("validation_data", [])
                unified_payload["media_data"] = result.get("media", {})
                unified_payload["analysis_sources_snapshot"] = result[
                    "story_structure"
                ]["collapsed_graph"].get("analysis_sources_snapshot")

                # D21: Include hotspot diagnostics if present
                if "diagnostics" in result["story_structure"]:
                    unified_payload["diagnostics"] = result["story_structure"][
                        "diagnostics"
                    ]

            # Write unified report
            unified_json = json.dumps(unified_payload, indent=2, ensure_ascii=False)
            unified_path.write_text(unified_json, encoding="utf-8")

            # Phase 5: Embed source_revision + run identity for freshness model
            try:
                from branchpy.artifact_freshness import patch_artifact_metadata
                from branchpy.run_context import RunContext

                _ctx = run_ctx
                if _ctx is None:
                    from branchpy.artifact_freshness import get_source_revision

                    _ctx = RunContext.start(
                        project_root, get_source_revision(project_root)
                    ).complete()
                patch_artifact_metadata(
                    unified_path, project_root, "analyze", run_ctx=_ctx
                )
            except Exception:
                pass  # non-fatal; freshness metadata is best-effort

            # Phase 5: InsightSummary is now owned exclusively by `insights_cmd`.
            # Analyze must NOT write insight_summary.json — see M-17 / ARTIFACT_RULES.md Rule 1.
            # (Removed: build_and_persist call that was here)

            # Log success (only in debug/verbose mode)
            if not (structured_out_path and structured_out_path != "-"):
                print(
                    f"[bpy] Unified report written to: {unified_path}", file=sys.stderr
                )
        except Exception as e:
            # Don't fail the analysis if unified report write fails
            print(
                f"[bpy] Warning: Failed to write unified report: {e}", file=sys.stderr
            )

        # Cache: label_fingerprints.json — fingerprint of every label for change detection.
        # Class: cache (ephemeral — may be deleted and rebuilt). No consumers yet.
        try:
            _cache_dir = Path(args.project).resolve() / ".branchpy" / "cache"
            _cache_dir.mkdir(parents=True, exist_ok=True)
            _label_data = (
                result.get("label_data", {}) if isinstance(result, dict) else {}
            )
            _fingerprints: dict = {}
            for _lname, _ldata in _label_data.items():
                _raw = json.dumps(_ldata, sort_keys=True, ensure_ascii=False)
                _fingerprints[_lname] = hashlib.md5(_raw.encode()).hexdigest()[:16]
            _lf_payload = {
                "version": "1",
                "generated_at": datetime.datetime.now().isoformat(),
                "data": _fingerprints,
            }
            (_cache_dir / "label_fingerprints.json").write_text(
                json.dumps(_lf_payload, indent=2, ensure_ascii=False), encoding="utf-8"
            )
        except Exception as _lfe:
            print(
                f"[bpy] Warning: Failed to write label_fingerprints cache: {_lfe}",
                file=sys.stderr,
            )

        # Cache: static_graph.json — stable node+edge snapshot for fast graph queries.
        # Class: cache (ephemeral — may be deleted and rebuilt). No consumers yet.
        try:
            _cg = (
                (result.get("story_structure", {}).get("collapsed_graph", {}))
                if isinstance(result, dict)
                else {}
            )
            _raw_nodes = _cg.get("nodes") or []
            if isinstance(_raw_nodes, dict):
                _node_ids = list(_raw_nodes.keys())
            elif isinstance(_raw_nodes, list):
                _node_ids = [
                    (
                        n.get("data", {}).get("id", str(n))
                        if isinstance(n, dict)
                        else str(n)
                    )
                    for n in _raw_nodes
                ]
            else:
                _node_ids = []
            _raw_edges = _cg.get("edges") or []
            if isinstance(_raw_edges, list):
                _edge_pairs = [
                    (
                        [
                            e.get("data", {}).get("source"),
                            e.get("data", {}).get("target"),
                        ]
                        if isinstance(e, dict)
                        else e
                    )
                    for e in _raw_edges
                ]
            else:
                _edge_pairs = []
            _sg_payload = {
                "version": "1",
                "generated_at": datetime.datetime.now().isoformat(),
                "data": {"nodes": _node_ids, "edges": _edge_pairs},
            }
            (_cache_dir / "static_graph.json").write_text(
                json.dumps(_sg_payload, indent=2, ensure_ascii=False), encoding="utf-8"
            )
        except Exception as _sge:
            print(
                f"[bpy] Warning: Failed to write static_graph cache: {_sge}",
                file=sys.stderr,
            )

    else:
        # Text output - use human-readable format
        if structured_out_path:
            _write_text_output(payload, structured_out_path)
        elif args.summary:
            # Human-readable summary to stdout
            _print_human_summary(payload)
        else:
            # Default text output to stdout
            _write_text_output(payload, None)

    # Save baseline performance snapshot if performance profiling was enabled
    if args.enable_perf and isinstance(result, dict):
        # Only show message if not in JSON-only mode
        suppress_messages = output_format == "json"
        if not suppress_messages:
            _save_baseline_snapshot(args.project, result)
        else:
            # Save silently
            try:
                project_root = Path(args.project).resolve()
                baseline_dir = project_root / ".branchpy" / "reports"
                baseline_file = baseline_dir / "baseline.json"
                baseline_dir.mkdir(parents=True, exist_ok=True)
                perf_data = result.get("performance", {})
                if not perf_data:
                    summary = result.get("summary", {})
                    perf_data = {
                        "duration_seconds": summary.get("duration", 0.0),
                        "labels_per_second": summary.get("labels_per_sec", 0.0),
                        "memory_peak_mb": summary.get("memory_peak_mb", 0.0),
                        "labels_count": summary.get("labels", 0),
                        "files_count": summary.get("files", 0),
                    }

                # Extract flowchart if present
                flowchart_summary = None
                if "flowchart" in result:
                    fc = result["flowchart"]
                    flowchart_summary = {
                        "cfg_edges_count": len(fc.get("cfg_edges", [])),
                        "pfi_edges_count": len(fc.get("pfi_edges", [])),
                        "sae_edges_count": len(fc.get("sae_edges", [])),
                        "erp_edges_count": len(fc.get("erp_edges", [])),
                        "edges_by_origin": fc.get("edges_by_origin", {}),
                    }

                baseline = {
                    "timestamp": datetime.datetime.now().isoformat(),
                    "project": str(project_root),
                    "performance": perf_data,
                    "summary": result.get("summary", {}),
                    "version": result.get("version", "unknown"),
                }

                # Include flowchart summary if available
                if flowchart_summary:
                    baseline["flowchart"] = flowchart_summary

                baseline_file.write_text(
                    json.dumps(baseline, indent=2, ensure_ascii=False), encoding="utf-8"
                )
            except Exception:
                pass  # Silently ignore errors in JSON mode

    # Emit telemetry metrics and complete session (v1.0.0 Phase 2)
    if telemetry_writer and isinstance(result, dict):
        try:
            analysis_duration_ms = (time.perf_counter() - analysis_start_time) * 1000
            summary = result.get("summary", {})
            # Ensure session_id not None for metric objects
            if session_id is None:
                session_id = ""

            # Emit performance metrics
            telemetry_writer.write_metric(
                TelemetryMetric(
                    ts=telemetry_writer.iso_now(),
                    session_id=session_id,
                    name="bpy_stats_duration_ms",
                    value=analysis_duration_ms,
                    unit="ms",
                    tags=(
                        {"engine": args.engine}
                        if telemetry_writer.privacy != "minimal"
                        else {}
                    ),
                )
            )

            # Emit label count metric
            label_count = summary.get("labels", 0)
            if label_count > 0:
                telemetry_writer.write_metric(
                    TelemetryMetric(
                        ts=telemetry_writer.iso_now(),
                        session_id=session_id,
                        name="analyze.labels_processed",
                        value=label_count,
                        unit="count",
                        tags={},
                    )
                )

            # Emit analyze.done event
            end_event = TelemetryEvent(
                ts=telemetry_writer.iso_now(),
                session_id=session_id,
                trace_id=trace_id,
                category="analyze",
                name="analyze.done",
                module="analyzer",
                duration_ms=analysis_duration_ms,
                attrs=(
                    {
                        "labels": label_count,
                        "issues": len(result.get("issues", [])),
                        "status": "ok",
                    }
                    if telemetry_writer.privacy != "minimal"
                    else {}
                ),
                level="info",
            )
            telemetry_writer.write_event(end_event)

            # Close session
            session = TelemetrySession(
                session_id=session_id,
                app="BranchPyApp",
                version=importlib.metadata.version("branchpy"),
                engine=args.engine,
                privacy=telemetry_writer.privacy,
                started_at=None,  # Not updated
                ended_at=telemetry_writer.iso_now(),
            )
            telemetry_writer.write_session(session)

            # Emit governance flush event — always, regardless of telemetry store
            # emit_governance_flush_event writes to local JSONL via LocalTelemetryWriter
            config = load_config(Path(args.project).resolve())
            try:
                from branchpy.telemetry.emit_governance import (
                    emit_governance_flush_event,
                )

                emit_governance_flush_event(
                    trigger="post_analysis", workflow="analyzer"
                )
            except Exception as e:
                print(
                    f"[bpy] Warning: Failed to emit governance event: {e}",
                    file=sys.stderr,
                )

        except Exception as e:
            print(f"[bpy] Warning: Telemetry finalization failed: {e}", file=sys.stderr)

    # Check for errors if --fail-on-errors
    if args.fail_on_errors and isinstance(result, dict):
        error_count = 0

        # Check asset validation errors
        if result.get("assets") and result["assets"].get("issues"):
            error_count += sum(
                1
                for issue in result["assets"]["issues"]
                if issue.get("severity", "").lower() == "error"
            )

        # Check CFG/legacy errors
        if result.get("issues"):
            error_count += sum(
                1
                for issue in result["issues"]
                if issue.get("severity", "").lower() == "error"
            )

        if error_count > 0:
            print(
                f"\n[bpy] Found {error_count} ERROR severity issues. Exiting with code 1.",
                file=sys.stderr,
            )
            return 1

    # Show attribution notice if Free tier
    maybe_show_attribution_notice("analyze")

    # --html / --open: generate HTML report artifact
    if getattr(args, "html", False) or getattr(args, "open_browser", False):
        try:
            from branchpy.cli.html_report import (
                announce_html_report,
                generate_analyze_html,
            )
            from branchpy.cli.html_report import open_in_browser as _open_browser
            from branchpy.cli.html_report import resolve_html_output_path

            project_root = Path(args.project).resolve()
            html_path = generate_analyze_html(
                payload,
                project_root,
                resolve_html_output_path(project_root, "analyze", html_out_path),
            )
            announce_html_report("analyze", html_path)
            if getattr(args, "open_browser", False):
                _open_browser(html_path)
        except Exception as _html_err:
            print(
                f"[bpy] Warning: HTML report generation failed: {_html_err}",
                file=sys.stderr,
            )

    # Funnel telemetry — first analyze succeeded (standard path)
    try:
        if _funnel is not None:
            from branchpy.onboarding.constants import (
                EVENT_ONBOARDING_FIRST_ANALYZE_SUCCEEDED,
            )

            _funnel.append(
                build_event(
                    event_type=EVENT_ONBOARDING_FIRST_ANALYZE_SUCCEEDED,
                    surface="cli",
                    session_id=_funnel_session_id,
                    payload={"deep": False},
                )
            )
    except Exception:
        pass

    return 0


if __name__ == "__main__":
    raise SystemExit(main())


def add_parser(subparsers):
    """Register the analyze command with the CLI parser."""
    # Import normalization (Axis5 v0.9.1 - replaced multi-level relative import)
    from branchpy.cli_help import HelpFmt, fmt_examples

    analyze_p = subparsers.add_parser(
        "analyze",
        help="Analyze a project with BranchPy.",
        description="Analyze a project using the modular engine system.",
        epilog=fmt_examples(
            "branchpy --project /path/to/project analyze",
            "branchpy --project /path/to/project analyze --engine renpy",
            "branchpy --project /path/to/project analyze --out analysis.json",
        ),
        formatter_class=HelpFmt,
    )

    # Handler: route to run_deep() if --deep flag is set, otherwise legacy analyze
    def analyze_handler(args):
        if getattr(args, "deep", False):
            return run_deep(args)
        else:
            # Build argv for main() including ALL flags
            argv = [args.project, f"--engine={args.engine}"]
            if args.out:
                argv.append(f"--out={args.out}")
            if args.debug_cfg:
                argv.append(f"--debug-cfg={args.debug_cfg}")
            if getattr(args, "output_format", None):
                argv.append(f"--format={args.output_format}")
            if getattr(args, "json", False):
                argv.append("--json")
            if getattr(args, "stats", False):
                argv.append("--stats")
            if getattr(args, "assets", False):
                argv.append("--assets")
            if getattr(args, "fail_on_errors", False):
                argv.append("--fail-on-errors")
            if getattr(args, "summary", False):
                argv.append("--summary")
            if getattr(args, "emit_semantics", False):
                argv.append("--emit-semantics")
            if hasattr(args, "bqf_analyze"):
                if args.bqf_analyze:
                    argv.append("--bqf-analyze")
                else:
                    argv.append("--no-bqf-analyze")
            if not getattr(args, "enable_perf", True):
                argv.append("--no-perf")
            if getattr(args, "max_nodes", None):
                argv.append(f"--max-nodes={args.max_nodes}")
            if getattr(args, "html", False):
                argv.append("--html")
            if getattr(args, "open_browser", False):
                argv.append("--open")
            return main(argv)

    analyze_p.set_defaults(handler=analyze_handler)
    # No positional project_path argument - uses global --project flag instead
    analyze_p.add_argument(
        "--engine",
        default="renpy",
        choices=["renpy"],
        help="Engine to use (default: renpy)",
    )
    analyze_p.add_argument(
        "--out",
        default="",
        help="Output file for analysis results (use '-' for stdout)",
    )
    analyze_p.add_argument(
        "--format",
        dest="output_format",
        choices=["text", "json"],
        default="text",
        help="Output format for analysis results (default: text)",
    )
    analyze_p.add_argument(
        "--json",
        action="store_true",
        help="Output results in JSON format (deprecated: use --format json)",
    )
    analyze_p.add_argument(
        "--stats", action="store_true", help="Include statistics in output"
    )
    analyze_p.add_argument(
        "--debug-cfg",
        metavar="DOT_FILE",
        default="",
        # SOP §3.3 — Class C flag. Suppressed from public help.
        help=argparse.SUPPRESS,
    )
    analyze_p.add_argument(
        "--internal",
        action="store_true",
        # SOP §3.3 — Class C flag. Not documented in public help.
        help=argparse.SUPPRESS,
    )

    # Deep analysis arguments (Gate 6)
    analyze_p.add_argument(
        "--deep",
        action="store_true",
        help="Use SAE API for deep analysis with progress tracking",
    )
    analyze_p.add_argument(
        "--export-cfg",
        action="store_true",
        # SOP §3.3 — Class C: CFG artifacts are engine internals.
        # Requires --internal. Not documented in public help.
        help=argparse.SUPPRESS,
    )
    analyze_p.add_argument(
        "--fail-on-errors",
        action="store_true",
        help="Exit with code 1 if validation errors found",
    )
    analyze_p.add_argument(
        "--summary",
        action="store_true",
        help="Show enhanced categorized summary report after analysis",
    )

    # Performance profiling (Phase 6 / SAE-06)
    analyze_p.add_argument(
        "--perf",
        dest="enable_perf",
        action="store_true",
        default=True,
        help="Enable performance profiling (default: enabled)",
    )
    analyze_p.add_argument(
        "--no-perf",
        dest="enable_perf",
        action="store_false",
        help="Disable performance profiling for faster analysis",
    )

    # Policy enforcement (v0.7.29)
    analyze_p.add_argument(
        "--policy-mode",
        choices=["off", "warn", "strict"],
        default="off",
        help="Policy enforcement mode (off=disabled, warn=log only, strict=exit on violations)",
    )
    analyze_p.add_argument(
        "--policy-json",
        type=str,
        default="",
        help="Path to policy JSON file with custom rules and severities",
    )

    # Semantic trace export (v0.8.7)
    analyze_p.add_argument(
        "--emit-semantics",
        action="store_true",
        help="Generate semantic trace JSONL file for governance and advanced analytics",
    )

    # Function index export (v0.8.9)
    analyze_p.add_argument(
        "--export-functions",
        action="store_true",
        help="Generate Project Function Index (PFI) with function analysis",
    )
    analyze_p.add_argument(
        "--pfi-format",
        choices=["full", "compact", "by-stat"],
        default="compact",
        help="PFI export format (default: compact)",
    )

    # BQF-Analyze integration (v1.0.0 Wave 4 Phase 4.2)
    analyze_p.add_argument(
        "--bqf-analyze",
        dest="bqf_analyze",
        action="store_true",
        default=True,
        help="Enable BQF-Analyze policies (default: enabled)",
    )
    analyze_p.add_argument(
        "--no-bqf-analyze",
        dest="bqf_analyze",
        action="store_false",
        help="Disable BQF-Analyze policies",
    )

    # Flowchart options (Phase 2)
    analyze_p.add_argument(
        "--max-nodes",
        type=int,
        default=100,
        help="Maximum number of nodes to include in story flowchart (default: 100)",
    )
    analyze_p.add_argument(
        "--html",
        action="store_true",
        help="Generate a standalone HTML report artifact (saved to .branchpy/reports/).",
    )
    analyze_p.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Generate and open an HTML report in the browser (implies --html).",
    )
