# branchpy/commands/interactive_diff_cmd.py

"""
Interactive Diff Command — Phase 2 Workstream B

CLI entrypoint for interactive_diff with test/coverage enrichment.
Intended for VS Code extension consumption and automation workflows.

BQS Compliance:
- Type hints (mypy-compliant)
- Click framework for CLI
- JSON output for machine consumption
- Cross-platform path handling
"""

from __future__ import annotations

import json
from typing import Optional

import click

from ..interactive_diff import interactive_diff


@click.command("interactive-diff")
@click.option("--from", "ref_from", required=True, help="Source ref/branch")
@click.option("--to", "ref_to", required=True, help="Target ref/branch")
@click.option(
    "--tests",
    "tests_json_path",
    type=click.Path(exists=True, dir_okay=False),
    required=False,
    help="Path to pytest JSON report (for failed_tests enrichment).",
)
@click.option(
    "--test-results",
    "tests_json_path_alias",
    type=click.Path(exists=True, dir_okay=False),
    required=False,
    help="Alias for --tests.",
)
@click.option(
    "--coverage",
    "coverage_json_path",
    type=click.Path(exists=True, dir_okay=False),
    required=False,
    help="Path to coverage.py JSON report (for coverage_deltas).",
)
@click.option(
    "--lane-id",
    "lane_id",
    type=str,
    required=False,
    help="Optional lane identifier for History Lanes mapping.",
)
def interactive_diff_cmd(
    ref_from: str,
    ref_to: str,
    tests_json_path: Optional[str],
    tests_json_path_alias: Optional[str],
    coverage_json_path: Optional[str],
    lane_id: Optional[str],
) -> None:
    """
    Compute interactive diff and emit JSON (tests + coverage aware).

    Intended to be consumed by the VS Code extension and automation.

    Examples:
        branchpy interactive-diff --from main --to feature/auth
        branchpy interactive-diff --from main --to feature/auth --tests results.json
        branchpy interactive-diff --from main --to feature/auth --tests results.json --lane-id feature-auth
    """
    # Prefer --tests over --test-results alias
    final_tests_path = tests_json_path or tests_json_path_alias

    payload = interactive_diff(
        ref_from,
        ref_to,
        tests_json_path=final_tests_path,
        coverage_json_path=coverage_json_path,
        lane_id=lane_id,
    )
    click.echo(json.dumps(payload, indent=2, sort_keys=True))


def add_parser(subparsers) -> None:
    """
    Legacy argparse-style registration hook.

    For compatibility with existing CLI architecture.
    """
    # Interactive diff uses Click, so this is a no-op placeholder
    # Actual registration happens via Click group in cli.py
    pass


def run(*args, **kwargs) -> int:
    """Entry point for BranchPy CLI router."""
    interactive_diff_cmd(*args, **kwargs)
    return 0
