# branchpy/patch_state.py
from __future__ import annotations

import json
from pathlib import Path


def _state_path(patch_dir: Path) -> Path:
    return patch_dir / "patch_state.json"


def load_state(patch_dir: Path) -> dict:
    path = _state_path(patch_dir)
    if not path.exists():
        return {"applied": [], "reverted": []}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"applied": [], "reverted": []}


def save_state(patch_dir: Path, state: dict) -> None:
    _state_path(patch_dir).write_text(json.dumps(state, indent=2), encoding="utf-8")


def record_apply(patch_dir: Path, patch_name: str) -> None:
    s = load_state(patch_dir)
    if patch_name not in s["applied"]:
        s["applied"].append(patch_name)
    if patch_name in s["reverted"]:
        s["reverted"].remove(patch_name)
    save_state(patch_dir, s)


def record_undo(patch_dir: Path, patch_name: str) -> None:
    s = load_state(patch_dir)
    if patch_name in s["applied"]:
        s["applied"].remove(patch_name)
    if patch_name not in s["reverted"]:
        s["reverted"].append(patch_name)
    save_state(patch_dir, s)
