"""
branchpy/commands/welcome_cmd.py

CLI Welcome & Getting Started guide for first-time BranchPy users.

Four modes:
    branchpy welcome           → guest first-run guided flow when unauthenticated;
                                  fast path (3 steps) when authenticated
    branchpy welcome --try     → guest first-run guided flow (explicit)
    branchpy welcome --full    → complete 9-step reference guide
    branchpy welcome --compact → one-page command cheat-sheet

The fast path covers login → analyze → flowchart and then directs
users to --full or --compact for the rest.

This command is the CLI equivalent of the VS Code extension's first-run walkthrough.
"""

from __future__ import annotations

import sys

# ---------------------------------------------------------------------------
# Output helpers — no external dependencies
# ---------------------------------------------------------------------------


def _supports_unicode() -> bool:
    """True when stdout encoding is UTF-family.

    Evaluated lazily (module imported only when command is invoked),
    so main() has already reconfigured stdout to UTF-8 by this point.
    """
    try:
        enc = (getattr(sys.stdout, "encoding", None) or "ascii").lower()
        return "utf" in enc
    except Exception:
        return False


_UNICODE = _supports_unicode()


def _line(char: str = "─", width: int = 60) -> str:
    return (char if _UNICODE else "-") * width


def _bar(width: int = 62) -> None:
    print(_line("═", width) if _UNICODE else _line("=", width))


def _divider(width: int = 60) -> None:
    print(_line("─", width) if _UNICODE else _line("-", width))


def _header(text: str) -> None:
    print()
    _bar()
    print(f"  {text}")
    _bar()


def _step(n: int, label: str) -> None:
    arrow = "▶" if _UNICODE else ">"
    print()
    print(f"  {arrow} STEP {n} — {label}")
    print(f"  {_line('·', len(label) + 12)}")


def _cmd(example: str, note: str = "") -> None:
    prefix = "  ›" if _UNICODE else "  $"
    if note:
        print(f"{prefix} {example:<46}  # {note}")
    else:
        print(f"{prefix} {example}")


def _outcome(lines: list[str]) -> None:
    """Explain what this step produces — the 'why should I care' block."""
    mark = "→" if _UNICODE else "->"
    print()
    for ln in lines:
        print(f"  {mark} {ln}")


def _tip(text: str) -> None:
    mark = "💡" if _UNICODE else "[TIP]"
    print(f"  {mark} {text}")


def _section(title: str) -> None:
    print()
    print(f"  {_line('·', 58)}")
    print(f"  {title}")


# ---------------------------------------------------------------------------
# Mode A — Default fast path  (≈60 s read time)
# ---------------------------------------------------------------------------


def _run_fast() -> None:
    _header("Welcome to BranchPy")

    print()
    print("  BranchPy finds structural, variable, and media problems in")
    print("  narrative game projects — before your players do.")
    print()
    print("  Three steps to your first result. Takes about 60 seconds.")
    print()
    _divider()

    # --- STEP 1 ---
    _step(1, "Log in")
    print()
    _cmd("branchpy login", "opens browser — create a free account if needed")
    _cmd("branchpy whoami", "confirm you're authenticated")
    print()

    # --- STEP 2 ---
    _step(2, "Analyze your project")
    print()
    print("  Navigate to your project folder, then:")
    print()
    _cmd("branchpy analyze --open", "analyze + open the HTML report in your browser")
    print()
    _outcome(
        [
            "A full issue report — broken jumps, undefined labels, type mismatches",
            "Foundation data used by every other command (flowchart, pilot, omega)",
            "Saved to .branchpy/reports/ — all subsequent commands read from here",
        ]
    )
    print()

    # --- STEP 3 ---
    _step(3, "Explore your story structure")
    print()
    _cmd("branchpy flowchart --open", "interactive story map, opens in browser")
    print()
    _outcome(
        [
            "Visual map of every scene, choice, and branch in your project",
            "Spot complexity hotspots and disconnected sections at a glance",
            "Updates automatically when you re-run analyze",
        ]
    )

    # --- CI / power-user tip ---
    print()
    _divider()
    print()
    ci_mark = "🔧" if _UNICODE else "[CI]"
    print(
        f"  {ci_mark}  Automating? Every command supports JSON output and exit-code gating:"
    )
    print()
    _cmd("branchpy analyze --format json --fail-on-errors", "CI pipeline integration")
    _cmd(
        "branchpy tests --format json --out report.json",
        "machine-readable test results",
    )
    _tip(
        "All reports are plain files under .branchpy/ — easy to artifact, diff, or upload."
    )

    # --- What next ---
    print()
    _divider()
    print()
    more = "✦" if _UNICODE else "*"
    print(f"  {more}  That's the core workflow. When you're ready for more:")
    print()
    _cmd(
        "branchpy welcome --full",
        "complete guide: stats, pilot, omega, media, licensing",
    )
    _cmd("branchpy welcome --compact", "one-page command cheat-sheet")
    _cmd("branchpy <command> --help", "full flags for any specific command")
    print()
    print("  Docs: https://branchpy.com/docs/1.1.1/")
    print()

    # --- VS Code extension upsell ---
    vsc = "🧩" if _UNICODE else "[VS Code]"
    print(
        f"  {vsc}  Want flowcharts, issue panels, and asset validation inside VS Code?"
    )
    print()
    print("       Install the BranchPy VS Code extension:")
    print(
        "       https://marketplace.visualstudio.com/items?itemName=branchpy.branchpy"
    )
    print()

    # --- Telemetry notice ---
    print()
    _divider()
    tel = "📊" if _UNICODE else "[i]"
    print(
        f"  {tel}  By default, usage data is collected locally only — nothing leaves your machine."
    )
    print("  To review or change this behaviour:  branchpy telemetry mode --show")
    print()


# ---------------------------------------------------------------------------
# Mode B — Full guide  (9 steps, complete reference)
# ---------------------------------------------------------------------------


def _run_full() -> None:
    _header("BranchPy — Complete Getting Started Guide")

    print()
    print("  BranchPy is a static analysis and quality tool for narrative")
    print("  and visual-novel game projects (Ren'Py, Godot, Unity, and more).")
    print()
    _tip("Run  branchpy <command> --help  at any time for full flag details.")

    # ------------------------------------------------------------------
    # STEP 1: Log in
    # ------------------------------------------------------------------
    _step(1, "Authenticate")
    print()
    print("  Create a free account at https://branchpy.com then log in:")
    print()
    _cmd("branchpy login", "opens browser-based login flow")
    _cmd("branchpy whoami", "confirm you are authenticated")
    _cmd("branchpy logout", "sign out of this machine")

    # ------------------------------------------------------------------
    # STEP 2: Verify setup
    # ------------------------------------------------------------------
    _step(2, "Verify your setup")
    print()
    _cmd("branchpy doctor", "checks Python, engine, config, daemon")
    _cmd("branchpy config show", "view current project configuration")
    _cmd("branchpy --project /my/game doctor", "run doctor on a specific project path")

    # ------------------------------------------------------------------
    # STEP 3: Analyze
    # ------------------------------------------------------------------
    _step(3, "Analyze your project")
    print()
    print("  Navigate to your project folder (or pass --project):")
    print()
    _cmd("branchpy analyze", "text report in terminal")
    _cmd("branchpy analyze --html --open", "HTML report, opens in browser")
    _cmd("branchpy analyze --deep", "deep SAE analysis with progress tracking")
    _cmd("branchpy analyze --format json", "JSON output for CI pipelines")
    _cmd("branchpy analyze --out report.txt", "write to file")
    _cmd("branchpy analyze --fail-on-errors", "exit 1 on errors — CI gate")
    _cmd("branchpy analyze --summary", "enhanced categorized summary")
    _cmd(
        "branchpy analyze --policy-mode strict",
        "enforce policy rules, fail on violations",
    )
    print()
    _outcome(
        [
            "Full issue report: broken jumps, orphan labels, undefined calls, type mismatches",
            "Foundation artifact (.branchpy/) — flowchart, pilot, and omega all build on this",
            "JSON output is Class B (stable schema, safe for CI integration and archival)",
        ]
    )

    # ------------------------------------------------------------------
    # STEP 4: Flowchart
    # ------------------------------------------------------------------
    _step(4, "Story flowchart")
    print()
    _cmd("branchpy flowchart --open", "generate + open in browser")
    _cmd("branchpy flowchart --html", "save to .branchpy/reports/")
    _cmd("branchpy flowchart --out flow.html", "save to a custom path")
    print()
    _outcome(
        [
            "Interactive visual map of every scene, choice, and branch",
            "Reveals complexity hotspots and disconnected story sections instantly",
            "Auto-reruns analyze if no fresh output is found",
        ]
    )

    # ------------------------------------------------------------------
    # STEP 5: Stats
    # ------------------------------------------------------------------
    _step(5, "Variable & flag consistency — Stats")
    print()
    print("  Check stat variables (trust, boldness, flags…) for")
    print("  duplicates, type mismatches, and misuse patterns:")
    print()
    _cmd("branchpy stats", "text summary")
    _cmd("branchpy stats --html --open", "HTML report, open in browser")
    _cmd("branchpy stats --format json", "JSON output")
    _cmd("branchpy stats --detailed", "per-variable breakdown")
    _cmd("branchpy stats --out stats.json", "write to file")
    print()
    _outcome(
        [
            "Catches variables set to conflicting types across scenes",
            "Detects duplicate definitions that silently overwrite each other",
        ]
    )

    # ------------------------------------------------------------------
    # STEP 6: Pilot
    # ------------------------------------------------------------------
    _step(6, "Deep variable tracking — Pilot (History Lanes)")
    print()
    print("  Full variable-flow timeline with condition trace and narrative")
    print("  path analysis. Run after analyze.")
    print()
    _cmd("branchpy pilot", "run Pilot analysis")
    _cmd("branchpy pilot --html --open", "HTML report, open in browser")
    _cmd("branchpy pilot --max-paths 1000", "raise path limit (default: 500)")
    _cmd("branchpy pilot --max-depth 200", "raise depth limit (default: 100)")
    _cmd("branchpy pilot --policy-mode strict", "enforce policies on variable flow")
    print()
    _outcome(
        [
            "Traces every value a variable can take across all reachable paths",
            "Identifies impossible conditions, dead flags, and reachability gaps",
            "Powers the Omega state-space analysis (next step)",
        ]
    )

    # ------------------------------------------------------------------
    # STEP 7: Omega
    # ------------------------------------------------------------------
    _step(7, "State-space analysis — Omega")
    print()
    print("  Derives min/max bounds and co-occurrence signals from Pilot output.")
    print("  Run Pilot first, or Omega will auto-recompute it.")
    print()
    _cmd("branchpy omega", "derive state-space bounds")
    _cmd("branchpy omega --html --open", "HTML report, open in browser")
    _cmd("branchpy omega --no-auto-recompute", "skip auto-recomputing pilot if stale")
    print()
    _outcome(
        [
            "Proves which variable value combinations are actually reachable",
            "Exposes impossible co-occurrences (e.g. two mutually exclusive flags both true)",
        ]
    )

    # ------------------------------------------------------------------
    # STEP 8: Tests
    # ------------------------------------------------------------------
    _step(8, "Structural tests — jumps, labels, orphans")
    print()
    _cmd("branchpy tests", "run structural tests")
    _cmd("branchpy tests --format json", "JSON output for CI")
    _cmd("branchpy tests --save-report", "persist timestamped report")
    _cmd("branchpy tests --out results.json", "write to file")
    print()
    _outcome(
        [
            "Catches missing jump/call targets, orphan labels, and dead ends",
            "JSON output + exit code make this a drop-in CI quality gate",
        ]
    )

    # ------------------------------------------------------------------
    # STEP 9: Media
    # ------------------------------------------------------------------
    _step(9, "Media asset validation")
    print()
    _cmd("branchpy media --missing", "referenced-but-missing assets")
    _cmd("branchpy media --unused", "on-disk assets not referenced in scripts")
    _cmd("branchpy media --missing --html --open", "HTML report, open in browser")
    _cmd("branchpy media --missing --ext .png,.ogg", "filter by extension")
    _cmd("branchpy media --unused --fail-on-unused", "exit 1 if unused found (CI gate)")
    print()
    _outcome(
        [
            "Prevents missing-asset crashes that only surface at runtime",
            "Identifies build bloat from unused files before shipping",
        ]
    )

    # ------------------------------------------------------------------
    # Common flags
    # ------------------------------------------------------------------
    _section("Common output flags — available on most commands")
    print()
    w = 22
    print(f"  {'FLAG':<{w}}  EFFECT")
    print(f"  {_line('·', w)}  {_line('·', 34)}")
    print(f"  {'--html':<{w}}  Save a standalone HTML report to .branchpy/reports/")
    print(f"  {'--open':<{w}}  Save HTML and open immediately in browser")
    print(f"  {'--format json':<{w}}  Machine-readable JSON (stable schema, CI-safe)")
    print(f"  {'--out FILE':<{w}}  Write output to a specific file path")
    print(f"  {'--fail-on-errors':<{w}}  Exit code 1 if any errors found (CI gate)")
    print(f"  {'--project PATH':<{w}}  Global flag — point at any project folder")

    # ------------------------------------------------------------------
    # CI positioning
    # ------------------------------------------------------------------
    _section("CI / automation")
    print()
    ci_mark = "🔧" if _UNICODE else "[CI]"
    print(
        f"  {ci_mark}  BranchPy is designed for integration, not just interactive use."
    )
    print()
    _cmd("branchpy analyze --format json --fail-on-errors", "analysis quality gate")
    _cmd("branchpy tests --format json --out report.json", "structural test gate")
    _cmd("branchpy media --missing --fail-on-unused", "asset integrity gate")
    print()
    _tip(
        "All output files live under .branchpy/ — easy to archive, diff, or upload as CI artifacts."
    )

    # ------------------------------------------------------------------
    # Licensing
    # ------------------------------------------------------------------
    _section("License management")
    print()
    _cmd("branchpy activate --key <YOUR_KEY>", "activate a commercial license")
    _cmd("branchpy status", "show license status and tier")
    _cmd("branchpy deactivate", "release seat / transfer to new machine")

    # ------------------------------------------------------------------
    # Help
    # ------------------------------------------------------------------
    _section("Help & resources")
    print()
    _cmd("branchpy <command> --help", "full flags for any command")
    _cmd("branchpy help <command>", "command quick-reference")
    _cmd("branchpy doctor", "diagnose environment issues")
    _cmd("branchpy support", "create a support bundle for bug reports")
    print()
    print(f"  {'Documentation:':<20} https://branchpy.com/docs/1.1.1/")
    print(f"  {'Community:':<20} https://branchpy.com/community/")
    print(f"  {'Support:':<20} support@branchpy.com")

    # ------------------------------------------------------------------
    # Telemetry notice
    # ------------------------------------------------------------------
    _section("Telemetry & privacy")
    print()
    tel = "📊" if _UNICODE else "[i]"
    print(
        f"  {tel}  BranchPy may collect anonymous usage data to help improve analysis quality."
    )
    print("  By default, collection is local only — no data leaves your machine.")
    print("  No source code, paths, or personal data is ever stored.")
    print()
    _cmd("branchpy telemetry mode --show", "check current telemetry settings")
    print("  Privacy policy: https://branchpy.com/privacy")
    print()
    mark = "✓" if _UNICODE else "[OK]"
    print(f"  {mark}  Ready.  Start with:  branchpy analyze --open")
    print()


# ---------------------------------------------------------------------------
# Mode C — Compact cheat-sheet
# ---------------------------------------------------------------------------


def _run_compact() -> None:
    L = _line("─", 58)
    print(
        f"""
BranchPy CLI — Quick Reference
{L}
  AUTH        branchpy login | whoami | logout
  SETUP       branchpy doctor | branchpy config show
  ANALYZE     branchpy analyze [--deep] [--html] [--open] [--format json]
  FLOWCHART   branchpy flowchart [--open] [--html] [--out FILE]
  STATS       branchpy stats [--html] [--open] [--format json] [--detailed]
  PILOT       branchpy pilot [--html] [--open] [--max-paths N]
  OMEGA       branchpy omega [--html] [--open]
  TESTS       branchpy tests [--format json] [--save-report]
  MEDIA       branchpy media --missing | --unused  [--html] [--open]
  LICENSE     branchpy activate --key <KEY> | status | deactivate
  HELP        branchpy <command> --help

  Shared flags: --html  --open  --format json  --out FILE  --fail-on-errors
  CI gate:      branchpy analyze --format json --fail-on-errors
{L}
  Full guide:   branchpy welcome --full
  Docs:         https://branchpy.com/docs/1.1.1/
"""
    )


# ---------------------------------------------------------------------------
# Mode D — Guest first-run guided flow  (value before registration)
# ---------------------------------------------------------------------------


def _is_authenticated() -> bool:
    """Return True if this machine has an active BranchPy session."""
    try:
        from branchpy.license.auth import is_authenticated

        return is_authenticated()
    except Exception:
        return False


def _run_guest_first_run(project_path: str | None = None) -> int:
    """Guest first-run flow — interactive (CLI) or non-interactive (VS Code).

    When project_path is given the function skips all prompts and runs
    non-interactively.  VS Code emits the welcome/try/folder events itself;
    Python emits detection, device, and report events.

    Flow: folder selection → root detection → device confirm → Quick Project Scan
          → post-report conversion CTA.

    Returns 0 on success, 1 on unrecoverable failure.
    """
    import uuid

    from branchpy.onboarding.activation_funnel import ActivationFunnelStore, build_event
    from branchpy.onboarding.constants import (
        ACTIVATION_FUNNEL_SUBMODULE_PROJECT_ROOT,
        EVENT_ACTIVATION_DEVICE_CONFIRMED,
        EVENT_ACTIVATION_DEVICE_SKIPPED,
        EVENT_ACTIVATION_FIRST_REPORT_FAILED,
        EVENT_ACTIVATION_FIRST_REPORT_STARTED,
        EVENT_ACTIVATION_FIRST_REPORT_SUCCEEDED,
        EVENT_ACTIVATION_FOLDER_SELECTED,
        EVENT_ACTIVATION_PROJECT_CONFIRMED,
        EVENT_ACTIVATION_PROJECT_DETECTION_COMPLETED,
        EVENT_ACTIVATION_SIGNUP_CTA_SHOWN,
        EVENT_ACTIVATION_TRY_NOW_CLICKED,
        EVENT_ACTIVATION_WELCOME_OPENED,
        QUICK_PROJECT_SCAN_REPORT_TYPE,
    )
    from branchpy.onboarding.guest_device_token import (
        create_or_reuse_guest_device_token,
    )
    from branchpy.onboarding.guest_session import (
        create_guest_session,
        save_guest_session,
    )
    from branchpy.onboarding.project_root_detection import (
        detect_project_candidates,
        detection_completed_payload,
        project_confirmed_payload,
    )

    session_id = str(uuid.uuid4())
    non_interactive = project_path is not None
    surface = "vscode" if non_interactive else "cli"
    funnel = ActivationFunnelStore()

    def emit(
        event_type: str, payload: dict | None = None, *, submodule: str | None = None
    ) -> None:
        try:
            funnel.append(
                build_event(
                    event_type=event_type,
                    surface=surface,
                    session_id=session_id,
                    payload=payload or {},
                    submodule=submodule,
                )
            )
        except Exception:
            pass  # Never block the flow on telemetry errors

    # ── Welcome surface ──────────────────────────────────────────────
    if not non_interactive:
        _header("Welcome to BranchPy")
        print()
        print("  See the structure of your Ren'Py project in seconds.")
        print()
        emit(EVENT_ACTIVATION_WELCOME_OPENED, {"trigger": "first_run"})

        print("  This guide will run a Quick Project Scan on your project")
        print("  without needing an account first.")
        print()
        _divider()

        # Signal CTA taken (user is already in the flow from having run the command)
        emit(EVENT_ACTIVATION_TRY_NOW_CLICKED)

    # ── Folder selection ─────────────────────────────────────────────
    if non_interactive:
        # project_path was provided via --project flag (e.g. from VS Code)
        selected_folder = project_path  # type: ignore[assignment]
    else:
        print()
        print("  Select your Ren'Py project folder")
        print()
        print("  Choose the main folder for your project —")
        print("  BranchPy will find the right location automatically.")
        print()
        selected_folder = input(
            "  Folder path (or press Enter to use current directory): "
        ).strip()
        if not selected_folder:
            selected_folder = "."

    from pathlib import Path

    selected_path = Path(selected_folder).expanduser().resolve()
    parts = selected_path.parts
    emit(
        EVENT_ACTIVATION_FOLDER_SELECTED,
        {
            "selected_path_depth": len(parts),
            "method": "cli_argument",
        },
    )

    # ── Root detection ───────────────────────────────────────────────
    if not non_interactive:
        print()
        print("  BranchPy is looking for your project…")
    result = detect_project_candidates(selected_path)

    detection_payload = detection_completed_payload(result)
    emit(
        EVENT_ACTIVATION_PROJECT_DETECTION_COMPLETED,
        {**detection_payload, "submodule": ACTIVATION_FUNNEL_SUBMODULE_PROJECT_ROOT},
        submodule=ACTIVATION_FUNNEL_SUBMODULE_PROJECT_ROOT,
    )

    if result.best_candidate is None:
        if not non_interactive:
            print()
            print("  BranchPy couldn't find a Ren'Py project near that folder.")
            print()
            print("  BranchPy expects a folder that contains a game/ directory")
            print("  with .rpy script files.")
            print()
            print("  Example:")
            print("    MyGame/          ← select this folder")
            print("      game/")
            print("        script.rpy")
            print()
            print(
                "  Run  branchpy welcome --try  to try again with a different folder."
            )
        return 1

    # Single or multiple candidates — show best for confirmation
    if not non_interactive:
        print()
        print(f"  You selected:      {selected_path}")
        print(f"  BranchPy detected: {result.best_candidate.resolved_root}")
        if result.candidate_count > 1:
            print()
            print(
                f"  (Found {result.candidate_count} possible projects. Using the best match.)"
            )
            print("  Run  branchpy welcome --try  to choose a different one.")
        print()
        confirm = input("  Use this project? [Y/n]: ").strip().lower()
        if confirm not in {"", "y", "yes"}:
            print()
            print("  Run  branchpy welcome --try  with a different folder path.")
            return 0

    resolved_root = str(result.best_candidate.resolved_root)
    confirmed_payload = project_confirmed_payload(result)
    emit(
        EVENT_ACTIVATION_PROJECT_CONFIRMED,
        confirmed_payload,
        submodule=ACTIVATION_FUNNEL_SUBMODULE_PROJECT_ROOT,
    )

    # ── Device confirmation ──────────────────────────────────────────
    device_token = None
    if non_interactive:
        # Auto-confirm: VS Code handles the device prompt in its own UI
        try:
            gdt = create_or_reuse_guest_device_token()
            device_token = gdt.token
            emit(
                EVENT_ACTIVATION_DEVICE_CONFIRMED,
                {
                    "token_created": True,
                    "token_was_existing": False,
                },
            )
        except Exception:
            emit(EVENT_ACTIVATION_DEVICE_SKIPPED)
    else:
        print()
        _divider()
        print()
        print("  Confirm this device to continue")
        print()
        print("  We'll associate this device with your session so your project")
        print("  and first scan can carry forward when you create an account.")
        print()
        device_confirm = input("  Confirm and continue? [Y/n]: ").strip().lower()
        if device_confirm not in {"", "y", "yes"}:
            print()
            print("  Continuing without saving device context.")
            print(
                "  Your scan will still run, but setup won't carry forward automatically."
            )
            emit(EVENT_ACTIVATION_DEVICE_SKIPPED)
        else:
            try:
                gdt = create_or_reuse_guest_device_token()
                device_token = gdt.token
                emit(
                    EVENT_ACTIVATION_DEVICE_CONFIRMED,
                    {
                        "token_created": True,
                        "token_was_existing": False,
                    },
                )
            except Exception:
                print()
                print("  BranchPy couldn't save your device context.")
                print(
                    "  Your scan can still run, but setup won't carry forward automatically."
                )
                print()
                retry = input("  Run scan anyway? [Y/n]: ").strip().lower()
                if retry not in {"", "y", "yes"}:
                    return 0
                emit(EVENT_ACTIVATION_DEVICE_SKIPPED)

    # ── Quick Project Scan ───────────────────────────────────────────
    if not non_interactive:
        print()
        _divider()
        print()
        print("  Scanning your project…")
        print("  BranchPy is reading your scripts and building a picture of")
        print("  your project structure.")
        print()

    emit(
        EVENT_ACTIVATION_FIRST_REPORT_STARTED,
        {"report_type": QUICK_PROJECT_SCAN_REPORT_TYPE},
    )

    import subprocess
    import time

    start = time.monotonic()
    try:
        proc = subprocess.run(
            ["branchpy", "--project", resolved_root, "analyze", "--html"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        duration_ms = int((time.monotonic() - start) * 1000)
        success = proc.returncode == 0

        # Parse the HTML report path from stderr if the analyze command emitted it
        import re as _re

        html_report_path: str | None = None
        for line in (proc.stderr or "").splitlines():
            m = _re.search(r"\[bpy\] Analyze HTML report:\s+(.+)$", line.strip())
            if m:
                html_report_path = m.group(1).strip()
                break
    except Exception as exc:
        if not non_interactive:
            print(f"  The scan didn't complete: {exc}")
            print()
            print("  Try running  bpy doctor  to check your setup, or choose a")
            print("  different folder and try again.")
        emit(
            EVENT_ACTIVATION_FIRST_REPORT_FAILED,
            {
                "report_type": QUICK_PROJECT_SCAN_REPORT_TYPE,
                "failure_stage": "analysis",
                "error_code": "SUBPROCESS_ERROR",
            },
        )
        return 1

    if not success:
        if not non_interactive:
            print("  The scan didn't complete.")
            print()
            print("  Try running  bpy doctor  to check your setup, or choose a")
            print("  different folder and try again.")
        emit(
            EVENT_ACTIVATION_FIRST_REPORT_FAILED,
            {
                "report_type": QUICK_PROJECT_SCAN_REPORT_TYPE,
                "failure_stage": "analysis",
                "error_code": "ANALYZE_NONZERO_EXIT",
            },
        )
        return 1

    emit(
        EVENT_ACTIVATION_FIRST_REPORT_SUCCEEDED,
        {
            "report_type": QUICK_PROJECT_SCAN_REPORT_TYPE,
            "duration_ms": duration_ms,
            "had_findings": True,
        },
    )

    # Persist guest session for later handoff
    try:
        session = create_guest_session(
            selected_path=str(selected_path),
            resolved_root=resolved_root,
            report_type=QUICK_PROJECT_SCAN_REPORT_TYPE,
            report_output_path=html_report_path,
            report_session_id=session_id,
            local_guest_device_token=device_token,
            entry_surface=surface,
        )
        save_guest_session(session)
    except Exception:
        pass  # Non-fatal — report already ran

    # ── Post-report conversion CTA ───────────────────────────────────
    if not non_interactive:
        print()
        _bar()
        print()
        print("  Your project is ready.")
        print()
        print("  Create a free account to save your results, run more commands,")
        print("  and keep going where you left off.")
        print()
        mark = "▶" if _UNICODE else ">"
        print(f"  {mark}  Create a free account to continue:")
        print("       https://branchpy.com/register")
        print()
        print("  Already have an account?  branchpy login")
        print()
        _bar()
        print()
        emit(EVENT_ACTIVATION_SIGNUP_CTA_SHOWN)

    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run(args=None) -> int:
    """Entry point for `branchpy welcome`."""
    compact = getattr(args, "compact", False)
    full = getattr(args, "full", False)
    guest_try = getattr(args, "try_guest", False)
    project_path = getattr(args, "project_path", None)

    # Guest first-run: explicit --try flag, --project path, or no authenticated session
    if (
        guest_try
        or project_path
        or (not compact and not full and not _is_authenticated())
    ):
        return _run_guest_first_run(project_path=project_path)

    try:
        from branchpy.telemetry import collector as telemetry_collector

        mode = "compact" if compact else ("full" if full else "fast")
        telemetry_collector.emit(
            "cli.welcome.shown",
            {"compact": compact, "full": full, "unicode": _UNICODE, "mode": mode},
        )
    except Exception:
        pass  # Never block welcome on telemetry errors

    if compact:
        _run_compact()
    elif full:
        _run_full()
    else:
        _run_fast()

    return 0


def add_parser(subparsers) -> None:
    p = subparsers.add_parser(
        "welcome",
        help="Show the getting-started guide for new BranchPy users.",
        description=(
            "Display an onboarding guide for first-time BranchPy CLI users.\n\n"
            "Default (unauthenticated): guided guest first-run flow — select project,\n"
            "  run Quick Project Scan, create a free account to continue.\n"
            "Default (authenticated): 3-step fast path (login → analyze → flowchart).\n"
            "Use --try to always enter the guest first-run flow.\n"
            "Use --full for the complete 9-step reference guide.\n"
            "Use --compact for a one-page command cheat-sheet."
        ),
    )
    mode = p.add_mutually_exclusive_group()
    mode.add_argument(
        "--try",
        dest="try_guest",
        action="store_true",
        help="Run the interactive guest first-run flow (try BranchPy on your project).",
    )
    mode.add_argument(
        "--full",
        action="store_true",
        help="Show the complete 9-step reference guide.",
    )
    mode.add_argument(
        "--compact",
        action="store_true",
        help="Show a one-page command cheat-sheet.",
    )
    p.add_argument(
        "--project",
        dest="project_path",
        metavar="PATH",
        default=None,
        help="Pre-selected project folder — skips interactive prompts (used when launched from VS Code).",
    )
    p.set_defaults(handler=run)
