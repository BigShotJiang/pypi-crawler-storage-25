# branchpy/commands/serve_cmd.py
import argparse
import json
import mimetypes
import os
import secrets
import sys
import threading
import time
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from ..cli_help import HelpFmt, fmt_examples
from ..commands import doctor_cmd
from ..contract import VERSION
from ..project_resolver import resolve_project

# Single source of truth for dashboard port
DEFAULT_PORT = int(os.environ.get("BRANCHPY_DASHBOARD_PORT", "8765"))
HOST = "127.0.0.1"  # loopback only

ROOT = Path.cwd()
DASHBOARD_ROOT = Path(__file__).parent.parent / "dashboard"
ASSETS_ROOT = DASHBOARD_ROOT / "assets"
REPORT_FILE = ROOT / ".branchpy" / "out" / "latest_report.json"

# Ensure deterministic MIME (Windows sometimes misses .js)
mimetypes.add_type("application/javascript", ".js")


def _timestamp() -> str:
    """Return formatted timestamp for log messages."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _log(message: str) -> None:
    """Print message with timestamp prefix."""
    print(f"[{_timestamp()}] {message}")


mimetypes.add_type("text/css", ".css")


def _utcnow_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _is_under(root: Path, target: Path) -> bool:
    try:
        target.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _send_json(handler, obj: dict, status: int = 200):
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


def _send_bytes(handler, data: bytes, content_type: str, status: int = 200):
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(data)))
    handler.end_headers()
    handler.wfile.write(data)


class BranchPyHTTPHandler(BaseHTTPRequestHandler):
    """HTTP request handler for BranchPy local dashboard."""

    def __init__(self, *args, project_root=None, **kwargs):
        self.project_root = project_root or "."
        super().__init__(*args, **kwargs)

    def _read_report(self):
        """Read the latest report JSON from project location."""
        if not REPORT_FILE.exists():
            return {"schema_version": "1", "version": VERSION, "report": None}

        try:
            # Atomic read
            with REPORT_FILE.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"schema_version": "1", "version": VERSION, "report": None}

    def do_GET(self):
        """Handle GET requests."""
        # Normalize path
        parsed = urlparse(self.path)
        path = parsed.path or "/"

        # /api/health
        if path == "/api/health":
            return _send_json(
                self, {"ok": True, "version": VERSION, "time": _utcnow_iso()}
            )

        # /api/report — returns 200 with report or null (no 404/403)
        if path == "/api/report":
            if not REPORT_FILE.exists():
                return _send_json(
                    self,
                    {
                        "schema_version": "1",
                        "version": "0.0.0",
                        "generated_at": _utcnow_iso(),
                        "report_id": None,
                        "report": None,
                    },
                )
            try:
                with REPORT_FILE.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                return _send_json(self, data)
            except Exception as e:
                return _send_json(self, {"ok": False, "error": str(e)}, status=500)

        # /assets/*
        if path.startswith("/assets/"):
            rel = Path(unquote(path[len("/assets/") :]))
            candidate = (ASSETS_ROOT / rel).resolve()
            if not (_is_under(ASSETS_ROOT, candidate) and candidate.is_file()):
                return self._not_found()
            ctype, _ = mimetypes.guess_type(str(candidate))
            try:
                data = candidate.read_bytes()
                return _send_bytes(self, data, ctype or "application/octet-stream")
            except Exception:
                return self._not_found()

        # Root → serve dashboard/index.html
        if path == "/":
            index = (DASHBOARD_ROOT / "index.html").resolve()
            if not (_is_under(DASHBOARD_ROOT, index) and index.is_file()):
                return self._not_found()
            try:
                data = index.read_bytes()
                return _send_bytes(self, data, "text/html; charset=utf-8")
            except Exception:
                return self._not_found()

        # Legacy API endpoints for compatibility
        elif path == "/api/logs":
            self.handle_logs_api(parsed.query)
            return
        elif path == "/api/doctor":
            self.handle_doctor_api()
            return

        # New v0.6.68 dashboard routes
        elif path == "/reports":
            self.handle_reports_index()
            return
        elif path == "/api/reports":
            self.handle_api_reports()
            return
        elif path.startswith("/reports/") and len(path) > 9:
            # Serve individual report files
            report_name = path[9:]  # Remove "/reports/"
            self.handle_report_file(report_name)
            return

        # Fallback
        return self._not_found()

    def do_POST(self):
        """Handle POST requests."""
        parsed_path = urlparse(self.path)
        path = parsed_path.path

        if path == "/api/run":
            self.handle_run_api()
        else:
            self.send_error(404, "Not Found")

    def send_json_response(self, data, cache_control="no-store"):
        """Send a JSON response."""
        response = json.dumps(data, indent=2)
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(response)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", cache_control)
        self.end_headers()
        self.wfile.write(response.encode("utf-8"))

    def serve_asset_file(self, rel_path: str):
        """Serve asset files with strict path validation."""
        # Decode and normalize path
        decoded_path = Path(unquote(rel_path))
        candidate = (ASSETS_ROOT / decoded_path).resolve()

        # Security check: ensure file is under ASSETS_ROOT
        if not _is_under(ASSETS_ROOT, candidate) or not candidate.is_file():
            self.send_error(404, "Not Found")
            return

        try:
            content = candidate.read_bytes()

            self.send_response(200)

            # Set MIME type based on extension
            if candidate.suffix == ".css":
                content_type = "text/css"
            elif candidate.suffix == ".js":
                content_type = "application/javascript"
            else:
                content_type = "application/octet-stream"

            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Error reading file: {e}")

    def _not_found(self):
        msg = b"Not found"
        self.send_response(404)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(msg)))
        self.end_headers()
        self.wfile.write(msg)

    def serve_dashboard_file(self, file_path):
        """Serve a file from the dashboard directory or fallback to inline HTML."""
        full_path = DASHBOARD_ROOT / file_path

        # Security check: ensure file is within dashboard directory
        if not _is_under(DASHBOARD_ROOT, full_path.resolve()):
            self.send_error(403, "Forbidden")
            return

        # If file exists, serve it
        if full_path.exists():
            try:
                content = full_path.read_bytes()

                self.send_response(200)

                # Set appropriate content type based on extension
                if file_path.endswith(".css"):
                    self.send_header("Content-Type", "text/css; charset=utf-8")
                elif file_path.endswith(".js"):
                    self.send_header(
                        "Content-Type", "application/javascript; charset=utf-8"
                    )
                elif file_path.endswith(".html"):
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                else:
                    self.send_header("Content-Type", "application/octet-stream")

                self.send_header("Content-Length", str(len(content)))
                self.send_header(
                    "Cache-Control", "no-store"
                )  # Avoid stale assets during development
                self.end_headers()
                self.wfile.write(content)
                return
            except Exception as e:
                self.send_error(500, f"Error reading file: {e}")
                return

        # Fallback: serve inline HTML for index.html
        if file_path == "index.html":
            self.serve_static_html()
        else:
            self.send_error(404, "Not Found")

    def handle_logs_api(self, query_string):
        """Handle /api/logs endpoint."""
        params = parse_qs(query_string)
        tail_count = int(params.get("tail", ["200"])[0])

        try:
            # Get log file path
            log_dir = os.path.join(os.getenv("LOCALAPPDATA", ""), "BranchPy", "logs")
            log_file = Path(log_dir) / "branchpy.log"

            if not log_file.exists():
                self.send_json_response({"lines": [], "message": "No log file found"})
                return

            # Read last N lines
            with open(log_file, "r", encoding="utf-8") as f:
                lines = f.readlines()[-tail_count:]
                clean_lines = [line.rstrip() for line in lines]

            self.send_json_response(
                {
                    "lines": clean_lines,
                    "tail_count": len(clean_lines),
                    "log_file": str(log_file),
                }
            )

        except Exception as e:
            self.send_json_response({"error": f"Failed to read logs: {e}"})

    def handle_doctor_api(self):
        """Handle /api/doctor endpoint."""
        try:
            # Create proper args namespace for doctor command
            mock_args = argparse.Namespace()
            mock_args.project = self.project_root
            mock_args.json = True

            # Capture doctor output
            import contextlib
            import io

            output_buffer = io.StringIO()
            with contextlib.redirect_stdout(output_buffer):
                doctor_cmd.cmd_doctor(mock_args)

            doctor_output = output_buffer.getvalue()

            # Try to parse as JSON, fallback to text
            try:
                doctor_data = json.loads(doctor_output)
            except Exception:
                doctor_data = {"output": doctor_output, "format": "text"}

            self.send_json_response(doctor_data)

        except Exception as e:
            self.send_json_response({"error": f"Failed to run doctor: {e}"})

    def handle_run_api(self):
        """Handle /api/run endpoint."""
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            post_data = self.rfile.read(content_length)
            request_data = json.loads(post_data.decode("utf-8"))

            cmd = request_data.get("cmd", "tests")
            if cmd not in ["tests", "stats", "checks", "doctor"]:
                self.send_json_response({"error": f"Invalid command: {cmd}"})
                return

            # Queue the command (for now, just return success)
            self.send_json_response(
                {
                    "message": f"Command '{cmd}' queued",
                    "command": cmd,
                    "status": "queued",
                }
            )

        except Exception as e:
            self.send_json_response({"error": f"Failed to queue command: {e}"})

    def handle_reports_index(self):
        """Handle /reports endpoint - show HTML index of reports."""
        try:
            from branchpy.server.serve import _fallback_index_html

            root = Path(self.project_root).resolve()
            html = _fallback_index_html(root)
            html_bytes = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html_bytes)))
            self.end_headers()
            self.wfile.write(html_bytes)
        except Exception as e:
            error_msg = f"Error generating reports index: {e}"
            self.send_error(500, error_msg)

    def handle_api_reports(self):
        """Handle /api/reports endpoint - JSON list of reports."""
        try:
            from branchpy.server.serve import _discover_reports

            root = Path(self.project_root).resolve()
            reports = _discover_reports(root)
            self.send_json_response(reports)
        except Exception as e:
            self.send_json_response({"error": f"Failed to discover reports: {e}"})

    def handle_report_file(self, report_name: str):
        """Handle /reports/{filename} - serve individual report HTML files."""
        try:
            from branchpy.server.serve import _reports_dir

            root = Path(self.project_root).resolve()
            reports_dir = _reports_dir(root)

            # Security check - only allow .html files and no path traversal
            if (
                not report_name.endswith(".html")
                or "/" in report_name
                or "\\" in report_name
            ):
                self.send_error(404, "Report not found")
                return

            report_path = reports_dir / report_name
            if not report_path.exists() or not report_path.is_file():
                self.send_error(404, "Report not found")
                return

            content = report_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Error reading report: {e}")

    def serve_static_html(self):
        """Serve the main dashboard HTML."""
        html_content = self.get_dashboard_html()
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(html_content)))
        self.end_headers()
        self.wfile.write(html_content.encode("utf-8"))

    def get_dashboard_html(self):
        """Generate the dashboard HTML with new design."""
        html_template = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>BranchPy — Dashboard</title>
  <style>
    :root {
      --accent: #36b37e;
      --accent-ink: #0f5132;
      --bg: #0b0f14;
      --panel: #10151c;
      --text: #e8f0f7;
      --muted: #94a3b8;
      --bad: #ef4444;
      --ok: #22c55e;
    }

    * { box-sizing: border-box; }
    body { margin:0; font: 14px/1.5 system-ui, -apple-system, Segoe UI, Roboto, Inter, sans-serif; color: var(--text); background: var(--bg); }
    .bp-header, .bp-footer { background: var(--panel); padding: 12px 16px; display:flex; align-items:center; justify-content:space-between; border-bottom: 1px solid #1e2633; }
    .bp-footer { border-top: 1px solid #1e2633; border-bottom: none; }
    .logo { font-weight: 700; color: var(--accent); }
    .meta { color: var(--muted); font-size: 12px; }
    main { padding: 16px; }
    h1 { margin: 0 0 12px; }
    .summary-cards { display:flex; gap:12px; margin-bottom: 16px; flex-wrap: wrap; }
    .card { background: var(--panel); padding:12px; border-radius:10px; min-width:120px; text-align:center; }
    .card-key { color: var(--muted); font-size: 12px; }
    .card-val { font-size: 20px; font-weight: 700; margin-top: 4px; }
    .table { width: 100%; border-collapse: collapse; }
    .table th, .table td { padding: 8px 10px; border-bottom: 1px solid #1e2633; text-align: left; }
    .table th { color: var(--muted); font-weight: 600; }
    .table tr.missing td { color: var(--bad); }
    .table tr.ok td { color: var(--ok); }
    .table tr.unused td { color: var(--muted); }
    .empty { color: var(--muted); padding: 24px; background: var(--panel); border-radius: 10px; text-align: center; }
    .btn {
      background: var(--accent);
      color: var(--accent-ink);
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      cursor: pointer;
      margin-right: 10px;
      font-weight: 600;
    }
    .btn:hover {
      background: #2a9566;
    }
    .actions { margin-bottom: 20px; }
  </style>
</head>
<body>
  <header class="bp-header">
    <div class="logo">BranchPy</div>
    <div class="meta">
      <span id="bp-version">v{VERSION}</span>
      <span id="bp-updated">—</span>
    </div>
  </header>

  <main id="root">
    <div class="actions">
      <button class="btn" onclick="runCommand('doctor')">🩺 Run Doctor</button>
      <button class="btn" onclick="runCommand('tests')">🧪 Run Tests</button>
      <button class="btn" onclick="runCommand('stats')">📊 Stats</button>
      <button class="btn" onclick="refreshReport()">🔄 Refresh</button>
    </div>
    
    <section class="report">
      <h1 id="report-title">No Report Yet</h1>
      <div id="summary" class="summary-cards"></div>
      <div id="items" class="items-table"></div>
    </section>
  </main>

  <footer class="bp-footer">© BranchPy</footer>
  <script>
    const rootTitle = document.getElementById("report-title");
    const summary = document.getElementById("summary");
    const items = document.getElementById("items");
    const versionEl = document.getElementById("bp-version");
    const updatedEl = document.getElementById("bp-updated");

    async function fetchReport() {
      const res = await fetch("/api/report", { cache: "no-store" });
      return await res.json();
    }

    function renderSummaryCounts(counts = {}) {
      const keys = Object.keys(counts);
      if (!keys.length) return "";
      return keys.map(k => `
        <div class="card">
          <div class="card-key">${k}</div>
          <div class="card-val">${counts[k]}</div>
        </div>
      `).join("");
    }

    function renderItems(list = []) {
      if (!list.length) return `<div class="empty">No items.</div>`;
      const rows = list.map(x => `
        <tr class="${x.status || ''}">
          <td>${x.type || ""}</td>
          <td>${x.path || ""}</td>
          <td>${x.status || ""}</td>
          <td>${x.ref || ""}</td>
        </tr>
      `).join("");
      return `
        <table class="table">
          <thead><tr><th>Type</th><th>Path</th><th>Status</th><th>Ref</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      `;
    }

    function render(data) {
      versionEl.textContent = data.version || "—";
      const r = data.report;
      if (!r) {
        rootTitle.textContent = "No Report Yet";
        summary.innerHTML = "";
        items.innerHTML = `<div class="empty">Run an action to generate a report.</div>`;
        updatedEl.textContent = "";
        return;
      }
      rootTitle.textContent = r.title || r.kind || "Report";
      summary.innerHTML = renderSummaryCounts(r.summary?.counts);
      items.innerHTML = renderItems(r.items);
      updatedEl.textContent = data.generated_at ? `Updated ${new Date(data.generated_at).toLocaleString()}` : "";
    }

    async function runCommand(cmd) {
      try {
        const response = await fetch('/api/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cmd: cmd })
        });
        const data = await response.json();
        
        // Refresh report after a short delay
        setTimeout(tick, 1000);
      } catch (error) {
        console.error('Error running command:', error);
      }
    }

    function refreshReport() {
      tick();
    }

    async function tick() {
      try {
        const data = await fetchReport();
        render(data);
      } catch (e) {
        console.error('Error fetching report:', e);
      } finally {
        setTimeout(tick, 1500); // light polling; can switch to SSE later
      }
    }
    
    // Initialize dashboard
    tick();
  </script>
</body>
</html>"""
        return html_template.format(VERSION=VERSION)

    def log_message(self, format, *args):
        """Override to reduce log verbosity."""
        # Only log errors
        if format.startswith("code"):
            return
        sys.stderr.write(f"[{self.address_string()}] {format % args}\n")


def run(args):
    """
    Start the BranchPy local dashboard server.
    """
    try:
        project_root = Path(resolve_project(args.project)).resolve()
    except Exception as e:
        print(f"Error resolving project: {e}")
        return 1

    port = args.port or DEFAULT_PORT
    host = "127.0.0.1"  # Bind to loopback only for security

    # Generate security token for preview URLs
    token = os.environ.get("BRANCHPY_SERVE_TOKEN") or secrets.token_urlsafe(16)
    os.environ["BRANCHPY_SERVE_TOKEN"] = token

    # Set force flag if requested
    if args.force:
        os.environ["BRANCHPY_SERVE_FORCE"] = "1"

    # Print startup banner
    print("=" * 60)
    _log(f"[BranchPy Serve] Project: {project_root}")
    _log(f"[BranchPy Serve] Starting server on http://{host}:{port}")
    print("=" * 60)

    # Set the project root for the new dashboard server
    os.environ["BRANCHPY_PROJECT"] = str(project_root)

    # Open browser if requested
    if args.open_browser and not args.no_open:

        def open_browser():
            time.sleep(2)  # Give server time to start
            webbrowser.open(f"http://{host}:{port}")

        browser_thread = threading.Thread(target=open_browser, daemon=True)
        browser_thread.start()

    # Open report preview if requested
    if args.preview_report and not args.no_open:

        def open_report():
            time.sleep(2)  # Give server time to start
            report_url = f"http://{host}:{port}/reports/latest.html?t={token}"
            try:
                webbrowser.open(report_url, new=2)  # new tab
            except Exception:
                pass

        report_thread = threading.Thread(target=open_report, daemon=True)
        report_thread.start()

    if not args.headless:
        _log(f"[BranchPy Serve] Dashboard available at: http://{host}:{port}")
        if args.preview_report and not args.no_open:
            _log(
                f"[BranchPy Serve] Report preview will open at: http://{host}:{port}/reports/latest.html"
            )
        _log("[BranchPy Serve] Press Ctrl+C to stop")

    # Use the new v0.6.68 dashboard server
    from branchpy.server.serve import run_dashboard_server

    try:
        run_dashboard_server(host=host, port=port)
        return 0
    except KeyboardInterrupt:
        if not args.headless:
            _log("\n[BranchPy Serve] Stopping server...")
        return 0
    except Exception as e:
        _log(f"[BranchPy Serve] Server error: {e}")
        return 1


def add_parser(subparsers):
    """Register the serve command with the CLI parser."""
    serve_p = subparsers.add_parser(
        "serve",
        help="Start local dashboard server",
        description="Start a local web dashboard for project monitoring and management.",
        epilog=fmt_examples(
            "branchpy serve --project .",
            "branchpy serve --port 8080 --open",
            "branchpy serve --headless",
        ),
        formatter_class=HelpFmt,
    )
    serve_p.set_defaults(handler=run)
    serve_p.add_argument(
        "--project",
        default=".",
        help="Project directory to serve (default: current directory)",
    )
    serve_p.add_argument(
        "--port",
        type=int,
        default=None,
        help=f"Port to serve on (default: env BRANCHPY_DASHBOARD_PORT or {DEFAULT_PORT})",
    )
    serve_p.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Open browser automatically",
    )
    serve_p.add_argument(
        "--headless", action="store_true", help="Run without console output"
    )
    serve_p.add_argument(
        "--preview-report",
        action="store_true",
        help="Open latest report in browser after render",
    )
    serve_p.add_argument(
        "--no-open", action="store_true", help="Do not auto-open a browser window"
    )
    serve_p.add_argument(
        "--force",
        action="store_true",
        help="Force start even if instance appears to be running (clears stale locks)",
    )
