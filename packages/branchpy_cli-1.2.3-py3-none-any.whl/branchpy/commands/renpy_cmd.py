# branchpy/commands/renpy_cmd.py
"""
Ren'Py SDK management commands.
Handles multi-SDK discovery, registration, and project configuration.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ..project_config import load_project_config, save_project_config
from ..renpy_sdk import RenpySdkManager


def cmd_renpy(args: argparse.Namespace) -> int:
    """Handle the renpy subcommand."""
    if args.action == "list":
        return _list_sdks(args.format == "json")
    elif args.action == "detect":
        return _detect_sdks(args.paths, args.format == "json")
    elif args.action == "use":
        return _use_sdk(args.sdk_name, args.project)
    elif args.action == "add":
        return _add_sdk(args.name, args.path)
    elif args.action == "remove":
        return _remove_sdk(args.name, args.force)
    elif args.action == "validate":
        return _validate_sdk(args.sdk_name, args.project)
    elif args.action == "default":
        return _set_default_sdk(args.sdk_name)
    else:
        print(f"Unknown renpy action: {args.action}")
        return 2


def _list_sdks(as_json: bool = False) -> int:
    """List all registered Ren'Py SDKs."""
    manager = RenpySdkManager()
    sdks = manager.list_sdks()

    if not sdks:
        if as_json:
            print(json.dumps({"sdks": [], "message": "No SDKs registered"}))
        else:
            print("No Ren'Py SDKs registered.")
            print("Use 'branchpy renpy detect' to find SDKs automatically,")
            print("or 'branchpy renpy add <name> <path>' to register manually.")
        return 0

    if as_json:
        sdk_data = {}
        for name, sdk in sdks.items():
            sdk_data[name] = {
                "path": sdk.path,
                "version": sdk.version,
                "valid": sdk.valid,
            }
        print(json.dumps({"sdks": sdk_data}))
    else:
        print("Registered Ren'Py SDKs:")
        print("=" * 40)

        for name, sdk in sdks.items():
            status = "✓" if sdk.valid else "✗"
            version = sdk.version or "unknown"
            print(f"{status} {name:15} {version:12} {sdk.path}")

        print()
        print("Legend: ✓ = valid, ✗ = invalid/missing")

    return 0


def _detect_sdks(search_paths: list[str] | None, as_json: bool = False) -> int:
    """Detect Ren'Py SDKs on the system."""
    manager = RenpySdkManager()

    if as_json:
        print(json.dumps({"message": "Detecting SDKs..."}))
    else:
        print("Detecting Ren'Py SDKs...")

    detected_sdks = manager.detect_sdks(search_paths)

    if not detected_sdks:
        if as_json:
            print(json.dumps({"detected": [], "message": "No SDKs found"}))
        else:
            print("No Ren'Py SDKs found.")
            print("Try specifying additional search paths or install Ren'Py.")
        return 0

    # Add detected SDKs to registry
    added_count = 0
    skipped_sdks = []

    for sdk in detected_sdks:
        # Check if already registered
        existing = manager.get_sdk(sdk.name)
        if existing and existing.path == sdk.path:
            skipped_sdks.append(sdk.name)
            continue

        # Handle name conflicts
        original_name = sdk.name
        counter = 1
        while manager.get_sdk(sdk.name):
            sdk.name = f"{original_name}_{counter}"
            counter += 1

        if manager.add_sdk(sdk.name, sdk.path):
            added_count += 1
            if not as_json:
                print(
                    f"Added SDK: {sdk.name} ({sdk.version or 'unknown'}) at {sdk.path}"
                )

    if as_json:
        detected_data = [
            {
                "name": sdk.name,
                "path": sdk.path,
                "version": sdk.version,
                "valid": sdk.valid,
            }
            for sdk in detected_sdks
        ]
        print(
            json.dumps(
                {
                    "detected": detected_data,
                    "added_count": added_count,
                    "skipped": skipped_sdks,
                }
            )
        )
    else:
        print(f"\nDetection complete: {added_count} new SDKs added")
        if skipped_sdks:
            print(f"Skipped {len(skipped_sdks)} already registered SDKs")

    return 0


def _use_sdk(sdk_name: str, project_path: str) -> int:
    """Set the SDK to use for a project."""
    manager = RenpySdkManager()
    sdk = manager.get_sdk(sdk_name)

    if not sdk:
        print(f"SDK '{sdk_name}' not found.")
        print("Use 'branchpy renpy list' to see available SDKs.")
        return 1

    if not sdk.valid:
        print(f"SDK '{sdk_name}' is invalid or inaccessible.")
        return 1

    # Load and update project config
    config = load_project_config(project_path)
    config.renpy_project_pin = sdk_name

    if save_project_config(project_path, config):
        print(f"Set project to use Ren'Py SDK: {sdk_name}")
        if sdk.version:
            print(f"Version: {sdk.version}")
        print(f"Path: {sdk.path}")
        return 0
    else:
        print("Failed to save project configuration.")
        return 1


def _add_sdk(name: str, path: str) -> int:
    """Add an SDK to the registry."""
    manager = RenpySdkManager()

    # Check if name already exists
    if manager.get_sdk(name):
        print(f"SDK '{name}' already exists.")
        print(
            "Use 'branchpy renpy remove' to remove it first, or choose a different name."
        )
        return 1

    # Validate path
    sdk_path = Path(path).resolve()
    if not sdk_path.exists():
        print(f"Path does not exist: {path}")
        return 1

    if manager.add_sdk(name, str(sdk_path)):
        sdk = manager.get_sdk(name)
        print(f"Added SDK: {name}")
        if sdk and sdk.version:
            print(f"Version: {sdk.version}")
        print(f"Path: {sdk_path}")
        return 0
    else:
        print("Failed to add SDK. Path does not contain a valid Ren'Py installation.")
        return 1


def _remove_sdk(name: str, force: bool = False) -> int:
    """Remove an SDK from the registry."""
    manager = RenpySdkManager()
    sdk = manager.get_sdk(name)

    if not sdk:
        print(f"SDK '{name}' not found.")
        return 1

    # Check if it's in use
    config = load_project_config(".")
    in_use = config.renpy_default == name or config.renpy_project_pin == name

    if in_use and not force:
        print(f"SDK '{name}' is currently in use.")
        if config.renpy_default == name:
            print("It is set as the default SDK.")
        if config.renpy_project_pin == name:
            print("It is pinned for this project.")
        print("Use --force to remove anyway, or change the configuration first.")
        return 1

    if manager.remove_sdk(name):
        print(f"Removed SDK: {name}")
        return 0
    else:
        print(f"Failed to remove SDK: {name}")
        return 1


def _validate_sdk(sdk_name: str, project_path: str) -> int:
    """Validate an SDK against a project."""
    manager = RenpySdkManager()
    sdk = manager.get_sdk(sdk_name)

    if not sdk:
        print(f"SDK '{sdk_name}' not found.")
        return 1

    runner = manager.get_runner(sdk_name)
    if not runner:
        print(f"Cannot create runner for SDK '{sdk_name}'.")
        return 1

    print(f"Validating SDK '{sdk_name}' against project at {project_path}")
    print(f"SDK path: {sdk.path}")
    print(f"SDK version: {sdk.version or 'unknown'}")

    # Basic SDK validation
    if not sdk.valid:
        print("✗ SDK is invalid or inaccessible")
        return 1

    print("✓ SDK is accessible")

    # Project validation
    is_valid, message = runner.validate_project(project_path)
    if is_valid:
        print(f"✓ {message}")
        return 0
    else:
        print(f"✗ {message}")
        return 1


def _set_default_sdk(sdk_name: str) -> int:
    """Set the default SDK."""
    manager = RenpySdkManager()
    sdk = manager.get_sdk(sdk_name)

    if not sdk:
        print(f"SDK '{sdk_name}' not found.")
        return 1

    if not sdk.valid:
        print(f"SDK '{sdk_name}' is invalid or inaccessible.")
        return 1

    # Load and update global config
    config = load_project_config(".")
    config.renpy_default = sdk_name

    if save_project_config(".", config):
        print(f"Set default Ren'Py SDK: {sdk_name}")
        if sdk.version:
            print(f"Version: {sdk.version}")
        return 0
    else:
        print("Failed to save configuration.")
        return 1


def add_parser(subparsers):
    """Add the renpy subcommand parser."""
    parser = subparsers.add_parser(
        "renpy",
        help="Manage Ren'Py SDK installations",
        description="Register, detect, and manage multiple Ren'Py SDK versions.",
    )

    parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    subparsers_renpy = parser.add_subparsers(dest="action", required=True)

    # list subcommand
    list_parser = subparsers_renpy.add_parser(
        "list", help="List registered Ren'Py SDKs"
    )

    # detect subcommand
    detect_parser = subparsers_renpy.add_parser(
        "detect", help="Detect Ren'Py SDKs on the system"
    )
    detect_parser.add_argument("paths", nargs="*", help="Additional paths to search")

    # use subcommand
    use_parser = subparsers_renpy.add_parser("use", help="Set SDK for current project")
    use_parser.add_argument("sdk_name", help="Name of the SDK to use")
    use_parser.add_argument(
        "--project", default=".", help="Project path (default: current directory)"
    )

    # add subcommand
    add_parser = subparsers_renpy.add_parser("add", help="Register a new SDK")
    add_parser.add_argument("name", help="Name for the SDK")
    add_parser.add_argument("path", help="Path to SDK root directory")

    # remove subcommand
    remove_parser = subparsers_renpy.add_parser("remove", help="Unregister an SDK")
    remove_parser.add_argument("name", help="Name of the SDK to remove")
    remove_parser.add_argument(
        "--force", action="store_true", help="Force removal even if SDK is in use"
    )

    # validate subcommand
    validate_parser = subparsers_renpy.add_parser(
        "validate", help="Validate SDK against a project"
    )
    validate_parser.add_argument("sdk_name", help="Name of the SDK to validate")
    validate_parser.add_argument(
        "--project", default=".", help="Project path (default: current directory)"
    )

    # default subcommand
    default_parser = subparsers_renpy.add_parser("default", help="Set default SDK")
    default_parser.add_argument("sdk_name", help="Name of the SDK to set as default")

    parser.set_defaults(handler=cmd_renpy)
