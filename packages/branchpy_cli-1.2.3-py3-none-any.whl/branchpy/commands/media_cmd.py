# branchpy/commands/media_cmd.py
import fnmatch
import logging
import os
import re
import sys
import time
from typing import Any, Dict, List, Literal, Optional, Set, Tuple

from branchpy.report import safe_print, safe_print_err
from branchpy.report_writer import (
    create_media_report,
    should_emit_from_args,
    write_report_and_emit,
)

# Module-level import so tests can patch branchpy.commands.media_cmd.analyze_files_for_pfi
try:
    from branchpy.analyzer.pfi_inference import PFI_WRAPPERS, analyze_files_for_pfi
except ImportError:  # pragma: no cover
    PFI_WRAPPERS = {}  # type: ignore[assignment]
    analyze_files_for_pfi = None  # type: ignore[assignment]

log = logging.getLogger("branchpy.media")

# ---- Regexes ---------------------------------------

# Image/file references defined via: image foo bar = "images/bg.png"
IMAGE_DEF_RE = re.compile(r'^\s*image\s+[A-Za-z0-9_ ]+\s*=\s*"(.*?)"\s*$', re.MULTILINE)

# Ren'Py image placeholder definitions: image eileen happy = "characters/eileen_happy.png"
# Captures the placeholder name (e.g., "eileen happy") for later resolution
IMAGE_PLACEHOLDER_DEF_RE = re.compile(
    r'^\s*image\s+([A-Za-z0-9_ ]+)\s*=\s*"(.*?)"\s*$', re.MULTILINE
)

# Colon-form composite/animation image definitions: image menu_bg:
# These have no literal file path — they define a named displayable via indented body.
# We register their name so that `show menu_bg` / `add "menu_bg"` resolves as known.
IMAGE_COMPOSITE_DEF_RE = re.compile(
    r'^\s*image\s+([A-Za-z0-9_ ]+)\s*:', re.MULTILINE
)

# Show/scene with placeholders: show eileen happy, scene bg kitchen
# Captures the placeholder name for lookup
SHOW_SCENE_PLACEHOLDER_RE = re.compile(
    r"^\s*(?:show|scene)\s+([A-Za-z0-9_]+(?: [A-Za-z0-9_]+)*)\s*(?:at|with|behind|onlayer|as|zorder|:|$)",
    re.MULTILINE,
)

# "play <channel>" lines — any channel name (ambient, sfx, theme, …), excludes movie.
# Trailing modifiers (fadein 1.0, loop, channel=) are intentionally NOT anchored.
PLAY_RE = re.compile(r'^\s*play\s+(?!movie\b)\w+\s+"(.*?)"', re.MULTILINE)

# Video playback lines: play movie "cutscene.webm" [modifiers ok]
MOVIE_RE = re.compile(r'^\s*play\s+movie\s+"(.*?)"', re.MULTILINE)

# Python-side movie playback: $ renpy.movie_cutscene("intro.mp4")
MOVIE_CUTSCENE_RE = re.compile(r'renpy\.movie_cutscene\(\s*"(.*?)"\s*\)')

# Voice shortcut: voice "voice/line_001.ogg" [trailing modifiers ok]
VOICE_RE = re.compile(r'^\s*voice\s+"(.*?)"', re.MULTILINE)

# Queue channel: queue music/ambient/sfx/… "path" [GAP-2]
QUEUE_RE = re.compile(r'^\s*queue\s+\w+\s+"(.*?)"', re.MULTILINE)

# Named audio constants: define audio.theme = "audio/main.ogg" [GAP-4]
# Also captures Ren'Py audio-tag paths: define audio.t1 = "<loop 0>bgm/1.ogg"
# _strip_audio_tag() is used at call-site to clean the captured group.
DEFINE_AUDIO_RE = re.compile(r'^\s*define\s+audio\.(\w+)\s*=\s*"(.*?)"', re.MULTILINE)

# Unquoted audio constant reference: play music audio.theme  [indirection]
# Captures the dotted identifier (e.g. "audio.theme") for registry lookup.
PLAY_AUDIO_CONST_RE = re.compile(
    r'^\s*(?:play|queue)\s+\w+\s+(audio\.\w+)\s*(?:#.*)?$', re.MULTILINE
)

# Screen / UI literal file references — Layer C [GAP-7]
# add "gui/frame.png"  |  add "sprites/bg.png"
SCREEN_ADD_RE = re.compile(r'^\s*add\s+"(.*?)"', re.MULTILINE)
# background "gui/textbox.png"  (outside Python context)
SCREEN_BG_STR_RE = re.compile(r'^\s*background\s+"(.*?)"', re.MULTILINE)
# imagebutton idle "btn_idle.png" hover "btn_hover.png" ...
IMAGEBUTTON_RE = re.compile(r'\bidle\s+"(.*?)"|(?:\bhover\s+"(.*?)")', re.MULTILINE)

# Declarative config/gui paths — Layer B [gui.window_background, config.window_icon, …]
# define gui.main_menu_background = "images/menu.png"
# define config.window_icon = "gui/icon.ico"
DEFINE_GUI_RE = re.compile(r'^\s*define\s+(?:gui|config)\.[\w.]+\s*=\s*"(.*?)"', re.MULTILINE)

# Dynamic-risk signals — Layer D [GAP-9 / GAP-12]
# play music <identifier>  (unquoted, not matching audio.X pattern above)
PLAY_DYNAMIC_RE = re.compile(
    r'^\s*(?:play|queue)\s+\w+\s+([A-Za-z_]\w*(?:\.\w+)?)\s*(?:#.*)?$', re.MULTILINE
)
# show expression <variable>  / renpy.music.play(<variable>)
SHOW_EXPRESSION_DYN_RE = re.compile(
    r'^\s*show\s+expression\s+([A-Za-z_]\w*)', re.MULTILINE
)
RENPY_MUSIC_PLAY_DYN_RE = re.compile(
    r'renpy\.(?:music|sound)\.play\s*\(\s*([A-Za-z_]\w*)', re.MULTILINE
)

# Show/scene with direct file path (rare, but supported when quoted):
#   scene "bg/room.png"
#   show expression "sprites/claire/happy.png"
SCENE_SHOW_PATH_RE = re.compile(
    r'^\s*(?:scene|show(?:\s+expression)?)\s+"(.*?)"\s*$', re.MULTILINE
)

# Layer E-Strong — Ren'Py UI constructors with literal media paths [GAP-D]
# These are unambiguous: the string is the *only* argument that names the asset file.
# Matched patterns (case-sensitive, as used by Ren'Py/Python):
#   Image("gui/textbox_d.png")
#   Frame("gui/frame_d.png", Borders(...))
#   Transform("mod_assets/buttons/dropdown/arrow.png", ...)
#   AlphaMask("fg.png", "mask.png")   — captures first arg only
# The name before '(' is anchored to avoid false matches on attributes like
# `renpy.display.Image(...)` — we strip the dot-prefix at the call site.
_MEDIA_EXTS_RE_FRAG = (
    r'\.(?:png|jpg|jpeg|webp|gif|bmp|tga|avif|ico'
    r'|ogg|mp3|wav|opus|flac'
    r'|mp4|webm|ogv|avi)'
)
KNOWN_CONSTRUCTOR_RE = re.compile(
    r'\b(?:Image|Frame|Transform|AlphaMask|Composite|Crop|Scale|Tile|Flatten)'
    r'\s*\(\s*"([^"<>\[\]\n]+' + _MEDIA_EXTS_RE_FRAG + r')"',
    re.IGNORECASE,
)

# Layer E-Soft — generic quoted media-extension literal anywhere else [GAP-B]
# Catches custom audio wrappers, Python variable assignments holding media paths:
#   mas_play_song("mod_assets/bgm/track.ogg", ...)
#   FP_TRACK = "mod_assets/bgm/song.ogg"
# These are *candidates* only — not promoted to hard refs — because the string
# may appear in a non-playback context (e.g. passed to a logging call, stored
# in a dict that is never iterated).  They go into `skipped` with
# kind="candidate_literal" so the unused-files report can optionally credit them.
# NOTE: strings containing < > [ ] are excluded (audio tags, dynamic interpolation).
# Comment-only lines are skipped at the call site.
GENERIC_MEDIA_LITERAL_RE = re.compile(
    r'"([^"<>\[\]\n]+' + _MEDIA_EXTS_RE_FRAG + r')"',
    re.IGNORECASE,
)

# Extension → media-kind mapping for Layer E
_EXT_KIND: Dict[str, str] = {
    '.png': 'img', '.jpg': 'img', '.jpeg': 'img', '.webp': 'img',
    '.gif': 'img', '.bmp': 'img', '.tga': 'img', '.avif': 'img', '.ico': 'img',
    '.ogg': 'snd', '.mp3': 'snd', '.wav': 'snd', '.opus': 'snd', '.flac': 'snd',
    '.mp4': 'vid', '.webm': 'vid', '.ogv': 'vid', '.avi': 'vid',
}

# Confidence scores per resolution_method (Hybrid Media Reference Resolver — spine).
# These are the *base* confidence values; project rules (.branchpy.json) can override.
# >0.84 → strong reference; 0.60–0.84 → candidate usage; 0.40–0.59 → dynamic risk;
# <0.40 → low-confidence note only.
_CONFIDENCE_MAP: Dict[str, Tuple[float, str]] = {
    # (score, human-readable reason)
    "regex":               (1.00, "Engine statement rule"),
    "audio_const":         (1.00, "Audio constant resolved via registry"),
    "auto_image":          (0.85, "Ren'Py auto-image naming convention"),
    "constructor_literal": (0.90, "Known UI constructor argument"),
    "candidate_literal":   (0.60, "Generic media literal in call/assignment"),
    "unresolved_placeholder": (0.50, "Symbolic name — no definition found"),
    "dynamic":             (0.35, "Dynamic/interpolated path"),
    "dynamic_audio":       (0.35, "Dynamic audio path"),
    "dynamic_image":       (0.35, "Dynamic image path"),
}

def _conf(resolution_method: str) -> Tuple[float, str]:
    """Return (confidence, reason) for a given resolution_method."""
    return _CONFIDENCE_MAP.get(resolution_method, (0.70, f"Resolved via {resolution_method}"))

# Anything that looks like a dynamic/format string we'll skip and report as unresolved
DYNAMIC_QUOTED_RE = re.compile(r'["\']\s*\{.*?\}\s*["\']')

# Ren'Py color displayables: #RGB, #RGBA, #RRGGBB, #RRGGBBAA — not file-backed assets.
# Matching these would produce false-positive missing refs (color Solids are not disk files).
_COLOR_LITERAL_RE = re.compile(r'^#[0-9a-fA-F]{3,8}$')

# Asset Catalog: layeredimage tag declarations
LAYEREDIMAGE_DEF_RE = re.compile(
    r'^\s*layeredimage\s+([A-Za-z0-9_][A-Za-z0-9_ ]*?)\s*:',
    re.MULTILINE,
)

# Asset Catalog: define identifier = Character(...) or DynamicCharacter(...)
DEFINE_CHARACTER_RE = re.compile(
    r'^\s*define\s+([A-Za-z0-9_]+)\s*=\s*(?:Character|DynamicCharacter)\s*\(',
    re.MULTILINE,
)

# Asset Catalog: scene-only placeholder (background detection signal)
SCENE_ONLY_PLACEHOLDER_RE = re.compile(
    r'^\s*scene\s+([A-Za-z0-9_]+(?: [A-Za-z0-9_]+)*)\s*(?:at|with|onlayer|as|zorder|$)',
    re.MULTILINE,
)

# Asset Catalog: Ren'Py built-in displayable/transition names that appear as
# path values in `image X = <displayable>` declarations.  These are not files.
_DISPLAYABLE_BINDING_RE = re.compile(
    r'^(imagedissolve|imagematrix|imagemorph|pushmatrix|alphadissolve|pixellate'
    r'|Transform|At|Composite|Frame|Fixed|HBox|VBox|Solid|Color|Image|ConditionSwitch'
    r'|LiveComposite|MovieSprite|DynamicDisplayable|Flatten|AlphaMask|Blur'
    r'|Crop|Scale|Movie|Tile|TextureGrid)\b',
    re.IGNORECASE,
)

# Auto-image: extensions that Ren'Py treats as image files (sprites, BGs, UI).
# Audio/video are NOT in this set — they should not enter the image catalog.
_IMAGE_EXTS_AUTO = frozenset({
    ".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".avif", ".tga",
})

# Sprite emotional/state words used in Ren'Py sprite variant names.
# A family with ≥2 auto variants where ≥1 attribute matches this set is likely a character.
_SPRITE_STATE_WORDS = frozenset({
    "happy", "sad", "angry", "surprised", "concerned", "neutral", "normal",
    "smile", "smiling", "cry", "crying", "worried", "mad", "vhappy", "unhappy",
    "excited", "scared", "confused", "thoughtful", "serious", "embarrassed",
    "laughing", "nervous", "shy", "tired", "upset", "shocked", "annoyed",
    "bored", "curious", "hopeful", "proud", "relieved", "hurt",
    # common sprite suffixes for time/costume/pose
    "night", "casual", "formal", "school", "standby",
})

# Media file extensions — used for type classification and symbolic-name detection.
_MEDIA_EXT_RE = re.compile(
    r'\.(png|jpg|jpeg|webp|gif|bmp|tga|avif|mp3|ogg|wav|opus|flac|mp4|webm|ogv|avi|ico)$',
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Project-rule config helpers (Hybrid Media Reference Resolver — Commit 2)
# ---------------------------------------------------------------------------

def _load_media_rules(project: str) -> List[Dict[str, Any]]:
    """Load media.rules from .branchpy.toml; return [] on any error."""
    try:
        from pathlib import Path as _Path
        from branchpy.config import load_config
        cfg = load_config(_Path(project))
        return cfg.get("media", {}).get("rules", []) or []
    except Exception:
        return []


def _apply_project_rules(
    items: List[Dict[str, Any]],
    rules: List[Dict[str, Any]],
    asset_root: str,
) -> None:
    """
    Mutate each item dict in-place, overlaying confidence/classification when
    a project rule pattern matches the item's value (normalised project-relative
    path).

    Supported classification values and their effect:
        "dynamic_used"  — sets rule_classification; confidence upgraded to rule value.
        "verified"      — same, treated as a confirmed reference.
        "ignored"       — marks item for exclusion from hard counts (callers filter on this).

    The original confidence is preserved in ``base_confidence`` for audit trails.
    Only the *first* matching rule is applied (rules are ordered by the user).
    """
    if not rules:
        return

    import fnmatch as _fnmatch

    for item in items:
        val = item.get("value", "")
        # Normalise to forward-slash relative path for matching
        norm_val = val.replace("\\", "/").lstrip("/")
        for rule in rules:
            pattern = rule.get("pattern", "")
            if not pattern:
                continue
            if _fnmatch.fnmatch(norm_val, pattern):
                # Preserve original confidence for audit
                if "base_confidence" not in item:
                    item["base_confidence"] = item.get("confidence")
                classification = rule.get("classification", "")
                override_conf = rule.get("confidence")
                reason = rule.get("reason", f"Project rule: {pattern}")
                if classification:
                    item["rule_classification"] = classification
                    item["rule_reason"] = reason
                if override_conf is not None:
                    item["confidence"] = float(override_conf)
                    item["confidence_reason"] = reason
                break  # first-match wins


def _looks_like_file_path(value: str) -> bool:
    """Return True when 'value' looks like a literal file path rather than a
    Ren'Py symbolic image name (e.g. 'menu_bg', 'black', 'confirm_glitch').

    A symbolic name: no recognised media extension, no directory separator.
    A literal path:  has a recognised media extension OR contains '/' or '\\'.
    """
    v = value.strip()
    if not v:
        return False
    if "/" in v or "\\" in v:
        return True
    return bool(_MEDIA_EXT_RE.search(v))


def _detect_binding_type(path_str: str) -> str:
    """Return 'color' | 'displayable' | 'alias' | 'file' for an image declaration's value."""
    p = path_str.strip()
    if not p:
        return "alias"
    if _COLOR_LITERAL_RE.match(p):
        return "color"
    if _DISPLAYABLE_BINDING_RE.match(p):
        return "displayable"
    # No dot-extension → likely an alias (references another image tag)
    if not _MEDIA_EXT_RE.search(p):
        return "alias"
    return "file"


# ---- Helpers ----------------------------------------------------------------


def _build_scan_wrappers(user_wrappers: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """
    Return an isolated PFI wrapper registry for this scan.

    Never touches or mutates the global PFI_WRAPPERS. Values are copied
    individually so that future additions of nested metadata keys remain safe.

    Args:
        user_wrappers: List of wrapper dicts from config media.pfi.wrappers.
                       Each entry must have "name" (str), "kind" (str), and
                       optionally "arg_index" (int, default 0).

    Returns:
        A fresh dict suitable for passing to analyze_files_for_pfi().

    Governance:
        MEDIA-PHASE-B-WP-B1
    """
    registry: Dict[str, Dict[str, Any]] = {k: v.copy() for k, v in PFI_WRAPPERS.items()}

    for entry in user_wrappers:
        name = entry.get("name")
        kind = entry.get("kind")
        arg_index = entry.get("arg_index", 0)
        if name and kind in ("image", "audio", "video"):
            registry[str(name)] = {"kind": str(kind), "arg_index": int(arg_index)}

    return registry


def _read_text(path: str) -> str:
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except UnicodeDecodeError:
        with open(path, encoding="latin-1") as f:
            return f.read()


def _norm(p: str) -> str:
    # normalize slashes and collapse .. segments; keep case as-is (Ren'Py is case-sensitive on Linux)
    return os.path.normpath(p.replace("\\", "/")).replace("\\", "/")


def _strip_audio_tag(s: str) -> str:
    """Strip leading Ren'Py audio-tag modifiers from an audio path string.

    Ren'Py allows: define audio.t1 = "<loop 22.073>bgm/1.ogg"
    The engine strips everything up to and including the closing '>'.
    We do the same so the downstream path lookup gets 'bgm/1.ogg'.
    """
    s = s.strip()
    if s.startswith("<"):
        end = s.find(">")
        if end != -1:
            s = s[end + 1:].strip()
    return s


def _categorize_media(path: str) -> str:
    """
    Infer media category from file path and name using Ren'Py conventions.
    Returns: 'character', 'background', 'ui', 'effect', 'music', 'sfx', 'voice', 'video', 'other'
    """
    path_lower = path.lower().replace("\\", "/")
    name = os.path.basename(path_lower)

    # Check path segments for common folder patterns
    if any(x in path_lower for x in ["/character", "/sprite", "/chr", "/npc"]):
        return "character"
    if any(x in path_lower for x in ["/background", "/bg", "/scene"]):
        return "background"
    if any(x in path_lower for x in ["/ui", "/gui", "/button", "/icon", "/menu"]):
        return "ui"
    if any(x in path_lower for x in ["/effect", "/fx", "/particle", "/overlay"]):
        return "effect"
    if any(x in path_lower for x in ["/music", "/bgm", "/ost"]):
        return "music"
    if any(x in path_lower for x in ["/sound", "/sfx", "/audio/s"]):
        return "sfx"
    if any(x in path_lower for x in ["/voice", "/vo", "/dialogue"]):
        return "voice"
    if any(x in path_lower for x in ["/video", "/movie", "/cutscene", "/movies"]):
        return "video"

    # Check file extension for audio files without clear path
    ext = os.path.splitext(name)[1].lower()
    if ext in [".ogg", ".mp3", ".wav", ".opus"]:
        # Try to infer from filename
        if any(x in name for x in ["music", "bgm", "theme", "ost"]):
            return "music"
        if any(x in name for x in ["voice", "vo_", "dlg_"]):
            return "voice"
        return "sfx"  # Default for audio

    if ext in [".mp4", ".webm", ".ogv", ".avi", ".mov", ".mkv"]:
        return "video"

    # Check for image types by name patterns
    if ext in [".png", ".jpg", ".jpeg", ".webp"]:
        # Common character name patterns (ends with emotion/pose)
        if any(
            x in name
            for x in [
                "_happy",
                "_sad",
                "_angry",
                "_neutral",
                "_smile",
                "_blush",
                "_surprised",
                "_worried",
                "_vhappy",
                "_concerned",
            ]
        ):
            return "character"
        # Background indicators
        if any(
            x in name
            for x in ["bg_", "background_", "_day", "_night", "_evening", "_morning"]
        ):
            return "background"
        # UI elements
        if any(
            x in name
            for x in ["button", "icon", "cursor", "frame", "box", "bar_", "gui_"]
        ):
            return "ui"

    return "other"


def _suggest_categories(media_files: List[str]) -> List[Dict]:
    """
    Auto-suggest custom categories by analyzing filename patterns.
    Returns list of suggested categories with regex patterns.

    Examples:
      - eileen_happy.png, eileen_sad.png → Category: "Eileen" with pattern: ^eileen_
      - bg_kitchen.jpg, bg_bedroom.jpg → Category: "Backgrounds" with pattern: ^bg_
    """
    import re
    from collections import defaultdict

    # Group files by common prefixes (character names, etc.)
    prefix_groups = defaultdict(list)

    for path in media_files:
        filename = os.path.basename(path).lower()
        name_without_ext = os.path.splitext(filename)[0]

        # Look for common patterns: name_emotion, name_pose, etc.
        parts = re.split(r"[_\-\s]", name_without_ext)
        if len(parts) >= 2:
            # First part is likely the character/object name
            prefix = parts[0]
            if (
                len(prefix) >= 3 and prefix.isalpha()
            ):  # Valid name (at least 3 letters, all alphabetic)
                prefix_groups[prefix].append(filename)

    # Generate suggestions for groups with 3+ files
    suggestions = []
    for prefix, files in prefix_groups.items():
        if len(files) >= 3:  # Only suggest if we have at least 3 files with this prefix
            category_name = prefix.capitalize()
            regex_pattern = f"^{prefix}_"

            suggestions.append(
                {
                    "name": category_name,
                    "icon": "👤",  # Default to character icon
                    "regex": regex_pattern,
                    "folder": "",
                    "sample_files": files[:5],  # Include sample files for preview
                    "match_count": len(files),
                }
            )

    # Sort by match count (most common first)
    suggestions.sort(key=lambda x: x["match_count"], reverse=True)

    return suggestions


def _rel_norm(base: str, full: str) -> str:
    try:
        rel = os.path.relpath(full, base)
    except ValueError:
        rel = full
    return _norm(rel)


# ---- Scan script refs --------------------------------------------------------
def _is_ignored(base: str, path: str, patterns: Optional[list[str]]) -> bool:
    """Return True if path (relative to base) matches any ignore glob."""
    if not patterns:
        return False
    rel = os.path.relpath(path, base)
    return any(fnmatch.fnmatch(rel.replace("\\", "/"), pat) for pat in patterns)


def _line_of(text: str, idx: int) -> int:
    # 1-based line number (handles \r\n and \n by counting \n)
    return text.count("\n", 0, idx) + 1


def _collect_refs_in_text(
    text: str,
    file_path: str,
    placeholder_registry: Dict[str, str],
    audio_registry: Optional[Dict[str, str]] = None,
) -> Tuple[List[Dict], List[Dict]]:
    refs = []
    skipped = []

    # Collect all image placeholder definitions in THIS file (already in global registry)
    for m in IMAGE_PLACEHOLDER_DEF_RE.finditer(text):
        file_path_str = m.group(2)
        line = _line_of(text, m.start(2))

        if DYNAMIC_QUOTED_RE.search(file_path_str):
            skipped.append(
                {
                    "kind": "dynamic",
                    "file": file_path,
                    "value": file_path_str,
                    "line": line,
                }
            )
            continue

        # Skip Ren'Py color displayables — not file-backed assets
        if _COLOR_LITERAL_RE.match(file_path_str.strip()):
            continue

        # Add to refs (file itself is referenced by the definition)
        _c, _r = _conf("regex")
        refs.append(
            {
                "kind": "img",
                "file": file_path,
                "value": _norm(file_path_str),
                "line": line,
                "resolution_method": "regex",
                "confidence": _c,
                "confidence_reason": _r,
            }
        )

    def add(kind: str, m: re.Match):
        raw = m.group(1)
        line = _line_of(text, m.start(1))
        if _COLOR_LITERAL_RE.match(raw.strip()):
            return  # Ren'Py color displayable — not a file-backed asset
        if DYNAMIC_QUOTED_RE.search(raw):
            _dc, _dr = _conf("dynamic")
            skipped.append(
                {"kind": "dynamic", "file": file_path, "value": raw, "line": line,
                 "confidence": _dc, "confidence_reason": _dr}
            )
            return
        _c, _r = _conf("regex")
        refs.append(
            {
                "kind": kind,
                "file": file_path,
                "value": _norm(raw),
                "line": line,
                "resolution_method": "regex",
                "confidence": _c,
                "confidence_reason": _r,
            }
        )

    # Ren'Py statement modifier keywords that follow the image tag in show/scene.
    # The greedy regex may capture these into the group (e.g. "lucy mad at right"
    # when the lookahead on "at" does not force backtracking).  Strip them off
    # before using the captured name as a lookup key.
    _SHOW_MODIFIERS = frozenset({"at", "with", "behind", "onlayer", "as", "zorder"})

    # Resolve show/scene placeholder references
    for m in SHOW_SCENE_PLACEHOLDER_RE.finditer(text):
        placeholder_name = m.group(1).strip().lower()
        # Strip trailing modifier words (e.g. "lucy mad at right" → "lucy mad")
        parts = placeholder_name.split()
        clean_parts = []
        for part in parts:
            if part in _SHOW_MODIFIERS:
                break
            clean_parts.append(part)
        placeholder_name = " ".join(clean_parts) if clean_parts else placeholder_name
        line = _line_of(text, m.start(1))

        # Try to resolve placeholder to actual file
        if placeholder_name in placeholder_registry:
            resolved_path = placeholder_registry[placeholder_name]
            # Skip color displayables that resolved from declarations like
            # `image bg blue = "#0000cc"` — the resolved path is a hex color, not a file.
            if _COLOR_LITERAL_RE.match(resolved_path.strip()):
                continue
            # Skip composite/animation definitions (image NAME: ...) — these are
            # named displayables with no single backing file path.
            if resolved_path == "__composite__":
                continue
            _c, _r = _conf("regex")
            refs.append(
                {
                    "kind": "img",
                    "file": file_path,
                    "value": resolved_path,
                    "line": line,
                    "resolution_method": "regex",
                    "confidence": _c,
                    "confidence_reason": _r,
                }
            )
        else:
            # Placeholder not defined in any `image X = ...` declaration.
            # This is the Ren'Py auto-image case: a file like `eileen happy.png`
            # in the images/ directory is automatically registered by the engine.
            # Add a ref so the fuzzy key lookup in run_unused/run_referenced can
            # match `images/eileen happy.png` via the shared stem key `eileen happy`.
            guessed_path = placeholder_name.replace(" ", "_")
            _uc, _ur = _conf("unresolved_placeholder")
            skipped.append(
                {
                    "kind": "unresolved_placeholder",
                    "file": file_path,
                    "value": placeholder_name,
                    "guessed": guessed_path,
                    "line": line,
                    "confidence": _uc,
                    "confidence_reason": _ur,
                }
            )
            # Also add as a synthetic ref so the asset participates in
            # referenced/unused accounting.  The logical name (e.g. "eileen happy")
            # is a key that _asset_lookup_keys expands for the matching disk file.
            _ac, _ar = _conf("auto_image")
            refs.append(
                {
                    "kind": "img",
                    "file": file_path,
                    "value": placeholder_name,
                    "line": line,
                    "resolution_method": "auto_image",
                    "confidence": _ac,
                    "confidence_reason": _ar,
                }
            )

    # ------------------------------------------------------------------ #
    # Layer A — direct quoted audio / video references                    #
    # ------------------------------------------------------------------ #
    for m in PLAY_RE.finditer(text):
        add("snd", m)
    for m in QUEUE_RE.finditer(text):          # queue <channel> "path"
        add("snd", m)
    for m in VOICE_RE.finditer(text):
        add("snd", m)
    for m in MOVIE_RE.finditer(text):
        add("vid", m)
    for m in MOVIE_CUTSCENE_RE.finditer(text):
        add("vid", m)

    # Layer B — define audio.X = "path"  (quoted, possibly with <tag>)
    _aregistry = audio_registry or {}
    for m in DEFINE_AUDIO_RE.finditer(text):
        raw = _strip_audio_tag(m.group(2))
        if not raw or _COLOR_LITERAL_RE.match(raw):
            continue
        if DYNAMIC_QUOTED_RE.search(raw):
            _dc, _dr = _conf("dynamic")
            skipped.append({"kind": "dynamic", "file": file_path, "value": raw,
                            "line": _line_of(text, m.start(2)),
                            "confidence": _dc, "confidence_reason": _dr})
            continue
        _c, _r = _conf("regex")
        refs.append({"kind": "snd", "file": file_path, "value": _norm(raw),
                     "line": _line_of(text, m.start(2)), "resolution_method": "regex",
                     "confidence": _c, "confidence_reason": _r})

    # Layer B — define gui.X / define config.X = "path"
    for m in DEFINE_GUI_RE.finditer(text):
        add("img", m)

    # Layer B — audio constant indirection: play music audio.theme
    for m in PLAY_AUDIO_CONST_RE.finditer(text):
        const_key = m.group(1)          # e.g. "audio.theme"
        resolved = _aregistry.get(const_key)
        if resolved:
            _c, _r = _conf("audio_const")
            refs.append({"kind": "snd", "file": file_path, "value": resolved,
                         "line": _line_of(text, m.start(1)), "resolution_method": "audio_const",
                         "confidence": _c, "confidence_reason": _r})
        # (if not in registry: likely a variable, handled by PLAY_DYNAMIC_RE below)

    # Layer C — screen/UI literal paths
    for m in SCREEN_ADD_RE.finditer(text):
        add("img", m)
    for m in SCREEN_BG_STR_RE.finditer(text):
        add("img", m)
    for m in IMAGEBUTTON_RE.finditer(text):
        # idle group=1, hover group=2
        for g in (1, 2):
            val = m.group(g)
            if val:
                line = _line_of(text, m.start(g))
                if not _COLOR_LITERAL_RE.match(val.strip()) and not DYNAMIC_QUOTED_RE.search(val):
                    _c, _r = _conf("regex")
                    refs.append({"kind": "img", "file": file_path, "value": _norm(val),
                                 "line": line, "resolution_method": "regex",
                                 "confidence": _c, "confidence_reason": _r})

    # Layer D — dynamic-risk signals (do NOT add to refs; add to skipped)
    _seen_dyn: Set[str] = set()
    for m in PLAY_DYNAMIC_RE.finditer(text):
        val = m.group(1)
        # Exclude audio.X constants (already handled above) and quoted-string false-positives
        if val.startswith("audio.") or val.startswith('"') or val.startswith("'"):
            continue
        key = ("play_dynamic", val)
        if key not in _seen_dyn:
            _seen_dyn.add(key)
            _dc, _dr = _conf("dynamic_audio")
            skipped.append({"kind": "dynamic_audio", "file": file_path, "value": val,
                            "line": _line_of(text, m.start(1)),
                            "confidence": _dc, "confidence_reason": _dr})
    for m in SHOW_EXPRESSION_DYN_RE.finditer(text):
        val = m.group(1)
        key = ("show_expr", val)
        if key not in _seen_dyn:
            _seen_dyn.add(key)
            _dc, _dr = _conf("dynamic_image")
            skipped.append({"kind": "dynamic_image", "file": file_path, "value": val,
                            "line": _line_of(text, m.start(1)),
                            "confidence": _dc, "confidence_reason": _dr})
    for m in RENPY_MUSIC_PLAY_DYN_RE.finditer(text):
        val = m.group(1)
        key = ("renpy_music", val)
        if key not in _seen_dyn:
            _seen_dyn.add(key)
            _dc, _dr = _conf("dynamic_audio")
            skipped.append({"kind": "dynamic_audio", "file": file_path, "value": val,
                            "line": _line_of(text, m.start(1)),
                            "confidence": _dc, "confidence_reason": _dr})

    # Collect direct quoted image paths
    for m in SCENE_SHOW_PATH_RE.finditer(text):
        add("img", m)

    # ------------------------------------------------------------------ #
    # Layer E-Strong — known Ren'Py UI constructors [GAP-D]              #
    # Image("p"), Frame("p"), Transform("p"), etc. → hard refs            #
    # These are unambiguous: the literal is the primary asset argument.   #
    # ------------------------------------------------------------------ #
    _seen_e_strong: Set[str] = set()
    for m in KNOWN_CONSTRUCTOR_RE.finditer(text):
        raw = m.group(1)
        line_start = text.rfind('\n', 0, m.start()) + 1
        if text[line_start:m.start()].lstrip()[:1] == '#':
            continue
        if DYNAMIC_QUOTED_RE.search(raw) or _COLOR_LITERAL_RE.match(raw.strip()):
            continue
        val = _norm(raw)
        if val in _seen_e_strong:
            continue
        _seen_e_strong.add(val)
        ext = os.path.splitext(val)[1].lower()
        kind = _EXT_KIND.get(ext, 'img')
        _c, _r = _conf('constructor_literal')
        refs.append({
            'kind': kind,
            'file': file_path,
            'value': val,
            'line': _line_of(text, m.start(1)),
            'resolution_method': 'constructor_literal',
            'confidence': _c,
            'confidence_reason': _r,
        })

    # ------------------------------------------------------------------ #
    # Layer E-Soft — generic media-extension candidate literals [GAP-B]  #
    # Custom wrappers, variable assignments → skipped as candidates.     #
    # NOT promoted to hard refs — avoids false "missing" inflation.      #
    # Unused-files accounting credits these via candidate_literal check. #
    # ------------------------------------------------------------------ #
    _seen_e_soft: Set[str] = set()
    for m in GENERIC_MEDIA_LITERAL_RE.finditer(text):
        raw = m.group(1)
        line_start = text.rfind('\n', 0, m.start()) + 1
        if text[line_start:m.start()].lstrip()[:1] == '#':
            continue
        if DYNAMIC_QUOTED_RE.search(raw) or _COLOR_LITERAL_RE.match(raw.strip()):
            continue
        val = _norm(raw)
        # Already captured as a hard ref by an earlier layer or E-Strong
        if val in _seen_e_strong:
            continue
        if val in _seen_e_soft:
            continue
        _seen_e_soft.add(val)
        ext = os.path.splitext(val)[1].lower()
        kind = _EXT_KIND.get(ext, 'img')
        _cc, _cr = _conf('candidate_literal')
        skipped.append({
            'kind': 'candidate_literal',
            'media_kind': kind,
            'file': file_path,
            'value': val,
            'line': _line_of(text, m.start(1)),
            'confidence': _cc,
            'confidence_reason': _cr,
        })

    return refs, skipped


# ---- PFI helpers (WP-B2 / WP-B3) -------------------------------------------


_PFI_KIND_TO_SCAN_KIND: Dict[str, str] = {
    "image": "img",
    "audio": "snd",
    "video": "vid",
}

_PFI_EXTENSIONS: Dict[str, List[str]] = {
    "image": [".png", ".jpg", ".webp", ".jpeg"],
    "audio": [".ogg", ".mp3", ".wav"],
    "video": [".mp4", ".webm", ".ogv"],
}

_PFI_PREFIXES: Dict[str, List[str]] = {
    "image": ["images/", "game/images/"],
    "audio": ["audio/", "game/audio/", "music/", "sounds/"],
    "video": ["video/", "game/video/", "movies/"],
}


def _normalize_pfi_media_id(media_id: str, media_kind: str) -> str:  # noqa: ARG001
    """
    Normalize a raw PFI-emitted media ID to a consistent form.

    Purely syntactic — no filesystem access, no placeholder lookup.
    Forward-slashes only, stripped of surrounding whitespace.

    Returns:
        Normalized media_id string (e.g. "sprites/ch01", "bg_cafe").

    Governance: MEDIA-PHASE-B-WP-B3
    """
    return media_id.strip().replace("\\", "/")


def _resolve_pfi_to_path(
    normalized_id: str,
    media_kind: str,
    placeholder_registry: Dict[str, str],
    asset_root: str,
) -> Tuple[Optional[str], str]:
    """
    Resolve a normalized PFI media ID to a project-relative asset path.

    Resolution ladder (first match wins):
      1. placeholder registry lookup
      2. exact asset existence check
      3. extension probe (try common extensions)
      4. prefix + extension probe (try common sub-folders)
      5. unresolved

    Args:
        normalized_id: Output of _normalize_pfi_media_id().
        media_kind: "image" | "audio" | "video".
        placeholder_registry: Image-definition map from Pass 1.
        asset_root: The asset root directory (same as passed to _exists_under_assets).

    Returns:
        (resolved_path, resolution_method)

        resolved_path:
            A normalized project-relative path using forward slashes, no leading
            slash (e.g. "images/bg_cafe.png", "audio/vo_12.ogg"). Produced via
            _norm() — identical convention to all refs in refs_all, so
            (resolved_path, media_kind) is a stable dedup key.
            None when resolution_method is "unresolved".

        resolution_method:
            One of "placeholder" | "exact" | "extension_probe" |
            "prefix_probe" | "unresolved".

    Governance: MEDIA-PHASE-B-WP-B3
    """
    # 1. Placeholder registry
    lower_id = normalized_id.lower()
    if lower_id in placeholder_registry:
        return _norm(placeholder_registry[lower_id]), "placeholder"

    # 2. Exact existence check
    if _exists_under_assets(asset_root, normalized_id):
        return _norm(normalized_id), "exact"

    # 3. Extension probe
    for ext in _PFI_EXTENSIONS.get(media_kind, []):
        candidate = normalized_id + ext
        if _exists_under_assets(asset_root, candidate):
            return _norm(candidate), "extension_probe"

    # 4. Prefix + extension probe
    for prefix in _PFI_PREFIXES.get(media_kind, []):
        for ext in _PFI_EXTENSIONS.get(media_kind, []):
            candidate = prefix + normalized_id + ext
            if _exists_under_assets(asset_root, candidate):
                return _norm(candidate), "prefix_probe"

    return None, "unresolved"


def _scan_project_for_media(
    project_root: str,
    ignore: Optional[list[str]] = None,
    asset_root: Optional[str] = None,
    pfi_config: Optional[Dict[str, Any]] = None,
) -> Tuple[List[Dict], List[Dict], List[Dict]]:
    """
    Scan a Ren'Py project for all media references.

    Returns a 3-tuple:
        (refs_all, skipped_all, pfi_candidates_all)

        refs_all:           Resolved refs (confidence >= 0.8).
        skipped_all:        Unresolvable / dynamic / low-confidence refs.
        pfi_candidates_all: PFI refs with 0.5 <= confidence < 0.8 (diagnostics only;
                            excluded from missing/unused counts and exit code).

    Call-site contract:
        All 6 call sites must unpack all 3 values. Use _ for unused buckets.

    Governance: MEDIA-PHASE-B-WP-B2
    """
    refs_all: List[Dict] = []
    skipped_all: List[Dict] = []
    pfi_candidates_all: List[Dict] = []
    placeholder_registry: Dict[str, str] = {}
    audio_registry: Dict[str, str] = {}  # "audio.theme" → normalized path

    # Pass 1: Collect all .rpy files and build placeholder registry
    rpy_files: List[str] = []
    for r, dirs, files in os.walk(project_root):
        if ignore:
            dirs[:] = [
                d
                for d in dirs
                if not _is_ignored(project_root, os.path.join(r, d), ignore)
            ]
        for fn in files:
            full = os.path.join(r, fn)
            if not fn.endswith(".rpy"):
                continue
            if ignore and _is_ignored(project_root, full, ignore):
                continue
            rpy_files.append(full)

    # Pass 1 (cont): Build placeholder registry from image definitions
    for full in rpy_files:
        text = _read_text(full)
        for m in IMAGE_PLACEHOLDER_DEF_RE.finditer(text):
            placeholder_name = m.group(1).strip().lower()
            file_path_str = m.group(2)
            if DYNAMIC_QUOTED_RE.search(file_path_str):
                continue
            placeholder_registry[placeholder_name] = _norm(file_path_str)
        # Register colon-form composite/animation definitions (image NAME:)
        # No file path — sentinel value marks the name as defined so it is never
        # reported as a missing symbolic reference.
        for m in IMAGE_COMPOSITE_DEF_RE.finditer(text):
            composite_name = m.group(1).strip().lower()
            if composite_name not in placeholder_registry:
                placeholder_registry[composite_name] = "__composite__"
        # Build audio constant registry: "audio.theme" → cleaned file path
        for m in DEFINE_AUDIO_RE.finditer(text):
            const_name = "audio." + m.group(1)
            raw_path = _strip_audio_tag(m.group(2))
            if raw_path and not DYNAMIC_QUOTED_RE.search(raw_path):
                audio_registry[const_name] = _norm(raw_path)

    # Pass 2: Regex-based Ren'Py statement scanning
    for full in rpy_files:
        text = _read_text(full)
        refs, skipped = _collect_refs_in_text(text, full, placeholder_registry, audio_registry)
        refs_all.extend(refs)
        skipped_all.extend(skipped)

    # Pass 3: PFI wrapper inference (Phase B)
    _pfi_cfg = pfi_config or {}
    pfi_enabled = _pfi_cfg.get("enabled", True)

    if pfi_enabled:
        try:
            from pathlib import Path as _Path

            if analyze_files_for_pfi is None:
                raise ImportError("analyze_files_for_pfi not available")

            scan_wrappers = _build_scan_wrappers(_pfi_cfg.get("wrappers", []))
            pfi_results = analyze_files_for_pfi(
                [_Path(f) for f in rpy_files],
                wrappers=scan_wrappers,
            )

            # Resolve path and confidence-bucket each PFI reference
            _eff_asset_root = asset_root or project_root

            # Build dedup set from regex pass: (resolved_path, scan_kind)
            dedup_set: Set[Tuple[str, str]] = {
                (r["value"], r["kind"]) for r in refs_all
            }

            pfi_wrappers_triggered: Set[str] = set()
            pfi_refs_found = 0
            pfi_refs_resolved = 0
            pfi_refs_skipped = 0

            for pfi_result in pfi_results:
                for ref in pfi_result.references:
                    pfi_refs_found += 1
                    if ref.wrapper_name:
                        pfi_wrappers_triggered.add(ref.wrapper_name)

                    # Normalize
                    normalized_id = _normalize_pfi_media_id(ref.media_id, ref.media_kind)

                    # Confidence routing
                    if ref.confidence < 0.5:
                        continue  # silently dropped

                    scan_kind = _PFI_KIND_TO_SCAN_KIND.get(ref.media_kind, "img")

                    if ref.confidence < 0.8:
                        # Low-confidence → pfi_candidates bucket
                        pfi_candidates_all.append(
                            {
                                "kind": scan_kind,
                                "file": str(ref.file_path),
                                "value": normalized_id,
                                "line": ref.line_number,
                                "wrapper_name": ref.wrapper_name,
                                "media_kind": ref.media_kind,
                                "confidence": ref.confidence,
                                "source": ref.source,
                                "resolution_method": "pfi_candidate",
                            }
                        )
                        continue

                    # Resolve to project-relative path
                    resolved_path, resolution_method = _resolve_pfi_to_path(
                        normalized_id,
                        ref.media_kind,
                        placeholder_registry,
                        _eff_asset_root,
                    )

                    if resolution_method == "unresolved":
                        pfi_refs_skipped += 1
                        skipped_all.append(
                            {
                                "kind": "pfi_unresolved",
                                "file": str(ref.file_path),
                                "value": normalized_id,
                                "line": ref.line_number,
                                "wrapper_name": ref.wrapper_name,
                                "media_kind": ref.media_kind,
                            }
                        )
                        continue

                    # Dedup against regex pass
                    dedup_key = (resolved_path, scan_kind)
                    if dedup_key in dedup_set:
                        continue
                    dedup_set.add(dedup_key)

                    pfi_refs_resolved += 1
                    _pfi_c, _pfi_r = _conf(resolution_method)
                    refs_all.append(
                        {
                            "kind": scan_kind,
                            "file": str(ref.file_path),
                            "value": resolved_path,
                            "line": ref.line_number,
                            "resolution_method": resolution_method,
                            "wrapper_name": ref.wrapper_name,
                            "source": ref.source,
                            "confidence": ref.confidence,
                            "confidence_reason": _pfi_r,
                        }
                    )

            # Emit telemetry for the PFI pass
            try:
                from branchpy.telemetry import LocalTelemetryWriter, TelemetryEvent, create_trace_id
                from pathlib import Path as _TelPath
                _tw = LocalTelemetryWriter(_TelPath.home() / ".branchpy" / "telemetry")
                _tw.write_event(TelemetryEvent(
                    ts=_tw.iso_now(),
                    session_id=_tw.session_id,
                    trace_id=create_trace_id(),
                    category="media",
                    name="media.pfi_scan",
                    attrs={
                        "pfi_refs_found": pfi_refs_found,
                        "pfi_refs_resolved": pfi_refs_resolved,
                        "pfi_refs_skipped": pfi_refs_skipped,
                        "wrappers_triggered": sorted(pfi_wrappers_triggered),
                        "custom_wrappers_count": len(_pfi_cfg.get("wrappers", [])),
                    },
                ))
            except Exception:
                pass  # telemetry is always non-fatal

        except Exception as _pfi_err:
            log.warning("[media] PFI pass failed, continuing with regex-only results: %s", _pfi_err)

    return refs_all, skipped_all, pfi_candidates_all


def _exists_under_assets(asset_root: str, rel_path: str) -> bool:
    # Most scripts reference paths relative to the game/ folder.
    # If rel_path is absolute, just check it; otherwise join to asset_root.
    candidate = (
        rel_path if os.path.isabs(rel_path) else os.path.join(asset_root, rel_path)
    )
    return os.path.exists(candidate)


_FUZZY_EXTENSIONS = [
    ".png", ".jpg", ".webp", ".jpeg",
    ".ogg", ".mp3", ".wav", ".opus",
    ".mp4", ".webm", ".ogv",
]
_FUZZY_PREFIXES = [
    "images/", "audio/", "music/", "sound/",
    "voice/", "video/", "movies/",
]


def _exists_fuzzy(asset_root: str, value: str) -> bool:
    """
    Extended existence check: tries common file-extension probes and Ren'Py
    implicit asset-search prefixes before declaring a reference missing.

    Resolves cases like:
      "imagedissolve circleiris"  →  "images/imagedissolve circleiris.png"
      "logo base.png"             →  "images/logo base.png"
      "logo base"                 →  "images/logo base.png"
    """
    if _exists_under_assets(asset_root, value):
        return True
    _, ext = os.path.splitext(value)
    # Extension probe for bare logical names (no extension)
    if not ext:
        for probe_ext in _FUZZY_EXTENSIONS:
            if _exists_under_assets(asset_root, value + probe_ext):
                return True
    # Prefix probes
    for prefix in _FUZZY_PREFIXES:
        if value.startswith(prefix):
            continue  # already has this prefix, direct check already failed
        if _exists_under_assets(asset_root, prefix + value):
            return True
        if not ext:
            for probe_ext in _FUZZY_EXTENSIONS:
                if _exists_under_assets(asset_root, prefix + value + probe_ext):
                    return True
    return False


# ---- Missing -----------------------------------------------------------------


def run_missing(
    project: str,
    assets_root: str,
    as_json: bool = False,
    ignore: Optional[list[str]] = None,
    emit: bool = True,
    export_csv: Optional[str] = None,
    bqf_media: bool = False,
    policy_mode: str = "off",
    policy_config: Optional[str] = None,
) -> int:
    """
    Scan project for missing media files.

    v0.7.29: Added CSV export support for missing images.
    WS-B1: Added BQF policy enforcement with exit codes.

    Returns:
        0: Success
        65: BQF policy violation
        66: BQF remote error
        67: BQF partial analysis
    """
    start_time = time.time()
    _pfi_cfg: Dict[str, Any] = {}
    _media_rules: List[Dict[str, Any]] = []
    try:
        from pathlib import Path as _Path
        from branchpy.config import load_config
        _cfg = load_config(_Path(project))
        _pfi_cfg = _cfg.get("media", {}).get("pfi", {})
        _media_rules = _cfg.get("media", {}).get("rules", []) or []
    except Exception:
        pass
    refs, skipped, pfi_candidates = _scan_project_for_media(
        project, ignore=ignore, asset_root=assets_root, pfi_config=_pfi_cfg
    )
    # Apply project-rule overrides (confidence, classification) before routing.
    _apply_project_rules(refs, _media_rules, assets_root)
    _apply_project_rules(skipped, _media_rules, assets_root)
    _apply_project_rules(pfi_candidates, _media_rules, assets_root)
    missing = [
        r for r in refs
        # Auto-image refs are "soft" — they are synthetic refs for unresolved show/scene
        # placeholders that may correspond to Ren'Py auto-image files (e.g. eileen happy.png).
        # If the file exists on disk they correctly participate in referenced/unused counting.
        # If no file exists they are unresolved symbolic names, NOT missing-file violations.
        if r.get("resolution_method") != "auto_image"
        and r.get("rule_classification") not in ("ignored", "dynamic_used", "verified")
        and not _exists_fuzzy(assets_root, r["value"])
    ]
    ok_count = len(refs) - len(missing)

    # Split missing into literal file paths vs Ren'Py symbolic image/displayable names.
    # Symbolic names (e.g. "menu_bg", "black", "game_menu_bg") are image tags or
    # displayable identifiers — they should not be treated as missing files on disk.
    missing_files = [r for r in missing if _looks_like_file_path(r["value"])]
    missing_symbolic = [r for r in missing if not _looks_like_file_path(r["value"])]

    # Mark each item with its sub-type for downstream consumers
    for item in missing_files:
        item["ref_type"] = "file_path"
    for item in missing_symbolic:
        item["ref_type"] = "symbolic_name"

    # Detect Ren'Py archives (.rpa) — if present, some "missing" file refs may
    # actually exist inside archives and cannot be verified as loose files.
    rpa_files = []
    for _r, _dirs, _fns in os.walk(project):
        for _fn in _fns:
            if _fn.lower().endswith(".rpa"):
                rpa_files.append(os.path.join(_r, _fn))
    rpa_detected = len(rpa_files) > 0

    # Add categories to missing items
    for item in missing:
        item["category"] = _categorize_media(item["value"])

    duration_ms = int((time.time() - start_time) * 1000)

    # v0.7.29: Export to CSV if requested
    if export_csv:
        import csv
        from pathlib import Path

        csv_path = Path(export_csv)
        csv_path.parent.mkdir(parents=True, exist_ok=True)

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["path", "label", "referenced_by", "resolution_method"])

            for m in missing:
                # Extract label from file path (last component before extension)
                label = Path(m["value"]).stem
                ref_location = f"{m['file']}:{m.get('line', '?')}"
                writer.writerow([m["value"], label, ref_location, m.get("resolution_method", "")])

            # Append PFI candidates section
            if pfi_candidates:
                writer.writerow([])
                writer.writerow(["# pfi_candidates"])
                writer.writerow(["value", "wrapper", "confidence", "source_file", "line"])
                for c in pfi_candidates:
                    writer.writerow([
                        c.get("value", ""),
                        c.get("wrapper_name", ""),
                        c.get("confidence", ""),
                        c.get("file", ""),
                        c.get("line", ""),
                    ])

        safe_print(f"Exported {len(missing)} missing file(s) to {csv_path}")
        return 0

    if as_json:
        payload = {
            "mode": "missing",
            "summary": {
                "issues": len(missing_files),           # literal file paths not on disk
                "symbolic_unresolved": len(missing_symbolic),  # Ren'Py image/displayable names
                "declared_refs": len(refs),             # total refs detected in scripts
                "ok": ok_count,
            },
            "rpa_detected": rpa_detected,               # True if .rpa archives present
            "rpa_files": [os.path.basename(p) for p in rpa_files],
            "issues": missing_files,                    # literal file path misses only
            "issues_symbolic": missing_symbolic,        # symbolic name refs (image tags, etc.)
            "issues_all": missing,                      # full combined list (legacy compat)
            "skipped": skipped,
            "pfi_candidates": pfi_candidates,
        }
        from json import dumps as _dumps

        safe_print(_dumps(payload, indent=2, ensure_ascii=False))
    else:
        safe_print(f"Missing media ({len(missing)})")
        if len(missing) == 0:
            safe_print("  ✓ All media files found (no issues)")
        else:
            for m in missing:
                tag = "img" if m["kind"] == "img" else "snd"
                res = m.get("resolution_method", "regex")
                pfi_badge = (
                    "  [pfi:exact]"       if res == "exact" else
                    "  [pfi:ext]"         if res == "extension_probe" else
                    "  [pfi:prefix]"      if res == "prefix_probe" else
                    "  [pfi:placeholder]" if res == "placeholder" else
                    ""
                )
                safe_print(f"{tag:3} {m['value']:<35} {m['file']}:{m.get('line', '?')}{pfi_badge}")
        if skipped:
            safe_print(f"\nSkipped (dynamic/unresolved) ({len(skipped)})")
            for s in skipped:
                safe_print(f"- dynamic: {s['file']}:{s.get('line', '?')}  {s['value']}")

    # Emit dashboard report
    if emit:
        project_name = os.path.basename(os.path.abspath(project))

        # Convert missing items to dashboard format
        items = []
        for m in missing:
            items.append(
                {
                    "type": "image" if m["kind"] == "img" else "sound",
                    "path": m["value"],
                    "status": "missing",
                    "ref": f"{m['file']}:{m.get('line', '?')}",
                }
            )

        # Add OK items for completeness
        for r in refs:
            if not any(m["value"] == r["value"] for m in missing):
                items.append(
                    {
                        "type": "image" if r["kind"] == "img" else "sound",
                        "path": r["value"],
                        "status": "ok",
                        "ref": f"{r['file']}:{r.get('line', '?')}",
                    }
                )

        report = create_media_report(
            kind="media-missing",
            title="Media — Missing",
            project_name=project_name,
            missing_count=len(missing),
            ok_count=ok_count,
            total_count=len(refs),
            duration_ms=duration_ms,
            items=items,
        )

        # M-12: Write to canonical .branchpy/media/ (primary); /out/ backward-compat copy is
        # written automatically by write_report_and_emit when out≠None and outside /out/.
        _media_dir = os.path.join(os.path.abspath(project), ".branchpy", "media")
        os.makedirs(_media_dir, exist_ok=True)
        _ts = time.strftime("%Y%m%d-%H%M%S")
        _media_out = os.path.join(_media_dir, f"media-{project_name}-{_ts}.json")
        write_report_and_emit(report, project, emit, out=_media_out)

    return 1 if missing else 0


# ---- Unused ------------------------------------------------------------------

_DEFAULT_EXTS = [
    ".png",
    ".webp",
    ".jpg",
    ".jpeg",
    ".ogg",
    ".mp3",
    ".wav",
    ".opus",
    ".mp4",
    ".webm",
    ".ogv",
]


def _asset_lookup_keys(path: str) -> Set[str]:
    normalized = _norm(path).lower()
    no_ext = os.path.splitext(normalized)[0]
    stem = os.path.basename(no_ext)
    keys = {normalized, no_ext, stem}
    for prefix in (
        "images/",
        "audio/",
        "music/",
        "sound/",
        "voice/",
        "video/",
        "movies/",
    ):
        if no_ext.startswith(prefix):
            keys.add(no_ext[len(prefix) :])
    return {k for k in keys if k}


def _build_asset_lookup(on_disk: List[str]) -> Dict[str, List[str]]:
    lookup: Dict[str, List[str]] = {}
    for path in on_disk:
        for key in _asset_lookup_keys(path):
            lookup.setdefault(key, []).append(path)
    return lookup


def _resolve_logical_asset(
    raw_value: str,
    guessed_value: str,
    lookup: Dict[str, List[str]],
) -> Optional[str]:
    candidates: List[str] = []
    for value in (raw_value, guessed_value):
        normalized = _norm(value).lower().strip()
        if not normalized:
            continue
        candidates.extend(
            [
                normalized,
                normalized.replace("_", " "),
                normalized.replace(" ", "_"),
            ]
        )

    seen: Set[str] = set()
    for key in candidates:
        if key in seen:
            continue
        seen.add(key)
        matches = lookup.get(key, [])
        if len(matches) == 1:
            return matches[0]
    return None


# ---- Ren'Py Essentials classifier -------------------------------------------
#
# Standard Ren'Py GUI/system assets that are used through engine conventions,
# style system, or implicit framework wiring rather than direct script refs.
# These should NOT be reported as "unused" — they belong to a separate class.
#
# Rule set is conservative: a file must match a known Ren'Py asset convention
# to be classified essential.  The classification is advisory, not a guarantee.
# Governance: MEDIA-ESSENTIAL-V1

_RENPY_ESSENTIAL_PREFIXES = (
    "gui/bar/",
    "gui/button/",
    "gui/slider/",
    "gui/scrollbar/",
    "gui/overlay/",
    "gui/phone/",
    "gui/arrow/",        # GAP-8: scrollbar arrow images
)

_RENPY_ESSENTIAL_EXACT = frozenset({
    "gui/frame.png",
    "gui/main_menu.jpg",
    "gui/main_menu.png",     # GAP-8: .png variant used by some templates
    "gui/game_menu.png",     # GAP-8: in-game menu background
    "gui/namebox.png",
    "gui/notify.png",
    "gui/nvl.png",
    "gui/skip.png",
    "gui/startextbox.png",
    "gui/textbox.png",
    "gui/window_icon.png",
    "gui/window_icon.ico",   # GAP-8: Windows launcher icon
    "gui/mouse0.png",
    "gui/mouse1.png",
    "gui/mouse2.png",
    "gui/confirm.png",       # GAP-8: confirm screen background
    "gui/choice.png",        # GAP-8: choice button background
    "gui/dialogue.png",      # GAP-8: used in some default templates
})

# Imagemap state families (any file with these prefixes in images/)
_RENPY_IMAGEMAP_STEMS = (
    "imagemap ",
    "imagedissolve ",
)


def _is_renpy_essential(rel_path: str) -> bool:
    """
    Return True when `rel_path` matches a known Ren'Py GUI/system asset convention.

    The classification is conservative: only well-known framework-managed
    asset families qualify.  Project-specific files that happen to live in
    the same directories do NOT automatically qualify.
    """
    p = _norm(rel_path).lower()
    if p in _RENPY_ESSENTIAL_EXACT:
        return True
    for prefix in _RENPY_ESSENTIAL_PREFIXES:
        if p.startswith(prefix):
            return True
    # Standard imagemap / imagedissolve transition families in images/
    for stem in _RENPY_IMAGEMAP_STEMS:
        if ("images/" + stem) in p or p.startswith(stem):
            return True
    return False


def _parse_exts(exts: Optional[list[str]]) -> Set[str]:
    """
    Returns a normalized set like {'.png', '.jpg'}.
    If exts is None/empty, falls back to _DEFAULT_EXTS.
    """
    if not exts:
        return set(_DEFAULT_EXTS)

    out: Set[str] = set()
    for e in exts:
        e = (e or "").strip().lower().lstrip(".")
        if e:
            out.add(f".{e}")
    # If user passed only blanks, fall back to defaults
    return out or set(_DEFAULT_EXTS)


def _walk_assets(
    asset_root: str, exts: Set[str], ignore: Optional[list[str]] = None
) -> List[str]:
    results: List[str] = []
    for r, dirs, files in os.walk(asset_root):
        if ignore:
            # prune ignored directories early
            dirs[:] = [
                d
                for d in dirs
                if not _is_ignored(asset_root, os.path.join(r, d), ignore)
            ]
        for fn in files:
            full = os.path.join(r, fn)
            if ignore and _is_ignored(asset_root, full, ignore):
                continue
            if os.path.splitext(fn)[1].lower() in exts:
                results.append(_rel_norm(asset_root, full))
    return results


def run_unused(
    project: str,
    assets_root: str,
    exts: Optional[list[str]],
    as_json: bool = False,
    fail_on_unused: bool = False,
    ignore: Optional[list[str]] = None,
    emit: bool = True,
) -> int:
    start_time = time.time()
    _pfi_cfg_u: Dict[str, Any] = {}
    _media_rules_u: List[Dict[str, Any]] = []
    try:
        from pathlib import Path as _Path
        from branchpy.config import load_config
        _cfg_u = load_config(_Path(project))
        _pfi_cfg_u = _cfg_u.get("media", {}).get("pfi", {})
        _media_rules_u = _cfg_u.get("media", {}).get("rules", []) or []
    except Exception:
        pass
    refs, skipped_u, _pfi_cands_u = _scan_project_for_media(
        project, ignore=ignore, asset_root=assets_root, pfi_config=_pfi_cfg_u
    )
    # Apply project-rule overrides before unused-set computation.
    _apply_project_rules(refs, _media_rules_u, assets_root)
    _apply_project_rules(skipped_u, _media_rules_u, assets_root)
    _apply_project_rules(_pfi_cands_u, _media_rules_u, assets_root)
    ref_set = set(_norm(r["value"]).lower() for r in refs)
    # Fuzzy lookup: expands logical names to all canonical keys so that a script
    # reference like "imagedissolve circleiris" matches the disk asset at
    # "images/imagedissolve circleiris.png" (prefix + extension mismatch).
    _ref_lookup: Set[str] = set()
    for _r in refs:
        _ref_lookup.update(_asset_lookup_keys(_r["value"]))

    exts_set = _parse_exts(exts)  # now strictly Set[str]
    on_disk = _walk_assets(assets_root, exts_set, ignore=ignore)
    if len(on_disk) == 0:
        safe_print_err(
            "Warning: No assets were scanned (scanned == 0). Check --assets path; try tests/media_demo/game"
        )

    unused_all = [p for p in on_disk if not (_asset_lookup_keys(p) & _ref_lookup)]

    # Split into essential (framework-managed) and genuinely unused
    essential = [p for p in unused_all if _is_renpy_essential(p)]
    unused = [p for p in unused_all if not _is_renpy_essential(p)]

    # ------------------------------------------------------------------ #
    # 3-way confidence classification of unused files                     #
    # For each on-disk file that has no hard ref, check if it has any     #
    # soft signal in skipped (candidate_literal) or dynamic_* entries.   #
    # ------------------------------------------------------------------ #
    # Build a normalised lookup set of soft signals per kind
    _candidate_paths: Set[str] = set()
    _dynamic_paths: Set[str] = set()
    for s in skipped_u:
        kind = s.get("kind", "")
        val = _norm(s.get("value", ""))
        val_lower = val.lower()
        if kind == "candidate_literal":
            _candidate_paths.update(_asset_lookup_keys(val))
        elif kind in ("dynamic_audio", "dynamic_image", "dynamic"):
            _dynamic_paths.update(_asset_lookup_keys(val))
    # Apply project rules: user-classified "dynamic_used" items go into candidate bucket
    for r in refs:
        if r.get("rule_classification") in ("dynamic_used",):
            _candidate_paths.update(_asset_lookup_keys(_norm(r.get("value", ""))))

    def _classify_unused(path: str) -> str:
        """Return 'candidate', 'dynamic_risk', or 'unused' for an on-disk file."""
        keys = _asset_lookup_keys(path)
        if keys & _candidate_paths:
            return "candidate"
        if keys & _dynamic_paths:
            return "dynamic_risk"
        return "unused"

    # Convert to dict format with categories and confidence classification
    unused_with_category = []
    unused_candidates = []    # soft signals exist (candidate_literal)
    unused_dynamic = []       # dynamic-risk signals exist
    unused_high_conf = []     # no soft signals at all — genuinely unreferenced

    for p in unused:
        classification = _classify_unused(p)
        item = {"path": p, "category": _categorize_media(p), "unused_classification": classification}
        unused_with_category.append(item)
        if classification == "candidate":
            unused_candidates.append(item)
        elif classification == "dynamic_risk":
            unused_dynamic.append(item)
        else:
            unused_high_conf.append(item)

    essential_with_category = [
        {"path": p, "category": _categorize_media(p), "usage_reason": "renpy_gui_convention"}
        for p in essential
    ]

    duration_ms = int((time.time() - start_time) * 1000)

    if as_json:
        from json import dumps as _dumps

        payload = {
            "mode": "unused",
            "summary": {
                "issues": len(unused),
                "essential": len(essential),
                # 3-way split counts
                "unused_high_conf": len(unused_high_conf),
                "unused_candidates": len(unused_candidates),
                "unused_dynamic": len(unused_dynamic),
            },
            "issues": unused_with_category,
            "essential": essential_with_category,
            # Named 3-way split lists for UI consumption
            "unused_high_conf": unused_high_conf,
            "unused_candidates": unused_candidates,
            "unused_dynamic": unused_dynamic,
        }
        safe_print(_dumps(payload, indent=2, ensure_ascii=False))
    else:
        safe_print(f"Unused media ({len(unused)})")
        if len(unused) == 0:
            safe_print("  ✓ All media files are used (no issues)")
        else:
            for item in unused_with_category:
                safe_print(f"  [{item['category']:10}] {item['path']}")
        if essential:
            safe_print(f"\nRen'Py Essentials ({len(essential)})  [framework-managed, not flagged as unused]")
            for item in essential_with_category:
                safe_print(f"  [{item['category']:10}] {item['path']}")

    # Emit dashboard report
    if emit:
        project_name = os.path.basename(os.path.abspath(project))

        # Convert to dashboard format
        items = []
        for path in unused:
            # Determine file type from extension
            ext = os.path.splitext(path)[1].lower()
            file_type = (
                "image" if ext in [".png", ".webp", ".jpg", ".jpeg"] else "sound"
            )
            items.append(
                {"type": file_type, "path": path, "status": "unused", "ref": ""}
            )

        # Add used items for context
        for r in refs:
            if _norm(r["value"]).lower() in ref_set:
                items.append(
                    {
                        "type": "image" if r["kind"] == "img" else "sound",
                        "path": r["value"],
                        "status": "ok",
                        "ref": f"{r['file']}:{r.get('line', '?')}",
                    }
                )

        report = create_media_report(
            kind="media-unused",
            title="Media — Unused",
            project_name=project_name,
            unused_count=len(unused),
            ok_count=len(refs),
            total_count=len(on_disk),
            duration_ms=duration_ms,
            items=items,
        )

        # M-12: canonical .branchpy/media/ write
        _media_dir = os.path.join(os.path.abspath(project), ".branchpy", "media")
        os.makedirs(_media_dir, exist_ok=True)
        _ts = time.strftime("%Y%m%d-%H%M%S")
        _media_out = os.path.join(_media_dir, f"media-{project_name}-{_ts}.json")
        write_report_and_emit(report, project, emit, out=_media_out)

    return 2 if (fail_on_unused and unused) else 0


# ---- Referenced --------------------------------------------------------------


def run_referenced(
    project: str,
    assets_root: str,
    exts: Optional[list[str]],
    as_json: bool = False,
    ignore: Optional[list[str]] = None,
    emit: bool = True,
) -> int:
    """
    Scan project for media files that are both on disk AND referenced in scripts.
    This is the intersection of on-disk files and script references.
    """
    start_time = time.time()
    refs, _, _pfi_cands_r = _scan_project_for_media(project, ignore=ignore)
    # Fuzzy lookup — same logic as run_unused: handles logical-name → prefixed-path mismatches.
    _ref_lookup_r: Set[str] = set()
    for _r in refs:
        _ref_lookup_r.update(_asset_lookup_keys(_r["value"]))

    exts_set = _parse_exts(exts)
    on_disk = _walk_assets(assets_root, exts_set, ignore=ignore)

    # Intersection: files that exist on disk AND are referenced (fuzzy match)
    referenced = [p for p in on_disk if bool(_asset_lookup_keys(p) & _ref_lookup_r)]

    # Convert to dict format with categories
    referenced_with_category = [
        {"path": p, "category": _categorize_media(p)} for p in referenced
    ]

    duration_ms = int((time.time() - start_time) * 1000)

    if as_json:
        from json import dumps as _dumps

        payload = {
            "mode": "referenced",
            "summary": {"count": len(referenced)},
            "files": referenced_with_category,  # Array of {path, category} objects
        }
        safe_print(_dumps(payload, indent=2, ensure_ascii=False))
    else:
        safe_print(f"Referenced media ({len(referenced)} files)")
        if len(referenced) == 0:
            safe_print("  No referenced files found")
        else:
            for item in referenced_with_category:
                safe_print(f"  [{item['category']:10}] {item['path']}")

    # Emit dashboard report
    if emit:
        project_name = os.path.basename(os.path.abspath(project))

        items = []
        for path in referenced:
            ext = os.path.splitext(path)[1].lower()
            file_type = (
                "image" if ext in [".png", ".webp", ".jpg", ".jpeg"] else "sound"
            )
            # Find the reference info
            ref_info = next(
                (r for r in refs if _norm(r["value"]).lower() == _norm(path).lower()),
                None,
            )
            ref_str = (
                f"{ref_info['file']}:{ref_info.get('line', '?')}" if ref_info else ""
            )

            items.append(
                {"type": file_type, "path": path, "status": "ok", "ref": ref_str}
            )

        report = create_media_report(
            kind="media-referenced",
            title="Media — Referenced",
            project_name=project_name,
            ok_count=len(referenced),
            total_count=len(on_disk),
            duration_ms=duration_ms,
            items=items,
        )

        # M-12: canonical .branchpy/media/ write
        _media_dir = os.path.join(os.path.abspath(project), ".branchpy", "media")
        os.makedirs(_media_dir, exist_ok=True)
        _ts = time.strftime("%Y%m%d-%H%M%S")
        _media_out = os.path.join(_media_dir, f"media-{project_name}-{_ts}.json")
        write_report_and_emit(report, project, emit, out=_media_out)

    return 0


def _is_protected_path(path: str) -> bool:
    """Return True if the asset is in a Ren'Py-managed directory."""
    p = path.lower().replace("\\", "/")
    # Mid-path markers (e.g. "sprites/gui/icons.png")
    protected_markers = ("/gui/", "/ui/", "/menu/", "/screens/", "/fonts/", "/system/")
    if any(m in p for m in protected_markers):
        return True
    # Leading-path prefixes: paths relative to game/ assets root (e.g. "gui/frame.png")
    protected_prefixes = ("gui/", "ui/", "menu/", "screens/", "fonts/", "system/")
    return any(p.startswith(pr) for pr in protected_prefixes)


def _protection_reason(path: str) -> str:
    """Return a human-readable reason why an asset path is protected from cleanup analysis."""
    p = path.lower().replace("\\", "/")
    if "/gui/" in p or p.startswith("gui/"):
        return "Ren'Py GUI system"
    if "/fonts/" in p or p.startswith("fonts/"):
        return "Font assets"
    if "/screens/" in p or p.startswith("screens/"):
        return "UI screen assets"
    if "/ui/" in p or p.startswith("ui/"):
        return "UI directory"
    if "/menu/" in p or p.startswith("menu/"):
        return "Menu assets"
    if "/system/" in p or p.startswith("system/"):
        return "System files"
    return "Protected directory"


# ---- Asset Catalog -----------------------------------------------------------

# Folder-name sets used for path-based semantic inference
_FOLDER_UI_NAMES = frozenset({
    "gui", "ui", "interface", "buttons", "button", "icons", "icon",
    "frames", "frame", "scrollbar", "scrollbars", "thumbs", "thumb",
    "arrows", "arrow", "cursor", "cursors", "menus", "menu",
    "hover", "idle", "selected", "check", "toggle", "bar", "bars",
    "ninepatch", "ninepatches",
})
_FOLDER_BG_NAMES = frozenset({
    "bg", "backgrounds", "background", "cg", "cgs", "locations",
    "location", "scenes", "scene", "rooms", "room", "environments",
    "environment", "maps", "map",
})
_FOLDER_CHAR_NAMES = frozenset({
    "sprites", "sprite", "chars", "characters", "character",
})


def _classify_from_folder_hint(folder_path: Optional[str]) -> Optional[tuple]:
    """
    Scan all segments of a relative folder path for known semantic folder names.
    Returns (type, confidence) if any segment matches, else None.
    Checks deepest segment first (most specific).
    """
    if not folder_path:
        return None
    segments = [s for s in folder_path.lower().replace("\\", "/").split("/") if s and s not in (".", "")]
    for seg in reversed(segments):
        if seg in _FOLDER_UI_NAMES:
            return "ui", 0.75
        if seg in _FOLDER_BG_NAMES:
            return "background", 0.70
        if seg in _FOLDER_CHAR_NAMES:
            return "character", 0.65
    return None


def _classify_asset_family(
    tag: str,
    is_layeredimage: bool,
    character_tags: Set[str],
    show_count: int,
    scene_count: int,
    binding_types: Optional[list] = None,
    folder_hint: Optional[str] = None,
    variant_attrs: Optional[Set[str]] = None,
) -> tuple:
    """
    Classify a family. Returns (type, confidence) where confidence is 0.0–1.0.

    Tier model (highest confidence wins):
      1.00  layeredimage declaration  → character  (engine-definitive)
      0.95  define Character(…)       → character  (engine-definitive)
      0.90  all bindings non-file     → displayable (binding-definitive)
      0.85  bg-prefix + file variants → background  (strong name + binding)
      0.75  folder name in UI set     → ui          (structural)
      0.70  folder name in BG set     → background  (structural)
      0.70  UI tag/prefix blocklist   → ui          (name-based)
      0.65  folder name in char set   → character   (structural)
      0.65  scene-only usage          → background  (usage-based)
      0.60  sprite-state variant attrs → character  (morphology)
      0.00  fallback                  → unknown
    """
    # Tier 1 — engine-definitive
    if is_layeredimage:
        return "character", 1.0
    if tag in character_tags:
        return "character", 0.95

    # Tier 2 — binding-definitive: all variants are generated/non-file
    if binding_types and all(b in ("color", "displayable", "alias") for b in binding_types):
        return "displayable", 0.90

    # Tier 3 — bg-prefix + has at least one file-backed variant
    _BG_TAGS = frozenset({"bg", "background", "cg", "loc", "location", "room"})
    if (tag in _BG_TAGS or tag.startswith("bg_") or tag.startswith("background_")) and binding_types:
        if any(b in ("file", "auto") for b in binding_types):
            return "background", 0.85

    # Tier 4 — folder path semantic hints (deepest segment wins)
    folder_result = _classify_from_folder_hint(folder_hint)
    if folder_result:
        return folder_result

    # Tier 5 — UI tag/prefix blocklist (name-based, medium confidence)
    _UI_TAGS = frozenset({
        "ui", "gui", "icon", "button", "menu", "cursor", "bar", "overlay",
        "launcher", "popup", "ninepatch", "check", "imagemap", "logo",
        "paper", "spotlight", "magic", "hover", "idle", "selected",
        "frame", "scroll", "slider", "thumb", "arrow",
    })
    _UI_PREFIXES = ("ui_", "gui_", "btn_", "icon_", "launcher", "popup_", "check_")
    if tag in _UI_TAGS or any(tag.startswith(p) for p in _UI_PREFIXES):
        return "ui", 0.70

    # Tier 6 — scene-only usage (medium usage-based signal)
    if scene_count > 0 and show_count == 0:
        return "background", 0.65

    # Tier 7 — sprite-state morphology (at least one known emotional/state attribute)
    if variant_attrs and variant_attrs & _SPRITE_STATE_WORDS:
        return "character", 0.60

    return "unknown", 0.0


def _build_asset_catalog(
    project_root: str,
    assets_root: str,
    ignore: Optional[list[str]] = None,
    exts: Optional[list[str]] = None,
) -> Dict[str, Any]:
    """
    Build an Asset Catalog from Ren'Py declarations and usage.

    Parses:
    - ``image TAG ATTRS = "path"`` declarations
    - ``layeredimage TAG:`` declarations
    - ``define IDENTIFIER = Character(...)`` definitions
    - ``show TAG ATTRS`` usages (character evidence)
    - ``scene TAG ATTRS`` usages (background evidence)

    Returns a dict suitable for JSON serialisation.
    """
    rpy_files: list[str] = []
    for root_dir, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__", "node_modules")]
        for f in files:
            if f.endswith(".rpy"):
                full = os.path.join(root_dir, f)
                if not _is_ignored(project_root, full, ignore):
                    rpy_files.append(full)

    # { label_lower: {label, path, file, line} }
    image_defs: Dict[str, Dict] = {}
    # { tag_lower: {tag, file, line} }
    layeredimage_defs: Dict[str, Dict] = {}
    # Set of identifier names known to be characters via define
    character_tags: Set[str] = set()
    # Usage tracking keyed by tag
    show_usages: Dict[str, list] = {}
    scene_usages: Dict[str, list] = {}

    for rpy_path in rpy_files:
        text = _read_text(rpy_path)
        rel_path = _rel_norm(project_root, rpy_path)

        # Image declarations: image TAG ATTRS = "path"
        for m in IMAGE_PLACEHOLDER_DEF_RE.finditer(text):
            label = m.group(1).strip()
            path_str = m.group(2)
            line = _line_of(text, m.start())
            label_lower = label.lower()
            image_defs.setdefault(label_lower, {
                "label": label,
                "path": _norm(path_str),
                "file": rel_path,
                "line": line,
            })

        # Layeredimage declarations
        for m in LAYEREDIMAGE_DEF_RE.finditer(text):
            tag_str = m.group(1).strip().split()[0]  # first word only
            tag_lower = tag_str.lower()
            line = _line_of(text, m.start())
            layeredimage_defs.setdefault(tag_lower, {
                "tag": tag_str,
                "file": rel_path,
                "line": line,
            })

        # Character definitions via define
        for m in DEFINE_CHARACTER_RE.finditer(text):
            character_tags.add(m.group(1).strip().lower())

        # show usages
        for m in SHOW_SCENE_PLACEHOLDER_RE.finditer(text):
            label = m.group(1).strip()
            tag = label.split()[0].lower()
            line = _line_of(text, m.start())
            show_usages.setdefault(tag, []).append(
                {"label": label, "file": rel_path, "line": line}
            )

        # scene usages
        for m in SCENE_ONLY_PLACEHOLDER_RE.finditer(text):
            label = m.group(1).strip()
            tag = label.split()[0].lower()
            line = _line_of(text, m.start())
            scene_usages.setdefault(tag, []).append(
                {"label": label, "file": rel_path, "line": line}
            )

    # Disk files
    exts_set = _parse_exts(exts)
    on_disk = _walk_assets(assets_root, exts_set, ignore=ignore)
    on_disk_norm: Set[str] = {_norm(p).lower() for p in on_disk}
    # Richer lookup set: each disk path expands to all lookup keys (stem, no-ext, stripped-prefix).
    # Fixes the path-resolver mismatch where declared "images/logo base.png" and disk "logo base.png"
    # share the stem key "logo base" but differ in prefix/extension.
    on_disk_keys: Set[str] = set()
    for _dp in on_disk:
        on_disk_keys.update(_asset_lookup_keys(_dp))
    declared_paths_norm: Set[str] = {_norm(d["path"]).lower() for d in image_defs.values()}
    # Key-expanded version of declared paths: used for orphan suppression so that
    # a declared path "logo base.png" and disk path "images/logo base.png" both
    # produce the stem key "logo base" and correctly suppress the orphan entry.
    declared_keys: Set[str] = set()
    for _decl in image_defs.values():
        declared_keys.update(_asset_lookup_keys(_decl["path"]))

    # Gather all tags
    all_tags: Set[str] = set()
    for label_lower in image_defs:
        all_tags.add(label_lower.split()[0])
    all_tags.update(layeredimage_defs.keys())

    families: Dict[str, Dict] = {}
    for tag in all_tags:
        variants = []
        for label_lower, defn in image_defs.items():
            if label_lower.split()[0] != tag:
                continue
            attrs = label_lower.split()[1:]
            # Collect matched usages for this specific variant
            usage_list: list = []
            label_usages = [u for u in show_usages.get(tag, []) if u["label"].lower() == label_lower]
            label_usages += [u for u in scene_usages.get(tag, []) if u["label"].lower() == label_lower]
            for u in label_usages[:5]:
                usage_list.append({"file": u["file"], "line": u["line"]})
            # Check on-disk by fuzzy keys
            file_on_disk = bool(_asset_lookup_keys(defn["path"]) & on_disk_keys)
            btype = _detect_binding_type(defn["path"])
            variants.append({
                "label": defn["label"],
                "attributes": attrs,
                "file": defn["path"],
                "binding_type": btype,
                "declaration_file": defn["file"],
                "declaration_line": defn["line"],
                "on_disk": file_on_disk if btype == "file" else None,
                "usage_count": len(label_usages),
                "usages": usage_list,
            })

        is_layeredimage = tag in layeredimage_defs
        show_count = len(show_usages.get(tag, []))
        scene_count = len(scene_usages.get(tag, []))
        binding_types = [v["binding_type"] for v in variants]
        variant_attrs_set = {a.lower() for v in variants for a in v.get("attributes", [])}
        family_type, family_confidence = _classify_asset_family(
            tag=tag,
            is_layeredimage=is_layeredimage,
            character_tags=character_tags,
            show_count=show_count,
            scene_count=scene_count,
            binding_types=binding_types,
            variant_attrs=variant_attrs_set,
        )

        # Orphan disk files: match tag prefix, not already declared.
        # Use key-set intersection so that path-prefix mismatches (e.g. declared
        # "logo base.png" vs disk "images/logo base.png") are handled correctly.
        orphan_files: list[str] = []
        for p in on_disk:
            if _asset_lookup_keys(p) & declared_keys:
                continue
            if _is_renpy_essential(p):
                continue
            stem = os.path.splitext(os.path.basename(p))[0].lower()
            if stem == tag or stem.startswith(tag + "_") or stem.startswith(tag + " "):
                orphan_files.append(p)

        referenced_count = sum(1 for v in variants if v["usage_count"] > 0)
        # Mark family as hybrid if it contains both file/auto variants AND
        # non-file (color/displayable/alias) variants.  The UI can surface this
        # to prevent the family from looking like a pure background or character set.
        has_file = any(b in ("file", "auto") for b in binding_types)
        has_non_file = any(b in ("color", "displayable", "alias") for b in binding_types)
        families[tag] = {
            "tag": tag,
            "type": family_type,
            "type_confidence": family_confidence,
            "is_hybrid": has_file and has_non_file,
            "declaration_type": "layeredimage" if is_layeredimage else "image",
            "declared_count": len(variants),
            "referenced_count": referenced_count,
            "orphan_count": len(orphan_files),
            "show_usages": show_count,
            "scene_usages": scene_count,
            "variants": variants,
            "orphan_files": orphan_files[:20],
        }

    _TYPE_ORDER = {"character": 0, "background": 1, "ui": 2, "displayable": 3, "object": 4, "unknown": 5}

    # ── Auto-image pass ──────────────────────────────────────────────────────
    # Ren'Py automatically creates image declarations from files in the images/
    # directory: "eileen happy.png" → `image eileen happy`.  These never appear
    # in .rpy files, so we build families directly from disk files for any tag
    # that has NO explicit declaration family yet.
    covered_paths_norm: Set[str] = {
        _norm(v["file"]).lower()
        for f in families.values()
        for v in f["variants"]
        if v.get("binding_type") == "file"
    }
    auto_by_tag: Dict[str, list] = {}
    for p in on_disk:
        if _is_renpy_essential(p):
            continue
        if _norm(p).lower() in covered_paths_norm:
            continue
        # ── Image-only filter ──────────────────────────────────────
        # Only image files belong in the image asset catalog.
        # Audio (.ogg, .opus, .wav) and video (.webm, .mp4) are excluded.
        ext = os.path.splitext(p)[1].lower()
        if ext not in _IMAGE_EXTS_AUTO:
            continue
        stem = os.path.splitext(os.path.basename(p))[0]
        parts = stem.split()
        if not parts:
            continue
        tag = parts[0].lower()
        # For bg-prefix families: if the existing family has no file-backed declared variants,
        # absorb this disk file as an auto variant and reclassify (prevents bg cave.jpg being
        # stranded as an orphan while color/displayable aliases crowd the Backgrounds bucket).
        _BG_FAMILY_TAGS_AUTO = frozenset({"bg", "background", "cg", "loc", "location", "room"})
        if tag in families:
            existing = families[tag]
            is_bg_tag = (
                tag in _BG_FAMILY_TAGS_AUTO
                or tag.startswith("bg_")
                or tag.startswith("background_")
            )
            existing_btypes = [v["binding_type"] for v in existing["variants"]]
            # Promote ALL bg-tagged disk files as auto variants (not just the first one).
            # Check per-file whether it's already represented, not family-level file presence.
            p_norm_check = _norm(p).lower()
            already_variant = any(_norm(v["file"]).lower() == p_norm_check for v in existing["variants"])
            if is_bg_tag and not already_variant:
                # Disk bg image not yet represented in variants — promote it
                attrs_auto = parts[1:] if len(parts) > 1 else []
                label_auto = stem
                label_lower_auto = label_auto.lower()
                lu_auto = [u for u in show_usages.get(tag, []) if u["label"].lower() == label_lower_auto]
                lu_auto += [u for u in scene_usages.get(tag, []) if u["label"].lower() == label_lower_auto]
                auto_v = {
                    "label": label_auto,
                    "attributes": attrs_auto,
                    "file": p,
                    "binding_type": "auto",
                    "declaration_file": None,
                    "declaration_line": None,
                    "on_disk": True,
                    "usage_count": len(lu_auto),
                    "usages": [{"file": u["file"], "line": u["line"]} for u in lu_auto[:5]],
                }
                existing["variants"].append(auto_v)
                existing["declared_count"] += 1
                if lu_auto:
                    existing["referenced_count"] += 1
                # Remove from orphan_files (was added during explicit family pass)
                p_norm_lower = _norm(p).lower()
                existing["orphan_files"] = [
                    of for of in existing["orphan_files"] if _norm(of).lower() != p_norm_lower
                ]
                existing["orphan_count"] = len(existing["orphan_files"])
                # Reclassify: bg tag + now has file variant → background
                all_btypes = [v["binding_type"] for v in existing["variants"]]
                all_attrs = {a.lower() for v in existing["variants"] for a in v.get("attributes", [])}
                new_type, new_conf = _classify_asset_family(
                    tag=tag,
                    is_layeredimage=existing.get("declaration_type") == "layeredimage",
                    character_tags=character_tags,
                    show_count=existing["show_usages"],
                    scene_count=existing["scene_usages"],
                    binding_types=all_btypes,
                    variant_attrs=all_attrs,
                )
                existing["type"] = new_type
                existing["type_confidence"] = new_conf
                # Update hybrid flag after absorbing file-backed variant into what may have
                # been a pure color/displayable family.
                has_file_now = any(b in ("file", "auto") for b in all_btypes)
                has_non_file_now = any(b in ("color", "displayable", "alias") for b in all_btypes)
                existing["is_hybrid"] = has_file_now and has_non_file_now
            continue
        attrs = parts[1:] if len(parts) > 1 else []
        label = stem
        label_lower = label.lower()
        label_usages = [u for u in show_usages.get(tag, []) if u["label"].lower() == label_lower]
        label_usages += [u for u in scene_usages.get(tag, []) if u["label"].lower() == label_lower]
        # Auto-image heuristic: only create an auto family for this file if
        #   (a) the stem uses space-separated words (Ren'Py auto-image convention), OR
        #   (b) the file is actually referenced in a script.
        # Files with no-space stems that are unreferenced are NOT Ren'Py auto-images;
        # they will be grouped by the path-cluster pass below.
        if not label_usages and " " not in stem:
            continue
        auto_by_tag.setdefault(tag, []).append({
            "label": label,
            "attributes": attrs,
            "file": p,
            "binding_type": "auto",
            "declaration_file": None,
            "declaration_line": None,
            "on_disk": True,
            "usage_count": len(label_usages),
            "usages": [{"file": u["file"], "line": u["line"]} for u in label_usages[:5]],
        })

    for tag, auto_variants in auto_by_tag.items():
        show_count = len(show_usages.get(tag, []))
        scene_count = len(scene_usages.get(tag, []))
        variant_attrs_set = {a.lower() for v in auto_variants for a in (v.get("attributes") or [])}
        family_type, family_confidence = _classify_asset_family(
            tag=tag,
            is_layeredimage=False,
            character_tags=character_tags,
            show_count=show_count,
            scene_count=scene_count,
            binding_types=["auto"] * len(auto_variants),
            variant_attrs=variant_attrs_set,
        )
        # Sprite-state heuristic is now inside _classify_asset_family (Tier 7).
        # For auto families with ≥2 variants the function already checks variant_attrs.
        referenced_count = sum(1 for v in auto_variants if v["usage_count"] > 0)
        families[tag] = {
            "tag": tag,
            "type": family_type,
            "type_confidence": family_confidence,
            "is_hybrid": False,  # auto families are file-only by definition
            "declaration_type": "auto",
            "declared_count": len(auto_variants),
            "referenced_count": referenced_count,
            "orphan_count": 0,
            "show_usages": show_count,
            "scene_usages": scene_count,
            "variants": auto_variants,
            "orphan_files": [],
        }

    # ── Path-cluster pass ────────────────────────────────────────────────────
    # Group any remaining disk images (not covered by explicit, auto, or orphan
    # association) by their immediate parent folder.  This gives stable, useful
    # families to deeply-structured projects (e.g. MAS mod_assets/) even when
    # there are no matching Ren'Py image declarations.
    #
    # Each cluster becomes a family with:
    #   declaration_type = "path_cluster"
    #   cluster_path     = relative folder (for UI display)
    #   type             = inferred from folder-name semantics + confidence score
    covered_by_any: Set[str] = set()
    for _fam in families.values():
        for _v in _fam["variants"]:
            if _v.get("file"):
                covered_by_any.add(_norm(_v["file"]).lower())
        for _of in _fam.get("orphan_files", []):
            covered_by_any.add(_norm(_of).lower())

    folder_groups: Dict[str, list] = {}
    for p in on_disk:
        if _is_renpy_essential(p):
            continue
        ext = os.path.splitext(p)[1].lower()
        if ext not in _IMAGE_EXTS_AUTO:
            continue
        if _norm(p).lower() in covered_by_any:
            continue
        # p is already relative to assets_root (returned by _walk_assets via _rel_norm).
        # Normalise separators only — do NOT call os.path.relpath (which would resolve
        # against CWD and produce wrong ../.. paths for relative inputs).
        rel = p.replace("\\", "/")
        # Guard: skip anything that escaped the assets root (symlink edge-cases)
        if rel.startswith(".."):
            continue
        folder = "/".join(rel.split("/")[:-1]) or "."
        folder_groups.setdefault(folder, []).append(p)

    for folder_path, paths in folder_groups.items():
        # Last non-empty, non-generic path segment → family tag
        segments = [s for s in folder_path.split("/") if s and s not in (".", "")]
        base_tag = (segments[-1] if segments else "_root").lower()
        # Avoid collision with existing families — append numeric suffix if needed
        cluster_tag = base_tag
        _suffix = 0
        while cluster_tag in families:
            _suffix += 1
            cluster_tag = f"{base_tag}_{_suffix}"

        cluster_variants = []
        cluster_show = 0
        cluster_scene = 0
        for p in paths:
            stem = os.path.splitext(os.path.basename(p))[0]
            label = stem
            label_lower = label.lower()
            tag_for_usage = label_lower.split()[0] if " " in label_lower else label_lower
            lu_show = show_usages.get(tag_for_usage, [])
            lu_scene = scene_usages.get(tag_for_usage, [])
            usage_count = len(lu_show) + len(lu_scene)
            cluster_show += len(lu_show)
            cluster_scene += len(lu_scene)
            cluster_variants.append({
                "label": label,
                "attributes": [],
                "file": p,
                "binding_type": "auto",
                "declaration_file": None,
                "declaration_line": None,
                "on_disk": True,
                "usage_count": usage_count,
                "usages": [{"file": u["file"], "line": u["line"]} for u in (lu_show + lu_scene)[:5]],
            })

        cluster_attrs: Set[str] = set()  # path-cluster files use full stems, no space-split attrs
        cluster_type, cluster_confidence = _classify_asset_family(
            tag=cluster_tag,
            is_layeredimage=False,
            character_tags=character_tags,
            show_count=cluster_show,
            scene_count=cluster_scene,
            binding_types=["auto"] * len(cluster_variants),
            folder_hint=folder_path,
            variant_attrs=cluster_attrs,
        )
        referenced_count = sum(1 for v in cluster_variants if v["usage_count"] > 0)
        families[cluster_tag] = {
            "tag": cluster_tag,
            "type": cluster_type,
            "type_confidence": cluster_confidence,
            "is_hybrid": False,
            "declaration_type": "path_cluster",
            "cluster_path": folder_path,
            "declared_count": len(cluster_variants),
            "referenced_count": referenced_count,
            "orphan_count": 0,
            "show_usages": cluster_show,
            "scene_usages": cluster_scene,
            "variants": cluster_variants,
            "orphan_files": [],
        }

    sorted_families = sorted(
        families.values(),
        key=lambda f: (_TYPE_ORDER.get(f["type"], 99), f["tag"])
    )

    type_counts: Dict[str, int] = {"character": 0, "background": 0, "ui": 0, "displayable": 0, "object": 0, "unknown": 0}
    for f in sorted_families:
        type_counts[f["type"]] = type_counts.get(f["type"], 0) + 1

    # character_defines: identifiers known to be characters via `define X = Character(...)`
    # This is useful as a scope note: even if there are no image declarations for those
    # identifiers, the project does have named characters.
    return {
        "mode": "catalog",
        "summary": {
            "families": len(sorted_families),
            **type_counts,
            "total_declared": sum(f["declared_count"] for f in sorted_families),
            "total_referenced": sum(f["referenced_count"] for f in sorted_families),
            "total_orphans": sum(f["orphan_count"] for f in sorted_families),
            "character_defines": sorted(character_tags),
        },
        "families": sorted_families,
    }


# ---------------------------------------------------------------------------
# Rule dry-run — validates a proposed project rule without writing it
# ---------------------------------------------------------------------------

_CONFIDENCE_HINT_MAP: Dict[str, float] = {
    "function_ref": 0.85,
    "placeholder": 0.75,
    "asset_pattern": 0.80,
    "ignore": 1.00,
}


def run_rule_dry_run(
    project: str,
    assets_root: str,
    rule: Dict[str, Any],
    as_json: bool = True,
    ignore: Optional[List[str]] = None,
) -> int:
    """
    Validate a proposed rule (from the VS Code wizard) without writing it.

    Returns JSON like::

        {
            "mode": "rule_dry_run",
            "rule_type": "asset_pattern",
            "match_count": 42,
            "sample": ["images/bg/school.png", ...],          # first 10
            "confidence": 0.80,
            "confidence_hint": "medium",
            "conflict_note": null   # or a warning string
        }

    Exit codes: 0 OK, 1 error in rule/args.
    """
    import json

    rule_type = rule.get("type", "asset_pattern")
    pattern = rule.get("pattern", "")
    function_name = rule.get("function", "")
    arg_index = int(rule.get("arg_index", 0))
    identifier = rule.get("identifier", "")
    classification = rule.get("classification", "dynamic_used")

    # Resolve assets root
    if assets_root and not os.path.isabs(assets_root):
        assets_root = os.path.join(project, assets_root)

    # Build confidence from rule type (no raw user values)
    confidence_float = _CONFIDENCE_HINT_MAP.get(rule_type, 0.75)
    confidence_hint = (
        "high" if confidence_float >= 0.85
        else "medium" if confidence_float >= 0.70
        else "low"
    )

    matched_paths: List[str] = []
    conflict_note: Optional[str] = None

    # ── Match against disk files ────────────────────────────────────────────
    if rule_type in ("asset_pattern", "ignore") and pattern:
        if os.path.isdir(assets_root):
            # Scan all disk files and apply fnmatch against the relative path
            for dirpath, _, filenames in os.walk(assets_root):
                for fname in filenames:
                    abs_path = os.path.join(dirpath, fname)
                    rel_path = os.path.relpath(abs_path, assets_root).replace("\\", "/")
                    if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(fname, pattern):
                        matched_paths.append(rel_path)
            matched_paths.sort()
        # Conflict warning if pattern is very broad
        if pattern in ("*", "**", "**/*", "*.*"):
            conflict_note = "Pattern is very broad and may match all files. Consider narrowing it."
        elif matched_paths and len(matched_paths) > 200:
            conflict_note = f"Pattern matches {len(matched_paths)} files — consider narrowing the glob."

    elif rule_type == "function_ref" and function_name:
        # Scan .rpy files for calls to this function and count unique call sites
        _func_re = re.compile(
            r'\b' + re.escape(function_name) + r'\s*\(',
            re.IGNORECASE,
        )
        call_files: List[str] = []
        rpy_root = project  # search scripts in project root
        for dirpath, _, filenames in os.walk(rpy_root):
            for fname in filenames:
                if not fname.endswith(".rpy"):
                    continue
                fpath = os.path.join(dirpath, fname)
                try:
                    content = open(fpath, encoding="utf-8", errors="replace").read()
                except OSError:
                    continue
                calls = _func_re.findall(content)
                if calls:
                    rel = os.path.relpath(fpath, project).replace("\\", "/")
                    for _ in calls:
                        call_files.append(rel)
        matched_paths = sorted(set(call_files))
        if not matched_paths:
            conflict_note = f"No calls to {function_name}() found in .rpy files."

    elif rule_type == "placeholder" and identifier:
        # Count occurrences of the identifier in .rpy files
        _id_re = re.compile(r'\b' + re.escape(identifier) + r'\b')
        ref_files: List[str] = []
        for dirpath, _, filenames in os.walk(project):
            for fname in filenames:
                if not fname.endswith(".rpy"):
                    continue
                fpath = os.path.join(dirpath, fname)
                try:
                    content = open(fpath, encoding="utf-8", errors="replace").read()
                except OSError:
                    continue
                if _id_re.search(content):
                    rel = os.path.relpath(fpath, project).replace("\\", "/")
                    ref_files.append(rel)
        matched_paths = sorted(set(ref_files))
        if not matched_paths:
            conflict_note = f"Identifier '{identifier}' not found in any .rpy files."

    # ── Overlap + precedence simulation (pattern-based rules only) ──────────
    #
    # We simulate adding the proposed rule at the END of the existing rule list
    # (which is where the wizard appends it).  Under first-match-wins semantics,
    # any file already claimed by an earlier rule is NOT reachable by this rule.
    #
    # Algorithm:
    #   1. Bidirectional sample: take up to 25 from our matches + up to 25 from
    #      each existing rule's matches.  This catches overlaps that lie outside
    #      the proposed rule's match set (false-negative fix for unidirectional).
    #   2. For each file in the combined sample, check every existing rule first.
    #      If an earlier rule matches → that file is "blocked" for our rule.
    #   3. Apply the same logic across ALL of matched_paths (not just the sample)
    #      to produce effective_match_count.
    effective_match_count: int = len(matched_paths)
    blocked_by_existing: int = 0
    blocking_rules: List[str] = []
    overlapping: List[str] = []

    if rule_type in ("asset_pattern", "ignore") and os.path.isdir(assets_root):
        existing_rules = _load_media_rules(project)
        pattern_rules = [
            r for r in existing_rules
            if r.get("type") in ("asset_pattern", "ignore") and r.get("pattern")
        ]

        if pattern_rules:
            # Build bidirectional sample: our matches + existing-rule matches
            bi_sample: List[str] = list(matched_paths[:25])
            for ex_rule in pattern_rules:
                ex_pat = ex_rule["pattern"]
                ex_hits: List[str] = []
                for dirpath, _, filenames in os.walk(assets_root):
                    for fname in filenames:
                        rel = os.path.relpath(
                            os.path.join(dirpath, fname), assets_root
                        ).replace("\\", "/")
                        if fnmatch.fnmatch(rel, ex_pat) or fnmatch.fnmatch(fname, ex_pat):
                            ex_hits.append(rel)
                            if len(ex_hits) >= 25:
                                break
                    if len(ex_hits) >= 25:
                        break
                # Extend sample with files not already present
                for h in ex_hits:
                    if h not in bi_sample:
                        bi_sample.append(h)

            # Detect which existing rules overlap with the proposed rule (in sample)
            for ex_rule in pattern_rules:
                ex_pat = ex_rule["pattern"]
                ex_label = f"{ex_rule['type']} {ex_pat}"
                for rel in bi_sample:
                    proposed_hits = (
                        fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(rel.split("/")[-1], pattern)
                    ) if pattern else False
                    ex_hits_rel = (
                        fnmatch.fnmatch(rel, ex_pat) or fnmatch.fnmatch(rel.split("/")[-1], ex_pat)
                    )
                    if proposed_hits and ex_hits_rel and ex_label not in overlapping:
                        overlapping.append(ex_label)
                        break  # one proof per existing rule is enough

            # Precedence simulation: count how many of our matches are blocked
            # by rules that precede the proposed rule (all existing rules do).
            # Also track which specific rules are doing the blocking (for "why blocked?").
            blocked_by_existing = 0
            blocking_rules: List[str] = []  # names of rules that claim at least 1 file
            for rel in matched_paths:
                for idx, ex_rule in enumerate(pattern_rules):
                    ex_pat = ex_rule["pattern"]
                    if fnmatch.fnmatch(rel, ex_pat) or fnmatch.fnmatch(
                        rel.split("/")[-1], ex_pat
                    ):
                        blocked_by_existing += 1
                        rule_label = f"{ex_rule['type']} {ex_pat} (rule #{idx + 1})"
                        if rule_label not in blocking_rules:
                            blocking_rules.append(rule_label)
                        break  # first existing rule wins; stop checking this file
            effective_match_count = len(matched_paths) - blocked_by_existing

        # Build conflict_note (only if not already set by broad-pattern check)
        if overlapping and not conflict_note:
            joined = "\n  - ".join(overlapping)
            if effective_match_count == 0 and matched_paths:
                conflict_note = (
                    f"All {len(matched_paths)} match(es) are blocked by existing rules "
                    f"(first-match-wins). This rule would have no effect in its current position.\n"
                    f"  Overlapping rule(s):\n  - {joined}"
                )
            else:
                conflict_note = (
                    f"This rule overlaps with {len(overlapping)} existing rule(s):\n"
                    f"  - {joined}\n"
                    f"Effective matches after rule order: {effective_match_count} "
                    f"({blocked_by_existing} blocked by earlier rules)."
                )

    result = {
        "mode": "rule_dry_run",
        "rule_type": rule_type,
        "match_count": len(matched_paths),           # standalone (rule in isolation)
        "effective_match_count": effective_match_count,  # after precedence simulation
        "blocked_by_existing": blocked_by_existing,
        "blocking_rules": blocking_rules,
        "sample": matched_paths[:10],
        "confidence": confidence_float,
        "confidence_hint": confidence_hint,
        "conflict_note": conflict_note,
    }

    if as_json:
        print(json.dumps(result, indent=2))
    return 0


def run_rule_dry_run_from_toml(
    project: str,
    assets_root: str,
    as_json: bool = True,
    ignore: Optional[List[str]] = None,
) -> int:
    """
    Run dry-run simulation against ALL existing rules in .branchpy.toml.

    Useful for auditing an existing rule set outside VS Code::

        branchpy media --rule-dry-run --from-toml --project /path/to/project

    Returns JSON with one entry per rule showing standalone matches, effective
    matches after precedence, and which earlier rules are doing the blocking.
    """
    import json

    existing_rules = _load_media_rules(project)
    if not existing_rules:
        result = {"mode": "rule_dry_run_from_toml", "rules": [], "note": "No [[media.rules]] found in .branchpy.toml"}
        if as_json:
            print(json.dumps(result, indent=2))
        return 0

    if assets_root and not os.path.isabs(assets_root):
        assets_root = os.path.join(project, assets_root)

    rule_results = []
    for idx, rule in enumerate(existing_rules):
        rule_type = rule.get("type", "asset_pattern")
        pattern = rule.get("pattern", "")
        function_name = rule.get("function", "")
        identifier = rule.get("identifier", "")

        # Compute standalone matches
        matched_paths: List[str] = []
        if rule_type in ("asset_pattern", "ignore") and pattern and os.path.isdir(assets_root):
            for dirpath, _, filenames in os.walk(assets_root):
                for fname in filenames:
                    abs_path = os.path.join(dirpath, fname)
                    rel_path = os.path.relpath(abs_path, assets_root).replace("\\", "/")
                    if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(fname, pattern):
                        matched_paths.append(rel_path)
            matched_paths.sort()
        elif rule_type == "function_ref" and function_name:
            _func_re = re.compile(r'\b' + re.escape(function_name) + r'\s*\(', re.IGNORECASE)
            for dirpath, _, filenames in os.walk(project):
                for fname in filenames:
                    if not fname.endswith(".rpy"):
                        continue
                    fpath = os.path.join(dirpath, fname)
                    try:
                        content = open(fpath, encoding="utf-8", errors="replace").read()
                    except OSError:
                        continue
                    if _func_re.search(content):
                        matched_paths.append(os.path.relpath(fpath, project).replace("\\", "/"))
            matched_paths = sorted(set(matched_paths))
        elif rule_type == "placeholder" and identifier:
            _id_re = re.compile(r'\b' + re.escape(identifier) + r'\b')
            for dirpath, _, filenames in os.walk(project):
                for fname in filenames:
                    if not fname.endswith(".rpy"):
                        continue
                    fpath = os.path.join(dirpath, fname)
                    try:
                        content = open(fpath, encoding="utf-8", errors="replace").read()
                    except OSError:
                        continue
                    if _id_re.search(content):
                        matched_paths.append(os.path.relpath(fpath, project).replace("\\", "/"))
            matched_paths = sorted(set(matched_paths))

        # Precedence simulation: rules[0..idx-1] precede this rule
        preceding = [
            r for r in existing_rules[:idx]
            if r.get("type") in ("asset_pattern", "ignore") and r.get("pattern")
        ]
        blocked_count = 0
        blocking: List[str] = []
        if rule_type in ("asset_pattern", "ignore") and matched_paths:
            for rel in matched_paths:
                for p_idx, prec in enumerate(preceding):
                    pp = prec.get("pattern", "")
                    if fnmatch.fnmatch(rel, pp) or fnmatch.fnmatch(rel.split("/")[-1], pp):
                        blocked_count += 1
                        label = f"{prec['type']} {pp} (rule #{p_idx + 1})"
                        if label not in blocking:
                            blocking.append(label)
                        break

        effective = len(matched_paths) - blocked_count
        confidence_float = _CONFIDENCE_HINT_MAP.get(rule_type, 0.75)
        confidence_hint_str = (
            "high" if confidence_float >= 0.85
            else "medium" if confidence_float >= 0.70
            else "low"
        )
        note = None
        if effective == 0 and matched_paths:
            note = f"All {len(matched_paths)} match(es) blocked by earlier rules. This rule never fires."
        elif not matched_paths:
            note = "No matches found."

        rule_results.append({
            "index": idx + 1,
            "type": rule_type,
            "pattern": pattern or function_name or identifier,
            "reason": rule.get("reason", ""),
            "match_count": len(matched_paths),
            "effective_match_count": effective,
            "blocked_by_preceding": blocked_count,
            "blocking_rules": blocking,
            "confidence_hint": confidence_hint_str,
            "sample": matched_paths[:5],
            "note": note,
        })

    result = {
        "mode": "rule_dry_run_from_toml",
        "rule_count": len(existing_rules),
        "rules": rule_results,
    }
    if as_json:
        print(json.dumps(result, indent=2))
    return 0


def run_catalog(
    project: str,
    assets_root: str,
    exts: Optional[list[str]] = None,
    as_json: bool = False,
    ignore: Optional[list[str]] = None,
) -> int:
    """Scan the project and emit a structured Asset Catalog from Ren'Py declarations."""
    catalog = _build_asset_catalog(
        project_root=project,
        assets_root=assets_root,
        ignore=ignore,
        exts=exts,
    )

    if as_json:
        from json import dumps as _dumps
        safe_print(_dumps(catalog, indent=2, ensure_ascii=False))
    else:
        summary = catalog["summary"]
        safe_print(f"Asset Catalog — {summary['families']} families detected")
        safe_print(f"  Characters:  {summary.get('character', 0)}")
        safe_print(f"  Backgrounds: {summary.get('background', 0)}")
        safe_print(f"  UI:          {summary.get('ui', 0)}")
        safe_print(f"  Unknown:     {summary.get('unknown', 0)}")
        safe_print(f"  Declared variants:   {summary['total_declared']}")
        safe_print(f"  Referenced in script: {summary['total_referenced']}")
        if summary["total_orphans"] > 0:
            safe_print(f"  Orphan files detected: {summary['total_orphans']}")
        _ICON = {"character": "👤", "background": "🏞️", "ui": "🎨", "object": "📦", "unknown": "❓"}
        for family in catalog["families"]:
            icon = _ICON.get(family["type"], "❓")
            safe_print(
                f"\n{icon}  {family['tag']}  ({family['type']})  "
                f"declared={family['declared_count']}  "
                f"referenced={family['referenced_count']}  "
                f"orphans={family['orphan_count']}"
            )
    return 0


def _build_media_browser_payload(
    project: str,
    assets_root: str,
    exts: Optional[list[str]],
    ignore: Optional[list[str]] = None,
) -> Dict:
    """Build a review-focused media payload for HTML rendering."""
    from difflib import SequenceMatcher, get_close_matches

    refs, skipped, _pfi_cands_rev = _scan_project_for_media(project, ignore=ignore)
    exts_set = _parse_exts(exts)
    on_disk = _walk_assets(assets_root, exts_set, ignore=ignore)
    asset_lookup = _build_asset_lookup(on_disk)

    resolved_refs_by_path: Dict[str, List[Dict[str, str]]] = {}
    resolved_unresolved_placeholders: List[Dict] = []
    unresolved_skipped: List[Dict] = []
    for item in skipped:
        if item.get("kind") != "unresolved_placeholder":
            unresolved_skipped.append(item)
            continue
        resolved_path = _resolve_logical_asset(
            str(item.get("value", "")),
            str(item.get("guessed", "")),
            asset_lookup,
        )
        if not resolved_path:
            unresolved_skipped.append(item)
            continue
        ref_label = f"{item.get('file', '')}:{item.get('line', '?')}"
        key = _norm(resolved_path).lower()
        resolved_unresolved_placeholders.append(
            {
                "path": resolved_path,
                "ref": ref_label,
                "reason": "Resolved from Ren'Py image tag",
                "confidence": "resolved",
            }
        )
        resolved_refs_by_path.setdefault(key, []).append(
            resolved_unresolved_placeholders[-1]
        )

    direct_refs_by_path: Dict[str, List[Dict[str, str]]] = {}
    for ref in refs:
        value = str(ref.get("value", ""))
        if not _exists_under_assets(assets_root, value):
            continue
        key = _norm(value).lower()
        direct_refs_by_path.setdefault(key, []).append(
            {
                "path": value,
                "ref": f"{ref.get('file', '')}:{ref.get('line', '?')}",
                "reason": "Direct file reference",
                "confidence": "definite",
            }
        )

    ref_set = set(direct_refs_by_path.keys()) | set(resolved_refs_by_path.keys())
    missing = [r for r in refs if not _exists_under_assets(assets_root, r["value"])]
    unused = [p for p in on_disk if _norm(p).lower() not in ref_set]
    referenced = [p for p in on_disk if _norm(p).lower() in ref_set]

    protected_set = {p for p in on_disk if _is_protected_path(p)}
    protected_unused = [p for p in unused if p in protected_set]
    cleanup_candidates = [p for p in unused if p not in protected_set]

    needs_review = []
    for m in missing:
        needs_review.append(
            {
                "path": m.get("value", ""),
                "category": _categorize_media(m.get("value", "")),
                "confidence": "definite",
                "ref": f"{m.get('file', '')}:{m.get('line', '?')}",
                "reason": "Not found on disk",
            }
        )

    dynamic_risk = []
    for s in unresolved_skipped:
        val = s.get("value") or s.get("guessed") or ""
        reason = "Template / variable path"
        if s.get("kind") == "unresolved_placeholder":
            reason = "Unresolved Ren'Py image tag"
        dynamic_risk.append(
            {
                "path": val,
                "category": "dynamic",
                "confidence": "dynamic",
                "ref": f"{s.get('file', '')}:{s.get('line', '?')}",
                "reason": reason,
            }
        )

    used_items = []
    for path in referenced:
        key = _norm(path).lower()
        refs_for_path = direct_refs_by_path.get(key, []) + resolved_refs_by_path.get(
            key, []
        )
        reason = "Direct file reference"
        confidence = "definite"
        if refs_for_path and all(
            r.get("reason") == "Resolved from Ren'Py image tag" for r in refs_for_path
        ):
            reason = "Resolved from Ren'Py image tag"
            confidence = "resolved"
        elif refs_for_path and any(
            r.get("reason") == "Resolved from Ren'Py image tag" for r in refs_for_path
        ):
            reason = "Script reference + Ren'Py image tag"
        # Collect all unique script refs for the evidence panel
        all_refs = list({r.get("ref", "") for r in refs_for_path if r.get("ref", "")})
        used_items.append(
            {
                "path": path,
                "category": _categorize_media(path),
                "confidence": confidence,
                "ref": all_refs[0] if all_refs else "",
                "all_refs": all_refs[:10],
                "reason": reason,
            }
        )

    cleanup_items = [
        {
            "path": p,
            "category": _categorize_media(p),
            "confidence": "definite",
            "ref": "",
            "reason": "No script reference found",
        }
        for p in cleanup_candidates
    ]

    protected_items = [
        {
            "path": p,
            "category": _categorize_media(p),
            "confidence": "dynamic",
            "ref": "",
            "reason": _protection_reason(p),
        }
        for p in protected_unused
    ]

    # Rename-pair hints: suggest close on-disk matches for missing paths.
    rename_hints = []
    on_disk_by_name = {os.path.basename(p).lower(): p for p in on_disk}
    on_disk_names = list(on_disk_by_name.keys())
    for m in missing[:600]:
        miss_path = str(m.get("value", ""))
        miss_name = os.path.basename(miss_path).lower()
        if not miss_name:
            continue
        best = get_close_matches(miss_name, on_disk_names, n=1, cutoff=0.72)
        if not best:
            continue
        match_name = best[0]
        score = SequenceMatcher(None, miss_name, match_name).ratio()
        rename_hints.append(
            {
                "missing": miss_path,
                "suggested": on_disk_by_name.get(match_name, match_name),
                "score": round(score, 3),
            }
        )

    return {
        "summary": {
            "used": len(referenced),
            "referenced": len(referenced),
            "unused": len(unused),
            "missing": len(missing),
            "protected": len(protected_set),
            "dynamic_risk": len(dynamic_risk),
            "safe_cleanup": len(cleanup_candidates),
            "total_on_disk": len(on_disk),
            "total_refs": len(refs) + len(resolved_unresolved_placeholders),
        },
        "tiers": {
            "used": used_items,
            "protected": protected_items,
            "cleanup_candidates": cleanup_items,
            "needs_review": needs_review,
            "dynamic_risk": dynamic_risk,
        },
        "rename_hints": rename_hints,
    }


# ---- Entrypoint from CLI -----------------------------------------------------


def run(
    command: Optional[Literal["missing", "unused", "referenced"]] = None,
    project: str = ".",
    assets: str = "game",
    ext: Optional[str] = None,
    as_json: bool = False,
    fail_on_unused: bool = False,
    ignore: Optional[list[str]] = None,
    export_csv: Optional[str] = None,  # v0.7.29: CSV export support
    bqf_media: bool = False,  # WS-B1: Enable BQF policy enforcement
    policy_mode: str = "off",  # WS-B1: BQF enforcement mode
    policy_config: Optional[str] = None,  # WS-B1: BQF policy configuration
    engine: Optional[str] = None,  # WS-C1: Engine override
    remote_debug: bool = False,  # WS-C1: Display remote/engine context
    out: Optional[str] = None,  # HTML output path (via wrapper/dispatcher)
    html: bool = False,  # HTML artifact request (handled in parser wrapper)
    open_browser: bool = False,  # Browser launch request (handled in parser wrapper)
    rule_dry_run: Optional[str] = None,  # JSON string of rule to dry-run validate
    args=None,  # For accessing emit settings
) -> int:
    import os
    import re

    # WS-C1: Display remote/engine context if debug enabled
    if remote_debug:
        try:
            from branchpy.core.engine_resolver import EngineResolver
            from branchpy.core.remote_context import RemoteContext

            remote_ctx = RemoteContext.detect()
            print(f"[Remote Context] Type: {remote_ctx.type.value}")
            print(f"[Remote Context] Is Remote: {remote_ctx.is_remote}")
            print(f"[Remote Context] Is CI: {remote_ctx.is_ci}")
            print(f"[Remote Context] Session: {remote_ctx.session_id}")

            engine_ctx = EngineResolver().detect()
            print(f"[Engine Detection] Type: {engine_ctx.engine_type.value}")
            print(f"[Engine Detection] Confidence: {engine_ctx.confidence:.2f}")
            if engine_ctx.version:
                print(f"[Engine Detection] Version: {engine_ctx.version}")
            print()
        except Exception as e:
            print(f"[WS-C1] Context detection error: {e}\n")

    # assets relative to project
    if assets and not os.path.isabs(assets):
        assets = os.path.join(project, assets)

    # normalize --ext → list[str] or None
    exts_list: Optional[list[str]] = None
    if ext:
        parts = [
            p.strip().lstrip(".").lower() for p in re.split(r"[,\s]+", ext) if p.strip()
        ]
        exts_list = parts or None

    # Determine if we should emit events
    emit = should_emit_from_args(args) if args else True

    if command == "missing":
        return run_missing(
            project=project,
            assets_root=assets,
            as_json=as_json,
            ignore=ignore,
            emit=emit,
            export_csv=export_csv,
            bqf_media=bqf_media,
            policy_mode=policy_mode,
            policy_config=policy_config,
        )

    if command == "unused":
        return run_unused(
            project=project,
            assets_root=assets,
            exts=exts_list,
            as_json=as_json,
            fail_on_unused=fail_on_unused,
            ignore=ignore,
            emit=emit,
        )

    if command == "referenced":
        return run_referenced(
            project=project,
            assets_root=assets,
            exts=exts_list,
            as_json=as_json,
            ignore=ignore,
            emit=emit,
        )

    if command == "catalog":
        return run_catalog(
            project=project,
            assets_root=assets,
            exts=exts_list,
            as_json=as_json,
            ignore=ignore,
        )

    # Rule dry-run: validate a proposed rule without writing it
    if rule_dry_run is not None or command == "rule-dry-run":
        import json as _json
        raw = rule_dry_run or ""
        try:
            rule_obj = _json.loads(raw) if raw.strip() else {}
        except Exception:
            rule_obj = {}
        return run_rule_dry_run(
            project=project,
            assets_root=assets,
            rule=rule_obj,
            as_json=True,
            ignore=ignore,
        )

    safe_print(
        "branchpy media: specify a subcommand (e.g., --missing, --unused, or --referenced)"
    )
    return 1


def add_parser(subparsers):
    """Register the media command with the CLI parser."""
    from branchpy.cli_help import HelpFmt, fmt_examples

    media_p = subparsers.add_parser(
        "media",
        help="Scan project for missing or unused media files.",
        description="Validate media file references and detect unused assets.",
        epilog=fmt_examples(
            "branchpy --project /path/to/project media --missing",
            "branchpy --project /path/to/project media --unused",
            "branchpy --project /path/to/project media --missing --export-csv missing.csv",
        ),
        formatter_class=HelpFmt,
    )

    def media_handler(args):
        html_requested = getattr(args, "html", False) or getattr(
            args, "open_browser", False
        )

        # --rule-dry-run: stand-alone validation, bypasses all other modes
        if getattr(args, "rule_dry_run", None) is not None:
            assets_path = getattr(args, "assets", "game")
            if assets_path and not os.path.isabs(assets_path):
                assets_path = os.path.join(args.project, assets_path)
            # --from-toml: audit all existing rules instead of validating one
            if getattr(args, "from_toml", False):
                return run_rule_dry_run_from_toml(
                    project=args.project,
                    assets_root=assets_path,
                    as_json=True,
                    ignore=getattr(args, "ignore", None),
                )
            import json as _jh
            try:
                rule_obj = _jh.loads(args.rule_dry_run) if args.rule_dry_run.strip() else {}
            except Exception:
                rule_obj = {}
            return run_rule_dry_run(
                project=args.project,
                assets_root=assets_path,
                rule=rule_obj,
                as_json=True,
                ignore=getattr(args, "ignore", None),
            )

        # --catalog: stand-alone, bypasses all other modes and HTML report
        if getattr(args, "catalog", False):
            assets_path = getattr(args, "assets", "game")
            if assets_path and not os.path.isabs(assets_path):
                assets_path = os.path.join(args.project, assets_path)
            exts_list_c = None
            if getattr(args, "ext", None):
                exts_list_c = [
                    p.strip().lstrip(".").lower()
                    for p in re.split(r"[,\s]+", args.ext)
                    if p.strip()
                ]
            return run_catalog(
                project=args.project,
                assets_root=assets_path,
                exts=exts_list_c,
                as_json=getattr(args, "json", False),
                ignore=getattr(args, "ignore", None),
            )

        # Browser mode defaults to triage/all when no explicit mode is given.
        if (
            html_requested
            and not getattr(args, "scan_all", False)
            and not getattr(args, "missing", False)
            and not getattr(args, "unused", False)
            and not getattr(args, "referenced", False)
        ):
            args.scan_all = True

        # Handle --all flag
        if getattr(args, "scan_all", False):
            # For JSON output, collect results and combine them
            if args.json:
                import json
                from io import StringIO

                results = {}
                exit_codes = []

                # Capture output for each mode
                for mode in ["missing", "unused", "referenced"]:
                    old_stdout = sys.stdout
                    sys.stdout = StringIO()

                    try:
                        exit_code = run(
                            command=mode,
                            project=args.project,
                            assets=args.assets,
                            ext=args.ext,
                            as_json=True,
                            fail_on_unused=args.fail_on_unused,
                            ignore=args.ignore,
                            export_csv=None,
                            bqf_media=getattr(args, "bqf_media", False),
                            policy_mode=getattr(args, "policy_mode", "off"),
                            policy_config=getattr(args, "policy_config", None),
                            engine=getattr(args, "engine", None),
                            remote_debug=getattr(args, "remote_debug", False),
                            args=args,
                        )
                        output = sys.stdout.getvalue()
                        if output.strip():
                            results[mode] = json.loads(output)
                        exit_codes.append(exit_code)
                    finally:
                        sys.stdout = old_stdout

                # Print combined JSON
                print(json.dumps(results, indent=2))
                result_code = max(exit_codes)
            else:
                # Non-JSON: run each mode normally
                exit_codes = []
                for mode in ["missing", "unused", "referenced"]:
                    exit_codes.append(
                        run(
                            command=mode,
                            project=args.project,
                            assets=args.assets,
                            ext=args.ext,
                            as_json=False,
                            fail_on_unused=args.fail_on_unused,
                            ignore=args.ignore,
                            export_csv=None,
                            bqf_media=getattr(args, "bqf_media", False),
                            policy_mode=getattr(args, "policy_mode", "off"),
                            policy_config=getattr(args, "policy_config", None),
                            engine=getattr(args, "engine", None),
                            remote_debug=getattr(args, "remote_debug", False),
                            args=args,
                        )
                    )
                result_code = max(exit_codes)

            if html_requested:
                try:
                    from pathlib import Path

                    from branchpy.cli.html_report import (
                        announce_html_report,
                        generate_media_html,
                    )
                    from branchpy.cli.html_report import (
                        open_in_browser as _open_browser,
                    )
                    from branchpy.cli.html_report import resolve_media_html_path

                    # assets relative to project
                    assets_root = args.assets
                    if assets_root and not os.path.isabs(assets_root):
                        assets_root = os.path.join(args.project, assets_root)

                    exts_list = None
                    if args.ext:
                        exts_list = [
                            p.strip().lstrip(".").lower()
                            for p in re.split(r"[,\s]+", args.ext)
                            if p.strip()
                        ]

                    payload = _build_media_browser_payload(
                        project=args.project,
                        assets_root=assets_root,
                        exts=exts_list,
                        ignore=args.ignore,
                    )
                    project_root = Path(args.project).resolve()
                    html_path = generate_media_html(
                        payload,
                        project_root,
                        resolve_media_html_path(project_root, args.out),
                    )
                    announce_html_report("media", html_path)
                    if getattr(args, "open_browser", False):
                        print(
                            "[bpy] Opening interactive media report in browser...",
                            file=sys.stderr,
                        )
                        _open_browser(html_path)
                except Exception as _html_err:
                    print(
                        f"[bpy] Warning: Media HTML generation failed: {_html_err}",
                        file=sys.stderr,
                    )

            return result_code

        # Single mode
        command = (
            "missing"
            if args.missing
            else (
                "unused" if args.unused else ("referenced" if args.referenced else None)
            )
        )
        result_code = run(
            command=command,
            project=args.project,
            assets=args.assets,
            ext=args.ext,
            as_json=args.json,
            fail_on_unused=args.fail_on_unused,
            ignore=args.ignore,
            export_csv=args.export_csv,
            bqf_media=getattr(args, "bqf_media", False),
            policy_mode=getattr(args, "policy_mode", "off"),
            policy_config=getattr(args, "policy_config", None),
            engine=getattr(args, "engine", None),
            remote_debug=getattr(args, "remote_debug", False),
            args=args,
        )

        if html_requested:
            try:
                from pathlib import Path

                from branchpy.cli.html_report import (
                    announce_html_report,
                    generate_media_html,
                )
                from branchpy.cli.html_report import open_in_browser as _open_browser
                from branchpy.cli.html_report import resolve_media_html_path

                assets_root = args.assets
                if assets_root and not os.path.isabs(assets_root):
                    assets_root = os.path.join(args.project, assets_root)

                exts_list = None
                if args.ext:
                    exts_list = [
                        p.strip().lstrip(".").lower()
                        for p in re.split(r"[,\s]+", args.ext)
                        if p.strip()
                    ]

                payload = _build_media_browser_payload(
                    project=args.project,
                    assets_root=assets_root,
                    exts=exts_list,
                    ignore=args.ignore,
                )
                project_root = Path(args.project).resolve()
                html_path = generate_media_html(
                    payload,
                    project_root,
                    resolve_media_html_path(project_root, args.out),
                )
                announce_html_report("media", html_path)
                if getattr(args, "open_browser", False):
                    print(
                        "[bpy] Opening interactive media report in browser...",
                        file=sys.stderr,
                    )
                    _open_browser(html_path)
            except Exception as _html_err:
                print(
                    f"[bpy] Warning: Media HTML generation failed: {_html_err}",
                    file=sys.stderr,
                )

        return result_code

    media_p.set_defaults(handler=media_handler)

    # Subcommand flags
    media_p.add_argument(
        "--catalog",
        action="store_true",
        help="Build an Asset Catalog from Ren'Py image and layeredimage declarations.",
    )
    media_p.add_argument(
        "--missing",
        action="store_true",
        help="Scan for missing media files referenced by scripts",
    )
    media_p.add_argument(
        "--unused",
        action="store_true",
        help="Scan for unused media files in the asset directory",
    )
    media_p.add_argument(
        "--referenced",
        action="store_true",
        help="Scan for media files that are both on disk and referenced by scripts",
    )
    media_p.add_argument(
        "--all",
        dest="scan_all",
        action="store_true",
        help="Run all scan modes (missing, unused, referenced)",
    )
    media_p.add_argument(
        "--rule-dry-run",
        dest="rule_dry_run",
        metavar="RULE_JSON",
        nargs="?",
        const="{}",
        default=None,
        help="Validate a proposed rule (JSON) without writing it. Pass --from-toml to audit all existing rules.",
    )
    media_p.add_argument(
        "--from-toml",
        dest="from_toml",
        action="store_true",
        default=False,
        help="With --rule-dry-run: audit all existing rules in .branchpy.toml instead of a single rule JSON.",
    )

    # Options
    media_p.add_argument(
        "--assets",
        default="game",
        help="Assets directory relative to project (default: game)",
    )
    media_p.add_argument(
        "--ext",
        type=str,
        default="",
        help="Comma-separated list of file extensions to scan (e.g., png,jpg,ogg)",
    )
    media_p.add_argument(
        "--json", action="store_true", help="Output results in JSON format"
    )
    media_p.add_argument(
        "--html",
        action="store_true",
        help="Generate a review-focused HTML media report artifact.",
    )
    media_p.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Generate and open the media report in the browser (implies --html).",
    )
    media_p.add_argument(
        "--out",
        type=str,
        default="",
        metavar="PATH",
        help="Output path for HTML (used when --html or --open is set).",
    )
    media_p.add_argument(
        "--fail-on-unused",
        action="store_true",
        help="Exit with code 2 if unused files are found",
    )
    media_p.add_argument(
        "--ignore",
        type=str,
        action="append",
        help="Glob patterns to ignore (can be specified multiple times)",
    )
    media_p.add_argument(
        "--export-csv",
        type=str,
        default=None,
        help="Export missing files to CSV (missing mode only)",
    )

    # BQF-Media integration (WS-B1)
    media_p.add_argument(
        "--bqf-media",
        dest="bqf_media",
        action="store_true",
        default=False,
        help="Enable BQF policy enforcement for media analysis",
    )
    media_p.add_argument(
        "--policy-mode",
        choices=["off", "warn", "strict", "ci"],
        default="off",
        help="BQF enforcement mode: off (disabled), warn (log only), strict (fail on any violation), ci (fail on errors only)",
    )
    media_p.add_argument(
        "--policy-config",
        type=str,
        metavar="PATH",
        help="Path to BQF policy configuration file (YAML/TOML)",
    )

    # WS-C1: Remote context and engine detection
    media_p.add_argument(
        "--engine",
        choices=["renpy", "unity", "godot", "generic"],
        help="Override engine detection (WS-C1)",
    )
    media_p.add_argument(
        "--remote-debug",
        dest="remote_debug",
        action="store_true",
        help="Display remote environment and engine context (WS-C1)",
    )
