# branchpy/commands/stats_cmd.py
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from ..report_writer import (
    create_stats_report,
    should_emit_from_args,
    write_report_and_emit,
)

# Logging
try:
    from ..core.logging import log
except ImportError:
    # Fallback for simpler logging
    class _FallbackLog:
        def debug(self, msg, *args, **kwargs):
            pass

        def info(self, msg, *args, **kwargs):
            pass

    log = _FallbackLog()

# SAE (optional) – programmatic CFG builder
try:
    from branchpy.analysis.sae.cfg_builder import StatementCFGBuilder
    from branchpy.analysis.sae.indexer import Indexer

    _HAS_SAE = True
except Exception:
    _HAS_SAE = False

# Module-level file content cache — populated lazily during a stats run.
# Safe as module-level state because the stats CLI is always invoked as an
# isolated subprocess; there is no shared state between invocations.
_FILE_LINES_CACHE: Dict[str, List[str]] = {}


def _cached_file_lines(path: str) -> List[str]:
    """Return lines (without trailing newlines) of a file, with caching."""
    if path not in _FILE_LINES_CACHE:
        _FILE_LINES_CACHE[path] = _read_text(path).splitlines()
    return _FILE_LINES_CACHE[path]


class CFGSource:
    """CFG data source options for Stats 2.0"""

    AUTO = "auto"
    SAE = "sae"  # programmatic build (preferred)
    JSON = "json"  # --deep --export-cfg artifact
    DOT = "dot"  # --debug-cfg output
    NONE = "none"  # legacy counts only


ASSIGN_RE = re.compile(
    r"^\s*\$\s*([A-Za-z_]\w*)\s*([+\-*/]?=)\s*(.+?)\s*$", re.MULTILINE
)

# Patterns for detecting variable usage (reads)
# Matches variables in expressions, conditions, interpolations, etc.
USAGE_PATTERNS = [
    re.compile(r"\bif\s+([A-Za-z_]\w*)\b"),  # if variable
    re.compile(r"\b([A-Za-z_]\w*)\s*[<>=!]+"),  # variable in comparison
    re.compile(r"[<>=!]+\s*([A-Za-z_]\w*)\b"),  # variable after comparison
    re.compile(r"\[([A-Za-z_]\w*)\]"),  # [variable] interpolation
    re.compile(r"\$\s*([A-Za-z_]\w*)\b(?!\s*[+\-*/]?=)"),  # $variable (not assignment)
    re.compile(r"\{([A-Za-z_]\w*)\}"),  # {variable} in text
    re.compile(r"menu\s+\(([A-Za-z_]\w*)\)"),  # menu(variable)
    re.compile(r"show\s+expression\s+([A-Za-z_]\w*)\b"),  # show expression variable
]


def _read_text(path: str) -> str:
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except UnicodeDecodeError:
        with open(path, encoding="latin-1") as f:
            return f.read()


def _infer_type(rhs: str, op: str) -> str:
    # Crude but useful: number / bool / string / list / dict / unknown
    s = rhs.strip()
    if op in ("+=", "-=", "*=", "/="):
        return "number"
    if s.lower() in ("true", "false"):
        return "bool"
    if (s.startswith('"') and s.endswith('"')) or (
        s.startswith("'") and s.endswith("'")
    ):
        return "string"
    if re.fullmatch(r"[-+]?\d+(\.\d+)?", s):
        return "number"
    if s.startswith("[") and s.endswith("]"):
        return "list"
    if s.startswith("{") and s.endswith("}"):
        return "dict"
    return "unknown"


def _extract_numeric_value(rhs: str) -> float | None:
    """Try to extract a numeric value from an assignment RHS"""
    s = rhs.strip()
    try:
        return float(s)
    except ValueError:
        return None


def _extract_code_snippet(file_path: str, line_num: int, context_lines: int = 2) -> str:
    """Extract code snippet around a specific line with context.

    Args:
        file_path: Path to the source file
        line_num: 1-based line number (target line)
        context_lines: Number of lines to include before and after

    Returns:
        String containing the code snippet with context
    """
    try:
        lines = _cached_file_lines(file_path)

        # Calculate range (1-based to 0-based conversion)
        start = max(0, line_num - context_lines - 1)
        end = min(len(lines), line_num + context_lines)

        # Extract snippet with line numbers
        snippet_lines = []
        for i in range(start, end):
            line_number = i + 1
            prefix = "→ " if line_number == line_num else "  "
            snippet_lines.append(f"{prefix}{line_number:4d} | {lines[i]}")

        return "\n".join(snippet_lines)
    except Exception as e:
        log.debug(f"Failed to extract snippet from {file_path}:{line_num}: {e}")
        return f"[Could not extract snippet: {e}]"


def _scan_assignments(project_root: str) -> List[Tuple[str, str, str, str, int]]:
    """Return list of tuples: (file, var, op, rhs_type, line_number)"""
    found: List[Tuple[str, str, str, str, int]] = []
    for r, _, files in os.walk(project_root):
        for fn in files:
            if not fn.endswith(".rpy"):
                continue
            full = os.path.join(r, fn)
            text = _read_text(full)
            lines = text.split("\n")
            for line_num, line in enumerate(lines, start=1):
                for m in ASSIGN_RE.finditer(line):
                    var, op, rhs = m.group(1), m.group(2), m.group(3)
                    t = _infer_type(rhs, op)
                    found.append((full, var, op, t, line_num))
    return found


def _scan_assignments_and_usage(
    project_root: str,
) -> Tuple[List[Tuple[str, str, str, str, int]], Dict[str, int]]:
    """Single-pass scan: collect both assignments and usage counts from every .rpy file.
    Replaces calling _scan_assignments + _count_variable_usage separately (halves I/O).
    """
    found: List[Tuple[str, str, str, str, int]] = []
    usage_counts: Dict[str, int] = {}

    # First pass — collect assignments
    file_lines: List[Tuple[str, List[str]]] = []
    for r, dirs, files in os.walk(project_root):
        dirs[:] = [
            d
            for d in dirs
            if d
            not in {
                "node_modules",
                ".git",
                ".branchpy",
                "__pycache__",
                "saves",
                "cache",
                "logs",
                "tmp",
            }
        ]
        for fn in files:
            if not fn.endswith(".rpy"):
                continue
            full = os.path.join(r, fn)
            text = _read_text(full)
            lines = text.split("\n")
            file_lines.append((full, lines))
            for line_num, line in enumerate(lines, start=1):
                for m in ASSIGN_RE.finditer(line):
                    var, op, rhs = m.group(1), m.group(2), m.group(3)
                    t = _infer_type(rhs, op)
                    found.append((full, var, op, t, line_num))

    # Build known-vars set from what we just found
    known_vars: Set[str] = {row[1] for row in found}

    # Second sub-pass over cached lines — no file I/O, just regex
    for full, lines in file_lines:
        for line_num, line in enumerate(lines, start=1):
            if ASSIGN_RE.match(line):
                continue
            for pattern in USAGE_PATTERNS:
                for match in pattern.finditer(line):
                    var_name = match.group(1)
                    if var_name in known_vars:
                        usage_counts[var_name] = usage_counts.get(var_name, 0) + 1

    return found, usage_counts


def _count_variable_usage(project_root: str, known_vars: Set[str]) -> Dict[str, int]:
    """Count reads of known variables in expressions, conditions, etc.
    Returns: dict mapping var_name -> read count (only vars with >=1 read are included).
    Avoids allocating per-location dicts — the caller only needs counts."""
    counts: Dict[str, int] = {}

    for r, _, files in os.walk(project_root):
        for fn in files:
            if not fn.endswith(".rpy"):
                continue
            full = os.path.join(r, fn)
            text = _read_text(full)
            lines = text.split("\n")

            for line_num, line in enumerate(lines, start=1):
                # Skip assignment lines (we already tracked those)
                if ASSIGN_RE.match(line):
                    continue

                # Check each usage pattern
                for pattern in USAGE_PATTERNS:
                    for match in pattern.finditer(line):
                        var_name = match.group(1)
                        if var_name in known_vars:
                            counts[var_name] = counts.get(var_name, 0) + 1

    return counts


def run(args) -> int:
    """
    Main entry point for stats command from CLI.
    Args is a Namespace object with: project, out, format, cfg_source
    """
    from pathlib import Path

    start_time = time.time()

    # Extract values from args
    project = args.project
    requested_out = getattr(args, "out", None)
    html_requested = getattr(args, "html", False) or getattr(
        args, "open_browser", False
    )
    out = requested_out
    html_out_path = None
    if html_requested and requested_out:
        candidate = Path(requested_out)
        if candidate.suffix.lower() in {".html", ".htm"}:
            html_out_path = candidate
            out = None
    # JSON output if: --json flag OR --format json OR --out specified
    as_json = (
        getattr(args, "json", False)
        or getattr(args, "format", "text") == "json"
        or out is not None
    )
    detailed = getattr(args, "detailed", False)

    # Phase 1.1: Load full CFG (nodes/edges), not just counts
    cfg_graph = None
    _sae_index = None  # reused by Phase 1.2 to avoid double build_index()
    cfg_source = getattr(args, "cfg_source", CFGSource.AUTO)
    project_root = Path(project).resolve()

    # Reset the per-process file cache for this run
    _FILE_LINES_CACHE.clear()

    # Set JSON-only mode to suppress progress output
    import os

    if as_json:
        os.environ["BPY_JSON_MODE"] = "1"

    # Pre-scan: count .rpy files and total size using stat() only (no file reads → fast).
    # Printed before any heavy work so CLI users see immediate feedback on large projects.
    if not as_json:
        total_bytes = 0
        rpy_count = 0
        for r, dirs, files in os.walk(project_root):
            dirs[:] = [
                d
                for d in dirs
                if d
                not in {
                    "node_modules",
                    ".git",
                    ".branchpy",
                    "__pycache__",
                    "saves",
                    "cache",
                    "logs",
                    "tmp",
                }
            ]
            for fn in files:
                if fn.endswith(".rpy"):
                    try:
                        total_bytes += os.path.getsize(os.path.join(r, fn))
                        rpy_count += 1
                    except OSError:
                        pass
        size_kb = total_bytes / 1024
        size_label = (
            f"{size_kb / 1024:.1f} MB" if size_kb >= 1024 else f"{size_kb:.0f} KB"
        )
        print(
            f"[Stats] Project: {rpy_count} .rpy file(s), {size_label} — starting analysis…"
        )

    _t_phase = time.perf_counter()
    if cfg_source in (CFGSource.AUTO, CFGSource.SAE):
        if _HAS_SAE:
            cfg_graph, _sae_index = _load_sae_cfg(project_root)
            if not as_json:
                print(
                    f"[Stats][timing] Phase 1.1 (load CFG): {time.perf_counter() - _t_phase:.2f}s",
                    flush=True,
                )
            if cfg_graph:
                log.debug("Stats: Using SAE StatementCFG (programmatic).")
                cfg_source = CFGSource.SAE
            elif cfg_source == CFGSource.SAE:
                print(
                    "[Stats] ERROR: SAE CFG build failed but --cfg-source=sae was specified"
                )
                return 1
        elif cfg_source == CFGSource.SAE:
            print("[Stats] ERROR: SAE not available but --cfg-source=sae was specified")
            return 1

    if cfg_graph is None and cfg_source in (CFGSource.AUTO, CFGSource.DOT):
        cfg_graph = _try_parse_dot_graph(project_root)
        if cfg_graph:
            log.debug("Stats: Using DOT graph.")
            cfg_source = CFGSource.DOT

    # Note: CFGSource.JSON / exported flowgraph.json is not used.
    # That path (.branchpy/analyze/flowgraph.json) is never written by any current command.

    # Log CFG status (suppress in JSON mode)
    if cfg_graph:
        try:
            # Handle both SAE CFG (nodes/edges are dicts/lists) and adapters (nodes/edges are methods)
            nodes = cfg_graph.nodes() if callable(cfg_graph.nodes) else cfg_graph.nodes
            edges = cfg_graph.edges() if callable(cfg_graph.edges) else cfg_graph.edges
            node_count = len(list(nodes)) if hasattr(nodes, "__iter__") else len(nodes)
            edge_count = len(list(edges)) if hasattr(edges, "__iter__") else len(edges)
            if not as_json:
                print(
                    f"[Stats] Loaded CFG from {cfg_source}: {node_count} nodes, {edge_count} edges"
                )
        except Exception as e:
            log.debug(f"CFG loaded but couldn't count nodes/edges: {e}")
    else:
        if cfg_source == CFGSource.NONE:
            if not as_json:
                print("[Stats] CFG disabled (--cfg-source=none)")
        else:
            if not as_json:
                print("[Stats] No CFG available (falling back to legacy mode)")
        cfg_source = CFGSource.NONE

    # Phase 1.2: Extract variable assignments from CFG if available
    cfg_assignments = {}
    variable_flow_graph = {}
    if cfg_graph is not None and _HAS_SAE:
        try:
            from branchpy.analysis.variable_flow import (
                build_variable_flow_graph,
                extract_assignments_from_cfg,
            )

            _t12 = time.perf_counter()
            # Reuse the index built in Phase 1.1 — avoids a redundant build_index() call
            index = _sae_index
            cfg_assignments = extract_assignments_from_cfg(cfg_graph, index=index)
            total_cfg_assigns = sum(
                len(assigns) for assigns in cfg_assignments.values()
            )
            if not as_json:
                print(
                    f"[Stats] Phase 1.2: Extracted {total_cfg_assigns} assignments from CFG across {len(cfg_assignments)} labels"
                )
                print(
                    f"[Stats][timing] Phase 1.2 (extract assignments): {time.perf_counter() - _t12:.2f}s",
                    flush=True,
                )

            # Phase 1.3: Build variable flow graph
            if cfg_assignments:
                _t13 = time.perf_counter()
                variable_flow_graph = build_variable_flow_graph(
                    cfg_assignments, cfg_graph
                )
                if not as_json:
                    print(
                        f"[Stats] Phase 1.3: Built flow graph for {len(variable_flow_graph)} variables"
                    )
                    print(
                        f"[Stats][timing] Phase 1.3 (build flow graph): {time.perf_counter() - _t13:.2f}s",
                        flush=True,
                    )
        except Exception as e:
            log.debug(f"Phase 1.2/1.3 extraction failed: {e}")
            import traceback

            log.debug(traceback.format_exc())

    _t_scan = time.perf_counter()
    assigns, actual_usage_counts = _scan_assignments_and_usage(project)
    types: Dict[str, set] = {}
    locations: Dict[str, List[Dict]] = {}

    for file, var, op, t, line_num in assigns:
        types.setdefault(var, set()).add(t)
        locations.setdefault(var, []).append(
            {"file": file, "line": line_num, "operator": op, "type": t}
        )
    if not as_json:
        print(
            f"[Stats][timing] scan+usage (fused): {time.perf_counter() - _t_scan:.2f}s  ({len(types)} vars, {sum(actual_usage_counts.values())} reads)",
            flush=True,
        )
        print(
            f"[Stats] Found {sum(actual_usage_counts.values())} variable reads across {len(actual_usage_counts)} variables"
        )

    issues: List[Dict] = []

    # === Enhanced Analysis ===
    # Track usage patterns
    usage_stats: Dict[str, Dict[str, int]] = (
        {}
    )  # var -> {writes, modifies, reads, total}
    for var, var_locations in locations.items():
        writes = sum(1 for loc in var_locations if loc["operator"] == "=")
        modifies = sum(
            1 for loc in var_locations if loc["operator"] in ("+=", "-=", "*=", "/=")
        )
        reads = actual_usage_counts.get(var, 0)
        usage_stats[var] = {
            "writes": writes,
            "modifies": modifies,
            "reads": reads,
            "total": len(var_locations) + reads,  # assignments + reads
        }

    # Detect potentially unused variables (only assigned once, never read)
    potentially_unused = []
    for var, stats in usage_stats.items():
        if stats["writes"] == 1 and stats["reads"] == 0 and stats["modifies"] == 0:
            potentially_unused.append(var)

    # Detect numeric stat variables and their value ranges (not just "trust")
    # Pattern-based detection for common stat variable patterns
    STAT_PATTERNS = [
        "trust",
        "affection",
        "relationship",
        "score",
        "points",
        "level",
        "boldness",
        "obedience",
        "loyalty",
        "friendship",
        "love",
        "respect",
    ]

    # Ren'Py built-in variables that should be ignored
    RENPY_BUILTINS = {
        # UI/Menu variables
        "menu",
        "style",
        "choices",
        "selected",
        "nvl_mode",
        "quick_menu",
        # System variables
        "config",
        "preferences",
        "persistent",
        "save_name",
        "mouse_visible",
        # Screen/Display variables
        "renpy",
        "_window",
        "_window_hide",
        "_window_auto",
        "show_window",
        # Audio variables
        "audio",
        "voice",
        "sound",
        "music",
        # Special variables
        "_skipping",
        "_dismiss_pause",
        "_rollback",
        "_reload",
        # Common namespace
        "store",
        "default",
        "define",
    }

    numeric_vars = {}  # All pure numeric variables
    non_numeric_vars = {}  # String, list, dict variables
    unknown_type_vars = {}  # Variables with only "unknown" type
    system_vars = {}  # Ren'Py built-ins that were filtered out

    for var, var_types in types.items():
        # Track Ren'Py built-in variables separately
        if var in RENPY_BUILTINS:
            system_vars[var] = {
                "locations": len(locations.get(var, [])),
                "reads": actual_usage_counts.get(var, 0),
                "types": sorted(types[var]),
                "reason": "Ren'Py system variable",
            }
            continue

        var_locations = locations.get(var, [])
        type_set = set(var_types) - {"unknown"}

        # Extract numeric values and track min/max
        numeric_values = []
        string_values = set()

        for loc in var_locations:
            if loc["operator"] == "=" and loc["type"] == "number":
                try:
                    lines = _cached_file_lines(loc["file"])
                    if 0 < loc["line"] <= len(lines):
                        line = lines[loc["line"] - 1]
                        match = re.search(r"=\s*([-+]?\d+(?:\.\d+)?)", line)
                        if match:
                            numeric_values.append(float(match.group(1)))
                except Exception:
                    pass
            elif loc["operator"] == "=" and loc["type"] == "string":
                try:
                    lines = _cached_file_lines(loc["file"])
                    if 0 < loc["line"] <= len(lines):
                        line = lines[loc["line"] - 1]
                        match = re.search(r'=\s*["\']([^"\']+)["\']', line)
                        if match:
                            string_values.add(match.group(1))
                except Exception:
                    pass

        # Categorize variables by their primary type
        if type_set == {"number"}:
            numeric_vars[var] = {
                "locations": len(var_locations),
                "reads": actual_usage_counts.get(var, 0),
                "types": sorted(types[var]),
                "min_value": min(numeric_values) if numeric_values else None,
                "max_value": max(numeric_values) if numeric_values else None,
                "value_count": len(numeric_values),
                "is_stat": any(pattern in var.lower() for pattern in STAT_PATTERNS),
            }
        elif not type_set:  # Only "unknown" type - we can't determine what it is
            unknown_type_vars[var] = {
                "locations": len(var_locations),
                "reads": actual_usage_counts.get(var, 0),
                "types": sorted(types[var]),
            }
        elif type_set and not type_set.issubset(
            {"bool"}
        ):  # Non-boolean, non-pure-numeric
            non_numeric_vars[var] = {
                "locations": len(var_locations),
                "reads": actual_usage_counts.get(var, 0),
                "types": sorted(types[var]),
                "string_values": sorted(string_values) if string_values else None,
                "value_count": len(string_values),
            }

    # Detect flag variables
    flag_vars = {}
    for var in types.keys():
        if (
            var.lower().startswith("is_")
            or var.lower().endswith("_flag")
            or var.lower().startswith("has_")
        ):
            flag_vars[var] = {
                "locations": len(locations[var]),
                "reads": actual_usage_counts.get(var, 0),
                "types": sorted(types[var]),
            }

    # Naming convention analysis
    naming_issues = []
    for var in types.keys():
        # Check for camelCase (should be snake_case in Python/Ren'Py)
        if re.match(r"^[a-z]+[A-Z]", var):
            naming_issues.append(
                {
                    "var": var,
                    "issue": "Uses camelCase instead of snake_case",
                    "suggestion": re.sub(r"([A-Z])", r"_\1", var).lower(),
                }
            )
        # Check for ALL_CAPS variables (usually constants, but check if modified)
        if var.isupper() and len(var) > 1 and usage_stats[var]["modifies"] > 0:
            naming_issues.append(
                {
                    "var": var,
                    "issue": "ALL_CAPS variable is being modified (constants shouldn't change)",
                    "suggestion": "Consider using lowercase if this is not a constant",
                }
            )

    # === Generate Suggestions ===
    suggestions = []

    # Suggest removing unused variables (with location info)
    if len(potentially_unused) > 0:
        # Get location info for each unused variable (with code snippets)
        unused_with_locations = []
        for var in potentially_unused:
            var_locs = locations.get(var, [])
            if var_locs:
                first_loc = var_locs[0]
                snippet = _extract_code_snippet(
                    first_loc["file"], first_loc["line"], context_lines=2
                )
                unused_with_locations.append(
                    {
                        "var": var,
                        "file": first_loc["file"],
                        "line": first_loc["line"],
                        "snippet": snippet,  # NEW: Code snippet with context
                    }
                )
            else:
                unused_with_locations.append({"var": var})

        suggestions.append(
            {
                "category": "cleanup",
                "priority": "medium",
                "title": f"Remove {len(potentially_unused)} unused variable(s)",
                "description": f"These variables are assigned once but never used: {', '.join(potentially_unused[:5])}{'...' if len(potentially_unused) > 5 else ''}",
                "action": "Consider removing these variables or verify they're used in expressions/conditions",
                "variables": unused_with_locations,  # NEW: With file/line info
            }
        )

    # Suggest fixing naming conventions (with location info and snippets)
    if len(naming_issues) > 0:
        naming_with_locations = []
        for issue in naming_issues:
            var = issue["var"]
            var_locs = locations.get(var, [])
            if var_locs:
                first_loc = var_locs[0]
                snippet = _extract_code_snippet(
                    first_loc["file"], first_loc["line"], context_lines=2
                )
                naming_with_locations.append(
                    {
                        "var": var,
                        "file": first_loc["file"],
                        "line": first_loc["line"],
                        "snippet": snippet,
                        "suggestion": issue.get(
                            "suggestion", ""
                        ),  # Include the suggested name
                    }
                )
            else:
                naming_with_locations.append({"var": var})

        affected_vars = [issue["var"] for issue in naming_issues]
        suggestions.append(
            {
                "category": "style",
                "priority": "low",
                "title": f"Fix {len(naming_issues)} naming convention issue(s)",
                "description": f"Variables with naming issues: {', '.join(affected_vars[:5])}{'...' if len(affected_vars) > 5 else ''}",
                "action": "Rename variables to use snake_case instead of camelCase",
                "variables": naming_with_locations,  # NEW: With file/line info
            }
        )

    # Suggest fixing type issues (with location info and snippets)
    mixed_type_vars = [
        var
        for var, tset in types.items()
        if len({tt for tt in tset if tt != "unknown"}) > 1
    ]
    if len(mixed_type_vars) > 0:
        mixed_with_locations = []
        for var in mixed_type_vars:
            var_locs = locations.get(var, [])
            if var_locs:
                first_loc = var_locs[0]
                snippet = _extract_code_snippet(
                    first_loc["file"], first_loc["line"], context_lines=2
                )
                # Get all types for this variable
                var_types = sorted(types.get(var, []))
                mixed_with_locations.append(
                    {
                        "var": var,
                        "file": first_loc["file"],
                        "line": first_loc["line"],
                        "snippet": snippet,
                        "types": var_types,  # Include detected types
                    }
                )
            else:
                mixed_with_locations.append({"var": var})

        suggestions.append(
            {
                "category": "bugs",
                "priority": "high",
                "title": f"{len(mixed_type_vars)} variable(s) with mixed types",
                "description": f"These variables are assigned different types: {', '.join(mixed_type_vars[:5])}{'...' if len(mixed_type_vars) > 5 else ''}",
                "action": "Ensure each variable uses a consistent type throughout the code",
                "variables": mixed_with_locations,  # NEW: With file/line info
            }
        )

    # Suggest stat variable validation (numeric stats that are never read, with snippets)
    stat_vars_unused = [
        var
        for var, data in numeric_vars.items()
        if data["is_stat"] and data["reads"] == 0
    ]
    if len(stat_vars_unused) > 0:
        stat_unused_with_locations = []
        for var in stat_vars_unused:
            var_locs = locations.get(var, [])
            if var_locs:
                first_loc = var_locs[0]
                snippet = _extract_code_snippet(
                    first_loc["file"], first_loc["line"], context_lines=2
                )
                # Get range info if available
                var_data = numeric_vars.get(var, {})
                stat_unused_with_locations.append(
                    {
                        "var": var,
                        "file": first_loc["file"],
                        "line": first_loc["line"],
                        "snippet": snippet,
                        "min_value": var_data.get("min_value"),
                        "max_value": var_data.get("max_value"),
                    }
                )
            else:
                stat_unused_with_locations.append({"var": var})

        suggestions.append(
            {
                "category": "optimization",
                "priority": "medium",
                "title": f"{len(stat_vars_unused)} stat variable(s) never used",
                "description": f"Stat variables that are tracked but never read: {', '.join(stat_vars_unused[:3])}",
                "action": "Either use these variables in conditions/displays or remove them",
                "variables": stat_unused_with_locations,  # NEW: With file/line info
            }
        )

    # === END NEW ===

    for var, tset in types.items():
        var_locations = locations.get(var, [])
        # trust-like should be numeric only
        if "trust" in var.lower():
            if any(tt not in ("number", "unknown") for tt in tset):
                issues.append(
                    {
                        "var": var,
                        "issue": "trust-not-numeric",
                        "types": sorted(tset),
                        "where": var_locations,
                    }
                )
        # flag-like should be bool only
        if var.lower().startswith("is_") or var.lower().endswith("_flag"):
            if any(tt not in ("bool", "unknown") for tt in tset):
                issues.append(
                    {
                        "var": var,
                        "issue": "flag-not-bool",
                        "types": sorted(tset),
                        "hint": "Use True/False (avoid 0/1 or strings).",
                        "where": var_locations,
                    }
                )
        # mixed-type anywhere
        if len({tt for tt in tset if tt != "unknown"}) > 1:
            issues.append(
                {
                    "var": var,
                    "issue": "mixed-types",
                    "types": sorted(tset),
                    "where": var_locations,
                }
            )

    duration_ms = int((time.time() - start_time) * 1000)
    if not as_json:
        print(f"[Stats][timing] TOTAL: {duration_ms / 1000:.2f}s", flush=True)

    if as_json:
        output = {
            "summary": {"vars_seen": len(types), "issues": len(issues)},
            "issues": issues,
        }

        # Add detailed info if requested
        if detailed:
            output["variables"] = {
                var: {
                    "types": sorted(tset),
                    "locations": locations.get(var, []),
                    "usage": usage_stats.get(var, {}),
                }
                for var, tset in types.items()
            }
            output["usage_stats"] = usage_stats
            output["potentially_unused"] = potentially_unused
            output["numeric_vars"] = numeric_vars
            output["flag_vars"] = flag_vars
            output["naming_issues"] = naming_issues
            output["suggestions"] = suggestions

        print(json.dumps(output, indent=2, ensure_ascii=False))
    else:
        print(f"Stats check — issues ({len(issues)})")
        for it in issues:
            print(f"- {it['var']}: {it['issue']}  types={','.join(it['types'])}")
            for w in it["where"][:5]:
                print(f"    • {w['file']}:{w['line']} ({w['operator']} {w['type']})")
            if "hint" in it:
                print(f"    hint: {it['hint']}")

    # Emit dashboard report
    emit = should_emit_from_args(args) if args else True
    html_requested = getattr(args, "html", False) or getattr(
        args, "open_browser", False
    )
    # Always write the stats artifact — required for the VS Code panel contract.
    # 'emit' controls only the JSONL event, not whether the artifact is written.
    if True:
        project_name = os.path.basename(os.path.abspath(project))

        # If no output path specified, default to .branchpy/stats/
        if out is None:
            project_root = Path(project).resolve()
            stats_dir = project_root / ".branchpy" / "stats"
            stats_dir.mkdir(parents=True, exist_ok=True)
            timestamp = time.strftime("%Y%m%d-%H%M%S")
            out = str(stats_dir / f"stats-{project_name}-{timestamp}.json")
        # If output path is relative, put it in .branchpy/stats/
        elif not Path(out).is_absolute():
            project_root = Path(project).resolve()
            stats_dir = project_root / ".branchpy" / "stats"
            stats_dir.mkdir(parents=True, exist_ok=True)
            out = str(stats_dir / Path(out).name)

        # Create detailed variable information for report
        all_variables = []
        for var in sorted(types.keys()):
            var_types = sorted(types[var])
            var_locations = locations.get(var, [])
            var_usage = []  # Read locations not tracked (counts-only mode)
            var_stats = usage_stats.get(var, {})

            # Determine status based on issues
            var_issue = None
            status = "ok"
            issue_desc = None
            hint = None

            for issue in issues:
                if issue["var"] == var:
                    var_issue = issue
                    if (
                        "flag-not-bool" in issue["issue"]
                        or "trust-not-numeric" in issue["issue"]
                    ):
                        status = "warning"
                    else:
                        status = "error"
                    issue_desc = issue["issue"]
                    hint = issue.get("hint")
                    break

            all_variables.append(
                {
                    "name": var,
                    "types": var_types,
                    "status": status,
                    "issue": issue_desc,
                    "hint": hint,
                    "definitions": var_locations,
                    "usage_count": len(var_locations),
                    "reads": var_usage,  # Read locations not tracked (counts only)
                    "read_count": actual_usage_counts.get(var, 0),  # Read count
                    "writes": var_stats.get("writes", 0),  # NEW: Write count
                    "modifies": var_stats.get("modifies", 0),  # NEW: Modify count
                    "total_usage": var_stats.get("total", 0),  # NEW: Total usage
                }
            )

        # Create stats data for report
        stats_data = {
            "variables": len(types),
            "assignments": len(assigns),
            "issues": issues,
            "all_variables": all_variables,
            # Enhanced metrics
            "usage_stats": usage_stats,
            "potentially_unused": potentially_unused,
            "numeric_vars": numeric_vars,  # NEW: Numeric variables with ranges
            "non_numeric_vars": non_numeric_vars,  # NEW: Non-numeric variables
            "flag_vars": flag_vars,
            "naming_issues": naming_issues,
            "suggestions": suggestions,  # NEW: Actionable suggestions
            "type_distribution": {
                "bool": len([v for v, t in types.items() if t == {"bool"}]),
                "number": len([v for v, t in types.items() if t == {"number"}]),
                "string": len([v for v, t in types.items() if t == {"string"}]),
                "list": len([v for v, t in types.items() if t == {"list"}]),
                "dict": len([v for v, t in types.items() if t == {"dict"}]),
                "mixed": len([v for v, t in types.items() if len(t - {"unknown"}) > 1]),
                "unknown": len([v for v, t in types.items() if t == {"unknown"}]),
            },
        }

        # Convert to dashboard items (legacy format for compatibility)
        items = []

        # Add a summary item at the beginning
        items.append(
            {
                "type": "summary",
                "path": f"{len(types)} variables analyzed",
                "status": "ok" if not issues else "warning",
                "ref": f"{len(assigns)} assignments found",
            }
        )

        # === NEW: Add Insights Section ===
        # Add suggestions first (most important)
        if suggestions:
            items.append(
                {
                    "type": "insight",
                    "insight_type": "suggestions",
                    "path": "💡 Suggestions",
                    "status": "info",
                    "ref": f"{len(suggestions)} recommendation(s) to improve your code",
                    "details": {
                        "hint": "Actionable recommendations based on variable usage analysis",
                        "suggestions": suggestions,
                    },
                }
            )

        # Most used variables
        most_used = sorted(
            usage_stats.items(), key=lambda x: x[1]["total"], reverse=True
        )[:10]
        if most_used:
            items.append(
                {
                    "type": "insight",
                    "insight_type": "most_used",
                    "path": "📊 Most Used Variables",
                    "status": "info",
                    "ref": f"Top {len(most_used)} variables by usage count",
                    "details": {
                        "hint": "Variables with the highest usage across writes, modifies, and reads",
                        "items": [{"var": var, **stats} for var, stats in most_used],
                    },
                }
            )

        # Potentially unused variables - with locations and code snippets
        if potentially_unused:
            # Gather detailed info for each unused variable (with snippets)
            unused_details = []
            for var in potentially_unused[:35]:  # Limit to 35
                var_locs = locations.get(var, [])
                if var_locs:
                    first_loc = var_locs[0]
                    snippet = _extract_code_snippet(
                        first_loc["file"], first_loc["line"], context_lines=2
                    )
                    unused_details.append(
                        {
                            "var": var,
                            "file": first_loc["file"],
                            "line": first_loc["line"],
                            "operator": first_loc["operator"],
                            "type": first_loc["type"],
                            "snippet": snippet,  # NEW: Code snippet with context
                        }
                    )

            items.append(
                {
                    "type": "insight",
                    "insight_type": "potentially_unused",
                    "path": "⚠️ Potentially Unused Variables",
                    "status": "warning",
                    "ref": f"{len(potentially_unused)} variables assigned only once",
                    "details": {
                        "hint": "These variables are assigned once but never used. Consider removing them or verify they're used in expressions/conditions.",
                        "variables": unused_details,
                        "total_count": len(potentially_unused),
                    },
                }
            )

        # Numeric variables summary
        if numeric_vars:
            items.append(
                {
                    "type": "insight",
                    "insight_type": "numeric_variables",
                    "path": "🔢 Numeric Variables",
                    "status": "info",
                    "ref": f"{len(numeric_vars)} number variables with ranges",
                    "details": {
                        "hint": "Variables that store numeric values with their min/max ranges",
                        "variables": numeric_vars,
                    },
                }
            )

        # Non-numeric variables summary
        if non_numeric_vars:
            items.append(
                {
                    "type": "insight",
                    "insight_type": "non_numeric_variables",
                    "path": "� Non-numeric Variables",
                    "status": "info",
                    "ref": f"{len(non_numeric_vars)} string/list/dict variables",
                    "details": {
                        "hint": "Variables that store text, lists, or objects with their possible values",
                        "variables": non_numeric_vars,
                    },
                }
            )

        # Flag variables summary
        if flag_vars:
            items.append(
                {
                    "type": "insight",
                    "insight_type": "flag_variables",
                    "path": "🚩 Flag Variables",
                    "status": "info",
                    "ref": f"{len(flag_vars)} flag/boolean variables found",
                    "details": {
                        "hint": "Boolean/flag variables - should only be True/False (not 0/1 or strings)",
                        "variables": flag_vars,
                    },
                }
            )

        # Unknown type variables summary
        if unknown_type_vars:
            items.append(
                {
                    "type": "insight",
                    "insight_type": "unknown_type_variables",
                    "path": "❓ Unknown Type Variables",
                    "status": "warning",
                    "ref": f"{len(unknown_type_vars)} variables with undetermined types",
                    "details": {
                        "hint": "Variables that couldn't be type-analyzed. They may be used in complex expressions, conditionals, or come from external sources.",
                        "variables": unknown_type_vars,
                    },
                }
            )

        # System variables (Ren'Py built-ins that were excluded)
        if system_vars:
            items.append(
                {
                    "type": "insight",
                    "insight_type": "system_variables",
                    "path": "⚙️ System Variables",
                    "status": "info",
                    "ref": f"{len(system_vars)} Ren'Py built-in variables detected",
                    "details": {
                        "hint": "These are Ren'Py system variables (menu, style, config, etc.) that were excluded from analysis. They're managed by the engine.",
                        "variables": system_vars,
                    },
                }
            )

        # Naming convention issues
        if naming_issues:
            items.append(
                {
                    "type": "insight",
                    "path": "✏️ Naming Convention Issues",
                    "status": "warning",
                    "ref": f"{len(naming_issues)} variables with naming issues",
                    "details": {"issues": naming_issues[:10]},  # Show first 10
                }
            )
        # === END NEW ===

        # Add issue items (but NOT the ok variables - those are now in insight categories)
        for issue in issues:
            items.append(
                {
                    "type": "variable",
                    "path": issue["var"],
                    "status": (
                        "warning"
                        if "flag-not-bool" in issue["issue"]
                        or "trust-not-numeric" in issue["issue"]
                        else "error"
                    ),
                    "ref": f"{issue['issue']} ({', '.join(issue['types'])})",
                    "details": {
                        "issue": issue["issue"],
                        "types": issue["types"],
                        "locations": issue.get("where", []),
                        "hint": issue.get("hint"),
                    },
                }
            )

        # NOTE: Removed "Variables (90)" section - all variables now appear in categorized insights

        report = create_stats_report(
            project_name=project_name, stats_data=stats_data, duration_ms=duration_ms
        )

        # Override with our custom items
        report["items"] = items
        report["summary"]["counts"] = {
            "variables": len(types),
            "assignments": len(assigns),
            "issues": len(issues),
        }

        # Phase 1.1: Attach full CFG structure when available
        if cfg_graph is not None:
            try:
                # Get nodes and edges (handle both SAE CFG and adapters)
                nodes_raw = (
                    cfg_graph.nodes() if callable(cfg_graph.nodes) else cfg_graph.nodes
                )
                edges_raw = (
                    cfg_graph.edges() if callable(cfg_graph.edges) else cfg_graph.edges
                )

                # Convert to list if needed
                if hasattr(nodes_raw, "values"):
                    nodes_list = list(nodes_raw.values())  # type: ignore[union-attr]
                elif hasattr(nodes_raw, "__iter__"):
                    nodes_list = list(nodes_raw)  # type: ignore[arg-type]
                else:
                    nodes_list = []

                if hasattr(edges_raw, "__iter__"):
                    edges_list = list(edges_raw)  # type: ignore[arg-type]
                else:
                    edges_list = []

                # Build node data
                node_data = []
                for n in nodes_list:
                    node_info = {"id": getattr(n, "id", str(n))}
                    if hasattr(n, "kind"):
                        kind_val = n.kind  # type: ignore[union-attr]
                        # Handle NodeKind enum
                        node_info["kind"] = kind_val.value if hasattr(kind_val, "value") else str(kind_val)  # type: ignore[union-attr]
                    if hasattr(n, "name") and n.name:  # type: ignore[union-attr]
                        node_info["name"] = str(n.name)  # type: ignore[union-attr]
                    if hasattr(n, "file") and n.file:  # type: ignore[union-attr]
                        node_info["file"] = str(n.file)  # type: ignore[union-attr]
                    if hasattr(n, "line") and n.line:  # type: ignore[union-attr]
                        node_info["line"] = int(n.line)  # type: ignore[union-attr]
                    node_data.append(node_info)

                # Build edge data
                edge_data = []
                for e in edges_list:
                    edge_info = {}
                    # Handle different edge formats
                    if hasattr(e, "from_node"):
                        edge_info["from"] = getattr(e, "from_node")
                    elif hasattr(e, "src"):
                        edge_info["from"] = getattr(e, "src")

                    if hasattr(e, "to_node"):
                        edge_info["to"] = getattr(e, "to_node")
                    elif hasattr(e, "dst"):
                        edge_info["to"] = getattr(e, "dst")

                    if hasattr(e, "edge_type"):
                        etype = e.edge_type  # type: ignore[union-attr]
                        edge_info["type"] = (
                            etype.value if hasattr(etype, "value") else str(etype)
                        )
                    elif hasattr(e, "etype"):
                        edge_info["type"] = str(e.etype)  # type: ignore[union-attr]

                    edge_data.append(edge_info)

                # Build label index
                label_index = _build_label_index(cfg_graph)

                report["cfg"] = {
                    "nodes": node_data,
                    "edges": edge_data,
                    "label_index": label_index,
                    "source": cfg_source,
                }
            except Exception as e:
                import traceback

                log.debug(f"Failed to serialize CFG for report: {e}")  # type: ignore[attr-defined]
                log.debug(traceback.format_exc())
                # Fallback to counts only
                try:
                    nodes_count = len(nodes_list)  # type: ignore[possibly-unbound]
                    edges_count = len(edges_list)  # type: ignore[possibly-unbound]
                except NameError:
                    nodes_count = 0
                    edges_count = 0
                report["cfg"] = {
                    "nodes": nodes_count,
                    "edges": edges_count,
                    "source": "error",
                }
        else:
            # Legacy: counts only (backward compatibility)
            report["cfg"] = {
                "nodes": 0,
                "edges": 0,
                "source": "counts",
            }

        # Phase 1.2: Add CFG-based assignments to report
        if cfg_assignments:
            report["cfg_assignments"] = cfg_assignments
            report["summary"]["cfg_assignments_count"] = sum(
                len(a) for a in cfg_assignments.values()
            )

        # Phase 1.3: Add variable flow graph to report
        if variable_flow_graph:
            report["variable_flow"] = variable_flow_graph
            report["summary"]["flow_variables_count"] = len(variable_flow_graph)

        write_report_and_emit(report, project, emit, out=out)

        # --html / --open: generate HTML report artifact
        if html_requested:
            try:
                from branchpy.cli.html_report import (
                    announce_html_report,
                    generate_stats_html,
                )
                from branchpy.cli.html_report import open_in_browser as _open_browser
                from branchpy.cli.html_report import resolve_html_output_path

                html_path = generate_stats_html(
                    stats_data,
                    project_root,
                    resolve_html_output_path(project_root, "stats", html_out_path),
                )
                announce_html_report("stats", html_path)
                if getattr(args, "open_browser", False):
                    _open_browser(html_path)
            except Exception as _html_err:
                print(f"[Stats] Warning: HTML report generation failed: {_html_err}")

    # treat issues as warnings (exit 0) for now
    return 0


def add_parser(subparsers):
    """Register the stats command with the CLI parser."""
    from ..cli_help import HelpFmt, fmt_examples

    stats_p = subparsers.add_parser(
        "stats",
        help="Variable consistency check: types, flags, trust values, naming conventions.",
        description=(
            "Analyze variable assignments for type consistency, flag validation, "
            "trust value ranges, and naming conventions. Provides actionable suggestions "
            "for code improvements including unused variable detection and usage patterns."
        ),
        epilog=fmt_examples(
            "branchpy --project /path/to/project stats",
            "branchpy --project mygame stats --out stats.json",
            "branchpy --project mygame stats --format json",
        ),
        formatter_class=HelpFmt,
    )

    # Handler: route to run() function
    stats_p.set_defaults(handler=run)

    # Arguments
    stats_p.add_argument(
        "--out", type=str, metavar="PATH", help="Write output to file (JSON format)"
    )
    stats_p.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    stats_p.add_argument(
        "--json",
        action="store_true",
        help="Output in JSON format (equivalent to --format json)",
    )
    stats_p.add_argument(
        "--detailed",
        action="store_true",
        help="Include detailed variable information in output",
    )
    stats_p.add_argument(
        "--cfg-source",
        choices=["auto", "sae", "json", "dot", "none"],
        default="auto",
        help="Choose where to load full CFG from (default: auto).",
    )
    stats_p.add_argument(
        "--html",
        action="store_true",
        help="Generate a standalone HTML report artifact (saved to .branchpy/reports/).",
    )
    stats_p.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Generate and open an HTML report in the browser (implies --html).",
    )


# ============================================================================
# Phase 1.1: CFG Loading Functions
# ============================================================================


def _load_sae_cfg(project_root: Path):
    """Programmatically build a statement-level CFG via SAE.
    Returns (cfg, index) so the caller can reuse the index without rebuilding."""
    try:
        _t0 = time.perf_counter()
        indexer = Indexer(str(project_root))  # type: ignore[possibly-unbound]
        index = indexer.build_index()
        _t1 = time.perf_counter()
        print(
            f"[Stats][timing] build_index: {_t1 - _t0:.2f}s",
            flush=True,
            file=sys.stderr,
        )
        builder = StatementCFGBuilder(index, project_root=str(project_root))  # type: ignore[possibly-unbound]
        cfg = builder.build()  # Returns ControlFlowGraph with .nodes / .edges
        _t2 = time.perf_counter()
        print(
            f"[Stats][timing] StatementCFGBuilder.build: {_t2 - _t1:.2f}s",
            flush=True,
            file=sys.stderr,
        )
        return cfg, index
    except Exception as e:
        log.debug(f"SAE CFG build failed: {e}")
        return None, None


def _try_load_export_cfg_json(project_root: Path):
    """Load .branchpy/analyze/flowgraph.json produced by: branchpy analyze --deep --export-cfg"""
    # Try multiple possible locations
    candidates = [
        project_root / ".branchpy" / "analyze" / "flowgraph.json",
        project_root / "reports" / "sae" / "flowgraph.json",
    ]

    for p in candidates:
        if not p.exists():
            continue
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            nodes = [
                _NodeAdapter(
                    n.get("id"),
                    n.get("kind", "stmt"),
                    n.get("name"),
                    n.get("file"),
                    n.get("line"),
                )
                for n in data.get("nodes", [])
            ]

            edges = [
                _EdgeAdapter(e.get("from"), e.get("to"), e.get("type", "edge"))
                for e in data.get("edges", [])
            ]

            return _GraphAdapter(nodes, edges)
        except Exception as e:
            log.debug(f"Exported CFG JSON load failed from {p}: {e}")
            continue

    return None


def _try_parse_dot_graph(project_root: Path):
    """Parse .branchpy/cache/cfg.dot produced by: branchpy analyze --debug-cfg cfg.dot

    Note: .branchpy/analyze/cfg.dot was previously listed as a candidate but
    is never written by any command (M-06). Only .branchpy/cache/cfg.dot is valid.
    """
    candidates = [
        project_root / ".branchpy" / "cache" / "cfg.dot",
    ]

    for dot_path in candidates:
        if not dot_path.exists():
            continue

        try:
            import re

            node_rx = re.compile(r'"?(\w+)"?\s+\[label="([^"]*)"\]')
            edge_rx = re.compile(r'"?(\w+)"?\s*->\s*"?(\w+)"?')

            nodes, edges, seen = [], [], {}
            content = dot_path.read_text(encoding="utf-8")

            for line in content.splitlines():
                # Try to match nodes
                m = node_rx.search(line)
                if m:
                    nid, lbl = m.group(1), m.group(2)
                    if nid not in seen:
                        seen[nid] = _NodeAdapter(nid, "label", lbl, None, None)
                        nodes.append(seen[nid])
                    continue

                # Try to match edges
                m = edge_rx.search(line)
                if m:
                    edges.append(_EdgeAdapter(m.group(1), m.group(2), "edge"))

            if nodes or edges:
                return _GraphAdapter(nodes, edges)
        except Exception as e:
            log.debug(f"DOT graph parse failed from {dot_path}: {e}")
            continue

    return None


class _NodeAdapter:
    """Adapter for CFG nodes from different sources"""

    def __init__(
        self,
        id: str,
        kind: str,
        name: Optional[str],
        file: Optional[str],
        line: Optional[int],
    ):
        self.id = id
        self.kind = kind
        self.name = name
        self.file = file
        self.line = line


class _EdgeAdapter:
    """Adapter for CFG edges from different sources"""

    def __init__(self, src: str, dst: str, etype: str):
        self.src = src
        self.dst = dst
        self.etype = etype


class _GraphAdapter:
    """Adapter to provide consistent interface for different CFG sources"""

    def __init__(self, nodes: List[_NodeAdapter], edges: List[_EdgeAdapter]):
        self._nodes = nodes
        self._edges = edges

    def nodes(self):
        return self._nodes

    def edges(self):
        return self._edges


def _build_label_index(cfg_graph) -> Dict[str, List[str]]:
    """Heuristic map: label name → list of node ids that carry that label token."""
    label_idx: Dict[str, List[str]] = {}

    # Get nodes (handle both SAE CFG and adapters)
    nodes_raw = cfg_graph.nodes() if callable(cfg_graph.nodes) else cfg_graph.nodes
    if hasattr(nodes_raw, "values"):
        nodes_iter = nodes_raw.values()  # type: ignore[union-attr]
    elif hasattr(nodes_raw, "__iter__"):
        nodes_iter = nodes_raw  # type: ignore[assignment]
    else:
        return label_idx

    for n in nodes_iter:  # type: ignore[union-attr]
        # Get label from node name or node attributes
        lbl = None
        if hasattr(n, "name") and n.name:
            lbl = str(n.name)
        elif hasattr(n, "label") and n.label:
            lbl = str(n.label)

        if not lbl:
            continue

        lbl = lbl.strip()
        # Accept common patterns like "chapter1_label", "label: chapter1_label", etc.
        key = lbl.replace("label:", "").strip().split()[0]
        if key:
            node_id = getattr(n, "id", str(n))
            label_idx.setdefault(key, []).append(node_id)

    return label_idx
