"""PFI Command - Project Function Index CLI"""

import sys
from pathlib import Path

# License gating (v1.0.0)
from branchpy.license.gating import require_feature_cli

try:
    from ..core.logging import log
except ImportError:
    import logging

    log = logging.getLogger(__name__)

from ..analysis.pfi import (
    CallGraph,
    ConsistencyChecker,
    FunctionIndexer,
    PFIExporter,
    StatEffectAnalyzer,
)
from ..analysis.pfi.consistency_checker import WarningLevel, WarningType


def add_pfi_subcommand(subparsers):
    """Add 'branchpy pfi' subcommand to argument parser"""
    parser = subparsers.add_parser(
        "pfi",
        help="Project Function Index - Analyze custom functions",
        description="Discover, classify, and index all custom functions in the project",
    )

    parser.add_argument(
        "-p", "--project", required=True, help="Path to Ren'Py project root"
    )

    parser.add_argument(
        "-o",
        "--output",
        help="Output file path (default: .branchpy/cache/function_index.json)",
    )

    parser.add_argument(
        "--format",
        choices=["full", "compact", "by-stat"],
        default="full",
        help="Output format (default: full)",
    )

    parser.add_argument(
        "--export-dot", help="Export call graph in DOT format to specified file"
    )

    parser.add_argument(
        "--complexity-threshold",
        type=int,
        default=15,
        help="Cyclomatic complexity warning threshold (default: 15)",
    )

    parser.add_argument(
        "--no-naming-checks",
        action="store_true",
        help="Disable naming convention checks",
    )

    parser.add_argument(
        "--stats",
        nargs="+",
        help="Additional stat variable names to track (beyond common patterns)",
    )

    parser.add_argument(
        "--show-warnings",
        action="store_true",
        help="Print consistency warnings to console",
    )

    parser.add_argument(
        "--show-dead",
        action="store_true",
        help="Print dead (unused) functions to console",
    )

    parser.add_argument(
        "--show-call-graph",
        action="store_true",
        help="Print call graph summary to console",
    )

    parser.set_defaults(func=run_pfi_command)


def run_pfi_command(args) -> int:
    """Execute PFI analysis command"""
    # LIC-CLI-1: Require pfi feature (Pro+ or Ren'Py)
    project_root = Path(args.project).resolve()
    require_feature_cli("pfi", "Project Function Index", project_root)

    import time

    start_time = time.time()

    if not project_root.exists():
        print(f"Error: Project path does not exist: {project_root}", file=sys.stderr)
        return 1

    print(f"[PFI] Analyzing project: {project_root}")

    # Phase 1: Index functions
    print("[PFI] Phase 1/4: Discovering functions...")
    indexer = FunctionIndexer(project_root)
    index_data = indexer.index_project()
    files_scanned = (
        len(list((project_root / "game").rglob("*.rpy")))
        if (project_root / "game").exists()
        else 0
    )

    total_functions = len(indexer.all_functions)
    unique_names = len(indexer.functions)
    print(
        f"[PFI] Found {total_functions} function definitions ({unique_names} unique names)"
    )

    # Phase 2: Analyze stat effects
    print("[PFI] Phase 2/4: Analyzing stat effects...")

    # Build known stats set
    known_stats = StatEffectAnalyzer.COMMON_STATS.copy()
    if args.stats:
        known_stats.update(args.stats)

    analyzer = StatEffectAnalyzer(known_stats=known_stats)

    # Analyze each function
    for func in indexer.all_functions:
        # Read source file
        try:
            file_path = project_root / func.file
            if file_path.exists():
                source = file_path.read_text(encoding="utf-8", errors="ignore")
                analyzer.analyze_function(func, source)
        except Exception as e:
            log.error("pfi.analysis_error", function=func.name, error=str(e))

    stat_modifiers = sum(1 for a in analyzer.analyses.values() if a.is_stat_modifier)
    print(
        f"[PFI] Analyzed {len(analyzer.analyses)} functions ({stat_modifiers} modify stats)"
    )

    # Phase 3: Build call graph
    print("[PFI] Phase 3/4: Building call graph...")
    call_graph = CallGraph()
    call_graph.build_from_functions(indexer.all_functions)

    cycles = call_graph.detect_cycles()
    print(
        f"[PFI] Call graph: {len(call_graph.edges)} edges, {len(cycles)} cycles detected"
    )

    # Phase 4: Consistency checks
    print("[PFI] Phase 4/4: Running consistency checks...")
    checker = ConsistencyChecker(
        complexity_threshold=args.complexity_threshold,
        enable_naming_checks=not args.no_naming_checks,
    )
    warnings = checker.check_all(indexer.all_functions, analyzer.analyses)

    error_count = len(checker.get_warnings_by_level(WarningLevel.ERROR))
    warning_count = len(checker.get_warnings_by_level(WarningLevel.WARNING))
    info_count = len(checker.get_warnings_by_level(WarningLevel.INFO))

    print(
        f"[PFI] Consistency: {error_count} errors, {warning_count} warnings, {info_count} info"
    )

    # Export results
    print("[PFI] Exporting results...")
    exporter = PFIExporter(indexer, analyzer, checker, call_graph)

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        cache_dir = project_root / ".branchpy" / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        output_path = cache_dir / "function_index.json"

    # Save main export
    exporter.save_to_file(output_path, format=args.format)
    print(f"[PFI] Saved function index: {output_path}")

    # Export DOT file if requested
    if args.export_dot:
        dot_path = Path(args.export_dot)
        exporter.save_call_graph_dot(dot_path)
        print(f"[PFI] Saved call graph: {dot_path}")

    # Optional console outputs
    if args.show_warnings and warnings:
        print("\n=== Consistency Warnings ===")
        for w in warnings:
            level_symbol = {
                WarningLevel.ERROR: "❌",
                WarningLevel.WARNING: "⚠️",
                WarningLevel.INFO: "ℹ️",
            }.get(w.level, "•")
            print(f"{level_symbol} {w.file}:{w.line} - {w.message}")

    if args.show_dead:
        dead_funcs = checker.get_warnings_by_type(WarningType.DEAD_FUNCTION)
        if dead_funcs:
            print("\n=== Dead Functions (Never Called) ===")
            for w in dead_funcs:
                print(f"  • {w.function_name} ({w.file}:{w.line})")

    if args.show_call_graph:
        print("\n=== Call Graph Summary ===")
        print(f"  Total nodes: {len(call_graph.nodes)}")
        print(f"  Total edges: {len(call_graph.edges)}")
        print(f"  Leaf functions: {len(call_graph.get_leaf_functions())}")
        print(f"  Root functions: {len(call_graph.get_root_functions())}")

        if cycles:
            print(f"\n  ⚠️  Detected {len(cycles)} circular dependencies:")
            for cycle in cycles[:5]:  # Show first 5
                print(f"    → {' → '.join(cycle)} → {cycle[0]}")
            if len(cycles) > 5:
                print(f"    ... and {len(cycles) - 5} more")

    print("\n[PFI] Analysis complete!")

    # Emit governance summary event
    try:
        from ..analysis.pfi import get_governance_logger

        governance_logger = get_governance_logger()

        duration_ms = (time.time() - start_time) * 1000
        unused_functions = len(checker.get_warnings_by_type(WarningType.DEAD_FUNCTION))
        redefined_functions = len(
            checker.get_warnings_by_type(WarningType.SIGNATURE_DRIFT)
        )

        governance_logger.emit_pfi_indexed(
            project=str(project_root),
            total_functions=total_functions,
            stat_modifiers=stat_modifiers,
            unused_functions=unused_functions,
            redefined_functions=redefined_functions,
            total_warnings=len(warnings),
            files_scanned=files_scanned,
            duration_ms=duration_ms,
        )
    except Exception as e:
        log.error(f"Failed to emit governance summary: {e}")

    # Return error code if errors found
    return 1 if error_count > 0 else 0


def run(args) -> int:
    """Legacy entry point (for backward compatibility)"""
    return run_pfi_command(args)
