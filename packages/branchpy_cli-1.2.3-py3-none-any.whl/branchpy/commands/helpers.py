from argparse import Namespace

from branchpy.ai.provider_base import DataClass


def infer_data_class_for_ai(args: Namespace) -> DataClass:
    """
    Infers the data classification for an AI command based on its arguments.

    Args:
        args: The parsed command-line arguments.

    Returns:
        The inferred DataClass.
    """
    # If the user explicitly provides the data class, respect it.
    if getattr(args, "data_class", None):
        try:
            return DataClass(args.data_class)
        except ValueError:
            # Default to the most restrictive if the value is invalid.
            return DataClass.RESTRICTED

    # Commands that operate on local file paths are likely sensitive.
    if hasattr(args, "path") and args.path:
        return DataClass.SENSITIVE

    # Commands that operate on text snippets are likely public.
    if hasattr(args, "warning_text") or hasattr(args, "prompt"):
        return DataClass.PUBLIC

    # Default fallback.
    return DataClass.SENSITIVE
