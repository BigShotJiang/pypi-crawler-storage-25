import re
import subprocess
from pathlib import Path


def _repo_root(start: Path | None = None) -> Path:
    start = start or Path.cwd()
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=start,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        return Path(out) if out else start
    except Exception:
        return start


def _slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_") or "project"


def _detect_game_root(start: Path) -> Path | None:
    # Walk up from 'start' and prefer a folder that has /game
    cur = start
    while cur and cur != cur.parent:
        if (cur / "game").is_dir():
            return cur
        cur = cur.parent
    return None


def _resolve_project(args, repo_root: Path) -> tuple[Path, str]:
    """
    Returns (project_root, project_slug)
    --project may be a path or a short name equal to a folder that has /game.
    """
    if getattr(args, "project", None):
        p = Path(args.project)
        project_root = (p if p.is_absolute() else (repo_root / p)).resolve()
        if not project_root.exists():
            # treat as name: search under repo for folder matching name with /game
            cand = [d for d in repo_root.rglob(args.project) if (d / "game").is_dir()]
            if cand:
                project_root = cand[0]
        # if still not found, fall back to repo_root
    else:
        project_root = (
            _detect_game_root(Path.cwd()) or _detect_game_root(repo_root) or repo_root
        )

    slug = _slugify(project_root.name)
    return project_root, slug


def _project_patches_dir(repo_root: Path, slug: str) -> Path:
    return repo_root / ".branchpy" / "patches" / slug


def _latest_patch(patches_dir: Path) -> Path | None:
    patches = sorted(patches_dir.glob("*.patch"), key=lambda p: p.stat().st_mtime)
    return patches[-1] if patches else None


def _is_git_dirty(cwd: Path) -> bool:
    # Ignore untracked noise; only block on tracked changes
    out = subprocess.run(
        ["git", "status", "--porcelain", "--untracked-files=no"],
        cwd=cwd,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    return bool(out)
