"""
branchpy.commands.ai_cmd — CLI for AI capabilities

Provides command-line access to the AI provider framework for code review,
documentation generation, and other AI-powered tasks.

Governance ID: V0.9.5-AI-BYOAI
"""

from __future__ import annotations

import json
import sys
import time
from argparse import _SubParsersAction
from pathlib import Path

from branchpy.ai.provider_base import (
    AICapability,
    CodeReviewRequest,
    DocGenRequest,
    ExplainWarningRequest,
    ProviderConfigurationError,
)
from branchpy.ai.provider_registry import ProviderRegistry
from branchpy.ai.telemetry import log_ai_call
from branchpy.commands.helpers import infer_data_class_for_ai
from branchpy.project import detect_project_id, detect_workspace_root


def add_parser(subparsers: _SubParsersAction):
    """Add the 'ai' command parser."""
    ai_parser = subparsers.add_parser(
        "ai", help="Interact with BranchPy's AI capabilities."
    )
    ai_subparsers = ai_parser.add_subparsers(
        dest="ai_command", required=True, help="AI sub-command"
    )

    # `branchpy ai providers`
    providers_parser = ai_subparsers.add_parser(
        "providers", help="Manage and inspect AI providers."
    )
    providers_subparsers = providers_parser.add_subparsers(
        dest="providers_command", required=True
    )

    # `branchpy ai providers list`
    list_parser = providers_subparsers.add_parser(
        "list", help="List all configured AI providers."
    )
    list_parser.set_defaults(func=handle_providers_list)

    # `branchpy ai providers test`
    test_parser = providers_subparsers.add_parser(
        "test", help="Test a specific AI provider's health."
    )
    test_parser.add_argument(
        "--provider", required=True, help="The ID of the provider to test."
    )
    test_parser.set_defaults(func=handle_providers_test)

    # `branchpy ai review`
    review_parser = ai_subparsers.add_parser(
        "review", help="Perform an AI-powered code review on a file."
    )
    review_parser.add_argument("path", type=Path, help="Path to the file to review.")
    review_parser.add_argument("--provider", help="ID of the preferred AI provider.")
    review_parser.add_argument(
        "--json", action="store_true", help="Output results in JSON format."
    )
    review_parser.set_defaults(func=handle_review)

    # `branchpy ai docgen`
    docgen_parser = ai_subparsers.add_parser(
        "docgen", help="Generate documentation for a code file or symbol."
    )
    docgen_parser.add_argument("path", type=Path, help="Path to the file to document.")
    docgen_parser.add_argument("--provider", help="ID of the preferred AI provider.")
    docgen_parser.add_argument(
        "--json", action="store_true", help="Output results in JSON format."
    )
    docgen_parser.set_defaults(func=handle_docgen)

    # `branchpy ai explain-warning`
    explain_parser = ai_subparsers.add_parser(
        "explain-warning", help="Explain a warning or error message."
    )
    explain_parser.add_argument(
        "--warning-text", required=True, help="The warning text to explain."
    )
    explain_parser.add_argument("--provider", help="ID of the preferred AI provider.")
    explain_parser.add_argument(
        "--json", action="store_true", help="Output results in JSON format."
    )
    explain_parser.set_defaults(func=handle_explain_warning)


def run(args):
    """Entry point for 'ai' commands."""
    if hasattr(args, "func"):
        return args.func(args)
    return 1


# --- Command Handlers ---


def handle_providers_list(args):
    """Handles `branchpy ai providers list`."""
    registry = ProviderRegistry()
    providers = registry.list_providers()

    print("Configured AI Providers:")
    for p in providers:
        status = "✅ Healthy" if p["healthy"] else "❌ Unhealthy"
        caps = ", ".join(p["capabilities"])
        print(f"  - ID: {p['id']}")
        print(f"    Name: {p['name']}")
        print(f"    Type: {p['type']}")
        print(f"    Status: {status}")
        print(f"    Capabilities: {caps}")
        print("-" * 20)
    return 0


def handle_providers_test(args):
    """Handles `branchpy ai providers test`."""
    start = time.perf_counter()
    provider_id = args.provider
    success = False
    error_code = None
    error_message = None
    correlation_id = f"ai-test-{int(time.time() * 1000)}"
    exit_code = 1

    try:
        registry = ProviderRegistry()
        provider = registry.get_provider_by_id(args.provider)

        if not provider:
            raise ValueError(f"Provider '{args.provider}' not found.")

        print(f"Testing provider: {provider.name} ({provider.id})...")
        is_healthy = provider.health_check()

        if is_healthy:
            print("Result: ✅ Provider is healthy and responding.")
            success = True
            exit_code = 0
        else:
            print("Result: ❌ Provider health check failed.")
            error_message = "Provider health check returned unhealthy."
            exit_code = 1

    except Exception as exc:
        error_code = type(exc).__name__
        error_message = str(exc)
        print(f"[BranchPy AI] Error: {error_message}", flush=True)
        exit_code = 1

    finally:
        duration_ms = (time.perf_counter() - start) * 1000.0
        log_ai_call(
            provider_id=provider_id,
            model_name=None,  # No model used for health check
            capability="provider_test",
            command="ai providers test",
            project_id=None,
            workspace_root=None,
            data_class="public",
            redaction_applied=False,
            success=success,
            duration_ms=duration_ms,
            error_code=error_code,
            error_message=error_message[:200] if error_message else None,
            correlation_id=correlation_id,
        )
    return exit_code


def handle_review(args):
    """Handles `branchpy ai review`."""
    start = time.perf_counter()
    provider_id = None
    model_name = None
    success = False
    error_code = None
    error_message = None
    token_prompt = None
    token_completion = None
    exit_code = 1

    # Use getattr to safely access path, which may not exist for all commands
    path = getattr(args, "path", None)
    project_id = detect_project_id(path) if path else None
    workspace_root = detect_workspace_root(path) if path else None
    correlation_id = f"ai-review-{int(time.time() * 1000)}"
    data_class = infer_data_class_for_ai(args)

    try:
        registry = ProviderRegistry()
        provider = registry.get_provider(
            capability=AICapability.CODE_REVIEW,
            preferred_id=getattr(args, "provider", None),
        )
        if not provider:
            raise ProviderConfigurationError(
                "No capable provider found for code review."
            )

        provider_id = provider.id
        model_name = provider.get_default_model_for(AICapability.CODE_REVIEW)

        try:
            code = args.path.read_text(encoding="utf-8")
        except Exception as e:
            raise IOError(f"Error reading file {args.path}: {e}") from e

        request = CodeReviewRequest(
            code=code,
            language=args.path.suffix.lstrip("."),
            file_path=str(args.path),
        )

        print(f"Performing code review with provider: {provider.name}...")
        response = provider.review_code(request)
        success = True
        exit_code = 0

        token_prompt = response.metadata.get("token_prompt")
        token_completion = response.metadata.get("token_completion")

        if args.json:
            print(json.dumps(response.to_dict(), indent=2))
        else:
            print("\n--- Code Review Summary ---")
            print(response.summary)
            print("\n--- Findings ---")
            for finding in response.findings:
                print(
                    f"  - [{finding.severity.upper()}] Line {finding.line}: {finding.message}"
                )
                if finding.suggestion:
                    print(f"    Suggestion: {finding.suggestion}")
            print("\n" + "=" * 40)

    except Exception as exc:
        error_code = type(exc).__name__
        error_message = str(exc)
        print(f"[BranchPy AI] Error: {error_message}", flush=True)
        exit_code = 1

    finally:
        duration_ms = (time.perf_counter() - start) * 1000.0
        try:
            log_ai_call(
                provider_id=provider_id or "unknown",
                model_name=model_name,
                capability=AICapability.CODE_REVIEW.value,
                command="ai review",
                project_id=project_id,
                workspace_root=workspace_root,
                data_class=data_class,
                redaction_applied=False,  # Placeholder
                success=success,
                duration_ms=duration_ms,
                error_code=error_code,
                error_message=error_message[:200] if error_message else None,
                token_used_prompt=token_prompt,
                token_used_completion=token_completion,
                correlation_id=correlation_id,
            )
        except Exception as log_exc:
            # Telemetry must be non-fatal. Log to stderr and continue.
            print(
                f"[BranchPy Telemetry] CRITICAL: Failed to emit AI governance event: {log_exc}",
                file=sys.stderr,
                flush=True,
            )
    return exit_code


def handle_docgen(args):
    """Handles `branchpy ai docgen`."""
    start = time.perf_counter()
    provider_id = None
    model_name = None
    success = False
    error_code = None
    error_message = None
    token_prompt = None
    token_completion = None
    exit_code = 1

    project_id = detect_project_id(args.path)
    workspace_root = detect_workspace_root(args.path)
    correlation_id = f"ai-docgen-{int(time.time() * 1000)}"
    data_class = infer_data_class_for_ai(args)

    try:
        registry = ProviderRegistry()
        provider = registry.get_provider(
            capability=AICapability.DOCGEN,
            preferred_id=getattr(args, "provider", None),
        )
        if not provider:
            raise ProviderConfigurationError(
                "No capable provider found for document generation."
            )

        provider_id = provider.id
        model_name = provider.get_default_model_for(AICapability.DOCGEN)

        try:
            code = args.path.read_text(encoding="utf-8")
        except Exception as e:
            raise IOError(f"Error reading file {args.path}: {e}") from e

        request = DocGenRequest(
            code=code,
            language=args.path.suffix.lstrip("."),
            doc_type="docstring",  # Default for now
        )

        print(f"Generating documentation with provider: {provider.name}...")
        response = provider.generate_docs(request)
        success = True
        exit_code = 0

        token_prompt = getattr(response, "token_prompt", None)
        token_completion = getattr(response, "token_completion", None)

        if args.json:
            print(json.dumps(response.to_dict(), indent=2))
        else:
            print("\n--- Generated Documentation ---")
            print(response.content)
            print("\n" + "=" * 40)

    except Exception as exc:
        error_code = type(exc).__name__
        error_message = str(exc)
        print(f"[BranchPy AI] Error: {error_message}", flush=True)
        exit_code = 1

    finally:
        duration_ms = (time.perf_counter() - start) * 1000.0
        try:
            log_ai_call(
                provider_id=provider_id or "unknown",
                model_name=model_name,
                capability=AICapability.DOCGEN.value,
                command="ai docgen",
                project_id=project_id,
                workspace_root=workspace_root,
                data_class=data_class,
                redaction_applied=False,  # Placeholder
                success=success,
                duration_ms=duration_ms,
                error_code=error_code,
                error_message=error_message[:200] if error_message else None,
                token_used_prompt=token_prompt,
                token_used_completion=token_completion,
                correlation_id=correlation_id,
            )
        except Exception as log_exc:
            # Telemetry must be non-fatal. Log to stderr and continue.
            print(
                f"[BranchPy Telemetry] CRITICAL: Failed to emit AI governance event: {log_exc}",
                file=sys.stderr,
                flush=True,
            )

    return exit_code


def handle_explain_warning(args):
    """Handles `branchpy ai explain-warning`."""
    start = time.perf_counter()
    provider_id = None
    model_name = None
    success = False
    error_code = None
    error_message = None
    token_prompt = None
    token_completion = None
    exit_code = 1

    correlation_id = f"ai-explain-{int(time.time() * 1000)}"
    data_class = infer_data_class_for_ai(args)

    try:
        registry = ProviderRegistry()
        provider = registry.get_provider(
            capability=AICapability.EXPLAIN_WARNING,
            preferred_id=getattr(args, "provider", None),
        )
        if not provider:
            raise ProviderConfigurationError(
                "No capable provider found for explaining warnings."
            )

        provider_id = provider.id
        model_name = provider.get_default_model_for(AICapability.EXPLAIN_WARNING)

        request = ExplainWarningRequest(warning_text=args.warning_text)

        print(f"Getting explanation with provider: {provider.name}...")
        response = provider.explain_warning(request)
        success = True
        exit_code = 0

        token_prompt = getattr(response, "token_prompt", None)
        token_completion = getattr(response, "token_completion", None)

        if args.json:
            print(json.dumps(response.to_dict(), indent=2))
        else:
            print("\n--- Explanation ---")
            print(response.explanation)
            if response.suggestion:
                print("\n--- Suggestion ---")
                print(response.suggestion)
            print("\n" + "=" * 40)

    except Exception as exc:
        error_code = type(exc).__name__
        error_message = str(exc)
        print(f"[BranchPy AI] Error: {error_message}", flush=True)
        exit_code = 1

    finally:
        duration_ms = (time.perf_counter() - start) * 1000.0
        try:
            log_ai_call(
                provider_id=provider_id or "unknown",
                model_name=model_name,
                capability=AICapability.EXPLAIN_WARNING.value,
                command="ai explain-warning",
                project_id=None,  # No project context for this command
                workspace_root=None,
                data_class=data_class,
                redaction_applied=False,  # Placeholder
                success=success,
                duration_ms=duration_ms,
                error_code=error_code,
                error_message=error_message[:200] if error_message else None,
                token_used_prompt=token_prompt,
                token_used_completion=token_completion,
                correlation_id=correlation_id,
            )
        except Exception as log_exc:
            # Telemetry must be non-fatal. Log to stderr and continue.
            print(
                f"[BranchPy Telemetry] CRITICAL: Failed to emit AI governance event: {log_exc}",
                file=sys.stderr,
                flush=True,
            )

    return exit_code


def handle_chat(args):
    """Handles `branchpy ai chat`."""
    start = time.perf_counter()
    provider_id = None
    model_name = None
    success = False
    error_code = None
    error_message = None
    token_prompt = None
    token_completion = None
    exit_code = 1

    correlation_id = f"ai-chat-{int(time.time() * 1000)}"
    data_class = infer_data_class_for_ai(args)

    try:
        registry = ProviderRegistry()
        provider = registry.get_provider(
            capability=AICapability.CHAT_HELP,
            preferred_id=getattr(args, "provider", None),
        )
        if not provider:
            raise ProviderConfigurationError("No capable provider found for chat.")

        provider_id = provider.id
        model_name = provider.get_default_model_for(AICapability.CHAT_HELP)

        # TODO: Implement interactive chat loop
        print(f"Provider {provider.name} selected for chat. (ID: {provider_id})")
        print("Chat functionality is not yet implemented.")

        success = True
        exit_code = 0

    except Exception as exc:
        error_code = type(exc).__name__
        error_message = str(exc)
        print(f"[BranchPy AI] Error: {error_message}", flush=True)
        exit_code = 1

    finally:
        duration_ms = (time.perf_counter() - start) * 1000.0
        try:
            log_ai_call(
                provider_id=provider_id or "unknown",
                model_name=model_name,
                capability=AICapability.CHAT_HELP.value,
                command="ai chat",
                project_id=None,
                workspace_root=None,
                data_class=data_class,
                redaction_applied=False,  # Placeholder
                success=success,
                duration_ms=duration_ms,
                error_code=error_code,
                error_message=error_message[:200] if error_message else None,
                token_used_prompt=token_prompt,
                token_used_completion=token_completion,
                correlation_id=correlation_id,
            )
        except Exception as log_exc:
            # Telemetry must be non-fatal. Log to stderr and continue.
            print(
                f"[BranchPy Telemetry] CRITICAL: Failed to emit AI governance event: {log_exc}",
                file=sys.stderr,
                flush=True,
            )

    return exit_code
