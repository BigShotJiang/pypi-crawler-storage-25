import argparse
from datetime import datetime

from branchpy.license_manager import mask_key, status


def build(parser: argparse.ArgumentParser) -> None:
    # no args
    ...


def run(args: argparse.Namespace) -> int:
    info = status()
    print("BranchPy License Status")
    print("-----------------------")
    print("Tier:", info.tier)
    print("Source:", info.source)
    print("Active:", "yes" if info.is_active else "no")
    if info.key:
        print("Key:", mask_key(info.key))
    if info.email:
        print("Email:", info.email)
    if info.issued_at:
        print("Issued:", datetime.utcfromtimestamp(info.issued_at).isoformat() + "Z")
    if info.expires_at:
        print("Expires:", datetime.utcfromtimestamp(info.expires_at).isoformat() + "Z")
    if info.offline_until:
        print(
            "Offline grace until:",
            datetime.utcfromtimestamp(info.offline_until).isoformat() + "Z",
        )
    return 0
