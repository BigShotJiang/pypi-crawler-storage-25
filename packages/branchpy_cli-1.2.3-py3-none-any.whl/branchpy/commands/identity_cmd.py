"""
Identity Management Commands for BranchPy v0.8.1

Provides:
- identity init-user: Create user identity
- identity whoami: Show current identity and role

Part of v0.8.1 (BPY-812 - CLI Commands)
"""

import argparse
import sys
from pathlib import Path


# Lazy import to avoid circular dependencies
def _get_audit_modules():
    """Lazy import audit modules"""
    from branchpy.core.audit import IdentityResolver

    return IdentityResolver


def add_parser(subparsers):
    """Add identity command parser (BranchPy convention)"""
    parser = subparsers.add_parser(
        "identity",
        help="Manage user identity for audit logging",
        description="Initialize and view user identity for team audit logging",
    )

    # Create subcommands
    identity_subparsers = parser.add_subparsers(
        dest="identity_command", help="Identity subcommands"
    )

    # identity init-user
    init_parser = identity_subparsers.add_parser(
        "init-user",
        help="Initialize user identity",
        description="Create ~/.branchpy/identity.toml with your user information",
    )
    init_parser.add_argument(
        "--name", type=str, help="User name (will prompt if not provided)"
    )
    init_parser.add_argument(
        "--email", type=str, help="User email (will prompt if not provided)"
    )

    # identity whoami
    whoami_parser = identity_subparsers.add_parser(
        "whoami",
        help="Show current identity",
        description="Display user identity, machine info, and role (if team.toml exists)",
    )

    return parser


def run(args):
    """Run identity command (BranchPy convention)"""
    if not hasattr(args, "identity_command") or args.identity_command is None:
        print(
            "Error: No subcommand specified. Use 'identity init-user' or 'identity whoami'"
        )
        return 1

    if args.identity_command == "init-user":
        return init_user(args)
    elif args.identity_command == "whoami":
        return whoami(args)
    else:
        print(f"Error: Unknown identity command: {args.identity_command}")
        return 1


def init_user(args):
    """Initialize user identity"""
    IdentityResolver = _get_audit_modules()

    # Get name and email
    name = args.name
    email = args.email

    if not name:
        name = input("Name: ").strip()
        if not name:
            print("Error: Name is required")
            return 1

    if not email:
        email = input("Email: ").strip()
        if not email:
            print("Error: Email is required")
            return 1

    # Create identity
    try:
        resolver = IdentityResolver(Path.home() / ".branchpy")
        identity = resolver.create_identity(name=name, email=email)

        print(f"\n[OK] Created identity in {resolver.identity_path}")
        print(f"  UUID: {identity.user.user_uuid}")
        print(f"  Name: {identity.user.name}")
        print(f"  Email: {identity.user.email}")

        return 0
    except Exception as e:
        print(f"Error creating identity: {e}", file=sys.stderr)
        return 1


def whoami(args):
    """Show current identity and role"""
    IdentityResolver = _get_audit_modules()

    try:
        # Resolve identity
        project_root = Path.cwd()
        resolver = IdentityResolver(project_root)
        identity = resolver.resolve()

        # Display identity
        print(f"User:    {identity.user.name} <{identity.user.email}>")
        print(f"UUID:    {identity.user.user_uuid}")
        print()
        print(f"Machine: {identity.machine.hostname} ({identity.machine.machine_uuid})")
        print()

        # Check for team role
        team_path = project_root / ".branchpy" / "team.toml"
        if team_path.exists():
            role = _get_user_role(team_path, identity.user.user_uuid)
            if role:
                print(f"Role:    {role}")
            else:
                print("Role:    (not in team.toml)")
        else:
            print("Role:    (no team.toml)")

        # Check audit log status
        audit_log = project_root / ".branchpy" / "audit" / "log.jsonl"
        if audit_log.exists():
            # Count entries
            try:
                with open(audit_log, "r", encoding="utf-8") as f:
                    count = sum(1 for _ in f)
                print(f"Audit:   {count} entries")
            except Exception:
                print("Audit:   log exists")
        else:
            print("Audit:   (no log)")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def _get_user_role(team_path: Path, user_uuid: str) -> str | None:
    """Get user role from team.toml"""
    try:
        # Use tomllib if Python 3.11+, else tomli
        try:
            import tomllib

            with open(team_path, "rb") as f:
                team_config = tomllib.load(f)
        except ImportError:
            import tomli

            with open(team_path, "rb") as f:
                team_config = tomli.load(f)

        # Find user in team config
        for user in team_config.get("users", []):
            if user.get("user_uuid") == user_uuid:
                return user.get("role", "contributor")

        return None
    except Exception:
        return None


if __name__ == "__main__":
    # Standalone test
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers()
    add_parser(subparsers)
    args = parser.parse_args()
    sys.exit(run(args))
