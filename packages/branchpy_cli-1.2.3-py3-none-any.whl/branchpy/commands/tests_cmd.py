# branchpy/commands/tests_cmd.py
import json
import logging
import os
import subprocess
import sys
import time
from typing import Any, Dict, Optional

from branchpy.parser import scan_project
from branchpy.report import print_report, save_dot
from branchpy.report_writer import (
    create_analysis_report,
    should_emit_from_args,
    write_report_and_emit,
)
from branchpy.utils.env import find_dot, graphviz_hint

log = logging.getLogger("branchpy.tests")


def run(
    project: str,
    out: Optional[str] = None,
    as_json: bool = False,
    dot_path: Optional[str] = None,
    png_path: Optional[str] = None,
    dry_run: bool = False,
    save_report: bool = False,
    matrix: Optional[str] = None,
    args=None,  # For emit settings
    **_kw,
) -> int:
    """
    Produces test results. When as_json is True, ALWAYS print a JSON object to stdout.
    When save_report is True, saves the report to the project's reports directory.
    When matrix is provided, runs tests across multiple Ren'Py SDKs.
    """
    log.debug(
        "tests.run: project=%s out=%s json=%s dot=%s png=%s dry=%s save_report=%s matrix=%s",
        project,
        out,
        as_json,
        dot_path,
        png_path,
        dry_run,
        save_report,
        matrix,
    )

    # Matrix testing across multiple SDKs
    if matrix:
        return _run_matrix_tests(project, matrix, as_json, out, save_report, dry_run)

    # Single SDK test (existing behavior)
    return _run_single_test(
        project, out, as_json, dot_path, png_path, dry_run, save_report, args
    )


def _run_matrix_tests(
    project: str,
    matrix: str,
    as_json: bool,
    out: Optional[str],
    save_report: bool,
    dry_run: bool,
) -> int:
    """Run tests across multiple Ren'Py SDKs."""
    from branchpy.renpy_sdk import RenpySdkManager

    sdk_names = [name.strip() for name in matrix.split(",")]
    manager = RenpySdkManager()

    matrix_results = {
        "matrix": True,
        "sdks": {},
        "summary": {
            "total_sdks": len(sdk_names),
            "successful": 0,
            "failed": 0,
            "skipped": 0,
        },
    }

    for sdk_name in sdk_names:
        sdk = manager.get_sdk(sdk_name)

        if not sdk:
            matrix_results["sdks"][sdk_name] = {
                "status": "not_found",
                "error": f"SDK '{sdk_name}' not registered",
            }
            matrix_results["summary"]["skipped"] += 1
            continue

        if not sdk.valid:
            matrix_results["sdks"][sdk_name] = {
                "status": "invalid",
                "error": f"SDK '{sdk_name}' is invalid or inaccessible",
            }
            matrix_results["summary"]["skipped"] += 1
            continue

        # Run test with this SDK
        try:
            if dry_run:
                print(
                    f"[dry-run] Would run tests with SDK: {sdk_name} ({sdk.version or 'unknown'})"
                )
                matrix_results["sdks"][sdk_name] = {
                    "status": "dry_run",
                    "version": sdk.version,
                    "path": sdk.path,
                }
                matrix_results["summary"]["successful"] += 1
            else:
                print(
                    f"Running tests with SDK: {sdk_name} ({sdk.version or 'unknown'})",
                    file=sys.stderr,
                )

                # Actually run the test with this SDK
                runner = manager.get_runner(sdk_name)
                if runner:
                    # For now, just validate the project
                    is_valid, message = runner.validate_project(project)

                    if is_valid:
                        # Run normal test logic
                        test_results = _run_single_test_logic(project)
                        matrix_results["sdks"][sdk_name] = {
                            "status": "success",
                            "version": sdk.version,
                            "path": sdk.path,
                            "results": test_results,
                        }
                        matrix_results["summary"]["successful"] += 1
                    else:
                        matrix_results["sdks"][sdk_name] = {
                            "status": "validation_failed",
                            "version": sdk.version,
                            "path": sdk.path,
                            "error": message,
                        }
                        matrix_results["summary"]["failed"] += 1
                else:
                    matrix_results["sdks"][sdk_name] = {
                        "status": "runner_error",
                        "error": "Could not create runner",
                    }
                    matrix_results["summary"]["failed"] += 1

        except Exception as e:
            matrix_results["sdks"][sdk_name] = {"status": "error", "error": str(e)}
            matrix_results["summary"]["failed"] += 1

    # Output results
    if as_json:
        json_str = json.dumps(matrix_results, ensure_ascii=False, indent=2)
        print(json_str)
        if out:
            try:
                with open(out, "w", encoding="utf-8") as f:
                    f.write(json_str)
                print(f"Matrix results written to {out}", file=sys.stderr)
            except Exception as e:
                print(f"Failed to write matrix results to {out}: {e}", file=sys.stderr)
    else:
        # Human-readable matrix summary
        print("=" * 60)
        print("BranchPy Matrix Test Results")
        print("=" * 60)

        for sdk_name, result in matrix_results["sdks"].items():
            status_icon = {
                "success": "✓",
                "not_found": "✗",
                "invalid": "✗",
                "validation_failed": "⚠",
                "error": "✗",
                "runner_error": "✗",
                "dry_run": "○",
            }.get(result["status"], "?")

            version = result.get("version", "unknown")
            print(f"{status_icon} {sdk_name:15} {version:12} {result['status']}")

            if "error" in result:
                print(f"    Error: {result['error']}")

        print()
        summary = matrix_results["summary"]
        print(
            f"Summary: {summary['successful']} successful, {summary['failed']} failed, {summary['skipped']} skipped"
        )

    # Return non-zero if any tests failed
    return 1 if matrix_results["summary"]["failed"] > 0 else 0


def _run_single_test(
    project: str,
    out: Optional[str],
    as_json: bool,
    dot_path: Optional[str],
    png_path: Optional[str],
    dry_run: bool,
    save_report: bool,
    args=None,
) -> int:
    """Run a single test (existing behavior)."""
    start_time = time.time()
    results = _run_single_test_logic(project)
    duration_ms = int((time.time() - start_time) * 1000)

    # Handle output and display
    if as_json:
        json_str = json.dumps(results, ensure_ascii=False, indent=2)
        print(json_str)
        if out:
            try:
                with open(out, "w", encoding="utf-8") as f:
                    f.write(json_str)
                print(f"Results written to {out}", file=sys.stderr)
            except Exception as e:
                print(f"Failed to write results to {out}: {e}", file=sys.stderr)
    else:
        print_report(results)

    # Emit dashboard report
    emit = should_emit_from_args(args) if args else True
    if emit:
        project_name = os.path.basename(os.path.abspath(project))

        # Convert test results to analysis format
        issues = []

        # Process different types of issues
        for target in results.get("missing_jump_targets", []):
            issues.append(
                {
                    "severity": "error",
                    "message": f"Missing jump target: {target}",
                    "file": "unknown",
                    "line": 0,
                }
            )

        for target in results.get("missing_call_targets", []):
            issues.append(
                {
                    "severity": "error",
                    "message": f"Missing call target: {target}",
                    "file": "unknown",
                    "line": 0,
                }
            )

        for label in results.get("orphan_labels", []):
            issues.append(
                {
                    "severity": "warning",
                    "message": f"Orphan label: {label}",
                    "file": "unknown",
                    "line": 0,
                }
            )

        for label in results.get("dead_end_labels", []):
            issues.append(
                {
                    "severity": "warning",
                    "message": f"Dead end label: {label}",
                    "file": "unknown",
                    "line": 0,
                }
            )

        for call in results.get("called_without_return", []):
            issues.append(
                {
                    "severity": "error",
                    "message": f"Called without return: {call}",
                    "file": "unknown",
                    "line": 0,
                }
            )

        for var, locations in results.get("duplicate_vars", {}).items():
            issues.append(
                {
                    "severity": "warning",
                    "message": f"Duplicate variable: {var}",
                    "file": "multiple",
                    "line": 0,
                }
            )

        # Check for scan errors
        if "scan_error" in results:
            issues.append(
                {
                    "severity": "error",
                    "message": f"Scan error: {results['scan_error']}",
                    "file": "project",
                    "line": 0,
                }
            )

        analysis_data = {"issues": issues}
        report = create_analysis_report(
            project_name=project_name,
            analysis_data=analysis_data,
            duration_ms=duration_ms,
        )

        # M-12: Write to canonical .branchpy/tests/ (primary); /out/ backward-compat copy is
        # written automatically by write_report_and_emit when out!=None and outside /out/.
        _tests_dir = os.path.join(os.path.abspath(project), ".branchpy", "tests")
        os.makedirs(_tests_dir, exist_ok=True)
        _ts = time.strftime("%Y%m%d-%H%M%S")
        _tests_out = os.path.join(_tests_dir, f"tests-{project_name}-{_ts}.json")
        write_report_and_emit(report, project, emit, out=_tests_out)

    # Optional report saving
    if save_report:
        try:
            from datetime import datetime

            from branchpy.report import save_report as save_report_func

            # Create reports directory in project
            reports_dir = os.path.join(project, "reports")
            os.makedirs(reports_dir, exist_ok=True)

            # Generate timestamped filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_path = os.path.join(reports_dir, f"test_report_{timestamp}.json")

            save_report_func(results, report_path, as_json=True)
            print(f"Report saved to {report_path}", file=sys.stderr)
        except Exception as e:
            print(f"Failed to save report: {e}", file=sys.stderr)

    # Optional DOT/PNG output
    if dot_path:
        if not dry_run:
            try:
                save_dot(results, dot_path)
                print(f"DOT file saved to {dot_path}", file=sys.stderr)
            except Exception as e:
                print(f"Failed to save DOT file: {e}", file=sys.stderr)
        else:
            print(f"[dry-run] Would save DOT to {dot_path}")

    if png_path:
        if not dry_run:
            try:
                dot = find_dot()
                if dot:
                    subprocess.run(
                        [dot, "-Tpng", dot_path or "output.dot", "-o", png_path],
                        check=True,
                    )
                    print(f"PNG file saved to {png_path}", file=sys.stderr)
                else:
                    print(f"Graphviz not found. {graphviz_hint()}", file=sys.stderr)
            except Exception as e:
                print(f"Failed to save PNG file: {e}", file=sys.stderr)
        else:
            print(f"[dry-run] Would save PNG to {png_path}")

    # Return non-zero if there are issues
    has_issues = (
        len(results.get("missing_jump_targets", [])) > 0
        or len(results.get("missing_call_targets", [])) > 0
        or len(results.get("orphan_labels", [])) > 0
        or len(results.get("dead_end_labels", [])) > 0
        or len(results.get("called_without_return", [])) > 0
        or len(results.get("duplicate_vars", {})) > 0
    )
    return 1 if has_issues else 0


def _run_single_test_logic(project: str) -> Dict[str, Any]:
    """Core test logic that returns results dictionary."""
    # Minimal schema for VS Code extension compatibility
    results = {
        "missing_jump_targets": [],
        "missing_call_targets": [],
        "orphan_labels": [],
        "dead_end_labels": [],
        "called_without_return": [],
        "duplicate_vars": {},
    }

    try:
        # Run the actual parsing and analysis
        graph = scan_project(project)

        # TODO: Implement actual test logic based on graph analysis
        # For now, return empty results indicating no issues found

        # Placeholder for future implementation:
        # - Analyze graph for missing jump targets
        # - Check for missing call targets
        # - Find orphan labels
        # - Detect dead end labels
        # - Identify calls without return
        # - Find duplicate variable definitions

    except Exception as e:
        # If scanning fails, record the error but don't crash
        log.error(f"Failed to scan project {project}: {e}")
        results["scan_error"] = str(e)

    return results
