# branchpy/commands/logs_cmd.py
import json
import os
import pathlib
import sys
import time

from branchpy import logs
from branchpy.cli_help import HelpFmt, fmt_examples


def get_log_dir() -> pathlib.Path:
    """Get the BranchPy logs directory."""
    if os.name == "nt":
        base = os.getenv("LOCALAPPDATA", os.path.expanduser("~"))
        return pathlib.Path(base) / "BranchPy" / "logs"
    return pathlib.Path.home() / ".branchpy" / "logs"


def cmd_where(args):
    """Show paths to all log files."""
    log_dir = get_log_dir()
    if not log_dir.exists():
        print(f"Log directory not found: {log_dir}")
        return 0

    paths = sorted(log_dir.glob("*.jsonl*"))
    if not paths:
        print(f"No log files found in: {log_dir}")
        return 0

    print(f"BranchPy log files ({len(paths)}):")
    for p in paths:
        size_mb = p.stat().st_size / (1024 * 1024)
        print(f"  {p} ({size_mb:.2f} MB)")
    return 0


def cmd_tail(args):
    """Tail log files with filtering."""
    log_dir = get_log_dir()
    log_file = log_dir / "cli.jsonl"  # Primary log file

    if not log_file.exists():
        print(f"Log file not found: {log_file}")
        if args.follow:
            print("Waiting for log file...")
            try:
                while not log_file.exists():
                    time.sleep(0.5)
            except KeyboardInterrupt:
                print("\nCancelled.")
                return 0
        else:
            return 0

    # Level ordering
    level_order = {
        "TRACE": 10,
        "DEBUG": 20,
        "INFO": 30,
        "WARN": 40,
        "ERROR": 50,
        "FATAL": 60,
    }
    min_level = level_order.get(args.level.upper(), 30)

    def should_show(rec):
        """Filter predicate for log records."""
        if args.component and rec.get("component") != args.component:
            return False
        rec_level = level_order.get(rec.get("level", "INFO"), 30)
        return rec_level >= min_level

    # Show initial tail
    with open(log_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
        for line in lines[-args.lines :]:
            try:
                rec = json.loads(line)
                if should_show(rec):
                    print(line, end="")
            except Exception:
                pass

    # Follow mode
    if args.follow:
        print("\n[Following logs — Ctrl+C to stop]", file=sys.stderr)
        pos = log_file.stat().st_size
        try:
            while True:
                time.sleep(0.2)
                with open(log_file, "r", encoding="utf-8") as f:
                    f.seek(pos)
                    for line in f:
                        try:
                            rec = json.loads(line)
                            if should_show(rec):
                                print(line, end="")
                        except Exception:
                            pass
                    pos = f.tell()
        except KeyboardInterrupt:
            print("\n[Stopped]", file=sys.stderr)
    return 0


def cmd_set(args):
    """Set log level with optional debug window."""
    component = args.component or "vscode"  # Default to vscode
    level = args.level.upper()

    # This sets it in the Python logs module (for CLI/daemon)
    logs.set_level(
        level,
        component=component,
        duration_minutes=args.minutes if args.minutes > 0 else None,
    )

    if args.minutes > 0:
        print(
            f"Set {component} to {level} for {args.minutes} minutes (auto-downshift to INFO)"
        )
    else:
        print(f"Set {component} to {level}")

    return 0


def cmd_find(args):
    """Find log events by name."""
    log_dir = get_log_dir()
    cutoff = time.time() - (args.since * 3600)

    found = 0
    for log_file in sorted(log_dir.glob("*.jsonl")):
        if log_file.stat().st_mtime < cutoff:
            continue

        with open(log_file, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    rec = json.loads(line)
                    if rec.get("event") == args.event:
                        print(line, end="")
                        found += 1
                except Exception:
                    pass

    if found == 0:
        print(f"No events found matching: {args.event}", file=sys.stderr)
    else:
        print(f"\n[Found {found} events]", file=sys.stderr)

    return 0


def run(args):
    """Dispatch to subcommand."""
    # Legacy support: if no subcommand, run tail
    if not hasattr(args, "logs_subcommand"):
        # Old-style invocation: bpy logs (no subcommand)
        # Fall back to simple tail behavior
        return cmd_tail(args)

    # Dispatch to subcommand
    handler = {
        "where": cmd_where,
        "tail": cmd_tail,
        "set": cmd_set,
        "find": cmd_find,
    }.get(args.logs_subcommand)

    if handler:
        return handler(args)

    print(f"Unknown logs subcommand: {args.logs_subcommand}", file=sys.stderr)
    return 1


def add_parser(subparsers):
    """Register the logs command with the CLI parser."""
    logs_p = subparsers.add_parser(
        "logs",
        help="Log utilities (where/tail/set/find)",
        description="BranchPy log utilities for viewing and managing logs.",
        epilog=fmt_examples(
            "branchpy logs where",
            "branchpy logs tail --component daemon --level WARN",
            "branchpy logs tail --follow",
            "branchpy logs set --component sae --level DEBUG --minutes 20",
            "branchpy logs find --event http.server_start --since 48",
        ),
        formatter_class=HelpFmt,
    )

    # Create subcommands
    logs_sub = logs_p.add_subparsers(dest="logs_subcommand", help="Subcommand")

    # where
    where_p = logs_sub.add_parser("where", help="Show log file paths")
    where_p.set_defaults(handler=run)

    # tail
    tail_p = logs_sub.add_parser("tail", help="Tail log files with filtering")
    tail_p.add_argument(
        "--component", default="", help="Filter by component (e.g. daemon, sae)"
    )
    tail_p.add_argument(
        "--level",
        default="INFO",
        help="Minimum level (TRACE/DEBUG/INFO/WARN/ERROR/FATAL)",
    )
    tail_p.add_argument(
        "--follow", "-f", action="store_true", help="Follow log file (like tail -f)"
    )
    tail_p.add_argument(
        "--lines", "-n", type=int, default=20, help="Number of lines to show initially"
    )
    tail_p.set_defaults(handler=run)

    # set
    set_p = logs_sub.add_parser("set", help="Set log level with optional debug window")
    set_p.add_argument(
        "--component", required=True, help="Component name (e.g. sae, daemon)"
    )
    set_p.add_argument(
        "--level", required=True, help="Log level (DEBUG, INFO, WARN, ERROR)"
    )
    set_p.add_argument(
        "--minutes",
        type=int,
        default=0,
        help="Auto-downshift after N minutes (0=permanent)",
    )
    set_p.set_defaults(handler=run)

    # find
    find_p = logs_sub.add_parser("find", help="Find events by name")
    find_p.add_argument(
        "--event", required=True, help="Event name (e.g. http.server_start)"
    )
    find_p.add_argument(
        "--since", type=int, default=24, help="Search files modified in last N hours"
    )
    find_p.set_defaults(handler=run)

    # Default handler for backward compat
    logs_p.set_defaults(handler=run)
