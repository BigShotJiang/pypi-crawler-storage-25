"""
Media Validation V3 CLI Commands - BranchPy v0.9.1.2

Comprehensive command suite for:
- Feature cache management (rebuild, purge, stats)
- Image clustering (duplicate/similar detection)
- Provider integration (test, fetch, sync)
- Report generation and export

Governance ID: AXIS5-V0.9.1.2-20251112-IMPL
Checkpoint: H2 — CLI Integration
Created: 2025-11-12
"""

import argparse
import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Tuple

# Lazy imports for performance
_IMAGE_VALIDATOR = None
_FEATURE_STORE = None
_CLUSTER_ENGINE = None

logger = logging.getLogger(__name__)


def _lazy_import_validator():
    """Lazy import validator to avoid startup overhead."""
    global _IMAGE_VALIDATOR
    if _IMAGE_VALIDATOR is None:
        from branchpy.image_validation_v3 import ImageValidator

        _IMAGE_VALIDATOR = ImageValidator
    return _IMAGE_VALIDATOR


def _lazy_import_feature_store():
    """Lazy import feature store."""
    global _FEATURE_STORE
    if _FEATURE_STORE is None:
        from branchpy.image_validation_v3.feature_store import ImageFeatureStore

        _FEATURE_STORE = ImageFeatureStore
    return _FEATURE_STORE


def _lazy_import_cluster_engine():
    """Lazy import cluster engine."""
    global _CLUSTER_ENGINE
    if _CLUSTER_ENGINE is None:
        from branchpy.image_validation_v3.cluster_v3 import ClusterEngineV3

        _CLUSTER_ENGINE = ClusterEngineV3
    return _CLUSTER_ENGINE


def add_parser(subparsers):
    """
    Add media command parsers to main CLI.

    Args:
        subparsers: Argparse subparsers object
    """
    media_parser = subparsers.add_parser(
        "media",
        help="Image validation and media provider commands",
        description="BranchPy Media Validation V3 - Image clustering and provider integration",
    )

    media_subs = media_parser.add_subparsers(dest="media_command", required=True)

    # === CACHE COMMANDS ===
    cache_parser = media_subs.add_parser(
        "cache",
        help="Feature cache management",
        description="Manage image feature vector cache",
    )
    cache_subs = cache_parser.add_subparsers(dest="cache_action", required=True)

    # cache rebuild
    rebuild_parser = cache_subs.add_parser(
        "rebuild", help="Rebuild feature cache from scratch"
    )
    rebuild_parser.add_argument(
        "--root",
        type=str,
        help="Root directory to scan for images (default: ./game/images)",
    )
    rebuild_parser.add_argument(
        "--backend",
        choices=["clip", "resnet50"],
        default="clip",
        help="Feature extraction backend",
    )
    rebuild_parser.add_argument(
        "--project-dir", type=str, default=".", help="Project directory"
    )

    # cache purge
    purge_parser = cache_subs.add_parser("purge", help="Purge cached feature data")
    purge_parser.add_argument(
        "--older-than", type=int, metavar="DAYS", help="Purge entries older than N days"
    )
    purge_parser.add_argument(
        "--missing-only", action="store_true", help="Purge only missing file entries"
    )
    purge_parser.add_argument(
        "--all",
        action="store_true",
        help="Purge all cache data (requires confirmation)",
    )
    purge_parser.add_argument(
        "--project-dir", type=str, default=".", help="Project directory"
    )
    purge_parser.add_argument(
        "-y", "--yes", action="store_true", help="Skip confirmation prompt"
    )

    # cache stats
    stats_parser = cache_subs.add_parser("stats", help="Show cache statistics")
    stats_parser.add_argument(
        "--project-dir", type=str, default=".", help="Project directory"
    )
    stats_parser.add_argument("--json", action="store_true", help="Output as JSON")

    # === CLUSTER COMMANDS ===
    cluster_parser = media_subs.add_parser(
        "cluster",
        help="Image similarity clustering",
        description="Detect duplicate and similar images",
    )
    cluster_parser.add_argument(
        "--source", type=str, required=True, help="Source directory or path pattern"
    )
    cluster_parser.add_argument("--out", type=str, help="Output report path (JSON)")
    cluster_parser.add_argument(
        "--similarity-threshold",
        type=float,
        default=0.86,
        help="Similarity threshold (0.0-1.0, default: 0.86)",
    )
    cluster_parser.add_argument(
        "--duplicate-threshold",
        type=float,
        default=0.98,
        help="Duplicate threshold (default: 0.98)",
    )
    cluster_parser.add_argument(
        "--fast",
        action="store_true",
        help="Fast mode (5x faster, slightly less accurate)",
    )
    cluster_parser.add_argument(
        "--auto-adopt",
        action="store_true",
        help="Auto-adopt canonical images by filename heuristics",
    )
    cluster_parser.add_argument(
        "--backend",
        choices=["clip", "resnet50"],
        default="clip",
        help="Feature extraction backend",
    )
    cluster_parser.add_argument(
        "--goldset",
        type=str,
        help="Path to goldset CSV for precision/recall validation",
    )
    cluster_parser.add_argument(
        "--project-dir", type=str, default=".", help="Project directory"
    )

    # === PROVIDER COMMANDS ===
    provider_parser = media_subs.add_parser(
        "provider",
        help="External provider integration",
        description="Test and fetch from external media providers",
    )
    provider_subs = provider_parser.add_subparsers(
        dest="provider_action", required=True
    )

    # provider test
    test_parser = provider_subs.add_parser("test", help="Test provider connection")
    test_parser.add_argument(
        "--type",
        choices=["mfiles", "onedrive", "dropbox", "webdav"],
        required=True,
        help="Provider type",
    )
    test_parser.add_argument(
        "--config", type=str, required=True, help="Provider configuration JSON file"
    )

    # provider fetch
    fetch_parser = provider_subs.add_parser("fetch", help="Fetch media from provider")
    fetch_parser.add_argument(
        "--provider",
        choices=["mfiles", "onedrive", "dropbox", "webdav"],
        required=True,
        help="Provider type",
    )
    fetch_parser.add_argument(
        "--path", type=str, required=True, help="Remote path or resource ID"
    )
    fetch_parser.add_argument(
        "--out", type=str, required=True, help="Local output directory"
    )
    fetch_parser.add_argument(
        "--recursive", action="store_true", help="Fetch recursively"
    )
    fetch_parser.add_argument(
        "--config", type=str, required=True, help="Provider configuration JSON file"
    )


def run(args: argparse.Namespace) -> int:
    """
    Execute media command.

    Args:
        args: Parsed command-line arguments

    Returns:
        Exit code (0 = success)
    """
    try:
        if args.media_command == "cache":
            return _handle_cache_command(args)
        elif args.media_command == "cluster":
            return _handle_cluster_command(args)
        elif args.media_command == "provider":
            return _handle_provider_command(args)
        else:
            print(f"Unknown media command: {args.media_command}", file=sys.stderr)
            return 1

    except Exception as e:
        logger.error(f"Media command failed: {e}", exc_info=True)
        print(f"Error: {e}", file=sys.stderr)
        return 1


def _handle_cache_command(args: argparse.Namespace) -> int:
    """Handle cache subcommands."""
    project_dir = Path(args.project_dir).resolve()
    cache_dir = project_dir / ".branchpy" / "cache"

    FeatureStore = _lazy_import_feature_store()

    if args.cache_action == "rebuild":
        print("Rebuilding feature cache...")

        backend = args.backend
        root = Path(args.root) if args.root else (project_dir / "game" / "images")

        if not root.exists():
            print(f"Error: Source directory not found: {root}", file=sys.stderr)
            return 1

        store = FeatureStore(cache_dir, backend=backend)

        try:
            store.rebuild(root)
            print("✓ Cache rebuilt successfully")

            stats = store.get_cache_stats()
            print(f"  Vectors: {stats['vector_count']}")
            print(f"  Size: {stats['db_size_mb']:.2f} MB")

        finally:
            store.close()

        return 0

    elif args.cache_action == "purge":
        if not args.yes and not args.missing_only and not args.older_than:
            if args.all:
                confirm = input("Purge ALL cache data? This cannot be undone. (y/N): ")
                if confirm.lower() != "y":
                    print("Cancelled.")
                    return 0

        store = FeatureStore(cache_dir)

        try:
            if args.all:
                store.purge()
                print("✓ All cache data purged")

            elif args.missing_only:
                removed = store.purge_missing()
                print(f"✓ Purged {removed} missing file entries")

            elif args.older_than:
                removed = store.purge_older_than(args.older_than)
                print(f"✓ Purged {removed} entries older than {args.older_than} days")

        finally:
            store.close()

        return 0

    elif args.cache_action == "stats":
        store = FeatureStore(cache_dir)

        try:
            stats = store.get_cache_stats()

            if args.json:
                print(json.dumps(stats, indent=2))
            else:
                print("Feature Cache Statistics")
                print("=" * 60)
                print(f"Vectors:        {stats['vector_count']}")
                print(f"Metadata:       {stats['meta_count']}")
                print(f"Database Size:  {stats['db_size_mb']:.2f} MB")
                print(f"Schema Version: {stats['schema_version']}")
                print(f"Backend:        {stats['backend']}")
                print(f"Cache Dir:      {stats['cache_dir']}")

        finally:
            store.close()

        return 0

    # Catch-all for unexpected cache actions
    print(f"Error: Unknown cache action: {args.cache_action}", file=sys.stderr)
    return 1


def _handle_cluster_command(args: argparse.Namespace) -> int:
    """Handle cluster command."""
    project_dir = Path(args.project_dir).resolve()
    cache_dir = project_dir / ".branchpy" / "cache"

    # Parse source
    source = Path(args.source)
    if not source.exists():
        print(f"Error: Source not found: {source}", file=sys.stderr)
        return 1

    # Find images
    if source.is_dir():
        image_exts = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
        image_paths = []
        for ext in image_exts:
            image_paths.extend(source.rglob(f"*{ext}"))
            image_paths.extend(source.rglob(f"*{ext.upper()}"))
        image_paths = [str(p) for p in image_paths]
    else:
        image_paths = [str(source)]

    if not image_paths:
        print(f"Error: No images found in {source}", file=sys.stderr)
        return 1

    print(f"Found {len(image_paths)} images in {source}")

    # Load feature store
    FeatureStore = _lazy_import_feature_store()
    store = FeatureStore(cache_dir, backend=args.backend)

    try:
        # Index images
        print(f"Indexing images with {args.backend} backend...")

        def progress_callback(current, total, path):
            if current % 100 == 0 or current == total:
                print(f"  [{current}/{total}] {Path(path).name}")

        vectors = store.index_images(image_paths, progress_callback=progress_callback)

        print(f"✓ Indexed {len(vectors)} images")

        # Load goldset if provided
        goldset = None
        if args.goldset:
            goldset = _load_goldset(args.goldset)
            print(f"Loaded goldset: {len(goldset)} labeled pairs")

        # Cluster
        print(f"Clustering (threshold={args.similarity_threshold})...")

        ClusterEngine = _lazy_import_cluster_engine()

        from branchpy.image_validation_v3.similarity import SimilarityConfig

        sim_config = SimilarityConfig(
            duplicate_threshold=args.duplicate_threshold,
            similar_threshold=args.similarity_threshold,
        )

        engine = ClusterEngine(
            similarity_config=sim_config,
            canonicals_path=project_dir / ".branchpy" / "image_canonicals.json",
        )

        clusters, metrics = engine.cluster_vectors(
            vectors, fast_mode=args.fast, goldset=goldset
        )

        # Auto-adopt if requested
        if args.auto_adopt:
            adopted = engine.auto_adopt_by_filename(clusters)
            print(f"✓ Auto-adopted {adopted} canonical images")

        # Display results
        print("\n" + "=" * 60)
        print("Clustering Results")
        print("=" * 60)
        print(f"Total images:      {metrics['images_processed']}")
        print(f"Clusters found:    {len(clusters)}")
        print(f"  Duplicates:      {metrics['duplicates_found']}")
        print(f"  Similar groups:  {metrics['similar_groups_found']}")
        print(f"Duration:          {metrics['duration_seconds']:.2f}s")
        print(f"Peak memory:       {metrics['peak_memory_mb']:.2f} MB")

        if goldset:
            print("\nGoldset Validation:")
            print(f"  Precision:       {metrics.get('precision', 0):.4f}")
            print(f"  Recall:          {metrics.get('recall', 0):.4f}")
            print(f"  F1:              {metrics.get('f1', 0):.4f}")

        # Show top clusters
        if clusters:
            print("\nTop Clusters:")
            sorted_clusters = sorted(
                clusters, key=lambda c: len(c.members), reverse=True
            )
            for cluster in sorted_clusters[:10]:
                canonical = cluster.canonical or "none"
                print(
                    f"  {cluster.group_id}: {len(cluster.members)} images, "
                    f"sim={cluster.avg_similarity:.2%}, "
                    f"type={cluster.cluster_type}, "
                    f"canonical={Path(canonical).name if canonical != 'none' else 'none'}"
                )

        # Export report
        if args.out:
            output_path = Path(args.out)
        else:
            output_path = (
                project_dir
                / ".branchpy"
                / "reports"
                / f"clusters_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            )

        output_path.parent.mkdir(parents=True, exist_ok=True)

        report = {
            "metadata": {
                "timestamp": datetime.now().isoformat(),
                "source": str(source),
                "backend": args.backend,
                "similarity_threshold": args.similarity_threshold,
                "duplicate_threshold": args.duplicate_threshold,
            },
            "metrics": metrics,
            "clusters": [c.to_dict() for c in clusters],
        }

        with open(output_path, "w") as f:
            json.dump(report, f, indent=2)

        print(f"\n✓ Report saved: {output_path}")

    finally:
        store.close()

    return 0


def _handle_provider_command(args: argparse.Namespace) -> int:
    """Handle provider subcommands."""

    if args.provider_action == "test":
        return _test_provider(args)
    elif args.provider_action == "fetch":
        return _fetch_from_provider(args)
    else:
        print(f"Unknown provider action: {args.provider_action}", file=sys.stderr)
        return 1


def _test_provider(args: argparse.Namespace) -> int:
    """Test provider connection."""
    from branchpy.image_validation_v3.providers_v2.registry import get_provider

    # Load config
    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Error: Config file not found: {config_path}", file=sys.stderr)
        return 1

    with open(config_path, "r") as f:
        config = json.load(f)

    credentials = config.get("credentials", {})

    print(f"Testing {args.type} provider connection...")

    try:
        provider = get_provider(args.type, config)

        if provider.connect(credentials):
            print(f"✓ Connected to {args.type}")

            if provider.test_connection():
                print("✓ Connection test passed")
                return 0
            else:
                print("✗ Connection test failed", file=sys.stderr)
                return 1
        else:
            print("✗ Failed to connect", file=sys.stderr)
            return 1

    except Exception as e:
        print(f"✗ Connection error: {e}", file=sys.stderr)
        return 1


def _fetch_from_provider(args: argparse.Namespace) -> int:
    """Fetch media from provider."""
    from branchpy.image_validation_v3.providers_v2.registry import get_provider

    # Load config
    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Error: Config file not found: {config_path}", file=sys.stderr)
        return 1

    with open(config_path, "r") as f:
        config = json.load(f)

    credentials = config.get("credentials", {})
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Fetching from {args.provider}: {args.path}")

    try:
        provider = get_provider(args.provider, config)

        if not provider.connect(credentials):
            print("✗ Failed to connect", file=sys.stderr)
            return 1

        # List assets
        assets = provider.list_images(args.path, recursive=args.recursive)

        print(f"Found {len(assets)} assets")

        # Fetch each asset
        for i, asset in enumerate(assets, 1):
            print(f"  [{i}/{len(assets)}] {asset.path}")

            try:
                data = provider.fetch_image(asset)

                # Save to local file
                local_path = out_dir / Path(asset.path).name
                local_path.write_bytes(data)

            except Exception as e:
                print(f"    ✗ Failed: {e}", file=sys.stderr)

        print(f"✓ Downloaded {len(assets)} assets to {out_dir}")
        return 0

    except Exception as e:
        print(f"✗ Fetch error: {e}", file=sys.stderr)
        return 1


def _load_goldset(goldset_path: str) -> List[Tuple[str, str, bool]]:
    """
    Load goldset from CSV.

    Format: path1,path2,is_similar

    Returns:
        List of (path1, path2, is_similar) tuples
    """
    import csv

    goldset = []
    with open(goldset_path, "r") as f:
        reader = csv.reader(f)
        next(reader, None)  # Skip header if present

        for row in reader:
            if len(row) >= 3:
                path1, path2, is_similar = row[0], row[1], row[2]
                is_similar_bool = is_similar.lower() in ("true", "1", "yes")
                goldset.append((path1, path2, is_similar_bool))

    return goldset
